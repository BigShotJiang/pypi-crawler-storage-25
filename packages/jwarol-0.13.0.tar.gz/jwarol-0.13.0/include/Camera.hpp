#pragma once

class GameObject;

class Camera {
public:
    float x, y;
    float w, h;
    float zoom;
    float smooth;
    GameObject* target;

    Camera(float viewW, float viewH);
    void follow(GameObject* obj);
    void unfollow();
    void update(float dt);
    void apply_to(void* renderer);
};
