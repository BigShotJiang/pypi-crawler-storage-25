#pragma once
#include <cmath>
#include <cstring>

struct Vec2 {
    float x, y;
    Vec2 operator+(const Vec2& o) const { return {x + o.x, y + o.y}; }
    Vec2 operator-(const Vec2& o) const { return {x - o.x, y - o.y}; }
    Vec2 operator*(float s) const { return {x * s, y * s}; }
};

struct Rect {
    float x, y, w, h;
    bool contains(Vec2 p) const {
        return p.x >= x && p.x <= x + w && p.y >= y && p.y <= y + h;
    }
    bool intersects(const Rect& o) const {
        return !(x + w < o.x || x > o.x + o.w || y + h < o.y || y > o.y + o.h);
    }
};

struct Mat3 {
    float m[9];
    Mat3() { identity(); }
    void identity() {
        std::memset(m, 0, sizeof(m));
        m[0] = m[4] = m[8] = 1.0f;
    }
    static Mat3 from_translate(float x, float y) {
        Mat3 r;
        r.m[0] = 1; r.m[1] = 0; r.m[2] = x;
        r.m[3] = 0; r.m[4] = 1; r.m[5] = y;
        r.m[6] = 0; r.m[7] = 0; r.m[8] = 1;
        return r;
    }
    static Mat3 from_rotate(float deg) {
        float rad = deg * 3.14159265f / 180.0f;
        float c = cosf(rad), s = sinf(rad);
        Mat3 r;
        r.m[0] = c; r.m[1] = -s; r.m[2] = 0;
        r.m[3] = s; r.m[4] =  c; r.m[5] = 0;
        r.m[6] = 0; r.m[7] =  0; r.m[8] = 1;
        return r;
    }
    static Mat3 from_scale(float sx, float sy) {
        Mat3 r;
        r.m[0] = sx; r.m[1] = 0;  r.m[2] = 0;
        r.m[3] = 0;  r.m[4] = sy; r.m[5] = 0;
        r.m[6] = 0;  r.m[7] = 0;  r.m[8] = 1;
        return r;
    }
    Mat3 operator*(const Mat3& o) const {
        Mat3 r;
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                r.m[i * 3 + j] = m[i * 3 + 0] * o.m[0 * 3 + j]
                               + m[i * 3 + 1] * o.m[1 * 3 + j]
                               + m[i * 3 + 2] * o.m[2 * 3 + j];
        return r;
    }
    void transform(float& x, float& y) const {
        float nx = m[0] * x + m[1] * y + m[2];
        float ny = m[3] * x + m[4] * y + m[5];
        x = nx; y = ny;
    }
};