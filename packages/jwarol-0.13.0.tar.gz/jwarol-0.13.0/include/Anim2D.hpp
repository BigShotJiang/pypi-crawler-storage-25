#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include "Math.hpp"

class Texture;
class Renderer;

struct Bone2D {
    std::string name;
    int parent;
    float x, y, rotation, sx, sy;
    Bone2D() : parent(-1), x(0), y(0), rotation(0), sx(1), sy(1) {}
};

struct SkeletonData {
    std::vector<Bone2D> bones;
    int add_bone(const std::string& name, int parent = -1);
    int index_of(const std::string& name) const;
    void compute_world(std::vector<Mat3>& out_matrices) const;
};

struct BoneKeyframe {
    float time;
    float x, y, rotation, sx, sy;
    BoneKeyframe() : time(0), x(0), y(0), rotation(0), sx(1), sy(1) {}
};

struct BoneTrack {
    int bone_index;
    std::vector<BoneKeyframe> keyframes;
    void evaluate(float t, bool loop, BoneKeyframe& out) const;
};

struct SkeletalAnimation {
    std::string name;
    float duration;
    float speed;
    bool loop;
    std::vector<BoneTrack> tracks;
    SkeletalAnimation() : duration(1), speed(1), loop(true) {}
    void evaluate(float t, std::vector<Mat3>& out_pose, const SkeletonData& skel) const;
};

struct BoneAttachment {
    int bone_index;
    float ox, oy, w, h;
    float u0, v0, u1, v1;
    BoneAttachment() : bone_index(0), ox(0), oy(0), w(0), h(0), u0(0), v0(0), u1(1), v1(1) {}
};

class AnimatedSprite2D {
public:
    SkeletonData skeleton;
    std::vector<SkeletalAnimation> animations;
    std::vector<BoneAttachment> attachments;
    std::vector<Mat3> bone_poses;
    Texture* texture;
    int current_anim;
    float current_time;
    float speed;
    bool playing;
    bool anim_loop;

    AnimatedSprite2D();
    ~AnimatedSprite2D() = default;

    void set_texture(Texture* tex);
    int add_animation(const SkeletalAnimation& anim);
    bool play(const std::string& name);
    void stop();
    void update(float dt);
    void draw(Renderer* renderer, float x, float y, float scale = 1.0f);

    static AnimatedSprite2D* from_blender(const std::string& json_path, const std::string& tex_path);
};
