#pragma once
#include <string>

class Sound {
public:
    Sound(const std::string& filepath);
    ~Sound();
    void play();
    void stop();
    void set_volume(int vol);
    bool is_playing();
    static void play_file(const std::string& filepath);
private:
    std::string alias;
    std::string path;
    bool loaded;
};
