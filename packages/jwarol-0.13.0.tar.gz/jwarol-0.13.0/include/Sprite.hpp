#pragma once
#include <string>
#include <vector>

class Texture;

class Animation {
public:
    std::vector<int> frames;
    float speed;
    bool loop;

    Animation();
    void add_frame(int index);
    void from_range(int start, int end);
    int size() const;
    static Animation generate(const std::string& type, int count);
};

class Sprite {
public:
    Texture* texture;
    int cols, rows;
    int frameW, frameH;
    int currentFrame;
    float timer;
    float speed;
    bool playing;
    bool loop;
    Animation* anim;
    int animFrame;

    Sprite();
    void set_texture(Texture* tex, int cols, int rows);
    void set_animation(Animation* a);
    void update(float dt);
    void play();
    void stop();
    void reset();
    int get_frame_count() const;
    void get_uv(int frame, float& u0, float& v0, float& u1, float& v1) const;
    void draw_at(void* renderer, float x, float y, float w, float h);
};
