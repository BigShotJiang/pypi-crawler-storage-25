#pragma once
#include <vector>

class Texture;

class DetailGroup {
public:
    DetailGroup();
    ~DetailGroup();
    void set_culling(bool enabled);
    bool get_culling() const;
    void set_max_distance(float dist);
    float get_max_distance() const;
    void set_texture(Texture& tex, int cols = 1, int rows = 1);
    void add(float x, float y, float w, float h,
             float r = 1.0f, float g = 1.0f, float b = 1.0f, float a = 1.0f);
    void add_uv(float x, float y, float w, float h,
                float u0, float v0, float u1, float v1,
                float r = 1.0f, float g = 1.0f, float b = 1.0f, float a = 1.0f);
    void add_frame(float x, float y, float w, float h,
                   int frameCol, int frameRow,
                   float r = 1.0f, float g = 1.0f, float b = 1.0f, float a = 1.0f);
    void clear();
    void draw(float camX, float camY, float viewW, float viewH);
    int count() const;
private:
    struct Instance {
        float x, y, w, h, u0, v0, u1, v1, r, g, b, a;
        bool hasTex;
    };
    std::vector<Instance> instances;
    unsigned int vao, vbo, program;
    bool cullingEnabled;
    float maxDistance;
    Texture* atlas;
    int atlasCols, atlasRows;
    bool useTexture;
    bool glReady;
    void initGL();
};
