"""Core modules — Planner, Coverage."""
