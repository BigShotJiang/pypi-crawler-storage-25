# coding: utf-8
"""
$Id$

output functionality for EBAS NetCDF
"""

import os.path
import sys
import datetime
import itertools
from collections import defaultdict
from six import string_types
from .base import EbasNetcdfBase
from ..base import FLAGS_ALL, EBAS_IOFORMAT_NETCDF1, \
    SUPPRESS_SORT_VARIABLES, SUPPRESS_METADATA_OCCURRENCE, \
    SpatialExtentFormat

try:
    import netCDF4
    import numpy
    NETCDFSTRING = numpy.unicode_ if numpy.__version__ < '2.0' else numpy.str_
except ImportError:
    # pydap and numpy are NOT dependencies for ebas-io. Thus, ebas-io can
    # be used w/o this modules.
    # However the functionality is limited. An error message will be thrown
    # in the entry points of ebas opendap writer (methods write, make_dataset)
    pass


from ..basefile.write import VAL, FLG, MTA

    
class EbasNetCDFPartialWrite(EbasNetcdfBase):  # pylint: disable=R0901, W0223,
    # R0901: Too many ancestors
    # This is a quite big class, therefore we ignore this warning
    # W0223: ... is abstract in base class but is not overridden
    # this class is abstract as well (does not have any NotImplementedError)
    """
    Output of I/O object to NetCDF
    """

    def __init__(self, *args, **kwargs):
        """
        Initialize the object.
        """
        super(EbasNetCDFPartialWrite, self).__init__(*args, **kwargs)
        # dimensions added to the netCFD file only used during write():
        self.dims = None
        self.dvas_metadata = None  # list of dicts for storing the generated DVAS metadata for each variable

    def write(self, createfiles=False, destdir=None, xmlwrap=False,
              fileobj=None, flags=FLAGS_ALL,  # @UnusedVariable
              datadef='EBAS_1.1', metadata_options=0, suppress=0,
              dvas_metadata=False):
        # pylint: disable=R0913,W0613
        # R0913: Too many arguments
        # W0613: Unused argument flags (not used for NetCDF)
        """
        Writes the I/O object to a NetCDF file (or stdout)
        Parameters:
            createfiles   write to file? else write to stdout
                          (special case for fileobj)
            destdir       destination directory path for files
            xmlwrap       wrap output in xml container
            fileobj       write to filehandle
            flags         flag column options: FLAGS_ONE_OR_ALL (default),
                          FLAGS_COMPRESS, FLAGS_ALL, FLAGS_NONE
            datadef       ebas data definition (EBAS_1 or EBAS_1.1)
            metadata_options
                          options for output, bitfield:
                          currently only EBAS_IOMETADATA_OPTION_SETKEY
            suppress      suppress selected consolidations (bitfield):
                              SUPPRESS_SORT_VARIABLES
                              SUPPRESS_METADATA_OCCURRENCE
            dvas_metadata  collect dvas metadata for variables
        Returns:
            None
        """
        self.check_requirements()

        # prepare write used without opening the output file because the netCDF4
        # module cannot handle output to open files. This is somewhere deep in
        # the NetCDF C library and cannot be changed easily. Instead we will
        # pass the file name to netCDF4.
        # Instead, the file logic needs to be handled here, includeing some
        # workaround for stdout/stream outpot (diskleess object, seralized in
        # the end)
        self.prepare_write(
            False, createfiles=createfiles, destdir=destdir, xmlwrap=xmlwrap,
            fileobj=fileobj, datadef=datadef, metadata_options=metadata_options,
            suppress=suppress)

        if createfiles:
            if destdir:
                fnam = os.path.join(destdir, self.metadata.filename)
            else:
                fnam = self.metadata.filename
            # NETCDF3_64BIT_OFFSET ???
            ncfile = netCDF4.Dataset(fnam, mode='w',
                                     format='NETCDF4')
            self.logger.info("writing to file " + fnam)

        else:
            ncfile = netCDF4.Dataset(self.metadata.filename, diskless=True,
                                     mode='w', format='NETCDF4')
        self.ncfile = ncfile

        self.add_global_attributes(metadata_options)
        self.add_time_variables()
        if dvas_metadata:
            self.dvas_metadata = DVAS_Metadata(self)
        self.add_variables()
        #self.parse_characteristics(ncfile)
        #self.create_variables(ncfile, var_time)
        if not createfiles:
            sys.stdout.write(str(ncfile))
        self.finish_write(createfiles, xmlwrap)
        ncfile.close()
        if createfiles and self.dvas_metadata:
            self.dvas_metadata.set_transfersize(os.stat(fnam).st_size)
        self.write_indexdb()

    def check_requirements(self):
        """
        Check requirements for opendap output.
        pydap and numpy are NOT dependencies for ebas-io generally.
        Thus, ebas-io can  be used w/o this modules.
        However the functionality is limited. An error message is thrown here
        and no output produced.
        # Info: make dataset is also a direct entry point (from the webservice)
        """
        # netCDF4 and numpy are NOT dependencies for ebas-io. Thus, ebas-io can
        # be used w/o this modules.
        # However the functionality is limited. An error message is thrown
        # here and no output produced.
        try:
            import netCDF4  # @UnusedImport pylint: disable=W0612, W0621
            # W0612: Unused variable 'netCDF4'
            # W0621: Redefining name 'netCDF4' from outer scope
            # Unused import: netCDF4
            # --> this line is just used to get a nice error message instead
            # of an exception in case of requirements not been installed
        except ImportError:
            self.error("The python netCDF4 module is not installed. NetCDF "
                       "output is not available.")
            return
        try:
            import numpy  # @UnusedImport pylint: disable=W0612, W0621
            # W0612: Unused variable 'netCDF4'
            # W0621: Redefining name 'netCDF4' from outer scope
            # Unused import: netCDF4
            # --> this line is just used to get a nice error message instead
            # of an exception in case of requirements not been installed
        except ImportError:
            self.error("The python numpy module is not installed. NetCDF "
                       "output is not available.")
            return

    def add_global_attributes(self, metadata_options):
        """
        Add global attributes.
        See generate_global_acdd_attributes and generate_global_ebas_attributes
        for details.
        """
        # ACDD atttributes
        for att in self.generate_global_acdd_attributes(metadata_options):
            self.ncfile.setncattr(att[0], att[1])
        for att in self.generate_global_ebas_attributes(
                version=1 if self.__class__.IOFORMAT == EBAS_IOFORMAT_NETCDF1
                else 2):
            self.ncfile.setncattr(att[0], att[1])

    def add_time_variables(self):
        """
        Add the time variables and the time dimenstion.
        """
        self.ncfile.createDimension('time', len(self.sample_times))
        self.ncfile.createDimension('metadata_time',
                                    len(self.metadata_intervals))
        self.ncfile.createDimension('tbnds', 2)

        # Create time variable
        var_time = self.ncfile.createVariable('time', numpy.float64, ('time', ))
        # Add varaible attributes
        var_time.standard_name = 'time'
        var_time.long_name = 'time of measurement'
        var_time.units = 'days since 1900-01-01T00:00:00Z'
        var_time.axis = 'T'
        var_time.calendar = 'standard'
        var_time.bounds = "time_bnds"
        # values for the time variable:
        var_time[:] = netCDF4.date2num(
            [intv[0]+(intv[1]-intv[0])/2 for intv in self.sample_times],
            var_time.units, calendar=var_time.calendar)

        # Create time_bounds variable
        var_time_bounds = self.ncfile.createVariable(
            'time_bnds', numpy.float64, ('time', 'tbnds',))
        
        # Add variable attributes
        var_time_bounds.long_name = 'time bounds for measurement'
        # CF-1.8 (Chapter 7.1): for cell boundaries those attributes are NOT
        # reccommended: units, standard_name, axis, positive, calendar,
        #   leap_month, leap_year
        # var_time_bounds.standard_name = 'time'
        # var_time_bounds.units = 'days since 1900-01-01 00:00:00Z'

        # values for the var_time_bounds variable:
        var_time_bounds[:] = numpy.column_stack((
            netCDF4.date2num([intv[0] for intv in self.sample_times],
                             var_time.units, calendar=var_time.calendar),
            netCDF4.date2num([intv[1] for intv in self.sample_times],
                             var_time.units, calendar=var_time.calendar)))

        # Create metadata_time variable
        var_metadata_time = self.ncfile.createVariable(
            'metadata_time', numpy.float64, ('metadata_time', ))
        # Add varaible attributes
        var_metadata_time.standard_name = 'time'
        var_metadata_time.long_name = 'time of ebas metadata intervals'
        var_metadata_time.units = 'days since 1900-01-01T00:00:00Z'
        var_metadata_time.axis = 'T'
        var_metadata_time.calendar = 'standard'
        var_metadata_time.bounds = "metadata_time_bnds"
        # values for the metadata_time variable:
        var_metadata_time[:] = netCDF4.date2num(
            [intv[0]+(intv[1]-intv[0])/2 for intv in self.metadata_intervals],
            var_metadata_time.units, calendar=var_metadata_time.calendar)

        # Create time_bounds variable
        var_metadata_time_bounds = self.ncfile.createVariable(
            'metadata_time_bnds', numpy.float64, ('metadata_time', 'tbnds',))
        # Add variable attributes
        var_metadata_time_bounds.long_name = \
            'time bounds for ebas metadata intervals'
        # CF-1.8 (Chapter 7.1): for cell boundaries those attributes are NOT
        # reccommended: units, standard_name, axis, positive, calendar,
        #   leap_month, leap_year
        # var_metadata_time_bounds.standard_name = 'time'
        # var_metadata_time_bounds.units = 'days since 1900-01-01 00:00:00Z'
        # var_metadata_time_bounds.calendar = 'gregorian'

        # values for the metadata_time_bounds variable:
        var_metadata_time_bounds[:] = numpy.column_stack((
            netCDF4.date2num([intv[0] for intv in self.metadata_intervals],
                             var_metadata_time.units,
                             calendar=var_metadata_time.calendar),
            netCDF4.date2num([intv[1] for intv in self.metadata_intervals],
                             var_metadata_time.units,
                             calendar=var_metadata_time.calendar)))

    def add_var_dimensions(self, cdm_var):
        """
        Add additional dimensions needed by the cdm variable.
        Parameters:
            cdm_var    the cdm variable description (dict)
        Returns:
            None
        """
        for i in range(len(cdm_var['dimensions'])):
            dim = cdm_var['dimensions'][i]
            if dim not in self.dims:
                self.dims.add(dim)
                self.ncfile.createDimension(
                    dim, len(cdm_var['dimextents'][i]))
                if isinstance(cdm_var['dimextents'][i][0], string_types):
                    var = self.ncfile.createVariable(dim, NETCDFSTRING,
                                                     (dim, ))
                    var[:] = numpy.array([ext
                                          for ext in cdm_var['dimextents'][i]],
                                         NETCDFSTRING)
                elif isinstance(cdm_var['dimextents'][i][0], int):
                    var = self.ncfile.createVariable(dim, numpy.int32, (dim, ))
                    var[:] = numpy.array([ext
                                          for ext in cdm_var['dimextents'][i]],
                                         numpy.int32)
                else:
                    var = self.ncfile.createVariable(dim, numpy.float64,
                                                     (dim, ))
                    var[:] = numpy.array([ext
                                          for ext in cdm_var['dimextents'][i]],
                                         numpy.float64)

    def add_var_attributes(self, var, cdm_var):
        """
        Set the variable attributes for a cdm variable.
        Parameters:
            var        the netCDF variable
            cdm_var    the cdm variable description (dict)
        Returns:
            None
        """
        # use the first variable (of all dimensions) for the attributes
        ebas_var_ind = cdm_var['ebas_variables'][0]
        cfname, cfunit = self.cfparams(ebas_var_ind)
        if cdm_var['var_type'] == FLG:
            var.setncatts({'standard_name': "status_flag"})
            var.setncatts({'missing_value': numpy.int32(0)})
            var.setncatts({'_FillValue': numpy.int32(0)})
            var.setncatts({'units': '1'})
        elif cdm_var['var_type'] == MTA:
            var.setncatts({
                'long_name':
                    "ebas metadata for different time intervals; json encoded"})
        else:
            if cfname:
                var.setncatts({'standard_name': cfname})
            var.setncatts({'missing_value': numpy.float64(numpy.nan)})
            var.setncatts({'_FillValue': numpy.float64(numpy.nan)})
            if cfunit:
                var.setncatts({'units': cfunit})
            else:
                var.setncatts({'units':
                               self.get_meta_for_var(ebas_var_ind, 'unit')})
            var.setncatts({
                'ancillary_variables':
                    "{0}_qc {0}_ebasmetadata".format(cdm_var['cdm_varname'])})
            var.setncatts({'cell_methods': self.cell_methods(ebas_var_ind)})
            if self.__class__.IOFORMAT != EBAS_IOFORMAT_NETCDF1:
                # In version 2 we use all the ebas_XXX attributes:
                atts = defaultdict(int)
                for var_index in cdm_var['ebas_variables']:
                    # In case of addtitional dimensions (characteristics), we
                    # need to make sure, only attributes which are the same for
                    # all variables are used.
                    for att in self.generate_variable_ebas_attributes(
                            var_index=var_index):
                        # double check the types of values:
                        # for now we support only simple types (string, int,
                        # float) and lists of simple types (for multiple values)
                        if isinstance(att[1], (str, int, float)):
                            val = att[1]
                        elif (isinstance(att[1], list) and
                                all(isinstance(v, (str))
                                    for v in att[1])):
                            val = tuple(att[1])
                        else:
                            raise ValueError(
                                "Unsupported attribute value type for "
                                "{}: {}".format(att[0], type(att[1])))
                        atts[(att[0], val)] += 1
                for tag_val in atts:
                    if atts[tag_val] == len(cdm_var['ebas_variables']):
                        var.setncatts({tag_val[0]: tag_val[1]})

    def add_var_data(self, var, cdm_var):
        """
        Set the variable data for a cdm variable.
        Parameters:
            var        the netCDF variable
            cdm_var    the cdm variable description (dict)
        Returns:
            None
        """
        maxlen_ebasmeta = 3   # TODO?
        # now fill the data according to the dims list
        dims = [[tuple([cdm_var['dimensions'][i], k]) for k in cdm_var['dimextents'][i]] for i in range(len(cdm_var['dimensions']))]
        indxs = [[slice(j, j+1) for j in range(len(cdm_var['dimextents'][i]))] for i in range(len(cdm_var['dimensions']))]
        index_perm = itertools.product(*indxs) # index permutations
        for elem in itertools.product(*dims):
            data_ind = next(index_perm)
            idx = cdm_var['variable_dimensions'].index(elem)
            var_index = cdm_var['ebas_variables'][idx]
            if cdm_var['var_type'] == VAL:
                data = numpy.array(
                    self.variables[var_index].values_,
                    dtype=float)
            if cdm_var['var_type'] == FLG:
                # prepare variable flags according to dimensions
                fdim = cdm_var['flag_dimsize']
                tdim = len(self.sample_times)
                data = numpy.empty(shape=(fdim, tdim), dtype=numpy.int32)
                for i in range(fdim):
                    lst = [flag[i] if len(flag) >= i+1 else 0 for flag in self.variables[var_index].flags]
                    data[i] = numpy.array(lst, dtype=numpy.int32)
            if cdm_var['var_type'] == MTA:
                # prepare variable metadata according to metadata_time dimension
                #dtype = 'U{}'.format(maxlen_ebasmeta)
                ebasmeta = [
                    mdi[2].ebas_metadata_json(
                        var_index=var_index,
                        version=1 if self.__class__.IOFORMAT == \
                            EBAS_IOFORMAT_NETCDF1 else 2)
                    for mdi in self.metadata_intervals]
                data = numpy.array(ebasmeta, dtype=NETCDFSTRING)
            var[data_ind] = data

    def add_variables(self):
        """
        Add all data (VAL), metadata (META) and flag (FLG) variables to the
        netCDF file (all except time variables).
        """
        self.gen_cdm_variables()
        self.dims = set()
        for cdm_var in self.cdm_variables.values():
            self.add_var_dimensions(cdm_var)
            if cdm_var['var_type'] == VAL:
                # only for data variable: add additionsl variable dimensions
                # add the variable for holding the measurements
                var = self.ncfile.createVariable(
                    cdm_var['cdm_varname'], numpy.float64,
                    cdm_var['dimensions']+('time', ),
                    fill_value=numpy.float64(numpy.nan))
            if cdm_var['var_type'] == MTA:
                # add the variable for holding the variable metadata
                var = self.ncfile.createVariable(
                    cdm_var['cdm_varname'], NETCDFSTRING,
                    cdm_var['dimensions']+('metadata_time', ))
            if cdm_var['var_type'] == FLG:
                # add the flag dimension for this variable:
                dimname = cdm_var['cdm_varname'] + '_flags'
                self.ncfile.createDimension(dimname, cdm_var['flag_dimsize'])
                #var = self.ncfile.createVariable(dimname, numpy.int32,
                #                                 (dimname, ))
                # add the variable for holding the flags
                var = self.ncfile.createVariable(
                    cdm_var['cdm_varname'], numpy.int32,
                    cdm_var['dimensions']+(dimname, 'time'),
                    fill_value=numpy.int32(0))

            self.add_var_attributes(var, cdm_var)
            self.add_var_data(var, cdm_var)
            if cdm_var['var_type'] == VAL and self.dvas_metadata:
                ebas_var_ind = cdm_var['ebas_variables'][0]
                if self.get_meta_for_var(ebas_var_ind, 'statistics') == \
                        'arithmetic mean':
                    self.dvas_metadata.add_variable(cdm_var)


class DVAS_Metadata:
    """
    Class for storing DVAS metadata for a file.
    """
    def __init__(self, file):
        """
        Initialize the object.
        """
        self.file = file
        self.dataset_metadata = None
        self.identification = None
        self.usage_information = None
        self.product_type = 'observation'
        self.facility = None
        self.spatial_extent = None
        self.temporal_extent = {
            "time_period_begin": self.file.sample_times[0][0].strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            "time_period_end": self.file.sample_times[-1][1].strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
        }
        self.distribution_information = None
        # The array of variables which will be built up during add_variable:
        self.variables = []

        # First collect file global parts.
        self.gen_dataset_metadata()
        self.gen_identification()
        self.gen_usage_information()
        self.gen_facility()
        self.gen_spatial_extent()
        self.gen_distribution_information()

    def gen_dataset_metadata(self) -> None:
        """
        Generate the dataset metadata part.
        Returns:
            None
        """
        if (not self.file.metadata.export_state or
            not self.file.metadata.revdate):
            # not possible actually...
            return None
        export_state = self.file.metadata.export_state.strftime(
            "%Y-%m-%dT%H:%M:%S.%fZ")
        revdate = self.file.metadata.revdate.strftime(
            "%Y-%m-%dT%H:%M:%S.%fZ")
        self.dataset_metadata = {
            "repository": {
              "repository_id": "In-Situ"
            },
            # time_file_created: DOI timestamp rather than file creation time,
            # because the the actual file creation should not be relevant:
            "time_file_created": export_state,
            # time_metadata_created is now
            "time_metadata_created": datetime.datetime.now(
                tz=datetime.UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            # time_content_revised: revision time of the file
            "time_content_revised": revdate,
        }

    def gen_identification(self) -> None:
        """
        Generate the identification part.
        Returns:
            None
        """
        def _gen_person_role(pers):
            data = {}
            if pers.PS_FIRST_NAME:
                data["first_name"] = pers.PS_FIRST_NAME
            if pers.PS_LAST_NAME:
                data["last_name"] = pers.PS_LAST_NAME
            if pers.PS_ORG_NAME:
                data["affiliation"] = {
                    'name': pers.PS_ORG_NAME,
                }
            if pers.PS_ORCID:
                data["orcid"] = pers.PS_ORCID
            return data
                
        if not self.file.metadata.doi or not self.file.metadata.doi[0] or \
                self.file.metadata.doi[1]:
            # Should not happen, dvas metadata can only be generated for files
            # witch containe one single DOI
            raise RuntimeError(
                "DVAS metadata can only be generated for files with one single "
                f"DOI, but file has DOI: {self.file.metadata.doi}")
        self.identification = {
            "identifier": {
                "pid": self.file.metadata.doi[0],
                "pid_type" : "DOI",
            },
            "title": self.file.title(),
            "abstract": self.file.global_abstract_keywords()[0],
            "roles": [],
            "organisations": [],
        }
        for pers in self.file.metadata.submitter:
            data = _gen_person_role(pers)
            if data:
                self.identification["roles"].append({
                    "role_code": ['pointOfContact'],
                    "person": data,
                })
        for pers in self.file.metadata.originator:
            data = _gen_person_role(pers)
            if data:
                self.identification["roles"].append({
                    "role_code": ["principalInvestigator", "originator"],
                    "person": data,
                })
        if not self.identification["roles"]:
            del self.identification["roles"]
        for org in self.file.get_metadata_set('org'):
            data = {
                "name": (
                    org['OR_NAME'] +
                    f', {org["OR_UNIT"]}' if org['OR_UNIT'] else '' +
                    f' ({org["OR_ACRONYM"]})' if org['OR_ACRONYM'] else ''),
                "country_code": org['OR_CODE'][:2],
            }
            self.identification["organisations"].append({
                "role_code": "funding organisation",
                "organisation": data,
            })
            self.identification["organisations"].append({
                "role_code": "data provider",
                "organisation": data,
            })
        if not self.identification["organisations"]:
            del self.identification["organisations"]

    def gen_usage_information(self) -> None:
        """
        Generate the usage information part.
        Returns:
            None
        """
        self.usage_information = {
            "metadata_licence": 'CC0-1.0',
            "citation": self.file.metadata.citation,
            "acknowledgement": self.file.joined_metadata('acknowledgement'),
        }
        
        if self.file.metadata.license == \
                "https://creativecommons.org/licenses/by/4.0/":
            self.usage_information["data_licence"] = 'CC-BY-4.0'

    def gen_facility(self) -> None:
        """
        Generate the facility part.
        Returns:
            None
        """
        from dvas_catalog_mapping.station_mapping import station_mapping
        self.facility = {
            "identifier": station_mapping[
                self.file.metadata.station_code]['actris_identifier'],
            "extra_metadata": {
                "insitu": {
                    "ebas_station_code": self.file.metadata.station_code,
                    "ebas_station_name": self.file.metadata.station_name,
                    "ebas_country_code": self.file.metadata.station_code[:2],
                },
            },
        }
        if self.file.metadata.station_latitude is not None and \
                self.file.metadata.station_longitude is not None:
            self.facility["extra_metadata"]["insitu"]["ebas_station_lat"] = \
                self.file.metadata.station_latitude
            self.facility["extra_metadata"]["insitu"]["ebas_station_lon"] = \
                self.file.metadata.station_longitude
        if self.file.metadata.station_altitude is not None:
            self.facility["extra_metadata"]["insitu"]["ebas_station_alt"] = \
                self.file.metadata.station_altitude

    def gen_spatial_extent(self) -> None:
        """
        Generate the spatial extent part.
        Returns:
            None
        """
        # use basefile's gen_spatiol_extent
        try:
            self.spatial_extent = self.file.spatial_extent(
                SpatialExtentFormat.GEOJSON_DICT, False)
        except ValueError:
            # in case of error (e.g. missing station coordinates), do not set
            # spatial extent
            self.spatial_extent = None

    def gen_distribution_information(self) -> None:
        """
        Generate the distribution information part.
        Returns:
            None
        """
        basedoi = self.file.metadata.doi[0][-9:]
        self.distribution_information = [
            {
                "data_format": "netCDF download",
                "dataset_url": (
                    "https://thredds.nilu.no/thredds/fileServer/ebas_doi/"
                    f"{basedoi[:2]}/{basedoi[2:4]}/{basedoi[5:7]}/{basedoi}.nc"),
                "protocol": "HTTP",
                "access_restriction": {},
                "transfersize": {
                    # size will be set after writing the file (set_transfersize)
                    'size': None,
                    'unit': 'B',
                },
            },
            {
                "data_format": "OPeNDAP",
                "dataset_url": (
                    "https://thredds.nilu.no/thredds/dodsC/ebas_doi/"
                    f"{basedoi[:2]}/{basedoi[2:4]}/{basedoi[5:7]}/{basedoi}.nc"),
                "protocol": "OPeNDAP",
                "access_restriction": {},
                # transfersize is not applicable for OPeNDAP
            },
        ]
        if self.file.access_requirements == [[]]:
            for din in  self.distribution_information:
                din['access_restriction']['restricted'] = False
        else:
            ldesc = []
            for req in self.file.access_requirements:
                ldesc.append('(' + ' & '.join(req) + ')')
            for din in  self.distribution_information:
                din['access_restriction']['restricted'] = True
                din['access_restriction']['description'] = ' | '.join(ldesc)

    def set_transfersize(self, size):
        """
        Set the transfer size for the distribution information.
        Parameters:
            size    the size in bytes
        Returns:
            None
        """
        for din in self.distribution_information:
            if 'transfersize' in din:
                din['transfersize']['size'] = size

    def add_variable(self, cdm_var):
        """
        Add a variable to the DVAS metadata.
        Parameters:
            cdm_var    the cdm variable description (dict)
        Returns:
            None
        """
        var_ind = cdm_var['ebas_variables'][0]
        if not self.file.get_meta_for_var(
                var_ind, 'actris_variable_preferred_term'):
            # do not generate DVAS metadata for variables without actris_
            # metadata
            return
        var_metadata = {
            "variable_name": self.file.get_meta_for_var(
                var_ind, 'actris_variable_preferred_term'),
            "variable_matrix": self.file.get_meta_for_var(
                var_ind, 'actris_matrix_preferred_term'),
            # we need only variable name, matrix and constraints for DVAS,
            # the rest of the metadata is not needed for the variable
            # metadata, but could be added if there is a usecase.
            # "variable_property_of_interest": self.file.get_meta_for_var(
            #    var_ind, 'actris_property_preferred_term'),
            # "object_of_interest": self.file.get_meta_for_var(
            #     var_ind, 'actris_object_preferred_term'),

            # TODO: missing vocabulary for statistics
            #"variable_statistical_property":
            #    self.file.variables[var_ind].metadata.
            #        actris_statistics_preferred_term,
            #
            # TODO: postponed
            #"variable_geometry":
            #    self.file.variables[var_ind].metadata.
            #        actris_geometry_preferred_term,
            #"data_quality_control": 
            # ...see all in md schema and make sure they are filled in _set_actris_md
            # make also sure they are iun ebasmetdata and file.basefile.base
            # (attibutes)
            "timeliness": self.file.get_meta_for_var(
                var_ind, 'actris_timeliness_preferred_term'),
            "temporal_resolution": self.file.get_meta_for_var(
                var_ind, 'actris_temporal_resolution'),
            "method": {
                "title": self.file.get_meta_for_var(var_ind, 'method'),
                "extra_metadata": {
                    "insitu": {
                        "ebas_method_ref": self.file.get_meta_for_var(
                            var_ind, 'method'),
                    }
                }
            },
            "extra_metadata": {
                "insitu": {
                    "ebas_matrix": self.file.get_meta_for_var(
                        var_ind, 'matrix'),
                    "ebas_component_name": self.file.get_meta_for_var(
                        var_ind, 'comp_name'),
                    "ebas_unit": self.file.get_meta_for_var(
                        var_ind, 'unit'),
                    "nc_varname": cdm_var['cdm_varname'],
                }
            },
        }
        if self.file.get_meta_for_var(var_ind,
                                      'actris_constraints_preferred_term'):
            var_metadata["variable_constraints"] = [
                {'constraint': x} for x in self.file.get_meta_for_var(
                    var_ind, 'actris_constraints_preferred_term')]

        agg_inst = [
            [x[0], x[1],
             x[2].get_meta_for_var(var_ind, 'actris_instrument_type_preferred_term'),
             x[2].get_meta_for_var(var_ind, 'actris_instrument_manufacturer_preferred_term'),
             x[2].get_meta_for_var(var_ind, 'actris_instrument_model_preferred_term'),
             x[2].get_meta_for_var(var_ind, 'instr_type'),
             x[2].get_meta_for_var(var_ind, 'lab_code'),
             x[2].get_meta_for_var(var_ind, 'instr_name'),
             x[2].get_meta_for_var(var_ind, 'instr_manufacturer'),
             x[2].get_meta_for_var(var_ind, 'instr_model'),
             x[2].get_meta_for_var(var_ind, 'instr_serialno')]
            for x in self.file.metadata_intervals]
        for i in reversed(range(len(agg_inst))):
            if (i > 0 and agg_inst[i][0] == agg_inst[i-1][1]
                    and agg_inst[i][2:] == agg_inst[i-1][2:]):
                agg_inst[i-1][1] = agg_inst[i][1]
                del agg_inst[i]
        if agg_inst:
            var_metadata["instrument"] = []
            for x in agg_inst:
                inst = {
                    "validtime_start": x[0].strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
                    "validtime_end": x[1].strftime("%Y-%m-%dT%H:%M:%S.%fZ"),

                    
                    "instrument_name": x[7],
                    "extra_metadata": {
                        "insitu": {
                            "ebas_instrument_ref": x[6] + '_' + x[7],
                            "ebas_instrument_type": x[5],
                        }
                    }
                }
                if x[2]:
                    inst["instrument_type"] = x[2]
                if x[3]:
                    inst["instrument_manufacturer"] = x[3]
                if x[4]:
                    inst["instrument_model"] = x[4]
                if x[8]:
                    inst["extra_metadata"]["insitu"][
                        "ebas_instrument_manufacturer"] = x[8]
                if x[9]:
                    inst["extra_metadata"]["insitu"][
                        "ebas_instrument_model"] = x[9]
                if x[10]:
                    inst["extra_metadata"]["insitu"][
                        "ebas_instrument_serialno"] = x[10]
                var_metadata["instrument"].append(inst)

        agg_framework = [
            [x[0], x[1],
             x[2].get_meta_for_var(var_ind, 'actris_framework_preferred_term'),
             x[2].get_meta_for_var(var_ind, 'projects')]
            for x in self.file.metadata_intervals]
        # unnest frameworks from nested lists:
        # the lists of actrios mapped frameworks and ebas projects are sync
        # (see io_from_domain)
        agg_framework = [[x[0], x[1], x[2][i], x[3][i]]
                         for x in agg_framework
                         for i in range(len(x[3]))]
        # sort by project in order to merge afterwards:
        agg_framework.sort(key=lambda x: (x[3], x[0]))
        # merge (same framework for consecutive intervals):
        for i in reversed(range(len(agg_framework))):
            if (i > 0 and agg_framework[i][0] == agg_framework[i-1][1]
                    and agg_framework[i][2:] == agg_framework[i-1][2:]):
                del agg_framework[i]
        if agg_framework:
            var_metadata["framework"] = []
            for x in agg_framework:
                framework = {
                    "validtime_start": x[0].strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
                    "validtime_end": x[1].strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
                    "extra_metadata": {
                        "insitu": {
                            "ebas_framework": x[3],
                        }
                    }
                }
                # add actris framework only if not None
                if x[2]:
                    framework["framework"] = x[2]

                var_metadata["framework"].append(framework)

        if self.file.get_meta_for_var(var_ind, 'std_method'):
            var_metadata["method"]['extra_metadata']['insitu'][
                'ebas_standard_method'] = self.file.get_meta_for_var(
                    var_ind, 'std_method')
        self.variables.append(var_metadata)
        
    def get(self):
        """
        Get the generated DVAS metadata.
        Returns:
            dict with the DVAS metadata
        """
        return {
            "dataset_metadata": self.dataset_metadata,
            "identification": self.identification,
            "usage_information": self.usage_information,
            "product_type": self.product_type,
            "facility": self.facility,
            "spatial_extent": self.spatial_extent,
            "temporal_extent": self.temporal_extent,
            "variables": self.variables,
            "distribution_information": self.distribution_information,
            # TODO:
            #"provenance": ???,
        }