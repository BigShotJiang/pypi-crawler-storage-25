"""
Base classes for (file) I/O.

$Id: write.py 2739 2021-11-19 23:46:25Z pe $
"""

from __future__ import annotations
import sys
import os
import math
from six import PY2
import re
from nilutility.string_helper import list_joiner
from nilutility.datetime_helper import DatetimeISO8601Duration
from ebas.domain.basic_domain_logic.time_period import period_code_iso8601_duration
from .consolidate import EbasFileConsolidate
from ...fileset.xmlwrap import xmlwrap_fileheader, xmlwrap_filetrailer
from ebas.domain.masterdata.dl import EbasMasterDL
from ebas.domain.masterdata.pm import EbasMasterPM
import json
from ..base import FLAGS_ONE_OR_ALL, SpatialExtentFormat


# constants for variable types (used internally)
VAL = 0  # measurement values
FLG = 1  # flags
MTA = 2  # metadata

class EbasFileWriteCDM(EbasFileConsolidate):  # pylint: disable=W0223
    # W0223: ... is abstract in base class but is not overridden
    # this class is abstract as well (does not have any NotImplementedError)
    """
    Partial class for EbasFile (Base class for file objects).
    This part handles methods used for output of CDM related file formats
    (NetCDF, OPeNDAP).
    """

    def __init__(self, *args, **kwargs):
        """
        Initialize the object.
        """
        super(EbasFileWriteCDM, self).__init__(*args, **kwargs)
        # cdm variables, provided by gen_cdm_variables and used by derived
        # classes (NetCDF, OPeNDAP)
        # self.cdm_variables data structure:
        # self.cdm_variables =
        # 'cdm_varname' : {
        #         'var_type' = VAL | FLG | MTA
        #         'cdm_varname' = <key>
        #         'ebas_variables' = [index, index, ...]
        #         'dimensions' = (name, name, ....)
        #         'dimextents' = ([value, value, ...], ...)
        #                          ... for each dimension
        #         'variable_dimensions': (((dimension, value), ...), ...)
        #                          ... for each variable (for each dimension)
        #         'slice': None,
        # }
        self.cdm_variables = None


    def _global_project_list(self):
        """
        Returns a unique, sorted list of global projects.
        Parameters:
            None
        Returns:
            list of strings (proj acronym)
        """
        # generate a sorted list of unique projects
        projset = set()
        for val in self.get_metadata_set('projects'):
            for proj in val:
                projset.add(proj)
        return sorted(list(projset))

    def joined_metadata(self, tag) -> str:
        """
        Joins the metadata values for a given tag into one string.
        Parameters:
            tag         metadata tag
        Returns:
            string with all metadata values for the given tag joined together
        """
        return list_joiner(self.get_metadata_set(tag), ',', insert_space=True)

    def joined_list_metadata(self, tag) -> str:
        """
        Joins the metadata values for a given tag into one string, where each
        metadata value is a list (e.g. projects, doi_list).
        Parameters:
            tag         metadata tag
        Returns:
            string with all metadata values for the given tag joined together
        """
        return list_joiner(
            sorted(list(set([
                x for y in self.get_metadata_set(tag)
                for x in y]))),
            ',', insert_space=True)

    def global_abstract_keywords(self) -> tuple[str, list[str]]:
        """
        Generates an abstract/summary and a keyword list for the dataset.
        Parameters:
            None
        Returns:
            tuple (abstract, keywords_list)
        """
        keywords = []
        if self.metadata.station_name:
            keywords.append(self.metadata.station_name)
        keywords.append(self.metadata.station_code)
        for val in self.get_metadata_set('comp_name', exclude_aux=True):
            if val not in keywords:
                keywords.append(val)
        for val in self.get_metadata_set('matrix', exclude_aux=True):
            if val not in keywords:
                keywords.append(val)
        projects = self._global_project_list()
        for proj in projects:
            if proj not in keywords:
                keywords.append(proj)

        compdesc_list = []
        for varind, _ in enumerate(self.variables):
            desc = f'{self.get_meta_for_var(varind, "comp_name")} in ' + \
                   f'{self.get_meta_for_var(varind, "matrix")}'
            cfname, _ = self.cfparams(varind)
            if cfname:
                desc += f' ({cfname})'
                if cfname not in keywords:
                    keywords.append(cfname)
            if desc not in compdesc_list:
                compdesc_list.append(desc)
        return (
            f"{self.title()}. These measurements are gathered as a part of "
            "the following projects "
            f"{', '.join(self._global_project_list())} and they are stored "
            "in the EBAS database (http://ebas.nilu.no/). "
            f"Parameters measured are: {compdesc_list}",
            keywords)

    def generate_global_acdd_attributes(self, metadata_options):
        """
        Generator for global ACDD (including netCDF COARDS and CF) attributes.
        ACDD is compatible with netCDF basic metadata and CF metadata:
            "The NetCDF User Guide (NUG) provides basic recommendations for
            creating NetCDF files; the NetCDF Climate and Forecast Metadata
            Conventions (CF) provides more specific guidance.
            The ACDD builds upon and is compatible with these conventions;
            it may refine the definition of some terms in those conventions,
            but does not preclude the use of any attributes defined by the NUG
            or CF."
            http://wiki.esipfed.org/index.php/Category:Attribute_Conventions_
                Dataset_Discovery
        Parameters:
            None
        Returns:
            generator, each a tuple (global_attriubute_name, value)
        """
        yield ('Conventions', "CF-1.8, ACDD-1.3")
        yield ('featureType', "timeSeries")

        # title: CF, ACDD:
        yield ('title', self.title())

        abstract, keywords = self.global_abstract_keywords()

        # summary: ACDD recommended attribute
        yield ('summary', abstract)
        
        # keywords: ACDD
        yield ('keywords', list_joiner(keywords))

        # id/naming_authority: ACDD
        yield ('id', self.metadata.filename)
        yield ('naming_authority', 'no.nilu.ebas')

        # project, recommended global attribute ACDD (specified that multiple
        # projects should be separated by commas)
        yield ('project', self.joined_list_metadata('projects'))
        
        # Acknowledgement, recommended global attribute ACDD
        yield ('acknowledgement', self.joined_metadata('acknowledgement'))
        
        yield ('doi', self.joined_list_metadata('doi_list'))

        # license: recommended global attribute ACDD
        license = "https://creativecommons.org/licenses/by/4.0/"
        for fil in [elem[2] for elem in self.metadata_intervals
                    if elem[2] is not self]:
            if fil.metadata.license != license:
                yield ('license', 'Various, see detailed metadata')
                break
        else:
            yield ('license', license)

        # citation (not in ACDD). Just use ebas_citation for now
        if self.metadata.citation:
            yield ('citation', self.metadata.citation)
        
        # source: CF, ACDD
        yield (
            'source',
            'airborn observation' if self.metadata.station_code.endswith('A') \
            else 'surface observation')

        # institution: ACDD
        inst = ''
        for org in self.get_metadata_set('org'):
            lst = [
                org['OR_CODE'],
                org['OR_NAME'],
                org['OR_ACRONYM'],
                org['OR_UNIT'],
                org['OR_ADDR_LINE1'],
                org['OR_ADDR_LINE2'],
                org['OR_ADDR_ZIP'],
                org['OR_ADDR_CITY'],
                org['OR_ADDR_COUNTRY']]
            i = 0
            while i < len(lst):
                if lst[i] is None:
                    del lst[i]
                else:
                    i += 1
            inst += list_joiner(lst)
        yield ('institution', inst)

        # processing level: ACDD
        if not self.metadata._acdd_processing_level and self.metadata.datalevel:
            # not set in from_domain (not from database, but from file convert?
            # in this case we set according to current MasterDataa
            try:
                dl_ = EbasMasterDL()[self.metadata.datalevel]
            except KeyError:
                pass
            else:
                self.metadata._acdd_processing_level = "{}: {} ({})".format(
                    self.metadata.datalevel,
                    dl_.DL_NAME, dl_.DL_DESC)
        if self.metadata._acdd_processing_level:
            yield ('processing_level', self.metadata._acdd_processing_level)

        # date_created: ACDD
        revdate = max(list(self.get_metadata_set('revdate')))
        yield('date_created', self.metadata.export_state.strftime(
            '%Y-%m-%dT%H:%M:%S.%fZ'))
        # date_metadata_modified: ACDD
        yield('date_metadata_modified',
              revdate.strftime('%Y-%m-%dT%H:%M:%SZ'))

        # creator_name, creator_email, creator_institution, creator_type: ACDD
        # use Data Originator as creator_type person
        lst = []
        if self.metadata.originator is not None:
            for ps_ in self.metadata.originator:
                elem = []
                elem.append("{} {}".format(ps_.PS_FIRST_NAME, ps_.PS_LAST_NAME))
                elem.append(ps_.PS_EMAIL)
                elem.append(", ".join([
                    x for x in (ps_.PS_ORG_NAME, ps_.PS_ORG_UNIT, ps_.PS_ORG_ACR)
                    if x]))
                lst.append(elem)
        if lst:
            yield (
                'creator_name',
                list_joiner([x[0] for x in lst], ',', insert_space=True))

            yield ('creator_type', 'person')
            yield (
                'creator_email',
                list_joiner([x[1] for x in lst], ',', insert_space=True))
            yield (
                'creator_institution',
                list_joiner([x[2] for x in lst], ',', insert_space=True))

        # contributor_name, contributor_role: ACDD
        # use Data Submitter as contributoe_role data submitter
        lst = []
        if self.metadata.submitter is not None:
            for ps_ in self.metadata.submitter:
                lst.append(u"{} {}".format(ps_.PS_FIRST_NAME, ps_.PS_LAST_NAME))
            if lst:
                yield (
                    'contributor_name',
                    list_joiner(lst, ',', insert_space=True))
                yield (
                    'contributor_role',
                    list_joiner(['data submitter'] * len(lst), ',',
                                insert_space=True))

        # publisher_name, publisher_email, publisher_url, publisher_type,
        # publisher_institution: ACDD
        yield ('publisher_type', 'institution')
        yield (
            'publisher_name',
            'NILU - Norwegian Institute for Air Research, ATMOS, EBAS')
        # publisher_institution should be the same as publisher_name if
        # publisher_type is institution.
        yield (
            'publisher_institution',
            'NILU - Norwegian Institute for Air Research, ATMOS, EBAS')
        yield ('publisher_email', 'ebas@nilu.no')
        yield ('publisher_url', 'http://ebas.nilu.no/')

        # geospatial_bounds,
        # geospatial_lat_min, geospatial_lat_max, geospatial_lon_min,
        # geospatial_lon_max, geospatial_vertical_min, geospatial_vertical_max,
        # geospatial_vertical_positive:
        #  ALL ACDD
        try:
            wkt, box = self.spatial_extent(SpatialExtentFormat.WKT, True)
        except ValueError:
            self.logger.warning(
                "Could not determine spatial extent")
            yield ('geospatial_bounds', "POINT Z EMPTY")
        else:
            yield ('geospatial_bounds', wkt)
            yield ('geospatial_lat_min', box[1])
            yield ('geospatial_lat_max', box[4])
            yield ('geospatial_lon_min', box[0])
            yield ('geospatial_lon_max', box[3])
            if box[2] is not None and box[5] is not None:
                yield ('geospatial_vertical_min', box[2])
                yield ('geospatial_vertical_max', box[5])
        yield ('geospatial_vertical_positive', "up")
        yield ('geospatial_bounds_crs', "EPSG:4979")

        yield (
            'time_coverage_start',
            self.sample_times[0][0].strftime('%Y-%m-%dT%H:%M:%SZ'))

        yield (
            'time_coverage_end',
            self.sample_times[-1][-1].strftime('%Y-%m-%dT%H:%M:%SZ'))

        dur = DatetimeISO8601Duration()
        dur.diff(self.sample_times[0][0], self.sample_times[-1][-1])
        yield ('time_coverage_duration', dur.format(2))

        dur = period_code_iso8601_duration(self.metadata.resolution)
        yield ('time_coverage_resolution', dur.format(2))

        # timezone: neither CF nor ACDD but definitely useful
        yield ('timezone', "UTC")

    def generate_global_ebas_attributes(self, version=2):
        """
        Generator for global EBAS attributes.
        Those are:
        in Version 1:
         - attributes which contain important information we need for
           further mapping into other metadata standards
         - an attribute 'ebas_metadata' which contains all global EBAS metadata
           as json encoded string
        in Version2:
         - all gloabal metadata with the nc_tag names as ebas_XXX attributes
        Parameters:
            version    attribute and metadata verision (EBAS NetCDF V1 or V2)
                       (the plan is to discontinue V1 after some time, then
                       all this can be thrown away and the code cleaned up)
        Returns:
            generator, each a tuple (global_attriubute_name, value)
        """
        if version == 1:
            yield ('ebas_metadata', self.ebas_metadata_json(version=version))
        else:
            # Version 2:
            # all ebas metadata as separate global attributes with name:
            #  ebas_<nc_tag>
            for meta in self.internal.ebasmetadata.metadata_list_tag_outputvalue(
                    self, nc_tags=True):
                yield (
                    f'{"ebas_" if not meta[0].startswith("actris_") else ""}' +
                        meta[0],
                    int(meta[1]) if isinstance(meta[1], bool) else meta[1])

    def generate_variable_ebas_attributes(self, var_index):
        """
        Generator for EBAS variable attributes. Currently only used in NetCDF V2
        Those are:
         - all variable metadata for variable vnum with the nc_tag names as
           ebas_XXX attributes
        Parameters:
            var_index   variable number in EbasFile object
        Returns:
            generator, each a tuple (variable_attriubute_name, value)
        """
        # Version 2:
        for meta in self.internal.ebasmetadata.metadata_list_tag_outputvalue(
                self, var_index=var_index, explicit_only=False, nc_tags=True):
            yield (
                f'{"ebas_" if not meta[0].startswith("actris_") else ""}' +
                    meta[0],
                int(meta[1]) if isinstance(meta[1], bool) else meta[1])

    def ebas_metadata_json(self, var_index=None, version=2):
        """
        Encodes the ebas metadata for a variable in json.
        Parameters:
            var_index   variable number in nasa ames object
                        Use file global metadata if var_index==None
        Returms:
            The json encoded metadata
        """
        from collections import OrderedDict
        ebas_metadata = OrderedDict()
        for meta in self.internal.ebasmetadata.metadata_list_tag_outputvalue(
                self, var_index=var_index, explicit_only=False,
                nc_tags=False if version == 1 else True):
            if version != 1 and not meta[0].startswith("actris_"):
                key = "ebas_" + meta[0]
            else:
                key = meta[0]
            ebas_metadata[key] = meta[1]
        # characteristics: are implemented as dimensions
        # so usually this here will only apply to the _ebasmetadata variables
        # (where we have metadata for each dimension).
        # In V1 we have a global ebas_metadata attribute, but usually
        # characteristics will not be file global (if more than one single
        # DS is exported)
        # In V2, we do not generate the global JSON attribute at all
        meta = self.metadata if var_index is None \
            else self.variables[var_index].metadata
        if 'characteristics' in meta and meta.characteristics is not None:
            for char in meta.characteristics.sorted():
                ebas_metadata[
                    ('ebas_characteristic ' if version != 1 else '') + \
                    char.CT_TYPE] = char.value_string()
        # json.dumps with ensure_ascii=False keeps unicode encoding, and does
        # not ' \uXXXX' encode it).
        # encoding: just to be sure, if there are str instances with
        # characters > 127 in the input objects, they are considered utf-8
        # (should not be the case, as ebas operates with the unicode type
        # internally)
        return json.dumps(ebas_metadata, indent=4, ensure_ascii=False)

    def cfparams(self, var_index):
        """
        Get the CF name for an EBAS  regime/matrix/component combination.
        Parameters:
            regime       EBAS regime code
            matrix       EBAS matrix name
            comp_name    EBAS component name
            unit         EBAS unit
            statistics   EBAS statistics code
                         (can overrule unit, cfname and cfunit)
            datalevel    used for exceptional PM (masterdata not in database,
                         for lev0 and lev1)
        Returns:
            CF name, CF unit
            None if no CF name exists
        """
        cfname = self.get_meta_for_var(var_index, '_acdd_cfname')
        if cfname:
            # cfname is set already in from_domain, so we can just return it 
            return cfname, self.get_meta_for_var(var_index, '_acdd_cfunit')
        if self.from_domain:
            # file is from_domain, but cfname is not set, so there is no cfname
            # definition for this regime/matrix/component combination in the
            # database. We return None in this case.
            return (None, None)
        # else not set:
        # - the file is not from_domain (converted from other format)
        pm_ = EbasMasterPM()
        regime = self.get_meta_for_var(var_index, 'regime')
        matrix = self.get_meta_for_var(var_index, 'matrix')
        comp = self.get_meta_for_var(var_index, 'comp_name')
        stat = self.get_meta_for_var(var_index, 'statistics')
        unit = self.get_meta_for_var(var_index, 'unit')
        datalevel = self.get_meta_for_var(var_index, 'datalevel')
        try:
            elem = pm_[(regime, matrix, comp, stat, datalevel)]
            # pm masterdata lookup with additional data level:
            # if pm is not defined in DB masterdata, lookup in exceptional
            # masterdata (data level dependent, not meant to be imported)
            # This is only relevant for imported files (not for files
            # read throug from_domain.
        except KeyError:
            elem = None
        if elem is None or elem['PM_UNIT'] != unit:
            # unit converted, lookup with unit
            try:
                elem = pm_.exceptional_unit_exp((
                    regime, matrix, comp, unit))
            except KeyError:
                elem = None
        if elem is None:
            return (None, None)
        return (elem['PM_CFNAME'], elem['PM_CFUNIT'])

    def cell_methods(self, var_index):
        """
        Get the cell_methods attribute (CF) for a variable.
        Parameters:
            var_index   variable number in EbasIO object
        Returms:
            the respective cell_methods attribute value
        """
        # perfect translations, where CF has actually a term:
        translations = {
            #'68.27% lower confidence bound': ,
            #'68.27% upper confidence bound': ,
            #'absolute error': ,
            #'accuracy': ,
            'arithmetic mean': 'mean',
            #'detection limit': 'det.lim.',
            #'expanded uncertainty 2sigma': 'ExpUnc2s',
            #'expanded uncertainty 3sigma': 'ExpUnc3s',
            #'geometric mean': 'gmean',
            'maximum': 'maximum',
            'median': 'median',
            'minimum': 'minimum',
            #'percentile:15.87': 'prec1587',
            #'percentile:84.13': 'perc8413',
            #'precision': 'precision',
            'stddev': 'standard_deviation',
            'uncertainty': 'uncertainty',
            'sample count': 'sample_count',
        }
        stat = self.get_meta_for_var(var_index, 'statistics')
        if self.get_meta_for_var(var_index, 'comp_name').startswith(
                'precipitation_amount') and stat == 'arithmetic mean':
            # special case: precipitation amount is a sum
            return "time: sum"
        if stat in translations:
            return "time: {}".format(translations[stat])
        return "time: {}".format(stat)


    def var_dimensions(self, var_index):
        """
        Get the dimensions (and their value) for a variable.
        Parameters:
            var_index   variable number in EbasIO object
        Returms:
            tupel ([dimensions], {dimvals})
                dimensions is a list of dimension names
                dimvals is a dict (key=dimension names)
            example: (['D'], {'D': 28.5})
        """
        dimensions = []
        dimval = {}
        dcdict = self.get_characteristics_for_var(var_index)

        # special casefor particle diameter: Dmin and Dmax are in reality _one_
        # dimension, convert or D (geom. mean):
        if 'Dmin' in dcdict and 'Dmax' in dcdict and 'D' not in dcdict:
            dcdict['D'] = math.sqrt(dcdict['Dmin'] * dcdict['Dmax'])
        if 'Dmin' in dcdict and 'D' in dcdict:
            del dcdict['Dmin']
        if 'Dmax' in dcdict and 'D' in dcdict:
            del dcdict['Dmax']
        if dcdict:
            from ebas.domain.masterdata.dc import DCListBase
            sortorder = DCListBase.META['SORTORDER']
            for char in sorted(
                    [(sortorder.index(k) if k in sortorder else 999, k)
                     for k in dcdict]):
                # fix the dimension name for valid characters
                # Per now, dimension names contain '/' and ' ' which should be
                # avoided.
                # We replace all non standard characters to '_' for now
                fix_dim = re.sub(r'[^A-Za-z0-9_]', '_', char[1])
                # CF reccommends variable and dimension names to start with
                # a letter, so we add 'd_' in front for all dimensions, this
                # is more consistent than only for those which don't comply.
                fix_dim = 'd_' + fix_dim
                dimensions.append(fix_dim)
                dimval[fix_dim] = dcdict[char[1]]
        return (dimensions, dimval)

    def cdm_flag_dimsize(self, cdm_var):
        """
        Get the size needed for the flag dimension of a _qc variable.
        Parameters:
            cdm_var    the cdm variable description (dict)
        Returns:
            None
        """
        return max([1] + [len(flags)
                          for var_ind in cdm_var['ebas_variables']
                          for flags in self.variables[var_ind].flags])
        
    def gen_cdm_variables(self):
        """
        Find a unique variable name for each variable.
        CF Convention is stricter then Netcdf (NUG) and COARS, it
        recommends:
         - Only letters A-Z, a-Z, digits 0-9, and underscores
         - Start with letter
         - Avoid names that differ only in upper/lower case
         - NUG also recommends to avoid variable names starting with underscore
        (https://cf-convention.github.io/Data/cf-conventions/cf-conventions-1.13/cf-conventions.html#_naming_conventions)
        """
        def _compname_fix(compname):
            """
            Sanitize the comp name to be used as variable name.
            Parameters:
                compname    the component name to sanitize
            Return:
                sanitized version to be used as variable name
            """
            # Per now, component names contain '.', '-' and '+' which should be
            # avoided.
            # We replace all non standard characters to '_' for now, but this
            # might need to be adapted in the future if there are more special
            # characters.
            compname = re.sub(r'[^A-Za-z0-9_]', '_', compname)
            return compname

        def _matrix_ext(matrix_value):
            """
            Sanitize the matrix name to be used as extension in variable name.
            Parameters:
                matrix_value    value of metadata element 'matrix'
            Return:
                sanitized version to be used as extension in variable name
            """
            # Per now, matrix names contain '+' which should be avoided.
            # We replace all non standard characters to '_'.
            return re.sub(r'[^A-Za-z0-9_]', '_', matrix_value)

        def _statistics_ext(stat_value):
            """
            Generate a short version of statistics metadata for use in variable
            name.
            Parameters:
                stat_value    value of metadata element 'statistics'
            Return:
                short version to be used as extension in variable name
            """
            # there are a lot of long statistics names, we need to shorten them
            # for use in variable names.
            # also some of them contain characters which are not allowed in
            # variable names.
            # First we do manual translations for all existsing statistics
            # today:
            statistics = {
                '68.27% lower confidence bound': '6827lcb',
                '68.27% upper confidence bound': '6827ucb',
                'absolute error': 'abs_err',
                'accuracy': 'accuracy',
                'arithmetic mean': 'amean',
                'detection limit': 'det_lim',
                'expanded uncertainty 2sigma': 'ExpUnc2s',
                'expanded uncertainty 3sigma': 'ExpUnc3s',
                'geometric mean': 'gmean',
                'maximum': 'max',
                'median': 'median',
                'minimum': 'min',
                'percentile:15.87': 'prec1587',
                'percentile:84.13': 'perc8413',
                'precision': 'precision',
                'stddev': 'stddev',
                'uncertainty': 'uncertainty',
                'sample count': 'sample_count',
                }
            if stat_value in statistics:
                return statistics[stat_value]
            # Fallback for new statistics: just replace non standard
            # characters with '_'
            return re.sub(r'[^A-Za-z0-9_]', '_', stat_value)

        def _unit_ext(unit_value):
            """
            Generate a modified version of unit metadata for use in variable
            name as an extension. (Background: / is not 100% supported as
            variable name, and is not allowd at all as dimension (flag vars
            will have an additional dimesnion which is generated from the var
            name))
            Parameters:
                unit          value of metadata element 'unit'
            Return:
                modified version to be used as extension in variable name
                this will conform to both var name and dim name conventions
            """
            # Per now units contain '/', ' ' and '%' which should be avoided
            # in variable names
            # '/' is replaced by '_per_'
            unit_value = unit_value.replace('/', '_per_')
            # '%' is replaced by 'pct'
            unit_value = unit_value.replace('%', 'pct')
            # ' ' and all other special characters are replaced by '_'
            return re.sub(r'[^A-Za-z0-9_]', '_', unit_value)

        def _dim_ext(dimensions):
            """
            Generate an extension for distinguishing by var dimensions.
            Parameters:
                dimensions    list of dimension names
            Return:
                string to identify dimensions in var name
            """
            # The valid cgaracters in the dimension names are already
            # sanitized (see self.var_dimensions), so we just need to join
            # them together.
            return '_'.join(dimensions)

        # frame is a helper structure for sorting and structuring the variables
        # framekey=(compname, matrix, unit, stat, dimensions)
        # dimkey = tupel(tupel(dim: dimval), ...)
        # frame =  {
        #     framekey:
        #         [
        #             'cdm_varname':
        #             'ebas_variables' = {dimkey: var_index}
        #         ]}
        frame = {}
        # find possible additional dimensions (i.e. characteristics):
        for i in range(len(self.variables)):
            compname = self.get_meta_for_var(i, 'comp_name').replace('.', '_')
            # . not allowed in netCDF (at least in OPeNDAP (pydap client))
            dimensions, dimval = self.var_dimensions(i)
            key = (compname,
                   self.get_meta_for_var(i, 'matrix'),
                   self.get_meta_for_var(i, 'unit'),
                   self.get_meta_for_var(i, 'statistics'),
                   tuple(dimensions))
            dimkey = tuple((dim, dimval[dim]) for dim in dimensions)
            if key in frame:
                # there is already at least one variable with the same core data
                # note: dimensions is correctly sorted, so will be dimkey
                for elem in frame[key]:
                    if dimkey in elem['ebas_variables']:
                        # See comment NOTE_DUPLICATE_VARIABLES below!
                        # Same comp, matrix, unit, statistics, dimensions
                        # and duplicate value for dimensions?
                        # This might be a co-located measurement (2 instruments
                        # 2 methods)?
                        # Else, we need to add an element to the frame key!
                        # Here we continue, which means there is another cdm
                        # variable already in the list, or we create a new one  .
                        continue
                    else:
                        # add this to ebas_variables:
                        elem['ebas_variables'][dimkey] = i
                        break
                else:
                    # add a new variable
                    frame[key].append({
                        'cdm_varname': _compname_fix(compname),
                        'ebas_variables': {dimkey: i}})
            else:
                # add a new key:
                frame[key] = [{
                    'cdm_varname': _compname_fix(compname),
                    'ebas_variables': {dimkey: i}}]

        # Solve duplicate cdm variable names:
        for key in frame.keys():
            jdiff = set()
            change = set()
            for other in frame.keys():
                if key == other:
                    continue
                # We only need to check the first list element, the other
                # elements are numbered sequentially.
                # (See comments NOTE_DUPLICATE_VARIABLES above and below)
                if frame[key][0]['cdm_varname'] == \
                   frame[other][0]['cdm_varname']:
                    change.add(key)
                    change.add(other)
                    if key[1] != other[1]:
                        jdiff.add('matrix')
                    if key[2] != other[2]:
                        jdiff.add('unit')
                    if key[3] != other[3]:
                        jdiff.add('statistics')
                    if key[4] != other[4]:
                        jdiff.add('dimensions')
                    if not jdiff:
                        raise RuntimeError(
                            'duplicate cdm variable name: {}'.format(
                                frame[key][0]['cdm_varname']))
            for other in change:
                if 'matrix' in jdiff:
                    for elem in frame[other]:
                        elem['cdm_varname'] += '_' + _matrix_ext(other[1])
                if 'unit' in jdiff:
                    for elem in frame[other]:
                        elem['cdm_varname'] += '_' + _unit_ext(other[2])
                if 'statistics' in jdiff:
                    for elem in frame[other]:
                        elem['cdm_varname'] += '_' + _statistics_ext(other[3])
                if 'dimensions' in jdiff:
                    for elem in frame[other]:
                        if other[4]:
                            elem['cdm_varname'] += '_' + _dim_ext(other[4])
        # Double check: still dulpicate variables?
        for key in frame.keys():
            for other in frame.keys():
                if key == other:
                    continue
                if frame[key][0]['cdm_varname'] == \
                   frame[other][0]['cdm_varname']:
                    raise RuntimeError(
                        'duplicate cdm variable name: {}'.format(
                            frame[key][0]['cdm_varname']))

        # See comment NOTE_DUPLICATE_VARIABLES above!
        # Sequentially number duplicate cdm variables within one framekey:
        for key in frame:
            if len(frame[key]) > 1:
                for i, elem in enumerate(frame[key]):
                    elem['cdm_varname'] += '_{}'.format(i)

        # now the cdm_varnames are unique, lets build the cdm var structure:
        # structure layout see __init__
        self.cdm_variables = {}
        for key in frame.keys():
            for elem in frame[key]:
                newvar = \
                    {
                        'var_type': None,  # will be set later to VAL, FLG or MTA
                        'cdm_varname': None,  # will be set later
                        'ebas_variables': [],
                        'dimensions': key[4],
                        'dimextents': [[] for i in range(len(key[4]))],
                        'variable_dimensions': []
                    }
                for dimkey in sorted(elem['ebas_variables']):
                    newvar['ebas_variables'].append(
                        elem['ebas_variables'][dimkey])
                    for i in range(len(dimkey)):
                        if dimkey[i][1] not in newvar['dimextents'][i]:
                            newvar['dimextents'][i].append(dimkey[i][1])
                    newvar['variable_dimensions'].append(dimkey)

                vname = 'v_' + elem['cdm_varname']
                self.cdm_variables[vname] = newvar.copy()
                self.cdm_variables[vname]['var_type'] = VAL
                self.cdm_variables[vname]['cdm_varname'] = vname
                
                vname = 'qc_' + elem['cdm_varname']
                self.cdm_variables[vname] = newvar.copy()
                self.cdm_variables[vname]['var_type'] = FLG
                self.cdm_variables[vname]['flag_dimsize'] = \
                    self.cdm_flag_dimsize(self.cdm_variables[vname])
                self.cdm_variables[vname]['cdm_varname'] = vname

                vname = 'meta_' + elem['cdm_varname']
                self.cdm_variables[vname] = newvar.copy()
                self.cdm_variables[vname]['var_type'] = MTA
                self.cdm_variables[vname]['cdm_varname'] = vname

        # check if variable with same dimensions names have the same dimension
        # entents.
        # if the dimension name is the same, but the dimension extents are
        # different in different variables, we generate a new dimension name
        # for each different dimension extent.
        # First check conflicts and collect them in dimclean.
        # dimclean is a dictionary with key=dimension name, value=list of
        # different dimension extents for this dimension name.
        from collections import defaultdict
        dimclean = defaultdict(list)
        cdm_vnames = list(self.cdm_variables.keys())
        for vind1 in range(len(cdm_vnames)):
            var1 = self.cdm_variables[cdm_vnames[vind1]]
            for vind2 in range(vind1+1, len(cdm_vnames)):
                var2 = self.cdm_variables[cdm_vnames[vind2]]
                for dind1 in range(len(self.cdm_variables[cdm_vnames[vind1]]
                                       ['dimensions'])):
                    for dind2 in range(len(self.cdm_variables[cdm_vnames[vind2]]
                                           ['dimensions'])):
                        if var1['dimensions'][dind1] == \
                                var2['dimensions'][dind2] and \
                           var1['dimextents'][dind1] != \
                                var2['dimextents'][dind2]:
                                if var1['dimextents'][dind1] not in dimclean[var1['dimensions'][dind1]]:
                                    dimclean[var1['dimensions'][dind1]].append(
                                        var1['dimextents'][dind1])
                                if var2['dimextents'][dind2] not in dimclean[var2['dimensions'][dind2]]:
                                    dimclean[var2['dimensions'][dind2]].append(
                                        var2['dimextents'][dind2])
        # cleanup dimension names if necessary (append _d1, _d2, ... to the
        # dimension name
        if dimclean:
            for vind1 in range(len(cdm_vnames)):
                var1 = self.cdm_variables[cdm_vnames[vind1]]
                for dind1 in range(len(self.cdm_variables[cdm_vnames[vind1]]
                                       ['dimensions'])):
                    if var1['dimensions'][dind1] in dimclean:
                        old_dim = var1['dimensions'][dind1]
                        new_dim = old_dim + f'_d{dimclean[old_dim].index(var1["dimextents"][dind1])}'
                        
                        # tuple is immutable, convert to list and back...
                        lst = list(var1['dimensions'])
                        lst[dind1] = new_dim
                        var1['dimensions'] = tuple(lst)
                        
                        var1['variable_dimensions'] = [
                            tuple((new_dim, y[1]) if y[0] == old_dim else y
                                  for y in x)
                            for x in var1['variable_dimensions']]


class EbasFileWrite(EbasFileWriteCDM):  # pylint: disable=W0223
    # W0223: ... is abstract in base class but is not overridden
    # this class is abstract as well (does not have any NotImplementedError)
    """
    Partial class for EbasFile (Base class for file objects).
    This part handles generic methods for file output.
    """

    def prepare_write(
            self, open_file, createfiles=False, destdir=None, xmlwrap=False,
            fileobj=None, flags=FLAGS_ONE_OR_ALL, datadef='EBAS_1.1',
            metadata_options=0, suppress=0):
        """
        Prepare the IO object for writing.
        Used for all output formats (Nasa Ames, CSV, NetCDF, OPeNDAP, XML)
        Parameters:
            open_file  wheter the oputut file should be opened and the file
                       handle be returned. (Should net be done for certain
                       types of output objects (e.g. EbasNetCDF) or on the
                       atomic files within an EbasJoinedFile container)
            createfiles   write to file? else write to stdout
                          (special case for fileobj)
            destdir       destination directory path for files
            xmlwrap       wrap output in xml container
            fileobj       write to filehandle
            flags         flag column options: FLAGS_ONE_OR_ALL (default),
                          FLAGS_COMPRESS, FLAGS_ALL, FLAGS_NONE
            datadef       ebas data definition (EBAS_1 or EBAS_1.1)
            metadata_options
                          options for output, bitfield:
                          currently only EBAS_IOMETADATA_OPTION_SETKEY
            suppress      suppress selected consolidations (bitfield):
                              SUPPRESS_SORT_VARIABLES
                              SUPPRESS_METADATA_OCCURRENCE
        Returns
            filehandle (None if not open_file)
        """
        # must be implemented here, because ebasmetadata can't be imported in
        # ..base
        self.metadata.datadef = datadef
        # make sure datadef is not defined in any variable:
        for var in self.variables:
            if 'datadef' in var.metadata:
                del(var.metadata.datadef)
        self.setup_ebasmetadata(datadef, metadata_options)
        # finalize the EbasFile metadata structure:
        self.set_timespec_metadata()
        self.set_default_metadata()
        self.consolidate_metadata(flags=flags, suppress=suppress)
        # set_citation after consolidate_metadata:
        # originators and revdate are consolidated
        self.set_citation(metadata_options)

        self.gen_filename(createfiles, destdir)
        # Used for header and filename if physical file is written).
        # A "genuine" filename is generated already in consolidate_metadata,
        # but this time it's also checked for uniqueness if needed.

        if not createfiles and xmlwrap:
            xmlwrap_fileheader(self.metadata.filename)
        if not open_file:
            return

        if createfiles:
            fnam = self.metadata.filename
            if destdir:
                fnam = os.path.join(destdir, self.metadata.filename)
            if PY2:
                mod = "w"
            else:
                mod = "wb"
            fil = open(fnam, mod)
            self.logger.info("writing to file " + fnam)
        elif fileobj:
            # redirect output to given file-like object
            fil = fileobj
        else:
            if PY2:
                fil = sys.stdout

            else:  # PY3
                from io  import _io
                if isinstance(sys.stdout, _io.TextIOWrapper):
                    # std stream in py3 is an encoding wrapper. We need to use
                    # the unencoded buffer directly in order to write bytes.
                    # We need to check if it's really a TextIOWrapper, otherwise
                    # we get problems with jupyter.
                    fil = sys.stdout.buffer
                else:
                    fil = sys.stdout
        return fil

    @staticmethod
    def finish_write(createfiles, xmlwrap):
        """
        Finish file write.
        Parameters:
            createfiles   output to file or stdout
            xmlwrap       whether the xml wrapper must be closed
        Returns
            None
        """
        if not createfiles and xmlwrap:
            xmlwrap_filetrailer()

    # Methods for the generation of NetCDF like output objetcs
    # (OPeNDAP, NetCDF, ...)
