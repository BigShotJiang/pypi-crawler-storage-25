"""
decorator wrapper and hook for typechecks in dev environment

    decorator example:

        from nilutility.typecheck import typechecked
        @typechecked
        def my_method(x: float) -> None:
            ...

    -> typechecking ifor the decorated method will be turned on if the ENV
       variable is set to dev _and_ the typeguard package is installed, else
       silently ignored




    install hooks (turning on typecheck for all modules in dev):

        from nilutility.typecheck import install_all_import_hooks
        install_all_import_hooks()
        from ebas.petst import greetings

    --> typechecking will be turned on for all methods in all packages if the
        ENV variable is set to dev _and_ the typeguard package is installed,
        else, silently ignored
                                                                                 
"""
    
import os

IS_DEV = os.getenv("TYPECHECK", "off") == "on"

if IS_DEV:
    try:
        from typeguard import typechecked
    except ImportError:
        # Fallback if typeguard not installed
        def typechecked(func):
            return func
else:
    # Production: no-op decorator
    def typechecked(func):
        return func


def install_all_import_hooks():
    if IS_DEV:
        try:
            from typeguard import install_import_hook
            install_import_hook()
        except ImportError:
            pass
