# PDF → DOCX Converter

> A sleek, dark-themed desktop app to convert PDF documents into editable Word files — no command line needed.

---

## Preview

```
PDF  →  DOCX
Convert PDF documents to editable Word files

[ ⬆  Click to upload PDF here ]

OUTPUT FILE
[ path/to/output.docx          ] [ Browse ]

[         Convert          ]

▸  Selected: document.pdf
▸  Starting conversion…
▸  Conversion complete!
```

---

## Features

- 🖱️ **Click-to-upload** file picker with visual feedback
- 📄 **Auto-suggests** output path based on input filename
- ⚡ **Non-blocking conversion** — runs in a background thread so the UI stays responsive
- 📊 **Animated progress bar** with indeterminate and completion states
- 🪵 **Live log panel** with colour-coded status messages
- 🎨 **Dark UI** built with pure `tkinter` — no external GUI dependencies

---

## Requirements

- Python **3.7+**
- `tkinter` (bundled with standard Python on Windows and macOS)
- [`pdf2docx`](https://github.com/dothinking/pdf2docx)

---

## Installation

```bash
pip install pdf2DocxGUIbyeliteVaibhav
```

This will automatically install `pdf2docx` as a dependency.

> **Linux users:** `tkinter` may need to be installed separately:
> ```bash
> sudo apt install python3-tk   # Debian/Ubuntu
> sudo dnf install python3-tkinter  # Fedora
> ```

---

## Usage

After installing, launch the app from your terminal:

```bash
pdf2DocxGUIbyeliteVaibhav
```

Or run it directly with Python:

```python
from pdf2DocxGUIbyeliteVaibhavimport mainFunc

mainFunc()
```

### Steps

1. Click the upload zone and select your PDF file
2. The output path is auto-filled — or click **Browse** to choose a custom save location
3. Click **Convert**
4. Find your `.docx` file at the chosen output path

---

## How It Works

Under the hood, the conversion is powered by [`pdf2docx`](https://github.com/dothinking/pdf2docx), which parses PDF structure and rebuilds it as a Word document — preserving layout, text, tables, and images where possible.

The GUI is built entirely with Python's built-in `tkinter` library, keeping the install footprint minimal.

---

## Limitations

- Conversion quality depends on the source PDF. Scanned/image-only PDFs will not produce editable text (no OCR support).
- Complex layouts (multi-column, heavy graphics) may not convert perfectly — this is a limitation of `pdf2docx` itself.

---

## Contributing

Pull requests are welcome! Please open an issue first to discuss any major changes.

```bash
git clone https://github.com/vaibhavbhor404/pdf-to-docx-gui
cd pdf-to-docx-gui
pip install -e ".[dev]"
```

---

## License

MIT © eliteVaibhav
