from .mymodule import main
