from __future__ import annotations

import sys
from pathlib import Path

from typer.testing import CliRunner


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "cli"))

from raze_cli import main  # noqa: E402

runner = CliRunner()


def _empty_bundle_status() -> main.BundleStatus:
    return main.BundleStatus(
        root=None,
        manifest_path=None,
        manifest={},
        components=[],
        bundle_version=None,
        release_manifest_url=None,
        dashboard_mode="unavailable",
        dashboard_source_path=None,
        dashboard_dist_path=None,
        core_path=None,
        managed_runtime=False,
        runtime_env_dir=None,
        runtime_python=None,
        forbidden_entries=[],
    )


def test_get_source_tree_root_detects_expected_layout(monkeypatch, tmp_path: Path):
    workspace = tmp_path / "raze"
    (workspace / "services" / "core").mkdir(parents=True)
    (workspace / "apps" / "dashboard").mkdir(parents=True)

    monkeypatch.setattr(main, "get_workspace_root", lambda: workspace)

    assert main.get_source_tree_root() == workspace


def test_render_dashboard_command_returns_none_without_source_tree(monkeypatch):
    monkeypatch.setattr(main, "get_source_tree_root", lambda: None)

    assert main._render_dashboard_command(52000) is None


def test_render_dashboard_command_uses_dashboard_source_dir(monkeypatch, tmp_path: Path):
    workspace = tmp_path / "raze"
    dashboard_dir = workspace / "apps" / "dashboard"
    dashboard_dir.mkdir(parents=True)
    (workspace / "services" / "core").mkdir(parents=True)

    monkeypatch.setattr(main, "get_source_tree_root", lambda: workspace)

    command = main._render_dashboard_command(52000)
    assert command == f"cd {dashboard_dir} && npm run dev -- --port 52000"


def test_can_launch_installed_core_returns_false_when_package_is_missing(monkeypatch):
    def fake_find_spec(_name: str):
        raise ModuleNotFoundError("No module named 'raze_core'")

    monkeypatch.setattr(main.importlib.util, "find_spec", fake_find_spec)

    assert main._can_launch_installed_core() is False


def test_dashboard_handles_missing_runtime_without_traceback(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: _empty_bundle_status())
    monkeypatch.setattr(
        main,
        "acquire_managed_bundle",
        lambda **_kwargs: (_ for _ in ()).throw(main.RuntimeAcquisitionError("manifest is unavailable")),
    )

    result = runner.invoke(main.app, ["dashboard"])

    assert result.exit_code == 1
    assert "could not prepare the local runtime automatically" in result.output.lower()
    assert "manifest is unavailable" in result.output.lower()
    assert "raze bootstrap --bundle-dir <bundle-root>" in result.output
    assert "Traceback" not in result.output


def test_setup_skips_dashboard_prompt_when_runtime_is_missing(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: _empty_bundle_status())
    monkeypatch.setattr(main, "_dashboard_launch_ready", lambda status: False)
    monkeypatch.setattr(main, "_create_config", lambda config_path: config_path.write_text("providers: []\n", encoding="utf-8"))

    result = runner.invoke(main.app, ["setup"])

    assert result.exit_code == 0
    assert "Skipping dashboard launch until the managed local runtime is ready." in result.output
    assert "Open the local dashboard after setup?" not in result.output


def test_doctor_reports_missing_runtime_guidance(monkeypatch, tmp_path: Path):
    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: _empty_bundle_status())
    monkeypatch.setattr(main, "_can_launch_installed_core", lambda: False)

    async def raise_missing_core():
        raise RuntimeError("Core unavailable")

    monkeypatch.setattr(main.client, "run_doctor", raise_missing_core)

    result = runner.invoke(main.app, ["doctor"])

    assert result.exit_code == 0
    assert "Bundle:" in result.output
    assert "run raze onboard" in result.output.lower()
    assert "raze bootstrap --bundle-dir <bundle-root>" in result.output


def test_doctor_reports_outdated_bundle_state(monkeypatch, tmp_path: Path):
    bundle_root = tmp_path / "bundle"
    bundle_root.mkdir()
    bundle_status = main.BundleStatus(
        root=bundle_root,
        manifest_path=bundle_root / "distribution" / "raze-bundle.json",
        manifest={},
        components=[],
        bundle_version="1.0.0",
        release_manifest_url=None,
        dashboard_mode="bundled-static",
        dashboard_source_path=None,
        dashboard_dist_path=bundle_root / "apps" / "dashboard" / "dist",
        core_path=bundle_root / "services" / "core",
        managed_runtime=True,
        runtime_env_dir=tmp_path / "env",
        runtime_python=None,
        forbidden_entries=[],
    )

    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_bundle_status", lambda explicit_root=None, allow_dev_fallback=True: bundle_status)
    monkeypatch.setattr(main, "_can_launch_installed_core", lambda: True)
    monkeypatch.setattr(
        main,
        "load_update_status",
        lambda _data_dir: {
            "status": "update_available",
            "checked_version": "1.0.0",
            "latest_version": "1.0.1",
        },
    )

    async def raise_missing_core():
        raise RuntimeError("Core unavailable")

    monkeypatch.setattr(main.client, "run_doctor", raise_missing_core)

    result = runner.invoke(main.app, ["doctor"])

    assert result.exit_code == 0
    assert "Update state:" in result.output
    assert "latest v1.0.1" in result.output


def test_onboard_prepares_runtime_and_launches_dashboard(monkeypatch, tmp_path: Path):
    bundle_root = tmp_path / "bundle"
    bundle_root.mkdir()
    bundle_status = main.BundleStatus(
        root=bundle_root,
        manifest_path=bundle_root / "distribution" / "raze-bundle.json",
        manifest={},
        components=[],
        bundle_version="1.0.0",
        release_manifest_url=None,
        dashboard_mode="bundled-static",
        dashboard_source_path=None,
        dashboard_dist_path=bundle_root / "apps" / "dashboard" / "dist",
        core_path=bundle_root / "services" / "core",
        managed_runtime=True,
        runtime_env_dir=tmp_path / "env",
        runtime_python=tmp_path / "env" / "Scripts" / "python.exe",
        forbidden_entries=[],
    )
    calls: list[str] = []

    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_ensure_runtime_bundle", lambda command_label: calls.append(f"bundle:{command_label}") or bundle_status)
    monkeypatch.setattr(main, "_launch_dashboard_flow", lambda status, command_label: calls.append(f"launch:{command_label}:{status.root}"))

    result = runner.invoke(main.app, ["onboard"])

    assert result.exit_code == 0
    assert calls == [f"bundle:onboard", f"launch:onboard:{bundle_root}"]


def test_dashboard_prepares_runtime_and_launches_dashboard(monkeypatch, tmp_path: Path):
    bundle_root = tmp_path / "bundle"
    bundle_root.mkdir()
    bundle_status = main.BundleStatus(
        root=bundle_root,
        manifest_path=bundle_root / "distribution" / "raze-bundle.json",
        manifest={},
        components=[],
        bundle_version="1.0.0",
        release_manifest_url=None,
        dashboard_mode="bundled-static",
        dashboard_source_path=None,
        dashboard_dist_path=bundle_root / "apps" / "dashboard" / "dist",
        core_path=bundle_root / "services" / "core",
        managed_runtime=True,
        runtime_env_dir=tmp_path / "env",
        runtime_python=tmp_path / "env" / "Scripts" / "python.exe",
        forbidden_entries=[],
    )
    calls: list[str] = []

    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(main, "_ensure_runtime_bundle", lambda command_label: calls.append(f"bundle:{command_label}") or bundle_status)
    monkeypatch.setattr(main, "_launch_dashboard_flow", lambda status, command_label: calls.append(f"launch:{command_label}:{status.root}"))

    result = runner.invoke(main.app, ["dashboard"])

    assert result.exit_code == 0
    assert calls == [f"bundle:dashboard", f"launch:dashboard:{bundle_root}"]
