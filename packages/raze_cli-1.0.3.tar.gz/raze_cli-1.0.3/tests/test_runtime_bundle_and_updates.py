from __future__ import annotations

import json
import shutil
from pathlib import Path

from raze_cli.runtime_bundle import (
    RuntimeAcquisitionError,
    acquire_managed_bundle,
    find_forbidden_runtime_entries,
    inspect_bundle,
    load_bundle_installation,
    resolve_bundle_root,
    save_bundle_installation,
)
from raze_cli.updates import build_update_status, compare_versions

ROOT = Path(__file__).resolve().parents[2]


def test_resolve_bundle_root_prefers_registered_bundle(monkeypatch, tmp_path: Path):
    data_dir = tmp_path / "data"
    bundle_root = tmp_path / "bundle"
    bundle_root.mkdir()
    save_bundle_installation(bundle_root, data_dir=data_dir, source="test")

    resolved = resolve_bundle_root(data_dir=data_dir, workspace_root=tmp_path / "missing")

    assert resolved == bundle_root.resolve()


def test_resolve_bundle_root_does_not_fallback_when_explicit_path_is_missing(tmp_path: Path):
    resolved = resolve_bundle_root(explicit_root=str(tmp_path / "missing"))

    assert resolved is None


def test_inspect_bundle_reads_manifest_and_detects_bundled_dashboard(tmp_path: Path):
    root = tmp_path / "bundle"
    (root / "distribution").mkdir(parents=True)
    (root / "services" / "core").mkdir(parents=True)
    (root / "apps" / "dashboard" / "dist").mkdir(parents=True)
    (root / "apps" / "dashboard" / "dist" / "index.html").write_text("<html></html>", encoding="utf-8")
    (root / "employees").mkdir()
    (root / "packages" / "shared-specs").mkdir(parents=True)

    manifest = {
        "bundle_version": "1.0.0",
        "components": {
            "core": {"label": "Core", "kind": "python-runtime", "path": "services/core", "required": True},
            "dashboard": {
                "label": "Dashboard",
                "kind": "web-runtime",
                "source_path": "apps/dashboard",
                "dist_path": "apps/dashboard/dist",
                "required": True,
            },
            "employees": {"label": "Employees", "kind": "definitions", "path": "employees", "required": True},
            "shared_specs": {"label": "Shared Specs", "kind": "shared-assets", "path": "packages/shared-specs", "required": True},
        },
    }
    (root / "distribution" / "raze-bundle.json").write_text(json.dumps(manifest), encoding="utf-8")

    status = inspect_bundle(explicit_root=str(root))

    assert status.bundle_version == "1.0.0"
    assert status.dashboard_mode == "bundled-static"
    assert status.dashboard_dist_path == (root / "apps" / "dashboard" / "dist").resolve()
    assert any(component.key == "core" and component.present for component in status.components)


def test_inspect_bundle_resolves_relative_release_manifest_source(tmp_path: Path):
    root = tmp_path / "bundle"
    (root / "distribution").mkdir(parents=True)
    (root / "distribution" / "release-manifest.json").write_text("{}", encoding="utf-8")
    (root / "distribution" / "raze-bundle.json").write_text(
        json.dumps(
            {
                "bundle_version": "1.0.0",
                "release_manifest_url": "distribution/release-manifest.json",
                "components": {},
            }
        ),
        encoding="utf-8",
    )

    status = inspect_bundle(explicit_root=str(root))

    assert status.release_manifest_url == str((root / "distribution" / "release-manifest.json").resolve())


def test_compare_versions_handles_patch_updates():
    assert compare_versions("1.0.1", "1.0.0") > 0
    assert compare_versions("1.0.0", "1.0.0") == 0
    assert compare_versions("0.9.9", "1.0.0") < 0


def test_build_update_status_supports_local_manifest_file(tmp_path: Path):
    manifest_path = tmp_path / "release-manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "latest_version": "1.2.0",
                "instructions": "Replace the local bundle manually.",
                "download_page_url": "https://example.com/raze/releases",
            }
        ),
        encoding="utf-8",
    )

    status = build_update_status(current_version="1.0.0", source=str(manifest_path))

    assert status["status"] == "update_available"
    assert status["update_available"] is True
    assert status["latest_version"] == "1.2.0"
    assert status["checked_version"] == "1.0.0"


def test_build_update_status_carries_release_notes(tmp_path: Path):
    manifest_path = tmp_path / "release-manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "latest_version": "1.0.1",
                "release_notes": ["First note", "Second note"],
                "release_notes_url": "https://example.com/raze/releases/1.0.1",
            }
        ),
        encoding="utf-8",
    )

    status = build_update_status(current_version="1.0.0", source=str(manifest_path))

    assert status["release_notes"] == ["First note", "Second note"]
    assert status["release_notes_url"] == "https://example.com/raze/releases/1.0.1"


def test_distribution_manifest_matches_cli_first_bundle_boundary():
    manifest = json.loads((ROOT / "distribution" / "raze-bundle.json").read_text(encoding="utf-8"))
    include = manifest["distribution"]["include"]
    exclude = manifest["distribution"]["exclude"]

    assert "cli/" not in include
    assert "services/core/" in include
    assert "apps/dashboard/dist/" in include
    assert "employees/" in include
    assert "packages/shared-specs/" in include
    assert "distribution/raze-bundle.json" in include
    assert "docs/" in include
    assert ".raze/" in exclude
    assert ".raze-dev/" in exclude
    assert "tmp/" in exclude
    assert "**/runtime.json" in exclude
    assert "**/config.yaml" in exclude
    assert "**/*.db" in exclude
    assert "**/node_modules/" in exclude
    assert "apps/website/" in exclude


def test_find_forbidden_runtime_entries_detects_local_only_state(tmp_path: Path):
    root = tmp_path / "bundle"
    (root / "distribution").mkdir(parents=True)
    (root / ".env").write_text("secret=value\n", encoding="utf-8")
    (root / "runtime.json").write_text("{}", encoding="utf-8")
    (root / "apps" / "website").mkdir(parents=True)
    (root / "logs").mkdir()
    (root / "data.sqlite3").write_text("", encoding="utf-8")

    forbidden = find_forbidden_runtime_entries(root)

    names = {path.name for path in forbidden}
    assert ".env" in names
    assert "runtime.json" in names
    assert "website" in names
    assert "logs" in names
    assert "data.sqlite3" in names


def test_acquire_managed_bundle_installs_from_local_manifest(tmp_path: Path):
    source_root = tmp_path / "bundle-source"
    bundle_root = source_root / "runtime"
    (bundle_root / "distribution").mkdir(parents=True)
    (bundle_root / "services" / "core").mkdir(parents=True)
    (bundle_root / "apps" / "dashboard" / "dist").mkdir(parents=True)
    (bundle_root / "apps" / "dashboard" / "dist" / "index.html").write_text("<html></html>", encoding="utf-8")
    (bundle_root / "employees").mkdir()
    (bundle_root / "packages" / "shared-specs").mkdir(parents=True)
    (bundle_root / "distribution" / "raze-bundle.json").write_text(
        json.dumps(
            {
                "bundle_version": "1.0.0",
                "components": {
                    "core": {"label": "Core", "kind": "python-runtime", "path": "services/core", "required": True},
                    "dashboard": {
                        "label": "Dashboard",
                        "kind": "web-runtime",
                        "source_path": "apps/dashboard",
                        "dist_path": "apps/dashboard/dist",
                        "required": True,
                    },
                    "employees": {"label": "Employees", "kind": "definitions", "path": "employees", "required": True},
                    "shared_specs": {"label": "Shared Specs", "kind": "shared-assets", "path": "packages/shared-specs", "required": True},
                },
            }
        ),
        encoding="utf-8",
    )

    archive_path = shutil.make_archive(str(tmp_path / "raze-runtime-bundle-1.0.0"), "zip", root_dir=source_root)
    manifest_path = tmp_path / "release-manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "latest_version": "1.0.0",
                "bundle_version": "1.0.0",
                "bundle_archive_path": Path(archive_path).name,
                "instructions": "Replace the local runtime bundle manually.",
            }
        ),
        encoding="utf-8",
    )

    status = acquire_managed_bundle(
        source=str(manifest_path),
        data_dir=tmp_path / "data",
        workspace_root=tmp_path / "missing",
    )

    assert status.root == (tmp_path / "data" / "runtime" / "bundles" / "1.0.0").resolve()
    assert status.managed_runtime is True
    assert status.dashboard_mode == "bundled-static"
    installation = load_bundle_installation(tmp_path / "data")
    assert installation["bundle_root"] == str(status.root)


def test_acquire_managed_bundle_rejects_forbidden_files(tmp_path: Path):
    source_root = tmp_path / "bundle-source"
    bundle_root = source_root / "runtime"
    (bundle_root / "distribution").mkdir(parents=True)
    (bundle_root / "services" / "core").mkdir(parents=True)
    (bundle_root / "apps" / "dashboard" / "dist").mkdir(parents=True)
    (bundle_root / "apps" / "dashboard" / "dist" / "index.html").write_text("<html></html>", encoding="utf-8")
    (bundle_root / "employees").mkdir()
    (bundle_root / "packages" / "shared-specs").mkdir(parents=True)
    (bundle_root / "config.yaml").write_text("providers: []\n", encoding="utf-8")
    (bundle_root / "distribution" / "raze-bundle.json").write_text(
        json.dumps(
            {
                "bundle_version": "1.0.0",
                "components": {
                    "core": {"label": "Core", "kind": "python-runtime", "path": "services/core", "required": True},
                    "dashboard": {
                        "label": "Dashboard",
                        "kind": "web-runtime",
                        "source_path": "apps/dashboard",
                        "dist_path": "apps/dashboard/dist",
                        "required": True,
                    },
                    "employees": {"label": "Employees", "kind": "definitions", "path": "employees", "required": True},
                    "shared_specs": {"label": "Shared Specs", "kind": "shared-assets", "path": "packages/shared-specs", "required": True},
                },
            }
        ),
        encoding="utf-8",
    )

    archive_path = shutil.make_archive(str(tmp_path / "raze-runtime-bundle-1.0.0-bad"), "zip", root_dir=source_root)
    manifest_path = tmp_path / "release-manifest-bad.json"
    manifest_path.write_text(
        json.dumps(
            {
                "latest_version": "1.0.0",
                "bundle_version": "1.0.0",
                "bundle_archive_path": Path(archive_path).name,
            }
        ),
        encoding="utf-8",
    )

    try:
        acquire_managed_bundle(
            source=str(manifest_path),
            data_dir=tmp_path / "data",
            workspace_root=tmp_path / "missing",
        )
    except RuntimeAcquisitionError as exc:
        assert "forbidden local files" in str(exc).lower()
    else:
        raise AssertionError("Expected RuntimeAcquisitionError for forbidden bundle content")
