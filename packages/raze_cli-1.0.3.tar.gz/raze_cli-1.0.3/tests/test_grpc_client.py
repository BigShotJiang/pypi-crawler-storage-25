from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "cli"))

from raze_cli.api_client import RazeAPIClient  # noqa: E402
from raze_cli.grpc_client import RazeGrpcClient  # noqa: E402


@pytest.mark.asyncio
async def test_grpc_client_reads_runtime_target(monkeypatch, tmp_path: Path):
    calls: list[tuple[str, dict]] = []

    class FakeMethod:
        def __init__(self, path: str):
            self.path = path

        async def __call__(self, payload: dict):
            calls.append((self.path, payload))
            return {"path": self.path}

    class FakeChannel:
        def __init__(self, target: str):
            self.target = target

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def unary_unary(self, path: str, request_serializer=None, response_deserializer=None):
            return FakeMethod(path)

    fake_grpc = SimpleNamespace(aio=SimpleNamespace(insecure_channel=lambda target: FakeChannel(target)))

    monkeypatch.setenv("RAZE_DATA_DIR", str(tmp_path))
    runtime_path = tmp_path / "runtime.json"
    runtime_path.write_text(
        json.dumps(
            {
                "grpc_host": "127.0.0.1",
                "grpc_port": 52110,
                "grpc_status": "running",
            }
        ),
        encoding="utf-8",
    )

    client = RazeGrpcClient()
    client._grpc = fake_grpc

    result = await client.get_settings()

    assert client.available() is True
    assert result["path"] == "/raze.v1.SystemService/GetSettings"
    assert calls == [("/raze.v1.SystemService/GetSettings", {})]


@pytest.mark.asyncio
async def test_api_client_prefers_grpc_when_available():
    class FakeGrpcClient:
        def available(self):
            return True

        async def get_settings(self):
            return {"transport": "grpc"}

    client = RazeAPIClient()
    client.grpc = FakeGrpcClient()

    result = await client.get_settings()

    assert result == {"transport": "grpc"}
