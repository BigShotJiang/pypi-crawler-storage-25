# RAZE CLI

RAZE CLI is the local command line entrypoint for the RAZE runtime.

## Install

```bash
pip install raze-cli
```

This installs the CLI manager. The local Core and Dashboard runtime are then provided through the managed RAZE runtime bundle that the CLI installs or registers locally.

Optional gRPC transport support:

```bash
pip install "raze-cli[grpc]"
```

## First run

```bash
raze onboard
# or: raze dashboard

raze doctor
raze status
raze update
```

For the normal product flow, the CLI now manages the local runtime automatically:

- it detects whether the runtime is already installed
- it acquires and registers the managed runtime if needed
- it stores that runtime under `~/.raze/runtime`
- it validates the bundle, starts Core, and opens the local dashboard

End users should not build the dashboard manually. The intended product flow is:

```bash
pipx install raze-cli
# or: pip install raze-cli

raze onboard
```

`raze bootstrap --bundle-dir <bundle-root>` remains available as an advanced fallback for custom or developer-managed bundle paths.

## What the CLI expects

- A writable local runtime directory via `RAZE_DATA_DIR` or the default user data path
- A release manifest and ready runtime bundle artifact for automatic first-run acquisition in the normal product flow
- A bundled dashboard build that Core can serve, or the dashboard source tree for dev-only launches
- When `grpcio` is installed and Core exposes the localhost control plane, the CLI will prefer gRPC automatically and fall back to REST when needed

## Common commands

```bash
raze config
raze list
raze install research-employee
raze run research-employee
raze reset-db --yes
```
