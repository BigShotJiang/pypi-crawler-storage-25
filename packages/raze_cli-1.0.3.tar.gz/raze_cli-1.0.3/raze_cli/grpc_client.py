"""Optional gRPC client for the RAZE internal control plane."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Optional


SYSTEM_SERVICE = "raze.v1.SystemService"
PROVIDERS_SERVICE = "raze.v1.ProvidersService"
JOBS_SERVICE = "raze.v1.JobsService"
ACTIONS_SERVICE = "raze.v1.ActionsService"


def _method_path(service: str, method: str) -> str:
    return f"/{service}/{method}"


def _dumps(payload: Any) -> bytes:
    return json.dumps(payload or {}, ensure_ascii=False, sort_keys=True).encode("utf-8")


def _loads(payload: bytes | None) -> Any:
    if not payload:
        return {}
    return json.loads(payload.decode("utf-8"))


class RazeGrpcClient:
    def __init__(self):
        self._grpc = self._import_grpc()

    def _import_grpc(self):
        try:
            import grpc
        except Exception:
            return None
        return grpc

    def _runtime_state_path(self) -> Path:
        data_dir = Path(os.environ.get("RAZE_DATA_DIR", Path.home() / ".raze"))
        return data_dir / "runtime.json"

    def _load_target(self) -> Optional[str]:
        if self._grpc is None:
            return None

        path = self._runtime_state_path()
        if not path.exists():
            return None

        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None

        status = str(payload.get("grpc_status") or "").lower()
        if status not in {"running", "ready"}:
            return None

        host = payload.get("grpc_host") or payload.get("core_host") or "127.0.0.1"
        port = payload.get("grpc_port")
        if isinstance(port, int) and port > 0:
            return f"{host}:{port}"
        if isinstance(port, str) and port.isdigit():
            return f"{host}:{int(port)}"
        return None

    def available(self) -> bool:
        return self._load_target() is not None

    async def _call(self, path: str, payload: dict[str, Any] | None = None) -> Any:
        if self._grpc is None:
            raise RuntimeError("grpcio is not installed")

        target = self._load_target()
        if not target:
            raise RuntimeError("RAZE gRPC control plane is not available")

        async with self._grpc.aio.insecure_channel(target) as channel:
            method = channel.unary_unary(
                path,
                request_serializer=_dumps,
                response_deserializer=_loads,
            )
            return await method(payload or {})

    async def get_settings(self) -> dict[str, Any]:
        return await self._call(_method_path(SYSTEM_SERVICE, "GetSettings"))

    async def run_doctor(self) -> dict[str, Any]:
        return await self._call(_method_path(SYSTEM_SERVICE, "RunDoctor"))

    async def list_providers(self) -> list[dict[str, Any]]:
        payload = await self._call(_method_path(PROVIDERS_SERVICE, "ListProviders"))
        return payload.get("providers", [])

    async def test_provider(self, provider_id: str) -> dict[str, Any]:
        return await self._call(_method_path(PROVIDERS_SERVICE, "TestProvider"), {"provider_id": provider_id})

    async def list_models(self) -> dict[str, Any]:
        return await self._call(_method_path(PROVIDERS_SERVICE, "ListModels"))
