"""Helpers for resolving, acquiring, and validating the local RAZE runtime bundle."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urljoin, urlparse

import httpx

from raze_cli import __version__
from raze_cli.updates import compare_versions, load_release_manifest


BUNDLE_MANIFEST_RELATIVE_PATH = Path("distribution") / "raze-bundle.json"
BUNDLE_INSTALLATION_FILE = "bundle-installation.json"
UPDATE_STATUS_FILE = "update-status.json"
MANAGED_RUNTIME_DIR_NAME = "runtime"
MANAGED_BUNDLE_DIR_NAME = "bundles"
MANAGED_ENV_DIR_NAME = "environments"
DEFAULT_RELEASE_MANIFEST_URL = "https://github.com/mtma1/Raze-1/releases/latest/download/release-manifest.json"
RELEASE_MANIFEST_ENV_VARS = ("RAZE_RELEASE_MANIFEST_URL", "RAZE_RUNTIME_MANIFEST_URL")
FORBIDDEN_DIR_NAMES = {
    ".raze",
    ".raze-dev",
    "tmp",
    "logs",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".cache",
}
FORBIDDEN_FILE_NAMES = {"runtime.json", "config.yaml"}
FORBIDDEN_FILE_SUFFIXES = {".db", ".sqlite", ".sqlite3", ".log"}


class RuntimeAcquisitionError(RuntimeError):
    """Raised when the CLI cannot prepare a usable local runtime."""


@dataclass
class BundleComponentStatus:
    key: str
    label: str
    kind: str
    required: bool
    path: Optional[Path]
    present: bool


@dataclass
class BundleStatus:
    root: Optional[Path]
    manifest_path: Optional[Path]
    manifest: dict[str, Any]
    components: list[BundleComponentStatus]
    bundle_version: Optional[str]
    release_manifest_url: Optional[str]
    dashboard_mode: str
    dashboard_source_path: Optional[Path]
    dashboard_dist_path: Optional[Path]
    core_path: Optional[Path]
    managed_runtime: bool
    runtime_env_dir: Optional[Path]
    runtime_python: Optional[Path]
    forbidden_entries: list[Path]


def get_data_dir() -> Path:
    return Path(os.environ.get("RAZE_DATA_DIR", Path.home() / ".raze"))


def get_managed_runtime_dir(data_dir: Optional[Path] = None) -> Path:
    return (data_dir or get_data_dir()) / MANAGED_RUNTIME_DIR_NAME


def get_managed_bundle_base_dir(data_dir: Optional[Path] = None) -> Path:
    return get_managed_runtime_dir(data_dir) / MANAGED_BUNDLE_DIR_NAME


def get_managed_environment_base_dir(data_dir: Optional[Path] = None) -> Path:
    return get_managed_runtime_dir(data_dir) / MANAGED_ENV_DIR_NAME


def _load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_json(path: Path, payload: dict[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return path


def get_bundle_installation_path(data_dir: Optional[Path] = None) -> Path:
    return (data_dir or get_data_dir()) / BUNDLE_INSTALLATION_FILE


def load_bundle_installation(data_dir: Optional[Path] = None) -> dict[str, Any]:
    path = get_bundle_installation_path(data_dir)
    if not path.exists():
        return {}
    return _load_json(path)


def save_bundle_installation(
    root: Path,
    *,
    data_dir: Optional[Path] = None,
    source: str = "manual",
) -> Path:
    payload = {
        "bundle_root": str(root.resolve()),
        "source": source,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    return _write_json(get_bundle_installation_path(data_dir), payload)


def get_update_status_path(data_dir: Optional[Path] = None) -> Path:
    return (data_dir or get_data_dir()) / UPDATE_STATUS_FILE


def load_update_status(data_dir: Optional[Path] = None) -> dict[str, Any]:
    path = get_update_status_path(data_dir)
    if not path.exists():
        return {}
    return _load_json(path)


def save_update_status(payload: dict[str, Any], data_dir: Optional[Path] = None) -> Path:
    return _write_json(get_update_status_path(data_dir), payload)


def find_source_tree_root(start: Optional[Path] = None) -> Optional[Path]:
    candidate = (start or Path(__file__).resolve().parents[2]).resolve()
    if (candidate / "services" / "core").exists() and (candidate / "apps" / "dashboard").exists():
        return candidate
    return None


def allow_source_tree_fallback(workspace_root: Optional[Path] = None) -> bool:
    flag = os.environ.get("RAZE_DEV_MODE", "").strip().lower()
    if flag in {"1", "true", "yes", "on"}:
        return True

    source_root = find_source_tree_root(workspace_root)
    if not source_root:
        return False
    return (source_root / ".git").exists()


def _path_within(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _sanitize_version(value: str) -> str:
    cleaned = "".join(char if char.isalnum() or char in {".", "-", "_"} else "-" for char in value.strip())
    return cleaned or "unknown"


def _bundle_runtime_id(root: Path, bundle_version: Optional[str]) -> str:
    normalized = str(root.resolve()).encode("utf-8")
    suffix = hashlib.sha256(normalized).hexdigest()[:12]
    return f"{_sanitize_version(bundle_version or 'unknown')}-{suffix}"


def get_runtime_environment_dir(
    root: Path,
    *,
    bundle_version: Optional[str],
    data_dir: Optional[Path] = None,
) -> Path:
    return get_managed_environment_base_dir(data_dir) / _bundle_runtime_id(root, bundle_version)


def get_runtime_python_path(env_dir: Path) -> Path:
    if os.name == "nt":
        return env_dir / "Scripts" / "python.exe"
    return env_dir / "bin" / "python"


def _find_registered_bundle_root(data_dir: Optional[Path] = None) -> Optional[Path]:
    installation = load_bundle_installation(data_dir)
    registered_root = str(installation.get("bundle_root") or "").strip()
    if not registered_root:
        return None

    candidate = Path(registered_root).expanduser().resolve()
    if candidate.exists():
        return candidate
    return None


def _find_managed_bundle_root(data_dir: Optional[Path] = None) -> Optional[Path]:
    bundles_dir = get_managed_bundle_base_dir(data_dir)
    if not bundles_dir.exists():
        return None

    candidates = [
        path.resolve()
        for path in bundles_dir.iterdir()
        if path.is_dir() and (path / BUNDLE_MANIFEST_RELATIVE_PATH).exists()
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda path: path.stat().st_mtime)


def _resolve_release_manifest_source(root: Path, source: object) -> Optional[str]:
    text = str(source or "").strip()
    if not text:
        return None
    if text.startswith(("http://", "https://")):
        return text

    candidate = Path(text).expanduser()
    if candidate.is_absolute():
        return str(candidate.resolve())
    return str((root / candidate).resolve())


def resolve_release_manifest_source(preferred: Optional[str] = None) -> Optional[str]:
    if preferred:
        return preferred

    for env_name in RELEASE_MANIFEST_ENV_VARS:
        value = os.environ.get(env_name, "").strip()
        if value:
            return value

    return DEFAULT_RELEASE_MANIFEST_URL


def resolve_bundle_root(
    *,
    explicit_root: Optional[str] = None,
    data_dir: Optional[Path] = None,
    workspace_root: Optional[Path] = None,
    allow_dev_fallback: bool = True,
) -> Optional[Path]:
    if explicit_root is not None:
        candidate = Path(explicit_root).expanduser().resolve()
        if candidate.exists():
            return candidate
        return None

    env_root = os.environ.get("RAZE_BUNDLE_DIR", "").strip()
    if env_root:
        candidate = Path(env_root).expanduser().resolve()
        if candidate.exists():
            return candidate

    registered_root = _find_registered_bundle_root(data_dir)
    if registered_root:
        return registered_root

    managed_root = _find_managed_bundle_root(data_dir)
    if managed_root:
        return managed_root

    if allow_dev_fallback and allow_source_tree_fallback(workspace_root):
        return find_source_tree_root(workspace_root)
    return None


def load_bundle_manifest(root: Path) -> tuple[Optional[Path], dict[str, Any]]:
    manifest_path = root / BUNDLE_MANIFEST_RELATIVE_PATH
    if not manifest_path.exists():
        return None, {}
    return manifest_path, _load_json(manifest_path)


def find_forbidden_runtime_entries(root: Path) -> list[Path]:
    if not root.exists():
        return []

    matches: list[Path] = []
    for path in root.rglob("*"):
        relative = path.relative_to(root)
        parts = tuple(part.lower() for part in relative.parts)
        name = path.name.lower()

        if path.is_dir():
            if name in FORBIDDEN_DIR_NAMES or name.startswith(".raze-dev-"):
                matches.append(path)
                continue
            if parts[:2] == ("apps", "website"):
                matches.append(path)
            continue

        if parts[:2] == ("apps", "website"):
            matches.append(path)
            continue
        if name in FORBIDDEN_FILE_NAMES or name.startswith(".env"):
            matches.append(path)
            continue
        if path.suffix.lower() in FORBIDDEN_FILE_SUFFIXES:
            matches.append(path)

    unique: list[Path] = []
    seen: set[Path] = set()
    for entry in matches:
        resolved = entry.resolve()
        if resolved not in seen:
            unique.append(resolved)
            seen.add(resolved)
    return unique


def get_missing_required_components(status: BundleStatus) -> list[str]:
    return [
        component.label
        for component in status.components
        if component.required and not component.present
    ]


def inspect_bundle(
    *,
    explicit_root: Optional[str] = None,
    data_dir: Optional[Path] = None,
    workspace_root: Optional[Path] = None,
    allow_dev_fallback: bool = True,
) -> BundleStatus:
    working_data_dir = data_dir or get_data_dir()
    root = resolve_bundle_root(
        explicit_root=explicit_root,
        data_dir=working_data_dir,
        workspace_root=workspace_root,
        allow_dev_fallback=allow_dev_fallback,
    )
    if not root:
        return BundleStatus(
            root=None,
            manifest_path=None,
            manifest={},
            components=[],
            bundle_version=None,
            release_manifest_url=None,
            dashboard_mode="unavailable",
            dashboard_source_path=None,
            dashboard_dist_path=None,
            core_path=None,
            managed_runtime=False,
            runtime_env_dir=None,
            runtime_python=None,
            forbidden_entries=[],
        )

    manifest_path, manifest = load_bundle_manifest(root)
    components: list[BundleComponentStatus] = []
    dashboard_source_path: Optional[Path] = None
    dashboard_dist_path: Optional[Path] = None
    core_path: Optional[Path] = None

    for key, spec in (manifest.get("components") or {}).items():
        required = bool(spec.get("required", False))
        label = str(spec.get("label") or key.replace("_", " ").title())
        kind = str(spec.get("kind") or "unknown")

        if key == "dashboard":
            source_rel = spec.get("source_path")
            dist_rel = spec.get("dist_path")
            dashboard_source_path = (root / source_rel).resolve() if source_rel else None
            dashboard_dist_path = (root / dist_rel).resolve() if dist_rel else None
            present = bool(
                (dashboard_dist_path and (dashboard_dist_path / "index.html").exists())
                or (dashboard_source_path and dashboard_source_path.exists())
            )
            components.append(
                BundleComponentStatus(
                    key=key,
                    label=label,
                    kind=kind,
                    required=required,
                    path=dashboard_dist_path if dashboard_dist_path and (dashboard_dist_path / "index.html").exists() else dashboard_source_path,
                    present=present,
                )
            )
            continue

        rel_path = spec.get("path")
        component_path = (root / rel_path).resolve() if rel_path else None
        present = bool(component_path and component_path.exists())
        if key == "core":
            core_path = component_path
        components.append(
            BundleComponentStatus(
                key=key,
                label=label,
                kind=kind,
                required=required,
                path=component_path,
                present=present,
            )
        )

    if dashboard_dist_path and (dashboard_dist_path / "index.html").exists():
        dashboard_mode = "bundled-static"
    elif dashboard_source_path and dashboard_source_path.exists():
        dashboard_mode = "source-tree"
    else:
        dashboard_mode = "unavailable"

    bundle_version = str(manifest.get("bundle_version") or "").strip() or None
    runtime_env_dir = get_runtime_environment_dir(root, bundle_version=bundle_version, data_dir=working_data_dir)
    runtime_python = get_runtime_python_path(runtime_env_dir)
    managed_runtime = _path_within(root, get_managed_bundle_base_dir(working_data_dir))

    return BundleStatus(
        root=root,
        manifest_path=manifest_path,
        manifest=manifest,
        components=components,
        bundle_version=bundle_version,
        release_manifest_url=_resolve_release_manifest_source(root, manifest.get("release_manifest_url")),
        dashboard_mode=dashboard_mode,
        dashboard_source_path=dashboard_source_path,
        dashboard_dist_path=dashboard_dist_path,
        core_path=core_path,
        managed_runtime=managed_runtime,
        runtime_env_dir=runtime_env_dir,
        runtime_python=runtime_python if runtime_python.exists() else None,
        forbidden_entries=find_forbidden_runtime_entries(root),
    )


def _resolve_manifest_resource(manifest_source: str, resource: object) -> Optional[str]:
    text = str(resource or "").strip()
    if not text:
        return None
    if text.startswith(("http://", "https://")):
        return text

    candidate = Path(text).expanduser()
    if candidate.is_absolute():
        return str(candidate.resolve())

    if manifest_source.startswith(("http://", "https://")):
        return urljoin(manifest_source, text.replace("\\", "/"))

    base_dir = Path(manifest_source).expanduser().resolve().parent
    return str((base_dir / candidate).resolve())


def _copy_or_download(source: str, destination: Path) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.startswith(("http://", "https://")):
        with httpx.stream("GET", source, timeout=60.0, follow_redirects=True) as response:
            response.raise_for_status()
            with destination.open("wb") as handle:
                for chunk in response.iter_bytes():
                    if chunk:
                        handle.write(chunk)
        return destination

    local_source = Path(source).expanduser().resolve()
    if not local_source.exists():
        raise RuntimeAcquisitionError(f"Runtime bundle archive was not found: {local_source}")
    shutil.copy2(local_source, destination)
    return destination


def _archive_filename(source: str) -> str:
    if source.startswith(("http://", "https://")):
        name = Path(urlparse(source).path).name
        return name or "raze-runtime-bundle.zip"
    return Path(source).name or "raze-runtime-bundle.zip"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _extract_archive(archive_path: Path, destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    lower_name = archive_path.name.lower()
    if lower_name.endswith(".zip"):
        with zipfile.ZipFile(archive_path) as archive:
            for member in archive.infolist():
                target = (destination / member.filename).resolve()
                if not _path_within(target, destination):
                    raise RuntimeAcquisitionError(
                        "The runtime bundle archive contains an unsafe path."
                    )
                archive.extract(member, destination)
        return destination

    if lower_name.endswith((".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz")):
        with tarfile.open(archive_path) as archive:
            for member in archive.getmembers():
                if member.islnk() or member.issym():
                    raise RuntimeAcquisitionError(
                        "The runtime bundle archive contains unsupported link entries."
                    )
                target = (destination / member.name).resolve()
                if not _path_within(target, destination):
                    raise RuntimeAcquisitionError(
                        "The runtime bundle archive contains an unsafe path."
                    )
                archive.extract(member, destination)
        return destination

    raise RuntimeAcquisitionError(
        "Unsupported runtime bundle archive format. Expected .zip or .tar.*"
    )


def _find_bundle_root_in_tree(search_root: Path) -> Optional[Path]:
    direct_manifest = search_root / BUNDLE_MANIFEST_RELATIVE_PATH
    if direct_manifest.exists():
        return search_root.resolve()

    matches = sorted(
        search_root.rglob(str(BUNDLE_MANIFEST_RELATIVE_PATH)),
        key=lambda path: len(path.parts),
    )
    if not matches:
        return None
    return matches[0].parent.parent.resolve()


def acquire_managed_bundle(
    *,
    source: Optional[str] = None,
    data_dir: Optional[Path] = None,
    workspace_root: Optional[Path] = None,
) -> BundleStatus:
    working_data_dir = data_dir or get_data_dir()
    manifest_source = resolve_release_manifest_source(source)
    if not manifest_source:
        raise RuntimeAcquisitionError(
            "No runtime release source is configured. Set RAZE_RELEASE_MANIFEST_URL or use the advanced bootstrap fallback."
        )

    try:
        manifest, normalized_source = load_release_manifest(manifest_source)
    except Exception as exc:
        raise RuntimeAcquisitionError(f"Could not load the runtime release manifest: {exc}") from exc

    minimum_cli_version = str(manifest.get("minimum_cli_version") or "").strip()
    if minimum_cli_version and compare_versions(__version__, minimum_cli_version) < 0:
        raise RuntimeAcquisitionError(
            f"This runtime requires raze-cli >= {minimum_cli_version}, but the installed CLI is {__version__}."
        )

    bundle_version = str(
        manifest.get("bundle_version")
        or manifest.get("latest_version")
        or manifest.get("version")
        or ""
    ).strip()
    if not bundle_version:
        raise RuntimeAcquisitionError(
            "The runtime release manifest does not declare a bundle version."
        )

    bundle_archive_source = _resolve_manifest_resource(
        normalized_source,
        manifest.get("bundle_archive_url")
        or manifest.get("runtime_bundle_url")
        or manifest.get("bundle_url")
        or manifest.get("bundle_archive_path"),
    )
    if not bundle_archive_source:
        raise RuntimeAcquisitionError(
            "The runtime release manifest does not provide a bundle archive URL."
        )

    installed_root = get_managed_bundle_base_dir(working_data_dir) / _sanitize_version(bundle_version)
    if (installed_root / BUNDLE_MANIFEST_RELATIVE_PATH).exists():
        status = inspect_bundle(
            explicit_root=str(installed_root),
            data_dir=working_data_dir,
            workspace_root=workspace_root,
            allow_dev_fallback=False,
        )
        if not get_missing_required_components(status) and not status.forbidden_entries:
            save_bundle_installation(installed_root, data_dir=working_data_dir, source="managed-install")
            return status

    runtime_dir = get_managed_runtime_dir(working_data_dir)
    runtime_dir.mkdir(parents=True, exist_ok=True)

    staging_root = runtime_dir / "_staging"
    staging_root.mkdir(parents=True, exist_ok=True)
    temp_dir = staging_root / f"{_sanitize_version(bundle_version)}-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}"
    temp_dir.mkdir(parents=True, exist_ok=False)
    try:
        archive_path = temp_dir / _archive_filename(bundle_archive_source)
        _copy_or_download(bundle_archive_source, archive_path)

        expected_sha256 = str(manifest.get("bundle_archive_sha256") or "").strip().lower()
        if expected_sha256:
            actual_sha256 = _sha256(archive_path)
            if actual_sha256.lower() != expected_sha256:
                raise RuntimeAcquisitionError(
                    "The downloaded runtime bundle failed checksum validation."
                )

        extracted_dir = temp_dir / "extracted"
        _extract_archive(archive_path, extracted_dir)
        extracted_root = _find_bundle_root_in_tree(extracted_dir)
        if not extracted_root:
            raise RuntimeAcquisitionError(
                "The downloaded runtime archive does not contain distribution\\raze-bundle.json."
            )

        status = inspect_bundle(
            explicit_root=str(extracted_root),
            data_dir=working_data_dir,
            workspace_root=workspace_root,
            allow_dev_fallback=False,
        )
        missing_required = get_missing_required_components(status)
        if missing_required:
            raise RuntimeAcquisitionError(
                "The downloaded runtime bundle is incomplete. Missing required components: "
                + ", ".join(missing_required)
            )
        if status.forbidden_entries:
            sample = ", ".join(str(path.relative_to(extracted_root)) for path in status.forbidden_entries[:3])
            raise RuntimeAcquisitionError(
                "The downloaded runtime bundle contains forbidden local files: "
                + sample
            )

        if installed_root.exists():
            if not _path_within(installed_root, get_managed_bundle_base_dir(working_data_dir)):
                raise RuntimeAcquisitionError(
                    "Refusing to replace a runtime outside the managed bundle directory."
                )
            shutil.rmtree(installed_root, ignore_errors=True)
        installed_root.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(extracted_root, installed_root)
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

    save_bundle_installation(installed_root, data_dir=working_data_dir, source="managed-install")
    return inspect_bundle(
        explicit_root=str(installed_root),
        data_dir=working_data_dir,
        workspace_root=workspace_root,
        allow_dev_fallback=False,
    )


def ensure_runtime_environment(
    status: BundleStatus,
    *,
    data_dir: Optional[Path] = None,
    python_executable: Optional[str] = None,
) -> Path:
    if not status.root or not status.core_path or not status.core_path.exists():
        raise RuntimeAcquisitionError(
            "No Core runtime is available in the active bundle."
        )

    env_dir = status.runtime_env_dir or get_runtime_environment_dir(
        status.root,
        bundle_version=status.bundle_version,
        data_dir=data_dir,
    )
    runtime_python = get_runtime_python_path(env_dir)
    if runtime_python.exists():
        return runtime_python

    env_dir.parent.mkdir(parents=True, exist_ok=True)
    creator = python_executable or sys.executable
    subprocess.run(
        [creator, "-m", "venv", str(env_dir)],
        check=True,
    )
    runtime_python = get_runtime_python_path(env_dir)
    subprocess.run(
        [str(runtime_python), "-m", "pip", "install", "--upgrade", "pip"],
        check=True,
    )
    subprocess.run(
        [str(runtime_python), "-m", "pip", "install", str(status.core_path)],
        check=True,
    )
    return runtime_python
