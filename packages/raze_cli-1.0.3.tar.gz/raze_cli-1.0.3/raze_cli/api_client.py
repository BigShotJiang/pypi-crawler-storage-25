"""HTTP client for communicating with the local RAZE Core API."""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Optional

import httpx

from raze_cli.grpc_client import RazeGrpcClient


DEFAULT_CORE_URL = "http://127.0.0.1:52100"
FALLBACK_CORE_PORTS = [8400, 8401, 8500, 9100, 9200]


class RazeAPIClient:
    """Client for RAZE Core API."""

    def __init__(self, base_url: str = DEFAULT_CORE_URL):
        self.base_url = base_url.rstrip("/")
        self.grpc = RazeGrpcClient()

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _runtime_state_path(self) -> Path:
        data_dir = Path(os.environ.get("RAZE_DATA_DIR", Path.home() / ".raze"))
        return data_dir / "runtime.json"

    def _load_runtime_target(self) -> Optional[str]:
        path = self._runtime_state_path()
        if not path.exists():
            return None

        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None

        host = payload.get("core_host") or "127.0.0.1"
        port = payload.get("core_port")
        if isinstance(port, int) and port > 0:
            return f"http://{host}:{port}"
        if isinstance(port, str) and port.isdigit():
            return f"http://{host}:{int(port)}"
        return None

    def _candidate_ports(self, preferred_port: int, scan_range: int) -> list[int]:
        candidates: list[int] = []

        runtime_target = self._load_runtime_target()
        if runtime_target:
            try:
                candidates.append(int(runtime_target.rsplit(":", 1)[-1]))
            except ValueError:
                pass

        for offset in range(scan_range + 1):
            candidates.append(preferred_port + offset)

        candidates.extend(FALLBACK_CORE_PORTS)

        deduped: list[int] = []
        seen: set[int] = set()
        for port in candidates:
            if port not in seen:
                seen.add(port)
                deduped.append(port)
        return deduped

    async def health(self) -> dict:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(self._url("/api/health"))
            resp.raise_for_status()
            return resp.json()

    async def is_running(self) -> bool:
        try:
            await self.health()
            return True
        except Exception:
            return False

    async def discover_core(self, preferred_port: int = 52100, scan_range: int = 20) -> Optional[int]:
        """Discover a running Core instance using runtime state plus port scanning."""
        runtime_target = self._load_runtime_target()
        if runtime_target:
            try:
                async with httpx.AsyncClient(timeout=2.0) as client:
                    resp = await client.get(f"{runtime_target}/api/health")
                if resp.status_code == 200 and resp.json().get("status") == "healthy":
                    self.base_url = runtime_target
                    return int(runtime_target.rsplit(":", 1)[-1])
            except Exception:
                pass

        for port in self._candidate_ports(preferred_port, scan_range):
            try:
                url = f"http://127.0.0.1:{port}"
                async with httpx.AsyncClient(timeout=2.0) as client:
                    resp = await client.get(f"{url}/api/health")
                if resp.status_code == 200 and resp.json().get("status") == "healthy":
                    self.base_url = url
                    payload = resp.json()
                    return int(payload.get("port") or port)
            except Exception:
                continue
        return None

    async def wait_for_ready(self, timeout: int = 15) -> bool:
        """Poll the health endpoint until Core is ready or timeout."""
        for _ in range(timeout * 2):
            try:
                port = await self.discover_core()
                if port is not None:
                    return True
            except Exception:
                pass
            await asyncio.sleep(0.5)
        return False

    async def list_providers(self) -> list[dict]:
        if self.grpc.available():
            try:
                return await self.grpc.list_providers()
            except Exception:
                pass
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(self._url("/api/providers"))
            resp.raise_for_status()
            return resp.json()

    async def add_provider(self, data: dict) -> dict:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(self._url("/api/providers"), json=data)
            resp.raise_for_status()
            return resp.json()

    async def test_provider(self, provider_id: str) -> dict:
        if self.grpc.available():
            try:
                return await self.grpc.test_provider(provider_id)
            except Exception:
                pass
        async with httpx.AsyncClient(timeout=20.0) as client:
            resp = await client.post(self._url(f"/api/providers/{provider_id}/test"))
            resp.raise_for_status()
            return resp.json()

    async def list_employees(self) -> list[dict]:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(self._url("/api/employees"))
            resp.raise_for_status()
            return resp.json()

    async def install_employee(self, employee_id: str, dev_path: Optional[str] = None) -> dict:
        data = {"employee_id": employee_id}
        if dev_path:
            data["dev_path"] = dev_path
        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(self._url("/api/employees/install"), json=data)
            resp.raise_for_status()
            return resp.json()

    async def run_employee(self, employee_id: str) -> dict:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(self._url(f"/api/employees/{employee_id}/run"))
            resp.raise_for_status()
            return resp.json()

    async def stop_employee(self, employee_id: str) -> dict:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(self._url(f"/api/employees/{employee_id}/stop"))
            resp.raise_for_status()
            return resp.json()

    async def uninstall_employee(self, employee_id: str) -> dict:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.delete(self._url(f"/api/employees/{employee_id}"))
            resp.raise_for_status()
            return resp.json()

    async def list_registry(self) -> list[dict]:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(self._url("/api/registry"))
            resp.raise_for_status()
            return resp.json()

    async def run_doctor(self) -> dict:
        if self.grpc.available():
            try:
                return await self.grpc.run_doctor()
            except Exception:
                pass
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(self._url("/api/doctor"))
            resp.raise_for_status()
            return resp.json()

    async def get_logs(self, limit: int = 50, level: Optional[str] = None) -> list[dict]:
        params = {"limit": limit}
        if level:
            params["level"] = level
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(self._url("/api/logs"), params=params)
            resp.raise_for_status()
            return resp.json()

    async def get_settings(self) -> dict:
        if self.grpc.available():
            try:
                return await self.grpc.get_settings()
            except Exception:
                pass
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(self._url("/api/settings"))
            resp.raise_for_status()
            return resp.json()

    async def list_models(self) -> dict:
        if self.grpc.available():
            try:
                return await self.grpc.list_models()
            except Exception:
                pass
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(self._url("/api/models"))
            resp.raise_for_status()
            return resp.json()
