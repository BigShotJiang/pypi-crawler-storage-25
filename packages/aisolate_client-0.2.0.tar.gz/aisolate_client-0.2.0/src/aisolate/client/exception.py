from typing import Any, Optional


class SandboxClientError(Exception):
    """Base exception for Sandbox Client errors."""

    pass


class SandboxConnectionError(SandboxClientError):
    """Raised for network connection-related errors."""

    pass


class SandboxTimeoutError(SandboxClientError):
    """Raised when a request to the sandbox API times out."""

    pass


class SandboxAPIError(SandboxClientError):
    """
    Raised for errors returned by the Sandbox API (e.g., HTTP 4xx or 5xx).
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_data: Optional[Any] = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data

    def __str__(self):
        return f"API Error (Status {self.status_code}): {super().__str__()} - Response: {self.response_data}"


class SandboxWebSocketError(SandboxClientError):
    """Raised for errors specific to WebSocket communication."""

    pass


class SandboxError(Exception):
    """Raised for any errors related to the Sandbox lifecycle or execution."""

    pass
