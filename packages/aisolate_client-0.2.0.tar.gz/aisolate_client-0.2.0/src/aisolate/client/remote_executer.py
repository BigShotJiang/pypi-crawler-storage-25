import base64
import pickle
from typing import List, Optional, Tuple, Any
from smolagents.remote_executors import RemotePythonExecutor, CodeOutput, AgentError
from smolagents.monitoring import LogLevel
from aisolate.client.sandbox import Sandbox
from aisolate.common.models import ErrorOutput


class AIsolateExecutor(RemotePythonExecutor):
    def __init__(
        self,
        domain,
        api_key,
        additional_imports: List[str],
        logger,
        additional_env_vars: Optional[dict[str, str]] = None,
    ):
        super().__init__(additional_imports, logger)
        self.sandbox = Sandbox(
            domain=domain, api_key=api_key, additional_env_vars=additional_env_vars
        )
        self.sandbox.start()
        self.installed_packages = self.install_packages(additional_imports)
        self.logger.log("Sandbox is running", level=LogLevel.INFO)

    def run_code_raise_errors(self, code: str) -> CodeOutput:
        execution = self.sandbox.run_code(code)
        if execution.has_error:
            error: ErrorOutput = execution.error
            # Check if the error is a FinalAnswerException
            if error.error_name == RemotePythonExecutor.FINAL_ANSWER_EXCEPTION:
                final_answer = pickle.loads(base64.b64decode(error.error_value))
                return CodeOutput(
                    output=final_answer,
                    logs=execution.stdout,
                    is_final_answer=True,
                )

            # Construct error message
            error_message = (
                f"{execution.stdout}\n"
                f"Executing code yielded an error:\n"
                f"{error.error_name}\n"
                f"{error.error_value}\n"
                f"{execution.traceback_str}"
            )
            raise AgentError(error_message, self.logger)

        return CodeOutput(
            output=execution.output, logs=execution.stdout, is_final_answer=False
        )

    def close(self):
        self.sandbox.close()
        self.logger.log("Sandbox closed", level=LogLevel.INFO)
