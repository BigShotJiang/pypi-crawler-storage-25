import re
from io import BytesIO
from typing import List, Optional, Union
import re
from io import BytesIO
from typing import List, Optional, Dict, Any
from PIL import Image


from aisolate.common.models import (
    DisplayData,
    ErrorOutput,
    ExecuteResult,
    KernelMessage,
    StreamOutput,
)


class SandboxError(Exception):
    """Raised for any errors related to the Sandbox lifecycle or execution."""

    pass


class Execution:
    """
    A user-friendly container for the results of a code execution.

    This object is returned by a sandbox's execution method and provides
    convenient properties to inspect the outcome, abstracting away the
    low-level kernel event stream.
    """

    # Defines the priority for the .output property. The first matching
    # MIME type in this list will be the one returned.
    # Note: 'image/*' is handled as a special case to group all image formats.
    OUTPUT_TYPE_PRIORITY: List[str] = [
        # Image formats are often the most desirable rich output.
        "image/png",
        "image/jpeg",
        "image/gif",
        "application/pdf",
        "text/html",
        "image/svg+xml",
        # Data and charting formats.
        "application/vnd.vegalite.v5+json",
        "application/json",
        # Text-based formats.
        "text/markdown",
        "text/latex",
        "application/javascript",
        # Fallback to plain text.
        "text/plain",
    ]

    # MIME types that can be treated as text-based.
    TEXT_MIME_TYPES = {
        "text/html",
        "image/svg+xml",
        "application/vnd.vegalite.v5+json",
        "application/json",
        "text/markdown",
        "text/latex",
        "application/javascript",
        "text/plain",
    }

    # MIME types that represent binary images.
    IMAGE_MIME_TYPES = {"image/png", "image/jpeg", "image/gif"}

    def __init__(self, events: List["KernelMessage"]):
        """Initializes the Execution object with a list of kernel events."""
        self.events = events
        """The raw list of kernel messages received during execution."""

        self._main_result_event = self._find_main_result_event()
        """Internal cache for the primary result event."""

    @staticmethod
    def _strip_ansi(source: str) -> str:
        """Removes ANSI escape codes for colors from a string."""
        return re.sub(r"\x1b\[[0-9;]*m", "", source)

    @property
    def error(self) -> Optional["ErrorOutput"]:
        """Returns the execution error object, if one occurred."""
        return next((e for e in self.events if isinstance(e, ErrorOutput)), None)

    @property
    def has_error(self) -> bool:
        """Returns True if the execution resulted in an error."""
        return self.error is not None

    @property
    def traceback_str(self) -> str:
        """
        Returns a formatted, multi-line string of the error traceback,
        if an error occurred. ANSI color codes are stripped.
        """
        if not self.error or not self.error.traceback:
            return ""
        clean_traceback = [Execution._strip_ansi(line) for line in self.error.traceback]
        return "\n".join(clean_traceback)

    @property
    def final_answer(self) -> Optional[Dict[str, Any]]:
        """Returns the final answer data if present in DisplayData.

        Checks for the custom MIME type 'application/vnd.aisolate.final-answer+json'
        which is sent by the final_answer() action.
        """
        for event in self.events:
            if isinstance(event, DisplayData):
                # Check for our custom MIME type
                final_data = event.data.get(
                    "application/vnd.aisolate.final-answer+json"
                )
                if final_data:
                    return final_data
        return None

    @property
    def has_final_answer(self) -> bool:
        """Returns True if the execution produced a final answer."""
        return self.final_answer is not None

    @property
    def review_request(self) -> Optional[Dict[str, Any]]:
        """Returns the review request data if present in DisplayData.

        Checks for the custom MIME type 'application/vnd.aisolate.review-request+json'
        which is sent by the request_report_review() action.
        """
        for event in self.events:
            if isinstance(event, DisplayData):
                review_data = event.data.get(
                    "application/vnd.aisolate.review-request+json"
                )
                if review_data:
                    return review_data
        return None

    @property
    def has_review_request(self) -> bool:
        """Returns True if the execution requested a review."""
        return self.review_request is not None

    def _find_main_result_event(
        self,
    ) -> Optional[Union["ExecuteResult", "DisplayData"]]:
        """Finds the most likely "main result" event."""
        # The main result is typically the last ExecuteResult or DisplayData event.
        result_events = [
            e
            for e in self.events
            if isinstance(e, (ExecuteResult, DisplayData))
            # e
            # for e in self.events
            # if isinstance(e, ExecuteResult)
        ]
        return result_events[-1] if result_events else None

    @property
    def _main_result_data(self) -> Optional[Dict[str, Any]]:
        """Returns the data bundle of the main result event."""
        return self._main_result_event.data if self._main_result_event else None

    @property
    def output_type(self) -> Optional[str]:
        """
        Returns the MIME type of the primary output, based on the priority list.
        Returns None if there is no displayable output.

        Example: 'image/png', 'text/html', 'application/json'
        """
        data = self._main_result_data
        if not data:
            return None

        for mime_type in self.OUTPUT_TYPE_PRIORITY:
            if mime_type in data:
                return mime_type
        return None

    @property
    def output(self) -> Optional[Any]:
        """
        Returns the richest available output from the main result based on the
        defined priority.

        The type of the returned value depends on `output_type`. It could be
        bytes (for PDF/images), a dict (for JSON), or a string (for HTML, SVG, etc.).

        This is the primary property to access the execution result.
        """
        otype = self.output_type
        if otype is None or self._main_result_data is None:
            return None

        return self._main_result_data.get(otype)

    @property
    def output_is_text(self) -> bool:
        """Returns True if the main output can be represented as a string."""
        return self.output_type in self.TEXT_MIME_TYPES

    @property
    def output_is_image(self) -> bool:
        """
        Returns True if the main output is a renderable image format (PNG, JPEG, GIF, SVG).
        """
        # Note: SVG is both text and an image.
        return (
            self.output_type in self.IMAGE_MIME_TYPES
            or self.output_type == "image/svg+xml"
        )

    @property
    def text(self) -> Optional[str]:
        """Returns the plain text output, if available."""
        return (
            self._main_result_data.get("text/plain") if self._main_result_data else None
        )

    @property
    def image(self) -> Optional["Image.Image"]:
        """
        Returns a PIL Image object if a standard bitmap image was generated.
        Returns None if no image is found or PIL/Pillow is not installed.
        """
        if Image is None or self._main_result_data is None:
            return None

        for mime_type in self.IMAGE_MIME_TYPES:
            if mime_type in self._main_result_data:
                image_bytes = self._main_result_data[mime_type]
                return Image.open(BytesIO(image_bytes))
        return None

    @property
    def html(self) -> Optional[str]:
        """Returns the HTML output, if available."""
        return (
            self._main_result_data.get("text/html") if self._main_result_data else None
        )

    @property
    def markdown(self) -> Optional[str]:
        """Returns the Markdown output, if available."""
        return (
            self._main_result_data.get("text/markdown")
            if self._main_result_data
            else None
        )

    @property
    def json(self) -> Optional[Dict[str, Any]]:
        """Returns the JSON output (as a dict), if available."""
        # This serves as the accessor for the 'data' type you requested.
        return (
            self._main_result_data.get("application/json")
            if self._main_result_data
            else None
        )

    @property
    def chart(self) -> Optional[Dict[str, Any]]:
        """Returns chart data (e.g., from Altair/Vega-Lite) as a dict."""
        return (
            self._main_result_data.get("application/vnd.vegalite.v5+json")
            if self._main_result_data
            else None
        )

    @property
    def latex(self) -> Optional[str]:
        """Returns the LaTeX output, if available."""
        return (
            self._main_result_data.get("text/latex") if self._main_result_data else None
        )

    @property
    def javascript(self) -> Optional[str]:
        """Returns the Javascript output, if available."""
        return (
            self._main_result_data.get("application/javascript")
            if self._main_result_data
            else None
        )

    @property
    def svg(self) -> Optional[str]:
        """
        Returns the SVG image output (as an XML string).
        This handles both 'svg' and 'svg+text'.
        """
        return (
            self._main_result_data.get("image/svg+xml")
            if self._main_result_data
            else None
        )

    @property
    def pdf(self) -> Optional[bytes]:
        """Returns the PDF output (as bytes), if available."""
        return (
            self._main_result_data.get("application/pdf")
            if self._main_result_data
            else None
        )

    # --- Standard Stream Properties ---

    @property
    def stdout(self) -> str:
        """Concatenates all text from standard output streams (e.g., `print()` calls)."""
        return "".join(
            e.text
            for e in self.events
            if isinstance(e, StreamOutput) and e.name == "stdout"
        )

    def __repr__(self) -> str:
        if self.has_error:
            status = f"error='{self.error.error_name}'"
        else:
            otype = self.output_type
            if otype:
                # Provide more detail for image/data types
                if otype in self.IMAGE_MIME_TYPES and self.image:
                    status = f"output=Image<size={self.image.size}>"
                elif otype == "application/json" and self.json is not None:
                    status = f"output=dict<keys={list(self.json.keys())}>"
                else:
                    status = f"output_type='{otype}'"
            else:
                status = "output=None"

        stdout_len = len(self.stdout)
        return f"Execution({status}, stdout_len={stdout_len})"
