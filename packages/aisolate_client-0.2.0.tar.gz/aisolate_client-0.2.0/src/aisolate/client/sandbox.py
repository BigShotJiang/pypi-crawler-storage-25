import asyncio
import contextlib
import logging
import uuid
from typing import Any, AsyncIterator, Iterator, List, Optional, Union

from .exception import SandboxError
from .models import Execution, KernelMessage
from .gateway_client import GatewayClient

logger = logging.getLogger(__name__)


class Sandbox:
    """
    Manages the lifecycle of a code execution sandbox.

    This class supports two patterns of use:
    1. As a context manager (recommended for most cases):
       Ensures resources are automatically and safely cleaned up.
       ```
       with Sandbox() as sbx:
           execution = sbx.run_code("1 + 1")
           print(execution.result)
       ```
    2. As a standalone object with manual lifecycle management:
       Useful when the sandbox needs to persist for the lifetime of another object.
       ```
       sbx = Sandbox()
       try:
           sbx.start()
           # ... use sbx for multiple operations ...
           result = sbx.run_code("print('hello')")
       finally:
           sbx.close() # Must be called to release resources
       ```
    """

    def __init__(
        self,
        *,
        domain: str = "http://localhost:8080",
        api_key: Optional[str] = None,
        additional_env_vars: Optional[dict[str, str]] = {},
        timeout: float = 30.0,
        sandbox_id: Optional[str] = None,
        gateway_client: Optional[GatewayClient] = None,
        ping_interval: Optional[float] = 30.0,
        ping_timeout: Optional[float] = 3600.0,
        context_id: Optional[str] = None,
        ram_mb: Optional[int] = None,
        vcpu: Optional[int] = None,
    ) -> None:
        """Initializes the Sandbox configuration.

        Args:
            domain: The gateway domain URL.
            api_key: Optional API key for authentication.
            additional_env_vars: Environment variables to pass to the sandbox.
            timeout: Timeout for operations in seconds.
            sandbox_id: Optional sandbox identifier. If None, auto-generated.
            gateway_client: Optional pre-existing GatewayClient (for shared connections).
            ping_interval: WebSocket ping interval in seconds.
            ping_timeout: WebSocket ping timeout in seconds.
            context_id: Optional default context ID to use for all run_code operations.
            ram_mb: VM memory in MB. If None, gateway default (2048) is used.
            vcpu: Number of vCPUs. If None, gateway default (2) is used.
        """
        self._domain = domain.rstrip("/") + "/"
        self._api_key = api_key
        self._timeout = timeout
        self._additional_env_vars = additional_env_vars
        self.sandbox_id = sandbox_id or f"sbx-{uuid.uuid4().hex[:12]}"
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._client: Optional[GatewayClient] = gateway_client
        self._is_active: bool = False
        self._ping_interval = ping_interval
        self._ping_timeout = ping_timeout
        self._default_context_id = context_id
        self._ram_mb = ram_mb
        self._vcpu = vcpu

    def _get_loop(self) -> asyncio.AbstractEventLoop:
        """Initializes and returns a running asyncio event loop."""
        try:
            return asyncio.get_running_loop()
        except RuntimeError:
            if self._loop is None:
                self._loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self._loop)
            return self._loop

    def _run_sync(self, coro: Any) -> Any:
        """Runs a coroutine to completion, bridging async and sync contexts."""
        loop = self._get_loop()
        if loop.is_running():
            future = asyncio.run_coroutine_threadsafe(coro, loop)
            return future.result()
        return loop.run_until_complete(coro)

    def start(self) -> "Sandbox":
        """
        Connects to the gateway and creates the remote sandbox environment (synchronous version).

        This method is idempotent and safe to call multiple times.
        """
        if self._is_active:
            return self
        self._run_sync(self._async_start())
        return self

    async def astart(self) -> "Sandbox":
        """
        Connects to the gateway and creates the remote sandbox environment (asynchronous version).

        This method is idempotent and safe to call multiple times.
        """
        if self._is_active:
            return self
        await self._async_start()
        return self

    async def _async_start(self) -> None:
        """Asynchronous setup logic."""
        if self._client is None:
            self._client = GatewayClient(
                self._domain,
                api_key=self._api_key,
                timeout=self._timeout,
                ping_interval=self._ping_interval,
                ping_timeout=self._ping_timeout,
            )

        # Start the underlying client (connects websocket)
        await self._client.start()

        try:
            # Create the specific sandbox environment on the server
            await self._client.create_sandbox(
                self.sandbox_id,
                ram_mb=self._ram_mb,
                vcpu=self._vcpu,
            )
            self._is_active = True
            logger.info("Sandbox %s created and active.", self.sandbox_id)
        except Exception:
            # If creating the sandbox fails, ensure we clean up the connection
            await self._client.close()
            raise

    def close(self, exc_type: Any = None, exc: Any = None, tb: Any = None) -> None:
        """
        Deletes the remote sandbox and closes all network connections (synchronous version).

        This method is idempotent and safe to call multiple times.
        """
        if not self._is_active:
            return
        self._run_sync(self._async_close(exc_type, exc, tb))

    async def aclose(
        self, exc_type: Any = None, exc: Any = None, tb: Any = None
    ) -> None:
        """
        Deletes the remote sandbox and closes all network connections (asynchronous version).

        This method is idempotent and safe to call multiple times.
        """
        if not self._is_active:
            return
        await self._async_close(exc_type, exc, tb)

    async def _async_close(self, exc_type: Any, exc: Any, tb: Any) -> None:
        """Asynchronous teardown logic."""
        if not self._client:
            return

        # Suppress errors during deletion, as we want to proceed to close the connection
        with contextlib.suppress(Exception):
            logger.info("Deleting sandbox %s...", self.sandbox_id)
            await self._client.delete_sandbox(self.sandbox_id)
            logger.info("Sandbox %s deleted.", self.sandbox_id)

        # Close the underlying client connection
        await self._client.close(exc_type, exc, tb)
        self._is_active = False

    def __enter__(self) -> "Sandbox":
        """Context manager entry point. Starts the sandbox."""
        return self.start()

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        """Context manager exit point. Closes the sandbox."""
        self.close(exc_type, exc, tb)
        if self._loop and not self._loop.is_running():
            self._loop.close()
            self._loop = None

    async def __aenter__(self) -> "Sandbox":
        """Async context manager entry point. Starts the sandbox."""
        await self._async_start()
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        """Async context manager exit point. Closes the sandbox."""
        await self._async_close(exc_type, exc, tb)

    def run_code(
        self,
        code: str,
        *,
        language: str = "python3",
        env_vars: Optional[dict[str, str]] = None,
        stream: bool = False,
        context_id: Optional[str] = None,
    ) -> Union[Execution, Iterator[KernelMessage]]:
        """
        Executes code inside the sandbox (synchronous version).

        Args:
            code: The code string to execute.
            language: The programming language of the code (only used if context_id is None).
            stream: If False (default), blocks until execution is complete and
                    returns an `Execution` object. If True, returns an iterator
                    that yields `KernelMessage` events as they occur.
            context_id: Optional context/notebook ID. If not provided, uses the default
                       context_id set in __init__ (if any), otherwise uses default context for language.

        Returns:
            An `Execution` object or an `Iterator[KernelMessage]`.

        Raises:
            SandboxError: If the sandbox is not running.
        """
        if not self._is_active or not self._client:
            raise SandboxError(
                "Sandbox not running. Use 'with Sandbox(...) as sbx:' or call sandbox.start()."
            )

        # Use provided context_id, or fall back to default, or None
        effective_context_id = context_id or self._default_context_id

        async_event_stream = self._client.execute_code(
            self.sandbox_id,
            code,
            language=language,
            env_vars={**(env_vars or {}), **(self._additional_env_vars or {})},
            context_id=effective_context_id,
        )

        if not stream:
            # Block and collect all events, then return a final Execution object
            async def _collect_events() -> List[KernelMessage]:
                return [event async for event in async_event_stream]

            events = self._run_sync(_collect_events())
            return Execution(events=events)

        return self._stream_synchronously(async_event_stream)

    async def arun_code(
        self,
        code: str,
        *,
        language: str = "python3",
        env_vars: Optional[dict[str, str]] = None,
        stream: bool = False,
        context_id: Optional[str] = None,
    ) -> Union[Execution, AsyncIterator[KernelMessage]]:
        """
        Executes code inside the sandbox (asynchronous version).

        Args:
            code: The code string to execute.
            language: The programming language of the code (only used if context_id is None).
            stream: If False (default), awaits until execution is complete and
                    returns an `Execution` object. If True, returns an async iterator
                    that yields `KernelMessage` events as they occur.
            context_id: Optional context/notebook ID. If not provided, uses the default
                       context_id set in __init__ (if any), otherwise uses default context for language.

        Returns:
            An `Execution` object or an `AsyncIterator[KernelMessage]`.

        Raises:
            SandboxError: If the sandbox is not running.
        """
        if not self._is_active or not self._client:
            raise SandboxError(
                "Sandbox not running. Use 'async with Sandbox(...) as sbx:' or call await sandbox.start()."
            )

        # Use provided context_id, or fall back to default, or None
        effective_context_id = context_id or self._default_context_id

        async_event_stream = self._client.execute_code(
            self.sandbox_id,
            code,
            language=language,
            env_vars={**(env_vars or {}), **(self._additional_env_vars or {})},
            context_id=effective_context_id,
        )

        if not stream:
            # Collect all events asynchronously, then return a final Execution object
            events = [event async for event in async_event_stream]
            return Execution(events=events)

        return async_event_stream

    def _stream_synchronously(
        self, async_iterator: AsyncIterator[KernelMessage]
    ) -> Iterator[KernelMessage]:
        """Converts an async iterator to a sync iterator using a queue."""
        queue: asyncio.Queue[Optional[KernelMessage]] = asyncio.Queue()
        loop = self._get_loop()

        async def producer() -> None:
            """Pulls items from the async source and puts them on the queue."""
            try:
                async for item in async_iterator:
                    await queue.put(item)
            finally:
                await queue.put(None)  # Sentinel to signal the end

        # Start the producer coroutine as a fire-and-forget task
        loop.create_task(producer())

        while True:
            # Block until an item is available in the queue
            item = self._run_sync(queue.get())
            if item is None:  # End of stream
                break
            yield item

    # Context management methods
    def create_context(
        self,
        language: str = "python3",
        *,
        cwd: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        """
        Create a new context (notebook/kernel) in this sandbox (synchronous version).

        Args:
            language: Programming language for the kernel.
            cwd: Working directory for the context.
            env: Environment variables for the context.

        Returns:
            A dictionary with context info including 'id', 'language', and 'cwd'.

        Raises:
            SandboxError: If the sandbox is not running.
        """
        if not self._is_active or not self._client:
            raise SandboxError(
                "Sandbox not running. Use 'with Sandbox(...) as sbx:' or call sandbox.start()."
            )
        return self._run_sync(
            self._client.create_context(self.sandbox_id, language, cwd=cwd, env=env)
        )

    async def acreate_context(
        self,
        language: str = "python3",
        *,
        cwd: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        """
        Create a new context (notebook/kernel) in this sandbox (asynchronous version).

        Args:
            language: Programming language for the kernel.
            cwd: Working directory for the context.
            env: Environment variables for the context.

        Returns:
            A dictionary with context info including 'id', 'language', and 'cwd'.

        Raises:
            SandboxError: If the sandbox is not running.
        """
        if not self._is_active or not self._client:
            raise SandboxError(
                "Sandbox not running. Use 'async with Sandbox(...) as sbx:' or call await sandbox.astart()."
            )
        return await self._client.create_context(
            self.sandbox_id, language, cwd=cwd, env=env
        )

    def list_contexts(self) -> List[dict[str, Any]]:
        """
        List all contexts in this sandbox (synchronous version).

        Returns:
            A list of context info dictionaries.

        Raises:
            SandboxError: If the sandbox is not running.
        """
        if not self._is_active or not self._client:
            raise SandboxError(
                "Sandbox not running. Use 'with Sandbox(...) as sbx:' or call sandbox.start()."
            )
        return self._run_sync(self._client.list_contexts(self.sandbox_id))

    async def alist_contexts(self) -> List[dict[str, Any]]:
        """
        List all contexts in this sandbox (asynchronous version).

        Returns:
            A list of context info dictionaries.

        Raises:
            SandboxError: If the sandbox is not running.
        """
        if not self._is_active or not self._client:
            raise SandboxError(
                "Sandbox not running. Use 'async with Sandbox(...) as sbx:' or call await sandbox.astart()."
            )
        return await self._client.list_contexts(self.sandbox_id)

    def restart_context(self, context_id: str) -> None:
        """
        Restart a specific context (synchronous version).

        Args:
            context_id: The ID of the context to restart.

        Raises:
            SandboxError: If the sandbox is not running.
        """
        if not self._is_active or not self._client:
            raise SandboxError(
                "Sandbox not running. Use 'with Sandbox(...) as sbx:' or call sandbox.start()."
            )
        self._run_sync(self._client.restart_context(self.sandbox_id, context_id))

    async def arestart_context(self, context_id: str) -> None:
        """
        Restart a specific context (asynchronous version).

        Args:
            context_id: The ID of the context to restart.

        Raises:
            SandboxError: If the sandbox is not running.
        """
        if not self._is_active or not self._client:
            raise SandboxError(
                "Sandbox not running. Use 'async with Sandbox(...) as sbx:' or call await sandbox.astart()."
            )
        await self._client.restart_context(self.sandbox_id, context_id)

    def delete_context(self, context_id: str) -> None:
        """
        Delete a specific context (synchronous version).

        Args:
            context_id: The ID of the context to delete.

        Raises:
            SandboxError: If the sandbox is not running.
        """
        if not self._is_active or not self._client:
            raise SandboxError(
                "Sandbox not running. Use 'with Sandbox(...) as sbx:' or call sandbox.start()."
            )
        self._run_sync(self._client.delete_context(self.sandbox_id, context_id))

    async def adelete_context(self, context_id: str) -> None:
        """
        Delete a specific context (asynchronous version).

        Args:
            context_id: The ID of the context to delete.

        Raises:
            SandboxError: If the sandbox is not running.
        """
        if not self._is_active or not self._client:
            raise SandboxError(
                "Sandbox not running. Use 'async with Sandbox(...) as sbx:' or call await sandbox.astart()."
            )
        await self._client.delete_context(self.sandbox_id, context_id)

    # Helper methods for context-bound sandboxes
    def create_context_bound_sandbox(
        self,
        language: str = "python3",
        *,
        cwd: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
    ) -> "Sandbox":
        """
        Create a context and return a NEW Sandbox instance with the context pre-bound (synchronous version).

        This is a convenience method that creates a context and returns a new Sandbox
        instance with the context_id set as default, allowing you to call run_code()
        without specifying context_id each time.

        Args:
            language: Programming language for the kernel.
            cwd: Working directory for the context.
            env: Environment variables for the context.

        Returns:
            A new Sandbox instance with the context pre-bound.

        Example:
            ```python
            with Sandbox() as sbx:
                sbx_a = sbx.create_context_bound_sandbox(language="python3")
                sbx_b = sbx.create_context_bound_sandbox(language="python3")

                # These are both Sandbox instances!
                sbx_a.run_code("x = 10; print(x)")
                sbx_b.run_code("x = 20; print(x)")
            ```
        """
        ctx = self.create_context(language=language, cwd=cwd, env=env)

        # Create a new Sandbox instance that shares the client and has a default context
        return Sandbox(
            sandbox_id=self.sandbox_id,
            gateway_client=self._client,
            context_id=ctx["id"],
            domain=self._domain,
            api_key=self._api_key,
            additional_env_vars=self._additional_env_vars,
            timeout=self._timeout,
            ping_interval=self._ping_interval,
            ping_timeout=self._ping_timeout,
        )

    async def acreate_context_bound_sandbox(
        self,
        language: str = "python3",
        *,
        cwd: Optional[str] = None,
        env: Optional[dict[str, str]] = None,
    ) -> "Sandbox":
        """
        Create a context and return a NEW Sandbox instance with the context pre-bound (asynchronous version).

        This is a convenience method that creates a context and returns a new Sandbox
        instance with the context_id set as default, allowing you to call arun_code()
        without specifying context_id each time.

        Args:
            language: Programming language for the kernel.
            cwd: Working directory for the context.
            env: Environment variables for the context.

        Returns:
            A new Sandbox instance with the context pre-bound.

        Example:
            ```python
            async with Sandbox() as sbx:
                sbx_a = await sbx.acreate_context_bound_sandbox(language="python3")
                sbx_b = await sbx.acreate_context_bound_sandbox(language="python3")

                # These are both Sandbox instances!
                await sbx_a.arun_code("x = 10; print(x)")
                await sbx_b.arun_code("x = 20; print(x)")
            ```
        """
        ctx = await self.acreate_context(language=language, cwd=cwd, env=env)

        # Create a new Sandbox instance that shares the client and has a default context
        # Note: We mark it as active since it shares the parent's client
        new_sandbox = Sandbox(
            sandbox_id=self.sandbox_id,
            gateway_client=self._client,
            context_id=ctx["id"],
            domain=self._domain,
            api_key=self._api_key,
            additional_env_vars=self._additional_env_vars,
            timeout=self._timeout,
            ping_interval=self._ping_interval,
            ping_timeout=self._ping_timeout,
        )
        new_sandbox._is_active = True  # Mark as active since we're sharing the client
        return new_sandbox
