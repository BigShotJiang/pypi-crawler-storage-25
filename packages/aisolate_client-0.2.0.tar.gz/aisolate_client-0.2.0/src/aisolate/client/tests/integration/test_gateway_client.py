from textwrap import dedent
from typing import List

import pytest

from aisolate.common.models import (
    DisplayData,
    ErrorOutput,
    ExecuteResult,
    KernelBusy,
    KernelMessage,
    StreamOutput,
    KernelExecutionCompleted,
)

from ...gateway_client import GatewayClient


async def execute_code(
    client: GatewayClient, sandbox_id: str, code: str, language: str
) -> List[KernelMessage]:
    """
    Executes code in a sandbox via websocket and returns the frames.
    """
    events = []
    async for event in client.execute_code(sandbox_id, code=code, language=language):
        events.append(event)
    return events


@pytest.mark.asyncio
async def test_create_and_delete_sandbox(gateway_client_instance: GatewayClient):
    """
    Verify the simplest HTTP round-trip: create → delete
    """
    sandbox_id = "sbx_http"

    sbx = await gateway_client_instance.create_sandbox(sandbox_id)
    assert sbx["sandboxID"] == sandbox_id

    # teardown
    await gateway_client_instance.delete_sandbox(sandbox_id)


@pytest.mark.asyncio
async def test_execute_code_returns_result(gateway_client_instance: GatewayClient):
    """
    End-to-end WebSocket round-trip: send '1+1', receive ExecutionResult == 2
    """
    sandbox_id = "sbx_ws"
    await gateway_client_instance.create_sandbox(sandbox_id)

    got_result = False

    async for event in gateway_client_instance.execute_code(sandbox_id, code="1+1"):
        # Only need to observe one terminal event
        if isinstance(event, ExecuteResult):
            assert event.data == {"text/plain": "2"}
            got_result = True
            break

    assert got_result, "No ExecutionResult frame received"
    await gateway_client_instance.delete_sandbox(sandbox_id)


@pytest.mark.asyncio
async def test_execute_python_chart_returns_image(
    gateway_client_instance: GatewayClient,
):
    """
    End-to-end: execute a Matplotlib snippet and confirm we get an image/png frame.
    """
    sandbox_id = "sbx_chart"
    await gateway_client_instance.create_sandbox(sandbox_id)

    code = dedent(
        """
    import matplotlib.pyplot as plt
    plt.plot([0, 1, 2, 3], [0, 1, 4, 9], marker="o")
    _ = plt.title("Sandbox-Gateway Test Plot")
    plt.tight_layout()
    plt.show()
    """
    )
    events = await execute_code(gateway_client_instance, sandbox_id, code, "python3")
    event = next(e for e in events if isinstance(e, DisplayData))
    assert isinstance(
        event.data["image/png"], (bytes, bytearray)
    ), "No image/png DisplayData frame received"

    await gateway_client_instance.delete_sandbox(sandbox_id)


@pytest.mark.asyncio
async def test_execute_deno_chart_returns_image(
    gateway_client_instance: GatewayClient,
):
    """
    End-to-end: execute a Matplotlib snippet and confirm we get an image/png frame.
    """
    sandbox_id = "sbx_chart"
    await gateway_client_instance.create_sandbox(sandbox_id)

    code = dedent(
        """import * as Plot from "npm:@observablehq/plot";
        import { DOMParser } from "npm:linkedom";

        const document = new DOMParser().parseFromString(
        `<!DOCTYPE html><html lang="en"></html>`,
        "text/html",
        );

        const data = [
        {x: 0, y: 0},
        {x: 1, y: 1},
        {x: 2, y: 2},
        {x: 3, y: 3},
        {x: 4, y: 4},
        {x: 5, y: 5},
        ];

        const plot = Plot.plot({
        document,
        width: 600,
        height: 400,
        marginLeft: 50,
        marginBottom: 50,
        x: {
            label: "X Axis",
            grid: true,
        },
        y: {
            label: "Y Axis",
            grid: true,
        },
        marks: [
            // Area under the line for a subtle fill effect using Plot.areaY:
            Plot.areaY(data, { x: "x", y: "y", y1: 0, fill: "lightblue", opacity: 0.5 }),
            // Main line with tooltips enabled:
            Plot.line(data, { x: "x", y: "y", stroke: "steelblue", strokeWidth: 2, tip: true }),
            // Dots at each data point with a title showing coordinates:
            Plot.dot(data, { 
            x: "x", 
            y: "y", 
            fill: "white", 
            stroke: "steelblue", 
            r: 4, 
            title: d => `(${d.x}, ${d.y})`
            }),
            // Vertical reference line at x = 2.5:
            Plot.ruleX([2.5], { stroke: "red", strokeDasharray: "4 2", title: "x = 2.5" }),
            // Horizontal reference line at y = 2.5:
            Plot.ruleY([2.5], { stroke: "green", strokeDasharray: "4 2", title: "y = 2.5" }),
        ],
        }).toString();

        const display = {
        [Symbol.for("Jupyter.display")]() {
            return {
            "image/svg+xml": plot,
            };
        },
        };

        display;
        """
    )
    events = await execute_code(gateway_client_instance, sandbox_id, code, "deno")
    event = next(e for e in events if isinstance(e, ExecuteResult))
    assert isinstance(
        event.data["image/svg+xml"], str
    ), "No image/svg+xml DisplayData frame received"

    await gateway_client_instance.delete_sandbox(sandbox_id)


@pytest.mark.asyncio
async def test_execute_code_returns_stream(gateway_client_instance: GatewayClient):
    """
    End-to-end WebSocket round-trip: send a print statement, receive StreamOutput.
    """
    sandbox_id = "sbx_stream"
    await gateway_client_instance.create_sandbox(sandbox_id)

    code = 'print("hello from sandbox")'
    expected_text = "hello from sandbox\n"

    events: List[KernelMessage] = []
    async for event in gateway_client_instance.execute_code(sandbox_id, code=code):
        events.append(event)

    event_types = [type(e) for e in events]
    assert StreamOutput in event_types

    stream_event = next(e for e in events if isinstance(e, StreamOutput))
    assert stream_event.name == "stdout"
    assert stream_event.text == expected_text

    await gateway_client_instance.delete_sandbox(sandbox_id)


@pytest.mark.asyncio
async def test_execute_code_raises_error(gateway_client_instance: GatewayClient):
    """
    Execute code that raises an exception and confirm we get an ErrorOutput.
    """
    sandbox_id = "sbx_error"
    await gateway_client_instance.create_sandbox(sandbox_id)

    code = "1 / 0"

    events: List[KernelMessage] = []
    async for event in gateway_client_instance.execute_code(sandbox_id, code=code):
        events.append(event)

    event_types = [type(e) for e in events]
    assert ErrorOutput in event_types

    event = next(e for e in events if isinstance(e, ErrorOutput))
    assert event.error_name == "ZeroDivisionError"
    assert "division by zero" in event.error_value
    assert isinstance(event.traceback, list)
    assert len(event.traceback) > 0

    await gateway_client_instance.delete_sandbox(sandbox_id)


@pytest.mark.asyncio
async def test_execution_lifecycle_sends_busy_and_idle(
    gateway_client_instance: GatewayClient,
):
    """
    Verify that a simple execution emits KernelBusy at the start and KernelIdle at the end.
    """
    sandbox_id = "sbx_lifecycle"
    await gateway_client_instance.create_sandbox(sandbox_id)

    events: List[KernelMessage] = []
    async for event in gateway_client_instance.execute_code(sandbox_id, code="x = 42"):
        events.append(event)

    event_types = [type(e) for e in events]
    assert KernelExecutionCompleted in event_types
    assert KernelBusy in event_types

    await gateway_client_instance.delete_sandbox(sandbox_id)


@pytest.mark.asyncio
async def test_multiple_outputs_are_streamed_correctly(
    gateway_client_instance: GatewayClient,
):
    """
    Execute code that produces multiple outputs and verify they are all received.
    """
    sandbox_id = "sbx_multi"
    await gateway_client_instance.create_sandbox(sandbox_id)

    code = "print('First line')\n'Final result'"
    events: List[KernelMessage] = []

    async for event in gateway_client_instance.execute_code(sandbox_id, code=code):
        events.append(event)

    # Check that we received the expected types of events
    event_types = [type(e) for e in events]
    assert KernelBusy in event_types
    assert StreamOutput in event_types
    assert ExecuteResult in event_types
    assert KernelExecutionCompleted in event_types

    # Find and validate the specific events
    stream_event = next(e for e in events if isinstance(e, StreamOutput))
    assert stream_event.name == "stdout"
    assert stream_event.text == "First line\n"

    result_event = next(e for e in events if isinstance(e, ExecuteResult))
    assert result_event.data == {"text/plain": "'Final result'"}

    await gateway_client_instance.delete_sandbox(sandbox_id)


@pytest.mark.asyncio
async def test_context_management(gateway_client_instance: GatewayClient):
    """
    Test creating, listing, and using multiple contexts within a single sandbox.
    """
    sandbox_id = "sbx_contexts"
    await gateway_client_instance.create_sandbox(sandbox_id)

    # Create two contexts
    ctx_a = await gateway_client_instance.create_context(sandbox_id, language="python3")
    ctx_b = await gateway_client_instance.create_context(sandbox_id, language="python3")

    assert "id" in ctx_a
    assert "id" in ctx_b
    assert ctx_a["id"] != ctx_b["id"]
    assert ctx_a["language"] == "python3"
    assert ctx_b["language"] == "python3"

    # List contexts
    contexts = await gateway_client_instance.list_contexts(sandbox_id)
    assert len(contexts) >= 2
    context_ids = [ctx["id"] for ctx in contexts]
    assert ctx_a["id"] in context_ids
    assert ctx_b["id"] in context_ids

    # Execute code in context A
    events_a = []
    async for event in gateway_client_instance.execute_code(
        sandbox_id, code="x = 10; x", context_id=ctx_a["id"]
    ):
        events_a.append(event)

    result_a = next(e for e in events_a if isinstance(e, ExecuteResult))
    assert result_a.data == {"text/plain": "10"}

    # Execute code in context B
    events_b = []
    async for event in gateway_client_instance.execute_code(
        sandbox_id, code="x = 20; x", context_id=ctx_b["id"]
    ):
        events_b.append(event)

    result_b = next(e for e in events_b if isinstance(e, ExecuteResult))
    assert result_b.data == {"text/plain": "20"}

    # Verify isolation: context A still has x=10
    events_a2 = []
    async for event in gateway_client_instance.execute_code(
        sandbox_id, code="x", context_id=ctx_a["id"]
    ):
        events_a2.append(event)

    result_a2 = next(e for e in events_a2 if isinstance(e, ExecuteResult))
    assert result_a2.data == {"text/plain": "10"}

    # Restart context A
    await gateway_client_instance.restart_context(sandbox_id, ctx_a["id"])

    # After restart, x should be undefined in context A
    events_a3 = []
    async for event in gateway_client_instance.execute_code(
        sandbox_id, code="x", context_id=ctx_a["id"]
    ):
        events_a3.append(event)

    error_event = next(e for e in events_a3 if isinstance(e, ErrorOutput))
    assert error_event.error_name == "NameError"

    # Delete context B
    await gateway_client_instance.delete_context(sandbox_id, ctx_b["id"])

    # List contexts again - context B should be gone
    contexts_after = await gateway_client_instance.list_contexts(sandbox_id)
    remaining_ids = [ctx["id"] for ctx in contexts_after]
    assert ctx_b["id"] not in remaining_ids

    await gateway_client_instance.delete_sandbox(sandbox_id)
