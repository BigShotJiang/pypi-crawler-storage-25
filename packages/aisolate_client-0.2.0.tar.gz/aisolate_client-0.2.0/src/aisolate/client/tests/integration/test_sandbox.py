from textwrap import dedent
from typing import List

import pytest
from PIL import Image

from aisolate.common.models import (
    ExecuteResult,
    KernelBusy,
    KernelExecutionCompleted,
    KernelMessage,
    StreamOutput,
)

from ...sandbox import Execution, Sandbox


@pytest.fixture
def sandbox_cls(gateway_client_instance):
    """Fixture to provide the Sandbox class with a patched domain."""

    def factory(*args, **kwargs):
        return Sandbox(
            domain="test.local", *args, **kwargs, gateway_client=gateway_client_instance
        )

    return factory


@pytest.mark.asyncio
async def test_sandbox_lifecycle(sandbox_cls):
    """Verify that entering and exiting the context manager creates and deletes the sandbox."""
    async with sandbox_cls(sandbox_id="sbx_lifecycle_test") as sbx:
        assert sbx.sandbox_id == "sbx_lifecycle_test"


@pytest.mark.asyncio
async def test_execution_with_simple_result(sandbox_cls):
    """Test blocking execution that returns a simple text result."""
    async with sandbox_cls(sandbox_id="sbx_result") as sbx:
        execution = await sbx.arun_code("'hello world'")

        assert isinstance(execution, Execution)
        assert not execution.has_error
        assert execution.stdout == ""
        assert execution.output_type == "text/plain"
        assert execution.text == "'hello world'"


@pytest.mark.asyncio
async def test_execution_with_stdout(sandbox_cls):
    """Test blocking execution that only prints to stdout."""
    async with sandbox_cls(sandbox_id="sbx_stdout") as sbx:
        code = 'print("line 1")\nprint("line 2")'
        execution = await sbx.arun_code(code)

        assert isinstance(execution, Execution)
        assert not execution.has_error
        assert execution.stdout == "line 1\nline 2\n"
        assert execution.output is None
        assert execution.text is None
        assert execution.error is None


@pytest.mark.asyncio
async def test_execution_with_error(sandbox_cls):
    """Test a blocking execution that raises a Python exception."""
    async with sandbox_cls(sandbox_id="sbx_error") as sbx:
        execution = await sbx.arun_code("1 / 0")

        assert isinstance(execution, Execution)
        assert execution.has_error
        assert execution.error is not None
        assert execution.error.error_name == "ZeroDivisionError"
        assert "division by zero" in execution.error.error_value
        assert "Traceback (most recent call last)" in execution.traceback_str
        assert "1 / 0" in execution.traceback_str
        assert "ZeroDivisionError: division by zero" in execution.traceback_str


@pytest.mark.asyncio
async def test_execution_generates_image(sandbox_cls):
    """Test execution that generates a plot and verify the image property."""
    async with sandbox_cls(sandbox_id="sbx_chart") as sbx:
        code = dedent(
            """
            import base64
            from io import BytesIO
            import matplotlib.pyplot as plt

            fig, ax = plt.subplots()
            ax.plot([1, 2, 3], [1, 4, 9])
            ax.set_title("Test Plot")

            # Instead of plt.show(), save to a buffer and encode
            buf = BytesIO()
            fig.savefig(buf, format='png')
            buf.seek(0)
            # Display the base64 encoded string so it can be captured
            from IPython.display import display, Image
            img = Image(data=buf.getvalue(), format='png')
            display(img)
            """
        )
        execution = await sbx.arun_code(code)

        assert isinstance(execution, Execution)
        assert not execution.has_error
        assert execution.image is not None
        assert isinstance(execution.image, Image.Image)
        assert execution.image.format == "PNG"


@pytest.mark.asyncio
async def test_streaming_execution(sandbox_cls):
    """Test the streaming API by iterating over all kernel events."""
    async with sandbox_cls(sandbox_id="sbx_stream") as sbx:
        code = "print('interim output'); 'final result'"
        events_iterator = await sbx.arun_code(code, stream=True)

        # Test actual streaming behavior by processing events as they arrive
        events: List[KernelMessage] = []
        stream_output_received = False
        execution_result_received = False

        async for event in events_iterator:
            events.append(event)

            # Verify we can process events in real-time
            if isinstance(event, StreamOutput):
                assert event.text == "interim output\n"
                assert event.name == "stdout"
                stream_output_received = True

            elif isinstance(event, ExecuteResult):
                assert event.data == {"text/plain": "'final result'"}
                execution_result_received = True

        # Verify we received the expected events
        assert stream_output_received, "StreamOutput event was not received"
        assert execution_result_received, "ExecuteResult event was not received"

        # Check that we received the expected types of events in proper sequence
        event_types = [type(e) for e in events]
        assert KernelBusy in event_types, "KernelBusy event missing"
        assert StreamOutput in event_types, "StreamOutput event missing"
        assert ExecuteResult in event_types, "ExecuteResult event missing"
        assert (
            KernelExecutionCompleted in event_types
        ), "KernelExecutionCompleted event missing"

        # Verify proper ordering: KernelBusy should come first, KernelExecutionCompleted should come last
        first_busy_idx = next(
            i for i, e in enumerate(events) if isinstance(e, KernelBusy)
        )
        last_completed_idx = next(
            i
            for i, e in enumerate(reversed(events))
            if isinstance(e, KernelExecutionCompleted)
        )
        last_completed_idx = len(events) - 1 - last_completed_idx

        assert (
            first_busy_idx < last_completed_idx
        ), "KernelBusy should come before KernelExecutionCompleted"

        # Verify we have exactly one of each expected event type
        assert len([e for e in events if isinstance(e, StreamOutput)]) == 1
        assert len([e for e in events if isinstance(e, ExecuteResult)]) == 1


@pytest.mark.asyncio
async def test_streaming_multiple_outputs(sandbox_cls):
    """Test streaming with multiple print statements and outputs."""
    async with sandbox_cls(sandbox_id="sbx_multi_stream") as sbx:
        code = dedent(
            """
            print('First line')
            print('Second line')
            x = 42
            print(f'Third line: {x}')
            'final_result'
        """
        ).strip()

        events_iterator = await sbx.arun_code(code, stream=True)

        events: List[KernelMessage] = []
        stream_outputs = []

        async for event in events_iterator:
            events.append(event)
            if isinstance(event, StreamOutput):
                stream_outputs.append(event.text)

        # Verify we received multiple stream outputs
        assert stream_outputs == ["First line\nSecond line\nThird line: 42\n"]

        # Verify final result
        result_events = [e for e in events if isinstance(e, ExecuteResult)]
        assert len(result_events) == 1
        assert result_events[0].data == {"text/plain": "'final_result'"}


@pytest.mark.asyncio
async def test_streaming_no_stdout(sandbox_cls):
    """Test streaming execution with no stdout output."""
    async with sandbox_cls(sandbox_id="sbx_no_stdout") as sbx:
        code = "42 + 8"  # No print statements, just a result
        events_iterator = await sbx.arun_code(code, stream=True)

        events: List[KernelMessage] = [event async for event in events_iterator]

        # Should have no StreamOutput events
        stream_events = [e for e in events if isinstance(e, StreamOutput)]
        assert len(stream_events) == 0

        # Should still have ExecuteResult
        result_events = [e for e in events if isinstance(e, ExecuteResult)]
        assert len(result_events) == 1
        assert result_events[0].data == {"text/plain": "50"}

        # Should still have proper kernel lifecycle events
        event_types = [type(e) for e in events]
        assert KernelBusy in event_types
        assert KernelExecutionCompleted in event_types


@pytest.mark.asyncio
async def test_agent_like_result_handling(sandbox_cls):
    """
    Tests the sandbox execution flow, mimicking the logic of an agent that
    processes results by checking for errors, then images, then text.
    """
    # Scenario 1: Execution with an error, verifying log generation
    async with sandbox_cls(sandbox_id="sbx_agent_error") as sbx:
        code_with_error = "print('operation started'); 1 / 0"
        execution = await sbx.arun_code(code_with_error)

        # Agent's error handling logic
        if execution.has_error:
            logs = execution.stdout
            logs += "Executing code yielded an error:\n"
            logs += execution.error.error_name + "\n"
            logs += execution.error.error_value + "\n"
            logs += execution.traceback_str

            assert "operation started" in logs
            assert "Executing code yielded an error:" in logs
            assert "ZeroDivisionError" in logs
            assert "division by zero" in logs
            assert "Traceback" in logs
        else:
            pytest.fail("Execution should have failed but did not.")

    # Scenario 2: Execution with an image result
    async with sandbox_cls(sandbox_id="sbx_agent_image") as sbx:
        code_with_image = dedent(
            """
            from IPython.display import display, Image
            import numpy as np
            from PIL import Image as PILImage
            from io import BytesIO

            print('generating image...')
            im_array = np.random.randint(0, 255, size=(10, 20, 3), dtype=np.uint8)
            pil_img = PILImage.fromarray(im_array, 'RGB')
            
            buffer = BytesIO()
            pil_img.save(buffer, format="PNG")
            display(Image(data=buffer.getvalue()))
            """
        )
        execution = await sbx.arun_code(code_with_image)
        execution_logs = execution.stdout
        main_result = None

        if not execution.has_error:
            if execution.image:
                main_result = execution.image
            elif execution.text:
                main_result = execution.text

        assert "generating image..." in execution_logs
        assert isinstance(main_result, Image.Image)
        assert main_result.format == "PNG"

    # Scenario 3: Execution with a text result
    async with sandbox_cls(sandbox_id="sbx_agent_text") as sbx:
        code_with_text = "print('calculating...'); 'the final answer'"
        execution = await sbx.arun_code(code_with_text)
        execution_logs = execution.stdout
        main_result = None

        if not execution.has_error:
            if execution.image:
                main_result = execution.image
            elif execution.text:
                main_result = execution.text

        assert "calculating..." in execution_logs
        assert main_result == "'the final answer'"

    # Scenario 4: Execution with no specific result (only stdout)
    async with sandbox_cls(sandbox_id="sbx_agent_no_result") as sbx:
        code_no_result = "print('all tasks complete.')"
        execution = await sbx.arun_code(code_no_result)
        execution_logs = execution.stdout
        main_result = None

        if not execution.has_error:
            if execution.image:
                main_result = execution.image
            elif execution.text:
                main_result = execution.text

        assert "all tasks complete." in execution_logs
        assert main_result is None


@pytest.mark.asyncio
async def test_context_bound_sandbox(sandbox_cls):
    """
    Test creating context-bound sandboxes that return proper Sandbox instances
    with default context_id set.
    """
    async with sandbox_cls(sandbox_id="sbx_context_bound") as sbx:
        # Create two context-bound sandboxes
        sbx_a = await sbx.acreate_context_bound_sandbox(language="python3")
        sbx_b = await sbx.acreate_context_bound_sandbox(language="python3")

        # Verify they are Sandbox instances
        from ...sandbox import Sandbox

        assert isinstance(sbx_a, Sandbox)
        assert isinstance(sbx_b, Sandbox)

        # Verify they have default context IDs set
        assert sbx_a._default_context_id is not None
        assert sbx_b._default_context_id is not None
        assert sbx_a._default_context_id != sbx_b._default_context_id

        # Execute code without passing context_id
        result_a = await sbx_a.arun_code("x = 10; print(f'Context A: x = {x}'); x")
        result_b = await sbx_b.arun_code("x = 20; print(f'Context B: x = {x}'); x")

        # Cast to Execution for type checker
        from typing import cast

        exec_a = cast(Execution, result_a)
        exec_b = cast(Execution, result_b)

        assert not exec_a.has_error
        assert not exec_b.has_error
        assert exec_a.text == "10"
        assert exec_b.text == "20"
        assert "Context A: x = 10" in exec_a.stdout
        assert "Context B: x = 20" in exec_b.stdout

        # Verify isolation - variables don't leak between contexts
        exec_a2 = cast(Execution, await sbx_a.arun_code("x"))
        exec_b2 = cast(Execution, await sbx_b.arun_code("x"))

        assert exec_a2.text == "10"  # Still 10 in context A
        assert exec_b2.text == "20"  # Still 20 in context B


@pytest.mark.asyncio
async def test_context_bound_sandbox_with_override(sandbox_cls):
    """
    Test that context_id can still be overridden on context-bound sandboxes.
    """
    from typing import cast

    async with sandbox_cls(sandbox_id="sbx_context_override") as sbx:
        # Create context-bound sandbox
        sbx_a = await sbx.acreate_context_bound_sandbox(language="python3")

        # Set a variable in the default context
        await sbx_a.arun_code("x = 100")

        # Create another context manually
        ctx_b = await sbx.acreate_context(language="python3")

        # Override the default context_id to use ctx_b
        exec_in_b = cast(
            Execution, await sbx_a.arun_code("x = 200; x", context_id=ctx_b["id"])
        )
        assert exec_in_b.text == "200"

        # Verify the default context still has x=100
        exec_in_default = cast(Execution, await sbx_a.arun_code("x"))
        assert exec_in_default.text == "100"

        # Verify ctx_b has x=200
        exec_in_b2 = cast(Execution, await sbx_a.arun_code("x", context_id=ctx_b["id"]))
        assert exec_in_b2.text == "200"
