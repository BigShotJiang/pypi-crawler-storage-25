import asyncio
import importlib
from contextlib import AsyncExitStack
from pathlib import Path
from types import SimpleNamespace

import pytest_asyncio
from asgi_lifespan import LifespanManager
from aisolate.common.tests.utils import WsAliasTestClient

# Import fixtures from common fixtures module
from aisolate.common.tests.fixtures import *


class _DummyProcess(SimpleNamespace):
    returncode = None
    pid = 12345

    async def wait(self):
        return 0

    def kill(self):
        self.returncode = -9

    def terminate(self):
        return 0


@pytest_asyncio.fixture(autouse=True)
async def _patch_create_firecracker(kernel_gateway_proc, monkeypatch):
    """
    Monkey-patch the Firecracker helper so the gateway thinks it started a VM,
    now returning a FirecrackerVM dataclass instead of a tuple.
    """
    # import your service module, which already does:
    fc_mod = importlib.import_module("aisolate.gateway.app.services.firecracker")
    sandbox_app = importlib.import_module("aisolate.sandbox.app.main").app

    # Track all stacks so we can clean them up at the end
    stacks = []

    async def _fake_create_firecracker_vm(sbx):
        # Create a new stack for each sandbox to avoid WebSocket reuse issues
        stack = AsyncExitStack()
        stacks.append(stack)

        # bring up the ASGI sandbox app so WS paths exist
        await stack.enter_async_context(LifespanManager(sandbox_app))
        # get a test client that supports HTTP + WS
        async_client = await stack.enter_async_context(WsAliasTestClient(sandbox_app))
        ws = await stack.enter_async_context(async_client.websocket_connect("/execute"))

        conn = fc_mod.SandboxConnection(
            session=async_client,
            ws=ws,
            base_url="http://sandbox.local",
        )
        # build fake socat proxy
        socat = fc_mod.SocatProcess(
            process=_DummyProcess(),
            socket_path=Path("/tmp/dummy.sock"),
            vsock_port=1080,
            protocol="TCP",
            remote_host="127.0.0.1",
            remote_port=1080,
        )

        # return the new FirecrackerVM dataclass
        return fc_mod.FirecrackerVM(
            sandbox=sbx,
            firecracker_proc=_DummyProcess(),
            conn=conn,
            socat=socat,
            log_forwarder_task=asyncio.create_task(asyncio.sleep(0)),  # dummy task
        )

    monkeypatch.setattr(fc_mod, "create_firecracker_vm", _fake_create_firecracker_vm)
    yield
    # Clean up all stacks
    for stack in stacks:
        await stack.aclose()
