import asyncio
import logging
import uuid
from typing import Any, Dict, Optional

from .exception import SandboxError
from .gateway_client import GatewayClient
from .sandbox import Sandbox

logger = logging.getLogger(__name__)


class SandboxManager:
    """
    Manages multiple sandbox instances with shared configuration.

    This class allows you to create and manage multiple sandboxes that share
    the same gateway connection and configuration, with automatic cleanup.

    Usage:
        ```python
        async with SandboxManager(additional_env_vars=env_vars) as manager:
            # Create sandboxes with explicit IDs
            sbx_a = await manager.aget(id="a")
            sbx_b = await manager.aget(id="b")
            sbx_c = await manager.aget(id="c")

            # Or create sandboxes with auto-generated IDs
            sbx_auto1 = await manager.aget()
            sbx_auto2 = await manager.aget()

            # Use the sandboxes
            result_a = await sbx_a.arun_code("print('hello from a')")
            result_b = await sbx_b.arun_code("print('hello from b')")

            # All sandboxes automatically cleaned up on exit
        ```

    Synchronous usage:
        ```python
        with SandboxManager(additional_env_vars=env_vars) as manager:
            # Create sandboxes with explicit IDs
            sbx_a = manager.get(id="a")
            sbx_b = manager.get(id="b")

            # Or with auto-generated IDs
            sbx_auto = manager.get()

            result_a = sbx_a.run_code("print('hello from a')")
            result_b = sbx_b.run_code("print('hello from b')")
        ```
    """

    def __init__(
        self,
        *,
        domain: str = "http://localhost:8080",
        api_key: Optional[str] = None,
        additional_env_vars: Optional[dict[str, str]] = None,
        timeout: float = 30.0,
        ping_interval: Optional[float] = 30.0,
        ping_timeout: Optional[float] = 3600.0,
    ) -> None:
        """
        Initialize the SandboxManager.

        Args:
            domain: The gateway domain URL.
            api_key: Optional API key for authentication.
            additional_env_vars: Environment variables to pass to all sandboxes.
            timeout: Timeout for operations in seconds.
            ping_interval: WebSocket ping interval in seconds.
            ping_timeout: WebSocket ping timeout in seconds.
        """
        self._domain = domain
        self._api_key = api_key
        self._additional_env_vars = additional_env_vars or {}
        self._timeout = timeout
        self._ping_interval = ping_interval
        self._ping_timeout = ping_timeout

        self._client: Optional[GatewayClient] = None
        self._sandboxes: Dict[str, Sandbox] = {}
        self._is_active: bool = False
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._counter: int = 0  # Counter for auto-generated IDs

    def _get_loop(self) -> asyncio.AbstractEventLoop:
        """Initializes and returns a running asyncio event loop."""
        try:
            return asyncio.get_running_loop()
        except RuntimeError:
            if self._loop is None:
                self._loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self._loop)
            return self._loop

    def _run_sync(self, coro: Any) -> Any:
        """Runs a coroutine to completion, bridging async and sync contexts."""
        loop = self._get_loop()
        if loop.is_running():
            future = asyncio.run_coroutine_threadsafe(coro, loop)
            return future.result()
        return loop.run_until_complete(coro)

    def _generate_id(self) -> str:
        """Generate a unique ID for a sandbox."""
        self._counter += 1
        return f"auto-{self._counter}-{uuid.uuid4().hex[:8]}"

    def start(self) -> "SandboxManager":
        """
        Initialize the manager and connect to the gateway (synchronous version).

        This method is idempotent and safe to call multiple times.
        """
        if self._is_active:
            return self
        self._run_sync(self._async_start())
        return self

    async def astart(self) -> "SandboxManager":
        """
        Initialize the manager and connect to the gateway (asynchronous version).

        This method is idempotent and safe to call multiple times.
        """
        if self._is_active:
            return self
        await self._async_start()
        return self

    async def _async_start(self) -> None:
        """Asynchronous setup logic."""
        if self._client is None:
            self._client = GatewayClient(
                self._domain,
                api_key=self._api_key,
                timeout=self._timeout,
                ping_interval=self._ping_interval,
                ping_timeout=self._ping_timeout,
            )

        # Start the underlying client (connects websocket)
        await self._client.start()
        self._is_active = True
        logger.info("SandboxManager started and connected to gateway.")

    def close(self, exc_type: Any = None, exc: Any = None, tb: Any = None) -> None:
        """
        Close all sandboxes and disconnect from the gateway (synchronous version).

        This method is idempotent and safe to call multiple times.
        """
        if not self._is_active:
            return
        self._run_sync(self._async_close(exc_type, exc, tb))

    async def aclose(
        self, exc_type: Any = None, exc: Any = None, tb: Any = None
    ) -> None:
        """
        Close all sandboxes and disconnect from the gateway (asynchronous version).

        This method is idempotent and safe to call multiple times.
        """
        if not self._is_active:
            return
        await self._async_close(exc_type, exc, tb)

    async def _async_close(self, exc_type: Any, exc: Any, tb: Any) -> None:
        """Asynchronous teardown logic."""
        # Close all sandboxes
        close_tasks = []
        for sandbox_id, sandbox in self._sandboxes.items():
            logger.info("Closing sandbox %s...", sandbox_id)
            close_tasks.append(sandbox.aclose(exc_type, exc, tb))

        if close_tasks:
            await asyncio.gather(*close_tasks, return_exceptions=True)

        self._sandboxes.clear()

        # Close the gateway client
        if self._client:
            await self._client.close(exc_type, exc, tb)

        self._is_active = False
        logger.info("SandboxManager closed.")

    def get(self, id: Optional[str] = None) -> Sandbox:
        """
        Get or create a sandbox with the given ID (synchronous version).

        Args:
            id: The sandbox identifier. If a sandbox with this ID already exists,
                it will be returned. Otherwise, a new one will be created.
                If not provided, a unique ID will be auto-generated.

        Returns:
            A Sandbox instance.

        Raises:
            SandboxError: If the manager is not started.
        """
        if not self._is_active:
            raise SandboxError(
                "SandboxManager not started. Use 'with SandboxManager() as mgr:' "
                "or call manager.start()."
            )

        # Auto-generate ID if not provided
        if id is None:
            id = self._generate_id()

        return self._run_sync(self._async_get(id))

    async def aget(self, id: Optional[str] = None) -> Sandbox:
        """
        Get or create a sandbox with the given ID (asynchronous version).

        Args:
            id: The sandbox identifier. If a sandbox with this ID already exists,
                it will be returned. Otherwise, a new one will be created.
                If not provided, a unique ID will be auto-generated.

        Returns:
            A Sandbox instance.

        Raises:
            SandboxError: If the manager is not started.
        """
        if not self._is_active:
            raise SandboxError(
                "SandboxManager not started. Use 'async with SandboxManager() as mgr:' "
                "or call await manager.astart()."
            )

        # Auto-generate ID if not provided
        if id is None:
            id = self._generate_id()

        return await self._async_get(id)

    async def _async_get(self, id: str) -> Sandbox:
        """Internal method to get or create a sandbox."""
        if id in self._sandboxes:
            return self._sandboxes[id]

        # Create a new sandbox with a formatted ID
        sandbox_id = f"sbx-{id}"
        sandbox = Sandbox(
            domain=self._domain,
            api_key=self._api_key,
            additional_env_vars=self._additional_env_vars,
            timeout=self._timeout,
            sandbox_id=sandbox_id,
            gateway_client=self._client,  # Share the gateway client
            ping_interval=self._ping_interval,
            ping_timeout=self._ping_timeout,
        )

        # Start the sandbox
        await sandbox.astart()
        self._sandboxes[id] = sandbox
        logger.info("Created and started sandbox with id '%s'", id)

        return sandbox

    def list_sandboxes(self) -> list[str]:
        """
        Get a list of all sandbox IDs currently managed.

        Returns:
            A list of sandbox IDs.
        """
        return list(self._sandboxes.keys())

    def __enter__(self) -> "SandboxManager":
        """Context manager entry point. Starts the manager."""
        return self.start()

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        """Context manager exit point. Closes all sandboxes."""
        self.close(exc_type, exc, tb)
        if self._loop and not self._loop.is_running():
            self._loop.close()
            self._loop = None

    async def __aenter__(self) -> "SandboxManager":
        """Async context manager entry point. Starts the manager."""
        await self._async_start()
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        """Async context manager exit point. Closes all sandboxes."""
        await self._async_close(exc_type, exc, tb)
