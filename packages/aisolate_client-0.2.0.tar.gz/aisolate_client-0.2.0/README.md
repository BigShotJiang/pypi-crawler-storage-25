# aisolate-client

Client library for sandbox environments

## Local Installation

```bash
pip install path/to/aisolate_client-0.2.0-py3-none-any.whl
```

## Usage

```python
# Import the main module
import aisolate.client

# Use the package...
```

## Requirements

- Python 3.10+

## License

Apache License 2.0
