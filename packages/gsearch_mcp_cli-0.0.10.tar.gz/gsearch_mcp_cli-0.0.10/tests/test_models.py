from gsearch_mcp_cli.models import AIOverview, AIResult, FetchResult, OrganicResult, SearchResult, Section, Source


def test_search_result_serialization():
    result = SearchResult(
        query="test",
        results=[
            OrganicResult(
                position=1,
                title="Test",
                url="https://example.com",
                snippet="A test",
                source="example.com",
            )
        ],
    )
    data = result.model_dump()
    assert data["query"] == "test"
    assert len(data["results"]) == 1
    assert data["ai_overview"] is None


def test_search_result_with_ai_overview():
    result = SearchResult(
        query="test",
        ai_overview=AIOverview(
            text="AI generated text",
            sources=[Source(title="Src", url="https://x.com", domain="x.com")],
        ),
        results=[],
    )
    data = result.model_dump()
    assert data["ai_overview"]["text"] == "AI generated text"
    assert len(data["ai_overview"]["sources"]) == 1


def test_ai_result_with_sections():
    result = AIResult(
        query="test",
        synthesis="Test synthesis",
        sections=[Section(heading="Intro", content="Content", items=["item1"])],
        sources=[Source(title="Src", url="https://example.com", domain="example.com")],
    )
    json_str = result.model_dump_json()
    assert "Test synthesis" in json_str


def test_fetch_result():
    result = FetchResult(url="https://example.com", title="Example", content="# Hello", word_count=1)
    assert result.metadata == {}


def test_source_default_snippet():
    s = Source(title="T", url="https://x.com", domain="x.com")
    assert s.snippet == ""


def test_search_result_defaults():
    result = SearchResult(query="q", results=[])
    assert result.people_also_ask == []
    assert result.related_searches == []
    assert result.ai_overview is None
