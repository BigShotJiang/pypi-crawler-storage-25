from gsearch_mcp_cli.exceptions import CDPConnectionError, SearchBlockedError, SSRFBlockedError
from gsearch_mcp_cli.mcp.server import sanitize_error


def test_sanitize_error_strips_paths():
    err = CDPConnectionError("Failed at /Users/jacob/.gsearch-mcp-cli/chrome-profile on port 9222 (pid 12345)")
    sanitized = sanitize_error(err)
    assert "/Users/" not in sanitized
    assert "12345" not in sanitized


def test_sanitize_error_strips_port():
    err = CDPConnectionError("Cannot connect to port 9345")
    sanitized = sanitize_error(err)
    assert "9345" not in sanitized


def test_sanitize_error_preserves_message():
    err = SearchBlockedError("Google blocked the search — unusual traffic detected")
    sanitized = sanitize_error(err)
    assert "blocked" in sanitized.lower()
    assert "unusual traffic" in sanitized.lower()


def test_sanitize_error_ssrf():
    err = SSRFBlockedError("Blocked host: localhost")
    sanitized = sanitize_error(err)
    assert "Blocked" in sanitized


def test_mcp_server_has_tools():
    from gsearch_mcp_cli.mcp.server import mcp

    mcp._tool_manager._tools if hasattr(mcp, "_tool_manager") else {}
    # Just verify the server object exists and is configured
    assert mcp.name == "gsearch-mcp"
