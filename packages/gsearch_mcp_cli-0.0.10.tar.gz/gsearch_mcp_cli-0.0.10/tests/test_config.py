import pytest

from gsearch_mcp_cli.config import Config
from gsearch_mcp_cli.exceptions import ConfigError


def test_config_defaults(tmp_config_dir):
    cfg = Config(config_dir=tmp_config_dir)
    assert cfg.get("browser") == "auto"
    assert cfg.get("rate_limit") == 2.0
    assert cfg.get("max_tabs") == 5
    assert cfg.get("timeout") == 30
    assert cfg.get("lang") == "en"
    assert cfg.get("region") is None
    assert cfg.get("max_results") == 10
    assert cfg.get("json_output") is False


def test_config_set_and_get(tmp_config_dir):
    cfg = Config(config_dir=tmp_config_dir)
    cfg.set("browser", "brave")
    assert cfg.get("browser") == "brave"
    cfg2 = Config(config_dir=tmp_config_dir)
    assert cfg2.get("browser") == "brave"


def test_config_set_numeric(tmp_config_dir):
    cfg = Config(config_dir=tmp_config_dir)
    cfg.set("rate_limit", "1.5")
    assert cfg.get("rate_limit") == 1.5
    cfg.set("max_tabs", "8")
    assert cfg.get("max_tabs") == 8


def test_config_show(tmp_config_dir):
    cfg = Config(config_dir=tmp_config_dir)
    cfg.set("lang", "fr")
    all_cfg = cfg.show()
    assert all_cfg["lang"] == "fr"
    assert all_cfg["browser"] == "auto"


def test_config_invalid_key_raises(tmp_config_dir):
    cfg = Config(config_dir=tmp_config_dir)
    with pytest.raises(ConfigError):
        cfg.set("invalid_key", "value")


def test_config_get_invalid_key_raises(tmp_config_dir):
    cfg = Config(config_dir=tmp_config_dir)
    with pytest.raises(ConfigError):
        cfg.get("nonexistent")


def test_config_corrupt_json_falls_back_to_defaults(tmp_config_dir):
    config_file = tmp_config_dir / "config.json"
    config_file.write_text("{corrupt json!!")
    cfg = Config(config_dir=tmp_config_dir)
    assert cfg.get("browser") == "auto"
