import pytest

from gsearch_mcp_cli import shared


@pytest.fixture(scope="module")
async def browser():
    """Shared browser for integration tests."""
    await shared._get_browser()
    yield
    await shared.shutdown()


@pytest.mark.integration
@pytest.mark.asyncio
async def test_full_search():
    """End-to-end: search Google and get results."""
    try:
        result = await shared.search("what is python programming")
        assert result.query == "what is python programming"
        assert len(result.results) > 0
        assert result.results[0].title
        assert result.results[0].url.startswith("http")
    finally:
        await shared.shutdown()


@pytest.mark.integration
@pytest.mark.asyncio
async def test_full_ai_mode():
    """End-to-end: Google AI Mode search."""
    try:
        result = await shared.ai_search("what is docker")
        assert result.query == "what is docker"
        assert len(result.synthesis) > 50
    finally:
        await shared.shutdown()


@pytest.mark.integration
@pytest.mark.asyncio
async def test_full_fetch():
    """End-to-end: fetch a page and convert to text."""
    try:
        result = await shared.fetch("https://example.com", format="text", use_browser="never")
        assert "Example" in result.content or "example" in result.content.lower()
        assert result.word_count > 0
    finally:
        await shared.shutdown()
