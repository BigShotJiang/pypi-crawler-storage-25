class GSearchError(Exception):
    """Base exception for gsearch-mcp-cli."""


class BrowserNotFoundError(GSearchError):
    """No supported Chromium browser found."""


class CDPConnectionError(GSearchError):
    """Failed to connect to Chrome via CDP."""


class ChromeLaunchError(CDPConnectionError):
    """Chrome process exited during launch."""

    def __init__(self, message: str, exit_code: int = -1, stderr: str = ""):
        self.exit_code = exit_code
        self.stderr = stderr
        detail = message
        if stderr:
            detail += f"\nChrome stderr: {stderr}"
        super().__init__(detail)


class SearchBlockedError(GSearchError):
    """Google blocked the search (unusual traffic)."""


class ProfileWarmupError(GSearchError):
    """Profile warmup failed."""


class FetchError(GSearchError):
    """Failed to fetch URL."""


class SSRFBlockedError(FetchError):
    """URL blocked for security (SSRF prevention)."""


class GSearchTimeoutError(GSearchError):
    """Operation timed out."""


class RateLimitError(GSearchError):
    """Rate limit exceeded."""


class PortExhaustedError(GSearchError):
    """All CDP ports in range are occupied."""


class ExtractionError(GSearchError):
    """Failed to extract results from DOM (selectors may be outdated)."""


class ConfigError(GSearchError):
    """Invalid configuration."""
