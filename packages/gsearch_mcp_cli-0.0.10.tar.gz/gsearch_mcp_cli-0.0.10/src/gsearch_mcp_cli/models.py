from pydantic import BaseModel, field_validator


class Source(BaseModel):
    title: str
    url: str
    snippet: str = ""
    domain: str


class AIOverview(BaseModel):
    text: str
    sources: list[Source] = []


class OrganicResult(BaseModel):
    position: int
    title: str
    url: str
    snippet: str
    source: str

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        if "google.com" in v.lower() and "google.com/url" not in v.lower():
            raise ValueError(f"Excluded internal Google URL: {v}")
        if not v.startswith("http"):
            raise ValueError(f"Invalid protocol in URL: {v}")
        return v


class SearchResult(BaseModel):
    query: str
    ai_overview: AIOverview | None = None
    results: list[OrganicResult] = []
    people_also_ask: list[str] = []
    related_searches: list[str] = []


class Section(BaseModel):
    heading: str
    content: str
    items: list[str] = []


class AIResult(BaseModel):
    query: str
    synthesis: str
    sections: list[Section] = []
    sources: list[Source] = []


class FetchResult(BaseModel):
    url: str
    title: str
    content: str
    word_count: int
    metadata: dict = {}
