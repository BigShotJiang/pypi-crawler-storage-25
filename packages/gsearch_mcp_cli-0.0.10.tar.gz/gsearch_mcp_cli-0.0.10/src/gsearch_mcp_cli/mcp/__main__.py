from gsearch_mcp_cli.mcp import run_server

if __name__ == "__main__":
    run_server()
