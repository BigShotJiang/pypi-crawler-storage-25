from .server import mcp


def run_server():
    mcp.run()
