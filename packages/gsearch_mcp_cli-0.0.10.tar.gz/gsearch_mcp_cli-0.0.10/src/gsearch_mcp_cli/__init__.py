from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("gsearch-mcp-cli")
except PackageNotFoundError:
    __version__ = "0.0.10"  # Keep in sync with pyproject.toml
