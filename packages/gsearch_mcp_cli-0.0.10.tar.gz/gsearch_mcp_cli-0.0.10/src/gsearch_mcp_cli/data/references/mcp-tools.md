# MCP Tools Reference

## gsearch_search

Search Google with AI Overview and organic results.

**Parameters:**
| Name | Type | Default | Description |
|------|------|---------|-------------|
| query | str | (required) | Search query |
| max_results | int | 10 | Max organic results |
| include_ai | bool | True | Include AI Overview |
| language | str | "en" | Search language (hl param) |
| region | str | None | Search region (gl param) |
| timeout_seconds | int | 30 | Operation timeout |

**Returns:** SearchResult with query, ai_overview, results[], people_also_ask[], related_searches[]

## gsearch_ai

Google AI Mode search (equivalent to g.ai).

**Parameters:**
| Name | Type | Default | Description |
|------|------|---------|-------------|
| query | str | (required) | Search query |
| language | str | "en" | Language |
| timeout_seconds | int | 30 | Operation timeout |

**Returns:** AIResult with query, synthesis, sections[], sources[]

## gsearch_fetch

Fetch URL and convert to clean Markdown.

**Parameters:**
| Name | Type | Default | Description |
|------|------|---------|-------------|
| url | str | (required) | URL to fetch (https:// only) |
| format | str | "md" | Output format: "md", "text", "raw_html" |
| use_browser | str | "auto" | "auto", "always", or "never" |
| timeout_seconds | int | 30 | Request timeout |

**Returns:** FetchResult with url, title, content, word_count, metadata
