import asyncio
import json
import logging
import os
import platform
import re
import subprocess
from pathlib import Path

try:
    import fcntl
except ImportError:
    fcntl = None  # type: ignore

from contextlib import contextmanager

import httpx

from gsearch_mcp_cli.constants import (
    CHROME_BASE_FLAGS,
    CHROME_PLATFORM_FLAGS,
    CHROME_PROFILE_DIR,
    CONFIG_DIR,
    PORT_MAP_FILE,
    TIMEOUT_CHROME_LAUNCH,
    get_browser_candidates,
)
from gsearch_mcp_cli.exceptions import BrowserNotFoundError, CDPConnectionError, ChromeLaunchError

logger = logging.getLogger(__name__)


def find_browser(preference: str = "auto") -> str:
    """Find a Chromium-based browser binary.

    Args:
        preference: "auto" for first found, or browser name like "chrome", "brave", "edge"

    Returns:
        Full path to browser binary.

    Raises:
        BrowserNotFoundError if no browser found.
    """
    candidates = get_browser_candidates()

    if preference != "auto":
        pref_lower = preference.lower()
        for name, path in candidates:
            if pref_lower in name.lower() and Path(path).exists():
                return path
        raise BrowserNotFoundError(
            f"Browser '{preference}' not found. Available browsers: "
            + ", ".join(name for name, path in candidates if Path(path).exists())
            + ". Install a Chromium-based browser or set browser=auto."
        )

    for name, path in candidates:
        if Path(path).exists():
            return path

    raise BrowserNotFoundError(
        "No Chromium-based browser found. Install one of: "
        "Google Chrome, Brave, Microsoft Edge, Chromium, Vivaldi, Opera."
    )


def build_chrome_args(browser_path: str, profile_dir: str, extra_flags: list[str] | None = None) -> list[str]:
    """Build Chrome launch arguments."""
    args = [browser_path]
    args.append("--remote-debugging-port=0")
    args.append(f"--user-data-dir={profile_dir}")
    args.extend(CHROME_BASE_FLAGS)

    system = platform.system()
    if system in CHROME_PLATFORM_FLAGS:
        args.extend(CHROME_PLATFORM_FLAGS[system])

    if extra_flags:
        args.extend(extra_flags)

    args.append("about:blank")
    return args


def parse_port_from_stderr(line: str) -> int | None:
    """Parse CDP port from Chrome's stderr output.

    Chrome prints: DevTools listening on ws://127.0.0.1:<PORT>/devtools/browser/<id>
    """
    match = re.search(r"DevTools listening on ws://127\.0\.0\.1:(\d+)/", line)
    if match:
        return int(match.group(1))
    return None


async def connect_existing() -> tuple[None, int] | None:
    """Try to connect to an already-running Chrome from the port map.

    Returns (None, port) if a live instance is found, or None if no live instance.
    The None proc signals that we didn't launch Chrome (caller must not kill it).
    """
    port_map = _read_port_map()
    for port_str, info in port_map.items():
        port = int(port_str)
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"http://localhost:{port}/json/version", timeout=2)
                if resp.status_code == 200:
                    logger.debug(f"Reusing existing Chrome on port {port}")
                    return None, port
        except Exception:
            continue
    return None


def _drain_stderr(proc: subprocess.Popen, max_chars: int = 500) -> str:
    """Read remaining stderr from a dead process (best-effort, non-blocking)."""
    try:
        lines = []
        while True:
            line = proc.stderr.readline()
            if not line:
                break
            lines.append(line.rstrip())
        return "\n".join(lines)[-max_chars:]
    except Exception:
        return ""


def _clear_profile_locks(profile_dir: str | Path) -> bool:
    """Remove stale Chrome lock files. Returns True if any were removed."""
    removed = False
    for name in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
        p = Path(profile_dir) / name
        if p.exists():
            try:
                p.unlink()
                removed = True
                logger.debug(f"Removed stale lock file: {p}")
            except OSError:
                pass
    return removed


@contextmanager
def _port_map_lock():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lock_path = CONFIG_DIR / "chrome-port-map.lock"
    with open(lock_path, "w") as f:
        if fcntl:
            try:
                fcntl.flock(f, fcntl.LOCK_EX)
                yield
            finally:
                fcntl.flock(f, fcntl.LOCK_UN)
        else:
            yield


async def connect_or_launch(
    profile_dir: str | Path | None = None,
    browser_path: str | None = None,
) -> tuple[subprocess.Popen | None, int]:
    """Try reuse, then launch, with cross-process serialization.

    Uses an exclusive file lock so only one process at a time enters
    the check-then-launch critical section.  Other processes that
    block on the lock will find Chrome already running when they
    acquire it.  If launch still fails (exit 1/21), an exponential
    backoff loop polls ``connect_existing`` for up to ~7 s.
    """
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    launch_lock_path = CONFIG_DIR / "chrome-launch.lock"

    # --- Lock-protected critical section ----------------------------------
    with open(launch_lock_path, "w") as lock_fd:
        if fcntl:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)
        try:
            # Re-check after acquiring the lock – another process may have
            # launched Chrome while we were waiting.
            existing = await connect_existing()
            if existing is not None:
                return existing

            try:
                return await launch_chrome(profile_dir, browser_path)
            except ChromeLaunchError as e:
                if e.exit_code not in (1, 21):
                    raise
                logger.warning(
                    "Chrome launch failed with %s inside launch lock, will poll for peer Chrome...",
                    e.exit_code,
                )
        finally:
            if fcntl:
                fcntl.flock(lock_fd, fcntl.LOCK_UN)

    # --- Exponential-backoff fallback (outside lock) ----------------------
    backoff_delays = [1, 2, 4]
    for delay in backoff_delays:
        await asyncio.sleep(delay)
        existing = await connect_existing()
        if existing is not None:
            logger.info("Connected to peer Chrome after %ss backoff", delay)
            return existing

    raise ChromeLaunchError(
        "Chrome launch failed and no peer Chrome appeared after backoff",
        exit_code=21,
        stderr="",
    )


async def launch_chrome(
    profile_dir: str | Path | None = None,
    browser_path: str | None = None,
    _retried: bool = False,
) -> tuple[subprocess.Popen, int]:
    """Launch headless Chrome and return (process, port).

    Uses --remote-debugging-port=0 so the OS assigns a free port.
    Reads the actual port from Chrome's stderr.

    On profile-lock failures (exit codes 1, 21), clears stale lock files
    and retries once.
    """
    if profile_dir is None:
        profile_dir = str(CHROME_PROFILE_DIR)
    if browser_path is None:
        browser_path = find_browser()

    Path(str(profile_dir)).mkdir(parents=True, exist_ok=True)

    args = build_chrome_args(browser_path, str(profile_dir))

    proc = subprocess.Popen(
        args,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
    )

    port = None
    deadline = asyncio.get_event_loop().time() + TIMEOUT_CHROME_LAUNCH

    while asyncio.get_event_loop().time() < deadline:
        line = proc.stderr.readline()
        if not line:
            if proc.poll() is not None:
                stderr_tail = _drain_stderr(proc)
                # Retry once on profile-lock-likely exit codes
                if not _retried and proc.returncode in (1, 21):
                    _clear_profile_locks(profile_dir)
                    logger.info(f"Chrome exited with code {proc.returncode}, cleared stale locks, retrying")
                    return await launch_chrome(profile_dir, browser_path, _retried=True)
                raise ChromeLaunchError(
                    f"Chrome exited with code {proc.returncode}",
                    exit_code=proc.returncode,
                    stderr=stderr_tail,
                )
            await asyncio.sleep(0.1)
            continue
        port = parse_port_from_stderr(line)
        if port:
            break

    if port is None:
        proc.terminate()
        raise CDPConnectionError("Failed to read CDP port from Chrome stderr")

    async with httpx.AsyncClient() as client:
        for _ in range(int(TIMEOUT_CHROME_LAUNCH * 2)):
            try:
                resp = await client.get(f"http://localhost:{port}/json/version", timeout=1)
                if resp.status_code == 200:
                    _write_port_map(port, proc.pid)
                    return proc, port
            except httpx.ConnectError:
                await asyncio.sleep(0.5)

    proc.terminate()
    raise CDPConnectionError("CDP endpoint never became ready")


async def ensure_browser(port: int) -> bool:
    """Check if Chrome is responsive on the given port."""
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.get(f"http://localhost:{port}/json/version", timeout=2)
            return resp.status_code == 200
    except Exception:
        return False


def shutdown_chrome(proc: subprocess.Popen, port: int | None = None) -> None:
    """Gracefully shutdown Chrome. Try terminate, then kill."""
    if proc.poll() is not None:
        if port:
            _remove_port_map(port)
        return

    try:
        proc.terminate()
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=3)

    if port:
        _remove_port_map(port)


def _read_port_map_locked() -> dict:
    """Read without locking (assumes caller holds the lock)."""
    if not PORT_MAP_FILE.exists():
        return {}
    try:
        data = json.loads(PORT_MAP_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}

    alive = {}
    for port_str, info in data.items():
        pid = info.get("pid")
        if pid and _is_process_alive(pid):
            alive[port_str] = info

    if alive != data:
        PORT_MAP_FILE.write_text(json.dumps(alive, indent=2))

    return alive


def _read_port_map() -> dict:
    """Read the port map file, pruning dead entries."""
    with _port_map_lock():
        return _read_port_map_locked()


def _write_port_map(port: int, pid: int) -> None:
    """Record a port mapping."""
    with _port_map_lock():
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        data = _read_port_map_locked()
        data[str(port)] = {"pid": pid}
        PORT_MAP_FILE.write_text(json.dumps(data, indent=2))


def _remove_port_map(port: int) -> None:
    """Remove a port mapping."""
    with _port_map_lock():
        data = _read_port_map_locked()
        data.pop(str(port), None)
        if data:
            PORT_MAP_FILE.write_text(json.dumps(data, indent=2))
        elif PORT_MAP_FILE.exists():
            PORT_MAP_FILE.unlink()


def _is_process_alive(pid: int) -> bool:
    """Check if a process is still running."""
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False
