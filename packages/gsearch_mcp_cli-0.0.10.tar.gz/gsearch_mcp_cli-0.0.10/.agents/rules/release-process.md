---
trigger: always_on
---

This project will include a GitHub action that will check the diversion of the TOML file, the init file, and the skill.md are all aligned. Otherwise, jobs will fail. Also, we do not publish directly. The GitHub action will take care of it when we create a new tag and release.
Also, there is a rough lint check that will also fail the push to PyPI if it's not validated. Always ensure to do everything before releasing and pushing. 