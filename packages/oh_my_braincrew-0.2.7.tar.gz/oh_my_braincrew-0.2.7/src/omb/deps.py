# BCRW-PLAN-000080: Dependency wiring and CLI registration
"""Shared dependency factories consumed by CLI command groups.

Centralises construction of stateful singletons (HookHandler, session manager)
so that command modules can import them lazily without circular dependencies.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from omb.services.paths import resolve_project_root

if TYPE_CHECKING:
    from omb.hook.handler import HookHandler


def _project_root() -> str:
    """Return the project root directory as a string.

    Delegates to resolve_project_root() for centralized resolution (RPR-044).
    No caching — re-resolves on every call so tests can monkeypatch freely.
    """
    return str(resolve_project_root())


def get_handler() -> HookHandler:
    """Return a fully-wired HookHandler instance.

    When pipeline.enabled is True in .omb/config.json, constructs the full
    session manager chain:
        PipelineStorage → PipelineResolver → SessionHandler → SessionManager

    The concrete SessionManager.handle(event, input, status) is adapted to the
    handle_event(hook_input) protocol expected by HookHandler via a thin lambda
    adapter.  If pipeline is disabled or config cannot be loaded, returns a bare
    HookHandler with no session manager.

    All heavy imports are inside this function body (lazy imports, RPR-021).
    """
    # Lazy imports for startup performance (RPR-021).
    import re

    from omb.hook.handler import HookHandler
    from omb.hook.types import Decision, EventType, HookInput, HookOutput
    from omb.hook.utils import parse_result_status_with_session
    from omb.services.config import load_config

    pipeline_session_re = re.compile(r"\d{12}-[a-z0-9]{6}")

    root = Path(_project_root())
    cfg = load_config(root)

    if not cfg.pipeline.enabled:
        return HookHandler()

    from omb.pipeline.resolver import PipelineResolver
    from omb.pipeline.storage import PipelineStorage
    from omb.pipeline.types import ResultStatus
    from omb.session.handler import SessionHandler
    from omb.session.manager import SessionManager as ConcreteSessionManager

    storage = PipelineStorage(root)
    resolver = PipelineResolver(storage)
    session_handler = SessionHandler(storage)
    concrete_manager = ConcreteSessionManager(resolver=resolver, handler=session_handler)

    # Map skill completion signals to pipeline result statuses.
    skill_status_map: dict[str, ResultStatus] = {
        "DONE": ResultStatus.APPROVED,
        "DONE_WITH_CONCERNS": ResultStatus.APPROVED,
        "APPROVED": ResultStatus.APPROVED,
        "NEEDS_REVISION": ResultStatus.REJECT,
        "REJECT": ResultStatus.REJECT,
        "FAILED": ResultStatus.FAILED,
        "NEEDS_CONTEXT": ResultStatus.NONE,
        "BLOCKED": ResultStatus.NONE,
    }

    class _SessionManagerAdapter:
        """Adapter from handle_event(hook_input) → concrete handle(event, input, status)."""

        def handle_event(self, event_input: HookInput) -> HookOutput:
            try:
                event = EventType(event_input.hook_event_name)
            except ValueError:
                return HookOutput()

            xml_pipeline_id, xml_task_name, raw_status = parse_result_status_with_session(
                event_input.last_assistant_message,
            )

            # Capture original Claude UUID before XML override
            original_claude_uuid = event_input.session_id or ""

            # Validate XML session_id format before trusting it
            if xml_pipeline_id and not pipeline_session_re.fullmatch(xml_pipeline_id):
                xml_pipeline_id = None  # reject malformed session_id

            # Auto-approve: if parsing failed on a Stop event and an active
            # pipeline has a running task, treat the missing <omb> marker as
            # implicit DONE.  Previously this path delegated to omb-fallback-
            # decide via a two-BLOCK chain, but Claude Code ignores the second
            # BLOCK when stop_hook_active=True, causing the pipeline to freeze.
            # Inline auto-approve eliminates the two-BLOCK dependency.
            if raw_status is None and event == EventType.STOP:
                infer_id = event_input.session_id or ""
                if infer_id:
                    pipeline_state = (
                        resolver.resolve(infer_id)
                        or resolver.resolve_by_claude_session(infer_id)
                    )
                    if pipeline_state is not None:
                        active = pipeline_state.active_task()
                        if active and active.status.value == "active":
                            inferred_status = ResultStatus.APPROVED
                            inferred_input = event_input.model_copy(
                                update={"session_id": pipeline_state.session_id},
                            )
                            inferred_uuid = original_claude_uuid or infer_id
                            output = concrete_manager.handle(
                                event=event,
                                input=inferred_input,
                                status=inferred_status,
                                original_claude_uuid=(
                                    inferred_uuid
                                    if pipeline_state.session_id != infer_id
                                    else None
                                ),
                            )
                            # When stop_hook_active=True, Claude Code may
                            # ignore BLOCK.  Downgrade to ALLOW so the state
                            # update is still persisted; the next
                            # UserPromptSubmit will inject the active task.
                            if (
                                event_input.stop_hook_active
                                and output.decision == Decision.BLOCK
                            ):
                                output.decision = Decision.ALLOW
                                if output.message:
                                    output.message = (
                                        f"[Pipeline advanced] Next: {output.message}"
                                    )
                            return output

            # Normal path: map to ResultStatus
            if raw_status in skill_status_map:
                status = skill_status_map[raw_status]
            elif raw_status:
                try:
                    status = ResultStatus(raw_status)
                except ValueError:
                    status = ResultStatus.NONE
            else:
                status = ResultStatus.NONE

            # Guard: if the <omb> marker names a task that differs from the
            # currently active task, the omb advance CLI already advanced past
            # it — skip to prevent double advance.
            if xml_task_name:
                guard_id = xml_pipeline_id or event_input.session_id or ""
                if guard_id:
                    guard_state = (
                        resolver.resolve(guard_id)
                        or resolver.resolve_by_claude_session(guard_id)
                    )
                    if guard_state:
                        guard_active = guard_state.active_task()
                        if guard_active and guard_active.task_name != xml_task_name:
                            return HookOutput()

            # When skill output includes a pipeline session_id in the XML marker,
            # use it to override the session_id so direct resolve hits in SessionManager.
            if xml_pipeline_id:
                event_input = event_input.model_copy(
                    update={"session_id": xml_pipeline_id},
                )

            return concrete_manager.handle(
                event=event,
                input=event_input,
                status=status,
                original_claude_uuid=original_claude_uuid if xml_pipeline_id else None,
            )

    return HookHandler(session_manager=_SessionManagerAdapter())
