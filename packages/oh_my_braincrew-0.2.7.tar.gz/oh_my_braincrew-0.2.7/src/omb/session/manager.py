# BCRW-PLAN-000080: Session manager
"""Session manager — resolves a session to its active pipeline and routes to handler.

Provides the concrete ``SessionManager`` class that bridges Claude Code hook
events to the Hotl pipeline state machine.  The handler dependency is injected
to avoid circular imports with ``session/handler.py`` (Task 11), which does not
exist yet at the time this module is written.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from omb.hook.types import EventType, HookInput, HookOutput

if TYPE_CHECKING:
    # SessionHandler is defined in session/handler.py (Task 11).
    # Using TYPE_CHECKING avoids a circular import at runtime.
    from omb.pipeline.resolver import PipelineResolver
    from omb.pipeline.types import ResultStatus
    from omb.session.handler import SessionHandler


class SessionManager:
    """Routes Claude Code hook events to the active pipeline handler.

    Resolves the session ID from the incoming ``HookInput`` (falling back to
    the ``CLAUDE_SESSION_ID`` environment variable when the payload field is
    empty).  If no active pipeline is found for that session, returns a
    passthrough ``HookOutput`` with no side-effects.
    """

    def __init__(self, resolver: PipelineResolver, handler: SessionHandler) -> None:
        self._resolver = resolver
        self._handler = handler

    def handle(
        self,
        event: EventType,
        input: HookInput,
        status: ResultStatus,
        original_claude_uuid: str | None = None,
    ) -> HookOutput:
        """Dispatch *event* to the active pipeline handler for this session.

        Args:
            event: The Claude Code hook event type.
            input: The parsed hook payload from Claude Code.
            status: The result status parsed from the last assistant message.
            original_claude_uuid: The original Claude session UUID before any
                XML session_id override.  Supplied by the adapter when a valid
                XML pipeline session_id was present so that the handler can
                store it on ``PipelineState.claude_session_id``.

        Returns:
            ``HookOutput`` from the handler, or a default passthrough output
            when no session or active pipeline is found.
        """
        # Prefer session_id from the input payload; fall back to env var.
        session_id = input.session_id or os.environ.get("CLAUDE_SESSION_ID", "")
        if not session_id:
            return HookOutput()

        state = self._resolver.resolve(session_id)
        if state is None:
            state = self._resolver.resolve_by_claude_session(session_id)
        if state is None:
            return HookOutput()

        # Bind Claude UUID to pipeline state for future Stop hook resolution.
        # Persisted via handler.handle() → _handle_stop() → _advance() or
        # _handle_non_approved(), which always call storage.save(state).
        # Two sources: (1) original_claude_uuid from XML override path,
        #              (2) session_id itself when it's a Claude UUID (non-XML path).
        claude_uuid = original_claude_uuid or (
            session_id if session_id != state.session_id else None
        )
        if claude_uuid and state.claude_session_id is None:
            state.claude_session_id = claude_uuid

        return self._handler.handle(state, event, input, status)
