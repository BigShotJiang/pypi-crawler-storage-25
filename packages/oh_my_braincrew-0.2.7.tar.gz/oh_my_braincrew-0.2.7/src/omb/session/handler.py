# BCRW-PLAN-000080: Session handler — task_handler, decide, deque
"""Session handler — orchestrates pipeline step transitions on hook events.

Implements the DECIDE logic for STOP events (RPR-032):
  - APPROVED  → _advance: mark current task done, activate next, run it
  - REJECT / FAILED / NONE → _handle_non_approved: delegate to reject module,
      then activate the recovery task that reject inserts at the queue front

USER_PROMPT_SUBMIT and SESSION_START: return the active task's run instruction
without mutating state (inject-only paths).

Circular dependencies with session/runner and session/reject are avoided via
module-level lazy-import functions (_run_task, _handle_reject) that are imported
inside methods at call time.  Tests patch these module-level names.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from omb.hook.types import Decision, EventType, HookInput, HookOutput
from omb.pipeline.types import (
    PipelineState,
    PipelineStatus,
    ResultStatus,
    TaskState,
    TaskStatus,
    TaskType,
)

if TYPE_CHECKING:
    from omb.pipeline.storage import PipelineStorage
    from omb.services.notification import SlackConfig

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lazy-import bridge functions — patch these in tests, not internal modules
# ---------------------------------------------------------------------------


def _run_task(_state: PipelineState, task: TaskState) -> HookOutput:
    """Lazy wrapper around session.runner.run_task to avoid circular imports."""
    from omb.session.runner import run_task  # noqa: PLC0415

    return run_task(task)


def _handle_reject(
    state: PipelineState, status: ResultStatus, hook_input: HookInput
) -> TaskState | None:
    """Lazy wrapper around session.reject.handle_reject to avoid circular imports."""
    from omb.session.reject import handle_reject  # noqa: PLC0415

    return handle_reject(state, status, hook_input)


# ---------------------------------------------------------------------------
# Notification helper
# ---------------------------------------------------------------------------


def _notify(config: SlackConfig | None, text: str) -> None:
    """Fire-and-forget Slack notification; never raises."""
    try:
        from omb.services.notification import notify_sync  # noqa: PLC0415

        notify_sync(config, text)
    except Exception:  # noqa: BLE001
        logger.warning("[handler] notification failed (suppressed)")


# ---------------------------------------------------------------------------
# Logging helper
# ---------------------------------------------------------------------------


def _log_step(session_id: str, entry: dict[str, Any]) -> None:
    """Append a JSON-line step record to .omb/logs/{session_id}.log."""
    try:
        log_dir = os.path.join(os.environ.get("OMB_PROJECT_ROOT", "."), ".omb", "logs")
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(log_dir, f"{session_id}.log")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:  # noqa: BLE001
        logger.warning("[handler] failed to write step log (suppressed)")


# ---------------------------------------------------------------------------
# SessionHandler
# ---------------------------------------------------------------------------


class SessionHandler:
    """Drives pipeline state transitions in response to Claude Code hook events.

    Injected into ``SessionManager`` to process events once a pipeline state
    has been resolved for the current session.
    """

    def __init__(
        self,
        storage: PipelineStorage,
        notification_config: SlackConfig | None = None,
    ) -> None:
        self._storage = storage
        self._notification_config = notification_config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def handle(
        self,
        state: PipelineState,
        event: EventType,
        input: HookInput,  # noqa: A002
        status: ResultStatus,
    ) -> HookOutput:
        """Dispatch the event to the appropriate internal handler.

        Args:
            state: The active pipeline state (mutated in-place for STOP events).
            event: The Claude Code hook event type.
            input: The parsed hook payload.
            status: The result status parsed from the last assistant message.

        Returns:
            HookOutput with message containing the next run instruction,
            or an empty HookOutput when no action is required.
        """
        if event == EventType.STOP:
            return self._handle_stop(state, input, status)

        if event in {EventType.USER_PROMPT_SUBMIT, EventType.SESSION_START}:
            return self._inject_active_task(state)

        # All other events: passthrough
        return HookOutput()

    # ------------------------------------------------------------------
    # STOP path
    # ------------------------------------------------------------------

    def _handle_stop(
        self,
        state: PipelineState,
        input: HookInput,  # noqa: A002
        status: ResultStatus,
    ) -> HookOutput:
        """Process a STOP event: update task result, then DECIDE."""
        active = state.active_task()
        if active is not None:
            # Task is PENDING — this is an activation request, not a completion.
            # Just activate it and return its run instruction without advancing.
            if active.status == TaskStatus.PENDING:
                active.status = TaskStatus.ACTIVE
                self._storage.save(state)
                return _run_task(state, active)

            # USER_PROMPT and ASK_USER tasks auto-approve on any STOP — their
            # purpose is to collect input, not produce a specific outcome.
            if active.task_type in {TaskType.USER_PROMPT, TaskType.ASK_USER}:  # BCRW-PLAN-000085
                status = ResultStatus.APPROVED
            active.result = status
            # Mark the task done only on APPROVED; other statuses keep the task
            # as active until the reject handler re-queues or stalls it.
            if status == ResultStatus.APPROVED:
                active.status = TaskStatus.DONE

        if status == ResultStatus.APPROVED:
            return self._advance(state)
        return self._handle_non_approved(state, status, input)

    def _advance(self, state: PipelineState) -> HookOutput:
        """Activate the next ready task and return its run instruction.

        If no ready task remains, the pipeline is marked COMPLETED.
        Uses next_ready_tasks() so depends_on constraints are respected.
        """
        ready = state.next_ready_tasks()

        if not ready:
            # Pipeline is complete — no more tasks
            state.status = PipelineStatus.COMPLETED
            self._storage.save(state)

            _notify(
                self._notification_config,
                f"Pipeline '{state.name}' completed ({state.session_id})",
            )
            _log_step(
                state.session_id,
                {
                    "ts": datetime.now(tz=UTC).isoformat(),
                    "event": "pipeline_complete",
                    "session": state.session_id,
                },
            )
            logger.info("[handler] pipeline '%s' completed", state.name)
            return HookOutput(message=f"Pipeline '{state.name}' is now complete.")

        task = ready[0]
        task.status = TaskStatus.ACTIVE
        idx = state.tasks.index(task)
        state.current_task = idx  # keep current_task updated for compat

        self._storage.save(state)

        _notify(
            self._notification_config,
            f"[{state.name}] step {idx + 1}: {task.task_name}",
        )
        _log_step(
            state.session_id,
            {
                "ts": datetime.now(tz=UTC).isoformat(),
                "event": "task_activated",
                "task": task.task_name,
                "index": idx,
                "session": state.session_id,
            },
        )
        logger.info("[handler] activating task '%s' (index %d)", task.task_name, idx)
        return _run_task(state, task)

    def _handle_non_approved(
        self,
        state: PipelineState,
        status: ResultStatus,
        input: HookInput,  # noqa: A002
    ) -> HookOutput:
        """Handle REJECT / FAILED / NONE by delegating to the reject module.

        The reject module may append a recovery task (with depends_on=[]) to
        the task list.  We use next_ready_tasks() to find it, so depends_on
        constraints are respected.  State is saved exactly once per branch.
        """
        _handle_reject(state, status, input)

        # Look for any ready task (reject handler may have appended one with depends_on=[])
        ready = state.next_ready_tasks()

        if not ready:
            # No recovery path available — stall the pipeline
            state.status = PipelineStatus.STALLED
            self._storage.save(state)

            _notify(
                self._notification_config,
                f"[{state.name}] pipeline stalled after {status} — manual intervention needed",
            )
            _log_step(
                state.session_id,
                {
                    "ts": datetime.now(tz=UTC).isoformat(),
                    "event": "pipeline_stalled",
                    "status": str(status),
                    "session": state.session_id,
                },
            )
            logger.warning("[handler] pipeline '%s' stalled (status=%s)", state.name, status)
            return HookOutput(
                message=(
                    f"Pipeline '{state.name}' has stalled after {status}. "
                    "Manual intervention is required."
                )
            )

        task = ready[0]
        task.status = TaskStatus.ACTIVE
        idx = state.tasks.index(task)
        state.current_task = idx

        self._storage.save(state)

        _log_step(
            state.session_id,
            {
                "ts": datetime.now(tz=UTC).isoformat(),
                "event": "recovery_task_activated",
                "task": task.task_name,
                "index": idx,
                "original_status": str(status),
                "session": state.session_id,
            },
        )
        logger.info(
            "[handler] activating recovery task '%s' (index %d, after %s)",
            task.task_name,
            idx,
            status,
        )
        return _run_task(state, task)

    # ------------------------------------------------------------------
    # Inject-only path (USER_PROMPT_SUBMIT / SESSION_START)
    # ------------------------------------------------------------------

    def _inject_active_task(self, state: PipelineState) -> HookOutput:
        """Return the active task's run instruction without mutating state.

        Used by USER_PROMPT_SUBMIT and SESSION_START to re-inject context when
        Claude resumes a session that already has an active task in progress.

        Unlike the Stop path, this must NEVER block the user's prompt.
        run_task() returns BLOCK (appropriate for Stop hooks), so we downgrade
        the decision to ALLOW and surface the instruction as a system message.
        """
        active = state.active_task()
        if active is None:
            return HookOutput()

        logger.info("[handler] injecting context for active task '%s'", active.task_name)
        output = _run_task(state, active)
        output.decision = Decision.ALLOW
        return output
