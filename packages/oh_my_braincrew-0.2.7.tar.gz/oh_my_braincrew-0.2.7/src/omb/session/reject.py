# BCRW-PLAN-000080: handle_reject — inline recovery handler
"""Inline recovery handler for non-approved pipeline task results.

Handles REJECT, FAILED, and NONE outcomes by appending a recovery task and
re-queuing the original task with a depends_on dependency on the recovery task.

This is a pure Python function — no Claude involvement, no hooks.
Retry limit enforcement (RPR-023): when the active task's iteration count
reaches max_iterations, the task is marked FAILED and the pipeline is STALLED.
Recovery depth guard: when recovery_depth reaches 3, the recovery task itself
is marked FAILED and the pipeline is STALLED.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from omb.pipeline.types import (
    PipelineStatus,
    ResultStatus,
    TaskState,
    TaskStatus,
    TaskType,
)

if TYPE_CHECKING:
    from omb.hook.types import HookInput
    from omb.pipeline.types import PipelineState


def handle_reject(
    state: PipelineState,
    status: ResultStatus,
    input: HookInput,  # noqa: A002
    max_iterations: int = 5,
) -> TaskState | None:
    """Handle a non-approved task result by appending a depends_on recovery task.

    Recovery is dependency-based: the recovery task is appended with no deps
    (immediately eligible), and the original task is re-queued with its
    existing depends_on list extended to include the recovery task's task_id.
    The recovery task is appended to state.tasks — the original task remains
    at its current index (mutated in-place). Ordering is irrelevant because
    next_ready_tasks() uses depends_on resolution, not index position.

    Args:
        state: The active pipeline state (mutated in-place).
        status: The result status that triggered recovery.
        input: The hook payload from Claude Code (reserved for future use).
        max_iterations: Maximum retry attempts before stalling the pipeline.

    Returns:
        The newly appended recovery ``TaskState``, or ``None`` when the
        retry limit is exceeded, recovery depth is exhausted, or *status*
        is APPROVED.
    """
    # Guard clause: APPROVED should never reach this handler.
    if status == ResultStatus.APPROVED:
        return None

    active_task = state.active_task()

    # Guard: if no active task found, stall — cannot recover from undefined state.
    if active_task is None:
        state.status = PipelineStatus.STALLED
        return None

    # Retry limit enforcement (RPR-023): stall the pipeline when exhausted.
    if active_task.iteration >= max_iterations:
        active_task.status = TaskStatus.FAILED
        state.status = PipelineStatus.STALLED
        return None

    task_name = active_task.task_name
    next_recovery_depth = active_task.recovery_depth + 1

    # Recovery depth guard: prevent infinite recovery chains.
    if next_recovery_depth >= 3:
        active_task.status = TaskStatus.FAILED
        state.status = PipelineStatus.STALLED
        return None

    # Build the recovery task with no deps (immediately eligible) and the
    # incremented recovery_depth so nested recovery chains are tracked.
    recovery_task = _build_recovery_task(status, task_name, next_recovery_depth)

    # Re-queue original task as PENDING with incremented iteration counter.
    # Preserve its existing depends_on and add the recovery task_id so it
    # only runs AFTER recovery completes.
    active_task.status = TaskStatus.PENDING
    active_task.iteration += 1
    active_task.depends_on = [*active_task.depends_on, recovery_task.task_id]

    # Append recovery task to the end of the task list — active_task is already
    # in state.tasks and was mutated in-place above. depends_on resolution
    # handles ordering; index-based insertion is no longer used.
    state.tasks.append(recovery_task)

    return recovery_task


def _build_recovery_task(
    status: ResultStatus,
    task_name: str,
    recovery_depth: int,
) -> TaskState:
    """Construct the appropriate recovery task for the given result status.

    The recovery task has an empty depends_on list so it is immediately
    eligible for execution. Its recovery_depth is set to the provided value
    so that nested recovery chains are bounded by the depth guard in
    handle_reject().

    Args:
        status: The result that triggered recovery.
        task_name: The name of the original task that failed.
        recovery_depth: Depth counter to propagate to the new task.

    Returns:
        A new ``TaskState`` configured for recovery.
    """
    if status == ResultStatus.REJECT:
        return TaskState(
            task_name=f"recover-{task_name}",
            task_type=TaskType.SUB_AGENT,
            task_payload=f"use executor agent to fix {task_name} review findings",
            status=TaskStatus.PENDING,
            depends_on=[],
            recovery_depth=recovery_depth,
        )

    if status == ResultStatus.FAILED:
        return TaskState(
            task_name=f"debug-{task_name}",
            task_type=TaskType.SUB_AGENT,
            task_payload=f"use debugger agent to investigate {task_name} failure",
            status=TaskStatus.PENDING,
            depends_on=[],
            recovery_depth=recovery_depth,
        )

    # ResultStatus.NONE
    return TaskState(
        task_name=f"decide-{task_name}",
        task_type=TaskType.SYSTEM_DECISION,
        task_payload="Re-evaluate previous skill output and determine if task succeeded",
        status=TaskStatus.PENDING,
        depends_on=[],
        recovery_depth=recovery_depth,
    )
