"""Task lifecycle operations for pipeline state management.

# BCRW-PLAN-000080: Task skip, cancel, and removal operations
"""
from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from omb.pipeline.types import PipelineState

from omb.pipeline.types import TaskStatus


def skip_task(state: PipelineState, task_id: str) -> list[str]:
    """Set a task and all its transitive dependents to SKIPPED.

    Args:
        state: The pipeline state containing all tasks.
        task_id: The ID of the task to skip.

    Returns:
        List of all skipped task_ids (including the original).

    Raises:
        ValueError: If task_id is not found.
        ValueError: If the task has checkpoint=True.
    """
    task_map = {t.task_id: t for t in state.tasks}

    if task_id not in task_map:
        msg = f"Task '{task_id}' not found in pipeline"
        raise ValueError(msg)

    task = task_map[task_id]
    if task.checkpoint:
        msg = f"Cannot skip checkpoint task '{task_id}' without explicit override"
        raise ValueError(msg)

    # Build reverse dependency map: task_id -> list of tasks that depend on it
    reverse_deps: dict[str, list[str]] = defaultdict(list)
    for t in state.tasks:
        for dep_id in t.depends_on:
            reverse_deps[dep_id].append(t.task_id)

    # BFS/iterative walk to collect all transitive dependents
    to_skip: list[str] = []
    queue: list[str] = [task_id]
    visited: set[str] = set()

    while queue:
        current_id = queue.pop(0)
        if current_id in visited:
            continue
        visited.add(current_id)
        to_skip.append(current_id)
        for dependent_id in reverse_deps.get(current_id, []):
            if dependent_id not in visited:
                queue.append(dependent_id)

    for t in state.tasks:
        if t.task_id in visited:
            t.status = TaskStatus.SKIPPED

    return to_skip


def cancel_remaining(state: PipelineState) -> list[str]:
    """Set all PENDING tasks to SKIPPED.

    Args:
        state: The pipeline state containing all tasks.

    Returns:
        List of cancelled task_ids.
    """
    cancelled: list[str] = []
    for task in state.tasks:
        if task.status == TaskStatus.PENDING:
            task.status = TaskStatus.SKIPPED
            cancelled.append(task.task_id)
    return cancelled


def remove_task(state: PipelineState, task_id: str) -> None:
    """Remove a task from the pipeline and clean up dependency references.

    Args:
        state: The pipeline state containing all tasks.
        task_id: The ID of the task to remove.

    Raises:
        ValueError: If task_id is not found.
        ValueError: If the task has checkpoint=True.
    """
    task_map = {t.task_id: t for t in state.tasks}

    if task_id not in task_map:
        msg = f"Task '{task_id}' not found in pipeline"
        raise ValueError(msg)

    task = task_map[task_id]
    if task.checkpoint:
        msg = f"Cannot remove checkpoint task '{task_id}' without explicit override"
        raise ValueError(msg)

    # Remove task from the tasks list
    state.tasks = [t for t in state.tasks if t.task_id != task_id]

    # Remove task_id from all other tasks' depends_on lists
    for t in state.tasks:
        if task_id in t.depends_on:
            t.depends_on = [dep for dep in t.depends_on if dep != task_id]
