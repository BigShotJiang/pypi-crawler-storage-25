"""Pipeline template definitions with checkpoint and retry support.

# BCRW-PLAN-000080: Pipeline definitions with checkpoint and retry support
"""

from __future__ import annotations

import copy

from omb.pipeline.types import TaskState, TaskType

# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _skill(name: str, checkpoint: bool = False, max_retries: int = 0, depends_on: list[str] | None = None) -> TaskState:
    """Create a SKILL-type TaskState with the given name and options."""
    return TaskState(
        task_name=name,
        task_type=TaskType.SKILL,
        checkpoint=checkpoint,
        max_retries=max_retries,
        depends_on=depends_on or [],
    )


def _ask_user(payload: str | None = None) -> TaskState:
    """Create an ASK_USER-type TaskState that actively asks the user for intent."""
    return TaskState(
        task_name="ask-user",
        task_type=TaskType.ASK_USER,
        task_payload=payload or "What would you like to accomplish?",
    )


def _system_decision(name: str, payload: str) -> TaskState:
    """Create a SYSTEM_DECISION-type TaskState for conditional branching."""
    return TaskState(
        task_name=name,
        task_type=TaskType.SYSTEM_DECISION,
        task_payload=payload,
    )


def _build_sequential(*steps: TaskState) -> list[TaskState]:
    """Link tasks sequentially: each step depends on the previous one."""
    for i in range(1, len(steps)):
        steps[i].depends_on = [steps[i - 1].task_id]
    return list(steps)


# ---------------------------------------------------------------------------
# Pipeline templates
# ---------------------------------------------------------------------------

# Each template is a list of TaskState instances representing pipeline steps.
# The _TEMPLATES dict holds the canonical definitions; get_pipeline_templates()
# returns deep copies to ensure callers cannot mutate the originals.
#
# Template key naming convention:
#   Descriptive display names used as dict keys for clarity.
#   Corresponding pre-made schema JSON files live in .omb/schema/.

_TEMPLATES: dict[str, list[TaskState]] = {
    "Interview - Plan - Review - Execute - Verify - Document - Create PR": _build_sequential(
        _ask_user("Describe the feature or task you want to accomplish."),
        _skill("interview"),
        _skill("create-plan"),
        _skill("review-plan", checkpoint=True, max_retries=2),
        _skill("execute"),
        _skill("verify"),
        _skill("document"),
        _skill("create-pr"),
    ),
    "ASK_USER - Plan - Review - Execute - Verify - Document - Create PR": _build_sequential(
        _ask_user("Describe the bug or issue you want to fix."),
        _skill("create-plan"),
        _skill("review-plan", checkpoint=True, max_retries=2),
        _skill("execute"),
        _skill("verify"),
        _skill("document"),
        _skill("create-pr"),
    ),
    "ASK_USER - Plan - Review": _build_sequential(
        _ask_user("Describe what you want to plan."),
        _skill("create-plan"),
        _skill("review-plan", checkpoint=True, max_retries=2),
    ),
    "ASK_USER - Execute - Verify - Document - Create PR": _build_sequential(
        _ask_user("Describe what you want to execute."),
        _skill("execute"),
        _skill("verify"),
        _skill("document"),
        _skill("create-pr"),
    ),
    "ASK_USER - Review PR - Judge - Plan - Review - Execute - Verify - Document - Create PR": _build_sequential(
        _ask_user("Provide the PR number or URL to review."),
        _skill("review-pr"),
        _system_decision(
            "judge",
            "Check review-pr result. If APPROVED: mark subsequent tasks SKIPPED."
            " If NEEDS_REVISION or REJECT: continue to create-plan.",
        ),
        _skill("create-plan"),
        _skill("review-plan", checkpoint=True, max_retries=2),
        _skill("execute"),
        _skill("verify"),
        _skill("document"),
        _skill("create-pr"),
    ),
}

# Backward-compatible aliases for old template keys
_TEMPLATE_ALIASES: dict[str, str] = {
    "full": "Interview - Plan - Review - Execute - Verify - Document - Create PR",
    "fix": "ASK_USER - Plan - Review - Execute - Verify - Document - Create PR",
    "plan": "ASK_USER - Plan - Review",
    "exec": "ASK_USER - Execute - Verify - Document - Create PR",
    "review-pr": "ASK_USER - Review PR - Judge - Plan - Review - Execute - Verify - Document - Create PR",
}


def _get_templates() -> dict[str, list[TaskState]]:
    """Return deep copies of all pipeline templates."""
    return {name: copy.deepcopy(steps) for name, steps in _TEMPLATES.items()}


# ---------------------------------------------------------------------------
# Task -> skill name mapping
# ---------------------------------------------------------------------------

TASK_SKILL_MAP: dict[str, str] = {
    "interview": "omb-interview",
    "create-plan": "omb-create-plan",
    "review-plan": "omb-review-plan",
    "execute": "omb-execute",
    "verify": "omb-verify",
    "document": "omb-document",
    "create-pr": "omb-create-pr",
    "review-pr": "omb-review-pr",
    "commit-to-pr": "omb-commit-to-pr",
}


def get_pipeline_templates() -> dict[str, list[TaskState]]:
    """Return fresh deep copies of all pipeline templates.

    Always call this instead of reading _TEMPLATES directly when
    you intend to mutate the returned tasks (e.g., attaching a session_id).
    """
    return _get_templates()


def resolve_template_name(name: str) -> str | None:
    """Resolve a template name, supporting both new display names and old aliases.

    Returns the canonical display name if found, or None if unrecognized.
    """
    if name in _TEMPLATES:
        return name
    if name in _TEMPLATE_ALIASES:
        return _TEMPLATE_ALIASES[name]
    return None
