"""Pipeline and session shared type system.

# BCRW-PLAN-000080: Pipeline and session type system
"""

from __future__ import annotations

import random
import string
from datetime import UTC, datetime  # noqa: TC003
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, field_validator

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class ResultStatus(StrEnum):
    """Outcome of a completed task or pipeline step."""

    APPROVED = "APPROVED"
    REJECT = "REJECT"
    FAILED = "FAILED"
    NONE = "NONE"
    DONE = "DONE"
    DONE_WITH_CONCERNS = "DONE_WITH_CONCERNS"


class TaskType(StrEnum):
    """Category of work represented by a task."""

    SKILL = "SKILL"
    SUB_AGENT = "SUB-AGENT"
    USER_PROMPT = "USER_PROMPT"
    ASK_USER = "ASK_USER"  # [NEW] Interactive user intent collection  # BCRW-PLAN-000085
    SYSTEM_DECISION = "SYSTEM_DECISION"


class TaskStatus(StrEnum):
    """Lifecycle state of an individual task."""

    PENDING = "pending"
    ACTIVE = "active"
    DONE = "done"
    FAILED = "failed"
    SKIPPED = "skipped"


class PipelineStatus(StrEnum):
    """Lifecycle state of a pipeline."""

    ACTIVE = "active"
    COMPLETED = "completed"
    STALLED = "stalled"
    CANCELLED = "cancelled"


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _random_alphanumeric(k: int) -> str:
    """Generate k random lowercase alphanumeric characters."""
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=k))


def generate_session_id() -> str:
    """Generate session_id in YYYYmmddHHMM-XXXXXX format (UTC)."""
    ts = datetime.now(tz=UTC).strftime("%Y%m%d%H%M")
    return f"{ts}-{_random_alphanumeric(6)}"


def generate_task_id() -> str:
    """Generate a 6-character lowercase alphanumeric task ID."""
    return _random_alphanumeric(6)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class TaskState(BaseModel):
    """State of a single task within a pipeline."""

    task_id: str = Field(default_factory=generate_task_id)
    task_name: str
    task_type: TaskType
    task_payload: str | None = None
    status: TaskStatus = TaskStatus.PENDING
    result: ResultStatus | None = None
    iteration: int = 0
    checkpoint: bool = False
    max_retries: int = 0
    notification: bool = True
    depends_on: list[str] = Field(default_factory=list)
    recovery_depth: int = 0


class NotificationConfig(BaseModel):
    """Controls which pipeline lifecycle events trigger Slack notifications."""

    on_step_complete: bool = True
    on_pipeline_complete: bool = True
    on_failure: bool = True


class PipelineState(BaseModel):
    """Full state of an active or completed pipeline."""

    model_config = ConfigDict(extra="ignore")

    session_id: str
    name: str
    description: str = ""
    status: PipelineStatus = PipelineStatus.ACTIVE
    user_id: str | None = None
    claude_session_id: str | None = None
    created_at: datetime
    current_task: int = 0
    notification: NotificationConfig = Field(default_factory=NotificationConfig)
    tasks: list[TaskState] = Field(default_factory=lambda: [])

    @field_validator("session_id")
    @classmethod
    def session_id_no_path_traversal(cls, v: str) -> str:
        """Reject session_id values that contain path-traversal characters."""
        forbidden = ("/", "\\", "\0", "..")
        for char in forbidden:
            if char in v:
                msg = f"session_id contains forbidden sequence: {char!r}"
                raise ValueError(msg)
        return v

    def active_task(self) -> TaskState | None:
        """Return the task at the current_task index, or None if out of range."""
        if 0 <= self.current_task < len(self.tasks):
            return self.tasks[self.current_task]
        return None

    def next_pending_task(self) -> tuple[int, TaskState] | None:
        """Return (index, task) for the first pending task after current, or None.

        Deprecated: does not respect depends_on. Use next_ready_tasks() instead.
        """
        for i, task in enumerate(self.tasks):
            if i > self.current_task and task.status == TaskStatus.PENDING:
                return (i, task)
        return None

    def active_tasks(self) -> list[TaskState]:
        """Return all tasks with status ACTIVE."""
        return [t for t in self.tasks if t.status == TaskStatus.ACTIVE]

    def next_ready_tasks(self) -> list[TaskState]:
        """Return all PENDING tasks whose depends_on are ALL done.

        Uses status-based resolution: a task is 'ready' when every task_id
        in its depends_on list has status DONE. Tasks with empty depends_on
        are ready if they are PENDING.
        """
        done_ids = {t.task_id for t in self.tasks if t.status == TaskStatus.DONE}
        return [
            t for t in self.tasks
            if t.status == TaskStatus.PENDING
            and all(dep_id in done_ids for dep_id in t.depends_on)
        ]
