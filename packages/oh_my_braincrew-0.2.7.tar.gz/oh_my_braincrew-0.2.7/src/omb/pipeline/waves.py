"""Wave computation for dependency-aware task scheduling.

# BCRW-PLAN-000080: Wave computation via topological sort
"""
from __future__ import annotations

from collections import deque
from typing import TYPE_CHECKING

from omb.pipeline.types import TaskStatus

if TYPE_CHECKING:
    from omb.pipeline.types import TaskState


def compute_waves(tasks: list[TaskState]) -> list[list[str]]:
    """Return ordered waves of task_ids using Kahn's topological sort.

    Wave 0 contains tasks with no dependencies. Wave N contains tasks
    whose entire ``depends_on`` list is satisfied by waves 0..N-1.

    Raises:
        ValueError: If an unknown dependency is referenced.
        ValueError: If a circular dependency is detected.
    """
    known_ids: set[str] = {t.task_id for t in tasks}

    # Validate all dependency references up-front.
    for task in tasks:
        for dep_id in task.depends_on:
            if dep_id not in known_ids:
                msg = (
                    f"Task '{task.task_id}' depends on unknown task_id '{dep_id}'"
                )
                raise ValueError(msg)

    # Build adjacency and in-degree structures.
    in_degree: dict[str, int] = {t.task_id: 0 for t in tasks}
    dependents: dict[str, list[str]] = {t.task_id: [] for t in tasks}

    for task in tasks:
        for dep_id in task.depends_on:
            dependents[dep_id].append(task.task_id)
            in_degree[task.task_id] += 1

    # Seed the queue with tasks that have no dependencies.
    queue: deque[str] = deque(
        tid for tid, degree in in_degree.items() if degree == 0
    )

    waves: list[list[str]] = []
    visited_count = 0

    while queue:
        # All tasks currently in the queue form one wave (can run in parallel).
        wave = list(queue)
        queue.clear()
        waves.append(wave)
        visited_count += len(wave)

        next_wave_candidates: list[str] = []
        for tid in wave:
            for dependent_id in dependents[tid]:
                in_degree[dependent_id] -= 1
                if in_degree[dependent_id] == 0:
                    next_wave_candidates.append(dependent_id)

        queue.extend(next_wave_candidates)

    if visited_count != len(tasks):
        remaining = [tid for tid, deg in in_degree.items() if deg > 0]
        msg = f"Circular dependency detected among tasks: {remaining}"
        raise ValueError(msg)

    return waves


def next_ready_task_ids(tasks: list[TaskState]) -> list[str]:
    """Return task_ids of all PENDING tasks whose dependencies are all DONE.

    This is the runtime complement to ``compute_waves``: given the current
    live status of every task, return which tasks can be activated right now.
    """
    done_ids: set[str] = {
        t.task_id for t in tasks if t.status == TaskStatus.DONE
    }
    return [
        t.task_id
        for t in tasks
        if t.status == TaskStatus.PENDING
        and all(dep_id in done_ids for dep_id in t.depends_on)
    ]
