# BCRW-PLAN-000080: Hook regex patterns
"""Compiled regex patterns for hook enforcement.

All patterns are compiled once at module load for performance.
Separated from constants to keep static strings and regex distinct.
"""

from __future__ import annotations

import re

# ---------------------------------------------------------------------------
# Dangerous bash command patterns — position-aware regex.
# These match at command boundaries (start of line, after ; & | pipe) to avoid
# false positives from strings inside echo/printf/comments.
# ---------------------------------------------------------------------------

_CMD_START = r"(?:^|[;&|]\s*)"  # start of line or after shell separator

DANGEROUS_BASH_CMD_PATTERNS: list[re.Pattern[str]] = [
    re.compile(_CMD_START + r"rm\s+-[a-zA-Z]*r[a-zA-Z]*f[a-zA-Z]*\s+/(?:\s|$)"),
    re.compile(_CMD_START + r"rm\s+-[a-zA-Z]*f[a-zA-Z]*r[a-zA-Z]*\s+/(?:\s|$)"),
    re.compile(_CMD_START + r"rm\s+-rf\s+~"),
    re.compile(_CMD_START + r"rm\s+-rf\s+\.(?:\s|$)"),
    re.compile(_CMD_START + r"git\s+push\s+--force\s+origin\s+(?:main|master)\b"),
    re.compile(_CMD_START + r"git\s+reset\s+--hard\b"),
    re.compile(_CMD_START + r"terraform\s+destroy\b"),
    re.compile(_CMD_START + r"chmod\s+777\b"),
]


# ---------------------------------------------------------------------------
# Long-running command advisory patterns
# ---------------------------------------------------------------------------

LONG_RUNNING_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\bpytest\b"),
    re.compile(r"\bnpm test\b"),
    re.compile(r"\bnpm run test\b"),
    re.compile(r"\bnpx vitest\b"),
    re.compile(r"\bdocker build\b"),
    re.compile(r"\bdocker compose up\b"),
    re.compile(r"\bmake test\b"),
    re.compile(r"\btsc --noEmit\b"),
    re.compile(r"\bmypy\b"),
    re.compile(r"\bpyright\b"),
]

# ---------------------------------------------------------------------------
# Result status parsing (RPR-042: only match structured markers, not prose)
# ---------------------------------------------------------------------------

# Match <omb> XML schema with optional <session_id>.
# Format: <omb>[<session_id>ID</session_id>]<task>name(summary)</task><decision>STATUS</decision></omb>
# Priority 1 parser — all well-behaved skills emit this format.
# Groups: 1=session_id (optional), 2=task, 3=decision
# Deprecation: optional session_id for 1 release cycle, then mandatory
OMB_XML_RE: re.Pattern[str] = re.compile(
    r"<omb>\s*(?:<session_id>([^<]*)</session_id>\s*)?<task>([^<]+)</task>\s*<decision>([A-Z_]+)</decision>\s*</omb>",
    re.DOTALL,
)

# Match <omb>STEP:<name>:<STATUS></omb> or <omb>LOOP:<name>:<STATUS></omb> markers.
OMB_MARKER_RE: re.Pattern[str] = re.compile(r"<omb>(?:STEP|LOOP):[a-z0-9\-]+:([A-Z_]+)</omb>")

# Match verdict headers like "### Status: APPROVED" or "### Verdict: NEEDS REVISION"
VERDICT_HEADER_RE: re.Pattern[str] = re.compile(
    r"^###\s+(?:Status|Verdict):\s*(APPROVED|REJECT|FAILED|NEEDS[_ ]REVISION)",
    re.MULTILINE,
)

# Match skill completion signals: "DONE — ...", "DONE_WITH_CONCERNS — ...", "APPROVED — ...", etc.
# at the start of a line, followed by em-dash, double-dash, colon, or end of line.
# Covers all decision tokens used by executor, reviewer, and critic agents.
# Bare keywords in prose (e.g., "DONE with analysis") are NOT matched (RPR-042).
COMPLETION_SIGNAL_RE: re.Pattern[str] = re.compile(
    r"^(DONE(?:_WITH_CONCERNS)?|APPROVED|NEEDS_REVISION|REJECT|FAILED|NEEDS_CONTEXT|BLOCKED)\s*(?:—|--|:|$)",
    re.MULTILINE,
)

# ---------------------------------------------------------------------------
# Sensitive content patterns (ported from Go)
# ---------------------------------------------------------------------------

SENSITIVE_CONTENT_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"-----BEGIN[A-Z ]*PRIVATE KEY-----"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"gh[ps]_[A-Za-z0-9_]{36,}"),
    re.compile(r"glpat-[A-Za-z0-9\-_]{20,}"),
    re.compile(r"xox[bpsa]-[A-Za-z0-9\-]+"),
    re.compile(r"(?i)api[_\-]?key\s*=\s*[\"'][^\"']{8,}[\"']"),
]
