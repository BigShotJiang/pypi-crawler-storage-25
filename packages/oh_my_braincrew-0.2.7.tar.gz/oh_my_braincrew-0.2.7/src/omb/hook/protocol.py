# BCRW-PLAN-000080: Hook protocol JSON I/O
"""stdin/stdout JSON protocol for Claude Code hook handlers.

Provides read_input (JSON → HookInput) and write_output (HookOutput → JSON stdout).
Key normalisation step: Claude Code sends camelCase keys; this module converts them to
snake_case before constructing HookInput so callers always work with Pythonic names.
"""

from __future__ import annotations

import json
import os
import re
import sys
from typing import IO, Any, cast

from omb.hook.types import HookInput, HookOutput


def _camel_to_snake(name: str) -> str:
    """Convert a camelCase identifier to snake_case.

    Examples:
        stopHookActive  -> stop_hook_active
        hookEventName   -> hook_event_name
        cwd             -> cwd  (already lowercase — unchanged)
    """
    # Insert an underscore before every uppercase letter that follows a lowercase letter
    # or digit, then lowercase the whole string.
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    return s.lower()


def _normalize_keys(data: dict[str, Any]) -> dict[str, Any]:
    """Recursively normalize dict keys from camelCase to snake_case.

    Also recurses into nested dicts and lists of dicts (RPR-014 fix).
    """
    result: dict[str, Any] = {}
    for key, value in data.items():
        snake_key = _camel_to_snake(key)
        if isinstance(value, dict):
            result[snake_key] = _normalize_keys(cast("dict[str, Any]", value))
        elif isinstance(value, list):
            result[snake_key] = [
                _normalize_keys(cast("dict[str, Any]", item)) if isinstance(item, dict) else item
                for item in cast("list[Any]", value)
            ]
        else:
            result[snake_key] = value
    return result


def read_input(stream: IO[str] = sys.stdin) -> HookInput:
    """Read and parse hook payload from *stream* (default: stdin).

    Steps:
    1. Read the full stream content.
    2. Raise ValueError on empty input (Claude Code always sends JSON).
    3. Parse JSON.
    4. Normalize keys from camelCase → snake_case.
    5. Validate required fields: session_id, cwd, hook_event_name.
    6. Construct and return a HookInput instance, storing the normalized payload in raw.

    Raises:
        ValueError: on empty input or missing required fields.
        json.JSONDecodeError: on malformed JSON (propagated to caller).
    """
    raw_text = stream.read().strip()
    if not raw_text:
        raise ValueError("Hook stdin was empty — Claude Code always sends a JSON payload")

    data: dict[str, Any] = json.loads(raw_text)
    normalized = _normalize_keys(data)

    # Inject omb_project_dir from environment if not already present in payload.
    normalized.setdefault("omb_project_dir", os.environ.get("CLAUDE_PROJECT_DIR", ""))

    # --- Field name normalization for official vs internal naming ---

    # UserPromptSubmit: official sends "prompt", internal model uses "user_prompt"
    if "prompt" in normalized and "user_prompt" not in normalized:
        normalized["user_prompt"] = normalized.pop("prompt")

    # ConfigChange: official sends "config_source"; legacy might send "source"
    is_config_change = normalized.get("hook_event_name") == "ConfigChange"
    if is_config_change and "source" in normalized and "config_source" not in normalized:
        normalized["config_source"] = normalized.pop("source")

    required = ("session_id", "cwd", "hook_event_name")
    missing = [f for f in required if not normalized.get(f)]
    if missing:
        raise ValueError(f"Hook payload missing required fields: {missing}")

    return HookInput(**normalized, raw=normalized)


def write_output(output: HookOutput, stream: IO[str] = sys.stdout) -> None:
    """Serialize *output* as JSON and write it to *stream* (default: stdout).

    Delegates to HookOutput.to_stdout() for the serialization contract.
    Wire format varies by event type — see HookOutput.to_stdout() docstring.
    """
    stream.write(output.to_stdout())
