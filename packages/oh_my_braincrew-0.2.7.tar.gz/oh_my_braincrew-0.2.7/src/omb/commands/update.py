"""omb update — upgrade oh-my-braincrew (binary or PyPI)."""

from __future__ import annotations

import contextlib
import json
import platform
import shutil
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

import click

PKG_NAME = "oh-my-braincrew"
RELEASE_REPO = "teddynote-lab/oh-my-braincrew-release"
GITHUB_API = f"https://api.github.com/repos/{RELEASE_REPO}/releases/latest"


def _run(cmd: list[str], check: bool = True) -> subprocess.CompletedProcess[str]:
    """Run a subprocess, raising on failure when *check* is True."""
    result = subprocess.run(cmd, capture_output=True, text=True)
    if check and result.returncode != 0:
        stderr = result.stderr.strip() or result.stdout.strip()
        raise click.ClickException(f"`{' '.join(cmd)}` failed:\n{stderr}")
    return result


def _is_frozen() -> bool:
    """Return True when running as a PyInstaller-bundled binary."""
    return getattr(sys, "frozen", False)


def _is_dev_checkout() -> bool:
    """Return True when running from a source checkout (editable install)."""
    omb_pkg = Path(__file__).resolve().parent.parent  # src/omb
    candidate = omb_pkg.parent.parent / "pyproject.toml"
    if not candidate.exists():
        return False
    try:
        content = candidate.read_text(encoding="utf-8")
        return f'name = "{PKG_NAME}"' in content
    except OSError:
        return False


def _detect_tool_install(tool: str) -> bool:
    """Check whether the package is managed by *tool* (uv tool / pipx)."""
    exe = shutil.which(tool)
    if not exe:
        return False
    result = _run([exe, "list"], check=False)
    return PKG_NAME in (result.stdout or "")


def _current_platform() -> str:
    """Return platform string matching release asset names (darwin, linux, windows)."""
    s = platform.system().lower()
    if s == "darwin":
        return "darwin"
    if s == "linux":
        return "linux"
    if s in ("windows", "win32"):
        return "windows"
    return s


def _current_arch() -> str:
    """Return architecture string matching release asset names (amd64, arm64)."""
    m = platform.machine().lower()
    if m in ("x86_64", "amd64"):
        return "amd64"
    if m in ("arm64", "aarch64"):
        return "arm64"
    return m


def _fetch_json(url: str) -> dict[str, object]:
    """Fetch JSON from a URL."""
    import urllib.request

    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=10) as resp:
        result: dict[str, object] = json.loads(resp.read())
        return result


def _latest_release() -> tuple[str, str] | None:
    """Fetch latest release info. Returns (version, asset_download_url) or None."""
    try:
        data = _fetch_json(GITHUB_API)
    except Exception:
        return None

    tag = str(data.get("tag_name", ""))
    version = tag.lstrip("v")
    plat = _current_platform()
    arch = _current_arch()

    suffix = ".exe" if plat == "windows" else ""
    target_name = f"omb-v{version}-{plat}-{arch}{suffix}"

    assets: list[dict[str, object]] = data.get("assets", [])  # type: ignore[assignment]
    for asset in assets:
        if str(asset.get("name", "")) == target_name:
            return version, str(asset.get("browser_download_url", ""))

    return None


def _latest_pypi_version() -> str | None:
    """Fetch the latest version string from PyPI (best-effort)."""
    try:
        import urllib.request

        with urllib.request.urlopen(
            f"https://pypi.org/pypi/{PKG_NAME}/json", timeout=5
        ) as resp:
            data = json.loads(resp.read())
            return data["info"]["version"]
    except Exception:
        return None


def _download_file(url: str, dest: Path) -> None:
    """Download a file from URL to dest path."""
    import urllib.request

    click.echo(f"Downloading from {RELEASE_REPO}...")
    urllib.request.urlretrieve(url, str(dest))


def _self_replace(new_binary: Path) -> None:
    """Replace the currently running binary with *new_binary*."""
    current = Path(sys.executable).resolve()
    backup = current.with_suffix(".bak")

    # Make downloaded binary executable
    new_binary.chmod(new_binary.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

    # Backup current → replace
    if backup.exists():
        backup.unlink()
    current.rename(backup)
    try:
        shutil.copy2(str(new_binary), str(current))
        current.chmod(current.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    except Exception:
        # Restore backup on failure
        if backup.exists():
            backup.rename(current)
        raise
    finally:
        if backup.exists():
            with contextlib.suppress(OSError):
                backup.unlink()


@click.command("update")
def update_cmd() -> None:
    """Update omb to the latest version."""
    from omb.services.version import get_version

    current_version = get_version()

    # --- Frozen binary: self-update from GitHub Releases -------------------------
    if _is_frozen():
        click.echo(f"Current version: {current_version}")
        click.echo("Checking for updates...")

        release = _latest_release()
        if release is None:
            raise click.ClickException(
                f"Could not find a release for {_current_platform()}/{_current_arch()}.\n"
                f"Check {RELEASE_REPO} on GitHub for available binaries."
            )

        latest_version, download_url = release
        if latest_version == current_version:
            click.echo(f"Already up to date (v{current_version}).")
            return

        click.echo(f"New version available: v{current_version} -> v{latest_version}")

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp) / "omb_new"
            _download_file(download_url, tmp_path)
            _self_replace(tmp_path)

        click.echo(f"Updated to v{latest_version}.")
        return

    # --- Dev checkout: advise git pull -------------------------------------------
    if _is_dev_checkout():
        click.echo(
            "You are running omb from a source checkout.\n"
            "Use `git pull && make setup` (or `uv pip install -e .`) to update."
        )
        return

    # --- PyPI install: pip/uv/pipx upgrade ---------------------------------------
    cmd: list[str]
    if _detect_tool_install("uv"):
        cmd = [str(shutil.which("uv")), "tool", "upgrade", PKG_NAME]
    elif _detect_tool_install("pipx"):
        cmd = [str(shutil.which("pipx")), "upgrade", PKG_NAME]
    else:
        uv = shutil.which("uv")
        if uv:
            cmd = [uv, "pip", "install", "--upgrade", PKG_NAME]
        else:
            cmd = [sys.executable, "-m", "pip", "install", "--upgrade", PKG_NAME]

    latest = _latest_pypi_version()
    if latest:
        click.echo(f"Latest PyPI version: {latest}")

    click.echo(f"Running: {' '.join(cmd)}")
    _run(cmd)

    click.echo("Update complete.")
    _run([sys.executable, "-m", "omb", "version"])
