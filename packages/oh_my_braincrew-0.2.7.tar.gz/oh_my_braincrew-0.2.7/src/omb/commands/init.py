"""omb init — initialize oh-my-braincrew in a project directory."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import click

PLUGIN_REPO = "teddynote-lab/oh-my-braincrew"
PLUGIN_REPO_URL = f"https://github.com/{PLUGIN_REPO}.git"
GITHUB_INSTALL_CMD = ["claude", "install-plugin", f"github:{PLUGIN_REPO}"]


def _has_claude_cli() -> bool:
    """Check if claude CLI is available."""
    return shutil.which("claude") is not None


def _clone_plugin(dest: Path) -> bool:
    """Clone the plugin repo to dest. Returns True on success."""
    result = subprocess.run(
        ["git", "clone", "--depth", "1", PLUGIN_REPO_URL, str(dest)],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def _scaffold_project(project_dir: Path) -> None:
    """Create .omb/ directory structure in the project."""
    omb_dir = project_dir / ".omb"
    dirs = ["plans", "sessions", "verifications", "prs", "reviews", "logs", "documents", "config"]
    for d in dirs:
        (omb_dir / d).mkdir(parents=True, exist_ok=True)

    # Create config.json if it doesn't exist
    config_path = omb_dir / "config.json"
    if not config_path.exists():
        config_path.write_text(json.dumps({
            "project": project_dir.name,
            "counters": {
                "PLAN": 0,
                "SPEC": 0,
                "FIX": 0,
                "TASK": 0,
                "PR": 0,
            },
        }, indent=2) + "\n")

    click.echo("  Created .omb/ directory structure")


def _write_home(plugin_path: Path) -> None:
    """Write the plugin path to ~/.omb/home."""
    from omb.services.home import omb_dir, write_home

    omb_dir()  # ensure ~/.omb/ exists
    write_home(str(plugin_path.resolve()))
    click.echo("  Saved plugin path to ~/.omb/home")


def run_init(path: str) -> None:
    """Initialize omb in the given project directory."""
    project_dir = Path(path).resolve()

    if not project_dir.is_dir():
        raise click.ClickException(f"Directory does not exist: {project_dir}")

    click.echo(f"Initializing omb in {project_dir}...")
    click.echo()

    # Step 1: Scaffold .omb/ project structure
    _scaffold_project(project_dir)

    # Step 2: Install plugin (for Claude Code integration)
    home_dir = Path.home() / ".omb"
    home_file = home_dir / "home"
    plugin_path: Path | None = None

    # Check if plugin is already installed
    if home_file.exists():
        existing = Path(home_file.read_text().strip())
        if existing.is_dir() and (existing / ".claude-plugin" / "plugin.json").exists():
            plugin_path = existing
            click.echo(f"  Plugin already installed at {plugin_path}")

    if plugin_path is None:
        # Try claude install-plugin first
        if _has_claude_cli():
            click.echo("  Installing plugin via Claude Code...")
            result = subprocess.run(GITHUB_INSTALL_CMD, capture_output=True, text=True)
            if result.returncode == 0:
                click.echo("  Plugin installed via claude install-plugin")
                # Claude installs to ~/.claude/plugins/
                claude_plugin_dir = Path.home() / ".claude" / "plugins" / "oh-my-braincrew"
                if claude_plugin_dir.is_dir():
                    plugin_path = claude_plugin_dir
            else:
                click.echo("  claude install-plugin failed, falling back to git clone...")

        # Fallback: clone to ~/.omb/plugin/
        if plugin_path is None:
            plugin_dest = home_dir / "plugin"
            if plugin_dest.is_dir():
                click.echo(f"  Plugin directory exists at {plugin_dest}, updating...")
                subprocess.run(
                    ["git", "-C", str(plugin_dest), "pull", "--ff-only"],
                    capture_output=True,
                    text=True,
                )
                plugin_path = plugin_dest
            else:
                click.echo("  Cloning plugin from GitHub...")
                if _clone_plugin(plugin_dest):
                    plugin_path = plugin_dest
                    click.echo(f"  Plugin cloned to {plugin_dest}")
                else:
                    click.echo("  Warning: Could not clone plugin repo.")
                    click.echo("  You can install manually: claude install-plugin github:teddynote-lab/oh-my-braincrew")

    # Step 3: Save home path
    if plugin_path is not None:
        _write_home(plugin_path)

    # Step 4: Print next steps
    click.echo()
    click.echo("Done! Next steps:")
    click.echo()

    if plugin_path is not None:
        click.echo("  1. Start Claude Code with the plugin:")
        click.echo(f"     claude --plugin-dir {plugin_path}")
        click.echo()
        click.echo("  2. Or run the setup wizard inside Claude Code:")
        click.echo("     /omb setup")
    else:
        click.echo("  1. Install the plugin:")
        click.echo("     claude install-plugin github:teddynote-lab/oh-my-braincrew")
        click.echo()
        click.echo("  2. Start Claude Code:")
        click.echo("     claude")

    click.echo()
    click.echo("  Update anytime with: omb update")
