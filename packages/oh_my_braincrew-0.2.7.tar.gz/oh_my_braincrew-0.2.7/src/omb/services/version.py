"""Build version info — replaces pkg/version/version.go."""

from __future__ import annotations

import json
import platform
import sys
from dataclasses import dataclass

try:
    from importlib.metadata import version as _pkg_version

    _resolved_version = _pkg_version("oh-my-braincrew")
except Exception:
    _resolved_version = "0.0.0-dev"

VERSION: str = _resolved_version
COMMIT = "unknown"
DATE = "unknown"


@dataclass(frozen=True)
class Info:
    version: str
    commit: str
    date: str
    python_version: str
    os: str
    arch: str

    def __str__(self) -> str:
        return f"omb {self.version} ({self.commit}) built {self.date}"

    def to_json(self) -> str:
        return json.dumps(
            {
                "version": self.version,
                "commit": self.commit,
                "date": self.date,
                "python_version": self.python_version,
                "os": self.os,
                "arch": self.arch,
            },
            indent=2,
        )


def get_info() -> Info:
    return Info(
        version=VERSION,
        commit=COMMIT,
        date=DATE,
        python_version=f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        os=platform.system().lower(),
        arch=platform.machine(),
    )


def get_version() -> str:
    return VERSION
