function render({ model, el }) {
    const container = document.createElement("div");
    container.className = "subword-container";

    const renderWords = () => {
        container.innerHTML = "";
        const subwords = model.get("subwords");
        const hovered = model.get("hovered_index");

        subwords.forEach((word, i) => {
            const span = document.createElement("span");
            span.className = "subword" + (i === hovered ? " active" : "");
            span.textContent = word;

            span.addEventListener("mouseenter", () => {
                model.set("hovered_index", i);
                model.save_changes();
            });

            container.appendChild(span);
        });
    };

    renderWords();
    model.on("change:subwords", renderWords);
    model.on("change:hovered_index", renderWords);

    el.appendChild(container);
}
export default { render };
