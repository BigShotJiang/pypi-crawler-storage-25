import importlib.metadata
import pathlib

import anywidget
import traitlets

try:
    __version__ = importlib.metadata.version("subword-tooltip")
except importlib.metadata.PackageNotFoundError:
    __version__ = "unknown"


class Widget(anywidget.AnyWidget):
    _esm = pathlib.Path(__file__).parent / "static" / "widget.js"
    _css = pathlib.Path(__file__).parent / "static" / "widget.css"
    subwords = traitlets.List(traitlets.Unicode(), ["This", " is", " an", " impor", "tant", " example"]).tag(sync=True)
    hovered_index = traitlets.Int(0).tag(sync=True)
