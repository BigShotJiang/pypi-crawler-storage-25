import marimo

__generated_with = "0.22.4"
app = marimo.App(width="medium")


@app.cell
def _():
    import marimo as mo
    import subword_tooltip

    list_of_subwords = ['This', ' is', ' an', ' impor', 'tant', ' example']
    w = mo.ui.anywidget(subword_tooltip.Widget(subwords=list_of_subwords))
    w
    return list_of_subwords, w


@app.cell
def _(list_of_subwords, w):
    w.hovered_index       # → index (int)
    list_of_subwords[w.hovered_index]  # → the subword string
    return


if __name__ == "__main__":
    app.run()
