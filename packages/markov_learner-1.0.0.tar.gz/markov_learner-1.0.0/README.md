# markov-learner

言語レベルでのマルコフ連鎖を簡単に体験できるライブラリです。
指定したURLからテキストを学習し、それに基づいた文章を生成します。

## インストール

```bash
pip install markov-learner
```

## 使い方

```python
# ライブラリのダウンロード
import markov

# URLから学習
## 同じ階層のみを学習する 
markov.learn.add("https://example.com")
markov.learn.add("https://en.wikipedia.org/wiki/Markov_chain")

# 文章の生成 
markov.output
## 変数に保存したり、表示したりできる
x = markov.output
print(markov.output)

# 学習データのリセット
markov.learn.reset
```

## 作者
Atsuki
