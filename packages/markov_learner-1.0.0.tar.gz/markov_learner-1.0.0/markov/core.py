import random
import re

class MarkovModel:
    def __init__(self, state_size=2):
        self.state_size = state_size
        self.model = {}
        self.start_nodes = []

    def _tokenize(self, text):
        # 簡易的なトークナイザ: スペース、改行、句読点で分割
        # 日本語の場合、形態素解析なしでは文字単位に近い動作になります
        # 正規表現で「単語」と「それ以外（記号など）」を切り分けます
        tokens = re.findall(r'[a-zA-Z0-9]+|[ぁ-んァ-ヶー一-龠々]+|[^\s\w]', text)
        return tokens

    def add_text(self, text):
        if not text:
            return
        
        tokens = self._tokenize(text)
        if len(tokens) < self.state_size:
            return

        # 開始ノードを保存
        self.start_nodes.append(tuple(tokens[:self.state_size]))

        for i in range(len(tokens) - self.state_size):
            state = tuple(tokens[i : i + self.state_size])
            next_token = tokens[i + self.state_size]
            
            if state not in self.model:
                self.model[state] = []
            self.model[state].append(next_token)

    def generate(self, max_length=100):
        if not self.model:
            return ""

        # ランダムな開始地点を選択
        if not self.start_nodes:
            current_state = random.choice(list(self.model.keys()))
        else:
            current_state = random.choice(self.start_nodes)
            
        result = list(current_state)

        for _ in range(max_length - self.state_size):
            if current_state not in self.model:
                break
            
            next_token = random.choice(self.model[current_state])
            result.append(next_token)
            current_state = tuple(result[-self.state_size :])

        return "".join(result)

    def reset(self):
        self.model = {}
        self.start_nodes = []
