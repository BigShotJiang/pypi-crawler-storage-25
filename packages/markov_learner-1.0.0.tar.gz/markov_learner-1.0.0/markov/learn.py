import requests
from bs4 import BeautifulSoup
from .core import MarkovModel

class LearnManager:
    def __init__(self, model: MarkovModel):
        self._model = model

    def add(self, url):
        if not isinstance(url, str):
            # 変数などを用いて記載することを考慮し、文字列に変換できるかチェック
            try:
                url = str(url)
            except Exception:
                raise ValueError(f"Invalid URL type: {type(url)}")

        if not (url.startswith('http://') or url.startswith('https://')):
            raise ValueError(f"Invalid URL format: {url}. Must start with http:// or https://")

        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Failed to fetch URL {url}: {e}")

        # BeautifulSoupでテキストを抽出
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 不要なタグを除去
        for script_or_style in soup(["script", "style", "header", "footer", "nav"]):
            script_or_style.decompose()

        text = soup.get_text(separator=' ', strip=True)
        self._model.add_text(text)

    @property
    def reset(self):
        """学習データをリセットします。プロパティとしてアクセスすることで実行されます。"""
        self._model.reset()
        return None
