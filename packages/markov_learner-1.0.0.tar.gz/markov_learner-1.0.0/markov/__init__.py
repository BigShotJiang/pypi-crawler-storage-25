from .core import MarkovModel
from .learn import LearnManager

# シングルトンインスタンスとしてモデルと学習マネージャーを初期化
_model = MarkovModel()
learn = LearnManager(_model)

def __getattr__(name):
    """
    Python 3.7+ のモジュールレベル __getattr__ を使用して
    markov.output をプロパティのように動作させます。
    """
    if name == 'output':
        return _model.generate()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

# markov.output という名前が名前空間に存在することをIDE等に伝えるためのヒント
output: str
