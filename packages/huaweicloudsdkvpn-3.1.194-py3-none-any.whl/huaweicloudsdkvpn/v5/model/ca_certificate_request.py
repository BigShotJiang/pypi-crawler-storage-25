# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CaCertificateRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []
    sensitive_list.append('content')

    openapi_types = {
        'id': 'str',
        'content': 'str'
    }

    attribute_map = {
        'id': 'id',
        'content': 'content'
    }

    def __init__(self, id=None, content=None):
        r"""CaCertificateRequest

        The model defined in huaweicloud sdk

        :param id: 使用已有证书ID
        :type id: str
        :param content: 对端网关CA证书内容
        :type content: str
        """
        
        

        self._id = None
        self._content = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if content is not None:
            self.content = content

    @property
    def id(self):
        r"""Gets the id of this CaCertificateRequest.

        使用已有证书ID

        :return: The id of this CaCertificateRequest.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this CaCertificateRequest.

        使用已有证书ID

        :param id: The id of this CaCertificateRequest.
        :type id: str
        """
        self._id = id

    @property
    def content(self):
        r"""Gets the content of this CaCertificateRequest.

        对端网关CA证书内容

        :return: The content of this CaCertificateRequest.
        :rtype: str
        """
        return self._content

    @content.setter
    def content(self, content):
        r"""Sets the content of this CaCertificateRequest.

        对端网关CA证书内容

        :param content: The content of this CaCertificateRequest.
        :type content: str
        """
        self._content = content

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CaCertificateRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
