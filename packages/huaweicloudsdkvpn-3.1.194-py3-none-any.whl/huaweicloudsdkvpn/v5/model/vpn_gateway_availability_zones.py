# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class VpnGatewayAvailabilityZones:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'vpc': 'list[str]',
        'er': 'list[str]'
    }

    attribute_map = {
        'vpc': 'vpc',
        'er': 'er'
    }

    def __init__(self, vpc=None, er=None):
        r"""VpnGatewayAvailabilityZones

        The model defined in huaweicloud sdk

        :param vpc: VPC关联类型的可用区列表
        :type vpc: list[str]
        :param er: ER关联类型的可用区列表
        :type er: list[str]
        """
        
        

        self._vpc = None
        self._er = None
        self.discriminator = None

        if vpc is not None:
            self.vpc = vpc
        if er is not None:
            self.er = er

    @property
    def vpc(self):
        r"""Gets the vpc of this VpnGatewayAvailabilityZones.

        VPC关联类型的可用区列表

        :return: The vpc of this VpnGatewayAvailabilityZones.
        :rtype: list[str]
        """
        return self._vpc

    @vpc.setter
    def vpc(self, vpc):
        r"""Sets the vpc of this VpnGatewayAvailabilityZones.

        VPC关联类型的可用区列表

        :param vpc: The vpc of this VpnGatewayAvailabilityZones.
        :type vpc: list[str]
        """
        self._vpc = vpc

    @property
    def er(self):
        r"""Gets the er of this VpnGatewayAvailabilityZones.

        ER关联类型的可用区列表

        :return: The er of this VpnGatewayAvailabilityZones.
        :rtype: list[str]
        """
        return self._er

    @er.setter
    def er(self, er):
        r"""Sets the er of this VpnGatewayAvailabilityZones.

        ER关联类型的可用区列表

        :param er: The er of this VpnGatewayAvailabilityZones.
        :type er: list[str]
        """
        self._er = er

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, VpnGatewayAvailabilityZones):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
