"""Unit tests for Scheduler Python API: happy paths, cancel, list, get."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
from _fakes import FakeChannel
from zeno.scheduler.scheduler import Scheduler
from zeno.scheduler.testing import InMemoryScheduleStore

_BASE = datetime(2025, 6, 1, 12, 0, 0, tzinfo=UTC)


def _sched(ch: FakeChannel | None = None) -> tuple[Scheduler, InMemoryScheduleStore, FakeChannel]:
    store = InMemoryScheduleStore()
    channel = ch or FakeChannel(name="fake://api")
    clock = [_BASE]
    sched = Scheduler(
        store,
        {channel.name: channel},
        None,
        now_fn=lambda: clock[0],
        min_interval_s=10,
    )
    return sched, store, channel


# ---------------------------------------------------------------------------
# schedule_once
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_schedule_once_with_delta_stores_row() -> None:
    sched, store, _ = _sched()
    row = await sched.schedule_once(
        user_id="u1",
        thread_key="t1",
        channel="fake://api",
        prompt="Hello",
        delta=timedelta(seconds=60),
    )
    fetched = await store.get(row.id)
    assert fetched is not None
    assert fetched.kind == "one_shot"
    assert fetched.prompt == "Hello"
    assert fetched.user_id == "u1"
    assert fetched.thread_key == "t1"
    assert fetched.status == "active"


@pytest.mark.asyncio
async def test_schedule_once_with_at_stores_row() -> None:
    sched, store, _ = _sched()
    fire_at = _BASE + timedelta(hours=1)
    row = await sched.schedule_once(
        user_id="u1",
        thread_key=None,
        channel="fake://api",
        prompt="At test",
        at=fire_at,
    )
    fetched = await store.get(row.id)
    assert fetched is not None
    assert fetched.next_fire_at == int(fire_at.timestamp())


@pytest.mark.asyncio
async def test_schedule_once_neither_at_nor_delta_raises() -> None:
    sched, _, _ = _sched()
    with pytest.raises(ValueError, match="exactly one of at=, delta="):
        await sched.schedule_once(
            user_id="u1",
            thread_key=None,
            channel="fake://api",
            prompt="Bad",
        )


@pytest.mark.asyncio
async def test_schedule_once_both_at_and_delta_raises() -> None:
    sched, _, _ = _sched()
    with pytest.raises(ValueError, match="exactly one of at=, delta="):
        await sched.schedule_once(
            user_id="u1",
            thread_key=None,
            channel="fake://api",
            prompt="Bad",
            at=_BASE + timedelta(hours=1),
            delta=timedelta(hours=1),
        )


# ---------------------------------------------------------------------------
# schedule_heartbeat
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_schedule_heartbeat_stores_row() -> None:
    sched, store, _ = _sched()
    row = await sched.schedule_heartbeat(
        user_id="u2",
        thread_key=None,
        channel="fake://api",
        prompt="Ping",
        interval_s=30,
    )
    fetched = await store.get(row.id)
    assert fetched is not None
    assert fetched.kind == "heartbeat"
    assert fetched.spec == "30"


@pytest.mark.asyncio
async def test_schedule_heartbeat_max_fires_stored() -> None:
    sched, store, _ = _sched()
    row = await sched.schedule_heartbeat(
        user_id="u2",
        thread_key=None,
        channel="fake://api",
        prompt="Limited",
        interval_s=30,
        max_fires=5,
    )
    fetched = await store.get(row.id)
    assert fetched is not None
    assert fetched.max_fires == 5


# ---------------------------------------------------------------------------
# schedule_cron
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_schedule_cron_stores_row() -> None:
    sched, store, _ = _sched()
    row = await sched.schedule_cron(
        user_id="u3",
        thread_key=None,
        channel="fake://api",
        prompt="Daily",
        expression="0 9 * * *",
        timezone="UTC",
    )
    fetched = await store.get(row.id)
    assert fetched is not None
    assert fetched.kind == "cron"
    assert "0 9 * * *" in fetched.spec
    assert "UTC" in fetched.spec


# ---------------------------------------------------------------------------
# cancel_trigger
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cancel_trigger_sets_cancelled_status() -> None:
    sched, store, _ = _sched()
    row = await sched.schedule_once(
        user_id="u4",
        thread_key=None,
        channel="fake://api",
        prompt="Cancel me",
        delta=timedelta(hours=1),
    )
    result = await sched.cancel_trigger(row.id)
    assert result is True

    fetched = await store.get(row.id)
    assert fetched is not None
    assert fetched.status == "cancelled"


@pytest.mark.asyncio
async def test_cancel_trigger_returns_false_for_missing() -> None:
    sched, _, _ = _sched()
    result = await sched.cancel_trigger("DOES-NOT-EXIST")
    assert result is False


@pytest.mark.asyncio
async def test_cancel_trigger_with_owner_enforces_s1() -> None:
    """cancel_trigger with wrong owner_user_id returns False (S1)."""
    sched, store, _ = _sched()
    row = await sched.schedule_once(
        user_id="u4",
        thread_key=None,
        channel="fake://api",
        prompt="Mine",
        delta=timedelta(hours=1),
    )
    await sched.cancel_trigger(row.id, owner_user_id="u-other")
    # cancel with wrong owner should be a no-op → row still active
    fetched = await store.get(row.id)
    assert fetched is not None
    assert fetched.status == "active"


# ---------------------------------------------------------------------------
# cancel_trigger_by_name
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cancel_trigger_by_name() -> None:
    sched, store, _ = _sched()
    row = await sched.schedule_once(
        user_id="u5",
        thread_key=None,
        channel="fake://api",
        prompt="Named",
        delta=timedelta(hours=1),
        name="my-trigger",
    )
    count = await sched.cancel_trigger_by_name("u5", "my-trigger")
    assert count == 1

    fetched = await store.get(row.id)
    assert fetched is not None
    assert fetched.status == "cancelled"


@pytest.mark.asyncio
async def test_cancel_trigger_by_name_missing_returns_zero() -> None:
    sched, _, _ = _sched()
    count = await sched.cancel_trigger_by_name("u5", "no-such-trigger")
    assert count == 0


# ---------------------------------------------------------------------------
# list_triggers
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_triggers_returns_only_queried_user() -> None:
    sched, store, _ = _sched()
    await sched.schedule_once(
        user_id="ua",
        thread_key=None,
        channel="fake://api",
        prompt="A1",
        delta=timedelta(hours=1),
    )
    await sched.schedule_once(
        user_id="ua",
        thread_key=None,
        channel="fake://api",
        prompt="A2",
        delta=timedelta(hours=2),
    )
    await sched.schedule_once(
        user_id="ub",
        thread_key=None,
        channel="fake://api",
        prompt="B1",
        delta=timedelta(hours=1),
    )

    rows_a = await sched.list_triggers("ua")
    rows_b = await sched.list_triggers("ub")

    assert len(rows_a) == 2
    assert all(r.user_id == "ua" for r in rows_a)
    assert len(rows_b) == 1
    assert rows_b[0].user_id == "ub"


# ---------------------------------------------------------------------------
# get_trigger
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_trigger_returns_row() -> None:
    sched, _, _ = _sched()
    row = await sched.schedule_once(
        user_id="u6",
        thread_key=None,
        channel="fake://api",
        prompt="Getme",
        delta=timedelta(hours=1),
    )
    fetched = await sched.get_trigger(row.id)
    assert fetched is not None
    assert fetched.id == row.id


@pytest.mark.asyncio
async def test_get_trigger_with_wrong_owner_returns_none() -> None:
    sched, _, _ = _sched()
    row = await sched.schedule_once(
        user_id="u6",
        thread_key=None,
        channel="fake://api",
        prompt="Secret",
        delta=timedelta(hours=1),
    )
    result = await sched.get_trigger(row.id, owner_user_id="u-other")
    assert result is None


# ---------------------------------------------------------------------------
# Named upsert does not double-count per-user limit
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_named_upsert_does_not_double_count() -> None:
    """Re-scheduling same name should update in place, not count as a new trigger."""
    sched, store, _ = _sched()
    # Create trigger with name.
    await sched.schedule_once(
        user_id="u7",
        thread_key=None,
        channel="fake://api",
        prompt="First",
        delta=timedelta(hours=1),
        name="daily-brief",
    )
    # Update same name.
    await sched.schedule_once(
        user_id="u7",
        thread_key=None,
        channel="fake://api",
        prompt="Updated",
        delta=timedelta(hours=2),
        name="daily-brief",
    )
    # Both calls should succeed; only 1 row.
    rows = await store.list("u7")
    assert len(rows) == 1
    assert rows[0].prompt == "Updated"
    # Count still 1.
    count = await store.count_active("u7")
    assert count == 1
