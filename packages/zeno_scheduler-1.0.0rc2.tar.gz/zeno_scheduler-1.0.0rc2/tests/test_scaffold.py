"""Smoke tests for the zeno-scheduler scaffold (U1)."""

from __future__ import annotations

import dataclasses

import pytest
from zeno.scheduler import ScheduleError, ScheduleLimitError, TriggerRow


def test_imports() -> None:
    """Public symbols are importable from zeno.scheduler."""
    assert ScheduleError is not None
    assert ScheduleLimitError is not None
    assert TriggerRow is not None


def test_schedule_limit_error_is_subclass_of_schedule_error() -> None:
    """ScheduleLimitError must extend ScheduleError for broad except clauses."""
    assert issubclass(ScheduleLimitError, ScheduleError)

    err = ScheduleLimitError("max_active_triggers (10) reached")
    assert isinstance(err, ScheduleError)
    assert "Cannot schedule:" in str(err)
    assert err.reason == "max_active_triggers (10) reached"


def test_trigger_row_is_frozen() -> None:
    """TriggerRow is a frozen dataclass — mutation must raise FrozenInstanceError."""
    row = TriggerRow(
        id="01JTEST",
        user_id="user-1",
        thread_key=None,
        channel_ref="cli://default",
        kind="one_shot",
        name="my trigger",
        prompt="Say hello",
        metadata={},
        spec="@once",
        next_fire_at=1_700_000_000,
        fire_count=0,
        max_fires=1,
        on_missed="drop",
        status="active",
        created_at=1_700_000_000,
    )

    with pytest.raises(dataclasses.FrozenInstanceError):
        row.fire_count = 1  # type: ignore[misc]
