"""Unit tests for zeno.scheduler.kinds — compute_next_fire dispatch.

All tests are synchronous and pure; no real I/O, no real sleeps.
Because ``compute_next_fire`` accepts ``now`` as an explicit parameter, no
clock-mocking library is required — we just pass the desired instant.
"""

from __future__ import annotations

from datetime import UTC, datetime

import pytest
from zeno.scheduler.exceptions import ScheduleError
from zeno.scheduler.kinds import compute_next_fire
from zeno.scheduler.types import TriggerRow

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_row(
    *,
    kind: str = "one_shot",
    spec: str = "2026-05-01T12:00:00Z",
    fire_count: int = 0,
    max_fires: int | None = None,
    on_missed: str = "drop",
) -> TriggerRow:
    """Construct a minimal TriggerRow for testing."""
    return TriggerRow(
        id="01JTEST000000000000000000",
        user_id="user-1",
        thread_key=None,
        channel_ref="cli://default",
        kind=kind,  # type: ignore[arg-type]
        name=None,
        prompt="test",
        metadata={},
        spec=spec,
        next_fire_at=0,
        fire_count=fire_count,
        max_fires=max_fires,
        on_missed=on_missed,  # type: ignore[arg-type]
        status="active",
        created_at=0,
    )


def _utc(year: int, month: int, day: int, hour: int = 0, minute: int = 0) -> datetime:
    """Shorthand for a UTC-aware datetime."""
    return datetime(year, month, day, hour, minute, tzinfo=UTC)


# ---------------------------------------------------------------------------
# one_shot — happy path
# ---------------------------------------------------------------------------


class TestOneShotHappyPath:
    def test_fire_count_0_returns_scheduled_time(self) -> None:
        row = _make_row(kind="one_shot", spec="2026-05-01T12:00:00Z", fire_count=0)
        now = _utc(2026, 5, 1, 11, 0)
        result = compute_next_fire(row, now)
        assert result == _utc(2026, 5, 1, 12, 0)

    def test_fire_count_1_returns_none(self) -> None:
        row = _make_row(kind="one_shot", spec="2026-05-01T12:00:00Z", fire_count=1)
        now = _utc(2026, 5, 1, 13, 0)
        assert compute_next_fire(row, now) is None

    def test_fire_count_0_missed_returns_spec_time_not_now(self) -> None:
        """Missed one_shot (spec is 10 min past): return original spec time, not now."""
        row = _make_row(kind="one_shot", spec="2026-05-01T12:00:00Z", fire_count=0)
        now = _utc(2026, 5, 1, 12, 10)  # 10 min past the scheduled time
        result = compute_next_fire(row, now)
        # Must return the scheduled target time, not now.
        assert result == _utc(2026, 5, 1, 12, 0)

    def test_result_is_utc_aware(self) -> None:
        row = _make_row(kind="one_shot", spec="2026-05-01T12:00:00Z", fire_count=0)
        result = compute_next_fire(row, _utc(2026, 5, 1, 11, 0))
        assert result is not None
        assert result.tzinfo is not None
        assert result.utcoffset() is not None

    def test_on_missed_fire_preserves_scheduled_for_integrity(self) -> None:
        """on_missed='fire' with one_shot still returns spec time (not now)."""
        row = _make_row(
            kind="one_shot",
            spec="2026-05-01T12:00:00Z",
            fire_count=0,
            on_missed="fire",
        )
        now = _utc(2026, 5, 1, 12, 10)
        result = compute_next_fire(row, now)
        assert result == _utc(2026, 5, 1, 12, 0)


# ---------------------------------------------------------------------------
# heartbeat — happy path
# ---------------------------------------------------------------------------


class TestHeartbeatHappyPath:
    def test_fire_count_0_returns_now_plus_interval(self) -> None:
        row = _make_row(kind="heartbeat", spec="300", fire_count=0)
        t0 = _utc(2026, 5, 1, 10, 0)
        result = compute_next_fire(row, t0)
        from datetime import timedelta

        assert result == t0 + timedelta(seconds=300)

    def test_fire_count_below_max_fires_returns_now_plus_interval(self) -> None:
        row = _make_row(kind="heartbeat", spec="300", fire_count=2, max_fires=3)
        now = _utc(2026, 5, 1, 10, 0)
        from datetime import timedelta

        assert compute_next_fire(row, now) == now + timedelta(seconds=300)

    def test_fire_count_equals_max_fires_returns_none(self) -> None:
        row = _make_row(kind="heartbeat", spec="300", fire_count=3, max_fires=3)
        now = _utc(2026, 5, 1, 10, 0)
        assert compute_next_fire(row, now) is None

    def test_no_max_fires_runs_indefinitely(self) -> None:
        row = _make_row(kind="heartbeat", spec="300", fire_count=9999, max_fires=None)
        now = _utc(2026, 5, 1, 10, 0)
        from datetime import timedelta

        result = compute_next_fire(row, now)
        assert result == now + timedelta(seconds=300)

    def test_coalesce_outage_gives_one_fire_not_many(self) -> None:
        """Interval=300s, last-fired 60 min ago → returns now+300s (no N catch-ups)."""
        from datetime import timedelta

        row = _make_row(kind="heartbeat", spec="300", fire_count=0, on_missed="coalesce")
        now = _utc(2026, 5, 1, 11, 0)  # 60 min after epoch-zero
        result = compute_next_fire(row, now)
        assert result == now + timedelta(seconds=300)

    def test_result_is_utc_aware(self) -> None:
        row = _make_row(kind="heartbeat", spec="300", fire_count=0)
        result = compute_next_fire(row, _utc(2026, 5, 1, 10, 0))
        assert result is not None
        assert result.tzinfo is not None


# ---------------------------------------------------------------------------
# cron — basic UTC
# ---------------------------------------------------------------------------


class TestCronBasicUTC:
    def test_next_occurrence_utc(self) -> None:
        """spec='0 9 * * *|UTC', now just before 9am: returns 9am today."""
        row = _make_row(kind="cron", spec="0 9 * * *|UTC", on_missed="drop")
        now = _utc(2026, 5, 1, 8, 59)
        result = compute_next_fire(row, now)
        assert result == _utc(2026, 5, 1, 9, 0)

    def test_daily_macro_equals_explicit(self) -> None:
        """@daily|UTC should produce the same result as 0 0 * * *|UTC."""
        now = _utc(2026, 5, 1, 23, 0)
        row_macro = _make_row(kind="cron", spec="@daily|UTC", on_missed="drop")
        row_explicit = _make_row(kind="cron", spec="0 0 * * *|UTC", on_missed="drop")
        assert compute_next_fire(row_macro, now) == compute_next_fire(row_explicit, now)

    def test_hourly_macro(self) -> None:
        row = _make_row(kind="cron", spec="@hourly|UTC", on_missed="drop")
        now = _utc(2026, 5, 1, 8, 30)
        result = compute_next_fire(row, now)
        assert result == _utc(2026, 5, 1, 9, 0)

    def test_weekly_macro(self) -> None:
        row = _make_row(kind="cron", spec="@weekly|UTC", on_missed="drop")
        # 2026-05-01 is a Friday; next Sunday (day 0) is 2026-05-03
        now = _utc(2026, 5, 1, 1, 0)
        result = compute_next_fire(row, now)
        assert result is not None
        assert result.weekday() == 6  # Sunday

    def test_result_is_utc_aware(self) -> None:
        row = _make_row(kind="cron", spec="0 9 * * *|UTC", on_missed="drop")
        result = compute_next_fire(row, _utc(2026, 5, 1, 8, 0))
        assert result is not None
        assert result.tzinfo is not None
        assert result.utcoffset() is not None


# ---------------------------------------------------------------------------
# cron — timezone + DST
# ---------------------------------------------------------------------------


class TestCronTimezone:
    def test_la_pdt_offset(self) -> None:
        """LA in May (PDT = UTC-7): 9am LA = 16:00 UTC."""
        row = _make_row(kind="cron", spec="0 9 * * *|America/Los_Angeles", on_missed="drop")
        now = _utc(2026, 5, 15, 0, 0)
        result = compute_next_fire(row, now)
        assert result == _utc(2026, 5, 15, 16, 0)  # PDT: UTC-7 → 9am LA = 16:00 UTC

    def test_ny_est_offset(self) -> None:
        """NY in January (EST = UTC-5): 9am NY = 14:00 UTC."""
        row = _make_row(kind="cron", spec="0 9 * * *|America/New_York", on_missed="drop")
        now = _utc(2026, 1, 15, 0, 0)
        result = compute_next_fire(row, now)
        assert result == _utc(2026, 1, 15, 14, 0)  # EST: UTC-5 → 9am NY = 14:00 UTC

    def test_dst_spring_forward_la_2026_03_08(self) -> None:
        """DST spring-forward: 2am doesn't exist on 2026-03-08 in LA.

        Croniter skips the non-existent 2am and advances to 3am on the same day
        (the spring-forward behaviour).  After that, the following day's 2am
        fires normally at 2026-03-09 09:00Z (PDT = UTC-7).

        The spec says 'just let it through': we trust croniter to handle the
        gap and do NOT special-case the skipped hour.

        now = 2026-03-08 09:00Z = 01:00 PST (before the 2am gap).
        First get_next → 03:00 PDT on 3-08 = 10:00Z (spring-forward, no 2am fire).
        """
        row = _make_row(kind="cron", spec="0 2 * * *|America/Los_Angeles", on_missed="drop")
        now = _utc(2026, 3, 8, 9, 0)  # 01:00 PST, before the DST gap

        result = compute_next_fire(row, now)
        assert result is not None

        # croniter naturally skips the non-existent 2am → lands at 3:00 PDT
        # = 2026-03-08 10:00 UTC.  No fire occurs at 2am on the spring-forward day.
        assert result == _utc(2026, 3, 8, 10, 0), (
            f"Expected 2026-03-08 10:00Z (3am PDT, spring-forward skip), got {result}"
        )

    def test_dst_spring_forward_next_day_fires_at_2am(self) -> None:
        """After the spring-forward day, 2am fires normally next day."""
        row = _make_row(kind="cron", spec="0 2 * * *|America/Los_Angeles", on_missed="drop")
        # Set now to just after the 3am spring-fwd fire on 3-08 (10:00Z)
        now = _utc(2026, 3, 8, 10, 1)  # just past the spring-fwd fire
        result = compute_next_fire(row, now)
        assert result is not None
        # Next real 2am in PDT (UTC-7) is 2026-03-09 02:00 PDT = 09:00Z
        assert result == _utc(2026, 3, 9, 9, 0), (
            f"Expected 2026-03-09 09:00Z (2am PDT), got {result}"
        )

    def test_dst_fall_back_la_2026_11_01_uses_post_dst_occurrence(self) -> None:
        """DST fall-back: 1:30am repeats on 2026-11-01 in LA.

        now = 2026-11-01 07:00Z = midnight PDT (UTC-7).
        The cron '30 1 * * *' fires at 1:30am local time.
        On fall-back day, 1:30am occurs twice:
          - First  (PDT, fold=0): 1:30am PDT = UTC 08:30
          - Second (PST, fold=1): 1:30am PST = UTC 09:30

        The spec mandates fold=1 (post-DST, standard time occurrence).
        Expected result: 2026-11-01 09:30Z.
        """
        row = _make_row(kind="cron", spec="30 1 * * *|America/Los_Angeles", on_missed="drop")
        now = _utc(2026, 11, 1, 7, 0)  # 2026-11-01 00:00 PDT

        result = compute_next_fire(row, now)
        assert result is not None

        expected_utc = _utc(2026, 11, 1, 9, 30)  # PST 1:30am = UTC 09:30
        assert result == expected_utc, (
            f"Expected post-DST occurrence at 09:30Z (PST 1:30am, fold=1), got {result}"
        )


# ---------------------------------------------------------------------------
# cron — missed-fire policy
# ---------------------------------------------------------------------------


class TestCronMissedFire:
    def test_on_missed_fire_returns_missed_slot(self) -> None:
        """on_missed='fire': woke at 15:00Z having missed 09:00Z → return 09:00Z."""
        row = _make_row(kind="cron", spec="0 9 * * *|UTC", on_missed="fire")
        now = _utc(2026, 5, 1, 15, 0)
        result = compute_next_fire(row, now)
        assert result == _utc(2026, 5, 1, 9, 0)

    def test_on_missed_fire_subsequent_call_advances_past_now(self) -> None:
        """After firing missed slot, next call (with updated now) returns tomorrow."""
        row = _make_row(kind="cron", spec="0 9 * * *|UTC", on_missed="fire")
        # Simulate: missed slot fired at 09:00, now update now to 15:01
        now = _utc(2026, 5, 1, 15, 1)
        # After the fire, on_missed='fire' again: get_prev gives 09:00 (≤ now) → fires again?
        # No — after advancing, the store calls compute_next_fire with now=15:01 still.
        # But wait: the worker will have already fired 09:00 and calls compute_next_fire
        # again with the same or updated now. get_prev(15:01) still gives 09:00Z.
        # The worker loop (U4) is responsible for advancing fire_count and updating
        # next_fire_at; this function is pure.  Here we just test that the missed
        # slot is returned (same behaviour at 15:00 and 15:01 without state change).
        result = compute_next_fire(row, now)
        assert result == _utc(2026, 5, 1, 9, 0)

    def test_on_missed_drop_returns_next_future_occurrence(self) -> None:
        """on_missed='drop': skip the missed slot, return next > now."""
        row = _make_row(kind="cron", spec="0 9 * * *|UTC", on_missed="drop")
        now = _utc(2026, 5, 1, 15, 0)
        result = compute_next_fire(row, now)
        assert result == _utc(2026, 5, 2, 9, 0)

    def test_on_missed_default_is_drop_for_cron(self) -> None:
        """Default on_missed='drop' skips past occurrences."""
        row = _make_row(kind="cron", spec="0 9 * * *|UTC", on_missed="drop")
        now = _utc(2026, 5, 1, 15, 0)
        result = compute_next_fire(row, now)
        assert result == _utc(2026, 5, 2, 9, 0)

    def test_on_missed_fire_exact_now_match(self) -> None:
        """on_missed='fire': when now is 1 second past the scheduled time, fire the slot.

        croniter.get_prev() treats now as an *exclusive* boundary — so when
        now == cron_time exactly, get_prev() gives the *previous* occurrence,
        not today's.  We therefore use now = 09:00:01 to ensure get_prev()
        returns today's 09:00 and the condition candidate_utc <= now holds.
        """
        row = _make_row(kind="cron", spec="0 9 * * *|UTC", on_missed="fire")
        # 1 second past: ensures get_prev gives today's 09:00 (< now)
        now = datetime(2026, 5, 1, 9, 0, 1, tzinfo=UTC)
        result = compute_next_fire(row, now)
        assert result == _utc(2026, 5, 1, 9, 0)


# ---------------------------------------------------------------------------
# Error cases
# ---------------------------------------------------------------------------


class TestErrors:
    def test_invalid_cron_expression_raises_schedule_error(self) -> None:
        row = _make_row(kind="cron", spec="bad expression|UTC", on_missed="drop")
        with pytest.raises(ScheduleError, match="Invalid cron expression"):
            compute_next_fire(row, _utc(2026, 5, 1))

    def test_unknown_timezone_raises_schedule_error(self) -> None:
        row = _make_row(kind="cron", spec="0 9 * * *|Not/ATimezone", on_missed="drop")
        with pytest.raises(ScheduleError, match="Unknown timezone"):
            compute_next_fire(row, _utc(2026, 5, 1))

    def test_missing_pipe_in_cron_spec_raises_schedule_error(self) -> None:
        """Cron spec without '|<tz>' must raise a helpful ScheduleError."""
        row = _make_row(kind="cron", spec="0 9 * * *", on_missed="drop")
        with pytest.raises(ScheduleError, match="Invalid cron spec"):
            compute_next_fire(row, _utc(2026, 5, 1))

    def test_invalid_heartbeat_spec_raises_schedule_error(self) -> None:
        row = _make_row(kind="heartbeat", spec="not_a_number", fire_count=0)
        with pytest.raises(ScheduleError, match="Invalid heartbeat spec"):
            compute_next_fire(row, _utc(2026, 5, 1))

    def test_zero_heartbeat_interval_raises_schedule_error(self) -> None:
        row = _make_row(kind="heartbeat", spec="0", fire_count=0)
        with pytest.raises(ScheduleError):
            compute_next_fire(row, _utc(2026, 5, 1))

    def test_invalid_one_shot_spec_raises_schedule_error(self) -> None:
        row = _make_row(kind="one_shot", spec="not-a-date", fire_count=0)
        with pytest.raises(ScheduleError, match="Invalid one_shot spec"):
            compute_next_fire(row, _utc(2026, 5, 1))

    def test_naive_now_raises_schedule_error(self) -> None:
        """Passing a naive (tz-unaware) now must raise ScheduleError."""
        row = _make_row(kind="one_shot", spec="2026-05-01T12:00:00Z", fire_count=0)
        naive_now = datetime(2026, 5, 1, 11, 0)  # no tzinfo
        with pytest.raises(ScheduleError):
            compute_next_fire(row, naive_now)
