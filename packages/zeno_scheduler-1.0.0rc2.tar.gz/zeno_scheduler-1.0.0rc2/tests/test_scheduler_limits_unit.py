"""Unit tests for Scheduler limit enforcement (S2, S7, interval, lead time, cron validity)."""

from __future__ import annotations

import asyncio
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from _fakes import FakeChannel
from zeno.scheduler.exceptions import ScheduleError, ScheduleLimitError
from zeno.scheduler.scheduler import Scheduler
from zeno.scheduler.sqlite.store import SqliteScheduleStore
from zeno.scheduler.testing import InMemoryScheduleStore
from zeno.scheduler.types import TriggerRow

_BASE = datetime(2025, 6, 1, 12, 0, 0, tzinfo=UTC)

_CHANNEL = "fake://limits"
_USER = "limiter"


def _make_scheduler(
    *,
    max_triggers: int = 50,
    min_interval_s: int = 60,
    max_lead_days: int = 365,
    max_prompt_length: int = 4096,
    store: InMemoryScheduleStore | None = None,
) -> Scheduler:
    s = store or InMemoryScheduleStore()
    ch = FakeChannel(name=_CHANNEL)
    return Scheduler(
        s,
        {_CHANNEL: ch},
        None,
        now_fn=lambda: _BASE,
        max_triggers_per_user=max_triggers,
        min_interval_s=min_interval_s,
        max_lead_days=max_lead_days,
        max_prompt_length=max_prompt_length,
    )


# ---------------------------------------------------------------------------
# S2 — prompt length
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_prompt_too_long_schedule_once() -> None:
    sched = _make_scheduler()
    with pytest.raises(ScheduleLimitError, match="prompt exceeds 4096 characters"):
        await sched.schedule_once(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="x" * 4097,
            delta=timedelta(hours=1),
        )


@pytest.mark.asyncio
async def test_prompt_exactly_at_limit_is_ok() -> None:
    sched = _make_scheduler()
    # Should not raise.
    row = await sched.schedule_once(
        user_id=_USER,
        thread_key=None,
        channel=_CHANNEL,
        prompt="x" * 4096,
        delta=timedelta(hours=1),
    )
    assert row is not None


@pytest.mark.asyncio
async def test_prompt_too_long_heartbeat() -> None:
    sched = _make_scheduler()
    with pytest.raises(ScheduleLimitError, match="prompt exceeds 4096 characters"):
        await sched.schedule_heartbeat(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="y" * 5000,
            interval_s=60,
        )


@pytest.mark.asyncio
async def test_prompt_too_long_cron() -> None:
    sched = _make_scheduler()
    with pytest.raises(ScheduleLimitError, match="prompt exceeds 4096 characters"):
        await sched.schedule_cron(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="z" * 4097,
            expression="0 9 * * *",
        )


# ---------------------------------------------------------------------------
# Minimum interval — heartbeat
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_heartbeat_interval_too_short_raises() -> None:
    sched = _make_scheduler(min_interval_s=60)
    with pytest.raises(ScheduleLimitError, match="minimum 60s"):
        await sched.schedule_heartbeat(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="Fast",
            interval_s=30,
        )


@pytest.mark.asyncio
async def test_heartbeat_interval_exact_minimum_is_ok() -> None:
    sched = _make_scheduler(min_interval_s=60)
    row = await sched.schedule_heartbeat(
        user_id=_USER,
        thread_key=None,
        channel=_CHANNEL,
        prompt="OK",
        interval_s=60,
    )
    assert row is not None


# ---------------------------------------------------------------------------
# Minimum interval — cron
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cron_too_fast_raises_limit_error() -> None:
    """A 6-field every-30s cron raises ScheduleLimitError."""
    sched = _make_scheduler(min_interval_s=60)
    with pytest.raises(ScheduleLimitError):
        await sched.schedule_cron(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="Too fast",
            expression="*/30 * * * * *",
        )


@pytest.mark.asyncio
async def test_cron_every_minute_is_ok() -> None:
    """``* * * * *`` fires every 60s, which meets the 60s minimum."""
    sched = _make_scheduler(min_interval_s=60)
    row = await sched.schedule_cron(
        user_id=_USER,
        thread_key=None,
        channel=_CHANNEL,
        prompt="Every minute",
        expression="* * * * *",
    )
    assert row is not None


# ---------------------------------------------------------------------------
# Lead time — one_shot
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_lead_time_too_far_raises() -> None:
    sched = _make_scheduler(max_lead_days=365)
    with pytest.raises(ScheduleLimitError, match="maximum 365 days lead time"):
        await sched.schedule_once(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="Far future",
            at=_BASE + timedelta(days=400),
        )


@pytest.mark.asyncio
async def test_lead_time_exact_max_is_ok() -> None:
    sched = _make_scheduler(max_lead_days=365)
    row = await sched.schedule_once(
        user_id=_USER,
        thread_key=None,
        channel=_CHANNEL,
        prompt="Just within limit",
        at=_BASE + timedelta(days=365),
    )
    assert row is not None


# ---------------------------------------------------------------------------
# Invalid cron expression → ScheduleError (not ScheduleLimitError)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_invalid_cron_expression_raises_schedule_error() -> None:
    sched = _make_scheduler()
    with pytest.raises(ScheduleError) as exc_info:
        await sched.schedule_cron(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="Bad cron",
            expression="NOT_A_CRON",
        )
    # Must be ScheduleError, NOT ScheduleLimitError.
    assert type(exc_info.value) is ScheduleError


@pytest.mark.asyncio
async def test_invalid_timezone_raises_schedule_error() -> None:
    sched = _make_scheduler()
    with pytest.raises(ScheduleError, match="Unknown timezone"):
        await sched.schedule_cron(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="Bad tz",
            expression="0 9 * * *",
            timezone="Not/ATimezone",
        )


# ---------------------------------------------------------------------------
# S7 — per-user trigger count (51st trigger)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_51st_trigger_raises_limit_error() -> None:
    """Inserting the 51st trigger for a user raises ScheduleLimitError."""
    store = InMemoryScheduleStore()
    sched = _make_scheduler(max_triggers=50, store=store)

    for i in range(50):
        await sched.schedule_once(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt=f"Trigger {i}",
            delta=timedelta(hours=i + 1),
        )

    with pytest.raises(ScheduleLimitError) as exc_info:
        await sched.schedule_once(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="One too many",
            delta=timedelta(hours=100),
        )
    assert "50 active triggers" in str(exc_info.value)


# ---------------------------------------------------------------------------
# S7 — atomic race: two concurrent calls at positions 49/50
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_s7_atomic_race_exactly_one_succeeds() -> None:
    """Concurrent schedule_once at positions 49 and 50 → exactly one ScheduleLimitError."""
    # Use InMemoryScheduleStore which serializes under asyncio.Lock (S7).
    store = InMemoryScheduleStore()
    sched = _make_scheduler(max_triggers=50, store=store)

    # Pre-fill 49 triggers.
    for i in range(49):
        await sched.schedule_once(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt=f"Pre-fill {i}",
            delta=timedelta(hours=i + 1),
        )

    # Two concurrent calls compete for the 50th slot.
    results = await asyncio.gather(
        sched.schedule_once(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="Race A",
            delta=timedelta(hours=100),
        ),
        sched.schedule_once(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="Race B",
            delta=timedelta(hours=101),
        ),
        return_exceptions=True,
    )

    successes = [r for r in results if isinstance(r, TriggerRow)]
    failures = [r for r in results if isinstance(r, ScheduleLimitError)]

    assert len(successes) == 1, f"Expected exactly 1 success, got: {results}"
    assert len(failures) == 1, f"Expected exactly 1 failure, got: {results}"


# ---------------------------------------------------------------------------
# S7 — atomic race with SQLite BEGIN IMMEDIATE
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_s7_sqlite_race_exactly_one_succeeds() -> None:
    """SQLite BEGIN IMMEDIATE prevents double-insert under concurrent asyncio tasks."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test_race.db"
        store = SqliteScheduleStore(db_path)
        # Initialize schema.
        await store.count_active("__init__")

        ch = FakeChannel(name=_CHANNEL)
        sched = Scheduler(
            store,
            {_CHANNEL: ch},
            None,
            now_fn=lambda: _BASE,
            max_triggers_per_user=50,
            min_interval_s=60,
        )

        # Pre-fill 49 triggers directly in the store.
        for i in range(49):
            await sched.schedule_once(
                user_id=_USER,
                thread_key=None,
                channel=_CHANNEL,
                prompt=f"Pre-fill {i}",
                delta=timedelta(hours=i + 1),
            )

        # Concurrent race for the 50th slot.
        results = await asyncio.gather(
            sched.schedule_once(
                user_id=_USER,
                thread_key=None,
                channel=_CHANNEL,
                prompt="SQLite Race A",
                delta=timedelta(hours=100),
            ),
            sched.schedule_once(
                user_id=_USER,
                thread_key=None,
                channel=_CHANNEL,
                prompt="SQLite Race B",
                delta=timedelta(hours=101),
            ),
            return_exceptions=True,
        )

        successes = [r for r in results if isinstance(r, TriggerRow)]
        failures = [r for r in results if isinstance(r, ScheduleLimitError)]

        assert len(successes) == 1
        assert len(failures) == 1


# ---------------------------------------------------------------------------
# Named upsert does not double-count per-user limit
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_named_upsert_does_not_count_twice() -> None:
    """Same-name re-schedule is an update, not a new insert; count stays stable."""
    store = InMemoryScheduleStore()
    sched = _make_scheduler(max_triggers=2, store=store)

    # First insert: count goes to 1.
    await sched.schedule_once(
        user_id=_USER,
        thread_key=None,
        channel=_CHANNEL,
        prompt="First",
        delta=timedelta(hours=1),
        name="named-trigger",
    )
    # Second insert with same name: count stays at 1 (upsert).
    await sched.schedule_once(
        user_id=_USER,
        thread_key=None,
        channel=_CHANNEL,
        prompt="Updated",
        delta=timedelta(hours=2),
        name="named-trigger",
    )
    count = await store.count_active(_USER)
    assert count == 1

    # Third insert with a DIFFERENT name: count goes to 2, still within limit.
    await sched.schedule_once(
        user_id=_USER,
        thread_key=None,
        channel=_CHANNEL,
        prompt="Third",
        delta=timedelta(hours=3),
        name="other-trigger",
    )
    count = await store.count_active(_USER)
    assert count == 2

    # Fourth insert would push over max_triggers=2.
    with pytest.raises(ScheduleLimitError):
        await sched.schedule_once(
            user_id=_USER,
            thread_key=None,
            channel=_CHANNEL,
            prompt="Over limit",
            delta=timedelta(hours=4),
            name="yet-another",
        )
