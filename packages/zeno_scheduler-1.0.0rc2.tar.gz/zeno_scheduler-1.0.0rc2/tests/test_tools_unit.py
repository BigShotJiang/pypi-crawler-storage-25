"""Unit tests for zeno-scheduler built-in tools (U5).

Tests cover the six @tool functions:
  schedule_once, schedule_heartbeat, schedule_cron,
  cancel_trigger, cancel_trigger_by_name, list_triggers

Provider-loop integration (OpenAIProvider end-to-end) is intentionally
deferred to U7's reference app, which wires the full stack together.
"""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
from _fakes import FakeChannel
from zeno.context import Ctx
from zeno.scheduler.scheduler import Scheduler
from zeno.scheduler.testing import InMemoryScheduleStore
from zeno.scheduler.tools import (
    cancel_trigger,
    cancel_trigger_by_name,
    list_triggers,
    schedule_cron,
    schedule_heartbeat,
    schedule_once,
)

# ---------------------------------------------------------------------------
# Fixed clock: 2026-01-01 noon UTC
# ---------------------------------------------------------------------------

_BASE = datetime(2026, 1, 1, 12, 0, 0, tzinfo=UTC)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_scheduler(
    channel_name: str = "test",
    *,
    max_triggers_per_user: int = 50,
    min_interval_s: int = 60,
) -> tuple[Scheduler, InMemoryScheduleStore, FakeChannel]:
    store = InMemoryScheduleStore()
    channel = FakeChannel(name=channel_name)
    clock = [_BASE]
    sched = Scheduler(
        store,
        {channel.name: channel},
        None,  # ctx_factory reserved for U6
        now_fn=lambda: clock[0],
        max_triggers_per_user=max_triggers_per_user,
        min_interval_s=min_interval_s,
    )
    return sched, store, channel


def _make_ctx(
    scheduler: Scheduler | None,
    user_id: str = "alice",
    channel_name: str = "test",
    thread_key: str | None = "main",
) -> Ctx:
    transport = httpx.MockTransport(lambda req: httpx.Response(200))
    http = httpx.AsyncClient(transport=transport)
    return Ctx(
        user_id=user_id,
        session_id=None,
        channel=channel_name,
        memory=MagicMock(),
        reply=AsyncMock(),
        stream=AsyncMock(),
        finalize=AsyncMock(),
        http=http,
        logger=MagicMock(),
        tracer=MagicMock(),
        state={"scheduler": scheduler},
        thread_key=thread_key,
    )


# ---------------------------------------------------------------------------
# Happy: schedule_once with delta
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_schedule_once_delta_happy() -> None:
    sched, store, _ = _make_scheduler()
    ctx = _make_ctx(sched)

    result = await schedule_once(ctx, prompt="Say hello", delta="30m")

    # Return string must mention trigger id, ISO timestamp, channel.
    assert "trigger_id:" in result
    assert "2026-01-01T12:30:00Z" in result
    assert "test" in result

    # Exactly one row in the store.
    rows = await store.list("alice")
    assert len(rows) == 1
    assert rows[0].kind == "one_shot"
    assert rows[0].prompt == "Say hello"


# ---------------------------------------------------------------------------
# Happy: schedule_once with at (absolute datetime)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_schedule_once_at_happy() -> None:
    sched, store, _ = _make_scheduler()
    ctx = _make_ctx(sched)

    result = await schedule_once(ctx, prompt="Meeting reminder", at="2026-05-01T09:00:00Z")

    assert "trigger_id:" in result
    assert "2026-05-01T09:00:00Z" in result

    rows = await store.list("alice")
    assert len(rows) == 1
    assert rows[0].next_fire_at == int(datetime(2026, 5, 1, 9, 0, 0, tzinfo=UTC).timestamp())


# ---------------------------------------------------------------------------
# Happy: schedule_cron persists expression and timezone
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_schedule_cron_persists_expr_and_timezone() -> None:
    sched, store, _ = _make_scheduler()
    ctx = _make_ctx(sched)

    result = await schedule_cron(
        ctx, prompt="Daily briefing", expression="0 9 * * *", timezone="Europe/Amsterdam"
    )

    assert "trigger_id:" in result
    assert "0 9 * * *" in result
    assert "Europe/Amsterdam" in result

    rows = await store.list("alice")
    assert len(rows) == 1
    row = rows[0]
    assert row.kind == "cron"
    # spec format is "<expression>|<timezone>"
    assert "0 9 * * *" in row.spec
    assert "Europe/Amsterdam" in row.spec


# ---------------------------------------------------------------------------
# Happy: cancel_trigger_by_name — existing trigger
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cancel_trigger_by_name_existing() -> None:
    sched, store, _ = _make_scheduler()
    ctx = _make_ctx(sched)

    await schedule_once(ctx, prompt="named reminder", delta="1h", name="daily-check")

    result = await cancel_trigger_by_name(ctx, name="daily-check")

    assert "Cancelled 1" in result
    assert "daily-check" in result

    # The trigger should now be cancelled.
    rows = await store.list("alice")
    assert len(rows) == 0


# ---------------------------------------------------------------------------
# Happy: cancel_trigger_by_name — missing trigger
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cancel_trigger_by_name_missing() -> None:
    sched, store, _ = _make_scheduler()
    ctx = _make_ctx(sched)

    result = await cancel_trigger_by_name(ctx, name="ghost-trigger")

    assert "No triggers found with name" in result
    assert "ghost-trigger" in result


# ---------------------------------------------------------------------------
# Happy: list_triggers — formatted output contains key fields
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_triggers_formatted() -> None:
    sched, store, _ = _make_scheduler()
    ctx = _make_ctx(sched)

    await schedule_once(ctx, prompt="First reminder", delta="1h", name="first")
    await schedule_heartbeat(ctx, prompt="Heartbeat check", interval="60s", name="hb")

    result = await list_triggers(ctx)

    # Bulk structure.
    assert "You have 2 scheduled trigger(s):" in result
    # one_shot row
    assert "one_shot" in result
    assert "First reminder" in result
    assert "first" in result
    # heartbeat row
    assert "heartbeat" in result
    assert "Heartbeat check" in result
    # trigger ids are ULIDs — check the ISO fire time format appears.
    assert "2026-01-01" in result


# ---------------------------------------------------------------------------
# Edge: cross-user isolation (CRITICAL — origin doc success criterion)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cross_user_isolation() -> None:
    sched, store, _ = _make_scheduler()

    ctx_alice = _make_ctx(sched, user_id="alice")
    ctx_bob = _make_ctx(sched, user_id="bob")

    # Alice schedules a trigger.
    alice_result = await schedule_once(ctx_alice, prompt="alice secret", delta="1h")
    # Extract trigger id from the return string.
    assert "trigger_id:" in alice_result
    alice_trigger_id = alice_result.split("trigger_id:")[1].strip().rstrip(".")

    # Bob sees no triggers.
    bob_list = await list_triggers(ctx_bob)
    assert bob_list == "No scheduled triggers."

    # Bob attempts to cancel Alice's trigger — gets "not found" (not auth error).
    bob_cancel = await cancel_trigger(ctx_bob, trigger_id=alice_trigger_id)
    assert "No trigger found with id" in bob_cancel
    # The trigger must still be active for Alice.
    alice_rows = await store.list("alice")
    assert len(alice_rows) == 1


# ---------------------------------------------------------------------------
# Edge: no scheduler wired
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_no_scheduler_wired_schedule_once() -> None:
    ctx = _make_ctx(None)
    result = await schedule_once(ctx, prompt="reminder", delta="30m")
    assert "not enabled" in result.lower()


@pytest.mark.asyncio
async def test_no_scheduler_wired_list_triggers() -> None:
    ctx = _make_ctx(None)
    result = await list_triggers(ctx)
    assert "not enabled" in result.lower()


@pytest.mark.asyncio
async def test_no_scheduler_wired_cancel() -> None:
    ctx = _make_ctx(None)
    result = await cancel_trigger(ctx, trigger_id="01JXXX")
    assert "not enabled" in result.lower()


# ---------------------------------------------------------------------------
# Error: limit violation (51st trigger for same user)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_limit_violation_51st_trigger() -> None:
    sched, store, _ = _make_scheduler(max_triggers_per_user=50)
    ctx = _make_ctx(sched)

    # Schedule 50 triggers with distinct names (avoids upsert dedup).
    for i in range(50):
        row_result = await schedule_once(ctx, prompt=f"trigger {i}", delta="1h", name=f"t{i}")
        assert "trigger_id:" in row_result, f"Expected success for trigger {i}: {row_result}"

    # 51st should hit the limit.
    result = await schedule_once(ctx, prompt="one too many", delta="1h")
    assert "Cannot schedule" in result
    assert "50 active trigger" in result


# ---------------------------------------------------------------------------
# Error: invalid cron expression
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_invalid_cron_expression() -> None:
    sched, _, _ = _make_scheduler()
    ctx = _make_ctx(sched)

    result = await schedule_cron(ctx, prompt="bad cron", expression="not-a-cron")
    # Must mention the expression and indicate invalidity.
    assert "not-a-cron" in result or "Invalid cron" in result
    # Must NOT contain a trigger_id (no row created).
    assert "trigger_id:" not in result


# ---------------------------------------------------------------------------
# Error: invalid timezone
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_invalid_timezone() -> None:
    sched, _, _ = _make_scheduler()
    ctx = _make_ctx(sched)

    result = await schedule_cron(
        ctx, prompt="tz test", expression="0 9 * * *", timezone="Mars/Olympus"
    )
    assert "Mars/Olympus" in result
    assert "trigger_id:" not in result


# ---------------------------------------------------------------------------
# Error: ambiguous schedule_once — neither at nor delta
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_schedule_once_neither_at_nor_delta() -> None:
    sched, _, _ = _make_scheduler()
    ctx = _make_ctx(sched)

    result = await schedule_once(ctx, prompt="oops")
    assert "Cannot schedule" in result
    assert "delta" in result
    assert "at" in result


# ---------------------------------------------------------------------------
# Error: ambiguous schedule_once — both at and delta
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_schedule_once_both_at_and_delta() -> None:
    sched, _, _ = _make_scheduler()
    ctx = _make_ctx(sched)

    result = await schedule_once(ctx, prompt="oops", delta="30m", at="2026-05-01T09:00:00Z")
    assert "Cannot schedule" in result


# ---------------------------------------------------------------------------
# Error: invalid delta format
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_invalid_delta_format() -> None:
    sched, _, _ = _make_scheduler()
    ctx = _make_ctx(sched)

    result = await schedule_once(ctx, prompt="bad delta", delta="30 minutes")
    assert "Cannot schedule" in result
    assert "30 minutes" in result
    # Must give format examples.
    assert "30m" in result or "PT30M" in result
