"""Pytest fixtures for zeno-scheduler tests.

Provides a parametrized ``store`` fixture that yields a ready adapter
(SqliteScheduleStore or InMemoryScheduleStore) and tears down any temp DB.
"""

from __future__ import annotations

import sys
import tempfile
from collections.abc import AsyncGenerator
from pathlib import Path

import pytest
import pytest_asyncio
from zeno.scheduler.sqlite.store import SqliteScheduleStore
from zeno.scheduler.testing import InMemoryScheduleStore

# Make the tests/ directory importable so test helper modules (e.g. _fakes)
# can be imported directly by test files.
_tests_dir = str(Path(__file__).parent)
if _tests_dir not in sys.path:
    sys.path.insert(0, _tests_dir)

# ---------------------------------------------------------------------------
# Per-adapter factories
# ---------------------------------------------------------------------------


async def _sqlite_factory() -> AsyncGenerator[SqliteScheduleStore, None]:
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test_triggers.db"
        store = SqliteScheduleStore(db_path)
        # Force initialization so the WAL and schema exist before tests run.
        _ = await store.count_active("__init__")
        yield store
        # tmpdir cleanup removes the DB file.


async def _inmem_factory() -> AsyncGenerator[InMemoryScheduleStore, None]:
    store = InMemoryScheduleStore()
    yield store


# ---------------------------------------------------------------------------
# Parametrized contract fixture
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture(
    params=["sqlite", "inmem"],
)
async def store(request: pytest.FixtureRequest):  # type: ignore[type-arg]
    """Yield a ready ScheduleStore adapter, parametrized over both backends."""
    param: str = request.param
    if param == "sqlite":
        async for s in _sqlite_factory():
            yield s
    else:
        async for s in _inmem_factory():
            yield s
