"""Minimal test doubles for zeno-scheduler unit tests."""

from __future__ import annotations

from zeno.testing import FakeChannel as FakeChannel  # re-export for in-package tests


class RecordingTracer:
    """Tracer that collects emitted events for inspection in tests."""

    def __init__(self) -> None:
        self.events: list[object] = []

    def on_event(self, event: object) -> None:
        self.events.append(event)
