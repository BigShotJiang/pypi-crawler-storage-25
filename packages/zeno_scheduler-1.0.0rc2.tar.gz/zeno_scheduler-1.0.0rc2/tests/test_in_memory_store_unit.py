"""In-memory-specific tests for InMemoryScheduleStore.

These tests verify properties unique to the in-memory adapter:
no cross-instance state sharing and no persistence across garbage collection.
"""

from __future__ import annotations

import gc

import pytest
from zeno.scheduler.testing import InMemoryScheduleStore
from zeno.scheduler.types import TriggerRow

_BASE_TS = 1_700_000_000


def _make_row(id: str = "01TEST0000000000000000001") -> TriggerRow:
    return TriggerRow(
        id=id,
        user_id="user-A",
        thread_key=None,
        channel_ref="cli://default",
        kind="one_shot",
        name=None,
        prompt="Say hello",
        metadata={},
        spec="@once",
        next_fire_at=_BASE_TS + 60,
        fire_count=0,
        max_fires=1,
        on_missed="drop",
        status="active",
        created_at=_BASE_TS,
    )


@pytest.mark.asyncio
async def test_two_instances_do_not_share_state() -> None:
    """Two InMemoryScheduleStore() instances have independent storage."""
    store_a = InMemoryScheduleStore()
    store_b = InMemoryScheduleStore()

    await store_a.upsert(_make_row(id="ID-A"))

    # store_b must not see store_a's row.
    result = await store_b.get("ID-A")
    assert result is None

    # And store_a must not see anything from store_b.
    rows_b = await store_b.list("user-A")
    assert len(rows_b) == 0


@pytest.mark.asyncio
async def test_data_does_not_persist_after_instance_dropped() -> None:
    """Data is lost once the InMemoryScheduleStore instance goes out of scope."""
    row = _make_row(id="ID-GC")

    store = InMemoryScheduleStore()
    await store.upsert(row)

    # Capture internal dict identity to verify it goes away.
    rows_dict = store._rows
    assert "ID-GC" in rows_dict

    # Drop the reference and force GC.
    del store
    gc.collect()

    # The dict reference is still alive via `rows_dict` in this test frame
    # (Python doesn't collect referenced objects), but a NEW store has no data.
    new_store = InMemoryScheduleStore()
    result = await new_store.get("ID-GC")
    assert result is None
