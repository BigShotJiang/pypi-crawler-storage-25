"""Unit tests for the Scheduler worker loop, concurrency, and at-most-once semantics.

All tests use a synthetic clock (``now_fn``) and ``InMemoryScheduleStore``
so no real sleeps occur.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from typing import Any

import pytest
from _fakes import FakeChannel, RecordingTracer
from zeno.scheduler.scheduler import Scheduler
from zeno.scheduler.testing import InMemoryScheduleStore
from zeno.scheduler.types import TriggerRow

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_BASE = datetime(2025, 6, 1, 12, 0, 0, tzinfo=UTC)


def make_clock(start: datetime) -> tuple[list[datetime], Callable[[], datetime]]:
    """Return a mutable clock list + a now_fn that reads from it."""
    clock = [start]

    def now_fn() -> datetime:
        return clock[0]

    return clock, now_fn


async def run_one_cycle(scheduler: Scheduler) -> None:
    """Trigger one full worker-loop cycle and wait for it to finish."""
    scheduler._wake.set()
    await scheduler.wait_idle()
    # Also wait for any in-flight fire tasks to complete.
    if scheduler._inflight:
        await asyncio.gather(*list(scheduler._inflight), return_exceptions=True)


# ---------------------------------------------------------------------------
# Happy path — one_shot
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_one_shot_fires_once_and_row_deleted() -> None:
    """One-shot trigger fires exactly once; DB row is deleted afterward."""
    clock, now_fn = make_clock(_BASE)
    store = InMemoryScheduleStore()
    ch = FakeChannel(name="fake://test")
    tracer = RecordingTracer()
    sched = Scheduler(store, {"fake://test": ch}, None, tracer, now_fn=now_fn)

    # Schedule 2 seconds into the future.
    row = await sched.schedule_once(
        user_id="u1",
        thread_key="t1",
        channel="fake://test",
        prompt="Hello",
        delta=timedelta(seconds=2),
    )
    assert len(ch.received) == 0

    await sched.start()

    # Advance clock past fire time.
    clock[0] = _BASE + timedelta(seconds=3)
    await run_one_cycle(sched)

    await sched.stop()

    assert len(ch.received) == 1
    msg = ch.received[0]
    assert msg.user_id == "u1"
    assert msg.text == "Hello"
    assert msg.metadata["scheduler"]["triggered_by"] == "scheduler"
    assert msg.metadata["scheduler"]["trigger_id"] == row.id
    assert msg.metadata["scheduler"]["trigger_kind"] == "one_shot"
    assert msg.metadata["scheduler"]["fire_count"] == 1

    # Row should be gone.
    fetched = await store.get(row.id)
    assert fetched is None


# ---------------------------------------------------------------------------
# Happy path — heartbeat
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_heartbeat_fires_multiple_times() -> None:
    """Heartbeat fires 3 times across 180s; row persists with fire_count=3."""
    clock, now_fn = make_clock(_BASE)
    store = InMemoryScheduleStore()
    ch = FakeChannel(name="fake://hb")
    sched = Scheduler(store, {"fake://hb": ch}, None, now_fn=now_fn, min_interval_s=10)

    await sched.schedule_heartbeat(
        user_id="u2",
        thread_key=None,
        channel="fake://hb",
        prompt="Ping",
        interval_s=60,
    )
    await sched.start()

    # Advance 60s — first fire.
    clock[0] = _BASE + timedelta(seconds=61)
    await run_one_cycle(sched)

    # Advance another 60s — second fire.
    clock[0] = _BASE + timedelta(seconds=121)
    await run_one_cycle(sched)

    # Advance another 60s — third fire.
    clock[0] = _BASE + timedelta(seconds=181)
    await run_one_cycle(sched)

    await sched.stop()

    assert len(ch.received) == 3


@pytest.mark.asyncio
async def test_heartbeat_max_fires_stops_after_limit() -> None:
    """Heartbeat with max_fires=2 fires exactly 2 times then row is gone."""
    clock, now_fn = make_clock(_BASE)
    store = InMemoryScheduleStore()
    ch = FakeChannel(name="fake://maxhb")
    sched = Scheduler(store, {"fake://maxhb": ch}, None, now_fn=now_fn, min_interval_s=10)

    row = await sched.schedule_heartbeat(
        user_id="u3",
        thread_key=None,
        channel="fake://maxhb",
        prompt="Limited ping",
        interval_s=60,
        max_fires=2,
    )
    await sched.start()

    for offset in (61, 121, 181):
        clock[0] = _BASE + timedelta(seconds=offset)
        await run_one_cycle(sched)

    await sched.stop()

    assert len(ch.received) == 2
    # Row must be gone (max_fires exhausted).
    fetched = await store.get(row.id)
    assert fetched is None


# ---------------------------------------------------------------------------
# Happy path — cron
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cron_fires_at_scheduled_times() -> None:
    """Cron 0 9 * * * UTC fires at 9am; fires a second time 24h later."""
    # Start the clock just before 9am on 2025-06-01.
    base = datetime(2025, 6, 1, 8, 59, 0, tzinfo=UTC)
    clock, now_fn = make_clock(base)
    store = InMemoryScheduleStore()
    ch = FakeChannel(name="fake://cron")
    sched = Scheduler(store, {"fake://cron": ch}, None, now_fn=now_fn, min_interval_s=10)

    await sched.schedule_cron(
        user_id="u4",
        thread_key=None,
        channel="fake://cron",
        prompt="Morning brief",
        expression="0 9 * * *",
        timezone="UTC",
    )
    await sched.start()

    # Advance to 9am.
    clock[0] = datetime(2025, 6, 1, 9, 0, 1, tzinfo=UTC)
    await run_one_cycle(sched)
    assert len(ch.received) == 1

    # Advance 24h.
    clock[0] = datetime(2025, 6, 2, 9, 0, 1, tzinfo=UTC)
    await run_one_cycle(sched)
    assert len(ch.received) == 2

    await sched.stop()


# ---------------------------------------------------------------------------
# Edge — at-most-once
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_at_most_once_fire_count_advanced_even_on_error() -> None:
    """Advance happens BEFORE dispatch; even if _fire raises, fire_count increments."""
    clock, now_fn = make_clock(_BASE)
    store = InMemoryScheduleStore()
    ch = FakeChannel(name="fake://amo")
    sched = Scheduler(store, {"fake://amo": ch}, None, now_fn=now_fn)

    row = await sched.schedule_once(
        user_id="u5",
        thread_key=None,
        channel="fake://amo",
        prompt="Boom",
        delta=timedelta(seconds=1),
    )

    # Patch _fire to raise AFTER the advance has already happened in the loop.
    async def raise_after_advance(self: Scheduler, r: TriggerRow, now: datetime) -> None:
        raise RuntimeError("simulated fire error")

    sched._fire = raise_after_advance.__get__(sched, Scheduler)  # type: ignore[method-assign]

    await sched.start()
    clock[0] = _BASE + timedelta(seconds=2)
    # Let the loop run; the fire task should raise but not propagate.
    sched._wake.set()
    await sched.wait_idle()
    # Allow fire tasks to complete.
    await asyncio.sleep(0)
    if sched._inflight:
        await asyncio.gather(*list(sched._inflight), return_exceptions=True)

    await sched.stop()

    # Row was deleted (one_shot after advance).
    fetched = await store.get(row.id)
    assert fetched is None
    # No retry — channel received nothing.
    assert len(ch.received) == 0


# ---------------------------------------------------------------------------
# Edge — missed one-shot on restart
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_missed_one_shot_fires_immediately_on_start() -> None:
    """Row with next_fire_at 5min in the past and on_missed='fire' fires once."""
    five_min_ago = _BASE - timedelta(minutes=5)
    clock, now_fn = make_clock(_BASE)
    store = InMemoryScheduleStore()
    ch = FakeChannel(name="fake://miss")
    sched = Scheduler(store, {"fake://miss": ch}, None, now_fn=now_fn)

    # Directly insert a row that is already overdue.
    row = TriggerRow(
        id="MISSED-001",
        user_id="u6",
        thread_key=None,
        channel_ref="fake://miss",
        kind="one_shot",
        name=None,
        prompt="Missed shot",
        metadata={},
        spec=five_min_ago.isoformat(),
        next_fire_at=int(five_min_ago.timestamp()),
        fire_count=0,
        max_fires=1,
        on_missed="fire",
        status="active",
        created_at=int(five_min_ago.timestamp()),
    )
    await store.upsert(row)

    await sched.start()
    await run_one_cycle(sched)
    await sched.stop()

    assert len(ch.received) == 1


# ---------------------------------------------------------------------------
# Edge — missed heartbeat coalesce
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_missed_heartbeat_coalesce_fires_once() -> None:
    """10 missed heartbeat intervals with on_missed='coalesce' → one fire."""
    # Insert a heartbeat row that is way overdue (10 intervals past).
    store = InMemoryScheduleStore()
    ch = FakeChannel(name="fake://coal")
    clock, now_fn = make_clock(_BASE)
    sched = Scheduler(store, {"fake://coal": ch}, None, now_fn=now_fn, min_interval_s=10)

    # Create the row directly as if it was inserted during a long outage.
    overdue_ts = int((_BASE - timedelta(seconds=600)).timestamp())
    row = TriggerRow(
        id="COALESCE-001",
        user_id="u7",
        thread_key=None,
        channel_ref="fake://coal",
        kind="heartbeat",
        name=None,
        prompt="Heartbeat",
        metadata={},
        spec="60",
        next_fire_at=overdue_ts,
        fire_count=0,
        max_fires=None,
        on_missed="coalesce",
        status="active",
        created_at=overdue_ts,
    )
    await store.upsert(row)

    await sched.start()
    # Single cycle — only one fire should happen despite 10 missed intervals.
    await run_one_cycle(sched)
    # Wait for any in-flight tasks.
    if sched._inflight:
        await asyncio.gather(*list(sched._inflight), return_exceptions=True)
    await sched.stop()

    # The loop calls due() once and gets one row — fires once.
    assert len(ch.received) == 1


# ---------------------------------------------------------------------------
# Edge — channel_ref missing at fire time
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_missing_channel_at_fire_time_emits_dropped_event() -> None:
    """If channel is not in registry at fire time, TriggerDropped is emitted."""
    clock, now_fn = make_clock(_BASE)
    store = InMemoryScheduleStore()
    ch = FakeChannel(name="fake://gone")
    tracer = RecordingTracer()

    # Register channel but then remove it before fire.
    channels: dict[str, Any] = {"fake://gone": ch}
    sched = Scheduler(store, channels, None, tracer, now_fn=now_fn)

    row = await sched.schedule_once(
        user_id="u8",
        thread_key=None,
        channel="fake://gone",
        prompt="Ghost",
        delta=timedelta(seconds=1),
    )
    # Remove channel BEFORE firing.
    del channels["fake://gone"]

    await sched.start()
    clock[0] = _BASE + timedelta(seconds=2)
    await run_one_cycle(sched)
    if sched._inflight:
        await asyncio.gather(*list(sched._inflight), return_exceptions=True)
    await sched.stop()

    # No message delivered.
    assert len(ch.received) == 0
    # TriggerDropped event emitted.
    dropped: list[Any] = [e for e in tracer.events if type(e).__name__ == "TriggerDropped"]
    assert len(dropped) == 1
    assert dropped[0].trigger_id == row.id
    assert dropped[0].reason == "channel_not_registered"
    # Row should be deleted.
    fetched = await store.get(row.id)
    assert fetched is None


# ---------------------------------------------------------------------------
# Edge — concurrent fires
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_concurrent_fire_limit() -> None:
    """20 triggers due at once with max_concurrent_fires=5 → at most 5 inflight."""
    clock, now_fn = make_clock(_BASE)
    store = InMemoryScheduleStore()
    ch = FakeChannel(name="fake://conc")
    sched = Scheduler(
        store,
        {"fake://conc": ch},
        None,
        now_fn=now_fn,
        max_concurrent_fires=5,
    )

    # Track peak in-flight count by observing _inflight set size at each fire start.
    peak_inflight: list[int] = []

    async def instrumented_fire(row: TriggerRow, now: datetime) -> None:
        peak_inflight.append(len(sched._inflight))
        await asyncio.sleep(0)  # yield to let other tasks run concurrently
        await ch.inbound_put(
            __import__("zeno.channels.messages", fromlist=["IncomingMessage"]).IncomingMessage(
                user_id=row.user_id,
                text=row.prompt,
                thread_key=row.thread_key,
                received_at=now,
            )
        )

    sched._fire = instrumented_fire  # type: ignore[method-assign]

    # Insert 20 triggers all due now.
    for i in range(20):
        row = TriggerRow(
            id=f"CONC-{i:03d}",
            user_id="u9",
            thread_key=None,
            channel_ref="fake://conc",
            kind="one_shot",
            name=None,
            prompt=f"Fire {i}",
            metadata={},
            spec=(_BASE - timedelta(seconds=1)).isoformat(),
            next_fire_at=int((_BASE - timedelta(seconds=1)).timestamp()),
            fire_count=0,
            max_fires=1,
            on_missed="fire",
            status="active",
            created_at=int(_BASE.timestamp()),
        )
        await store.upsert(row)

    await sched.start()
    clock[0] = _BASE + timedelta(seconds=1)
    sched._wake.set()
    await sched.wait_idle()
    # Wait for all in-flight tasks.
    while sched._inflight:
        await asyncio.gather(*list(sched._inflight), return_exceptions=True)
        await asyncio.sleep(0)
    await sched.stop()

    # At no point should inflight + acquired semaphore exceed 5.
    # Because the semaphore is acquired per task and max_concurrent_fires=5,
    # the semaphore prevents more than 5 from being in-flight simultaneously.
    # Verify: semaphore was never over-acquired (value never negative).
    assert sched._dispatch_semaphore._value >= 0


# ---------------------------------------------------------------------------
# Event-driven wakeup
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_event_driven_wakeup_does_not_wait_cap() -> None:
    """Scheduling a trigger wakes the loop before the cap sleep expires."""
    clock, now_fn = make_clock(_BASE)
    store = InMemoryScheduleStore()
    ch = FakeChannel(name="fake://wake")
    # Use a large cap so the test would time-out if wakeup didn't work.
    sched = Scheduler(
        store,
        {"fake://wake": ch},
        None,
        now_fn=now_fn,
        wakeup_cap_s=3600.0,
    )

    await sched.start()

    # Schedule a trigger due immediately.
    clock[0] = _BASE + timedelta(seconds=10)  # advance clock
    await sched.schedule_once(
        user_id="u10",
        thread_key=None,
        channel="fake://wake",
        prompt="Wake",
        delta=timedelta(seconds=-5),  # due 5s ago in clock time
    )
    # The schedule_* method set _wake; loop should recompute immediately.
    await sched.wait_idle()
    if sched._inflight:
        await asyncio.gather(*list(sched._inflight), return_exceptions=True)
    await sched.stop()

    # Message should have been delivered without waiting the 3600s cap.
    assert len(ch.received) == 1
