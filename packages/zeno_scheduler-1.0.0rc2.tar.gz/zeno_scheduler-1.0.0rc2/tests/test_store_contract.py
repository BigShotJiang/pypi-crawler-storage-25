"""Parametrized contract tests for ScheduleStore adapters.

Runs identically against SqliteScheduleStore and InMemoryScheduleStore via
the ``store`` fixture in conftest.py.  Any new adapter must satisfy these
tests without modification.

Coverage:
  - Happy-path round-trips (upsert / get / list / due).
  - Named upsert semantics (in-place update, stable id).
  - Ownership isolation (S1 security).
  - Atomic limit enforcement (S7 security).
  - cancel / delete / advance edge cases.
"""

from __future__ import annotations

import asyncio
import dataclasses
from typing import Any

import pytest
from zeno.scheduler.exceptions import ScheduleLimitError
from zeno.scheduler.protocols import ScheduleStore
from zeno.scheduler.types import TriggerRow

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_BASE_TS = 1_700_000_000


def _make_row(
    id: str = "01TEST0000000000000000001",
    user_id: str = "user-A",
    name: str | None = None,
    next_fire_at: int = _BASE_TS + 60,
    status: str = "active",
    fire_count: int = 0,
    thread_key: str | None = None,
    metadata: dict[str, Any] | None = None,
    prompt: str = "Say hello",
) -> TriggerRow:
    return TriggerRow(
        id=id,
        user_id=user_id,
        thread_key=thread_key,
        channel_ref="cli://default",
        kind="one_shot",
        name=name,
        prompt=prompt,
        metadata=metadata or {"key": "value", "num": 42},
        spec="@once",
        next_fire_at=next_fire_at,
        fire_count=fire_count,
        max_fires=1,
        on_missed="drop",
        status=status,  # type: ignore[arg-type]
        created_at=_BASE_TS,
    )


# ---------------------------------------------------------------------------
# Happy-path tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_upsert_and_get_round_trip(store: ScheduleStore) -> None:
    """upsert then get returns every field unchanged (including metadata)."""
    row = _make_row(metadata={"greeting": "hello", "count": 7})
    stored = await store.upsert(row)

    fetched = await store.get(stored.id)
    assert fetched is not None
    assert fetched.id == stored.id
    assert fetched.user_id == "user-A"
    assert fetched.channel_ref == "cli://default"
    assert fetched.prompt == "Say hello"
    assert fetched.metadata == {"greeting": "hello", "count": 7}
    assert fetched.next_fire_at == _BASE_TS + 60
    assert fetched.fire_count == 0
    assert fetched.status == "active"


@pytest.mark.asyncio
async def test_list_returns_only_that_users_rows(store: ScheduleStore) -> None:
    """list(user_id) returns only active rows belonging to that user."""
    row_a = _make_row(id="ID-A1", user_id="user-A")
    row_b = _make_row(id="ID-B1", user_id="user-B")
    await store.upsert(row_a)
    await store.upsert(row_b)

    a_rows = await store.list("user-A")
    b_rows = await store.list("user-B")

    assert len(a_rows) == 1
    assert a_rows[0].id == "ID-A1"
    assert len(b_rows) == 1
    assert b_rows[0].id == "ID-B1"


@pytest.mark.asyncio
async def test_due_returns_rows_with_next_fire_at_lte_now_ordered(
    store: ScheduleStore,
) -> None:
    """due(now) returns active rows with next_fire_at <= now, ascending order."""
    early = _make_row(id="ID-EARLY", next_fire_at=_BASE_TS + 10)
    late = _make_row(id="ID-LATE", next_fire_at=_BASE_TS + 50)
    future = _make_row(id="ID-FUTURE", next_fire_at=_BASE_TS + 9999)
    await store.upsert(early)
    await store.upsert(late)
    await store.upsert(future)

    due = await store.due(_BASE_TS + 100)
    assert len(due) == 2
    assert due[0].id == "ID-EARLY"
    assert due[1].id == "ID-LATE"


@pytest.mark.asyncio
async def test_due_excludes_inactive_rows(store: ScheduleStore) -> None:
    """due() does not return cancelled or dead rows."""
    active = _make_row(id="ID-ACTIVE", next_fire_at=_BASE_TS)
    await store.upsert(active)
    await store.cancel("ID-ACTIVE")

    due = await store.due(_BASE_TS + 1)
    assert not any(r.id == "ID-ACTIVE" for r in due)


# ---------------------------------------------------------------------------
# Named upsert semantics
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_named_upsert_updates_in_place_stable_id(store: ScheduleStore) -> None:
    """upsert same (user_id, name) → updates in place; id stays stable."""
    row1 = _make_row(id="ID-ORIG", name="daily-brief", next_fire_at=_BASE_TS + 100)
    stored1 = await store.upsert(row1)

    row2 = dataclasses.replace(
        row1, id="ID-NEW", next_fire_at=_BASE_TS + 200, prompt="Updated prompt"
    )
    stored2 = await store.upsert(row2)

    assert stored2.id == stored1.id  # id is stable
    assert stored2.next_fire_at == _BASE_TS + 200
    assert stored2.prompt == "Updated prompt"

    all_rows = await store.list("user-A")
    assert len(all_rows) == 1  # no duplicate created


@pytest.mark.asyncio
async def test_named_upsert_different_users_creates_two_rows(
    store: ScheduleStore,
) -> None:
    """upsert with same name but different user_id creates two separate rows."""
    row_a = _make_row(id="ID-UA", user_id="user-A", name="shared-name")
    row_b = _make_row(id="ID-UB", user_id="user-B", name="shared-name")
    await store.upsert(row_a)
    await store.upsert(row_b)

    a_rows = await store.list("user-A")
    b_rows = await store.list("user-B")
    assert len(a_rows) == 1 and a_rows[0].user_id == "user-A"
    assert len(b_rows) == 1 and b_rows[0].user_id == "user-B"


# ---------------------------------------------------------------------------
# cancel / delete
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cancel_sets_status_does_not_delete(store: ScheduleStore) -> None:
    """cancel sets status='cancelled' and the row still exists."""
    row = _make_row(id="ID-CANCEL")
    await store.upsert(row)
    await store.cancel("ID-CANCEL")

    fetched = await store.get("ID-CANCEL")
    assert fetched is not None
    assert fetched.status == "cancelled"


@pytest.mark.asyncio
async def test_delete_removes_row(store: ScheduleStore) -> None:
    """delete removes the row; get returns None afterwards."""
    row = _make_row(id="ID-DEL")
    await store.upsert(row)
    await store.delete("ID-DEL")

    fetched = await store.get("ID-DEL")
    assert fetched is None


@pytest.mark.asyncio
async def test_list_excludes_cancelled_and_dead(store: ScheduleStore) -> None:
    """list(user_id) excludes cancelled and dead rows."""
    active = _make_row(id="ID-ACT")
    cancelled = _make_row(id="ID-CAN")
    await store.upsert(active)
    await store.upsert(cancelled)
    await store.cancel("ID-CAN")

    rows = await store.list("user-A")
    ids = {r.id for r in rows}
    assert "ID-ACT" in ids
    assert "ID-CAN" not in ids


# ---------------------------------------------------------------------------
# advance / claim edge cases
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_claim_on_missing_id_returns_none(store: ScheduleStore) -> None:
    """claim on a non-existent id returns None without raising."""
    result = await store.claim("DOES-NOT-EXIST")
    assert result is None


@pytest.mark.asyncio
async def test_advance_on_missing_id_is_silent_noop(store: ScheduleStore) -> None:
    """advance on a missing id does not raise."""
    await store.advance("DOES-NOT-EXIST", _BASE_TS + 9999, 99)  # no error


# ---------------------------------------------------------------------------
# Security: S1 — ownership isolation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cancel_wrong_owner_is_noop(store: ScheduleStore) -> None:
    """cancel with wrong owner_user_id is silent no-op; row remains active."""
    row = _make_row(id="ID-OWN", user_id="user-A")
    await store.upsert(row)

    await store.cancel("ID-OWN", owner_user_id="user-B")  # wrong owner

    fetched = await store.get("ID-OWN")
    assert fetched is not None
    assert fetched.status == "active"


@pytest.mark.asyncio
async def test_delete_wrong_owner_is_noop(store: ScheduleStore) -> None:
    """delete with wrong owner_user_id is silent no-op; row still exists."""
    row = _make_row(id="ID-OWN2", user_id="user-A")
    await store.upsert(row)

    await store.delete("ID-OWN2", owner_user_id="user-B")

    fetched = await store.get("ID-OWN2")
    assert fetched is not None


@pytest.mark.asyncio
async def test_get_wrong_owner_returns_none(store: ScheduleStore) -> None:
    """get with wrong owner_user_id returns None — no information leak (S1)."""
    row = _make_row(id="ID-LEAK", user_id="user-A")
    await store.upsert(row)

    result = await store.get("ID-LEAK", owner_user_id="user-B")
    assert result is None


# ---------------------------------------------------------------------------
# Security: S7 — atomic limit enforcement
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_upsert_max_active_raises_at_limit(store: ScheduleStore) -> None:
    """upsert with max_active raises ScheduleLimitError when limit is reached."""
    # Fill up to max_active=3.
    for i in range(3):
        await store.upsert(_make_row(id=f"ID-LIM-{i}", user_id="user-lim"))

    fourth = _make_row(id="ID-LIM-3", user_id="user-lim")
    with pytest.raises(ScheduleLimitError) as exc_info:
        await store.upsert(fourth, max_active=3)

    # Error message must include both the count and the limit for usability.
    msg = str(exc_info.value)
    assert "3" in msg  # current count or limit


@pytest.mark.asyncio
async def test_upsert_max_active_error_message_contains_limit(
    store: ScheduleStore,
) -> None:
    """ScheduleLimitError message includes '50 active triggers'."""
    for i in range(50):
        await store.upsert(_make_row(id=f"ID-50-{i}", user_id="user-50"))

    overflow = _make_row(id="ID-50-OVER", user_id="user-50")
    with pytest.raises(ScheduleLimitError) as exc_info:
        await store.upsert(overflow, max_active=50)

    msg = str(exc_info.value)
    assert "50 active triggers" in msg


@pytest.mark.asyncio
async def test_concurrent_upsert_at_limit_exactly_one_succeeds(
    store: ScheduleStore,
) -> None:
    """Concurrent upserts at the limit: exactly one succeeds, the other raises."""
    # Pre-fill 49 active triggers.
    for i in range(49):
        await store.upsert(_make_row(id=f"ID-RACE-{i}", user_id="user-race"))

    # Two tasks both try to insert one more with max_active=50.
    row_x = _make_row(id="ID-RACE-X", user_id="user-race")
    row_y = _make_row(id="ID-RACE-Y", user_id="user-race")

    results = await asyncio.gather(
        store.upsert(row_x, max_active=50),
        store.upsert(row_y, max_active=50),
        return_exceptions=True,
    )

    successes = [r for r in results if isinstance(r, TriggerRow)]
    failures = [r for r in results if isinstance(r, ScheduleLimitError)]

    assert len(successes) == 1, f"Expected 1 success, got: {results}"
    assert len(failures) == 1, f"Expected 1 failure, got: {results}"


@pytest.mark.asyncio
async def test_concurrent_named_upsert_no_spurious_count(
    store: ScheduleStore,
) -> None:
    """Concurrent same-name upserts target the same row; final count stays 1."""
    row_v1 = _make_row(id="ID-NAME-1", name="concurrent-name", next_fire_at=_BASE_TS + 10)
    row_v2 = dataclasses.replace(row_v1, next_fire_at=_BASE_TS + 20)

    await asyncio.gather(
        store.upsert(row_v1),
        store.upsert(row_v2),
    )

    rows = await store.list("user-A")
    named = [r for r in rows if r.name == "concurrent-name"]
    assert len(named) == 1, f"Expected 1 named row, got {len(named)}"


# ---------------------------------------------------------------------------
# time_until_next_due
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_time_until_next_due_none_when_empty(store: ScheduleStore) -> None:
    """time_until_next_due returns None when there are no active triggers."""
    result = await store.time_until_next_due(_BASE_TS)
    assert result is None


@pytest.mark.asyncio
async def test_time_until_next_due_returns_correct_delta(store: ScheduleStore) -> None:
    """time_until_next_due returns seconds to earliest active next_fire_at."""
    row = _make_row(id="ID-DUE-DELTA", next_fire_at=_BASE_TS + 300)
    await store.upsert(row)

    result = await store.time_until_next_due(_BASE_TS)
    assert result == pytest.approx(300.0)


@pytest.mark.asyncio
async def test_time_until_next_due_floors_to_zero_if_past(store: ScheduleStore) -> None:
    """time_until_next_due returns 0.0 when earliest trigger is in the past."""
    row = _make_row(id="ID-DUE-PAST", next_fire_at=_BASE_TS - 100)
    await store.upsert(row)

    result = await store.time_until_next_due(_BASE_TS)
    assert result == 0.0
