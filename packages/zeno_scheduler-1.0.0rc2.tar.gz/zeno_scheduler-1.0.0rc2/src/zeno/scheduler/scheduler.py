"""Scheduler — core worker loop + Python API.

This module is the heart of ``zeno-scheduler``.  It owns:

- The async event-driven worker that polls for due triggers, advances state
  (at-most-once semantics, R18), and dispatches synthetic ``IncomingMessage``s
  into registered channels.
- A clean Python facade (``schedule_once``, ``schedule_heartbeat``,
  ``schedule_cron``, ``cancel_trigger``, ``list_triggers``, etc.) for app
  bootstraps and the built-in tools (U5).

Thread-safety note: the ``Scheduler`` is designed for use within a single
asyncio event loop.  Do not share instances across OS threads.

``ctx_factory`` is reserved for U6 per-turn context construction.  It is
accepted here for API compatibility but unused in U4.
"""

from __future__ import annotations

import asyncio
import contextlib
import dataclasses
import logging
from collections.abc import Callable, Mapping
from datetime import UTC, datetime, timedelta
from typing import Any

from ulid import ULID
from zeno.channels.messages import IncomingMessage
from zeno.observability.events import (
    SchedulerFireConsumed,
    SchedulerFireErrored,
    SchedulerFireQueued,
    TriggerDropped,
)
from zeno.scheduler.exceptions import ScheduleError, ScheduleLimitError
from zeno.scheduler.kinds import compute_next_fire
from zeno.scheduler.protocols import ScheduleStore
from zeno.scheduler.types import OnMissed, TriggerKind, TriggerRow

logger = logging.getLogger("zeno.scheduler")


class Scheduler:
    """Async scheduler with a single event-driven worker loop.

    Parameters
    ----------
    store:
        Persistence backend (``SqliteScheduleStore`` or
        ``InMemoryScheduleStore``).
    channels:
        Mapping from channel name to ``Channel`` object.  At fire time the
        scheduler looks up ``trigger.channel_ref`` here.
    ctx_factory:
        Reserved for U6 — per-turn context construction.  Unused in U4;
        kept in the signature for forward compatibility.
    tracer:
        Optional tracer implementing ``on_event(event)``.  Silently skipped
        when ``None``.
    max_triggers_per_user:
        Per-user active-trigger cap enforced atomically at upsert.
    min_interval_s:
        Minimum allowed heartbeat/cron effective interval in seconds.
    max_lead_days:
        Maximum future lead time for one-shots (days from now).
    max_concurrent_fires:
        Maximum number of ``_fire`` tasks in flight at once.
    wakeup_cap_s:
        Upper bound on the idle sleep between wake-up cycles.
    max_prompt_length:
        Maximum allowed ``prompt`` length in characters (S2).
    now_fn:
        Clock injection for testing.  Defaults to ``datetime.now(UTC)``.
    """

    def __init__(
        self,
        store: ScheduleStore,
        # Channel — typed loosely to avoid circular import
        channels: Mapping[str, Any] | None = None,
        ctx_factory: Any = None,  # Callable; reserved for U6 per-turn ctx construction
        tracer: Any = None,
        *,
        max_triggers_per_user: int = 50,
        min_interval_s: int = 60,
        max_lead_days: int = 365,
        max_concurrent_fires: int = 10,
        wakeup_cap_s: float = 60.0,
        max_prompt_length: int = 4096,
        now_fn: Callable[[], datetime] | None = None,
    ) -> None:
        self._store = store
        self._channels: Mapping[str, Any] = channels or {}
        self._ctx_factory = ctx_factory  # reserved for U6
        self._tracer = tracer

        self._max_triggers_per_user = max_triggers_per_user
        self._min_interval_s = min_interval_s
        self._max_lead_days = max_lead_days
        self._wakeup_cap_s = wakeup_cap_s
        self._max_prompt_length = max_prompt_length

        self._now_fn: Callable[[], datetime] = now_fn or (lambda: datetime.now(UTC))

        # Concurrency controls.
        self._dispatch_semaphore = asyncio.Semaphore(max_concurrent_fires)
        # In-flight _fire task handles.  Kept so stop() can await them.
        self._inflight: set[asyncio.Task[None]] = set()

        # Event-driven wakeup: set whenever the trigger set changes.
        # The worker awaits this (with timeout) instead of a fixed sleep.
        self._wake = asyncio.Event()

        # Lifecycle state.
        self._worker_task: asyncio.Task[None] | None = None
        self._stopping = False

        # ``_cycle_done`` is set at the end of each loop iteration (after
        # draining ``rows``).  Tests use ``wait_idle()`` to synchronize
        # without real sleeps.
        self._cycle_done = asyncio.Event()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the worker loop (idempotent)."""
        if self._worker_task is not None and not self._worker_task.done():
            return
        self._stopping = False
        self._worker_task = asyncio.create_task(self._run(), name="scheduler-loop")

    async def stop(self) -> None:
        """Cancel the worker and await all in-flight fire tasks."""
        self._stopping = True
        self._wake.set()  # unblock any idle wait
        if self._worker_task is not None and not self._worker_task.done():
            self._worker_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._worker_task
        # Drain remaining in-flight fires.
        if self._inflight:
            await asyncio.gather(*list(self._inflight), return_exceptions=True)

    async def wait_idle(self) -> None:
        """Wait until the worker loop has completed at least one full cycle.

        Tests inject a controllable clock and call ``wait_idle()`` after
        advancing the clock so that fired rows are visible in the store
        before assertions run.  The ``_cycle_done`` event is cleared at the
        start of each loop iteration and set at its end; awaiting it ensures
        the loop has processed all rows that were due at the most recent
        ``now_fn()`` reading.
        """
        self._cycle_done.clear()
        await self._cycle_done.wait()

    def bind_channels(self, channels: Mapping[str, Any]) -> None:
        """Late-bind the channel registry (used by ZenoApp at startup).

        Idempotent — safe to call multiple times; the last call wins.
        Users who seed triggers at bootstrap via schedule_* before app.run()
        still work; scheduling does not touch channels.
        """
        self._channels = channels

    # ------------------------------------------------------------------
    # Python API — schedule_*
    # ------------------------------------------------------------------

    async def schedule_once(
        self,
        *,
        user_id: str,
        thread_key: str | None,
        channel: str,
        prompt: str,
        at: datetime | None = None,
        delta: timedelta | None = None,
        name: str | None = None,
        on_missed: OnMissed = "fire",
        metadata: Mapping[str, Any] | None = None,
    ) -> TriggerRow:
        """Schedule a single one-shot trigger.

        Exactly one of ``at`` or ``delta`` must be provided.
        """
        self._check_prompt(prompt)

        if (at is None) == (delta is None):
            raise ValueError("schedule_once requires exactly one of at=, delta=")

        now = self._now()
        if at is None:
            assert delta is not None
            fire_at = now + delta
        else:
            # Normalize to UTC.
            fire_at = at.replace(tzinfo=UTC) if at.tzinfo is None else at.astimezone(UTC)

        lead = fire_at - now
        if lead.total_seconds() > self._max_lead_days * 86400:
            raise ScheduleLimitError(
                f"maximum {self._max_lead_days} days lead time (got {lead.days} days)"
            )

        spec = fire_at.isoformat()
        row = self._build_row(
            user_id=user_id,
            thread_key=thread_key,
            channel_ref=channel,
            kind="one_shot",
            prompt=prompt,
            spec=spec,
            next_fire_at=int(fire_at.timestamp()),
            max_fires=1,
            on_missed=on_missed,
            name=name,
            metadata=metadata or {},
        )
        stored = await self._store.upsert(row, max_active=self._max_triggers_per_user)
        self._wake.set()
        return stored

    async def schedule_heartbeat(
        self,
        *,
        user_id: str,
        thread_key: str | None,
        channel: str,
        prompt: str,
        interval_s: int,
        name: str | None = None,
        max_fires: int | None = None,
        on_missed: OnMissed = "coalesce",
        metadata: Mapping[str, Any] | None = None,
    ) -> TriggerRow:
        """Schedule a recurring heartbeat trigger."""
        self._check_prompt(prompt)
        if interval_s < self._min_interval_s:
            raise ScheduleLimitError(
                f"minimum {self._min_interval_s}s interval (got {interval_s}s)"
            )

        now = self._now()
        next_fire = now + timedelta(seconds=interval_s)
        row = self._build_row(
            user_id=user_id,
            thread_key=thread_key,
            channel_ref=channel,
            kind="heartbeat",
            prompt=prompt,
            spec=str(interval_s),
            next_fire_at=int(next_fire.timestamp()),
            max_fires=max_fires,
            on_missed=on_missed,
            name=name,
            metadata=metadata or {},
        )
        stored = await self._store.upsert(row, max_active=self._max_triggers_per_user)
        self._wake.set()
        return stored

    async def schedule_cron(
        self,
        *,
        user_id: str,
        thread_key: str | None,
        channel: str,
        prompt: str,
        expression: str,
        timezone: str = "UTC",
        name: str | None = None,
        on_missed: OnMissed = "fire",
        metadata: Mapping[str, Any] | None = None,
    ) -> TriggerRow:
        """Schedule a cron-based recurring trigger."""
        self._check_prompt(prompt)

        # Validate expression + timezone + minimum interval.
        spec = self._validate_cron(expression, timezone)

        now = self._now()
        # Compute first fire time using compute_next_fire on a dummy row.
        dummy = self._build_row(
            user_id=user_id,
            thread_key=thread_key,
            channel_ref=channel,
            kind="cron",
            prompt=prompt,
            spec=spec,
            next_fire_at=int(now.timestamp()),
            max_fires=None,
            on_missed=on_missed,
            name=name,
            metadata=metadata or {},
        )
        first_fire = compute_next_fire(dummy, now)
        if first_fire is None:
            raise ScheduleError("cron expression produces no future fire times")

        row = dataclasses.replace(dummy, next_fire_at=int(first_fire.timestamp()))
        stored = await self._store.upsert(row, max_active=self._max_triggers_per_user)
        self._wake.set()
        return stored

    # ------------------------------------------------------------------
    # Python API — cancel / list / get
    # ------------------------------------------------------------------

    async def cancel_trigger(self, trigger_id: str, *, owner_user_id: str | None = None) -> bool:
        """Cancel a trigger by id.  Returns True if found and cancelled."""
        row = await self._store.get(trigger_id, owner_user_id=owner_user_id)
        if row is None or row.status != "active":
            return False
        await self._store.cancel(trigger_id, owner_user_id=owner_user_id)
        self._wake.set()
        return True

    async def cancel_trigger_by_name(self, user_id: str, name: str) -> int:
        """Cancel all active triggers matching ``(user_id, name)``.

        Returns the number of triggers cancelled.
        """
        row = await self._store.list_by_name(user_id, name)
        if row is None:
            return 0
        await self._store.cancel(row.id)
        self._wake.set()
        return 1

    async def list_triggers(self, user_id: str) -> list[TriggerRow]:
        """Return all active triggers for ``user_id``."""
        return await self._store.list(user_id)

    async def get_trigger(
        self, trigger_id: str, *, owner_user_id: str | None = None
    ) -> TriggerRow | None:
        """Fetch a trigger by id (S1: returns None on mismatched owner)."""
        return await self._store.get(trigger_id, owner_user_id=owner_user_id)

    # ------------------------------------------------------------------
    # Worker loop
    # ------------------------------------------------------------------

    async def _run(self) -> None:
        """Main event loop.  Runs until ``_stopping`` is set."""
        while not self._stopping:
            self._cycle_done.clear()
            now = self._now()
            now_ts = int(now.timestamp())
            rows = await self._store.due(now_ts)
            if rows:
                for row in rows:
                    if self._stopping:
                        break
                    await self._dispatch_semaphore.acquire()
                    try:
                        # Compute the NEXT fire time after this firing.
                        # We pass an advanced row (fire_count + 1) so that:
                        #   - one_shot: compute_next_fire returns None → delete
                        #   - heartbeat: returns now + interval
                        #   - cron: we use fire_at as the "now" so get_next()
                        #     starts from the current slot, not wall-clock time.
                        # For cron, pass fire_at (the current slot) as the
                        # reference point so compute_next_fire's get_next() picks
                        # the next scheduled occurrence rather than a missed one.
                        # Compute the NEXT fire time after this firing.
                        # We always use on_missed='drop' semantics here because
                        # the on_missed='fire' path in compute_next_fire checks
                        # for past occurrences — but for advancing state we want
                        # the next FUTURE slot, not a re-fire of the current one.
                        # fire_count+1 ensures one_shot returns None (delete).
                        advance_row = dataclasses.replace(
                            row,
                            fire_count=row.fire_count + 1,
                            on_missed="drop",
                        )
                        next_fire_dt = compute_next_fire(advance_row, now)
                        if next_fire_dt is None:
                            await self._store.delete(row.id)
                        else:
                            await self._store.advance(
                                row.id,
                                int(next_fire_dt.timestamp()),
                                row.fire_count + 1,
                            )
                        fire_task = asyncio.create_task(self._fire(row, now))
                        self._inflight.add(fire_task)
                        fire_task.add_done_callback(self._on_fire_done)
                    except BaseException:
                        # Only release here if create_task never ran; otherwise
                        # _on_fire_done is responsible for releasing the slot.
                        self._dispatch_semaphore.release()
                        raise
            else:
                # No rows due — wait until the next trigger fires or someone
                # adds/cancels a trigger (via _wake).
                wait_s = await self._store.time_until_next_due(now_ts)
                if wait_s is None:
                    sleep_for = self._wakeup_cap_s
                else:
                    sleep_for = min(self._wakeup_cap_s, float(wait_s))
                with contextlib.suppress(TimeoutError):
                    await asyncio.wait_for(self._wake.wait(), timeout=sleep_for)
                self._wake.clear()

            self._cycle_done.set()

    def _on_fire_done(self, task: asyncio.Task[None]) -> None:
        """Callback invoked when a ``_fire`` task completes.

        Releases the dispatch semaphore slot and removes the task from the
        in-flight set.  Always called even if the task raised.
        """
        self._inflight.discard(task)
        self._dispatch_semaphore.release()

    async def _fire(self, row: TriggerRow, now: datetime) -> None:
        """Construct a synthetic IncomingMessage and push it into the channel.

        Semaphore release is owned by ``_on_fire_done`` (via done callback),
        NOT by this coroutine.  This means the slot stays occupied until the
        fire task finishes, bounding concurrency correctly.
        """
        fire_count = row.fire_count + 1  # 1-based: "this is fire N"
        scheduled_for = now.isoformat()

        msg = IncomingMessage(
            user_id=row.user_id,
            text=row.prompt,
            thread_key=row.thread_key,
            received_at=now,
            metadata={
                "scheduler": {
                    "triggered_by": "scheduler",
                    "trigger_id": row.id,
                    "trigger_kind": row.kind,
                    "trigger_name": row.name,
                    "fire_count": fire_count,
                    "scheduled_for": scheduled_for,
                }
            },
        )

        channel = self._channels.get(row.channel_ref)
        if channel is None:
            self._emit(
                TriggerDropped(
                    trigger_id=row.id,
                    trigger_kind=row.kind,
                    user_id=row.user_id,
                    fire_count=fire_count,
                    reason="channel_not_registered",
                )
            )
            await self._store.delete(row.id)
            return

        self._emit(
            SchedulerFireQueued(
                trigger_id=row.id,
                trigger_kind=row.kind,
                user_id=row.user_id,
                fire_count=fire_count,
            )
        )

        try:
            if hasattr(channel, "inbound_put"):
                await channel.inbound_put(msg)
            else:
                # inbound_put is added in U6.  Log a warning but don't crash.
                self._emit(
                    SchedulerFireErrored(
                        trigger_id=row.id,
                        trigger_kind=row.kind,
                        user_id=row.user_id,
                        fire_count=fire_count,
                        error="channel_missing_inbound_put",
                    )
                )
                logger.warning(
                    "channel %r has no inbound_put; trigger %s dropped",
                    row.channel_ref,
                    row.id,
                )
                return
        except Exception as exc:  # noqa: BLE001
            self._emit(
                SchedulerFireErrored(
                    trigger_id=row.id,
                    trigger_kind=row.kind,
                    user_id=row.user_id,
                    fire_count=fire_count,
                    error=str(exc),
                )
            )
            logger.exception("_fire failed for trigger %s", row.id)
            return

        self._emit(
            SchedulerFireConsumed(
                trigger_id=row.id,
                trigger_kind=row.kind,
                user_id=row.user_id,
                fire_count=fire_count,
            )
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _now(self) -> datetime:
        """Return the current UTC datetime (injected in tests)."""
        return self._now_fn()

    def _emit(self, event: Any) -> None:
        """Emit a trace event if a tracer is configured."""
        if self._tracer is not None:
            try:
                self._tracer.on_event(event)
            except Exception:  # noqa: BLE001
                logger.exception("Tracer raised during scheduler emit")

    def _check_prompt(self, prompt: str) -> None:
        """Raise ScheduleLimitError if prompt exceeds max_prompt_length (S2)."""
        if len(prompt) > self._max_prompt_length:
            raise ScheduleLimitError(
                f"prompt exceeds {self._max_prompt_length} characters (got {len(prompt)})"
            )

    def _validate_cron(self, expression: str, timezone: str) -> str:
        """Validate cron expression + timezone; check minimum interval.

        Returns the ``spec`` string (``"<expr>|<tz>"``).  Raises
        ``ScheduleError`` for invalid syntax and ``ScheduleLimitError`` for
        sub-minimum intervals.
        """
        from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

        from croniter import CroniterBadCronError, croniter  # type: ignore[import-untyped]

        # Resolve timezone first — informative error ordering.
        try:
            tz = ZoneInfo(timezone)
        except (ZoneInfoNotFoundError, KeyError) as exc:
            raise ScheduleError(f"Unknown timezone: {timezone!r}") from exc

        # Expand macros then validate.
        from zeno.scheduler.kinds import _expand_cron_macro

        expanded = _expand_cron_macro(expression)
        try:
            if not croniter.is_valid(expanded):
                raise ScheduleError(f"Invalid cron expression: {expression!r}")
        except CroniterBadCronError as exc:
            raise ScheduleError(f"Invalid cron expression: {expression!r}") from exc

        # Minimum-interval check: compute two consecutive fires and compare.
        now_local = datetime.now(tz)
        try:
            it = croniter(expanded, now_local)
            next1: datetime = it.get_next(datetime)
            next2: datetime = it.get_next(datetime)
            interval = (next2 - next1).total_seconds()
        except Exception as exc:  # noqa: BLE001
            raise ScheduleError(f"Could not evaluate cron expression: {expression!r}") from exc

        if interval < self._min_interval_s:
            raise ScheduleLimitError(
                f"minimum {self._min_interval_s}s interval; "
                f"cron {expression!r} fires every {interval:.0f}s"
            )

        return f"{expression}|{timezone}"

    @staticmethod
    def _build_row(
        *,
        user_id: str,
        thread_key: str | None,
        channel_ref: str,
        kind: TriggerKind,
        prompt: str,
        spec: str,
        next_fire_at: int,
        max_fires: int | None,
        on_missed: OnMissed,
        name: str | None,
        metadata: Mapping[str, Any],
    ) -> TriggerRow:
        """Construct a ``TriggerRow`` with a fresh ULID id."""
        now_ts = int(datetime.now(UTC).timestamp())
        return TriggerRow(
            id=str(ULID()),
            user_id=user_id,
            thread_key=thread_key,
            channel_ref=channel_ref,
            kind=kind,
            name=name,
            prompt=prompt,
            metadata=dict(metadata),
            spec=spec,
            next_fire_at=next_fire_at,
            fire_count=0,
            max_fires=max_fires,
            on_missed=on_missed,
            status="active",
            created_at=now_ts,
        )
