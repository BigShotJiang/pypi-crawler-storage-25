"""Trigger-kind dispatch: compute the next fire datetime for a TriggerRow.

This module contains one public function — ``compute_next_fire`` — that is the
single place in the codebase that knows how ``one_shot``, ``heartbeat``, and
``cron`` differ from each other.  Everything is pure; there are no I/O calls or
side effects.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from croniter import CroniterBadCronError, croniter  # type: ignore[import-untyped]  # noqa: F401
from zeno.scheduler.exceptions import ScheduleError
from zeno.scheduler.types import TriggerRow

# ---------------------------------------------------------------------------
# Cron macro expansion
# ---------------------------------------------------------------------------

_CRON_MACROS: dict[str, str] = {
    "@daily": "0 0 * * *",
    "@hourly": "0 * * * *",
    "@weekly": "0 0 * * 0",
    "@monthly": "0 0 1 * *",
    "@yearly": "0 0 1 1 *",
    "@annually": "0 0 1 1 *",
}


def _expand_cron_macro(expr: str) -> str:
    """Expand a cron macro (e.g. ``@daily``) to a five-field expression.

    Returns *expr* unchanged when it is not a recognised macro.
    """
    return _CRON_MACROS.get(expr.strip().lower(), expr)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_ambiguous(dt: datetime) -> bool:
    """Return True when *dt* falls in a DST fall-back repeated hour.

    Detects ambiguity by comparing the UTC offsets of the fold=0 and fold=1
    variants of the same local time.  When the two offsets differ the instant
    is genuinely ambiguous.
    """
    fold0 = dt.replace(fold=0)
    fold1 = dt.replace(fold=1)
    return fold0.utcoffset() != fold1.utcoffset()


# ---------------------------------------------------------------------------
# Per-kind helpers (private)
# ---------------------------------------------------------------------------


def _next_one_shot(row: TriggerRow, _now: datetime) -> datetime | None:
    """Compute next fire for a ``one_shot`` trigger."""
    if row.fire_count >= 1:
        return None

    try:
        fire_at = datetime.fromisoformat(row.spec.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ScheduleError(f"Invalid one_shot spec (expected ISO-8601): {row.spec!r}") from exc

    # Ensure timezone-aware UTC
    fire_at = fire_at.replace(tzinfo=UTC) if fire_at.tzinfo is None else fire_at.astimezone(UTC)

    return fire_at


def _next_heartbeat(row: TriggerRow, now: datetime) -> datetime | None:
    """Compute next fire for a ``heartbeat`` trigger."""
    if row.max_fires is not None and row.fire_count >= row.max_fires:
        return None

    try:
        interval = int(row.spec)
    except ValueError as exc:
        raise ScheduleError(
            f"Invalid heartbeat spec (expected integer seconds): {row.spec!r}"
        ) from exc

    if interval <= 0:
        raise ScheduleError(f"Invalid heartbeat spec (interval must be positive): {row.spec!r}")

    # Coalesce: always fire one interval from now regardless of outage duration.
    return now + timedelta(seconds=interval)


def _next_cron(row: TriggerRow, now: datetime) -> datetime | None:
    """Compute next fire for a ``cron`` trigger.

    Handles:
    - Macro expansion (``@daily`` etc.)
    - IANA timezone math with DST
    - Missed-fire policy (``on_missed='fire'`` vs ``'drop'``)
    - Fall-back ambiguous hours (fold=1 → post-DST occurrence)
    """
    parts = row.spec.split("|", maxsplit=1)
    if len(parts) != 2:
        raise ScheduleError(f"Invalid cron spec (expected '<expr>|<tz>'): {row.spec!r}")

    expr_raw, tz_str = parts[0].strip(), parts[1].strip()
    expr = _expand_cron_macro(expr_raw)

    # Validate expression before touching ZoneInfo so errors are well-ordered.
    if not croniter.is_valid(expr):
        raise ScheduleError(f"Invalid cron expression: {expr_raw!r}")

    try:
        tz = ZoneInfo(tz_str)
    except (ZoneInfoNotFoundError, KeyError) as exc:
        raise ScheduleError(f"Unknown timezone: {tz_str!r}") from exc

    now_in_tz = now.astimezone(tz)

    if row.on_missed == "fire":
        # If a past occurrence exists (now > last scheduled slot), return it
        # immediately so the worker fires the missed slot.
        it = croniter(expr, now_in_tz)
        candidate_local = it.get_prev(datetime)
        if candidate_local is not None:
            candidate_utc = _local_to_utc(candidate_local, tz)
            if candidate_utc <= now:
                # There is a missed (or exact) occurrence — fire it.
                return candidate_utc

    # Default / drop: return the next occurrence strictly after now.
    it = croniter(expr, now_in_tz)
    next_local = it.get_next(datetime)
    return _local_to_utc(next_local, tz)


def _local_to_utc(local_dt: datetime, tz: ZoneInfo) -> datetime:
    """Convert a naive-or-aware local datetime to UTC.

    When the local time is ambiguous (DST fall-back), forces ``fold=1`` so
    Python interprets it as the *second* (post-DST / standard time) occurrence.
    """
    # croniter may return a naive datetime — attach the tz.
    if local_dt.tzinfo is None:
        local_dt = local_dt.replace(tzinfo=tz)
    else:
        # Already has tz info; re-attach with the canonical ZoneInfo object so
        # zoneinfo DST rules apply.
        local_dt = local_dt.replace(tzinfo=tz, fold=local_dt.fold)

    # Apply fold=1 for fall-back ambiguous hours.
    if _is_ambiguous(local_dt):
        local_dt = local_dt.replace(fold=1)

    return local_dt.astimezone(UTC)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def compute_next_fire(row: TriggerRow, now: datetime) -> datetime | None:
    """Return the next fire datetime (UTC, timezone-aware) or None when exhausted.

    ``now`` must be UTC-aware.  Returns ``None`` when:

    - ``one_shot``: the single fire has already occurred (``fire_count >= 1``).
    - ``heartbeat``: ``fire_count >= max_fires`` (when ``max_fires`` is set).

    Raises ``ScheduleError`` on invalid cron expressions, missing ``|``
    separators, or unknown IANA timezones.
    """
    if now.tzinfo is None or now.utcoffset() is None:
        raise ScheduleError("'now' must be a UTC-aware datetime")

    if row.kind == "one_shot":
        return _next_one_shot(row, now)
    if row.kind == "heartbeat":
        return _next_heartbeat(row, now)
    if row.kind == "cron":
        return _next_cron(row, now)

    raise ScheduleError(f"Unknown trigger kind: {row.kind!r}")
