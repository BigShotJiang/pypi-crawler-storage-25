"""zeno-scheduler public API."""

from __future__ import annotations

from zeno.scheduler.exceptions import ScheduleError, ScheduleLimitError
from zeno.scheduler.protocols import ScheduleStore
from zeno.scheduler.scheduler import Scheduler
from zeno.scheduler.sqlite.store import SqliteScheduleStore
from zeno.scheduler.tools import (
    cancel_trigger,
    cancel_trigger_by_name,
    list_triggers,
    schedule_cron,
    schedule_heartbeat,
    schedule_once,
)
from zeno.scheduler.types import OnMissed, TriggerKind, TriggerRow

# InMemoryScheduleStore is intentionally NOT exported from the top-level
# package — users import it from `zeno.scheduler.testing` per R11 / C4.

__all__ = [
    # Exceptions
    "ScheduleError",
    "ScheduleLimitError",
    # Types
    "TriggerKind",
    "OnMissed",
    "TriggerRow",
    # Protocol
    "ScheduleStore",
    # Adapters
    "SqliteScheduleStore",
    # Core
    "Scheduler",
    # Built-in tools (U5)
    "schedule_once",
    "schedule_heartbeat",
    "schedule_cron",
    "cancel_trigger",
    "cancel_trigger_by_name",
    "list_triggers",
]
