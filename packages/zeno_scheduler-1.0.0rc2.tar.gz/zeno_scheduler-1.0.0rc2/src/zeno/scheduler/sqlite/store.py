"""`SqliteScheduleStore` — durable trigger store backed by aiosqlite + WAL mode.

Security:
  S1 — ownership enforcement: ``get``, ``cancel``, and ``delete`` accept an
       ``owner_user_id`` parameter and silently return/no-op when the stored
       ``user_id`` does not match, revealing no information to the caller.
  S6 — file permissions: when the backing DB file is newly created,
       ``os.chmod(path, 0o600)`` restricts read/write to the owning process
       user only.
  S7 — atomic limit check: ``upsert`` with ``max_active`` uses
       ``BEGIN IMMEDIATE`` so no other writer can interleave between the
       ``SELECT COUNT(*)`` and the ``INSERT``.

Concurrency:
  WAL mode + ``busy_timeout=30000`` handle cross-connection contention.
  A per-instance ``asyncio.Lock`` serializes concurrent upsert calls within
  the same event loop, supplementing the ``BEGIN IMMEDIATE`` SQLite lock.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

import aiosqlite
from zeno.scheduler.exceptions import ScheduleLimitError
from zeno.scheduler.sqlite.migrate import ensure_schema
from zeno.scheduler.types import TriggerRow

_LOGGER = logging.getLogger("zeno.scheduler.sqlite.store")


def _row_to_trigger(row: Any) -> TriggerRow:
    """Convert a raw SQLite row (tuple) to a ``TriggerRow``."""
    (
        id_,
        user_id,
        thread_key,
        channel_ref,
        kind,
        name,
        prompt,
        metadata_json,
        spec,
        next_fire_at,
        fire_count,
        max_fires,
        on_missed,
        status,
        created_at,
    ) = row
    metadata: dict[str, Any] = json.loads(metadata_json) if metadata_json else {}
    return TriggerRow(
        id=id_,
        user_id=user_id,
        thread_key=thread_key,
        channel_ref=channel_ref,
        kind=kind,
        name=name,
        prompt=prompt,
        metadata=metadata,
        spec=spec,
        next_fire_at=next_fire_at,
        fire_count=fire_count,
        max_fires=max_fires,
        on_missed=on_missed,
        status=status,
        created_at=created_at,
    )


_SELECT_ALL = (
    "id, user_id, thread_key, channel_ref, kind, name, prompt, metadata, "
    "spec, next_fire_at, fire_count, max_fires, on_missed, status, created_at"
)

# Process-wide lock protecting schema initialization. One per event loop
# is sufficient because SQLite WAL + busy_timeout handles cross-process races.
_STORE_INIT_LOCK = asyncio.Lock()


class SqliteScheduleStore:
    """Durable trigger store backed by aiosqlite + WAL mode.

    Parameters
    ----------
    path:
        Filesystem path for the SQLite database file.  The parent directory
        must already exist.  If the file does not yet exist it will be
        created with ``0o600`` permissions (S6).
    """

    def __init__(self, path: str | Path) -> None:
        self._path = str(path)
        self._initialized = False
        self._init_lock = asyncio.Lock()
        # Serializes upsert calls within this event loop so the
        # BEGIN IMMEDIATE path doesn't need to compete with itself.
        self._upsert_lock = asyncio.Lock()

    async def _ensure_initialized(self, conn: aiosqlite.Connection) -> None:
        """Run schema migration on the first connection open. Idempotent."""
        if self._initialized:
            return
        async with self._init_lock:
            if self._initialized:
                return
            await ensure_schema(conn)
            self._initialized = True

    @contextlib.asynccontextmanager
    async def _conn(self) -> AsyncIterator[aiosqlite.Connection]:
        """Open a fresh connection, ensuring schema on first use.

        S6: chmod the DB file to 0o600 if we just created it.
        """
        file_existed = os.path.exists(self._path)
        async with aiosqlite.connect(self._path) as conn:
            if not file_existed and os.path.exists(self._path):
                os.chmod(self._path, 0o600)
            await self._ensure_initialized(conn)
            yield conn

    # ------------------------------------------------------------------
    # ScheduleStore protocol
    # ------------------------------------------------------------------

    async def due(self, now: int) -> list[TriggerRow]:
        """Return active rows with ``next_fire_at <= now``, ordered ascending."""
        async with self._conn() as conn:
            cur = await conn.execute(
                f"SELECT {_SELECT_ALL} FROM triggers "
                "WHERE status = 'active' AND next_fire_at <= ? "
                "ORDER BY next_fire_at ASC",
                (now,),
            )
            rows = await cur.fetchall()
        return [_row_to_trigger(r) for r in rows]

    async def claim(self, trigger_id: str) -> TriggerRow | None:
        """Idempotent claim — returns ``None`` if already claimed or missing."""
        async with self._conn() as conn:
            cur = await conn.execute(
                f"SELECT {_SELECT_ALL} FROM triggers WHERE id = ?",
                (trigger_id,),
            )
            row = await cur.fetchone()
            if row is None:
                return None
            trigger = _row_to_trigger(row)
            if trigger.status != "active":
                return None
            return trigger

    async def advance(self, trigger_id: str, next_fire_at: int, fire_count: int) -> None:
        """Update ``next_fire_at`` and ``fire_count`` after a successful fire."""
        async with self._conn() as conn:
            await conn.execute(
                "UPDATE triggers SET next_fire_at = ?, fire_count = ? WHERE id = ?",
                (next_fire_at, fire_count, trigger_id),
            )
            await conn.commit()

    async def delete(self, trigger_id: str, *, owner_user_id: str | None = None) -> None:
        """Delete a trigger row entirely (S1 ownership guard)."""
        async with self._conn() as conn:
            if owner_user_id is not None:
                await conn.execute(
                    "DELETE FROM triggers WHERE id = ? AND user_id = ?",
                    (trigger_id, owner_user_id),
                )
            else:
                await conn.execute(
                    "DELETE FROM triggers WHERE id = ?",
                    (trigger_id,),
                )
            await conn.commit()

    async def cancel(self, trigger_id: str, *, owner_user_id: str | None = None) -> None:
        """Set ``status='cancelled'`` — does NOT delete the row (S1 guard)."""
        async with self._conn() as conn:
            if owner_user_id is not None:
                await conn.execute(
                    "UPDATE triggers SET status = 'cancelled' WHERE id = ? AND user_id = ?",
                    (trigger_id, owner_user_id),
                )
            else:
                await conn.execute(
                    "UPDATE triggers SET status = 'cancelled' WHERE id = ?",
                    (trigger_id,),
                )
            await conn.commit()

    async def upsert(self, row: TriggerRow, *, max_active: int | None = None) -> TriggerRow:
        """Insert or name-update a trigger, optionally enforcing a limit (S7)."""
        async with self._upsert_lock:
            return await self._upsert_inner(row, max_active=max_active)

    async def _upsert_inner(self, row: TriggerRow, *, max_active: int | None = None) -> TriggerRow:
        metadata_json = json.dumps(dict(row.metadata))

        async with self._conn() as conn:
            # Use explicit transaction for atomic count+insert (S7).
            await conn.execute("BEGIN IMMEDIATE")
            try:
                existing_id: str | None = None
                if row.name is not None:
                    cur = await conn.execute(
                        "SELECT id FROM triggers "
                        "WHERE user_id = ? AND name = ? AND status = 'active'",
                        (row.user_id, row.name),
                    )
                    existing_row = await cur.fetchone()
                    if existing_row is not None:
                        existing_id = existing_row[0]

                if existing_id is None and max_active is not None:
                    # S7: count INSIDE the transaction; no racing writer can
                    # change it because BEGIN IMMEDIATE holds a reserved lock.
                    cur = await conn.execute(
                        "SELECT COUNT(*) FROM triggers WHERE user_id = ? AND status = 'active'",
                        (row.user_id,),
                    )
                    count_row = await cur.fetchone()
                    current_count = int(count_row[0]) if count_row else 0
                    if current_count >= max_active:
                        await conn.execute("ROLLBACK")
                        raise ScheduleLimitError(
                            f"user already has {current_count} active trigger(s); "
                            f"limit is {max_active} active triggers"
                        )

                if existing_id is not None:
                    # UPDATE in place, keep id stable.
                    stored_id = existing_id
                    await conn.execute(
                        "UPDATE triggers SET "
                        "thread_key=?, channel_ref=?, kind=?, prompt=?, "
                        "metadata=?, spec=?, next_fire_at=?, fire_count=?, "
                        "max_fires=?, on_missed=?, status=?, created_at=? "
                        "WHERE id=?",
                        (
                            row.thread_key,
                            row.channel_ref,
                            row.kind,
                            row.prompt,
                            metadata_json,
                            row.spec,
                            row.next_fire_at,
                            row.fire_count,
                            row.max_fires,
                            row.on_missed,
                            row.status,
                            row.created_at,
                            stored_id,
                        ),
                    )
                else:
                    stored_id = row.id
                    await conn.execute(
                        "INSERT INTO triggers "
                        "(id, user_id, thread_key, channel_ref, kind, name, "
                        "prompt, metadata, spec, next_fire_at, fire_count, "
                        "max_fires, on_missed, status, created_at) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (
                            stored_id,
                            row.user_id,
                            row.thread_key,
                            row.channel_ref,
                            row.kind,
                            row.name,
                            row.prompt,
                            metadata_json,
                            row.spec,
                            row.next_fire_at,
                            row.fire_count,
                            row.max_fires,
                            row.on_missed,
                            row.status,
                            row.created_at,
                        ),
                    )

                await conn.execute("COMMIT")

                # Re-fetch to return stored state.
                cur2 = await conn.execute(
                    f"SELECT {_SELECT_ALL} FROM triggers WHERE id = ?",
                    (stored_id,),
                )
                fetched = await cur2.fetchone()

            except ScheduleLimitError:
                raise
            except Exception:
                with contextlib.suppress(Exception):
                    await conn.execute("ROLLBACK")
                raise

        if fetched is None:
            raise RuntimeError(f"upsert: row {row.id!r} not found after write")
        return _row_to_trigger(fetched)

    async def get(self, trigger_id: str, *, owner_user_id: str | None = None) -> TriggerRow | None:
        """Fetch by id (S1 ownership guard returns ``None`` on mismatch)."""
        async with self._conn() as conn:
            cur = await conn.execute(
                f"SELECT {_SELECT_ALL} FROM triggers WHERE id = ?",
                (trigger_id,),
            )
            row = await cur.fetchone()
        if row is None:
            return None
        trigger = _row_to_trigger(row)
        if owner_user_id is not None and trigger.user_id != owner_user_id:
            return None
        return trigger

    async def list(self, user_id: str) -> list[TriggerRow]:
        """Return all active rows for ``user_id``."""
        async with self._conn() as conn:
            cur = await conn.execute(
                f"SELECT {_SELECT_ALL} FROM triggers "
                "WHERE user_id = ? AND status = 'active' "
                "ORDER BY created_at ASC",
                (user_id,),
            )
            rows = await cur.fetchall()
        return [_row_to_trigger(r) for r in rows]

    async def list_by_name(self, user_id: str, name: str) -> TriggerRow | None:
        """Return the active row matching ``(user_id, name)``, or ``None``."""
        async with self._conn() as conn:
            cur = await conn.execute(
                f"SELECT {_SELECT_ALL} FROM triggers "
                "WHERE user_id = ? AND name = ? AND status = 'active'",
                (user_id, name),
            )
            row = await cur.fetchone()
        if row is None:
            return None
        return _row_to_trigger(row)

    async def count_active(self, user_id: str) -> int:
        """Return the count of active triggers for ``user_id``."""
        async with self._conn() as conn:
            cur = await conn.execute(
                "SELECT COUNT(*) FROM triggers WHERE user_id = ? AND status = 'active'",
                (user_id,),
            )
            row = await cur.fetchone()
        return int(row[0]) if row else 0

    async def time_until_next_due(self, now: int) -> float | None:
        """Seconds until the earliest active ``next_fire_at``, or ``None``."""
        async with self._conn() as conn:
            cur = await conn.execute(
                "SELECT MIN(next_fire_at) FROM triggers WHERE status = 'active'",
            )
            row = await cur.fetchone()
        if row is None or row[0] is None:
            return None
        earliest: int = row[0]
        return max(0.0, float(earliest - now))
