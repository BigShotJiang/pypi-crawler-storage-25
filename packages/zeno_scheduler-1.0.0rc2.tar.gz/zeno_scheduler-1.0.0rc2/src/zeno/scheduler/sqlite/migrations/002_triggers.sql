CREATE TABLE IF NOT EXISTS triggers (
    id           TEXT    PRIMARY KEY,
    user_id      TEXT    NOT NULL,
    thread_key   TEXT,
    channel_ref  TEXT    NOT NULL,
    kind         TEXT    NOT NULL CHECK (kind IN ('one_shot', 'heartbeat', 'cron')),
    name         TEXT,
    prompt       TEXT    NOT NULL,
    metadata     TEXT    NOT NULL,
    spec         TEXT    NOT NULL,
    next_fire_at INTEGER NOT NULL,
    fire_count   INTEGER NOT NULL DEFAULT 0,
    max_fires    INTEGER,
    on_missed    TEXT    NOT NULL CHECK (on_missed IN ('fire', 'drop', 'coalesce')),
    status       TEXT    NOT NULL CHECK (status IN ('active', 'cancelled', 'dead')),
    created_at   INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS triggers_next_fire
    ON triggers (next_fire_at)
    WHERE status = 'active';

CREATE UNIQUE INDEX IF NOT EXISTS triggers_user_name
    ON triggers (user_id, name)
    WHERE name IS NOT NULL AND status = 'active';
