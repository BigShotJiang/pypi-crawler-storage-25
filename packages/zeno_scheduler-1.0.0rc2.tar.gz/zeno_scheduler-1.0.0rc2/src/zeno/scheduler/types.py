"""Public types for zeno-scheduler."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal

TriggerKind = Literal["one_shot", "heartbeat", "cron"]
OnMissed = Literal["fire", "drop", "coalesce"]


@dataclass(frozen=True)
class TriggerRow:
    """Immutable representation of a persisted trigger row."""

    id: str
    user_id: str
    thread_key: str | None
    channel_ref: str
    kind: TriggerKind
    name: str | None
    prompt: str
    metadata: Mapping[str, Any]
    spec: str
    next_fire_at: int  # epoch seconds UTC
    fire_count: int
    max_fires: int | None
    on_missed: OnMissed
    status: Literal["active", "cancelled", "dead"]
    created_at: int  # epoch seconds UTC
