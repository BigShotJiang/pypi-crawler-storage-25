"""Scheduler-specific exceptions."""

from __future__ import annotations


class ScheduleError(Exception):
    """Base class for all zeno-scheduler errors."""


class ScheduleLimitError(ScheduleError):
    """Raised when a scheduling limit is exceeded (agent-visible).

    The message is surfaced directly to the LLM via the tool surface, so it
    should be concise and actionable.

    Example::

        raise ScheduleLimitError("max_active_triggers (10) reached for this user")
    """

    def __init__(self, reason: str) -> None:
        super().__init__(f"Cannot schedule: {reason}")
        self.reason = reason
