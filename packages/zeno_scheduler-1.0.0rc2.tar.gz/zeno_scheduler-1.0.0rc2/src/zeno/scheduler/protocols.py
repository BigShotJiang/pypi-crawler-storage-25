"""ScheduleStore protocol — the contract every persistence backend implements.

Adapters (SqliteScheduleStore, InMemoryScheduleStore) must satisfy this
protocol at runtime. Use ``isinstance(obj, ScheduleStore)`` to verify.

Security invariants enforced at the store layer:
  S1 — ownership: ``owner_user_id`` parameter on ``get``, ``cancel``, and
       ``delete`` causes a silent no-op (same shape as "not found") when the
       caller's user_id does not match the row's user_id. No error is raised,
       no information is leaked.
  S7 — atomic upsert: ``upsert`` with ``max_active`` enforces the limit
       atomically — no race window between the count query and the insert.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from zeno.scheduler.types import TriggerRow


@runtime_checkable
class ScheduleStore(Protocol):
    """Async persistence contract for trigger rows.

    All methods are ``async``. Adapters are free to be stateful (connection
    pooling, caches) as long as the public contract is satisfied.
    """

    async def due(self, now: int) -> list[TriggerRow]:
        """Return active rows with ``next_fire_at <= now``, ordered ascending."""
        ...

    async def claim(self, trigger_id: str) -> TriggerRow | None:
        """Mark a trigger as claimed and return it.

        Idempotent. Returns ``None`` (no error) if already claimed or missing.
        """
        ...

    async def advance(self, trigger_id: str, next_fire_at: int, fire_count: int) -> None:
        """Update ``next_fire_at`` and ``fire_count`` after a successful fire.

        Internal worker call — the scheduler is trusted here; no
        ``owner_user_id`` check. Silent no-op on missing id.
        """
        ...

    async def delete(self, trigger_id: str, *, owner_user_id: str | None = None) -> None:
        """Delete a trigger row entirely.

        Silent no-op on missing id or mismatched ``owner_user_id`` (S1).
        """
        ...

    async def cancel(self, trigger_id: str, *, owner_user_id: str | None = None) -> None:
        """Set ``status='cancelled'`` — does NOT delete the row.

        Silent no-op on missing id or mismatched ``owner_user_id`` (S1).
        """
        ...

    async def upsert(self, row: TriggerRow, *, max_active: int | None = None) -> TriggerRow:
        """Insert or update a trigger row.

        If ``row.name`` is set and a row with ``(user_id, name)`` and
        ``status='active'`` already exists, update it in place keeping
        the existing ``id``.  Otherwise insert.

        If ``max_active`` is provided enforce atomically (S7): raise
        ``ScheduleLimitError`` if inserting a *new* row would push the
        user's active count above ``max_active``.  A same-name UPDATE is
        not counted as a new row.

        Returns the stored row (with any id assigned by the backend).
        """
        ...

    async def get(self, trigger_id: str, *, owner_user_id: str | None = None) -> TriggerRow | None:
        """Fetch a trigger by id.

        Returns ``None`` on missing id or mismatched ``owner_user_id`` (S1).
        """
        ...

    async def list(self, user_id: str) -> list[TriggerRow]:
        """Return all active rows for ``user_id``.

        Excludes ``status='cancelled'`` and ``status='dead'``.
        """
        ...

    async def list_by_name(self, user_id: str, name: str) -> TriggerRow | None:
        """Return the active row matching ``(user_id, name)``, or ``None``."""
        ...

    async def count_active(self, user_id: str) -> int:
        """Return the number of active triggers for ``user_id``.

        Used internally by ``upsert`` for the ``max_active`` check.
        """
        ...

    async def time_until_next_due(self, now: int) -> float | None:
        """Seconds until the earliest active ``next_fire_at``.

        Returns ``None`` when there are no active triggers (signal: sleep
        at cap). Used by the event-driven wakeup in U4.
        """
        ...
