"""Built-in scheduler tools — schedule_once, schedule_heartbeat, schedule_cron,
cancel_trigger, cancel_trigger_by_name, list_triggers.

These are opt-in tools that expose the Scheduler to agents:

    from zeno.scheduler.tools import schedule_once, schedule_cron, list_triggers
    agent = Agent(name="root", instructions="...", tools=[schedule_once, list_triggers])

All tools read scope from `Ctx` (user_id, thread_key, channel).  Tools never
accept those as arguments — the agent cannot cross user boundaries (R3, S1).

The Scheduler instance is retrieved from ``ctx.state["scheduler"]`` (wired by
``ZenoApp`` in U6).  If not present the tool returns a backwards-compatible
message rather than raising (R19).

``ScheduleLimitError`` and ``ScheduleError`` are caught and returned to the
model as human-readable strings so the agent can self-correct (R17).
"""

from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta

from zeno.context import Ctx
from zeno.scheduler.exceptions import ScheduleError, ScheduleLimitError
from zeno.tool import tool

# ---------------------------------------------------------------------------
# Public tools
# ---------------------------------------------------------------------------


@tool
async def schedule_once(
    ctx: Ctx,
    prompt: str,
    delta: str | None = None,
    at: str | None = None,
    name: str | None = None,
    on_missed: str = "fire",
) -> str:
    """Schedule a one-shot reminder that fires once at an absolute time or after a delay.

    Provide exactly one of:
    - ``delta``: how far in the future to fire — e.g. ``"30m"``, ``"2h"``,
      ``"7d"``, or an ISO-8601 duration like ``"PT30M"``, ``"P1DT2H"``.
    - ``at``: an ISO-8601 datetime string — e.g. ``"2026-05-01T09:00:00Z"``.

    ``name`` (optional): stable human-readable label; re-scheduling with the
    same name updates the existing trigger instead of creating a new one.

    ``on_missed``: what to do if the process was down at fire time —
    ``"fire"`` (fire immediately on restart, default) or ``"drop"`` (skip).

    Returns a confirmation string with the trigger id and resolved fire time
    that the agent should echo to the user.
    """
    scheduler = ctx.state.get("scheduler")
    if scheduler is None:
        return "Scheduling is not enabled on this deployment."

    # Mutex: exactly one of at/delta.
    if at is None and delta is None:
        return (
            "Cannot schedule: schedule_once requires either delta (e.g., '30m') "
            "or at (ISO-8601 datetime)."
        )
    if at is not None and delta is not None:
        return (
            "Cannot schedule: schedule_once requires only one of delta or at — provide exactly one."
        )

    if delta is not None:
        parsed_delta = _parse_duration(delta)
        if parsed_delta is None:
            return (
                f"Cannot schedule: unable to parse delta {delta!r} — "
                "use '30m', '2h', '7d', or an ISO-8601 duration like 'PT30M'."
            )
        fire_dt = None
        fire_delta = parsed_delta
    else:
        assert at is not None
        fire_dt = _parse_datetime(at)
        if fire_dt is None:
            return (
                f"Cannot schedule: unable to parse at {at!r} — "
                "use an ISO-8601 datetime like '2026-05-01T09:00:00Z'."
            )
        fire_delta = None

    try:
        row = await scheduler.schedule_once(
            user_id=ctx.user_id,
            thread_key=ctx.thread_key,
            channel=ctx.channel,
            prompt=prompt,
            at=fire_dt,
            delta=fire_delta,
            name=name,
            on_missed=on_missed,
        )
    except (ScheduleLimitError, ScheduleError) as exc:
        return str(exc)

    fire_time_iso = datetime.fromtimestamp(row.next_fire_at, tz=UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    snippet = _prompt_snippet(prompt, 40)
    return (
        f"Scheduled reminder '{snippet}' for {fire_time_iso} "
        f"on channel '{ctx.channel}' (trigger_id: {row.id})."
    )


@tool
async def schedule_heartbeat(
    ctx: Ctx,
    prompt: str,
    interval: str,
    name: str | None = None,
    max_fires: int | None = None,
    on_missed: str = "coalesce",
) -> str:
    """Schedule a recurring heartbeat that fires at a fixed interval.

    ``interval``: how often to fire — e.g. ``"60s"``, ``"30m"``, ``"2h"``,
    ``"1d"``, or an ISO-8601 duration like ``"PT1H"``.  Minimum 60 seconds.

    ``name`` (optional): stable label; re-scheduling with the same name
    updates the existing trigger instead of creating a new one.

    ``max_fires`` (optional): stop after this many fires.  Omit to run
    indefinitely until cancelled.

    ``on_missed``: ``"coalesce"`` (default — fire once on restart and skip
    missed beats) or ``"fire"`` (fire once for each missed beat).

    Returns a confirmation string with the trigger id and first fire time.
    """
    scheduler = ctx.state.get("scheduler")
    if scheduler is None:
        return "Scheduling is not enabled on this deployment."

    parsed = _parse_duration(interval)
    if parsed is None:
        return (
            f"Cannot schedule: unable to parse interval {interval!r} — "
            "use '60s', '30m', '2h', '7d', or an ISO-8601 duration like 'PT1H'."
        )

    interval_s = int(parsed.total_seconds())

    try:
        row = await scheduler.schedule_heartbeat(
            user_id=ctx.user_id,
            thread_key=ctx.thread_key,
            channel=ctx.channel,
            prompt=prompt,
            interval_s=interval_s,
            name=name,
            max_fires=max_fires,
            on_missed=on_missed,
        )
    except (ScheduleLimitError, ScheduleError) as exc:
        return str(exc)

    first_fire_iso = datetime.fromtimestamp(row.next_fire_at, tz=UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    fires_desc = str(max_fires) if max_fires is not None else "until cancelled"
    return (
        f"Scheduled heartbeat every {interval} — will fire {fires_desc} "
        f"starting {first_fire_iso} (trigger_id: {row.id})."
    )


@tool
async def schedule_cron(
    ctx: Ctx,
    prompt: str,
    expression: str,
    timezone: str = "UTC",
    name: str | None = None,
    on_missed: str = "fire",
) -> str:
    """Schedule a recurring cron trigger using a standard 5-field cron expression.

    ``expression``: a 5-field cron expression — e.g. ``"0 9 * * *"`` for
    9 am every day.  Supports common macros like ``"@daily"``, ``"@hourly"``.
    The minimum effective interval is 60 seconds.

    ``timezone``: IANA timezone name — e.g. ``"America/New_York"``,
    ``"Europe/Amsterdam"``.  Defaults to ``"UTC"``.

    ``name`` (optional): stable label; re-scheduling with the same name
    updates the existing trigger.

    ``on_missed``: ``"fire"`` (default) or ``"drop"``.

    Returns a confirmation string with the trigger id and next fire time.
    """
    scheduler = ctx.state.get("scheduler")
    if scheduler is None:
        return "Scheduling is not enabled on this deployment."

    try:
        row = await scheduler.schedule_cron(
            user_id=ctx.user_id,
            thread_key=ctx.thread_key,
            channel=ctx.channel,
            prompt=prompt,
            expression=expression,
            timezone=timezone,
            name=name,
            on_missed=on_missed,
        )
    except (ScheduleLimitError, ScheduleError) as exc:
        return str(exc)

    next_fire_iso = datetime.fromtimestamp(row.next_fire_at, tz=UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    return (
        f"Scheduled cron '{expression}' in {timezone} — "
        f"next fire {next_fire_iso} (trigger_id: {row.id})."
    )


@tool
async def cancel_trigger(ctx: Ctx, trigger_id: str) -> str:
    """Cancel a scheduled trigger by its trigger id.

    Only the trigger's owner can cancel it — passing another user's trigger id
    returns the same "not found" response as a missing id (no authorization
    leak, S1/S7).

    Returns a confirmation string.
    """
    scheduler = ctx.state.get("scheduler")
    if scheduler is None:
        return "Scheduling is not enabled on this deployment."

    cancelled = await scheduler.cancel_trigger(trigger_id, owner_user_id=ctx.user_id)
    if cancelled:
        return f"Cancelled trigger {trigger_id}."
    return f"No trigger found with id '{trigger_id}'."


@tool
async def cancel_trigger_by_name(ctx: Ctx, name: str) -> str:
    """Cancel all active triggers with the given name that belong to you.

    ``name``: the stable label set when the trigger was created.

    Returns a confirmation string indicating how many triggers were cancelled.
    """
    scheduler = ctx.state.get("scheduler")
    if scheduler is None:
        return "Scheduling is not enabled on this deployment."

    count = await scheduler.cancel_trigger_by_name(ctx.user_id, name)
    if count == 0:
        return f"No triggers found with name '{name}'."
    return f"Cancelled {count} trigger(s) named '{name}'."


@tool
async def list_triggers(ctx: Ctx) -> str:
    """List all your active scheduled triggers.

    Returns a formatted summary of all active triggers belonging to you,
    including their id, kind, prompt snippet, next fire time, and name.
    Only your own triggers are visible — other users' triggers are hidden.
    """
    scheduler = ctx.state.get("scheduler")
    if scheduler is None:
        return "Scheduling is not enabled on this deployment."

    rows = await scheduler.list_triggers(ctx.user_id)
    if not rows:
        return "No scheduled triggers."

    lines = [f"You have {len(rows)} scheduled trigger(s):"]
    for row in rows:
        next_fire_iso = datetime.fromtimestamp(row.next_fire_at, tz=UTC).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        name_label = row.name if row.name else "unnamed"
        snippet = _prompt_snippet(row.prompt, 50)
        lines.append(
            f'- {row.id} [{row.kind}] "{snippet}" — next fire {next_fire_iso} ({name_label})'
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

# Shorthand duration pattern: 30s / 30m / 2h / 7d (integers only).
_SHORTHAND_RE = re.compile(r"^(\d+)([smhd])$", re.IGNORECASE)

# ISO-8601 duration pattern: P[nY][nM][nW][nD][T[nH][nM][nS]]
# Supports the common subset: PTxS, PTxM, PTxH, PxD, PxDTyH, etc.
_ISO_DURATION_RE = re.compile(
    r"^P"
    r"(?:(\d+)Y)?"
    r"(?:(\d+)M)?"
    r"(?:(\d+)W)?"
    r"(?:(\d+)D)?"
    r"(?:T"
    r"(?:(\d+)H)?"
    r"(?:(\d+)M)?"
    r"(?:(\d+(?:\.\d+)?)S)?"
    r")?$",
    re.IGNORECASE,
)


def _parse_duration(s: str) -> timedelta | None:
    """Parse a duration string into a ``timedelta``.

    Accepts:
    - Shorthand: ``"30s"``, ``"30m"``, ``"2h"``, ``"7d"``
    - ISO-8601 duration: ``"PT30M"``, ``"P1DT2H"``, ``"PT1H30M"``

    Returns ``None`` for unrecognised formats.
    """
    s = s.strip()

    # Shorthand first (fast path).
    m = _SHORTHAND_RE.match(s)
    if m:
        value, unit = int(m.group(1)), m.group(2).lower()
        mapping = {"s": 1, "m": 60, "h": 3600, "d": 86400}
        return timedelta(seconds=value * mapping[unit])

    # ISO-8601 duration.
    m2 = _ISO_DURATION_RE.match(s)
    if m2:
        # groups: years, months, weeks, days, hours, minutes, seconds
        years_s, months_s, weeks_s, days_s, hours_s, minutes_s, seconds_s = m2.groups()
        years = int(years_s or 0)
        months = int(months_s or 0)
        weeks = int(weeks_s or 0)
        days = int(days_s or 0)
        hours = int(hours_s or 0)
        minutes = int(minutes_s or 0)
        seconds = float(seconds_s or 0)

        # If the pattern matched but all groups are empty/zero, it's not a valid
        # duration (e.g. bare "P").
        total_s = (
            years * 365 * 86400
            + months * 30 * 86400
            + weeks * 7 * 86400
            + days * 86400
            + hours * 3600
            + minutes * 60
            + seconds
        )
        if total_s == 0 and s.upper() != "PT0S":
            return None
        return timedelta(seconds=total_s)

    return None


def _parse_datetime(s: str) -> datetime | None:
    """Parse an ISO-8601 datetime string into a timezone-aware ``datetime``.

    Handles ``Z`` suffix by normalising to ``+00:00`` before calling
    ``datetime.fromisoformat``.  Returns ``None`` on parse failure.
    """
    s = s.strip()
    # Normalise Z → +00:00 so fromisoformat handles it on Python < 3.11.
    if s.endswith("Z") or s.endswith("z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        return None
    # Make timezone-aware if naive (assume UTC).
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt


def _prompt_snippet(prompt: str, max_len: int) -> str:
    """Return the first ``max_len`` characters of ``prompt``, truncated with ellipsis."""
    if len(prompt) <= max_len:
        return prompt
    return prompt[:max_len] + "..."
