"""`InMemoryScheduleStore` — fast, ephemeral adapter for tests.

Intentionally placed in ``zeno.scheduler.testing`` (not ``zeno.testing``) to
avoid a circular import with other ``zeno.*`` packages (C4).

Two instances created with ``InMemoryScheduleStore()`` do NOT share state —
each gets a fresh ``dict`` and ``asyncio.Lock``.

Security invariants are identical to ``SqliteScheduleStore``:
  S1 — ``get``, ``cancel``, and ``delete`` silently return / no-op on
       ``owner_user_id`` mismatch.
  S7 — ``upsert`` with ``max_active`` is serialized by an ``asyncio.Lock``
       that spans the count + mutate pair atomically within the event loop.
"""

from __future__ import annotations

import asyncio
from typing import Any

from zeno.scheduler.exceptions import ScheduleLimitError
from zeno.scheduler.types import TriggerRow


class InMemoryScheduleStore:
    """Pure-Python, in-memory trigger store for unit tests and local development.

    Not thread-safe across OS threads; safe under ``asyncio`` concurrency
    (single event loop).
    """

    def __init__(self) -> None:
        self._rows: dict[str, TriggerRow] = {}
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # ScheduleStore protocol
    # ------------------------------------------------------------------

    async def due(self, now: int) -> list[TriggerRow]:
        """Return active rows with ``next_fire_at <= now``, ordered ascending."""
        async with self._lock:
            result = [
                r for r in self._rows.values() if r.status == "active" and r.next_fire_at <= now
            ]
        result.sort(key=lambda r: r.next_fire_at)
        return result

    async def claim(self, trigger_id: str) -> TriggerRow | None:
        """Idempotent — returns ``None`` if already claimed or missing."""
        async with self._lock:
            row = self._rows.get(trigger_id)
            if row is None or row.status != "active":
                return None
            return row

    async def advance(self, trigger_id: str, next_fire_at: int, fire_count: int) -> None:
        """Update ``next_fire_at`` and ``fire_count`` — silent no-op on missing."""
        async with self._lock:
            row = self._rows.get(trigger_id)
            if row is None:
                return
            self._rows[trigger_id] = _replace(row, next_fire_at=next_fire_at, fire_count=fire_count)

    async def delete(self, trigger_id: str, *, owner_user_id: str | None = None) -> None:
        """Delete a trigger row (S1 ownership guard)."""
        async with self._lock:
            row = self._rows.get(trigger_id)
            if row is None:
                return
            if owner_user_id is not None and row.user_id != owner_user_id:
                return
            del self._rows[trigger_id]

    async def cancel(self, trigger_id: str, *, owner_user_id: str | None = None) -> None:
        """Set ``status='cancelled'`` — does NOT delete the row (S1 guard)."""
        async with self._lock:
            row = self._rows.get(trigger_id)
            if row is None:
                return
            if owner_user_id is not None and row.user_id != owner_user_id:
                return
            self._rows[trigger_id] = _replace(row, status="cancelled")

    async def upsert(self, row: TriggerRow, *, max_active: int | None = None) -> TriggerRow:
        """Insert or name-update, optionally enforcing a per-user limit (S7)."""
        async with self._lock:
            existing_id: str | None = None
            if row.name is not None:
                for stored in self._rows.values():
                    if (
                        stored.user_id == row.user_id
                        and stored.name == row.name
                        and stored.status == "active"
                    ):
                        existing_id = stored.id
                        break

            if existing_id is None and max_active is not None:
                active_count = sum(
                    1
                    for r in self._rows.values()
                    if r.user_id == row.user_id and r.status == "active"
                )
                if active_count >= max_active:
                    raise ScheduleLimitError(
                        f"user already has {active_count} active trigger(s); "
                        f"limit is {max_active} active triggers"
                    )

            if existing_id is not None:
                # Keep the original id stable.
                stored_row = _replace(
                    row,
                    id=existing_id,
                )
                self._rows[existing_id] = stored_row
                return stored_row
            else:
                self._rows[row.id] = row
                return row

    async def get(self, trigger_id: str, *, owner_user_id: str | None = None) -> TriggerRow | None:
        """Fetch by id (S1 ownership guard returns ``None`` on mismatch)."""
        async with self._lock:
            row = self._rows.get(trigger_id)
        if row is None:
            return None
        if owner_user_id is not None and row.user_id != owner_user_id:
            return None
        return row

    async def list(self, user_id: str) -> list[TriggerRow]:
        """Return all active rows for ``user_id``."""
        async with self._lock:
            result = [
                r for r in self._rows.values() if r.user_id == user_id and r.status == "active"
            ]
        result.sort(key=lambda r: r.created_at)
        return result

    async def list_by_name(self, user_id: str, name: str) -> TriggerRow | None:
        """Return the active row matching ``(user_id, name)``, or ``None``."""
        async with self._lock:
            for row in self._rows.values():
                if row.user_id == user_id and row.name == name and row.status == "active":
                    return row
        return None

    async def count_active(self, user_id: str) -> int:
        """Return the count of active triggers for ``user_id``."""
        async with self._lock:
            return sum(
                1 for r in self._rows.values() if r.user_id == user_id and r.status == "active"
            )

    async def time_until_next_due(self, now: int) -> float | None:
        """Seconds until the earliest active ``next_fire_at``, or ``None``."""
        async with self._lock:
            active = [r.next_fire_at for r in self._rows.values() if r.status == "active"]
        if not active:
            return None
        return max(0.0, float(min(active) - now))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _replace(row: TriggerRow, **kwargs: Any) -> TriggerRow:
    """Return a new ``TriggerRow`` with the given fields replaced."""
    import dataclasses

    return dataclasses.replace(row, **kwargs)
