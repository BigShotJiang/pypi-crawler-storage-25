"""fusion submodule."""
