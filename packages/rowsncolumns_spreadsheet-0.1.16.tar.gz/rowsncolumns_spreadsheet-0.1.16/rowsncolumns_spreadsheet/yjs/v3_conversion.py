"""
V3 Data Structure Conversion Utilities.

V3 uses a flat Map structure for sheet data storage:
- Key format: `${sheetId}!${A1Address}` (e.g., "1!A1", "2!B5")
- Value: CellDataV3 containing cell data and position

Benefits:
- O(1) cell lookups by key
- Sparse storage (no null padding for empty cells)
- More efficient for large spreadsheets with sparse data
"""

import re
from typing import Any, Dict, List, Optional, TypedDict


class CellDataV3(TypedDict):
    """
    V3 cell data structure containing value and position.

    - value: The cell data
    - sId: Sheet ID
    - r: Row index (1-based)
    - c: Column index (1-based)
    """

    value: Dict[str, Any]
    sId: int  # Sheet ID
    r: int  # Row index (1-based)
    c: int  # Column index (1-based)


# Type aliases
CellKeyV3 = str  # Format: "sheetId!A1" (e.g., "1!A1", "2!B5", "1!AA100")
SheetDataV2 = Dict[int, List[Optional[Dict[str, Any]]]]
# Flat structure: cellKey -> CellDataV3
SheetDataV3 = Dict[CellKeyV3, CellDataV3]


def _cell_to_address(row_index: int, column_index: int) -> str:
    """
    Convert cell coordinates to A1 notation.

    Args:
        row_index: Zero-based row index
        column_index: Zero-based column index

    Returns:
        Cell address in A1 notation (e.g., "A1", "B2")
    """
    # Convert column index to letter(s)
    column = ""
    col = column_index + 1
    while col > 0:
        col -= 1
        column = chr(65 + (col % 26)) + column
        col //= 26

    # Row is 1-indexed
    return f"{column}{row_index + 1}"


def _letter_to_column_index(letters: str) -> int:
    """
    Convert column letters to 1-based column index.

    Args:
        letters: Column letters (e.g., "A", "B", "AA")

    Returns:
        1-based column index (A=1, B=2, ..., Z=26, AA=27)
    """
    result = 0
    for char in letters.upper():
        result = result * 26 + (ord(char) - ord("A") + 1)
    return result


def create_cell_key_v3(sheet_id: int, row_index: int, column_index: int) -> CellKeyV3:
    """
    Create a V3 cell key from sheet ID, row and column indices.

    Args:
        sheet_id: Sheet ID
        row_index: 1-based row index
        column_index: 1-based column index

    Returns:
        Cell key in format "sheetId!A1" (e.g., "1!A1", "2!B5")

    Examples:
        >>> create_cell_key_v3(1, 1, 1)
        '1!A1'
        >>> create_cell_key_v3(2, 5, 3)
        '2!C5'
        >>> create_cell_key_v3(1, 1, 27)
        '1!AA1'
    """
    # Convert to 0-based for _cell_to_address
    address = _cell_to_address(row_index - 1, column_index - 1)
    return f"{sheet_id}!{address}"


def parse_cell_key_v3(cell_key: CellKeyV3) -> Optional[Dict[str, Any]]:
    """
    Parse a V3 cell key to extract sheet ID and position information.

    Args:
        cell_key: Cell key in format "sheetId!A1" (e.g., "1!A1")

    Returns:
        Dict with sheetId, address, rowIndex, columnIndex or None if invalid

    Examples:
        >>> parse_cell_key_v3("1!A1")
        {'sheetId': 1, 'address': 'A1', 'rowIndex': 1, 'columnIndex': 1}
    """
    match = re.match(r"^(\d+)!([A-Z]+)(\d+)$", cell_key, re.IGNORECASE)
    if not match:
        return None

    sheet_id_str, column_letters, row_index_str = match.groups()
    return {
        "sheetId": int(sheet_id_str),
        "address": f"{column_letters.upper()}{row_index_str}",
        "rowIndex": int(row_index_str),
        "columnIndex": _letter_to_column_index(column_letters),
    }


def create_cell_data_v3(
    value: Dict[str, Any],
    sheet_id: int,
    row_index: int,
    column_index: int,
) -> CellDataV3:
    """
    Create a CellDataV3 object with position and sheet ID.

    Args:
        value: Cell data dictionary
        sheet_id: Sheet ID
        row_index: 1-based row index
        column_index: 1-based column index

    Returns:
        CellDataV3 with value and position (sId, r, c)
    """
    return {
        "value": value,
        "sId": sheet_id,
        "r": row_index,
        "c": column_index,
    }


def sheet_data_v2_to_v3(sheet_data: SheetDataV2) -> SheetDataV3:
    """
    Convert V2 SheetData (nested array structure) to V3 flat dict format.

    V2 format: Dict[sheetId, List[Optional[Dict with 'values' key]]]
    - V2 uses sparse arrays where the array index IS the row/column number
    - Example: rows[4] contains row 4's data, values[3] contains column C's data

    V3 format: Dict[cellKey, CellDataV3]
    - Flat structure with keys like "1!A1", "2!B5"

    Args:
        sheet_data: V2 sheet data structure

    Returns:
        V3 sheet data as a flat dictionary
    """
    v3_data: SheetDataV3 = {}

    for sheet_id_int, rows in sheet_data.items():
        sheet_id = int(sheet_id_int)
        if not rows:
            continue

        # V2 uses sparse arrays where index = row number
        for row_index, row in enumerate(rows):
            if not row or not row.get("values"):
                continue

            values = row["values"]
            # V2 uses sparse arrays where index = column number
            for col_index, cell_data in enumerate(values):
                if cell_data:
                    # Array indices ARE the row/column numbers in V2
                    key = create_cell_key_v3(sheet_id, row_index, col_index)
                    v3_data[key] = create_cell_data_v3(
                        cell_data, sheet_id, row_index, col_index
                    )

    return v3_data


def sheet_data_v3_to_v2(v3_data: SheetDataV3) -> SheetDataV2:
    """
    Convert V3 flat dict format to V2 SheetData (nested array structure).

    V3 format: Dict[cellKey, CellDataV3]
    V2 format: Dict[sheetId, List[Optional[Dict with 'values' key]]]

    Args:
        v3_data: V3 sheet data (flat dictionary)

    Returns:
        V2 sheet data as nested array structure
    """
    sheet_data: SheetDataV2 = {}

    for cell_key, cell_data_v3 in v3_data.items():
        if not cell_data_v3:
            continue

        sheet_id = cell_data_v3["sId"]
        row_idx = cell_data_v3["r"]
        col_idx = cell_data_v3["c"]
        value = cell_data_v3["value"]

        # Ensure sheet exists
        if sheet_id not in sheet_data:
            sheet_data[sheet_id] = []

        # Ensure row exists
        while len(sheet_data[sheet_id]) <= row_idx:
            sheet_data[sheet_id].append(None)

        if sheet_data[sheet_id][row_idx] is None:
            sheet_data[sheet_id][row_idx] = {"values": []}

        row = sheet_data[sheet_id][row_idx]
        if row.get("values") is None:
            row["values"] = []

        # Ensure values array is long enough
        while len(row["values"]) <= col_idx:
            row["values"].append(None)

        row["values"][col_idx] = value

    return sheet_data


# Alias for backwards compatibility
create_sheet_cell_identifier = create_cell_key_v3

__all__ = [
    "CellDataV3",
    "CellKeyV3",
    "SheetDataV2",
    "SheetDataV3",
    "create_cell_key_v3",
    "parse_cell_key_v3",
    "create_cell_data_v3",
    "sheet_data_v2_to_v3",
    "sheet_data_v3_to_v2",
    # Backwards compatibility alias
    "create_sheet_cell_identifier",
]
