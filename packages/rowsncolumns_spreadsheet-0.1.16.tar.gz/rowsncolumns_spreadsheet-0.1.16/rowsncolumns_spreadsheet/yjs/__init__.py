"""
Yjs-specific helpers for manipulating spreadsheet data.

Currently exposes a Python port of the TypeScript `changeBatch` interface that
operates directly on Y.Doc data structures (via pycrdt-compatible array/map
objects).
"""

from .change_batch import change_batch
from .change_formatting import change_formatting
from .create_new_sheet import create_sheet
from .create_table import create_table
from .insert_column import insert_column
from .insert_row import insert_row
from .delete_column import delete_column
from .delete_row import delete_row
from .insert_table_column import insert_table_column
from .delete_table_column import delete_table_column
from .update_sheet import update_sheet
from .update_table import update_table
from .v3_conversion import (
    sheet_data_v2_to_v3,
    sheet_data_v3_to_v2,
    create_cell_key_v3,
    parse_cell_key_v3,
    create_cell_data_v3,
    # Backwards compatibility alias
    create_sheet_cell_identifier,
    # Types
    CellDataV3,
    CellKeyV3,
    SheetDataV2,
    SheetDataV3,
)

__all__ = [
    "change_batch",
    "change_formatting",
    "create_sheet",
    "insert_row",
    "insert_column",
    "delete_row",
    "delete_column",
    "update_sheet",
    "create_table",
    "update_table",
    "insert_table_column",
    "delete_table_column",
    # V3 conversion utilities
    "sheet_data_v2_to_v3",
    "sheet_data_v3_to_v2",
    "create_cell_key_v3",
    "parse_cell_key_v3",
    "create_cell_data_v3",
    # Backwards compatibility alias
    "create_sheet_cell_identifier",
    # V3 types
    "CellDataV3",
    "CellKeyV3",
    "SheetDataV2",
    "SheetDataV3",
]
