"""Tests for V3 data structure conversion utilities (flat map structure)."""

import pytest
from rowsncolumns_spreadsheet.yjs.v3_conversion import (
    create_cell_key_v3,
    parse_cell_key_v3,
    create_cell_data_v3,
    sheet_data_v2_to_v3,
    sheet_data_v3_to_v2,
    # Backwards compatibility alias
    create_sheet_cell_identifier,
)


class TestCreateCellKeyV3:
    """Tests for create_cell_key_v3 function."""

    def test_simple_cell(self):
        """Test creating key for cell 1!A1."""
        assert create_cell_key_v3(1, 1, 1) == "1!A1"

    def test_different_row(self):
        """Test creating key with different row."""
        assert create_cell_key_v3(1, 5, 1) == "1!A5"

    def test_multi_digit_row(self):
        """Test creating key with multi-digit row."""
        assert create_cell_key_v3(1, 100, 1) == "1!A100"

    def test_multi_letter_column(self):
        """Test creating key with multi-letter column (AA)."""
        assert create_cell_key_v3(1, 1, 27) == "1!AA1"

    def test_column_z(self):
        """Test creating key for column Z."""
        assert create_cell_key_v3(1, 1, 26) == "1!Z1"

    def test_large_column(self):
        """Test creating key for large column numbers."""
        # AB = 28
        assert create_cell_key_v3(1, 1, 28) == "1!AB1"

    def test_different_sheet(self):
        """Test creating key for different sheet."""
        assert create_cell_key_v3(2, 5, 2) == "2!B5"

    def test_b5(self):
        """Test creating key for 1!B5."""
        assert create_cell_key_v3(1, 5, 2) == "1!B5"


class TestParseCellKeyV3:
    """Tests for parse_cell_key_v3 function."""

    def test_simple_cell(self):
        """Test parsing key for cell 1!A1."""
        result = parse_cell_key_v3("1!A1")
        assert result == {
            "sheetId": 1,
            "address": "A1",
            "rowIndex": 1,
            "columnIndex": 1,
        }

    def test_different_row(self):
        """Test parsing key with different row."""
        result = parse_cell_key_v3("1!B5")
        assert result["sheetId"] == 1
        assert result["rowIndex"] == 5
        assert result["columnIndex"] == 2

    def test_multi_letter_column(self):
        """Test parsing key with multi-letter column."""
        result = parse_cell_key_v3("2!AA1")
        assert result["sheetId"] == 2
        assert result["columnIndex"] == 27  # AA = 27

    def test_case_insensitive(self):
        """Test that parsing is case insensitive."""
        result = parse_cell_key_v3("1!aa1")
        assert result["address"] == "AA1"
        assert result["columnIndex"] == 27

    def test_invalid_key(self):
        """Test parsing invalid key."""
        assert parse_cell_key_v3("invalid") is None
        assert parse_cell_key_v3("A1") is None  # Missing sheetId
        assert parse_cell_key_v3("1!A") is None  # Missing row
        assert parse_cell_key_v3("") is None

    def test_roundtrip(self):
        """Test that create and parse are inverses."""
        test_cases = [
            (1, 1, 1),
            (2, 10, 26),
            (5, 100, 52),
        ]
        for sheet_id, row, col in test_cases:
            key = create_cell_key_v3(sheet_id, row, col)
            parsed = parse_cell_key_v3(key)
            assert parsed["sheetId"] == sheet_id
            assert parsed["rowIndex"] == row
            assert parsed["columnIndex"] == col


class TestCreateCellDataV3:
    """Tests for create_cell_data_v3 function."""

    def test_creates_correct_structure(self):
        """Test that CellDataV3 structure is correct (with sId)."""
        value = {"ue": {"sv": "Hello"}}
        result = create_cell_data_v3(value, 1, 2, 3)
        assert result == {
            "value": {"ue": {"sv": "Hello"}},
            "sId": 1,
            "r": 2,
            "c": 3,
        }

    def test_different_sheet_id(self):
        """Test with different sheet ID."""
        value = {"fv": "Test"}
        result = create_cell_data_v3(value, 5, 10, 20)
        assert result["sId"] == 5
        assert result["r"] == 10
        assert result["c"] == 20


class TestSheetDataV2ToV3:
    """Tests for sheet_data_v2_to_v3 function (flat structure)."""

    def test_empty_data(self):
        """Test converting empty sheet data."""
        result = sheet_data_v2_to_v3({})
        assert result == {}

    def test_single_cell(self):
        """Test converting single cell.

        V2 uses sparse arrays where index matches row/column number.
        Result is flat: cellKey -> CellDataV3
        """
        v2_data = {
            1: [None, {"values": [None, {"ue": {"sv": "Hello"}}]}]
        }
        result = sheet_data_v2_to_v3(v2_data)

        # Flat structure with key "1!A1"
        assert "1!A1" in result
        assert result["1!A1"]["value"] == {"ue": {"sv": "Hello"}}
        assert result["1!A1"]["sId"] == 1
        assert result["1!A1"]["r"] == 1
        assert result["1!A1"]["c"] == 1

    def test_sparse_data(self):
        """Test converting sparse data (cells with nulls in between).

        V2 uses sparse arrays where index matches row/column number.
        """
        v2_data = {
            1: [
                None,  # index 0 (unused)
                {"values": [None, None, None, {"ue": {"sv": "C1"}}]},  # row 1, column 3
                None,  # row 2 is empty
                {"values": [None, {"ue": {"sv": "A3"}}]},  # row 3, column 1
            ]
        }
        result = sheet_data_v2_to_v3(v2_data)

        # Should only have 2 cells
        assert len(result) == 2
        assert "1!C1" in result
        assert "1!A3" in result
        # Null cells should not be in the result
        assert "1!A1" not in result
        assert "1!B1" not in result

    def test_multiple_sheets(self):
        """Test converting data from multiple sheets.

        Result is flat: cellKey -> CellDataV3
        """
        v2_data = {
            1: [None, {"values": [None, {"ue": {"sv": "Sheet1"}}]}],
            2: [None, {"values": [None, {"ue": {"sv": "Sheet2"}}]}],
        }
        result = sheet_data_v2_to_v3(v2_data)

        assert "1!A1" in result
        assert "2!A1" in result
        assert result["1!A1"]["value"]["ue"]["sv"] == "Sheet1"
        assert result["1!A1"]["sId"] == 1
        assert result["2!A1"]["value"]["ue"]["sv"] == "Sheet2"
        assert result["2!A1"]["sId"] == 2


class TestSheetDataV3ToV2:
    """Tests for sheet_data_v3_to_v2 function."""

    def test_empty_data(self):
        """Test converting empty V3 data."""
        result = sheet_data_v3_to_v2({})
        assert result == {}

    def test_single_cell(self):
        """Test converting single cell."""
        v3_data = {
            "1!A1": {"value": {"fv": "Hello"}, "sId": 1, "r": 1, "c": 1}
        }
        result = sheet_data_v3_to_v2(v3_data)

        assert 1 in result
        assert result[1][1]["values"][1] == {"fv": "Hello"}

    def test_multiple_cells(self):
        """Test converting multiple cells."""
        v3_data = {
            "1!A1": {"value": {"fv": "A1"}, "sId": 1, "r": 1, "c": 1},
            "1!B1": {"value": {"fv": "B1"}, "sId": 1, "r": 1, "c": 2},
            "1!A2": {"value": {"fv": "A2"}, "sId": 1, "r": 2, "c": 1},
        }
        result = sheet_data_v3_to_v2(v3_data)

        assert result[1][1]["values"][1] == {"fv": "A1"}
        assert result[1][1]["values"][2] == {"fv": "B1"}
        assert result[1][2]["values"][1] == {"fv": "A2"}

    def test_multiple_sheets(self):
        """Test converting data from multiple sheets."""
        v3_data = {
            "1!A1": {"value": {"fv": "Sheet1"}, "sId": 1, "r": 1, "c": 1},
            "2!A1": {"value": {"fv": "Sheet2"}, "sId": 2, "r": 1, "c": 1},
        }
        result = sheet_data_v3_to_v2(v3_data)

        assert result[1][1]["values"][1] == {"fv": "Sheet1"}
        assert result[2][1]["values"][1] == {"fv": "Sheet2"}

    def test_roundtrip(self):
        """Test that V2 -> V3 -> V2 produces equivalent data."""
        v2_original = {
            1: [
                None,
                {"values": [None, {"fv": "A1"}, {"fv": "B1"}]},
                {"values": [None, {"fv": "A2"}]},
            ],
        }
        v3_data = sheet_data_v2_to_v3(v2_original)
        v2_result = sheet_data_v3_to_v2(v3_data)

        assert v2_result[1][1]["values"][1] == {"fv": "A1"}
        assert v2_result[1][1]["values"][2] == {"fv": "B1"}
        assert v2_result[1][2]["values"][1] == {"fv": "A2"}


class TestBackwardsCompatibility:
    """Tests for backwards compatibility aliases."""

    def test_create_sheet_cell_identifier_is_alias(self):
        """Test that create_sheet_cell_identifier is an alias for create_cell_key_v3."""
        assert create_sheet_cell_identifier(1, 1, 1) == create_cell_key_v3(1, 1, 1)
        assert create_sheet_cell_identifier(2, 5, 10) == create_cell_key_v3(2, 5, 10)
