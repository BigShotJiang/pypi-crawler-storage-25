# Projects

This directory contains all active work. Each project should be self-contained enough that execution can happen mostly inside that project directory.

This template is designed for OpenCode `chatloop`:

- early conversation should focus on building `PRD.md`
- the loop plugin only works from `PRD.md`, restarting from scratch on each idle checkpoint

## When to create a new project

Create a new project when the work has its own goal, context, and deliverables. Examples:

- a research task
- a one-off implementation
- a bugfix stream
- a larger initiative that may later split into multiple tasks

## Naming

Use `MM-DD-<project-name>` for each project directory.

## Default structure

Start with the simplest structure:

```text
MM-DD-<project-name>/
  PRD.md
  progress.md
  memory.md
  playground/
  reference/
```

Use this for research, one-off development, focused cleanup, and other work that can stay inside one clear work boundary.

## File roles

- `PRD.md`: meaning, scope, requirements, constraints, completion target
- `memory.md`: local context, important files, working notes
- `progress.md`: current status, key decisions, next step
- `playground/`: drafts, experiments, temporary outputs
- `reference/`: project-local references and samples

`PRD.md` is the single primary entry file. `memory.md` and `progress.md` are optional supporting context.

## Subdirectory growth

If the work later grows sub-parts, do not force a complex project/task management model first. Just create subdirectories and place a new `PRD.md` inside the relevant subdirectory:

```text
MM-DD-<project-name>/
  PRD.md
  progress.md
  memory.md
  subtask-a/
      PRD.md
      progress.md
      memory.md
```

This keeps hierarchy growing from `PRD.md` itself instead of forcing an up-front management structure.
