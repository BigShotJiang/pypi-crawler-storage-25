"""Tests for athanor.runner --- Runner class, tool execution, score parsing."""

import json
import os
import subprocess
import tempfile
import urllib.error

from unittest.mock import patch, MagicMock

from athanor.runner import Runner, _NoRedirectHandler


# ---------------------------------------------------------------------------
# Helper: create a Runner without needing real docker
# ---------------------------------------------------------------------------

def _make_runner(**overrides):
    """Create a Runner with docker mocked out."""
    with patch("shutil.which", return_value="/usr/bin/docker"):
        r = Runner(token="test-token", **overrides)
    return r


# ---------------------------------------------------------------------------
# 1. Runner.__init__
# ---------------------------------------------------------------------------

class TestRunnerInit:
    """Runner construction and defaults."""

    @patch("shutil.which", return_value="/usr/bin/docker")
    def test_defaults(self, mock_which):
        r = Runner(token="tok123")
        assert r.token == "tok123"
        assert r.platform_url == "https://tahoe.athanor-ai.com"
        assert r.name == "default"
        assert r.runner_id is None
        assert r.docker_bin == "/usr/bin/docker"

    @patch("shutil.which", return_value="/usr/bin/docker")
    def test_custom_platform_url(self, mock_which):
        r = Runner(token="t", platform_url="https://custom.example.com/")
        # Trailing slash stripped
        assert r.platform_url == "https://custom.example.com"

    @patch("shutil.which", return_value="/usr/bin/docker")
    def test_custom_name(self, mock_which):
        r = Runner(token="t", name="worker-1")
        assert r.name == "worker-1"

    @patch("shutil.which", side_effect=lambda cmd: "/usr/bin/podman" if cmd == "podman" else None)
    def test_podman_fallback(self, mock_which):
        r = Runner(token="t")
        assert r.docker_bin == "/usr/bin/podman"

    @patch("shutil.which", return_value=None)
    def test_no_docker_raises(self, mock_which):
        try:
            Runner(token="t")
            assert False, "Expected RuntimeError"
        except RuntimeError as e:
            assert "Docker" in str(e) or "Podman" in str(e)


# ---------------------------------------------------------------------------
# 2. _NoRedirectHandler
# ---------------------------------------------------------------------------

class TestNoRedirectHandler:
    """Verify redirect handler raises HTTPError instead of following."""

    def test_raises_on_redirect(self):
        handler = _NoRedirectHandler()
        req = MagicMock()
        fp = MagicMock()
        try:
            handler.redirect_request(req, fp, 302, "Found", {}, "https://other.com")
            assert False, "Expected HTTPError"
        except urllib.error.HTTPError as e:
            assert e.code == 302
            assert e.url == "https://other.com"

    def test_raises_on_301(self):
        handler = _NoRedirectHandler()
        try:
            handler.redirect_request(MagicMock(), MagicMock(), 301, "Moved", {}, "https://x.com")
            assert False, "Expected HTTPError"
        except urllib.error.HTTPError as e:
            assert e.code == 301


# ---------------------------------------------------------------------------
# 3. _exec_tool read_file
# ---------------------------------------------------------------------------

class TestExecToolReadFile:
    """_exec_tool('read_file', ...) reads from data/ and shared/."""

    def test_read_from_data(self):
        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)
            with open(os.path.join(data_dir, "solution.py"), "w") as f:
                f.write("print('hello')")

            result = runner._exec_tool(
                "read_file", {"path": "data/solution.py"},
                data_dir, shared_dir, "img:latest",
            )
            assert result == "print('hello')"

    def test_read_from_shared(self):
        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)
            with open(os.path.join(shared_dir, "ref.txt"), "w") as f:
                f.write("reference data")

            result = runner._exec_tool(
                "read_file", {"path": "shared/ref.txt"},
                data_dir, shared_dir, "img:latest",
            )
            assert result == "reference data"

    def test_read_file_not_found(self):
        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)

            result = runner._exec_tool(
                "read_file", {"path": "data/nonexistent.py"},
                data_dir, shared_dir, "img:latest",
            )
            assert "Error" in result
            assert "not found" in result

    def test_read_bare_path_resolves_to_data(self):
        """A path without data/ or shared/ prefix resolves relative to data_dir."""
        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)
            with open(os.path.join(data_dir, "foo.py"), "w") as f:
                f.write("bare")

            result = runner._exec_tool(
                "read_file", {"path": "foo.py"},
                data_dir, shared_dir, "img:latest",
            )
            assert result == "bare"

    def test_read_truncates_large_file(self):
        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)
            with open(os.path.join(data_dir, "big.txt"), "w") as f:
                f.write("x" * 50000)

            result = runner._exec_tool(
                "read_file", {"path": "data/big.txt"},
                data_dir, shared_dir, "img:latest",
            )
            assert len(result) == 30000


# ---------------------------------------------------------------------------
# 4. _exec_tool write_file
# ---------------------------------------------------------------------------

class TestExecToolWriteFile:
    """_exec_tool('write_file', ...) writes to data/ directory."""

    def test_write_file(self):
        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)

            result = runner._exec_tool(
                "write_file",
                {"path": "solution.py", "content": "print(42)"},
                data_dir, shared_dir, "img:latest",
            )
            assert "Written" in result
            assert "9 chars" in result
            written = open(os.path.join(data_dir, "solution.py")).read()
            assert written == "print(42)"

    def test_write_file_strips_directory_from_path(self):
        """write_file uses os.path.basename, so nested paths get flattened."""
        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)

            runner._exec_tool(
                "write_file",
                {"path": "sub/deep.py", "content": "code"},
                data_dir, shared_dir, "img:latest",
            )
            # Should write to data/deep.py (basename only)
            assert os.path.isfile(os.path.join(data_dir, "deep.py"))


# ---------------------------------------------------------------------------
# 5. _exec_tool bash
# ---------------------------------------------------------------------------

class TestExecToolBash:
    """_exec_tool('bash', ...) runs command inside container via subprocess."""

    @patch("subprocess.run")
    def test_bash_captures_stdout(self, mock_run):
        mock_run.return_value = MagicMock(
            stdout="hello world", stderr="", returncode=0,
        )
        runner = _make_runner()
        result = runner._exec_tool(
            "bash", {"command": "echo hello"},
            "/tmp/data", "/tmp/shared", "img:latest",
        )
        assert result == "hello world"
        mock_run.assert_called_once()
        call_args = mock_run.call_args
        assert call_args.kwargs["timeout"] == 30

    @patch("subprocess.run")
    def test_bash_includes_stderr(self, mock_run):
        mock_run.return_value = MagicMock(
            stdout="out", stderr="warn: something", returncode=0,
        )
        runner = _make_runner()
        result = runner._exec_tool(
            "bash", {"command": "cmd"},
            "/tmp/data", "/tmp/shared", "img:latest",
        )
        assert "STDERR:" in result
        assert "warn: something" in result

    @patch("subprocess.run")
    def test_bash_nonzero_exit(self, mock_run):
        mock_run.return_value = MagicMock(
            stdout="", stderr="fail", returncode=1,
        )
        runner = _make_runner()
        result = runner._exec_tool(
            "bash", {"command": "false"},
            "/tmp/data", "/tmp/shared", "img:latest",
        )
        assert "exit code 1" in result

    @patch("subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="x", timeout=30))
    def test_bash_timeout(self, mock_run):
        runner = _make_runner()
        result = runner._exec_tool(
            "bash", {"command": "sleep 999"},
            "/tmp/data", "/tmp/shared", "img:latest",
        )
        assert "timed out" in result

    @patch("subprocess.run")
    def test_bash_no_output(self, mock_run):
        mock_run.return_value = MagicMock(stdout="", stderr="", returncode=0)
        runner = _make_runner()
        result = runner._exec_tool(
            "bash", {"command": "true"},
            "/tmp/data", "/tmp/shared", "img:latest",
        )
        assert result == "(no output)"


# ---------------------------------------------------------------------------
# 6. _exec_tool unknown
# ---------------------------------------------------------------------------

class TestExecToolUnknown:
    """Unknown tool names return an error string."""

    def test_unknown_tool(self):
        runner = _make_runner()
        result = runner._exec_tool(
            "delete_file", {"path": "x"},
            "/tmp/data", "/tmp/shared", "img:latest",
        )
        assert "Unknown tool" in result
        assert "delete_file" in result


# ---------------------------------------------------------------------------
# 7. run_score parsing
# ---------------------------------------------------------------------------

class TestRunScoreParsing:
    """run_score parses score JSON from container stdout."""

    @patch("subprocess.run")
    def test_parses_score_with_markers(self, mock_run):
        score_json = json.dumps({"score": 0.85, "metadata": {"checks_passed": 5}})
        stdout = f"---SCORE_JSON---\n{score_json}\n---SCORE_STDERR---\nsome warning\n"
        mock_run.return_value = MagicMock(
            stdout=stdout, stderr="", returncode=0,
        )
        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)

            result = runner.run_score(
                "img:latest",
                {"task_slug": "test_task"},
                student_code="code",
                data_dir=data_dir,
                shared_dir=shared_dir,
            )
        assert result["score"] == 0.85
        assert result["task"] == "test_task"
        assert result["scoring_metadata"]["checks_passed"] == 5

    @patch("subprocess.run")
    def test_captures_stderr_in_metadata(self, mock_run):
        score_json = json.dumps({"score": 0.0, "metadata": {}})
        stdout = f"---SCORE_JSON---\n{score_json}\n---SCORE_STDERR---\nTraceback: error here\n"
        mock_run.return_value = MagicMock(
            stdout=stdout, stderr="", returncode=0,
        )
        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)

            result = runner.run_score(
                "img:latest",
                {"task_slug": "t"},
                data_dir=data_dir,
                shared_dir=shared_dir,
            )
        assert "Traceback" in result["scoring_metadata"].get("compilation_errors", "")

    @patch("subprocess.run")
    def test_handles_malformed_json(self, mock_run):
        mock_run.return_value = MagicMock(
            stdout="---SCORE_JSON---\n{bad json\n---SCORE_STDERR---\n",
            stderr="", returncode=0,
        )
        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)

            result = runner.run_score(
                "img:latest",
                {"task_slug": "t"},
                data_dir=data_dir,
                shared_dir=shared_dir,
            )
        assert result["score"] == 0.0
        assert "error" in result["scoring_metadata"].get("error", "").lower() or \
               "Parse error" in result["scoring_metadata"].get("error", "")

    @patch("subprocess.run")
    def test_collects_student_files(self, mock_run):
        score_json = json.dumps({"score": 1.0, "metadata": {}})
        stdout = f"---SCORE_JSON---\n{score_json}\n---SCORE_STDERR---\n"
        mock_run.return_value = MagicMock(
            stdout=stdout, stderr="", returncode=0,
        )
        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)
            with open(os.path.join(data_dir, "sol.py"), "w") as f:
                f.write("print(1)")

            result = runner.run_score(
                "img:latest",
                {"task_slug": "t"},
                data_dir=data_dir,
                shared_dir=shared_dir,
            )
        assert "data/sol.py" in result["student_files"]
        assert result["student_files"]["data/sol.py"] == "print(1)"

    @patch("subprocess.run")
    def test_creates_temp_dir_when_data_dir_none(self, mock_run):
        score_json = json.dumps({"score": 0.5, "metadata": {}})
        stdout = f"---SCORE_JSON---\n{score_json}\n---SCORE_STDERR---\n"
        mock_run.return_value = MagicMock(
            stdout=stdout, stderr="", returncode=0,
        )
        runner = _make_runner()
        result = runner.run_score(
            "img:latest",
            {"task_slug": "t", "stub_filename": "sol.py"},
            student_code="x = 1",
        )
        assert result["score"] == 0.5
        assert result["task"] == "t"


# ---------------------------------------------------------------------------
# 8. run_score lean diagnostics
# ---------------------------------------------------------------------------

class TestRunScoreLeanDiagnostics:
    """run_score runs lean diagnostics when compilation fails."""

    @patch("subprocess.run")
    def test_lean_errors_captured(self, mock_run):
        score_json = json.dumps({
            "score": 0.0,
            "metadata": {
                "full_compilation": False,
                "lean_file": "/workdir/data/proof.lean",
            },
        })
        stdout = f"---SCORE_JSON---\n{score_json}\n---SCORE_STDERR---\n"

        call_count = {"n": 0}

        def side_effect(*args, **kwargs):
            call_count["n"] += 1
            # First call is the scoring run, second is the diagnostic run
            if call_count["n"] == 1:
                return MagicMock(stdout=stdout, stderr="", returncode=0)
            return MagicMock(
                stdout="error: unknown identifier 'Real'\n",
                stderr="", returncode=1,
            )

        mock_run.side_effect = side_effect

        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)
            # The lean file must exist on disk for diagnostics to run
            with open(os.path.join(data_dir, "proof.lean"), "w") as f:
                f.write("-- lean stub")

            result = runner.run_score(
                "img:latest",
                {"task_slug": "lean_task"},
                data_dir=data_dir,
                shared_dir=shared_dir,
            )
        assert "lean_errors" in result["scoring_metadata"]
        assert "unknown identifier" in result["scoring_metadata"]["lean_errors"]

    @patch("subprocess.run")
    def test_lean_diag_skipped_when_compilation_ok(self, mock_run):
        score_json = json.dumps({
            "score": 0.9,
            "metadata": {
                "full_compilation": True,
                "lean_file": "/workdir/data/proof.lean",
            },
        })
        stdout = f"---SCORE_JSON---\n{score_json}\n---SCORE_STDERR---\n"
        mock_run.return_value = MagicMock(stdout=stdout, stderr="", returncode=0)

        runner = _make_runner()
        with tempfile.TemporaryDirectory() as tmpdir:
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)
            with open(os.path.join(data_dir, "proof.lean"), "w") as f:
                f.write("-- ok")

            result = runner.run_score(
                "img:latest",
                {"task_slug": "t"},
                data_dir=data_dir,
                shared_dir=shared_dir,
            )
        # Only one subprocess call (scoring), no diagnostic
        assert mock_run.call_count == 1
        assert "lean_errors" not in result["scoring_metadata"]


# ---------------------------------------------------------------------------
# 9. SOLVE_TOOLS schema
# ---------------------------------------------------------------------------

class TestSolveToolsSchema:
    """SOLVE_TOOLS has the correct structure for Anthropic tool_use format."""

    def test_three_tools(self):
        assert len(Runner.SOLVE_TOOLS) == 3

    def test_tool_names(self):
        names = {t["name"] for t in Runner.SOLVE_TOOLS}
        assert names == {"read_file", "write_file", "bash"}

    def test_all_have_description(self):
        for tool in Runner.SOLVE_TOOLS:
            assert "description" in tool
            assert isinstance(tool["description"], str)
            assert len(tool["description"]) > 0

    def test_all_have_input_schema(self):
        for tool in Runner.SOLVE_TOOLS:
            schema = tool["input_schema"]
            assert schema["type"] == "object"
            assert "properties" in schema
            assert "required" in schema
            assert isinstance(schema["required"], list)

    def test_read_file_requires_path(self):
        read = [t for t in Runner.SOLVE_TOOLS if t["name"] == "read_file"][0]
        assert "path" in read["input_schema"]["required"]

    def test_write_file_requires_path_and_content(self):
        write = [t for t in Runner.SOLVE_TOOLS if t["name"] == "write_file"][0]
        assert "path" in write["input_schema"]["required"]
        assert "content" in write["input_schema"]["required"]

    def test_bash_requires_command(self):
        bash = [t for t in Runner.SOLVE_TOOLS if t["name"] == "bash"][0]
        assert "command" in bash["input_schema"]["required"]


# ---------------------------------------------------------------------------
# 10. score_history tracking
# ---------------------------------------------------------------------------

class TestScoreHistoryTracking:
    """Verify score_history structure in run_solve output."""

    @patch("subprocess.run")
    @patch.object(Runner, "_call_anthropic")
    def test_score_history_structure(self, mock_anthropic, mock_subprocess):
        """After one solve turn, score_history has the expected fields."""
        # First call: model returns text (no tool use) -> triggers scoring
        mock_anthropic.return_value = {
            "stop_reason": "end_turn",
            "content": [{"type": "text", "text": "Done."}],
        }

        score_json = json.dumps({"score": 0.65, "metadata": {"sorry_count": 2, "full_compilation": True}})
        stdout = f"---SCORE_JSON---\n{score_json}\n---SCORE_STDERR---\n"
        mock_subprocess.return_value = MagicMock(
            stdout=stdout, stderr="", returncode=0,
        )

        runner = _make_runner()
        result = runner.run_solve(
            image="img:latest",
            task_config={"task_slug": "t", "stub_code": "# stub", "stub_filename": "sol.py"},
            model="claude-sonnet-4-20250514",
            api_key="sk-test",
            max_turns=1,
        )

        assert "score_history" in result
        history = result["score_history"]
        assert len(history) == 1

        entry = history[0]
        assert entry["iteration"] == 1
        assert entry["turn"] == 1
        assert entry["score"] == 0.65
        assert "tool_calls" in entry
        assert "time" in entry
        assert entry["sorry_count"] == 2
        assert entry["compilation"] is True

    @patch("subprocess.run")
    @patch.object(Runner, "_call_anthropic")
    def test_score_history_accumulates(self, mock_anthropic, mock_subprocess):
        """Multiple scoring rounds produce multiple history entries."""
        # Turn 1: text -> score; Turn 2: text -> score (>= 0.95 -> stop)
        mock_anthropic.return_value = {
            "stop_reason": "end_turn",
            "content": [{"type": "text", "text": "attempt"}],
        }

        # run_solve calls subprocess.run for: (1) tar -cf (extract shared),
        # (2) tar -xf, then scoring calls. We track call index to return
        # appropriate mock for each.
        call_count = {"n": 0}
        scores = [0.3, 0.97]

        def subprocess_side_effect(*args, **kwargs):
            call_count["n"] += 1
            # Calls 1-2 are tar setup (return generic success)
            if call_count["n"] <= 2:
                return MagicMock(stdout="", stderr="", returncode=0)
            # Remaining calls are scoring runs
            score_idx = call_count["n"] - 3
            s = scores[min(score_idx, len(scores) - 1)]
            score_json = json.dumps({"score": s, "metadata": {}})
            stdout = f"---SCORE_JSON---\n{score_json}\n---SCORE_STDERR---\n"
            return MagicMock(stdout=stdout, stderr="", returncode=0)

        mock_subprocess.side_effect = subprocess_side_effect

        runner = _make_runner()
        result = runner.run_solve(
            image="img:latest",
            task_config={"task_slug": "t", "stub_code": "", "stub_filename": "sol.py"},
            model="m",
            api_key="sk-test",
            max_turns=5,
        )

        assert len(result["score_history"]) == 2
        assert result["score_history"][0]["score"] == 0.3
        assert result["score_history"][1]["score"] == 0.97
        assert result["score"] == 0.97
