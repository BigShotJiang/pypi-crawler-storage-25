"""Self-hosted runner — polls the Athanor platform for jobs and executes them locally.

Usage:
    athanor run --token <sync-token>
    athanor run --token <sync-token> --platform https://tahoe.athanor-ai.com

The runner:
1. Registers with the platform
2. Polls for jobs (score, solve, evaluate, build)
3. Pulls the scoring container from GHCR
4. Runs scoring locally with Docker
5. Reports results back to the platform

Requirements: Docker, Python 3.10+, outbound HTTPS
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Prevent urllib from following redirects (which drops the Authorization header)."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(newurl, code, msg, headers, fp)


class Runner:
    def __init__(self, token: str, platform_url: str = "https://tahoe.athanor-ai.com", name: str = "default"):
        self.token = token
        self.platform_url = platform_url.rstrip("/")
        self.name = name
        self.runner_id: str | None = None
        self.docker_bin = shutil.which("docker") or shutil.which("podman")
        if not self.docker_bin:
            raise RuntimeError("Docker or Podman is required. Install Docker and try again.")
        self._opener = urllib.request.build_opener(_NoRedirectHandler)

    def _request(self, method: str, path: str, data: dict | None = None) -> dict:
        url = f"{self.platform_url}{path}"
        body = json.dumps(data).encode() if data else None
        req = urllib.request.Request(
            url,
            data=body,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "User-Agent": "athanor-runner/0.2.0",
            },
            method=method,
        )
        try:
            resp = self._opener.open(req, timeout=35)
            return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = e.read().decode() if e.fp else ""
            if e.code == 401:
                raise RuntimeError("Authentication failed. Check your sync token (--token or ATHANOR_TOKEN).")
            if e.code == 403:
                if "1010" in body:
                    raise RuntimeError(
                        "Cloudflare blocked the request (error 1010). "
                        "The platform may need a CF Access bypass for this endpoint."
                    )
                raise RuntimeError("Access denied. Your token may not have permission for this operation.")
            if e.code == 404:
                raise RuntimeError(f"Not found: {path}. Check that the environment/task exists.")
            raise RuntimeError(f"API error {e.code}: {body[:200]}")
        except urllib.error.URLError as e:
            raise RuntimeError(f"Cannot reach platform at {self.platform_url}: {e.reason}")

    def register(self):
        """Register this runner with the platform."""
        result = self._request("POST", "/api/runner", {"name": self.name})
        self.runner_id = result.get("runner_id")
        print(f"Runner registered: {self.runner_id}")
        return self.runner_id

    def poll(self) -> dict | None:
        """Poll for the next job. Returns None if no jobs queued."""
        result = self._request("GET", f"/api/runner/poll?runner_id={self.runner_id}")
        return result.get("job")

    def report(self, job_id: str, result: dict | None = None, error: str | None = None):
        """Report job results back to the platform."""
        self._request("POST", "/api/runner/results", {
            "job_id": job_id,
            "status": "failed" if error else "completed",
            "result": result,
            "error": error,
        })

    def pull_image(self, image: str):
        """Pull a container image if not already present."""
        check = subprocess.run(
            [self.docker_bin, "image", "inspect", image],
            capture_output=True,
        )
        if check.returncode != 0:
            print(f"  Pulling {image}...")
            result = subprocess.run(
                [self.docker_bin, "pull", image],
                capture_output=True, text=True,
            )
            if result.returncode != 0:
                stderr = result.stderr.strip()[:300]
                if "not found" in stderr.lower() or "manifest unknown" in stderr.lower():
                    raise RuntimeError(
                        f"Container image not found: {image}\n"
                        f"Check that the environment exists at ghcr.io/athanor-ai/"
                    )
                raise RuntimeError(f"Failed to pull {image}: {stderr}")

    def run_score(self, image: str, task_config: dict, student_code: str | None = None,
                  data_dir: str | None = None, shared_dir: str | None = None) -> dict:
        """Run scoring in a container and return the result.

        If data_dir is provided, scores files in-place (used by run_solve).
        Otherwise creates a temp dir and optionally writes student_code.
        """
        cleanup = False
        if data_dir is None:
            tmpdir = tempfile.mkdtemp(prefix="athanor-score-")
            data_dir = os.path.join(tmpdir, "data")
            shared_dir = os.path.join(tmpdir, "shared")
            os.makedirs(data_dir)
            os.makedirs(shared_dir)
            cleanup = True

            # Write student code if provided
            stub_filename = task_config.get("stub_filename", "solution.py")
            if student_code:
                with open(os.path.join(data_dir, stub_filename), "w") as f:
                    f.write(student_code)

        if shared_dir is None:
            shared_dir = os.path.join(os.path.dirname(data_dir), "shared")
            os.makedirs(shared_dir, exist_ok=True)

        task_slug = task_config.get("task_slug", "unknown")
        config_path = f"/root_data/eval/configs/{task_slug}.json"

        result = subprocess.run(
            [
                self.docker_bin, "run", "--rm", "--user", "root",
                "--network=none", "--memory=4g", "--pids-limit=256",
                "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID",
                "-v", f"{data_dir}:/workdir/data",
                "-v", f"{shared_dir}:/workdir/shared:ro",
                image, "bash", "-c",
                # Run scoring, capture stderr for feedback, then output score JSON + errors
                f"/root/.venv/bin/python /root_data/eval/scoring.py "
                f"{config_path} /tmp/score.json 2>/tmp/score_err.txt; "
                f"echo '---SCORE_JSON---'; "
                f"cat /tmp/score.json 2>/dev/null || "
                f'echo \'{{"score": 0.0, "metadata": {{"error": "scoring crashed"}}}}\'; '
                f"echo '---SCORE_STDERR---'; "
                f"head -100 /tmp/score_err.txt 2>/dev/null",
            ],
            capture_output=True, text=True, timeout=300,
        )

        try:
            stdout = result.stdout.strip()
            # Split on markers to get score JSON and stderr separately
            score_json_str = stdout
            scoring_stderr = ""
            if "---SCORE_JSON---" in stdout:
                parts = stdout.split("---SCORE_JSON---", 1)
                rest = parts[1] if len(parts) > 1 else ""
                if "---SCORE_STDERR---" in rest:
                    json_part, stderr_part = rest.split("---SCORE_STDERR---", 1)
                    score_json_str = json_part.strip()
                    scoring_stderr = stderr_part.strip()[:3000]
                else:
                    score_json_str = rest.strip()

            json_start = score_json_str.find("{")
            if json_start >= 0:
                score_data = json.loads(score_json_str[json_start:])
            else:
                score_data = json.loads(score_json_str)
        except (json.JSONDecodeError, ValueError):
            score_data = {"score": 0.0, "metadata": {"error": f"Parse error: {result.stdout[:300]}"}}
            scoring_stderr = ""

        # Inject captured stderr (Lean errors, compilation errors) into metadata
        if scoring_stderr:
            meta = score_data.get("metadata", {})
            existing = meta.get("compilation_errors", "")
            if scoring_stderr not in str(existing):
                meta["compilation_errors"] = (str(existing) + "\n" + scoring_stderr).strip()
            score_data["metadata"] = meta

        # Post-score diagnostics: get actual compiler errors when compilation fails
        score_meta = score_data.get("metadata", {})
        if score_meta.get("full_compilation") is False or (score_meta.get("error") and score_data.get("score", 0) < 0.1):
            lean_file = score_meta.get("lean_file", "")
            if lean_file and lean_file.startswith("/workdir/data/"):
                fname = os.path.basename(lean_file)
                if os.path.exists(os.path.join(data_dir, fname)):
                    try:
                        diag = subprocess.run(
                            [self.docker_bin, "run", "--rm", "--user", "root",
                             "--network=none", "--memory=4g",
                             "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID",
                             "-v", f"{data_dir}:/workdir/data",
                             "-v", f"{shared_dir}:/workdir/shared:ro",
                             image, "bash", "-c",
                             f"cd /workdir && lean data/{fname} 2>&1 | grep -E 'error|Error|unknown' | head -20"],
                            capture_output=True, text=True, timeout=120,
                        )
                        if diag.stdout.strip():
                            score_meta["lean_errors"] = diag.stdout.strip()[:2000]
                            score_data["metadata"] = score_meta
                    except Exception:
                        pass

        # Read student files after scoring
        student_files = {}
        for f in os.listdir(data_dir):
            fpath = os.path.join(data_dir, f)
            if os.path.isfile(fpath) and os.path.getsize(fpath) < 50000:
                try:
                    student_files[f"data/{f}"] = open(fpath).read()
                except Exception:
                    pass

        if cleanup:
            import shutil as _shutil
            _shutil.rmtree(tmpdir, ignore_errors=True)

        return {
            "task": task_slug,
            "score": score_data.get("score", 0.0),
            "scoring_metadata": score_data.get("metadata", {}),
            "student_files": student_files,
            "tool_calls_total": 0,
            "time_seconds": 0,
        }

    # Tool definitions for the agent solve loop (Anthropic tool_use format)
    SOLVE_TOOLS = [
        {
            "name": "read_file",
            "description": "Read a file from the working directory. Paths are relative to /workdir/ (e.g. 'data/solution.py', 'shared/reference.txt').",
            "input_schema": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "File path relative to /workdir/"}},
                "required": ["path"],
            },
        },
        {
            "name": "write_file",
            "description": "Write content to a file in /workdir/data/. Only files in data/ can be written.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path relative to /workdir/data/ (e.g. 'solution.py')"},
                    "content": {"type": "string", "description": "Full file content to write"},
                },
                "required": ["path", "content"],
            },
        },
        {
            "name": "bash",
            "description": "Run a bash command inside the scoring container. Network is disabled. Timeout 30s.",
            "input_schema": {
                "type": "object",
                "properties": {"command": {"type": "string", "description": "Command to execute"}},
                "required": ["command"],
            },
        },
    ]

    def _call_anthropic(self, messages: list, api_key: str, model: str,
                        tools: list | None = None, api_base: str | None = None) -> dict:
        """Call the Anthropic Messages API and return the raw response."""
        base = api_base or os.environ.get("ANTHROPIC_BASE_URL") or "https://api.anthropic.com"
        base = base.rstrip("/")
        url = f"{base}/v1/messages"

        payload: dict = {
            "model": model,
            "max_tokens": 8192,
            "messages": messages,
        }
        if tools:
            payload["tools"] = tools

        body = json.dumps(payload).encode()
        req = urllib.request.Request(
            url, data=body,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
                "User-Agent": "athanor-runner/0.2.0",
            },
        )
        resp = urllib.request.urlopen(req, timeout=180)
        return json.loads(resp.read())

    def _exec_tool(self, name: str, args: dict, data_dir: str, shared_dir: str, image: str) -> str:
        """Execute a tool call and return the result string."""
        if name == "read_file":
            path = args.get("path", "")
            # Resolve to data/ or shared/
            if path.startswith("data/"):
                full = os.path.join(os.path.dirname(data_dir), path)
            elif path.startswith("shared/"):
                full = os.path.join(os.path.dirname(data_dir), path)
            else:
                full = os.path.join(data_dir, path)
            if not os.path.isfile(full):
                return f"Error: file not found: {path}"
            try:
                content = open(full).read()
                return content[:30000]
            except Exception as e:
                return f"Error reading file: {e}"

        elif name == "write_file":
            path = args.get("path", "")
            content = args.get("content", "")
            # Only write to data/
            full = os.path.join(data_dir, os.path.basename(path))
            with open(full, "w") as f:
                f.write(content)
            return f"Written {len(content)} chars to data/{os.path.basename(path)}"

        elif name == "bash":
            cmd = args.get("command", "")
            try:
                result = subprocess.run(
                    [
                        self.docker_bin, "run", "--rm", "--user", "root",
                        "--network=none", "--memory=4g", "--pids-limit=256",
                        "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID",
                        "-v", f"{data_dir}:/workdir/data",
                        "-v", f"{shared_dir}:/workdir/shared:ro",
                        image, "bash", "-c", cmd,
                    ],
                    capture_output=True, text=True, timeout=30,
                )
                output = result.stdout[:5000]
                if result.stderr:
                    output += f"\nSTDERR:\n{result.stderr[:2000]}"
                if result.returncode != 0:
                    output += f"\n(exit code {result.returncode})"
                return output or "(no output)"
            except subprocess.TimeoutExpired:
                return "Error: command timed out (30s)"
            except Exception as e:
                return f"Error: {e}"

        return f"Unknown tool: {name}"

    def run_solve(self, image: str, task_config: dict, model: str = "claude-opus-4-6",
                   api_key: str | None = None, max_turns: int = 30) -> dict:
        """Run a full agent solve loop with tool use: read/write files, bash, score, retry."""
        api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            return {"error": "ANTHROPIC_API_KEY required for solve"}

        task_slug = task_config.get("task_slug", "unknown")
        stub_code = task_config.get("stub_code", "")
        stub_filename = task_config.get("stub_filename", "solution.py")
        description = task_config.get("task_description", "")

        print(f"  Solving {task_slug} with {model}...")

        # Set up workdir
        tmpdir = tempfile.mkdtemp(prefix="athanor-solve-")
        data_dir = os.path.join(tmpdir, "data")
        shared_dir = os.path.join(tmpdir, "shared")
        os.makedirs(data_dir)
        os.makedirs(shared_dir)

        # Write stub file(s)
        student_path = os.path.join(data_dir, stub_filename)
        with open(student_path, "w") as f:
            f.write(stub_code)

        # Write additional stub files if present (multi-file tasks)
        extra_files = task_config.get("extra_files", {})
        for fname, content in extra_files.items():
            with open(os.path.join(data_dir, fname), "w") as f:
                f.write(content)

        # Copy shared data from container
        subprocess.run(
            [self.docker_bin, "run", "--rm", image, "tar", "-cf", "-", "-C", "/workdir/shared", "."],
            stdout=open(os.path.join(tmpdir, "shared.tar"), "wb"),
            timeout=30,
        )
        subprocess.run(["tar", "-xf", os.path.join(tmpdir, "shared.tar"), "-C", shared_dir], timeout=10)

        # List available files for context
        data_files = os.listdir(data_dir)
        shared_files = []
        try:
            shared_files = os.listdir(shared_dir)
        except OSError:
            pass

        # Build system prompt
        system = (
            "You are solving a coding task. Use the provided tools to read files, write solutions, "
            "and run commands.\n\n"
            f"Task: {description}\n\n"
            f"Files in data/ (editable): {', '.join(data_files)}\n"
            f"Files in shared/ (read-only): {', '.join(shared_files[:20])}\n\n"
            f"Primary file to edit: data/{stub_filename}\n"
            "Write your solution using write_file, then I will score it automatically."
        )

        messages: list[dict] = [
            {"role": "user", "content": (
                f"Solve this task by editing the file(s) in data/.\n\n"
                f"--- data/{stub_filename} ---\n{stub_code}\n\n"
                "Start by reading any shared/ reference files you need, then write your solution."
            )},
        ]

        best_score = 0.0
        best_files: dict[str, str] = {}
        tool_call_count = 0
        score_result: dict = {}
        score_history: list[dict] = []
        start_time = time.time()

        for turn in range(max_turns):
            # Call LLM
            try:
                resp = self._call_anthropic(
                    messages, api_key, model,
                    tools=self.SOLVE_TOOLS,
                )
            except Exception as e:
                print(f"    Turn {turn + 1}: API error: {e}")
                break

            stop_reason = resp.get("stop_reason", "end_turn")
            content_blocks = resp.get("content", [])

            # Build assistant message for conversation history
            assistant_content = []
            for block in content_blocks:
                if block.get("type") == "text":
                    assistant_content.append({"type": "text", "text": block["text"]})
                elif block.get("type") == "tool_use":
                    assistant_content.append(block)

            messages.append({"role": "assistant", "content": assistant_content})

            # Process tool calls
            tool_results = []
            has_tool_use = False
            for block in content_blocks:
                if block.get("type") != "tool_use":
                    continue
                has_tool_use = True
                tool_call_count += 1
                tool_name = block["name"]
                tool_args = block.get("input", {})
                result_text = self._exec_tool(tool_name, tool_args, data_dir, shared_dir, image)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block["id"],
                    "content": result_text[:10000],
                })

            if tool_results:
                messages.append({"role": "user", "content": tool_results})
                continue  # Let the model keep using tools

            # No tool calls — model is done with this attempt. Score it.
            score_result = self.run_score(image, task_config, data_dir=data_dir, shared_dir=shared_dir)
            score = score_result.get("score", 0.0)
            meta = score_result.get("scoring_metadata", {})
            print(f"    Turn {turn + 1}: score={score:.3f} (tools={tool_call_count})")

            score_history.append({
                "iteration": len(score_history) + 1,
                "turn": turn + 1,
                "score": score,
                "tool_calls": tool_call_count,
                "time": round(time.time() - start_time, 1),
                "sorry_count": meta.get("sorry_count"),
                "compilation": meta.get("full_compilation"),
            })

            if score > best_score:
                best_score = score
                best_files = {}
                for f in os.listdir(data_dir):
                    fpath = os.path.join(data_dir, f)
                    if os.path.isfile(fpath) and os.path.getsize(fpath) < 50000:
                        try:
                            best_files[f"data/{f}"] = open(fpath).read()
                        except Exception:
                            pass

            if score >= 0.95:
                print(f"  Solved! Score: {score:.3f}")
                break

            # Build detailed retry feedback — give the agent everything it needs
            feedback_parts = [f"Score: {score:.3f} (previous best: {best_score:.3f})."]

            # Error summary
            if meta.get("error"):
                feedback_parts.append(f"Error: {meta['error']}")

            # Property test results (integer counts or fraction-based)
            if meta.get("checks_passed") is not None:
                total = meta.get("checks_total", "?")
                feedback_parts.append(f"Property checks: {meta['checks_passed']}/{total} passed.")
            elif meta.get("checks_passed_fraction") is not None:
                frac = meta["checks_passed_fraction"]
                total = meta.get("total_checks", "?")
                feedback_parts.append(f"Property checks: {frac:.0%} passed ({total} total).")

            # Property gate (neuroscience-style)
            if meta.get("property_gate") is False:
                feedback_parts.append(f"Property gate FAILED: {meta.get('gate_reason', 'unknown')}")

            # Failed check details — extract from check_details if no failed_checks list
            if meta.get("failed_checks"):
                failed = meta["failed_checks"]
                if isinstance(failed, list):
                    feedback_parts.append(f"Failed checks: {', '.join(str(f) for f in failed[:10])}")
            elif meta.get("check_details"):
                details = meta["check_details"]
                if isinstance(details, list):
                    failed = [d for d in details if d.get("status") in ("fail", "missing")]
                    if failed:
                        summary = []
                        for d in failed[:8]:
                            key = d.get("key", "?")
                            if "student" in d and "expected" in d:
                                summary.append(f"{key}: got {d['student']}, expected {d['expected']}")
                            elif "fraction_correct" in d:
                                summary.append(f"{key}: {d['fraction_correct']:.0%} correct")
                            elif "reason" in d:
                                summary.append(f"{key}: {d['reason']}")
                            else:
                                summary.append(f"{key}: {d.get('status', 'fail')}")
                        feedback_parts.append(f"Failed checks:\n  " + "\n  ".join(summary))

            # Property tests array (neuroscience-style detailed)
            if meta.get("property_tests"):
                tests = meta["property_tests"]
                if isinstance(tests, list):
                    failed_tests = [t for t in tests if t.get("status") != "pass"]
                    if failed_tests:
                        test_msgs = []
                        for t in failed_tests[:5]:
                            msg = f"{t.get('type', '?')}/{t.get('key', '?')}: {t.get('status', 'fail')}"
                            if t.get("reason"):
                                msg += f" — {t['reason']}"
                            if t.get("rel_err") is not None:
                                msg += f" (rel_err={t['rel_err']:.4f})"
                            test_msgs.append(msg)
                        feedback_parts.append(f"Property test failures:\n  " + "\n  ".join(test_msgs))

            # Lean-specific feedback
            if meta.get("sorry_count") is not None:
                feedback_parts.append(f"Sorry count: {meta['sorry_count']}/{meta.get('sorry_denominator', '?')}")
            if meta.get("full_compilation") is False:
                feedback_parts.append("Lean compilation FAILED.")
            if meta.get("completeness") is not None:
                feedback_parts.append(f"Completeness: {meta['completeness']:.0%}")
            if meta.get("signatures_matched") is not None:
                feedback_parts.append(
                    f"Signatures matched: {meta['signatures_matched']}/{meta.get('signatures_total', '?')}")
            # Lean proof status (neuroscience/NKI-style)
            if meta.get("lean_status"):
                feedback_parts.append(f"Lean proof: {meta['lean_status']}")
                if meta.get("lean_error"):
                    feedback_parts.append(f"Lean error: {meta['lean_error'][:500]}")
            # Actual Lean compiler errors (from diagnostic step)
            if meta.get("lean_errors"):
                feedback_parts.append(f"Lean compiler output:\n{meta['lean_errors'][:1500]}")

            # Numerical results (NKI-style: max_error, mean_error, correctness)
            if meta.get("max_error") is not None:
                feedback_parts.append(f"Max error: {meta['max_error']:.6f} (tolerance: {meta.get('tolerance', '?')})")
            if meta.get("mean_error") is not None:
                feedback_parts.append(f"Mean error: {meta['mean_error']:.6f}")
            if meta.get("mse") is not None:
                feedback_parts.append(f"MSE: {meta['mse']:.6f}")
            if meta.get("relative_error") is not None:
                feedback_parts.append(f"Relative error: {meta['relative_error']:.6f}")
            if meta.get("correctness") is not None:
                feedback_parts.append(f"Correctness: {meta['correctness']:.3f}")

            # Compilation / stderr errors (Lean errors, Python tracebacks, etc.)
            if meta.get("compilation_errors"):
                errors = str(meta["compilation_errors"])
                # Filter noise, keep actionable errors
                error_lines = [l for l in errors.split("\n")
                               if l.strip() and "warning: failed to query" not in l]
                if error_lines:
                    feedback_parts.append(f"Errors:\n{chr(10).join(error_lines[:30])}")

            feedback = "\n".join(feedback_parts)
            messages.append({"role": "user", "content": (
                f"{feedback}\n\nFix the issues above and try again. Use the tools to read error "
                "messages, edit your code, and test."
            )})

        elapsed = time.time() - start_time

        # Collect final student files
        student_files = best_files or {}
        if not student_files:
            for f in os.listdir(data_dir):
                fpath = os.path.join(data_dir, f)
                if os.path.isfile(fpath) and os.path.getsize(fpath) < 50000:
                    try:
                        student_files[f"data/{f}"] = open(fpath).read()
                    except Exception:
                        pass

        # Clean up
        import shutil as _shutil
        _shutil.rmtree(tmpdir, ignore_errors=True)

        return {
            "task": task_slug,
            "score": best_score,
            "scoring_metadata": score_result.get("scoring_metadata", {}),
            "student_files": student_files,
            "tool_calls_total": tool_call_count,
            "time_seconds": round(elapsed, 1),
            "score_history": score_history,
        }

    def run_build(self, image: str, config: dict, api_key: str) -> dict:
        """Generate a task using Opus 4.6 and validate scoring works."""
        task_name = config.get("task_name", "unnamed_task")
        description = config.get("description", "")
        difficulty = config.get("difficulty", "medium")
        category = config.get("category", "implementation")
        proof_backend = config.get("proof_backend", "none")
        scoring_type = config.get("scoring_type", "property_tests")
        env_slug = config.get("environment", "")

        print(f"  Building task: {task_name}")

        prompt = (
            f'Generate a verified training task for the "{env_slug}" environment.\n\n'
            f"Task name: {task_name}\n"
            f"Description: {description}\n"
            f"Difficulty: {difficulty}\n"
            f"Category: {category}\n"
            f"Proof backend: {proof_backend}\n"
            f"Scoring: {scoring_type}\n\n"
            "Generate:\n"
            "1. A student stub file (the starting code the agent edits)\n"
            "2. A scoring configuration (sigmoid_center, sigmoid_scale, checks)\n"
            "3. A proof template if proof_backend is not 'none'\n\n"
            "Output as JSON with keys: stub_code, scoring_config, proof_template (or null), "
            "description, task_id, stub_filename"
        )

        try:
            resp = self._call_anthropic(
                [{"role": "user", "content": prompt}],
                api_key, "claude-opus-4-6",
            )
            text = resp.get("content", [{}])[0].get("text", "")

            # Parse JSON from response
            import re as _re
            json_match = _re.search(r'\{[\s\S]*\}', text)
            if not json_match:
                return {"error": "Could not parse JSON from Opus response", "raw": text[:2000]}

            task_data = json.loads(json_match.group())
            task_id = task_data.get("task_id", task_name)
            stub_code = task_data.get("stub_code", "")
            stub_filename = task_data.get("stub_filename", f"{task_name}.py")

            # Validate: score stub (should be near-zero) and reference (should be high)
            validation = {"stub_score": None, "reference_score": None}
            task_cfg = {"task_slug": task_id, "stub_filename": stub_filename}
            if stub_code:
                stub_result = self.run_score(image, task_cfg, student_code=stub_code)
                validation["stub_score"] = stub_result.get("score", 0.0)
                validation["stub_metadata"] = stub_result.get("scoring_metadata", {})

            # If Opus generated a reference solution, score that too
            ref_code = task_data.get("reference_solution") or task_data.get("solution")
            if ref_code:
                ref_result = self.run_score(image, task_cfg, student_code=ref_code)
                validation["reference_score"] = ref_result.get("score", 0.0)
                validation["reference_metadata"] = ref_result.get("scoring_metadata", {})

            task_data["validation"] = validation
            # Task is valid if stub scores low and reference scores high (if provided)
            is_valid = validation["stub_score"] is not None
            if validation["reference_score"] is not None:
                is_valid = is_valid and validation["reference_score"] > validation["stub_score"]

            return {
                "task_id": task_id,
                "task_name": task_name,
                "generated": task_data,
                "status": "validated" if is_valid else "generated",
                "validation": validation,
            }

        except Exception as e:
            return {"error": f"Build failed: {e}"}

    def execute_job(self, job: dict) -> dict:
        """Execute a job and return the result."""
        job_type = job["type"]
        image = job["image"]
        config = job.get("config", {})

        print(f"  Job {job['id'][:8]}: {job_type} on {job['environment']}")

        self.pull_image(image)

        if job_type == "score":
            student_code = config.get("student_code")
            result = self.run_score(image, config, student_code)
            print(f"  Score: {result['score']:.3f}")
            return result

        elif job_type == "solve":
            model = config.get("model", "claude-opus-4-6")
            api_key = config.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
            max_turns = config.get("max_turns", 30)
            result = self.run_solve(image, config, model=model, api_key=api_key, max_turns=max_turns)
            print(f"  Score: {result.get('score', 0):.3f} ({result.get('tool_calls_total', 0)} turns)")
            return result

        elif job_type == "evaluate":
            # TODO: run evaluate.py --all-tasks
            return {"error": "evaluate not yet implemented in runner"}

        elif job_type == "build":
            api_key = config.get("api_key") or os.environ.get("ANTHROPIC_API_KEY")
            if not api_key:
                return {"error": "ANTHROPIC_API_KEY required for build jobs"}
            result = self.run_build(image, config, api_key=api_key)
            print(f"  Build: {result.get('task_id', 'unknown')}")
            return result

        return {"error": f"Unknown job type: {job_type}"}

    def run_forever(self):
        """Main loop — poll for jobs and execute them."""
        if not self.runner_id:
            self.register()

        print(f"Runner '{self.name}' ready. Polling {self.platform_url}...")
        print(f"Docker: {self.docker_bin}")
        print()

        consecutive_empty = 0
        while True:
            try:
                job = self.poll()
                if job:
                    consecutive_empty = 0
                    try:
                        result = self.execute_job(job)
                        self.report(job["id"], result=result)
                    except Exception as e:
                        print(f"  Job failed: {e}")
                        self.report(job["id"], error=str(e))
                else:
                    consecutive_empty += 1
                    # Back off: 2s → 5s → 10s
                    delay = min(2 * consecutive_empty, 10)
                    time.sleep(delay)

            except KeyboardInterrupt:
                print("\nShutting down...")
                break
            except Exception as e:
                print(f"Poll error: {e}")
                time.sleep(10)
