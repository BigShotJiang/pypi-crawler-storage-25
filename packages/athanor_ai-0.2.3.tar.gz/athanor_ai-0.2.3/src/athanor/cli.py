"""Athanor CLI — the platform in your terminal.

Usage:
    athanor run --token <token>                     # Start runner
    athanor score --task <slug> --file solution.py  # Score a file
    athanor solve --env <env> --task <slug>         # Solve a task with a model
    athanor evaluate --env <env>                    # Batch evaluate all tasks
    athanor pull --env <env>                        # Download environment tarball
    athanor runs --env <env>                        # List recent evaluation runs
    athanor proofs --env <env>                      # List verified proofs
    athanor config --set KEY=VALUE                  # Set config
"""

import argparse
import json
import os
import sys


def cmd_run(args):
    """Start the runner."""
    from athanor.runner import Runner

    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)

    runner = Runner(
        token=token,
        platform_url=args.platform,
        name=args.name,
    )
    runner.run_forever()


def cmd_score(args):
    """Score a file against a task."""
    from athanor.runner import Runner

    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)

    if not args.file or not os.path.exists(args.file):
        print(f"Error: file not found: {args.file}")
        sys.exit(1)

    student_code = open(args.file).read()

    runner = Runner(token=token, platform_url=args.platform)
    image = f"ghcr.io/athanor-ai/{args.env}:latest"
    runner.pull_image(image)

    result = runner.run_score(
        image=image,
        task_config={"task_slug": args.task, "stub_filename": os.path.basename(args.file)},
        student_code=student_code,
    )

    print(json.dumps(result, indent=2))


def cmd_solve(args):
    """Solve a task with a model — full agent loop with retry."""
    from athanor.runner import Runner

    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)
    if not api_key:
        print("Error: ANTHROPIC_API_KEY env var required for solve")
        sys.exit(1)

    runner = Runner(token=token, platform_url=args.platform)
    image = f"ghcr.io/athanor-ai/{args.env}:latest"
    runner.pull_image(image)

    # Fetch task info from platform
    print(f"Solving {args.task} on {args.env} with {args.model}...")
    try:
        task_info = runner._request("GET", f"/api/tasks?slug={args.task}&env={args.env}")
        if isinstance(task_info, list) and task_info:
            task_data = task_info[0]
        elif isinstance(task_info, dict) and task_info.get("data"):
            task_data = task_info["data"][0]
        else:
            task_data = {}
    except Exception:
        task_data = {}

    task_config = {
        "task_slug": args.task,
        "task_description": task_data.get("description", args.task),
        "stub_code": (task_data.get("metadata") or {}).get("stub_code", ""),
        "stub_filename": (task_data.get("metadata") or {}).get("stub_filename", f"{args.task}.py"),
    }

    if not task_config["stub_code"]:
        # Try extracting from container
        import subprocess
        result = subprocess.run(
            [runner.docker_bin, "run", "--rm", image, "cat", f"/workdir/data/{task_config['stub_filename']}"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0:
            task_config["stub_code"] = result.stdout

    result = runner.run_solve(image, task_config, model=args.model, api_key=api_key)
    print(f"\nFinal score: {result.get('score', 0):.3f}")
    print(f"Turns: {result.get('tool_calls_total', 0)}")
    print(f"Time: {result.get('time_seconds', 0):.1f}s")

    # Save results
    output = args.output or f"{args.task}_solve.json"
    json.dump(result, open(output, "w"), indent=2)
    print(f"Saved: {output}")


def cmd_build(args):
    """Build a task using Opus 4.6."""
    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    api_key = args.api_key or os.environ.get("ANTHROPIC_API_KEY")

    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)
    if not api_key:
        print("Error: --api-key required or set ANTHROPIC_API_KEY env var")
        print("Task Builder uses YOUR Opus 4.6 API key.")
        sys.exit(1)

    print(f"Building task: {args.name}")
    print(f"  Environment: {args.env}")
    print(f"  Difficulty: {args.difficulty}")
    print(f"  Proof backend: {args.proof_backend}")
    print(f"  Description: {args.description[:100]}...")
    print()

    # Call Opus to generate the task
    try:
        import urllib.request
        prompt = f"""Generate a verified training task for the "{args.env}" environment.

Task name: {args.name}
Description: {args.description}
Difficulty: {args.difficulty}
Category: {args.category}
Proof backend: {args.proof_backend}
Scoring: {args.scoring}

Generate:
1. A student stub file (the starting code the agent edits)
2. A scoring configuration (sigmoid_center, sigmoid_scale, checks)
3. A proof template if proof_backend is not "none"

Output as JSON with keys: stub_code, scoring_config, proof_template (or null), description, task_id
"""
        payload = json.dumps({
            "model": "claude-opus-4-6",
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": prompt}],
        }).encode()

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
        )
        resp = json.loads(urllib.request.urlopen(req, timeout=120).read())
        content = resp.get("content", [{}])[0].get("text", "")
        print("=== Opus 4.6 Output ===")
        print(content[:2000])

        # Try to parse JSON from the response
        try:
            # Find JSON block in response
            import re
            json_match = re.search(r'\{[\s\S]*\}', content)
            if json_match:
                task_data = json.loads(json_match.group())
                print(f"\nTask generated: {task_data.get('task_id', args.name)}")
                print(f"Stub code: {len(task_data.get('stub_code', ''))} chars")
                print(f"Proof template: {'Yes' if task_data.get('proof_template') else 'No'}")

                # Save to files
                out_dir = args.output or "."
                os.makedirs(out_dir, exist_ok=True)
                if task_data.get("stub_code"):
                    stub_file = os.path.join(out_dir, f"{args.name}.py")
                    open(stub_file, "w").write(task_data["stub_code"])
                    print(f"Saved: {stub_file}")
                if task_data.get("scoring_config"):
                    cfg_file = os.path.join(out_dir, f"{args.name}.json")
                    json.dump(task_data["scoring_config"], open(cfg_file, "w"), indent=2)
                    print(f"Saved: {cfg_file}")
                if task_data.get("proof_template"):
                    ext = ".lean" if args.proof_backend == "lean4" else ".dfy" if args.proof_backend == "dafny" else ".proof"
                    proof_file = os.path.join(out_dir, f"{args.name}{ext}")
                    open(proof_file, "w").write(task_data["proof_template"])
                    print(f"Saved: {proof_file}")
        except (json.JSONDecodeError, ValueError):
            print("\nCould not parse structured output — review the raw text above.")

    except Exception as e:
        print(f"Error calling Opus: {e}")
        sys.exit(1)


def cmd_evaluate(args):
    """Batch evaluate all tasks in an environment."""
    from athanor.runner import Runner

    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)
    if not api_key:
        print("Error: ANTHROPIC_API_KEY env var required for evaluate")
        sys.exit(1)

    import subprocess
    import time

    runner = Runner(token=token, platform_url=args.platform)
    image = f"ghcr.io/athanor-ai/{args.env}:latest"
    runner.pull_image(image)

    # List all task configs from the container
    print(f"Discovering tasks in {args.env}...")
    ls_result = subprocess.run(
        [runner.docker_bin, "run", "--rm", image, "ls", "/root_data/eval/configs/"],
        capture_output=True, text=True, timeout=30,
    )
    if ls_result.returncode != 0:
        print(f"Error listing configs: {ls_result.stderr}")
        sys.exit(1)

    config_files = [f for f in ls_result.stdout.strip().split("\n") if f.endswith(".json")]
    if not config_files:
        print("No task configs found in container.")
        sys.exit(1)

    task_slugs = [f.replace(".json", "") for f in config_files]
    print(f"Found {len(task_slugs)} tasks: {', '.join(task_slugs)}\n")

    results = []
    for i, task_slug in enumerate(task_slugs, 1):
        print(f"[{i}/{len(task_slugs)}] {task_slug}")

        # Extract stub from container
        stub_filename = f"{task_slug}.py"
        stub_result = subprocess.run(
            [runner.docker_bin, "run", "--rm", image, "cat", f"/workdir/data/{stub_filename}"],
            capture_output=True, text=True, timeout=15,
        )
        stub_code = stub_result.stdout if stub_result.returncode == 0 else ""

        task_config = {
            "task_slug": task_slug,
            "task_description": task_slug,
            "stub_code": stub_code,
            "stub_filename": stub_filename,
        }

        try:
            result = runner.run_solve(image, task_config, model=args.model, api_key=api_key)
            results.append(result)
            print(f"  -> score={result.get('score', 0):.3f}  time={result.get('time_seconds', 0):.1f}s  turns={result.get('tool_calls_total', 0)}")
        except Exception as e:
            print(f"  -> FAILED: {e}")
            results.append({
                "task": task_slug,
                "score": 0.0,
                "scoring_metadata": {"error": str(e)},
                "student_files": {},
                "tool_calls_total": 0,
                "time_seconds": 0,
            })

    # Compute summary
    scores = [r.get("score", 0.0) for r in results]
    mean_score = sum(scores) / len(scores) if scores else 0.0

    output_data = {
        "model": args.model,
        "environment": args.env,
        "results": results,
        "mean_score": round(mean_score, 4),
        "completed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }

    output_path = args.output or f"{args.env}_evaluate.json"
    with open(output_path, "w") as f:
        json.dump(output_data, f, indent=2)

    # Print summary table
    print(f"\n{'=' * 60}")
    print(f"  Environment: {args.env}")
    print(f"  Model:       {args.model}")
    print(f"  Tasks:       {len(results)}")
    print(f"{'=' * 60}")
    print(f"  {'Task':<30} {'Score':>8} {'Time':>8} {'Turns':>6}")
    print(f"  {'-' * 30} {'-' * 8} {'-' * 8} {'-' * 6}")
    for r in results:
        print(f"  {r['task']:<30} {r.get('score', 0):.3f}    {r.get('time_seconds', 0):>6.1f}s {r.get('tool_calls_total', 0):>5}")
    print(f"  {'-' * 30} {'-' * 8} {'-' * 8} {'-' * 6}")
    print(f"  {'MEAN':<30} {mean_score:.3f}")
    print(f"{'=' * 60}")
    print(f"\nSaved: {output_path}")


def cmd_pull(args):
    """Download an environment tarball from the platform."""
    import urllib.request

    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)

    platform = args.platform.rstrip("/")
    url = f"{platform}/api/download/{args.env}"
    output_path = args.output or f"{args.env}.tar.gz"

    print(f"Downloading {args.env} from {platform}...")

    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "User-Agent": "athanor-cli/0.2.0",
        },
    )

    try:
        resp = urllib.request.urlopen(req, timeout=120)
        data = resp.read()
        with open(output_path, "wb") as f:
            f.write(data)

        size_mb = len(data) / (1024 * 1024)
        if size_mb >= 1.0:
            print(f"Downloaded: {output_path} ({size_mb:.1f} MB)")
        else:
            size_kb = len(data) / 1024
            print(f"Downloaded: {output_path} ({size_kb:.1f} KB)")
    except urllib.error.HTTPError as e:
        print(f"Error: HTTP {e.code} — {e.read().decode()[:200]}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


def cmd_runs(args):
    """List recent evaluation runs from the platform."""
    import urllib.request

    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)

    platform = args.platform.rstrip("/")
    params = f"limit={args.limit}"
    if args.env:
        params += f"&env={args.env}"
    url = f"{platform}/api/cli/runs?{params}"

    class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            raise urllib.error.HTTPError(newurl, code, msg, headers, fp)

    opener = urllib.request.build_opener(_NoRedirectHandler)
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "User-Agent": "athanor-cli/0.2.0",
        },
    )

    try:
        resp = opener.open(req, timeout=30)
        data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        print(f"Error: HTTP {e.code} — {e.read().decode()[:200]}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    # Handle {runs: [...]}, {data: [...]}, or [...]
    if isinstance(data, list):
        runs = data
    elif isinstance(data, dict):
        runs = data.get("runs") or data.get("data") or []
    else:
        runs = []

    if not runs:
        print("No runs found.")
        return

    # Print table
    print(f"  {'Run ID':<10} {'Environment':<20} {'Model':<22} {'Tasks':>5} {'Mean Score':>10} {'Date':<12}")
    print(f"  {'-' * 10} {'-' * 20} {'-' * 22} {'-' * 5} {'-' * 10} {'-' * 12}")
    for r in runs:
        run_id = str(r.get("id", r.get("run_id", "")))[:8]
        env = str(r.get("environment", r.get("env", "")))[:20]
        model = str(r.get("model", ""))[:22]
        tasks = r.get("tasks", r.get("task_count", ""))
        mean = r.get("mean_score", r.get("score", ""))
        date = str(r.get("date", r.get("created_at", r.get("completed_at", ""))))[:12]
        score_str = f"{float(mean):.3f}" if mean != "" and mean is not None else ""
        print(f"  {run_id:<10} {env:<20} {model:<22} {str(tasks):>5} {score_str:>10} {date:<12}")


def cmd_proofs(args):
    """List verified proofs from the platform."""
    import urllib.request

    token = args.token or os.environ.get("ATHANOR_TOKEN") or os.environ.get("CRON_SECRET")
    if not token:
        print("Error: --token required or set ATHANOR_TOKEN env var")
        sys.exit(1)

    platform = args.platform.rstrip("/")
    params = f"limit={args.limit}"
    if args.env:
        params += f"&env={args.env}"
    url = f"{platform}/api/cli/proofs?{params}"

    class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            raise urllib.error.HTTPError(newurl, code, msg, headers, fp)

    opener = urllib.request.build_opener(_NoRedirectHandler)
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "User-Agent": "athanor-cli/0.2.0",
        },
    )

    try:
        resp = opener.open(req, timeout=30)
        data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        print(f"Error: HTTP {e.code} — {e.read().decode()[:200]}")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    # Handle {proofs: [...]}, {data: [...]}, or [...]
    if isinstance(data, list):
        proofs = data
    elif isinstance(data, dict):
        proofs = data.get("proofs") or data.get("data") or []
    else:
        proofs = []

    if not proofs:
        print("No proofs found.")
        return

    # Print table
    print(f"  {'Task':<30} {'Environment':<20} {'Model':<22} {'Score':>7} {'Proof Backend':<14}")
    print(f"  {'-' * 30} {'-' * 20} {'-' * 22} {'-' * 7} {'-' * 14}")
    for p in proofs:
        task = str(p.get("task", p.get("task_slug", "")))[:30]
        env = str(p.get("environment", p.get("env", "")))[:20]
        model = str(p.get("model", ""))[:22]
        score = p.get("score", "")
        backend = str(p.get("proof_backend", p.get("backend", "")))[:14]
        score_str = f"{float(score):.3f}" if score != "" and score is not None else ""
        print(f"  {task:<30} {env:<20} {model:<22} {score_str:>7} {backend:<14}")


def cmd_config(args):
    """Manage configuration."""
    config_dir = os.path.expanduser("~/.athanor")
    config_file = os.path.join(config_dir, "config.json")
    os.makedirs(config_dir, exist_ok=True)

    config = {}
    if os.path.exists(config_file):
        config = json.load(open(config_file))

    if args.set:
        key, _, value = args.set.partition("=")
        config[key] = value
        json.dump(config, open(config_file, "w"), indent=2)
        print(f"Set {key}")
    else:
        for k, v in config.items():
            display = v[:8] + "..." if len(str(v)) > 20 else v
            print(f"  {k}={display}")


def main():
    parser = argparse.ArgumentParser(
        prog="athanor",
        description="Athanor AI — formal verification as agentic training signal",
    )
    sub = parser.add_subparsers(dest="command")

    # run
    p_run = sub.add_parser("run", help="Start the self-hosted runner")
    p_run.add_argument("--token", help="Sync token (or set ATHANOR_TOKEN)")
    p_run.add_argument("--platform", default="https://tahoe.athanor-ai.com", help="Platform URL")
    p_run.add_argument("--name", default="default", help="Runner name")

    # score
    p_score = sub.add_parser("score", help="Score a file against a task")
    p_score.add_argument("--token", help="Sync token")
    p_score.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_score.add_argument("--env", required=True, help="Environment slug")
    p_score.add_argument("--task", required=True, help="Task slug")
    p_score.add_argument("--file", required=True, help="Path to student file")

    # solve
    p_solve = sub.add_parser("solve", help="Solve a task with a model")
    p_solve.add_argument("--token", help="Sync token")
    p_solve.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_solve.add_argument("--env", required=True, help="Environment slug")
    p_solve.add_argument("--task", required=True, help="Task slug")
    p_solve.add_argument("--model", default="claude-opus-4-6", help="Model to use")
    p_solve.add_argument("--output", "-o", help="Output JSON path")

    # build
    p_build = sub.add_parser("build", help="Build a task using Opus 4.6")
    p_build.add_argument("--token", help="Sync token")
    p_build.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_build.add_argument("--api-key", help="Anthropic API key for Opus 4.6")
    p_build.add_argument("--env", required=True, help="Environment slug")
    p_build.add_argument("--name", required=True, help="Task name (snake_case)")
    p_build.add_argument("--description", required=True, help="What the agent should do")
    p_build.add_argument("--difficulty", default="medium", choices=["easy", "medium", "hard"])
    p_build.add_argument("--category", default="implementation",
                         choices=["bug_fix", "implementation", "verification", "optimization", "translation"])
    p_build.add_argument("--proof-backend", default="none",
                         choices=["none", "lean4", "dafny", "ebmc", "verus"])
    p_build.add_argument("--scoring", default="property_tests",
                         choices=["property_tests", "simulation", "compilation", "output_match"])
    p_build.add_argument("--output", help="Output directory for generated files")

    # evaluate
    p_eval = sub.add_parser("evaluate", help="Batch evaluate all tasks in an environment")
    p_eval.add_argument("--token", help="Sync token")
    p_eval.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_eval.add_argument("--env", required=True, help="Environment slug")
    p_eval.add_argument("--model", default="claude-opus-4-6", help="Model to use")
    p_eval.add_argument("--output", "-o", help="Output JSON path")

    # pull
    p_pull = sub.add_parser("pull", help="Download an environment tarball")
    p_pull.add_argument("--token", help="Sync token")
    p_pull.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_pull.add_argument("--env", required=True, help="Environment slug")
    p_pull.add_argument("--output", "-o", help="Output path (default: {env}.tar.gz)")

    # runs
    p_runs = sub.add_parser("runs", help="List recent evaluation runs")
    p_runs.add_argument("--token", help="Sync token")
    p_runs.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_runs.add_argument("--env", default=None, help="Filter by environment slug")
    p_runs.add_argument("--limit", type=int, default=10, help="Max runs to show (default 10)")

    # proofs
    p_proofs = sub.add_parser("proofs", help="List verified proofs")
    p_proofs.add_argument("--token", help="Sync token")
    p_proofs.add_argument("--platform", default="https://tahoe.athanor-ai.com")
    p_proofs.add_argument("--env", default=None, help="Filter by environment slug")
    p_proofs.add_argument("--limit", type=int, default=20, help="Max proofs to show (default 20)")

    # config
    p_config = sub.add_parser("config", help="Manage configuration")
    p_config.add_argument("--set", help="Set a config value (KEY=VALUE)")

    args = parser.parse_args()
    if args.command == "run":
        cmd_run(args)
    elif args.command == "score":
        cmd_score(args)
    elif args.command == "solve":
        cmd_solve(args)
    elif args.command == "build":
        cmd_build(args)
    elif args.command == "evaluate":
        cmd_evaluate(args)
    elif args.command == "pull":
        cmd_pull(args)
    elif args.command == "runs":
        cmd_runs(args)
    elif args.command == "proofs":
        cmd_proofs(args)
    elif args.command == "config":
        cmd_config(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
