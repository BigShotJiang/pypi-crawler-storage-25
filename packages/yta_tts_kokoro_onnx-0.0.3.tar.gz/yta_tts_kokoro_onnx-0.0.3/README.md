# Youtube Autonomous TTS Kokoro Onnx Module

This project is to include the TTS functionality using the official `kokoro-onnx` project (https://github.com/thewh1teagle/kokoro-onnx) which is apparently supporting more languages than the original project.

The models and voices needed are downloaded automatically by the `kokoro-onnx` dependency from Hugginface.

Here you have one example using the Spanish language: https://www.dailymotion.com/video/xa87qpy