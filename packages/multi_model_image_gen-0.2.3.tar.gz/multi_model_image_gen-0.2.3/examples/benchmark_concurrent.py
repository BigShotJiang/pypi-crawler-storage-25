"""Benchmark: concurrent async Higgsfield-style requests vs serial.

Demonstrates that ``asyncio.gather`` over 10 concurrent requests completes in
~single-request time rather than 10× that time.

No real API keys are required — the script uses a mock provider that simulates
0.5s of network/polling latency per request.

Run:
    PYTHONPATH=src python examples/benchmark_concurrent.py

Expected output (approximate):
    --- Concurrent benchmark (10 requests, 0.50s simulated latency each) ---
    Serial baseline (estimated):    5.00s
    Concurrent asyncio.gather:      0.51s  (10 requests in parallel)
    Speedup:                        9.8x
    All 10 requests completed successfully.

    --- Higgsfield-style poll simulation (3 pending → completed) ---
    Poll iterations: 3  (interval=0.01s, total=~0.02s)
    Result: completed  image_url=https://mock.example.com/img.png
"""

from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path

# Allow running from the repo root without installing the package.
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from image_gen.providers._poll import poll_until_async
from image_gen.providers.result import GenerationResult

# ---------------------------------------------------------------------------
# Mock provider (simulates a slow network + polling backend)
# ---------------------------------------------------------------------------

SIMULATED_LATENCY = 0.5  # seconds per request
NUM_REQUESTS = 10


class MockHiggsFieldProvider:
    """Simulates a Higgsfield-like async provider with 0.5s latency."""

    async def generate_image_async(
        self,
        prompt: str,
        model: str = "higgsfield-ai/soul/standard",
        **kwargs,
    ) -> GenerationResult:
        """Simulate a full submit-poll-complete cycle."""
        # Simulate network round-trip + server processing.
        await asyncio.sleep(SIMULATED_LATENCY)
        return GenerationResult(
            request_id=f"mock-{id(asyncio.current_task())}",
            status="completed",
            image_url="https://mock.example.com/img.png",
        )


# ---------------------------------------------------------------------------
# Benchmark 1: concurrent gather vs serial
# ---------------------------------------------------------------------------

async def benchmark_concurrent() -> None:
    provider = MockHiggsFieldProvider()
    prompt = "a neon-lit Tokyo alley at night"

    print(f"\n--- Concurrent benchmark ({NUM_REQUESTS} requests, {SIMULATED_LATENCY:.2f}s simulated latency each) ---")
    serial_estimate = NUM_REQUESTS * SIMULATED_LATENCY
    print(f"Serial baseline (estimated):    {serial_estimate:.2f}s")

    start = time.monotonic()
    results = await asyncio.gather(
        *[provider.generate_image_async(prompt) for _ in range(NUM_REQUESTS)]
    )
    elapsed = time.monotonic() - start

    speedup = serial_estimate / elapsed
    print(f"Concurrent asyncio.gather:      {elapsed:.2f}s  ({NUM_REQUESTS} requests in parallel)")
    print(f"Speedup:                        {speedup:.1f}x")

    completed = sum(1 for r in results if r.status == "completed")
    print(f"All {completed}/{NUM_REQUESTS} requests completed successfully.")

    assert completed == NUM_REQUESTS, "Not all requests completed!"
    assert elapsed < serial_estimate * 0.5, (
        f"Expected concurrent execution to be at least 2x faster than serial. "
        f"Got {elapsed:.2f}s vs serial {serial_estimate:.2f}s."
    )


# ---------------------------------------------------------------------------
# Benchmark 2: Higgsfield-style polling simulation
# ---------------------------------------------------------------------------

async def benchmark_poll_simulation() -> None:
    print("\n--- Higgsfield-style poll simulation (3 pending → completed) ---")

    poll_count = 0

    async def _status_fn() -> dict:
        nonlocal poll_count
        poll_count += 1
        if poll_count < 3:
            return {"status": "pending"}
        return {
            "status": "completed",
            "output": {"image_url": "https://mock.example.com/img.png"},
        }

    poll_interval = 0.01
    start = time.monotonic()
    terminal, data = await poll_until_async(
        status_fn=_status_fn,
        is_done=lambda d: d.get("status") == "completed",
        is_failed=lambda d: d.get("status") == "failed",
        is_blocked=lambda d: d.get("status") == "nsfw",
        interval=poll_interval,
        timeout=5.0,
    )
    elapsed = time.monotonic() - start

    print(f"Poll iterations: {poll_count}  (interval={poll_interval}s, total={elapsed:.2f}s)")
    print(f"Result: {terminal}  image_url={data['output']['image_url']}")

    assert terminal == "completed"
    assert poll_count == 3


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

async def main() -> None:
    await benchmark_concurrent()
    await benchmark_poll_simulation()
    print("\nAll benchmarks passed.")


if __name__ == "__main__":
    asyncio.run(main())
