"""Skeleton RunwayML provider for multi-model-image-gen.

This module demonstrates how to package a third-party provider as a plugin.
It does not call real Runway APIs; it returns stub data so the wiring can be
validated without credentials.

Install with:
    pip install -e ./examples/runway_plugin

Then use:
    from image_gen import generate
    result = generate(prompt="a neon city", model="runway:gen-3")
    print(result.status)  # "completed"
"""

from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any

# poll_until is imported from the host package to demonstrate the pattern
# described in providers/README.md.  A real plugin would drive an actual
# async task API here.
from image_gen.providers._poll import poll_until
from image_gen.providers.result import GenerationResult


class RunwayClient:
    """Stub ImageProvider for RunwayML Gen-3 Alpha.

    Demonstrates the minimal surface required to satisfy the ImageProvider
    protocol and integrate with multi-model-image-gen's plugin system.
    """

    # Mapping of shorthand model names to canonical Runway API identifiers.
    _MODEL_MAP: dict[str, str] = {
        "gen-3": "gen3a_turbo",
        "gen-3-alpha": "gen3a",
        "gen-3-turbo": "gen3a_turbo",
    }

    def generate_image(
        self,
        prompt: str,
        model: str = "gen-3",
        aspect_ratio: str = "9:16",
        resolution: str = "720p",
        **kwargs: Any,
    ) -> GenerationResult:
        """Submit a generation task and poll until complete.

        This stub never makes a network call; it uses poll_until with an
        instant-success status function to verify the integration plumbing.

        Args:
            prompt: Text prompt forwarded to the Runway API.
            model: Runway model shorthand (``"gen-3"``, ``"gen-3-turbo"``).
            aspect_ratio: Desired output aspect ratio.
            resolution: Desired output resolution.
            **kwargs: Additional parameters forwarded to the Runway API.

        Returns:
            A :class:`GenerationResult` with ``status="completed"`` and
            stub ``image_url`` populated.
        """
        canonical_model = self._MODEL_MAP.get(model, model)
        request_id = str(uuid.uuid4())

        # In a real client you would POST to the Runway API here and then
        # poll the task endpoint.  We use poll_until with a one-shot stub
        # status_fn to exercise the primitive without network access.
        call_count = 0

        def _stub_status() -> dict[str, Any]:
            nonlocal call_count
            call_count += 1
            return {
                "id": request_id,
                "status": "SUCCEEDED",
                "output": [f"https://runway.example/stub/{request_id}.mp4"],
                "model": canonical_model,
            }

        terminal, data = poll_until(
            status_fn=_stub_status,
            is_done=lambda d: d.get("status") == "SUCCEEDED",
            is_failed=lambda d: d.get("status") == "FAILED",
            is_blocked=lambda d: d.get("status") == "CONTENT_MODERATED",
            interval=0.0,   # no delay in stub
            timeout=30.0,
        )

        output_urls: list[str] = data.get("output") or []
        return GenerationResult(
            request_id=request_id,
            status=terminal,
            video_url=output_urls[0] if output_urls else None,
            raw=data,
        )

    def download(self, url: str, output_path: str | Path) -> Path:
        """Download a previously generated asset to *output_path*.

        Stub implementation — writes placeholder bytes so callers that check
        the output file don't crash.
        """
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(b"STUB:runway:" + url.encode())
        return out

    def close(self) -> None:
        """Release any held resources (HTTP sessions, etc.)."""
        # Stub has no resources to release.
