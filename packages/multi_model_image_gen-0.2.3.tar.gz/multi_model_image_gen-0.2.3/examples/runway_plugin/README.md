# runway-image-gen — Example Plugin for multi-model-image-gen

This package demonstrates how to add a new provider to `multi-model-image-gen`
without modifying the core library.  It registers a `RunwayClient` via the
`image_gen.providers` entry-point group.

The implementation is intentionally a stub: it exercises the `poll_until`
primitive from Phase 5 but never calls real Runway APIs.  Use it as a
template when integrating a real async-task provider.

## Installation

```bash
# From the repo root, install the core library in editable mode first:
pip install -e .

# Then install the plugin in editable mode:
pip install -e ./examples/runway_plugin
```

## Usage

```python
from image_gen import generate

# "runway:gen-3" routes to RunwayClient.generate_image(model="gen-3")
result = generate(prompt="a neon cyberpunk city", model="runway:gen-3")
print(result.status)   # "completed"
print(result.video_url)  # stub URL

# The plugin is also accessible directly:
from runway_image_gen import RunwayClient

client = RunwayClient()
result = client.generate_image(prompt="...", model="gen-3-turbo")
client.close()
```

## Verification (no API key needed)

```bash
PYTHONPATH=../../src python -c "
from image_gen import generate
result = generate(prompt='a neon city', model='runway:gen-3')
print(result)
"
```

Expected output (status and video_url will vary by stub UUID):

```
GenerationResult(request_id='...', status='completed', image_bytes=None,
                 image_url=None, video_url='https://runway.example/stub/....mp4', ...)
```

## How It Works

1. `pyproject.toml` declares:
   ```toml
   [project.entry-points."image_gen.providers"]
   runway = "runway_image_gen:RunwayClient"
   ```
2. When `get_provider("runway")` is called and `"runway"` is not in the
   runtime registry, the library calls `_discover_plugins()` which uses
   `importlib.metadata.entry_points(group="image_gen.providers")` to find
   this entry point and loads `RunwayClient`.
3. `RunwayClient.generate_image` uses `poll_until` from
   `image_gen.providers._poll` to drive the async task loop — exactly the
   same primitive used by `HiggsFieldClient`.

## Writing Your Own Plugin

1. Copy this directory.
2. Rename the package (`runway_image_gen` → `your_provider_image_gen`).
3. Rename the entry-point key in `pyproject.toml` to your provider name.
4. Implement `generate_image`, `download`, and `close` on your client class.
5. `pip install -e .` and use `generate(model="your-provider:model-name")`.
