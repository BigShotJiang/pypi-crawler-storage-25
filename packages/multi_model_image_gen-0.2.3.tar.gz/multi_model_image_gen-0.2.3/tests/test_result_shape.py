"""GenerationResult schema + generate() output writing."""

from __future__ import annotations

from unittest.mock import patch

from image_gen import GenerationResult, generate


def test_generation_result_defaults():
    r = GenerationResult(request_id="x", status="completed")
    assert r.image_bytes is None
    assert r.image_url is None
    assert r.video_url is None
    assert r.cost_usd is None
    assert r.raw is None


def test_generation_result_bytes_field():
    r = GenerationResult(request_id="x", status="completed", image_bytes=b"PNG_BYTES")
    assert r.image_bytes == b"PNG_BYTES"


def test_generate_writes_bytes_to_output(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    out_path = tmp_path / "out.png"
    payload = b"\x89PNG\r\n\x1a\nFAKE"

    fake_result = GenerationResult(
        request_id="r1", status="completed", image_bytes=payload
    )

    with patch("image_gen.get_provider") as get_prov:
        client = get_prov.return_value
        client.generate_image.return_value = fake_result
        generate(prompt="x", model="gpt-image", output=out_path, provider="openai")

    assert out_path.read_bytes() == payload


def test_generate_uses_url_when_no_bytes(tmp_path, monkeypatch):
    monkeypatch.setenv("FAL_KEY", "test-key")
    out_path = tmp_path / "out.png"
    fake_result = GenerationResult(
        request_id="r1", status="completed", image_url="https://example.com/x.png"
    )

    with patch("image_gen.get_provider") as get_prov:
        client = get_prov.return_value
        client.generate_image.return_value = fake_result
        generate(prompt="x", model="flux", output=out_path, provider="fal")

        client.download.assert_called_once_with("https://example.com/x.png", out_path)


def test_generate_skips_output_on_non_completed(tmp_path, monkeypatch):
    monkeypatch.setenv("FAL_KEY", "test-key")
    out_path = tmp_path / "out.png"
    fake_result = GenerationResult(request_id="r1", status="failed")

    with patch("image_gen.get_provider") as get_prov:
        client = get_prov.return_value
        client.generate_image.return_value = fake_result
        generate(prompt="x", model="flux", output=out_path, provider="fal")

        client.download.assert_not_called()

    assert not out_path.exists()
