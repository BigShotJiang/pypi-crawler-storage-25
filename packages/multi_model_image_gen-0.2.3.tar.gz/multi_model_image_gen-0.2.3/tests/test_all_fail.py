"""Test that FallbackExhausted is raised with the full error chain when every provider fails.

Strategy
--------
Stub ``get_provider`` with N mock clients that all raise.  Assert:

 1. ``FallbackExhausted`` is raised.
 2. ``errors`` contains one entry per provider, in order.
 3. Each entry captures the correct (provider_name, exception) pair.
 4. The exception message includes all provider names.
"""

from __future__ import annotations

import pytest

from image_gen.providers.result import GenerationResult
from image_gen.router import FallbackExhausted, Router


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FailClient:
    """Mock client that always raises with a distinguishable message."""

    def __init__(self, name: str) -> None:
        self._name = name

    def generate_image(self, **_kwargs) -> GenerationResult:
        raise RuntimeError(f"{self._name} failed")

    def close(self) -> None:
        pass


def _patch_providers(names: list[str], monkeypatch) -> None:
    clients = {name: _FailClient(name) for name in names}

    def _fake_get_provider(name: str):
        if name not in clients:
            raise ValueError(f"unexpected provider: {name}")
        return clients[name]

    monkeypatch.setattr("image_gen.router.get_provider", _fake_get_provider)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_all_fail_raises_fallback_exhausted(monkeypatch):
    """Three providers all fail → FallbackExhausted with three error entries."""
    providers = ["alpha", "beta", "gamma"]
    _patch_providers(providers, monkeypatch)

    router = Router(primary="alpha", fallbacks=["beta", "gamma"])
    with pytest.raises(FallbackExhausted) as exc_info:
        router.generate("test prompt")

    err = exc_info.value
    assert len(err.errors) == 3


def test_all_fail_error_order(monkeypatch):
    """Errors list preserves the attempt order: primary first, then fallbacks."""
    providers = ["alpha", "beta", "gamma"]
    _patch_providers(providers, monkeypatch)

    router = Router(primary="alpha", fallbacks=["beta", "gamma"])
    with pytest.raises(FallbackExhausted) as exc_info:
        router.generate("test prompt")

    names = [name for name, _ in exc_info.value.errors]
    assert names == ["alpha", "beta", "gamma"]


def test_all_fail_error_pairs(monkeypatch):
    """Each error entry contains the correct (name, exception) pair."""
    providers = ["alpha", "beta"]
    _patch_providers(providers, monkeypatch)

    router = Router(primary="alpha", fallbacks=["beta"])
    with pytest.raises(FallbackExhausted) as exc_info:
        router.generate("test prompt")

    for name, exc in exc_info.value.errors:
        assert isinstance(exc, RuntimeError)
        assert name in str(exc), f"Expected provider name '{name}' in exception message"


def test_all_fail_exception_message_contains_providers(monkeypatch):
    """The FallbackExhausted message mentions each provider name."""
    providers = ["p1", "p2", "p3"]
    _patch_providers(providers, monkeypatch)

    router = Router(primary="p1", fallbacks=["p2", "p3"])
    with pytest.raises(FallbackExhausted) as exc_info:
        router.generate("test prompt")

    message = str(exc_info.value)
    for name in providers:
        assert name in message, f"Expected '{name}' in FallbackExhausted message"


def test_single_provider_all_fail(monkeypatch):
    """Only primary, no fallbacks, primary fails → FallbackExhausted with one entry."""
    _patch_providers(["solo"], monkeypatch)

    router = Router(primary="solo")
    with pytest.raises(FallbackExhausted) as exc_info:
        router.generate("test prompt")

    assert len(exc_info.value.errors) == 1
    name, exc = exc_info.value.errors[0]
    assert name == "solo"
    assert isinstance(exc, RuntimeError)


def test_fallback_exhausted_is_exception():
    """FallbackExhausted must be an Exception subclass."""
    errors = [("x", RuntimeError("boom"))]
    exc = FallbackExhausted(errors)
    assert isinstance(exc, Exception)
    assert exc.errors is errors
