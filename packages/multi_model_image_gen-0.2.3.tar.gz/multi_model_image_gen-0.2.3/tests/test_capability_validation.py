"""Capability validation tests.

Verifies that ``UnsupportedCapabilityError`` is raised **before** any SDK call
when the requested aspect_ratio or resolution is not supported by the model.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from image_gen import generate
from image_gen.providers.catalog import UnsupportedCapabilityError, load_catalog

load_catalog.cache_clear()


@pytest.fixture(autouse=True)
def clear_cache():
    load_catalog.cache_clear()
    yield
    load_catalog.cache_clear()


def test_unsupported_aspect_ratio_raises_before_sdk_call():
    """An aspect_ratio not in the catalog entry must raise before any provider call."""
    with patch("image_gen.get_provider") as mock_get_provider:
        mock_client = MagicMock()
        mock_get_provider.return_value = mock_client

        with pytest.raises(UnsupportedCapabilityError) as exc_info:
            generate(
                prompt="test prompt",
                model="flux",
                aspect_ratio="3:2",  # not supported by flux
            )

        # The SDK (generate_image) must never have been called
        mock_client.generate_image.assert_not_called()

    assert "aspect_ratio" in str(exc_info.value).lower() or "3:2" in str(exc_info.value)


def test_unsupported_resolution_raises_before_sdk_call():
    """A resolution not in the catalog entry must raise before any provider call."""
    with patch("image_gen.get_provider") as mock_get_provider:
        mock_client = MagicMock()
        mock_get_provider.return_value = mock_client

        with pytest.raises(UnsupportedCapabilityError) as exc_info:
            generate(
                prompt="test prompt",
                model="flux",
                aspect_ratio="1:1",  # valid
                resolution="4k",  # not listed for flux
            )

        mock_client.generate_image.assert_not_called()

    assert "resolution" in str(exc_info.value).lower() or "4k" in str(exc_info.value)


def test_supported_aspect_ratio_does_not_raise():
    """Supported capabilities must not raise and must reach the client."""
    fake_result = MagicMock()
    fake_result.status = "completed"
    fake_result.image_bytes = b"PNG"
    fake_result.image_url = None
    fake_result.cost_usd = None

    with patch("image_gen.get_provider") as mock_get_provider:
        mock_client = MagicMock()
        mock_client.generate_image.return_value = fake_result
        mock_get_provider.return_value = mock_client

        result = generate(
            prompt="test prompt",
            model="flux",
            aspect_ratio="9:16",  # supported
            resolution="720p",  # supported
        )

    mock_client.generate_image.assert_called_once()
    assert result.status == "completed"


def test_error_message_includes_model_and_supported_values():
    """Error message must name the model and list what IS supported."""
    with patch("image_gen.get_provider"):
        with pytest.raises(UnsupportedCapabilityError) as exc_info:
            generate(
                prompt="test prompt",
                model="flux",
                aspect_ratio="5:4",
            )

    msg = str(exc_info.value)
    # Should mention the shorthand or model name
    assert "flux" in msg
    # Should mention the bad value
    assert "5:4" in msg


@pytest.mark.parametrize("model", ["gpt-image", "nb2", "imagen4", "seedream"])
def test_valid_capabilities_for_catalog_models(model):
    """Every catalog model should accept (9:16, 720p) without raising."""
    fake_result = MagicMock()
    fake_result.status = "completed"
    fake_result.image_bytes = b"x"
    fake_result.image_url = None
    fake_result.cost_usd = None

    with patch("image_gen.get_provider") as mock_get_provider:
        mock_client = MagicMock()
        mock_client.generate_image.return_value = fake_result
        mock_get_provider.return_value = mock_client

        # Should not raise
        generate(prompt="test", model=model, aspect_ratio="9:16", resolution="720p")

    mock_client.generate_image.assert_called_once()


def test_unknown_model_bypasses_validation():
    """Full model IDs not in the catalog bypass validation entirely."""
    fake_result = MagicMock()
    fake_result.status = "completed"
    fake_result.image_bytes = b"x"
    fake_result.image_url = None
    fake_result.cost_usd = None

    with patch("image_gen.get_provider") as mock_get_provider:
        mock_client = MagicMock()
        mock_client.generate_image.return_value = fake_result
        mock_get_provider.return_value = mock_client

        # This model ID is not in the catalog → resolve() returns None → no validation
        result = generate(
            prompt="test",
            model="some-provider/unknown-custom-model/v99",
            aspect_ratio="5:4",  # arbitrary, should not raise because model is unknown
            provider="higgsfield",
        )

    assert result.status == "completed"
    mock_client.generate_image.assert_called_once()
