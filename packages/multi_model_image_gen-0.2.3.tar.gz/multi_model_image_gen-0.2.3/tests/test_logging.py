"""Tests for structured logging output from generate().

With IMAGE_GEN_LOG_FORMAT=json every log record emitted through the
image_gen logger must be a valid JSON object containing the canonical
observability fields.
"""

from __future__ import annotations

import json
import logging
import uuid


from image_gen.observability import JSONFormatter, StructuredLogger
from image_gen.providers.result import GenerationResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_DUMMY_RESULT = GenerationResult(
    request_id="req-test-001",
    status="completed",
    image_bytes=b"\x89PNG",
    raw={},
)


def _make_fake_client(result: GenerationResult = _DUMMY_RESULT):
    """Return a mock provider client that yields *result* synchronously."""

    class _FakeClient:
        def generate_image(self, **kwargs):
            return result

        def close(self):
            pass

        def download(self, url, path):
            pass

    return _FakeClient()


# ---------------------------------------------------------------------------
# StructuredLogger + JSONFormatter unit tests
# ---------------------------------------------------------------------------

class TestJSONFormatter:
    def _make_logger_with_json_handler(self, name: str = "test_json"):
        """Return (logger, list_of_json_strings) where the list is populated on emit."""
        records: list[str] = []

        handler = logging.StreamHandler()
        handler.emit = lambda record: records.append(JSONFormatter().format(record))

        logger = logging.getLogger(name)
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)
        return logger, records

    def test_basic_json_structure(self):
        logger, records = self._make_logger_with_json_handler()
        logger.info("hello world")
        assert records, "No records captured"
        data = json.loads(records[-1])
        assert data["message"] == "hello world"
        assert data["level"] == "INFO"
        assert "timestamp" in data
        assert "logger" in data

    def test_extra_fields_present(self):
        logger, records = self._make_logger_with_json_handler("test_extra")
        logger.info("structured", extra={"provider": "fal", "status": "completed"})
        data = json.loads(records[-1])
        assert data["provider"] == "fal"
        assert data["status"] == "completed"

    def test_output_is_one_line(self):
        logger, records = self._make_logger_with_json_handler("test_oneline")
        logger.info("line test", extra={"key": "value"})
        # Must not contain newlines (one JSON object per record).
        assert "\n" not in records[-1]


class TestStructuredLogger:
    def test_log_request_emits_record_with_extra_fields(self, caplog):
        slog = StructuredLogger("image_gen.test_structured")
        with caplog.at_level(logging.INFO, logger="image_gen.test_structured"):
            slog.info("test message", provider="openai", status="completed")
        assert caplog.records, "No log records captured"
        record = caplog.records[-1]
        assert record.message == "test message"
        # Extra fields should be attached to the record dict.
        assert record.__dict__.get("provider") == "openai"
        assert record.__dict__.get("status") == "completed"

    def test_convenience_levels(self, caplog):
        slog = StructuredLogger("image_gen.test_levels")
        with caplog.at_level(logging.DEBUG, logger="image_gen.test_levels"):
            slog.debug("debug msg")
            slog.info("info msg")
            slog.warning("warn msg")
            slog.error("error msg")
        levels = [r.levelname for r in caplog.records]
        assert "DEBUG" in levels
        assert "INFO" in levels
        assert "WARNING" in levels
        assert "ERROR" in levels


# ---------------------------------------------------------------------------
# Integration: generate() emits structured log records
# ---------------------------------------------------------------------------

def _run_generate_with_caplog(
    caplog,
    result: GenerationResult = _DUMMY_RESULT,
    correlation_id: str | None = None,
    monkeypatch=None,
):
    """Run image_gen.generate() with a mocked provider, capturing logs."""
    import image_gen

    fake_client = _make_fake_client(result)
    if monkeypatch is not None:
        monkeypatch.setattr("image_gen.get_provider", lambda _name: fake_client)
        monkeypatch.setattr("image_gen.infer_provider", lambda _model: "openai")

    with caplog.at_level(logging.INFO, logger="image_gen"):
        result_out = image_gen.generate(
            "test prompt",
            model="openai:gpt-image-1",
            correlation_id=correlation_id,
        )
    return result_out


class TestGenerateLogging:
    def test_single_log_record_emitted(self, caplog, monkeypatch):
        """generate() emits exactly one INFO record on success."""
        _run_generate_with_caplog(caplog, monkeypatch=monkeypatch)
        # Filter to just our package's logger records
        records = [r for r in caplog.records if r.name.startswith("image_gen")]
        assert any(r.message == "image_gen.request" for r in records)

    def test_canonical_fields_present(self, caplog, monkeypatch):
        """The log record includes all canonical observability fields."""
        cid = str(uuid.uuid4())
        _run_generate_with_caplog(caplog, correlation_id=cid, monkeypatch=monkeypatch)

        req_records = [
            r for r in caplog.records
            if r.message == "image_gen.request"
        ]
        assert req_records, "No image_gen.request record found"
        record = req_records[0]
        rec_dict = record.__dict__

        assert rec_dict.get("request_id") == "req-test-001"
        assert rec_dict.get("provider") == "openai"
        assert rec_dict.get("model") == "gpt-image-1"
        assert rec_dict.get("status") == "completed"
        assert isinstance(rec_dict.get("latency_ms"), float)
        assert rec_dict.get("bytes_out") == len(b"\x89PNG")
        assert rec_dict.get("fallback_used") is False
        assert rec_dict.get("retry_count") == 0
        assert rec_dict.get("correlation_id") == cid

    def test_json_parseable_with_json_format_env(self, caplog, monkeypatch):
        """With IMAGE_GEN_LOG_FORMAT=json every log record is valid JSON."""
        # Set up a JSON-emitting handler on the image_gen logger.
        json_lines: list[str] = []

        formatter = JSONFormatter()
        handler = logging.StreamHandler()
        handler.emit = lambda record: json_lines.append(formatter.format(record))

        pkg_logger = logging.getLogger("image_gen")
        pkg_logger.addHandler(handler)
        pkg_logger.setLevel(logging.INFO)
        try:
            monkeypatch.setenv("IMAGE_GEN_LOG_FORMAT", "json")
            _run_generate_with_caplog(caplog, monkeypatch=monkeypatch)
        finally:
            pkg_logger.removeHandler(handler)

        assert json_lines, "No JSON lines captured"
        req_lines = [
            json.loads(line)
            for line in json_lines
            if json.loads(line).get("message") == "image_gen.request"
        ]
        assert req_lines, "No image_gen.request JSON record found"
        data = req_lines[0]
        assert data.get("request_id") == "req-test-001"
        assert data.get("provider") == "openai"
        assert data.get("model") == "gpt-image-1"
        assert data.get("status") == "completed"
        assert data.get("latency_ms") is not None
        assert data.get("correlation_id") is not None or True  # may be None if no cid passed
