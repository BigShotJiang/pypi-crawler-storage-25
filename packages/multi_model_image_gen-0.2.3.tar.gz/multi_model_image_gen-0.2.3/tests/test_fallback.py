"""Test that Router falls back to the secondary provider when primary fails.

Strategy
--------
We stub ``get_provider`` to return lightweight mock clients so no SDK or network
is involved.  We verify:

 1. Primary raises on every call → fallback is invoked.
 2. The fallback's result is returned.
 3. Structured log messages (provider name, error class) are emitted.
"""

from __future__ import annotations

import logging

import pytest

from image_gen.providers.result import GenerationResult
from image_gen.router import FallbackExhausted, Router


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_FALLBACK_RESULT = GenerationResult(request_id="fallback-ok", status="completed")


class _AlwaysFailClient:
    """Mock provider that always raises RuntimeError."""

    def generate_image(self, **kwargs) -> GenerationResult:
        raise RuntimeError("primary exploded")

    def close(self) -> None:
        pass


class _AlwaysSucceedClient:
    """Mock provider that always returns a successful result."""

    def generate_image(self, **kwargs) -> GenerationResult:
        return _FALLBACK_RESULT

    def close(self) -> None:
        pass


def _make_router_with_mocks(primary_client, fallback_client, monkeypatch):
    """Patch get_provider so the Router uses our mock clients."""
    call_order = []

    def _fake_get_provider(name: str):
        call_order.append(name)
        if name == "primary":
            return primary_client
        if name == "fallback":
            return fallback_client
        raise ValueError(f"unexpected provider: {name}")

    monkeypatch.setattr("image_gen.router.get_provider", _fake_get_provider)
    return call_order


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_fallback_used_when_primary_fails(monkeypatch):
    """Primary raises → fallback succeeds → result returned."""
    call_order = _make_router_with_mocks(
        _AlwaysFailClient(), _AlwaysSucceedClient(), monkeypatch
    )

    router = Router(primary="primary", fallbacks=["fallback"])
    result = router.generate("test prompt", model="some-model")

    assert result is _FALLBACK_RESULT
    assert call_order == ["primary", "fallback"]


def test_fallback_log_messages(monkeypatch, caplog):
    """Router emits structured log messages on primary failure and fallback success."""
    _make_router_with_mocks(_AlwaysFailClient(), _AlwaysSucceedClient(), monkeypatch)

    router = Router(primary="primary", fallbacks=["fallback"])
    with caplog.at_level(logging.WARNING, logger="image_gen.router"):
        router.generate("test prompt", model="some-model")

    # Phase 6 switched to structured logging — the provider name is in the
    # record's `provider` extra field rather than the message string.
    warning_records = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert any(getattr(r, "provider", None) == "primary" for r in warning_records), (
        f"Expected a warning record with provider='primary'. "
        f"Records: {[(r.message, getattr(r, 'provider', None)) for r in warning_records]}"
    )
    assert any(
        getattr(r, "error_class", "") == "RuntimeError" for r in warning_records
    ), "Expected a warning with error_class='RuntimeError'."


def test_fallback_not_used_when_primary_succeeds(monkeypatch):
    """Primary succeeds → fallback is never called."""
    call_order = _make_router_with_mocks(
        _AlwaysSucceedClient(), _AlwaysFailClient(), monkeypatch
    )

    router = Router(primary="primary", fallbacks=["fallback"])
    result = router.generate("test prompt")

    assert result.status == "completed"
    assert call_order == ["primary"]  # fallback never touched


def test_no_fallbacks_configured(monkeypatch):
    """Router without fallbacks raises FallbackExhausted when primary fails."""
    _make_router_with_mocks(_AlwaysFailClient(), _AlwaysSucceedClient(), monkeypatch)

    router = Router(primary="primary")  # no fallbacks
    with pytest.raises(FallbackExhausted) as exc_info:
        router.generate("test prompt")

    assert len(exc_info.value.errors) == 1
    name, exc = exc_info.value.errors[0]
    assert name == "primary"
    assert isinstance(exc, RuntimeError)


def test_generate_kwarg_forwarded_to_fallback(monkeypatch):
    """kwargs passed to router.generate() reach the provider's generate_image."""
    received_kwargs: dict = {}

    class _KwargsCapture:
        def generate_image(self, **kwargs) -> GenerationResult:
            received_kwargs.update(kwargs)
            return _FALLBACK_RESULT

        def close(self) -> None:
            pass

    _make_router_with_mocks(_AlwaysFailClient(), _KwargsCapture(), monkeypatch)

    router = Router(primary="primary", fallbacks=["fallback"])
    router.generate("my prompt", model="test-model", aspect_ratio="1:1")

    assert received_kwargs.get("aspect_ratio") == "1:1"
    assert received_kwargs.get("model") == "test-model"
    assert received_kwargs.get("prompt") == "my prompt"


def test_generate_function_uses_router_when_fallbacks_given(monkeypatch):
    """image_gen.generate() with fallbacks= delegates to Router."""
    _make_router_with_mocks(_AlwaysFailClient(), _AlwaysSucceedClient(), monkeypatch)

    # Also patch infer_provider so generate() resolves 'primary' without real models.
    monkeypatch.setattr("image_gen.infer_provider", lambda _model: "primary")

    import image_gen

    result = image_gen.generate(
        "test prompt",
        model="some-model",
        fallbacks=["fallback"],
    )
    assert result is _FALLBACK_RESULT
