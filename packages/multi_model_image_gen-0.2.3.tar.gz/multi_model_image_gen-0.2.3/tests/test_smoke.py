"""Import + routing smoke test. Runs without API keys or network."""

from __future__ import annotations

import image_gen
from image_gen import GenerationResult, ImageProvider, generate, infer_provider


def test_public_api_exports():
    for name in ("generate", "infer_provider", "get_provider", "GenerationResult", "ImageProvider"):
        assert hasattr(image_gen, name), f"missing: {name}"


def test_version_present():
    assert image_gen.__version__


def test_routing():
    assert infer_provider("flux") == "fal"
    assert infer_provider("seedream-4.5") == "fal"
    assert infer_provider("gpt-image") == "openai"
    assert infer_provider("nb2") == "google-studio"
    assert infer_provider("nb-pro") == "google-studio"
    assert infer_provider("imagen4") == "google"
    assert infer_provider("higgsfield-ai/soul/standard") == "higgsfield"


def test_generation_result_shape():
    r = GenerationResult(request_id="x", status="completed", image_url="b64")
    assert r.request_id == "x"
    assert r.raw is None


def test_image_provider_is_runtime_checkable():
    # Any object with generate_image/download/close/async counterparts should
    # satisfy the protocol.
    class Fake:
        def generate_image(self, prompt, model=..., aspect_ratio=..., resolution=..., **kw):
            return GenerationResult(request_id="", status="completed")

        async def generate_image_async(self, prompt, model=..., aspect_ratio=..., resolution=..., **kw):
            return GenerationResult(request_id="", status="completed")

        def download(self, url, output_path):
            return output_path

        async def download_async(self, url, output_path):
            from pathlib import Path
            return Path(output_path)

        def close(self):
            pass

        async def aclose(self):
            pass

    assert isinstance(Fake(), ImageProvider)


def test_generate_unknown_provider_raises():
    import pytest

    with pytest.raises(ValueError):
        generate("hello", model="bogus:flux")
