"""Tests for the poll_until reusable polling primitive."""

from __future__ import annotations

import pytest

from image_gen.providers._poll import PollTimeout, poll_until


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_sequence(*responses: dict) -> callable:
    """Return a status_fn that yields each response in order, then repeats last."""
    items = list(responses)

    def status_fn() -> dict:
        if len(items) > 1:
            return items.pop(0)
        return items[0]

    return status_fn


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


def test_happy_path_returns_completed():
    """status_fn returns pending twice then completed; terminal == 'completed'."""
    responses = [
        {"status": "pending"},
        {"status": "pending"},
        {"status": "completed", "output": {"url": "https://example.com/image.png"}},
    ]
    calls = iter(responses)

    def status_fn():
        return next(calls)

    terminal, last = poll_until(
        status_fn=status_fn,
        is_done=lambda d: d.get("status") == "completed",
        interval=0.0,
        timeout=10.0,
    )

    assert terminal == "completed"
    assert last == {"status": "completed", "output": {"url": "https://example.com/image.png"}}


# ---------------------------------------------------------------------------
# Failed path
# ---------------------------------------------------------------------------


def test_failed_path_returns_failed_without_exception():
    """status_fn eventually returns failed; terminal == 'failed', no exception."""
    responses = [
        {"status": "pending"},
        {"status": "failed", "error": "model crashed"},
    ]
    calls = iter(responses)

    terminal, last = poll_until(
        status_fn=lambda: next(calls),
        is_done=lambda d: d.get("status") == "completed",
        is_failed=lambda d: d.get("status") == "failed",
        interval=0.0,
        timeout=10.0,
    )

    assert terminal == "failed"
    assert last["error"] == "model crashed"


# ---------------------------------------------------------------------------
# Blocked path
# ---------------------------------------------------------------------------


def test_blocked_path_returns_blocked():
    """status_fn returns nsfw; terminal == 'blocked'."""
    calls = iter([{"status": "nsfw", "reason": "flagged"}])

    terminal, last = poll_until(
        status_fn=lambda: next(calls),
        is_done=lambda d: d.get("status") == "completed",
        is_blocked=lambda d: d.get("status") == "nsfw",
        interval=0.0,
        timeout=10.0,
    )

    assert terminal == "blocked"
    assert last["reason"] == "flagged"


# ---------------------------------------------------------------------------
# Timeout path
# ---------------------------------------------------------------------------


def test_timeout_raises_poll_timeout():
    """status_fn always returns pending; raises PollTimeout after timeout expires."""
    with pytest.raises(PollTimeout):
        poll_until(
            status_fn=lambda: {"status": "pending"},
            is_done=lambda d: d.get("status") == "completed",
            interval=0.05,
            timeout=0.1,
        )


# ---------------------------------------------------------------------------
# Priority: is_done beats is_failed when both match
# ---------------------------------------------------------------------------


def test_is_done_priority_beats_is_failed():
    """If both is_done and is_failed match the same response, is_done wins."""
    always_match = {"status": "ambiguous"}

    terminal, last = poll_until(
        status_fn=lambda: always_match,
        is_done=lambda d: True,    # always true
        is_failed=lambda d: True,  # also always true
        interval=0.0,
        timeout=10.0,
    )

    assert terminal == "completed"
    assert last is always_match


# ---------------------------------------------------------------------------
# Priority: is_done beats is_blocked when both match
# ---------------------------------------------------------------------------


def test_is_done_priority_beats_is_blocked():
    """If both is_done and is_blocked match the same response, is_done wins."""
    always_match = {"status": "ambiguous"}

    terminal, last = poll_until(
        status_fn=lambda: always_match,
        is_done=lambda d: True,
        is_blocked=lambda d: True,
        interval=0.0,
        timeout=10.0,
    )

    assert terminal == "completed"


# ---------------------------------------------------------------------------
# Priority: is_blocked beats is_failed when both match
# ---------------------------------------------------------------------------


def test_is_blocked_priority_beats_is_failed():
    """If both is_blocked and is_failed match, is_blocked wins (blocked > failed)."""
    always_match = {"status": "ambiguous"}

    terminal, _ = poll_until(
        status_fn=lambda: always_match,
        is_done=lambda d: False,
        is_blocked=lambda d: True,
        is_failed=lambda d: True,
        interval=0.0,
        timeout=10.0,
    )

    assert terminal == "blocked"
