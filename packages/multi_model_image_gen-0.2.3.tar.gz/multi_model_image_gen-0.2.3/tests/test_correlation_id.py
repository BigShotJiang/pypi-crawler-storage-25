"""Tests for correlation_id propagation through generate().

Verifies that:
1. correlation_id is stamped onto result.raw["correlation_id"]
2. correlation_id appears in the emitted log record
3. correlation_id is forwarded through Router fallback paths
4. When correlation_id is None no corruption occurs
"""

from __future__ import annotations

import logging
import uuid


from image_gen.providers.result import GenerationResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_BASE_RESULT = GenerationResult(
    request_id="req-cid-001",
    status="completed",
    image_bytes=b"FAKEIMAGE",
    raw={},
)


def _fake_client(result: GenerationResult = _BASE_RESULT):
    class _C:
        def generate_image(self, **kwargs):
            return result

        def close(self):
            pass

    return _C()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_correlation_id_stamped_on_result(monkeypatch):
    """correlation_id is written into result.raw['correlation_id']."""
    import image_gen

    cid = "trace-abc-123"
    monkeypatch.setattr("image_gen.get_provider", lambda _: _fake_client())
    monkeypatch.setattr("image_gen.infer_provider", lambda _: "openai")

    result = image_gen.generate(
        "test prompt",
        model="openai:gpt-image-1",
        correlation_id=cid,
    )
    assert result.raw is not None
    assert result.raw.get("correlation_id") == cid


def test_correlation_id_in_log_record(monkeypatch, caplog):
    """The emitted log record carries correlation_id as a structured field."""
    import image_gen

    cid = str(uuid.uuid4())
    monkeypatch.setattr("image_gen.get_provider", lambda _: _fake_client())
    monkeypatch.setattr("image_gen.infer_provider", lambda _: "openai")

    with caplog.at_level(logging.INFO, logger="image_gen"):
        image_gen.generate(
            "test prompt",
            model="openai:gpt-image-1",
            correlation_id=cid,
        )

    req_records = [r for r in caplog.records if r.message == "image_gen.request"]
    assert req_records, "No image_gen.request record emitted"
    assert req_records[0].__dict__.get("correlation_id") == cid


def test_none_correlation_id_does_not_stamp_raw(monkeypatch):
    """When correlation_id=None, result.raw is not polluted."""
    import image_gen

    # Start with an empty raw dict
    result_stub = GenerationResult(
        request_id="req-none-cid",
        status="completed",
        image_bytes=b"BYTES",
        raw={},
    )
    monkeypatch.setattr("image_gen.get_provider", lambda _: _fake_client(result_stub))
    monkeypatch.setattr("image_gen.infer_provider", lambda _: "openai")

    result = image_gen.generate(
        "test prompt",
        model="openai:gpt-image-1",
        correlation_id=None,
    )
    # "correlation_id" key should NOT be added when value is None
    if result.raw:
        assert "correlation_id" not in result.raw


def test_correlation_id_forwarded_through_router(monkeypatch):
    """correlation_id reaches result.raw when routed through fallback."""
    import image_gen

    cid = "router-cid-xyz"

    class _FailClient:
        def generate_image(self, **kwargs):
            raise RuntimeError("primary fail")

        def close(self):
            pass

    call_order = []

    def _fake_get_provider(name: str):
        call_order.append(name)
        if name == "fal":
            return _FailClient()
        # fallback openai
        return _fake_client()

    monkeypatch.setattr("image_gen.get_provider", lambda _: _fake_client())
    monkeypatch.setattr("image_gen.infer_provider", lambda _: "fal")
    monkeypatch.setattr("image_gen.router.get_provider", _fake_get_provider)

    result = image_gen.generate(
        "test prompt",
        model="some-model",
        fallbacks=["openai"],
        correlation_id=cid,
    )
    assert result.raw is not None
    assert result.raw.get("correlation_id") == cid


def test_correlation_id_log_field_with_json_formatter(monkeypatch, caplog):
    """correlation_id appears as a top-level key in JSON-formatted log records."""
    import json
    import image_gen
    from image_gen.observability import JSONFormatter

    cid = "json-cid-456"
    monkeypatch.setattr("image_gen.get_provider", lambda _: _fake_client())
    monkeypatch.setattr("image_gen.infer_provider", lambda _: "openai")

    json_lines: list[str] = []
    formatter = JSONFormatter()
    handler = logging.StreamHandler()
    handler.emit = lambda record: json_lines.append(formatter.format(record))

    pkg_logger = logging.getLogger("image_gen")
    pkg_logger.addHandler(handler)
    pkg_logger.setLevel(logging.INFO)
    try:
        image_gen.generate(
            "test prompt",
            model="openai:gpt-image-1",
            correlation_id=cid,
        )
    finally:
        pkg_logger.removeHandler(handler)

    req_lines = [
        json.loads(line)
        for line in json_lines
        if json.loads(line).get("message") == "image_gen.request"
    ]
    assert req_lines, "No image_gen.request JSON line captured"
    assert req_lines[0].get("correlation_id") == cid
