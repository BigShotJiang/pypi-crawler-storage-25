"""Shorthand → provider-model-id resolution tests.

Each test monkeypatches the SDK entry point and asserts the resolved model ID
that reaches the SDK matches the expected provider model ID.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from image_gen.providers import fal_images, google_images, openai_images


# ---------- fal ----------


@pytest.mark.parametrize(
    "shorthand,expected",
    [
        ("flux", "fal-ai/flux/dev"),
        ("flux-schnell", "fal-ai/flux/schnell"),
        ("flux-pro", "fal-ai/flux-pro"),
        ("seedream", "fal-ai/bytedance/seedream/v4/text-to-image"),
        ("seedream-4.5", "fal-ai/bytedance/seedream/v4/text-to-image"),
        ("ideogram", "fal-ai/ideogram/v2"),
        ("recraft", "fal-ai/recraft-v3"),
        ("nb2-fal", "fal-ai/gemini-flash-image"),
        ("nb-pro-fal", "fal-ai/gemini-flash-image/pro"),
        ("imagen4-fal", "fal-ai/imagen4/preview"),
        ("fal-ai/custom/model", "fal-ai/custom/model"),  # passthrough
    ],
)
def test_fal_shorthand_resolves(shorthand, expected, monkeypatch):
    monkeypatch.setenv("FAL_KEY", "test-key")

    captured = {}

    def fake_subscribe(self, application, arguments, **kwargs):
        captured["model"] = application
        return {"images": [{"url": "https://example.com/img.png"}], "request_id": "r1"}

    monkeypatch.setattr(fal_images.fal_client.SyncClient, "subscribe", fake_subscribe)

    client = fal_images.FalImageClient()
    client.generate_image(prompt="hi", model=shorthand)
    assert captured["model"] == expected


# ---------- openai ----------


@pytest.mark.parametrize(
    "shorthand,expected",
    [
        ("gpt-image", "gpt-image-1"),
        ("gpt-image-1", "gpt-image-1"),
        ("openai/gpt-image", "gpt-image-1"),
    ],
)
def test_openai_shorthand_resolves(shorthand, expected, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    captured = {}
    fake_data = MagicMock()
    fake_data.b64_json = None
    fake_resp = MagicMock()
    fake_resp.data = [fake_data]

    def fake_generate(**kwargs):
        captured["model"] = kwargs["model"]
        return fake_resp

    with patch.object(openai_images, "OpenAI") as FakeClient:
        FakeClient.return_value.images.generate.side_effect = fake_generate
        client = openai_images.OpenAIImageClient()
        client.generate_image(prompt="hi", model=shorthand)

    assert captured["model"] == expected


# ---------- google ----------


@pytest.mark.parametrize(
    "shorthand,expected",
    [
        ("nb2", "gemini-2.5-flash-image"),
        ("nb-pro", "gemini-2.5-flash-image"),
        ("imagen4", "imagen-4.0-generate-001"),
        ("gemini-2.5-flash-image", "gemini-2.5-flash-image"),
    ],
)
def test_google_shorthand_resolves(shorthand, expected, monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "test-key")
    monkeypatch.delenv("GOOGLE_CLOUD_PROJECT", raising=False)

    captured = {}
    fake_resp = MagicMock()
    fake_resp.prompt_feedback = None
    fake_resp.candidates = []
    fake_resp.text = "failed"

    def fake_generate_content(**kwargs):
        captured["model"] = kwargs["model"]
        return fake_resp

    with patch.object(google_images.genai, "Client") as FakeClient:
        FakeClient.return_value.models.generate_content.side_effect = fake_generate_content
        client = google_images.GoogleImageClient()
        client.generate_image(prompt="hi", model=shorthand)

    assert captured["model"] == expected
