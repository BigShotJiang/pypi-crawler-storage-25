"""Tests for optional Prometheus metrics integration.

Skipped when prometheus_client is not installed.  Install with:

    pip install prometheus-client

or via the package extra:

    pip install "multi-model-image-gen[metrics]"
"""

from __future__ import annotations

import pytest

# Skip entire module when prometheus_client is absent.
prometheus_client = pytest.importorskip("prometheus_client", reason="prometheus_client not installed")

from image_gen.providers.result import GenerationResult  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fake_client(result: GenerationResult):
    class _C:
        def generate_image(self, **kwargs):
            return result

        def close(self):
            pass

    return _C()


def _get_counter_value(counter, **labels) -> float:
    """Extract a Counter's sample value by label set."""
    for metric in counter.collect():
        for sample in metric.samples:
            if all(sample.labels.get(k) == v for k, v in labels.items()):
                return sample.value
    return 0.0


def _get_histogram_count(histogram, **labels) -> float:
    """Return the _count sample value for a Histogram by label set."""
    for metric in histogram.collect():
        for sample in metric.samples:
            if sample.name.endswith("_count") and all(
                sample.labels.get(k) == v for k, v in labels.items()
            ):
                return sample.value
    return 0.0


# ---------------------------------------------------------------------------
# Import actual metric objects
# ---------------------------------------------------------------------------

from image_gen import metrics as _metrics  # noqa: E402


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestMetricsModule:
    def test_prometheus_available_flag(self):
        assert _metrics._PROMETHEUS_AVAILABLE is True

    def test_record_request_increments_counter(self):
        """record_request() increments image_gen_requests_total."""
        before = _get_counter_value(
            _metrics._requests_total,
            provider="test_p", model="test_m", status="completed",
        )
        _metrics.record_request(
            provider="test_p",
            model="test_m",
            status="completed",
            latency_ms=500.0,
        )
        after = _get_counter_value(
            _metrics._requests_total,
            provider="test_p", model="test_m", status="completed",
        )
        assert after == before + 1.0

    def test_record_request_observes_latency(self):
        """record_request() records a latency histogram observation."""
        before = _get_histogram_count(
            _metrics._latency_seconds,
            provider="test_lat", model="test_lat_m",
        )
        _metrics.record_request(
            provider="test_lat",
            model="test_lat_m",
            status="completed",
            latency_ms=2500.0,
        )
        after = _get_histogram_count(
            _metrics._latency_seconds,
            provider="test_lat", model="test_lat_m",
        )
        assert after == before + 1.0

    def test_record_request_adds_cost(self):
        """record_request() adds cost when cost_usd is provided."""
        before = _get_counter_value(
            _metrics._cost_usd_total,
            provider="test_cost", model="test_cost_m",
        )
        _metrics.record_request(
            provider="test_cost",
            model="test_cost_m",
            status="completed",
            latency_ms=1000.0,
            cost_usd=0.05,
        )
        after = _get_counter_value(
            _metrics._cost_usd_total,
            provider="test_cost", model="test_cost_m",
        )
        assert abs(after - (before + 0.05)) < 1e-9

    def test_record_request_skips_cost_when_none(self):
        """record_request() does not update cost counter when cost_usd=None."""
        before = _get_counter_value(
            _metrics._cost_usd_total,
            provider="test_no_cost", model="test_no_cost_m",
        )
        _metrics.record_request(
            provider="test_no_cost",
            model="test_no_cost_m",
            status="completed",
            latency_ms=1000.0,
            cost_usd=None,
        )
        after = _get_counter_value(
            _metrics._cost_usd_total,
            provider="test_no_cost", model="test_no_cost_m",
        )
        assert after == before  # unchanged

    def test_record_retry_increments_counter(self):
        """record_retry() increments image_gen_retries_total."""
        before = _get_counter_value(_metrics._retries_total, provider="retry_test_p")
        _metrics.record_retry("retry_test_p")
        after = _get_counter_value(_metrics._retries_total, provider="retry_test_p")
        assert after == before + 1.0

    def test_record_fallback_increments_counter(self):
        """record_fallback() increments image_gen_fallbacks_total."""
        before = _get_counter_value(
            _metrics._fallbacks_total, primary="fb_primary", fallback="fb_fallback"
        )
        _metrics.record_fallback(primary="fb_primary", fallback="fb_fallback")
        after = _get_counter_value(
            _metrics._fallbacks_total, primary="fb_primary", fallback="fb_fallback"
        )
        assert after == before + 1.0


class TestMetricsIntegration:
    """Verify that generate() drives metric helpers correctly."""

    def test_generate_increments_request_counter(self, monkeypatch):
        import image_gen

        fake_result = GenerationResult(
            request_id="metric-req-1",
            status="completed",
            image_bytes=b"BYTES",
            raw={},
        )
        monkeypatch.setattr(
            "image_gen.get_provider", lambda _: _fake_client(fake_result)
        )
        monkeypatch.setattr("image_gen.infer_provider", lambda _: "openai")

        before = _get_counter_value(
            _metrics._requests_total,
            provider="openai", model="gpt-image-1", status="completed",
        )
        image_gen.generate("test prompt", model="openai:gpt-image-1")
        after = _get_counter_value(
            _metrics._requests_total,
            provider="openai", model="gpt-image-1", status="completed",
        )
        assert after == before + 1.0

    def test_generate_observes_latency(self, monkeypatch):
        import image_gen

        fake_result = GenerationResult(
            request_id="metric-req-2",
            status="completed",
            image_bytes=b"BYTES",
            raw={},
        )
        monkeypatch.setattr(
            "image_gen.get_provider", lambda _: _fake_client(fake_result)
        )
        monkeypatch.setattr("image_gen.infer_provider", lambda _: "fal")

        before = _get_histogram_count(
            _metrics._latency_seconds, provider="fal", model="flux"
        )
        image_gen.generate("test prompt", model="fal:flux")
        after = _get_histogram_count(
            _metrics._latency_seconds, provider="fal", model="flux"
        )
        assert after == before + 1.0
