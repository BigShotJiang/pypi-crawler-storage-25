"""Blocked (NSFW / policy refusal) status mapping across providers."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from image_gen.providers import fal_images, google_images, higgsfield


def test_fal_nsfw_maps_to_blocked(monkeypatch):
    monkeypatch.setenv("FAL_KEY", "test-key")

    def fake_subscribe(self, application, arguments, **kwargs):
        return {
            "request_id": "r1",
            "has_nsfw_concepts": [True],
            "images": [{"url": "https://example.com/x.png"}],
        }

    monkeypatch.setattr(fal_images.fal_client.SyncClient, "subscribe", fake_subscribe)
    client = fal_images.FalImageClient()
    result = client.generate_image(prompt="x", model="flux")

    assert result.status == "blocked"
    assert result.raw["reason"] == "nsfw"


def test_google_block_reason_maps_to_blocked(monkeypatch):
    monkeypatch.setenv("GOOGLE_API_KEY", "test-key")
    monkeypatch.delenv("GOOGLE_CLOUD_PROJECT", raising=False)

    fake_resp = MagicMock()
    fake_resp.prompt_feedback.block_reason = "SAFETY"
    fake_resp.candidates = []

    with patch.object(google_images.genai, "Client") as FakeClient:
        FakeClient.return_value.models.generate_content.return_value = fake_resp
        client = google_images.GoogleImageClient()
        result = client.generate_image(prompt="x", model="nb2")

    assert result.status == "blocked"
    assert "SAFETY" in result.raw["reason"]


def test_higgsfield_nsfw_maps_to_blocked_not_raises(monkeypatch):
    monkeypatch.setenv("HIGGSFIELD_API_KEY", "k")
    monkeypatch.setenv("HIGGSFIELD_API_SECRET", "s")

    client = higgsfield.HiggsFieldClient()

    with patch.object(client, "submit", return_value="req-1"):
        with patch.object(
            client,
            "status",
            return_value={"status": "nsfw", "reason": "flagged"},
        ):
            result = client.generate_and_wait("some/model", {"prompt": "x"})

    assert result.status == "blocked"
    assert result.raw["reason"] == "nsfw"


def test_higgsfield_failed_does_not_raise(monkeypatch):
    monkeypatch.setenv("HIGGSFIELD_API_KEY", "k")
    monkeypatch.setenv("HIGGSFIELD_API_SECRET", "s")

    client = higgsfield.HiggsFieldClient()

    with patch.object(client, "submit", return_value="req-2"):
        with patch.object(client, "status", return_value={"status": "failed"}):
            result = client.generate_and_wait("some/model", {"prompt": "x"})

    assert result.status == "failed"
