"""Test that @retry_policy() retries transient failures and succeeds on the third attempt.

Strategy
--------
We do NOT need real SDK clients.  We patch ``get_provider`` to return a mock
provider whose ``generate_image`` internally applies ``@retry_policy()`` to an
inner function that fails twice with a retryable error, then succeeds.

This validates:
 1. The retry machinery counts attempts correctly.
 2. The first two transient exceptions are swallowed by tenacity.
 3. The result from the third (success) call is returned unchanged.
 4. Non-retryable exceptions (ValueError, NSFW) propagate immediately.
"""

from __future__ import annotations

import os
import time

import httpx
import pytest

from image_gen.providers._retry import is_retryable, retry_policy
from image_gen.providers.result import GenerationResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_GOOD_RESULT = GenerationResult(request_id="ok", status="completed", image_url="http://x")


def _make_failing_call(fail_count: int, exc_factory=None):
    """Return a function that fails ``fail_count`` times then returns ``_GOOD_RESULT``."""
    if exc_factory is None:

        def exc_factory():
            resp = httpx.Response(429, request=httpx.Request("GET", "http://test"))
            return httpx.HTTPStatusError("429", request=resp.request, response=resp)

    calls = {"n": 0}

    @retry_policy()
    def inner():
        calls["n"] += 1
        if calls["n"] <= fail_count:
            raise exc_factory()
        return _GOOD_RESULT

    return inner, calls


# ---------------------------------------------------------------------------
# Tests: is_retryable predicate
# ---------------------------------------------------------------------------


def test_is_retryable_timeout():
    assert is_retryable(httpx.TimeoutException("t"))


def test_is_retryable_connect_error():
    assert is_retryable(httpx.ConnectError("c"))


def test_is_retryable_read_error():
    assert is_retryable(httpx.ReadError("r"))


@pytest.mark.parametrize("code", [429, 500, 502, 503, 504])
def test_is_retryable_http_status(code):
    resp = httpx.Response(code, request=httpx.Request("GET", "http://t"))
    exc = httpx.HTTPStatusError(str(code), request=resp.request, response=resp)
    assert is_retryable(exc)


def test_is_not_retryable_404():
    resp = httpx.Response(404, request=httpx.Request("GET", "http://t"))
    exc = httpx.HTTPStatusError("404", request=resp.request, response=resp)
    assert not is_retryable(exc)


def test_is_not_retryable_value_error():
    assert not is_retryable(ValueError("bad input"))


def test_is_not_retryable_runtime_error():
    assert not is_retryable(RuntimeError("generic"))


def test_retryable_via_cause_chain():
    """An outer non-httpx exception whose __cause__ is a retryable httpx error."""
    resp = httpx.Response(503, request=httpx.Request("GET", "http://t"))
    root = httpx.HTTPStatusError("503", request=resp.request, response=resp)
    wrapper = RuntimeError("wrapped")
    wrapper.__cause__ = root
    assert is_retryable(wrapper)


# ---------------------------------------------------------------------------
# Tests: retry_policy() decorator
# ---------------------------------------------------------------------------


def test_retry_succeeds_on_third_attempt():
    """Two failures then success — total call count should be 3."""
    inner, calls = _make_failing_call(fail_count=2)
    result = inner()
    assert result is _GOOD_RESULT
    assert calls["n"] == 3


def test_retry_no_failures_single_call():
    inner, calls = _make_failing_call(fail_count=0)
    result = inner()
    assert result is _GOOD_RESULT
    assert calls["n"] == 1


def test_retry_exhausted_reraises(monkeypatch):
    """After max_attempts all fail, the last exception is re-raised."""
    monkeypatch.setenv("IMAGE_GEN_RETRY_ATTEMPTS", "2")
    monkeypatch.setenv("IMAGE_GEN_RETRY_MAX_WAIT", "0.1")

    calls = {"n": 0}

    @retry_policy()
    def always_fail():
        calls["n"] += 1
        resp = httpx.Response(503, request=httpx.Request("GET", "http://t"))
        raise httpx.HTTPStatusError("503", request=resp.request, response=resp)

    with pytest.raises(httpx.HTTPStatusError):
        always_fail()

    assert calls["n"] == 2  # 2 attempts total


def test_retry_does_not_retry_value_error():
    """ValueError is not a transient error — should propagate on first attempt."""
    calls = {"n": 0}

    @retry_policy()
    def config_error():
        calls["n"] += 1
        raise ValueError("bad config")

    with pytest.raises(ValueError):
        config_error()

    assert calls["n"] == 1


def test_retry_env_overrides(monkeypatch):
    """IMAGE_GEN_RETRY_ATTEMPTS env var controls the attempt count."""
    monkeypatch.setenv("IMAGE_GEN_RETRY_ATTEMPTS", "1")
    monkeypatch.setenv("IMAGE_GEN_RETRY_MAX_WAIT", "0.1")

    inner, calls = _make_failing_call(fail_count=1)
    # With only 1 attempt allowed, the first failure should be re-raised.
    with pytest.raises(httpx.HTTPStatusError):
        inner()

    assert calls["n"] == 1


# ---------------------------------------------------------------------------
# Timing test: two 429 failures, then success, under 20s
# ---------------------------------------------------------------------------


def test_retry_timing_two_429_then_success():
    """Two 429s then success should complete in well under 20 seconds.

    Tenacity exponential backoff: min=1, multiplier=1 → waits ~1s + ~2s + jitter
    ≈ 3-4 seconds total.  We allow a generous 20s budget.
    """
    # Force small waits to keep the test fast in CI.
    original_attempts = os.environ.get("IMAGE_GEN_RETRY_ATTEMPTS")
    original_wait = os.environ.get("IMAGE_GEN_RETRY_MAX_WAIT")
    os.environ["IMAGE_GEN_RETRY_ATTEMPTS"] = "3"
    os.environ["IMAGE_GEN_RETRY_MAX_WAIT"] = "3"  # cap at 3s per wait

    try:
        inner, calls = _make_failing_call(fail_count=2)
        t0 = time.monotonic()
        result = inner()
        elapsed = time.monotonic() - t0
    finally:
        if original_attempts is None:
            os.environ.pop("IMAGE_GEN_RETRY_ATTEMPTS", None)
        else:
            os.environ["IMAGE_GEN_RETRY_ATTEMPTS"] = original_attempts
        if original_wait is None:
            os.environ.pop("IMAGE_GEN_RETRY_MAX_WAIT", None)
        else:
            os.environ["IMAGE_GEN_RETRY_MAX_WAIT"] = original_wait

    assert result is _GOOD_RESULT
    assert calls["n"] == 3
    assert elapsed < 20, f"Expected < 20s, got {elapsed:.1f}s"
