"""Tests for runtime provider registration (Phase 7).

Covers:
- register_provider() happy path
- generate(model="stub:any") dispatches to stub.generate_image
- Duplicate-name rejection (without override=True)
- override=True replaces silently
- Invalid name validation (uppercase, spaces, underscores, leading hyphen)
"""

from __future__ import annotations

import pytest

from image_gen import generate, register_provider
from image_gen.providers import _PROVIDER_REGISTRY, _discover_plugins, get_provider
from image_gen.providers.result import GenerationResult


# ---------------------------------------------------------------------------
# Shared stub provider
# ---------------------------------------------------------------------------


class StubProvider:
    """Minimal ImageProvider for testing."""

    def __init__(self) -> None:
        self.calls: list[dict] = []

    def generate_image(self, prompt, model="stub-model", aspect_ratio="9:16", resolution="720p", **kw):
        call = dict(prompt=prompt, model=model, aspect_ratio=aspect_ratio, **kw)
        self.calls.append(call)
        return GenerationResult(request_id="stub-req-1", status="completed", image_url="http://stub/img.png")

    async def generate_image_async(self, prompt, model="stub-model", aspect_ratio="9:16", resolution="720p", **kw):
        return self.generate_image(prompt, model=model, aspect_ratio=aspect_ratio, resolution=resolution, **kw)

    def download(self, url, output_path):
        from pathlib import Path
        return Path(output_path)

    async def download_async(self, url, output_path):
        return self.download(url, output_path)

    def close(self) -> None:
        pass

    async def aclose(self) -> None:
        pass


_stub_instance: StubProvider | None = None


def _stub_factory() -> StubProvider:
    global _stub_instance
    _stub_instance = StubProvider()
    return _stub_instance


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clean_registry():
    """Remove any test-registered providers and clear plugin cache after each test."""
    original_keys = set(_PROVIDER_REGISTRY.keys())
    _discover_plugins.cache_clear()
    yield
    # Remove any keys added during the test.
    for key in list(_PROVIDER_REGISTRY.keys()):
        if key not in original_keys:
            del _PROVIDER_REGISTRY[key]
    _discover_plugins.cache_clear()


# ---------------------------------------------------------------------------
# Happy-path registration
# ---------------------------------------------------------------------------


def test_register_provider_and_get():
    """register_provider followed by get_provider returns a StubProvider."""
    register_provider("stub", _stub_factory)
    provider = get_provider("stub")
    assert isinstance(provider, StubProvider)


def test_generate_dispatches_to_registered_provider():
    """generate(model="stub:any-model") calls stub.generate_image."""
    global _stub_instance
    _stub_instance = None

    register_provider("stub", _stub_factory)
    result = generate("test prompt", model="stub:any-model")

    assert result.status == "completed"
    assert _stub_instance is not None, "factory was never called"
    assert len(_stub_instance.calls) == 1
    call = _stub_instance.calls[0]
    assert call["prompt"] == "test prompt"
    assert call["model"] == "any-model"


def test_generate_with_bare_registered_provider():
    """get_provider works for a registered provider used directly."""
    register_provider("stub2", _stub_factory)
    provider = get_provider("stub2")
    result = provider.generate_image("hello", model="m1")
    assert result.status == "completed"


# ---------------------------------------------------------------------------
# Duplicate-name rejection
# ---------------------------------------------------------------------------


def test_duplicate_name_raises_without_override():
    """Registering the same name twice without override=True raises ValueError."""
    register_provider("stub", _stub_factory)
    with pytest.raises(ValueError, match="already registered"):
        register_provider("stub", _stub_factory)


def test_duplicate_name_allowed_with_override():
    """override=True silently replaces the existing factory."""

    class AltProvider(StubProvider):
        pass

    def _alt_factory() -> AltProvider:
        return AltProvider()

    register_provider("stub", _stub_factory)
    register_provider("stub", _alt_factory, override=True)  # should not raise

    provider = get_provider("stub")
    assert isinstance(provider, AltProvider)


# ---------------------------------------------------------------------------
# Invalid name validation
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "bad_name",
    [
        "MyProvider",        # uppercase letters
        "my provider",       # space
        "my_provider",       # underscore
        "-myprovider",       # leading hyphen
        "",                  # empty string
        "MY-PROVIDER",       # all-caps with hyphen
        "provider name",     # embedded space
    ],
)
def test_invalid_names_rejected(bad_name: str):
    """register_provider rejects names that don't match the allowed pattern."""
    with pytest.raises(ValueError, match="[Ii]nvalid provider name|Invalid"):
        register_provider(bad_name, _stub_factory)


@pytest.mark.parametrize(
    "good_name",
    [
        "myprovider",
        "my-provider",
        "provider-v2",
        "stability-ai",
        "runway",
        "p",
        "a1b2c3",
    ],
)
def test_valid_names_accepted(good_name: str):
    """register_provider accepts all compliant names."""
    register_provider(good_name, _stub_factory)
    assert good_name in _PROVIDER_REGISTRY


# ---------------------------------------------------------------------------
# Unknown provider raises cleanly
# ---------------------------------------------------------------------------


def test_unknown_provider_in_generate_raises():
    """generate("bogus:model") raises ValueError mentioning the bad name."""
    with pytest.raises(ValueError, match="bogus"):
        generate("hello", model="bogus:model")


def test_unknown_provider_get_raises():
    """get_provider("does-not-exist") raises ValueError."""
    with pytest.raises(ValueError, match="does-not-exist"):
        get_provider("does-not-exist")
