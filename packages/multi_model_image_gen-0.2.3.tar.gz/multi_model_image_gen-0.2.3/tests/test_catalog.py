"""Catalog integrity tests.

Verifies that:
- catalog.yaml parses without error
- every entry has all required fields with correct types
- every provider named in the catalog exists in the get_provider factory
- lookups work by both shorthand and by model_id
"""

from __future__ import annotations

import pytest

from image_gen.providers.catalog import ModelEntry, load_catalog, resolve

# Ensure a fresh catalog load for each test run (lru_cache is process-scoped).
load_catalog.cache_clear()


_VALID_PROVIDERS = {"openai", "google", "google-studio", "fal", "higgsfield"}


@pytest.fixture(autouse=True)
def clear_cache():
    """Clear the lru_cache before each test so yaml is re-parsed."""
    load_catalog.cache_clear()
    yield
    load_catalog.cache_clear()


def test_catalog_loads():
    catalog = load_catalog()
    assert len(catalog) > 0, "Catalog must have at least one entry"


def test_every_entry_is_model_entry():
    catalog = load_catalog()
    for key, entry in catalog.items():
        assert isinstance(entry, ModelEntry), f"Key {key!r} is not a ModelEntry"


def test_every_entry_has_required_fields():
    catalog = load_catalog()
    seen_shorthands = set()
    for key, entry in catalog.items():
        # Required string fields
        assert isinstance(entry.shorthand, str) and entry.shorthand, (
            f"Entry {key!r}: shorthand must be a non-empty string"
        )
        assert isinstance(entry.provider, str) and entry.provider, (
            f"Entry {key!r}: provider must be a non-empty string"
        )
        assert isinstance(entry.model_id, str) and entry.model_id, (
            f"Entry {key!r}: model_id must be a non-empty string"
        )
        # Capability sets
        assert isinstance(entry.aspect_ratios, frozenset), (
            f"Entry {key!r}: aspect_ratios must be a frozenset"
        )
        assert isinstance(entry.resolutions, frozenset), (
            f"Entry {key!r}: resolutions must be a frozenset"
        )
        # Boolean flags
        assert isinstance(entry.seed, bool), f"Entry {key!r}: seed must be bool"
        assert isinstance(entry.negative_prompt, bool), (
            f"Entry {key!r}: negative_prompt must be bool"
        )
        # cost_usd is optional
        assert entry.cost_usd is None or isinstance(entry.cost_usd, (int, float)), (
            f"Entry {key!r}: cost_usd must be float or None"
        )
        seen_shorthands.add(entry.shorthand)

    assert len(seen_shorthands) > 0


def test_every_provider_in_catalog_exists_in_factory():
    """Every provider name in the catalog must be handled by get_provider."""

    catalog = load_catalog()
    for key, entry in catalog.items():
        assert entry.provider in _VALID_PROVIDERS, (
            f"Entry {entry.shorthand!r} references unknown provider {entry.provider!r}"
        )


def test_lookup_by_shorthand():
    """resolve() must find entries by their shorthand."""
    # spot-check a few known shorthands
    for shorthand, expected_model_id in [
        ("flux", "fal-ai/flux/dev"),
        ("gpt-image", "gpt-image-1"),
        ("nb2", "gemini-3.1-flash-image-preview"),
        ("imagen4", "imagen-4.0-generate-001"),
    ]:
        entry = resolve(shorthand)
        assert entry is not None, f"shorthand {shorthand!r} not found in catalog"
        assert entry.model_id == expected_model_id, (
            f"shorthand {shorthand!r}: expected model_id={expected_model_id!r}, "
            f"got {entry.model_id!r}"
        )


def test_lookup_by_model_id():
    """resolve() must also find entries by their full model_id."""
    for model_id, expected_shorthand in [
        ("fal-ai/flux/dev", "flux"),
        ("gpt-image-1", "gpt-image"),
        ("gemini-2.5-flash-image", "nano-banana"),  # original Nano Banana shorthand
        ("imagen-4.0-generate-001", "imagen4"),
    ]:
        entry = resolve(model_id)
        assert entry is not None, f"model_id {model_id!r} not found in catalog"
        assert entry.shorthand == expected_shorthand, (
            f"model_id {model_id!r}: expected shorthand={expected_shorthand!r}, "
            f"got {entry.shorthand!r}"
        )


def test_resolve_returns_none_for_unknown():
    """resolve() must return None for IDs not present in the catalog."""
    assert resolve("not-a-real-model") is None
    assert resolve("") is None


def test_catalog_entries_are_frozen():
    """ModelEntry instances must be immutable (frozen=True)."""
    entry = resolve("flux")
    assert entry is not None
    with pytest.raises((AttributeError, TypeError)):
        entry.shorthand = "mutated"  # type: ignore[misc]
