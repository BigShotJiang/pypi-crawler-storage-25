"""Tests for Phase 3 provider:model addressing syntax."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

import image_gen


# ---------------------------------------------------------------------------
# Parametrized cases: (model_string, expected_provider, expected_model_id)
# ---------------------------------------------------------------------------
_CASES = [
    # Explicit provider:model syntax
    ("fal:flux/dev", "fal", "flux/dev"),
    ("fal:flux", "fal", "flux"),
    ("openai:gpt-image-1", "openai", "gpt-image-1"),
    ("google:imagen4", "google", "imagen4"),
    ("higgsfield:higgsfield-ai/soul/standard", "higgsfield", "higgsfield-ai/soul/standard"),
    # Bare shorthands routed via infer_provider; catalog resolves to real model_id
    ("flux", "fal", "fal-ai/flux/dev"),
    ("higgsfield-ai/soul/standard", "higgsfield", "higgsfield-ai/soul/standard"),
]


@pytest.mark.parametrize("model_str,expected_provider,expected_model_id", _CASES)
def test_addressing_routes_correctly(
    model_str: str, expected_provider: str, expected_model_id: str
) -> None:
    """generate() must call get_provider with the correct provider name and forward
    the correct model ID to the client's generate_image method."""
    fake_result = image_gen.GenerationResult(
        request_id="test-id",
        status="completed",
        image_url="https://example.com/img.png",
    )

    mock_client = MagicMock()
    mock_client.generate_image.return_value = fake_result

    with patch("image_gen.get_provider", return_value=mock_client) as mock_get_provider:
        result = image_gen.generate(prompt="test prompt", model=model_str)

    # Verify provider selection
    mock_get_provider.assert_called_once_with(expected_provider)

    # Verify the model ID forwarded to the client is the portion after the colon
    # (or the full string for bare shorthands)
    call_kwargs = mock_client.generate_image.call_args
    assert call_kwargs.kwargs.get("model") == expected_model_id or (
        call_kwargs.args[1] == expected_model_id if len(call_kwargs.args) > 1 else False
    ), (
        f"Expected model_id={expected_model_id!r} forwarded to client, "
        f"got call: {call_kwargs}"
    )

    assert result.status == "completed"
    mock_client.close.assert_called_once()


def test_invalid_provider_prefix_raises() -> None:
    """A 'provider:model' string with an unknown provider must raise ValueError."""
    with pytest.raises(ValueError, match="nonexistent"):
        image_gen.generate(prompt="test", model="nonexistent:foo")


def test_invalid_provider_error_message_lists_valid_providers() -> None:
    """The ValueError message must name the valid providers."""
    with pytest.raises(ValueError, match="openai|google|fal|higgsfield"):
        image_gen.generate(prompt="test", model="bogus:something")
