"""Tests for Phase 8 async-first API.

Covers:
- Concurrency: gather of 5 async calls completes in < 0.3s (not 0.5s serial).
- Async Higgsfield poll: mock status_fn returning pending twice then completed.
- Async Router fallback: primary raises, fallback returns result.
- Regression: existing sync tests still pass (import guard check).
- Cross-context safety: sync generate_image() from inside async raises clearly.
"""

from __future__ import annotations

import asyncio
import time
from pathlib import Path
from unittest.mock import patch

import pytest

from image_gen.providers._poll import PollTimeout, poll_until_async
from image_gen.providers.result import GenerationResult
from image_gen.router import FallbackExhausted, Router


# ---------------------------------------------------------------------------
# Shared mock providers
# ---------------------------------------------------------------------------


class _AsyncSlowProvider:
    """Mock async provider that sleeps 0.1s per call (simulates network latency)."""

    _RESULT = GenerationResult(request_id="async-ok", status="completed")

    async def generate_image_async(self, prompt, model="m", aspect_ratio="9:16", resolution="720p", **kw):
        await asyncio.sleep(0.1)
        return self._RESULT

    def generate_image(self, prompt, model="m", aspect_ratio="9:16", resolution="720p", **kw):
        return self._RESULT

    def download(self, url, output_path):
        return Path(output_path)

    async def download_async(self, url, output_path):
        return Path(output_path)

    def close(self) -> None:
        pass

    async def aclose(self) -> None:
        pass


class _AsyncFailProvider:
    """Mock async provider that always raises."""

    async def generate_image_async(self, prompt, **kw):
        raise RuntimeError("async provider exploded")

    def generate_image(self, prompt, **kw):
        raise RuntimeError("sync provider exploded")

    def download(self, url, output_path):
        return Path(output_path)

    async def download_async(self, url, output_path):
        return Path(output_path)

    def close(self) -> None:
        pass

    async def aclose(self) -> None:
        pass


class _AsyncSucceedProvider:
    _RESULT = GenerationResult(request_id="fallback-async-ok", status="completed")

    async def generate_image_async(self, prompt, **kw):
        return self._RESULT

    def generate_image(self, prompt, **kw):
        return self._RESULT

    def download(self, url, output_path):
        return Path(output_path)

    async def download_async(self, url, output_path):
        return Path(output_path)

    def close(self) -> None:
        pass

    async def aclose(self) -> None:
        pass


# ---------------------------------------------------------------------------
# Concurrency test
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_concurrent_async_calls_faster_than_serial():
    """Five concurrent async calls should complete in < 0.3s, not 0.5s (serial).

    Each call sleeps 0.1s.  Running 5 serially would take 0.5s; concurrent via
    asyncio.gather should take ~0.1s (+ minimal overhead).
    """
    provider = _AsyncSlowProvider()

    async def _one_call():
        return await provider.generate_image_async("test prompt")

    start = time.monotonic()
    results = await asyncio.gather(*[_one_call() for _ in range(5)])
    elapsed = time.monotonic() - start

    assert all(r.status == "completed" for r in results), "All calls should succeed"
    assert elapsed < 0.3, (
        f"Expected concurrent execution < 0.3s, got {elapsed:.3f}s. "
        "This indicates serial blocking instead of concurrent execution."
    )


# ---------------------------------------------------------------------------
# Async Higgsfield poll
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_poll_until_async_returns_completed_after_pending():
    """poll_until_async should call status_fn 3 times: pending, pending, completed."""
    call_count = 0

    async def _status_fn():
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            return {"status": "pending"}
        return {"status": "completed", "output": {"url": "https://example.com/img.png"}}

    terminal, data = await poll_until_async(
        status_fn=_status_fn,
        is_done=lambda d: d.get("status") == "completed",
        is_failed=lambda d: d.get("status") == "failed",
        is_blocked=lambda d: d.get("status") == "nsfw",
        interval=0.001,  # Very short interval for test speed.
        timeout=5.0,
    )

    assert terminal == "completed"
    assert data["status"] == "completed"
    assert call_count == 3


@pytest.mark.asyncio
async def test_poll_until_async_returns_blocked():
    """poll_until_async detects blocked status."""

    async def _status_fn():
        return {"status": "nsfw"}

    terminal, data = await poll_until_async(
        status_fn=_status_fn,
        is_done=lambda d: d.get("status") == "completed",
        is_blocked=lambda d: d.get("status") == "nsfw",
        interval=0.001,
        timeout=5.0,
    )

    assert terminal == "blocked"


@pytest.mark.asyncio
async def test_poll_until_async_returns_failed():
    """poll_until_async detects failed status."""

    async def _status_fn():
        return {"status": "failed"}

    terminal, data = await poll_until_async(
        status_fn=_status_fn,
        is_done=lambda d: d.get("status") == "completed",
        is_failed=lambda d: d.get("status") == "failed",
        interval=0.001,
        timeout=5.0,
    )

    assert terminal == "failed"


@pytest.mark.asyncio
async def test_poll_until_async_timeout():
    """poll_until_async raises PollTimeout when deadline exceeded."""

    async def _status_fn():
        return {"status": "pending"}

    with pytest.raises(PollTimeout):
        await poll_until_async(
            status_fn=_status_fn,
            is_done=lambda d: False,
            interval=0.001,
            timeout=0.01,
        )


# ---------------------------------------------------------------------------
# Async router fallback
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_router_fallback_primary_raises(monkeypatch):
    """Async router: primary raises → fallback returns result via generate_async."""
    fail_provider = _AsyncFailProvider()
    succeed_provider = _AsyncSucceedProvider()

    call_order = []

    def _fake_get_provider(name: str):
        call_order.append(name)
        if name == "primary":
            return fail_provider
        if name == "fallback":
            return succeed_provider
        raise ValueError(f"unexpected: {name}")

    monkeypatch.setattr("image_gen.router.get_provider", _fake_get_provider)

    router = Router(primary="primary", fallbacks=["fallback"])
    result = await router.generate_async("test prompt", model="some-model")

    assert result.status == "completed"
    assert result.request_id == "fallback-async-ok"
    assert call_order == ["primary", "fallback"]


@pytest.mark.asyncio
async def test_async_router_primary_succeeds_no_fallback(monkeypatch):
    """Async router: primary succeeds → fallback never called."""
    succeed_provider = _AsyncSucceedProvider()
    fail_provider = _AsyncFailProvider()

    call_order = []

    def _fake_get_provider(name: str):
        call_order.append(name)
        if name == "primary":
            return succeed_provider
        if name == "fallback":
            return fail_provider
        raise ValueError(f"unexpected: {name}")

    monkeypatch.setattr("image_gen.router.get_provider", _fake_get_provider)

    router = Router(primary="primary", fallbacks=["fallback"])
    result = await router.generate_async("test prompt")

    assert result.status == "completed"
    assert call_order == ["primary"]  # fallback never touched


@pytest.mark.asyncio
async def test_async_router_all_fail_raises_fallback_exhausted(monkeypatch):
    """Async router: all providers fail → FallbackExhausted raised."""

    def _fake_get_provider(name: str):
        return _AsyncFailProvider()

    monkeypatch.setattr("image_gen.router.get_provider", _fake_get_provider)

    router = Router(primary="p1", fallbacks=["p2"])
    with pytest.raises(FallbackExhausted) as exc_info:
        await router.generate_async("test prompt")

    assert len(exc_info.value.errors) == 2


# ---------------------------------------------------------------------------
# Cross-context safety
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_sync_generate_image_raises_from_async_context_fal(monkeypatch):
    """FalImageClient.generate_image() raises RuntimeError when called from async."""
    monkeypatch.setenv("FAL_KEY", "test-key")
    from image_gen.providers.fal_images import FalImageClient

    client = FalImageClient()
    try:
        with pytest.raises(RuntimeError, match="generate_image_async"):
            client.generate_image("test prompt")
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_sync_generate_image_raises_from_async_context_openai(monkeypatch):
    """OpenAIImageClient.generate_image() raises RuntimeError when called from async."""
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    from image_gen.providers.openai_images import OpenAIImageClient

    client = OpenAIImageClient()
    try:
        with pytest.raises(RuntimeError, match="generate_image_async"):
            client.generate_image("test prompt")
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_sync_generate_image_raises_from_async_context_google(monkeypatch):
    """GoogleImageClient.generate_image() raises RuntimeError when called from async."""
    monkeypatch.setenv("GOOGLE_API_KEY", "test-key")
    monkeypatch.delenv("GOOGLE_CLOUD_PROJECT", raising=False)
    from image_gen.providers.google_images import GoogleImageClient

    client = GoogleImageClient()
    try:
        with pytest.raises(RuntimeError, match="generate_image_async"):
            client.generate_image("test prompt")
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_sync_generate_image_raises_from_async_context_higgsfield(monkeypatch):
    """HiggsFieldClient.generate_image() raises RuntimeError when called from async."""
    monkeypatch.setenv("HIGGSFIELD_API_KEY", "test-key")
    monkeypatch.setenv("HIGGSFIELD_API_SECRET", "test-secret")
    from image_gen.providers.higgsfield import HiggsFieldClient

    client = HiggsFieldClient()
    try:
        with pytest.raises(RuntimeError, match="generate_image_async"):
            client.generate_image("test prompt")
    finally:
        await client.aclose()


# ---------------------------------------------------------------------------
# generate_async top-level function
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_generate_async_top_level(monkeypatch):
    """image_gen.generate_async dispatches to provider's generate_image_async."""
    from image_gen import generate_async
    from image_gen.providers import _PROVIDER_REGISTRY

    provider = _AsyncSucceedProvider()

    def _factory():
        return provider

    # Temporarily register a stub provider.
    original = _PROVIDER_REGISTRY.get("fal")
    _PROVIDER_REGISTRY["fal"] = _factory
    try:
        result = await generate_async("test prompt", model="fal:any-model")
        assert result.status == "completed"
    finally:
        if original is not None:
            _PROVIDER_REGISTRY["fal"] = original
        else:
            del _PROVIDER_REGISTRY["fal"]


@pytest.mark.asyncio
async def test_generate_async_unknown_provider_raises():
    """generate_async raises ValueError for unknown provider prefix."""
    from image_gen import generate_async

    with pytest.raises(ValueError, match="bogus"):
        await generate_async("test prompt", model="bogus:model")


# ---------------------------------------------------------------------------
# Regression: sync still works from non-async context
# ---------------------------------------------------------------------------


def test_sync_generate_image_works_outside_loop(monkeypatch):
    """Sync generate_image works correctly when no event loop is running."""
    monkeypatch.setenv("FAL_KEY", "test-key")
    from image_gen.providers.fal_images import FalImageClient

    def fake_subscribe(self, application, arguments, **kwargs):
        return {"images": [{"url": "https://example.com/img.png"}], "request_id": "r1"}

    import fal_client
    monkeypatch.setattr(fal_client.SyncClient, "subscribe", fake_subscribe)

    client = FalImageClient()
    result = client.generate_image(prompt="hi", model="flux")
    assert result.status == "completed"
    client.close()


# ---------------------------------------------------------------------------
# Async Higgsfield full flow (mocked)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_higgsfield_generate_image_async(monkeypatch):
    """HiggsFieldClient.generate_image_async polls and returns completed result."""
    monkeypatch.setenv("HIGGSFIELD_API_KEY", "k")
    monkeypatch.setenv("HIGGSFIELD_API_SECRET", "s")

    from image_gen.providers.higgsfield import HiggsFieldClient

    client = HiggsFieldClient()

    poll_count = 0

    async def _fake_submit_async(model_id, payload):
        return "req-async-1"

    async def _fake_status_async(request_id):
        nonlocal poll_count
        poll_count += 1
        if poll_count < 3:
            return {"status": "pending"}
        return {"status": "completed", "output": {"image_url": "https://example.com/x.png"}}

    with patch.object(client, "submit_async", side_effect=_fake_submit_async), \
         patch.object(client, "status_async", side_effect=_fake_status_async):
        result = await client.generate_image_async(
            "test prompt",
            model="higgsfield-ai/soul/standard",
            poll_interval=0.001,
            max_wait=5.0,
        )

    assert result.status == "completed"
    assert result.request_id == "req-async-1"
    assert result.image_url == "https://example.com/x.png"
    assert poll_count == 3

    await client.aclose()
