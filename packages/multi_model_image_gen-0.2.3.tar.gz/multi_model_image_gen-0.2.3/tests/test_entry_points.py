"""Tests for entry-point discovery (Phase 7).

Verifies that providers installed via ``image_gen.providers`` entry points are
discoverable by :func:`get_provider` without being manually registered.

Strategy: monkeypatch ``importlib.metadata.entry_points`` to return a fake
entry point, clear the ``_discover_plugins`` lru_cache, and assert that
``get_provider("fake-ep-provider")`` instantiates via the fake entry point.
"""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest

from image_gen.providers import _PROVIDER_REGISTRY, _discover_plugins, get_provider
from image_gen.providers.result import GenerationResult


# ---------------------------------------------------------------------------
# Stub provider loaded via fake entry point
# ---------------------------------------------------------------------------


class FakeEpProvider:
    """Stub provider loaded via a fake entry point."""

    def generate_image(
        self, prompt: str, model: str = "ep-model", aspect_ratio: str = "9:16",
        resolution: str = "720p", **kw: Any,
    ) -> GenerationResult:
        return GenerationResult(request_id="ep-req", status="completed", image_url="http://ep/img.png")

    def download(self, url: str, output_path: Any) -> Any:
        return output_path

    def close(self) -> None:
        pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_fake_entry_point(name: str, cls: type) -> SimpleNamespace:
    """Construct a minimal entry-point-like object."""
    return SimpleNamespace(name=name, load=lambda: cls)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clean_registry_and_cache():
    """Restore registry and clear plugin cache before and after each test."""
    original_keys = set(_PROVIDER_REGISTRY.keys())
    _discover_plugins.cache_clear()
    yield
    for key in list(_PROVIDER_REGISTRY.keys()):
        if key not in original_keys:
            del _PROVIDER_REGISTRY[key]
    _discover_plugins.cache_clear()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_get_provider_via_entry_point(monkeypatch: pytest.MonkeyPatch) -> None:
    """get_provider discovers a provider registered only via entry point."""
    fake_ep = _make_fake_entry_point("fake-ep-provider", FakeEpProvider)

    # Patch importlib.metadata.entry_points inside the providers module.
    import image_gen.providers as providers_mod

    def _fake_entry_points(*, group: str):
        if group == "image_gen.providers":
            return [fake_ep]
        return []

    monkeypatch.setattr(
        providers_mod,
        # We need to patch the reference used inside _discover_plugins.
        # _discover_plugins imports entry_points from importlib.metadata at
        # call time; we patch the importlib.metadata module directly.
        "__builtins__",  # sentinel — real patch is below
        providers_mod.__builtins__,  # no-op
    )

    # Patch the actual importlib.metadata.entry_points used by _discover_plugins.
    import importlib.metadata as _meta

    monkeypatch.setattr(_meta, "entry_points", _fake_entry_points)

    # Mandatory: clear the lru_cache so our monkeypatched function is called.
    _discover_plugins.cache_clear()

    # "fake-ep-provider" is NOT in _PROVIDER_REGISTRY (built-ins only).
    assert "fake-ep-provider" not in _PROVIDER_REGISTRY

    provider = get_provider("fake-ep-provider")
    assert isinstance(provider, FakeEpProvider)


def test_entry_point_provider_generate(monkeypatch: pytest.MonkeyPatch) -> None:
    """A provider loaded via entry point can generate images."""
    fake_ep = _make_fake_entry_point("fake-ep-provider", FakeEpProvider)

    import importlib.metadata as _meta

    def _fake_entry_points(*, group: str):
        return [fake_ep] if group == "image_gen.providers" else []

    monkeypatch.setattr(_meta, "entry_points", _fake_entry_points)
    _discover_plugins.cache_clear()

    provider = get_provider("fake-ep-provider")
    result = provider.generate_image("hello", model="ep-model")
    assert result.status == "completed"
    assert result.image_url == "http://ep/img.png"


def test_entry_point_not_in_registry_before_discovery() -> None:
    """Built-in registry does not contain the fake provider name."""
    assert "fake-ep-provider" not in _PROVIDER_REGISTRY


def test_multiple_entry_points(monkeypatch: pytest.MonkeyPatch) -> None:
    """Multiple entry points from the same group are all discoverable."""

    class ProviderA(FakeEpProvider):
        pass

    class ProviderB(FakeEpProvider):
        pass

    eps = [
        _make_fake_entry_point("ep-a", ProviderA),
        _make_fake_entry_point("ep-b", ProviderB),
    ]

    import importlib.metadata as _meta

    monkeypatch.setattr(_meta, "entry_points", lambda *, group: eps if group == "image_gen.providers" else [])
    _discover_plugins.cache_clear()

    assert isinstance(get_provider("ep-a"), ProviderA)
    assert isinstance(get_provider("ep-b"), ProviderB)


def test_cache_is_cleared_on_register_provider() -> None:
    """register_provider invalidates the _discover_plugins lru_cache."""
    from image_gen.providers import register_provider
    from image_gen.providers.result import GenerationResult

    class SomeProvider:
        def generate_image(self, prompt, model="m", aspect_ratio="9:16", resolution="720p", **kw):
            return GenerationResult(request_id="x", status="completed")

        def download(self, url, path):
            return path

        def close(self):
            pass

    # Populate the cache with a first call.
    _ = _discover_plugins()
    cache_info_before = _discover_plugins.cache_info()
    assert cache_info_before.currsize == 1

    # register_provider should clear the cache.
    register_provider("some-provider", SomeProvider)
    cache_info_after = _discover_plugins.cache_info()
    assert cache_info_after.currsize == 0, (
        "register_provider must call _discover_plugins.cache_clear() "
        "so subsequent lookups re-scan entry points"
    )
