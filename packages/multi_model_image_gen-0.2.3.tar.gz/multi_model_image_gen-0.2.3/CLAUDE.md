# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Install editable (from repo root; creates the `image-gen` CLI)
pip install -e .

# Run the full test suite (160 tests, ~16s)
PYTHONPATH=src python -m pytest tests/ -q

# Run a single test
PYTHONPATH=src python -m pytest tests/test_retry.py::test_retry_succeeds_on_third_attempt -q

# Run only one phase's tests (examples)
PYTHONPATH=src python -m pytest tests/test_catalog.py tests/test_capability_validation.py -q     # Phase 2
PYTHONPATH=src python -m pytest tests/test_retry.py tests/test_fallback.py tests/test_all_fail.py -q  # Phase 4
PYTHONPATH=src python -m pytest tests/test_async.py -q                                             # Phase 8

# With optional metrics tests (Prometheus)
pip install prometheus-client
PYTHONPATH=src python -m pytest tests/test_metrics.py -q

# CLI smoke
image-gen -p "a neon fox" -m flux -o /tmp/fox.png
image-gen -p "…" -m "openai:gpt-image-1.5" --aspect 16:9 --resolution 1080p -o wide.png

# Concurrency benchmark (mocked, no API keys needed)
python examples/benchmark_concurrent.py
```

Tests do not require API keys — every SDK call is mocked.

## Architecture

Single function (`generate` / `generate_async`) that dispatches to one of four image-gen backends, wraps SDK calls with retry, supports fallback chains, polls async-task providers, and emits structured logs + metrics per request. The adapter pattern is modeled on LiteLLM.

### The hot path (read this first)

`src/image_gen/__init__.py::generate()` is the entry point. It:

1. **Parses the model string** — `"provider:model"` explicit, or bare shorthand/ID via `infer_provider()`.
2. **Consults the catalog** (bare shorthands only) — `catalog.resolve()` returns a `ModelEntry`; `catalog.validate()` rejects unsupported `aspect_ratio` / `resolution` **before** any SDK call.
3. **Dispatches** — direct `client.generate_image(...)` if no fallbacks; otherwise `Router(primary, fallbacks).generate(...)`.
4. **Emits observability** — one structured log line `image_gen.request` with canonical fields (`request_id`, `provider`, `model`, `latency_ms`, `status`, `bytes_out`, `cost_usd`, `retry_count`, `fallback_used`, `correlation_id`) plus Prometheus counters.
5. **Writes output** if `output=` given and `status == "completed"` — bytes or URL download.

Each step is one level of indirection away:
- `providers/catalog.py` → resolution + validation
- `providers/__init__.py::get_provider` → factory + plugin discovery
- `router.py::Router` → retry-exhausted → next provider
- `providers/_retry.py::retry_policy` → tenacity wrapping every SDK call
- `providers/_poll.py::poll_until` → async-task provider primitive (Higgsfield)

### Single source of truth: `catalog.yaml`

`src/image_gen/providers/catalog.yaml` lists every known model with: shorthand, provider, `model_id`, supported aspect ratios / resolutions, `seed` / `negative_prompt` capabilities, `cost_usd`. **Adding a model is editing this file** — no Python changes. `catalog.py` is the loader + `UnsupportedCapabilityError`. Currently 27 entries across 4 providers.

If you update the catalog, also update the README's models table (currently hand-maintained; search for "Supported models" section).

### Addressing rules (don't break these)

| Input | Behavior |
|---|---|
| `"fal:flux/dev"` | Explicit prefix → provider=`fal`, model_id forwarded verbatim, **catalog bypassed**. |
| `"flux"` | Bare shorthand → `infer_provider` → catalog resolves to `fal-ai/flux/dev`, validates. |
| `"higgsfield-ai/…"` | Bare full ID → `infer_provider` returns `"higgsfield"` (default), passthrough. |
| `"bogus:foo"` | Unknown provider prefix → `ValueError`. |

The explicit `"provider:model"` path is deliberately a passthrough so you can hit any model the SDK supports without adding a catalog entry.

### Result shape

`GenerationResult(request_id, status, image_bytes, image_url, video_url, cost_usd, raw)`. `status` is `"completed"` | `"failed"` | `"blocked"`. On success exactly one of `image_bytes` / `image_url` / `video_url` is set. **Do not reintroduce the old `"b64"` sentinel** — Phase 1 deliberately killed it; decode to `image_bytes` at the provider.

### Failure taxonomy (matters for retry logic)

- **Transient** (`httpx.Timeout`, `ConnectError`, `ReadError`, 429 / 500 / 502 / 503 / 504) → retried by tenacity (exp. backoff, default 3 attempts). `is_retryable()` walks `__cause__` / `__context__` so SDK-wrapped httpx errors still retry.
- **Blocked** (NSFW, policy refusal) → `GenerationResult(status="blocked", raw={"reason": …})`. **Never raised, never retried.** Every provider maps its own blocked-shape to this status (fal: `has_nsfw_concepts`; Google: `prompt_feedback.block_reason`; Higgsfield: `status == "nsfw"`).
- **Config** (`ValueError`, missing key) → raised immediately, not retried, not fallback-eligible.
- **Capability** (`UnsupportedCapabilityError`) → raised pre-flight, no SDK call made.

### Async semantics

`generate_async` is the full mirror. Every provider has `generate_image_async`. Most SDKs are native async (OpenAI `AsyncOpenAI`, fal `AsyncClient`, Higgsfield pure `httpx.AsyncClient`); **Google wraps in `asyncio.to_thread`** because `google-genai` has no native async yet. Calling sync `generate_image()` from inside a running event loop raises with a clear message pointing at `generate_image_async`.

### Plugin system

`register_provider(name, factory)` runtime, or declare in `pyproject.toml`:
```toml
[project.entry-points."image_gen.providers"]
runway = "runway_image_gen:RunwayClient"
```
`_discover_plugins()` is `@lru_cache`-d. `register_provider` clears the cache. See `examples/runway_plugin/` for a working third-party skeleton using `poll_until`.

### Google: two backends, one provider

`GoogleImageClient.__init__` auth priority: `GOOGLE_API_KEY` + `GOOGLE_GENAI_USE_VERTEXAI=True` → Vertex (API key, Railway prod); `GOOGLE_CLOUD_PROJECT` → Vertex (ADC, local dev); `GOOGLE_API_KEY` alone → AI Studio. Imagen 4 generally requires Vertex. For per-tenant GCP projects, construct `GoogleImageClient(project=…, location=…)` directly or `register_provider("google-eu", lambda: GoogleImageClient(project="…", location="europe-west4"))`.

### Higgsfield polling flow

`submit()` returns a `request_id`; `poll_until()` calls `status()` every `HIGGSFIELD_POLL_INTERVAL` seconds until `is_done` / `is_failed` / `is_blocked` or `HIGGSFIELD_POLL_MAX_WAIT` expires (→ `HiggsFieldError`). Priority order: `is_done > is_blocked > is_failed`. Each HTTP call (not the loop) is wrapped in `@retry_policy` so `time.sleep` in the loop is untouched.

## Phase layout

Eight phases, all in git log. Each phase corresponds to one specific capability:

1. Normalized `GenerationResult` + split timeouts + no env mutation
2. `catalog.yaml` + `ModelEntry` + pre-flight validation
3. `"provider:model"` aisuite-style addressing (hard break — no `provider=` kwarg)
4. `@retry_policy` + `Router` + `FallbackExhausted`
5. `poll_until` primitive + Higgsfield refactor
6. `observability.py` + `metrics.py` + canonical log fields + `correlation_id`
7. `register_provider` + entry-point discovery + `examples/runway_plugin/`
8. `generate_async` + `poll_until_async` + async provider methods

## Gotchas learned the hard way

- **Parallel worktree agents can lose commits.** Phase 2 landed its work on a dangling worktree branch while main moved forward on a parallel track; `git log --graph --all` was needed to find it. If you fan out agents in worktrees, merge them sequentially onto main and rebase the next one before it starts — don't assume disk-visible files are committed.
- **Don't mutate `os.environ`** for provider credentials (the original fal client did `os.environ.setdefault("FAL_KEY", ...)`). Pass keys to SDK clients explicitly — env mutation leaks across tenants and is not thread-safe.
- **Google `response.text` access via `.text` attribute can fail** on blocked responses. Traverse `response.candidates[0].content.parts` with `getattr` fallbacks, and check `prompt_feedback.block_reason` first.
- **The `"b64"` magic string is dead.** If you see it anywhere, that code is stale. Result carries real `bytes` in `image_bytes`.
- **Tenacity's `is_retryable` must walk the cause chain.** SDK libraries (openai, google-genai) wrap httpx errors in their own exception types. Without walking `__cause__`, retries silently stop working.
- **Catalog validation is skipped on explicit `"provider:model"`** — this is intentional. Callers signaling "I know what I'm doing" get verbatim passthrough. Only bare shorthands get validated.

## Environment

Credentials are read lazily at client construction — never at import. `config.py` has one reader per env var. The library does **not** call `load_dotenv()`; the consuming app is responsible.

```
OPENAI_API_KEY                  # OpenAI Images API
FAL_KEY                         # fal.ai
GOOGLE_APPLICATION_CREDENTIALS_JSON  # service-account JSON string → auto-writes temp file for ADC (Railway)
GOOGLE_CLOUD_PROJECT            # → Vertex AI (preferred for Imagen)
GOOGLE_CLOUD_LOCATION           # default us-central1 (Imagen); use "global" for Gemini image models on Vertex
GOOGLE_API_KEY                  # → AI Studio (alone) or Vertex (with GOOGLE_GENAI_USE_VERTEXAI=True)
GOOGLE_VERTEX_API_KEY           # → "google" provider uses Vertex AI with this key (Railway prod)
GOOGLE_GEMINI_API_KEY           # → "google-studio" provider uses AI Studio with this key
GOOGLE_GENAI_USE_VERTEXAI       # set to "true" to use GOOGLE_API_KEY against Vertex (Railway prod)
HIGGSFIELD_API_KEY              # Higgsfield
HIGGSFIELD_API_SECRET
HIGGSFIELD_BASE_URL             # default https://platform.higgsfield.ai
HIGGSFIELD_POLL_INTERVAL        # default 3s
HIGGSFIELD_POLL_MAX_WAIT        # default 300s
IMAGE_GEN_RETRY_ATTEMPTS        # default 3
IMAGE_GEN_RETRY_MAX_WAIT        # default 8 (seconds, cap per backoff)
IMAGE_GEN_LOG_FORMAT            # set to "json" for one-line-per-request JSON
```

## Working with this repo

- **Adding a model**: edit `catalog.yaml`, regenerate the README table (manual), run tests.
- **Adding a provider in-tree**: implement `ImageProvider` Protocol (sync + async), add to `_PROVIDER_REGISTRY` in `providers/__init__.py`, add catalog entries.
- **Adding a provider out-of-tree**: use the `examples/runway_plugin/` pattern — standalone package with `image_gen.providers` entry point. No core changes.
- **Changing the log schema**: canonical fields are defined in `observability.py`. Update both emission sites in `__init__.py::generate` (direct and Router paths) plus any documentation.
- **CLI help is source of truth** for CLI behavior — `cli.py` deliberately mirrors `generate()`.

## Research cache

`.firecrawl/` holds scraped provider docs used to populate/refresh `catalog.yaml`. Gitignored. Regenerate with the `/firecrawl` skill if models change.

## Non-goals (don't add without asking)

- HTTP server / FastAPI app: this is a library. Consumers wrap `generate_async` themselves.
- UI / dashboard: out of scope.
- LLM chat completions: this is image-gen only; the adapter pattern comes from LiteLLM but the target modality is images/video.
- Training / fine-tuning code: inference-only.
