"""CLI: ``image-gen`` — thin wrapper around ``image_gen.generate``."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

import click

from image_gen import generate, infer_provider


@click.command()
@click.option("--prompt", "-p", required=True, help="Text prompt for the image.")
@click.option(
    "--model",
    "-m",
    default="flux",
    show_default=True,
    help=(
        "Model to use. Accepts 'provider:model' syntax for explicit routing "
        "(e.g. -m fal:flux/dev, -m openai:gpt-image-1, -m google:imagen4, "
        "-m higgsfield:higgsfield-ai/soul/standard) or a bare shorthand "
        "(e.g. -m flux, -m nb-pro) that is routed automatically."
    ),
)
@click.option("--aspect", default="9:16", show_default=True)
@click.option("--resolution", default="720p", show_default=True)
@click.option(
    "--output",
    "-o",
    type=click.Path(path_type=Path),
    default=Path("output.png"),
    show_default=True,
)
@click.option("-v", "--verbose", is_flag=True, help="Enable debug logging.")
def main(
    prompt: str,
    model: str,
    aspect: str,
    resolution: str,
    output: Path,
    verbose: bool,
) -> None:
    """Generate an image and save it locally."""
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    if ":" in model:
        routed, model_display = model.split(":", 1)
    else:
        routed = infer_provider(model)
        model_display = model
    click.echo(f"→ provider: {routed}  model: {model_display}  aspect: {aspect}")

    result = generate(
        prompt=prompt,
        model=model,
        aspect_ratio=aspect,
        resolution=resolution,
        output=output,
    )

    if result.status != "completed":
        click.echo(f"✗ generation failed: {result.raw}", err=True)
        sys.exit(1)

    click.echo(f"✓ saved to {output}")


if __name__ == "__main__":
    main()
