"""Optional Prometheus metrics for image generation observability.

All metric functions are safe to call regardless of whether ``prometheus_client``
is installed.  When the package is absent every helper is a no-op so the main
package never requires the optional dependency.

Install the optional extra to enable real metrics::

    pip install "multi-model-image-gen[metrics]"

Then expose a ``/metrics`` endpoint in your own application or start the
default HTTP server::

    from prometheus_client import start_http_server
    start_http_server(8000)

Counters and histogram buckets
-------------------------------
``image_gen_requests_total``          {provider, model, status}
``image_gen_latency_seconds``         {provider, model}   (histogram)
``image_gen_retries_total``           {provider}
``image_gen_fallbacks_total``         {primary, fallback}
``image_gen_cost_usd_total``          {provider, model}
"""

from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# Optional import — fall back to no-ops when prometheus_client is absent
# ---------------------------------------------------------------------------

try:
    from prometheus_client import Counter, Histogram

    _PROMETHEUS_AVAILABLE = True

    # Latency histogram with buckets tuned for typical generation latency 1-60s.
    _LATENCY_BUCKETS = (
        0.5, 1.0, 2.0, 3.0, 5.0, 7.5,
        10.0, 15.0, 20.0, 30.0, 45.0, 60.0,
        float("inf"),
    )

    _requests_total: Any = Counter(
        "image_gen_requests_total",
        "Total image generation requests",
        ["provider", "model", "status"],
    )
    _latency_seconds: Any = Histogram(
        "image_gen_latency_seconds",
        "Image generation latency in seconds",
        ["provider", "model"],
        buckets=_LATENCY_BUCKETS,
    )
    _retries_total: Any = Counter(
        "image_gen_retries_total",
        "Total retry attempts across all providers",
        ["provider"],
    )
    _fallbacks_total: Any = Counter(
        "image_gen_fallbacks_total",
        "Total provider fallback transitions",
        ["primary", "fallback"],
    )
    _cost_usd_total: Any = Counter(
        "image_gen_cost_usd_total",
        "Cumulative estimated cost in USD",
        ["provider", "model"],
    )

except ImportError:  # pragma: no cover — tested only when pkg installed
    _PROMETHEUS_AVAILABLE = False

    # Define null sentinels so the names are present (helps type-checkers).
    _requests_total = None
    _latency_seconds = None
    _retries_total = None
    _fallbacks_total = None
    _cost_usd_total = None


# ---------------------------------------------------------------------------
# Helper functions (always importable; no-op when prometheus_client absent)
# ---------------------------------------------------------------------------

def record_request(
    provider: str,
    model: str,
    status: str,
    latency_ms: float,
    cost_usd: float | None = None,
) -> None:
    """Increment request counter, observe latency histogram, and add cost.

    Args:
        provider:   Provider name (e.g. ``"fal"``).
        model:      Model identifier forwarded to the provider.
        status:     ``"completed"``, ``"failed"``, or ``"blocked"``.
        latency_ms: Wall-clock duration of the call in milliseconds.
        cost_usd:   Optional estimated cost.  Skipped when ``None``.
    """
    if not _PROMETHEUS_AVAILABLE:
        return
    _requests_total.labels(provider=provider, model=model, status=status).inc()
    _latency_seconds.labels(provider=provider, model=model).observe(latency_ms / 1000.0)
    if cost_usd is not None:
        _cost_usd_total.labels(provider=provider, model=model).inc(cost_usd)


def record_retry(provider: str) -> None:
    """Increment the per-provider retry counter.

    Should be called from the tenacity ``before_sleep`` callback once per
    retry attempt (i.e. after the first failure, before sleeping).

    Args:
        provider: Provider name (e.g. ``"openai"``).
    """
    if not _PROMETHEUS_AVAILABLE:
        return
    _retries_total.labels(provider=provider).inc()


def record_fallback(primary: str, fallback: str) -> None:
    """Increment the fallback-transition counter.

    Args:
        primary:  Name of the provider that failed (e.g. ``"fal"``).
        fallback: Name of the provider being tried next (e.g. ``"openai"``).
    """
    if not _PROMETHEUS_AVAILABLE:
        return
    _fallbacks_total.labels(primary=primary, fallback=fallback).inc()
