"""Env-var readers — called lazily at client-construction time, not import time.

This module deliberately does NOT call ``load_dotenv()``. Consumers are
responsible for loading their own ``.env`` (e.g. with ``python-dotenv`` or
their framework). Keeping env reads lazy means that an app which sets
``FAL_KEY`` programmatically after importing this package still works.
"""

from __future__ import annotations

import os

# Default location for Google Vertex AI when the consumer doesn't set it.
# Imagen models use "us-central1"; Gemini image models require "global".
# Set GOOGLE_CLOUD_LOCATION explicitly to match the model you're using.
DEFAULT_GOOGLE_LOCATION = "us-central1"
DEFAULT_HIGGSFIELD_BASE_URL = "https://platform.higgsfield.ai"


def openai_api_key() -> str:
    return os.getenv("OPENAI_API_KEY", "")


def fal_key() -> str:
    return os.getenv("FAL_KEY", "")


def google_api_key() -> str:
    return os.getenv("GOOGLE_API_KEY", "")


def google_vertex_api_key() -> str:
    return os.getenv("GOOGLE_VERTEX_API_KEY", "")


def google_gemini_api_key() -> str:
    return os.getenv("GOOGLE_GEMINI_API_KEY", "")


def google_genai_use_vertexai() -> bool:
    return os.getenv("GOOGLE_GENAI_USE_VERTEXAI", "").lower() in ("1", "true", "yes")


def google_cloud_project() -> str:
    return os.getenv("GOOGLE_CLOUD_PROJECT", "")


def google_cloud_location() -> str:
    return os.getenv("GOOGLE_CLOUD_LOCATION", DEFAULT_GOOGLE_LOCATION)


def higgsfield_api_key() -> str:
    return os.getenv("HIGGSFIELD_API_KEY", "")


def higgsfield_api_secret() -> str:
    return os.getenv("HIGGSFIELD_API_SECRET", "")


def higgsfield_base_url() -> str:
    return os.getenv("HIGGSFIELD_BASE_URL", DEFAULT_HIGGSFIELD_BASE_URL)


def higgsfield_poll_interval() -> float:
    return float(os.getenv("HIGGSFIELD_POLL_INTERVAL", "3"))


def higgsfield_poll_max_wait() -> float:
    return float(os.getenv("HIGGSFIELD_POLL_MAX_WAIT", "300"))
