"""Structured logging and request context for image generation observability.

Usage::

    from image_gen.observability import StructuredLogger, request_context

    logger = StructuredLogger(__name__)

    with request_context(correlation_id="abc-123", provider="fal") as ctx:
        # ... run generation ...
        ctx.emit("generation complete", status="completed", latency_ms=1234.5)

Set ``IMAGE_GEN_LOG_FORMAT=json`` to emit one JSON object per log record.
"""

from __future__ import annotations

import json
import logging
import os
import time
from contextlib import contextmanager
from typing import Any, Generator

# ---------------------------------------------------------------------------
# Canonical field names for every structured log record
# ---------------------------------------------------------------------------
#
#   request_id      — opaque ID for this single generation call
#   provider        — "openai" | "fal" | "google" | "higgsfield"
#   model           — model_id forwarded to the provider
#   latency_ms      — wall-clock duration of the generate call (float, ms)
#   status          — "completed" | "failed" | "blocked"
#   bytes_out       — len(result.image_bytes) if set, else 0
#   cost_usd        — cost_usd from GenerationResult (float | None)
#   retry_count     — number of retry attempts consumed (int)
#   fallback_used   — True when a fallback provider served the request
#   correlation_id  — caller-supplied correlation/trace ID (str | None)
#
CANONICAL_FIELDS = frozenset(
    {
        "request_id",
        "provider",
        "model",
        "latency_ms",
        "status",
        "bytes_out",
        "cost_usd",
        "retry_count",
        "fallback_used",
        "correlation_id",
    }
)


# ---------------------------------------------------------------------------
# JSON formatter
# ---------------------------------------------------------------------------

class JSONFormatter(logging.Formatter):
    """Logging formatter that serialises each record as a single JSON line.

    Extra fields passed to the logger via ``extra={}`` are merged into the
    top-level JSON object.  Useful for structured log pipelines (Datadog,
    Loki, CloudWatch Logs Insights, …).
    """

    _SKIP_ATTRS: frozenset[str] = frozenset(
        {
            "args",
            "created",
            "exc_info",
            "exc_text",
            "filename",
            "funcName",
            "levelno",
            "lineno",
            "module",
            "msecs",
            "msg",
            "pathname",
            "process",
            "processName",
            "relativeCreated",
            "stack_info",
            "thread",
            "threadName",
        }
    )

    def format(self, record: logging.LogRecord) -> str:
        data: dict[str, Any] = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Merge any extra fields injected via ``extra={}``
        for key, value in record.__dict__.items():
            if key.startswith("_") or key in self._SKIP_ATTRS:
                continue
            if key in data:
                continue
            data[key] = value

        if record.exc_info:
            data["exception"] = self.formatException(record.exc_info)

        return json.dumps(data, default=str)


# ---------------------------------------------------------------------------
# Structured logger wrapper
# ---------------------------------------------------------------------------

def _use_json() -> bool:
    """Return True when IMAGE_GEN_LOG_FORMAT=json is set (case-insensitive)."""
    return os.environ.get("IMAGE_GEN_LOG_FORMAT", "").lower() == "json"


class StructuredLogger:
    """Thin wrapper around :class:`logging.Logger` that adds structured fields.

    When ``IMAGE_GEN_LOG_FORMAT=json``, each call emits a JSON-formatted
    record via :class:`JSONFormatter`; otherwise plain-text logging with
    ``extra={}`` fields passed through for downstream handlers.
    """

    def __init__(self, name: str) -> None:
        self._log = logging.getLogger(name)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def log_request(self, level: int, message: str, **fields: Any) -> None:
        """Log *message* at *level* with structured *fields* merged in.

        In JSON mode the fields appear as top-level keys alongside the message.
        In plain-text mode they are forwarded as ``extra={}`` for handlers that
        support structured data (e.g., python-json-logger, Datadog library).
        """
        if not self._log.isEnabledFor(level):
            return
        self._log.log(level, message, extra=fields, stacklevel=2)

    # Convenience shortcuts

    def info(self, message: str, **fields: Any) -> None:
        self.log_request(logging.INFO, message, **fields)

    def warning(self, message: str, **fields: Any) -> None:
        self.log_request(logging.WARNING, message, **fields)

    def debug(self, message: str, **fields: Any) -> None:
        self.log_request(logging.DEBUG, message, **fields)

    def error(self, message: str, **fields: Any) -> None:
        self.log_request(logging.ERROR, message, **fields)


# ---------------------------------------------------------------------------
# Request context manager
# ---------------------------------------------------------------------------

class RequestContext:
    """Accumulates structured fields and emits one log line on exit.

    Callers call :meth:`emit` to add fields incrementally. When the context
    manager exits (and :attr:`status` has been set), the logger emits one
    consolidated record.
    """

    def __init__(
        self,
        logger: StructuredLogger,
        correlation_id: str | None,
        **initial_fields: Any,
    ) -> None:
        self._logger = logger
        self._fields: dict[str, Any] = {
            "correlation_id": correlation_id,
            **initial_fields,
        }
        self._start_time: float = time.monotonic()
        self._emitted = False

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def emit(self, message: str | None = None, **more_fields: Any) -> None:
        """Merge *more_fields* into the accumulated context.

        If *message* is provided, log immediately at INFO level.
        Otherwise fields are buffered until context exit.
        """
        self._fields.update(more_fields)
        if message is not None:
            self._logger.info(message, **self._fields)
            self._emitted = True

    def _flush(self) -> None:
        """Emit one consolidated log line if not already emitted."""
        if not self._emitted and self._fields.get("status"):
            elapsed_ms = (time.monotonic() - self._start_time) * 1000.0
            self._fields.setdefault("latency_ms", round(elapsed_ms, 2))
            self._logger.info("image_gen.request", **self._fields)

    # Allow direct field assignment: ctx.status = "completed"
    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith("_") or name not in CANONICAL_FIELDS:
            super().__setattr__(name, value)
        else:
            self._fields[name] = value

    def __getattr__(self, name: str) -> Any:
        if name in CANONICAL_FIELDS:
            return self._fields.get(name)
        raise AttributeError(name)


@contextmanager
def request_context(
    correlation_id: str | None = None,
    **initial_fields: Any,
) -> Generator[RequestContext, None, None]:
    """Context manager that yields a :class:`RequestContext`.

    On exit the context emits one structured log line containing all fields
    accumulated via :meth:`~RequestContext.emit` (plus elapsed ``latency_ms``).

    Example::

        with request_context(correlation_id="abc", provider="fal") as ctx:
            result = client.generate_image(...)
            ctx.emit(status=result.status, bytes_out=len(result.image_bytes or b""))

    Args:
        correlation_id: Optional caller-supplied correlation / trace ID.
        **initial_fields: Seed fields to include in every emitted record.
    """
    _module_logger = StructuredLogger("image_gen.observability")
    ctx = RequestContext(_module_logger, correlation_id=correlation_id, **initial_fields)
    try:
        yield ctx
    finally:
        ctx._flush()


# ---------------------------------------------------------------------------
# Module-level logger instance for use inside this package
# ---------------------------------------------------------------------------

logger = StructuredLogger("image_gen")
