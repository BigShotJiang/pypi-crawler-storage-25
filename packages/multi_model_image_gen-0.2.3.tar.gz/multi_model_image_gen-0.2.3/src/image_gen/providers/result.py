"""Shared result type for all image providers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class GenerationResult:
    """Normalized output across all providers.

    Exactly one of ``image_bytes`` / ``image_url`` / ``video_url`` is populated
    on ``status == "completed"``. ``status`` is one of:

    - ``"completed"``   — success, payload available
    - ``"failed"``      — provider returned no usable output
    - ``"blocked"``     — policy/safety refusal (NSFW, content policy, …)
    """

    request_id: str
    status: str
    image_bytes: bytes | None = None
    image_url: str | None = None
    video_url: str | None = None
    cost_usd: float | None = None
    raw: dict[str, Any] | None = None
