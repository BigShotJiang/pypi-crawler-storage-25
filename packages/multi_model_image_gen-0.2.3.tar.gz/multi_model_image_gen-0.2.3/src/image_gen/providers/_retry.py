"""Tenacity-based retry policy for provider HTTP calls.

Environment variables
---------------------
IMAGE_GEN_RETRY_ATTEMPTS   Max total attempts (default 3).
IMAGE_GEN_RETRY_MAX_WAIT   Max backoff seconds between attempts (default 8.0).
"""

from __future__ import annotations

import os
from typing import Any, Callable, TypeVar

import httpx
import tenacity

F = TypeVar("F", bound=Callable[..., Any])

# ---------------------------------------------------------------------------
# Retryable-error predicate
# ---------------------------------------------------------------------------

_RETRYABLE_STATUS_CODES: frozenset[int] = frozenset({429, 500, 502, 503, 504})


def is_retryable(exc: BaseException) -> bool:
    """Return True when *exc* represents a transient failure worth retrying."""
    if isinstance(exc, (httpx.TimeoutException, httpx.ConnectError, httpx.ReadError)):
        return True
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code in _RETRYABLE_STATUS_CODES
    # Provider-SDK transient wrappers (openai, fal, google) often surface
    # httpx exceptions wrapped in their own exception types.  We catch them
    # by inspecting the cause chain so callers don't need to know SDK internals.
    cause = exc.__cause__ or exc.__context__
    if cause is not None and cause is not exc:
        return is_retryable(cause)
    return False


# ---------------------------------------------------------------------------
# Decorator factory
# ---------------------------------------------------------------------------

def retry_policy(
    max_attempts: int | None = None,
    max_wait: float | None = None,
    provider_name: str | None = None,
) -> Callable[[F], F]:
    """Return a tenacity retry decorator tuned for transient HTTP failures.

    Configuration is read lazily from environment variables so that tests can
    override them without reloading the module.

    Parameters
    ----------
    max_attempts:
        Override for ``IMAGE_GEN_RETRY_ATTEMPTS``.  Pass ``None`` to read from env.
    max_wait:
        Override for ``IMAGE_GEN_RETRY_MAX_WAIT``.  Pass ``None`` to read from env.
    provider_name:
        Optional provider name (e.g. ``"openai"``) used to record per-provider
        retry metrics.  When ``None`` retries are still executed but not counted
        in Prometheus.
    """

    def _decorator(fn: F) -> F:
        def _wrapper(*args: Any, **kwargs: Any) -> Any:
            _attempts = max_attempts if max_attempts is not None else int(
                os.environ.get("IMAGE_GEN_RETRY_ATTEMPTS", "3")
            )
            _max_wait = max_wait if max_wait is not None else float(
                os.environ.get("IMAGE_GEN_RETRY_MAX_WAIT", "8.0")
            )

            def _before_sleep(retry_state: tenacity.RetryCallState) -> None:
                """Called after a failed attempt, before sleeping."""
                if provider_name is not None:
                    # Import lazily to avoid circular import at module load time.
                    from image_gen import metrics as _metrics
                    _metrics.record_retry(provider_name)

            retryer = tenacity.Retrying(
                retry=tenacity.retry_if_exception(is_retryable),
                stop=tenacity.stop_after_attempt(_attempts),
                wait=tenacity.wait_exponential(multiplier=1.0, min=1, max=_max_wait)
                + tenacity.wait_random(0, 0.5),
                reraise=True,
                before_sleep=_before_sleep,
            )
            return retryer(fn, *args, **kwargs)

        # Preserve function identity (name, docstring, annotations) so that
        # wrapping does not obscure the provider method in tracebacks.
        _wrapper.__name__ = fn.__name__
        _wrapper.__doc__ = fn.__doc__
        _wrapper.__annotations__ = fn.__annotations__
        return _wrapper  # type: ignore[return-value]

    return _decorator
