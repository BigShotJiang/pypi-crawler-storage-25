"""Reusable polling primitive for async-task image providers."""

from __future__ import annotations

import asyncio
import time
from typing import Any, Awaitable, Callable, Union


class PollTimeout(Exception):
    """Raised when no terminal state is reached within the timeout window."""


def poll_until(
    *,
    status_fn: Callable[[], dict[str, Any]],
    is_done: Callable[[dict[str, Any]], bool],
    is_failed: Callable[[dict[str, Any]], bool] = lambda _d: False,
    is_blocked: Callable[[dict[str, Any]], bool] = lambda _d: False,
    interval: float = 3.0,
    timeout: float = 300.0,
) -> tuple[str, dict[str, Any]]:
    """Poll until a terminal state is reached.

    On each tick the function:
    1. Calls ``status_fn()`` to fetch the current state.
    2. Tests predicates in priority order: ``is_done`` → ``is_blocked`` →
       ``is_failed``.  The first predicate that returns ``True`` determines the
       terminal state string that is returned.
    3. If no predicate matches, sleeps ``interval`` seconds and repeats.
    4. Once the cumulative elapsed time exceeds ``timeout`` seconds without
       reaching a terminal state, raises ``PollTimeout``.

    Args:
        status_fn:  Zero-argument callable that returns the latest status dict.
        is_done:    Returns ``True`` when the task completed successfully.
        is_failed:  Returns ``True`` when the task failed irrecoverably.
        is_blocked: Returns ``True`` when the task was refused (e.g. NSFW).
        interval:   Seconds to sleep between polls.
        timeout:    Maximum total seconds to wait before raising ``PollTimeout``.

    Returns:
        A tuple ``(terminal_state, last_response)`` where *terminal_state* is
        one of ``"completed" | "failed" | "blocked"`` and *last_response* is
        the dict returned by ``status_fn`` on that final call.

    Raises:
        PollTimeout: No terminal state was reached within *timeout* seconds.
    """
    start = time.monotonic()

    while True:
        data = status_fn()

        if is_done(data):
            return "completed", data
        if is_blocked(data):
            return "blocked", data
        if is_failed(data):
            return "failed", data

        if time.monotonic() - start >= timeout:
            raise PollTimeout(
                f"No terminal state reached after {timeout}s."
            )

        time.sleep(interval)


async def poll_until_async(
    *,
    status_fn: Callable[[], Union[Awaitable[dict[str, Any]], dict[str, Any]]],
    is_done: Callable[[dict[str, Any]], bool],
    is_failed: Callable[[dict[str, Any]], bool] = lambda _d: False,
    is_blocked: Callable[[dict[str, Any]], bool] = lambda _d: False,
    interval: float = 3.0,
    timeout: float = 300.0,
) -> tuple[str, dict[str, Any]]:
    """Async version of ``poll_until`` using ``asyncio.sleep`` for non-blocking waits.

    ``status_fn`` must be an async callable (a coroutine function). Uses
    ``time.monotonic()`` for elapsed-time tracking (no asyncio clock dependency).

    Args:
        status_fn:  Async zero-argument callable that returns the latest status dict.
        is_done:    Returns ``True`` when the task completed successfully.
        is_failed:  Returns ``True`` when the task failed irrecoverably.
        is_blocked: Returns ``True`` when the task was refused (e.g. NSFW).
        interval:   Seconds to sleep between polls (non-blocking via asyncio.sleep).
        timeout:    Maximum total seconds to wait before raising ``PollTimeout``.

    Returns:
        A tuple ``(terminal_state, last_response)`` where *terminal_state* is
        one of ``"completed" | "failed" | "blocked"`` and *last_response* is
        the dict returned by ``status_fn`` on that final call.

    Raises:
        PollTimeout: No terminal state was reached within *timeout* seconds.
    """
    start = time.monotonic()

    while True:
        result = status_fn()
        # Support both sync and async status_fn for flexibility.
        if asyncio.iscoroutine(result):
            data = await result
        else:
            data = result  # type: ignore[assignment]

        if is_done(data):
            return "completed", data
        if is_blocked(data):
            return "blocked", data
        if is_failed(data):
            return "failed", data

        if time.monotonic() - start >= timeout:
            raise PollTimeout(
                f"No terminal state reached after {timeout}s."
            )

        await asyncio.sleep(interval)
