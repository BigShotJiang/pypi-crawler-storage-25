"""Provider registry — factory functions and plugin registration for image generation backends."""

from __future__ import annotations

import re
from functools import lru_cache
from typing import TYPE_CHECKING, Callable

from image_gen.providers.base import ImageProvider
from image_gen.providers.result import GenerationResult

if TYPE_CHECKING:
    pass

__all__ = [
    "GenerationResult",
    "ImageProvider",
    "get_provider",
    "infer_provider",
    "register_provider",
]

# ---------------------------------------------------------------------------
# Built-in model shorthands (used by infer_provider)
# ---------------------------------------------------------------------------

_OPENAI_MODELS = {"gpt-image"}

_FAL_MODELS = {
    "flux",
    "flux-schnell",
    "flux-pro",
    "seedream",
    "seedream-4.5",
    "ideogram",
    "recraft",
    "nb2-fal",
    "nb-pro-fal",
    "imagen4-fal",
}

_GOOGLE_MODELS = {"imagen4"}

_GOOGLE_STUDIO_MODELS = {"nb2", "nb-pro", "nano-banana"}

# ---------------------------------------------------------------------------
# Provider name validation
# ---------------------------------------------------------------------------

_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]*$")


def _validate_provider_name(name: str) -> None:
    """Raise ValueError if *name* is not a valid provider identifier.

    Valid names are lowercase, start with a letter or digit, and contain
    only letters, digits, and hyphens.
    """
    if not _NAME_RE.match(name):
        raise ValueError(
            f"Invalid provider name {name!r}. "
            "Names must be lowercase, start with a letter or digit, "
            "and contain only letters, digits, and hyphens."
        )


# ---------------------------------------------------------------------------
# Runtime registry
# ---------------------------------------------------------------------------
# Values are zero-argument callables (factories) that return an ImageProvider
# instance.  We use factories rather than classes so that SDK imports remain
# lazy and tests can supply lightweight stubs.

_PROVIDER_REGISTRY: dict[str, Callable[[], ImageProvider]] = {}


def _make_builtin_factories() -> dict[str, Callable[[], ImageProvider]]:
    """Return factory closures for the four built-in providers.

    Each factory is a separate closure so the SDK import stays local to the
    call site and is not executed until the provider is actually requested.
    """

    def _openai_factory() -> ImageProvider:
        from image_gen.providers.openai_images import OpenAIImageClient

        return OpenAIImageClient()

    def _google_factory() -> ImageProvider:
        from image_gen.providers.google_images import GoogleImageClient
        from image_gen.config import google_vertex_api_key

        vkey = google_vertex_api_key()
        if vkey:
            return GoogleImageClient(api_key=vkey, use_vertexai=True)
        return GoogleImageClient()

    def _google_studio_factory() -> ImageProvider:
        from image_gen.providers.google_images import GoogleImageClient
        from image_gen.config import google_gemini_api_key

        return GoogleImageClient(api_key=google_gemini_api_key(), use_vertexai=False)

    def _fal_factory() -> ImageProvider:
        from image_gen.providers.fal_images import FalImageClient

        return FalImageClient()

    def _higgsfield_factory() -> ImageProvider:
        from image_gen.providers.higgsfield import HiggsFieldClient

        return HiggsFieldClient()

    return {
        "openai": _openai_factory,
        "google": _google_factory,
        "google-studio": _google_studio_factory,
        "fal": _fal_factory,
        "higgsfield": _higgsfield_factory,
    }


# Populate built-ins at import time (lazy factories, no SDK imports yet).
_PROVIDER_REGISTRY.update(_make_builtin_factories())


def register_provider(
    name: str,
    factory: Callable[[], ImageProvider],
    *,
    override: bool = False,
) -> None:
    """Register a provider factory under *name*.

    Args:
        name: Identifier for the provider.  Must be lowercase, start with a
            letter or digit, and contain only letters, digits, and hyphens
            (e.g. ``"runway"``, ``"stability-ai"``).
        factory: Zero-argument callable that returns an :class:`ImageProvider`
            instance.  The factory is called fresh on every :func:`get_provider`
            lookup so provider objects are not cached at the registry level.
        override: If ``True``, silently replace an existing entry for *name*.
            Defaults to ``False``, which raises :class:`ValueError` on duplicates.

    Raises:
        ValueError: If *name* fails validation or is already registered and
            *override* is ``False``.
    """
    _validate_provider_name(name)
    if name in _PROVIDER_REGISTRY and not override:
        raise ValueError(
            f"Provider {name!r} is already registered. "
            "Pass override=True to replace it."
        )
    _PROVIDER_REGISTRY[name] = factory
    # Invalidate the entry-point cache so that the new name is visible to any
    # callers that previously triggered discovery (edge case: a plugin name
    # shadowed an entry-point name that was already cached).  We clear the
    # entire cache because lru_cache doesn't support per-key eviction.
    _discover_plugins.cache_clear()


# ---------------------------------------------------------------------------
# Entry-point discovery (cached)
# ---------------------------------------------------------------------------


@lru_cache(maxsize=None)
def _discover_plugins() -> dict[str, Callable[[], ImageProvider]]:
    """Load third-party providers registered under ``image_gen.providers``.

    This function is called at most once per interpreter lifetime (the result
    is memoised by ``@lru_cache``).  The cache is cleared by
    :func:`register_provider` so that subsequent calls can merge newly
    registered names — though in practice the runtime registry takes
    precedence and this function's return value is consulted only for names
    *not* already in :data:`_PROVIDER_REGISTRY`.

    Returns:
        Mapping from provider name to factory callable sourced from installed
        distribution entry points in the ``image_gen.providers`` group.
    """
    try:
        from importlib.metadata import entry_points
    except ImportError:  # Python < 3.9 shim (shouldn't occur given >=3.10 req)
        return {}

    discovered: dict[str, Callable[[], ImageProvider]] = {}
    eps = entry_points(group="image_gen.providers")
    for ep in eps:
        # Capture ep in the closure so the loop variable isn't captured by ref.
        def _make_ep_factory(entry_point=ep) -> Callable[[], ImageProvider]:
            def _factory() -> ImageProvider:
                cls = entry_point.load()
                return cls()

            return _factory

        discovered[ep.name] = _make_ep_factory()

    return discovered


# ---------------------------------------------------------------------------
# Public lookup
# ---------------------------------------------------------------------------


def get_provider(name: str) -> ImageProvider:
    """Instantiate an image provider by name.

    Lookup order:
    1. :data:`_PROVIDER_REGISTRY` (built-ins + runtime-registered plugins).
    2. Entry-point discovery via ``importlib.metadata`` (cached after first call).

    Args:
        name: Provider identifier, e.g. ``"openai"``, ``"fal"``, ``"runway"``.

    Returns:
        A fresh object satisfying the :class:`ImageProvider` protocol.

    Raises:
        ValueError: If *name* is not found in the registry or any installed
            entry point.
    """
    # 1. Fast path — registry (built-ins and explicitly registered plugins).
    if name in _PROVIDER_REGISTRY:
        return _PROVIDER_REGISTRY[name]()

    # 2. Slow path — entry-point discovery (result is cached after first call).
    plugins = _discover_plugins()
    if name in plugins:
        return plugins[name]()

    known = sorted(set(_PROVIDER_REGISTRY) | set(plugins))
    raise ValueError(
        f"Unknown provider: {name!r}. "
        f"Known providers: {known}. "
        "To add a new provider install a package that declares an entry point "
        "in the 'image_gen.providers' group, or call register_provider()."
    )


# ---------------------------------------------------------------------------
# Provider inference (shorthand → provider name)
# ---------------------------------------------------------------------------


def infer_provider(model: str) -> str:
    """Return the provider name for a bare model shorthand or full model ID.

    For ``"provider:model"`` strings the caller is expected to split on ``:``
    before calling this function.  Here we handle un-qualified names only.

    Args:
        model: Bare shorthand (``"flux"``) or full provider model ID
            (``"higgsfield-ai/soul/standard"``).

    Returns:
        One of the registered provider names, defaulting to ``"higgsfield"``
        for unrecognised IDs (Higgsfield uses full IDs rather than shorthands).
    """
    # Catalog is the primary source of truth (Phase 2).  Fall back to the
    # hard-coded shorthand sets if the catalog isn't available or doesn't
    # know about this model.
    try:
        from image_gen.providers.catalog import resolve as _catalog_resolve

        entry = _catalog_resolve(model)
        if entry is not None:
            return entry.provider
    except Exception:
        pass

    if model in _OPENAI_MODELS:
        return "openai"
    if model in _GOOGLE_MODELS:
        return "google"
    if model in _FAL_MODELS:
        return "fal"
    return "higgsfield"
