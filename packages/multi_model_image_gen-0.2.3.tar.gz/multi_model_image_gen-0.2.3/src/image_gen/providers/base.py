"""Provider protocol — minimum contract for image generation backends."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from image_gen.providers.result import GenerationResult


@runtime_checkable
class ImageProvider(Protocol):
    """Any backend that can generate images and download them."""

    def generate_image(
        self,
        prompt: str,
        model: str = ...,
        aspect_ratio: str = ...,
        resolution: str = ...,
        **kwargs: Any,
    ) -> GenerationResult: ...

    async def generate_image_async(
        self,
        prompt: str,
        model: str = ...,
        aspect_ratio: str = ...,
        resolution: str = ...,
        **kwargs: Any,
    ) -> GenerationResult: ...

    def download(self, url: str, output_path: str | Path) -> Path: ...

    async def download_async(self, url: str, output_path: str | Path) -> Path: ...

    def close(self) -> None: ...

    async def aclose(self) -> None: ...
