"""OpenAI Images API provider — direct gpt-image-1 generation."""

from __future__ import annotations

import asyncio
import base64
import uuid
from pathlib import Path
from typing import Any

import httpx
from openai import AsyncOpenAI, OpenAI

from image_gen.config import openai_api_key
from image_gen.providers._retry import retry_policy
from image_gen.providers.result import GenerationResult

_SIZE_MAP: dict[str, str] = {
    "9:16": "1024x1536",
    "16:9": "1536x1024",
    "1:1": "1024x1024",
}

_SHORTHAND: dict[str, str] = {
    "gpt-image": "gpt-image-1",
}

_DEFAULT_TIMEOUT = httpx.Timeout(connect=5.0, read=60.0, write=10.0, pool=5.0)


def _resolve_model(model: str) -> str:
    if "/" in model:
        model = model.rsplit("/", 1)[-1]
    return _SHORTHAND.get(model, model)


def _raise_if_loop_running(client_name: str) -> None:
    """Raise a clear error if called from inside a running event loop."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return  # No running loop — safe to proceed synchronously.
    raise RuntimeError(
        f"{client_name}.generate_image() called from inside a running asyncio event loop. "
        f"Use 'await client.generate_image_async(...)' instead to avoid blocking the loop."
    )


class OpenAIImageClient:
    """Synchronous/async client for OpenAI's Images API (gpt-image-1).

    The sync ``generate_image`` uses the synchronous :class:`openai.OpenAI` client.
    The async ``generate_image_async`` uses :class:`openai.AsyncOpenAI` and never
    blocks the event loop.  Calling ``generate_image`` from within a running loop
    raises a :class:`RuntimeError` with a clear migration message.
    """

    def __init__(self, api_key: str | None = None):
        api_key = api_key or openai_api_key()
        if not api_key:
            raise ValueError("OPENAI_API_KEY not set and no api_key passed.")
        self._api_key = api_key
        self._client = OpenAI(api_key=api_key)
        self._http = httpx.Client(timeout=_DEFAULT_TIMEOUT)
        # Lazy async clients — created on first use.
        self._async_client: AsyncOpenAI | None = None
        self._async_http: httpx.AsyncClient | None = None

    # ------------------------------------------------------------------
    # Lazy async client accessors
    # ------------------------------------------------------------------

    def _get_async_client(self) -> AsyncOpenAI:
        if self._async_client is None:
            self._async_client = AsyncOpenAI(api_key=self._api_key)
        return self._async_client

    def _get_async_http(self) -> httpx.AsyncClient:
        if self._async_http is None:
            self._async_http = httpx.AsyncClient(timeout=_DEFAULT_TIMEOUT)
        return self._async_http

    # ------------------------------------------------------------------
    # Sync API
    # ------------------------------------------------------------------

    def generate_image(
        self,
        prompt: str,
        model: str = "gpt-image-1",
        aspect_ratio: str = "9:16",
        resolution: str = "720p",
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate an image synchronously.

        Raises ``RuntimeError`` if called from inside a running event loop —
        use ``generate_image_async`` instead.
        """
        _raise_if_loop_running("OpenAIImageClient")
        size = _SIZE_MAP.get(aspect_ratio, "1024x1536")
        model = _resolve_model(model)

        @retry_policy()
        def _call() -> Any:
            return self._client.images.generate(
                model=model,
                prompt=prompt,
                size=size,
                n=1,
                **kwargs,
            )

        resp = _call()

        b64 = resp.data[0].b64_json
        return GenerationResult(
            request_id=str(uuid.uuid4()),
            status="completed",
            image_bytes=base64.b64decode(b64) if b64 else None,
            raw={"b64_json": b64},
        )

    def download(self, url: str, output_path: str | Path) -> Path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        resp = self._http.get(url)
        resp.raise_for_status()
        output_path.write_bytes(resp.content)
        return output_path

    def close(self) -> None:
        self._client.close()
        self._http.close()

    # ------------------------------------------------------------------
    # Async API
    # ------------------------------------------------------------------

    async def generate_image_async(
        self,
        prompt: str,
        model: str = "gpt-image-1",
        aspect_ratio: str = "9:16",
        resolution: str = "720p",
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate an image asynchronously using :class:`openai.AsyncOpenAI`."""
        size = _SIZE_MAP.get(aspect_ratio, "1024x1536")
        resolved_model = _resolve_model(model)
        async_client = self._get_async_client()

        resp = await async_client.images.generate(
            model=resolved_model,
            prompt=prompt,
            size=size,
            n=1,
            **kwargs,
        )

        b64 = resp.data[0].b64_json
        return GenerationResult(
            request_id=str(uuid.uuid4()),
            status="completed",
            image_bytes=base64.b64decode(b64) if b64 else None,
            raw={"b64_json": b64},
        )

    async def download_async(self, url: str, output_path: str | Path) -> Path:
        """Download a file asynchronously."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        async_http = self._get_async_http()
        resp = await async_http.get(url)
        resp.raise_for_status()
        output_path.write_bytes(resp.content)
        return output_path

    async def aclose(self) -> None:
        """Close all async resources."""
        if self._async_client is not None:
            await self._async_client.close()
        if self._async_http is not None:
            await self._async_http.aclose()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.aclose()
