"""Catalog — YAML-driven model registry with capability validation.

The catalog.yaml file is the single source of truth for all known models.
Use :func:`resolve` to look up a model by shorthand or full model ID, and
:func:`validate` to assert that a requested aspect_ratio/resolution pair
is supported before dispatching to the provider SDK.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

__all__ = [
    "ModelEntry",
    "UnsupportedCapabilityError",
    "load_catalog",
    "resolve",
    "validate",
]

_CATALOG_PATH = Path(__file__).parent / "catalog.yaml"


class UnsupportedCapabilityError(ValueError):
    """Raised when a model does not support the requested capability."""


@dataclass(frozen=True)
class ModelEntry:
    """Immutable descriptor for a single model in the catalog."""

    shorthand: str
    provider: str
    model_id: str
    aspect_ratios: frozenset[str]
    resolutions: frozenset[str]
    seed: bool
    negative_prompt: bool
    cost_usd: float | None


def _parse_entry(raw: dict[str, Any]) -> ModelEntry:
    supports: dict[str, Any] = raw.get("supports", {})
    return ModelEntry(
        shorthand=raw["shorthand"],
        provider=raw["provider"],
        model_id=raw["model_id"],
        aspect_ratios=frozenset(supports.get("aspect_ratios", [])),
        resolutions=frozenset(supports.get("resolutions", [])),
        seed=bool(supports.get("seed", False)),
        negative_prompt=bool(supports.get("negative_prompt", False)),
        cost_usd=raw.get("cost_usd"),
    )


@lru_cache(maxsize=1)
def load_catalog() -> dict[str, ModelEntry]:
    """Load and parse catalog.yaml.

    Returns a dict keyed *primarily* by shorthand but also with model_id
    as an alias so that both ``resolve("flux")`` and
    ``resolve("fal-ai/flux/dev")`` work.

    The cache is populated once per process; call ``load_catalog.cache_clear()``
    in tests if you need to reload.
    """
    data: list[dict[str, Any]] = yaml.safe_load(_CATALOG_PATH.read_text())
    index: dict[str, ModelEntry] = {}
    for raw in data:
        entry = _parse_entry(raw)
        # Primary key: shorthand
        index[entry.shorthand] = entry
        # Secondary key: full model_id (only if it doesn't shadow a shorthand)
        if entry.model_id not in index:
            index[entry.model_id] = entry
    return index


def resolve(shorthand_or_id: str) -> ModelEntry | None:
    """Return the :class:`ModelEntry` for *shorthand_or_id*, or ``None``.

    Looks up by shorthand first, then by full model_id.
    """
    return load_catalog().get(shorthand_or_id)


def validate(entry: ModelEntry, aspect_ratio: str, resolution: str) -> None:
    """Assert *entry* supports *aspect_ratio* and *resolution*.

    Raises :class:`UnsupportedCapabilityError` with a descriptive message
    if either capability is missing.  When the capability set is empty (i.e.
    the YAML entry has no constraints listed) the check is skipped so that
    pass-through / Higgsfield full IDs are never blocked.
    """
    if entry.aspect_ratios and aspect_ratio not in entry.aspect_ratios:
        raise UnsupportedCapabilityError(
            f"Model {entry.shorthand!r} (provider={entry.provider!r}) does not support "
            f"aspect_ratio={aspect_ratio!r}. "
            f"Supported: {sorted(entry.aspect_ratios)}"
        )
    if entry.resolutions and resolution not in entry.resolutions:
        raise UnsupportedCapabilityError(
            f"Model {entry.shorthand!r} (provider={entry.provider!r}) does not support "
            f"resolution={resolution!r}. "
            f"Supported: {sorted(entry.resolutions)}"
        )
