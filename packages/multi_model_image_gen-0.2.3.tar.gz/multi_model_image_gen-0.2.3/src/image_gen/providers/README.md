# Adding an async-task provider

Many image/video generation APIs follow the same pattern:

1. **Submit** a generation job; receive a `request_id`.
2. **Poll** a status endpoint until a terminal state (`completed`, `failed`,
   or `blocked`).
3. **Map** the final response to a `GenerationResult`.

The `_poll.py` module extracts step 2 into a reusable `poll_until` helper so
that new async-task providers can be implemented in roughly 60 lines.

---

## `poll_until` quick reference

```python
from image_gen.providers._poll import poll_until, PollTimeout

terminal_state, last_response = poll_until(
    status_fn=callable_returning_dict,   # fetches current status
    is_done=lambda d: ...,               # True → "completed"
    is_failed=lambda d: ...,             # True → "failed"   (default: never)
    is_blocked=lambda d: ...,            # True → "blocked"  (default: never)
    interval=3.0,                        # seconds between polls
    timeout=300.0,                       # raises PollTimeout if exceeded
)
```

**Predicate priority** (highest first): `is_done` → `is_blocked` → `is_failed`.
If a response satisfies multiple predicates, the highest-priority one wins.

**`PollTimeout`** is raised (not returned) when no terminal state is reached
within `timeout` seconds.  Catch it and convert to your provider's error type.

---

## Minimal skeleton for a new async provider

```python
"""MyProvider API client — submit, poll, download."""

from __future__ import annotations

from typing import Any
import httpx

from image_gen.providers._poll import PollTimeout, poll_until
from image_gen.providers.result import GenerationResult


class MyProviderError(Exception):
    """Raised when a MyProvider API call fails."""


class MyProviderClient:
    def __init__(self, api_key: str):
        self._api_key = api_key
        self._http = httpx.Client()

    # ------------------------------------------------------------------ #
    # Low-level API wrappers                                               #
    # ------------------------------------------------------------------ #

    def _submit(self, payload: dict[str, Any]) -> str:
        resp = self._http.post(
            "https://api.myprovider.io/generate",
            headers={"Authorization": f"Bearer {self._api_key}"},
            json=payload,
        )
        resp.raise_for_status()
        return resp.json()["id"]

    def _status(self, job_id: str) -> dict[str, Any]:
        resp = self._http.get(f"https://api.myprovider.io/jobs/{job_id}")
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------ #
    # High-level: submit → poll → map                                     #
    # ------------------------------------------------------------------ #

    def generate_and_wait(
        self,
        prompt: str,
        timeout: float = 300.0,
        interval: float = 3.0,
    ) -> GenerationResult:
        job_id = self._submit({"prompt": prompt})

        try:
            terminal, data = poll_until(
                status_fn=lambda: self._status(job_id),
                is_done=lambda d: d.get("state") == "succeeded",
                is_failed=lambda d: d.get("state") == "failed",
                is_blocked=lambda d: d.get("state") == "rejected",
                interval=interval,
                timeout=timeout,
            )
        except PollTimeout:
            raise MyProviderError(f"Timeout after {timeout}s for job {job_id}")

        if terminal == "completed":
            return GenerationResult(
                request_id=job_id,
                status="completed",
                image_url=data.get("output", {}).get("url"),
                raw=data,
            )
        if terminal == "blocked":
            return GenerationResult(
                request_id=job_id,
                status="blocked",
                raw={**data, "reason": "policy"},
            )
        return GenerationResult(request_id=job_id, status="failed", raw=data)

    def generate_image(self, prompt: str, **kwargs: Any) -> GenerationResult:
        return self.generate_and_wait(prompt, **kwargs)

    def download(self, url: str, output_path: str) -> str:
        resp = self._http.get(url)
        resp.raise_for_status()
        with open(output_path, "wb") as f:
            f.write(resp.content)
        return output_path

    def close(self) -> None:
        self._http.close()
```

That's it — roughly 60 lines for a complete async-task provider.
`poll_until` owns the loop, the timeout, and the predicate contract;
your provider only defines what "done / failed / blocked" means and how
to map the final dict to `GenerationResult`.
