"""Higgsfield API client — submit, poll, download (sync + async)."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import httpx

from image_gen.config import (
    higgsfield_api_key,
    higgsfield_api_secret,
    higgsfield_base_url,
    higgsfield_poll_interval,
    higgsfield_poll_max_wait,
)
from image_gen.providers._poll import PollTimeout, poll_until, poll_until_async
from image_gen.providers._retry import retry_policy
from image_gen.providers.result import GenerationResult

__all__ = ["HiggsFieldClient", "HiggsFieldError"]


class HiggsFieldError(Exception):
    """Raised when a Higgsfield API call fails."""


def _raise_if_loop_running(client_name: str) -> None:
    """Raise a clear error if called from inside a running event loop."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return  # No running loop — safe to proceed synchronously.
    raise RuntimeError(
        f"{client_name}.generate_image() called from inside a running asyncio event loop. "
        f"Use 'await client.generate_image_async(...)' instead to avoid blocking the loop."
    )


class HiggsFieldClient:
    """Async-queue client for the Higgsfield generation platform.

    Provides both synchronous (``generate_image``) and fully async
    (``generate_image_async``) APIs.  The async path uses ``httpx.AsyncClient``
    and ``asyncio.sleep`` so that many concurrent Higgsfield requests can be
    batched via ``asyncio.gather`` without blocking each other.
    """

    def __init__(
        self,
        api_key: str | None = None,
        api_secret: str | None = None,
        base_url: str | None = None,
    ):
        api_key = api_key or higgsfield_api_key()
        api_secret = api_secret or higgsfield_api_secret()
        base_url = base_url or higgsfield_base_url()
        if not api_key or not api_secret:
            raise HiggsFieldError(
                "HIGGSFIELD_API_KEY and HIGGSFIELD_API_SECRET must be set."
            )
        self.base_url = base_url.rstrip("/")
        self._headers = {
            "Authorization": f"Key {api_key}:{api_secret}",
            "Content-Type": "application/json",
        }
        self._client = httpx.Client(
            timeout=httpx.Timeout(connect=5.0, read=60.0, write=10.0, pool=5.0)
        )
        # Lazy async client — created on first use.
        self._async_client: httpx.AsyncClient | None = None

    # ------------------------------------------------------------------
    # Lazy async client accessor
    # ------------------------------------------------------------------

    def _get_async_client(self) -> httpx.AsyncClient:
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                timeout=httpx.Timeout(connect=5.0, read=60.0, write=10.0, pool=5.0)
            )
        return self._async_client

    # ------------------------------------------------------------------
    # Sync submit / status
    # ------------------------------------------------------------------

    def submit(self, model_id: str, payload: dict[str, Any]) -> str:
        """POST to the Higgsfield generation endpoint and return the request_id.

        Automatically retried on transient HTTP failures (429, 5xx, timeouts).
        """

        @retry_policy()
        def _call() -> dict[str, Any]:
            url = f"{self.base_url}/{model_id}"
            resp = self._client.post(url, headers=self._headers, json=payload)
            resp.raise_for_status()
            return resp.json()

        data = _call()
        request_id = data.get("request_id") or data.get("id")
        if not request_id:
            raise HiggsFieldError(f"No request_id in response: {data}")
        return request_id

    def status(self, request_id: str) -> dict[str, Any]:
        """Poll the status endpoint for an in-flight request.

        Automatically retried on transient HTTP failures (429, 5xx, timeouts).
        """

        @retry_policy()
        def _call() -> dict[str, Any]:
            url = f"{self.base_url}/requests/{request_id}/status"
            resp = self._client.get(url, headers=self._headers)
            resp.raise_for_status()
            return resp.json()

        return _call()

    # ------------------------------------------------------------------
    # Async submit / status
    # ------------------------------------------------------------------

    async def submit_async(self, model_id: str, payload: dict[str, Any]) -> str:
        """Async version of ``submit`` using ``httpx.AsyncClient``."""
        async_client = self._get_async_client()
        url = f"{self.base_url}/{model_id}"
        resp = await async_client.post(url, headers=self._headers, json=payload)
        resp.raise_for_status()
        data = resp.json()
        request_id = data.get("request_id") or data.get("id")
        if not request_id:
            raise HiggsFieldError(f"No request_id in response: {data}")
        return request_id

    async def status_async(self, request_id: str) -> dict[str, Any]:
        """Async version of ``status`` using ``httpx.AsyncClient``."""
        async_client = self._get_async_client()
        url = f"{self.base_url}/requests/{request_id}/status"
        resp = await async_client.get(url, headers=self._headers)
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # Sync generate-and-wait
    # ------------------------------------------------------------------

    def cancel(self, request_id: str) -> bool:
        url = f"{self.base_url}/requests/{request_id}/cancel"
        resp = self._client.post(url, headers=self._headers)
        return resp.status_code == 200

    def generate_and_wait(
        self,
        model_id: str,
        payload: dict[str, Any],
        poll_interval: float | None = None,
        max_wait: float | None = None,
    ) -> GenerationResult:
        poll_interval = poll_interval if poll_interval is not None else higgsfield_poll_interval()
        max_wait = max_wait if max_wait is not None else higgsfield_poll_max_wait()

        request_id = self.submit(model_id, payload)

        try:
            terminal, data = poll_until(
                status_fn=lambda: self.status(request_id),
                is_done=lambda d: d.get("status") == "completed",
                is_blocked=lambda d: d.get("status") == "nsfw",
                is_failed=lambda d: d.get("status") == "failed",
                interval=poll_interval,
                timeout=max_wait,
            )
        except PollTimeout:
            raise HiggsFieldError(
                f"Timeout after {max_wait}s waiting for request {request_id}"
            )

        return _build_result(terminal, data, request_id)

    # ------------------------------------------------------------------
    # Async generate-and-wait
    # ------------------------------------------------------------------

    async def generate_and_wait_async(
        self,
        model_id: str,
        payload: dict[str, Any],
        poll_interval: float | None = None,
        max_wait: float | None = None,
    ) -> GenerationResult:
        """Submit a request and poll for completion asynchronously.

        Uses ``asyncio.sleep`` so that the event loop is not blocked during
        polling, enabling many concurrent requests via ``asyncio.gather``.
        """
        poll_interval = poll_interval if poll_interval is not None else higgsfield_poll_interval()
        max_wait = max_wait if max_wait is not None else higgsfield_poll_max_wait()

        request_id = await self.submit_async(model_id, payload)

        async def _status_fn() -> dict[str, Any]:
            return await self.status_async(request_id)

        try:
            terminal, data = await poll_until_async(
                status_fn=_status_fn,
                is_done=lambda d: d.get("status") == "completed",
                is_blocked=lambda d: d.get("status") == "nsfw",
                is_failed=lambda d: d.get("status") == "failed",
                interval=poll_interval,
                timeout=max_wait,
            )
        except PollTimeout:
            raise HiggsFieldError(
                f"Timeout after {max_wait}s waiting for request {request_id}"
            )

        return _build_result(terminal, data, request_id)

    # ------------------------------------------------------------------
    # Download
    # ------------------------------------------------------------------

    def download(self, url: str, output_path: str | Path) -> Path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        resp = self._client.get(url)
        resp.raise_for_status()
        output_path.write_bytes(resp.content)
        return output_path

    async def download_async(self, url: str, output_path: str | Path) -> Path:
        """Download a file asynchronously."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        async_client = self._get_async_client()
        resp = await async_client.get(url)
        resp.raise_for_status()
        output_path.write_bytes(resp.content)
        return output_path

    # ------------------------------------------------------------------
    # generate_image / generate_image_async (public protocol surface)
    # ------------------------------------------------------------------

    def generate_image(
        self,
        prompt: str,
        model: str = "higgsfield-ai/soul/standard",
        aspect_ratio: str = "9:16",
        resolution: str = "720p",
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate an image synchronously.

        Raises ``RuntimeError`` if called from inside a running event loop —
        use ``generate_image_async`` instead.
        """
        _raise_if_loop_running("HiggsFieldClient")
        payload = {
            "prompt": prompt,
            "aspect_ratio": aspect_ratio,
            "resolution": resolution,
            **kwargs,
        }
        return self.generate_and_wait(model, payload)

    async def generate_image_async(
        self,
        prompt: str,
        model: str = "higgsfield-ai/soul/standard",
        aspect_ratio: str = "9:16",
        resolution: str = "720p",
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate an image asynchronously.

        Uses ``httpx.AsyncClient`` for HTTP and ``asyncio.sleep`` for polling,
        so many concurrent calls can share a single event loop efficiently.
        """
        payload = {
            "prompt": prompt,
            "aspect_ratio": aspect_ratio,
            "resolution": resolution,
            **kwargs,
        }
        return await self.generate_and_wait_async(model, payload)

    # ------------------------------------------------------------------
    # Video helpers (sync-only; video support is sync-sufficient today)
    # ------------------------------------------------------------------

    def generate_video(
        self,
        image_url: str,
        prompt: str,
        model: str = "kling-video/v2.1/pro/image-to-video",
        duration: int = 5,
        **kwargs: Any,
    ) -> GenerationResult:
        payload = {
            "image_url": image_url,
            "prompt": prompt,
            "duration": duration,
            **kwargs,
        }
        return self.generate_and_wait(model, payload)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self):
        self._client.close()

    async def aclose(self) -> None:
        """Close all async resources."""
        if self._async_client is not None:
            await self._async_client.aclose()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.aclose()


# ------------------------------------------------------------------
# Shared result-building helper
# ------------------------------------------------------------------

def _build_result(terminal: str, data: dict[str, Any], request_id: str) -> GenerationResult:
    if terminal == "completed":
        output = data.get("output", {})
        return GenerationResult(
            request_id=request_id,
            status="completed",
            image_url=output.get("image_url") or output.get("url"),
            video_url=output.get("video_url"),
            raw=data,
        )
    if terminal == "blocked":
        return GenerationResult(
            request_id=request_id,
            status="blocked",
            raw={**data, "reason": "nsfw"},
        )
    # terminal == "failed"
    return GenerationResult(request_id=request_id, status="failed", raw=data)
