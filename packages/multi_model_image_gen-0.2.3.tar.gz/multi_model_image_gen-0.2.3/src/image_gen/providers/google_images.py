"""Google Generative AI image provider — Nano Banana / Imagen via Vertex AI or AI Studio."""

from __future__ import annotations

import atexit
import asyncio
import json
import logging
import os
import tempfile
import uuid
from pathlib import Path
from typing import Any

import httpx
from google import genai
from google.genai import types

from image_gen.config import google_api_key, google_cloud_location, google_cloud_project, google_genai_use_vertexai, google_vertex_api_key, google_gemini_api_key
from image_gen.providers._retry import retry_policy
from image_gen.providers.result import GenerationResult

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Service-account JSON credentials bootstrap
# ---------------------------------------------------------------------------
# Reads GOOGLE_APPLICATION_CREDENTIALS_JSON (full JSON string), writes it to
# a temp file, and sets GOOGLE_APPLICATION_CREDENTIALS so the Google SDK
# picks it up as ADC. Idempotent — runs at most once per process.

_CREDENTIALS_TMPFILE: str | None = None


def _ensure_google_credentials() -> None:
    global _CREDENTIALS_TMPFILE
    if _CREDENTIALS_TMPFILE is not None:
        return
    if os.environ.get("GOOGLE_APPLICATION_CREDENTIALS"):
        return
    raw = os.getenv("GOOGLE_APPLICATION_CREDENTIALS_JSON")
    if not raw:
        return
    tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False)
    json.dump(json.loads(raw), tmp)
    tmp.flush()
    tmp.close()
    _CREDENTIALS_TMPFILE = tmp.name
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = tmp.name
    atexit.register(os.unlink, tmp.name)
    log.info("google: loaded credentials from GOOGLE_APPLICATION_CREDENTIALS_JSON")

_IMAGE_SIZE_MAP: dict[str, str] = {
    "720p": "1K",
    "1080p": "2K",
    "4k": "4K",
}

_SHORTHAND: dict[str, str] = {
    "nb2": "gemini-2.5-flash-image",
    "nb-pro": "gemini-2.5-flash-image",
    "imagen4": "imagen-4.0-generate-001",
}

_DEFAULT_TIMEOUT = httpx.Timeout(connect=5.0, read=60.0, write=10.0, pool=5.0)


def _resolve_model(model: str) -> str:
    return _SHORTHAND.get(model, model)


def _raise_if_loop_running(client_name: str) -> None:
    """Raise a clear error if called from inside a running event loop."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return  # No running loop — safe to proceed synchronously.
    raise RuntimeError(
        f"{client_name}.generate_image() called from inside a running asyncio event loop. "
        f"Use 'await client.generate_image_async(...)' instead to avoid blocking the loop."
    )


def _extract_result(response: Any, request_id: str) -> GenerationResult:
    """Parse a Google genai response into a GenerationResult."""
    # Block detection: prompt_feedback.block_reason is the canonical signal.
    pf = getattr(response, "prompt_feedback", None)
    block_reason = getattr(pf, "block_reason", None) if pf is not None else None
    if block_reason:
        return GenerationResult(
            request_id=request_id,
            status="blocked",
            raw={"reason": str(block_reason)},
        )

    for candidate in getattr(response, "candidates", None) or []:
        content = getattr(candidate, "content", None)
        parts = getattr(content, "parts", None) or []
        for part in parts:
            inline = getattr(part, "inline_data", None)
            data = getattr(inline, "data", None) if inline is not None else None
            if data:
                return GenerationResult(
                    request_id=request_id,
                    status="completed",
                    image_bytes=data,
                )

    log.warning("No image data in Google response")
    text = getattr(response, "text", None) or "no image returned"
    return GenerationResult(
        request_id=request_id,
        status="failed",
        raw={"text": text},
    )


class GoogleImageClient:
    """Synchronous/async client for Google's Generative AI image models.

    Uses Vertex AI when a project is provided, else AI Studio API key.

    The Google ``genai`` SDK does not currently expose a native async
    ``generate_content_async`` method; the async path wraps the sync call
    in ``asyncio.to_thread`` to avoid blocking the event loop.
    """

    def __init__(
        self,
        api_key: str | None = None,
        project: str | None = None,
        location: str | None = None,
        use_vertexai: bool | None = None,
    ):
        _ensure_google_credentials()  # bootstrap from GOOGLE_APPLICATION_CREDENTIALS_JSON if set
        project = project or google_cloud_project()
        location = location or google_cloud_location()
        api_key = api_key or google_api_key()

        if use_vertexai is None:
            use_vertexai = google_genai_use_vertexai()

        if api_key and use_vertexai:
            log.info("google: using Vertex AI (API key)")
            self._client = genai.Client(vertexai=True, api_key=api_key)
        elif project:
            log.info("google: using Vertex AI (ADC, project=%s, location=%s)", project, location)
            self._client = genai.Client(vertexai=True, project=project, location=location)
        elif api_key:
            log.info("google: using AI Studio API key")
            self._client = genai.Client(api_key=api_key)
        else:
            raise ValueError(
                "Set GOOGLE_CLOUD_PROJECT for Vertex AI (ADC), "
                "or GOOGLE_API_KEY + GOOGLE_GENAI_USE_VERTEXAI=True for Vertex AI (API key), "
                "or GOOGLE_API_KEY alone for AI Studio."
            )
        self._http = httpx.Client(timeout=_DEFAULT_TIMEOUT)
        # Lazy async HTTP client — created on first use.
        self._async_http: httpx.AsyncClient | None = None

    # ------------------------------------------------------------------
    # Lazy async client accessor
    # ------------------------------------------------------------------

    def _get_async_http(self) -> httpx.AsyncClient:
        if self._async_http is None:
            self._async_http = httpx.AsyncClient(timeout=_DEFAULT_TIMEOUT)
        return self._async_http

    # ------------------------------------------------------------------
    # Sync API
    # ------------------------------------------------------------------

    def generate_image(
        self,
        prompt: str,
        model: str = "gemini-2.5-flash-image",
        aspect_ratio: str = "9:16",
        resolution: str = "720p",
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate an image synchronously.

        Raises ``RuntimeError`` if called from inside a running event loop —
        use ``generate_image_async`` instead.
        """
        _raise_if_loop_running("GoogleImageClient")
        image_size = _IMAGE_SIZE_MAP.get(resolution, "1K")
        model = _resolve_model(model)
        request_id = str(uuid.uuid4())

        log.info("google → %s (%s, %s)", model, aspect_ratio, image_size)

        @retry_policy()
        def _call():
            return self._client.models.generate_content(
                model=model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_modalities=["IMAGE"],
                    image_config=types.ImageConfig(
                        aspect_ratio=aspect_ratio,
                        image_size=image_size,
                    ),
                ),
            )

        response = _call()
        return _extract_result(response, request_id)

    def download(self, url: str, output_path: str | Path) -> Path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        resp = self._http.get(url)
        resp.raise_for_status()
        output_path.write_bytes(resp.content)
        return output_path

    def close(self) -> None:
        self._http.close()

    # ------------------------------------------------------------------
    # Async API
    # ------------------------------------------------------------------

    async def generate_image_async(
        self,
        prompt: str,
        model: str = "gemini-2.5-flash-image",
        aspect_ratio: str = "9:16",
        resolution: str = "720p",
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate an image asynchronously.

        The Google ``genai`` SDK does not expose a native async method, so the
        synchronous call is wrapped in ``asyncio.to_thread`` to keep the event
        loop unblocked.
        """
        image_size = _IMAGE_SIZE_MAP.get(resolution, "1K")
        resolved_model = _resolve_model(model)
        request_id = str(uuid.uuid4())

        log.info("google async → %s (%s, %s)", resolved_model, aspect_ratio, image_size)

        def _sync_call() -> Any:
            @retry_policy()
            def _inner():
                return self._client.models.generate_content(
                    model=resolved_model,
                    contents=prompt,
                    config=types.GenerateContentConfig(
                        response_modalities=["IMAGE"],
                        image_config=types.ImageConfig(
                            aspect_ratio=aspect_ratio,
                            image_size=image_size,
                        ),
                    ),
                )
            return _inner()

        response = await asyncio.to_thread(_sync_call)
        return _extract_result(response, request_id)

    async def download_async(self, url: str, output_path: str | Path) -> Path:
        """Download a file asynchronously."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        async_http = self._get_async_http()
        resp = await async_http.get(url)
        resp.raise_for_status()
        output_path.write_bytes(resp.content)
        return output_path

    async def aclose(self) -> None:
        """Close all async resources."""
        if self._async_http is not None:
            await self._async_http.aclose()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.aclose()
