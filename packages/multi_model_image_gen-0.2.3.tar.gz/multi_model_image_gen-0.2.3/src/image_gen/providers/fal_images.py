"""fal.ai image provider — 600+ models via fal_client.SyncClient / AsyncClient."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

import fal_client
import httpx

from image_gen.config import fal_key
from image_gen.providers._retry import retry_policy
from image_gen.providers.result import GenerationResult

log = logging.getLogger(__name__)

_SIZE_MAP: dict[str, dict[str, int]] = {
    "9:16": {"width": 1080, "height": 1920},
    "16:9": {"width": 1920, "height": 1080},
    "1:1": {"width": 1080, "height": 1080},
}

_SHORTHAND: dict[str, str] = {
    "flux": "fal-ai/flux/dev",
    "flux-schnell": "fal-ai/flux/schnell",
    "flux-pro": "fal-ai/flux-pro",
    "seedream": "fal-ai/bytedance/seedream/v4/text-to-image",
    "seedream-4.5": "fal-ai/bytedance/seedream/v4/text-to-image",
    "ideogram": "fal-ai/ideogram/v2",
    "recraft": "fal-ai/recraft-v3",
    "nb2-fal": "fal-ai/gemini-flash-image",
    "nb-pro-fal": "fal-ai/gemini-flash-image/pro",
    "imagen4-fal": "fal-ai/imagen4/preview",
}

_DEFAULT_TIMEOUT = httpx.Timeout(connect=5.0, read=60.0, write=10.0, pool=5.0)


def _resolve_model(model: str) -> str:
    return _SHORTHAND.get(model, model)


def _raise_if_loop_running(client_name: str) -> None:
    """Raise a clear error if called from inside a running event loop."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return  # No running loop — safe to proceed synchronously.
    raise RuntimeError(
        f"{client_name}.generate_image() called from inside a running asyncio event loop. "
        f"Use 'await client.generate_image_async(...)' instead to avoid blocking the loop."
    )


def _build_result(result: dict[str, Any]) -> GenerationResult:
    """Convert a fal_client result dict to a GenerationResult."""
    if result.get("has_nsfw_concepts") and any(result.get("has_nsfw_concepts", [])):
        return GenerationResult(
            request_id=result.get("request_id", ""),
            status="blocked",
            raw={**result, "reason": "nsfw"},
        )

    images = result.get("images", [])
    if not images:
        return GenerationResult(
            request_id=result.get("request_id", ""),
            status="failed",
            raw=result,
        )

    return GenerationResult(
        request_id=result.get("request_id", ""),
        status="completed",
        image_url=images[0]["url"],
        raw=result,
    )


class FalImageClient:
    """Synchronous/async client for fal.ai image generation models.

    The sync ``generate_image`` uses :class:`fal_client.SyncClient`.
    The async ``generate_image_async`` uses :class:`fal_client.AsyncClient`.
    Calling ``generate_image`` from within a running event loop raises a
    :class:`RuntimeError` with a clear migration message.
    """

    def __init__(self, api_key: str | None = None):
        api_key = api_key or fal_key()
        if not api_key:
            raise ValueError("FAL_KEY not set and no api_key passed.")
        self._api_key = api_key
        self._fal = fal_client.SyncClient(key=api_key)
        self._http = httpx.Client(timeout=_DEFAULT_TIMEOUT)
        # Lazy async clients — created on first use.
        self._async_fal: fal_client.AsyncClient | None = None
        self._async_http: httpx.AsyncClient | None = None

    # ------------------------------------------------------------------
    # Lazy async client accessors
    # ------------------------------------------------------------------

    def _get_async_fal(self) -> fal_client.AsyncClient:
        if self._async_fal is None:
            self._async_fal = fal_client.AsyncClient(key=self._api_key)
        return self._async_fal

    def _get_async_http(self) -> httpx.AsyncClient:
        if self._async_http is None:
            self._async_http = httpx.AsyncClient(timeout=_DEFAULT_TIMEOUT)
        return self._async_http

    # ------------------------------------------------------------------
    # Sync API
    # ------------------------------------------------------------------

    def generate_image(
        self,
        prompt: str,
        model: str = "fal-ai/flux/dev",
        aspect_ratio: str = "9:16",
        resolution: str = "720p",
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate an image synchronously.

        Raises ``RuntimeError`` if called from inside a running event loop —
        use ``generate_image_async`` instead.
        """
        _raise_if_loop_running("FalImageClient")
        image_size = _SIZE_MAP.get(aspect_ratio, _SIZE_MAP["9:16"])
        model = _resolve_model(model)

        arguments: dict[str, Any] = {
            "prompt": prompt,
            "image_size": image_size,
            **kwargs,
        }

        log.info("fal.ai → %s (%dx%d)", model, image_size["width"], image_size["height"])

        def _on_queue_update(update):
            if isinstance(update, fal_client.InProgress):
                for entry in update.logs:
                    log.debug("fal: %s", entry["message"])

        @retry_policy()
        def _call():
            return self._fal.subscribe(
                model,
                arguments=arguments,
                with_logs=True,
                on_queue_update=_on_queue_update,
            )

        result = _call()
        return _build_result(result)

    def download(self, url: str, output_path: str | Path) -> Path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        resp = self._http.get(url)
        resp.raise_for_status()
        output_path.write_bytes(resp.content)
        return output_path

    def close(self) -> None:
        self._http.close()

    # ------------------------------------------------------------------
    # Async API
    # ------------------------------------------------------------------

    async def generate_image_async(
        self,
        prompt: str,
        model: str = "fal-ai/flux/dev",
        aspect_ratio: str = "9:16",
        resolution: str = "720p",
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate an image asynchronously using :class:`fal_client.AsyncClient`."""
        image_size = _SIZE_MAP.get(aspect_ratio, _SIZE_MAP["9:16"])
        resolved_model = _resolve_model(model)
        async_fal = self._get_async_fal()

        arguments: dict[str, Any] = {
            "prompt": prompt,
            "image_size": image_size,
            **kwargs,
        }

        log.info("fal.ai async → %s (%dx%d)", resolved_model, image_size["width"], image_size["height"])

        def _on_queue_update(update):
            if isinstance(update, fal_client.InProgress):
                for entry in update.logs:
                    log.debug("fal: %s", entry["message"])

        result = await async_fal.subscribe(
            resolved_model,
            arguments=arguments,
            with_logs=True,
            on_queue_update=_on_queue_update,
        )

        return _build_result(result)

    async def download_async(self, url: str, output_path: str | Path) -> Path:
        """Download a file asynchronously."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        async_http = self._get_async_http()
        resp = await async_http.get(url)
        resp.raise_for_status()
        output_path.write_bytes(resp.content)
        return output_path

    async def aclose(self) -> None:
        """Close all async resources."""
        if self._async_http is not None:
            await self._async_http.aclose()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.aclose()
