"""Multi-provider fallback router for image generation.

Usage::

    from image_gen.router import Router, FallbackExhausted

    result = Router(primary="fal", fallbacks=["openai"]).generate(
        "a neon-lit Tokyo alley at night",
        model="flux",
    )
"""

from __future__ import annotations

import logging
from typing import Any

from image_gen import metrics
from image_gen.observability import StructuredLogger
from image_gen.providers import GenerationResult, get_provider

log = logging.getLogger(__name__)
_slog = StructuredLogger(__name__)


class FallbackExhausted(Exception):
    """Raised when every provider in the chain has failed after retries.

    Attributes:
        errors: List of ``(provider_name, exception)`` pairs in the order they
                were attempted.
    """

    def __init__(self, errors: list[tuple[str, Exception]]) -> None:
        self.errors = errors
        summary = "; ".join(
            f"{name}: {type(exc).__name__}({exc})" for name, exc in errors
        )
        super().__init__(f"All providers exhausted. Errors: [{summary}]")


class Router:
    """Try *primary* first, then each provider in *fallbacks* in order.

    Each provider's inner SDK call is already wrapped with ``@retry_policy()``,
    so individual transient failures are retried transparently before the Router
    moves on to the next provider.

    Args:
        primary:   Name of the first provider to attempt (e.g. ``"fal"``).
        fallbacks: Optional list of provider names to try if *primary* fails
                   permanently (after its retries are exhausted).
    """

    def __init__(self, primary: str, fallbacks: list[str] | None = None) -> None:
        self.primary = primary
        self.fallbacks: list[str] = fallbacks or []

    def generate(
        self,
        prompt: str,
        *,
        correlation_id: str | None = None,
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate an image, falling back to the next provider on failure.

        Args:
            prompt: Text prompt.
            correlation_id: Optional caller-supplied correlation/trace ID
                forwarded to structured log records during fallback transitions.
            **kwargs: Passed through to the provider's ``generate_image``.

        Returns:
            A ``GenerationResult`` from the first provider that succeeds.

        Raises:
            FallbackExhausted: If every provider in the chain fails.
        """
        errors: list[tuple[str, Exception]] = []
        providers = [self.primary, *self.fallbacks]
        prev_provider: str | None = None

        for attempt_num, provider_name in enumerate(providers, start=1):
            client = get_provider(provider_name)
            try:
                _slog.info(
                    "router: attempting provider",
                    provider=provider_name,
                    attempt=attempt_num,
                    total=len(providers),
                    fallback_used=attempt_num > 1,
                    correlation_id=correlation_id,
                )

                # Log and record metric for fallback transitions
                if prev_provider is not None:
                    _slog.info(
                        "router: fallback transition",
                        primary=prev_provider,
                        fallback=provider_name,
                        fallback_used=True,
                        correlation_id=correlation_id,
                    )
                    metrics.record_fallback(primary=prev_provider, fallback=provider_name)

                result = client.generate_image(prompt=prompt, **kwargs)
                _slog.info(
                    "router: success",
                    provider=provider_name,
                    status=result.status,
                    fallback_used=attempt_num > 1,
                    correlation_id=correlation_id,
                )
                return result
            except Exception as exc:
                _slog.warning(
                    "router: provider failed",
                    provider=provider_name,
                    error_class=type(exc).__name__,
                    error=str(exc),
                    fallback_used=attempt_num > 1,
                    correlation_id=correlation_id,
                )
                errors.append((provider_name, exc))
                prev_provider = provider_name
            finally:
                client.close()

        raise FallbackExhausted(errors)


    async def generate_async(
        self,
        prompt: str,
        *,
        correlation_id: str | None = None,
        **kwargs: Any,
    ) -> GenerationResult:
        """Generate an image asynchronously, falling back to the next provider on failure.

        Iterates providers sequentially (not concurrently), so that the first
        successful provider wins.  Within each provider, the call is fully async
        (no thread blocking).

        Args:
            prompt: Text prompt.
            correlation_id: Optional caller-supplied correlation/trace ID.
            **kwargs: Passed through to the provider's ``generate_image_async``.

        Returns:
            A ``GenerationResult`` from the first provider that succeeds.

        Raises:
            FallbackExhausted: If every provider in the chain fails.
        """
        errors: list[tuple[str, Exception]] = []
        providers = [self.primary, *self.fallbacks]
        prev_provider: str | None = None

        for attempt_num, provider_name in enumerate(providers, start=1):
            client = get_provider(provider_name)
            try:
                _slog.info(
                    "router async: attempting provider",
                    provider=provider_name,
                    attempt=attempt_num,
                    total=len(providers),
                    fallback_used=attempt_num > 1,
                    correlation_id=correlation_id,
                )

                if prev_provider is not None:
                    _slog.info(
                        "router async: fallback transition",
                        primary=prev_provider,
                        fallback=provider_name,
                        fallback_used=True,
                        correlation_id=correlation_id,
                    )
                    metrics.record_fallback(primary=prev_provider, fallback=provider_name)

                result = await client.generate_image_async(prompt=prompt, **kwargs)
                _slog.info(
                    "router async: success",
                    provider=provider_name,
                    status=result.status,
                    fallback_used=attempt_num > 1,
                    correlation_id=correlation_id,
                )
                return result
            except Exception as exc:
                _slog.warning(
                    "router async: provider failed",
                    provider=provider_name,
                    error_class=type(exc).__name__,
                    error=str(exc),
                    fallback_used=attempt_num > 1,
                    correlation_id=correlation_id,
                )
                errors.append((provider_name, exc))
                prev_provider = provider_name
            finally:
                await client.aclose()

        raise FallbackExhausted(errors)


def generate_with_fallback(
    prompt: str,
    primary: str,
    fallbacks: list[str],
    **kwargs: Any,
) -> GenerationResult:
    """Convenience wrapper around ``Router.generate``."""
    return Router(primary=primary, fallbacks=fallbacks).generate(prompt, **kwargs)
