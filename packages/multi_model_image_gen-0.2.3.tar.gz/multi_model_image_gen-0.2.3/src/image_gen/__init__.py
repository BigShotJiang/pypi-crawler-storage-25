"""Multi-model image generation — unified interface over OpenAI, fal.ai, Google, Higgsfield.

Typical use::

    from image_gen import generate

    result = generate(
        prompt="a neon-lit Tokyo alley at night",
        model="fal:flux/dev",
        output="out.png",
    )

Models are addressed with aisuite-style ``"provider:model"`` strings::

    generate(prompt="...", model="fal:flux/dev")
    generate(prompt="...", model="openai:gpt-image-1")
    generate(prompt="...", model="higgsfield:higgsfield-ai/soul/standard")

Bare shorthands (no colon) are still accepted and routed automatically::

    generate(prompt="...", model="flux")   # routes to fal via infer_provider

Multi-provider fallback::

    from image_gen import generate

    result = generate(
        prompt="...",
        model="fal:flux/dev",
        fallbacks=["openai", "higgsfield"],
    )

Or pick a provider client directly::

    from image_gen import FalImageClient

    with FalImageClient() as client:
        result = client.generate_image(prompt="...", model="fal-ai/flux/dev")

Third-party plugin providers can be registered at runtime::

    from image_gen import register_provider
    from my_provider import MyClient

    register_provider("my-provider", MyClient)
    result = generate(prompt="...", model="my-provider:my-model")
"""

from __future__ import annotations

import time
from pathlib import Path

from image_gen import metrics as _metrics
from image_gen.observability import logger as _obs_logger
from image_gen.providers import (
    GenerationResult,
    ImageProvider,
    _PROVIDER_REGISTRY,
    _discover_plugins,
    get_provider,
    infer_provider,
    register_provider,
)
from image_gen.providers.fal_images import FalImageClient
from image_gen.providers.google_images import GoogleImageClient
from image_gen.providers.higgsfield import HiggsFieldClient, HiggsFieldError
from image_gen.providers.openai_images import OpenAIImageClient
from image_gen.router import FallbackExhausted, Router

__version__ = "0.2.0"

__all__ = [
    "generate",
    "generate_async",
    "get_provider",
    "infer_provider",
    "register_provider",
    "GenerationResult",
    "ImageProvider",
    "FalImageClient",
    "GoogleImageClient",
    "HiggsFieldClient",
    "HiggsFieldError",
    "OpenAIImageClient",
    "Router",
    "FallbackExhausted",
    "__version__",
]


def _is_known_provider(name: str) -> bool:
    """Return True if *name* is a registered provider (built-in or plugin).

    Checks the runtime registry first (O(1)), then the cached entry-point
    discovery results so plugin-registered names are always recognised without
    a full re-scan.
    """
    if name in _PROVIDER_REGISTRY:
        return True
    plugins = _discover_plugins()
    return name in plugins


def generate(
    prompt: str,
    model: str = "flux",
    output: str | Path | None = None,
    *,
    fallbacks: list[str] | None = None,
    aspect_ratio: str = "9:16",
    resolution: str = "720p",
    correlation_id: str | None = None,
    **kwargs,
) -> GenerationResult:
    """Generate an image and optionally save it to ``output``.

    Models are addressed with aisuite-style ``"provider:model"`` strings.
    A bare shorthand (no colon) is routed automatically via ``infer_provider``.

    Plugin providers registered via :func:`register_provider` or installed as
    ``image_gen.providers`` entry-point packages are supported transparently —
    ``generate(model="runway:gen-3")`` works after registering a ``"runway"``
    provider.

    Args:
        prompt: Text prompt.
        model: One of:

            * ``"provider:model"`` — explicit routing, e.g. ``"fal:flux/dev"``,
              ``"openai:gpt-image-1"``,
              ``"higgsfield:higgsfield-ai/soul/standard"``,
              ``"runway:gen-3"`` (third-party plugin).
              The part after the colon is forwarded verbatim to the provider client.
            * Bare shorthand or full provider ID (no colon), e.g. ``"flux"``,
              ``"nb-pro"``, ``"higgsfield-ai/soul/standard"`` — provider is
              inferred via ``infer_provider``.

        output: If given, write the image to this path on ``status == "completed"``.
        fallbacks: Optional list of provider names (e.g. ``["openai", "higgsfield"]``)
            to attempt in order if the primary provider fails after retries. When
            provided, delegates to ``Router(primary=..., fallbacks=...).generate``.
        aspect_ratio: ``9:16``, ``16:9``, or ``1:1``.
        resolution: ``720p``, ``1080p``, or ``4k``.
        **kwargs: Passed through to the provider's ``generate_image``.

    Returns:
        A ``GenerationResult``. On success, exactly one of ``image_bytes`` or
        ``image_url`` / ``video_url`` is set.

    Raises:
        ValueError: If the provider prefix in ``"provider:model"`` syntax is not
            a known registered provider.
        FallbackExhausted: If ``fallbacks`` are provided and every provider fails.
    """
    if ":" in model:
        provider_name, model_id = model.split(":", 1)
        if not _is_known_provider(provider_name):
            raise ValueError(
                f"Unknown provider {provider_name!r} in model string {model!r}. "
                f"Known providers: {sorted(_PROVIDER_REGISTRY)}. "
                "Register a new provider with register_provider() or install a "
                "package that declares an 'image_gen.providers' entry point."
            )
        _explicit_prefix = True
    else:
        provider_name = infer_provider(model)
        model_id = model
        _explicit_prefix = False

    # Pre-flight capability validation via the catalog (Phase 2).  Only applied
    # when the caller used a bare shorthand — explicit "provider:model" strings
    # bypass catalog resolution and are forwarded verbatim.
    _entry = None
    if not _explicit_prefix:
        try:
            from image_gen.providers.catalog import (
                resolve as _catalog_resolve,
                validate as _catalog_validate,
            )

            _entry = _catalog_resolve(model_id)
            if _entry is not None:
                _catalog_validate(_entry, aspect_ratio, resolution)
                model_id = _entry.model_id
        except ImportError:
            pass

    def _emit(result: GenerationResult, latency_ms: float, fallback_used: bool) -> None:
        bytes_out = len(result.image_bytes) if result.image_bytes is not None else 0
        cost = result.cost_usd if result.cost_usd is not None else (
            _entry.cost_usd if _entry is not None else None
        )
        _obs_logger.info(
            "image_gen.request",
            request_id=result.request_id,
            provider=provider_name,
            model=model_id,
            latency_ms=round(latency_ms, 2),
            status=result.status,
            bytes_out=bytes_out,
            cost_usd=cost,
            retry_count=0,
            fallback_used=fallback_used,
            correlation_id=correlation_id,
        )
        _metrics.record_request(
            provider=provider_name,
            model=model_id,
            status=result.status,
            latency_ms=latency_ms,
            cost_usd=cost,
        )
        if correlation_id is not None:
            if result.raw is None:
                result.raw = {}
            result.raw["correlation_id"] = correlation_id

    # When fallbacks are requested, delegate entirely to the Router which handles
    # provider lifecycle (open / close) and structured logging internally.
    if fallbacks is not None:
        t0 = time.monotonic()
        result = Router(primary=provider_name, fallbacks=fallbacks).generate(
            prompt,
            model=model_id,
            aspect_ratio=aspect_ratio,
            resolution=resolution,
            **kwargs,
        )
        _emit(result, (time.monotonic() - t0) * 1000.0, fallback_used=True)
        if output is not None and result.status == "completed":
            out_path = Path(output)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            if result.image_bytes is not None:
                out_path.write_bytes(result.image_bytes)
            # Note: url-based output not written here since router closed the client.
            # Callers that need URL download should use Router directly.
        return result

    client = get_provider(provider_name)
    try:
        t0 = time.monotonic()
        result = client.generate_image(
            prompt=prompt,
            model=model_id,
            aspect_ratio=aspect_ratio,
            resolution=resolution,
            **kwargs,
        )
        _emit(result, (time.monotonic() - t0) * 1000.0, fallback_used=False)
        if output is not None and result.status == "completed":
            out_path = Path(output)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            if result.image_bytes is not None:
                out_path.write_bytes(result.image_bytes)
            elif result.image_url:
                client.download(result.image_url, out_path)
        return result
    finally:
        client.close()


async def generate_async(
    prompt: str,
    model: str = "flux",
    output: str | Path | None = None,
    *,
    fallbacks: list[str] | None = None,
    aspect_ratio: str = "9:16",
    resolution: str = "720p",
    correlation_id: str | None = None,
    **kwargs,
) -> GenerationResult:
    """Async counterpart of :func:`generate` — uses async provider clients end-to-end.

    Models are addressed with aisuite-style ``"provider:model"`` strings, exactly
    as in the sync :func:`generate`.  All four built-in providers have async
    implementations; the async path never blocks the event loop.

    Args:
        prompt: Text prompt.
        model: ``"provider:model"`` string or bare shorthand — same rules as
            :func:`generate`.
        output: If given, write the image to this path on ``status == "completed"``.
        fallbacks: Optional list of provider names to attempt in order if the
            primary provider fails.  Delegates to ``Router.generate_async``.
        aspect_ratio: ``9:16``, ``16:9``, or ``1:1``.
        resolution: ``720p``, ``1080p``, or ``4k``.
        **kwargs: Passed through to the provider's ``generate_image_async``.

    Returns:
        A ``GenerationResult``. On success, exactly one of ``image_bytes`` or
        ``image_url`` / ``video_url`` is set.

    Raises:
        ValueError: If the provider prefix is not a known registered provider.
        FallbackExhausted: If ``fallbacks`` are provided and every provider fails.
    """
    if ":" in model:
        provider_name, model_id = model.split(":", 1)
        if not _is_known_provider(provider_name):
            raise ValueError(
                f"Unknown provider {provider_name!r} in model string {model!r}. "
                f"Known providers: {sorted(_PROVIDER_REGISTRY)}. "
                "Register a new provider with register_provider() or install a "
                "package that declares an 'image_gen.providers' entry point."
            )
    else:
        provider_name = infer_provider(model)
        model_id = model

    if fallbacks is not None:
        result = await Router(primary=provider_name, fallbacks=fallbacks).generate_async(
            prompt,
            model=model_id,
            aspect_ratio=aspect_ratio,
            resolution=resolution,
            **kwargs,
        )
        if output is not None and result.status == "completed":
            out_path = Path(output)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            if result.image_bytes is not None:
                out_path.write_bytes(result.image_bytes)
        return result

    client = get_provider(provider_name)
    try:
        result = await client.generate_image_async(
            prompt=prompt,
            model=model_id,
            aspect_ratio=aspect_ratio,
            resolution=resolution,
            **kwargs,
        )
        if output is not None and result.status == "completed":
            out_path = Path(output)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            if result.image_bytes is not None:
                out_path.write_bytes(result.image_bytes)
            elif result.image_url:
                await client.download_async(result.image_url, out_path)
        return result
    finally:
        await client.aclose()
