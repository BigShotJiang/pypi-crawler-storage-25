use calamine::{Data, Reader, open_workbook_auto};
use std::io::Cursor;

pub struct ParsedSheet {
    pub name: String,
    pub values: Vec<Vec<String>>,
    pub nfs: Vec<Vec<String>>,
    pub rows: usize,
    pub cols: usize,
}

fn float_to_string(f: f64) -> String {
    if f == f.trunc() && f.abs() < 1e15 {
        format!("{}", f as i64)
    } else {
        f.to_string()
    }
}

fn excel_serial_to_date_string(serial: f64) -> String {
    // Excel epoch: 1899-12-30 (accounting for the 1900 leap year bug)
    let days = serial.trunc() as i32;
    // Convert serial days to year/month/day using a simple algorithm
    // Excel day 1 = 1900-01-01, but we use epoch 1899-12-30
    // so day 2 = 1900-01-01, etc.
    let (y, m, d) = serial_to_ymd(days);
    let frac = serial.fract();
    if frac.abs() < 1e-10 {
        format!("{:04}-{:02}-{:02}", y, m, d)
    } else {
        let total_secs = (frac * 86400.0).round() as u32;
        let h = total_secs / 3600;
        let mn = (total_secs % 3600) / 60;
        let s = total_secs % 60;
        format!("{:04}-{:02}-{:02} {:02}:{:02}:{:02}", y, m, d, h, mn, s)
    }
}

fn serial_to_ymd(serial: i32) -> (i32, u32, u32) {
    // Excel serial date: 1 = 1900-01-01
    // Excel has a bug: it thinks 1900 was a leap year (serial 60 = Feb 29, 1900)
    let adjusted = if serial > 60 { serial - 1 } else { serial };
    // Now adjusted serial 1 = Jan 1, 1900 with no leap year bug
    // Convert to days since a known epoch using a reliable algorithm
    // Jan 1, 1900 = Julian Day Number 2415021
    let jdn = 2415020 + adjusted as i64;
    // Convert JDN to Gregorian date (algorithm from Wikipedia / Meeus)
    let a = jdn + 32044;
    let b = (4 * a + 3) / 146097;
    let c = a - (146097 * b) / 4;
    let d = (4 * c + 3) / 1461;
    let e = c - (1461 * d) / 4;
    let m = (5 * e + 2) / 153;
    let day = (e - (153 * m + 2) / 5 + 1) as u32;
    let month = (m + 3 - 12 * (m / 10)) as u32;
    let year = (100 * b + d - 4800 + m / 10) as i32;
    (year, month, day)
}

fn datetime_to_string(serial: f64) -> String {
    excel_serial_to_date_string(serial)
}

fn data_to_string(d: &Data) -> String {
    match d {
        Data::Float(f) => float_to_string(*f),
        Data::DateTime(dt) => datetime_to_string(dt.as_f64()),
        Data::Int(i) => i.to_string(),
        Data::String(s) => s.clone(),
        Data::Bool(b) => if *b { "True".to_string() } else { "False".to_string() },
        Data::DateTimeIso(s) | Data::DurationIso(s) => s.clone(),
        Data::Empty | Data::Error(_) => String::new(),
    }
}

fn extract_sheets<RS: std::io::Read + std::io::Seek, R: Reader<RS>>(
    wb: &mut R,
) -> Result<Vec<ParsedSheet>, String>
where
    R::Error: std::fmt::Display,
{
    let names: Vec<String> = wb.sheet_names().to_vec();
    let mut sheets = Vec::new();
    for name in &names {
        let range = wb
            .worksheet_range(name)
            .map_err(|e| format!("Failed to read sheet '{}': {}", name, e))?;
        let (rows, cols) = range.get_size();
        let mut values = vec![vec![String::new(); cols]; rows];
        let mut nfs = vec![vec!["None".to_string(); cols]; rows];
        for (r, row) in range.rows().enumerate() {
            for (c, cell) in row.iter().enumerate() {
                values[r][c] = data_to_string(cell);
                // Set NFS for DateTime cells so the type detector uses the format
                // string as the label (matching SpreadsheetLLM/openpyxl behavior)
                if matches!(cell, Data::DateTime(_)) {
                    nfs[r][c] = "yyyy-mm-dd".to_string();
                }
            }
        }
        sheets.push(ParsedSheet { name: name.clone(), values, nfs, rows, cols });
    }
    Ok(sheets)
}

fn get_names<RS: std::io::Read + std::io::Seek>(
    wb: &mut impl Reader<RS>,
) -> Vec<String> {
    wb.sheet_names().to_vec()
}

pub fn open_from_path(path: &str) -> Result<Vec<ParsedSheet>, String> {
    let mut wb = open_workbook_auto(path).map_err(|e| format!("Cannot open '{}': {}", path, e))?;
    extract_sheets(&mut wb)
}

pub fn open_from_bytes(bytes: &[u8], fmt: &str) -> Result<Vec<ParsedSheet>, String> {
    let cursor = Cursor::new(bytes);
    match fmt {
        "xlsx" => {
            let mut wb: calamine::Xlsx<_> =
                Reader::new(cursor).map_err(|e| format!("xlsx parse error: {}", e))?;
            extract_sheets(&mut wb)
        }
        "xlsb" => {
            let mut wb: calamine::Xlsb<_> =
                Reader::new(cursor).map_err(|e| format!("xlsb parse error: {}", e))?;
            extract_sheets(&mut wb)
        }
        _ => Err(format!("Unsupported format '{}', use 'xlsx' or 'xlsb'", fmt)),
    }
}

pub fn sheet_names_from_path(path: &str) -> Result<Vec<String>, String> {
    let mut wb = open_workbook_auto(path).map_err(|e| format!("Cannot open '{}': {}", path, e))?;
    Ok(get_names(&mut wb))
}

pub fn sheet_names_from_bytes(bytes: &[u8], fmt: &str) -> Result<Vec<String>, String> {
    let cursor = Cursor::new(bytes);
    match fmt {
        "xlsx" => {
            let mut wb: calamine::Xlsx<_> =
                Reader::new(cursor).map_err(|e| format!("xlsx parse error: {}", e))?;
            Ok(get_names(&mut wb))
        }
        "xlsb" => {
            let mut wb: calamine::Xlsb<_> =
                Reader::new(cursor).map_err(|e| format!("xlsb parse error: {}", e))?;
            Ok(get_names(&mut wb))
        }
        _ => Err(format!("Unsupported format '{}', use 'xlsx' or 'xlsb'", fmt)),
    }
}
