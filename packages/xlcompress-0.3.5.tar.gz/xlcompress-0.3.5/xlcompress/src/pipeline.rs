use crate::parser::ParsedSheet;
use compress_aggregation::{aggregate_similar_areas, areas_to_tuples, col_num_to_letter, tuples_to_input_string};
use heuristic_detection::{detect_boundaries, SheetData};
use std::collections::HashMap;

pub struct CompressOptions {
    pub mode: String,
    pub structural: bool,
    pub structural_k: usize,
}

pub struct CompressedSheet {
    pub name: String,
    pub original: String,
    pub compressed: String,
    pub original_tokens: usize,
    pub compressed_tokens: usize,
}

pub fn compress_sheet(sheet: &ParsedSheet, opts: &CompressOptions) -> Option<CompressedSheet> {
    if sheet.rows == 0 || sheet.cols == 0 {
        return None;
    }

    // Build vanilla original
    let mut original_lines = Vec::new();
    for (r, row) in sheet.values.iter().enumerate() {
        for (c, val) in row.iter().enumerate() {
            if !val.is_empty() {
                let col_letter = col_num_to_letter((c + 1) as u32);
                original_lines.push(format!("|{}{}, {}|", col_letter, r + 1, val));
            }
        }
    }
    let original = original_lines.join("\n");

    // Determine working values/nfs (possibly filtered by structural boundaries)
    let mut values = sheet.values.clone();
    let mut nfs = sheet.nfs.clone();

    if opts.structural {
        let sheet_data = SheetData {
            rows: sheet.rows,
            cols: sheet.cols,
            values: sheet.values.clone(),
            nfs: sheet.nfs.clone(),
            has_color: vec![vec![false; sheet.cols]; sheet.rows],
            has_formula: vec![vec![false; sheet.cols]; sheet.rows],
            borders: vec![vec![[false; 4]; sheet.cols]; sheet.rows],
            merged: vec![],
        };
        let boundaries = detect_boundaries(&sheet_data);
        if !boundaries.is_empty() {
            let k = opts.structural_k;
            let mut keep_rows = vec![false; sheet.rows];
            let mut keep_cols = vec![false; sheet.cols];
            for b in &boundaries {
                let top = (b.top - 1).max(0) as usize;
                let bottom = (b.bottom - 1).max(0) as usize;
                let left = (b.left - 1).max(0) as usize;
                let right = (b.right - 1).max(0) as usize;
                for r in top.saturating_sub(k)..=(bottom + k).min(sheet.rows - 1) {
                    keep_rows[r] = true;
                }
                for c in left.saturating_sub(k)..=(right + k).min(sheet.cols - 1) {
                    keep_cols[c] = true;
                }
            }
            // Count non-empty cells before and after filtering.
            // If structural compression drops >50% of non-empty cells, skip it —
            // the boundary detector likely misidentified the data region.
            let original_nonempty: usize = sheet.values.iter()
                .flat_map(|row| row.iter())
                .filter(|v| !v.is_empty())
                .count();
            let mut kept_nonempty: usize = 0;
            for r in 0..sheet.rows {
                if !keep_rows[r] { continue; }
                for c in 0..sheet.cols {
                    if keep_cols[c] && !sheet.values[r][c].is_empty() {
                        kept_nonempty += 1;
                    }
                }
            }
            let keep_ratio = if original_nonempty > 0 { kept_nonempty as f64 / original_nonempty as f64 } else { 1.0 };
            if keep_ratio >= 0.5 {
                let kept_rows: Vec<usize> = (0..sheet.rows).filter(|r| keep_rows[*r]).collect();
                let kept_cols: Vec<usize> = (0..sheet.cols).filter(|c| keep_cols[*c]).collect();
                values = kept_rows
                    .iter()
                    .map(|&r| kept_cols.iter().map(|&c| sheet.values[r][c].clone()).collect())
                    .collect();
                nfs = kept_rows
                    .iter()
                    .map(|&r| kept_cols.iter().map(|&c| sheet.nfs[r][c].clone()).collect())
                    .collect();
            }
            // else: structural compression too aggressive, use full grid
        }
    }

    let compressed = match opts.mode.as_str() {
        "vanilla" => original.clone(),
        "inverted" => {
            let mut map: HashMap<String, Vec<String>> = HashMap::new();
            for (r, row) in values.iter().enumerate() {
                for (c, val) in row.iter().enumerate() {
                    if !val.is_empty() {
                        let col_letter = col_num_to_letter((c + 1) as u32);
                        let addr = format!("{}{}", col_letter, r + 1);
                        map.entry(val.clone()).or_default().push(addr);
                    }
                }
            }
            serde_json::to_string_pretty(&map).unwrap_or_default()
        }
        _ => {
            // aggregated (default)
            let areas = aggregate_similar_areas(&values, &nfs);
            let tuples = areas_to_tuples(&areas, 0, 0);
            tuples_to_input_string(&tuples)
        }
    };

    let original_tokens = (original.len() / 4).max(1);
    let compressed_tokens = (compressed.len() / 4).max(1);

    Some(CompressedSheet {
        name: sheet.name.clone(),
        original,
        compressed,
        original_tokens,
        compressed_tokens,
    })
}
