"""Event dependency examples."""
