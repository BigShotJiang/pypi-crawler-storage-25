#!/usr/bin/env python3
"""SessionStart hook: spawn tmux pane with office animation."""
import json
import os
import subprocess
import sys

from validate import (
    validate_session_id, sock_path, pane_path,
    kill_all_elves_panes, cleanup_all,
)

CONFIG_PATH = os.path.expanduser("~/.config/agent-elves/config.json")


def _load_autostart() -> str:
    """Load autostart preference from config. Returns 'auto' or 'manual'."""
    try:
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
            return cfg.get("autostart", "auto")
    except (FileNotFoundError, json.JSONDecodeError):
        return "auto"  # default to auto on first launch


def main() -> None:
    try:
        data = json.load(sys.stdin)
    except (json.JSONDecodeError, ValueError):
        # Compact or other non-standard trigger — no valid JSON on stdin
        print(json.dumps({}))
        sys.exit(0)

    # Skip if triggered by compact (not a real session start)
    trigger = data.get("hook_event_name", "") or data.get("trigger", "")
    if trigger in ("compact", "PreCompact", "PostCompact"):
        print(json.dumps({}))
        sys.exit(0)

    short_id = validate_session_id(data.get("session_id", "default"))

    # Skip if not in tmux
    if not os.environ.get("TMUX"):
        print(json.dumps({}))
        sys.exit(0)

    # Skip if manual mode (user must run /agent-elves-start)
    autostart = _load_autostart()
    if autostart == "manual":
        print(json.dumps({}))
        sys.exit(0)

    # Clean up any stale panes/sockets from previous sessions (best-effort)
    try:
        kill_all_elves_panes()
        cleanup_all()
    except Exception:
        pass

    plugin_root = os.environ.get(
        "CLAUDE_PLUGIN_ROOT",
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    )
    engine_script = os.path.join(plugin_root, "engine", "main.py")
    sp = sock_path(short_id)
    pf = pane_path(short_id)

    # Create pane — pass args as discrete argv elements (no shell interpolation)
    result = subprocess.run(
        [
            "tmux", "split-window",
            "-h", "-l", "40%", "-d",
            "-P", "-F", "#{pane_id}",
            sys.executable, engine_script,
            "--session-id", short_id,
            "--socket", sp,
        ],
        capture_output=True,
        text=True,
    )

    pane_id = result.stdout.strip()
    if pane_id:
        fd = os.open(pf, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(pane_id)

    print(json.dumps({}))
    sys.exit(0)


if __name__ == "__main__":
    main()
