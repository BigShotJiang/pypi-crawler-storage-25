"""Claude Code hooks for Agent Elves."""
