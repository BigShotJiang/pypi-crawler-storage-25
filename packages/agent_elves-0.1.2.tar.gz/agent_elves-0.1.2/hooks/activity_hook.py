#!/usr/bin/env python3
"""PreToolUse/PostToolUse hook: forward events to animation via socket."""
import json
import socket
import sys
import time

from validate import validate_session_id, sock_path

# Only forward these fields from tool_input to avoid leaking sensitive data
SAFE_INPUT_KEYS = (
    "command", "file_path", "pattern", "query", "description",
    "name", "subagent_type", "prompt", "skill", "to",
)


def main() -> None:
    phase = sys.argv[1] if len(sys.argv) > 1 else "pre"
    data = json.load(sys.stdin)
    short_id = validate_session_id(data.get("session_id", "default"))
    sp = sock_path(short_id)

    tool_input = data.get("tool_input", {})
    if not isinstance(tool_input, dict):
        tool_input = {}

    safe_input: dict[str, str] = {}
    for k, v in tool_input.items():
        if k in SAFE_INPUT_KEYS and isinstance(v, str):
            raw = v[:80]
            safe_input[k] = raw + ("..." if len(v) > 80 else "")

    tool_name = str(data.get("tool_name", ""))[:64]

    # Plan mode tools get special event types (only on pre)
    if tool_name == "EnterPlanMode" and phase == "pre":
        msg = {"type": "plan_mode_enter", "ts": time.time()}
    elif tool_name == "ExitPlanMode" and phase == "pre":
        msg = {"type": "plan_mode_exit", "ts": time.time()}
    else:
        msg = {
            "type": f"tool_{phase}",
            "tool": tool_name,
            "input": safe_input,
            "ts": time.time(),
        }

    # For tool_post events, detect if the tool errored
    if phase == "post":
        # Check multiple error indicators
        has_error = False
        if data.get("tool_error"):
            has_error = True
        elif data.get("is_error"):
            has_error = True
        msg["error"] = has_error

    # Send to all active sockets (handles manual-start and session mismatch)
    import glob
    import os
    payload = json.dumps(msg).encode()
    sock_dir = os.path.expanduser("~/.cache/agent-elves")
    targets = glob.glob(os.path.join(sock_dir, "co-*.sock"))
    if not targets:
        targets = [sp]  # fallback to session-specific path
    for target in targets:
        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
            sock.sendto(payload, target)
            sock.close()
        except OSError:
            pass  # Socket not reachable; fine

    sys.exit(0)


if __name__ == "__main__":
    main()
