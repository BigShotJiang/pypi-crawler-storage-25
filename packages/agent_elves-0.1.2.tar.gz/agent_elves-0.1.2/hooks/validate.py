"""Shared validation utilities for hook scripts."""
import os
import re

# session_id: alphanumeric, hyphens, underscores only, max 64 chars
_SESSION_ID_RE = re.compile(r"[A-Za-z0-9_\-]{1,64}")

# Runtime directory for sockets, pane files, crash log (mode 700)
RUNTIME_DIR = os.path.expanduser("~/.cache/agent-elves")


def validate_session_id(sid: str) -> str:
    """Validate and sanitize session_id. Returns safe short_id (max 12 chars)."""
    if not sid or not _SESSION_ID_RE.fullmatch(sid):
        sid = "default"
    return sid[:12]


def runtime_path(filename: str) -> str:
    """Return a safe path under ~/.cache/agent-elves/."""
    os.makedirs(RUNTIME_DIR, mode=0o700, exist_ok=True)
    return os.path.join(RUNTIME_DIR, filename)


def sock_path(short_id: str) -> str:
    return runtime_path(f"co-{short_id}.sock")


def pane_path(short_id: str) -> str:
    return runtime_path(f"co-{short_id}.pane")


def kill_all_elves_panes() -> int:
    """Kill all Agent Elves panes using .pane file records. Returns count killed."""
    import glob
    import subprocess

    killed = 0
    for pf in glob.glob(os.path.join(RUNTIME_DIR, "co-*.pane")):
        try:
            with open(pf) as f:
                pane_id = f.read().strip()
            if pane_id:
                subprocess.run(
                    ["tmux", "kill-pane", "-t", pane_id],
                    capture_output=True,
                )
                killed += 1
        except OSError:
            pass
    return killed


def cleanup_all() -> None:
    """Remove all runtime files (sockets, pane files)."""
    import glob

    for pattern in ["co-*.sock", "co-*.pane"]:
        for path in glob.glob(os.path.join(RUNTIME_DIR, pattern)):
            try:
                os.unlink(path)
            except OSError:
                pass
