#!/usr/bin/env python3
"""SessionEnd hook: trigger outro animation and wait for graceful shutdown."""
import json
import os
import socket
import subprocess
import sys
import time

from validate import validate_session_id, sock_path, pane_path

OUTRO_TIMEOUT = 25  # max seconds to wait for outro animation


def main() -> None:
    data = json.load(sys.stdin)
    short_id = validate_session_id(data.get("session_id", "default"))
    sp = sock_path(short_id)
    pf = pane_path(short_id)

    # Send shutdown to all active sockets (handles manual-start mismatch)
    import glob
    payload = json.dumps({"type": "shutdown"}).encode()
    targets = glob.glob(os.path.join(os.path.dirname(sp), "co-*.sock"))
    if not targets:
        targets = [sp]
    for target in targets:
        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
            sock.sendto(payload, target)
            sock.close()
        except OSError:
            pass

    # Wait for the animation process to finish outro and exit on its own
    pane_id = ""
    try:
        with open(pf) as f:
            pane_id = f.read().strip()
    except (FileNotFoundError, OSError):
        pass

    if pane_id:
        deadline = time.monotonic() + OUTRO_TIMEOUT
        while time.monotonic() < deadline:
            check = subprocess.run(
                ["tmux", "list-panes", "-a", "-F", "#{pane_id}"],
                capture_output=True, text=True,
            )
            if pane_id not in check.stdout:
                break
            time.sleep(0.5)
        else:
            # Timeout: force kill this pane
            subprocess.run(
                ["tmux", "kill-pane", "-t", pane_id],
                capture_output=True,
            )

    # Cleanup only THIS session's runtime files (not other active sessions)
    for f in (sp, pf):
        try:
            os.unlink(f)
        except OSError:
            pass

    print(json.dumps({}))
    sys.exit(0)


if __name__ == "__main__":
    main()
