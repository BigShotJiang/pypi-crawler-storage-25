"""Tests for engine.config — load/save preferences."""
import json
import os
import tempfile
from unittest.mock import patch

from engine.config import load_config, save_config, VALID_THEMES, VALID_LANGS, VALID_OFFICES


class TestConstants:
    def test_valid_themes(self):
        assert "claude" in VALID_THEMES
        assert "kaomoji" in VALID_THEMES

    def test_valid_langs(self):
        assert "en" in VALID_LANGS
        assert "ja" in VALID_LANGS

    def test_valid_offices(self):
        assert "auto" in VALID_OFFICES
        assert "garage" in VALID_OFFICES


class TestLoadConfig:
    def test_defaults_when_no_file(self):
        with patch("engine.config.CONFIG_PATH", "/nonexistent/path/config.json"):
            theme, lang, autostart, office, total, unlocked = load_config()
        assert theme == ""
        assert lang == ""
        assert office == "auto"
        assert total == 0
        assert "garage" in unlocked

    def test_loads_from_file(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"theme": "claude", "lang": "ja", "office": "garage", "total_tasks": 5}, f)
            tmp_path = f.name
        try:
            with patch("engine.config.CONFIG_PATH", tmp_path):
                theme, lang, autostart, office, total, unlocked = load_config()
            assert theme == "claude"
            assert lang == "ja"
            assert total == 5
        finally:
            os.unlink(tmp_path)

    def test_env_overrides_file(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"theme": "kaomoji", "lang": "en"}, f)
            tmp_path = f.name
        try:
            with patch("engine.config.CONFIG_PATH", tmp_path), \
                 patch.dict(os.environ, {"CLAUDE_OFFICE_THEME": "claude"}):
                theme, lang, *_ = load_config()
            assert theme == "claude"  # env overrides file
        finally:
            os.unlink(tmp_path)

    def test_invalid_office_falls_back(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump({"office": "nonexistent_level"}, f)
            tmp_path = f.name
        try:
            with patch("engine.config.CONFIG_PATH", tmp_path):
                _, _, _, office, *_ = load_config()
            assert office == "auto"
        finally:
            os.unlink(tmp_path)


class TestSaveConfig:
    def test_saves_and_loads(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = os.path.join(tmpdir, "config.json")
            with patch("engine.config.CONFIG_PATH", config_path):
                save_config("claude", "en", office="garage", total_tasks=10)
                with open(config_path) as f:
                    cfg = json.load(f)
            assert cfg["theme"] == "claude"
            assert cfg["lang"] == "en"
            assert cfg["total_tasks"] == 10

    def test_preserves_existing_keys(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = os.path.join(tmpdir, "config.json")
            with open(config_path, "w") as f:
                json.dump({"custom_key": "preserved"}, f)
            with patch("engine.config.CONFIG_PATH", config_path):
                save_config("claude", "ja")
                with open(config_path) as f:
                    cfg = json.load(f)
            assert cfg["custom_key"] == "preserved"
            assert cfg["theme"] == "claude"
