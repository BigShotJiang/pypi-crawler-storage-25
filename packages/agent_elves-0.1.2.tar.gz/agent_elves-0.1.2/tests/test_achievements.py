"""Tests for engine.achievements — Achievement dataclass, ACHIEVEMENTS list,
ACHIEVEMENT_MAP, and AchievementTracker behaviour."""
from __future__ import annotations

import json
from types import SimpleNamespace
from unittest.mock import MagicMock, mock_open, patch

import pytest

import engine.achievements as ach_mod
from engine.achievements import (
    ACHIEVEMENT_MAP,
    ACHIEVEMENTS,
    Achievement,
    AchievementTracker,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_REQUIRED_LANGS = {"en", "ja", "zh", "ko"}


def _make_tracker(tmp_path) -> AchievementTracker:
    """Return a fresh AchievementTracker that reads/writes to tmp_path."""
    save_file = tmp_path / "achievements.json"
    with patch.object(ach_mod, "SAVE_PATH", str(save_file)):
        tracker = AchievementTracker()
    # Patch save path on the instance so _save() also writes there
    tracker._save_path = str(save_file)
    return tracker, str(save_file)


def _make_scene(
    completed_count: int = 0,
    office_level: str = "garage",
    characters: list | None = None,
    pomo_count: int = 0,
) -> MagicMock:
    """Build a minimal mock Scene with the attributes checked by AchievementTracker.check()."""
    scene = MagicMock()
    scene.completed_count = completed_count
    scene.office_level = office_level
    scene.characters = characters if characters is not None else []
    scene._pomodoro = MagicMock()
    scene._pomodoro.completed_pomodoros = pomo_count
    return scene


def _make_character(
    peak_consecutive: int = 0,
    is_agent: bool = False,
    state=None,
) -> MagicMock:
    from engine.characters import State

    char = MagicMock()
    char._peak_consecutive = peak_consecutive
    char.is_agent = is_agent
    char.state = state if state is not None else State.IDLE
    return char


# ---------------------------------------------------------------------------
# TestAchievementDataclass
# ---------------------------------------------------------------------------


class TestAchievementDataclass:
    def test_fourteen_achievements(self):
        assert len(ACHIEVEMENTS) == 14

    def test_all_have_four_language_names(self):
        for a in ACHIEVEMENTS:
            assert _REQUIRED_LANGS <= set(a.name.keys()), (
                f"{a.id} missing language keys in name"
            )

    def test_all_have_four_language_descs(self):
        for a in ACHIEVEMENTS:
            assert _REQUIRED_LANGS <= set(a.desc.keys()), (
                f"{a.id} missing language keys in desc"
            )

    def test_achievement_is_frozen(self):
        a = ACHIEVEMENTS[0]
        with pytest.raises((AttributeError, TypeError)):
            a.id = "mutated"  # type: ignore[misc]

    def test_all_have_nonempty_icon(self):
        for a in ACHIEVEMENTS:
            assert a.icon, f"{a.id} has empty icon"


# ---------------------------------------------------------------------------
# TestAchievementMap
# ---------------------------------------------------------------------------


class TestAchievementMap:
    def test_keys_match_ids(self):
        for achievement_id, achievement in ACHIEVEMENT_MAP.items():
            assert achievement_id == achievement.id

    def test_length_matches_achievements_list(self):
        assert len(ACHIEVEMENT_MAP) == len(ACHIEVEMENTS)

    def test_known_ids_present(self):
        expected_ids = {
            "first_task", "task_10", "task_50", "task_100",
            "streak_3", "streak_5",
            "level_up", "level_5", "level_10",
            "pomo_1", "pomo_5",
            "night_owl", "smith_visit", "high_five",
        }
        assert set(ACHIEVEMENT_MAP.keys()) == expected_ids


# ---------------------------------------------------------------------------
# TestAchievementTrackerInit
# ---------------------------------------------------------------------------


class TestAchievementTrackerInit:
    def test_starts_with_no_unlocked(self, tmp_path):
        tracker, _ = _make_tracker(tmp_path)
        assert tracker.unlocked == {}

    def test_loads_existing_save(self, tmp_path):
        save_file = tmp_path / "achievements.json"
        save_file.write_text(json.dumps({"unlocked": {"first_task": 1234567890.0}}))
        with patch.object(ach_mod, "SAVE_PATH", str(save_file)):
            tracker = AchievementTracker()
        assert "first_task" in tracker.unlocked

    def test_handles_missing_file_gracefully(self, tmp_path):
        missing = tmp_path / "nonexistent" / "achievements.json"
        with patch.object(ach_mod, "SAVE_PATH", str(missing)):
            tracker = AchievementTracker()
        assert tracker.unlocked == {}

    def test_handles_corrupt_json_gracefully(self, tmp_path):
        save_file = tmp_path / "achievements.json"
        save_file.write_text("not valid json {{{{")
        with patch.object(ach_mod, "SAVE_PATH", str(save_file)):
            tracker = AchievementTracker()
        assert tracker.unlocked == {}


# ---------------------------------------------------------------------------
# TestUnlock
# ---------------------------------------------------------------------------


class TestUnlock:
    def test_first_unlock_returns_true(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
            assert tracker.unlock("first_task") is True

    def test_second_unlock_returns_false(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
            tracker.unlock("first_task")
            assert tracker.unlock("first_task") is False

    def test_unknown_id_returns_false(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
            assert tracker.unlock("does_not_exist") is False

    def test_unlock_records_timestamp(self, tmp_path):
        fake_time = 9999999.0
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
            with patch("time.time", return_value=fake_time):
                tracker.unlock("task_10")
        assert tracker.unlocked["task_10"] == fake_time

    def test_unlock_persists_to_disk(self, tmp_path):
        save_file = tmp_path / "a.json"
        with patch.object(ach_mod, "SAVE_PATH", str(save_file)):
            tracker = AchievementTracker()
            tracker.unlock("streak_3")
        data = json.loads(save_file.read_text())
        assert "streak_3" in data["unlocked"]

    def test_unlock_queues_notification(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
            tracker.unlock("pomo_1")
        assert tracker._pending_notifications[0].id == "pomo_1"


# ---------------------------------------------------------------------------
# TestPopNotification
# ---------------------------------------------------------------------------


class TestPopNotification:
    def test_returns_none_when_empty(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
        assert tracker.pop_notification() is None

    def test_returns_achievement_after_unlock(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
            tracker.unlock("first_task")
            result = tracker.pop_notification()
        assert isinstance(result, Achievement)
        assert result.id == "first_task"

    def test_returns_in_fifo_order(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
            tracker.unlock("first_task")
            tracker.unlock("task_10")
            first = tracker.pop_notification()
            second = tracker.pop_notification()
        assert first.id == "first_task"
        assert second.id == "task_10"

    def test_returns_none_after_all_popped(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
            tracker.unlock("first_task")
            tracker.pop_notification()
            assert tracker.pop_notification() is None


# ---------------------------------------------------------------------------
# TestCheckTaskMilestones
# ---------------------------------------------------------------------------


class TestCheckTaskMilestones:
    def _tracker(self, tmp_path) -> AchievementTracker:
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            return AchievementTracker()

    def test_first_task_unlocked_at_1(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(completed_count=1)
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "first_task" in tracker.unlocked

    def test_first_task_not_unlocked_at_0(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(completed_count=0)
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "first_task" not in tracker.unlocked

    def test_task_10_unlocked_at_10(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(completed_count=10)
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "task_10" in tracker.unlocked

    def test_task_50_unlocked_at_50(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(completed_count=50)
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "task_50" in tracker.unlocked

    def test_task_100_unlocked_at_100(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(completed_count=100)
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "task_100" in tracker.unlocked

    def test_task_10_not_unlocked_below_threshold(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(completed_count=9)
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "task_10" not in tracker.unlocked


# ---------------------------------------------------------------------------
# TestCheckStreakAchievements
# ---------------------------------------------------------------------------


class TestCheckStreakAchievements:
    def _tracker(self, tmp_path) -> AchievementTracker:
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            return AchievementTracker()

    def test_streak_3_unlocked_when_peak_ge_3(self, tmp_path):
        tracker = self._tracker(tmp_path)
        char = _make_character(peak_consecutive=3)
        scene = _make_scene(characters=[char])
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "streak_3" in tracker.unlocked

    def test_streak_5_unlocked_when_peak_ge_5(self, tmp_path):
        tracker = self._tracker(tmp_path)
        char = _make_character(peak_consecutive=5)
        scene = _make_scene(characters=[char])
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "streak_5" in tracker.unlocked

    def test_streak_3_not_unlocked_at_peak_2(self, tmp_path):
        tracker = self._tracker(tmp_path)
        char = _make_character(peak_consecutive=2)
        scene = _make_scene(characters=[char])
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "streak_3" not in tracker.unlocked

    def test_streak_5_not_unlocked_at_peak_4(self, tmp_path):
        tracker = self._tracker(tmp_path)
        char = _make_character(peak_consecutive=4)
        scene = _make_scene(characters=[char])
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "streak_3" in tracker.unlocked
        assert "streak_5" not in tracker.unlocked

    def test_streak_checked_across_all_characters(self, tmp_path):
        tracker = self._tracker(tmp_path)
        chars = [
            _make_character(peak_consecutive=1),
            _make_character(peak_consecutive=5),
        ]
        scene = _make_scene(characters=chars)
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "streak_5" in tracker.unlocked


# ---------------------------------------------------------------------------
# TestCheckLevelAchievements
# ---------------------------------------------------------------------------


class TestCheckLevelAchievements:
    def _tracker(self, tmp_path) -> AchievementTracker:
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            return AchievementTracker()

    def test_level_up_unlocked_at_index_1(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(office_level="home_office")  # index 1
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "level_up" in tracker.unlocked

    def test_level_up_not_unlocked_at_index_0(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(office_level="garage")  # index 0
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "level_up" not in tracker.unlocked

    def test_level_5_unlocked_at_index_4(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(office_level="studio")  # index 4
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "level_5" in tracker.unlocked

    def test_level_5_not_unlocked_at_index_3(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(office_level="growing_office")  # index 3
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "level_5" not in tracker.unlocked

    def test_level_10_unlocked_at_index_9(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(office_level="dream_office")  # index 9
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "level_10" in tracker.unlocked

    def test_unknown_level_key_does_not_crash(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(office_level="nonexistent_level")
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "level_up" not in tracker.unlocked


# ---------------------------------------------------------------------------
# TestCheckSmithVisit
# ---------------------------------------------------------------------------


class TestCheckSmithVisit:
    def _tracker(self, tmp_path) -> AchievementTracker:
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            return AchievementTracker()

    def test_smith_visit_unlocked_when_agent_present(self, tmp_path):
        tracker = self._tracker(tmp_path)
        agent = _make_character(is_agent=True)
        scene = _make_scene(characters=[agent])
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "smith_visit" in tracker.unlocked

    def test_smith_visit_not_unlocked_without_agent(self, tmp_path):
        tracker = self._tracker(tmp_path)
        char = _make_character(is_agent=False)
        scene = _make_scene(characters=[char])
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "smith_visit" not in tracker.unlocked

    def test_smith_visit_unlocked_when_one_of_many_is_agent(self, tmp_path):
        tracker = self._tracker(tmp_path)
        chars = [
            _make_character(is_agent=False),
            _make_character(is_agent=True),
            _make_character(is_agent=False),
        ]
        scene = _make_scene(characters=chars)
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "smith_visit" in tracker.unlocked


# ---------------------------------------------------------------------------
# TestCheckPomodoro
# ---------------------------------------------------------------------------


class TestCheckPomodoro:
    def _tracker(self, tmp_path) -> AchievementTracker:
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            return AchievementTracker()

    def test_pomo_1_unlocked_at_1(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(pomo_count=1)
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "pomo_1" in tracker.unlocked

    def test_pomo_5_unlocked_at_5(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(pomo_count=5)
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "pomo_5" in tracker.unlocked

    def test_pomo_1_not_unlocked_at_0(self, tmp_path):
        tracker = self._tracker(tmp_path)
        scene = _make_scene(pomo_count=0)
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "pomo_1" not in tracker.unlocked


# ---------------------------------------------------------------------------
# TestCheckHighFive
# ---------------------------------------------------------------------------


class TestCheckHighFive:
    def _tracker(self, tmp_path) -> AchievementTracker:
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            return AchievementTracker()

    def test_high_five_unlocked_when_character_in_state(self, tmp_path):
        from engine.characters import State

        tracker = self._tracker(tmp_path)
        char = _make_character(state=State.HIGH_FIVE)
        scene = _make_scene(characters=[char])
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "high_five" in tracker.unlocked

    def test_high_five_not_unlocked_when_no_character_in_state(self, tmp_path):
        from engine.characters import State

        tracker = self._tracker(tmp_path)
        char = _make_character(state=State.IDLE)
        scene = _make_scene(characters=[char])
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker.check(scene)
        assert "high_five" not in tracker.unlocked


# ---------------------------------------------------------------------------
# TestUnlockedAndTotalCount
# ---------------------------------------------------------------------------


class TestUnlockedAndTotalCount:
    def test_total_count_is_14(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
        assert tracker.total_count == 14

    def test_unlocked_count_starts_at_0(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
        assert tracker.unlocked_count == 0

    def test_unlocked_count_increments(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
            tracker.unlock("first_task")
            assert tracker.unlocked_count == 1
            tracker.unlock("task_10")
            assert tracker.unlocked_count == 2

    def test_unlocked_count_does_not_double_count(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
            tracker.unlock("first_task")
            tracker.unlock("first_task")
            assert tracker.unlocked_count == 1

    def test_total_count_equals_achievements_list_length(self, tmp_path):
        with patch.object(ach_mod, "SAVE_PATH", str(tmp_path / "a.json")):
            tracker = AchievementTracker()
        assert tracker.total_count == len(ACHIEVEMENTS)
