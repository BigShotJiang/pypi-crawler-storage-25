"""Tests for engine.bubbles — i18n, display width, bubble rendering."""
from engine.bubbles import (
    display_width,
    _pad_to_width,
    _wrap_words,
    make_speech_bubble,
    make_thought_bubble,
    describe_tool_event,
    set_language,
    get_language,
    t,
)


class TestDisplayWidth:
    def test_ascii(self):
        assert display_width("hello") == 5

    def test_cjk(self):
        assert display_width("早安") == 4  # 2 chars × 2 width

    def test_mixed(self):
        assert display_width("Hi 早安") == 7  # 2+1+4

    def test_empty(self):
        assert display_width("") == 0


class TestPadToWidth:
    def test_ascii_pad(self):
        result = _pad_to_width("hi", 6)
        assert display_width(result) == 6
        assert result == "hi    "

    def test_cjk_pad(self):
        result = _pad_to_width("早安", 8)
        assert display_width(result) == 8

    def test_already_wide_enough(self):
        result = _pad_to_width("hello", 3)
        assert result == "hello"


class TestWrapWords:
    def test_short(self):
        lines = _wrap_words("hi", 10)
        assert lines == ["hi"]

    def test_wrap(self):
        lines = _wrap_words("hello world foo", 10)
        assert len(lines) == 2

    def test_empty(self):
        lines = _wrap_words("", 10)
        assert lines == [" "]


class TestSpeechBubble:
    def test_renders_box(self):
        lines = make_speech_bubble("test")
        assert lines[0].startswith("┌")
        assert lines[-2].startswith("└")
        assert lines[-1].strip() == "╰"

    def test_cjk_alignment(self):
        lines = make_speech_bubble("編輯中")
        # All box lines should have same display width
        widths = [display_width(l) for l in lines[:-1]]  # exclude tail
        assert len(set(widths)) == 1

    def test_max_width_clamp(self):
        # Text with spaces gets word-wrapped to fit max_width
        lines = make_speech_bubble("one two three four five six", max_width=16)
        content_lines = [l for l in lines if l.startswith("│")]
        assert len(content_lines) >= 2  # text was wrapped
        # All lines should have consistent display width
        widths = [display_width(l) for l in lines[:-1]]
        assert len(set(widths)) == 1


class TestThoughtBubble:
    def test_renders_box(self):
        lines = make_thought_bubble("think")
        assert lines[0].startswith("╭")
        assert "○" in lines[-3]
        assert lines[-2].strip() == "o"
        assert lines[-1].strip() == "∘"


class TestI18n:
    def test_set_get_language(self):
        set_language("ja")
        assert get_language() == "ja"
        set_language("zh")
        assert get_language() == "zh"

    def test_translate(self):
        set_language("zh")
        assert t("done") == "完成！"
        assert t("lights_on") == "開燈！"
        assert t("pizza") == "披薩來了！"

    def test_fallback_to_en(self):
        set_language("en")
        assert t("nonexistent_key") == "nonexistent_key"

    def test_all_languages_have_same_keys(self):
        from engine.bubbles import STRINGS
        en_keys = set(STRINGS["en"].keys())
        for lang in ["ja", "zh", "ko"]:
            assert set(STRINGS[lang].keys()) == en_keys, f"{lang} missing keys"


class TestDescribeToolEvent:
    def test_bash(self):
        set_language("en")
        desc, btype = describe_tool_event("Bash", {"command": "npm test"})
        assert "npm test" in desc
        assert btype == "speech"

    def test_read(self):
        set_language("zh")
        desc, btype = describe_tool_event("Read", {"file_path": "/src/app.tsx"})
        assert "讀取中" in desc
        assert btype == "thought"

    def test_truncation_adds_ellipsis(self):
        set_language("en")
        desc, _ = describe_tool_event("Bash", {"command": "a" * 50})
        assert desc.endswith("...")

    def test_agent(self):
        desc, btype = describe_tool_event("Agent", {})
        assert btype == "speech"


class TestDisplayWidthEdgeCases:
    """Edge-case tests for display_width with special Unicode characters."""

    def test_variation_selector_promotes_prev_char_to_width_2(self):
        # U+FE0F promotes the previous width-1 char to width 2
        # ☕ (U+2615) is East Asian Width 'A' (ambiguous → 1 col in most terminals)
        # With U+FE0F it becomes emoji-style (width 2)
        result = display_width("☕\uFE0F")
        assert result == 2

    def test_variation_selector_on_already_wide_char_no_double_add(self):
        # A CJK char (W/F width = 2) followed by FE0F should stay at 2, not become 3
        result = display_width("早\uFE0F")
        assert result == 2

    def test_control_chars_zero_width(self):
        # Control characters (\x00–\x1F) have Unicode category Cc → zero width
        assert display_width("\x00\x01\x02") == 0

    def test_combining_marks_zero_width(self):
        # e + combining acute accent (U+0301) = 'é' visually but still 1 cell wide
        assert display_width("e\u0301") == 1

    def test_multiple_combining_marks(self):
        # Base char + two combining marks → still 1 cell
        assert display_width("a\u0300\u0301") == 1

    def test_box_drawing_single_width(self):
        # Box-drawing characters are single-width
        assert display_width("┌─┐│└┘") == 6

    def test_newline_in_string(self):
        # \n is a control char (Cc) → zero width; only visible chars counted
        assert display_width("ab\ncd") == 4

    def test_tab_zero_width(self):
        # \t is a control char (Cc) → zero width
        assert display_width("\t") == 0

    def test_mixed_ascii_and_cjk(self):
        # ASCII (1) + CJK (2) + ASCII (1) = 4
        assert display_width("A文B") == 4

    def test_null_byte_ignored(self):
        assert display_width("\x00") == 0

    def test_lone_variation_selector_at_start(self):
        # Variation selector with no preceding char adds nothing
        result = display_width("\uFE0Fabc")
        assert result == 3


class TestWrapWordsNewlines:
    """Tests for _wrap_words handling of explicit newline characters."""

    def test_explicit_newline_splits_into_two_lines(self):
        lines = _wrap_words("line1\nline2", 20)
        assert lines == ["line1", "line2"]

    def test_explicit_newline_at_start_adds_blank(self):
        lines = _wrap_words("\nline2", 20)
        # Leading newline creates an empty paragraph → " " placeholder
        assert lines[0] == " "
        assert lines[1] == "line2"

    def test_explicit_newline_at_end_adds_blank(self):
        lines = _wrap_words("line1\n", 20)
        assert lines[0] == "line1"
        assert lines[1] == " "

    def test_multiple_explicit_newlines(self):
        lines = _wrap_words("a\nb\nc", 20)
        assert lines == ["a", "b", "c"]

    def test_newline_with_wrapping(self):
        # Each paragraph is word-wrapped independently
        lines = _wrap_words("hello world\nfoo bar", 6)
        # "hello world" wraps at width 6: ["hello", "world"]
        # "foo bar" wraps at width 6: ["foo", "bar"]
        assert "hello" in lines
        assert "world" in lines
        assert "foo" in lines
        assert "bar" in lines

    def test_double_newline_two_blanks(self):
        # Two consecutive newlines → two empty paragraphs
        lines = _wrap_words("a\n\nb", 20)
        assert lines[0] == "a"
        assert lines[1] == " "
        assert lines[2] == "b"
