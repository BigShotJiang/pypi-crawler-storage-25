"""Tests for engine.sprites — themes, furniture, custom theme loading."""
import json
import os
import tempfile

from engine.sprites import THEMES, FurnitureItem, DESK, PLANT


class TestThemes:
    def test_three_builtin_themes(self):
        assert "claude" in THEMES
        assert "kaomoji" in THEMES
        assert "pixel" in THEMES

    def test_all_themes_have_required_states(self):
        required_keys = [
            ("idle", "right"),
            ("typing", "right"),
            ("thinking", "right"),
            ("walking", "right"),
            ("walking", "left"),
            ("celebrating", "right"),
            ("coffee", "right"),
        ]
        for name, theme in THEMES.items():
            if name == "custom":
                continue
            for key in required_keys:
                assert key in theme["sprites"], f"{name} missing {key}"

    def test_all_themes_have_names(self):
        for name, theme in THEMES.items():
            if name == "custom":
                continue
            assert len(theme["names"]) >= 3


class TestFurnitureItem:
    def test_frozen(self):
        fi = FurnitureItem("test", ["##"], 0, 0)
        try:
            fi.x = 5  # type: ignore
            assert False, "Should be frozen"
        except AttributeError:
            pass

    def test_width_height(self):
        fi = FurnitureItem("desk", DESK, 0, 0)
        assert fi.width == 14  # desk width updated to 14 for wider nameplates
        assert fi.height == 5


class TestCustomTheme:
    def test_load_custom_theme(self):
        from engine.sprites import load_custom_theme, CUSTOM_THEME_PATH

        # Write a temp custom theme
        theme_data = {
            "name": "test-custom",
            "label": "Test Custom",
            "names": ["A", "B", "C"],
            "sprites": {
                "idle": [["  O  ", " /|\\ ", " / \\ "]],
                "typing": [["  O  ", " /|= ", " | | "]],
                "walking_right": [["  O> ", " /|  ", "  >> "]],
                "walking_left": [[" <O  ", "  |\\ ", " <<  "]],
                "celebrating": [["\\O/  ", " |   ", "/ \\  "]],
                "thinking": [["  O? ", " /|\\ ", " / \\ "]],
                "coffee": [["  O~ ", " /|c ", " / \\ "]],
            },
        }

        tmpdir = tempfile.mkdtemp()
        path = os.path.join(tmpdir, "custom-theme.json")
        with open(path, "w") as f:
            json.dump(theme_data, f)

        # Monkey-patch the path
        import engine.sprites
        old_path = engine.sprites.CUSTOM_THEME_PATH
        engine.sprites.CUSTOM_THEME_PATH = path

        try:
            result = load_custom_theme()
            assert result is True
            assert "custom" in THEMES
            assert THEMES["custom"]["label"] == "Test Custom"
        finally:
            engine.sprites.CUSTOM_THEME_PATH = old_path
            THEMES.pop("custom", None)
            os.unlink(path)

    def test_load_missing_file(self):
        from engine.sprites import load_custom_theme
        import engine.sprites
        old_path = engine.sprites.CUSTOM_THEME_PATH
        engine.sprites.CUSTOM_THEME_PATH = "/nonexistent/path.json"
        try:
            assert load_custom_theme() is False
        finally:
            engine.sprites.CUSTOM_THEME_PATH = old_path
