"""Tests for engine.levels — LevelDef, LEVEL_DEFS, LEVEL_BY_KEY, LEVEL_KEYS, OLD_KEY_MIGRATION."""
from engine.levels import (
    LEVEL_DEFS,
    LEVEL_BY_KEY,
    LEVEL_KEYS,
    OLD_KEY_MIGRATION,
)


class TestLevelDefsCount:
    def test_exactly_ten_levels(self):
        assert len(LEVEL_DEFS) == 10


class TestLevelDefIndices:
    def test_indices_are_sequential(self):
        for expected, ld in enumerate(LEVEL_DEFS):
            assert ld.index == expected


class TestLevelDefThresholds:
    def test_session_threshold_strictly_increases(self):
        for i in range(1, len(LEVEL_DEFS)):
            prev = LEVEL_DEFS[i - 1].session_threshold
            curr = LEVEL_DEFS[i].session_threshold
            assert curr > prev, (
                f"session_threshold did not increase at index {i}: "
                f"{prev} → {curr}"
            )

    def test_unlock_threshold_strictly_increases(self):
        for i in range(1, len(LEVEL_DEFS)):
            prev = LEVEL_DEFS[i - 1].unlock_threshold
            curr = LEVEL_DEFS[i].unlock_threshold
            assert curr > prev, (
                f"unlock_threshold did not increase at index {i}: "
                f"{prev} → {curr}"
            )


class TestLevelDefElfCount:
    def test_elf_count_never_decreases(self):
        for i in range(1, len(LEVEL_DEFS)):
            prev = LEVEL_DEFS[i - 1].elf_count
            curr = LEVEL_DEFS[i].elf_count
            assert curr >= prev, (
                f"elf_count decreased at index {i}: {prev} → {curr}"
            )


class TestLevelByKey:
    def test_level_by_key_has_all_ten_keys(self):
        assert len(LEVEL_BY_KEY) == 10

    def test_level_by_key_contains_all_level_keys(self):
        for ld in LEVEL_DEFS:
            assert ld.key in LEVEL_BY_KEY
            assert LEVEL_BY_KEY[ld.key] is ld


class TestLevelKeys:
    def test_level_keys_order_matches_level_defs(self):
        assert LEVEL_KEYS == tuple(ld.key for ld in LEVEL_DEFS)

    def test_level_keys_length(self):
        assert len(LEVEL_KEYS) == 10


class TestOldKeyMigration:
    def test_migration_values_exist_in_level_by_key(self):
        for old_key, new_key in OLD_KEY_MIGRATION.items():
            assert new_key in LEVEL_BY_KEY, (
                f"OLD_KEY_MIGRATION[{old_key!r}] = {new_key!r} not found in LEVEL_BY_KEY"
            )


class TestFurniture:
    def test_all_levels_have_door(self):
        for ld in LEVEL_DEFS:
            assert "door" in ld.furniture, (
                f"Level {ld.key!r} is missing 'door' in furniture"
            )

    def test_higher_levels_have_more_furniture(self):
        # Each level at index > 0 should have at least as many furniture items
        # as the previous level (levels accumulate furniture)
        for i in range(1, len(LEVEL_DEFS)):
            prev = len(LEVEL_DEFS[i - 1].furniture)
            curr = len(LEVEL_DEFS[i].furniture)
            assert curr >= prev, (
                f"Level index {i} ({LEVEL_DEFS[i].key!r}) has fewer furniture items "
                f"({curr}) than level index {i - 1} ({LEVEL_DEFS[i - 1].key!r}) ({prev})"
            )
