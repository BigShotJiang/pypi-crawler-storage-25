"""Tests for engine.atmosphere — time-of-day system."""
from engine.atmosphere import (
    TimeOfDay,
    get_time_of_day,
    get_atmosphere,
    Atmosphere,
)


class TestTimeOfDay:
    def test_returns_valid_enum(self):
        tod = get_time_of_day()
        assert isinstance(tod, TimeOfDay)

    def test_all_periods_have_atmosphere(self):
        for tod in TimeOfDay:
            atmo = get_atmosphere()
            assert isinstance(atmo, Atmosphere)


class TestAtmosphere:
    def test_morning_bright(self):
        from engine.atmosphere import _ATMOSPHERES
        atmo = _ATMOSPHERES[TimeOfDay.MORNING]
        assert not atmo.floor_dim
        assert atmo.char_bold
        assert atmo.status_icon == "☀"

    def test_night_dim(self):
        from engine.atmosphere import _ATMOSPHERES
        atmo = _ATMOSPHERES[TimeOfDay.NIGHT]
        assert atmo.floor_dim
        assert atmo.furniture_dim
        assert not atmo.char_bold
        assert atmo.status_icon == "🌙"

    def test_frozen(self):
        atmo = get_atmosphere()
        try:
            atmo.floor_dim = True  # type: ignore
            assert False, "Should be frozen"
        except AttributeError:
            pass
