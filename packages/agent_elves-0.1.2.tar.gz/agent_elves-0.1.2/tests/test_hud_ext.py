"""Tests for engine.hud — status line, HUD, banners."""
from engine.scene import Scene
from engine.characters import State
from engine.bubbles import set_language
from engine import hud


def _make_scene(w=80, h=30):
    set_language("en")
    scene = Scene(width=w, height=h, theme_name="claude", office_level="small_office")
    scene.populate()
    return scene


class FakeAchievement:
    icon = "🏆"
    name = {"en": "Test Achievement", "ja": "テスト"}
    desc = {"en": "A test achievement", "ja": "テスト"}


class TestGetStatusLine:
    def test_intro_mode(self):
        scene = _make_scene()
        scene.start_intro()
        assert scene.intro_active
        result = hud.get_status_line(scene, max_w=80)
        assert "Agent Elves" in result

    def test_normal_mode(self):
        scene = _make_scene()
        result = hud.get_status_line(scene, max_w=80)
        assert "Agent Elves" in result
        assert "✓" in result

    def test_respects_max_width(self):
        scene = _make_scene()
        result = hud.get_status_line(scene, max_w=40)
        assert len(result) <= 40


class TestGetHudLines:
    def test_returns_list(self):
        scene = _make_scene()
        result = hud.get_hud_lines(scene, max_w=80)
        assert isinstance(result, list)
        assert all(isinstance(s, str) for s in result)

    def test_always_two_items(self):
        scene = _make_scene()
        result = hud.get_hud_lines(scene, max_w=200)
        assert len(result) == 2

    def test_narrow_both_have_content(self):
        scene = _make_scene()
        result = hud.get_hud_lines(scene, max_w=40)
        assert len(result) == 2
        assert result[0].strip()
        assert result[1].strip()


class TestPomoBanner:
    def test_break_banner(self):
        scene = _make_scene()
        hud.show_pomodoro_banner(scene, "break")
        assert len(scene.upgrade_overlay) > 0
        assert scene.upgrade_flash is True
        assert scene._bell_pending is True

    def test_work_banner(self):
        scene = _make_scene()
        hud.show_pomodoro_banner(scene, "work")
        assert len(scene.upgrade_overlay) > 0

    def test_start_banner(self):
        scene = _make_scene()
        hud.show_pomodoro_banner(scene, "start")
        assert len(scene.upgrade_overlay) > 0

    def test_invalid_event_noop(self):
        scene = _make_scene()
        hud.show_pomodoro_banner(scene, "invalid")
        assert len(scene.upgrade_overlay) == 0


class TestPomodoroBreak:
    def test_start_break_celebrates(self):
        scene = _make_scene()
        for c in scene.characters:
            c.state = State.IDLE
            c.busy = False
        hud.start_pomodoro_break(scene)
        celebrating = [c for c in scene.characters if c.state == State.CELEBRATING]
        assert len(celebrating) > 0

    def test_end_break_sets_bubble(self):
        scene = _make_scene()
        for c in scene.characters:
            c.state = State.CELEBRATING
            c.busy = False
        hud.end_pomodoro_break(scene)
        with_bubble = [c for c in scene.characters if c.bubble_text == "Back to work!"]
        assert len(with_bubble) > 0


class TestAchievementBanner:
    def test_shows_banner(self):
        scene = _make_scene()
        hud.show_achievement_banner(scene, FakeAchievement())
        assert len(scene.upgrade_overlay) > 0
        assert scene.upgrade_flash is True
        # Check banner contains achievement text
        banner_text = " ".join(scene.upgrade_overlay)
        assert "ACHIEVEMENT" in banner_text
