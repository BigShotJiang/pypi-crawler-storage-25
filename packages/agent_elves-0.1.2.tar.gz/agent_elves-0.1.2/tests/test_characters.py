"""Tests for engine.characters — state machine, movement, roles."""
from engine.characters import (
    Character,
    State,
    ROLE_TOOLS,
    _ROLE_CYCLE,
    create_characters,
)
from engine.bubbles import set_language


class TestCharacterCreation:
    def test_create_with_desks(self):
        desks = [(10.0, 5.0), (20.0, 5.0), (30.0, 5.0)]
        chars = create_characters("claude", 3, 60, 20, desk_positions=desks)
        assert len(chars) == 3
        assert chars[0].desk_x == 10.0
        assert chars[1].desk_y == 5.0

    def test_roles_assigned(self):
        chars = create_characters("claude", 4, 60, 20)
        roles = [c.role for c in chars]
        assert roles == _ROLE_CYCLE[:4]

    def test_names_from_theme(self):
        chars = create_characters("kaomoji", 3, 60, 20)
        assert chars[0].name == "Mochi"
        assert chars[1].name == "Anko"


class TestRoleMatching:
    def test_engineer_handles_bash(self):
        c = Character(name="T", x=0, y=0, role="engineer")
        assert c.can_handle("Bash")
        assert c.can_handle("Edit")

    def test_researcher_handles_read(self):
        c = Character(name="T", x=0, y=0, role="researcher")
        assert c.can_handle("Read")
        assert c.can_handle("Grep")
        assert not c.can_handle("Bash")

    def test_ops_handles_agent(self):
        c = Character(name="T", x=0, y=0, role="ops")
        assert c.can_handle("Agent")


class TestStateMachine:
    def test_idle_to_walking(self):
        c = Character(name="T", x=5, y=5)
        c._wander(60, 20)
        assert c.state == State.WALKING
        assert c.target_x is not None

    def test_walking_arrives(self):
        c = Character(name="T", x=10, y=10)
        c.target_x = 10.5
        c.target_y = 10.0
        c.target_callback = "typing"
        c.state = State.WALKING
        c.tick(0.5, 60, 20)
        assert c.state == State.TYPING

    def test_celebrating_returns_to_idle(self):
        c = Character(name="T", x=5, y=5, state=State.CELEBRATING)
        for _ in range(20):
            c.tick(0.1, 60, 20)
        assert c.state == State.IDLE

    def test_greeting_then_walk(self):
        c = Character(name="T", x=5, y=5, state=State.GREETING)
        c.target_x = 20.0
        c.target_y = 10.0
        for _ in range(20):
            c.tick(0.1, 60, 20)
        assert c.state == State.WALKING

    def test_chatting_returns_to_idle(self):
        c = Character(name="T", x=5, y=5, state=State.CHATTING)
        for _ in range(40):
            c.tick(0.1, 60, 20)
        assert c.state == State.IDLE

    def test_idle_threshold_rolled_once(self):
        c = Character(name="T", x=5, y=5)
        c._enter_idle()
        threshold = c._idle_threshold
        # Threshold should stay the same across ticks
        for _ in range(10):
            c.tick(0.1, 60, 20)
        assert c._idle_threshold == threshold


class TestTaskAssignment:
    def test_assign_uses_own_desk(self):
        set_language("en")
        c = Character(name="T", x=5, y=5, desk_x=30.0, desk_y=10.0)
        c.assign_task(99.0, 99.0, "typing", "test", "speech", "Bash:1")
        assert c.target_x == 30.0  # own desk, not the provided 99.0
        assert c.current_task_id == "Bash:1"
        assert c.busy

    def test_finish_clears_task(self):
        set_language("en")
        c = Character(name="T", x=5, y=5, busy=True, current_task_id="Edit:3")
        c.finish_task()
        assert c.current_task_id == ""
        assert not c.busy
        assert c.state == State.CELEBRATING


class TestDeparture:
    def test_agent_departure_flow(self):
        c = Character(name="T", x=5, y=5, is_agent=True)
        c._departure_pending = True
        c.state = State.CELEBRATING
        c.state_timer = 0.0

        # Tick through celebration → walking to exit (needs enough time)
        for _ in range(300):
            c.tick(0.1, 60, 20)
            if c._departed:
                break

        assert c._departed

    def test_departure_unclamped(self):
        c = Character(name="T", x=50, y=5, is_agent=True)
        c._departure_pending = True
        c.target_x = 65.0
        c.target_y = 1.0
        c.state = State.WALKING

        # Should be allowed past normal boundary
        for _ in range(100):
            c.tick(0.1, 60, 20)
        assert c.x > 55  # past normal clamp of scene_w - 8 = 52


class TestExpressionStates:
    """Tests for the 7 new expression states."""

    def test_stretching_returns_to_idle_when_no_prev_state(self):
        c = Character(name="T", x=5, y=5, state=State.STRETCHING)
        c._pre_stretch_state = ""  # no previous state → should go idle
        for _ in range(30):
            c.tick(0.1, 60, 20)
        assert c.state == State.IDLE

    def test_stretching_returns_to_typing(self):
        c = Character(name="T", x=5, y=5, state=State.STRETCHING)
        c._pre_stretch_state = "typing"
        for _ in range(30):
            c.tick(0.1, 60, 20)
        assert c.state == State.TYPING

    def test_stretching_returns_to_thinking(self):
        c = Character(name="T", x=5, y=5, state=State.STRETCHING)
        c._pre_stretch_state = "thinking"
        for _ in range(30):
            c.tick(0.1, 60, 20)
        assert c.state == State.THINKING

    def test_stretching_returns_to_reading(self):
        c = Character(name="T", x=5, y=5, state=State.STRETCHING)
        c._pre_stretch_state = "reading"
        for _ in range(30):
            c.tick(0.1, 60, 20)
        assert c.state == State.READING

    def test_stretching_duration_is_about_2_5s(self):
        c = Character(name="T", x=5, y=5, state=State.STRETCHING)
        c._pre_stretch_state = ""
        # Still in STRETCHING after 2.4s
        for _ in range(24):
            c.tick(0.1, 60, 20)
        assert c.state == State.STRETCHING
        # Transitioned after 2.5s
        c.tick(0.15, 60, 20)
        assert c.state == State.IDLE

    def test_sleepy_returns_to_idle(self):
        c = Character(name="T", x=5, y=5, state=State.SLEEPY)
        for _ in range(50):
            c.tick(0.1, 60, 20)
        assert c.state == State.IDLE

    def test_sleepy_duration_is_about_4s(self):
        c = Character(name="T", x=5, y=5, state=State.SLEEPY)
        # Still SLEEPY at 3.9s
        for _ in range(39):
            c.tick(0.1, 60, 20)
        assert c.state == State.SLEEPY
        # Transitions after 4.0s
        c.tick(0.15, 60, 20)
        assert c.state == State.IDLE

    def test_excited_returns_to_idle(self):
        c = Character(name="T", x=5, y=5, state=State.EXCITED)
        for _ in range(30):
            c.tick(0.1, 60, 20)
        assert c.state == State.IDLE

    def test_excited_duration_is_about_2s(self):
        c = Character(name="T", x=5, y=5, state=State.EXCITED)
        # Still EXCITED at 1.9s
        for _ in range(19):
            c.tick(0.1, 60, 20)
        assert c.state == State.EXCITED
        # Transitions after 2.0s
        c.tick(0.15, 60, 20)
        assert c.state == State.IDLE

    def test_frustrated_returns_to_idle(self):
        c = Character(name="T", x=5, y=5, state=State.FRUSTRATED)
        for _ in range(30):
            c.tick(0.1, 60, 20)
        assert c.state == State.IDLE

    def test_frustrated_duration_is_about_2_5s(self):
        c = Character(name="T", x=5, y=5, state=State.FRUSTRATED)
        # Still FRUSTRATED at 2.4s
        for _ in range(24):
            c.tick(0.1, 60, 20)
        assert c.state == State.FRUSTRATED
        # Transitions after 2.5s
        c.tick(0.15, 60, 20)
        assert c.state == State.IDLE

    def test_high_five_returns_to_desk_or_idle(self):
        c = Character(name="T", x=5, y=5, state=State.HIGH_FIVE)
        for _ in range(30):
            c.tick(0.1, 60, 20)
        # No desk → enters idle; with desk → starts walking
        assert c.state in (State.IDLE, State.WALKING)

    def test_high_five_with_desk_walks_back(self):
        c = Character(name="T", x=5, y=5, state=State.HIGH_FIVE,
                      desk_x=10.0, desk_y=5.0)
        for _ in range(30):
            c.tick(0.1, 60, 20)
        assert c.state == State.WALKING
        assert c.target_x == 10.0
        assert c.target_y == 5.0

    def test_high_five_duration_is_about_2s(self):
        c = Character(name="T", x=5, y=5, state=State.HIGH_FIVE)
        # Still HIGH_FIVE at 1.9s
        for _ in range(19):
            c.tick(0.1, 60, 20)
        assert c.state == State.HIGH_FIVE
        # Transitions after 2.0s
        c.tick(0.15, 60, 20)
        assert c.state in (State.IDLE, State.WALKING)

    def test_reading_transitions_when_not_busy(self):
        c = Character(name="T", x=5, y=5, state=State.READING)
        c.busy = False
        for _ in range(30):
            c.tick(0.1, 60, 20)
        # Non-busy reading → CELEBRATING after timeout
        assert c.state in (State.CELEBRATING, State.IDLE)

    def test_reading_stays_while_busy(self):
        c = Character(name="T", x=5, y=5, state=State.READING)
        c.busy = True
        for _ in range(30):
            c.tick(0.1, 60, 20)
        assert c.state == State.READING

    def test_reading_non_busy_timeout_is_about_2s(self):
        c = Character(name="T", x=5, y=5, state=State.READING)
        c.busy = False
        # Still READING at 1.9s
        for _ in range(19):
            c.tick(0.1, 60, 20)
        assert c.state == State.READING
        # Transitions after 2.0s
        c.tick(0.15, 60, 20)
        assert c.state == State.CELEBRATING

    def test_snacking_returns_to_idle(self):
        c = Character(name="T", x=5, y=5, state=State.SNACKING)
        for _ in range(40):
            c.tick(0.1, 60, 20)
        assert c.state == State.IDLE

    def test_snacking_duration_is_about_3s(self):
        c = Character(name="T", x=5, y=5, state=State.SNACKING)
        # Still SNACKING at 2.9s
        for _ in range(29):
            c.tick(0.1, 60, 20)
        assert c.state == State.SNACKING
        # Transitions after 3.0s
        c.tick(0.15, 60, 20)
        assert c.state == State.IDLE


class TestTaskStreak:
    """Tests for consecutive task tracking and EXCITED state trigger."""

    def test_consecutive_increments_on_finish(self):
        from engine.bubbles import set_language
        set_language("en")
        c = Character(name="T", x=5, y=5)
        assert c._consecutive_tasks == 0
        c.finish_task()
        assert c._consecutive_tasks == 1
        c.finish_task()
        assert c._consecutive_tasks == 2

    def test_peak_tracks_maximum_streak(self):
        from engine.bubbles import set_language
        set_language("en")
        c = Character(name="T", x=5, y=5)
        c.finish_task()
        c.finish_task()
        assert getattr(c, "_peak_consecutive", 0) == 2
        # Trigger EXCITED (streak resets to 0) — peak stays at 3
        c.finish_task()
        assert getattr(c, "_peak_consecutive", 0) == 3

    def test_excited_at_streak_3(self):
        from engine.bubbles import set_language
        set_language("en")
        c = Character(name="T", x=5, y=5)
        c.finish_task()
        assert c.state == State.CELEBRATING
        c.finish_task()
        assert c.state == State.CELEBRATING
        c.finish_task()
        assert c.state == State.EXCITED

    def test_streak_resets_after_excited(self):
        from engine.bubbles import set_language
        set_language("en")
        c = Character(name="T", x=5, y=5)
        c.finish_task()
        c.finish_task()
        c.finish_task()  # triggers EXCITED, resets streak to 0
        assert c._consecutive_tasks == 0

    def test_streak_resets_on_enter_idle(self):
        from engine.bubbles import set_language
        set_language("en")
        c = Character(name="T", x=5, y=5)
        c.finish_task()
        c.finish_task()
        assert c._consecutive_tasks == 2
        c._enter_idle()
        assert c._consecutive_tasks == 0

    def test_peak_not_downgraded_after_reset(self):
        from engine.bubbles import set_language
        set_language("en")
        c = Character(name="T", x=5, y=5)
        # Build streak to 3 → EXCITED → resets to 0
        c.finish_task()
        c.finish_task()
        c.finish_task()
        peak_after_first_streak = getattr(c, "_peak_consecutive", 0)
        # Second streak of only 1 should not lower peak
        c.finish_task()
        assert getattr(c, "_peak_consecutive", 0) == peak_after_first_streak
