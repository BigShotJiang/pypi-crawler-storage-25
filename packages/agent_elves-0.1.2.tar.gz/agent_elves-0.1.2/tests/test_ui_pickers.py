"""Tests for engine.ui_pickers — curses UI helpers tested with mock stdscr."""
import curses
from unittest.mock import MagicMock, patch

from engine.ui_pickers import (
    LOGO,
    COPYRIGHT,
    _safe_addstr,
    _draw_box,
    _center_x,
    _draw_header,
    setup_wizard,
)


def _mock_stdscr(h=40, w=80):
    stdscr = MagicMock()
    stdscr.getmaxyx.return_value = (h, w)
    return stdscr


class TestSafeAddstr:
    def test_within_bounds(self):
        stdscr = _mock_stdscr()
        _safe_addstr(stdscr, 5, 10, "hello")
        stdscr.addnstr.assert_called_once()

    def test_out_of_bounds_y(self):
        stdscr = _mock_stdscr(h=10, w=80)
        _safe_addstr(stdscr, 15, 0, "hello")
        stdscr.addnstr.assert_not_called()

    def test_out_of_bounds_x(self):
        stdscr = _mock_stdscr(h=40, w=80)
        _safe_addstr(stdscr, 0, 85, "hello")
        stdscr.addnstr.assert_not_called()

    def test_negative_coords(self):
        stdscr = _mock_stdscr()
        _safe_addstr(stdscr, -1, 5, "hello")
        stdscr.addnstr.assert_not_called()

    def test_curses_error_suppressed(self):
        stdscr = _mock_stdscr()
        stdscr.addnstr.side_effect = curses.error("test")
        # Should not raise
        _safe_addstr(stdscr, 0, 0, "hello")


class TestDrawBox:
    def test_draws_borders(self):
        stdscr = _mock_stdscr()
        _draw_box(stdscr, 0, 0, 10, 5, 0)
        # Top + bottom + sides = at least 2 + (5-2)*2 = 8 calls
        assert stdscr.addnstr.call_count >= 4

    def test_small_box(self):
        stdscr = _mock_stdscr()
        _draw_box(stdscr, 1, 1, 4, 3, 0)
        assert stdscr.addnstr.call_count >= 3


class TestCenterX:
    def test_centers_text(self):
        stdscr = _mock_stdscr(w=80)
        x = _center_x(stdscr, "hello")  # len=5
        assert x == (80 - 5) // 2

    def test_long_text_returns_zero(self):
        stdscr = _mock_stdscr(w=5)
        x = _center_x(stdscr, "a very long text")
        assert x == 0


class TestDrawHeader:
    @patch("engine.ui_pickers.curses")
    def test_returns_next_y(self, mock_curses):
        mock_curses.color_pair.return_value = 0
        mock_curses.A_BOLD = 0
        mock_curses.A_DIM = 0
        stdscr = _mock_stdscr(h=40, w=80)
        next_y = _draw_header(stdscr, 0)
        assert next_y > 0

    @patch("engine.ui_pickers.curses")
    def test_narrow_skips_logo(self, mock_curses):
        mock_curses.color_pair.return_value = 0
        mock_curses.A_BOLD = 0
        mock_curses.A_DIM = 0
        stdscr = _mock_stdscr(h=40, w=30)
        next_y = _draw_header(stdscr, 0)
        assert next_y >= 0


class TestLogo:
    def test_logo_is_list(self):
        assert isinstance(LOGO, list)
        assert len(LOGO) > 0

    def test_copyright_is_string(self):
        assert isinstance(COPYRIGHT, str)
        assert "Nickdevlab" in COPYRIGHT
