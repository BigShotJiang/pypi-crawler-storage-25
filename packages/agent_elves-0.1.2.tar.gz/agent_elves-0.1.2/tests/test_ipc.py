"""Tests for engine.ipc — socket communication."""
import json
import os
import socket
import tempfile

from engine.ipc import EventReceiver


class TestEventReceiver:
    def _make_receiver(self) -> tuple[EventReceiver, str]:
        tmpdir = tempfile.mkdtemp()
        path = os.path.join(tmpdir, "test.sock")
        r = EventReceiver(path)
        r.start()
        return r, path

    def test_start_creates_socket(self):
        r, path = self._make_receiver()
        assert os.path.exists(path)
        r.close()

    def test_drain_empty(self):
        r, _ = self._make_receiver()
        events = r.drain()
        assert events == []
        r.close()

    def test_drain_valid_event(self):
        r, path = self._make_receiver()
        msg = {"type": "tool_pre", "tool": "Bash", "input": {"command": "test"}}
        s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        s.sendto(json.dumps(msg).encode(), path)
        s.close()

        events = r.drain()
        assert len(events) == 1
        assert events[0]["type"] == "tool_pre"
        assert events[0]["tool"] == "Bash"
        r.close()

    def test_drain_clamps_tool_name(self):
        r, path = self._make_receiver()
        msg = {"type": "tool_pre", "tool": "A" * 200, "input": {}}
        s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        s.sendto(json.dumps(msg).encode(), path)
        s.close()

        events = r.drain()
        assert len(events[0]["tool"]) <= 64
        r.close()

    def test_drain_rejects_non_dict(self):
        r, path = self._make_receiver()
        s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        s.sendto(b'"just a string"', path)
        s.close()

        events = r.drain()
        assert events == []
        r.close()

    def test_drain_fixes_bad_input_type(self):
        r, path = self._make_receiver()
        msg = {"type": "tool_pre", "tool": "X", "input": "not a dict"}
        s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        s.sendto(json.dumps(msg).encode(), path)
        s.close()

        events = r.drain()
        assert events[0]["input"] == {}
        r.close()

    def test_drain_skips_invalid_json(self):
        r, path = self._make_receiver()
        s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        s.sendto(b"not json at all", path)
        s.close()

        events = r.drain()
        assert events == []
        r.close()

    def test_close_removes_socket(self):
        r, path = self._make_receiver()
        r.close()
        assert not os.path.exists(path)
