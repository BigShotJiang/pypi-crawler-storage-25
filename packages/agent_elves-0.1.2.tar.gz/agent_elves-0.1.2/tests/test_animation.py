"""Tests for PlanSequence and ExitPlanSequence in engine.animation."""
from dataclasses import dataclass, field

from engine.bubbles import set_language
from engine.characters import Character, State
from engine.sprites import FurnitureItem
from engine.animation import (
    ExitPlanSequence,
    ExitPlanStage,
    PlanSequence,
    PlanStage,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_char(name: str = "T", x: float = 5, y: float = 5,
               busy: bool = False, **kw) -> Character:
    return Character(name=name, x=x, y=y, busy=busy,
                     desk_x=float(x), desk_y=float(y), **kw)


@dataclass
class _MockPomodoro:
    completed_pomodoros: int = 0


@dataclass
class _MockAchievements:
    _check_called: bool = False

    def check(self, scene) -> None:
        self._check_called = True

    def pop_notification(self):
        return None


@dataclass
class MockScene:
    width: int = 80
    height: int = 24
    characters: list = field(default_factory=list)
    furniture: list = field(default_factory=list)

    # ExitPlanSequence extras
    _plan_active: bool = True
    _pomodoro: _MockPomodoro = field(default_factory=_MockPomodoro)
    _achievements: _MockAchievements = field(default_factory=_MockAchievements)

    def _check_auto_upgrade(self) -> None:
        pass


# ---------------------------------------------------------------------------
# PlanSequence tests
# ---------------------------------------------------------------------------

class TestPlanSequenceStart:
    def setup_method(self):
        set_language("en")

    def test_start_sets_all_characters_to_idle(self):
        scene = MockScene()
        scene.characters = [
            _make_char("A", busy=True, state=State.TYPING),
            _make_char("B", busy=True, state=State.THINKING),
        ]
        seq = PlanSequence(scene=scene)
        seq.start()

        for c in scene.characters:
            assert c.state == State.IDLE
            # busy/task_id preserved so tool_post can still match
            assert c.target_x is None
            assert c.target_y is None

    def test_start_clears_bubble(self):
        scene = MockScene()
        c = _make_char("A")
        c.bubble_text = "hello"
        c.bubble_ttl = 5.0
        scene.characters = [c]
        seq = PlanSequence(scene=scene)
        seq.start()

        assert c.bubble_text == ""
        assert c.bubble_ttl == 0.0

    def test_start_identifies_opus_as_first_character(self):
        scene = MockScene()
        scene.characters = [_make_char("Opus"), _make_char("B"), _make_char("C")]
        seq = PlanSequence(scene=scene)
        seq.start()

        assert seq._opus is scene.characters[0]

    def test_start_identifies_others_excluding_agents(self):
        scene = MockScene()
        lead = _make_char("Lead")
        regular = _make_char("Reg")
        agent = _make_char("Agent", is_agent=True)
        scene.characters = [lead, regular, agent]
        seq = PlanSequence(scene=scene)
        seq.start()

        assert seq._opus is lead
        assert regular in seq._others
        assert agent not in seq._others

    def test_start_marks_busy_agents_with_flag(self):
        scene = MockScene()
        lead = _make_char("Lead")
        agent = _make_char("AgentX", busy=True, is_agent=True)
        scene.characters = [lead, agent]
        seq = PlanSequence(scene=scene)
        seq.start()

        assert getattr(agent, "_plan_mode_was_busy", False) is True

    def test_start_does_not_mark_non_busy_agents(self):
        scene = MockScene()
        lead = _make_char("Lead")
        agent = _make_char("AgentX", busy=False, is_agent=True)
        scene.characters = [lead, agent]
        seq = PlanSequence(scene=scene)
        seq.start()

        assert not getattr(agent, "_plan_mode_was_busy", False)


class TestPlanSequenceStopWork:
    def setup_method(self):
        set_language("en")

    def test_tick_through_stop_work_enters_setup(self):
        scene = MockScene()
        scene.characters = [_make_char("A")]
        seq = PlanSequence(scene=scene)
        seq.start()

        assert seq.stage == PlanStage.STOP_WORK

        # STOP_WORK stage lasts 1.0 second
        seq.tick(1.1)
        assert seq.stage == PlanStage.SETUP


class TestPlanSequenceSetup:
    def setup_method(self):
        set_language("en")

    def test_setup_places_meeting_table_and_whiteboard(self):
        scene = MockScene()
        scene.characters = [_make_char("A")]
        seq = PlanSequence(scene=scene)
        seq.start()

        # Drive past STOP_WORK → SETUP
        seq.tick(1.1)
        assert seq.stage == PlanStage.SETUP

        # Furniture added during _place_furniture (called at end of STOP_WORK)
        names = [f.name for f in scene.furniture]
        assert "meeting_table" in names
        assert "whiteboard_plan" in names

    def test_setup_furniture_items_are_furniture_items(self):
        scene = MockScene()
        scene.characters = [_make_char("A")]
        seq = PlanSequence(scene=scene)
        seq.start()
        seq.tick(1.1)

        for item in scene.furniture:
            assert isinstance(item, FurnitureItem)


class TestPlanSequenceGather:
    def setup_method(self):
        set_language("en")

    def _advance_to_gather(self, seq: PlanSequence) -> None:
        """Drive seq from STOP_WORK through SETUP into GATHER."""
        seq.tick(1.1)   # STOP_WORK → SETUP
        seq.tick(1.6)   # SETUP → GATHER

    def test_gather_sends_characters_toward_seats(self):
        scene = MockScene()
        lead = _make_char("Lead", x=5, y=5)
        other = _make_char("Other", x=10, y=10)
        scene.characters = [lead, other]
        seq = PlanSequence(scene=scene)
        seq.start()
        self._advance_to_gather(seq)

        assert seq.stage == PlanStage.GATHER
        # Give enough time for gather to dispatch the first char
        seq.tick(0.6)
        # The other character should have been given a target
        assert other.target_x is not None
        assert other.target_y is not None


class TestPlanSequenceCompletion:
    def setup_method(self):
        set_language("en")

    def test_full_sequence_completes_within_fifteen_seconds(self):
        scene = MockScene()
        scene.characters = [_make_char("Lead"), _make_char("B")]
        seq = PlanSequence(scene=scene)
        seq.start()

        total = 0.0
        dt = 0.1
        while not seq.is_complete and total < 15.0:
            seq.tick(dt)
            total += dt

        assert seq.is_complete, (
            f"PlanSequence not complete after {total:.1f}s "
            f"(stage={seq.stage})"
        )

    def test_solo_sequence_completes(self):
        """Single character (no others) still completes without hanging."""
        scene = MockScene()
        scene.characters = [_make_char("Solo")]
        seq = PlanSequence(scene=scene)
        seq.start()

        total = 0.0
        dt = 0.1
        while not seq.is_complete and total < 15.0:
            seq.tick(dt)
            total += dt

        assert seq.is_complete


# ---------------------------------------------------------------------------
# ExitPlanSequence tests
# ---------------------------------------------------------------------------

class TestExitPlanSequenceStart:
    def setup_method(self):
        set_language("en")

    def test_start_sets_all_characters_to_celebrating(self):
        scene = MockScene()
        scene.characters = [_make_char("A"), _make_char("B")]
        seq = ExitPlanSequence(scene=scene)
        seq.start()

        for c in scene.characters:
            assert c.state == State.CELEBRATING

    def test_start_shows_plan_wrap_up_bubble_on_lead(self):
        scene = MockScene()
        lead = _make_char("Lead")
        follower = _make_char("B")
        scene.characters = [lead, follower]
        seq = ExitPlanSequence(scene=scene)
        seq.start()

        # Lead should have a speech bubble set
        assert lead.bubble_text != ""
        assert lead.bubble_type == "speech"
        assert lead.bubble_ttl > 0.0

    def test_start_stage_is_wrap_up(self):
        scene = MockScene()
        scene.characters = [_make_char("A")]
        seq = ExitPlanSequence(scene=scene)
        seq.start()

        assert seq.stage == ExitPlanStage.WRAP_UP


class TestExitPlanSequenceCleanup:
    def setup_method(self):
        set_language("en")

    def _make_scene_with_meeting_furniture(self) -> MockScene:
        scene = MockScene()
        from engine.sprites import MEETING_TABLE, WHITEBOARD_BLANK
        scene.furniture = [
            FurnitureItem(name="meeting_table", sprite=MEETING_TABLE, x=10, y=10),
            FurnitureItem(name="whiteboard_plan", sprite=WHITEBOARD_BLANK, x=15, y=6),
            FurnitureItem(name="coffee", sprite=WHITEBOARD_BLANK, x=5, y=5),
        ]
        return scene

    def test_after_1_5s_removes_meeting_furniture(self):
        scene = self._make_scene_with_meeting_furniture()
        scene.characters = [_make_char("A", x=40, y=12)]
        seq = ExitPlanSequence(scene=scene)
        seq.start()

        # Tick past WRAP_UP (1.5s)
        seq.tick(1.6)

        names = [f.name for f in scene.furniture]
        assert "meeting_table" not in names
        assert "whiteboard_plan" not in names

    def test_non_meeting_furniture_is_preserved(self):
        scene = self._make_scene_with_meeting_furniture()
        scene.characters = [_make_char("A", x=40, y=12)]
        seq = ExitPlanSequence(scene=scene)
        seq.start()

        seq.tick(1.6)

        names = [f.name for f in scene.furniture]
        assert "coffee" in names


class TestExitPlanSequenceCompletion:
    def setup_method(self):
        set_language("en")

    def test_completes_and_sets_plan_active_false(self):
        scene = MockScene()
        scene.characters = [_make_char("A", x=40, y=12)]
        assert scene._plan_active is True

        seq = ExitPlanSequence(scene=scene)
        seq.start()

        total = 0.0
        dt = 0.1
        while not seq.is_complete and total < 10.0:
            seq.tick(dt)
            total += dt

        assert seq.is_complete, (
            f"ExitPlanSequence not complete after {total:.1f}s "
            f"(stage={seq.stage})"
        )
        assert scene._plan_active is False

    def test_completes_within_eight_seconds(self):
        scene = MockScene()
        scene.characters = [_make_char("B", x=40, y=12)]
        seq = ExitPlanSequence(scene=scene)
        seq.start()

        total = 0.0
        dt = 0.1
        while not seq.is_complete and total < 8.0:
            seq.tick(dt)
            total += dt

        assert seq.is_complete

    def test_completion_stage_is_done(self):
        scene = MockScene()
        scene.characters = [_make_char("A", x=40, y=12)]
        seq = ExitPlanSequence(scene=scene)
        seq.start()

        for _ in range(100):
            if seq.is_complete:
                break
            seq.tick(0.1)

        assert seq.stage == ExitPlanStage.DONE
