"""Additional scene tests — resize, upgrade, furniture animations, tick."""
from engine.scene import Scene
from engine.characters import State
from engine.bubbles import set_language


def _make_scene(w: int = 70, h: int = 25, level: str = "small_office") -> Scene:
    set_language("en")
    scene = Scene(width=w, height=h, theme_name="claude", office_level=level)
    scene.populate()
    return scene


class TestResize:
    def test_preserves_characters(self):
        scene = _make_scene()
        initial_count = len(scene.characters)
        initial_name = scene.characters[0].name
        scene.resize(100, 35)
        assert len(scene.characters) == initial_count
        assert scene.characters[0].name == initial_name

    def test_updates_dimensions(self):
        scene = _make_scene()
        scene.resize(100, 35)
        assert scene.width == 100
        assert scene.height == 35

    def test_clamps_character_positions(self):
        scene = _make_scene(w=100, h=40)
        # Move a char near the edge
        scene.characters[0].x = 95.0
        scene.characters[0].y = 35.0
        scene.resize(60, 25)
        # Char position should be clamped
        assert scene.characters[0].x <= 60 - 8
        assert scene.characters[0].y <= 25 - 6


class TestUpgradeOffice:
    def test_same_level_noop(self):
        scene = _make_scene(level="garage")
        scene.upgrade_office("garage")
        assert scene.office_level == "garage"
        assert scene._upgrade is None

    def test_level_change_creates_sequence(self):
        scene = _make_scene(level="garage")
        scene.upgrade_office("small_office")
        assert scene.office_level == "small_office"
        assert scene._upgrade is not None


class TestFurnitureAnimations:
    def test_open_door(self):
        scene = _make_scene()
        scene.door_state = "closed"
        scene.open_door()
        assert scene.door_state == "opening"

    def test_open_door_already_open_noop(self):
        scene = _make_scene()
        scene.door_state = "open"
        scene.open_door()
        assert scene.door_state == "open"

    def test_close_door(self):
        scene = _make_scene()
        scene.door_state = "open"
        scene.close_door()
        assert scene.door_state == "closing"

    def test_boot_monitors(self):
        scene = _make_scene()
        scene.monitor_state = "off"
        scene.boot_monitors()
        assert scene.monitor_state == "boot1"

    def test_shutdown_monitors(self):
        scene = _make_scene()
        scene.monitor_state = "on"
        scene.shutdown_monitors()
        assert scene.monitor_state == "shutdown"

    def test_start_coffee(self):
        scene = _make_scene()
        scene.coffee_state = "idle"
        scene.start_coffee()
        assert scene.coffee_state == "brewing1"

    def test_tick_door_animation(self):
        scene = _make_scene()
        scene.door_state = "opening"
        scene.door_timer = 0.0
        scene._tick_furniture_animations(0.6)
        assert scene.door_state == "open"

    def test_tick_monitor_boot_sequence(self):
        scene = _make_scene()
        scene.monitor_state = "boot1"
        scene.monitor_timer = 0.0
        scene._tick_furniture_animations(0.5)
        assert scene.monitor_state == "boot2"

    def test_tick_coffee_brewing(self):
        scene = _make_scene()
        scene.coffee_state = "brewing1"
        scene.coffee_timer = 0.0
        scene._tick_furniture_animations(1.1)
        assert scene.coffee_state == "brewing2"


class TestSprites:
    def test_get_door_sprite_closed(self):
        scene = _make_scene()
        scene.door_state = "closed"
        sprite = scene.get_door_sprite()
        assert isinstance(sprite, list)
        assert len(sprite) > 0

    def test_get_door_sprite_open(self):
        scene = _make_scene()
        scene.door_state = "open"
        sprite = scene.get_door_sprite()
        assert isinstance(sprite, list)

    def test_get_monitor_pixels(self):
        scene = _make_scene()
        scene.monitor_state = "on"
        pixels = scene.get_monitor_pixels()
        assert isinstance(pixels, str)

    def test_get_coffee_sprite(self):
        scene = _make_scene()
        scene.coffee_state = "idle"
        sprite = scene.get_coffee_sprite()
        assert isinstance(sprite, list)


class TestSceneProperties:
    def test_intro_active_initially_false(self):
        scene = _make_scene()
        assert scene.intro_active is False

    def test_intro_active_after_start(self):
        scene = _make_scene()
        scene.start_intro()
        assert scene.intro_active is True

    def test_outro_active(self):
        scene = _make_scene()
        assert scene.outro_active is False
        scene.start_outro()
        assert scene.outro_active is True

    def test_plan_active_initially_false(self):
        scene = _make_scene()
        assert scene.plan_active is False
