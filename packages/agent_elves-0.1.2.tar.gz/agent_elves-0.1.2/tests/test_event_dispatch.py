"""Tests for engine.event_dispatch — tool dispatch, character assignment, plan mode."""
from engine.scene import Scene
from engine.characters import State
from engine.bubbles import set_language
from engine import event_dispatch


def _make_scene(w=70, h=25, level="small_office"):
    set_language("en")
    scene = Scene(width=w, height=h, theme_name="claude", office_level=level)
    scene.populate()
    return scene


class TestMakeTaskId:
    def test_increments(self):
        scene = _make_scene()
        result1 = event_dispatch.make_task_id(scene, "Read")
        result2 = event_dispatch.make_task_id(scene, "Write")
        assert result1 == "Read:1"
        assert result2 == "Write:2"
        assert scene._next_task_id == 2


class TestPickCharacter:
    def test_picks_idle(self):
        scene = _make_scene()
        char = event_dispatch.pick_character_for_tool(scene, "Read")
        assert char is not None
        assert not char.is_agent

    def test_returns_none_all_busy(self):
        scene = _make_scene()
        for c in scene.characters:
            c.busy = True
        char = event_dispatch.pick_character_for_tool(scene, "Read")
        assert char is None

    def test_load_balance(self):
        scene = _make_scene()
        # Give char[0] many tasks — use a generic tool so no specialist match
        scene._char_task_counts[scene.characters[0].name] = 10
        scene._char_task_counts[scene.characters[1].name] = 0
        selected = event_dispatch.pick_character_for_tool(scene, "SomeGenericTool")
        # Should pick the char with fewer tasks (not necessarily char[1] due to specialist matching)
        assert selected is not None
        assert scene._char_task_counts.get(selected.name, 0) <= 10


class TestPickFreeDesk:
    def test_returns_desk_position(self):
        scene = _make_scene()
        pos = event_dispatch.pick_free_desk(scene)
        assert isinstance(pos, tuple)
        assert len(pos) == 2

    def test_avoids_occupied(self):
        scene = _make_scene()
        if len(scene._desk_positions) >= 2:
            # Unassign all chars first, then occupy only desk[0]
            for c in scene.characters:
                c.desk_x = None
                c.desk_y = None
            scene.characters[0].desk_x, scene.characters[0].desk_y = scene._desk_positions[0]
            pos = event_dispatch.pick_free_desk(scene)
            assert pos != scene._desk_positions[0]


class TestHandleEvent:
    def test_tool_pre_dispatches(self):
        scene = _make_scene()
        event_dispatch.handle_event(scene, {
            "type": "tool_pre",
            "tool": "Read",
            "input": {"file_path": "/tmp/test.py"},
        })
        assert any(c.busy for c in scene.characters)

    def test_tool_post_releases(self):
        scene = _make_scene()
        # First start a tool
        event_dispatch.handle_event(scene, {
            "type": "tool_pre",
            "tool": "Read",
            "input": {"file_path": "/tmp/test.py"},
        })
        initial_completed = scene.completed_count
        event_dispatch.handle_event(scene, {
            "type": "tool_post",
            "tool": "Read",
            "error": False,
        })
        assert scene.completed_count == initial_completed + 1

    def test_shutdown_noop(self):
        scene = _make_scene()
        states_before = [c.state for c in scene.characters]
        event_dispatch.handle_event(scene, {"type": "shutdown"})
        states_after = [c.state for c in scene.characters]
        assert states_before == states_after


class TestOnToolStart:
    def test_regular_tool(self):
        scene = _make_scene()
        event_dispatch.on_tool_start(scene, {
            "tool": "Read",
            "input": {"file_path": "/tmp/test.py"},
        })
        busy = [c for c in scene.characters if c.busy]
        assert len(busy) >= 1

    def test_agent_tool_spawns_contractor(self):
        scene = _make_scene()
        initial = len(scene.characters)
        event_dispatch.on_tool_start(scene, {
            "tool": "Agent",
            "input": {"subagent_type": "Explore", "prompt": "test"},
        })
        assert len(scene.characters) > initial
        new_char = scene.characters[-1]
        assert new_char.is_agent
        assert "Smith" in new_char.name


class TestOnToolEnd:
    def test_releases_character(self):
        scene = _make_scene()
        c = scene.characters[0]
        c.busy = True
        c.current_task_id = "Read:1"
        c.state = State.TYPING
        event_dispatch.on_tool_end(scene, {"tool": "Read", "error": False})
        assert not c.busy

    def test_increments_completed(self):
        scene = _make_scene()
        c = scene.characters[0]
        c.busy = True
        c.current_task_id = "Read:1"
        initial = scene.completed_count
        event_dispatch.on_tool_end(scene, {"tool": "Read", "error": False})
        assert scene.completed_count == initial + 1

    def test_error_sets_frustrated(self):
        scene = _make_scene()
        c = scene.characters[0]
        c.busy = True
        c.current_task_id = "Read:1"
        c.state = State.TYPING
        event_dispatch.on_tool_end(scene, {"tool": "Read", "error": True})
        assert c.state == State.FRUSTRATED


class TestOnToolEndQuiet:
    def test_releases_during_plan_mode(self):
        scene = _make_scene()
        c = scene.characters[0]
        c.busy = True
        c.current_task_id = "Read:1"
        event_dispatch.on_tool_end_quiet(scene, {"tool": "Read"})
        assert not c.busy

    def test_increments_completed(self):
        scene = _make_scene()
        initial = scene.completed_count
        c = scene.characters[0]
        c.busy = True
        c.current_task_id = "Read:1"
        event_dispatch.on_tool_end_quiet(scene, {"tool": "Read"})
        assert scene.completed_count == initial + 1
