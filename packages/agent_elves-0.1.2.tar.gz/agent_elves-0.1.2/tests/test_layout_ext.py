"""Tests for engine.layout — furniture placement, desk management."""
from engine.scene import Scene
from engine.characters import Character, State
from engine.levels import LEVEL_DEFS
from engine.bubbles import set_language
from engine.layout import layout_office, add_desk, find_open_spot, add_temp_desk, remove_temp_desk


def _make_scene(w=70, h=40, level="garage"):
    set_language("en")
    scene = Scene(width=w, height=h, theme_name="claude", office_level=level)
    scene.furniture = []
    scene._desk_positions = []
    scene._desk_type_idx = 0
    return scene


class TestLayoutOffice:
    def test_garage_has_door(self):
        scene = _make_scene()
        layout_office(scene, 70, 40, LEVEL_DEFS[0], char_count=1)
        doors = [f for f in scene.furniture if f.name == "door"]
        assert len(doors) == 1

    def test_garage_has_desk(self):
        scene = _make_scene()
        layout_office(scene, 70, 40, LEVEL_DEFS[0], char_count=1)
        desks = [f for f in scene.furniture if f.name == "desk"]
        assert len(desks) >= 1

    def test_studio_has_bookshelf(self):
        scene = _make_scene(level="studio")
        layout_office(scene, 70, 40, LEVEL_DEFS[4], char_count=2)
        bookshelves = [f for f in scene.furniture if f.name == "bookshelf"]
        assert len(bookshelves) > 0

    def test_penthouse_has_many_furniture(self):
        scene = _make_scene(level="penthouse")
        layout_office(scene, 70, 40, LEVEL_DEFS[8], char_count=3)
        names = {f.name for f in scene.furniture}
        assert "door" in names
        assert "desk" in names

    def test_dream_office_has_gold_wall(self):
        scene = _make_scene(w=100, h=40, level="dream_office")
        layout_office(scene, 100, 40, LEVEL_DEFS[9], char_count=4)
        gold = [f for f in scene.furniture if f.name == "gold_wall"]
        assert len(gold) > 0

    def test_mid_level_has_windows(self):
        scene = _make_scene(level="office")
        layout_office(scene, 70, 40, LEVEL_DEFS[5], char_count=3)
        windows = [f for f in scene.furniture if "window" in f.name]
        assert len(windows) > 0

    def test_high_level_has_coffee(self):
        scene = _make_scene(level="loft")
        layout_office(scene, 70, 40, LEVEL_DEFS[6], char_count=3)
        coffee = [f for f in scene.furniture if f.name == "coffee"]
        assert len(coffee) > 0


class TestAddDesk:
    def test_adds_furniture(self):
        scene = _make_scene()
        initial = len(scene.furniture)
        add_desk(scene, 10, 10)
        assert len(scene.furniture) == initial + 1
        assert scene.furniture[-1].name == "desk"

    def test_registers_position(self):
        scene = _make_scene()
        add_desk(scene, 10, 10)
        assert len(scene._desk_positions) == 1
        assert scene._desk_positions[0] == (14.0, 8.0)  # x+4, y-2

    def test_cycles_desk_types(self):
        scene = _make_scene()
        add_desk(scene, 10, 10)
        add_desk(scene, 25, 10)
        assert scene._desk_type_idx == 2


class TestFindOpenSpot:
    def test_returns_int_tuple(self):
        scene = _make_scene()
        spot = find_open_spot(scene)
        assert isinstance(spot, tuple)
        assert isinstance(spot[0], int)
        assert isinstance(spot[1], int)

    def test_within_bounds(self):
        scene = _make_scene()
        x, y = find_open_spot(scene)
        assert 0 <= x < scene.width
        assert 0 <= y < scene.height


class TestTempDesk:
    def test_add_temp_desk(self):
        scene = _make_scene()
        char = Character(name="Test", x=20.0, y=15.0, color_index=1)
        initial_furn = len(scene.furniture)
        initial_desks = len(scene._desk_positions)
        add_temp_desk(scene, char)
        assert len(scene.furniture) == initial_furn + 1
        assert scene.furniture[-1].name == "desk_portable"
        assert len(scene._desk_positions) == initial_desks + 1
        assert char.desk_x is not None

    def test_remove_temp_desk(self):
        scene = _make_scene()
        char = Character(name="Test", x=20.0, y=15.0, color_index=1)
        add_temp_desk(scene, char)
        initial_desks = len(scene._desk_positions)
        remove_temp_desk(scene, char)
        assert len(scene._desk_positions) == initial_desks - 1
        # Furniture item is replaced with "removed" placeholder
        removed = [f for f in scene.furniture if f.name == "removed"]
        assert len(removed) == 1
