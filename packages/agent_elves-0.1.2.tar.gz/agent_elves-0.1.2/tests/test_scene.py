"""Tests for engine.scene — layout, task tracking, interactions, whiteboard."""
from engine.scene import Scene
from engine.characters import State
from engine.bubbles import set_language


def _make_scene(w: int = 70, h: int = 25) -> Scene:
    set_language("en")
    scene = Scene(width=w, height=h, theme_name="claude")
    scene.populate()
    return scene


def _make_scene_multi(w: int = 70, h: int = 25) -> Scene:
    """Make a scene with enough characters for multi-elf tests (uses small_office level)."""
    set_language("en")
    scene = Scene(width=w, height=h, theme_name="claude", office_level="small_office")
    scene.populate()
    return scene


class TestLayout:
    def test_small_layout(self):
        # garage level has elf_count=1; max_by_width for w<40 is 2 → min(1,2)=1
        scene = _make_scene(35, 15)
        assert len(scene.characters) == 1
        assert len(scene._desk_positions) >= 1

    def test_medium_layout(self):
        # garage level has elf_count=1; max_by_width for w<55 is 3 → min(1,3)=1
        scene = _make_scene(55, 20)
        assert len(scene.characters) == 1
        assert len(scene._desk_positions) >= 1

    def test_large_layout(self):
        # garage level has elf_count=1; max_by_width for w>=55 is 4 → min(1,4)=1
        scene = _make_scene(80, 30)
        assert len(scene.characters) == 1
        assert len(scene._desk_positions) >= 1


class TestTaskTracking:
    def test_task_id_increments(self):
        scene = _make_scene()
        id1 = scene._make_task_id("Bash")
        id2 = scene._make_task_id("Edit")
        assert id1 == "Bash:1"
        assert id2 == "Edit:2"

    def test_tool_start_assigns_character(self):
        scene = _make_scene()
        scene.handle_event({"type": "tool_pre", "tool": "Bash",
                            "input": {"command": "test"}})
        busy = [c for c in scene.characters if c.busy]
        assert len(busy) == 1
        assert busy[0].current_task_id.startswith("Bash:")

    def test_tool_end_releases_correct_character(self):
        scene = _make_scene_multi()
        scene.handle_event({"type": "tool_pre", "tool": "Edit",
                            "input": {"file_path": "/a.py"}})
        scene.handle_event({"type": "tool_pre", "tool": "Grep",
                            "input": {"pattern": "TODO"}})
        assert sum(1 for c in scene.characters if c.busy) == 2

        scene.handle_event({"type": "tool_post", "tool": "Edit", "input": {}})
        busy = [c for c in scene.characters if c.busy]
        assert len(busy) == 1
        assert busy[0].current_task_id.startswith("Grep:")

    def test_per_char_task_counts(self):
        scene = _make_scene()
        for _ in range(3):
            scene.handle_event({"type": "tool_pre", "tool": "Bash",
                                "input": {"command": "x"}})
            for _ in range(20):
                scene.tick(0.1)
            scene.handle_event({"type": "tool_post", "tool": "Bash", "input": {}})
            for _ in range(20):
                scene.tick(0.1)

        assert sum(scene._char_task_counts.values()) == 3


class TestRoleSpecialization:
    def test_bash_goes_to_engineer(self):
        scene = _make_scene()
        scene.handle_event({"type": "tool_pre", "tool": "Bash",
                            "input": {"command": "test"}})
        busy = [c for c in scene.characters if c.busy]
        assert busy[0].role == "engineer"

    def test_read_goes_to_researcher(self):
        # Need at least 2 characters so a researcher role exists (small_office level)
        scene = _make_scene_multi()
        scene.handle_event({"type": "tool_pre", "tool": "Read",
                            "input": {"file_path": "/x"}})
        busy = [c for c in scene.characters if c.busy]
        assert busy[0].role == "researcher"


class TestAgentSpawnDepart:
    def test_agent_spawn(self):
        scene = _make_scene()
        initial = len(scene.characters)
        scene.handle_event({"type": "tool_pre", "tool": "Agent",
                            "input": {"name": "helper"}})
        assert len(scene.characters) == initial + 1
        assert scene.characters[-1].is_agent
        # Agent name is formatted as Smith(type) with capitalized type
        assert scene.characters[-1].name == "Smith(Helper)"

    def test_agent_depart_after_complete(self):
        scene = _make_scene()
        scene.handle_event({"type": "tool_pre", "tool": "Agent",
                            "input": {"name": "scout"}})
        for _ in range(50):
            scene.tick(0.1)
        scene.handle_event({"type": "tool_post", "tool": "Agent", "input": {}})
        for _ in range(300):
            scene.tick(0.1)
        agents = [c for c in scene.characters if c.is_agent]
        assert len(agents) == 0


class TestTaskBox:
    def test_empty_shows_waiting(self):
        scene = _make_scene()
        lines = scene.get_task_box_lines(50)
        # get_task_box_lines returns list of (line_string, color_index) tuples
        assert any("waiting" in l[0] for l in lines)

    def test_tasks_appear(self):
        scene = _make_scene()
        scene.handle_event({"type": "tool_pre", "tool": "Bash",
                            "input": {"command": "npm test"}})
        lines = scene.get_task_box_lines(50)
        # Active tasks show a blink indicator (▸ or ▹)
        assert any("▸" in l[0] or "▹" in l[0] for l in lines)

    def test_completed_marked(self):
        scene = _make_scene()
        scene.handle_event({"type": "tool_pre", "tool": "Bash",
                            "input": {"command": "test"}})
        scene.handle_event({"type": "tool_post", "tool": "Bash", "input": {}})
        lines = scene.get_task_box_lines(50)
        # Done tasks are marked with ✓
        assert any("✓" in l[0] for l in lines)

    def test_dq_box_borders(self):
        scene = _make_scene()
        scene.handle_event({"type": "tool_pre", "tool": "Bash",
                            "input": {"command": "test"}})
        lines = scene.get_task_box_lines(50)
        # Each element is a (line_string, color_index) tuple
        assert lines[0][0].startswith("╔")
        assert lines[-1][0].startswith("╚")

    def test_two_column_layout(self):
        scene = _make_scene()
        for i in range(4):
            scene.handle_event({"type": "tool_pre", "tool": "Bash",
                                "input": {"command": f"cmd{i}"}})
        lines = scene.get_task_box_lines(60)
        # Box borders use ║; inner lines also contain ║
        assert any("║" in l[0] for l in lines[1:-1])

    def test_max_4_items(self):
        # Use multi-elf scene so multiple tasks can be assigned simultaneously
        scene = _make_scene_multi()
        for i in range(12):
            scene.handle_event({"type": "tool_pre", "tool": "Bash",
                                "input": {"command": f"cmd{i}"}})
        assert len(scene.task_log) <= 10  # capped at 10 internally


class TestIntroOutro:
    def test_intro_completes(self):
        scene = Scene(width=60, height=20, theme_name="claude")
        scene.start_intro()
        assert scene.intro_active
        for _ in range(300):
            scene.tick(0.1)
        assert not scene.intro_active
        assert len(scene.characters) > 0

    def test_outro_completes(self):
        scene = _make_scene()
        scene.start_outro()
        assert scene.outro_active
        for _ in range(300):
            scene.tick(0.1)
        assert scene.outro_complete


class TestStatusLine:
    def test_normal_status(self):
        scene = _make_scene()
        line = scene.get_status_line(60)
        assert "Agent Elves" in line
        assert "小精靈" not in line  # en language

    def test_intro_status(self):
        scene = Scene(width=60, height=20, theme_name="claude")
        scene.start_intro()
        line = scene.get_status_line(60)
        assert "Opening" in line

    def test_atmosphere_icon(self):
        scene = _make_scene()
        line = scene.get_status_line(80)
        # Should contain one of the atmosphere icons
        assert any(icon in line for icon in ["☀", "⛅", "🌆", "🌙"])
