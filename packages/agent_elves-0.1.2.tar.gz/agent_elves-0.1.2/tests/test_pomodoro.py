"""Tests for engine.pomodoro — PomodoroPhase enum and PomodoroTimer dataclass."""
from engine.pomodoro import PomodoroPhase, PomodoroTimer


class TestInitialState:
    def test_phase_is_off(self):
        p = PomodoroTimer()
        assert p.phase == PomodoroPhase.OFF

    def test_remaining_is_zero(self):
        p = PomodoroTimer()
        assert p.remaining == 0.0

    def test_completed_pomodoros_is_zero(self):
        p = PomodoroTimer()
        assert p.completed_pomodoros == 0


class TestToggle:
    def test_off_to_work(self):
        p = PomodoroTimer()
        p.toggle()
        assert p.phase == PomodoroPhase.WORK
        assert p.remaining == 25 * 60

    def test_off_to_work_clears_pending_transition(self):
        p = PomodoroTimer()
        p._transition_pending = "to_work"
        p.toggle()
        assert p._transition_pending == ""

    def test_work_to_off(self):
        p = PomodoroTimer()
        p.toggle()  # OFF → WORK
        p.toggle()  # WORK → OFF
        assert p.phase == PomodoroPhase.OFF
        assert p.remaining == 0.0

    def test_break_to_off(self):
        p = PomodoroTimer()
        p.phase = PomodoroPhase.BREAK
        p.remaining = 60.0
        p.toggle()
        assert p.phase == PomodoroPhase.OFF
        assert p.remaining == 0.0

    def test_cancel_clears_pending_transition(self):
        p = PomodoroTimer()
        p.toggle()  # OFF → WORK
        p._transition_pending = "to_break"
        p.toggle()  # WORK → OFF
        assert p._transition_pending == ""


class TestTick:
    def test_tick_does_nothing_when_off(self):
        p = PomodoroTimer()
        p.tick(10.0)
        assert p.phase == PomodoroPhase.OFF
        assert p.remaining == 0.0

    def test_tick_decrements_remaining(self):
        p = PomodoroTimer()
        p.toggle()  # OFF → WORK
        initial = p.remaining
        p.tick(5.0)
        assert p.remaining == initial - 5.0

    def test_tick_work_to_break_when_remaining_hits_zero(self):
        p = PomodoroTimer()
        p.toggle()  # OFF → WORK
        p.remaining = 1.0
        p.tick(1.0)
        assert p.phase == PomodoroPhase.BREAK
        assert p.remaining == p.break_duration

    def test_tick_work_to_break_increments_completed_pomodoros(self):
        p = PomodoroTimer()
        p.toggle()  # OFF → WORK
        p.remaining = 0.5
        p.tick(1.0)
        assert p.completed_pomodoros == 1

    def test_tick_work_to_break_sets_transition_pending(self):
        p = PomodoroTimer()
        p.toggle()  # OFF → WORK
        p.remaining = 0.5
        p.tick(1.0)
        assert p._transition_pending == "to_break"

    def test_tick_break_to_work_when_remaining_hits_zero(self):
        p = PomodoroTimer()
        p.phase = PomodoroPhase.BREAK
        p.remaining = 1.0
        p.tick(1.0)
        assert p.phase == PomodoroPhase.WORK
        assert p.remaining == p.work_duration

    def test_tick_break_to_work_sets_transition_pending(self):
        p = PomodoroTimer()
        p.phase = PomodoroPhase.BREAK
        p.remaining = 0.5
        p.tick(1.0)
        assert p._transition_pending == "to_work"

    def test_tick_does_not_increment_pomodoros_on_break_to_work(self):
        p = PomodoroTimer()
        p.phase = PomodoroPhase.BREAK
        p.remaining = 0.5
        p.completed_pomodoros = 1
        p.tick(1.0)
        assert p.completed_pomodoros == 1


class TestConsumeTransition:
    def test_returns_pending_transition(self):
        p = PomodoroTimer()
        p._transition_pending = "to_break"
        result = p.consume_transition()
        assert result == "to_break"

    def test_clears_pending_after_consume(self):
        p = PomodoroTimer()
        p._transition_pending = "to_break"
        p.consume_transition()
        assert p._transition_pending == ""

    def test_returns_empty_string_when_no_pending(self):
        p = PomodoroTimer()
        result = p.consume_transition()
        assert result == ""

    def test_second_consume_returns_empty(self):
        p = PomodoroTimer()
        p._transition_pending = "to_work"
        p.consume_transition()
        result = p.consume_transition()
        assert result == ""


class TestFormatDisplay:
    def test_off_shows_dashes(self):
        p = PomodoroTimer()
        assert p.format_display() == "◉--:--"

    def test_work_shows_correct_time(self):
        p = PomodoroTimer()
        p.toggle()  # OFF → WORK, remaining = 25*60 = 1500
        assert p.format_display() == "◉25:00 WORK"

    def test_work_shows_mid_session_time(self):
        p = PomodoroTimer()
        p.phase = PomodoroPhase.WORK
        p.remaining = 9 * 60 + 5  # 9:05
        assert p.format_display() == "◉09:05 WORK"

    def test_break_shows_brk_label(self):
        p = PomodoroTimer()
        p.phase = PomodoroPhase.BREAK
        p.remaining = 5 * 60
        assert p.format_display() == "◉05:00 BRK"

    def test_break_shows_mid_break_time(self):
        p = PomodoroTimer()
        p.phase = PomodoroPhase.BREAK
        p.remaining = 60 + 30  # 1:30
        assert p.format_display() == "◉01:30 BRK"


class TestFullCycle:
    def test_work_to_break_to_work(self):
        p = PomodoroTimer()
        p.toggle()  # OFF → WORK

        # Drain work phase
        p.remaining = 1.0
        p.tick(1.0)
        assert p.phase == PomodoroPhase.BREAK
        assert p.completed_pomodoros == 1
        assert p.consume_transition() == "to_break"

        # Drain break phase
        p.remaining = 1.0
        p.tick(1.0)
        assert p.phase == PomodoroPhase.WORK
        assert p.remaining == p.work_duration
        assert p.consume_transition() == "to_work"

    def test_multiple_pomodoros_accumulate(self):
        p = PomodoroTimer()
        p.toggle()  # OFF → WORK

        for _ in range(3):
            p.remaining = 0.5
            p.tick(1.0)  # WORK → BREAK
            p.remaining = 0.5
            p.tick(1.0)  # BREAK → WORK

        assert p.completed_pomodoros == 3
        assert p.phase == PomodoroPhase.WORK
