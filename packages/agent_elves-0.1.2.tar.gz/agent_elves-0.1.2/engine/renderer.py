"""Double-buffered curses renderer for flicker-free animation."""
from __future__ import annotations

import curses
import unicodedata
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .scene import Scene


def _char_width(ch: str) -> int:
    """Return display width of a single character (0, 1, or 2)."""
    cp = ord(ch)
    # Zero-width: variation selectors, combining marks
    if cp == 0xFE0F or cp == 0xFE0E:
        return 0
    cat = unicodedata.category(ch)
    if cat.startswith("M") or cat == "Cc":  # combining marks, control chars
        return 0
    eaw = unicodedata.east_asian_width(ch)
    if eaw in ("W", "F"):
        return 2
    # Ambiguous symbols (emoji-like) are 2 cols,
    # but Box Drawing (2500-257F) and Block Elements (2580-259F) are 1 col
    return 1


def init_colors():
    """Initialize curses color pairs."""
    curses.start_color()
    curses.use_default_colors()
    # Color pairs for characters (1-6) — avoid YELLOW (used by furniture pair 8)
    curses.init_pair(1, curses.COLOR_CYAN, -1)     # cool blue
    curses.init_pair(2, curses.COLOR_GREEN, -1)    # fresh green
    curses.init_pair(3, curses.COLOR_MAGENTA, -1)  # pink
    curses.init_pair(4, curses.COLOR_RED, -1)      # coral
    curses.init_pair(5, curses.COLOR_WHITE, -1)    # clean white
    curses.init_pair(6, curses.COLOR_BLUE, -1)     # blue
    # UI elements
    curses.init_pair(7, curses.COLOR_WHITE, curses.COLOR_BLUE)   # status bar
    curses.init_pair(8, curses.COLOR_YELLOW, -1)   # furniture
    curses.init_pair(9, curses.COLOR_GREEN, -1)    # bubble
    curses.init_pair(10, curses.COLOR_WHITE, -1)   # floor
    curses.init_pair(11, curses.COLOR_YELLOW, -1)  # power-up effects (⚡ ripple scouter)
    curses.init_pair(12, curses.COLOR_CYAN, -1)   # HUD bar


class Renderer:
    """Renders a Scene onto a curses window with minimal redraws.

    Uses double-buffering with diff-only updates to minimize terminal output.
    Skips refresh entirely when nothing changed to avoid triggering
    WezTerm's IME anchor recalculation on the right tmux pane.
    """

    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.prev: dict[tuple[int, int], tuple[str, int]] = {}
        self._idle_frames: int = 0  # consecutive frames with zero dirty cells

    def draw(self, scene: Scene):
        """Render the scene. Only update cells that changed."""
        from .atmosphere import get_atmosphere
        h, w = self.stdscr.getmaxyx()
        next_buf: dict[tuple[int, int], tuple[str, int]] = {}
        atmo = get_atmosphere()

        # Layer 0: HUD bar (dynamic 1-2 rows)
        hud_lines = scene.get_hud_lines(w)
        hud_attr = curses.color_pair(12) | curses.A_BOLD
        for row_i, hud_line in enumerate(hud_lines):
            col = 0
            for ch in hud_line:
                if col >= w - 1:
                    break
                cw = _char_width(ch)
                if cw == 0:
                    continue  # skip variation selectors / combining marks
                next_buf[(row_i, col)] = (ch, hud_attr)
                if cw == 2 and col + 1 < w - 1:
                    next_buf[(row_i, col + 1)] = ("", hud_attr)
                col += cw

        y_off = len(hud_lines)  # dynamic offset based on actual HUD rows

        # Layer 1: Floor
        floor_attr = curses.color_pair(10) | curses.A_DIM
        if atmo.floor_dim:
            floor_attr = curses.A_DIM  # darker floor at night
        for y in range(y_off, min(h - 1, scene.height + y_off)):
            for x in range(min(w, scene.width)):
                ch = "." if (x + y) % 7 == 0 else " "
                next_buf[(y, x)] = (ch, floor_attr)

        # Pre-compute task box position so walls don't overlap
        _pre_box_w = min(w - 2, scene.width - 2)
        _pre_task_lines = scene.get_task_box_lines(_pre_box_w)
        _pre_box_h = len(_pre_task_lines) if _pre_task_lines else 0
        _pre_box_y = (min(h - 2, scene.height - 2) - _pre_box_h) if _pre_box_h else h

        # Layer 2: Walls / border (top + left + right; bottom omitted — task box is the visual floor)
        wall_attr = curses.color_pair(8) | atmo.wall_attr_extra
        wall_right = min(scene.width - 1, w - 2)
        wall_bottom_y = max(y_off + 1, _pre_box_y - 1)  # left/right walls stop just above task box
        # Top wall
        for x in range(wall_right + 1):
            next_buf[(y_off, x)] = ("═", wall_attr)
        # Left wall
        for y in range(y_off, wall_bottom_y + 1):
            next_buf[(y, 0)] = ("║", wall_attr)
        # Right wall
        for y in range(y_off, wall_bottom_y + 1):
            if wall_right > 0:
                next_buf[(y, wall_right)] = ("║", wall_attr)
        # Top corners only
        if 0 <= y_off < h and 0 <= wall_right < w:
            next_buf[(y_off, 0)] = ("╔", wall_attr)
            next_buf[(y_off, wall_right)] = ("╗", wall_attr)

        # Layers 3+4+5: Y-sorted rendering — background furniture, characters, and desks
        # merged into a single painter's-algorithm pass so near objects occlude far ones.
        from .characters import State as _CharState
        import time as _render_time_char
        import time as _render_time

        furn_attr = curses.color_pair(8)
        if atmo.furniture_dim:
            furn_attr = curses.color_pair(8) | curses.A_DIM

        _blink = int(_render_time.monotonic() * 1.5) % 2  # 1.5Hz blink (slower = fewer diffs)

        # Collect all renderable objects with their Y sort key (bottom edge)
        _render_objects = []

        for item in scene.furniture:
            if not item.foreground and item.sprite:  # background furniture
                y_bottom = item.y + len(item.sprite)
                _render_objects.append((y_bottom, "bg_furn", item, None))

        for char in scene.characters:
            sprite_lines = char.get_sprite_lines(scene.theme_name)
            y_bottom = int(char.y) + len(sprite_lines)
            _render_objects.append((y_bottom, "char", char, sprite_lines))

        for fi, item in enumerate(scene.furniture):
            if item.foreground:  # desks
                y_bottom = item.y + len(item.sprite)
                _render_objects.append((y_bottom, "desk", item, fi))

        # Sort by Y ascending (far objects first, near objects last = painter's algorithm)
        _render_objects.sort(key=lambda r: r[0])

        for _y_key, obj_type, obj, extra in _render_objects:
            if obj_type == "bg_furn":
                item = obj
                # Use animated sprite for door and coffee
                if item.name == "door":
                    sprite = scene.get_door_sprite()
                elif item.name == "coffee":
                    sprite = scene.get_coffee_sprite()
                else:
                    sprite = item.sprite
                for row_i, line in enumerate(sprite):
                    sy = item.y + row_i + y_off
                    for col_i, ch in enumerate(line):
                        sx = item.x + col_i
                        if 0 < sy < h - 1 and 0 < sx < w - 1 and ch != " ":
                            next_buf[(sy, sx)] = (ch, furn_attr)

                # After drawing window frame, fill interior with weather
                if item.name.startswith("window") and scene._weather:
                    import random as _rand_w
                    weather = scene._weather
                    sprite_h = len(sprite)
                    for wy in range(item.y + 1 + y_off, item.y + sprite_h - 1 + y_off):
                        for wx in range(item.x + 1, item.x + item.width - 1):
                            if 0 < wy < h - 1 and 0 < wx < w - 1:
                                if weather.description == "sunny":
                                    # Place a dot in center, rest bright space
                                    mid_x = item.x + item.width // 2
                                    mid_y = item.y + 1 + y_off
                                    if wx == mid_x and wy == mid_y:
                                        ch2 = "."
                                        attr2 = curses.color_pair(8) | curses.A_BOLD
                                    else:
                                        continue  # leave as floor/space
                                    next_buf[(wy, wx)] = (ch2, attr2)
                                elif weather.description in ("rain", "storm"):
                                    if _rand_w.random() < 0.3:
                                        next_buf[(wy, wx)] = ("|", curses.color_pair(6))
                                elif weather.description == "snow":
                                    if _rand_w.random() < 0.2:
                                        next_buf[(wy, wx)] = ("*", curses.color_pair(5) | curses.A_BOLD)
                                elif weather.description in ("cloudy", "foggy"):
                                    if wy == item.y + 1 + y_off and _rand_w.random() < 0.4:
                                        next_buf[(wy, wx)] = ("~", curses.color_pair(5))

            elif obj_type == "char":
                char = obj
                sprite_lines = extra
                attr = curses.color_pair(char.color_index)
                if atmo.char_bold:
                    attr |= curses.A_BOLD

                # Power-up rendering: bold glow during and after transformation
                if char.state.value == "power_up":
                    phase = char._powerup_phase
                    if phase == 0:
                        # 3Hz flicker during crouch
                        if int(_render_time_char.monotonic() * 3) % 2:
                            attr |= curses.A_BOLD
                    elif phase == 1:
                        # 6Hz faster flicker during scream
                        if int(_render_time_char.monotonic() * 6) % 2:
                            attr |= curses.A_BOLD
                    else:
                        # Full bright during burst
                        attr |= curses.A_BOLD
                elif char.powered_up:
                    # Persistent bold golden glow while working post-transformation
                    attr |= curses.A_BOLD

                # Find the bounding box of non-space content to fill body area
                for row_i, line in enumerate(sprite_lines):
                    sy = int(char.y) + row_i + y_off
                    # Find leftmost and rightmost non-space in this row
                    left = len(line)
                    right = -1
                    for ci, c in enumerate(line):
                        if c != " ":
                            left = min(left, ci)
                            right = max(right, ci)
                    if right < 0:
                        continue
                    # Fill the entire span (left..right) — spaces become opaque black
                    for col_i in range(left, right + 1):
                        sx = int(char.x) + col_i
                        if 0 < sy < h - 1 and 0 < sx < w - 1:
                            ch = line[col_i]
                            if ch == " ":
                                next_buf[(sy, sx)] = (" ", 0)
                            else:
                                next_buf[(sy, sx)] = (ch, attr)

            elif obj_type == "desk":
                fi = extra
                item = obj
                desk_name = scene._desk_names.get(fi, "")

                # Check if a character is seated at this desk and what they're doing
                seated = False
                seated_state: _CharState | None = None
                for c in scene.characters:
                    if (c.desk_x is not None and c.desk_y is not None
                            and abs(c.x - c.desk_x) < 2 and abs(c.y - c.desk_y) < 2
                            and c.state in (_CharState.TYPING, _CharState.THINKING,
                                            _CharState.READING, _CharState.IDLE,
                                            _CharState.SETTING_UP)):
                        if abs(item.x + 4 - c.desk_x) < 2 and abs(item.y - 2 - c.desk_y) < 2:
                            seated = True
                            seated_state = c.state
                            break

                # Per-desk monitor pixels based on character state
                if seated_state == _CharState.TYPING:
                    mon_pixels = "▪▫" if _blink else "▫▪"   # C: alternating dots
                elif seated_state == _CharState.THINKING:
                    mon_pixels = "_|" if _blink else "|_"    # F: cursor blink
                elif seated_state == _CharState.READING:
                    mon_pixels = "▪▪"                        # on, reading
                elif seated_state in (_CharState.IDLE, _CharState.SETTING_UP):
                    mon_pixels = "▪▪"                        # on but idle
                else:
                    mon_pixels = "▫▫"                        # off / nobody

                # Only opaque-cover body when working at desk
                seated = seated and seated_state in (
                    _CharState.TYPING, _CharState.THINKING, _CharState.READING)

                for row_i, line in enumerate(item.sprite):
                    sy = item.y + row_i + y_off
                    is_last_row = (row_i == len(item.sprite) - 1)

                    line = line.replace("▫▫", mon_pixels)

                    # Inject character name in legs row
                    if is_last_row and desk_name:
                        inner_start = line.find("┐")
                        inner_end = line.rfind("┌")
                        if inner_start >= 0 and inner_end > inner_start:
                            inner_w = inner_end - inner_start - 1
                            padded = desk_name[:inner_w].center(inner_w)
                            line = line[:inner_start + 1] + padded + line[inner_end:]

                    # Pre-compute bounding box for opaque fill
                    left = next((i for i, c in enumerate(line) if c != " "), len(line))
                    right = next((i for i in range(len(line) - 1, -1, -1) if line[i] != " "), -1)

                    # Monitor area (rows 0-2) is always opaque;
                    # table/legs (rows 3+) only opaque when seated
                    is_monitor_row = row_i <= 2

                    for col_i in range(left, right + 1):
                        sx = item.x + col_i
                        if 0 < sy < h - 1 and 0 < sx < w - 1:
                            ch = line[col_i]
                            if ch == " ":
                                if is_monitor_row or seated:
                                    next_buf[(sy, sx)] = (" ", 0)  # opaque
                                # table/legs not seated → transparent
                            elif is_last_row and desk_name and ch.isalpha():
                                next_buf[(sy, sx)] = (ch, curses.A_DIM)
                            else:
                                next_buf[(sy, sx)] = (ch, furn_attr)

                # Q9: Render subtitle row (model/type) one row below desk sprite
                desk_subtitle = scene._desk_subtitles.get(fi, "")
                if desk_subtitle:
                    sub_y = item.y + len(item.sprite) + y_off
                    if 0 < sub_y < h - 1:
                        # Center subtitle within the desk legs inner area
                        # Find the ┐ and ┌ positions from the last sprite row
                        last_line = item.sprite[-1] if item.sprite else ""
                        inner_start = last_line.find("┐")
                        inner_end = last_line.rfind("┌")
                        if inner_start >= 0 and inner_end > inner_start:
                            inner_width = inner_end - inner_start - 1
                            sub_text = desk_subtitle[:inner_width].center(inner_width)
                            for col_i, ch in enumerate(sub_text):
                                sx = item.x + inner_start + 1 + col_i
                                if 0 < sx < w - 1 and ch != " ":
                                    next_buf[(sub_y, sx)] = (ch, curses.A_DIM)

        # Layer 5.2: Power-up effects (⚡ lightning, * ripple, scouter box)
        import math as _math

        pu_attr = curses.color_pair(11) | curses.A_BOLD

        for char_name, pu in scene.powerup_effects.items():
            phase = pu["phase"]
            cx = int(pu["char_x"])
            cy = int(pu["char_y"]) + y_off
            ripple_r = pu["ripple_radius"]
            skill = pu["skill_name"]

            # Phase 0: single ⚡ above head (wide char = 2 columns)
            if phase == 0:
                sy = cy - 1
                sx = cx + 2
                if 0 < sy < h - 1 and 0 < sx < w - 2:
                    next_buf[(sy, sx)] = ("⚡", pu_attr)
                    if sx + 1 < w - 1:
                        next_buf[(sy, sx + 1)] = ("", pu_attr)

            # Phase 1: double ⚡ on both sides
            elif phase == 1:
                sy = cy - 1
                for sx in (cx, cx + 4):
                    if 0 < sy < h - 1 and 0 < sx < w - 2:
                        next_buf[(sy, sx)] = ("⚡", pu_attr)
                        if sx + 1 < w - 1:
                            next_buf[(sy, sx + 1)] = ("", pu_attr)

            # Phase 2: triple ⚡ + expanding * ripple ring + scouter box
            elif phase == 2:
                # Triple ⚡ above head
                sy = cy - 1
                for sx in (cx - 2, cx + 2, cx + 6):
                    if 0 < sy < h - 1 and 0 < sx < w - 2:
                        next_buf[(sy, sx)] = ("⚡", pu_attr)
                        if sx + 1 < w - 1:
                            next_buf[(sy, sx + 1)] = ("", pu_attr)

                # * ripple ring at 12 evenly spaced points
                for i in range(12):
                    angle = i * (_math.pi * 2 / 12)
                    rx = cx + 2 + int(_math.cos(angle) * ripple_r * 1.0)
                    ry = cy + int(_math.sin(angle) * ripple_r * 0.5)
                    if 0 < ry < h - 1 and 0 < rx < w - 1:
                        next_buf[(ry, rx)] = ("*", pu_attr)

                # Scouter box — 4 lines at right of character
                scouter_label = f"/{skill}" if skill else "/skill"
                scouter_lines = [
                    "╔══════════════╗",
                    f"║ {scouter_label[:12]:<12} ║",
                    "║ POWER: 9000+ ║",
                    "╚══════════════╝",
                ]
                box_w_px = 16
                box_h_px = 4
                bx = cx + 7
                by = cy - 3
                # Clamp to scene bounds
                bx = max(1, min(w - box_w_px - 1, bx))
                by = max(1, min(h - box_h_px - 2, by))
                for row_i, sline in enumerate(scouter_lines):
                    sy2 = by + row_i
                    for col_i, sch in enumerate(sline):
                        sx2 = bx + col_i
                        if 0 < sy2 < h - 1 and 0 < sx2 < w - 1:
                            next_buf[(sy2, sx2)] = (sch, pu_attr)

        # Layer 5.4: Smith special effects (punch lines, bullets)
        if scene.smith_effects:
            fx = scene.smith_effects
            fx_type = fx.get("type", "")
            phase = fx.get("phase", 0)
            smith_attr = curses.color_pair(5) | curses.A_BOLD  # bright white

            if fx_type == "smith_fight" and phase == 2:
                # Draw punch effect ━→ between smith and target
                smith_char = next(
                    (c for c in scene.characters if c.name == fx["smith_name"]), None)
                target_char = next(
                    (c for c in scene.characters if c.name == fx["target_name"]), None)
                if smith_char and target_char:
                    sy = int(smith_char.y) + 1 + y_off
                    sx_start = min(int(smith_char.x), int(target_char.x)) + 4
                    sx_end = max(int(smith_char.x), int(target_char.x))
                    for sx in range(sx_start, sx_end):
                        if 0 < sy < h - 1 and 0 < sx < w - 1:
                            next_buf[(sy, sx)] = ("━", smith_attr)
                    if 0 < sy < h - 1 and 0 < sx_end < w - 1:
                        next_buf[(sy, sx_end)] = ("→", smith_attr)

            elif fx_type == "smith_bullet" and phase == 1:
                # Draw bullet · at current position with trail
                bx = int(fx.get("bullet_x", 0))
                by = int(fx.get("bullet_y", 0)) + y_off
                if 0 < by < h - 1 and 0 < bx < w - 1:
                    next_buf[(by, bx)] = ("·", smith_attr)
                # Bullet trail
                for trail in range(1, 3):
                    tx = bx - trail
                    if 0 < by < h - 1 and 0 < tx < w - 1:
                        next_buf[(by, tx)] = ("·", smith_attr | curses.A_DIM)

        # Rain/snow visuals are rendered inside window frames (see Layer 1 above).
        # Particle system removed — it leaked rain/snow into the office interior.

        # (Bubbles rendered after final wall pass — see below)

        # Layer 6: Task box with per-line colors (bottom overlay)
        if not scene.intro_active:
            box_w = _pre_box_w
            task_lines = _pre_task_lines
            if task_lines:
                box_h = _pre_box_h
                box_y = _pre_box_y
                box_x = max(1, (min(w, scene.width) - box_w) // 2)

                border_attr = curses.color_pair(5) | curses.A_BOLD  # white borders
                _border_chars = frozenset("╔╗╚╝═║─")
                for row_i, (line, color_idx) in enumerate(task_lines):
                    sy = box_y + row_i
                    line_attr = curses.color_pair(color_idx) if color_idx else curses.color_pair(5)
                    col = 0
                    for ch in line:
                        sx = box_x + col
                        cw = _char_width(ch)
                        if cw == 0:
                            continue
                        if 0 < sy < h - 1 and 0 <= sx < w - 1:
                            attr = border_attr if ch in _border_chars else line_attr
                            next_buf[(sy, sx)] = (ch, attr)
                            if cw == 2 and sx + 1 < w - 1:
                                next_buf[(sy, sx + 1)] = ("", attr)
                        col += cw
                    # Ensure right border is always drawn at the expected position
                    right_x = box_x + box_w - 1
                    if 0 < sy < h - 1 and 0 <= right_x < w - 1:
                        # Determine correct border char for this row
                        if row_i == 0:
                            right_ch = "╗"
                        elif row_i == box_h - 1:
                            right_ch = "╝"
                        else:
                            right_ch = "║"
                        next_buf[(sy, right_x)] = (right_ch, border_attr)

        # Layer 7: Status bar (bottom line)
        status = scene.get_status_line(w)
        status_y = min(h - 1, scene.height - 1)
        col = 0
        for ch in status:
            if col >= w - 1:
                break
            cw = _char_width(ch)
            if cw == 0:
                continue
            next_buf[(status_y, col)] = (ch, curses.color_pair(7))
            if cw == 2 and col + 1 < w - 1:
                next_buf[(status_y, col + 1)] = ("", curses.color_pair(7))
            col += cw

        # Layer 8: Upgrade overlay (banner box + furniture labels)
        if scene.upgrade_overlay:
            overlay_lines = scene.upgrade_overlay
            oy = scene.upgrade_overlay_y + y_off
            # Center horizontally
            max_line_w = max(len(l) for l in overlay_lines) if overlay_lines else 0
            ox = max(1, (min(w, scene.width) - max_line_w) // 2)
            banner_attr = curses.color_pair(5) | curses.A_BOLD  # bright white bold

            for row_i, line in enumerate(overlay_lines):
                sy = oy + row_i
                col = 0
                for ch in line:
                    cw = _char_width(ch)
                    if cw == 0:
                        continue
                    sx = ox + col
                    if 0 < sy < h - 1 and 0 <= sx < w - 1:
                        # Black background fill for the entire box
                        next_buf[(sy, sx)] = (ch, banner_attr)
                        if cw == 2 and sx + 1 < w - 1:
                            next_buf[(sy, sx + 1)] = ("", banner_attr)
                    col += cw

        # Layer 8b: Furniture pop-in labels
        for lx, ly, label_text in scene.upgrade_labels:
            label_attr = curses.color_pair(9) | curses.A_BOLD  # bright green bold
            ly_off = ly + y_off
            col = 0
            for ch in label_text:
                cw = _char_width(ch)
                if cw == 0:
                    continue
                sx = lx + col
                if 0 < ly_off < h - 1 and 0 <= sx < w - 1:
                    next_buf[(ly_off, sx)] = (ch, label_attr)
                    if cw == 2 and sx + 1 < w - 1:
                        next_buf[(ly_off, sx + 1)] = ("", label_attr)
                col += cw

        # Final wall pass — redraw walls over furniture to prevent occlusion
        if not scene.intro_active and not scene.outro_active:
            # Top wall + corners
            for x in range(wall_right + 1):
                next_buf[(y_off, x)] = ("═", wall_attr)
            next_buf[(y_off, 0)] = ("╔", wall_attr)
            if wall_right > 0:
                next_buf[(y_off, wall_right)] = ("╗", wall_attr)
            # Left wall
            for y in range(y_off + 1, wall_bottom_y + 1):
                next_buf[(y, 0)] = ("║", wall_attr)
            # Right wall
            if wall_right > 0:
                for y in range(y_off + 1, wall_bottom_y + 1):
                    next_buf[(y, wall_right)] = ("║", wall_attr)

        # Bubbles — rendered AFTER final wall pass so they appear on top of walls
        for char in scene.characters:
            if char.bubble_ttl > 0 and char.bubble_text:
                from .bubbles import display_width, make_speech_bubble, make_thought_bubble

                max_bw = min(24, (w - 2) // 3)
                if char.bubble_type == "thought":
                    blines = make_thought_bubble(char.bubble_text, max_bw)
                else:
                    blines = make_speech_bubble(char.bubble_text, max_bw)

                bubble_h = len(blines)
                max_line_dw = max(display_width(l) for l in blines)
                bx = int(char.x) - 1
                by = int(char.y) + y_off - bubble_h
                bx = max(1, min(w - max_line_dw - 1, bx))
                by = max(1, by)

                battr = curses.color_pair(char.color_index)
                for row_i, line in enumerate(blines):
                    left_col = -1
                    right_col = -1
                    dcol = 0
                    for c in line:
                        cw2 = _char_width(c)
                        if cw2 == 0:
                            continue
                        if c != " ":
                            if left_col < 0:
                                left_col = dcol
                            right_col = dcol + cw2 - 1
                        dcol += cw2

                    col = 0
                    for ch in line:
                        cw = _char_width(ch)
                        if cw == 0:
                            continue
                        sx = bx + col
                        sy = by + row_i
                        if 0 < sy < h - 1 and 0 < sx < w - 2:
                            if left_col <= col <= right_col:
                                if ch == " ":
                                    next_buf[(sy, sx)] = (" ", 0)
                                else:
                                    next_buf[(sy, sx)] = (ch, battr)
                                    if cw == 2:
                                        next_buf[(sy, sx + 1)] = ("", battr)
                        col += cw

        # Lighting mask (intro/outro light effect) — uses squared distance
        if scene.light_radius is not None:
            lcx, lcy = scene.light_center
            r_sq = scene.light_radius * scene.light_radius
            r_inner_sq = r_sq * 0.49  # 0.7^2
            dimmed_buf: dict[tuple[int, int], tuple[str, int]] = {}
            for (y, x), (ch, attr) in next_buf.items():
                dist_sq = (x - lcx) ** 2 + ((y - lcy) * 2) ** 2
                if dist_sq > r_sq:
                    if ch == "" or ch == " ":
                        dimmed_buf[(y, x)] = (ch, attr)
                    else:
                        dimmed_buf[(y, x)] = (ch, curses.A_DIM)
                elif dist_sq > r_inner_sq:
                    dimmed_buf[(y, x)] = (ch, (attr & ~curses.A_BOLD) | curses.A_DIM)
                else:
                    dimmed_buf[(y, x)] = (ch, attr)
            next_buf = dimmed_buf

        # Upgrade flash effect — invert all visible cells
        if scene.upgrade_flash:
            flash_buf: dict[tuple[int, int], tuple[str, int]] = {}
            for (y, x), (ch, attr) in next_buf.items():
                flash_buf[(y, x)] = (ch, curses.A_REVERSE | curses.A_BOLD)
            next_buf = flash_buf

        # Diff and draw — only touch cells that actually changed
        dirty = 0
        for (y, x), (ch, attr) in next_buf.items():
            if y >= h or x >= w:
                continue
            if ch == "":
                # Placeholder for second column of wide char — skip drawing
                continue
            prev = self.prev.get((y, x))
            if prev != (ch, attr):
                dirty += 1
                try:
                    self.stdscr.addstr(y, x, ch, attr)
                except curses.error:
                    pass  # edge of screen

        # Clear cells that are no longer drawn
        for (y, x) in self.prev:
            if (y, x) not in next_buf and 0 <= y < h and 0 <= x < w:
                dirty += 1
                try:
                    self.stdscr.addstr(y, x, " ")
                except curses.error:
                    pass

        self.prev = next_buf

        # Consume pending bell (Pomodoro transitions)
        if scene._bell_pending:
            curses.beep()
            scene._bell_pending = False

        # Only flush to terminal if something actually changed.
        # This prevents WezTerm from recalculating IME anchor position
        # on frames where the scene is visually identical.
        if dirty > 0:
            self._idle_frames = 0
            self.stdscr.noutrefresh()
            curses.doupdate()
        else:
            self._idle_frames += 1
