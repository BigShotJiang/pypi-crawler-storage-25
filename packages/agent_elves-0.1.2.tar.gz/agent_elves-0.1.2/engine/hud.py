"""HUD, status line, and banner overlays — extracted from scene.py."""
from __future__ import annotations

import random
import threading
import time
from typing import TYPE_CHECKING

from .bubbles import display_width, _pad_to_width, get_language, t
from .characters import State

if TYPE_CHECKING:
    from .scene import Scene


def get_hud_lines(scene: Scene, max_w: int) -> list[str]:
    """Build HUD bar lines. Returns 1 line if fits, 2 if not."""
    from .atmosphere import get_atmosphere
    from .levels import LEVEL_BY_KEY, LEVEL_DEFS

    now = time.localtime()
    atmo = get_atmosphere()

    current_time = f"🕐{time.strftime('%H:%M', now)}"
    pomo = scene._pomodoro.format_display()
    pomo_count = f"×{scene._pomodoro.completed_pomodoros}" if scene._pomodoro.completed_pomodoros else ""

    weather_str = ""
    city_str = ""
    if scene._weather:
        weather_str = f"{atmo.status_icon}{scene._weather.temperature:.0f}°C"
        city_str = f"🏠{scene._weather.city}" if scene._weather.city else ""

    elapsed = time.time() - scene._session_start_wall
    eh = int(elapsed) // 3600
    em = (int(elapsed) % 3600) // 60
    elapsed_str = f"⏱️{eh}h{em:02d}m" if eh > 0 else f"⏱️{em}m"

    date_str = f"📅{time.strftime('%a %b %d', now)}"
    start_str = f"▶️{time.strftime('%H:%M', time.localtime(scene._session_start_wall))}"

    tasks_per_hr = 0.0
    if elapsed > 60:
        tasks_per_hr = scene.completed_count / (elapsed / 3600)
    tph_str = f"⚡{tasks_per_hr:.1f}/h"

    level_def = LEVEL_BY_KEY.get(scene.office_level, LEVEL_DEFS[0])
    lv_str = f"🌟Lv.{level_def.index + 1}"

    all_parts = [current_time, date_str, f"{city_str} {weather_str}".strip(),
                 f"{start_str} {elapsed_str}", f"{pomo} {pomo_count}".strip(),
                 f"{tph_str} {lv_str}"]
    full = " " + " | ".join(p for p in all_parts if p)

    if display_width(full) <= max_w:
        return [_pad_to_width(full, max_w)[:max_w],
                " " * max_w]

    row1_parts = [current_time, pomo, weather_str, elapsed_str]
    row2_parts = [date_str, city_str, start_str, tph_str, lv_str, pomo_count]

    row1 = " " + " | ".join(p for p in row1_parts if p)
    row2 = " " + " | ".join(p for p in row2_parts if p)

    return [_pad_to_width(row1, max_w)[:max_w],
            _pad_to_width(row2, max_w)[:max_w]]


def get_status_line(scene: Scene, max_w: int) -> str:
    """Build the status bar string."""
    if scene.intro_active:
        line = f" Agent Elves | {t('opening')}"
        return line.ljust(max_w)[:max_w]

    if scene.outro_active:
        line = f" Agent Elves | {t('closed')}"
        return line.ljust(max_w)[:max_w]

    from .atmosphere import get_atmosphere
    atmo = get_atmosphere()

    agents = len(scene.characters)
    busy = sum(1 for c in scene.characters if c.busy)
    temp_str = ""
    if scene._weather:
        temp_str = f" {scene._weather.temperature:.0f}\u00b0C"
    line = (
        f" {atmo.status_icon}{temp_str} Agent Elves | {t('status_agents')}: {agents} |"
        f" {t('status_working')}: {busy} |"
        f" {t('status_tasks')}: {scene.completed_count} \u2713"
    )
    return line.ljust(max_w)[:max_w]


def show_pomodoro_banner(scene: Scene, event: str) -> None:
    """Show a big banner for Pomodoro transitions, reusing upgrade_overlay."""
    w = scene.width
    count = scene._pomodoro.completed_pomodoros

    if event == "start":
        title = "◉  FOCUS TIME  ◉"
        subtitle = "25:00 — Let's go!"
    elif event == "break":
        title = "☕  BREAK TIME  ☕"
        subtitle = f"5:00 — Pomodoro ×{count} done!"
    elif event == "work":
        title = "◉  BACK TO WORK  ◉"
        subtitle = f"25:00 — Pomodoro ×{count}"
    else:
        return

    content_w = max(display_width(title), display_width(subtitle))
    box_w = min(w - 6, content_w + 8)
    inner = box_w - 4

    def _center(text: str) -> str:
        dw = display_width(text)
        pad = max(0, inner - dw)
        return " " * (pad // 2) + text + " " * (pad - pad // 2)

    lines = []
    lines.append("╔" + "═" * (box_w - 2) + "╗")
    lines.append("║ " + " " * inner + " ║")
    lines.append("║ " + _center(title) + " ║")
    lines.append("║ " + " " * inner + " ║")
    lines.append("║ " + _center(subtitle) + " ║")
    lines.append("║ " + " " * inner + " ║")
    lines.append("╚" + "═" * (box_w - 2) + "╝")

    scene.upgrade_overlay = lines
    scene.upgrade_overlay_y = max(1, (scene.height - len(lines)) // 2)
    scene.upgrade_flash = True
    scene._pomo_banner_timer = 3.0
    scene._bell_pending = True

    def _clear_flash():
        time.sleep(0.5)
        scene.upgrade_flash = False
    threading.Thread(target=_clear_flash, daemon=True).start()


def show_achievement_banner(scene: Scene, achievement) -> None:
    """Show achievement unlock banner."""
    lang = get_language()
    title = "🏆 ACHIEVEMENT UNLOCKED 🏆"
    name_line = f"{achievement.icon}  {achievement.name.get(lang, achievement.name['en'])}"
    desc_line = achievement.desc.get(lang, achievement.desc['en'])

    content_w = max(display_width(title), display_width(name_line), display_width(desc_line))
    box_w = min(scene.width - 6, content_w + 8)
    inner = box_w - 4

    def _center(text: str) -> str:
        dw = display_width(text)
        pad = max(0, inner - dw)
        return " " * (pad // 2) + text + " " * (pad - pad // 2)

    lines = []
    lines.append("╔" + "═" * (box_w - 2) + "╗")
    lines.append("║ " + " " * inner + " ║")
    lines.append("║ " + _center(title) + " ║")
    lines.append("║ " + " " * inner + " ║")
    lines.append("║ " + _center(name_line) + " ║")
    lines.append("║ " + _center(desc_line) + " ║")
    lines.append("║ " + " " * inner + " ║")
    lines.append("╚" + "═" * (box_w - 2) + "╝")

    scene.upgrade_overlay = lines
    scene.upgrade_overlay_y = max(1, (scene.height - len(lines)) // 2)
    scene.upgrade_flash = True
    scene._pomo_banner_timer = 3.0

    def _clear_flash():
        time.sleep(0.5)
        scene.upgrade_flash = False
    threading.Thread(target=_clear_flash, daemon=True).start()


def start_pomodoro_break(scene: Scene) -> None:
    """All regular elves celebrate and walk to leisure areas."""
    leisure_spots = []
    for item in scene.furniture:
        if item.name in ("sofa", "arcade", "bar", "coffee", "bike"):
            leisure_spots.append((float(item.x + 2), float(item.y)))

    for c in scene.characters:
        if not c.is_agent and not c.busy:
            c.state = State.CELEBRATING
            c.state_timer = 0.0
            c.bubble_text = "Break time!"
            c.bubble_type = "speech"
            c.bubble_ttl = 3.0
            if leisure_spots:
                spot = random.choice(leisure_spots)
                c.target_x = spot[0]
                c.target_y = spot[1]
                c.target_callback = "furniture"


def end_pomodoro_break(scene: Scene) -> None:
    """All regular elves return to desks."""
    for c in scene.characters:
        if not c.is_agent and not c.busy:
            c.bubble_text = "Back to work!"
            c.bubble_type = "speech"
            c.bubble_ttl = 2.0
            c._return_to_desk()
