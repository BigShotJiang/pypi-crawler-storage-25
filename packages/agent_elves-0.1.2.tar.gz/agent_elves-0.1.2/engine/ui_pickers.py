"""UI pickers, wizard screens, and branding constants for Agent Elves.

Extracted from engine/main.py — contains all curses-based interactive
picker screens and helper drawing functions used by the setup wizard
and the main animation loop.
"""
from __future__ import annotations

import curses
import json
import os
import time
from typing import TYPE_CHECKING

from engine.config import (
    CONFIG_PATH,
    VALID_THEMES,
    VALID_LANGS,
    VALID_OFFICES,
    OFFICE_SESSION_THRESHOLDS,
    OFFICE_UNLOCK_THRESHOLDS,
    VERSION,
)
from engine.renderer import init_colors
from engine.sprites import THEMES

if TYPE_CHECKING:
    from engine.scene import Scene


# ── Branding ───────────────────────────────────────────────────────

LOGO = [
    r"     _                    _     _____ _                ",
    r"    / \   __ _  ___ _ __ | |_  | ____| |_   _____  ___ ",
    r"   / _ \ / _` |/ _ \ '_ \| __| |  _| | \ \ / / _ \/ __|",
    r"  / ___ \ (_| |  __/ | | | |_  | |___| |\ V /  __/\__ \\",
    r" /_/   \_\__, |\___|_| |_|\__| |_____|_| \_/ \___||___/",
    r"         |___/                                          ",
]

COPYRIGHT = "Copyright (c) 2025 Nickdevlab"


# ── UI helpers ─────────────────────────────────────────────────────

def _safe_addstr(stdscr, y: int, x: int, text: str, attr: int = 0):
    """Write string to screen, silently ignore out-of-bounds."""
    h, w = stdscr.getmaxyx()
    if 0 <= y < h and 0 <= x < w:
        try:
            stdscr.addnstr(y, x, text, w - x - 1, attr)
        except curses.error:
            pass


def _show_dashboard(stdscr, scene: 'Scene') -> None:
    """Show statistics overlay. Blocks until any key is pressed."""
    import time as _time
    from engine.atmosphere import get_atmosphere

    curses.curs_set(0)
    stdscr.nodelay(False)
    stdscr.erase()
    h, w = stdscr.getmaxyx()
    atmo = get_atmosphere()

    elapsed = _time.monotonic() - scene._start_time
    mins = int(elapsed // 60)
    secs = int(elapsed % 60)

    title_attr = curses.color_pair(1) | curses.A_BOLD
    label_attr = curses.color_pair(8)
    value_attr = curses.color_pair(6) | curses.A_BOLD
    bar_attr = curses.color_pair(3)

    cy = 2
    _safe_addstr(stdscr, cy, 3, "╔════════════════════════════════════════╗", title_attr)
    cy += 1
    _safe_addstr(stdscr, cy, 3, "║       Agent Elves  Dashboard          ║", title_attr)
    cy += 1
    _safe_addstr(stdscr, cy, 3, "╚════════════════════════════════════════╝", title_attr)
    cy += 2

    # Session info
    _safe_addstr(stdscr, cy, 5, f"{atmo.status_icon} Time of day:", label_attr)
    _safe_addstr(stdscr, cy, 25, atmo.status_label, value_attr)
    cy += 1
    _safe_addstr(stdscr, cy, 5, "Session:", label_attr)
    _safe_addstr(stdscr, cy, 25, f"{mins}m {secs}s", value_attr)
    cy += 1
    _safe_addstr(stdscr, cy, 5, "Total tasks:", label_attr)
    _safe_addstr(stdscr, cy, 25, str(scene.task_count), value_attr)
    cy += 1
    _safe_addstr(stdscr, cy, 5, "Completed:", label_attr)
    _safe_addstr(stdscr, cy, 25, f"{scene.completed_count} ✓", value_attr)
    cy += 1
    _safe_addstr(stdscr, cy, 5, "Active elves:", label_attr)
    _safe_addstr(stdscr, cy, 25, str(len(scene.characters)), value_attr)
    cy += 1

    # Office level
    try:
        from engine.levels import LEVEL_BY_KEY, LEVEL_DEFS
        level_def = LEVEL_BY_KEY.get(scene.office_level, LEVEL_DEFS[0])
        _safe_addstr(stdscr, cy, 5, "Office level:", label_attr)
        from engine.bubbles import t as _t_i18n
        _safe_addstr(stdscr, cy, 25, f"Lv.{level_def.index + 1} {_t_i18n(level_def.name_i18n)}", value_attr)
        cy += 1
    except Exception:
        pass

    # Tasks per hour
    import time as _t2
    elapsed_wall = _t2.time() - scene._session_start_wall
    tph = scene.completed_count / (elapsed_wall / 3600) if elapsed_wall > 60 else 0
    _safe_addstr(stdscr, cy, 5, "Tasks/hour:", label_attr)
    _safe_addstr(stdscr, cy, 25, f"⚡{tph:.1f}", value_attr)
    cy += 2

    # Per-elf stats
    _safe_addstr(stdscr, cy, 5, "── Elf Leaderboard ──", title_attr)
    cy += 1

    # Sort by task count descending
    sorted_elves = sorted(
        scene._char_task_counts.items(),
        key=lambda kv: kv[1],
        reverse=True,
    )
    max_tasks = max((v for _, v in sorted_elves), default=1)

    for rank, (name, count) in enumerate(sorted_elves[:6], 1):
        bar_len = int((count / max_tasks) * 20) if max_tasks > 0 else 0
        bar = "█" * bar_len + "░" * (20 - bar_len)

        # Find character's role
        role = ""
        for c in scene.characters:
            if c.name == name:
                role = c.role
                break

        _safe_addstr(stdscr, cy, 5, f"#{rank}", label_attr)
        _safe_addstr(stdscr, cy, 8, f"{name:12s}", curses.color_pair(rank if rank <= 6 else 6) | curses.A_BOLD)
        _safe_addstr(stdscr, cy, 21, f"({role:10s})", curses.A_DIM)
        _safe_addstr(stdscr, cy, 33, bar, bar_attr)
        _safe_addstr(stdscr, cy, 54, f" {count}", value_attr)
        cy += 1

    if not sorted_elves:
        _safe_addstr(stdscr, cy, 5, "(no tasks yet)", curses.A_DIM)
        cy += 1

    cy += 1

    # Pomodoro stats section
    _safe_addstr(stdscr, cy, 5, "── Pomodoro ──", title_attr)
    cy += 1
    from engine.pomodoro import PomodoroPhase
    pomo = scene._pomodoro
    phase_str = "🍅 WORK" if pomo.phase == PomodoroPhase.WORK else ("☕ BREAK" if pomo.phase == PomodoroPhase.BREAK else "⏸ OFF")
    _safe_addstr(stdscr, cy, 5, "Status:", label_attr)
    _safe_addstr(stdscr, cy, 25, phase_str, value_attr)
    cy += 1
    _safe_addstr(stdscr, cy, 5, "Completed:", label_attr)
    _safe_addstr(stdscr, cy, 25, f"🍅 ×{pomo.completed_pomodoros}", value_attr)
    cy += 2

    # Achievements section
    try:
        from engine.achievements import ACHIEVEMENTS, AchievementTracker
        tracker = scene._achievements
        _safe_addstr(stdscr, cy, 5, "── Achievements ──", title_attr)
        cy += 1
        _safe_addstr(stdscr, cy, 5, f"Unlocked: {tracker.unlocked_count}/{tracker.total_count}", label_attr)
        cy += 1

        from engine.bubbles import get_language
        lang = get_language()
        for ach in ACHIEVEMENTS:
            if cy >= h - 3:
                break
            unlocked = ach.id in tracker.unlocked
            icon = ach.icon if unlocked else "🔒"
            name = ach.name.get(lang, ach.name["en"])
            attr = value_attr if unlocked else curses.A_DIM
            _safe_addstr(stdscr, cy, 5, f"{icon} {name}", attr)
            cy += 1
        cy += 1
    except Exception:
        pass

    hint = "Press any key to return..."
    _safe_addstr(stdscr, cy, _center_x(stdscr, hint), hint, curses.A_DIM)

    stdscr.refresh()
    stdscr.getch()  # wait for any key


def _draw_box(stdscr, y: int, x: int, box_w: int, box_h: int, attr: int):
    """Draw a bordered box."""
    _safe_addstr(stdscr, y, x, "╔" + "═" * (box_w - 2) + "╗", attr)
    for row in range(1, box_h - 1):
        _safe_addstr(stdscr, y + row, x, "║", attr)
        _safe_addstr(stdscr, y + row, x + box_w - 1, "║", attr)
    _safe_addstr(stdscr, y + box_h - 1, x, "╚" + "═" * (box_w - 2) + "╝", attr)


def _center_x(stdscr, text: str) -> int:
    """Return x position to center text."""
    _, w = stdscr.getmaxyx()
    return max(0, (w - len(text)) // 2)


def _draw_header(stdscr, start_y: int) -> int:
    """Draw logo + copyright header. Returns next y position."""
    h, w = stdscr.getmaxyx()
    title_attr = curses.color_pair(1) | curses.A_BOLD  # amber

    # Logo (skip if pane too narrow)
    cy = start_y
    if w >= 56:
        for line in LOGO:
            _safe_addstr(stdscr, cy, _center_x(stdscr, line), line, title_attr)
            cy += 1
        cy += 1
    else:
        title = "~ Agent Elves ~"
        _safe_addstr(stdscr, cy, _center_x(stdscr, title), title, title_attr)
        cy += 2

    # Version + copyright
    ver_line = f"v{VERSION}"
    _safe_addstr(stdscr, cy, _center_x(stdscr, ver_line), ver_line,
                 curses.color_pair(6) | curses.A_DIM)
    cy += 1
    _safe_addstr(stdscr, cy, _center_x(stdscr, COPYRIGHT), COPYRIGHT,
                 curses.color_pair(6) | curses.A_DIM)
    cy += 1

    # Separator
    sep = "─" * min(40, w - 4)
    _safe_addstr(stdscr, cy, _center_x(stdscr, sep), sep,
                 curses.color_pair(8) | curses.A_DIM)
    cy += 2

    return cy


# ── Theme picker ───────────────────────────────────────────────────

def _theme_picker(stdscr, timeout_secs: int = 15) -> str:
    """Show theme selection with live character previews."""
    curses.curs_set(0)
    stdscr.nodelay(True)
    start = time.monotonic()

    theme_info = [
        ("1", "claude", "Claude 圓潤風", curses.COLOR_YELLOW),
        ("2", "kaomoji", "Kaomoji 顏文字風", curses.COLOR_CYAN),
        ("3", "pixel", "Pixel RPG 像素風", curses.COLOR_GREEN),
        ("4", "samurai", "侍 Samurai 和風", curses.COLOR_RED),
        ("5", "space", "Space 太空風", curses.COLOR_MAGENTA),
    ]
    # Add custom theme if loaded
    if "custom" in THEMES:
        custom_label = THEMES["custom"].get("label", "Custom Theme")
        theme_info.append(("6", "custom", custom_label, curses.COLOR_WHITE))

    selected = 0  # highlighted option
    anim_frame = 0

    while True:
        remaining = max(0, timeout_secs - (time.monotonic() - start))
        if remaining <= 0:
            return theme_info[selected][1]

        h, w = stdscr.getmaxyx()
        stdscr.erase()

        # Header
        cy = _draw_header(stdscr, 1)

        # Section title
        section = "[ SELECT STYLE ]"
        _safe_addstr(stdscr, cy, _center_x(stdscr, section), section,
                     curses.color_pair(7))
        cy += 2

        # Options with sprite preview
        for idx, (key, name, label, color) in enumerate(theme_info):
            theme_data = THEMES[name]
            sprites = theme_data["sprites"]
            idle_frames = sprites.get(("idle", "right"), [[]])

            # Highlight selected
            is_sel = idx == selected
            marker = " >" if is_sel else "  "
            label_attr = curses.color_pair(idx + 1) | curses.A_BOLD
            dim_attr = curses.color_pair(idx + 1)

            # Key + label
            option_x = max(2, (w - 50) // 2)
            line = f"{marker} [{key}] {label}"
            _safe_addstr(stdscr, cy, option_x, line,
                         label_attr if is_sel else dim_attr)

            # Sprite preview (animated)
            frame = idle_frames[anim_frame % len(idle_frames)]
            sprite_x = option_x + 38
            for si, sl in enumerate(frame):
                _safe_addstr(stdscr, cy + si, sprite_x, sl,
                             curses.color_pair(idx + 1))

            # Character names
            names = ", ".join(theme_data["names"][:3]) + "..."
            _safe_addstr(stdscr, cy + len(frame), option_x + 6, names,
                         curses.A_DIM)

            cy += max(len(frame), 2) + 2

        # Editor entry
        edit_hint = "[E] Edit Custom Theme"
        _safe_addstr(stdscr, cy, _center_x(stdscr, edit_hint), edit_hint,
                     curses.color_pair(12) | curses.A_DIM)
        cy += 1

        # Footer
        hint = f"[1-6] select  |  [q] default  |  auto in {int(remaining)}s"
        _safe_addstr(stdscr, cy, _center_x(stdscr, hint), hint, curses.A_DIM)

        # Help
        help_text = "[s] settings anytime during animation"
        _safe_addstr(stdscr, cy + 1, _center_x(stdscr, help_text), help_text,
                     curses.A_DIM)

        stdscr.refresh()
        time.sleep(0.3)
        anim_frame += 1

        ch = stdscr.getch()
        if ch == ord("e") or ch == ord("E"):
            result = _theme_editor(stdscr)
            # Restore nodelay after editor
            stdscr.nodelay(True)
            start = time.monotonic()
            if result:
                return result
            continue
        for i, (key, name, _label, _color) in enumerate(theme_info):
            if ch == ord(key):
                return name
        if ch == curses.KEY_DOWN:
            selected = (selected + 1) % len(theme_info)
            start = time.monotonic()  # reset timeout on interaction
        elif ch == curses.KEY_UP:
            selected = (selected - 1) % len(theme_info)
            start = time.monotonic()
        elif ch == 10 or ch == curses.KEY_ENTER:  # Enter
            return theme_info[selected][1]
        elif ch == ord("q") or ch == 27:
            return "claude"


# ── Theme editor ───────────────────────────────────────────────────

def _theme_editor(stdscr) -> str:
    """Interactive ASCII art custom theme editor.

    Returns "custom" if saved, "" if cancelled.
    """
    from engine.sprites import THEMES, CUSTOM_THEME_PATH, load_custom_theme

    SPRITE_WIDTH = 10
    SPRITE_HEIGHT = 4

    # State keys shown in the editor (JSON key → display label)
    STATE_KEYS = [
        ("idle",          "idle"),
        ("typing",        "typing"),
        ("thinking",      "thinking"),
        ("walking_right", "walking_right"),
        ("walking_left",  "walking_left"),
        ("celebrating",   "celebrating"),
        ("coffee",        "coffee"),
    ]

    # Internal key mapping used by load_custom_theme
    _internal_key = {
        "idle":          ("idle", "right"),
        "typing":        ("typing", "right"),
        "thinking":      ("thinking", "right"),
        "walking_right": ("walking", "right"),
        "walking_left":  ("walking", "left"),
        "celebrating":   ("celebrating", "right"),
        "coffee":        ("coffee", "right"),
    }

    def _blank_frame() -> list[str]:
        return [" " * SPRITE_WIDTH for _ in range(SPRITE_HEIGHT)]

    def _pad_frame(frame: list[str]) -> list[str]:
        """Ensure frame has exactly SPRITE_HEIGHT rows, each SPRITE_WIDTH chars."""
        result = []
        for i in range(SPRITE_HEIGHT):
            row = frame[i] if i < len(frame) else ""
            # Pad or trim to exactly SPRITE_WIDTH
            row = (row + " " * SPRITE_WIDTH)[:SPRITE_WIDTH]
            result.append(row)
        return result

    # ── Load existing custom theme or start from blank ──────────────
    label = "My Custom Theme"
    names = ["Elf-1", "Elf-2", "Elf-3", "Elf-4", "Elf-5"]

    # sprites: json_key → list[list[str]]  (frames × rows)
    sprites: dict[str, list[list[str]]] = {}
    for jk, _ in STATE_KEYS:
        sprites[jk] = [_blank_frame(), _blank_frame()]  # 2 frames default

    # Try to populate from existing custom theme
    import os
    import json as _json

    if os.path.isfile(CUSTOM_THEME_PATH):
        try:
            with open(CUSTOM_THEME_PATH) as _f:
                _data = _json.load(_f)
            label = str(_data.get("label", label))
            _names = _data.get("names", names)
            if isinstance(_names, list):
                names = [str(n) for n in (_names + names)[:5]]
            _raw = _data.get("sprites", {})
            for jk, _ in STATE_KEYS:
                if jk in _raw and isinstance(_raw[jk], list) and _raw[jk]:
                    sprites[jk] = [_pad_frame(f) for f in _raw[jk]
                                   if isinstance(f, list)]
                    # Ensure at least 1 frame
                    if not sprites[jk]:
                        sprites[jk] = [_blank_frame()]
        except (OSError, _json.JSONDecodeError, ValueError):
            pass
    else:
        # Start from THEME_CLAUDE as template
        src = THEMES.get("claude", {})
        for jk, _ in STATE_KEYS:
            ik = _internal_key[jk]
            src_frames = src.get("sprites", {}).get(ik, [])
            if src_frames:
                sprites[jk] = [_pad_frame(f) for f in src_frames]

    # ── Editor state ────────────────────────────────────────────────
    state_idx = 0           # current STATE_KEYS index
    frame_idx = 0           # current frame within state
    cur_row = 0             # cursor row within sprite
    cur_col = 0             # cursor col within sprite

    ui_attr = curses.color_pair(12) | curses.A_BOLD
    dim_attr = curses.A_DIM
    rev_attr = curses.A_REVERSE

    curses.curs_set(0)
    stdscr.nodelay(True)

    anim_tick = 0
    preview_frame = 0
    last_anim = time.monotonic()

    while True:
        h, w = stdscr.getmaxyx()
        stdscr.erase()

        jk, state_label = STATE_KEYS[state_idx]
        cur_frames = sprites[jk]
        # Clamp frame_idx
        frame_idx = frame_idx % max(1, len(cur_frames))
        cur_frame = cur_frames[frame_idx]

        # ── Header ──────────────────────────────────────────────────
        box_title = "  CUSTOM THEME EDITOR  "
        box_w = max(50, len(box_title) + 4)
        box_x = max(0, (w - box_w) // 2)
        _draw_box(stdscr, 0, box_x, box_w, 3, ui_attr)
        _safe_addstr(stdscr, 1, box_x + (box_w - len(box_title)) // 2,
                     box_title, ui_attr)

        cy = 4

        # ── Theme label ──────────────────────────────────────────────
        label_line = f"  Theme name: {label}"
        _safe_addstr(stdscr, cy, box_x, label_line, curses.color_pair(6))
        cy += 2

        # ── State header ─────────────────────────────────────────────
        n_frames = len(cur_frames)
        state_hdr = f"  -- Edit Sprite: {state_label}  ({frame_idx + 1}/{n_frames}) --"
        _safe_addstr(stdscr, cy, box_x, state_hdr, ui_attr)
        cy += 2

        # ── Sprite grid (editable) ───────────────────────────────────
        grid_x = box_x + 5
        for r in range(SPRITE_HEIGHT):
            row_str = cur_frame[r] if r < len(cur_frame) else " " * SPRITE_WIDTH
            for c in range(SPRITE_WIDTH):
                ch_val = row_str[c] if c < len(row_str) else " "
                cell_attr = rev_attr if (r == cur_row and c == cur_col) else curses.A_NORMAL
                _safe_addstr(stdscr, cy + r, grid_x + c, ch_val, cell_attr)
        cy += SPRITE_HEIGHT + 1

        # ── Live preview (animating) on the right side ───────────────
        now = time.monotonic()
        if now - last_anim >= 0.33:
            preview_frame = (preview_frame + 1) % max(1, len(cur_frames))
            last_anim = now

        preview_x = grid_x + SPRITE_WIDTH + 6
        if preview_x + SPRITE_WIDTH < w:
            _safe_addstr(stdscr, cy - SPRITE_HEIGHT - 2, preview_x,
                         "preview:", dim_attr)
            preview = cur_frames[preview_frame]
            for r in range(SPRITE_HEIGHT):
                row_str = preview[r] if r < len(preview) else " " * SPRITE_WIDTH
                _safe_addstr(stdscr, cy - SPRITE_HEIGHT - 1 + r,
                             preview_x, row_str, curses.color_pair(6))

        # ── All state thumbnails ──────────────────────────────────────
        thumb_y = cy + 1
        thumb_x = box_x
        _safe_addstr(stdscr, thumb_y, thumb_x, "States:", dim_attr)
        thumb_y += 1

        tx = thumb_x
        for si, (sjk, slabel) in enumerate(STATE_KEYS):
            s_frames = sprites[sjk]
            is_active = si == state_idx
            thumb_attr = ui_attr if is_active else dim_attr
            _safe_addstr(stdscr, thumb_y, tx, slabel[:8], thumb_attr)
            # Show first row of first frame
            first_row = s_frames[0][0] if s_frames and s_frames[0] else " " * SPRITE_WIDTH
            _safe_addstr(stdscr, thumb_y + 1, tx, first_row[:8], thumb_attr)
            tx += 10
            if tx + 10 >= w:
                break

        cy = thumb_y + 3

        # ── Controls footer ──────────────────────────────────────────
        controls = [
            "[←→] state  [↑↓] cursor row  [Tab] next frame  [+/-] add/del frame",
            "[type] edit char  [Backspace] clear  [n] names  [l] label  [t] template",
            "[Enter] save & apply  [Esc] cancel",
        ]
        for i, ctrl in enumerate(controls):
            _safe_addstr(stdscr, cy + i, box_x, ctrl, dim_attr)

        stdscr.refresh()

        # ── Input handling ───────────────────────────────────────────
        time.sleep(0.05)
        ch = stdscr.getch()

        if ch == -1:
            continue

        elif ch == 27:  # Esc — cancel
            stdscr.nodelay(False)
            return ""

        elif ch == 10 or ch == curses.KEY_ENTER:  # Enter — save
            # Build JSON payload
            out_sprites: dict[str, list[list[str]]] = {}
            for jk2, _ in STATE_KEYS:
                out_sprites[jk2] = sprites[jk2]

            payload = {
                "name": "custom",
                "label": label,
                "names": names,
                "sprites": out_sprites,
            }
            config_dir = os.path.dirname(CUSTOM_THEME_PATH)
            os.makedirs(config_dir, exist_ok=True)
            try:
                import tempfile as _tempfile
                fd, tmp = _tempfile.mkstemp(dir=config_dir)
                with os.fdopen(fd, "w") as _f:
                    _json.dump(payload, _f, indent=2)
                os.replace(tmp, CUSTOM_THEME_PATH)
                load_custom_theme()
            except OSError:
                pass
            stdscr.nodelay(False)
            return "custom"

        elif ch == curses.KEY_LEFT:
            state_idx = (state_idx - 1) % len(STATE_KEYS)
            frame_idx = 0
            cur_row = 0
            cur_col = 0

        elif ch == curses.KEY_RIGHT:
            state_idx = (state_idx + 1) % len(STATE_KEYS)
            frame_idx = 0
            cur_row = 0
            cur_col = 0

        elif ch == curses.KEY_UP:
            cur_row = (cur_row - 1) % SPRITE_HEIGHT

        elif ch == curses.KEY_DOWN:
            cur_row = (cur_row + 1) % SPRITE_HEIGHT

        elif ch == 9:  # Tab — next frame
            frame_idx = (frame_idx + 1) % max(1, len(cur_frames))

        elif ch == ord("+"):  # Add frame
            cur_frames.append(_blank_frame())
            frame_idx = len(cur_frames) - 1

        elif ch == ord("-"):  # Remove current frame
            if len(cur_frames) > 1:
                cur_frames.pop(frame_idx)
                frame_idx = min(frame_idx, len(cur_frames) - 1)

        elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:  # Clear cell
            row = list(cur_frames[frame_idx][cur_row])
            row[cur_col] = " "
            cur_frames[frame_idx][cur_row] = "".join(row)
            cur_col = min(cur_col + 1, SPRITE_WIDTH - 1)

        elif ch == ord("n"):  # Edit names sub-screen
            names = _theme_editor_names(stdscr, names)
            stdscr.nodelay(True)

        elif ch == ord("l"):  # Edit label
            label = _theme_editor_label(stdscr, label)
            stdscr.nodelay(True)

        elif ch == ord("t"):  # Template selection
            tpl = _theme_editor_template(stdscr)
            if tpl and tpl in THEMES:
                src = THEMES[tpl]
                for jk2, _ in STATE_KEYS:
                    ik = _internal_key[jk2]
                    src_frames = src.get("sprites", {}).get(ik, [])
                    if src_frames:
                        sprites[jk2] = [_pad_frame(f) for f in src_frames]
                label = src.get("label", label)
                names = list(src.get("names", names))[:5]
            stdscr.nodelay(True)

        elif 32 <= ch <= 126:  # Printable ASCII — write to cell
            row = list(cur_frames[frame_idx][cur_row])
            if cur_col < SPRITE_WIDTH:
                row[cur_col] = chr(ch)
            cur_frames[frame_idx][cur_row] = "".join(row)
            cur_col = min(cur_col + 1, SPRITE_WIDTH - 1)


def _theme_editor_names(stdscr, names: list[str]) -> list[str]:
    """Sub-screen to edit the 5 character names. Returns updated names list."""
    curses.curs_set(1)
    stdscr.nodelay(False)

    ui_attr = curses.color_pair(12) | curses.A_BOLD
    current = list((names + [""] * 5)[:5])
    selected = 0

    while True:
        h, w = stdscr.getmaxyx()
        stdscr.erase()

        box_title = "  EDIT CHARACTER NAMES  "
        box_w = max(44, len(box_title) + 4)
        box_x = max(0, (w - box_w) // 2)
        _draw_box(stdscr, 0, box_x, box_w, 3, ui_attr)
        _safe_addstr(stdscr, 1, box_x + (box_w - len(box_title)) // 2,
                     box_title, ui_attr)

        cy = 5
        for i, name in enumerate(current):
            is_sel = i == selected
            prefix = ">" if is_sel else " "
            attr = ui_attr if is_sel else curses.A_NORMAL
            _safe_addstr(stdscr, cy, box_x + 4,
                         f"{prefix} Elf {i + 1}: {name:<20}", attr)
            cy += 2

        cy += 1
        _safe_addstr(stdscr, cy, box_x + 4,
                     "[↑↓] select  [type] edit  [Enter] save  [Esc] back",
                     curses.A_DIM)
        stdscr.refresh()

        ch = stdscr.getch()
        if ch == 27 or ch == ord("q"):
            break
        elif ch == 10 or ch == curses.KEY_ENTER:
            break
        elif ch == curses.KEY_UP:
            selected = (selected - 1) % 5
        elif ch == curses.KEY_DOWN:
            selected = (selected + 1) % 5
        elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
            if current[selected]:
                current[selected] = current[selected][:-1]
        elif 32 <= ch <= 126:
            if len(current[selected]) < 20:
                current[selected] += chr(ch)

    curses.curs_set(0)
    return current


def _theme_editor_label(stdscr, label: str) -> str:
    """Sub-screen to edit the theme display label. Returns updated label."""
    curses.curs_set(1)
    stdscr.nodelay(False)

    ui_attr = curses.color_pair(12) | curses.A_BOLD
    current = label

    while True:
        h, w = stdscr.getmaxyx()
        stdscr.erase()

        box_title = "  EDIT THEME LABEL  "
        box_w = max(50, len(box_title) + 4)
        box_x = max(0, (w - box_w) // 2)
        _draw_box(stdscr, 0, box_x, box_w, 3, ui_attr)
        _safe_addstr(stdscr, 1, box_x + (box_w - len(box_title)) // 2,
                     box_title, ui_attr)

        cy = 5
        _safe_addstr(stdscr, cy, box_x + 4, "Theme label:", curses.A_NORMAL)
        cy += 1
        _safe_addstr(stdscr, cy, box_x + 4,
                     f"  {current:<40}", ui_attr)
        cy += 3
        _safe_addstr(stdscr, cy, box_x + 4,
                     "[type] edit  [Backspace] delete  [Enter/Esc] done",
                     curses.A_DIM)
        stdscr.refresh()

        ch = stdscr.getch()
        if ch == 27 or ch == 10 or ch == curses.KEY_ENTER:
            break
        elif ch == curses.KEY_BACKSPACE or ch == 127 or ch == 8:
            if current:
                current = current[:-1]
        elif 32 <= ch <= 126:
            if len(current) < 40:
                current += chr(ch)

    curses.curs_set(0)
    return current


def _theme_editor_template(stdscr) -> str:
    """Sub-screen to pick a built-in theme as starting template. Returns theme name or ''."""
    curses.curs_set(0)
    stdscr.nodelay(False)

    ui_attr = curses.color_pair(12) | curses.A_BOLD
    options = ["claude", "kaomoji", "pixel", "samurai", "space"]
    selected = 0

    while True:
        h, w = stdscr.getmaxyx()
        stdscr.erase()

        box_title = "  CHOOSE TEMPLATE  "
        box_w = max(40, len(box_title) + 4)
        box_x = max(0, (w - box_w) // 2)
        _draw_box(stdscr, 0, box_x, box_w, 3, ui_attr)
        _safe_addstr(stdscr, 1, box_x + (box_w - len(box_title)) // 2,
                     box_title, ui_attr)

        cy = 5
        _safe_addstr(stdscr, cy, box_x + 4,
                     "Copy sprites from a built-in theme:", curses.A_NORMAL)
        cy += 2

        for i, name in enumerate(options):
            is_sel = i == selected
            prefix = ">" if is_sel else " "
            attr = ui_attr if is_sel else curses.A_NORMAL
            _safe_addstr(stdscr, cy, box_x + 4, f"{prefix} {name}", attr)
            cy += 2

        cy += 1
        _safe_addstr(stdscr, cy, box_x + 4,
                     "[↑↓] select  [Enter] apply  [Esc] cancel",
                     curses.A_DIM)
        stdscr.refresh()

        ch = stdscr.getch()
        if ch == 27 or ch == ord("q"):
            return ""
        elif ch == 10 or ch == curses.KEY_ENTER:
            return options[selected]
        elif ch == curses.KEY_UP:
            selected = (selected - 1) % len(options)
        elif ch == curses.KEY_DOWN:
            selected = (selected + 1) % len(options)


# ── Language picker ────────────────────────────────────────────────

def _lang_picker(stdscr, timeout_secs: int = 15) -> str:
    """Show language selection with preview text."""
    curses.curs_set(0)
    stdscr.nodelay(True)
    start = time.monotonic()

    lang_info = [
        ("1", "en", "English", "Editing... / Done! / Searching..."),
        ("2", "ja", "日本語", "編集中... / 完了！ / 検索中..."),
        ("3", "zh", "中文", "編輯中... / 完成！ / 搜尋中..."),
        ("4", "ko", "한국어", "편집 중... / 완료! / 검색 중..."),
    ]

    selected = 0

    while True:
        remaining = max(0, timeout_secs - (time.monotonic() - start))
        if remaining <= 0:
            return lang_info[selected][1]

        h, w = stdscr.getmaxyx()
        stdscr.erase()

        cy = _draw_header(stdscr, 1)

        section = "[ SELECT LANGUAGE ]"
        _safe_addstr(stdscr, cy, _center_x(stdscr, section), section,
                     curses.color_pair(7))
        cy += 2

        for idx, (key, code, label, preview) in enumerate(lang_info):
            is_sel = idx == selected
            marker = " >" if is_sel else "  "
            option_x = max(2, (w - 50) // 2)

            # Label
            attr = curses.color_pair(1) | curses.A_BOLD if is_sel else curses.A_NORMAL
            _safe_addstr(stdscr, cy, option_x, f"{marker} [{key}] {label}", attr)

            # Preview text
            _safe_addstr(stdscr, cy + 1, option_x + 6, preview,
                         curses.color_pair(9) | curses.A_DIM)

            cy += 3

        # Footer
        cy += 1
        hint = f"[1-4] select  |  [q] default  |  auto in {int(remaining)}s"
        _safe_addstr(stdscr, cy, _center_x(stdscr, hint), hint, curses.A_DIM)

        stdscr.refresh()
        time.sleep(0.2)

        ch = stdscr.getch()
        for i, (key, code, _label, _preview) in enumerate(lang_info):
            if ch == ord(key):
                return code
        if ch == curses.KEY_DOWN:
            selected = (selected + 1) % len(lang_info)
            start = time.monotonic()
        elif ch == curses.KEY_UP:
            selected = (selected - 1) % len(lang_info)
            start = time.monotonic()
        elif ch == 10 or ch == curses.KEY_ENTER:
            return lang_info[selected][1]
        elif ch == ord("q") or ch == 27:
            return "en"


# ── Office picker ─────────────────────────────────────────────────

def _office_picker(
    stdscr, unlocked: list[str], current: str = "auto", timeout_secs: int = 15,
) -> str:
    """Show office level selection."""
    curses.curs_set(0)
    stdscr.nodelay(True)
    start = time.monotonic()

    from engine.bubbles import t as _t
    from engine.levels import LEVEL_DEFS

    office_options: list[tuple[str, str, str]] = [
        ("auto", _t("office_auto"), "Auto-upgrade as you work"),
    ]
    for ld in LEVEL_DEFS:
        desc = f"Lv.{ld.index + 1}"
        if ld.unlock_threshold > 0:
            desc += f"  ({ld.unlock_threshold} tasks)"
        office_options.append((ld.key, _t(ld.name_i18n), desc))

    # Find current selection index
    selected = 0
    for i, (code, _label, _desc) in enumerate(office_options):
        if code == current:
            selected = i
            break

    while True:
        remaining = max(0, timeout_secs - (time.monotonic() - start))
        if remaining <= 0:
            return office_options[selected][0]

        h, w = stdscr.getmaxyx()
        stdscr.erase()

        cy = _draw_header(stdscr, 1)

        section = "[ SELECT OFFICE ]"
        _safe_addstr(stdscr, cy, _center_x(stdscr, section), section,
                     curses.color_pair(7))
        cy += 2

        # Scrollable list: show items that fit on screen
        max_visible = max(1, (h - cy - 3) // 2)
        scroll_start = max(0, selected - max_visible + 1)
        visible_end = min(len(office_options), scroll_start + max_visible)

        for idx in range(scroll_start, visible_end):
            code, label, desc = office_options[idx]
            is_sel = idx == selected
            is_locked = code not in ("auto",) and code not in unlocked
            marker = " >" if is_sel else "  "
            option_x = max(2, (w - 50) // 2)

            if is_locked:
                lock_str = f"{marker}    {label}  [{desc}]"
                _safe_addstr(stdscr, cy, option_x, lock_str, curses.A_DIM)
            else:
                tag = " *" if code == "auto" else ""
                attr = curses.color_pair(1) | curses.A_BOLD if is_sel else curses.A_NORMAL
                _safe_addstr(stdscr, cy, option_x, f"{marker} {label}{tag}", attr)
                _safe_addstr(stdscr, cy + 1, option_x + 4, desc,
                             curses.color_pair(9) | curses.A_DIM)
            cy += 2

        cy += 1
        hint = f"[q] keep current  |  auto in {int(remaining)}s"
        _safe_addstr(stdscr, cy, _center_x(stdscr, hint), hint, curses.A_DIM)

        stdscr.refresh()
        time.sleep(0.2)

        ch = stdscr.getch()
        if ch == curses.KEY_DOWN:
            # Skip locked options
            for _ in range(len(office_options)):
                selected = (selected + 1) % len(office_options)
                code = office_options[selected][0]
                if code == "auto" or code in unlocked:
                    break
            start = time.monotonic()
        elif ch == curses.KEY_UP:
            for _ in range(len(office_options)):
                selected = (selected - 1) % len(office_options)
                code = office_options[selected][0]
                if code == "auto" or code in unlocked:
                    break
            start = time.monotonic()
        elif ch == 10 or ch == curses.KEY_ENTER:
            code = office_options[selected][0]
            if code == "auto" or code in unlocked:
                return code
        elif ch == ord("q") or ch == 27:
            return current


# ── Welcome screen ─────────────────────────────────────────────────

def _welcome_screen(stdscr) -> None:
    """Show animated welcome/introduction screen on first launch."""
    curses.curs_set(0)
    stdscr.nodelay(True)
    init_colors()

    h, w = stdscr.getmaxyx()
    title_attr = curses.color_pair(1) | curses.A_BOLD
    text_attr = curses.color_pair(6)
    dim_attr = curses.A_DIM
    highlight_attr = curses.color_pair(3) | curses.A_BOLD

    intro_lines = [
        ("Welcome to", text_attr),
        ("", 0),
    ] + [(line, title_attr) for line in LOGO] + [
        ("", 0),
        (f"v{VERSION}  —  {COPYRIGHT}", dim_attr),
        ("", 0),
        ("━" * min(50, w - 6), dim_attr),
        ("", 0),
        ("Your AI agents now have an office!", highlight_attr),
        ("", 0),
        ("Watch them type, think, chat, and celebrate", text_attr),
        ("as Claude Code works on your tasks.", text_attr),
        ("", 0),
        ("Features:", curses.color_pair(2) | curses.A_BOLD),
        ("  • Animated ASCII office in a tmux pane", text_attr),
        ("  • Startup & shutdown ceremonies", text_attr),
        ("  • Role-based task assignment", text_attr),
        ("  • Watercooler chats & high-fives", text_attr),
        ("  • Dynamic whiteboard & statistics", text_attr),
        ("  • 3 themes + custom theme support", text_attr),
        ("  • 4 languages (EN/JA/ZH/KO)", text_attr),
        ("", 0),
        ("━" * min(50, w - 6), dim_attr),
    ]

    # Animate: reveal lines one by one
    visible = 0
    frame = 0
    start = time.monotonic()
    total_duration = 12.0  # auto-advance after 12s

    while True:
        elapsed = time.monotonic() - start
        if elapsed >= total_duration:
            break

        stdscr.erase()

        # Reveal 2 lines per second
        visible = min(len(intro_lines), int(elapsed * 2.5) + 1)

        cy = max(1, (h - visible) // 2)
        for i in range(visible):
            text, attr = intro_lines[i]
            x = _center_x(stdscr, text) if text else 0
            if text:
                _safe_addstr(stdscr, cy, x, text, attr)
            cy += 1

        # Footer
        remaining = max(0, int(total_duration - elapsed))
        hint = f"Press any key to continue... ({remaining}s)"
        _safe_addstr(stdscr, h - 2, _center_x(stdscr, hint), hint, dim_attr)

        stdscr.refresh()
        time.sleep(0.1)
        frame += 1

        ch = stdscr.getch()
        if ch != -1:
            break


# ── Autostart picker ───────────────────────────────────────────────

def _autostart_picker(stdscr, timeout_secs: int = 15) -> str:
    """Ask user whether to auto-start or use manual /agent-elves-start."""
    curses.curs_set(0)
    stdscr.nodelay(True)
    start = time.monotonic()

    options = [
        ("1", "auto", "Auto-start",
         "Automatically open the office when Claude Code starts"),
        ("2", "manual", "Manual start",
         "Use /agent-elves-start to open the office yourself"),
    ]
    selected = 0

    while True:
        remaining = max(0, timeout_secs - (time.monotonic() - start))
        if remaining <= 0:
            return options[selected][1]

        h, w = stdscr.getmaxyx()
        stdscr.erase()

        cy = _draw_header(stdscr, 1)

        section = "[ STARTUP MODE ]"
        _safe_addstr(stdscr, cy, _center_x(stdscr, section), section,
                     curses.color_pair(7))
        cy += 2

        for idx, (key, _val, label, desc) in enumerate(options):
            is_sel = idx == selected
            marker = " >" if is_sel else "  "
            option_x = max(2, (w - 55) // 2)

            attr = curses.color_pair(1) | curses.A_BOLD if is_sel else curses.A_NORMAL
            _safe_addstr(stdscr, cy, option_x, f"{marker} [{key}] {label}", attr)
            cy += 1
            _safe_addstr(stdscr, cy, option_x + 6, desc,
                         curses.color_pair(9) | curses.A_DIM)
            cy += 2

        hint = f"[1-2] select  |  [q] default  |  auto in {int(remaining)}s"
        _safe_addstr(stdscr, cy + 1, _center_x(stdscr, hint), hint, curses.A_DIM)

        stdscr.refresh()
        time.sleep(0.2)

        ch = stdscr.getch()
        for i, (key, val, _l, _d) in enumerate(options):
            if ch == ord(key):
                return val
        if ch == curses.KEY_DOWN:
            selected = (selected + 1) % len(options)
            start = time.monotonic()
        elif ch == curses.KEY_UP:
            selected = (selected - 1) % len(options)
            start = time.monotonic()
        elif ch == 10 or ch == curses.KEY_ENTER:
            return options[selected][1]
        elif ch == ord("q") or ch == 27:
            return "auto"


def _reset_progress_picker(stdscr, total_tasks: int, timeout_secs: int = 15) -> bool:
    """Ask user to confirm resetting office progress. Returns True if confirmed."""
    curses.curs_set(0)
    stdscr.nodelay(True)
    start = time.monotonic()
    selected = 1  # default to "No"

    options = ["Yes, reset", "No, keep"]

    while True:
        remaining = max(0, timeout_secs - (time.monotonic() - start))
        if remaining <= 0:
            return False

        h, w = stdscr.getmaxyx()
        stdscr.erase()
        cy = _draw_header(stdscr, 1)

        section = "[ RESET PROGRESS ]"
        _safe_addstr(stdscr, cy, _center_x(stdscr, section), section,
                     curses.color_pair(7))
        cy += 2

        info = f"Total tasks completed: {total_tasks}"
        _safe_addstr(stdscr, cy, _center_x(stdscr, info), info, curses.A_BOLD)
        cy += 1
        warn = "This will reset task count and lock all offices."
        _safe_addstr(stdscr, cy, _center_x(stdscr, warn), warn,
                     curses.color_pair(4))
        cy += 2

        for idx, label in enumerate(options):
            is_sel = idx == selected
            marker = " >" if is_sel else "  "
            attr = curses.color_pair(4 if idx == 0 else 1) | curses.A_BOLD if is_sel else curses.A_NORMAL
            ox = max(2, (w - 30) // 2)
            _safe_addstr(stdscr, cy, ox, f"{marker} {label}", attr)
            cy += 2

        hint = f"[q] cancel  |  auto cancel in {int(remaining)}s"
        _safe_addstr(stdscr, cy + 1, _center_x(stdscr, hint), hint, curses.A_DIM)

        stdscr.refresh()
        time.sleep(0.2)

        ch = stdscr.getch()
        if ch == curses.KEY_DOWN or ch == curses.KEY_UP:
            selected = 1 - selected
            start = time.monotonic()
        elif ch == 10 or ch == curses.KEY_ENTER:
            return selected == 0
        elif ch == ord("q") or ch == 27:
            return False


# ── Combined wizard ────────────────────────────────────────────────

def setup_wizard(
    stdscr,
    first_launch: bool = False,
    unlocked_offices: list[str] | None = None,
    current_office: str = "auto",
    total_tasks: int = 0,
) -> tuple[str, str, str, str, bool]:
    """First-launch or settings wizard.

    Returns (theme, lang, autostart, office, reset_progress).
    """
    init_colors()

    if first_launch:
        _welcome_screen(stdscr)

    theme = _theme_picker(stdscr)
    lang = _lang_picker(stdscr)

    autostart = ""
    if first_launch:
        autostart = _autostart_picker(stdscr)

    office = _office_picker(
        stdscr,
        unlocked=unlocked_offices or ["garage"],
        current=current_office,
    )

    reset = False
    if not first_launch:
        reset = _reset_progress_picker(stdscr, total_tasks)

    return theme, lang, autostart, office, reset
