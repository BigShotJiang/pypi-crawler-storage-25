"""Pomodoro timer for the Agent Elves office."""
from dataclasses import dataclass, field
from enum import Enum


class PomodoroPhase(Enum):
    OFF = "off"
    WORK = "work"
    BREAK = "break"


@dataclass
class PomodoroTimer:
    """25-min work / 5-min break Pomodoro timer."""
    phase: PomodoroPhase = PomodoroPhase.OFF
    remaining: float = 0.0
    work_duration: float = 25 * 60  # 25 minutes
    break_duration: float = 5 * 60  # 5 minutes
    completed_pomodoros: int = 0
    _transition_pending: str = ""  # "to_break" / "to_work" / ""

    def toggle(self) -> None:
        """Toggle Pomodoro: OFF→WORK, WORK/BREAK→OFF."""
        if self.phase == PomodoroPhase.OFF:
            self.phase = PomodoroPhase.WORK
            self.remaining = self.work_duration
            self._transition_pending = ""
        else:
            # Cancel
            self.phase = PomodoroPhase.OFF
            self.remaining = 0.0
            self._transition_pending = ""

    def tick(self, dt: float) -> None:
        """Advance timer by dt seconds."""
        if self.phase == PomodoroPhase.OFF:
            return
        self.remaining -= dt
        if self.remaining <= 0:
            if self.phase == PomodoroPhase.WORK:
                self.completed_pomodoros += 1
                self.phase = PomodoroPhase.BREAK
                self.remaining = self.break_duration
                self._transition_pending = "to_break"
            elif self.phase == PomodoroPhase.BREAK:
                self.phase = PomodoroPhase.WORK
                self.remaining = self.work_duration
                self._transition_pending = "to_work"

    def consume_transition(self) -> str:
        """Return and clear any pending transition. Called by Scene."""
        t = self._transition_pending
        self._transition_pending = ""
        return t

    def format_display(self) -> str:
        """Format for HUD display with ◉ icon."""
        if self.phase == PomodoroPhase.OFF:
            return "◉--:--"
        mins = int(self.remaining) // 60
        secs = int(self.remaining) % 60
        label = "WORK" if self.phase == PomodoroPhase.WORK else "BRK"
        return f"◉{mins:02d}:{secs:02d} {label}"
