"""Event handling and tool dispatch — extracted from scene.py."""
from __future__ import annotations

import random
import time
from typing import TYPE_CHECKING

from .bubbles import describe_tool_event, t
from .characters import Character, State
from . import task_board as _task_board
from . import layout as _layout

if TYPE_CHECKING:
    from .scene import Scene

AVAILABLE_STATES = frozenset({
    State.IDLE, State.WALKING, State.CHATTING,
    State.CELEBRATING, State.COFFEE, State.SNACKING,
})


def handle_event(scene: Scene, event: dict) -> None:
    """Handle an IPC event from hooks."""
    etype = event.get("type", "")

    if etype == "plan_mode_enter":
        if (not scene.intro_active and not scene.outro_active
                and not scene._plan_active
                and not (scene._plan_exit and not scene._plan_exit.is_complete)):
            start_plan_mode(scene)
    elif etype == "plan_mode_exit":
        if scene._plan_active and not (scene._plan_exit and not scene._plan_exit.is_complete):
            exit_plan_mode(scene)
    elif etype == "tool_pre":
        if not scene.intro_active and not scene.outro_active and not scene._plan_active:
            on_tool_start(scene, event)
    elif etype == "tool_post":
        if not scene.intro_active and not scene.outro_active:
            if scene._plan_active:
                on_tool_end_quiet(scene, event)
            else:
                on_tool_end(scene, event)
                scene._check_auto_upgrade()
    elif etype == "shutdown":
        pass


def start_plan_mode(scene: Scene) -> None:
    """Start the plan mode war room animation."""
    from .animation import PlanSequence
    scene._plan_exit = None
    scene._plan = PlanSequence(scene=scene)
    scene._plan.start()
    scene._plan_active = True


def exit_plan_mode(scene: Scene) -> None:
    """Start the plan mode exit animation."""
    from .animation import ExitPlanSequence
    scene._plan_exit = ExitPlanSequence(scene=scene)
    scene._plan_exit.start()


def make_task_id(scene: Scene, tool: str) -> str:
    """Generate a unique task ID for tracking."""
    scene._next_task_id += 1
    return f"{tool}:{scene._next_task_id}"


def on_tool_start(scene: Scene, event: dict) -> None:
    """Assign the best-matched character to work on this tool."""
    tool = event.get("tool", "")
    tool_input = event.get("input", {})

    desc, bubble_type = describe_tool_event(tool, tool_input)
    if tool in ("Read", "Grep", "Glob"):
        task_state = "reading"
    elif bubble_type == "thought":
        task_state = "thinking"
    else:
        task_state = "typing"
    task_id = make_task_id(scene, tool)

    # Skill tool → power-up animation before working (protagonist gets priority)
    if tool == "Skill":
        skill_name = tool_input.get("skill", "") or tool_input.get("name", "")
        protagonist = scene.characters[0] if scene.characters else None
        if (protagonist and not protagonist.is_agent
                and not protagonist.busy
                and protagonist.state in AVAILABLE_STATES):
            char = protagonist
        else:
            char = pick_character_for_tool(scene, tool)
        if not char:
            return
        desk_x, desk_y = pick_free_desk(scene)
        char.assign_powerup_task(desk_x, desk_y, skill_name, task_id)
        display = f"/{skill_name}" if skill_name else "Skill"
        _task_board.add_task_entry(scene, display, char.name, char.color_index)
        scene.task_count += 1
        scene._char_task_counts[char.name] = scene._char_task_counts.get(char.name, 0) + 1
        return

    # Agent/TeamCreate/SendMessage → open door + spawn contractor with full lifecycle
    if tool in ("Agent", "TeamCreate", "SendMessage") and len(scene.characters) < 12:
        scene.open_door()
        if tool == "Agent":
            agent_name = tool_input.get("name", "")
            agent_type = tool_input.get("subagent_type", "")
            raw_name = agent_name or agent_type or ""
        elif tool == "TeamCreate":
            raw_name = tool_input.get("name", "")
        else:  # SendMessage
            raw_name = tool_input.get("to", "") or tool_input.get("name", "")
        if raw_name:
            type_part = raw_name[:7].capitalize()
            display_name = f"Smith({type_part})"
        else:
            fallback_types = ["Explore", "Analyze", "Build", "Review", "Deploy"]
            type_part = fallback_types[len(scene.characters) % len(fallback_types)]
            display_name = f"Smith({type_part})"

        idx = len(scene.characters)
        spot_x, spot_y = _layout.find_open_spot(scene)
        door_x, door_y = scene._get_door_position()

        new_char = Character(
            name=display_name,
            x=float(door_x + 2),
            y=float(door_y + 2),
            color_index=(idx % 6) + 1,
            is_agent=True,
            theme_override="contractor",
            role="ops",
            _pending_task_state=task_state,
            _pending_task_id=task_id,
            _door_target_x=float(door_x + 2),
            _door_target_y=float(door_y + 2),
        )
        new_char.state = State.GREETING
        new_char.state_timer = 0.0
        new_char.target_x = float(spot_x + 1)
        new_char.target_y = float(spot_y - 2)
        new_char.bubble_text = t("agent_intro")
        new_char.bubble_type = "speech"
        new_char.bubble_ttl = 2.0
        new_char.busy = True
        new_char.current_task_id = task_id

        scene.characters.append(new_char)
        _task_board.add_task_entry(scene, desc, display_name, new_char.color_index)
        scene.task_count += 1

        reactions = ["!", "!?", "...?", "Oh!"]
        for c in scene.characters:
            if not c.is_agent and c.state == State.IDLE and c.bubble_ttl <= 0:
                c.bubble_text = random.choice(reactions)
                c.bubble_type = "speech"
                c.bubble_ttl = 1.5
                c.direction = "right" if door_x > c.x else "left"
        return

    # Role-based matching: prefer specialist, fall back to anyone idle
    char = pick_character_for_tool(scene, tool)
    if not char:
        return

    desk_x, desk_y = pick_free_desk(scene)
    char.assign_task(desk_x, desk_y, task_state, desc, bubble_type, task_id)
    _task_board.add_task_entry(scene, desc, char.name, char.color_index)
    scene.task_count += 1
    scene._char_task_counts[char.name] = scene._char_task_counts.get(char.name, 0) + 1


def on_tool_end_quiet(scene: Scene, event: dict) -> None:
    """Process tool completion during plan mode — state update only."""
    tool = event.get("tool", "")
    released = None
    for c in scene.characters:
        if c.busy and c.current_task_id.startswith(f"{tool}:"):
            c.busy = False
            c.current_task_id = ""
            released = c
            break
    else:
        for c in scene.characters:
            if c.busy:
                c.busy = False
                c.current_task_id = ""
                released = c
                break
    if released and released.is_agent and released._idle_before_depart <= 0:
        released._idle_before_depart = 8.0
    scene.completed_count += 1
    _task_board.mark_task_done(scene)


def on_tool_end(scene: Scene, event: dict) -> None:
    """Release the character working on this tool. Precise matching via task_id."""
    tool = event.get("tool", "")
    is_error = event.get("error", False)

    if tool in ("Agent", "TeamCreate", "SendMessage"):
        prefix_options = (f"{tool}:",)
        for c in scene.characters:
            if (c.busy and c.is_agent
                    and any(c.current_task_id.startswith(p) for p in prefix_options)):
                c.finish_task()
                scene.completed_count += 1
                _task_board.mark_task_done(scene)
                if is_error:
                    c.state = State.FRUSTRATED
                    c.state_timer = 0.0
                    c.bubble_text = t(random.choice(["frustrated_1", "frustrated_2", "frustrated_3"]))
                    c.bubble_type = "speech"
                    c.bubble_ttl = 2.5
                    c._consecutive_tasks = 0
                c._idle_before_depart = 8.0
                return

    for c in scene.characters:
        if c.busy and c.current_task_id.startswith(f"{tool}:"):
            c.finish_task()
            scene.completed_count += 1
            _task_board.mark_task_done(scene)
            if is_error:
                c.state = State.FRUSTRATED
                c.state_timer = 0.0
                c.bubble_text = t(random.choice(["frustrated_1", "frustrated_2", "frustrated_3"]))
                c.bubble_type = "speech"
                c.bubble_ttl = 2.5
                c._consecutive_tasks = 0
            else:
                now = time.monotonic()
                partner = None
                for pname, pts in scene._recent_completions:
                    if now - pts < 3.0 and pname != c.name:
                        partner_char = next(
                            (ch for ch in scene.characters
                             if ch.name == pname and ch.state in (State.CELEBRATING, State.EXCITED)),
                            None
                        )
                        if partner_char:
                            partner = partner_char
                            break
                scene._recent_completions.append((c.name, now))
                scene._recent_completions = [(n, ts) for n, ts in scene._recent_completions if now - ts < 5.0]
                if partner:
                    for hf_char in (c, partner):
                        hf_char.state = State.HIGH_FIVE
                        hf_char.state_timer = 0.0
                        hf_char.bubble_text = t("highfive_1")
                        hf_char.bubble_type = "speech"
                        hf_char.bubble_ttl = 2.0
            return

    # Fallback: release any busy character
    for c in scene.characters:
        if c.busy:
            c.finish_task()
            scene.completed_count += 1
            _task_board.mark_task_done(scene)
            if is_error:
                c.state = State.FRUSTRATED
                c.state_timer = 0.0
                c.bubble_text = t(random.choice(["frustrated_1", "frustrated_2", "frustrated_3"]))
                c.bubble_type = "speech"
                c.bubble_ttl = 2.5
                c._consecutive_tasks = 0
            return


def pick_character_for_tool(scene: Scene, tool: str) -> Character | None:
    """Pick the best available character for a tool, with load balancing."""
    available = [c for c in scene.characters
                 if c.state in AVAILABLE_STATES
                 and not c.busy and not c.is_agent]
    if not available:
        return None

    idle_specs = [c for c in available
                  if c.state == State.IDLE and c.can_handle(tool)]
    if idle_specs:
        return random.choice(idle_specs)

    idle = [c for c in available if c.state == State.IDLE]
    if idle:
        return min(idle, key=lambda c: scene._char_task_counts.get(c.name, 0))

    return min(available, key=lambda c: scene._char_task_counts.get(c.name, 0))


def pick_free_desk(scene: Scene) -> tuple[float, float]:
    """Pick a desk not currently occupied by another character."""
    if not scene._desk_positions:
        return (scene.width / 2, scene.height / 2)

    occupied = set()
    for c in scene.characters:
        if c.desk_x is not None and c.desk_y is not None:
            occupied.add((c.desk_x, c.desk_y))

    free = [d for d in scene._desk_positions if d not in occupied]
    if free:
        return random.choice(free)
    return random.choice(scene._desk_positions)
