"""ASCII art sprite definitions for furniture, decorations, and characters."""
from dataclasses import dataclass

# ---------------------------------------------------------------------------
# Character theme sprites
# Each theme maps (state, direction) -> list[list[str]]  (rows of frames)
# A "frame" is a list of strings (lines).  Multiple frames = animation cycle.
# ---------------------------------------------------------------------------

THEME_CLAUDE = {
    "name": "claude",
    "label": "Claude 圓潤風",
    "names": ["Opus", "Sonnet", "Haiku", "Claude Jr", "Artifact"],
    "sprites": {
        ("idle", "right"): [
            [
                "  .---.  ",
                " ( o o ) ",
                "  ( u )  ",
                "   /\\    ",
            ],
            [
                "  .---.  ",
                " ( - - ) ",
                "  ( u )  ",
                "   /\\    ",
            ],
        ],
        ("typing", "right"): [
            [
                "  .---.  ",
                " ( >_< ) ",
                "  ( u )| ",
                "   ||    ",
            ],
            [
                "  .---.  ",
                " ( -_- ) ",
                "  ( u )| ",
                "   ||    ",
            ],
        ],
        ("thinking", "right"): [
            [
                "  .---.  ",
                " ( . . ) ",
                "  ( ~ )? ",
                "   /\\    ",
            ],
            [
                "  .---.  ",
                " ( . . ) ",
                "  ( ~ )  ",
                "   /\\    ",
            ],
        ],
        ("walking", "right"): [
            [
                "  .---.  ",
                " ( o o ) ",
                "  ( u )> ",
                "  /> />  ",
            ],
            [
                "  .---.  ",
                " ( o o ) ",
                "  ( u )> ",
                "  <\\ <\\  ",
            ],
        ],
        ("walking", "left"): [
            [
                "  .---.  ",
                " ( o o ) ",
                " <( u )  ",
                "  <\\ <\\  ",
            ],
            [
                "  .---.  ",
                " ( o o ) ",
                " <( u )  ",
                "  /> />  ",
            ],
        ],
        ("celebrating", "right"): [
            [
                "  .---.  ",
                " ( ^o^ ) ",
                " \\( v )/ ",
                "   /\\    ",
            ],
            [
                "  .---. *",
                " ( ^o^ ) ",
                " \\( v )/ ",
                "   <>    ",
            ],
        ],
        ("coffee", "right"): [
            [
                "  .---.  ",
                " ( ^o^ )~",
                "  ( u )c ",
                "   /\\    ",
            ],
        ],
        ("stretching", "right"): [
            [
                "  .---.  ",
                " ( >o< ) ",
                " \\(   )/ ",
                "   /\\    ",
            ],
            [
                "  .---. ~",
                " ( >o< ) ",
                " \\(   )/ ",
                "   <>    ",
            ],
        ],
        ("sleepy", "right"): [
            [
                "  .---.  ",
                " ( - - ) ",
                "  ( o )  ",
                "   /\\  z ",
            ],
            [
                "  .---.  ",
                " ( _ _ ) ",
                "  ( o )  ",
                "   /\\ zZ ",
            ],
        ],
        ("excited", "right"): [
            [
                "  .---. ★",
                " ( ^o^ ) ",
                " \\( v )/ ",
                "         ",
            ],
            [
                "★ .---. ★",
                " ( ^o^ ) ",
                " \\( v )/ ",
                "   <>    ",
            ],
        ],
        ("frustrated", "right"): [
            [
                "  .---.  ",
                " ( >_< ) ",
                "  (   )  ",
                "  /|  |\\ ",
            ],
            [
                " #.---.  ",
                " ( >_< )!",
                "  (   )  ",
                "  /|  |\\ ",
            ],
        ],
        ("reading", "right"): [
            [
                "  .---.  ",
                " ( °° )  ",
                "  ( - )_ ",
                "   /\\  | ",
            ],
            [
                "  .---.  ",
                " ( °° )  ",
                "  ( - )_ ",
                "   /\\ _| ",
            ],
        ],
        ("snacking", "right"): [
            [
                "  .---.  ",
                " ( ~u~ ) ",
                "  ( m )d ",
                "   /\\    ",
            ],
            [
                "  .---.  ",
                " ( ^u^ ) ",
                "  ( o )d ",
                "   /\\    ",
            ],
        ],
    },
}

THEME_KAOMOJI = {
    "name": "kaomoji",
    "label": "顏文字 Kaomoji 風",
    "names": ["Mochi", "Anko", "Daifuku", "Kinako", "Sakura"],
    "sprites": {
        ("idle", "right"): [
            [
                " (^_^) ",
                "  /|\\  ",
                "  / \\  ",
            ],
            [
                " (^_^) ",
                "  /|\\  ",
                "  / \\  ",
            ],
        ],
        ("typing", "right"): [
            [
                " (>_<) ",
                "  /|\\~ ",
                "  ||   ",
            ],
            [
                " (>.<) ",
                "  /|\\~ ",
                "  ||   ",
            ],
        ],
        ("thinking", "right"): [
            [
                " (._.)>",
                "  /|\\  ",
                "  / \\  ",
            ],
            [
                " (._.)?",
                "  /|\\  ",
                "  / \\  ",
            ],
        ],
        ("walking", "right"): [
            [
                " (^_^)>",
                "  /|/  ",
                "   >>  ",
            ],
            [
                " (^_^)>",
                "  \\|\\  ",
                "  <<   ",
            ],
        ],
        ("walking", "left"): [
            [
                "<(^_^) ",
                "  \\|\\  ",
                "  <<   ",
            ],
            [
                "<(^_^) ",
                "  /|/  ",
                "   >>  ",
            ],
        ],
        ("celebrating", "right"): [
            [
                "\\(^o^)/",
                "   |   ",
                "  / \\  ",
            ],
            [
                "\\(^o^)/",
                "   |  *",
                "  < >  ",
            ],
        ],
        ("coffee", "right"): [
            [
                " (^o^)~",
                "  /|c  ",
                "  / \\  ",
            ],
        ],
    },
}

THEME_PIXEL = {
    "name": "pixel",
    "label": "像素 RPG 風",
    "names": ["Player1", "Player2", "NPC_A", "NPC_B", "Boss"],
    "sprites": {
        ("idle", "right"): [
            [
                " [@@] ",
                " |oo| ",
                " [==] ",
                "  ||  ",
                "  /\\  ",
            ],
            [
                " [@@] ",
                " |--| ",
                " [==] ",
                "  ||  ",
                "  /\\  ",
            ],
        ],
        ("typing", "right"): [
            [
                " [@@] ",
                " |><| ",
                " [==]~",
                "  ||  ",
                "  ||  ",
            ],
            [
                " [@@] ",
                " |><| ",
                " [==] ",
                "  ||~ ",
                "  ||  ",
            ],
        ],
        ("thinking", "right"): [
            [
                " [@@] ",
                " |..| ",
                " [==]?",
                "  ||  ",
                "  /\\  ",
            ],
            [
                " [@@] ",
                " |..| ",
                " [==] ",
                "  ||  ",
                "  /\\  ",
            ],
        ],
        ("walking", "right"): [
            [
                " [@@] ",
                " |oo|>",
                " [==] ",
                "  /|  ",
                " /    ",
            ],
            [
                " [@@] ",
                " |oo|>",
                " [==] ",
                "  |\\  ",
                "    \\ ",
            ],
        ],
        ("walking", "left"): [
            [
                " [@@] ",
                "<|oo| ",
                " [==] ",
                "  |\\  ",
                "    \\ ",
            ],
            [
                " [@@] ",
                "<|oo| ",
                " [==] ",
                "  /|  ",
                " /    ",
            ],
        ],
        ("celebrating", "right"): [
            [
                "*[@@]*",
                " |^^| ",
                " [==] ",
                " /||\\ ",
                " /  \\ ",
            ],
            [
                " [@@] ",
                "*|^^|*",
                " [==] ",
                " \\||/ ",
                " <  > ",
            ],
        ],
        ("coffee", "right"): [
            [
                " [@@] ",
                " |^^|~",
                " [==]c",
                "  ||  ",
                "  /\\  ",
            ],
        ],
    },
}

THEME_SAMURAI = {
    "name": "samurai",
    "label": "侍 Samurai 和風",
    "names": ["Musashi", "Hanzo", "Sakura", "Kaede", "Ryu"],
    "sprites": {
        ("idle", "right"): [
            [
                "  /|\\  ",
                " (o_o) ",
                " /|=|\\ ",
                "  / \\  ",
            ],
            [
                "  /|\\  ",
                " (-_-) ",
                " /|=|\\ ",
                "  / \\  ",
            ],
        ],
        ("typing", "right"): [
            [
                "  /|\\  ",
                " (>.<) ",
                " /|=|~ ",
                "  | |  ",
            ],
            [
                "  /|\\  ",
                " (-.-) ",
                " /|=|~ ",
                "  | |  ",
            ],
        ],
        ("thinking", "right"): [
            [
                "  /|\\  ",
                " (._.)>",
                " /|=|\\ ",
                "  / \\  ",
            ],
            [
                "  /|\\  ",
                " (._.) ",
                " /|=|\\ ",
                "  / \\  ",
            ],
        ],
        ("walking", "right"): [
            [
                "  /|\\  ",
                " (o_o)>",
                " /|=|/ ",
                "  /> />",
            ],
            [
                "  /|\\  ",
                " (o_o)>",
                " /|=|\\ ",
                "  <\\ <\\",
            ],
        ],
        ("walking", "left"): [
            [
                "  /|\\  ",
                "<(o_o) ",
                " \\|=|\\ ",
                " <\\ <\\ ",
            ],
            [
                "  /|\\  ",
                "<(o_o) ",
                " /|=|/ ",
                "  /> />",
            ],
        ],
        ("celebrating", "right"): [
            [
                " \\|/   ",
                " (^o^) ",
                " \\|=|/ ",
                "  / \\  ",
            ],
            [
                "  |/*  ",
                " (^o^) ",
                " \\|=|/ ",
                "  < >  ",
            ],
        ],
        ("coffee", "right"): [
            [
                "  /|\\  ",
                " (^.^)~",
                " /|=|c ",
                "  / \\  ",
            ],
        ],
    },
}

THEME_SPACE = {
    "name": "space",
    "label": "Space 太空風",
    "names": ["Astro", "Zeta", "Nova", "Cosmo", "Orbit"],
    "sprites": {
        ("idle", "right"): [
            [
                "  ,-.  ",
                " {o o} ",
                " /| |\\ ",
                "  d b  ",
            ],
            [
                "  ,-.  ",
                " {- -} ",
                " /| |\\ ",
                "  d b  ",
            ],
        ],
        ("typing", "right"): [
            [
                "  ,-.  ",
                " {>_<} ",
                " /| |~ ",
                "  | |  ",
            ],
            [
                "  ,-.  ",
                " {-_-} ",
                " /| |~ ",
                "  | |  ",
            ],
        ],
        ("thinking", "right"): [
            [
                "  ,-.  ",
                " {. .}?",
                " /| |\\ ",
                "  d b  ",
            ],
            [
                "  ,-.  ",
                " {. .} ",
                " /| |\\ ",
                "  d b  ",
            ],
        ],
        ("walking", "right"): [
            [
                "  ,-.  ",
                " {o o}>",
                " /| |/ ",
                "  > >  ",
            ],
            [
                "  ,-.  ",
                " {o o}>",
                " \\| |\\ ",
                "  < <  ",
            ],
        ],
        ("walking", "left"): [
            [
                "  ,-.  ",
                "<{o o} ",
                " \\| |\\ ",
                "  < <  ",
            ],
            [
                "  ,-.  ",
                "<{o o} ",
                " /| |/ ",
                "  > >  ",
            ],
        ],
        ("celebrating", "right"): [
            [
                " *,-.* ",
                " \\{^o^}/",
                "  | |  ",
                "  d b  ",
            ],
            [
                "  ,-.*  ",
                " \\{^o^}/",
                "  | |   ",
                "  < >   ",
            ],
        ],
        ("coffee", "right"): [
            [
                "  ,-.  ",
                " {^.^}~",
                " /| |c ",
                "  d b  ",
            ],
        ],
    },
}

# Contractor / support elf theme — Agent Smith (Matrix) style
THEME_CONTRACTOR = {
    "name": "contractor",
    "label": "Agent Smith",
    "names": ["Smith", "Smith-2", "Smith-3", "Smith-4", "Smith-5",
              "Smith-6", "Smith-7", "Smith-8", "Smith-9", "Smith-X"],
    "sprites": {
        ("idle", "right"): [
            [
                "  _===_  ",
                " (|■ ■|) ",
                "  ( - )| ",
                "   /\\    ",
            ],
            [
                "  _===_  ",
                " (|□ □|) ",
                "  ( - )| ",
                "   /\\    ",
            ],
        ],
        ("typing", "right"): [
            [
                "  _===_  ",
                " (|> <|) ",
                "  ( - )| ",
                "   ||    ",
            ],
            [
                "  _===_  ",
                " (|■ ■|) ",
                "  ( - )| ",
                "   ||    ",
            ],
        ],
        ("thinking", "right"): [
            [
                "  _===_  ",
                " (|. .|) ",
                "  ( - )? ",
                "   /\\    ",
            ],
            [
                "  _===_  ",
                " (|. .|) ",
                "  ( - )  ",
                "   /\\    ",
            ],
        ],
        ("walking", "right"): [
            [
                "  _===_  ",
                " (|■ ■|)>",
                "  ( - )| ",
                "  /> />  ",
            ],
            [
                "  _===_  ",
                " (|■ ■|)>",
                "  ( - )| ",
                "  <\\ <\\  ",
            ],
        ],
        ("walking", "left"): [
            [
                "  _===_  ",
                "<(|■ ■|) ",
                " |( - )  ",
                "  <\\ <\\  ",
            ],
            [
                "  _===_  ",
                "<(|■ ■|) ",
                " |( - )  ",
                "  /> />  ",
            ],
        ],
        ("celebrating", "right"): [
            [
                "  _===_  ",
                "\\(|■ ■|)/",
                "  ( v )  ",
                "   /\\    ",
            ],
            [
                "  _===_ *",
                "\\(|■ ■|)/",
                "  ( v )  ",
                "   <>    ",
            ],
        ],
        ("coffee", "right"): [
            [
                "  _===_  ",
                " (|□ □|)~",
                "  ( - )c ",
                "   /\\    ",
            ],
        ],
    },
}

THEMES: dict[str, dict] = {
    "claude": THEME_CLAUDE,
    "kaomoji": THEME_KAOMOJI,
    "pixel": THEME_PIXEL,
    "samurai": THEME_SAMURAI,
    "space": THEME_SPACE,
    "contractor": THEME_CONTRACTOR,
}

# ---------------------------------------------------------------------------
# Custom theme loading
# ---------------------------------------------------------------------------

CUSTOM_THEME_PATH = __import__("os").path.expanduser(
    "~/.config/agent-elves/custom-theme.json"
)


def load_custom_theme() -> bool:
    """Load user-defined custom theme from JSON config.

    Expected format in ~/.config/agent-elves/custom-theme.json:
    {
      "name": "my-theme",
      "label": "My Custom Theme",
      "names": ["Alice", "Bob", "Charlie", "Dave", "Eve"],
      "sprites": {
        "idle": [["  O  ", " /|\\\\ ", " / \\\\ "]],
        "typing": [["  O  ", " /|= ", " | | "]],
        "walking_right": [["  O  ", " /|> ", "  >>"]],
        "walking_left": [["  O  ", "<|\\\\ ", " << "]],
        "celebrating": [["\\\\O/ ", " |  ", "/ \\\\ "]],
        "thinking": [["  O? ", " /|\\\\ ", " / \\\\ "]],
        "coffee": [["  O~ ", " /|c ", " / \\\\ "]]
      }
    }

    Returns True if custom theme was loaded successfully.
    """
    import json
    import os

    if not os.path.isfile(CUSTOM_THEME_PATH):
        return False

    try:
        with open(CUSTOM_THEME_PATH) as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return False

    if not isinstance(data, dict):
        return False

    name = str(data.get("name", "custom"))
    label = str(data.get("label", "Custom Theme"))
    names = data.get("names", ["Elf-1", "Elf-2", "Elf-3", "Elf-4", "Elf-5"])

    raw_sprites = data.get("sprites", {})
    if not isinstance(raw_sprites, dict):
        return False

    # Convert JSON format to internal (state, direction) -> list[list[str]]
    sprite_map: dict[tuple[str, str], list[list[str]]] = {}

    key_mapping = {
        "idle": ("idle", "right"),
        "typing": ("typing", "right"),
        "thinking": ("thinking", "right"),
        "walking_right": ("walking", "right"),
        "walking_left": ("walking", "left"),
        "celebrating": ("celebrating", "right"),
        "coffee": ("coffee", "right"),
    }

    for json_key, internal_key in key_mapping.items():
        frames = raw_sprites.get(json_key)
        if isinstance(frames, list) and frames:
            # Ensure each frame is a list of strings
            valid_frames = []
            for frame in frames:
                if isinstance(frame, list) and all(isinstance(s, str) for s in frame):
                    valid_frames.append(frame)
            if valid_frames:
                sprite_map[internal_key] = valid_frames

    if not sprite_map:
        return False

    # Ensure at least idle exists
    if ("idle", "right") not in sprite_map:
        return False

    theme = {
        "name": name,
        "label": label,
        "names": names[:5] if isinstance(names, list) else ["Elf-1"],
        "sprites": sprite_map,
    }

    THEMES["custom"] = theme
    return True


# Try loading custom theme at import time
load_custom_theme()

# ---------------------------------------------------------------------------
# Furniture sprites  (list of strings, one per row)
# ---------------------------------------------------------------------------

# Front-facing dual monitor desk
DESK = [
    " ╭──╮╭──╮    ",
    " │▫▫││▫▫│    ",
    " ╰┬─╯╰─┬╯    ",
    " ┌──────────┐ ",
    " └┐        ┌┘ ",
]

# Front-facing single monitor desk
DESK_SINGLE = [
    "  ╭────╮     ",
    "  │ ▫▫ │     ",
    "  ╰─┬┬─╯     ",
    " ┌──────────┐ ",
    " └┐        ┌┘ ",
]

# Side-view desk
DESK_SIDE = [
    "  ╭──╮ ",
    "  │▫▫│ ",
    "  ╰──╯ ",
    "   ││  ",
    " ┌────┐",
    " └┐  ┌┘",
]

# Keep DESK_SMALL as alias for compact layouts
DESK_SMALL = DESK_SINGLE

# Portable/temporary desk for contractor elves (dotted table = foldable)
DESK_PORTABLE = [
    "  ╭────╮     ",
    "  │ ▫▫ │     ",
    "  ╰─┬┬─╯     ",
    " +----------+ ",
    " |_        _| ",
]

PLANT = [
    " ,*. ",
    " \\|/ ",
    " [▓] ",
]

WATERCOOLER = [
    " ┌┐ ",
    " ├┤ ",
    " ├┤ ",
    " └┘ ",
]

WHITEBOARD = [
    "┌────────┐",
    "│ TASKS: │",
    "│ v v _  │",
    "└────────┘",
]

# Plan-mode meeting furniture
MEETING_TABLE = [
    " ┌──────────┐ ",
    " │ ░░░░░░░░ │ ",
    " └──────────┘ ",
]

WHITEBOARD_BLANK = [
    "┌────────┐",
    "│        │",
    "│        │",
    "└────┬┬──┘",
]

WHITEBOARD_WRITING = [
    "┌────────┐",
    "│ PLAN:  │",
    "│ □→□... │",
    "└────┬┬──┘",
]

WHITEBOARD_PLAN = [
    "┌────────┐",
    "│ PLAN:  │",
    "│ □→□→□  │",
    "└────┬┬──┘",
]

# Game Dev Story style decorations
BOOKSHELF = [
    "┌──────────┐",
    "│▓▓▓▓▓▓▓▓▓▓│",
    "│▓▒▓▓▒▓▓▒▓▓│",
    "└──────────┘",
]

TROPHY_CASE = [
    "╔════════╗",
    "║ ★  ♦  ★║",
    "║ ┃  ┃  ┃║",
    "╚════════╝",
]

ARCADE_CABINET = [
    "┌────┐",
    "│▓▓▓▓│",
    "│ ▒▒ │",
    "└┤  ├┘",
]

SOFA = [
    "╭────────╮",
    "│ ≈≈≈≈≈≈ │",
    "╰┤      ├╯",
]

SERVER_RACK = [
    "╔════╗",
    "║●○●○║",
    "║○●○●║",
    "╚════╝",
]

BAR = [
    "+---------+",
    "| ~ :] ~ :|",
    "+---------+",
    "|         |",
    "+---------+",
]

BIKE = [
    " __O  ",
    "/|\\|\\ ",
    "(_)(_)",
]

# ---------------------------------------------------------------------------
# Level-up banner ASCII art (big version for width >= 55)
# ---------------------------------------------------------------------------
LEVEL_UP_BIG = [
    "██╗     ███████╗██╗   ██╗███████╗██╗     ",
    "██║     ██╔════╝██║   ██║██╔════╝██║     ",
    "██║     █████╗  ██║   ██║█████╗  ██║     ",
    "██║     ██╔══╝  ╚██╗ ██╔╝██╔══╝  ██║     ",
    "███████╗███████╗ ╚████╔╝ ███████╗███████╗",
    "╚══════╝╚══════╝  ╚═══╝  ╚══════╝╚══════╝",
    "         ██╗   ██╗██████╗ ██╗             ",
    "         ██║   ██║██╔══██╗██║             ",
    "         ██║   ██║██████╔╝██║             ",
    "         ██║   ██║██╔═══╝ ╚═╝             ",
    "         ╚██████╔╝██║     ██╗             ",
    "          ╚═════╝ ╚═╝     ╚═╝             ",
]

# Level-up banner ASCII art (small version for width < 55)
LEVEL_UP_SMALL = [
    "╦  ╔══╗╦  ╦╔══╗╦  ",
    "║  ║╔═╝║  ║║╔═╝║  ",
    "║  ║╚═╗╚╗╔╝║╚═╗║  ",
    "╩═╝╚══╝ ╚╝ ╚══╝╩═╝",
    "╦ ╦╔══╗╦           ",
    "║ ║╠══╝╩           ",
    "╚═╝╩   ╩           ",
]


# Dream Office special decoration (Lv.10)
GOLD_TROPHY_WALL = [
    "╔═══════════╗",
    "║ ★  ★  ★  ★║",
    "║ ┃  ┃  ┃  ┃║",
    "╚═══════════╝",
]

# Windows — grow with office level (2x size)
WINDOW_SMALL = [
    "┌──────┐",
    "│      │",
    "│      │",
    "└──────┘",
]

WINDOW_MEDIUM = [
    "┌──────────┐",
    "│          │",
    "│          │",
    "└──────────┘",
]

WINDOW_LARGE = [
    "┌──────────────────────┐",
    "│                      │",
    "│                      │",
    "│                      │",
    "└──────────────────────┘",
]


COFFEE_MACHINE = [
    " ╔══════╗ ",
    " ║ .--. ║ ",
    " ║ |C | ║ ",
    " ║ `--' ║ ",
    " ╚═╤══╤═╝ ",
    "   ╙╜╙╜   ",
]

# Door states
DOOR_CLOSED = [
    "╔══════╗",
    "║      ║",
    "║      ║",
    "║   o  ║",
    "║      ║",
    "╚══════╝",
]

DOOR_OPENING = [
    "╔══════╗",
    "║    ╱ ║",
    "║   ╱  ║",
    "║  ╱   ║",
    "║ ╱    ║",
    "╚══════╝",
]

DOOR_OPEN = [
    "╔══════╗",
    "╱      ║",
    "╱      ║",
    "╱   o  ║",
    "╱      ║",
    "╚══════╝",
]

# Default alias
DOOR = DOOR_CLOSED

# Monitor states (for desk screens)
MONITOR_OFF = "▫▫"
MONITOR_BOOT_1 = "░░"
MONITOR_BOOT_2 = "▒▒"
MONITOR_ON = "▪▪"
MONITOR_SHUTDOWN = "▓▓"

# Coffee machine states
COFFEE_IDLE = [
    " ╔══════╗ ",
    " ║ .--. ║ ",
    " ║ |C | ║ ",
    " ║ `--' ║ ",
    " ╚═╤══╤═╝ ",
    "   ╙╜╙╜   ",
]

COFFEE_BREWING_1 = [
    " ╔══════╗ ",
    " ║ .--. ║~",
    " ║ |C | ║ ",
    " ║ `--' ║ ",
    " ╚═╤══╤═╝ ",
    "   ╙╜╙╜   ",
]

COFFEE_BREWING_2 = [
    " ╔══════╗~",
    " ║ .--. ║ ",
    " ║ |C | ║ ",
    " ║ `--' ║ ",
    " ╚═╤══╤═╝ ",
    "  ~╙╜╙╜   ",
]

COFFEE_DONE = [
    " ╔══════╗ ",
    " ║ .--. ║ ",
    " ║ |C | ║ ",
    " ║ `--' ║ ",
    " ╚═╤══╤═╝~",
    "   ╙╜╙╜   ",
]

FLOOR_CHARS = [" ", ".", " ", " "]  # sparse floor pattern


@dataclass(frozen=True)
class FurnitureItem:
    """A placed furniture item in the scene (immutable after creation)."""
    name: str
    sprite: list[str]
    x: int
    y: int
    walkable: bool = False
    foreground: bool = False  # render after characters (covers lower body)

    @property
    def width(self) -> int:
        return max(len(line) for line in self.sprite) if self.sprite else 0

    @property
    def height(self) -> int:
        return len(self.sprite)
