"""Task whiteboard rendering — extracted from scene.py."""
from __future__ import annotations

import time
from typing import TYPE_CHECKING

from .bubbles import display_width, _pad_to_width

if TYPE_CHECKING:
    from .scene import Scene


def get_task_box_lines(scene: Scene, box_w: int) -> list[tuple[str, int]]:
    """Generate task box lines with per-line color index.

    Returns list of (line_string, color_index) where color_index 0 = default.
    Format: WORKING section with name+progress bar, separator, DONE section.
    """
    inner_w = box_w - 2
    if inner_w < 14:
        return []
    lines: list[tuple[str, int]] = []
    border_top = "╔" + "═" * (box_w - 2) + "╗"
    border_bot = "╚" + "═" * (box_w - 2) + "╝"
    lines.append((border_top, 0))
    if not scene.task_log:
        lines.append(("║" + _pad_to_width("  TASKS:  (waiting for work...)", inner_w) + "║", 0))
        lines.append((border_bot, 0))
        return lines
    now = time.monotonic()
    working = [e for e in scene.task_log if not e[1]]
    done = [e for e in scene.task_log if e[1]]

    def _bar(elapsed: float) -> str:
        filled = min(5, int(elapsed / 3) + 1)
        return "█" * filled + "░" * (6 - filled)

    def _fmt_time(secs: float) -> str:
        s = int(secs)
        return f"{s}s" if s < 60 else f"{s // 60}m{s % 60:02d}s"

    blink = int(now * 2) % 2 == 0

    def _make_line(content: str, color: int) -> tuple[str, int]:
        while display_width(content) > inner_w:
            content = content[:-1]
        padded = _pad_to_width(content, inner_w)
        return ("║" + padded + "║", color)

    for entry in working[:3]:
        desc, _, elf_name, start, _, color = entry
        elapsed = now - start
        bar = _bar(elapsed)
        indicator = "▸" if blink else "▹"
        time_str = _fmt_time(elapsed)
        if "(" in elf_name and elf_name.endswith(")"):
            short_name = elf_name[:elf_name.index("(")]
        else:
            short_name = elf_name
        name_to_use = elf_name
        prefix_full = f" {name_to_use} {bar} {indicator} "
        suffix = f" {time_str:>5s} "
        desc_w_full = inner_w - display_width(prefix_full) - display_width(suffix)
        if desc_w_full < 15:
            name_to_use = short_name
        name_display = name_to_use[:12].ljust(min(12, display_width(name_to_use)))
        prefix = f" {name_display} {bar} {indicator} "
        desc_w = inner_w - display_width(prefix) - display_width(suffix)
        short = desc
        while display_width(short) > max(1, desc_w):
            short = short[:-1]
        content = prefix + _pad_to_width(short, max(0, desc_w)) + suffix
        lines.append(_make_line(content, color))

    if working and done:
        sep = " ─" * (inner_w // 2)
        lines.append(_make_line(sep, 0))

    max_done = max(1, 7 - len(working) - (1 if working and done else 0))
    for entry in done[:max_done]:
        desc, _, _elf, _start, elapsed, color = entry
        time_str = _fmt_time(elapsed)
        prefix = " [✓] "
        suffix = f" {time_str:>5s} "
        desc_w = inner_w - display_width(prefix) - display_width(suffix)
        short = desc
        while display_width(short) > max(1, desc_w):
            short = short[:-1]
        content = prefix + _pad_to_width(short, max(0, desc_w)) + suffix
        lines.append(_make_line(content, color))

    lines.append((border_bot, 0))
    return lines


def add_task_entry(scene: Scene, desc: str, elf_name: str, color_idx: int) -> None:
    """Add a new task to the whiteboard log."""
    scene.task_log.insert(0, [desc.replace("\n", " "), False, elf_name, time.monotonic(), 0.0, color_idx])
    scene.task_log = scene.task_log[:10]


def mark_task_done(scene: Scene) -> None:
    """Mark the oldest incomplete task on whiteboard as done."""
    for entry in reversed(scene.task_log):
        if not entry[1]:
            entry[1] = True
            entry[4] = time.monotonic() - entry[3]
            return
