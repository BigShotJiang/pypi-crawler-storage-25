"""Weather data service for Agent Elves office windows.

Fetches real weather data from Open-Meteo API with IP geolocation,
caching, and graceful fallback. Never crashes — all network calls are
wrapped in try/except with timeout=3.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import os
import random
import time
import urllib.request


@dataclass
class WeatherData:
    temperature: float
    code: int
    description: str  # sunny/cloudy/foggy/rain/snow/storm
    timestamp: float
    city: str = ""


class WeatherService:
    CACHE_PATH = os.path.expanduser("~/.cache/agent-elves/weather_cache.json")
    UPDATE_INTERVAL = 600  # 10 minutes

    def __init__(self):
        self._data: WeatherData | None = None
        self._last_fetch: float = 0
        self._latitude: float | None = None
        self._longitude: float | None = None
        self._city: str = ""

    def configure(self, lat: float | None = None, lon: float | None = None,
                  city: str | None = None):
        self._latitude = lat
        self._longitude = lon
        if city is not None:
            self._city = city

    @property
    def city(self) -> str:
        return self._city

    def get_weather(self) -> WeatherData:
        now = time.monotonic()
        if self._data and now - self._last_fetch < self.UPDATE_INTERVAL:
            return self._data
        data = self._fetch_from_api()
        if data:
            self._data = data
            self._last_fetch = now
            self._save_cache(data)
            return data
        cached = self._load_cache()
        if cached:
            self._data = cached
            self._last_fetch = now
            return cached
        fallback = self._random_weather()
        self._data = fallback
        self._last_fetch = now
        return fallback

    def _fetch_from_api(self) -> WeatherData | None:
        try:
            lat, lon = self._get_location()
            url = (
                f"https://api.open-meteo.com/v1/forecast?"
                f"latitude={lat}&longitude={lon}"
                f"&current=temperature_2m,weather_code"
            )
            resp = urllib.request.urlopen(url, timeout=3)
            data = json.loads(resp.read().decode())
            current = data.get("current", {})
            temp = current.get("temperature_2m", 20.0)
            code = current.get("weather_code", 0)
            return WeatherData(
                temperature=temp,
                code=code,
                description=self._code_to_desc(code),
                timestamp=time.time(),
                city=self._city,
            )
        except Exception:
            return None

    def _get_location(self) -> tuple[float, float]:
        if self._latitude is not None and self._longitude is not None:
            return (self._latitude, self._longitude)
        try:
            resp = urllib.request.urlopen(
                "http://ip-api.com/json/?fields=lat,lon,city", timeout=3
            )
            data = json.loads(resp.read().decode())
            city = data.get("city", "")
            if city:
                self._city = city
            return (data.get("lat", 35.68), data.get("lon", 139.69))
        except Exception:
            return (35.68, 139.69)

    @staticmethod
    def _code_to_desc(code: int) -> str:
        if code == 0:
            return "sunny"
        if code <= 3:
            return "cloudy"
        if 45 <= code <= 48:
            return "foggy"
        if 51 <= code <= 67 or 80 <= code <= 82:
            return "rain"
        if 71 <= code <= 77:
            return "snow"
        if 95 <= code <= 99:
            return "storm"
        return "cloudy"

    def _save_cache(self, data: WeatherData) -> None:
        try:
            os.makedirs(os.path.dirname(self.CACHE_PATH), mode=0o700, exist_ok=True)
            with open(self.CACHE_PATH, "w") as f:
                json.dump(
                    {
                        "temperature": data.temperature,
                        "code": data.code,
                        "description": data.description,
                        "timestamp": data.timestamp,
                        "city": data.city,
                    },
                    f,
                )
        except OSError:
            pass

    def _load_cache(self) -> WeatherData | None:
        try:
            with open(self.CACHE_PATH) as f:
                d = json.load(f)
                city = d.get("city", "")
                if city and not self._city:
                    self._city = city
                return WeatherData(
                    temperature=d["temperature"],
                    code=d["code"],
                    description=d["description"],
                    timestamp=d["timestamp"],
                    city=city,
                )
        except (OSError, KeyError, json.JSONDecodeError):
            return None

    def _random_weather(self) -> WeatherData:
        hour = time.localtime().tm_hour
        if 6 <= hour < 18:
            desc = random.choice(["sunny", "sunny", "cloudy"])
        else:
            desc = random.choice(["cloudy", "cloudy", "rain"])
        return WeatherData(
            temperature=random.uniform(15.0, 30.0),
            code=0 if desc == "sunny" else 2,
            description=desc,
            timestamp=time.time(),
        )
