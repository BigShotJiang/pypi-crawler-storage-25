"""Agent Elves — ASCII art office animation for Claude Code."""
__version__ = "0.1.2"
