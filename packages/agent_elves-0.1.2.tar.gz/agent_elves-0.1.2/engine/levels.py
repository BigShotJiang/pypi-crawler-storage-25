"""Office level definitions — 10 levels from Garage to Dream Office.

This module is intentionally free of imports from other engine modules
to avoid circular dependencies.
"""
from dataclasses import dataclass, field


@dataclass(frozen=True)
class LevelDef:
    """Immutable definition for a single office level."""
    index: int              # 0-9
    key: str                # config key e.g. "garage"
    name_i18n: str          # i18n key e.g. "office_garage"
    session_threshold: int  # tasks in current session to auto-upgrade
    unlock_threshold: int   # cumulative tasks across sessions to unlock
    elf_count: int          # number of characters
    desk_count: int         # number of desks (>= elf_count sometimes)
    furniture: tuple[str, ...] = field(default=())  # furniture items to place


LEVEL_DEFS: tuple[LevelDef, ...] = (
    LevelDef(0, "garage", "office_garage", 0, 0, 1, 2,
             ("door", "coffee", "whiteboard")),
    LevelDef(1, "home_office", "office_home_office", 5, 20, 1, 2,
             ("door", "coffee", "whiteboard", "bookshelf")),
    LevelDef(2, "small_office", "office_small_office", 12, 50, 2, 2,
             ("door", "coffee", "whiteboard", "bookshelf", "plant")),
    LevelDef(3, "growing_office", "office_growing_office", 22, 100, 2, 3,
             ("door", "coffee", "whiteboard", "bookshelf", "plant", "trophy")),
    LevelDef(4, "studio", "office_studio", 35, 200, 3, 3,
             ("door", "coffee", "whiteboard", "bookshelf", "plant", "trophy",
              "sofa", "watercooler")),
    LevelDef(5, "creative_studio", "office_creative_studio", 55, 350, 3, 4,
             ("door", "coffee", "whiteboard", "bookshelf", "plant", "trophy",
              "sofa", "watercooler", "arcade")),
    LevelDef(6, "tech_company", "office_tech_company", 80, 550, 3, 4,
             ("door", "coffee", "whiteboard", "bookshelf", "plant", "trophy",
              "sofa", "watercooler", "arcade", "bar")),
    LevelDef(7, "big_tech", "office_big_tech", 115, 800, 4, 4,
             ("door", "coffee", "whiteboard", "bookshelf", "plant", "trophy",
              "sofa", "watercooler", "arcade", "bar", "bike")),
    LevelDef(8, "enterprise", "office_enterprise", 160, 1200, 4, 4,
             ("door", "coffee", "whiteboard", "bookshelf", "plant", "trophy",
              "sofa", "watercooler", "arcade", "bar", "bike", "server")),
    LevelDef(9, "dream_office", "office_dream_office", 220, 2000, 4, 4,
             ("door", "coffee", "whiteboard", "bookshelf", "plant", "trophy",
              "sofa", "watercooler", "arcade", "bar", "bike", "server", "gold_wall")),
)

LEVEL_BY_KEY: dict[str, LevelDef] = {ld.key: ld for ld in LEVEL_DEFS}
LEVEL_KEYS: tuple[str, ...] = tuple(ld.key for ld in LEVEL_DEFS)

# Old 3-level keys → new keys (for config migration)
OLD_KEY_MIGRATION: dict[str, str] = {
    "startup": "garage",
    "studio": "studio",
    "aaa": "enterprise",
}
