"""Unix domain socket listener for receiving hook events."""
import json
import os
import socket


class EventReceiver:
    """Non-blocking UDP Unix socket receiver for hook events."""

    def __init__(self, sock_path: str):
        self.sock_path = sock_path
        self.sock: socket.socket | None = None

    def start(self) -> None:
        # Ensure parent directory exists (mode 700)
        parent = os.path.dirname(self.sock_path)
        if parent:
            os.makedirs(parent, mode=0o700, exist_ok=True)

        # Remove stale socket
        try:
            os.unlink(self.sock_path)
        except OSError:
            pass

        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        self.sock.bind(self.sock_path)
        self.sock.setblocking(False)

    def drain(self) -> list[dict]:
        """Drain all pending messages. Returns list of validated events."""
        events = []
        if not self.sock:
            return events
        while True:
            try:
                data = self.sock.recv(32768)  # 32KB to handle larger payloads
                event = json.loads(data.decode())
                if not isinstance(event, dict):
                    continue
                # Validate required fields and clamp tool name
                etype = event.get("type", "")
                if not isinstance(etype, str):
                    continue
                tool = event.get("tool", "")
                if not isinstance(tool, str):
                    event["tool"] = ""
                else:
                    event["tool"] = tool[:64]
                inp = event.get("input")
                if not isinstance(inp, dict):
                    event["input"] = {}
                events.append(event)
            except BlockingIOError:
                break
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
        return events

    def close(self) -> None:
        if self.sock:
            self.sock.close()
            self.sock = None
        try:
            os.unlink(self.sock_path)
        except OSError:
            pass
