"""Comic-style speech and thought bubbles with i18n support."""
from __future__ import annotations

import unicodedata

# ---------------------------------------------------------------------------
# Translations
# ---------------------------------------------------------------------------

STRINGS: dict[str, dict[str, str]] = {
    "en": {
        "editing": "Editing",
        "writing": "Writing",
        "reading": "Reading",
        "searching": "Searching...",
        "finding": "Finding...",
        "backup": "Calling backup!",
        "web_search": "Searching web...",
        "web_fetch": "Fetching page...",
        "running": "Running...",
        "done": "Done!",
        "grep": "grep",
        "glob": "glob",
        "status_agents": "Agents",
        "status_working": "Working",
        "status_tasks": "Tasks",
        # Intro / outro
        "lights_on": "Lights on!",
        "greet_1": "Good morning!",
        "greet_2": "Hey there!",
        "greet_3": "Ready to work!",
        "lets_go": "Let's go!",
        "bye_1": "See you tomorrow!",
        "bye_2": "Great work today!",
        "bye_3": "Good night!",
        "last_one": "I'll get the lights",
        "goodbye": "Bye bye!",
        "opening": "Opening...",
        "closed": "See you next time!",
        # Watercooler chat
        "chat_1": "Nice weather!",
        "chat_2": "How's it going?",
        "chat_3": "Coffee break?",
        "chat_4": "Any plans later?",
        # High-five
        "highfive": "High five!",
        # Easter eggs
        "pizza": "Pizza time!",
        "cat": "Meow~",
        "sleepy": "Zzz...",
        "music": "La la la~",
        "stretch": "*stretch*",
        # Idle chatter
        "idle_1": "Need more RAM...",
        "idle_2": "Is it Friday yet?",
        "idle_3": "Bugs everywhere!",
        "idle_4": "Ship it!",
        "idle_5": "LGTM",
        "idle_6": "git push --force",
        "idle_7": "Stack Overflow...",
        "idle_8": "Works on my machine",
        # Plan mode
        "plan_gather": "Meeting time!",
        "plan_writing": "Let me plan...",
        "plan_thinking_1": "Hmm...",
        "plan_thinking_2": "I see...",
        "plan_ready": "Plan ready!",
        "plan_wrap_up": "Let's do it!",
        "plan_mode_status": "Planning...",
        # Office levels
        "office_upgrade": "Level up!",
        "office_auto": "Auto",
        "office_garage": "Garage",
        "office_home_office": "Home Office",
        "office_small_office": "Small Office",
        "office_growing_office": "Growing Office",
        "office_studio": "Studio",
        "office_creative_studio": "Creative Studio",
        "office_tech_company": "Tech Company",
        "office_big_tech": "Big Tech",
        "office_enterprise": "Enterprise",
        "office_dream_office": "Dream Office",
        # Furniture names (for upgrade pop-in labels)
        "furn_bookshelf": "+Bookshelf!",
        "furn_trophy": "+Trophy Case!",
        "furn_arcade": "+Arcade!",
        "furn_sofa": "+Sofa!",
        "furn_server": "+Server Rack!",
        "furn_plant": "+Plant!",
        "furn_whiteboard": "+Whiteboard!",
        "furn_watercooler": "+Watercooler!",
        "furn_gold_wall": "+Trophy Wall!",
        "furn_bar": "+Bar!",
        "furn_bike": "+Spin Bike!",
        # Furniture interaction bubbles
        "furn_sofa_1": "*relax*",
        "furn_sofa_2": "So comfy~",
        "furn_arcade_1": "High score!",
        "furn_arcade_2": "Game over!",
        "furn_bar_1": "Cheers!",
        "furn_bar_2": "*sip*",
        "furn_bike_1": "*pedaling*",
        "furn_bike_2": "Burn!",
        "furn_book_1": "Hmm...",
        "furn_book_2": "Interesting...",
        "furn_server_1": "All green",
        "furn_server_2": "CPU: 99%!",
        "furn_sofa_3": "*snore*",
        "furn_sofa_4": "5 more min...",
        "furn_arcade_3": "Insert coin!",
        "furn_arcade_4": "COMBO x3!",
        "furn_bar_3": "One more!",
        "furn_bar_4": "*hic*",
        "furn_bike_3": "No pain no gain!",
        "furn_bike_4": "Legs day!",
        "furn_book_3": "Good read!",
        "furn_book_4": "*page flip*",
        "furn_server_3": "Disk full!",
        "furn_server_4": "Reboot time",
        "furn_coffee_1": "Need caffeine!",
        "furn_coffee_2": "Mmm fresh brew",
        "furn_coffee_3": "My 3rd cup...",
        "furn_trophy_1": "We earned this!",
        "furn_trophy_2": "*admire*",
        "furn_trophy_3": "The glory days",
        "furn_plant_1": "*water*",
        "furn_plant_2": "Growing well~",
        "furn_plant_3": "Is it drooping?",
        "furn_wb_1": "Good plan!",
        "furn_wb_2": "*erase erase*",
        "furn_wb_3": "TODO: ...",
        "furn_wc_1": "*gossip*",
        "furn_wc_2": "Did you hear?",
        "furn_wc_3": "So anyway...",
        "furn_door_1": "*peek outside*",
        "furn_door_2": "Fresh air~",
        # Contractor lifecycle
        "agent_intro": "I'm here.",
        "agent_setup": "Setting up...",
        "agent_packing": "Packing up...",
        "agent_farewell": "Done, bye!",
        # Power-up (universal scream — same in all languages)
        "powerup_scream": "HAAA!!!!",
        # Agent Smith easter egg lines (English movie quotes in all languages)
        "smith_clone": "Me, me, me...",
        "smith_fight": "Mr. Anderson...",
        "smith_neo": "My name is Neo!",
        "smith_bullet": "Dodge this.",
        "smith_whoa": "Whoa.",
        "smith_handshake": "Good fight.",
        # New expression states
        "stretch_yawn": "Ahhh~",
        "sleepy_1": "So sleepy...",
        "sleepy_2": "5 more min...",
        "excited_1": "On fire!",
        "excited_2": "Streak!",
        "frustrated_1": "!@#$%!",
        "frustrated_2": "Why?!",
        "frustrated_3": "Bug...",
        "highfive_1": "Nice!",
        "reading_1": "Hmm...",
        "reading_2": "I see...",
        "snack_1": "*munch*",
        "snack_2": "Yummy~",
        "snack_3": "Snack time!",
        # Tool reaction prefixes (prepended to tool descriptions)
        "react_1": "Roger!",
        "react_2": "On it~",
        "react_3": "Let's go!",
        "react_4": "Ugh, fine...",
        "react_5": "Easy peasy!",
        "react_6": "Here we go!",
        "react_7": "Hmm okay...",
        "react_8": "Yessir!",
        "react_9": "Again?!",
        "react_10": "No prob!",
        "react_11": "Sigh...",
        "react_12": "Watch this!",
    },
    "ja": {
        "editing": "編集中",
        "writing": "書込中",
        "reading": "読込中",
        "searching": "検索中...",
        "finding": "探索中...",
        "backup": "応援を呼ぶ！",
        "web_search": "Web検索中...",
        "web_fetch": "取得中...",
        "running": "実行中...",
        "done": "完了！",
        "grep": "検索",
        "glob": "探索",
        "status_agents": "エージェント",
        "status_working": "作業中",
        "status_tasks": "タスク",
        "lights_on": "電気つけるよ！",
        "greet_1": "おはよう！",
        "greet_2": "やあ！",
        "greet_3": "頑張ろう！",
        "lets_go": "さあ始めよう！",
        "bye_1": "また明日！",
        "bye_2": "お疲れ様！",
        "bye_3": "おやすみ！",
        "last_one": "電気消すね",
        "goodbye": "バイバイ！",
        "opening": "開店中...",
        "closed": "またね！",
        "chat_1": "いい天気！",
        "chat_2": "調子どう？",
        "chat_3": "休憩する？",
        "chat_4": "今日の予定は？",
        "highfive": "ハイタッチ！",
        "pizza": "ピザだ！",
        "cat": "ニャー~",
        "sleepy": "Zzz...",
        "music": "ラララ~",
        "stretch": "*伸び*",
        "idle_1": "メモリ足りない...",
        "idle_2": "金曜日まだ？",
        "idle_3": "バグだらけ！",
        "idle_4": "出荷だ！",
        "idle_5": "LGTM",
        "idle_6": "git push --force",
        "idle_7": "ググるか...",
        "idle_8": "手元では動く",
        "plan_gather": "会議だ！",
        "plan_writing": "計画中...",
        "plan_thinking_1": "ふむ...",
        "plan_thinking_2": "なるほど...",
        "plan_ready": "計画完了！",
        "plan_wrap_up": "やるぞ！",
        "plan_mode_status": "計画中...",
        "office_upgrade": "レベルアップ！",
        "office_auto": "自動",
        "office_garage": "ガレージ",
        "office_home_office": "ホームオフィス",
        "office_small_office": "小さなオフィス",
        "office_growing_office": "成長中オフィス",
        "office_studio": "スタジオ",
        "office_creative_studio": "クリエイティブスタジオ",
        "office_tech_company": "テック企業",
        "office_big_tech": "大手テック",
        "office_enterprise": "エンタープライズ",
        "office_dream_office": "ドリームオフィス",
        "furn_bookshelf": "+本棚！",
        "furn_trophy": "+トロフィー！",
        "furn_arcade": "+アーケード！",
        "furn_sofa": "+ソファ！",
        "furn_server": "+サーバー！",
        "furn_plant": "+植物！",
        "furn_whiteboard": "+ホワイトボード！",
        "furn_watercooler": "+ウォーターサーバー！",
        "furn_gold_wall": "+トロフィーウォール！",
        "furn_bar": "+バー！",
        "furn_bike": "+フィットネスバイク！",
        # Furniture interaction bubbles
        "furn_sofa_1": "*リラックス*",
        "furn_sofa_2": "快適〜",
        "furn_arcade_1": "ハイスコア！",
        "furn_arcade_2": "ゲームオーバー！",
        "furn_bar_1": "乾杯！",
        "furn_bar_2": "*ゴクゴク*",
        "furn_bike_1": "*ペダリング*",
        "furn_bike_2": "バーン！",
        "furn_book_1": "ふむ...",
        "furn_book_2": "面白い...",
        "furn_server_1": "オール正常",
        "furn_server_2": "CPU: 99%!",
        "furn_sofa_3": "*ぐう*",
        "furn_sofa_4": "あと5分...",
        "furn_arcade_3": "コイン投入！",
        "furn_arcade_4": "コンボ×3！",
        "furn_bar_3": "もう一杯！",
        "furn_bar_4": "*ひっく*",
        "furn_bike_3": "限界突破！",
        "furn_bike_4": "レッグデー！",
        "furn_book_3": "名著だ！",
        "furn_book_4": "*ぺらぺら*",
        "furn_server_3": "ディスク満杯！",
        "furn_server_4": "再起動の時間",
        "furn_coffee_1": "カフェイン！",
        "furn_coffee_2": "いい香り〜",
        "furn_coffee_3": "3杯目...",
        "furn_trophy_1": "勝ち取った！",
        "furn_trophy_2": "*うっとり*",
        "furn_trophy_3": "輝かしい日々",
        "furn_plant_1": "*水やり*",
        "furn_plant_2": "元気に育って",
        "furn_plant_3": "元気ないかな?",
        "furn_wb_1": "いい計画！",
        "furn_wb_2": "*消す消す*",
        "furn_wb_3": "TODO: ...",
        "furn_wc_1": "*ヒソヒソ*",
        "furn_wc_2": "聞いた？",
        "furn_wc_3": "それでね...",
        "furn_door_1": "*外を覗く*",
        "furn_door_2": "新鮮な空気〜",
        "agent_intro": "I'm here.",
        "agent_setup": "準備中...",
        "agent_packing": "片付け中...",
        "agent_farewell": "完了、お先に！",
        "powerup_scream": "HAAA!!!!",
        "smith_clone": "Me, me, me...",
        "smith_fight": "Mr. Anderson...",
        "smith_neo": "My name is Neo!",
        "smith_bullet": "Dodge this.",
        "smith_whoa": "Whoa.",
        "smith_handshake": "Good fight.",
        # New expression states
        "stretch_yawn": "あぁ〜",
        "sleepy_1": "眠い...",
        "sleepy_2": "あと5分...",
        "excited_1": "絶好調！",
        "excited_2": "連続！",
        "frustrated_1": "くそっ！",
        "frustrated_2": "なぜ?!",
        "frustrated_3": "バグ...",
        "highfive_1": "ナイス！",
        "reading_1": "ふむ...",
        "reading_2": "なるほど",
        "snack_1": "*もぐもぐ*",
        "snack_2": "美味い～",
        "snack_3": "おやつ！",
        "react_1": "了解！",
        "react_2": "やるぞ～",
        "react_3": "いくぞ！",
        "react_4": "えー...まぁ",
        "react_5": "余裕！",
        "react_6": "よし！",
        "react_7": "ん、OK",
        "react_8": "承知！",
        "react_9": "また？！",
        "react_10": "任せて！",
        "react_11": "はぁ...",
        "react_12": "見てて！",
    },
    "zh": {
        "editing": "編輯中",
        "writing": "寫入中",
        "reading": "讀取中",
        "searching": "搜尋中...",
        "finding": "尋找中...",
        "backup": "呼叫支援！",
        "web_search": "搜尋網頁...",
        "web_fetch": "擷取頁面...",
        "running": "執行中...",
        "done": "完成！",
        "grep": "搜尋",
        "glob": "尋找",
        "status_agents": "小精靈",
        "status_working": "工作中",
        "status_tasks": "任務",
        "lights_on": "開燈！",
        "greet_1": "早安！",
        "greet_2": "嗨！",
        "greet_3": "準備開工！",
        "lets_go": "開工囉！",
        "bye_1": "明天見！",
        "bye_2": "辛苦了！",
        "bye_3": "晚安！",
        "last_one": "我來關燈",
        "goodbye": "下班囉！",
        "opening": "開門中...",
        "closed": "下次見！",
        "chat_1": "天氣真好！",
        "chat_2": "還順利嗎？",
        "chat_3": "喝杯咖啡？",
        "chat_4": "等等有什麼計劃？",
        "highfive": "擊掌！",
        "pizza": "披薩來了！",
        "cat": "喵~",
        "sleepy": "Zzz...",
        "music": "啦啦啦~",
        "stretch": "*伸懶腰*",
        "idle_1": "記憶體不夠...",
        "idle_2": "週五還沒到？",
        "idle_3": "到處都是 bug！",
        "idle_4": "直接上線！",
        "idle_5": "LGTM",
        "idle_6": "git push --force",
        "idle_7": "問 AI 好了...",
        "idle_8": "我電腦可以跑",
        "plan_gather": "開會了！",
        "plan_writing": "規劃中...",
        "plan_thinking_1": "嗯...",
        "plan_thinking_2": "原來如此...",
        "plan_ready": "計畫完成！",
        "plan_wrap_up": "開工！",
        "plan_mode_status": "規劃中...",
        "office_upgrade": "升級了！",
        "office_auto": "自動",
        "office_garage": "車庫",
        "office_home_office": "居家辦公",
        "office_small_office": "小辦公室",
        "office_growing_office": "成長中",
        "office_studio": "工作室",
        "office_creative_studio": "創意工作室",
        "office_tech_company": "科技公司",
        "office_big_tech": "大企業",
        "office_enterprise": "跨國企業",
        "office_dream_office": "夢幻辦公室",
        "furn_bookshelf": "+書架！",
        "furn_trophy": "+獎盃櫃！",
        "furn_arcade": "+街機台！",
        "furn_sofa": "+沙發！",
        "furn_server": "+伺服器！",
        "furn_plant": "+植物！",
        "furn_whiteboard": "+白板！",
        "furn_watercooler": "+飲水機！",
        "furn_gold_wall": "+獎盃牆！",
        "furn_bar": "+吧檯！",
        "furn_bike": "+飛輪！",
        # Furniture interaction bubbles
        "furn_sofa_1": "*放鬆*",
        "furn_sofa_2": "好舒服~",
        "furn_arcade_1": "最高分！",
        "furn_arcade_2": "遊戲結束！",
        "furn_bar_1": "乾杯！",
        "furn_bar_2": "*喝一口*",
        "furn_bike_1": "*踩踏中*",
        "furn_bike_2": "燃燒！",
        "furn_book_1": "嗯...",
        "furn_book_2": "有趣...",
        "furn_server_1": "一切正常",
        "furn_server_2": "CPU: 99%!",
        "furn_sofa_3": "*呼呼*",
        "furn_sofa_4": "再5分鐘...",
        "furn_arcade_3": "投幣！",
        "furn_arcade_4": "COMBO x3!",
        "furn_bar_3": "再一杯！",
        "furn_bar_4": "*嗝*",
        "furn_bike_3": "沒有痛苦！",
        "furn_bike_4": "練腿日！",
        "furn_book_3": "好書！",
        "furn_book_4": "*翻頁*",
        "furn_server_3": "磁碟滿了！",
        "furn_server_4": "該重開了",
        "furn_coffee_1": "需要咖啡因！",
        "furn_coffee_2": "好香~",
        "furn_coffee_3": "第三杯了...",
        "furn_trophy_1": "我們贏了！",
        "furn_trophy_2": "*欣賞*",
        "furn_trophy_3": "光榮的日子",
        "furn_plant_1": "*澆水*",
        "furn_plant_2": "長得好~",
        "furn_plant_3": "怎麼有點垂？",
        "furn_wb_1": "好計畫！",
        "furn_wb_2": "*擦擦擦*",
        "furn_wb_3": "TODO: ...",
        "furn_wc_1": "*八卦*",
        "furn_wc_2": "你聽說了嗎？",
        "furn_wc_3": "話說回來...",
        "furn_door_1": "*偷看外面*",
        "furn_door_2": "新鮮空氣~",
        "agent_intro": "I'm here.",
        "agent_setup": "架設中...",
        "agent_packing": "收拾中...",
        "agent_farewell": "完成，先走了！",
        "powerup_scream": "HAAA!!!!",
        "smith_clone": "Me, me, me...",
        "smith_fight": "Mr. Anderson...",
        "smith_neo": "My name is Neo!",
        "smith_bullet": "Dodge this.",
        "smith_whoa": "Whoa.",
        "smith_handshake": "Good fight.",
        # New expression states
        "stretch_yawn": "啊～",
        "sleepy_1": "好睏...",
        "sleepy_2": "再5分鐘...",
        "excited_1": "超順！",
        "excited_2": "連勝！",
        "frustrated_1": "可惡！",
        "frustrated_2": "為什麼?!",
        "frustrated_3": "Bug...",
        "highfive_1": "讚！",
        "reading_1": "嗯...",
        "reading_2": "原來如此",
        "snack_1": "*嚼嚼*",
        "snack_2": "好吃～",
        "snack_3": "零食時間！",
        "react_1": "收到！",
        "react_2": "來囉～",
        "react_3": "衝啊！",
        "react_4": "唉...好吧",
        "react_5": "小事一樁！",
        "react_6": "開工！",
        "react_7": "嗯...OK",
        "react_8": "遵命！",
        "react_9": "又來？！",
        "react_10": "交給我！",
        "react_11": "哎...",
        "react_12": "看好了！",
    },
    "ko": {
        "editing": "편집 중",
        "writing": "작성 중",
        "reading": "읽는 중",
        "searching": "검색 중...",
        "finding": "찾는 중...",
        "backup": "지원 요청!",
        "web_search": "웹 검색 중...",
        "web_fetch": "페이지 가져오는 중...",
        "running": "실행 중...",
        "done": "완료!",
        "grep": "검색",
        "glob": "찾기",
        "status_agents": "에이전트",
        "status_working": "작업 중",
        "status_tasks": "작업",
        "lights_on": "불 켜요!",
        "greet_1": "좋은 아침!",
        "greet_2": "안녕!",
        "greet_3": "화이팅!",
        "lets_go": "시작하자!",
        "bye_1": "내일 봐!",
        "bye_2": "수고했어요!",
        "bye_3": "잘 자요!",
        "last_one": "불 끌게요",
        "goodbye": "퇴근이다!",
        "opening": "오픈 중...",
        "closed": "다음에 봐요!",
        "chat_1": "날씨 좋다!",
        "chat_2": "잘 지내?",
        "chat_3": "커피 마실래?",
        "chat_4": "오늘 계획 있어?",
        "highfive": "하이파이브!",
        "pizza": "피자 왔다!",
        "cat": "야옹~",
        "sleepy": "Zzz...",
        "music": "랄랄라~",
        "stretch": "*기지개*",
        "idle_1": "메모리 부족...",
        "idle_2": "금요일 아직?",
        "idle_3": "버그 투성이!",
        "idle_4": "배포하자!",
        "idle_5": "LGTM",
        "idle_6": "git push --force",
        "idle_7": "구글링 중...",
        "idle_8": "내 PC에선 됨",
        "plan_gather": "회의 시작!",
        "plan_writing": "계획 중...",
        "plan_thinking_1": "음...",
        "plan_thinking_2": "그렇군...",
        "plan_ready": "계획 완료!",
        "plan_wrap_up": "시작하자!",
        "plan_mode_status": "계획 중...",
        "office_upgrade": "레벨 업!",
        "office_auto": "자동",
        "office_garage": "차고",
        "office_home_office": "홈오피스",
        "office_small_office": "소규모 사무실",
        "office_growing_office": "성장 사무실",
        "office_studio": "스튜디오",
        "office_creative_studio": "크리에이티브 스튜디오",
        "office_tech_company": "테크 기업",
        "office_big_tech": "빅테크",
        "office_enterprise": "엔터프라이즈",
        "office_dream_office": "드림 오피스",
        "furn_bookshelf": "+책장!",
        "furn_trophy": "+트로피!",
        "furn_arcade": "+아케이드!",
        "furn_sofa": "+소파!",
        "furn_server": "+서버 랙!",
        "furn_plant": "+식물!",
        "furn_whiteboard": "+화이트보드!",
        "furn_watercooler": "+정수기!",
        "furn_gold_wall": "+트로피 월!",
        "furn_bar": "+바!",
        "furn_bike": "+스핀바이크!",
        # Furniture interaction bubbles
        "furn_sofa_1": "*릴랙스*",
        "furn_sofa_2": "편해~",
        "furn_arcade_1": "최고 점수!",
        "furn_arcade_2": "게임 오버!",
        "furn_bar_1": "건배!",
        "furn_bar_2": "*한 모금*",
        "furn_bike_1": "*페달링*",
        "furn_bike_2": "불타올라!",
        "furn_book_1": "흠...",
        "furn_book_2": "흥미롭다...",
        "furn_server_1": "정상 작동",
        "furn_server_2": "CPU: 99%!",
        "furn_sofa_3": "*쿨쿨*",
        "furn_sofa_4": "5분만 더...",
        "furn_arcade_3": "코인 투입!",
        "furn_arcade_4": "콤보×3!",
        "furn_bar_3": "한잔 더!",
        "furn_bar_4": "*딸꾹*",
        "furn_bike_3": "고통없이!",
        "furn_bike_4": "레그데이!",
        "furn_book_3": "명작이다!",
        "furn_book_4": "*철컥*",
        "furn_server_3": "디스크 꽉!",
        "furn_server_4": "재부팅 시간",
        "furn_coffee_1": "카페인 필요!",
        "furn_coffee_2": "좋은 향~",
        "furn_coffee_3": "세번째 잔...",
        "furn_trophy_1": "우리가 해냈다!",
        "furn_trophy_2": "*감상*",
        "furn_trophy_3": "영광의 날들",
        "furn_plant_1": "*물주기*",
        "furn_plant_2": "잘 자라네~",
        "furn_plant_3": "시들었나?",
        "furn_wb_1": "좋은 계획!",
        "furn_wb_2": "*지우개*",
        "furn_wb_3": "TODO: ...",
        "furn_wc_1": "*수근수근*",
        "furn_wc_2": "들었어?",
        "furn_wc_3": "그래서...",
        "furn_door_1": "*밖을 엿보기*",
        "furn_door_2": "신선한 공기~",
        "agent_intro": "I'm here.",
        "agent_setup": "설치 중...",
        "agent_packing": "정리 중...",
        "agent_farewell": "완료, 먼저 갈게요!",
        "powerup_scream": "HAAA!!!!",
        "smith_clone": "Me, me, me...",
        "smith_fight": "Mr. Anderson...",
        "smith_neo": "My name is Neo!",
        "smith_bullet": "Dodge this.",
        "smith_whoa": "Whoa.",
        "smith_handshake": "Good fight.",
        # New expression states
        "stretch_yawn": "아～",
        "sleepy_1": "졸려...",
        "sleepy_2": "5분만 더...",
        "excited_1": "불타오른다!",
        "excited_2": "연속!",
        "frustrated_1": "젠장!",
        "frustrated_2": "왜?!",
        "frustrated_3": "버그...",
        "highfive_1": "나이스!",
        "reading_1": "음...",
        "reading_2": "그렇구나",
        "snack_1": "*냠냠*",
        "snack_2": "맛있다~",
        "snack_3": "간식시간!",
        "react_1": "알겠어!",
        "react_2": "간다～",
        "react_3": "가자!",
        "react_4": "에이...알겠어",
        "react_5": "쉽지!",
        "react_6": "시작!",
        "react_7": "음...OK",
        "react_8": "넵!",
        "react_9": "또?!",
        "react_10": "맡겨!",
        "react_11": "휴...",
        "react_12": "봐봐!",
    },
}

# Module-level language setting
_current_lang: str = "en"


def set_language(lang: str) -> None:
    """Set the display language."""
    global _current_lang
    if lang in STRINGS:
        _current_lang = lang


def get_language() -> str:
    return _current_lang


def t(key: str) -> str:
    """Get translated string for current language."""
    return STRINGS.get(_current_lang, STRINGS["en"]).get(
        key, STRINGS["en"].get(key, key)
    )


def display_width(s: str) -> int:
    """Return terminal display width of a string.

    CJK/fullwidth/emoji = 2 columns, combining marks/variation selectors = 0, others = 1.
    """
    w = 0
    prev_cw = 0  # width of the last non-zero-width char
    for ch in s:
        cp = ord(ch)
        if cp == 0xFE0F or cp == 0xFE0E:
            # Variation selector: promote previous char to 2 if it was only 1
            if prev_cw == 1:
                w += 1
                prev_cw = 2
            continue
        cat = unicodedata.category(ch)
        if cat.startswith("M") or cat == "Cc":
            continue  # combining marks and control chars (\n, \t, etc.)
        eaw = unicodedata.east_asian_width(ch)
        if eaw in ("W", "F"):
            prev_cw = 2
            w += 2
        else:
            prev_cw = 1
            w += 1
    return w


def _pad_to_width(s: str, target_w: int) -> str:
    """Pad string with spaces to reach target display width."""
    current = display_width(s)
    if current >= target_w:
        return s
    return s + " " * (target_w - current)


def _wrap_words(text: str, max_display_w: int) -> list[str]:
    """Word-wrap text respecting display width of CJK characters.

    Explicit \\n in text forces a line break.
    """
    # Split on explicit newlines first, then wrap each paragraph
    paragraphs = text.split("\n")
    lines: list[str] = []
    for para in paragraphs:
        words = para.split()
        if not words:
            lines.append(" ")
            continue
        current = ""
        for word in words:
            candidate = f"{current} {word}".strip() if current else word
            if current and display_width(candidate) > max_display_w:
                lines.append(current)
                current = word
            else:
                current = candidate
        if current:
            lines.append(current)
    return lines or [" "]


def make_speech_bubble(text: str, max_width: int = 20) -> list[str]:
    """Render a speech bubble. Returns list of lines."""
    text = text[:60]  # hard cap
    if max_width < 10:
        max_width = 10
    inner_w = min(max_width - 4, max(display_width(text), 4))

    lines = _wrap_words(text, inner_w)

    box_w = max(display_width(line) for line in lines) + 2
    result = ["┌" + "─" * box_w + "┐"]
    for line in lines:
        padded = _pad_to_width(line, box_w - 2)
        result.append("│ " + padded + " │")
    result.append("└" + "─" * (box_w // 2) + "┬" + "─" * (box_w - box_w // 2 - 1) + "┘")
    result.append(" " * (box_w // 2 + 1) + "╰")
    return result


def make_thought_bubble(text: str, max_width: int = 20) -> list[str]:
    """Render a thought bubble. Returns list of lines."""
    text = text[:60]
    if max_width < 10:
        max_width = 10
    inner_w = min(max_width - 4, max(display_width(text), 4))

    lines = _wrap_words(text, inner_w)

    box_w = max(display_width(line) for line in lines) + 2
    result = ["╭" + "─" * box_w + "╮"]
    for line in lines:
        padded = _pad_to_width(line, box_w - 2)
        result.append("│ " + padded + " │")
    result.append("╰" + "─" * (box_w // 2) + "○" + "─" * (box_w - box_w // 2 - 1) + "╯")
    result.append(" " * (box_w // 2 + 1) + "o")
    result.append(" " * (box_w // 2 + 1) + "∘")
    return result


def shorten_path(path: str) -> str:
    """Shorten a file path for display — keep last 2 segments."""
    if not path:
        return ""
    parts = path.replace("\\", "/").split("/")
    if len(parts) <= 2:
        return path
    return "/".join(parts[-2:])


_REACT_KEYS = [f"react_{i}" for i in range(1, 13)]


def _random_react() -> str:
    """Return a random reaction prefix in the current language."""
    import random
    return t(random.choice(_REACT_KEYS))


def describe_tool_event(tool: str, tool_input: dict) -> tuple[str, str]:
    """Return (short_description, bubble_type) for a tool event.

    Each description is prefixed with a random reaction line to add personality.
    bubble_type is 'speech' or 'thought'.
    """
    fp = shorten_path(tool_input.get("file_path", ""))
    raw_cmd = tool_input.get("command", "")
    cmd = raw_cmd[:40] + ("..." if len(raw_cmd) > 40 else "")
    raw_pat = tool_input.get("pattern", "")
    pattern = raw_pat[:30] + ("..." if len(raw_pat) > 30 else "")
    raw_desc = tool_input.get("description", "")
    desc = raw_desc[:40] + ("..." if len(raw_desc) > 40 else "")

    react = _random_react()

    mapping = {
        "Bash": (f"{react}\n{cmd or desc or t('running')}", "speech"),
        "Edit": (f"{react}\n{t('editing')} {fp}" if fp else f"{react}\n{t('editing')}...", "speech"),
        "Write": (f"{react}\n{t('writing')} {fp}" if fp else f"{react}\n{t('writing')}...", "speech"),
        "Read": (f"{react}\n{t('reading')} {fp}" if fp else f"{react}\n{t('reading')}...", "thought"),
        "Grep": (f"{react}\n{t('grep')}: {pattern}" if pattern else f"{react}\n{t('searching')}", "thought"),
        "Glob": (f"{react}\n{t('glob')}: {pattern}" if pattern else f"{react}\n{t('finding')}", "thought"),
        "Agent": (f"{react}\n{t('backup')}", "speech"),
        "WebSearch": (f"{react}\n{t('web_search')}", "thought"),
        "WebFetch": (f"{react}\n{t('web_fetch')}", "thought"),
        "Skill": (f"{react}\n/{tool_input.get('skill', '') or tool_input.get('name', 'skill')}", "speech"),
    }

    default = (f"{tool}...", "speech")
    return mapping.get(tool, default)
