"""Intro (startup) and Outro (shutdown) animation sequences."""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import TYPE_CHECKING

from .bubbles import t
from .characters import Character, State
from .sprites import (
    LEVEL_UP_BIG,
    LEVEL_UP_SMALL,
    MEETING_TABLE,
    THEMES,
    WHITEBOARD_BLANK,
    WHITEBOARD_PLAN,
    WHITEBOARD_WRITING,
    FurnitureItem,
)

if TYPE_CHECKING:
    from .scene import Scene


# ---------------------------------------------------------------------------
# Intro stages
# ---------------------------------------------------------------------------

class IntroStage(Enum):
    DARK = auto()          # Dark office, nothing visible
    FIRST_AGENT = auto()   # First elf enters, walks to light switch
    LIGHTS_ON = auto()     # Light radius expands from center
    AGENTS_ARRIVE = auto() # Remaining elves enter one by one
    SETTLE = auto()        # Everyone reaches their desk
    DONE = auto()          # Intro complete


@dataclass
class IntroSequence:
    """Manages the startup intro animation."""
    scene: Scene
    stage: IntroStage = IntroStage.DARK
    elapsed: float = 0.0
    stage_elapsed: float = 0.0

    # Lighting
    light_radius: float | None = 0.0
    light_center: tuple[float, float] = (0.0, 0.0)

    # Character scheduling
    _char_count: int = 0
    _next_char_idx: int = 1  # 0 = first agent (light-switcher)
    _next_spawn_at: float = 0.0
    _all_spawned: bool = False

    is_complete: bool = False

    def start(self) -> None:
        """Initialize the intro sequence."""
        self.stage = IntroStage.DARK
        self.elapsed = 0.0
        self.stage_elapsed = 0.0
        self.light_radius = 0.0

        w, h = self.scene.width, self.scene.height
        # Light switch near center of the office
        self.light_center = (w * 0.4, h * 0.4)

        # How many characters to spawn — respect level's elf_count
        from .levels import LEVEL_BY_KEY, LEVEL_DEFS
        level_def = LEVEL_BY_KEY.get(self.scene.office_level, LEVEL_DEFS[0])
        max_by_width = 2 if w < 40 else (3 if w < 55 else 4)
        self._char_count = min(level_def.elf_count, max_by_width)
        self._next_char_idx = 1
        self._next_spawn_at = 0.0
        self._all_spawned = self._char_count <= 1  # already done if only 1 elf

        # Spawn first character at the door
        self._spawn_character(0)

    def tick(self, dt: float) -> None:
        """Advance intro by one frame."""
        self.elapsed += dt
        self.stage_elapsed += dt

        if self.stage == IntroStage.DARK:
            # Stay dark for 1.5 seconds, then open door
            if self.stage_elapsed >= 1.5:
                self.scene.open_door()
                self._advance(IntroStage.FIRST_AGENT)

        elif self.stage == IntroStage.FIRST_AGENT:
            # First agent walks toward light switch
            first = self._first_char()
            if first and first.state == State.IDLE:
                # Arrived at switch position — start lights
                first.bubble_text = t("lights_on")
                first.bubble_type = "speech"
                first.bubble_ttl = 2.0
                self._advance(IntroStage.LIGHTS_ON)
            elif self.stage_elapsed >= 8.0:
                # Timeout fallback
                self._advance(IntroStage.LIGHTS_ON)

        elif self.stage == IntroStage.LIGHTS_ON:
            # Expand light radius
            max_r = math.sqrt(self.scene.width**2 + self.scene.height**2)
            self.light_radius = min(
                max_r,
                (self.light_radius or 0) + dt * max_r * 0.6,
            )
            if self.light_radius >= max_r:
                self.light_radius = None  # fully lit
                self.scene.boot_monitors()
                # Send first agent to their desk
                first = self._first_char()
                if first and self.scene._desk_positions:
                    dx, dy = self.scene._desk_positions[0]
                    first.target_x = dx
                    first.target_y = dy
                    first.target_callback = None
                    first.state = State.WALKING
                self._next_spawn_at = self.elapsed + 1.0
                self._advance(IntroStage.AGENTS_ARRIVE)

        elif self.stage == IntroStage.AGENTS_ARRIVE:
            # Spawn remaining characters at intervals
            if (not self._all_spawned
                    and self._next_char_idx < self._char_count
                    and self.elapsed >= self._next_spawn_at):
                self.scene.open_door()  # open for each arrival
                self._spawn_character(self._next_char_idx)
                self._next_char_idx += 1
                self._next_spawn_at = self.elapsed + 1.8
                if self._next_char_idx >= self._char_count:
                    self._all_spawned = True

            # Check if all characters settled (or timeout after 10s)
            if self._all_spawned:
                all_settled = all(
                    c.state in (State.IDLE, State.TYPING, State.THINKING)
                    for c in self.scene.characters
                )
                if all_settled or self.stage_elapsed >= 10.0:
                    self._advance(IntroStage.SETTLE)

        elif self.stage == IntroStage.SETTLE:
            # Close door + last agent shows "let's go!"
            if self.stage_elapsed < 0.1:
                self.scene.close_door()
            if self.stage_elapsed < 0.1 and self.scene.characters:
                last = self.scene.characters[-1]
                last.bubble_text = t("lets_go")
                last.bubble_type = "speech"
                last.bubble_ttl = 2.0
            if self.stage_elapsed >= 2.0:
                self.scene._apply_protagonist_names()
                self.scene._assign_desk_names()
                self._advance(IntroStage.DONE)
                self.is_complete = True

    def _advance(self, stage: IntroStage) -> None:
        self.stage = stage
        self.stage_elapsed = 0.0

    def _first_char(self) -> Character | None:
        return self.scene.characters[0] if self.scene.characters else None

    def _spawn_character(self, idx: int) -> None:
        """Spawn character at the door and send to desk or light switch."""
        theme = THEMES.get(self.scene.theme_name, THEMES["claude"])
        names = theme["names"]
        name = names[idx] if idx < len(names) else f"Elf-{idx}"

        # Door position
        door_x, door_y = self.scene._get_door_position()

        # Assign desk position and role
        from .characters import _ROLE_CYCLE
        desk_x: float | None = None
        desk_y: float | None = None
        if self.scene._desk_positions and idx < len(self.scene._desk_positions):
            desk_x, desk_y = self.scene._desk_positions[idx]
        elif self.scene._desk_positions:
            desk_x, desk_y = random.choice(self.scene._desk_positions)

        char = Character(
            name=name,
            x=float(door_x + 2),
            y=float(door_y + 2),
            color_index=(idx % 6) + 1,
            desk_x=desk_x,
            desk_y=desk_y,
            role=_ROLE_CYCLE[idx % len(_ROLE_CYCLE)],
        )

        if idx == 0:
            # First character: walk to light switch
            sx, sy = self.light_center
            char.target_x = sx
            char.target_y = sy
            char.target_callback = None
            char.state = State.WALKING
        else:
            # Others: pause to greet, then walk to desk
            greetings = ["greet_1", "greet_2", "greet_3"]
            char.bubble_text = t(random.choice(greetings))
            char.bubble_type = "speech"
            char.bubble_ttl = 2.0
            char.state = State.GREETING
            char.state_timer = 0.0
            char.target_x = desk_x if desk_x is not None else self.scene.width / 2
            char.target_y = desk_y if desk_y is not None else self.scene.height / 2
            char.target_callback = None

        self.scene.characters.append(char)


# ---------------------------------------------------------------------------
# Outro stages
# ---------------------------------------------------------------------------

class OutroStage(Enum):
    STOP_WORK = auto()      # Everyone stops working
    SAY_GOODBYE = auto()    # Characters say bye and walk to door
    LAST_ONE = auto()       # Last character walks to light switch
    LIGHTS_OFF = auto()     # Light radius shrinks
    CLOSE_DOOR = auto()     # Final darkness, then exit
    DONE = auto()


@dataclass
class OutroSequence:
    """Manages the shutdown outro animation."""
    scene: Scene
    stage: OutroStage = OutroStage.STOP_WORK
    elapsed: float = 0.0
    stage_elapsed: float = 0.0

    light_radius: float | None = None  # None = fully lit
    light_center: tuple[float, float] = (0.0, 0.0)

    # Store Character references, not indices (avoids index drift)
    _departure_queue: list[Character] = field(default_factory=list)
    _next_depart_at: float = 0.0
    _last_char: Character | None = None

    is_complete: bool = False

    def start(self) -> None:
        """Initialize the outro sequence."""
        self.stage = OutroStage.STOP_WORK
        self.elapsed = 0.0
        self.stage_elapsed = 0.0
        self.light_radius = None  # fully lit

        w, h = self.scene.width, self.scene.height
        self.light_center = (w * 0.4, h * 0.4)

        # Stop all characters from working
        for c in self.scene.characters:
            c.busy = False
            c.current_task_id = ""
            c.target_x = None
            c.target_y = None
            c.target_callback = None
            c.state = State.IDLE
            c.state_timer = 0.0

        # Queue departure: store references, all except last
        chars = list(self.scene.characters)
        if len(chars) > 1:
            self._departure_queue = chars[:-1]
        else:
            self._departure_queue = []
        self._next_depart_at = 0.0

    def tick(self, dt: float) -> None:
        """Advance outro by one frame."""
        self.elapsed += dt
        self.stage_elapsed += dt

        if self.stage == OutroStage.STOP_WORK:
            if self.stage_elapsed < 0.1:
                self.scene.shutdown_monitors()
            if self.stage_elapsed >= 1.0:
                self._advance(OutroStage.SAY_GOODBYE)
                self._next_depart_at = self.elapsed + 0.5

        elif self.stage == OutroStage.SAY_GOODBYE:
            # Send characters to door one by one
            if (self._departure_queue
                    and self.elapsed >= self._next_depart_at):
                self.scene.open_door()
                char = self._departure_queue.pop(0)
                if not char._departed:
                    byes = ["bye_1", "bye_2", "bye_3"]
                    char.bubble_text = t(random.choice(byes))
                    char.bubble_type = "speech"
                    char.bubble_ttl = 2.0
                    door_x, door_y = self.scene._get_door_position()
                    char.target_x = float(door_x + 2)
                    char.target_y = float(door_y + 2)
                    char.target_callback = "depart"
                    char._departure_pending = True
                    char.state = State.GREETING
                    char.state_timer = 0.0
                self._next_depart_at = self.elapsed + 1.8

            # Check if all departed except last
            non_departed = [c for c in self.scene.characters if not c._departed]
            if len(non_departed) <= 1 and not self._departure_queue:
                self._last_char = non_departed[0] if non_departed else None
                self._advance(OutroStage.LAST_ONE)

        elif self.stage == OutroStage.LAST_ONE:
            # Last elf walks to door (not light switch)
            if self._last_char and self.stage_elapsed < 0.1:
                self._last_char.bubble_text = t("last_one")
                self._last_char.bubble_type = "speech"
                self._last_char.bubble_ttl = 2.5
                door_x, door_y = self.scene._get_door_position()
                self._last_char.target_x = float(door_x + 2)
                self._last_char.target_y = float(door_y + 2)
                self._last_char.target_callback = None
                self._last_char.state = State.WALKING
                self._last_char.state_timer = 0.0

            # Arrived at door → turn off lights + monitors
            if self._last_char and self._last_char.state == State.IDLE:
                self._last_char.bubble_text = t("goodbye")
                self._last_char.bubble_type = "speech"
                self._last_char.bubble_ttl = 2.0
                self.scene.shutdown_monitors()
                # Set light center at door for radial darkness from door
                door_x, door_y = self.scene._get_door_position()
                self.light_center = (float(door_x + 3), float(door_y + 2))
                max_r = math.sqrt(self.scene.width**2 + self.scene.height**2)
                self.light_radius = max_r
                self._advance(OutroStage.LIGHTS_OFF)

            if self.stage_elapsed >= 8.0:
                max_r = math.sqrt(self.scene.width**2 + self.scene.height**2)
                self.light_radius = max_r
                self._advance(OutroStage.LIGHTS_OFF)

        elif self.stage == OutroStage.LIGHTS_OFF:
            # Shrink light radius from door position
            max_r = math.sqrt(self.scene.width**2 + self.scene.height**2)
            self.light_radius = max(
                0.0,
                (self.light_radius or max_r) - dt * max_r * 0.5,
            )

            # Last char exits through door
            if self._last_char and self.stage_elapsed < 0.1:
                # Already at door — just mark as departed
                self._last_char._departed = True
                self._last_char = None

            if self.light_radius <= 0.0:
                self.light_radius = 0.0
                self._advance(OutroStage.CLOSE_DOOR)

        elif self.stage == OutroStage.CLOSE_DOOR:
            if self.stage_elapsed < 0.1:
                self.scene.door_state = "closing"
                self.scene.door_timer = 0.0
            if self.scene.door_state == "closed" or self.stage_elapsed >= 2.0:
                self.scene.door_state = "closed"
                self._advance(OutroStage.DONE)
                self.is_complete = True

    def _advance(self, stage: OutroStage) -> None:
        self.stage = stage
        self.stage_elapsed = 0.0


# ---------------------------------------------------------------------------
# Plan Mode stages
# ---------------------------------------------------------------------------

class PlanStage(Enum):
    STOP_WORK = auto()   # Everyone stops working
    SETUP = auto()       # Place meeting table + whiteboard
    GATHER = auto()      # Characters walk to meeting area
    PLANNING = auto()    # Opus writes on whiteboard
    DISCUSS = auto()     # Team discusses the plan
    DONE = auto()


@dataclass
class PlanSequence:
    """Manages the plan-mode 'war room' enter animation."""
    scene: Scene
    stage: PlanStage = PlanStage.STOP_WORK
    elapsed: float = 0.0
    stage_elapsed: float = 0.0

    # Temporary furniture references
    _meeting_table: FurnitureItem | None = None
    _whiteboard: FurnitureItem | None = None

    # Character roles
    _opus: Character | None = None
    _others: list[Character] = field(default_factory=list)

    # Gather scheduling
    _gather_queue: list[Character] = field(default_factory=list)
    _next_gather_at: float = 0.0
    _gather_started: bool = False

    # Whiteboard transition tracking
    _wb_phase: int = 0  # 0=blank, 1=writing, 2=plan
    _planning_started: bool = False
    _discuss_started: bool = False
    _plan_ready_shown: bool = False

    # Saved task state for in-flight tools (restored on exit)
    _saved_tasks: dict = field(default_factory=dict)

    is_complete: bool = False

    def start(self) -> None:
        """Initialize the plan sequence."""
        self.stage = PlanStage.STOP_WORK
        self.elapsed = 0.0
        self.stage_elapsed = 0.0
        self._wb_phase = 0
        self._planning_started = False
        self._discuss_started = False
        self._plan_ready_shown = False

        # Identify opus (lead) and others — exclude Agent Smith contractors
        if self.scene.characters:
            self._opus = self.scene.characters[0]
            self._others = [c for c in self.scene.characters[1:] if not c.is_agent]
        else:
            self._opus = None
            self._others = []

        # Save in-flight task identity so tool_post can still match
        self._saved_tasks = {}
        for c in self.scene.characters:
            if c.busy and c.current_task_id:
                self._saved_tasks[c.name] = {
                    "task_id": c.current_task_id,
                    "was_agent": c.is_agent,
                }

        # Pause characters visually but preserve task ownership
        for c in self.scene.characters:
            c.target_x = None
            c.target_y = None
            c.target_callback = None
            c.state = State.IDLE
            c.state_timer = 0.0
            c.bubble_text = ""
            c.bubble_ttl = 0.0
            # Mark agents that were busy — departure scheduled when plan mode exits
            if c.is_agent and c.busy:
                c._plan_mode_was_busy = True

    def tick(self, dt: float) -> None:
        """Advance plan sequence by one frame."""
        self.elapsed += dt
        self.stage_elapsed += dt

        if self.stage == PlanStage.STOP_WORK:
            if self.stage_elapsed >= 1.0:
                self._place_furniture()
                self._prepare_gather()
                self._advance(PlanStage.SETUP)

        elif self.stage == PlanStage.SETUP:
            if self.stage_elapsed >= 1.5:
                self._send_opus_to_whiteboard()
                self._gather_started = True
                self._next_gather_at = self.elapsed + 0.5
                self._advance(PlanStage.GATHER)

        elif self.stage == PlanStage.GATHER:
            # Send others at 1.5s intervals
            if (self._gather_queue
                    and self.elapsed >= self._next_gather_at):
                char = self._gather_queue.pop(0)
                seat = self._seats[len(self._others) - len(self._gather_queue) - 1]
                char.target_x = float(seat[0])
                char.target_y = float(seat[1])
                char.target_callback = None
                char.state = State.WALKING
                char.bubble_text = t("plan_gather")
                char.bubble_type = "speech"
                char.bubble_ttl = 2.0
                self._next_gather_at = self.elapsed + 1.5

            # Check if all settled or timeout
            all_settled = all(
                c.state in (State.IDLE, State.TYPING, State.THINKING)
                for c in self.scene.characters
            )
            if (all_settled and not self._gather_queue) or self.stage_elapsed >= 6.0:
                self._advance(PlanStage.PLANNING)

        elif self.stage == PlanStage.PLANNING:
            if not self._planning_started:
                self._planning_started = True
                if self._opus:
                    self._opus.state = State.TYPING
                    self._opus.state_timer = 0.0
                    self._opus.bubble_text = t("plan_writing")
                    self._opus.bubble_type = "speech"
                    self._opus.bubble_ttl = 3.0

            # Whiteboard transitions
            if self._wb_phase == 0 and self.stage_elapsed >= 0.3:
                self._swap_whiteboard(WHITEBOARD_WRITING)
                self._wb_phase = 1
            if self._wb_phase == 1 and self.stage_elapsed >= 1.3:
                self._swap_whiteboard(WHITEBOARD_PLAN)
                self._wb_phase = 2

            if self.stage_elapsed >= 2.0:
                self._advance(PlanStage.DISCUSS)

        elif self.stage == PlanStage.DISCUSS:
            if not self._discuss_started:
                self._discuss_started = True
                if self._others:
                    for c in self._others:
                        c.state = State.THINKING
                        c.state_timer = 0.0
                        think_key = random.choice(["plan_thinking_1", "plan_thinking_2"])
                        c.bubble_text = t(think_key)
                        c.bubble_type = "thought"
                        c.bubble_ttl = 3.0
                elif self._opus:
                    # Solo mode: lone elf thinks by themselves
                    self._opus.state = State.THINKING
                    self._opus.state_timer = 0.0
                    self._opus.bubble_text = t("plan_thinking_1")
                    self._opus.bubble_type = "thought"
                    self._opus.bubble_ttl = 2.0

            # Opus announces plan ready
            if self.stage_elapsed >= 1.0 and self._opus and not self._plan_ready_shown:
                self._plan_ready_shown = True
                self._opus.bubble_text = t("plan_ready")
                self._opus.bubble_type = "speech"
                self._opus.bubble_ttl = 2.0

            if self.stage_elapsed >= 1.5:
                self._advance(PlanStage.DONE)
                self.is_complete = True

    def _advance(self, stage: PlanStage) -> None:
        self.stage = stage
        self.stage_elapsed = 0.0

    def _place_furniture(self) -> None:
        """Place meeting table and whiteboard in the center."""
        cx = self.scene.width // 2
        cy = self.scene.height // 2

        self._meeting_table = FurnitureItem(
            name="meeting_table",
            sprite=MEETING_TABLE,
            x=cx - 7,
            y=cy,
        )
        self._whiteboard = FurnitureItem(
            name="whiteboard_plan",
            sprite=WHITEBOARD_BLANK,
            x=cx - 5,
            y=cy - 4,
        )
        self.scene.furniture.append(self._meeting_table)
        self.scene.furniture.append(self._whiteboard)

    def _prepare_gather(self) -> None:
        """Calculate seats dynamically and build gather queue."""
        cx = self.scene.width // 2
        cy = self.scene.height // 2
        n = len(self._others)

        # Base seats around the meeting table (left/right pairs, top-to-bottom)
        base_seats = [
            (cx - 8, cy + 2),   # left-bottom
            (cx + 8, cy + 2),   # right-bottom
            (cx - 8, cy - 1),   # left-top
            (cx + 8, cy - 1),   # right-top
        ]

        if n <= len(base_seats):
            self._seats = base_seats[:n]
        else:
            # Generate overflow seats in a wider ring around the table
            self._seats = list(base_seats)
            for i in range(len(base_seats), n):
                side = -1 if i % 2 == 0 else 1
                row = (i - len(base_seats)) // 2
                self._seats.append((cx + side * 12, cy - 2 + row * 3))
        self._gather_queue = list(self._others)

    def _send_opus_to_whiteboard(self) -> None:
        """Send Opus to stand beside the whiteboard."""
        if not self._opus:
            return
        cx = self.scene.width // 2
        cy = self.scene.height // 2
        self._opus.target_x = float(cx + 5)
        self._opus.target_y = float(cy - 3)
        self._opus.target_callback = None
        self._opus.state = State.WALKING

    def _swap_whiteboard(self, new_sprite: list[str]) -> None:
        """Replace the whiteboard sprite (FurnitureItem is frozen)."""
        if not self._whiteboard:
            return
        old = self._whiteboard
        new_wb = FurnitureItem(
            name=old.name,
            sprite=new_sprite,
            x=old.x,
            y=old.y,
        )
        # Replace in furniture list
        for i, f in enumerate(self.scene.furniture):
            if f is old:
                self.scene.furniture[i] = new_wb
                break
        self._whiteboard = new_wb


# ---------------------------------------------------------------------------
# Exit Plan Mode stages
# ---------------------------------------------------------------------------

class ExitPlanStage(Enum):
    WRAP_UP = auto()          # Celebrate briefly
    CLEANUP = auto()          # Remove meeting furniture, walk to desks
    RETURN_TO_DESKS = auto()  # Wait for everyone to settle
    DONE = auto()


@dataclass
class ExitPlanSequence:
    """Manages the plan-mode exit animation."""
    scene: Scene
    stage: ExitPlanStage = ExitPlanStage.WRAP_UP
    elapsed: float = 0.0
    stage_elapsed: float = 0.0
    _wrap_up_started: bool = False
    _cleanup_done: bool = False

    is_complete: bool = False

    def start(self) -> None:
        """Initialize the exit-plan sequence."""
        self.stage = ExitPlanStage.WRAP_UP
        self.elapsed = 0.0
        self.stage_elapsed = 0.0
        self._wrap_up_started = False
        self._cleanup_done = False

        # Immediately start celebration
        if self.scene.characters:
            lead = self.scene.characters[0]
            lead.bubble_text = t("plan_wrap_up")
            lead.bubble_type = "speech"
            lead.bubble_ttl = 2.0
        for c in self.scene.characters:
            c.state = State.CELEBRATING
            c.state_timer = 0.0
        self._wrap_up_started = True

    def tick(self, dt: float) -> None:
        """Advance exit-plan sequence by one frame."""
        self.elapsed += dt
        self.stage_elapsed += dt

        if self.stage == ExitPlanStage.WRAP_UP:
            if self.stage_elapsed >= 1.5:
                # Remove meeting furniture and send chars to desks
                self.scene.furniture = [
                    f for f in self.scene.furniture
                    if f.name not in ("meeting_table", "whiteboard_plan")
                ]
                for c in self.scene.characters:
                    if c.desk_x is not None and c.desk_y is not None:
                        c.target_x = c.desk_x
                        c.target_y = c.desk_y
                    else:
                        c.target_x = float(self.scene.width // 2)
                        c.target_y = float(self.scene.height // 2)
                    c.target_callback = None
                    c.state = State.WALKING
                    c.state_timer = 0.0
                    # Only clear busy for chars whose tool already completed
                    # during plan mode (on_tool_end_quiet already set busy=False).
                    # Chars still busy have in-flight tools — preserve ownership
                    # so the eventual tool_post can match them correctly.
                self._advance(ExitPlanStage.CLEANUP)

        elif self.stage == ExitPlanStage.CLEANUP:
            if self.stage_elapsed >= 1.5:
                self._advance(ExitPlanStage.RETURN_TO_DESKS)

        elif self.stage == ExitPlanStage.RETURN_TO_DESKS:
            all_settled = all(
                c.state in (State.IDLE, State.TYPING, State.THINKING)
                for c in self.scene.characters
            )
            if all_settled or self.stage_elapsed >= 3.0:
                # Force idle for any stragglers
                for c in self.scene.characters:
                    if c.state == State.WALKING:
                        c.state = State.IDLE
                        c.target_x = None
                        c.target_y = None
                self._advance(ExitPlanStage.DONE)
                self.is_complete = True
                self.scene._plan_active = False
                # Schedule departure for agents that were busy when plan mode started
                for c in self.scene.characters:
                    if c.is_agent and getattr(c, "_plan_mode_was_busy", False):
                        c._plan_mode_was_busy = False  # type: ignore[attr-defined]
                        if c._idle_before_depart <= 0:
                            c._idle_before_depart = 8.0
                # Catch up on checks that were paused during plan mode
                self.scene._check_auto_upgrade()
                self.scene._achievements.check(self.scene)

    def _advance(self, stage: ExitPlanStage) -> None:
        self.stage = stage
        self.stage_elapsed = 0.0


# ---------------------------------------------------------------------------
# Office Upgrade stages
# ---------------------------------------------------------------------------

class UpgradeStage(Enum):
    FLASH = auto()          # Screen flashes white 3 times
    BANNER = auto()         # Big LEVEL UP text with box, typewriter reveal
    CELEBRATE = auto()      # Characters celebrate while banner stays
    REBUILD_REVEAL = auto() # Furniture pop-in one by one with labels
    SETTLE = auto()         # Characters walk to new desks
    DONE = auto()


# Map furniture name → i18n key
_FURN_I18N: dict[str, str] = {
    "bookshelf": "furn_bookshelf",
    "trophy": "furn_trophy",
    "arcade": "furn_arcade",
    "sofa": "furn_sofa",
    "server": "furn_server",
    "plant": "furn_plant",
    "whiteboard": "furn_whiteboard",
    "watercooler": "furn_watercooler",
    "gold_wall": "furn_gold_wall",
    "bar": "furn_bar",
    "bike": "furn_bike",
}


def _get_new_furniture(old_key: str, new_key: str) -> list[str]:
    """Compute furniture items that are new in new_key vs old_key."""
    from .levels import LEVEL_BY_KEY, LEVEL_DEFS
    old_def = LEVEL_BY_KEY.get(old_key, LEVEL_DEFS[0])
    new_def = LEVEL_BY_KEY.get(new_key, LEVEL_DEFS[0])
    old_set = set(old_def.furniture)
    # Deduplicate: "bookshelf2" → "bookshelf" for display
    return [f for f in new_def.furniture
            if f not in old_set and f not in ("door", "coffee")]


@dataclass
class UpgradeSequence:
    """Manages the office upgrade animation (~8 seconds).

    Stages: FLASH → BANNER → CELEBRATE → REBUILD_REVEAL → SETTLE → DONE
    """
    scene: Scene
    new_level: str = ""
    old_level: str = ""
    stage: UpgradeStage = UpgradeStage.FLASH
    elapsed: float = 0.0
    stage_elapsed: float = 0.0
    is_complete: bool = False

    # Flash state
    _flash_count: int = 0
    _flash_on: bool = False

    # Banner state
    _banner_lines_shown: int = 0
    _banner_full: list[str] = field(default_factory=list)
    _star_blink: bool = False

    # Rebuild/reveal state
    _rebuild_done: bool = False
    _reveal_items: list[tuple[str, int, int]] = field(default_factory=list)
    _reveal_idx: int = 0
    _reveal_timer: float = 0.0

    def start(self) -> None:
        """Initialize the upgrade sequence."""
        self.stage = UpgradeStage.FLASH
        self.elapsed = 0.0
        self.stage_elapsed = 0.0
        self._flash_count = 0
        self._flash_on = False
        self._banner_lines_shown = 0
        self._rebuild_done = False
        self._reveal_idx = 0
        self._reveal_timer = 0.0

        # Freeze all characters
        for c in self.scene.characters:
            c.busy = False
            c.current_task_id = ""
            c.target_x = None
            c.target_y = None
            c.target_callback = None

        # Build the full banner text
        self._banner_full = self._build_banner()

    def _build_banner(self) -> list[str]:
        """Build the LEVEL UP banner lines for overlay."""
        from .bubbles import display_width as _dw

        def _center_dw(text: str, width: int) -> str:
            """Center text using display width (CJK-safe)."""
            dw = _dw(text)
            if dw >= width:
                return text
            pad = width - dw
            left = pad // 2
            right = pad - left
            return " " * left + text + " " * right

        def _make_row(content: str) -> str:
            """Build a box row: ║ + content padded to inner width + ║."""
            return "║ " + _center_dw(content, inner) + " ║"

        w = self.scene.width
        use_big = w >= 55
        art = LEVEL_UP_BIG if use_big else LEVEL_UP_SMALL
        art_w = max(len(line) for line in art)

        # Box width: art + margins
        box_w = min(w - 4, art_w + 8)
        inner = box_w - 4  # inside ║  ...  ║

        lines: list[str] = []
        # Top border
        lines.append("╔" + "═" * (box_w - 2) + "╗")

        # Star row
        star_line = "✦  ✦  ✦"
        star_dw = _dw(star_line)
        if star_dw * 2 + 2 <= inner:
            star_row = star_line + " " * (inner - star_dw * 2) + star_line
        else:
            star_row = star_line
        lines.append(_make_row(star_row))

        # Empty line
        lines.append("║ " + " " * inner + " ║")

        # ASCII art lines (centered)
        for art_line in art:
            lines.append(_make_row(art_line))

        # Empty line
        lines.append("║ " + " " * inner + " ║")

        # Level transition line (may contain CJK characters)
        old_name = t(f"office_{self.old_level}")
        new_name = t(f"office_{self.new_level}")
        transition = f"{old_name}  ──►  {new_name}"
        lines.append(_make_row(transition))

        # Star row again
        lines.append(_make_row(star_row))

        # Bottom border
        lines.append("╚" + "═" * (box_w - 2) + "╝")

        return lines

    def tick(self, dt: float) -> None:
        """Advance upgrade sequence by one frame."""
        self.elapsed += dt
        self.stage_elapsed += dt

        if self.stage == UpgradeStage.FLASH:
            self._tick_flash(dt)
        elif self.stage == UpgradeStage.BANNER:
            self._tick_banner(dt)
        elif self.stage == UpgradeStage.CELEBRATE:
            self._tick_celebrate(dt)
        elif self.stage == UpgradeStage.REBUILD_REVEAL:
            self._tick_rebuild_reveal(dt)
        elif self.stage == UpgradeStage.SETTLE:
            self._tick_settle(dt)

    def _tick_flash(self, dt: float) -> None:
        """Flash screen white 3 times (fast→slow rhythm)."""
        # Flash pattern: on 0.08s, off 0.08s, on 0.08s, off 0.12s, on 0.12s, off 0.12s
        thresholds = [0.08, 0.16, 0.24, 0.36, 0.48, 0.60]
        flash_states = [True, False, True, False, True, False]

        idx = 0
        for i, th in enumerate(thresholds):
            if self.stage_elapsed >= th:
                idx = i
        if idx < len(flash_states):
            self.scene.upgrade_flash = flash_states[idx]
        else:
            self.scene.upgrade_flash = False

        if self.stage_elapsed >= 0.80:
            self.scene.upgrade_flash = False
            self._advance(UpgradeStage.BANNER)

    def _tick_banner(self, dt: float) -> None:
        """Typewriter reveal of the LEVEL UP banner."""
        total_lines = len(self._banner_full)
        # Reveal ~1 line per 0.1s (borders appear instantly, art lines type in)
        target_lines = min(total_lines, int(self.stage_elapsed / 0.10) + 1)

        if target_lines != self._banner_lines_shown:
            self._banner_lines_shown = target_lines
            # Update overlay with revealed lines so far
            visible = self._banner_full[:self._banner_lines_shown]
            self.scene.upgrade_overlay = visible
            # Center vertically
            h = self.scene.height
            self.scene.upgrade_overlay_y = max(1, (h - len(visible)) // 2)

        # Blink stars every 0.2s
        blink = int(self.stage_elapsed / 0.2) % 2 == 0
        if blink != self._star_blink:
            self._star_blink = blink
            # Replace ✦ with ✧ for blink effect in overlay
            updated = []
            for line in self.scene.upgrade_overlay:
                if blink:
                    updated.append(line)
                else:
                    updated.append(line.replace("✦", "✧"))
            self.scene.upgrade_overlay = updated

        # After all lines shown + 0.5s hold → advance
        if self._banner_lines_shown >= total_lines and self.stage_elapsed >= total_lines * 0.10 + 0.5:
            self._advance(UpgradeStage.CELEBRATE)

    def _tick_celebrate(self, dt: float) -> None:
        """Characters celebrate while banner stays visible."""
        # Set celebrating on first tick
        if self.stage_elapsed < dt * 2:
            for c in self.scene.characters:
                c.state = State.CELEBRATING
                c.state_timer = 0.0
            if self.scene.characters:
                lead = self.scene.characters[0]
                lead.bubble_text = t("office_upgrade")
                lead.bubble_type = "speech"
                lead.bubble_ttl = 2.0

        # Keep blinking stars
        blink = int(self.elapsed / 0.2) % 2 == 0
        updated = []
        for line in self._banner_full:
            if blink:
                updated.append(line)
            else:
                updated.append(line.replace("✦", "✧"))
        self.scene.upgrade_overlay = updated

        if self.stage_elapsed >= 1.2:
            # Clear banner overlay
            self.scene.upgrade_overlay = []
            self._advance(UpgradeStage.REBUILD_REVEAL)

    def _tick_rebuild_reveal(self, dt: float) -> None:
        """Rebuild layout and reveal new furniture one by one with labels."""
        if not self._rebuild_done:
            self._rebuild_done = True
            # Save character state
            old_chars = list(self.scene.characters)
            # Repopulate furniture with new layout (may add desks)
            self.scene.populate(with_characters=False)
            # Restore existing characters
            self.scene.characters = old_chars

            # Spawn additional elves if new level has more
            from .levels import LEVEL_BY_KEY, LEVEL_DEFS
            new_def = LEVEL_BY_KEY.get(self.new_level, LEVEL_DEFS[0])
            w = self.scene.width
            max_by_width = 2 if w < 40 else (3 if w < 55 else 4)
            target_count = min(new_def.elf_count, max_by_width)
            if target_count > len(old_chars):
                from .characters import create_characters
                extra = create_characters(
                    self.scene.theme_name, target_count, w,
                    self.scene.height,
                    desk_positions=self.scene._desk_positions,
                )
                # Only keep the new ones
                for c in extra[len(old_chars):]:
                    # Spawn at door position
                    door_x, door_y = self.scene._get_door_position()
                    c.x = float(door_x + 2)
                    c.y = float(door_y + 2)
                    self.scene.characters.append(c)

            # Build list of new furniture items to reveal with pop-in
            new_furn_keys = _get_new_furniture(self.old_level, self.new_level)
            # Map level keys (e.g. "bookshelf2") to item names ("bookshelf")
            # and track which base names we need to find in scene
            need: list[str] = []  # (level_key) in order
            for key in new_furn_keys:
                need.append(key)
            found: set[str] = set()
            self._reveal_items = []
            for key in need:
                base_name = key.rstrip("0123456789")  # "bookshelf2" → "bookshelf"
                i18n_name = key  # keep original for label lookup
                for item in self.scene.furniture:
                    item_id = f"{item.name}_{item.x}_{item.y}"
                    if item.name == base_name and item_id not in found:
                        found.add(item_id)
                        self._reveal_items.append((i18n_name, item.x, item.y))
                        break

            # Send everyone to new desk positions
            for i, c in enumerate(self.scene.characters):
                if i < len(self.scene._desk_positions):
                    dx, dy = self.scene._desk_positions[i]
                    c.desk_x = dx
                    c.desk_y = dy
                    c.target_x = dx
                    c.target_y = dy
                else:
                    c.target_x = float(self.scene.width // 2)
                    c.target_y = float(self.scene.height // 2)
                c.target_callback = None
                c.state = State.WALKING
                c.state_timer = 0.0

        # Pop-in: reveal one furniture item every 0.6s
        self._reveal_timer += dt
        items_to_show = min(len(self._reveal_items), int(self._reveal_timer / 0.6) + 1)

        if items_to_show > self._reveal_idx:
            self._reveal_idx = items_to_show
            # Update labels: show current item label (clear old ones)
            self.scene.upgrade_labels = []
            if self._reveal_idx <= len(self._reveal_items):
                name, fx, fy = self._reveal_items[self._reveal_idx - 1]
                base = name.rstrip("0123456789")
                i18n_key = _FURN_I18N.get(name, _FURN_I18N.get(base, name))
                label_text = t(i18n_key)
                # Position label near the furniture item
                self.scene.upgrade_labels = [(fx, max(1, fy - 1), label_text)]

        # Clear label after 0.5s of showing
        label_age = self._reveal_timer - (self._reveal_idx - 1) * 0.6
        if label_age > 0.5:
            self.scene.upgrade_labels = []

        # Done after all items revealed + 0.5s buffer
        total_time = len(self._reveal_items) * 0.6 + 0.5
        if self._reveal_timer >= total_time:
            self.scene.upgrade_labels = []
            self._advance(UpgradeStage.SETTLE)

    def _tick_settle(self, dt: float) -> None:
        """Wait for characters to reach their desks."""
        all_settled = all(
            c.state in (State.IDLE, State.TYPING, State.THINKING)
            for c in self.scene.characters
        )
        if all_settled or self.stage_elapsed >= 3.0:
            for c in self.scene.characters:
                if c.state == State.WALKING:
                    c.state = State.IDLE
                    c.target_x = None
                    c.target_y = None
            self.scene._assign_desk_names()
            self.scene.upgrade_flash = False
            self.scene.upgrade_overlay = []
            self.scene.upgrade_labels = []
            self._advance(UpgradeStage.DONE)
            self.is_complete = True

    def _advance(self, stage: UpgradeStage) -> None:
        self.stage = stage
        self.stage_elapsed = 0.0
