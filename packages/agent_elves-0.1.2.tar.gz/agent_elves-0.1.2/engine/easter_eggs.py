"""Easter eggs, interactions, and Smith animations — extracted from scene.py."""
from __future__ import annotations

import random
import time as _time_mod
from typing import TYPE_CHECKING

from .bubbles import t
from .characters import State

if TYPE_CHECKING:
    from .scene import Scene


def check_interactions(scene: Scene) -> None:
    """Trigger social interactions between elves."""
    scene._interaction_cooldown = max(0.0, scene._interaction_cooldown - 0.1)
    if scene._interaction_cooldown > 0:
        return

    idle_chars = [c for c in scene.characters
                  if c.state == State.IDLE and not c.is_agent]

    # Watercooler chat: if 2+ idle chars, small chance one invites another
    if len(idle_chars) >= 2 and random.random() < 0.008:
        a, b = random.sample(idle_chars, 2)
        cx, cy = scene._coffee_pos
        chat_keys = ["chat_1", "chat_2", "chat_3", "chat_4"]
        a.target_x = cx - 5
        a.target_y = cy
        a.target_callback = "chat"
        a.state = State.WALKING
        a.state_timer = 0.0
        a.bubble_text = t(random.choice(chat_keys))
        a.bubble_type = "speech"
        a.bubble_ttl = 3.0

        b.target_x = cx - 9
        b.target_y = cy
        b.target_callback = "chat"
        b.state = State.WALKING
        b.state_timer = 0.0
        b.bubble_text = t(random.choice(chat_keys))
        b.bubble_type = "speech"
        b.bubble_ttl = 3.0

        scene.start_coffee()
        scene._interaction_cooldown = 12.0
        return

    # High-five: when a char is celebrating, nearby idle chars join
    for c in scene.characters:
        if c.state == State.CELEBRATING and c.state_timer < 0.2:
            for other in scene.characters:
                if (other is not c
                        and other.state == State.IDLE
                        and not other.is_agent):
                    dx = abs(other.x - c.x)
                    dy = abs(other.y - c.y)
                    if dx < 12 and dy < 6:
                        other.bubble_text = t("highfive")
                        other.bubble_type = "speech"
                        other.bubble_ttl = 1.5
                        other.state = State.CELEBRATING
                        other.state_timer = 0.0
                        scene._interaction_cooldown = 5.0
                        break


def check_easter_eggs(scene: Scene, dt: float) -> None:
    """Randomly trigger fun easter egg events and idle chatter."""
    scene._easter_egg_timer += dt
    if scene._easter_egg_timer < random.uniform(5.0, 7.0):
        return
    scene._easter_egg_timer = 0.0

    idle = [c for c in scene.characters
            if c.state == State.IDLE and not c.is_agent]
    if not idle:
        return

    # Night mode: idle elves get sleepy
    hour = _time_mod.localtime().tm_hour
    if hour >= 23 or hour < 6:
        for c in idle:
            if c.bubble_ttl <= 0 and random.random() < 0.03:
                c.state = State.SLEEPY
                c.state_timer = 0.0
                c.bubble_text = t(random.choice(["sleepy_1", "sleepy_2"]))
                c.bubble_type = "thought"
                c.bubble_ttl = 4.0
                return

    # Furniture interactions
    quiet = [c for c in idle if c.bubble_ttl <= 0]
    available_furn: list[tuple[str, float, float, list[str], str, float]] = []
    for item in scene.furniture:
        if item.name == "sofa":
            available_furn.append(("sofa", item.x + 2, item.y,
                                   ["furn_sofa_1", "furn_sofa_2", "furn_sofa_3", "furn_sofa_4"], "thought", 5.0))
        elif item.name == "arcade":
            available_furn.append(("arcade", item.x + 1, item.y + 1,
                                   ["furn_arcade_1", "furn_arcade_2", "furn_arcade_3", "furn_arcade_4"], "speech", 4.0))
        elif item.name == "bar":
            available_furn.append(("bar", item.x + 2, item.y + 2,
                                   ["furn_bar_1", "furn_bar_2", "furn_bar_3", "furn_bar_4"], "speech", 3.0))
        elif item.name == "bike":
            available_furn.append(("bike", item.x + 1, item.y - 1,
                                   ["furn_bike_1", "furn_bike_2", "furn_bike_3", "furn_bike_4"], "speech", 4.0))
        elif item.name == "bookshelf":
            available_furn.append(("bookshelf", item.x + 2, item.y + 2,
                                   ["furn_book_1", "furn_book_2", "furn_book_3", "furn_book_4"], "thought", 3.0))
        elif item.name == "server":
            available_furn.append(("server", item.x + 1, item.y + 2,
                                   ["furn_server_1", "furn_server_2", "furn_server_3", "furn_server_4"], "thought", 3.0))
        elif item.name == "coffee":
            available_furn.append(("coffee", item.x + 3, item.y + 1,
                                   ["furn_coffee_1", "furn_coffee_2", "furn_coffee_3"], "speech", 3.0))
        elif item.name == "trophy":
            available_furn.append(("trophy", item.x + 3, item.y + 2,
                                   ["furn_trophy_1", "furn_trophy_2", "furn_trophy_3"], "thought", 4.0))
        elif item.name.startswith("plant"):
            available_furn.append(("plant", item.x + 1, item.y,
                                   ["furn_plant_1", "furn_plant_2", "furn_plant_3"], "speech", 3.0))
        elif item.name == "whiteboard":
            available_furn.append(("whiteboard", item.x + 3, item.y + 2,
                                   ["furn_wb_1", "furn_wb_2", "furn_wb_3"], "thought", 4.0))
        elif item.name == "watercooler":
            available_furn.append(("watercooler", item.x + 1, item.y + 1,
                                   ["furn_wc_1", "furn_wc_2", "furn_wc_3"], "speech", 3.0))
        elif item.name == "door" and not item.name.startswith("door_"):
            available_furn.append(("door", item.x + 3, item.y + 3,
                                   ["furn_door_1", "furn_door_2"], "thought", 3.0))

    # Dual-elf furniture interactions
    if len(quiet) >= 2 and available_furn and random.random() < 0.10:
        dual_furn = [f for f in available_furn if f[0] in ("arcade", "bar", "sofa", "trophy")]
        if dual_furn:
            _, fx, fy, bubble_keys, btype, duration = random.choice(dual_furn)
            pair = random.sample(quiet, 2)
            for i, elf in enumerate(pair):
                elf.target_x = float(fx + i * 2)
                elf.target_y = float(fy)
                elf.target_callback = "furniture"
                elf.state = State.WALKING
                elf.state_timer = 0.0
                elf.bubble_text = t(random.choice(bubble_keys))
                elf.bubble_type = btype
                elf.bubble_ttl = duration
                if elf in quiet:
                    quiet.remove(elf)
            return

    if available_furn and quiet and random.random() < 0.35:
        _, fx, fy, bubble_keys, btype, duration = random.choice(available_furn)
        elf = random.choice(quiet)
        elf.target_x = float(fx)
        elf.target_y = float(fy)
        elf.target_callback = "furniture"
        elf.state = State.WALKING
        elf.state_timer = 0.0
        elf.bubble_text = t(random.choice(bubble_keys))
        elf.bubble_type = btype
        elf.bubble_ttl = duration
        quiet = [c for c in quiet if c is not elf]

    # Random snacking
    if quiet and random.random() < 0.08:
        snacker = random.choice(quiet)
        snacker.state = State.SNACKING
        snacker.state_timer = 0.0
        snacker.bubble_text = t(random.choice(["snack_1", "snack_2", "snack_3"]))
        snacker.bubble_type = "speech"
        snacker.bubble_ttl = 3.0
        quiet = [c for c in quiet if c is not snacker]

    # Idle chatter
    if quiet and random.random() < 0.65:
        talker = random.choice(quiet)
        chatter_keys = [
            "chat_1", "chat_2", "chat_3", "chat_4",
            "idle_1", "idle_2", "idle_3", "idle_4",
            "idle_5", "idle_6", "idle_7", "idle_8",
        ]
        talker.bubble_text = t(random.choice(chatter_keys))
        talker.bubble_type = random.choice(["speech", "thought"])
        talker.bubble_ttl = random.uniform(2.0, 4.0)

    # Easter egg events (less frequent)
    if random.random() > 0.25:
        return

    target = random.choice(idle)

    event_type = random.choice([
        "pizza", "cat", "sleepy", "music", "stretch",
    ])

    if event_type == "sleepy":
        target.bubble_text = t("sleepy")
        target.bubble_type = "thought"
        target.bubble_ttl = 4.0
    elif event_type == "pizza":
        target.bubble_text = t("pizza")
        target.bubble_type = "speech"
        target.bubble_ttl = 3.0
        target.state = State.CELEBRATING
        target.state_timer = 0.0
        for other in idle:
            if other is not target:
                other.bubble_text = "🍕!"
                other.bubble_type = "speech"
                other.bubble_ttl = 2.0
    elif event_type == "cat":
        target.bubble_text = t("cat")
        target.bubble_type = "speech"
        target.bubble_ttl = 3.0
    elif event_type == "music":
        target.bubble_text = t("music")
        target.bubble_type = "thought"
        target.bubble_ttl = 3.0
    elif event_type == "stretch":
        target.bubble_text = t("stretch")
        target.bubble_type = "speech"
        target.bubble_ttl = 2.0
        target.state = State.CELEBRATING
        target.state_timer = 0.0

    # Smith special events
    smiths = [c for c in scene.characters
              if c.is_agent and c.state == State.IDLE
              and not c.busy and c.target_x is None]
    idle_regulars = [c for c in scene.characters
                     if not c.is_agent and c.state == State.IDLE
                     and not c.busy and c.target_x is None]

    if smiths and idle_regulars and not scene.smith_effects and random.random() < 0.15:
        smith = random.choice(smiths)
        target2 = random.choice(idle_regulars)
        event2 = random.choice(["smith_clone", "smith_fight", "smith_bullet"])

        smith.target_x = target2.x + (3 if smith.x > target2.x else -3)
        smith.target_y = target2.y
        smith.target_callback = None
        smith.state = State.WALKING
        smith.state_timer = 0.0

        scene.smith_effects = {
            "type": event2,
            "phase": 0,
            "timer": 0.0,
            "smith_name": smith.name,
            "target_name": target2.name,
            "bullet_x": 0.0,
            "bullet_y": 0.0,
            "target_old_theme": target2.theme_override,
        }


def tick_smith_effects(scene: Scene, dt: float) -> None:
    """Advance Agent Smith easter egg animations."""
    if not scene.smith_effects:
        return

    fx = scene.smith_effects
    fx["timer"] += dt

    smith = next((c for c in scene.characters if c.name == fx["smith_name"]), None)
    target = next((c for c in scene.characters if c.name == fx["target_name"]), None)

    if smith is None or target is None or target.busy or smith.busy:
        if target is not None and "target_old_theme" in fx:
            target.theme_override = fx["target_old_theme"]
        scene.smith_effects = {}
        return

    fx_type = fx["type"]
    phase = fx["phase"]
    timer = fx["timer"]

    if fx_type == "smith_clone":
        if phase == 0:
            dist = abs(smith.x - target.x) + abs(smith.y - target.y)
            if dist < 4 or timer > 8.0:
                fx["phase"] = 1
                fx["timer"] = 0.0
                smith.state = State.IDLE
                smith.bubble_text = t("smith_clone")
                smith.bubble_type = "speech"
                smith.bubble_ttl = 1.5
        elif phase == 1:
            if timer >= 1.5:
                fx["phase"] = 2
                fx["timer"] = 0.0
                target.theme_override = "contractor"
                target.bubble_text = "..."
                target.bubble_type = "speech"
                target.bubble_ttl = 2.0
        elif phase == 2:
            if timer >= 2.0:
                fx["phase"] = 3
                fx["timer"] = 0.0
        elif phase == 3:
            if timer >= 0.5:
                target.theme_override = fx["target_old_theme"]
                smith.state = State.IDLE
                target.state = State.IDLE
                scene.smith_effects = {}

    elif fx_type == "smith_fight":
        if phase == 0:
            dist = abs(smith.x - target.x) + abs(smith.y - target.y)
            if dist < 5 or timer > 8.0:
                fx["phase"] = 1
                fx["timer"] = 0.0
                smith.state = State.IDLE
                smith.bubble_text = t("smith_fight")
                smith.bubble_type = "speech"
                smith.bubble_ttl = 1.5
        elif phase == 1:
            if timer >= 1.0:
                fx["phase"] = 2
                fx["timer"] = 0.0
                target.bubble_text = t("smith_neo")
                target.bubble_type = "speech"
                target.bubble_ttl = 1.5
                smith.state = State.CELEBRATING
                smith.state_timer = 0.0
        elif phase == 2:
            if timer >= 1.5:
                fx["phase"] = 3
                fx["timer"] = 0.0
                target.state = State.CELEBRATING
                target.state_timer = 0.0
                smith.bubble_text = t("smith_handshake")
                smith.bubble_type = "speech"
                smith.bubble_ttl = 1.5
        elif phase == 3:
            if timer >= 1.5:
                smith.state = State.IDLE
                target.state = State.IDLE
                scene.smith_effects = {}

    elif fx_type == "smith_bullet":
        if phase == 0:
            dist = abs(smith.x - target.x) + abs(smith.y - target.y)
            if dist < 6 or timer > 8.0:
                fx["phase"] = 1
                fx["timer"] = 0.0
                fx["bullet_x"] = smith.x + 4
                fx["bullet_y"] = smith.y + 1
                smith.state = State.IDLE
                smith.bubble_text = t("smith_bullet")
                smith.bubble_type = "speech"
                smith.bubble_ttl = 2.0
                target.state = State.THINKING
                target.state_timer = 0.0
        elif phase == 1:
            direction = 1 if target.x > smith.x else -1
            fx["bullet_x"] += direction * 3.0 * dt
            if ((direction > 0 and fx["bullet_x"] >= target.x)
                    or (direction < 0 and fx["bullet_x"] <= target.x)
                    or timer >= 2.0):
                fx["phase"] = 2
                fx["timer"] = 0.0
                target.bubble_text = t("smith_whoa")
                target.bubble_type = "speech"
                target.bubble_ttl = 1.5
        elif phase == 2:
            if timer >= 1.0:
                fx["phase"] = 3
                fx["timer"] = 0.0
        elif phase == 3:
            if timer >= 1.0:
                smith.state = State.IDLE
                target.state = State.IDLE
                scene.smith_effects = {}
