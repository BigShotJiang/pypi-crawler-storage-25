"""Character (manju agent) state machine and movement."""
from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from enum import Enum

from .sprites import THEMES


class State(Enum):
    IDLE = "idle"
    WALKING = "walking"
    TYPING = "typing"
    THINKING = "thinking"
    CELEBRATING = "celebrating"
    COFFEE = "coffee"
    GREETING = "greeting"      # brief pause at door to wave hello/goodbye
    CHATTING = "chatting"      # chatting at watercooler with another elf
    SETTING_UP = "setting_up"  # contractor setting up temp desk
    PACKING_UP = "packing_up"  # contractor packing up temp desk
    FAREWELL = "farewell"      # contractor saying goodbye before leaving
    POWER_UP = "power_up"      # Super Saiyan transformation (Skill tool)
    STRETCHING = "stretching"  # auto-stretch after long typing
    SLEEPY = "sleepy"          # drowsy at night
    EXCITED = "excited"        # streak of completed tasks
    FRUSTRATED = "frustrated"  # tool error
    HIGH_FIVE = "high_five"    # two elves celebrate together
    READING = "reading"        # Read/Grep/Glob tools
    SNACKING = "snacking"      # random idle snacking


# Role → tool affinity mapping
# Each role has a list of preferred tools (highest priority first)
ROLE_TOOLS: dict[str, list[str]] = {
    "engineer": ["Bash", "Edit", "Write"],        # coding & execution
    "researcher": ["Read", "Grep", "Glob"],        # reading & searching
    "designer": ["Edit", "Write"],                 # creative editing
    "ops": ["Bash", "Agent", "WebSearch", "Skill"],  # operations & orchestration
}

# Fallback: any role can handle any tool
ALL_TOOLS = ["Bash", "Edit", "Write", "Read", "Grep", "Glob", "Agent",
             "WebSearch", "WebFetch", "Skill"]


@dataclass
class Character:
    """A single office character with position, state, and animation."""
    name: str
    x: float
    y: float
    color_index: int = 1
    state: State = State.IDLE
    direction: str = "right"  # "left" or "right"
    target_x: float | None = None
    target_y: float | None = None
    target_callback: str | None = None  # state to enter on arrival
    bubble_text: str = ""
    bubble_type: str = "speech"  # "speech" or "thought"
    bubble_ttl: float = 0.0
    anim_frame: int = 0
    anim_timer: float = 0.0
    state_timer: float = 0.0
    busy: bool = False  # currently handling a tool event
    speed: float = 4.0  # cells per second
    is_agent: bool = False  # spawned by Agent tool (temporary)
    theme_override: str = ""  # use this theme instead of scene theme

    # Contractor lifecycle fields
    _pending_task_state: str = ""  # "typing" or "thinking" — used after setup
    _pending_task_id: str = ""     # task_id stored during setup phase
    _door_target_x: float = 1.0   # door position for departure
    _door_target_y: float = 1.0
    _temp_desk_idx: int = -1       # index of temp desk in scene.furniture (-1 = none)

    _consecutive_tasks: int = 0        # tracks task streak for EXCITED
    _pre_stretch_state: str = ""       # state to return to after STRETCHING

    # Power-up (Super Saiyan) fields — used during POWER_UP state
    _powerup_phase: int = 0         # 0=crouch, 1=scream, 2=burst
    _powerup_timer: float = 0.0
    _powerup_skill_name: str = ""
    powered_up: bool = False        # True while working after power-up (bold golden glow)

    # (A) Fixed desk assignment
    desk_x: float | None = None
    desk_y: float | None = None

    # (B) Task tracking — matches tool_pre to tool_post
    current_task_id: str = ""

    # (C) Role-based specialization
    role: str = "engineer"  # engineer, researcher, designer, ops

    _idle_timer: float = field(default=0.0, repr=False)
    _idle_threshold: float = field(default=6.0, repr=False)
    _departure_pending: bool = field(default=False, repr=False)
    _departed: bool = field(default=False, repr=False)

    _idle_before_depart: float = field(default=0.0, repr=False)

    def can_handle(self, tool: str) -> bool:
        """Check if this character's role prefers this tool type.

        The 'lead' role (protagonist) can handle any tool.
        """
        if self.role == "lead":
            return True
        preferred = ROLE_TOOLS.get(self.role, ALL_TOOLS)
        return tool in preferred

    def get_sprite_lines(self, theme_name: str) -> list[str]:
        """Get current animation frame lines for this character."""
        name = self.theme_override or theme_name
        theme = THEMES.get(name, THEMES["claude"])
        sprites = theme["sprites"]

        # Find matching sprite key
        state_name = self.state.value
        direction = self.direction

        # Map states that reuse other sprites
        if state_name == "greeting":
            state_name = "celebrating"
        elif state_name == "chatting":
            state_name = "idle"
        elif state_name == "setting_up":
            state_name = "typing"  # looks like working/building
        elif state_name == "packing_up":
            state_name = "typing"  # same busy animation
        elif state_name == "farewell":
            state_name = "celebrating"  # waving goodbye
        elif state_name == "power_up":
            # Phase 0: crouch (thinking), phases 1-2: celebrating (arms raised)
            state_name = "thinking" if self._powerup_phase == 0 else "celebrating"
        elif state_name == "high_five":
            state_name = "celebrating"
        # New states: use dedicated sprite if available, otherwise fallback
        elif state_name in ("stretching", "sleepy", "excited", "frustrated", "reading", "snacking"):
            # These states have dedicated sprites in THEME_CLAUDE
            # Other themes will fallback via the key-not-in-sprites check below
            pass
        key = (state_name, direction)
        if key not in sprites:
            key = (state_name, "right")
        if key not in sprites:
            # Smart fallback for new expression states
            _fallback = {
                "stretching": "celebrating",
                "sleepy": "idle",
                "excited": "celebrating",
                "frustrated": "thinking",
                "reading": "thinking",
                "snacking": "coffee",
            }
            fb = _fallback.get(state_name)
            if fb:
                key = (fb, direction)
                if key not in sprites:
                    key = (fb, "right")
        if key not in sprites:
            key = ("idle", "right")

        frames = sprites[key]
        frame_idx = self.anim_frame % len(frames)
        return frames[frame_idx]

    def sprite_width(self, theme_name: str) -> int:
        lines = self.get_sprite_lines(theme_name)
        return max(len(l) for l in lines) if lines else 0

    def sprite_height(self, theme_name: str) -> int:
        return len(self.get_sprite_lines(theme_name))

    def tick(self, dt: float, scene_w: int, scene_h: int):
        """Update character state for one frame."""
        self.anim_timer += dt
        self.state_timer += dt
        self.bubble_ttl = max(0.0, self.bubble_ttl - dt)

        # Animate at ~3fps for sprite cycling
        if self.anim_timer >= 0.33:
            self.anim_timer -= 0.33
            self.anim_frame += 1

        if self.state == State.WALKING:
            self._move_toward_target(dt, scene_w, scene_h)
        elif self.state == State.CELEBRATING:
            if self.state_timer >= 1.5:
                if self._departure_pending:
                    # Contractor done — start packing up
                    self.state = State.PACKING_UP
                    self.state_timer = 0.0
                    from .bubbles import t
                    self.bubble_text = t("agent_packing")
                    self.bubble_type = "speech"
                    self.bubble_ttl = 2.0
                else:
                    self._enter_idle()
        elif self.state == State.GREETING:
            # Brief pause to wave, then walk to assigned desk
            if self.state_timer >= 1.5:
                if self.target_x is not None:
                    if self.is_agent:
                        # Contractor: walk to spot, then set up desk
                        self.target_callback = "setup"
                    self.state = State.WALKING
                    self.state_timer = 0.0
                else:
                    self._enter_idle()
        elif self.state == State.SETTING_UP:
            # Contractor setting up temp desk (~2s)
            if self.state_timer >= 2.0:
                # Desk is placed by scene callback — start working
                if self._pending_task_state == "typing":
                    self.state = State.TYPING
                elif self._pending_task_state == "reading":
                    self.state = State.READING
                else:
                    self.state = State.THINKING
                self.state_timer = 0.0
        elif self.state == State.PACKING_UP:
            # Contractor packing up — skip quickly if no desk was set up
            pack_time = 1.5 if self._temp_desk_idx >= 0 or self.desk_x is not None else 0.3
            if self.state_timer >= pack_time:
                self.state = State.FAREWELL
                self.state_timer = 0.0
                from .bubbles import t
                self.bubble_text = t("agent_farewell")
                self.bubble_type = "speech"
                self.bubble_ttl = 2.0
        elif self.state == State.FAREWELL:
            # Say goodbye, then walk to door
            if self.state_timer >= 1.5:
                # Walk to door (set by scene before departure)
                door_x = self._door_target_x
                door_y = self._door_target_y
                self.target_x = door_x
                self.target_y = door_y
                self.target_callback = "depart"
                self.state = State.WALKING
                self.state_timer = 0.0
        elif self.state == State.POWER_UP:
            self._powerup_timer += dt
            if self._powerup_phase == 0:
                # Crouch phase (1s): tense up, show "..."
                if self._powerup_timer >= 1.0:
                    self._powerup_phase = 1
                    self._powerup_timer = 0.0
                    from .bubbles import t
                    self.bubble_text = t("powerup_scream")
                    self.bubble_type = "speech"
                    self.bubble_ttl = 1.5
            elif self._powerup_phase == 1:
                # Scream phase (1s): HAAA!!!!
                if self._powerup_timer >= 1.0:
                    self._powerup_phase = 2
                    self._powerup_timer = 0.0
                    self.bubble_text = ""
                    self.bubble_ttl = 0.0
            elif self._powerup_phase == 2:
                # Burst phase (1.5s): golden explosion, then start working
                if self._powerup_timer >= 1.5:
                    self.powered_up = True
                    self.state = State.TYPING
                    self.state_timer = 0.0
                    skill = self._powerup_skill_name
                    self.bubble_text = f"/{skill}" if skill else "skill!"
                    self.bubble_type = "speech"
                    self.bubble_ttl = 5.0
        elif self.state == State.CHATTING:
            if self.state_timer >= 3.5:
                self._return_to_desk()
        elif self.state == State.COFFEE:
            if self.state_timer >= 3.0:
                self._return_to_desk()
        elif self.state == State.STRETCHING:
            if self.state_timer >= 2.5:
                # Return to previous work state
                prev = self._pre_stretch_state
                if prev == "typing":
                    self.state = State.TYPING
                elif prev == "thinking":
                    self.state = State.THINKING
                elif prev == "reading":
                    self.state = State.READING
                else:
                    self._enter_idle()
                self.state_timer = 0.0
        elif self.state == State.SLEEPY:
            if self.state_timer >= 4.0:
                self._enter_idle()
        elif self.state == State.EXCITED:
            if self.state_timer >= 2.0:
                self._enter_idle()
        elif self.state == State.FRUSTRATED:
            if self.state_timer >= 2.5:
                self._enter_idle()
        elif self.state == State.HIGH_FIVE:
            if self.state_timer >= 2.0:
                self._return_to_desk()
        elif self.state == State.READING:
            # Same as THINKING — stay until tool_end or timeout
            if not self.busy and self.state_timer >= 2.0:
                self.state = State.CELEBRATING
                self.state_timer = 0.0
        elif self.state == State.SNACKING:
            if self.state_timer >= 3.0:
                self._enter_idle()
        elif self.state == State.IDLE:
            # Smith idle-before-depart countdown
            if self._idle_before_depart > 0:
                self._idle_before_depart -= dt
                if self._idle_before_depart <= 0:
                    self._idle_before_depart = 0.0
                    self._departure_pending = True
                    self.state = State.CELEBRATING
                    self.state_timer = 0.0
                return  # don't wander while counting down
            self._idle_timer += dt
            if self._idle_timer >= self._idle_threshold:
                self._idle_timer = 0.0
                self._wander(scene_w, scene_h)
        elif self.state in (State.TYPING, State.THINKING):
            # Stay until tool_end or timeout (30s max)
            if not self.busy and self.state_timer >= 2.0:
                self.state = State.CELEBRATING
                self.state_timer = 0.0

    def _move_toward_target(self, dt: float, scene_w: int, scene_h: int):
        if self.target_x is None or self.target_y is None:
            self._enter_idle()
            return

        dx = self.target_x - self.x
        dy = self.target_y - self.y
        dist = math.sqrt(dx * dx + dy * dy)

        if dist < 0.8:
            self.x = self.target_x
            self.y = self.target_y
            self.target_x = None
            self.target_y = None
            if self.target_callback == "typing":
                self.state = State.TYPING
            elif self.target_callback == "thinking":
                self.state = State.THINKING
            elif self.target_callback == "reading":
                self.state = State.READING
            elif self.target_callback == "coffee":
                self.state = State.COFFEE
            elif self.target_callback == "chat":
                self.state = State.CHATTING
            elif self.target_callback == "setup":
                # Contractor arrived at spot — start setting up desk
                self.state = State.SETTING_UP
                from .bubbles import t
                self.bubble_text = t("agent_setup")
                self.bubble_type = "speech"
                self.bubble_ttl = 2.0
            elif self.target_callback == "depart":
                # Mark for removal by scene
                self.state = State.IDLE
                self._departure_pending = False
                self._departed = True
            elif self.target_callback == "powerup":
                # Start Super Saiyan power-up animation
                self.state = State.POWER_UP
                self._powerup_phase = 0
                self._powerup_timer = 0.0
                self.state_timer = 0.0
            elif self.target_callback == "furniture":
                # Arrived at furniture — idle here with bubble already set
                self.state = State.IDLE
                self._idle_timer = 0.0
                self._idle_threshold = 5.0  # stay longer before wandering away
            else:
                self._enter_idle()
            self.target_callback = None
            self.state_timer = 0.0
            return

        step = self.speed * dt
        self.x += (dx / dist) * step
        self.y += (dy / dist) * step

        # Clamp to bounds (allow departing chars to reach edges)
        if self._departure_pending:
            self.x = max(-5, min(scene_w + 5, self.x))
            self.y = max(-5, min(scene_h + 5, self.y))
        else:
            self.x = max(1, min(scene_w - 8, self.x))
            self.y = max(1, min(scene_h - 6, self.y))

        # Face direction of movement
        self.direction = "right" if dx >= 0 else "left"

    def _enter_idle(self):
        self.state = State.IDLE
        self.state_timer = 0.0
        self._idle_timer = 0.0
        self._idle_threshold = random.uniform(4.0, 8.0)
        # Preserve busy/task_id if an in-flight tool is still pending
        # (e.g. during plan-mode the char is visually idle but tool_post
        # hasn't arrived yet — clearing busy would break matching)
        if not self.current_task_id:
            self.busy = False
            self._consecutive_tasks = 0

    def _return_to_desk(self):
        """Walk back to assigned desk after coffee/chat instead of idling in place."""
        if self.desk_x is not None and self.desk_y is not None:
            self.target_x = self.desk_x
            self.target_y = self.desk_y
            self.target_callback = None
            self.state = State.WALKING
            self.state_timer = 0.0
            if not self.current_task_id:
                self.busy = False
        else:
            self._enter_idle()

    def _wander(self, scene_w: int, scene_h: int):
        """Pick a random nearby spot to walk to."""
        self.target_x = self.x + random.uniform(-10, 10)
        self.target_y = self.y + random.uniform(-4, 4)
        self.target_x = max(1, min(scene_w - 8, self.target_x))
        self.target_y = max(1, min(scene_h - 6, self.target_y))
        self.target_callback = None
        self.state = State.WALKING
        self.state_timer = 0.0

    def assign_task(self, desk_x: float, desk_y: float,
                    task_state: str, bubble: str, bubble_type: str,
                    task_id: str = ""):
        """Send character to their own desk (or given desk) to work."""
        # (A) Use own desk if assigned, otherwise use provided position
        tx = self.desk_x if self.desk_x is not None else desk_x
        ty = self.desk_y if self.desk_y is not None else desk_y
        self.target_x = tx
        self.target_y = ty
        self.target_callback = task_state
        self.state = State.WALKING
        self.state_timer = 0.0
        self.busy = True
        # (B) Track which task this character is working on
        self.current_task_id = task_id
        self.bubble_text = bubble
        self.bubble_type = bubble_type
        self.bubble_ttl = 5.0

    def finish_task(self):
        """Called when tool_end arrives. Force into celebrating."""
        from .bubbles import t

        self._consecutive_tasks += 1
        self._peak_consecutive: int = max(
            getattr(self, "_peak_consecutive", 0), self._consecutive_tasks
        )

        # If still walking to desk, snap to desk position first
        if self.state in (State.WALKING, State.GREETING, State.SETTING_UP):
            if self.desk_x is not None and self.desk_y is not None:
                self.x = self.desk_x
                self.y = self.desk_y
            elif self.is_agent:
                # Agent hasn't set up desk yet — stay at current position
                # (will skip PACKING_UP since no desk to pack)
                pass

        self.busy = False
        self.current_task_id = ""
        self.target_x = None
        self.target_y = None
        self.target_callback = None
        if self._consecutive_tasks >= 3:
            self.state = State.EXCITED
            self._consecutive_tasks = 0
        else:
            self.state = State.CELEBRATING
        self.state_timer = 0.0
        self.bubble_text = t("done")
        self.bubble_type = "speech"
        self.bubble_ttl = 1.5
        self.powered_up = False

    def assign_powerup_task(self, desk_x: float, desk_y: float,
                            skill_name: str, task_id: str = ""):
        """Send character to desk to perform Super Saiyan power-up for a Skill task."""
        tx = self.desk_x if self.desk_x is not None else desk_x
        ty = self.desk_y if self.desk_y is not None else desk_y
        self.target_x = tx
        self.target_y = ty
        self.target_callback = "powerup"
        self.state = State.WALKING
        self.state_timer = 0.0
        self.busy = True
        self.current_task_id = task_id
        self._powerup_skill_name = skill_name
        self._powerup_phase = 0
        self._powerup_timer = 0.0
        self.bubble_text = "..."
        self.bubble_type = "thought"
        self.bubble_ttl = 3.0


# Role assignments by character index — gives each elf a specialty
# Role assignments by character index — protagonist gets overridden to "lead"
# by _apply_protagonist_names() after creation
_ROLE_CYCLE = ["engineer", "researcher", "ops", "designer"]


def create_characters(
    theme_name: str,
    count: int,
    scene_w: int,
    scene_h: int,
    desk_positions: list[tuple[float, float]] | None = None,
) -> list[Character]:
    """Create initial characters with assigned roles and desks."""
    theme = THEMES.get(theme_name, THEMES["claude"])
    names = theme["names"]
    chars = []
    for i in range(min(count, len(names))):
        # (A) Assign fixed desk
        dx: float | None = None
        dy: float | None = None
        if desk_positions and i < len(desk_positions):
            dx, dy = desk_positions[i]

        c = Character(
            name=names[i],
            x=random.uniform(3, max(4, scene_w - 10)),
            y=random.uniform(3, max(4, scene_h - 6)),
            color_index=(i % 6) + 1,
            # (A) Fixed desk
            desk_x=dx,
            desk_y=dy,
            # (C) Role specialization
            role=_ROLE_CYCLE[i % len(_ROLE_CYCLE)],
        )
        chars.append(c)
    return chars
