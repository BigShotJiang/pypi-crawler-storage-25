"""Time-of-day atmosphere system for the office."""
from __future__ import annotations

import curses
import time
from dataclasses import dataclass
from enum import Enum


class TimeOfDay(Enum):
    MORNING = "morning"      # 06:00 - 11:59
    AFTERNOON = "afternoon"  # 12:00 - 17:59
    EVENING = "evening"      # 18:00 - 21:59
    NIGHT = "night"          # 22:00 - 05:59


def get_time_of_day() -> TimeOfDay:
    """Get current time of day based on local clock."""
    hour = time.localtime().tm_hour
    if 6 <= hour < 12:
        return TimeOfDay.MORNING
    elif 12 <= hour < 18:
        return TimeOfDay.AFTERNOON
    elif 18 <= hour < 22:
        return TimeOfDay.EVENING
    else:
        return TimeOfDay.NIGHT


@dataclass(frozen=True)
class Atmosphere:
    """Visual atmosphere properties for a time of day."""
    time_of_day: TimeOfDay
    floor_dim: bool           # dim the floor pattern
    furniture_dim: bool       # dim furniture
    char_bold: bool           # characters use bold
    wall_attr_extra: int      # extra curses attr for walls
    status_icon: str          # icon shown in status bar
    status_label: str         # time label for status bar


# Atmosphere presets per time of day
_ATMOSPHERES: dict[TimeOfDay, Atmosphere] = {
    TimeOfDay.MORNING: Atmosphere(
        time_of_day=TimeOfDay.MORNING,
        floor_dim=False,
        furniture_dim=False,
        char_bold=True,
        wall_attr_extra=0,
        status_icon="☀",
        status_label="Morning",
    ),
    TimeOfDay.AFTERNOON: Atmosphere(
        time_of_day=TimeOfDay.AFTERNOON,
        floor_dim=False,
        furniture_dim=False,
        char_bold=True,
        wall_attr_extra=0,
        status_icon="⛅",
        status_label="Afternoon",
    ),
    TimeOfDay.EVENING: Atmosphere(
        time_of_day=TimeOfDay.EVENING,
        floor_dim=True,
        furniture_dim=False,
        char_bold=True,
        wall_attr_extra=curses.A_DIM,
        status_icon="🌆",
        status_label="Evening",
    ),
    TimeOfDay.NIGHT: Atmosphere(
        time_of_day=TimeOfDay.NIGHT,
        floor_dim=True,
        furniture_dim=True,
        char_bold=False,
        wall_attr_extra=curses.A_DIM,
        status_icon="🌙",
        status_label="Night",
    ),
}


def get_atmosphere() -> Atmosphere:
    """Get the current atmosphere based on time of day."""
    return _ATMOSPHERES[get_time_of_day()]
