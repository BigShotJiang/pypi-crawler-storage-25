"""Office scene — central state container with delegation to sub-modules."""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .bubbles import t
from .characters import Character, State, create_characters
from .levels import LEVEL_BY_KEY, LEVEL_DEFS, LevelDef
from . import layout as _layout
from . import task_board as _task_board
from . import hud as _hud
from . import easter_eggs as _easter_eggs
from . import event_dispatch as _event_dispatch
from .sprites import (
    COFFEE_BREWING_1,
    COFFEE_BREWING_2,
    COFFEE_DONE,
    COFFEE_IDLE,
    DOOR_CLOSED,
    DOOR_OPEN,
    DOOR_OPENING,
    MONITOR_BOOT_1,
    MONITOR_BOOT_2,
    MONITOR_OFF,
    MONITOR_ON,
    MONITOR_SHUTDOWN,
    FurnitureItem,
)
from .achievements import AchievementTracker
from .pomodoro import PomodoroTimer, PomodoroPhase
from .weather import WeatherData, WeatherService

HUD_ROWS = 2  # rows reserved above office for HUD (up to 2 lines)

if TYPE_CHECKING:
    from .animation import (
        ExitPlanSequence,
        IntroSequence,
        OutroSequence,
        PlanSequence,
        UpgradeSequence,
    )


COLLEAGUE_NAMES = [
    "Alex", "Sam", "Jordan", "Casey", "Riley",
    "Morgan", "Taylor", "Quinn", "Avery", "Blake",
    "Charlie", "Drew", "Frankie", "Jamie", "Kelly",
]


@dataclass
class Scene:
    """The office scene containing furniture and characters."""
    width: int
    height: int
    theme_name: str = "claude"
    office_level: str = "garage"    # level key from levels.py
    office_mode: str = "auto"       # "auto" or any level key
    protagonist_name: str = ""      # e.g. "Nick(Opus)"
    protagonist_short: str = ""     # e.g. "Nick"
    furniture: list[FurnitureItem] = field(default_factory=list)
    characters: list[Character] = field(default_factory=list)
    task_count: int = 0
    completed_count: int = 0
    _start_time: float = field(default_factory=lambda: __import__("time").monotonic())

    # Per-character task counts for stats
    _char_task_counts: dict[str, int] = field(default_factory=dict)

    # Desk positions for characters to walk to
    _desk_positions: list[tuple[float, float]] = field(default_factory=list)
    # Map desk furniture index → character name (for nameplate rendering)
    _desk_names: dict[int, str] = field(default_factory=dict)
    # Map desk furniture index → subtitle text (model/type, dim row below legs)
    _desk_subtitles: dict[int, str] = field(default_factory=dict)
    _coffee_pos: tuple[float, float] = (0, 0)
    _door_pos: tuple[int, int] = (0, 0)

    # Task history for dynamic whiteboard (newest first, max 10)
    # Each entry: (desc, done, elf_name, start_time, elapsed_on_done, color_index)
    task_log: list[list] = field(default_factory=list)

    # Interaction cooldown
    _interaction_cooldown: float = 0.0

    # Easter egg timer
    _easter_egg_timer: float = 0.0

    # Animated furniture states
    door_state: str = "closed"       # closed, opening, open
    door_timer: float = 0.0
    monitor_state: str = "off"       # off, boot1, boot2, on, shutdown
    monitor_timer: float = 0.0
    coffee_state: str = "idle"       # idle, brewing1, brewing2, done
    coffee_timer: float = 0.0

    # Lighting (None = fully lit, float = radius of lit area)
    light_radius: float | None = None
    light_center: tuple[float, float] = (0.0, 0.0)

    # Animation sequences
    _intro: IntroSequence | None = field(default=None, repr=False)
    _outro: OutroSequence | None = field(default=None, repr=False)
    _plan: PlanSequence | None = field(default=None, repr=False)
    _plan_exit: ExitPlanSequence | None = field(default=None, repr=False)
    _plan_active: bool = False
    _upgrade: UpgradeSequence | None = field(default=None, repr=False)

    # Upgrade animation overlay data (set by UpgradeSequence, read by Renderer)
    upgrade_flash: bool = False                # True during flash frames
    upgrade_overlay: list[str] = field(default_factory=list)  # banner lines
    upgrade_overlay_y: int = 0                 # top row of overlay
    upgrade_overlay_attr: int = 0              # curses attr for overlay text
    upgrade_labels: list[tuple[int, int, str]] = field(default_factory=list)  # (x, y, text)

    # Power-up effects overlay data (keyed by character name)
    # Each value: dict with keys: phase, char_x, char_y, ripple_radius, skill_name
    powerup_effects: dict = field(default_factory=dict)

    # Smith easter egg animation state (one animation at a time)
    # Keys: type (clone/fight/bullet_time), phase, timer, smith_name, target_name,
    #       bullet_x, bullet_y, target_old_theme
    smith_effects: dict = field(default_factory=dict)

    # Weather system
    _weather_service: WeatherService = field(default_factory=WeatherService, repr=False)
    _weather: WeatherData | None = field(default=None, repr=False)
    _weather_tick: float = 0.0
    _rain_drops: list = field(default_factory=list)   # list of (x, y) tuples
    _snow_flakes: list = field(default_factory=list)  # list of (x, y) tuples

    # Pomodoro timer
    _pomodoro: PomodoroTimer = field(default_factory=PomodoroTimer, repr=False)
    _pomo_banner_timer: float = 0.0
    _bell_pending: bool = False

    # Recent task completions for HIGH_FIVE detection: list of (char_name, timestamp)
    _recent_completions: list = field(default_factory=list)
    # Wall-clock time when this session started (for HUD elapsed display)
    _session_start_wall: float = field(
        default_factory=lambda: __import__("time").time(), repr=False
    )

    # Achievement system
    _achievements: AchievementTracker = field(default_factory=AchievementTracker, repr=False)
    _achievement_check_timer: float = 0.0

    @property
    def intro_active(self) -> bool:
        return self._intro is not None and not self._intro.is_complete

    @property
    def outro_active(self) -> bool:
        return self._outro is not None and not self._outro.is_complete

    @property
    def outro_complete(self) -> bool:
        return self._outro is not None and self._outro.is_complete

    @property
    def plan_active(self) -> bool:
        return self._plan_active

    # (B) Task ID counter for tracking
    _next_task_id: int = 0

    # Reserve bottom rows for task box + status bar
    TASK_BOX_RESERVE = 11  # border + working(3) + sep + done(3) + border + status + margin

    def populate(self, with_characters: bool = True):
        """Place furniture based on office level and scene size."""
        self.furniture.clear()
        self._desk_positions.clear()
        self._desk_type_idx = 0

        w = self.width
        h = self.height - self.TASK_BOX_RESERVE - HUD_ROWS  # HUD_ROWS=2 always reserved

        level_def = LEVEL_BY_KEY.get(self.office_level, LEVEL_DEFS[0])
        # Elf count from level def, clamped by screen width
        max_by_width = 2 if w < 40 else (3 if w < 55 else 4)
        char_count = min(level_def.elf_count, max_by_width)

        self._layout_office(w, h, level_def, char_count)

        if with_characters:
            self.characters = create_characters(
                self.theme_name, char_count, w, h,
                desk_positions=self._desk_positions,
            )
            self._apply_protagonist_names()
            self._assign_desk_names()

    def start_intro(self) -> None:
        """Start the opening animation (dark → lights → agents arrive)."""
        from .animation import IntroSequence

        # Place furniture but no characters (intro will spawn them)
        self.populate(with_characters=False)
        self.light_radius = 0.0
        self.light_center = (self.width * 0.4, self.height * 0.4)

        self._intro = IntroSequence(scene=self)
        self._intro.start()

    def start_outro(self) -> None:
        """Start the closing animation (goodbye → lights off → exit)."""
        from .animation import OutroSequence

        self._outro = OutroSequence(scene=self)
        self._outro.start()

    def _get_door_position(self) -> tuple[int, int]:
        """Return the (x, y) of the door furniture item."""
        return self._door_pos

    _desk_type_idx: int = 0

    def _apply_protagonist_names(self) -> None:
        """Set protagonist name on characters[0] and random names on others."""
        if not self.characters:
            return
        # Protagonist is always characters[0]
        if self.protagonist_name:
            self.characters[0].name = self.protagonist_name
            self.characters[0].role = "lead"

        # Other elves get random names from the pool (no model tag)
        if len(self.characters) > 1:
            pool = list(COLLEAGUE_NAMES)
            # Don't use the protagonist's short name as a colleague name
            short = self.protagonist_short
            if short in pool:
                pool.remove(short)
            chosen = random.sample(pool, min(len(self.characters) - 1, len(pool)))
            for i, name in enumerate(chosen, start=1):
                self.characters[i].name = name

    def _assign_desk_names(self) -> None:
        """Map each desk to its assigned character's name and build subtitle map."""
        self._desk_names.clear()
        self._desk_subtitles.clear()
        desk_items = [i for i, f in enumerate(self.furniture) if f.foreground]
        for char in self.characters:
            if char.desk_x is None or char.desk_y is None:
                continue
            # Find which desk this character belongs to
            for di in desk_items:
                item = self.furniture[di]
                if abs(item.x + 4 - char.desk_x) < 2 and abs(item.y - 1 - char.desk_y) < 2:
                    # Nameplate shows short name; subtitle shows (model) part
                    if "(" in char.name and char.name.endswith(")"):
                        short = char.name[:char.name.index("(")]
                        subtitle = char.name[char.name.index("("):]
                    else:
                        short = char.name
                        subtitle = ""
                    self._desk_names[di] = short
                    if subtitle:
                        self._desk_subtitles[di] = subtitle
                    break

    def _add_desk(self, x: int, y: int, sprite: list[str] | None = None) -> None:
        _layout.add_desk(self, x, y, sprite)

    # ------------------------------------------------------------------
    # Data-driven office layout (10 levels)
    # ------------------------------------------------------------------

    def _layout_office(self, w: int, h: int, level_def: LevelDef,
                       char_count: int) -> None:
        _layout.layout_office(self, w, h, level_def, char_count)

    def upgrade_office(self, new_level: str) -> None:
        """Upgrade office layout with animation."""
        if new_level == self.office_level:
            return
        old_level = self.office_level
        self.office_level = new_level
        from .animation import UpgradeSequence
        self._upgrade = UpgradeSequence(scene=self, new_level=new_level, old_level=old_level)
        self._upgrade.start()

    def _check_auto_upgrade(self) -> None:
        """Check if office should auto-upgrade based on completed tasks."""
        if self.office_mode != "auto":
            return
        if self._upgrade and not self._upgrade.is_complete:
            return  # upgrade already in progress
        current = LEVEL_BY_KEY.get(self.office_level, LEVEL_DEFS[0])
        next_idx = current.index + 1
        if next_idx < len(LEVEL_DEFS):
            next_def = LEVEL_DEFS[next_idx]
            if self.completed_count >= next_def.session_threshold:
                self.upgrade_office(next_def.key)

    def resize(self, new_w: int, new_h: int):
        """Handle terminal resize."""
        old_chars = self.characters
        self.width = new_w
        self.height = new_h
        self.populate(with_characters=not self.intro_active)
        if old_chars and not self.intro_active:
            for i, c in enumerate(old_chars):
                if i < len(self.characters):
                    self.characters[i].name = c.name
                    self.characters[i].state = c.state
                    self.characters[i].busy = c.busy
                    self.characters[i].bubble_text = c.bubble_text
                    self.characters[i].bubble_type = c.bubble_type
                    self.characters[i].bubble_ttl = c.bubble_ttl
                    self.characters[i].x = min(c.x, new_w - 8)
                    self.characters[i].y = min(c.y, new_h - 6)

    def tick(self, dt: float):
        """Update all characters and animation sequences."""
        # Intro/outro sequences manage their own logic
        if self._intro and not self._intro.is_complete:
            self._intro.tick(dt)
            self.light_radius = self._intro.light_radius
            if self._intro.light_center:
                self.light_center = self._intro.light_center

        if self._outro and not self._outro.is_complete:
            self._outro.tick(dt)
            self.light_radius = self._outro.light_radius
            if self._outro.light_center:
                self.light_center = self._outro.light_center

        # Upgrade sequence (paused during plan mode)
        if self._upgrade and not self._upgrade.is_complete and not self._plan_active:
            self._upgrade.tick(dt)

        # Plan mode sequences
        if self._plan and not self._plan.is_complete:
            self._plan.tick(dt)
        if self._plan_exit and not self._plan_exit.is_complete:
            self._plan_exit.tick(dt)

        # Tick all characters
        for c in self.characters:
            c.tick(dt, self.width, self.height)

        # The following effects are paused during plan mode
        if not self._plan_active:
            # Auto-stretch after long typing/thinking/reading
            for c in self.characters:
                if c.state in (State.TYPING, State.THINKING, State.READING) and c.state_timer > 45:
                    if random.random() < 0.02:
                        c._pre_stretch_state = c.state.value
                        c.state = State.STRETCHING
                        c.state_timer = 0.0
                        c.bubble_text = t("stretch_yawn")
                        c.bubble_type = "thought"
                        c.bubble_ttl = 2.5

            # Sync power-up effect overlay data
            self._tick_powerup_effects(dt)

            # Smith easter egg animations
            self._tick_smith_effects(dt)

        # Animated furniture
        self._tick_furniture_animations(dt)

        # Weather update (every 10s check, actual API call every 10min)
        self._weather_tick += dt
        if self._weather_tick >= 10.0:
            self._weather_tick = 0.0
            self._weather = self._weather_service.get_weather()

        # Pomodoro timer
        self._pomodoro.tick(dt)
        transition = self._pomodoro.consume_transition()
        if transition == "to_break":
            self._show_pomodoro_banner("break")
            self._start_pomodoro_break()
        elif transition == "to_work":
            self._show_pomodoro_banner("work")
            self._end_pomodoro_break()

        # Auto-dismiss Pomodoro banner after 3 seconds
        if self._pomo_banner_timer > 0:
            self._pomo_banner_timer -= dt
            if self._pomo_banner_timer <= 0:
                self.upgrade_overlay = []
                self.upgrade_flash = False

        # Achievement checks (every ~2 seconds, paused during plan mode)
        self._achievement_check_timer += dt
        if self._achievement_check_timer >= 2.0 and not self._plan_active:
            self._achievement_check_timer = 0.0
            self._achievements.check(self)
            # Show unlock banner if any
            notif = self._achievements.pop_notification()
            if notif:
                if not self.upgrade_overlay:
                    self._show_achievement_banner(notif)
                else:
                    # Push back — show when current overlay clears
                    self._achievements._pending_notifications.insert(0, notif)

        # Interactions and easter eggs (only during normal mode)
        if not self.intro_active and not self.outro_active and not self._plan_active:
            self._check_interactions()
            self._check_easter_eggs(dt)

        # Contractor lifecycle: place/remove temp desks at state transitions
        for c in self.characters:
            if c.is_agent and c.state == State.SETTING_UP and c.state_timer < dt * 2:
                # Just entered SETTING_UP — place the temp desk
                self._add_temp_desk(c)
            elif c.is_agent and c.state == State.PACKING_UP and c.state_timer < dt * 2:
                # Just entered PACKING_UP — remove the temp desk
                self._remove_temp_desk(c)
                self.open_door()  # open door for departure

        # Safety net: Smith idle too long without departure timer → force depart
        for c in self.characters:
            if (c.is_agent and not c.busy and not c._departure_pending
                    and not c._departed and c._idle_before_depart <= 0
                    and c.state == State.IDLE and c.state_timer > 30):
                c._idle_before_depart = 1.0  # depart soon

        # Remove departed characters + clean up empty "removed" furniture
        self.characters = [c for c in self.characters if not c._departed]
        self.furniture = [f for f in self.furniture if f.name != "removed"]

    def handle_event(self, event: dict):
        _event_dispatch.handle_event(self, event)

    def _start_plan_mode(self) -> None:
        _event_dispatch.start_plan_mode(self)

    def _exit_plan_mode(self) -> None:
        _event_dispatch.exit_plan_mode(self)

    def _make_task_id(self, tool: str) -> str:
        return _event_dispatch.make_task_id(self, tool)

    def _on_tool_start(self, event: dict):
        _event_dispatch.on_tool_start(self, event)

    # ── Animated furniture ──────────────────────────────────────────

    def open_door(self) -> None:
        """Trigger door opening animation."""
        if self.door_state == "closed":
            self.door_state = "opening"
            self.door_timer = 0.0

    def close_door(self) -> None:
        """Trigger door closing animation."""
        if self.door_state in ("open", "opening"):
            self.door_state = "closing"
            self.door_timer = 0.0

    def boot_monitors(self) -> None:
        """Trigger monitor boot-up sequence."""
        if self.monitor_state == "off":
            self.monitor_state = "boot1"
            self.monitor_timer = 0.0

    def shutdown_monitors(self) -> None:
        """Trigger monitor shutdown sequence."""
        if self.monitor_state == "on":
            self.monitor_state = "shutdown"
            self.monitor_timer = 0.0

    def start_coffee(self) -> None:
        """Trigger coffee brewing animation."""
        if self.coffee_state == "idle":
            self.coffee_state = "brewing1"
            self.coffee_timer = 0.0

    def _tick_furniture_animations(self, dt: float) -> None:
        """Advance animated furniture states."""
        # Door
        self.door_timer += dt
        if self.door_state == "opening" and self.door_timer >= 0.5:
            self.door_state = "open"
        elif self.door_state == "closing" and self.door_timer >= 0.5:
            self.door_state = "closed"

        # Monitors
        self.monitor_timer += dt
        if self.monitor_state == "boot1" and self.monitor_timer >= 0.4:
            self.monitor_state = "boot2"
            self.monitor_timer = 0.0
        elif self.monitor_state == "boot2" and self.monitor_timer >= 0.4:
            self.monitor_state = "on"
        elif self.monitor_state == "shutdown" and self.monitor_timer >= 0.6:
            self.monitor_state = "off"

        # Coffee
        self.coffee_timer += dt
        if self.coffee_state == "brewing1" and self.coffee_timer >= 1.0:
            self.coffee_state = "brewing2"
            self.coffee_timer = 0.0
        elif self.coffee_state == "brewing2" and self.coffee_timer >= 1.0:
            self.coffee_state = "done"
            self.coffee_timer = 0.0
        elif self.coffee_state == "done" and self.coffee_timer >= 3.0:
            self.coffee_state = "idle"

    def _tick_powerup_effects(self, dt: float) -> None:
        """Sync powerup_effects overlay data from characters currently in POWER_UP state."""
        active_names: set[str] = set()
        for char in self.characters:
            if char.state == State.POWER_UP:
                active_names.add(char.name)
                phase = char._powerup_phase
                timer = char._powerup_timer

                # Ripple radius grows from 3.0 to 6.0 over the 1.5s burst phase
                if phase == 2:
                    ripple_radius = 3.0 + min(timer / 1.5, 1.0) * 3.0
                else:
                    ripple_radius = 0.0

                self.powerup_effects[char.name] = {
                    "phase": phase,
                    "char_x": char.x,
                    "char_y": char.y,
                    "ripple_radius": ripple_radius,
                    "skill_name": char._powerup_skill_name,
                }

        # Remove entries for characters no longer in POWER_UP
        for name in list(self.powerup_effects.keys()):
            if name not in active_names:
                del self.powerup_effects[name]

    def _tick_smith_effects(self, dt: float) -> None:
        _easter_eggs.tick_smith_effects(self, dt)

    def get_door_sprite(self) -> list[str]:
        """Get current door sprite based on animation state."""
        if self.door_state == "opening":
            return DOOR_OPENING
        elif self.door_state == "open":
            return DOOR_OPEN
        return DOOR_CLOSED

    def get_monitor_pixels(self) -> str:
        """Get current monitor pixel pattern based on state."""
        return {
            "off": MONITOR_OFF,
            "boot1": MONITOR_BOOT_1,
            "boot2": MONITOR_BOOT_2,
            "on": MONITOR_ON,
            "shutdown": MONITOR_SHUTDOWN,
        }.get(self.monitor_state, MONITOR_OFF)

    def get_coffee_sprite(self) -> list[str]:
        """Get current coffee machine sprite based on state."""
        return {
            "idle": COFFEE_IDLE,
            "brewing1": COFFEE_BREWING_1,
            "brewing2": COFFEE_BREWING_2,
            "done": COFFEE_DONE,
        }.get(self.coffee_state, COFFEE_IDLE)

    def _check_interactions(self) -> None:
        _easter_eggs.check_interactions(self)

    def _check_easter_eggs(self, dt: float) -> None:
        _easter_eggs.check_easter_eggs(self, dt)

    def _add_task_entry(self, desc: str, elf_name: str, color_idx: int) -> None:
        _task_board.add_task_entry(self, desc, elf_name, color_idx)

    def _mark_task_done(self) -> None:
        _task_board.mark_task_done(self)

    def _on_tool_end_quiet(self, event: dict):
        _event_dispatch.on_tool_end_quiet(self, event)

    def _on_tool_end(self, event: dict):
        _event_dispatch.on_tool_end(self, event)

    def _pick_character_for_tool(self, tool: str) -> Character | None:
        return _event_dispatch.pick_character_for_tool(self, tool)

    def _pick_free_desk(self) -> tuple[float, float]:
        return _event_dispatch.pick_free_desk(self)

    def _find_open_spot(self) -> tuple[int, int]:
        return _layout.find_open_spot(self)

    def _add_temp_desk(self, char: Character) -> None:
        _layout.add_temp_desk(self, char)

    def _remove_temp_desk(self, char: Character) -> None:
        _layout.remove_temp_desk(self, char)

    def get_task_box_lines(self, box_w: int) -> list[tuple[str, int]]:
        return _task_board.get_task_box_lines(self, box_w)

    def get_status_line(self, max_w: int) -> str:
        return _hud.get_status_line(self, max_w)

    def get_hud_lines(self, max_w: int) -> list[str]:
        return _hud.get_hud_lines(self, max_w)

    def _show_pomodoro_banner(self, event: str) -> None:
        _hud.show_pomodoro_banner(self, event)

    def _show_achievement_banner(self, achievement) -> None:
        _hud.show_achievement_banner(self, achievement)

    def _start_pomodoro_break(self) -> None:
        _hud.start_pomodoro_break(self)

    def _end_pomodoro_break(self) -> None:
        _hud.end_pomodoro_break(self)
