#!/usr/bin/env python3
"""Agent Elves - ASCII art office animation engine.

Copyright (c) 2025 Nickdevlab. All rights reserved.

Usage:
    python3 engine/main.py --session-id <id> --socket <path> [--theme claude|kaomoji|pixel]
"""
from __future__ import annotations

import argparse
import curses
import json
import os
import signal
import subprocess
import sys
import time

# Ensure package imports work when run directly
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine.config import (
    VERSION,
    CONFIG_PATH,
    CRASH_LOG,
    VALID_THEMES,
    VALID_LANGS,
    VALID_OFFICES,
    OFFICE_UNLOCK_THRESHOLDS,
    OFFICE_SESSION_THRESHOLDS,
    load_config,
    save_config,
)
from engine.ipc import EventReceiver
from engine.renderer import Renderer, init_colors
from engine.scene import Scene
from engine.sprites import THEMES
from engine.ui_pickers import (
    LOGO,
    COPYRIGHT,
    _safe_addstr,
    _show_dashboard,
    _theme_picker,
    _theme_editor,
    _lang_picker,
    _office_picker,
    _welcome_screen,
    _autostart_picker,
    _reset_progress_picker,
    setup_wizard,
)

FRAME_INTERVAL = 0.1  # ~10fps


def _get_user_name() -> str:
    """Get user display name: config.json user_name > git config > 'You'."""
    try:
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
            name = cfg.get("user_name", "")
            if name:
                return str(name)
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    try:
        result = subprocess.run(
            ["git", "config", "user.name"],
            capture_output=True, text=True, timeout=2,
        )
        name = result.stdout.strip()
        if name:
            return name.split()[0]  # First name only
    except (OSError, subprocess.TimeoutExpired):
        pass
    return "You"


def _get_model_name() -> str:
    """Get current Claude model name from environment or default."""
    model = os.environ.get("CLAUDE_MODEL", "")
    if not model:
        model = os.environ.get("ANTHROPIC_MODEL", "")
    if "opus" in model.lower():
        return "Opus"
    elif "sonnet" in model.lower():
        return "Sonnet"
    elif "haiku" in model.lower():
        return "Haiku"
    return "Claude"


# ── Main loop ──────────────────────────────────────────────────────

def run(stdscr, session_id: str, sock_path: str,
        theme: str, lang: str,
        office: str = "auto", total_tasks: int = 0,
        unlocked_offices: list[str] | None = None,
        user_name: str = "", model_name: str = ""):
    """Main animation loop."""
    from engine.bubbles import set_language

    if not user_name:
        user_name = _get_user_name()
    if not model_name:
        model_name = _get_model_name()

    curses.curs_set(0)
    stdscr.nodelay(True)
    stdscr.timeout(0)
    init_colors()

    if unlocked_offices is None:
        unlocked_offices = ["startup"]

    h, w = stdscr.getmaxyx()

    # First-launch wizard if needed
    if not theme or not lang:
        picked_theme, picked_lang, picked_auto, picked_office, _ = setup_wizard(
            stdscr, first_launch=True,
            unlocked_offices=unlocked_offices, current_office=office,
        )
        theme = theme or picked_theme
        lang = lang or picked_lang
        autostart = picked_auto or "auto"
        office = picked_office or office
        save_config(theme, lang, autostart, office, total_tasks, unlocked_offices)
        stdscr.nodelay(True)
        stdscr.timeout(0)

    set_language(lang)

    # IPC
    receiver = EventReceiver(sock_path)
    receiver.start()

    # Scene — start with intro animation (always Lv.1 in auto mode)
    start_level = "garage" if office == "auto" else office
    protagonist_name = f"{user_name}({model_name})"
    scene = Scene(width=w, height=h, theme_name=theme,
                  office_level=start_level, office_mode=office,
                  protagonist_name=protagonist_name,
                  protagonist_short=user_name)

    # Weather config — read lat/lon/city from config.json if available
    try:
        with open(CONFIG_PATH) as f:
            _cfg = json.load(f)
            _lat = _cfg.get("latitude")
            _lon = _cfg.get("longitude")
            _city = _cfg.get("city")
            if _lat is not None and _lon is not None:
                scene._weather_service.configure(float(_lat), float(_lon))
            if _city:
                scene._weather_service._city = str(_city)
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        pass

    scene.start_intro()
    _last_saved_tasks = scene.completed_count

    # Renderer
    renderer = Renderer(stdscr)

    running = True

    def handle_sigterm(*_args):
        nonlocal running
        running = False

    signal.signal(signal.SIGTERM, handle_sigterm)

    try:
        while running:
            frame_start = time.monotonic()

            # 1. Drain IPC events
            for event in receiver.drain():
                if event.get("type") == "shutdown":
                    if not scene.outro_active:
                        scene.start_outro()
                    continue
                scene.handle_event(event)

            # Check if outro finished
            if scene.outro_complete:
                running = False
                break

            # 2. Check for key input
            try:
                ch = stdscr.getch()
                if ch == ord("q"):
                    if not scene.outro_active:
                        scene.start_outro()
                elif ch == ord("p") and not scene.intro_active and not scene.outro_active:
                    from engine.pomodoro import PomodoroPhase
                    was_off = scene._pomodoro.phase == PomodoroPhase.OFF
                    scene._pomodoro.toggle()
                    if was_off:
                        scene._show_pomodoro_banner("start")
                elif ch == ord("d") and not scene.intro_active and not scene.outro_active:
                    # Dashboard overlay
                    _show_dashboard(stdscr, scene)
                    stdscr.nodelay(True)
                    stdscr.timeout(0)
                    renderer.prev.clear()
                elif ch == ord("s") and not scene.intro_active and not scene.outro_active:
                    # Settings menu
                    stdscr.nodelay(False)
                    current_total = total_tasks + scene.completed_count
                    new_theme, new_lang, _, new_office, reset = setup_wizard(
                        stdscr,
                        unlocked_offices=unlocked_offices,
                        current_office=office,
                        total_tasks=current_total,
                    )
                    if reset:
                        total_tasks = 0
                        scene.completed_count = 0
                        unlocked_offices = ["garage"]
                        office = "auto"
                        scene.office_mode = "auto"
                        scene.office_level = "garage"
                        scene.populate(with_characters=True)
                        _last_saved_tasks = 0
                    else:
                        if new_theme:
                            theme = new_theme
                            scene.theme_name = theme
                        if new_lang:
                            lang = new_lang
                            set_language(lang)
                        if new_office and new_office != office:
                            office = new_office
                            scene.office_mode = office
                            new_level = "garage" if office == "auto" else office
                            if new_level != scene.office_level:
                                scene.upgrade_office(new_level)
                    save_config(theme, lang, office=office,
                                total_tasks=total_tasks + scene.completed_count,
                                unlocked_offices=unlocked_offices)
                    scene.resize(w, h)
                    renderer.prev.clear()
                    stdscr.nodelay(True)
                    stdscr.timeout(0)
                elif ch == curses.KEY_RESIZE:
                    h, w = stdscr.getmaxyx()
                    scene.resize(w, h)
                    renderer.prev.clear()
            except curses.error:
                pass

            # 2b. Periodically save task progress (every 10 tasks)
            current_tasks = total_tasks + scene.completed_count
            if scene.completed_count - _last_saved_tasks >= 10:
                _last_saved_tasks = scene.completed_count
                # Update unlock list
                for lvl, thresh in OFFICE_UNLOCK_THRESHOLDS.items():
                    if current_tasks >= thresh and lvl not in unlocked_offices:
                        unlocked_offices.append(lvl)
                save_config(theme, lang, office=office,
                            total_tasks=current_tasks,
                            unlocked_offices=unlocked_offices)

            # 3. Update scene
            scene.tick(FRAME_INTERVAL)

            # 4. Check terminal resize
            new_h, new_w = stdscr.getmaxyx()
            if new_h != h or new_w != w:
                h, w = new_h, new_w
                scene.resize(w, h)
                renderer.prev.clear()

            # 5. Render
            renderer.draw(scene)

            # 6. Sleep remainder of frame
            elapsed = time.monotonic() - frame_start
            sleep_time = max(0, FRAME_INTERVAL - elapsed)
            if sleep_time > 0:
                time.sleep(sleep_time)
    finally:
        # Save final task count on shutdown
        final_total = total_tasks + scene.completed_count
        for lvl, thresh in OFFICE_UNLOCK_THRESHOLDS.items():
            if final_total >= thresh and lvl not in unlocked_offices:
                unlocked_offices.append(lvl)
        save_config(theme, lang, office=office,
                    total_tasks=final_total,
                    unlocked_offices=unlocked_offices)
        receiver.close()


# ── Entry point ────────────────────────────────────────────────────

def main():
    import traceback

    parser = argparse.ArgumentParser(description="Agent Elves Animation")
    parser.add_argument("--session-id", default="default")
    parser.add_argument("--socket", required=True)
    parser.add_argument("--theme", default="", choices=["claude", "kaomoji", "pixel", ""])
    parser.add_argument("--lang", default="", choices=["en", "ja", "zh", "ko", ""])
    args = parser.parse_args()

    saved_theme, saved_lang, _saved_auto, saved_office, saved_total, saved_unlocked = load_config()
    theme = args.theme or saved_theme
    lang = args.lang or saved_lang

    user_name = _get_user_name()
    model_name = _get_model_name()

    try:
        curses.wrapper(lambda stdscr: run(
            stdscr, args.session_id, args.socket, theme, lang,
            office=saved_office, total_tasks=saved_total,
            unlocked_offices=saved_unlocked,
            user_name=user_name, model_name=model_name,
        ))
    except Exception:
        with open(CRASH_LOG, "a") as f:
            f.write(f"\n--- crash at {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
            traceback.print_exc(file=f)


if __name__ == "__main__":
    main()
