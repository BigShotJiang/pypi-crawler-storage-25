"""Office furniture layout — extracted from scene.py."""
from __future__ import annotations

import random
from typing import TYPE_CHECKING

from .sprites import (
    ARCADE_CABINET,
    BAR,
    BIKE,
    BOOKSHELF,
    COFFEE_MACHINE,
    DESK,
    DESK_PORTABLE,
    DESK_SINGLE,
    DESK_SMALL,
    DOOR,
    GOLD_TROPHY_WALL,
    PLANT,
    SERVER_RACK,
    SOFA,
    TROPHY_CASE,
    WATERCOOLER,
    WHITEBOARD,
    WINDOW_LARGE,
    WINDOW_MEDIUM,
    WINDOW_SMALL,
    FurnitureItem,
)
from .levels import LevelDef

if TYPE_CHECKING:
    from .characters import Character
    from .scene import Scene

DESK_TYPES = [DESK, DESK_SINGLE, DESK, DESK_SINGLE, DESK, DESK_SINGLE]


def layout_office(scene: Scene, w: int, h: int, level_def: LevelDef, char_count: int) -> None:
    """Place furniture based on level definition."""
    furn = set(level_def.furniture)
    lv = level_def.index  # 0-9

    # --- Door position: left wall (lv 0-3), right-top (lv 4-6), top-center (lv 7-9)
    if lv <= 3:
        scene._door_pos = (1, 1)
    elif lv <= 6:
        scene._door_pos = (max(w - 12, w // 2 + 5), 1)
    else:
        scene._door_pos = (max(1, w // 3 - 3), 1)
    scene.furniture.append(FurnitureItem("door", DOOR, *scene._door_pos))

    top_x = 2
    if "bookshelf" in furn:
        if scene._door_pos[0] > 14 or scene._door_pos[0] == 1:
            bx = 10 if scene._door_pos[0] == 1 else 2
            scene.furniture.append(FurnitureItem("bookshelf", BOOKSHELF, bx, 1))
            top_x = bx + 13
    if "trophy" in furn:
        trophy_x = max(top_x + 2, w // 2 - 5)
        door_right = scene._door_pos[0] + 8
        if trophy_x < door_right + 2:
            trophy_x = door_right + 2
        if trophy_x + 10 < w - 4:
            scene.furniture.append(FurnitureItem("trophy", TROPHY_CASE, trophy_x, 1))
            top_x = trophy_x + 12

    if "gold_wall" in furn:
        gx = top_x + 16
        if gx < scene._door_pos[0] + 10:
            gx = scene._door_pos[0] + 10
        if gx + 14 < w - 10:
            scene.furniture.append(FurnitureItem("gold_wall", GOLD_TROPHY_WALL, gx, 1))
            top_x = gx + 14

    if "server" in furn:
        scene.furniture.append(FurnitureItem("server", SERVER_RACK, w - 10, 1))

    top_occupied: list[tuple[int, int]] = []
    for item in scene.furniture:
        if item.y == 1:
            top_occupied.append((item.x, item.x + item.width + 2))

    def _fits_top(wx: int, ww: int) -> bool:
        for ox1, ox2 in top_occupied:
            if wx < ox2 and wx + ww > ox1:
                return False
        return 1 < wx and wx + ww < w - 2

    if lv <= 1:
        for wx in range(w // 2, 2, -2):
            if _fits_top(wx, 8):
                scene.furniture.append(FurnitureItem("window_small", WINDOW_SMALL, wx, 1))
                top_occupied.append((wx, wx + 10))
                break
    elif lv <= 3:
        placed = 0
        for wx in range(w // 3, 2, -2):
            if _fits_top(wx, 8) and placed < 2:
                scene.furniture.append(FurnitureItem("window_small", WINDOW_SMALL, wx, 1))
                top_occupied.append((wx, wx + 10))
                placed += 1
        for wx in range(2 * w // 3, w // 2, -2):
            if _fits_top(wx, 8) and placed < 2:
                scene.furniture.append(FurnitureItem("window_small", WINDOW_SMALL, wx, 1))
                top_occupied.append((wx, wx + 10))
                placed += 1
    elif lv <= 5:
        for wx in range(w // 2, 2, -2):
            if _fits_top(wx, 12):
                scene.furniture.append(FurnitureItem("window_medium", WINDOW_MEDIUM, wx, 1))
                top_occupied.append((wx, wx + 14))
                break
    elif lv <= 8:
        placed = 0
        for wx in range(w // 4, 2, -2):
            if _fits_top(wx, 12) and placed < 1:
                scene.furniture.append(FurnitureItem("window_medium", WINDOW_MEDIUM, wx, 1))
                top_occupied.append((wx, wx + 14))
                placed += 1
        for wx in range(3 * w // 4, w // 2, -2):
            if _fits_top(wx, 12) and placed < 2:
                scene.furniture.append(FurnitureItem("window_medium", WINDOW_MEDIUM, wx, 1))
                top_occupied.append((wx, wx + 14))
                placed += 1
    else:
        for wx in range(w // 2 - 12, 2, -2):
            if _fits_top(wx, 24):
                scene.furniture.append(FurnitureItem("window_large", WINDOW_LARGE, wx, 1))
                break

    desk_w = 12
    gap = 3
    desk_count = level_def.desk_count
    desk_sprite = DESK_SMALL if lv <= 2 else None

    row1_y = 8
    row2_y = min(row1_y + 7, h - 8)
    left_x = 4
    left_x2 = left_x + (8 if lv >= 7 else 0)

    desks_placed = 0
    for i in range(min(2, desk_count)):
        dx = left_x + i * (desk_w + gap)
        if dx + desk_w < w - 2:
            add_desk(scene, dx, row1_y, desk_sprite)
            desks_placed += 1
    remaining = desk_count - desks_placed
    for i in range(remaining):
        dx = left_x2 + i * (desk_w + gap)
        if dx + desk_w < w - 2:
            add_desk(scene, dx, row2_y, desk_sprite)

    right_x = w - 14
    if "whiteboard" in furn and w > 40:
        scene.furniture.append(
            FurnitureItem("whiteboard", WHITEBOARD, right_x, row1_y))

    if "arcade" in furn and w > 50:
        arcade_y = max(row1_y + 5, row2_y - 1)
        scene.furniture.append(FurnitureItem("arcade", ARCADE_CABINET, right_x, arcade_y))

    coffee_x = w - 14
    if "coffee" in furn:
        coffee_y = h - 7
        if coffee_x > w // 2:
            scene.furniture.append(
                FurnitureItem("coffee", COFFEE_MACHINE, coffee_x, coffee_y))
            scene._coffee_pos = (float(coffee_x - 5), float(coffee_y + 1))
        else:
            scene._coffee_pos = (float(w - 10), float(h - 4))

    if "plant" in furn and w > 50:
        plant_x = min(w - 22, coffee_x - 7)
        scene.furniture.append(FurnitureItem("plant", PLANT, plant_x, h - 4))

    if "sofa" in furn and w > 45:
        sofa_x = max(w // 2 - 5, left_x2 + desk_w + 4)
        sofa_y = max(h - 4, row2_y + 6)
        coffee_left = w - 14 if "coffee" in furn else w
        if sofa_x + 10 > coffee_left - 2:
            sofa_x = max(2, coffee_left - 12)
        if "bar" in furn and sofa_x < 16:
            sofa_x = 16
        scene.furniture.append(FurnitureItem("sofa", SOFA, sofa_x, sofa_y))

    if "watercooler" in furn and w >= 50:
        wc_x = max(w // 3, 15)
        wc_y = max(row2_y + 8, h - 10)
        scene.furniture.append(FurnitureItem("watercooler", WATERCOOLER, wc_x, wc_y))

    if "bar" in furn:
        bar_x = max(2, left_x)
        bar_y = max(h - 6, row2_y + 7)
        scene.furniture.append(FurnitureItem("bar", BAR, bar_x, bar_y))

    if "bike" in furn and w > 40:
        bike_x = 16 if "bar" in furn else 2
        bike_y = max(h - 4, row2_y + 7)
        scene.furniture.append(FurnitureItem("bike", BIKE, bike_x, bike_y))


def add_desk(scene: Scene, x: int, y: int, sprite: list[str] | None = None) -> None:
    """Add a desk and register the sitting position behind it."""
    if sprite is None:
        sprite = DESK_TYPES[scene._desk_type_idx % len(DESK_TYPES)]
        scene._desk_type_idx += 1
    scene.furniture.append(FurnitureItem("desk", sprite, x, y, foreground=True))
    scene._desk_positions.append((float(x + 4), float(y - 2)))


def find_open_spot(scene: Scene) -> tuple[int, int]:
    """Find an open floor spot for a temporary desk (no overlap)."""
    w = scene.width
    h = scene.height - scene.TASK_BOX_RESERVE
    desk_w, desk_h = 12, 5
    boxes: list[tuple[int, int, int, int]] = []
    for item in scene.furniture:
        boxes.append((item.x, item.y, item.x + item.width, item.y + item.height))
    candidates: list[tuple[int, int]] = []
    for ty in range(5, h - desk_h - 1, 3):
        for tx in range(w // 3, w - desk_w - 2, 4):
            ok = True
            for bx1, by1, bx2, by2 in boxes:
                if tx - 1 < bx2 and tx + desk_w + 1 > bx1 and ty - 1 < by2 and ty + desk_h + 1 > by1:
                    ok = False
                    break
            if ok:
                candidates.append((tx, ty))
    if candidates:
        return random.choice(candidates)
    return (max(4, w - desk_w - 4), h // 2)


def add_temp_desk(scene: Scene, char: Character) -> None:
    """Place a portable desk at the character's position."""
    dx = int(char.x) - 1
    dy = int(char.y) + 2
    desk_item = FurnitureItem("desk_portable", DESK_PORTABLE, dx, dy, foreground=True)
    scene.furniture.append(desk_item)
    char._temp_desk_idx = len(scene.furniture) - 1
    char.desk_x = float(dx + 4)
    char.desk_y = float(dy - 2)
    scene._desk_positions.append((char.desk_x, char.desk_y))


def remove_temp_desk(scene: Scene, char: Character) -> None:
    """Remove the portable desk placed by a contractor."""
    if char.desk_x is None or char.desk_y is None:
        return
    for i, item in enumerate(scene.furniture):
        if (item.name == "desk_portable"
                and abs(item.x + 4 - char.desk_x) < 0.5
                and abs(item.y - 2 - char.desk_y) < 0.5):
            scene.furniture[i] = FurnitureItem("removed", [], item.x, item.y)
            break
    pos = (char.desk_x, char.desk_y)
    if pos in scene._desk_positions:
        scene._desk_positions.remove(pos)
    char._temp_desk_idx = -1
