"""Achievement system — unlock badges for milestones."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .scene import Scene

SAVE_PATH = os.path.expanduser("~/.config/agent-elves/achievements.json")


@dataclass(frozen=True)
class Achievement:
    id: str
    icon: str
    name: dict[str, str]  # {en: ..., ja: ..., zh: ..., ko: ...}
    desc: dict[str, str]  # {en: ..., ja: ..., zh: ..., ko: ...}


# All achievements
ACHIEVEMENTS: list[Achievement] = [
    Achievement("first_task", "🎯",
        {"en": "First Task", "ja": "初仕事", "zh": "首個任務", "ko": "첫 작업"},
        {"en": "Complete your first task", "ja": "初めてのタスク完了", "zh": "完成第一個任務", "ko": "첫 작업 완료"}),
    Achievement("task_10", "⭐",
        {"en": "Getting Started", "ja": "始動", "zh": "起步", "ko": "시작"},
        {"en": "Complete 10 tasks", "ja": "10タスク完了", "zh": "完成10個任務", "ko": "10개 작업 완료"}),
    Achievement("task_50", "🌟",
        {"en": "Workhorse", "ja": "働き者", "zh": "勞模", "ko": "일꾼"},
        {"en": "Complete 50 tasks", "ja": "50タスク完了", "zh": "完成50個任務", "ko": "50개 작업 완료"}),
    Achievement("task_100", "💎",
        {"en": "Centurion", "ja": "百人隊長", "zh": "百夫長", "ko": "백부장"},
        {"en": "Complete 100 tasks", "ja": "100タスク完了", "zh": "完成100個任務", "ko": "100개 작업 완료"}),
    Achievement("streak_3", "🔥",
        {"en": "On Fire", "ja": "絶好調", "zh": "火力全開", "ko": "불타오른다"},
        {"en": "3-task streak", "ja": "3連続タスク", "zh": "3連勝", "ko": "3연속 작업"}),
    Achievement("streak_5", "💥",
        {"en": "Unstoppable", "ja": "無敵", "zh": "勢不可擋", "ko": "막을수없다"},
        {"en": "5-task streak", "ja": "5連続タスク", "zh": "5連勝", "ko": "5연속 작업"}),
    Achievement("level_up", "🏠",
        {"en": "Moving Up", "ja": "昇進", "zh": "升級", "ko": "승진"},
        {"en": "Upgrade your office", "ja": "オフィス昇格", "zh": "辦公室升級", "ko": "사무실 업그레이드"}),
    Achievement("level_5", "🏢",
        {"en": "Studio", "ja": "スタジオ", "zh": "工作室", "ko": "스튜디오"},
        {"en": "Reach level 5", "ja": "レベル5到達", "zh": "達到等級5", "ko": "레벨5 도달"}),
    Achievement("level_10", "🏰",
        {"en": "Dream Office", "ja": "夢のオフィス", "zh": "夢幻辦公室", "ko": "꿈의사무실"},
        {"en": "Reach level 10", "ja": "レベル10到達", "zh": "達到等級10", "ko": "레벨10 도달"}),
    Achievement("pomo_1", "🍅",
        {"en": "Focused", "ja": "集中", "zh": "專注", "ko": "집중"},
        {"en": "Complete 1 Pomodoro", "ja": "ポモドーロ1回完了", "zh": "完成1個番茄鐘", "ko": "포모도로 1회 완료"}),
    Achievement("pomo_5", "🍅",
        {"en": "Deep Work", "ja": "深い仕事", "zh": "深度工作", "ko": "딥워크"},
        {"en": "Complete 5 Pomodoros", "ja": "ポモドーロ5回完了", "zh": "完成5個番茄鐘", "ko": "포모도로 5회 완료"}),
    Achievement("night_owl", "🦉",
        {"en": "Night Owl", "ja": "夜更かし", "zh": "夜貓子", "ko": "올빼미"},
        {"en": "Work past midnight", "ja": "深夜作業", "zh": "工作到深夜", "ko": "자정 넘겨 작업"}),
    Achievement("smith_visit", "🕶️",
        {"en": "The One", "ja": "救世主", "zh": "天選之人", "ko": "그사람"},
        {"en": "Agent Smith visited", "ja": "スミス来訪", "zh": "Smith來訪", "ko": "스미스 방문"}),
    Achievement("high_five", "🤝",
        {"en": "Teamwork", "ja": "チームワーク", "zh": "團隊合作", "ko": "팀워크"},
        {"en": "First high five", "ja": "初ハイタッチ", "zh": "首次擊掌", "ko": "첫 하이파이브"}),
]

ACHIEVEMENT_MAP: dict[str, Achievement] = {a.id: a for a in ACHIEVEMENTS}


class AchievementTracker:
    """Track and persist unlocked achievements."""

    def __init__(self) -> None:
        self.unlocked: dict[str, float] = {}  # id → timestamp
        self._pending_notifications: list[Achievement] = []
        self._load()

    def _load(self) -> None:
        try:
            with open(SAVE_PATH) as f:
                data = json.load(f)
                self.unlocked = data.get("unlocked", {})
        except (FileNotFoundError, json.JSONDecodeError):
            self.unlocked = {}

    def _save(self) -> None:
        os.makedirs(os.path.dirname(SAVE_PATH), exist_ok=True)
        with open(SAVE_PATH, "w") as f:
            json.dump({"unlocked": self.unlocked}, f, indent=2)

    def unlock(self, achievement_id: str) -> bool:
        """Unlock an achievement. Returns True if newly unlocked."""
        if achievement_id in self.unlocked:
            return False
        if achievement_id not in ACHIEVEMENT_MAP:
            return False
        import time
        self.unlocked[achievement_id] = time.time()
        self._pending_notifications.append(ACHIEVEMENT_MAP[achievement_id])
        self._save()
        return True

    def pop_notification(self) -> Achievement | None:
        """Get next pending unlock notification (for banner display)."""
        if self._pending_notifications:
            return self._pending_notifications.pop(0)
        return None

    def check(self, scene: Scene) -> None:
        """Check all achievement conditions against current scene state."""
        import time as _t

        completed = scene.completed_count
        if completed >= 1:
            self.unlock("first_task")
        if completed >= 10:
            self.unlock("task_10")
        if completed >= 50:
            self.unlock("task_50")
        if completed >= 100:
            self.unlock("task_100")

        # Streak achievements (use peak which survives the reset in finish_task)
        for c in scene.characters:
            peak = getattr(c, "_peak_consecutive", 0)
            if peak >= 3:
                self.unlock("streak_3")
            if peak >= 5:
                self.unlock("streak_5")

        # Level achievements
        from .levels import LEVEL_BY_KEY
        level_def = LEVEL_BY_KEY.get(scene.office_level)
        if level_def:
            if level_def.index >= 1:
                self.unlock("level_up")
            if level_def.index >= 4:
                self.unlock("level_5")
            if level_def.index >= 9:
                self.unlock("level_10")

        # Pomodoro achievements
        pomo_count = scene._pomodoro.completed_pomodoros
        if pomo_count >= 1:
            self.unlock("pomo_1")
        if pomo_count >= 5:
            self.unlock("pomo_5")

        # Night owl
        hour = _t.localtime().tm_hour
        if hour >= 0 and hour < 5 and completed > 0:
            self.unlock("night_owl")

        # Smith visit
        if any(c.is_agent for c in scene.characters):
            self.unlock("smith_visit")

        # High five
        from .characters import State
        if any(c.state == State.HIGH_FIVE for c in scene.characters):
            self.unlock("high_five")

    @property
    def unlocked_count(self) -> int:
        return len(self.unlocked)

    @property
    def total_count(self) -> int:
        return len(ACHIEVEMENTS)
