"""Configuration persistence — load/save preferences, constants."""
from __future__ import annotations

import json
import os

from engine.levels import (
    LEVEL_BY_KEY,
    LEVEL_DEFS,
    LEVEL_KEYS,
    OLD_KEY_MIGRATION,
)

from engine import __version__ as VERSION
CONFIG_PATH = os.path.expanduser("~/.config/agent-elves/config.json")
CRASH_LOG = os.path.expanduser("~/.config/agent-elves/crash.log")

VALID_THEMES = ("claude", "kaomoji", "pixel", "samurai", "space", "custom")
VALID_LANGS = ("en", "ja", "zh", "ko")
VALID_OFFICES = ("auto",) + LEVEL_KEYS
OFFICE_UNLOCK_THRESHOLDS = {
    ld.key: ld.unlock_threshold for ld in LEVEL_DEFS if ld.unlock_threshold > 0
}
OFFICE_SESSION_THRESHOLDS = {
    ld.key: ld.session_threshold for ld in LEVEL_DEFS if ld.session_threshold > 0
}


def load_config() -> tuple[str, str, str, str, int, list[str]]:
    """Load saved preferences.

    Returns (theme, lang, autostart, office, total_tasks, unlocked_offices).
    """
    env_theme = os.environ.get("CLAUDE_OFFICE_THEME", "")
    env_lang = os.environ.get("CLAUDE_OFFICE_LANG", "")

    theme = env_theme if env_theme in VALID_THEMES else ""
    lang = env_lang if env_lang in VALID_LANGS else ""
    autostart = ""
    office = "auto"
    total_tasks = 0
    unlocked_offices = ["garage"]

    try:
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
            if not theme:
                theme = cfg.get("theme", "")
            if not lang:
                lang = cfg.get("lang", "")
            autostart = cfg.get("autostart", "")
            office = cfg.get("office", "auto")
            total_tasks = int(cfg.get("total_tasks", 0))
            saved_unlocked = cfg.get("unlocked_offices", [])
            if isinstance(saved_unlocked, list):
                unlocked_offices = saved_unlocked
    except (FileNotFoundError, json.JSONDecodeError):
        pass

    # Migrate old 3-level keys to new 10-level keys
    if office in OLD_KEY_MIGRATION:
        office = OLD_KEY_MIGRATION[office]
    unlocked_offices = [OLD_KEY_MIGRATION.get(o, o) for o in unlocked_offices]

    # Validate office key — fallback to "auto" if invalid
    if office != "auto" and office not in LEVEL_BY_KEY:
        office = "auto"

    # Re-derive unlocks from total_tasks (handles migration + missed unlocks)
    for ld in LEVEL_DEFS:
        if total_tasks >= ld.unlock_threshold and ld.key not in unlocked_offices:
            unlocked_offices.append(ld.key)

    # Ensure "garage" is always unlocked
    if "garage" not in unlocked_offices:
        unlocked_offices.insert(0, "garage")

    return theme, lang, autostart, office, total_tasks, unlocked_offices


def save_config(
    theme: str,
    lang: str,
    autostart: str = "",
    office: str = "",
    total_tasks: int = 0,
    unlocked_offices: list[str] | None = None,
):
    """Persist preferences atomically."""
    import tempfile

    config_dir = os.path.dirname(CONFIG_PATH)
    os.makedirs(config_dir, exist_ok=True)
    cfg: dict = {}
    try:
        with open(CONFIG_PATH) as f:
            cfg = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    cfg["theme"] = theme
    cfg["lang"] = lang
    if autostart:
        cfg["autostart"] = autostart
    if office:
        cfg["office"] = office
    if total_tasks > 0:
        cfg["total_tasks"] = total_tasks
    if unlocked_offices is not None:
        cfg["unlocked_offices"] = unlocked_offices

    # Check for new unlocks
    current_total = cfg.get("total_tasks", 0)
    current_unlocked = cfg.get("unlocked_offices", ["startup"])
    for level, threshold in OFFICE_UNLOCK_THRESHOLDS.items():
        if current_total >= threshold and level not in current_unlocked:
            current_unlocked.append(level)
    cfg["unlocked_offices"] = current_unlocked

    try:
        fd, tmp = tempfile.mkstemp(dir=config_dir)
        with os.fdopen(fd, "w") as f:
            json.dump(cfg, f)
        os.replace(tmp, CONFIG_PATH)
    except OSError:
        pass
