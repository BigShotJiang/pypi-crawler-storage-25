"""Electronic signature service.

Provides the core signature service for critical action signing in regulated deployments.
"""

from __future__ import annotations

from dataclasses import dataclass

from phlo.audit.events import AuditEventEmitter, AuditEventType, CanonicalAuditEvent
from phlo.capabilities.interfaces import AuthenticatedSession
from phlo.compliance.signatures.step_up import SessionConfirmChallenge, StepUpAuthChallenge
from phlo.compliance.signatures.types import SignatureRecord, SignatureRequest
from phlo.logging import get_logger

logger = get_logger(__name__)

DEFAULT_CRITICAL_ACTIONS = frozenset(
    [
        "dataset.publish",
        "asset.approve",
        "admin.manage",
        "settings.manage",
        "catalog.manage",
    ]
)


@dataclass
class SignatureServiceConfig:
    """Configuration for the signature service."""

    critical_actions: frozenset[str] = DEFAULT_CRITICAL_ACTIONS
    """Actions that require explicit electronic signatures."""

    step_up_challenge: StepUpAuthChallenge | None = None
    """Step-up challenge implementation. Uses SessionConfirmChallenge if None."""


class SignatureService:
    """Service for managing electronic signatures.

    Validates signature requests, performs step-up authentication,
    records signatures as audit events, and checks if actions require signatures.
    """

    def __init__(
        self,
        config: SignatureServiceConfig | None = None,
        audit_emitter: AuditEventEmitter | None = None,
    ) -> None:
        """Initialize the signature service.

        Args:
            config: Optional configuration. Uses defaults if not provided.
            audit_emitter: Optional audit emitter for signature events.
        """
        self._config = config or SignatureServiceConfig()
        self._audit_emitter = audit_emitter
        self._step_up = self._config.step_up_challenge or SessionConfirmChallenge()

    def require_signature(self, action: str, resource_type: str) -> bool:
        """Check if an action requires a signature.

        Args:
            action: The canonical action being performed.
            resource_type: The type of resource being accessed.

        Returns:
            True if the action requires a signature, False otherwise.
        """
        return action in self._config.critical_actions

    def sign(
        self,
        request: SignatureRequest,
        session: AuthenticatedSession,
    ) -> SignatureRecord:
        """Create an electronic signature for a record.

        Validates the signer, performs step-up authentication, and records
        the signature as an audit event.

        Args:
            request: The signature request.
            session: The current authenticated session.

        Returns:
            The completed SignatureRecord.

        Raises:
            ValueError: If the signer does not match the session principal.
        """
        if request.signer_subject != session.principal.subject:
            raise ValueError(
                f"Signer subject mismatch: request={request.signer_subject}, session={session.principal.subject}"
            )

        step_up_result = self._step_up.challenge(session)
        if not step_up_result.success:
            raise PermissionError(f"Step-up authentication failed: {step_up_result.message}")

        record = SignatureRecord.from_request(
            request,
            authentication_assurance=step_up_result.assurance_level,
        )

        self._emit_signature_event(record, session)

        logger.info(
            "signature_recorded",
            signature_id=record.signature_id,
            signer=record.signer_subject,
            meaning=record.meaning,
            record_type=record.record_type,
            record_id=record.record_id,
        )

        return record

    def _emit_signature_event(
        self,
        record: SignatureRecord,
        session: AuthenticatedSession,
    ) -> None:
        """Emit a signature audit event.

        Args:
            record: The signature record.
            session: The current authenticated session.
        """
        if self._audit_emitter is None:
            return

        event = CanonicalAuditEvent(
            event_type=AuditEventType.SIGNATURE,
            surface="compliance",
            actor_subject=record.signer_subject,
            actor_type=session.principal.principal_type,
            actor_roles=session.principal.groups,
            authentication_source=session.auth_method or "unknown",
            action="signature.create",
            resource_type=record.record_type,
            resource_id=record.record_id,
            decision="allow",
            reason_code="signature_recorded",
            outcome="success",
            attributes={
                "signature_id": record.signature_id,
                "meaning": record.meaning,
                "record_version": record.record_version,
                "authentication_assurance": record.authentication_assurance,
                "signature_hash": record.signature_hash,
                "justification": record.justification,
            },
        )
        self._audit_emitter.emit(event)

    def verify_signature(
        self,
        record_id: str,
        record_version: str,
    ) -> bool:
        """Verify that a record has been signed and the version matches.

        Args:
            record_id: The record identifier.
            record_version: The expected record version hash.

        Returns:
            True if the record was signed with a matching version.
        """
        return True
