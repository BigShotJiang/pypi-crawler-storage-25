import os
import re
import sys

from functools import partial
from datetime import datetime

from packaging.version import parse as parse_version
from jinja2 import Template

from traitlets.config.configurable import Configurable
from traitlets import Unicode

from wtforms import BooleanField, DecimalField, SelectField, SelectMultipleField
from wtforms.form import BaseForm
from wtforms.validators import InputRequired, NumberRange, AnyOf
from wtforms import IntegerField
from wtforms.widgets import html_params
from wtforms.widgets import NumberInput

from .traitlets import NumericRangeWidget, SelectWidget, LockableWidget

def select_multi_checkbox(field, **kwargs):
    kwargs.setdefault('type', 'checkbox')
    field_id = kwargs.pop('id', field.id)
    html = []
    for value, label, checked, _ in field.iter_choices():
        choice_id = f"{field_id}-{value}"
        options = dict(kwargs, name=field.name, value=value, id=choice_id)
        if checked:
            options['checked'] = 'checked'
        html.append('<div class="form-check form-check-inline">')
        html.append(f'<input class="form-check-input" {html_params(**options)} /> ')
        html.append(f'<label class="form-check-label" for="{choice_id}">{label}</label>')
        html.append("</div>")
    return "".join(html)

class FakeMultiDict(dict):
    getlist = dict.__getitem__

def resolve(value, *args, **kargs):
    if callable(value):
        return value(*args, **kargs)
    else:
        return value

class SbatchForm(Configurable):

    runtime = NumericRangeWidget(
        {
            'min' : 0.25,
            'def' : 1.0,
            'step': 0.25,
            'lock': False,
        },
        help="Define parameters of runtime numeric range widget"
    ).tag(config=True)

    memory = NumericRangeWidget(
        {
            'min' : 1024,
            'step': 1,
            'lock': False,
            'def': lambda api, user: int(max(api.get_mems()) / max(api.get_cpus())),
            'max': lambda api, user: max(api.get_mems())
        },
        help="Define parameters of memory numeric range widget in MB"
    ).tag(config=True)

    nprocs = NumericRangeWidget(
        {
            'min' : 1,
            'step': 1,
            'lock': False,
            'def': 1,
            'max' : lambda api, user: max(api.get_cpus())
        },
        help="Define parameters of core numeric range widget"
    ).tag(config=True)

    oversubscribe = LockableWidget({'def' : False, 'lock' : True}).tag(config=True)

    gpus = SelectWidget(
        {
            'def' : 'gpu:0',
            'choices' : lambda api, user: api.get_gres(),
            'lock' : False
        },
        help="Define the list of available gpu configurations."
    ).tag(config=True)

    profile = SelectWidget(
        {
            'def': 'default',
            'lock' : False,
        },
        help="Define available profiles."
    ).tag(config=True)

    account = SelectWidget(
        {
            'choices' : lambda api, user: api.get_accounts(user),
            'lock' : False
        },
        help="Define the list of available accounts."
    ).tag(config=True)

    reservation = SelectWidget(
        {
            'def' : '',
            'choices' : lambda api, user: api.get_active_reservations(user, api.get_accounts(user)),
            'lock' : False
        },
        help="Define the list of available reservations."
    ).tag(config=True)

    ui = SelectWidget(
        {
            'lock' : False,
            'def' : 'lab',
            'choices' : ['notebook', 'lab', 'terminal']
        },
        help="Define the list of available user interface."
    ).tag(config=True)

    partition = SelectWidget(
        {
            'lock' : True,
            'def' : '',
            'choices' : lambda api, user: api.get_partitions()
        },
        help="Define the list of available slurm partitions."
    ).tag(config=True)

    feature = SelectWidget(
        {
            'lock' : False,
            'def' : [],
            'choices' : lambda api, user: api.get_features()
        },
        help="Define the list of available slurm features."
    ).tag(config=True)

    form_template_path = Unicode(
        os.path.join(sys.prefix, 'share', 'slurmformspawner', 'templates', 'form.html'),
        help="Path to the Jinja2 template of the form"
    ).tag(config=True)

    def __init__(self, username, slurm_api, ui_args, profile_args, hub_version, user_options = {}, config=None):
        super().__init__(config=config)
        fields = {
            'account' : SelectField("Account", validators=[AnyOf([])]),
            'runtime' : DecimalField('Time (hours)', validators=[InputRequired(), NumberRange()], widget=NumberInput()),
            'ui'      : SelectField('User interface', validators=[AnyOf([])]),
            'nprocs'  : IntegerField('Number of cores', validators=[InputRequired(), NumberRange()], widget=NumberInput()),
            'memory'  : IntegerField('Memory (MB)',  validators=[InputRequired(), NumberRange()], widget=NumberInput()),
            'gpus'    : SelectField('GPU configuration', validators=[AnyOf([])]),
            'profile' : SelectField('Job profile', validators=[AnyOf([])]),
            'oversubscribe' : BooleanField('Enable core oversubscription', description="Recommended for interactive usage"),
            'reservation' : SelectField("Reservation", validators=[AnyOf([])]),
            'partition' : SelectField("Partition", validators=[AnyOf([])]),
            'feature' : SelectMultipleField("Feature constraints", validators=[self.validate_features], widget=select_multi_checkbox)
        }
        self.form = BaseForm(fields)
        self.form['runtime'].filters = [float]
        self.slurm_api = slurm_api
        self.resolve = partial(resolve, api=self.slurm_api, user=username)
        self.ui_args = ui_args

        # retrieve defaults from config
        defaults = dict.fromkeys(fields.keys() - ['profile'])
        for field in defaults:
            defaults[field] = self.resolve(getattr(self, field).get('def'))

        self.profile_args = {'default': {'name': 'Default', 'params': defaults}} | profile_args

        if parse_version(hub_version) >= parse_version('5.0.0'):
            self.bootstrap_version = 5
        else:
            self.bootstrap_version = 3

        with open(self.form_template_path, 'r') as template_file:
            self.template = template_file.read()

        for key in fields:
            dict_ = getattr(self, key)
            if dict_.get('lock') is True and dict_.get('def') is None:
                raise Exception(f'You need to define a default value for {key} because it is locked.')
            value = user_options[key] if key in user_options else self.resolve(getattr(self, key).get('def'))
            if not isinstance(self.form[key], SelectMultipleField):
                value = [value]
            self.form[key].process(formdata=FakeMultiDict({key : value }))

    @property
    def data(self):
        return self.form.data

    @property
    def errors(self):
        return self.form.errors

    def process(self, formdata):
        profile = formdata.get('profile', ('default',))[0]
        profile_params = self.profile_args[profile]['params']
        for key in self.form._fields.keys():
            lock = self.resolve(getattr(self, key).get('lock'))
            value = formdata.get(key)
            profile_value = profile_params[key] if key in profile_params.keys() else None
            if not lock and value is not None:
                self.form[key].process(formdata=FakeMultiDict({key : value}))
            if lock and profile_value is not None:
                self.form[key].process(formdata=FakeMultiDict({key : [profile_value]}))

    def validate(self):
        valid = True
        for key in self.form._fields.keys():
            lock = self.resolve(getattr(self, key).get('lock'))
            if not lock:
                valid = self.form[key].validate(self.form) and valid
        return valid

    def render(self):
        self.config_runtime()
        self.config_nprocs()
        self.config_memory()
        self.config_oversubscribe()
        self.config_ui()
        self.config_gpus()
        self.config_profile()
        self.config_reservations()
        self.config_account()
        self.config_partition()
        self.config_feature()
        return Template(self.template).render(form=self.form, bootstrap_version=self.bootstrap_version, profile_params=self.profile_args)

    def config_runtime(self):
        lock = self.resolve(self.runtime.get('lock'))
        if lock:
            def_ = self.resolve(self.runtime.get('def'))
            self.form['runtime'].render_kw = {'disabled': 'disabled'}
            self.form['runtime'].widget.min = def_
            self.form['runtime'].widget.max = def_
            self.form['runtime'].validators[-1].min = def_
            self.form['runtime'].validators[-1].max = def_
            self.form['runtime'].validators[-1].message = f'Runtime can only be {def_}'
        else:
            min_ = self.resolve(self.runtime.get('min'))
            max_ = self.resolve(self.runtime.get('max'))
            step = self.resolve(self.runtime.get('step'))
            self.form['runtime'].widget.min = min_
            self.form['runtime'].widget.max = max_
            self.form['runtime'].widget.step = step
            if min_ is not None:
                self.form['runtime'].validators[-1].min = min_
            if max_ is not None:
                self.form['runtime'].validators[-1].max = max_
            self.form['runtime'].validators[-1].message = f'Runtime outside of allowed range [{min_}, {max_}]'

    def config_nprocs(self):
        lock = self.resolve(self.nprocs.get('lock'))
        if lock:
            def_ = self.resolve(self.nprocs.get('def'))
            self.form['nprocs'].render_kw = {'disabled': 'disabled'}
            self.form['nprocs'].widget.min = def_
            self.form['nprocs'].widget.max = def_
            self.form['nprocs'].validators[-1].min = def_
            self.form['nprocs'].validators[-1].max = def_
        else:
            min_ = self.resolve(self.nprocs.get('min'))
            max_ = self.resolve(self.nprocs.get('max'))
            step = self.resolve(self.nprocs.get('step'))
            self.form['nprocs'].widget.min = min_
            self.form['nprocs'].widget.max = max_
            self.form['nprocs'].widget.step = step
            self.form['nprocs'].validators[-1].min = min_
            self.form['nprocs'].validators[-1].max = max_

    def config_memory(self):
        lock = self.resolve(self.memory.get('lock'))
        if lock:
            def_ = self.resolve(self.memory.get('def'))
            self.form['memory'].render_kw = {'disabled': 'disabled'}
            self.form['memory'].widget.min = def_
            self.form['memory'].widget.max = def_
            self.form['memory'].validators[-1].min = def_
            self.form['memory'].validators[-1].max = def_
        else:
            min_ = self.resolve(self.memory.get('min'))
            max_ = self.resolve(self.memory.get('max'))
            step = self.resolve(self.memory.get('step'))
            self.form['memory'].widget.min = min_
            self.form['memory'].widget.max = max_
            self.form['memory'].widget.step = step
            self.form['memory'].validators[-1].min = min_
            self.form['memory'].validators[-1].max = max_

    def config_oversubscribe(self):
        if self.oversubscribe['lock']:
            self.form['oversubscribe'].render_kw = {'disabled': 'disabled'}

    def config_account(self):
        keys = self.resolve(self.account.get('choices'))
        if keys:
            choices = list(zip(keys, keys))
        else:
            keys = [""]
            choices = [("", "None")]

        self.form['account'].choices = choices
        self.form['account'].validators[-1].values = keys

        if self.resolve(self.account.get('lock')):
            self.form['account'].render_kw = {'disabled': 'disabled'}

    def config_gpus(self):
        choices = self.resolve(self.gpus.get('choices'))
        lock = self.resolve(self.gpus.get('lock'))

        gpu_choice_map = {}
        # if the node has shards, we need the number of gpus and number of shards
        max_shard_per_gpu = 0
        gpu_types = set()
        for choice in choices:
            if choice == 'gpu:0':
                gpu_choice_map['gpu:0'] = 'None'
                continue

            # we now have one choice per type of gres configuration to support
            # heterogenous cluster configuration, each node could have multiple types of gres
            gres_list = choice.split(',')

            total_gpu = 0
            num_shard = 0
            gpu_type = ''
            for gres_def in gres_list:
                match = re.match(r"(gpu:[\w:.]+)", gres_def)
                if match:
                    gres = match.group(1).split(':')
                    number = int(gres[-1])
                    total_gpu += number
                    if len(gres) == 2:
                        strings = ('gpu:{}', '{} x GPU')
                        gpu_type = 'GPU'
                    elif len(gres) > 2:
                        strings = ('gpu:{}:{{}}'.format(gres[1]), '{{}} x {}'.format(gres[1].upper()))
                        gpu_type = gres[1].upper()
                    for i in range(1, number + 1):
                        gpu_choice_map[strings[0].format(i)] = strings[1].format(i)
                else:
                    match = re.match(r"(shard:[\w:.]+)", gres_def)
                    if match:
                        gres = match.group(1).split(':')
                        num_shard = int(gres[-1])
            if num_shard > 0:
                gpu_types.add(gpu_type)
            max_shard_per_gpu = max(max_shard_per_gpu, int(num_shard / total_gpu))

        if max_shard_per_gpu > 0:
            strings = ('shard:{}', '{}/{} x ({})')
            for i in range(1, max_shard_per_gpu):
                gpu_choice_map[strings[0].format(i)] = strings[1].format(i, max_shard_per_gpu, '|'.join(gpu_types))

        self.form['gpus'].choices = list(gpu_choice_map.items())
        if lock:
            self.form['gpus'].render_kw = {'disabled': 'disabled'}
        self.form['gpus'].validators[-1].values = [key for key, value in self.form['gpus'].choices]

    def config_profile(self):
        choices = self.resolve(self.profile.get('choices'))
        if not choices:
            choices = self.profile_args.keys()
        lock = self.resolve(self.profile.get('lock'))
        self.form['profile'].validators[-1].values = [key for key in choices]
        self.form['profile'].choices = [(key, self.profile_args[key]['name']) for key in choices]

        if lock:
            self.form['profile'].render_kw = {'disabled': 'disabled'}


    def config_ui(self):
        choices = self.resolve(self.ui.get('choices'))
        lock = self.resolve(self.ui.get('lock'))
        self.form['ui'].validators[-1].values = [key for key in choices]
        self.form['ui'].choices = [(key, self.ui_args[key]['name']) for key in choices]

        if lock:
            self.form['ui'].render_kw = {'disabled': 'disabled'}

    def config_partition(self):
        choices = list(self.resolve(self.partition.get('choices')))
        lock = self.resolve(self.partition.get('lock'))
        def_ = self.resolve(self.partition.get('def'))

        if def_ != '':
            try:
                choices.remove(def_)
            except ValueError:
                raise Exception(f'The partition default value is not a valid choice.')
        choices.insert(0, def_)

        self.form['partition'].choices = list(zip(choices, choices))
        self.form['partition'].validators[-1].values = choices

        if lock:
            self.form['partition'].render_kw = {'disabled': 'disabled'}

    def config_feature(self):
        choices = self.resolve(self.feature.get('choices'))
        lock = self.resolve(self.feature.get('lock'))
        def_ = self.resolve(self.feature.get('def'))

        self.form['feature'].choices = list(zip(choices, choices))
        self.form['feature'].data = def_

        if lock:
            self.form['feature'].render_kw = {'disabled': 'disabled'}

    def validate_features(self, form, field):
        selected_features = set(field.data)
        # No feature constraints have been selected
        if len(selected_features) == 0:
            return
        active_features = set(self.resolve(self.feature.get('choices')))
        feature_sets = self.slurm_api.get_node_info()['features']
        if not active_features.issuperset(selected_features):
            raise Exception('Some of the features selected are not available in any node.')

        unselect = set()
        for feature_set in feature_sets:
            if feature_set.issuperset(selected_features):
                return
            unselect.add(frozenset(selected_features.difference(feature_set)))

        # No node can satisfy all selected features; report a single clear error
        feature_list = ", ".join(sorted(selected_features))
        unselect_list = ", ".join(["[%s]" % ", ".join(sorted(combo)) for combo in sorted(unselect)])
        message = (
            f'The selected feature combination [{feature_list}] cannot be satisfied by any single node. '
            f'Unselect one of the following set of features: {unselect_list}.'
        )
        raise Exception(message)

    def config_reservations(self):
        choices = self.resolve(self.reservation.get('choices'))
        lock = self.resolve(self.reservation.get('lock'))
        if choices is None:
            choices = []

        now = datetime.now()
        self.form['reservation'].choices = [("", "None")]
        for rsv in choices:
            name = rsv['ReservationName']
            # Compute the duration left to the reservation and remove the milliseconds
            duration = str(rsv['EndTime'] - now).split('.')[0]
            string = '{} - time left: {}'.format(name, duration)
            self.form['reservation'].choices.append((name, string))
        if lock:
            self.form['reservation'].render_kw = {'disabled': 'disabled'}
        self.form['reservation'].validators[-1].values = [key for key, value in self.form['reservation'].choices]
