"""Tests für `models.runtime` (parse_source_spec) und `services.rclone_source.nfc_normalize`."""

from __future__ import annotations

from pathlib import Path

import pytest

from schnittprojekt_leser.models.runtime import RcloneSource, parse_source_spec
from schnittprojekt_leser.services.rclone_source import nfc_normalize


def test_parse_absolute_local_path():
    result = parse_source_spec("/Volumes/Card")
    assert isinstance(result, Path)
    assert result == Path("/Volumes/Card")


def test_parse_home_relative_path():
    result = parse_source_spec("~/Schnittprojekte")
    assert isinstance(result, Path)
    # ~ wurde expandiert
    assert "~" not in str(result)


def test_parse_relative_path():
    result = parse_source_spec("./projects")
    assert isinstance(result, Path)


def test_parse_rclone_source_with_path():
    result = parse_source_spec("lyssach-nas:/Videoschnitt/Luma Fusion-Export")
    assert isinstance(result, RcloneSource)
    assert result.remote == "lyssach-nas"
    assert result.path == "/Videoschnitt/Luma Fusion-Export"


def test_parse_rclone_source_relative_path():
    result = parse_source_spec("mega:Backup")
    assert isinstance(result, RcloneSource)
    assert result.remote == "mega"
    assert result.path == "Backup"


def test_parse_windows_drive_treated_as_local():
    result = parse_source_spec("C:/Users/Patrick/Schnitt")
    assert isinstance(result, Path)


def test_parse_empty_raises():
    with pytest.raises(ValueError):
        parse_source_spec("")


def test_parse_empty_remote_raises():
    with pytest.raises(ValueError):
        parse_source_spec(":/path")


def test_rclone_source_describe_and_path():
    src = RcloneSource(remote="nas", path="/data")
    assert src.describe() == "nas:/data"
    assert src.rclone_path == "nas:/data"


def test_nfc_normalize_combines_diaeresis():
    """macOS-NFD `ä` (a + Combining Diaeresis) → NFC `ä` (precomposed)."""
    nfd = "Käthrin"  # Käthrin, NFD
    nfc = "Käthrin"  # Käthrin, NFC precomposed
    assert nfc_normalize(nfd) == nfc
    assert nfc_normalize(nfc) == nfc  # idempotent
