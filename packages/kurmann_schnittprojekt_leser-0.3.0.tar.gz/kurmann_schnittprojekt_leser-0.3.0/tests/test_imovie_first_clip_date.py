"""Integrationstests für `read_first_clip_date` mit iMovieMobile-Bundles."""

from __future__ import annotations

import plistlib
import zipfile

from schnittprojekt_leser.api import read_first_clip_date
from schnittprojekt_leser.models import (
    SOURCE_IMOVIE_EDITLIST_CREATION_DATE,
    ClipDateConfidence,
    ProjectFormat,
    ReadFirstClipDateRequest,
    RuntimeOptions,
)


def test_first_clip_date_imovie_success(imovie_bundle):
    request = ReadFirstClipDateRequest(
        project_path=imovie_bundle, timezone_assumption="Europe/Zurich"
    )
    result = read_first_clip_date(request, RuntimeOptions())

    assert result.success is True
    assert result.iso_date == "2026-04-23"
    # Plist-Stempel ist UTC `2026-04-23T15:52:21Z`, mit timezone_assumption
    # `Europe/Zurich` (CEST = +02:00) wird daraus die Wallclock-Zeit 17:52.
    assert result.iso_datetime == "2026-04-23T17:52:21+02:00"
    assert result.source_label == SOURCE_IMOVIE_EDITLIST_CREATION_DATE
    assert result.confidence is ClipDateConfidence.HIGH
    assert result.project_format is ProjectFormat.IMOVIE_MOBILE_ZIP
    # Kein Quelldatei-Zugriff bei iMovie
    assert result.resolved_source_file is None


def test_first_clip_date_imovie_timezone_consistent_iso_datetime(imovie_bundle):
    """Ohne Assumption: iso_datetime bleibt in der Eigen-TZ des Stempels (UTC)."""
    request = ReadFirstClipDateRequest(project_path=imovie_bundle)
    result = read_first_clip_date(request, RuntimeOptions())

    assert result.success is True
    # Plist-Stempel ist `Z` (UTC), ohne Assumption bleibt er so.
    assert result.iso_datetime is not None
    assert result.iso_datetime.endswith("+00:00")
    # iso_date entsteht in derselben TZ (also UTC) → 2026-04-23
    assert result.iso_date == "2026-04-23"


def test_first_clip_date_imovie_no_exiftool_required(imovie_bundle):
    """iMovie-Pfad braucht weder exiftool noch rclone – Aufruf funktioniert
    auch mit absurden Tool-Pfaden in RuntimeOptions."""
    request = ReadFirstClipDateRequest(project_path=imovie_bundle)
    result = read_first_clip_date(
        request,
        RuntimeOptions(exiftool_path="/does/not/exist/exiftool"),
    )
    assert result.success is True


def test_first_clip_date_imovie_without_video_clip_fails(tmp_path):
    """editList nur mit Photo-Clips → Fehler (kein Video-Clip)."""
    bundle = tmp_path / "nophotos.iMovieMobile"
    plist_bytes = plistlib.dumps(
        {
            "UUID": "TEST",
            "editInfo": {
                "editList": [
                    {"clipType": 5, "duration": 120},
                    {"clipType": 3, "duration": 30},
                ],
                "cutaways": [],
            },
        }
    )
    with zipfile.ZipFile(bundle, "w") as archive:
        archive.writestr("iMovieMobileProject.plist", plist_bytes)

    request = ReadFirstClipDateRequest(project_path=bundle)
    result = read_first_clip_date(request, RuntimeOptions())
    assert result.success is False
    assert "Video-Clip" in (result.error_message or "")
    assert result.project_format is ProjectFormat.IMOVIE_MOBILE_ZIP


def test_first_clip_date_imovie_video_without_creation_date_fails(tmp_path):
    bundle = tmp_path / "no_date.iMovieMobile"
    plist_bytes = plistlib.dumps(
        {
            "editInfo": {
                "editList": [{"clipType": 1, "duration": 600}],
            },
        }
    )
    with zipfile.ZipFile(bundle, "w") as archive:
        archive.writestr("iMovieMobileProject.plist", plist_bytes)

    request = ReadFirstClipDateRequest(project_path=bundle)
    result = read_first_clip_date(request, RuntimeOptions())
    assert result.success is False
    assert "creationDate" in (result.error_message or "")


def test_first_clip_date_imovie_timezone_default(imovie_bundle):
    """Ohne timezone_assumption: iso_date entsteht aus Eigen-TZ des Stempels (UTC).

    Plist-Stempel `2026-04-23T15:52:21Z` → UTC-Tag 2026-04-23.
    """
    request = ReadFirstClipDateRequest(project_path=imovie_bundle)
    result = read_first_clip_date(request, RuntimeOptions())
    assert result.iso_date == "2026-04-23"


def test_first_clip_date_imovie_warning_on_creation_date_mismatch(tmp_path):
    """Wenn clip.creationDate != movie.creationDate → Warnung im Result."""
    import datetime as _dt

    bundle = tmp_path / "mismatch.iMovieMobile"
    clip_date = _dt.datetime(2026, 4, 23, 15, 52, 21, tzinfo=_dt.timezone.utc)
    movie_date = _dt.datetime(2026, 4, 22, 10, 0, 0, tzinfo=_dt.timezone.utc)
    plist_bytes = plistlib.dumps(
        {
            "editInfo": {
                "editList": [
                    {
                        "clipType": 1,
                        "duration": 600,
                        "creationDate": clip_date,
                        "movie": {"creationDate": movie_date},
                    }
                ],
            },
        }
    )
    with zipfile.ZipFile(bundle, "w") as archive:
        archive.writestr("iMovieMobileProject.plist", plist_bytes)

    request = ReadFirstClipDateRequest(project_path=bundle)
    result = read_first_clip_date(request, RuntimeOptions())
    assert result.success is True
    # clip.creationDate gewinnt
    assert result.iso_datetime is not None and result.iso_datetime.startswith("2026-04-23")
    # Aber Warnung über Abweichung
    assert any("movie.creationDate" in w for w in result.warnings)
