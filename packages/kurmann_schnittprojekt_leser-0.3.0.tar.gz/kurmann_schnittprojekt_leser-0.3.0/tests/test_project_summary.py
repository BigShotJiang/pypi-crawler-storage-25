"""Integrationstests für `api.read_project_summary`."""

from __future__ import annotations

from pathlib import Path

from schnittprojekt_leser.api import read_project_summary
from schnittprojekt_leser.models import (
    ProjectFormat,
    ReadProjectSummaryRequest,
    SchnittprojektLeserEvent,
)


def test_read_project_summary_success(kathrin_fcpxml):
    request = ReadProjectSummaryRequest(project_path=kathrin_fcpxml)
    result = read_project_summary(request)

    assert result.success is True
    assert result.project_name == "Kathrin Meerjungfrau basteln"
    assert result.project_format is ProjectFormat.FCPXML_FILE
    assert result.schema_version == "1.8"
    assert result.video_resolution == (3840, 2160)
    assert result.color_space == "9-16-9 (Rec. 2020 PQ)"
    assert result.audio_layout == "stereo"
    assert result.clip_count_primary == 4
    assert result.clip_count_total >= 4
    assert result.timeline_duration_seconds is not None
    assert result.timeline_duration_seconds > 0


def test_read_project_summary_emits_events(kathrin_fcpxml):
    captured: list[SchnittprojektLeserEvent] = []
    request = ReadProjectSummaryRequest(project_path=kathrin_fcpxml)
    read_project_summary(request, on_event=captured.append)

    stage_ids = [e.stage_id for e in captured]
    assert "format_detection_started" in stage_ids
    assert "format_detected" in stage_ids
    assert "fcpxml_parsing_started" in stage_ids
    assert "fcpxml_parsed" in stage_ids


def test_read_project_summary_invalid_path(tmp_path: Path):
    request = ReadProjectSummaryRequest(project_path=tmp_path / "doesnt_exist.fcpxml")
    result = read_project_summary(request)

    assert result.success is False
    assert result.error_message is not None
    assert "existiert nicht" in result.error_message or "nicht gefunden" in result.error_message


def test_read_project_summary_bundle(tmp_path: Path, kathrin_fcpxml):
    bundle = tmp_path / "Test.fcpxmld"
    bundle.mkdir()
    (bundle / "info.fcpxml").write_bytes(kathrin_fcpxml.read_bytes())

    request = ReadProjectSummaryRequest(project_path=bundle)
    result = read_project_summary(request)
    assert result.success is True
    assert result.project_format is ProjectFormat.FCPXML_BUNDLE


def test_read_project_summary_imovie(imovie_bundle):
    request = ReadProjectSummaryRequest(project_path=imovie_bundle)
    result = read_project_summary(request)
    assert result.success is True
    assert result.project_format is ProjectFormat.IMOVIE_MOBILE_ZIP
    assert result.project_name == "Test Project"
    assert result.video_resolution == (3840, 2160)
    assert result.color_space == "HDR"
    # 1 Video + 9 Fotos + 9 Transitions
    assert result.clip_count_primary == 19
    assert result.clip_count_total == 19  # keine cutaways im Sample
    assert result.timeline_duration_seconds is not None
    assert result.timeline_duration_seconds > 0
