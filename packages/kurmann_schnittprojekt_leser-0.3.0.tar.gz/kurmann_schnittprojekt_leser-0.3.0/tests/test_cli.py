"""CLI-Tests via Typer's CliRunner."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from schnittprojekt_leser.cli.main import app

runner = CliRunner()


def test_inspect_summary_text(kathrin_fcpxml):
    result = runner.invoke(app, ["inspect", "summary", str(kathrin_fcpxml)])
    assert result.exit_code == 0
    assert "Kathrin Meerjungfrau basteln" in result.stdout
    assert "3840×2160" in result.stdout
    assert "Schema 1.8" in result.stdout


def test_inspect_summary_json(kathrin_fcpxml):
    result = runner.invoke(
        app, ["inspect", "summary", str(kathrin_fcpxml), "--format", "json"]
    )
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["success"] is True
    assert data["project_name"] == "Kathrin Meerjungfrau basteln"
    assert data["video_resolution"] == [3840, 2160]
    assert data["clip_count_primary"] == 4


def test_inspect_summary_invalid_path():
    result = runner.invoke(app, ["inspect", "summary", "/does/not/exist.fcpxml"])
    # Typer-eigene Existenz-Prüfung → Exit-Code 2
    assert result.exit_code != 0


def test_inspect_first_clip_date_no_source_returns_value_with_fallback(tmp_path, kathrin_fcpxml):
    """Standalone-FCPXML ohne Quelldateien → Project-Fallback, exit 0, iso_date auf stdout."""
    # Sample wird kopiert ohne MOVs daneben, dann läuft der Resolver auf project_fallback
    result = runner.invoke(app, ["inspect", "first-clip-date", str(kathrin_fcpxml)])
    assert result.exit_code == 0
    # Date format YYYY-MM-DD
    assert len(result.stdout.strip()) >= 10


def test_inspect_first_clip_date_json_format(kathrin_fcpxml):
    result = runner.invoke(
        app,
        ["inspect", "first-clip-date", str(kathrin_fcpxml), "--format", "json"],
    )
    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert "iso_date" in data
    assert "iso_datetime" in data
    assert "source_label" in data
    assert "confidence" in data


def test_inspect_first_clip_date_iso_datetime_format(kathrin_fcpxml):
    result = runner.invoke(
        app,
        ["inspect", "first-clip-date", str(kathrin_fcpxml), "--format", "iso-datetime"],
    )
    assert result.exit_code == 0
    # ISO-Format mit T oder mindestens Datum
    output = result.stdout.strip()
    assert len(output) >= 10
