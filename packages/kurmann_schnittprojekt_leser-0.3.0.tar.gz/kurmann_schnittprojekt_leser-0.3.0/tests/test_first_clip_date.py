"""Integrationstests für `api.read_first_clip_date`.

exiftool-Aufrufe werden via Monkeypatch mocked, damit die Tests ohne
echte MOV-Quelldateien grosser Grösse auskommen und auch in CI ohne
Sample-MOVs grün laufen.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from schnittprojekt_leser.api import read_first_clip_date
from schnittprojekt_leser.models import (
    ClipDateConfidence,
    DateSources,
    ProjectFormat,
    ReadFirstClipDateRequest,
    RuntimeOptions,
)


def _write_minimal_fcpxml(target: Path, src_relative: str) -> None:
    """Schreibt ein minimales FCPXML mit einer einzigen Spine-asset-clip-Referenz."""
    target.write_text(
        f"""<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!DOCTYPE fcpxml>
<fcpxml version="1.8">
    <resources>
        <format id="f1" frameDuration="10/600s" width="1920" height="1080"/>
        <format id="r0" frameDuration="20/1200s" width="1920" height="1080"/>
        <asset id="a1" name="test.mov" src="{src_relative}" format="r0" hasVideo="1" hasAudio="1" audioRate="48000"/>
    </resources>
    <library>
        <event name="TestEvent">
            <project name="TestProject">
                <sequence format="f1" tcStart="0s" audioLayout="stereo" audioRate="48k">
                    <spine>
                        <asset-clip name="test" offset="0s" start="0s" duration="60/60s" ref="a1" format="r0" audioRole="dialogue"/>
                    </spine>
                </sequence>
            </project>
        </event>
    </library>
</fcpxml>
""",
        encoding="utf-8",
    )


def test_first_clip_date_with_mocked_exiftool(tmp_path, monkeypatch):
    """End-to-End: synthetisches FCPXML + neben-Datei-Quelle + gemockter exiftool."""
    fcpxml = tmp_path / "test.fcpxml"
    _write_minimal_fcpxml(fcpxml, "./test.mov")
    # Eine echte (leere) Datei nebenan, damit der Resolver Erfolg hat.
    (tmp_path / "test.mov").write_bytes(b"")

    # exiftool mocken
    from schnittprojekt_leser.core import first_clip_date as core_first_clip_date

    def fake_exiftool(file_path, runtime, on_output=None):
        return DateSources(keys_creation_date="2026:04:23 17:52:21+02:00")

    monkeypatch.setattr(core_first_clip_date, "exiftool_read_dates", fake_exiftool)

    request = ReadFirstClipDateRequest(project_path=fcpxml, timezone_assumption="Europe/Zurich")
    result = read_first_clip_date(request, RuntimeOptions())

    assert result.success is True
    assert result.iso_date == "2026-04-23"
    assert result.iso_datetime == "2026-04-23T17:52:21+02:00"
    assert result.source_label == "exif:Keys:CreationDate"
    assert result.confidence is ClipDateConfidence.HIGH
    assert result.project_format is ProjectFormat.FCPXML_FILE


def test_first_clip_date_source_not_found_falls_back_to_project_mtime(tmp_path):
    fcpxml = tmp_path / "test.fcpxml"
    _write_minimal_fcpxml(fcpxml, "./missing.mov")

    request = ReadFirstClipDateRequest(project_path=fcpxml)
    result = read_first_clip_date(request, RuntimeOptions())

    assert result.success is True
    assert result.confidence is ClipDateConfidence.LOW
    assert result.source_label == "project_fallback"
    assert "nicht gefunden" in " ".join(result.warnings)


def test_first_clip_date_invalid_project_returns_error_message(tmp_path):
    request = ReadFirstClipDateRequest(project_path=tmp_path / "missing.fcpxml")
    result = read_first_clip_date(request, RuntimeOptions())
    assert result.success is False
    assert result.error_message is not None


def test_first_clip_date_no_real_source_clip(tmp_path):
    """Spine ohne echte Quelldatei-Refs (nur Title) → success=False."""
    fcpxml = tmp_path / "test.fcpxml"
    fcpxml.write_text(
        """<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<fcpxml version="1.8">
    <resources>
        <format id="f1" frameDuration="10/600s" width="1920" height="1080"/>
        <format id="r0" width="1920" height="1080"/>
        <asset id="t1" name="01-Plain-White.titleData" src="./white.png" format="r0" hasVideo="1"/>
    </resources>
    <library>
        <event name="E">
            <project name="P">
                <sequence format="f1" audioLayout="stereo" audioRate="48k">
                    <spine>
                        <asset-clip name="title" offset="0s" start="0s" duration="60/60s" ref="t1" format="r0"/>
                    </spine>
                </sequence>
            </project>
        </event>
    </library>
</fcpxml>
""",
        encoding="utf-8",
    )
    request = ReadFirstClipDateRequest(project_path=fcpxml)
    result = read_first_clip_date(request, RuntimeOptions())
    assert result.success is False
    assert "primär" in (result.error_message or "")


def test_first_clip_date_timezone_default_uses_stamp_own_tz(tmp_path, monkeypatch):
    """Ohne timezone_assumption: iso_date wird in der Eigen-TZ des Stempels gebildet."""
    fcpxml = tmp_path / "test.fcpxml"
    _write_minimal_fcpxml(fcpxml, "./test.mov")
    (tmp_path / "test.mov").write_bytes(b"")

    from schnittprojekt_leser.core import first_clip_date as core_first_clip_date

    def fake_exiftool(file_path, runtime, on_output=None):
        # Stempel in CEST, Tag = 2026-04-23
        return DateSources(keys_creation_date="2026:04:23 23:00:00+02:00")

    monkeypatch.setattr(core_first_clip_date, "exiftool_read_dates", fake_exiftool)

    request = ReadFirstClipDateRequest(project_path=fcpxml)  # keine TZ
    result = read_first_clip_date(request, RuntimeOptions())
    assert result.iso_date == "2026-04-23"


def test_first_clip_date_real_sample_via_bundle_if_present():
    """Optional-Test mit Patricks LumaFusion-Sample, wenn lokal vorhanden.

    Wird übersprungen, wenn die Sample-Datei nicht existiert (z. B. in CI).
    """
    sample = Path(
        "/Users/patrickkurmann/Downloads/Videoprojects-Samples/Kathrin Meerjungfrau basteln.fcpxmld"
    )
    if not sample.is_dir():
        pytest.skip("LumaFusion-Sample nicht vorhanden")

    # Auch exiftool muss verfügbar sein
    import shutil

    if shutil.which("exiftool") is None:
        pytest.skip("exiftool nicht im PATH")

    request = ReadFirstClipDateRequest(
        project_path=sample, timezone_assumption="Europe/Zurich"
    )
    result = read_first_clip_date(request, RuntimeOptions())
    assert result.success is True
    assert result.iso_date == "2026-03-29"
    assert result.iso_datetime is not None
    assert result.source_label is not None
    assert result.source_label.startswith("exif:")
