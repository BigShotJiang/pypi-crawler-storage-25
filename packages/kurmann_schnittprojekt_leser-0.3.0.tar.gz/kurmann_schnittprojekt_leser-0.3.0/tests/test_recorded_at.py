"""Tests für `core.recorded_at` – Hierarchie und FCC-Fallback."""

from __future__ import annotations

from schnittprojekt_leser.core.recorded_at import (
    has_timezone,
    normalize_iso_date,
    pick_recorded_at,
)
from schnittprojekt_leser.models.dates import DateSources
from schnittprojekt_leser.models.formats import ClipDateConfidence

# ---------------------------------------------------------------------------
# normalize_iso_date
# ---------------------------------------------------------------------------


def test_normalize_exiftool_format():
    assert normalize_iso_date("2026:04:20 12:52:15+02:00") == "2026-04-20T12:52:15+02:00"


def test_normalize_without_tz():
    assert normalize_iso_date("2026:04:20 12:52:15") == "2026-04-20T12:52:15"


def test_normalize_already_iso_passthrough():
    iso = "2026-04-20T12:52:15+02:00"
    assert normalize_iso_date(iso) == iso


def test_normalize_none_returns_none():
    assert normalize_iso_date(None) is None


def test_normalize_empty_returns_none():
    assert normalize_iso_date("") is None
    assert normalize_iso_date("   ") is None


def test_normalize_unparsable_passes_through():
    assert normalize_iso_date("garbage") == "garbage"


# ---------------------------------------------------------------------------
# has_timezone
# ---------------------------------------------------------------------------


def test_has_timezone_with_offset():
    assert has_timezone("2026-04-20T12:52:15+02:00") is True


def test_has_timezone_with_z():
    assert has_timezone("2026-04-20T12:52:15Z") is True


def test_has_timezone_without_offset():
    assert has_timezone("2026-04-20T12:52:15") is False


def test_has_timezone_none():
    assert has_timezone(None) is False


# ---------------------------------------------------------------------------
# pick_recorded_at – Hierarchie
# ---------------------------------------------------------------------------


def test_pick_keys_creation_date_first():
    dates = DateSources(
        keys_creation_date="2026:04:20 12:00:00+02:00",
        exif_creation_date="2025:01:01 00:00:00+02:00",
        exif_create_date="2024:01:01 00:00:00",
        file_mtime="2023-01-01T00:00:00+02:00",
    )
    iso, label, conf = pick_recorded_at(dates)
    assert iso == "2026-04-20T12:00:00+02:00"
    assert label == "exif:Keys:CreationDate"
    assert conf is ClipDateConfidence.HIGH


def test_pick_falls_through_to_create_date():
    dates = DateSources(
        exif_create_date="2024:08:14 15:30:00+02:00",
        file_mtime="2024-08-14T15:30:00+02:00",
    )
    iso, label, conf = pick_recorded_at(dates)
    assert iso == "2024-08-14T15:30:00+02:00"
    assert label == "exif:CreateDate"
    assert conf is ClipDateConfidence.MEDIUM


def test_pick_fcc_fallback_infers_tz_from_mtime():
    """Final-Cut-Camera-Sonderfall: CreateDate UTC ohne TZ, mtime mit TZ."""
    dates = DateSources(
        exif_create_date="2024:08:14 13:30:00",  # naive UTC
        file_mtime="2024-08-14T15:30:00+02:00",  # mit TZ
    )
    iso, label, conf = pick_recorded_at(dates)
    # 13:30 UTC entspricht 15:30 in CEST
    assert iso == "2024-08-14T15:30:00+02:00"
    assert label == "exif:CreateDate+tz_from_mtime"
    assert conf is ClipDateConfidence.MEDIUM


def test_pick_fcc_no_mtime_no_inference():
    """Ohne mtime kann nicht inferiert werden – CreateDate bleibt naiv."""
    dates = DateSources(exif_create_date="2024:08:14 13:30:00")
    iso, label, _ = pick_recorded_at(dates)
    assert iso == "2024-08-14T13:30:00"
    assert label == "exif:CreateDate"


def test_pick_falls_through_to_birthtime():
    dates = DateSources(file_birthtime="2026-04-20T12:00:00+02:00")
    iso, label, conf = pick_recorded_at(dates)
    assert iso == "2026-04-20T12:00:00+02:00"
    assert label == "file_birthtime"
    assert conf is ClipDateConfidence.MEDIUM


def test_pick_falls_through_to_mtime():
    dates = DateSources(file_mtime="2026-04-20T12:00:00+02:00")
    iso, label, conf = pick_recorded_at(dates)
    assert iso == "2026-04-20T12:00:00+02:00"
    assert label == "file_mtime"
    assert conf is ClipDateConfidence.LOW


def test_pick_returns_none_on_empty():
    dates = DateSources()
    iso, label, conf = pick_recorded_at(dates)
    assert iso is None
    assert label is None
    assert conf is ClipDateConfidence.UNKNOWN


def test_pick_blackmagic_takes_precedence_over_datetime_original():
    dates = DateSources(
        blackmagic_date_recorded="2026:01:15 10:00:00+01:00",
        exif_datetime_original="2025:06:01 14:00:00",
    )
    iso, label, conf = pick_recorded_at(dates)
    assert "2026-01-15" in iso
    assert label == "exif:Blackmagic-design:CameraDateRecorded"
    assert conf is ClipDateConfidence.HIGH
