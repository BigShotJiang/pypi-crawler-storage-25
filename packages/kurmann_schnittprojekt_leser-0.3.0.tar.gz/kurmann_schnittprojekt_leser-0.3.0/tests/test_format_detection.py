"""Tests für `core.format_detection`."""

from __future__ import annotations

import pytest

from schnittprojekt_leser.core.format_detection import (
    detect_format,
    resolve_inner_xml_path,
)
from schnittprojekt_leser.models.errors import FormatDetectionError
from schnittprojekt_leser.models.formats import ProjectFormat


def test_detect_fcpxml_file(kathrin_fcpxml):
    assert detect_format(kathrin_fcpxml) is ProjectFormat.FCPXML_FILE


def test_detect_fcpxml_bundle(tmp_path, kathrin_fcpxml):
    bundle = tmp_path / "Test.fcpxmld"
    bundle.mkdir()
    (bundle / "info.fcpxml").write_bytes(kathrin_fcpxml.read_bytes())
    assert detect_format(bundle) is ProjectFormat.FCPXML_BUNDLE


def test_detect_unknown_path_raises(tmp_path):
    with pytest.raises(FormatDetectionError):
        detect_format(tmp_path / "doesnt_exist.fcpxml")


def test_detect_wrong_extension_raises(tmp_path):
    other = tmp_path / "test.txt"
    other.write_text("hello")
    with pytest.raises(FormatDetectionError):
        detect_format(other)


def test_detect_fcpxml_with_wrong_root(tmp_path):
    fake = tmp_path / "fake.fcpxml"
    fake.write_text("<?xml version='1.0'?><notfcpxml/>")
    with pytest.raises(FormatDetectionError):
        detect_format(fake)


def test_detect_bundle_without_info_raises(tmp_path):
    bundle = tmp_path / "Empty.fcpxmld"
    bundle.mkdir()
    with pytest.raises(FormatDetectionError):
        detect_format(bundle)


def test_detect_imovie_mobile(imovie_bundle):
    assert detect_format(imovie_bundle) is ProjectFormat.IMOVIE_MOBILE_ZIP


def test_detect_imovie_extension_but_not_zip_raises(tmp_path):
    fake = tmp_path / "fake.iMovieMobile"
    fake.write_text("not a zip")
    with pytest.raises(FormatDetectionError):
        detect_format(fake)


def test_detect_imovie_zip_without_project_plist_raises(tmp_path):
    import zipfile

    bundle = tmp_path / "wrong.iMovieMobile"
    with zipfile.ZipFile(bundle, "w") as archive:
        archive.writestr("other.txt", "no project plist")
    with pytest.raises(FormatDetectionError):
        detect_format(bundle)


def test_resolve_inner_xml_path_for_file(kathrin_fcpxml):
    assert resolve_inner_xml_path(kathrin_fcpxml, ProjectFormat.FCPXML_FILE) == kathrin_fcpxml


def test_resolve_inner_xml_path_for_bundle(tmp_path, kathrin_fcpxml):
    bundle = tmp_path / "Test.fcpxmld"
    bundle.mkdir()
    info = bundle / "info.fcpxml"
    info.write_bytes(kathrin_fcpxml.read_bytes())
    assert resolve_inner_xml_path(bundle, ProjectFormat.FCPXML_BUNDLE) == info
