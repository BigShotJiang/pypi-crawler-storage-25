"""Tests für `services.imovie_mobile_reader`."""

from __future__ import annotations

import zipfile

import pytest

from schnittprojekt_leser.models.errors import IMovieParseError
from schnittprojekt_leser.models.imovie import (
    CLIP_TYPE_PHOTO,
    CLIP_TYPE_TRANSITION,
    CLIP_TYPE_VIDEO,
)
from schnittprojekt_leser.services.imovie_mobile_reader import read_imovie_mobile


def test_read_ikea_sample_basic_fields(imovie_bundle):
    project = read_imovie_mobile(imovie_bundle)

    # Bundle-Name ist `Test Project.iMovieMobile` (Fixture)
    assert project.project_name == "Test Project"
    assert project.uuid == "34701503-0A03-4F8C-95A2-CE0B3C76FD03"
    assert project.contains_2160 is True
    assert project.contains_hdr is True
    assert project.contains_hevc is True
    assert project.contains_prores is False


def test_edit_list_first_entry_is_video_clip(imovie_bundle):
    project = read_imovie_mobile(imovie_bundle)
    first = project.edit_list[0]
    assert first.clip_type == CLIP_TYPE_VIDEO
    assert first.is_video is True
    assert first.creation_date_iso is not None
    assert first.creation_date_iso.startswith("2026-04-23T15:52:21")
    # Video-Pfad innerhalb des Bundles als persistentURL aus dem Plist
    assert first.relative_path is not None
    assert first.relative_path.endswith(".mov")
    # Title-Overlay aus iMovie
    assert first.title_text == "IKEA Lyssach"
    assert first.title_subtitle is not None and "23. April 2026" in first.title_subtitle
    # GPS aus mapLocation
    assert first.map_location is not None
    assert first.map_location.country_name == "Schweiz"
    assert first.map_location.region_name == "Lyssach"
    assert first.map_location.latitude == pytest.approx(47.0747)


def test_clip_types_distribution(imovie_bundle):
    """Sample hat 1 Video + 9 Fotos + 9 Transitions = 19 editList-Einträge."""
    project = read_imovie_mobile(imovie_bundle)
    counts = {}
    for clip in project.edit_list:
        counts[clip.clip_type] = counts.get(clip.clip_type, 0) + 1
    assert counts[CLIP_TYPE_VIDEO] == 1
    assert counts[CLIP_TYPE_TRANSITION] == 9
    assert counts[CLIP_TYPE_PHOTO] == 9
    assert len(project.edit_list) == 19


def test_first_video_clip_helper(imovie_bundle):
    project = read_imovie_mobile(imovie_bundle)
    first_video = project.first_video_clip()
    assert first_video is not None
    assert first_video.is_video is True
    assert first_video.clip_type == CLIP_TYPE_VIDEO


def test_duration_uses_60fps_timebase(imovie_bundle):
    """`duration` in Plist sind Frames bei 60 fps – Reader rechnet in Sekunden um."""
    project = read_imovie_mobile(imovie_bundle)
    first_video = project.first_video_clip()
    # Plist-Wert: 2148 frames; 2148/60 = 35.8s
    assert first_video.duration_frames == 2148
    assert first_video.duration_seconds == pytest.approx(35.8, rel=1e-3)


def test_timeline_duration_summed(imovie_bundle):
    project = read_imovie_mobile(imovie_bundle)
    assert project.timeline_duration_seconds > 0
    # Sample hat ca. 57 Sekunden Gesamtdauer (1 Video 35.8s + 9 Fotos je 2s + 9 Transitions je 0.5s)
    assert 50 < project.timeline_duration_seconds < 65


def test_no_cutaways_in_sample(imovie_bundle):
    project = read_imovie_mobile(imovie_bundle)
    assert project.cutaways == []


def test_read_missing_bundle_raises(tmp_path):
    with pytest.raises(IMovieParseError):
        read_imovie_mobile(tmp_path / "doesnt_exist.iMovieMobile")


def test_read_non_zip_raises(tmp_path):
    bad = tmp_path / "fake.iMovieMobile"
    bad.write_text("this is not a zip")
    with pytest.raises(IMovieParseError):
        read_imovie_mobile(bad)


def test_read_zip_without_plist_raises(tmp_path):
    bundle = tmp_path / "no_plist.iMovieMobile"
    with zipfile.ZipFile(bundle, "w") as archive:
        archive.writestr("readme.txt", "no plist here")
    with pytest.raises(IMovieParseError):
        read_imovie_mobile(bundle)


def test_read_zip_with_invalid_plist_raises(tmp_path):
    bundle = tmp_path / "bad_plist.iMovieMobile"
    with zipfile.ZipFile(bundle, "w") as archive:
        archive.writestr("iMovieMobileProject.plist", b"not a plist")
    with pytest.raises(IMovieParseError):
        read_imovie_mobile(bundle)


def test_read_zip_with_plist_missing_editinfo_raises(tmp_path):
    """Plist ohne `editInfo` → klare Fehlermeldung."""
    import plistlib

    bundle = tmp_path / "missing_editinfo.iMovieMobile"
    plist_bytes = plistlib.dumps({"UUID": "TEST", "contains1080Content": True})
    with zipfile.ZipFile(bundle, "w") as archive:
        archive.writestr("iMovieMobileProject.plist", plist_bytes)
    with pytest.raises(IMovieParseError):
        read_imovie_mobile(bundle)
