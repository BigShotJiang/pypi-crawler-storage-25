"""Tests für `services.fcpxml_reader`."""

from __future__ import annotations

import pytest

from schnittprojekt_leser.models.errors import FcpxmlParseError
from schnittprojekt_leser.services.fcpxml_reader import (
    _parse_audio_rate,
    _parse_seconds,
    read_fcpxml,
)


def test_read_kathrin_sample(kathrin_fcpxml):
    project = read_fcpxml(kathrin_fcpxml)

    assert project.project_name == "Kathrin Meerjungfrau basteln"
    assert project.schema_version == "1.8"
    assert project.sequence_format.width == 3840
    assert project.sequence_format.height == 2160
    assert project.audio_layout == "stereo"
    assert project.audio_rate == 48000
    # 4 Top-Level-Spine-Clips: A001_03290820, _D499, _D500, _D501
    assert len(project.spine_clips) == 4
    # 1 Lane-Clip ("Adjustment") und 1 nested video — wir zählen alle
    # Sub-asset-clips
    assert project.nested_spine_clip_count >= 1


def test_first_clip_is_real_source(kathrin_fcpxml):
    project = read_fcpxml(kathrin_fcpxml)
    first = project.spine_clips[0]
    asset = project.assets_by_id[first.asset_ref]
    assert asset.is_real_source is True
    assert asset.src_relative is not None
    assert asset.src_relative.endswith(".mov")
    # Erster Clip in der Spine ist A001_03290820_D498
    assert "A001_03290820_D498" in asset.src_relative


def test_title_data_assets_marked_not_real_source(kathrin_fcpxml):
    project = read_fcpxml(kathrin_fcpxml)
    title_assets = [a for a in project.assets_by_id.values() if a.name.endswith(".titleData")]
    assert title_assets, "Sample sollte mindestens ein titleData-Asset enthalten"
    for asset in title_assets:
        assert asset.is_real_source is False


def test_timeline_duration_computed(kathrin_fcpxml):
    project = read_fcpxml(kathrin_fcpxml)
    assert project.timeline_duration_seconds > 0
    # Sample-Timeline ist ~164 s (Spine-Clip-Durations summiert, ohne Transitions)
    assert 100 < project.timeline_duration_seconds < 300


def test_read_missing_file_raises(tmp_path):
    with pytest.raises(FcpxmlParseError):
        read_fcpxml(tmp_path / "doesnt_exist.fcpxml")


def test_read_invalid_xml_raises(tmp_path):
    bad = tmp_path / "bad.fcpxml"
    bad.write_text("not xml at all")
    with pytest.raises(FcpxmlParseError):
        read_fcpxml(bad)


# ---------------------------------------------------------------------------
# _parse_seconds
# ---------------------------------------------------------------------------


def test_parse_seconds_integer():
    assert _parse_seconds("30157s") == 30157.0


def test_parse_seconds_rational():
    # 106720 / 1200 = 88.9333...
    assert _parse_seconds("106720/1200s") == pytest.approx(88.9333, rel=1e-3)


def test_parse_seconds_zero():
    assert _parse_seconds("0s") == 0.0


def test_parse_seconds_empty():
    assert _parse_seconds("") == 0.0


# ---------------------------------------------------------------------------
# _parse_audio_rate
# ---------------------------------------------------------------------------


def test_parse_audio_rate_numeric():
    assert _parse_audio_rate("48000") == 48000


def test_parse_audio_rate_k_suffix():
    assert _parse_audio_rate("48k") == 48000


def test_parse_audio_rate_none():
    assert _parse_audio_rate(None) is None


def test_parse_audio_rate_unknown():
    assert _parse_audio_rate("garbage") is None
