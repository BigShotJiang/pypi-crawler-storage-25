"""Wrapper um `rclone` für Quellverzeichnisse auf Remotes.

Spiegelt das Aufruf-Pattern aus `kamera-einleser/rclone.py`. Subprocess-
basiert, kein konfigurierbares Binary für die rclone-Auflösung selbst
(rclone wird aus PATH gelöst, der Pfad ist via `RuntimeOptions.rclone_path`
übergebbar).

Dateinamen aus `rclone lsf` werden für Vergleiche NFC-normalisiert
(siehe `_nfc_normalize`), damit macOS-NFD-Dateinamen mit Linux/SMB-NFC-
Listings matchen.
"""

from __future__ import annotations

import shutil
import subprocess
import unicodedata
from pathlib import Path
from typing import Callable

from schnittprojekt_leser.models.errors import RcloneError, RcloneUnavailableError
from schnittprojekt_leser.models.runtime import RcloneSource, RuntimeOptions


def check_rclone_available(runtime: RuntimeOptions) -> bool:
    """True, wenn das konfigurierte rclone-Binary auffindbar ist."""
    return shutil.which(runtime.rclone_path) is not None


def nfc_normalize(name: str) -> str:
    """NFC-Normalisierung für Filename-Vergleich.

    macOS speichert Dateinamen typisch als NFD (z. B. ``ä`` als
    ``a`` + Combining Diaeresis), Linux/SMB-NAS als NFC. Vergleiche
    werden inkonsistent ohne explizite Normalisierung.
    """
    return unicodedata.normalize("NFC", name)


def list_files(
    source: RcloneSource,
    runtime: RuntimeOptions,
    max_depth: int,
    on_output: Callable[[str], None] | None = None,
) -> list[str]:
    """Listet alle Dateien in einer rclone-Quelle.

    Args:
        source: rclone-Remote + Pfad.
        runtime: rclone-Pfad und Timeout.
        max_depth: Anzahl zusätzlicher Unterverzeichnis-Ebenen
            (0 = nur Wurzel, 1 = + eine Ebene, ...). Wird auf rclone's
            ``--max-depth`` (= max_depth + 1) abgebildet.
        on_output: optionaler Callback für rohen rclone-Output.

    Returns:
        Liste relativer Pfad-Strings, einer pro Datei (z. B.
        ``"Sub/2026-04-23.mov"``). Verzeichnisse sind nicht enthalten.

    Raises:
        RcloneUnavailableError: rclone-Binary nicht im PATH bzw. unter
            `rclone_path`.
        RcloneError: Aufruf scheiterte oder Timeout.
    """
    if not check_rclone_available(runtime):
        raise RcloneUnavailableError(
            f"rclone nicht gefunden ({runtime.rclone_path}). "
            "Installation: <https://rclone.org/install/>. "
            "Pfad konfigurierbar via RuntimeOptions.rclone_path."
        )

    cmd = [
        runtime.rclone_path,
        "lsf",
        "--files-only",
        "--recursive",
        f"--max-depth={max(0, max_depth) + 1}",
        source.rclone_path,
    ]
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=runtime.rclone_timeout_seconds,
        )
    except subprocess.TimeoutExpired as exc:
        raise RcloneError(
            f"rclone-Timeout nach {runtime.rclone_timeout_seconds}s für {source.describe()}"
        ) from exc

    if on_output:
        if proc.stdout:
            on_output(proc.stdout)
        if proc.stderr:
            on_output(proc.stderr)

    if proc.returncode != 0:
        raise RcloneError(
            f"rclone fehlgeschlagen für {source.describe()}: "
            f"{(proc.stderr or proc.stdout).strip()}"
        )

    return [line.strip() for line in proc.stdout.splitlines() if line.strip()]


def copy_file(
    source: RcloneSource,
    relative_path: str,
    target_dir: Path,
    runtime: RuntimeOptions,
    on_output: Callable[[str], None] | None = None,
) -> Path:
    """Kopiert eine einzelne Datei aus der rclone-Quelle ins lokale Zielverzeichnis.

    Returns:
        Lokaler Pfad der kopierten Datei (`target_dir / Path(relative_path).name`).

    Raises:
        RcloneError: Aufruf scheiterte oder Datei wurde nicht erstellt.
    """
    target_dir.mkdir(parents=True, exist_ok=True)
    remote_path = f"{source.rclone_path.rstrip('/')}/{relative_path}"
    local_target = target_dir / Path(relative_path).name

    cmd = [
        runtime.rclone_path,
        "copyto",
        remote_path,
        str(local_target),
    ]
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=runtime.rclone_timeout_seconds,
        )
    except subprocess.TimeoutExpired as exc:
        raise RcloneError(
            f"rclone-Timeout beim Kopieren von {remote_path} nach {local_target}"
        ) from exc

    if on_output:
        if proc.stdout:
            on_output(proc.stdout)
        if proc.stderr:
            on_output(proc.stderr)

    if proc.returncode != 0 or not local_target.exists():
        raise RcloneError(
            f"rclone-copyto fehlgeschlagen für {remote_path}: "
            f"{(proc.stderr or proc.stdout).strip()}"
        )

    return local_target
