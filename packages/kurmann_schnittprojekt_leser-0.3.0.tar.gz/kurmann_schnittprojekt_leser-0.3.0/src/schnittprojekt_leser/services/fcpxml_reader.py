"""FCPXML-Parser via `lxml`.

Liefert ein neutrales internes Modell (`FcpxmlProject`) – `core/`-Module
arbeiten ausschliesslich gegen dieses Modell, nie gegen `lxml`-Elements
direkt.

FCPXML-Zeitwerte sind rationale Sekunden im Format `"<num>/<den>s"` (z. B.
`"106720/1200s"`) oder ganzzahlige Sekunden (`"30157s"`). Wir rationalisieren
hier zentral zu `float`, sodass alle Konsumenten in echten Sekunden rechnen.
"""

from __future__ import annotations

from pathlib import Path

from lxml import etree

from schnittprojekt_leser.models.errors import FcpxmlParseError
from schnittprojekt_leser.models.fcpxml import (
    FcpxmlAsset,
    FcpxmlProject,
    FcpxmlSpineClip,
    SequenceFormat,
)


def read_fcpxml(xml_path: Path) -> FcpxmlProject:
    """Parst eine FCPXML-Datei und liefert das neutrale interne Modell.

    Args:
        xml_path: Pfad zur `*.fcpxml`-Datei (bei Bundle-Variante zur
            `info.fcpxml` darin).

    Raises:
        FcpxmlParseError: Datei fehlt, ist kein FCPXML, oder erwartete
            Top-Level-Struktur (`<fcpxml>` → `<library>` → `<event>` →
            `<project>` → `<sequence>` → `<spine>`) ist nicht vorhanden.
    """
    if not xml_path.is_file():
        raise FcpxmlParseError(f"FCPXML-Datei nicht gefunden: {xml_path}")

    try:
        tree = etree.parse(str(xml_path))
    except etree.XMLSyntaxError as exc:
        raise FcpxmlParseError(f"FCPXML nicht parsbar ({xml_path.name}): {exc}") from exc

    root = tree.getroot()
    if root.tag != "fcpxml":
        raise FcpxmlParseError(
            f"Kein FCPXML-Wurzelelement (gefunden: <{root.tag}>)"
        )

    schema_version = root.get("version") or "unknown"

    # Resources: Format- und Asset-Pool
    sequence_format = _find_sequence_format(root)
    assets_by_id = _read_assets(root)

    # Library → Event → Project → Sequence → Spine
    project_elem = _require_first(root, ".//project", "Kein <project>-Element gefunden")
    project_name = project_elem.get("name") or xml_path.stem

    sequence_elem = _require_first(project_elem, "sequence", "Kein <sequence>-Element gefunden")
    spine_elem = _require_first(sequence_elem, "spine", "Kein <spine>-Element gefunden")

    audio_layout = sequence_elem.get("audioLayout")
    audio_rate = _parse_audio_rate(sequence_elem.get("audioRate"))

    spine_clips, nested_count = _read_spine(spine_elem, assets_by_id)
    timeline_duration = sum(c.duration_seconds for c in spine_clips)

    return FcpxmlProject(
        project_name=project_name,
        schema_version=schema_version,
        sequence_format=sequence_format,
        audio_layout=audio_layout,
        audio_rate=audio_rate,
        spine_clips=spine_clips,
        nested_spine_clip_count=nested_count,
        assets_by_id=assets_by_id,
        timeline_duration_seconds=timeline_duration,
    )


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------


def _require_first(parent: etree._Element, xpath: str, msg: str) -> etree._Element:
    """Erstes Element für den XPath, oder FcpxmlParseError mit Klartext."""
    elem = parent.find(xpath)
    if elem is None:
        raise FcpxmlParseError(msg)
    return elem


def _find_sequence_format(root: etree._Element) -> SequenceFormat:
    """Format-Profil aus dem Sequenz-Format. Phase-1-relevante Felder."""
    sequence = root.find(".//sequence")
    if sequence is None:
        raise FcpxmlParseError("Kein <sequence>-Element gefunden – keine Format-Info")
    fmt_id = sequence.get("format")
    fmt_elem = root.find(f".//resources/format[@id='{fmt_id}']") if fmt_id else None
    if fmt_elem is None:
        # Fallback: erstes Format-Element nehmen
        fmt_elem = root.find(".//resources/format")
    if fmt_elem is None:
        raise FcpxmlParseError("Kein <format>-Element in <resources>")

    width = int(fmt_elem.get("width") or 0)
    height = int(fmt_elem.get("height") or 0)
    frame_duration = _parse_seconds(fmt_elem.get("frameDuration") or "0s")
    color_space = fmt_elem.get("colorSpace")
    return SequenceFormat(
        width=width,
        height=height,
        frame_duration_seconds=frame_duration,
        color_space=color_space,
    )


def _read_assets(root: etree._Element) -> dict[str, FcpxmlAsset]:
    """Asset-Pool indexiert nach `@id`."""
    assets: dict[str, FcpxmlAsset] = {}
    for asset_elem in root.findall(".//resources/asset"):
        asset_id = asset_elem.get("id") or ""
        if not asset_id:
            continue
        src = asset_elem.get("src")
        has_video = asset_elem.get("hasVideo") == "1"
        has_audio = asset_elem.get("hasAudio") == "1"
        audio_rate = _parse_audio_rate(asset_elem.get("audioRate"))
        # `is_real_source`: Asset hat ein `src` UND ist kein reines
        # Bild-Asset für Generators/Titles. Heuristik: name endet auf
        # `.titleData` → kein echter Video-Clip.
        name = asset_elem.get("name") or ""
        is_real_source = bool(src) and not name.endswith(".titleData")
        assets[asset_id] = FcpxmlAsset(
            asset_id=asset_id,
            name=name,
            src_relative=src,
            has_video=has_video,
            has_audio=has_audio,
            audio_rate=audio_rate,
            is_real_source=is_real_source,
        )
    return assets


def _read_spine(
    spine_elem: etree._Element,
    assets_by_id: dict[str, FcpxmlAsset],
) -> tuple[list[FcpxmlSpineClip], int]:
    """Top-Level-Spine-Clips in Reihenfolge + Anzahl Lane-Sub-Spine-Clips."""
    clips: list[FcpxmlSpineClip] = []
    nested_count = 0

    for child in spine_elem:
        if child.tag != "asset-clip":
            # `<transition>`, `<gap>`, `<title>` etc. ignorieren wir – sie
            # tragen keine Quelldatei-Referenz.
            if child.tag in {"video", "title"}:
                # Generator/Title: wird später auch ignoriert, aber als
                # potenzieller Erst-Clip kann er Patrick's Spine eröffnen.
                pass
            continue
        ref = child.get("ref") or ""
        clip = FcpxmlSpineClip(
            asset_ref=ref,
            name=child.get("name") or "",
            offset_seconds=_parse_seconds(child.get("offset") or "0s"),
            start_seconds=_parse_seconds(child.get("start") or "0s"),
            duration_seconds=_parse_seconds(child.get("duration") or "0s"),
            audio_role=child.get("audioRole"),
            is_top_level_spine=True,
        )
        clips.append(clip)
        # Lane-Sub-Spines zählen
        for sub in child.iter():
            if sub is child:
                continue
            if sub.tag == "asset-clip":
                nested_count += 1
    return clips, nested_count


def _parse_seconds(raw: str) -> float:
    """Wandelt FCPXML-Zeitwert (`"<num>/<den>s"` oder `"<num>s"`) in float Sekunden.

    Beispiele:
        ``"30157s"`` → ``30157.0``
        ``"106720/1200s"`` → ``88.933...``
        ``"0s"`` → ``0.0``
    """
    s = raw.strip()
    if s.endswith("s"):
        s = s[:-1]
    if not s:
        return 0.0
    if "/" in s:
        num_str, _, den_str = s.partition("/")
        try:
            return float(num_str) / float(den_str)
        except (ValueError, ZeroDivisionError):
            return 0.0
    try:
        return float(s)
    except ValueError:
        return 0.0


def _parse_audio_rate(raw: str | None) -> int | None:
    """`"48000"` → `48000`, `"48k"` → `48000`, sonst `None`."""
    if raw is None:
        return None
    s = raw.strip().lower()
    if s.endswith("k"):
        try:
            return int(float(s[:-1]) * 1000)
        except ValueError:
            return None
    try:
        return int(s)
    except ValueError:
        return None
