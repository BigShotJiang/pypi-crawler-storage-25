"""iMovieMobile-Reader.

Öffnet ein `*.iMovieMobile`-ZIP-Bundle, parst die enthaltene
`iMovieMobileProject.plist` und liefert ein neutrales internes
Modell (`IMovieMobileProject`).

`plistlib` aus der Standardlib akzeptiert sowohl XML- als auch
Binary-Plists; iMovieMobile nutzt typischerweise XML.

Zeitbasis: 60 Frames/Sekunde – siehe `models/imovie.py`.
"""

from __future__ import annotations

import datetime as _dt
import plistlib
import zipfile
from pathlib import Path

from schnittprojekt_leser.models.errors import IMovieParseError
from schnittprojekt_leser.models.imovie import (
    IMOVIE_FRAMES_PER_SECOND,
    IMovieClip,
    IMovieMapLocation,
    IMovieMobileProject,
)

PROJECT_PLIST_NAME = "iMovieMobileProject.plist"


def read_imovie_mobile(zip_path: Path) -> IMovieMobileProject:
    """Öffnet das ZIP, parst das Projekt-Plist, liefert das Modell.

    Raises:
        IMovieParseError: ZIP nicht öffenbar, `iMovieMobileProject.plist`
            fehlt, oder erwartete Top-Level-Keys (`editInfo`, `editList`)
            sind nicht vorhanden.
    """
    if not zip_path.exists():
        raise IMovieParseError(f"iMovieMobile-Bundle nicht gefunden: {zip_path}")

    try:
        with zipfile.ZipFile(zip_path, "r") as archive:
            try:
                with archive.open(PROJECT_PLIST_NAME) as plist_file:
                    plist_bytes = plist_file.read()
            except KeyError as exc:
                raise IMovieParseError(
                    f"`{PROJECT_PLIST_NAME}` nicht im Bundle: {zip_path.name}"
                ) from exc
    except zipfile.BadZipFile as exc:
        raise IMovieParseError(
            f"`{zip_path.name}` ist kein gültiges ZIP-Archiv"
        ) from exc

    try:
        data: dict = plistlib.loads(plist_bytes)
    except plistlib.InvalidFileException as exc:
        raise IMovieParseError(
            f"`{PROJECT_PLIST_NAME}` ist kein gültiges Plist ({zip_path.name})"
        ) from exc

    edit_info = data.get("editInfo")
    if not isinstance(edit_info, dict):
        raise IMovieParseError(
            f"`editInfo` fehlt oder hat unerwarteten Typ in {zip_path.name}"
        )
    raw_edit_list = edit_info.get("editList")
    if not isinstance(raw_edit_list, list):
        raise IMovieParseError(
            f"`editInfo.editList` fehlt oder hat unerwarteten Typ in {zip_path.name}"
        )
    raw_cutaways = edit_info.get("cutaways") or []
    if not isinstance(raw_cutaways, list):
        raw_cutaways = []

    edit_list = [_clip_from_plist(entry) for entry in raw_edit_list if isinstance(entry, dict)]
    cutaways = [_clip_from_plist(entry) for entry in raw_cutaways if isinstance(entry, dict)]

    movie_version = _first_movie_version(edit_list, cutaways)
    timeline_seconds = sum(c.duration_seconds for c in edit_list)

    project_name = _project_name_from_path(zip_path)

    return IMovieMobileProject(
        project_name=project_name,
        uuid=_str_or_none(data.get("UUID")),
        contains_1080=bool(data.get("contains1080Content")),
        contains_2160=bool(data.get("contains2160h264Content")),
        contains_hdr=bool(data.get("containsHDRContent")),
        contains_hevc=bool(data.get("containsHEVCContent")),
        contains_prores=bool(data.get("containsProResContent")),
        movie_version=movie_version,
        edit_list=edit_list,
        cutaways=cutaways,
        timeline_duration_seconds=timeline_seconds,
    )


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------


def _project_name_from_path(zip_path: Path) -> str:
    """`Mein Projekt.iMovieMobile` → `Mein Projekt`."""
    name = zip_path.name
    suffix = ".iMovieMobile"
    if name.endswith(suffix):
        return name[: -len(suffix)]
    return zip_path.stem


def _clip_from_plist(entry: dict) -> IMovieClip:
    """Mappt einen Plist-Dict-Eintrag aus `editList`/`cutaways` auf `IMovieClip`."""
    clip_type = int(entry.get("clipType", 0) or 0)
    duration_frames = int(entry.get("duration", 0) or 0)
    duration_seconds = duration_frames / IMOVIE_FRAMES_PER_SECOND
    start_offset_frames = int(entry.get("startOffset", 0) or 0)
    start_offset_seconds = start_offset_frames / IMOVIE_FRAMES_PER_SECOND

    movie = entry.get("movie") if isinstance(entry.get("movie"), dict) else None
    creation_date_iso = _date_to_iso(entry.get("creationDate"))
    movie_creation_date_iso = _date_to_iso(movie.get("creationDate")) if movie else None
    relative_path = _str_or_none(movie.get("relativePath")) if movie else None

    title = entry.get("titleDefinition") if isinstance(entry.get("titleDefinition"), dict) else None
    title_text = _str_or_none(title.get("text")) if title else None
    title_subtitle = _str_or_none(title.get("text2")) if title else None

    map_location = _map_location_from_plist(movie.get("mapLocation") if movie else None)

    rotation = entry.get("rotation")
    rotation_deg = float(rotation) if isinstance(rotation, (int, float)) else None

    return IMovieClip(
        clip_type=clip_type,
        duration_seconds=duration_seconds,
        duration_frames=duration_frames,
        start_offset_seconds=start_offset_seconds,
        creation_date_iso=creation_date_iso,
        movie_creation_date_iso=movie_creation_date_iso,
        relative_path=relative_path,
        title_text=title_text,
        title_subtitle=title_subtitle,
        map_location=map_location,
        rotation_degrees=rotation_deg,
        transition_name=_str_or_none(entry.get("transitionName")),
    )


def _map_location_from_plist(raw) -> IMovieMapLocation | None:
    if not isinstance(raw, dict):
        return None
    lat = raw.get("Latitude")
    lon = raw.get("Longitude")
    return IMovieMapLocation(
        country_name=_str_or_none(raw.get("CountryName")),
        region_name=_str_or_none(raw.get("Name")),
        latitude=float(lat) if isinstance(lat, (int, float)) else None,
        longitude=float(lon) if isinstance(lon, (int, float)) else None,
    )


def _first_movie_version(
    edit_list: list[IMovieClip], cutaways: list[IMovieClip]
) -> str | None:
    """Liefert den ersten gefundenen `MovieVersion`-String aus dem Plist.

    `MovieVersion` lebt im Plist unter `editList[i].movie.MovieVersion`. Da
    `IMovieClip` selbst kein `MovieVersion` führt (das ist Plist-Detail-Info,
    die wir nicht für Konsumenten exponieren), greifen wir hier nicht auf
    das Modell zu – stattdessen liefern wir konservativ ``None``. Die Info
    ist für den Erstanwender nicht kritisch und kann später ergänzt werden,
    falls ein Konsument sie braucht.
    """
    return None


def _str_or_none(value) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        s = value.strip()
        return s or None
    return str(value)


def _date_to_iso(value) -> str | None:
    """Wandelt ein Plist-`<date>` (`datetime.datetime`) in ISO 8601 mit `Z`-UTC-Suffix.

    `plistlib` parst `<date>`-Tags als `datetime.datetime` mit UTC-tzinfo
    bzw. ohne (je nach Plist). Wir normalisieren auf ISO 8601 mit Offset.
    Andere Typen werden ignoriert.
    """
    if value is None:
        return None
    if isinstance(value, _dt.datetime):
        if value.tzinfo is None:
            # plistlib liefert seit 3.11 immer aware-datetimes für <date>.
            # Sicherheitshalber: naive Werte als UTC interpretieren.
            value = value.replace(tzinfo=_dt.timezone.utc)
        return value.isoformat(timespec="seconds")
    if isinstance(value, str):
        return value.strip() or None
    return None
