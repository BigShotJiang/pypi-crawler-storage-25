"""Wrapper um `exiftool`.

Spiegelt Tag-Liste und Aufrufmuster aus
`kamera-einleser/services/exiftool_runner.py`. Tag-Pfade werden mit
`-G1` (Family-1-Gruppen) explizit benannt, damit gleichnamige Tags
aus verschiedenen Atomen (Keys vs. QuickTime vs. ExifIFD) sauber
unterscheidbar sind.

Verbindung zur Konfidenz-Hierarchie: siehe `core.recorded_at`.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from schnittprojekt_leser.models.dates import DateSources
from schnittprojekt_leser.models.errors import ExiftoolError, ExiftoolUnavailableError
from schnittprojekt_leser.models.runtime import RuntimeOptions

# Welche exiftool-Tags wir abfragen. Bewusst explizit aufgelistet, damit
# wir nicht versehentlich auf riesige Output-Dumps angewiesen sind und
# nicht über unbekannte Felder stolpern.
_EXIFTOOL_TAGS: list[str] = [
    "-Keys:CreationDate",
    "-QuickTime:CreationDate",
    "-CreateDate",
    "-DateTimeOriginal",
    "-Blackmagic-design:CameraDateRecorded",
]


def check_exiftool_available(runtime: RuntimeOptions) -> bool:
    """True, wenn das konfigurierte exiftool-Binary auffindbar ist."""
    return shutil.which(runtime.exiftool_path) is not None


def read_dates(
    file_path: Path,
    runtime: RuntimeOptions,
    on_output: Callable[[str], None] | None = None,
) -> DateSources:
    """Liest Datums-Tags und Filesystem-Stempel und mappt sie auf `DateSources`.

    Args:
        file_path: Quelldatei (MOV, M4V, JPG, HEIC, ...).
        runtime: konfigurierter exiftool-Pfad und Timeout.
        on_output: optionaler Callback für rohen exiftool-stderr/stdout-Output.

    Raises:
        ExiftoolUnavailableError: exiftool nicht im PATH bzw. unter `exiftool_path`.
        ExiftoolError: Aufruf scheiterte, Timeout, ungültiges JSON.
    """
    if not check_exiftool_available(runtime):
        raise ExiftoolUnavailableError(
            f"exiftool nicht gefunden ({runtime.exiftool_path}). "
            "Installation: `brew install exiftool` (macOS) oder via deinen "
            "Paketmanager. Pfad konfigurierbar via RuntimeOptions.exiftool_path."
        )

    cmd = [runtime.exiftool_path, "-j", "-G1", *_EXIFTOOL_TAGS, str(file_path)]
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=runtime.exiftool_timeout_seconds,
        )
    except subprocess.TimeoutExpired as exc:
        raise ExiftoolError(
            f"exiftool-Timeout nach {runtime.exiftool_timeout_seconds}s für {file_path.name}"
        ) from exc

    if on_output:
        if proc.stdout:
            on_output(proc.stdout)
        if proc.stderr:
            on_output(proc.stderr)

    if proc.returncode != 0:
        raise ExiftoolError(
            f"exiftool fehlgeschlagen für {file_path.name}: "
            f"{(proc.stderr or proc.stdout).strip()}"
        )

    try:
        data = json.loads(proc.stdout or "[]")
    except json.JSONDecodeError as exc:
        raise ExiftoolError(
            f"exiftool lieferte kein gültiges JSON für {file_path.name}: {exc}"
        ) from exc

    raw_meta: dict = data[0] if data else {}
    return _build_date_sources(raw_meta, file_path)


# ---------------------------------------------------------------------------
# Mapping-Helfer
# ---------------------------------------------------------------------------


def _g(meta: dict, *keys: str) -> str | None:
    """Erster nicht-leerer Wert aus mehreren möglichen Tag-Pfaden."""
    for k in keys:
        v = meta.get(k)
        if v is None or v == "":
            continue
        return v if isinstance(v, str) else str(v)
    return None


def _build_date_sources(meta: dict, file_path: Path) -> DateSources:
    """Mappt rohen exiftool-JSON + Filesystem-Stat auf `DateSources`.

    Die Reihenfolge der Tag-Lookups innerhalb eines Felds folgt dem
    kamera-einleser-Vorbild (Keys vor QuickTime vor IFD).
    """
    try:
        stat = file_path.stat()
    except OSError:
        # Datei zwar parsbar (exiftool lief), aber nicht stat-bar – sehr selten.
        # Filesystem-Stempel bleiben dann leer.
        return DateSources(
            keys_creation_date=_g(meta, "Keys:CreationDate"),
            exif_creation_date=_g(meta, "QuickTime:CreationDate", "CreationDate"),
            exif_datetime_original=_g(meta, "ExifIFD:DateTimeOriginal", "DateTimeOriginal"),
            exif_create_date=_g(meta, "QuickTime:CreateDate", "ExifIFD:CreateDate", "CreateDate"),
            blackmagic_date_recorded=_g(
                meta,
                "Blackmagic-design:CameraDateRecorded",
                "QuickTime:CameraDateRecorded",
            ),
        )

    return DateSources(
        keys_creation_date=_g(meta, "Keys:CreationDate"),
        exif_creation_date=_g(meta, "QuickTime:CreationDate", "CreationDate"),
        exif_datetime_original=_g(meta, "ExifIFD:DateTimeOriginal", "DateTimeOriginal"),
        exif_create_date=_g(meta, "QuickTime:CreateDate", "ExifIFD:CreateDate", "CreateDate"),
        blackmagic_date_recorded=_g(
            meta,
            "Blackmagic-design:CameraDateRecorded",
            "QuickTime:CameraDateRecorded",
        ),
        file_birthtime=_format_fs_time(getattr(stat, "st_birthtime", None)),
        file_mtime=_format_fs_time(stat.st_mtime),
    )


def _format_fs_time(epoch_seconds: float | None) -> str | None:
    """Formatiert einen Filesystem-Zeitstempel als ISO-8601 mit lokaler TZ.

    Format `YYYY-MM-DDTHH:MM:SS+HH:MM` (mit `:` im TZ-Offset).
    """
    if epoch_seconds is None or epoch_seconds <= 0:
        return None
    dt = datetime.fromtimestamp(epoch_seconds, tz=timezone.utc).astimezone()
    return dt.isoformat(timespec="seconds")
