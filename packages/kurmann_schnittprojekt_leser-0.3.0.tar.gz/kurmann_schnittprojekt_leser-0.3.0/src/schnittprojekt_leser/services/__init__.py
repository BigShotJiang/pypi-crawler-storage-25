"""I/O-Services: FCPXML-Parser, exiftool-Wrapper, rclone-Wrapper, Quell-Resolver.

Werden von `core/`-Modulen benutzt, nicht von `core/` direkt importiert –
die Schichtung wird durch Funktions-Argumente eingehalten (Dependency
Injection auf Funktionsebene).
"""
