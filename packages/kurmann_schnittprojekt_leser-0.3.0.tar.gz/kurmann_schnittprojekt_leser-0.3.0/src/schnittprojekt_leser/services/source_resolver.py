"""Quelldatei-Auflösung: lokal neben Projektdatei, lokale Search-Roots, rclone-Roots.

Wird von `core.first_clip_date` benutzt, um aus einem
`FcpxmlAsset.src_relative` einen lokal lesbaren Pfad zu machen, den
exiftool dann verarbeitet.
"""

from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from schnittprojekt_leser.models.runtime import RcloneSource, RuntimeOptions
from schnittprojekt_leser.services.rclone_source import copy_file, list_files, nfc_normalize


@dataclass
class ResolvedSource:
    """Ergebnis der Quell-Auflösung.

    `local_path` ist immer ein lesbarer lokaler Pfad. `is_temporary=True`
    bedeutet, dass die Datei aus einer rclone-Quelle in ein Temp-Verzeichnis
    kopiert wurde und vom Aufrufer nach Gebrauch entsorgt werden sollte
    (siehe `cleanup`).
    """

    local_path: Path
    origin_describe: str
    is_temporary: bool
    _temp_dir: Path | None = None

    def cleanup(self) -> None:
        """Entfernt die heruntergeladene Datei und ggf. das Temp-Verzeichnis."""
        if not self.is_temporary:
            return
        try:
            self.local_path.unlink(missing_ok=True)
        except OSError:
            pass
        if self._temp_dir is not None:
            try:
                self._temp_dir.rmdir()
            except OSError:
                pass


def resolve_source_file(
    asset_src_relative: str,
    project_path: Path,
    runtime: RuntimeOptions,
    on_output: Callable[[str], None] | None = None,
) -> ResolvedSource | None:
    """Findet die Quelldatei zu einem FCPXML-Asset-`src`-Wert.

    Suchreihenfolge:

    1. **Direkt neben der Projektdatei**: `project_path.parent / asset_src_relative`.
       Bei Bundle-Variante (`.fcpxmld/`) ist `project_path` die `info.fcpxml`,
       Bundle-interne Quellen liegen direkt daneben.
    2. **`runtime.source_search_roots`** in Reihenfolge. Pro Root:
       - `Path` → rekursive Suche per Dateiname (NFC-normalisiert), bis
         `runtime.source_search_max_depth` Unterverzeichnis-Ebenen.
       - `RcloneSource` → `rclone lsf` mit Tiefen-Limit, bei Match per
         Dateiname wird die Datei via `rclone copyto` ins Temp geholt.

    Erster Treffer gewinnt.

    Returns:
        `ResolvedSource` bei Erfolg, sonst `None`.
    """
    expected_name = nfc_normalize(Path(asset_src_relative).name)

    # 1. Direkt neben der Projektdatei
    direct = (project_path.parent / asset_src_relative).resolve()
    if direct.is_file():
        return ResolvedSource(
            local_path=direct,
            origin_describe=str(direct),
            is_temporary=False,
        )

    # 2. Search-Roots
    max_depth = runtime.source_search_max_depth
    for root in runtime.source_search_roots:
        if isinstance(root, RcloneSource):
            hit = _find_in_rclone(root, expected_name, runtime, max_depth, on_output)
            if hit is not None:
                return hit
        else:
            hit = _find_in_local_root(root, expected_name, max_depth)
            if hit is not None:
                return ResolvedSource(
                    local_path=hit,
                    origin_describe=str(hit),
                    is_temporary=False,
                )
    return None


def _find_in_local_root(root: Path, expected_name_nfc: str, max_depth: int) -> Path | None:
    """Sucht rekursiv (begrenzt) im lokalen Root nach passendem Dateinamen."""
    if not root.is_dir():
        return None
    root_resolved = root.resolve()
    root_depth = len(root_resolved.parts)
    for current_dir, dirnames, filenames in os.walk(root_resolved):
        current_path = Path(current_dir)
        depth_below_root = len(current_path.parts) - root_depth
        if depth_below_root > max_depth:
            # Weiter absteigen wir nicht
            dirnames.clear()
            continue
        for name in filenames:
            if nfc_normalize(name) == expected_name_nfc:
                return current_path / name
    return None


def _find_in_rclone(
    source: RcloneSource,
    expected_name_nfc: str,
    runtime: RuntimeOptions,
    max_depth: int,
    on_output: Callable[[str], None] | None,
) -> ResolvedSource | None:
    """Listet rclone-Remote, sucht nach Filename, kopiert bei Treffer ins Temp."""
    listing = list_files(source, runtime, max_depth, on_output=on_output)
    for relative in listing:
        name = nfc_normalize(Path(relative).name)
        if name == expected_name_nfc:
            temp_dir_str = tempfile.mkdtemp(
                prefix="schnittprojekt-leser-",
                dir=str(runtime.temp_dir) if runtime.temp_dir else None,
            )
            temp_dir = Path(temp_dir_str)
            local = copy_file(source, relative, temp_dir, runtime, on_output=on_output)
            return ResolvedSource(
                local_path=local,
                origin_describe=f"{source.describe()} → {local}",
                is_temporary=True,
                _temp_dir=temp_dir,
            )
    return None
