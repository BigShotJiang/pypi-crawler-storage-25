"""CLI-Entrypoint `schnittprojekt-leser`.

Dünner Adapter über der Public-API. stdout/stderr-Disziplin gemäss
`kurmann-cli-und-config`-Skill:

- **stdout** – nur Ergebnisdaten (Datum, JSON, Übersicht). Pipeline-fähig.
- **stderr** – Events, Warnungen, Diagnose, roher Tool-Output (nur mit
  `--verbose`).
- `--verbose` ändert nie stdout.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from enum import StrEnum
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from schnittprojekt_leser import __version__
from schnittprojekt_leser.api import read_first_clip_date, read_project_summary
from schnittprojekt_leser.models import (
    RcloneSource,
    ReadFirstClipDateRequest,
    ReadProjectSummaryRequest,
    RuntimeOptions,
    SchnittprojektLeserEvent,
    parse_source_spec,
)

app = typer.Typer(
    name="schnittprojekt-leser",
    help="Read-only-Bibliothek für Videoschnitt-Projekte (FCPXML).",
    no_args_is_help=True,
)
inspect_app = typer.Typer(help="Inspektoren für Schnittprojekt-Dateien.")
app.add_typer(inspect_app, name="inspect")

stdout_console = Console()
stderr_console = Console(stderr=True)


class FirstClipDateFormat(StrEnum):
    VALUE = "value"
    JSON = "json"
    ISO_DATETIME = "iso-datetime"


class SummaryFormat(StrEnum):
    TEXT = "text"
    JSON = "json"


@app.callback()
def _main_callback(
    version: bool = typer.Option(False, "--version", help="Version anzeigen und beenden."),
) -> None:
    if version:
        stdout_console.print(__version__)
        raise typer.Exit(code=0)


@inspect_app.command(name="first-clip-date")
def inspect_first_clip_date(
    project_path: Path = typer.Argument(
        ...,
        exists=True,
        file_okay=True,
        dir_okay=True,
        readable=True,
        help="Pfad zur FCPXML-Datei oder zum FCPXMLD-Bundle-Verzeichnis.",
    ),
    output_format: FirstClipDateFormat = typer.Option(
        FirstClipDateFormat.VALUE,
        "--format",
        "-f",
        help="Ausgabeformat. 'value' = nur ISO-Datum, 'json' = vollständiges Result, 'iso-datetime' = Vollzeitstempel falls bekannt.",
    ),
    timezone_assumption: str | None = typer.Option(
        None,
        "--timezone",
        "-t",
        help="IANA-Zeitzonen-Name für Wallclock-Datum, z. B. 'Europe/Zurich'.",
    ),
    source_search_root: list[str] = typer.Option(
        [],
        "--source-root",
        "-r",
        help="Zusätzliches Suchverzeichnis für Quelldateien. Mehrfach angebbar. "
        "Akzeptiert lokale Pfade und rclone-Specs (z. B. 'lyssach-nas:/Videoschnitt').",
    ),
    source_search_max_depth: int = typer.Option(
        2,
        "--source-depth",
        help="Maximale Rekursionstiefe pro --source-root.",
    ),
    exiftool_path: str = typer.Option(
        "exiftool", "--exiftool", help="Pfad zum exiftool-Binary."
    ),
    rclone_path: str = typer.Option(
        "rclone", "--rclone", help="Pfad zum rclone-Binary (nur für rclone-Quellen)."
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Diagnose-Output auf stderr."
    ),
) -> None:
    """Liest das Aufnahmedatum des ersten Clips."""
    runtime = RuntimeOptions(
        exiftool_path=exiftool_path,
        rclone_path=rclone_path,
        source_search_roots=[parse_source_spec(s) for s in source_search_root],
        source_search_max_depth=source_search_max_depth,
    )
    on_event, on_output = _make_callbacks(verbose)

    request = ReadFirstClipDateRequest(
        project_path=project_path,
        timezone_assumption=timezone_assumption,
    )
    result = read_first_clip_date(request, runtime, on_event=on_event, on_output=on_output)

    for warning in result.warnings:
        stderr_console.print(f"[yellow]Warnung:[/yellow] {warning}")

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    if output_format is FirstClipDateFormat.JSON:
        stdout_console.print_json(json.dumps(_result_to_dict(result), default=str))
    elif output_format is FirstClipDateFormat.ISO_DATETIME:
        print(result.iso_datetime or result.iso_date or "")
    else:  # VALUE
        print(result.iso_date or "")


@inspect_app.command(name="summary")
def inspect_summary(
    project_path: Path = typer.Argument(
        ...,
        exists=True,
        file_okay=True,
        dir_okay=True,
        readable=True,
        help="Pfad zur FCPXML-Datei oder zum FCPXMLD-Bundle-Verzeichnis.",
    ),
    output_format: SummaryFormat = typer.Option(
        SummaryFormat.TEXT,
        "--format",
        "-f",
        help="Ausgabeformat. 'text' = menschenlesbar, 'json' = vollständiges Result.",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Diagnose-Output auf stderr."
    ),
) -> None:
    """Liefert eine Übersicht des Schnittprojekts (Name, Auflösung, Dauer, Clip-Anzahl)."""
    on_event, _ = _make_callbacks(verbose)

    request = ReadProjectSummaryRequest(project_path=project_path)
    result = read_project_summary(request, on_event=on_event)

    for warning in result.warnings:
        stderr_console.print(f"[yellow]Warnung:[/yellow] {warning}")

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    if output_format is SummaryFormat.JSON:
        stdout_console.print_json(json.dumps(_result_to_dict(result), default=str))
    else:
        _print_summary_text(result)


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------


def _make_callbacks(verbose: bool):
    """Stellt on_event/on_output je nach `--verbose` bereit."""

    def on_event(event: SchnittprojektLeserEvent) -> None:
        if verbose:
            stderr_console.print(f"[dim][{event.stage_id}][/dim] {event.message}")

    def on_output(text: str) -> None:
        if verbose:
            stderr_console.print(text, end="")

    return on_event, on_output


def _result_to_dict(result: Any) -> dict:
    """Dataclass → Dict, Pfade als Strings, Tuples als Listen."""
    raw = asdict(result)
    return _normalize_for_json(raw)


def _normalize_for_json(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _normalize_for_json(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_normalize_for_json(v) for v in value]
    if isinstance(value, tuple):
        return [_normalize_for_json(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, RcloneSource):
        return value.describe()
    if isinstance(value, StrEnum):
        return value.value
    return value


def _print_summary_text(result) -> None:
    """Menschenlesbare Übersicht auf stdout."""
    name = result.project_name or "?"
    fmt = result.project_format.value if result.project_format else "?"
    schema = result.schema_version or "?"
    clips = result.clip_count_primary if result.clip_count_primary is not None else "?"
    total = result.clip_count_total if result.clip_count_total is not None else "?"
    duration = (
        f"{result.timeline_duration_seconds:.1f}s"
        if result.timeline_duration_seconds is not None
        else "?"
    )
    res = (
        f"{result.video_resolution[0]}×{result.video_resolution[1]}"
        if result.video_resolution
        else "?"
    )
    color = result.color_space or "(kein Farbraum-Hinweis)"
    audio = result.audio_layout or "?"

    lines = [
        f"Projekt: {name}",
        f"Format: {fmt} (Schema {schema})",
        f"Auflösung: {res}",
        f"Farbraum: {color}",
        f"Audio: {audio}",
        f"Timeline-Dauer: {duration}",
        f"Clips primär: {clips}",
        f"Clips total (inkl. sekundärer Spuren): {total}",
    ]
    if result.project_mtime_iso:
        lines.append(f"Projektdatei mtime: {result.project_mtime_iso}")
    print("\n".join(lines))
