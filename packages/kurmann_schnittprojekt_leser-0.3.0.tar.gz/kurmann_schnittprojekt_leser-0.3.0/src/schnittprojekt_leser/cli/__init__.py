"""Typer-CLI-Adapter über der Public-API."""
