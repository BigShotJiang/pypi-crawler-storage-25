"""Best-Guess-Aufnahmedatum aus `DateSources` mit Provenance-Tracking.

Spiegelt 1:1 die Logik aus
`kamera-einleser/services/date_extractor.py:46–181`. API-spiegelnd, damit
eine spätere Extraktion in eine gemeinsame `kurmann-recorded-at`-Lib
mechanisch möglich ist.

Schlüssel-Aspekte:

- **Format-Normalisierung** – exiftool liefert oft `2026:04:20 12:52:15`,
  wir normalisieren auf saubere ISO-8601 (`2026-04-20T12:52:15`).
- **Hierarchie** – fest definierte 7-stufige Vertrauensreihenfolge.
- **TZ-Inferenz für Final Cut Camera** – wenn `exif_create_date` UTC
  ohne TZ-Marker ist, wird die TZ aus `file_mtime` abgeleitet und
  applied. Source-Label bekommt Suffix `+tz_from_mtime`.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

from schnittprojekt_leser.models.dates import (
    SOURCE_FILE_BIRTHTIME,
    SOURCE_FILE_MTIME,
    DateSources,
)
from schnittprojekt_leser.models.formats import ClipDateConfidence

# ---------------------------------------------------------------------------
# Format-Normalisierung
# ---------------------------------------------------------------------------

_EXIF_DATE_RE = re.compile(
    r"^(\d{4}):(\d{2}):(\d{2})[ T](\d{2}):(\d{2}):(\d{2})(.*)$"
)


def normalize_iso_date(raw: str | None) -> str | None:
    """Normalisiert ein exiftool-Datum auf ISO-8601.

    Beispiele:
        ``"2026:04:20 12:52:15+02:00"`` → ``"2026-04-20T12:52:15+02:00"``
        ``"2026:04:20 12:52:15"`` → ``"2026-04-20T12:52:15"``
        ``"2026-04-20T12:52:15+02:00"`` → ``"2026-04-20T12:52:15+02:00"`` (idempotent)

    Wenn der Input nicht parsbar ist, wird er unverändert durchgereicht –
    besser als ihn zu verwerfen.
    """
    if raw is None:
        return None
    s = raw.strip()
    if not s:
        return None
    m = _EXIF_DATE_RE.match(s)
    if not m:
        return s
    yyyy, mo, dd, hh, mi, ss, rest = m.groups()
    return f"{yyyy}-{mo}-{dd}T{hh}:{mi}:{ss}{rest}"


def parse_iso_date(raw: str) -> datetime | None:
    """Parsed einen normalisierten ISO-8601-String. None bei Fehlschlag."""
    s = normalize_iso_date(raw)
    if s is None:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None


def has_timezone(iso_string: str | None) -> bool:
    """True, wenn ein normalisierter ISO-8601-String einen TZ-Offset hat."""
    if not iso_string:
        return False
    return bool(re.search(r"(\+|-)\d{2}:?\d{2}$|Z$", iso_string.strip()))


def _infer_tz_from_mtime(naive_utc_iso: str, mtime_iso: str | None) -> str | None:
    """Wandelt ein naives UTC-Datum in lokale TZ um, abgeleitet von mtime.

    Final-Cut-Camera-Sonderfall: schreibt `CreateDate` in UTC ohne TZ-Marker.
    Wenn als-ist angezeigt, wird der Wert als lokale Zeit missverstanden
    (1–2 Stunden falsch). Wir inferieren die TZ aus `file_mtime`.
    """
    if not mtime_iso or has_timezone(naive_utc_iso):
        return None
    mtime_dt = parse_iso_date(mtime_iso)
    if mtime_dt is None or mtime_dt.utcoffset() is None:
        return None
    naive = parse_iso_date(naive_utc_iso)
    if naive is None:
        return None
    utc_aware = naive.replace(tzinfo=timezone.utc)
    local_aware = utc_aware.astimezone(mtime_dt.tzinfo)
    return local_aware.isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# Hierarchie und Konfidenz-Mapping
# ---------------------------------------------------------------------------

# Reihenfolge = Vertrauens-Hierarchie. Erstes Feld mit nicht-leerem Wert
# wird gewählt. Spiegelt kamera-einleser/_DATE_PRIORITY exakt.
_DATE_PRIORITY: list[tuple[str, str, ClipDateConfidence]] = [
    # (DateSources-Feldname, source_label, ClipDateConfidence)
    ("keys_creation_date", "exif:Keys:CreationDate", ClipDateConfidence.HIGH),
    ("exif_creation_date", "exif:CreationDate", ClipDateConfidence.HIGH),
    (
        "blackmagic_date_recorded",
        "exif:Blackmagic-design:CameraDateRecorded",
        ClipDateConfidence.HIGH,
    ),
    ("exif_datetime_original", "exif:DateTimeOriginal", ClipDateConfidence.HIGH),
    ("exif_create_date", "exif:CreateDate", ClipDateConfidence.MEDIUM),
    ("file_birthtime", SOURCE_FILE_BIRTHTIME, ClipDateConfidence.MEDIUM),
    ("file_mtime", SOURCE_FILE_MTIME, ClipDateConfidence.LOW),
]


def pick_recorded_at(
    dates: DateSources,
) -> tuple[str | None, str | None, ClipDateConfidence]:
    """Liefert `(iso_datetime, source_label, confidence)` aus den Datums-Quellen.

    Algorithmus:

    1. Iteriere `_DATE_PRIORITY` (höchste Vertrauens-Quelle zuerst).
    2. Erste Quelle mit nicht-leerem Wert wird normalisiert.
    3. Sonderfall Final Cut Camera: bei `exif_create_date` ohne TZ-Marker
       wird die TZ aus `file_mtime` inferiert (Source-Label-Suffix
       ``+tz_from_mtime``).
    4. Konfidenz wird aus der Hierarchie-Position abgeleitet.

    Alle Rückgabewerte ``None``/``UNKNOWN``, wenn keine Quelle einen Wert
    liefert.
    """
    for field_name, source_label, confidence in _DATE_PRIORITY:
        value = getattr(dates, field_name, None)
        if not value:
            continue
        normalized = normalize_iso_date(value)
        if (
            field_name == "exif_create_date"
            and not has_timezone(normalized)
            and dates.file_mtime
        ):
            inferred = _infer_tz_from_mtime(normalized, dates.file_mtime)
            if inferred:
                return inferred, f"{source_label}+tz_from_mtime", confidence
        return normalized, source_label, confidence
    return None, None, ClipDateConfidence.UNKNOWN
