"""Komposition `read_project_summary`: Format-Detection + Dispatch FCPXML/iMovieMobile.

Rein FCPXML/iMovieMobile-internes Lesen, kein Quelldatei-Zugriff –
schnell, ohne externe Abhängigkeiten.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Callable

from schnittprojekt_leser.core.format_detection import detect_format, resolve_inner_xml_path
from schnittprojekt_leser.models.events import ProjectSummaryStage, SchnittprojektLeserEvent
from schnittprojekt_leser.models.formats import ProjectFormat
from schnittprojekt_leser.models.imovie import IMovieMobileProject
from schnittprojekt_leser.models.requests import ReadProjectSummaryResult
from schnittprojekt_leser.services.fcpxml_reader import read_fcpxml
from schnittprojekt_leser.services.imovie_mobile_reader import read_imovie_mobile


def read_project_summary(
    project_path: Path,
    on_event: Callable[[SchnittprojektLeserEvent], None] | None = None,
) -> ReadProjectSummaryResult:
    """Hauptkomposition für Projekt-Übersicht."""
    _emit(
        on_event,
        ProjectSummaryStage.FORMAT_DETECTION_STARTED,
        f"Format-Detection für {project_path}",
    )
    project_format = detect_format(project_path)
    _emit(
        on_event,
        ProjectSummaryStage.FORMAT_DETECTED,
        f"Format erkannt: {project_format.value}",
    )

    if project_format is ProjectFormat.IMOVIE_MOBILE_ZIP:
        return _summary_imovie(project_path, project_format, on_event)
    return _summary_fcpxml(project_path, project_format, on_event)


# ---------------------------------------------------------------------------
# FCPXML-Pfad
# ---------------------------------------------------------------------------


def _summary_fcpxml(
    project_path: Path,
    project_format: ProjectFormat,
    on_event: Callable[[SchnittprojektLeserEvent], None] | None,
) -> ReadProjectSummaryResult:
    xml_path = resolve_inner_xml_path(project_path, project_format)

    _emit(
        on_event,
        ProjectSummaryStage.FCPXML_PARSING_STARTED,
        f"Parse FCPXML {xml_path.name}",
    )
    project = read_fcpxml(xml_path)
    _emit(
        on_event,
        ProjectSummaryStage.FCPXML_PARSED,
        f"FCPXML geparst: {project.project_name}, "
        f"{len(project.spine_clips)} primäre Clips",
    )

    return ReadProjectSummaryResult(
        success=True,
        project_name=project.project_name,
        project_format=project_format,
        schema_version=project.schema_version,
        timeline_duration_seconds=project.timeline_duration_seconds,
        clip_count_primary=len(project.spine_clips),
        clip_count_total=len(project.spine_clips) + project.nested_spine_clip_count,
        video_resolution=(project.sequence_format.width, project.sequence_format.height),
        color_space=project.sequence_format.color_space,
        audio_layout=project.audio_layout,
        project_mtime_iso=_project_mtime_iso(project_path),
    )


# ---------------------------------------------------------------------------
# iMovieMobile-Pfad
# ---------------------------------------------------------------------------


def _summary_imovie(
    project_path: Path,
    project_format: ProjectFormat,
    on_event: Callable[[SchnittprojektLeserEvent], None] | None,
) -> ReadProjectSummaryResult:
    _emit(
        on_event,
        ProjectSummaryStage.FCPXML_PARSING_STARTED,
        f"Parse iMovieMobile-Bundle {project_path.name}",
    )
    project = read_imovie_mobile(project_path)
    _emit(
        on_event,
        ProjectSummaryStage.FCPXML_PARSED,
        f"iMovieMobile geparst: {project.project_name}, "
        f"{len(project.edit_list)} editList-Einträge",
    )

    return ReadProjectSummaryResult(
        success=True,
        project_name=project.project_name,
        project_format=project_format,
        schema_version=project.movie_version,
        timeline_duration_seconds=project.timeline_duration_seconds,
        clip_count_primary=len(project.edit_list),
        clip_count_total=len(project.edit_list) + len(project.cutaways),
        video_resolution=_imovie_resolution(project),
        color_space=_imovie_color_space(project),
        audio_layout=None,
        project_mtime_iso=_project_mtime_iso(project_path),
    )


def _imovie_resolution(project: IMovieMobileProject) -> tuple[int, int] | None:
    """Heuristische Auflösung aus den `contains*Content`-Flags (höchste gewinnt)."""
    if project.contains_2160:
        return (3840, 2160)
    if project.contains_1080:
        return (1920, 1080)
    return None


def _imovie_color_space(project: IMovieMobileProject) -> str | None:
    """`HDR` / `SDR` / `None` – iMovie-Plist exponiert keinen detaillierten Farbraum."""
    if project.contains_hdr:
        return "HDR"
    if project.contains_1080 or project.contains_2160:
        return "SDR"
    return None


# ---------------------------------------------------------------------------
# Gemeinsame Hilfen
# ---------------------------------------------------------------------------


def _project_mtime_iso(project_path: Path) -> str | None:
    try:
        mtime_epoch = project_path.stat().st_mtime
    except OSError:
        return None
    return datetime.fromtimestamp(mtime_epoch).astimezone().isoformat(timespec="seconds")


def _emit(
    on_event: Callable[[SchnittprojektLeserEvent], None] | None,
    stage: ProjectSummaryStage,
    message: str,
) -> None:
    if on_event is None:
        return
    on_event(SchnittprojektLeserEvent(stage_id=stage.value, message=message))
