"""Komposition `read_first_clip_date`: Format-Detection + Dispatch FCPXML/iMovieMobile.

Das ist die Kernoperation der Bibliothek. Strikt funktional, fängt
keine Exceptions – die werden in der API-Fassade auf `error_message`
abgebildet.

Dispatch nach Format:

- **FCPXML** (Datei oder Bundle): Spine-Parsing → Source-Resolver →
  exiftool → Hierarchie-Auswahl. Sieben Konfidenz-Stufen.
- **iMovieMobile-ZIP**: ZIP öffnen → Plist parsen → erste `editList`-
  Eintrag mit `clipType=1` → `creationDate` direkt. Kein Quelldatei-
  Lesepass, kein exiftool. HIGH-Konfidenz.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Callable
from zoneinfo import ZoneInfo

from schnittprojekt_leser.core.format_detection import detect_format, resolve_inner_xml_path
from schnittprojekt_leser.core.recorded_at import (
    has_timezone,
    parse_iso_date,
    pick_recorded_at,
)
from schnittprojekt_leser.models.dates import (
    SOURCE_IMOVIE_EDITLIST_CREATION_DATE,
    SOURCE_PROJECT_FALLBACK,
    DateSources,
)
from schnittprojekt_leser.models.events import (
    FirstClipDateStage,
    SchnittprojektLeserEvent,
)
from schnittprojekt_leser.models.fcpxml import FcpxmlProject
from schnittprojekt_leser.models.formats import ClipDateConfidence, ProjectFormat
from schnittprojekt_leser.models.requests import ReadFirstClipDateResult
from schnittprojekt_leser.models.runtime import RuntimeOptions
from schnittprojekt_leser.services.exiftool_runner import read_dates as exiftool_read_dates
from schnittprojekt_leser.services.fcpxml_reader import read_fcpxml
from schnittprojekt_leser.services.imovie_mobile_reader import read_imovie_mobile
from schnittprojekt_leser.services.source_resolver import resolve_source_file


def read_first_clip_date(
    project_path: Path,
    runtime: RuntimeOptions,
    timezone_assumption: str | None,
    on_event: Callable[[SchnittprojektLeserEvent], None] | None = None,
    on_output: Callable[[str], None] | None = None,
) -> ReadFirstClipDateResult:
    """Hauptkomposition. Liefert befülltes Result.

    Erwartet, dass der Aufrufer (API-Fassade) Exceptions fängt; hier
    werden absichtlich keine Try/Excepts gesetzt, damit der Datenfluss
    klar bleibt.
    """
    _emit(
        on_event,
        FirstClipDateStage.FORMAT_DETECTION_STARTED,
        f"Format-Detection für {project_path}",
    )
    project_format = detect_format(project_path)
    _emit(
        on_event,
        FirstClipDateStage.FORMAT_DETECTED,
        f"Format erkannt: {project_format.value}",
    )

    if project_format is ProjectFormat.IMOVIE_MOBILE_ZIP:
        return _read_first_clip_date_imovie(
            project_path, project_format, timezone_assumption, on_event
        )

    return _read_first_clip_date_fcpxml(
        project_path,
        project_format,
        runtime,
        timezone_assumption,
        on_event,
        on_output,
    )


# ---------------------------------------------------------------------------
# FCPXML-Pfad (bestehende Logik)
# ---------------------------------------------------------------------------


def _read_first_clip_date_fcpxml(
    project_path: Path,
    project_format: ProjectFormat,
    runtime: RuntimeOptions,
    timezone_assumption: str | None,
    on_event: Callable[[SchnittprojektLeserEvent], None] | None,
    on_output: Callable[[str], None] | None,
) -> ReadFirstClipDateResult:
    warnings: list[str] = []
    xml_path = resolve_inner_xml_path(project_path, project_format)

    _emit(on_event, FirstClipDateStage.FCPXML_PARSING_STARTED, f"Parse FCPXML {xml_path.name}")
    project = read_fcpxml(xml_path)
    _emit(
        on_event,
        FirstClipDateStage.FCPXML_PARSED,
        f"FCPXML geparst: Schema {project.schema_version}, "
        f"{len(project.spine_clips)} Top-Level-Spine-Clips",
    )

    first_clip, asset = _find_first_real_clip(project)
    if first_clip is None or asset is None or asset.src_relative is None:
        return ReadFirstClipDateResult(
            success=False,
            project_format=project_format,
            error_message="Schnittprojekt enthält keinen primären Video-Clip mit Quelldatei",
            warnings=warnings,
        )
    _emit(
        on_event,
        FirstClipDateStage.FIRST_CLIP_RESOLVED,
        f"Erster Clip: {first_clip.name} → Asset {asset.asset_id} ({asset.src_relative})",
    )

    _emit(
        on_event,
        FirstClipDateStage.SOURCE_FILE_RESOLUTION_STARTED,
        f"Suche Quelldatei {asset.src_relative}",
    )
    resolved = resolve_source_file(asset.src_relative, xml_path, runtime, on_output=on_output)
    if resolved is None:
        _emit(
            on_event,
            FirstClipDateStage.SOURCE_FILE_NOT_FOUND,
            f"Quelldatei {Path(asset.src_relative).name} nicht gefunden",
        )
        warnings.append(f"Quelldatei {Path(asset.src_relative).name} nicht gefunden")
        return _project_fallback(project_path, project_format, warnings, on_event)

    _emit(
        on_event,
        FirstClipDateStage.SOURCE_FILE_RESOLVED,
        f"Quelldatei: {resolved.origin_describe}",
    )

    try:
        _emit(
            on_event,
            FirstClipDateStage.EXIFTOOL_INVOKED,
            f"exiftool liest {resolved.local_path.name}",
        )
        dates = exiftool_read_dates(resolved.local_path, runtime, on_output=on_output)
        _emit(on_event, FirstClipDateStage.METADATA_EXTRACTED, "exiftool-Output verarbeitet")
    finally:
        resolved.cleanup()

    iso_datetime, source_label, confidence = pick_recorded_at(dates)

    if iso_datetime is None:
        warnings.append("Keine Datums-Quelle in Quelldatei gefunden")
        return _project_fallback(
            project_path,
            project_format,
            warnings,
            on_event,
            resolved_source_file=resolved.local_path,
        )

    iso_datetime_norm, iso_date = _normalize_to_assumption_tz(iso_datetime, timezone_assumption)
    return ReadFirstClipDateResult(
        success=True,
        iso_date=iso_date,
        iso_datetime=iso_datetime_norm,
        source_label=source_label,
        confidence=confidence,
        project_format=project_format,
        resolved_source_file=resolved.local_path if not resolved.is_temporary else None,
        warnings=warnings,
    )


# ---------------------------------------------------------------------------
# iMovieMobile-Pfad (neu in 0.3.0)
# ---------------------------------------------------------------------------


def _read_first_clip_date_imovie(
    project_path: Path,
    project_format: ProjectFormat,
    timezone_assumption: str | None,
    on_event: Callable[[SchnittprojektLeserEvent], None] | None,
) -> ReadFirstClipDateResult:
    """iMovie-spezifischer Pfad: editList[0].creationDate direkt aus dem Plist."""
    warnings: list[str] = []
    _emit(
        on_event,
        FirstClipDateStage.FCPXML_PARSING_STARTED,
        f"Parse iMovieMobile-Bundle {project_path.name}",
    )
    project = read_imovie_mobile(project_path)
    _emit(
        on_event,
        FirstClipDateStage.FCPXML_PARSED,
        f"iMovieMobile geparst: {len(project.edit_list)} editList-Einträge",
    )

    first_video = project.first_video_clip()
    if first_video is None:
        return ReadFirstClipDateResult(
            success=False,
            project_format=project_format,
            error_message=(
                "iMovieMobile-Projekt enthält keinen Video-Clip "
                "(clipType=1) in der editList"
            ),
            warnings=warnings,
        )
    _emit(
        on_event,
        FirstClipDateStage.FIRST_CLIP_RESOLVED,
        f"Erster Video-Clip: {first_video.relative_path or '(ohne Pfad)'}",
    )

    iso_datetime = first_video.creation_date_iso or first_video.movie_creation_date_iso
    if iso_datetime is None:
        # Plist-Schema-Anomalie: Video-Clip ohne creationDate. Nicht
        # erwartet; melden statt raten.
        return ReadFirstClipDateResult(
            success=False,
            project_format=project_format,
            error_message=(
                "Erster Video-Clip in editList hat kein creationDate-Feld"
            ),
            warnings=warnings,
        )

    if (
        first_video.movie_creation_date_iso
        and first_video.creation_date_iso
        and first_video.movie_creation_date_iso != first_video.creation_date_iso
    ):
        warnings.append(
            "movie.creationDate weicht von clip.creationDate ab "
            f"({first_video.movie_creation_date_iso} vs. {first_video.creation_date_iso})"
        )

    iso_datetime_norm, iso_date = _normalize_to_assumption_tz(iso_datetime, timezone_assumption)
    return ReadFirstClipDateResult(
        success=True,
        iso_date=iso_date,
        iso_datetime=iso_datetime_norm,
        source_label=SOURCE_IMOVIE_EDITLIST_CREATION_DATE,
        confidence=ClipDateConfidence.HIGH,
        project_format=project_format,
        resolved_source_file=None,
        warnings=warnings,
    )


# ---------------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------------


def _emit(
    on_event: Callable[[SchnittprojektLeserEvent], None] | None,
    stage: FirstClipDateStage,
    message: str,
) -> None:
    if on_event is None:
        return
    on_event(SchnittprojektLeserEvent(stage_id=stage.value, message=message))


def _find_first_real_clip(project: FcpxmlProject):
    """Erster Top-Level-Spine-Clip mit echter Quelldatei."""
    for clip in project.spine_clips:
        asset = project.assets_by_id.get(clip.asset_ref)
        if asset is None or not asset.is_real_source:
            continue
        return clip, asset
    return None, None


def _project_fallback(
    project_path: Path,
    project_format: ProjectFormat,
    warnings: list[str],
    on_event: Callable[[SchnittprojektLeserEvent], None] | None,
    resolved_source_file: Path | None = None,
) -> ReadFirstClipDateResult:
    """Notnagel: Projektdatei-mtime als Datum, LOW-Konfidenz."""
    try:
        mtime_epoch = project_path.stat().st_mtime
    except OSError:
        return ReadFirstClipDateResult(
            success=False,
            project_format=project_format,
            error_message=f"Projektdatei nicht stat-bar: {project_path}",
            warnings=warnings,
        )
    dt = datetime.fromtimestamp(mtime_epoch).astimezone()
    iso_dt = dt.isoformat(timespec="seconds")
    _emit(
        on_event,
        FirstClipDateStage.FALLBACK_APPLIED,
        f"Projektdatei-mtime als Notnagel verwendet: {iso_dt}",
    )
    return ReadFirstClipDateResult(
        success=True,
        iso_date=iso_dt[:10],
        iso_datetime=iso_dt,
        source_label=SOURCE_PROJECT_FALLBACK,
        confidence=ClipDateConfidence.LOW,
        project_format=project_format,
        resolved_source_file=resolved_source_file,
        warnings=warnings,
    )


def _normalize_to_assumption_tz(
    iso_datetime: str, timezone_assumption: str | None
) -> tuple[str, str]:
    """Normalisiert einen ISO-Zeitstempel auf die angenommene Zeitzone.

    Liefert ``(iso_datetime_in_tz, iso_date_in_tz)``. Beide Felder werden
    konsistent in derselben Zeitzone ausgegeben:

    - Aware-Stempel + Assumption: konvertieren in Assumption-TZ.
    - Aware-Stempel ohne Assumption: in der Eigen-TZ des Stempels lassen.
    - Naive Stempel + Assumption: als Lokalzeit der Assumption interpretieren.
    - Naive Stempel ohne Assumption: als UTC interpretieren.

    `iso_datetime_in_tz` ist also der **Wallclock-Zeitstempel mit Offset**,
    `iso_date_in_tz` der zugehörige Wallclock-Tag in derselben TZ.

    Hintergrund: iMovie-Plists speichern Stempel als reines UTC (`Z`), was
    Konsumenten verwirrt, wenn sie ihn neben Finder-Anzeigen sehen
    (Finder zeigt die Lokal-TZ-Variante). Wenn der Konsument explizit
    eine `timezone_assumption` setzt, wird er sie konsistent angewendet
    sehen wollen – nicht nur auf das Datum.
    """
    dt = parse_iso_date(iso_datetime)
    if dt is None:
        return iso_datetime, iso_datetime[:10]

    target_tz: ZoneInfo | None = None
    if timezone_assumption:
        try:
            target_tz = ZoneInfo(timezone_assumption)
        except Exception:
            target_tz = None

    is_aware = has_timezone(iso_datetime)
    if is_aware:
        if target_tz is not None:
            dt = dt.astimezone(target_tz)
    else:
        if target_tz is not None:
            dt = dt.replace(tzinfo=target_tz)
        else:
            dt = dt.replace(tzinfo=ZoneInfo("UTC"))

    return dt.isoformat(timespec="seconds"), dt.date().isoformat()


__all__ = ["read_first_clip_date", "DateSources"]
