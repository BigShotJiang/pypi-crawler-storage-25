"""Format-Detection für Schnittprojekt-Pfade."""

from __future__ import annotations

import zipfile
from pathlib import Path

from schnittprojekt_leser.models.errors import FormatDetectionError
from schnittprojekt_leser.models.formats import ProjectFormat


def detect_format(project_path: Path) -> ProjectFormat:
    """Erkennt das Schnittprojekt-Format.

    Erkennung basiert auf Dateiendung und ggf. Inhaltsstruktur:

    - `*.fcpxml` als Datei mit XML-Root `<fcpxml>` → ``FCPXML_FILE``.
    - `*.fcpxmld/` als Verzeichnis mit `info.fcpxml` darin → ``FCPXML_BUNDLE``.
    - `*.iMovieMobile` als ZIP-Archiv mit `iMovieMobileProject.plist`
      darin → ``IMOVIE_MOBILE_ZIP``.

    Raises:
        FormatDetectionError: Pfad existiert nicht oder ist kein erkanntes Format.
    """
    if not project_path.exists():
        raise FormatDetectionError(f"Pfad existiert nicht: {project_path}")

    suffix = project_path.suffix.lower()

    if project_path.is_dir():
        if suffix == ".fcpxmld":
            info = project_path / "info.fcpxml"
            if info.is_file():
                return ProjectFormat.FCPXML_BUNDLE
            raise FormatDetectionError(
                f"Bundle hat keine info.fcpxml: {project_path}"
            )
        raise FormatDetectionError(
            f"Verzeichnis ist kein erkanntes Schnittprojekt-Bundle: {project_path}"
        )

    if suffix == ".fcpxml":
        if _is_fcpxml_root(project_path):
            return ProjectFormat.FCPXML_FILE
        raise FormatDetectionError(
            f"Datei hat .fcpxml-Endung, aber Wurzelelement ist nicht <fcpxml>: {project_path}"
        )

    # iMovieMobile: case-insensitiv, weil Endung historisch CamelCase ist.
    if project_path.name.lower().endswith(".imoviemobile"):
        if _is_imovie_mobile_bundle(project_path):
            return ProjectFormat.IMOVIE_MOBILE_ZIP
        raise FormatDetectionError(
            f"Datei hat .iMovieMobile-Endung, aber kein gültiges ZIP "
            f"mit iMovieMobileProject.plist: {project_path}"
        )

    raise FormatDetectionError(
        f"Format nicht erkannt: {project_path} "
        "(unterstützt: .fcpxml, .fcpxmld/, .iMovieMobile)"
    )


def resolve_inner_xml_path(project_path: Path, project_format: ProjectFormat) -> Path:
    """Liefert den tatsächlichen XML-Pfad zum Parsen.

    Bei `FCPXML_BUNDLE`: `<bundle>/info.fcpxml`. Bei `FCPXML_FILE`: der
    übergebene Pfad selbst. Für `IMOVIE_MOBILE_ZIP` nicht definiert –
    iMovieMobile wird über den ZIP-Pfad direkt gelesen.
    """
    if project_format is ProjectFormat.FCPXML_BUNDLE:
        return project_path / "info.fcpxml"
    return project_path


def _is_fcpxml_root(path: Path) -> bool:
    """Prüft, ob die ersten Bytes auf ein `<fcpxml>`-Wurzelelement hindeuten."""
    try:
        with path.open("rb") as f:
            head = f.read(2048)
    except OSError:
        return False
    text = head.decode("utf-8", errors="replace")
    return "<fcpxml" in text


def _is_imovie_mobile_bundle(path: Path) -> bool:
    """ZIP-Archiv mit `iMovieMobileProject.plist`-Member?"""
    try:
        with zipfile.ZipFile(path, "r") as archive:
            return "iMovieMobileProject.plist" in archive.namelist()
    except (zipfile.BadZipFile, OSError):
        return False
