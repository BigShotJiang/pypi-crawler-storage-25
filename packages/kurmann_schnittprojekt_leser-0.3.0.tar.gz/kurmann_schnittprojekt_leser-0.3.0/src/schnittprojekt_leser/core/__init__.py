"""Fachliche Logik – Format-Detection, Hierarchie-Auswahl, Operations-Komposition.

Konsumiert ausschliesslich `models/` und ruft `services/` über Funktions-
Argumente auf. Importiert `services/`-Module nicht direkt.
"""
