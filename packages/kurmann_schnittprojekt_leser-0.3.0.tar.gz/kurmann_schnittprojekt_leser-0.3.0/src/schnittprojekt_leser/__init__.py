"""kurmann-schnittprojekt-leser – Read-only-Bibliothek für Videoschnitt-Projekte."""

__version__ = "0.3.0"
