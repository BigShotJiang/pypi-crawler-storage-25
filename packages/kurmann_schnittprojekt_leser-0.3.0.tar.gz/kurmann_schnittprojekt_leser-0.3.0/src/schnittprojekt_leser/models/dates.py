"""Datums-Quellen-Datenmodell.

Spiegelt das Vorbild aus `kamera-einleser/services/manifest_schema.py:85`
(DateSources) und `services/date_extractor.py` (Hierarchie) – siehe Skill-
Hinweis in der README. Provenance via Source-Label-Strings, identische
Format-Konventionen.
"""

from __future__ import annotations

from dataclasses import dataclass

# Source-Label-Konstanten — werden im Result als `source_label` zurückgegeben.
# Bewusst lesbare Strings (statt Enum), damit das Provenance-Format
# zukunftsoffen ist (z. B. `+tz_from_mtime`-Suffix).
SOURCE_FILE_MTIME = "file_mtime"
SOURCE_FILE_BIRTHTIME = "file_birthtime"
SOURCE_PROJECT_FALLBACK = "project_fallback"
SOURCE_IMOVIE_EDITLIST_CREATION_DATE = "imovie:editList:creationDate"
"""Aufnahmedatum direkt aus iMovie-Mobile-Plist (`editInfo.editList[i].creationDate`).
Höchste Konfidenz, weil die App den Wert beim Aufnehmen selbst gesetzt hat –
kein Quelldatei-Lesepass nötig."""


@dataclass
class DateSources:
    """Alle gefundenen Datums-Quellen für eine Quelldatei. Provenance-Tracking.

    Felder bleiben optional, weil je nach Datei-Typ (iPhone-MOV, BMD-MOV,
    ProRes, Foto, generic) unterschiedliche Quellen verfügbar sind.
    `core.recorded_at.pick_recorded_at` wählt nach Hierarchie aus.

    Hierarchie (sortiert nach Verlässlichkeit, mirroring kamera-einleser):

    1. `keys_creation_date` — Apple Item-List-Atom, mit TZ.
    2. `exif_creation_date` — QuickTime UDTA `CreationDate`, oft mit TZ.
    3. `blackmagic_date_recorded` — vom BMD-Cam-App geschriebenes Feld.
    4. `exif_datetime_original` — klassisches EXIF-Tag, oft ohne TZ.
    5. `exif_create_date` — QuickTime MVHD `CreateDate`, typisch UTC ohne TZ-Marker.
       Sonderfall Final Cut Camera: TZ wird via mtime inferiert.
    6. `file_birthtime` — Filesystem-Erstellzeit (macOS APFS/HFS+).
    7. `file_mtime` — Filesystem-mtime, Notnagel.
    """

    keys_creation_date: str | None = None
    exif_creation_date: str | None = None
    exif_datetime_original: str | None = None
    exif_create_date: str | None = None
    blackmagic_date_recorded: str | None = None
    file_birthtime: str | None = None
    file_mtime: str | None = None

    def to_dict(self) -> dict[str, str]:
        """Nicht-leere Felder als Dict, für JSON-Output."""
        return {k: v for k, v in self.__dict__.items() if v}
