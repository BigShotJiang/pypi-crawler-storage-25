"""Internes Modell des iMovieMobile-Readers.

`services/imovie_mobile_reader.py` öffnet das ZIP-Bundle, parst
`iMovieMobileProject.plist` und liefert eine Instanz von
`IMovieMobileProject`. `core/`-Module konsumieren ausschliesslich
dieses Modell.

iMovieMobile-Zeitwerte (`duration`, `startOffset`, `startTime`,
`maxDuration`) sind ganzzahlige Frames bei **60 fps**. Der Reader
rechnet zentral in Sekunden um, sodass Konsumenten ohne diese
Konvention auskommen.

Bekannte `clipType`-Werte (Sample-Befund):

- ``1`` – Video (MOV mit Audio)
- ``3`` – Transition (z. B. ``crossDissolve``)
- ``5`` – Foto (typisch mit ``kenBurnsInfo``)
- ``6`` – Hintergrund/Audio (selten)

Für „Erster Clip in der Timeline" zählt nur ``clipType == 1``.
"""

from __future__ import annotations

from dataclasses import dataclass

CLIP_TYPE_VIDEO = 1
CLIP_TYPE_TRANSITION = 3
CLIP_TYPE_PHOTO = 5

IMOVIE_FRAMES_PER_SECOND = 60
"""iMovieMobile-Plist-Zeitbasis (`duration`, `startOffset` in Frames bei 60 fps)."""


@dataclass(frozen=True)
class IMovieMapLocation:
    """GPS- und Ortsangabe pro Clip (aus `movie.mapLocation`)."""

    country_name: str | None
    region_name: str | None
    latitude: float | None
    longitude: float | None


@dataclass(frozen=True)
class IMovieClip:
    """Ein Eintrag aus `editInfo.editList[]` oder `editInfo.cutaways[]`."""

    clip_type: int
    """`1` Video, `3` Transition, `5` Foto, `6` sonstig (siehe Konstanten oben)."""
    duration_seconds: float
    """Dauer in Sekunden (Frames / 60)."""
    duration_frames: int
    """Roher Wert aus `duration` (60 Frames/Sekunde)."""
    start_offset_seconds: float
    creation_date_iso: str | None
    """`creationDate` auf Top-Ebene des Clips. Bei Video- und Foto-Clips gesetzt."""
    movie_creation_date_iso: str | None
    """`movie.creationDate` als sekundäre Quelle."""
    relative_path: str | None
    """`movie.relativePath` – Original-Speicherort auf dem iPhone."""
    title_text: str | None
    """`titleDefinition.text` falls Overlay-Titel definiert."""
    title_subtitle: str | None
    """`titleDefinition.text2`, oft mit dem Aufnahmedatum als formatierter Text."""
    map_location: IMovieMapLocation | None
    rotation_degrees: float | None
    """`rotation` (z. B. 270 für Hochkant-Aufnahme)."""
    transition_name: str | None
    """`transitionName` für `clip_type == 3` (z. B. `"crossDissolve"`)."""

    @property
    def is_video(self) -> bool:
        return self.clip_type == CLIP_TYPE_VIDEO

    @property
    def is_transition(self) -> bool:
        return self.clip_type == CLIP_TYPE_TRANSITION

    @property
    def is_photo(self) -> bool:
        return self.clip_type == CLIP_TYPE_PHOTO


@dataclass(frozen=True)
class IMovieMobileProject:
    """Neutrales internes Modell eines iMovieMobile-Projekts."""

    project_name: str
    """Aus dem Bundle-Dateinamen abgeleitet (Endung `.iMovieMobile` entfernt)."""
    uuid: str | None
    """`UUID`-Feld aus dem Plist."""
    contains_1080: bool
    contains_2160: bool
    contains_hdr: bool
    contains_hevc: bool
    contains_prores: bool
    movie_version: str | None
    """`MovieVersion` aus dem ersten Movie-Eintrag (z. B. `"1.0"`)."""
    edit_list: list[IMovieClip]
    """Geordnete Hauptspur-Liste (entspricht der primären Storyline)."""
    cutaways: list[IMovieClip]
    """Sekundäre Spur (vergleichbar mit FCPXML-`lane > 0`)."""
    timeline_duration_seconds: float
    """Summe der Top-Level-`editList`-Clip-Dauern (Transitions sind als
    Cross-Fades enthalten und überlappen, werden aber hier mitgezählt)."""

    def first_video_clip(self) -> IMovieClip | None:
        """Erster Eintrag in `edit_list` mit `clip_type == 1` (Video)."""
        for clip in self.edit_list:
            if clip.is_video:
                return clip
        return None
