"""RuntimeOptions und Quell-Spezifikationen.

`RuntimeOptions` enthält technische Parameter (Werkzeug-Pfade, Timeouts,
Suchpfade). Strikt getrennt von fachlichen Requests – siehe Skill
`kurmann-python-api`.

`RcloneSource` und `parse_source_spec` spiegeln das Vorbild aus
`kamera-einleser/models.py:31`, damit Konsumenten dasselbe Konfigurations-
Format wie für den `kamera-einleser` benutzen können.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class RcloneSource:
    """Quelle auf einem rclone-Remote (z. B. NAS via SMB/SFTP).

    Beispiel: `RcloneSource(remote="lyssach-nas", path="/Videoschnitt/Luma Fusion-Export")`
    entspricht dem rclone-Pfad `lyssach-nas:/Videoschnitt/Luma Fusion-Export`.
    """

    remote: str
    path: str

    def describe(self) -> str:
        return f"{self.remote}:{self.path}"

    @property
    def rclone_path(self) -> str:
        return f"{self.remote}:{self.path}"


def parse_source_spec(spec: str) -> Path | RcloneSource:
    """Parst einen Config-String in `Path` (lokal) oder `RcloneSource` (remote).

    Regeln:

    - Beginnt mit `/`, `~`, `./`, `../` oder einem Windows-Drive-Letter (`C:/...`)
      → `Path` (lokal).
    - Enthält `:` (und ist kein Windows-Drive-Letter) → `RcloneSource`,
      Form `remote:/path` oder `remote:path`.
    - Sonst: behandelt als lokaler relativer Pfad.

    Beispiele:

    - `/Volumes/Card` → `Path("/Volumes/Card")`
    - `lyssach-nas:/Videoschnitt/Luma Fusion-Export`
      → `RcloneSource("lyssach-nas", "/Videoschnitt/Luma Fusion-Export")`
    - `mega:Backup` → `RcloneSource("mega", "Backup")`
    """
    spec = spec.strip()
    if not spec:
        raise ValueError("Leere Quell-Spezifikation")

    # Windows-Drive-Letter (C:/..., D:\\...) als lokal erkennen
    if (
        len(spec) >= 2
        and spec[1] == ":"
        and spec[0].isalpha()
        and (len(spec) == 2 or spec[2] in ("/", "\\"))
    ):
        return Path(spec).expanduser()

    if spec.startswith(("/", "~", "./", "../")):
        return Path(spec).expanduser()

    if ":" in spec:
        remote, _, remote_path = spec.partition(":")
        if not remote:
            raise ValueError(f"Ungültige rclone-Quelle: {spec!r}")
        return RcloneSource(remote=remote, path=remote_path)

    # Fallback: behandle als lokalen relativen Pfad
    return Path(spec).expanduser()


@dataclass
class RuntimeOptions:
    """Technische Parameter für API-Aufrufe.

    Gemäss `kurmann-python-api`-Skill: Werkzeug-Defaults sind nackte Namen
    (PATH-Auflösung), keine absoluten Pfade.
    """

    exiftool_path: str = "exiftool"
    """Pfad zum exiftool-Binary. Default `"exiftool"` → PATH-Auflösung."""

    exiftool_timeout_seconds: float = 30.0
    """Timeout pro exiftool-Aufruf, in Sekunden."""

    rclone_path: str = "rclone"
    """Pfad zum rclone-Binary. Nur relevant, wenn `source_search_roots` rclone-Quellen enthält."""

    rclone_timeout_seconds: float = 60.0
    """Timeout pro rclone-Aufruf, in Sekunden."""

    source_search_roots: list[Path | RcloneSource] = field(default_factory=list)
    """Zusätzliche Verzeichnisse, in denen Quelldateien rekursiv gesucht werden,
    wenn der Asset-`src` aus dem FCPXML nicht direkt neben der Projektdatei liegt.
    Werden in der Reihenfolge der Liste durchsucht; erster Treffer per Dateiname gewinnt."""

    source_search_max_depth: int = 2
    """Maximale Rekursionstiefe für `source_search_roots`. 0 = nur das Wurzelverzeichnis,
    1 = eine Unterverzeichnis-Ebene, etc. Default 2 deckt typische flache Layouts ab."""

    temp_dir: Path | None = None
    """Optional: Temp-Verzeichnis für rclone-Downloads. Default → System-Temp."""
