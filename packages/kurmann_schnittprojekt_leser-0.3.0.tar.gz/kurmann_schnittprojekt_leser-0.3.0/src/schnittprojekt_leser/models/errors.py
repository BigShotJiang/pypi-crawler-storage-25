"""Exception-Hierarchie der Bibliothek.

Werden in den Services geworfen und in der API-Fassade gefangen,
um sie auf `error_message` im Result abzubilden – Konsumenten sehen
keine Stack-Traces, sondern einen handlungsanweisenden Text.
"""

from __future__ import annotations


class SchnittprojektLeserError(RuntimeError):
    """Basisklasse aller Fehler dieser Bibliothek."""


class FormatDetectionError(SchnittprojektLeserError):
    """Pfad zeigt nicht auf ein erkanntes Schnittprojekt-Format."""


class FcpxmlParseError(SchnittprojektLeserError):
    """FCPXML-Datei konnte nicht geparst oder erwartete Struktur fehlt."""


class IMovieParseError(SchnittprojektLeserError):
    """iMovieMobile-Bundle konnte nicht geöffnet/geparst werden oder Plist-Struktur fehlt."""


class ExiftoolUnavailableError(SchnittprojektLeserError):
    """exiftool ist nicht im PATH installiert."""


class ExiftoolError(SchnittprojektLeserError):
    """exiftool-Aufruf scheiterte (Timeout, ungültige Datei, parse-Fehler)."""


class RcloneUnavailableError(SchnittprojektLeserError):
    """rclone ist nicht im PATH installiert (nur relevant bei RcloneSource-Nutzung)."""


class RcloneError(SchnittprojektLeserError):
    """rclone-Aufruf scheiterte (Timeout, Authentifizierung, unbekannter Remote)."""
