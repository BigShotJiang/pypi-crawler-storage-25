"""Geteilte Domänen-Datentypen.

Reine Dataclasses und Enums, ohne I/O-Logik. Werden von allen Schichten
(`api`, `cli`, `core`, `services`) genutzt.
"""

from schnittprojekt_leser.models.dates import (
    SOURCE_FILE_BIRTHTIME,
    SOURCE_FILE_MTIME,
    SOURCE_IMOVIE_EDITLIST_CREATION_DATE,
    SOURCE_PROJECT_FALLBACK,
    DateSources,
)
from schnittprojekt_leser.models.errors import (
    ExiftoolError,
    ExiftoolUnavailableError,
    FcpxmlParseError,
    FormatDetectionError,
    IMovieParseError,
    RcloneError,
    RcloneUnavailableError,
    SchnittprojektLeserError,
)
from schnittprojekt_leser.models.events import (
    FirstClipDateStage,
    ProjectSummaryStage,
    SchnittprojektLeserEvent,
)
from schnittprojekt_leser.models.fcpxml import (
    FcpxmlAsset,
    FcpxmlProject,
    FcpxmlSpineClip,
    SequenceFormat,
)
from schnittprojekt_leser.models.formats import ClipDateConfidence, ProjectFormat
from schnittprojekt_leser.models.imovie import (
    CLIP_TYPE_PHOTO,
    CLIP_TYPE_TRANSITION,
    CLIP_TYPE_VIDEO,
    IMovieClip,
    IMovieMapLocation,
    IMovieMobileProject,
)
from schnittprojekt_leser.models.requests import (
    ReadFirstClipDateRequest,
    ReadFirstClipDateResult,
    ReadProjectSummaryRequest,
    ReadProjectSummaryResult,
)
from schnittprojekt_leser.models.runtime import RcloneSource, RuntimeOptions, parse_source_spec

__all__ = [
    "CLIP_TYPE_PHOTO",
    "CLIP_TYPE_TRANSITION",
    "CLIP_TYPE_VIDEO",
    "ClipDateConfidence",
    "DateSources",
    "ExiftoolError",
    "ExiftoolUnavailableError",
    "FcpxmlAsset",
    "FcpxmlParseError",
    "FcpxmlProject",
    "FcpxmlSpineClip",
    "FirstClipDateStage",
    "FormatDetectionError",
    "IMovieClip",
    "IMovieMapLocation",
    "IMovieMobileProject",
    "IMovieParseError",
    "ProjectFormat",
    "ProjectSummaryStage",
    "RcloneError",
    "RcloneSource",
    "RcloneUnavailableError",
    "ReadFirstClipDateRequest",
    "ReadFirstClipDateResult",
    "ReadProjectSummaryRequest",
    "ReadProjectSummaryResult",
    "RuntimeOptions",
    "SOURCE_FILE_BIRTHTIME",
    "SOURCE_FILE_MTIME",
    "SOURCE_IMOVIE_EDITLIST_CREATION_DATE",
    "SOURCE_PROJECT_FALLBACK",
    "SchnittprojektLeserError",
    "SchnittprojektLeserEvent",
    "SequenceFormat",
    "parse_source_spec",
]
