"""Request/Result-Datentypen der Public-API.

Pro Operation ein eigenes Request/Result-Paar – keine generische
`inspect`-Funktion mit Discriminator-Field.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from schnittprojekt_leser.models.formats import ClipDateConfidence, ProjectFormat


@dataclass
class ReadFirstClipDateRequest:
    """Anfrage: Aufnahmedatum des ersten Clips eines Schnittprojekts."""

    project_path: Path
    timezone_assumption: str | None = None
    """Optional: IANA-Zeitzonen-Name (z. B. `"Europe/Zurich"`).

    Steuert die Interpretation naiver Zeitstempel und die Wallclock-TZ
    für `iso_date`. Default `None` → naive Stempel werden als UTC
    interpretiert; `iso_date` entspricht dem Datum in der Eigen-TZ
    des Stempels.
    """


@dataclass
class ReadFirstClipDateResult:
    """Ergebnis: Aufnahmedatum des ersten Clips."""

    success: bool
    iso_date: str | None = None
    """Wallclock-Datum des ersten Clips (z. B. `"2026-04-23"`)."""
    iso_datetime: str | None = None
    """Vollzeitstempel mit Offset (z. B. `"2026-04-23T17:52:21+02:00"`),
    falls der gefundene Wert eine Uhrzeit enthält. Sonst `None`."""
    source_label: str | None = None
    """Provenance der Datums-Quelle, z. B. `"exif:Keys:CreationDate"`,
    `"exif:CreateDate+tz_from_mtime"`, `"file_mtime"`, `"project_fallback"`."""
    confidence: ClipDateConfidence = ClipDateConfidence.UNKNOWN
    """Aus der Position des Source-Labels in der Hierarchie abgeleitet."""
    project_format: ProjectFormat | None = None
    resolved_source_file: Path | None = None
    """Welche Quelldatei wurde tatsächlich gelesen. `None` wenn kein
    Quelldatei-Zugriff stattfand (Projektdatei-Fallback)."""
    error_message: str | None = None
    warnings: list[str] = field(default_factory=list)


@dataclass
class ReadProjectSummaryRequest:
    """Anfrage: Projekt-Übersicht (rein FCPXML-intern, kein Quelldatei-Zugriff)."""

    project_path: Path


@dataclass
class ReadProjectSummaryResult:
    """Ergebnis: Projekt-Übersicht."""

    success: bool
    project_name: str | None = None
    project_format: ProjectFormat | None = None
    schema_version: str | None = None
    timeline_duration_seconds: float | None = None
    clip_count_primary: int | None = None
    """Anzahl Top-Level-Spine-Clips."""
    clip_count_total: int | None = None
    """Inklusive Lane-Sub-Spine-Clips."""
    video_resolution: tuple[int, int] | None = None
    color_space: str | None = None
    audio_layout: str | None = None
    project_mtime_iso: str | None = None
    error_message: str | None = None
    warnings: list[str] = field(default_factory=list)
