"""Drei-Kanal-Events der Bibliothek.

Stage-IDs sind auf Englisch (stabil für Host-Matching, gemäss ADR-0009),
`message` auf Deutsch (menschenlesbar für CLI/Logs).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


@dataclass(frozen=True)
class SchnittprojektLeserEvent:
    """Strukturierter Zwischenzustand während einer API-Operation.

    Wird über den `on_event`-Callback ausgegeben. Konsumenten dürfen auf
    `stage_id` matchen, um Operationen zu verfolgen.
    """

    stage_id: str
    message: str
    current: int | None = None
    total: int | None = None


class FirstClipDateStage(StrEnum):
    """Stages der `read_first_clip_date`-Operation."""

    FORMAT_DETECTION_STARTED = "format_detection_started"
    FORMAT_DETECTED = "format_detected"
    FCPXML_PARSING_STARTED = "fcpxml_parsing_started"
    FCPXML_PARSED = "fcpxml_parsed"
    FIRST_CLIP_RESOLVED = "first_clip_resolved"
    SOURCE_FILE_RESOLUTION_STARTED = "source_file_resolution_started"
    SOURCE_FILE_RESOLVED = "source_file_resolved"
    SOURCE_FILE_NOT_FOUND = "source_file_not_found"
    EXIFTOOL_INVOKED = "exiftool_invoked"
    METADATA_EXTRACTED = "metadata_extracted"
    FALLBACK_APPLIED = "fallback_applied"


class ProjectSummaryStage(StrEnum):
    """Stages der `read_project_summary`-Operation."""

    FORMAT_DETECTION_STARTED = "format_detection_started"
    FORMAT_DETECTED = "format_detected"
    FCPXML_PARSING_STARTED = "fcpxml_parsing_started"
    FCPXML_PARSED = "fcpxml_parsed"
