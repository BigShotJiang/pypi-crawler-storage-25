"""Internes Modell des FCPXML-Readers.

`services/fcpxml_reader.py` parst FCPXML mit `lxml` und liefert eine
Instanz von `FcpxmlProject`. `core/`-Module konsumieren ausschliesslich
dieses neutrale Modell, nie das `lxml`-Element direkt.

FCPXML-Zeitwerte (z. B. `"106720/1200s"`) werden im Reader zentral zu
`float` Sekunden rationalisiert.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SequenceFormat:
    """Format-Profil der Sequenz/Timeline."""

    width: int
    height: int
    frame_duration_seconds: float
    color_space: str | None = None


@dataclass(frozen=True)
class FcpxmlAsset:
    """Eintrag aus dem Resource-/Asset-Pool des Projekts.

    `is_real_source=True` bedeutet: das Asset hat ein konkretes `src`-Attribut
    (Quelldatei-Verweis). Generator/Title-Refs ohne `src` werden auf
    `is_real_source=False` gesetzt – `core.first_clip_date` filtert darüber.
    """

    asset_id: str
    name: str
    src_relative: str | None
    has_video: bool
    has_audio: bool
    audio_rate: int | None
    is_real_source: bool


@dataclass(frozen=True)
class FcpxmlSpineClip:
    """Ein `<asset-clip>`-Element direkt unter einer Spine.

    Phase 1 betrachtet ausschliesslich `is_top_level_spine=True`-Clips
    (primäre Storyline). Lane-Sub-Spine-Clips werden im Modell aktuell
    nicht erfasst, sondern nur über `FcpxmlProject.nested_spine_clip_count`
    gezählt.
    """

    asset_ref: str
    name: str
    offset_seconds: float
    start_seconds: float
    duration_seconds: float
    audio_role: str | None
    is_top_level_spine: bool


@dataclass(frozen=True)
class FcpxmlProject:
    """Neutrales internes Modell eines FCPXML-Projekts."""

    project_name: str
    schema_version: str
    sequence_format: SequenceFormat
    audio_layout: str | None
    audio_rate: int | None
    spine_clips: list[FcpxmlSpineClip]
    """Geordnete Liste der Top-Level-Spine-Clips."""
    nested_spine_clip_count: int
    """Anzahl Clips in Lane-Sub-Spines (sekundäre Spuren)."""
    assets_by_id: dict[str, FcpxmlAsset]
    timeline_duration_seconds: float
    """Summe der Top-Level-Spine-Clip-Durations."""
