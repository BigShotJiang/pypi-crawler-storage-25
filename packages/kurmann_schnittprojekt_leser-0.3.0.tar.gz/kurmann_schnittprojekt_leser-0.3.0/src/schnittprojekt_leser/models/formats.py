"""Format- und Konfidenz-Enums."""

from __future__ import annotations

from enum import StrEnum


class ProjectFormat(StrEnum):
    """Erkannte Schnittprojekt-Formate."""

    FCPXML_FILE = "fcpxml_file"
    FCPXML_BUNDLE = "fcpxml_bundle"
    IMOVIE_MOBILE_ZIP = "imovie_mobile_zip"


class ClipDateConfidence(StrEnum):
    """Vertrauensgrad des gefundenen Aufnahmedatums.

    Wird aus der Position in der Quellen-Hierarchie abgeleitet
    (siehe `core.recorded_at`):

    - `HIGH`: Aufnahmedatum stammt aus einem dezidierten EXIF-Feld
      mit Zeitzone (`Keys:CreationDate`, `QuickTime:CreationDate`,
      `Blackmagic-design:CameraDateRecorded`, `DateTimeOriginal`).
    - `MEDIUM`: Aufnahmedatum stammt aus `CreateDate` (ggf. mit TZ-Inferenz
      aus mtime) oder `file_birthtime`.
    - `LOW`: nur `file_mtime` oder Projektdatei-mtime als Notnagel.
    """

    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNKNOWN = "unknown"
