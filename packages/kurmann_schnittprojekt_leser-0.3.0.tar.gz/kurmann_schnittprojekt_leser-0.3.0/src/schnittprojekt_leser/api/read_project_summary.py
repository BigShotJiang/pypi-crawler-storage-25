"""Public-API-Fassade für `read_project_summary`."""

from __future__ import annotations

from typing import Callable

from schnittprojekt_leser.core import project_summary as core_project_summary
from schnittprojekt_leser.models.errors import SchnittprojektLeserError
from schnittprojekt_leser.models.events import SchnittprojektLeserEvent
from schnittprojekt_leser.models.requests import (
    ReadProjectSummaryRequest,
    ReadProjectSummaryResult,
)
from schnittprojekt_leser.models.runtime import RuntimeOptions


def read_project_summary(
    request: ReadProjectSummaryRequest,
    runtime: RuntimeOptions | None = None,  # noqa: ARG001 — derzeit nicht genutzt, API-konsistent
    on_event: Callable[[SchnittprojektLeserEvent], None] | None = None,
) -> ReadProjectSummaryResult:
    """Liefert eine Übersicht über ein Schnittprojekt (rein FCPXML-intern).

    Args:
        request: Pflicht. Mindestens `project_path`.
        runtime: derzeit ungenutzt (für API-Symmetrie und Zukunft akzeptiert).
        on_event: optionaler Callback für strukturierte Zwischenzustände.
    """
    try:
        return core_project_summary.read_project_summary(
            project_path=request.project_path,
            on_event=on_event,
        )
    except SchnittprojektLeserError as exc:
        return ReadProjectSummaryResult(
            success=False,
            error_message=str(exc),
        )
