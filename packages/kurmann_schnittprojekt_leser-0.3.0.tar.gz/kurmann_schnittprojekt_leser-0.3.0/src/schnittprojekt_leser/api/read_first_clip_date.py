"""Public-API-Fassade für `read_first_clip_date`.

Fängt sämtliche `SchnittprojektLeserError`-Subklassen und mappt sie auf
`error_message` im Result. Konsumenten sehen nie eine Exception.
"""

from __future__ import annotations

from typing import Callable

from schnittprojekt_leser.core import first_clip_date as core_first_clip_date
from schnittprojekt_leser.models.errors import SchnittprojektLeserError
from schnittprojekt_leser.models.events import SchnittprojektLeserEvent
from schnittprojekt_leser.models.requests import (
    ReadFirstClipDateRequest,
    ReadFirstClipDateResult,
)
from schnittprojekt_leser.models.runtime import RuntimeOptions


def read_first_clip_date(
    request: ReadFirstClipDateRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[SchnittprojektLeserEvent], None] | None = None,
    on_output: Callable[[str], None] | None = None,
) -> ReadFirstClipDateResult:
    """Liest das Aufnahmedatum des ersten Clips eines Schnittprojekts.

    Args:
        request: Pflicht. Mindestens `project_path`.
        runtime: optional. Default `RuntimeOptions()` (PATH-Auflösung für
            exiftool und rclone, Default-Timeouts, leere Search-Roots).
        on_event: optionaler Callback für strukturierte Zwischenzustände.
        on_output: optionaler Callback für rohen exiftool/rclone-Output
            (für `--verbose`-Anzeigen).

    Returns:
        Befülltes `ReadFirstClipDateResult`. `success` zeigt an, ob ein
        Datum ermittelt werden konnte; bei `False` enthält `error_message`
        einen handlungsanweisenden deutschen Text.
    """
    runtime = runtime or RuntimeOptions()
    try:
        return core_first_clip_date.read_first_clip_date(
            project_path=request.project_path,
            runtime=runtime,
            timezone_assumption=request.timezone_assumption,
            on_event=on_event,
            on_output=on_output,
        )
    except SchnittprojektLeserError as exc:
        return ReadFirstClipDateResult(
            success=False,
            error_message=str(exc),
        )
