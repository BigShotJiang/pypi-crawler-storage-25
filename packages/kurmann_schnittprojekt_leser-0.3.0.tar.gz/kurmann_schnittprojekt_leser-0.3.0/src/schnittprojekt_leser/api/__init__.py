"""Public API der Bibliothek.

Externe Konsumenten importieren ausschliesslich aus diesem Paket:

    from schnittprojekt_leser.api import (
        read_first_clip_date,
        read_project_summary,
    )
    from schnittprojekt_leser.models import (
        ReadFirstClipDateRequest,
        ReadProjectSummaryRequest,
        RuntimeOptions,
        RcloneSource,
    )
"""

from schnittprojekt_leser.api.read_first_clip_date import read_first_clip_date
from schnittprojekt_leser.api.read_project_summary import read_project_summary

__all__ = [
    "read_first_clip_date",
    "read_project_summary",
]
