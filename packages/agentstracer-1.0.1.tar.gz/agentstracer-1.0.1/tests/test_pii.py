import json
import subprocess

import pytest

from agentstracer.pii import (
    _collect_text_work_items,
    _content_findings_for_text,
    _extract_json_array,
    _normalize_llm_findings,
    _read_batch_findings,
    _review_text_with_agent,
    _split_into_batches,
    _truncate_for_llm,
    apply_findings_to_session,
    apply_findings_to_text,
    load_findings,
    merge_findings,
    replacement_for_type,
    review_session_pii,
    review_session_pii_hybrid,
    review_session_pii_with_agent,
    review_session_pii_with_claude,
    write_findings,
)


def test_replacement_for_type_defaults():
    assert replacement_for_type("person_name") == "[REDACTED_PERSON]"
    assert replacement_for_type("unknown") == "[REDACTED]"


def test_merge_findings_prefers_longer_text():
    findings = [
        {
            "session_id": "s1",
            "message_index": 0,
            "field": "content",
            "entity_text": "Kai",
            "entity_type": "person_name",
            "confidence": 0.8,
        },
        {
            "session_id": "s1",
            "message_index": 0,
            "field": "content",
            "entity_text": "Kai D",
            "entity_type": "person_name",
            "confidence": 0.95,
        },
    ]
    merged = merge_findings(findings)
    assert len(merged) == 1
    assert merged[0]["entity_text"] == "Kai D"


def test_apply_findings_to_text_replaces_all_occurrences():
    findings = [
        {
            "entity_text": "Kai D",
            "entity_type": "person_name",
            "replacement": "[REDACTED_PERSON]",
            "confidence": 0.9,
        }
    ]
    redacted, count = apply_findings_to_text("Kai D said hi to Kai D.", findings)
    assert count == 2
    assert "Kai D" not in redacted
    assert redacted.count("[REDACTED_PERSON]") == 2


def test_apply_findings_to_session_nested_tool_field():
    session = {
        "session_id": "s1",
        "messages": [
            {
                "content": "hello",
                "tool_uses": [
                    {
                        "input": {"command": "echo Kai D"},
                        "output": {"text": "done"},
                    }
                ],
            }
        ],
    }
    findings = [
        {
            "session_id": "s1",
            "message_index": 0,
            "field": "tool_uses[0].input.command",
            "entity_text": "Kai D",
            "entity_type": "person_name",
            "replacement": "[REDACTED_PERSON]",
            "confidence": 0.99,
        }
    ]
    redacted, count = apply_findings_to_session(session, findings)
    assert count == 1
    assert redacted["messages"][0]["tool_uses"][0]["input"]["command"] == "echo [REDACTED_PERSON]"


def test_review_session_pii_detects_metadata_entities():
    session = {
        "session_id": "s1",
        "messages": [
            {
                "content": '{"sender_id":"7859110712","name":"Kai D","username":"kaidagent"}'
            }
        ],
    }
    findings = review_session_pii(session)
    entity_texts = {f["entity_text"] for f in findings}
    assert "7859110712" in entity_texts
    assert "Kai D" in entity_texts
    assert "kaidagent" in entity_texts


def test_review_session_pii_detects_escaped_quote_metadata():
    """Metadata patterns should match both regular and escaped JSON quotes."""
    session = {
        "session_id": "s1",
        "messages": [
            {
                "content": r'{"text": "{\"name\":\"Kai D\",\"username\":\"kaidagent\"}"}'
            }
        ],
    }
    findings = review_session_pii(session)
    entity_texts = {f["entity_text"] for f in findings}
    assert "Kai D" in entity_texts
    assert "kaidagent" in entity_texts


def test_metadata_id_pattern_only_matches_numeric_ids():
    """The generic 'id' pattern should only match numeric IDs, not UUIDs or hashes."""
    session = {
        "session_id": "s1",
        "messages": [
            {
                "content": '{"id":"abc123-uuid-value","user_id":"9876543210"}'
            }
        ],
    }
    findings = review_session_pii(session)
    entity_texts = {f["entity_text"] for f in findings}
    # UUID-like id should NOT be matched
    assert "abc123-uuid-value" not in entity_texts
    # Numeric user_id SHOULD be matched via the specific user_id pattern
    assert "9876543210" in entity_texts


def test_write_and_load_findings_roundtrip(tmp_path):
    path = tmp_path / "findings.json"
    findings = [
        {
            "session_id": "s1",
            "message_index": 0,
            "field": "content",
            "entity_text": "Kai D",
            "entity_type": "person_name",
            "confidence": 0.9,
        }
    ]
    write_findings(path, findings, meta={"provider": "rules"})
    loaded = load_findings(path)
    assert len(loaded) == 1
    assert loaded[0]["entity_text"] == "Kai D"
    assert json.loads(path.read_text())["provider"] == "rules"


def test_extract_json_array_from_wrapped_text():
    parsed = _extract_json_array('noise before [{"entity_text":"Kai D","entity_type":"person_name","confidence":0.9,"reason":"name"}] noise after')
    assert parsed[0]["entity_text"] == "Kai D"


def test_normalize_llm_findings_filters_unknown_type():
    findings = _normalize_llm_findings("s1", 0, "content", [{
        "entity_text": "secret thing",
        "entity_type": "weird_type",
        "confidence": 0.7,
        "reason": "sensitive",
    }], source="claude")
    assert findings[0]["entity_type"] == "custom_sensitive"
    assert findings[0]["source"] == "claude"


def test_review_session_pii_with_claude(monkeypatch):
    session = {
        "session_id": "s1",
        "messages": [{"content": "Kai D from Acme"}],
    }

    def fake_review(session_id, message_index, field, text, **kwargs):
        assert session_id == "s1"
        assert field == "content"
        assert text == "Kai D from Acme"
        return [{
            "session_id": session_id,
            "message_index": message_index,
            "field": field,
            "entity_text": "Kai D",
            "entity_type": "person_name",
            "confidence": 0.95,
            "reason": "name",
            "replacement": "[REDACTED_PERSON]",
            "source": "claude",
        }]

    monkeypatch.setattr("agentstracer.pii._review_text_with_agent", fake_review)
    findings = review_session_pii_with_claude(session)
    assert findings[0]["entity_text"] == "Kai D"
    assert findings[0]["source"] == "claude"


def test_review_session_pii_with_agent_dispatches_backend(monkeypatch):
    """review_session_pii_with_agent resolves backend and calls the batch runner."""
    session = {
        "session_id": "s1",
        "messages": [{"content": "Hello World"}],
    }
    called_with = []

    def fake_runner(session_id, work_items, *, rubric=None, timeout_seconds=180):
        called_with.append(session_id)
        return []

    monkeypatch.setattr("agentstracer.pii.resolve_backend", lambda b: "codex")
    monkeypatch.setattr("agentstracer.pii.check_backend_runtime", lambda b: None)
    monkeypatch.setattr("agentstracer.pii._PII_BATCH_RUNNERS", {"codex": fake_runner})
    review_session_pii_with_agent(session, backend="codex")
    assert called_with == ["s1"]


def test_review_session_pii_hybrid_merges_rule_and_claude(monkeypatch):
    session = {
        "session_id": "s1",
        "messages": [{"content": '{"name":"Kai D","username":"kaidagent"} and Acme Labs'}],
    }

    monkeypatch.setattr("agentstracer.pii.review_session_pii_with_agent", lambda s, backend="auto", ignore_errors=True, **kw: [{
        "session_id": "s1",
        "message_index": 0,
        "field": "content",
        "entity_text": "Acme Labs",
        "entity_type": "org_name",
        "confidence": 0.88,
        "reason": "org",
        "replacement": "[REDACTED_ORG]",
        "source": "claude",
    }])
    findings = review_session_pii_hybrid(session)
    entity_texts = {f["entity_text"] for f in findings}
    assert "Kai D" in entity_texts
    assert "kaidagent" in entity_texts
    assert "Acme Labs" in entity_texts


def test_content_findings_github_url():
    findings = _content_findings_for_text("s1", 0, "content", "See https://github.com/kaiaiagent/clawtrace for details")
    entity_texts = {f["entity_text"] for f in findings}
    assert "kaiaiagent" in entity_texts
    assert all(f["entity_type"] == "username" for f in findings)


def test_content_findings_github_raw_url():
    findings = _content_findings_for_text("s1", 0, "content", "https://raw.githubusercontent.com/myuser/repo/main/file.txt")
    assert any(f["entity_text"] == "myuser" for f in findings)


def test_content_findings_skips_public_github_orgs():
    findings = _content_findings_for_text("s1", 0, "content", "https://github.com/anthropic/sdk and https://github.com/npm/cli")
    entity_texts = {f["entity_text"] for f in findings}
    assert "anthropic" not in entity_texts
    assert "npm" not in entity_texts


def test_content_findings_telegram_bot_token():
    findings = _content_findings_for_text("s1", 0, "content", "token is 8773626713:AAGaVClH6X8qr59wwbwoLpqVyu3ebOi5irw here")
    assert len(findings) == 1
    assert findings[0]["entity_type"] == "custom_sensitive"
    assert "8773626713:" in findings[0]["entity_text"]


def test_content_findings_private_ips():
    text = "connect to 10.0.0.1 or 192.168.1.100 or 172.16.0.5 but not 8.8.8.8"
    findings = _content_findings_for_text("s1", 0, "content", text)
    entity_texts = {f["entity_text"] for f in findings}
    assert "10.0.0.1" in entity_texts
    assert "192.168.1.100" in entity_texts
    assert "172.16.0.5" in entity_texts
    assert "8.8.8.8" not in entity_texts


def test_content_findings_email():
    findings = _content_findings_for_text("s1", 0, "content", "contact kai@example.com for help")
    assert any(f["entity_text"] == "kai@example.com" for f in findings)


def test_content_findings_skips_noreply_emails():
    findings = _content_findings_for_text("s1", 0, "content", "Co-Authored-By: noreply@anthropic.com")
    entity_texts = {f["entity_text"] for f in findings}
    assert "noreply@anthropic.com" not in entity_texts


def test_content_findings_session_wide_apply():
    """Findings from one field should redact the same entity in other fields."""
    session = {
        "session_id": "s1",
        "messages": [
            {
                "content": "See https://github.com/kaiaiagent/clawtrace",
                "tool_uses": [
                    {"input": {"command": "gh repo view kaiaiagent/clawtrace"}, "output": {"text": "ok"}}
                ],
            }
        ],
    }
    findings = review_session_pii(session)
    redacted, count = apply_findings_to_session(session, findings)
    # The entity was found in content; session-wide apply should also redact it in tool input
    assert "kaiaiagent" not in redacted["messages"][0]["tool_uses"][0]["input"]["command"]
    assert count >= 2


def test_truncate_for_llm_keeps_ends():
    text = "A" * 7000 + "MIDDLE" + "B" * 7000
    out = _truncate_for_llm(text, max_chars=100)
    assert "TRUNCATED FOR PII REVIEW" in out
    assert out.startswith("A")
    assert out.endswith("B" * 50)


# ---------------------------------------------------------------------------
# _collect_text_work_items
# ---------------------------------------------------------------------------


def test_collect_text_work_items_basic():
    session = {
        "session_id": "s1",
        "messages": [
            {"content": "hello", "thinking": "thought"},
            {"content": "world"},
        ],
    }
    items = _collect_text_work_items(session)
    assert len(items) == 3
    assert items[0] == ("s1", 0, "content", "hello")
    assert items[1] == ("s1", 0, "thinking", "thought")
    assert items[2] == ("s1", 1, "content", "world")


def test_collect_text_work_items_tool_uses():
    session = {
        "session_id": "s1",
        "messages": [{
            "content": "cmd",
            "tool_uses": [
                {"input": {"command": "echo hi"}, "output": "done"},
            ],
        }],
    }
    items = _collect_text_work_items(session)
    fields = [item[2] for item in items]
    assert "content" in fields
    assert "tool_uses[0].input.command" in fields
    assert "tool_uses[0].output" in fields


def test_collect_text_work_items_skips_empty():
    session = {"session_id": "s1", "messages": [{"content": "   "}]}
    assert _collect_text_work_items(session) == []


def test_collect_text_work_items_non_list_messages():
    session = {"session_id": "s1", "messages": "not a list"}
    assert _collect_text_work_items(session) == []


# ---------------------------------------------------------------------------
# _read_batch_findings
# ---------------------------------------------------------------------------


def test_read_batch_findings_prefers_file(tmp_path):
    (tmp_path / "findings.json").write_text(
        '[{"message_index": 0, "field": "content", "entity_text": "File", "entity_type": "person_name", "confidence": 0.9, "reason": "from file"}]'
    )
    results = _read_batch_findings(tmp_path, "s1", "claude", stdout="[]")
    assert results[0]["entity_text"] == "File"


def test_read_batch_findings_falls_back_to_stdout(tmp_path):
    stdout = '[{"message_index": 0, "field": "content", "entity_text": "Bob", "entity_type": "person_name", "confidence": 0.9, "reason": "name"}]'
    results = _read_batch_findings(tmp_path, "s1", "claude", stdout=stdout)
    assert len(results) == 1
    assert results[0]["entity_text"] == "Bob"


# ---------------------------------------------------------------------------
# _split_into_batches
# ---------------------------------------------------------------------------


def test_split_into_batches_single():
    items = [("s1", 0, "content", "short text")]
    batches = _split_into_batches(items, char_limit=100_000)
    assert len(batches) == 1
    assert batches[0] == items


def test_split_into_batches_splits_large():
    # Each item is 12K after MAX_LLM_TEXT_CHARS cap; 5 items = 60K
    items = [("s1", i, "content", "x" * 40_000) for i in range(5)]
    batches = _split_into_batches(items, char_limit=30_000)
    assert len(batches) >= 2
    # All items accounted for
    assert sum(len(b) for b in batches) == 5


# ---------------------------------------------------------------------------
# _review_text_with_agent dispatch
# ---------------------------------------------------------------------------


def test_review_text_with_agent_unsupported_backend(monkeypatch):
    monkeypatch.setattr("agentstracer.pii.resolve_backend", lambda b: "gemini")
    monkeypatch.setattr("agentstracer.pii.check_backend_runtime", lambda b: None)
    with pytest.raises(RuntimeError, match="Unsupported PII backend"):
        _review_text_with_agent("s1", 0, "content", "test", backend="gemini")


# ---------------------------------------------------------------------------
# review_session_pii_with_agent error propagation
# ---------------------------------------------------------------------------


def test_review_session_pii_with_agent_raises_on_error(monkeypatch):
    session = {"session_id": "s1", "messages": [{"content": "test"}]}
    monkeypatch.setattr("agentstracer.pii.resolve_backend", lambda b: "claude")
    monkeypatch.setattr("agentstracer.pii.check_backend_runtime", lambda b: None)

    def failing_runner(*a, **kw):
        raise RuntimeError("backend crashed")

    monkeypatch.setattr("agentstracer.pii._PII_BATCH_RUNNERS", {"claude": failing_runner})
    with pytest.raises(RuntimeError, match="backend crashed"):
        review_session_pii_with_agent(session, backend="claude", ignore_errors=False)


def test_review_session_pii_with_agent_ignores_errors(monkeypatch):
    session = {"session_id": "s1", "messages": [{"content": "test"}]}
    monkeypatch.setattr("agentstracer.pii.resolve_backend", lambda b: "claude")
    monkeypatch.setattr("agentstracer.pii.check_backend_runtime", lambda b: None)

    def failing_runner(*a, **kw):
        raise RuntimeError("backend crashed")

    monkeypatch.setattr("agentstracer.pii._PII_BATCH_RUNNERS", {"claude": failing_runner})
    findings = review_session_pii_with_agent(session, backend="claude", ignore_errors=True)
    assert findings == []
