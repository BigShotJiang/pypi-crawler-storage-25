# Plexus Python Common Module

![PyPI - Python Version](https://img.shields.io/pypi/pyversions/plexus-python-common?style=for-the-badge)
![PyPI - Version](https://img.shields.io/pypi/v/plexus-python-common?style=for-the-badge)
![Codecov](https://img.shields.io/codecov/c/github/ruyangshou/plexus-python-common?token=0FGT4M40CD&style=for-the-badge)

## Build and Deploy

### Using Conda

We recommend using Conda. You need to install Anaconda packages from
the [official site](https://www.anaconda.com/products/distribution)

Create a Conda environment and install the modules and their dependencies in it

```shell
conda create -n plexus python=3.14
conda activate plexus

pip install .

conda deactivate
```

To remove the existing Conda environment (and create a brand new one)

```shell
conda env remove -n plexus
```
