from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_connection import ApiConnection
from ...models.connection_type import ConnectionType
from ...models.database_connection import DatabaseConnection
from ...models.databricks_connection import DatabricksConnection
from ...models.file_connection import FileConnection
from ...models.http_validation_error import HTTPValidationError
from ...models.s3_connection import S3Connection
from ...models.webhook_connection import WebhookConnection
from ...types import UNSET, Response


def _get_kwargs(
    *,
    body: ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection | WebhookConnection,
    b: ConnectionType,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_b = b.value
    params["b"] = json_b

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/connections/openapi",
        "params": params,
    }

    if isinstance(body, DatabaseConnection):
        _kwargs["json"] = body.to_dict()
    elif isinstance(body, S3Connection):
        _kwargs["json"] = body.to_dict()
    elif isinstance(body, ApiConnection):
        _kwargs["json"] = body.to_dict()
    elif isinstance(body, WebhookConnection):
        _kwargs["json"] = body.to_dict()
    elif isinstance(body, FileConnection):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection | WebhookConnection,
    b: ConnectionType,
) -> Response[Any | HTTPValidationError]:
    """Get Connections Openapi Schema

     Placeholder for OpenAPI schema generation.

    Args:
        b (ConnectionType):
        body (ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection |
            S3Connection | WebhookConnection): Union type for all connection types - generates named
            schema in OpenAPI.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        b=b,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection | WebhookConnection,
    b: ConnectionType,
) -> Any | HTTPValidationError | None:
    """Get Connections Openapi Schema

     Placeholder for OpenAPI schema generation.

    Args:
        b (ConnectionType):
        body (ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection |
            S3Connection | WebhookConnection): Union type for all connection types - generates named
            schema in OpenAPI.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
        b=b,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection | WebhookConnection,
    b: ConnectionType,
) -> Response[Any | HTTPValidationError]:
    """Get Connections Openapi Schema

     Placeholder for OpenAPI schema generation.

    Args:
        b (ConnectionType):
        body (ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection |
            S3Connection | WebhookConnection): Union type for all connection types - generates named
            schema in OpenAPI.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        b=b,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection | WebhookConnection,
    b: ConnectionType,
) -> Any | HTTPValidationError | None:
    """Get Connections Openapi Schema

     Placeholder for OpenAPI schema generation.

    Args:
        b (ConnectionType):
        body (ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection |
            S3Connection | WebhookConnection): Union type for all connection types - generates named
            schema in OpenAPI.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            b=b,
        )
    ).parsed
