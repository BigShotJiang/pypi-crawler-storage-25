from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_connection_v1_connections_connection_id_delete_response_delete_connection_v1_connections_connection_id_delete import (
    DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    connection_id: str,
    *,
    project_id: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/connections/{connection_id}".format(
            connection_id=quote(str(connection_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete
    | HTTPValidationError
    | None
):
    if response.status_code == 200:
        response_200 = DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete
    | HTTPValidationError
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> Response[
    DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete
    | HTTPValidationError
]:
    """Delete Connection

     Delete a connection. Requires member role or above.

    Args:
        connection_id (str):
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> (
    DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete
    | HTTPValidationError
    | None
):
    """Delete Connection

     Delete a connection. Requires member role or above.

    Args:
        connection_id (str):
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete | HTTPValidationError
    """

    return sync_detailed(
        connection_id=connection_id,
        client=client,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> Response[
    DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete
    | HTTPValidationError
]:
    """Delete Connection

     Delete a connection. Requires member role or above.

    Args:
        connection_id (str):
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> (
    DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete
    | HTTPValidationError
    | None
):
    """Delete Connection

     Delete a connection. Requires member role or above.

    Args:
        connection_id (str):
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteConnectionV1ConnectionsConnectionIdDeleteResponseDeleteConnectionV1ConnectionsConnectionIdDelete | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            connection_id=connection_id,
            client=client,
            project_id=project_id,
        )
    ).parsed
