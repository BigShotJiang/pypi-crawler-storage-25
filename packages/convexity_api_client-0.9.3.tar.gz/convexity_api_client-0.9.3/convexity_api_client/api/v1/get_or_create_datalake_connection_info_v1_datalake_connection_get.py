from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.datalake_connection_response import DatalakeConnectionResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    *,
    project_id: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/datalake-connection",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DatalakeConnectionResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DatalakeConnectionResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DatalakeConnectionResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> Response[DatalakeConnectionResponse | HTTPValidationError]:
    """Get Or Create Datalake Connection Info

     Get datalake connection info for direct DuckDB WASM access.

    Returns connection information that allows frontend DuckDB WASM to attach
    directly to the datalake backend (DuckLake, Delta Lake, or Parquet).

    For DuckLake backends, frontend can use:
    ```sql
    INSTALL ducklake; LOAD ducklake;
    SET s3_access_key_id = '{s3AccessKeyId}';
    SET s3_secret_access_key = '{s3SecretAccessKey}';
    SET s3_endpoint = '{s3Endpoint}';
    SET s3_region = '{s3Region}';
    ATTACH 'ducklake:{catalogConnection}' AS {ducklakeName} (DATA_PATH '{dataPath}');
    SELECT * FROM {ducklakeName}.table_name;
    ```

    Requires viewer role.

    Args:
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatalakeConnectionResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> DatalakeConnectionResponse | HTTPValidationError | None:
    """Get Or Create Datalake Connection Info

     Get datalake connection info for direct DuckDB WASM access.

    Returns connection information that allows frontend DuckDB WASM to attach
    directly to the datalake backend (DuckLake, Delta Lake, or Parquet).

    For DuckLake backends, frontend can use:
    ```sql
    INSTALL ducklake; LOAD ducklake;
    SET s3_access_key_id = '{s3AccessKeyId}';
    SET s3_secret_access_key = '{s3SecretAccessKey}';
    SET s3_endpoint = '{s3Endpoint}';
    SET s3_region = '{s3Region}';
    ATTACH 'ducklake:{catalogConnection}' AS {ducklakeName} (DATA_PATH '{dataPath}');
    SELECT * FROM {ducklakeName}.table_name;
    ```

    Requires viewer role.

    Args:
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatalakeConnectionResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> Response[DatalakeConnectionResponse | HTTPValidationError]:
    """Get Or Create Datalake Connection Info

     Get datalake connection info for direct DuckDB WASM access.

    Returns connection information that allows frontend DuckDB WASM to attach
    directly to the datalake backend (DuckLake, Delta Lake, or Parquet).

    For DuckLake backends, frontend can use:
    ```sql
    INSTALL ducklake; LOAD ducklake;
    SET s3_access_key_id = '{s3AccessKeyId}';
    SET s3_secret_access_key = '{s3SecretAccessKey}';
    SET s3_endpoint = '{s3Endpoint}';
    SET s3_region = '{s3Region}';
    ATTACH 'ducklake:{catalogConnection}' AS {ducklakeName} (DATA_PATH '{dataPath}');
    SELECT * FROM {ducklakeName}.table_name;
    ```

    Requires viewer role.

    Args:
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DatalakeConnectionResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    project_id: str,
) -> DatalakeConnectionResponse | HTTPValidationError | None:
    """Get Or Create Datalake Connection Info

     Get datalake connection info for direct DuckDB WASM access.

    Returns connection information that allows frontend DuckDB WASM to attach
    directly to the datalake backend (DuckLake, Delta Lake, or Parquet).

    For DuckLake backends, frontend can use:
    ```sql
    INSTALL ducklake; LOAD ducklake;
    SET s3_access_key_id = '{s3AccessKeyId}';
    SET s3_secret_access_key = '{s3SecretAccessKey}';
    SET s3_endpoint = '{s3Endpoint}';
    SET s3_region = '{s3Region}';
    ATTACH 'ducklake:{catalogConnection}' AS {ducklakeName} (DATA_PATH '{dataPath}');
    SELECT * FROM {ducklakeName}.table_name;
    ```

    Requires viewer role.

    Args:
        project_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DatalakeConnectionResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            project_id=project_id,
        )
    ).parsed
