from enum import Enum


class ProjectResourceChangedPayloadResourceType(str, Enum):
    CONNECTION = "connection"
    DASHBOARD = "dashboard"
    DATASET = "dataset"
    RUN = "run"
    TASK = "task"

    def __str__(self) -> str:
        return str(self.value)
