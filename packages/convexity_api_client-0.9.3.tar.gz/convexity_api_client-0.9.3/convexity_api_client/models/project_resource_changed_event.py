from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.project_resource_changed_payload import ProjectResourceChangedPayload


T = TypeVar("T", bound="ProjectResourceChangedEvent")


@_attrs_define
class ProjectResourceChangedEvent:
    """Event emitted when a project-scoped resource changes.

    Attributes:
        data (ProjectResourceChangedPayload):
        event_type (Literal['project_resource_changed'] | Unset): Type of event, e.g. 'project_resource_changed'
            Default: 'project_resource_changed'.
    """

    data: ProjectResourceChangedPayload
    event_type: Literal["project_resource_changed"] | Unset = "project_resource_changed"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data = self.data.to_dict()

        event_type = self.event_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "data": data,
            }
        )
        if event_type is not UNSET:
            field_dict["event_type"] = event_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.project_resource_changed_payload import ProjectResourceChangedPayload

        d = dict(src_dict)
        data = ProjectResourceChangedPayload.from_dict(d.pop("data"))

        event_type = cast(Literal["project_resource_changed"] | Unset, d.pop("event_type", UNSET))
        if event_type != "project_resource_changed" and not isinstance(event_type, Unset):
            raise ValueError(f"event_type must match const 'project_resource_changed', got '{event_type}'")

        project_resource_changed_event = cls(
            data=data,
            event_type=event_type,
        )

        project_resource_changed_event.additional_properties = d
        return project_resource_changed_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
