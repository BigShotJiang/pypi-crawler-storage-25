from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="DeleteDatasetPayload")


@_attrs_define
class DeleteDatasetPayload:
    """Payload for deleting a dataset's DuckLake table.

    Drops the DuckLake table associated with the dataset.
    Parquet data files remain on S3 until VACUUM is run.

        Attributes:
            dataset_id (str): ID of the dataset whose DuckLake table to delete
            project_id (str): Project the dataset belongs to
            type_ (Literal['delete_dataset'] | Unset):  Default: 'delete_dataset'.
    """

    dataset_id: str
    project_id: str
    type_: Literal["delete_dataset"] | Unset = "delete_dataset"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        dataset_id = self.dataset_id

        project_id = self.project_id

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "datasetId": dataset_id,
                "projectId": project_id,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        dataset_id = d.pop("datasetId")

        project_id = d.pop("projectId")

        type_ = cast(Literal["delete_dataset"] | Unset, d.pop("type", UNSET))
        if type_ != "delete_dataset" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'delete_dataset', got '{type_}'")

        delete_dataset_payload = cls(
            dataset_id=dataset_id,
            project_id=project_id,
            type_=type_,
        )

        delete_dataset_payload.additional_properties = d
        return delete_dataset_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
