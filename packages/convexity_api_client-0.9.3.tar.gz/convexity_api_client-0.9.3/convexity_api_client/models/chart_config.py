from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.area_chart_config import AreaChartConfig
    from ..models.bar_chart_config import BarChartConfig
    from ..models.kpi_chart_config import KpiChartConfig
    from ..models.line_chart_config import LineChartConfig
    from ..models.pie_chart_config import PieChartConfig
    from ..models.scatter_chart_config import ScatterChartConfig
    from ..models.table_chart_config import TableChartConfig


T = TypeVar("T", bound="ChartConfig")


@_attrs_define
class ChartConfig:
    """Chart configuration with type-specific options.

    Attributes:
        id (str): Unique chart configuration identifier
        type_ (Literal['chartconfig'] | Unset):  Default: 'chartconfig'.
        dataset_id (None | str | Unset): Dataset identifier
        title (None | str | Unset): Chart title
        config (AreaChartConfig | BarChartConfig | KpiChartConfig | LineChartConfig | None | PieChartConfig |
            ScatterChartConfig | TableChartConfig | Unset): Chart type-specific configuration
    """

    id: str
    type_: Literal["chartconfig"] | Unset = "chartconfig"
    dataset_id: None | str | Unset = UNSET
    title: None | str | Unset = UNSET
    config: (
        AreaChartConfig
        | BarChartConfig
        | KpiChartConfig
        | LineChartConfig
        | None
        | PieChartConfig
        | ScatterChartConfig
        | TableChartConfig
        | Unset
    ) = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.area_chart_config import AreaChartConfig
        from ..models.bar_chart_config import BarChartConfig
        from ..models.kpi_chart_config import KpiChartConfig
        from ..models.line_chart_config import LineChartConfig
        from ..models.pie_chart_config import PieChartConfig
        from ..models.scatter_chart_config import ScatterChartConfig
        from ..models.table_chart_config import TableChartConfig

        id = self.id

        type_ = self.type_

        dataset_id: None | str | Unset
        if isinstance(self.dataset_id, Unset):
            dataset_id = UNSET
        else:
            dataset_id = self.dataset_id

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, LineChartConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, BarChartConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, AreaChartConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, ScatterChartConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, PieChartConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, KpiChartConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, TableChartConfig):
            config = self.config.to_dict()
        else:
            config = self.config

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if dataset_id is not UNSET:
            field_dict["datasetId"] = dataset_id
        if title is not UNSET:
            field_dict["title"] = title
        if config is not UNSET:
            field_dict["config"] = config

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.area_chart_config import AreaChartConfig
        from ..models.bar_chart_config import BarChartConfig
        from ..models.kpi_chart_config import KpiChartConfig
        from ..models.line_chart_config import LineChartConfig
        from ..models.pie_chart_config import PieChartConfig
        from ..models.scatter_chart_config import ScatterChartConfig
        from ..models.table_chart_config import TableChartConfig

        d = dict(src_dict)
        id = d.pop("id")

        type_ = cast(Literal["chartconfig"] | Unset, d.pop("type", UNSET))
        if type_ != "chartconfig" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'chartconfig', got '{type_}'")

        def _parse_dataset_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        dataset_id = _parse_dataset_id(d.pop("datasetId", UNSET))

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_config(
            data: object,
        ) -> (
            AreaChartConfig
            | BarChartConfig
            | KpiChartConfig
            | LineChartConfig
            | None
            | PieChartConfig
            | ScatterChartConfig
            | TableChartConfig
            | Unset
        ):
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_0 = LineChartConfig.from_dict(data)

                return config_type_0_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_1 = BarChartConfig.from_dict(data)

                return config_type_0_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_2 = AreaChartConfig.from_dict(data)

                return config_type_0_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_3 = ScatterChartConfig.from_dict(data)

                return config_type_0_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_4 = PieChartConfig.from_dict(data)

                return config_type_0_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_5 = KpiChartConfig.from_dict(data)

                return config_type_0_type_5
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0_type_6 = TableChartConfig.from_dict(data)

                return config_type_0_type_6
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(
                AreaChartConfig
                | BarChartConfig
                | KpiChartConfig
                | LineChartConfig
                | None
                | PieChartConfig
                | ScatterChartConfig
                | TableChartConfig
                | Unset,
                data,
            )

        config = _parse_config(d.pop("config", UNSET))

        chart_config = cls(
            id=id,
            type_=type_,
            dataset_id=dataset_id,
            title=title,
            config=config,
        )

        chart_config.additional_properties = d
        return chart_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
