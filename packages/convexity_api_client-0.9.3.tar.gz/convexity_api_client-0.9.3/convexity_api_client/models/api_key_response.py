from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.api_key_permission import ApiKeyPermission
from ..models.api_key_status import ApiKeyStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_key_scope_roles import ApiKeyScopeRoles


T = TypeVar("T", bound="ApiKeyResponse")


@_attrs_define
class ApiKeyResponse:
    """Response model for an API key (without the actual key).

    Attributes:
        id (str):
        name (str):
        key_prefix (str):
        permission (ApiKeyPermission):
        scopes (ApiKeyScopeRoles): Role buckets for user-scoped API tokens.
        status (ApiKeyStatus):
        created_by (str):
        created_at (datetime.datetime):
        description (None | str | Unset):
        tenant_id (None | str | Unset):
        owner_user_id (None | str | Unset):
        created_by_name (None | str | Unset):
        expires_at (datetime.datetime | None | Unset):
        last_used_at (datetime.datetime | None | Unset):
        use_count (int | Unset):  Default: 0.
        rate_limit (int | None | Unset):
        allowed_ips (list[str] | Unset):
    """

    id: str
    name: str
    key_prefix: str
    permission: ApiKeyPermission
    scopes: ApiKeyScopeRoles
    status: ApiKeyStatus
    created_by: str
    created_at: datetime.datetime
    description: None | str | Unset = UNSET
    tenant_id: None | str | Unset = UNSET
    owner_user_id: None | str | Unset = UNSET
    created_by_name: None | str | Unset = UNSET
    expires_at: datetime.datetime | None | Unset = UNSET
    last_used_at: datetime.datetime | None | Unset = UNSET
    use_count: int | Unset = 0
    rate_limit: int | None | Unset = UNSET
    allowed_ips: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        key_prefix = self.key_prefix

        permission = self.permission.value

        scopes = self.scopes.to_dict()

        status = self.status.value

        created_by = self.created_by

        created_at = self.created_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        tenant_id: None | str | Unset
        if isinstance(self.tenant_id, Unset):
            tenant_id = UNSET
        else:
            tenant_id = self.tenant_id

        owner_user_id: None | str | Unset
        if isinstance(self.owner_user_id, Unset):
            owner_user_id = UNSET
        else:
            owner_user_id = self.owner_user_id

        created_by_name: None | str | Unset
        if isinstance(self.created_by_name, Unset):
            created_by_name = UNSET
        else:
            created_by_name = self.created_by_name

        expires_at: None | str | Unset
        if isinstance(self.expires_at, Unset):
            expires_at = UNSET
        elif isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        last_used_at: None | str | Unset
        if isinstance(self.last_used_at, Unset):
            last_used_at = UNSET
        elif isinstance(self.last_used_at, datetime.datetime):
            last_used_at = self.last_used_at.isoformat()
        else:
            last_used_at = self.last_used_at

        use_count = self.use_count

        rate_limit: int | None | Unset
        if isinstance(self.rate_limit, Unset):
            rate_limit = UNSET
        else:
            rate_limit = self.rate_limit

        allowed_ips: list[str] | Unset = UNSET
        if not isinstance(self.allowed_ips, Unset):
            allowed_ips = self.allowed_ips

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "keyPrefix": key_prefix,
                "permission": permission,
                "scopes": scopes,
                "status": status,
                "createdBy": created_by,
                "createdAt": created_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if tenant_id is not UNSET:
            field_dict["tenantId"] = tenant_id
        if owner_user_id is not UNSET:
            field_dict["ownerUserId"] = owner_user_id
        if created_by_name is not UNSET:
            field_dict["createdByName"] = created_by_name
        if expires_at is not UNSET:
            field_dict["expiresAt"] = expires_at
        if last_used_at is not UNSET:
            field_dict["lastUsedAt"] = last_used_at
        if use_count is not UNSET:
            field_dict["useCount"] = use_count
        if rate_limit is not UNSET:
            field_dict["rateLimit"] = rate_limit
        if allowed_ips is not UNSET:
            field_dict["allowedIps"] = allowed_ips

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key_scope_roles import ApiKeyScopeRoles

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        key_prefix = d.pop("keyPrefix")

        permission = ApiKeyPermission(d.pop("permission"))

        scopes = ApiKeyScopeRoles.from_dict(d.pop("scopes"))

        status = ApiKeyStatus(d.pop("status"))

        created_by = d.pop("createdBy")

        created_at = isoparse(d.pop("createdAt"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_tenant_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tenant_id = _parse_tenant_id(d.pop("tenantId", UNSET))

        def _parse_owner_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        owner_user_id = _parse_owner_user_id(d.pop("ownerUserId", UNSET))

        def _parse_created_by_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        created_by_name = _parse_created_by_name(d.pop("createdByName", UNSET))

        def _parse_expires_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)

                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        expires_at = _parse_expires_at(d.pop("expiresAt", UNSET))

        def _parse_last_used_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_used_at_type_0 = isoparse(data)

                return last_used_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_used_at = _parse_last_used_at(d.pop("lastUsedAt", UNSET))

        use_count = d.pop("useCount", UNSET)

        def _parse_rate_limit(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        rate_limit = _parse_rate_limit(d.pop("rateLimit", UNSET))

        allowed_ips = cast(list[str], d.pop("allowedIps", UNSET))

        api_key_response = cls(
            id=id,
            name=name,
            key_prefix=key_prefix,
            permission=permission,
            scopes=scopes,
            status=status,
            created_by=created_by,
            created_at=created_at,
            description=description,
            tenant_id=tenant_id,
            owner_user_id=owner_user_id,
            created_by_name=created_by_name,
            expires_at=expires_at,
            last_used_at=last_used_at,
            use_count=use_count,
            rate_limit=rate_limit,
            allowed_ips=allowed_ips,
        )

        api_key_response.additional_properties = d
        return api_key_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
