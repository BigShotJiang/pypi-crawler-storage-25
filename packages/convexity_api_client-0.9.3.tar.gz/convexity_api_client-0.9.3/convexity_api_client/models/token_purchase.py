from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.profile import Profile
    from ..models.token_package import TokenPackage


T = TypeVar("T", bound="TokenPurchase")


@_attrs_define
class TokenPurchase:
    """Represents a TokenPurchase record

    Attributes:
        id (str):
        user_id (str):
        package_id (str):
        amount_usd (float | str):
        tokens_purchased (int):
        status (str):
        created_at (datetime.datetime):
        stripe_payment_intent_id (None | str | Unset):
        stripe_session_id (None | str | Unset):
        failure_reason (None | str | Unset):
        completed_at (datetime.datetime | None | Unset):
        token_packages (None | TokenPackage | Unset):
        profiles (None | Profile | Unset):
    """

    id: str
    user_id: str
    package_id: str
    amount_usd: float | str
    tokens_purchased: int
    status: str
    created_at: datetime.datetime
    stripe_payment_intent_id: None | str | Unset = UNSET
    stripe_session_id: None | str | Unset = UNSET
    failure_reason: None | str | Unset = UNSET
    completed_at: datetime.datetime | None | Unset = UNSET
    token_packages: None | TokenPackage | Unset = UNSET
    profiles: None | Profile | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.profile import Profile
        from ..models.token_package import TokenPackage

        id = self.id

        user_id = self.user_id

        package_id = self.package_id

        amount_usd: float | str
        amount_usd = self.amount_usd

        tokens_purchased = self.tokens_purchased

        status = self.status

        created_at = self.created_at.isoformat()

        stripe_payment_intent_id: None | str | Unset
        if isinstance(self.stripe_payment_intent_id, Unset):
            stripe_payment_intent_id = UNSET
        else:
            stripe_payment_intent_id = self.stripe_payment_intent_id

        stripe_session_id: None | str | Unset
        if isinstance(self.stripe_session_id, Unset):
            stripe_session_id = UNSET
        else:
            stripe_session_id = self.stripe_session_id

        failure_reason: None | str | Unset
        if isinstance(self.failure_reason, Unset):
            failure_reason = UNSET
        else:
            failure_reason = self.failure_reason

        completed_at: None | str | Unset
        if isinstance(self.completed_at, Unset):
            completed_at = UNSET
        elif isinstance(self.completed_at, datetime.datetime):
            completed_at = self.completed_at.isoformat()
        else:
            completed_at = self.completed_at

        token_packages: dict[str, Any] | None | Unset
        if isinstance(self.token_packages, Unset):
            token_packages = UNSET
        elif isinstance(self.token_packages, TokenPackage):
            token_packages = self.token_packages.to_dict()
        else:
            token_packages = self.token_packages

        profiles: dict[str, Any] | None | Unset
        if isinstance(self.profiles, Unset):
            profiles = UNSET
        elif isinstance(self.profiles, Profile):
            profiles = self.profiles.to_dict()
        else:
            profiles = self.profiles

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "user_id": user_id,
                "package_id": package_id,
                "amount_usd": amount_usd,
                "tokens_purchased": tokens_purchased,
                "status": status,
                "created_at": created_at,
            }
        )
        if stripe_payment_intent_id is not UNSET:
            field_dict["stripe_payment_intent_id"] = stripe_payment_intent_id
        if stripe_session_id is not UNSET:
            field_dict["stripe_session_id"] = stripe_session_id
        if failure_reason is not UNSET:
            field_dict["failure_reason"] = failure_reason
        if completed_at is not UNSET:
            field_dict["completed_at"] = completed_at
        if token_packages is not UNSET:
            field_dict["token_packages"] = token_packages
        if profiles is not UNSET:
            field_dict["profiles"] = profiles

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.profile import Profile
        from ..models.token_package import TokenPackage

        d = dict(src_dict)
        id = d.pop("id")

        user_id = d.pop("user_id")

        package_id = d.pop("package_id")

        def _parse_amount_usd(data: object) -> float | str:
            return cast(float | str, data)

        amount_usd = _parse_amount_usd(d.pop("amount_usd"))

        tokens_purchased = d.pop("tokens_purchased")

        status = d.pop("status")

        created_at = isoparse(d.pop("created_at"))

        def _parse_stripe_payment_intent_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        stripe_payment_intent_id = _parse_stripe_payment_intent_id(d.pop("stripe_payment_intent_id", UNSET))

        def _parse_stripe_session_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        stripe_session_id = _parse_stripe_session_id(d.pop("stripe_session_id", UNSET))

        def _parse_failure_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        failure_reason = _parse_failure_reason(d.pop("failure_reason", UNSET))

        def _parse_completed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                completed_at_type_0 = isoparse(data)

                return completed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        completed_at = _parse_completed_at(d.pop("completed_at", UNSET))

        def _parse_token_packages(data: object) -> None | TokenPackage | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                token_packages_type_0 = TokenPackage.from_dict(data)

                return token_packages_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TokenPackage | Unset, data)

        token_packages = _parse_token_packages(d.pop("token_packages", UNSET))

        def _parse_profiles(data: object) -> None | Profile | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                profiles_type_0 = Profile.from_dict(data)

                return profiles_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Profile | Unset, data)

        profiles = _parse_profiles(d.pop("profiles", UNSET))

        token_purchase = cls(
            id=id,
            user_id=user_id,
            package_id=package_id,
            amount_usd=amount_usd,
            tokens_purchased=tokens_purchased,
            status=status,
            created_at=created_at,
            stripe_payment_intent_id=stripe_payment_intent_id,
            stripe_session_id=stripe_session_id,
            failure_reason=failure_reason,
            completed_at=completed_at,
            token_packages=token_packages,
            profiles=profiles,
        )

        token_purchase.additional_properties = d
        return token_purchase

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
