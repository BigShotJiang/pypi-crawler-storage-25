from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.dataset_parameter_type import DatasetParameterType
from ..types import UNSET, Unset

T = TypeVar("T", bound="DatasetParameter")


@_attrs_define
class DatasetParameter:
    """Parameter definition for parameterized datasets.

    Attributes:
        name (str): Parameter name
        type_ (DatasetParameterType): Parameter type
        default_value (Any | None | Unset): Default value
        required (bool | Unset): Whether the parameter is required Default: False.
    """

    name: str
    type_: DatasetParameterType
    default_value: Any | None | Unset = UNSET
    required: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        type_ = self.type_.value

        default_value: Any | None | Unset
        if isinstance(self.default_value, Unset):
            default_value = UNSET
        else:
            default_value = self.default_value

        required = self.required

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type_,
            }
        )
        if default_value is not UNSET:
            field_dict["defaultValue"] = default_value
        if required is not UNSET:
            field_dict["required"] = required

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        type_ = DatasetParameterType(d.pop("type"))

        def _parse_default_value(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        default_value = _parse_default_value(d.pop("defaultValue", UNSET))

        required = d.pop("required", UNSET)

        dataset_parameter = cls(
            name=name,
            type_=type_,
            default_value=default_value,
            required=required,
        )

        dataset_parameter.additional_properties = d
        return dataset_parameter

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
