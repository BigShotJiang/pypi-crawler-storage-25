from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateDatabaseConnectionRequest")


@_attrs_define
class UpdateDatabaseConnectionRequest:
    """
    Attributes:
        name (None | str | Unset): Connection name
        description (None | str | Unset): Connection description
        db_type (None | str | Unset): Database type
        connection_string (None | str | Unset): Full connection string
        host (None | str | Unset): Database host
        port (int | None | Unset): Database port
        db_name (None | str | Unset): Database name
        db_schema (None | str | Unset): Database schema
        username (None | str | Unset): Database username
        password (None | str | Unset): Database password
    """

    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    db_type: None | str | Unset = UNSET
    connection_string: None | str | Unset = UNSET
    host: None | str | Unset = UNSET
    port: int | None | Unset = UNSET
    db_name: None | str | Unset = UNSET
    db_schema: None | str | Unset = UNSET
    username: None | str | Unset = UNSET
    password: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        db_type: None | str | Unset
        if isinstance(self.db_type, Unset):
            db_type = UNSET
        else:
            db_type = self.db_type

        connection_string: None | str | Unset
        if isinstance(self.connection_string, Unset):
            connection_string = UNSET
        else:
            connection_string = self.connection_string

        host: None | str | Unset
        if isinstance(self.host, Unset):
            host = UNSET
        else:
            host = self.host

        port: int | None | Unset
        if isinstance(self.port, Unset):
            port = UNSET
        else:
            port = self.port

        db_name: None | str | Unset
        if isinstance(self.db_name, Unset):
            db_name = UNSET
        else:
            db_name = self.db_name

        db_schema: None | str | Unset
        if isinstance(self.db_schema, Unset):
            db_schema = UNSET
        else:
            db_schema = self.db_schema

        username: None | str | Unset
        if isinstance(self.username, Unset):
            username = UNSET
        else:
            username = self.username

        password: None | str | Unset
        if isinstance(self.password, Unset):
            password = UNSET
        else:
            password = self.password

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if db_type is not UNSET:
            field_dict["dbType"] = db_type
        if connection_string is not UNSET:
            field_dict["connectionString"] = connection_string
        if host is not UNSET:
            field_dict["host"] = host
        if port is not UNSET:
            field_dict["port"] = port
        if db_name is not UNSET:
            field_dict["dbName"] = db_name
        if db_schema is not UNSET:
            field_dict["dbSchema"] = db_schema
        if username is not UNSET:
            field_dict["username"] = username
        if password is not UNSET:
            field_dict["password"] = password

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_db_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        db_type = _parse_db_type(d.pop("dbType", UNSET))

        def _parse_connection_string(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        connection_string = _parse_connection_string(d.pop("connectionString", UNSET))

        def _parse_host(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        host = _parse_host(d.pop("host", UNSET))

        def _parse_port(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        port = _parse_port(d.pop("port", UNSET))

        def _parse_db_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        db_name = _parse_db_name(d.pop("dbName", UNSET))

        def _parse_db_schema(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        db_schema = _parse_db_schema(d.pop("dbSchema", UNSET))

        def _parse_username(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        username = _parse_username(d.pop("username", UNSET))

        def _parse_password(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        password = _parse_password(d.pop("password", UNSET))

        update_database_connection_request = cls(
            name=name,
            description=description,
            db_type=db_type,
            connection_string=connection_string,
            host=host,
            port=port,
            db_name=db_name,
            db_schema=db_schema,
            username=username,
            password=password,
        )

        update_database_connection_request.additional_properties = d
        return update_database_connection_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
