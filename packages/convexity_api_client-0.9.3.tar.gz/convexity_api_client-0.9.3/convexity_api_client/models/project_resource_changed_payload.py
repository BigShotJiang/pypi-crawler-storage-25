from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.project_resource_changed_payload_action import ProjectResourceChangedPayloadAction
from ..models.project_resource_changed_payload_resource_type import ProjectResourceChangedPayloadResourceType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.project_resource_changed_payload_metadata_type_0 import ProjectResourceChangedPayloadMetadataType0


T = TypeVar("T", bound="ProjectResourceChangedPayload")


@_attrs_define
class ProjectResourceChangedPayload:
    """
    Attributes:
        resource_type (ProjectResourceChangedPayloadResourceType):
        resource_id (str):
        action (ProjectResourceChangedPayloadAction):
        metadata (None | ProjectResourceChangedPayloadMetadataType0 | Unset):
    """

    resource_type: ProjectResourceChangedPayloadResourceType
    resource_id: str
    action: ProjectResourceChangedPayloadAction
    metadata: None | ProjectResourceChangedPayloadMetadataType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.project_resource_changed_payload_metadata_type_0 import ProjectResourceChangedPayloadMetadataType0

        resource_type = self.resource_type.value

        resource_id = self.resource_id

        action = self.action.value

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, ProjectResourceChangedPayloadMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "resource_type": resource_type,
                "resource_id": resource_id,
                "action": action,
            }
        )
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.project_resource_changed_payload_metadata_type_0 import ProjectResourceChangedPayloadMetadataType0

        d = dict(src_dict)
        resource_type = ProjectResourceChangedPayloadResourceType(d.pop("resource_type"))

        resource_id = d.pop("resource_id")

        action = ProjectResourceChangedPayloadAction(d.pop("action"))

        def _parse_metadata(data: object) -> None | ProjectResourceChangedPayloadMetadataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = ProjectResourceChangedPayloadMetadataType0.from_dict(data)

                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ProjectResourceChangedPayloadMetadataType0 | Unset, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        project_resource_changed_payload = cls(
            resource_type=resource_type,
            resource_id=resource_id,
            action=action,
            metadata=metadata,
        )

        project_resource_changed_payload.additional_properties = d
        return project_resource_changed_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
