from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="SyncCatalogToS3Payload")


@_attrs_define
class SyncCatalogToS3Payload:
    """Payload for syncing the DuckLake catalog to S3.

    Exports the PostgreSQL catalog metadata to a DuckDB file on S3
    so that the frontend DuckDB WASM can attach it as a read-only
    catalog for direct data access.

        Attributes:
            project_id (str): Project whose catalog to sync
            type_ (Literal['sync_catalog_to_s3'] | Unset):  Default: 'sync_catalog_to_s3'.
    """

    project_id: str
    type_: Literal["sync_catalog_to_s3"] | Unset = "sync_catalog_to_s3"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        project_id = self.project_id

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "projectId": project_id,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        project_id = d.pop("projectId")

        type_ = cast(Literal["sync_catalog_to_s3"] | Unset, d.pop("type", UNSET))
        if type_ != "sync_catalog_to_s3" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'sync_catalog_to_s3', got '{type_}'")

        sync_catalog_to_s3_payload = cls(
            project_id=project_id,
            type_=type_,
        )

        sync_catalog_to_s3_payload.additional_properties = d
        return sync_catalog_to_s3_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
