from enum import Enum


class DashboardChartWidgetModeType0(str, Enum):
    DATASET = "dataset"
    SQL = "sql"

    def __str__(self) -> str:
        return str(self.value)
