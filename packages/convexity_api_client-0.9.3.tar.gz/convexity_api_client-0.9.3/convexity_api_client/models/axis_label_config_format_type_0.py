from enum import Enum


class AxisLabelConfigFormatType0(str, Enum):
    CURRENCY = "currency"
    NUMBER = "number"
    PERCENT = "percent"

    def __str__(self) -> str:
        return str(self.value)
