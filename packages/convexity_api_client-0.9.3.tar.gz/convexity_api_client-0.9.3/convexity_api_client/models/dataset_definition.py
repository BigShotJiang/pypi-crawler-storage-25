from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.dataset_type import DatasetType
from ..models.refresh_mode import RefreshMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.column import Column
    from ..models.dataset_config import DatasetConfig


T = TypeVar("T", bound="DatasetDefinition")


@_attrs_define
class DatasetDefinition:
    """Dataset definition model.

    Attributes:
        id (str): Unique dataset identifier
        name (str): Dataset name
        type_ (DatasetType):
        config (DatasetConfig): Union of all dataset config types.
        user_id (str): Creator user ID
        project_id (str): Project ID
        description (None | str | Unset): Dataset description
        connection_id (None | str | Unset): Connection ID for data source
        schema (list[Column] | None | Unset): Column schema
        refresh_mode (RefreshMode | Unset):
        refresh_schedule (None | str | Unset): Cron schedule for refresh
        last_refreshed_at (datetime.datetime | None | Unset): Last refresh timestamp
        cache_ttl_seconds (int | None | Unset): Cache TTL in seconds
        tags (list[str] | None | Unset): Tags
        created_at (datetime.datetime | None | Unset): Creation timestamp
        updated_at (datetime.datetime | None | Unset): Last update timestamp
    """

    id: str
    name: str
    type_: DatasetType
    config: DatasetConfig
    user_id: str
    project_id: str
    description: None | str | Unset = UNSET
    connection_id: None | str | Unset = UNSET
    schema: list[Column] | None | Unset = UNSET
    refresh_mode: RefreshMode | Unset = UNSET
    refresh_schedule: None | str | Unset = UNSET
    last_refreshed_at: datetime.datetime | None | Unset = UNSET
    cache_ttl_seconds: int | None | Unset = UNSET
    tags: list[str] | None | Unset = UNSET
    created_at: datetime.datetime | None | Unset = UNSET
    updated_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        type_ = self.type_.value

        config = self.config.to_dict()

        user_id = self.user_id

        project_id = self.project_id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        connection_id: None | str | Unset
        if isinstance(self.connection_id, Unset):
            connection_id = UNSET
        else:
            connection_id = self.connection_id

        schema: list[dict[str, Any]] | None | Unset
        if isinstance(self.schema, Unset):
            schema = UNSET
        elif isinstance(self.schema, list):
            schema = []
            for schema_type_0_item_data in self.schema:
                schema_type_0_item = schema_type_0_item_data.to_dict()
                schema.append(schema_type_0_item)

        else:
            schema = self.schema

        refresh_mode: str | Unset = UNSET
        if not isinstance(self.refresh_mode, Unset):
            refresh_mode = self.refresh_mode.value

        refresh_schedule: None | str | Unset
        if isinstance(self.refresh_schedule, Unset):
            refresh_schedule = UNSET
        else:
            refresh_schedule = self.refresh_schedule

        last_refreshed_at: None | str | Unset
        if isinstance(self.last_refreshed_at, Unset):
            last_refreshed_at = UNSET
        elif isinstance(self.last_refreshed_at, datetime.datetime):
            last_refreshed_at = self.last_refreshed_at.isoformat()
        else:
            last_refreshed_at = self.last_refreshed_at

        cache_ttl_seconds: int | None | Unset
        if isinstance(self.cache_ttl_seconds, Unset):
            cache_ttl_seconds = UNSET
        else:
            cache_ttl_seconds = self.cache_ttl_seconds

        tags: list[str] | None | Unset
        if isinstance(self.tags, Unset):
            tags = UNSET
        elif isinstance(self.tags, list):
            tags = self.tags

        else:
            tags = self.tags

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        elif isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        elif isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "type": type_,
                "config": config,
                "userId": user_id,
                "projectId": project_id,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if connection_id is not UNSET:
            field_dict["connectionId"] = connection_id
        if schema is not UNSET:
            field_dict["schema"] = schema
        if refresh_mode is not UNSET:
            field_dict["refreshMode"] = refresh_mode
        if refresh_schedule is not UNSET:
            field_dict["refreshSchedule"] = refresh_schedule
        if last_refreshed_at is not UNSET:
            field_dict["lastRefreshedAt"] = last_refreshed_at
        if cache_ttl_seconds is not UNSET:
            field_dict["cacheTtlSeconds"] = cache_ttl_seconds
        if tags is not UNSET:
            field_dict["tags"] = tags
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.column import Column
        from ..models.dataset_config import DatasetConfig

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        type_ = DatasetType(d.pop("type"))

        config = DatasetConfig.from_dict(d.pop("config"))

        user_id = d.pop("userId")

        project_id = d.pop("projectId")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_connection_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        connection_id = _parse_connection_id(d.pop("connectionId", UNSET))

        def _parse_schema(data: object) -> list[Column] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                schema_type_0 = []
                _schema_type_0 = data
                for schema_type_0_item_data in _schema_type_0:
                    schema_type_0_item = Column.from_dict(schema_type_0_item_data)

                    schema_type_0.append(schema_type_0_item)

                return schema_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Column] | None | Unset, data)

        schema = _parse_schema(d.pop("schema", UNSET))

        _refresh_mode = d.pop("refreshMode", UNSET)
        refresh_mode: RefreshMode | Unset
        if isinstance(_refresh_mode, Unset):
            refresh_mode = UNSET
        else:
            refresh_mode = RefreshMode(_refresh_mode)

        def _parse_refresh_schedule(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        refresh_schedule = _parse_refresh_schedule(d.pop("refreshSchedule", UNSET))

        def _parse_last_refreshed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_refreshed_at_type_0 = isoparse(data)

                return last_refreshed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_refreshed_at = _parse_last_refreshed_at(d.pop("lastRefreshedAt", UNSET))

        def _parse_cache_ttl_seconds(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cache_ttl_seconds = _parse_cache_ttl_seconds(d.pop("cacheTtlSeconds", UNSET))

        def _parse_tags(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tags_type_0 = cast(list[str], data)

                return tags_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        tags = _parse_tags(d.pop("tags", UNSET))

        def _parse_created_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = isoparse(data)

                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        created_at = _parse_created_at(d.pop("createdAt", UNSET))

        def _parse_updated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = isoparse(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        updated_at = _parse_updated_at(d.pop("updatedAt", UNSET))

        dataset_definition = cls(
            id=id,
            name=name,
            type_=type_,
            config=config,
            user_id=user_id,
            project_id=project_id,
            description=description,
            connection_id=connection_id,
            schema=schema,
            refresh_mode=refresh_mode,
            refresh_schedule=refresh_schedule,
            last_refreshed_at=last_refreshed_at,
            cache_ttl_seconds=cache_ttl_seconds,
            tags=tags,
            created_at=created_at,
            updated_at=updated_at,
        )

        dataset_definition.additional_properties = d
        return dataset_definition

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
