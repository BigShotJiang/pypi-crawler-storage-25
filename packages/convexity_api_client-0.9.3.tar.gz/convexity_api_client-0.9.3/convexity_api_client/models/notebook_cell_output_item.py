from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.output_type import OutputType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.notebook_cell_output_item_data_type_0 import NotebookCellOutputItemDataType0
    from ..models.notebook_cell_output_item_metadata_type_0 import NotebookCellOutputItemMetadataType0


T = TypeVar("T", bound="NotebookCellOutputItem")


@_attrs_define
class NotebookCellOutputItem:
    """Individual output item from cell execution.

    Attributes:
        output_type (OutputType): Notebook cell output types.
        name (None | str | Unset):
        text (None | str | Unset):
        data (None | NotebookCellOutputItemDataType0 | Unset):
        metadata (None | NotebookCellOutputItemMetadataType0 | Unset):
        execution_count (int | None | Unset):
    """

    output_type: OutputType
    name: None | str | Unset = UNSET
    text: None | str | Unset = UNSET
    data: None | NotebookCellOutputItemDataType0 | Unset = UNSET
    metadata: None | NotebookCellOutputItemMetadataType0 | Unset = UNSET
    execution_count: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.notebook_cell_output_item_data_type_0 import NotebookCellOutputItemDataType0
        from ..models.notebook_cell_output_item_metadata_type_0 import NotebookCellOutputItemMetadataType0

        output_type = self.output_type.value

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        text: None | str | Unset
        if isinstance(self.text, Unset):
            text = UNSET
        else:
            text = self.text

        data: dict[str, Any] | None | Unset
        if isinstance(self.data, Unset):
            data = UNSET
        elif isinstance(self.data, NotebookCellOutputItemDataType0):
            data = self.data.to_dict()
        else:
            data = self.data

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, NotebookCellOutputItemMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        execution_count: int | None | Unset
        if isinstance(self.execution_count, Unset):
            execution_count = UNSET
        else:
            execution_count = self.execution_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "output_type": output_type,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if text is not UNSET:
            field_dict["text"] = text
        if data is not UNSET:
            field_dict["data"] = data
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if execution_count is not UNSET:
            field_dict["execution_count"] = execution_count

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.notebook_cell_output_item_data_type_0 import NotebookCellOutputItemDataType0
        from ..models.notebook_cell_output_item_metadata_type_0 import NotebookCellOutputItemMetadataType0

        d = dict(src_dict)
        output_type = OutputType(d.pop("output_type"))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_text(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        text = _parse_text(d.pop("text", UNSET))

        def _parse_data(data: object) -> None | NotebookCellOutputItemDataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                data_type_0 = NotebookCellOutputItemDataType0.from_dict(data)

                return data_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NotebookCellOutputItemDataType0 | Unset, data)

        data = _parse_data(d.pop("data", UNSET))

        def _parse_metadata(data: object) -> None | NotebookCellOutputItemMetadataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = NotebookCellOutputItemMetadataType0.from_dict(data)

                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NotebookCellOutputItemMetadataType0 | Unset, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        def _parse_execution_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        execution_count = _parse_execution_count(d.pop("execution_count", UNSET))

        notebook_cell_output_item = cls(
            output_type=output_type,
            name=name,
            text=text,
            data=data,
            metadata=metadata,
            execution_count=execution_count,
        )

        notebook_cell_output_item.additional_properties = d
        return notebook_cell_output_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
