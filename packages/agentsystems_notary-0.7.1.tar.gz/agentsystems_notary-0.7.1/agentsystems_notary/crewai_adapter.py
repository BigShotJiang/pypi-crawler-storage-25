"""CrewAI adapter for Notary compliance logging."""

import threading
from typing import Any

from .config import RawPayloadStorage
from .core import HashStorage, NotaryCore

try:
    from crewai.hooks import after_llm_call, before_llm_call

    CREWAI_AVAILABLE = True
except ImportError:
    CREWAI_AVAILABLE = False


class CrewAINotary:
    """
    CrewAI hook handler for Notary compliance logging.

    This is a thin adapter that extracts data from CrewAI's hook context
    and passes it to the framework-agnostic NotaryCore.

    Args:
        raw_payload_storage: Configuration for vendor's S3 bucket (full audit logs)
        hash_storage: List of hash storage configurations (custodied and/or Arweave)
        debug: Enable debug output (default: False)

    Example:
        ```python
        from agentsystems_notary import (
            CrewAINotary,
            RawPayloadStorage,
            CustodiedHashStorage,
        )
        from crewai import Agent, Task, Crew

        raw_payload_storage = RawPayloadStorage(
            bucket_name="acme-corp-audit-logs",
            aws_access_key_id="...",
            aws_secret_access_key="...",
        )

        # Initialize notary logging
        notary = CrewAINotary(
            raw_payload_storage=raw_payload_storage,
            hash_storage=[
                CustodiedHashStorage(
                    api_key="sk_asn_prod_...",
                    slug="tnt_acme_corp",
                ),
            ],
        )

        # Create crew - hooks are automatically registered
        agent = Agent(role="Research Analyst", ...)
        task = Task(description="Research AIUC-1 compliance", ...)
        crew = Crew(agents=[agent], tasks=[task])

        # All LLM calls are logged automatically
        crew.kickoff()
        ```
    """

    def __init__(
        self,
        raw_payload_storage: RawPayloadStorage,
        hash_storage: list[HashStorage],
        debug: bool = False,
        pre_execution_record: dict[str, Any] | None = None,
    ):
        if not CREWAI_AVAILABLE:
            raise ImportError(
                "CrewAI is not installed. Install it with: pip install crewai"
            )

        # Initialize framework-agnostic core
        self.core = NotaryCore(
            raw_payload_storage=raw_payload_storage,
            hash_storage=hash_storage,
            debug=debug,
        )

        self._pre_execution_record = pre_execution_record

        # Pending requests keyed by request_id for concurrent call isolation
        self._pending_requests: dict[int, dict[str, Any]] = {}
        self._request_counter = 0
        self._counter_lock = threading.Lock()

        # Register hooks with CrewAI
        self._register_hooks()

    def _register_hooks(self) -> None:
        """Register before/after hooks with CrewAI."""

        @before_llm_call  # type: ignore
        def _notary_before_llm(context: Any) -> None:
            """Capture LLM request from CrewAI context."""
            # Extract messages from context
            messages = []
            if hasattr(context, "messages") and context.messages:
                for msg in context.messages:
                    if isinstance(msg, dict):
                        messages.append(
                            {
                                "role": msg.get("role", "unknown"),
                                "content": msg.get("content", str(msg)),
                            }
                        )
                    else:
                        messages.append(
                            {
                                "role": getattr(msg, "role", "unknown"),
                                "content": getattr(msg, "content", str(msg)),
                            }
                        )

            # Generate unique request_id with thread-safe counter
            with self._counter_lock:
                self._request_counter += 1
                request_id = self._request_counter

            # Store request data keyed by request_id
            self._pending_requests[request_id] = {
                "messages": messages,
                "agent": context.agent.role if context.agent else None,
                "task": context.task.description if context.task else None,
                "crew": context.crew.name if hasattr(context.crew, "name") else None,
            }

            # Attach request_id to executor for retrieval in after_hook
            # (before/after hooks get different LLMCallHookContext wrappers,
            # but context.executor is the same CrewAgentExecutor instance)
            if context.executor is not None:
                context.executor._notary_request_id = request_id
            else:
                context._notary_request_id = request_id

            return None  # Allow execution

        @after_llm_call  # type: ignore
        def _notary_after_llm(context: Any) -> None:
            """Capture LLM response and log to Notary."""
            # Retrieve request_id from executor (or context for direct calls)
            target = context.executor if context.executor is not None else context
            request_id = getattr(target, "_notary_request_id", None)
            if request_id is None:
                return None

            request_data = self._pending_requests.pop(request_id, None)
            if request_data is None:
                return None

            # Extract response from context
            output_data = {
                "text": context.response if hasattr(context, "response") else ""
            }

            # Build metadata from CrewAI context
            metadata: dict[str, Any] = {}
            if context.agent:
                metadata["agent_role"] = context.agent.role
            if context.task:
                # Truncate long descriptions
                metadata["task_description"] = context.task.description[:100]
            if hasattr(context, "iterations"):
                metadata["iteration"] = context.iterations

            # Call framework-agnostic core
            self.core.log_interaction(
                input_data=request_data,
                output_data=output_data,
                metadata=metadata,
                pre_execution_record=self._pre_execution_record,
            )

            return None  # Don't modify response
