# tibet-gateway

> **Alpha** -- API may change between versions.

Sovereign external API proxy with TIBET provenance. Routes all AI agent egress traffic through a single gateway with host allowlist, intent verification (SNAFT), and provenance sealing.

## Install

```bash
pip install tibet-gateway
```

## Quick start

**1. Configure allowed hosts** (safe default: block all)

```bash
export TIBET_GATEWAY_ALLOWED_HOSTS=api.openai.com,api.anthropic.com
```

**2. Start the gateway**

```bash
tibet-gateway serve --port 8080
```

**3. Proxy a call**

```bash
curl -X POST http://localhost:8080/proxy \
  -H "Content-Type: application/json" \
  -d '{
    "agent_id": "my-bot.aint",
    "intent": "summarize_text",
    "target_url": "https://api.openai.com/v1/chat/completions",
    "method": "POST",
    "payload": {"model": "gpt-4", "messages": [{"role": "user", "content": "Hello"}]}
  }'
```

The response includes the original API response plus a TIBET seal with full provenance.

**4. Check stats**

```bash
tibet-gateway stats
```

## What happens on each call

1. **Host check** -- target domain must be in `TIBET_GATEWAY_ALLOWED_HOSTS`
2. **TIBET envelope** -- mint provenance token (actor, intent, timestamp)
3. **SNAFT check** -- verify payload matches declared intent
4. **Identity headers** -- attach AINS identity and TBZ signature
5. **Proxy** -- forward to external API
6. **Seal** -- wrap response with TIBET seal and log stats

## Configuration

| Environment variable | Description | Default |
|---|---|---|
| `TIBET_GATEWAY_ALLOWED_HOSTS` | Comma-separated list of allowed domains | empty (block all) |

## Part of the TIBET ecosystem

- [tibet](https://pypi.org/project/tibet/) -- core provenance tokens
- [tibet-airlock](https://pypi.org/project/tibet-airlock/) -- sandbox execution
- [tibet-mux](https://pypi.org/project/tibet-mux/) -- channel multiplexing

---

*Authors: Jasper van de Meent, Gemini & Root AI (Humotica AI fAmIly)*
*License: MIT*
