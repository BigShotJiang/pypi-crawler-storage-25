"""CLI entry point for tibet-gateway."""

import argparse
import sys


def main() -> None:
    """Main CLI entry point — run server or show stats."""
    parser = argparse.ArgumentParser(
        prog="tibet-gateway",
        description="TIBET Gateway — sovereign external API proxy with provenance",
    )
    subparsers = parser.add_subparsers(dest="command")

    # tibet-gateway serve
    serve_parser = subparsers.add_parser("serve", help="Start the gateway server")
    serve_parser.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    serve_parser.add_argument("--port", type=int, default=8080, help="Bind port (default: 8080)")

    # tibet-gateway stats
    subparsers.add_parser("stats", help="Show gateway statistics")

    args = parser.parse_args()

    if args.command == "serve":
        try:
            import uvicorn
        except ImportError:
            print("Error: uvicorn is required. Install with: pip install tibet-gateway", file=sys.stderr)
            sys.exit(1)
        from .gateway import app
        uvicorn.run(app, host=args.host, port=args.port)

    elif args.command == "stats":
        from .tibet_seal import get_global_stats
        stats = get_global_stats()
        print("TIBET Gateway Status: Active")
        print("-" * 40)
        for key, value in stats.items():
            print(f"  {key:<20}: {value}")
        print("-" * 40)

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
