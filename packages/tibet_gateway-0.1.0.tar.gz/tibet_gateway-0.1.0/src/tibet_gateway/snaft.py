"""SNAFT — Security Network Action Filtering & Triage.

Simple keyword-based intent-vs-payload validation for tibet-gateway v0.1.0.
Checks whether the payload content is consistent with the declared intent.
"""

import json


def snaft_check(intent: str, payload: dict | None) -> tuple[bool, str]:
    """Check if the payload matches the declared intent.

    Args:
        intent: Declared intent string (e.g. "chat", "payment", "query").
        payload: The request payload to inspect.

    Returns:
        Tuple of (is_safe, reason). If is_safe is False, reason explains why.
    """
    payload_str = json.dumps(payload).lower() if payload else ""

    # Rule 1: No code execution keywords when intent is conversational
    if "chat" in intent or "summarize" in intent:
        dangerous_keywords = ["os.system", "exec(", "eval(", "subprocess", "rm -rf"]
        if any(kw in payload_str for kw in dangerous_keywords):
            return False, "Payload contains code execution keywords but intent is conversational."

    # Rule 2: Destructive SQL when intent is data/query
    if "data" in intent or "query" in intent:
        sql_keywords = ["drop table", "delete from", "truncate"]
        if any(kw in payload_str for kw in sql_keywords):
            return False, "Payload contains destructive SQL keywords."

    # Rule 3: Payment intent must include amount/currency
    if "payment" in intent or "stripe" in intent:
        if "amount" not in payload_str and "currency" not in payload_str:
            return False, "Payment intent requires 'amount' and 'currency' fields."

    return True, "Safe."
