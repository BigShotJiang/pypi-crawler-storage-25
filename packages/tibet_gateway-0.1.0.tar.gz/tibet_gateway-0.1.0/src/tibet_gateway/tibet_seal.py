"""TIBET seal — envelope minting, response sealing, and gateway statistics."""

import time
import uuid

# In-memory stats store (resets on process restart)
gateway_stats: dict = {
    "requests": 0,
    "unique_apis": set(),
    "tokens_minted": 0,
    "snaft_blocks": 0,
    "cost_tracked": 0.0,
    "latencies": [],
}


def mint_envelope(agent_id: str, intent: str, target: str) -> dict:
    """Mint a TIBET envelope before external execution.

    Args:
        agent_id: The calling agent's identifier.
        intent: Declared intent for the request.
        target: Target URL being called.

    Returns:
        Envelope dict with id, actor, intent, target, timestamp, status.
    """
    return {
        "id": str(uuid.uuid4()),
        "actor": agent_id,
        "intent": intent,
        "target": target,
        "timestamp": time.time(),
        "status": "pending",
    }


def seal_response(
    original_envelope: dict,
    response_status: int,
    response_data: str,
    latency_ms: float,
) -> dict:
    """Seal an external API response with TIBET provenance.

    Args:
        original_envelope: The envelope from mint_envelope().
        response_status: HTTP status code from the external API.
        response_data: Response body text.
        latency_ms: Gateway latency in milliseconds.

    Returns:
        TIBET seal dict with provenance fields.
    """
    return {
        "erin": f"Response status: {response_status}. Data length: {len(response_data)}",
        "eraan": f"API: {original_envelope['target']}",
        "eromheen": f"SNAFT: Passed. Gateway Latency: {latency_ms:.2f}ms",
        "erachter": original_envelope["intent"],
        "cryptographic_seal": f"tbz_sign_ed25519_response_{original_envelope['id']}",
        "timestamp": time.time(),
    }


def log_request_stats(
    agent_id: str,
    target_url: str,
    status: str,
    cost: float,
    latency_ms: float | None = None,
) -> None:
    """Track global statistics for the gateway.

    Args:
        agent_id: The calling agent's identifier.
        target_url: The target URL that was called.
        status: Request outcome — "success", "blocked", or "error".
        cost: Estimated cost of the request.
        latency_ms: Gateway latency in milliseconds (if available).
    """
    gateway_stats["requests"] += 1
    gateway_stats["unique_apis"].add(
        target_url.split("/")[2] if "://" in target_url else target_url
    )

    if status == "success":
        gateway_stats["tokens_minted"] += 1
    elif status == "blocked":
        gateway_stats["snaft_blocks"] += 1

    gateway_stats["cost_tracked"] += cost

    if latency_ms is not None:
        gateway_stats["latencies"].append(latency_ms)


def get_global_stats() -> dict:
    """Return current gateway statistics.

    Returns:
        Dict with human-readable stats (requests, APIs, blocks, latency, cost).
    """
    latencies = gateway_stats["latencies"]
    avg_latency = sum(latencies) / len(latencies) if latencies else 0.0
    return {
        "Requests": gateway_stats["requests"],
        "Unique APIs": len(gateway_stats["unique_apis"]),
        "TIBET tokens minted": gateway_stats["tokens_minted"],
        "SNAFT blocks": gateway_stats["snaft_blocks"],
        "Avg latency": f"{avg_latency:.2f}ms",
        "Cost tracked": f"${gateway_stats['cost_tracked']:.4f}",
    }
