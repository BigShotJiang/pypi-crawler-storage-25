"""TIBET Gateway — sovereign external API proxy with host allowlist and TIBET provenance."""

import os
import time
from typing import Optional
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import httpx

from .snaft import snaft_check
from .tibet_seal import mint_envelope, seal_response, log_request_stats

app = FastAPI(
    title="TIBET Gateway",
    version="0.1.0",
    description="Sovereign external API proxy with egress control and TIBET provenance",
)

# --- Host allowlist ---
# Comma-separated list of allowed domains. Empty = block all (safe default).
# Example: TIBET_GATEWAY_ALLOWED_HOSTS=api.openai.com,api.anthropic.com,api.stripe.com
_hosts_env = os.environ.get("TIBET_GATEWAY_ALLOWED_HOSTS", "")
ALLOWED_HOSTS: list[str] = [h.strip().lower() for h in _hosts_env.split(",") if h.strip()]


def _check_host_allowed(url: str) -> str | None:
    """Return the hostname if allowed, or raise HTTPException if blocked."""
    parsed = urlparse(url)
    hostname = (parsed.hostname or "").lower()
    if not hostname:
        raise HTTPException(status_code=400, detail="Invalid target URL: no hostname")
    if not ALLOWED_HOSTS:
        raise HTTPException(
            status_code=403,
            detail=(
                f"Host '{hostname}' blocked: no hosts configured. "
                "Set TIBET_GATEWAY_ALLOWED_HOSTS to allow egress."
            ),
        )
    if hostname not in ALLOWED_HOSTS:
        raise HTTPException(
            status_code=403,
            detail=f"Host '{hostname}' not in allowlist. Allowed: {', '.join(ALLOWED_HOSTS)}",
        )
    return hostname


class ExternalCallRequest(BaseModel):
    """Request model for proxied external API calls."""

    agent_id: str
    intent: str
    target_url: str
    method: str = "POST"
    headers: Optional[dict] = {}
    payload: Optional[dict] = {}


@app.post("/proxy")
async def proxy_external_call(req: ExternalCallRequest):
    """Proxy an external API call with TIBET envelope, SNAFT check, and host allowlist."""
    start_time = time.perf_counter()

    # 0. Host allowlist check
    _check_host_allowed(req.target_url)

    # 1. TIBET envelope minten (intent, timestamp, actor)
    envelope = mint_envelope(agent_id=req.agent_id, intent=req.intent, target=req.target_url)

    # 2. SNAFT check (mag deze call, past intent bij payload?)
    is_safe, block_reason = snaft_check(intent=req.intent, payload=req.payload)
    if not is_safe:
        log_request_stats(req.agent_id, req.target_url, status="blocked", cost=0.0)
        raise HTTPException(status_code=403, detail=f"SNAFT Blocked: {block_reason}")

    # 3. JIS identity toevoegen aan request headers + TBZ Sign
    headers = req.headers or {}
    headers["X-AINS-Identity"] = req.agent_id
    headers["X-TIBET-Envelope"] = envelope["id"]
    headers["X-TBZ-Signature"] = "ed25519:signed_by_gateway"

    # 4. Request doorsturen (Egress naar externe API)
    try:
        async with httpx.AsyncClient() as client:
            if req.method.upper() == "POST":
                ext_res = await client.post(req.target_url, headers=headers, json=req.payload)
            elif req.method.upper() == "GET":
                ext_res = await client.get(req.target_url, headers=headers)
            else:
                raise HTTPException(status_code=405, detail="Method not allowed in gateway")

            ext_status = ext_res.status_code
            ext_data = ext_res.text

            # Simple cost simulation for API tracking
            estimated_cost = len(str(req.payload)) * 0.00001 if req.payload else 0.0

    except httpx.HTTPError as e:
        log_request_stats(req.agent_id, req.target_url, status="error", cost=0.0)
        raise HTTPException(status_code=502, detail=f"External API failed: {e}")

    end_time = time.perf_counter()
    latency_ms = (end_time - start_time) * 1000

    # 5. TIBET seal op het response
    sealed_response = seal_response(
        original_envelope=envelope,
        response_status=ext_status,
        response_data=ext_data,
        latency_ms=latency_ms,
    )

    # 6. Log stats
    log_request_stats(req.agent_id, req.target_url, status="success", cost=estimated_cost, latency_ms=latency_ms)

    return {
        "status": ext_status,
        "data": ext_data,
        "tibet_seal": sealed_response,
        "gateway_latency_ms": round(latency_ms, 2),
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8080)
