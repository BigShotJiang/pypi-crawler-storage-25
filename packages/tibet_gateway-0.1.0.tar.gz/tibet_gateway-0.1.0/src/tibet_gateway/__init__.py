"""tibet-gateway: Sovereign external API proxy with TIBET provenance."""

__version__ = "0.1.0"

from .gateway import app, ExternalCallRequest
from .snaft import snaft_check
from .tibet_seal import mint_envelope, seal_response, get_global_stats
