"""Base class and factory helper for Azure resource clients."""

from typing import Any

from azure.core.credentials import TokenCredential

from .._cache import RingCache
from ..mgmt.identity import AzureIdentity
from ..mgmt.logging import AzureLogger
from ._utils import setup_credential, setup_logger


class AzureResourceBase:
    """
    Common foundation for all Azure resource wrappers.

    Handles credential resolution, logger setup, and correlation-ID
    propagation so that each concrete resource only deals with its own
    service-specific logic.
    """

    def __init__(
        self,
        *,
        credential: TokenCredential | None = None,
        azure_identity: AzureIdentity | None = None,
        service_name: str,
        service_version: str = "1.0.0",
        logger: AzureLogger | None = None,
        connection_string: str | None = None,
    ):
        self.service_name = service_name
        self.service_version = service_version

        self.logger = setup_logger(logger=logger, service_name=service_name)

        self.credential, _ = setup_credential(
            credential=credential,
            azure_identity=azure_identity,
        )

    # ── Correlation ID ───────────────────────────────────────────

    def set_correlation_id(self, correlation_id: str) -> None:
        """Set correlation ID for request/transaction tracking."""
        AzureLogger.set_correlation_id(correlation_id)

    def get_correlation_id(self) -> str | None:
        """Get current correlation ID."""
        return AzureLogger.correlation_id()


def create_cached_resource[T: AzureResourceBase](
    cls: type[T],
    cache: RingCache,
    cache_key_parts: tuple[Any, ...],
    *,
    credential: TokenCredential | None = None,
    azure_identity: AzureIdentity | None = None,
    service_name: str,
    service_version: str = "1.0.0",
    logger: AzureLogger | None = None,
    connection_string: str | None = None,
    **kwargs: Any,
) -> T:
    """
    Factory helper: auto-creates identity, checks cache, instantiates and caches.

    Args:
        cls: Resource class to instantiate.
        cache: Module-level RingCache.
        cache_key_parts: Service-specific cache key elements.
            Credential/identity object IDs are appended automatically.
        credential: Azure credential for authentication.
        azure_identity: AzureIdentity instance for credential management.
        service_name: Service name for tracing context.
        service_version: Service version for metadata.
        logger: Optional AzureLogger instance.
        connection_string: Application Insights connection string.
        **kwargs: Additional constructor arguments forwarded to *cls*.

    """
    if credential is None and azure_identity is None:
        from ..mgmt.identity import create_azure_identity

        azure_identity = create_azure_identity(
            service_name=f"{service_name}_identity",
            service_version=service_version,
            connection_string=connection_string,
        )

    cache_key = (
        *cache_key_parts,
        id(credential) if credential is not None else None,
        id(azure_identity) if azure_identity is not None else None,
    )

    if cache_key in cache:
        return cache[cache_key]

    instance = cls(
        credential=credential,
        azure_identity=azure_identity,
        service_name=service_name,
        service_version=service_version,
        logger=logger,
        connection_string=connection_string,
        **kwargs,
    )

    cache[cache_key] = instance
    return instance
