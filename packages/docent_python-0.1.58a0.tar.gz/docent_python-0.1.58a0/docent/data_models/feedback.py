"""Data structures for reading-backed feedback elicitation."""

import json
from datetime import datetime
from typing import Any, Literal, TypeAlias

from pydantic import BaseModel, Field, model_validator

from docent.data_models.citation import InlineCitation
from docent.judges.types import Rubric
from docent.judges.util.voting import OutputDistribution


def _stable_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True)


def _indent_lines(lines: list[str], indent: int) -> list[str]:
    prefix = " " * max(0, indent)
    return [f"{prefix}{line}" if line else "" for line in lines]


def _tag_block(tag: str, body_lines: list[str], indent: int) -> list[str]:
    lines = [f"<{tag}>"]
    if body_lines:
        lines.extend(_indent_lines(body_lines, indent))
    else:
        lines.extend(_indent_lines(["N/A"], indent))
    lines.append(f"</{tag}>")
    return lines


def _text_or_na(text: str | None) -> str:
    if text is None:
        return "N/A"
    stripped = text.strip()
    return stripped if stripped else "N/A"


def _text_lines_or_na(text: str | None) -> list[str]:
    return _text_or_na(text).splitlines()


def _render_citations_block(citations: list[InlineCitation], indent: int) -> list[str]:
    citation_payload = [citation.model_dump(mode="json") for citation in citations]
    citation_text = _stable_json(citation_payload) if citation_payload else "N/A"
    return _tag_block("Citations", [citation_text], indent)


# ============================================================================
# Persisted question and answer records
# These models represent the durable question/answer rows that get stored and
# later re-hydrated. They are distinct from the mutable per-session app state
# used to track generation progress.
# ============================================================================


class FeedbackQuestionContent(BaseModel):
    """Structured question content shown to a human."""

    text: str
    citations: list[InlineCitation] = Field(default_factory=lambda: list[InlineCitation]())

    def to_str(self, indent: int = 0) -> str:
        body_lines = _text_lines_or_na(self.text)
        body_lines.extend(_render_citations_block(self.citations, indent))
        return "\n".join(_tag_block("Question", body_lines, indent))


def feedback_sample_answers_to_str(sample_answers: list[str], indent: int = 0) -> str:
    body_lines = (
        [f"Answer {idx}: {answer}" for idx, answer in enumerate(sample_answers, start=1)]
        if sample_answers
        else ["N/A"]
    )
    return "\n".join(_tag_block("Sample Answers", body_lines, indent))


class FeedbackQuestionAnswer(BaseModel):
    """Persisted answer for a specific question."""

    question_id: str
    answer: str
    explanation: str | None = None
    created_at: datetime
    updated_at: datetime

    def to_str(self, question: "FeedbackQuestion", indent: int = 0) -> str:
        lines = question.question.to_str(indent=indent).splitlines()
        if question.sample_answers is not None:
            lines.extend(
                feedback_sample_answers_to_str(question.sample_answers, indent).splitlines()
            )
        lines.append(f"User answer: {_text_or_na(self.answer)}")
        lines.append(f"User explanation: {_text_or_na(self.explanation)}")
        return "\n".join(lines)


class FeedbackQuestion(BaseModel):
    """Persisted question record."""

    id: str
    feedback_session_id: str
    question: FeedbackQuestionContent
    sample_answers: list[str] | None = None
    created_at: datetime


# ============================================================================
# Mutable feedback-session application state
# These models capture orchestration state for round generation: sampled runs,
# groupings, requested label targets, and other transient workflow bookkeeping.
# They are not the user-authored answer/label payloads themselves.
# ============================================================================


FeedbackTargetObjectType = Literal[
    "agent_run",
    "transcript",
    "transcript_slice",
    "reading_result",
]
FeedbackTargetIdentity: TypeAlias = tuple[FeedbackTargetObjectType, str]


class FeedbackLabelTarget(BaseModel):
    """Canonical identity set for one requested feedback target."""

    target_identities: list[FeedbackTargetIdentity]
    target_key: str
    target_key_hash: str

    @model_validator(mode="after")
    def validate_target_identities(self) -> "FeedbackLabelTarget":
        normalized_identities: list[FeedbackTargetIdentity] = []
        seen: set[FeedbackTargetIdentity] = set()
        for identity in self.target_identities:
            if len(identity) != 2:
                raise ValueError("FeedbackLabelTarget.target_identities must be (type, id) pairs")
            object_type, object_id = identity
            stripped_id = object_id.strip()
            if not stripped_id:
                raise ValueError("FeedbackLabelTarget target IDs must be non-empty strings")
            normalized_identity: FeedbackTargetIdentity = (object_type, stripped_id)
            if normalized_identity in seen:
                raise ValueError(
                    "FeedbackLabelTarget.target_identities must not contain duplicates"
                )
            seen.add(normalized_identity)
            normalized_identities.append(normalized_identity)
        if not normalized_identities:
            raise ValueError("FeedbackLabelTarget.target_identities must contain at least one item")
        self.target_identities = normalized_identities
        self.target_key = self.target_key.strip()
        self.target_key_hash = self.target_key_hash.strip()
        if not self.target_key:
            raise ValueError("FeedbackLabelTarget.target_key must be non-empty")
        if not self.target_key_hash:
            raise ValueError("FeedbackLabelTarget.target_key_hash must be non-empty")
        return self

    def key(self) -> str:
        return self.target_key_hash


class FeedbackRoundGenerationParams(BaseModel):
    """Inputs used to generate one feedback round."""

    num_samples: int
    top_n: int
    seed: int


class FeedbackRoundInvocationEstimate(BaseModel):
    """Stored p_u metadata for one sampled reading invocation within a round."""

    target_key_hash: str
    target_key: str
    target_identities: list[FeedbackTargetIdentity] = Field(
        default_factory=lambda: list[FeedbackTargetIdentity]()
    )
    arguments_dict: dict[str, Any] = Field(default_factory=dict)
    materialized_prompt: str
    user_distribution: OutputDistribution | None = None
    reasoning: str | None = None
    reasoning_citations: list[InlineCitation] = Field(
        default_factory=lambda: list[InlineCitation]()
    )


class FeedbackQuestionGroupState(BaseModel):
    """Application-state record tying questions to representative invocations."""

    high_level_question_id: str
    representative_target_key_hashes: list[str] = Field(default_factory=lambda: list[str]())
    run_specific_question_ids_by_target_key_hash: dict[str, list[str]] = Field(
        default_factory=lambda: dict[str, list[str]]()
    )


class FeedbackRoundState(BaseModel):
    """Application-state record for one generated round."""

    round_index: int
    generation_params: FeedbackRoundGenerationParams
    sampled_target_key_hashes: list[str] = Field(default_factory=lambda: list[str]())
    invocation_estimates: list[FeedbackRoundInvocationEstimate] = Field(
        default_factory=lambda: list[FeedbackRoundInvocationEstimate]()
    )
    question_groups: list[FeedbackQuestionGroupState] = Field(
        default_factory=lambda: list[FeedbackQuestionGroupState]()
    )
    created_at: datetime = Field(default_factory=datetime.now)


class FeedbackSessionAppState(BaseModel):
    """Mutable application state for a feedback session."""

    version: int = 2
    current_round: int = 0
    requested_label_targets: list[FeedbackLabelTarget] = Field(
        default_factory=lambda: list[FeedbackLabelTarget]()
    )
    rounds: list[FeedbackRoundState] = Field(default_factory=lambda: list[FeedbackRoundState]())

    def get_round(self, round_index: int) -> FeedbackRoundState | None:
        for round_state in self.rounds:
            if round_state.round_index == round_index:
                return round_state
        return None

    def has_requested_label_target(self, target: FeedbackLabelTarget) -> bool:
        target_key = target.key()
        return any(
            existing_target.key() == target_key for existing_target in self.requested_label_targets
        )


# ============================================================================
# Persisted session record
# This is the durable feedback-session row that stores rubric metadata plus the
# mutable app-state payload above.
# ============================================================================


class FeedbackSession(BaseModel):
    """Feedback-session metadata persisted on the server."""

    id: str
    reading_preset_id: str
    reading_preset_version: int
    dql_query: str
    app_state: FeedbackSessionAppState = Field(default_factory=FeedbackSessionAppState)
    created_at: datetime


# ============================================================================
# Hydrated API response models
# These are read-oriented payloads assembled from persisted records plus app
# state so the client can render a round or poll job state.
# ============================================================================


class FeedbackQuestionWithAnswer(BaseModel):
    """Hydrated question payload returned by the API."""

    question: FeedbackQuestion
    answer: FeedbackQuestionAnswer | None = None


class FeedbackRepresentativeInvocationPrompt(BaseModel):
    """Hydrated representative-invocation payload returned by the feedback API."""

    target_key_hash: str
    target_key: str
    target_identities: list[FeedbackTargetIdentity] = Field(
        default_factory=lambda: list[FeedbackTargetIdentity]()
    )
    arguments_dict: dict[str, Any] = Field(default_factory=dict)
    materialized_prompt: str
    user_distribution: OutputDistribution | None = None
    user_distribution_reasoning: str | None = None
    user_distribution_reasoning_citations: list[InlineCitation] = Field(
        default_factory=lambda: list[InlineCitation]()
    )
    questions: list["FeedbackQuestionWithAnswer"] = Field(
        default_factory=lambda: list[FeedbackQuestionWithAnswer]()
    )
    label_target: FeedbackLabelTarget


class FeedbackQuestionGroup(BaseModel):
    """Hydrated high-level question plus its representative invocations."""

    high_level_question: FeedbackQuestionWithAnswer
    representative_invocations: list[FeedbackRepresentativeInvocationPrompt] = Field(
        default_factory=lambda: list[FeedbackRepresentativeInvocationPrompt]()
    )


class FeedbackRound(BaseModel):
    """Round-scoped feedback payload returned by the REST API."""

    feedback_session_id: str
    round_index: int
    groups: list[FeedbackQuestionGroup] = Field(
        default_factory=lambda: list[FeedbackQuestionGroup]()
    )


FeedbackJobStatus = Literal["pending", "running", "cancelling", "canceled", "completed"]


class StartFeedbackRoundJobResponse(BaseModel):
    """Response for enqueueing or reusing a feedback round-generation job."""

    job_id: str


class FeedbackRoundJobStateResponse(BaseModel):
    """Current feedback round job status and the active round payload."""

    job_id: str | None
    job_status: FeedbackJobStatus | None
    current_round: int
    round: FeedbackRound | None = None


# ============================================================================
# Stored user feedback payloads
# These models represent the actual persisted labels derived from the
# reading-backed feedback workflow.
# ============================================================================


class FeedbackLabel(BaseModel):
    """Persisted label row stored for a canonical feedback target."""

    id: str
    feedback_session_id: str
    target_key: str
    target_key_hash: str
    label_value: dict[str, Any]
    explanation: str | None = None
    created_at: datetime
    updated_at: datetime


# ============================================================================
# Rubric optimization job/result models
# These are derived evaluation payloads returned by optimization workflows,
# rather than raw user answers or mutable session state.
# ============================================================================


class RubricOptimizationMetrics(BaseModel):
    """Aggregate rubric performance on labeled feedback contexts."""

    total_labeled: int
    correct: int
    incorrect: int
    failure: int
    accuracy: float | None


class RubricOptimizationCandidate(BaseModel):
    """One rubric candidate returned by the optimization job."""

    candidate_index: int
    generation: int
    parent_candidate_index: int | None
    rubric: Rubric
    train_metrics: RubricOptimizationMetrics
    test_metrics: RubricOptimizationMetrics


class RubricOptimizationResult(BaseModel):
    """Compact completed-job payload for feedback rubric optimization."""

    feedback_session_id: str
    base_rubric: Rubric
    baseline_train_metrics: RubricOptimizationMetrics
    baseline_test_metrics: RubricOptimizationMetrics
    raw_context_count: int
    filtered_context_count: int
    contexts_with_labels: int
    contexts_with_answered_qa: int
    train_labeled_count: int
    train_qa_only_count: int
    test_labeled_count: int
    rubrics: list[RubricOptimizationCandidate] = Field(
        default_factory=lambda: list[RubricOptimizationCandidate]()
    )


class StartFeedbackRubricOptimizationJobResponse(BaseModel):
    """Response for enqueueing or reusing a feedback rubric optimization job."""

    job_id: str


class FeedbackRubricOptimizationJobStateResponse(BaseModel):
    """Current feedback rubric optimization job status and result payload."""

    job_id: str | None
    job_status: FeedbackJobStatus | None
    result: RubricOptimizationResult | None = None


# ============================================================================
