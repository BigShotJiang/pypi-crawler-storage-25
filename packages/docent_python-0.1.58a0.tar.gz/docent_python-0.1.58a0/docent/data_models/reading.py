from datetime import datetime
from typing import Any, Literal, TypeAlias
from uuid import uuid4

from pydantic import BaseModel, Field

from docent._llm_util.providers.preference_types import ModelOption

# ── Shared building blocks ──────────────────────────────────────────


ReadingParamType = Literal[
    "agent_run", "transcript", "transcript_slice", "reading_result", "text", "unknown"
]
AnnotatableReadingParamType = Literal[
    "agent_run", "transcript", "transcript_slice", "reading_result", "text"
]


class ReadingParamPlaceholder(BaseModel):
    param_name: str
    param_type: ReadingParamType
    is_list: bool = False


ReadingTemplateSegment = str | ReadingParamPlaceholder


"""Controls caching granularity when submitting a reading step.

Reading identity is determined by a content hash. For template readings this covers the
prompt template, model config, output schema, and the resolved DQL arguments (the DQL
query is always executed regardless of cache mode). For scripted readings it covers the
prompt segments, model config, output schema, and user-supplied arguments.

- ``"reading"``: reuse an existing reading with the same content hash and its cached
  results (by cache key hash). If a match is found, no new records are created.
- ``"results"``: always create a new reading record, but still reuse cached results when
  a matching cache key hash is found (avoids redundant LLM calls).
- ``"none"``: no caching — always create a new reading and new results, forcing full
  re-evaluation.
"""
ReadingCacheMode = Literal["reading", "results", "none"]


class ContextFilterSection(BaseModel):
    mode: Literal["include", "exclude"] = "include"
    patterns: list[str] = Field(default_factory=list)


class ParameterContextConfig(BaseModel):
    transcript_metadata: ContextFilterSection | None = None
    message_metadata: ContextFilterSection | None = None
    agent_run_metadata: ContextFilterSection | None = None
    transcript_names: ContextFilterSection | None = None


class ReadingConfig(BaseModel):
    """Canonical reading configuration — the fields that determine config_hash."""

    prompt_template_segments: list[ReadingTemplateSegment]
    context_config: dict[str, ParameterContextConfig] = Field(default_factory=dict)
    model: ModelOption
    output_schema: dict[str, Any]
    max_new_tokens: int | None = None


# ── Reading presets ─────────────────────────────────────────────────


class ReadingPreset(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    collection_id: str
    name: str
    created_at: datetime | None = None
    updated_at: datetime | None = None


class ReadingPresetVersion(BaseModel):
    reading_preset_id: str
    config_hash: str
    version_index: int
    prompt_template_segments: list[ReadingTemplateSegment]
    context_config: dict[str, ParameterContextConfig] = Field(default_factory=dict)
    model: ModelOption
    output_schema: dict[str, Any]
    max_new_tokens: int | None = None
    created_at: datetime | None = None


# ── Core reading / result domain models ─────────────────────────────


class Reading(BaseModel):
    """
    Attributes:
        content_hash: represents the full identity including resolved arguments, used to deduplicate readings
        config_hash: doesn't depend on arguments, used to determine if a reading matches a preset
        is_template: whether the reading is a template or an scripted request
        prompt_template_segments: None for scripted readings
        context_config: None for scripted readings
        dql_query: None for scripted readings
        source_reading_preset_id: preset this reading was created from (config may not match exactly if user made changes)
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    collection_id: str
    content_hash: str
    config_hash: str | None = None
    is_template: bool
    prompt_template_segments: list[ReadingTemplateSegment] | None = None
    context_config: dict[str, ParameterContextConfig] | None = None
    dql_query: str | None = None
    model: ModelOption
    output_schema: dict[str, Any]
    max_new_tokens: int | None = None
    user_metadata: dict[str, Any] | None = None
    source_reading_preset_id: str | None = None
    created_at: datetime | None = None


class ReadingResult(BaseModel):
    """
    This is created before the LLM call is made, so most attributes start out as None.

    Attributes:
        cache_key_hash: before calling the LLM, we look for an existing result with the same cache_key_hash; if one exists, we reuse it and link it
        arguments_dict: arguments filled into template slots; for scripted readings this is user-supplied
        prompt_segments: None for template readings
        llm_context_spec: None for template readings
        created_at: set by DB, None until then
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    cache_key_hash: str
    arguments_dict: dict[str, Any] = Field(default_factory=dict)
    prompt_segments: list[Any] | None = None
    llm_context_spec: dict[str, Any] | None = None
    output: dict[str, Any] | None = None
    error: dict[str, Any] | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    item_token_estimates: dict[str, int] | None = None
    created_at: datetime | None = None


# ── Plan steps (persisted in ReadingPlan) ────────────────────────────


class BeginGroupStep(BaseModel):
    type: Literal["begin_step_group"] = "begin_step_group"
    alias: str
    label: str
    submitted_at: datetime | None = None


class EndGroupStep(BaseModel):
    type: Literal["end_step_group"] = "end_step_group"
    alias: str
    submitted_at: datetime | None = None


class DqlOnlyStep(BaseModel):
    type: Literal["dql_only"] = "dql_only"
    alias: str
    name: str | None = None
    dql_query: str
    submitted_at: datetime | None = None


class ReadingStep(BaseModel):
    type: Literal["reading"] = "reading"
    alias: str
    name: str | None = None
    reading_id: str | None = None
    dql_query: str | None = None
    prompt_template_segments: list[Any] | None = None
    context_config: dict[str, Any] | None = None
    model: ModelOption
    output_schema: dict[str, Any]
    max_new_tokens: int | None = None
    user_metadata: dict[str, Any] | None = None
    source_reading_preset_id: str | None = None
    cache_mode: ReadingCacheMode = "reading"
    approved_at: datetime | None = None
    submitted_at: datetime | None = None

    def to_submission(self, *, dql_query: str | None = None) -> "ReadingStepSubmission":
        """Convert to a ReadingStepSubmission for resolve_reading_entry.

        Optionally overrides dql_query (e.g. after alias substitution).
        """
        return ReadingStepSubmission(
            alias=self.alias,
            name=self.name,
            model=self.model,
            output_schema=self.output_schema,
            max_new_tokens=self.max_new_tokens,
            user_metadata=self.user_metadata,
            prompt_template_segments=self.prompt_template_segments,
            context_config=self.context_config,
            dql_query=dql_query if dql_query is not None else self.dql_query,
            source_reading_preset_id=self.source_reading_preset_id,
            cache_mode=self.cache_mode,
        )


PlanStep: TypeAlias = BeginGroupStep | EndGroupStep | DqlOnlyStep | ReadingStep


class ReadingPlan(BaseModel):
    """A plan is an ordered list of reading steps.

    Each step is a discriminated union (PlanStep) with a "type" field:
      - "step_group" / "end_step_group": visual grouping markers
      - "reading": an LLM reading step (has alias, reading_id once resolved, etc.)
      - "dql_only": a query-only step with no LLM call

    reading_id is backfilled on each reading step once the step is resolved.
    Dependent steps (whose DQL references $alias of an upstream step) start
    with reading_id=null and are resolved by the plan worker at execution time.
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    collection_id: str
    name: str | None = None
    steps: list[PlanStep] = Field(default_factory=list)  # type: ignore[reportUnknownVariableType]
    created_at: datetime | None = None
    updated_at: datetime | None = None


# ── Submission format (SDK → server) ───────────────────────────────


class ScriptedRequest(BaseModel):
    """A single LLM request in a scripted reading.
    Attributes:
        arguments_dict: optional user-supplied metadata, stored on the result and included in the cache key but not used to resolve any template parameters."""

    prompt_segments: list[Any]
    arguments_dict: dict[str, Any] = Field(default_factory=dict)
    llm_context_spec: dict[str, Any]


class StepGroupSubmission(BaseModel):
    entry_type: Literal["step_group"] = "step_group"
    alias: str
    label: str


class EndStepGroupSubmission(BaseModel):
    entry_type: Literal["end_step_group"] = "end_step_group"
    alias: str


class ReadingStepSubmission(BaseModel):
    entry_type: Literal["reading"] = "reading"
    alias: str
    name: str | None = None
    model: ModelOption
    output_schema: dict[str, Any] | None = None
    max_new_tokens: int | None = None
    user_metadata: dict[str, Any] | None = None
    source_reading_preset_id: str | None = None
    cache_mode: ReadingCacheMode = "reading"

    # Template reading fields (mutually exclusive with requests)
    prompt_template_segments: list[Any] | None = None
    context_config: dict[str, ParameterContextConfig] | None = None
    dql_query: str | None = None

    # Scripted reading fields (mutually exclusive with template fields)
    requests: list[ScriptedRequest] | None = None


class PresetReadingStepSubmission(BaseModel):
    entry_type: Literal["preset_reading"] = "preset_reading"
    alias: str
    name: str | None = None
    source_reading_preset_id: str
    user_metadata: dict[str, Any] | None = None
    dql_query: str | None = None
    cache_mode: ReadingCacheMode = "reading"


class DqlOnlyStepSubmission(BaseModel):
    entry_type: Literal["dql_only"] = "dql_only"
    alias: str
    name: str | None = None
    dql_query: str


PlanStepSubmission = (
    StepGroupSubmission
    | EndStepGroupSubmission
    | ReadingStepSubmission
    | PresetReadingStepSubmission
    | DqlOnlyStepSubmission
)


class PlanSubmissionRequest(BaseModel):
    plan_id: str | None = None
    plan_name: str | None = None
    source_script: str | None = None
    entries: list[PlanStepSubmission]


class PlanStepSubmissionStatus(BaseModel):
    alias: str
    status: Literal["cached", "needs_approval", "unresolved"]
    reading_id: str | None = None


class PlanSubmissionResponse(BaseModel):
    plan_id: str
    entry_statuses: list[PlanStepSubmissionStatus]


__all__ = [
    "AnnotatableReadingParamType",
    "BeginGroupStep",
    "ContextFilterSection",
    "DqlOnlyStep",
    "DqlOnlyStepSubmission",
    "EndGroupStep",
    "EndStepGroupSubmission",
    "ScriptedRequest",
    "ParameterContextConfig",
    "PlanStep",
    "PlanStepSubmission",
    "PlanStepSubmissionStatus",
    "PlanSubmissionRequest",
    "PlanSubmissionResponse",
    "ReadingCacheMode",
    "ReadingParamPlaceholder",
    "ReadingParamType",
    "ReadingStep",
    "ReadingStepSubmission",
    "ReadingTemplateSegment",
    "Reading",
    "ReadingConfig",
    "ReadingPlan",
    "ReadingPreset",
    "ReadingPresetVersion",
    "ReadingResult",
    "StepGroupSubmission",
    "PresetReadingStepSubmission",
]
