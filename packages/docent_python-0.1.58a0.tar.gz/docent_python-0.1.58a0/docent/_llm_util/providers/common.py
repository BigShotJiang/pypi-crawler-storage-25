import asyncio
import json
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Awaitable, Callable, Literal, cast

import backoff
from backoff.types import Details

ReasoningEffort = Literal["minimal", "low", "medium", "high"]


@asynccontextmanager
async def async_timeout_ctx(timeout: float | None) -> AsyncIterator[None]:
    if timeout:
        async with asyncio.timeout(timeout):
            yield
    else:
        # No-op async contextmanager
        yield


def reasoning_budget(max_new_tokens: int, effort: ReasoningEffort) -> int:
    if effort == "high":
        ratio = 0.75
    elif effort == "medium":
        ratio = 0.5
    elif effort == "low":
        ratio = 0.25
    else:
        ratio = 0.1
    return int(max_new_tokens * ratio)


def coerce_tool_args(args: Any) -> dict[str, Any]:
    if isinstance(args, dict):
        return cast(dict[str, Any], args)
    if isinstance(args, str):
        try:
            loaded = json.loads(args)
            return (
                cast(dict[str, Any], loaded)
                if isinstance(loaded, dict)
                else {"__parse_error_raw_args": args}
            )
        except Exception:
            return {"__parse_error_raw_args": args}
    # Fallback: unknown structure
    return {"__parse_error_raw_args": str(args)}


async def retry_async(
    func: Callable[[], Awaitable[Any]],
    *,
    max_retries: int,
    is_retryable_error: Callable[[BaseException], bool],
    factor: float,
    on_backoff: Callable[[Details], None] | None = None,
) -> Any:
    if max_retries < 0:
        raise ValueError("max_retries must be non-negative")

    decorated = backoff.on_exception(
        backoff.expo,
        exception=(Exception,),
        giveup=lambda e: not is_retryable_error(e),
        max_tries=max_retries + 1,
        factor=factor,
        on_backoff=on_backoff,
    )(func)
    return await decorated()
