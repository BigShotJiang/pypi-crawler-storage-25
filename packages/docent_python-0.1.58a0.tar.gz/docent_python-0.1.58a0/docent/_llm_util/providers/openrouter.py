"""OpenRouter provider implementation built on the OpenAI SDK."""

import os
from collections.abc import Mapping
from typing import Literal, cast

from openai import AsyncOpenAI, AuthenticationError, BadRequestError

from docent._llm_util.data_models.exceptions import ContextWindowException
from docent._llm_util.data_models.llm_output import (
    AsyncSingleLLMOutputStreamingCallback,
    LLMOutput,
)
from docent._llm_util.providers.common import ReasoningEffort
from docent._llm_util.providers.openai import (
    get_openai_chat_completion_async,
    get_openai_chat_completion_streaming_async,
)
from docent.data_models.chat import ChatMessage, ToolInfo
from docent.data_models.chat.response_format import ResponseFormat

OPENROUTER_API_BASE = "https://openrouter.ai/api/v1"
_OPENROUTER_CONTEXT_ERROR_SUBSTRINGS = (
    "context limit",
    "context length",
    "context window",
)


def get_openrouter_client_async(api_key: str | None = None) -> AsyncOpenAI:
    resolved_api_key = api_key if api_key is not None else os.getenv("OPENROUTER_API_KEY")
    # Pass an empty string when no OpenRouter key is configured so the OpenAI SDK
    # does not silently inherit OPENAI_API_KEY for OpenRouter requests.
    return AsyncOpenAI(api_key=resolved_api_key or "", base_url=OPENROUTER_API_BASE)


def _build_openrouter_extra_body(
    reasoning_effort: ReasoningEffort | None,
) -> dict[str, dict[str, ReasoningEffort]] | None:
    if reasoning_effort is None:
        return None
    return {"reasoning": {"effort": reasoning_effort}}


def _convert_openrouter_error(e: BadRequestError) -> ContextWindowException | None:
    error_text_parts = [e.message]
    raw_body: object = e.body
    if isinstance(raw_body, Mapping):
        error_body = cast(Mapping[str, object], raw_body)
        error_text_parts.extend(
            str(error_body[key]) for key in ("message", "detail", "error") if key in error_body
        )
    elif isinstance(raw_body, str):
        error_text_parts.append(raw_body)

    error_message = " ".join(error_text_parts).lower()
    if e.status_code == 400 and any(
        substring in error_message for substring in _OPENROUTER_CONTEXT_ERROR_SUBSTRINGS
    ):
        return ContextWindowException()
    return None


async def get_openrouter_chat_completion_async(
    client: AsyncOpenAI,
    messages: list[ChatMessage],
    model_name: str,
    *,
    tools: list[ToolInfo] | None = None,
    tool_choice: Literal["auto", "required"] | None = None,
    max_new_tokens: int = 32,
    temperature: float = 1.0,
    reasoning_effort: ReasoningEffort | None = None,
    logprobs: bool = False,
    top_logprobs: int | None = None,
    timeout: float = 30.0,
    response_format: ResponseFormat | None = None,
    max_retries: int = 1,
) -> LLMOutput:
    try:
        # OpenRouter sometimes reports context overflows via 400 message text rather
        # than the OpenAI-specific `context_length_exceeded` code.
        return await get_openai_chat_completion_async(
            client=client,
            messages=messages,
            model_name=model_name,
            tools=tools,
            tool_choice=tool_choice,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            reasoning_effort=None,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            timeout=timeout,
            response_format=response_format,
            extra_body=_build_openrouter_extra_body(reasoning_effort),
            max_retries=max_retries,
        )
    except BadRequestError as e:
        if e2 := _convert_openrouter_error(e):
            raise e2 from e
        raise


async def get_openrouter_chat_completion_streaming_async(
    client: AsyncOpenAI,
    streaming_callback: AsyncSingleLLMOutputStreamingCallback | None,
    messages: list[ChatMessage],
    model_name: str,
    *,
    tools: list[ToolInfo] | None = None,
    tool_choice: Literal["auto", "required"] | None = None,
    max_new_tokens: int = 32,
    temperature: float = 1.0,
    reasoning_effort: ReasoningEffort | None = None,
    logprobs: bool = False,
    top_logprobs: int | None = None,
    timeout: float = 30.0,
    response_format: ResponseFormat | None = None,
    max_retries: int = 1,
) -> LLMOutput:
    try:
        return await get_openai_chat_completion_streaming_async(
            client=client,
            streaming_callback=streaming_callback,
            messages=messages,
            model_name=model_name,
            tools=tools,
            tool_choice=tool_choice,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            reasoning_effort=None,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            timeout=timeout,
            response_format=response_format,
            extra_body=_build_openrouter_extra_body(reasoning_effort),
            max_retries=max_retries,
        )
    except BadRequestError as e:
        if e2 := _convert_openrouter_error(e):
            raise e2 from e
        raise


async def is_openrouter_api_key_valid(api_key: str) -> bool:
    """Test whether an OpenRouter API key is valid."""
    client = get_openrouter_client_async(api_key=api_key)

    try:
        await client.chat.completions.create(
            model="openai/gpt-5-nano",
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=1,
        )
        return True
    except AuthenticationError:
        return False
    except Exception:
        return True
