"""Output helpers — clean prefixed text, no panels/boxes."""

from __future__ import annotations

from rich.console import Console

from aethis_cli.errors import AethisAPIError

console = Console()


def error_panel(e: AethisAPIError) -> None:
    """Render an API error as a single line."""
    console.print(f"[red]Error: {e.detail} (HTTP {e.status_code})[/red]", highlight=False)
    if e.status_code == 401:
        console.print("[dim]Run 'aethis login' to re-authenticate.[/dim]")


def success(msg: str) -> None:
    console.print(f"[green]✓[/green] {msg}")


def info(msg: str) -> None:
    console.print(f"[dim]→[/dim] {msg}")


def warn(msg: str) -> None:
    console.print(f"[yellow]![/yellow] {msg}")
