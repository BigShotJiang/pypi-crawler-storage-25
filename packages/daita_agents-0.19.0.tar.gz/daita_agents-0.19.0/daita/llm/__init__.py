"""
LLM provider integrations for Daita Agents.

This module provides a unified interface for different LLM providers:
- OpenAI (GPT-5.4 mini, GPT-5.5, etc.)
- Anthropic (Claude models)
- Google Gemini
- xAI Grok
- Mock provider for testing

The factory pattern allows easy switching between providers while maintaining
a consistent interface for agents.

Usage:
    ```python
    from daita.llm import create_llm_provider

    # Create OpenAI provider
    llm = create_llm_provider("openai", "gpt-5.4-mini", api_key="sk-...")
    response = await llm.generate("Hello, world!")

    # Create Anthropic provider
    llm = create_llm_provider("anthropic", "claude-haiku-4-5")
    response = await llm.generate("Analyze this data...")
    ```
"""

# Factory and registry functions
from .factory import (
    create_llm_provider,
    register_llm_provider,
    list_available_providers,
)

# Base class for custom providers
from .base import BaseLLMProvider
from .pricing import CostEstimate, ModelPricing, TokenUsage, estimate_llm_cost

# Concrete provider implementations
from .openai import OpenAIProvider
from .anthropic import AnthropicProvider
from .grok import GrokProvider
from .gemini import GeminiProvider
from .mock import MockLLMProvider

__all__ = [
    # Factory functions
    "create_llm_provider",
    "register_llm_provider",
    "list_available_providers",
    # Base class
    "BaseLLMProvider",
    "CostEstimate",
    "ModelPricing",
    "TokenUsage",
    "estimate_llm_cost",
    # Provider implementations
    "OpenAIProvider",
    "AnthropicProvider",
    "GrokProvider",
    "GeminiProvider",
    "MockLLMProvider",
]
