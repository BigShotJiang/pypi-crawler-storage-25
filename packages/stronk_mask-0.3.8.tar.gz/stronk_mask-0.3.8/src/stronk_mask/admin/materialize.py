from __future__ import annotations

import errno
import json
import re
import textwrap
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from tempfile import NamedTemporaryFile

from stronk_mask.admin.operator_state import (
    OperatorState,
    Provider,
    iter_published_aliases,
)
from stronk_mask.admin.secrets import load_env_file

CLIPROXY_PRIVATE_PORT = 8317
CLIPROXY_AUTH_DIR = Path("/var/lib/cliproxy/auth")
FORBIDDEN_ARTIFACT_TOKENS = (
    "panel-github-repository",
    "github.com/",
    "router-for-me",
    "source_repo",
    "registry_repo",
    "validated_target",
    "stronk-claw",
    "private-bundle-distribution.md",
)
ALLOWED_PRIVATE_SURFACE_POSTURES = {"private_only", "host_published", "unknown"}
SAFE_DOCTOR_CHECK_MESSAGES = {
    "cliproxy-private-surface": {
        "pass": "CLIProxyAPI remains private with no host-published ports.",
        "fail": "CLIProxyAPI appears to have a host-published port mapping.",
    },
    "cliproxy-runtime-config-path": {
        "pass": (
            "CLIProxyAPI reads config from the generated directory mount and the -config "
            "path points at the mounted file."
        ),
        "fail": (
            "CLIProxyAPI is missing the bundle .env mount, the generated directory mount, "
            "or the -config path still points at the old single-file bind mount."
        ),
    },
    "gateway-artifact-mount": {
        "pass": (
            "stronk-mask-admin mounts the config and generated bundle directories at the "
            "v2 paths."
        ),
        "fail": (
            "stronk-mask-admin is missing one or more v2 config, generated, .env, or "
            "secrets mounts."
        ),
    },
    "admin-bundle-env-access": {
        "pass": (
            "stronk-mask-admin reads the staged bundle env file so PROVIDER_* secrets and "
            "STRONK_GATEWAY_PUBLIC_API_KEY are visible at runtime."
        ),
        "fail": "stronk-mask-admin is missing bundle env access through env_file: ./.env.",
    },
    "generated-handoff-artifacts": {
        "pass": "materialization-summary.json and hermes-connect.json are present.",
        "fail": "Generated handoff artifacts are missing.",
    },
    "hermes-metadata-only": {
        "pass": "Hermes metadata artifact omits the staged public API key value.",
        "fail": "Hermes metadata artifact appears to contain the staged public API key.",
    },
    "approved-admin-access-mode": {
        "pass": "Admin access mode is inside the approved v2 set.",
        "fail": "Admin access mode is not approved for v2.",
    },
}
BUNDLE_VERSION_PATTERNS = (
    re.compile(r"^stronk-gateway\.bundle/v[0-9A-Za-z._-]+$"),
    re.compile(r"^\d{4}\.\d{2}\.\d{2}$"),
)
IMAGE_PIN_PATTERNS = {
    "stronk-mask": re.compile(
        r"^ghcr\.io/eyycheev/stronk-mask(?::[A-Za-z0-9._-]+|@sha256:[a-f0-9]{64})$"
    ),
    "cliproxyapi": re.compile(
        r"^ghcr\.io/eyycheev/stronk-cliproxyapi(?::[A-Za-z0-9._-]+|@sha256:[a-f0-9]{64})$"
    ),
}


@dataclass(frozen=True)
class MaterializedFiles:
    config_path: Path
    materialization_summary_path: Path
    hermes_connect_path: Path
    doctor_report_path: Path


def now_iso() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def derive_public_base_url(env_values: dict[str, str]) -> str:
    configured = env_values.get("STRONK_GATEWAY_PUBLIC_BASE_URL", "").strip()
    if configured:
        return configured.rstrip("/")
    port = env_values.get("STRONK_GATEWAY_PUBLIC_HTTP_PORT", "").strip()
    if not port:
        raise ValueError("STRONK_GATEWAY_PUBLIC_HTTP_PORT is required")
    return f"http://127.0.0.1:{port}/v1"


def compute_provider_readiness(provider: Provider, env_values: dict[str, str]) -> str:
    if not provider.secret_ref:
        return "keyless"
    if env_values.get(provider.secret_ref, "").strip():
        return "ready"
    return "needs_input"


def render_cliproxy_config(
    state: OperatorState,
    *,
    public_api_key: str,
    env_values: dict[str, str],
) -> str:
    provider_blocks: list[str] = []
    for provider in state.providers:
        model_blocks = []
        for model in provider.models:
            if not model.enabled:
                continue
            model_lines = [f'      - name: "{model.upstream_id}"']
            if model.public_alias is not None:
                model_lines.append(f'        alias: "{model.public_alias}"')
            model_blocks.append("\n".join(model_lines))
        rendered_models = "\n".join(model_blocks) if model_blocks else "      []"
        if provider.secret_ref:
            api_key_entries = (
                "    api-key-entries:\n"
                f'      - api-key-env: "{provider.secret_ref}"'
            )
        else:
            api_key_entries = "    api-key-entries: []"
        provider_blocks.append(
            "\n".join(
                [
                    f'  - name: "{provider.cliproxy_provider_name}"',
                    f'    base-url: "{provider.base_url}"',
                    api_key_entries,
                    "    models:",
                    rendered_models,
                ]
            )
        )
    rendered_providers = "\n".join(provider_blocks) if provider_blocks else "  []"
    base_config = textwrap.dedent(
        f"""
        host: "0.0.0.0"
        port: {CLIPROXY_PRIVATE_PORT}
        remote-management:
          allow-remote: false
          secret-key: ""
          disable-control-panel: true
        auth-dir: "{CLIPROXY_AUTH_DIR}"
        api-keys:
          - "{public_api_key}"
        debug: false
        usage-statistics-enabled: false
        openai-compatibility:
        """
    ).strip()
    config_text = f"{base_config}\n{rendered_providers}\n"
    for provider in state.providers:
        if not provider.secret_ref:
            continue
        if provider.secret_ref not in config_text:
            raise ValueError(f"generated config lost secret ref {provider.secret_ref}")
        secret_value = env_values.get(provider.secret_ref, "").strip()
        if secret_value and secret_value in config_text:
            raise ValueError("generated config embedded a raw provider secret")
    return config_text


def build_materialization_summary(
    state: OperatorState,
    *,
    env_values: dict[str, str],
    generated_at: str,
) -> dict[str, object]:
    providers = []
    models = []
    published_aliases = list(iter_published_aliases(state))
    for provider in state.providers:
        readiness = compute_provider_readiness(provider, env_values)
        provider_aliases = []
        for model in provider.models:
            if model.enabled and model.public_alias is not None:
                provider_aliases.append(model.public_alias)
            models.append(
                {
                    "provider_id": provider.id,
                    "provider_label": provider.label,
                    "upstream_id": model.upstream_id,
                    "public_alias": model.public_alias,
                    "privacy_policy_id": model.privacy_policy_id,
                    "enabled": model.enabled,
                    "readiness_posture": readiness,
                }
            )
        providers.append(
            {
                "id": provider.id,
                "label": provider.label,
                "kind": provider.kind,
                "base_url": provider.base_url,
                "secret_ref": provider.secret_ref or None,
                "cliproxy_provider_name": provider.cliproxy_provider_name,
                "readiness_posture": readiness,
                "model_count": len(provider.models),
                "published_model_aliases": provider_aliases,
            }
        )
    return {
        "schema_version": state.schema_version,
        "generated_at": generated_at,
        "provider_count": len(state.providers),
        "published_model_count": len(published_aliases),
        "published_model_aliases": published_aliases,
        "providers": providers,
        "models": models,
    }


def build_hermes_connect(state: OperatorState, *, public_base_url: str) -> dict[str, object]:
    published_aliases = list(iter_published_aliases(state))
    return {
        "schema_version": state.schema_version,
        "public_base_url": public_base_url,
        "recommended_model_aliases": published_aliases,
        "credential_flow": "cli_only",
        "providers": [
            {
                "id": provider.id,
                "label": provider.label,
                "cliproxy_provider_name": provider.cliproxy_provider_name,
            }
            for provider in state.providers
        ],
        "copy_snippets": [
            {
                "label": f"Hermes custom provider ({alias})",
                "snippet": "\n".join(
                    [
                        f'OPENAI_BASE_URL="{public_base_url}"',
                        f'OPENAI_MODEL="{alias}"',
                        "OPENAI_API_KEY=<stage-public-api-key>",
                    ]
                ),
            }
            for alias in published_aliases
        ],
    }


def build_doctor_report(
    state: OperatorState,
    *,
    env_values: dict[str, str],
    generated_dir: Path,
    previous_doctor_report: dict[str, object] | None = None,
) -> dict[str, object]:
    raw_previous = previous_doctor_report
    if raw_previous is None:
        raw_previous = _load_previous_doctor_report(generated_dir / "doctor-report.json")
    previous = _sanitize_previous_doctor_report(raw_previous)
    return {
        "schema_version": state.schema_version,
        "generated_at": now_iso(),
        "checks": previous.get("checks", []),
        "private_surface_posture": previous.get("private_surface_posture", "private_only"),
        "bundle_version": previous.get("bundle_version"),
        "image_pins": previous.get("image_pins", {}),
        "providers": [
            {
                "id": provider.id,
                "label": provider.label,
                "kind": provider.kind,
                "readiness_posture": compute_provider_readiness(provider, env_values),
                "published_model_aliases": [
                    model.public_alias
                    for model in provider.models
                    if model.enabled and model.public_alias is not None
                ],
            }
            for provider in state.providers
        ],
    }


def materialize_bundle(
    *,
    state: OperatorState,
    bundle_env_path: Path,
    generated_dir: Path,
    previous_doctor_report: dict[str, object] | None = None,
) -> MaterializedFiles:
    env_values = load_env_file(bundle_env_path)
    public_api_key = env_values.get("STRONK_GATEWAY_PUBLIC_API_KEY", "").strip()
    if not public_api_key:
        raise ValueError("STRONK_GATEWAY_PUBLIC_API_KEY is required for materialization")
    generated_dir.mkdir(parents=True, exist_ok=True)
    config_path = generated_dir / "cliproxy-config.yaml"
    summary_path = generated_dir / "materialization-summary.json"
    hermes_path = generated_dir / "hermes-connect.json"
    doctor_path = generated_dir / "doctor-report.json"

    rendered = render_cliproxy_config(
        state,
        public_api_key=public_api_key,
        env_values=env_values,
    )
    generated_at = now_iso()
    materialization_summary = build_materialization_summary(
        state,
        env_values=env_values,
        generated_at=generated_at,
    )
    hermes = build_hermes_connect(
        state,
        public_base_url=derive_public_base_url(env_values),
    )
    doctor = build_doctor_report(
        state,
        env_values=env_values,
        generated_dir=generated_dir,
        previous_doctor_report=previous_doctor_report,
    )

    _atomic_write_text(config_path, rendered)
    _atomic_write_json(summary_path, materialization_summary)
    _atomic_write_json(hermes_path, hermes)
    _atomic_write_json(doctor_path, doctor)
    return MaterializedFiles(
        config_path=config_path,
        materialization_summary_path=summary_path,
        hermes_connect_path=hermes_path,
        doctor_report_path=doctor_path,
    )


def _load_previous_doctor_report(path: Path) -> dict[str, object]:
    if not path.exists():
        return {}
    raw = json.loads(path.read_text(encoding="utf-8"))
    return raw if isinstance(raw, dict) else {}


def _sanitize_previous_doctor_report(raw: dict[str, object]) -> dict[str, object]:
    private_surface_posture = raw.get("private_surface_posture")
    if private_surface_posture not in ALLOWED_PRIVATE_SURFACE_POSTURES:
        private_surface_posture = "private_only"

    checks: list[dict[str, str | None]] = []
    raw_checks = raw.get("checks")
    if isinstance(raw_checks, list):
        for item in raw_checks:
            safe_check = _sanitize_previous_doctor_check(item)
            if safe_check is not None:
                checks.append(safe_check)

    image_pins: dict[str, str] = {}
    raw_image_pins = raw.get("image_pins")
    if isinstance(raw_image_pins, dict):
        for raw_key, raw_value in raw_image_pins.items():
            if not isinstance(raw_key, str) or not isinstance(raw_value, str):
                continue
            pin_pattern = IMAGE_PIN_PATTERNS.get(raw_key)
            if pin_pattern is None or not pin_pattern.fullmatch(raw_value):
                continue
            image_pins[raw_key] = raw_value

    bundle_version = raw.get("bundle_version")
    if not isinstance(bundle_version, str) or not _is_allowed_bundle_version(bundle_version):
        bundle_version = None

    return {
        "checks": checks,
        "private_surface_posture": private_surface_posture,
        "bundle_version": bundle_version,
        "image_pins": image_pins,
    }


def _sanitize_previous_doctor_check(item: object) -> dict[str, str | None] | None:
    if not isinstance(item, dict):
        return None
    name = item.get("name")
    status = item.get("status")
    if not isinstance(name, str) or not isinstance(status, str):
        return None
    safe_messages = SAFE_DOCTOR_CHECK_MESSAGES.get(name)
    normalized_status = status.strip().lower()
    if safe_messages is None or normalized_status not in safe_messages:
        return None
    return {
        "name": name,
        "status": normalized_status,
        "message": safe_messages[normalized_status],
        "evidence_ref": None,
    }


def _contains_forbidden_artifact_token(value: str) -> bool:
    return any(token in value for token in FORBIDDEN_ARTIFACT_TOKENS)


def _is_allowed_bundle_version(value: str) -> bool:
    if _contains_forbidden_artifact_token(value):
        return False
    return any(pattern.fullmatch(value) for pattern in BUNDLE_VERSION_PATTERNS)


def _atomic_write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile(
        "w",
        encoding="utf-8",
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        delete=False,
    ) as handle:
        handle.write(value)
        temp_path = Path(handle.name)
    try:
        temp_path.replace(path)
    except OSError as exc:
        if exc.errno not in {errno.EBUSY, errno.EXDEV}:
            raise
        path.write_text(value, encoding="utf-8")
    finally:
        temp_path.unlink(missing_ok=True)


def _atomic_write_json(path: Path, payload: dict[str, object]) -> None:
    _atomic_write_text(path, json.dumps(payload, indent=2) + "\n")
