"""
API module for the Local Flight Map application.
Provides interfaces for various flight data sources and their configuration.
"""

from typing import NamedTuple

from .adsbexchange import AdsbExchangeClient, AdsbExchangeConfig
from .adsbexchange.feed import AdsbExchangeFeederClient, AdsbExchangeFeederConfig
from .base import BBox, Location
from .hexdb import HexDbClient, HexDbConfig
from .jetphotos import JetPhotosClient, JetPhotosConfig
from .opensky import OpenSkyClient, OpenSkyConfig


class ApiConfig(OpenSkyConfig, HexDbConfig, AdsbExchangeConfig, AdsbExchangeFeederConfig, JetPhotosConfig):
    """
    Combined configuration class for all API clients.
    Inherits configuration from OpenSky, HexDB, and ADSBExchange.
    """


class ApiClients(NamedTuple):
    """
    Combined API client that provides access to multiple flight data sources.
    """

    opensky_client: OpenSkyClient
    hexdb_client: HexDbClient
    jetphotos_client: JetPhotosClient
    adsbexchange_client: AdsbExchangeClient
    adsbexchange_feed_client: AdsbExchangeFeederClient


__all__ = [
    "ApiConfig",
    "ApiClients",
    "OpenSkyClient",
    "OpenSkyConfig",
    "HexDbClient",
    "HexDbConfig",
    "AdsbExchangeClient",
    "AdsbExchangeConfig",
    "AdsbExchangeFeederClient",
    "AdsbExchangeFeederConfig",
    "BBox",
    "Location",
    "JetPhotosClient",
    "JetPhotosConfig",
]
