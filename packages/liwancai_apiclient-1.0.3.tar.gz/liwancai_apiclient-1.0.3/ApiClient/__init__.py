"""
ApiClient - 动态API客户端库

提供链式调用的动态API客户端，支持自动方法解析和路径转换。
"""

from .api_client import ApiClient, ApiProxy

__version__ = "1.0.3"
__author__ = "liwancai"
__all__ = ["ApiClient", "ApiProxy"]