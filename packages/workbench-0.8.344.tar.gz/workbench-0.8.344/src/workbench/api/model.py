"""Model: Manages AWS Model Package/Group creation and management.

Models are automatically set up and provisioned for deployment into AWS.
Models can be viewed in the AWS Sagemaker interfaces or in the Workbench
Dashboard UI, which provides additional model details and performance metrics
"""

from __future__ import annotations

# Type checking imports (avoid circular imports at runtime)
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from workbench.algorithms.dataframe.feature_space_proximity import FeatureSpaceProximity
    from workbench.algorithms.dataframe.fingerprint_proximity import FingerprintProximity
    from workbench.algorithms.models.noise_model import NoiseModel
    from workbench.algorithms.models.cleanlab_model import CleanlabModels

# Workbench Imports
from workbench.core.artifacts.artifact import Artifact
from workbench.core.artifacts.model_core import ModelCore, ModelType, ModelFramework  # noqa: F401
from workbench.core.transforms.model_to_endpoint.model_to_endpoint import ModelToEndpoint
from workbench.api.endpoint import Endpoint
from workbench.utils.model_utils import (
    proximity_model_local,
    fingerprint_prox_model_local,
    uq_model_local,
    noise_model_local,
    cleanlab_model_local,
)


class Model(ModelCore):
    """Model: Workbench Model API Class.

    Common Usage:
        ```python
        my_model = Model(name)
        my_model.details()
        my_model.to_endpoint()
        ```
    """

    def details(self, **kwargs) -> dict:
        """Retrieve the Model Details.

        Returns:
            dict: A dictionary of details about the Model
        """
        return super().details(**kwargs)

    def to_endpoint(
        self,
        name: str = None,
        tags: list = None,
        serverless: bool = True,
        mem_size: int = 2048,
        max_concurrency: int = 5,
        instance: str = None,
        data_capture: bool = False,
        async_endpoint: bool = False,
        min_instances: int = 0,
        max_instances: int = None,
        auto_scaling_mode: str = None,
        scale_in_idle_minutes: int = None,
        async_max_concurrent: int = 1,
    ) -> Endpoint:
        """Create an Endpoint from the Model.

        Args:
            name (str): Set the name for the endpoint. If not specified, an automatic name will be generated
            tags (list): Set the tags for the endpoint. If not specified automatic tags will be generated.
            serverless (bool): Set the endpoint to be serverless (default: True)
            mem_size (int): The memory size for the Endpoint in MB (default: 2048)
            max_concurrency (int): The maximum concurrency for the Endpoint (default: 5)
            instance (str): The instance type for Realtime Endpoints (default: None = auto-select based on model)
            data_capture (bool): Enable data capture for the Endpoint (default: False)
            async_endpoint (bool): Deploy as an async endpoint (default: False). Async
                endpoints are conceptually *batch* endpoints — support up to 60-minute
                per-invocation timeouts, use S3 for I/O, and scale 0 → max_instances →
                0 as traffic arrives and drains.
            min_instances (int): Autoscaler floor (default: 0 — scale to zero).
            max_instances (int): Autoscaler upper bound for async endpoints (default:
                None = use the 8-instance default in register_autoscaling).
            auto_scaling_mode (str): Autoscaling strategy for async endpoints.
                Defaults to "batch" (step scaling — instant jump 0 → max on traffic,
                fast drain to min when idle). Other modes may be added in the future.
            scale_in_idle_minutes (int): Batch-mode only — minutes of empty queue
                before scaling in to min_instances (default: None = register_autoscaling's
                default of 15).
            async_max_concurrent (int): MaxConcurrentInvocationsPerInstance for async
                endpoints (default: 1, suits CPU-bound predict_fn). Bump for I/O-bound
                workloads where multiple invocations can share a single instance.

        All deploy-time sizing/autoscaling args are persisted to the endpoint's
        workbench_meta so later reconstructions can see what it was deployed with.

        Returns:
            Endpoint: The Endpoint (auto-routes to the async transport when
            ``async_endpoint=True``).
        """

        # Ensure the endpoint_name is valid
        if name:
            Artifact.is_name_valid(name, delimiter="-", lower_case=False)

        # If the endpoint_name wasn't given generate it
        else:
            name = self.name.replace("_features", "") + ""
            name = Artifact.generate_valid_name(name, delimiter="-")

        # Create the Endpoint Tags
        tags = [name] if tags is None else tags

        # Create an Endpoint from the Model
        model_to_endpoint = ModelToEndpoint(
            self.name,
            name,
            serverless=serverless,
            instance=instance,
            async_endpoint=async_endpoint,
            min_instances=min_instances,
            max_instances=max_instances,
            auto_scaling_mode=auto_scaling_mode,
            scale_in_idle_minutes=scale_in_idle_minutes,
            async_max_concurrent=async_max_concurrent,
        )
        model_to_endpoint.set_output_tags(tags)
        model_to_endpoint.transform(
            mem_size=mem_size,
            max_concurrency=max_concurrency,
            data_capture=data_capture,
        )

        end = Endpoint(name)
        end.set_owner(self.get_owner())
        return end

    def prox_model(self, include_all_columns: bool = False) -> FeatureSpaceProximity:
        """Create a local Proximity Model for this Model

        Args:
            include_all_columns (bool): Include all DataFrame columns in results (default: False)

        Returns:
            FeatureSpaceProximity: A local FeatureSpaceProximity Model
        """
        return proximity_model_local(self, include_all_columns=include_all_columns)

    def fp_prox_model(
        self,
        include_all_columns: bool = False,
        radius: int = 2,
        n_bits: int = 2048,
    ) -> FingerprintProximity:
        """Create a local Fingerprint Proximity Model for this Model

        Note: FingerprintProximity auto-detects binary vs. count fingerprints from the
        fingerprint column format (comma-separated → count, otherwise binary).

        Args:
            include_all_columns (bool): Include all DataFrame columns in results (default: False)
            radius (int): Morgan fingerprint radius (default: 2)
            n_bits (int): Number of bits for the fingerprint (default: 2048)

        Returns:
            FingerprintProximity: A local FingerprintProximity Model
        """
        return fingerprint_prox_model_local(self, include_all_columns=include_all_columns, radius=radius, n_bits=n_bits)

    def uq_model(
        self,
        version: str = None,
        refresh_proximity: bool = False,
        radius: int = 2,
        n_bits: int = 2048,
    ):
        """Load this model's fitted UQ model (V0 or V1) for uncertainty-quantified inference.

        Usage:
            model = Model("my-model")
            uq = model.uq_model()                    # bundle-default version
            uq_v0 = model.uq_model(version="v0")     # original isotonic calibrator
            uq_v1 = model.uq_model(version="v1")     # proximity-augmented RF
            out = uq.predict(test_df[["smiles"]], predictions, prediction_std)

        Args:
            version (str | None): Which UQ version to load — ``"v0"`` (original
                isotonic-on-(prediction, std) calibrator) or ``"v1"`` (proximity-
                augmented RandomForest error model). If ``None``, reads
                ``hyperparameters["uq_version"]`` from the bundle and falls back
                to ``"v0"`` if not set.
            refresh_proximity (bool): V1-only. If False (default), use the
                proximity backend embedded in the model artifact at training
                time. If True, build a fresh FingerprintProximity from the
                current source FeatureSet. Ignored for V0.
            radius (int): Morgan fingerprint radius (V1 + refresh_proximity only).
            n_bits (int): Fingerprint bit width (V1 + refresh_proximity only).

        Returns:
            A ready-to-use ``UQModelV0`` or ``UQModelV1`` for inference (``.predict``).

        Raises:
            FileNotFoundError: If the requested version's artifact is not in the bundle.
        """
        return uq_model_local(
            self,
            version=version,
            refresh_proximity=refresh_proximity,
            radius=radius,
            n_bits=n_bits,
        )

    def noise_model(self) -> NoiseModel:
        """Create a local Noise Model for this Model

        Returns:
            NoiseModel: A local Noise Model
        """
        return noise_model_local(self)

    def cleanlab_model(self) -> CleanlabModels:
        """Create a CleanlabModels instance for this Model's training data.

        Returns:
            CleanlabModels: Factory providing access to CleanLearning and Datalab models. Use get_label_issues() to get
                a DataFrame with id_column, label_quality, predicted_label, given_label, is_label_issue.
        """
        return cleanlab_model_local(self)


if __name__ == "__main__":
    """Exercise the Model Class"""
    from pprint import pprint

    # Retrieve an existing Data Source
    my_model = Model("abalone-regression")
    pprint(my_model.summary())
    pprint(my_model.details())

    # Create an Endpoint from the Model (commented out for now)
    # my_endpoint = my_model.to_endpoint()
    # pprint(my_endpoint.summary())

    # Create a local Proximity Model for this Model
    prox_model = my_model.prox_model()
    print(prox_model.neighbors(3398))
