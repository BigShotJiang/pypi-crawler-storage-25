from typing_extensions import TypeVar, overload, Literal, Any, Mapping
from dataclasses import dataclass, field
import json
import os
import httpx

from typed_core.util import RateLimit
from .exc import ApiError
from .validation import validator
from .types import Response, is_ok
from .http import AuthHttpMixin, AuthHttpClient

T = TypeVar('T')
E = TypeVar('E', default=Any)
AnyT: type = Any # type: ignore

ETHERSCAN_API_URL = 'https://api.etherscan.io/v2/api'

def response_validator(type: type[T], err_type: type[E] = AnyT) -> validator[Response[T, E]]:
  return validator(Response[type, err_type])

@dataclass
class BaseMixin:
  validate: bool = True

  def should_validate(self, validate: bool | None = None) -> bool:
    return self.validate if validate is None else validate

  @overload
  def output(
    self, data: str | bytes, validator: validator[Response[T, E]], *,
    validate: bool | None, raw: Literal[False] = False
  ) -> T:
    ...
  @overload
  def output(
    self, data: str | bytes, validator: validator[Response[T, E]], *,
    validate: bool | None, raw: Literal[True]
  ) -> Response[T, E]:
    ...
  def output(
    self, data: str | bytes, validator: validator[Response[T, E]], *,
    validate: bool | None, raw: bool = False
  ):
    obj = validator(data) if self.should_validate(validate) else json.loads(data)
    if raw:
      return obj
    if not is_ok(obj):
      raise ApiError(obj)
    return obj['result']

@dataclass
class Endpoint(BaseMixin, AuthHttpMixin):
  base_url: str = field(kw_only=True, default=ETHERSCAN_API_URL)
  rate_limit: RateLimit | None = field(kw_only=True, default=None)

  async def request(self, method: str, path: str, *, content: httpx._types.RequestContent | None = None, data: httpx._types.RequestData | None = None, files: httpx._types.RequestFiles | None = None, json: Any | None = None, params: Mapping[str, Any] | None = None, headers: Mapping | None = None, cookies: httpx._types.CookieTypes | None = None, auth: httpx._types.AuthTypes | httpx._client.UseClientDefault | None = httpx.USE_CLIENT_DEFAULT, follow_redirects: bool | httpx._client.UseClientDefault = httpx.USE_CLIENT_DEFAULT, timeout: httpx._types.TimeoutTypes | httpx._client.UseClientDefault = httpx.USE_CLIENT_DEFAULT, extensions: httpx._types.RequestExtensions | None = None):
    if self.rate_limit is not None:
      await self.rate_limit.acquire()
    return await super().request(method, path, content=content, data=data, files=files, json=json, params=params, headers=headers, cookies=cookies, auth=auth, follow_redirects=follow_redirects, timeout=timeout, extensions=extensions)

  async def authed_request(self, method: str, path: str = '', *, content: httpx._types.RequestContent | None = None, data: httpx._types.RequestData | None = None, files: httpx._types.RequestFiles | None = None, json: Any | None = None, params: Mapping | None = None, headers: Mapping[str, str] | None = None, cookies: httpx._types.CookieTypes | None = None, auth: httpx._types.AuthTypes | httpx._client.UseClientDefault | None = httpx.USE_CLIENT_DEFAULT, follow_redirects: bool | httpx._client.UseClientDefault = httpx.USE_CLIENT_DEFAULT, timeout: httpx._types.TimeoutTypes | httpx._client.UseClientDefault = httpx.USE_CLIENT_DEFAULT, extensions: httpx._types.RequestExtensions | None = None):
    if self.rate_limit is not None:
      await self.rate_limit.acquire()
    return await super().authed_request(method, path, content=content, data=data, files=files, json=json, params=params, headers=headers, cookies=cookies, auth=auth, follow_redirects=follow_redirects, timeout=timeout, extensions=extensions)

  @classmethod
  def new(
    cls, api_key: str | None = None, *, rate_limit: int | None = None,
    base_url: str = ETHERSCAN_API_URL, validate: bool = True,
  ):
    if api_key is None:
      api_key = os.environ['ETHERSCAN_API_KEY']
    if rate_limit is None:
      env_val = os.environ.get('ETHERSCAN_RATE_LIMIT')
      if env_val is not None:
        rate_limit = int(env_val)
    client = AuthHttpClient(api_key=api_key)
    return cls(base_url=base_url, http=client, validate=validate)

@dataclass
class Router(Endpoint):
  def __post_init__(self):
    for field, cls in self.__annotations__.items():
      if issubclass(cls, Endpoint) or issubclass(cls, Router):
        setattr(self, field, cls(base_url=self.base_url, http=self.http, validate=self.validate))