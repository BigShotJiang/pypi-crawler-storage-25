# Typed Etherscan

> A fully typed, validated async client for the Etherscan API

**Use autocomplete instead of documentation.**

🚧 Under construction.
