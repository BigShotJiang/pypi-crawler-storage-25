"""Configuration management for codrninja."""

import os
from dataclasses import dataclass, field
from typing import Optional, Dict, Any


@dataclass
class Config:
    """Configuration for codrninja."""
    
    # Provider settings
    default_provider: str = field(default_factory=lambda: os.environ.get("CODRNINJA_PROVIDER", "ollama"))
    default_model: str = field(default_factory=lambda: os.environ.get("CODRNINJA_MODEL", "codellama"))
    
    # Ollama
    ollama_url: str = field(default_factory=lambda: os.environ.get("OLLAMA_URL", "http://localhost:11434"))
    
    # OpenAI
    openai_api_key: str = field(default_factory=lambda: os.environ.get("OPENAI_API_KEY", ""))
    
    # Anthropic
    anthropic_api_key: str = field(default_factory=lambda: os.environ.get("ANTHROPIC_API_KEY", ""))
    
    # OpenRouter
    openrouter_api_key: str = field(default_factory=lambda: os.environ.get("OPENROUTER_API_KEY", ""))
    
    # Database
    db_path: str = field(default_factory=lambda: os.path.expanduser("~/.codrninja/sessions.db"))
    
    # Prompt
    system_prompt: str = """You are an expert software engineer. You help write, review, and modify code.
When asked to create or modify files, respond with the file content in a code block.
Always specify the file path in the response.
Be concise and practical."""
    
    def get_provider_config(self, provider: Optional[str] = None) -> Dict[str, Any]:
        """Get configuration for a specific provider."""
        p = provider or self.default_provider
        
        configs = {
            "ollama": {
                "url": self.ollama_url,
                "model": self.default_model
            },
            "openai": {
                "api_key": self.openai_api_key,
                "model": self.default_model
            },
            "anthropic": {
                "api_key": self.anthropic_api_key,
                "model": self.default_model
            },
            "openrouter": {
                "api_key": self.openrouter_api_key,
                "model": self.default_model
            }
        }
        
        return configs.get(p, configs["ollama"])
    
    @classmethod
    def from_env(cls) -> "Config":
        """Create configuration from environment variables."""
        return cls()
    
    def ensure_db_dir(self):
        """Ensure database directory exists."""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
