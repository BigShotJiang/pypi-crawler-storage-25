#!/usr/bin/env python3
"""
codrninja TUI — Interactive coding assistant for humans.
Features: ASCII art, real-time autocomplete, tab completion.
"""

import json
import os
import sys
import time
import subprocess
import tty
import termios
import select
from typing import Optional, List, Dict, Any

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.status import Status
    from rich.table import Table
    from rich.text import Text
    from rich import box
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

from codrninja.core import AICode
from codrninja.agent import Agent
from codrninja.tools import ToolRegistry


# Milan's exact ASCII art for codrninja
CODRNINJA_LOGO = """
╔══════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                      ║
║   ██████╗ ██████╗ ██████╗ ██████╗ ███╗   ██╗██╗███╗   ██╗     ██╗ █████╗            ║
║  ██╔════╝██╔═══██╗██╔══██╗██╔══██╗████╗  ██║██║████╗  ██║     ██║██╔══██╗           ║
║  ██║     ██║   ██║██║  ██║██████╔╝██╔██╗ ██║██║██╔██╗ ██║     ██║███████║           ║
║  ██║     ██║   ██║██║  ██║██╔══██╗██║╚██╗██║██║██║╚██╗██║██   ██║██╔══██║           ║
║  ╚██████╗╚██████╔╝██████╔╝██║  ██║██║ ╚████║██║██║ ╚████║╚█████╔╝██║  ██║           ║
║   ╚═════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝╚═╝  ╚═══╝ ╚════╝ ╚═╝  ╚═╝           ║
║                                                                                      ║
║              AI-first coding assistant for automation                                  ║
║                                                                                      ║
╚══════════════════════════════════════════════════════════════════════════════════════╝
"""

# Slash commands with descriptions
SLASH_COMMANDS = [
    ("/clear", "Clear screen"),
    ("/commit", "Git commit changes"),
    ("/context", "Show project context"),
    ("/edit", "Edit file by replacement"),
    ("/exec", "Execute shell command"),
    ("/exit", "Exit codrninja"),
    ("/explain", "Explain code or concept"),
    ("/files", "List files in directory"),
    ("/help", "Show detailed help"),
    ("/model", "Show AI configuration"),
    ("/plan", "Plan a feature or task"),
    ("/read", "Read file with syntax highlighting"),
    ("/review", "Review code for issues"),
    ("/session", "Show session information"),
    ("/test", "Run tests"),
    ("/write", "Write to file (interactive)"),
]


class TUI:
    """Terminal User Interface with real-time autocomplete."""
    
    def __init__(self, ai: AICode, session_name: str):
        self.ai = ai
        self.session_name = session_name
        self.agent = Agent(ai, session_name)
        self.console = Console() if HAS_RICH else None
        self.tools = ToolRegistry()
        self.current_workflow = None
        
    def start(self):
        """Start the TUI."""
        if not HAS_RICH:
            self._simple_mode()
            return
        
        self._rich_mode()
    
    def _rich_mode(self):
        """Rich-powered TUI with real-time autocomplete."""
        # First run check
        config_path = os.path.expanduser("~/.config/codrninja/config.json")
        if not os.path.exists(config_path):
            self._onboarding()
        
        self._show_welcome()
        
        # Main input loop with autocomplete
        while True:
            try:
                message = self._read_input_with_autocomplete()
                
                if not message.strip():
                    continue
                
                if message.lower() in ['exit', 'quit', 'q']:
                    self._show_goodbye()
                    break
                
                if message.startswith('/'):
                    if not self._handle_command(message):
                        break
                    continue
                
                # Process as chat
                self._process_message(message)
                
            except KeyboardInterrupt:
                self.console.print("\n[dim]Interrupted. Type 'exit' to quit.[/dim]")
            except EOFError:
                break
    
    def _read_input_with_autocomplete(self) -> str:
        """Read input with real-time slash command suggestions."""
        self.console.print(f"\n[bold green]You[/bold green]", end="")
        
        buffer = []
        showing_suggestions = False
        
        # Save terminal settings
        if sys.stdin.isatty():
            old_settings = termios.tcgetattr(sys.stdin)
            tty.setcbreak(sys.stdin.fileno())
        else:
            old_settings = None
        
        try:
            while True:
                # Read single character (blocking)
                char = sys.stdin.read(1)
                if not char:
                    break
                
                # Handle special keys
                if char == '\n' or char == '\r':
                    # Enter pressed
                    if showing_suggestions:
                        self._clear_suggestions(len(buffer))
                        showing_suggestions = False
                    self.console.print()
                    return ''.join(buffer)
                
                elif char == '\t':
                    # Tab - accept first suggestion
                    if showing_suggestions:
                        matches = self._get_matches(''.join(buffer))
                        if matches:
                            # Replace with matched command
                            cmd = matches[0][0]
                            self._clear_suggestions(len(buffer))
                            buffer = list(cmd + ' ')
                            showing_suggestions = False
                            # Redraw
                            self.console.print(f"\r[bold green]You[/bold green] {cmd} ", end="")
                    continue
                
                elif ord(char) == 127 or ord(char) == 8:
                    # Backspace
                    if buffer:
                        buffer.pop()
                        self.console.print("\b \b", end="")
                        if showing_suggestions:
                            self._clear_suggestions(len(buffer) + 1)
                            showing_suggestions = False
                
                elif ord(char) == 3:
                    # Ctrl+C
                    raise KeyboardInterrupt
                
                elif ord(char) == 4:
                    # Ctrl+D
                    raise EOFError
                
                elif ord(char) == 27:
                    # Escape sequence (arrow keys, etc) - just discard
                    # Try to read the rest non-blocking
                    try:
                        import select as sel
                        ready, _, _ = sel.select([sys.stdin], [], [], 0.05)
                        if ready:
                            next_char = sys.stdin.read(1)
                            if next_char == '[':
                                ready2, _, _ = sel.select([sys.stdin], [], [], 0.05)
                                if ready2:
                                    sys.stdin.read(1)
                    except:
                        pass
                    continue
                
                elif char.isprintable():
                    # Regular character
                    buffer.append(char)
                    self.console.print(char, end="")
                    
                    # Check if we should show suggestions
                    current = ''.join(buffer)
                    if current.startswith('/'):
                        matches = self._get_matches(current)
                        if matches and len(current) >= 1:
                            if showing_suggestions:
                                self._clear_suggestions(len(buffer) - 1)
                            self._show_suggestions(matches, current)
                            showing_suggestions = True
                        elif showing_suggestions:
                            self._clear_suggestions(len(buffer))
                            showing_suggestions = False
        
        finally:
            # Restore terminal settings
            if old_settings:
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
    
    def _get_matches(self, current: str) -> List[tuple]:
        """Get matching slash commands."""
        if not current.startswith('/'):
            return []
        
        partial = current[1:]  # Remove leading /
        matches = []
        
        for cmd, desc in SLASH_COMMANDS:
            cmd_name = cmd[1:]  # Remove leading /
            if cmd_name.startswith(partial):
                matches.append((cmd, desc))
        
        return matches
    
    def _show_suggestions(self, matches: List[tuple], current: str):
        """Display command suggestions below input."""
        lines = []
        for cmd, desc in matches[:8]:  # Show max 8
            # Highlight matching part
            hl = len(current) - 1  # -1 for the /
            highlighted = f"[bold white]{cmd[:hl+1]}[/bold white][dim]{cmd[hl+1:]}[/dim]"
            lines.append(f"  {highlighted:18} {desc}")
        
        if len(matches) > 8:
            lines.append(f"  [dim]... and {len(matches) - 8} more[/dim]")
        
        self.suggestion_lines = len(lines)
        for line in lines:
            self.console.print(f"\n{line}", end="")
        # Move cursor back up
        self.console.print(f"\033[{len(lines)}A", end="")
    
    def _clear_suggestions(self, input_len: int):
        """Clear suggestion lines and redraw prompt."""
        if hasattr(self, 'suggestion_lines') and self.suggestion_lines > 0:
            # Move down to end of suggestions
            self.console.print(f"\033[{self.suggestion_lines}B", end="")
            # Clear each line
            for _ in range(self.suggestion_lines):
                self.console.print("\r\033[K", end="")
                self.console.print("\033[1A", end="")
            # Move back to input line
            self.console.print("\r", end="")
    
    def _show_welcome(self):
        """Show welcome screen with ASCII art."""
        for line in CODRNINJA_LOGO.strip().split('\n'):
            self.console.print(f"[bold cyan]{line}[/bold cyan]")
        self.console.print()
        self.console.print(f"  [dim]Session:[/dim] [bold yellow]{self.session_name}[/bold yellow]")
        self.console.print("  [dim]Type[/dim] [bold]/[/bold] [dim]for commands or start typing[/dim]")
        self.console.print()

    def _process_message(self, message: str):
        """Process user message with Rich UI."""
        with Status("[bold yellow]🤔 Thinking...[/bold yellow]", spinner="dots", console=self.console):
            result = self.agent.run(message, auto_approve=False)
        
        if not result['success']:
            self.console.print(f"\n[bold red]❌ Error:[/bold red] {result.get('error', 'Unknown error')}")
            return
        
        self._display_response(result['response'])
        
        if result.get('tool_calls', 0) > 0:
            self._show_tool_usage(result['tools_used'], result['iterations'])

    def _handle_command(self, command: str) -> bool:
        """Handle slash commands."""
        parts = command.split()
        cmd = parts[0].lower()
        
        if cmd == '/':
            return True  # Just showing suggestions
        
        if cmd == '/plan':
            self._cmd_plan(' '.join(parts[1:]) if len(parts) > 1 else None)
        elif cmd == '/build':
            self._cmd_build(' '.join(parts[1:]) if len(parts) > 1 else None)
        elif cmd == '/review':
            self._cmd_review(' '.join(parts[1:]) if len(parts) > 1 else None)
        elif cmd == '/explain':
            self._cmd_explain(' '.join(parts[1:]) if len(parts) > 1 else None)
        elif cmd == '/test':
            self._cmd_test(' '.join(parts[1:]) if len(parts) > 1 else None)
        elif cmd == '/commit':
            self._cmd_commit(' '.join(parts[1:]) if len(parts) > 1 else None)
        elif cmd == '/files':
            self._cmd_files()
        elif cmd == '/read':
            if len(parts) > 1:
                self._cmd_read(parts[1])
        elif cmd == '/write':
            if len(parts) > 1:
                self._cmd_write(parts[1])
        elif cmd == '/edit':
            if len(parts) > 1:
                self._cmd_edit(parts[1])
        elif cmd == '/exec':
            if len(parts) > 1:
                self._cmd_exec(' '.join(parts[1:]))
        elif cmd == '/context':
            self._cmd_context()
        elif cmd == '/model':
            self._cmd_model()
        elif cmd == '/session':
            self._cmd_session()
        elif cmd == '/help':
            self._show_help()
        elif cmd == '/clear':
            os.system('clear' if os.name != 'nt' else 'cls')
            self._show_welcome()
        elif cmd == '/exit':
            self._show_goodbye()
            return False
        else:
            self.console.print(f"[red]Unknown command: {cmd}. Type / for suggestions.[/red]")
        
        return True

    # === WORKFLOW COMMANDS ===
    
    def _cmd_plan(self, topic: Optional[str]):
        self.current_workflow = 'plan'
        if not topic:
            topic = self._ask("What do you want to plan?")
        self.console.print(f"\n[bold cyan]📋 PLANNING: {topic}[/bold cyan]\n")
        prompt = f"Create a detailed plan for: {topic}\n\n1. Break down into concrete steps\n2. Identify files that need to be created or modified\n3. Consider edge cases and potential issues\n4. Suggest testing approach\n\nOutput as a numbered plan with file paths."
        self._process_message(prompt)
        self.current_workflow = None
    
    def _cmd_build(self, topic: Optional[str]):
        self.current_workflow = 'build'
        if not topic:
            topic = self._ask("What do you want to build?")
        self.console.print(f"\n[bold cyan]🔨 BUILDING: {topic}[/bold cyan]\n")
        prompt = f"Implement: {topic}\n\nSteps:\n1. Check existing relevant files\n2. Create or modify files\n3. Show complete implementation\n4. Run build/test commands\n\nUse tools to read, write, edit files. Be thorough."
        self._process_message(prompt)
        self.current_workflow = None
    
    def _cmd_review(self, target: Optional[str]):
        self.current_workflow = 'review'
        if not target:
            target = self._ask("Which file or directory to review?", default=".")
        self.console.print(f"\n[bold cyan]👀 REVIEWING: {target}[/bold cyan]\n")
        result = self.tools.read_file(target)
        if not result.success:
            result = self.tools.list_files(target, depth=2)
        if result.success:
            prompt = f"Review for bugs, quality, performance, security:\n\n{result.output}"
            self._process_message(prompt)
        else:
            self.console.print(f"[red]Cannot read {target}[/red]")
        self.current_workflow = None
    
    def _cmd_explain(self, target: Optional[str]):
        self.current_workflow = 'explain'
        if not target:
            target = self._ask("What to explain?")
        self.console.print(f"\n[bold cyan]📖 EXPLAINING: {target}[/bold cyan]\n")
        if os.path.exists(target):
            result = self.tools.read_file(target)
            if result.success:
                self._process_message(f"Explain this code:\n\n{result.output}")
            else:
                self._process_message(f"Explain: {target}")
        else:
            self._process_message(f"Explain: {target}")
        self.current_workflow = None
    
    def _cmd_test(self, target: Optional[str]):
        self.current_workflow = 'test'
        if not target:
            if os.path.exists('package.json'):
                target = 'npm test'
            elif os.path.exists('pytest.ini'):
                target = 'pytest'
            elif os.path.exists('Cargo.toml'):
                target = 'cargo test'
            elif os.path.exists('go.mod'):
                target = 'go test ./...'
            else:
                target = self._ask("Test command?", default="npm test")
        self.console.print(f"\n[bold cyan]🧪 TESTING: {target}[/bold cyan]\n")
        self._cmd_exec(target)
        self.current_workflow = None
    
    def _cmd_commit(self, message: Optional[str]):
        self.current_workflow = 'commit'
        if not message:
            result = self.tools.execute_command('git diff --stat')
            if result.success:
                self.console.print("[dim]Changed files:[/dim]")
                self.console.print(result.output)
            message = self._ask("Commit message?")
        self.console.print(f"\n[bold cyan]📦 COMMITTING: {message}[/bold cyan]\n")
        self._cmd_exec('git add -A')
        self._cmd_exec(f'git commit -m "{message}"')
        self.current_workflow = None
    
    # === FILE COMMANDS ===
    
    def _cmd_files(self):
        result = self.tools.list_files(path=".", depth=2)
        if result.success:
            self.console.print(Panel(result.output, title="📁 Files", border_style="blue"))
        else:
            self.console.print(f"[red]Error: {result.error}[/red]")
    
    def _cmd_read(self, filepath: str):
        result = self.tools.read_file(filepath)
        if result.success:
            ext = os.path.splitext(filepath)[1]
            lang_map = {'.py': 'python', '.js': 'javascript', '.ts': 'typescript', '.jsx': 'javascript', '.tsx': 'typescript', '.json': 'json', '.css': 'css', '.html': 'html', '.md': 'markdown'}
            lang = lang_map.get(ext, "text")
            syntax = Syntax(result.output, lang, theme="monokai", line_numbers=True)
            self.console.print(Panel(syntax, title=f"📄 {filepath}", border_style="blue"))
        else:
            self.console.print(f"[red]Error: {result.error}[/red]")
    
    def _cmd_write(self, filepath: str):
        self.console.print(f"[dim]Enter content for {filepath} (Ctrl+D to finish):[/dim]")
        content = []
        try:
            while True:
                line = input()
                content.append(line)
        except EOFError:
            pass
        result = self.tools.write_file(filepath, '\n'.join(content))
        self.console.print(f"[green]✅ {result.output}[/green]" if result.success else f"[red]❌ Error: {result.error}[/red]")
    
    def _cmd_edit(self, filepath: str):
        result = self.tools.read_file(filepath)
        if not result.success:
            self.console.print(f"[red]Error: {result.error}[/red]")
            return
        syntax = Syntax(result.output, "text", theme="monokai", line_numbers=True)
        self.console.print(syntax)
        old_text = self._ask("Text to replace")
        new_text = self._ask("Replacement text")
        result = self.tools.edit_file(filepath, old_text, new_text)
        self.console.print(f"[green]✅ {result.output}[/green]" if result.success else f"[red]❌ Error: {result.error}[/red]")
    
    def _cmd_exec(self, command: str):
        with Status(f"[bold yellow]⚡ {command}[/bold yellow]", console=self.console):
            result = self.tools.execute_command(command)
        if result.success:
            self.console.print(Panel(result.output, title=f"⚡ {command}", border_style="green"))
        else:
            self.console.print(Panel(result.output, title=f"❌ {command}", border_style="red"))
    
    def _cmd_context(self):
        table = Table(title="Current Context", box=box.ROUNDED)
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="white")
        table.add_row("Directory", os.getcwd())
        table.add_row("Session", self.session_name)
        result = self.tools.execute_command('git branch --show-current 2>/dev/null || echo "not a git repo"')
        if result.success:
            table.add_row("Git Branch", result.output.strip())
        self.console.print(table)
    
    def _cmd_model(self):
        table = Table(title="AI Configuration", box=box.ROUNDED)
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="white")
        table.add_row("Provider", self.ai.config.default_provider)
        table.add_row("Model", self.ai.config.default_model)
        table.add_row("Ollama URL", self.ai.config.ollama_url)
        self.console.print(table)
    
    def _cmd_session(self):
        history = self.ai.get_history(self.session_name)
        if history:
            self.console.print(f"[bold]Session:[/bold] {self.session_name}")
            self.console.print(f"[dim]Messages: {len(history['messages'])}[/dim]")
        else:
            self.console.print(f"[dim]Session: {self.session_name} (new)[/dim]")
    
    # === DISPLAY ===
    
    def _display_response(self, response: str):
        parts = response.split('```')
        for i, part in enumerate(parts):
            if i % 2 == 0:
                if part.strip():
                    self.console.print(f"\n[bold blue]🤖 AI[/bold blue]:")
                    self.console.print(Markdown(part.strip()))
            else:
                lines = part.split('\n')
                lang = lines[0].strip() if lines else ""
                code = '\n'.join(lines[1:]) if lines else part
                if code.strip():
                    syntax = Syntax(code, lang or "text", theme="monokai", line_numbers=True)
                    self.console.print(syntax)
    
    def _show_tool_usage(self, tools_used: list, iterations: int):
        table = Table(title=f"Tools ({len(tools_used)} calls, {iterations} iterations)", box=box.ROUNDED)
        table.add_column("Tool", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Result", style="white")
        for tool in tools_used:
            status = "✅" if tool['success'] else "❌"
            result = tool['output'][:60] + "..." if len(tool['output']) > 60 else tool['output']
            table.add_row(tool['tool'], status, result)
        self.console.print(table)
    
    def _show_goodbye(self):
        self.console.print("\n[dim]👋 Goodbye! Happy coding![/dim]\n")
    
    def _show_help(self):
        self.console.print("\n[bold]Commands:[/bold]")
        for cmd, desc in SLASH_COMMANDS:
            self.console.print(f"  [bold cyan]{cmd:16}[/bold cyan] {desc}")
        self.console.print()
    
    def _ask(self, prompt: str, default: str = "") -> str:
        """Ask user for input."""
        if default:
            return input(f"{prompt} [{default}]: ").strip() or default
        return input(f"{prompt}: ").strip()
    
    # === ONBOARDING ===
    
    def _onboarding(self):
        """First-run setup."""
        self.console.print("\n[bold cyan]Welcome to codrninja![/bold cyan]")
        self.console.print("[dim]Let's set up your AI provider.[/dim]\n")
        
        self.console.print("[bold]Choose provider:[/bold]")
        self.console.print("  1. Ollama (local, free)")
        self.console.print("  2. OpenAI (GPT-4)")
        self.console.print("  3. Anthropic (Claude)")
        self.console.print("  4. OpenRouter (all models)")
        
        choice = input("\nEnter choice [1-4] (default: 1): ").strip() or "1"
        
        provider_map = {
            "1": ("ollama", "http://localhost:11434", "codellama"),
            "2": ("openai", None, "gpt-4"),
            "3": ("anthropic", None, "claude-3-sonnet-20240229"),
            "4": ("openrouter", None, "openai/gpt-4")
        }
        
        provider, url, model = provider_map.get(choice, provider_map["1"])
        
        if provider != "ollama":
            env_var = f"{provider.upper()}_API_KEY"
            api_key = input(f"\nEnter {provider.upper()} API key: ").strip()
            if api_key:
                os.environ[env_var] = api_key
                shell_config = ""
                if os.path.exists(os.path.expanduser("~/.zshrc")):
                    shell_config = os.path.expanduser("~/.zshrc")
                elif os.path.exists(os.path.expanduser("~/.bashrc")):
                    shell_config = os.path.expanduser("~/.bashrc")
                if shell_config:
                    with open(shell_config, "a") as f:
                        f.write(f"\n# codrninja\nexport {env_var}=\"{api_key}\"\n")
                        f.write(f'export CODRNINJA_PROVIDER="{provider}"\n')
                        f.write(f'export CODRNINJA_MODEL="{model}"\n')
                    self.console.print(f"[green]✅ Saved to {shell_config}[/green]")
        
        if provider == "ollama":
            url = input("\nOllama URL [http://localhost:11434]: ").strip() or "http://localhost:11434"
        
        config_dir = os.path.expanduser("~/.config/codrninja")
        os.makedirs(config_dir, exist_ok=True)
        config = {"provider": provider, "model": model, "ollama_url": url or "http://localhost:11434"}
        with open(f"{config_dir}/config.json", "w") as f:
            json.dump(config, f, indent=2)
        
        self.console.print(f"\n[green]✅ Config saved![/green]\n")
    
    # === SIMPLE MODE ===
    
    def _simple_mode(self):
        print("codrninja — Session: {self.session_name}")
        print("Type 'exit' to quit or '/help' for commands")
        while True:
            try:
                message = input("\nYou: ").strip()
                if not message:
                    continue
                if message.lower() in ['exit', 'quit', 'q']:
                    print("Goodbye!")
                    break
                if message.startswith('/'):
                    if message == '/exit':
                        break
                    print(f"Commands: /plan, /build, /review, /explain, /test, /commit, /files, /read, /exec, /help, /exit")
                    continue
                print("\nThinking...")
                result = self.agent.run(message, auto_approve=True)
                print(f"\nAI: {result.get('response', '')}")
            except (KeyboardInterrupt, EOFError):
                break


def main():
    if len(sys.argv) < 2:
        print("Usage: codrninja-tui <session-name>")
        sys.exit(1)
    
    session_name = sys.argv[1]
    ai = AICode()
    tui = TUI(ai, session_name)
    tui.start()


if __name__ == "__main__":
    main()
