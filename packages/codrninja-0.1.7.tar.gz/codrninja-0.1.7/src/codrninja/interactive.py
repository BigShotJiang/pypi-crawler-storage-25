"""Interactive mode for codrninja — human-friendly TUI."""

import json
import os
import sys
from typing import Optional

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.prompt import Prompt
    from rich.status import Status
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

from .core import AICode
from .tools import ToolRegistry


class InteractiveSession:
    """Interactive session for human users."""
    
    def __init__(self, ai: AICode, session_name: str):
        self.ai = ai
        self.session_name = session_name
        self.tools = ToolRegistry()
        self.console = Console() if HAS_RICH else None
        self.use_tools = True
    
    def start(self):
        """Start interactive session."""
        if HAS_RICH:
            self._rich_start()
        else:
            self._simple_start()
    
    def _rich_start(self):
        """Start with Rich TUI."""
        self.console.print(Panel.fit(
            f"[bold blue]codrninja[/bold blue] — Session: [bold]{self.session_name}[/bold]\n"
            "Type your message, or [bold]exit[/bold] to quit",
            title="Interactive Mode"
        ))
        
        while True:
            try:
                message = Prompt.ask("\n[bold green]You[/bold green]")
                
                if message.lower() in ['exit', 'quit', 'q']:
                    self.console.print("[dim]Goodbye![/dim]")
                    break
                
                if message.lower() == 'tools':
                    self._show_tools()
                    continue
                
                if message.lower().startswith('/'):
                    self._handle_command(message)
                    continue
                
                self._send_message(message)
                
            except KeyboardInterrupt:
                self.console.print("\n[dim]Interrupted. Type 'exit' to quit.[/dim]")
            except EOFError:
                break
    
    def _simple_start(self):
        """Start simple text-based mode."""
        print(f"codrninja — Session: {self.session_name}")
        print("Type your message, or 'exit' to quit")
        print("-" * 40)
        
        while True:
            try:
                message = input("\nYou: ").strip()
                
                if message.lower() in ['exit', 'quit', 'q']:
                    print("Goodbye!")
                    break
                
                if not message:
                    continue
                
                self._send_message_simple(message)
                
            except KeyboardInterrupt:
                print("\nInterrupted.")
            except EOFError:
                break
    
    def _send_message(self, message: str):
        """Send message and show response with Rich."""
        with Status("[bold yellow]Thinking...[/bold yellow]", console=self.console):
            result = self.ai.send_message(self.session_name, message)
        
        if not result.get('success'):
            self.console.print(f"[bold red]Error:[/bold red] {result.get('error')}")
            return
        
        response = result['response']
        
        # Check if response contains code blocks
        if '```' in response:
            self._render_code_response(response)
        else:
            self.console.print(f"\n[bold blue]AI[/bold blue]: {response}")
        
        # Show token usage
        tokens = result.get('tokens', {})
        self.console.print(
            f"[dim]Tokens: {tokens.get('input', 0)} in, {tokens.get('output', 0)} out[/dim]",
            style="dim"
        )
        
        # If tool mode enabled, check if AI wants to use tools
        if self.use_tools:
            self._check_for_tool_calls(response)
    
    def _send_message_simple(self, message: str):
        """Send message with simple text output."""
        print("\nThinking...")
        result = self.ai.send_message(self.session_name, message)
        
        if not result.get('success'):
            print(f"Error: {result.get('error')}")
            return
        
        response = result['response']
        print(f"\nAI: {response}")
        
        tokens = result.get('tokens', {})
        print(f"Tokens: {tokens.get('input', 0)} in, {tokens.get('output', 0)} out")
    
    def _render_code_response(self, response: str):
        """Render response with syntax highlighting."""
        parts = response.split('```')
        
        for i, part in enumerate(parts):
            if i % 2 == 0:
                # Text part
                if part.strip():
                    self.console.print(f"\n[bold blue]AI[/bold blue]: {part.strip()}")
            else:
                # Code part
                lines = part.split('\n')
                lang = lines[0].strip() if lines else ""
                code = '\n'.join(lines[1:]) if lines else part
                
                syntax = Syntax(code, lang or "text", theme="monokai", line_numbers=True)
                self.console.print(syntax)
    
    def _show_tools(self):
        """Show available tools."""
        schema = json.loads(self.tools.get_schema())
        self.console.print("\n[bold]Available Tools:[/bold]")
        for name, info in schema.items():
            self.console.print(f"  [bold]{name}[/bold]: {info['description']}")
    
    def _handle_command(self, command: str):
        """Handle special commands."""
        parts = command.split()
        cmd = parts[0].lower()
        
        if cmd == '/help':
            self.console.print("""
[bold]Commands:[/bold]
  /help         Show this help
  /tools        List available tools
  /files        List files in current directory
  /read <file> Read a file
  /exec <cmd>  Execute a command
  /model        Show current model
  /exit         Exit session
            """)
        
        elif cmd == '/files':
            result = self.tools.list_files()
            self.console.print(result.output if result.success else f"Error: {result.error}")
        
        elif cmd == '/read' and len(parts) > 1:
            result = self.tools.read_file(parts[1])
            if result.success:
                syntax = Syntax(result.output, "text", theme="monokai")
                self.console.print(syntax)
            else:
                self.console.print(f"[red]Error: {result.error}[/red]")
        
        elif cmd == '/exec' and len(parts) > 1:
            cmd_str = ' '.join(parts[1:])
            result = self.tools.execute_command(cmd_str)
            self.console.print(result.output if result.success else f"[red]Error: {result.error}[/red]")
        
        elif cmd == '/model':
            self.console.print(f"[bold]Model:[/bold] {self.ai.config.default_model}")
            self.console.print(f"[bold]Ollama:[/bold] {self.ai.config.ollama_url}")
        
        else:
            self.console.print(f"[red]Unknown command: {cmd}[/red]")
    
    def _check_for_tool_calls(self, response: str):
        """Check if AI wants to use tools (basic implementation)."""
        # This would parse structured tool requests from the AI
        # For now, just a placeholder
        pass
