"""Tool system for codrninja — allows the AI to read/write/execute."""

import json
import os
import subprocess
from dataclasses import dataclass
from typing import Dict, List, Optional, Any


@dataclass
class ToolResult:
    """Result from a tool execution."""
    success: bool
    output: str
    error: Optional[str] = None


class ToolRegistry:
    """Registry of available tools."""
    
    def __init__(self):
        self.tools = {
            "read_file": self.read_file,
            "write_file": self.write_file,
            "edit_file": self.edit_file,
            "execute_command": self.execute_command,
            "list_files": self.list_files,
            "search_files": self.search_files,
        }
    
    def call(self, name: str, **kwargs) -> ToolResult:
        """Call a tool by name."""
        if name not in self.tools:
            return ToolResult(False, "", f"Unknown tool: {name}")
        
        try:
            return self.tools[name](**kwargs)
        except Exception as e:
            return ToolResult(False, "", str(e))
    
    def read_file(self, path: str, offset: int = 0, limit: int = 100) -> ToolResult:
        """Read a file from disk."""
        try:
            with open(path, 'r') as f:
                lines = f.readlines()
            
            start = offset
            end = min(offset + limit, len(lines))
            content = ''.join(lines[start:end])
            
            if len(lines) > end:
                content += f"\n... ({len(lines) - end} more lines)"
            
            return ToolResult(True, content)
        except Exception as e:
            return ToolResult(False, "", str(e))
    
    def write_file(self, path: str, content: str) -> ToolResult:
        """Write content to a file."""
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, 'w') as f:
                f.write(content)
            return ToolResult(True, f"File written: {path}")
        except Exception as e:
            return ToolResult(False, "", str(e))
    
    def edit_file(self, path: str, old_text: str, new_text: str) -> ToolResult:
        """Edit a file by replacing text."""
        try:
            with open(path, 'r') as f:
                content = f.read()
            
            if old_text not in content:
                return ToolResult(False, "", f"Text not found in {path}")
            
            content = content.replace(old_text, new_text, 1)
            
            with open(path, 'w') as f:
                f.write(content)
            
            return ToolResult(True, f"File edited: {path}")
        except Exception as e:
            return ToolResult(False, "", str(e))
    
    def execute_command(self, command: str, cwd: Optional[str] = None) -> ToolResult:
        """Execute a shell command."""
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                cwd=cwd,
                timeout=300
            )
            
            output = result.stdout
            if result.stderr:
                output += f"\n[stderr]\n{result.stderr}"
            
            return ToolResult(
                result.returncode == 0,
                output,
                f"Exit code: {result.returncode}" if result.returncode != 0 else None
            )
        except subprocess.TimeoutExpired:
            return ToolResult(False, "", "Command timed out")
        except Exception as e:
            return ToolResult(False, "", str(e))
    
    def list_files(self, path: str = ".", depth: int = 1) -> ToolResult:
        """List files in a directory."""
        try:
            files = []
            for root, dirs, filenames in os.walk(path):
                level = root.replace(path, '').count(os.sep)
                if level <= depth:
                    indent = ' ' * 2 * level
                    files.append(f"{indent}{os.path.basename(root)}/")
                    subindent = ' ' * 2 * (level + 1)
                    for f in filenames:
                        files.append(f"{subindent}{f}")
            return ToolResult(True, '\n'.join(files))
        except Exception as e:
            return ToolResult(False, "", str(e))
    
    def search_files(self, pattern: str, path: str = ".") -> ToolResult:
        """Search for files matching a pattern."""
        try:
            import fnmatch
            matches = []
            for root, dirs, filenames in os.walk(path):
                for filename in fnmatch.filter(filenames, pattern):
                    matches.append(os.path.join(root, filename))
            return ToolResult(True, '\n'.join(matches) if matches else "No matches found")
        except Exception as e:
            return ToolResult(False, "", str(e))
    
    def get_schema(self) -> str:
        """Get JSON schema of all tools for the AI."""
        schema = {
            "read_file": {
                "description": "Read a file from disk",
                "parameters": {
                    "path": {"type": "string", "required": True},
                    "offset": {"type": "integer", "default": 0},
                    "limit": {"type": "integer", "default": 100}
                }
            },
            "write_file": {
                "description": "Write content to a file",
                "parameters": {
                    "path": {"type": "string", "required": True},
                    "content": {"type": "string", "required": True}
                }
            },
            "edit_file": {
                "description": "Edit a file by replacing text",
                "parameters": {
                    "path": {"type": "string", "required": True},
                    "old_text": {"type": "string", "required": True},
                    "new_text": {"type": "string", "required": True}
                }
            },
            "execute_command": {
                "description": "Execute a shell command",
                "parameters": {
                    "command": {"type": "string", "required": True},
                    "cwd": {"type": "string", "required": False}
                }
            },
            "list_files": {
                "description": "List files in a directory",
                "parameters": {
                    "path": {"type": "string", "default": "."},
                    "depth": {"type": "integer", "default": 1}
                }
            },
            "search_files": {
                "description": "Search for files matching a pattern",
                "parameters": {
                    "pattern": {"type": "string", "required": True},
                    "path": {"type": "string", "default": "."}
                }
            }
        }
        return json.dumps(schema, indent=2)
