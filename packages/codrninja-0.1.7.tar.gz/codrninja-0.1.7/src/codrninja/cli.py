"""Command-line interface for codrninja with dual modes."""

import json
import os
import sys
from typing import Optional

from .core import AICode
from .config import Config
from .interactive import InteractiveSession


def main():
    """Main CLI entry point — supports both human and AI modes."""
    
    # Check if running in automation mode (non-interactive, JSON output)
    automation_mode = os.environ.get('AI_CODE_MODE') == 'automation' or '--json' in sys.argv
    
    # If no args or just a session name, start the TUI
    if len(sys.argv) < 2:
        # No args at all — start TUI with default session
        start_tui("default")
        return
    
    # Check if first arg is a command or a session name
    first_arg = sys.argv[1]
    
    # If it doesn't look like a command, treat it as a session name
    known_commands = [
        "create-session", "send", "list-sessions", "show-session",
        "config", "agent", "run", "chat", "interactive", "i",
        "new", "help", "--help", "-h", "--version", "-v",
        "tui"
    ]
    
    if first_arg not in known_commands and not first_arg.startswith('-'):
        # First arg is a session name — start TUI with it
        start_tui(first_arg)
        return
    
    command = first_arg
    ai = AICode()
    
    # Start TUI directly
    if command == "tui":
        session_name = sys.argv[2] if len(sys.argv) > 2 else "default"
        start_tui(session_name)
        return
    
    # Automation/AI mode commands
    if command == "create-session":
        if len(sys.argv) < 3:
            error_out("Usage: codrninja create-session <name>", automation_mode)
        session = ai.create_session(sys.argv[2])
        output({"id": session.id, "name": session.name, "created": True}, automation_mode)
    
    elif command == "send":
        if len(sys.argv) < 4:
            error_out("Usage: codrninja send <session> <message>", automation_mode)
        result = ai.send_message(sys.argv[2], sys.argv[3])
        output(result, automation_mode)
    
    elif command == "list-sessions":
        sessions = ai.list_sessions()
        output({"sessions": sessions}, automation_mode)
    
    elif command == "show-session":
        if len(sys.argv) < 3:
            error_out("Usage: codrninja show-session <name>", automation_mode)
        result = ai.get_history(sys.argv[2])
        if result:
            output(result, automation_mode)
        else:
            error_out(f"Session '{sys.argv[2]}' not found", automation_mode)
    
    elif command == "config":
        config = Config.from_env()
        output({
            "ollama_url": config.ollama_url,
            "default_model": config.default_model,
            "db_path": config.db_path
        }, automation_mode)
    
    # Agent mode — the REAL tool
    elif command == "agent" or command == "run":
        if len(sys.argv) < 4:
            error_out("Usage: codrninja agent <session> <message>", automation_mode)
        
        session_name = sys.argv[2]
        message = sys.argv[3]
        
        # Create session if needed
        ai.create_session(session_name)
        
        # Create agent and run
        from .agent import Agent
        agent = Agent(ai, session_name, max_iterations=10)
        
        # Progress callback for interactive mode
        if not automation_mode:
            def on_progress(msg):
                print(f"  {msg}")
            agent.on_progress = on_progress
        
        result = agent.run(message, auto_approve=automation_mode)
        
        if automation_mode:
            output(result, True)
        else:
            if result['success']:
                print(f"\n✅ Task completed in {result['iterations']} iterations")
                print(f"Tools used: {result['tool_calls']}")
                print(f"\nResponse:\n{result['response'][:500]}...")
            else:
                print(f"\n❌ Error: {result.get('error', 'Unknown error')}")
    
    # Interactive human mode commands
    elif command == "chat" or command == "interactive" or command == "i":
        session_name = sys.argv[2] if len(sys.argv) > 2 else "default"
        session = ai.create_session(session_name)
        
        interactive = InteractiveSession(ai, session_name)
        interactive.start()
    
    elif command == "new":
        # Quick start: create session and enter interactive mode
        session_name = sys.argv[2] if len(sys.argv) > 2 else f"session-{os.urandom(4).hex()}"
        session = ai.create_session(session_name)
        
        if automation_mode:
            output({"session": session_name, "status": "created"}, True)
        else:
            print(f"Created session: {session_name}")
            interactive = InteractiveSession(ai, session_name)
            interactive.start()
    
    elif command == "help" or command == "--help" or command == "-h":
        if automation_mode:
            output({"help": get_help_text()}, True)
        else:
            print_help()
    
    else:
        error_out(f"Unknown command: {command}", automation_mode)


def output(data: dict, automation_mode: bool):
    """Output data in appropriate format."""
    if automation_mode:
        print(json.dumps(data))
    else:
        # Pretty print for humans
        print(json.dumps(data, indent=2))


def error_out(message: str, automation_mode: bool):
    """Output error and exit."""
    if automation_mode:
        print(json.dumps({"error": message}))
    else:
        print(f"Error: {message}")
    sys.exit(1)


def print_welcome():
    """Print welcome message."""
    welcome = """
    _    _          _____          _
   / \\  (_)_ __ ___/__   \\___  ___| |__
  / _ \\ | | '__/ _ \\ / /\\/\\/ / __| '_ \\
 / ___ \\| | | |  __// /  >  < \\__ \\ | | |
/_/   \\_\\_|_|  \\___\\/   \\_/\\_/___/_| |_|

AI-first coding assistant for automation
    """
    print(welcome)


def print_help():
    """Print help message for humans."""
    help_text = """
[bold]Usage:[/bold]

  [bold green]Human Mode[/bold green] (interactive):
    codrninja chat [session]      Start interactive chat session
    codrninja new [session]       Create and enter new session
    codrninja help                Show this help

  [bold blue]AI Mode[/bold blue] (automation — JSON output):
    AI_CODE_MODE=automation codrninja create-session <name>
    AI_CODE_MODE=automation codrninja send <session> <message>
    AI_CODE_MODE=automation codrninja list-sessions
    AI_CODE_MODE=automation codrninja show-session <name>

  [bold]Anywhere:[/bold]
    codrninja config              Show configuration

[bold]Environment Variables:[/bold]
  OLLAMA_URL       Ollama endpoint (default: http://localhost:11434)
  OLLAMA_MODEL     Default model (default: codellama)
  AI_CODE_MODE     Set to 'automation' for JSON output

[bold]Examples:[/bold]
  # Human interactive mode
  codrninja chat my-project

  # AI automation mode
  AI_CODE_MODE=automation codrninja create-session my-project
  AI_CODE_MODE=automation codrninja send my-project "Create a Button"
  AI_CODE_MODE=automation codrninja send my-project "Add dark mode"

  # Or use --json flag anywhere
  codrninja send my-project "Hello" --json
"""
    print(help_text)


def get_help_text() -> str:
    """Get help text for JSON output."""
    return """Available commands:
  create-session <name>  Create a new session
  send <session> <msg>   Send a message to a session
  list-sessions          List all sessions
  show-session <name>    Show session history
  config                 Show configuration
  chat [session]         Interactive mode (human)
  new [session]          Quick start (human)
  tui [session]          Start TUI (default)
  help                   Show help

Just type 'codrninja' or 'codrninja <session-name>' to start the TUI.

Use AI_CODE_MODE=automation or --json for JSON output.
"""


def start_tui(session_name: str = "default"):
    """Start the TUI interface."""
    try:
        from .tui import TUI
        ai = AICode()
        tui = TUI(ai, session_name)
        tui.start()
    except ImportError:
        print("❌ Rich not installed. Install with: pip3 install rich")
        print("   Or use: codrninja chat my-session")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error starting TUI: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
