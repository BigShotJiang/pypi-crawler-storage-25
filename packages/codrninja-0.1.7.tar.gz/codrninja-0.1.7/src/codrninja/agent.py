"""Agent loop for codrninja — makes it a real coding tool."""

import json
import os
import re
from typing import Dict, List, Optional, Any, Callable

from .core import AICode
from .tools import ToolRegistry


SYSTEM_PROMPT = """You are an expert software engineer. You help write, review, and modify code.

When you need to perform actions, use the TOOL format:

```tool
{
  "tool": "tool_name",
  "params": {
    "param1": "value1",
    "param2": "value2"
  }
}
```

Available tools:
- read_file: Read file contents. Params: path, offset, limit
- write_file: Write content to file. Params: path, content
- edit_file: Edit file by replacing text. Params: path, old_text, new_text
- execute_command: Run shell command. Params: command, cwd
- list_files: List directory contents. Params: path, depth
- search_files: Search for files. Params: pattern, path

Rules:
1. Always check existing files before modifying them
2. Use execute_command for builds, tests, git operations
3. Show file paths when creating or modifying files
4. Be concise but thorough
5. If a task requires multiple steps, use multiple tool calls

After using tools, summarize what you did and any important findings."""


class Agent:
    """Agent that can use tools to accomplish coding tasks."""
    
    def __init__(self, ai: AICode, session_name: str, max_iterations: int = 10):
        self.ai = ai
        self.session_name = session_name
        self.tools = ToolRegistry()
        self.max_iterations = max_iterations
        self.message_history = []
        self.on_progress: Optional[Callable[[str], None]] = None  # Callback for progress
        
    def run(self, message: str, auto_approve: bool = False) -> Dict[str, Any]:
        """Run the agent loop with tool execution."""
        # Build initial context
        context = self._build_context(message)
        
        iteration = 0
        tool_results = []
        
        while iteration < self.max_iterations:
            iteration += 1
            
            # Send message to AI
            response = self._call_ai(context)
            
            if not response.get('success'):
                return {
                    'success': False,
                    'error': response.get('error', 'Unknown error'),
                    'iterations': iteration
                }
            
            content = response['response']
            
            # Check for tool calls
            tool_calls = self._parse_tool_calls(content)
            
            if not tool_calls:
                # No more tools to call, task is complete
                return {
                    'success': True,
                    'response': content,
                    'iterations': iteration,
                    'tool_calls': len(tool_results),
                    'tools_used': tool_results
                }
            
            # Execute tools
            for tool_call in tool_calls:
                tool_name = tool_call['tool']
                params = tool_call['params']
                
                # Permission check for destructive operations
                if not auto_approve and self._needs_permission(tool_name):
                    if not self._ask_permission(tool_name, params):
                        return {
                            'success': False,
                            'error': f'User denied permission for {tool_name}',
                            'iterations': iteration
                        }
                
                # Execute tool
                result = self.tools.call(tool_name, **params)
                
                tool_results.append({
                    'tool': tool_name,
                    'params': params,
                    'success': result.success,
                    'output': result.output[:500] if result.success else result.error
                })
                
                # Add tool result to context
                context += f"\n\n[Tool Result: {tool_name}]\n"
                if result.success:
                    context += f"Success: {result.output[:500]}"
                else:
                    context += f"Error: {result.error}"
                
                # Progress callback
                if self.on_progress:
                    self.on_progress(f"✅ {tool_name}: {result.output[:100]}...")
        
        return {
            'success': True,
            'response': content,
            'iterations': iteration,
            'tool_calls': len(tool_results),
            'tools_used': tool_results,
            'note': 'Max iterations reached'
        }
    
    def _build_context(self, message: str) -> str:
        """Build context for the AI including project info."""
        context = SYSTEM_PROMPT + "\n\n"
        
        # Add current directory info
        context += "Current directory: " + os.getcwd() + "\n"
        
        # List files in current directory (shallow)
        result = self.tools.list_files(path=".", depth=1)
        if result.success:
            context += "Files in current directory:\n" + result.output + "\n\n"
        
        # Add the user's message
        context += "User: " + message + "\n\n"
        context += "Assistant: "
        
        return context
    
    def _call_ai(self, context: str) -> Dict[str, Any]:
        """Call the AI with context."""
        # Use the AI's send_message but with our system prompt
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": context}
        ]
        
        # Call Ollama directly
        return self.ai.send_message(self.session_name, context)
    
    def _parse_tool_calls(self, content: str) -> List[Dict[str, Any]]:
        """Parse tool calls from AI response."""
        tool_calls = []
        
        # Find tool blocks
        pattern = r'```tool\s*\n(.*?)\n```'
        matches = re.findall(pattern, content, re.DOTALL)
        
        for match in matches:
            try:
                tool_data = json.loads(match.strip())
                if 'tool' in tool_data and 'params' in tool_data:
                    tool_calls.append(tool_data)
            except json.JSONDecodeError:
                continue
        
        return tool_calls
    
    def _needs_permission(self, tool_name: str) -> bool:
        """Check if tool needs user permission."""
        destructive_tools = ['write_file', 'edit_file', 'execute_command']
        return tool_name in destructive_tools
    
    def _ask_permission(self, tool_name: str, params: Dict) -> bool:
        """Ask user for permission (interactive mode)."""
        print(f"\n🔒 Permission required for: {tool_name}")
        print(f"Params: {json.dumps(params, indent=2)}")
        
        try:
            response = input("Allow? [Y/n]: ").strip().lower()
            return response in ['', 'y', 'yes']
        except (EOFError, KeyboardInterrupt):
            return False
    
    def stream_run(self, message: str, auto_approve: bool = False):
        """Run with streaming output."""
        # This would stream responses chunk by chunk
        # For now, just yield the final result
        result = self.run(message, auto_approve)
        yield result
