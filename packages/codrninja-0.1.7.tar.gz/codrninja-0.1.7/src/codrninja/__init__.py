"""
codrninja: AI-first coding assistant for automation
"""

__version__ = "0.1.0"
__author__ = "Milan"
__license__ = "MIT"

from .core import AICode, Session
from .config import Config
from .agent import Agent
from .providers import ProviderManager, OllamaProvider, OpenAIProvider, AnthropicProvider, OpenRouterProvider

__all__ = ["AICode", "Session", "Config", "Agent", "ProviderManager", "OllamaProvider", "OpenAIProvider", "AnthropicProvider", "OpenRouterProvider"]
