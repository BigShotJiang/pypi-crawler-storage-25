# OwnTools
2021-12-27 Created

## Upload process
0. pip install wheel twine -i https://pypi.org/simple
1. change version
2. python setup.py sdist bdist_wheel
2. pip install -e
4. twine upload dist/*

## Attention
After the update, it cannot be directly downloaded from the new source address. You need to specify the original address for installation:

pip install xiuyutools -i https://pypi.org/simple

## Update log

### 2024-5-19
1. trans_to_date
2. trans_to_datetime
    

### 2026-4-6
1. Add Translation_AI
2. Delete unsafe key and secret key in Translation_AI and Translation
3. Add install_requires
