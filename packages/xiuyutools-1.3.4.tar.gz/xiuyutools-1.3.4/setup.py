from setuptools import setup, find_packages

setup(
    name="xiuyutools",
    version="1.3.4",
    packages=find_packages(),
    description="Tools for myself",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Neely",
    author_email="liangxiuyu@outlook.com",
    url="https://github.com/liangxiuyu/owntools",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    install_requires=[
        "retry",  # 直接写包名，将安装最新版
        "paramiko",
        "requests",
        "pprint",
        "httpx",
        "tqdm",
        "loguru",
        "pymysql",
        "rarfile",
        "Pillow",
        "paramiko"
    ],
)
