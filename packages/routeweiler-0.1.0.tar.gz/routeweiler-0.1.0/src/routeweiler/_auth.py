"""RouteweilerAuth — httpx.Auth subclass that retries on 402."""

from __future__ import annotations

import hashlib
import logging
from collections.abc import AsyncGenerator, Generator
from dataclasses import dataclass, field
from datetime import UTC, datetime
from decimal import Decimal
from typing import TYPE_CHECKING

import httpx

from routeweiler._constants import HTTP_CLIENT_ERROR_THRESHOLD, HTTP_STATUS_PAYMENT_REQUIRED
from routeweiler.budgets.local import BudgetStore
from routeweiler.budgets.receipts import uuid7 as _uuid7
from routeweiler.budgets.schema import DrawReceipt, EnvelopeCurrency
from routeweiler.errors import (
    FmvUnavailableError,
    NoFeasibleRailError,
    PolicyDeniedError,
    PolicyMaxPerCallExceededError,
    PostCommitPaymentError,
    RailNotSupportedError,
)
from routeweiler.funding import FundingSource
from routeweiler.policy.engine import PolicyEngine
from routeweiler.routing.router import Router
from routeweiler.routing.sticky import StickyCache, StickyKey

if TYPE_CHECKING:
    from routeweiler.credentials.recovery import CredentialRecoverer
    from routeweiler.credentials.schema import CredentialRecord
    from routeweiler.credentials.store import CredentialStore
    from routeweiler.normalized import NormalizedChallenge, Rail
    from routeweiler.rails.base import PaymentResult
    from routeweiler.trace.emitter import TraceEmitter

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Per-iteration failover state
# ---------------------------------------------------------------------------


@dataclass
class _FailoverState:
    """Mutable state carried across failover-loop iterations."""

    excluded_rails: frozenset[Rail] = field(default_factory=frozenset)
    prior_rail: Rail | None = None
    attempt: int = 0

    def advance(self, failed_rail: Rail) -> None:
        self.excluded_rails = self.excluded_rails | {failed_rail}
        self.prior_rail = failed_rail
        self.attempt += 1


# ---------------------------------------------------------------------------
# Module-level pure helpers
# ---------------------------------------------------------------------------


def _build_retry_request(request: httpx.Request, payment_result: PaymentResult) -> httpx.Request:
    """Build the retry request with the payment header attached."""
    retry_headers = dict(request.headers)
    if payment_result.header_name is not None and payment_result.header_value is not None:
        retry_headers[payment_result.header_name] = payment_result.header_value
    return httpx.Request(
        method=request.method,
        url=request.url,
        headers=retry_headers,
        content=request.content,
        extensions=request.extensions,
    )


class RouteweilerAuth(httpx.Auth):
    """Intercepts HTTP 402 responses and retries with a signed payment.

    Uses ``httpx.Auth.async_auth_flow()`` — the correct primitive for
    retry-with-modified-request (event_hooks are read-only and cannot retry).
    ``requires_request_body = True`` ensures the body is buffered so POST
    retries work correctly.
    """

    requires_request_body = True

    def __init__(
        self,
        *,
        router: Router,
        sticky_cache: StickyCache,
        funding: list[FundingSource],
        agent_id: str | None = None,
        session_id: str | None = None,
        emitter: TraceEmitter | None = None,
        budget_store: BudgetStore | None = None,
        envelope_id: str | None = None,
        envelope_currency: EnvelopeCurrency | None = None,
        envelope_allowed_rails: list[Rail] | None = None,
        reference_currency: EnvelopeCurrency | None = None,
        policy_engine: PolicyEngine | None = None,
        credential_store: CredentialStore | None = None,
        recoverer: CredentialRecoverer | None = None,
    ) -> None:
        self._router = router
        self._sticky_cache = sticky_cache
        self._funding = funding
        self._agent_id = agent_id
        self._session_id = session_id
        self._emitter = emitter
        self._budget_store = budget_store
        self._envelope_id = envelope_id
        self._envelope_currency = envelope_currency
        self._envelope_allowed_rails: frozenset[Rail] = frozenset(envelope_allowed_rails or [])
        self._reference_currency = reference_currency
        self._policy_engine = policy_engine
        self._credential_store = credential_store
        self._recoverer = recoverer

    def bind_envelope(self, *, currency: EnvelopeCurrency, allowed_rails: list[Rail]) -> None:
        """Update envelope currency and allowed-rails after deferred spec creation."""
        self._envelope_currency = currency
        self._reference_currency = currency
        self._envelope_allowed_rails = frozenset(allowed_rails)

    def auth_flow(self, request: httpx.Request) -> Generator[httpx.Request, httpx.Response, None]:
        # Sync path not supported — callers must use AsyncClient.
        raise NotImplementedError(
            "Routeweiler is async-only. Use httpx.AsyncClient (or await client.get(...))."
        )
        # httpx uses inspect.isgeneratorfunction to detect auth_flow; the yield
        # keyword must exist even though it is unreachable.
        yield request  # pragma: no cover

    async def async_auth_flow(
        self, request: httpx.Request
    ) -> AsyncGenerator[httpx.Request, httpx.Response]:
        ts_start = datetime.now(UTC)
        response = yield request

        if response.status_code != HTTP_STATUS_PAYMENT_REQUIRED:
            # Non-402: the passthrough trace is emitted by the client's
            # response event hook (which also fires for free calls).  We tag
            # the extensions dict so the hook knows it is not a paid call.
            response.extensions["routeweiler_emitted"] = False
            return

        # Drain the 402 body so the connection returns to the pool.
        await response.aread()

        request_id = _uuid7()
        sticky_key = StickyKey(
            origin=_origin(request.url),
            agent_id=self._agent_id,
            session_id=self._session_id,
        )

        # Load FMV snapshot once per 402 (needed by router for cost scoring).
        fmv_snapshot = await self._load_fmv_snapshot()

        state = _FailoverState()

        while True:
            # -----------------------------------------------------------------
            # Routing phase: select the best feasible rail.
            # -----------------------------------------------------------------
            sticky_rail = self._sticky_cache.lookup(sticky_key)
            try:
                choice = await self._router.decide(
                    request=request,
                    response=response,
                    policy_engine=self._policy_engine,
                    funding=self._funding,
                    reference_currency=self._reference_currency,
                    fmv_snapshot=fmv_snapshot,
                    excluded_rails=state.excluded_rails,
                    sticky_rail=sticky_rail,
                    prior_rail=state.prior_rail,
                    attempt=state.attempt,
                )
            except (RailNotSupportedError, PolicyDeniedError, NoFeasibleRailError) as err:
                await self._safe_emit_error(
                    error=err,
                    request=request,
                    response=response,
                    challenge=None,
                    ts_start=ts_start,
                    fallback_from=state.prior_rail,
                )
                raise

            challenge = choice.candidate.challenge
            adapter = choice.candidate.adapter
            decision = choice.candidate.policy_decision

            # -----------------------------------------------------------------
            # Policy max_per_call gate (post-routing, amount-based).
            # Requires a reference_currency (from envelope or policy.currency).
            # -----------------------------------------------------------------
            if (
                decision.max_per_call_minor_units is not None
                and self._reference_currency is not None
            ):
                quote = choice.candidate.quote_envelope_minor_units
                if quote is None:
                    # FMV unavailable for a rail covered by a per-call cap — fail closed.
                    fmv_err = FmvUnavailableError(
                        f"FMV conversion failed for {request.url}; "
                        "refusing to pay an uncapped amount when max_per_call_minor_units is set."
                    )
                    await self._safe_emit_error(
                        error=fmv_err,
                        request=request,
                        response=response,
                        challenge=challenge,
                        ts_start=ts_start,
                        fallback_from=choice.fallback_from,
                    )
                    raise fmv_err
                if quote > decision.max_per_call_minor_units:
                    exc = PolicyMaxPerCallExceededError(
                        rule_name=decision.rule_name,
                        requested=quote,
                        limit=decision.max_per_call_minor_units,
                    )
                    await self._safe_emit_error(
                        error=exc,
                        request=request,
                        response=response,
                        challenge=challenge,
                        ts_start=ts_start,
                        fallback_from=choice.fallback_from,
                    )
                    raise exc

            # -----------------------------------------------------------------
            # Budget draw phase — reserve capacity before committing to payment.
            # -----------------------------------------------------------------
            receipt: DrawReceipt | None = None
            quote = choice.candidate.quote_envelope_minor_units
            if (
                self._budget_store is not None
                and self._envelope_id is not None
                and self._envelope_currency is not None
            ):
                if quote is None:
                    if adapter.rail in self._envelope_allowed_rails:
                        # FMV failed for a rail the envelope explicitly covers — fail closed.
                        fmv_err = FmvUnavailableError(
                            f"FMV conversion failed for all candidate rails on {request.url}; "
                            "refusing to pay uncapped."
                        )
                        await self._safe_emit_error(
                            error=fmv_err,
                            request=request,
                            response=response,
                            challenge=challenge,
                            ts_start=ts_start,
                            fallback_from=choice.fallback_from,
                        )
                        raise fmv_err
                    # Rail not in envelope's allowed_rails — skip draw, no enforcement.
                else:
                    idempotency_key = _make_idempotency_key(request_id, state.attempt)
                    try:
                        receipt = await self._budget_store.draw(
                            envelope_id=self._envelope_id,
                            request_id=request_id,
                            idempotency_key=idempotency_key,
                            amount_reserved_minor_units=quote,
                            rail_quoted=adapter.rail,
                        )
                    except Exception as exc:
                        await self._safe_emit_error(
                            error=exc,
                            request=request,
                            response=response,
                            challenge=challenge,
                            ts_start=ts_start,
                            fallback_from=choice.fallback_from,
                        )
                        raise  # budget errors are not failover-able

            # -----------------------------------------------------------------
            # Pay phase — produce the PaymentResult.
            # PostCommitPaymentError: funds already left the wire before the
            # exception fired — confirm the draw, emit an error trace, and
            # raise to the caller (no failover; re-issuing would double-spend).
            # All other exceptions: rollback, exclude this rail, failover.
            # -----------------------------------------------------------------
            try:
                payment_result = await adapter.pay(challenge)
            except PostCommitPaymentError as exc:
                await self._confirm_draw_safe(receipt)
                await self._safe_emit_error(
                    error=exc,
                    request=request,
                    response=response,
                    challenge=challenge,
                    ts_start=ts_start,
                    fallback_from=choice.fallback_from,
                )
                self._sticky_cache.forget(sticky_key)
                raise
            except Exception:
                _log.warning(
                    "Pay failed for rail %r on attempt %d; rolling back and trying next rail.",
                    adapter.rail,
                    state.attempt,
                )
                await self._rollback_safe(receipt)
                self._sticky_cache.forget(sticky_key)
                state.advance(adapter.rail)
                continue

            # -----------------------------------------------------------------
            # Persist credential before the retry so a crash mid-retry leaves a
            # recoverable PERSISTED row — persisted before the retry is attempted.
            # -----------------------------------------------------------------
            credential_record = await self._persist_credential_safe(
                request_id, adapter.rail, str(request.url), payment_result, challenge
            )

            # Build the retry request with the payment header attached.
            retry = _build_retry_request(request, payment_result)
            ts_retry = datetime.now(UTC)

            # -----------------------------------------------------------------
            # Yield retry — may raise on transport error.
            # On transport error: confirm (funds left the wire), emit error
            # trace, attempt recovery/failover.
            # -----------------------------------------------------------------
            try:
                final_response = yield retry
            except Exception as exc:
                await self._confirm_draw_safe(receipt)
                await self._attempt_recovery_safe(credential_record, last_response=None)
                await self._safe_emit_error(
                    error=exc,
                    request=request,
                    response=response,
                    challenge=challenge,
                    ts_start=ts_start,
                    fallback_from=choice.fallback_from,
                )
                self._sticky_cache.forget(sticky_key)
                state.advance(adapter.rail)
                continue

            ts_end = datetime.now(UTC)

            # Tag the final response so the passthrough hook skips it.
            final_response.extensions["routeweiler_emitted"] = True

            # -----------------------------------------------------------------
            # Credential lifecycle: REDEEMED on 2xx, or split-URL recovery on
            # 4xx/5xx.  Returns the budget_response (may be the recovered 2xx).
            # -----------------------------------------------------------------
            budget_response = await self._handle_credential_post_response(
                credential_record, final_response
            )

            # -----------------------------------------------------------------
            # Confirm the draw — adapter.pay() returned, so funds left the
            # wire regardless of the HTTP outcome or credential recovery state.
            # -----------------------------------------------------------------
            await self._confirm_draw_safe(receipt)

            # Update sticky cache on successful payment.
            self._sticky_cache.remember(sticky_key, adapter.rail, challenge.expires_at)

            if self._emitter:
                try:
                    settlement = await adapter.confirm(payment_result, budget_response)
                    await self._emitter.emit_paid(
                        request=request,
                        challenge=challenge,
                        payment_result=payment_result,
                        settlement=settlement,
                        final_response=budget_response,
                        ts_start=ts_start,
                        ts_retry=ts_retry,
                        ts_end=ts_end,
                        fallback_from=choice.fallback_from,
                        snapshot_rates=fmv_snapshot,
                    )
                except Exception:
                    _log.exception("Trace emit_paid failed; continuing.")

            return  # success — exit the failover loop

    # ---------------------------------------------------------------------------
    # Private helpers
    # ---------------------------------------------------------------------------

    async def _safe_emit_error(
        self,
        *,
        error: Exception,
        request: httpx.Request,
        response: httpx.Response,
        challenge: NormalizedChallenge | None,
        ts_start: datetime,
        fallback_from: Rail | None,
    ) -> None:
        """Emit an error trace event, swallowing any emission failure."""
        if self._emitter:
            try:
                await self._emitter.emit_error(
                    request=request,
                    response=response,
                    error=error,
                    challenge=challenge,
                    ts_start=ts_start,
                    ts_end=datetime.now(UTC),
                    fallback_from=fallback_from,
                )
            except Exception:
                _log.exception("Trace emit failed.")

    async def _load_fmv_snapshot(self) -> dict[str, Decimal] | None:
        if self._budget_store is not None and self._envelope_id is not None:
            return await self._budget_store.load_fmv_snapshot(self._envelope_id)
        return None

    async def _rollback_safe(self, receipt: DrawReceipt | None) -> None:
        if receipt is not None and self._budget_store is not None:
            try:
                await self._budget_store.rollback(receipt.receipt_id)
            except Exception:
                _log.exception("Rollback failed; draw will expire via reaper.")

    async def _persist_credential_safe(
        self,
        request_id: str,
        rail: Rail,
        challenge_url: str,
        payment_result: PaymentResult,
        challenge: NormalizedChallenge,
    ) -> CredentialRecord | None:
        if payment_result.credential is None or self._credential_store is None:
            return None
        try:
            return await self._credential_store.persist(
                request_id=request_id,
                rail=rail,
                challenge_url=challenge_url,
                payload=payment_result.credential,
                expires_at=challenge.expires_at,
            )
        except Exception:
            _log.exception(
                "Credential persistence failed; retry proceeds without recovery tracking."
            )
            return None

    async def _attempt_recovery_safe(
        self,
        credential_record: CredentialRecord | None,
        *,
        last_response: httpx.Response | None,
    ) -> None:
        if credential_record is not None and self._recoverer is not None:
            try:
                await self._recoverer.attempt_recovery(
                    credential_record.credential_id,
                    last_response=last_response,
                )
            except Exception:
                _log.exception("Credential recovery attempt failed.")

    async def _handle_credential_post_response(
        self,
        credential_record: CredentialRecord | None,
        final_response: httpx.Response,
    ) -> httpx.Response:
        """Transition the credential and return the response to use for budget settle.

        On a direct 2xx: marks the credential REDEEMED.
        On 4xx/5xx: triggers split-URL recovery; on success, substitutes the
        recovered 2xx as the budget_response so the draw is confirmed, not rolled back.
        The extension ``"routeweiler_recovered_response"`` signals ``client._traced``
        to return the recovered response to the caller.
        """
        if credential_record is None:
            return final_response

        budget_response = final_response

        if final_response.status_code < HTTP_CLIENT_ERROR_THRESHOLD:
            # Direct 2xx from the original retry — credential is consumed.
            # Route through recoverer so it owns all PERSISTED→REDEEMED transitions.
            if self._recoverer is not None:
                await self._recoverer.mark_redeemed(credential_record.credential_id)
        elif self._recoverer is not None:
            # 4xx/5xx: attempt split-URL recovery.
            # On success the recoverer transitions REDEEMED internally.
            # On exhaustion it transitions MANUAL_HOLD and emits a trace event.
            try:
                outcome = await self._recoverer.attempt_recovery(
                    credential_record.credential_id,
                    last_response=final_response,
                )
                if outcome.succeeded and outcome.response is not None:
                    # Tag the recovered response so _traced() does not double-emit.
                    outcome.response.extensions["routeweiler_emitted"] = True
                    # Signal client._traced() to return this response to the caller.
                    final_response.extensions["routeweiler_recovered_response"] = outcome.response
                    # Use the recovered 2xx for budget confirm and trace emission.
                    budget_response = outcome.response
            except Exception:
                _log.exception("Credential recovery attempt failed.")

        return budget_response

    async def _confirm_draw_safe(self, receipt: DrawReceipt | None) -> None:
        """Confirm the budget draw unconditionally.

        Only called after adapter.pay() returns successfully, meaning funds have
        left the wallet on the wire.  Rollback is reserved for pay-phase failures
        (see _rollback_safe) where pay() raised before the wire commit.
        """
        if receipt is None or self._budget_store is None:
            return
        try:
            await self._budget_store.confirm(
                receipt.receipt_id, receipt.amount_reserved_minor_units
            )
        except Exception:
            _log.exception("Confirm failed; draw will stay reserved until reaper.")


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _origin(url: httpx.URL) -> str:
    """Return the origin of a URL as "{scheme}://{host}:{port}"."""
    default_port = 443 if url.scheme == "https" else 80
    port = url.port if url.port is not None else default_port
    return f"{url.scheme}://{url.host}:{port}"


def _make_idempotency_key(request_id: str, attempt: int) -> str:
    """Deterministic idempotency key derived from (request_id, attempt).

    Using SHA-256 means a retried failover with the same (request_id, attempt)
    naturally collapses to the same draw (naturally idempotent).
    """
    return hashlib.sha256(f"{request_id}:{attempt}".encode()).hexdigest()
