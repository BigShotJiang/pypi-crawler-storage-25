"""Canonical service-shape manifests shipped with Routeweiler."""

from __future__ import annotations

from routeweiler.credentials.manifests.schema import ServiceShape, ServiceShapeStep

# Real-world case: the Lightning Enable Store by Refined Element.
# The 402 challenge is issued at POST /api/store/checkout but fulfilment
# happens at POST /api/store/claim. The order ID is carried inside the
# macaroon as a first-party caveat (key=order_id), not in the URL path.
#
# Sources:
#   https://refinedelement.com/blog/l402-broke-at-the-worst-possible-moment-here-s-what-we-learned
#   https://docs.lightningenable.com/products/product-overview
#   https://store.lightningenable.com/
_LIGHTNING_ENABLE_STORE = ServiceShape(
    name="lightning-enable-store",
    domain_matches="*.lightningenable.com",
    flow=[
        ServiceShapeStep(
            challenge_path="/api/store/checkout",
            fulfil_path_template="/api/store/claim",
            id_extractor="macaroon:order_id",
            method="POST",
        ),
    ],
)

BUNDLED_SHAPES: tuple[ServiceShape, ...] = (_LIGHTNING_ENABLE_STORE,)
