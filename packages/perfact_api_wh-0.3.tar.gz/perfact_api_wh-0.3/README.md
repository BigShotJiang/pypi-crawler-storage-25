# perfact-api-wh

SQLAlchemy models and domain services for the WH domain. Part of the `perfact.api.wh` namespace.

## What it provides

Domain logic only — no web framework dependency. Intended to be used directly in workers, scripts, or as a dependency of `perfact-api-wh-fastapi`.

Models inherit from `Base` (provided by `perfact-api-base-model`) and live under `perfact.api.wh.model`:

```python
from perfact.api.base.model import Base, Mapped

class WhSomething(Base):
    name: Mapped[str]  # DB column: whsomething_name
```

## Dependencies

- `perfact-api-base-model`
- `sqlalchemy`
- `psycopg[c]`
- `pydantic-settings`

## Maintainers

- Alexander Rolfes <alexander.rolfes@perfact.de>
