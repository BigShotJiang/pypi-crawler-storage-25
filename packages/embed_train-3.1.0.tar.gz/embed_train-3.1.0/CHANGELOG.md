# [3.1.0](https://gitlab.com/efysent/agentic-core/embed-train/compare/v3.0.0...v3.1.0) (2026-05-12)


### Features

* add hard negative training ([4d79e25](https://gitlab.com/efysent/agentic-core/embed-train/commit/4d79e25877f7483dd7c6f13a97b1dd846c998c9a))

# [3.0.0](https://gitlab.com/efysent/agentic-core/embed-train/compare/v2.0.0...v3.0.0) (2026-05-09)


* feat!: rename trainer configuration fields for consistency ([c3538f1](https://gitlab.com/efysent/agentic-core/embed-train/commit/c3538f1eadeeb708fa50962e648da000e471b1e9))


### BREAKING CHANGES

* Renamed training configuration fields across PyTorch and Hugging Face trainers:
- config.lr -> config.learning_rate
- config.batch_size -> config.per_device_train_batch_size (HF trainer only)

# [2.0.0](https://gitlab.com/efysent/agentic-core/embed-train/compare/v1.0.0...v2.0.0) (2026-05-08)


* feat!: add validation ranking metrics and rename in-batch collate functions ([a3b01e4](https://gitlab.com/efysent/agentic-core/embed-train/commit/a3b01e4148ab632090008c346415fbff8fa11f9f))


### BREAKING CHANGES

* renamed in-batch collate function classes and updated validation loop behavior to compute ranking metrics

# 1.0.0 (2026-04-21)


### Features

* initial release ([0ef0776](https://gitlab.com/efysent/agentic-core/embed-train/commit/0ef07764d7279d95e149fb795348e6637e4f52a3))
