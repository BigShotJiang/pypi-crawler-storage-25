from pathlib import Path
from typing import Any, Literal, Self

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings

from embed_train.constants import RANDOM_SEED, TRUST_REMOTE_CODE
from embed_train.exceptions import EmbedTrainValueError
from retrievalbase.connector.settings import DatasetConnectorSettings
from retrievalbase.dataset.settings import HuggingFaceDatasetAdaptaterSettings
from retrievalbase.evaluation.settings import ProcessorSettings
from retrievalbase.settings import FromConfigMixinSettings


class TorchDatasetSettings[TCDatasetConnector: "DatasetConnectorSettings"](FromConfigMixinSettings):
    dataset_connector: TCDatasetConnector


class TokenizerSettings(BaseSettings):
    name: str
    padding: str | bool
    truncation: bool
    max_length: int
    trust_remote_code: bool = TRUST_REMOTE_CODE


class SamplerSettings(BaseSettings):
    module_path: str
    seed: int | None


class DistanceSettings(FromConfigMixinSettings):
    pass


class StepRangeDistanceSettings(DistanceSettings):
    pass


class PositiveSamplerSettings[TCDistance: "DistanceSettings"](SamplerSettings):
    max_step_distance: int
    distance: TCDistance
    k: int


class CollateFnSettings[TCProcessor: "ProcessorSettings"](BaseSettings):
    module_path: str
    tokenizer: TokenizerSettings
    processor: TCProcessor


class InBatchNegativeCollateFnSettings[TCProcessor: "ProcessorSettings"](CollateFnSettings[TCProcessor]):
    pass


class MultiPositiveInBatchCollateFnSettings[TCProcessor: "ProcessorSettings"](CollateFnSettings[TCProcessor]):
    n_pos: int


class HardNegativeCollateFnSettings[TCProcessor: "ProcessorSettings"](CollateFnSettings[TCProcessor]):
    pass


class ModelSettings(FromConfigMixinSettings):
    pass


class LossSettings(FromConfigMixinSettings):
    pass


class TrainerSettings(FromConfigMixinSettings):
    data_dir: Path


class HardNegativeMinerSettings(FromConfigMixinSettings):
    pass


class SentenceTransformerHardNegativeMinerSettings(HardNegativeMinerSettings):
    model_name_or_path: str
    cross_encoder_model_name_or_path: str | None = None
    tokenizer: TokenizerSettings
    pooling: Literal["cls", "mean_tokens", "max_tokens"]
    anchor_column_name: str = "query"
    positive_column_name: str = "positive"
    range_min: int = 0
    range_max: int | None = None
    max_score: float | None = None
    min_score: float | None = None
    absolute_margin: float | None = None
    relative_margin: float | None = None
    num_negatives: int = 3
    sampling_strategy: Literal["random", "top"] = "top"
    query_prompt_name: str | None = None
    query_prompt: str | None = None
    corpus_prompt_name: str | None = None
    corpus_prompt: str | None = None
    include_positives: bool = False
    output_format: Literal["triplet", "n-tuple", "labeled-pair", "labeled-list"] = "n-tuple"
    output_scores: bool = False
    batch_size: int = 32
    faiss_batch_size: int = 16384
    use_faiss: bool = False
    use_multi_process: bool | list[str] = False
    verbose: bool = True
    cache_folder: str | None = None
    trust_remote_code: bool = TRUST_REMOTE_CODE


class PyTorchTrainerSettings[
    TCModel: "ModelSettings",
    TCLoss: "LossSettings",
    TCTorchDataset: "TorchDatasetSettings[Any]",
    TCCollateFn: "CollateFnSettings[Any]",
](TrainerSettings):
    model: TCModel
    torch_dataset: TCTorchDataset
    collate_fn: TCCollateFn
    train_frac: float
    num_epochs: int
    batch_size: int
    shuffle: bool
    learning_rate: float
    device: str
    save_every: int
    drop_last: bool
    loss: TCLoss
    seed: int = RANDOM_SEED
    resume_from: str | None = None


class ContrastiveLossSettings(LossSettings):
    temperature: float


class QueryMultiPositiveDatasetSettings[TCDatasetConnector: "DatasetConnectorSettings"](
    TorchDatasetSettings[TCDatasetConnector]
):
    pass


class QueryPositiveDatasetSettings[TCDatasetConnector: "DatasetConnectorSettings"](
    TorchDatasetSettings[TCDatasetConnector]
):
    pass


class HardNegativeDatasetSettings[
    TCDatasetConnector: "DatasetConnectorSettings",
    TCHardNegativeMiner: "HardNegativeMinerSettings",
](TorchDatasetSettings[TCDatasetConnector]):
    hard_negative_miner: TCHardNegativeMiner


class InBatchNegativeContrastiveLossSettings(ContrastiveLossSettings):
    pass


class MultiPositiveContrastiveLossSettings(ContrastiveLossSettings):
    n_pos: int


class HardNegativeContrastiveLossSettings(ContrastiveLossSettings):
    pass


class RunnerSettings(FromConfigMixinSettings):
    pass


class HFSettings(BaseSettings):
    repo: str
    revision: str | None
    private: bool
    commit_message: str | None


class PushToHFRunnerSettings[TCModel: "ModelSettings"](RunnerSettings):
    checkpoint_path: str = Field(init=False)
    device: str = Field(init=False)
    push: bool = Field(init=False)
    create_repo: bool = Field(init=False)
    hf: HFSettings = Field(init=False)
    model: TCModel = Field(init=False)


class TrainRunnerSettings[TCTrainer: "TrainerSettings"](RunnerSettings):
    trainer: TCTrainer


class EvalutationSettings(BaseSettings):
    query_column: str
    document_column: str
    precision_recall_at_k: list[int]
    mrr_at_k: list[int]
    ndcg_at_k: list[int]
    batch_size: int


class SentenceTransformerLoss(LossSettings):
    kwargs: dict[str, Any]


class SentenceTransformersTrainerSettings[
    TCDatasetConnector: "DatasetConnectorSettings",
    TCModel: "ModelSettings",
](TrainerSettings):
    hf_dataset: HuggingFaceDatasetAdaptaterSettings[TCDatasetConnector]
    model: TCModel
    tokenizer: TokenizerSettings
    loss: SentenceTransformerLoss
    pooling: Literal["cls", "mean_tokens", "max_tokens"]
    per_device_train_batch_size: int
    num_epochs: int
    learning_rate: float
    warmup_ratio: float
    eval_steps: int
    save_steps: int
    logging_steps: int
    fp16: bool
    train_frac: float
    resume_from: str | None
    evaluation: EvalutationSettings
    trust_remote_code: bool = TRUST_REMOTE_CODE

    # -------------------------
    # CROSS-FIELD VALIDATION
    # -------------------------
    @model_validator(mode="after")
    def _validate_steps_consistency(self) -> Self:
        # 1️⃣ ordering
        if not (self.logging_steps <= self.eval_steps <= self.save_steps):
            raise EmbedTrainValueError(
                "Expected logging_steps ≤ eval_steps ≤ save_steps, got "
                f"{self.logging_steps} ≤ {self.eval_steps} ≤ {self.save_steps}"
            )

        # 2️⃣ alignment (CRITICAL)
        if self.save_steps % self.eval_steps != 0:
            raise EmbedTrainValueError(
                "save_steps must be a multiple of eval_steps "
                f"(got save_steps={self.save_steps}, eval_steps={self.eval_steps})"
            )

        return self
