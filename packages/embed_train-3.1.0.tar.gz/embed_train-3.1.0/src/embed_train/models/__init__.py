from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any, Self, cast

from torch import nn
from transformers import PreTrainedModel

from embed_train.utils import load_checkpoint_state_dict
from retrievalbase.mixins import FromConfigMixin

if TYPE_CHECKING:
    from embed_train.settings import ModelSettings


class Model[TCModel: "ModelSettings"](FromConfigMixin[TCModel], ABC):
    def __init__(self, config: TCModel):
        self.config = config

    @abstractmethod
    def to_hf_model(self) -> PreTrainedModel:  # inplace
        raise NotImplementedError()

    def save(
        self,
        repo_dir: str | Path,
        push: bool = False,
        **push_kwargs: Any,
    ) -> None:
        repo_dir_path = Path(repo_dir) if isinstance(repo_dir, str) else repo_dir
        self.to_hf_model().save_pretrained(repo_dir_path)
        if push:
            self.to_hf_model().push_to_hub(
                repo_id=repo_dir_path.name,
                **push_kwargs,
            )

    def to(self, device: str) -> Self:
        cast(nn.Module, self.to_hf_model()).to(device)
        return self

    @classmethod
    def from_checkpoint(
        cls,
        config: TCModel,
        checkpoint: str,
        device: str,
        strict: bool = True,
    ) -> "Model[TCModel]":
        model = cls(config)
        hf_model = model.to_hf_model()
        checkpoint_path = Path(checkpoint)
        if checkpoint_path.is_dir():
            state_dict_path = checkpoint_path / "model.safetensors"
            if not state_dict_path.exists():
                raise FileNotFoundError(f"No model.safetensors found in {checkpoint_path}")
            state_dict = load_checkpoint_state_dict(state_dict_path)
        else:
            state_dict = load_checkpoint_state_dict(checkpoint_path)
        hf_model.load_state_dict(state_dict, strict=strict)
        hf_model.to(device)  # ty: ignore[invalid-argument-type]
        return model
