from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

import yaml

from embed_train.exceptions import InvalidRunnerClassError
from embed_train.utils import load_class
from retrievalbase.mixins import FromConfigMixin

if TYPE_CHECKING:
    from embed_train.settings import RunnerSettings


class Runner[TCRunner: "RunnerSettings"](FromConfigMixin[TCRunner], ABC):
    def __init__(self, config: TCRunner):
        self.config = config

    @abstractmethod
    def run(self) -> None:
        raise NotImplementedError()

    @classmethod
    def _validate_klass(self, symbol: Any) -> type["Runner[TCRunner]"]:
        if not isinstance(symbol, type):
            raise InvalidRunnerClassError(f"Loaded object is not a class: {symbol!r}")
        # 2️⃣ Ensure it is a Runner subclass
        if not issubclass(symbol, Runner):
            raise InvalidRunnerClassError(f"Class {symbol.__module__}.{symbol.__name__} is not a subclass of Runner")
        return symbol

    @classmethod
    def get_runner(cls, config_path: str) -> "Runner[TCRunner]":
        with open(config_path) as f:
            yaml_config = yaml.safe_load(f)
            symbol = load_class(yaml_config["module_path"])
            klass: type[Runner[TCRunner]] = cls._validate_klass(symbol)
            return klass.from_settings()
