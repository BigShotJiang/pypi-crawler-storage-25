from typing import TYPE_CHECKING, Any

from embed_train import Runner
from embed_train.train.trainers import Trainer
from embed_train.utils import load_class

if TYPE_CHECKING:
    from embed_train.settings import TrainRunnerSettings


class TrainRunner[TCTrainRunner: "TrainRunnerSettings[Any]"](Runner[TCTrainRunner]):
    def __init__(self, config: TCTrainRunner):
        super().__init__(config)
        self.trainer: Trainer[Any] = load_class(self.config.trainer.module_path).from_config(self.config.trainer)

    def run(self) -> None:
        self.trainer.train()
