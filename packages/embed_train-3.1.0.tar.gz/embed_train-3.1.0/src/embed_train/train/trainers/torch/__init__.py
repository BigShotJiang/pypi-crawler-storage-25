import logging
import random
from abc import ABC, abstractmethod
from contextlib import nullcontext
from datetime import datetime
from typing import TYPE_CHECKING, Any, cast

import torch
import torch.nn.functional as F
from torch.optim import Optimizer
from torch.utils.data import DataLoader, random_split
from torch.utils.tensorboard import SummaryWriter

from embed_train.models import Model
from embed_train.train.dataset import CollateFn
from embed_train.train.dataset.torch_datasets import TorchDataset
from embed_train.train.trainers import Trainer
from embed_train.train.trainers.torch.loss import Loss
from embed_train.utils import load_class

_logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from embed_train.settings import PyTorchTrainerSettings


class PyTorchTrainer[TCPyTorchTrainer: "PyTorchTrainerSettings[Any, Any, Any, Any]"](Trainer[TCPyTorchTrainer], ABC):
    LOGS_PER_EPOCH = 51  # logs per epoch
    VAL_METRIC_KS = (1, 5, 10)

    def __init__(self, config: TCPyTorchTrainer):
        super().__init__(config)
        self.run_name = self._run_name()
        self.device = self.config.device
        self.seed = self.config.seed
        self.latest_val_metrics: dict[str, float] = {}
        self._set_seed()
        self.model = self._load_model().to_hf_model()
        self.optimizer = self._load_optimizer()
        self.writer = self._load_writer()
        self.num_epochs = self.config.num_epochs
        self.checkpoint_dir = self.config.data_dir / "checkpoints"
        self.save_every = self.config.save_every
        self.loss = self._load_loss()
        self.resume_from = self.config.resume_from
        self.torch_dataset: TorchDataset[Any, Any] = load_class(self.config.torch_dataset.module_path).from_config(
            self.config.torch_dataset
        )
        _logger.info(
            f"Initialized {self.__class__.__name__} | device={self.device} | \
            num_epochs={self.num_epochs} | save_every={self.save_every} | \
            seed={self.seed} | resume_from={self.resume_from}"
        )

    @classmethod
    def get_nstep(cls, num_batches: int) -> int:
        return max(1, num_batches // cls.LOGS_PER_EPOCH)

    def _set_seed(self) -> None:
        random.seed(self.seed)
        torch.manual_seed(self.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(self.seed)

    def _torch_generator(self) -> torch.Generator:
        return torch.Generator().manual_seed(self.seed)

    @abstractmethod
    def _encode_query(self, tokens: dict[str, torch.Tensor]) -> torch.Tensor:
        raise NotImplementedError()

    @abstractmethod
    def _encode_documents(self, tokens: dict[str, torch.Tensor]) -> torch.Tensor:
        raise NotImplementedError()

    @torch.no_grad()
    def _compute_val_scores(self, batch: Any) -> dict[str, float]:
        q_tok, c_tok = batch
        q_emb = self._encode_query(q_tok)
        c_emb = self._encode_documents(c_tok)
        q_emb = F.normalize(q_emb, dim=-1)
        c_emb = F.normalize(c_emb, dim=-1)
        scores = q_emb @ c_emb.T
        relevance = self._build_relevance_mask(q_emb.size(0), c_emb.size(0), scores.device)
        return self._ranking_metrics(scores, relevance)

    def _build_relevance_mask(
        self,
        num_queries: int,
        num_candidates: int,
        device: torch.device,
    ) -> torch.Tensor:
        positives_per_query = num_candidates // num_queries if num_candidates % num_queries == 0 else 1
        relevance = torch.zeros((num_queries, num_candidates), dtype=torch.bool, device=device)
        for query_idx in range(num_queries):
            start = query_idx * positives_per_query
            end = min(start + positives_per_query, num_candidates)
            relevance[query_idx, start:end] = True
        return relevance

    def _ranking_metrics(
        self,
        scores: torch.Tensor,
        relevance: torch.Tensor,
    ) -> dict[str, float]:
        num_candidates = scores.size(1)
        max_k = min(max(self.VAL_METRIC_KS), num_candidates)
        top_indices = scores.topk(k=max_k, dim=1).indices
        ranked_relevance = relevance.gather(1, top_indices).float()
        num_relevant = relevance.sum(dim=1).clamp(min=1).float()
        metrics: dict[str, float] = {}

        for k in self.VAL_METRIC_KS:
            effective_k = min(k, num_candidates)
            rel_at_k = ranked_relevance[:, :effective_k]
            hits_at_k = rel_at_k.sum(dim=1)
            metrics[f"precision@{k}"] = (hits_at_k / effective_k).mean().item()
            metrics[f"recall@{k}"] = (hits_at_k / num_relevant).clamp(max=1.0).mean().item()

            has_hit = rel_at_k.bool().any(dim=1)
            first_hit = rel_at_k.argmax(dim=1).float() + 1.0
            reciprocal_rank = torch.where(has_hit, 1.0 / first_hit, torch.zeros_like(first_hit))
            metrics[f"mrr@{k}"] = reciprocal_rank.mean().item()

            discounts = 1.0 / torch.log2(torch.arange(2, effective_k + 2, device=scores.device).float())
            dcg = (rel_at_k * discounts).sum(dim=1)
            ideal_counts = torch.minimum(num_relevant, torch.full_like(num_relevant, float(effective_k))).long()
            ideal_rel = torch.arange(effective_k, device=scores.device).unsqueeze(0) < ideal_counts.unsqueeze(1)
            idcg = (ideal_rel.float() * discounts).sum(dim=1).clamp(min=torch.finfo(scores.dtype).eps)
            metrics[f"ndcg@{k}"] = (dcg / idcg).mean().item()

        return metrics

    def _format_val_scores(self, metrics: dict[str, float]) -> str:
        return " | ".join(f"{name}={value:.4f}" for name, value in sorted(metrics.items()))

    def _step(
        self,
        batch: tuple[dict[str, torch.Tensor], dict[str, torch.Tensor]],
    ) -> torch.Tensor:
        q_tok, c_tok = batch
        q_emb = self._encode_query(q_tok)
        c_emb = self._encode_documents(c_tok)
        return self.loss(q_emb, c_emb)

    def _run_name(self) -> str:
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        class_name = self.config.module_path.split(".")[-1].lower()
        return f"{class_name}_bs{self.config.batch_size}_lr{self.config.learning_rate}_{ts}"

    def _load_model(self) -> Model[Any]:
        return cast(
            Model[Any],
            load_class(self.config.model.module_path).from_config(self.config.model).to(self.device),
        )

    def _load_optimizer(self) -> Optimizer:
        return torch.optim.AdamW(
            self.model.parameters(),
            lr=self.config.learning_rate,
        )

    def _load_loss(self) -> Loss[Any]:
        return cast(
            Loss[Any],
            load_class(self.config.loss.module_path).from_config(self.config.loss),
        )

    def _load_writer(self) -> SummaryWriter:
        log_dir = self.config.data_dir / f"tensorboard/runs/{self.run_name}"
        _logger.info(f"TensorBoard log dir | path={log_dir}")
        return SummaryWriter(log_dir=str(log_dir))

    def save_checkpoint(self, epoch: int) -> None:
        ckpt = {
            "epoch": epoch,
            "model_state": self.model.state_dict(),
            "optimizer_state": self.optimizer.state_dict(),
        }
        path = self.checkpoint_dir / f"{self.run_name}/epoch_{epoch:04d}.pt"
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(ckpt, path)

    def load_checkpoint(self) -> int:
        if self.resume_from:
            checkpoint_path = self.resume_from
            _logger.info(f"Loading checkpoint from {checkpoint_path}")
            ckpt = torch.load(checkpoint_path, map_location=self.device, weights_only=True)
            self.model.load_state_dict(ckpt["model_state"])
            self.optimizer.load_state_dict(ckpt["optimizer_state"])
            _logger.info(f"Resuming training from epoch {ckpt['epoch']}")
            return ckpt["epoch"]
        return 0

    def run_epoch(
        self,
        epoch: int,
        data_loader: DataLoader,
        training: bool,
    ) -> float:
        self.model.train() if training else self.model.eval()
        tag = "Train" if training else "Val"

        ctx = nullcontext() if training else torch.no_grad()
        loss_sum = 0.0
        num_batches = len(data_loader)
        val_metric_sums: dict[str, float] = {}
        val_metric_count = 0

        for step, batch in enumerate(data_loader):
            with ctx:
                loss = self._step(batch)
                val_scores = self._compute_val_scores(batch) if not training else None

            if training:
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.optimizer.step()

            loss_sum += loss.detach().item()

            if val_scores is not None:
                val_metric_count += 1
                for name, value in val_scores.items():
                    val_metric_sums[name] = val_metric_sums.get(name, 0.0) + value

            if step % self.get_nstep(num_batches) == 0:
                if training:
                    _logger.info(f"{tag} epoch {epoch} | step {step} / {num_batches}")
                else:
                    _logger.info(
                        f"{tag} epoch {epoch} | step {step} / {num_batches} | {self._format_val_scores(val_scores or {})}"
                    )

        if not training and val_metric_sums:
            self.latest_val_metrics = {name: value / val_metric_count for name, value in val_metric_sums.items()}

            _logger.info(f"{tag} epoch {epoch} | {self._format_val_scores(self.latest_val_metrics)}")

        return loss_sum / num_batches

    def _fit(
        self,
        train_loader: DataLoader,
        val_loader: DataLoader,
    ) -> None:
        start_epoch = self.load_checkpoint()
        for epoch in range(start_epoch + 1, self.num_epochs + 1):
            train_loss = self.run_epoch(epoch, train_loader, training=True)
            val_loss = self.run_epoch(epoch, val_loader, training=False)
            _logger.info(f"[Epoch {epoch:02d}] train loss: {train_loss:4f} | val loss: {val_loss:4f}")
            self.writer.add_scalar("loss/train_epoch", train_loss, epoch)
            self.writer.add_scalar("loss/val_epoch", val_loss, epoch)
            for name, value in self.latest_val_metrics.items():
                self.writer.add_scalar(f"val/{name}", value, epoch)
            if epoch % self.save_every == 0:
                self.save_checkpoint(epoch)

    def _build_collate_fn(self) -> CollateFn[Any, Any]:
        collate_cls = load_class(self.config.collate_fn.module_path)
        _logger.info(
            f"Building collate function | class={collate_cls.__name__} | "
            f"module_path={self.config.collate_fn.module_path}"
        )
        context = {"torch_dataset": self.torch_dataset}
        collate_fn: CollateFn[Any, Any] = collate_cls(self.config.collate_fn, context)
        _logger.info("Collate function ready")
        return collate_fn

    def _load_dataloaders(self) -> tuple[DataLoader, DataLoader]:
        collate_fn = self._build_collate_fn()
        n_total = len(self.torch_dataset)
        n_val = int((1 - self.config.train_frac) * n_total)
        n_train = n_total - n_val
        train_ds, val_ds = random_split(
            self.torch_dataset,
            [n_train, n_val],
            generator=self._torch_generator(),
        )
        train_loader = DataLoader(
            train_ds,
            batch_size=self.config.batch_size,
            shuffle=self.config.shuffle,
            collate_fn=collate_fn,
            drop_last=self.config.drop_last,
            generator=self._torch_generator(),
        )
        val_loader = DataLoader(
            val_ds,
            batch_size=self.config.batch_size,
            shuffle=False,
            collate_fn=collate_fn,
            drop_last=self.config.drop_last,
        )
        return train_loader, val_loader

    def train(self) -> None:
        train_loader, val_loader = self._load_dataloaders()
        self._fit(train_loader, val_loader)
