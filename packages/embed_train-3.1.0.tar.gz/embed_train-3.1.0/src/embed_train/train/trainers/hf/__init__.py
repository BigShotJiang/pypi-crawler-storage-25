import logging
from typing import TYPE_CHECKING, Any

from datasets import Dataset  # type: ignore[import-untyped]
from sentence_transformers import SentenceTransformer, SentenceTransformerTrainer, SentenceTransformerTrainingArguments
from sentence_transformers.sentence_transformer.evaluation import InformationRetrievalEvaluator
from sentence_transformers.sentence_transformer.modules import Pooling, Transformer

from embed_train.constants import RANDOM_SEED
from embed_train.exceptions import EmbedTrainValueError
from embed_train.models import Model
from embed_train.train.trainers import Trainer
from embed_train.utils import load_class
from retrievalbase.dataset.hf import HuggingFaceDatasetAdaptater

_logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from embed_train.settings import SentenceTransformersTrainerSettings


class SentenceTransformersTrainer[TCHFTrainRunner: "SentenceTransformersTrainerSettings[Any, Any]"](
    Trainer[TCHFTrainRunner]
):
    def __init__(self, config: TCHFTrainRunner) -> None:
        super().__init__(config)

    def train(self) -> None:
        st_model = self._load_sentence_transformer()
        hf_ds = self._load_hf_dataset()
        splits = hf_ds.train_test_split(
            test_size=1.0 - self.config.train_frac,
            seed=RANDOM_SEED,
            shuffle=True,
        )
        train_dataset = splits["train"]
        val_dataset = splits["test"]
        loss = load_class(self.config.loss.module_path)(model=st_model, **self.config.loss.kwargs)
        val_evaluator = self._hf_dataset_to_ir_evaluator(val_dataset, name="val")
        warmup_steps = self._get_warmup_steps(train_dataset)
        args = SentenceTransformerTrainingArguments(
            output_dir=str(self.config.data_dir / f"checkpoints/{self._run_name()}"),
            per_device_train_batch_size=self.config.per_device_train_batch_size,
            per_device_eval_batch_size=self.config.per_device_train_batch_size,
            num_train_epochs=self.config.num_epochs,
            learning_rate=self.config.learning_rate,
            warmup_steps=warmup_steps,
            eval_strategy="steps",
            save_strategy="steps",
            logging_strategy="steps",
            eval_steps=self.config.eval_steps,
            save_steps=self.config.save_steps,
            logging_steps=self.config.logging_steps,
            fp16=self.config.fp16,
        )
        trainer = SentenceTransformerTrainer(
            model=st_model,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            loss=loss,
            args=args,
            evaluator=val_evaluator,
        )
        _logger.info("Starting SentenceTransformers training...")
        trainer.train()

    def _get_warmup_steps(self, dataset: Dataset) -> float:
        train_size = len(dataset)
        steps_per_epoch = train_size // self.config.per_device_train_batch_size
        total_steps = steps_per_epoch * self.config.num_epochs
        warmup_steps = int(total_steps * self.config.warmup_ratio)
        return warmup_steps

    def _load_model(self) -> Model[Any]:
        model_cls: type[Model[Any]] = load_class(self.config.model.module_path)
        if self.config.resume_from:
            return model_cls.from_checkpoint(
                config=self.config.model,
                checkpoint=self.config.resume_from,
                device="cpu",  # or config.device
            )
        return model_cls.from_config(self.config.model)

    def _prepare_model_path(self) -> str:
        if self.config.resume_from:
            return self.config.resume_from
        model = self._load_model()
        save_path = str(self.config.data_dir / f"checkpoints/{self._run_name()}_root")
        model.save(save_path)
        return str(save_path)

    def _load_sentence_transformer(self) -> SentenceTransformer:
        model_path = self._prepare_model_path()
        trust = self.config.trust_remote_code or self.config.tokenizer.trust_remote_code
        transformer = Transformer(
            model_name_or_path=model_path,
            max_seq_length=self.config.tokenizer.max_length,
            tokenizer_name_or_path=self.config.tokenizer.name,
            model_args={
                "trust_remote_code": trust,
            },
            config_args={
                "trust_remote_code": trust,
            },
            tokenizer_args={
                "trust_remote_code": trust,
                "padding": self.config.tokenizer.padding,
                "truncation": self.config.tokenizer.truncation,
                "model_max_length": self.config.tokenizer.max_length,
            },
        )
        pooling = Pooling(
            transformer.get_word_embedding_dimension(),
            pooling_mode_mean_tokens=self.config.pooling == "mean_tokens",
            pooling_mode_cls_token=self.config.pooling == "cls",
            pooling_mode_max_tokens=self.config.pooling == "max_tokens",
        )

        return SentenceTransformer(modules=[transformer, pooling])

    def _load_hf_dataset(self) -> Dataset:
        hf_adaptater: HuggingFaceDatasetAdaptater[Any] = load_class(self.config.hf_dataset.module_path).from_config(
            self.config.hf_dataset
        )
        return hf_adaptater.to_hf()

    def _hf_dataset_to_ir_evaluator(
        self,
        ds: Dataset,
        name: str,
    ) -> InformationRetrievalEvaluator:
        query_col = self.config.evaluation.query_column
        doc_col = self.config.evaluation.document_column
        queries: dict[str, str] = {}
        corpus: dict[str, str] = {}
        relevant_docs: dict[str, set[str]] = {}
        for i, row in enumerate(ds):
            qid = f"q{i}"
            did = f"d{i}"
            try:
                query = row[query_col]
                doc = row[doc_col]
            except KeyError as e:
                raise EmbedTrainValueError(
                    f"Column '{e.args[0]}' not found in dataset. Available columns: {list(row.keys())}"
                ) from e
            queries[qid] = query
            corpus[did] = doc
            relevant_docs[qid] = {did}
        return InformationRetrievalEvaluator(
            queries=queries,
            corpus=corpus,
            relevant_docs=relevant_docs,
            name=name,
            precision_recall_at_k=self.config.evaluation.precision_recall_at_k,
            mrr_at_k=self.config.evaluation.mrr_at_k,
            ndcg_at_k=self.config.evaluation.ndcg_at_k,
            batch_size=self.config.evaluation.batch_size,
        )
