import gc
import logging

import torch
from datasets import Dataset as HFDataset  # type: ignore[import-untyped]
from sentence_transformers import SentenceTransformer
from sentence_transformers.cross_encoder import CrossEncoder
from sentence_transformers.sentence_transformer.modules import Pooling, Transformer
from sentence_transformers.util import mine_hard_negatives

from embed_train.settings import SentenceTransformerHardNegativeMinerSettings
from embed_train.train.dataset import HardNegativeMiner

_logger = logging.getLogger(__name__)


class SentenceTransformerHardNegativeMiner(HardNegativeMiner[SentenceTransformerHardNegativeMinerSettings]):
    def __init__(self, config: "SentenceTransformerHardNegativeMinerSettings") -> None:
        super().__init__(config)

    def _load_sentence_transformer(self) -> SentenceTransformer:
        trust = self.config.trust_remote_code or self.config.tokenizer.trust_remote_code

        _logger.info(
            f"Loading SentenceTransformer | "
            f"model={self.config.model_name_or_path} | "
            f"pooling={self.config.pooling} | "
            f"max_length={self.config.tokenizer.max_length}"
        )

        transformer = Transformer(
            model_name_or_path=self.config.model_name_or_path,
            max_seq_length=self.config.tokenizer.max_length,
            tokenizer_name_or_path=self.config.tokenizer.name,
            model_args={
                "trust_remote_code": trust,
            },
            config_args={
                "trust_remote_code": trust,
            },
            tokenizer_args={
                "trust_remote_code": trust,
                "padding": self.config.tokenizer.padding,
                "truncation": self.config.tokenizer.truncation,
                "model_max_length": self.config.tokenizer.max_length,
            },
        )

        pooling = Pooling(
            transformer.get_word_embedding_dimension(),
            pooling_mode_mean_tokens=self.config.pooling == "mean_tokens",
            pooling_mode_cls_token=self.config.pooling == "cls",
            pooling_mode_max_tokens=self.config.pooling == "max_tokens",
        )

        model = SentenceTransformer(modules=[transformer, pooling])

        _logger.info(
            f"SentenceTransformer loaded successfully | embedding_dim={transformer.get_word_embedding_dimension()}"
        )

        return model

    def _load_cross_encoder(self) -> "CrossEncoder | None":
        if not self.config.cross_encoder_model_name_or_path:
            _logger.info("No CrossEncoder configured")
            return None

        _logger.info(f"Loading CrossEncoder | model={self.config.cross_encoder_model_name_or_path}")

        model = CrossEncoder(
            self.config.cross_encoder_model_name_or_path,
            trust_remote_code=self.config.trust_remote_code,
        )

        _logger.info("CrossEncoder loaded successfully")

        return model

    def mine(self, dataset: HFDataset) -> HFDataset:
        _logger.info(
            f"Starting hard negative mining | "
            f"dataset_size={len(dataset)} | "
            f"num_negatives={self.config.num_negatives} | "
            f"sampling_strategy={self.config.sampling_strategy} | "
            f"use_faiss={self.config.use_faiss}"
        )

        model = self._load_sentence_transformer()
        cross_encoder = self._load_cross_encoder()

        try:
            mined = mine_hard_negatives(
                dataset=dataset,
                model=model,
                anchor_column_name=self.config.anchor_column_name,
                positive_column_name=self.config.positive_column_name,
                cross_encoder=cross_encoder,
                range_min=self.config.range_min,
                range_max=self.config.range_max,
                max_score=self.config.max_score,
                min_score=self.config.min_score,
                absolute_margin=self.config.absolute_margin,
                relative_margin=self.config.relative_margin,
                num_negatives=self.config.num_negatives,
                sampling_strategy=self.config.sampling_strategy,
                query_prompt_name=self.config.query_prompt_name,
                query_prompt=self.config.query_prompt,
                corpus_prompt_name=self.config.corpus_prompt_name,
                corpus_prompt=self.config.corpus_prompt,
                include_positives=self.config.include_positives,
                output_format=self.config.output_format,
                output_scores=self.config.output_scores,
                batch_size=self.config.batch_size,
                faiss_batch_size=self.config.faiss_batch_size,
                use_faiss=self.config.use_faiss,
                use_multi_process=self.config.use_multi_process,
                verbose=self.config.verbose,
                cache_folder=self.config.cache_folder,
            )

            _logger.info(f"Hard negative mining completed successfully | mined_dataset_size={len(mined)}")
        finally:
            _logger.info("Cleaning GPU memory after hard negative mining")
            del model
            if cross_encoder is not None:
                del cross_encoder
            gc.collect()
            if torch.cuda.is_available():
                allocated_before = torch.cuda.memory_allocated() / 1024**3
                reserved_before = torch.cuda.memory_reserved() / 1024**3
                torch.cuda.empty_cache()
                torch.cuda.ipc_collect()
                allocated_after = torch.cuda.memory_allocated() / 1024**3
                reserved_after = torch.cuda.memory_reserved() / 1024**3
                _logger.info(
                    f"CUDA memory cleanup completed | "
                    f"allocated_before={allocated_before:.2f}GB | "
                    f"reserved_before={reserved_before:.2f}GB | "
                    f"allocated_after={allocated_after:.2f}GB | "
                    f"reserved_after={reserved_after:.2f}GB"
                )
        return mined
