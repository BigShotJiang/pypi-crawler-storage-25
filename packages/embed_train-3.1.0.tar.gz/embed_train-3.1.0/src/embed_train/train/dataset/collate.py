import random
from typing import Any

from embed_train.settings import (
    HardNegativeCollateFnSettings,
    InBatchNegativeCollateFnSettings,
    MultiPositiveInBatchCollateFnSettings,
)
from embed_train.train.dataset import CollateFn


class InBatchNegativeCollateFn(CollateFn[InBatchNegativeCollateFnSettings, dict[str, str]]):
    def __init__(
        self,
        config: InBatchNegativeCollateFnSettings,
        context: dict[str, Any] | None,
    ) -> None:
        super().__init__(config, context)

    def _process_batch(
        self,
        batch: list[dict[str, str]],
    ) -> tuple[list[str], list[str]]:
        queries: list[str] = []
        positives: list[str] = []

        for item in batch:
            queries.append(item["query"])
            positives.append(item["positive"])
        return queries, positives


class MultiPositiveInBatchCollateFn(CollateFn[MultiPositiveInBatchCollateFnSettings, dict[str, Any]]):
    def __init__(
        self,
        config: MultiPositiveInBatchCollateFnSettings,
        context: dict[str, Any] | None,
    ) -> None:
        super().__init__(config, context)

    def _process_batch(
        self,
        batch: list[dict[str, Any]],
    ) -> tuple[list[str], list[str]]:
        queries: list[str] = []
        passages: list[str] = []
        for item in batch:
            query = item["query"]
            positives = item["positives"]
            sampled_positives = [random.choice(positives) for _ in range(self.config.n_pos)]  # nosec B311
            queries.append(query)
            passages.extend(sampled_positives)
        return queries, passages


class HardNegativeCollateFn(CollateFn[HardNegativeCollateFnSettings, dict[str, Any]]):
    def __init__(
        self,
        config: HardNegativeCollateFnSettings,
        context: dict[str, Any] | None,
    ) -> None:
        super().__init__(config, context)

    def _process_batch(
        self,
        batch: list[dict[str, Any]],
    ) -> tuple[list[str], list[str]]:
        queries: list[str] = []
        passages: list[str] = []

        for item in batch:
            queries.append(item["query"])
            passages.append(item["positive"])
            passages.extend(self._negative_passages(item))

        return queries, passages

    def _negative_passages(self, item: dict[str, Any]) -> list[str]:
        if "negative" in item:
            return [item["negative"]]

        negative_keys = sorted(
            (key for key in item if key.startswith("negative_")),
            key=lambda key: int(key.rsplit("_", 1)[1]),
        )
        return [item[key] for key in negative_keys]
