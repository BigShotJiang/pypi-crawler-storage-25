from typing import Any

import polars as pl
from datasets import Dataset as HFDataset  # type: ignore[import-untyped]

from embed_train.settings import (
    HardNegativeDatasetSettings,
    QueryMultiPositiveDatasetSettings,
    QueryPositiveDatasetSettings,
)
from embed_train.train.dataset import TorchDataset
from embed_train.train.dataset.hard_negatives import HardNegativeMiner
from embed_train.utils import load_class


class QueryMultiPositiveDataset(TorchDataset[QueryMultiPositiveDatasetSettings[Any], dict[str, Any]]):
    """
    Each item:
      {
        "query": str,
        "positives": List[str]
      }
    """

    def __init__(self, config: QueryMultiPositiveDatasetSettings[Any]) -> None:
        super().__init__(config)
        grouped = self.dataset.polars.group_by(pl.col("metadata").struct.field("query")).agg(
            pl.col("page_content").alias("positives"),
        )

        self.queries: list[str] = grouped.select(pl.col("query")).to_series().to_list()
        self.positives: list[list[str]] = grouped["positives"].to_list()

        assert len(self.queries) == len(self.positives)

    def __len__(self) -> int:
        return len(self.queries)

    def __getitem__(self, index: int) -> dict[str, Any]:
        positives = self.positives[index]
        return {
            "query": self.queries[index],
            "positives": positives,
        }


class QueryPositiveDataset(
    TorchDataset[
        QueryPositiveDatasetSettings[Any],
        dict[str, str],
    ]
):
    def __init__(
        self,
        config: QueryPositiveDatasetSettings[Any],
    ) -> None:
        super().__init__(config)

        rows = self.dataset.polars.select(
            pl.col("metadata").struct.field("query").alias("query"),
            pl.col("page_content").alias("positive"),
        )

        self._queries = rows["query"].to_list()
        self._positives = rows["positive"].to_list()

    def __len__(self) -> int:
        return len(self._queries)

    def __getitem__(self, index: int) -> dict[str, str]:
        positive = self._positives[index]

        if not positive:
            msg = f"No positive passage found for index {index}"
            raise ValueError(msg)

        return {
            "query": self._queries[index],
            "positive": positive,
        }


class HardNegativeDataset(
    TorchDataset[
        HardNegativeDatasetSettings[Any, Any],
        dict[str, Any],
    ]
):
    def __init__(
        self,
        config: HardNegativeDatasetSettings[Any, Any],
    ) -> None:
        super().__init__(config)
        input_dataset = self._to_query_positive_hf_dataset()
        miner = self._load_hard_negative_miner()
        self._dataset = miner.mine(input_dataset)

    def _to_query_positive_hf_dataset(self) -> HFDataset:
        rows = self.dataset.polars.select(
            pl.col("metadata").struct.field("query").alias("query"),
            pl.col("page_content").alias("positive"),
        )
        return HFDataset.from_list(rows.to_dicts())

    def _load_hard_negative_miner(self) -> HardNegativeMiner[Any]:
        miner_cls = load_class(self.config.hard_negative_miner.module_path)
        return miner_cls.from_config(self.config.hard_negative_miner)

    def __len__(self) -> int:
        return len(self._dataset)

    def __getitem__(self, index: int) -> dict[str, Any]:
        return self._dataset[index]
