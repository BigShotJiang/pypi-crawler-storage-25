from typing import Any

from embed_train.settings import PositiveSamplerSettings
from embed_train.train.dataset.sampling import Sampler
from embed_train.utils import load_class


class PositiveSampler(Sampler[PositiveSamplerSettings, dict[str, Any]]):
    def __init__(self, config: PositiveSamplerSettings, context: dict[str, Any] | None) -> None:
        super().__init__(config, context)
        self.distance = load_class(self.config.distance.module_path).from_config(self.config.distance)

    def sample(self, item: dict[str, Any], **kwargs: Any) -> list[str]:
        texts: list[str] = item["page_content"]
        metas: list[dict[str, Any]] = item["metadata"]
        anchor_meta = metas[kwargs["anchor_idx"]]
        anchor_range: tuple[int, int] = anchor_meta["step_range"]
        anchor_section = anchor_meta["section"]
        candidates = [
            i
            for i, m in enumerate(metas)
            if (
                m["section"] == anchor_section
                and self.distance(anchor_range, m["step_range"]) <= self.config.max_step_distance
            )
        ]
        candidates = list(set(candidates))
        candidates = list(dict.fromkeys(candidates))
        while len(candidates) < self.config.k:
            candidates.append(kwargs["anchor_idx"])
        positives = self.rng.sample(
            candidates,
            k=self.config.k,
        )
        assert len(positives) == self.config.k
        return [texts[i] for i in positives]
