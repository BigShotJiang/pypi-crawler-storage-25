import random
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from embed_train.settings import StepRangeDistanceSettings
from retrievalbase.mixins import FromConfigMixin

if TYPE_CHECKING:
    from embed_train.settings import DistanceSettings, SamplerSettings


class Sampler[TCSampler: "SamplerSettings", T: dict[str, Any]](ABC):
    RANDOM_SEED = 42

    def __init__(self, config: TCSampler, context: dict[str, Any] | None) -> None:
        self.config = config
        self.context = context
        self.rng = random.Random(self.config.seed)  # nosec B311

    @abstractmethod
    def sample(self, item: T, **kwargs: Any) -> list[str]:
        pass

    def _init_components(self) -> None:
        return None


class Distance[TCDistance: "DistanceSettings"](FromConfigMixin[TCDistance], ABC):
    def __init__(self, config: TCDistance) -> None:
        self.config = config

    @abstractmethod
    def __call__(self, a: tuple[int, int], b: tuple[int, int]) -> int:
        raise NotImplementedError


class StepRangeDistance(Distance[StepRangeDistanceSettings]):
    def __init__(self, config: StepRangeDistanceSettings) -> None:
        super().__init__(config)

    def __call__(self, a: tuple[int, int], b: tuple[int, int]) -> int:
        if a[1] < b[0]:
            return b[0] - a[1]
        if b[1] < a[0]:
            return a[0] - b[1]
        return 0
