import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, cast

import torch
from datasets import Dataset as HFDataset  # type: ignore[import-untyped]
from torch.utils.data import Dataset as TorchDatasetBase
from transformers import AutoTokenizer, PreTrainedTokenizer

from embed_train.utils import load_class
from retrievalbase.dataset import TextDataset
from retrievalbase.enums import EmbeddingPurposeEnum
from retrievalbase.evaluation import Processor
from retrievalbase.mixins import FromConfigMixin

_logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from embed_train.settings import CollateFnSettings, HardNegativeMinerSettings, TorchDatasetSettings


class CollateFn[TCCollateFn: "CollateFnSettings[Any]", T: dict[str, Any]](ABC):
    def __init__(self, config: TCCollateFn, context: dict[str, Any] | None) -> None:
        self.config = config
        self.context = context
        self.tokenizer: PreTrainedTokenizer = self._load_tokenizer()
        self.processor: Processor[Any] = self._load_processor()

    @abstractmethod
    def _process_batch(self, batch: list[T]) -> tuple[list[str], list[str]]:
        raise NotImplementedError()

    def _load_tokenizer(self) -> PreTrainedTokenizer:
        tokenizer = AutoTokenizer.from_pretrained(  # nosec CWE-494
            self.config.tokenizer.name,
            trust_remote_code=self.config.tokenizer.trust_remote_code,
        )
        return cast(PreTrainedTokenizer, tokenizer)

    def _load_processor(self) -> Processor[Any]:
        processor: Processor[Any] = load_class(self.config.processor.module_path).from_config(self.config.processor)
        return processor

    def __call__(self, batch: list[T]) -> tuple[torch.Tensor, torch.Tensor]:
        queries, candidates = self._process_batch(batch)
        return self._post_process(queries, candidates)

    def _post_process(self, queries: list[str], candidates: list[str]) -> tuple[torch.Tensor, torch.Tensor]:
        queries = [
            self.processor(
                text=query,
                purpose=cast(EmbeddingPurposeEnum, EmbeddingPurposeEnum.QUERY),
            )
            for query in queries
        ]
        candidates = [
            self.processor(
                text=candidate,
                purpose=cast(EmbeddingPurposeEnum, EmbeddingPurposeEnum.DOCUMENT),
            )
            for candidate in candidates
        ]
        return self._tokenizer_qc(queries, candidates)

    def _tokenizer_qc(self, queries: list[str], candidates: list[str]) -> tuple[torch.Tensor, torch.Tensor]:
        q_tok = self.tokenizer(
            queries,
            padding=self.config.tokenizer.padding,
            truncation=self.config.tokenizer.truncation,
            max_length=self.config.tokenizer.max_length,
            return_tensors="pt",
        )
        c_tok = self.tokenizer(
            candidates,
            padding=self.config.tokenizer.padding,
            truncation=self.config.tokenizer.truncation,
            max_length=self.config.tokenizer.max_length,
            return_tensors="pt",
        )
        return q_tok, c_tok


class TorchDataset[TCTorchDataset: "TorchDatasetSettings[Any]", T: dict[str, Any]](
    FromConfigMixin[TCTorchDataset],
    TorchDatasetBase[T],
    ABC,
):
    def __init__(self, config: TCTorchDataset) -> None:
        self.config = config
        self.dataset = self._load_dataset()

    @abstractmethod
    def __len__(self) -> int:
        raise NotImplementedError()

    def _load_dataset(self) -> TextDataset[Any]:
        dataset: TextDataset[Any] = (
            load_class(self.config.dataset_connector.module_path).from_config(self.config.dataset_connector).load_text()
        )
        _logger.info(f"Instantiating dataset | class={dataset.__class__.__name__} |")
        _logger.info(f"Dataset loaded | type={type(dataset).__name__} | size={len(dataset)}")
        return dataset

    def to_hf_dataset(self) -> HFDataset:
        """
        Convert *this* TorchDataset (via __getitem__) to a HuggingFace Dataset.
        """
        rows: list[dict[str, Any]] = [self[i] for i in range(len(self))]
        return HFDataset.from_list(rows)


class HardNegativeMiner[TCHardNegativeMiner: "HardNegativeMinerSettings"](FromConfigMixin[TCHardNegativeMiner], ABC):
    def __init__(self, config: TCHardNegativeMiner) -> None:
        self.config = config

    @abstractmethod
    def mine(self, dataset: HFDataset) -> HFDataset:
        raise NotImplementedError
