import importlib
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Any

import torch
from huggingface_hub import HfApi
from safetensors.torch import load_file as load_safetensors

if TYPE_CHECKING:
    pass


def load_class(path: str) -> Any:
    module_path, class_name = path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def save_extra_files_locally(
    *,
    files: list[str],
    target_dir: Path,
) -> None:
    """
    Copy extra source files into the local HF repo directory.
    """
    target_dir.mkdir(parents=True, exist_ok=True)

    for file in files:
        src = Path(file)
        if not src.exists():
            raise FileNotFoundError(f"Extra file not found: {src}")

        dst = target_dir / src.name
        shutil.copy2(src, dst)


def push_extra_files_to_hf(
    *,
    repo_id: str,
    files: list[str],
    revision: str | None,
    commit_message: str,
) -> None:
    api = HfApi()

    for file in files:
        path = Path(file)

        api.upload_file(
            path_or_fileobj=path,
            path_in_repo=path.name,
            repo_id=repo_id,
            repo_type="model",
            revision=revision,
            commit_message=commit_message,
        )


def load_checkpoint_state_dict(
    checkpoint_path: str | Path,
) -> dict:
    checkpoint_path = str(checkpoint_path)
    if checkpoint_path.endswith(".safetensors"):
        state_dict = load_safetensors(checkpoint_path)
    else:
        state_dict = torch.load(
            checkpoint_path,
            map_location="cpu",
            weights_only=True,  # 🔥 critical security fix
        )
    if isinstance(state_dict, dict) and "model_state" in state_dict:
        state_dict = state_dict["model_state"]
    if not isinstance(state_dict, dict):
        raise ValueError("Checkpoint must be a state_dict")
    for k, _v in state_dict.items():
        if not isinstance(k, str):
            raise ValueError("Invalid key in state_dict")
    return state_dict
