class EmbedTrainError(Exception):
    """Base exception for all embed_train errors."""


# -------------------------
# Runtime errors
# -------------------------
class EmbedTrainRuntimeError(RuntimeError, EmbedTrainError):
    """Runtime errors during execution (training, loading, etc.)."""


class MissingContextError(EmbedTrainRuntimeError):
    """Raised when required context is missing."""


# -------------------------
# Type errors
# -------------------------
class EmbedTrainTypeError(TypeError, EmbedTrainError):
    """Invalid type provided."""


class InvalidRunnerClassError(EmbedTrainTypeError):
    """Runner class is not valid or does not inherit expected base."""


# -------------------------
# Value errors
# -------------------------
class EmbedTrainValueError(ValueError, EmbedTrainError):
    """Invalid value provided in configuration or runtime."""
