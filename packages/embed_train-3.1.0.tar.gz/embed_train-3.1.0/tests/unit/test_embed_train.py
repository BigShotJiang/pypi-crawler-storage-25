from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from embed_train import Runner
from embed_train.exceptions import InvalidRunnerClassError
from tests.fixtures.components import DummyRunner, NotARunner


def test_validate_klass_rejects_non_class() -> None:
    with pytest.raises(InvalidRunnerClassError, match="not a class"):
        Runner._validate_klass("bad")


def test_validate_klass_rejects_non_runner_class() -> None:
    with pytest.raises(InvalidRunnerClassError, match="not a subclass"):
        Runner._validate_klass(NotARunner)


def test_validate_klass_accepts_runner_subclass() -> None:
    assert Runner._validate_klass(DummyRunner) is DummyRunner


def test_get_runner_loads_yaml_module_path(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config_path = tmp_path / "config.yaml"
    config_path.write_text(yaml.safe_dump({"module_path": "tests.fixtures.components.DummyRunner"}), encoding="utf-8")

    expected = object()
    monkeypatch.setattr(DummyRunner, "from_settings", classmethod(lambda cls: expected))

    result = Runner.get_runner(str(config_path))

    assert result is expected
