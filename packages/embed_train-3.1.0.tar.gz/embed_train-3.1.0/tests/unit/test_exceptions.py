from embed_train.exceptions import (
    EmbedTrainError,
    EmbedTrainRuntimeError,
    EmbedTrainTypeError,
    EmbedTrainValueError,
    InvalidRunnerClassError,
    MissingContextError,
)


def test_exception_hierarchy() -> None:
    assert issubclass(EmbedTrainRuntimeError, RuntimeError)
    assert issubclass(EmbedTrainRuntimeError, EmbedTrainError)
    assert issubclass(MissingContextError, EmbedTrainRuntimeError)
    assert issubclass(EmbedTrainTypeError, TypeError)
    assert issubclass(InvalidRunnerClassError, EmbedTrainTypeError)
    assert issubclass(EmbedTrainValueError, ValueError)
