from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from embed_train.settings import (
    DistanceSettings,
    ModelSettings,
    RunnerSettings,
    SamplerSettings,
    SentenceTransformersTrainerSettings,
    TorchDatasetSettings,
)
from retrievalbase.connector.settings import DatasetConnectorSettings
from tests.fixtures.components import (
    build_collate_settings,
    build_dataset_connector_settings,
    build_evaluation_settings,
    build_hard_negative_miner_settings,
    build_hard_negative_torch_dataset_settings,
    build_hf_settings,
    build_loss_settings,
    build_model_settings,
    build_multi_positive_collate_settings,
    build_positive_sampler_settings,
    build_pytorch_trainer_settings,
    build_sentence_transformer_loss,
    build_sentence_transformers_trainer_settings,
    build_step_range_distance_settings,
    build_tokenizer_settings,
)


def test_basic_settings_objects_build(tmp_path: Path) -> None:
    assert TorchDatasetSettings(
        module_path="x.y.Dataset",
        dataset_connector=build_dataset_connector_settings(),
    ).dataset_connector.module_path.endswith("DummyDatasetConnector")
    assert build_collate_settings().tokenizer == build_tokenizer_settings()
    assert build_multi_positive_collate_settings().n_pos == 2
    assert SamplerSettings(module_path="x.y.Sampler", seed=1).seed == 1
    assert DistanceSettings(module_path="x.y.Distance").module_path == "x.y.Distance"
    assert build_loss_settings().module_path.endswith("InBatchNegativeContrastiveLoss")
    assert RunnerSettings(module_path="x.y.Runner").module_path == "x.y.Runner"
    assert build_hf_settings().repo == "dummy-repo"
    assert build_sentence_transformer_loss().kwargs == {"margin": 0.1}
    assert build_evaluation_settings().precision_recall_at_k == [1, 3]
    assert build_pytorch_trainer_settings(tmp_path).seed == 42
    assert build_positive_sampler_settings().distance == build_step_range_distance_settings()
    assert build_hard_negative_miner_settings().sampling_strategy == "top"
    assert build_hard_negative_torch_dataset_settings().hard_negative_miner == build_hard_negative_miner_settings()


def test_sentence_transformers_trainer_settings_validates_when_consistent() -> None:
    settings = build_sentence_transformers_trainer_settings()
    assert settings.save_steps == 4
    assert settings.logging_steps == 1
    assert settings.loss == build_sentence_transformer_loss()
    assert settings.model == build_model_settings()


def test_sentence_transformers_trainer_settings_rejects_invalid_order() -> None:
    data = build_sentence_transformers_trainer_settings().model_dump()
    data.update({"logging_steps": 3, "eval_steps": 2, "save_steps": 4})

    with pytest.raises(ValidationError, match="logging_steps"):
        SentenceTransformersTrainerSettings[DatasetConnectorSettings, ModelSettings](**data)


def test_sentence_transformers_trainer_settings_rejects_misaligned_save_steps() -> None:
    data = build_sentence_transformers_trainer_settings().model_dump()
    data.update({"eval_steps": 3, "save_steps": 4})

    with pytest.raises(ValidationError, match="multiple of eval_steps"):
        SentenceTransformersTrainerSettings[DatasetConnectorSettings, ModelSettings](**data)
