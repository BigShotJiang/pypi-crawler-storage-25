from __future__ import annotations

from pathlib import Path

import pytest
import torch
from safetensors.torch import save_file

from tests.fixtures.components import DummyHFModel, DummyModelWrapper, build_model_settings


def test_model_save_writes_pretrained_files(tmp_path: Path) -> None:
    model = DummyModelWrapper(build_model_settings())
    repo_dir = tmp_path / "repo"

    model.save(repo_dir)

    assert (repo_dir / "dummy.bin").exists()
    assert DummyHFModel.saved_paths == [repo_dir]


def test_model_save_can_push(tmp_path: Path) -> None:
    model = DummyModelWrapper(build_model_settings())
    repo_dir = tmp_path / "repo"

    model.save(repo_dir, push=True, revision="main")

    assert DummyHFModel.pushed_payloads == [{"repo_id": "repo", "revision": "main"}]


def test_model_to_moves_hf_model() -> None:
    model = DummyModelWrapper(build_model_settings())

    returned = model.to("cpu")

    assert returned is model


def test_model_from_checkpoint_loads_pt_file(tmp_path: Path) -> None:
    model = DummyModelWrapper(build_model_settings())
    checkpoint = tmp_path / "ckpt.pt"
    torch.save(model.to_hf_model().state_dict(), checkpoint)

    restored = DummyModelWrapper.from_checkpoint(build_model_settings(), str(checkpoint), device="cpu")

    assert isinstance(restored, DummyModelWrapper)


def test_model_from_checkpoint_loads_safetensors_directory(tmp_path: Path) -> None:
    model = DummyModelWrapper(build_model_settings())
    checkpoint_dir = tmp_path / "checkpoint-dir"
    checkpoint_dir.mkdir()
    save_file(model.to_hf_model().state_dict(), str(checkpoint_dir / "model.safetensors"))

    restored = DummyModelWrapper.from_checkpoint(build_model_settings(), str(checkpoint_dir), device="cpu")

    assert isinstance(restored, DummyModelWrapper)


def test_model_from_checkpoint_raises_when_directory_has_no_safetensors(tmp_path: Path) -> None:
    checkpoint_dir = tmp_path / "checkpoint-dir"
    checkpoint_dir.mkdir()

    with pytest.raises(FileNotFoundError, match="model.safetensors"):
        DummyModelWrapper.from_checkpoint(build_model_settings(), str(checkpoint_dir), device="cpu")
