from __future__ import annotations

from pathlib import Path
from typing import Any, cast

import pytest

from embed_train.push_to_hf import PushToHFRunner
from tests.fixtures.components import (
    DummyModelWrapper,
    build_hf_settings,
    build_model_settings,
    build_push_to_hf_runner_settings,
)


def test_infer_model_name_rejects_invalid_suffix(tmp_path: Path) -> None:
    config = build_push_to_hf_runner_settings(tmp_path)
    runner = PushToHFRunner(config)
    runner.wrapper_cls = type("BrokenName", (), {})

    with pytest.raises(ValueError, match="must end"):
        runner._infer_model_name()


def test_collect_model_files_reads_supported_patterns(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = build_push_to_hf_runner_settings(tmp_path)
    runner = PushToHFRunner(config)
    runner.wrapper_cls = DummyModelWrapper
    model_dir = tmp_path / "dummy"
    model_dir.mkdir()
    for name in ("modeling_dummy.py", "configuration_dummy.py", "vllm_modeling_dummy.py"):
        (model_dir / name).write_text("# x", encoding="utf-8")
    monkeypatch.setattr(runner, "_find_model_source_dir", lambda: tmp_path)

    files = runner._collect_model_files()

    assert [path.name for path in files] == [
        "configuration_dummy.py",
        "modeling_dummy.py",
        "vllm_modeling_dummy.py",
    ]


def test_find_model_source_dir_uses_wrapper_module_path(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = build_push_to_hf_runner_settings(tmp_path)
    runner = PushToHFRunner(config)
    runner.wrapper_cls = DummyModelWrapper
    module_file = tmp_path / "wrapper.py"
    module_file.write_text("x = 1", encoding="utf-8")
    monkeypatch.setattr("embed_train.push_to_hf.inspect.getfile", lambda _: str(module_file))

    assert runner._find_model_source_dir() == tmp_path


def test_collect_model_files_raises_when_directory_missing(tmp_path: Path) -> None:
    config = build_push_to_hf_runner_settings(tmp_path)
    runner = PushToHFRunner(config)
    runner.wrapper_cls = DummyModelWrapper
    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(runner, "_find_model_source_dir", lambda: tmp_path)

    with pytest.raises(FileNotFoundError, match="Model directory"):
        runner._collect_model_files()

    monkeypatch.undo()


def test_collect_model_files_raises_when_no_source_files(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = build_push_to_hf_runner_settings(tmp_path)
    runner = PushToHFRunner(config)
    runner.wrapper_cls = DummyModelWrapper
    model_dir = tmp_path / "dummy"
    model_dir.mkdir()
    monkeypatch.setattr(runner, "_find_model_source_dir", lambda: tmp_path)

    with pytest.raises(RuntimeError, match="No model source files"):
        runner._collect_model_files()


def test_save_model_source_files_copies_content(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = build_push_to_hf_runner_settings(tmp_path, hf=build_hf_settings(repo=str(tmp_path / "repo")).model_dump())
    runner = PushToHFRunner(config)
    source = tmp_path / "modeling_dummy.py"
    source.write_text("value = 1", encoding="utf-8")
    Path(config.hf.repo).mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(runner, "_collect_model_files", lambda: [source])

    runner._save_model_source_files()

    assert (Path(config.hf.repo) / "modeling_dummy.py").read_text(encoding="utf-8") == "value = 1"


def test_load_model_uses_wrapper_checkpoint_loader(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = build_push_to_hf_runner_settings(tmp_path)
    runner = PushToHFRunner(config)
    expected = DummyModelWrapper(build_model_settings())

    monkeypatch.setattr(
        DummyModelWrapper,
        "from_checkpoint",
        classmethod(lambda cls, config, checkpoint, device: expected),
    )

    model = runner._load_model()

    assert model is expected


def test_load_wrapper_sets_wrapper_class(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = build_push_to_hf_runner_settings(tmp_path)
    runner = PushToHFRunner(config)
    monkeypatch.setattr("embed_train.push_to_hf.load_class", lambda _: DummyModelWrapper)

    runner._load_wrapper()

    assert runner.wrapper_cls is DummyModelWrapper


def test_load_model_from_checkpoint_uses_wrapper_class(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = build_push_to_hf_runner_settings(tmp_path)
    runner = PushToHFRunner(config)
    runner.wrapper_cls = DummyModelWrapper
    expected = DummyModelWrapper(build_model_settings())
    monkeypatch.setattr(
        DummyModelWrapper,
        "from_checkpoint",
        classmethod(lambda cls, config, checkpoint, device: expected),
    )

    runner._load_model_from_checkpoint()

    assert runner.model is expected


def test_save_model_locally_passes_expected_arguments(tmp_path: Path) -> None:
    config = build_push_to_hf_runner_settings(tmp_path)
    runner = PushToHFRunner(config)
    payloads: list[dict[str, object]] = []

    class DummySavedModel:
        def save(self, **kwargs: object) -> None:
            payloads.append(kwargs)

    runner.model = cast(Any, DummySavedModel())

    runner._save_model_locally()

    assert payloads == [
        {
            "repo_dir": config.hf.repo,
            "push": False,
            "create_repo": config.create_repo,
            "revision": config.hf.revision,
            "private": config.hf.private,
            "commit_message": config.hf.commit_message,
        }
    ]


def test_push_repo_to_hf_calls_upload_folder(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = build_push_to_hf_runner_settings(tmp_path)
    runner = PushToHFRunner(config)
    payloads: list[dict[str, object]] = []

    class DummyApi:
        def upload_folder(self, **kwargs: object) -> None:
            payloads.append(kwargs)

    monkeypatch.setattr("embed_train.push_to_hf.HfApi", DummyApi)

    runner._push_repo_to_hf()

    assert payloads[0]["repo_id"] == config.hf.repo
    assert payloads[0]["folder_path"] == config.hf.repo


def test_run_executes_push_flow_when_enabled(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = build_push_to_hf_runner_settings(tmp_path, push=True)
    runner = PushToHFRunner(config)
    calls: list[str] = []

    monkeypatch.setattr(runner, "_load_wrapper", lambda: calls.append("wrapper"))
    monkeypatch.setattr(runner, "_load_model_from_checkpoint", lambda: calls.append("checkpoint"))
    monkeypatch.setattr(runner, "_save_model_locally", lambda: calls.append("save"))
    monkeypatch.setattr(runner, "_save_model_source_files", lambda: calls.append("sources"))
    monkeypatch.setattr(runner, "_ensure_hf_repo_exists", lambda: calls.append("create"))
    monkeypatch.setattr(runner, "_push_repo_to_hf", lambda: calls.append("push"))

    runner.run()

    assert calls == ["wrapper", "checkpoint", "save", "sources", "create", "push"]


def test_run_skips_push_flow_when_disabled(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = build_push_to_hf_runner_settings(tmp_path, push=False)
    runner = PushToHFRunner(config)
    calls: list[str] = []

    monkeypatch.setattr(runner, "_load_wrapper", lambda: calls.append("wrapper"))
    monkeypatch.setattr(runner, "_load_model_from_checkpoint", lambda: calls.append("checkpoint"))
    monkeypatch.setattr(runner, "_save_model_locally", lambda: calls.append("save"))
    monkeypatch.setattr(runner, "_save_model_source_files", lambda: calls.append("sources"))

    runner.run()

    assert calls == ["wrapper", "checkpoint", "save", "sources"]
