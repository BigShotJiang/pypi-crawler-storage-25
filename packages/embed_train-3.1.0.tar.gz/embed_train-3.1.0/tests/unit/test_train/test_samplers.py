from embed_train.train.dataset.sampling import StepRangeDistance
from tests.fixtures.components import build_positive_sampler_settings
from tests.fixtures.data import build_sampler_item


def test_positive_sampler_samples_same_section_and_pads_anchor(monkeypatch) -> None:
    from embed_train.train.dataset.sampling.samplers import PositiveSampler

    monkeypatch.setattr(
        "embed_train.train.dataset.sampling.samplers.load_class",
        lambda _: StepRangeDistance,
    )
    sampler = PositiveSampler(build_positive_sampler_settings(k=4), context=None)
    item = build_sampler_item()

    positives = sampler.sample(item, anchor_idx=0)

    assert len(positives) == 4
    assert set(positives).issubset({"doc-1", "doc-2"})
