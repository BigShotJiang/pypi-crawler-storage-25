from embed_train.train.dataset.sampling import StepRangeDistance
from tests.fixtures.components import build_step_range_distance_settings


def test_step_range_distance_handles_overlap_and_gaps() -> None:
    distance = StepRangeDistance(build_step_range_distance_settings())
    assert distance((0, 1), (3, 4)) == 2
    assert distance((3, 4), (0, 1)) == 2
    assert distance((0, 2), (1, 3)) == 0
