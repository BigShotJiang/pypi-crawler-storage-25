from __future__ import annotations

from typing import Any, cast

import torch

from embed_train.train.dataset.collate import (
    HardNegativeCollateFn,
    InBatchNegativeCollateFn,
    MultiPositiveInBatchCollateFn,
)
from tests.fixtures.components import (
    DummyTokenizer,
    build_collate_settings,
    build_hard_negative_collate_settings,
    build_multi_positive_collate_settings,
)


def test_in_batch_positive_collate_process_batch(monkeypatch) -> None:
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )
    monkeypatch.setattr("embed_train.train.dataset.collate.random.choice", lambda values: values[0])
    collate = InBatchNegativeCollateFn(build_collate_settings(), context=None)

    q_tok, c_tok = collate(
        cast(
            Any,
            [
                {"query": "q1", "positive": "p1"},
                {"query": "q2", "positive": "p3"},
            ],
        )
    )

    assert cast(Any, q_tok)["input_ids"].shape == torch.Size([2, 3])
    assert cast(Any, c_tok)["input_ids"].shape == torch.Size([2, 3])


def test_multi_positive_collate_process_batch(monkeypatch) -> None:
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )
    monkeypatch.setattr("embed_train.train.dataset.collate.random.choice", lambda values: values[-1])
    collate = MultiPositiveInBatchCollateFn(build_multi_positive_collate_settings(), context=None)

    q_tok, c_tok = collate(cast(Any, [{"query": "q1", "positives": ["p1", "p2"]}]))

    assert cast(Any, q_tok)["input_ids"].shape == torch.Size([1, 3])
    assert cast(Any, c_tok)["input_ids"].shape == torch.Size([2, 3])


def test_hard_negative_collate_processes_negative_columns(monkeypatch) -> None:
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )
    collate = HardNegativeCollateFn(build_hard_negative_collate_settings(), context=None)

    q_tok, c_tok = collate(
        cast(
            Any,
            [
                {"query": "q1", "positive": "p1", "negative_1": "n1", "negative_2": "n2"},
                {"query": "q2", "positive": "p2", "negative_1": "n3", "negative_2": "n4"},
            ],
        )
    )

    assert cast(Any, q_tok)["input_ids"].shape == torch.Size([2, 3])
    assert cast(Any, c_tok)["input_ids"].shape == torch.Size([6, 3])
