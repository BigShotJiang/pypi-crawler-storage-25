from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, cast

import pytest
import torch

from tests.fixtures.components import DummyDatasetConnector, DummyTokenizer, build_pytorch_trainer_settings
from tests.fixtures.data import build_query_rows


def test_get_nstep_has_lower_bound() -> None:
    from embed_train.train.trainers.torch import PyTorchTrainer

    assert PyTorchTrainer.get_nstep(1) == 1
    assert PyTorchTrainer.get_nstep(102) == 2


def test_pytorch_trainer_initialization_and_helpers(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from tests.fixtures.components import DummyPyTorchTrainer

    DummyDatasetConnector.rows = build_query_rows()
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )

    class FixedDatetime:
        @classmethod
        def now(cls) -> datetime:
            return datetime(2024, 1, 2, 3, 4, 5)

    monkeypatch.setattr("embed_train.train.trainers.torch.datetime", FixedDatetime)
    trainer = DummyPyTorchTrainer(build_pytorch_trainer_settings(tmp_path))

    assert trainer.run_name == "dummypytorchtrainer_bs2_lr0.01_20240102-030405"
    assert trainer.checkpoint_dir == tmp_path / "checkpoints"
    assert cast(Any, trainer._build_collate_fn().context)["torch_dataset"] is trainer.torch_dataset


def test_pytorch_trainer_compute_val_scores_and_step(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from tests.fixtures.components import DummyPyTorchTrainer

    DummyDatasetConnector.rows = build_query_rows()
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )
    trainer = DummyPyTorchTrainer(build_pytorch_trainer_settings(tmp_path))
    batch = (
        {"input_ids": torch.tensor([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]])},
        {"input_ids": torch.tensor([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]])},
    )

    scores = trainer._compute_val_scores(batch)
    loss = trainer._step(batch)
    assert set(scores) == {
        "precision@1",
        "precision@5",
        "precision@10",
        "recall@1",
        "recall@5",
        "recall@10",
        "mrr@1",
        "mrr@5",
        "mrr@10",
        "ndcg@1",
        "ndcg@5",
        "ndcg@10",
    }
    assert loss.ndim == 0


def test_pytorch_trainer_val_scores_are_perfect_for_aligned_identity_embeddings(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from tests.fixtures.components import DummyPyTorchTrainer

    DummyDatasetConnector.rows = build_query_rows()
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )
    trainer = DummyPyTorchTrainer(build_pytorch_trainer_settings(tmp_path))
    monkeypatch.setattr(trainer, "_encode_query", lambda tokens: tokens["input_ids"])
    monkeypatch.setattr(trainer, "_encode_documents", lambda tokens: tokens["input_ids"])
    batch = (
        {"input_ids": torch.tensor([[1.0, 0.0], [0.0, 1.0]])},
        {"input_ids": torch.tensor([[1.0, 0.0], [0.0, 1.0]])},
    )

    scores = trainer._compute_val_scores(batch)

    assert scores["precision@1"] == pytest.approx(1.0)
    assert scores["recall@1"] == pytest.approx(1.0)
    assert scores["mrr@1"] == pytest.approx(1.0)
    assert scores["ndcg@1"] == pytest.approx(1.0)
    assert scores["precision@5"] == pytest.approx(0.5)
    assert scores["recall@5"] == pytest.approx(1.0)


def test_pytorch_trainer_save_and_load_checkpoint(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from tests.fixtures.components import DummyPyTorchTrainer

    DummyDatasetConnector.rows = build_query_rows()
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )
    trainer = DummyPyTorchTrainer(build_pytorch_trainer_settings(tmp_path))

    trainer.save_checkpoint(1)
    checkpoint = next((tmp_path / "checkpoints").rglob("*.pt"))
    trainer.resume_from = str(checkpoint)

    epoch = trainer.load_checkpoint()

    assert epoch == 1


def test_pytorch_trainer_load_checkpoint_returns_zero_without_resume(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from tests.fixtures.components import DummyPyTorchTrainer

    DummyDatasetConnector.rows = build_query_rows()
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )
    trainer = DummyPyTorchTrainer(build_pytorch_trainer_settings(tmp_path))

    assert trainer.load_checkpoint() == 0


def test_pytorch_trainer_load_dataloaders_and_run_epoch(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from tests.fixtures.components import DummyPyTorchTrainer

    DummyDatasetConnector.rows = build_query_rows() * 2
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )
    monkeypatch.setattr("embed_train.train.dataset.collate.random.choice", lambda values: values[0])
    trainer = DummyPyTorchTrainer(build_pytorch_trainer_settings(tmp_path, train_frac=0.5))
    train_loader, val_loader = trainer._load_dataloaders()

    train_loss = trainer.run_epoch(1, train_loader, training=True)
    val_loss = trainer.run_epoch(1, val_loader, training=False)

    assert train_loss >= 0
    assert val_loss >= 0
    assert trainer.latest_val_metrics["recall@1"] >= 0


def test_pytorch_trainer_load_dataloaders_uses_seed_for_split(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from tests.fixtures.components import DummyPyTorchTrainer

    DummyDatasetConnector.rows = [
        {
            "page_content": f"doc-{idx}",
            "metadata": {"query": f"query-{idx}", "step_range": (idx, idx + 1), "section": "test"},
        }
        for idx in range(12)
    ]
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )
    first = DummyPyTorchTrainer(build_pytorch_trainer_settings(tmp_path / "first", train_frac=0.5, seed=11))
    second = DummyPyTorchTrainer(build_pytorch_trainer_settings(tmp_path / "second", train_frac=0.5, seed=11))
    third = DummyPyTorchTrainer(build_pytorch_trainer_settings(tmp_path / "third", train_frac=0.5, seed=12))

    first_train, first_val = first._load_dataloaders()
    second_train, second_val = second._load_dataloaders()
    third_train, third_val = third._load_dataloaders()

    assert cast(Any, first_train.dataset).indices == cast(Any, second_train.dataset).indices
    assert cast(Any, first_val.dataset).indices == cast(Any, second_val.dataset).indices
    assert cast(Any, first_train.dataset).indices != cast(Any, third_train.dataset).indices
    assert cast(Any, first_val.dataset).indices != cast(Any, third_val.dataset).indices


def test_pytorch_trainer_fit_and_train(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from tests.fixtures.components import DummyPyTorchTrainer

    DummyDatasetConnector.rows = build_query_rows() * 2
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )
    monkeypatch.setattr("embed_train.train.dataset.collate.random.choice", lambda values: values[0])
    trainer = DummyPyTorchTrainer(build_pytorch_trainer_settings(tmp_path, train_frac=0.5))
    train_loader, val_loader = trainer._load_dataloaders()

    trainer._fit(train_loader, val_loader)
    trainer.train()

    saved = list((tmp_path / "checkpoints").rglob("*.pt"))
    assert saved
