from __future__ import annotations

from tests.fixtures.components import (
    DummyDatasetConnector,
    build_multi_positive_torch_dataset_settings,
    build_torch_dataset_settings,
)
from tests.fixtures.data import build_query_rows


def test_query_multi_positive_dataset_groups_rows() -> None:
    from embed_train.train.dataset.torch_datasets import QueryMultiPositiveDataset

    DummyDatasetConnector.rows = build_query_rows()
    dataset = QueryMultiPositiveDataset(build_multi_positive_torch_dataset_settings())

    assert len(dataset) == 2
    grouped = {item["query"]: item["positives"] for item in (dataset[i] for i in range(len(dataset)))}
    assert grouped["query-a"] == ["doc-1", "doc-2"]
    assert grouped["query-b"] == ["doc-3"]


def test_query_positive_dataset_flattens_rows() -> None:
    from embed_train.train.dataset.torch_datasets import QueryPositiveDataset

    DummyDatasetConnector.rows = build_query_rows()
    dataset = QueryPositiveDataset(build_torch_dataset_settings())

    assert len(dataset) == 3
    rows = {tuple(item.values()) for item in (dataset[i] for i in range(len(dataset)))}
    assert ("query-a", "doc-1") in rows
    assert ("query-a", "doc-2") in rows
    assert ("query-b", "doc-3") in rows
