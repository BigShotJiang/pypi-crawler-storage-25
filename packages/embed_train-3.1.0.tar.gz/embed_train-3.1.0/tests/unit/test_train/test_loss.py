from __future__ import annotations

import pytest
import torch

from embed_train.exceptions import EmbedTrainValueError
from embed_train.settings import HardNegativeContrastiveLossSettings
from embed_train.train.trainers.torch.loss import (
    HardNegativeContrastiveLoss,
    InBatchNegativeContrastiveLoss,
    MultiPositiveContrastiveLoss,
)
from tests.fixtures.components import build_loss_settings, build_multi_positive_loss_settings


def test_loss_normalize_returns_unit_norm_embeddings() -> None:
    loss = InBatchNegativeContrastiveLoss(build_loss_settings())
    q_emb = torch.tensor([[3.0, 4.0]])
    c_emb = torch.tensor([[5.0, 12.0]])

    q_norm, c_norm = loss.normalize(q_emb, c_emb)

    assert torch.allclose(q_norm.norm(dim=-1), torch.ones(1))
    assert torch.allclose(c_norm.norm(dim=-1), torch.ones(1))


def test_multi_positive_contrastive_loss_returns_scalar() -> None:
    loss = MultiPositiveContrastiveLoss(build_multi_positive_loss_settings())
    q_emb = torch.tensor([[1.0, 0.0], [0.0, 1.0]])
    c_emb = torch.tensor([[1.0, 0.0], [1.0, 0.0], [0.0, 1.0], [0.0, 1.0]])

    result = loss(q_emb, c_emb)

    assert result.ndim == 0
    assert result.item() >= 0


def test_in_batch_negative_contrastive_loss_returns_scalar() -> None:
    loss = InBatchNegativeContrastiveLoss(build_loss_settings())
    q_emb = torch.tensor([[1.0, 0.0], [0.0, 1.0]])
    c_emb = torch.tensor([[1.0, 0.0], [0.0, 1.0]])

    result = loss(q_emb, c_emb)

    assert result.ndim == 0
    assert result.item() >= 0


def test_hard_negative_contrastive_loss_rejects_invalid_candidate_layout() -> None:
    loss = HardNegativeContrastiveLoss(
        HardNegativeContrastiveLossSettings(
            module_path="embed_train.train.trainers.torch.loss.HardNegativeContrastiveLoss",
            temperature=0.5,
        )
    )
    q_emb = torch.tensor([[1.0, 0.0], [0.0, 1.0]])
    c_emb = torch.tensor([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])

    with pytest.raises(EmbedTrainValueError, match="one positive and at least one negative"):
        loss(q_emb, c_emb)
