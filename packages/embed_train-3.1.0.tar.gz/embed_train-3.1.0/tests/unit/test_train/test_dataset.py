from __future__ import annotations

from typing import Any, cast

import torch

from embed_train.train.dataset import CollateFn
from tests.fixtures.components import (
    DummyDatasetConnector,
    DummyTokenizer,
    build_collate_settings,
    build_multi_positive_torch_dataset_settings,
)


class ConcreteCollate(CollateFn):
    def _process_batch(self, batch):
        return ["q"], ["d"]


def test_collate_fn_post_process_uses_processor_and_tokenizer(monkeypatch) -> None:
    tokenizer = DummyTokenizer()
    monkeypatch.setattr("embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: tokenizer)
    collate = ConcreteCollate(build_collate_settings(), context=None)

    q_tok, c_tok = collate._post_process(["test_query"], ["test_candidate"])

    assert torch.is_tensor(cast(Any, q_tok)["input_ids"])
    assert torch.is_tensor(cast(Any, c_tok)["input_ids"])
    assert tokenizer.calls[0]["texts"][0].endswith(":test_query")
    assert tokenizer.calls[1]["texts"][0].endswith(":test_candidate")


def test_collate_fn_call_processes_batch(monkeypatch) -> None:
    tokenizer = DummyTokenizer()
    monkeypatch.setattr("embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: tokenizer)
    collate = ConcreteCollate(build_collate_settings(), context=None)

    queries, candidates = collate(cast(Any, [{"query": "x", "positive": "y"}]))

    assert cast(Any, queries)["input_ids"].shape == torch.Size([1, 3])
    assert cast(Any, candidates)["input_ids"].shape == torch.Size([1, 3])


def test_torch_dataset_loads_runtime_dataset_and_converts_to_hf() -> None:
    from embed_train.train.dataset.torch_datasets import QueryMultiPositiveDataset

    DummyDatasetConnector.rows = [
        {
            "page_content": "doc-1",
            "metadata": {"query": "query-a", "step_range": (0, 1), "section": "alpha"},
        },
        {
            "page_content": "doc-2",
            "metadata": {"query": "query-a", "step_range": (1, 2), "section": "alpha"},
        },
    ]
    dataset = QueryMultiPositiveDataset(build_multi_positive_torch_dataset_settings())

    hf_dataset = dataset.to_hf_dataset()

    assert len(dataset) == 1
    assert hf_dataset[0]["query"] == "query-a"
    assert hf_dataset[0]["positives"] == ["doc-1", "doc-2"]
