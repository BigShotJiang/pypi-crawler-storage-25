from __future__ import annotations

from embed_train.settings import TrainRunnerSettings
from embed_train.train import TrainRunner
from tests.fixtures.components import DummyTrainer, build_dummy_trainer_config


def test_train_runner_loads_trainer_and_runs(tmp_path, monkeypatch) -> None:
    config = TrainRunnerSettings(
        module_path="embed_train.train.TrainRunner",
        trainer=build_dummy_trainer_config(tmp_path),
    )
    DummyTrainer.runtime.calls = 0
    monkeypatch.setattr("embed_train.train.load_class", lambda _: DummyTrainer)

    runner = TrainRunner(config)
    runner.run()

    assert DummyTrainer.runtime.calls == 1
