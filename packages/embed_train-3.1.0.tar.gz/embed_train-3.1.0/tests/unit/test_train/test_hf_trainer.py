from __future__ import annotations

from pathlib import Path
from typing import Any, cast

import pytest
from datasets import Dataset

from embed_train.exceptions import EmbedTrainValueError
from tests.fixtures.components import (
    DummyModelWrapper,
    DummySentenceLoss,
    build_model_settings,
    build_sentence_transformers_trainer_runtime,
)


class DummyTransformer:
    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def get_word_embedding_dimension(self) -> int:
        return 16


class DummyPooling:
    def __init__(self, dimension: int, **kwargs):
        self.dimension = dimension
        self.kwargs = kwargs


class DummySentenceTransformer:
    def __init__(self, modules):
        self.modules = modules


class DummyTrainingArguments:
    def __init__(self, **kwargs):
        self.kwargs = kwargs


class DummySTTrainer:
    trained = False

    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def train(self) -> None:
        type(self).trained = True


class DummyEvaluator:
    def __init__(self, **kwargs):
        self.kwargs = kwargs


def test_hf_trainer_get_warmup_steps() -> None:
    trainer = build_sentence_transformers_trainer_runtime(batch_size=2, num_epochs=3, warmup_ratio=0.25)
    dataset = Dataset.from_list([{"query": "q", "document": "d"}] * 8)
    assert trainer._get_warmup_steps(dataset) == 3


def test_hf_trainer_load_model_handles_resume_and_fresh(monkeypatch: pytest.MonkeyPatch) -> None:
    trainer = build_sentence_transformers_trainer_runtime()
    monkeypatch.setattr("embed_train.train.trainers.hf.load_class", lambda _: DummyModelWrapper)
    monkeypatch.setattr(
        DummyModelWrapper,
        "from_checkpoint",
        classmethod(lambda cls, config, checkpoint, device: cls(config)),
    )

    fresh = trainer._load_model()
    resumed = build_sentence_transformers_trainer_runtime(resume_from="/tmp/ckpt.pt")._load_model()

    assert isinstance(fresh, DummyModelWrapper)
    assert isinstance(resumed, DummyModelWrapper)


def test_hf_trainer_prepare_model_path_saves_when_needed(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    trainer = build_sentence_transformers_trainer_runtime(data_dir=tmp_path)
    saved_paths: list[str] = []

    class SavableModel(DummyModelWrapper):
        def save(self, repo_dir: str | Path, push: bool = False, **push_kwargs):
            saved_paths.append(str(repo_dir))

    monkeypatch.setattr(trainer, "_load_model", lambda: SavableModel(build_model_settings()))

    path = trainer._prepare_model_path()
    resumed = build_sentence_transformers_trainer_runtime(
        data_dir=tmp_path,
        resume_from="/tmp/existing",
    )._prepare_model_path()

    assert path.endswith("_root")
    assert saved_paths == [path]
    assert resumed == "/tmp/existing"


def test_hf_trainer_load_sentence_transformer(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    trainer = build_sentence_transformers_trainer_runtime(data_dir=tmp_path, pooling="cls")
    monkeypatch.setattr(trainer, "_prepare_model_path", lambda: "/tmp/model")
    monkeypatch.setattr("embed_train.train.trainers.hf.Transformer", DummyTransformer)
    monkeypatch.setattr("embed_train.train.trainers.hf.Pooling", DummyPooling)
    monkeypatch.setattr("embed_train.train.trainers.hf.SentenceTransformer", DummySentenceTransformer)

    sentence_transformer = trainer._load_sentence_transformer()

    assert isinstance(sentence_transformer, DummySentenceTransformer)
    transformer = sentence_transformer.modules[0]
    pooling = sentence_transformer.modules[1]
    assert transformer.kwargs["model_name_or_path"] == "/tmp/model"
    assert pooling.kwargs["pooling_mode_cls_token"] is True


def test_hf_trainer_load_hf_dataset_and_evaluator(monkeypatch: pytest.MonkeyPatch) -> None:
    trainer = build_sentence_transformers_trainer_runtime()
    monkeypatch.setattr("embed_train.train.trainers.hf.InformationRetrievalEvaluator", DummyEvaluator)

    dataset = trainer._load_hf_dataset()
    evaluator = trainer._hf_dataset_to_ir_evaluator(dataset, name="val")

    assert dataset.num_rows == 4
    assert cast(Any, evaluator).kwargs["queries"] == {"q0": "q1", "q1": "q2", "q2": "q3", "q3": "q4"}
    assert cast(Any, evaluator).kwargs["relevant_docs"]["q0"] == {"d0"}


def test_hf_trainer_evaluator_raises_on_missing_column(monkeypatch: pytest.MonkeyPatch) -> None:
    trainer = build_sentence_transformers_trainer_runtime()
    trainer.config.evaluation = trainer.config.evaluation.model_copy(update={"document_column": "missing"})
    monkeypatch.setattr("embed_train.train.trainers.hf.InformationRetrievalEvaluator", DummyEvaluator)

    with pytest.raises(EmbedTrainValueError, match="Column 'missing'"):
        trainer._hf_dataset_to_ir_evaluator(trainer._load_hf_dataset(), name="val")


def test_hf_trainer_train_runs_full_flow(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    trainer = build_sentence_transformers_trainer_runtime(data_dir=tmp_path)
    DummySTTrainer.trained = False
    dataset = trainer._load_hf_dataset()
    monkeypatch.setattr(trainer, "_load_sentence_transformer", lambda: "st-model")
    monkeypatch.setattr(trainer, "_load_hf_dataset", lambda: dataset)
    monkeypatch.setattr(trainer, "_hf_dataset_to_ir_evaluator", lambda ds, name: "evaluator")
    monkeypatch.setattr(
        "embed_train.train.trainers.hf.load_class",
        lambda _: DummySentenceLoss,
    )
    monkeypatch.setattr("embed_train.train.trainers.hf.SentenceTransformerTrainingArguments", DummyTrainingArguments)
    monkeypatch.setattr("embed_train.train.trainers.hf.SentenceTransformerTrainer", DummySTTrainer)

    trainer.train()

    assert DummySTTrainer.trained is True
