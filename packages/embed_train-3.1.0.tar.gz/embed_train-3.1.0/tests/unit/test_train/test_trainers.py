from datetime import datetime

from tests.fixtures.components import build_trainer_runtime


def test_trainer_run_name_uses_module_path(tmp_path, monkeypatch) -> None:
    trainer = build_trainer_runtime(tmp_path, module_path="tests.fixtures.components.ConcreteTrainer")

    class FixedDatetime:
        @classmethod
        def now(cls) -> datetime:
            return datetime(2024, 1, 2, 3, 4, 5)

    monkeypatch.setattr("embed_train.train.trainers.datetime", FixedDatetime)

    assert trainer._run_name() == "concretetrainer_20240102-030405"
