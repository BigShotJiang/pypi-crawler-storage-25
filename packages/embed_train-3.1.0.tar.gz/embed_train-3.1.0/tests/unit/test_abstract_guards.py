from __future__ import annotations

from typing import Any, cast

import pytest
import torch

from embed_train import Runner
from embed_train.models import Model
from embed_train.train.dataset import CollateFn, TorchDataset
from embed_train.train.dataset.sampling import Distance, Sampler
from embed_train.train.trainers import Trainer
from embed_train.train.trainers.torch import PyTorchTrainer
from embed_train.train.trainers.torch.loss import Loss


def test_runner_run_base_method_raises() -> None:
    with pytest.raises(NotImplementedError):
        Runner.run(cast(Any, object()))


def test_model_to_hf_model_base_method_raises() -> None:
    with pytest.raises(NotImplementedError):
        Model.to_hf_model(cast(Any, object()))


def test_collate_fn_process_batch_base_method_raises() -> None:
    with pytest.raises(NotImplementedError):
        CollateFn._process_batch(cast(Any, object()), [])


def test_torch_dataset_len_base_method_raises() -> None:
    with pytest.raises(NotImplementedError):
        TorchDataset.__len__(cast(Any, object()))


def test_sampler_sample_base_method_returns_none() -> None:
    assert Sampler.sample(cast(Any, object()), {}) is None


def test_distance_call_base_method_raises() -> None:
    with pytest.raises(NotImplementedError):
        Distance.__call__(cast(Any, object()), (0, 1), (1, 2))


def test_trainer_train_base_method_raises() -> None:
    with pytest.raises(NotImplementedError):
        Trainer.train(cast(Any, object()))


def test_pytorch_trainer_encode_base_methods_raise() -> None:
    with pytest.raises(NotImplementedError):
        PyTorchTrainer._encode_query(cast(Any, object()), {})
    with pytest.raises(NotImplementedError):
        PyTorchTrainer._encode_documents(cast(Any, object()), {})


def test_loss_get_loss_base_method_raises() -> None:
    with pytest.raises(NotImplementedError):
        Loss._get_loss(cast(Any, object()), torch.tensor([[1.0]]), torch.tensor([[1.0]]))
