from __future__ import annotations

from pathlib import Path

import pytest
import torch
from safetensors.torch import save_file

from embed_train.utils import (
    load_checkpoint_state_dict,
    load_class,
    push_extra_files_to_hf,
    save_extra_files_locally,
)


def test_load_class_returns_symbol() -> None:
    loaded = load_class("tests.fixtures.components.DummyProcessor")
    assert loaded.__name__ == "DummyProcessor"


def test_save_extra_files_locally_copies_files(tmp_path: Path) -> None:
    src = tmp_path / "input.txt"
    src.write_text("payload", encoding="utf-8")
    target_dir = tmp_path / "target"

    save_extra_files_locally(files=[str(src)], target_dir=target_dir)

    assert (target_dir / "input.txt").read_text(encoding="utf-8") == "payload"


def test_save_extra_files_locally_raises_for_missing_file(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        save_extra_files_locally(files=[str(tmp_path / "missing.txt")], target_dir=tmp_path / "target")


def test_push_extra_files_to_hf_uploads_each_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    src = tmp_path / "weights.bin"
    src.write_text("x", encoding="utf-8")
    payloads: list[dict[str, object]] = []

    class DummyApi:
        def upload_file(self, **kwargs: object) -> None:
            payloads.append(kwargs)

    monkeypatch.setattr("embed_train.utils.HfApi", DummyApi)

    push_extra_files_to_hf(
        repo_id="demo/model",
        files=[str(src)],
        revision="main",
        commit_message="push file",
    )

    assert payloads == [
        {
            "path_or_fileobj": src,
            "path_in_repo": "weights.bin",
            "repo_id": "demo/model",
            "repo_type": "model",
            "revision": "main",
            "commit_message": "push file",
        }
    ]


def test_load_checkpoint_state_dict_reads_safetensors(tmp_path: Path) -> None:
    path = tmp_path / "model.safetensors"
    save_file({"weight": torch.ones(2)}, str(path))

    state_dict = load_checkpoint_state_dict(path)

    assert state_dict["weight"].tolist() == [1.0, 1.0]


def test_load_checkpoint_state_dict_reads_torch_and_unwraps_model_state(tmp_path: Path) -> None:
    path = tmp_path / "model.pt"
    torch.save({"model_state": {"weight": torch.arange(2)}}, path)

    state_dict = load_checkpoint_state_dict(path)

    assert state_dict["weight"].tolist() == [0, 1]


def test_load_checkpoint_state_dict_rejects_non_dict(tmp_path: Path) -> None:
    path = tmp_path / "invalid.pt"
    torch.save(["bad"], path)

    with pytest.raises(ValueError, match="state_dict"):
        load_checkpoint_state_dict(path)


def test_load_checkpoint_state_dict_rejects_non_string_keys(tmp_path: Path) -> None:
    path = tmp_path / "invalid-keys.pt"
    torch.save({1: torch.tensor([1.0])}, path)

    with pytest.raises(ValueError, match="Invalid key"):
        load_checkpoint_state_dict(path)
