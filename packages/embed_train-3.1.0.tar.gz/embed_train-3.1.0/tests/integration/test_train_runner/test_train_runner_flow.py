from pathlib import Path

from tests.fixtures.components import DummyDatasetConnector, DummyTokenizer, build_train_runner_settings
from tests.fixtures.data import build_query_rows


def test_train_runner_executes_end_to_end_training(tmp_path: Path, monkeypatch) -> None:
    from embed_train.train import TrainRunner

    DummyDatasetConnector.rows = build_query_rows() * 2
    monkeypatch.setattr(
        "embed_train.train.dataset.AutoTokenizer.from_pretrained", lambda *args, **kwargs: DummyTokenizer()
    )
    monkeypatch.setattr("embed_train.train.dataset.collate.random.choice", lambda values: values[0])
    runner = TrainRunner(build_train_runner_settings(tmp_path))

    runner.run()

    assert list((tmp_path / "checkpoints").rglob("*.pt"))
