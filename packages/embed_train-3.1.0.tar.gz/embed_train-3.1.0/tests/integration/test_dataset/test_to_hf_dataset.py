from tests.fixtures.components import DummyDatasetConnector, build_multi_positive_torch_dataset_settings
from tests.fixtures.data import build_query_rows


def test_query_multi_positive_dataset_to_hf_dataset_roundtrip() -> None:
    from embed_train.train.dataset.torch_datasets import QueryMultiPositiveDataset

    DummyDatasetConnector.rows = build_query_rows()
    dataset = QueryMultiPositiveDataset(build_multi_positive_torch_dataset_settings())

    hf_dataset = dataset.to_hf_dataset()

    assert hf_dataset.num_rows == 2
    assert sorted(hf_dataset["query"]) == ["query-a", "query-b"]
