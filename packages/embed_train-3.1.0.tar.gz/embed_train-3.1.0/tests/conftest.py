from __future__ import annotations

from importlib import import_module

from retrievalbase.connector.settings import DatasetConnectorSettings
from retrievalbase.dataset.settings import HuggingFaceDatasetAdaptaterSettings
from retrievalbase.evaluation.settings import ProcessorSettings

settings_module = import_module("embed_train.settings")
types_namespace = {
    "DatasetConnectorSettings": DatasetConnectorSettings,
    "HuggingFaceDatasetAdaptaterSettings": HuggingFaceDatasetAdaptaterSettings,
    "ProcessorSettings": ProcessorSettings,
}

for settings_cls in (
    settings_module.TorchDatasetSettings,
    settings_module.QueryMultiPositiveDatasetSettings,
    settings_module.PositiveSamplerSettings,
    settings_module.CollateFnSettings,
    settings_module.InBatchNegativeCollateFnSettings,
    settings_module.MultiPositiveInBatchCollateFnSettings,
    settings_module.PyTorchTrainerSettings,
    settings_module.SentenceTransformersTrainerSettings,
    settings_module.TrainRunnerSettings,
    settings_module.PushToHFRunnerSettings,
):
    settings_cls.model_rebuild(force=True, _types_namespace=types_namespace)

HuggingFaceDatasetAdaptaterSettings[DatasetConnectorSettings].model_rebuild(
    force=True,
    _types_namespace=types_namespace,
)
