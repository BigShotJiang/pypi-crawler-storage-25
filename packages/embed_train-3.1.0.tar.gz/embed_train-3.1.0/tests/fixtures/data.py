from __future__ import annotations

from typing import Any


def build_query_rows() -> list[dict[str, Any]]:
    return [
        {
            "page_content": "doc-1",
            "metadata": {
                "query": "query-a",
                "step_range": (0, 1),
                "section": "alpha",
            },
        },
        {
            "page_content": "doc-2",
            "metadata": {
                "query": "query-a",
                "step_range": (1, 2),
                "section": "alpha",
            },
        },
        {
            "page_content": "doc-3",
            "metadata": {
                "query": "query-b",
                "step_range": (8, 9),
                "section": "beta",
            },
        },
    ]


def build_sampler_item() -> dict[str, Any]:
    rows = build_query_rows()
    return {
        "page_content": [row["page_content"] for row in rows],
        "metadata": [row["metadata"] for row in rows],
    }
