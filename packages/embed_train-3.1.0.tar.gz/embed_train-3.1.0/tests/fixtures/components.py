from __future__ import annotations

from pathlib import Path
from typing import Any

import polars as pl
import pytest
import torch
from datasets import Dataset

from embed_train import Runner
from embed_train.models import Model
from embed_train.push_to_hf import PushToHFRunner
from embed_train.settings import (
    EvalutationSettings,
    HardNegativeCollateFnSettings,
    HardNegativeContrastiveLossSettings,
    HardNegativeDatasetSettings,
    HFSettings,
    InBatchNegativeCollateFnSettings,
    InBatchNegativeContrastiveLossSettings,
    ModelSettings,
    MultiPositiveContrastiveLossSettings,
    MultiPositiveInBatchCollateFnSettings,
    PositiveSamplerSettings,
    PushToHFRunnerSettings,
    PyTorchTrainerSettings,
    QueryMultiPositiveDatasetSettings,
    QueryPositiveDatasetSettings,
    RunnerSettings,
    SentenceTransformerHardNegativeMinerSettings,
    SentenceTransformerLoss,
    SentenceTransformersTrainerSettings,
    StepRangeDistanceSettings,
    TokenizerSettings,
    TrainerSettings,
    TrainRunnerSettings,
)
from embed_train.train import TrainRunner
from embed_train.train.trainers import Trainer
from embed_train.train.trainers.hf import SentenceTransformersTrainer
from embed_train.train.trainers.torch import PyTorchTrainer
from retrievalbase.connector.settings import DatasetConnectorSettings
from retrievalbase.dataset.settings import HuggingFaceDatasetAdaptaterSettings
from retrievalbase.evaluation.settings import ProcessorSettings
from tests.fixtures.data import build_query_rows


class DummyTextDataset:
    def __init__(self, rows: list[dict[str, Any]]) -> None:
        self.rows = rows
        self.polars = pl.DataFrame(rows)

    def __len__(self) -> int:
        return len(self.rows)


class DummyDatasetConnector:
    rows: list[dict[str, Any]] = []

    def __init__(self, config: DatasetConnectorSettings) -> None:
        self.config = config

    @classmethod
    def from_config(cls, config: DatasetConnectorSettings) -> DummyDatasetConnector:
        return cls(config)

    def load_text(self) -> DummyTextDataset:
        rows = self.rows or build_query_rows()
        return DummyTextDataset(rows)


class DummyProcessor:
    calls: list[tuple[str, str]] = []

    def __init__(self, config: ProcessorSettings) -> None:
        self.config = config

    @classmethod
    def from_config(cls, config: ProcessorSettings) -> DummyProcessor:
        return cls(config)

    def __call__(self, text: str, purpose: Any) -> str:
        self.calls.append((text, str(purpose)))
        return f"{purpose}:{text}"


class DummyTokenizer:
    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def __call__(
        self,
        texts: list[str],
        *,
        padding: str | bool,
        truncation: bool,
        max_length: int,
        return_tensors: str,
    ) -> dict[str, torch.Tensor]:
        self.calls.append(
            {
                "texts": texts,
                "padding": padding,
                "truncation": truncation,
                "max_length": max_length,
                "return_tensors": return_tensors,
            }
        )
        rows = [[len(text), len(text) + 1, len(text) + 2] for text in texts]
        return {"input_ids": torch.tensor(rows, dtype=torch.float32)}


class DummyHFModel(torch.nn.Module):
    saved_paths: list[Path] = []
    pushed_payloads: list[dict[str, Any]] = []

    def __init__(self) -> None:
        super().__init__()
        self.linear = torch.nn.Linear(3, 3)

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        return self.linear(inputs)

    def save_pretrained(self, repo_dir: Path) -> None:
        repo_dir.mkdir(parents=True, exist_ok=True)
        (repo_dir / "dummy.bin").write_text("saved", encoding="utf-8")
        self.saved_paths.append(repo_dir)

    def push_to_hub(self, *, repo_id: str, **kwargs: Any) -> None:
        self.pushed_payloads.append({"repo_id": repo_id, **kwargs})


class DummyModelWrapper(Model[ModelSettings]):
    def __init__(self, config: ModelSettings) -> None:
        super().__init__(config)
        self.hf_model = DummyHFModel()

    def to_hf_model(self) -> DummyHFModel:
        return self.hf_model


class DummyTrainerConfig(TrainerSettings):
    pass


class DummyTrainerRuntime:
    def __init__(self) -> None:
        self.calls = 0

    def train(self) -> None:
        self.calls += 1


class DummyTrainer:
    runtime = DummyTrainerRuntime()

    @classmethod
    def from_config(cls, _config: TrainerSettings) -> DummyTrainerRuntime:
        return cls.runtime


class DummyRunnerConfig(RunnerSettings):
    pass


class DummyRunner(Runner[DummyRunnerConfig]):
    def run(self) -> None:
        return None


class DummyPyTorchTrainerConfig(
    PyTorchTrainerSettings[
        ModelSettings,
        InBatchNegativeContrastiveLossSettings,
        QueryPositiveDatasetSettings[DatasetConnectorSettings],
        InBatchNegativeCollateFnSettings[ProcessorSettings],
    ]
):
    pass


class DummyPyTorchTrainer(PyTorchTrainer[DummyPyTorchTrainerConfig]):
    def _encode_query(self, tokens: dict[str, torch.Tensor]) -> torch.Tensor:
        return self.model(tokens["input_ids"])

    def _encode_documents(self, tokens: dict[str, torch.Tensor]) -> torch.Tensor:
        return self.model(tokens["input_ids"])


class NotARunner:
    pass


class DummyHFAdapter:
    def __init__(self, config: HuggingFaceDatasetAdaptaterSettings[DatasetConnectorSettings]) -> None:
        self.config = config

    @classmethod
    def from_config(cls, config: HuggingFaceDatasetAdaptaterSettings[DatasetConnectorSettings]) -> DummyHFAdapter:
        return cls(config)

    def to_hf(self) -> Dataset:
        return Dataset.from_list(
            [
                {"query": "q1", "document": "d1"},
                {"query": "q2", "document": "d2"},
                {"query": "q3", "document": "d3"},
                {"query": "q4", "document": "d4"},
            ]
        )


class DummySentenceLoss:
    def __init__(self, model: object, **kwargs: Any) -> None:
        self.model = model
        self.kwargs = kwargs


def build_tokenizer_settings(**overrides: Any) -> TokenizerSettings:
    settings = TokenizerSettings(
        name="dummy-tokenizer",
        padding=True,
        truncation=True,
        max_length=8,
    )
    return settings.model_copy(update=overrides)


def build_processor_settings(**overrides: Any) -> ProcessorSettings:
    data = {"module_path": "tests.fixtures.components.DummyProcessor"}
    data.update(overrides)
    return ProcessorSettings(**data)


def build_dataset_connector_settings(**overrides: Any) -> DatasetConnectorSettings:
    data = {"module_path": "tests.fixtures.components.DummyDatasetConnector"}
    data.update(overrides)
    return DatasetConnectorSettings(**data)


def build_torch_dataset_settings(**overrides: Any) -> QueryPositiveDatasetSettings[DatasetConnectorSettings]:
    data = {
        "module_path": "embed_train.train.dataset.torch_datasets.QueryPositiveDataset",
        "dataset_connector": build_dataset_connector_settings(),
    }
    data.update(overrides)
    return QueryPositiveDatasetSettings(**data)


def build_multi_positive_torch_dataset_settings(
    **overrides: Any,
) -> QueryMultiPositiveDatasetSettings[DatasetConnectorSettings]:
    data = {
        "module_path": "embed_train.train.dataset.torch_datasets.QueryMultiPositiveDataset",
        "dataset_connector": build_dataset_connector_settings(),
    }
    data.update(overrides)
    return QueryMultiPositiveDatasetSettings(**data)


def build_hard_negative_miner_settings(**overrides: Any) -> SentenceTransformerHardNegativeMinerSettings:
    data: dict[str, Any] = {
        "module_path": "embed_train.train.dataset.hard_negatives.SentenceTransformerHardNegativeMiner",
        "model_name_or_path": "dummy-miner",
        "tokenizer": build_tokenizer_settings(),
        "pooling": "mean_tokens",
        "range_min": 0,
        "range_max": 2,
        "relative_margin": 0.1,
        "num_negatives": 2,
        "sampling_strategy": "top",
        "batch_size": 4,
        "use_faiss": False,
        "verbose": False,
    }
    data.update(overrides)
    return SentenceTransformerHardNegativeMinerSettings(**data)


def build_hard_negative_torch_dataset_settings(
    **overrides: Any,
) -> HardNegativeDatasetSettings[DatasetConnectorSettings, SentenceTransformerHardNegativeMinerSettings]:
    data = {
        "module_path": "embed_train.train.dataset.torch_datasets.HardNegativeDataset",
        "dataset_connector": build_dataset_connector_settings(),
        "hard_negative_miner": build_hard_negative_miner_settings(),
    }
    data.update(overrides)
    return HardNegativeDatasetSettings[DatasetConnectorSettings, SentenceTransformerHardNegativeMinerSettings](**data)


def build_step_range_distance_settings(**overrides: Any) -> StepRangeDistanceSettings:
    data = {"module_path": "embed_train.train.dataset.sampling.StepRangeDistance"}
    data.update(overrides)
    return StepRangeDistanceSettings(**data)


def build_positive_sampler_settings(**overrides: Any) -> PositiveSamplerSettings[StepRangeDistanceSettings]:
    data = {
        "module_path": "embed_train.train.dataset.sampling.samplers.PositiveSampler",
        "seed": 7,
        "max_step_distance": 1,
        "distance": build_step_range_distance_settings(),
        "k": 3,
    }
    data.update(overrides)
    return PositiveSamplerSettings(**data)


def build_model_settings(**overrides: Any) -> ModelSettings:
    data = {"module_path": "tests.fixtures.components.DummyModelWrapper"}
    data.update(overrides)
    return ModelSettings(**data)


def build_loss_settings(**overrides: Any) -> InBatchNegativeContrastiveLossSettings:
    data = {
        "module_path": "embed_train.train.trainers.torch.loss.InBatchNegativeContrastiveLoss",
        "temperature": 0.5,
    }
    data.update(overrides)
    return InBatchNegativeContrastiveLossSettings(**data)


def build_multi_positive_loss_settings(**overrides: Any) -> MultiPositiveContrastiveLossSettings:
    data = {
        "module_path": "embed_train.train.trainers.torch.loss.MultiPositiveContrastiveLoss",
        "temperature": 0.5,
        "n_pos": 2,
    }
    data.update(overrides)
    return MultiPositiveContrastiveLossSettings(**data)


def build_hard_negative_loss_settings(**overrides: Any) -> HardNegativeContrastiveLossSettings:
    data = {
        "module_path": "embed_train.train.trainers.torch.loss.HardNegativeContrastiveLoss",
        "temperature": 0.5,
    }
    data.update(overrides)
    return HardNegativeContrastiveLossSettings(**data)


def build_collate_settings(**overrides: Any) -> InBatchNegativeCollateFnSettings[ProcessorSettings]:
    data = {
        "module_path": "embed_train.train.dataset.collate.InBatchNegativeCollateFn",
        "tokenizer": build_tokenizer_settings(),
        "processor": build_processor_settings(),
    }
    data.update(overrides)
    return InBatchNegativeCollateFnSettings(**data)


def build_multi_positive_collate_settings(**overrides: Any) -> MultiPositiveInBatchCollateFnSettings[ProcessorSettings]:
    data = {
        "module_path": "embed_train.train.dataset.collate.MultiPositiveInBatchCollateFn",
        "tokenizer": build_tokenizer_settings(),
        "processor": build_processor_settings(),
        "n_pos": 2,
    }
    data.update(overrides)
    return MultiPositiveInBatchCollateFnSettings(**data)


def build_hard_negative_collate_settings(**overrides: Any) -> HardNegativeCollateFnSettings[ProcessorSettings]:
    data = {
        "module_path": "embed_train.train.dataset.collate.HardNegativeCollateFn",
        "tokenizer": build_tokenizer_settings(),
        "processor": build_processor_settings(),
    }
    data.update(overrides)
    return HardNegativeCollateFnSettings(**data)


def build_pytorch_trainer_settings(tmp_path: Path, **overrides: Any) -> DummyPyTorchTrainerConfig:
    data: dict[str, Any] = {
        "module_path": "tests.fixtures.components.DummyPyTorchTrainer",
        "data_dir": tmp_path,
        "model": build_model_settings(),
        "torch_dataset": build_torch_dataset_settings(),
        "collate_fn": build_collate_settings(),
        "train_frac": 0.5,
        "num_epochs": 1,
        "batch_size": 2,
        "shuffle": True,
        "learning_rate": 0.01,
        "device": "cpu",
        "save_every": 1,
        "drop_last": False,
        "loss": build_loss_settings(),
        "resume_from": None,
    }
    data.update(overrides)
    return DummyPyTorchTrainerConfig(**data)


def build_train_runner_settings(tmp_path: Path, **overrides: Any) -> TrainRunnerSettings[DummyPyTorchTrainerConfig]:
    data = {
        "module_path": "embed_train.train.TrainRunner",
        "trainer": build_pytorch_trainer_settings(tmp_path),
    }
    data.update(overrides)
    return TrainRunnerSettings(**data)


def build_dummy_trainer_config(tmp_path: Path, **overrides: Any) -> DummyTrainerConfig:
    data = {"module_path": "tests.fixtures.components.DummyTrainer", "data_dir": tmp_path}
    data.update(overrides)
    return DummyTrainerConfig(**data)


def build_hf_settings(**overrides: Any) -> HFSettings:
    data = {
        "repo": "dummy-repo",
        "revision": "main",
        "private": False,
        "commit_message": "test commit",
    }
    data.update(overrides)
    return HFSettings(**data)


def build_push_to_hf_runner_config_data(tmp_path: Path, **overrides: Any) -> dict[str, Any]:
    data = {
        "checkpoint_path": str(tmp_path / "checkpoint.pt"),
        "device": "cpu",
        "push": False,
        "create_repo": True,
        "hf": build_hf_settings(repo=str(tmp_path / "local-repo")).model_dump(),
        "model": build_model_settings().model_dump(),
    }
    data.update(overrides)
    return data


def build_push_to_hf_runner_settings(tmp_path: Path, **overrides: Any) -> PushToHFRunnerSettings[ModelSettings]:
    data = build_push_to_hf_runner_config_data(tmp_path, **overrides)
    return PushToHFRunnerSettings[ModelSettings].model_construct(
        checkpoint_path=data["checkpoint_path"],
        device=data["device"],
        push=data["push"],
        create_repo=data["create_repo"],
        hf=build_hf_settings(**data["hf"]),
        model=build_model_settings(**data["model"]),
    )


def build_hf_dataset_adapter_settings(
    **overrides: Any,
) -> HuggingFaceDatasetAdaptaterSettings[DatasetConnectorSettings]:
    data = {
        "module_path": "tests.fixtures.components.DummyHFAdapter",
        "connector": build_dataset_connector_settings(),
        "columns_mapping": {"text": "page_content"},
    }
    data.update(overrides)
    return HuggingFaceDatasetAdaptaterSettings[DatasetConnectorSettings](**data)


def build_evaluation_settings(**overrides: Any) -> EvalutationSettings:
    data = {
        "query_column": "query",
        "document_column": "document",
        "precision_recall_at_k": [1, 3],
        "mrr_at_k": [3],
        "ndcg_at_k": [3],
        "batch_size": 4,
    }
    data.update(overrides)
    return EvalutationSettings(**data)


def build_sentence_transformer_loss(**overrides: Any) -> SentenceTransformerLoss:
    data = {"module_path": "tests.fixtures.components.DummySentenceLoss", "kwargs": {"margin": 0.1}}
    data.update(overrides)
    return SentenceTransformerLoss(**data)


def build_sentence_transformers_trainer_settings(**overrides: Any) -> SentenceTransformersTrainerSettings[Any, Any]:
    settings = SentenceTransformersTrainerSettings[DatasetConnectorSettings, ModelSettings](
        module_path="dummy.trainer",
        data_dir=Path("/tmp/data"),
        hf_dataset=build_hf_dataset_adapter_settings(),
        model=build_model_settings(),
        tokenizer=build_tokenizer_settings(),
        loss=build_sentence_transformer_loss(),
        pooling="mean_tokens",
        per_device_train_batch_size=2,
        num_epochs=1,
        learning_rate=0.01,
        warmup_ratio=0.1,
        eval_steps=2,
        save_steps=4,
        logging_steps=1,
        fp16=False,
        train_frac=0.8,
        resume_from=None,
        evaluation=build_evaluation_settings(),
    )
    return settings.model_copy(update=overrides)


def build_sentence_transformers_trainer_runtime(
    **overrides: Any,
) -> SentenceTransformersTrainer[SentenceTransformersTrainerSettings[Any, Any]]:
    return SentenceTransformersTrainer(build_sentence_transformers_trainer_settings(**overrides))


def build_train_runner_runtime(tmp_path: Path, **overrides: Any) -> Any:
    return TrainRunner(build_train_runner_settings(tmp_path, **overrides))


def build_push_to_hf_runner_runtime(tmp_path: Path, **overrides: Any) -> Any:
    return PushToHFRunner(build_push_to_hf_runner_settings(tmp_path, **overrides))


def build_trainer_runtime(tmp_path: Path, **overrides: Any) -> Trainer[DummyTrainerConfig]:
    class ConcreteTrainer(Trainer[DummyTrainerConfig]):
        def train(self) -> None:
            return None

    return ConcreteTrainer(build_dummy_trainer_config(tmp_path, **overrides))


@pytest.fixture
def query_rows() -> list[dict[str, Any]]:
    return build_query_rows()


@pytest.fixture
def dataset_connector_settings() -> DatasetConnectorSettings:
    return build_dataset_connector_settings()


@pytest.fixture
def tokenizer_settings() -> TokenizerSettings:
    return build_tokenizer_settings()


@pytest.fixture
def processor_settings() -> ProcessorSettings:
    return build_processor_settings()
