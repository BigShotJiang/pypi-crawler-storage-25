# AGENTS.md

## Purpose

This file gives coding agents project-specific guidance for working in `embed-train`.
Use it together with the repository code and tests, not as a substitute for reading the implementation.

## Project Summary

`embed-train` is a config-driven Python library for:

- training embedding models with a custom PyTorch loop
- training embedding models with SentenceTransformers
- loading components dynamically from `module_path`
- checkpointing models
- packaging and optionally pushing model repos to Hugging Face Hub

The codebase is built around small abstractions connected through typed settings objects in `src/embed_train/settings.py`.

## Source Layout

Main library code lives under `src/embed_train/`.

Key modules:

- `src/embed_train/__init__.py`
  Top-level `Runner` abstraction and YAML bootstrap via `Runner.get_runner(...)`.
- `src/embed_train/settings.py`
  Central configuration contract for runners, trainers, datasets, collate functions, losses, and HF publishing.
- `src/embed_train/models/__init__.py`
  Base `Model` wrapper abstraction with `save`, `to`, and `from_checkpoint`.
- `src/embed_train/train/__init__.py`
  `TrainRunner`, which instantiates a configured trainer and executes `train()`.
- `src/embed_train/train/trainers/torch/__init__.py`
  Custom PyTorch training loop with checkpointing, train/val split, TensorBoard logging, and pluggable loss/collate/dataset pieces.
- `src/embed_train/train/trainers/hf/__init__.py`
  SentenceTransformers-based training path with `InformationRetrievalEvaluator`.
- `src/embed_train/train/dataset/__init__.py`
  Base `TorchDataset`, `HardNegativeMiner`, and `CollateFn` abstractions.
- `src/embed_train/train/dataset/collate.py`
  Built-in collate functions for in-batch positive and hard-negative training.
- `src/embed_train/train/dataset/hard_negatives.py`
  SentenceTransformers-backed hard-negative mining implementation.
- `src/embed_train/train/dataset/torch_datasets.py`
  Built-in grouped, flattened query/positive, and hard-negative dataset views.
- `src/embed_train/train/trainers/torch/loss.py`
  Built-in contrastive losses, including hard-negative candidate ranking.
- `src/embed_train/push_to_hf/__init__.py`
  `PushToHFRunner` for checkpoint restore, local repo export, and HF upload.
- `src/embed_train/utils.py`
  Dynamic class loading and checkpoint loading utilities.

Tests live in `tests/` and are the best executable reference for intended behavior.

## Working Style For This Repo

- Read the relevant module and its tests before changing behavior.
- Treat `settings.py` as the public config contract.
- Prefer extending existing abstractions instead of bypassing them.
- Keep the config-driven architecture intact. Avoid hardcoding project-specific classes where `module_path` is the current pattern.
- Preserve typed settings and validation rules when adding new configuration.
- Keep changes small and local unless the task clearly requires a cross-cutting refactor.

## What To Check Before Editing

For most changes, inspect the matching implementation and tests together:

- runner changes:
  `src/embed_train/__init__.py`, `src/embed_train/train/__init__.py`, `src/embed_train/push_to_hf/__init__.py`
- settings changes:
  `src/embed_train/settings.py`, `tests/unit/test_settings.py`
- model wrapper changes:
  `src/embed_train/models/__init__.py`, `tests/unit/test_models.py`
- custom PyTorch trainer changes:
  `src/embed_train/train/trainers/torch/__init__.py`, `tests/unit/test_train/test_torch_trainer.py`
- dataset or collate changes:
  `src/embed_train/train/dataset/`, `tests/unit/test_train/test_dataset.py`, `tests/unit/test_train/test_collate.py`
- loss changes:
  `src/embed_train/train/trainers/torch/loss.py`, `tests/unit/test_train/test_loss.py`
- HF publishing changes:
  `src/embed_train/push_to_hf/__init__.py`, `tests/unit/test_push_to_hf.py`

## Change Guidelines

### Configuration Changes

- Add new fields in `src/embed_train/settings.py`.
- Prefer Pydantic validation for cross-field rules.
- Keep names explicit and aligned with existing settings models.
- If behavior depends on a new config field, add or update tests that validate both valid and invalid cases.

### Trainer Changes

- Maintain separation between:
  - dataset loading
  - collate/tokenization
  - embedding computation
  - loss calculation
  - checkpointing/logging
- Keep output paths consistent with the current `data_dir/checkpoints/...` and TensorBoard structure unless migration is intentional.

### Dataset and Collate Changes

- Preserve the row contracts expected by built-in collate functions:
  - grouped format: `{"query": str, "positives": list[str]}`
  - flattened format: `{"query": str, "positive": str}`
  - hard-negative format: `{"query": str, "positive": str, "negative": str}` or `negative_<n>` columns
- Keep hard-negative mining isolated behind `HardNegativeMiner`/`HardNegativeDataset` unless a task explicitly changes the abstraction boundary.
- Preserve the hard-negative candidate order expected by `HardNegativeContrastiveLoss`: one positive first, followed by one or more negatives for the same query.
- When changing row formats, update the collate functions and tests together.
- Keep tokenizer behavior explicit through settings rather than hidden defaults.

### Model and Checkpoint Changes

- `Model.to_hf_model()` should keep returning a Hugging Face-compatible model object.
- Preserve support for loading checkpoints from:
  - `.pt`-style files
  - `.safetensors`
  - directories containing `model.safetensors`
- Be careful with checkpoint loading and save format changes because they affect training and HF publishing flows.

### Hugging Face Publishing Changes

- `PushToHFRunner` currently assumes custom model source files may need to be copied into the exported repo.
- If you change the file discovery logic, keep the supported patterns aligned with the current intent:
  - `modeling_*.py`
  - `configuration_*.py`
  - `vllm_modeling_*.py`
  - `vllm_configuration_*.py`
- Avoid making remote-side effects happen implicitly. Keep `push` behavior explicit.

## Documentation Expectations

When changing public behavior, update docs in the same task when appropriate:

- `README.md` for library usage, structure, or workflows
- inline docstrings only when they add real clarity

Do not add generic documentation that is not supported by the code.

## Testing Expectations

Use the Makefile targets when possible.

Common commands:

```bash
make test
make lint
make type-check
make ci
```

Minimum expectations by change type:

- docs-only changes:
  usually no tests required
- settings or validation changes:
  run affected unit tests, ideally `make test`
- trainer, dataset, loss, or runner changes:
  run relevant unit tests and any affected integration tests
- broad behavioral changes:
  run `make ci` if feasible

If you cannot run tests, say so explicitly in the final handoff.

## Repo Conventions

- Python version target is defined in `pyproject.toml`.
- Formatting and linting use Ruff.
- Type checking uses `ty`.
- Tests use Pytest.
- The project may rely on `retrievalbase` types and mixins for configuration and dataset/processor integration.

## Agent Pitfalls To Avoid

- Do not assume this is a CLI-first project. The main contract is the Python library plus config-driven orchestration.
- Do not invent public APIs that are not present in `src/embed_train/`.
- Do not document package publishing flows unless they actually exist in the repo.
- Do not bypass dynamic imports with direct hardcoded references unless the task is specifically to remove that pattern.
- Do not change config names casually; they are effectively part of the library interface.
- Do not remove or weaken validation without a clear reason and test coverage.

## Good Agent Outcomes

A good change in this repo usually has these properties:

- it respects the current abstraction boundaries
- it updates tests with behavior changes
- it keeps configuration explicit
- it improves the library without making it more project-specific
- it leaves README and docs more accurate, not more generic
