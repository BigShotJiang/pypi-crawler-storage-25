"""Internal HTTP helpers."""

from __future__ import annotations

import json
import socket
import ssl
from collections.abc import Generator
from functools import lru_cache
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import certifi

from .errors import APIError


@lru_cache(maxsize=1)
def _default_ssl_context() -> ssl.SSLContext:
    """Build a stable CA-backed SSL context for outbound HTTPS requests."""
    return ssl.create_default_context(cafile=certifi.where())


def _urlopen(request: Request, timeout: float):
    return urlopen(request, timeout=timeout, context=_default_ssl_context())


def _auth_header(api_key: str | None) -> dict[str, str]:
    return {"x-api-key": api_key} if api_key else {}


def post_and_parse_json(
    url: str,
    *,
    body: dict[str, Any] | None = None,
    timeout: float = 30.0,
    api_key: str | None = None,
) -> Any:
    """POST to *url* and return the parsed JSON response.

    If *body* is provided it is sent as ``application/json``;
    otherwise an empty payload is sent (matching the old behaviour).
    """
    if body is not None:
        payload = json.dumps(body).encode("utf-8")
        content_type = "application/json"
    else:
        payload = b""
        content_type = "application/x-www-form-urlencoded"
    headers: dict[str, str] = {
        "accept": "application/json",
        "content-type": content_type,
        **_auth_header(api_key),
    }
    request = Request(
        url=url,
        data=payload,
        method="POST",
        headers=headers,
    )
    try:
        with _urlopen(request, timeout=timeout) as response:
            body = response.read()
    except HTTPError as exc:
        error_details = safe_parse_json(exc.read())
        raise APIError(
            status_code=exc.code,
            message=extract_error_message(error_details) or exc.reason or "API request failed",
            details=error_details,
        ) from exc
    except URLError as exc:
        reason = exc.reason
        if isinstance(reason, TimeoutError | socket.timeout):
            raise APIError(
                status_code=0,
                message=(
                    f"Request timed out after {timeout:.1f}s while calling {url}. "
                    "Try increasing the timeout in Workspace.create(timeout=...)."
                ),
            ) from exc
        raise APIError(status_code=0, message=f"Network error: {exc.reason}") from exc
    except TimeoutError as exc:
        raise APIError(
            status_code=0,
            message=(
                f"Request timed out after {timeout:.1f}s while calling {url}. "
                "Try increasing the timeout in Workspace.create(timeout=...)."
            ),
        ) from exc
    except socket.timeout as exc:
        raise APIError(
            status_code=0,
            message=(
                f"Request timed out after {timeout:.1f}s while calling {url}. "
                "Try increasing the timeout in Workspace.create(timeout=...)."
            ),
        ) from exc

    return safe_parse_json(body)


def get_and_parse_json(url: str, timeout: float, *, api_key: str | None = None) -> Any:
    """GET from *url* and return the parsed JSON response."""
    request = Request(
        url=url,
        method="GET",
        headers={"accept": "application/json", **_auth_header(api_key)},
    )
    try:
        with _urlopen(request, timeout=timeout) as response:
            body = response.read()
    except HTTPError as exc:
        error_details = safe_parse_json(exc.read())
        raise APIError(
            status_code=exc.code,
            message=extract_error_message(error_details) or exc.reason or "API request failed",
            details=error_details,
        ) from exc
    except URLError as exc:
        reason = exc.reason
        if isinstance(reason, TimeoutError | socket.timeout):
            raise APIError(
                status_code=0,
                message=f"Request timed out after {timeout:.1f}s while calling {url}.",
            ) from exc
        raise APIError(status_code=0, message=f"Network error: {exc.reason}") from exc
    except (TimeoutError, socket.timeout) as exc:
        raise APIError(
            status_code=0,
            message=f"Request timed out after {timeout:.1f}s while calling {url}.",
        ) from exc

    return safe_parse_json(body)


def delete_and_parse_json(url: str, timeout: float, *, api_key: str | None = None) -> Any:
    request = Request(
        url=url,
        method="DELETE",
        headers={"accept": "application/json", **_auth_header(api_key)},
    )
    try:
        with _urlopen(request, timeout=timeout) as response:
            body = response.read()
    except HTTPError as exc:
        error_details = safe_parse_json(exc.read())
        raise APIError(
            status_code=exc.code,
            message=extract_error_message(error_details) or exc.reason or "API request failed",
            details=error_details,
        ) from exc
    except URLError as exc:
        reason = exc.reason
        if isinstance(reason, TimeoutError | socket.timeout):
            raise APIError(
                status_code=0,
                message=(
                    f"Request timed out after {timeout:.1f}s while calling {url}. "
                    "Try increasing the timeout in Workspace.create(timeout=...)."
                ),
            ) from exc
        raise APIError(status_code=0, message=f"Network error: {exc.reason}") from exc
    except TimeoutError as exc:
        raise APIError(
            status_code=0,
            message=(
                f"Request timed out after {timeout:.1f}s while calling {url}. "
                "Try increasing the timeout in Workspace.create(timeout=...)."
            ),
        ) from exc
    except socket.timeout as exc:
        raise APIError(
            status_code=0,
            message=(
                f"Request timed out after {timeout:.1f}s while calling {url}. "
                "Try increasing the timeout in Workspace.create(timeout=...)."
            ),
        ) from exc

    return safe_parse_json(body)


def _iter_sse(response) -> Generator[tuple[str, Any], None, None]:
    event_type = ""
    data_buf = ""
    for raw_line in response:
        line = raw_line.decode("utf-8", errors="replace").rstrip("\n").rstrip("\r")
        if line.startswith("event:"):
            event_type = line[len("event:"):].strip()
        elif line.startswith("data:"):
            data_buf += line[len("data:"):].strip()
        elif line == "":
            if data_buf:
                parsed = safe_parse_json(data_buf.encode("utf-8"))
                yield (event_type or "message", parsed)
            event_type = ""
            data_buf = ""


def post_stream_sse(
    url: str,
    *,
    body: dict[str, Any] | None = None,
    timeout: float,
    api_key: str | None = None,
) -> Generator[tuple[str, Any], None, None]:
    """POST to an SSE endpoint and yield (event_type, parsed_data) tuples."""
    if body is not None:
        payload = json.dumps(body).encode("utf-8")
        content_type = "application/json"
    else:
        payload = b""
        content_type = "application/x-www-form-urlencoded"
    request = Request(
        url=url,
        data=payload,
        method="POST",
        headers={
            "accept": "text/event-stream",
            "content-type": content_type,
            **_auth_header(api_key),
        },
    )
    try:
        response = _urlopen(request, timeout=timeout)
    except HTTPError as exc:
        error_details = safe_parse_json(exc.read())
        raise APIError(
            status_code=exc.code,
            message=extract_error_message(error_details) or exc.reason or "SSE request failed",
            details=error_details,
        ) from exc
    except URLError as exc:
        reason = exc.reason
        if isinstance(reason, TimeoutError | socket.timeout):
            raise APIError(
                status_code=0,
                message=f"SSE connection timed out after {timeout:.1f}s while calling {url}.",
            ) from exc
        raise APIError(status_code=0, message=f"Network error: {exc.reason}") from exc
    except (TimeoutError, socket.timeout) as exc:
        raise APIError(
            status_code=0,
            message=f"SSE connection timed out after {timeout:.1f}s while calling {url}.",
        ) from exc

    try:
        yield from _iter_sse(response)
    finally:
        response.close()


def stream_sse(
    url: str,
    timeout: float,
    *,
    api_key: str | None = None,
) -> Generator[tuple[str, Any], None, None]:
    """Open a GET request to an SSE endpoint and yield (event_type, parsed_data) tuples."""
    request = Request(
        url=url,
        method="GET",
        headers={"accept": "text/event-stream", **_auth_header(api_key)},
    )
    try:
        response = _urlopen(request, timeout=timeout)
    except HTTPError as exc:
        error_details = safe_parse_json(exc.read())
        raise APIError(
            status_code=exc.code,
            message=extract_error_message(error_details) or exc.reason or "SSE request failed",
            details=error_details,
        ) from exc
    except URLError as exc:
        reason = exc.reason
        if isinstance(reason, TimeoutError | socket.timeout):
            raise APIError(
                status_code=0,
                message=f"SSE connection timed out after {timeout:.1f}s while calling {url}.",
            ) from exc
        raise APIError(status_code=0, message=f"Network error: {exc.reason}") from exc
    except (TimeoutError, socket.timeout) as exc:
        raise APIError(
            status_code=0,
            message=f"SSE connection timed out after {timeout:.1f}s while calling {url}.",
        ) from exc

    try:
        yield from _iter_sse(response)
    finally:
        response.close()


def safe_parse_json(data: bytes) -> Any:
    text = data.decode("utf-8", errors="replace").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text


def extract_error_message(details: Any) -> str | None:
    if isinstance(details, dict):
        detail_value = details.get("detail")
        if isinstance(detail_value, str):
            return detail_value
        if isinstance(detail_value, list) and detail_value:
            first = detail_value[0]
            if isinstance(first, dict):
                message = first.get("msg")
                if isinstance(message, str):
                    return message
    return None
