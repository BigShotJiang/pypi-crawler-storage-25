"""Pi-agent subagent and workspace clients.

Mirrors the /pi-agent/* endpoints exposed by the Funky API router
(apps/api/app/routers/workspaces_with_pi_agent.py).
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Generator
from dataclasses import dataclass
from typing import Any
from urllib.parse import quote, urlencode

from ._http import (
    delete_and_parse_json,
    get_and_parse_json,
    post_and_parse_json,
    post_stream_sse,
)
from .constants import DEFAULT_BASE_URL, DEFAULT_TIMEOUT_SECONDS
from .errors import APIError

DEFAULT_POLL_INTERVAL_SECONDS = 2.0
DEFAULT_READY_TIMEOUT_SECONDS = 300.0


@dataclass(frozen=True, slots=True)
class PiAgentSessionSummary:
    id: str
    model: str
    created_at: int
    updated_at: int
    message_count: int
    first_message: str


@dataclass(frozen=True, slots=True)
class PiAgentLastMessage:
    role: str
    text: str
    timestamp: int


@dataclass(frozen=True, slots=True)
class PiAgentSessionAnalysis:
    id: str
    total_tokens: int
    total_cost: float
    last_message: PiAgentLastMessage | None


@dataclass(frozen=True, slots=True)
class PiAgentCreateSessionResponse:
    session_id: str
    model: str | None


@dataclass(frozen=True, slots=True)
class PiAgentModelAndSystemPrompt:
    model: str
    system_prompt: str | None
    updated_live_sessions: int | None = None


@dataclass(frozen=True, slots=True)
class SubAgentMessage:
    role: str
    text: str
    raw: dict[str, Any]


def _parse_model_and_system_prompt_response(response: Any) -> PiAgentModelAndSystemPrompt:
    if not isinstance(response, dict) or not isinstance(response.get("model"), str):
        raise APIError(
            status_code=200,
            message="Unexpected response format: expected object with model",
            details=response,
        )
    system_prompt = response.get("systemPrompt", response.get("system_prompt"))
    if system_prompt is not None and not isinstance(system_prompt, str):
        raise APIError(
            status_code=200,
            message="Unexpected response format: expected system prompt string",
            details=response,
        )
    updated_raw = response.get("updatedLiveSessions", response.get("updated_live_sessions"))
    updated_live_sessions = int(updated_raw) if updated_raw is not None else None
    return PiAgentModelAndSystemPrompt(
        model=response["model"],
        system_prompt=system_prompt,
        updated_live_sessions=updated_live_sessions,
    )


def _extract_message_text(message: dict[str, Any]) -> str:
    content = message.get("content")
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return ""

    chunks: list[str] = []
    for item in content:
        if isinstance(item, str):
            chunks.append(item)
        elif isinstance(item, dict):
            text = item.get("text")
            if isinstance(text, str):
                chunks.append(text)
    return "".join(chunks)


def _parse_subagent_message(message: Any) -> SubAgentMessage | None:
    if not isinstance(message, dict):
        return None
    role = message.get("role")
    if not isinstance(role, str):
        return None
    return SubAgentMessage(role=role, text=_extract_message_text(message), raw=message)


def _stream_error_message(data: Any) -> str:
    if isinstance(data, dict):
        error = data.get("error")
        if isinstance(error, str):
            return error
    return "Sub-agent stream returned an error"


@dataclass(frozen=True, slots=True)
class PiAgentSyncthingInfo:
    service_name: str
    external_ip: str | None
    sync_address: str | None
    device_id: str | None
    folder_id: str


class PiAgentWorkspace:
    """Client for a pi-agent workspace and its sessions."""

    def __init__(
        self,
        claim_name: str,
        namespace: str,
        pod_name: str,
        base_url: str,
        timeout: float,
        api_key: str | None = None,
    ) -> None:
        self.claim_name = claim_name
        self.namespace = namespace
        self.pod_name = pod_name
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._api_key = api_key

    # ── Lifecycle ───────────────────────────────────────────────────────

    @classmethod
    def create(
        cls,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        poll_interval: float = DEFAULT_POLL_INTERVAL_SECONDS,
        ready_timeout: float = DEFAULT_READY_TIMEOUT_SECONDS,
        api_key: str | None = None,
    ) -> "PiAgentWorkspace":
        """Create a pi-agent workspace and poll until the pod is Running."""
        response = post_and_parse_json(
            url=f"{base_url.rstrip('/')}/pi-agent/workspaces-with-pi-agent",
            timeout=timeout,
            api_key=api_key,
        )
        return cls._wait_until_ready(
            create_response=response,
            base_url=base_url,
            timeout=timeout,
            poll_interval=poll_interval,
            ready_timeout=ready_timeout,
            api_key=api_key,
        )

    @classmethod
    def _wait_until_ready(
        cls,
        *,
        create_response: Any,
        base_url: str,
        timeout: float,
        poll_interval: float,
        ready_timeout: float,
        api_key: str | None = None,
    ) -> "PiAgentWorkspace":
        if not isinstance(create_response, dict) or not isinstance(
            create_response.get("claim_name"), str
        ):
            raise APIError(
                status_code=200,
                message="Unexpected response format: expected object with claim_name",
                details=create_response,
            )
        claim_name: str = create_response["claim_name"]
        namespace: str = create_response.get("namespace", "")

        normalized_url = base_url.rstrip("/")
        deadline = time.monotonic() + ready_timeout
        status_payload: Any = None
        pod_name = ""
        while True:
            status_payload = get_and_parse_json(
                url=(
                    f"{normalized_url}/pi-agent/workspaces/{quote(claim_name, safe='')}/status"
                    f"?{urlencode({'namespace': namespace})}"
                ),
                timeout=timeout,
                api_key=api_key,
            )
            if isinstance(status_payload, dict):
                phase = status_payload.get("status")
                candidate_pod = status_payload.get("pod_name")
                if phase == "Running" and isinstance(candidate_pod, str) and candidate_pod:
                    pod_name = candidate_pod
                    break
                if phase == "Failed":
                    raise APIError(
                        status_code=500,
                        message="Pi-agent workspace failed to start",
                        details=status_payload,
                    )
            if time.monotonic() > deadline:
                raise APIError(
                    status_code=0,
                    message=f"Pi-agent workspace did not become ready within {ready_timeout:.1f}s",
                    details=status_payload,
                )
            time.sleep(poll_interval)

        return cls(
            claim_name=claim_name,
            namespace=namespace,
            pod_name=pod_name,
            base_url=base_url,
            timeout=timeout,
            api_key=api_key,
        )

    def get_status(self) -> dict:
        """Return current workspace Pod phase and pod_name."""
        return get_and_parse_json(
            url=(
                f"{self._base_url}/pi-agent/workspaces/{quote(self.claim_name, safe='')}/status"
                f"?{urlencode({'namespace': self.namespace})}"
            ),
            timeout=self._timeout,
            api_key=self._api_key,
        )

    async def delete(self) -> dict:
        """Delete this workspace's claim (DELETE /workspaces/{claim_name})."""
        return await asyncio.to_thread(
            delete_and_parse_json,
            (
                f"{self._base_url}/workspaces/{quote(self.claim_name, safe='')}"
                f"?{urlencode({'namespace': self.namespace})}"
            ),
            self._timeout,
            api_key=self._api_key,
        )

    # ── Sessions ────────────────────────────────────────────────────────

    def _session_qs(self) -> str:
        return urlencode({"namespace": self.namespace, "pod_name": self.pod_name})

    def get_model_and_system_prompt(self) -> PiAgentModelAndSystemPrompt:
        """Return the workspace-global model and appended system prompt."""
        response = get_and_parse_json(
            url=(
                f"{self._base_url}/pi-agent/workspaces/{quote(self.claim_name, safe='')}"
                f"/model_and_system_prompt?{self._session_qs()}"
            ),
            timeout=self._timeout,
            api_key=self._api_key,
        )
        return _parse_model_and_system_prompt_response(response)

    def set_model_and_system_prompt(
        self,
        *,
        model: str,
        system: str,
    ) -> PiAgentModelAndSystemPrompt:
        """Set the workspace-global model and extra system prompt for new sessions."""
        response = post_and_parse_json(
            url=(
                f"{self._base_url}/pi-agent/workspaces/{quote(self.claim_name, safe='')}"
                f"/set_model_and_system_prompt?{self._session_qs()}"
            ),
            body={"model": model, "systemPrompt": system},
            timeout=self._timeout,
            api_key=self._api_key,
        )
        return _parse_model_and_system_prompt_response(response)

    def create_session(self) -> PiAgentCreateSessionResponse:
        """Create a new agent session using this workspace's global model setting."""
        response = post_and_parse_json(
            url=(
                f"{self._base_url}/pi-agent/workspaces/{quote(self.claim_name, safe='')}/sessions"
                f"?{self._session_qs()}"
            ),
            timeout=self._timeout,
            api_key=self._api_key,
        )
        if not isinstance(response, dict) or not isinstance(response.get("sessionId"), str):
            raise APIError(
                status_code=200,
                message="Unexpected response format: expected object with sessionId",
                details=response,
            )
        return PiAgentCreateSessionResponse(
            session_id=response["sessionId"],
            model=response.get("model"),
        )

    def list_sessions(self) -> list[PiAgentSessionSummary]:
        """List all sessions in this workspace's pod."""
        response = get_and_parse_json(
            url=(
                f"{self._base_url}/pi-agent/workspaces/{quote(self.claim_name, safe='')}/sessions"
                f"?{self._session_qs()}"
            ),
            timeout=self._timeout,
            api_key=self._api_key,
        )
        if not isinstance(response, dict) or not isinstance(response.get("sessions"), list):
            raise APIError(
                status_code=200,
                message="Unexpected response format: expected object with sessions array",
                details=response,
            )
        return [
            PiAgentSessionSummary(
                id=item["id"],
                model=item.get("model", "unknown"),
                created_at=int(item.get("createdAt", 0)),
                updated_at=int(item.get("updatedAt", 0)),
                message_count=int(item.get("messageCount", 0)),
                first_message=item.get("firstMessage", ""),
            )
            for item in response["sessions"]
            if isinstance(item, dict) and isinstance(item.get("id"), str)
        ]

    def get_session(self, session_id: str) -> dict:
        """Return a session's full message history and streaming state."""
        return get_and_parse_json(
            url=(
                f"{self._base_url}/pi-agent/workspaces/{quote(self.claim_name, safe='')}"
                f"/sessions/{quote(session_id, safe='')}"
                f"?{self._session_qs()}"
            ),
            timeout=self._timeout,
            api_key=self._api_key,
        )

    def get_session_analysis(self, session_id: str) -> PiAgentSessionAnalysis:
        """Return aggregated totals (tokens, cost) and the last message for a session."""
        response = get_and_parse_json(
            url=(
                f"{self._base_url}/pi-agent/workspaces/{quote(self.claim_name, safe='')}"
                f"/sessions/{quote(session_id, safe='')}/analysis"
                f"?{self._session_qs()}"
            ),
            timeout=self._timeout,
            api_key=self._api_key,
        )
        if not isinstance(response, dict) or not isinstance(response.get("id"), str):
            raise APIError(
                status_code=200,
                message="Unexpected response format: expected analysis object",
                details=response,
            )
        last_raw = response.get("lastMessage")
        last_message: PiAgentLastMessage | None = None
        if isinstance(last_raw, dict):
            last_message = PiAgentLastMessage(
                role=last_raw.get("role", "unknown"),
                text=last_raw.get("text", ""),
                timestamp=int(last_raw.get("timestamp", 0)),
            )
        return PiAgentSessionAnalysis(
            id=response["id"],
            total_tokens=int(response.get("totalTokens", 0)),
            total_cost=float(response.get("totalCost", 0.0)),
            last_message=last_message,
        )

    def stream_message(
        self,
        session_id: str,
        text: str,
        *,
        timeout: float | None = None,
    ) -> Generator[tuple[str, Any], None, None]:
        """Send a user message and yield (event_type, data) tuples from the SSE stream.

        Event types include: agent_start, turn_start, message_start, message_update,
        message_end, tool_execution_start, tool_execution_update, tool_execution_end,
        turn_end, agent_end, error.
        """
        yield from post_stream_sse(
            url=(
                f"{self._base_url}/pi-agent/workspaces/{quote(self.claim_name, safe='')}"
                f"/sessions/{quote(session_id, safe='')}/messages"
                f"?{self._session_qs()}"
            ),
            body={"text": text},
            timeout=timeout if timeout is not None else self._timeout,
            api_key=self._api_key,
        )

    def send_message(
        self,
        session_id: str,
        text: str,
        *,
        timeout: float | None = None,
    ) -> Generator[tuple[str, Any], None, None]:
        """Backward-compatible alias for stream_message."""
        yield from self.stream_message(session_id, text, timeout=timeout)

    # ── Syncthing ───────────────────────────────────────────────────────

    def get_syncthing_info(self) -> PiAgentSyncthingInfo:
        """Return syncthing connection info (external IP, device ID, folder ID)."""
        response = get_and_parse_json(
            url=(
                f"{self._base_url}/pi-agent/workspaces/{quote(self.claim_name, safe='')}"
                f"/syncthing/info?{self._session_qs()}"
            ),
            timeout=self._timeout,
            api_key=self._api_key,
        )
        if not isinstance(response, dict) or not isinstance(response.get("service_name"), str):
            raise APIError(
                status_code=200,
                message="Unexpected response format: expected syncthing info object",
                details=response,
            )
        return PiAgentSyncthingInfo(
            service_name=response["service_name"],
            external_ip=response.get("external_ip"),
            sync_address=response.get("sync_address"),
            device_id=response.get("device_id"),
            folder_id=response.get("folder_id", "default"),
        )

    def pair_syncthing(self, device_id: str, device_name: str = "desktop") -> dict:
        """Authorize a desktop device and share the workspace folder with it."""
        return post_and_parse_json(
            url=(
                f"{self._base_url}/pi-agent/syncthing/pair"
                f"?{urlencode({'namespace': self.namespace, 'pod_name': self.pod_name})}"
            ),
            body={"device_id": device_id, "device_name": device_name},
            timeout=self._timeout,
            api_key=self._api_key,
        )


class SubAgent:
    """High-level client for one pi-agent subagent session."""

    def __init__(
        self,
        *,
        name: str,
        model: str,
        system: str,
        workspace: PiAgentWorkspace,
        session_id: str,
    ) -> None:
        self.name = name
        self.model = model
        self.system = system
        self.workspace = workspace
        self.session_id = session_id

    @classmethod
    def create(
        cls,
        *,
        name: str,
        model: str,
        system: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        poll_interval: float = DEFAULT_POLL_INTERVAL_SECONDS,
        ready_timeout: float = DEFAULT_READY_TIMEOUT_SECONDS,
        api_key: str | None = None,
    ) -> "SubAgent":
        """Create a pi-agent workspace, configure it, and start one session."""
        workspace = PiAgentWorkspace.create(
            base_url=base_url,
            timeout=timeout,
            poll_interval=poll_interval,
            ready_timeout=ready_timeout,
            api_key=api_key,
        )
        workspace.set_model_and_system_prompt(model=model, system=system)
        session = workspace.create_session()
        return cls(
            name=name,
            model=session.model or model,
            system=system,
            workspace=workspace,
            session_id=session.session_id,
        )

    @property
    def claim_name(self) -> str:
        return self.workspace.claim_name

    @property
    def namespace(self) -> str:
        return self.workspace.namespace

    @property
    def pod_name(self) -> str:
        return self.workspace.pod_name

    def get_session(self) -> dict:
        """Return this subagent session's full message history and streaming state."""
        return self.workspace.get_session(self.session_id)

    def get_session_analysis(self) -> PiAgentSessionAnalysis:
        """Return aggregated totals and the last message for this subagent session."""
        return self.workspace.get_session_analysis(self.session_id)

    def stream_message(
        self,
        text: str,
        *,
        timeout: float | None = None,
    ) -> Generator[tuple[str, Any], None, None]:
        """Send a user message to this subagent and stream response events."""
        yield from self.workspace.stream_message(self.session_id, text, timeout=timeout)

    def send_message(
        self,
        text: str,
        *,
        timeout: float | None = None,
    ) -> list[SubAgentMessage]:
        """Send a user message and return completed assistant messages."""
        messages: list[SubAgentMessage] = []
        for event_type, data in self.stream_message(text, timeout=timeout):
            if event_type == "error":
                raise APIError(
                    status_code=0,
                    message=_stream_error_message(data),
                    details=data,
                )
            if event_type == "message_end" and isinstance(data, dict):
                message = _parse_subagent_message(data.get("message"))
                if message is not None and message.role == "assistant":
                    messages.append(message)
            elif event_type == "agent_end" and not messages and isinstance(data, dict):
                raw_messages = data.get("messages")
                if isinstance(raw_messages, list):
                    for raw_message in raw_messages:
                        message = _parse_subagent_message(raw_message)
                        if message is not None and message.role == "assistant":
                            messages.append(message)
        return messages

    async def delete(self) -> dict:
        """Delete the underlying pi-agent workspace."""
        return await self.workspace.delete()
