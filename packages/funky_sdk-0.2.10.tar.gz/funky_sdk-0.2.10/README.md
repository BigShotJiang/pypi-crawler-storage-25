# funky-sdk

Python SDK for creating and talking to Funky pi-agent subagents.

## Install

```bash
uv sync
```

## Usage

```python
from funky import SubAgent

agent = SubAgent.create(
    name="Coding Assistant",
    model="claude-opus-4-7",
    system="You are a helpful coding assistant. Write clean, well-documented code.",
)

messages = agent.send_message("Create a small Python CLI that prints hello.")
for message in messages:
    print(message.text)
```

## Streaming

```python
for event_type, event in agent.stream_message("Add tests for that CLI."):
    if event_type == "message_update":
        message = event.get("message", {})
        content = message.get("content", [])
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                print(item.get("text", ""), end="")
```

## API Behavior

- `SubAgent.create(...)` creates a pi-agent workspace, sets the global model and appended system prompt for that workspace, then creates one session.
- `agent.send_message(text)` waits for the subagent to finish and returns completed assistant messages.
- `agent.stream_message(text)` yields raw SSE events for live UI and progress output.
- Returned `SubAgentMessage` objects expose `role`, `text`, and `raw`.
- The subagent exposes `name`, `model`, `system`, `session_id`, `claim_name`, `namespace`, and `pod_name`.
