from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import pytest

import funky._http
from funky import PiAgentWorkspace, SubAgent


@dataclass
class FakeResponse:
    body: bytes

    def read(self) -> bytes:
        return self.body

    def __enter__(self) -> FakeResponse:
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:
        return False


@dataclass
class FakeSSEResponse:
    lines: list[bytes]

    def __iter__(self):
        return iter(self.lines)

    def close(self) -> None:
        pass


def make_sse_lines(events: list[tuple[str, dict[str, Any]]]) -> list[bytes]:
    lines: list[bytes] = []
    for event_type, data in events:
        lines.append(f"event: {event_type}\n".encode("utf-8"))
        lines.append(f"data: {json.dumps(data)}\n".encode("utf-8"))
        lines.append(b"\n")
    return lines


def message(role: str, text: str) -> dict[str, Any]:
    return {"role": role, "content": [{"type": "text", "text": text}], "timestamp": 1}


def fake_pi_agent_urlopen(captured: list[tuple[str, str, dict[str, Any] | None]]):
    def fake_urlopen(request, timeout: float, context=None):
        body = json.loads(request.data.decode("utf-8")) if request.data else None
        captured.append((request.get_method(), request.full_url, body))

        if request.full_url.endswith("/pi-agent/workspaces-with-pi-agent"):
            return FakeResponse(
                b'{"claim_name":"pi-claim-1","namespace":"pi-ns","status":"creating"}'
            )
        if "/pi-agent/workspaces/pi-claim-1/status" in request.full_url:
            return FakeResponse(b'{"status":"Running","pod_name":"pi-pod-1"}')
        if "/set_model_and_system_prompt" in request.full_url:
            return FakeResponse(
                b'{"model":"claude-opus-4-7","systemPrompt":"Be helpful","updatedLiveSessions":0}'
            )
        if "/model_and_system_prompt" in request.full_url:
            return FakeResponse(
                b'{"model":"claude-opus-4-7","systemPrompt":"Be helpful"}'
            )
        if "/sessions/session-1/messages" in request.full_url:
            return FakeSSEResponse(
                make_sse_lines(
                    [
                        (
                            "message_end",
                            {"type": "message_end", "message": message("user", "Hi")},
                        ),
                        (
                            "message_update",
                            {
                                "type": "message_update",
                                "message": message("assistant", "Hel"),
                            },
                        ),
                        (
                            "message_end",
                            {
                                "type": "message_end",
                                "message": message("assistant", "Hello"),
                            },
                        ),
                        (
                            "message_end",
                            {
                                "type": "message_end",
                                "message": message("assistant", "Done"),
                            },
                        ),
                        (
                            "agent_end",
                            {
                                "type": "agent_end",
                                "messages": [
                                    message("assistant", "Hello"),
                                    message("assistant", "Done"),
                                ],
                            },
                        ),
                    ]
                )
            )
        if request.full_url.endswith("sessions?namespace=pi-ns&pod_name=pi-pod-1"):
            return FakeResponse(b'{"sessionId":"session-1","model":"claude-opus-4-7"}')
        return FakeResponse(b"{}")

    return fake_urlopen


def test_pi_agent_workspace_uses_global_settings_endpoints(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_pi_agent_urlopen(captured))

    workspace = PiAgentWorkspace.create(poll_interval=0.0)
    settings = workspace.set_model_and_system_prompt(
        model="claude-opus-4-7",
        system="Be helpful",
    )
    fetched = workspace.get_model_and_system_prompt()
    session = workspace.create_session()

    assert settings.model == "claude-opus-4-7"
    assert settings.system_prompt == "Be helpful"
    assert settings.updated_live_sessions == 0
    assert fetched.model == "claude-opus-4-7"
    assert session.session_id == "session-1"

    set_request = [item for item in captured if "/set_model_and_system_prompt" in item[1]][0]
    session_request = [
        item
        for item in captured
        if item[1].endswith("/sessions?namespace=pi-ns&pod_name=pi-pod-1")
    ][0]
    assert set_request[2] == {"model": "claude-opus-4-7", "systemPrompt": "Be helpful"}
    assert session_request[2] is None


def test_subagent_create_configures_workspace_then_creates_session(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_pi_agent_urlopen(captured))

    agent = SubAgent.create(
        name="Coding Assistant",
        model="claude-opus-4-7",
        system="Be helpful",
        poll_interval=0.0,
    )

    assert agent.name == "Coding Assistant"
    assert agent.model == "claude-opus-4-7"
    assert agent.system == "Be helpful"
    assert agent.session_id == "session-1"
    assert agent.claim_name == "pi-claim-1"
    assert agent.namespace == "pi-ns"
    assert agent.pod_name == "pi-pod-1"

    endpoint_order = [url.rsplit("/", 1)[-1].split("?", 1)[0] for _, url, _ in captured]
    assert endpoint_order == [
        "workspaces-with-pi-agent",
        "status",
        "set_model_and_system_prompt",
        "sessions",
    ]


def test_subagent_send_message_returns_all_completed_assistant_messages(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_pi_agent_urlopen(captured))

    agent = SubAgent.create(
        name="Coding Assistant",
        model="claude-opus-4-7",
        system="Be helpful",
        poll_interval=0.0,
    )
    messages = agent.send_message("Hi")

    assert [item.role for item in messages] == ["assistant", "assistant"]
    assert [item.text for item in messages] == ["Hello", "Done"]
    message_request = [
        item for item in captured if "/sessions/session-1/messages" in item[1]
    ][0]
    assert message_request[2] == {"text": "Hi"}


def test_subagent_stream_message_yields_raw_stream_events(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[tuple[str, str, dict[str, Any] | None]] = []
    monkeypatch.setattr(funky._http, "urlopen", fake_pi_agent_urlopen(captured))

    agent = SubAgent.create(
        name="Coding Assistant",
        model="claude-opus-4-7",
        system="Be helpful",
        poll_interval=0.0,
    )
    events = list(agent.stream_message("Hi"))

    assert [event_type for event_type, _ in events] == [
        "message_end",
        "message_update",
        "message_end",
        "message_end",
        "agent_end",
    ]
    assert events[1][1]["message"]["content"][0]["text"] == "Hel"

