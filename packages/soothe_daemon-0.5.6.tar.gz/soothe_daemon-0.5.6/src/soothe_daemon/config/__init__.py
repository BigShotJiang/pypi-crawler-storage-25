"""Daemon configuration: ``SootheDaemonConfig`` + nested schemas."""

from soothe_daemon.config.env import apply_env_overrides
from soothe_daemon.config.models import (
    DistributedConfig,
    HttpRestConfig,
    RayClusterConfig,
    TransportConfig,
    WebSocketConfig,
    WorkerPoolConfig,
)
from soothe_daemon.config.settings import (
    SootheDaemonConfig,
    default_daemon_config_path,
    default_soothe_config_path,
)

__all__ = [
    "DistributedConfig",
    "HttpRestConfig",
    "RayClusterConfig",
    "SootheDaemonConfig",
    "TransportConfig",
    "WebSocketConfig",
    "WorkerPoolConfig",
    "apply_env_overrides",
    "default_daemon_config_path",
    "default_soothe_config_path",
]
