# Homebrew formula for ainfera-verify.
#
# This is the source-of-truth copy. On release, copy it to the
# ainfera/homebrew-tap repo as Formula/verify.rb so users can:
#
#   brew install ainfera/tap/verify
#
# RELEASE STEPS (cannot be completed until ainfera-verify 0.1.0 is on PyPI):
#   1. Publish 0.1.0 to PyPI.
#   2. Fill in `url` + `sha256` below from the PyPI sdist
#      (https://pypi.org/pypi/ainfera-verify/0.1.0/json -> urls[].digests.sha256).
#   3. Generate the `resource` stanzas for every dependency:
#        brew update-python-resources Formula/verify.rb
#      (run from a checkout of the tap, with the formula's url/sha256 set).
#   4. `brew install --build-from-source ./Formula/verify.rb` to smoke-test.
#   5. Open the PR against ainfera/homebrew-tap.

class Verify < Formula
  include Language::Python::Virtualenv

  desc "Offline verifier for Ainfera AuditChains"
  homepage "https://ainfera.ai/docs/verify"
  url "https://files.pythonhosted.org/packages/source/a/ainfera-verify/ainfera_verify-0.1.0.tar.gz"
  sha256 "REPLACE_WITH_SDIST_SHA256_AFTER_PYPI_PUBLISH"
  license "Apache-2.0"

  depends_on "python@3.12"
  depends_on "rust" => :build # cryptography builds native extensions

  # `brew update-python-resources` populates the resource stanzas for
  # typer, httpx, rich, cryptography and their transitive dependencies.
  # Do not hand-write them — regenerate on every version bump.

  def install
    virtualenv_install_with_resources
  end

  test do
    assert_match "ainfera-verify #{version}", shell_output("#{bin}/ainfera-verify --version")
    # Non-existent bundle path exits 2 (fetch/parse error class).
    output = shell_output("#{bin}/ainfera-verify bundle /nonexistent.zip", 2)
    assert_match "Error", output
  end
end
