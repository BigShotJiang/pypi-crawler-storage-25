# ainfera-verify

> Trust no one. Verify the chain yourself.

`ainfera-verify` is the public, offline verifier for [Ainfera](https://ainfera.ai) AuditChains. It lets anyone — regulator, auditor, partner, curious developer — fetch an Agent's AuditChain and cryptographically verify it without trusting Ainfera or holding an Ainfera account.

This is the customer trust primitive behind Ainfera's audit-grade transparency claim: chain of custody you can check yourself.

## Install

```bash
pip install ainfera-verify
```

Or with Homebrew:

```bash
brew install ainfera/tap/verify
```

## Usage

Verify a full AuditChain by Agent ID (fetches from the public read endpoint, then verifies offline):

```bash
ainfera-verify chain manwe
```

Inspect a single AuditEvent:

```bash
ainfera-verify event manwe 1245
```

Verify an offline Annex IV bundle export (use this for air-gapped review):

```bash
ainfera-verify bundle ./manwe-2026-05-19.zip
```

## What it verifies

For every `AuditEvent` in the chain:

1. **Hash continuity** — `previous_hash` matches the prior event's `event_hash`.
2. **Event integrity** — `event_hash` is the SHA-256 of `previous_hash || canonical_json(payload)`.
3. **HMAC signature** — `hmac_signature` validates against Ainfera's published public key.
4. **Sigstore signature** — when present, validated against the Rekor transparency log.

If any check fails, the verifier reports the exact `seq` where the chain breaks.

## Trust model

- The CLI ships under Apache 2.0. The verification logic is auditable.
- After events are fetched, verification is fully offline — no network calls, no Ainfera dependency.
- Ainfera's HMAC public key is published at [`https://ainfera.ai/.well-known/ainfera-public-key.json`](https://ainfera.ai/.well-known/ainfera-public-key.json) and cached locally.
- For air-gapped verification, download the key once or use a bundle export (which embeds the key).

## EU AI Act Annex IV

Annex IV technical documentation requires verifiable evidence of system behavior. `ainfera-verify bundle` produces a pass/fail with the cryptographic chain of custody — sufficient evidence for a regulator's technical reviewer.

## Web version

Don't want to install anything? Drop a bundle into [verify.ainfera.ai](https://verify.ainfera.ai). All verification runs in your browser.

## License

Apache 2.0. See [LICENSE](LICENSE).
