"""Offline verifier for Ainfera AuditChains."""

from ainfera_verify.chain import (
    GENESIS_HASH,
    AuditEvent,
    ChainVerifyResult,
    canonical_json,
    compute_event_hash,
    verify_chain,
)

__version__ = "0.1.0"

__all__ = [
    "AuditEvent",
    "ChainVerifyResult",
    "GENESIS_HASH",
    "canonical_json",
    "compute_event_hash",
    "verify_chain",
    "__version__",
]
