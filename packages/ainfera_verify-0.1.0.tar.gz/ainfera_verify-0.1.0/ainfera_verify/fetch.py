"""HTTP client for Ainfera's public read endpoints and well-known key.

Per API Contract v1.0, public AuditChains are readable without auth. The CLI
treats the API as a delivery mechanism only — every event is re-hashed and
re-verified locally, so a malicious response cannot mint a passing chain.
"""

from __future__ import annotations

import base64
from typing import Any

import httpx

from ainfera_verify.chain import AuditEvent

DEFAULT_BASE_URL = "https://api.ainfera.ai"
DEFAULT_WELL_KNOWN_URL = "https://ainfera.ai/.well-known/ainfera-public-key.json"


class FetchError(RuntimeError):
    pass


def fetch_public_key(
    well_known_url: str = DEFAULT_WELL_KNOWN_URL,
    *,
    client: httpx.Client | None = None,
) -> bytes:
    """Fetch and decode the HMAC verification key.

    Expects ``{"hmac_key_b64": "<base64>"}``. Returns raw key bytes.
    """

    own_client = client is None
    client = client or httpx.Client(timeout=15.0)
    try:
        resp = client.get(well_known_url)
        resp.raise_for_status()
        data = resp.json()
    except httpx.HTTPError as exc:
        raise FetchError(f"could not fetch public key from {well_known_url}: {exc}") from exc
    finally:
        if own_client:
            client.close()

    key_b64 = data.get("hmac_key_b64")
    if not key_b64:
        raise FetchError(f"public key document missing 'hmac_key_b64' at {well_known_url}")
    return base64.b64decode(key_b64)


def fetch_chain(
    agent_id: str,
    *,
    base_url: str = DEFAULT_BASE_URL,
    client: httpx.Client | None = None,
    page_size: int = 500,
) -> list[AuditEvent]:
    """Fetch every AuditEvent for an agent, paginated by seq.

    Returns events in seq order. Raises FetchError on any HTTP failure.
    """

    own_client = client is None
    client = client or httpx.Client(timeout=30.0)
    events: list[AuditEvent] = []
    cursor: int | None = None

    try:
        while True:
            params: dict[str, Any] = {"limit": page_size}
            if cursor is not None:
                params["after_seq"] = cursor

            try:
                resp = client.get(
                    f"{base_url}/v1/agents/{agent_id}/audit-chain",
                    params=params,
                )
                resp.raise_for_status()
            except httpx.HTTPError as exc:
                raise FetchError(f"chain fetch failed for {agent_id}: {exc}") from exc

            body = resp.json()
            page = body.get("events", [])
            for raw in page:
                events.append(AuditEvent.from_dict(raw))

            if not body.get("has_more") or not page:
                break
            cursor = page[-1]["seq"]
    finally:
        if own_client:
            client.close()

    events.sort(key=lambda e: e.seq)
    return events


def fetch_event(
    agent_id: str,
    seq: int,
    *,
    base_url: str = DEFAULT_BASE_URL,
    client: httpx.Client | None = None,
) -> AuditEvent:
    own_client = client is None
    client = client or httpx.Client(timeout=15.0)
    try:
        try:
            resp = client.get(f"{base_url}/v1/agents/{agent_id}/audit-chain/{seq}")
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            raise FetchError(f"event fetch failed for {agent_id}:{seq}: {exc}") from exc
        return AuditEvent.from_dict(resp.json())
    finally:
        if own_client:
            client.close()
