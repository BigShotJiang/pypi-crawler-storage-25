"""AuditChain walk + hash recomputation.

Per Ontology v1.0 §2, each AuditEvent commits to its predecessor via
``previous_hash``, and ``event_hash = sha256(previous_hash || canonical_json(payload))``.
The first event in a chain references ``GENESIS_HASH``.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any

from ainfera_verify.signatures import verify_hmac, verify_sigstore

GENESIS_HASH = "0" * 64


@dataclass
class AuditEvent:
    """An AuditEvent as fetched from the public read API.

    Field set mirrors Ontology v1.0 §2. Optional fields default to None so
    bundles produced by older agents still parse.
    """

    agent_id: str
    seq: int
    event_type: str
    timestamp: str
    payload: dict[str, Any]
    previous_hash: str
    event_hash: str
    hmac_signature: str
    payload_hash: str | None = None
    sigstore_sig: dict[str, Any] | None = None
    receipt_url: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AuditEvent:
        return cls(
            agent_id=data["agent_id"],
            seq=int(data["seq"]),
            event_type=data["event_type"],
            timestamp=data["timestamp"],
            payload=data["payload"],
            previous_hash=data["previous_hash"],
            event_hash=data["event_hash"],
            hmac_signature=data["hmac_signature"],
            payload_hash=data.get("payload_hash"),
            sigstore_sig=data.get("sigstore_sig"),
            receipt_url=data.get("receipt_url"),
            raw=data,
        )


@dataclass
class ChainVerifyResult:
    ok: bool
    events_verified: int = 0
    broken_at_seq: int | None = None
    reason: str | None = None
    expected: str | None = None
    actual: str | None = None
    genesis_hash: str = GENESIS_HASH
    tip_hash: str | None = None


def canonical_json(payload: Any) -> str:
    """Deterministic JSON encoding used for hash inputs.

    Must match the producer side exactly. Sorted keys, no whitespace, UTF-8,
    ``ensure_ascii=False`` so non-ASCII bytes are encoded directly.
    """

    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def compute_event_hash(previous_hash: str, payload: Any) -> str:
    data = previous_hash.encode("utf-8") + canonical_json(payload).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def verify_chain(
    events: list[AuditEvent],
    hmac_public_key: bytes,
    *,
    verify_sigstore_sigs: bool = False,
) -> ChainVerifyResult:
    """Walk events in seq order, recomputing hashes and verifying signatures.

    Returns at the first broken link. Caller decides how to render the result.
    """

    if not events:
        return ChainVerifyResult(ok=True, events_verified=0, tip_hash=GENESIS_HASH)

    ordered = sorted(events, key=lambda e: e.seq)
    expected_previous = GENESIS_HASH
    tip_hash = GENESIS_HASH

    for event in ordered:
        if event.previous_hash != expected_previous:
            return ChainVerifyResult(
                ok=False,
                broken_at_seq=event.seq,
                reason="previous_hash mismatch",
                expected=expected_previous,
                actual=event.previous_hash,
            )

        computed = compute_event_hash(event.previous_hash, event.payload)
        if computed != event.event_hash:
            return ChainVerifyResult(
                ok=False,
                broken_at_seq=event.seq,
                reason="event_hash mismatch",
                expected=computed,
                actual=event.event_hash,
            )

        if not verify_hmac(event.event_hash, event.hmac_signature, hmac_public_key):
            return ChainVerifyResult(
                ok=False,
                broken_at_seq=event.seq,
                reason="hmac signature invalid",
            )

        if verify_sigstore_sigs and event.sigstore_sig:
            if not verify_sigstore(event.event_hash, event.sigstore_sig):
                return ChainVerifyResult(
                    ok=False,
                    broken_at_seq=event.seq,
                    reason="sigstore signature invalid",
                )

        expected_previous = event.event_hash
        tip_hash = event.event_hash

    return ChainVerifyResult(
        ok=True,
        events_verified=len(ordered),
        tip_hash=tip_hash,
    )
