"""Signature verification: HMAC (mandatory) and Sigstore (D14+ optional).

Ainfera signs each AuditEvent's ``event_hash`` with HMAC-SHA256 using a key
whose verification half is published at
``https://ainfera.ai/.well-known/ainfera-public-key.json``.

Sigstore signatures use ephemeral keys via Fulcio CA, transparency-logged
in Rekor. They wrap the same ``event_hash``. We keep the integration behind
a flag because ``sigstore-python`` is heavy and not all bundles carry one.
"""

from __future__ import annotations

import hashlib
import hmac
from typing import Any


def verify_hmac(event_hash: str, signature_hex: str, key: bytes) -> bool:
    """Constant-time check of HMAC-SHA256 over the event_hash hex string.

    The producer signs the hex-encoded ``event_hash`` (not the raw bytes) so
    signatures are stable across canonicalization boundaries.
    """

    expected = hmac.new(key, event_hash.encode("utf-8"), hashlib.sha256).hexdigest()
    try:
        provided = signature_hex.lower()
    except AttributeError:
        return False
    return hmac.compare_digest(expected, provided)


def verify_sigstore(event_hash: str, sigstore_sig: dict[str, Any]) -> bool:
    """Verify a Sigstore signature against Rekor.

    Stub for the v0.1.0 cut. We accept any signature whose ``payload_hash``
    field matches the event_hash and whose ``verified`` flag is set by the
    bundle producer — appropriate for offline bundle review where Rekor has
    already been consulted at export time. Online verification against
    Rekor lands once we wire ``sigstore-python``; see AIN-46.
    """

    if not isinstance(sigstore_sig, dict):
        return False
    if sigstore_sig.get("payload_hash") != event_hash:
        return False
    return bool(sigstore_sig.get("verified"))
