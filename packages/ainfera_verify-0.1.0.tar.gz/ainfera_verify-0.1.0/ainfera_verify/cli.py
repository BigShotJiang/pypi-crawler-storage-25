"""typer entry point for ainfera-verify.

Three commands — chain, event, bundle — map to the three ways a verifier
meets an AuditChain: live by agent id, a single event, or an offline export.
"""

from __future__ import annotations

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn

from ainfera_verify import __version__
from ainfera_verify.bundle import BundleError, load_bundle
from ainfera_verify.chain import verify_chain
from ainfera_verify.fetch import (
    DEFAULT_BASE_URL,
    DEFAULT_WELL_KNOWN_URL,
    FetchError,
    fetch_chain,
    fetch_event,
    fetch_public_key,
)
from ainfera_verify.render import (
    console,
    render_bundle_result,
    render_chain_result,
    render_event,
)
from ainfera_verify.signatures import verify_hmac, verify_sigstore

app = typer.Typer(
    name="ainfera-verify",
    help="Offline verifier for Ainfera AuditChains. Trust no one — verify the chain yourself.",
    add_completion=False,
    no_args_is_help=True,
)


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"ainfera-verify {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False, "--version", callback=_version_callback, is_eager=True, help="Show version and exit."
    ),
) -> None:
    pass


@app.command()
def chain(
    agent_id: str = typer.Argument(..., help="Agent ID whose AuditChain to verify."),
    base_url: str = typer.Option(DEFAULT_BASE_URL, help="Ainfera public API base URL."),
    well_known_url: str = typer.Option(DEFAULT_WELL_KNOWN_URL, help="HMAC public key URL."),
    sigstore: bool = typer.Option(False, help="Also verify Sigstore signatures when present."),
) -> None:
    """Fetch and verify a full AuditChain by Agent ID."""

    with Progress(
        SpinnerColumn(), TextColumn("{task.description}"), transient=True, console=console
    ) as progress:
        progress.add_task(f"Fetching AuditChain for agent '{agent_id}'...", total=None)
        try:
            key = fetch_public_key(well_known_url)
            events = fetch_chain(agent_id, base_url=base_url)
        except FetchError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(code=2) from exc

    console.print(f"[green]✅ Fetched {len(events)} AuditEvents[/green]")
    console.print("Verifying hash chain...")

    result = verify_chain(events, key, verify_sigstore_sigs=sigstore)
    render_chain_result(agent_id, events, result)
    raise typer.Exit(code=0 if result.ok else 1)


@app.command()
def event(
    agent_id: str = typer.Argument(..., help="Agent ID."),
    seq: int = typer.Argument(..., help="Sequence number of the event."),
    base_url: str = typer.Option(DEFAULT_BASE_URL, help="Ainfera public API base URL."),
    well_known_url: str = typer.Option(DEFAULT_WELL_KNOWN_URL, help="HMAC public key URL."),
) -> None:
    """Inspect and verify a single AuditEvent."""

    try:
        key = fetch_public_key(well_known_url)
        ev = fetch_event(agent_id, seq, base_url=base_url)
    except FetchError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=2) from exc

    hmac_ok = verify_hmac(ev.event_hash, ev.hmac_signature, key)
    sigstore_ok = verify_sigstore(ev.event_hash, ev.sigstore_sig) if ev.sigstore_sig else None
    render_event(ev, hmac_ok=hmac_ok, sigstore_ok=sigstore_ok)

    ok = hmac_ok and (sigstore_ok is None or sigstore_ok)
    raise typer.Exit(code=0 if ok else 1)


@app.command()
def bundle(
    path: str = typer.Argument(..., help="Path to an Annex IV bundle .zip export."),
    sigstore: bool = typer.Option(False, help="Also verify Sigstore signatures when present."),
) -> None:
    """Verify an offline Annex IV bundle export."""

    console.print("Parsing bundle...")
    try:
        b = load_bundle(path)
    except BundleError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=2) from exc

    console.print("[green]✅ Bundle metadata valid[/green]")
    console.print(
        f"[green]✅ AuditChain manifest matches bundle contents ({len(b.events)} events)[/green]"
    )
    console.print("Verifying chain...")

    result = verify_chain(b.events, b.hmac_public_key, verify_sigstore_sigs=sigstore)
    render_bundle_result(b, result)
    raise typer.Exit(code=0 if result.ok else 1)


if __name__ == "__main__":
    app()
