"""Annex IV bundle parser.

A bundle is a zip with:
  - manifest.json   — bundle metadata, agent_id, issued_at, issuer identity
  - events.jsonl    — one AuditEvent per line, seq-ordered
  - public_key.json — same shape as the well-known doc; embedded so the bundle
                      is self-contained for air-gapped verification
"""

from __future__ import annotations

import base64
import json
import zipfile
from dataclasses import dataclass
from pathlib import Path

from ainfera_verify.chain import AuditEvent


@dataclass
class Bundle:
    manifest: dict
    events: list[AuditEvent]
    hmac_public_key: bytes
    path: Path


class BundleError(RuntimeError):
    pass


def load_bundle(path: str | Path) -> Bundle:
    path = Path(path)
    if not path.exists():
        raise BundleError(f"bundle not found: {path}")

    try:
        with zipfile.ZipFile(path, "r") as zf:
            names = set(zf.namelist())
            for required in ("manifest.json", "events.jsonl", "public_key.json"):
                if required not in names:
                    raise BundleError(f"bundle missing required file: {required}")

            manifest = json.loads(zf.read("manifest.json"))
            key_doc = json.loads(zf.read("public_key.json"))
            events_raw = zf.read("events.jsonl").decode("utf-8")
    except zipfile.BadZipFile as exc:
        raise BundleError(f"not a valid zip file: {path}") from exc

    key_b64 = key_doc.get("hmac_key_b64")
    if not key_b64:
        raise BundleError("public_key.json missing 'hmac_key_b64'")
    hmac_key = base64.b64decode(key_b64)

    events: list[AuditEvent] = []
    for line_num, line in enumerate(events_raw.splitlines(), start=1):
        line = line.strip()
        if not line:
            continue
        try:
            events.append(AuditEvent.from_dict(json.loads(line)))
        except (json.JSONDecodeError, KeyError) as exc:
            raise BundleError(f"events.jsonl line {line_num}: {exc}") from exc

    events.sort(key=lambda e: e.seq)
    return Bundle(manifest=manifest, events=events, hmac_public_key=hmac_key, path=path)
