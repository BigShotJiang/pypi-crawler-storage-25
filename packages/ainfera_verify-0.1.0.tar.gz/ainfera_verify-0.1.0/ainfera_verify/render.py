"""Rich-based terminal rendering for verify results.

Kept in a single module so the CLI stays declarative and so non-CLI consumers
(tests, the web build) can opt out of rich entirely.
"""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ainfera_verify.bundle import Bundle
from ainfera_verify.chain import AuditEvent, ChainVerifyResult

console = Console()


def render_chain_result(
    agent_id: str,
    events: list[AuditEvent],
    result: ChainVerifyResult,
) -> None:
    if result.ok:
        console.print(f"[green]✅ Chain intact — {result.events_verified} events verified[/green]")
        console.print()
        if events:
            console.print(f"Genesis hash: [dim]{result.genesis_hash}[/dim]")
            console.print(f"Tip hash:     [bold]{result.tip_hash}[/bold]")
            console.print(f"First event:  {events[0].timestamp}")
            console.print(f"Last event:   {events[-1].timestamp}")
            console.print()
            console.print(
                f"Run [cyan]ainfera-verify event {agent_id} <seq>[/cyan] "
                "to inspect a specific event."
            )
        return

    console.print(f"[red]❌ Chain broken at seq {result.broken_at_seq}[/red]")
    console.print(f"Reason: [yellow]{result.reason}[/yellow]")
    if result.expected and result.actual:
        console.print(f"Expected: [dim]{result.expected}[/dim]")
        console.print(f"Actual:   [dim]{result.actual}[/dim]")
    console.print()
    console.print(
        f"Run [cyan]ainfera-verify event {agent_id} {result.broken_at_seq}[/cyan] to inspect."
    )


def render_event(
    event: AuditEvent,
    *,
    hmac_ok: bool | None = None,
    sigstore_ok: bool | None = None,
) -> None:
    table = Table(show_header=False, box=None, pad_edge=False)
    table.add_column(style="bold")
    table.add_column()

    table.add_row("agent_id:", event.agent_id)
    table.add_row("seq:", str(event.seq))
    table.add_row("event_type:", event.event_type)
    table.add_row("timestamp:", event.timestamp)

    provider = event.payload.get("provider")
    model = event.payload.get("model")
    cost = event.payload.get("cost_usd")
    if provider:
        table.add_row("", "")
        table.add_row("Provider:", str(provider))
    if model:
        table.add_row("Model:", str(model))
    if cost is not None:
        table.add_row("Cost (USD):", f"{cost}")

    table.add_row("", "")
    if event.payload_hash:
        table.add_row("payload_hash:", _short(event.payload_hash))
    table.add_row("previous_hash:", _short(event.previous_hash))
    table.add_row("event_hash:", _short(event.event_hash))

    if hmac_ok is not None:
        table.add_row(
            "hmac signature:",
            "[green]✅ verified[/green]" if hmac_ok else "[red]❌ invalid[/red]",
        )
    if sigstore_ok is not None:
        table.add_row(
            "sigstore sig:",
            "[green]✅ verified[/green]" if sigstore_ok else "[red]❌ invalid[/red]",
        )

    if event.receipt_url:
        table.add_row("", "")
        table.add_row("Receipt:", event.receipt_url)

    console.print(Panel(table, title="AuditEvent", border_style="cyan"))


def render_bundle_result(bundle: Bundle, result: ChainVerifyResult) -> None:
    if not result.ok:
        console.print(
            f"[red]❌ Bundle verification failed at seq "
            f"{result.broken_at_seq}: {result.reason}[/red]"
        )
        return

    manifest = bundle.manifest
    console.print(f"[green]✅ {result.events_verified} events verified[/green]")
    console.print("[green]✅ HMAC signatures valid[/green]")
    if manifest.get("sigstore_verified"):
        log = manifest.get("sigstore_log", "rekor.sigstore.dev")
        console.print(
            f"[green]✅ Sigstore signatures valid (transparency log: {log})[/green]"
        )
    console.print()
    console.print("[bold]Bundle is genuine. Cryptographic chain of custody verified.[/bold]")
    if manifest.get("issuer"):
        console.print(f"Issued by:    {manifest['issuer']}")
    if manifest.get("issued_at"):
        console.print(f"Issued at:    {manifest['issued_at']}")
    if manifest.get("agent_id"):
        tenant = manifest.get("tenant")
        if tenant:
            console.print(f"Agent:        {manifest['agent_id']} (Tenant: {tenant})")
        else:
            console.print(f"Agent:        {manifest['agent_id']}")
    if manifest.get("use_for"):
        console.print(f"Use for:      {manifest['use_for']}")


def _short(h: str) -> str:
    return f"{h[:10]}..." if len(h) > 16 else h
