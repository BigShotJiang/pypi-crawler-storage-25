from typer.testing import CliRunner

from ainfera_verify import __version__
from ainfera_verify.cli import app

runner = CliRunner()


def test_version():
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert __version__ in result.stdout


def test_bundle_command_intact(bundle_path):
    result = runner.invoke(app, ["bundle", str(bundle_path)])
    assert result.exit_code == 0
    assert "1247 events verified" in result.stdout
    assert "Bundle is genuine" in result.stdout


def test_bundle_command_broken(broken_events, tmp_path):
    import base64
    import json
    import zipfile

    from tests.conftest import TEST_HMAC_KEY

    path = tmp_path / "broken.zip"
    key_doc = {"hmac_key_b64": base64.b64encode(TEST_HMAC_KEY).decode("ascii")}
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("manifest.json", json.dumps({"agent_id": "manwe"}))
        zf.writestr("events.jsonl", "\n".join(json.dumps(e.raw) for e in broken_events))
        zf.writestr("public_key.json", json.dumps(key_doc))

    result = runner.invoke(app, ["bundle", str(path)])
    assert result.exit_code == 1
    assert "seq 500" in result.stdout


def test_bundle_command_missing_file(tmp_path):
    result = runner.invoke(app, ["bundle", str(tmp_path / "nope.zip")])
    assert result.exit_code == 2
    assert "Error" in result.stdout
