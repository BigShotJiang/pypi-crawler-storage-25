"""Regenerate test fixtures. Run from repo root: python tests/_generate_fixtures.py

Produces:
  tests/fixtures/manwe_chain_intact.json
  tests/fixtures/manwe_chain_broken_at_500.json
  tests/fixtures/annex_iv_bundle.zip

The HMAC key below is a throwaway test key — never used in production.
"""

from __future__ import annotations

import base64
import copy
import hashlib
import hmac
import json
import zipfile
from pathlib import Path

from ainfera_verify.chain import GENESIS_HASH, canonical_json, compute_event_hash

FIXTURES = Path(__file__).parent / "fixtures"
TEST_HMAC_KEY = b"ainfera-test-hmac-key-do-not-use-in-prod"
N_EVENTS = 1247
PROVIDERS = ["anthropic", "openai", "google"]
MODELS = ["claude-sonnet-4-6", "gpt-4o", "gemini-2.0-pro"]


def _hmac(event_hash: str) -> str:
    return hmac.new(TEST_HMAC_KEY, event_hash.encode("utf-8"), hashlib.sha256).hexdigest()


def build_chain(n: int) -> list[dict]:
    events: list[dict] = []
    previous_hash = GENESIS_HASH
    for seq in range(1, n + 1):
        payload = {
            "provider": PROVIDERS[seq % 3],
            "model": MODELS[seq % 3],
            "cost_usd": round(0.001 * (seq % 50) + 0.0034, 4),
            "privacy_mode": "content_masked",
            "tokens_in": 100 + seq,
            "tokens_out": 50 + seq,
        }
        payload_hash = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
        event_hash = compute_event_hash(previous_hash, payload)
        events.append(
            {
                "agent_id": "manwe",
                "seq": seq,
                "event_type": "inference.routed",
                "timestamp": f"2026-05-14T08:{seq % 60:02d}:{(seq * 7) % 60:02d}Z",
                "payload": payload,
                "payload_hash": payload_hash,
                "previous_hash": previous_hash,
                "event_hash": event_hash,
                "hmac_signature": _hmac(event_hash),
                "receipt_url": f"https://ainfera.ai/receipts/r_manwe_{seq}",
            }
        )
        previous_hash = event_hash
    return events


def main() -> None:
    FIXTURES.mkdir(parents=True, exist_ok=True)
    intact = build_chain(N_EVENTS)

    (FIXTURES / "manwe_chain_intact.json").write_text(
        json.dumps({"agent_id": "manwe", "events": intact}, indent=2)
    )

    # Broken chain: tamper payload at seq 500 but leave the stored event_hash,
    # so recomputation fails at exactly seq 500.
    broken = copy.deepcopy(intact)
    broken[499]["payload"]["cost_usd"] = broken[499]["payload"]["cost_usd"] + 0.0001
    (FIXTURES / "manwe_chain_broken_at_500.json").write_text(
        json.dumps({"agent_id": "manwe", "events": broken}, indent=2)
    )

    # Annex IV bundle: a self-contained zip over the intact chain.
    key_doc = {
        "hmac_key_b64": base64.b64encode(TEST_HMAC_KEY).decode("ascii"),
        "alg": "HMAC-SHA256",
    }
    manifest = {
        "bundle_version": "1.0",
        "agent_id": "manwe",
        "tenant": "Ainfera Inc.",
        "issuer": "Ainfera Inc. (sigstore identity: ainfera-prod@ainfera.ai)",
        "issued_at": "2026-05-19T23:00:00Z",
        "event_count": len(intact),
        "use_for": "EU AI Act Annex IV technical documentation",
        "sigstore_verified": False,
    }
    events_jsonl = "\n".join(json.dumps(e) for e in intact)
    bundle_path = FIXTURES / "annex_iv_bundle.zip"
    with zipfile.ZipFile(bundle_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps(manifest, indent=2))
        zf.writestr("events.jsonl", events_jsonl)
        zf.writestr("public_key.json", json.dumps(key_doc, indent=2))

    print(f"Wrote {len(intact)}-event fixtures + bundle to {FIXTURES}")


if __name__ == "__main__":
    main()
