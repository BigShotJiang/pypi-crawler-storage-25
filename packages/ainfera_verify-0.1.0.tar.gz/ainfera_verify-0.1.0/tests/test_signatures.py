from ainfera_verify.signatures import verify_hmac, verify_sigstore


def test_hmac_roundtrip(intact_events, hmac_key):
    ev = intact_events[0]
    assert verify_hmac(ev.event_hash, ev.hmac_signature, hmac_key)


def test_hmac_rejects_wrong_key(intact_events):
    ev = intact_events[0]
    assert not verify_hmac(ev.event_hash, ev.hmac_signature, b"wrong-key")


def test_hmac_rejects_tampered_hash(intact_events, hmac_key):
    ev = intact_events[0]
    assert not verify_hmac("0" * 64, ev.hmac_signature, hmac_key)


def test_hmac_is_case_insensitive_on_signature(intact_events, hmac_key):
    ev = intact_events[0]
    assert verify_hmac(ev.event_hash, ev.hmac_signature.upper(), hmac_key)


def test_hmac_handles_non_string_signature(hmac_key):
    assert not verify_hmac("abc", None, hmac_key)


def test_sigstore_accepts_matching_verified_sig():
    sig = {"payload_hash": "deadbeef", "verified": True}
    assert verify_sigstore("deadbeef", sig)


def test_sigstore_rejects_hash_mismatch():
    sig = {"payload_hash": "deadbeef", "verified": True}
    assert not verify_sigstore("cafebabe", sig)


def test_sigstore_rejects_unverified():
    sig = {"payload_hash": "deadbeef", "verified": False}
    assert not verify_sigstore("deadbeef", sig)


def test_sigstore_rejects_non_dict():
    assert not verify_sigstore("deadbeef", None)
