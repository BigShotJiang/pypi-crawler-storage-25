import json
from pathlib import Path

import pytest

from ainfera_verify.chain import AuditEvent

FIXTURES = Path(__file__).parent / "fixtures"
TEST_HMAC_KEY = b"ainfera-test-hmac-key-do-not-use-in-prod"


def _load_events(name: str) -> list[AuditEvent]:
    data = json.loads((FIXTURES / name).read_text())
    return [AuditEvent.from_dict(e) for e in data["events"]]


@pytest.fixture
def hmac_key() -> bytes:
    return TEST_HMAC_KEY


@pytest.fixture
def intact_events() -> list[AuditEvent]:
    return _load_events("manwe_chain_intact.json")


@pytest.fixture
def broken_events() -> list[AuditEvent]:
    return _load_events("manwe_chain_broken_at_500.json")


@pytest.fixture
def bundle_path() -> Path:
    return FIXTURES / "annex_iv_bundle.zip"
