import copy

from ainfera_verify.chain import (
    GENESIS_HASH,
    canonical_json,
    compute_event_hash,
    verify_chain,
)


def test_canonical_json_is_deterministic():
    a = {"b": 2, "a": 1, "nested": {"y": 9, "x": 8}}
    b = {"nested": {"x": 8, "y": 9}, "a": 1, "b": 2}
    assert canonical_json(a) == canonical_json(b)
    assert " " not in canonical_json(a)


def test_compute_event_hash_matches_known_inputs():
    h = compute_event_hash(GENESIS_HASH, {"x": 1})
    assert len(h) == 64
    # stable across calls
    assert h == compute_event_hash(GENESIS_HASH, {"x": 1})


def test_intact_chain_verifies(intact_events, hmac_key):
    result = verify_chain(intact_events, hmac_key)
    assert result.ok
    assert result.events_verified == len(intact_events)
    assert result.broken_at_seq is None
    assert result.genesis_hash == GENESIS_HASH
    assert result.tip_hash == intact_events[-1].event_hash


def test_empty_chain_is_trivially_ok(hmac_key):
    result = verify_chain([], hmac_key)
    assert result.ok
    assert result.events_verified == 0
    assert result.tip_hash == GENESIS_HASH


def test_broken_chain_detected_at_seq_500(broken_events, hmac_key):
    result = verify_chain(broken_events, hmac_key)
    assert not result.ok
    assert result.broken_at_seq == 500
    assert result.reason == "event_hash mismatch"


def test_previous_hash_break_detected(intact_events, hmac_key):
    events = copy.deepcopy(intact_events)
    events[10].previous_hash = "f" * 64
    result = verify_chain(events, hmac_key)
    assert not result.ok
    assert result.broken_at_seq == events[10].seq
    assert result.reason == "previous_hash mismatch"


def test_bad_hmac_detected(intact_events, hmac_key):
    events = copy.deepcopy(intact_events)
    events[3].hmac_signature = "00" * 32
    result = verify_chain(events, hmac_key)
    assert not result.ok
    assert result.broken_at_seq == events[3].seq
    assert result.reason == "hmac signature invalid"


def test_verify_stops_at_first_break(broken_events, hmac_key):
    # seq 500 broken; introduce a later break too — should still report 500.
    events = copy.deepcopy(broken_events)
    events[800].event_hash = "a" * 64
    result = verify_chain(events, hmac_key)
    assert result.broken_at_seq == 500


def test_unordered_input_is_sorted(intact_events, hmac_key):
    shuffled = list(reversed(intact_events))
    result = verify_chain(shuffled, hmac_key)
    assert result.ok
