import zipfile

import pytest

from ainfera_verify.bundle import BundleError, load_bundle
from ainfera_verify.chain import verify_chain


def test_load_bundle_parses_all_parts(bundle_path):
    bundle = load_bundle(bundle_path)
    assert bundle.manifest["agent_id"] == "manwe"
    assert bundle.manifest["event_count"] == len(bundle.events)
    assert len(bundle.hmac_public_key) > 0
    assert bundle.events[0].seq == 1


def test_bundle_chain_verifies(bundle_path):
    bundle = load_bundle(bundle_path)
    result = verify_chain(bundle.events, bundle.hmac_public_key)
    assert result.ok
    assert result.events_verified == bundle.manifest["event_count"]


def test_missing_file_raises(bundle_path, tmp_path):
    bad = tmp_path / "incomplete.zip"
    with zipfile.ZipFile(bad, "w") as zf:
        zf.writestr("manifest.json", "{}")
    with pytest.raises(BundleError, match="missing required file"):
        load_bundle(bad)


def test_not_a_zip_raises(tmp_path):
    bad = tmp_path / "notazip.zip"
    bad.write_text("this is not a zip")
    with pytest.raises(BundleError, match="not a valid zip"):
        load_bundle(bad)


def test_nonexistent_path_raises(tmp_path):
    with pytest.raises(BundleError, match="not found"):
        load_bundle(tmp_path / "nope.zip")


def test_bundle_missing_key_raises(tmp_path):
    bad = tmp_path / "nokey.zip"
    with zipfile.ZipFile(bad, "w") as zf:
        zf.writestr("manifest.json", "{}")
        zf.writestr("events.jsonl", "")
        zf.writestr("public_key.json", "{}")
    with pytest.raises(BundleError, match="missing 'hmac_key_b64'"):
        load_bundle(bad)
