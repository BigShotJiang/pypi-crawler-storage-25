# ainfera-verify — examples

## Quickstart

Install:

```bash
pip install ainfera-verify
```

### Verify a live AuditChain

```bash
ainfera-verify chain manwe
```

Fetches every `AuditEvent` for agent `manwe` from the public read API, then
verifies the hash chain and HMAC signatures locally. Exit code `0` if the
chain is intact, `1` if broken, `2` on a fetch error.

### Inspect one event

```bash
ainfera-verify event manwe 1245
```

### Verify an offline Annex IV bundle

```bash
ainfera-verify bundle ./manwe-2026-05-19.zip
```

A bundle is a self-contained `.zip` (manifest + events + embedded public key),
so this works fully air-gapped — no network, no Ainfera account.

## Bundle format

```
manwe-2026-05-19.zip
├── manifest.json     # agent_id, issuer, issued_at, event_count, use_for
├── events.jsonl      # one AuditEvent per line, seq-ordered
└── public_key.json   # {"hmac_key_b64": "...", "alg": "HMAC-SHA256"}
```

## Using as a library

```python
from ainfera_verify import verify_chain, AuditEvent
from ainfera_verify.bundle import load_bundle

bundle = load_bundle("manwe-2026-05-19.zip")
result = verify_chain(bundle.events, bundle.hmac_public_key)
print(result.ok, result.events_verified)
```

## Regenerating test fixtures

```bash
python tests/_generate_fixtures.py
```
