# Copyright 2025-present Coinbase Global, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dataclasses import dataclass
from typing import List, Optional
from ...base_response import BaseResponse
from ...enums import WalletType


@dataclass
class CreateWalletRequest:
    portfolio_id: str
    name: str
    symbol: str
    idempotency_key: str
    wallet_type: WalletType
    allowed_status_codes: Optional[List[int]] = None


@dataclass
class CreateWalletResponse(BaseResponse):
    activity_id: str = None
    name: str = None
    symbol: str = None
    wallet_type: str = None
    network_family: str = None