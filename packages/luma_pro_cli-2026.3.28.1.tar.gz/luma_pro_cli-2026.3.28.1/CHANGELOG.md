# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Calendar Versioning](https://calver.org/) (YYYY.MM.DD.BUILD).

## [0.1.0] - 2026-03-18

### Added
- Initial release
- Luma video generation from text prompts
- Image-to-video generation
- Video extension
- Task management with polling
- Rich terminal output with tables and panels
- JSON output mode (`--json` flag)
- Multiple model support
