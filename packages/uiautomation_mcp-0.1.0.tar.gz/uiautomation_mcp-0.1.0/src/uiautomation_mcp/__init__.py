"""Desktop UI Automation Inspector MCP Server."""

from .server import main

__all__ = ["main"]
