"""
Desktop UI Automation Inspector MCP Server

Provides tools for AI to inspect desktop UI elements and generate automation scripts.
Works with Windows UI Automation API via the uiautomation library.
"""

import json
import io
import base64
import time
from typing import Any

import uiautomation as auto
from fastmcp import FastMCP

mcp = FastMCP("uiautomation mcp")

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Cache element references so AI can drill down by id
_element_cache: dict[str, auto.Control] = {}
_cache_counter = 0


def _next_id() -> str:
    global _cache_counter
    _cache_counter += 1
    return f"e_{_cache_counter:04d}"


def _cache_element(ctrl: auto.Control) -> str:
    eid = _next_id()
    _element_cache[eid] = ctrl
    return eid


def _get_cached(element_id: str) -> auto.Control | None:
    return _element_cache.get(element_id)


def _rect_dict(rect) -> dict | None:
    if rect is None:
        return None
    try:
        return {
            "x": rect.left,
            "y": rect.top,
            "width": rect.width(),
            "height": rect.height(),
        }
    except Exception:
        return None


def _control_summary(ctrl: auto.Control, element_id: str) -> dict[str, Any]:
    """Build a concise summary dict for a control."""
    info: dict[str, Any] = {
        "elementId": element_id,
        "controlType": ctrl.ControlTypeName,
        "name": ctrl.Name or "",
        "className": ctrl.ClassName or "",
        "automationId": ctrl.AutomationId or "",
        "rect": _rect_dict(ctrl.BoundingRectangle),
    }
    # States
    states = []
    try:
        if ctrl.IsEnabled:
            states.append("enabled")
        else:
            states.append("disabled")
    except Exception:
        pass
    try:
        if ctrl.IsOffscreen:
            states.append("offscreen")
        else:
            states.append("visible")
    except Exception:
        pass
    info["states"] = states
    return info


def _build_tree(ctrl: auto.Control, max_depth: int, current_depth: int = 0,
                filter_types: list[str] | None = None,
                interactable_only: bool = False) -> dict[str, Any] | None:
    """Recursively build a control tree up to max_depth."""
    # Filter by control type
    if filter_types and ctrl.ControlTypeName not in filter_types:
        pass  # still traverse children, just don't include this node directly

    eid = _cache_element(ctrl)
    node = _control_summary(ctrl, eid)

    if current_depth >= max_depth:
        # Count children without expanding
        try:
            children = ctrl.GetChildren()
            node["childCount"] = len(children)
            node["children"] = f"[{len(children)} children - use inspect_element_tree with rootElementId='{eid}' to expand]"
        except Exception:
            node["childCount"] = 0
            node["children"] = []
        return node

    children_nodes = []
    try:
        for child in ctrl.GetChildren():
            child_node = _build_tree(
                child, max_depth, current_depth + 1,
                filter_types, interactable_only
            )
            if child_node is not None:
                children_nodes.append(child_node)
    except Exception:
        pass

    node["childCount"] = len(children_nodes)
    node["children"] = children_nodes
    return node


def _get_supported_patterns(ctrl: auto.Control) -> list[str]:
    """Detect which UI Automation patterns a control supports."""
    patterns = []
    pattern_checks = [
        ("InvokePattern", auto.PatternId.InvokePattern),
        ("ValuePattern", auto.PatternId.ValuePattern),
        ("SelectionPattern", auto.PatternId.SelectionPattern),
        ("SelectionItemPattern", auto.PatternId.SelectionItemPattern),
        ("ExpandCollapsePattern", auto.PatternId.ExpandCollapsePattern),
        ("TogglePattern", auto.PatternId.TogglePattern),
        ("ScrollPattern", auto.PatternId.ScrollPattern),
        ("TextPattern", auto.PatternId.TextPattern),
        ("WindowPattern", auto.PatternId.WindowPattern),
        ("GridPattern", auto.PatternId.GridPattern),
        ("TablePattern", auto.PatternId.TablePattern),
        ("RangeValuePattern", auto.PatternId.RangeValuePattern),
    ]
    for name, pid in pattern_checks:
        try:
            p = ctrl.GetPattern(pid)
            if p:
                patterns.append(name)
        except Exception:
            pass
    return patterns


def _get_pattern_details(ctrl: auto.Control, patterns: list[str]) -> dict[str, Any]:
    """Get current values from supported patterns."""
    details: dict[str, Any] = {}
    try:
        if "ValuePattern" in patterns:
            vp = ctrl.GetValuePattern()
            if vp:
                details["ValuePattern"] = {
                    "value": vp.Value,
                    "isReadOnly": vp.IsReadOnly,
                }
    except Exception:
        pass
    try:
        if "TogglePattern" in patterns:
            tp = ctrl.GetTogglePattern()
            if tp:
                details["TogglePattern"] = {
                    "toggleState": str(tp.ToggleState),
                }
    except Exception:
        pass
    try:
        if "ExpandCollapsePattern" in patterns:
            ep = ctrl.GetExpandCollapsePattern()
            if ep:
                details["ExpandCollapsePattern"] = {
                    "expandCollapseState": str(ep.ExpandCollapseState),
                }
    except Exception:
        pass
    try:
        if "SelectionItemPattern" in patterns:
            sp = ctrl.GetSelectionItemPattern()
            if sp:
                details["SelectionItemPattern"] = {
                    "isSelected": sp.IsSelected,
                }
    except Exception:
        pass
    try:
        if "RangeValuePattern" in patterns:
            rp = ctrl.GetRangeValuePattern()
            if rp:
                details["RangeValuePattern"] = {
                    "value": rp.Value,
                    "minimum": rp.Minimum,
                    "maximum": rp.Maximum,
                    "isReadOnly": rp.IsReadOnly,
                }
    except Exception:
        pass
    return details


def _build_locator_strategies(ctrl: auto.Control, element_id: str) -> dict[str, str | None]:
    """Generate multiple locator strategies for the control."""
    strategies: dict[str, str | None] = {}
    if ctrl.AutomationId:
        strategies["byAutomationId"] = f'auto.Control(searchDepth=..., AutomationId="{ctrl.AutomationId}")'
    else:
        strategies["byAutomationId"] = None

    if ctrl.Name:
        strategies["byName"] = f'auto.{ctrl.ControlTypeName}Control(searchDepth=..., Name="{ctrl.Name}")'
    else:
        strategies["byName"] = None

    if ctrl.ClassName:
        strategies["byClassName"] = f'auto.Control(searchDepth=..., ClassName="{ctrl.ClassName}")'
    else:
        strategies["byClassName"] = None

    # Recommend best strategy
    if ctrl.AutomationId:
        strategies["recommended"] = "byAutomationId"
    elif ctrl.Name:
        strategies["recommended"] = "byName"
    else:
        strategies["recommended"] = "byClassName"

    return strategies


# ---------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def list_windows(filter: str = "", include_hidden: bool = False) -> str:
    """List all visible top-level windows on the desktop.

    Use this as the first step to find the target application window.

    Args:
        filter: Optional fuzzy match on window title (case-insensitive).
        include_hidden: Whether to include offscreen/hidden windows.

    Returns:
        JSON array of window info with handle references for further inspection.
    """
    _element_cache.clear()
    global _cache_counter
    _cache_counter = 0

    desktop = auto.GetRootControl()
    windows = []
    for win in desktop.GetChildren():
        try:
            if not include_hidden and win.IsOffscreen:
                continue
            title = win.Name or ""
            if filter and filter.lower() not in title.lower():
                continue
            eid = _cache_element(win)
            windows.append({
                "elementId": eid,
                "title": title,
                "processName": win.ClassName or "",
                "className": win.ClassName or "",
                "automationId": win.AutomationId or "",
                "rect": _rect_dict(win.BoundingRectangle),
                "isActive": False,  # simplified
            })
        except Exception:
            continue

    return json.dumps(windows, ensure_ascii=False, indent=2)


@mcp.tool()
def inspect_element_tree(
    element_id: str,
    max_depth: int = 3,
    filter_control_types: str = "",
    interactable_only: bool = False,
) -> str:
    """Inspect the UI control tree starting from a given element.

    Use this to explore the structure of a window or sub-element.
    Start with a window elementId from list_windows, then drill deeper
    using child elementIds.

    Args:
        element_id: The element to start from (from list_windows or a previous inspect call).
        max_depth: How many levels deep to expand (default 3, keep small to avoid overload).
        filter_control_types: Comma-separated control types to include, e.g. "Button,Edit,ComboBox". Empty means all.
        interactable_only: If true, only return elements that are enabled and not offscreen.

    Returns:
        JSON tree of controls with elementIds for further drilling.
    """
    ctrl = _get_cached(element_id)
    if ctrl is None:
        return json.dumps({"error": f"Element '{element_id}' not found in cache. Call list_windows first."})

    filter_types = [t.strip() for t in filter_control_types.split(",") if t.strip()] or None

    tree = _build_tree(ctrl, max_depth, 0, filter_types, interactable_only)
    return json.dumps(tree, ensure_ascii=False, indent=2)


@mcp.tool()
def get_element_detail(element_id: str) -> str:
    """Get full details of a single UI element including automation patterns, values, and locator strategies.

    Use this when you've identified a target element and need to know:
    - What operations it supports (click, set value, toggle, expand, etc.)
    - Its current value/state
    - The best way to locate it in automation code

    Args:
        element_id: The element to inspect (from a previous inspect_element_tree call).

    Returns:
        JSON with complete element info, supported patterns, current values, and code-ready locator strategies.
    """
    ctrl = _get_cached(element_id)
    if ctrl is None:
        return json.dumps({"error": f"Element '{element_id}' not found in cache."})

    patterns = _get_supported_patterns(ctrl)
    pattern_details = _get_pattern_details(ctrl, patterns)
    locators = _build_locator_strategies(ctrl, element_id)

    detail = _control_summary(ctrl, element_id)
    detail["supportedPatterns"] = patterns
    detail["patternDetails"] = pattern_details
    detail["locatorStrategies"] = locators

    # Suggest possible actions based on patterns
    actions = []
    if "InvokePattern" in patterns:
        actions.append("click / invoke")
    if "ValuePattern" in patterns:
        actions.append("get/set text value")
    if "TogglePattern" in patterns:
        actions.append("toggle (checkbox/switch)")
    if "ExpandCollapsePattern" in patterns:
        actions.append("expand/collapse (dropdown/tree)")
    if "SelectionItemPattern" in patterns:
        actions.append("select this item")
    if "ScrollPattern" in patterns:
        actions.append("scroll content")
    if "TextPattern" in patterns:
        actions.append("read text content")
    if "RangeValuePattern" in patterns:
        actions.append("set numeric value (slider/spinner)")
    detail["possibleActions"] = actions

    return json.dumps(detail, ensure_ascii=False, indent=2)


@mcp.tool()
def inspect_at_point(x: int, y: int) -> str:
    """Inspect the UI element at a specific screen coordinate.

    Useful when you know the approximate position of an element
    (e.g., from a screenshot) but don't know its place in the control tree.

    Args:
        x: Screen X coordinate.
        y: Screen Y coordinate.

    Returns:
        JSON with element details and its elementId for further inspection.
    """
    try:
        ctrl = auto.ControlFromPoint(x, y)
        if ctrl is None:
            return json.dumps({"error": f"No element found at ({x}, {y})"})

        eid = _cache_element(ctrl)
        patterns = _get_supported_patterns(ctrl)
        locators = _build_locator_strategies(ctrl, eid)

        detail = _control_summary(ctrl, eid)
        detail["supportedPatterns"] = patterns
        detail["locatorStrategies"] = locators
        return json.dumps(detail, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def find_elements(
    element_id: str,
    name: str = "",
    control_type: str = "",
    automation_id: str = "",
    class_name: str = "",
    max_results: int = 20,
) -> str:
    """Search for elements matching criteria within a window/container.

    This is the most efficient way to find specific controls without
    manually traversing the tree. At least one search criterion is required.

    Args:
        element_id: The root element to search within (usually a window elementId).
        name: Match element Name (substring, case-insensitive).
        control_type: Match ControlType exactly, e.g. "Button", "Edit", "ComboBox".
        automation_id: Match AutomationId exactly.
        class_name: Match ClassName (substring, case-insensitive).
        max_results: Maximum number of results to return.

    Returns:
        JSON array of matching elements with elementIds.
    """
    root = _get_cached(element_id)
    if root is None:
        return json.dumps({"error": f"Element '{element_id}' not found in cache."})

    if not any([name, control_type, automation_id, class_name]):
        return json.dumps({"error": "At least one search criterion is required."})

    results = []

    def _search(ctrl: auto.Control, depth: int = 0):
        if len(results) >= max_results:
            return
        if depth > 30:  # safety limit
            return

        match = True
        if name and name.lower() not in (ctrl.Name or "").lower():
            match = False
        if control_type and ctrl.ControlTypeName != control_type:
            match = False
        if automation_id and ctrl.AutomationId != automation_id:
            match = False
        if class_name and class_name.lower() not in (ctrl.ClassName or "").lower():
            match = False

        if match and depth > 0:  # skip root itself
            eid = _cache_element(ctrl)
            info = _control_summary(ctrl, eid)
            info["supportedPatterns"] = _get_supported_patterns(ctrl)
            results.append(info)

        try:
            for child in ctrl.GetChildren():
                if len(results) >= max_results:
                    return
                _search(child, depth + 1)
        except Exception:
            pass

    _search(root)
    return json.dumps(results, ensure_ascii=False, indent=2)


@mcp.tool()
def capture_screenshot(element_id: str = "", highlight: bool = True) -> str:
    """Capture a screenshot of a window or the entire desktop.

    Returns a base64-encoded PNG image. If element_id is provided,
    captures just that window. Useful for visual verification.

    Args:
        element_id: Optional window/element to capture. Empty = full desktop.
        highlight: Whether to draw a red border around the target element.

    Returns:
        JSON with base64 image data and dimensions.
    """
    try:
        from PIL import ImageGrab, ImageDraw

        if element_id:
            ctrl = _get_cached(element_id)
            if ctrl is None:
                return json.dumps({"error": f"Element '{element_id}' not found."})
            rect = ctrl.BoundingRectangle
            bbox = (rect.left, rect.top, rect.right, rect.bottom)
            img = ImageGrab.grab(bbox=bbox)
        else:
            img = ImageGrab.grab()

        # Resize if too large
        max_w = 1280
        if img.width > max_w:
            ratio = max_w / img.width
            img = img.resize((max_w, int(img.height * ratio)))

        buf = io.BytesIO()
        img.save(buf, format="PNG")
        b64 = base64.b64encode(buf.getvalue()).decode()

        return json.dumps({
            "width": img.width,
            "height": img.height,
            "format": "png",
            "base64": b64,
        })
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def activate_window(element_id: str) -> str:
    """Activate and bring a window to the foreground.

    IMPORTANT: Always call this before performing any actions on a window
    to ensure it is visible and focused. This prevents operations from
    failing on minimized or background windows.

    Args:
        element_id: The window element to activate (from list_windows).

    Returns:
        JSON with success status and window info.
    """
    ctrl = _get_cached(element_id)
    if ctrl is None:
        return json.dumps({"error": f"Element '{element_id}' not found."})

    try:
        # Try to find the top-level window
        win = ctrl
        for _ in range(20):
            if win.ControlTypeName in ("WindowControl", "PaneControl"):
                break
            parent = win.GetParentControl()
            if parent is None:
                break
            win = parent

        # Restore if minimized
        try:
            wp = win.GetWindowPattern()
            if wp and wp.WindowVisualState == auto.WindowVisualState.Minimized:
                wp.SetWindowVisualState(auto.WindowVisualState.Normal)
                time.sleep(0.3)
        except Exception:
            pass

        # Bring to front
        try:
            win.SetTopmost(True)
            time.sleep(0.2)
            win.SetTopmost(False)
        except Exception:
            pass

        try:
            win.SetFocus()
        except Exception:
            pass

        rect = _rect_dict(win.BoundingRectangle)
        return json.dumps({
            "success": True,
            "window": win.Name or "",
            "rect": rect,
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def perform_action(element_id: str, action: str, value: str = "") -> str:
    """Perform a basic action on a UI element for testing/verification.

    Use this to verify that an element is correctly identified before
    generating a full automation script. Supports common actions.

    Args:
        element_id: The target element.
        action: One of: "click", "set_value", "toggle", "expand", "collapse",
                "select", "focus", "double_click", "right_click".
        value: Required for "set_value" action - the text to set.

    Returns:
        JSON with success status and any result info.
    """
    ctrl = _get_cached(element_id)
    if ctrl is None:
        return json.dumps({"error": f"Element '{element_id}' not found."})

    try:
        if action == "click":
            ctrl.Click()
            return json.dumps({"success": True, "action": "click"})

        elif action == "double_click":
            ctrl.DoubleClick()
            return json.dumps({"success": True, "action": "double_click"})

        elif action == "right_click":
            ctrl.RightClick()
            return json.dumps({"success": True, "action": "right_click"})

        elif action == "set_value":
            vp = ctrl.GetValuePattern()
            if vp:
                vp.SetValue(value)
                return json.dumps({"success": True, "action": "set_value", "value": value})
            else:
                # Fallback: click and type
                ctrl.Click()
                time.sleep(0.2)
                auto.SendKeys(value)
                return json.dumps({"success": True, "action": "set_value_via_keys", "value": value})

        elif action == "toggle":
            tp = ctrl.GetTogglePattern()
            if tp:
                tp.Toggle()
                return json.dumps({"success": True, "action": "toggle", "newState": str(tp.ToggleState)})
            return json.dumps({"error": "Element does not support TogglePattern"})

        elif action == "expand":
            ep = ctrl.GetExpandCollapsePattern()
            if ep:
                ep.Expand()
                return json.dumps({"success": True, "action": "expand"})
            return json.dumps({"error": "Element does not support ExpandCollapsePattern"})

        elif action == "collapse":
            ep = ctrl.GetExpandCollapsePattern()
            if ep:
                ep.Collapse()
                return json.dumps({"success": True, "action": "collapse"})
            return json.dumps({"error": "Element does not support ExpandCollapsePattern"})

        elif action == "select":
            sp = ctrl.GetSelectionItemPattern()
            if sp:
                sp.Select()
                return json.dumps({"success": True, "action": "select"})
            return json.dumps({"error": "Element does not support SelectionItemPattern"})

        elif action == "focus":
            ctrl.SetFocus()
            return json.dumps({"success": True, "action": "focus"})

        else:
            return json.dumps({"error": f"Unknown action: {action}. Supported: click, set_value, toggle, expand, collapse, select, focus, double_click, right_click"})

    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def generate_script_snippet(element_id: str, action: str, value: str = "") -> str:
    """Generate a ready-to-use Python automation code snippet for an element.

    After inspecting an element, use this to get copy-paste-ready code
    that locates and interacts with the element.

    Args:
        element_id: The target element.
        action: The desired action: "click", "set_value", "toggle", "expand",
                "collapse", "select", "read_value", "wait_appear".
        value: Required for "set_value" - the text to set.

    Returns:
        JSON with the generated Python code snippet and explanation.
    """
    ctrl = _get_cached(element_id)
    if ctrl is None:
        return json.dumps({"error": f"Element '{element_id}' not found."})

    # Build the best locator chain
    lines = ["import uiautomation as auto", ""]

    # Find parent window
    parent = ctrl
    window_name = ""
    try:
        p = ctrl
        for _ in range(20):
            p = p.GetParentControl()
            if p and p.ControlTypeName == "WindowControl":
                window_name = p.Name
                break
            if p is None:
                break
    except Exception:
        pass

    if window_name:
        lines.append(f'# Find the target window')
        lines.append(f'window = auto.WindowControl(searchDepth=1, Name="{window_name}")')
        lines.append(f'window.SetTopmost(True)')
        lines.append("")

    # Build element locator
    locator_parts = []
    if ctrl.AutomationId:
        locator_parts.append(f'AutomationId="{ctrl.AutomationId}"')
    if ctrl.Name:
        locator_parts.append(f'Name="{ctrl.Name}"')
    if ctrl.ClassName:
        locator_parts.append(f'ClassName="{ctrl.ClassName}"')

    ctrl_type = ctrl.ControlTypeName
    if not ctrl_type.endswith("Control"):
        ctrl_type += "Control"

    locator_str = ", ".join(locator_parts) if locator_parts else ""
    search_from = "window" if window_name else "auto.GetRootControl()"

    lines.append(f"# Locate the target element")
    lines.append(f"element = {search_from}.{ctrl_type}(searchDepth=10, {locator_str})")
    lines.append("")

    # Action code
    if action == "click":
        lines.append("# Click the element")
        lines.append("element.Click()")
    elif action == "set_value":
        lines.append(f"# Set value")
        lines.append(f'element.GetValuePattern().SetValue("{value}")')
        lines.append(f"# Alternative: element.Click(); auto.SendKeys('{value}')")
    elif action == "toggle":
        lines.append("# Toggle (checkbox/switch)")
        lines.append("element.GetTogglePattern().Toggle()")
    elif action == "expand":
        lines.append("# Expand (dropdown/tree node)")
        lines.append("element.GetExpandCollapsePattern().Expand()")
    elif action == "collapse":
        lines.append("# Collapse")
        lines.append("element.GetExpandCollapsePattern().Collapse()")
    elif action == "select":
        lines.append("# Select this item")
        lines.append("element.GetSelectionItemPattern().Select()")
    elif action == "read_value":
        lines.append("# Read current value")
        lines.append("value = element.GetValuePattern().Value")
        lines.append("print(f'Current value: {value}')")
    elif action == "wait_appear":
        lines.append("# Wait for element to appear (timeout 10s)")
        lines.append("element.Exists(maxSearchSeconds=10)")

    code = "\n".join(lines)
    return json.dumps({
        "code": code,
        "explanation": f"Locates '{ctrl.Name or ctrl.ControlTypeName}' via {locator_parts[0] if locator_parts else 'type'} and performs '{action}'",
        "locatorStrategy": locator_parts[0] if locator_parts else "by control type",
    }, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()