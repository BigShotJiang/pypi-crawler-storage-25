# uiautomation-mcp

[![GitHub](https://img.shields.io/github/license/miloira/uiautomation-mcp)](https://github.com/miloira/uiautomation-mcp)

基于 [UI Automation API](https://learn.microsoft.com/en-us/windows/win32/winauto/entry-uiauto-win32) 的 MCP Server，用于检查和自动化 Windows 桌面 UI 元素。

为 AI 助手提供探索 UI 控件树、检查元素属性、执行操作（点击、输入、切换等）以及生成可直接使用的 Python 自动化脚本的能力。

## 安装

```bash
pip install uiautomation-mcp
```

或使用 [uv](https://docs.astral.sh/uv/)：

```bash
uv pip install uiautomation-mcp
```

## 使用方式

### 命令行启动

```bash
uiautomation-mcp
```

通过 stdio 启动 MCP Server。

### MCP 客户端配置

添加到 MCP 客户端配置文件（如 `.kiro/settings/mcp.json`）：

```json
{
  "mcpServers": {
    "uiautomation": {
      "command": "uiautomation-mcp",
      "disabled": false,
      "autoApprove": []
    }
  }
}
```

也可以通过 uvx 直接运行（无需预装）：

```json
{
  "mcpServers": {
    "uiautomation": {
      "command": "uvx",
      "args": ["uiautomation-mcp"],
      "disabled": false,
      "autoApprove": []
    }
  }
}
```

## 工具列表

| 工具 | 说明 |
|------|------|
| `list_windows` | 列出桌面上所有可见的顶层窗口 |
| `inspect_element_tree` | 从指定元素开始探索 UI 控件树 |
| `get_element_detail` | 获取元素的完整详情，包括自动化模式和定位策略 |
| `inspect_at_point` | 检查屏幕坐标处的 UI 元素 |
| `find_elements` | 按名称、类型、AutomationId 或类名搜索元素 |
| `capture_screenshot` | 截取窗口或桌面的屏幕截图 |
| `activate_window` | 将窗口激活并置于前台 |
| `perform_action` | 对元素执行操作（点击、输入、切换、展开等） |
| `generate_script_snippet` | 生成可直接复制使用的 Python 自动化代码 |

## 典型工作流

1. `list_windows` — 找到目标应用窗口
2. `activate_window` — 将窗口置于前台
3. `inspect_element_tree` — 探索 UI 结构
4. `find_elements` / `get_element_detail` — 定位具体控件
5. `perform_action` — 与元素交互
6. `generate_script_snippet` — 获取可复用的自动化代码

## 系统要求

- Windows 操作系统
- Python >= 3.12

## 许可证

MIT
