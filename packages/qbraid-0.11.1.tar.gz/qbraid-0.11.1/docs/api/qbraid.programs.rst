qbraid.programs
================

.. automodule:: qbraid.programs
   :undoc-members:
   :show-inheritance:


Submodules
-----------

.. autosummary::
   :toctree: ../stubs/

   analog
   annealing
   gate_model