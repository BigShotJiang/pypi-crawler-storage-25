# moirais.fn — function file from book-equation translation pipeline (hadesllm/moirais)
"""
Black carbon spatial

Category: AirBio
"""

import numpy as np


def abblc(data=None, coords=None, n=50):
    """Black carbon spatial

    Returns
    -------
    DescriptiveResult
    """
    from ._containers import DescriptiveResult

    if data is None:
        data = np.random.default_rng(0).standard_normal(n)
    if coords is None:
        coords = np.random.default_rng(1).uniform(0, 100, (n, 2))
    stat = float(np.mean(data))
    return DescriptiveResult(
        name=short,
        value=stat,
        extra={"n": len(data), "mean": float(np.mean(data)), "std": float(np.std(data))},
    )


short = "abblc"
alias = "abblc"
quote = "It's over 9000! -- Vegeta"
abblc = abblc


def cheatsheet() -> str:
    return "abblc({}) -> Black carbon spatial"
