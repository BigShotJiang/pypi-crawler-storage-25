class ReqError(Exception):
    pass
