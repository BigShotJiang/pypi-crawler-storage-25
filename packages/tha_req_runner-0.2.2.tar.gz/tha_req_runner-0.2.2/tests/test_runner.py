import threading
from unittest.mock import MagicMock

import pytest
import requests

from tha_req_runner import ThaReq


# --- helpers ---

def _mock_resp(status_code: int = 200, json_data: object = None) -> MagicMock:
    resp = MagicMock(spec=requests.Response)
    resp.status_code = status_code
    if json_data is not None:
        resp.json.return_value = json_data
    else:
        resp.json.side_effect = ValueError("no json")
    return resp


# --- get_session ---

def test_get_session_returns_session(req: ThaReq) -> None:
    assert isinstance(req.get_session(), requests.Session)


def test_get_session_same_instance_per_thread(req: ThaReq) -> None:
    assert req.get_session() is req.get_session()


def test_get_session_thread_local(req: ThaReq) -> None:
    sessions: list[requests.Session] = []

    def capture() -> None:
        sessions.append(req.get_session())

    t1 = threading.Thread(target=capture)
    t2 = threading.Thread(target=capture)
    t1.start()
    t2.start()
    t1.join()
    t2.join()

    assert len(sessions) == 2
    assert sessions[0] is not sessions[1]


def test_get_session_instances_independent() -> None:
    assert ThaReq().get_session() is not ThaReq().get_session()


def test_get_session_default_status_forcelist(req: ThaReq) -> None:
    adapter = req.get_session().get_adapter("https://example.com")
    for code in (500, 502, 503, 504):
        assert code in adapter.max_retries.status_forcelist


def test_get_session_custom_status_forcelist() -> None:
    req = ThaReq()
    adapter = req.get_session(status_forcelist=(429, 503)).get_adapter("https://example.com")
    assert 429 in adapter.max_retries.status_forcelist
    assert 503 in adapter.max_retries.status_forcelist
    assert 500 not in adapter.max_retries.status_forcelist


def test_get_session_allowed_methods_frozenset() -> None:
    req = ThaReq()
    adapter = req.get_session(allowed_methods=frozenset(["GET", "POST"])).get_adapter("https://example.com")
    assert "POST" in adapter.max_retries.allowed_methods


def test_get_session_allowed_methods_list() -> None:
    req = ThaReq()
    adapter = req.get_session(allowed_methods=["GET", "POST"]).get_adapter("https://example.com")
    assert "POST" in adapter.max_retries.allowed_methods


def test_get_session_mounts_http_and_https(req: ThaReq) -> None:
    session = req.get_session()
    assert session.get_adapter("https://example.com") is not None
    assert session.get_adapter("http://example.com") is not None


# --- parse_response ---

def test_parse_success_json() -> None:
    resp = _mock_resp(200, {"id": 1})
    result = ThaReq.parse_response(resp)
    assert result["status"] is None
    assert result["code"] == 200
    assert result["data"] == {"id": 1}
    assert result["message"] is None
    assert result["raw_response"] is resp


def test_parse_success_non_json() -> None:
    resp = _mock_resp(200)
    result = ThaReq.parse_response(resp)
    assert result["status"] is None
    assert result["code"] == 200
    assert result["data"] is None
    assert result["message"] is None


def test_parse_exception_no_response() -> None:
    exc = ConnectionError("timed out")
    result = ThaReq.parse_response(exc)
    assert result["status"] == "error"
    assert result["code"] is None
    assert result["data"] is None
    assert "timed out" in result["message"]
    assert result["raw_response"] is None


def test_parse_exception_with_response() -> None:
    raw = _mock_resp(401)
    exc = requests.HTTPError("401 Unauthorized", response=raw)
    result = ThaReq.parse_response(exc)
    assert result["status"] == "error"
    assert result["code"] == 401
    assert result["raw_response"] is raw
    assert result["data"] is None  # no JSON body on this mock


def test_parse_exception_with_response_json_body() -> None:
    raw = _mock_resp(422, {"detail": "field required"})
    exc = requests.HTTPError("422 Unprocessable Entity", response=raw)
    result = ThaReq.parse_response(exc)
    assert result["status"] == "error"
    assert result["code"] == 422
    assert result["data"] == {"detail": "field required"}
    assert "422" in result["message"]


def test_parse_callable_as_static(req: ThaReq) -> None:
    result = req.parse_response(_mock_resp(204))
    assert result["status"] is None
    assert result["code"] == 204


# --- safe_call ---

def test_safe_call_success(req: ThaReq) -> None:
    resp = _mock_resp(200, {"id": 1})
    result = req.safe_call(lambda **_: resp)
    assert result["status"] is None
    assert result["code"] == 200
    assert result["data"] == {"id": 1}


def test_safe_call_exception(req: ThaReq) -> None:
    def boom(**_: object) -> requests.Response:
        raise ConnectionError("refused")

    result = req.safe_call(boom)
    assert result["status"] == "error"
    assert result["code"] is None
    assert "refused" in result["message"]


def test_safe_call_passes_args_and_kwargs(req: ThaReq) -> None:
    calls: list[tuple[object, ...]] = []

    def fn(url: str, **kwargs: object) -> requests.Response:
        calls.append((url, kwargs))
        return _mock_resp(200, {})

    req.safe_call(fn, "https://example.com", headers={"X-Key": "v"})
    assert calls[0][0] == "https://example.com"
    assert calls[0][1]["headers"] == {"X-Key": "v"}
    assert "timeout" in calls[0][1]


def test_safe_call_stores_nothing_on_instance(req: ThaReq) -> None:
    req.safe_call(lambda: _mock_resp(200, {}))
    assert not hasattr(req, "result")


def test_safe_call_raises_for_status(req: ThaReq) -> None:
    resp = _mock_resp(422, {"detail": "field required"})
    resp.raise_for_status.side_effect = requests.HTTPError("422", response=resp)
    result = req.safe_call(lambda **_: resp)
    assert result["status"] == "error"
    assert result["code"] == 422
    assert result["data"] == {"detail": "field required"}
    assert result["message"] is not None


def test_safe_call_200_does_not_raise(req: ThaReq) -> None:
    resp = _mock_resp(200, {"id": 1})
    resp.raise_for_status.return_value = None
    result = req.safe_call(lambda **_: resp)
    assert result["status"] is None
    assert result["code"] == 200
    assert result["message"] is None


# --- default headers ---

def test_get_session_default_headers() -> None:
    req = ThaReq()
    session = req.get_session(headers={"Authorization": "Bearer tok", "X-Custom": "val"})
    assert session.headers["Authorization"] == "Bearer tok"
    assert session.headers["X-Custom"] == "val"


def test_get_session_no_headers_does_not_error(req: ThaReq) -> None:
    session = req.get_session()
    assert "Authorization" not in session.headers


# --- timeout ---

def test_get_session_default_timeout(req: ThaReq) -> None:
    req.get_session()
    assert req.timeout == 30


def test_get_session_custom_timeout() -> None:
    req = ThaReq()
    req.get_session(timeout=10)
    assert req.timeout == 10


def test_safe_call_injects_timeout(req: ThaReq) -> None:
    req.get_session(timeout=7)
    captured: list[dict[str, object]] = []

    def fn(**kwargs: object) -> requests.Response:
        captured.append(dict(kwargs))
        return _mock_resp(200, {})

    req.safe_call(fn)
    assert captured[0]["timeout"] == 7


def test_safe_call_caller_timeout_overrides(req: ThaReq) -> None:
    req.get_session(timeout=7)
    captured: list[dict[str, object]] = []

    def fn(**kwargs: object) -> requests.Response:
        captured.append(dict(kwargs))
        return _mock_resp(200, {})

    req.safe_call(fn, timeout=99)
    assert captured[0]["timeout"] == 99


# --- reset_session / close_session ---

def test_reset_session_creates_new_session(req: ThaReq) -> None:
    s1 = req.get_session()
    req.reset_session()
    s2 = req.get_session()
    assert s1 is not s2


def test_reset_session_no_session_does_not_error(req: ThaReq) -> None:
    req.reset_session()  # called before get_session — should not raise


def test_close_session_creates_new_session(req: ThaReq) -> None:
    s1 = req.get_session()
    req.close_session()
    s2 = req.get_session()
    assert s1 is not s2


def test_reset_clears_timeout(req: ThaReq) -> None:
    req.get_session(timeout=5)
    req.reset_session()
    req.get_session(timeout=15)
    assert req.timeout == 15


# --- httpx backend ---

import httpx


def test_httpx_backend_returns_client() -> None:
    req = ThaReq(backend="httpx")
    assert isinstance(req.get_session(), httpx.Client)


def test_httpx_backend_same_instance_per_thread() -> None:
    req = ThaReq(backend="httpx")
    assert req.get_session() is req.get_session()


def test_httpx_backend_thread_local() -> None:
    req = ThaReq(backend="httpx")
    sessions: list[httpx.Client] = []

    def capture() -> None:
        sessions.append(req.get_session())

    t1 = threading.Thread(target=capture)
    t2 = threading.Thread(target=capture)
    t1.start(); t2.start()
    t1.join(); t2.join()

    assert sessions[0] is not sessions[1]


def test_httpx_backend_default_headers() -> None:
    req = ThaReq(backend="httpx")
    client = req.get_session(headers={"Authorization": "Bearer tok"})
    assert client.headers["authorization"] == "Bearer tok"


def test_httpx_backend_reset_session() -> None:
    req = ThaReq(backend="httpx")
    c1 = req.get_session()
    req.reset_session()
    c2 = req.get_session()
    assert c1 is not c2


def test_httpx_parse_response_success() -> None:
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = 200
    resp.json.return_value = {"ok": True}
    result = ThaReq.parse_response(resp)
    assert result["status"] is None
    assert result["code"] == 200
    assert result["data"] == {"ok": True}
    assert result["message"] is None


def test_httpx_parse_response_exception_with_response() -> None:
    raw = MagicMock(spec=httpx.Response)
    raw.status_code = 403
    exc = httpx.HTTPStatusError("403", request=MagicMock(), response=raw)
    result = ThaReq.parse_response(exc)
    assert result["status"] == "error"
    assert result["code"] == 403
    assert result["raw_response"] is raw


def test_requests_default_backend() -> None:
    req = ThaReq()
    assert isinstance(req.get_session(), requests.Session)
