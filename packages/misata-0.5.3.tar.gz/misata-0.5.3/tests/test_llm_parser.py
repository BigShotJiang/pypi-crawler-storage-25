"""
Unit tests for LLM parser (using mocks).
"""

import json
import pytest
from unittest.mock import MagicMock, patch

# Mock response from Groq
MOCK_LLM_RESPONSE = {
    "name": "Test Dataset",
    "description": "Test description",
    "seed": 42,
    "tables": [
        {"name": "plans", "is_reference": True, "inline_data": [
            {"id": 1, "name": "Free", "price": 0.0},
            {"id": 2, "name": "Premium", "price": 9.99}
        ]},
        {"name": "users", "row_count": 100, "is_reference": False}
    ],
    "columns": {
        "users": [
            {"name": "id", "type": "int", "distribution_params": {"distribution": "uniform", "min": 1, "max": 100}},
            {"name": "email", "type": "text", "distribution_params": {"text_type": "email"}},
            {"name": "plan_id", "type": "foreign_key", "distribution_params": {}}
        ]
    },
    "relationships": [
        {"parent_table": "plans", "child_table": "users", "parent_key": "id", "child_key": "plan_id"}
    ],
    "events": []
}


class TestLLMSchemaGenerator:
    """Tests for LLMSchemaGenerator with mocked Groq API."""
    
    @pytest.fixture
    def mock_groq_response(self):
        """Create mock Groq response."""
        mock_message = MagicMock()
        mock_message.content = json.dumps(MOCK_LLM_RESPONSE)
        
        mock_choice = MagicMock()
        mock_choice.message = mock_message
        
        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        
        return mock_response
    
    @patch.dict('os.environ', {'GROQ_API_KEY': 'test_key'})
    @patch('misata.llm_parser.Groq')
    def test_generate_from_story(self, mock_groq_class, mock_groq_response):
        """Test schema generation from story."""
        from misata.llm_parser import LLMSchemaGenerator
        
        # Setup mock
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_groq_response
        mock_groq_class.return_value = mock_client
        
        # Test
        generator = LLMSchemaGenerator(api_key="test_key")
        schema = generator.generate_from_story("Test SaaS app")
        
        assert schema.name == "Test Dataset"
        assert len(schema.tables) == 2
        assert len(schema.relationships) == 1
    
    @patch.dict('os.environ', {'GROQ_API_KEY': 'test_key'})
    @patch('misata.llm_parser.Groq')
    def test_reference_table_parsing(self, mock_groq_class, mock_groq_response):
        """Test that reference tables with inline_data are parsed correctly."""
        from misata.llm_parser import LLMSchemaGenerator
        
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_groq_response
        mock_groq_class.return_value = mock_client
        
        generator = LLMSchemaGenerator(api_key="test_key")
        schema = generator.generate_from_story("Test")
        
        # Find plans table
        plans_table = next(t for t in schema.tables if t.name == "plans")
        
        assert plans_table.is_reference is True
        assert plans_table.inline_data is not None
        assert len(plans_table.inline_data) == 2
        assert plans_table.inline_data[0]["price"] == 0.0
    
    @patch.dict('os.environ', {'GROQ_API_KEY': 'test_key'})
    @patch('misata.llm_parser.Groq')
    def test_columns_parsed(self, mock_groq_class, mock_groq_response):
        """Test that columns are parsed correctly."""
        from misata.llm_parser import LLMSchemaGenerator
        
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_groq_response
        mock_groq_class.return_value = mock_client
        
        generator = LLMSchemaGenerator(api_key="test_key")
        schema = generator.generate_from_story("Test")
        
        user_columns = schema.columns["users"]
        assert len(user_columns) == 3
        
        email_col = next(c for c in user_columns if c.name == "email")
        assert email_col.type == "text"
        assert email_col.distribution_params["text_type"] == "email"
    
    def test_missing_api_key_raises(self):
        """Test that missing API key raises ValueError."""
        from misata.llm_parser import LLMSchemaGenerator
        
        with patch.dict('os.environ', {}, clear=True):
            with pytest.raises(ValueError, match="Groq API key required"):
                LLMSchemaGenerator()
    
    @patch.dict('os.environ', {'GROQ_API_KEY': 'test_key'})
    @patch('misata.llm_parser.Groq')
    def test_handles_missing_optional_fields(self, mock_groq_class):
        """Test handling of minimal LLM response."""
        from misata.llm_parser import LLMSchemaGenerator
        
        minimal_response = {
            "name": "Minimal",
            "tables": [{"name": "data", "row_count": 10}],
            "columns": {
                "data": [{"name": "id", "type": "int", "distribution_params": {"distribution": "uniform"}}]
            }
        }
        
        mock_message = MagicMock()
        mock_message.content = json.dumps(minimal_response)
        mock_choice = MagicMock()
        mock_choice.message = mock_message
        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_groq_class.return_value = mock_client
        
        generator = LLMSchemaGenerator(api_key="test_key")
        schema = generator.generate_from_story("Minimal test")
        
        assert schema.name == "Minimal"
        assert len(schema.tables) == 1
        assert schema.relationships == []
        assert schema.events == []


class TestLLMDateNormalization:
    """Test date parameter normalization."""
    
    @patch.dict('os.environ', {'GROQ_API_KEY': 'test_key'})
    @patch('misata.llm_parser.Groq')
    def test_normalizes_start_date_end_date(self, mock_groq_class):
        """Test that start_date/end_date are normalized to start/end."""
        from misata.llm_parser import LLMSchemaGenerator
        
        response_with_date_variants = {
            "name": "Test",
            "tables": [{"name": "events", "row_count": 10}],
            "columns": {
                "events": [
                    {"name": "id", "type": "int", "distribution_params": {"distribution": "uniform"}},
                    {"name": "created_at", "type": "date", "distribution_params": {
                        "start_date": "2023-01-01",
                        "end_date": "2024-12-31"
                    }}
                ]
            }
        }
        
        mock_message = MagicMock()
        mock_message.content = json.dumps(response_with_date_variants)
        mock_choice = MagicMock()
        mock_choice.message = mock_message
        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_groq_class.return_value = mock_client
        
        generator = LLMSchemaGenerator(api_key="test_key")
        schema = generator.generate_from_story("Test")
        
        date_col = schema.columns["events"][1]
        assert "start" in date_col.distribution_params
        assert "end" in date_col.distribution_params


# === Mock enrichment response for enrich_schema tests ===
MOCK_ENRICHMENT_RESPONSE = {
    "inferred_domain": "E-commerce platform",
    "columns": {
        "users": [
            {"name": "id", "type": "int", "distribution_params": {"distribution": "uniform", "min": 1, "max": 1000}, "unique": True},
            {"name": "name", "type": "text", "distribution_params": {"text_type": "name"}},
            {"name": "email", "type": "text", "distribution_params": {"text_type": "email"}},
            {"name": "age", "type": "int", "distribution_params": {"distribution": "normal", "mean": 35, "std": 12, "min": 18, "max": 80}},
            {"name": "status", "type": "categorical", "distribution_params": {"choices": ["active", "inactive", "suspended"], "probabilities": [0.7, 0.2, 0.1]}},
        ],
        "orders": [
            {"name": "id", "type": "int", "distribution_params": {"distribution": "uniform", "min": 1, "max": 5000}, "unique": True},
            {"name": "user_id", "type": "foreign_key", "distribution_params": {}},
            {"name": "amount", "type": "float", "distribution_params": {"distribution": "exponential", "scale": 75, "min": 0.99, "decimals": 2}},
            {"name": "quantity", "type": "int", "distribution_params": {"distribution": "poisson", "lambda": 3, "min": 1}},
            {"name": "created_at", "type": "date", "distribution_params": {"start": "2024-01-01", "end": "2025-12-31"}},
        ]
    },
    "reference_tables": [
        {
            "name": "categories",
            "inline_data": [
                {"id": 1, "name": "Electronics", "commission_pct": 0.08},
                {"id": 2, "name": "Clothing", "commission_pct": 0.12},
                {"id": 3, "name": "Books", "commission_pct": 0.05},
            ]
        }
    ],
    "constraints": {
        "orders": [
            {"name": "min_order_amount", "type": "min_per_group", "group_by": [], "column": "amount", "value": 0.99, "action": "cap"}
        ]
    }
}


class TestEnrichSchema:
    """Tests for LLMSchemaGenerator.enrich_schema with mocked LLM."""

    def _bare_schema(self):
        """Create a bare schema like one from introspection."""
        from misata.schema import Column, Relationship, SchemaConfig, Table
        return SchemaConfig(
            name="IntrospectedSchema",
            tables=[
                Table(name="users", row_count=100),
                Table(name="orders", row_count=500),
                Table(name="categories", row_count=10),
            ],
            columns={
                "users": [
                    Column(name="id", type="int", unique=True, distribution_params={"distribution": "normal"}),
                    Column(name="name", type="text", distribution_params={"text_type": "sentence"}),
                    Column(name="email", type="text", distribution_params={"text_type": "sentence"}),
                    Column(name="age", type="int", distribution_params={"distribution": "normal"}),
                    Column(name="status", type="text", distribution_params={"text_type": "sentence"}),
                ],
                "orders": [
                    Column(name="id", type="int", unique=True, distribution_params={"distribution": "normal"}),
                    Column(name="user_id", type="foreign_key", distribution_params={}),
                    Column(name="amount", type="float", distribution_params={"distribution": "normal"}),
                    Column(name="quantity", type="int", distribution_params={"distribution": "normal"}),
                    Column(name="created_at", type="date"),
                ],
                "categories": [
                    Column(name="id", type="int", unique=True, distribution_params={"distribution": "normal"}),
                    Column(name="name", type="text", distribution_params={"text_type": "sentence"}),
                    Column(name="commission_pct", type="float", distribution_params={"distribution": "normal"}),
                ],
            },
            relationships=[
                Relationship(parent_table="users", child_table="orders", parent_key="id", child_key="user_id"),
            ],
        )

    def _mock_llm(self, mock_groq_class, response_dict):
        """Setup mock LLM to return a given response."""
        mock_message = MagicMock()
        mock_message.content = json.dumps(response_dict)
        mock_choice = MagicMock()
        mock_choice.message = mock_message
        mock_response = MagicMock()
        mock_response.choices = [mock_choice]
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_groq_class.return_value = mock_client
        return mock_client

    @patch.dict('os.environ', {'GROQ_API_KEY': 'test_key'})
    @patch('misata.llm_parser.Groq')
    def test_enriches_distribution_params(self, mock_groq_class):
        """Test that enrich_schema populates distribution_params."""
        self._mock_llm(mock_groq_class, MOCK_ENRICHMENT_RESPONSE)
        from misata.llm_parser import LLMSchemaGenerator

        generator = LLMSchemaGenerator(api_key="test_key")
        bare = self._bare_schema()
        enriched = generator.enrich_schema(bare)

        # Email should be enriched with text_type email
        email_col = next(c for c in enriched.columns["users"] if c.name == "email")
        assert email_col.distribution_params.get("text_type") == "email"

        # Name should be enriched with text_type name
        name_col = next(c for c in enriched.columns["users"] if c.name == "name")
        assert name_col.distribution_params.get("text_type") == "name"

        # Age should have realistic distribution
        age_col = next(c for c in enriched.columns["users"] if c.name == "age")
        assert age_col.distribution_params.get("mean") == 35

        # Amount should have exponential distribution
        amount_col = next(c for c in enriched.columns["orders"] if c.name == "amount")
        assert amount_col.distribution_params.get("distribution") == "exponential"

    @patch.dict('os.environ', {'GROQ_API_KEY': 'test_key'})
    @patch('misata.llm_parser.Groq')
    def test_preserves_foreign_key_columns(self, mock_groq_class):
        """Test that FK columns are not modified."""
        self._mock_llm(mock_groq_class, MOCK_ENRICHMENT_RESPONSE)
        from misata.llm_parser import LLMSchemaGenerator

        generator = LLMSchemaGenerator(api_key="test_key")
        bare = self._bare_schema()
        enriched = generator.enrich_schema(bare)

        fk_col = next(c for c in enriched.columns["orders"] if c.name == "user_id")
        assert fk_col.type == "foreign_key"

    @patch.dict('os.environ', {'GROQ_API_KEY': 'test_key'})
    @patch('misata.llm_parser.Groq')
    def test_converts_reference_tables(self, mock_groq_class):
        """Test that small tables are converted to reference tables with inline_data."""
        self._mock_llm(mock_groq_class, MOCK_ENRICHMENT_RESPONSE)
        from misata.llm_parser import LLMSchemaGenerator

        generator = LLMSchemaGenerator(api_key="test_key")
        bare = self._bare_schema()
        enriched = generator.enrich_schema(bare)

        cat_table = next(t for t in enriched.tables if t.name == "categories")
        assert cat_table.is_reference is True
        assert cat_table.inline_data is not None
        assert len(cat_table.inline_data) == 3
        assert cat_table.inline_data[0]["name"] == "Electronics"

    @patch.dict('os.environ', {'GROQ_API_KEY': 'test_key'})
    @patch('misata.llm_parser.Groq')
    def test_adds_constraints(self, mock_groq_class):
        """Test that business rule constraints are added."""
        self._mock_llm(mock_groq_class, MOCK_ENRICHMENT_RESPONSE)
        from misata.llm_parser import LLMSchemaGenerator

        generator = LLMSchemaGenerator(api_key="test_key")
        bare = self._bare_schema()
        enriched = generator.enrich_schema(bare)

        orders_table = next(t for t in enriched.tables if t.name == "orders")
        assert len(orders_table.constraints) == 1
        assert orders_table.constraints[0].name == "min_order_amount"

    @patch.dict('os.environ', {'GROQ_API_KEY': 'test_key'})
    @patch('misata.llm_parser.Groq')
    def test_preserves_relationships(self, mock_groq_class):
        """Test that relationships are preserved."""
        self._mock_llm(mock_groq_class, MOCK_ENRICHMENT_RESPONSE)
        from misata.llm_parser import LLMSchemaGenerator

        generator = LLMSchemaGenerator(api_key="test_key")
        bare = self._bare_schema()
        enriched = generator.enrich_schema(bare)

        assert len(enriched.relationships) == 1
        assert enriched.relationships[0].parent_table == "users"
        assert enriched.relationships[0].child_table == "orders"

    @patch.dict('os.environ', {'GROQ_API_KEY': 'test_key'})
    @patch('misata.llm_parser.Groq')
    def test_type_transition_text_to_categorical(self, mock_groq_class):
        """Test safe type transition from text to categorical."""
        self._mock_llm(mock_groq_class, MOCK_ENRICHMENT_RESPONSE)
        from misata.llm_parser import LLMSchemaGenerator

        generator = LLMSchemaGenerator(api_key="test_key")
        bare = self._bare_schema()
        enriched = generator.enrich_schema(bare)

        status_col = next(c for c in enriched.columns["users"] if c.name == "status")
        assert status_col.type == "categorical"
        assert "choices" in status_col.distribution_params

