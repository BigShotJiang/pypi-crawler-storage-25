"""
Core DataSimulator class for high-performance synthetic data generation.

This module implements vectorized data generation with support for:
- Topological sorting of table dependencies
- Vectorized column generation (NO LOOPS)
- Referential integrity enforcement
- Scenario event application
- Pure Python text generation (no external dependencies)
"""

import warnings
from collections import defaultdict, deque
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from misata.generators.base import TextGenerator as _FactoryTextGenerator  # Generator factory version
# Use the original generators.py TextGenerator which supports seed
from misata.generators_legacy import TextGenerator
from misata.schema import Column, Relationship, ScenarioEvent, SchemaConfig


class DataSimulator:
    """
    High-performance synthetic data simulator.

    Generates synthetic datasets based on SchemaConfig definitions,
    using vectorized operations for maximum performance.

    Attributes:
        config: Schema configuration
        data: Generated dataframes (table_name -> DataFrame)
        text_gen: TextGenerator for entity generation
        rng: NumPy random generator for reproducibility
    """

    # Performance constants
    MAX_CONTEXT_ROWS = 50000  # Cap context storage for memory efficiency
    TEXT_POOL_SIZE = 10000    # Size of text value pools for vectorized sampling

    def __init__(self, config: SchemaConfig,
                 apply_semantic_fixes: bool = True, batch_size: int = 10_000,
                 smart_mode: bool = False, use_llm: bool = True):
        """
        Initialize the simulator.

        Args:
            config: Schema configuration defining tables, columns, and relationships
            apply_semantic_fixes: Auto-fix column types based on semantic patterns
            batch_size: Number of rows to generate per batch
            smart_mode: Enable LLM-powered context-aware value generation
            use_llm: If smart_mode is True, whether to use LLM (vs curated fallbacks)
        """
        self.config = config
        self.context: Dict[str, pd.DataFrame] = {}  # Lightweight context (IDs only)
        self.text_gen = TextGenerator(seed=config.seed)
        self.batch_size = batch_size
        self.smart_mode = smart_mode
        self.use_llm = use_llm
        self._smart_gen = None  # Lazy init
        self._unique_pools: Dict[str, np.ndarray] = {}  # Store pre-generated unique values
        self._unique_counters: Dict[str, int] = {}      # Track usage of unique pools
        self._sequence_counters: Dict[str, int] = {}    # Stable counters for primary keys
        self._smart_pools: Dict[str, np.ndarray] = {}   # Cache smart value pools
        self._text_pools: Dict[str, np.ndarray] = {}    # Cache text pools for vectorized sampling

        # Apply semantic inference to fix column types
        if apply_semantic_fixes:
            from misata.semantic import apply_semantic_inference
            self.config.columns = apply_semantic_inference(self.config.columns)

        # Set random seed if provided
        seed = config.seed if config.seed is not None else np.random.randint(0, 2**32 - 1)
        self.rng = np.random.default_rng(seed)
        np.random.seed(seed)  # For legacy numpy.random calls
    
    def _get_smart_gen(self):
        """Lazy initialize SmartValueGenerator."""
        if self._smart_gen is None:
            try:
                from misata.smart_values import SmartValueGenerator
                self._smart_gen = SmartValueGenerator()
            except Exception:
                self._smart_gen = None
        return self._smart_gen

    def topological_sort(self) -> List[str]:
        """
        Determine table generation order using topological sort.

        Parent tables must be generated before child tables to ensure
        referential integrity.

        Returns:
            List of table names in dependency order

        Raises:
            ValueError: If circular dependencies are detected
        """
        # Build adjacency list and in-degree map
        graph = defaultdict(list)
        in_degree = {table.name: 0 for table in self.config.tables}

        for rel in self.config.relationships:
            graph[rel.parent_table].append(rel.child_table)
            in_degree[rel.child_table] += 1

        # Kahn's algorithm for topological sort
        queue = deque([name for name, degree in in_degree.items() if degree == 0])
        sorted_tables = []

        while queue:
            table_name = queue.popleft()
            sorted_tables.append(table_name)

            for neighbor in graph[table_name]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # Check for circular dependencies
        if len(sorted_tables) != len(self.config.tables):
            raise ValueError(
                f"Circular dependency detected in relationships. "
                f"Generated {len(sorted_tables)} / {len(self.config.tables)} tables."
            )

        return sorted_tables

    def _get_parent_ids(self, relationship: Relationship) -> np.ndarray:
        """
        Get valid parent IDs for foreign key generation, applying filters if defined.

        Args:
            relationship: Relationship definition

        Returns:
            Array of valid parent IDs
        """
        if relationship.parent_table not in self.context:
            return np.array([])

        parent_df = self.context[relationship.parent_table]
        if relationship.parent_key not in parent_df.columns:
             return np.array([])

        # Apply filters if defined (Logic Gap Fix)
        # Apply filters if defined (Logic Gap Fix)
        if relationship.filters:
            mask = np.ones(len(parent_df), dtype=bool)
            for col, val in relationship.filters.items():
                if col in parent_df.columns:
                    mask &= (parent_df[col] == val)
                else:
                    # If filter column missing from context, can't filter.
                    # Assume mismatch if column missing.
                    mask[:]=False

            valid_ids = parent_df.loc[mask, relationship.parent_key].values
        else:
            valid_ids = parent_df[relationship.parent_key].values

        return valid_ids

    def _update_context(self, table_name: str, df: pd.DataFrame) -> None:
        """
        Update the context with key columns from the generated batch.

        Smart Context Logic:
        1. Store Primary Key ('id')
        2. Store columns used as foreign keys by children (parent_key)
        3. Store columns used in Relationship filters (Logic Gap fix)
        4. Store columns used in 'relative_to' date constraints (Time Travel fix)
        """
        needed_cols = {'id'}

        # 2. FK and Filter dependencies
        for rel in self.config.relationships:
            if rel.parent_table == table_name:
                needed_cols.add(rel.parent_key)
                if rel.filters:
                    for col in rel.filters.keys():
                        needed_cols.add(col)

        # 4. Filter 'relative_to' dependencies
        # This requires scanning ALL columns of ALL child tables to see if they reference this table
        # Optimization: Build this dependency map once in __init__?
        # For now, we scan here. It's fast enough for schema sizes < 100 tables.
        for child_table in self.config.tables:
            child_cols = self.config.get_columns(child_table.name)
            for col in child_cols:
                if col.type == 'date' and 'relative_to' in col.distribution_params:
                    # Format: "parent_table.column"
                    try:
                        ptable, pcol = col.distribution_params['relative_to'].split('.')
                        if ptable == table_name:
                            needed_cols.add(pcol)
                    except:
                        pass

        cols_to_store = [c for c in needed_cols if c in df.columns]
        if not cols_to_store:
            return

        ctx_df = df[cols_to_store].copy()

        if table_name not in self.context:
            # First batch: store up to MAX_CONTEXT_ROWS
            if len(ctx_df) > self.MAX_CONTEXT_ROWS:
                ctx_df = ctx_df.sample(n=self.MAX_CONTEXT_ROWS, random_state=self.config.seed)
            self.context[table_name] = ctx_df
        else:
            # Append to existing context, but cap at MAX_CONTEXT_ROWS
            current_len = len(self.context[table_name])
            if current_len >= self.MAX_CONTEXT_ROWS:
                # Already at capacity, use reservoir sampling for randomness
                # Replace some existing rows with new ones (probability-based)
                return  # Skip appending, we have enough IDs
            
            remaining_space = self.MAX_CONTEXT_ROWS - current_len
            rows_to_add = ctx_df.iloc[:remaining_space]
            self.context[table_name] = pd.concat(
                [self.context[table_name], rows_to_add], 
                ignore_index=True
            )

    def generate_column(
        self,
        table_name: str,
        column: Column,
        size: int,
        table_data: Optional[pd.DataFrame] = None,
    ) -> np.ndarray:
        """
        Generate a single column using vectorized operations.

        Args:
            table_name: Name of the table being generated
            column: Column definition
            size: Number of values to generate
            table_data: Partially generated table (for columns that depend on other columns)

        Returns:
            Numpy array of generated values
        """
        params = column.distribution_params

        # ========== CORRELATED COLUMN GENERATION ==========
        # If this column depends on another column's value, use conditional distribution
        if "depends_on" in params and table_data is not None:
            parent_col = params["depends_on"]
            mapping = params.get("mapping", {})
            
            if parent_col in table_data.columns and mapping:
                parent_values = table_data[parent_col].values
                
                # Check if it's numeric or categorical mapping
                first_val = next(iter(mapping.values()))
                if isinstance(first_val, dict) and "mean" in first_val:
                    # Numeric conditional distribution (e.g., salary based on job_title)
                    # mapping = {"Intern": {"mean": 40000, "std": 5000}, "CTO": {"mean": 200000, "std": 30000}}
                    values = np.zeros(size)
                    for key, dist in mapping.items():
                        mask = parent_values == key
                        count = mask.sum()
                        if count > 0:
                            mean = dist.get("mean", 50000)
                            std = dist.get("std", mean * 0.1)
                            values[mask] = self.rng.normal(mean, std, count)
                    
                    # Handle values that didn't match any key (use default)
                    default = params.get("default", {"mean": 50000, "std": 10000})
                    unmatched = ~np.isin(parent_values, list(mapping.keys()))
                    if unmatched.sum() > 0:
                        values[unmatched] = self.rng.normal(
                            default.get("mean", 50000), 
                            default.get("std", 10000), 
                            unmatched.sum()
                        )
                    return values
                    
                elif isinstance(first_val, list):
                    # Categorical conditional (e.g., state based on country)
                    # mapping = {"USA": ["CA", "TX", "NY"], "UK": ["England", "Scotland"]}
                    values = np.empty(size, dtype=object)
                    for key, choices in mapping.items():
                        mask = parent_values == key
                        count = mask.sum()
                        if count > 0:
                            values[mask] = self.rng.choice(choices, count)
                    
                    # Default for unmatched
                    default_choices = params.get("default", ["Unknown"])
                    unmatched = values == None  # noqa
                    if unmatched.sum() > 0:
                        values[unmatched] = self.rng.choice(default_choices, unmatched.sum())
                    return values
                    
                elif isinstance(first_val, (int, float)):
                    # Probability-based boolean (e.g., churn probability based on plan)
                    # mapping = {"free": 0.3, "pro": 0.1, "enterprise": 0.05}
                    values = np.zeros(size, dtype=bool)
                    for key, prob in mapping.items():
                        mask = parent_values == key
                        count = mask.sum()
                        if count > 0:
                            values[mask] = self.rng.random(count) < prob
                    return values

        # ========== STANDARD COLUMN GENERATION ==========
        
        # CATEGORICAL
        if column.type == "categorical":
            choices = params.get("choices", ["A", "B", "C"])
            probabilities = params.get("probabilities", None)

            # Ensure choices is a list
            if not isinstance(choices, list):
                choices = list(choices)

            if probabilities is not None:
                # Convert to float array and normalize
                probabilities = np.array(probabilities, dtype=float)
                prob_sum = probabilities.sum()
                if prob_sum > 0:
                    probabilities = probabilities / prob_sum
                else:
                    probabilities = None

            values = self.rng.choice(choices, size=size, p=probabilities)
            return values

        # INTEGER
        elif column.type == "int":
            # Treat primary-key style columns as stable unique sequences.
            if column.name == "id":
                pool_key = f"{table_name}.{column.name}"
                start = params.get("min", 1)
                current = self._sequence_counters.get(pool_key, start)
                values = np.arange(current, current + size)
                self._sequence_counters[pool_key] = current + size
                return values.astype(int)

            # Handle unique integer generation
            if column.unique:
                pool_key = f"{table_name}.{column.name}"

                # Verify we aren't asking for more uniques than possible
                low = params.get("min", 0)
                high = params.get("max", 1000)
                total_needed_for_table = self.config.get_table(table_name).row_count

                if pool_key not in self._unique_pools:
                    # Check range capacity
                    if (high - low) < total_needed_for_table:
                        # Auto-expand range to fix user error (common in tests/small ranges)
                        warnings.warn(f"Range {high-low} too small for unique column {column.name} (needs {total_needed_for_table}). Extending max.")
                        high = low + total_needed_for_table + 100

                    # Generate full permutation
                    pool = np.arange(low, high)
                    self.rng.shuffle(pool)
                    self._unique_pools[pool_key] = pool
                    self._unique_counters[pool_key] = 0

                # Fetch chunk
                current_idx = self._unique_counters[pool_key]
                if current_idx + size > len(self._unique_pools[pool_key]):
                     raise ValueError(f"Exhausted unique values for {column.name}")

                values = self._unique_pools[pool_key][current_idx : current_idx + size]
                self._unique_counters[pool_key] += size
                return values.astype(int)

            distribution = params.get("distribution", "normal")

            # Handle categorical distribution (fixed choices)
            if distribution == "categorical" or "choices" in params:
                choices = params.get("choices", [1, 2, 3, 4, 5])
                probabilities = params.get("probabilities", None)
                if probabilities is not None:
                    probabilities = np.array(probabilities)
                    probabilities = probabilities / probabilities.sum()
                values = self.rng.choice(choices, size=size, p=probabilities)
                return np.array(values).astype(int)
            elif distribution == "normal":
                mean = params.get("mean", 100)
                std = params.get("std", 20)
                values = self.rng.normal(mean, std, size=size).astype(int)
            elif distribution == "uniform":
                low = params.get("min", 0)
                high = params.get("max", 1000)
                values = self.rng.integers(low, high, size=size)
            elif distribution == "poisson":
                lam = params.get("lambda", 10)
                values = self.rng.poisson(lam, size=size)
            else:
                low = params.get("min", 0)
                high = params.get("max", 1000)
                values = self.rng.integers(low, high, size=size)

            if "min" in params:
                values = np.maximum(values, params["min"])
            if "max" in params:
                values = np.minimum(values, params["max"])

            return values

        # FLOAT
        elif column.type == "float":
            distribution = params.get("distribution", "normal")

            if distribution == "categorical" or "choices" in params:
                choices = params.get("choices", [1.0, 2.0, 3.0])
                probabilities = params.get("probabilities", None)
                if probabilities is not None:
                    probabilities = np.array(probabilities)
                    probabilities = probabilities / probabilities.sum()
                values = self.rng.choice(choices, size=size, p=probabilities)
                return np.array(values).astype(float)
            elif distribution == "normal":
                mean = params.get("mean", 100.0)
                std = params.get("std", 20.0)
                values = self.rng.normal(mean, std, size=size)
            elif distribution == "uniform":
                low = params.get("min", 0.0)
                high = params.get("max", 1000.0)
                values = self.rng.uniform(low, high, size=size)
            elif distribution == "exponential":
                scale = params.get("scale", 1.0)
                values = self.rng.exponential(scale, size=size)
            else:
                low = params.get("min", 0.0)
                high = params.get("max", 1000.0)
                values = self.rng.uniform(low, high, size=size)

            if "min" in params:
                values = np.maximum(values, params["min"])
            if "max" in params:
                values = np.minimum(values, params["max"])
            if "decimals" in params:
                values = np.round(values, params["decimals"])

            return values

        # DATE
        elif column.type == "date":
            # Parent-Relative Date Generation (Time Travel Fix)
            if "relative_to" in params:
                # Format: "parent_table.column_name"
                try:
                    rel_table, rel_col = params["relative_to"].split(".")
                    # Find relationship
                    relationship = None
                    for rel in self.config.relationships:
                        if rel.child_table == table_name and rel.parent_table == rel_table:
                            relationship = rel
                            break

                    if relationship and table_data is not None and relationship.child_key in table_data.columns:
                        # Vectorized lookup!
                        child_fk_values = table_data[relationship.child_key].values
                        parent_df = self.context.get(rel_table)

                        if parent_df is not None and rel_col in parent_df.columns:
                            # Map FK to Parent Date
                            # Create a lookup series/dict
                            parent_date_map = parent_df.set_index(relationship.parent_key)[rel_col]
                            parent_dates = parent_date_map.reindex(child_fk_values).values

                            # Generate deltas
                            min_delta = params.get("min_delta_days", 0)
                            max_delta = params.get("max_delta_days", 365)
                            deltas = self.rng.integers(min_delta, max_delta, size=size)
                            deltas_ns = deltas.astype('timedelta64[D]')

                            # Child Date = Parent Date + Delta
                            values = parent_dates + deltas_ns
                            return values
                except Exception as e:
                    warnings.warn(f"Failed to generate relative date: {e}. Falling back to random range.")

            start = pd.to_datetime(params["start"])
            end = pd.to_datetime(params["end"])

            start_int = start.value
            end_int = end.value
            random_ints = self.rng.integers(start_int, end_int, size=size)
            values = pd.to_datetime(random_ints)

            return values

        # FOREIGN KEY
        elif column.type == "foreign_key":
            relationship = None
            for rel in self.config.relationships:
                if rel.child_table == table_name and rel.child_key == column.name:
                    relationship = rel
                    break

            if relationship is None:
                warnings.warn(
                    f"No relationship defined for foreign key '{column.name}' "
                    f"in table '{table_name}'. Generating sequential IDs instead."
                )
                values = self.rng.integers(1, max(size // 10, 100), size=size)
                return values

            # Check context instead of data
            if relationship.parent_table not in self.context:
                warnings.warn(
                    f"Parent table '{relationship.parent_table}' not yet generated for "
                    f"foreign key '{column.name}'. Generating sequential IDs instead."
                )
                values = self.rng.integers(1, max(size // 10, 100), size=size)
                return values

            parent_ids = self._get_parent_ids(relationship)

            if len(parent_ids) == 0:
                warnings.warn(
                    f"Parent table '{relationship.parent_table}' has no valid IDs in context (after filters). "
                    f"Generating sequential IDs for foreign key '{column.name}'."
                )
                values = self.rng.integers(1, max(size // 10, 100), size=size)
                return values

            values = self.rng.choice(parent_ids, size=size)
            return values

        # TEXT
        elif column.type == "text":
            text_type = params.get("text_type", "sentence")
            
            # Smart value generation - check for domain-specific content
            smart_generate = params.get("smart_generate", False) or self.smart_mode
            if smart_generate:
                smart_gen = self._get_smart_gen()
                if smart_gen:
                    # Check for explicit domain hint or auto-detect
                    domain_hint = params.get("domain_hint")
                    context = params.get("context", "")
                    
                    # Create cache key for this column's pool
                    pool_key = f"{table_name}.{column.name}"
                    
                    if pool_key not in self._smart_pools:
                        pool = smart_gen.get_pool(
                            column_name=column.name,
                            table_name=table_name,
                            domain_hint=domain_hint,
                            context=context,
                            size=100,
                            use_llm=self.use_llm,
                        )
                        if pool:
                            self._smart_pools[pool_key] = np.array(pool)
                    
                    if pool_key in self._smart_pools:
                        pool = self._smart_pools[pool_key]
                        values = self.rng.choice(pool, size=size)
                        return values

            if text_type == "name":
                pool_key = "text_name"
                if pool_key not in self._text_pools:
                    pool_size = min(size, self.TEXT_POOL_SIZE)
                    self._text_pools[pool_key] = np.array([self.text_gen.name() for _ in range(pool_size)])
                values = self.rng.choice(self._text_pools[pool_key], size=size)
            elif text_type == "email":
                pool_key = "text_email"
                if pool_key not in self._text_pools:
                    pool_size = min(size, self.TEXT_POOL_SIZE)
                    self._text_pools[pool_key] = np.array([self.text_gen.email() for _ in range(pool_size)])
                values = self.rng.choice(self._text_pools[pool_key], size=size)
            elif text_type == "company":
                pool_key = "text_company"
                if pool_key not in self._text_pools:
                    pool_size = min(size, self.TEXT_POOL_SIZE)
                    self._text_pools[pool_key] = np.array([self.text_gen.company() for _ in range(pool_size)])
                values = self.rng.choice(self._text_pools[pool_key], size=size)
            elif text_type == "sentence":
                pool_key = "text_sentence"
                if pool_key not in self._text_pools:
                    pool_size = min(size, self.TEXT_POOL_SIZE)
                    self._text_pools[pool_key] = np.array([self.text_gen.sentence() for _ in range(pool_size)])
                values = self.rng.choice(self._text_pools[pool_key], size=size)
            elif text_type == "word":
                pool_key = "text_word"
                if pool_key not in self._text_pools:
                    pool_size = min(size, self.TEXT_POOL_SIZE)
                    self._text_pools[pool_key] = np.array([self.text_gen.word() for _ in range(pool_size)])
                values = self.rng.choice(self._text_pools[pool_key], size=size)
            elif text_type == "address":
                pool_key = "text_address"
                if pool_key not in self._text_pools:
                    pool_size = min(size, self.TEXT_POOL_SIZE)
                    self._text_pools[pool_key] = np.array([self.text_gen.full_address() for _ in range(pool_size)])
                values = self.rng.choice(self._text_pools[pool_key], size=size)
            elif text_type == "phone":
                pool_key = "text_phone"
                if pool_key not in self._text_pools:
                    pool_size = min(size, self.TEXT_POOL_SIZE)
                    self._text_pools[pool_key] = np.array([self.text_gen.phone_number() for _ in range(pool_size)])
                values = self.rng.choice(self._text_pools[pool_key], size=size)
            elif text_type == "url":
                pool_key = "text_url"
                if pool_key not in self._text_pools:
                    pool_size = min(size, self.TEXT_POOL_SIZE)
                    self._text_pools[pool_key] = np.array([self.text_gen.url() for _ in range(pool_size)])
                values = self.rng.choice(self._text_pools[pool_key], size=size)
            else:
                pool_key = "text_sentence"
                if pool_key not in self._text_pools:
                    pool_size = min(size, self.TEXT_POOL_SIZE)
                    self._text_pools[pool_key] = np.array([self.text_gen.sentence() for _ in range(pool_size)])
                values = self.rng.choice(self._text_pools[pool_key], size=size)

            return values

        # BOOLEAN
        elif column.type == "boolean":
            probability = params.get("probability", 0.5)
            values = self.rng.random(size) < probability
            return values

        # TIME
        elif column.type == "time":
            # Generate random times as HH:MM:SS strings
            start_hour = params.get("start_hour", 0)
            end_hour = params.get("end_hour", 24)
            hours = self.rng.integers(start_hour, end_hour, size=size)
            minutes = self.rng.integers(0, 60, size=size)
            seconds = self.rng.integers(0, 60, size=size)
            values = np.array([f"{h:02d}:{m:02d}:{s:02d}" for h, m, s in zip(hours, minutes, seconds)])
            return values

        # DATETIME
        elif column.type == "datetime":
            # Generate random datetimes within a range
            start = pd.to_datetime(params.get("start", "2020-01-01"))
            end = pd.to_datetime(params.get("end", "2024-12-31"))
            start_int = start.value
            end_int = end.value
            random_ints = self.rng.integers(start_int, end_int, size=size)
            values = pd.to_datetime(random_ints)
            return values

        else:
            raise ValueError(f"Unknown column type: {column.type}")

    def apply_event(self, df: pd.DataFrame, event: ScenarioEvent) -> pd.DataFrame:
        """Apply a scenario event to modify data based on conditions."""
        try:
            mask = df.eval(event.condition)
        except Exception as e:
            warnings.warn(f"Failed to evaluate condition '{event.condition}' for event '{event.name}': {e}")
            return df

        if event.modifier_type == "multiply":
            df.loc[mask, event.column] *= event.modifier_value
        elif event.modifier_type == "add":
            df.loc[mask, event.column] += event.modifier_value
        elif event.modifier_type == "set":
            df.loc[mask, event.column] = event.modifier_value
        elif event.modifier_type == "function":
            warnings.warn(f"Function modifiers not yet implemented for event '{event.name}'")

        return df

    def _update_context(self, table_name: str, df: pd.DataFrame) -> None:
        """
        Update the context with key columns from the generated batch.

        Smart Context Logic:
        1. Store Primary Key ('id')
        2. Store columns used as foreign keys by children (parent_key)
        3. Store columns used in Relationship filters (Logic Gap fix)
        4. Store columns used in 'relative_to' date constraints (Time Travel fix)
        """
        needed_cols = {'id'}

        # 2. FK and Filter dependencies
        for rel in self.config.relationships:
            if rel.parent_table == table_name:
                needed_cols.add(rel.parent_key)
                if rel.filters:
                    for col in rel.filters.keys():
                        needed_cols.add(col)

        # 4. Filter 'relative_to' dependencies
        # This requires scanning ALL columns of ALL child tables to see if they reference this table
        # Optimization: Build this dependency map once in __init__?
        # For now, we scan here. It's fast enough for schema sizes < 100 tables.
        for child_table in self.config.tables:
            child_cols = self.config.get_columns(child_table.name)
            for col in child_cols:
                if col.type == 'date' and 'relative_to' in col.distribution_params:
                    # Format: "parent_table.column"
                    try:
                        ptable, pcol = col.distribution_params['relative_to'].split('.')
                        if ptable == table_name:
                            needed_cols.add(pcol)
                    except Exception:
                        pass

        cols_to_store = [c for c in needed_cols if c in df.columns]
        if not cols_to_store:
            return

        ctx_df = df[cols_to_store].copy()

        if table_name not in self.context:
            self.context[table_name] = ctx_df
        else:
            # Append to existing context
            self.context[table_name] = pd.concat([self.context[table_name], ctx_df], ignore_index=True)

    def generate_batches(self, table_name: str) -> Any:
        """
        Yield batches of generated data for a table.

        Args:
            table_name: Name of the table to generate

        Yields:
            DataFrame batch
        """
        table = self.config.get_table(table_name)
        if table is None:
            raise ValueError(f"Table '{table_name}' not found in schema")

        # Reference table with inline data - yield as single batch
        if table.is_reference and table.inline_data:
            df = pd.DataFrame(table.inline_data)
            self._update_context(table_name, df)
            yield df
            return

        columns = self.config.get_columns(table_name)
        total_rows = table.row_count

        rows_generated = 0

        while rows_generated < total_rows:
            batch_size = min(self.batch_size, total_rows - rows_generated)

            # Generate batch
            data = {}
            df_batch = pd.DataFrame()

            for column in columns:
                values = self.generate_column(table_name, column, batch_size, df_batch)
                data[column.name] = values
                df_batch[column.name] = values

            df_batch = pd.DataFrame(data)

            # Apply formulas
            df_batch = self._apply_formula_columns(df_batch, table_name)

            # Post-process
            df_batch = self._fix_correlated_columns(df_batch, table_name)

            # Apply events
            table_events = [e for e in self.config.events if e.table == table_name]
            for event in table_events:
                df_batch = self.apply_event(df_batch, event)

            # Apply business rule constraints
            df_batch = self.apply_constraints(df_batch, table)
            
            # Apply outcome curves (Trends/Seasonality)
            df_batch = self.apply_outcome_curves(df_batch, table_name)

            # Update context for future batches/tables
            self._update_context(table_name, df_batch)

            yield df_batch

            rows_generated += batch_size

    def apply_constraints(self, df: pd.DataFrame, table: Any) -> pd.DataFrame:
        """
        Apply business rule constraints to generated data.

        Args:
            df: DataFrame batch to constrain
            table: Table definition containing constraints

        Returns:
            Constrained DataFrame
        """
        if not hasattr(table, 'constraints') or not table.constraints:
            return df

        for constraint in table.constraints:
            df = self._apply_single_constraint(df, constraint)

        return df

    def apply_outcome_curves(self, df: pd.DataFrame, table_name: str) -> pd.DataFrame:
        """
        Apply temporal outcome curves to force data to match trends/seasonality.
        
        This overrides the base distribution with the high-level constraints
        defined in the prompt (e.g. "seasonal peaks", "upward trend").
        """
        if not hasattr(self.config, 'outcome_curves') or not self.config.outcome_curves:
            print(f"[CURVE DEBUG] No outcome_curves found in config for {table_name}")
            return df

        print(f"[CURVE DEBUG] Found {len(self.config.outcome_curves)} curves in config")
        
        # Filter curves for this table - handle both dict and Pydantic object
        curves = []
        for c in self.config.outcome_curves:
            # Get table name from curve (handle both dict and object)
            c_table = c.table if hasattr(c, 'table') else c.get('table')
            if c_table == table_name:
                curves.append(c)
        
        print(f"[CURVE DEBUG] {len(curves)} curves match table '{table_name}'")
        
        for curve in curves:
            try:
                # Access attributes (Pydantic) or dict keys
                target_col = curve.column if hasattr(curve, 'column') else curve['column']
                time_col = curve.time_column if hasattr(curve, 'time_column') else curve['time_column']
                points = curve.curve_points if hasattr(curve, 'curve_points') else curve.get('curve_points', [])
                pattern_type = curve.pattern_type if hasattr(curve, 'pattern_type') else curve.get('pattern_type', 'seasonal')
                
                print(f"[CURVE DEBUG] Applying curve: table={table_name}, col={target_col}, time_col={time_col}, pattern={pattern_type}")
                print(f"[CURVE DEBUG] DF columns: {list(df.columns)}")
                
                if target_col not in df.columns:
                    print(f"[CURVE DEBUG] Target column '{target_col}' not in DataFrame!")
                    continue
                if time_col not in df.columns:
                    print(f"[CURVE DEBUG] Time column '{time_col}' not in DataFrame!")
                    continue
                    
                if not points:
                    print(f"[CURVE DEBUG] No curve points!")
                    continue
                
                # Convert Pydantic CurvePoint objects to dicts if needed
                point_dicts = []
                for p in points:
                    if hasattr(p, 'month'):
                        point_dicts.append({'month': p.month, 'relative_value': p.relative_value})
                    else:
                        point_dicts.append(p)
                points = point_dicts
                
                print(f"[CURVE DEBUG] Points: {points}")

                # Sort points by order (month or progress)
                points.sort(key=lambda x: x.get('month', x.get('x', 0)))

                pattern_type = curve.get('pattern_type', 'seasonal')
                
                # Extract time components
                if not pd.api.types.is_datetime64_any_dtype(df[time_col]):
                    timestamps = pd.to_datetime(df[time_col], errors='coerce')
                else:
                    timestamps = df[time_col]

                # Initialize factors
                row_factors = np.ones(len(df))

                # STRATEGY 1: SEASONAL (Cyclic 1-12)
                if pattern_type in ['seasonal', 'cyclic']:
                    months = timestamps.dt.month
                    scaling_factors = np.ones(13) # Index 1-12
                    
                    x_known = np.array([p['month'] for p in points])
                    y_known = np.array([p['relative_value'] for p in points])
                    
                    for m in range(1, 13):
                        if m < x_known.min():
                            scaling_factors[m] = y_known[0]
                        elif m > x_known.max():
                            scaling_factors[m] = y_known[-1]
                        else:
                            scaling_factors[m] = np.interp(m, x_known, y_known)
                    
                    row_factors = scaling_factors[months.fillna(1).astype(int).values]

                # STRATEGY 2: GROWTH/TREND (Linear over absolute time)
                elif pattern_type in ['growth', 'trend', 'increase', 'decline']:
                    # Normalize time to 0.0 - 1.0 range
                    t_min = timestamps.min()
                    t_max = timestamps.max()
                    
                    if t_min == t_max:
                        row_factors = np.ones(len(df))
                    else:
                        # Convert to numeric (timestamps)
                        t_numerics = timestamps.astype(np.int64)
                        t_start = t_numerics.min()
                        t_range = t_numerics.max() - t_start
                        
                        # Normalize 0.0 to 1.0
                        t_norm = (t_numerics - t_start) / t_range
                        
                        # Map points (assume points are mapped 1-12 or 0.0-1.0?)
                        # The LLM outputs "month" 1-12 usually. Let's map 1=Start, 12=End?
                        # Or safer: interpolating 1-12 across the whole range.
                        
                        x_known = np.array([p['month'] for p in points])
                        y_known = np.array([p['relative_value'] for p in points])
                        
                        # Normalize x_known to 0.0-1.0 range (assuming 1..12 scale from LLM)
                        # If LLM says Month 1 to 12, we treat 1 as 0.0 and 12 as 1.0
                        x_known_norm = (x_known - 1) / 11.0 # 1->0, 12->1
                        
                        # Interpolate
                        row_factors = np.interp(t_norm, x_known_norm, y_known)

                # Apply!
                df[target_col] = df[target_col] * row_factors
                
            except Exception as e:
                warnings.warn(f"Failed to apply outcome curve for {table_name}: {e}")
                continue
                
        return df

    def _apply_single_constraint(self, df: pd.DataFrame, constraint: Any) -> pd.DataFrame:
        """Apply a single constraint to the DataFrame."""

        # Validate required columns exist
        for col in constraint.group_by:
            if col not in df.columns:
                warnings.warn(f"Constraint '{constraint.name}': Column '{col}' not found. Skipping.")
                return df

        if constraint.column and constraint.column not in df.columns:
            warnings.warn(f"Constraint '{constraint.name}': Target column '{constraint.column}' not found. Skipping.")
            return df

        if constraint.type == "max_per_group":
            # Cap values per group (e.g., max 8 hours per employee per day)
            if constraint.action == "cap":
                # Simple cap: clip the value column
                df[constraint.column] = df.groupby(constraint.group_by)[constraint.column].transform(
                    lambda x: x.clip(upper=constraint.value)
                )
            elif constraint.action == "redistribute":
                # More complex: redistribute excess across the group
                # For now, just cap
                df[constraint.column] = df.groupby(constraint.group_by)[constraint.column].transform(
                    lambda x: x.clip(upper=constraint.value)
                )

        elif constraint.type == "sum_limit":
            # Limit sum per group (e.g., max 8 total hours per employee per day across projects)
            def cap_sum(group):
                total = group[constraint.column].sum()
                if total > constraint.value:
                    # Scale down proportionally
                    scale = constraint.value / total
                    group[constraint.column] = group[constraint.column] * scale
                return group

            df = df.groupby(constraint.group_by, group_keys=False).apply(cap_sum)

        elif constraint.type == "unique_combination":
            # Ensure unique combinations (e.g., one timesheet per employee-project-date)
            if constraint.action == "drop":
                df = df.drop_duplicates(subset=constraint.group_by, keep='first')

        elif constraint.type == "min_per_group":
            # Floor values per group
            if constraint.action == "cap":
                df[constraint.column] = df.groupby(constraint.group_by)[constraint.column].transform(
                    lambda x: x.clip(lower=constraint.value)
                )

        return df

    def _apply_formula_columns(self, df: pd.DataFrame, table_name: str) -> pd.DataFrame:
        """Apply formula-based derived columns using context for lookups."""
        try:
            from misata.formulas import FormulaEngine
        except ImportError:
            return df

        columns = self.config.get_columns(table_name)
        formula_cols = [c for c in columns if c.distribution_params.get("formula")]

        if not formula_cols:
            return df

        # FormulaEngine now needs context, not full data
        # BUT FormulaEngine expects full DataFrames in tables dict for lookups
        # Our self.context IS a Dict[str, pd.DataFrame], just restricted columns
        # So it should work if the formulas only ref columns in context (like id, price)
        # Note: We need to make sure context has columns needed for formulas!
        # Current _update_context only saves PK/FKs.
        # TODO: Analyze formulas to find required context columns?
        # For now, simplistic approach: formulas usually look up 'price', 'cost' etc.
        # We might need to store more in context.
        # Let's trust user or update _update_context to be smarter later.

        engine = FormulaEngine(self.context)

        for col in formula_cols:
            formula = col.distribution_params["formula"]
            # For correctness, lookups should work.
            # If context doesn't have the column, FormulaEngine raises Error.
            try:
                result = engine.evaluate_with_lookups(df, formula)
                df[col.name] = result
            except ValueError as e:
                # Warn and skip if context missing
                warnings.warn(f"Formula evaluation failed (context missing?): {e}")

        return df

    def _fix_correlated_columns(self, df: pd.DataFrame, table_name: str) -> pd.DataFrame:
        """Post-process to fix common semantically correlated columns."""
        try:
            from misata.realism import apply_realism_rules
        except Exception:
            return df
        return apply_realism_rules(df, table_name)

    def generate_all(self):
        """
        Generate all tables in dependency order.

        Yields:
            Tuple[str, pd.DataFrame]: (table_name, batch_df)
        """
        sorted_tables = self.topological_sort()

        for table_name in sorted_tables:
            for batch in self.generate_batches(table_name):
                yield table_name, batch

    def export_to_csv(self, output_dir: str = ".") -> None:
        """
        Export all generated tables to CSV files, creating files progressively.
        """
        import os
        os.makedirs(output_dir, exist_ok=True)

        # Track open file handles or just append?
        # Appending is safer.
        files_created = set()

        for table_name, batch_df in self.generate_all():
            output_path = os.path.join(output_dir, f"{table_name}.csv")
            mode = 'a' if table_name in files_created else 'w'
            header = table_name not in files_created

            batch_df.to_csv(output_path, mode=mode, header=header, index=False)
            files_created.add(table_name)

    def get_summary(self) -> str:
        """
        Get a summary of generated data (from context).
        Only shows context info since full data isn't kept.
        """
        summary_lines = ["Generated Context Summary (Lightweight):", "=" * 50]

        for table_name, df in self.context.items():
            summary_lines.append(f"\n{table_name}: {len(df):,} rows tracked in context")
            summary_lines.append(f"  Context Columns: {list(df.columns)}")
            summary_lines.append(f"  Context Memory: {df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")

        return "\n".join(summary_lines)
