"""Protocols for kafkalite producer and consumer implementations."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Protocol

from .models import PublishAck, ReceivedMessage, TopicPartition


class EventConsumerRebalanceListener(Protocol):
    def on_partitions_revoked(self, revoked: set[TopicPartition]) -> None: ...

    def on_partitions_assigned(self, assigned: set[TopicPartition]) -> None: ...


class EventProducer(Protocol):
    async def start(self) -> None: ...

    async def stop(self) -> None: ...

    async def send_and_wait(
        self,
        topic: str,
        *,
        value: object,
        key: str | None = None,
        headers: Sequence[tuple[str, bytes]] | None = None,
    ) -> PublishAck: ...


class EventConsumer(Protocol):
    def subscribe(
        self,
        topics: Sequence[str],
        listener: EventConsumerRebalanceListener | None = None,
    ) -> None: ...

    async def start(self) -> None: ...

    async def stop(self) -> None: ...

    async def commit(self, offsets: Mapping[TopicPartition, int]) -> None: ...

    def seek(self, tp: TopicPartition, offset: int) -> None: ...

    def __aiter__(self) -> EventConsumer: ...

    async def __anext__(self) -> ReceivedMessage: ...
