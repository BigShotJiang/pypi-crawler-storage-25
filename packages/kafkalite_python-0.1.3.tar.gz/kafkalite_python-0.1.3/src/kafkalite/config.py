"""Shared configuration models for kafkalite clients."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class KafkaliteConfig:
    brokers: list[str] = field(default_factory=lambda: ["127.0.0.1:7171"])
