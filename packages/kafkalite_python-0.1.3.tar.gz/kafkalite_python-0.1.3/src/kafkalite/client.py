"""gRPC-backed kafkalite transport adapters."""

# pyright: reportAttributeAccessIssue=false

from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from collections.abc import Mapping, Sequence
from typing import Any

import grpc

from ._generated import kafkalite_pb2, kafkalite_pb2_grpc
from .config import KafkaliteConfig
from .interfaces import EventConsumerRebalanceListener
from .models import PublishAck, ReceivedMessage, TopicPartition

_POLL_LIMIT = 1
_POLL_INTERVAL_SECONDS = 0.1
_HEARTBEAT_INTERVAL_SECONDS = 1.0
_SESSION_TIMEOUT_MS = 10_000

logger = logging.getLogger(__name__)


def _now_unix_ms() -> int:
    return time.time_ns() // 1_000_000


def _encode_headers(
    headers: Sequence[tuple[str, bytes]] | None,
) -> list[kafkalite_pb2.Header]:
    if not headers:
        return []
    return [kafkalite_pb2.Header(key=key, value=value) for key, value in headers]


def _decode_headers(
    headers: Sequence[kafkalite_pb2.Header] | None,
) -> list[tuple[str, bytes]]:
    if not headers:
        return []
    return [(header.key, bytes(header.value)) for header in headers]


def _encode_payload(value: object) -> bytes:
    return json.dumps(value).encode("utf-8")


def _decode_payload(raw_payload: bytes) -> Any:
    return json.loads(raw_payload.decode("utf-8"))


def _set_partition_zero(request: object) -> None:
    if hasattr(request, "partition"):
        request.partition = 0


def _target(config: KafkaliteConfig) -> str:
    if not config.brokers:
        raise ValueError("kafkalite requires at least one broker endpoint")
    if len(config.brokers) > 1:
        logger.warning(
            "kafkalite currently uses only the first broker endpoint: %s",
            config.brokers[0],
        )
    return config.brokers[0]


def _is_rejoin_error(error: grpc.aio.AioRpcError) -> bool:
    return error.code() in {
        grpc.StatusCode.FAILED_PRECONDITION,
        grpc.StatusCode.PERMISSION_DENIED,
    }


class KafkaliteProducerAdapter:
    def __init__(
        self,
        config: KafkaliteConfig,
        *,
        channel: grpc.aio.Channel | None = None,
        stub: kafkalite_pb2_grpc.KafkaliteStub | None = None,
    ) -> None:
        self._config = config
        self._channel = channel
        self._stub = stub
        self._owns_channel = channel is None and stub is None

    async def start(self) -> None:
        if self._stub is None:
            if self._channel is None:
                self._channel = grpc.aio.insecure_channel(_target(self._config))
            self._stub = kafkalite_pb2_grpc.KafkaliteStub(self._channel)

    async def stop(self) -> None:
        if self._channel is not None and self._owns_channel:
            await self._channel.close()
        self._channel = None
        self._stub = None

    async def send_and_wait(
        self,
        topic: str,
        *,
        value: object,
        key: str | None = None,
        headers: Sequence[tuple[str, bytes]] | None = None,
    ) -> PublishAck:
        stub = self._require_stub()
        ack = await stub.Publish(
            kafkalite_pb2.NewMessage(
                topic=topic,
                key=key or "",
                payload_json=_encode_payload(value),
                headers=_encode_headers(headers),
                published_at_unix_ms=_now_unix_ms(),
            )
        )
        return PublishAck(topic=ack.topic, partition=ack.partition, offset=ack.offset)

    def _require_stub(self) -> kafkalite_pb2_grpc.KafkaliteStub:
        if self._stub is None:
            raise RuntimeError(f"kafkalite producer is not started ({_target(self._config)})")
        return self._stub


class KafkaliteConsumerAdapter:
    def __init__(
        self,
        config: KafkaliteConfig,
        *,
        group_id: str,
        topics: Sequence[str] | None = None,
        auto_offset_reset: str = "earliest",
        channel: grpc.aio.Channel | None = None,
        stub: kafkalite_pb2_grpc.KafkaliteStub | None = None,
    ) -> None:
        self._config = config
        self._group_id = group_id
        self._member_id = f"{group_id}-{uuid.uuid4().hex[:12]}"
        self._topics = list(topics or [])
        self._auto_offset_reset = auto_offset_reset
        self._channel = channel
        self._stub = stub
        self._owns_channel = channel is None and stub is None
        self._listener: EventConsumerRebalanceListener | None = None
        self._assigned: set[TopicPartition] = set()
        self._fetch_offsets: dict[str, int] = {}
        self._topic_index = 0
        self._generation = 0
        self._coordination_lock = asyncio.Lock()
        self._heartbeat_task: asyncio.Task[None] | None = None

    def subscribe(
        self,
        topics: Sequence[str],
        listener: EventConsumerRebalanceListener | None = None,
    ) -> None:
        self._topics = list(topics)
        self._listener = listener

    async def start(self) -> None:
        if self._stub is None:
            if self._channel is None:
                self._channel = grpc.aio.insecure_channel(_target(self._config))
            self._stub = kafkalite_pb2_grpc.KafkaliteStub(self._channel)

        await self._join_group()
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    async def stop(self) -> None:
        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass
            self._heartbeat_task = None

        old_assigned = self._assigned
        self._assigned = set()
        self._fetch_offsets = {}
        if self._listener is not None and old_assigned:
            self._listener.on_partitions_revoked(old_assigned)

        if self._stub is not None:
            try:
                await self._stub.LeaveGroup(
                    kafkalite_pb2.LeaveGroupRequest(
                        group_id=self._group_id,
                        member_id=self._member_id,
                    )
                )
            except grpc.aio.AioRpcError:
                logger.exception("kafkalite leave-group failed")

        self._generation = 0
        if self._channel is not None and self._owns_channel:
            await self._channel.close()
        self._channel = None
        self._stub = None

    async def commit(self, offsets: Mapping[TopicPartition, int]) -> None:
        stub = self._require_stub()
        async with self._coordination_lock:
            for tp, offset in offsets.items():
                if tp.partition != 0:
                    raise ValueError("kafkalite only supports partition 0")
                try:
                    response = await stub.CommitOffsets(
                        _commit_offsets_request(
                            group_id=self._group_id,
                            member_id=self._member_id,
                            generation=self._generation,
                            topic=tp.topic,
                            next_offset=offset,
                            updated_at_unix_ms=_now_unix_ms(),
                        )
                    )
                except grpc.aio.AioRpcError as error:
                    if _is_rejoin_error(error):
                        await self._join_group_locked()
                    raise
                if not response.committed:
                    raise RuntimeError(f"kafkalite commit rejected for {tp.topic}@{offset}")

    def seek(self, tp: TopicPartition, offset: int) -> None:
        if tp.partition != 0:
            raise ValueError("kafkalite only supports partition 0")
        if tp not in self._assigned:
            raise ValueError(f"kafkalite topic-partition is not assigned: {tp}")
        self._fetch_offsets[tp.topic] = offset

    def __aiter__(self) -> KafkaliteConsumerAdapter:
        return self

    async def __anext__(self) -> ReceivedMessage:
        while True:
            topics = [tp.topic for tp in sorted(self._assigned, key=lambda tp: tp.topic)]
            if not topics:
                await asyncio.sleep(_POLL_INTERVAL_SECONDS)
                continue

            for _ in range(len(topics)):
                topic = topics[self._topic_index % len(topics)]
                self._topic_index = (self._topic_index + 1) % len(topics)
                message = await self._read_one(topic)
                if message is not None:
                    self._fetch_offsets[topic] = message.offset + 1
                    return message
            await asyncio.sleep(_POLL_INTERVAL_SECONDS)

    async def _heartbeat_loop(self) -> None:
        stub = self._require_stub()
        try:
            while True:
                await asyncio.sleep(_HEARTBEAT_INTERVAL_SECONDS)
                async with self._coordination_lock:
                    response = await stub.Heartbeat(
                        kafkalite_pb2.HeartbeatRequest(
                            group_id=self._group_id,
                            member_id=self._member_id,
                            generation=self._generation,
                            heartbeat_at_unix_ms=_now_unix_ms(),
                        )
                    )
                    if response.needs_rejoin:
                        await self._join_group_locked()
        except asyncio.CancelledError:
            raise
        except grpc.aio.AioRpcError:
            logger.exception("kafkalite heartbeat failed")

    async def _join_group(self) -> None:
        async with self._coordination_lock:
            await self._join_group_locked()

    async def _join_group_locked(self) -> None:
        if self._auto_offset_reset != "earliest":
            raise ValueError(
                "kafkalite currently supports committed offsets or auto_offset_reset='earliest'"
            )

        response = await self._require_stub().JoinGroup(
            _join_group_request(
                group_id=self._group_id,
                member_id=self._member_id,
                topics=self._topics,
                session_timeout_ms=_SESSION_TIMEOUT_MS,
                joined_at_unix_ms=_now_unix_ms(),
            )
        )
        self._generation = response.generation
        new_assigned = {TopicPartition(item.topic, item.partition) for item in response.assignments}
        revoked = self._assigned - new_assigned
        assigned = new_assigned - self._assigned
        if self._listener is not None and revoked:
            self._listener.on_partitions_revoked(revoked)
        self._assigned = new_assigned
        self._fetch_offsets = {item.topic: int(item.next_offset) for item in response.assignments}
        if self._listener is not None and assigned:
            self._listener.on_partitions_assigned(assigned)

    async def _read_one(self, topic: str) -> ReceivedMessage | None:
        stub = self._require_stub()
        try:
            response = await stub.PollMessages(
                _poll_messages_request(
                    group_id=self._group_id,
                    member_id=self._member_id,
                    generation=self._generation,
                    topic=topic,
                    start_offset=self._fetch_offsets.get(topic, 0),
                    limit=_POLL_LIMIT,
                )
            )
        except grpc.aio.AioRpcError as error:
            if _is_rejoin_error(error):
                await self._join_group()
                return None
            raise
        if not response.messages:
            return None
        raw = response.messages[0]
        return ReceivedMessage(
            topic=raw.topic,
            partition=raw.partition,
            offset=raw.offset,
            value=_decode_payload(bytes(raw.payload_json)),
            headers=_decode_headers(raw.headers),
            key=raw.key or None,
        )

    def _require_stub(self) -> kafkalite_pb2_grpc.KafkaliteStub:
        if self._stub is None:
            raise RuntimeError(f"kafkalite consumer is not started ({_target(self._config)})")
        return self._stub


def _join_group_request(
    *,
    group_id: str,
    member_id: str,
    topics: Sequence[str],
    session_timeout_ms: int,
    joined_at_unix_ms: int,
) -> kafkalite_pb2.JoinGroupRequest:
    request = kafkalite_pb2.JoinGroupRequest(
        group_id=group_id,
        member_id=member_id,
        topics=list(topics),
        session_timeout_ms=session_timeout_ms,
        joined_at_unix_ms=joined_at_unix_ms,
    )
    _set_partition_zero(request)
    return request


def _poll_messages_request(
    *,
    group_id: str,
    member_id: str,
    generation: int,
    topic: str,
    start_offset: int,
    limit: int,
) -> kafkalite_pb2.PollMessagesRequest:
    request = kafkalite_pb2.PollMessagesRequest(
        group_id=group_id,
        member_id=member_id,
        generation=generation,
        topic=topic,
        start_offset=start_offset,
        limit=limit,
        wait_ms=0,
    )
    _set_partition_zero(request)
    return request


def _commit_offsets_request(
    *,
    group_id: str,
    member_id: str,
    generation: int,
    topic: str,
    next_offset: int,
    updated_at_unix_ms: int,
) -> kafkalite_pb2.CommitOffsetsRequest:
    request = kafkalite_pb2.CommitOffsetsRequest(
        group_id=group_id,
        member_id=member_id,
        generation=generation,
        topic=topic,
        next_offset=next_offset,
        updated_at_unix_ms=updated_at_unix_ms,
    )
    _set_partition_zero(request)
    return request
