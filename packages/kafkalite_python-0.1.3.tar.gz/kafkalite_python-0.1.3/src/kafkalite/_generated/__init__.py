"""Generated protobuf bindings for kafkalite."""

from __future__ import annotations
