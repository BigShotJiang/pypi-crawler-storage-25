from __future__ import annotations

from kafkalite import KafkaliteConfig, KafkaliteConsumer, KafkaliteProducer, TopicPartition


def test_public_api_exports_kafkalite_names() -> None:
    assert KafkaliteConfig.__name__ == "KafkaliteConfig"
    assert KafkaliteConsumer.__name__ == "KafkaliteConsumerAdapter"
    assert KafkaliteProducer.__name__ == "KafkaliteProducerAdapter"


def test_config_defaults_and_topic_partition_shape() -> None:
    config = KafkaliteConfig()

    assert config.brokers == ["127.0.0.1:7171"]
    assert TopicPartition("events").partition == 0
