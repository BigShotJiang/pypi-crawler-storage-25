from __future__ import annotations

from kafkalite._generated import kafkalite_pb2, kafkalite_pb2_grpc


def test_generated_stub_uses_kafkalite_service_name() -> None:
    assert kafkalite_pb2_grpc.KafkaliteStub.__name__ == "KafkaliteStub"
    assert kafkalite_pb2_grpc.Kafkalite.__name__ == "Kafkalite"


def test_generated_proto_uses_kafkalite_package() -> None:
    assert kafkalite_pb2.DESCRIPTOR.package == "kafkalite"
    assert kafkalite_pb2.DESCRIPTOR.services_by_name["Kafkalite"].full_name == "kafkalite.Kafkalite"
