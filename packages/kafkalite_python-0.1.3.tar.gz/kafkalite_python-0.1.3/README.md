# kafkalite-python

`kafkalite-python` is a small Python SDK for producing and consuming events through the `kafkalite` gRPC transport.

## Requirements

- Python `3.13+`
- A reachable `kafkalite` server endpoint

## Installation

```bash
pip install kafkalite-python
```

## Quick Start

```python
import asyncio

from kafkalite import KafkaliteConfig, KafkaliteConsumer, KafkaliteProducer, TopicPartition


async def main() -> None:
    config = KafkaliteConfig(brokers=["127.0.0.1:7171"])

    producer = KafkaliteProducer(config)
    await producer.start()
    await producer.send_and_wait("events", value={"message": "hello"})
    await producer.stop()

    consumer = KafkaliteConsumer(config, group_id="example-group", topics=["events"])
    await consumer.start()

    message = await consumer.__anext__()
    print(message.value)

    await consumer.commit({TopicPartition("events"): message.offset + 1})
    await consumer.stop()


asyncio.run(main())
```

## Public API

- `KafkaliteConfig`: broker endpoint configuration
- `KafkaliteProducer`: async producer adapter
- `KafkaliteConsumer`: async consumer adapter
- `PublishAck`, `ReceivedMessage`, `TopicPartition`: shared transport models

## Notes

- The current client uses only the first configured broker endpoint.
- Consumer support is currently limited to partition `0`.
- `auto_offset_reset` currently supports committed offsets or `"earliest"`.

## License

MIT
