from google import genai
from google.genai import types

client = genai.Client(api_key="AQ.Ab8RN6Lx5gauEQ-4hZEKNDJBOMNLyRiGL76pZxBIK06Vjw06ug")

RULES = """
Ты - решатель олимпиадных задач по информатике.
Твоя задача: вернуть только полный рабочий код решения на Python.
Запрещено:
- писать объяснения
- писать текст до кода
- писать текст после кода
- использовать ```python
- использовать комментарии
- извиняться
- задавать вопросы
Если возможно несколько решений, выдай одно лучшее.
Код должен быть коротким, корректным и готовым к запуску.
"""

while True:
    task = input()
    if task.lower() in ["exit", "quit", "выход"]:
        break

    r = client.models.generate_content(
        model="gemini-2.5-flash-lite",
        contents=task,
        config=types.GenerateContentConfig(
            system_instruction=RULES,
            temperature=0
        )
    )

    print(r.text)