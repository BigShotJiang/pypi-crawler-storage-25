# Changelog

All notable changes to this project are documented here. Versioning follows
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] — 2026-05-17

### Distribution

- **PyPI distribution name changed:** `ausdata` → `ausdata-sdk` (the
  short `ausdata` name was taken by another project on PyPI). The
  **import path stays `from ausdata import Client`** — no code changes
  required for existing users. Install command:
  `pip install ausdata-sdk` (was `pip install ausdata`).

### Added

- `client.whoami()` / `AsyncClient.whoami()` — caller introspection.
- `client.describe(source, dataset_id)` / async equivalent — schema lookup.
- `client.list_datasets(source)` / async equivalent — enumerate a source's
  curated datasets.
- `client.get_data(source, dataset_id, **filters)` / async equivalent —
  generic data fetch with kwargs for source-specific dimension filters.
- `WhoamiResponse` typed model.
- Drift-detection tests (`tests/test_model_drift.py`) — fail CI when the
  SDK model fields diverge from the live API response shape.

### Changed

- Default base URL is now `https://ausdata-api.fly.dev` (was the unconfigured
  `https://api.ausdata.io`). Override via `AUSDATA_BASE_URL` env var or the
  `base_url` constructor arg.
- `EconomicDashboard` model gained `consumer_spending_yoy_pct`. The old
  `lending_housing_change_qoq_pct` field is kept as a deprecated alias and
  will be removed in v0.2.

## [0.1.0] — 2026-05-16

Initial scaffold.

### Added
- Synchronous `Client` and asynchronous `AsyncClient` over httpx.
- API-key resolution: constructor arg, then `AUSDATA_API_KEY` env var.
- Typed response models mirroring the ausdata-api `ApiResponse` envelope
  (`Meta`, `Links`, `SourceCitation`, plus per-endpoint payload shapes).
- Endpoint methods for the v1 MVP surface:
  - `health()`
  - `account.api_key()` / `account.rotate_key()`
  - `search_datasets(q, source, limit)`
  - `real_wages(start, end, seasonal_adjustment)`
  - `economic_dashboard(period)`
- Convenience: `ApiResponse.to_dataframe()` (requires `pandas` extra),
  `to_csv(path=None)`, `to_json()`.
- Typed exception hierarchy (`AusdataError`, `AuthenticationError`,
  `PermissionError`, `RateLimitError`, `ValidationError`, `UpstreamError`,
  `AusdataServerError`) — each carries the API's hint string.
- Automatic retry policy: 5xx and 429 retried with exponential backoff,
  `Retry-After` header respected up to 60s, configurable via constructor.
- `py.typed` marker so downstream users get full IDE type completion.
- Test suite (40+ tests) covering successful parsing, auth, errors, retries,
  pandas integration, and the async surface. All mocked — no live calls.
