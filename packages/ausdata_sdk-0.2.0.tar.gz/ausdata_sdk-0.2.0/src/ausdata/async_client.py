"""Asynchronous ``AsyncClient`` for the ausdata REST API.

Mirrors :class:`ausdata.Client` one-to-one; only the I/O is awaitable. The
two classes deliberately share neither a base class nor a transport so the
sync version stays usable without an event loop.

Usage::

    async with AsyncClient(api_key="ak_xxx") as client:
        result = await client.real_wages(start="2019-Q1")
"""

from __future__ import annotations

import asyncio
from typing import Any, Literal, Self

import httpx

from ._internal.http import (
    DEFAULT_BASE_URL,
    DEFAULT_TIMEOUT,
    build_default_headers,
    normalise_base_url,
    raise_for_response,
    resolve_api_key,
)
from ._internal.retry import RetryPolicy
from .exceptions import AusdataError
from .models import (
    AccountResponse,
    ApiResponse,
    DatasetSummary,
    EconomicDashboard,
    HealthResponse,
    RealWageRow,
    WhoamiResponse,
    parse_api_response,
)


class _AsyncAccountNamespace:
    """Async equivalent of :class:`ausdata.client._AccountNamespace`."""

    def __init__(self, client: "AsyncClient") -> None:
        self._client = client

    async def api_key(self) -> AccountResponse:
        """Fetch the current account's API key (creates one if first call)."""
        body = await self._client._request("GET", "/v1/account/api-key")
        return AccountResponse.model_validate(body)

    async def rotate_key(self) -> AccountResponse:
        """Revoke the current key and issue a new one. Plaintext returned once."""
        body = await self._client._request(
            "POST", "/v1/account/api-key", params={"rotate": "true"}
        )
        return AccountResponse.model_validate(body)


class AsyncClient:
    """Asynchronous client for the ausdata REST API.

    Construction args mirror :class:`ausdata.Client`. Use as an async
    context manager so the underlying ``httpx.AsyncClient`` connection
    pool is released::

        async with AsyncClient(api_key="ak_xxx") as client:
            ...
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 3,
        retry_backoff_factor: float = 2.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        resolved_key = resolve_api_key(api_key)
        self._base_url = normalise_base_url(base_url) or DEFAULT_BASE_URL
        self._retry_policy = RetryPolicy(
            max_retries=max_retries,
            backoff_factor=retry_backoff_factor,
        )
        self._httpx = httpx.AsyncClient(
            base_url=self._base_url,
            headers=build_default_headers(resolved_key),
            timeout=timeout,
            transport=transport,
        )
        self.account = _AsyncAccountNamespace(self)

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Release the underlying httpx connection pool."""
        await self._httpx.aclose()

    # ------------------------------------------------------------------
    # Endpoint methods (parameter docs live on the sync Client)
    # ------------------------------------------------------------------

    async def health(self) -> HealthResponse:
        """``GET /v1/health`` — service status; doesn't consume your quota."""
        body = await self._request("GET", "/v1/health")
        return HealthResponse.model_validate(body)

    async def whoami(self) -> WhoamiResponse:
        """``GET /v1/whoami`` — verify credentials and see your tier/usage."""
        body = await self._request("GET", "/v1/whoami")
        return WhoamiResponse.model_validate(body)

    async def search_datasets(
        self,
        q: str,
        *,
        source: str | list[str] | None = None,
        limit: int = 10,
    ) -> ApiResponse[list[DatasetSummary]]:
        """``GET /v1/search-datasets`` — fan-out search across all 9 sources."""
        params: dict[str, Any] = {"q": q, "limit": limit}
        if source is not None:
            params["source"] = (
                source if isinstance(source, str) else ",".join(source)
            )
        body = await self._request("GET", "/v1/search-datasets", params=params)
        return parse_api_response(body, data_list_model=DatasetSummary)

    async def real_wages(
        self,
        *,
        start: str = "2019-Q1",
        end: str | None = None,
        seasonal_adjustment: Literal[
            "original", "trend", "seasonally_adjusted"
        ] = "trend",
    ) -> ApiResponse[list[RealWageRow]]:
        """``GET /v1/real-wages`` — WPI YoY minus CPI YoY quarterly series."""
        params: dict[str, Any] = {
            "start": start,
            "seasonal_adjustment": seasonal_adjustment,
        }
        if end is not None:
            params["end"] = end
        body = await self._request("GET", "/v1/real-wages", params=params)
        return parse_api_response(body, data_list_model=RealWageRow)

    async def economic_dashboard(
        self,
        *,
        period: str = "latest",
    ) -> ApiResponse[EconomicDashboard]:
        """``GET /v1/economic-dashboard`` — five headline macro indicators."""
        body = await self._request(
            "GET", "/v1/economic-dashboard", params={"period": period}
        )
        return parse_api_response(body, data_model=EconomicDashboard)

    async def list_datasets(self, source: str) -> dict[str, Any]:
        """``GET /v1/datasets/{source}`` — see sync client docs."""
        return await self._request("GET", f"/v1/datasets/{source}")

    async def describe(self, source: str, dataset_id: str) -> dict[str, Any]:
        """``GET /v1/describe/{source}/{dataset_id}`` — see sync client docs."""
        return await self._request(
            "GET", f"/v1/describe/{source}/{dataset_id}"
        )

    async def get_data(
        self,
        source: str,
        dataset_id: str,
        *,
        start: str | None = None,
        end: str | None = None,
        limit: int = 100,
        format: Literal["json", "csv"] = "json",
        **filters: Any,
    ) -> ApiResponse[list[dict[str, Any]]]:
        """``GET /v1/data/{source}/{dataset_id}`` — generic data passthrough.

        See :meth:`ausdata.Client.get_data` for parameter docs.
        """
        params: dict[str, Any] = {"limit": limit, "format": format, **filters}
        if start is not None:
            params["start"] = start
        if end is not None:
            params["end"] = end
        body = await self._request("GET", f"/v1/data/{source}/{dataset_id}", params=params)
        return parse_api_response(body)

    # ------------------------------------------------------------------
    # Request execution + retry loop
    # ------------------------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any | None = None,
    ) -> dict[str, Any]:
        attempt = 0
        while True:
            try:
                response = await self._httpx.request(
                    method, path, params=params, json=json
                )
            except Exception as exc:
                if (
                    self._retry_policy.should_retry_exception(exc)
                    and attempt < self._retry_policy.max_retries
                ):
                    attempt += 1
                    await asyncio.sleep(self._retry_policy.backoff_seconds(attempt))
                    continue
                raise AusdataError(
                    f"Transport error contacting ausdata API: {exc}"
                ) from exc

            if response.is_success:
                try:
                    return response.json()
                except ValueError as exc:
                    raise AusdataError(
                        "API returned a non-JSON 2xx response.",
                        status_code=response.status_code,
                    ) from exc

            if (
                self._retry_policy.should_retry_status(response.status_code)
                and attempt < self._retry_policy.max_retries
            ):
                attempt += 1
                if response.status_code == 429:
                    wait = self._retry_policy.retry_after_seconds(response) or (
                        self._retry_policy.backoff_seconds(attempt)
                    )
                else:
                    wait = self._retry_policy.backoff_seconds(attempt)
                await asyncio.sleep(wait)
                continue

            raise_for_response(response)
            return {}  # pragma: no cover
