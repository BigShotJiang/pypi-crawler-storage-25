"""Exception hierarchy for the ausdata SDK.

All errors inherit from :class:`AusdataError` so callers can do a single
``except AusdataError`` if they don't care about specifics. Each specific
class carries the API's error message plus the actionable ``hint`` returned
by the server when present (see ``ErrorDetail`` in ausdata-api).
"""

from __future__ import annotations

from typing import Any


class AusdataError(Exception):
    """Base class for every error raised by the ausdata SDK.

    Attributes:
        message: Human-readable error string.
        status_code: HTTP status code that caused the error (None for
            client-side errors like missing API key).
        hint: Optional "Try X" guidance returned by the API. Surfaced
            prominently when present.
        response_body: Raw JSON body from the API, if parsed successfully.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        hint: str | None = None,
        response_body: dict[str, Any] | None = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.hint = hint
        self.response_body = response_body
        full = message
        if hint:
            full = f"{message} (hint: {hint})"
        super().__init__(full)


class AuthenticationError(AusdataError):
    """401 — API key is missing, malformed, or revoked.

    Check your ``AUSDATA_API_KEY`` env var or the ``api_key`` argument
    passed to ``Client(...)``. Rotate the key in the dashboard if you
    suspect it has been compromised.
    """


class PermissionError(AusdataError):  # noqa: A001 — intentional shadow of builtin
    """403 — your tier doesn't grant access to this endpoint or feature.

    The ``hint`` typically names the tier required (e.g. "Upgrade to
    ANALYST at https://ausdata.io/pricing").
    """


class RateLimitError(AusdataError):
    """429 — monthly call quota exceeded, or per-minute burst limit hit.

    Attributes:
        retry_after: Seconds to wait before retrying, parsed from the
            ``Retry-After`` response header. ``None`` if absent.
    """

    def __init__(
        self,
        message: str,
        *,
        retry_after: float | None = None,
        **kwargs: Any,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(message, **kwargs)


class ValidationError(AusdataError):
    """400 — request rejected by the API.

    Common causes: malformed period strings, unknown dataset IDs,
    invalid enum values. The ``hint`` usually suggests the fix.
    """


class UpstreamError(AusdataError):
    """502/503 — a sister data source (ABS, RBA, etc.) is failing upstream.

    Retries already happened automatically before this was raised. The
    API may serve a stale cached response on subsequent calls (look for
    ``meta.stale=True``).
    """


class AusdataServerError(AusdataError):
    """5xx — generic server-side failure not covered by :class:`UpstreamError`.

    Raised after the SDK's automatic retries are exhausted.
    """
