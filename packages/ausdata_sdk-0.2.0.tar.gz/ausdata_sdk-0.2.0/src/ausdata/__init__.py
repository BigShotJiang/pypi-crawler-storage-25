"""Python SDK for the Australian public data API at https://ausdata.io.

Quick start::

    from ausdata import Client

    client = Client(api_key="ak_xxx")     # or set AUSDATA_API_KEY
    result = client.real_wages(start="2019-Q1", end="2024-Q4")
    df = result.to_dataframe()

Async equivalent::

    import asyncio
    from ausdata import AsyncClient

    async def main():
        async with AsyncClient(api_key="ak_xxx") as client:
            return await client.real_wages(start="2019-Q1")

    asyncio.run(main())
"""

from __future__ import annotations

from ._version import __version__
from .async_client import AsyncClient
from .client import Client
from .exceptions import (
    AusdataError,
    AusdataServerError,
    AuthenticationError,
    PermissionError,
    RateLimitError,
    UpstreamError,
    ValidationError,
)
from .models import (
    AccountResponse,
    ApiResponse,
    DatasetSummary,
    EconomicDashboard,
    HealthResponse,
    Links,
    Meta,
    RealWageRow,
    SearchResponse,
    SourceCitation,
    WhoamiResponse,
)

__all__ = [
    "__version__",
    # clients
    "AsyncClient",
    "Client",
    # exceptions
    "AusdataError",
    "AusdataServerError",
    "AuthenticationError",
    "PermissionError",
    "RateLimitError",
    "UpstreamError",
    "ValidationError",
    # models
    "AccountResponse",
    "ApiResponse",
    "DatasetSummary",
    "EconomicDashboard",
    "HealthResponse",
    "Links",
    "Meta",
    "RealWageRow",
    "SearchResponse",
    "SourceCitation",
    "WhoamiResponse",
]
