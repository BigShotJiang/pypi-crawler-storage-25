"""Retry policy shared by the sync and async clients.

The policy:
- Auto-retry on 5xx with exponential backoff (default 1s, 2s, 4s, max 3 attempts)
- Retry on 429 if a ``Retry-After`` header is present (capped at ``max_retry_after_seconds``)
- Never retry on other 4xx
- Caller-side ``ConnectError`` / ``ReadTimeout`` failures retry like 5xx

Sleeping is delegated to a caller-provided callable so the async client can
``await asyncio.sleep`` while the sync client uses ``time.sleep``. This keeps
the policy decision in one place.
"""

from __future__ import annotations

from dataclasses import dataclass

import httpx


@dataclass(frozen=True)
class RetryPolicy:
    """Configuration for the SDK's automatic retry behaviour.

    Defaults are conservative — 3 attempts (so 2 retries after the first
    failure), 2x exponential backoff starting at 1 second. ``Retry-After``
    headers on 429 responses are always respected up to
    ``max_retry_after_seconds`` (default 60s).
    """

    max_retries: int = 3
    backoff_factor: float = 2.0
    initial_backoff: float = 1.0
    max_retry_after_seconds: float = 60.0

    def should_retry_status(self, status_code: int) -> bool:
        if status_code == 429:
            return True
        return 500 <= status_code < 600

    def should_retry_exception(self, exc: BaseException) -> bool:
        # httpx network-layer failures get the same retry treatment as 5xx.
        return isinstance(
            exc,
            (httpx.ConnectError, httpx.ReadTimeout, httpx.WriteTimeout, httpx.RemoteProtocolError),
        )

    def backoff_seconds(self, attempt: int) -> float:
        """Backoff for the ``attempt``-th retry (1-indexed)."""
        return self.initial_backoff * (self.backoff_factor ** (attempt - 1))

    def retry_after_seconds(self, response: httpx.Response) -> float | None:
        """Parse the ``Retry-After`` header. Returns None if absent or bogus."""
        header = response.headers.get("Retry-After") or response.headers.get(
            "retry-after"
        )
        if not header:
            return None
        try:
            value = float(header)
        except ValueError:
            return None
        return min(value, self.max_retry_after_seconds)
