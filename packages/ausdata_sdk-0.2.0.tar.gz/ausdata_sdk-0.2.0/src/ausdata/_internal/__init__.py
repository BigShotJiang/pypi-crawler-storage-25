"""Internal helpers — not part of the public API.

Symbols inside ``ausdata._internal`` may change between minor versions.
Public callers should depend on the surfaces exposed in ``ausdata.__init__``.
"""
