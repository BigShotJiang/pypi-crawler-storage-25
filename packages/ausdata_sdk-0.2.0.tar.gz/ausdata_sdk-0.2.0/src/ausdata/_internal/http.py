"""Shared HTTP plumbing for the sync and async clients.

Responsibilities kept here:
- API-key resolution (constructor arg → env var → informative error)
- Default headers (Authorization, User-Agent)
- Mapping HTTP status codes to typed :class:`AusdataError` subclasses

The actual request execution + retry loop lives in the sync/async clients
because the two transport styles can't share that wrapper cleanly.
"""

from __future__ import annotations

import os
from typing import Any

import httpx

from .._version import __version__
from ..exceptions import (
    AusdataError,
    AusdataServerError,
    AuthenticationError,
    PermissionError,
    RateLimitError,
    UpstreamError,
    ValidationError,
)

DEFAULT_BASE_URL = "https://api.ausdata.io"
DEFAULT_TIMEOUT = 30.0
API_KEY_ENV_VAR = "AUSDATA_API_KEY"
BASE_URL_ENV_VAR = "AUSDATA_BASE_URL"


def resolve_api_key(api_key: str | None) -> str:
    """Return ``api_key``, falling back to the ``AUSDATA_API_KEY`` env var.

    Raises ``AuthenticationError`` with a directly actionable message when
    neither source is set — failing here is much better than a cryptic 401
    from the API on the first call.
    """
    if api_key:
        return api_key
    env_value = os.environ.get(API_KEY_ENV_VAR)
    if env_value:
        return env_value
    raise AuthenticationError(
        "No API key provided.",
        hint=(
            f"Pass api_key='ak_...' to Client(), or set the {API_KEY_ENV_VAR} "
            "environment variable. Get a free key at https://ausdata.io."
        ),
    )


def build_default_headers(api_key: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {api_key}",
        "User-Agent": f"ausdata-python/{__version__}",
        "Accept": "application/json",
    }


def normalise_base_url(base_url: str | None) -> str:
    """Resolve base URL: explicit arg → ``AUSDATA_BASE_URL`` env → default.

    Trailing slash is stripped so endpoint paths can always start with ``/v1/...``.
    """
    resolved = base_url or os.environ.get(BASE_URL_ENV_VAR) or DEFAULT_BASE_URL
    return resolved.rstrip("/")


def parse_error_body(response: httpx.Response) -> tuple[str, str | None, dict[str, Any] | None]:
    """Best-effort extraction of ``(message, hint, raw_body)`` from a non-2xx body.

    The API's :class:`ErrorDetail` shape is ``{"error", "message", "hint"}``;
    FastAPI's default validation failures use ``{"detail"}``. We accept either.
    """
    try:
        body = response.json()
    except (ValueError, httpx.DecodingError):
        return response.text or response.reason_phrase or "API error", None, None

    if not isinstance(body, dict):
        return str(body), None, None

    hint = body.get("hint")
    if "message" in body:
        return str(body["message"]), hint, body
    if "detail" in body:
        detail = body["detail"]
        if isinstance(detail, str):
            return detail, hint, body
        return str(detail), hint, body
    if "error" in body:
        return str(body["error"]), hint, body
    return response.reason_phrase or "API error", hint, body


def raise_for_response(response: httpx.Response) -> None:
    """Map an HTTP status code to the right :class:`AusdataError` subclass.

    Called by the sync/async clients after exhausting the retry policy.
    """
    if response.is_success:
        return

    status = response.status_code
    message, hint, raw = parse_error_body(response)

    if status == 400:
        raise ValidationError(message, status_code=status, hint=hint, response_body=raw)
    if status == 401:
        raise AuthenticationError(message, status_code=status, hint=hint, response_body=raw)
    if status == 402:
        # Treat 402 ("payment required" / tier-blocked) as a permission error.
        raise PermissionError(message, status_code=status, hint=hint, response_body=raw)
    if status == 403:
        raise PermissionError(message, status_code=status, hint=hint, response_body=raw)
    if status == 404:
        raise ValidationError(message, status_code=status, hint=hint, response_body=raw)
    if status == 429:
        retry_after_header = response.headers.get("Retry-After")
        retry_after: float | None = None
        if retry_after_header:
            try:
                retry_after = float(retry_after_header)
            except ValueError:
                retry_after = None
        raise RateLimitError(
            message,
            status_code=status,
            hint=hint,
            response_body=raw,
            retry_after=retry_after,
        )
    if status in (502, 503, 504):
        raise UpstreamError(message, status_code=status, hint=hint, response_body=raw)
    if 500 <= status < 600:
        raise AusdataServerError(message, status_code=status, hint=hint, response_body=raw)

    raise AusdataError(message, status_code=status, hint=hint, response_body=raw)
