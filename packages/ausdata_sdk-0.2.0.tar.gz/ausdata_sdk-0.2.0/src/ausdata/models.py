"""Pydantic response models mirroring the ausdata-api envelope.

The shapes here track ``API_DESIGN_V1.md`` and ``ausdata-api/src/ausdata_api/
models.py``. Whenever the API ships a new field, add it here as optional
first so older SDK versions don't break on newer servers.
"""

from __future__ import annotations

import csv
import io
import json
from datetime import datetime
from typing import TYPE_CHECKING, Any, Generic, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    import pandas as pd

T = TypeVar("T")

TierName = Literal["free", "analyst", "pro", "enterprise"]


# ---------------------------------------------------------------------------
# Envelope pieces
# ---------------------------------------------------------------------------


class SourceCitation(BaseModel):
    """One CC-BY attribution entry. Every payload carries at least one."""

    model_config = ConfigDict(extra="allow")

    name: str
    url: str
    attribution: str


class Meta(BaseModel):
    """Provenance + audit metadata travelling with every API response."""

    model_config = ConfigDict(extra="allow")

    endpoint: str
    query: dict[str, Any] = Field(default_factory=dict)
    period: dict[str, str | None] = Field(
        default_factory=lambda: {"start": None, "end": None}
    )
    row_count: int = 0
    retrieved_at: datetime
    sources: list[SourceCitation] = Field(default_factory=list)
    stale: bool = False
    stale_reason: str | None = None
    server_version: str | None = None
    tier: TierName | None = None


class Links(BaseModel):
    """Alternative renderings of the same payload."""

    model_config = ConfigDict(extra="allow")

    csv: str | None = None
    chart_template: str | None = None


# ---------------------------------------------------------------------------
# Generic API response wrapper
# ---------------------------------------------------------------------------


class ApiResponse(BaseModel, Generic[T]):
    """Universal envelope returned by every data endpoint.

    Iterate or index into ``.data`` for the payload. Use ``.meta`` for
    provenance. Use ``.to_dataframe()`` / ``.to_csv()`` / ``.to_json()``
    for quick conversion to common shapes.
    """

    model_config = ConfigDict(extra="allow")

    data: T
    meta: Meta
    links: Links = Field(default_factory=Links)

    @property
    def row_count(self) -> int:
        """Shortcut to ``meta.row_count``."""
        return self.meta.row_count

    def to_dataframe(self) -> pd.DataFrame:
        """Convert ``.data`` to a pandas DataFrame.

        Requires ``pandas`` — install via ``pip install ausdata[pandas]``.

        Handles both list-of-dicts payloads (most endpoints) and single-dict
        payloads (``/economic-dashboard``) by wrapping the dict in a 1-row
        frame.
        """
        try:
            import pandas as pd
        except ImportError as exc:  # pragma: no cover — exercised in tests
            raise ImportError(
                "pandas is required for to_dataframe(). "
                "Install via: pip install ausdata[pandas]"
            ) from exc

        payload = self._payload_for_serialisation()
        if isinstance(payload, list):
            return pd.DataFrame(payload)
        if isinstance(payload, dict):
            return pd.DataFrame([payload])
        return pd.DataFrame([{"value": payload}])

    def to_csv(self, path: str | None = None) -> str:
        """Serialise ``.data`` to CSV.

        If ``path`` is provided, the CSV is written there and the same
        string is also returned. List payloads become row-per-record;
        a dict payload becomes a single-row CSV.
        """
        payload = self._payload_for_serialisation()
        buf = io.StringIO()
        rows: list[dict[str, Any]]
        if isinstance(payload, list):
            rows = [r if isinstance(r, dict) else {"value": r} for r in payload]
        elif isinstance(payload, dict):
            rows = [payload]
        else:
            rows = [{"value": payload}]

        if not rows:
            text = ""
        else:
            fieldnames: list[str] = []
            seen: set[str] = set()
            for row in rows:
                for k in row.keys():
                    if k not in seen:
                        seen.add(k)
                        fieldnames.append(k)
            writer = csv.DictWriter(buf, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow({k: row.get(k) for k in fieldnames})
            text = buf.getvalue()

        if path is not None:
            with open(path, "w", encoding="utf-8", newline="") as fh:
                fh.write(text)
        return text

    def to_json(self, *, indent: int | None = 2) -> str:
        """Serialise the full envelope (data + meta + links) to JSON."""
        return self.model_dump_json(indent=indent)

    def _payload_for_serialisation(self) -> Any:
        data = self.data
        if isinstance(data, BaseModel):
            return data.model_dump(mode="json")
        if isinstance(data, list):
            return [
                item.model_dump(mode="json") if isinstance(item, BaseModel) else item
                for item in data
            ]
        return data


# ---------------------------------------------------------------------------
# Endpoint-specific payloads
# ---------------------------------------------------------------------------


class HealthResponse(BaseModel):
    """Returned by ``GET /v1/health`` (not wrapped in ``ApiResponse``)."""

    model_config = ConfigDict(extra="allow")

    status: Literal["ok", "degraded", "down"]
    version: str
    environment: str | None = None
    upstreams: dict[str, str] = Field(default_factory=dict)


class AccountResponse(BaseModel):
    """Returned by ``GET / POST /v1/account/api-key``."""

    model_config = ConfigDict(extra="allow")

    key: str
    tier: TierName
    monthly_usage: int
    monthly_limit: int | None
    created_at: datetime | None = None
    last_used_at: datetime | None = None


class DatasetSummary(BaseModel):
    """One search result from ``/v1/search-datasets``."""

    model_config = ConfigDict(extra="allow")

    dataset_id: str
    source: str
    name: str
    description: str | None = None
    is_curated: bool = False
    relevance: float | None = None
    endpoint: str | None = None


class RealWageRow(BaseModel):
    """One quarter of the ``/v1/real-wages`` series."""

    model_config = ConfigDict(extra="allow")

    period: str
    wpi_annual_change_pct: float | None = None
    cpi_annual_change_pct: float | None = None
    real_wages_gap_pct: float | None = None
    real_wages_direction: Literal["growing", "shrinking", "flat", "unknown"] = "unknown"


class EconomicDashboard(BaseModel):
    """Single-snapshot payload from ``/v1/economic-dashboard``."""

    model_config = ConfigDict(extra="allow")

    as_of: str | None = None
    cash_rate_pct: float | None = None
    cpi_annual_pct: float | None = None
    unemployment_rate_pct: float | None = None
    wage_growth_annual_pct: float | None = None
    consumer_spending_yoy_pct: float | None = None
    # Deprecated alias kept for old-SDK compatibility — API never shipped it.
    # Will be removed in v0.2.
    lending_housing_change_qoq_pct: float | None = None


class WhoamiResponse(BaseModel):
    """Caller introspection — returned by ``GET /v1/whoami``."""

    auth_kind: Literal["api_key", "jwt"]
    tier: TierName
    monthly_usage: int
    monthly_limit: int | None
    key_prefix: str | None = None
    email: str | None = None


# Typed convenience aliases for the common payload shapes.
SearchResponse = ApiResponse[list[DatasetSummary]]
RealWagesResponse = ApiResponse[list[RealWageRow]]
EconomicDashboardResponse = ApiResponse[EconomicDashboard]


# Helper to coerce a raw JSON body into the right ApiResponse shape.
def parse_api_response(
    body: dict[str, Any],
    *,
    data_model: type[BaseModel] | None = None,
    data_list_model: type[BaseModel] | None = None,
) -> ApiResponse[Any]:
    """Coerce ``body`` into ``ApiResponse``, optionally typing ``data``.

    The SDK avoids the full ``GenericModel`` dance at runtime — instead we
    parse meta+links eagerly and then narrow ``data`` only if a caller
    passes ``data_model`` or ``data_list_model``.
    """
    raw_data = body.get("data")
    parsed_data: Any
    if data_list_model is not None and isinstance(raw_data, list):
        parsed_data = [data_list_model.model_validate(r) for r in raw_data]
    elif data_model is not None and isinstance(raw_data, dict):
        parsed_data = data_model.model_validate(raw_data)
    else:
        parsed_data = raw_data

    meta = Meta.model_validate(body.get("meta") or {})
    links = Links.model_validate(body.get("links") or {})
    return ApiResponse(data=parsed_data, meta=meta, links=links)


def parse_json_value(text: str) -> Any:
    """Standalone JSON loader so request modules don't import ``json`` twice."""
    return json.loads(text)
