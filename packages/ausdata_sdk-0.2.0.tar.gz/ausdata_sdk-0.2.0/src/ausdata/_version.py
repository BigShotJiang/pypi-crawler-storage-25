"""Single source of truth for the SDK version string.

Kept in its own module so internal helpers can import it without forcing
the full ``ausdata/__init__.py`` to initialise (which would cause a circular
import: ``__init__`` imports ``Client``, which imports ``_internal.http``,
which used to import back from ``__init__`` for ``__version__``).
"""

from __future__ import annotations

__version__ = "0.2.0"
