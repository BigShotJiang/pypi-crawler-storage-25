# ausdata-sdk — developer notes

The official Python client library for the hosted REST API at
[ausdata.io](https://ausdata.io). Layer 3's public face — thin HTTP wrapper,
not a data engine.

**One-line value prop:** `pip install ausdata-sdk` (imports as `from ausdata import Client`) and call typed methods against
the hosted API; no MCP runtime, no SDMX parsing, no upstream credentials.

## License

**MIT.** This package is intentionally MIT (not FSL like `ausdata-api`)
because the SDK is a trivial HTTP wrapper — the moat lives in the API
backend, not here. Permissive licensing maximises adoption + makes
enterprise legal teams happy.

The upstream FastAPI in `../ausdata-api/` is FSL-1.1-MIT; that's where
competitors would lift code and the licence does the work.

## Layout

```
src/ausdata/
├── __init__.py        Re-exports Client, AsyncClient, models, exceptions
├── client.py          Synchronous Client (httpx.Client)
├── async_client.py    AsyncClient (httpx.AsyncClient)
├── models.py          Pydantic ApiResponse envelope + per-endpoint payloads
├── exceptions.py      AusdataError + 6 typed subclasses
├── py.typed           PEP 561 marker — full IDE type completion downstream
└── _internal/
    ├── http.py        API-key resolution, default headers, error mapping
    └── retry.py       RetryPolicy (5xx + 429 with Retry-After)

tests/
├── conftest.py        Canned API response fixtures (all mocked via pytest-httpx)
├── test_client.py     Sync client construction + headers + base_url
├── test_async_client.py
├── test_endpoints.py  Success-path test per public method
├── test_exceptions.py 4xx/5xx → typed exception mapping
├── test_retry.py      Backoff math + end-to-end retry behaviour
└── test_to_dataframe.py  pandas/CSV/JSON conversions
```

## Cross-links

- **API spec** (private): `../API_DESIGN_V1.md` — every endpoint here mirrors
  what the API exposes. If you add an endpoint method, update both files.
- **API server** (private): `../ausdata-api/` — when its response shape
  changes, mirror the change in `models.py` here. Add new optional fields
  rather than breaking changes whenever possible so old SDK versions stay
  compatible with new servers.
- **Portfolio strategy** (private): `../STRATEGY.md` — the SDK is intentionally
  separate from the 9 sister MCP packages on PyPI; don't blur the line.

## Development

```bash
cd ausdata-sdk
uv sync --extra dev
uv run pytest -q
uv run ruff check src tests
uv build
```

All tests use `pytest-httpx` — there are zero live API calls in the suite.
This is deliberate: SDK tests should run in CI without secrets and in <2s.

## Test patterns

- One success-path test per endpoint method (see `test_endpoints.py`)
- One typed-exception test per HTTP status the API uses (`test_exceptions.py`)
- Retry behaviour is tested both unit-style (`RetryPolicy` math) and
  integration-style (full `Client.health()` calls with mocked 500s)
- pandas import failure is tested by patching `builtins.__import__` so the
  test runs even if pandas is installed in the dev environment

## Anti-patterns — don't do these

- **Don't auto-publish to PyPI.** The user runs `uv publish` when ready.
  CI here only lints + tests; no Trusted Publishing workflow yet.
- **Don't push to a public GitHub remote** until the user explicitly creates
  it. Local commits only for now.
- **Don't add new runtime dependencies beyond `httpx` + `pydantic`** (plus
  `pandas` as an optional extra). The SDK's value is being lightweight.
- **Don't import from any sister MCP package** (`abs_mcp`, `rba_mcp`, etc.).
  The SDK talks to the hosted API only — that's the whole point of the
  layered architecture.
- **Don't build a CLI here.** A future `ausdata-cli` package can wrap this
  SDK; keep them separate.
- **Don't reimplement data parsing.** All shaping happens in `ausdata-api`'s
  composers + the sister MCPs they call.
- **Don't echo tokens or API keys** in logs, errors, or test output.

## Adding a new endpoint method

1. Confirm the API supports it (`../ausdata-api/src/ausdata_api/routers/`).
2. Add the payload shape to `src/ausdata/models.py` if it isn't already
   there. Prefer optional fields so older SDK versions don't break.
3. Add a method to both `Client` and `AsyncClient` (parameters mirror
   the API query string, kwarg-only where it improves readability).
4. Add at least one success-path test (`test_endpoints.py`) and any
   relevant error-path test (`test_exceptions.py`).
5. Update `README.md` (endpoint table) + `CHANGELOG.md` (new entry).

## Releasing (when the user is ready)

1. Bump `version` in `pyproject.toml` + `src/ausdata/__init__.py`.
2. Update `CHANGELOG.md`.
3. `uv run pytest -q` 10x — zero flakes.
4. `uv run ruff check src tests` — clean.
5. `uv build` — wheel + sdist build cleanly.
6. `uv publish` — **user runs this**, not Claude.

PyPI new-project rate limit: 5 per account per 24h. Plan first publish
accordingly; the user handles this.
