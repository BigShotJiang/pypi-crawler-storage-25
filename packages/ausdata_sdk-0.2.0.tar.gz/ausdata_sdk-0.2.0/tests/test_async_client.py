"""Async-client smoke tests — verify the async surface mirrors the sync one."""

from __future__ import annotations

import asyncio

import pytest
from pytest_httpx import HTTPXMock

from ausdata import AsyncClient
from ausdata.exceptions import AuthenticationError, RateLimitError
from ausdata.models import EconomicDashboard, RealWageRow


@pytest.fixture(autouse=True)
def _no_async_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    async def _noop(*_a, **_kw) -> None:
        return None

    monkeypatch.setattr(asyncio, "sleep", _noop)


async def test_async_client_health(httpx_mock: HTTPXMock, health_body: dict) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health", json=health_body, status_code=200
    )
    async with AsyncClient(api_key="ak_x") as client:
        result = await client.health()
    assert result.status == "ok"


async def test_async_client_search(httpx_mock: HTTPXMock, search_body: dict) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/search-datasets?q=unemployment&limit=10",
        json=search_body,
        status_code=200,
    )
    async with AsyncClient(api_key="ak_x") as client:
        result = await client.search_datasets(q="unemployment")
    assert len(result.data) == 2
    assert result.data[0].dataset_id == "abs.LF"


async def test_async_client_real_wages(
    httpx_mock: HTTPXMock, real_wages_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/real-wages?start=2019-Q1&seasonal_adjustment=trend",
        json=real_wages_body,
        status_code=200,
    )
    async with AsyncClient(api_key="ak_x") as client:
        result = await client.real_wages()
    assert isinstance(result.data[0], RealWageRow)


async def test_async_client_economic_dashboard(
    httpx_mock: HTTPXMock, dashboard_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/economic-dashboard?period=latest",
        json=dashboard_body,
        status_code=200,
    )
    async with AsyncClient(api_key="ak_x") as client:
        result = await client.economic_dashboard()
    assert isinstance(result.data, EconomicDashboard)
    assert result.data.cash_rate_pct == 4.35


async def test_async_client_account_api_key(
    httpx_mock: HTTPXMock, account_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/account/api-key",
        json=account_body,
        status_code=200,
        method="GET",
    )
    async with AsyncClient(api_key="ak_x") as client:
        result = await client.account.api_key()
    assert result.tier == "analyst"


async def test_async_client_raises_without_key() -> None:
    with pytest.raises(AuthenticationError):
        AsyncClient(api_key=None)


async def test_async_client_retries_5xx(
    httpx_mock: HTTPXMock, health_body: dict
) -> None:
    for _ in range(2):
        httpx_mock.add_response(
            url="https://api.ausdata.io/v1/health",
            status_code=500,
            json={"message": "boom"},
        )
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health", status_code=200, json=health_body
    )
    async with AsyncClient(api_key="ak_x", max_retries=3) as client:
        result = await client.health()
    assert result.status == "ok"
    assert len(httpx_mock.get_requests()) == 3


async def test_async_client_rate_limit_error(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health",
        status_code=429,
        headers={"Retry-After": "5"},
        json={"message": "Slow down"},
    )
    async with AsyncClient(api_key="ak_x", max_retries=0) as client:
        with pytest.raises(RateLimitError) as exc_info:
            await client.health()
    assert exc_info.value.retry_after == 5.0
