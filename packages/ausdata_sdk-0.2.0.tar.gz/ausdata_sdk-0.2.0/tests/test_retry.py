"""Retry policy tests — both via the RetryPolicy itself and through the Client."""

from __future__ import annotations

import time

import httpx
import pytest
from pytest_httpx import HTTPXMock

from ausdata import Client
from ausdata._internal.retry import RetryPolicy
from ausdata.exceptions import AusdataServerError, RateLimitError


@pytest.fixture(autouse=True)
def _no_real_sleeps(monkeypatch: pytest.MonkeyPatch) -> None:
    """Patch time.sleep so the retry tests run instantly."""
    monkeypatch.setattr(time, "sleep", lambda *_a, **_kw: None)


def test_retry_policy_backoff_seconds_doubles() -> None:
    policy = RetryPolicy(initial_backoff=1.0, backoff_factor=2.0)
    assert policy.backoff_seconds(1) == 1.0
    assert policy.backoff_seconds(2) == 2.0
    assert policy.backoff_seconds(3) == 4.0


def test_retry_policy_should_retry_5xx_only() -> None:
    policy = RetryPolicy()
    assert policy.should_retry_status(500) is True
    assert policy.should_retry_status(502) is True
    assert policy.should_retry_status(429) is True
    assert policy.should_retry_status(400) is False
    assert policy.should_retry_status(404) is False
    assert policy.should_retry_status(200) is False


def test_retry_policy_retry_after_capped() -> None:
    policy = RetryPolicy(max_retry_after_seconds=10.0)
    response = httpx.Response(429, headers={"Retry-After": "99"})
    assert policy.retry_after_seconds(response) == 10.0


def test_retry_policy_retry_after_missing() -> None:
    policy = RetryPolicy()
    response = httpx.Response(429)
    assert policy.retry_after_seconds(response) is None


def test_client_retries_500_then_succeeds(
    httpx_mock: HTTPXMock, health_body: dict
) -> None:
    # First three responses fail with 500, fourth succeeds — but max_retries=3
    # means we get one initial attempt + three retries = 4 calls total.
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health", status_code=500, json={"error": "boom"}
    )
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health", status_code=500, json={"error": "boom"}
    )
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health", status_code=500, json={"error": "boom"}
    )
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health", status_code=200, json=health_body
    )

    client = Client(api_key="ak_x", max_retries=3)
    result = client.health()
    assert result.status == "ok"
    assert len(httpx_mock.get_requests()) == 4


def test_client_gives_up_after_max_retries(httpx_mock: HTTPXMock) -> None:
    # All attempts (1 + 3 retries = 4 total) fail with 500.
    for _ in range(4):
        httpx_mock.add_response(
            url="https://api.ausdata.io/v1/health",
            status_code=500,
            json={"error": "boom", "message": "Persistent 500"},
        )
    client = Client(api_key="ak_x", max_retries=3)
    with pytest.raises(AusdataServerError) as exc_info:
        client.health()
    assert exc_info.value.status_code == 500
    assert len(httpx_mock.get_requests()) == 4


def test_client_no_retry_on_4xx(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health",
        status_code=400,
        json={"message": "Bad request", "hint": "fix it"},
    )
    client = Client(api_key="ak_x", max_retries=3)
    with pytest.raises(Exception):
        client.health()
    # Only one attempt was made — no retries on 4xx.
    assert len(httpx_mock.get_requests()) == 1


def test_client_retries_429_with_retry_after(
    httpx_mock: HTTPXMock, health_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health",
        status_code=429,
        headers={"Retry-After": "1"},
        json={"message": "Slow down"},
    )
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health", status_code=200, json=health_body
    )

    client = Client(api_key="ak_x", max_retries=3)
    result = client.health()
    assert result.status == "ok"
    assert len(httpx_mock.get_requests()) == 2


def test_client_gives_up_on_persistent_429(httpx_mock: HTTPXMock) -> None:
    for _ in range(4):
        httpx_mock.add_response(
            url="https://api.ausdata.io/v1/health",
            status_code=429,
            headers={"Retry-After": "1"},
            json={"message": "Quota exhausted", "hint": "Upgrade."},
        )
    client = Client(api_key="ak_x", max_retries=3)
    with pytest.raises(RateLimitError) as exc_info:
        client.health()
    assert exc_info.value.retry_after == 1.0


def test_zero_retries_means_no_retry(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health",
        status_code=503,
        json={"message": "Down."},
    )
    client = Client(api_key="ak_x", max_retries=0)
    with pytest.raises(Exception):
        client.health()
    assert len(httpx_mock.get_requests()) == 1
