"""Verify HTTP errors are mapped to the right :class:`AusdataError` subclass."""

from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

from ausdata import Client
from ausdata.exceptions import (
    AusdataServerError,
    AuthenticationError,
    PermissionError,
    RateLimitError,
    UpstreamError,
    ValidationError,
)


def test_400_raises_validation_error_with_hint(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/real-wages?start=bad&seasonal_adjustment=trend",
        status_code=400,
        json={
            "error": "bad_request",
            "message": "Bad start 'bad'. Expected 'YYYY' or 'YYYY-Q[1-4]'.",
            "hint": "Did you mean 'bad-Q1'?",
        },
    )
    client = Client(api_key="ak_x")
    with pytest.raises(ValidationError) as exc_info:
        client.real_wages(start="bad")
    assert exc_info.value.status_code == 400
    assert exc_info.value.hint == "Did you mean 'bad-Q1'?"
    assert "Bad start" in exc_info.value.message


def test_401_raises_authentication_error(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health",
        status_code=401,
        json={
            "error": "unauthorized",
            "message": "Invalid API key.",
            "hint": "Rotate at https://ausdata.io/dashboard.",
        },
    )
    client = Client(api_key="ak_bad")
    with pytest.raises(AuthenticationError) as exc_info:
        client.health()
    assert exc_info.value.status_code == 401
    assert "Rotate" in (exc_info.value.hint or "")


def test_403_raises_permission_error_with_tier_hint(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/economic-dashboard?period=latest",
        status_code=403,
        json={
            "error": "tier_blocked",
            "message": "This endpoint requires ANALYST.",
            "hint": "Upgrade at https://ausdata.io/pricing.",
        },
    )
    client = Client(api_key="ak_x")
    with pytest.raises(PermissionError) as exc_info:
        client.economic_dashboard()
    assert "ANALYST" in exc_info.value.message
    assert "ausdata.io/pricing" in (exc_info.value.hint or "")


def test_402_treated_as_permission_error(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/real-wages?start=1990-Q1&seasonal_adjustment=trend",
        status_code=402,
        json={
            "error": "history_cap",
            "message": "Tier 'free' is capped at 1y of history.",
            "hint": "Upgrade at https://ausdata.io/pricing.",
        },
    )
    client = Client(api_key="ak_x")
    with pytest.raises(PermissionError) as exc_info:
        client.real_wages(start="1990-Q1")
    assert exc_info.value.status_code == 402


def test_429_raises_rate_limit_error_with_retry_after(httpx_mock: HTTPXMock) -> None:
    # With retries disabled the 429 surfaces immediately so the test
    # can inspect the typed exception.
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health",
        status_code=429,
        headers={"Retry-After": "30"},
        json={
            "error": "rate_limited",
            "message": "Monthly quota exhausted.",
            "hint": "Upgrade or wait until 2026-06-01.",
        },
    )
    client = Client(api_key="ak_x", max_retries=0)
    with pytest.raises(RateLimitError) as exc_info:
        client.health()
    assert exc_info.value.status_code == 429
    assert exc_info.value.retry_after == 30.0


def test_502_raises_upstream_error(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/economic-dashboard?period=latest",
        status_code=502,
        json={
            "error": "upstream_unavailable",
            "message": "ABS is currently failing.",
            "hint": "Try again in 5 minutes; cached data may be served.",
        },
    )
    client = Client(api_key="ak_x", max_retries=0)
    with pytest.raises(UpstreamError) as exc_info:
        client.economic_dashboard()
    assert exc_info.value.status_code == 502


def test_500_falls_back_to_server_error(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health",
        status_code=500,
        json={"error": "internal", "message": "Boom."},
    )
    client = Client(api_key="ak_x", max_retries=0)
    with pytest.raises(AusdataServerError) as exc_info:
        client.health()
    assert exc_info.value.status_code == 500
    assert "Boom" in exc_info.value.message


def test_error_with_fastapi_detail_string(httpx_mock: HTTPXMock) -> None:
    """FastAPI's default HTTPException uses {'detail': '...'} — accept it."""
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health",
        status_code=400,
        json={"detail": "Bad period format. Did you mean 2024-Q1?"},
    )
    client = Client(api_key="ak_x")
    with pytest.raises(ValidationError) as exc_info:
        client.health()
    assert "Did you mean" in exc_info.value.message


def test_error_with_non_json_body(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health",
        status_code=500,
        content=b"<html>bad gateway</html>",
        headers={"Content-Type": "text/html"},
    )
    client = Client(api_key="ak_x", max_retries=0)
    with pytest.raises(AusdataServerError) as exc_info:
        client.health()
    assert exc_info.value.status_code == 500
