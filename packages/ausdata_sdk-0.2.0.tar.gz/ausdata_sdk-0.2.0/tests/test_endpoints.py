"""One success-path test per public endpoint method.

These verify parameters are forwarded correctly + response parsing returns
the expected typed objects. Error-path coverage lives in test_exceptions.py.
"""

from __future__ import annotations

from pytest_httpx import HTTPXMock

from ausdata import Client
from ausdata.models import DatasetSummary, EconomicDashboard, RealWageRow


def test_health_returns_health_response(
    httpx_mock: HTTPXMock, health_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health", json=health_body, status_code=200
    )
    client = Client(api_key="ak_x")
    result = client.health()

    assert result.status == "ok"
    assert result.version == "0.1.0"
    assert result.upstreams["abs"] == "ok"


def test_account_api_key(httpx_mock: HTTPXMock, account_body: dict) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/account/api-key",
        json=account_body,
        status_code=200,
        method="GET",
    )
    client = Client(api_key="ak_x")
    result = client.account.api_key()
    assert result.key == "ak_live_abcd1234"
    assert result.tier == "analyst"
    assert result.monthly_usage == 1247


def test_account_rotate_key(httpx_mock: HTTPXMock, account_body: dict) -> None:
    rotated = {**account_body, "monthly_usage": 0, "key": "ak_live_rotated_999"}
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/account/api-key?rotate=true",
        json=rotated,
        status_code=200,
        method="POST",
    )
    client = Client(api_key="ak_x")
    result = client.account.rotate_key()
    assert result.key == "ak_live_rotated_999"
    assert result.monthly_usage == 0


def test_search_datasets_parses_envelope(
    httpx_mock: HTTPXMock, search_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/search-datasets?q=unemployment+nsw&limit=10",
        json=search_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    result = client.search_datasets(q="unemployment nsw", limit=10)

    assert isinstance(result.data, list)
    assert len(result.data) == 2
    assert isinstance(result.data[0], DatasetSummary)
    assert result.data[0].dataset_id == "abs.LF"
    assert result.data[0].is_curated is True
    assert result.row_count == 2
    assert result.meta.sources[0].name == "ABS Wage Price Index"


def test_search_datasets_source_list_joined(
    httpx_mock: HTTPXMock, search_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/search-datasets?q=banking&limit=10&source=abs%2Crba",
        json=search_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    client.search_datasets(q="banking", source=["abs", "rba"])

    request = httpx_mock.get_request()
    assert request is not None
    assert "source=abs%2Crba" in str(request.url) or "source=abs,rba" in str(request.url)


def test_real_wages_default_params(
    httpx_mock: HTTPXMock, real_wages_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/real-wages?start=2019-Q1&seasonal_adjustment=trend",
        json=real_wages_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    result = client.real_wages()

    assert len(result.data) == 2
    assert isinstance(result.data[0], RealWageRow)
    assert result.data[0].period == "2024-Q4"
    assert result.data[0].real_wages_gap_pct == 0.8


def test_real_wages_custom_params(
    httpx_mock: HTTPXMock, real_wages_body: dict
) -> None:
    httpx_mock.add_response(
        url=(
            "https://api.ausdata.io/v1/real-wages"
            "?start=2020-Q2&seasonal_adjustment=seasonally_adjusted&end=2024-Q4"
        ),
        json=real_wages_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    client.real_wages(
        start="2020-Q2",
        end="2024-Q4",
        seasonal_adjustment="seasonally_adjusted",
    )

    request = httpx_mock.get_request()
    assert request is not None
    assert "start=2020-Q2" in str(request.url)
    assert "end=2024-Q4" in str(request.url)
    assert "seasonal_adjustment=seasonally_adjusted" in str(request.url)


def test_economic_dashboard(
    httpx_mock: HTTPXMock, dashboard_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/economic-dashboard?period=latest",
        json=dashboard_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    result = client.economic_dashboard()

    assert isinstance(result.data, EconomicDashboard)
    assert result.data.cash_rate_pct == 4.35
    assert result.data.unemployment_rate_pct == 4.0
    assert result.data.as_of == "2024-Q4"


def test_economic_dashboard_custom_period(
    httpx_mock: HTTPXMock, dashboard_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/economic-dashboard?period=2024-Q3",
        json=dashboard_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    client.economic_dashboard(period="2024-Q3")

    request = httpx_mock.get_request()
    assert request is not None
    assert "period=2024-Q3" in str(request.url)


def test_get_data_passthrough(httpx_mock: HTTPXMock) -> None:
    body = {
        "data": [
            {"period": "2026-Q1", "value": 4.6, "unit": "Percent"},
            {"period": "2025-Q4", "value": 3.8, "unit": "Percent"},
        ],
        "meta": {
            "endpoint": "/v1/data/abs/CPI",
            "row_count": 2,
            "retrieved_at": "2026-05-17T00:00:00Z",
            "server_version": "0.1.0",
            "sources": [],
        },
        "links": {"csv": None, "chart_template": None},
    }
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/data/abs/CPI?limit=2&format=json&measure=change_year&region=australia",
        json=body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    result = client.get_data(
        "abs", "CPI", limit=2, measure="change_year", region="australia"
    )
    assert result.meta.row_count == 2
    assert result.data[0]["value"] == 4.6


def test_get_data_with_period_window(httpx_mock: HTTPXMock) -> None:
    body = {
        "data": [],
        "meta": {
            "endpoint": "/v1/data/rba/F1.1",
            "row_count": 0,
            "retrieved_at": "2026-05-17T00:00:00Z",
            "server_version": "0.1.0",
            "sources": [],
        },
        "links": {"csv": None, "chart_template": None},
    }
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/data/rba/F1.1?limit=100&format=json&series=cash_rate_target&start=2024&end=2025",
        json=body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    client.get_data(
        "rba", "F1.1", start="2024", end="2025", series="cash_rate_target"
    )
    req = httpx_mock.get_request()
    assert req is not None
    assert "start=2024" in str(req.url)
    assert "end=2025" in str(req.url)


def test_whoami_returns_caller_info(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/whoami",
        json={
            "auth_kind": "api_key",
            "tier": "free",
            "monthly_usage": 5,
            "monthly_limit": 100,
            "key_prefix": "abcd1234",
            "email": None,
        },
        status_code=200,
    )
    from ausdata import Client
    client = Client(api_key="ak_x")
    r = client.whoami()
    assert r.auth_kind == "api_key"
    assert r.tier == "free"
    assert r.monthly_limit == 100
    assert r.key_prefix == "abcd1234"


def test_describe_returns_schema(httpx_mock: HTTPXMock) -> None:
    body = {
        "data": {
            "id": "LF",
            "name": "Labour Force",
            "dimensions": [
                {"name": "region", "values": [{"key": "australia"}, {"key": "nsw"}]},
            ],
        },
        "meta": {"endpoint": "/v1/describe/abs/LF", "source": "abs", "dataset_id": "LF"},
    }
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/describe/abs/LF",
        json=body,
        status_code=200,
    )
    from ausdata import Client
    client = Client(api_key="ak_x")
    r = client.describe("abs", "LF")
    assert r["data"]["id"] == "LF"
    assert r["data"]["dimensions"][0]["name"] == "region"


def test_describe_404_raises_validation_error(httpx_mock: HTTPXMock) -> None:
    """Dataset-not-found returns 404 — should map to ValidationError per the SDK's status table."""
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/describe/abs/BOGUS",
        json={"detail": "Dataset 'BOGUS' is not a curated dataset."},
        status_code=404,
    )
    from ausdata import Client, ValidationError
    client = Client(api_key="ak_x")
    try:
        client.describe("abs", "BOGUS")
        assert False, "expected ValidationError"
    except ValidationError as e:
        assert "BOGUS" in str(e)


def test_list_datasets_routes_correctly(httpx_mock: HTTPXMock) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/datasets/abs",
        json={
            "data": [{"id": "LF", "name": "Labour Force"}, {"id": "CPI", "name": "Consumer Price Index"}],
            "meta": {"endpoint": "/v1/datasets/abs", "source": "abs", "row_count": 2},
        },
        status_code=200,
    )
    from ausdata import Client
    client = Client(api_key="ak_x")
    r = client.list_datasets("abs")
    assert r["meta"]["row_count"] == 2
    assert {d["id"] for d in r["data"]} == {"LF", "CPI"}
