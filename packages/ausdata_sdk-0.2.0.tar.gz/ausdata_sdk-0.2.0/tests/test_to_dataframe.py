"""pandas conversion + to_csv / to_json convenience tests."""

from __future__ import annotations

import importlib
import json
from pathlib import Path

import pytest
from pytest_httpx import HTTPXMock

from ausdata import Client


def test_to_dataframe_list_payload(
    httpx_mock: HTTPXMock, real_wages_body: dict
) -> None:
    pd = pytest.importorskip("pandas")
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/real-wages?start=2019-Q1&seasonal_adjustment=trend",
        json=real_wages_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    result = client.real_wages()
    df = result.to_dataframe()
    assert isinstance(df, pd.DataFrame)
    assert list(df.columns)[:2] == ["period", "wpi_annual_change_pct"]
    assert len(df) == 2
    assert df["real_wages_gap_pct"].iloc[0] == 0.8


def test_to_dataframe_dict_payload(
    httpx_mock: HTTPXMock, dashboard_body: dict
) -> None:
    pd = pytest.importorskip("pandas")
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/economic-dashboard?period=latest",
        json=dashboard_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    result = client.economic_dashboard()
    df = result.to_dataframe()
    assert len(df) == 1
    assert df["cash_rate_pct"].iloc[0] == 4.35


def test_to_dataframe_without_pandas(
    httpx_mock: HTTPXMock,
    real_wages_body: dict,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If pandas isn't installed, the SDK raises with an install hint."""
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/real-wages?start=2019-Q1&seasonal_adjustment=trend",
        json=real_wages_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    result = client.real_wages()

    real_import_module = importlib.import_module

    def fake_import_module(name: str, *args, **kwargs):
        if name == "pandas":
            raise ImportError("No module named 'pandas'")
        return real_import_module(name, *args, **kwargs)

    monkeypatch.setattr(importlib, "import_module", fake_import_module)

    # Simulate pandas being unimportable.
    import builtins

    real_import = builtins.__import__

    def fake_builtin_import(name, *args, **kwargs):
        if name == "pandas":
            raise ImportError("No module named 'pandas'")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_builtin_import)

    with pytest.raises(ImportError) as exc_info:
        result.to_dataframe()
    assert "pip install ausdata[pandas]" in str(exc_info.value)


def test_to_csv_list_payload(
    httpx_mock: HTTPXMock, real_wages_body: dict, tmp_path: Path
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/real-wages?start=2019-Q1&seasonal_adjustment=trend",
        json=real_wages_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    result = client.real_wages()
    text = result.to_csv()
    assert "period,wpi_annual_change_pct" in text
    assert "2024-Q4" in text
    assert "0.8" in text

    out = tmp_path / "wages.csv"
    result.to_csv(str(out))
    assert out.exists()
    assert "2024-Q4" in out.read_text()


def test_to_csv_dict_payload(
    httpx_mock: HTTPXMock, dashboard_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/economic-dashboard?period=latest",
        json=dashboard_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    result = client.economic_dashboard()
    text = result.to_csv()
    lines = text.strip().split("\n")
    # Header + 1 row.
    assert len(lines) == 2
    assert "cash_rate_pct" in lines[0]


def test_to_json_round_trip(
    httpx_mock: HTTPXMock, real_wages_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/real-wages?start=2019-Q1&seasonal_adjustment=trend",
        json=real_wages_body,
        status_code=200,
    )
    client = Client(api_key="ak_x")
    result = client.real_wages()
    text = result.to_json()
    parsed = json.loads(text)
    assert "data" in parsed
    assert "meta" in parsed
    assert parsed["data"][0]["period"] == "2024-Q4"
