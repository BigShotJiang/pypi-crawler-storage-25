"""Shared fixtures + canned API responses for the SDK test suite.

All tests use ``pytest-httpx`` to mock the API — there are no live calls
anywhere in this suite. The fixtures here construct realistic envelopes
matching ``ausdata-api``'s ``ApiResponse`` shape so we exercise the same
parsing code paths in tests as in production.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from datetime import UTC, datetime
from typing import Any

import pytest

# Make sure the SDK doesn't accidentally pick up an env var from the host
# while tests are running. Each test that wants a key sets it explicitly.
@pytest.fixture(autouse=True)
def _isolate_env(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    monkeypatch.delenv("AUSDATA_API_KEY", raising=False)
    yield


@pytest.fixture
def api_key(monkeypatch: pytest.MonkeyPatch) -> str:
    key = "ak_test_1234567890"
    return key


@pytest.fixture
def base_url() -> str:
    return "https://api.ausdata.io"


@pytest.fixture
def health_body() -> dict[str, Any]:
    return {
        "status": "ok",
        "version": "0.1.0",
        "environment": "production",
        "upstreams": {
            "abs": "ok",
            "aemo": "unknown",
            "aihw": "unknown",
            "apra": "ok",
            "asic": "unknown",
            "ato": "unknown",
            "au_weather": "unknown",
            "rba": "ok",
            "wgea": "unknown",
        },
    }


@pytest.fixture
def account_body() -> dict[str, Any]:
    return {
        "key": "ak_live_abcd1234",
        "tier": "analyst",
        "monthly_usage": 1247,
        "monthly_limit": 10000,
        "created_at": "2026-01-15T08:30:00Z",
        "last_used_at": "2026-05-15T11:21:00Z",
    }


def _meta(endpoint: str, row_count: int, **extras: Any) -> dict[str, Any]:
    return {
        "endpoint": endpoint,
        "query": extras.pop("query", {}),
        "period": extras.pop("period", {"start": None, "end": None}),
        "row_count": row_count,
        "retrieved_at": datetime.now(UTC).isoformat(),
        "sources": [
            {
                "name": "ABS Wage Price Index",
                "url": "https://www.abs.gov.au/statistics/economy/wage-price-index",
                "attribution": "Based on Australian Bureau of Statistics data, CC-BY 4.0",
            }
        ],
        "stale": False,
        "stale_reason": None,
        "server_version": "0.1.0",
        "tier": "analyst",
        **extras,
    }


@pytest.fixture
def search_body() -> dict[str, Any]:
    return {
        "data": [
            {
                "dataset_id": "abs.LF",
                "source": "ABS",
                "name": "Labour Force, Australia",
                "description": "Monthly labour force statistics.",
                "is_curated": True,
                "relevance": 0.95,
                "endpoint": "/v1/dataset/abs.LF",
            },
            {
                "dataset_id": "abs.LEND_HOUSING",
                "source": "ABS",
                "name": "Lending to Housing",
                "description": "Housing lending commitments.",
                "is_curated": True,
                "relevance": 0.72,
                "endpoint": None,
            },
        ],
        "meta": _meta(
            "/v1/search-datasets",
            row_count=2,
            query={"q": "unemployment nsw", "limit": 10},
        ),
        "links": {"csv": None, "chart_template": None},
    }


@pytest.fixture
def real_wages_body() -> dict[str, Any]:
    return {
        "data": [
            {
                "period": "2024-Q4",
                "wpi_annual_change_pct": 3.2,
                "cpi_annual_change_pct": 2.4,
                "real_wages_gap_pct": 0.8,
                "real_wages_direction": "growing",
            },
            {
                "period": "2024-Q3",
                "wpi_annual_change_pct": 3.5,
                "cpi_annual_change_pct": 2.8,
                "real_wages_gap_pct": 0.7,
                "real_wages_direction": "growing",
            },
        ],
        "meta": _meta(
            "/v1/real-wages",
            row_count=2,
            query={"start": "2024-Q1", "end": "2024-Q4"},
            period={"start": "2024-Q1", "end": "2024-Q4"},
        ),
        "links": {"csv": None, "chart_template": None},
    }


@pytest.fixture
def dashboard_body() -> dict[str, Any]:
    return {
        "data": {
            "as_of": "2024-Q4",
            "cash_rate_pct": 4.35,
            "cpi_annual_pct": 2.4,
            "unemployment_rate_pct": 4.0,
            "wage_growth_annual_pct": 3.2,
            "consumer_spending_yoy_pct": 1.8,
        },
        "meta": _meta("/v1/economic-dashboard", row_count=1),
        "links": {"csv": None, "chart_template": None},
    }
