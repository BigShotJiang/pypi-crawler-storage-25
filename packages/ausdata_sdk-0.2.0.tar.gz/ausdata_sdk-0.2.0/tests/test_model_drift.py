"""Drift tests — fail if SDK models go out of sync with the live API shape.

Pattern:
  Each test gets a known-good response payload (mirroring what the live API
  actually returns) and asserts that:

  1. The corresponding SDK model accepts every field in the payload as a
     declared attribute (no fields disappear into `__pydantic_extra__`).
  2. The SDK model doesn't have surprise non-deprecated fields that don't
     come back from the API.

  When the API ships a new field, update the canned payload here AND add the
  field to the SDK model. Drift is caught at test time, not by customer reports.

The canned payloads below were captured against ausdata-api.fly.dev on
2026-05-17. Refresh them whenever the API ships new fields.
"""

from __future__ import annotations

from ausdata.models import (
    AccountResponse,
    DatasetSummary,
    EconomicDashboard,
    HealthResponse,
    Links,
    Meta,
    RealWageRow,
    SourceCitation,
)

# Fields the SDK keeps for backwards compatibility but that the live API
# does NOT emit. These are explicitly marked "deprecated" in the model
# and are allowed to be SDK-only.
ALLOWED_DEPRECATED_FIELDS = {
    "EconomicDashboard": {"lending_housing_change_qoq_pct"},
}


def _assert_no_drift(model_cls, payload: dict) -> None:
    """Validate that ``payload`` covers every non-deprecated SDK field and
    every field in ``payload`` is a declared model attribute (not extras)."""
    model_name = model_cls.__name__
    deprecated = ALLOWED_DEPRECATED_FIELDS.get(model_name, set())

    sdk_fields = set(model_cls.model_fields.keys())
    live_fields = set(payload.keys())

    # SDK-only fields that aren't marked deprecated → drift
    sdk_only_missing_from_live = (sdk_fields - live_fields) - deprecated
    assert not sdk_only_missing_from_live, (
        f"{model_name}: SDK declares {sorted(sdk_only_missing_from_live)} "
        f"but they aren't in the canned API payload. Either remove them, "
        f"add them to ALLOWED_DEPRECATED_FIELDS, or update the API."
    )

    # Live-only fields → API ships data the SDK can't typed-access
    live_only = live_fields - sdk_fields
    assert not live_only, (
        f"{model_name}: API payload has {sorted(live_only)} but the SDK "
        f"model doesn't declare them. They will land in __pydantic_extra__ "
        f"and customers can't typed-access them. Add to "
        f"src/ausdata/models.py."
    )

    # Round-trip: validate, dump, ensure nothing was silently moved to extras
    instance = model_cls.model_validate(payload)
    dumped = instance.model_dump(exclude_none=False)
    for key in payload:
        assert key in dumped, (
            f"{model_name}: field '{key}' was accepted but lost on dump — "
            f"likely fell into __pydantic_extra__ instead of being typed."
        )


def test_health_response_no_drift():
    _assert_no_drift(
        HealthResponse,
        {
            "status": "ok",
            "version": "0.1.0",
            "environment": "production",
            "upstreams": {"abs": "ok", "rba": "ok"},
        },
    )


def test_economic_dashboard_no_drift():
    _assert_no_drift(
        EconomicDashboard,
        {
            "as_of": "2026-Q1",
            "cash_rate_pct": 4.1,
            "cpi_annual_pct": 4.6,
            "unemployment_rate_pct": 3.93,
            "wage_growth_annual_pct": 3.2,
            "consumer_spending_yoy_pct": 6.1,
        },
    )


def test_meta_no_drift():
    _assert_no_drift(
        Meta,
        {
            "endpoint": "/v1/economic-dashboard",
            "query": {"period": "latest"},
            "period": {"start": "2026-Q1", "end": "2026-Q1"},
            "row_count": 1,
            "retrieved_at": "2026-05-17T00:00:00Z",
            "sources": [],
            "stale": False,
            "stale_reason": None,
            "server_version": "0.1.0",
            "tier": "free",
        },
    )


def test_links_no_drift():
    _assert_no_drift(Links, {"csv": None, "chart_template": None})


def test_source_citation_no_drift():
    _assert_no_drift(
        SourceCitation,
        {
            "name": "RBA Statistical Table F1.1 (Cash rate)",
            "url": "https://www.rba.gov.au/statistics/tables/",
            "attribution": "Source: Reserve Bank of Australia, licensed under CC-BY 4.0.",
        },
    )


def test_real_wage_row_no_drift():
    _assert_no_drift(
        RealWageRow,
        {
            "period": "2026-Q1",
            "wpi_annual_change_pct": 3.3,
            "cpi_annual_change_pct": 3.8,
            "real_wages_gap_pct": -0.5,
            "real_wages_direction": "shrinking",
        },
    )


def test_dataset_summary_no_drift():
    _assert_no_drift(
        DatasetSummary,
        {
            "dataset_id": "abs.LF",
            "source": "ABS",
            "name": "Labour Force, Australia",
            "description": "Monthly labour force estimates.",
            "is_curated": True,
            "relevance": 95.0,
            "endpoint": None,
        },
    )


def test_account_response_no_drift():
    _assert_no_drift(
        AccountResponse,
        {
            "key": "ak_xxx",
            "tier": "free",
            "monthly_usage": 42,
            "monthly_limit": 100,
            "created_at": "2026-01-01T00:00:00Z",
            "last_used_at": None,
        },
    )


def test_whoami_response_no_drift():
    from ausdata.models import WhoamiResponse
    _assert_no_drift(
        WhoamiResponse,
        {
            "auth_kind": "api_key",
            "tier": "free",
            "monthly_usage": 5,
            "monthly_limit": 100,
            "key_prefix": "abcd1234",
            "email": None,
        },
    )
