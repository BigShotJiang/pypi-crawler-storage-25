"""Tests for the sync :class:`ausdata.Client` constructor + headers + auth."""

from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

from ausdata import Client
from ausdata.exceptions import AuthenticationError


def test_client_uses_explicit_api_key(httpx_mock: HTTPXMock, health_body: dict) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health",
        json=health_body,
        status_code=200,
    )
    client = Client(api_key="ak_explicit_123")
    result = client.health()
    assert result.status == "ok"

    request = httpx_mock.get_request()
    assert request is not None
    assert request.headers["Authorization"] == "Bearer ak_explicit_123"


def test_client_falls_back_to_env_var(
    monkeypatch: pytest.MonkeyPatch, httpx_mock: HTTPXMock, health_body: dict
) -> None:
    monkeypatch.setenv("AUSDATA_API_KEY", "ak_from_env_456")
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health", json=health_body, status_code=200
    )

    client = Client()  # no api_key arg
    client.health()

    request = httpx_mock.get_request()
    assert request is not None
    assert request.headers["Authorization"] == "Bearer ak_from_env_456"


def test_client_raises_without_any_key() -> None:
    with pytest.raises(AuthenticationError) as exc_info:
        Client(api_key=None)
    assert "No API key" in str(exc_info.value)
    assert "AUSDATA_API_KEY" in str(exc_info.value)
    assert "ausdata.io" in str(exc_info.value)


def test_client_sends_user_agent(httpx_mock: HTTPXMock, health_body: dict) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health", json=health_body, status_code=200
    )
    client = Client(api_key="ak_x")
    client.health()
    request = httpx_mock.get_request()
    assert request is not None
    assert request.headers["User-Agent"].startswith("ausdata-python/")


def test_client_respects_custom_base_url(
    httpx_mock: HTTPXMock, health_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://staging.ausdata.io/v1/health",
        json=health_body,
        status_code=200,
    )
    client = Client(api_key="ak_x", base_url="https://staging.ausdata.io")
    client.health()


def test_client_strips_trailing_slash_in_base_url(
    httpx_mock: HTTPXMock, health_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://staging.ausdata.io/v1/health",
        json=health_body,
        status_code=200,
    )
    client = Client(api_key="ak_x", base_url="https://staging.ausdata.io/")
    result = client.health()
    assert result.status == "ok"


def test_client_as_context_manager(
    httpx_mock: HTTPXMock, health_body: dict
) -> None:
    httpx_mock.add_response(
        url="https://api.ausdata.io/v1/health", json=health_body, status_code=200
    )
    with Client(api_key="ak_x") as client:
        result = client.health()
        assert result.status == "ok"
