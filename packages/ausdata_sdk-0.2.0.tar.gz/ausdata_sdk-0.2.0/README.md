# ausdata — Python SDK for the Australian public data API

The official Python client for [ausdata.io](https://ausdata.io). One auth key,
one uniform response envelope, every major Australian government data source.

```bash
pip install ausdata-sdk
# or, with pandas convenience:
pip install "ausdata-sdk[pandas]"
```

## Why?

The chart you spend 90 minutes building in Excel — one HTTP call.

```bash
# Before — wrangling SDMX XML by hand
curl 'https://api.data.abs.gov.au/data/WPI/...'

# After — typed, normalised, attribution-tagged
```

```python
from ausdata import Client

client = Client(api_key="ak_xxx")
result = client.real_wages(start="2019-Q1", end="2024-Q4")

print(result.data[0])
# RealWageRow(period='2024-Q4', wpi_annual_change_pct=3.2,
#             cpi_annual_change_pct=2.4, real_wages_gap_pct=0.8,
#             real_wages_direction='growing')

df = result.to_dataframe()       # pandas (optional extra)
result.to_csv("real_wages.csv")  # Datawrapper-friendly
```

## Async client

```python
import asyncio
from ausdata import AsyncClient

async def main():
    async with AsyncClient(api_key="ak_xxx") as client:
        snapshot = await client.economic_dashboard()
        print(snapshot.data.cash_rate_pct, snapshot.data.unemployment_rate_pct)

asyncio.run(main())
```

## Endpoints

| Method | API endpoint | What you get |
|---|---|---|
| `client.health()` | `GET /v1/health` | Service status (no quota cost) |
| `client.whoami()` | `GET /v1/whoami` | Tier + monthly usage (works for API keys or JWTs) |
| `client.account.api_key()` | `GET /v1/account/api-key` | Your key + tier + monthly usage (JWT-only) |
| `client.account.rotate_key()` | `POST /v1/account/api-key` | Rotate the key, get new plaintext (JWT-only) |
| `client.search_datasets(q=...)` | `GET /v1/search-datasets` | Search across all 9 AU sources |
| `client.list_datasets(source)` | `GET /v1/datasets/{source}` | Enumerate curated datasets for one source |
| `client.describe(source, id)` | `GET /v1/describe/{source}/{id}` | Schema: dimensions, valid filters, valid values |
| `client.get_data(source, id, **filters)` | `GET /v1/data/{source}/{id}` | Fetch any dataset with source-specific filters |
| `client.real_wages(start=...)` | `GET /v1/real-wages` | WPI YoY minus CPI YoY (composed) |
| `client.economic_dashboard()` | `GET /v1/economic-dashboard` | 5-source headline macro snapshot (composed) |

The full discover → introspect → fetch loop is:

```python
r = client.search_datasets(q="unemployment rate")  # find dataset
schema = client.describe("abs", "LF")              # see valid filters
data = client.get_data("abs", "LF",                # fetch with right filters
                       measure="unemployment_rate",
                       region="nsw", start="2024-01")
```

Every data response is wrapped in the same `ApiResponse` envelope so you
always know where to find the payload (`.data`), the attribution (`.meta.sources`),
and the audit trail (`.meta.retrieved_at`, `.meta.stale`).

## Pricing

| Tier | Price | Calls/mo | Notes |
|---|---|---|---|
| Free | $0 | 100 | 1y history, attribution required |
| Analyst | $29 | 10,000 | 10y history, no attribution |
| Pro | $99 | 100,000 | Webhooks, priority support |
| Enterprise | custom | unlimited | SLA, white-label, custom queries |

Sign up + get a free key at [ausdata.io](https://ausdata.io).

## Configuration

```python
from ausdata import Client

# API key resolution order:
#   1. explicit api_key= argument
#   2. AUSDATA_API_KEY environment variable
client = Client(
    api_key="ak_xxx",
    base_url="https://api.ausdata.io",   # override for staging
    timeout=30.0,                         # per-request timeout (seconds)
    max_retries=3,                        # 5xx + 429 retry budget
    retry_backoff_factor=2.0,             # exponential delay multiplier
)
```

## Errors

```python
from ausdata import Client
from ausdata.exceptions import (
    AusdataError,         # base
    AuthenticationError,  # 401
    PermissionError,      # 403, 402 (tier-blocked)
    RateLimitError,       # 429 with retry_after
    ValidationError,      # 400
    UpstreamError,        # 502/503
    AusdataServerError,   # 5xx fallback
)

try:
    result = client.real_wages(start="not-a-quarter")
except ValidationError as e:
    print(e.message, "Hint:", e.hint)
```

Every error carries the API's message plus the actionable `hint` when
available (e.g. `"Did you mean 2024-Q1?"`).

## Links

- **Docs**: [docs.ausdata.io](https://docs.ausdata.io)
- **API reference**: [api.ausdata.io/docs](https://api.ausdata.io/docs)
- **Issues**: [github.com/Bigred97/ausdata-sdk/issues](https://github.com/Bigred97/ausdata-sdk/issues)

## License

MIT. See [LICENSE](LICENSE).
