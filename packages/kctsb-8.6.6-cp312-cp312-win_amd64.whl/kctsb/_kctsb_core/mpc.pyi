"""
MPC primitives — Rep3 replicated secret sharing and Half-Gates GC benchmarks
"""
from __future__ import annotations
import collections.abc
import typing
__all__: list[str] = ['GCResult', 'gc_benchmark', 'gc_benchmark_parallel', 'rep3_reconstruct', 'rep3_reconstruct_batch', 'rep3_share', 'rep3_share_batch']
class GCResult:
    """
    
            Garbled-circuit benchmark result.
    
            Attributes:
                garble_ms (float): Garbling time in milliseconds.
                eval_ms (float): Evaluation time in milliseconds.
                and_gates (int): Number of AND gates processed.
                free_gates (int): Number of free gates (XOR/NOT).
                table_bytes (int): Garbled table size in bytes.
                throughput_mgates_sec (float): Million gates per second.
            
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def and_gates(self) -> int:
        ...
    @property
    def eval_ms(self) -> float:
        ...
    @property
    def free_gates(self) -> int:
        ...
    @property
    def garble_ms(self) -> float:
        ...
    @property
    def table_bytes(self) -> int:
        ...
    @property
    def throughput_mgates_sec(self) -> float:
        ...
def gc_benchmark(num_and_gates: typing.SupportsInt = 1000000) -> GCResult:
    """
            Single-threaded Half-Gates garbled circuit benchmark.
    
            Garbles and evaluates a synthetic circuit with ``num_and_gates`` AND
            gates to measure single-core throughput.
    
            Args:
                num_and_gates: Number of AND gates (default 1 000 000).
    
            Returns:
                :class:`GCResult` with timing and throughput statistics.
    
            Example::
    
                r = mpc.gc_benchmark(100_000)
                print(f"{r.throughput_mgates_sec:.1f} Mgate/s")
    """
def gc_benchmark_parallel(total_and_gates: typing.SupportsInt = 1000000, num_threads: typing.SupportsInt = 0) -> GCResult:
    """
            Multi-threaded batched Half-Gates benchmark.
    
            Mirrors EMP-toolkit's "N independent AES-128 circuit" benchmark style:
            spawns ``num_threads`` workers each garbling independent sub-circuits,
            then reports aggregate throughput.
    
            Args:
                total_and_gates: Total AND gates across all threads (default 1 000 000).
                num_threads: Worker count; 0 = ``hardware_concurrency`` clamped to
                    ``[1, 16]``. Can be controlled via ``KCTSB_OT_THREADS`` env var.
    
            Returns:
                :class:`GCResult` with aggregate throughput
                (garble_ms = 0 for parallel, eval_ms = wall-clock).
    
            Example::
    
                r = mpc.gc_benchmark_parallel(1_000_000, num_threads=0)
                print(f"{r.throughput_mgates_sec:.1f} Mgate/s (parallel)")
    """
def rep3_reconstruct(shares: collections.abc.Sequence[tuple[typing.SupportsInt, typing.SupportsInt]]) -> int:
    """
            Reconstruct a uint64 secret from 3 replicated shares.
    
            Args:
                shares: List of exactly 3 ``(share_a, share_b)`` tuples.
    
            Returns:
                Reconstructed 64-bit unsigned integer.
    """
def rep3_reconstruct_batch(shares: collections.abc.Sequence[collections.abc.Sequence[tuple[typing.SupportsInt, typing.SupportsInt]]]) -> list[int]:
    """
            Batch Rep3 reconstruction.
    
            Args:
                shares: List of length *n*. Each element is a list of 3
                    ``(share_a, share_b)`` tuples (as returned by
                    ``rep3_share_batch``).
    
            Returns:
                List of *n* reconstructed uint64 values.
    """
def rep3_share(secret: typing.SupportsInt) -> list[tuple[int, int]]:
    """
            Split a uint64 secret into 3 replicated shares.
    
            Args:
                secret: 64-bit unsigned integer to share.
    
            Returns:
                List of 3 ``(share_a, share_b)`` tuples. Party *i* holds tuple *i*.
    
            Example::
    
                shares = mpc.rep3_share(42)
                assert len(shares) == 3
                value = mpc.rep3_reconstruct(shares)
                assert value == 42
    """
def rep3_share_batch(secrets: collections.abc.Sequence[typing.SupportsInt]) -> list[list[tuple[int, int]]]:
    """
            Batch Rep3 sharing using AES-CTR PRG for bulk randomness.
    
            Significantly faster than calling ``rep3_share`` in a loop for large
            batches (matches MOTION's batch-share throughput of ~130 Mops/s).
    
            Args:
                secrets: List of uint64 values to share.
    
            Returns:
                List of length ``len(secrets)``. Each element is a list of 3
                ``(share_a, share_b)`` tuples.
    
            Example::
    
                secrets = list(range(1000))
                all_shares = mpc.rep3_share_batch(secrets)
                recovered  = mpc.rep3_reconstruct_batch(all_shares)
                assert recovered == secrets
    """
