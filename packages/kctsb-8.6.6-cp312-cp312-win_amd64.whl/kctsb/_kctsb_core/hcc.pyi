"""
Homomorphic Confidential Computing — 6 privacy-preserving scenarios
"""
from __future__ import annotations
import collections.abc
import typing
__all__: list[str] = ['BLINDING', 'COMPARISON', 'Config', 'DP_NOISE', 'DataTier', 'EQUALITY', 'EncryptedValue', 'MODERATE', 'NON_PERSONAL', 'SENSITIVE', 'SORTING', 'STATISTICS', 'Scenario', 'Session']
class Config:
    """
    
            HCC session configuration.
    
            Parameters
            ----------
            n : int
                Ring dimension (power of 2, default 8192).
            L : int
                Maximum modulus levels (default 3).
            log_scale : float
                CKKS scaling factor in log₂ (default 40.0).
            sigma : float
                Error standard deviation (default 3.2).
            tier : DataTier
                Data sensitivity tier (default SENSITIVE).
            dp_epsilon : float
                DP privacy budget ε (default 1.0).
            dp_delta : float
                DP delta parameter (default 1e-5).
            dp_sensitivity : float
                DP query sensitivity Δf (default 1.0).
            
    """
    tier: DataTier
    def __init__(self, n: typing.SupportsInt = 8192, L: typing.SupportsInt = 3, log_scale: typing.SupportsFloat = 40.0, sigma: typing.SupportsFloat = 3.2, tier: DataTier = ..., dp_epsilon: typing.SupportsFloat = 1.0, dp_delta: typing.SupportsFloat = 1e-05, dp_sensitivity: typing.SupportsFloat = 1.0) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def L(self) -> int:
        ...
    @L.setter
    def L(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def dp_delta(self) -> float:
        ...
    @dp_delta.setter
    def dp_delta(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def dp_epsilon(self) -> float:
        ...
    @dp_epsilon.setter
    def dp_epsilon(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def dp_sensitivity(self) -> float:
        ...
    @dp_sensitivity.setter
    def dp_sensitivity(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def log_scale(self) -> float:
        ...
    @log_scale.setter
    def log_scale(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def n(self) -> int:
        ...
    @n.setter
    def n(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def sigma(self) -> float:
        ...
    @sigma.setter
    def sigma(self, arg0: typing.SupportsFloat) -> None:
        ...
class DataTier:
    """
    Data sensitivity tier for three-tier encryption.
    
    Members:
    
      SENSITIVE : Full CKKS HE (K1)
    
      MODERATE : K1 → PCC → HE (K2)
    
      NON_PERSONAL : AES-256-GCM only (K3)
    """
    MODERATE: typing.ClassVar[DataTier]  # value = <DataTier.MODERATE: 2>
    NON_PERSONAL: typing.ClassVar[DataTier]  # value = <DataTier.NON_PERSONAL: 3>
    SENSITIVE: typing.ClassVar[DataTier]  # value = <DataTier.SENSITIVE: 1>
    __members__: typing.ClassVar[dict[str, DataTier]]  # value = {'SENSITIVE': <DataTier.SENSITIVE: 1>, 'MODERATE': <DataTier.MODERATE: 2>, 'NON_PERSONAL': <DataTier.NON_PERSONAL: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class EncryptedValue:
    """
    
            Encrypted value produced by HCCSession.
    
            Properties
            ----------
            scale : float
                Current CKKS scaling factor.
            level : int
                Current modulus level.
            size : int
                Number of polynomial components.
            
    """
    def __repr__(self) -> str:
        ...
    @property
    def level(self) -> int:
        ...
    @property
    def scale(self) -> float:
        ...
    @property
    def size(self) -> int:
        ...
class Scenario:
    """
    HCC computation scenario.
    
    Members:
    
      STATISTICS
    
      EQUALITY
    
      COMPARISON
    
      SORTING
    
      BLINDING
    
      DP_NOISE
    """
    BLINDING: typing.ClassVar[Scenario]  # value = <Scenario.BLINDING: 4>
    COMPARISON: typing.ClassVar[Scenario]  # value = <Scenario.COMPARISON: 2>
    DP_NOISE: typing.ClassVar[Scenario]  # value = <Scenario.DP_NOISE: 5>
    EQUALITY: typing.ClassVar[Scenario]  # value = <Scenario.EQUALITY: 1>
    SORTING: typing.ClassVar[Scenario]  # value = <Scenario.SORTING: 3>
    STATISTICS: typing.ClassVar[Scenario]  # value = <Scenario.STATISTICS: 0>
    __members__: typing.ClassVar[dict[str, Scenario]]  # value = {'STATISTICS': <Scenario.STATISTICS: 0>, 'EQUALITY': <Scenario.EQUALITY: 1>, 'COMPARISON': <Scenario.COMPARISON: 2>, 'SORTING': <Scenario.SORTING: 3>, 'BLINDING': <Scenario.BLINDING: 4>, 'DP_NOISE': <Scenario.DP_NOISE: 5>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Session:
    """
    
            HCC Session — unified API for all 6 confidential computing scenarios.
    
            Manages CKKS key generation, encryption/decryption, and provides
            methods for each scenario: statistics, equality, comparison,
            sorting, blinding, and differential privacy.
    
            Parameters
            ----------
            config : Config
                Session configuration.
    
            Examples
            --------
            >>> cfg = hcc.Config(n=4096, L=3, log_scale=40.0)
            >>> session = hcc.Session(cfg)
            >>> session.generate_keys()
            >>> enc_a = session.encrypt(3.14)
            >>> enc_b = session.encrypt(2.71)
            >>> enc_sum = session.add(enc_a, enc_b)
            >>> session.decrypt(enc_sum)
            5.85...
            
    """
    @staticmethod
    def remove_blinding(blinded_result: typing.SupportsFloat, blinding_factor: typing.SupportsFloat) -> float:
        """
        Remove blinding from a decrypted result: x = blinded / factor.
        """
    def __init__(self, config: Config) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def add(self, a: EncryptedValue, b: EncryptedValue) -> EncryptedValue:
        """
        Homomorphic addition: Enc(a) + Enc(b).
        """
    def add_batch(self, a: collections.abc.Sequence[EncryptedValue], b: collections.abc.Sequence[EncryptedValue]) -> list[EncryptedValue]:
        """
        Batch homomorphic addition: pair-wise add on chunked ciphertexts.
        """
    def add_gaussian_noise(self, encrypted: EncryptedValue) -> EncryptedValue:
        """
        Add Gaussian DP noise (ε,δ calibrated) to encrypted value.
        """
    def add_laplace_noise(self, encrypted: EncryptedValue) -> EncryptedValue:
        """
        Add Laplace DP noise (ε calibrated) to encrypted value.
        """
    def apply_blinding(self, encrypted: EncryptedValue) -> tuple[EncryptedValue, float]:
        """
                Apply multiplicative blinding.
        
                Returns
                -------
                tuple[EncryptedValue, float]
                    (blinded_enc, blinding_factor)
        """
    def batch_add_gaussian_noise(self, encrypted_list: collections.abc.Sequence[EncryptedValue]) -> list[EncryptedValue]:
        """
        Batch add Gaussian DP noise to multiple encrypted values.
        """
    def batch_add_laplace_noise(self, encrypted_list: collections.abc.Sequence[EncryptedValue]) -> list[EncryptedValue]:
        """
        Batch add Laplace DP noise to multiple encrypted values.
        """
    def decrypt(self, encrypted: EncryptedValue) -> float:
        """
                Decrypt to a single real value.
        
                Parameters
                ----------
                encrypted : EncryptedValue
        
                Returns
                -------
                float
        """
    def decrypt_batch(self, encrypted: collections.abc.Sequence[EncryptedValue], total_count: typing.SupportsInt) -> list[float]:
        """
                Decrypt a batch of ciphertexts and concatenate results.
        
                Parameters
                ----------
                encrypted : list[EncryptedValue]
                    Ciphertexts from encrypt_batch.
                total_count : int
                    Original number of values (for correct trimming).
        
                Returns
                -------
                list[float]
                    Decrypted values, exactly total_count elements.
        """
    def decrypt_vector(self, encrypted: EncryptedValue) -> list[float]:
        """
        Decrypt to a vector of real values.
        """
    def encrypt(self, value: typing.SupportsFloat) -> EncryptedValue:
        """
                Encrypt a single real value.
        
                Parameters
                ----------
                value : float
        
                Returns
                -------
                EncryptedValue
        """
    def encrypt_batch(self, values: collections.abc.Sequence[typing.SupportsFloat]) -> list[EncryptedValue]:
        """
                Encrypt a vector with automatic SIMD slot chunking.
        
                If len(values) > n/2, splits into ceil(N/(n/2)) ciphertexts.
                Each ciphertext packs up to n/2 values via SIMD slots.
        
                Parameters
                ----------
                values : list[float]
                    Arbitrary-length vector.
        
                Returns
                -------
                list[EncryptedValue]
                    One ciphertext per chunk; single-element list if N <= n/2.
        """
    def encrypt_vector(self, values: collections.abc.Sequence[typing.SupportsFloat]) -> EncryptedValue:
        """
                Encrypt a vector of real values (SIMD packing).
        
                Parameters
                ----------
                values : list[float]
        
                Returns
                -------
                EncryptedValue
        """
    def encrypted_covariance(self, encrypted_x: collections.abc.Sequence[EncryptedValue], encrypted_y: collections.abc.Sequence[EncryptedValue], count: typing.SupportsInt) -> EncryptedValue:
        """
        Encrypted covariance: Cov(X,Y) = E[XY] - E[X]E[Y].
        """
    def encrypted_dot_product(self, encrypted_x: collections.abc.Sequence[EncryptedValue], encrypted_y: collections.abc.Sequence[EncryptedValue]) -> EncryptedValue:
        """
        Encrypted dot product: Σ xi * yi.
        """
    def encrypted_equality(self, a: EncryptedValue, b: EncryptedValue) -> EncryptedValue:
        """
        Encrypted equality test: ≈1 if equal, ≈0 otherwise.
        """
    def encrypted_greater_than(self, a: EncryptedValue, b: EncryptedValue, scale_range: typing.SupportsFloat = 1.0) -> EncryptedValue:
        """
        Encrypted greater-than: ≈1 if a > b, ≈0 otherwise.
        """
    def encrypted_mean(self, encrypted_values: collections.abc.Sequence[EncryptedValue], count: typing.SupportsInt) -> EncryptedValue:
        """
        Encrypted mean of values.
        """
    def encrypted_minmax(self, a: EncryptedValue, b: EncryptedValue) -> tuple[EncryptedValue, EncryptedValue]:
        """
        Encrypted min/max: returns (Enc(min), Enc(max)).
        """
    def encrypted_second_moment(self, encrypted_values: collections.abc.Sequence[EncryptedValue], count: typing.SupportsInt) -> EncryptedValue:
        """
        Encrypted second raw moment: E[X²] = (1/n) Σ xi².
        """
    def encrypted_sort(self, encrypted_values: collections.abc.Sequence[EncryptedValue], ascending: bool = True) -> list[EncryptedValue]:
        """
        Sort encrypted values using Batcher's odd-even merge network.
        """
    def encrypted_sum(self, encrypted_values: collections.abc.Sequence[EncryptedValue]) -> EncryptedValue:
        """
                Encrypted sum of values.
        
                Parameters
                ----------
                encrypted_values : list[EncryptedValue]
        
                Returns
                -------
                EncryptedValue
                    Encryption of Σ values[i].
        """
    def encrypted_sum_of_squares(self, encrypted_values: collections.abc.Sequence[EncryptedValue]) -> EncryptedValue:
        """
        Encrypted sum of squares: Σ xi².
        """
    def encrypted_variance(self, encrypted_values: collections.abc.Sequence[EncryptedValue], count: typing.SupportsInt) -> EncryptedValue:
        """
        Encrypted variance: Var = E[X²] - (E[X])².
        """
    def generate_keys(self) -> None:
        """
        Generate secret key, public key, and relinearization key.
        """
    def multiply(self, a: EncryptedValue, b: EncryptedValue) -> EncryptedValue:
        """
        Homomorphic multiplication with relin + rescale.
        """
    def multiply_batch(self, a: collections.abc.Sequence[EncryptedValue], b: collections.abc.Sequence[EncryptedValue]) -> list[EncryptedValue]:
        """
        Batch homomorphic multiplication: pair-wise mul+relin+rescale.
        """
    def sub(self, a: EncryptedValue, b: EncryptedValue) -> EncryptedValue:
        """
        Homomorphic subtraction: Enc(a) - Enc(b).
        """
    def sub_batch(self, a: collections.abc.Sequence[EncryptedValue], b: collections.abc.Sequence[EncryptedValue]) -> list[EncryptedValue]:
        """
        Batch homomorphic subtraction: pair-wise sub on chunked ciphertexts.
        """
    @property
    def dp_budget(self) -> float:
        """
        DP privacy budget ε.
        """
    @property
    def dp_sigma(self) -> float:
        """
        Gaussian noise σ for current DP parameters.
        """
BLINDING: Scenario  # value = <Scenario.BLINDING: 4>
COMPARISON: Scenario  # value = <Scenario.COMPARISON: 2>
DP_NOISE: Scenario  # value = <Scenario.DP_NOISE: 5>
EQUALITY: Scenario  # value = <Scenario.EQUALITY: 1>
MODERATE: DataTier  # value = <DataTier.MODERATE: 2>
NON_PERSONAL: DataTier  # value = <DataTier.NON_PERSONAL: 3>
SENSITIVE: DataTier  # value = <DataTier.SENSITIVE: 1>
SORTING: Scenario  # value = <Scenario.SORTING: 3>
STATISTICS: Scenario  # value = <Scenario.STATISTICS: 0>
