"""
RFC 9497 VOPRF — P256-SHA256 Verifiable Oblivious PRF
"""
from __future__ import annotations
import typing
__all__: list[str] = ['Mode', 'NE', 'NH', 'NK', 'NS', 'SEED_LEN', 'SUITE_ID', 'blind', 'derive_key_pair', 'evaluate', 'oprf_evaluate_blinded', 'oprf_finalize', 'poprf_evaluate', 'verify_proof', 'voprf_evaluate_blinded']
class Mode:
    """
    VOPRF protocol mode (RFC 9497)
    
    Members:
    
      OPRF : Basic oblivious PRF (no proof)
    
      VOPRF : Verifiable oblivious PRF (with DLEQ proof)
    
      POPRF : Partially-oblivious PRF (with info binding + proof)
    """
    OPRF: typing.ClassVar[Mode]  # value = <Mode.OPRF: 0>
    POPRF: typing.ClassVar[Mode]  # value = <Mode.POPRF: 2>
    VOPRF: typing.ClassVar[Mode]  # value = <Mode.VOPRF: 1>
    __members__: typing.ClassVar[dict[str, Mode]]  # value = {'OPRF': <Mode.OPRF: 0>, 'VOPRF': <Mode.VOPRF: 1>, 'POPRF': <Mode.POPRF: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
def blind(input: bytes, mode: Mode) -> tuple:
    """
        Blind an input for OPRF/VOPRF/POPRF (RFC 9497 §3.3.2).
    
        Args:
            input: Client's private input (bytes)
            mode: Protocol mode
    
        Returns:
            Tuple of (blind_scalar_bytes, blinded_element_bytes)
    """
def derive_key_pair(seed: bytes, info: bytes, mode: Mode) -> tuple:
    """
        Derive a key pair from seed and info (RFC 9497 §3.2.1).
    
        Args:
            seed: 32-byte random seed
            info: Optional info string (bytes)
            mode: Protocol mode (OPRF/VOPRF/POPRF)
    
        Returns:
            Tuple of (sk_bytes, pk_bytes) - 32-byte secret key, 33-byte public key
    """
def evaluate(sk: bytes, input: bytes, mode: Mode) -> bytes:
    """
    Direct PRF evaluation: F(sk, input).
    """
def oprf_evaluate_blinded(sk: bytes, blinded_element: bytes) -> bytes:
    """
    Server-side OPRF evaluation (no proof).
    """
def oprf_finalize(input: bytes, blind: bytes, evaluated_element: bytes) -> bytes:
    """
    Client-side OPRF finalization.
    """
def poprf_evaluate(sk: bytes, input: bytes, info: bytes) -> bytes:
    """
    Direct POPRF evaluation: F(sk, input, info).
    """
def verify_proof(pk: bytes, blinded_element: bytes, evaluated_element: bytes, proof_c: bytes, proof_s: bytes, mode: Mode) -> bool:
    """
        Verify a DLEQ proof (client-side, RFC 9497 §2.2.2).
    
        Verifies that the server used the private key corresponding to `pk` when
        computing `evaluated_element` from `blinded_element`.
    
        Args:
            pk: 33-byte compressed public key
            blinded_element: 33-byte blinded input sent to server
            evaluated_element: 33-byte evaluated output from server
            proof_c: 32-byte proof challenge scalar
            proof_s: 32-byte proof response scalar
            mode: Protocol mode (VOPRF or POPRF)
    
        Returns:
            True if the DLEQ proof is valid, False otherwise
    """
def voprf_evaluate_blinded(sk: bytes, pk: bytes, blinded_element: bytes, mode: Mode) -> tuple:
    """
    Server-side VOPRF evaluation (with DLEQ proof).
    """
NE: int = 33
NH: int = 32
NK: int = 32
NS: int = 32
SEED_LEN: int = 32
SUITE_ID: str = 'P256-SHA256'
