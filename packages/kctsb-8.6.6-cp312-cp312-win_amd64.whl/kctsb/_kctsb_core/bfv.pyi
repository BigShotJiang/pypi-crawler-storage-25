"""
BFV scale-invariant homomorphic encryption — exact integer arithmetic
"""
from __future__ import annotations
import collections.abc
import typing
__all__: list[str] = ['Acceleration', 'BatchEncoder', 'Ciphertext', 'Context', 'GCCompareResult', 'GarbledComparisonCircuit', 'InsertSortConfig', 'InsertSortResult', 'InsertSortStrategy', 'PublicKey', 'RelinKey', 'SecretKey', 'SortAlgorithm', 'SortConfig', 'SortResult', 'add', 'add_plain', 'context_n16384', 'context_n4096', 'context_n8192', 'context_toy', 'decrypt', 'decrypt_int', 'encrypt', 'encrypt_int', 'gc_batch_compare', 'gc_bitonic_sort', 'generate_keys', 'generate_public_key', 'generate_relin_key', 'generate_secret_key', 'get_delta', 'he_insert_sorted', 'he_merge_sorted', 'he_sort', 'insertion_sort_encrypted', 'multiply', 'multiply_plain', 'multiply_relin', 'negate', 'relinearize', 'simd_radix_sort', 'sub']
class Acceleration:
    """
    Hardware acceleration hint for he_sort().
    
    Members:
    
      AUTO : Auto-detect best available
    
      GPU_SIMD : GPU + SIMD (CUDA)
    
      SIMD_ONLY : CPU SIMD only
    
      BASELINE : Scalar fallback
    """
    AUTO: typing.ClassVar[Acceleration]  # value = <Acceleration.AUTO: 0>
    BASELINE: typing.ClassVar[Acceleration]  # value = <Acceleration.BASELINE: 3>
    GPU_SIMD: typing.ClassVar[Acceleration]  # value = <Acceleration.GPU_SIMD: 1>
    SIMD_ONLY: typing.ClassVar[Acceleration]  # value = <Acceleration.SIMD_ONLY: 2>
    __members__: typing.ClassVar[dict[str, Acceleration]]  # value = {'AUTO': <Acceleration.AUTO: 0>, 'GPU_SIMD': <Acceleration.GPU_SIMD: 1>, 'SIMD_ONLY': <Acceleration.SIMD_ONLY: 2>, 'BASELINE': <Acceleration.BASELINE: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class BatchEncoder:
    """
    
            SIMD Batch Encoder for BFV (NTT-based slot packing).
    
            When ``t ≡ 1 (mod 2n)``, ``X^n + 1`` splits completely over ``Z_t``,
            giving ``n`` independent SIMD slots per BFV plaintext/ciphertext.
    
            Example: ``n=16384, t=65537`` → 16384 slots × 65537 range each.
    
            Internally uses negacyclic NTT over ``Z_t`` (AVX2-accelerated).
            
    """
    def __init__(self, n: typing.SupportsInt, t: typing.SupportsInt) -> None:
        """
        Create batch encoder for polynomial degree n and plaintext modulus t.
        """
    def decode(self, coefficients: collections.abc.Sequence[typing.SupportsInt]) -> list[int]:
        """
        Decode polynomial coefficients → slot values (forward NTT over Z_t)
        """
    def decrypt_decode(self, ct: Ciphertext, ctx: Context, sk: SecretKey) -> list[int]:
        """
        Decrypt and decode to slot values in one step.
        """
    def encode(self, values: collections.abc.Sequence[typing.SupportsInt]) -> list[int]:
        """
        Encode slot values → polynomial coefficients (inverse NTT over Z_t)
        """
    def encode_encrypt(self, values: collections.abc.Sequence[typing.SupportsInt], ctx: Context, pk: PublicKey) -> Ciphertext:
        """
        Encode slot values and encrypt in one step.
        """
    @property
    def plaintext_modulus(self) -> int:
        """
        Plaintext modulus t
        """
    @property
    def slot_count(self) -> int:
        """
        Number of SIMD slots (= n)
        """
class Ciphertext:
    """
    BFV ciphertext (NTT domain)
    """
    @property
    def level(self) -> int:
        """
        Current modulus level
        """
    @property
    def noise_budget(self) -> int:
        """
        Remaining noise budget (bits)
        """
    @property
    def scale_degree(self) -> int:
        """
        Scale degree: 1=fresh, 2=after multiply
        """
    @property
    def size(self) -> int:
        """
        Number of polynomial components (2 = fresh/relinearized, 3 = after multiply)
        """
class Context:
    """
    
            BFV encryption context.
    
            Holds RNS modulus chain, evaluator, and PRNG.
            Create via ``bfv.context_n4096()``, ``bfv.context_n8192()``, etc.
            
    """
    def has_behz_tool(self) -> bool:
        """
        Check if BEHZ multiplication tool is initialized
        """
    @property
    def plaintext_modulus(self) -> int:
        """
        Plaintext modulus t
        """
class GCCompareResult:
    """
    Result of Garbled Circuit comparison.
    """
    @property
    def a_greater_than_b(self) -> bool:
        ...
    @property
    def comm_bytes(self) -> int:
        ...
    @property
    def evaluate_ms(self) -> float:
        ...
    @property
    def garble_ms(self) -> float:
        ...
    @property
    def n_and_gates(self) -> int:
        ...
    @property
    def n_xor_gates(self) -> int:
        ...
class GarbledComparisonCircuit:
    """
    
            Yao's Garbled Circuit for non-interactive ciphertext comparison.
    
            Computes (A > B) for w-bit unsigned values using:
            - Free XOR optimization (XOR gates cost zero)
            - Half-Gates AND optimization (2 ciphertexts per AND)
            - AES-NI hardware acceleration for gate garbling
    
            Example (t=65537, w=17):
                gc = bfv.GarbledComparisonCircuit(17)
                result = gc.compare(42, 37, ctx)  # 42 > 37? → True
            
    """
    def __init__(self, bit_width: typing.SupportsInt) -> None:
        """
        Create comparison circuit for bit_width-bit values.
        """
    def compare(self, a: typing.SupportsInt, b: typing.SupportsInt, ctx: Context) -> GCCompareResult:
        """
        Complete comparison: garble + evaluate. Returns GCCompareResult.
        """
    @property
    def bit_width(self) -> int:
        ...
    @property
    def communication_bytes(self) -> int:
        ...
    @property
    def gate_count(self) -> int:
        ...
    @property
    def wire_count(self) -> int:
        ...
class InsertSortConfig:
    """
    Configuration for he_insert_sorted().
    """
    ascending: bool
    strategy: InsertSortStrategy
    def __init__(self) -> None:
        ...
    @property
    def bit_width(self) -> int:
        ...
    @bit_width.setter
    def bit_width(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def thread_count(self) -> int:
        ...
    @thread_count.setter
    def thread_count(self, arg0: typing.SupportsInt) -> None:
        ...
class InsertSortResult:
    """
    Result from he_insert_sorted().
    """
    @property
    def acceleration_used(self) -> str:
        ...
    @property
    def elapsed_ms(self) -> float:
        ...
    @property
    def n_comparisons(self) -> int:
        ...
    @property
    def n_he_ops(self) -> int:
        ...
    @property
    def n_inserted(self) -> int:
        ...
    @property
    def n_original(self) -> int:
        ...
    @property
    def sorted_values(self) -> list[int]:
        ...
    @property
    def strategy_used(self) -> str:
        ...
    @property
    def verified(self) -> bool:
        ...
class InsertSortStrategy:
    """
    
            Strategy for inserting new values into already-sorted encrypted data.
    
            Only FULL_RESORT is supported. GC Bitonic full re-sort (~0.018ms/cmp)
            is ~270x faster than HE binary search insert (~32ms/cmp).
            For retrieval, use gc_binary_search() O(log N) + implicit index O(1).
            
    
    Members:
    
      FULL_RESORT
    """
    FULL_RESORT: typing.ClassVar[InsertSortStrategy]  # value = <InsertSortStrategy.FULL_RESORT: 1>
    __members__: typing.ClassVar[dict[str, InsertSortStrategy]]  # value = {'FULL_RESORT': <InsertSortStrategy.FULL_RESORT: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class PublicKey:
    """
    BFV public key (NTT domain)
    """
class RelinKey:
    """
    BFV relinearization key
    """
class SecretKey:
    """
    BFV secret key (NTT domain)
    """
class SortAlgorithm:
    """
    Algorithm selection for he_sort().
    
    Members:
    
      AUTO : Auto-select optimal algorithm based on input size
    
      RADIX : SIMD Radix Sort (LSD, stable, GPU auto-accelerated)
    
      GC_BITONIC : GC Bitonic Sort (non-interactive, multi-threaded, fastest)
    """
    AUTO: typing.ClassVar[SortAlgorithm]  # value = <SortAlgorithm.AUTO: 0>
    GC_BITONIC: typing.ClassVar[SortAlgorithm]  # value = <SortAlgorithm.GC_BITONIC: 3>
    RADIX: typing.ClassVar[SortAlgorithm]  # value = <SortAlgorithm.RADIX: 1>
    __members__: typing.ClassVar[dict[str, SortAlgorithm]]  # value = {'AUTO': <SortAlgorithm.AUTO: 0>, 'RADIX': <SortAlgorithm.RADIX: 1>, 'GC_BITONIC': <SortAlgorithm.GC_BITONIC: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SortConfig:
    """
    
            Configuration for the unified he_sort() API.
    
            Attributes:
                algorithm: Algorithm selection (default: AUTO)
                acceleration: Hardware hint (default: AUTO)
                ascending: Sort direction (default: True)
                bit_width: Bits per value for radix sort (default: 17)
                thread_count: Thread count for GC sort (0 = auto-detect)
            
    """
    acceleration: Acceleration
    algorithm: SortAlgorithm
    ascending: bool
    def __init__(self) -> None:
        ...
    @property
    def bit_width(self) -> int:
        ...
    @bit_width.setter
    def bit_width(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def thread_count(self) -> int:
        ...
    @thread_count.setter
    def thread_count(self, arg0: typing.SupportsInt) -> None:
        ...
class SortResult:
    """
    Result of a homomorphic sorting operation.
    """
    @property
    def acceleration_used(self) -> str:
        ...
    @property
    def algorithm_used(self) -> str:
        ...
    @property
    def elapsed_ms(self) -> float:
        ...
    @property
    def n_comparisons(self) -> int:
        ...
    @property
    def n_he_ops(self) -> int:
        ...
    @property
    def sorted_values(self) -> list[int]:
        ...
    @property
    def verified(self) -> bool:
        ...
def add(ctx: Context, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
    """
    Homomorphic addition: ct1 + ct2.
    """
def add_plain(ctx: Context, ct: Ciphertext, plaintext: collections.abc.Sequence[typing.SupportsInt]) -> Ciphertext:
    """
    Add plaintext to ciphertext: ct + Δ·pt.
    """
def context_n16384(plaintext_modulus: typing.SupportsInt = 256) -> Context:
    """
        Create 128-bit security context (n=16384, 7 primes).
    
        Supports 6+ multiplicative depth. For deep circuits.
    
        Args:
            plaintext_modulus: Plaintext space modulus t (default: 256)
    
        Returns:
            BFV Context with 128-bit security (n=16384)
    """
def context_n4096(plaintext_modulus: typing.SupportsInt = 256) -> Context:
    """
        Create 128-bit security context (n=4096, 3 primes).
    
        Supports 2-3 multiplicative depth. Good for simple comparisons.
    
        Args:
            plaintext_modulus: Plaintext space modulus t (default: 256)
    
        Returns:
            BFV Context with 128-bit security (n=4096)
    """
def context_n8192(plaintext_modulus: typing.SupportsInt = 256) -> Context:
    """
        Create 128-bit security context (n=8192, 5 primes).
    
        Supports 4-5 multiplicative depth. Good for phone/ID equality.
    
        Args:
            plaintext_modulus: Plaintext space modulus t (default: 256)
    
        Returns:
            BFV Context with 128-bit security (n=8192)
    """
def context_toy(plaintext_modulus: typing.SupportsInt = 256) -> Context:
    """
        Create a TOY context (n=256) — for testing only, NOT secure.
    
        Args:
            plaintext_modulus: Plaintext space modulus t (default: 256)
    
        Returns:
            BFV Context with toy parameters
    """
def decrypt(ctx: Context, ct: Ciphertext, sk: SecretKey) -> list[int]:
    """
        Decrypt ciphertext to plaintext vector.
    
        Args:
            ctx: BFV Context
            ct: Ciphertext (must be size 2)
            sk: Secret key
    
        Returns:
            List of plaintext integers
    """
def decrypt_int(ctx: Context, ct: Ciphertext, sk: SecretKey) -> int:
    """
    Decrypt and return only the first slot value.
    """
def encrypt(ctx: Context, plaintext: collections.abc.Sequence[typing.SupportsInt], pk: PublicKey) -> Ciphertext:
    """
        Encrypt plaintext vector.
    
        Args:
            ctx: BFV Context
            plaintext: List of integers in [0, t-1]
            pk: Public key
    
        Returns:
            BFV Ciphertext
    """
def encrypt_int(ctx: Context, value: typing.SupportsInt, pk: PublicKey) -> Ciphertext:
    """
    Encrypt a single integer (constant polynomial).
    """
def gc_batch_compare(a_values: collections.abc.Sequence[typing.SupportsInt], b_values: collections.abc.Sequence[typing.SupportsInt], bit_width: typing.SupportsInt, ctx: Context) -> list[bool]:
    """
        Batch Garbled Circuit comparison.
    
        Compares a[i] > b[i] for all i using independent garbled circuits.
    
        Args:
            a_values: First set of values
            b_values: Second set of values
            bit_width: Bit width per value
            ctx: BFV context (for RNG)
    
        Returns:
            List of booleans (a[i] > b[i])
    """
def gc_bitonic_sort(values: collections.abc.Sequence[typing.SupportsInt], ctx: Context, bit_width: typing.SupportsInt = 17, ascending: bool = True, thread_count: typing.SupportsInt = 0) -> SortResult:
    """
        GC-based Bitonic Sort (non-interactive, multi-threaded).
    
        Uses Yao's Garbled Circuit for comparisons — no secret key needed
        during sorting (garbler prepares circuits offline).
        Multi-threaded execution: each thread gets independent GC instances.
    
        Args:
            values: Input values to sort
            ctx: BFV context (for RNG seed)
            bit_width: Bits per value (default: 17)
            ascending: Sort direction (default: True)
            thread_count: 0 = auto-detect hardware concurrency
    
        Returns:
            SortResult with sorted_values, timing, thread info
    """
def generate_keys(ctx: Context, decomp_base: typing.SupportsInt = 65536) -> tuple:
    """
        Generate full key set: (secret_key, public_key, relin_key).
    
        Args:
            ctx: BFV Context
            decomp_base: Decomposition base for relin key (default: 65536)
    
        Returns:
            Tuple of (SecretKey, PublicKey, RelinKey)
    """
def generate_public_key(ctx: Context, sk: SecretKey) -> PublicKey:
    """
    Generate public key from secret key.
    """
def generate_relin_key(ctx: Context, sk: SecretKey, decomp_base: typing.SupportsInt = 65536) -> RelinKey:
    """
    Generate relinearization key.
    """
def generate_secret_key(ctx: Context) -> SecretKey:
    """
    Generate secret key.
    """
def get_delta(ctx: Context) -> list[int]:
    """
    Get BFV scaling factor Δ = floor(q_i / t) for each RNS modulus.
    """
def he_insert_sorted(sorted_values: collections.abc.Sequence[typing.SupportsInt], new_values: collections.abc.Sequence[typing.SupportsInt], encoder: BatchEncoder, ctx: Context, pk: PublicKey, sk: SecretKey, config: InsertSortConfig = ...) -> InsertSortResult:
    """
        Insert new values into already-sorted encrypted data.
    
        FULL_RESORT only: Append + full re-sort via GC Bitonic / SIMD Radix.
        GC per-comparison cost (~0.018ms) is ~270x faster than HE (~32ms).
    
        Architecture: "Indexed Sorted Ciphertext Array (ISCA)"
          1. Initial sort: he_sort() → sorted array with implicit index [0..N-1]
          2. Retrieval by rank: O(1) — direct array access
          3. Search for value: gc_binary_search() → O(log N) GC comparisons
          4. Bulk insert: Append K values → FULL_RESORT (GC/Radix auto)
          5. Point insert: gc_binary_search → array insert → indices maintained
    
        Args:
            sorted_values: Pre-sorted array (ascending or descending)
            new_values: Unsorted values to insert
            encoder: BFV batch encoder
            ctx: BFV context
            pk: Public key
            sk: Secret key
            config: InsertSortConfig (strategy, bit_width, half_t, etc.)
    
        Returns:
            InsertSortResult with merged sorted_values and performance metrics
    """
def he_merge_sorted(sorted_a: collections.abc.Sequence[typing.SupportsInt], sorted_b: collections.abc.Sequence[typing.SupportsInt], ctx: Context, pk: PublicKey, sk: SecretKey, half_t: typing.SupportsInt = 32768) -> tuple:
    """
        Merge two sorted encrypted arrays using HE comparison.
    
        O(N+K) HE sub+decrypt comparisons. Both inputs must be pre-sorted
        in the same direction.
    
        Args:
            sorted_a: First sorted array
            sorted_b: Second sorted array
            ctx: BFV context
            pk: Public key
            sk: Secret key
            half_t: Sign threshold (default: t/2=32768)
    
        Returns:
            Tuple of (merged_sorted_values, n_he_ops)
    """
def he_sort(values: collections.abc.Sequence[typing.SupportsInt], encoder: BatchEncoder, ctx: Context, pk: PublicKey, sk: SecretKey, config: SortConfig = ...) -> SortResult:
    """
        Unified homomorphic sorting API — auto-selects optimal algorithm.
    
        - AUTO mode: N ≤ 10000 → GC Bitonic (non-interactive), else → Radix
        - Supports interactive (RADIX/BITONIC use sk) and non-interactive (GC_BITONIC)
        - Multi-threaded GC comparison for maximum throughput
    
        Args:
            values: Input unsigned integers to sort
            encoder: BFV batch encoder
            ctx: BFV context
            pk: Public key
            sk: Secret key
            config: SortConfig (algorithm, acceleration, ascending, bit_width, threads)
    
        Returns:
            SortResult with sorted_values, algorithm_used, acceleration_used, timing
    """
def insertion_sort_encrypted(values: collections.abc.Sequence[typing.SupportsInt], ctx: Context, pk: PublicKey, sk: SecretKey, half_t: typing.SupportsInt = 32768) -> SortResult:
    """
        Insertion sort with encrypted binary search.
    
        O(N × log N) comparisons. Incremental — can extend existing sorted array.
    
        Args:
            values: Input values
            ctx: BFV context
            pk: Public key
            sk: Secret key
            half_t: Half of plaintext modulus (sign threshold, default: 32768)
    
        Returns:
            SortResult with sorted values and metrics
    """
def multiply(ctx: Context, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
    """
        Homomorphic multiplication: ct1 * ct2.
    
        Result is size 3 — call relinearize() before further operations.
    """
def multiply_plain(ctx: Context, ct: Ciphertext, plaintext: collections.abc.Sequence[typing.SupportsInt]) -> Ciphertext:
    """
    Multiply ciphertext by plaintext: ct * pt.
    """
def multiply_relin(ctx: Context, ct1: Ciphertext, ct2: Ciphertext, rk: RelinKey) -> Ciphertext:
    """
        Multiply two ciphertexts and relinearize in one step.
    
        Equivalent to: relinearize(multiply(ct1, ct2), rk)
    """
def negate(ctx: Context, ct: Ciphertext) -> Ciphertext:
    """
    Negate ciphertext: -ct.
    """
def relinearize(ctx: Context, ct: Ciphertext, rk: RelinKey) -> Ciphertext:
    """
    Relinearize ciphertext from size 3 to size 2.
    """
def simd_radix_sort(values: collections.abc.Sequence[typing.SupportsInt], encoder: BatchEncoder, ctx: Context, pk: PublicKey, sk: SecretKey, bit_width: typing.SupportsInt = 17) -> SortResult:
    """
        SIMD Radix Sort (LSD, stable) for BFV-encrypted data.
    
        O(w) passes (w=bit_width). No comparison network overhead.
        Significantly faster than bitonic for large arrays.
    
        Args:
            values: Input values to sort
            encoder: BFV batch encoder
            ctx: BFV context
            pk: Public key
            sk: Secret key
            bit_width: Number of bits per value (default: 17 for t=65537)
    
        Returns:
            SortResult with sorted values and performance metrics
    """
def sub(ctx: Context, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
    """
    Homomorphic subtraction: ct1 - ct2.
    """
