"""

        _kctsb_core — Knight's Cryptographic Trusted Security Base (C++ core)
        =====================================================================

        Low-level C++ extension module providing:

        * **ckks** — CKKS approximate homomorphic encryption
          (keygen, encode/decode, encrypt/decrypt, homomorphic ops)

        * **dp** — Differential privacy noise mechanisms
          (Laplace, Gaussian, budget accounting)

        * **hcc** — Homomorphic Confidential Computing
          (6 scenarios: statistics, equality, comparison, sorting, blinding, DP noise)

        * **voprf** — RFC 9497 VOPRF (Verifiable Oblivious PRF)
          (P256-SHA256 blind evaluation with DLEQ proof)

        * **bfv** — BFV scale-invariant homomorphic encryption
          (exact integer arithmetic, Pure RNS, 128-bit security)

        * **bgv** — BGV leveled homomorphic encryption
          (exact integer arithmetic, noise management via modulus switching)

        * **psi** — Private Set Intersection protocols
          (Piano-PSI O(√n), OT-PSI IKNP/KKRT, simple baseline)

        * **pir** — FHE-based Private Information Retrieval
          (BGV ct*ct, BFV multiply_plain, CKKS approximate)

        * **upsi** — Unbalanced PSI & Searchable Encryption
          (Cuckoo+OPRF, Bloom PSI, SSE keyword search, OPE range queries)

        * **core** — Hardware acceleration & GPU detection
          (AVX2, AVX-512, CUDA detection, backend auto-selection)

        This is the internal backend. Use the high-level ``kctsb`` Python
        package for a friendlier API.
    
"""
from __future__ import annotations
from . import bfv
from . import bgv
from . import ckks
from . import core
from . import crypto
from . import dp
from . import hcc
from . import mpc
from . import pir
from . import psi
from . import sss
from . import upsi
from . import version
from . import voprf
__all__: list[str] = ['bfv', 'bgv', 'ckks', 'core', 'crypto', 'dp', 'hcc', 'mpc', 'pir', 'psi', 'sss', 'upsi', 'version', 'voprf']
__version__: str = '8.6.4'
