"""
Hardware acceleration detection, GPU management, backend selection
"""
from __future__ import annotations
import typing
__all__: list[str] = ['AES_NI', 'AVX2', 'AVX512', 'AVX512F', 'AVX512IFMA', 'AVX512VL', 'AccelBackend', 'AccelCaps', 'CUDA', 'GPUInfo', 'NONE', 'PCLMULQDQ', 'accel_detect', 'accel_status', 'backend_name', 'clear_force', 'detect_hardware', 'force_backend', 'gpu_count', 'gpu_info', 'has_cap', 'print_status', 'select_fhe_backend', 'select_ntt_backend']
class AccelBackend:
    """
    Hardware acceleration backend types
    
    Members:
    
      NONE : Scalar CPU (no acceleration)
    
      AVX2 : AVX2 CPU vectorization
    
      AVX512 : AVX-512 CPU vectorization
    
      CUDA : NVIDIA CUDA GPU
    """
    AVX2: typing.ClassVar[AccelBackend]  # value = <AccelBackend.AVX2: 1>
    AVX512: typing.ClassVar[AccelBackend]  # value = <AccelBackend.AVX512: 2>
    CUDA: typing.ClassVar[AccelBackend]  # value = <AccelBackend.CUDA: 3>
    NONE: typing.ClassVar[AccelBackend]  # value = <AccelBackend.NONE: 0>
    __members__: typing.ClassVar[dict[str, AccelBackend]]  # value = {'NONE': <AccelBackend.NONE: 0>, 'AVX2': <AccelBackend.AVX2: 1>, 'AVX512': <AccelBackend.AVX512: 2>, 'CUDA': <AccelBackend.CUDA: 3>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class AccelCaps:
    """
    Hardware capability flags (bitmask)
    
    Members:
    
      NONE
    
      AVX2
    
      AVX512F
    
      AVX512VL
    
      AVX512IFMA
    
      AES_NI
    
      PCLMULQDQ
    
      CUDA
    """
    AES_NI: typing.ClassVar[AccelCaps]  # value = <AccelCaps.AES_NI: 16>
    AVX2: typing.ClassVar[AccelCaps]  # value = <AccelCaps.AVX2: 1>
    AVX512F: typing.ClassVar[AccelCaps]  # value = <AccelCaps.AVX512F: 2>
    AVX512IFMA: typing.ClassVar[AccelCaps]  # value = <AccelCaps.AVX512IFMA: 8>
    AVX512VL: typing.ClassVar[AccelCaps]  # value = <AccelCaps.AVX512VL: 4>
    CUDA: typing.ClassVar[AccelCaps]  # value = <AccelCaps.CUDA: 256>
    NONE: typing.ClassVar[AccelCaps]  # value = <AccelCaps.NONE: 0>
    PCLMULQDQ: typing.ClassVar[AccelCaps]  # value = <AccelCaps.PCLMULQDQ: 32>
    __members__: typing.ClassVar[dict[str, AccelCaps]]  # value = {'NONE': <AccelCaps.NONE: 0>, 'AVX2': <AccelCaps.AVX2: 1>, 'AVX512F': <AccelCaps.AVX512F: 2>, 'AVX512VL': <AccelCaps.AVX512VL: 4>, 'AVX512IFMA': <AccelCaps.AVX512IFMA: 8>, 'AES_NI': <AccelCaps.AES_NI: 16>, 'PCLMULQDQ': <AccelCaps.PCLMULQDQ: 32>, 'CUDA': <AccelCaps.CUDA: 256>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class GPUInfo:
    """
    GPU device information
    """
    def __repr__(self) -> str:
        ...
    @property
    def compute_major(self) -> int:
        ...
    @property
    def compute_minor(self) -> int:
        ...
    @property
    def device_id(self) -> int:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def sm_count(self) -> int:
        ...
    @property
    def total_memory(self) -> int:
        ...
def accel_detect() -> int:
    """
        Detect all available hardware acceleration capabilities.
    
        Returns:
            Bitmask of detected capabilities (AccelCaps flags)
    """
def accel_status() -> str:
    """
    Get acceleration status as human-readable string.
    """
def backend_name(backend: AccelBackend) -> str:
    """
    Get human-readable name for an acceleration backend.
    """
def clear_force() -> None:
    """
    Clear forced backend, return to automatic selection.
    """
def detect_hardware() -> dict:
    """
        Detect hardware and return comprehensive summary dictionary.
    
        Returns:
            Dict with keys: avx2, avx512, aes_ni, cuda, gpu_count,
            gpu_name, gpu_memory_mb, fhe_backend, etc.
    """
def force_backend(backend: AccelBackend) -> None:
    """
    Force a specific backend (ignoring auto-detection).
    """
def gpu_count() -> int:
    """
    Get number of CUDA GPU devices available.
    """
def gpu_info(device_id: typing.SupportsInt = 0) -> typing.Any:
    """
        Get GPU device information.
    
        Args:
            device_id: CUDA device ID (default: 0)
    
        Returns:
            GPUInfo or None if not available
    """
def has_cap(cap: AccelCaps) -> bool:
    """
    Check if a specific hardware capability is available.
    """
def print_status() -> None:
    """
    Print acceleration capabilities to stdout.
    """
def select_fhe_backend(n: typing.SupportsInt, L: typing.SupportsInt) -> AccelBackend:
    """
    Select optimal backend for FHE operations.
    """
def select_ntt_backend(n: typing.SupportsInt, L: typing.SupportsInt) -> AccelBackend:
    """
    Select optimal backend for NTT operations based on problem size.
    """
AES_NI: AccelCaps  # value = <AccelCaps.AES_NI: 16>
AVX2: AccelCaps  # value = <AccelCaps.AVX2: 1>
AVX512: AccelBackend  # value = <AccelBackend.AVX512: 2>
AVX512F: AccelCaps  # value = <AccelCaps.AVX512F: 2>
AVX512IFMA: AccelCaps  # value = <AccelCaps.AVX512IFMA: 8>
AVX512VL: AccelCaps  # value = <AccelCaps.AVX512VL: 4>
CUDA: AccelCaps  # value = <AccelCaps.CUDA: 256>
NONE: AccelCaps  # value = <AccelCaps.NONE: 0>
PCLMULQDQ: AccelCaps  # value = <AccelCaps.PCLMULQDQ: 32>
