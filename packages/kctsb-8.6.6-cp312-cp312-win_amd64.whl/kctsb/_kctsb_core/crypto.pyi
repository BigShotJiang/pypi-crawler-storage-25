"""
kctsb atomic crypto primitives (hardware-accelerated: AES-NI / SHA-NI / AVX2 / CUDA when available).
"""
from __future__ import annotations
import typing
__all__: list[str] = ['AESGCM', 'ChaCha20Poly1305', 'hkdf_sha256', 'hmac_sha256', 'hmac_sha512', 'random_bytes', 'random_range', 'random_uint32', 'random_uint64', 'secure_compare', 'sha256', 'sha3_256', 'sha512']
class AESGCM:
    """
    AES-GCM AEAD cipher (AES-128/192/256, 12-byte nonce, 16-byte tag). API mirrors cryptography.hazmat.primitives.ciphers.aead.AESGCM.
    """
    @staticmethod
    def generate_key(bit_length: typing.SupportsInt = 256) -> bytes:
        ...
    def __init__(self, key: bytes) -> None:
        ...
    def decrypt(self, nonce: bytes, data: bytes, associated_data: typing.Any) -> bytes:
        """
        Decrypt ciphertext||tag; raises on authentication failure.
        """
    def encrypt(self, nonce: bytes, data: bytes, associated_data: typing.Any) -> bytes:
        """
        Encrypt `data` with `nonce` and optional AAD; returns ciphertext||tag.
        """
class ChaCha20Poly1305:
    """
    ChaCha20-Poly1305 AEAD (32-byte key, 12-byte nonce, 16-byte tag). RFC 8439.
    """
    @staticmethod
    def generate_key() -> bytes:
        ...
    def __init__(self, key: bytes) -> None:
        ...
    def decrypt(self, nonce: bytes, data: bytes, associated_data: typing.Any) -> bytes:
        ...
    def encrypt(self, nonce: bytes, data: bytes, associated_data: typing.Any) -> bytes:
        ...
def hkdf_sha256(ikm: bytes, salt: bytes, info: bytes, length: typing.SupportsInt) -> bytes:
    """
    HKDF-Extract-then-Expand with SHA-256 (RFC 5869)
    """
def hmac_sha256(key: bytes, data: bytes) -> bytes:
    """
    HMAC-SHA256 one-shot (RFC 2104)
    """
def hmac_sha512(key: bytes, data: bytes) -> bytes:
    """
    HMAC-SHA512 one-shot
    """
def random_bytes(n: typing.SupportsInt) -> bytes:
    """
    Cryptographically secure random bytes (platform CSPRNG)
    """
def random_range(max: typing.SupportsInt) -> int:
    """
    Uniform random uint32_t in [0, max)
    """
def random_uint32() -> int:
    """
    Secure random uint32_t
    """
def random_uint64() -> int:
    """
    Secure random uint64_t
    """
def secure_compare(a: bytes, b: bytes) -> bool:
    """
    Constant-time byte comparison (timing-attack resistant)
    """
def sha256(data: bytes) -> bytes:
    """
    SHA-256 one-shot (SHA-NI accelerated)
    """
def sha3_256(data: bytes) -> bytes:
    """
    SHA-3-256 one-shot (FIPS 202 Keccak)
    """
def sha512(data: bytes) -> bytes:
    """
    SHA-512 one-shot
    """
