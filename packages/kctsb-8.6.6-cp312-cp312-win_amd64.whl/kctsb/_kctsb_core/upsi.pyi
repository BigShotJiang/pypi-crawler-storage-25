"""
Unbalanced PSI, Searchable Encryption (SSE), Order-Preserving Encryption (OPE)
"""
from __future__ import annotations
import collections.abc
import typing
__all__: list[str] = ['BLOOM_PSI', 'CUCKOO_OPRF', 'OPE', 'OPEResult', 'PARTITION_OT', 'SSE', 'SSEIndexEntry', 'SSESearchResult', 'UPSIConfig', 'UPSIResult', 'UPSIStrategy', 'UnbalancedPSI', 'unbalanced_psi']
class OPE:
    """
    
            Order-Preserving Encryption (OPE)
    
            Encrypts integers while preserving their order.
            Enables range queries on encrypted data.
    
            Example::
    
                ope = kctsb.upsi.OPE()
                ope.keygen()
                result = ope.encrypt([10, 20, 30])
                assert result.order_preserved  # ct[0] < ct[1] < ct[2]
            
    """
    def __init__(self) -> None:
        ...
    def decrypt(self, ciphertext: typing.SupportsInt) -> int:
        """
        Decrypt a single OPE ciphertext
        """
    def encrypt(self, plaintexts: collections.abc.Sequence[typing.SupportsInt]) -> OPEResult:
        """
        Encrypt integers preserving order
        """
    def keygen(self) -> None:
        """
        Generate OPE key
        """
class OPEResult:
    """
    OPE encryption result
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def ciphertexts(self) -> list[int]:
        ...
    @property
    def encrypt_time_ms(self) -> float:
        ...
    @property
    def order_preserved(self) -> bool:
        ...
class SSE:
    """
    
            Symmetric Searchable Encryption (SSE)
    
            Encrypted keyword search over ciphertext databases.
            Server stores encrypted index; client generates search tokens.
    
            Example::
    
                sse = kctsb.upsi.SSE()
                sse.keygen()
                sse.build_index([
                    kctsb.upsi.SSEIndexEntry("hello", 1),
                    kctsb.upsi.SSEIndexEntry("world", 2),
                    kctsb.upsi.SSEIndexEntry("hello", 3),
                ])
                result = sse.search("hello")  # → doc_ids: [1, 3]
            
    """
    def __init__(self) -> None:
        ...
    def build_index(self, entries: collections.abc.Sequence[SSEIndexEntry]) -> None:
        """
        Build encrypted index from keyword-doc pairs
        """
    def has_index(self) -> bool:
        """
        Check if index is built
        """
    def keygen(self) -> None:
        """
        Generate encryption key
        """
    def search(self, keyword: str) -> SSESearchResult:
        """
        Search for keyword in encrypted index
        """
class SSEIndexEntry:
    """
    A keyword-document pair for SSE index
    """
    keyword: str
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, keyword: str, doc_id: typing.SupportsInt) -> None:
        ...
    @property
    def doc_id(self) -> int:
        ...
    @doc_id.setter
    def doc_id(self, arg0: typing.SupportsInt) -> None:
        ...
class SSESearchResult:
    """
    SSE search result
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def doc_ids(self) -> list[int]:
        ...
    @property
    def keyword(self) -> str:
        ...
    @property
    def search_time_ms(self) -> float:
        ...
class UPSIConfig:
    """
    Configuration for Unbalanced PSI
    """
    enable_preprocessing: bool
    strategy: UPSIStrategy
    def __init__(self) -> None:
        ...
    @property
    def bloom_fpr(self) -> float:
        ...
    @bloom_fpr.setter
    def bloom_fpr(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def max_cuckoo_iterations(self) -> int:
        ...
    @max_cuckoo_iterations.setter
    def max_cuckoo_iterations(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def num_hash_functions(self) -> int:
        ...
    @num_hash_functions.setter
    def num_hash_functions(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def partition_count(self) -> int:
        ...
    @partition_count.setter
    def partition_count(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def security_parameter(self) -> int:
        ...
    @security_parameter.setter
    def security_parameter(self, arg0: typing.SupportsInt) -> None:
        ...
class UPSIResult:
    """
    Result of Unbalanced PSI computation
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def client_comm_bytes(self) -> int:
        ...
    @property
    def client_time_ms(self) -> float:
        ...
    @property
    def error_message(self) -> str:
        ...
    @property
    def intersection(self) -> list[int]:
        ...
    @property
    def is_correct(self) -> bool:
        ...
    @property
    def server_comm_bytes(self) -> int:
        ...
    @property
    def server_time_ms(self) -> float:
        ...
    @property
    def total_comm_bytes(self) -> int:
        ...
    @property
    def total_time_ms(self) -> float:
        ...
class UPSIStrategy:
    """
    Unbalanced PSI protocol strategy
    
    Members:
    
      CUCKOO_OPRF : Cuckoo hash + OPRF (optimal for tiny client set)
    
      BLOOM_PSI : Bloom filter based (fast, slight FPR)
    
      PARTITION_OT : Partition + OT Extension (balanced)
    """
    BLOOM_PSI: typing.ClassVar[UPSIStrategy]  # value = <UPSIStrategy.BLOOM_PSI: 1>
    CUCKOO_OPRF: typing.ClassVar[UPSIStrategy]  # value = <UPSIStrategy.CUCKOO_OPRF: 0>
    PARTITION_OT: typing.ClassVar[UPSIStrategy]  # value = <UPSIStrategy.PARTITION_OT: 2>
    __members__: typing.ClassVar[dict[str, UPSIStrategy]]  # value = {'CUCKOO_OPRF': <UPSIStrategy.CUCKOO_OPRF: 0>, 'BLOOM_PSI': <UPSIStrategy.BLOOM_PSI: 1>, 'PARTITION_OT': <UPSIStrategy.PARTITION_OT: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class UnbalancedPSI:
    """
    
            Unbalanced PSI for asymmetric set sizes (|client| << |server|)
    
            Three strategies:
            - CUCKOO_OPRF: Optimal for very small client (< 1% of server)
            - BLOOM_PSI: Fast approximation with configurable FPR
            - PARTITION_OT: Balanced for moderate asymmetry
    
            Example::
    
                upsi = kctsb.upsi.UnbalancedPSI()
                result = upsi.compute([1, 2, 3], list(range(100000)))
            
    """
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, config: UPSIConfig) -> None:
        ...
    def compute(self, client_set: collections.abc.Sequence[typing.SupportsInt], server_set: collections.abc.Sequence[typing.SupportsInt]) -> UPSIResult:
        """
        Compute unbalanced PSI between client and server sets
        """
def unbalanced_psi(client_set: collections.abc.Sequence[typing.SupportsInt], server_set: collections.abc.Sequence[typing.SupportsInt], strategy: UPSIStrategy = ...) -> UPSIResult:
    """
            Quick unbalanced PSI computation
    
            Args:
                client_set: Small client set
                server_set: Large server set
                strategy: Protocol strategy (default: CUCKOO_OPRF)
    
            Returns:
                UPSIResult with intersection and metrics
    """
BLOOM_PSI: UPSIStrategy  # value = <UPSIStrategy.BLOOM_PSI: 1>
CUCKOO_OPRF: UPSIStrategy  # value = <UPSIStrategy.CUCKOO_OPRF: 0>
PARTITION_OT: UPSIStrategy  # value = <UPSIStrategy.PARTITION_OT: 2>
