"""
kctsb version information
"""
from __future__ import annotations
__all__: list[str] = ['release_date', 'string']
release_date: str = '2026-02-10'
string: str = '8.6.4'
