"""
Shamir's (t,n) Secret Sharing over GF(2^8)
"""
from __future__ import annotations
import collections.abc
import typing
__all__: list[str] = ['ShamirSSS', 'Share']
class ShamirSSS:
    """
    
            Shamir's (t,n) Secret Sharing over GF(2^8)
    
            Information-theoretically secure threshold scheme. Any t shares
            reconstruct the secret; fewer than t shares reveal nothing.
    
            All methods are static — no instance state required.
    
            Example::
    
                shares = ShamirSSS.split(b"AES-256 key bytes...", threshold=3, num_shares=5)
                secret = ShamirSSS.reconstruct(shares[:3], secret_len=len(original))
            
    """
    @staticmethod
    def reconstruct(shares: collections.abc.Sequence[Share], secret_len: typing.SupportsInt) -> bytes:
        """
                    Reconstruct a secret from Shamir shares via Lagrange interpolation.
        
                    Args:
                        shares: List of Share objects (>= threshold)
                        secret_len: Expected secret length in bytes
        
                    Returns:
                        Reconstructed secret as bytes
        """
    @staticmethod
    def split(secret: bytes, threshold: typing.SupportsInt, num_shares: typing.SupportsInt) -> list[Share]:
        """
                    Split a secret into (t,n) Shamir shares.
        
                    Args:
                        secret: Secret bytes to split (1-4096 bytes)
                        threshold: Minimum shares for reconstruction (2-255)
                        num_shares: Total shares to produce (threshold-255)
        
                    Returns:
                        List of Share objects
        """
class Share:
    """
    A single Shamir share (index + data bytes)
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def data(self) -> list[int]:
        """
        Share payload bytes
        """
    @data.setter
    def data(self, arg0: collections.abc.Sequence[typing.SupportsInt]) -> None:
        ...
    @property
    def index(self) -> int:
        """
        GF(2^8) evaluation point (1-255)
        """
    @index.setter
    def index(self, arg0: typing.SupportsInt) -> None:
        ...
