"""
FHE-based Private Information Retrieval — BGV/BFV/CKKS
"""
from __future__ import annotations
import collections.abc
import typing
__all__: list[str] = ['BFV', 'BGV', 'CKKS', 'NativePIR', 'PIRConfig', 'PIRResult', 'PIRScheme', 'pir_query']
class NativePIR:
    """
    
            Native FHE-based Private Information Retrieval
    
            Supports three FHE schemes:
            - BGV: Exact integer PIR using ct*ct multiplication
            - BFV: Exact integer PIR using multiply_plain (recommended, fastest)
            - CKKS: Approximate PIR for floating-point databases
    
            The database is loaded at construction time. Use query() with a
            target index to perform private retrieval.
    
            Example::
    
                config = kctsb.pir.PIRConfig()
                config.scheme = kctsb.pir.PIRScheme.BFV
                db = list(range(100))
                pir = kctsb.pir.NativePIR(config, db)
                result = pir.query(42)
                print(f"Retrieved: {result.retrieved_int64}")
            
    """
    @typing.overload
    def __init__(self, config: PIRConfig, database: collections.abc.Sequence[typing.SupportsInt]) -> None:
        """
        Create NativePIR for integer database
        """
    @typing.overload
    def __init__(self, config: PIRConfig, database: collections.abc.Sequence[typing.SupportsFloat]) -> None:
        """
        Create NativePIR for double database (CKKS)
        """
    def batch_query(self, indices: collections.abc.Sequence[typing.SupportsInt]) -> list[PIRResult]:
        """
                     Execute batch PIR queries for multiple indices
        
                     Args:
                         indices: List of target indices to retrieve
        
                     Returns:
                         List of PIRResult for each queried index
        """
    def query(self, target_index: typing.SupportsInt) -> PIRResult:
        """
                     Execute a single PIR query
        
                     Args:
                         target_index: Index of the element to retrieve privately
        
                     Returns:
                         PIRResult with retrieved value and performance metrics
        """
class PIRConfig:
    """
    Configuration for Native PIR query
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def batch_size(self) -> int:
        """
        Elements per batch (0=auto)
        """
    @batch_size.setter
    def batch_size(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def ckks_scale(self) -> float:
        """
        CKKS encoding scale (default 2^40)
        """
    @ckks_scale.setter
    def ckks_scale(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def database_size(self) -> int:
        """
        Number of elements in the database
        """
    @database_size.setter
    def database_size(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def element_size_bytes(self) -> int:
        """
        Size of each element in bytes
        """
    @element_size_bytes.setter
    def element_size_bytes(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def enable_batching(self) -> bool:
        """
        Enable SIMD batching
        """
    @enable_batching.setter
    def enable_batching(self, arg0: bool) -> None:
        ...
    @property
    def enable_sqrt_decomposition(self) -> bool:
        """
        Enable O(sqrt(n)) communication optimization
        """
    @enable_sqrt_decomposition.setter
    def enable_sqrt_decomposition(self, arg0: bool) -> None:
        ...
    @property
    def modulus_bits(self) -> int:
        """
        Bits per RNS modulus (30-60)
        """
    @modulus_bits.setter
    def modulus_bits(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def num_moduli(self) -> int:
        """
        RNS chain length L
        """
    @num_moduli.setter
    def num_moduli(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def plaintext_modulus(self) -> int:
        """
        Plaintext modulus for BGV/BFV (e.g. 65537)
        """
    @plaintext_modulus.setter
    def plaintext_modulus(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def poly_modulus_degree(self) -> int:
        """
        Polynomial modulus degree (power of 2, e.g. 4096, 8192)
        """
    @poly_modulus_degree.setter
    def poly_modulus_degree(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def scheme(self) -> PIRScheme:
        """
        FHE scheme (BGV/BFV/CKKS)
        """
    @scheme.setter
    def scheme(self, arg0: PIRScheme) -> None:
        ...
class PIRResult:
    """
    Result of a PIR query
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    @property
    def client_time_ms(self) -> float:
        """
        Client decryption time (ms)
        """
    @property
    def communication_bytes(self) -> int:
        """
        Total communication overhead (bytes)
        """
    @property
    def error_message(self) -> str:
        """
        Error message if any
        """
    @property
    def is_correct(self) -> bool:
        """
        Whether retrieval matched expected value
        """
    @property
    def noise_budget_bits(self) -> int:
        """
        Remaining noise budget (bits)
        """
    @property
    def query_index(self) -> int:
        """
        Queried index
        """
    @property
    def query_time_ms(self) -> float:
        """
        Query generation time (ms)
        """
    @property
    def retrieved_data(self) -> list[int]:
        """
        Retrieved raw data bytes
        """
    @property
    def retrieved_double(self) -> float:
        """
        Retrieved float value (CKKS)
        """
    @property
    def retrieved_int64(self) -> int:
        """
        Retrieved value as int64 (from raw data)
        """
    @property
    def server_time_ms(self) -> float:
        """
        Server processing time (ms)
        """
class PIRScheme:
    """
    FHE scheme for Private Information Retrieval
    
    Members:
    
      BGV : BGV exact integer PIR (ct*ct multiply)
    
      BFV : BFV PIR with multiply_plain (recommended)
    
      CKKS : CKKS approximate PIR for float databases
    """
    BFV: typing.ClassVar[PIRScheme]  # value = <PIRScheme.BFV: 1>
    BGV: typing.ClassVar[PIRScheme]  # value = <PIRScheme.BGV: 0>
    CKKS: typing.ClassVar[PIRScheme]  # value = <PIRScheme.CKKS: 2>
    __members__: typing.ClassVar[dict[str, PIRScheme]]  # value = {'BGV': <PIRScheme.BGV: 0>, 'BFV': <PIRScheme.BFV: 1>, 'CKKS': <PIRScheme.CKKS: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
def pir_query(database: collections.abc.Sequence[typing.SupportsInt], target_index: typing.SupportsInt, scheme: PIRScheme = ..., poly_degree: typing.SupportsInt = 4096) -> PIRResult:
    """
            Quick PIR query (convenience function)
    
            Args:
                database: List of integer values
                target_index: Index to retrieve privately
                scheme: FHE scheme (default: BFV)
                poly_degree: Polynomial degree (default: 4096)
    
            Returns:
                PIRResult with retrieved value
    
            Example::
    
                result = kctsb.pir.pir_query([10, 20, 30, 40], target_index=2)
                assert result.retrieved_int64 == 30
    """
BFV: PIRScheme  # value = <PIRScheme.BFV: 1>
BGV: PIRScheme  # value = <PIRScheme.BGV: 0>
CKKS: PIRScheme  # value = <PIRScheme.CKKS: 2>
