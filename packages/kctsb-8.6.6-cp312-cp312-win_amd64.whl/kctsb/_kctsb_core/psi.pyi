"""
Private Set Intersection — Piano-PSI, OT-PSI (IKNP/KKRT)
"""
from __future__ import annotations
import collections.abc
import typing
__all__: list[str] = ['OTConfig', 'OTPSI', 'OTResult', 'OTVariant', 'PianoConfig', 'PianoPSI', 'PianoResult', 'ot_psi', 'piano_psi', 'simple_intersection']
class OTConfig:
    """
    
            Configuration for OT-based PSI.
    
            Default uses IKNP OT Extension with 128-bit security.
            
    """
    def __init__(self) -> None:
        ...
    @property
    def enable_balanced_psi(self) -> bool:
        """
        Both parties learn result (default: false)
        """
    @enable_balanced_psi.setter
    def enable_balanced_psi(self, arg0: bool) -> None:
        ...
    @property
    def enable_malicious_security(self) -> bool:
        """
        Enable malicious security (default: false)
        """
    @enable_malicious_security.setter
    def enable_malicious_security(self, arg0: bool) -> None:
        ...
    @property
    def hash_table_size(self) -> int:
        """
        Cuckoo hash table size (0 = auto)
        """
    @hash_table_size.setter
    def hash_table_size(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def num_hash_functions(self) -> int:
        """
        Number of hash functions (default: 3)
        """
    @num_hash_functions.setter
    def num_hash_functions(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def ot_batch_size(self) -> int:
        """
        OT batch size (default: 1024)
        """
    @ot_batch_size.setter
    def ot_batch_size(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def security_parameter(self) -> int:
        """
        Security parameter in bits (default: 128)
        """
    @security_parameter.setter
    def security_parameter(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def variant(self) -> OTVariant:
        """
        OT protocol variant (default: EXTENSION)
        """
    @variant.setter
    def variant(self, arg0: OTVariant) -> None:
        ...
class OTPSI:
    """
    
            OT-based Private Set Intersection.
    
            Uses Oblivious Transfer extension (IKNP/KKRT) for PSI computation.
            Communication complexity: O(|X| + |Y|).
    
            Example::
    
                ot_psi = kctsb.psi.OTPSI()
                result = ot_psi.compute([1, 2, 3], [2, 3, 4])
                print(result.intersection_elements)  # [2, 3]
            
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Create OTPSI with default configuration (IKNP, 128-bit).
        """
    @typing.overload
    def __init__(self, config: OTConfig) -> None:
        """
        Create OTPSI with custom configuration.
        """
    def compute(self, client_set: collections.abc.Sequence[typing.SupportsInt], server_set: collections.abc.Sequence[typing.SupportsInt]) -> OTResult:
        """
                    Compute OT-based private set intersection.
        
                    Args:
                        client_set: Client's input list of integers
                        server_set: Server's input list of integers
        
                    Returns:
                        OTResult with intersection, timing breakdown, and OT statistics
        """
class OTResult:
    """
    Result of OT-PSI computation with detailed timing breakdown.
    """
    def __repr__(self) -> str:
        ...
    @property
    def communication_bytes(self) -> int:
        """
        Total communication overhead (bytes)
        """
    @property
    def error_message(self) -> str:
        """
        Error description (empty if success)
        """
    @property
    def execution_time_ms(self) -> float:
        """
        Total execution time (ms)
        """
    @property
    def intersection_elements(self) -> list[int]:
        """
        List of intersection elements
        """
    @property
    def intersection_size(self) -> int:
        """
        Intersection cardinality
        """
    @property
    def is_correct(self) -> bool:
        """
        Verification flag
        """
    @property
    def ot_count(self) -> int:
        """
        Number of OTs executed
        """
    @property
    def ot_execution_time_ms(self) -> float:
        """
        OT execution phase time (ms)
        """
    @property
    def ot_setup_time_ms(self) -> float:
        """
        OT setup phase time (ms)
        """
    @property
    def psi_compute_time_ms(self) -> float:
        """
        PSI computation time (ms)
        """
class OTVariant:
    """
    Oblivious Transfer protocol variant selection.
    
    Members:
    
      NAIVE : Naive 1-out-of-2 OT
    
      EXTENSION : IKNP OT Extension (recommended)
    
      KKRT : KKRT PSI-specific protocol
    """
    EXTENSION: typing.ClassVar[OTVariant]  # value = <OTVariant.EXTENSION: 1>
    KKRT: typing.ClassVar[OTVariant]  # value = <OTVariant.KKRT: 2>
    NAIVE: typing.ClassVar[OTVariant]  # value = <OTVariant.NAIVE: 0>
    __members__: typing.ClassVar[dict[str, OTVariant]]  # value = {'NAIVE': <OTVariant.NAIVE: 0>, 'EXTENSION': <OTVariant.EXTENSION: 1>, 'KKRT': <OTVariant.KKRT: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class PianoConfig:
    """
    
            Configuration for Piano-PSI protocol.
    
            Piano-PSI achieves sublinear O(√n) communication complexity.
            Default values provide 128-bit security with batch optimization.
            
    """
    def __init__(self) -> None:
        ...
    @property
    def bucket_size(self) -> int:
        """
        Bucket size for overflow handling (default: 8)
        """
    @bucket_size.setter
    def bucket_size(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def enable_batch_optimization(self) -> bool:
        """
        Enable batched query processing (default: true)
        """
    @enable_batch_optimization.setter
    def enable_batch_optimization(self, arg0: bool) -> None:
        ...
    @property
    def hash_table_size(self) -> int:
        """
        Hash table size (0 = auto-calculate based on set sizes)
        """
    @hash_table_size.setter
    def hash_table_size(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def load_factor_threshold(self) -> float:
        """
        Target hash table load factor (default: 0.75)
        """
    @load_factor_threshold.setter
    def load_factor_threshold(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def malicious_security(self) -> bool:
        """
        Enable malicious security mode (default: false)
        """
    @malicious_security.setter
    def malicious_security(self, arg0: bool) -> None:
        ...
    @property
    def max_cuckoo_iterations(self) -> int:
        """
        Max iterations for Cuckoo hashing (default: 20)
        """
    @max_cuckoo_iterations.setter
    def max_cuckoo_iterations(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def min_query_batch_size(self) -> int:
        """
        Minimum batch size for queries (default: 32)
        """
    @min_query_batch_size.setter
    def min_query_batch_size(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def num_hash_functions(self) -> int:
        """
        Number of Cuckoo hash functions (default: 4)
        """
    @num_hash_functions.setter
    def num_hash_functions(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def query_all_positions(self) -> bool:
        """
        Query ALL positions for full intersection; disable for O(sqrt n) sublinear mode (default: false)
        """
    @query_all_positions.setter
    def query_all_positions(self, arg0: bool) -> None:
        ...
    @property
    def statistical_security(self) -> float:
        """
        Statistical security parameter in bits (default: 128)
        """
    @statistical_security.setter
    def statistical_security(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def sublinear_factor(self) -> int:
        """
        √n factor for sublinear communication (default: 3)
        """
    @sublinear_factor.setter
    def sublinear_factor(self, arg0: typing.SupportsInt) -> None:
        ...
class PianoPSI:
    """
    
            Piano-PSI: Sublinear communication Private Set Intersection.
    
            Achieves O(√n) communication complexity vs O(n) for standard PSI.
            Uses Cuckoo hashing and batch query optimization.
    
            Example::
    
                psi = kctsb.psi.PianoPSI()
                result = psi.compute([1, 2, 3, 4, 5], [3, 4, 5, 6, 7])
                print(result.intersection)  # [3, 4, 5]
            
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Create PianoPSI with default configuration.
        """
    @typing.overload
    def __init__(self, config: PianoConfig) -> None:
        """
        Create PianoPSI with custom configuration.
        """
    def compute(self, client_set: collections.abc.Sequence[typing.SupportsInt], server_set: collections.abc.Sequence[typing.SupportsInt]) -> PianoResult:
        """
                    Compute private set intersection.
        
                    Args:
                        client_set: Client's input list of integers
                        server_set: Server's input list of integers
        
                    Returns:
                        PianoResult with intersection, timing, and communication stats
        """
class PianoResult:
    """
    Result of Piano-PSI computation with timing and communication metrics.
    """
    def __repr__(self) -> str:
        ...
    @property
    def client_time_ms(self) -> float:
        """
        Client-side processing time (ms)
        """
    @property
    def communication_bytes(self) -> float:
        """
        Communication overhead (bytes)
        """
    @property
    def error_message(self) -> str:
        """
        Error description (empty if success)
        """
    @property
    def execution_time_ms(self) -> float:
        """
        Total execution time (ms)
        """
    @property
    def hash_table_load_factor(self) -> float:
        """
        Actual hash table load factor
        """
    @property
    def intersection(self) -> list[int]:
        """
        List of elements in the intersection
        """
    @property
    def is_correct(self) -> bool:
        """
        Verification result
        """
    @property
    def server_time_ms(self) -> float:
        """
        Server-side processing time (ms)
        """
def ot_psi(client_set: collections.abc.Sequence[typing.SupportsInt], server_set: collections.abc.Sequence[typing.SupportsInt], variant: OTVariant = ...) -> OTResult:
    """
        One-shot OT-PSI computation.
    
        Args:
            client_set: Client's input list of integers
            server_set: Server's input list of integers
            variant: OT variant (default: EXTENSION / IKNP)
    
        Returns:
            OTResult with intersection and OT metrics
    """
def piano_psi(client_set: collections.abc.Sequence[typing.SupportsInt], server_set: collections.abc.Sequence[typing.SupportsInt], query_all: bool = True) -> PianoResult:
    """
        One-shot Piano-PSI computation.
    
        Convenience function — creates a PianoPSI instance internally.
        By default, queries ALL positions for full intersection (query_all=True).
        Set query_all=False for sublinear O(√n) communication mode (samples only).
    
        Args:
            client_set: Client's input list of integers
            server_set: Server's input list of integers
            query_all: If True (default), find complete intersection.
                       If False, use sublinear sampling (returns partial intersection).
    
        Returns:
            PianoResult with intersection and metrics
    """
def simple_intersection(set1: collections.abc.Sequence[typing.SupportsInt], set2: collections.abc.Sequence[typing.SupportsInt]) -> list[int]:
    """
            Compute plain (non-private) set intersection.
    
            Uses hash-based algorithm — O(n) time, no privacy guarantee.
            Useful as baseline for benchmarking PSI protocols.
    
            Args:
                set1: First list of integers
                set2: Second list of integers
    
            Returns:
                List of common elements
    """
