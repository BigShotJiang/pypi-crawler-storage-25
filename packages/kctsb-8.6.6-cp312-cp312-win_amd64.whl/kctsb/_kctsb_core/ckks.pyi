"""
CKKS approximate homomorphic encryption over RNS polynomials
"""
from __future__ import annotations
import collections.abc
import typing
__all__: list[str] = ['Ciphertext', 'Context', 'Plaintext', 'PublicKey', 'RelinKey', 'SecretKey']
class Ciphertext:
    """
    
            CKKS ciphertext — encrypted polynomial pair.
    
            Properties
            ----------
            scale : float
                Current scaling factor.
            level : int
                Current modulus level.
            size : int
                Number of polynomial components (2 = standard, 3 = after multiply).
            
    """
    def __repr__(self) -> str:
        ...
    @property
    def level(self) -> int:
        """
        Current modulus level.
        """
    @property
    def scale(self) -> float:
        """
        Scaling factor.
        """
    @property
    def size(self) -> int:
        """
        Number of polynomial components.
        """
class Context:
    """
    
            CKKS encryption context.
    
            Manages all internal state (RNS moduli, NTT tables, evaluator,
            encoder, PRNG).  Every key, plaintext, and ciphertext produced
            by this context holds a shared reference, so the context is
            kept alive automatically.
    
            Parameters
            ----------
            poly_modulus_degree : int
                Ring dimension *n* (must be a power of two, e.g. 4096, 8192).
            coeff_modulus_levels : int
                Number of RNS primes in the modulus chain.
            scale_bits : float
                Log₂ of the CKKS scaling factor (e.g. 40.0).
    
            Examples
            --------
            >>> ctx = Context(poly_modulus_degree=8192,
            ...               coeff_modulus_levels=5,
            ...               scale_bits=40.0)
            >>> ctx.slot_count
            4096
            
    """
    def __init__(self, poly_modulus_degree: typing.SupportsInt, coeff_modulus_levels: typing.SupportsInt, scale_bits: typing.SupportsFloat) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def add(self, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
        """
                Homomorphic addition of two ciphertexts.
        
                Parameters
                ----------
                ct1 : Ciphertext
                ct2 : Ciphertext
        
                Returns
                -------
                Ciphertext
                    Encryption of (m1 + m2).
        """
    def add_plain(self, ct: Ciphertext, pt: Plaintext) -> Ciphertext:
        """
                Add a plaintext to a ciphertext.
        
                Parameters
                ----------
                ct : Ciphertext
                pt : Plaintext
        
                Returns
                -------
                Ciphertext
        """
    def decode(self, pt: Plaintext) -> list[float]:
        """
                Decode a plaintext back to a list of real numbers.
        
                Parameters
                ----------
                pt : Plaintext
        
                Returns
                -------
                list[float]
                    Decoded real-valued message vector (length = slot_count).
        """
    def decrypt(self, sk: SecretKey, ct: Ciphertext) -> Plaintext:
        """
                Decrypt a ciphertext with the secret key.
        
                Parameters
                ----------
                sk : SecretKey
                ct : Ciphertext
        
                Returns
                -------
                Plaintext
        """
    def encode(self, values: collections.abc.Sequence[typing.SupportsFloat]) -> Plaintext:
        """
                Encode a list of real numbers into a CKKS plaintext.
        
                Parameters
                ----------
                values : list[float]
                    Real-valued message vector (length ≤ slot_count).
        
                Returns
                -------
                Plaintext
        """
    def encode_single(self, value: typing.SupportsFloat, scale: typing.SupportsFloat = 0.0) -> Plaintext:
        """
                Encode a single real number, broadcast to all slots.
        
                Parameters
                ----------
                value : float
                    The value to encode.
                scale : float, optional
                    Encoding scale. If 0 (default), uses the context's default
                    scale (2^scale_bits).  For add_plain after chained operations,
                    pass the ciphertext's current scale to avoid mismatch.
        
                Returns
                -------
                Plaintext
        """
    def encrypt(self, pk: PublicKey, pt: Plaintext) -> Ciphertext:
        """
                Encrypt a plaintext with a public key.
        
                Parameters
                ----------
                pk : PublicKey
                pt : Plaintext
        
                Returns
                -------
                Ciphertext
        """
    def encrypt_symmetric(self, sk: SecretKey, pt: Plaintext) -> Ciphertext:
        """
                Symmetric encryption using the secret key (faster, smaller).
        
                Parameters
                ----------
                sk : SecretKey
                pt : Plaintext
        
                Returns
                -------
                Ciphertext
        """
    def keygen(self) -> SecretKey:
        """
                Generate a fresh CKKS secret key.
        
                Returns
                -------
                SecretKey
                    Ternary secret key polynomial.
        """
    def multiply(self, ct1: Ciphertext, ct2: Ciphertext, rk: RelinKey) -> Ciphertext:
        """
                Homomorphic multiplication with relinearization and rescaling.
        
                Performs multiply → relinearize → rescale in a single call,
                which is the standard pattern for CKKS multiplication.
        
                Parameters
                ----------
                ct1 : Ciphertext
                ct2 : Ciphertext
                rk  : RelinKey
        
                Returns
                -------
                Ciphertext
                    Encryption of (m1 · m2), rescaled.
        """
    def multiply_plain(self, ct: Ciphertext, pt: Plaintext) -> Ciphertext:
        """
                Multiply a ciphertext by a plaintext (no relin needed).
        
                Parameters
                ----------
                ct : Ciphertext
                pt : Plaintext
        
                Returns
                -------
                Ciphertext
        """
    def public_key(self, sk: SecretKey) -> PublicKey:
        """
                Derive a public key from the given secret key.
        
                Parameters
                ----------
                sk : SecretKey
                    Previously generated secret key.
        
                Returns
                -------
                PublicKey
        """
    def relin_key(self, sk: SecretKey) -> RelinKey:
        """
                Generate a relinearization key from the secret key.
        
                Parameters
                ----------
                sk : SecretKey
        
                Returns
                -------
                RelinKey
        """
    def rescale(self, ct: Ciphertext) -> Ciphertext:
        """
                Rescale a ciphertext (divide scale by the last prime).
        
                Use this after multiply_plain when the scale has doubled.
        
                Parameters
                ----------
                ct : Ciphertext
        
                Returns
                -------
                Ciphertext
                    Rescaled ciphertext at one lower level.
        """
    def sub(self, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
        """
                Homomorphic subtraction of two ciphertexts.
        
                Parameters
                ----------
                ct1 : Ciphertext
                ct2 : Ciphertext
        
                Returns
                -------
                Ciphertext
                    Encryption of (m1 - m2).
        """
    @property
    def poly_modulus_degree(self) -> int:
        """
        Ring dimension n.
        """
    @property
    def scale(self) -> float:
        """
        Default scaling factor (2^scale_bits).
        """
    @property
    def slot_count(self) -> int:
        """
        Number of CKKS plaintext slots (n / 2).
        """
class Plaintext:
    """
    
            CKKS plaintext — encoded polynomial ready for encryption.
    
            Properties
            ----------
            scale : float
                Scaling factor applied during encoding.
            level : int
                Current modulus level.
            
    """
    def __repr__(self) -> str:
        ...
    @property
    def level(self) -> int:
        """
        Current modulus level.
        """
    @property
    def scale(self) -> float:
        """
        Scaling factor.
        """
class PublicKey:
    """
    CKKS public key (RLWE sample).
    """
    def __repr__(self) -> str:
        ...
class RelinKey:
    """
    CKKS relinearization key for ciphertext degree reduction.
    """
    def __repr__(self) -> str:
        ...
class SecretKey:
    """
    CKKS secret key (ternary polynomial).
    """
    def __repr__(self) -> str:
        ...
