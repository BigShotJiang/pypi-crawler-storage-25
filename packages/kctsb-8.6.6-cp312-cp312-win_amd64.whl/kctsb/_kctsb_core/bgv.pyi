"""
BGV leveled homomorphic encryption — exact integer, noise management
"""
from __future__ import annotations
import collections.abc
import typing
__all__: list[str] = ['Ciphertext', 'Context', 'GaloisKeys', 'PublicKey', 'RelinKey', 'SecretKey', 'add', 'context_n16384', 'context_n4096', 'context_n8192', 'decrypt', 'decrypt_int', 'encrypt', 'encrypt_int', 'generate_galois_keys', 'generate_keys', 'generate_public_key', 'generate_relin_key', 'generate_relin_key_fast', 'generate_secret_key', 'multiply', 'multiply_relin', 'negate', 'relinearize', 'rotate_columns', 'rotate_rows', 'sub']
class Ciphertext:
    """
    BGV ciphertext (NTT domain)
    """
    @property
    def level(self) -> int:
        """
        Current modulus level
        """
    @property
    def noise_budget(self) -> int:
        """
        Remaining noise budget (bits)
        """
    @property
    def size(self) -> int:
        """
        Number of polynomial components (2 = fresh/relinearized, 3 = after multiply)
        """
class Context:
    """
    
            BGV encryption context.
    
            Holds RNS modulus chain, evaluator, and PRNG.
            Create via ``bgv.context_n4096()``, ``bgv.context_n8192()``, etc.
            
    """
    @property
    def plaintext_modulus(self) -> int:
        """
        Plaintext modulus t
        """
class GaloisKeys:
    """
    BGV Galois keys for rotations
    """
class PublicKey:
    """
    BGV public key (NTT domain)
    """
class RelinKey:
    """
    BGV relinearization key
    """
class SecretKey:
    """
    BGV secret key (NTT domain)
    """
def add(ctx: Context, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
    """
    Homomorphic addition: ct1 + ct2.
    """
def context_n16384(plaintext_modulus: typing.SupportsInt = 65537) -> Context:
    """
        Create n=16384 context (128-bit security, 7 RNS primes).
        Good for deep circuits (10+ multiplication levels).
    """
def context_n4096(plaintext_modulus: typing.SupportsInt = 65537) -> Context:
    """
        Create n=4096 context (128-bit security, 3 RNS primes).
        Good for 2-3 multiplication depths.
    """
def context_n8192(plaintext_modulus: typing.SupportsInt = 65537) -> Context:
    """
        Create n=8192 context (128-bit security, 5 RNS primes).
        Good for 4-5 multiplication depths. Recommended for production.
    """
def decrypt(ctx: Context, ct: Ciphertext, sk: SecretKey) -> list[int]:
    """
        Decrypt ciphertext to plaintext vector.
    
        Args:
            ctx: BGV Context
            ct: Ciphertext (must be size 2)
            sk: Secret key
    
        Returns:
            List of plaintext integers
    """
def decrypt_int(ctx: Context, ct: Ciphertext, sk: SecretKey) -> int:
    """
    Decrypt and return only the first slot value.
    """
def encrypt(ctx: Context, plaintext: collections.abc.Sequence[typing.SupportsInt], pk: PublicKey) -> Ciphertext:
    """
        Encrypt plaintext vector.
    
        Args:
            ctx: BGV Context
            plaintext: List of integers in [0, t-1]
            pk: Public key
    
        Returns:
            BGV Ciphertext
    """
def encrypt_int(ctx: Context, value: typing.SupportsInt, pk: PublicKey) -> Ciphertext:
    """
    Encrypt a single integer (constant polynomial).
    """
def generate_galois_keys(ctx: Context, sk: SecretKey, steps: collections.abc.Sequence[typing.SupportsInt] = []) -> GaloisKeys:
    """
        Generate Galois keys for slot rotation.
    
        Args:
            ctx: BGV Context
            sk: Secret key
            steps: Rotation step sizes (empty = all powers of 2)
    
        Returns:
            GaloisKeys for rotate_rows / rotate_columns
    """
def generate_keys(ctx: Context, fast_relin: bool = False) -> tuple:
    """
        Generate a full key triple (sk, pk, rk).
    
        Args:
            ctx: BGV Context
            fast_relin: If True, use fast relin key (no digit decomposition, ~50× faster relin)
    
        Returns:
            Tuple of (SecretKey, PublicKey, RelinKey)
    """
def generate_public_key(ctx: Context, sk: SecretKey) -> PublicKey:
    """
    Generate public key from secret key.
    """
def generate_relin_key(ctx: Context, sk: SecretKey) -> RelinKey:
    """
    Generate relinearization key (digit decomposition, low noise).
    """
def generate_relin_key_fast(ctx: Context, sk: SecretKey) -> RelinKey:
    """
        Generate fast relinearization key (single KSK pair).
    
        Uses simple key switching without digit decomposition.
        Relin speed matches BFV (~1-2ms vs ~70ms with decomposition).
        Suitable for shallow circuits (≤ 3 multiplicative depths).
    
        Returns:
            RelinKey in fast mode (decomp_base=0)
    """
def generate_secret_key(ctx: Context) -> SecretKey:
    """
    Generate secret key from ternary distribution.
    """
def multiply(ctx: Context, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
    """
        Homomorphic multiplication: ct1 * ct2.
    
        Result is size 3 — call relinearize() before further operations.
        BGV uses noise flooding for efficient multiplication (faster than BFV BEHZ).
    """
def multiply_relin(ctx: Context, ct1: Ciphertext, ct2: Ciphertext, rk: RelinKey) -> Ciphertext:
    """
        Multiply two ciphertexts and relinearize in one step.
    
        Equivalent to: relinearize(multiply(ct1, ct2), rk)
    """
def negate(ctx: Context, ct: Ciphertext) -> Ciphertext:
    """
    Negate ciphertext: -ct.
    """
def relinearize(ctx: Context, ct: Ciphertext, rk: RelinKey) -> Ciphertext:
    """
    Relinearize ciphertext from size 3 to size 2.
    """
def rotate_columns(ctx: Context, ct: Ciphertext, galois_keys: GaloisKeys) -> Ciphertext:
    """
    Swap ciphertext column halves (conjugate).
    """
def rotate_rows(ctx: Context, ct: Ciphertext, steps: typing.SupportsInt, galois_keys: GaloisKeys) -> Ciphertext:
    """
        Rotate ciphertext SIMD rows.
    
        Args:
            ctx: BGV Context
            ct: Ciphertext
            steps: Rotation distance (positive=left, negative=right)
            galois_keys: Galois keys for rotation
    
        Returns:
            Rotated ciphertext
    """
def sub(ctx: Context, ct1: Ciphertext, ct2: Ciphertext) -> Ciphertext:
    """
    Homomorphic subtraction: ct1 - ct2.
    """
__version__: str = '4.11.0-rns'
