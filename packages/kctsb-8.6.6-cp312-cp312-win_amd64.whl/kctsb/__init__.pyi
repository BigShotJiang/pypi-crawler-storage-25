"""Type stubs for the top-level ``kctsb`` package.

Re-exports the high-level Python facades (:class:`CKKSContext`,
:class:`DPMechanism`, :class:`DPBudget`) and the C++ submodules
(``crypto``, ``dp``, ``ckks``, ``bfv``, ``bgv``, ``psi``, ``pir``,
``hcc``, ``upsi``, ``voprf``, ``sss``, ``core``, ``mpc``).
"""
from __future__ import annotations

from . import ckks as ckks
from . import crypto as crypto
from . import dp as dp
from ._kctsb_core import (
    bfv as bfv,
    bgv as bgv,
    core as core,
    hcc as hcc,
    mpc as mpc,
    pir as pir,
    psi as psi,
    sss as sss,
    upsi as upsi,
    voprf as voprf,
)
from .ckks import CKKSContext as CKKSContext
from .dp import DPBudget as DPBudget, DPMechanism as DPMechanism

__version__: str
__author__: str

__all__: list[str]
