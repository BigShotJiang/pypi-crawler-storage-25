"""Struct SDK — agent observability with zero-config instrumentation.

Usage:
    from struct_sdk import struct
    struct.init(ingest_key="pk-...")

    # Then use your agent framework as normal — telemetry is captured automatically.
"""

from struct_sdk.core import ContentCaptureMode, StructSDK

struct = StructSDK()

__all__ = ["struct", "ContentCaptureMode"]
