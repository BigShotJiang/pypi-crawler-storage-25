"""Auto-generated from thumbnail.yaml -- do not edit."""

from __future__ import annotations

from enum import Enum, IntEnum
from typing import Optional

from pydantic import BaseModel


class ThumbnailImageFit(str, Enum):
    MAX = 'max'
    CROP = 'crop'
    SCALE = 'scale'


class ThumbnailImageFormat(str, Enum):
    JPG = 'jpg'
    PNG = 'png'
    WEBP = 'webp'


class ThumbnailImageOptions(BaseModel):
    width: int
    height: int
    fit: ThumbnailImageFit = ThumbnailImageFit.CROP
    format: ThumbnailImageFormat = ThumbnailImageFormat.JPG


class ThumbnailVideoFit(str, Enum):
    MAX = 'max'
    CROP = 'crop'
    SCALE = 'scale'


class ThumbnailVideoFormat(str, Enum):
    JPG = 'jpg'
    PNG = 'png'
    WEBP = 'webp'


class ThumbnailVideoOptions(BaseModel):
    width: int
    height: int
    timestamp: str = '00:00:01'
    fit: ThumbnailVideoFit = ThumbnailVideoFit.CROP
    format: ThumbnailVideoFormat = ThumbnailVideoFormat.JPG


class ThumbnailDocumentSource(str, Enum):
    PAGE = 'page'
    COVER = 'cover'


class ThumbnailDocumentFit(str, Enum):
    MAX = 'max'
    CROP = 'crop'
    SCALE = 'scale'


class ThumbnailDocumentFormat(str, Enum):
    JPG = 'jpg'
    PNG = 'png'
    WEBP = 'webp'


class ThumbnailDocumentOptions(BaseModel):
    width: int
    height: int
    source: ThumbnailDocumentSource = ThumbnailDocumentSource.PAGE
    fit: ThumbnailDocumentFit = ThumbnailDocumentFit.CROP
    format: ThumbnailDocumentFormat = ThumbnailDocumentFormat.JPG
    page: Optional[int] = None

