"""Auto-generated from compress.yaml -- do not edit."""

from __future__ import annotations

from enum import Enum, IntEnum
from typing import Optional

from pydantic import BaseModel


class CompressImageMode(str, Enum):
    LOSSY = 'lossy'
    LOSSLESS = 'lossless'
    AUTO = 'auto'


class CompressImageFit(str, Enum):
    MAX = 'max'
    CROP = 'crop'
    SCALE = 'scale'


class CompressImageMetadata(str, Enum):
    ALL = 'all'
    NONE = 'none'
    COPYRIGHT = 'copyright'
    SENSITIVE = 'sensitive'


class CompressImageIccProfile(str, Enum):
    PRESERVE = 'preserve'
    STRIP = 'strip'
    SRGB = 'srgb'


class CompressImageOutputFormat(str, Enum):
    ORIGINAL = 'original'
    AUTO = 'auto'
    SMALLEST = 'smallest'
    JPEG = 'jpeg'
    PNG = 'png'
    WEBP = 'webp'
    AVIF = 'avif'


class CompressImageOptions(BaseModel):
    mode: CompressImageMode = CompressImageMode.LOSSY
    metadata: CompressImageMetadata = CompressImageMetadata.ALL
    icc_profile: CompressImageIccProfile = CompressImageIccProfile.PRESERVE
    auto_orient: bool = True
    progressive: bool = True
    output_format: CompressImageOutputFormat = CompressImageOutputFormat.ORIGINAL
    quality: Optional[int] = None
    width: Optional[int] = None
    height: Optional[int] = None
    fit: Optional[CompressImageFit] = None


class CompressAudioBitrate(IntEnum):
    _64 = 64
    _96 = 96
    _128 = 128
    _192 = 192
    _256 = 256
    _320 = 320


class CompressAudioSampleRate(IntEnum):
    _22050 = 22050
    _44100 = 44100
    _48000 = 48000


class CompressAudioOptions(BaseModel):
    bitrate: CompressAudioBitrate = CompressAudioBitrate._128
    normalize: bool = False
    channels: Optional[int] = None
    sample_rate: Optional[CompressAudioSampleRate] = None
    trim_start: Optional[float] = None
    trim_end: Optional[float] = None


class CompressVideoCodec(str, Enum):
    H264 = 'h264'
    H265 = 'h265'
    VP9 = 'vp9'
    AV1 = 'av1'


class CompressVideoEncodingMode(str, Enum):
    CRF = 'crf'
    TARGET_SIZE = 'target_size'


class CompressVideoPreset(str, Enum):
    ULTRAFAST = 'ultrafast'
    SUPERFAST = 'superfast'
    VERYFAST = 'veryfast'
    FASTER = 'faster'
    FAST = 'fast'
    MEDIUM = 'medium'
    SLOW = 'slow'
    SLOWER = 'slower'
    VERYSLOW = 'veryslow'


class CompressVideoFit(str, Enum):
    MAX = 'max'
    CROP = 'crop'
    SCALE = 'scale'
    PAD = 'pad'


class CompressVideoAudioCodec(str, Enum):
    AAC = 'aac'
    OPUS = 'opus'
    VORBIS = 'vorbis'
    COPY = 'copy'


class CompressVideoAudioBitrate(IntEnum):
    _64 = 64
    _96 = 96
    _128 = 128
    _192 = 192
    _256 = 256
    _320 = 320


class CompressVideoOptions(BaseModel):
    codec: CompressVideoCodec = CompressVideoCodec.H264
    encoding_mode: CompressVideoEncodingMode = CompressVideoEncodingMode.CRF
    preset: CompressVideoPreset = CompressVideoPreset.MEDIUM
    faststart: bool = True
    audio_codec: CompressVideoAudioCodec = CompressVideoAudioCodec.AAC
    audio_bitrate: CompressVideoAudioBitrate = CompressVideoAudioBitrate._128
    crf: Optional[int] = None
    target_size_bytes: Optional[int] = None
    width: Optional[int] = None
    height: Optional[int] = None
    fit: Optional[CompressVideoFit] = None
    fps: Optional[float] = None
    trim_start: Optional[float] = None
    trim_end: Optional[float] = None


class CompressDocumentPdfProfile(str, Enum):
    WEB = 'web'
    PRINT = 'print'
    ARCHIVE = 'archive'
    MAX = 'max'


class CompressDocumentPdfColorspace(str, Enum):
    UNCHANGED = 'unchanged'
    RGB = 'rgb'
    CMYK = 'cmyk'
    GRAYSCALE = 'grayscale'


class CompressDocumentPdfOptions(BaseModel):
    profile: CompressDocumentPdfProfile = CompressDocumentPdfProfile.WEB
    colorspace: CompressDocumentPdfColorspace = CompressDocumentPdfColorspace.UNCHANGED
    flatten_forms: bool = False
    pages: Optional[str] = None


class CompressDocumentOfficeOptions(BaseModel):
    image_quality: int = 80
    strip_macros: bool = True
    strip_hidden_data: bool = True
    strip_unused_fonts: bool = False


class CompressDocumentOdfOptions(BaseModel):
    image_quality: int = 80
    strip_metadata: bool = True
    strip_unused_styles: bool = False


class CompressDocumentEpubOptions(BaseModel):
    image_quality: int = 80
    font_subsetting: bool = True
    strip_unused_css: bool = False

