"""Auto-generated from watermark.yaml -- do not edit."""

from __future__ import annotations

from enum import Enum, IntEnum
from typing import Optional

from pydantic import BaseModel


class WatermarkImageWatermarkType(str, Enum):
    IMAGE = 'image'
    TEXT = 'text'


class WatermarkImagePosition(str, Enum):
    CENTER = 'center'
    TOP_LEFT = 'top-left'
    TOP_RIGHT = 'top-right'
    BOTTOM_LEFT = 'bottom-left'
    BOTTOM_RIGHT = 'bottom-right'


class WatermarkImageWatermarkMode(str, Enum):
    SINGLE = 'single'
    TILED = 'tiled'


class WatermarkImageOptions(BaseModel):
    watermark_type: WatermarkImageWatermarkType = WatermarkImageWatermarkType.IMAGE
    position: WatermarkImagePosition = WatermarkImagePosition.CENTER
    opacity: float = 0.5
    watermark_bucket: Optional[str] = None
    watermark_key: Optional[str] = None
    text: Optional[str] = None
    font_size: Optional[float] = None
    color: Optional[str] = None
    watermark_mode: Optional[WatermarkImageWatermarkMode] = None
    rotation: Optional[float] = None
    tile_spacing: Optional[int] = None

