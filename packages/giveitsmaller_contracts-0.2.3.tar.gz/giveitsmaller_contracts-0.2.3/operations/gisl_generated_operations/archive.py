"""Auto-generated from archive.yaml -- do not edit."""

from __future__ import annotations

from enum import Enum, IntEnum
from typing import Optional

from pydantic import BaseModel


class ArchiveFormat(str, Enum):
    ZIP = 'zip'
    TAR_GZ = 'tar.gz'


class ArchiveFolderStructure(str, Enum):
    FLAT = 'flat'
    BY_JOB = 'by_job'


class ArchiveOptions(BaseModel):
    format: ArchiveFormat = ArchiveFormat.ZIP
    folder_structure: ArchiveFolderStructure = ArchiveFolderStructure.FLAT
