"""Auto-generated from merge.yaml -- do not edit."""

from __future__ import annotations

from enum import Enum, IntEnum
from typing import Optional

from pydantic import BaseModel


class MergeImageOutputType(str, Enum):
    IMAGE = 'image'
    GIF = 'gif'
    VIDEO = 'video'


class MergeImageLayout(str, Enum):
    GRID = 'grid'
    HORIZONTAL = 'horizontal'
    VERTICAL = 'vertical'


class MergeImageResizeMode(str, Enum):
    FIT = 'fit'
    FILL = 'fill'
    NONE = 'none'


class MergeImageImageFormat(str, Enum):
    JPEG = 'jpeg'
    PNG = 'png'
    WEBP = 'webp'


class MergeImageTransition(str, Enum):
    NONE = 'none'
    FADE = 'fade'
    SLIDE = 'slide'


class MergeImageVideoFormat(str, Enum):
    MP4 = 'mp4'
    WEBM = 'webm'


class MergeImageOptions(BaseModel):
    output_type: MergeImageOutputType = MergeImageOutputType.IMAGE
    layout: Optional[MergeImageLayout] = None
    columns: Optional[int] = None
    resize_mode: Optional[MergeImageResizeMode] = None
    spacing: Optional[int] = None
    background: Optional[str] = None
    image_format: Optional[MergeImageImageFormat] = None
    delay: Optional[int] = None
    loop_count: Optional[int] = None
    duration_per_image: Optional[float] = None
    transition: Optional[MergeImageTransition] = None
    transition_duration: Optional[float] = None
    fps: Optional[int] = None
    video_format: Optional[MergeImageVideoFormat] = None


class MergeVideoTransition(str, Enum):
    NONE = 'none'
    CROSSFADE = 'crossfade'


class MergeVideoOptions(BaseModel):
    transition: MergeVideoTransition = MergeVideoTransition.NONE
    normalize_audio: bool = True
    crossfade_duration: Optional[float] = None


class MergeVideoPerInputOptions(BaseModel):
    transition: Optional[MergeVideoTransition] = None
    crossfade_duration: Optional[float] = None


class MergeAudioTransition(str, Enum):
    NONE = 'none'
    CROSSFADE = 'crossfade'


class MergeAudioOptions(BaseModel):
    transition: MergeAudioTransition = MergeAudioTransition.NONE
    gap_duration: float = 0
    normalize_audio: bool = True
    crossfade_duration: Optional[float] = None


class MergeAudioPerInputOptions(BaseModel):
    transition: Optional[MergeAudioTransition] = None
    crossfade_duration: Optional[float] = None
    gap_duration: Optional[float] = None


class MergeDocumentOptions(BaseModel):
    page_range: Optional[str] = None


class MergeDocumentPerInputOptions(BaseModel):
    page_range: Optional[str] = None

