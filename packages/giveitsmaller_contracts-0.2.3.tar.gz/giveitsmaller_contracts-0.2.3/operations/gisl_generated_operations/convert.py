"""Auto-generated from convert.yaml -- do not edit."""

from __future__ import annotations

from enum import Enum, IntEnum
from typing import Optional

from pydantic import BaseModel


class ConvertImageOutputFormat(str, Enum):
    JPEG = 'jpeg'
    PNG = 'png'
    WEBP = 'webp'
    AVIF = 'avif'
    GIF = 'gif'
    TIFF = 'tiff'


class ConvertImageOptions(BaseModel):
    output_format: ConvertImageOutputFormat
    quality: Optional[int] = None
    background: Optional[str] = None


class ConvertVideoOutputFormat(str, Enum):
    MP4 = 'mp4'
    WEBM = 'webm'
    OGG = 'ogg'
    GIF = 'gif'


class ConvertVideoCodec(str, Enum):
    H264 = 'h264'
    H265 = 'h265'
    VP9 = 'vp9'
    AV1 = 'av1'


class ConvertVideoOptions(BaseModel):
    output_format: ConvertVideoOutputFormat
    quality: int = 23
    codec: Optional[ConvertVideoCodec] = None


class ConvertAudioOutputFormat(str, Enum):
    MP3 = 'mp3'
    AAC = 'aac'
    OGG = 'ogg'
    FLAC = 'flac'
    WAV = 'wav'


class ConvertAudioBitrate(IntEnum):
    _64 = 64
    _96 = 96
    _128 = 128
    _192 = 192
    _256 = 256
    _320 = 320


class ConvertAudioOptions(BaseModel):
    output_format: ConvertAudioOutputFormat
    bitrate: Optional[ConvertAudioBitrate] = None


class ConvertDocumentPdfOutputFormat(str, Enum):
    PNG = 'png'
    JPEG = 'jpeg'


class ConvertDocumentPdfOptions(BaseModel):
    output_format: ConvertDocumentPdfOutputFormat
    pages: str = '1'
    dpi: int = 150

