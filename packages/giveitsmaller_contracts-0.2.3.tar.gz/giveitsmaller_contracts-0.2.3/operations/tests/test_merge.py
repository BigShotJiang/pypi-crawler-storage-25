"""Auto-generated tests for merge operation models."""

from gisl_generated_operations.merge import (
    MergeAudioOptions,
    MergeAudioPerInputOptions,
    MergeAudioTransition,
    MergeDocumentOptions,
    MergeDocumentPerInputOptions,
    MergeImageImageFormat,
    MergeImageLayout,
    MergeImageOptions,
    MergeImageOutputType,
    MergeImageResizeMode,
    MergeImageTransition,
    MergeImageVideoFormat,
    MergeVideoOptions,
    MergeVideoPerInputOptions,
    MergeVideoTransition,
)


def test_merge_image_output_type_image_value():
    assert MergeImageOutputType.IMAGE.value == 'image'


def test_merge_image_output_type_gif_value():
    assert MergeImageOutputType.GIF.value == 'gif'


def test_merge_image_output_type_video_value():
    assert MergeImageOutputType.VIDEO.value == 'video'


def test_merge_image_output_type_member_count():
    assert len(MergeImageOutputType) == 3


def test_merge_image_layout_grid_value():
    assert MergeImageLayout.GRID.value == 'grid'


def test_merge_image_layout_horizontal_value():
    assert MergeImageLayout.HORIZONTAL.value == 'horizontal'


def test_merge_image_layout_vertical_value():
    assert MergeImageLayout.VERTICAL.value == 'vertical'


def test_merge_image_layout_member_count():
    assert len(MergeImageLayout) == 3


def test_merge_image_resize_mode_fit_value():
    assert MergeImageResizeMode.FIT.value == 'fit'


def test_merge_image_resize_mode_fill_value():
    assert MergeImageResizeMode.FILL.value == 'fill'


def test_merge_image_resize_mode_none_value():
    assert MergeImageResizeMode.NONE.value == 'none'


def test_merge_image_resize_mode_member_count():
    assert len(MergeImageResizeMode) == 3


def test_merge_image_image_format_jpeg_value():
    assert MergeImageImageFormat.JPEG.value == 'jpeg'


def test_merge_image_image_format_png_value():
    assert MergeImageImageFormat.PNG.value == 'png'


def test_merge_image_image_format_webp_value():
    assert MergeImageImageFormat.WEBP.value == 'webp'


def test_merge_image_image_format_member_count():
    assert len(MergeImageImageFormat) == 3


def test_merge_image_transition_none_value():
    assert MergeImageTransition.NONE.value == 'none'


def test_merge_image_transition_fade_value():
    assert MergeImageTransition.FADE.value == 'fade'


def test_merge_image_transition_slide_value():
    assert MergeImageTransition.SLIDE.value == 'slide'


def test_merge_image_transition_member_count():
    assert len(MergeImageTransition) == 3


def test_merge_image_video_format_mp4_value():
    assert MergeImageVideoFormat.MP4.value == 'mp4'


def test_merge_image_video_format_webm_value():
    assert MergeImageVideoFormat.WEBM.value == 'webm'


def test_merge_image_video_format_member_count():
    assert len(MergeImageVideoFormat) == 2


def test_merge_image_options_default_construction():
    obj = MergeImageOptions()
    assert isinstance(obj, MergeImageOptions)
    assert obj.output_type == MergeImageOutputType.IMAGE
    assert obj.layout is None
    assert obj.columns is None
    assert obj.resize_mode is None
    assert obj.spacing is None
    assert obj.background is None
    assert obj.image_format is None
    assert obj.delay is None
    assert obj.loop_count is None
    assert obj.duration_per_image is None
    assert obj.transition is None
    assert obj.transition_duration is None
    assert obj.fps is None
    assert obj.video_format is None


def test_merge_image_options_roundtrip():
    data = {
        'output_type': 'image',
        'layout': 'grid',
        'columns': 1,
        'resize_mode': 'fit',
        'spacing': 0,
        'background': 'test_value',
        'image_format': 'jpeg',
        'delay': 10,
        'loop_count': 0,
        'duration_per_image': 0.5,
        'transition': 'none',
        'transition_duration': 0.1,
        'fps': 1,
        'video_format': 'mp4',
    }
    obj = MergeImageOptions.model_validate(data)
    assert isinstance(obj, MergeImageOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_merge_video_transition_none_value():
    assert MergeVideoTransition.NONE.value == 'none'


def test_merge_video_transition_crossfade_value():
    assert MergeVideoTransition.CROSSFADE.value == 'crossfade'


def test_merge_video_transition_member_count():
    assert len(MergeVideoTransition) == 2


def test_merge_video_options_default_construction():
    obj = MergeVideoOptions()
    assert isinstance(obj, MergeVideoOptions)
    assert obj.transition == MergeVideoTransition.NONE
    assert obj.normalize_audio is True
    assert obj.crossfade_duration is None


def test_merge_video_options_roundtrip():
    data = {
        'transition': 'none',
        'crossfade_duration': 0.1,
        'normalize_audio': True,
    }
    obj = MergeVideoOptions.model_validate(data)
    assert isinstance(obj, MergeVideoOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_merge_video_per_input_options_default_construction():
    obj = MergeVideoPerInputOptions()
    assert isinstance(obj, MergeVideoPerInputOptions)
    assert obj.transition is None
    assert obj.crossfade_duration is None


def test_merge_video_per_input_options_roundtrip():
    data = {
        'transition': 'none',
        'crossfade_duration': 0.1,
    }
    obj = MergeVideoPerInputOptions.model_validate(data)
    assert isinstance(obj, MergeVideoPerInputOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_merge_audio_transition_none_value():
    assert MergeAudioTransition.NONE.value == 'none'


def test_merge_audio_transition_crossfade_value():
    assert MergeAudioTransition.CROSSFADE.value == 'crossfade'


def test_merge_audio_transition_member_count():
    assert len(MergeAudioTransition) == 2


def test_merge_audio_options_default_construction():
    obj = MergeAudioOptions()
    assert isinstance(obj, MergeAudioOptions)
    assert obj.transition == MergeAudioTransition.NONE
    assert obj.gap_duration == 0
    assert obj.normalize_audio is True
    assert obj.crossfade_duration is None


def test_merge_audio_options_roundtrip():
    data = {
        'transition': 'none',
        'crossfade_duration': 0,
        'gap_duration': 0,
        'normalize_audio': True,
    }
    obj = MergeAudioOptions.model_validate(data)
    assert isinstance(obj, MergeAudioOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_merge_audio_per_input_options_default_construction():
    obj = MergeAudioPerInputOptions()
    assert isinstance(obj, MergeAudioPerInputOptions)
    assert obj.transition is None
    assert obj.crossfade_duration is None
    assert obj.gap_duration is None


def test_merge_audio_per_input_options_roundtrip():
    data = {
        'transition': 'none',
        'crossfade_duration': 0,
        'gap_duration': 0,
    }
    obj = MergeAudioPerInputOptions.model_validate(data)
    assert isinstance(obj, MergeAudioPerInputOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_merge_document_options_default_construction():
    obj = MergeDocumentOptions()
    assert isinstance(obj, MergeDocumentOptions)
    assert obj.page_range is None


def test_merge_document_options_roundtrip():
    data = {
        'page_range': 'test_value',
    }
    obj = MergeDocumentOptions.model_validate(data)
    assert isinstance(obj, MergeDocumentOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_merge_document_per_input_options_default_construction():
    obj = MergeDocumentPerInputOptions()
    assert isinstance(obj, MergeDocumentPerInputOptions)
    assert obj.page_range is None


def test_merge_document_per_input_options_roundtrip():
    data = {
        'page_range': 'test_value',
    }
    obj = MergeDocumentPerInputOptions.model_validate(data)
    assert isinstance(obj, MergeDocumentPerInputOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored

