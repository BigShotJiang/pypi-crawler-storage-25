"""Auto-generated tests for convert operation models."""

from gisl_generated_operations.convert import (
    ConvertAudioBitrate,
    ConvertAudioOptions,
    ConvertAudioOutputFormat,
    ConvertDocumentPdfOptions,
    ConvertDocumentPdfOutputFormat,
    ConvertImageOptions,
    ConvertImageOutputFormat,
    ConvertVideoCodec,
    ConvertVideoOptions,
    ConvertVideoOutputFormat,
)


def test_convert_image_output_format_jpeg_value():
    assert ConvertImageOutputFormat.JPEG.value == 'jpeg'


def test_convert_image_output_format_png_value():
    assert ConvertImageOutputFormat.PNG.value == 'png'


def test_convert_image_output_format_webp_value():
    assert ConvertImageOutputFormat.WEBP.value == 'webp'


def test_convert_image_output_format_avif_value():
    assert ConvertImageOutputFormat.AVIF.value == 'avif'


def test_convert_image_output_format_gif_value():
    assert ConvertImageOutputFormat.GIF.value == 'gif'


def test_convert_image_output_format_tiff_value():
    assert ConvertImageOutputFormat.TIFF.value == 'tiff'


def test_convert_image_output_format_member_count():
    assert len(ConvertImageOutputFormat) == 6


def test_convert_image_options_default_construction():
    obj = ConvertImageOptions(
        output_format=ConvertImageOutputFormat.JPEG,
    )
    assert isinstance(obj, ConvertImageOptions)
    assert obj.quality is None
    assert obj.background is None


def test_convert_image_options_roundtrip():
    data = {
        'output_format': 'jpeg',
        'quality': 1,
        'background': 'test_value',
    }
    obj = ConvertImageOptions.model_validate(data)
    assert isinstance(obj, ConvertImageOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_convert_video_output_format_mp4_value():
    assert ConvertVideoOutputFormat.MP4.value == 'mp4'


def test_convert_video_output_format_webm_value():
    assert ConvertVideoOutputFormat.WEBM.value == 'webm'


def test_convert_video_output_format_ogg_value():
    assert ConvertVideoOutputFormat.OGG.value == 'ogg'


def test_convert_video_output_format_gif_value():
    assert ConvertVideoOutputFormat.GIF.value == 'gif'


def test_convert_video_output_format_member_count():
    assert len(ConvertVideoOutputFormat) == 4


def test_convert_video_codec_h264_value():
    assert ConvertVideoCodec.H264.value == 'h264'


def test_convert_video_codec_h265_value():
    assert ConvertVideoCodec.H265.value == 'h265'


def test_convert_video_codec_vp9_value():
    assert ConvertVideoCodec.VP9.value == 'vp9'


def test_convert_video_codec_av1_value():
    assert ConvertVideoCodec.AV1.value == 'av1'


def test_convert_video_codec_member_count():
    assert len(ConvertVideoCodec) == 4


def test_convert_video_options_default_construction():
    obj = ConvertVideoOptions(
        output_format=ConvertVideoOutputFormat.MP4,
    )
    assert isinstance(obj, ConvertVideoOptions)
    assert obj.quality == 23
    assert obj.codec is None


def test_convert_video_options_roundtrip():
    data = {
        'output_format': 'mp4',
        'codec': 'h264',
        'quality': 0,
    }
    obj = ConvertVideoOptions.model_validate(data)
    assert isinstance(obj, ConvertVideoOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_convert_audio_output_format_mp3_value():
    assert ConvertAudioOutputFormat.MP3.value == 'mp3'


def test_convert_audio_output_format_aac_value():
    assert ConvertAudioOutputFormat.AAC.value == 'aac'


def test_convert_audio_output_format_ogg_value():
    assert ConvertAudioOutputFormat.OGG.value == 'ogg'


def test_convert_audio_output_format_flac_value():
    assert ConvertAudioOutputFormat.FLAC.value == 'flac'


def test_convert_audio_output_format_wav_value():
    assert ConvertAudioOutputFormat.WAV.value == 'wav'


def test_convert_audio_output_format_member_count():
    assert len(ConvertAudioOutputFormat) == 5


def test_convert_audio_bitrate_64_value():
    assert ConvertAudioBitrate._64.value == 64


def test_convert_audio_bitrate_96_value():
    assert ConvertAudioBitrate._96.value == 96


def test_convert_audio_bitrate_128_value():
    assert ConvertAudioBitrate._128.value == 128


def test_convert_audio_bitrate_192_value():
    assert ConvertAudioBitrate._192.value == 192


def test_convert_audio_bitrate_256_value():
    assert ConvertAudioBitrate._256.value == 256


def test_convert_audio_bitrate_320_value():
    assert ConvertAudioBitrate._320.value == 320


def test_convert_audio_bitrate_member_count():
    assert len(ConvertAudioBitrate) == 6


def test_convert_audio_options_default_construction():
    obj = ConvertAudioOptions(
        output_format=ConvertAudioOutputFormat.MP3,
    )
    assert isinstance(obj, ConvertAudioOptions)
    assert obj.bitrate is None


def test_convert_audio_options_roundtrip():
    data = {
        'output_format': 'mp3',
        'bitrate': 64,
    }
    obj = ConvertAudioOptions.model_validate(data)
    assert isinstance(obj, ConvertAudioOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_convert_document_pdf_output_format_png_value():
    assert ConvertDocumentPdfOutputFormat.PNG.value == 'png'


def test_convert_document_pdf_output_format_jpeg_value():
    assert ConvertDocumentPdfOutputFormat.JPEG.value == 'jpeg'


def test_convert_document_pdf_output_format_member_count():
    assert len(ConvertDocumentPdfOutputFormat) == 2


def test_convert_document_pdf_options_default_construction():
    obj = ConvertDocumentPdfOptions(
        output_format=ConvertDocumentPdfOutputFormat.PNG,
    )
    assert isinstance(obj, ConvertDocumentPdfOptions)
    assert obj.pages == '1'
    assert obj.dpi == 150


def test_convert_document_pdf_options_roundtrip():
    data = {
        'output_format': 'png',
        'pages': 'test_value',
        'dpi': 72,
    }
    obj = ConvertDocumentPdfOptions.model_validate(data)
    assert isinstance(obj, ConvertDocumentPdfOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored

