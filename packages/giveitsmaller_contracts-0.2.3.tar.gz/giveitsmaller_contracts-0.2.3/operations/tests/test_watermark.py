"""Auto-generated tests for watermark operation models."""

from gisl_generated_operations.watermark import (
    WatermarkImageOptions,
    WatermarkImagePosition,
    WatermarkImageWatermarkMode,
    WatermarkImageWatermarkType,
)


def test_watermark_image_watermark_type_image_value():
    assert WatermarkImageWatermarkType.IMAGE.value == 'image'


def test_watermark_image_watermark_type_text_value():
    assert WatermarkImageWatermarkType.TEXT.value == 'text'


def test_watermark_image_watermark_type_member_count():
    assert len(WatermarkImageWatermarkType) == 2


def test_watermark_image_position_center_value():
    assert WatermarkImagePosition.CENTER.value == 'center'


def test_watermark_image_position_top_left_value():
    assert WatermarkImagePosition.TOP_LEFT.value == 'top-left'


def test_watermark_image_position_top_right_value():
    assert WatermarkImagePosition.TOP_RIGHT.value == 'top-right'


def test_watermark_image_position_bottom_left_value():
    assert WatermarkImagePosition.BOTTOM_LEFT.value == 'bottom-left'


def test_watermark_image_position_bottom_right_value():
    assert WatermarkImagePosition.BOTTOM_RIGHT.value == 'bottom-right'


def test_watermark_image_position_member_count():
    assert len(WatermarkImagePosition) == 5


def test_watermark_image_watermark_mode_single_value():
    assert WatermarkImageWatermarkMode.SINGLE.value == 'single'


def test_watermark_image_watermark_mode_tiled_value():
    assert WatermarkImageWatermarkMode.TILED.value == 'tiled'


def test_watermark_image_watermark_mode_member_count():
    assert len(WatermarkImageWatermarkMode) == 2


def test_watermark_image_options_default_construction():
    obj = WatermarkImageOptions()
    assert isinstance(obj, WatermarkImageOptions)
    assert obj.watermark_type == WatermarkImageWatermarkType.IMAGE
    assert obj.position == WatermarkImagePosition.CENTER
    assert obj.opacity == 0.5
    assert obj.watermark_bucket is None
    assert obj.watermark_key is None
    assert obj.text is None
    assert obj.font_size is None
    assert obj.color is None
    assert obj.watermark_mode is None
    assert obj.rotation is None
    assert obj.tile_spacing is None


def test_watermark_image_options_roundtrip():
    data = {
        'watermark_type': 'image',
        'position': 'center',
        'opacity': 0.0,
        'watermark_bucket': 'test_value',
        'watermark_key': 'test_value',
        'text': 'test_value',
        'font_size': 8.0,
        'color': 'test_value',
        'watermark_mode': 'single',
        'rotation': -360.0,
        'tile_spacing': 0,
    }
    obj = WatermarkImageOptions.model_validate(data)
    assert isinstance(obj, WatermarkImageOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored

