"""Auto-generated tests for thumbnail operation models."""

from gisl_generated_operations.thumbnail import (
    ThumbnailDocumentFit,
    ThumbnailDocumentFormat,
    ThumbnailDocumentOptions,
    ThumbnailDocumentSource,
    ThumbnailImageFit,
    ThumbnailImageFormat,
    ThumbnailImageOptions,
    ThumbnailVideoFit,
    ThumbnailVideoFormat,
    ThumbnailVideoOptions,
)


def test_thumbnail_image_fit_max_value():
    assert ThumbnailImageFit.MAX.value == 'max'


def test_thumbnail_image_fit_crop_value():
    assert ThumbnailImageFit.CROP.value == 'crop'


def test_thumbnail_image_fit_scale_value():
    assert ThumbnailImageFit.SCALE.value == 'scale'


def test_thumbnail_image_fit_member_count():
    assert len(ThumbnailImageFit) == 3


def test_thumbnail_image_format_jpg_value():
    assert ThumbnailImageFormat.JPG.value == 'jpg'


def test_thumbnail_image_format_png_value():
    assert ThumbnailImageFormat.PNG.value == 'png'


def test_thumbnail_image_format_webp_value():
    assert ThumbnailImageFormat.WEBP.value == 'webp'


def test_thumbnail_image_format_member_count():
    assert len(ThumbnailImageFormat) == 3


def test_thumbnail_image_options_default_construction():
    obj = ThumbnailImageOptions(
        width=1,
        height=1,
    )
    assert isinstance(obj, ThumbnailImageOptions)
    assert obj.fit == ThumbnailImageFit.CROP
    assert obj.format == ThumbnailImageFormat.JPG


def test_thumbnail_image_options_roundtrip():
    data = {
        'width': 1,
        'height': 1,
        'fit': 'max',
        'format': 'jpg',
    }
    obj = ThumbnailImageOptions.model_validate(data)
    assert isinstance(obj, ThumbnailImageOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_thumbnail_video_fit_max_value():
    assert ThumbnailVideoFit.MAX.value == 'max'


def test_thumbnail_video_fit_crop_value():
    assert ThumbnailVideoFit.CROP.value == 'crop'


def test_thumbnail_video_fit_scale_value():
    assert ThumbnailVideoFit.SCALE.value == 'scale'


def test_thumbnail_video_fit_member_count():
    assert len(ThumbnailVideoFit) == 3


def test_thumbnail_video_format_jpg_value():
    assert ThumbnailVideoFormat.JPG.value == 'jpg'


def test_thumbnail_video_format_png_value():
    assert ThumbnailVideoFormat.PNG.value == 'png'


def test_thumbnail_video_format_webp_value():
    assert ThumbnailVideoFormat.WEBP.value == 'webp'


def test_thumbnail_video_format_member_count():
    assert len(ThumbnailVideoFormat) == 3


def test_thumbnail_video_options_default_construction():
    obj = ThumbnailVideoOptions(
        width=1,
        height=1,
    )
    assert isinstance(obj, ThumbnailVideoOptions)
    assert obj.timestamp == '00:00:01'
    assert obj.fit == ThumbnailVideoFit.CROP
    assert obj.format == ThumbnailVideoFormat.JPG


def test_thumbnail_video_options_roundtrip():
    data = {
        'timestamp': 'test_value',
        'width': 1,
        'height': 1,
        'fit': 'max',
        'format': 'jpg',
    }
    obj = ThumbnailVideoOptions.model_validate(data)
    assert isinstance(obj, ThumbnailVideoOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_thumbnail_document_source_page_value():
    assert ThumbnailDocumentSource.PAGE.value == 'page'


def test_thumbnail_document_source_cover_value():
    assert ThumbnailDocumentSource.COVER.value == 'cover'


def test_thumbnail_document_source_member_count():
    assert len(ThumbnailDocumentSource) == 2


def test_thumbnail_document_fit_max_value():
    assert ThumbnailDocumentFit.MAX.value == 'max'


def test_thumbnail_document_fit_crop_value():
    assert ThumbnailDocumentFit.CROP.value == 'crop'


def test_thumbnail_document_fit_scale_value():
    assert ThumbnailDocumentFit.SCALE.value == 'scale'


def test_thumbnail_document_fit_member_count():
    assert len(ThumbnailDocumentFit) == 3


def test_thumbnail_document_format_jpg_value():
    assert ThumbnailDocumentFormat.JPG.value == 'jpg'


def test_thumbnail_document_format_png_value():
    assert ThumbnailDocumentFormat.PNG.value == 'png'


def test_thumbnail_document_format_webp_value():
    assert ThumbnailDocumentFormat.WEBP.value == 'webp'


def test_thumbnail_document_format_member_count():
    assert len(ThumbnailDocumentFormat) == 3


def test_thumbnail_document_options_default_construction():
    obj = ThumbnailDocumentOptions(
        width=1,
        height=1,
    )
    assert isinstance(obj, ThumbnailDocumentOptions)
    assert obj.source == ThumbnailDocumentSource.PAGE
    assert obj.fit == ThumbnailDocumentFit.CROP
    assert obj.format == ThumbnailDocumentFormat.JPG
    assert obj.page is None


def test_thumbnail_document_options_roundtrip():
    data = {
        'source': 'page',
        'page': 1,
        'width': 1,
        'height': 1,
        'fit': 'max',
        'format': 'jpg',
    }
    obj = ThumbnailDocumentOptions.model_validate(data)
    assert isinstance(obj, ThumbnailDocumentOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored

