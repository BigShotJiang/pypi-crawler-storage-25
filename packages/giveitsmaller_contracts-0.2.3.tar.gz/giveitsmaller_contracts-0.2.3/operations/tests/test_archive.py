"""Auto-generated tests for archive operation models."""

from gisl_generated_operations.archive import (
    ArchiveFolderStructure,
    ArchiveFormat,
    ArchiveOptions,
)


def test_archive_format_zip_value():
    assert ArchiveFormat.ZIP.value == 'zip'


def test_archive_format_tar_gz_value():
    assert ArchiveFormat.TAR_GZ.value == 'tar.gz'


def test_archive_format_member_count():
    assert len(ArchiveFormat) == 2


def test_archive_folder_structure_flat_value():
    assert ArchiveFolderStructure.FLAT.value == 'flat'


def test_archive_folder_structure_by_job_value():
    assert ArchiveFolderStructure.BY_JOB.value == 'by_job'


def test_archive_folder_structure_member_count():
    assert len(ArchiveFolderStructure) == 2


def test_archive_options_default_construction():
    obj = ArchiveOptions()
    assert isinstance(obj, ArchiveOptions)
    assert obj.format == ArchiveFormat.ZIP
    assert obj.folder_structure == ArchiveFolderStructure.FLAT


def test_archive_options_roundtrip():
    data = {
        'format': 'zip',
        'folder_structure': 'flat',
    }
    obj = ArchiveOptions.model_validate(data)
    assert isinstance(obj, ArchiveOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored

