"""Auto-generated tests for compress operation models."""

from gisl_generated_operations.compress import (
    CompressAudioBitrate,
    CompressAudioOptions,
    CompressAudioSampleRate,
    CompressDocumentEpubOptions,
    CompressDocumentOdfOptions,
    CompressDocumentOfficeOptions,
    CompressDocumentPdfColorspace,
    CompressDocumentPdfOptions,
    CompressDocumentPdfProfile,
    CompressImageFit,
    CompressImageIccProfile,
    CompressImageMetadata,
    CompressImageMode,
    CompressImageOptions,
    CompressImageOutputFormat,
    CompressVideoAudioBitrate,
    CompressVideoAudioCodec,
    CompressVideoCodec,
    CompressVideoEncodingMode,
    CompressVideoFit,
    CompressVideoOptions,
    CompressVideoPreset,
)


def test_compress_image_mode_lossy_value():
    assert CompressImageMode.LOSSY.value == 'lossy'


def test_compress_image_mode_lossless_value():
    assert CompressImageMode.LOSSLESS.value == 'lossless'


def test_compress_image_mode_auto_value():
    assert CompressImageMode.AUTO.value == 'auto'


def test_compress_image_mode_member_count():
    assert len(CompressImageMode) == 3


def test_compress_image_fit_max_value():
    assert CompressImageFit.MAX.value == 'max'


def test_compress_image_fit_crop_value():
    assert CompressImageFit.CROP.value == 'crop'


def test_compress_image_fit_scale_value():
    assert CompressImageFit.SCALE.value == 'scale'


def test_compress_image_fit_member_count():
    assert len(CompressImageFit) == 3


def test_compress_image_metadata_all_value():
    assert CompressImageMetadata.ALL.value == 'all'


def test_compress_image_metadata_none_value():
    assert CompressImageMetadata.NONE.value == 'none'


def test_compress_image_metadata_copyright_value():
    assert CompressImageMetadata.COPYRIGHT.value == 'copyright'


def test_compress_image_metadata_sensitive_value():
    assert CompressImageMetadata.SENSITIVE.value == 'sensitive'


def test_compress_image_metadata_member_count():
    assert len(CompressImageMetadata) == 4


def test_compress_image_icc_profile_preserve_value():
    assert CompressImageIccProfile.PRESERVE.value == 'preserve'


def test_compress_image_icc_profile_strip_value():
    assert CompressImageIccProfile.STRIP.value == 'strip'


def test_compress_image_icc_profile_srgb_value():
    assert CompressImageIccProfile.SRGB.value == 'srgb'


def test_compress_image_icc_profile_member_count():
    assert len(CompressImageIccProfile) == 3


def test_compress_image_output_format_original_value():
    assert CompressImageOutputFormat.ORIGINAL.value == 'original'


def test_compress_image_output_format_auto_value():
    assert CompressImageOutputFormat.AUTO.value == 'auto'


def test_compress_image_output_format_smallest_value():
    assert CompressImageOutputFormat.SMALLEST.value == 'smallest'


def test_compress_image_output_format_jpeg_value():
    assert CompressImageOutputFormat.JPEG.value == 'jpeg'


def test_compress_image_output_format_png_value():
    assert CompressImageOutputFormat.PNG.value == 'png'


def test_compress_image_output_format_webp_value():
    assert CompressImageOutputFormat.WEBP.value == 'webp'


def test_compress_image_output_format_avif_value():
    assert CompressImageOutputFormat.AVIF.value == 'avif'


def test_compress_image_output_format_member_count():
    assert len(CompressImageOutputFormat) == 7


def test_compress_image_options_default_construction():
    obj = CompressImageOptions()
    assert isinstance(obj, CompressImageOptions)
    assert obj.mode == CompressImageMode.LOSSY
    assert obj.metadata == CompressImageMetadata.ALL
    assert obj.icc_profile == CompressImageIccProfile.PRESERVE
    assert obj.auto_orient is True
    assert obj.progressive is True
    assert obj.output_format == CompressImageOutputFormat.ORIGINAL
    assert obj.quality is None
    assert obj.width is None
    assert obj.height is None
    assert obj.fit is None


def test_compress_image_options_roundtrip():
    data = {
        'mode': 'lossy',
        'quality': 1,
        'width': 1,
        'height': 1,
        'fit': 'max',
        'metadata': 'all',
        'icc_profile': 'preserve',
        'auto_orient': True,
        'progressive': True,
        'output_format': 'original',
    }
    obj = CompressImageOptions.model_validate(data)
    assert isinstance(obj, CompressImageOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_compress_audio_bitrate_64_value():
    assert CompressAudioBitrate._64.value == 64


def test_compress_audio_bitrate_96_value():
    assert CompressAudioBitrate._96.value == 96


def test_compress_audio_bitrate_128_value():
    assert CompressAudioBitrate._128.value == 128


def test_compress_audio_bitrate_192_value():
    assert CompressAudioBitrate._192.value == 192


def test_compress_audio_bitrate_256_value():
    assert CompressAudioBitrate._256.value == 256


def test_compress_audio_bitrate_320_value():
    assert CompressAudioBitrate._320.value == 320


def test_compress_audio_bitrate_member_count():
    assert len(CompressAudioBitrate) == 6


def test_compress_audio_sample_rate_22050_value():
    assert CompressAudioSampleRate._22050.value == 22050


def test_compress_audio_sample_rate_44100_value():
    assert CompressAudioSampleRate._44100.value == 44100


def test_compress_audio_sample_rate_48000_value():
    assert CompressAudioSampleRate._48000.value == 48000


def test_compress_audio_sample_rate_member_count():
    assert len(CompressAudioSampleRate) == 3


def test_compress_audio_options_default_construction():
    obj = CompressAudioOptions()
    assert isinstance(obj, CompressAudioOptions)
    assert obj.bitrate == CompressAudioBitrate._128
    assert obj.normalize is False
    assert obj.channels is None
    assert obj.sample_rate is None
    assert obj.trim_start is None
    assert obj.trim_end is None


def test_compress_audio_options_roundtrip():
    data = {
        'bitrate': 64,
        'channels': 1,
        'sample_rate': 22050,
        'normalize': True,
        'trim_start': 0,
        'trim_end': 0,
    }
    obj = CompressAudioOptions.model_validate(data)
    assert isinstance(obj, CompressAudioOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_compress_video_codec_h264_value():
    assert CompressVideoCodec.H264.value == 'h264'


def test_compress_video_codec_h265_value():
    assert CompressVideoCodec.H265.value == 'h265'


def test_compress_video_codec_vp9_value():
    assert CompressVideoCodec.VP9.value == 'vp9'


def test_compress_video_codec_av1_value():
    assert CompressVideoCodec.AV1.value == 'av1'


def test_compress_video_codec_member_count():
    assert len(CompressVideoCodec) == 4


def test_compress_video_encoding_mode_crf_value():
    assert CompressVideoEncodingMode.CRF.value == 'crf'


def test_compress_video_encoding_mode_target_size_value():
    assert CompressVideoEncodingMode.TARGET_SIZE.value == 'target_size'


def test_compress_video_encoding_mode_member_count():
    assert len(CompressVideoEncodingMode) == 2


def test_compress_video_preset_ultrafast_value():
    assert CompressVideoPreset.ULTRAFAST.value == 'ultrafast'


def test_compress_video_preset_superfast_value():
    assert CompressVideoPreset.SUPERFAST.value == 'superfast'


def test_compress_video_preset_veryfast_value():
    assert CompressVideoPreset.VERYFAST.value == 'veryfast'


def test_compress_video_preset_faster_value():
    assert CompressVideoPreset.FASTER.value == 'faster'


def test_compress_video_preset_fast_value():
    assert CompressVideoPreset.FAST.value == 'fast'


def test_compress_video_preset_medium_value():
    assert CompressVideoPreset.MEDIUM.value == 'medium'


def test_compress_video_preset_slow_value():
    assert CompressVideoPreset.SLOW.value == 'slow'


def test_compress_video_preset_slower_value():
    assert CompressVideoPreset.SLOWER.value == 'slower'


def test_compress_video_preset_veryslow_value():
    assert CompressVideoPreset.VERYSLOW.value == 'veryslow'


def test_compress_video_preset_member_count():
    assert len(CompressVideoPreset) == 9


def test_compress_video_fit_max_value():
    assert CompressVideoFit.MAX.value == 'max'


def test_compress_video_fit_crop_value():
    assert CompressVideoFit.CROP.value == 'crop'


def test_compress_video_fit_scale_value():
    assert CompressVideoFit.SCALE.value == 'scale'


def test_compress_video_fit_pad_value():
    assert CompressVideoFit.PAD.value == 'pad'


def test_compress_video_fit_member_count():
    assert len(CompressVideoFit) == 4


def test_compress_video_audio_codec_aac_value():
    assert CompressVideoAudioCodec.AAC.value == 'aac'


def test_compress_video_audio_codec_opus_value():
    assert CompressVideoAudioCodec.OPUS.value == 'opus'


def test_compress_video_audio_codec_vorbis_value():
    assert CompressVideoAudioCodec.VORBIS.value == 'vorbis'


def test_compress_video_audio_codec_copy_value():
    assert CompressVideoAudioCodec.COPY.value == 'copy'


def test_compress_video_audio_codec_member_count():
    assert len(CompressVideoAudioCodec) == 4


def test_compress_video_audio_bitrate_64_value():
    assert CompressVideoAudioBitrate._64.value == 64


def test_compress_video_audio_bitrate_96_value():
    assert CompressVideoAudioBitrate._96.value == 96


def test_compress_video_audio_bitrate_128_value():
    assert CompressVideoAudioBitrate._128.value == 128


def test_compress_video_audio_bitrate_192_value():
    assert CompressVideoAudioBitrate._192.value == 192


def test_compress_video_audio_bitrate_256_value():
    assert CompressVideoAudioBitrate._256.value == 256


def test_compress_video_audio_bitrate_320_value():
    assert CompressVideoAudioBitrate._320.value == 320


def test_compress_video_audio_bitrate_member_count():
    assert len(CompressVideoAudioBitrate) == 6


def test_compress_video_options_default_construction():
    obj = CompressVideoOptions()
    assert isinstance(obj, CompressVideoOptions)
    assert obj.codec == CompressVideoCodec.H264
    assert obj.encoding_mode == CompressVideoEncodingMode.CRF
    assert obj.preset == CompressVideoPreset.MEDIUM
    assert obj.faststart is True
    assert obj.audio_codec == CompressVideoAudioCodec.AAC
    assert obj.audio_bitrate == CompressVideoAudioBitrate._128
    assert obj.crf is None
    assert obj.target_size_bytes is None
    assert obj.width is None
    assert obj.height is None
    assert obj.fit is None
    assert obj.fps is None
    assert obj.trim_start is None
    assert obj.trim_end is None


def test_compress_video_options_roundtrip():
    data = {
        'codec': 'h264',
        'encoding_mode': 'crf',
        'crf': 0,
        'target_size_bytes': 1048576,
        'preset': 'ultrafast',
        'width': 1,
        'height': 1,
        'fit': 'max',
        'fps': 1,
        'faststart': True,
        'audio_codec': 'aac',
        'audio_bitrate': 64,
        'trim_start': 0,
        'trim_end': 0,
    }
    obj = CompressVideoOptions.model_validate(data)
    assert isinstance(obj, CompressVideoOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_compress_document_pdf_profile_web_value():
    assert CompressDocumentPdfProfile.WEB.value == 'web'


def test_compress_document_pdf_profile_print_value():
    assert CompressDocumentPdfProfile.PRINT.value == 'print'


def test_compress_document_pdf_profile_archive_value():
    assert CompressDocumentPdfProfile.ARCHIVE.value == 'archive'


def test_compress_document_pdf_profile_max_value():
    assert CompressDocumentPdfProfile.MAX.value == 'max'


def test_compress_document_pdf_profile_member_count():
    assert len(CompressDocumentPdfProfile) == 4


def test_compress_document_pdf_colorspace_unchanged_value():
    assert CompressDocumentPdfColorspace.UNCHANGED.value == 'unchanged'


def test_compress_document_pdf_colorspace_rgb_value():
    assert CompressDocumentPdfColorspace.RGB.value == 'rgb'


def test_compress_document_pdf_colorspace_cmyk_value():
    assert CompressDocumentPdfColorspace.CMYK.value == 'cmyk'


def test_compress_document_pdf_colorspace_grayscale_value():
    assert CompressDocumentPdfColorspace.GRAYSCALE.value == 'grayscale'


def test_compress_document_pdf_colorspace_member_count():
    assert len(CompressDocumentPdfColorspace) == 4


def test_compress_document_pdf_options_default_construction():
    obj = CompressDocumentPdfOptions()
    assert isinstance(obj, CompressDocumentPdfOptions)
    assert obj.profile == CompressDocumentPdfProfile.WEB
    assert obj.colorspace == CompressDocumentPdfColorspace.UNCHANGED
    assert obj.flatten_forms is False
    assert obj.pages is None


def test_compress_document_pdf_options_roundtrip():
    data = {
        'profile': 'web',
        'colorspace': 'unchanged',
        'pages': 'test_value',
        'flatten_forms': True,
    }
    obj = CompressDocumentPdfOptions.model_validate(data)
    assert isinstance(obj, CompressDocumentPdfOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_compress_document_office_options_default_construction():
    obj = CompressDocumentOfficeOptions()
    assert isinstance(obj, CompressDocumentOfficeOptions)
    assert obj.image_quality == 80
    assert obj.strip_macros is True
    assert obj.strip_hidden_data is True
    assert obj.strip_unused_fonts is False


def test_compress_document_office_options_roundtrip():
    data = {
        'image_quality': 1,
        'strip_macros': True,
        'strip_hidden_data': True,
        'strip_unused_fonts': True,
    }
    obj = CompressDocumentOfficeOptions.model_validate(data)
    assert isinstance(obj, CompressDocumentOfficeOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_compress_document_odf_options_default_construction():
    obj = CompressDocumentOdfOptions()
    assert isinstance(obj, CompressDocumentOdfOptions)
    assert obj.image_quality == 80
    assert obj.strip_metadata is True
    assert obj.strip_unused_styles is False


def test_compress_document_odf_options_roundtrip():
    data = {
        'image_quality': 1,
        'strip_metadata': True,
        'strip_unused_styles': True,
    }
    obj = CompressDocumentOdfOptions.model_validate(data)
    assert isinstance(obj, CompressDocumentOdfOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored


def test_compress_document_epub_options_default_construction():
    obj = CompressDocumentEpubOptions()
    assert isinstance(obj, CompressDocumentEpubOptions)
    assert obj.image_quality == 80
    assert obj.font_subsetting is True
    assert obj.strip_unused_css is False


def test_compress_document_epub_options_roundtrip():
    data = {
        'image_quality': 1,
        'font_subsetting': True,
        'strip_unused_css': True,
    }
    obj = CompressDocumentEpubOptions.model_validate(data)
    assert isinstance(obj, CompressDocumentEpubOptions)
    dumped = obj.model_dump()
    restored = obj.model_validate(dumped)
    assert obj == restored

