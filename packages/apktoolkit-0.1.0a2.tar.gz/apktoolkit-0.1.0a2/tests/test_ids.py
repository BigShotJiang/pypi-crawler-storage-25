from pathlib import Path

import pytest

from apk_parser.ids import IdItem, IdsFileStruct, parse_ids


def test_parse_ids_ignores_non_id_elements(tmp_path: Path) -> None:
    ids_file = tmp_path / "ids.xml"
    ids_file.write_text(
        """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <id name="title" />
    <item type="id" name="ignored" />
    <id name="subtitle"></id>
</resources>
""",
        encoding="utf-8",
    )

    parsed = parse_ids(ids_file)

    assert [item.name for item in parsed.items] == ["title", "subtitle"]
    assert all(item.value == "" for item in parsed.items)


def test_parse_ids_rejects_invalid_root(tmp_path: Path) -> None:
    ids_file = tmp_path / "ids.xml"
    ids_file.write_text(
        """<?xml version="1.0" encoding="utf-8"?>
<ids>
    <id name="title" />
</ids>
""",
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="Expected root tag 'resources'"):
        parse_ids(ids_file)


def test_parse_ids_requires_name_attribute(tmp_path: Path) -> None:
    ids_file = tmp_path / "ids.xml"
    ids_file.write_text(
        """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <id />
</resources>
""",
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="without a 'name' attribute"):
        parse_ids(ids_file)


def test_id_item_repr_uses_id_tag_without_value() -> None:
    item = IdItem("action_settings")

    assert item.name == "action_settings"
    assert item.value == ""
    assert repr(item) == '<id name="action_settings" />'


def test_ids_file_struct_formats_resources_document() -> None:
    ids_file = IdsFileStruct([IdItem("title"), IdItem("subtitle")])

    assert ids_file.formatted_str() == """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <id name="title" />
    <id name="subtitle" />
</resources>"""
