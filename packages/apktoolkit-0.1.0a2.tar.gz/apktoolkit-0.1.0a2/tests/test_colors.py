from pathlib import Path

import pytest

from apk_parser.colors import parse_colors


def test_parse_colors_ignores_comments(tmp_path: Path) -> None:
    colors_file = tmp_path / "colors.xml"
    colors_file.write_text(
        """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- top-level comment -->
    <color name="primary">#FFFFFF</color>
    <color name="secondary"> <!-- inline --> #000000 </color>
    <!-- <color name="ignored">#123456</color> -->
</resources>
""",
        encoding="utf-8",
    )

    parsed = parse_colors(colors_file)

    assert [(item.name, item.value) for item in parsed.items] == [
        ("primary", "#FFFFFF"),
        ("secondary", "#000000"),
    ]


def test_parse_colors_rejects_invalid_root(tmp_path: Path) -> None:
    colors_file = tmp_path / "colors.xml"
    colors_file.write_text(
        """<?xml version="1.0" encoding="utf-8"?>
<colors>
    <color name="primary">#FFFFFF</color>
</colors>
""",
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="Expected root tag 'resources'"):
        parse_colors(colors_file)


def test_parse_colors_requires_name_attribute(tmp_path: Path) -> None:
    colors_file = tmp_path / "colors.xml"
    colors_file.write_text(
        """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color>#FFFFFF</color>
</resources>
""",
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="without a 'name' attribute"):
        parse_colors(colors_file)
