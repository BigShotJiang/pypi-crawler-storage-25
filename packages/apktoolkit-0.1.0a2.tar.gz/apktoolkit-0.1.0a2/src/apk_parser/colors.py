from pathlib import Path
from typing import List
from xml.etree import ElementTree as ET


class ColorItem:
    name: str
    value: str

    def __init__(self, name: str, value: str):
        self.name = name
        self.value = value

    def __repr__(self):
        return f'<color name="{self.name}">{self.value}</color>'


class ColorsFileStruct:
    items: List[ColorItem]

    def __init__(self, items: List[ColorItem]):
        self.items = items

    def items_str(self) -> str:
        item_contents = [f"    {i}" for i in self.items]
        return "\n".join(item_contents)

    def container_tag_str_start(self) -> str:
        return "<resources>"

    def container_tag_str_end(self) -> str:
        return "</resources>"

    def formatted_str(self) -> str:
        contents = [
            self.xmlns_str(),
            self.container_tag_str_start(),
            self.items_str(),
            self.container_tag_str_end(),
        ]
        return "\n".join(contents)

    def xmlns_str(self) -> str:
        return '<?xml version="1.0" encoding="utf-8"?>'


def parse_colors(colors_file_path: Path) -> ColorsFileStruct:
    tree = ET.parse(colors_file_path)
    root = tree.getroot()

    if root.tag != "resources":
        raise ValueError(f"Expected root tag 'resources', got {root.tag!r}")

    items: List[ColorItem] = []
    for child in root:
        if child.tag != "color":
            continue

        name = child.get("name")
        if not name:
            raise ValueError("Encountered <color> without a 'name' attribute")

        # Collect text content across mixed nodes so inline XML comments do not
        # break parsing of values like '#FFFFFF' or '@color/other'.
        value = "".join(child.itertext()).strip()
        items.append(ColorItem(name=name, value=value))

    return ColorsFileStruct(items)
