from pathlib import Path
from typing import List
from xml.etree import ElementTree as ET

from .colors import ColorsFileStruct, ColorItem


class IdItem(ColorItem):
    def __init__(self, name):
        super().__init__(name, "")

    def __repr__(self):
        return f'<id name="{self.name}" />'


class IdsFileStruct(ColorsFileStruct):
    def __init__(self, items: List[IdItem]):
        super().__init__(items)


def parse_ids(ids_file_path: Path) -> IdsFileStruct:
    tree = ET.parse(ids_file_path)
    root = tree.getroot()

    if root.tag != "resources":
        raise ValueError(f"Expected root tag 'resources', got {root.tag!r}")

    items: List[IdItem] = []
    for child in root:
        if child.tag != "id":
            continue

        name = child.get("name")
        if not name:
            raise ValueError("Encountered <id> without a 'name' attribute")

        items.append(IdItem(name=name))

    return IdsFileStruct(items)
