---
title: Development workflow
icon: lucide/braces
---

# Project development workflow

## Cloning the repository

```sh
git clone https://github.com/smkent/bdbox
cd bdbox
```

Run `poe setup` in new repository clones to:

* Enable git hooks
* Install UI dependencies via `npm`
  (To update, run `poe setup` again or `npm install`)
* Build static UI assets
  (To build again, run `poe static` or `poe dev`)

```sh
poe setup
```

## Development tools

* `poe dev`: Watch and automatically rebuild static UI assets on changes
* `poe lint`: Run formatters and static checks
* `poe static`: Build static UI assets
* `poe test`: Run tests

The `lint` and `test` tasks can also be run as a single combined command with:

```sh
poe lt
```

### Test snapshots

Some tests compare test results with saved snapshots. Test snapshots can be
updated by running:

```sh
poe snapup
```

## Documentation server

Start the development server with:

```sh
poe docs
```

The documentation site will be served at **<http://localhost:8000>**.

To use a different bind host/port, run `poe --help docs` for arguments info.
