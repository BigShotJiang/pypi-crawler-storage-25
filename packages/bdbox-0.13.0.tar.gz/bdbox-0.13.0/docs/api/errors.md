---
title: Errors
icon: lucide/siren
---

# Errors

::: bdbox.errors
    options:
      show_root_heading: false
      show_root_toc_entry: false
      heading_level: 2
