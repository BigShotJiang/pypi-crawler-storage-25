"""Model file invocation tests."""

from __future__ import annotations

import os
import re
import subprocess
import sys
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import pytest

from .utils import Models

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path

    from syrupy.assertion import SnapshotAssertion

    from .utils import DisallowCallable


@dataclass
class Runner:
    disallow_subprocess: DisallowCallable
    snapshot: SnapshotAssertion

    def __call__(
        self, cmd: Sequence[Any], test_mode: str = "", **kwargs: Any
    ) -> str:
        kwargs.setdefault(
            "env",
            os.environ | {"BDBOX_TEST_MODEL_MODE": test_mode, "COLUMNS": "80"},
        )
        kwargs.setdefault("text", True)
        kwargs.setdefault("stdout", subprocess.PIPE)
        kwargs.setdefault("stderr", subprocess.STDOUT)
        with self.disallow_subprocess.pause():
            result = subprocess.run(  # noqa: S603
                [sys.executable, *[str(c) for c in cmd]], check=True, **kwargs
            )
        assert result.returncode == 0
        return result.stdout.strip()

    def sanitize(self, output: str) -> str:
        return re.sub(r"\(\d+\s?ms\)", "([TIMER]ms)", output)

    def match_snapshot(
        self, cmd: Sequence[Any], *args: Any, **kwargs: Any
    ) -> None:
        assert self.sanitize(self(cmd, *args, **kwargs)) == self.snapshot

    def raises(
        self, cmd: Sequence[Any], match: str
    ) -> subprocess.CalledProcessError:
        with pytest.raises(
            subprocess.CalledProcessError,
            match="returned non-zero exit status",
        ) as ee:
            self(cmd)
        assert ee.value.returncode != 0
        assert match in (ee.value.output or "")
        return ee.value


@pytest.fixture
def runner(
    disallow_subprocess: DisallowCallable, snapshot: SnapshotAssertion
) -> Runner:
    return Runner(disallow_subprocess, snapshot)


@pytest.fixture(
    params=(
        pytest.param("", id="normal"),
        pytest.param("run", id="run"),
    )
)
def model_class_test_mode(request: pytest.FixtureRequest) -> str:
    return request.param


@pytest.fixture(
    params=(
        pytest.param("", id="normal"),
        pytest.param("show", id="show"),
        pytest.param("show_noparams", id="noparams"),
    )
)
def params_class_test_mode(request: pytest.FixtureRequest) -> str:
    return request.param


def test_mixed_model_then_params_raises(runner: Runner) -> None:
    runner.raises(
        [Models.MIXED_MODEL_THEN_PARAMS],
        "Cannot use Params subclass with an existing Model subclass",
    )


def test_mixed_params_then_model_raises(runner: Runner) -> None:
    runner.raises(
        [Models.MIXED_PARAMS_THEN_MODEL], "Cannot define Model subclass"
    )


@pytest.mark.parametrize(
    "args",
    [
        pytest.param(["--help"], id="help"),
        pytest.param(
            ["--sub.a", "1", "--preset", "small", "--width", "25.4"],
            id="render",
        ),
    ],
)
def test_model(
    runner: Runner, model_class_test_mode: str, args: Sequence[str]
) -> None:
    runner.match_snapshot([Models.MODEL_CLASS, *args], model_class_test_mode)


@pytest.mark.parametrize(
    "args",
    [
        pytest.param(["--help"], id="help"),
        pytest.param([], id="render"),
    ],
)
def test_model_blank(
    runner: Runner, model_class_test_mode: str, args: Sequence[str]
) -> None:
    runner.match_snapshot(
        [Models.MODEL_CLASS_BLANK, *args], model_class_test_mode
    )


@pytest.mark.parametrize(
    "args",
    [pytest.param(["--help"], id="help"), pytest.param([], id="render")],
)
@pytest.mark.parametrize(
    "model",
    [
        pytest.param([Models.MODEL_CLASS_MULTIPLE], id="file"),
        pytest.param(
            ["-m", f"tests.models.{Models.MODEL_CLASS_MULTIPLE.stem}"],
            id="class",
        ),
    ],
)
def test_model_multiple(
    runner: Runner,
    model_class_test_mode: str,
    args: Sequence[str],
    model: Sequence[str | Path],
) -> None:
    runner.match_snapshot([*model, *args], model_class_test_mode)


@pytest.mark.parametrize(
    "args",
    [pytest.param(["--help"], id="help"), pytest.param([], id="render")],
)
@pytest.mark.parametrize(
    "model",
    [
        pytest.param(
            f"tests.models.{Models.MODEL_CLASS_MULTIPLE.stem}:FirstModel",
            id="class_multi_first",
        ),
        pytest.param(
            f"tests.models.{Models.MODEL_CLASS_MULTIPLE.stem}:SecondModel",
            id="class_multi_second",
        ),
    ],
)
def test_model_multiple_harness(
    runner: Runner,
    model_class_test_mode: str,
    args: Sequence[str],
    model: str | Path,
) -> None:
    runner.match_snapshot(["-m", "bdbox", model, *args], model_class_test_mode)


def test_model_multiple_harness_nonexistent_class(runner: Runner) -> None:
    runner.raises(
        [
            "-m",
            "bdbox",
            f"tests.models.{Models.MODEL_CLASS_MULTIPLE.stem}:NonexistentModel",
        ],
        "Model NonexistentModel not found",
    )


@pytest.mark.parametrize(
    "args",
    [
        pytest.param(["--help"], id="help"),
        pytest.param(["--width", "25.4"], id="render"),
    ],
)
def test_model_subclass(
    runner: Runner, model_class_test_mode: str, args: Sequence[str]
) -> None:
    runner.match_snapshot(
        [Models.MODEL_CLASS_SUBCLASS, *args], model_class_test_mode
    )


@pytest.mark.parametrize(
    "runner_args",
    [pytest.param(["bdbox"], id="harness"), pytest.param([], id="embedded")],
)
@pytest.mark.parametrize(
    "args",
    [pytest.param(["--help"], id="help"), pytest.param([], id="render")],
)
@pytest.mark.parametrize(
    "module",
    [
        Models.MOD_MODEL,
        f"{Models.MOD_MODEL}.model",
        Models.MOD_PARAMS,
        f"{Models.MOD_PARAMS}.model",
        Models.MONO_MODEL,
        Models.MONO_PARAMS,
        Models.MONO_PLAIN,
    ],
)
def test_module_models(
    runner: Runner,
    module: str,
    runner_args: Sequence[str],
    args: Sequence[str],
) -> None:
    runner.match_snapshot(["-m", *runner_args, module, *args])


@pytest.mark.parametrize(
    "args",
    [pytest.param(["--help"], id="help"), pytest.param([], id="render")],
)
@pytest.mark.parametrize(
    "module",
    [
        pytest.param(f"{Models.MOD_MODEL}.model:SomeModel", id="mod_model"),
        pytest.param(f"{Models.MOD_PARAMS}.model:P", id="mod_params"),
        pytest.param(f"{Models.MONO_MODEL}:MyModel", id="mono_model"),
        pytest.param(f"{Models.MONO_PARAMS}:P", id="mono_params"),
    ],
)
def test_module_class_model(
    runner: Runner, module: str, args: Sequence[str]
) -> None:
    runner.match_snapshot(["-m", "bdbox", module, *args])


def test_nonexistent_module(runner: Runner) -> None:
    runner.raises(
        [
            "-m",
            "bdbox",
            "who.is.this.whats.your.operating.number",
            "export",
            "out.step",
        ],
        "Unrecognized options",
    )


@pytest.mark.parametrize(
    "args",
    [
        pytest.param(["--help"], id="help"),
        pytest.param(
            ["--sub.a", "1", "--preset", "small", "--width", "25.4"],
            id="render",
        ),
    ],
)
def test_params_class(
    runner: Runner, params_class_test_mode: str, args: Sequence[str]
) -> None:
    runner.match_snapshot([Models.PARAMS_CLASS, *args], params_class_test_mode)


@pytest.mark.parametrize(
    "args",
    [
        pytest.param(["--help"], id="help"),
        pytest.param([], id="render"),
    ],
)
def test_params_class_blank(
    runner: Runner, params_class_test_mode: str, args: Sequence[str]
) -> None:
    runner.match_snapshot(
        [Models.PARAMS_CLASS_BLANK, *args], params_class_test_mode
    )


def test_params_class_multiple_params_raises(runner: Runner) -> None:
    runner.raises(
        [Models.PARAMS_CLASS_MULTIPLE_PARAMS],
        "ParamsError: Cannot define Params subclass",
    )


@pytest.mark.parametrize(
    "args",
    [
        pytest.param(["--help"], id="help"),
        pytest.param(
            ["--preset", "small", "--width", "25.4", "--height", "30"],
            id="render",
        ),
    ],
)
def test_params_class_instance(runner: Runner, args: Sequence[str]) -> None:
    runner.match_snapshot([Models.PARAMS_CLASS_INSTANCE, *args])
