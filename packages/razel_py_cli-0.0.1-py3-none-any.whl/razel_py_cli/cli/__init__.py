"""CLI 内部装配模块。请通过控制台命令 razel-py-cli 或 python -m razel_py_cli 使用。"""
