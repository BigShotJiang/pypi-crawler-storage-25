from __future__ import annotations

from razel_py_cli.cli.app import _create_app


def main() -> None:
    _create_app()()
