from __future__ import annotations

import typer

from razel_py_cli.commands import register_all


def _create_app() -> typer.Typer:
    app = typer.Typer(
        name="razel-py-cli",
        help="Razel Python CLI.",
        add_completion=False,
    )

    @app.callback()
    def main_callback(
        ctx: typer.Context,
        verbose: bool = typer.Option(False, "--verbose", "-v", help="更详细的输出"),
    ) -> None:
        ctx.ensure_object(dict)
        ctx.obj["verbose"] = verbose

    register_all(app)
    return app
