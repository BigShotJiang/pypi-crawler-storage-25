from __future__ import annotations

from typing import Annotated

import typer
from rich.console import Console

from razel_py_cli.user_config import ensure_config_template

console = Console()


def register_init(app: typer.Typer) -> None:
    @app.command(
        "init",
        help="在用户目录生成 ~/.razel/config.json 模板（已存在时默认不覆盖）。",
    )
    def init_command(
        force: Annotated[
            bool,
            typer.Option("--force", help="已存在 config.json 时仍覆盖写入"),
        ] = False,
    ) -> None:
        path, status = ensure_config_template(force=force)
        if status == "existed":
            console.print(f"已存在，未修改: [cyan]{path}[/cyan]（需要重建请加 [bold]--force[/bold]）")
        elif status == "created":
            console.print(f"已创建: [cyan]{path}[/cyan]")
        else:
            console.print(f"已覆盖: [cyan]{path}[/cyan]")
