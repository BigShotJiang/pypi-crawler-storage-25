# `init`

在用户目录生成 **`~/.razel/config.json`** 模板；目录不存在时会一并创建。

## 用法

```bash
razel-py-cli init
razel-py-cli init --help
```

## 选项

| 选项 | 说明 |
|------|------|
| `--force` | 若 `config.json` 已存在，仍覆盖写入模板 |

## 行为说明

- **已存在且未加 `--force`**：不修改文件，提示路径。
- **新建或覆盖**：打印创建/覆盖结果。

若跳过 `init`，首次执行 **`speech-to-text`** 也会在缺少配置时自动生成模板并提示填写密钥后再次运行（与 `init` 使用同一套模板逻辑）。
