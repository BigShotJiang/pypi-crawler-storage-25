# `config`

读取或修改 **`~/.razel/config.json`**。键使用**点路径**（如 `llm_api_key`）。

## 子命令

```bash
razel-py-cli config --help
razel-py-cli config list
razel-py-cli config list --show-secrets   # 明文显示密钥，注意环境安全
razel-py-cli config set <点路径> <值>
```

## 允许的键

与 **speech-to-text** 读取的接入信息一致：

| 点路径 | 含义 |
|--------|------|
| `llm_base_url` | OpenAI-compatible API 根地址（如 AIGW / OpenRouter） |
| `llm_api_key` | 对应 API Key（Bearer） |
| `dashscope_api_key` | 阿里云 DashScope API Key |
| `local_server` | 本地 qwen-asr-serve 地址（如 `http://127.0.0.1:8000`） |

## 示例

```bash
razel-py-cli config set dashscope_api_key 'sk-...'
razel-py-cli config set llm_api_key '...'
razel-py-cli config set llm_base_url https://aigw.netease.com/v1
razel-py-cli config list
```

若配置文件尚不存在，`config list` 会提示先执行 **`razel-py-cli init`**。
