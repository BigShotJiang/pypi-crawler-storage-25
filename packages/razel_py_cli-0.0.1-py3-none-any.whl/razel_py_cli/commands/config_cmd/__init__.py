from __future__ import annotations

from typing import Annotated, Any

import typer
from rich.console import Console
from rich.table import Table

from razel_py_cli.user_config import (
    ALLOWED_CONFIG_DOT_PATHS,
    CONFIG_PATH,
    SECRET_DOT_PATHS,
    get_by_dot_path,
    load_config_merged,
    normalize_dot_path,
    save_config_document,
    set_by_dot_path,
)

console = Console()
router = typer.Typer(help="读取或修改 ~/.razel/config.json（键用点路径；使用 llm_base_url / llm_api_key）。")


def _mask_value(path: str, value: Any, show_secrets: bool) -> str:
    if value is None:
        return "(未设置)"
    s = str(value)
    if s == "":
        return "(空)"
    if show_secrets or path not in SECRET_DOT_PATHS:
        return s
    if len(s) <= 8:
        return "********"
    return f"{s[:4]}…{s[-4:]}"


@router.command("list")
def config_list(
    show_secrets: Annotated[
        bool,
        typer.Option("--show-secrets", help="显示密钥明文（勿用于共享屏幕或日志）"),
    ] = False,
) -> None:
    """列出当前配置（默认对密钥脱敏）。"""
    if not CONFIG_PATH.is_file():
        console.print(f"[yellow]尚未存在[/yellow] {CONFIG_PATH}，可执行 [bold]razel-py-cli init[/bold] 生成模板。")
        raise typer.Exit(1)
    doc = load_config_merged()
    table = Table(title=str(CONFIG_PATH), show_header=True, header_style="bold")
    table.add_column("键（点路径）")
    table.add_column("值")
    for path in sorted(ALLOWED_CONFIG_DOT_PATHS):
        raw = get_by_dot_path(doc, path)
        table.add_row(path, _mask_value(path, raw, show_secrets))
    console.print(table)


@router.command("set")
def config_set(
    key: Annotated[str, typer.Argument(help="点路径：llm_base_url、llm_api_key、dashscope_api_key、local_server")],
    value: Annotated[str, typer.Argument(help="配置值")],
) -> None:
    """写入一项配置并保存（原子写入）。"""
    path = normalize_dot_path(key)
    if path not in ALLOWED_CONFIG_DOT_PATHS:
        console.print(
            f"[red]不支持的键:[/red] {key!r}；允许: {', '.join(sorted(ALLOWED_CONFIG_DOT_PATHS))}"
        )
        raise typer.Exit(2)
    doc = load_config_merged()
    set_by_dot_path(doc, path, value)
    save_config_document(doc)
    console.print(f"已写入 [cyan]{path}[/cyan] → {CONFIG_PATH}")


def register_config(app: typer.Typer) -> None:
    app.add_typer(router, name="config")
