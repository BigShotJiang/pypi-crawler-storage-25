"""CLI 子命令包：按子目录划分命令，在 register_all 中统一挂到根 Typer。"""

from __future__ import annotations

import typer


def register_all(app: typer.Typer) -> None:
    from razel_py_cli.commands.config_cmd import register_config
    from razel_py_cli.commands.init_cmd import register_init
    from razel_py_cli.commands.speech_to_text import register_speech_to_text

    register_init(app)
    register_config(app)
    register_speech_to_text(app)
