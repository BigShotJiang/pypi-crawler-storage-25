from .cli import register_speech_to_text

__all__ = ["register_speech_to_text"]
