# `speech-to-text`

将音视频转为文字稿，底层为 **Qwen3-ASR**（DashScope / 网易 AIGW / 本地 **qwen-asr-serve** 等）。接入信息从 **`~/.razel/config.json`** 读取（也支持环境变量覆盖），其余由命令行指定。

若尚无 **`~/.razel`** 或缺少 **`config.json`**，会先写入模板并提示填写密钥后**再执行**（与 **`init`** 同源逻辑）。

## 用法

```bash
razel-py-cli speech-to-text --help
razel-py-cli speech-to-text -i /path/to/audio.mp4
razel-py-cli speech-to-text -i https://example.com/a.mp3 -o /custom/out --format txt
```

## 常用选项

| 选项 | 简写 | 说明 |
|------|------|------|
| `--input-file` | `-i` | 输入文件路径或 URL（必填） |
| `--output-dir` | `-o` | 结果目录，默认 **`~/.razel/speech_to_text`** |
| `--tmp-dir` | `-t` | 临时 WAV 缓存，默认 **`~/.razel/qwen3-asr-cache`** |
| `--format` | `-f` | `md` 或 `txt`（扩展名不同；正文均为纯转录文本） |
| `--output-name` | `-n` | 输出基名（不含扩展名） |
| `--save-srt` | `-srt` | 额外生成 SRT（时间轴按 VAD 段） |
| `--context` | `-c` | 传给模型的上下文文本 |
| `--model` | `-m` | 模型名（默认 `qwen3-asr-flash`；纯本地服务时以服务端为准） |
| `--provider` | | `auto` \| `aigw` \| `dashscope` \| `local` |
| `--aigw` | `-a` | `provider=auto` 时优先走 AIGW |
| `--fallback-order` | | 仅 `auto` 生效，如 `aigw,dashscope,local` |
| `--num-threads` | `-j` | 并行 ASR 请求线程数 |
| `--vad-segment-threshold` | `-d` | 长音频 VAD 切分目标时长（秒），默认 `120` |
| `--silence` | `-s` | 少打印进度 |

## 长音频与切分

- 时长 **小于 3 分钟**：整段送 ASR。
- **≥ 3 分钟**：用 **Silero VAD** 按 `--vad-segment-threshold` 切成多段，**并行**调用 ASR，再按时间顺序拼接文本。

## Provider 与配置

- **`auto`**：按 `--fallback-order` 依次尝试已配置的 provider（缺密钥或本地不可达会跳过）。
- **`aigw` / `dashscope` / `local`**：只用该通路；不可用时报错。

接入字段请在 **`config`** 子命令或 `init` 模板中填写，详见 [config 说明](../config_cmd/README.md)。

### 环境变量覆盖（优先级高于 config.json）

- `LLM_BASE_URL` / `LLM_API_KEY`
- `DASHSCOPE_API_KEY`
- `LOCAL_SERVER`

## 输出

- 主结果：`<output_dir>/<basename>.md` 或 `.txt`。
- `--save-srt`：同基名 **`.srt`**，条目与 VAD 段对齐。

## 相关源码

| 文件 | 职责 |
|------|------|
| `cli.py` | Typer 参数注册 |
| `run.py` | 加载音频、VAD、调度 ASR、写文件 |
| `asr.py` | DashScope / AIGW / 本地 API |
| `audio.py` | 解码、VAD、WAV 写出 |
| `config.py` | 从 `user_config` 合并读入 speech 相关配置 |

## 构建与发布（仅发布 wheel，跨平台）

统一脚本放在仓库根目录 `scripts/`：

- macOS / Linux:
  - `bash scripts/build.sh`
  - `bash scripts/publish_pypi.sh`
- Windows (PowerShell):
  - `powershell -ExecutionPolicy Bypass -File scripts/build.ps1`
  - `powershell -ExecutionPolicy Bypass -File scripts/publish_pypi.ps1`

说明：

- `build` 使用 `uv build --wheel --no-sources`，仅产出 wheel 到 `dist/`。
- `publish_pypi` 只上传 `dist/*.whl` 到 PyPI（不上传 sdist）。
- 若你在 Windows 上使用 Git Bash，也可以直接执行 `.sh` 脚本。
