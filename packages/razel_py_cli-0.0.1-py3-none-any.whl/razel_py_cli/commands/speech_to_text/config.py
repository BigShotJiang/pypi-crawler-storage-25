"""从 ~/.razel/config.json 读取接入信息；也支持环境变量覆盖。

仅使用以下字段（已铺平）：

{
  "llm_base_url": "https://aigw.netease.com/v1",
  "llm_api_key": "...",
  "dashscope_api_key": "...",
  "local_server": "http://127.0.0.1:8000"
}

环境变量（若设置则优先）：

- LLM_BASE_URL / LLM_API_KEY
- DASHSCOPE_API_KEY
- LOCAL_SERVER

其余选项由命令行参数提供。

首次运行 speech-to-text 时若文件不存在，会自动写入模板（见 razel_py_cli.user_config）。
"""
from __future__ import annotations

import json
import os
from typing import Any

from razel_py_cli.user_config import CONFIG_PATH, DEFAULT_ASR_CACHE_DIR, default_speech_output_dir


def default_asr_tmp_dir() -> str:
    return str(DEFAULT_ASR_CACHE_DIR)


def config_path_display() -> str:
    return str(CONFIG_PATH)


def load_speech_config() -> dict[str, Any]:
    if not CONFIG_PATH.is_file():
        return {}
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ValueError(f"无效的 JSON: {CONFIG_PATH} — {e}") from e
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise ValueError(f"{CONFIG_PATH} 根节点必须是 JSON 对象")
    return raw


def _str_or_none(v: Any) -> str | None:
    if v is None:
        return None
    s = str(v).strip()
    return s or None


def resolve_dashscope_api_key(cfg: dict[str, Any]) -> str | None:
    return _str_or_none(os.getenv("DASHSCOPE_API_KEY")) or _str_or_none(cfg.get("dashscope_api_key"))


def resolve_llm(cfg: dict[str, Any]) -> tuple[str | None, str | None]:
    base = _str_or_none(os.getenv("LLM_BASE_URL")) or _str_or_none(cfg.get("llm_base_url"))
    key = _str_or_none(os.getenv("LLM_API_KEY")) or _str_or_none(cfg.get("llm_api_key"))

    if base:
        base = base.rstrip("/")
    return base, key


def resolve_local_server(cfg: dict[str, Any]) -> str | None:
    return _str_or_none(os.getenv("LOCAL_SERVER")) or _str_or_none(cfg.get("local_server"))
