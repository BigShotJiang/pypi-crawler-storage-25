"""ASR 核心：Qwen3-ASR API 调用与文本后处理。支持 DashScope、AIGW（网易）、本地 qwen-asr-serve。"""
import base64
import os
import re
import time
import random
from typing import Optional

import requests
import dashscope
from pydub import AudioSegment

MAX_API_RETRY = 10
API_RETRY_SLEEP = (1, 2)

LANGUAGE_CODE_MAPPING = {
    "ar": "Arabic",
    "zh": "Chinese",
    "en": "English",
    "fr": "French",
    "de": "German",
    "it": "Italian",
    "ja": "Japanese",
    "ko": "Korean",
    "pt": "Portuguese",
    "ru": "Russian",
    "es": "Spanish",
}


def _parse_local_asr_output(content: str) -> tuple[str, str]:
    """解析 qwen-asr-serve 返回的 content，提取 language 和 text。"""
    if not content or not isinstance(content, str):
        return "Unknown", ""
    content = content.strip()
    lang_match = re.search(r"<\|language\|>\s*(\w+)\s*<\|end\|>", content, re.IGNORECASE)
    text_match = re.search(r"<\|text\|>\s*([\s\S]*?)\s*<\|end\|>", content, re.IGNORECASE)
    language = lang_match.group(1) if lang_match else "Unknown"
    text = text_match.group(1).strip() if text_match else content
    language = LANGUAGE_CODE_MAPPING.get(language.lower()[:2], language)
    return language, text


class QwenASR:
    def __init__(
        self,
        model: str = "qwen3-asr-flash",
        base_url: Optional[str] = None,
        aigw_base_url: Optional[str] = None,
        aigw_api_key: Optional[str] = None,
    ):
        """
        Args:
            model: 模型名称，在线 API 时使用
            base_url: 本地 qwen-asr-serve 地址，如 http://localhost:8000。设置后使用本地服务。
            aigw_base_url: AIGW（网易）API 地址，如 https://aigw.netease.com/v1。与 aigw_api_key 同时设置时走 AIGW。
            aigw_api_key: AIGW API Key，Bearer 认证。
        """
        self.model = model
        self.base_url = base_url.rstrip("/") if base_url else None
        self.aigw_base_url = aigw_base_url.rstrip("/") if aigw_base_url else None
        self.aigw_api_key = aigw_api_key

    def post_text_process(self, text: str, threshold: int = 20) -> str:
        """去重：单字符重复、模式重复，缓解幻觉。"""
        def fix_char_repeats(s: str, thresh: int) -> str:
            res = []
            i = 0
            n = len(s)
            while i < n:
                count = 1
                while i + count < n and s[i + count] == s[i]:
                    count += 1
                if count > thresh:
                    res.append(s[i])
                    i += count
                else:
                    res.append(s[i : i + count])
                    i += count
            return "".join(res)

        def fix_pattern_repeats(s: str, thresh: int, max_len: int = 20) -> str:
            n = len(s)
            min_repeat_chars = thresh * 2
            if n < min_repeat_chars:
                return s
            i = 0
            result = []
            while i <= n - min_repeat_chars:
                found = False
                for k in range(1, max_len + 1):
                    if i + k * thresh > n:
                        break
                    pattern = s[i : i + k]
                    valid = True
                    for rep in range(1, thresh):
                        start_idx = i + rep * k
                        if s[start_idx : start_idx + k] != pattern:
                            valid = False
                            break
                    if valid:
                        total_rep = thresh
                        end_index = i + thresh * k
                        while end_index + k <= n and s[end_index : end_index + k] == pattern:
                            total_rep += 1
                            end_index += k
                        result.append(pattern)
                        result.append(fix_pattern_repeats(s[end_index:], thresh, max_len))
                        i = n
                        found = True
                        break
                if found:
                    break
                result.append(s[i])
                i += 1
            if not found:
                result.append(s[i:])
            return "".join(result)

        text = fix_char_repeats(text, threshold)
        return fix_pattern_repeats(text, threshold)

    def _asr_aigw(self, wav_path: str, context: str) -> tuple[str, str]:
        """调用 AIGW（网易）API。仅支持本地文件路径，传入 base64。"""
        path = wav_path.replace("file://", "")
        assert os.path.exists(path), f"{path} not exists!"
        file_size = os.path.getsize(path)
        if file_size > 10 * 1024 * 1024:
            mp3_path = os.path.splitext(path)[0] + ".mp3"
            audio = AudioSegment.from_file(path)
            audio.export(mp3_path, format="mp3")
            path = mp3_path
        with open(path, "rb") as f:
            audio_b64 = base64.b64encode(f.read()).decode("utf-8")
        ext = "mp3" if path.endswith(".mp3") else "wav"
        audio_data = f"data:audio/{ext};base64,{audio_b64}"

        url = f"{self.aigw_base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.aigw_api_key}",
            "Content-Type": "application/json",
        }
        content_list: list = [{"type": "input_audio", "input_audio": {"data": audio_data}}]
        messages: list = [{"role": "user", "content": content_list}]
        if context:
            messages.insert(0, {"role": "system", "content": context})
        payload = {"model": self.model, "messages": messages}

        resp = requests.post(url, json=payload, headers=headers, timeout=300)
        resp.raise_for_status()
        data = resp.json()
        msg = data.get("choices", [{}])[0].get("message", {})
        recog_text = msg.get("content", "") or ""
        if isinstance(recog_text, list):
            recog_text = recog_text[0].get("text", "") if recog_text else ""
        lang_code = None
        for ann in msg.get("annotations", []):
            if ann.get("type") == "audio_info":
                lang_code = ann.get("language")
                break
        language = LANGUAGE_CODE_MAPPING.get(lang_code, "Not Supported") if lang_code else "Unknown"
        return language, self.post_text_process(recog_text)

    def _asr_local(self, wav_path: str, context: str) -> tuple[str, str]:
        """调用本地 qwen-asr-serve API。仅支持本地文件路径，传入 base64。"""
        path = wav_path.replace("file://", "")
        assert os.path.exists(path), f"{path} not exists!"
        file_size = os.path.getsize(path)
        if file_size > 10 * 1024 * 1024:
            mp3_path = os.path.splitext(path)[0] + ".mp3"
            audio = AudioSegment.from_file(path)
            audio.export(mp3_path, format="mp3")
            path = mp3_path
        with open(path, "rb") as f:
            audio_b64 = base64.b64encode(f.read()).decode("utf-8")
        ext = "mp3" if path.endswith(".mp3") else "wav"
        audio_url = f"data:audio/{ext};base64,{audio_b64}"
        url = f"{self.base_url}/v1/chat/completions"
        content_list: list = [{"type": "audio_url", "audio_url": {"url": audio_url}}]
        if context:
            content_list.insert(0, {"type": "text", "text": context})
        payload = {"messages": [{"role": "user", "content": content_list}]}
        resp = requests.post(url, json=payload, timeout=300)
        resp.raise_for_status()
        data = resp.json()
        content = data.get("choices", [{}])[0].get("message", {}).get("content", "") or ""
        language, text = _parse_local_asr_output(content)
        return language, self.post_text_process(text)

    def asr(self, wav_url: str, context: str = "") -> tuple[str, str]:
        """调用 API，返回 (language, text)。"""
        if not wav_url.startswith("http"):
            assert os.path.exists(wav_url), f"{wav_url} not exists!"
            file_path = wav_url
            file_size = os.path.getsize(file_path)
            if file_size > 10 * 1024 * 1024:
                mp3_path = os.path.splitext(file_path)[0] + ".mp3"
                audio = AudioSegment.from_file(file_path)
                audio.export(mp3_path, format="mp3")
                wav_url = mp3_path
            wav_url = f"file://{wav_url}"

        if self.base_url:
            return self._asr_local(wav_url.replace("file://", ""), context)

        if self.aigw_base_url and self.aigw_api_key:
            return self._asr_aigw(wav_url, context)

        response = None
        for attempt in range(MAX_API_RETRY):
            try:
                messages = [
                    {"role": "system", "content": [{"text": context}]},
                    {"role": "user", "content": [{"audio": wav_url}]},
                ]
                response = dashscope.MultiModalConversation.call(
                    model=self.model,
                    messages=messages,
                    result_format="message",
                    asr_options={"enable_lid": True, "enable_itn": False},
                )
                if response.status_code != 200:
                    raise Exception(f"http status_code: {response.status_code} {response}")
                output = response["output"]["choices"][0]
                recog_text = ""
                if output["message"]["content"]:
                    recog_text = output["message"]["content"][0].get("text") or ""
                lang_code = None
                if "annotations" in output["message"]:
                    lang_code = output["message"]["annotations"][0].get("language")
                language = LANGUAGE_CODE_MAPPING.get(lang_code, "Not Supported")
                return language, self.post_text_process(recog_text)
            except Exception as e:
                if response and getattr(response, "code", None) == "DataInspectionFailed":
                    print(f"数据校验失败，无效音频: {wav_url}")
                    break
                print(f"重试 {attempt + 1}/{MAX_API_RETRY}: {wav_url} | {e}")
            time.sleep(random.uniform(*API_RETRY_SLEEP))
        raise RuntimeError(f"ASR 失败: {wav_url}")
