"""语音转写编排（加载音频、VAD、多 provider ASR、写稿与可选 SRT）。"""
from __future__ import annotations

import os
import shutil
import time
import warnings
from collections import Counter
from dataclasses import dataclass
from datetime import timedelta
from typing import Literal, cast
from urllib.parse import urlparse

import concurrent.futures
import requests
import srt
from tqdm import tqdm
from silero_vad import load_silero_vad

from razel_py_cli.user_config import ensure_config_template

from .asr import QwenASR
from .audio import WAV_SAMPLE_RATE, load_audio, process_vad, save_audio_file
from .config import (
    config_path_display,
    default_asr_tmp_dir,
    default_speech_output_dir,
    load_speech_config,
    resolve_llm,
    resolve_dashscope_api_key,
    resolve_local_server,
)

warnings.filterwarnings("ignore", category=SyntaxWarning, module="pydub*")


def _normalize_local_server(local_server: str | None) -> str | None:
    if not local_server:
        return None
    if not local_server.startswith(("http://", "https://")):
        return f"http://{local_server}"
    return local_server


def _check_local_server(local_server: str, timeout: float = 2.0) -> bool:
    probes = ["/v1/models", "/health", "/"]
    for p in probes:
        url = f"{local_server.rstrip('/')}{p}"
        try:
            resp = requests.get(url, timeout=timeout)
            if resp.status_code < 500:
                return True
        except Exception:
            continue
    return False


def _parse_fallback_order(raw: str) -> list[str]:
    allowed = {"aigw", "dashscope", "local"}
    order = [x.strip().lower() for x in raw.split(",") if x.strip()]
    if not order:
        raise ValueError("--fallback-order 不能为空")
    if len(set(order)) != len(order):
        raise ValueError("--fallback-order 不能包含重复 provider")
    invalid = [x for x in order if x not in allowed]
    if invalid:
        raise ValueError(f"--fallback-order 包含非法 provider: {','.join(invalid)}")
    return order


@dataclass
class TranscriptionParams:
    input_file: str
    context: str = ""
    num_threads: int = 8
    vad_segment_threshold: int = 120
    tmp_dir: str = ""
    output_dir: str = ""
    output_name: str | None = None
    output_format: Literal["md", "txt"] = "md"
    save_srt: bool = False
    silence: bool = False
    model: str = "qwen3-asr-flash"
    use_aigw: bool = False
    provider: Literal["auto", "aigw", "dashscope", "local"] = "auto"
    fallback_order: str = "aigw,dashscope,local"

    def __post_init__(self) -> None:
        if not self.tmp_dir:
            self.tmp_dir = default_asr_tmp_dir()
        if not self.output_dir:
            self.output_dir = default_speech_output_dir()


def run_transcription(params: TranscriptionParams) -> None:
    import dashscope

    # 与 `razel-py-cli init` 一致：无 ~/.razel / config.json 时 mkdir 并落模板；新建则提示后退出
    cfg_path, cfg_status = ensure_config_template(force=False)
    if cfg_status == "created":
        msg = f"已生成默认配置: {cfg_path}，请填写密钥后重新执行。"
        if not params.silence:
            print(msg)
        raise SystemExit(0)

    cfg = load_speech_config()
    input_file = params.input_file
    context = params.context
    num_threads = params.num_threads
    vad_segment_threshold = params.vad_segment_threshold
    tmp_dir = params.tmp_dir
    output_dir = params.output_dir
    output_name = params.output_name
    output_format = params.output_format
    silence = params.silence
    model = params.model
    use_aigw = params.use_aigw
    provider = cast(
        Literal["auto", "aigw", "dashscope", "local"],
        params.provider,
    )
    fallback_order = _parse_fallback_order(params.fallback_order)

    if input_file.startswith(("http://", "https://")):
        try:
            response = requests.head(input_file, allow_redirects=True, timeout=5)
            if response.status_code >= 400:
                raise FileNotFoundError(f"请求返回状态码 {response.status_code}")
        except Exception as e:
            raise FileNotFoundError(f"链接不可用: {input_file}，错误: {str(e)}") from e
    elif not os.path.exists(input_file):
        raise FileNotFoundError(f"输入文件不存在: {input_file}")

    local_server = _normalize_local_server(resolve_local_server(cfg))
    if use_aigw and provider == "auto":
        provider = "aigw"

    llm_base_url, llm_api_key = resolve_llm(cfg)
    dashscope_key = resolve_dashscope_api_key(cfg)
    cfg_hint = config_path_display()

    def _provider_ready(p: str) -> tuple[bool, str]:
        if p == "aigw":
            if not llm_base_url or not llm_api_key:
                return False, f"缺少 llm_base_url / llm_api_key（见 {cfg_hint}）"
            return True, "ok"
        if p == "dashscope":
            if not dashscope_key:
                return False, f"缺少 dashscope_api_key（见 {cfg_hint}）"
            return True, "ok"
        if p == "local":
            if not local_server:
                return False, f"缺少 local_server（{cfg_hint}）"
            if not _check_local_server(local_server):
                return False, f"本地服务不可达: {local_server}"
            return True, "ok"
        return False, f"未知 provider: {p}"

    selected_provider_chain = (
        fallback_order if provider == "auto" else [provider]
    )
    ready_chain: list[str] = []
    skipped_reasons: list[str] = []
    for p in selected_provider_chain:
        ok, reason = _provider_ready(p)
        if ok:
            ready_chain.append(p)
        else:
            skipped_reasons.append(f"{p}: {reason}")

    if not ready_chain:
        if provider == "auto":
            raise RuntimeError(
                "auto 模式下没有可用 provider；"
                f"fallback-order={','.join(fallback_order)}；"
                f"跳过原因：{'; '.join(skipped_reasons) if skipped_reasons else '无'}"
            )
        raise RuntimeError(
            f"provider={provider} 不可用："
            f"{'; '.join(skipped_reasons) if skipped_reasons else '配置错误'}"
        )

    if dashscope_key:
        dashscope.api_key = dashscope_key

    if not silence:
        print("正在加载音频...")

    t_start_preprocess = time.perf_counter()
    wav = load_audio(input_file)
    if not silence:
        print(f"已加载音频，时长: {len(wav) / WAV_SAMPLE_RATE:.2f} 秒")

    if len(wav) / WAV_SAMPLE_RATE >= 180:
        if not silence:
            print("音频超过 3 分钟，正在加载 Silero VAD 模型进行切分...")
        worker_vad_model = load_silero_vad(onnx=True)
        wav_list = process_vad(wav, worker_vad_model, segment_threshold_s=vad_segment_threshold)
        if not silence:
            print(f"切分完成，共 {len(wav_list)} 段")
    else:
        wav_list = [(0, len(wav), wav)]

    wav_name = os.path.basename(input_file) if not input_file.startswith(("http://", "https://")) else os.path.basename(urlparse(input_file).path) or "audio"
    wav_dir_name = os.path.splitext(wav_name)[0]
    save_dir = os.path.join(tmp_dir, wav_dir_name)

    wav_path_list = []
    for idx, (_, _, wav_data) in enumerate(wav_list):
        wav_path = os.path.join(save_dir, f"{wav_name}_{idx}.wav")
        save_audio_file(wav_data, wav_path)
        wav_path_list.append(wav_path)

    t_end_preprocess = time.perf_counter()
    preprocess_duration = t_end_preprocess - t_start_preprocess

    attempts: list[dict] = []
    results = []
    languages = []
    api_duration = 0.0

    for provider_name in ready_chain:
        provider_start = time.perf_counter()
        if not silence:
            print(f"尝试 provider: {provider_name}")
        qwen3asr = QwenASR(
            model=model,
            base_url=local_server if provider_name == "local" else None,
            aigw_base_url=llm_base_url if provider_name == "aigw" else None,
            aigw_api_key=llm_api_key if provider_name == "aigw" else None,
        )
        try:
            _results = []
            _languages = []
            with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
                future_dict = {
                    executor.submit(qwen3asr.asr, wav_path, context): idx
                    for idx, wav_path in enumerate(wav_path_list)
                }
                if not silence:
                    pbar = tqdm(total=len(future_dict), desc=f"正在调用 ASR API ({provider_name})")
                for future in concurrent.futures.as_completed(future_dict):
                    idx = future_dict[future]
                    language, recog_text = future.result()
                    _results.append((idx, recog_text))
                    _languages.append(language)
                    if not silence:
                        pbar.update(1)
                if not silence:
                    pbar.close()
            results, languages = _results, _languages
            api_duration = time.perf_counter() - provider_start
            attempts.append({"provider": provider_name, "ok": True, "error": ""})
            if not silence:
                print(f"provider {provider_name} 成功")
            break
        except Exception as e:
            attempts.append({"provider": provider_name, "ok": False, "error": str(e)})
            if not silence:
                print(f"provider {provider_name} 失败: {e}")
            if provider != "auto":
                raise

    if not results:
        details = " | ".join(
            [f"{x['provider']} => {x['error']}" for x in attempts if not x["ok"]]
        )
        raise RuntimeError(f"所有 provider 均失败: {details if details else '未知错误'}")

    results.sort(key=lambda x: x[0])
    full_text = " ".join(text for _, text in results)
    language = Counter(languages).most_common(1)[0][0]

    if not silence:
        print(f"检测语言: {language}")
        print(f"[计时] 前置处理: {preprocess_duration:.2f} 秒 | API 调用: {api_duration:.2f} 秒 | 总计: {preprocess_duration + api_duration:.2f} 秒")
        if attempts:
            print("provider 尝试记录:")
            for item in attempts:
                state = "OK" if item["ok"] else "FAIL"
                extra = "" if item["ok"] else f" | {item['error']}"
                print(f"  - {item['provider']}: {state}{extra}")

    shutil.rmtree(save_dir, ignore_errors=True)

    os.makedirs(output_dir, exist_ok=True)
    if output_name is not None:
        base_name = os.path.splitext(output_name)[0]
    else:
        base_name = os.path.splitext(os.path.basename(
            input_file if os.path.exists(input_file) else urlparse(input_file).path
        ))[0]
    ext = ".md" if output_format == "md" else ".txt"
    save_file = os.path.join(output_dir, base_name + ext)

    with open(save_file, "w", encoding="utf-8") as f:
        if output_format == "md":
            # source_name = os.path.basename(input_file) if os.path.exists(input_file) else urlparse(input_file).path.split("/")[-1]
            # f.write("# 转录文本\n\n")
            # f.write(f"**来源**：{source_name}\n\n")
            # f.write(f"**语言**：{language}\n\n---\n\n")
            f.write(full_text + "\n")
        else:
            f.write(full_text + "\n")

    print(f"转录结果已保存至: {save_file}")

    if params.save_srt:
        srt_path = os.path.splitext(save_file)[0] + ".srt"
        subtitles = [
            srt.Subtitle(
                index=idx,
                start=timedelta(seconds=wav_list[idx][0] / WAV_SAMPLE_RATE),
                end=timedelta(seconds=wav_list[idx][1] / WAV_SAMPLE_RATE),
                content=result[1],
            )
            for idx, result in enumerate(results)
        ]
        with open(srt_path, "w", encoding="utf-8") as f:
            f.write(srt.compose(subtitles))
        print(f"SRT 字幕已保存至: {srt_path}")
