"""音频加载、VAD 切分与保存。使用 imageio-ffmpeg 内置 FFmpeg，无需系统安装。"""
import io
import os
import subprocess

import numpy as np
import soundfile as sf
from imageio_ffmpeg import get_ffmpeg_exe
from silero_vad import get_speech_timestamps

WAV_SAMPLE_RATE = 16000

FFMPEG_ONLY_EXT = (".mp4", ".m4a", ".mov", ".mkv", ".webm", ".avi")


def _get_ffmpeg_path() -> str:
    return get_ffmpeg_exe()


def _load_via_ffmpeg(file_path: str) -> np.ndarray:
    ffmpeg_exe = _get_ffmpeg_path()
    cmd = [
        ffmpeg_exe, "-i", file_path,
        "-ar", str(WAV_SAMPLE_RATE), "-ac", "1",
        "-c:a", "pcm_s16le", "-f", "wav", "-"
    ]
    proc = subprocess.run(cmd, capture_output=True, timeout=300)
    if proc.returncode != 0:
        raise RuntimeError(f"FFmpeg 失败: {proc.stderr.decode('utf-8', errors='ignore')}")
    data, _ = sf.read(io.BytesIO(proc.stdout), dtype="float32")
    return data


def load_audio(file_path: str) -> np.ndarray:
    use_ffmpeg = (
        file_path.startswith(("http://", "https://"))
        or file_path.lower().endswith(FFMPEG_ONLY_EXT)
    )
    if use_ffmpeg:
        return _load_via_ffmpeg(file_path)
    try:
        data, sr = sf.read(file_path, dtype="float32")
        if data.ndim > 1:
            data = data.mean(axis=1)
        if sr != WAV_SAMPLE_RATE:
            return _load_via_ffmpeg(file_path)
        return data
    except Exception:
        return _load_via_ffmpeg(file_path)


def process_vad(wav: np.ndarray, worker_vad_model, segment_threshold_s: int = 120, max_segment_threshold_s: int = 180) -> list:
    try:
        vad_params = {
            "sampling_rate": WAV_SAMPLE_RATE,
            "return_seconds": False,
            "min_speech_duration_ms": 1500,
            "min_silence_duration_ms": 500,
        }
        speech_timestamps = get_speech_timestamps(wav, worker_vad_model, **vad_params)
        if not speech_timestamps:
            raise ValueError("VAD 未检测到语音段")
        potential = {0.0, len(wav)}
        for s in speech_timestamps:
            potential.add(s["start"])
        sorted_pts = sorted(potential)
        final_pts = {0.0, len(wav)}
        seg_samples = segment_threshold_s * WAV_SAMPLE_RATE
        t = seg_samples
        while t < len(wav):
            final_pts.add(min(sorted_pts, key=lambda p: abs(p - t)))
            t += seg_samples
        ordered = sorted(final_pts)
        max_samples = max_segment_threshold_s * WAV_SAMPLE_RATE
        new_pts = [0.0]
        for i in range(1, len(ordered)):
            start, end = ordered[i - 1], ordered[i]
            seg_len = end - start
            if seg_len <= max_samples:
                new_pts.append(end)
            else:
                n = int(np.ceil(seg_len / max_samples))
                for j in range(1, n):
                    new_pts.append(start + j * seg_len / n)
                new_pts.append(end)
        return [
            (int(new_pts[i]), int(new_pts[i + 1]), wav[int(new_pts[i]) : int(new_pts[i + 1])])
            for i in range(len(new_pts) - 1)
        ]
    except Exception:
        segs = []
        for i in range(0, len(wav), max_segment_threshold_s * WAV_SAMPLE_RATE):
            j = min(i + max_segment_threshold_s * WAV_SAMPLE_RATE, len(wav))
            if j > i:
                segs.append((i, j, wav[i:j]))
        return segs


def save_audio_file(wav: np.ndarray, file_path: str) -> None:
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    sf.write(file_path, wav, WAV_SAMPLE_RATE)
