from __future__ import annotations

from typing import Annotated, Literal, Optional

import typer

from .config import default_asr_tmp_dir, default_speech_output_dir
from .run import TranscriptionParams, run_transcription


def register_speech_to_text(app: typer.Typer) -> None:
    @app.command(
        "speech-to-text",
        help=(
            "音视频转文字稿（Qwen3-ASR）。"
            "仅 llm_base_url / llm_api_key / dashscope_api_key / local_server 从 ~/.razel/config.json 读取，其余由命令行指定。"
            "若尚无 ~/.razel，会先按 init 生成目录与配置模板。"
        ),
    )
    def speech_to_text_cmd(
        input_file: Annotated[str, typer.Option("--input-file", "-i", help="输入媒体文件路径或 URL")],
        context: Annotated[str, typer.Option("--context", "-c", help="Qwen3-ASR-Flash 的上下文文本")] = "",
        num_threads: Annotated[int, typer.Option("--num-threads", "-j", help="并行调用的线程数")] = 8,
        vad_segment_threshold: Annotated[
            int,
            typer.Option("--vad-segment-threshold", "-d", help="VAD 切分的目标时长（秒）"),
        ] = 120,
        tmp_dir: Annotated[
            Optional[str],
            typer.Option(
                "--tmp-dir",
                "-t",
                help="临时文件目录（默认 ~/.razel/qwen3-asr-cache）",
            ),
        ] = None,
        output_dir: Annotated[
            Optional[str],
            typer.Option(
                "--output-dir",
                "-o",
                help="转录结果保存目录（默认 ~/.razel/speech_to_text）",
            ),
        ] = None,
        output_name: Annotated[
            Optional[str],
            typer.Option("--output-name", "-n", help="自定义输出文件名（不含扩展名）"),
        ] = None,
        output_format: Annotated[
            Literal["md", "txt"],
            typer.Option("--format", "-f", help="输出格式"),
        ] = "md",
        save_srt: Annotated[bool, typer.Option("--save-srt", "-srt", help="生成 SRT 字幕文件")] = False,
        silence: Annotated[bool, typer.Option("--silence", "-s", help="静默模式")] = False,
        model: Annotated[
            str,
            typer.Option("--model", "-m", help="ASR 模型名；本地服务时忽略"),
        ] = "qwen3-asr-flash",
        aigw: Annotated[
            bool,
            typer.Option(
                "--aigw",
                "-a",
                help="在 provider=auto 时强制优先走 AIGW（须在 config 中配置 llm_base_url / llm_api_key）",
            ),
        ] = False,
        provider: Annotated[
            Literal["auto", "aigw", "dashscope", "local"],
            typer.Option("--provider", help="ASR 接入策略"),
        ] = "auto",
        fallback_order: Annotated[
            str,
            typer.Option(
                "--fallback-order",
                help="仅 provider=auto 时生效；逗号分隔，如 aigw,dashscope,local",
            ),
        ] = "aigw,dashscope,local",
    ) -> None:
        params = TranscriptionParams(
            input_file=input_file,
            context=context,
            num_threads=num_threads,
            vad_segment_threshold=vad_segment_threshold,
            tmp_dir=tmp_dir or default_asr_tmp_dir(),
            output_dir=output_dir or default_speech_output_dir(),
            output_name=output_name,
            output_format=output_format,
            save_srt=save_srt,
            silence=silence,
            model=model,
            use_aigw=aigw,
            provider=provider,
            fallback_order=fallback_order,
        )
        run_transcription(params)
