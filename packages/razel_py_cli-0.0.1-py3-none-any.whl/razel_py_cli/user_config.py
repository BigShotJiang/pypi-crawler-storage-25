"""用户级配置目录 ~/.razel/ 与默认 config.json 模板。"""
from __future__ import annotations

import copy
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Literal

RAZEL_DIR = Path.home() / ".razel"
CONFIG_PATH = RAZEL_DIR / "config.json"
DEFAULT_ASR_CACHE_DIR = RAZEL_DIR / "qwen3-asr-cache"
DEFAULT_SPEECH_OUTPUT_DIR = RAZEL_DIR / "speech_to_text"


def default_speech_output_dir() -> str:
    return str(DEFAULT_SPEECH_OUTPUT_DIR)


# config set 允许的点路径（与 speech-to-text 读取字段一致）
ALLOWED_CONFIG_DOT_PATHS: frozenset[str] = frozenset({
    "llm_base_url",
    "llm_api_key",
    "dashscope_api_key",
    "local_server",
})

SECRET_DOT_PATHS: frozenset[str] = frozenset({
    "llm_api_key",
    "dashscope_api_key",
})


def default_config_document() -> dict[str, Any]:
    """与 speech-to-text 约定字段一致；密钥留空由用户填写。"""
    return {
        "llm_base_url": "https://aigw.netease.com/v1",
        "llm_api_key": "",
        "dashscope_api_key": "",
        "local_server": "http://127.0.0.1:8000",
    }


def ensure_config_template(*, force: bool = False) -> tuple[Path, Literal["created", "existed", "overwritten"]]:
    """
    保证存在 config.json：不存在则写入模板；已存在且 force 则覆盖。

    返回 (路径, created|existed|overwritten)。
    """
    RAZEL_DIR.mkdir(parents=True, exist_ok=True)
    path = CONFIG_PATH
    body = json.dumps(default_config_document(), indent=2, ensure_ascii=False) + "\n"
    if path.is_file() and not force:
        return path, "existed"
    mode: Literal["created", "overwritten"] = "overwritten" if path.is_file() else "created"
    path.write_text(body, encoding="utf-8")
    return path, mode


def load_config_merged() -> dict[str, Any]:
    """以默认模板为底，合并磁盘上的 config.json（便于缺字段时补全）。"""
    base = copy.deepcopy(default_config_document())
    if not CONFIG_PATH.is_file():
        return base
    try:
        over = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ValueError(f"无效的 JSON: {CONFIG_PATH} — {e}") from e
    if not isinstance(over, dict):
        raise ValueError(f"{CONFIG_PATH} 根节点必须是 JSON 对象")
    for k, v in over.items():
        # 兼容旧字段：保留原样合并到内存里（供 speech-to-text 回退读取）
        # 但模板与 config 子命令只暴露新字段 llm_base_url/llm_api_key
        base[k] = v
    return base


def save_config_document(doc: dict[str, Any]) -> None:
    """原子写入 config.json。"""
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(doc, indent=2, ensure_ascii=False) + "\n"
    fd, tmp_path = tempfile.mkstemp(
        prefix="config.",
        suffix=".tmp",
        dir=str(CONFIG_PATH.parent),
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp_path, CONFIG_PATH)
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def get_by_dot_path(root: dict[str, Any], path: str) -> Any:
    cur: Any = root
    for part in path.split("."):
        if part == "":
            continue
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def set_by_dot_path(root: dict[str, Any], path: str, value: str) -> None:
    parts = [p for p in path.split(".") if p]
    if not parts:
        raise ValueError("点路径不能为空")
    cur: dict[str, Any] = root
    for p in parts[:-1]:
        nxt = cur.get(p)
        if not isinstance(nxt, dict):
            cur[p] = {}
        cur = cur[p]
    cur[parts[-1]] = value


def normalize_dot_path(path: str) -> str:
    return ".".join(p for p in path.strip().split(".") if p)
