"""Generic evaluator runner.

Supports dual-field model specification (ADV-0015):
- Legacy: model + api_key_env fields (backwards compatible)
- New: model_requirement field (resolved via ModelResolver)

Transport: Uses litellm.completion() for LLM calls (ADV-0065).
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path

import litellm

from ..utils.colors import BOLD, GREEN, RED, RESET, YELLOW
from ..utils.config import load_config
from ..utils.validation import validate_evaluation_output
from .config import EvaluatorConfig
from .resolver import ModelResolver, ResolutionError


def _normalize_output_suffix(output_suffix: str) -> str:
    """Strip trailing .md extension from output suffix to avoid double extensions."""
    if output_suffix.lower().endswith(".md"):
        return output_suffix[:-3]
    return output_suffix


def run_evaluator(config: EvaluatorConfig, file_path: str, timeout: int = 180) -> int:
    """Run an evaluator on a file.

    All evaluators (built-in and custom) use the same LiteLLM transport path.

    Args:
        config: Evaluator configuration
        file_path: Path to file to evaluate
        timeout: Timeout in seconds (default: 180)

    Returns:
        0 on success, non-zero on failure
    """
    prefix = config.log_prefix or config.name.upper()
    print(f"{prefix}: Evaluating {file_path}")
    print()

    # 1. Validate file exists
    if not os.path.exists(file_path):
        print(f"{RED}Error: File not found: {file_path}{RESET}")
        return 1

    # 2. Load project config (check initialization first)
    config_path = Path(".adversarial/config.yml")
    if not config_path.exists():
        print(f"{RED}Error: Not initialized. Run 'adversarial init' first.{RESET}")
        return 1
    project_config = load_config()

    # 3. Resolve model (ADV-0015: dual-field support)
    resolver = ModelResolver()
    try:
        resolved_model, resolved_api_key_env = resolver.resolve(config)
    except ResolutionError as e:
        print(f"{RED}Error: {e}{RESET}")
        return 1

    # 4. Check API key (using resolved api_key_env)
    api_key = os.environ.get(resolved_api_key_env)
    if not api_key:
        print(f"{RED}Error: {resolved_api_key_env} not set{RESET}")
        print(f"   Set in .env or export {resolved_api_key_env}=your-key")
        return 1

    # 5. Pre-flight file size check
    line_count, estimated_tokens = _check_file_size(file_path)
    if line_count > 500 or estimated_tokens > 20000:
        _warn_large_file(line_count, estimated_tokens)
        if line_count > 700 and not _confirm_continue():
            print("Evaluation cancelled.")
            return 0

    # 6. Run evaluator via LiteLLM (all evaluators use the same path)
    return _run_custom_evaluator(
        config, file_path, project_config, timeout, resolved_model, resolved_api_key_env
    )


def _run_custom_evaluator(
    config: EvaluatorConfig,
    file_path: str,
    project_config: dict,
    timeout: int,
    resolved_model: str,
    resolved_api_key_env: str = "",
) -> int:
    """Run an evaluator via litellm.completion().

    Args:
        config: Evaluator configuration
        file_path: Path to file to evaluate
        project_config: Project configuration dict
        timeout: Timeout in seconds
        resolved_model: Resolved model ID from ModelResolver
        resolved_api_key_env: Resolved API key env var name (for error messages)
    """
    # Prepare output path
    logs_dir = Path(project_config["log_directory"])
    logs_dir.mkdir(parents=True, exist_ok=True)

    file_basename = Path(file_path).stem
    suffix = _normalize_output_suffix(config.output_suffix)
    output_file = logs_dir / f"{file_basename}-{suffix}.md"

    # Read input file
    file_content = Path(file_path).read_text(encoding="utf-8")

    # Build full prompt
    full_prompt = f"""{config.prompt}

---

## Document to Evaluate

**File**: {file_path}

{file_content}
"""

    prefix = config.log_prefix or config.name.upper()

    try:
        print(f"{prefix}: Using model {resolved_model}")

        # Call LiteLLM completion API
        response = litellm.completion(
            model=resolved_model,
            messages=[{"role": "user", "content": full_prompt}],
            timeout=timeout,
        )

        # Extract response content
        output = response.choices[0].message.content
        if output is None:
            output = ""
            print(f"{YELLOW}Warning: Model returned empty response{RESET}")

        # Write output with metadata header
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        header = f"""# {suffix.replace("-", " ").replace("_", " ").title()}

**Source**: {file_path}
**Evaluator**: {config.name}
**Model**: {resolved_model}
**Generated**: {timestamp}

---

"""
        output_file.write_text(header + output, encoding="utf-8")

        print(f"{prefix}: Output written to {output_file}")

        # Validate output and determine verdict
        is_valid, verdict, message = validate_evaluation_output(str(output_file))

        if not is_valid:
            print(f"{RED}Evaluation failed: {message}{RESET}")
            return 1

        return _report_verdict(verdict, output_file, config)

    except litellm.RateLimitError:
        _print_rate_limit_error(file_path)
        return 1
    except litellm.AuthenticationError:
        api_key_name = resolved_api_key_env or config.api_key_env or "API key"
        print(f"{RED}Error: Invalid API key for {api_key_name}{RESET}")
        print(f"   Check your {api_key_name} environment variable")
        return 1
    except litellm.Timeout:
        _print_timeout_error(timeout)
        return 1
    except Exception as e:
        print(f"{RED}Error: LLM call failed: {e}{RESET}")
        return 1


_PASS_VERDICTS = {"APPROVED", "PROCEED", "COMPLIANT", "PASS"}
_REVISE_VERDICTS = {"NEEDS_REVISION", "REVISION_SUGGESTED", "MOSTLY_COMPLIANT", "CONCERNS"}
_REJECT_VERDICTS = {"REJECTED", "RETHINK", "RESTRUCTURE_NEEDED", "NON_COMPLIANT", "FAIL"}


def _report_verdict(verdict: str | None, log_file: Path, config: EvaluatorConfig) -> int:
    """Report the evaluation verdict to terminal."""
    print()
    if verdict in _PASS_VERDICTS:
        print(f"{GREEN}Evaluation {verdict}!{RESET}")
        print(f"   Review output: {log_file}")
        return 0
    elif verdict in _REVISE_VERDICTS:
        print(f"{YELLOW}Evaluation {verdict}{RESET}")
        print(f"   Details: {log_file}")
        return 1
    elif verdict in _REJECT_VERDICTS:
        print(f"{RED}Evaluation {verdict}{RESET}")
        print(f"   Details: {log_file}")
        return 1
    else:
        print(f"{YELLOW}Evaluation complete (verdict: {verdict}){RESET}")
        print(f"   Review output: {log_file}")
        return 0


# Helper functions
def _check_file_size(file_path: str) -> tuple[int, int]:
    """Return (line_count, estimated_tokens)."""
    with open(file_path, encoding="utf-8") as f:
        lines = f.readlines()
        f.seek(0)
        content = f.read()
    return len(lines), len(content) // 4


def _warn_large_file(line_count: int, tokens: int) -> None:
    """Print large file warning."""
    print(f"{YELLOW}Large file detected:{RESET}")
    print(f"   Lines: {line_count:,}")
    print(f"   Estimated tokens: ~{tokens:,}")
    print()


def _confirm_continue() -> bool:
    """Ask user to confirm continuing with large file."""
    response = input("Continue anyway? [y/N]: ").strip().lower()
    return response in ["y", "yes"]


def _print_rate_limit_error(file_path: str) -> None:
    """Print rate limit error with suggestions."""
    print(f"{RED}Error: API rate limit exceeded{RESET}")
    print()
    print(f"{BOLD}SOLUTIONS:{RESET}")
    print("   1. Split into smaller documents (<500 lines)")
    print("   2. Upgrade your API tier")
    print("   3. Wait and retry")


def _print_timeout_error(timeout: int) -> None:
    """Print timeout error."""
    print(f"{RED}Error: Evaluation timed out (>{timeout}s){RESET}")
