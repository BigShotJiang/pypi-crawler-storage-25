"""
Adversarial Workflow - Multi-stage AI code review system

A package for integrating Author-Evaluator adversarial code review
into existing projects. Prevents "phantom work" through multi-stage verification.

Usage:
    pip install adversarial-workflow
    adversarial init
    adversarial evaluate task.md
    adversarial review
    adversarial validate "pytest"
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _get_version

try:
    __version__ = _get_version("adversarial-workflow")
except PackageNotFoundError:
    raise RuntimeError(
        "adversarial-workflow package is not installed. "
        "Run: pip install adversarial-workflow (or pip install -e '.[dev]' for development)"
    ) from None
__author__ = "Fredrik Matheson"
__license__ = "MIT"

from .cli import check, evaluate, init, main, review, validate

__all__ = ["__version__", "check", "evaluate", "init", "main", "review", "validate"]
