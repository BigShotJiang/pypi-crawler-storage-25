# cython: boundscheck=False
# cython: wraparound=False
# distutils: language = c++

import numpy as np
cimport numpy as np
from cython.parallel import prange
from cython cimport floating  # <-- The magic Fused Type import

def cpu_matmul(floating[:, :] A, floating[:, :] B):
    """
    Multi-threaded CPU Matrix Multiplication.
    Uses Fused Types ('floating') to support both 32-bit (np.float32) and 64-bit (np.float64) arrays.
    Uses 'prange' and 'nogil' to bypass Python and max out all CPU cores.
    """
    cdef int rows_A = A.shape[0]
    cdef int cols_A = A.shape[1]
    cdef int rows_B = B.shape[0]
    cdef int cols_B = B.shape[1]
    
    if cols_A != rows_B:
        raise ValueError("Matrix dimensions mismatch.")
        
    # Dynamically allocate the output array based on the fused type passed in
    cdef floating[:, :] C
    if floating is double:
        C = np.zeros((rows_A, cols_B), dtype=np.float64)
    else:
        C = np.zeros((rows_A, cols_B), dtype=np.float32)
    
    cdef int i, j, k
    cdef floating current_sum
    
    with nogil:
        for i in prange(rows_A, schedule='guided'):
            for j in range(cols_B):
                current_sum = 0.0
                for k in range(cols_A):
                    # THE FIX: We use '=' instead of '+=' 
                    # This prevents Cython from applying OpenMP reduction locks
                    current_sum = current_sum + (A[i][k] * B[k][j])
                C[i, j] = current_sum
                
    return np.asarray(C)