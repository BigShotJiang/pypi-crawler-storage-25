import csv
import os
import json
import time
import numpy as np
import multiprocessing as mp

# We now import DPOLoss from the tensor stack
from .llm import GPT, BPETokenizer, DPOLoss
from .nn_tensor import AdamW
from .compute import gpu_engine

# ==========================================
# WINDOWS MULTIPROCESSING WORKERS
# ==========================================
global_tokenizer = None
global_vocab_size = None
global_block_size = 128

def _init_worker(vocab, merges, special_tokens, vocab_size, block_size=128):
    global global_tokenizer, global_vocab_size, global_block_size
    global_tokenizer = BPETokenizer(vocab_size=vocab_size)
    global_tokenizer.vocab = vocab
    global_tokenizer.merges = merges
    global_tokenizer.special_tokens = special_tokens
    global_vocab_size = vocab_size
    global_block_size = block_size

def _process_row(row):
    """Universal Row Processor for SFT/Pre-Training."""
    if 'user' in row and 'assistant' in row:
        user_msg = row.get('user', '').strip()
        ai_msg = row.get('assistant', '').strip()
        if not user_msg or not ai_msg: return np.array([], dtype=np.uint16)
        formatted_text = (
            f"<|system|>You are a helpful AI.<|user|>{user_msg}\n"
            f"<|assistant|>{ai_msg}<|endoftext|>\n"
        )
    elif 'text' in row or 'body' in row or 'content' in row:
        text = row.get('text', row.get('body', row.get('content', ''))).strip()
        if not text: return np.array([], dtype=np.uint16)
        meta = ""
        if 'title' in row: meta += f"Title: {row['title']}. "
        if 'author' in row: meta += f"Author: {row['author']}. "
        
        if meta:
            formatted_text = f"<|system|>{meta.strip()}\n<|user|>Write the article.\n<|assistant|>{text}<|endoftext|>\n"
        else:
            formatted_text = f"{text}<|endoftext|>\n"
    else:
        text = " ".join(str(v) for v in row.values()).strip()
        if not text: return np.array([], dtype=np.uint16)
        formatted_text = f"{text}<|endoftext|>\n"

    token_ids = global_tokenizer.encode(formatted_text)
    dtype = np.uint32 if global_vocab_size > 65000 else np.uint16
    return np.array(token_ids, dtype=dtype)

def _process_dpo_row(row):
    """Twin-Row Processor for Direct Preference Optimization."""
    prompt = row.get('prompt', '').strip()
    chosen = row.get('chosen', '').strip()
    rejected = row.get('rejected', '').strip()
    
    if not prompt or not chosen or not rejected: 
        dtype = np.uint32 if global_vocab_size > 65000 else np.uint16
        return np.array([], dtype=dtype)

    sys_prompt = f"<|system|>You are a helpful AI.<|user|>{prompt}\n<|assistant|>"
    c_text = f"{sys_prompt}{chosen}<|endoftext|>"
    r_text = f"{sys_prompt}{rejected}<|endoftext|>"

    c_tokens = global_tokenizer.encode(c_text)
    r_tokens = global_tokenizer.encode(r_text)

    # Pad or truncate rigidly to block_size + 1 to maintain perfect binary strides
    def pad_trunc(toks):
        if len(toks) > global_block_size + 1:
            return toks[:global_block_size + 1]
        return toks + [0] * (global_block_size + 1 - len(toks))

    c_pad = pad_trunc(c_tokens)
    r_pad = pad_trunc(r_tokens)

    dtype = np.uint32 if global_vocab_size > 65000 else np.uint16
    # Returns [Chosen Tokens, Rejected Tokens] contiguously
    return np.array(c_pad + r_pad, dtype=dtype)

def _get_data_iterator(file_path):
    ext = os.path.splitext(file_path)[1].lower()
    if ext == '.csv':
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader: yield row
    elif ext == '.json':
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list):
                for row in data: yield row
            elif isinstance(data, dict): yield data 
    elif ext == '.jsonl':
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip(): yield json.loads(line)
    elif ext == '.txt':
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip(): yield {'text': line.strip()}
    else:
        raise ValueError(f"Unsupported file format: {ext}")

# ==========================================
# 1. THE ENTERPRISE TRAINER
# ==========================================
class AelionTrainer:
    @staticmethod
    def prepare_data(data_path, bin_path, vocab_size=3000, fast_limit=1000):
        print("\n[Aelion Pipeline] Step 1: SFT Data Preparation")
        
        tokenizer_path = bin_path.replace(".bin", "_vocab.json")
        try: csv.field_size_limit(10000000)
        except: pass
        
        print(f" -> Auto-detecting format for: {data_path}")
        print(" -> Training master vocabulary...")
        
        tokenizer = BPETokenizer(vocab_size=vocab_size)
        sample_text = ""
        iterator = _get_data_iterator(data_path)
        for i, row in enumerate(iterator):
            if i >= fast_limit: break
            row_text = " ".join(str(v) for v in row.values())
            sample_text += row_text + "\n"
            
        tokenizer.fit(sample_text)

        actual_dtype = "uint32" if vocab_size > 65000 else "uint16"
        print(f" -> Saving synchronized vocabulary to {tokenizer_path} (Locked to {actual_dtype})...")
        
        safe_vocab = {k: (v.decode('latin-1') if isinstance(v, bytes) else v) for k, v in tokenizer.vocab.items()}
        vocab_bundle = {
            "metadata": {"dtype": actual_dtype}, 
            "vocab": safe_vocab,
            "merges": {str(k): v for k, v in tokenizer.merges.items()}
        }
        with open(tokenizer_path, 'w') as f:
            json.dump(vocab_bundle, f)
        
        cores = mp.cpu_count()
        print(f" -> Igniting {cores} CPU Cores to shard data to {bin_path}...")

        def row_generator(): return _get_data_iterator(data_path)

        processed = 0
        with open(bin_path, 'wb') as bin_out:
            with mp.Pool(processes=cores, 
                         initializer=_init_worker, 
                         initargs=(tokenizer.vocab, tokenizer.merges, tokenizer.special_tokens, vocab_size)) as pool:
                
                for np_tokens in pool.imap(_process_row, row_generator(), chunksize=100):
                    if np_tokens.size > 0:
                        bin_out.write(np_tokens.tobytes())
                    processed += 1
                    if processed % 1000 == 0:
                        print(f"    ...Processed {processed} rows")
                        
        actual_size = len(tokenizer.vocab)
        print(f"✅ Data Pipeline Complete. Final Vocab Size: {actual_size}\n")
        return actual_size

    @staticmethod
    def prepare_dpo_data(data_path, bin_path, tokenizer_path, vocab_size=None, block_size=128):
        """Prepares strict Twin-Array datasets required for Preference Alignment."""
        print("\n[Aelion Pipeline] DPO Step 1: Twin-Array Data Formatting")
        
        if not os.path.exists(tokenizer_path):
            raise FileNotFoundError(f"DPO requires a pre-existing SFT Tokenizer. Missing: {tokenizer_path}")
            
        with open(tokenizer_path, 'r') as f:
            bundle = json.load(f)
        
        vocab_size = len(bundle['vocab'])
        safe_vocab = {int(k): (v.encode('latin-1') if isinstance(v, str) else v) for k, v in bundle['vocab'].items()}
        merges = {eval(k): v for k, v in bundle['merges'].items()}
        
        tokenizer = BPETokenizer(vocab_size=vocab_size)
        tokenizer.special_tokens = {"<|endoftext|>": 256, "<|user|>": 257, "<|assistant|>": 258, "<|system|>": 259}
        
        cores = mp.cpu_count()
        print(f" -> Structuring [Prompt, Chosen, Rejected] matrix to {bin_path}...")

        def row_generator(): return _get_data_iterator(data_path)

        processed = 0
        with open(bin_path, 'wb') as bin_out:
            with mp.Pool(processes=cores, 
                         initializer=_init_worker, 
                         initargs=(safe_vocab, merges, tokenizer.special_tokens, vocab_size, block_size)) as pool:
                
                for np_tokens in pool.imap(_process_dpo_row, row_generator(), chunksize=100):
                    if np_tokens.size > 0:
                        bin_out.write(np_tokens.tobytes())
                    processed += 1
                    if processed % 1000 == 0:
                        print(f"    ...Processed {processed} preference pairs")
                        
        print("✅ DPO Data Matrix Sealed.\n")

    @staticmethod
    def train(bin_path, export_path, data_path='chat_data.csv', vocab_size=None, block_size=128, embed_dim=128, n_head=4, layers=4, target_steps=1000, batch_size=8, accumulation_steps=1, mask_prompts=False):
        print(f"\n[Aelion Pipeline] Step 2: SFT GPU Training ({gpu_engine.ctx.devices[0].name if gpu_engine.available else 'CPU'})")
        
        if not os.path.exists(bin_path):
            raise FileNotFoundError(f"Binary file {bin_path} not found. Run prepare_data first.")

        tokenizer_path = bin_path.replace(".bin", "_vocab.json")
        saved_dtype_str = "uint16" 
        
        if vocab_size is None:
            if os.path.exists(tokenizer_path):
                with open(tokenizer_path, 'r') as f:
                    bundle = json.load(f)
                vocab_size = len(bundle['vocab'])
                saved_dtype_str = bundle.get("metadata", {}).get("dtype", "uint16")
            else:
                raise ValueError("vocab_size must be provided if no _vocab.json exists.")
        
        tokenizer = BPETokenizer(vocab_size=vocab_size)
        
        mapped_dtype = np.uint32 if saved_dtype_str == "uint32" else np.uint16
        mapped_data = np.memmap(bin_path, dtype=mapped_dtype, mode='r')
        
        model = GPT(vocab_size=vocab_size, block_size=block_size, n_embd=embed_dim, n_head=n_head, n_layer=layers)
        optimizer = AdamW(model.parameters(), lr=1e-3, weight_decay=0.01)
        
        checkpoint_file = export_path.replace(".aelion", "_checkpoint.npz")
        start_step = 0
        
        if os.path.exists(checkpoint_file):
            print(f" -> [Auto-Resume] Resuming SFT Checkpoint...")
            try:
                with open(checkpoint_file, 'rb') as f:
                    ckpt = np.load(f, allow_pickle=True)
                    start_step = int(ckpt['step'][0]) + 1
                    
                    for i, p in enumerate(model.parameters()):
                        if f"p{i}" in ckpt: p.data[:] = ckpt[f"p{i}"]
                    
                    if hasattr(optimizer, 'm'):
                        for i in range(len(model.parameters())):
                            if f"opt_m_{i}" in ckpt:
                                optimizer.m[i] = ckpt[f"opt_m_{i}"]
                                optimizer.v[i] = ckpt[f"opt_v_{i}"]
            except Exception as e:
                print(f" [!] Checkpoint corrupted ({e}). Restarting.")
                start_step = 0

        def get_batch(bs=8):
            ix = np.random.randint(0, len(mapped_data) - block_size - 1, bs)
            x = np.stack([mapped_data[i : i+block_size].astype(np.int32) for i in ix])
            y = np.stack([mapped_data[i+1 : i+block_size+1].astype(np.int32) for i in ix])
            
            if mask_prompts:
                for b in range(bs):
                    in_assistant = False
                    for t in range(block_size):
                        current_token = x[b, t]
                        if current_token == 258: 
                            in_assistant = True
                            continue
                        elif current_token in (256, 257, 259):
                            in_assistant = False
                            
                        if not in_assistant:
                            y[b, t] = -100
                            
            return x, y
        
        def save_checkpoint(step):
            temp_file = checkpoint_file + ".tmp"
            save_dict = {"step": np.array([step])}
            save_dict.update({f"p{i}": p.data for i, p in enumerate(model.parameters())})
            if hasattr(optimizer, 'm'):
                save_dict.update({f"opt_m_{i}": m for i, m in enumerate(optimizer.m)})
                save_dict.update({f"opt_v_{i}": v for i, v in enumerate(optimizer.v)})
            with open(temp_file, 'wb') as f: np.savez_compressed(f, **save_dict)
            if os.path.exists(checkpoint_file): os.remove(checkpoint_file)
            os.rename(temp_file, checkpoint_file)

        best_loss = float('inf')
        patience_counter = 0
        current_lr = 1e-3
        
        print(f" -> Training Target: {target_steps} steps | Batch Size: {batch_size} | Accumulation: {accumulation_steps}")
        
        try:
            optimizer.zero_grad()
            for step in range(start_step, target_steps):
                t0 = time.time()
                xb, yb = get_batch(batch_size)
                
                logits, loss = model(xb, targets=yb)
                loss = loss / accumulation_steps
                loss.backward()
                
                avg_loss = float(loss.data) * accumulation_steps
                
                if (step + 1) % accumulation_steps == 0 or (step + 1) == target_steps:
                    for p in model.parameters(): p.grad = np.clip(p.grad, -1.0, 1.0)
                    optimizer.step()
                    optimizer.zero_grad()
                
                if avg_loss < best_loss - 0.01:
                    best_loss = avg_loss; patience_counter = 0 
                else:
                    patience_counter += 1
                
                if patience_counter >= 100:
                    current_lr *= 0.5 
                    optimizer.lr = current_lr     
                    print(f"    [Scheduler] Slashed Learning Rate to {current_lr:.2e}")
                    patience_counter = 0          
                
                if step % 500 == 0 and step > 0: save_checkpoint(step)
                dt = (time.time() - t0) * 1000
                if step % 50 == 0: print(f"    Step {step:04d} | Loss: {avg_loss:.4f} | LR: {current_lr:.2e} | {dt:.1f}ms")
                    
        except KeyboardInterrupt:
            print(f"\n⚠️ Training paused.")
            save_checkpoint(step)
        finally:
            if 'mapped_data' in locals(): del mapped_data

        print("\n[Aelion Pipeline] Step 3: Exporting Unified Binary Model...")
        safe_vocab = {k: (v.decode('latin-1') if isinstance(v, bytes) else v) for k, v in tokenizer.vocab.items()}
        meta_string = json.dumps({
            "metadata": {"vocab_size": vocab_size, "block_size": block_size, "n_embd": embed_dim, "n_head": n_head, "n_layer": layers},
            "tokenizer": {"vocab": safe_vocab, "merges": {str(k): v for k, v in tokenizer.merges.items()}}
        })
        final_dict = {"meta": np.array([meta_string])}
        final_dict.update({f"p{i}": p.data for i, p in enumerate(model.parameters())})
        with open(export_path, 'wb') as f: np.savez_compressed(f, **final_dict)
        if os.path.exists(checkpoint_file): os.remove(checkpoint_file)
        print(f"✅ Master SFT Model perfectly sealed in: {export_path}\n")

    # --- ENTERPRISE UPGRADE: DIRECT PREFERENCE OPTIMIZATION (DPO) ---
    @staticmethod
    def train_dpo(bin_path, sft_model_path, export_path, beta=0.1, target_steps=1000, batch_size=2, accumulation_steps=4):
        """
        The Alignment Engine. 
        Requires an SFT model to start. Binds human preferences to neural weights.
        """
        print(f"\n[Aelion Pipeline] Step 2: DPO Alignment ({gpu_engine.ctx.devices[0].name if gpu_engine.available else 'CPU'})")
        
        if not os.path.exists(sft_model_path):
            raise FileNotFoundError("DPO requires a fully trained SFT model to anchor the intelligence.")
            
        print(" -> Booting Twin Architecture (Active Policy Model & Frozen Reference Model)...")
        with open(sft_model_path, 'rb') as f:
            bundle_raw = np.load(f, allow_pickle=True)
            bundle = json.loads(bundle_raw['meta'][0])
            
        m = bundle['metadata']
        b_size = m['block_size']
        
        # 1. The Active Model (Learning)
        active_model = GPT(vocab_size=m['vocab_size'], block_size=b_size, n_embd=m['n_embd'], n_head=m['n_head'], n_layer=m['n_layer'])
        # 2. The Frozen Reference Model (Anchoring)
        ref_model = GPT(vocab_size=m['vocab_size'], block_size=b_size, n_embd=m['n_embd'], n_head=m['n_head'], n_layer=m['n_layer'])
        
        for i, p in enumerate(active_model.parameters()):
            p.data[:] = bundle_raw[f"p{i}"]
            
        for i, p in enumerate(ref_model.parameters()):
            p.data[:] = bundle_raw[f"p{i}"]
            p.requires_grad = False # Mathematically severs the gradient graph to save VRAM
            
        ref_model.eval()
        
        optimizer = AdamW(active_model.parameters(), lr=5e-5, weight_decay=0.01) # DPO requires microscopic learning rates
        dpo_loss_fn = DPOLoss(beta=beta)

        tokenizer_path = bin_path.replace("_dpo.bin", "_vocab.json") if "_dpo" in bin_path else bin_path.replace(".bin", "_vocab.json")
        with open(tokenizer_path, 'r') as f:
            t_bundle = json.load(f)
            saved_dtype_str = t_bundle.get("metadata", {}).get("dtype", "uint16")
            
        mapped_dtype = np.uint32 if saved_dtype_str == "uint32" else np.uint16
        mapped_data = np.memmap(bin_path, dtype=mapped_dtype, mode='r')
        
        # In DPO, a single pair consumes 2 * (block_size + 1) integers
        pair_stride = 2 * (b_size + 1)
        total_pairs = len(mapped_data) // pair_stride

        def get_dpo_batch(bs=2):
            ix = np.random.randint(0, total_pairs, bs)
            xc_list, yc_list, xr_list, yr_list = [], [], [], []
            
            for i in ix:
                start = i * pair_stride
                c_chunk = mapped_data[start : start + b_size + 1].astype(np.int32)
                r_chunk = mapped_data[start + b_size + 1 : start + pair_stride].astype(np.int32)
                
                x_c, y_c = c_chunk[:-1], c_chunk[1:]
                x_r, y_r = r_chunk[:-1], r_chunk[1:]
                
                # Apply SFT Masking dynamically
                def apply_mask(x_arr, y_arr):
                    in_assistant = False
                    for t in range(b_size):
                        if x_arr[t] == 258: in_assistant = True; continue
                        elif x_arr[t] in (256, 257, 259): in_assistant = False
                        if not in_assistant: y_arr[t] = -100
                    return x_arr, y_arr
                
                x_c, y_c = apply_mask(x_c, y_c)
                x_r, y_r = apply_mask(x_r, y_r)
                
                xc_list.append(x_c); yc_list.append(y_c)
                xr_list.append(x_r); yr_list.append(y_r)
                
            return np.stack(xc_list), np.stack(yc_list), np.stack(xr_list), np.stack(yr_list)

        print(f" -> DPO Target: {target_steps} steps | Accumulation: {accumulation_steps}")
        
        try:
            optimizer.zero_grad()
            for step in range(target_steps):
                t0 = time.time()
                x_c, y_c, x_r, y_r = get_dpo_batch(batch_size)
                
                # The Twin Forward Pass
                pi_c_logps = active_model.get_dpo_logprobs(x_c, y_c)
                pi_r_logps = active_model.get_dpo_logprobs(x_r, y_r)
                
                # Frozen Pass
                ref_c_logps = ref_model.get_dpo_logprobs(x_c, y_c)
                ref_r_logps = ref_model.get_dpo_logprobs(x_r, y_r)
                
                # Preference Margin Calculus
                loss = dpo_loss_fn(pi_c_logps, pi_r_logps, ref_c_logps, ref_r_logps)
                
                loss = loss / accumulation_steps
                loss.backward()
                
                avg_loss = float(loss.data) * accumulation_steps
                
                if (step + 1) % accumulation_steps == 0 or (step + 1) == target_steps:
                    for p in active_model.parameters(): p.grad = np.clip(p.grad, -1.0, 1.0)
                    optimizer.step()
                    optimizer.zero_grad()

                dt = (time.time() - t0) * 1000
                if step % 10 == 0:
                    print(f"    DPO Step {step:04d} | Margin Loss: {avg_loss:.4f} | {dt:.1f}ms")
                    
        except KeyboardInterrupt:
            print("\n⚠️ DPO Training paused.")
        finally:
            if 'mapped_data' in locals(): del mapped_data

        print("\n[Aelion Pipeline] Step 3: Exporting Aligned DPO Model...")
        final_dict = {"meta": np.array([bundle_raw['meta'][0]])}
        final_dict.update({f"p{i}": p.data for i, p in enumerate(active_model.parameters())})
        with open(export_path, 'wb') as f: np.savez_compressed(f, **final_dict)
        print(f"✅ Master DPO Model perfectly sealed in: {export_path}\n")

# ==========================================
# 2. THE CHAT INTERFACE
# ==========================================
class Aelion:
    def __init__(self, model_path):
        print(f"[Aelion] Waking neural network from {model_path}...")
        
        with open(model_path, 'rb') as f:
            bundle_raw = np.load(f, allow_pickle=True)
            bundle = json.loads(bundle_raw['meta'][0])
            
        m = bundle['metadata']
        self.tokenizer = BPETokenizer(vocab_size=m['vocab_size'])
        self.tokenizer.vocab = {int(k): (v.encode('latin-1') if isinstance(v, str) else v) for k, v in bundle['tokenizer']['vocab'].items()}
        self.tokenizer.merges = {eval(k): v for k, v in bundle['tokenizer']['merges'].items()}
        
        n_head = m.get('n_head', 4) 
        self.model = GPT(vocab_size=m['vocab_size'], block_size=m['block_size'],
                         n_embd=m['n_embd'], n_head=n_head, n_layer=m['n_layer'])
        
        for i, p in enumerate(self.model.parameters()):
            ckpt_p = bundle_raw[f"p{i}"]
            if p.data.shape != ckpt_p.shape:
                raise ValueError(f"Architecture Mismatch! Layer p{i} expects {p.data.shape} but binary holds {ckpt_p.shape}.")
            p.data[:] = ckpt_p 
            
        print("[Aelion] Online.\n")

    def chat(self, prompt, max_tokens=150, temperature=0.75, top_k=40, repetition_penalty=1.2):
        prompt_tokens = self.tokenizer.encode(prompt)
        max_allowed_context = self.model.block_size - max_tokens - 1
        
        if len(prompt_tokens) > max_allowed_context:
            cutoff = len(prompt_tokens) - max_allowed_context
            print(f" [Aelion] Warning: Prompt too long. Truncating {cutoff} oldest tokens.")
            prompt_tokens = prompt_tokens[-max_allowed_context:]
            prompt = self.tokenizer.decode(prompt_tokens)

        return self.model.chat_generate(
            prompt=prompt, 
            tokenizer=self.tokenizer, 
            max_new_tokens=max_tokens, 
            temperature=temperature,
            top_k=top_k,
            repetition_penalty=repetition_penalty
        )