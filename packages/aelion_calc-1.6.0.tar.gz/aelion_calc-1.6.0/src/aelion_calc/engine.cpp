// engine.cpp
// Compile with: 
// Linux/Mac: g++ -O3 -shared -o engine.so -fPIC engine.cpp
// Windows:   g++ -O3 -shared -o engine.dll engine.cpp

#include <cmath>
#include <algorithm>
#include <vector>

// "extern C" allows Python to call these functions directly
extern "C" {

    // ==========================================
    // 1. CORE MATRIX MATH (The V12 Engine)
    // ==========================================

    // Matrix Multiplication (A x B = C)
    // A: [rowsA x colsA], B: [colsA x colsB], C: [rowsA x colsB]
    void matmul(float* A, float* B, float* C, int rowsA, int colsA, int colsB) {
        for (int i = 0; i < rowsA; i++) {
            for (int j = 0; j < colsB; j++) {
                float sum = 0.0f;
                // Optimization: In a real library, we'd use SIMD/AVX instructions here
                for (int k = 0; k < colsA; k++) {
                    sum += A[i * colsA + k] * B[k * colsB + j];
                }
                C[i * colsB + j] = sum;
            }
        }
    }

    // Element-wise Addition (A + B)
    void mat_add(float* A, float* B, float* C, int size) {
        for (int i = 0; i < size; i++) {
            C[i] = A[i] + B[i];
        }
    }

    // Element-wise Multiplication (A * B) - Needed for Gradients
    void mat_mul(float* A, float* B, float* C, int size) {
        for (int i = 0; i < size; i++) {
            C[i] = A[i] * B[i];
        }
    }

    // ==========================================
    // 2. ACTIVATION FUNCTIONS (The Turbocharger)
    // ==========================================

    void relu_forward(float* input, float* output, int size) {
        for (int i = 0; i < size; i++) {
            output[i] = (input[i] > 0) ? input[i] : 0.0f;
        }
    }

    void relu_backward(float* input, float* grad_output, float* grad_input, int size) {
        for (int i = 0; i < size; i++) {
            grad_input[i] = (input[i] > 0) ? grad_output[i] : 0.0f;
        }
    }

    void tanh_forward(float* input, float* output, int size) {
        for (int i = 0; i < size; i++) {
            // Using standard C++ tanh is much faster than Python math.tanh
            output[i] = std::tanh(input[i]);
        }
    }

    // ==========================================
    // 3. COMPUTER VISION (The Aerodynamics)
    // ==========================================

    // 2D Convolution Forward Pass
    // Images: [Batch, Ch_In, H, W]
    // Filters: [Ch_Out, Ch_In, K_H, K_W]
    // Output: [Batch, Ch_Out, Out_H, Out_W]
    void conv2d_forward(
        float* images, float* filters, float* output,
        int batch_size, int in_channels, int out_channels,
        int img_h, int img_w, int k_size, int stride
    ) {
        int out_h = (img_h - k_size) / stride + 1;
        int out_w = (img_w - k_size) / stride + 1;

        // Loop 1: Batch
        for (int b = 0; b < batch_size; b++) {
            // Loop 2: Output Channels (Filters)
            for (int oc = 0; oc < out_channels; oc++) {
                // Loop 3: Height
                for (int h = 0; h < out_h; h++) {
                    // Loop 4: Width
                    for (int w = 0; w < out_w; w++) {
                        
                        float sum = 0.0f;
                        
                        // Loop 5: Input Channels (Depth)
                        for (int ic = 0; ic < in_channels; ic++) {
                            // Loop 6: Kernel Rows
                            for (int kh = 0; kh < k_size; kh++) {
                                // Loop 7: Kernel Cols
                                for (int kw = 0; kw < k_size; kw++) {
                                    
                                    // Calculate Flat Indices
                                    int img_row = h * stride + kh;
                                    int img_col = w * stride + kw;
                                    
                                    int img_idx = b * (in_channels * img_h * img_w) + 
                                                  ic * (img_h * img_w) + 
                                                  img_row * img_w + 
                                                  img_col;
                                                  
                                    int filter_idx = oc * (in_channels * k_size * k_size) + 
                                                     ic * (k_size * k_size) + 
                                                     kh * k_size + 
                                                     kw;
                                    
                                    sum += images[img_idx] * filters[filter_idx];
                                }
                            }
                        }
                        
                        // Write result
                        int out_idx = b * (out_channels * out_h * out_w) + 
                                      oc * (out_h * out_w) + 
                                      h * out_w + 
                                      w;
                        output[out_idx] = sum;
                    }
                }
            }
        }
    }

    // Max Pooling Forward Pass
    void maxpool2d_forward(
        float* images, float* output,
        int batch_size, int channels, int img_h, int img_w, 
        int k_size, int stride
    ) {
        int out_h = (img_h - k_size) / stride + 1;
        int out_w = (img_w - k_size) / stride + 1;

        for (int b = 0; b < batch_size; b++) {
            for (int c = 0; c < channels; c++) {
                for (int h = 0; h < out_h; h++) {
                    for (int w = 0; w < out_w; w++) {
                        
                        float max_val = -999999999.0f;
                        
                        for (int kh = 0; kh < k_size; kh++) {
                            for (int kw = 0; kw < k_size; kw++) {
                                int r = h * stride + kh;
                                int c_idx = w * stride + kw;
                                
                                int idx = b * (channels * img_h * img_w) + 
                                          c * (img_h * img_w) + 
                                          r * img_w + 
                                          c_idx;
                                          
                                if (images[idx] > max_val) {
                                    max_val = images[idx];
                                }
                            }
                        }
                        
                        int out_idx = b * (channels * out_h * out_w) + 
                                      c * (out_h * out_w) + 
                                      h * out_w + 
                                      w;
                        output[out_idx] = max_val;
                    }
                }
            }
        }
    }
}