import math
import random
import json
import numpy as np
from collections import Counter

# We now import exclusively from the Enterprise Tensor Stack
from .tensor import Tensor
from .nn_tensor import Module, Linear, LayerNorm, Dropout, GELU, CrossEntropyLoss, Sequential

# ==========================================
# 1. THE WORD ENGINE (BPETokenizer)
# ==========================================

class BPETokenizer(Module):
    """
    Learns words instead of characters. 
    Includes Chat boundaries: <|user|>, <|assistant|>, <|system|>.
    """
    def __init__(self, vocab_size=5000):
        super().__init__()
        self.vocab_size = vocab_size
        self.merges = {}
        self.vocab = {i: bytes([i]) for i in range(256)}
        
        self.special_tokens = {
            "<|endoftext|>": 256, "<|user|>": 257, 
            "<|assistant|>": 258, "<|system|>": 259
        }
        for token, idx in self.special_tokens.items():
            self.vocab[idx] = token.encode("utf-8")
        self.next_idx = 260

    def fit(self, text):
        ids = list(text.encode("utf-8"))
        num_merges = self.vocab_size - self.next_idx
        for i in range(num_merges):
            stats = Counter(zip(ids, ids[1:]))
            if not stats: break
            best_pair = max(stats, key=stats.get)
            idx = self.next_idx + i
            self.merges[best_pair] = idx
            self.vocab[idx] = self.vocab[best_pair[0]] + self.vocab[best_pair[1]]
            
            new_ids = []; skip = False
            for j in range(len(ids)):
                if skip: skip = False; continue
                if j < len(ids)-1 and (ids[j], ids[j+1]) == best_pair:
                    new_ids.append(idx); skip = True
                else: new_ids.append(ids[j])
            ids = new_ids

    def encode(self, text):
        tokens = list(text.encode("utf-8"))
        while len(tokens) >= 2:
            stats = Counter(zip(tokens, tokens[1:]))
            pair = min(stats.keys(), key=lambda p: self.merges.get(p, float('inf')))
            if pair not in self.merges: break
            idx = self.merges[pair]
            new_tokens = []; skip = False
            for i in range(len(tokens)):
                if skip: skip = False; continue
                if i < len(tokens)-1 and (tokens[i], tokens[i+1]) == pair:
                    new_tokens.append(idx); skip = True
                else: new_tokens.append(tokens[i])
            tokens = new_tokens
        return tokens

    def decode(self, ids):
        return b"".join(self.vocab.get(i, b"") for i in ids).decode("utf-8", errors="replace")

# ==========================================
# 2. EMBEDDINGS
# ==========================================

class Embedding(Module):
    def __init__(self, num_embeddings, embedding_dim):
        super().__init__()
        self.weight = Tensor(np.random.uniform(-0.1, 0.1, (num_embeddings, embedding_dim)))

    def __call__(self, indices):
        return Tensor(self.weight.data[indices])

# ==========================================
# 3. ROTARY POSITIONAL EMBEDDINGS (RoPE)
# ==========================================

def precompute_rope_freqs(dim, max_seq_len=8192):
    """Precomputes sine and cosine waves for spatial matrix rotation."""
    theta = 10000.0 ** (-np.arange(0, dim, 2)[: (dim // 2)].astype(np.float32) / dim)
    t = np.arange(max_seq_len, dtype=np.float32)
    freqs = np.outer(t, theta)
    
    freqs_cos = np.cos(freqs)
    freqs_sin = np.sin(freqs)
    freqs_cos = np.repeat(freqs_cos, 2, axis=-1)
    freqs_sin = np.repeat(freqs_sin, 2, axis=-1)
    return freqs_cos, freqs_sin

def apply_rope(x, freqs_cos, freqs_sin, start_pos=0):
    """Physically rotates the Query and Key vectors in multi-dimensional space."""
    T = x.shape[2]
    fc = Tensor(freqs_cos[start_pos : start_pos + T].reshape(1, 1, T, -1))
    fs = Tensor(freqs_sin[start_pos : start_pos + T].reshape(1, 1, T, -1))
    
    x_data = x.data if hasattr(x, 'data') else x
    x_rot = np.empty_like(x_data)
    
    x_rot[..., 0::2] = -x_data[..., 1::2]
    x_rot[..., 1::2] = x_data[..., 0::2]
    
    return x * fc + Tensor(x_rot) * fs

# ==========================================
# 4. MULTI-HEAD CAUSAL SELF-ATTENTION
# ==========================================

class CausalSelfAttention(Module):
    def __init__(self, n_embd, n_head=4, dropout=0.1, n_layer=1):
        super().__init__()
        assert n_embd % n_head == 0, "Embedding dimension must be divisible by number of heads."
        self.n_embd = n_embd
        self.n_head = n_head
        self.head_dim = n_embd // n_head
        
        self.q_proj = Linear(n_embd, n_embd)
        self.k_proj = Linear(n_embd, n_embd)
        self.v_proj = Linear(n_embd, n_embd)
        self.c_proj = Linear(n_embd, n_embd)
        
        self.c_proj.weight.data *= (1.0 / math.sqrt(2.0 * n_layer))
        self.resid_drop = Dropout(dropout)

        self.freqs_cos, self.freqs_sin = precompute_rope_freqs(self.head_dim)
        
        self.use_cache = False
        self.cache_k = None
        self.cache_v = None

    def clear_cache(self):
        self.cache_k = None
        self.cache_v = None

    def __call__(self, x, start_pos=0):
        B, T, C = x.shape
        
        q = self.q_proj(x).reshape(B, T, self.n_head, self.head_dim).transpose(0, 2, 1, 3)
        k = self.k_proj(x).reshape(B, T, self.n_head, self.head_dim).transpose(0, 2, 1, 3)
        v = self.v_proj(x).reshape(B, T, self.n_head, self.head_dim).transpose(0, 2, 1, 3)
        
        q = apply_rope(q, self.freqs_cos, self.freqs_sin, start_pos)
        k = apply_rope(k, self.freqs_cos, self.freqs_sin, start_pos)
        
        if self.use_cache:
            if start_pos == 0 or self.cache_k is None:
                self.cache_k = k.data
                self.cache_v = v.data
            else:
                self.cache_k = np.concatenate([self.cache_k, k.data], axis=2)
                self.cache_v = np.concatenate([self.cache_v, v.data], axis=2)
            
            k = Tensor(self.cache_k)
            v = Tensor(self.cache_v)
            T_total = self.cache_k.shape[2]
        else:
            T_total = T

        scores = q.matmul(k.transpose(0, 1, 3, 2)) * (self.head_dim ** -0.5)
        
        if T > 1 and T_total > 1:
            mask = np.triu(np.ones((T, T_total)), k=(T_total - T + 1)) * -1e9
            scores = scores + Tensor(mask)
        
        max_scores = scores.max(axis=-1, keepdims=True)
        exps = (scores - max_scores).exp()
        sum_exps = exps.sum(axis=-1, keepdims=True)
        probs = exps * Tensor(1.0 / (sum_exps.data + 1e-8))
        
        out = probs.matmul(v)
        out = out.transpose(0, 2, 1, 3).reshape(B, T, C)
        return self.resid_drop(self.c_proj(out))

# ==========================================
# 5. THE TRANSFORMER BLOCK
# ==========================================

class TransformerBlock(Module):
    def __init__(self, n_embd, n_head=4, dropout=0.1, n_layer=1):
        super().__init__()
        self.ln1 = LayerNorm(n_embd)
        self.attn = CausalSelfAttention(n_embd, n_head, dropout, n_layer)
        self.ln2 = LayerNorm(n_embd)
        
        self.mlp_c_fc = Linear(n_embd, 4*n_embd)
        self.mlp_act = GELU()
        self.mlp_c_proj = Linear(4*n_embd, n_embd)
        self.mlp_drop = Dropout(dropout)
        
        self.mlp_c_proj.weight.data *= (1.0 / math.sqrt(2.0 * n_layer))

    def __call__(self, x, start_pos=0):
        x = x + self.attn(self.ln1(x), start_pos)
        m = self.mlp_drop(self.mlp_c_proj(self.mlp_act(self.mlp_c_fc(self.ln2(x)))))
        x = x + m
        return x

# ==========================================
# 6. THE COMPLETE TENSOR GPT MODEL
# ==========================================

class GPT(Module):
    def __init__(self, vocab_size, block_size, n_embd=64, n_head=4, n_layer=2, dropout=0.1):
        super().__init__()
        self.block_size = block_size
        self.vocab_size = vocab_size
        
        self.token_embedding = Embedding(vocab_size, n_embd)
        self.drop = Dropout(dropout)
        
        self.blocks = Sequential(*[TransformerBlock(n_embd, n_head, dropout, n_layer) for _ in range(n_layer)])
        self.ln_f = LayerNorm(n_embd)

    def set_cache_mode(self, use_cache=True):
        for block in self.blocks.layers:
            block.attn.use_cache = use_cache
            
    def clear_kv_cache(self):
        for block in self.blocks.layers:
            block.attn.clear_cache()

    def __call__(self, idx, targets=None, start_pos=0):
        idx = np.array(idx)
        is_1d = False
        if len(idx.shape) == 1:
            is_1d = True
            idx = idx[np.newaxis, :]
            if targets is not None:
                targets = np.array(targets)[np.newaxis, :]

        B, T = idx.shape
        
        x = self.drop(self.token_embedding(idx))
        
        for block in self.blocks.layers:
            x = block(x, start_pos=start_pos)
            
        x = self.ln_f(x)
        logits = x.dot(self.token_embedding.weight.transpose())
        
        loss = None
        if targets is not None:
            logits_flat = logits.reshape(B * T, -1)
            targets_flat = targets.flatten()
            
            valid_indices = targets_flat != -100
            
            if np.any(valid_indices):
                valid_logits = Tensor(logits_flat.data[valid_indices])
                valid_targets = targets_flat[valid_indices]
                loss = CrossEntropyLoss()(valid_logits, valid_targets)
            else:
                loss = Tensor(np.array(0.0, dtype=np.float32))
            
        if is_1d:
            logits = logits.reshape(T, -1)
            
        return logits, loss

    # --- ENTERPRISE UPGRADE: DPO LOGPROB EXTRACTOR ---
    def get_dpo_logprobs(self, idx, targets):
        """
        Extracts the exact Log-Probabilities required for Direct Preference Optimization.
        Bypasses standard CrossEntropyLoss to return the math matrix directly.
        """
        logits, _ = self.__call__(idx)
        logits_data = logits.data if hasattr(logits, 'data') else logits
        
        # Numerically stable Log-Softmax
        max_logits = np.max(logits_data, axis=-1, keepdims=True)
        log_sum_exp = np.log(np.sum(np.exp(logits_data - max_logits), axis=-1, keepdims=True))
        log_probs = (logits_data - max_logits) - log_sum_exp
        
        B, T = targets.shape
        batch_idx = np.arange(B)[:, None]
        seq_idx = np.arange(T)[None, :]
        
        # Mask out the prompt (-100 targets) so we only calculate probabilities for the Assistant's reply
        valid_mask = (targets != -100)
        safe_targets = np.where(valid_mask, targets, 0)
        
        target_logprobs = log_probs[batch_idx, seq_idx, safe_targets]
        sequence_logprobs = np.sum(target_logprobs * valid_mask, axis=-1)
        
        return Tensor(sequence_logprobs)

    def chat_generate(self, prompt, tokenizer, max_new_tokens=150, temperature=0.75, top_k=40, repetition_penalty=1.2):
        self.eval()
        self.set_cache_mode(True)
        self.clear_kv_cache()
        
        formatted_prompt = f"<|system|>You are a helpful AI.<|user|>{prompt}<|assistant|>"
        idx = tokenizer.encode(formatted_prompt)
        
        start_pos = 0
        logits, _ = self.__call__(idx, start_pos=start_pos)
        next_token = self._sample_token(logits.data[-1], idx, temperature, top_k, repetition_penalty)
        idx.append(next_token)
        
        start_pos += len(idx) - 1
        
        for _ in range(1, max_new_tokens):
            if next_token == 256: 
                break
                
            idx_cond = [next_token]
            logits, _ = self.__call__(idx_cond, start_pos=start_pos)
            
            next_token = self._sample_token(logits.data[-1], idx, temperature, top_k, repetition_penalty)
            idx.append(next_token)
            start_pos += 1
                
        self.train()
        self.set_cache_mode(False)
        
        reply_ids = idx[len(tokenizer.encode(formatted_prompt)):]
        return tokenizer.decode(reply_ids)
        
    def _sample_token(self, last_logits, idx_history, temperature, top_k, repetition_penalty):
        if repetition_penalty != 1.0:
            for token_id in set(idx_history):
                if last_logits[token_id] < 0:
                    last_logits[token_id] *= repetition_penalty
                else:
                    last_logits[token_id] /= repetition_penalty

        scaled_logits = last_logits / temperature
        
        if top_k is not None:
            kth_val = np.sort(scaled_logits)[-top_k]
            scaled_logits[scaled_logits < kth_val] = -float('Inf')
        
        max_val = np.max(scaled_logits)
        e_x = np.exp(scaled_logits - max_val)
        probs = e_x / np.sum(e_x)
        
        return np.random.choice(len(probs), p=probs)

# ==========================================
# 7. ALIGNMENT (DIRECT PREFERENCE OPTIMIZATION)
# ==========================================

class DPOLoss(Module):
    """
    Direct Preference Optimization Loss Function.
    Replaces RLHF by computing the log-probability margin between 
    a Winning answer and a Losing answer directly on the weights.
    """
    def __init__(self, beta=0.1):
        super().__init__()
        self.beta = beta

    def __call__(self, policy_chosen_logps, policy_rejected_logps, ref_chosen_logps, ref_rejected_logps):
        # Calculate the log ratios for the Active Model (Policy)
        pi_logratios = policy_chosen_logps - policy_rejected_logps
        
        # Calculate the log ratios for the Frozen Model (Reference)
        ref_logratios = ref_chosen_logps - ref_rejected_logps
        
        # The margin between what the model wants to do vs. what the base model would have done
        logits = pi_logratios - ref_logratios
        
        # Numerically stable calculation of: -log(sigmoid(beta * logits))
        loss = np.log1p(np.exp(-self.beta * logits.data))
        
        return Tensor(loss.mean())