import tkinter as tk
from tkinter import font
import time
import math
import random

# ==========================================
# 1. PHYSICS & MATH CORE
# ==========================================
class Easing:
    @staticmethod
    def ease_out_cubic(t): return 1 - pow(1 - t, 3)
    
    @staticmethod
    def ease_in_out(t): return 4 * t * t * t if t < 0.5 else 1 - pow(-2 * t + 2, 3) / 2
    
    @staticmethod
    def spring(t): 
        # Dampened spring effect
        return pow(2, -10 * t) * math.sin((t * 10 - 0.75) * (2 * math.pi) / 3) + 1

class ColorUtils:
    @staticmethod
    def hex_to_rgb(hex_col):
        hex_col = hex_col.lstrip('#')
        return tuple(int(hex_col[i:i+2], 16) for i in (0, 2, 4))

    @staticmethod
    def rgb_to_hex(rgb):
        return '#%02x%02x%02x' % (int(max(0, min(255, rgb[0]))), int(max(0, min(255, rgb[1]))), int(max(0, min(255, rgb[2]))))

    @staticmethod
    def blend(c1, c2, t):
        r1, g1, b1 = ColorUtils.hex_to_rgb(c1)
        r2, g2, b2 = ColorUtils.hex_to_rgb(c2)
        return ColorUtils.rgb_to_hex((r1 + (r2 - r1) * t, g1 + (g2 - g1) * t, b1 + (b2 - b1) * t))

    @staticmethod
    def adjust_brightness(hex_col, factor):
        r, g, b = ColorUtils.hex_to_rgb(hex_col)
        return ColorUtils.rgb_to_hex((r * factor, g * factor, b * factor))

# ==========================================
# 2. RENDERING ENGINE (Visual Effects)
# ==========================================
class Painter:
    @staticmethod
    def rounded_poly(x, y, w, h, r):
        # Generates coordinates for a smooth rounded rectangle
        return [x+r, y, x+w-r, y, x+w, y, x+w, y+r, x+w, y+h-r, x+w, y+h, 
                x+w-r, y+h, x+r, y+h, x, y+h, x, y+h-r, x, y+r, x, y]

    @staticmethod
    def draw_style(cv, node, x, y, w, h):
        # 1. SHADOWS (Elevation System)
        if node.elevation > 0:
            offset = node.elevation * 2
            alpha_col = "#000" # Tkinter doesn't support real alpha on canvas shapes easily, simulating with stipple
            # Simple offset shadow
            cv.create_polygon(Painter.rounded_poly(x+offset, y+offset, w, h, node.radius), 
                              fill="#000000", stipple="gray25", smooth=True, width=0)

        # 2. NEUMORPHISM
        if node.style == "neumorph":
            # Dark Shadow (Bottom Right)
            cv.create_polygon(Painter.rounded_poly(x+3, y+3, w, h, node.radius), 
                              fill=ColorUtils.blend(node.bg, "#000", 0.4), smooth=True, width=0)
            # Light Highlight (Top Left)
            cv.create_polygon(Painter.rounded_poly(x-2, y-2, w, h, node.radius), 
                              fill=ColorUtils.blend(node.bg, "#fff", 0.2), smooth=True, width=0)
            # Base
            cv.create_polygon(Painter.rounded_poly(x, y, w, h, node.radius), 
                              fill=node.bg, smooth=True, width=0)

        # 3. GLASSMORPHISM
        elif node.style == "glass":
            # Simulate Blur/Glass with semi-transparent overlay logic
            # Border highlight
            cv.create_polygon(Painter.rounded_poly(x, y, w, h, node.radius), 
                              fill=node.bg, outline=ColorUtils.blend(node.bg, "#fff", 0.3), width=1, smooth=True)
            # Inner Shine
            cv.create_line(x+node.radius, y+1, x+w-node.radius, y+1, fill="#ffffff", width=1)

        # 4. STANDARD FLAT / GRADIENT
        else:
            border = node.border_color if node.border_color else ""
            bw = 1 if border else 0
            cv.create_polygon(Painter.rounded_poly(x, y, w, h, node.radius), 
                              fill=node.bg, outline=border, width=bw, smooth=True)

        # 5. ACCENT GLOW
        if node.glow:
            cv.create_polygon(Painter.rounded_poly(x-2, y-2, w+4, h+4, node.radius), 
                              fill=node.glow, stipple="gray12", smooth=True, width=0)

# ==========================================
# 3. THE NODE (Animation & State)
# ==========================================
class Node:
    def __init__(self, **kw):
        # Layout Config
        self.w_req = kw.get("w", "100%") 
        self.h_req = kw.get("h", "auto")
        self.min_w = kw.get("min_w", 0)
        self.min_h = kw.get("min_h", 0)
        self.pad = kw.get("padding", 0)
        self.gap = kw.get("gap", 0)
        self.align = kw.get("align", "start") # start, center, end
        
        # Visual Config
        self.bg = kw.get("bg", "")
        self.style = kw.get("style", "flat") # flat, neumorph, glass
        self.radius = kw.get("radius", 0)
        self.elevation = kw.get("elevation", 0)
        self.border_color = kw.get("border", None)
        self.glow = kw.get("glow", None)
        self.opacity = kw.get("opacity", 1.0)
        
        # Text Config
        self.text = kw.get("text", "")
        self.text_col = kw.get("text_color", "#fff")
        self.font = kw.get("font", ("Segoe UI", 10))
        
        # State & Animation
        self.children = []
        self.parent = None
        self.hovered = False
        self.pressed = False
        self.on_click = kw.get("on_click", None)
        
        self.anim_props = {"scale": 1.0, "offset_y": 0, "alpha": 1.0}
        self.animations = {}
        
        # Calculated Geometry (The Rect)
        self.x = 0
        self.y = 0
        self.w = 0 
        self.h = 0

    def add(self, child):
        child.parent = self
        self.children.append(child)
        return child

    def animate(self, key, end_val, duration=0.3, curve="ease_out"):
        self.animations[key] = {
            "start": self.anim_props.get(key, 0),
            "end": end_val,
            "start_time": time.time(),
            "duration": duration,
            "curve": curve
        }

    def update_animations(self):
        now = time.time()
        finished = []
        for k, a in self.animations.items():
            progress = (now - a["start_time"]) / a["duration"]
            if progress >= 1.0:
                progress = 1.0
                finished.append(k)
            
            # Easing Selection
            if a["curve"] == "spring": t = Easing.spring(progress)
            else: t = Easing.ease_out_cubic(progress)
            
            self.anim_props[k] = a["start"] + (a["end"] - a["start"]) * t
            
        for k in finished: del self.animations[k]

    # --- MEASURE PASS (Fixes Overlap) ---
    def measure(self, parent_w, parent_h):
        # Resolve Width
        if self.w_req == "flex": self.w = 0 # Placeholder, resolved by parent
        elif isinstance(self.w_req, str) and "%" in self.w_req:
            self.w = (float(self.w_req.strip("%")) / 100) * parent_w
        else: self.w = self.w_req

        # Resolve Height
        if isinstance(self.h_req, int): self.h = self.h_req
        elif isinstance(self.h_req, str) and "%" in self.h_req:
            self.h = (float(self.h_req.strip("%")) / 100) * parent_h
        else: self.h = self.min_h # Default to min, expand later

    # --- LAYOUT PASS ---
    def layout(self, x, y):
        self.x = x
        self.y = y
        # Default layout for generic node: just fit children
        cur_x, cur_y = x + self.pad, y + self.pad
        for c in self.children:
            c.measure(self.w - self.pad*2, self.h - self.pad*2)
            c.layout(cur_x, cur_y)

    def render(self, cv):
        self.update_animations()
        
        # Apply Animation Transforms
        s = self.anim_props["scale"]
        oy = self.anim_props["offset_y"]
        
        final_w = self.w * s
        final_h = self.h * s
        final_x = self.x + (self.w - final_w)/2
        final_y = self.y + (self.h - final_h)/2 + oy
        
        # Culling optimization
        if final_y > 2000 or final_y + final_h < 0: return

        # Draw Background/Shape
        if self.bg: Painter.draw_style(cv, self, final_x, final_y, final_w, final_h)

        # Draw Text
        if self.text:
            cv.create_text(final_x + final_w/2, final_y + final_h/2, 
                           text=self.text, fill=self.text_col, font=self.font)

        # Render Children
        for c in self.children: c.render(cv)

# ==========================================
# 4. FLEX LAYOUT ENGINE (Fixes the Overlap)
# ==========================================
class Row(Node):
    def measure(self, parent_w, parent_h):
        super().measure(parent_w, parent_h)
        avail_w = self.w - (self.pad * 2)
        total_gap = (len(self.children) - 1) * self.gap if self.children else 0
        avail_w -= total_gap
        
        # 1. Measure fixed children first
        used_w = 0
        flex_children = []
        
        for c in self.children:
            if c.w_req == "flex":
                flex_children.append(c)
            else:
                c.measure(avail_w, self.h) # Measure fixed width
                used_w += c.w
        
        # 2. Distribute remaining space to flex children
        if flex_children:
            flex_w = max(0, (avail_w - used_w) / len(flex_children))
            for c in flex_children:
                c.w = flex_w # Force width
                c.measure(flex_w, self.h) # Recursively measure child height

    def layout(self, x, y):
        self.x, self.y = x, y
        cx = x + self.pad
        cy = y + self.pad
        max_h = 0
        
        for c in self.children:
            # Vertical Alignment Logic
            child_y = cy
            if self.align == "center": child_y = cy + (self.h - self.pad*2 - c.h)/2
            elif self.align == "end": child_y = cy + (self.h - self.pad*2 - c.h)
            
            c.layout(cx, child_y)
            cx += c.w + self.gap
            max_h = max(max_h, c.h)
            
        if self.h_req == "auto": self.h = max_h + self.pad*2

class Column(Node):
    def measure(self, parent_w, parent_h):
        super().measure(parent_w, parent_h)
        avail_w = self.w - (self.pad * 2)
        
        # Columns usually dictate width to children
        for c in self.children:
            c.measure(avail_w, parent_h) 

    def layout(self, x, y):
        self.x, self.y = x, y
        cx = x + self.pad
        cy = y + self.pad
        
        for c in self.children:
            c.layout(cx, cy)
            cy += c.h + self.gap
            
        if self.h_req == "auto": self.h = cy - y + self.pad

class Scroll(Node):
    def __init__(self, **kw):
        super().__init__(**kw)
        self.scroll_y = 0
        self.content_h = 0
        
    def layout(self, x, y):
        self.x, self.y = x, y
        cx = x + self.pad
        # Virtual Y position based on scroll
        cy = y + self.pad - self.scroll_y 
        
        for c in self.children:
            c.measure(self.w - self.pad*2, 9999)
            c.layout(cx, cy)
            cy += c.h + self.gap
        
        self.content_h = cy + self.scroll_y - y

    def on_scroll(self, delta):
        self.scroll_y -= delta
        # Clamp scrolling
        max_scroll = max(0, self.content_h - self.h)
        self.scroll_y = max(0, min(self.scroll_y, max_scroll))

# ==========================================
# 5. COMPONENT SYSTEM (UI Blocks)
# ==========================================
class Button(Node):
    def __init__(self, text, variant="primary", **kw):
        cols = {"primary": "#3b82f6", "danger": "#ef4444", "ghost": "#27272a"}
        kw.setdefault("bg", cols.get(variant, "#3b82f6"))
        kw.setdefault("h", 40)
        kw.setdefault("radius", 8)
        kw.setdefault("align", "center")
        kw.setdefault("text", text)
        super().__init__(**kw)
        self.base_bg = self.bg

class Input(Node):
    def __init__(self, placeholder, **kw):
        kw.setdefault("h", 40)
        kw.setdefault("bg", "#18181b")
        kw.setdefault("radius", 6)
        kw.setdefault("border", "#333")
        super().__init__(**kw)
        self.placeholder = placeholder
        self.tk_entry = None

    def render(self, cv):
        super().render(cv)
        if not self.tk_entry and cv.master:
            self.tk_entry = tk.Entry(cv.master, bg=self.bg, fg="white", 
                                     bd=0, insertbackground="white", font=("Segoe UI", 10))
            self.tk_entry.insert(0, self.placeholder)
            
        if self.tk_entry:
            # Hide if scrolled out of view
            if self.y < 0 or self.y > 1000: self.tk_entry.place_forget()
            else: self.tk_entry.place(x=self.x+10, y=self.y+10, width=self.w-20, height=self.h-20)

class Toggle(Node):
    def __init__(self, active=False, **kw):
        kw.setdefault("w", 50)
        kw.setdefault("h", 28)
        kw.setdefault("radius", 14)
        super().__init__(**kw)
        self.active = active
        self.bg = "#3b82f6" if active else "#3f3f46"
        self.on_click = self._toggle
        self.anim_props["knob_x"] = 28 if active else 4

    def _toggle(self):
        self.active = not self.active
        self.bg = "#3b82f6" if self.active else "#3f3f46"
        target = 28 if self.active else 4
        self.animate("knob_x", target, 0.4, "spring")

    def render(self, cv):
        super().render(cv)
        # Draw Knob
        kx = self.x + self.anim_props["knob_x"]
        ky = self.y + 4
        cv.create_oval(kx, ky, kx+20, ky+20, fill="white", outline="")

class Chart(Node):
    def __init__(self, data, color="#8b5cf6", **kw):
        kw.setdefault("h", 150)
        kw.setdefault("bg", "#111")
        kw.setdefault("radius", 10)
        super().__init__(**kw)
        self.data = data
        self.color = color

    def render(self, cv):
        super().render(cv)
        if not self.data: return
        
        # Simple Bar Chart rendering
        margin = 10
        bar_w = (self.w - margin*2) / len(self.data)
        max_val = max(self.data)
        
        for i, val in enumerate(self.data):
            h = (val / max_val) * (self.h - 30)
            bx = self.x + margin + i * bar_w
            by = self.y + self.h - 10
            
            # Gradient-ish effect by varying lightness
            col = self.color
            if i % 2 == 0: col = ColorUtils.adjust_brightness(col, 0.9)
            
            cv.create_rectangle(bx, by-h, bx+bar_w-2, by, fill=col, outline="")

# ==========================================
# 6. APP RUNTIME
# ==========================================
class App:
    def __init__(self):
        self.root = tk.Tk()
        self.root.geometry("1100x750")
        self.root.title("Nova Engine V2")
        self.root.configure(bg="#09090b")
        
        self.canvas = tk.Canvas(self.root, bg="#09090b", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        
        self.root_node = Row(w="100%", h="100%", bg="#09090b", gap=0)
        
        # Event Binding
        self.root.bind("<Configure>", lambda e: self.loop())
        self.canvas.bind("<Motion>", self.on_hover)
        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<MouseWheel>", self.on_scroll)
        
        self.loop()

    # Hit Testing (Recursive)
    def hit_test(self, node, x, y):
        if x >= node.x and x <= node.x + node.w and y >= node.y and y <= node.y + node.h:
            # Check children reverse (z-index)
            for c in reversed(node.children):
                res = self.hit_test(c, x, y)
                if res: return res
            return node
        return None

    def on_hover(self, e):
        target = self.hit_test(self.root_node, e.x, e.y)
        # Reset all hovers (simple approach)
        self._clear_hovers(self.root_node)
        
        if target and target.on_click: # Only animate interactive elements
            target.hovered = True
            target.animate("scale", 1.02, 0.2)
            self.root.config(cursor="hand2")
        else:
            self.root.config(cursor="")

    def _clear_hovers(self, node):
        if node.hovered: 
            node.hovered = False
            node.animate("scale", 1.0, 0.2)
        for c in node.children: self._clear_hovers(c)

    def on_click(self, e):
        target = self.hit_test(self.root_node, e.x, e.y)
        if target and target.on_click:
            target.on_click()
            # Ripple / Press effect
            target.animate("scale", 0.95, 0.1)
            self.root.after(100, lambda: target.animate("scale", 1.02, 0.1))

    def on_scroll(self, e):
        # Find scroll container under mouse
        target = self.hit_test(self.root_node, e.x, e.y)
        while target:
            if isinstance(target, Scroll):
                target.on_scroll(e.delta)
                break
            target = target.parent

    def loop(self):
        self.canvas.delete("all")
        w = self.root.winfo_width()
        h = self.root.winfo_height()
        
        # 1. Measure (The Fix)
        self.root_node.measure(w, h)
        # 2. Layout
        self.root_node.layout(0, 0)
        # 3. Render
        self.root_node.render(self.canvas)
        
        self.root.after(16, self.loop)

    def run(self): self.root.mainloop()

# ==========================================
# 7. IMPLEMENTATION (DEMO UI)
# ==========================================
if __name__ == "__main__":
    app = App()
    
    # --- Sidebar ---
    sidebar = Column(w=260, h="100%", bg="#18181b", padding=20, gap=10)
    sidebar.add(Node(text="NOVA V2", font=("Segoe UI", 20, "bold"), h=50, text_color="#60a5fa"))
    
    for label in ["Dashboard", "Analytics", "Team", "Settings", "Logout"]:
        btn_style = "danger" if label == "Logout" else "ghost"
        sidebar.add(Button(text=label, variant=btn_style, w="100%", align="start"))

    # --- Main Content ---
    main = Scroll(w="flex", h="100%", bg="#09090b", padding=30, gap=20)
    
    # Hero Section
    hero = Row(w="100%", h=120, gap=20)
    
    # Glassmorphism Card
    glass_card = Node(w="flex", h="100%", bg="#2563eb", style="glass", radius=15, padding=15)
    glass_card.add(Node(text="Glassmorphism", font=("Segoe UI", 14, "bold"), h=30))
    glass_card.add(Node(text="Blur overlay active", text_color="#bfdbfe"))
    hero.add(glass_card)
    
    # Neumorphism Card
    neu_card = Node(w="flex", h="100%", bg="#27272a", style="neumorph", radius=15, padding=15)
    neu_card.add(Node(text="Neumorphism", font=("Segoe UI", 14, "bold"), h=30))
    neu_card.add(Node(text="Soft shadows & depth", text_color="#a1a1aa"))
    hero.add(neu_card)
    
    main.add(hero)
    
    # Stats Row (Charts)
    stats = Row(w="100%", h=200, gap=20)
    stats.add(Chart(data=[10, 40, 30, 70, 50, 90, 20, 60], w="flex"))
    stats.add(Chart(data=[80, 20, 40, 30, 60, 10, 50, 40], color="#ec4899", w="flex"))
    main.add(stats)
    
    # Form Section
    form = Node(w="100%", h=250, bg="#18181b", radius=12, padding=20, gap=15)
    form.children.append(Node(text="User Settings", font=("Segoe UI", 14), h=30))
    
    input_row = Row(w="100%", h=50, gap=15)
    input_row.add(Input(placeholder="First Name", w="flex"))
    input_row.add(Input(placeholder="Last Name", w="flex"))
    form.children.append(input_row)
    
    toggle_row = Row(w="100%", h=40, gap=20, align="center")
    toggle_row.add(Node(text="Enable Notifications", w="flex"))
    toggle_row.add(Toggle(active=True))
    form.children.append(toggle_row)
    
    form.children.append(Button(text="Save Changes", w="100%"))
    
    main.add(form)

    # Attach to Root
    app.root_node.add(sidebar)
    app.root_node.add(main)
    
    app.run()