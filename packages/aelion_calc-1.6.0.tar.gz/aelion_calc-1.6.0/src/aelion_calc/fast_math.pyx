# cython: language_level=3
# cython: boundscheck=False
# cython: wraparound=False

import numpy as np
cimport numpy as np

def fast_dot(double[:, :] A, double[:, :] B):
    """
    ULTRA FAST Matrix Multiplication using Memoryviews.
    Instead of 'list', we use 'double[:, :]' which accesses raw memory.
    """
    cdef int rows_A = A.shape[0]
    cdef int cols_A = A.shape[1]
    cdef int rows_B = B.shape[0]
    cdef int cols_B = B.shape[1]
    
    if cols_A != rows_B:
        raise ValueError("Shape mismatch")
        
    # Pre-allocate a C-contiguous array for speed
    cdef double[:, :] result = np.zeros((rows_A, cols_B), dtype=np.float64)
    
    cdef int i, j, k
    cdef double current_sum
    
    # This triple loop now runs in pure C at CPU speed
    for i in range(rows_A):
        for j in range(cols_B):
            current_sum = 0.0
            for k in range(cols_A):
                current_sum += A[i][k] * B[k][j]
            result[i, j] = current_sum
            
    return np.asarray(result)