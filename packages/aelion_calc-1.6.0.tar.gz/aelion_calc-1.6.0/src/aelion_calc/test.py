from aelion_calc import Camera, AelionVision

# 1. Boot up the unified AI Vision Engine
ai = AelionVision(enable_hands=True, enable_body=True, enable_face=True)

# 2. Start the camera loop
for frame in Camera().stream():
    
    # 3. Scan the frame for everything (hands, body, and face)
    scan_data = ai.scan(frame, draw=True)
    
    # --- PLAYFUL LOGIC EXAMPLES ---
    
    # Example A: Fitness Tracking (Bicep Curls)
    body = scan_data["body"]
    if body:
        arm_angle = body.angle('right_arm')
        frame.write(f"Arm Angle: {int(arm_angle)}", x=50, y=100)
        
        if arm_angle < 45:
            frame.write("GOOD FLEX!", x=50, y=150, color=(0, 255, 255))

    # Example B: Gesture Control
    for hand in scan_data["hands"]:
        if hand.gesture() == "Peace":
            frame.write("Peace Sign!", x=400, y=100)

    # Example C: Face Tracking
    face = scan_data["face"]
    if face:
        nx, ny = face.nose()
        # Draw a red circle on the nose!
        import cv2
        cv2.circle(frame.data, (nx, ny), 15, (0, 0, 255), cv2.FILLED)

    # 4. Show the frame
    if not frame.show():
        break