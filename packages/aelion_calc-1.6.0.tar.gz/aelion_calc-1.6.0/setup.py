import sys
import os
from setuptools import setup, Extension
from Cython.Build import cythonize
import numpy as np

# 1. Determine the correct OpenMP flags based on the Operating System
if sys.platform.startswith("win"):
    # UPDATED FOR MICROSOFT MSVC:
    # We are using the official Microsoft compiler now! 
    omp_compile_args = ['/openmp']
    omp_link_args = []
elif sys.platform.startswith("darwin"):
    # macOS clang flags (Note: requires user to have libomp installed via Homebrew)
    omp_compile_args = ['-Xpreprocessor', '-fopenmp']
    omp_link_args = ['-lomp']
else:
    # Linux GCC flags (Google Colab, Ubuntu, etc.)
    omp_compile_args = ['-fopenmp']
    omp_link_args = ['-fopenmp']

# 2. Define the Extensions
extensions = [
    # fast_math: Standard C extension (no OpenMP needed)
    Extension(
        name="aelion_calc.fast_math",
        sources=["src/aelion_calc/fast_math.pyx"],
        include_dirs=[np.get_include()]
    ),
    
    # fast_tensor: C++ extension requiring OpenMP for multi-threading
    Extension(
        name="aelion_calc.fast_tensor",
        sources=["src/aelion_calc/fast_tensor.pyx"],
        include_dirs=[np.get_include()],
        language="c++",                         # Required by your # distutils: language = c++ tag
        extra_compile_args=omp_compile_args,    # Injects the OS-specific OpenMP compile flag
        extra_link_args=omp_link_args           # Injects the OS-specific OpenMP link flag
    )
]

# 3. Run Setup
setup(
    name="aelion_calc", # Make sure this matches your package name
    version="1.5.5",    
    ext_modules=cythonize(extensions, compiler_directives={'language_level': "3"}),
    zip_safe=False,
)