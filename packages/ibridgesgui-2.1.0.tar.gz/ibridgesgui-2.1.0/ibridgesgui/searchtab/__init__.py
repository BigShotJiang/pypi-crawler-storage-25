"""Search tab functionality."""
