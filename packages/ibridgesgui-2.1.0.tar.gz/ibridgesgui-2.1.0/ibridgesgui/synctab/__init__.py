"""Sync tab."""
