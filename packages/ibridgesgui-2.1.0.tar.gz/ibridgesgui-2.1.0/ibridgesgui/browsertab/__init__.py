"""Browser tab."""
