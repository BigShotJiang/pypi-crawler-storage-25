# wrg-rule-lab

A lightweight, local-first, deterministic rule evaluation engine for Python.

Define rules in JSON, evaluate them against any context, detect conflicts, and simulate outcomes — with zero external dependencies.

[![PyPI version](https://img.shields.io/pypi/v/wrg-rule-lab.svg)](https://pypi.org/project/wrg-rule-lab/)
[![Python 3.11+](https://img.shields.io/pypi/pyversions/wrg-rule-lab.svg)](https://pypi.org/project/wrg-rule-lab/)
[![CI](https://github.com/WRG-11/wrg-rule-lab/actions/workflows/ci.yml/badge.svg)](https://github.com/WRG-11/wrg-rule-lab/actions/workflows/ci.yml)
[![CodeQL](https://github.com/WRG-11/wrg-rule-lab/actions/workflows/codeql.yml/badge.svg)](https://github.com/WRG-11/wrg-rule-lab/actions/workflows/codeql.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> **Note:** Previously published as `rule-lab` on PyPI. Access to that account was lost; releases continue here as `wrg-rule-lab` under the WRG namespace. The import path `rule_lab` is unchanged.

## Installation
```bash
pip install wrg-rule-lab
```

## Quick Start
```python
from rule_lab import load_rules_from_dict, evaluate_rules

ruleset = {
    "rules": [
        {
            "rule_id": "r1",
            "name": "Block high risk",
            "conditions": [{"field": "risk_score", "op": "gt", "value": 80}],
            "action": "block",
            "priority": 10
        }
    ]
}

rules = load_rules_from_dict(ruleset)
result = evaluate_rules(rules, context={"risk_score": 95})

print(result.matched_count)    # 1
print(result.results[0].action)  # block
```

## CLI
```bash
# Validate a rule file
rule-lab validate --rules rules.json

# Simulate rules against a list of contexts
rule-lab simulate --rules rules.json --contexts contexts.json

# Detect conflicting rules
rule-lab diff --rules rules.json
```

## API Reference

| Function | Description |
|---|---|
| `load_rules_from_file(path)` | Load rules from a JSON file |
| `load_rules_from_dict(data)` | Load rules from a dict |
| `load_rules_from_list(rules)` | Load rules from a list |
| `evaluate_rule(rule, context)` | Evaluate a single rule |
| `evaluate_rules(rules, context)` | Evaluate a list of rules |
| `simulate(rules, contexts)` | Simulate multiple contexts |

## Rule Format
```json
{
  "rules": [
    {
      "rule_id": "unique-id",
      "name": "Human readable name",
      "conditions": [
        {"field": "score", "op": "gt", "value": 50}
      ],
      "action": "approve",
      "priority": 10,
      "tags": ["finance", "v1"],
      "metadata": {}
    }
  ]
}
```

## Use Cases

- **AI release gating** — validate LLM app outputs before production
- **Policy enforcement** — define and run compliance rules as code
- **Decision engines** — replace hardcoded if/else logic with JSON rules
- **Audit trails** — every rule evaluation is traceable and reproducible

## Design Principles

- **Zero dependencies** — stdlib only, no surprise installs
- **Deterministic** — same input always produces same output
- **Local-first** — no network calls, no cloud required
- **Testable** — every rule is independently verifiable

## License

MIT — built by [WinstonRedGuard](https://github.com/WRG-11)
