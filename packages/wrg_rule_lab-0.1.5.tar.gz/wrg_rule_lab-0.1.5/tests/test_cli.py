from __future__ import annotations

import json
from pathlib import Path

import pytest

from rule_lab.cli import main


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

VALID_RULE = {
    "rule_id": "r1",
    "name": "Score threshold",
    "conditions": [{"field": "score", "op": "gte", "value": 7.0}],
    "action": "keep",
    "priority": 1,
}

CONFLICTING_RULE = {
    "rule_id": "r2",
    "name": "Score threshold conflict",
    "conditions": [{"field": "score", "op": "gte", "value": 7.0}],
    "action": "discard",
    "priority": 1,
}


def _write_rules(path: Path, rules: list) -> None:
    path.write_text(json.dumps({"rules": rules}), encoding="utf-8")


def _write_contexts(path: Path, contexts: list) -> None:
    path.write_text(json.dumps(contexts), encoding="utf-8")


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------

def test_validate_ok(tmp_path: Path) -> None:
    rules_file = tmp_path / "rules.json"
    _write_rules(rules_file, [VALID_RULE])
    rc = main(["validate", "--rules", str(rules_file)])
    assert rc == 0


def test_validate_missing_file_returns_nonzero() -> None:
    rc = main(["validate", "--rules", "/nonexistent/rules.json"])
    assert rc != 0


def test_validate_invalid_json(tmp_path: Path) -> None:
    rules_file = tmp_path / "bad.json"
    rules_file.write_text("NOT JSON", encoding="utf-8")
    rc = main(["validate", "--rules", str(rules_file)])
    assert rc != 0


# ---------------------------------------------------------------------------
# simulate
# ---------------------------------------------------------------------------

def test_simulate_ok(tmp_path: Path) -> None:
    rules_file = tmp_path / "rules.json"
    contexts_file = tmp_path / "contexts.json"
    _write_rules(rules_file, [VALID_RULE])
    _write_contexts(contexts_file, [{"score": 8.0}, {"score": 3.0}])
    rc = main(["simulate", "--rules", str(rules_file), "--contexts", str(contexts_file)])
    assert rc == 0


def test_simulate_json_flag(tmp_path: Path) -> None:
    rules_file = tmp_path / "rules.json"
    contexts_file = tmp_path / "contexts.json"
    _write_rules(rules_file, [VALID_RULE])
    _write_contexts(contexts_file, [{"score": 8.0}])
    rc = main(["simulate", "--rules", str(rules_file), "--contexts", str(contexts_file), "--json"])
    assert rc == 0


def test_simulate_writes_out_file(tmp_path: Path) -> None:
    rules_file = tmp_path / "rules.json"
    contexts_file = tmp_path / "contexts.json"
    out_file = tmp_path / "report.json"
    _write_rules(rules_file, [VALID_RULE])
    _write_contexts(contexts_file, [{"score": 8.0}])
    rc = main(["simulate", "--rules", str(rules_file), "--contexts", str(contexts_file), "--out", str(out_file)])
    assert rc == 0
    assert out_file.exists()
    parsed = json.loads(out_file.read_text(encoding="utf-8"))
    assert "runs" in parsed


def test_simulate_missing_contexts_returns_nonzero(tmp_path: Path) -> None:
    rules_file = tmp_path / "rules.json"
    _write_rules(rules_file, [VALID_RULE])
    rc = main(["simulate", "--rules", str(rules_file), "--contexts", str(tmp_path / "missing.json")])
    assert rc != 0


# ---------------------------------------------------------------------------
# diff
# ---------------------------------------------------------------------------

def test_diff_no_conflicts_returns_zero(tmp_path: Path) -> None:
    rules_file = tmp_path / "rules.json"
    _write_rules(rules_file, [VALID_RULE])
    rc = main(["diff", "--rules", str(rules_file)])
    assert rc == 0


def test_diff_with_conflicts_returns_nonzero(tmp_path: Path) -> None:
    rules_file = tmp_path / "rules.json"
    _write_rules(rules_file, [VALID_RULE, CONFLICTING_RULE])
    rc = main(["diff", "--rules", str(rules_file)])
    assert rc != 0


def test_diff_json_flag(tmp_path: Path) -> None:
    rules_file = tmp_path / "rules.json"
    _write_rules(rules_file, [VALID_RULE, CONFLICTING_RULE])
    rc = main(["diff", "--rules", str(rules_file), "--json"])
    assert rc != 0
