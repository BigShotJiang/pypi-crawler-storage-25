from __future__ import annotations
import json
from pathlib import Path
from rule_lab.core.contracts import Rule
from rule_lab.core.evaluator import evaluate_rules, simulate
from rule_lab.core.conflicts import detect_conflicts
from rule_lab.core.reporting import build_run_report, build_batch_report, format_text_report, write_report


def _rule(rule_id: str, conditions: list, action: str) -> Rule:
    return Rule(rule_id=rule_id, name=rule_id, conditions=conditions, action=action)


RULE_KEEP = _rule("r1", [{"field": "score", "op": "gte", "value": 7.0}], "keep")
RULE_DISCARD = _rule("r2", [{"field": "score", "op": "lt", "value": 4.0}], "discard")


def test_build_run_report_shape():
    ctx = {"score": 8.0}
    batch = evaluate_rules([RULE_KEEP, RULE_DISCARD], ctx)
    conflicts = detect_conflicts([RULE_KEEP, RULE_DISCARD])
    report = build_run_report(batch, conflicts, ctx)

    for key in ("context", "total_rules", "matched_count", "conflict_count", "results", "conflicts"):
        assert key in report


def test_build_batch_report_shape():
    contexts = [{"score": 8.0}, {"score": 2.0}]
    results = simulate([RULE_KEEP, RULE_DISCARD], contexts)
    conflicts = detect_conflicts([RULE_KEEP, RULE_DISCARD])
    report = build_batch_report(results, conflicts, contexts)

    assert report["total_contexts"] == 2
    assert report["total_rules"] == 2
    assert len(report["runs"]) == 2


def test_format_text_report_is_string():
    ctx = {"score": 8.0}
    batch = evaluate_rules([RULE_KEEP], ctx)
    report = build_run_report(batch, [], ctx)
    text = format_text_report(report)
    assert isinstance(text, str)
    assert "rule_lab report" in text


def test_write_report_creates_file(tmp_path: Path):
    ctx = {"score": 8.0}
    batch = evaluate_rules([RULE_KEEP], ctx)
    report = build_run_report(batch, [], ctx)
    out = tmp_path / "out" / "report.json"
    write_report(report, out)
    assert out.exists()
    parsed = json.loads(out.read_text(encoding="utf-8"))
    assert "total_rules" in parsed
