from __future__ import annotations
import json
from pathlib import Path
import pytest
from rule_lab.core.loader import load_rules_from_dict, load_rules_from_file, load_rules_from_list
from rule_lab.core.errors import RuleLoadError, RuleValidationError


VALID_RULE = {
    "rule_id": "r1",
    "name": "Score threshold",
    "conditions": [{"field": "score", "op": "gte", "value": 7.0}],
    "action": "keep",
    "priority": 5,
}


def test_load_from_dict():
    rules = load_rules_from_dict({"rules": [VALID_RULE]})
    assert len(rules) == 1
    assert rules[0].rule_id == "r1"
    assert rules[0].action == "keep"


def test_load_from_list():
    rules = load_rules_from_list([VALID_RULE])
    assert len(rules) == 1


def test_load_empty_ruleset():
    rules = load_rules_from_dict({"rules": []})
    assert rules == []


def test_missing_required_field_raises():
    bad = {k: v for k, v in VALID_RULE.items() if k != "action"}
    with pytest.raises(RuleValidationError, match="action"):
        load_rules_from_list([bad])


def test_conditions_not_list_raises():
    bad = {**VALID_RULE, "conditions": "not_a_list"}
    with pytest.raises(RuleValidationError):
        load_rules_from_list([bad])


def test_rules_field_not_list_raises():
    with pytest.raises(RuleLoadError):
        load_rules_from_dict({"rules": "bad"})


def test_load_from_file(tmp_path: Path):
    f = tmp_path / "rules.json"
    f.write_text(json.dumps({"rules": [VALID_RULE]}), encoding="utf-8")
    rules = load_rules_from_file(f)
    assert len(rules) == 1


def test_load_from_missing_file_raises():
    with pytest.raises(RuleLoadError, match="not found"):
        load_rules_from_file("/nonexistent/path/rules.json")


def test_load_from_invalid_json_raises(tmp_path: Path):
    f = tmp_path / "bad.json"
    f.write_text("NOT JSON", encoding="utf-8")
    with pytest.raises(RuleLoadError, match="invalid JSON"):
        load_rules_from_file(f)


def test_priority_ordering():
    rules_data = [
        {**VALID_RULE, "rule_id": "low", "priority": 1},
        {**VALID_RULE, "rule_id": "high", "priority": 10},
    ]
    rules = load_rules_from_list(rules_data)
    assert rules[0].rule_id == "high"
    assert rules[1].rule_id == "low"
