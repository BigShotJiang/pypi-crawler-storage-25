from __future__ import annotations
from rule_lab.core.contracts import Rule
from rule_lab.core.conflicts import detect_conflicts


def _rule(rule_id: str, conditions: list, action: str) -> Rule:
    return Rule(rule_id=rule_id, name=rule_id, conditions=conditions, action=action)


COND_A = {"field": "score", "op": "gte", "value": 7.0}
COND_B = {"field": "status", "op": "eq", "value": "ok"}


def test_no_conflicts_when_same_action():
    rules = [
        _rule("r1", [COND_A], "keep"),
        _rule("r2", [COND_A], "keep"),
    ]
    assert detect_conflicts(rules) == []


def test_conflict_detected_when_different_actions():
    rules = [
        _rule("r1", [COND_A], "keep"),
        _rule("r2", [COND_A], "discard"),
    ]
    conflicts = detect_conflicts(rules)
    assert len(conflicts) == 1
    assert conflicts[0].conflict_type == "action_conflict"
    assert "r1" in conflicts[0].rule_a or "r1" in conflicts[0].rule_b


def test_no_conflict_when_conditions_differ():
    rules = [
        _rule("r1", [COND_A], "keep"),
        _rule("r2", [COND_B], "discard"),
    ]
    assert detect_conflicts(rules) == []


def test_no_conflict_when_no_conditions():
    rules = [
        _rule("r1", [], "keep"),
        _rule("r2", [], "discard"),
    ]
    assert detect_conflicts(rules) == []


def test_conflict_report_to_dict():
    rules = [
        _rule("r1", [COND_A], "keep"),
        _rule("r2", [COND_A], "discard"),
    ]
    conflicts = detect_conflicts(rules)
    d = conflicts[0].to_dict()
    for key in ("rule_a", "rule_b", "conflict_type", "message"):
        assert key in d


def test_multiple_conflicts():
    rules = [
        _rule("r1", [COND_A], "keep"),
        _rule("r2", [COND_A], "discard"),
        _rule("r3", [COND_A], "review"),
    ]
    conflicts = detect_conflicts(rules)
    assert len(conflicts) >= 2
