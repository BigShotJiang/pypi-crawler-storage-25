from __future__ import annotations
from rule_lab.core.contracts import Rule
from rule_lab.core.evaluator import evaluate_rule, evaluate_rules, simulate


def _rule(rule_id: str, conditions: list, action: str, priority: int = 0) -> Rule:
    return Rule(rule_id=rule_id, name=rule_id, conditions=conditions, action=action, priority=priority)


SCORE_RULE = _rule("r1", [{"field": "score", "op": "gte", "value": 7.0}], "keep")
STATUS_RULE = _rule("r2", [{"field": "status", "op": "eq", "value": "ok"}], "promote")
NO_COND_RULE = _rule("r3", [], "default_action")


def test_evaluate_rule_match():
    result = evaluate_rule(SCORE_RULE, {"score": 8.0})
    assert result.matched is True
    assert result.action == "keep"


def test_evaluate_rule_no_match():
    result = evaluate_rule(SCORE_RULE, {"score": 5.0})
    assert result.matched is False
    assert result.action is None


def test_evaluate_rule_no_conditions_always_matches():
    result = evaluate_rule(NO_COND_RULE, {})
    assert result.matched is True
    assert result.action == "default_action"


def test_evaluate_rule_result_fields():
    result = evaluate_rule(SCORE_RULE, {"score": 9.0})
    assert result.rule_id == "r1"
    assert result.conditions_checked == 1
    assert result.conditions_passed == 1
    assert isinstance(result.reason, str)


def test_evaluate_rules_batch():
    rules = [SCORE_RULE, STATUS_RULE]
    batch = evaluate_rules(rules, {"score": 8.0, "status": "ok"})
    assert batch.total_rules == 2
    assert batch.matched_count == 2


def test_evaluate_rules_partial_match():
    rules = [SCORE_RULE, STATUS_RULE]
    batch = evaluate_rules(rules, {"score": 3.0, "status": "ok"})
    assert batch.matched_count == 1


def test_evaluate_rules_no_match():
    rules = [SCORE_RULE]
    batch = evaluate_rules(rules, {"score": 1.0})
    assert batch.matched_count == 0


def test_simulate_multiple_contexts():
    rules = [SCORE_RULE]
    contexts = [{"score": 8.0}, {"score": 2.0}, {"score": 7.0}]
    results = simulate(rules, contexts)
    assert len(results) == 3
    assert results[0].matched_count == 1
    assert results[1].matched_count == 0
    assert results[2].matched_count == 1


def test_to_dict_shape():
    result = evaluate_rule(SCORE_RULE, {"score": 8.0})
    d = result.to_dict()
    for key in ("rule_id", "rule_name", "matched", "action", "reason", "conditions_checked", "conditions_passed"):
        assert key in d
