from __future__ import annotations

from rule_lab.core.contracts import Rule
from rule_lab.core.evaluator import evaluate_rule, evaluate_rules
from rule_lab.core.loader import load_rules_from_list
from rule_lab.core.models import RuleSet


# ---------------------------------------------------------------------------
# Rule metadata round-trip
# ---------------------------------------------------------------------------

def test_rule_metadata_survives_loader() -> None:
    raw = [{
        "rule_id": "r1",
        "name": "Meta rule",
        "conditions": [{"field": "score", "op": "gte", "value": 5.0}],
        "action": "keep",
        "tags": ["important", "v2"],
        "metadata": {"author": "yakuphan", "version": "0.2"},
    }]
    rules = load_rules_from_list(raw)
    assert rules[0].metadata == {"author": "yakuphan", "version": "0.2"}
    assert rules[0].tags == ["important", "v2"]


def test_rule_metadata_in_to_dict() -> None:
    rule = Rule(
        rule_id="r1",
        name="test",
        conditions=[],
        action="keep",
        tags=["x"],
        metadata={"source": "unit_test"},
    )
    d = rule.to_dict()
    assert d["metadata"] == {"source": "unit_test"}
    assert d["tags"] == ["x"]


def test_rule_metadata_empty_by_default() -> None:
    raw = [{
        "rule_id": "r2",
        "name": "No meta",
        "conditions": [],
        "action": "pass",
    }]
    rules = load_rules_from_list(raw)
    assert rules[0].metadata == {}
    assert rules[0].tags == []


# ---------------------------------------------------------------------------
# RuleSet model
# ---------------------------------------------------------------------------

def test_ruleset_to_dict_shape() -> None:
    rs = RuleSet(
        name="test_set",
        version="1.0",
        rules=[{"rule_id": "r1", "name": "x", "conditions": [], "action": "keep"}],
        metadata={"owner": "team_a"},
    )
    d = rs.to_dict()
    assert d["name"] == "test_set"
    assert d["version"] == "1.0"
    assert d["metadata"] == {"owner": "team_a"}
    assert len(d["rules"]) == 1


def test_ruleset_empty_metadata_by_default() -> None:
    rs = RuleSet(name="empty", version="0.1")
    assert rs.metadata == {}
    assert rs.rules == []


# ---------------------------------------------------------------------------
# Metadata does not affect evaluation
# ---------------------------------------------------------------------------

def test_metadata_does_not_affect_match_result() -> None:
    rule_with_meta = Rule(
        rule_id="r1",
        name="with meta",
        conditions=[{"field": "score", "op": "gte", "value": 7.0}],
        action="keep",
        metadata={"note": "some annotation"},
    )
    rule_without_meta = Rule(
        rule_id="r2",
        name="without meta",
        conditions=[{"field": "score", "op": "gte", "value": 7.0}],
        action="keep",
    )
    ctx = {"score": 8.0}
    result_a = evaluate_rule(rule_with_meta, ctx)
    result_b = evaluate_rule(rule_without_meta, ctx)

    assert result_a.matched == result_b.matched
    assert result_a.action == result_b.action


# ---------------------------------------------------------------------------
# Priority metadata
# ---------------------------------------------------------------------------

def test_priority_preserved_in_to_dict() -> None:
    raw = [
        {"rule_id": "low", "name": "low", "conditions": [], "action": "pass", "priority": 1},
        {"rule_id": "high", "name": "high", "conditions": [], "action": "pass", "priority": 10},
    ]
    rules = load_rules_from_list(raw)
    dicts = [r.to_dict() for r in rules]
    priorities = [d["priority"] for d in dicts]
    assert 10 in priorities
    assert 1 in priorities


def test_evaluation_result_does_not_leak_metadata() -> None:
    rule = Rule(
        rule_id="r1",
        name="meta check",
        conditions=[{"field": "x", "op": "eq", "value": 1}],
        action="keep",
        metadata={"secret": "internal"},
    )
    result = evaluate_rule(rule, {"x": 1})
    d = result.to_dict()
    assert "metadata" not in d
    assert "secret" not in d
