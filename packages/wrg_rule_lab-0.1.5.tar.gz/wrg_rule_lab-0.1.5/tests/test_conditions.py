from __future__ import annotations
from rule_lab.core.conditions import evaluate_condition, evaluate_all
from rule_lab.core.errors import ConditionError
import pytest


def test_eq_match():
    assert evaluate_condition({"field": "status", "op": "eq", "value": "active"}, {"status": "active"})


def test_eq_no_match():
    assert not evaluate_condition({"field": "status", "op": "eq", "value": "active"}, {"status": "inactive"})


def test_gte_match():
    assert evaluate_condition({"field": "score", "op": "gte", "value": 7.0}, {"score": 8.5})


def test_gte_no_match():
    assert not evaluate_condition({"field": "score", "op": "gte", "value": 7.0}, {"score": 5.0})


def test_lt_match():
    assert evaluate_condition({"field": "age", "op": "lt", "value": 30}, {"age": 25})


def test_contains_match():
    assert evaluate_condition({"field": "tag", "op": "contains", "value": "lab"}, {"tag": "rule_lab"})


def test_not_contains_match():
    assert evaluate_condition({"field": "tag", "op": "not_contains", "value": "prod"}, {"tag": "dev"})


def test_exists_true():
    assert evaluate_condition({"field": "score", "op": "exists"}, {"score": 0})


def test_exists_false():
    assert not evaluate_condition({"field": "score", "op": "exists"}, {})


def test_not_exists_true():
    assert evaluate_condition({"field": "missing", "op": "not_exists"}, {})


def test_missing_field_returns_false():
    assert not evaluate_condition({"field": "score", "op": "eq", "value": 5}, {})


def test_unsupported_operator_raises():
    with pytest.raises(ConditionError):
        evaluate_condition({"field": "x", "op": "regex", "value": ".*"}, {"x": "hello"})


def test_missing_field_key_raises():
    with pytest.raises(ConditionError):
        evaluate_condition({"op": "eq", "value": 1}, {"x": 1})


def test_evaluate_all_counts():
    conditions = [
        {"field": "score", "op": "gte", "value": 5.0},
        {"field": "status", "op": "eq", "value": "ok"},
    ]
    total, passed = evaluate_all(conditions, {"score": 8.0, "status": "ok"})
    assert total == 2
    assert passed == 2


def test_evaluate_all_partial():
    conditions = [
        {"field": "score", "op": "gte", "value": 5.0},
        {"field": "status", "op": "eq", "value": "ok"},
    ]
    total, passed = evaluate_all(conditions, {"score": 8.0, "status": "fail"})
    assert total == 2
    assert passed == 1
