from __future__ import annotations

from .contracts import ConflictReport, Rule


def detect_conflicts(rules: list[Rule]) -> list[ConflictReport]:
    """Detect same-priority rules with the same conditions but different actions."""
    conflicts: list[ConflictReport] = []
    seen: list[Rule] = []

    for rule in rules:
        for other in seen:
            if _conditions_overlap(rule, other) and rule.action != other.action:
                conflicts.append(
                    ConflictReport(
                        rule_a=rule.rule_id,
                        rule_b=other.rule_id,
                        conflict_type="action_conflict",
                        message=(
                            f"Rules '{rule.rule_id}' and '{other.rule_id}' have overlapping "
                            f"conditions but different actions: '{rule.action}' vs '{other.action}'"
                        ),
                    )
                )
        seen.append(rule)

    return conflicts


def _conditions_overlap(a: Rule, b: Rule) -> bool:
    """True if both rules share at least one identical condition dict."""
    if not a.conditions or not b.conditions:
        return False
    b_conditions = b.conditions
    return any(cond in b_conditions for cond in a.conditions)
