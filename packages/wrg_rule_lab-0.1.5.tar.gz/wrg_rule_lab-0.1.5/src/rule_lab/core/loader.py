from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .contracts import Rule
from .errors import RuleLoadError, RuleValidationError

REQUIRED_RULE_FIELDS = {"rule_id", "name", "conditions", "action"}


def _validate_rule_dict(raw: dict[str, Any]) -> None:
    missing = REQUIRED_RULE_FIELDS - set(raw.keys())
    if missing:
        raise RuleValidationError(f"rule missing required fields: {sorted(missing)}")
    if not isinstance(raw["conditions"], list):
        raise RuleValidationError(f"rule '{raw['rule_id']}': conditions must be a list")
    if not isinstance(raw["action"], str) or not raw["action"].strip():
        raise RuleValidationError(f"rule '{raw['rule_id']}': action must be a non-empty string")


def load_rules_from_dict(data: dict[str, Any]) -> list[Rule]:
    raw_rules = data.get("rules", [])
    if not isinstance(raw_rules, list):
        raise RuleLoadError("ruleset 'rules' field must be a list")

    rules: list[Rule] = []
    for raw in raw_rules:
        if not isinstance(raw, dict):
            raise RuleLoadError(f"rule entry must be a dict, got: {type(raw)}")
        _validate_rule_dict(raw)
        rules.append(
            Rule(
                rule_id=str(raw["rule_id"]),
                name=str(raw["name"]),
                conditions=list(raw["conditions"]),
                action=str(raw["action"]),
                priority=int(raw.get("priority", 0)),
                tags=list(raw.get("tags", [])),
                metadata=dict(raw.get("metadata", {})),
            )
        )
    return sorted(rules, key=lambda r: (-r.priority, r.rule_id))


def load_rules_from_file(path: str | Path) -> list[Rule]:
    p = Path(path)
    if not p.exists():
        raise RuleLoadError(f"rule file not found: {p}")
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise RuleLoadError(f"invalid JSON in rule file {p}: {exc}") from exc
    if not isinstance(data, dict):
        raise RuleLoadError(f"rule file must contain a JSON object: {p}")
    return load_rules_from_dict(data)


def load_rules_from_list(raw_rules: list[dict[str, Any]]) -> list[Rule]:
    return load_rules_from_dict({"rules": raw_rules})
