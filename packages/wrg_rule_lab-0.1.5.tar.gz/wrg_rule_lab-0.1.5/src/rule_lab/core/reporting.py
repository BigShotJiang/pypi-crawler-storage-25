from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .contracts import BatchResult, ConflictReport


def build_run_report(
    batch: BatchResult,
    conflicts: list[ConflictReport],
    context: dict[str, Any],
) -> dict[str, Any]:
    return {
        "context": context,
        "total_rules": batch.total_rules,
        "matched_count": batch.matched_count,
        "conflict_count": len(conflicts),
        "results": [r.to_dict() for r in batch.results],
        "conflicts": [c.to_dict() for c in conflicts],
    }


def build_batch_report(
    batch_results: list[BatchResult],
    conflicts: list[ConflictReport],
    contexts: list[dict[str, Any]],
) -> dict[str, Any]:
    return {
        "total_contexts": len(contexts),
        "total_rules": batch_results[0].total_rules if batch_results else 0,
        "conflict_count": len(conflicts),
        "conflicts": [c.to_dict() for c in conflicts],
        "runs": [
            {
                "context_index": i,
                "matched_count": r.matched_count,
                "results": [res.to_dict() for res in r.results],
            }
            for i, r in enumerate(batch_results)
        ],
    }


def format_text_report(report: dict[str, Any]) -> str:
    lines = ["rule_lab report:"]
    lines.append(f"  total_rules    : {report.get('total_rules', '?')}")
    lines.append(f"  matched_count  : {report.get('matched_count', '?')}")
    lines.append(f"  conflict_count : {report.get('conflict_count', 0)}")
    for result in report.get("results", []):
        status = "MATCH" if result["matched"] else "miss"
        lines.append(f"  [{status}] {result['rule_id']} — {result['reason']}")
    if report.get("conflicts"):
        lines.append("  conflicts:")
        for c in report["conflicts"]:
            lines.append(f"    {c['rule_a']} vs {c['rule_b']}: {c['message']}")
    return "\n".join(lines)


def write_report(report: dict[str, Any], path: str | Path) -> None:
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
