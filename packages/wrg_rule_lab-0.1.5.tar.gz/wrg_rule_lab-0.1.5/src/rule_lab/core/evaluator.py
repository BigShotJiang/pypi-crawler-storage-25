from __future__ import annotations

from typing import Any

from .conditions import evaluate_all
from .contracts import BatchResult, EvaluationResult, Rule


def evaluate_rule(rule: Rule, context: dict[str, Any]) -> EvaluationResult:
    if not rule.conditions:
        return EvaluationResult(
            rule_id=rule.rule_id,
            rule_name=rule.name,
            matched=True,
            action=rule.action,
            reason="no conditions — unconditional match",
            conditions_checked=0,
            conditions_passed=0,
        )

    total, passed = evaluate_all(rule.conditions, context)
    matched = passed == total

    return EvaluationResult(
        rule_id=rule.rule_id,
        rule_name=rule.name,
        matched=matched,
        action=rule.action if matched else None,
        reason=f"{passed}/{total} conditions passed",
        conditions_checked=total,
        conditions_passed=passed,
    )


def evaluate_rules(rules: list[Rule], context: dict[str, Any]) -> BatchResult:
    results = [evaluate_rule(rule, context) for rule in rules]
    matched = [r for r in results if r.matched]
    return BatchResult(
        total_rules=len(rules),
        matched_count=len(matched),
        results=results,
    )


def simulate(rules: list[Rule], contexts: list[dict[str, Any]]) -> list[BatchResult]:
    return [evaluate_rules(rules, ctx) for ctx in contexts]
