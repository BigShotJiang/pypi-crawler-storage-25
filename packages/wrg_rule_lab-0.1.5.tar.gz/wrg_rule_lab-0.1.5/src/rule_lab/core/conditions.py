from __future__ import annotations

from typing import Any

from .errors import ConditionError

SUPPORTED_OPERATORS = {"eq", "neq", "gt", "gte", "lt", "lte", "contains", "not_contains", "exists", "not_exists"}


def evaluate_condition(condition: dict[str, Any], context: dict[str, Any]) -> bool:
    """Evaluate a single condition against a context dict.

    Condition shape:
        {"field": "score", "op": "gte", "value": 7.0}
    """
    field = condition.get("field")
    op = condition.get("op")
    expected = condition.get("value")

    if not isinstance(field, str) or not field.strip():
        raise ConditionError(f"condition missing 'field': {condition}")
    if op not in SUPPORTED_OPERATORS:
        raise ConditionError(f"unsupported operator '{op}' in condition: {condition}")

    actual = context.get(field)

    if op == "exists":
        return field in context
    if op == "not_exists":
        return field not in context

    if actual is None:
        return False

    if op == "eq":
        return actual == expected
    if op == "neq":
        return actual != expected
    if op == "gt":
        return float(actual) > float(expected)
    if op == "gte":
        return float(actual) >= float(expected)
    if op == "lt":
        return float(actual) < float(expected)
    if op == "lte":
        return float(actual) <= float(expected)
    if op == "contains":
        return str(expected) in str(actual)
    if op == "not_contains":
        return str(expected) not in str(actual)

    raise ConditionError(f"unhandled operator '{op}'")


def evaluate_all(conditions: list[dict[str, Any]], context: dict[str, Any]) -> tuple[int, int]:
    """Evaluate all conditions. Returns (total_checked, total_passed)."""
    passed = sum(1 for c in conditions if evaluate_condition(c, context))
    return len(conditions), passed
