from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class Rule:
    rule_id: str
    name: str
    conditions: list[dict[str, Any]]
    action: str
    priority: int = 0
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "name": self.name,
            "conditions": self.conditions,
            "action": self.action,
            "priority": self.priority,
            "tags": self.tags,
            "metadata": self.metadata,
        }


@dataclass(slots=True)
class EvaluationResult:
    rule_id: str
    rule_name: str
    matched: bool
    action: str | None
    reason: str
    conditions_checked: int
    conditions_passed: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "rule_name": self.rule_name,
            "matched": self.matched,
            "action": self.action if self.matched else None,
            "reason": self.reason,
            "conditions_checked": self.conditions_checked,
            "conditions_passed": self.conditions_passed,
        }


@dataclass(slots=True)
class BatchResult:
    total_rules: int
    matched_count: int
    results: list[EvaluationResult]

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_rules": self.total_rules,
            "matched_count": self.matched_count,
            "results": [r.to_dict() for r in self.results],
        }


@dataclass(slots=True)
class ConflictReport:
    rule_a: str
    rule_b: str
    conflict_type: str
    message: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_a": self.rule_a,
            "rule_b": self.rule_b,
            "conflict_type": self.conflict_type,
            "message": self.message,
        }
