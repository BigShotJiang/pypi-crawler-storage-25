from __future__ import annotations


class RuleLabError(Exception):
    """Base error for rule_lab."""


class RuleLoadError(RuleLabError):
    """Raised when a rule file cannot be loaded or parsed."""


class RuleValidationError(RuleLabError):
    """Raised when a rule definition fails schema validation."""


class ConditionError(RuleLabError):
    """Raised when a condition cannot be evaluated."""
