from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Sequence

from rule_lab.core.conflicts import detect_conflicts
from rule_lab.core.errors import RuleLabError
from rule_lab.core.evaluator import simulate
from rule_lab.core.loader import load_rules_from_file
from rule_lab.core.reporting import build_batch_report, format_text_report, write_report


class CliError(Exception):
    pass


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="rule-lab", description="Deterministic rule evaluation engine")
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate_parser = subparsers.add_parser("validate", help="Validate a rule file")
    validate_parser.add_argument("--rules", required=True, help="Path to rules JSON file")

    simulate_parser = subparsers.add_parser("simulate", help="Simulate rules against contexts")
    simulate_parser.add_argument("--rules", required=True, help="Path to rules JSON file")
    simulate_parser.add_argument("--contexts", required=True, help="Path to contexts JSON file (list of dicts)")
    simulate_parser.add_argument("--out", help="Write JSON report to this path")
    simulate_parser.add_argument("--json", action="store_true", help="Emit JSON to stdout")

    diff_parser = subparsers.add_parser("diff", help="Detect conflicts between rules")
    diff_parser.add_argument("--rules", required=True, help="Path to rules JSON file")
    diff_parser.add_argument("--json", action="store_true", help="Emit JSON to stdout")

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "validate":
            return _cmd_validate(args)
        if args.command == "simulate":
            return _cmd_simulate(args)
        if args.command == "diff":
            return _cmd_diff(args)
        raise CliError(f"unsupported command: {args.command}")
    except CliError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except RuleLabError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except FileNotFoundError as exc:
        print(f"ERROR: file not found: {exc.filename or exc}", file=sys.stderr)
        return 1
    except json.JSONDecodeError as exc:
        print(f"ERROR: invalid JSON: {exc}", file=sys.stderr)
        return 1


def _cmd_validate(args: argparse.Namespace) -> int:
    rules = load_rules_from_file(args.rules)
    print(f"validate OK — {len(rules)} rule(s) loaded from {args.rules}")
    return 0


def _cmd_simulate(args: argparse.Namespace) -> int:
    rules = load_rules_from_file(args.rules)
    contexts_path = Path(args.contexts)
    if not contexts_path.exists():
        raise CliError(f"contexts file not found: {contexts_path}")
    contexts: list[dict[str, Any]] = json.loads(contexts_path.read_text(encoding="utf-8"))
    if not isinstance(contexts, list):
        raise CliError("contexts file must contain a JSON array")

    conflicts = detect_conflicts(rules)
    batch_results = simulate(rules, contexts)
    report = build_batch_report(batch_results, conflicts, contexts)

    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print(format_text_report({
            "total_rules": report["total_rules"],
            "matched_count": sum(r["matched_count"] for r in report["runs"]),
            "conflict_count": report["conflict_count"],
            "results": [res for run in report["runs"] for res in run["results"]],
            "conflicts": report["conflicts"],
        }))

    if args.out:
        write_report(report, args.out)
        print(f"report written to {args.out}")

    return 0


def _cmd_diff(args: argparse.Namespace) -> int:
    rules = load_rules_from_file(args.rules)
    conflicts = detect_conflicts(rules)

    if args.json:
        print(json.dumps([c.to_dict() for c in conflicts], indent=2, ensure_ascii=False))
    else:
        if not conflicts:
            print("diff: no conflicts detected")
        else:
            for c in conflicts:
                print(f"CONFLICT {c.rule_a} vs {c.rule_b}: {c.message}")

    return 1 if conflicts else 0


if __name__ == "__main__":
    raise SystemExit(main())
