from __future__ import annotations

APP_NAME = "rule_lab"
APP_VERSION = "0.1.5"
__version__ = APP_VERSION

from rule_lab.core.contracts import Rule, EvaluationResult, BatchResult
from rule_lab.core.models import RuleSet
from rule_lab.core.evaluator import evaluate_rule, evaluate_rules, simulate
from rule_lab.core.loader import load_rules_from_file, load_rules_from_dict, load_rules_from_list

__all__ = [
    "APP_NAME",
    "APP_VERSION",
    "__version__",
    "Rule",
    "EvaluationResult",
    "BatchResult",
    "RuleSet",
    "evaluate_rule",
    "evaluate_rules",
    "simulate",
    "load_rules_from_file",
    "load_rules_from_dict",
    "load_rules_from_list",
]
