import datetime as dt

from gitember import render
from gitember.colors import ColorScheme


def test_choose_level_zero():
    """Count of 0 always returns level 0."""
    for count in [0]:
        level = render.choose_level(count, (0, 1, 3, 6, 10))
        assert level == 0


def test_choose_level_boundaries():
    """Counts at each threshold boundary map to the correct level."""
    thresholds = (0, 2, 5, 8, 12)
    assert render.choose_level(0, thresholds) == 0
    assert render.choose_level(1, thresholds) == 1
    assert render.choose_level(2, thresholds) == 1
    assert render.choose_level(3, thresholds) == 2
    assert render.choose_level(5, thresholds) == 2
    assert render.choose_level(6, thresholds) == 3
    assert render.choose_level(8, thresholds) == 3
    assert render.choose_level(9, thresholds) == 4
    assert render.choose_level(12, thresholds) == 4
    assert render.choose_level(100, thresholds) == 4


def test_choose_level_max():
    """A very large count returns level 4."""
    level = render.choose_level(10000, (0, 1, 3, 6, 10))
    assert level == 4


def test_build_date_range_single_day():
    """Start == end returns a list of one date."""
    date = dt.date(2024, 1, 1)
    result = render.build_date_range(date, date)
    assert len(result) == 1
    assert result[0] == date


def test_build_date_range_span():
    """Correct number of days returned for a known range."""
    start = dt.date(2024, 1, 1)
    end = dt.date(2024, 1, 10)
    result = render.build_date_range(start, end)
    assert len(result) == 10


def test_build_date_range_order():
    """Dates are in ascending order."""
    start = dt.date(2024, 1, 5)
    end = dt.date(2024, 1, 10)
    result = render.build_date_range(start, end)
    for i in range(len(result) - 1):
        assert result[i] < result[i + 1]


def test_calculate_thresholds_auto():
    """Verify the 5 returned values are non-decreasing and first value is 0."""
    counts = {dt.date(2024, 1, i): i % 10 for i in range(1, 30)}
    result = render.calculate_thresholds(counts, mode="auto")
    assert len(result) == 5
    assert result[0] == 0
    for i in range(1, 5):
        assert result[i] >= result[i - 1]


def test_calculate_thresholds_adaptive():
    """Same monotonicity check with a realistic counts dict."""
    counts = {
        dt.date(2024, 1, 1): 0,
        dt.date(2024, 1, 2): 1,
        dt.date(2024, 1, 3): 2,
        dt.date(2024, 1, 4): 5,
        dt.date(2024, 1, 5): 10,
    }
    result = render.calculate_thresholds(counts, mode="adaptive")
    assert len(result) == 5
    assert result[0] == 0
    for i in range(1, 5):
        assert result[i] >= result[i - 1]


def test_calculate_thresholds_empty():
    """Empty counts dict does not raise and returns a valid 5-tuple."""
    result = render.calculate_thresholds({}, mode="auto")
    assert len(result) == 5
    assert result[0] == 0


def test_render_legend_skips_duplicate_thresholds():
    """When two adjacent threshold values are equal, that level does not appear."""
    thresholds = (0, 1, 1, 1, 5)
    scheme = ColorScheme("test", [""] * 5)
    legend = render.render_legend(thresholds, scheme, ascii_mode=True)
    assert "2-1" not in legend
    assert "1-1" not in legend


def test_render_legend_contains_all_levels():
    """With well-spread thresholds, all 4 block levels appear in the output."""
    thresholds = (0, 2, 5, 10, 20)
    scheme = ColorScheme("test", [""] * 5)
    legend = render.render_legend(thresholds, scheme, ascii_mode=True)
    assert ".." in legend
    assert "::" in legend
    assert "==" in legend
    assert "##" in legend


def test_render_grid_returns_string():
    """Smoke test that render_grid returns a non-empty string for a small date range."""
    counts = {dt.date(2024, 1, 1): 0, dt.date(2024, 1, 2): 1}
    scheme = ColorScheme("green", [""] * 5)
    result = render.render_grid(
        dt.date(2024, 1, 1),
        dt.date(2024, 1, 7),
        counts,
        scheme,
        "sunday",
        "=",
        False,
    )
    assert isinstance(result, str)
    assert len(result) > 0


def test_render_grid_month_labels():
    """Output contains at least one 3-letter month abbreviation."""
    counts = {dt.date(2024, 6, 15): 1}
    scheme = ColorScheme("green", [""] * 5)
    result = render.render_grid(
        dt.date(2024, 6, 1),
        dt.date(2024, 6, 30),
        counts,
        scheme,
        "sunday",
        "=",
        False,
    )
    months = [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
    ]
    has_month = any(m in result for m in months)
    assert has_month, "Expected at least one month label in output"
