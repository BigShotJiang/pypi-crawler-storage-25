import datetime as dt
from pathlib import Path

import pytest

from gitember import config, git


def test_load_config_defaults(tmp_path, monkeypatch):
    """When no config file exists, returns dict with color and border keys."""
    monkeypatch.setattr(
        config, "config_file_path", lambda: tmp_path / "nonexistent.toml"
    )
    result = config.load_config()
    assert "color" in result
    assert "border" in result
    assert result["color"] == "green"
    assert result["border"] == "="


def test_save_and_load_roundtrip(tmp_path, monkeypatch):
    """Saving a config dict and loading it back returns the same values."""
    test_file = tmp_path / "config.toml"
    monkeypatch.setattr(config, "config_file_path", lambda: test_file)

    config.save_config({"color": "blue", "border": "*", "week_start": "monday"})
    result = config.load_config()

    assert result["color"] == "blue"
    assert result["border"] == "*"
    assert result["week_start"] == "monday"


def test_load_config_ignores_unknown_keys(tmp_path, monkeypatch):
    """A config file containing an unknown key does not include it in the returned dict."""
    test_file = tmp_path / "config.toml"
    monkeypatch.setattr(config, "config_file_path", lambda: test_file)

    test_file.write_text('color = "blue"\nbadkey = "value"\n')
    result = config.load_config()

    assert "badkey" not in result
    assert result["color"] == "blue"


def test_save_config_only_writes_allowed_keys(tmp_path, monkeypatch):
    """Passing a dict with an extra key does not write that key to disk."""
    test_file = tmp_path / "config.toml"
    monkeypatch.setattr(config, "config_file_path", lambda: test_file)

    config.save_config({"color": "blue", "secret": "password"})
    content = test_file.read_text()

    assert "secret" not in content
    assert "color" in content


def test_config_file_path_returns_path():
    """Returns a Path object ending in config.toml."""
    result = config.config_file_path()
    assert isinstance(result, Path)
    assert result.name == "config.toml"
