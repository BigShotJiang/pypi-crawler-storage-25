import datetime as dt

import pytest

from gitember import git


def test_run_git_log_empty_repo(repo):
    """Returns empty dict when no commits exist in range."""
    result = git.run_git_log(
        dt.date(2024, 1, 1),
        dt.date(2024, 12, 31),
        str(repo),
    )
    assert result == {}


def test_run_git_log_counts_commits(repo_with_commits):
    """Returns non-empty dict when commits exist in date range."""
    result = git.run_git_log(
        dt.date(2024, 1, 1),
        dt.date(2024, 12, 31),
        str(repo_with_commits),
    )
    assert len(result) > 0


def test_run_git_log_invalid_path(tmp_path):
    """Raises ValueError for a non-git directory."""
    with pytest.raises(ValueError):
        git.run_git_log(
            dt.date(2024, 1, 1),
            dt.date(2024, 12, 31),
            str(tmp_path),
        )


def test_get_branches_returns_list(repo):
    """Returns a list of branches, possibly empty for fresh repos."""
    result = git.get_branches(str(repo))
    assert isinstance(result, list)


def test_get_default_branch(repo):
    """Returns a non-empty string for a valid repo."""
    result = git.get_default_branch(str(repo))
    assert isinstance(result, str)
    assert len(result) > 0


def test_get_streaks_empty():
    """Empty dict returns all zeros."""
    result = git.get_streaks({})
    assert result["current_streak"] == 0
    assert result["longest_streak"] == 0


def test_get_streaks_consecutive():
    """3 consecutive days with commits returns current_streak or longest_streak >= 3."""
    counts = {
        dt.date(2024, 1, 1): 1,
        dt.date(2024, 1, 2): 1,
        dt.date(2024, 1, 3): 1,
    }
    result = git.get_streaks(counts)
    assert result["current_streak"] >= 3 or result["longest_streak"] >= 3


def test_get_streaks_gap_resets():
    """A gap in dates resets the streak count."""
    counts = {
        dt.date(2024, 1, 1): 1,
        dt.date(2024, 1, 2): 1,
        dt.date(2024, 1, 4): 1,
    }
    result = git.get_streaks(counts)
    assert result["longest_streak"] == 2
    assert result["current_streak"] == 0


def test_get_top_contributors_ordering(repo_with_commits):
    """Author with more commits appears first."""
    result = git.get_top_contributors(str(repo_with_commits))
    assert len(result) >= 2
    assert result[0][1] >= result[1][1]


def test_get_repo_stats_keys(repo_with_commits):
    """Returned dict contains all expected keys."""
    result = git.get_repo_stats(str(repo_with_commits))
    assert "total_commits" in result
    assert "num_authors" in result
    assert "first_commit_date" in result
    assert "last_commit_date" in result
