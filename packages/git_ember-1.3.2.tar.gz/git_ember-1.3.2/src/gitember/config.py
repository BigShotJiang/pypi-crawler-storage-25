import os
import sys
from pathlib import Path


__all__ = [
    "config_file_path",
    "ALLOWED_CONFIG_KEYS",
    "load_config",
    "save_config",
]


def config_file_path() -> Path:
    """Get the path to the config file.

    Returns:
        Path to config.toml in platform-specific config directory.
    """
    if sys.platform.startswith("win"):
        base = os.getenv("APPDATA")
        if base:
            base_path = Path(base)
        else:
            base_path = Path.home() / "AppData" / "Roaming"
    else:
        xdg = os.getenv("XDG_CONFIG_HOME")
        if xdg:
            base_path = Path(xdg)
        else:
            base_path = Path.home() / ".config"
    return base_path / "git-ember" / "config.toml"


ALLOWED_CONFIG_KEYS = {"color", "border", "week_start"}


DEFAULT_CONFIG = {
    "color": "green",
    "border": "=",
    "week_start": "sunday",
}


def load_config() -> dict:
    """Load config from file, returning defaults if not exists.

    Returns:
        Dict with keys: color, border, week_start.
    """
    path = config_file_path()
    if not path.exists():
        return DEFAULT_CONFIG.copy()

    config = DEFAULT_CONFIG.copy()
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return config

    # Simple TOML-like parsing: key=value, ignore comments
    for line in text.splitlines():
        stripped = line.strip()
        # Skip empty lines and comments
        if not stripped or stripped.startswith("#"):
            continue
        if "=" in stripped:
            key, _, value = stripped.partition("=")
            key = key.strip()
            # Strip quotes from value - handles both "value" and 'value'
            value = value.strip().strip('"').strip("'")
            # Only allow predefined keys (whitelist for security)
            if key in ALLOWED_CONFIG_KEYS:
                config[key] = value
    return config


def save_config(config: dict) -> None:
    """Save config to file.

    Args:
        config: Dict with keys: week_start, style, color, border.
    """
    path = config_file_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        lines = []
        for k, v in config.items():
            if k in ALLOWED_CONFIG_KEYS:
                escaped = v.replace('"', '\\"')
                lines.append(f'{k} = "{escaped}"')
        path.write_text("\n".join(lines), encoding="utf-8")
    except OSError:
        pass
