import argparse
import calendar
import datetime as dt
import sys
import time
from pathlib import Path

from gitember import __version__
from gitember.colors import get_color_scheme, RESET, LIGHT_GRAY
from gitember.config import (
    config_file_path,
    ALLOWED_CONFIG_KEYS,
    load_config,
    save_config,
)
from gitember.git import (
    run_git_log,
    get_recent_commits,
    get_top_contributors,
    get_repo_stats,
    get_branches,
    get_branch_tree,
    get_default_branch,
    get_streaks,
)
from gitember.render import (
    render_grid,
    render_branch_tree,
    calculate_thresholds,
    render_legend,
)


__all__ = ["main"]


def parse_args() -> argparse.Namespace:
    """Parse command line arguments.

    Returns:
        Parsed arguments namespace.
    """
    parser = argparse.ArgumentParser(
        description="Display a GitHub-style heatmap of commits in your terminal.",
    )
    parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Path to git repository (default: current directory)",
    )
    parser.add_argument(
        "--color",
        "-c",
        choices=[
            "green",
            "blue",
            "orange",
            "purple",
            "red",
            "yellow",
            "teal",
            "pink",
            "aqua",
            "mono",
        ],
        help="Color scheme",
    )
    parser.add_argument(
        "--years",
        "-y",
        type=int,
        default=1,
        help="Number of years to show (default: 1)",
    )
    parser.add_argument(
        "--border",
        "-b",
        type=str,
        default="=",
        help="Border character (default: =)",
    )
    parser.add_argument(
        "--extended",
        "-e",
        action="store_true",
        help="Show extended report with recent commits and top contributors",
    )
    parser.add_argument(
        "--stats",
        "-S",
        action="store_true",
        help="Show repository statistics (total commits, authors, dates)",
    )
    parser.add_argument(
        "--ascii",
        "-a",
        action="store_true",
        help="Use ASCII characters instead of Unicode blocks",
    )
    parser.add_argument(
        "--compact",
        action="store_true",
        help="Only show months up to the current month",
    )
    parser.add_argument(
        "--branch",
        action="store",
        help="Show heatmap for specific branch instead of all branches",
    )
    parser.add_argument(
        "--tree",
        "-t",
        action="store_true",
        help="Show branch tree under heatmap",
    )
    parser.add_argument(
        "--scale",
        type=str,
        choices=["auto", "adaptive"],
        default="auto",
        help="Intensity scaling mode: auto or adaptive (default: auto)",
    )
    parser.add_argument(
        "--after",
        type=str,
        help="Show commits after this date (YYYY-MM-DD)",
    )
    parser.add_argument(
        "--before",
        type=str,
        help="Show commits before this date (YYYY-MM-DD)",
    )
    parser.add_argument(
        "--week-start",
        type=str,
        choices=["sunday", "monday"],
        default=None,
        help="First day of week: sunday or monday (default: sunday)",
    )
    parser.add_argument(
        "--author",
        "-A",
        type=str,
        help="Filter commits by author name or email (partial match)",
    )
    parser.add_argument(
        "--version",
        "-V",
        action="version",
        version=f"git-ember {__version__}",
    )
    return parser.parse_args()


def get_repo_path(path: str) -> str:
    """Resolve path to absolute path.

    Args:
        path: Relative or absolute path to git repository.

    Returns:
        Absolute path as string.

    Raises:
        ValueError: If path is unsafe (contains suspicious characters).
    """
    if not path:
        raise ValueError("Path cannot be empty")

    import re

    if re.search(r"[;&|`$()]", path):
        raise ValueError(f"Invalid characters in path: {path}")

    resolved = Path(path).resolve()

    return str(resolved)


def main() -> None:
    """Main entry point."""
    args = parse_args()
    repo_path = get_repo_path(args.path)

    config = load_config()

    color_name = args.color or config.get("color", "green")
    years = args.years
    border_char = args.border[0] if args.border else "="  # prevent escape codes
    ascii_mode = args.ascii
    branch = args.branch
    week_start = args.week_start or config.get("week_start", "sunday")
    author = args.author

    if branch:
        valid_branches = get_branches(repo_path)
        if branch not in valid_branches:
            print(f"Error: Branch '{branch}' not found")
            sys.exit(1)

    if args.color is not None:
        new_config = config.copy()
        if args.color:
            new_config["color"] = args.color
        if args.week_start is not None:
            new_config["week_start"] = args.week_start
        save_config(new_config)

    color_scheme = get_color_scheme(color_name)

    today = dt.date.today()
    output_parts = []
    extended = args.extended
    compact = args.compact
    scale_mode = args.scale

    custom_range = args.after or args.before

    start_date = dt.date.today() - dt.timedelta(days=365)
    end_date = dt.date.today()

    if args.after:
        try:
            start_date = dt.date.fromisoformat(args.after)
        except ValueError:
            print("Error: Invalid --after date. Use YYYY-MM-DD format.")
            sys.exit(1)
    if args.before:
        try:
            end_date = dt.date.fromisoformat(args.before)
        except ValueError:
            print("Error: Invalid --before date. Use YYYY-MM-DD format.")
            sys.exit(1)

    if custom_range:
        num_iterations = 1
    else:
        num_iterations = years

    for i in range(num_iterations):
        if custom_range:
            pass
        else:
            year = today.year - i
            current_month = today.month

            if compact and i == 0:
                start_month = max(1, current_month - 3)
                start_date = dt.date(year, start_month, 1)
                end_date = dt.date(
                    year, current_month, calendar.monthrange(year, current_month)[1]
                )
            else:
                start_date = dt.date(year, 1, 1)
                end_date = dt.date(year, 12, 31)

        try:
            counts = run_git_log(
                start_date, end_date, repo_path, branch=branch, author=author
            )
        except ValueError as e:
            print(f"Error: {e}")
            sys.exit(1)

        thresholds = calculate_thresholds(counts, scale_mode)

        heatmap = render_grid(
            start_date,
            end_date,
            counts,
            color_scheme,
            week_start,
            border_char,
            ascii_mode,
            thresholds=thresholds,
        )

        legend = render_legend(thresholds, color_scheme, ascii_mode)

        if custom_range:
            output_parts.append(f"{heatmap}\n    {legend}")
        elif num_iterations > 1:
            output_parts.append(f"[{year}]\n{heatmap}\n    {legend}")
        else:
            output_parts.append(f"{heatmap}\n    {legend}")

    output_parts.reverse()
    print("\n" + "\n".join(output_parts))

    if args.tree:
        tree_commits = get_branch_tree(repo_path, branch=branch, author=author)
        default_branch = get_default_branch(repo_path)
        tree_output = render_branch_tree(
            tree_commits,
            default_branch=default_branch,
            selected_branch=branch,
            color_scheme=color_scheme,
            ascii_mode=ascii_mode,
            compact=args.compact,
        )
        if tree_output:
            print(tree_output)

    show_stats = args.stats or extended

    if show_stats:
        stats = get_repo_stats(repo_path, branch=branch, author=author)

        print("\n--- Statistics ---")
        print(f"  Total commits:  {stats.get('total_commits', 0)}")
        print(f"  Authors:        {stats.get('num_authors', 0)}")

        first_commit_date = stats.get("first_commit_date", "")
        if first_commit_date:
            print(f"  First commit:   {first_commit_date}")

        last_commit_date = stats.get("last_commit_date", "")
        if last_commit_date:
            print(f"  Last commit:    {last_commit_date}")

        streak_start_date = dt.date.today() - dt.timedelta(days=years * 365)
        streak_end_date = dt.date.today()
        streak_counts = run_git_log(
            streak_start_date, streak_end_date, repo_path, branch=branch, author=author
        )
        streaks = get_streaks(streak_counts)

        if streaks["current_streak"] > 0:
            print(f"  Current streak: {streaks['current_streak']} days")

        if streaks["longest_streak"] > 0:
            longest_end = streaks["longest_streak_end"]
            if longest_end:
                month_name = longest_end.strftime("%b %Y")
                print(
                    f"  Longest streak: {streaks['longest_streak']} days ({month_name})"
                )
            else:
                print(f"  Longest streak: {streaks['longest_streak']} days")

    if extended:
        print("\n--- Recent Commits ---")
        for commit in get_recent_commits(repo_path, branch=branch, author=author):
            commit_color = color_scheme.get(3)
            author_color = color_scheme.get(2)

            commit_time = (
                time.strftime("%H:%M", time.localtime(int(commit["timestamp"])))
                if commit["timestamp"]
                else ""
            )
            date_parts = commit["date"].split("-")
            formatted_date = (
                f"{date_parts[2]}-{date_parts[1]}-{date_parts[0]}"
                if len(date_parts) == 3
                else commit["date"]
            )
            print(
                f"  {commit_color}{commit['hash']}{RESET} | {author_color}{commit['author']}{RESET} | {LIGHT_GRAY}{formatted_date} {commit_time}{RESET}"
            )
            print(f"      {commit['message']}")

        print("\n--- Top Contributors ---")
        contrib_color = color_scheme.get(2)
        for contrib, count in get_top_contributors(
            repo_path, branch=branch, author=author
        ):
            print(f"  {count:>4}  {contrib_color}{contrib}{RESET}")


if __name__ == "__main__":
    main()
