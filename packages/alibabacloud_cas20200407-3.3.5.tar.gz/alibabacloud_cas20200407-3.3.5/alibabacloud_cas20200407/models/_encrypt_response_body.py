# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class EncryptResponseBody(DaraModel):
    def __init__(
        self,
        cert_identifier: str = None,
        ciphertext_blob: str = None,
        request_id: str = None,
    ):
        # The unique identifier of the certificate.
        self.cert_identifier = cert_identifier
        # The data after encryption. The value is encoded in Base64.
        self.ciphertext_blob = ciphertext_blob
        # The ID of the request.
        self.request_id = request_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.cert_identifier is not None:
            result['CertIdentifier'] = self.cert_identifier

        if self.ciphertext_blob is not None:
            result['CiphertextBlob'] = self.ciphertext_blob

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CertIdentifier') is not None:
            self.cert_identifier = m.get('CertIdentifier')

        if m.get('CiphertextBlob') is not None:
            self.ciphertext_blob = m.get('CiphertextBlob')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        return self

