========
backlog
========

CSS3 color module
-----------------
:prio: 1

- named colors::

    Black = #000000         Green = #008000
    Silver = #C0C0C0        Lime = #00FF00
    Gray = #808080      Olive = #808000
    White = #FFFFFF         Yellow = #FFFF00
    Maroon = #800000        Navy = #000080
    Red = #FF0000       Blue = #0000FF
    Purple = #800080        Teal = #008080
    Fuchsia = #FF00FF       Aqua = #00FFFF

- "transparent"
- SVG colors?
- "currentColor"
- "flavor"?
- System Colors are DEPRECATED!

Fix profile.


Selector
--------
:prio: 1

- CSS2XPath converter -> use lxml.cssselector
- optimize selector parsing?
- **add query functionality**
    + specificity DONE
    + cascade


CSSValue
--------
:prio: 3

**this feature may be implemented later as CSSOM defines the complete thing differently**

implement RGBColor, Rect and Counter

serializer
~~~~~~~~~~
- add preference option how color values should be serializer:

  ser.prefs.COLORS_HEX, also the DEFAULT?
        e.g. #123, so short form is possible
        ignored for rgba()
  ser.prefs.COLORS_HEXFULL
        e.g. #112233, so always 6digit hex
        ignored for rgba()
  ser.prefs.COLORS_RGB_INTEGER
        e.g. rgb(1.1, 55, 255), so range from 0-255
        also for rgba()
  ser.prefs.COLORS_RGB_PERCENTAGE
        e.g. rgb(10%, 20%, 100%), so range from 0 to 100%
        also for rgba()
  ser.prefs.COLORS_FROM_SOURCE
        use colors as used in CSS Source

  additionally:
    ser.prefs.NAMED_COLORS
        e.g. white for #fff or rgb(100%, 100%, 100%)

- **refactor**: all preferences values should be constansts like above

CSS2Properties
--------------
:prio: 3

needs to be implemented fully, setting of margin: 1px sets actually marginTop, marginLeft etc


performance
-----------
:prio: 3


serializer
----------
:prio: 2

- prettyprint convinience serializer?
- XML serializer to be able to handle CSS with XSLT, schemas etc?
- different coding styles?


LinkStyle, DocumentStyle
------------------------
:prio: 3

::

    // Introduced in DOM Level 2:
    interface LinkStyle {
      readonly attribute StyleSheet       sheet;
    };
    // Introduced in DOM Level 2:
    interface DocumentStyle {
      readonly attribute StyleSheetList   styleSheets;
    };
