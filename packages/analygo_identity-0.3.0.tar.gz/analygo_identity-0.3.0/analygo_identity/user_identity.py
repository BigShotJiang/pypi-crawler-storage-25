"""User identity protocol for type-safe authentication across services.

This module defines the canonical interface for user objects, preventing
type mismatches like accessing .id when the attribute is .sub.
"""

from typing import Protocol, runtime_checkable, cast, TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Any


@runtime_checkable
class UserIdentity(Protocol):
    """Protocol defining the canonical interface for authenticated users.

    Any object representing an authenticated user must satisfy this protocol.
    Primary identifier is 'sub' (subject), not 'id', following JWT/OIDC conventions.

    Example:
        >>> user: UserIdentity = get_current_user()
        >>> user.sub  # Canonical user identifier
        'auth0|123456'
    """

    @property
    def sub(self) -> str:
        """Canonical user identifier (subject claim from auth provider)."""
        ...

    @property
    def email(self) -> str | None:
        """User's email address, if available."""
        ...


class UserIdentityValidator:
    """Runtime validator for user objects.

    Provides clear error messages when objects don't satisfy UserIdentity protocol,
    catching issues like missing .sub or using .id instead.
    """

    @staticmethod
    def _get_sub(user: object) -> str | None:
        """Extract 'sub' from an object or dict."""
        if isinstance(user, dict):
            return user.get("sub")  # type: ignore[return-value]
        if hasattr(user, "sub"):
            return getattr(user, "sub")
        return None

    @staticmethod
    def _has_sub(user: object) -> bool:
        """Check if user has 'sub' (as attribute or dict key)."""
        if isinstance(user, dict):
            return "sub" in user
        return hasattr(user, "sub")

    @staticmethod
    def _has_id_not_sub(user: object) -> bool:
        """Check for common mistake: has 'id' but not 'sub'."""
        if isinstance(user, dict):
            return "id" in user and "sub" not in user
        return hasattr(user, "id") and not hasattr(user, "sub")

    @staticmethod
    def _dir(user: object) -> list[str]:
        """List available keys/attributes for error messages."""
        if isinstance(user, dict):
            return list(user.keys())
        return [a for a in dir(user) if not a.startswith("_")]

    @staticmethod
    def validate_sub(user: object, context: str = "") -> str:
        """Extract and validate user.sub with clear error on failure.

        Supports both objects (attribute access) and dicts (key access).

        Args:
            user: Object or dict expected to satisfy UserIdentity protocol
            context: Additional context for error messages (e.g., function name)

        Returns:
            The user's sub (subject identifier)

        Raises:
            AttributeError: If user.sub is missing or user uses wrong attribute name
            TypeError: If user is None or wrong type
        """
        if user is None:
            raise TypeError(
                f"{context}: User object is None. "
                "Ensure authentication dependency returned a valid user."
            )

        # Check for common mistake: using .id / ["id"] instead of .sub / ["sub"]
        if UserIdentityValidator._has_id_not_sub(user):
            raise AttributeError(
                f"{context}: User object has 'id' but not 'sub'. "
                "Use user.sub (not user.id) for the canonical user identifier."
            )

        if not UserIdentityValidator._has_sub(user):
            raise AttributeError(
                f"{context}: User object missing 'sub' attribute. "
                f"Available attributes: {UserIdentityValidator._dir(user)}. "
                "User must satisfy UserIdentity protocol."
            )

        sub = UserIdentityValidator._get_sub(user)
        if not isinstance(sub, str):
            raise TypeError(
                f"{context}: user.sub must be str, got {type(sub).__name__}"
            )

        return sub

    @staticmethod
    def validate(user: object, context: str = "") -> "UserIdentity":
        """Validate user object satisfies UserIdentity protocol.

        Args:
            user: Object to validate
            context: Additional context for error messages

        Returns:
            The user object cast to UserIdentity

        Raises:
            TypeError: If user doesn't satisfy the protocol
        """
        if not isinstance(user, UserIdentity):
            raise TypeError(
                f"{context}: User object does not satisfy UserIdentity protocol. "
                f"Type: {type(user).__name__}. "
                "Required: .sub (str), .email (str | None)"
            )
        return cast("UserIdentity", user)
