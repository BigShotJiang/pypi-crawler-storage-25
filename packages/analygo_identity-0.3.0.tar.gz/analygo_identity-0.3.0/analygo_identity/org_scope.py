"""Workspace resolution types and header parsing for multi-tenant org scoping."""

from dataclasses import dataclass
from typing import Optional, Literal
from uuid import UUID

# ── Header constants ──────────────────────────────────────────────

HEADER_ORG_ID = "X-Org-Id"
HEADER_CLIENT_ID = "X-Client-Id"
HEADER_PORTAL_REQUEST_ID = "X-Portal-Request-Id"
HEADER_PORTAL_SERVICE = "X-Portal-Service"
HEADER_AUDITOR_INTERNAL = "X-Auditor-Internal"

# ── System org ────────────────────────────────────────────────────

SYSTEM_ORG_ID = "00000000-0000-0000-0000-000000000001"

# ── Literal types ─────────────────────────────────────────────────

LineageSource = Literal[
    "portal_request",
    "org_scope",
    "portal_membership",
    "fallback_org",
    "refresh_parent",
]

OrgScopeResolvedTo = Literal["system", "portal", "header"]

SystemOrgReason = Literal["no_portal_orgs", "internal_run", "demo", "worker"]


# ── Dataclasses ───────────────────────────────────────────────────


@dataclass(frozen=True)
class ResolvedOrg:
    """Result of org resolution — mirrors TS OrgContext."""
    org_id: UUID
    client_id: Optional[UUID]
    portal_request_id: Optional[UUID]
    lineage_source: LineageSource
    lineage_reason: Optional[str]
    org_scope_resolved_to: OrgScopeResolvedTo
    system_org_reason: Optional[SystemOrgReason] = None


@dataclass(frozen=True)
class OrgScope:
    """Tenant scope extracted from request headers."""
    org_id: UUID
    client_id: Optional[UUID] = None
    portal_request_id: Optional[UUID] = None


# ── Header parsing ────────────────────────────────────────────────


def _parse_uuid(value: Optional[str]) -> Optional[UUID]:
    """Parse a string to UUID, returning None for invalid/missing input."""
    if not value:
        return None
    try:
        return UUID(value)
    except (ValueError, AttributeError):
        return None


def get_org_scope(headers: dict[str, str]) -> Optional[OrgScope]:
    """Extract OrgScope from request headers.

    Returns None if X-Org-Id header is missing or invalid.
    """
    org_id_raw = headers.get(HEADER_ORG_ID)
    org_id = _parse_uuid(org_id_raw)
    if org_id is None:
        return None

    return OrgScope(
        org_id=org_id,
        client_id=_parse_uuid(headers.get(HEADER_CLIENT_ID)),
        portal_request_id=_parse_uuid(headers.get(HEADER_PORTAL_REQUEST_ID)),
    )


def is_portal_originated(headers: dict[str, str]) -> bool:
    """Check if request originated from the portal service."""
    return HEADER_PORTAL_REQUEST_ID in headers or HEADER_PORTAL_SERVICE in headers
