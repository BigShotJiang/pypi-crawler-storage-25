"""Abstract base for authority services across Analygo surfaces.

An authority service validates whether a user has the right to perform
an action within an organization context. Concrete implementations
resolve membership from different backends:

- Backend-native: org membership resolver + Portal DB (platform)
- Portal-forwarded: HTTP-forwarded authority checks (legacy Portal)
- AEGIS-native: brain-level agent authorization

All authority services share a common interface so consumers can
validate access without knowing which backend is authoritative.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, List, Optional


@dataclass(frozen=True)
class AuthorityResult:
    """Result of an authority check.

    Attributes:
        granted: True when the action is authorized
        reason: Human-readable explanation when not granted
        context: Additional metadata about the decision (role used, source, etc.)
    """

    granted: bool
    reason: str = ""
    context: dict[str, Any] = field(default_factory=dict)


class AuthorityService(ABC):
    """Abstract base for identity authority services.

    Concrete subclasses implement ``authorize`` and ``resolve_identity``
    to validate user access for a given organization context.

    Thread-safe: subclasses should not mutate instance state during checks.
    """

    @abstractmethod
    async def authorize(
        self,
        *,
        user_sub: str,
        org_id: Optional[str] = None,
        action: str = "access",
        **kwargs: Any,
    ) -> AuthorityResult:
        """Check whether a user is authorized for an action in an org context.

        Args:
            user_sub: Canonical user identifier (sub claim from auth).
            org_id: Target organization ID. May be None for global actions.
            action: Action being authorized (e.g. "access", "admin", "invite").
            **kwargs: Subclass-specific parameters.

        Returns:
            AuthorityResult with granted=True/False and reason.
        """
        ...

    @abstractmethod
    async def resolve_identity(
        self,
        *,
        user_sub: str,
        org_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Resolve identity information for a user in an org context.

        Args:
            user_sub: Canonical user identifier.
            org_id: Optional org to scope the resolution.

        Returns:
            Dict with at minimum ``org_ids``, ``role``, and any available profile data.
        """
        ...

    async def require(
        self,
        *,
        user_sub: str,
        org_id: Optional[str] = None,
        action: str = "access",
        **kwargs: Any,
    ) -> None:
        """Authorize and raise if not granted.

        Convenience wrapper for callers that want exception-based gating.

        Raises:
            PermissionError: If authorization is denied.
        """
        result = await self.authorize(
            user_sub=user_sub,
            org_id=org_id,
            action=action,
            **kwargs,
        )
        if not result.granted:
            raise PermissionError(
                f"Authorization denied for user={user_sub} "
                f"org={org_id} action={action}: {result.reason}"
            )
