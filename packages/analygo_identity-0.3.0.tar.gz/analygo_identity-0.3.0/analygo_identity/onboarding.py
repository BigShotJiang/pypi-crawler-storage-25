"""Onboarding state machine for multi-surface identity lifecycle.

Defines generic steps common to all Analygo surfaces. Per-service
extensions (e.g. Platform: ``connect_first_site``, AEGIS: ``select_default_agent``,
Portal: ``invite_team_members``) live in each service's own code, not in this package.
"""

from __future__ import annotations

from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional


class StepStatus(Enum):
    """Status of a single onboarding step."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SKIPPED = "skipped"


class OnboardingStep(str, Enum):
    """Generic onboarding steps shared across all Analygo surfaces.

    These four steps are the minimum common path. Services extend via
    ExtensionStep API (see ``OnboardingState.add_extension_step``).
    """

    VERIFY_EMAIL = "verify_email"
    CREATE_ORG = "create_org"
    CREATE_WORKSPACE = "create_workspace"
    SETUP_BILLING = "setup_billing"


@dataclass
class OnboardingState:
    """Onboarding progress for a user across one or more surfaces.

    The state machine tracks which steps exist, their status, and when
    each was completed. Steps are ordered; the ``current_step`` property
    returns the first non-completed step.

    Extension steps can be added at runtime via ``add_extension_step``
    for service-specific onboarding requirements.

    Example:
        >>> state = OnboardingState()
        >>> state.advance(OnboardingStep.VERIFY_EMAIL)
        >>> state.current_step
        <OnboardingStep.CREATE_ORG: 'create_org'>
        >>> state.is_complete
        False
    """

    steps: list[OnboardingStep] = field(
        default_factory=lambda: [
            OnboardingStep.VERIFY_EMAIL,
            OnboardingStep.CREATE_ORG,
            OnboardingStep.CREATE_WORKSPACE,
            OnboardingStep.SETUP_BILLING,
        ]
    )
    statuses: dict[OnboardingStep, StepStatus] = field(default_factory=dict)
    completed_at: dict[OnboardingStep, Optional[datetime]] = field(default_factory=dict)

    # Extension-point API for per-service steps
    _extension_loaders: list[Callable[[], list[OnboardingStep]]] = field(default_factory=list, repr=False)

    def __post_init__(self) -> None:
        """Initialize all steps as PENDING."""
        for step in self.steps:
            if step not in self.statuses:
                self.statuses[step] = StepStatus.PENDING
            if step not in self.completed_at:
                self.completed_at[step] = None

    @property
    def current_step(self) -> Optional[OnboardingStep]:
        """The first step that is not COMPLETED or SKIPPED, or None if all done."""
        for step in self.steps:
            status = self.statuses.get(step, StepStatus.PENDING)
            if status not in (StepStatus.COMPLETED, StepStatus.SKIPPED):
                return step
        return None

    @property
    def is_complete(self) -> bool:
        """True when all registered steps are COMPLETED or SKIPPED."""
        return self.current_step is None

    def advance(self, step: OnboardingStep) -> None:
        """Mark a step as COMPLETED at the current time.

        Args:
            step: The step to advance. Must be in ``steps``.
        """
        if step not in self.steps:
            raise ValueError(
                f"Unknown onboarding step: {step!r}. "
                f"Known steps: {[s.value for s in self.steps]}"
            )
        self.statuses[step] = StepStatus.COMPLETED
        self.completed_at[step] = datetime.utcnow()

    def skip(self, step: OnboardingStep) -> None:
        """Mark a step as SKIPPED.

        Args:
            step: The step to skip. Must be in ``steps``.
        """
        if step not in self.steps:
            raise ValueError(
                f"Unknown onboarding step: {step!r}. "
                f"Known steps: {[s.value for s in self.steps]}"
            )
        self.statuses[step] = StepStatus.SKIPPED
        self.completed_at[step] = None

    def progress(self, step: OnboardingStep) -> None:
        """Mark a step as IN_PROGRESS.

        Args:
            step: The step being worked on. Must be in ``steps``.
        """
        if step not in self.steps:
            raise ValueError(
                f"Unknown onboarding step: {step!r}. "
                f"Known steps: {[s.value for s in self.steps]}"
            )
        self.statuses[step] = StepStatus.IN_PROGRESS

    def reset(self, step: OnboardingStep) -> None:
        """Reset a step back to PENDING.

        Useful for re-doing a step after a failure.

        Args:
            step: The step to reset.
        """
        if step not in self.steps:
            raise ValueError(
                f"Unknown onboarding step: {step!r}. "
                f"Known steps: {[s.value for s in self.steps]}"
            )
        self.statuses[step] = StepStatus.PENDING
        self.completed_at[step] = None

    # ------------------------------------------------------------------
    # Extension Point API
    # ------------------------------------------------------------------

    def register_extension_loader(
        self,
        loader: Callable[[], list[OnboardingStep]],
    ) -> None:
        """Register a callable that returns service-specific extension steps.

        The loader is called once, when ``load_extensions`` is invoked.
        This allows lazy discovery of extension steps without tight coupling.

        Args:
            loader: A zero-argument callable returning a list of OnboardingStep values.
        """
        self._extension_loaders.append(loader)

    def load_extensions(self) -> list[OnboardingStep]:
        """Invoke all registered extension loaders and append new steps.

        Returns:
            The list of newly added extension steps.
        """
        added: list[OnboardingStep] = []
        for loader in self._extension_loaders:
            try:
                ext_steps = loader()
                for ext_step in ext_steps:
                    if ext_step not in self.steps:
                        self.steps.append(ext_step)
                        self.statuses[ext_step] = StepStatus.PENDING
                        self.completed_at[ext_step] = None
                        added.append(ext_step)
            except Exception:
                # Fail-soft: log and continue
                logger = __import__("logging").getLogger(__name__)
                logger.exception("Onboarding extension loader failed: %s", loader)
        return added

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialize onboarding state to a JSON-compatible dict.

        Returns:
            Dict with ``current_step``, ``is_complete``, ``steps``, and
            per-step status/completed_at entries.
        """
        return {
            "current_step": self.current_step.value if self.current_step else None,
            "is_complete": self.is_complete,
            "steps": [
                {
                    "step": s.value,
                    "status": (self.statuses.get(s) or StepStatus.PENDING).value,
                    "completed_at": (
                        self.completed_at[s].isoformat()
                        if self.completed_at.get(s)
                        else None
                    ),
                }
                for s in self.steps
            ],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "OnboardingState":
        """Deserialize onboarding state from a dict.

        Args:
            data: A dict previously produced by ``to_dict``.

        Returns:
            A new OnboardingState instance.
        """
        step_map = {s.value: s for s in OnboardingStep}
        raw_steps = data.get("steps", [])
        steps: list[OnboardingStep] = []
        statuses: dict[OnboardingStep, StepStatus] = {}
        completed_at: dict[OnboardingStep, Optional[datetime]] = {}

        for entry in raw_steps:
            step = step_map.get(entry["step"])
            if step is None:
                continue
            steps.append(step)
            raw_status = entry.get("status", "pending")
            statuses[step] = StepStatus(raw_status)
            raw_completed = entry.get("completed_at")
            completed_at[step] = (
                datetime.fromisoformat(raw_completed)
                if raw_completed
                else None
            )

        state = cls(steps=steps, statuses=statuses, completed_at=completed_at)
        return state
