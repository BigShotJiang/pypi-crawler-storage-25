"""Canonical structured logging for identity / org membership resolution.

Uses stdlib ``logging`` with ``extra={"identity_event": {...}}``.

**identity_event schema** (stable keys; all values JSON-serializable primitives or lists of strings):

- ``event``: always ``identity.resolution`` unless overridden.
- ``surface``: ``backend_resolver`` | ``backend_me_orgs`` | ``portal_user_orgs`` | ``portal_verify_org_access``.
- ``resolution_status``: ``ok`` | ``empty`` | ``unavailable``.
- ``request_id``: correlation id when set.
- ``sub_prefix``: first 8 chars of ``membership_sub``.
- ``effective_lookup_sub``: first 8 chars of the canonical Portal/cache lookup key.
- ``users_logs_sub_prefix``: optional; first 8 of ``UsersLog.sub`` when supplied.
- ``error_code``: optional when guarded or failed (e.g. ``canonical_sub_missing``).
- ``org_count``, ``org_ids``: UUID strings from the resolved payload (empty when unavailable).
- ``identity_source``: how membership sub was derived.
- ``resolver_source``: ``ResolveResult.source`` when applicable.
- ``active_org_id``: when known.

**Never** log access tokens, refresh tokens, or cookie values.
"""

from __future__ import annotations

import logging
from typing import Any, List, Literal, Optional

logger = logging.getLogger("analygo_identity.identity_resolution")

Surface = Literal["backend_resolver", "backend_me_orgs", "portal_user_orgs", "portal_verify_org_access"]
ResolutionStatus = Literal["ok", "empty", "unavailable"]


def _sub_prefix(sub: Optional[str]) -> Optional[str]:
    s = (sub or "").strip()
    if not s:
        return None
    return s[:8]


def log_identity_resolution(
    *,
    surface: Surface,
    resolution_status: ResolutionStatus,
    request_id: Optional[str] = None,
    identity_source: Optional[str] = None,
    resolver_source: Optional[str] = None,
    membership_sub: Optional[str] = None,
    users_logs_sub: Optional[str] = None,
    effective_lookup_sub: Optional[str] = None,
    org_ids: Optional[List[str]] = None,
    org_count: Optional[int] = None,
    active_org_id: Optional[str] = None,
    email: Optional[str] = None,
    error_code: Optional[str] = None,
    event: str = "identity.resolution",
    log_level: int = logging.INFO,
) -> None:
    """Emit one structured ``identity_event`` line for cross-surface correlation."""
    oids = [str(x) for x in (org_ids or []) if x is not None and str(x).strip()]
    count = org_count if org_count is not None else len(oids)
    canonical_for_prefix = (
        effective_lookup_sub if effective_lookup_sub is not None else membership_sub
    )
    mem_prefix = _sub_prefix(membership_sub) or ""
    eff_prefix = _sub_prefix(canonical_for_prefix) or ""
    payload: dict[str, Any] = {
        "event": event,
        "surface": surface,
        "resolution_status": resolution_status,
        "request_id": request_id or "",
        "sub_prefix": mem_prefix,
        "effective_lookup_sub": eff_prefix,
        "org_count": count,
        "org_ids": oids,
    }
    usp = _sub_prefix(users_logs_sub)
    if usp:
        payload["users_logs_sub_prefix"] = usp
    if identity_source:
        payload["identity_source"] = identity_source
    if resolver_source:
        payload["resolver_source"] = resolver_source
    if active_org_id:
        payload["active_org_id"] = str(active_org_id)
    if email is not None:
        payload["has_email"] = bool((email or "").strip())
    ec = (error_code or "").strip()
    if ec:
        payload["error_code"] = ec

    logger.log(
        log_level,
        "identity.resolution",
        extra={"identity_event": payload},
    )
