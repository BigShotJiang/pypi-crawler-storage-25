"""Canonical identity type hierarchy for Analygo platform."""

from datetime import datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, Field


class Organization(BaseModel):
    """Root tenant entity. All other entities belong to an organization."""

    id: UUID = Field(..., description="Unique organization identifier")
    name: str = Field(..., description="Organization display name")
    slug: str = Field(..., description="URL-safe organization identifier")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        frozen = True


class Workspace(BaseModel):
    """Groups projects, teams, or clients within an organization."""

    id: UUID = Field(..., description="Unique workspace identifier")
    org_id: UUID = Field(..., description="Parent organization ID")
    name: str = Field(..., description="Workspace display name")
    slug: str = Field(..., description="URL-safe workspace identifier")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        frozen = True


class Property(BaseModel):
    """Auditable entity: website, mobile app, or digital property."""

    id: UUID = Field(..., description="Unique property identifier")
    org_id: UUID = Field(..., description="Parent organization ID")
    workspace_id: Optional[UUID] = Field(None, description="Optional workspace grouping")
    name: str = Field(..., description="Property display name (e.g., 'Main Website')")
    domain: str = Field(..., description="Primary domain or identifier")
    property_type: str = Field("website", description="Type: website, mobile_app, etc.")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        frozen = True


class Target(BaseModel):
    """Specific URL or identifier to audit within a property."""

    id: UUID = Field(..., description="Unique target identifier")
    property_id: UUID = Field(..., description="Parent property ID")
    url: str = Field(..., description="Target URL or identifier")
    label: Optional[str] = Field(None, description="Human-readable label")
    is_primary: bool = Field(False, description="Primary target for this property")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        frozen = True


class Session(BaseModel):
    """Optional audit run or conversation session instance."""

    id: UUID = Field(..., description="Unique session identifier")
    org_id: UUID = Field(..., description="Parent organization ID")
    workspace_id: Optional[UUID] = Field(None, description="Optional workspace context")
    property_id: Optional[UUID] = Field(None, description="Optional property context")
    user_id: UUID = Field(..., description="User who initiated session")
    session_type: str = Field("audit", description="Type: audit, conversation, etc.")
    started_at: datetime = Field(default_factory=datetime.utcnow)
    ended_at: Optional[datetime] = Field(None)

    class Config:
        frozen = True
