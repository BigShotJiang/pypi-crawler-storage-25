# analygo-identity (Python)

Shared identity resolution, authority services, and onboarding state management.

Consumed as `analygo-identity` from GitHub Packages.
