# haber-devops

`haber-devops` is a CLI tool for managing common AWS tasks (EC2, ECR, S3, RDS, Route53) plus a few Docker helpers.

## Install

```bash
pip install haber-devops
```

## Quick start

```bash
haber-devops -h
```

## Common commands

```bash
# Initialize local config.json
haber-devops initialize

# Add an AWS profile into config.json (interactive)
haber-devops add-account

# List instances (interactive)
haber-devops list-instances

# EC2
haber-devops ec2 -h
haber-devops ec2 start <instance_name>
haber-devops ec2 stop <instance_name>
haber-devops ec2 ssh <instance_name> <command>

# Deploy (optional tag override)
haber-devops deploy -h
haber-devops deploy <profile> <resource> <folder_path> --tag v1.7

# Docker helpers
haber-devops docker -h
```

