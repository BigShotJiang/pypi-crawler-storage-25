from setuptools import setup, find_packages
from pathlib import Path

def _read_readme() -> str:
    try:
        return (Path(__file__).resolve().with_name("README.md")).read_text(encoding="utf-8")
    except FileNotFoundError:
        return ""

setup(
    name='haber-devops',
    version='1.1.3',
    description='CLI tool for managing AWS resources',
    long_description=_read_readme(),
    long_description_content_type="text/markdown",
    author='Shweta Jha',
    author_email='shweta.jha@haberwater.com',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'boto3',
        'docker',
        'PyYAML',
        'paramiko'
    ],
    entry_points={
        'console_scripts': [
            'haber-devops=haberdevops.main:main',
        ],
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
