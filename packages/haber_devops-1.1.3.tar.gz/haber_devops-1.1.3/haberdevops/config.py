import json
import os
from pathlib import Path

import boto3


def get_default_user_config_path() -> Path:
    override = os.environ.get("HABER_DEVOPS_CONFIG")
    if override:
        return Path(override).expanduser().resolve()

    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".config"
    return (base / "haber-devops" / "config.json").resolve()

def get_default_system_config_path() -> Path:
    return Path("/var/lib/haber-devops/config.json")

def find_config_path() -> Path:
    """
    Lookup order:
    - HABER_DEVOPS_CONFIG if set
    - ./config.json if present (legacy / per-project)
    - /var/lib/haber-devops/config.json if present (system-wide)
    - ~/.config/haber-devops/config.json (default per-user)
    """
    override = os.environ.get("HABER_DEVOPS_CONFIG")
    if override:
        return Path(override).expanduser().resolve()

    cwd_path = (Path.cwd() / "config.json").resolve()
    if cwd_path.is_file():
        return cwd_path

    system_path = get_default_system_config_path()
    if system_path.is_file():
        return system_path

    return get_default_user_config_path()


def get_config_path() -> Path:
    # Backwards-compatible alias
    return find_config_path()


def config_exists() -> bool:
    return get_config_path().is_file()

def initialize_config():
    # Initialize in the per-user location by default (not in cwd, not in /var).
    target_path = get_default_user_config_path()
    target_path.parent.mkdir(parents=True, exist_ok=True)

    legacy_path = Path.cwd() / "config.json"
    if legacy_path.is_file() and not target_path.is_file():
        try:
            legacy_config = json.loads(legacy_path.read_text(encoding="utf-8"))
            save_config(legacy_config)
            print(f"Migrated config from '{legacy_path}' to '{target_path}'.")
            return
        except Exception:
            # If legacy file is invalid, fall back to creating a fresh config.
            pass

    config = {"accounts": {}, "deploy": {}}
    save_config(config)
    print(f"Initialized config at '{target_path}'.")

def load_config(create_if_missing: bool = True):
    config_path = get_config_path()
    try:
        with open(config_path, "r", encoding="utf-8") as config_file:
            return json.load(config_file)
    except FileNotFoundError:
        if not create_if_missing:
            raise FileNotFoundError(
                "Config not found. Run `haber-devops initialize` then `haber-devops add-account`."
            )
        initialize_config()
        # After initialize, read from the user config location.
        with open(get_default_user_config_path(), "r", encoding="utf-8") as config_file:
            return json.load(config_file)

def save_config(config):
    # Always write to the user config location (never write to cwd or /var implicitly).
    config_path = get_default_user_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w", encoding="utf-8") as config_file:
        json.dump(config, config_file, indent=4)

def add_aws_account(profile_name, access_key, secret_key, region):
    config = load_config()
    config['accounts'][profile_name] = {
        'access_key': access_key,
        'secret_key': secret_key,
        'region': region,
        'instances': []
    }
    save_config(config)
    print(f"AWS account '{profile_name}' added successfully.")

def get_ssh_key_path(profile_name):
    config = load_config()
    return config['accounts'][profile_name].get('ssh_key_path', None)


def list_instances(profile_name):
    config = load_config()
    aws_access_key = config['accounts'][profile_name]['access_key']
    aws_secret_key = config['accounts'][profile_name]['secret_key']
    aws_region = config['accounts'][profile_name]['region']

    ec2_client = boto3.client('ec2', aws_access_key_id=aws_access_key, aws_secret_access_key=aws_secret_key, region_name=aws_region)

    response = ec2_client.describe_instances()

    instances = []
    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            instance_id = instance['InstanceId']
            private_ip = instance.get('PrivateIpAddress', 'N/A')
            public_ip = instance.get('PublicIpAddress', 'N/A')
            instances.append({
                'InstanceId': instance_id,
                'PrivateIp': private_ip,
                'PublicIp': public_ip
            })

    config['accounts'][profile_name]['instances'] = instances
    save_config(config)

    if instances:
        print(f"Instances in profile '{profile_name}':")
        for instance in instances:
            print(f"Instance ID: {instance['InstanceId']}, Private IP: {instance['PrivateIp']}, Public IP: {instance['PublicIp']}")
    else:
        print(f"No instances found in profile '{profile_name}'.")

    print(f"Instances in profile '{profile_name}' have been updated in config file.")


def list_s3_buckets(profile_name):
    config = load_config()
    aws_access_key = config['accounts'][profile_name]['access_key']
    aws_secret_key = config['accounts'][profile_name]['secret_key']
    aws_region = config['accounts'][profile_name]['region']

    s3_client = boto3.client('s3', aws_access_key_id=aws_access_key, aws_secret_access_key=aws_secret_key, region_name=aws_region)

    response = s3_client.list_buckets()

    buckets = []
    for bucket in response['Buckets']:
        buckets.append(bucket['Name'])

    config['accounts'][profile_name]['s3_buckets'] = buckets
    save_config(config)

    if buckets:
        print(f"S3 buckets in profile '{profile_name}':")
        for bucket in buckets:
            print(bucket)
    else:
        print(f"No S3 buckets found in profile '{profile_name}'.")

    print(f"S3 buckets in profile '{profile_name}' have been updated in config file.")

def update_deploy_config(profile_name, resource_name, algorithm, version, path):
    config = load_config()
    if profile_name not in config['deploy']:
        config['deploy'][profile_name] = {}
    if resource_name not in config['deploy'][profile_name]:
        config['deploy'][profile_name][resource_name] = {}
    if algorithm not in config['deploy'][profile_name][resource_name]:
        config['deploy'][profile_name][resource_name][algorithm] = {}
    config['deploy'][profile_name][resource_name][algorithm]['name'] = f"{resource_name}_{algorithm}_algorithm"
    config['deploy'][profile_name][resource_name][algorithm]['path'] = path
    config['deploy'][profile_name][resource_name][algorithm]['tag'] = version
    save_config(config)
    print(f"Deployment configuration for '{resource_name}' updated successfully.")

def get_route53_client(profile_name=None):
    if not profile_name:
        profile_name = input("Enter AWS profile name: ")

    config = load_config()
    aws_access_key = config['accounts'][profile_name]['access_key']
    aws_secret_key = config['accounts'][profile_name]['secret_key']
    aws_region = config['accounts'][profile_name]['region']
    
    session = boto3.Session(
        aws_access_key_id=aws_access_key,
        aws_secret_access_key=aws_secret_key,
        region_name=aws_region
    )
    
    return session.client('route53')