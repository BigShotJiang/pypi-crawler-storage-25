"""Query registry and DuckDB collection engine for Calypso."""

import base64
import inspect
import logging
from dataclasses import dataclass, field
from datetime import datetime, date
from decimal import Decimal
from pathlib import Path

import duckdb
import oracledb

from calypso.db import queries

logger = logging.getLogger(__name__)

# Dedicated per-table log: one line per query with the row count, written to
# whatever FileHandler calypso.py attaches. propagate=False is set there.
queries_logger = logging.getLogger("calypso.queries")

# Oracle prefetch / DuckDB insert batch size. 1000 keeps per-batch memory bounded
# while being 10x the oracledb default arraysize of 100.
FETCH_CHUNK_SIZE = 1000


@dataclass
class CollectionResult:
    duckdb_path: Path
    tables_collected: int = 0
    tables_failed: int = 0
    errors: list[dict] = field(default_factory=list)


def build_query_registry() -> dict[str, callable]:
    """Auto-discover all query functions in queries.py.

    Returns a dict of {table_name: callable} where table_name is the
    full function name (e.g. 'get_system_info_query', 'archive_log_info').
    """
    registry = {}
    for name, func in inspect.getmembers(queries, inspect.isfunction):
        if func.__module__ == queries.__name__:
            registry[name] = func
    # Safety check
    assert len(registry) == len(set(registry.keys())), "Duplicate table names in query registry"
    return registry


def _sanitize_value(val):
    """Convert Oracle-specific types to DuckDB-safe values."""
    if val is None:
        return None
    if isinstance(val, Decimal):
        return str(val)
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if isinstance(val, bytes):
        return base64.b64encode(val).decode("ascii")
    if hasattr(val, "read"):  # LOB objects
        data = val.read()
        if isinstance(data, bytes):
            return base64.b64encode(data).decode("ascii")
        return str(data)
    return str(val)


def _format_bytes(n: int) -> str:
    """Render a byte count as KB/MB/GB for human-readable progress output."""
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def _duckdb_memory_bytes(duckdb_conn) -> tuple[int, int]:
    """Return (resident_bytes, temp_spill_bytes) summed across DuckDB memory pools.

    Uses duckdb_memory(); returns (0, 0) if the function isn't available so
    progress reporting never fails the collection.
    """
    try:
        row = duckdb_conn.execute(
            "SELECT COALESCE(SUM(memory_usage_bytes), 0), "
            "COALESCE(SUM(temporary_storage_bytes), 0) "
            "FROM duckdb_memory()"
        ).fetchone()
        return int(row[0]), int(row[1])
    except Exception:
        return 0, 0


def _collect_one(
    oracle_conn,
    duckdb_conn,
    table_name,
    query_func,
    progress_callback=None,
    table_index=0,
    total_tables=0,
):
    """Execute one query against Oracle and stream results into DuckDB.

    Fetches in chunks of FETCH_CHUNK_SIZE so a single huge result set doesn't
    materialize in memory, and emits row-count progress updates so the bar
    doesn't appear frozen during multi-million-row queries.

    Returns (row_count, error_or_none). If a mid-stream Oracle error occurs,
    rows already inserted are kept and the error is reported.
    """
    cursor = None
    try:
        sql = query_func()
        cursor = oracle_conn.cursor()
        cursor.arraysize = FETCH_CHUNK_SIZE
        cursor.execute(sql)
        raw_columns = [col[0].lower() for col in cursor.description]
    except oracledb.Error as e:
        if cursor is not None:
            try:
                cursor.close()
            except Exception:
                pass
        error_obj = e.args[0] if e.args else e
        error_code = str(getattr(error_obj, "code", "N/A"))
        return 0, {"table_name": table_name, "error_code": error_code, "error_message": str(e)}

    # Deduplicate column names (e.g. two 'username' columns from a join)
    columns = []
    seen = {}
    for c in raw_columns:
        if c in seen:
            seen[c] += 1
            columns.append(f"{c}_{seen[c]}")
        else:
            seen[c] = 0
            columns.append(c)

    if not columns:
        duckdb_conn.execute(f'CREATE TABLE "{table_name}" (empty_result VARCHAR)')
        cursor.close()
        return 0, None

    col_defs = ", ".join(f'"{c}" VARCHAR' for c in columns)
    duckdb_conn.execute(f'CREATE TABLE "{table_name}" ({col_defs})')
    placeholders = ", ".join(["?"] * len(columns))
    insert_sql = f'INSERT INTO "{table_name}" VALUES ({placeholders})'

    total_rows = 0
    try:
        while True:
            batch = cursor.fetchmany(FETCH_CHUNK_SIZE)
            if not batch:
                break
            sanitized = [[_sanitize_value(v) for v in row] for row in batch]
            duckdb_conn.executemany(insert_sql, sanitized)
            total_rows += len(batch)
            if progress_callback:
                resident, spilled = _duckdb_memory_bytes(duckdb_conn)
                detail = f"{total_rows:,} rows · DuckDB {_format_bytes(resident)}"
                if spilled:
                    detail += f" (+{_format_bytes(spilled)} temp)"
                progress_callback(table_name, table_index, total_tables, detail=detail)
    except oracledb.Error as e:
        error_obj = e.args[0] if e.args else e
        error_code = str(getattr(error_obj, "code", "N/A"))
        return total_rows, {"table_name": table_name, "error_code": error_code, "error_message": str(e)}
    finally:
        try:
            cursor.close()
        except Exception:
            pass

    return total_rows, None


def run_collection(oracle_conn, output_dir, metadata=None, progress_callback=None, skip_queries=None):
    """Run all queries and store results in a DuckDB file.

    Args:
        oracle_conn: Active oracledb connection.
        output_dir: Directory for the .duckdb file.
        metadata: Dict of key/value pairs to store (host, port, etc.).
        progress_callback: Callable(table_name, current, total, detail=None) for progress updates.
            `detail` is an optional string describing in-query progress (e.g. row counts).
        skip_queries: Optional iterable of query function names to exclude from the run.

    Returns:
        CollectionResult with summary of the collection.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    duckdb_path = output_dir / "calypso_collection.duckdb"

    # Remove existing file to start fresh
    if duckdb_path.exists():
        duckdb_path.unlink()

    registry = build_query_registry()
    skipped = []
    if skip_queries:
        skip_set = {s for s in skip_queries if s}
        unknown = sorted(skip_set - registry.keys())
        if unknown:
            logger.warning("Unknown queries in skip list (ignored): %s", ", ".join(unknown))
        skipped = sorted(skip_set & registry.keys())
        if skipped:
            logger.info("Skipping %d queries by request: %s", len(skipped), ", ".join(skipped))
        registry = {k: v for k, v in registry.items() if k not in skip_set}
    result = CollectionResult(duckdb_path=duckdb_path)
    total = len(registry)

    con = duckdb.connect(str(duckdb_path))
    try:
        # Create metadata table
        con.execute("CREATE TABLE _metadata (key VARCHAR, value VARCHAR)")
        meta = {
            "calypso_collected_at": datetime.now().isoformat(),
            "query_count": str(total),
        }
        if skipped:
            meta["skipped_queries"] = ",".join(skipped)
        if metadata:
            meta.update(metadata)
        for k, v in meta.items():
            con.execute("INSERT INTO _metadata VALUES (?, ?)", [k, str(v)])

        # Create manifest and errors tables
        con.execute(
            "CREATE TABLE _manifest (table_name VARCHAR, row_count INTEGER, column_count INTEGER, collected_at TIMESTAMP)"
        )
        con.execute(
            "CREATE TABLE _errors (table_name VARCHAR, error_code VARCHAR, error_message VARCHAR)"
        )

        # Collect each query
        for i, (table_name, query_func) in enumerate(registry.items()):
            if progress_callback:
                progress_callback(table_name, i, total)

            row_count, error = _collect_one(
                oracle_conn,
                con,
                table_name,
                query_func,
                progress_callback=progress_callback,
                table_index=i,
                total_tables=total,
            )

            if error:
                result.tables_failed += 1
                result.errors.append(error)
                con.execute(
                    "INSERT INTO _errors VALUES (?, ?, ?)",
                    [error["table_name"], error["error_code"], error["error_message"]],
                )
                queries_logger.info("%s: FAILED (ORA-%s)", table_name, error["error_code"])
                # ORA-942 (table/view does not exist) is expected for optional
                # components like Statspack, x$ internal tables, and features
                # not installed on the target database.
                if error["error_code"] == "942":
                    logger.debug("Query '%s' skipped (ORA-942): table or view does not exist", table_name)
                else:
                    logger.warning("Query '%s' failed (ORA-%s): %s", table_name, error["error_code"], error["error_message"])
            else:
                result.tables_collected += 1
                # Get column count from the table we just created
                col_info = con.execute(f"SELECT * FROM \"{table_name}\" LIMIT 0").description
                col_count = len(col_info) if col_info else 0
                con.execute(
                    "INSERT INTO _manifest VALUES (?, ?, ?, ?)",
                    [table_name, row_count, col_count, datetime.now()],
                )
                queries_logger.info("%s: %d rows", table_name, row_count)
    finally:
        con.close()

    return result
