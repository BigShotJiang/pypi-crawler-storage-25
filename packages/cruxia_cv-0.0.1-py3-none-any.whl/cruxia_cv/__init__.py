"""cruxia-cv: vendor-agnostic LLM agent measurement (placeholder reservation, full package coming soon)."""
__version__ = "0.0.1"
