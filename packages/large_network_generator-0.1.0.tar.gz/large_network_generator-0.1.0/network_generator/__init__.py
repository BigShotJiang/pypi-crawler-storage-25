"""
Network Generator Package

A Python implementation of a real-world network generation algorithm.
"""

from .core import generate_network
from .find_clustering import find_coefficients, graph_to_igraph

__version__ = "0.1.0"
__author__ = "João Pedro Carolino Morais"
__email__ = "jpcmorais2001@gmail.com"

__all__ = ["generate_network", "graph_to_igraph", "find_coefficients"] 