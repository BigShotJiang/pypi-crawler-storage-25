"""
Core network generation functionality.
"""

import random
import time

# Global random number generator
random.seed(time.time())

def event_occurs(p):
    """Returns True with probability p, False with probability 1-p"""
    return random.random() < p

def get_random_integer(min_val, max_val):
    """Returns a random integer between min_val and max_val (inclusive)"""
    return random.randint(min_val, max_val)

# Cache for P function calculations
p_cache = {}

def P(p, x):
    """Calculates the probability distribution for step lengths"""
    if p == 0.0:
        return 0.1
    denominator = 1.0 - pow(1.0 - p, 10)
    return (p * pow(1.0 - p, x - 1)) / denominator

def get_number_of_steps(p):
    """Returns a random number of steps based on probability distribution P"""
    if p not in p_cache:
        weights = []
        for x in range(1, 11): 
            weights.append(P(p, x))
        p_cache[p] = weights
    
    total_weight = sum(p_cache[p])
    r = random.uniform(0, total_weight)
    cumulative_weight = 0
    for i, weight in enumerate(p_cache[p]):
        cumulative_weight += weight
        if r <= cumulative_weight:
            return i + 1

def random_walk(graph, start, number_of_steps):
    """Performs a random walk on the graph for the specified number of steps"""
    current_index = start
    
    for _ in range(number_of_steps):
        current_neighbors = graph[current_index]
        if not current_neighbors:
            break
        
        # Convert set to list for indexing
        neighbors_list = list(current_neighbors)
        set_index = get_random_integer(0, len(neighbors_list) - 1)
        current_index = neighbors_list[set_index]
    
    return current_index

def generate_network(N, m, p, fp, starting_graph=None):
    """
    Generates a network using the algorithm from the C++ implementation.
    
    Args:
        N (int): Number of additional nodes to add
        m (int): Number of marked nodes for each new node
        p (float): Step length probability (0.0 to 1.0)
        fp (float): Friendship probability (0.0 to 1.0)
        starting_graph (list[set], optional): Initial graph to build upon. 
                                            If None, starts with a ring of 10 nodes.
    
    Returns:
        list[set]: List of sets, where each set contains the neighbors of the corresponding node
        
    Raises:
        ValueError: If parameters are invalid
        
    Example:
        >>> network = generate_network(N=1000, m=5, p=0.5, fp=0.3)
        >>> print(f"Generated network with {len(network)} nodes")
        Generated network with 1010 nodes
        
        >>> # Start with a custom graph
        >>> custom_start = [set([1, 2]), set([0, 2]), set([0, 1])]
        >>> network = generate_network(N=100, m=3, p=0.5, fp=0.3, starting_graph=custom_start)
    """
    # Input validation
    if N < 0:
        raise ValueError("N must be non-negative")
    if m < 1:
        raise ValueError("m must be at least 1")
    if not 0.0 <= p <= 1.0:
        raise ValueError("p must be between 0.0 and 1.0")
    if not 0.0 <= fp <= 1.0:
        raise ValueError("fp must be between 0.0 and 1.0")
    
    # Initialize graph with starting_graph or default ring of 10 nodes
    if starting_graph is None:
        # Default: Initialize graph with 10 nodes in a ring structure
        graph = [set() for _ in range(10)]
        
        # Create initial ring structure
        for i in range(10):
            graph[i].add((i + 1) % 10)
            if i > 0:
                graph[i].add(i - 1)
        graph[0].add(9)
        
        n_nodes = 10
    else:
        # Use provided starting graph
        graph = [neighbors.copy() for neighbors in starting_graph]
        n_nodes = len(graph)
    
    # Add N new nodes
    for _ in range(N):
        start = get_random_integer(0, n_nodes - 1)
        current = start
        
        marked = [start]
        
        # Perform random walks to find m-1 additional marked nodes
        for _ in range(m - 1):
            number_of_steps = get_number_of_steps(p)
            current = random_walk(graph, current, number_of_steps)
            marked.append(current)
        
        # Add new node to graph
        graph.append(set())
        
        # Connect new node to all marked nodes
        for val in marked:
            graph[n_nodes].add(val)
            graph[val].add(n_nodes)
        
        # Create friendships between marked nodes with probability fp
        for i in range(len(marked)):
            for j in range(i + 1, len(marked)):
                if marked[i] != marked[j] and event_occurs(fp):
                    graph[marked[i]].add(marked[j])
                    graph[marked[j]].add(marked[i])
        
        n_nodes += 1
    
    return graph