"""
Utilities for finding network generation parameters (m, p, fp) that produce
a network with a desired number of edges and clustering coefficient.
"""

from .core import generate_network

def graph_to_igraph(graph):
    """
    Convert an adjacency-list graph (list of sets) to an igraph.Graph.

    Args:
        graph (list[set]): Adjacency list produced by generate_network.

    Returns:
        igraph.Graph: An undirected igraph graph.
    """
    import igraph as ig

    n = len(graph)
    edges = []
    for u, neighbors in enumerate(graph):
        for v in neighbors:
            if u < v:
                edges.append((u, v))
    g = ig.Graph(n=n, edges=edges, directed=False)
    return g


def calculate_clustering(N, m, p, fp):
    """
    Estimate the average local clustering coefficient for the given parameters.

    Generates a test network (capped at 5 000 nodes for speed) and measures
    its average local clustering coefficient using igraph.

    Args:
        N (int): Number of nodes in the target network (capped internally to 5 000).
        m (int): Number of marked nodes per new node.
        p (float): Step-length probability (0.0–1.0).
        fp (float): Friendship probability (0.0–1.0).

    Returns:
        float: Average local clustering coefficient of the test network.
    """
    test_network = generate_network(min(N, 5000), m, p, fp)
    ig_graph = graph_to_igraph(test_network)
    return ig_graph.transitivity_avglocal_undirected(mode="zero")


def calculate_n_edges(N, m, fp):
    """
    Compute the expected number of edges for the given parameters.

    Each of the *N* new nodes contributes *m* direct edges plus up to
    m*(m-1)/2 "friendship" edges, each created with probability *fp*.

    Args:
        N (int): Number of nodes added to the initial ring.
        m (int): Number of marked nodes per new node.
        fp (float): Friendship probability (0.0–1.0).

    Returns:
        float: Expected total number of edges in the generated network.
    """
    return N * (m + m * (m-1) * fp / 2)


def binary_search_clustering(N, m, fp, target_clustering, tol=0.005, max_iter=50):
    """
    Find the step-length probability *p* that yields a target clustering coefficient.

    Uses binary search over *p* ∈ [0.01, 1.0], exploiting the fact that
    the clustering coefficient increases monotonically with *p*.

    Args:
        N (int): Number of nodes.
        m (int): Number of marked nodes per new node.
        fp (float): Friendship probability (already determined).
        target_clustering (float): Desired average local clustering coefficient.
        tol (float, optional): Convergence tolerance for *p*. Defaults to 0.005.
        max_iter (int, optional): Maximum number of binary-search iterations.
            Defaults to 50.

    Returns:
        float: The value of *p* that approximately produces *target_clustering*.
    """
    left_p = 0.01
    right_p = 1.0
    for _ in range(max_iter):
        mid_p = (left_p + right_p) / 2
        if right_p - left_p < tol:
            return mid_p

        mid_val = calculate_clustering(N, m, mid_p, fp)
        if mid_val < target_clustering:
            left_p = mid_p
        else:
            right_p = mid_p
    return (left_p + right_p) / 2


def binary_search_edge_number(N, m, target_n_edges, tol=1e-6, max_iter=100):
    """
    Find the friendship probability *fp* that yields a target number of edges.

    Uses binary search over *fp* ∈ [0.0, 1.0], exploiting the fact that
    the expected edge count increases monotonically with *fp*.

    Args:
        N (int): Number of nodes.
        m (int): Number of marked nodes per new node.
        target_n_edges (float): Desired number of edges.
        tol (float, optional): Convergence tolerance for *fp*. Defaults to 1e-6.
        max_iter (int, optional): Maximum number of binary-search iterations.
            Defaults to 100.

    Returns:
        float: The value of *fp* that approximately produces *target_n_edges*.
    """
    left_fp = 0.0
    right_fp = 1.0
    for _ in range(max_iter):
        mid_fp = (left_fp + right_fp) / 2
        if right_fp - left_fp < tol:
            return mid_fp

        if calculate_n_edges(N, m, mid_fp) < target_n_edges:
            left_fp = mid_fp
        else:
            right_fp = mid_fp
    return (left_fp + right_fp) / 2


def find_coefficients(N, target_n_edges, target_clustering):
    """
    Determine generation parameters (m, fp, p) that produce a network with
    the desired number of edges and clustering coefficient.

    The search proceeds as follows:
      1. Starting from m = 2, find the smallest *m* for which *target_n_edges*
         is achievable by varying *fp* ∈ [0, 1].
      2. Binary-search for the *fp* that matches *target_n_edges*.
      3. If the achievable clustering range for the current (m, fp) does not
         contain *target_clustering*, increment *m* and repeat.
      4. Binary-search for the *p* that matches *target_clustering*.
      5. Generate a full network with the discovered parameters and measure the
         actual clustering coefficient for validation.

    Args:
        N (int): Number of nodes to add to the initial ring.
        target_n_edges (int | float): Desired number of edges.  Must be ≥ 2·N.
        target_clustering (float): Desired average local clustering coefficient.

    Returns:
        tuple[int, float, float, float] | None:
            A tuple ``(m, fp, p, actual_clustering)`` on success, where
            *actual_clustering* is measured on a network generated with the
            discovered parameters.  Returns ``None`` if no suitable parameters
            could be found (e.g. *m* exceeds 10 or the target is outside the
            achievable range).

    Raises:
        ValueError: If *target_n_edges* < 2·N.

    Example:
        >>> result = find_coefficients(N=1000, target_n_edges=5000, target_clustering=0.3)
        >>> if result is not None:
        ...     m, fp, p, actual_clustering = result
        ...     print(f"m={m}, fp={fp:.4f}, p={p:.4f}, clustering={actual_clustering:.4f}")
    """

    if target_n_edges < 2*N:
        raise ValueError(f"Number of edges ({target_n_edges}) must be at least 2N ({2*N}).")

    m = 2

    while True:

        if target_n_edges < calculate_n_edges(N, m, 0):
            return None

        if calculate_n_edges(N, m, 0) <= target_n_edges <= calculate_n_edges(N, m, 1.0):
            break

        m += 1

    result_fp = binary_search_edge_number(N, m, target_n_edges)

    # we have the first estimate for m and fp
    # clustering increases with p, so: clustering(p=0.1) <= target <= clustering(p=1.0)
    while not (calculate_clustering(N, m, 0.1, result_fp) <= target_clustering <= calculate_clustering(N, m, 1.0, result_fp)):

        m += 1

        if m > 10:
            return None

        if not (calculate_n_edges(N, m, 0) <= target_n_edges <= calculate_n_edges(N, m, 1.0)):
            return None

        result_fp = binary_search_edge_number(N, m, target_n_edges)


    result_p = binary_search_clustering(N, m, result_fp, target_clustering)

    # test in a real network generated by the algorithm
    network = generate_network(N, m, result_p, result_fp)
    ig_graph = graph_to_igraph(network)
    actual_clustering = ig_graph.transitivity_avglocal_undirected(mode="zero")

    return m, result_fp, result_p, actual_clustering