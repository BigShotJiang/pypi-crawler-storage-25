# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2020-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import os

import utilo

import baw.config
import baw.utils


def path_tested(root: str) -> str:
    tmpdir = baw.config.project_tmpdir(root)
    return os.path.join(tmpdir, 'tested')


def is_tested(root: str, hashed: str) -> bool:
    assert hashed.strip(), 'require hashed value'
    archive = path_tested(root)
    if not os.path.exists(archive):
        return False
    content = utilo.file_read(archive)
    lines = content.splitlines()
    if any(line.strip() == hashed for line in lines):
        return True
    return False


def mark_tested(root: str, hashed: str) -> bool:
    assert hashed.strip(), 'require hashed value'
    if is_tested(root, hashed):
        return True
    archive = path_tested(root)
    # add newline to separate hash values in file
    hashed = f'{hashed}\n'
    if os.path.exists(archive):
        baw.utils.file_append(archive, hashed)
    else:
        utilo.file_create(archive, hashed)
    return True
