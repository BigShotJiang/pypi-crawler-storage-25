#==============================================================================
# C O P Y R I G H T
#------------------------------------------------------------------------------
# Copyright (c) 2019-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
#==============================================================================

import contextlib
import importlib.metadata
import os
import re
import sys
import urllib.request

import packaging.requirements
import utilo
from pip import __version__ as pip_version

import baw.cmd.utils
import baw.config
import baw.gix
import baw.project.version
import baw.requirements
import baw.requirements.parser
import baw.requirements.upgrade
import baw.run
import baw.runtime
import baw.utils


def sync(
    root: str,
    packages: str = 'dev',
    *,
    minimal: bool = False,
    verbose: int = 0,
) -> int:
    """Sync packages which are defined in requirements.txt

    Args:
        root(str): root path of project to sync
        packages(str): decide which packages should be synchronized:
                        - dev/ minimal dev environment, formater, linter, test
                        - doc/ Sphinx
                        - extra
                        - all
        minimal(bool): if True use minimal version in requirement file
        verbose(bool): if True, increase verbosity of logging
    Returns:
        summed exit code of sync processes
    """
    baw.utils.check_root(root)
    ret = 0
    baw.log()
    ret += baw.gix.update_gitignore(root, verbose=verbose)
    # NOTE: Should we use Enum?
    ret += sync_dependencies(
        root,
        packages=packages,
        minimal=minimal,
        verbose=verbose,
    )
    return ret


def check_dependency(
    root: str,
    package: str,
    *,
    pre: bool = False,
    verbose: int = 0,
):
    """Check if packages need an upgrade."""
    python = baw.config.python(root)
    lookup = sources(pre)
    lookup = (None,) if lookup == (None, None) else lookup
    for index in lookup:
        if index:
            if not str(index).startswith('http'):
                index = f'http://{index}'
            index = f'--index {index}'
        else:
            index = ''
        pip = f'{python} -mpip index versions {index} {package}'
        completed = baw.runtime.run_target(
            root,
            pip,
            verbose=verbose,
            skip_error_code=[23, 2],  # package not found
        )
        if completed.returncode == 23:
            # Package not available
            continue
        if completed.returncode == 2:
            baw.error(f'not reachable: {index} for package {package}')
            baw.error(completed.stderr)
            sys.exit(completed.returncode)
        if completed.returncode and completed.stderr:
            baw.error(completed.stderr)
        if completed.stdout:
            if not completed.stdout.startswith(package):
                # nltk (3.5)  - 3.5
                # INSTALLED: 3.5 (latest)
                # skip finding nltk_data when searching for nltk
                continue
            return completed.stdout
    raise ValueError(f'Could not check dependencies {package}')


def sources(pre: bool = False) -> tuple:
    if pre:
        return (baw.config.package_testing(),)
    pip_index, extra_url = baw.config.package_address()
    # if not connected(pip_index, extra_url):
    #     msg = f"Could not reach index {pip_index} or {extra_url}"
    #     raise RuntimeError(msg)
    return (pip_index, extra_url)


def sync_dependencies(  # pylint:disable=R1260
    root: str,
    packages: str,
    *,
    minimal: bool = False,
    verbose: int = 0,
) -> int:
    baw.utils.check_root(root)
    baw.log('sync')
    resources = determine_resources(root, packages)
    pip_index, extra_url = baw.config.package_address()
    if not connected(pip_index, extra_url):
        baw.error('could not reach package index')
        return baw.FAILURE
    required = required_installation(
        root,
        resources,
        minimal=minimal,
        verbose=verbose,
    )
    if not required.equal and not required.greater:
        return baw.SUCCESS
    baw.log(f'\nrequire update:\n{required}')
    # create temporary requirements file
    requirements = baw.utils.tmpfile()
    baw.utils.file_replace(requirements, str(required))
    cmd, pip = get_install_cmd(
        root=root,
        requirements=requirements,
        verbose=verbose,
    )
    if verbose:
        baw.log(cmd)
    completed = baw.runtime.run_target(
        root,
        cmd,
        cwd=root,
        verbose=False,
    )
    baw.utils.file_remove(requirements)
    returncode = eval_sync(pip, completed, verbose=verbose)
    return returncode


def eval_sync(pip, completed, *, verbose: int) -> int:
    if 'NewConnectionError' in completed.stdout:
        baw.error(f'Could not reach server: {pip}')
        return completed.returncode
    if completed.stdout:
        for message in completed.stdout.splitlines():
            if should_skip(message, verbose=verbose):
                continue
            if verbose:
                baw.log(message)
    if completed.returncode and completed.stderr:
        baw.error(completed.stderr)
    baw.log()
    return completed.returncode


def required_installation(
    root,
    requirements: str,
    minimal: bool = False,
    verbose: int = 0,
):
    # TODO: REFACTOR LATER
    requested = [baw.requirements.parser.parse(requirements)]
    current = pip_list(root, verbose=verbose)
    missing = [
        baw.requirements.upgrade.diff(current, item, minimal)
        for item in requested
    ]
    result = baw.requirements.Requirements()
    for item in missing:
        result.equal.update(item.equal)  # pylint:disable=E1101
        if minimal:
            result.equal.update(item.greater)  # pylint:disable=E1101
        else:
            result.greater.update(item.greater)  # pylint:disable=E1101
    # TODO: REMOVE DUPLICATED
    for key in result.greater:
        with contextlib.suppress(KeyError):
            # remove duplicated requirement out of `equal requirement`
            result.equal.pop(key)
            continue
        baw.log(f'duplicated requirement: {key}')
    return result


def pyproject_packages(root: str) -> dict:
    """Determine requirements out of pytoml-file.

    >>> pyproject_packages(baw.determine_root(__file__))
    {'requirements':...'], 'dev': ['...'], 'doc': ['...]}

    toml does not exists
    >>> pyproject_packages(__file__)
    {}

    >>> pyproject_packages(None)
    {'requirements': [], 'dev': [], 'doc': []}
    """
    if not root:
        baw.error(f'pyproject_packages: root is {root}')
        return {'requirements': [], 'dev': [], 'doc': []}
    base = os.path.join(root, 'pyproject.toml')
    if not os.path.exists(base):
        return {}
    config = baw.project.version.load_toml(base)
    project = config['project']
    result = {
        'requirements': project.get('dependencies', []),
        'dev': project.get('optional-dependencies', {}).get('dev', []),
        'doc': project.get('optional-dependencies', {}).get('doc', []),
    }
    return result


def pyproject_packages_meta() -> dict:
    result = {'requirements': [], 'dev': [], 'doc': []}

    dist = importlib.metadata.distribution("baw")
    parsed = [
        packaging.requirements.Requirement(r) for r in dist.requires or []
    ]

    for item in parsed:
        line = f'{item.name} {item.specifier}'
        if item.marker:
            marker = str(item.marker).split(' ')[2]
            marker = marker.replace('"', '')
        else:
            marker = 'requirements'
        result[marker].append(line)
    return result


def determine_resources(root: str, packages: str) -> str:
    """Determine requirements depending on `packages` choice.

    Args:
        root(str): root of generated project
        packages(str): select package to install
    Returns:
        A single requirement file as a string.

    Choices(packages):
        - all: install project, test and doc environment
        - dev: install pytest, pycov etc.
        - doc: install Sphinx requirements
        - requirements: only install project pytoml.dependencies
    """
    baw_packages = pyproject_packages_meta()
    project_packages = pyproject_packages(baw.determine_root(root))
    if not baw_packages:
        baw.error(f'no baw_packages {baw_packages}')
    collected = []
    if packages == 'dev':
        collected.extend(baw_packages.get('dev', []))
    if packages == 'doc':
        collected.extend(baw_packages.get('doc', []))
    if packages == 'all':
        collected.extend(baw_packages.get('doc', []))
        collected.extend(baw_packages.get('dev', []))
    # Requirements_dev is a `global` file from baw project. This file is not
    # given in child project, it is referenced from global baw. Pay attention
    # to the difference of ROOT (baw) and root(project).
    # make path absolute in project
    if packages in {'dev', 'all'}:
        collected.extend(project_packages.get('dev', []))
    if packages in {'extra', 'all'}:
        collected.extend(project_packages.get('extra', []))
    # local project file
    collected.extend(project_packages.get('requirements', []))
    result = baw.NEWLINE.join(collected)
    return result


def get_install_cmd(
    root: str,
    requirements: str,
    *,
    verbose: int = 0,
    timeout: int = 30,
):
    pip_index, extra_url = baw.config.package_address()
    trusted = host(pip_index)
    pip = ''
    if pip_index:
        pip = f'--index-url {pip_index}'
    if extra_url:
        pip = f'{pip} --extra-index-url {extra_url}'
    testing_url = baw.config.package_testing()
    if '.post' not in utilo.file_read(requirements):
        testing_url = None
    if testing_url:
        pip += f'--extra-index-url {testing_url} '
    if trusted:
        pip += f'--trusted {trusted}'
    config = '--retries 2 --disable-pip-version-check '
    if require_legacy_solver():
        config += '--use-deprecated=legacy-resolver '
    python = baw.config.python(root)
    warning = '' if verbose else '--no-warn-conflicts'
    # prepare cmd
    cmd = f'{python} -mpip install {warning} {pip} '
    cmd += f'-U {config} '
    cmd += f'-r {requirements} '
    cmd += f'--timeout {timeout} '
    return cmd, pip


def require_legacy_solver() -> bool:
    """Older pip version does ot require or support this option."""
    major = baw.project.version.major(pip_version)
    if major < 21:
        return False
    if major == 22:
        # TODO: INVESTIGATE LATER
        return False
    return True


HOST = re.compile(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')


def host(url: str) -> str:
    """\
    >>> host('http://169.254.149.20:6103')
    '169.254.149.20'
    """
    if not url:
        return None
    if searched := HOST.search(url):
        return searched[0]
    return None


def pip_list(
    root,
    verbose: int = 0,
) -> baw.requirements.Requirements:
    python = baw.config.python(root)
    cmd = f'{python} -mpip list --format=freeze'
    if verbose:
        baw.log(cmd)
    completed = baw.runtime.run_target(
        root,
        cmd,
        cwd=root,
        verbose=False,
    )
    if completed.returncode and completed.stderr:
        baw.error(f'{cmd}, {verbose}')
        baw.error(completed.stderr)
        sys.exit(completed.returncode)
    content = completed.stdout
    parsed = baw.requirements.parser.parse(content)
    return parsed


def connected(internal: str, external: str) -> bool:
    """Test connect to internal and external server. Send a simple http-request
    and check the resonse.

    Args:
        internal(str): adress of internal pip server
        external(str): adress of external pip server
    Returns:
        True if boths connection are green, if not False
    Hint:
        Log the failure of a connection process also
    """
    result = True
    for item in (internal, external):
        if not item:
            baw.debug(f'Empty pip address: {item}')
            continue
        try:
            with urllib.request.urlopen(item) as response:  # nosec
                response.read()
        except urllib.request.URLError:
            result = False
            baw.error(f'Could not reach: {item}')
    return result


def should_skip(msg: str, verbose: int = 0):
    if not verbose and 'Requirement already' in msg:
        baw.log('.', end='')
        return True
    return False


def run(args: dict):
    root = baw.cmd.utils.run_environment(args)
    result = sync(
        root=root,
        packages=args.get('packages'),
        minimal=args.get('minimal', False),
        verbose=args.get('verbose', 0),
    )
    return result


def extend_cli(parser):
    synx = parser.add_parser('sync', help='Synchronize project requirements')
    synx.add_argument(
        '--minimal',
        help='use minimal required requirements',
        action='store_true',
    )
    synx.add_argument(
        'packages',
        help='Sync dependencies. Choices: dev(minimal), doc(sphinx), '
        'packages(requirements.txt only), all(dev, doc, packages)',
        nargs='?',
        const='dev',
        choices=['all', 'dev', 'doc', 'extra', 'requirements'],
    )
    synx.set_defaults(func=run)
