"""superharness — multi-agent session handoff framework."""

__version__ = "1.45.1"
