#!/usr/bin/env python3
"""Comprehensive box writeup analysis"""
import os, re, statistics
from pathlib import Path
from collections import defaultdict, Counter

BOXES_DIR = Path.home() / "writeups" / "boxes"

TECHNIQUES = {
    "AD": ["Kerberoasting", "AS-REP", "DCSync", "Pass-the-Hash", "Pass-the-Ticket", "Silver Ticket",
           "Golden Ticket", "ADCS", "ESC1", "ESC2", "ESC3", "ESC4", "ESC5", "ESC6", "ESC7", "ESC8",
           "ESC9", "ESC10", "Shadow Credentials", "Constrained Delegation", "Unconstrained Delegation",
           "RBCD", "GenericWrite", "WriteDacl", "WriteOwner", "AddMember", "ForceChangePassword",
           "BloodHound", "DACL", "ACL", "GPO", "LAPS", "gMSA", "DPAPI", "Certipy", "NTLM relay",
           "PetitPotam", "Coercion"],
    "Web": ["CVE", "exploit", "vulnerability", "LFI", "RFI", "SSRF", "SQLi", "SQL injection", "XSS",
            "SSTI", "RCE", "deserialization", "upload", "IDOR", "JWT", "cookie", "XXE", "CRLF",
            "Prototype Pollution", "Command Injection", "Path Traversal", "GraphQL", "OAuth", "CORS"],
    "Linux privesc": ["SUID", "sudo", "cron", "capabilities", "docker", "container escape",
                      "kernel exploit", "path hijack", "LD_PRELOAD", "NFS", "wildcard", "polkit"],
    "Windows privesc": ["token", "impersonation", "SeImpersonate", "JuicyPotato", "PrintSpoofer",
                        "GodPotato", "service", "AlwaysInstallElevated", "DLL hijack", "UAC bypass"],
    "Pivoting": ["chisel", "ligolo", "sshuttle", "proxychains", "tunnel", "port forward", "pivot"],
    "Credentials": ["hashcat", "john", "hydra", "credential", "password spray", "brute force",
                    "NTLM", "Kerberos", "relay"]
}

TOOL_NAMES = ["nmap", "rustscan", "ffuf", "feroxbuster", "gobuster", "dirsearch", "nikto", "wpscan",
              "sqlmap", "burp", "nuclei", "httpx", "curl", "wget", "bloodhound", "certipy", "rubeus",
              "mimikatz", "impacket", "secretsdump", "smbclient", "smbmap", "crackmapexec", "netexec",
              "nxc", "evil-winrm", "psexec", "wmiexec", "chisel", "ligolo", "proxychains", "hashcat",
              "john", "hydra", "linpeas", "winpeas", "pspy", "seatbelt", "ghidra", "ida", "gdb",
              "frida", "metasploit", "msfvenom", "responder", "ntlmrelayx"]

def analyze_file(filepath):
    content = filepath.read_text(encoding='utf-8', errors='ignore')
    lines = content.split('\n')
    total = len(lines)

    # Headers
    headers = Counter()
    sections = []
    for line in lines:
        m = re.match(r'^(#{1,4})\s+(.+)$', line)
        if m:
            headers[len(m.group(1))] += 1
            sections.append(m.group(2).strip().lower())

    # Code blocks & prose
    in_code = False
    code_lines = 0
    code_blocks = 0
    code_langs = Counter()
    for line in lines:
        if line.strip().startswith('```'):
            if not in_code:
                code_blocks += 1
                lang = re.match(r'^```(\w+)', line.strip())
                code_langs[lang.group(1) if lang else 'plain'] += 1
            in_code = not in_code
        elif in_code:
            code_lines += 1

    prose_lines = total - code_lines
    prose_ratio = prose_lines / total if total > 0 else 0

    # Images
    images = len(re.findall(r'!\[\[.*?\]\]', content))

    # Tags
    tags = re.findall(r'#(\w+)', '\n'.join(lines[:10]))
    tags = [t.lower() for t in tags]

    # Tables (credential tables)
    tables = sum(1 for line in lines if '|' in line and not line.strip().startswith('```'))

    # Technique keywords in full content
    content_lower = content.lower()
    tech_hits = {}
    for cat, keywords in TECHNIQUES.items():
        hits = 0
        for kw in keywords:
            hits += len(re.findall(r'\b' + re.escape(kw.lower()) + r'\b', content_lower))
        if hits > 0:
            tech_hits[cat] = hits

    # Tool mentions in prose (outside code blocks)
    prose_content = re.sub(r'```.*?```', '', content, flags=re.DOTALL).lower()
    tool_hits = Counter()
    for tool in TOOL_NAMES:
        count = len(re.findall(r'\b' + re.escape(tool.lower()) + r'\b', prose_content))
        if count > 0:
            tool_hits[tool] = count

    # Word count
    words = len(re.sub(r'```.*?```', '', content, flags=re.DOTALL).split())

    return {
        'name': filepath.name, 'total': total, 'prose_lines': prose_lines,
        'code_lines': code_lines, 'prose_ratio': prose_ratio, 'headers': headers,
        'sections': sections, 'code_blocks': code_blocks, 'code_langs': code_langs,
        'images': images, 'tags': tags, 'tables': tables, 'tech_hits': tech_hits,
        'tool_hits': tool_hits, 'words': words
    }

def main():
    files = list(BOXES_DIR.glob("*.md"))
    print(f"Analyzing {len(files)} box writeups...\n")
    results = [analyze_file(f) for f in sorted(files)]

    print("=" * 80)
    print("BOX WRITEUP ANALYSIS")
    print("=" * 80)

    # 1. Structure
    print("\n--- STRUCTURE ---")
    totals = sum(r['total'] for r in results)
    print(f"Total lines: {totals:,}")
    print(f"Avg lines/writeup: {totals/len(results):.1f}")
    print(f"Min: {min(r['total'] for r in results)}, Max: {max(r['total'] for r in results)}")
    print(f"Median: {statistics.median(r['total'] for r in results):.0f}")

    print(f"\nHeaders: H1={sum(r['headers'][1] for r in results)}, H2={sum(r['headers'][2] for r in results)}, "
          f"H3={sum(r['headers'][3] for r in results)}, H4={sum(r['headers'][4] for r in results)}")

    all_sections = Counter()
    for r in results:
        all_sections.update(r['sections'])
    print("\nTop 20 section names:")
    for name, count in all_sections.most_common(20):
        print(f"  {count:3d}x {name}")

    print(f"\nTotal code blocks: {sum(r['code_blocks'] for r in results)}")
    print(f"Avg code blocks/writeup: {sum(r['code_blocks'] for r in results)/len(results):.1f}")
    print(f"Total images: {sum(r['images'] for r in results)}")
    print(f"Avg images/writeup: {sum(r['images'] for r in results)/len(results):.1f}")
    print(f"Writeups with images: {sum(1 for r in results if r['images'] > 0)}")
    print(f"Total table lines: {sum(r['tables'] for r in results)}")

    # 2. Prose ratio
    print("\n--- PROSE RATIO ---")
    avg_pr = statistics.mean(r['prose_ratio'] for r in results)
    print(f"Average prose ratio: {avg_pr*100:.1f}%")
    print(f"Median prose ratio: {statistics.median(r['prose_ratio'] for r in results)*100:.1f}%")
    bins = [(0, 0.2, "<20%"), (0.2, 0.4, "20-40%"), (0.4, 0.6, "40-60%"), (0.6, 1.01, ">60%")]
    for lo, hi, label in bins:
        n = sum(1 for r in results if lo <= r['prose_ratio'] < hi)
        print(f"  {label}: {n} ({n/len(results)*100:.1f}%)")

    # 3. Tags
    print("\n--- TAGS ---")
    all_tags = Counter()
    tagged = 0
    for r in results:
        if r['tags']:
            tagged += 1
            all_tags.update(r['tags'])
    print(f"Writeups with tags: {tagged}/{len(results)} ({tagged/len(results)*100:.1f}%)")
    print(f"Unique tags: {len(all_tags)}")
    print("\nTop 30 tags:")
    for tag, count in all_tags.most_common(30):
        print(f"  {count:3d}x #{tag}")

    # 4. Technique mentions
    print("\n--- TECHNIQUE MENTIONS ---")
    for cat in TECHNIQUES:
        total_mentions = sum(r['tech_hits'].get(cat, 0) for r in results)
        writeups_with = sum(1 for r in results if cat in r['tech_hits'])
        print(f"  {cat:20s}: {total_mentions:5d} mentions across {writeups_with:3d} writeups")

    # 5. Tool mentions in prose
    print("\n--- TOOL MENTIONS IN PROSE ---")
    all_tools = Counter()
    for r in results:
        all_tools.update(r['tool_hits'])
    print("Top 30 tools mentioned in prose:")
    for tool, count in all_tools.most_common(30):
        print(f"  {tool:20s}: {count:4d}")

    # 6. Code languages
    print("\n--- CODE BLOCK LANGUAGES ---")
    all_langs = Counter()
    for r in results:
        all_langs.update(r['code_langs'])
    for lang, count in all_langs.most_common(15):
        print(f"  {lang:15s}: {count:4d} blocks")

    # 7. Word count
    total_words = sum(r['words'] for r in results)
    print(f"\n--- WORD COUNT ---")
    print(f"Total prose words: {total_words:,}")
    print(f"Avg words/writeup: {total_words/len(results):.0f}")

    # 8. Length distribution
    print("\n--- LENGTH DISTRIBUTION ---")
    for lo, hi, label in [(0,50,"<50"), (50,100,"50-100"), (100,200,"100-200"),
                           (200,400,"200-400"), (400,800,"400-800"), (800,9999,">800")]:
        n = sum(1 for r in results if lo <= r['total'] < hi)
        bar = "█" * (n // 3)
        print(f"  {label:>8s}: {n:3d} {bar}")

    # Longest
    by_len = sorted(results, key=lambda r: r['total'], reverse=True)
    print("\n5 longest:")
    for r in by_len[:5]:
        print(f"  {r['total']:5d} lines - {r['name']}")
    print("5 shortest:")
    for r in by_len[-5:]:
        print(f"  {r['total']:5d} lines - {r['name']}")

    print("\n" + "=" * 80)
    print("DONE")

if __name__ == "__main__":
    main()
