# Command Vault MCP - RAG Improvements Analysis

## Full Corpus Statistics (526 Writeups)

### Corpus Overview

| Type | Count | Avg Lines | Avg Words | Avg Prose% | Avg Code Blocks |
|---|---|---|---|---|---|
| **Boxes** | 208 | 653 | 603 | 29.1% | 26.7 |
| **Challenges** | 245 | 397 | 550 | 33.6% | 10.5 |
| **Sherlocks** | 73 | 403 | 639 | 55.6% | 12.2 |
| **TOTAL** | **526** | **~500** | **~583** | **29.4% overall** | — |

**Total prose: 306,694 words (~1,227 pages) across 77,214 lines — this is what a RAG system would index.**

### Length Distribution

```
    <50 lines:   13 writeups (mostly OSINT challenges)
  50-100 lines:  19
 100-200 lines:  76
 200-400 lines: 152  ← mode
 400-800 lines: 191  ← most boxes live here
    >800 lines:  75  (complex AD boxes, hard pwn challenges)
```

Longest: Kryptor (pwn) 3,485 lines, Hercules (box) 2,491 lines
Shortest: Letter Dispair (web) 5 lines, Ruse (sherlock) 9 lines

### Tag Coverage

- 211/526 writeups have tags (boxes: 98.6%, challenges/sherlocks: mostly untagged)
- 656 unique tags
- Top tags: `#linux`(143), `#cve`(99), `#windows`(60), `#php`(22), `#lfi`(19), `#sqli`(18), `#xss`(15)
- Top co-occurrences: `#cve+#linux`(57), `#linux+#php`(20), `#lfi+#linux`(18), `#kerberos+#windows`(11)

### Technique Coverage Across All Writeups

**AD/Windows** (detected in 57 box writeups):
- BloodHound: 41 | GPO abuse: 44 | Pass-the-Hash: 39 | DPAPI: 22
- ADCS: 16 | AS-REP roasting: 16 | DCSync: 13 | Kerberoasting: 10
- RBCD: 7 | Shadow Credentials: 5 | GenericWrite: 5 | NTLM relay: 5

**Web** (detected across boxes + challenges):
- SQLi: 112 | LFI/RFI: 51 | XSS: 50 | Command Injection: 33
- JWT: 29 | SSRF: 28 | Deserialization: 23 | SSTI: 17 | File Upload: 15

**Linux privesc:**
- sudo: 175 | cron: 44 | capabilities: 42 | SUID: 26
- wildcard: 10 | LD_PRELOAD: 8 | NFS: 8 | kernel exploit: 7

**Forensics/DFIR** (primarily sherlocks):
- Browser forensics: 163 | Network forensics: 114 | Disk forensics: 63
- Registry forensics: 48 | Malware analysis: 46 | Log analysis: 25 | Memory forensics: 15

### Tool Usage (Top 25 by writeup count)

| Tool | Writeups | Mentions | Tool | Writeups | Mentions |
|---|---|---|---|---|---|
| nmap | 206 | 1,030 | linpeas | 36 | 70 |
| curl | 152 | 468 | msfvenom | 33 | 55 |
| wget | 125 | 196 | tcpdump | 30 | 44 |
| strings | 124 | 209 | wireshark | 27 | 50 |
| john | 96 | 391 | pspy | 27 | 37 |
| ffuf | 94 | 155 | hashcat | 26 | 75 |
| docker | 87 | 405 | nxc | 26 | 95 |
| burp | 61 | 100 | secretsdump | 24 | 31 |
| impacket | 51 | 347 | pwndbg | 21 | 180 |
| ida | 47 | 77 | sqlmap | 19 | 101 |
| evil-winrm | 46 | 520 | certipy | 17 | 182 |
| chisel | 42 | 141 | mimikatz | 17 | 99 |
| bloodhound | 41 | 134 | — | — | — |

### Challenge Categories

| Category | Count | Avg Lines | Prose% | Top Languages |
|---|---|---|---|---|
| web | 46 | 363 | 34.9% | bash, http, js |
| pwn | 42 | 598 | 25.2% | bash, c, python |
| crypto | 35 | 305 | 31.9% | python, bash |
| reversing | 26 | 398 | 34.6% | bash, c, python |
| mobile | 13 | 505 | 31.7% | bash, java, http |
| forensics | 12 | 317 | 30.3% | bash, python |
| gamepwn | 8 | 533 | 36.2% | bash, c |
| blockchain | 8 | 282 | 31.5% | bash, solidity, js |
| secure coding | 6 | 928 | 18.0% | js, php |
| osint | 6 | 31 | 100% | (no code) |

Exploit scripts: 26.5% use pwntools, 9.8% use requests, 2.4% use Frida
73.9% of challenges contain Python code (23,585 total lines)

### Sherlock Forensics Breakdown

| Difficulty | Count | Avg Lines | Avg Tasks | Avg Images | Prose% |
|---|---|---|---|---|---|
| Very Easy | 3 | 141 | 6.3 | 0.0 | 88.9% |
| Easy | 30 | 319 | 11.3 | 2.6 | 56.5% |
| Medium | 23 | 474 | 13.0 | 2.5 | 53.7% |
| Hard | 12 | 541 | 14.1 | 4.8 | 48.5% |
| Insane | 3 | 481 | 13.0 | 5.0 | 47.7% |

876 total forensic questions extracted. Question types:
- tool/technique: 19.4% | timestamp: 15.4% | user/account: 15.0%
- process: 8.7% | domain/URL: 8.3% | count: 7.9%
- file/path: 7.1% | IP address: 5.0% | hash/IOC: 3.4%

Artifact mentions: Windows artifacts (1,316), Credentials (279), Network (190), Memory (111), Malware tools (111), DFIR tools (94), Log analysis (91)

### Code Block Languages (All Types)

| Language | Box Blocks | Challenge Blocks | Primary Use |
|---|---|---|---|
| bash | 3,869 | 987 | Commands, enumeration |
| python | 167 | 493 | Exploit scripts, solvers |
| c | 50 | 331 | Source analysis, exploits |
| http | 334 | 134 | Request/response capture |
| powershell | 279 | — | Windows commands |
| js | 71 | 147 | Web exploits, Frida |
| php | 85 | 33 | Web app source |
| sql | 93 | — | Database queries |

### Box Writeup Section Structure

Most common sections (highly standardized):
- `enumeration` (207/208), `privesc` (125), `getting the foothold` (41)
- Port-specific: `80/tcp - http` (32), `shares` (15)
- Technique: `attack` (22), `exploitation` (10)

### Key Insights for RAG Design

1. **306K words of prose is very indexable** — comparable to a medium technical book. At 512-token chunks, that's ~2,400 chunks across the corpus.

2. **Boxes are the most structured** — consistent H2/H3 hierarchy makes section-based chunking straightforward. 98.6% have tags.

3. **Challenges vary wildly** — from 5-line OSINT notes to 3,485-line pwn deep-dives. Category from filename is the best organizer.

4. **Sherlocks have the richest prose** (55.6% avg) with natural Q&A structure — 876 forensic questions already exist as retrievable triples.

5. **Screenshot dependency scales with difficulty** — Easy sherlocks average 2.6 images, Hard average 4.8. This is a real gap for text-only RAG.

6. **Tool-in-prose vs tool-in-code diverges** — burp(76 prose mentions) vs evil-winrm(520 total but mostly in code). Prose mentions indicate methodology discussion, code mentions indicate usage. Both are valuable differently.

---

## How RAG Works vs What Command Vault Does Today

### Classic RAG Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     RAG Pipeline                            │
│                                                             │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐              │
│  │ Documents │───▶│ Chunking │───▶│ Embedding│──┐           │
│  │ (md files)│    │ & Parse  │    │ Model    │  │           │
│  └──────────┘    └──────────┘    └──────────┘  │           │
│                                                 ▼           │
│                                          ┌──────────┐       │
│                                          │ Vector DB│       │
│                                          │(chromadb)│       │
│                                          └────┬─────┘       │
│                                               │             │
│  ┌──────────┐    ┌──────────┐    ┌────────────┘             │
│  │   LLM    │◀───│ Augment  │◀───│ Semantic                │
│  │ Response │    │ Prompt   │    │ Search                   │
│  └──────────┘    └──────────┘    └──────────┘              │
│       ▲                                                     │
│       │          User asks: "How do I abuse                 │
│       └───────── ADCS misconfiguration?"                    │
└─────────────────────────────────────────────────────────────┘
```

**R**etrieval - find relevant chunks from your knowledge base
**A**ugmented - inject those chunks into the LLM prompt
**G**eneration - LLM answers using your private data as context

### What Command Vault Does Today (Not RAG — It's Keyword Search)

```
User query ──▶ FTS5 phrase match ──▶ Raw results returned
                 (exact tokens)        (no LLM augmentation)
```

It's a **structured command index** with full-text search. Powerful for exact lookups (`tool=certipy`), but:

| Limitation | Example |
|---|---|
| **Phrase search too strict** | `"certipy ESC"` returns 0 results because FTS5 treats it as a phrase — "certipy" must be immediately followed by "ESC" |
| **No semantic understanding** | Searching `"kerberoasting attack"` finds nothing because no command contains that exact phrase. You need to know to search `kerberoast` instead |
| **No prose/context search** | Your writeups contain paragraphs explaining *why* you did something — FTS only indexes command text, purpose (short), and context (300 chars) |
| **No cross-writeup reasoning** | Can't answer "What boxes had ADCS attacks?" without tags already being set |

---

## Concrete Improvements for Pentesting Workflows

### 1. Fix FTS to Use OR Instead of Phrase Match (quick win)

Currently `database.py` wraps queries as `'"certipy ESC"'` (phrase). Change to tokenized OR/AND:

```python
# Before: phrase match — must appear as exact phrase
query = f'"{q}"'

# After: each word matches independently
query = ' OR '.join(f'"{token}"' for token in q.split())
```

This alone would make `certipy ESC` find all certipy commands whose purpose mentions ESC.

### 2. Index Full Writeup Prose (medium effort)

Right now only **commands** and short purpose/context snippets are indexed. The richest content — analysis paragraphs, methodology notes, observations — is thrown away. Add a `writeup_chunks` table + FTS:

```sql
CREATE TABLE writeup_chunks (
    id INTEGER PRIMARY KEY,
    writeup_id INTEGER REFERENCES writeups(id),
    section TEXT,           -- H2/H3 heading
    content TEXT,           -- the actual paragraph/prose
    chunk_index INTEGER     -- position in document
);

CREATE VIRTUAL TABLE writeup_chunks_fts USING fts5(
    content, section,
    content='writeup_chunks', content_rowid='id'
);
```

This lets you search for concepts: *"ADCS misconfiguration ESC8"*, *"NTLM relay to LDAP"*, *"forensic timeline analysis"* — matching against actual analysis text.

### 3. Add Semantic/Vector Search (the real RAG upgrade)

FTS can't handle: *"How do I escalate privileges when I have GenericWrite on a user?"* — no exact keyword match will find this. You need **embeddings**:

```
Writeup chunks ──▶ Embedding model ──▶ Vector store
                   (local or API)       (sqlite-vec / chromadb)

User question ──▶ Same embedding ──▶ Cosine similarity search
                                      ──▶ Top-K chunks returned
```

Options for embedding:
- **Local** (free, private): `sentence-transformers/all-MiniLM-L6-v2` (80MB, runs on CPU)
- **API**: OpenAI `text-embedding-3-small` or Anthropic via Voyage

**sqlite-vec** keeps everything in one SQLite file — no extra infra.

### 4. Writeup-Level Methodology Summaries

For each writeup, pre-extract a structured summary:

```json
{
  "file": "Certified.md",
  "attack_path": ["BloodHound enum", "GenericWrite abuse", "Shadow Credentials", "ADCS ESC9", "DCSync"],
  "techniques": ["shadow-credentials", "adcs-esc9", "dcsync", "genericwrite-abuse"],
  "tools_chain": ["bloodhound-python", "certipy", "impacket-secretsdump"],
  "os": "windows",
  "difficulty_notes": "Key insight: ca_operator had enrollment rights on vulnerable template"
}
```

This could be generated by an LLM pass over each writeup at index time (one-time cost). Then when stuck on a box, the system can retrieve *methodology patterns*, not just individual commands.

### 5. Practical Integration with Pentest Workflows

Here's how the improved vault would plug into an HTB session:

```
┌─────────────────────────────────────────────────────────────┐
│  Pentest Session                                            │
│                                                             │
│  You: "I found GenericWrite on a user object,               │
│        DC has ADCS. What's the attack path?"                │
│                                                             │
│  Claude:                                                    │
│   1. Vector search vault → finds Certified.md,              │
│      Authority.md, Escape.md chunks about                   │
│      GenericWrite + ADCS                                    │
│   2. Retrieves specific command sequences                    │
│   3. Adapts commands to YOUR current target                  │
│                                                             │
│  "Based on your Certified writeup, the path is:             │
│   Shadow Credentials → get cert → ESC9.                     │
│   Here are the adapted commands for {TARGET}..."            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

For **Sherlocks** (DFIR), the value is different — retrieving forensic artifact locations, Volatility plugin sequences, and log analysis patterns from past investigations.

---

## Priority Roadmap

| Priority | Change | Effort | Impact |
|---|---|---|---|
| **P0** | Fix FTS to OR-tokenized search | 1 hour | Immediate — searches actually work |
| **P1** | Index full writeup prose as chunks | Half day | 10x more searchable content |
| **P2** | Add `writeup_chunks_fts` search tool | 2 hours | Methodology/concept search |
| **P3** | Add vector embeddings (sqlite-vec) | 1-2 days | True semantic search / RAG |
| **P4** | LLM-generated writeup summaries | 1 day | Attack path retrieval |

**P0 and P1-P2 would be the biggest bang for the buck** — the vault already has 623 writeups of rich prose that's currently invisible to search.

---

## Writeup Data Analysis (Sample of 9 Writeups)

### Boxes (209 writeups) — Sampled: Certified, Sea, Environment

**Structure pattern:** Highly consistent across all boxes:
- Tags as metadata line after title (`#Windows #DACL #Shadow_credential #ESC9`)
- Port-organized enumeration sections (`### 445/tcp - SMB`, `### 389/tcp - LDAP`)
- Credential tables as running artifacts
- Horizontal rule (`---`) as phase separator (enum → foothold → privesc)

**Prose-to-code ratio:** ~20-30% prose / 70-80% code+output. Sparse but high-signal prose.

**What prose contains that commands miss:**
- **Causal reasoning chains:** "judith.mader has WriteOwner on management group → she can add herself → group has GenericWrite on management_svc → shadow credential attack → NTLM hash"
- **Tool selection rationale:** "`certipy auto` is quicker than `pywhisker.py` + `gettgtpkinit.py` + `getnthash.py`"
- **OSINT deduction:** LICENSE file → copyright "velik71" → WonderCMS community post → CVE identification
- **Exploit shortcuts:** Reading exploit source to find deployed shell path, then calling it directly instead of running the full XSS chain
- **Technique prerequisites:** ESC9 requires `StrongCertificateBindingEnforcement` not set to 2 + `CT_FLAG_NO_SECURITY_EXTENSION` on template — this is in a blockquote, not in any command
- **Cross-finding connections:** nmap clock skew (7h) → need `faketime` for Kerberos auth
- **Failed approach documentation:** "Cannot simply intercept the POST — there's a blacklist" → discovered `;<command>;` bypass

**Key gap:** Obsidian image embeds (`![[filename.png]]`) carry info with no text equivalent — BloodHound graphs, web UI screenshots, Burp intercepts.

---

### Challenges (246 writeups) — Sampled: RenderQuest (web), vvm (reversing), Angler (mobile)

**Structure pattern:** Varies dramatically by complexity:
- Simple (web/mobile): Flat `Intro / Analysis` with linear flow to flag
- Complex (reversing): Deep nested subsections (`### Dynamic analysis → #### Dynamic code analysis → ##### vm code`)

**Prose-to-code ratio:** Inversely correlated with difficulty:
- Web: ~15% prose, mostly code/payloads
- Mobile: ~25% prose, Frida workflow narrated with intent
- Reversing: ~40% prose, textbook-quality deep dive with reasoning at every step

**What prose contains that commands miss:**
- **Algorithm reconstruction:** Complete mathematical model of a VM's check algorithm — 8 constraint equations, opcode table (28 opcodes), bit rotation parameters
- **Anti-debugging bypass reasoning:** `ptrace(PTRACE_TRACEME)` identified → patched `test rax,rax` to `xor rax,rax` at offset `0x13F7` — the *why* of each byte change is in prose
- **JNI conventions:** Explanation that `Java_com_example_angler_MainActivity_getInfo` follows JNI naming and takes 3 params (JNIEnv, jobject, actual param)
- **Debugger methodology:** Conditional breakpoints (`b *(addr) if $r9 == N`), vmmap for RWX region identification, telescope for stack analysis — taught as a methodology, not just commands
- **Two-stage approach reasoning:** Java-side Frida call first to confirm partial flag, then native `strcmp` hook — shows methodical narrowing, not just "run this script"

**Unique to challenges:** Category completely drives tool selection (web=source review+HTTP, reversing=IDA+pwndbg+Python, mobile=Jadx+adb+Frida). No "failed attempts" documented — clean linear paths only.

---

### Sherlocks (74 writeups) — Sampled: Lockpick (Easy), Detroit becomes Human (Hard), Latus (Hard)

**Structure pattern:** Distinct from boxes/challenges:
- Scenario block (incident narrative)
- Analysis (artifact enumeration)
- Task 1-N (explicit Q&A — question in italics, method, precise answer)

**Prose-to-code ratio:** ~35-45% prose / 55-65% code+output. Highest prose density of all types.

**What prose contains that commands miss:**
- **Multi-artifact correlation chains:** SAM hashes → password cracking → DPAPI MasterKey decryption → credential blob decryption. The *dependency* between steps is only in prose.
- **Artifact interpretation:** Chromium timestamp `13355296200136503` means nothing without knowing it's Windows FILETIME (microseconds since Jan 1, 1601). The Python conversion script is extracted, but the *why* is prose.
- **Forensic shortcuts:** `grep -aR` on raw binary SQLite works because URLs are stored as plaintext strings — bypasses needing sqlite3 queries.
- **Counter-forensics awareness:** FileSlack recovery — attacker deleted `Windows PowerShell.evtx` but `.FileSlack` survived in NTFS slack space. Renaming restores parseable EVTX.
- **Tool output interpretation:** Hayabusa's "Remote Schtasks Creation (2,968)" at medium severity implies attacker dwell time and multiple persistence mechanisms — the number alone doesn't convey this.
- **Tool comparison reasoning:** "MFTExplorer is more convenient than FTK Imager for hex offset lookup"
- **Ransomware reverse engineering:** 10-step walkthrough of `encrypt_file` pseudocode explaining XOR loop, file renaming, ransom note creation — the *algorithm* is prose, commands just show IDA output.
- **RDP bitmap cache analysis:** `bmc-tools.py` extracts screen tiles, but identifying `NetBScanner` in the reconstructed collage requires *visual interpretation* documented in prose.

**Unique to Sherlocks:**
- Q&A structure creates natural question-answer-evidence triples — ideal for RAG retrieval
- Difficulty strongly correlates with artifact chain depth (Easy=1 artifact type, Hard=5+ chained)
- ~30-40% of Hard sherlock answers come from screenshots — significant gap for text-only RAG
- External references cited (Magnet Forensics blog, DFIR Spot) — methodology provenance tracking

---

## Updated Recommendations Based on Data Analysis

### The core insight: **prose is where the knowledge lives**

Commands are the *what*. Prose is the *why*, *when to use it*, and *what to look for in the output*. Current command-vault indexes only the *what* — missing the most valuable content.

### Type-specific chunking strategy

| Writeup Type | Optimal Chunk Strategy |
|---|---|
| **Boxes** | Section-level chunks (H2/H3) — each section is a self-contained attack phase with prose + commands interleaved |
| **Challenges** | Whole-writeup or subsection chunks — structure varies too much, but shorter writeups can be single chunks |
| **Sherlocks** | Per-task chunks — each Task is a natural question→method→answer triple, perfect for retrieval |

### Screenshot handling (future)

For Hard sherlocks/boxes, consider:
- OCR on `![[image.png]]` references during indexing (if images are in the writeup directory)
- Or: flag chunks as `has_image_context=true` so the LLM knows to caveat its answer
