#!/usr/bin/env python3
"""Comprehensive challenge writeup analysis"""
import os, re, statistics
from pathlib import Path
from collections import defaultdict, Counter

DIR = Path.home() / "writeups" / "challenges"

TECHNIQUES = [
    "XSS", "SQLi", "SQL injection", "SSTI", "SSRF", "RCE", "LFI", "RFI", "deserialization",
    "prototype pollution", "JWT", "cookie", "session", "CORS", "CSP", "WAF bypass",
    "buffer overflow", "heap", "stack overflow", "ROP", "format string", "race condition",
    "use-after-free", "shellcode", "GOT overwrite", "ret2libc", "canary", "PIE", "ASLR", "NX",
    "reverse engineering", "decompile", "disassemble", "IDA", "Ghidra", "Frida", "debug",
    "breakpoint", "crypto", "RSA", "AES", "XOR", "padding oracle", "hash", "ECDSA",
    "elliptic curve", "CBC", "ECB", "GCM", "HMAC", "command injection", "path traversal",
    "XXE", "CRLF", "WebSocket", "GraphQL", "OAuth", "IDOR", "file upload", "SUID",
    "ptrace", "anti-debug", "packing", "obfuscation", "virtual machine", "sandbox escape"
]

def extract_category(name):
    m = re.search(r'\(([^)]+)\)\.md$', name)
    return m.group(1).strip().lower() if m else 'unknown'

def analyze_file(filepath):
    content = filepath.read_text(encoding='utf-8', errors='ignore')
    lines = content.split('\n')
    total = len(lines)
    category = extract_category(filepath.name)

    # Code blocks
    in_code = False
    code_lines = 0
    code_blocks = 0
    code_langs = Counter()
    for line in lines:
        if line.strip().startswith('```'):
            if not in_code:
                code_blocks += 1
                lang = re.match(r'^```(\w+)', line.strip())
                code_langs[lang.group(1) if lang else 'plain'] += 1
            in_code = not in_code
        elif in_code:
            code_lines += 1

    prose_lines = total - code_lines
    prose_ratio = prose_lines / total if total > 0 else 0
    images = len(re.findall(r'!\[\[.*?\]\]', content))

    # Sections
    sections = []
    for line in lines:
        m = re.match(r'^(#{1,4})\s+(.+)$', line)
        if m:
            sections.append(m.group(2).strip().lower())

    # Techniques
    content_lower = content.lower()
    tech_hits = Counter()
    for t in TECHNIQUES:
        count = len(re.findall(r'\b' + re.escape(t.lower()) + r'\b', content_lower))
        if count > 0:
            tech_hits[t] = count

    # Scripts
    has_pwn = bool(re.search(r'from pwn import', content))
    has_requests = bool(re.search(r'import requests', content))
    has_exploit = bool(re.search(r'def exploit\(', content))
    has_frida = bool(re.search(r'frida|Java\.perform|Interceptor\.attach', content, re.I))

    # Python lines
    py_lines = 0
    in_py = False
    for line in lines:
        if re.match(r'^```(?:python|py)\b', line.strip()):
            in_py = True
        elif line.strip() == '```' and in_py:
            in_py = False
        elif in_py:
            py_lines += 1

    words = len(re.sub(r'```.*?```', '', content, flags=re.DOTALL).split())

    return {
        'name': filepath.name, 'category': category, 'total': total,
        'prose_ratio': prose_ratio, 'code_blocks': code_blocks, 'code_langs': code_langs,
        'images': images, 'sections': sections, 'tech_hits': tech_hits,
        'has_pwn': has_pwn, 'has_requests': has_requests, 'has_exploit': has_exploit,
        'has_frida': has_frida, 'py_lines': py_lines, 'words': words,
        'prose_lines': prose_lines, 'code_lines': code_lines
    }

def main():
    files = list(DIR.glob("*.md"))
    print(f"Analyzing {len(files)} challenge writeups...\n")
    results = [analyze_file(f) for f in sorted(files)]

    print("=" * 80)
    print("CHALLENGE WRITEUP ANALYSIS")
    print("=" * 80)

    # Category breakdown
    cats = Counter(r['category'] for r in results)
    print("\n--- CATEGORIES ---")
    for cat, count in cats.most_common():
        avg_len = statistics.mean(r['total'] for r in results if r['category'] == cat)
        avg_cb = statistics.mean(r['code_blocks'] for r in results if r['category'] == cat)
        avg_pr = statistics.mean(r['prose_ratio'] for r in results if r['category'] == cat)
        print(f"  {cat:20s}: {count:3d} writeups | avg {avg_len:5.0f} lines | "
              f"avg {avg_cb:4.1f} code blocks | {avg_pr*100:4.1f}% prose")

    # Structure
    print("\n--- STRUCTURE ---")
    totals = sum(r['total'] for r in results)
    print(f"Total lines: {totals:,}, Avg: {totals/len(results):.1f}")
    print(f"Total code blocks: {sum(r['code_blocks'] for r in results)}")
    print(f"Total images: {sum(r['images'] for r in results)}")
    print(f"Avg images/writeup: {sum(r['images'] for r in results)/len(results):.1f}")

    # Prose ratio
    print("\n--- PROSE RATIO ---")
    avg_pr = statistics.mean(r['prose_ratio'] for r in results)
    print(f"Average: {avg_pr*100:.1f}%")
    for lo, hi, label in [(0,0.2,"<20%"), (0.2,0.4,"20-40%"), (0.4,0.6,"40-60%"), (0.6,1.01,">60%")]:
        n = sum(1 for r in results if lo <= r['prose_ratio'] < hi)
        print(f"  {label}: {n} ({n/len(results)*100:.1f}%)")

    print("\nProse ratio by category:")
    for cat, _ in cats.most_common():
        ratios = [r['prose_ratio'] for r in results if r['category'] == cat]
        if len(ratios) >= 3:
            print(f"  {cat:20s}: {statistics.mean(ratios)*100:5.1f}% (n={len(ratios)})")

    # Code languages
    print("\n--- CODE LANGUAGES ---")
    all_langs = Counter()
    for r in results:
        all_langs.update(r['code_langs'])
    for lang, count in all_langs.most_common(15):
        print(f"  {lang:15s}: {count:4d} blocks")

    print("\nTop languages by category:")
    for cat, _ in cats.most_common(10):
        cat_langs = Counter()
        for r in results:
            if r['category'] == cat:
                cat_langs.update(r['code_langs'])
        top3 = ", ".join(f"{l}({c})" for l, c in cat_langs.most_common(3))
        print(f"  {cat:20s}: {top3}")

    # Techniques
    print("\n--- TECHNIQUE MENTIONS ---")
    all_tech = Counter()
    for r in results:
        all_tech.update(r['tech_hits'])
    print("Top 30:")
    for tech, count in all_tech.most_common(30):
        files_with = sum(1 for r in results if tech in r['tech_hits'])
        print(f"  {tech:25s}: {count:4d} mentions in {files_with:3d} files")

    print("\nTechniques by category (top 5 per):")
    for cat, _ in cats.most_common(10):
        cat_tech = Counter()
        for r in results:
            if r['category'] == cat:
                cat_tech.update(r['tech_hits'])
        if cat_tech:
            print(f"\n  {cat.upper()}:")
            for tech, count in cat_tech.most_common(5):
                print(f"    {tech:20s}: {count:3d}")

    # Scripts
    print("\n--- EXPLOIT SCRIPTS ---")
    print(f"with pwntools: {sum(1 for r in results if r['has_pwn'])} ({sum(1 for r in results if r['has_pwn'])/len(results)*100:.1f}%)")
    print(f"with requests: {sum(1 for r in results if r['has_requests'])} ({sum(1 for r in results if r['has_requests'])/len(results)*100:.1f}%)")
    print(f"with def exploit(): {sum(1 for r in results if r['has_exploit'])} ({sum(1 for r in results if r['has_exploit'])/len(results)*100:.1f}%)")
    print(f"with Frida: {sum(1 for r in results if r['has_frida'])} ({sum(1 for r in results if r['has_frida'])/len(results)*100:.1f}%)")

    py_writeups = [r for r in results if r['py_lines'] > 0]
    print(f"\nWriteups with Python code: {len(py_writeups)} ({len(py_writeups)/len(results)*100:.1f}%)")
    if py_writeups:
        total_py = sum(r['py_lines'] for r in py_writeups)
        print(f"Total Python lines: {total_py:,}")
        print(f"Avg Python lines (when present): {total_py/len(py_writeups):.1f}")
        top_py = max(py_writeups, key=lambda r: r['py_lines'])
        print(f"Most Python: {top_py['name']} ({top_py['py_lines']} lines)")

    print(f"\nScript usage by category:")
    for cat, _ in cats.most_common(10):
        cat_results = [r for r in results if r['category'] == cat]
        if len(cat_results) >= 3:
            n = len(cat_results)
            pwn = sum(1 for r in cat_results if r['has_pwn'])
            req = sum(1 for r in cat_results if r['has_requests'])
            fri = sum(1 for r in cat_results if r['has_frida'])
            print(f"  {cat:20s} (n={n:3d}): pwn={pwn:2d} requests={req:2d} frida={fri:2d}")

    # Words
    total_words = sum(r['words'] for r in results)
    print(f"\n--- WORD COUNT ---")
    print(f"Total prose words: {total_words:,}")
    print(f"Avg words/writeup: {total_words/len(results):.0f}")

    # Length
    print("\n--- LENGTH DISTRIBUTION ---")
    for lo, hi, label in [(0,50,"<50"), (50,100,"50-100"), (100,200,"100-200"),
                           (200,400,"200-400"), (400,800,"400-800"), (800,9999,">800")]:
        n = sum(1 for r in results if lo <= r['total'] < hi)
        bar = "█" * (n // 3)
        print(f"  {label:>8s}: {n:3d} {bar}")

    by_len = sorted(results, key=lambda r: r['total'], reverse=True)
    print("\n5 longest:")
    for r in by_len[:5]:
        print(f"  {r['total']:5d} lines - {r['name']}")
    print("5 shortest:")
    for r in by_len[-5:]:
        print(f"  {r['total']:5d} lines - {r['name']}")

    # Common sections
    print("\n--- COMMON SECTIONS ---")
    all_sections = Counter()
    for r in results:
        all_sections.update(r['sections'])
    for name, count in all_sections.most_common(15):
        print(f"  {count:3d}x {name}")

    print("\n" + "=" * 80)
    print("DONE")

if __name__ == "__main__":
    main()
