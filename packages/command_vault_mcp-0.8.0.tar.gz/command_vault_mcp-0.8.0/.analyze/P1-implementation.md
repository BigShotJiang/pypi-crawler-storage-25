# P1: Index Writeup Prose as Searchable Chunks

## Context

Currently command-vault-mcp only indexes **commands** and **scripts** from writeups. The rich prose — methodology explanations, attack chain reasoning, forensic analysis — is discarded during parsing. This is ~307K words of invisible knowledge. P1 stores prose paragraphs as chunks with FTS5 search, making concepts like "ADCS misconfiguration ESC8" or "NTLM relay to LDAP" searchable.

## Changes

### 1. Schema — `database.py`

Add to `SCHEMA` string:
```sql
CREATE TABLE IF NOT EXISTS writeup_chunks (
    id INTEGER PRIMARY KEY,
    writeup_id INTEGER NOT NULL,
    section TEXT,
    content TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    FOREIGN KEY (writeup_id) REFERENCES writeups(id)
);
CREATE INDEX IF NOT EXISTS idx_chunks_writeup ON writeup_chunks(writeup_id);
```

Add to `FTS_SCHEMA` string:
```sql
CREATE VIRTUAL TABLE IF NOT EXISTS writeup_chunks_fts USING fts5(
    content, section,
    content='writeup_chunks', content_rowid='id'
);
-- Sync triggers (INSERT/DELETE/UPDATE pattern matching existing ones)
```

### 2. Database methods — `database.py`

- `insert_chunk(writeup_id, section, content, chunk_index)` — insert a single chunk
- `clear_writeup_chunks(writeup_id)` — delete chunks for re-indexing (called from `clear_writeup_data`)
- `search_chunks(query, writeup_type, limit)` — FTS search returning chunk + writeup metadata
- Update `clear_writeup_data()` to also delete from `writeup_chunks`
- Update `reset()` to drop `writeup_chunks_fts` table and its triggers
- Update `get_stats()` to include chunk count

### 3. Prose extraction — `parser.py`

Add `extract_prose_chunks(content) -> list[dict]` method to `WriteupParser`:
- Walk the content line by line
- Track current section (H2/H3 headings)
- Skip: code blocks (```...```), image embeds (![[...]]), the Tags: line, blank lines
- Collect consecutive prose lines into paragraphs
- Skip paragraphs shorter than ~30 chars (noise like "Let's check:" or single words)
- Return `[{section, content, chunk_index}]`

### 4. Return chunks from parser — `parser.py`

- `parse_file()` currently returns `(Writeup, commands, scripts)` — change to also extract and return chunks
- Return type becomes `(Writeup, commands, scripts, chunks)` where chunks is a list of dicts

### 5. Indexer — `indexer.py`

- Update `index_file()` to receive chunks from parser and call `db.insert_chunk()` for each
- Update `clear_writeup_data` call path to also clear chunks
- Add `chunks_extracted` counter to `IndexResult` tracking

### 6. Model — `models.py`

- Add `ChunkResult` pydantic model: `id, section, content, source (dict with filename, writeup_type, title)`
- Add `chunks_extracted` field to `IndexResult` (default 0 for backward compat)

### 7. MCP tool — `server.py`

- Add `search_writeup_prose` tool in `list_tools()` with params: `query` (required), `writeup_type`, `tags`, `limit`
- Add dispatch in `call_tool()`
- Implement in `VaultTools`

### 8. CLI — `cli.py`

- Add `prose` subcommand: `vault prose "NTLM relay"` — searches writeup chunks
- Display format:
  ```
  ============================================================
  Source: Authority.md [389/tcp - LDAP]

    <prose content, truncated to ~300 chars>
  ```

### 9. Tests

- Test `extract_prose_chunks()` with sample markdown
- Test chunk insertion and FTS search
- Test that chunks are cleared on re-index

## Files to modify

1. `src/command_vault/database.py` — schema, CRUD, search, reset, stats
2. `src/command_vault/parser.py` — `extract_prose_chunks()`, update `parse_file()` return
3. `src/command_vault/indexer.py` — wire chunks through indexing pipeline
4. `src/command_vault/models.py` — `ChunkResult`, update `IndexResult`
5. `src/command_vault/server.py` — new MCP tool
6. `src/command_vault/cli.py` — new `prose` subcommand
7. `tests/test_parser.py` — prose extraction tests

## Verification

1. `uv run python -m pytest tests/ -q` — all tests pass
2. `vault index --rebuild` — reindex all writeups (required for chunks)
3. `vault stats` — shows chunk count
4. `vault prose "NTLM relay"` — returns relevant prose from writeups
5. `vault prose "ADCS ESC8"` — returns AD CS methodology text
6. MCP `search_writeup_prose` tool returns results
