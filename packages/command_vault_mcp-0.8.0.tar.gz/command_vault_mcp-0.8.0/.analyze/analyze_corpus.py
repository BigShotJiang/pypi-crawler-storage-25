#!/usr/bin/env python3
"""Cross-corpus knowledge map analysis"""
import os, re, statistics
from pathlib import Path
from collections import defaultdict, Counter

DIRS = {
    'box': Path.home() / "writeups" / "boxes",
    'challenge': Path.home() / "writeups" / "challenges",
    'sherlock': Path.home() / "writeups" / "sherlocks"
}

TECHNIQUES = {
    "AD/Windows": {
        "Kerberoasting": r"kerberoast",
        "AS-REP roasting": r"as.?rep",
        "DCSync": r"dcsync",
        "Pass-the-Hash": r"pass.the.hash|pth",
        "Pass-the-Ticket": r"pass.the.ticket|ptt",
        "Silver Ticket": r"silver ticket",
        "Golden Ticket": r"golden ticket",
        "ADCS": r"adcs|esc[1-9]|esc1[0-3]",
        "Shadow Credentials": r"shadow credential",
        "Constrained Delegation": r"constrained delegation",
        "Unconstrained Delegation": r"unconstrained delegation",
        "RBCD": r"rbcd|resource.based constrained",
        "GenericWrite": r"genericwrite",
        "WriteDacl": r"writedacl",
        "WriteOwner": r"writeowner",
        "ForceChangePassword": r"forcechangepassword",
        "BloodHound": r"bloodhound",
        "DACL abuse": r"dacl",
        "GPO abuse": r"gpo",
        "LAPS": r"\blaps\b",
        "gMSA": r"gmsa",
        "DPAPI": r"dpapi",
        "NTLM relay": r"ntlm.?relay|ntlmrelayx",
        "Coercion/PetitPotam": r"petitpotam|coercion|printerbug"
    },
    "Web": {
        "SQLi": r"sqli|sql injection",
        "XSS": r"\bxss\b|cross.site scripting",
        "SSRF": r"\bssrf\b",
        "SSTI": r"\bssti\b|template injection",
        "LFI/RFI": r"\blfi\b|\brfi\b|local file incl|remote file incl",
        "File Upload": r"file upload|unrestricted upload",
        "Deserialization": r"deserializ",
        "JWT": r"\bjwt\b|json web token",
        "IDOR": r"\bidor\b",
        "CORS": r"\bcors\b",
        "Prototype Pollution": r"prototype pollution",
        "XXE": r"\bxxe\b|xml external",
        "CRLF": r"\bcrlf\b",
        "WebSocket": r"websocket",
        "GraphQL": r"graphql",
        "Command Injection": r"command injection|os injection",
        "Path Traversal": r"path traversal|directory traversal"
    },
    "Linux privesc": {
        "SUID": r"\bsuid\b",
        "sudo": r"\bsudo\b",
        "cron": r"\bcron\b|cronjob|crontab",
        "capabilities": r"\bcapabilit",
        "docker/container": r"docker escape|container escape|docker group",
        "kernel exploit": r"kernel exploit|dirty",
        "path hijack": r"path hijack",
        "LD_PRELOAD": r"ld_preload|ld_library",
        "NFS": r"\bnfs\b|no_root_squash",
        "wildcard injection": r"wildcard"
    },
    "Forensics/DFIR": {
        "Memory forensics": r"memory forensic|volatility|vol3",
        "Disk forensics": r"disk forensic|mft|prefetch|amcache|usn journal",
        "Network forensics": r"network forensic|pcap|wireshark|packet",
        "Log analysis": r"log analysis|evtx|event log|hayabusa|chainsaw|sysmon",
        "Malware analysis": r"malware analysis|virustotal|yara|sandbox|any\.run",
        "Timeline analysis": r"timeline",
        "Registry forensics": r"registry|regripper|ntuser\.dat",
        "Browser forensics": r"browser forensic|browser history|chrome|firefox|edge.*histor"
    }
}

TOOLS = [
    "nmap", "rustscan", "masscan", "ffuf", "feroxbuster", "gobuster", "dirsearch",
    "nikto", "wpscan", "sqlmap", "burp", "nuclei", "httpx", "curl", "wget",
    "bloodhound", "certipy", "rubeus", "mimikatz", "impacket", "secretsdump",
    "smbclient", "smbmap", "crackmapexec", "netexec", "nxc", "evil-winrm",
    "psexec", "wmiexec", "dcomexec", "chisel", "ligolo", "sshuttle", "proxychains",
    "socat", "hashcat", "john", "hydra", "medusa", "linpeas", "winpeas", "pspy",
    "seatbelt", "volatility", "vol3", "wireshark", "tcpdump", "autopsy", "ftk",
    "regripper", "hayabusa", "chainsaw", "yara", "ghidra", "ida", "radare2", "gdb",
    "pwndbg", "pwntools", "frida", "jadx", "apktool", "objection", "drozer",
    "docker", "kubectl", "metasploit", "msfvenom", "responder", "ntlmrelayx",
    "pypykatz", "kerbrute", "enum4linux", "rpcclient", "binwalk", "exiftool",
    "strings", "strace", "ltrace", "steghide"
]

def analyze_file(filepath, wtype):
    content = filepath.read_text(encoding='utf-8', errors='ignore')
    lines = content.split('\n')
    total = len(lines)

    # Tags from first 15 lines
    tags = [t.lower() for t in re.findall(r'#(\w+)', '\n'.join(lines[:15]))]

    # Prose vs code
    in_code = False
    code_lines = 0
    for line in lines:
        if line.strip().startswith('```'):
            in_code = not in_code
        elif in_code:
            code_lines += 1
    prose_lines = total - code_lines
    prose_words = len(re.sub(r'```.*?```', '', content, flags=re.DOTALL).split())

    # Techniques
    content_lower = content.lower()
    found_techniques = {}
    for category, techs in TECHNIQUES.items():
        for tech_name, pattern in techs.items():
            if re.search(pattern, content_lower):
                found_techniques[tech_name] = category

    # Tools
    tool_counts = Counter()
    for tool in TOOLS:
        count = len(re.findall(r'\b' + re.escape(tool.lower()) + r'\b', content_lower))
        if count > 0:
            tool_counts[tool] = count

    return {
        'name': filepath.name, 'type': wtype, 'total': total,
        'prose_lines': prose_lines, 'code_lines': code_lines,
        'prose_words': prose_words, 'tags': tags,
        'techniques': found_techniques, 'tool_counts': tool_counts
    }

def main():
    all_results = []
    for wtype, directory in DIRS.items():
        if directory.exists():
            files = list(directory.glob("*.md"))
            print(f"Analyzing {len(files)} {wtype} writeups...")
            for f in sorted(files):
                all_results.append(analyze_file(f, wtype))

    print(f"\nTotal: {len(all_results)} writeups\n")
    print("=" * 80)
    print("CROSS-CORPUS KNOWLEDGE MAP")
    print("=" * 80)

    # 1. Tags
    print("\n--- 1. TAG FREQUENCY ---")
    all_tags = Counter()
    tag_pairs = Counter()
    tagged = 0
    for r in all_results:
        if r['tags']:
            tagged += 1
            all_tags.update(r['tags'])
            sorted_tags = sorted(set(r['tags']))
            for i, t1 in enumerate(sorted_tags):
                for t2 in sorted_tags[i+1:]:
                    tag_pairs[(t1, t2)] += 1

    print(f"Writeups with tags: {tagged}/{len(all_results)}")
    print(f"Unique tags: {len(all_tags)}")
    print("\nTop 50 tags:")
    for i, (tag, count) in enumerate(all_tags.most_common(50), 1):
        print(f"  {i:2d}. #{tag:<25s} {count:4d}")

    print("\nTop 30 tag co-occurrences:")
    for i, ((t1, t2), count) in enumerate(tag_pairs.most_common(30), 1):
        print(f"  {i:2d}. #{t1} + #{t2:<20s} {count:3d}")

    # 2. Technique coverage
    print("\n--- 2. TECHNIQUE COVERAGE ---")
    for category in TECHNIQUES:
        print(f"\n{category}:")
        tech_counts = Counter()
        for r in all_results:
            for tech, cat in r['techniques'].items():
                if cat == category:
                    tech_counts[tech] += 1
        for tech, count in tech_counts.most_common():
            bar = "█" * (count // 5)
            print(f"  {tech:30s}: {count:4d} writeups {bar}")

    # 3. Prose volume
    print("\n--- 3. PROSE VOLUME ---")
    total_prose = sum(r['prose_lines'] for r in all_results)
    total_code = sum(r['code_lines'] for r in all_results)
    total_words = sum(r['prose_words'] for r in all_results)
    print(f"Total prose lines: {total_prose:,}")
    print(f"Total code lines:  {total_code:,}")
    print(f"Total prose words: {total_words:,}")
    print(f"Prose ratio:       {total_prose/(total_prose+total_code)*100:.1f}%")
    print(f"\nEstimated pages (250 words/page): {total_words/250:.0f}")

    for wtype in ['box', 'challenge', 'sherlock']:
        wr = [r for r in all_results if r['type'] == wtype]
        if wr:
            wp = sum(r['prose_words'] for r in wr)
            wl = sum(r['prose_lines'] for r in wr)
            print(f"\n{wtype}:")
            print(f"  Prose words: {wp:,} ({wp/len(wr):.0f}/writeup)")
            print(f"  Prose lines: {wl:,} ({wl/len(wr):.0f}/writeup)")

    # 4. Tool usage
    print("\n--- 4. TOOL USAGE ---")
    all_tool_counts = Counter()
    tool_in_writeups = Counter()
    for r in all_results:
        for tool, count in r['tool_counts'].items():
            all_tool_counts[tool] += count
            tool_in_writeups[tool] += 1

    print(f"Unique tools found: {len(all_tool_counts)}")
    print("\nTop 50 tools (by writeup count):")
    for i, (tool, count) in enumerate(tool_in_writeups.most_common(50), 1):
        mentions = all_tool_counts[tool]
        print(f"  {i:2d}. {tool:20s}: in {count:4d} writeups ({mentions:5d} total mentions)")

    # 5. Length distribution
    print("\n--- 5. LENGTH DISTRIBUTION ---")
    for lo, hi, label in [(0,50,"<50"), (50,100,"50-100"), (100,200,"100-200"),
                           (200,400,"200-400"), (400,800,"400-800"), (800,99999,">800")]:
        n = sum(1 for r in all_results if lo <= r['total'] < hi)
        bar = "█" * (n // 5)
        print(f"  {label:>8s}: {n:3d} {bar}")

    print("\nAverage by type:")
    for wtype in ['box', 'challenge', 'sherlock']:
        wr = [r for r in all_results if r['type'] == wtype]
        if wr:
            avg = statistics.mean(r['total'] for r in wr)
            med = statistics.median(r['total'] for r in wr)
            print(f"  {wtype:12s}: avg={avg:.0f}, median={med:.0f}, n={len(wr)}")

    print("\n10 longest:")
    for r in sorted(all_results, key=lambda r: r['total'], reverse=True)[:10]:
        print(f"  {r['total']:5d} lines - {r['name']} ({r['type']})")
    print("\n10 shortest:")
    for r in sorted(all_results, key=lambda r: r['total'])[:10]:
        print(f"  {r['total']:5d} lines - {r['name']} ({r['type']})")

    print("\n" + "=" * 80)
    print(f"SUMMARY: {len(all_results)} writeups, {total_words:,} prose words, "
          f"{len(all_tags)} unique tags, {len(all_tool_counts)} tools")
    print("=" * 80)

if __name__ == "__main__":
    main()
