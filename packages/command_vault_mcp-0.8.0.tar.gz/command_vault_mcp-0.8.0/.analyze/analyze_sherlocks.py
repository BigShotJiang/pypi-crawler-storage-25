#!/usr/bin/env python3
"""Comprehensive sherlock writeup analysis"""
import os, re, statistics
from pathlib import Path
from collections import defaultdict, Counter

DIR = Path.home() / "writeups" / "sherlocks"

ARTIFACTS = {
    "Windows artifacts": ["EVTX", "Registry", "Prefetch", "MFT", "Amcache", "SRUM", "ShimCache",
                          "BAM", "UserAssist", "Shellbags", "Jump List", "LNK", "Recycle Bin",
                          "NTFS", "USN Journal", "SAM", "SECURITY", "SYSTEM", "NTUSER", "SOFTWARE"],
    "Memory forensics": ["Volatility", "vol3", "memdump", "process injection", "DLL injection",
                         "hollowing", "LSASS", "memory dump", "memory forensic"],
    "Network forensics": ["PCAP", "Wireshark", "tcpdump", "Zeek", "Suricata", "DNS query",
                          "HTTP request", "TLS", "beacon", "C2", "NetworkMiner"],
    "Log analysis": ["Hayabusa", "Chainsaw", "EventLog", "Sysmon", "PowerShell log",
                     "Windows Defender", "event log", "Security log"],
    "Malware tools": ["VirusTotal", "YARA", "strings", "PEStudio", "DIE", "sandbox",
                      "any.run", "hybrid-analysis", "static analysis", "dynamic analysis"],
    "DFIR tools": ["FTK", "Autopsy", "RegRipper", "MFTExplorer", "PECmd", "Timeline Explorer",
                   "KAPE", "Eric Zimmerman", "Registry Explorer", "ShellBags Explorer"],
    "Credential tools": ["DPAPI", "Mimikatz", "LSASS", "secretsdump", "hashcat", "john",
                         "NTLM", "Kerberos", "credential", "password"]
}

QUESTION_PATTERNS = {
    "timestamp": r"(?i)(when|time|date|timestamp|UTC|first seen|last seen|what time)",
    "ip_address": r"(?i)(IP address|IP of|source IP|destination IP|remote IP|attacker.s? IP)",
    "file_path": r"(?i)(file name|file path|filename|directory|folder|location|full path|what file)",
    "hash": r"(?i)(hash|SHA256|SHA-256|MD5|SHA1|indicator|IOC|checksum)",
    "tool_technique": r"(?i)(tool|technique|method|vulnerability|CVE|what was used|attack type|malware)",
    "user_account": r"(?i)(user|account|username|email|who|victim|attacker name|employee)",
    "process": r"(?i)(process|PID|executable|binary|what ran|parent process|command line)",
    "domain_url": r"(?i)(domain|URL|website|hostname|FQDN|web address|link)",
    "count": r"(?i)(how many|count|number of|total)"
}

def parse_difficulty(name):
    m = re.search(r'\(([^)]+)\)\.md$', name)
    return m.group(1).strip() if m else 'Unknown'

def analyze_file(filepath):
    content = filepath.read_text(encoding='utf-8', errors='ignore')
    lines = content.split('\n')
    total = len(lines)
    difficulty = parse_difficulty(filepath.name)

    # Tasks
    task_nums = set()
    for m in re.finditer(r'(?:#{2,3})\s*Task\s+(\d+)', content, re.I):
        task_nums.add(int(m.group(1)))
    num_tasks = len(task_nums)

    # Code blocks
    in_code = False
    code_lines = 0
    code_blocks = 0
    for line in lines:
        if line.strip().startswith('```'):
            if not in_code:
                code_blocks += 1
            in_code = not in_code
        elif in_code:
            code_lines += 1

    prose_lines = total - code_lines
    prose_ratio = prose_lines / total if total > 0 else 0
    images = len(re.findall(r'!\[\[.*?\]\]', content))

    # Artifact mentions
    content_lower = content.lower()
    artifact_counts = {}
    for cat, keywords in ARTIFACTS.items():
        total_mentions = 0
        for kw in keywords:
            total_mentions += len(re.findall(r'\b' + re.escape(kw.lower()) + r'\b', content_lower))
        artifact_counts[cat] = total_mentions

    # Extract task questions
    questions = []
    parts = re.split(r'#{2,3}\s*Task\s+\d+', content, flags=re.I)
    for part in parts[1:]:
        task_lines = part.strip().split('\n')[:10]
        for line in task_lines:
            line = line.strip().strip('_').strip('*')
            if '?' in line and 10 < len(line) < 300:
                # Categorize
                cats = []
                for cat_name, pattern in QUESTION_PATTERNS.items():
                    if re.search(pattern, line):
                        cats.append(cat_name)
                if not cats:
                    cats = ['other']
                questions.append({'text': line, 'categories': cats})
                break

    # URLs
    urls = re.findall(r'https?://[^\s\)\]<>"]+', content)
    domains = []
    for url in urls:
        m = re.search(r'https?://([^/\s]+)', url)
        if m:
            domains.append(m.group(1))

    words = len(re.sub(r'```.*?```', '', content, flags=re.DOTALL).split())

    return {
        'name': filepath.name, 'difficulty': difficulty, 'total': total,
        'num_tasks': num_tasks, 'code_blocks': code_blocks, 'images': images,
        'prose_ratio': prose_ratio, 'prose_lines': prose_lines, 'code_lines': code_lines,
        'artifact_counts': artifact_counts, 'questions': questions,
        'num_urls': len(urls), 'domains': domains, 'words': words
    }

def main():
    files = list(DIR.glob("*.md"))
    print(f"Analyzing {len(files)} sherlock writeups...\n")
    results = [analyze_file(f) for f in sorted(files)]

    print("=" * 80)
    print("SHERLOCK WRITEUP ANALYSIS")
    print("=" * 80)

    # Difficulty breakdown
    diffs = Counter(r['difficulty'] for r in results)
    print("\n--- DIFFICULTY BREAKDOWN ---")
    print(f"{'Difficulty':<12} | {'Count':<6} | {'Avg Lines':<10} | {'Avg Tasks':<10} | {'Avg Images':<10} | {'Avg Prose%':<10}")
    print("-" * 75)
    for diff in ['Very Easy', 'Easy', 'Medium', 'Hard', 'Insane']:
        dr = [r for r in results if r['difficulty'] == diff]
        if dr:
            print(f"{diff:<12} | {len(dr):<6} | {statistics.mean(r['total'] for r in dr):<10.1f} | "
                  f"{statistics.mean(r['num_tasks'] for r in dr):<10.1f} | "
                  f"{statistics.mean(r['images'] for r in dr):<10.1f} | "
                  f"{statistics.mean(r['prose_ratio'] for r in dr)*100:<10.1f}")

    # Structure
    print("\n--- STRUCTURE ---")
    print(f"Total lines: {sum(r['total'] for r in results):,}")
    print(f"Avg lines/writeup: {statistics.mean(r['total'] for r in results):.1f}")
    print(f"Total tasks: {sum(r['num_tasks'] for r in results)}")
    print(f"Avg tasks/writeup: {statistics.mean(r['num_tasks'] for r in results):.1f}")
    print(f"Total code blocks: {sum(r['code_blocks'] for r in results)}")
    print(f"Total images: {sum(r['images'] for r in results)}")
    print(f"Avg images/writeup: {statistics.mean(r['images'] for r in results):.1f}")

    # Prose ratio
    print("\n--- PROSE RATIO ---")
    print(f"Average: {statistics.mean(r['prose_ratio'] for r in results)*100:.1f}%")
    print(f"Median: {statistics.median(r['prose_ratio'] for r in results)*100:.1f}%")
    for lo, hi, label in [(0,0.5,"<50%"), (0.5,0.6,"50-60%"), (0.6,0.7,"60-70%"),
                           (0.7,0.8,"70-80%"), (0.8,0.9,"80-90%"), (0.9,1.01,">90%")]:
        n = sum(1 for r in results if lo <= r['prose_ratio'] < hi)
        bar = "█" * n
        print(f"  {label:>6s}: {n:3d} {bar}")

    # Artifacts
    print("\n--- FORENSIC ARTIFACT/TOOL MENTIONS ---")
    for cat in ARTIFACTS:
        total = sum(r['artifact_counts'][cat] for r in results)
        with_cat = sum(1 for r in results if r['artifact_counts'][cat] > 0)
        print(f"  {cat:20s}: {total:5d} mentions across {with_cat:2d} writeups")

    print("\nTop 5 by Windows artifacts:")
    for r in sorted(results, key=lambda r: r['artifact_counts']['Windows artifacts'], reverse=True)[:5]:
        print(f"  {r['artifact_counts']['Windows artifacts']:3d} - {r['name']}")

    print("\nTop 5 by Network forensics:")
    for r in sorted(results, key=lambda r: r['artifact_counts']['Network forensics'], reverse=True)[:5]:
        print(f"  {r['artifact_counts']['Network forensics']:3d} - {r['name']}")

    # Task questions
    all_q = []
    for r in results:
        all_q.extend(r['questions'])
    print(f"\n--- TASK QUESTION ANALYSIS ---")
    print(f"Total questions extracted: {len(all_q)}")
    q_cats = Counter()
    for q in all_q:
        for c in q['categories']:
            q_cats[c] += 1
    print("\nQuestion types:")
    for cat, count in q_cats.most_common():
        pct = count / len(all_q) * 100 if all_q else 0
        bar = "█" * (count // 5)
        print(f"  {cat:20s}: {count:4d} ({pct:5.1f}%) {bar}")

    # URLs/domains
    print(f"\n--- EXTERNAL REFERENCES ---")
    print(f"Total URLs: {sum(r['num_urls'] for r in results)}")
    print(f"Avg URLs/writeup: {statistics.mean(r['num_urls'] for r in results):.1f}")
    all_domains = Counter()
    for r in results:
        all_domains.update(r['domains'])
    print("\nTop 15 domains:")
    for domain, count in all_domains.most_common(15):
        print(f"  {domain:40s} {count:3d}")

    # Words
    total_words = sum(r['words'] for r in results)
    print(f"\n--- WORD COUNT ---")
    print(f"Total: {total_words:,}, Avg: {total_words/len(results):.0f}")

    # Top writeups
    print("\n--- TOP WRITEUPS ---")
    print("Longest:")
    for r in sorted(results, key=lambda r: r['total'], reverse=True)[:5]:
        print(f"  {r['total']:5d} lines - {r['name']}")
    print("Most tasks:")
    for r in sorted(results, key=lambda r: r['num_tasks'], reverse=True)[:5]:
        print(f"  {r['num_tasks']:2d} tasks - {r['name']}")
    print("Most images:")
    for r in sorted(results, key=lambda r: r['images'], reverse=True)[:5]:
        print(f"  {r['images']:3d} imgs - {r['name']}")

    print("\n" + "=" * 80)
    print("DONE")

if __name__ == "__main__":
    main()
