# HTML Writeup Conversion Pipeline

This document describes the pipeline for converting Russian HTML writeups to English markdown with extracted images.

## Directory Structure

```
writeups/
├── *.html              # Original HTML files (Russian, SingleFile format)
├── md/                 # Output: Translated markdown files
│   └── {name}.md
├── images/             # Output: Extracted images
│   └── {name}/
│       └── img_001_*.png
├── scripts/
│   └── convert_writeup.py
└── CONVERT.md          # This file
```

## Requirements

```bash
pip install beautifulsoup4 lxml
```

## Usage

### Convert a single file:
```bash
python3 scripts/convert_writeup.py "Easy Money.html"
```

### Convert all files:
```bash
for f in *.html; do
    python3 scripts/convert_writeup.py "$f"
done
```

## Pipeline Steps

1. **Parse HTML** - BeautifulSoup extracts content from SingleFile-exported HTML
2. **Extract Images** - Base64-encoded images are decoded and saved as PNG/JPG files
3. **Convert to Markdown** - HTML structure is converted to markdown syntax
4. **Manual Translation** - Russian text is translated to English (currently manual step)

## Output Format

Each markdown file contains:
- Title (H1)
- Challenge description (English, from original)
- Questions section (translated)
- Investigation section (translated walkthrough with answers)
- Image references pointing to `images/{writeup-name}/`
- Code blocks with flag/answer values

## Notes

- Images are named with a counter and content hash: `img_001_a1b2c3d4.png`
- The script handles nested HTML structures from the ProseMirror editor
- Code blocks, links, and formatting are preserved
