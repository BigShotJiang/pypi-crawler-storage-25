#!/usr/bin/env python3
"""
HTML Writeup to Markdown Converter

Converts SingleFile-exported HTML writeups to Markdown format with image extraction.
Designed for HackTheBox Sherlock writeups saved from Outline/ProseMirror editors.

Usage:
    python3 convert_writeup.py <html_file>
    python3 convert_writeup.py "Easy Money.html"

Output:
    - md/{filename}.md - Markdown file
    - images/{filename}/ - Extracted images
"""

import re
import base64
import hashlib
from pathlib import Path
from bs4 import BeautifulSoup, NavigableString
import sys


def extract_base64_image(data_uri: str, counter: int, output_dir: Path) -> str | None:
    """
    Extract base64-encoded image from data URI and save to file.

    Args:
        data_uri: Data URI string (data:image/png;base64,...)
        counter: Image counter for filename
        output_dir: Directory to save image

    Returns:
        Filename if successful, None otherwise
    """
    match = re.match(r'data:image/(\w+);base64,(.+)', data_uri)
    if not match:
        return None

    ext = match.group(1)
    if ext == 'jpeg':
        ext = 'jpg'
    data = match.group(2)

    # Create unique filename based on content hash
    content_hash = hashlib.md5(data[:100].encode()).hexdigest()[:8]
    filename = f"img_{counter:03d}_{content_hash}.{ext}"

    output_dir.mkdir(parents=True, exist_ok=True)
    img_path = output_dir / filename

    try:
        img_data = base64.b64decode(data)
        with open(img_path, 'wb') as f:
            f.write(img_data)
        return filename
    except Exception as e:
        print(f"  Error saving image: {e}")
        return None


def element_to_markdown(element, images_dir: Path, image_counter: list, writeup_name: str) -> str:
    """
    Recursively convert a BeautifulSoup element to markdown.

    Args:
        element: BeautifulSoup element
        images_dir: Directory for saving images
        image_counter: Mutable list containing counter [n]
        writeup_name: Name of writeup for image paths

    Returns:
        Markdown string
    """
    # Handle text nodes
    if isinstance(element, NavigableString):
        text = str(element)
        if text.strip():
            return text.strip()
        return ''

    tag = element.name

    # Skip non-content tags
    if tag in ['style', 'script', 'meta', 'link', 'noscript']:
        return ''

    # Skip heading-actions spans (editor UI elements)
    if tag == 'span' and 'heading-actions' in element.get('class', []):
        return ''

    # Process children recursively
    children_md = []
    for child in element.children:
        child_md = element_to_markdown(child, images_dir, image_counter, writeup_name)
        if child_md:
            children_md.append(child_md)

    content = ' '.join(children_md)
    content = re.sub(r'\s+', ' ', content).strip()

    # Convert HTML tags to markdown
    if tag == 'h1':
        return f"\n# {content}\n"
    elif tag == 'h2':
        return f"\n## {content}\n"
    elif tag == 'h3':
        return f"\n### {content}\n"
    elif tag == 'p':
        return f"\n{content}\n"
    elif tag == 'pre':
        code_text = element.get_text()
        return f"\n```\n{code_text}\n```\n"
    elif tag == 'code':
        if element.parent and element.parent.name == 'pre':
            return element.get_text()
        return f"`{content}`"
    elif tag == 'li':
        return f"- {content}"
    elif tag in ('ol', 'ul'):
        items = []
        for li in element.find_all('li', recursive=False):
            item_md = element_to_markdown(li, images_dir, image_counter, writeup_name)
            items.append(item_md)
        return '\n' + '\n'.join(items) + '\n'
    elif tag in ('strong', 'b'):
        return f"**{content}**" if content else ''
    elif tag in ('em', 'i'):
        return f"*{content}*" if content else ''
    elif tag == 'a':
        href = element.get('href', '')
        if href and content:
            return f"[{content}]({href})"
        return content
    elif tag == 'br':
        return '\n'
    elif tag == 'img':
        src = element.get('src', '')
        alt = element.get('alt', '')
        if src.startswith('data:image'):
            image_counter[0] += 1
            filename = extract_base64_image(src, image_counter[0], images_dir)
            if filename:
                return f"\n![{alt}](images/{writeup_name}/{filename})\n"
        elif src:
            return f"\n![{alt}]({src})\n"
        return ''
    else:
        return content


def convert_file(html_path: str | Path, output_dir: str | Path = None,
                 images_base_dir: str | Path = None) -> Path | None:
    """
    Convert a single HTML file to Markdown.

    Args:
        html_path: Path to HTML file
        output_dir: Directory for markdown output (default: ./md)
        images_base_dir: Directory for images (default: ./images)

    Returns:
        Path to output markdown file, or None on failure
    """
    html_path = Path(html_path)

    # Set defaults relative to HTML file location
    base_dir = html_path.parent
    output_dir = Path(output_dir) if output_dir else base_dir / 'md'
    images_base_dir = Path(images_base_dir) if images_base_dir else base_dir / 'images'

    writeup_name = html_path.stem
    images_dir = images_base_dir / writeup_name

    print(f"Processing: {html_path.name}")

    # Read and parse HTML
    with open(html_path, 'r', encoding='utf-8') as f:
        html_content = f.read()

    soup = BeautifulSoup(html_content, 'lxml')

    # Find main content area (ProseMirror editor or body)
    content_div = soup.find('div', class_='ProseMirror')
    if not content_div:
        content_div = soup.body

    if not content_div:
        print(f"  Warning: No content found in {html_path.name}")
        return None

    # Extract title
    h1 = soup.find('h1')
    title = h1.get_text().strip() if h1 else writeup_name

    # Convert to markdown
    image_counter = [0]  # Mutable for nested function
    markdown_parts = [f"# {title}\n"]

    for child in content_div.children:
        md = element_to_markdown(child, images_dir, image_counter, writeup_name)
        if md and md.strip():
            markdown_parts.append(md)

    markdown = '\n'.join(markdown_parts)

    # Clean up formatting
    markdown = re.sub(r'\n{3,}', '\n\n', markdown)
    markdown = re.sub(r' +', ' ', markdown)

    # Save markdown
    output_dir.mkdir(parents=True, exist_ok=True)
    md_path = output_dir / f"{writeup_name}.md"
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(markdown)

    print(f"  Output: {md_path}")
    print(f"  Images extracted: {image_counter[0]}")

    return md_path


def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print(__doc__)
        print("\nError: No input file specified")
        sys.exit(1)

    html_file = sys.argv[1]

    if not Path(html_file).exists():
        print(f"Error: File not found: {html_file}")
        sys.exit(1)

    convert_file(html_file)


if __name__ == '__main__':
    main()
