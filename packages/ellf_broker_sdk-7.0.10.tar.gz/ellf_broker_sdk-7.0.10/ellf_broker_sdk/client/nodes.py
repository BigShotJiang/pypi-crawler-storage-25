from typing import cast

from ..models import NodeDetail, NodeSummary
from .base import BaseClient


class Nodes(BaseClient):
    async def list_async(self) -> list[NodeSummary]:
        res = await self.request_async(
            "GET", endpoint="", return_model=list[NodeSummary]
        )
        return cast(list[NodeSummary], res)

    def list(self) -> list[NodeSummary]:
        res = self.request("GET", endpoint="", return_model=list[NodeSummary])
        return cast(list[NodeSummary], res)

    def get(self, name: str) -> NodeDetail:
        res = self.request("GET", endpoint=name, return_model=NodeDetail)
        return cast(NodeDetail, res)

    async def get_async(self, name: str) -> NodeDetail:
        res = await self.request_async("GET", endpoint=name, return_model=NodeDetail)
        return cast(NodeDetail, res)
