import json
from collections.abc import AsyncIterable, Iterable
from typing import Any

import httpcore
import httpx


def event_stream(
    *,
    client: httpx.Client,
    url: str,
    method: str,
    index: int,
    params: dict[str, Any] | None = None,
    timeout: int | None,
) -> Iterable[dict[str, Any]]:
    """Stream events via HTTP long-poll, reconnecting when disconnected."""
    if params is None:
        params = {}
    if index <= 0:
        index = -1
    while True:
        with client.stream(
            url=url,
            method=method,
            params={"index": index + 1}.update(params),
            timeout=timeout,
        ) as response:
            try:
                for line in response.iter_lines():
                    events = json.loads(line)
                    if events is None:
                        return
                    yield events
                    if "Index" in events:
                        index = max(events["Index"], index)
            except (
                httpcore.ReadTimeout,
                httpx.ReadTimeout,
                httpx.RemoteProtocolError,
                httpx.WriteError,
                httpx.WriteTimeout,
            ):
                continue


async def event_stream_async(
    *,
    client: httpx.AsyncClient,
    url: str,
    method: str,
    index: int,
    timeout: int | None,
    params: dict[str, Any] | None = None,
) -> AsyncIterable[dict[str, Any]]:
    """Stream events asynchronously via HTTP long-poll, reconnecting when disconnected."""
    if params is None:
        params = {}
    if index <= 0:
        index = -1
    while True:
        async with client.stream(
            url=url,
            method=method,
            params={"index": index + 1}.update(params),
            timeout=timeout,
        ) as response:
            try:
                async for line in response.aiter_lines():
                    events = json.loads(line)
                    if events is None:
                        return
                    yield events
                    if "Index" in events:
                        index = max(events["Index"], index)
            except (
                httpcore.ReadTimeout,
                httpx.ReadTimeout,
                httpx.RemoteProtocolError,
                httpx.WriteError,
                httpx.WriteTimeout,
            ):
                continue


__all__ = ["event_stream", "event_stream_async"]
