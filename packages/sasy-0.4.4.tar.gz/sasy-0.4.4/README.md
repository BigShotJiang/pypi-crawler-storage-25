# sasy

Python SDK for policy enforcement in LLM-based agent systems.

Instruments Langroid agents and HTTP libraries to enforce Datalog
policies via the SASY Rust binary, with automatic event recording
to the message dependency graph.

## Quick Start

```python
import sasy

sasy.configure(
    reference_monitor_url="localhost:10089",
    auth_method="api_key",
    api_key="my-api-key",
)
sasy.instrument()

# Langroid agents, HTTP requests, and Tau2 agents now have
# policy enforcement via the SASY binary.
```

## How It Works

Instrumentation monkey-patches key methods in target libraries:

- **Langroid**: Patches `Agent`/`ChatAgent` responders and `Task`
  methods to record messages to the graph and check tool authorization
- **HTTP**: Patches `requests` and `httpx` to route requests through
  the reference monitor for policy evaluation and credential injection
- **Tau2**: Patches Tau2 agent tool calls for policy enforcement

```
Application Code
    │ (patched)              │ (patched)
    ▼                        ▼
Langroid              HTTP
Instrumentation       Instrumentation
│ Record events       │ Route via RM
│ Check tool auth     │ Stream response
    ▼                        ▼
Observability         Reference Monitor
(gRPC :10089)         (gRPC :10089)
```

## Instrumentation

```python
import sasy

# Configure auth and options
sasy.configure(
    auth_hook=sasy.auth.APIKeyAuthHook(api_key="my-key"),
    log_denials=True,
    feedback_callback=my_callback,
)

# Enable all instrumentation (HTTP + Langroid)
sasy.instrument()

# Or selectively
sasy.instrument(http=True, langroid=False, tau2=False)
```

### Feedback Handling

Collect authorization feedback from denied requests:

```python
from sasy.instrumentation.feedback import FeedbackAccumulator

def feedback_callback(accumulator: FeedbackAccumulator, output, agent):
    if accumulator.has_denials():
        feedback = accumulator.format_for_llm()
        if output:
            output.content += f"\n\n{feedback}"

sasy.configure(feedback_callback=feedback_callback)
```

### Manual Tool Checks

```python
result = sasy.check_tool_call(
    fn_name="web_search",
    args='{"query": "hello"}',
)
if not result.authorized:
    print(result.denial_trace)
```

## Observability API

Record events and query the message dependency graph:

```python
from sasy.observability import (
    Event, Edge, Role, Tool,
    record_events,
    record_events_with_dependencies,
    backward_slice,
)

# Record an event with dependencies
ids = record_events_with_dependencies(
    events=[Event(text="Hello", role=Role.USER, agent="MyAgent")],
    edges=[Edge(source=parent_id, destination=new_id, proximal=True)],
)

# Query the graph
graph = backward_slice(event_id="msg-123", max_depth=5)
```

## Credentials API

Store and retrieve credentials for policy-driven injection:

```python
from sasy.credentials.api import set_credentials, get_credentials

# Store (requires credential-writer role)
set_credentials(
    entity="*",           # Wildcard: all entities
    service="openai",
    credentials={"api_key": "sk-..."},
)

# Retrieve (requires credential-reader role)
creds = get_credentials(entity="alice", service="openai")
```

## Authentication

The SDK supports multiple auth methods via hooks:

```python
from sasy.auth import (
    APIKeyAuthHook,      # API key in x-api-key header
    OIDCAuthHook,        # OAuth2 client credentials
    KeycloakAuthHook,    # Keycloak-specific OIDC
    BrowserAuthHook,     # OAuth2 authorization code + PKCE
    DeviceAuthHook,      # OAuth2 device flow
    NoAuthHook,          # No authentication (mTLS only)
)

sasy.configure(auth_hook=APIKeyAuthHook(api_key="my-key"))
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `SASY_URL` | SASY binary gRPC endpoint | `sasy.fly.dev:443` |
| `TLS_CA_PATH` | CA certificate path | — |
| `TLS_CERT_PATH` | Client certificate (mTLS) | — |
| `TLS_KEY_PATH` | Client private key (mTLS) | — |

For local development, set `SASY_URL=localhost:10089` in `.env`.

## Package Structure

| Module | Description |
|--------|-------------|
| `sasy.instrumentation` | HTTP, Langroid, and Tau2 instrumentation |
| `sasy.observability` | Event recording and graph queries |
| `sasy.credentials` | Credential store client |
| `sasy.reference_monitor` | Reference monitor client utilities |
| `sasy.auth` | Auth hooks and gRPC interceptors |
| `sasy.tls` | TLS/mTLS configuration |
| `sasy.proto` | Generated protobuf stubs |

## gRPC Protocol

The SDK communicates with the SASY binary via gRPC, defined in `proto/`:

- **`RMProxy.ProxyHTTP`** — Bidirectional streaming HTTP proxy with policy enforcement
- **`RMProxy.CheckToolCall`** — Tool call authorization check
- **`Observability.RegisterEventsWithDependencies`** — Atomic event + edge recording
- **`Observability.BackwardSlice`** / **`ForwardSlice`** — Graph queries
- **`CredentialServer.GetCredentials`** / **`SetCredentials`** — Credential CRUD
- **`PolicyEngine.UploadPolicy`** — Hot-reload policy at runtime
- **`PolicyEngine.ValidatePolicy`** — Validate policy without applying
