"""
Instrumentation for Langroid and HTTP libraries.

Usage:
    import sasy
    sasy.instrument()

    # Or selectively
    sasy.instrument(http=True, langroid=False, tau2=False)

    # Check tool call authorization manually
    result = sasy.check_tool_call(fn_name="my_tool", args='{"key": "value"}')
"""

from . import otel
from . import testing
from .http import instrument as _instrument_http
from .langroid import instrument as instrument_langroid
from .tau2 import instrument as instrument_tau2
from .config import configure, get_config, InstrumentationConfig, FeedbackCallback
from .feedback import (
    FeedbackAccumulator,
    get_current_feedback,
    add_denial,
    add_tool_denial,
)
from sasy.reference_monitor import check_tool_call

# Re-export for convenience
instrument_http = _instrument_http


def instrument(
    http: bool = True,
    langroid: bool = True,
    tau2: bool = False,
) -> None:
    """Instrument HTTP libraries, Langroid, and/or Tau2.

    Connection settings (URL, TLS, auth) are configured via
    ``sasy.configure()`` or the ``SASY_URL`` env var. This
    function just enables the monkey-patches.

    Args:
        http: Enable HTTP library instrumentation (requests, httpx).
        langroid: Enable Langroid agent instrumentation.
        tau2: Enable Tau2 agent instrumentation.
    """
    if http:
        _instrument_http()

    if langroid:
        instrument_langroid()

    if tau2:
        instrument_tau2()


__all__ = [
    "instrument",
    "configure",
    "get_config",
    "InstrumentationConfig",
    "FeedbackCallback",
    "instrument_http",
    "instrument_langroid",
    "instrument_tau2",
    "check_tool_call",
    "FeedbackAccumulator",
    "get_current_feedback",
    "add_denial",
    "add_tool_denial",
    "otel",
    "testing",
]
