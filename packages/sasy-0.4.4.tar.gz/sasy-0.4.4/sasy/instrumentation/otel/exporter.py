"""
OpenTelemetry Span Exporter for the Observability Server.

This module implements a custom SpanExporter that sends OTel spans
to the observability server via gRPC, which then stores them as
Computation nodes in Neo4j.
"""

import json
import logging
from typing import Sequence

from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult

from sasy.observability.api import register_computations
from sasy.proto.observability_pb2 import Computation, SpanStatusCode

logger = logging.getLogger(__name__)


class ObservabilitySpanExporter(SpanExporter):
    """
    Custom SpanExporter that sends OTel spans to the observability server.

    The exporter converts OTel spans to Computation protobuf messages and
    sends them via the RegisterComputations gRPC endpoint. The server then
    creates:
    - Computation nodes for each span with trace/span IDs, timing, status, etc.
    - CHILD_OF relationships between parent and child spans
    - PRODUCES relationships from spans to output messages (via _output_message_id attr)
    - CONSUMES relationships from spans to input messages (via _input_message_ids attr)

    Usage:
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from sasy.instrumentation.otel import ObservabilitySpanExporter

        exporter = ObservabilitySpanExporter()
        processor = BatchSpanProcessor(exporter)
        trace_provider.add_span_processor(processor)
    """

    def __init__(self) -> None:
        """Initialize the observability span exporter."""
        self._closed = False

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """
        Export spans to the observability server.

        Args:
            spans: Sequence of ReadableSpan objects to export

        Returns:
            SpanExportResult.SUCCESS or SpanExportResult.FAILURE
        """
        if self._closed:
            return SpanExportResult.FAILURE

        try:
            computations = [self._span_to_computation(span) for span in spans]
            register_computations(computations)
            return SpanExportResult.SUCCESS
        except Exception as e:
            logger.error(f"Failed to export spans: {e}")
            return SpanExportResult.FAILURE

    def _span_to_computation(self, span: ReadableSpan) -> Computation:
        """Convert an OTel ReadableSpan to a Computation protobuf message."""
        # Extract span identifiers
        trace_id = format(span.context.trace_id, "032x")
        span_id = format(span.context.span_id, "016x")
        parent_span_id = None
        if span.parent is not None:
            parent_span_id = format(span.parent.span_id, "016x")

        # Extract timing
        start_time_ns = span.start_time or 0
        end_time_ns = span.end_time or 0

        # Extract status - map OTel StatusCode to our SpanStatusCode enum
        status_code: SpanStatusCode = SpanStatusCode.STATUS_UNSET
        status_message: str | None = None
        if span.status:
            otel_code = span.status.status_code.value
            if otel_code == 1:  # OK
                status_code = SpanStatusCode.STATUS_OK
            elif otel_code == 2:  # ERROR
                status_code = SpanStatusCode.STATUS_ERROR
            status_message = span.status.description

        # Convert attributes to dict, separating special link attributes
        attributes = dict(span.attributes) if span.attributes else {}
        input_message_ids_raw = attributes.pop("_input_message_ids", None)
        input_message_ids: str | list[str] | None = (
            str(input_message_ids_raw) if isinstance(input_message_ids_raw, str)
            else list(input_message_ids_raw) if isinstance(input_message_ids_raw, (list, tuple))
            else None
        )
        output_message_id_raw = attributes.pop("_output_message_id", None)
        output_message_id: str | None = str(output_message_id_raw) if output_message_id_raw else None

        # Convert events to JSON array
        events_list = []
        for event in span.events or []:
            event_attrs = dict(event.attributes) if event.attributes else {}
            events_list.append({
                "name": event.name,
                "timestamp_ns": event.timestamp or 0,
                "attributes": event_attrs,
            })

        # Extract resource info
        service_name: str | None = None
        service_version: str | None = None
        if span.resource:
            sn = span.resource.attributes.get("service.name")
            service_name = str(sn) if sn else None
            sv = span.resource.attributes.get("service.version")
            service_version = str(sv) if sv else None

        # Build Computation message
        computation = Computation(
            trace_id=trace_id,
            span_id=span_id,
            name=span.name,
            start_time_ns=start_time_ns,
            end_time_ns=end_time_ns,
            status_code=status_code,
            attributes_json=json.dumps(attributes),
            events_json=json.dumps(events_list),
        )

        # Set optional fields
        if parent_span_id:
            computation.parent_span_id = parent_span_id
        if status_message:
            computation.status_message = status_message
        if service_name:
            computation.service_name = service_name
        if service_version:
            computation.service_version = service_version
        if input_message_ids:
            # input_message_ids is stored as comma-separated string in span attributes
            if isinstance(input_message_ids, str):
                computation.input_message_ids.extend(input_message_ids.split(","))
            else:
                computation.input_message_ids.extend(input_message_ids)
        if output_message_id:
            computation.output_message_id = output_message_id

        return computation

    def shutdown(self) -> None:
        """Clean up resources."""
        self._closed = True

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """
        Force flush any pending exports.

        Since we write synchronously, this is a no-op.

        Returns:
            True (always successful)
        """
        return True
