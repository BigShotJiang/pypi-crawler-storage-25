"""
Instrumentation configuration.

Connection settings (URL, TLS, auth) are managed by the shared
``sasy.config`` module. This module adds instrumentation-specific
options (logging, OTel, feedback callbacks).
"""

from typing import Any, Callable, Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from sasy.auth.hooks import AuthHook

# Type alias for feedback callback
# Signature: callback(accumulator: FeedbackAccumulator, output: ChatDocument | None, agent: Agent)
FeedbackCallback = Callable[[Any, Any, Any], None]


class InstrumentationConfig(BaseSettings):
    """Instrumentation-specific settings.

    Connection settings (URL, TLS, auth) come from ``sasy.config``.
    This class holds only the instrumentation-layer options.

    Environment variables:
        OTEL_ENABLED=true
        OTEL_SERVICE_NAME=instrumentation
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore",
    )

    # Feedback configuration
    log_denials: bool = Field(
        default=True,
        description="Log authorization denials at responder boundaries",
    )
    log_policy_decisions: bool = Field(
        default=False,
        description="Print colored [POLICY] lines for HTTP authorization decisions",
    )
    log_policy_decisions_transforms_only: bool = Field(
        default=False,
        description="Only print AUTHORIZED when transforms are present",
    )
    log_transforms: bool = Field(
        default=False,
        description="Print colored [TRANSFORM] lines for applied transforms",
    )
    feedback_callback: Optional[FeedbackCallback] = Field(
        default=None,
        description="Callback for handling authorization feedback",
    )

    # OpenTelemetry
    otel_enabled: bool = Field(
        default=True,
        description="Enable OpenTelemetry tracing",
        alias="OTEL_ENABLED",
    )
    otel_service_name: str = Field(
        default="instrumentation",
        description="Service name for OTel traces",
        alias="OTEL_SERVICE_NAME",
    )

    # Tool policy enforcement
    tool_policy_fail_closed: bool = Field(
        default=True,
        description="If True, deny tool calls when reference monitor is unavailable.",
    )



# Global configuration instance
_config: Optional[InstrumentationConfig] = None


def get_config() -> InstrumentationConfig:
    """Get the global instrumentation configuration."""
    global _config
    if _config is None:
        _config = InstrumentationConfig()
    return _config


def configure(
    sasy_url: Optional[str] = None,
    ca_path: Optional[str] = None,
    cert_path: Optional[str] = None,
    key_path: Optional[str] = None,
    auth_hook: Optional[AuthHook] = None,
    log_denials: Optional[bool] = None,
    log_policy_decisions: Optional[bool] = None,
    log_policy_decisions_transforms_only: Optional[bool] = None,
    log_transforms: Optional[bool] = None,
    feedback_callback: Optional[FeedbackCallback] = None,
    otel_enabled: Optional[bool] = None,
    otel_service_name: Optional[str] = None,
    tool_policy_fail_closed: Optional[bool] = None,
) -> InstrumentationConfig:
    """Configure instrumentation settings.

    Connection settings (url, TLS, auth) are forwarded to the shared
    ``sasy.config``. Instrumentation-specific options are stored here.
    """
    global _config
    if _config is None:
        _config = InstrumentationConfig()

    # Forward connection settings to shared config
    from sasy.config import configure as _configure_shared
    _configure_shared(
        url=sasy_url,
        ca_path=ca_path,
        cert_path=cert_path,
        key_path=key_path,
        auth_hook=auth_hook,
    )

    # Apply instrumentation-specific overrides
    if log_denials is not None:
        _config.log_denials = log_denials
    if log_policy_decisions is not None:
        _config.log_policy_decisions = log_policy_decisions
    if log_policy_decisions_transforms_only is not None:
        _config.log_policy_decisions_transforms_only = log_policy_decisions_transforms_only
    if log_transforms is not None:
        _config.log_transforms = log_transforms
    if feedback_callback is not None:
        _config.feedback_callback = feedback_callback
    if otel_enabled is not None:
        _config.otel_enabled = otel_enabled
    if otel_service_name is not None:
        _config.otel_service_name = otel_service_name
    if tool_policy_fail_closed is not None:
        _config.tool_policy_fail_closed = tool_policy_fail_closed

    return _config
