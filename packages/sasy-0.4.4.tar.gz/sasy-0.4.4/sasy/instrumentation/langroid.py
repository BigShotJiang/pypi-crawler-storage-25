"""
Observabilty instrumentation for Langroid, by wrapping
ChatAgent.llm_response and ChatAgent.llm_response_async.

Features:
    - Records messages as Event nodes in the observability graph
    - Creates DEPENDS_ON edges between messages
    - Creates OpenTelemetry spans for each responder and task
    - Links spans to messages via PRODUCES/CONSUMES edges
    - Accumulates authorization feedback per-responder scope

TODO:
    - handle LLMMessage contents being changed. Currently
    the implementation assumes that they are immutable, but
    this is not true, and Langroid in some cases will directly
    modify message contents. Treating messages as unique by
    (text, entity, agent) rather than ID would solve the problem
    but does not distinguish e.g. multiple generations of some text
    - detection of complex dependencies beyond those defined by
    agent responder signatures.
    - (potentially) update proximal dependencies when a ChatDocument's
    parent ID is set

All communication uses gRPC (including cloud deployments via
Fly.io h2_backend).
"""

import json
import logging
from functools import lru_cache
from typing import Literal, Optional, cast
from uuid import uuid4

from wrapt import wrap_function_wrapper  # type: ignore[import-untyped]
from opentelemetry.trace import StatusCode

from sasy.observability.api import (
    record_events,
    record_events_async,
    record_events_with_dependencies,
    record_events_with_dependencies_async,
)
from sasy.proto.observability_pb2 import Edge, Event, Role, Tool
from .feedback import (
    FeedbackScope,
    add_tool_denial,
)
from .config import get_config
from .otel import get_tracer
from .otel.context import (
    _current_input_ids,
    get_current_input_ids,
)

try:
    from pydantic import Extra
except ImportError:
    Extra = None  # type: ignore[misc,assignment]

from sasy.reference_monitor import (
    check_tool_call as rm_check_tool_call,
    check_tool_call_async as rm_check_tool_call_async,
)

logger = logging.getLogger(__name__)


@lru_cache
def instrument() -> None:
    """
    Observability instrumentation for Langroid.

    This function wraps Langroid agent methods to:
    1. Record messages and dependencies to the observability graph
    2. Create OpenTelemetry spans for each responder
    3. Link spans to messages via special attributes
    4. Accumulate authorization feedback per-responder scope

    OTel is automatically configured if not already done. Spans are exported
    to the observability server via the ObservabilitySpanExporter.
    """
    # Initialize OTel (configures if not already done)
    get_tracer("instrumentation.langroid")

    try:
        import langroid as lr
        from langroid import ChatAgent, ChatDocument
        from langroid.language_models import (
            LLMMessage,
        )
        from langroid.language_models import (
            Role as LRRole,
        )

        def translate_roles(role: LRRole | lr.Entity) -> Role:
            """Convert Langroid roles into proto Roles."""
            match role:
                case LRRole.SYSTEM | lr.Entity.SYSTEM:
                    return Role.SYSTEM
                case LRRole.ASSISTANT | lr.Entity.LLM:
                    return Role.LLM
                case LRRole.TOOL | LRRole.FUNCTION | lr.Entity.AGENT:
                    return Role.AGENT
                case LRRole.USER | lr.Entity.USER:
                    return Role.USER
                case _:
                    return Role.AGENT

        def get_id(msg: LLMMessage) -> Optional[str]:
            """
            Extract the ChatDocument ID from the message if
            it exists, or the saved observability ID otherwise.
            """
            if msg.chat_document_id:
                return msg.chat_document_id

            if hasattr(msg, "_observability_id") and (
                id := getattr(msg, "_observability_id")
            ):
                return cast(str, id)

            return None

        def get_name(msg: LLMMessage) -> Optional[str]:
            """Extracts the name of the sending agent if possible."""
            if not msg.chat_document_id:
                return None

            chat_doc = lr.ChatDocument.from_id(msg.chat_document_id)
            if not chat_doc:
                return None

            return chat_doc.metadata.sender_name

        def get_derived_from_tools(
            output: ChatDocument, input_doc: Optional[ChatDocument]
        ) -> list[Tool]:
            """
            Check if output is a tool result and extract the tools it was derived from.

            For tool results, returns the list of Tools that were called.
            For non-tool-result messages, returns an empty list.

            After agent_response, the input_doc.tool_messages field is populated
            with all tool calls (native, OAI, or function_call).
            """
            if output is None or input_doc is None:
                return []

            tools: list[Tool] = []

            # Check for OAI tool calls - match by ID or return all if no specific ID
            if input_doc.oai_tool_calls:
                if output.metadata.oai_tool_id:
                    # Find the specific matching tool call by ID
                    for tool_call in input_doc.oai_tool_calls:
                        if getattr(tool_call, "id", None) == output.metadata.oai_tool_id:
                            if tool_call.function is not None:
                                tools.append(Tool(
                                    name=tool_call.function.name,
                                    arguments=(
                                        json.dumps(tool_call.function.arguments)
                                        if tool_call.function.arguments
                                        else "{}"
                                    ),
                                ))
                            break
                else:
                    # No specific ID, return all tool calls
                    for tool_call in input_doc.oai_tool_calls:
                        if tool_call.function is not None:
                            tools.append(Tool(
                                name=tool_call.function.name,
                                arguments=(
                                    json.dumps(tool_call.function.arguments)
                                    if tool_call.function.arguments
                                    else "{}"
                                ),
                            ))
                if tools:
                    return tools

            # Get tool_messages from input - populated after agent_response
            # for all tool call patterns (native JSON, oai_tool_calls, function_call)
            input_tool_messages = getattr(input_doc, 'tool_messages', [])
            for tool_msg in input_tool_messages:
                tool_name = getattr(tool_msg, 'request', None) or type(tool_msg).__name__
                try:
                    args_dict = tool_msg.model_dump(exclude={'request'})
                    arguments = json.dumps(args_dict)
                except Exception:
                    arguments = "{}"
                tools.append(Tool(name=tool_name, arguments=arguments))

            return tools

        def get_tools(
            msg: LLMMessage | ChatDocument, agent: Optional[lr.Agent] = None
        ) -> list[Tool]:
            """Extracts the tools from a LLMMessage or a ChatDocument."""
            tools = []

            if msg.function_call is not None:
                tools.append(
                    Tool(
                        name=msg.function_call.name,
                        arguments=json.dumps(msg.function_call.arguments),
                    )
                )

            if isinstance(msg, LLMMessage):
                oai_tool_calls = msg.tool_calls
            else:
                oai_tool_calls = msg.oai_tool_calls

            if oai_tool_calls is not None:
                for oai_tool in oai_tool_calls:
                    if oai_tool.function is not None:
                        tools.append(
                            Tool(
                                name=oai_tool.function.name,
                                arguments=(
                                    (json.dumps(oai_tool.function.arguments))
                                    if oai_tool.function is not None
                                    else ""
                                ),
                            )
                        )

            if (
                agent is not None
                and isinstance(agent, lr.ChatAgent)
                and agent.config.use_tools
            ):
                json_tools = agent.get_formatted_tool_messages(msg.content)
                json_tools = [
                    t
                    for t in json_tools
                    if agent._tool_recipient_match(t) and t.default_value("request")
                ]

                for tool in json_tools:
                    tools.append(
                        Tool(
                            name=tool.default_value("request"),
                            arguments=json.dumps(tool.dict()),
                        )
                    )

            return tools

        def record_events_and_dependencies(
            message_history: list[Event], record_index: bool = True
        ) -> list[str]:
            """
            Record the provided events to the observability server
            and the dependencies assuming that all but the final message
            in message_history are the input messages (in order) sent to the LLM,
            and that the final message is the generate message.

            Uses the combined API for atomic registration when IDs are pre-set.
            """
            input_ids = [e.id for e in message_history[:-1] if e.id]
            output_id = message_history[-1].id
            dependencies = [
                Edge(
                    source=id,
                    destination=output_id,
                    message_index=i if record_index else None,
                    proximal=i == len(input_ids) - 1,
                )
                for i, id in enumerate(input_ids)
            ] if input_ids and output_id else []
            return record_events_with_dependencies(
                message_history, dependencies
            )

        async def record_events_and_dependencies_async(
            message_history: list[Event], record_index: bool = True
        ) -> list[str]:
            """Async version of record_events_and_dependencies."""
            input_ids = [e.id for e in message_history[:-1] if e.id]
            output_id = message_history[-1].id
            dependencies = [
                Edge(
                    source=id,
                    destination=output_id,
                    message_index=i if record_index else None,
                    proximal=i == len(input_ids) - 1,
                )
                for i, id in enumerate(input_ids)
            ] if input_ids and output_id else []
            return await record_events_with_dependencies_async(
                message_history, dependencies
            )

        # Currently wraps ChatAgent methods as wrapping LLM methods would
        # require ID propagation (and modification of the corresponding
        # message classes to support propagation of the information).
        # That method would also fail to identify the agent associated with
        # certain messages (e.g. the system message) which do not correspond
        # to ChatDocuments. Currently these will be duplicated in the graph.
        # This can be avoided by the same method of allowing extra fields to
        # persist the IDs. Assumes llm_response is not overridden.
        def wrapper_agent_responder(
            responder: Literal["llm", "agent", "user"], sync: bool, chat: bool
        ):
            """Generates the patched responder methods for observability."""
            match responder:
                case "llm":
                    out_role = Role.LLM
                case "agent":
                    out_role = Role.AGENT
                case "user":
                    out_role = Role.USER

            if sync:
                def wrapper(wrapped, instance: lr.Agent, args, kwargs):
                    # Extract the message argument from the responder call
                    message = None
                    if args:
                        message = args[0]
                    elif "message" in kwargs:
                        message = kwargs["message"]
                    elif "msg" in kwargs:
                        message = kwargs["msg"]

                    # Get input messages BEFORE calling the responder
                    # This allows input IDs to be available during execution
                    if responder == "llm" and chat:
                        # For chat LLM, use current message history
                        pre_messages = list(instance.message_history)  # type: ignore
                    elif message is not None:
                        pre_messages = ChatDocument.to_LLMMessage(message)
                    else:
                        pre_messages = []

                    # Assign observability IDs to messages without any ID
                    # (e.g. system prompt on first call)
                    for msg in pre_messages:
                        if not get_id(msg):
                            setattr(msg, "_observability_id", str(uuid4()))

                    # Collect input message IDs before execution (filter out None values)
                    input_ids = [id for msg in pre_messages if (id := get_id(msg))]

                    # Create span name
                    agent_name = getattr(instance.config, "name", "unknown")
                    span_name = f"langroid.{responder}_response"

                    with get_tracer("instrumentation.langroid").start_as_current_span(span_name) as span:
                        # Set attributes BEFORE execution so they're available
                        span.set_attribute("agent.name", agent_name)
                        span.set_attribute("responder.type", responder)
                        span.set_attribute("responder.chat", chat)
                        if input_ids:
                            span.set_attribute(
                                "_input_message_ids", ",".join(input_ids)
                            )
                            # Propagate input IDs to nested calls via ContextVar
                            token = _current_input_ids.set(input_ids)
                        else:
                            token = None

                        try:
                            try:
                                # Pre-record input events so they exist in Neo4j
                                # before HTTP interception fires during execution.
                                if input_ids:
                                    pre_events = [
                                        Event(
                                            text=msg.content,
                                            role=translate_roles(msg.role),
                                            agent=get_name(msg) or agent_name,
                                            tools=get_tools(msg),
                                            id=get_id(msg),
                                        )
                                        for msg in pre_messages
                                        if get_id(msg)
                                    ]
                                    if pre_events:
                                        record_events(pre_events)

                                # FeedbackScope accumulates auth feedback during execution
                                with FeedbackScope(agent_name, responder) as feedback_scope:
                                    output: Optional[ChatDocument] = wrapped(*args, **kwargs)
                                # Process feedback after execution (callback can modify output)
                                feedback_scope.process(output, instance)
                            except Exception as e:
                                # Record exception on span and set error status
                                span.record_exception(e)
                                span.set_status(StatusCode.ERROR, str(e))
                                raise

                            # Get final messages after execution
                            if responder == "llm" and chat:
                                messages = instance.message_history  # type: ignore
                            else:
                                messages = pre_messages

                            if output and messages:
                                history = [
                                    Event(
                                        text=msg.content,
                                        role=translate_roles(msg.role),
                                        agent=get_name(msg) or instance.config.name,
                                        tools=get_tools(msg, instance),
                                        id=get_id(msg),
                                    )
                                    for msg in messages
                                ]

                                # Add event for generated response
                                if not chat:
                                    # For agent/user responders, check if output is a tool result
                                    # First try the direct message
                                    input_doc = (
                                        message
                                        if isinstance(message, ChatDocument)
                                        else None
                                    )
                                    derived_from_tools = get_derived_from_tools(output, input_doc)
                                    # Proto only supports single derived_from, use first if available
                                    derived_from = derived_from_tools[0] if derived_from_tools else None

                                    history.append(
                                        Event(
                                            text=output.content,
                                            role=out_role,
                                            agent=instance.config.name,
                                            tools=get_tools(output, instance),
                                            id=output.metadata.id,
                                            derived_from=derived_from,
                                        )
                                    )

                                # Record events and dependencies
                                ids = record_events_and_dependencies(
                                    history, record_index=responder == "llm" and chat
                                )

                                # Set output message ID on span
                                if ids:
                                    span.set_attribute("_output_message_id", ids[-1])

                                # Persist observability IDs for all responders
                                for id, msg in zip(ids, messages):
                                    if not hasattr(msg, "_observability_id"):
                                        setattr(msg, "_observability_id", id)

                            span.set_status(StatusCode.OK)
                            return output
                        finally:
                            # Reset ContextVar to previous value
                            if token is not None:
                                _current_input_ids.reset(token)

            else:
                async def wrapper(wrapped, instance: lr.Agent, args, kwargs):  # type: ignore[misc]
                    # Extract the message argument from the responder call
                    message = None
                    if args:
                        message = args[0]
                    elif "message" in kwargs:
                        message = kwargs["message"]
                    elif "msg" in kwargs:
                        message = kwargs["msg"]

                    # Get input messages BEFORE calling the responder
                    if responder == "llm" and chat:
                        pre_messages = list(instance.message_history)  # type: ignore
                    elif message is not None:
                        pre_messages = ChatDocument.to_LLMMessage(message)
                    else:
                        pre_messages = []

                    # Assign observability IDs to messages without any ID
                    # (e.g. system prompt on first call)
                    for msg in pre_messages:
                        if not get_id(msg):
                            setattr(msg, "_observability_id", str(uuid4()))

                    # Collect input message IDs before execution (filter out None values)
                    input_ids = [id for msg in pre_messages if (id := get_id(msg))]

                    # Create span name
                    agent_name = getattr(instance.config, "name", "unknown")
                    span_name = f"langroid.{responder}_response"

                    with get_tracer("instrumentation.langroid").start_as_current_span(span_name) as span:
                        # Set attributes BEFORE execution
                        span.set_attribute("agent.name", agent_name)
                        span.set_attribute("responder.type", responder)
                        span.set_attribute("responder.chat", chat)
                        if input_ids:
                            span.set_attribute(
                                "_input_message_ids", ",".join(input_ids)
                            )
                            # Propagate input IDs to nested calls via ContextVar
                            token = _current_input_ids.set(input_ids)
                        else:
                            token = None

                        try:
                            try:
                                # Pre-record input events so they exist in Neo4j
                                # before HTTP interception fires during execution.
                                if input_ids:
                                    pre_events = [
                                        Event(
                                            text=msg.content,
                                            role=translate_roles(msg.role),
                                            agent=get_name(msg) or agent_name,
                                            tools=get_tools(msg),
                                            id=get_id(msg),
                                        )
                                        for msg in pre_messages
                                        if get_id(msg)
                                    ]
                                    if pre_events:
                                        await record_events_async(pre_events)

                                # FeedbackScope accumulates auth feedback during execution
                                with FeedbackScope(agent_name, responder) as feedback_scope:
                                    output: Optional[ChatDocument] = await wrapped(
                                        *args, **kwargs
                                    )
                                # Process feedback after execution (callback can modify output)
                                feedback_scope.process(output, instance)
                            except Exception as e:
                                # Record exception on span and set error status
                                span.record_exception(e)
                                span.set_status(StatusCode.ERROR, str(e))
                                raise

                            # Get final messages after execution
                            if responder == "llm" and chat:
                                messages = instance.message_history  # type: ignore
                            else:
                                messages = pre_messages

                            if output and messages:
                                history = [
                                    Event(
                                        text=msg.content,
                                        role=translate_roles(msg.role),
                                        agent=get_name(msg) or instance.config.name,
                                        tools=get_tools(msg, instance),
                                        id=get_id(msg),
                                    )
                                    for msg in messages
                                ]

                                # Add event for generated response
                                if not chat:
                                    # For agent/user responders, check if output is a tool result
                                    input_doc = (
                                        message
                                        if isinstance(message, ChatDocument)
                                        else None
                                    )
                                    derived_from_tools = get_derived_from_tools(output, input_doc)
                                    # Proto only supports single derived_from, use first if available
                                    derived_from = derived_from_tools[0] if derived_from_tools else None

                                    history.append(
                                        Event(
                                            text=output.content,
                                            role=out_role,
                                            agent=instance.config.name,
                                            tools=get_tools(output, instance),
                                            id=output.metadata.id,
                                            derived_from=derived_from,
                                        )
                                    )

                                # Record events and dependencies
                                ids = await record_events_and_dependencies_async(
                                    history, record_index=responder == "llm" and chat
                                )

                                # Set output message ID on span
                                if ids:
                                    span.set_attribute("_output_message_id", ids[-1])

                                # Persist observability IDs for all responders
                                for id, msg in zip(ids, messages):
                                    if not hasattr(msg, "_observability_id"):
                                        setattr(msg, "_observability_id", id)

                            span.set_status(StatusCode.OK)
                            return output
                        finally:
                            # Reset ContextVar to previous value
                            if token is not None:
                                _current_input_ids.reset(token)

            return wrapper

        def allow_extras_wrapper(wrapped, instance, args, kwargs):
            """Ensure that we can store additional metadata in LLMMessages."""
            wrapped(*args, **kwargs)
            if hasattr(instance, "model_config"):
                instance.model_config["extra"] = "allow"
            elif Extra is not None:
                # Fallback for Pydantic v1
                instance.__config__.extra = Extra.allow

        wrap_function_wrapper(
            "langroid.language_models.base",
            "LLMMessage.__init__",
            allow_extras_wrapper,
        )

        def persist_system_id_wrapper(wrapped, instance: ChatAgent, args, kwargs):
            """
            Ensures that Langroid's system prompt generation does not result
            in the observablity server as treating identical re-generated
            system messages as distinct.
            """
            id = None
            content = None
            # Get the system message's observability ID if it exists
            if instance.message_history:
                system_message = instance.message_history[0]
                if hasattr(system_message, "_observability_id"):
                    id = getattr(system_message, "_observability_id")
                    content = system_message.content

            new_message = wrapped(*args, **kwargs)
            # If there was an existing system message with an
            # observability ID, retain it
            if (
                id is not None
                and content is not None
                and new_message.content == content
            ):
                setattr(new_message, "_observability_id", id)

            return new_message

        wrap_function_wrapper(
            module="langroid.agent.chat_agent",
            name="ChatAgent._create_system_and_tools_message",
            wrapper=persist_system_id_wrapper,
        )

        for method in ["llm_response", "llm_response_async"]:
            for module, class_name in zip(
                ["base", "chat_agent"], ["Agent", "ChatAgent"]
            ):
                wrap_function_wrapper(
                    module=f"langroid.agent.{module}",
                    name=f"{class_name}.{method}",
                    wrapper=wrapper_agent_responder(
                        responder="llm",
                        chat=module == "chat_agent",
                        sync="async" not in method,
                    ),
                )

        for responder in ["user", "agent"]:
            for is_async in [True, False]:
                method = f"{responder}_response"
                if is_async:
                    method += "_async"

                wrap_function_wrapper(
                    module="langroid.agent.base",
                    name=f"Agent.{method}",
                    wrapper=wrapper_agent_responder(
                        responder=responder,  # type: ignore
                        chat=False,
                        sync=not is_async,
                    ),
                )

        def wrap_task_init(wrapped, instance: lr.Task, args, kwargs):
            """
            Ensure that messages sent to an agent to an agent in a
            to a child task have dependencies preserved.
            """
            message = None
            if args:
                message = args[0]
            elif "message" in kwargs:
                message = kwargs["msg"]

            # Collect input IDs for span
            input_id = None
            if message and isinstance(message, lr.ChatDocument):
                input_id = message.metadata.id

            task_name = getattr(instance, "name", "unknown")
            agent_name = getattr(instance.agent.config, "name", "unknown")
            span_name = "langroid.task.init"

            with get_tracer("instrumentation.langroid").start_as_current_span(span_name) as span:
                span.set_attribute("task.name", task_name)
                span.set_attribute("agent.name", agent_name)
                if input_id:
                    span.set_attribute("_input_message_ids", input_id)
                    # Propagate input ID to nested calls via ContextVar
                    token = _current_input_ids.set([input_id])
                else:
                    token = None

                try:
                    out = wrapped(*args, **kwargs)
                    pending_message = out or instance.pending_message

                    if (
                        message
                        and isinstance(message, lr.ChatDocument)
                        and pending_message
                        and isinstance(pending_message, lr.ChatDocument)
                    ):
                        # Set output message ID on span
                        span.set_attribute(
                            "_output_message_id", pending_message.metadata.id
                        )

                        # Record events and dependencies
                        pending_event = Event(
                            text=pending_message.content,
                            role=Role.USER,
                            agent=instance.agent.config.name,
                            id=pending_message.metadata.id,
                        )
                        message_event = Event(
                            text=message.content,
                            role=translate_roles(message.metadata.sender),
                            agent=message.metadata.sender_name,
                            tools=get_tools(message),
                            id=message.metadata.id,
                        )
                        if message.metadata.id and pending_message.metadata.id:
                            edge = Edge(
                                source=message.metadata.id,
                                destination=pending_message.metadata.id,
                                proximal=True,
                            )
                            record_events_with_dependencies(
                                [message_event, pending_event], [edge]
                            )
                        else:
                            record_events([message_event, pending_event])

                    return out
                finally:
                    # Reset ContextVar to previous value
                    if token is not None:
                        _current_input_ids.reset(token)

        wrap_function_wrapper(
            module="langroid.agent.task",
            name="Task.init",
            wrapper=wrap_task_init,
        )

        def wrap_task_result(wrapped, instance: lr.Task, args, kwargs):
            """
            Ensure that messages produced by a task depend on the
            internal messages produced by the task's responders.
            """
            task_name = getattr(instance, "name", "unknown")
            agent_name = getattr(instance.agent.config, "name", "unknown")
            span_name = "langroid.task.result"

            # Get pending message ID for input
            pending_message = instance.pending_message
            input_id = None
            if pending_message and isinstance(pending_message, lr.ChatDocument):
                input_id = pending_message.metadata.id

            with get_tracer("instrumentation.langroid").start_as_current_span(span_name) as span:
                span.set_attribute("task.name", task_name)
                span.set_attribute("agent.name", agent_name)
                if input_id:
                    span.set_attribute("_input_message_ids", input_id)
                    # Propagate input ID to nested calls via ContextVar
                    token = _current_input_ids.set([input_id])
                else:
                    token = None

                try:
                    out = wrapped(*args, **kwargs)
                    pending_message = instance.pending_message

                    if (
                        out
                        and isinstance(out, lr.ChatDocument)
                        and pending_message
                        and isinstance(pending_message, lr.ChatDocument)
                    ):
                        # Set output message ID on span
                        span.set_attribute("_output_message_id", out.metadata.id)

                        out_event = Event(
                            text=out.content,
                            role=translate_roles(out.metadata.sender),
                            agent=out.metadata.sender_name,
                            tools=get_tools(out),
                            id=out.metadata.id,
                        )
                        pending_event = Event(
                            text=pending_message.content,
                            role=translate_roles(pending_message.metadata.sender),
                            agent=pending_message.metadata.sender_name,
                            tools=get_tools(pending_message),
                            id=pending_message.metadata.id,
                        )
                        if pending_message.metadata.id and out.metadata.id:
                            edge = Edge(
                                source=pending_message.metadata.id,
                                destination=out.metadata.id,
                                proximal=True,
                            )
                            record_events_with_dependencies(
                                [out_event, pending_event], [edge]
                            )
                        else:
                            record_events([out_event, pending_event])

                    return out
                finally:
                    # Reset ContextVar to previous value
                    if token is not None:
                        _current_input_ids.reset(token)

        wrap_function_wrapper(
            module="langroid.agent.task",
            name="Task.result",
            wrapper=wrap_task_result,
        )

        # Tool call policy enforcement wrappers
        def _extract_denial_message(response) -> str:
            """Extract denial message from ToolCallResponse, including all reasons."""
            if response.denial_trace:
                msg = response.denial_trace.action_description
                if response.denial_trace.reasons:
                    # Include all reasons with their details
                    reason_parts = [
                        r.details if r.details else str(r.reason_type)
                        for r in response.denial_trace.reasons
                    ]
                    msg += ": " + "; ".join(reason_parts)
                return msg
            return "Tool call not authorized"

        def _extract_suggestions(response) -> list[str]:
            """Extract all suggestions from ToolCallResponse."""
            if response.denial_trace and response.denial_trace.suggested_fixes:
                return list(response.denial_trace.suggested_fixes)
            return []

        def _log_tool_denial(fn_name: str, message: str, suggestions: list[str]) -> None:
            """Print a colored denial line with message and suggestion."""
            # Strip redundant "Tool call: <name>: " prefix from message
            prefix = f"Tool call: {fn_name}: "
            reason = message[len(prefix):] if message.startswith(prefix) else message
            line = f"\033[91m\033[1m[POLICY] DENIED {fn_name} - {reason}\033[0m"
            print(line)
            for s in suggestions:
                print(f"\033[93m[POLICY]   Suggestion: {s}\033[0m")

        def _format_denial(fn_name: str, message: str, suggestions: list[str]) -> str:
            """Format a denial message string."""
            denial_msg = f"[BLOCKED] {fn_name}: {message}"
            if suggestions:
                if len(suggestions) == 1:
                    denial_msg += f"\nRequired action: {suggestions[0]}"
                else:
                    denial_msg += "\nRequired actions:\n" + "\n".join(f"  - {s}" for s in suggestions)
            return denial_msg

        def wrap_handle_tool_message(wrapped, instance, args, kwargs):
            """
            Check tool call authorization before executing the handler.

            If denied with deny_if_unauthorized=True, returns denial message
            instead of executing the tool.
            """
            tool = args[0] if args else kwargs.get("tool")
            if tool is None:
                return wrapped(*args, **kwargs)

            fn_name = tool.default_value("request")
            try:
                fn_args = json.dumps(tool.dict())
            except Exception:
                fn_args = str(tool)

            input_ids = get_current_input_ids()
            config = get_config()

            try:
                response = rm_check_tool_call(fn_name, fn_args, input_ids)
                if not response.authorized:
                    message = _extract_denial_message(response)
                    suggestions = _extract_suggestions(response)
                    add_tool_denial(fn_name, message, fn_args, suggestions)
                    if config.log_policy_decisions:
                        _log_tool_denial(fn_name, message, suggestions)
                    logger.warning(f"Tool call denied: {fn_name} - {message}")
                    return _format_denial(fn_name, message, suggestions)
                elif config.log_policy_decisions:
                    print(
                        f"\033[92m\033[1m[POLICY] AUTHORIZED {fn_name}\033[0m"
                    )

            except Exception as e:
                if config.tool_policy_fail_closed:
                    logger.warning(f"Tool call denied (RM unavailable, fail_closed=True): {fn_name} - {e}")
                    add_tool_denial(fn_name, "Reference monitor unavailable", fn_args, [])
                    return f"[BLOCKED] {fn_name}: Reference monitor unavailable"
                else:
                    logger.debug(f"Tool policy check failed (passthrough): {e}")

            return wrapped(*args, **kwargs)

        async def wrap_handle_tool_message_async(wrapped, instance, args, kwargs):
            """Async version of tool call authorization wrapper."""
            tool = args[0] if args else kwargs.get("tool")
            if tool is None:
                return await wrapped(*args, **kwargs)

            fn_name = tool.default_value("request")
            try:
                fn_args = json.dumps(tool.dict())
            except Exception:
                fn_args = str(tool)

            input_ids = get_current_input_ids()
            config = get_config()

            try:
                response = await rm_check_tool_call_async(fn_name, fn_args, input_ids)
                if not response.authorized:
                    message = _extract_denial_message(response)
                    suggestions = _extract_suggestions(response)
                    add_tool_denial(fn_name, message, fn_args, suggestions)
                    if config.log_policy_decisions:
                        _log_tool_denial(fn_name, message, suggestions)
                    logger.warning(f"Tool call denied: {fn_name} - {message}")
                    return _format_denial(fn_name, message, suggestions)
                elif config.log_policy_decisions:
                    print(
                        f"\033[92m\033[1m[POLICY] AUTHORIZED {fn_name}\033[0m"
                    )

            except Exception as e:
                if config.tool_policy_fail_closed:
                    logger.warning(f"Tool call denied (RM unavailable, fail_closed=True): {fn_name} - {e}")
                    add_tool_denial(fn_name, "Reference monitor unavailable", fn_args, [])
                    return f"[BLOCKED] {fn_name}: Reference monitor unavailable"
                else:
                    logger.debug(f"Tool policy check failed (passthrough): {e}")

            return await wrapped(*args, **kwargs)

        wrap_function_wrapper(
            module="langroid.agent.base",
            name="Agent.handle_tool_message",
            wrapper=wrap_handle_tool_message,
        )

        wrap_function_wrapper(
            module="langroid.agent.base",
            name="Agent.handle_tool_message_async",
            wrapper=wrap_handle_tool_message_async,
        )

    except ImportError:
        pass
