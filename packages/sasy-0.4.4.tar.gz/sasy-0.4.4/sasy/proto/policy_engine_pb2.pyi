from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DenialReasonType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DENIAL_REASON_UNSPECIFIED: _ClassVar[DenialReasonType]
    NOT_AUTHENTICATED: _ClassVar[DenialReasonType]
    DENYLISTED: _ClassVar[DenialReasonType]
    NOT_ALLOWLISTED: _ClassVar[DenialReasonType]
    SYNC_TIMEOUT: _ClassVar[DenialReasonType]
DENIAL_REASON_UNSPECIFIED: DenialReasonType
NOT_AUTHENTICATED: DenialReasonType
DENYLISTED: DenialReasonType
NOT_ALLOWLISTED: DenialReasonType
SYNC_TIMEOUT: DenialReasonType

class AuthorizationRequest(_message.Message):
    __slots__ = ("current_node_ids", "actions", "entity", "roles", "tenant_id")
    CURRENT_NODE_IDS_FIELD_NUMBER: _ClassVar[int]
    ACTIONS_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    TENANT_ID_FIELD_NUMBER: _ClassVar[int]
    current_node_ids: _containers.RepeatedScalarFieldContainer[str]
    actions: _containers.RepeatedCompositeFieldContainer[Action]
    entity: str
    roles: _containers.RepeatedScalarFieldContainer[str]
    tenant_id: str
    def __init__(self, current_node_ids: _Optional[_Iterable[str]] = ..., actions: _Optional[_Iterable[_Union[Action, _Mapping]]] = ..., entity: _Optional[str] = ..., roles: _Optional[_Iterable[str]] = ..., tenant_id: _Optional[str] = ...) -> None: ...

class Action(_message.Message):
    __slots__ = ("http_request", "tool_call", "send_message")
    HTTP_REQUEST_FIELD_NUMBER: _ClassVar[int]
    TOOL_CALL_FIELD_NUMBER: _ClassVar[int]
    SEND_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    http_request: HttpRequestAction
    tool_call: ToolCallAction
    send_message: SendMessageAction
    def __init__(self, http_request: _Optional[_Union[HttpRequestAction, _Mapping]] = ..., tool_call: _Optional[_Union[ToolCallAction, _Mapping]] = ..., send_message: _Optional[_Union[SendMessageAction, _Mapping]] = ...) -> None: ...

class HttpRequestAction(_message.Message):
    __slots__ = ("url", "body", "headers")
    URL_FIELD_NUMBER: _ClassVar[int]
    BODY_FIELD_NUMBER: _ClassVar[int]
    HEADERS_FIELD_NUMBER: _ClassVar[int]
    url: str
    body: str
    headers: _containers.RepeatedCompositeFieldContainer[Header]
    def __init__(self, url: _Optional[str] = ..., body: _Optional[str] = ..., headers: _Optional[_Iterable[_Union[Header, _Mapping]]] = ...) -> None: ...

class Header(_message.Message):
    __slots__ = ("key", "value")
    KEY_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    key: str
    value: str
    def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...

class ToolCallAction(_message.Message):
    __slots__ = ("fn_name", "args")
    FN_NAME_FIELD_NUMBER: _ClassVar[int]
    ARGS_FIELD_NUMBER: _ClassVar[int]
    fn_name: str
    args: str
    def __init__(self, fn_name: _Optional[str] = ..., args: _Optional[str] = ...) -> None: ...

class SendMessageAction(_message.Message):
    __slots__ = ("content", "agent", "agent_role", "tool_calls", "entity")
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_FIELD_NUMBER: _ClassVar[int]
    AGENT_ROLE_FIELD_NUMBER: _ClassVar[int]
    TOOL_CALLS_FIELD_NUMBER: _ClassVar[int]
    ENTITY_FIELD_NUMBER: _ClassVar[int]
    content: str
    agent: str
    agent_role: str
    tool_calls: _containers.RepeatedCompositeFieldContainer[ToolCall]
    entity: str
    def __init__(self, content: _Optional[str] = ..., agent: _Optional[str] = ..., agent_role: _Optional[str] = ..., tool_calls: _Optional[_Iterable[_Union[ToolCall, _Mapping]]] = ..., entity: _Optional[str] = ...) -> None: ...

class ToolCall(_message.Message):
    __slots__ = ("fn_name", "args")
    FN_NAME_FIELD_NUMBER: _ClassVar[int]
    ARGS_FIELD_NUMBER: _ClassVar[int]
    fn_name: str
    args: str
    def __init__(self, fn_name: _Optional[str] = ..., args: _Optional[str] = ...) -> None: ...

class AuthorizationResponse(_message.Message):
    __slots__ = ("results", "timing")
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    TIMING_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ActionResult]
    timing: PerformanceTiming
    def __init__(self, results: _Optional[_Iterable[_Union[ActionResult, _Mapping]]] = ..., timing: _Optional[_Union[PerformanceTiming, _Mapping]] = ...) -> None: ...

class PerformanceTiming(_message.Message):
    __slots__ = ("total_us", "sync_wait_us", "eval_us", "backend", "graph_nodes", "graph_edges")
    TOTAL_US_FIELD_NUMBER: _ClassVar[int]
    SYNC_WAIT_US_FIELD_NUMBER: _ClassVar[int]
    EVAL_US_FIELD_NUMBER: _ClassVar[int]
    BACKEND_FIELD_NUMBER: _ClassVar[int]
    GRAPH_NODES_FIELD_NUMBER: _ClassVar[int]
    GRAPH_EDGES_FIELD_NUMBER: _ClassVar[int]
    total_us: int
    sync_wait_us: int
    eval_us: int
    backend: str
    graph_nodes: int
    graph_edges: int
    def __init__(self, total_us: _Optional[int] = ..., sync_wait_us: _Optional[int] = ..., eval_us: _Optional[int] = ..., backend: _Optional[str] = ..., graph_nodes: _Optional[int] = ..., graph_edges: _Optional[int] = ...) -> None: ...

class ActionResult(_message.Message):
    __slots__ = ("index", "authorized", "trace", "transform_ids", "deny_if_unauthorized")
    INDEX_FIELD_NUMBER: _ClassVar[int]
    AUTHORIZED_FIELD_NUMBER: _ClassVar[int]
    TRACE_FIELD_NUMBER: _ClassVar[int]
    TRANSFORM_IDS_FIELD_NUMBER: _ClassVar[int]
    DENY_IF_UNAUTHORIZED_FIELD_NUMBER: _ClassVar[int]
    index: int
    authorized: bool
    trace: DenialTrace
    transform_ids: _containers.RepeatedScalarFieldContainer[str]
    deny_if_unauthorized: bool
    def __init__(self, index: _Optional[int] = ..., authorized: bool = ..., trace: _Optional[_Union[DenialTrace, _Mapping]] = ..., transform_ids: _Optional[_Iterable[str]] = ..., deny_if_unauthorized: bool = ...) -> None: ...

class DenialTrace(_message.Message):
    __slots__ = ("action_description", "reasons", "suggested_fixes")
    ACTION_DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REASONS_FIELD_NUMBER: _ClassVar[int]
    SUGGESTED_FIXES_FIELD_NUMBER: _ClassVar[int]
    action_description: str
    reasons: _containers.RepeatedCompositeFieldContainer[DenialReason]
    suggested_fixes: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, action_description: _Optional[str] = ..., reasons: _Optional[_Iterable[_Union[DenialReason, _Mapping]]] = ..., suggested_fixes: _Optional[_Iterable[str]] = ...) -> None: ...

class DenialReason(_message.Message):
    __slots__ = ("reason_type", "details", "source_location")
    REASON_TYPE_FIELD_NUMBER: _ClassVar[int]
    DETAILS_FIELD_NUMBER: _ClassVar[int]
    SOURCE_LOCATION_FIELD_NUMBER: _ClassVar[int]
    reason_type: DenialReasonType
    details: str
    source_location: str
    def __init__(self, reason_type: _Optional[_Union[DenialReasonType, str]] = ..., details: _Optional[str] = ..., source_location: _Optional[str] = ...) -> None: ...

class SyncStatusRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SyncStatusResponse(_message.Message):
    __slots__ = ("current_sequence", "node_count", "edge_count", "connected")
    CURRENT_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    NODE_COUNT_FIELD_NUMBER: _ClassVar[int]
    EDGE_COUNT_FIELD_NUMBER: _ClassVar[int]
    CONNECTED_FIELD_NUMBER: _ClassVar[int]
    current_sequence: int
    node_count: int
    edge_count: int
    connected: bool
    def __init__(self, current_sequence: _Optional[int] = ..., node_count: _Optional[int] = ..., edge_count: _Optional[int] = ..., connected: bool = ...) -> None: ...

class HealthRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class HealthResponse(_message.Message):
    __slots__ = ("healthy", "message")
    HEALTHY_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    healthy: bool
    message: str
    def __init__(self, healthy: bool = ..., message: _Optional[str] = ...) -> None: ...

class UploadPolicyRequest(_message.Message):
    __slots__ = ("policy_source", "backend", "hot_reload", "functor_source")
    POLICY_SOURCE_FIELD_NUMBER: _ClassVar[int]
    BACKEND_FIELD_NUMBER: _ClassVar[int]
    HOT_RELOAD_FIELD_NUMBER: _ClassVar[int]
    FUNCTOR_SOURCE_FIELD_NUMBER: _ClassVar[int]
    policy_source: str
    backend: str
    hot_reload: bool
    functor_source: str
    def __init__(self, policy_source: _Optional[str] = ..., backend: _Optional[str] = ..., hot_reload: bool = ..., functor_source: _Optional[str] = ...) -> None: ...

class UploadPolicyResponse(_message.Message):
    __slots__ = ("accepted", "message", "error_output")
    ACCEPTED_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ERROR_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    accepted: bool
    message: str
    error_output: str
    def __init__(self, accepted: bool = ..., message: _Optional[str] = ..., error_output: _Optional[str] = ...) -> None: ...

class EvaluatorStatusRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class EvaluatorStatusResponse(_message.Message):
    __slots__ = ("backend", "alive", "policy_path")
    BACKEND_FIELD_NUMBER: _ClassVar[int]
    ALIVE_FIELD_NUMBER: _ClassVar[int]
    POLICY_PATH_FIELD_NUMBER: _ClassVar[int]
    backend: str
    alive: bool
    policy_path: str
    def __init__(self, backend: _Optional[str] = ..., alive: bool = ..., policy_path: _Optional[str] = ...) -> None: ...

class ValidatePolicyRequest(_message.Message):
    __slots__ = ("policy_source",)
    POLICY_SOURCE_FIELD_NUMBER: _ClassVar[int]
    policy_source: str
    def __init__(self, policy_source: _Optional[str] = ...) -> None: ...

class ValidatePolicyResponse(_message.Message):
    __slots__ = ("valid", "error_output", "desugared_source")
    VALID_FIELD_NUMBER: _ClassVar[int]
    ERROR_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    DESUGARED_SOURCE_FIELD_NUMBER: _ClassVar[int]
    valid: bool
    error_output: str
    desugared_source: str
    def __init__(self, valid: bool = ..., error_output: _Optional[str] = ..., desugared_source: _Optional[str] = ...) -> None: ...
