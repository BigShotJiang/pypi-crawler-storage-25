"""Translate a natural-language policy + codebase into Souffle Datalog.

Client for the sasy-translate REST service. Uploads the English spec,
optional instructions, and an optional codebase archive, polls until
the two-stage translation pipeline completes, and returns the
generated policy + companion C++ functors.
"""

from __future__ import annotations

import io
import logging
import os
import tarfile
import time
import zipfile
from pathlib import Path
from typing import Callable, Iterable, Optional

import httpx
from pydantic import BaseModel

from sasy.config import get_config

logger = logging.getLogger(__name__)


# ── Response models ───────────────────────────────


class ValidationResult(BaseModel):
    ok: bool
    lint_errors: list[str] = []
    souffle_stdout: str = ""
    souffle_stderr: str = ""


class TranslateResult(BaseModel):
    """Result of translating a natural-language policy + codebase to Datalog."""

    status: str  # "success" | "failure"
    policy_dl: Optional[str] = None
    functors_cpp: Optional[str] = None
    agent_summary_md: Optional[str] = None
    validation: Optional[ValidationResult] = None
    errors: list[str] = []
    request_id: str = ""
    duration_seconds: Optional[float] = None
    cost_usd: Optional[float] = None

    def save_policy(self, path: str | Path) -> Path:
        """Save the generated Datalog policy to disk."""
        if not self.policy_dl:
            raise ValueError("No policy available (translation may have failed)")
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(self.policy_dl)
        return p

    def save_functors(self, path: str | Path) -> Optional[Path]:
        """Save the companion C++ functors file, if one was generated."""
        if not self.functors_cpp:
            return None
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(self.functors_cpp)
        return p

    def save_summary(self, path: str | Path) -> Optional[Path]:
        """Save the agent analysis summary, if available."""
        if not self.agent_summary_md:
            return None
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(self.agent_summary_md)
        return p

    def save_all(self, output_dir: str | Path, base_name: str = "airline") -> dict[str, Path]:
        """Save all artifacts under output_dir with consistent naming.

        Policy file is named ``<base_name>_policy.dl`` and the
        functors file is named ``<base_name>_functors.cpp`` so the
        sasy compiler's ``find_functors()`` auto-discovery works.
        """
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        saved: dict[str, Path] = {}
        if self.policy_dl:
            saved["policy"] = self.save_policy(out / f"{base_name}_policy.dl")
        if self.functors_cpp:
            f = self.save_functors(out / f"{base_name}_functors.cpp")
            if f is not None:
                saved["functors"] = f
        if self.agent_summary_md:
            s = self.save_summary(out / "agent_summary.md")
            if s is not None:
                saved["summary"] = s
        return saved

    def print_summary(self) -> None:
        dur = f" ({self.duration_seconds:.0f}s)" if self.duration_seconds else ""
        cost = f" cost=${self.cost_usd:.3f}" if self.cost_usd else ""
        lines = [
            "Policy Translation Result",
            "=" * 40,
            f"Status: {self.status.upper()}{dur}{cost}",
        ]
        if self.policy_dl:
            lines.append(f"Policy: {len(self.policy_dl):,} chars")
            n_unauth = self.policy_dl.count("Unauthorized")
            lines.append(f"  Unauthorized references: {n_unauth}")
        if self.functors_cpp:
            lines.append(f"Functors: {len(self.functors_cpp):,} chars")
        if self.validation is not None:
            mark = "OK" if self.validation.ok else "FAIL"
            lines.append(f"Validation: {mark}")
            for e in self.validation.lint_errors[:5]:
                lines.append(f"  - {e}")
        if self.errors:
            lines.append("Errors:")
            for e in self.errors:
                lines.append(f"  - {e}")
        print("\n".join(lines))


# ── Codebase packing helpers ──────────────────────


def _zip_paths(paths: Iterable[Path], base: Path) -> bytes:
    """Zip up the given paths into an in-memory buffer.

    Each path is stored relative to `base` (so callers pass their
    repo root as `base` and the zip preserves the repo-relative layout
    the translator expects).
    """
    base = Path(base).resolve()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in paths:
            p = Path(p).resolve()
            if not p.exists():
                raise FileNotFoundError(p)
            if p.is_file():
                zf.write(p, p.relative_to(base).as_posix())
            else:
                for sub in p.rglob("*"):
                    if sub.is_file() and "__pycache__" not in sub.parts \
                            and "node_modules" not in sub.parts \
                            and ".venv" not in sub.parts:
                        zf.write(sub, sub.relative_to(base).as_posix())
    return buf.getvalue()


# ── Main SDK function ─────────────────────────────


ProgressCallback = Callable[[str, float], None]


def translate(
    policy: str,
    *,
    codebase_paths: Optional[Iterable[str | Path]] = None,
    codebase_archive: Optional[str | Path] = None,
    codebase_root: Optional[str | Path] = None,
    instructions: str = "",
    model: str = "sonnet",
    focus_paths: Optional[list[str]] = None,
    stage1_only: bool = False,
    anthropic_api_key: Optional[str] = None,
    poll_interval: float = 15.0,
    timeout: float = 1800.0,
    on_progress: Optional[ProgressCallback] = None,
) -> TranslateResult:
    """Translate a natural-language policy spec into a Souffle Datalog policy.

    Exactly one of ``codebase_paths`` or ``codebase_archive`` may be
    given. If neither is given, the translator runs without any agent
    context — typically produces weaker results.

    Args:
        policy: Natural-language policy specification.
        codebase_paths: Iterable of files/dirs to zip into a codebase
            archive for the translator to analyze. Paths are stored
            relative to ``codebase_root`` (defaults to the common
            ancestor directory of the given paths).
        codebase_archive: Path to a pre-built .zip or .tar.gz of the
            agent codebase.
        codebase_root: Base directory when zipping ``codebase_paths``.
        instructions: Extra agent-specific instructions (e.g., "filter
            user messages on msg.agent = 'LLMAgent'"). These are passed
            verbatim to the translator inside a safety-fenced block.
        model: ``"haiku"``, ``"sonnet"`` (default), or ``"opus"``.
        focus_paths: Optional glob patterns to scope the agent analysis.
        stage1_only: If True, returns only the agent summary (cheaper
            for iterative development).
        anthropic_api_key: Anthropic API key to bill the LLM calls
            against. If None, reads ``ANTHROPIC_API_KEY`` from the
            environment.
        poll_interval: Seconds between status polls.
        timeout: Max seconds to wait for completion.
        on_progress: Callback invoked on every poll with
            ``(stage, elapsed_seconds)``.

    Returns:
        TranslateResult with policy, functors, summary, and
        server-side validation output.
    """
    if codebase_paths and codebase_archive:
        raise ValueError("pass either codebase_paths or codebase_archive, not both")

    cfg = get_config()
    base = cfg.translate_url.rstrip("/")

    headers: dict[str, str] = {}
    for k, v in cfg.get_metadata():
        if k.lower() == "x-api-key":
            headers["x-api-key"] = v
    if "x-api-key" not in headers:
        env_key = os.environ.get("SASY_API_KEY", "")
        if env_key:
            headers["x-api-key"] = env_key

    # Build multipart form
    import json

    files: list[tuple[str, tuple[str, bytes, str]]] = []

    # Codebase — optional
    if codebase_paths:
        paths = [Path(p) for p in codebase_paths]
        if codebase_root is None:
            # Common ancestor — Path.commonpath style. For a single
            # file this returns the file itself, which would zip the
            # entry as `.` and the server rejects dot-only names; walk
            # up to its parent in that case.
            common = Path(os.path.commonpath([str(p.resolve()) for p in paths]))
            codebase_root = common.parent if common.is_file() else common
        archive_bytes = _zip_paths(paths, Path(codebase_root))
        files.append(("codebase", ("codebase.zip", archive_bytes, "application/zip")))
    elif codebase_archive:
        ap = Path(codebase_archive)
        content = ap.read_bytes()
        mime = "application/gzip" if ap.suffix in (".gz", ".tgz") else "application/zip"
        files.append(("codebase", (ap.name, content, mime)))

    if anthropic_api_key is None:
        anthropic_api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    data = {
        "policy": policy,
        "instructions": instructions,
        "model": model,
        "focus_paths": json.dumps(focus_paths or []),
        "stage1_only": "true" if stage1_only else "false",
        "anthropic_api_key": anthropic_api_key,
    }

    with httpx.Client(timeout=60.0) as client:
        # Submit
        resp = client.post(
            f"{base}/v1/translate",
            headers=headers,
            data=data,
            files=files,
        )
        resp.raise_for_status()
        job = resp.json()
        job_id = job["job_id"]
        logger.info("submitted translate job %s", job_id)

        # Poll
        deadline = time.monotonic() + timeout
        while True:
            time.sleep(poll_interval)
            if time.monotonic() > deadline:
                raise TimeoutError(
                    f"translate job {job_id} did not finish within {timeout}s"
                )

            r = client.get(
                f"{base}/v1/translate/status/{job_id}",
                headers=headers,
            )
            r.raise_for_status()
            status = r.json()

            stage = status.get("stage", "unknown")
            elapsed = status.get("elapsed_seconds", 0.0)
            if on_progress:
                on_progress(stage, elapsed)

            if status["status"] == "running":
                logger.debug("job %s: %s (%.0fs)", job_id, stage, elapsed)
                continue

            result_data = status.get("result") or {}
            validation = None
            if result_data.get("validation"):
                validation = ValidationResult(**result_data["validation"])

            return TranslateResult(
                status=status["status"],
                policy_dl=result_data.get("policy_dl"),
                functors_cpp=result_data.get("functors_cpp"),
                agent_summary_md=result_data.get("agent_summary_md"),
                validation=validation,
                errors=result_data.get("errors", []),
                request_id=job_id,
                duration_seconds=result_data.get("duration_seconds", elapsed),
                cost_usd=result_data.get("cost_usd"),
            )
