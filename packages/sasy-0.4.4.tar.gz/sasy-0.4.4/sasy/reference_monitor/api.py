"""
Reference monitor gRPC client — HTTP proxying and tool call authorization.

Uses the shared ``sasy.config`` channel for all connections.
"""

import asyncio
import logging
import time
from typing import AsyncGenerator, Generator, Optional

import grpc
from sasy.config import get_async_channel, get_channel, get_config
from sasy.proto import reference_monitor_pb2_grpc as rm_grpc
from sasy.proto.reference_monitor_pb2 import (
    HTTPRequest,
    HTTPResponse,
    ToolCallRequest,
    ToolCallResponse,
)


logger = logging.getLogger(__name__)


def _metadata() -> list[tuple[str, str]]:
    return get_config().get_metadata()


# ── Sync API ──────────────────────────────────────────────

def proxy_http(
    request: HTTPRequest,
    metadata: Optional[list[tuple[str, str]]] = None,
) -> Generator[HTTPResponse, None, None]:
    """Proxy an HTTP request through the reference monitor.

    Sends the request as a single-message bidi stream. The server
    applies policy check + credential injection, then streams the
    response back.
    """
    stub = rm_grpc.RMProxyStub(get_channel())  # type: ignore
    yield from stub.ProxyHTTP(  # type: ignore
        iter([request]),
        metadata=metadata or _metadata(),
        timeout=180,
    )


def check_tool_call(
    fn_name: str,
    args: str,
    input_node_ids: Optional[list[str]] = None,
    max_retries: int = 3,
) -> ToolCallResponse:
    """Check authorization for a tool call.

    Args:
        fn_name: Tool function name.
        args: Tool arguments (JSON string).
        input_node_ids: Node IDs from observability graph context.
        max_retries: Retry count for transient failures.

    Returns:
        ToolCallResponse with authorization decision.
    """
    request = ToolCallRequest(
        fn_name=fn_name,
        args=args,
        input_node_ids=input_node_ids or [],
    )

    last_error = None
    for attempt in range(max_retries):
        try:
            stub = rm_grpc.RMProxyStub(get_channel())  # type: ignore
            return stub.CheckToolCall(  # type: ignore
                request, metadata=_metadata() or None,
            )
        except grpc.RpcError as e:
            last_error = e
            if e.code() in (grpc.StatusCode.CANCELLED, grpc.StatusCode.UNAVAILABLE):
                if attempt < max_retries - 1:
                    time.sleep(0.1 * (2 ** attempt))
                    continue
            raise

    raise last_error  # type: ignore


# ── Async API ─────────────────────────────────────────────



async def proxy_http_async(
    request: HTTPRequest,
    metadata: Optional[list[tuple[str, str]]] = None,
) -> AsyncGenerator[HTTPResponse, None]:
    """Proxy an HTTP request (async)."""
    stub = rm_grpc.RMProxyStub(get_async_channel())  # type: ignore

    async def _single():
        yield request

    async for response in stub.ProxyHTTP(  # type: ignore
        _single(), metadata=metadata or _metadata(), timeout=180,
    ):
        yield response


async def check_tool_call_async(
    fn_name: str,
    args: str,
    input_node_ids: Optional[list[str]] = None,
    max_retries: int = 3,
) -> ToolCallResponse:
    """Check authorization for a tool call (async)."""
    request = ToolCallRequest(
        fn_name=fn_name,
        args=args,
        input_node_ids=input_node_ids or [],
    )

    last_error = None
    for attempt in range(max_retries):
        try:
            stub = rm_grpc.RMProxyStub(get_async_channel())  # type: ignore
            return await stub.CheckToolCall(  # type: ignore
                request, metadata=_metadata() or None,
            )
        except grpc.RpcError as e:
            last_error = e
            if e.code() in (grpc.StatusCode.CANCELLED, grpc.StatusCode.UNAVAILABLE):
                if attempt < max_retries - 1:
                    await asyncio.sleep(0.1 * (2 ** attempt))
                    continue
            raise

    raise last_error  # type: ignore
