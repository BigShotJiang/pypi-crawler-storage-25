"""
sasy -- Policy enforcement for LLM-based agent systems.

Usage::

    import sasy
    from sasy.auth import APIKeyAuthHook

    sasy.configure(auth_hook=APIKeyAuthHook(api_key="my-key"))
    sasy.instrument()

For local development, set ``SASY_URL=localhost:10089`` in ``.env``.
The default endpoint is ``sasy.fly.dev:443`` (cloud).
"""

from .instrumentation import (
    configure,
    get_config,
    instrument,
    check_tool_call,
)
from .instrumentation.feedback import (
    AuthorizationFeedback,
    FeedbackAccumulator,
    get_current_feedback,
)
__all__ = [
    # Setup
    "configure",
    "get_config",
    "instrument",
    # Tool checks
    "check_tool_call",
    # Feedback
    "AuthorizationFeedback",
    "FeedbackAccumulator",
    "get_current_feedback",
]
