"""Credential server client API.

Uses the shared ``sasy.config`` for endpoint, TLS, and auth settings.
"""


from sasy.config import get_async_channel, get_channel, get_config
from sasy.proto import credential_server_pb2_grpc as credential_server_grpc
from sasy.proto.credential_server_pb2 import (
    Credential,
    CredentialsRequest,
    SetCredentialsRequest,
)


def _metadata() -> list[tuple[str, str]]:
    return get_config().get_metadata()


def set_credentials(
    entity: str,
    service: str,
    credentials: dict[str, str],
    tenant_id: str = "default",
) -> str:
    """Store credentials for an entity/service pair.

    Requires ``credential-writer`` role.

    Args:
        entity: Entity identifier (use ``"*"`` for global defaults)
        service: Service identifier (e.g. ``"openai"``)
        credentials: Key-value pairs to store
        tenant_id: Tenant scope for multi-tenancy
    """
    stub = credential_server_grpc.CredentialServerStub(get_channel())  # type: ignore
    response = stub.SetCredentials(
        SetCredentialsRequest(
            entity=entity,
            service=service,
            credentials=[Credential(key=k, value=v) for k, v in credentials.items()],
            tenant_id=tenant_id,
        ),
        metadata=_metadata(),
    )
    return response.response  # type: ignore


def get_credentials(
    entity: str,
    service: str,
    tenant_id: str = "default",
) -> dict[str, str]:
    """Get credentials for an entity/service pair.

    Requires ``credential-reader`` role.

    Args:
        entity: Entity identifier
        service: Service identifier
        tenant_id: Tenant scope for multi-tenancy
    """
    stub = credential_server_grpc.CredentialServerStub(get_channel())  # type: ignore
    response = stub.GetCredentials(
        CredentialsRequest(entity=entity, service=service, tenant_id=tenant_id),
        metadata=_metadata(),
    )
    return {c.key: c.value for c in response.credentials}


# ── Async API ─────────────────────────────────────────────



async def get_credentials_async(
    entity: str,
    service: str,
    tenant_id: str = "default",
) -> dict[str, str]:
    """Get credentials asynchronously."""
    stub = credential_server_grpc.CredentialServerStub(get_async_channel())  # type: ignore
    response = await stub.GetCredentials(
        CredentialsRequest(entity=entity, service=service, tenant_id=tenant_id),
        metadata=_metadata(),
    )
    return {c.key: c.value for c in response.credentials}
