"""Observability API for SASY — event recording and graph queries."""

from sasy.proto.observability_pb2 import (
    Computation,
    Computations,
    Dependencies,
    Edge,
    Event,
    Events,
    EventsWithDependencies,
    Role,
    SliceRequest,
    SpanRequest,
    Tool,
    TraceGraph,
    TraceRequest,
)

from .api import (
    backward_slice,
    configure,
    record_dependencies,
    record_events,
    record_events_with_dependencies,
)

__all__ = [
    # Proto types
    "Computation",
    "Computations",
    "Dependencies",
    "Edge",
    "Event",
    "Events",
    "EventsWithDependencies",
    "Role",
    "SliceRequest",
    "SpanRequest",
    "Tool",
    "TraceGraph",
    "TraceRequest",
    # API
    "backward_slice",
    "configure",
    "record_dependencies",
    "record_events",
    "record_events_with_dependencies",
]
