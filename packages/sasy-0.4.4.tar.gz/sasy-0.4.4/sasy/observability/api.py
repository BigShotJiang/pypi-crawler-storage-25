"""Observability API — event recording and graph queries.

Uses the shared ``sasy.config`` for endpoint, TLS, and auth settings.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from sasy.config import get_async_channel, get_channel, get_config

if TYPE_CHECKING:
    import networkx as nwx
from sasy.proto import observability_pb2_grpc as observability_grpc
from sasy.proto.observability_pb2 import (
    Computation,
    Computations,
    Dependencies,
    Edge,
    Event,
    Events,
    EventsWithDependencies,
    SliceRequest,
    SpanRequest,
    TraceGraph,
    TraceRequest,
)

from .utils import to_digraph

logger = logging.getLogger(__name__)


def _metadata() -> list[tuple[str, str]]:
    return get_config().get_metadata()


def get_current_input_ids() -> list[str]:
    """Get the input message IDs from the current OTel span."""
    try:
        from sasy.instrumentation.otel import get_current_input_ids as _get_input_ids
        return _get_input_ids()
    except ImportError:
        return []


def get_current_message_id() -> Optional[str]:
    """Get the most recent input message ID from the current OTel span."""
    input_ids = get_current_input_ids()
    return input_ids[-1] if input_ids else None


def configure(
    url: Optional[str] = None,
    cert_path: Optional[str] = None,
    key_path: Optional[str] = None,
    ca_path: Optional[str] = None,
    auth_hook=None,
) -> None:
    """Configure observability API (delegates to shared sasy.config)."""
    from sasy.config import configure as _configure
    _configure(url=url, cert_path=cert_path, key_path=key_path,
               ca_path=ca_path, auth_hook=auth_hook)


# ── Sync API ──────────────────────────────────────────────

def record_events(events: list[Event]) -> list[str]:
    """Record events (messages) and return their IDs."""
    stub = observability_grpc.ObservabilityStub(get_channel())  # type: ignore
    response = stub.RegisterEvents(Events(events=events), metadata=_metadata())
    return list(response.ids)


def record_dependencies(edges: list[Edge]) -> None:
    """Record dependencies between events."""
    stub = observability_grpc.ObservabilityStub(get_channel())  # type: ignore
    stub.RegisterDependencies(Dependencies(edges=edges), metadata=_metadata())


def record_events_with_dependencies(
    events: list[Event], edges: list[Edge]
) -> list[str]:
    """Record events and dependencies in a single atomic transaction."""
    stub = observability_grpc.ObservabilityStub(get_channel())  # type: ignore
    response = stub.RegisterEventsWithDependencies(
        EventsWithDependencies(events=events, edges=edges),
        metadata=_metadata(),
    )
    return list(response.ids)


def backward_slice(
    event_id: str, max_depth: Optional[int] = None,
) -> nwx.DiGraph:
    """Get the backward slice (ancestors) of an event."""
    stub = observability_grpc.ObservabilityStub(get_channel())  # type: ignore
    graph = stub.BackwardSlice(
        SliceRequest(event_id=event_id, max_depth=max_depth),
        metadata=_metadata(),
    )
    return to_digraph(graph)


def forward_slice(
    event_id: str, max_depth: Optional[int] = None,
) -> nwx.DiGraph:
    """Get the forward slice (descendants) of an event."""
    stub = observability_grpc.ObservabilityStub(get_channel())  # type: ignore
    graph = stub.ForwardSlice(
        SliceRequest(event_id=event_id, max_depth=max_depth),
        metadata=_metadata(),
    )
    return to_digraph(graph)


def register_computations(computations: list[Computation]) -> list[str]:
    """Record OTel spans in the graph."""
    stub = observability_grpc.ObservabilityStub(get_channel())  # type: ignore
    response = stub.RegisterComputations(
        Computations(computations=computations), metadata=_metadata(),
    )
    return list(response.ids)


def get_trace(
    trace_id: str,
    start_time_ns: Optional[int] = None,
    end_time_ns: Optional[int] = None,
) -> TraceGraph:
    """Retrieve a full trace with spans, messages, and relationships."""
    stub = observability_grpc.ObservabilityStub(get_channel())  # type: ignore
    return stub.GetTrace(
        TraceRequest(trace_id=trace_id, start_time_ns=start_time_ns, end_time_ns=end_time_ns),
        metadata=_metadata(),
    )


def get_span(
    span_id: str,
    include_children: bool = False,
    include_messages: bool = False,
) -> Computation:
    """Retrieve a single span by ID."""
    stub = observability_grpc.ObservabilityStub(get_channel())  # type: ignore
    return stub.GetSpan(
        SpanRequest(span_id=span_id, include_children=include_children, include_messages=include_messages),
        metadata=_metadata(),
    )


# ── Async API ─────────────────────────────────────────────



async def record_events_async(events: list[Event]) -> list[str]:
    """Record events asynchronously."""
    stub = observability_grpc.ObservabilityStub(get_async_channel())  # type: ignore
    response = await stub.RegisterEvents(Events(events=events), metadata=_metadata())
    return list(response.ids)


async def record_dependencies_async(edges: list[Edge]) -> None:
    """Record dependencies asynchronously."""
    stub = observability_grpc.ObservabilityStub(get_async_channel())  # type: ignore
    await stub.RegisterDependencies(Dependencies(edges=edges), metadata=_metadata())


async def record_events_with_dependencies_async(
    events: list[Event], edges: list[Edge]
) -> list[str]:
    """Record events and dependencies atomically (async)."""
    stub = observability_grpc.ObservabilityStub(get_async_channel())  # type: ignore
    response = await stub.RegisterEventsWithDependencies(
        EventsWithDependencies(events=events, edges=edges), metadata=_metadata(),
    )
    return list(response.ids)


async def register_computations_async(computations: list[Computation]) -> list[str]:
    """Record OTel spans asynchronously."""
    stub = observability_grpc.ObservabilityStub(get_async_channel())  # type: ignore
    response = await stub.RegisterComputations(
        Computations(computations=computations), metadata=_metadata(),
    )
    return list(response.ids)
