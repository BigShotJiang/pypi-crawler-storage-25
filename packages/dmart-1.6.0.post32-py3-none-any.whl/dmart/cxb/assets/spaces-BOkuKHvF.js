import{w as s}from"./svelte-BeVeE-NK.js";const o=s(null);export{o as s};
