"""Installation of network and threading patches.

Patches are installed once and remain active for the process lifetime.
They are inert when network access is allowed (``network_allowed`` is
``True``, the default), falling through to the original methods.

Threading patches ensure that ``contextvars`` state (including
``network_allowed``) propagates to worker threads spawned via
``threading.Thread`` and ``ThreadPoolExecutor.submit``.
``ThreadPoolExecutor.map`` is covered implicitly because CPython's
``Executor.map`` delegates to ``self.submit`` for each item.
"""

import concurrent.futures
import contextvars
import socket
import threading
from typing import Any

from . import socket as _gated

_lock = threading.Lock()
_installed = False

_METHODS = [
    "connect",
    "connect_ex",
    "bind",
    "listen",
    "accept",
    "send",
    "sendall",
    "sendto",
    "sendfile",
    "recv",
    "recvfrom",
    "recv_into",
    "recvfrom_into",
]

_PATCHES = {
    "connect": _gated._p_connect,
    "connect_ex": _gated._p_connect_ex,
    "bind": _gated._p_bind,
    "listen": _gated._p_listen,
    "accept": _gated._p_accept,
    "send": _gated._p_send,
    "sendall": _gated._p_sendall,
    "sendto": _gated._p_sendto,
    "sendfile": _gated._p_sendfile,
    "recv": _gated._p_recv,
    "recvfrom": _gated._p_recvfrom,
    "recv_into": _gated._p_recv_into,
    "recvfrom_into": _gated._p_recvfrom_into,
}

# --- Threading originals ---
_original_thread_start: Any = None
_original_executor_submit: Any = None


# --- Threading patches ---


def _p_thread_start(self: Any) -> Any:
    """Patched Thread.start() that propagates contextvars to the new thread."""
    ctx = contextvars.copy_context()
    original_run = self.run

    def _ctx_run(*args: Any, **kwargs: Any) -> Any:
        return ctx.run(original_run, *args, **kwargs)

    self.run = _ctx_run
    return _original_thread_start(self)


def _p_executor_submit(self: Any, fn: Any, /, *args: Any, **kwargs: Any) -> Any:
    """Patched ThreadPoolExecutor.submit() that propagates contextvars."""
    ctx = contextvars.copy_context()
    return _original_executor_submit(self, ctx.run, fn, *args, **kwargs)


def install() -> None:
    """Install network and threading patches (idempotent, permanent)."""
    global _installed, _original_thread_start, _original_executor_submit
    with _lock:
        if _installed:
            return

        # Store originals and install patches — sockets
        for name in _METHODS:
            if name not in _gated._originals:
                _gated._originals[name] = getattr(socket.socket, name)
                setattr(socket.socket, name, _PATCHES[name])
        if _gated._original_getaddrinfo is None:
            _gated._original_getaddrinfo = socket.getaddrinfo
            socket.getaddrinfo = _gated._p_getaddrinfo

        # Store originals and install patches — threading
        if _original_thread_start is None:
            _original_thread_start = threading.Thread.start
            threading.Thread.start = _p_thread_start  # type: ignore[assignment]
        if _original_executor_submit is None:
            _original_executor_submit = concurrent.futures.ThreadPoolExecutor.submit
            concurrent.futures.ThreadPoolExecutor.submit = _p_executor_submit  # type: ignore[assignment]

        _installed = True
