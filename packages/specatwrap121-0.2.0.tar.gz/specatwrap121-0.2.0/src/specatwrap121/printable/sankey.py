from __future__ import annotations

import colorsys
import re
from collections.abc import Callable, Sequence
from typing import Any

import plotly.graph_objects as go
import polars as pl
from plotly.colors import qualitative
import plotly.io as pio

pio.renderers.default = "notebook"


Predicate = Callable[[pl.LazyFrame], pl.Expr]

_PREFIX_RE = re.compile(r"^_(\d+)_(.*)$")
_MUTED_LINK_COLOR = "rgba(180, 180, 180, 0.18)"
_DEFAULT_NODE_COLOR = "rgba(120, 120, 120, 0.45)"
_DEFAULT_PALETTE = (
    qualitative.Plotly
    + qualitative.D3
    + qualitative.G10
    + qualitative.T10
    + qualitative.Alphabet
)


def _parse_event_position(activity: str) -> tuple[int, str]:
    match = _PREFIX_RE.match(activity)
    if match is None:
        return (10**9, activity)
    return (int(match.group(1)), match.group(2))


def _compute_node_positions(
    activities: Sequence[str],
    node_total_flow: dict[str, int],
) -> tuple[list[float], list[float]]:
    columns: dict[int, list[str]] = {}
    for activity in activities:
        column_index, _ = _parse_event_position(activity)
        columns.setdefault(column_index, []).append(activity)

    ordered_columns = sorted(columns)
    if not ordered_columns:
        return [], []

    max_column_index = max(1, len(ordered_columns) - 1)
    x_by_activity: dict[str, float] = {}
    y_by_activity: dict[str, float] = {}

    for column_offset, column_index in enumerate(ordered_columns):
        column_activities = sorted(
            columns[column_index],
            key=lambda activity: (
                -node_total_flow.get(activity, 0),
                _parse_event_position(activity),
            ),
        )
        x_position = (
            0.001 if len(ordered_columns) == 1 else column_offset / max_column_index
        )

        if len(column_activities) == 1:
            y_positions = [0.001]
        else:
            y_positions = [
                index / (len(column_activities) - 1) * 0.98 + 0.001
                for index in range(len(column_activities))
            ]

        for activity, y_position in zip(column_activities, y_positions, strict=True):
            x_by_activity[activity] = x_position
            y_by_activity[activity] = y_position

    return (
        [x_by_activity[activity] for activity in activities],
        [y_by_activity[activity] for activity in activities],
    )


def _hex_to_rgb(color: str) -> tuple[int, int, int]:
    value = color.lstrip("#")
    if len(value) != 6:
        raise ValueError(f"Expected a 6-digit hex color, got {color!r}.")
    return tuple(int(value[index : index + 2], 16) for index in (0, 2, 4))


def _blend_hex_colors(colors: Sequence[str]) -> tuple[int, int, int]:
    rgbs = [_hex_to_rgb(color) for color in colors]
    return tuple(
        round(sum(channel_values) / len(rgbs))
        for channel_values in zip(*rgbs, strict=True)
    )


def _rgb_to_rgba(color: tuple[int, int, int], alpha: float) -> str:
    red, green, blue = color
    return f"rgba({red}, {green}, {blue}, {alpha:.3f})"


def _generate_palette(size: int) -> list[str]:
    if size <= len(_DEFAULT_PALETTE):
        return list(_DEFAULT_PALETTE[:size])

    colors = list(_DEFAULT_PALETTE)
    missing = size - len(colors)
    for index in range(missing):
        hue = index / max(missing, 1)
        red, green, blue = colorsys.hsv_to_rgb(hue, 0.65, 0.95)
        colors.append(
            f"#{int(red * 255):02X}{int(green * 255):02X}{int(blue * 255):02X}"
        )
    return colors


def _normalise_predicate_result(result: Any, variants: pl.LazyFrame) -> pl.Expr:
    if isinstance(result, pl.Expr):
        return result
    if callable(result):
        resolved = result(variants)
        if isinstance(resolved, pl.Expr):
            return resolved
    raise TypeError("Each predicate must resolve to a Polars expression.")


def _build_variant_table(
    event_log: pl.DataFrame,
    case_col: str,
    activity_col: str,
) -> pl.DataFrame:
    per_case = (
        event_log.lazy()
        .with_row_index("__event_order")
        .group_by(case_col, maintain_order=True)
        .agg(pl.col(activity_col).sort_by("__event_order").alias("variant"))
    )

    variants = (
        per_case.group_by("variant", maintain_order=True)
        .agg(pl.len().alias("case_count"))
        .with_columns(pl.col("variant").list.len().alias("variant_length"))
        .collect()
    )

    max_length = variants.get_column("variant_length").max() if variants.height else 0
    if not max_length:
        return variants

    return variants.with_columns(
        [
            pl.col("variant")
            .list.get(index, null_on_oob=True)
            .alias(f"event_{index + 1}")
            for index in range(max_length)
        ]
    )


def _predicate_names(predicates: Sequence[Predicate]) -> list[str]:
    names: list[str] = []
    for index, predicate in enumerate(predicates, start=1):
        candidate = getattr(predicate, "__name__", None)
        if candidate and candidate != "<lambda>":
            names.append(candidate)
        else:
            names.append(f"predicate_{index}")
    return names


def plot_trace_highlighted_sankey(
    event_log: pl.DataFrame,
    predicates: Sequence[Predicate] | None = None,
    *,
    case_col: str = "case:concept:name",
    activity_col: str = "concept:name",
    title: str = "Trace-highlighted Sankey diagram",
    height: int | None = None,
    filter_out: float = 0.0,
    show: bool = True,
) -> tuple[go.Figure, pl.DataFrame, pl.DataFrame]:
    """Render a Sankey diagram where trace variants are highlighted by predicate matches.

    Predicate API
    -------------
    ``predicates`` may be ``None`` or a sequence of callables. If it is omitted
    or empty, no highlighting is applied and all links are rendered in muted
    colors.

    When predicates are provided, each callable is evaluated against the
    aggregated variant table and must resolve to a Polars boolean expression.
    Conceptually, predicates do not operate on individual event-log rows; they
    operate on one row per *trace variant*.

    A predicate is called like this::

        predicate(variants_lazyframe) -> pl.Expr

    The ``variants_lazyframe`` argument exists so the predicate signature is
    explicit and future-proof, but in most cases you will simply build and
    return a Polars expression with ``pl.col(...)``. The function does not need
    to read from the lazy frame directly.

    Each row of the aggregated variant table represents one unique trace
    variant and includes at least these columns:

    - ``variant``: ``list[str]`` containing the full ordered trace, for example
      ``["_1_CANCER", "_2_TUMOR", "_3_DEATH"]``.
    - ``case_count``: number of cases/patients having exactly that variant.
    - ``variant_length``: length of the trace.
    - ``event_1``, ``event_2``, ...: positional convenience columns extracted
      from ``variant``. If a variant is shorter than a position, that column is
      null for that row.

    Predicates should therefore express conditions on whole variants, for
    example:

    - first event is ``"_1_CANCER"``
    - trace contains ``"_3_DEATH"``
    - second event is in a set of diagnoses
    - trace length is exactly 3

    Example predicates::

        def starts_with_cancer(_: pl.LazyFrame) -> pl.Expr:
            return pl.col("event_1") == "_1_CANCER"

        def contains_death(_: pl.LazyFrame) -> pl.Expr:
            return pl.col("variant").list.contains("_3_DEATH")

        def short_tumor_path(_: pl.LazyFrame) -> pl.Expr:
            return (
                (pl.col("variant_length") == 3)
                & (pl.col("event_2") == "_2_TUMOR")
            )

    Predicate results are normalized as follows:

    - the returned expression is cast to boolean
    - null values are treated as ``False``
    - each predicate gets its own highlight color
    - if multiple predicates match the same variant, their colors are blended

    This means a predicate should describe membership in a highlighted subset
    of variants. Variants matching no predicate are rendered with muted links.

    Parameters
    ----------
    event_log
        Polars dataframe with one row per event.
    predicates
        Optional predicate callables following the Predicate API described
        above. If omitted or empty, all traces are shown with muted colors.
    case_col
        Trace identifier column.
    activity_col
        Activity column.
    title
        Plot title.
    height
        Optional figure height in pixels. If omitted, a larger height is chosen
        automatically based on the number of nodes.
    filter_out
        Filter out trace variants whose fraction of all cases is smaller than
        this threshold. For example, ``0.01`` removes variants representing
        less than 1% of all traces. Must be between 0.0 and 1.0.
    show
        Whether to call ``fig.show()``.

    Returns
    -------
    fig, variants, links
        The Plotly figure, the aggregated variant table, and the aggregated link table.
    """
    required_columns = {case_col, activity_col}
    missing_columns = required_columns.difference(event_log.columns)
    if missing_columns:
        missing = ", ".join(sorted(missing_columns))
        raise ValueError(f"Missing required columns: {missing}.")
    if not 0.0 <= filter_out <= 1.0:
        raise ValueError("filter_out must be between 0.0 and 1.0.")

    variants = _build_variant_table(
        event_log, case_col=case_col, activity_col=activity_col
    )
    if variants.is_empty():
        raise ValueError("The event log is empty.")

    if filter_out > 0.0:
        total_cases = int(variants.get_column("case_count").sum())
        variants = variants.filter(
            (pl.col("case_count") / pl.lit(total_cases)) >= pl.lit(filter_out)
        )
        if variants.is_empty():
            raise ValueError(
                "No trace variants remain after applying the filter_out threshold."
            )

    predicates = list(predicates or [])
    predicate_names = _predicate_names(predicates)
    predicate_palette = _generate_palette(len(predicates))
    variants_lf = variants.lazy()

    predicate_columns: list[str] = []
    for index, predicate in enumerate(predicates):
        column_name = f"__predicate_{index}"
        predicate_columns.append(column_name)
        predicate_expr = (
            _normalise_predicate_result(predicate, variants_lf)
            .fill_null(False)
            .cast(pl.Boolean)
        )
        variants_lf = variants_lf.with_columns(predicate_expr.alias(column_name))

    if predicate_columns:
        mask_expr = sum(
            pl.col(name).cast(pl.UInt32) * (1 << index)
            for index, name in enumerate(predicate_columns)
        )
        variants = variants_lf.with_columns(mask_expr.alias("highlight_mask")).collect()
    else:
        variants = variants.with_columns(
            pl.lit(0, dtype=pl.UInt32).alias("highlight_mask")
        )

    unique_activities = sorted(
        {
            activity
            for variant in variants.get_column("variant").to_list()
            for activity in variant
        },
        key=_parse_event_position,
    )

    node_total_flow: dict[str, int] = {}
    for variant, case_count in variants.select("variant", "case_count").iter_rows():
        for activity in variant:
            node_total_flow[activity] = node_total_flow.get(activity, 0) + int(
                case_count
            )

    node_x, node_y = _compute_node_positions(unique_activities, node_total_flow)
    node_indices = {activity: index for index, activity in enumerate(unique_activities)}

    edge_rows: list[dict[str, Any]] = []
    for variant, case_count, highlight_mask in variants.select(
        "variant", "case_count", "highlight_mask"
    ).iter_rows():
        for source, target in zip(variant, variant[1:], strict=False):
            edge_rows.append(
                {
                    "source": source,
                    "target": target,
                    "source_idx": node_indices[source],
                    "target_idx": node_indices[target],
                    "case_count": case_count,
                    "highlight_mask": int(highlight_mask),
                }
            )

    if edge_rows:
        links = (
            pl.DataFrame(edge_rows)
            .group_by(
                ["source", "target", "source_idx", "target_idx", "highlight_mask"],
                maintain_order=True,
            )
            .agg(pl.col("case_count").sum().alias("value"))
            .sort(["source_idx", "target_idx", "highlight_mask"])
        )
    else:
        links = pl.DataFrame(
            schema={
                "source": pl.String,
                "target": pl.String,
                "source_idx": pl.UInt32,
                "target_idx": pl.UInt32,
                "highlight_mask": pl.UInt32,
                "value": pl.UInt32,
            }
        )

    mask_to_color: dict[int, str] = {0: _MUTED_LINK_COLOR}
    mask_to_label: dict[int, str] = {0: "No predicate matched"}
    for mask in sorted(
        links.get_column("highlight_mask").unique().to_list() if links.height else [0]
    ):
        if mask == 0:
            continue
        active_indices = [
            index for index in range(len(predicates)) if mask & (1 << index)
        ]
        blended_color = _blend_hex_colors(
            [predicate_palette[index] for index in active_indices]
        )
        mask_to_color[mask] = _rgb_to_rgba(blended_color, 0.82)
        mask_to_label[mask] = " + ".join(
            predicate_names[index] for index in active_indices
        )

    link_colors = (
        [
            mask_to_color[int(mask)]
            for mask in links.get_column("highlight_mask").to_list()
        ]
        if links.height
        else []
    )
    link_labels = (
        [
            mask_to_label[int(mask)]
            for mask in links.get_column("highlight_mask").to_list()
        ]
        if links.height
        else []
    )

    figure = go.Figure(
        data=[
            go.Sankey(
                arrangement="fixed",
                node=dict(
                    pad=15,
                    thickness=20,
                    line=dict(color="rgba(80, 80, 80, 0.35)", width=0.5),
                    label=unique_activities,
                    color=[_DEFAULT_NODE_COLOR] * len(unique_activities),
                    x=node_x,
                    y=node_y,
                ),
                link=dict(
                    source=links.get_column("source_idx").to_list()
                    if links.height
                    else [],
                    target=links.get_column("target_idx").to_list()
                    if links.height
                    else [],
                    value=links.get_column("value").to_list() if links.height else [],
                    color=link_colors,
                    customdata=link_labels,
                    hovertemplate=(
                        "%{source.label} → %{target.label}<br>"
                        "Cases: %{value}<br>"
                        "Highlight: %{customdata}<extra></extra>"
                    ),
                ),
            )
        ]
    )
    computed_height = max(700, min(2400, 24 * len(unique_activities)))
    figure.update_layout(
        title_text=title,
        font_size=11,
        height=height if height is not None else computed_height,
    )

    if show:
        figure.show()

    return figure, variants, links
