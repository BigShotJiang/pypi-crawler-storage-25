# Copyright 2017 Jairo Llopis <jairo.llopis@tecnativa.com>
# Copyright 2020 Tecnativa - Pedro M. Baeza
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
{
    "name": "Sale Order Product Recommendation",
    "summary": "Recommend products to sell to customer based on history",
    "version": "19.0.1.0.0",
    "category": "Sales",
    "website": "https://github.com/OCA/sale-workflow",
    "author": "Tecnativa, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "application": False,
    "installable": True,
    "maintainers": ["sergio-teruel", "rafaelbn", "yajo"],
    "depends": [
        "sale_management",
    ],
    "data": [
        "security/ir.model.access.csv",
        "wizards/sale_order_recommendation_view.xml",
        "views/res_config_settings_views.xml",
        "views/sale_order_view.xml",
    ],
}
