# tokenspeed-iris

Placeholder package for the TokenSpeed repackaged ROCm Iris distribution.

The real package is built from ROCm/iris and will keep the upstream Python
import name:

```python
import iris
```
