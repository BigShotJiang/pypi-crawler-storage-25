from __future__ import annotations

import json
import logging
import re

from smritix.agents.base import Session, SessionMessage
from smritix.config import AUTO_CONFIRM_THRESHOLD, AUTO_DISCARD_THRESHOLD, DUPLICATE_SIMILARITY_THRESHOLD
from smritix.embedding.encoder import embed_memory
from smritix.storage.embeddings import insert_hot, maybe_merge, search
from smritix.storage.memories import confirm_memory, get_memory, insert_pending

logger = logging.getLogger(__name__)

_MAX_CONVERSATION_CHARS = 380_000

_VALID_OBS_TYPES = frozenset({
    "change", "discovery", "feature", "bug_fix",
    "correction", "preference", "session_summary",
})

_VALID_TYPES = frozenset({
    "decision", "preference", "learning", "context", "anti_pattern",
})


def strip_tool_results_from_text(messages: list[SessionMessage]) -> str:
    lines = []
    for m in messages:
        if m.role in ("user", "assistant") and m.content.strip():
            prefix = "User" if m.role == "user" else "AI"
            lines.append(f"{prefix}: {m.content.strip()}")

    text = "\n".join(lines)

    if len(text) > _MAX_CONVERSATION_CHARS:
        tail = text[-_MAX_CONVERSATION_CHARS:]
        first_newline = tail.find("\n")
        if first_newline > 0:
            tail = tail[first_newline + 1:]
        text = "[...earlier content omitted for length...]\n" + tail
        logger.debug("Conversation truncated to %d chars", len(text))

    return text


def _validate_memory(m: dict) -> bool:
    """Quality gate: return False to discard a memory."""
    if float(m.get("confidence", 0)) < AUTO_DISCARD_THRESHOLD:
        return False
    if not str(m.get("evidence", "")).strip():
        return False
    title = str(m.get("title", "")).strip()
    if not title or len(title.split()) < 4:
        return False
    if not str(m.get("narrative", "")).strip():
        return False
    obs = m.get("obs_type")
    if obs not in _VALID_OBS_TYPES:
        return False
    # session_summary never goes into the memories list
    if obs == "session_summary":
        return False
    if m.get("type") not in _VALID_TYPES:
        m["type"] = "context"  # safe fallback
    return True


def parse_drafter_response(raw: str) -> tuple[list[dict], dict | None]:
    """
    Parse AI response into (memories, session_summary).
    Returns ([], None) on parse failure.
    """
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if not match:
        return [], None
    try:
        data = json.loads(match.group())
    except (json.JSONDecodeError, TypeError):
        return [], None

    raw_memories = data.get("memories", [])
    session_summary = data.get("session_summary")

    memories = []
    for item in raw_memories:
        if not isinstance(item, dict):
            continue
        item["confidence"] = float(item.get("confidence", 0.5))
        item["facts"] = item.get("facts") or []
        item["tags"] = item.get("tags") or []
        item["files_mentioned"] = item.get("files_mentioned") or []
        item["narrative"] = str(item.get("narrative", "")).strip()
        item["title"] = str(item.get("title", "")).strip()
        item["evidence"] = str(item.get("evidence", "")).strip()
        item["type"] = str(item.get("type", "context"))
        item["obs_type"] = str(item.get("obs_type", "discovery"))

        if _validate_memory(item):
            memories.append(item)
        else:
            logger.debug("Discarded low-quality memory: %s", item.get("title", "?"))

    return memories, session_summary


def apply_confidence_tiers(
    memories: list[dict],
) -> tuple[list[dict], list[dict], list[dict]]:
    auto_confirm, pending, discarded = [], [], []
    for m in memories:
        c = m["confidence"]
        if c > AUTO_CONFIRM_THRESHOLD:
            auto_confirm.append(m)
        elif c >= AUTO_DISCARD_THRESHOLD:
            pending.append(m)
        else:
            discarded.append(m)
    return auto_confirm, pending, discarded


def draft_from_session(
    session: Session,
    messages: list[SessionMessage],
    session_id: str,
    conn,
    providers: list | None = None,
) -> bool:
    """
    Analyze a session and store memory drafts using the configured AI provider chain.

    providers: list of AIProvider instances in priority order.
    Tries each in sequence — first success wins.
    Returns True on success (even if no memories found), False if all providers failed.
    """

    if not providers:
        logger.warning("No AI providers configured — skipping session drafting for %s", session_id)
        return False

    conversation = strip_tool_results_from_text(messages)
    if not conversation.strip():
        return True  # Empty session is fine — checkpoint it so we don't retry

    raw = None
    for provider in providers:
        try:
            raw = provider.analyze(conversation)
            logger.info("Session %s analyzed by provider: %s", session_id, provider.name())
            break
        except Exception as exc:
            logger.warning("Provider %s failed for session %s: %s", provider.name(), session_id, exc)

    if raw is None:
        logger.error("All providers failed for session %s — will retry on next run", session_id)
        return False  # Signal failure so caller skips checkpoint

    # Log full raw response at DEBUG for easy inspection
    logger.debug(
        "Session %s raw response (%d chars):\n%s",
        session_id, len(raw), raw,
    )

    memories, session_summary = parse_drafter_response(raw)

    tool = getattr(session, "tool", None)
    project_path = getattr(session, "project_path", None)

    # Store the session summary as a confirmed memory (obs_type="session_summary").
    # We confirm it immediately rather than routing through pending so it never
    # sits in the review queue alongside real memories awaiting approval.
    # Skip titles that signal an empty/useless session (e.g. "Empty transcript...").
    _SKIP_TITLE_PATTERNS = ("empty transcript", "no conversation", "no content", "session analyzed")
    _summary_title = str(session_summary.get("title", "")).strip() if session_summary else ""
    _summary_ok = (
        session_summary
        and _summary_title
        and not any(_summary_title.lower().startswith(p) for p in _SKIP_TITLE_PATTERNS)
    )
    if _summary_ok:
        completed = session_summary.get("completed") or []
        facts = completed if isinstance(completed, list) else [str(completed)]
        pid = insert_pending(
            conn,
            title=_summary_title,
            obs_type="session_summary",
            type_="context",
            facts=facts,
            narrative=" ".join(filter(None, [
                session_summary.get("investigated"),
                session_summary.get("learned"),
            ])),
            tags=["session_summary"],
            files_mentioned=[],
            confidence=1.0,
            evidence=str(session_summary.get("next_steps", "") or ""),
            source_session_id=session_id,
            source_tool=tool,
            project_path=project_path,
        )
        mid = confirm_memory(conn, pid)
        # Embed session summary so it appears in search / get_memories results
        full_mem = get_memory(conn, mid) or {}
        if full_mem:
            insert_hot(conn, mid, embed_memory(full_mem))
        logger.debug("Session %s: confirmed session_summary — %s", session_id, _summary_title)

    if not memories:
        logger.warning(
            "No qualifying memories for session %s (raw response %d chars):\n%s",
            session_id, len(raw), raw,
        )
        maybe_merge(conn)
        return True  # Provider worked, just no qualifying content — checkpoint it

    auto_confirm, pending_list, discarded = apply_confidence_tiers(memories)
    logger.info(
        "Session %s: %d auto-confirm, %d pending, %d discarded",
        session_id, len(auto_confirm), len(pending_list), len(discarded),
    )

    def _store_pending(m: dict) -> str:
        return insert_pending(
            conn,
            title=m["title"],
            obs_type=m["obs_type"],
            type_=m["type"],
            facts=m["facts"],
            narrative=m["narrative"],
            tags=m["tags"],
            files_mentioned=m["files_mentioned"],
            confidence=m["confidence"],
            evidence=m["evidence"],
            source_session_id=session_id,
            source_tool=tool,
            project_path=project_path,
        )

    def _is_duplicate(memory: dict) -> bool:
        """Skip if very similar memory already confirmed."""
        vec = embed_memory(memory)
        hits = search(conn, vec, limit=3)
        return bool(hits and hits[0]["similarity"] > DUPLICATE_SIMILARITY_THRESHOLD)

    for m in auto_confirm:
        if _is_duplicate(m):
            logger.debug("Skipping duplicate: %s", m["title"])
            continue
        pid = _store_pending(m)
        mid = confirm_memory(conn, pid)
        confirmed_mem = get_memory(conn, mid) or m
        insert_hot(conn, mid, embed_memory(confirmed_mem))

    for m in pending_list:
        _store_pending(m)

    maybe_merge(conn)
    return True
