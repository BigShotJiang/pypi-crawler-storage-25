"""
Analysis prompt for session memory extraction.
Kept in a separate module to avoid circular imports.
"""
import json

# JSON schema shared between CLI (--json-schema flag) and API (tool_use input_schema)
MEMORY_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "memories": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "obs_type":        {"type": "string"},
                    "title":           {"type": "string"},
                    "facts":           {"type": "array", "items": {"type": "string"}},
                    "narrative":       {"type": "string"},
                    "type":            {"type": "string"},
                    "tags":            {"type": "array", "items": {"type": "string"}},
                    "files_mentioned": {"type": "array", "items": {"type": "string"}},
                    "confidence":      {"type": "number"},
                    "evidence":        {"type": "string"},
                },
                "required": ["obs_type", "title", "narrative", "type", "confidence", "evidence"],
                "additionalProperties": False,
            },
        },
        "session_summary": {
            "type": "object",
            "properties": {
                "title":        {"type": "string"},
                "investigated": {"type": "string"},
                "learned":      {"type": "string"},
                "completed":    {"type": "array", "items": {"type": "string"}},
                "next_steps":   {"type": "string"},
            },
            "required": ["title", "completed"],
            "additionalProperties": False,
        },
    },
    "required": ["memories", "session_summary"],
    "additionalProperties": False,
}

MEMORY_JSON_SCHEMA_STR = json.dumps(MEMORY_JSON_SCHEMA)

# Instructions block — reused in both the prompt template and the API tool description.
_INSTRUCTIONS = """\
Analyze the session transcript above. Extract 0-2 memories (default: ZERO).

A memory qualifies ONLY if it is one of:
1. CORRECTION — user explicitly corrected the AI ("no, use X not Y", "don't do that")
2. PREFERENCE — user stated a durable preference for how things should be done
3. DECISION — a significant architectural/tooling decision confirmed with clear reasoning

Does NOT qualify: discoveries, bug fixes, one-off task instructions, code changes, technical findings.

THE MEMORY TEST: "If this user starts a completely different session 3 months from now, would knowing this memory change how I'd assist them?" If no → do not save it.

For each qualifying memory use these exact fields:
- obs_type: "correction" | "preference" (not "decision" — use preference for decisions too)
- title: 6-10 word specific headline naming the subject
- facts: list of precise bullets
- narrative: 1-2 sentences — what was decided/preferred and why it matters for future sessions
- type: "decision" | "preference" | "anti_pattern"
- tags: 1-2 tags from: pattern, trade-off, architecture, testing, workflow, tooling
- files_mentioned: list of file paths mentioned (empty list if none)
- confidence: 0.85-1.0 (if < 0.85, do not include the memory)
- evidence: exact word-for-word user quote proving the preference/correction

HARD RULES:
- Maximum 2 memories. If you think you have 3, you have 0-1.
- Evidence must be a direct user quote. No evidence = no memory.
- When in doubt, return an empty memories array. Zero is correct and good.

Also return exactly one session_summary with: title (verb-first 8-15 word summary), \
investigated, learned, completed (list), next_steps.\
"""

_ANALYSIS_PROMPT = """\
<transcript>
{conversation}
</transcript>

{instructions}

Return ONLY the JSON object — no markdown fences, no explanation, no preamble.""".replace(
    "{instructions}", _INSTRUCTIONS
)
