"""
Conversation chunking and smart chunk selection for session analysis.

All providers go through `prepare_chunks(text, max_chars)`:
- If the text fits within max_chars → returned as-is (single chunk, no splitting).
- If it exceeds max_chars → split at message boundaries, then select the most
  signal-rich chunks (head + scored middle + tail).

CLI providers use a small max_chars (~4 KB) due to a known stdin bug in the
Claude/Codex CLIs. API providers use a large max_chars so chunking rarely fires,
but the same logic applies if it does.
"""
from __future__ import annotations

import json
import re

# ── Constants ─────────────────────────────────────────────────────────────────

HEAD_CHUNKS = 3
TAIL_CHUNKS = 2
MIDDLE_CHUNKS = 3  # top-scored by keyword density

# Matches User-turn lines that signal a correction or durable preference.
_SIGNAL_RE = re.compile(
    r"^User:.*\b("
    r"always|never|don't|dont|prefer|instead|"
    r"stop\s+using|stop\s+doing|use\s+\w+\s+not\s+\w+|"
    r"wrong|incorrect|actually|no[,.]|remember|"
    r"please\s+use|change\s+to|revert|fix\s+this|"
    r"not\s+that|do\s+not"
    r")\b",
    re.IGNORECASE | re.MULTILINE,
)


# ── Core functions ────────────────────────────────────────────────────────────

def _split_chunks(text: str, max_chars: int) -> list[str]:
    """Split *text* into segments ≤ max_chars, breaking at message boundaries."""
    chunks: list[str] = []
    while len(text) > max_chars:
        cut = max_chars
        for prefix in ("\nUser: ", "\nAI: "):
            pos = text.rfind(prefix, 0, max_chars)
            if pos > 0:
                cut = pos
                break
        chunks.append(text[:cut].strip())
        text = text[cut:].lstrip("\n")
    if text.strip():
        chunks.append(text.strip())
    return chunks


def _score_chunk(chunk: str) -> int:
    """Count preference/correction signals in *chunk* (User-turn lines only)."""
    return len(_SIGNAL_RE.findall(chunk))


def _select_chunks(
    chunks: list[str],
    head: int = HEAD_CHUNKS,
    tail: int = TAIL_CHUNKS,
    middle: int = MIDDLE_CHUNKS,
) -> list[str]:
    """
    Select the most relevant chunks from a list.

    - n ≤ head + tail          → return all
    - middle fits within budget → include all middle chunks
    - middle exceeds budget     → rank by signal density; fill gaps with
                                  evenly-spaced unsignalled chunks
    """
    n = len(chunks)
    if n <= head + tail:
        return chunks

    head_idx = set(range(head))
    tail_idx = set(range(n - tail, n))
    middle_indices = list(range(head, n - tail))

    if len(middle_indices) <= middle:
        top_middle = set(middle_indices)
    else:
        # Score each middle chunk once and cache — avoids triple regex invocation
        scores = {i: _score_chunk(chunks[i]) for i in middle_indices}
        scored = sorted(middle_indices, key=lambda i: scores[i], reverse=True)
        with_signal    = [i for i in scored if scores[i] > 0]
        without_signal = [i for i in scored if scores[i] == 0]

        selected_middle = with_signal[:middle]
        if len(selected_middle) < middle:
            gap  = middle - len(selected_middle)
            step = max(1, len(without_signal) // gap)
            selected_middle += without_signal[::step][:gap]

        top_middle = set(selected_middle)

    return [chunks[i] for i in sorted(head_idx | tail_idx | top_middle)]


def _merge_summaries(summaries: list[dict]) -> dict:
    """
    Combine per-chunk session summaries into one covering the full session.

    - title       : last chunk's title (most recent context)
    - investigated: all investigated texts joined into one paragraph
    - learned     : all learned texts joined into one paragraph
    - completed   : all completed items deduplicated, chronological order
    - next_steps  : last chunk's next_steps
    """
    if not summaries:
        return {"title": "session analyzed", "completed": []}
    if len(summaries) == 1:
        return summaries[0]

    investigated = " ".join(filter(None, (s.get("investigated") for s in summaries)))
    learned      = " ".join(filter(None, (s.get("learned")      for s in summaries)))
    next_steps   = summaries[-1].get("next_steps") or ""

    seen: set[str] = set()
    completed: list[str] = []
    for s in summaries:
        for item in (s.get("completed") or []):
            if item and item not in seen:
                seen.add(item)
                completed.append(item)

    return {
        "title":        summaries[-1].get("title", "session analyzed"),
        "investigated": investigated,
        "learned":      learned,
        "completed":    completed,
        "next_steps":   next_steps,
    }


def merge_chunk_responses(responses: list[str]) -> str:
    """
    Parse multiple raw chunk responses and merge into one JSON string.
    All memories are combined; all session summaries are merged into one.
    """
    all_memories: list[dict] = []
    all_summaries: list[dict] = []

    for raw in responses:
        if not raw or not raw.strip():
            continue
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            continue
        try:
            parsed = json.loads(match.group())
        except json.JSONDecodeError:
            continue
        all_memories.extend(parsed.get("memories") or [])
        if parsed.get("session_summary"):
            all_summaries.append(parsed["session_summary"])

    return json.dumps({
        "memories":        all_memories,
        "session_summary": _merge_summaries(all_summaries),
    })


def prepare_chunks(text: str, max_chars: int) -> list[str]:
    """
    Public entry point used by all providers.

    Returns ``[text]`` unchanged if it fits within *max_chars*.
    Otherwise splits and applies smart head+middle+tail selection.
    """
    if len(text) <= max_chars:
        return [text]
    return _select_chunks(_split_chunks(text, max_chars))
