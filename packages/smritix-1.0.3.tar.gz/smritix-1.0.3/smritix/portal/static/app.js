// ── Pending page helpers ──────────────────────────────────────────────────────

function showEdit(id) {
  document.getElementById('edit-' + id).style.display = 'block';
}

function submitEdit(id) {
  const content = document.getElementById('txt-' + id).value;
  htmx.ajax('POST', '/api/pending/' + id + '/confirm',
    { target: '#card-' + id, swap: 'outerHTML',
      values: { final_content: content } });
}

function showTab(id, tab, btn) {
  document.getElementById('tab-facts-' + id).style.display = tab === 'facts' ? '' : 'none';
  document.getElementById('tab-narrative-' + id).style.display = tab === 'narrative' ? '' : 'none';
  btn.parentElement.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
  btn.classList.add('active');
}

// ── Auto-init memories page when DOM is ready ────────────────────────────────

document.addEventListener('DOMContentLoaded', function () {
  if (document.getElementById('mem-container')) {
    loadMemories();
  }
});

// ── Memories page ─────────────────────────────────────────────────────────────

const OBS_LABELS = {
  change: 'CHANGE', discovery: 'DISCOVERY', feature: 'FEATURE',
  bug_fix: 'BUG FIX', correction: 'CORRECTION', preference: 'PREFERENCE',
  session_summary: 'SESSION SUMMARY',
};

const OBS_ORDER = [
  'session_summary', 'change', 'feature', 'bug_fix',
  'discovery', 'correction', 'preference',
];

let _searchTimer = null;
let _allMemories = [];
let _activeProject = null;
const _memCache = {};  // id → memory dict, populated on render

function debounceSearch(val) {
  clearTimeout(_searchTimer);
  _searchTimer = setTimeout(() => {
    if (val.trim().length > 1) {
      runSearch(val.trim());
    } else if (val.trim().length === 0) {
      clearSearch();
    }
  }, 350);
}

function clearSearch() {
  document.getElementById('search-input').value = '';
  document.getElementById('clear-btn').style.display = 'none';
  const filtered = _activeProject
    ? _allMemories.filter(m => _projectName(m) === _activeProject)
    : _allMemories;
  renderGrouped(filtered);
  document.getElementById('mem-count').textContent = _countLabel(filtered);
}

function filterByProject(name) {
  _activeProject = (_activeProject === name) ? null : name;  // toggle
  document.querySelectorAll('.proj-chip').forEach(el => {
    el.classList.toggle('active', el.dataset.project === _activeProject);
  });
  const filtered = _activeProject
    ? _allMemories.filter(m => _projectName(m) === _activeProject)
    : _allMemories;
  renderGrouped(filtered);
  document.getElementById('mem-count').textContent = _countLabel(filtered);
}

function _projectName(m) {
  return (m.project_path || '').replace(/\/$/, '').split('/').pop();
}

function _countLabel(mems) {
  const label = mems.length + ' memor' + (mems.length === 1 ? 'y' : 'ies');
  return _activeProject ? label + ' in ' + _activeProject : label;
}

function loadMemories() {
  fetch('/api/memories')
    .then(r => r.json())
    .then(data => {
      _allMemories = data.memories || [];
      document.getElementById('mem-count').textContent = _countLabel(_allMemories);
      renderGrouped(_allMemories);
    });
}

function runSearch(q) {
  document.getElementById('clear-btn').style.display = '';
  document.getElementById('mem-count').textContent = 'Searching…';
  fetch('/api/memories/search?q=' + encodeURIComponent(q) + '&limit=30')
    .then(r => r.json())
    .then(data => {
      const mems = data.memories || [];
      document.getElementById('mem-count').textContent =
        mems.length + ' result' + (mems.length !== 1 ? 's' : '') + ' for "' + q + '"';
      renderFlat(mems, true);
    });
}

function renderGrouped(memories) {
  const container = document.getElementById('mem-container');
  if (!memories.length) {
    container.innerHTML = '<p class="empty">No memories yet. Confirm some from the <a href="/" style="color:#4f8ef7">Pending</a> queue to see them here.</p>';
    return;
  }

  // Build project summary bar
  const projects = {};
  memories.forEach(m => {
    const p = m.project_path ? m.project_path.replace(/\/$/, '').split('/').pop() : 'unknown';
    projects[p] = (projects[p] || 0) + 1;
  });
  const projectBar = Object.entries(projects).length > 0
    ? `<div class="project-bar">` +
      Object.entries(projects).map(([p, n]) =>
        `<span class="proj-chip${_activeProject === p ? ' active' : ''}"
              data-project="${esc(p)}"
              onclick="filterByProject('${esc(p)}')"
              title="Filter to ${esc(p)}">${esc(p)} <b>${n}</b></span>`
      ).join('') + `</div>`
    : '';

  // Group by obs_type
  const groups = {};
  memories.forEach(m => {
    const g = m.obs_type || 'discovery';
    if (!groups[g]) groups[g] = [];
    groups[g].push(m);
  });

  const groupHtml = OBS_ORDER
    .filter(k => groups[k])
    .map(k => {
      const items = groups[k].map(m => memoryCard(m, false)).join('');
      const linked = groups[k].filter(m => (m.link_count || 0) > 0).length;
      const linkNote = linked ? `<span class="group-linked">🔗 ${linked} linked</span>` : '';
      return `<div class="group-section">
        <div class="group-header">
          ${OBS_LABELS[k] || k.toUpperCase()}
          <span class="group-count">${groups[k].length}</span>
          ${linkNote}
        </div>
        ${items}
      </div>`;
    })
    .join('');

  container.innerHTML = projectBar + (groupHtml || '<p class="empty">No memories yet.</p>');
}

function renderFlat(memories, showScore) {
  const container = document.getElementById('mem-container');
  if (!memories.length) {
    container.innerHTML = '<p class="empty">No results.</p>';
    return;
  }
  container.innerHTML = memories.map(m => memoryCard(m, showScore)).join('');
}

function memoryCard(m, showScore) {
  _memCache[m.id] = m;  // store for edit lookup — avoids HTML encoding issues
  const project = m.project_path ? m.project_path.replace(/\/$/, '').split('/').pop() : '';
  const tool = (m.source_tool || '').replace(/_/g, ' ');
  const date = m.created_at ? m.created_at.slice(0, 16).replace('T', ' ') : '';
  const scoreBadge = showScore && m.score_pct !== undefined
    ? `<span class="score-badge">${m.score_pct}%</span>` : '';

  const linkBadge = (m.link_count || 0) > 0
    ? `<span class="link-badge" title="Related memories">🔗 ${m.link_count}</span>` : '';

  const facts = (m.facts || []).length
    ? `<ul class="facts-list">${(m.facts || []).map(f => `<li>${esc(f)}</li>`).join('')}</ul>` : '';

  const tags = (m.tags || []).length
    ? `<div class="tags">${m.tags.map(t => `<span class="tag">${esc(t)}</span>`).join('')}</div>` : '';

  const evidence = m.evidence
    ? `<p class="evidence">"${esc(m.evidence)}"</p>` : '';

  const files = (m.files_mentioned || []).length
    ? m.files_mentioned.map(f => `<code>${esc(f.split('/').pop())}</code>`).join(' ') : '';

  // Session summary special rendering
  // Fields are stored as: narrative (investigated+learned), facts (completed), evidence (next_steps)
  if (m.obs_type === 'session_summary') {
    const inv = m.narrative ? `<div class="ss-section"><span class="ss-label">SUMMARY</span><p>${esc(m.narrative)}</p></div>` : '';
    const lrn = '';
    const comp = (m.facts || []).length
      ? `<div class="ss-section"><span class="ss-label">COMPLETED</span><ul>${m.facts.map(c => `<li>${esc(c)}</li>`).join('')}</ul></div>` : '';
    const ns = m.evidence ? `<div class="ss-section"><span class="ss-label">NEXT STEPS</span><p>${esc(m.evidence)}</p></div>` : '';
    return `
      <div class="card card-session-summary" id="mem-${m.id}">
        <div class="meta">
          <span class="type obs-session_summary">SESSION SUMMARY</span>
          ${tool ? `<span class="source-tool">${esc(tool.toUpperCase())}</span>` : ''}
          ${project ? `<span class="project-name">${esc(project)}</span>` : ''}
          ${scoreBadge}${linkBadge}
          <span class="mem-date">${date}</span>
        </div>
        <h3 class="memory-title">${esc(m.title)}</h3>
        ${inv}${lrn}${comp}${ns}
        <div class="mem-actions">
          <button class="btn-edit-mem" onclick="startEditMem('${m.id}')">Edit</button>
          <button class="btn-del-mem" onclick="deleteMem('${m.id}')">Delete</button>
        </div>
        <div id="edit-mem-${m.id}" class="inline-edit" style="display:none">
          <input id="edit-title-${m.id}" class="edit-title-input" value="${esc(m.title)}" />
          <textarea id="edit-narr-${m.id}" class="edit-narr-input">${esc(m.narrative || '')}</textarea>
          <div class="edit-actions">
            <button class="btn-approve" onclick="saveMem('${m.id}')">Save</button>
            <button class="btn-edit-mem" onclick="cancelEditMem('${m.id}')">Cancel</button>
          </div>
        </div>
      </div>`;
  }

  const narrative = m.narrative
    ? `<p class="narrative">${esc(m.narrative)}</p>` : '';

  return `
    <div class="card mem-card" id="mem-${m.id}">
      <div class="meta">
        <span class="type obs-${m.obs_type || 'discovery'}">${OBS_LABELS[m.obs_type] || (m.obs_type || '').toUpperCase()}</span>
        <span class="type type-${m.type || 'context'}">${(m.type || '').replace(/_/g, ' ')}</span>
        ${tool ? `<span class="source-tool">${esc(tool.toUpperCase())}</span>` : ''}
        ${project ? `<span class="project-name">${esc(project)}</span>` : ''}
        ${scoreBadge}${linkBadge}
        <span class="mem-date">${date}</span>
      </div>

      <div class="mem-view" id="view-${m.id}">
        <h3 class="memory-title">${esc(m.title)}</h3>
        ${facts}
        ${narrative}
        ${tags}
        ${evidence}
        ${files ? `<div class="meta-footer">${files}</div>` : ''}
      </div>

      <div id="edit-mem-${m.id}" class="inline-edit" style="display:none">
        <input id="edit-title-${m.id}" class="edit-title-input" value="${esc(m.title)}" />
        <textarea id="edit-narr-${m.id}" class="edit-narr-input">${esc(m.narrative || '')}</textarea>
        <div class="edit-actions">
          <button class="btn-approve" onclick="saveMem('${m.id}')">Save</button>
          <button class="btn-edit-mem" onclick="cancelEditMem('${m.id}')">Cancel</button>
        </div>
      </div>

      <div class="mem-actions">
          <button class="btn-edit-mem" onclick="startEditMem('${m.id}')">Edit</button>
        <button class="btn-del-mem" onclick="deleteMem('${m.id}')">Delete</button>
      </div>
    </div>`;
}

function esc(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function startEditMem(id) {
  const card = document.getElementById('mem-' + id);
  if (!card) return;
  const mem = _memCache[id];
  if (!mem) return;
  const title     = mem.title     || '';
  const narrative = mem.narrative || '';
  const evidence  = mem.evidence  || '';
  const tags      = (mem.tags  || []).join(', ');
  const facts     = (mem.facts || []).join('\n');
  card.innerHTML =
    '<div class="inline-edit">' +
    '<label class="edit-field-label">Title</label>' +
    '<input id="et-' + id + '" class="edit-title-input" value="' + esc(title) + '" />' +
    '<label class="edit-field-label">Narrative</label>' +
    '<textarea id="en-' + id + '" class="edit-narr-input">' + esc(narrative) + '</textarea>' +
    '<label class="edit-field-label">Evidence (user quote)</label>' +
    '<textarea id="ee-' + id + '" class="edit-narr-input" rows="2">' + esc(evidence) + '</textarea>' +
    '<label class="edit-field-label">Facts (one per line)</label>' +
    '<textarea id="ef-' + id + '" class="edit-narr-input" rows="3">' + esc(facts) + '</textarea>' +
    '<label class="edit-field-label">Tags (comma-separated)</label>' +
    '<input id="eg-' + id + '" class="edit-title-input" value="' + esc(tags) + '" />' +
    '<div class="edit-actions">' +
    '<button class="btn-approve" onclick="saveMem(\'' + id + '\')">Save</button>' +
    '<button class="btn-edit-mem" onclick="loadMemories()">Cancel</button>' +
    '</div></div>';
  var inp = document.getElementById('et-' + id);
  if (inp) { inp.focus(); inp.select(); }
}

function saveMem(id) {
  const titleEl    = document.getElementById('et-' + id);
  const narrEl     = document.getElementById('en-' + id);
  const evidenceEl = document.getElementById('ee-' + id);
  const factsEl    = document.getElementById('ef-' + id);
  const tagsEl     = document.getElementById('eg-' + id);
  if (!titleEl) { loadMemories(); return; }
  const title     = titleEl.value.trim();
  const narrative = narrEl     ? narrEl.value.trim()     : '';
  const evidence  = evidenceEl ? evidenceEl.value.trim() : '';
  const facts     = factsEl    ? factsEl.value.split('\n').map(s => s.trim()).filter(Boolean) : [];
  const tags      = tagsEl     ? tagsEl.value.split(',').map(s => s.trim()).filter(Boolean)   : [];
  if (!title) { alert('Title cannot be empty.'); return; }

  fetch('/api/memories/' + id, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, narrative, evidence, facts, tags }),
  })
    .then(r => {
      if (!r.ok) throw new Error('Update failed');
      const mem = _allMemories.find(m => m.id === id);
      if (mem) {
        Object.assign(mem, { title, narrative, evidence, facts, tags });
        if (_memCache[id]) Object.assign(_memCache[id], { title, narrative, evidence, facts, tags });
      }
      loadMemories();
    })
    .catch(() => alert('Failed to save. Try again.'));
}

function deleteMem(id) {
  const mem = _allMemories.find(m => m.id === id);
  const label = mem ? `"${mem.title.slice(0, 60)}"` : 'this memory';
  if (!confirm('Delete ' + label + '?')) return;

  fetch('/api/memories/' + id, { method: 'DELETE' })
    .then(r => {
      if (!r.ok) throw new Error('Delete failed');
      document.getElementById('mem-' + id).remove();
      _allMemories = _allMemories.filter(m => m.id !== id);
      document.getElementById('mem-count').textContent = _allMemories.length + ' memories';
      // Remove empty group headers
      document.querySelectorAll('.group-section').forEach(g => {
        if (!g.querySelector('.mem-card, .card-session-summary')) g.remove();
      });
    })
    .catch(() => alert('Failed to delete. Try again.'));
}
