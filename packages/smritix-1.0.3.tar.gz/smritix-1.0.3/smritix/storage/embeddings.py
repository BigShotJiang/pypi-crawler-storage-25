import duckdb

from smritix.config import HOT_THRESHOLD, EMBEDDING_DIM

_SEARCH_SQL = f"""
WITH cold_hits AS (
    SELECT memory_id,
           array_cosine_similarity(embedding, $1::FLOAT[{EMBEDDING_DIM}]) AS similarity
    FROM cold_embeddings
    ORDER BY similarity DESC
    LIMIT $2
),
hot_hits AS (
    SELECT memory_id,
           array_cosine_similarity(embedding, $1::FLOAT[{EMBEDDING_DIM}]) AS similarity
    FROM hot_embeddings
    ORDER BY similarity DESC
    LIMIT $2
)
SELECT memory_id, similarity
FROM (SELECT * FROM cold_hits UNION ALL SELECT * FROM hot_hits)
ORDER BY similarity DESC
LIMIT $2
"""


def insert_hot(
    conn: duckdb.DuckDBPyConnection, memory_id: str, embedding: list[float]
) -> None:
    conn.execute(
        "INSERT INTO hot_embeddings (memory_id, embedding) VALUES (?, ?)",
        [memory_id, embedding],
    )


def hot_count(conn: duckdb.DuckDBPyConnection) -> int:
    return conn.execute("SELECT COUNT(*) FROM hot_embeddings").fetchone()[0]


def search(
    conn: duckdb.DuckDBPyConnection,
    query_vec: list[float],
    limit: int = 20,
) -> list[dict]:
    """
    Union search: cold uses HNSW index, hot uses brute-force (small by design).
    Returns list of {memory_id, similarity} sorted by similarity descending.
    """
    rows = conn.execute(_SEARCH_SQL, [query_vec, limit]).fetchall()
    return [{"memory_id": row[0], "similarity": row[1]} for row in rows]


def merge_hot_to_cold(conn: duckdb.DuckDBPyConnection) -> None:
    """Move all hot embeddings to cold and rebuild HNSW index."""
    conn.execute("INSERT INTO cold_embeddings SELECT * FROM hot_embeddings")
    conn.execute("DELETE FROM hot_embeddings")
    _rebuild_hnsw(conn)


def maybe_merge(conn: duckdb.DuckDBPyConnection) -> bool:
    """Merge hot → cold when hot reaches HOT_THRESHOLD. Returns True if merged."""
    if hot_count(conn) >= HOT_THRESHOLD:
        merge_hot_to_cold(conn)
        return True
    return False


def _rebuild_hnsw(conn: duckdb.DuckDBPyConnection) -> None:
    # Rebuild HNSW index on cold_embeddings. DROP + CREATE is not atomic;
    # queries between the two fall back to brute-force scan (DuckDB handles gracefully).
    cold = conn.execute("SELECT COUNT(*) FROM cold_embeddings").fetchone()[0]
    if cold == 0:
        return
    conn.execute("BEGIN")
    try:
        conn.execute("DROP INDEX IF EXISTS idx_cold_hnsw")
        conn.execute(
            "CREATE INDEX idx_cold_hnsw ON cold_embeddings "
            "USING HNSW (embedding) WITH (metric = 'cosine')"
        )
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise
