import uuid
import duckdb


def create_link(
    conn: duckdb.DuckDBPyConnection,
    source_id: str,
    target_id: str,
    link_type: str,
    strength: float,
) -> str:
    lid = str(uuid.uuid4())
    conn.execute(
        "INSERT INTO memory_links (id, source_id, target_id, link_type, strength) "
        "VALUES (?, ?, ?, ?, ?)",
        [lid, source_id, target_id, link_type, strength],
    )
    return lid


def get_links(conn: duckdb.DuckDBPyConnection, memory_id: str) -> list[dict]:
    rows = conn.execute(
        """
        SELECT id, source_id, target_id, link_type, strength
        FROM memory_links
        WHERE source_id=? OR target_id=?
        ORDER BY strength DESC
        """,
        [memory_id, memory_id],
    ).fetchall()
    return [
        {"id": r[0], "source_id": r[1], "target_id": r[2],
         "link_type": r[3], "strength": r[4]}
        for r in rows
    ]


def get_graph(conn: duckdb.DuckDBPyConnection) -> dict:
    mem_rows = conn.execute(
        "SELECT id, title, type, obs_type, source_tool, project_path "
        "FROM memories WHERE is_archived=false"
    ).fetchall()
    nodes = [
        {"id": r[0], "content": r[1], "type": r[2], "obs_type": r[3],
         "source_tool": r[4], "project_path": r[5]}
        for r in mem_rows
    ]

    node_ids = {n["id"] for n in nodes}

    edge_rows = conn.execute(
        "SELECT id, source_id, target_id, link_type, strength FROM memory_links"
    ).fetchall()
    # Only include edges where both endpoints are visible (non-archived) nodes.
    edges = [
        {"id": r[0], "source": r[1], "target": r[2],
         "link_type": r[3], "strength": r[4]}
        for r in edge_rows
        if r[1] in node_ids and r[2] in node_ids
    ]
    return {"nodes": nodes, "edges": edges}
