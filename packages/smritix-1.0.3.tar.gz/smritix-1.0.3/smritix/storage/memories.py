import json
import uuid
import duckdb


def _next_seq(conn: duckdb.DuckDBPyConnection) -> int:
    row = conn.execute("SELECT COALESCE(MAX(seq_num), 0) + 1 FROM memories").fetchone()
    return row[0]


def insert_pending(
    conn: duckdb.DuckDBPyConnection,
    title: str,
    obs_type: str,
    type_: str,
    facts: list[str],
    narrative: str,
    tags: list[str],
    files_mentioned: list[str],
    confidence: float,
    evidence: str,
    source_session_id: str,
    source_tool: str | None = None,
    project_path: str | None = None,
    investigated: str | None = None,
    learned: str | None = None,
    completed: list[str] | None = None,
    next_steps: str | None = None,
) -> str:
    pid = str(uuid.uuid4())
    conn.execute(
        """
        INSERT INTO pending_memories (
            id, title, obs_type, type, facts, narrative, tags, files_mentioned,
            investigated, learned, completed, next_steps,
            project_path, source_session_id, source_tool,
            confidence, evidence, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        """,
        [
            pid, title, obs_type, type_,
            json.dumps(facts), narrative,
            json.dumps(tags), json.dumps(files_mentioned),
            investigated, learned, json.dumps(completed or []), next_steps,
            project_path, source_session_id, source_tool,
            confidence, evidence,
        ],
    )
    return pid


def confirm_memory(
    conn: duckdb.DuckDBPyConnection, pending_id: str, edited_title: str | None = None
) -> str:
    row = conn.execute(
        """SELECT title, obs_type, type, facts, narrative, tags, files_mentioned,
                  investigated, learned, completed, next_steps,
                  project_path, source_session_id, source_tool, confidence, evidence
           FROM pending_memories WHERE id=?""",
        [pending_id],
    ).fetchone()
    if row is None:
        raise ValueError(f"Pending memory {pending_id} not found")

    (title, obs_type, type_, facts, narrative, tags, files_mentioned,
     investigated, learned, completed, next_steps,
     project_path, session_id, source_tool, confidence, evidence) = row

    mid = str(uuid.uuid4())
    seq = _next_seq(conn)
    conn.execute(
        """
        INSERT INTO memories (
            id, seq_num, title, obs_type, type, facts, narrative, tags, files_mentioned,
            investigated, learned, completed, next_steps,
            project_path, source_session_id, source_tool,
            confidence, evidence, confirmed_by_user
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, true)
        """,
        [
            mid, seq,
            edited_title or title, obs_type, type_,
            facts, narrative, tags, files_mentioned,
            investigated, learned, completed, next_steps,
            project_path, session_id, source_tool,
            confidence, evidence,
        ],
    )
    conn.execute("UPDATE pending_memories SET status='approved' WHERE id=?", [pending_id])
    return mid


def reject_memory(conn: duckdb.DuckDBPyConnection, pending_id: str) -> None:
    row = conn.execute("SELECT id FROM pending_memories WHERE id=?", [pending_id]).fetchone()
    if row is None:
        raise ValueError(f"Pending memory {pending_id} not found")
    conn.execute("UPDATE pending_memories SET status='rejected' WHERE id=?", [pending_id])


def get_memory(conn: duckdb.DuckDBPyConnection, memory_id: str) -> dict | None:
    row = conn.execute(
        """SELECT id, seq_num, title, obs_type, type, facts, narrative, tags, files_mentioned,
                  investigated, learned, completed, next_steps,
                  project_path, source_session_id, source_tool,
                  confidence, evidence, confirmed_by_user,
                  access_count, is_archived, created_at, last_accessed
           FROM memories WHERE id=?""",
        [memory_id],
    ).fetchone()
    if row is None:
        return None
    return _row_to_dict(row)


def list_pending(conn: duckdb.DuckDBPyConnection) -> list[dict]:
    rows = conn.execute(
        """SELECT id, title, obs_type, type, facts, narrative, tags, files_mentioned,
                  investigated, learned, completed, next_steps,
                  project_path, source_session_id, source_tool,
                  confidence, evidence, created_at
           FROM pending_memories WHERE status='pending'
           ORDER BY created_at DESC"""
    ).fetchall()
    return [_pending_row_to_dict(r) for r in rows]


def get_pending_content(conn: duckdb.DuckDBPyConnection, pending_id: str) -> dict | None:
    row = conn.execute(
        "SELECT title, narrative FROM pending_memories WHERE id=?", [pending_id]
    ).fetchone()
    if row is None:
        return None
    return {"title": row[0], "narrative": row[1]}


def archive_memory(conn: duckdb.DuckDBPyConnection, memory_id: str) -> None:
    conn.execute("UPDATE memories SET is_archived=true WHERE id=?", [memory_id])


def increment_access(conn: duckdb.DuckDBPyConnection, memory_id: str) -> None:
    conn.execute(
        "UPDATE memories SET access_count=access_count+1, last_accessed=now() WHERE id=?",
        [memory_id],
    )


def _row_to_dict(row) -> dict:
    return {
        "id": row[0], "seq_num": row[1], "title": row[2],
        "obs_type": row[3], "type": row[4],
        "facts": json.loads(row[5]) if row[5] else [],
        "narrative": row[6],
        "tags": json.loads(row[7]) if row[7] else [],
        "files_mentioned": json.loads(row[8]) if row[8] else [],
        "investigated": row[9], "learned": row[10],
        "completed": json.loads(row[11]) if row[11] else [],
        "next_steps": row[12],
        "project_path": row[13], "source_session_id": row[14], "source_tool": row[15],
        "confidence": row[16], "evidence": row[17],
        "confirmed_by_user": row[18],
        "access_count": row[19], "is_archived": row[20],
        "created_at": str(row[21]),
        "last_accessed": str(row[22]) if row[22] else None,
    }


def _pending_row_to_dict(row) -> dict:
    return {
        "id": row[0], "title": row[1], "obs_type": row[2], "type": row[3],
        "facts": json.loads(row[4]) if row[4] else [],
        "narrative": row[5],
        "tags": json.loads(row[6]) if row[6] else [],
        "files_mentioned": json.loads(row[7]) if row[7] else [],
        "investigated": row[8], "learned": row[9],
        "completed": json.loads(row[10]) if row[10] else [],
        "next_steps": row[11],
        "project_path": row[12], "source_session_id": row[13], "source_tool": row[14],
        "confidence": row[15], "evidence": row[16],
        "created_at": str(row[17]),
    }
