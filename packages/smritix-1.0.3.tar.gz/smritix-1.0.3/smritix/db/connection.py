import logging
import os

import duckdb

from smritix.config import DATA_DIR, DB_PATH

_conn: duckdb.DuckDBPyConnection | None = None
_PID_FILE = DATA_DIR / "smritix.pid"

logger = logging.getLogger(__name__)


def write_pid() -> None:
    """Write current PID to the PID file. Call on MCP/serve startup."""
    try:
        _PID_FILE.write_text(str(os.getpid()))
    except OSError:
        pass


def clear_pid() -> None:
    """Remove the PID file on clean shutdown."""
    try:
        _PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _kill_stale_smritix() -> bool:
    """
    Check if a stale smritix process holds the lock. If so, kill it and return True.
    Returns False if no stale process found or kill failed.
    """
    if not _PID_FILE.exists():
        return False
    try:
        old_pid = int(_PID_FILE.read_text().strip())
    except (ValueError, OSError):
        return False

    if old_pid == os.getpid():
        return False  # that's us

    try:
        # Check the process is still running and is a smritix process
        with open(f"/proc/{old_pid}/cmdline", "rb") as f:
            cmdline = f.read().decode(errors="replace")
        is_smritix = "smritix" in cmdline
    except (FileNotFoundError, OSError):
        # /proc not available (macOS) — use psutil-free approach via ps
        try:
            import subprocess
            result = subprocess.run(
                ["ps", "-p", str(old_pid), "-o", "command="],
                capture_output=True, text=True, timeout=3,
            )
            is_smritix = "smritix" in result.stdout
        except Exception:
            # Can't verify — kill it anyway (PID file means it was smritix)
            is_smritix = True

    if not is_smritix:
        return False

    # Only kill if the process is no longer actively running (stale/dead PID file)
    if _is_process_active(old_pid):
        # Process is alive — it's a concurrent session, not a stale orphan
        # Caller will fall back to read-only instead
        logger.info(
            "smritix process PID %d is still active (concurrent session). "
            "Will open read-only connection.",
            old_pid,
        )
        return False

    # Process is gone but PID file and lock remain — clean up
    logger.warning(
        "Stale smritix PID file (PID %d no longer running) — cleaning up.",
        old_pid,
    )
    clear_pid()
    return True


def _is_process_active(pid: int) -> bool:
    """Return True if the process is running right now."""
    try:
        os.kill(pid, 0)  # signal 0 = just check existence
        return True
    except (ProcessLookupError, PermissionError):
        return False


def get_connection(path: str | None = None) -> duckdb.DuckDBPyConnection:
    global _conn
    if path is not None:
        conn = duckdb.connect(path)
        _load_extensions(conn)
        return conn
    if _conn is None:
        try:
            _conn = duckdb.connect(str(DB_PATH))
        except duckdb.IOException as exc:
            # Determine whether the holding process is stale or actively running
            stale = _kill_stale_smritix()
            if stale:
                # Was stale (orphan) — retry with write access
                logger.info("Stale smritix process cleared — retrying DB connection.")
                try:
                    _conn = duckdb.connect(str(DB_PATH))
                except duckdb.IOException as exc2:
                    raise RuntimeError(
                        f"\nCould not acquire DB lock even after clearing stale process.\n"
                        f"  • Stop all smritix processes and retry.\n"
                        f"  (Original error: {exc2})"
                    ) from exc2
            else:
                # Another active session holds the lock — open read-only so
                # memory retrieval still works; writes will fail gracefully.
                logger.warning(
                    "Another smritix process holds the DB write lock. "
                    "Opening read-only — get_memories works, add_memory/save_drafts will not."
                )
                try:
                    _conn = duckdb.connect(str(DB_PATH), read_only=True)
                except Exception:
                    raise RuntimeError(
                        f"\nAnother Smritix process is already running and holds the database lock.\n"
                        f"  • If smritix serve is running, the portal is already at http://localhost:{_get_web_port()}\n"
                        f"  • Stop the other process first, then retry.\n"
                        f"  (Original error: {exc})"
                    ) from exc
        except duckdb.InternalException:
            # Corrupted WAL from an unclean shutdown — delete it and retry once
            wal = DB_PATH.with_suffix(".duckdb.wal")
            if wal.exists():
                logger.warning("Corrupted WAL file detected, removing and retrying: %s", wal)
                wal.unlink()
                _conn = duckdb.connect(str(DB_PATH))
            else:
                raise
        _load_extensions(_conn)
    return _conn


def _get_web_port() -> int:
    try:
        from smritix.config import MCP_PORT
        return MCP_PORT
    except Exception:
        return 8666


def _load_extensions(conn: duckdb.DuckDBPyConnection) -> None:
    row = conn.execute(
        "SELECT installed FROM duckdb_extensions() WHERE extension_name = 'vss'"
    ).fetchone()
    if row is None or not row[0]:
        conn.execute("INSTALL vss")
    conn.execute("LOAD vss")
    # Required for HNSW indexes on persistent (non-memory) databases
    conn.execute("SET hnsw_enable_experimental_persistence = true")
