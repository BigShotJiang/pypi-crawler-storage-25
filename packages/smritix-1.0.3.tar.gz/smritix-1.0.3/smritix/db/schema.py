import duckdb

from smritix.config import EMBEDDING_DIM


def create_schema(conn: duckdb.DuckDBPyConnection) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id              TEXT PRIMARY KEY,
            file_path       TEXT NOT NULL,
            tool            TEXT,
            project_path    TEXT,
            session_number  INTEGER,
            last_processed  TIMESTAMPTZ,
            summary         TEXT,
            created_at      TIMESTAMPTZ DEFAULT now()
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS pending_memories (
            id              TEXT PRIMARY KEY,
            title           TEXT NOT NULL,
            obs_type        TEXT NOT NULL,
            type            TEXT NOT NULL,
            facts           TEXT DEFAULT '[]',
            narrative       TEXT,
            tags            TEXT DEFAULT '[]',
            files_mentioned TEXT DEFAULT '[]',
            investigated    TEXT,
            learned         TEXT,
            completed       TEXT DEFAULT '[]',
            next_steps      TEXT,
            project_path    TEXT,
            source_session_id TEXT,
            source_tool     TEXT,
            confidence      REAL DEFAULT 0.8,
            evidence        TEXT,
            created_at      TIMESTAMPTZ DEFAULT now(),
            status          TEXT DEFAULT 'pending'
        )
    """)

    conn.execute("""
        CREATE SEQUENCE IF NOT EXISTS memory_seq START 1
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id              TEXT PRIMARY KEY,
            seq_num         INTEGER DEFAULT nextval('memory_seq'),
            title           TEXT NOT NULL,
            obs_type        TEXT NOT NULL,
            type            TEXT NOT NULL,
            facts           TEXT DEFAULT '[]',
            narrative       TEXT,
            tags            TEXT DEFAULT '[]',
            files_mentioned TEXT DEFAULT '[]',
            investigated    TEXT,
            learned         TEXT,
            completed       TEXT DEFAULT '[]',
            next_steps      TEXT,
            project_path    TEXT,
            source_session_id TEXT,
            source_tool     TEXT,
            confidence      REAL DEFAULT 0.8,
            evidence        TEXT,
            confirmed_by_user BOOLEAN DEFAULT false,
            access_count    INTEGER DEFAULT 0,
            is_archived     BOOLEAN DEFAULT false,
            created_at      TIMESTAMPTZ DEFAULT now(),
            last_accessed   TIMESTAMPTZ
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS memory_links (
            id          TEXT PRIMARY KEY,
            source_id   TEXT REFERENCES memories(id),
            target_id   TEXT REFERENCES memories(id),
            link_type   TEXT NOT NULL,
            strength    REAL NOT NULL,
            created_at  TIMESTAMPTZ DEFAULT now()
        )
    """)

    conn.execute(f"""
        CREATE TABLE IF NOT EXISTS hot_embeddings (
            memory_id   TEXT NOT NULL,
            embedding   FLOAT[{EMBEDDING_DIM}] NOT NULL
        )
    """)

    conn.execute(f"""
        CREATE TABLE IF NOT EXISTS cold_embeddings (
            memory_id   TEXT NOT NULL,
            embedding   FLOAT[{EMBEDDING_DIM}] NOT NULL
        )
    """)

    # ── Sync state (replaces ~/.smritix/checkpoints/*.json) ───────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sync_state (
            id              TEXT PRIMARY KEY,   -- 'incremental' or 'historical'
            job_type        TEXT NOT NULL,       -- 'incremental' | 'historical'
            status          TEXT NOT NULL,       -- 'pending'|'running'|'completed'|'failed'
            start_time      TIMESTAMPTZ NOT NULL,
            end_time        TIMESTAMPTZ,         -- NULL for incremental (open-ended)
            global_cursor   TIMESTAMPTZ NOT NULL,-- current scan position
            created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
            updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS session_cursors (
            session_id        TEXT PRIMARY KEY,  -- '<tool>:<file_stem>'
            tool              TEXT NOT NULL,      -- 'claude_code' | 'codex'
            last_msg_time     TIMESTAMPTZ NOT NULL,
            processed_count   INTEGER NOT NULL,   -- guards against same-second timestamps
            updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
        )
    """)

