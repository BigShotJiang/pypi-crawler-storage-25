"""
AI provider package — one file per provider under smritix/providers/.

To add a new provider:
  1. Create smritix/providers/api_myprovider.py
  2. Extend AIProvider, implement analyze() and name()
  3. Register in smritix/providers/registry.py _REGISTRY dict

Public interface (also re-exported from smritix.providers for backward compat):
"""
from smritix.providers.base import AIProvider, ProviderValidationError
from smritix.providers.registry import get_provider, get_provider_chain

# Individual provider classes (for tests and type hints)
from smritix.providers.api_anthropic import AnthropicProvider
from smritix.providers.api_gemini import GeminiProvider
from smritix.providers.api_ollama import OllamaProvider
from smritix.providers.api_openai import OpenAIProvider
from smritix.providers.sub_claude import ClaudeCliProvider
from smritix.providers.sub_codex import CodexCliProvider

__all__ = [
    "AIProvider",
    "ProviderValidationError",
    "get_provider",
    "get_provider_chain",
    "AnthropicProvider",
    "GeminiProvider",
    "OllamaProvider",
    "OpenAIProvider",
    "ClaudeCliProvider",
    "CodexCliProvider",
]
