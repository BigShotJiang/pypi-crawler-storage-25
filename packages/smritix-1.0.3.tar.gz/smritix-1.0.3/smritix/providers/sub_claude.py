"""Claude Code CLI provider (subscription — no API key needed)."""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess

from smritix.providers.base import AIProvider, ProviderValidationError
from smritix.drafter.prompt import _ANALYSIS_PROMPT, MEMORY_JSON_SCHEMA_STR
from smritix.drafter.chunker import prepare_chunks, merge_chunk_responses

logger = logging.getLogger(__name__)

# The Claude Code CLI has a known bug (Issue #7263): stdin > ~7000 chars returns empty output.
# Keep each chunk well below that limit (prompt template adds ~1 KB overhead).
_CHUNK_CHARS = 4_000

_SYSTEM_PROMPT = (
    "You are a JSON extraction assistant. "
    "Analyze developer AI session transcripts as an outside observer. "
    "You are NOT a participant in those conversations. "
    "Return ONLY valid JSON — no markdown, no explanation, no preamble."
)


class ClaudeCliProvider(AIProvider):
    """
    Calls `claude --print` as a subprocess. Requires Claude Code CLI installed.

    Large sessions are split into ~4 KB chunks (below the CLI's ~7 KB stdin bug
    threshold). Up to 15 chunks are selected: first 5, last 5, and up to 5 from the
    middle ranked by preference/correction keyword density.
    """

    @classmethod
    def name(cls) -> str:
        return "sub_claude"

    def analyze(self, conversation_text: str) -> str:
        model = os.environ.get("SMRITIX_DRAFTER_MODEL") or self.default_model()

        selected = prepare_chunks(conversation_text, _CHUNK_CHARS)

        logger.info(
            "sub_claude: conversation %d chars → %d chunk(s) selected (max %d chars each)",
            len(conversation_text), len(selected), _CHUNK_CHARS,
        )

        responses: list[str] = []
        for i, chunk in enumerate(selected):
            logger.debug("sub_claude: chunk %d/%d (%d chars) model %s", i + 1, len(selected), len(chunk), model)
            try:
                raw = self._call_cli(chunk, model)
                unwrapped = self._unwrap_envelope(raw)
                logger.debug(
                    "sub_claude: chunk %d/%d response (%d chars):\n%s",
                    i + 1, len(selected), len(unwrapped), unwrapped,
                )
                responses.append(unwrapped)
            except RuntimeError as exc:
                logger.warning("sub_claude: chunk %d/%d failed: %s", i + 1, len(selected), exc)

        return merge_chunk_responses(responses)

    def _call_cli(self, chunk: str, model: str) -> str:
        prompt = _ANALYSIS_PROMPT.format(conversation=chunk)
        claude_bin = shutil.which("claude") or "claude"

        # --strict-mcp-config with an empty mcpServers object disables all MCP
        # servers (including smritix itself) without touching OAuth credentials,
        # giving us --bare-like isolation while keeping subscription auth intact.
        # --setting-sources "" skips user/project hooks so they don't inject
        # memory context that would otherwise cost an extra turn.
        result = subprocess.run(
            [
                claude_bin, "--print",
                "--strict-mcp-config", "--mcp-config", '{"mcpServers": {}}',
                "--setting-sources", "",
                "--model", model,
                "--output-format", "json",
                "--json-schema", MEMORY_JSON_SCHEMA_STR,
                "--max-turns", "3",
                "--system-prompt", _SYSTEM_PROMPT,
            ],
            input=prompt,
            capture_output=True, text=True, timeout=180,
        )

        if result.returncode != 0:
            if "Not logged in" in result.stdout or "Not logged in" in result.stderr:
                raise RuntimeError(
                    "Claude Code CLI is not logged in on this machine.\n"
                    "  Run: claude login"
                )
            logger.warning(
                "sub_claude: claude --print failed (exit %d)\n  stdout: %s\n  stderr: %s",
                result.returncode,
                result.stdout[:2000] or "(empty)",
                result.stderr[:2000] or "(empty)",
            )
            raise RuntimeError(
                f"claude --print failed (exit {result.returncode}): "
                f"stdout={result.stdout[:300]!r} stderr={result.stderr[:300]!r}"
            )
        return result.stdout

    def _unwrap_envelope(self, raw: str) -> str:
        """
        Extract the model's text from the --output-format json envelope.
        Returns structured_output (newer CLI) or result (older CLI) as a string.
        """
        try:
            envelope = json.loads(raw)
        except json.JSONDecodeError:
            return raw  # not an envelope — pass through as-is

        structured = envelope.get("structured_output")
        if isinstance(structured, dict):
            return json.dumps(structured)

        return envelope.get("result", "")

    @classmethod
    def list_models(cls, api_key: str | None = None) -> list[str]:
        return [
            "claude-haiku-4-5-20251001",
            "claude-sonnet-4-6",
            "claude-opus-4-6",
        ]

    @classmethod
    def default_model(cls) -> str:
        return "claude-haiku-4-5-20251001"

    def validate(self) -> None:
        if not shutil.which("claude"):
            raise ProviderValidationError(
                "claude: command not found\n  Ensure Claude Code CLI is installed."
            )
