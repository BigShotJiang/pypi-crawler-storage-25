"""Provider registry — maps provider names to classes and builds the active chain."""
from __future__ import annotations

import logging

from smritix.providers.api_anthropic import AnthropicProvider
from smritix.providers.api_gemini import GeminiProvider
from smritix.providers.api_ollama import OllamaProvider
from smritix.providers.api_openai import OpenAIProvider
from smritix.providers.base import AIProvider
from smritix.providers.sub_claude import ClaudeCliProvider
from smritix.providers.sub_codex import CodexCliProvider
from smritix.config import ANTHROPIC_API_KEY, SMRITIX_PROVIDERS

logger = logging.getLogger(__name__)

_REGISTRY: dict[str, type[AIProvider]] = {
    "sub_claude": ClaudeCliProvider,
    "sub_codex": CodexCliProvider,
    "api_anthropic": AnthropicProvider,
    "api_ollama": OllamaProvider,
    "api_gemini": GeminiProvider,
    "api_openai": OpenAIProvider,
}


def get_provider(name: str) -> AIProvider:
    """Return a configured AIProvider instance by name. Raises ValueError for unknown names."""
    cls = _REGISTRY.get(name)
    if cls is None:
        raise ValueError(
            f"Unknown provider: {name!r}. Valid names: {sorted(_REGISTRY)}"
        )
    return cls()


def get_provider_chain() -> list[AIProvider]:
    """
    Return ordered list of AIProvider instances from SMRITIX_PROVIDERS config.
    Falls back to AnthropicProvider if ANTHROPIC_API_KEY is set and SMRITIX_PROVIDERS is empty.

    # TODO: replace sequential calling with queue + fixed thread pool for parallel processing
    """
    if SMRITIX_PROVIDERS:
        chain = []
        for name in SMRITIX_PROVIDERS:
            try:
                chain.append(get_provider(name))
            except ValueError:
                logger.warning("Ignoring unknown provider in SMRITIX_PROVIDERS: %r", name)
        return chain
    if ANTHROPIC_API_KEY:
        return [AnthropicProvider()]
    return []
