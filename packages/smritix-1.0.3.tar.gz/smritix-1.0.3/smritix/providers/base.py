"""Base interface for all AI providers."""
from __future__ import annotations

from abc import ABC, abstractmethod


class ProviderValidationError(Exception):
    """Raised when a provider fails its startup validation check."""


class AIProvider(ABC):
    """
    Abstract AI provider. Each subclass wraps one AI service or CLI tool.

    Providers live in smritix/agents/api/ — one file per provider.
    Register new providers in smritix/agents/api/registry.py.
    """

    @abstractmethod
    def analyze(self, conversation_text: str) -> str:
        """
        Send conversation text to AI, return raw JSON response string.
        Raises RuntimeError on any failure — caller handles fallback chain.
        """

    @classmethod
    @abstractmethod
    def name(cls) -> str:
        """Provider name as stored in SMRITIX_PROVIDERS (e.g. 'sub_claude')."""

    def validate(self) -> None:
        """
        Check provider is available and configured.
        Raises ProviderValidationError if not.
        Called once at smritix serve startup — fail fast rather than silently.
        Default: no-op (subclasses override as needed).
        """

    @classmethod
    def list_models(cls, api_key: str | None = None) -> list[str]:
        """
        Fetch available model names for this provider.
        Tries live API first, falls back to known defaults.
        api_key: optional key to use for API call (for providers that need it).
        """
        return []

    @classmethod
    def default_model(cls) -> str | None:
        """Return the default model name, or None if not applicable."""
        return None
