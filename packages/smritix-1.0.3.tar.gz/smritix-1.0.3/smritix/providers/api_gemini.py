"""Google Gemini API provider."""
from __future__ import annotations

import logging
import os

import requests

from smritix.providers.base import AIProvider, ProviderValidationError
from smritix.drafter.prompt import _ANALYSIS_PROMPT
from smritix.drafter.chunker import prepare_chunks, merge_chunk_responses

logger = logging.getLogger(__name__)

_CHUNK_CHARS = 100_000  # Gemini 2.x has a 1M token window; chunking rarely fires


class GeminiProvider(AIProvider):
    """Calls Google Gemini API via REST. Uses GEMINI_API_KEY."""

    @classmethod
    def name(cls) -> str:
        return "api_gemini"

    def analyze(self, conversation_text: str) -> str:
        _key_var = os.getenv("SMRITIX_GEMINI_KEY_VAR", "GEMINI_API_KEY")
        api_key = os.getenv(_key_var, "")
        if not api_key:
            raise ValueError("GEMINI_API_KEY not set")
        model = os.getenv("SMRITIX_GEMINI_MODEL", "gemini-2.0-flash")

        chunks = prepare_chunks(conversation_text, _CHUNK_CHARS)
        logger.info(
            "api_gemini: conversation %d chars → %d chunk(s) (max %d chars each)",
            len(conversation_text), len(chunks), _CHUNK_CHARS,
        )

        responses: list[str] = []
        for i, chunk in enumerate(chunks):
            logger.debug("api_gemini: chunk %d/%d (%d chars)", i + 1, len(chunks), len(chunk))
            resp = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}",
                json={"contents": [{"parts": [{"text": _ANALYSIS_PROMPT.format(conversation=chunk)}]}]},
                timeout=120,
            )
            resp.raise_for_status()
            responses.append(resp.json()["candidates"][0]["content"]["parts"][0]["text"])

        return merge_chunk_responses(responses)

    @classmethod
    def list_models(cls, api_key: str | None = None) -> list[str]:
        key = api_key or os.getenv("GEMINI_API_KEY", "")
        if key:
            try:
                resp = requests.get(
                    f"https://generativelanguage.googleapis.com/v1beta/models?key={key}",
                    timeout=5,
                )
                if resp.ok:
                    return [
                        m["name"].replace("models/", "")
                        for m in resp.json().get("models", [])
                        if "generateContent" in m.get("supportedGenerationMethods", [])
                    ]
            except Exception:
                pass
        return [
            "gemini-2.0-flash",
            "gemini-2.5-flash-preview-04-17",
            "gemini-2.5-pro-preview-03-25",
        ]

    @classmethod
    def default_model(cls) -> str:
        return "gemini-2.0-flash"

    def validate(self) -> None:
        _key_var = os.getenv("SMRITIX_GEMINI_KEY_VAR", "GEMINI_API_KEY")
        if not os.getenv(_key_var):
            raise ProviderValidationError(
                f"${_key_var} is not set.\n  Run: smritix provider reconfigure"
            )
