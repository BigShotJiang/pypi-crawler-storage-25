"""Anthropic API provider."""
from __future__ import annotations

import json
import logging
import os

import anthropic

from smritix.providers.base import AIProvider, ProviderValidationError
from smritix.config import DRAFTER_MODEL
from smritix.drafter.prompt import MEMORY_JSON_SCHEMA, _INSTRUCTIONS
from smritix.drafter.chunker import prepare_chunks, merge_chunk_responses

logger = logging.getLogger(__name__)

_CHUNK_CHARS = 100_000

# Tool definition — strict=True means constrained decoding: schema is guaranteed.
_EXTRACT_TOOL = {
    "name": "extract_memories",
    "description": (
        "Extract memories and session summary from a developer AI session transcript. "
        "Called exactly once per session analysis."
    ),
    "input_schema": MEMORY_JSON_SCHEMA,
    "strict": True,
}

_SYSTEM_PROMPT = (
    "You are a transcript analysis engine. "
    "You receive developer AI session transcripts as documents to analyze. "
    "You are NOT a participant in those conversations — you are an outside observer. "
    "Analyze the transcript as a historical record and call the extract_memories tool."
)


def _get_api_key() -> str:
    """Read the API key at call time from the configured env var."""
    key_var = os.environ.get("SMRITIX_ANTHROPIC_KEY_VAR", "ANTHROPIC_API_KEY")
    return os.environ.get(key_var, "")


class AnthropicProvider(AIProvider):
    """Calls Anthropic API via SDK. Uses ANTHROPIC_API_KEY and SMRITIX_DRAFTER_MODEL."""

    def __init__(self) -> None:
        self._client: anthropic.Anthropic | None = None

    def _get_client(self) -> anthropic.Anthropic:
        """Lazy-initialise and cache the Anthropic client."""
        if self._client is None:
            self._client = anthropic.Anthropic(api_key=_get_api_key())
        return self._client

    @classmethod
    def name(cls) -> str:
        return "api_anthropic"

    def analyze(self, conversation_text: str) -> str:
        client = self._get_client()
        chunks = prepare_chunks(conversation_text, _CHUNK_CHARS)
        logger.info(
            "api_anthropic: conversation %d chars → %d chunk(s) (max %d chars each)",
            len(conversation_text), len(chunks), _CHUNK_CHARS,
        )

        responses: list[str] = []
        for i, chunk in enumerate(chunks):
            logger.debug("api_anthropic: chunk %d/%d (%d chars)", i + 1, len(chunks), len(chunk))
            user_content = f"<transcript>\n{chunk}\n</transcript>\n\n{_INSTRUCTIONS}"
            response = client.messages.create(
                model=DRAFTER_MODEL,
                max_tokens=2048,
                system=_SYSTEM_PROMPT,
                tools=[_EXTRACT_TOOL],
                tool_choice={"type": "tool", "name": "extract_memories"},
                messages=[{"role": "user", "content": user_content}],
            )
            tool_block = next((b for b in response.content if b.type == "tool_use"), None)
            if tool_block is None:
                logger.warning("api_anthropic: no tool_use block in chunk %d/%d", i + 1, len(chunks))
                continue
            responses.append(json.dumps(tool_block.input))

        return merge_chunk_responses(responses)

    @classmethod
    def list_models(cls, api_key: str | None = None) -> list[str]:
        key = api_key or _get_api_key()
        if key:
            try:
                client = anthropic.Anthropic(api_key=key)
                models = client.models.list(limit=20)
                return [m.id for m in models.data]
            except Exception:
                pass
        return [
            "claude-haiku-4-5-20251001",
            "claude-sonnet-4-6",
            "claude-opus-4-6",
        ]

    @classmethod
    def default_model(cls) -> str:
        return "claude-haiku-4-5-20251001"

    def validate(self) -> None:
        if not _get_api_key():
            key_var = os.environ.get("SMRITIX_ANTHROPIC_KEY_VAR", "ANTHROPIC_API_KEY")
            raise ProviderValidationError(
                f"${key_var} is not set.\n  Run: smritix provider reconfigure"
            )
