"""Codex CLI provider (subscription — no API key needed)."""
from __future__ import annotations

import logging
import shutil
import subprocess

from smritix.providers.base import AIProvider, ProviderValidationError
from smritix.drafter.prompt import _ANALYSIS_PROMPT
from smritix.drafter.chunker import prepare_chunks, merge_chunk_responses

logger = logging.getLogger(__name__)

# Codex CLI has the same stdin size constraint as the Claude CLI.
# See sub_claude.py for details on the ~7 KB stdin bug.
_CHUNK_CHARS = 4_000


class CodexCliProvider(AIProvider):
    """Calls `codex -p <prompt>` as a subprocess. Requires Codex CLI installed."""

    @classmethod
    def name(cls) -> str:
        return "sub_codex"

    def analyze(self, conversation_text: str) -> str:
        chunks = prepare_chunks(conversation_text, _CHUNK_CHARS)
        logger.info(
            "sub_codex: conversation %d chars → %d chunk(s) (max %d chars each)",
            len(conversation_text), len(chunks), _CHUNK_CHARS,
        )

        responses: list[str] = []
        for i, chunk in enumerate(chunks):
            logger.debug("sub_codex: chunk %d/%d (%d chars)", i + 1, len(chunks), len(chunk))
            prompt = _ANALYSIS_PROMPT.format(conversation=chunk)
            result = subprocess.run(
                ["codex", "-p", prompt],
                capture_output=True, text=True, timeout=180,
            )
            if result.returncode != 0:
                logger.warning(
                    "sub_codex: chunk %d/%d failed (exit %d): %s",
                    i + 1, len(chunks), result.returncode, result.stderr[:200],
                )
                continue
            logger.debug(
                "sub_codex: chunk %d/%d response (%d chars):\n%s",
                i + 1, len(chunks), len(result.stdout), result.stdout,
            )
            responses.append(result.stdout)

        return merge_chunk_responses(responses)

    @classmethod
    def list_models(cls, api_key: str | None = None) -> list[str]:
        # Codex CLI has no `models` subcommand — hardcoded known models.
        return ["o4-mini", "o3", "gpt-4.1", "gpt-4o"]

    @classmethod
    def default_model(cls) -> str:
        return "o4-mini"

    def validate(self) -> None:
        if not shutil.which("codex"):
            raise ProviderValidationError(
                "codex: command not found\n  Ensure Codex CLI is installed."
            )
