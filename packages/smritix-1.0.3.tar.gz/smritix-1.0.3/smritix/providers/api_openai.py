"""OpenAI API provider."""
from __future__ import annotations

import logging
import os

import requests

from smritix.providers.base import AIProvider, ProviderValidationError
from smritix.drafter.prompt import _ANALYSIS_PROMPT
from smritix.drafter.chunker import prepare_chunks, merge_chunk_responses

logger = logging.getLogger(__name__)

_CHUNK_CHARS = 100_000  # GPT-4o has a 128K token window; chunking fires on very long sessions


class OpenAIProvider(AIProvider):
    """Calls OpenAI API via REST. Uses OPENAI_API_KEY and SMRITIX_OPENAI_MODEL."""

    @classmethod
    def name(cls) -> str:
        return "api_openai"

    def analyze(self, conversation_text: str) -> str:
        _key_var = os.getenv("SMRITIX_OPENAI_KEY_VAR", "OPENAI_API_KEY")
        api_key = os.getenv(_key_var, "")
        if not api_key:
            raise ValueError("OPENAI_API_KEY not set")
        model = os.getenv("SMRITIX_OPENAI_MODEL", "gpt-4o-mini")

        chunks = prepare_chunks(conversation_text, _CHUNK_CHARS)
        logger.info(
            "api_openai: conversation %d chars → %d chunk(s) (max %d chars each)",
            len(conversation_text), len(chunks), _CHUNK_CHARS,
        )

        responses: list[str] = []
        for i, chunk in enumerate(chunks):
            logger.debug("api_openai: chunk %d/%d (%d chars)", i + 1, len(chunks), len(chunk))
            resp = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": _ANALYSIS_PROMPT.format(conversation=chunk)}],
                    "max_tokens": 2048,
                },
                timeout=120,
            )
            resp.raise_for_status()
            responses.append(resp.json()["choices"][0]["message"]["content"])

        return merge_chunk_responses(responses)

    @classmethod
    def list_models(cls, api_key: str | None = None) -> list[str]:
        key = api_key or os.getenv("OPENAI_API_KEY", "")
        if key:
            try:
                resp = requests.get(
                    "https://api.openai.com/v1/models",
                    headers={"Authorization": f"Bearer {key}"},
                    timeout=5,
                )
                if resp.ok:
                    gpt_models = [
                        m["id"] for m in resp.json().get("data", [])
                        if m["id"].startswith(("gpt-4", "gpt-3.5", "o1", "o3", "o4"))
                    ]
                    return sorted(gpt_models)[:10]
            except Exception:
                pass
        return [
            "gpt-4o-mini",
            "gpt-4o",
            "o4-mini",
        ]

    @classmethod
    def default_model(cls) -> str:
        return "gpt-4o-mini"

    def validate(self) -> None:
        _key_var = os.getenv("SMRITIX_OPENAI_KEY_VAR", "OPENAI_API_KEY")
        if not os.getenv(_key_var):
            raise ProviderValidationError(
                f"${_key_var} is not set.\n  Run: smritix provider reconfigure"
            )
