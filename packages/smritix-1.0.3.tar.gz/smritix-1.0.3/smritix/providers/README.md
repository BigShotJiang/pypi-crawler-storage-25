# smritix/providers/

AI providers — one file per AI service used to analyze sessions and extract memories.

Each provider implements `AIProvider` from `base.py`:
- `analyze(conversation_text) -> str` — send text to AI, return raw JSON
- `validate()` — fast startup check (binary exists / API key set)
- `name()` — provider name as stored in `SMRITIX_PROVIDERS`

| File | Provider name | Service |
|------|--------------|---------|
| `sub_claude.py` | `sub_claude` | Claude Code CLI subprocess |
| `sub_codex.py` | `sub_codex` | Codex CLI subprocess |
| `api_anthropic.py` | `api_anthropic` | Anthropic API (SDK) |
| `api_ollama.py` | `api_ollama` | Ollama local HTTP API |
| `api_gemini.py` | `api_gemini` | Google Gemini REST API |
| `api_openai.py` | `api_openai` | OpenAI REST API |
| `base.py` | — | `AIProvider` ABC + `ProviderValidationError` |
| `registry.py` | — | `get_provider()` + `get_provider_chain()` |

To add a new provider: create a new file, extend `AIProvider`, register in `registry.py`.

Configured via `SMRITIX_PROVIDERS` (comma-separated, priority order).
See `smritix init` to set up interactively.
