from __future__ import annotations

import logging

import duckdb

from smritix.config import LINK_SIMILARITY_THRESHOLD
from smritix.embedding.encoder import embed
from smritix.storage.embeddings import search
from smritix.storage.links import create_link, get_links
from smritix.storage.memories import get_memory

logger = logging.getLogger(__name__)

_NEGATION_WORDS = frozenset({
    "never", "don't", "dont", "avoid", "not", "no", "stop", "prevent",
    "shouldn't", "shouldnt", "cannot", "can't", "cant",
})

_STOP_WORDS = frozenset({
    "use", "the", "a", "an", "in", "for", "to", "of", "and", "or",
    "is", "it", "this", "that", "we", "i", "you",
})


def _memory_text(mem: dict) -> str:
    """Build searchable text from a memory's title + narrative."""
    title = mem.get("title", "")
    narrative = mem.get("narrative") or ""
    return f"{title}. {narrative}".strip()


def classify_relationship(
    content_a: str, content_b: str, similarity: float
) -> str:
    """
    Rule-based relationship classification. No LLM — zero API cost.

    Priority order:
    1. Topic overlap + one side has negation words -> contradicts
    2. similarity >= 0.85 -> supports
    3. default -> related
    """
    words_a = set(content_a.lower().split())
    words_b = set(content_b.lower().split())

    neg_a = bool(words_a & _NEGATION_WORDS)
    neg_b = bool(words_b & _NEGATION_WORDS)

    topic_a = words_a - _NEGATION_WORDS - _STOP_WORDS
    topic_b = words_b - _NEGATION_WORDS - _STOP_WORDS
    overlap = topic_a & topic_b

    if overlap and (neg_a != neg_b):
        return "contradicts"
    if similarity >= 0.85:
        return "supports"
    return "related"


def run_linking(
    conn: duckdb.DuckDBPyConnection,
    new_memory_ids: list[str],
    similarity_threshold: float = LINK_SIMILARITY_THRESHOLD,
) -> None:
    """
    For each new memory: find similar existing memories via vector search,
    classify relationship, create edge. Skips pairs already linked.
    """
    for mid in new_memory_ids:
        mem = get_memory(conn, mid)
        if mem is None:
            continue

        mem_text = _memory_text(mem)
        query_vec = embed(mem_text)
        candidates = search(conn, query_vec, limit=15)

        existing_pairs = {
            (lnk["source_id"], lnk["target_id"])
            for lnk in get_links(conn, mid)
        }

        for hit in candidates:
            cid = hit["memory_id"]
            if cid == mid:
                continue
            if hit["similarity"] < similarity_threshold:
                continue
            if (mid, cid) in existing_pairs or (cid, mid) in existing_pairs:
                continue

            other = get_memory(conn, cid)
            if other is None:
                continue

            other_text = _memory_text(other)
            rel = classify_relationship(
                mem_text, other_text, hit["similarity"]
            )
            create_link(conn, mid, cid, rel, round(hit["similarity"], 4))
            logger.debug(
                "Linked %s -> %s as %s (%.3f)",
                mid[:8], cid[:8], rel, hit["similarity"],
            )
