from fastembed import TextEmbedding

from smritix.config import DATA_DIR, EMBEDDING_DIM, EMBEDDING_MODEL

_MODELS_DIR = DATA_DIR / "models"
_MODELS_DIR.mkdir(parents=True, exist_ok=True)

_model: TextEmbedding | None = None


def _get_model() -> TextEmbedding:
    global _model
    if _model is None:
        _model = TextEmbedding(EMBEDDING_MODEL, cache_dir=str(_MODELS_DIR))
    return _model


def embed_memory(memory: dict) -> list[float]:
    """
    Build a rich embedding from all structured fields of a memory.
    Including facts, tags, and project name gives the model more signal
    so semantically related queries score higher on the right memories.

    Layout (ordered by importance to the query):
      title — most important
      narrative — context and reasoning
      facts — technical specifics
      project — scopes the memory
      tags — functional classification
    """
    parts = []

    title = str(memory.get("title") or "").strip()
    if title:
        parts.append(title)

    narrative = str(memory.get("narrative") or "").strip()
    if narrative:
        parts.append(narrative)

    facts = memory.get("facts") or []
    if facts:
        parts.append(" ".join(str(f) for f in facts if f))

    project_path = str(memory.get("project_path") or "").strip()
    if project_path:
        # Use only the last path segment (project name) to avoid absolute path noise
        parts.append(project_path.rstrip("/").split("/")[-1])

    tags = memory.get("tags") or []
    if tags:
        parts.append(" ".join(str(t) for t in tags if t))

    text = " | ".join(parts) if parts else title
    return embed(text)


def embed(text: str) -> list[float]:
    """
    Embed text using nomic-embed-text-v1.5.
    Returns EMBEDDING_DIM floats (256) via Matryoshka truncation from 768.
    First call downloads the model (~300MB) to ~/.cache/huggingface/.
    """
    model = _get_model()
    full_vec = list(model.embed([text]))[0].tolist()
    return full_vec[:EMBEDDING_DIM]
