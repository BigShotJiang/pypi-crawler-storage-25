from __future__ import annotations

import math
from datetime import datetime, timezone

from smritix.config import TOKEN_BUDGET


def score_and_rank(candidates: list[dict]) -> list[dict]:
    """
    Re-score each candidate using 5-component formula and return sorted desc.

    Score = 0.35 * similarity
          + 0.20 * confirmation_weight   (1.0 if confirmed, 0.3 if not)
          + 0.15 * recency               (1 / (1 + days_since_created))
          + 0.10 * frequency             (log(1+access) / log(1+max_access))
          + 0.20 * project_match         (1.0 if same project, 0.5 if no project set, 0.0 if different)

    project_path is passed in `_query_project` field set by the MCP caller.
    Mutates each dict in-place to add a 'final_score' key.
    Returns the list sorted by final_score descending.
    """
    if not candidates:
        return []

    max_access = max((c.get("access_count", 0) for c in candidates), default=1)
    max_access = max(max_access, 1)
    now = datetime.now(timezone.utc)

    for c in candidates:
        raw_created = c.get("created_at", "")
        try:
            created = datetime.fromisoformat(str(raw_created))
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
        except (ValueError, TypeError):
            created = now

        days_old = max((now - created).days, 0)
        recency = 1.0 / (1.0 + days_old)

        access = c.get("access_count", 0)
        frequency = math.log(1 + access) / math.log(1 + max_access)

        confirmation = 1.0 if c.get("confirmed_by_user") else 0.3

        # Project match: same project → full score, no project info → neutral, different → zero
        query_project = (c.get("_query_project") or "").rstrip("/")
        mem_project = (c.get("project_path") or "").rstrip("/")
        if not query_project or not mem_project:
            project_match = 0.5   # neutral when no project context
        elif query_project == mem_project:
            project_match = 1.0
        else:
            project_match = 0.0

        c["final_score"] = (
            0.35 * c.get("similarity", 0.0)
            + 0.20 * confirmation
            + 0.15 * recency
            + 0.10 * frequency
            + 0.20 * project_match
        )

    return sorted(candidates, key=lambda x: x["final_score"], reverse=True)


def enforce_token_budget(
    memories: list[dict],
    token_limit: int = TOKEN_BUDGET,
) -> tuple[list[dict], int]:
    """
    Greedily select memories until token_limit is reached.
    Token count estimated as number of whitespace-separated words in title + narrative.
    Returns (selected_memories, total_tokens).
    """
    selected, total = [], 0
    for m in memories:
        text = (m.get("title", "") + " " + (m.get("narrative") or m.get("content", ""))).strip()
        tokens = len(text.split())
        if total + tokens > token_limit:
            break
        selected.append(m)
        total += tokens
    return selected, total
