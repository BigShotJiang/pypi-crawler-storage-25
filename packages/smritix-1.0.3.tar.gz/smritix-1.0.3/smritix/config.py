import os
from pathlib import Path

from dotenv import load_dotenv

# Load ~/.smritix/.env first — this is where smritix init writes provider config.
# load_dotenv() without a path only loads ./.env (current dir), missing user config.
_DEFAULT_DATA_DIR = Path.home() / ".smritix"
load_dotenv(_DEFAULT_DATA_DIR / ".env")   # user config (SMRITIX_PROVIDERS, API keys, etc.)
load_dotenv()                              # project-local .env override (if any)

DATA_DIR = Path(os.getenv("SMRITIX_DATA_DIR", str(_DEFAULT_DATA_DIR)))
DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "smritix.duckdb"

HOT_THRESHOLD = int(os.getenv("SMRITIX_HOT_THRESHOLD", "200"))
TOKEN_BUDGET = int(os.getenv("SMRITIX_TOKEN_BUDGET", "500"))

EMBEDDING_MODEL = "nomic-ai/nomic-embed-text-v1.5"
EMBEDDING_DIM = 256  # Matryoshka truncation from 768

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
DRAFTER_MODEL = os.getenv("SMRITIX_DRAFTER_MODEL", "claude-haiku-4-5-20251001")

MCP_PORT = int(os.getenv("SMRITIX_MCP_PORT", "8666"))

# Confidence tiers
AUTO_CONFIRM_THRESHOLD = 0.88
AUTO_DISCARD_THRESHOLD = float(os.getenv("SMRITIX_AUTO_DISCARD_THRESHOLD", "0.75"))

# Linking
LINK_SIMILARITY_THRESHOLD = 0.65
DUPLICATE_SIMILARITY_THRESHOLD = float(os.getenv("SMRITIX_DUPLICATE_SIMILARITY_THRESHOLD", "0.78"))

# Hook auto-approve: pending memories older than this are approved at session start
HOOK_AUTO_APPROVE_HOURS = int(os.getenv("SMRITIX_HOOK_AUTO_APPROVE_HOURS", "12"))

# File watcher
WATCHER_POLL_MINUTES = int(os.getenv("SMRITIX_WATCHER_POLL_MINUTES", "5"))
CONTENT_SETTLE_MINUTES = int(os.getenv("SMRITIX_CONTENT_SETTLE_MINUTES", "5"))

# Auto-approve
AUTO_APPROVE_HOURS = int(os.getenv("SMRITIX_AUTO_APPROVE_HOURS", "24"))
AUTO_APPROVE_THRESHOLD = float(os.getenv("SMRITIX_AUTO_APPROVE_THRESHOLD", "0.75"))
EXPIRE_DAYS = int(os.getenv("SMRITIX_EXPIRE_DAYS", "30"))

# Archived memories are soft-deleted; purge them permanently after N days (0 = never)
ARCHIVE_EXPIRE_DAYS = int(os.getenv("SMRITIX_ARCHIVE_EXPIRE_DAYS", "30"))

# Background provider list (comma-separated, in priority order)
# e.g. SMRITIX_PROVIDERS=anthropic,ollama
SMRITIX_PROVIDERS = [
    p.strip() for p in os.getenv("SMRITIX_PROVIDERS", "").split(",") if p.strip()
]

# How many days back to load sessions on first start (0 = all history)
SESSION_LOOKBACK_DAYS = int(os.getenv("SMRITIX_SESSION_LOOKBACK_DAYS", "7"))

# Session file locations — override if your AI tool stores sessions elsewhere
CLAUDE_CODE_SESSIONS_DIR = Path(
    os.getenv("SMRITIX_CLAUDE_SESSIONS_DIR", str(Path.home() / ".claude" / "projects"))
)
CODEX_SESSIONS_DIR = Path(
    os.getenv("SMRITIX_CODEX_SESSIONS_DIR", str(Path.home() / ".codex"))
)
