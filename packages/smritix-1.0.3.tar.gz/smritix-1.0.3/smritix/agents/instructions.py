from __future__ import annotations

from pathlib import Path

MEMORY_INSTRUCTIONS = """
## Smritix — Personal Memory System

Prerequisites: `smritix serve` must be running before this session.
Sessions are analyzed automatically in the background — no manual steps needed.

### Session start (hook injects context automatically):
Show pending memories. Default is approve-all.
If user mentions specific ones to change → call confirm_memory_tool(id, 'reject'|'edit')
Otherwise → approve all silently, then answer the user's question.

### During session:
- Memory context is pre-injected before each prompt — use it directly.
- Call get_memories(query) only if you need a more targeted search.
- Call add_memory() when user says: remember / save / note / don't forget. Confirm: "Saved."
- Call delete_memory(memory_id) when user says: remove / delete / forget this memory.
"""


def write_instruction_file(path: Path) -> bool:
    """Append the shared Smritix instructions to a file if not already present."""
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = path.read_text() if path.exists() else ""
    if "smritix" in existing.lower():
        return False
    path.write_text(existing + MEMORY_INSTRUCTIONS)
    return True


def generate_launchd_plist(env_vars: dict[str, str]) -> str:
    """
    Generate a macOS launchd plist for smritix watch.
    env_vars: dict of env var name → value to bake into the plist.
    """
    import shutil
    smritix_bin = shutil.which("smritix") or "smritix"

    env_xml = "\n".join(
        f"        <key>{k}</key>\n        <string>{v}</string>"
        for k, v in env_vars.items()
    )

    log_path = Path.home() / ".smritix" / "logs" / "watcher.log"

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
    "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.smritix.watcher</string>
    <key>ProgramArguments</key>
    <array>
        <string>{smritix_bin}</string>
        <string>watch</string>
    </array>
    <key>KeepAlive</key>
    <true/>
    <key>RunAtLoad</key>
    <true/>
    <key>StandardErrorPath</key>
    <string>{log_path}</string>
    <key>EnvironmentVariables</key>
    <dict>
{env_xml}
    </dict>
</dict>
</plist>
"""


def generate_systemd_unit() -> str:
    """Generate a Linux systemd user service unit for smritix watch."""
    import shutil
    smritix_bin = shutil.which("smritix") or "smritix"
    data_dir = Path.home() / ".smritix"
    return f"""[Unit]
Description=Smritix background session watcher

[Service]
ExecStart={smritix_bin} watch
Restart=always
EnvironmentFile={data_dir}/.env
StandardError=append:{data_dir}/logs/watcher.log

[Install]
WantedBy=default.target
"""


def install_background_daemon(env_vars: dict[str, str]) -> str:
    """
    Install and start the background daemon for the current OS.
    Returns a status message.
    """
    import platform
    import subprocess

    log_dir = Path.home() / ".smritix" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    system = platform.system()

    if system == "Darwin":
        plist_path = Path.home() / "Library" / "LaunchAgents" / "com.smritix.watcher.plist"
        plist_path.parent.mkdir(parents=True, exist_ok=True)
        plist_path.write_text(generate_launchd_plist(env_vars))
        subprocess.run(["launchctl", "unload", str(plist_path)], capture_output=True)
        result = subprocess.run(
            ["launchctl", "load", str(plist_path)],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            return f"launchd daemon installed and started ({plist_path})"
        return f"launchd plist written to {plist_path} (start manually: launchctl load {plist_path})"

    elif system == "Linux":
        unit_dir = Path.home() / ".config" / "systemd" / "user"
        unit_dir.mkdir(parents=True, exist_ok=True)
        unit_path = unit_dir / "smritix-watcher.service"
        unit_path.write_text(generate_systemd_unit())
        subprocess.run(["systemctl", "--user", "daemon-reload"], capture_output=True)
        result = subprocess.run(
            ["systemctl", "--user", "enable", "--now", "smritix-watcher"],
            capture_output=True, text=True,
        )
        if result.returncode == 0:
            return f"systemd service installed and started ({unit_path})"
        return (
            f"systemd unit written to {unit_path} "
            f"(start manually: systemctl --user enable --now smritix-watcher)"
        )

    return (
        f"Unsupported OS ({system}) — run 'smritix watch' manually "
        "to start background processing."
    )
