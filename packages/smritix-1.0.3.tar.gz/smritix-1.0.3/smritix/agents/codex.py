from __future__ import annotations

import json
import logging
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from smritix.agents.base import AIAgentReader, AgentSetupResult, Session, SessionMessage
from smritix.agents.instructions import write_instruction_file

logger = logging.getLogger(__name__)

_EPOCH = datetime.min.replace(tzinfo=timezone.utc)
_PROJECT_INSTRUCTION_FILES = ("AGENTS.md",)

# Codex content block types that carry user/assistant text
_TEXT_BLOCK_TYPES = frozenset({"input_text", "output_text", "text"})


class CodexReader(AIAgentReader):
    """
    Reads sessions from OpenAI Codex CLI.
    Sessions stored as JSONL files in ~/.codex/sessions/YYYY/MM/DD/*.jsonl

    Format per line:
      - Session header : {"id": "...", "timestamp": "...", "git": {...}}
      - Message        : {"type": "message", "role": "user"|"assistant", "content": [...]}
      - Tool call      : {"type": "local_shell_call", ...}   -- skipped
      - Tool result    : {"type": "function_call_output", ...} -- skipped
      - Reasoning      : {"type": "reasoning", ...}           -- skipped
      - State snapshot : {"record_type": "state"}             -- skipped
    """

    def __init__(self, base_dir: Path | None = None) -> None:
        if base_dir is None:
            from smritix.config import CODEX_SESSIONS_DIR
            base_dir = CODEX_SESSIONS_DIR
        self._base_dir = base_dir

    @property
    def _sessions_dir(self) -> Path:
        return self._base_dir / "sessions"

    def is_available(self) -> bool:
        return self._sessions_dir.exists()

    def setup(self, project_dir: Path) -> AgentSetupResult:
        result = AgentSetupResult(agent="Codex", session_dir=self._base_dir)

        if self._register_mcp_cli():
            result.messages.append("Codex: MCP registered via CLI (HTTP)")
        else:
            from smritix.config import MCP_PORT
            result.messages.append(
                f"Codex: add MCP manually if needed -> "
                f"codex mcp add smritix --type http http://localhost:{MCP_PORT}/mcp"
            )

        for file_name in _PROJECT_INSTRUCTION_FILES:
            path = project_dir / file_name
            if write_instruction_file(path):
                result.messages.append(f"Codex: instructions written to {path}")

        return result

    def list_sessions(self) -> list[Session]:
        """
        Scans ~/.codex/sessions/**/*.jsonl recursively.
        Codex stores sessions in date-based subdirs: sessions/YYYY/MM/DD/*.jsonl
        """
        sessions = []
        try:
            entries = []
            for f in self._sessions_dir.rglob("*.jsonl"):
                try:
                    stat = f.stat()
                    entries.append((f, stat))
                except OSError:
                    continue
            entries.sort(key=lambda x: x[1].st_mtime, reverse=True)
            for f, stat in entries:
                sessions.append(Session(
                    id=f.stem,
                    tool="codex",
                    file_path=str(f),
                    project_path=self._extract_project_path(f),
                    created_at=datetime.fromtimestamp(stat.st_ctime, tz=timezone.utc),
                    last_modified=datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc),
                ))
        except OSError as exc:
            logger.debug("CodexReader.list_sessions failed: %s", exc)
        return sessions

    def get_messages(
        self, session_id: str, since: datetime | None
    ) -> list[SessionMessage]:
        # Sessions may live in a date-based subdir — find by stem
        matches = list(self._sessions_dir.rglob(f"{session_id}.jsonl"))
        if not matches:
            return []
        return self._parse_jsonl(matches[0], since)

    def _extract_project_path(self, path: Path) -> str | None:
        """Extract the working directory from the first few lines of a session."""
        try:
            for line in path.read_text(encoding="utf-8", errors="replace").splitlines()[:10]:
                if not line.strip():
                    continue
                try:
                    obj = json.loads(line)
                    cwd = (obj.get("cwd") or
                           obj.get("payload", {}).get("cwd") or
                           (obj.get("git", {}) or {}).get("repository_url"))
                    if cwd and not cwd.startswith("git@"):
                        return str(cwd)
                except json.JSONDecodeError:
                    continue
        except OSError:
            pass
        return None

    def _parse_jsonl(
        self, path: Path, since: datetime | None
    ) -> list[SessionMessage]:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.debug("Could not read %s: %s", path, exc)
            return []

        # Use the session header timestamp for messages that lack one
        session_ts = _EPOCH
        messages = []

        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                logger.debug("Skipping malformed JSONL line in %s", path)
                continue

            ts = self._parse_dt(obj.get("timestamp")) or session_ts
            msg_type = obj.get("type", "")

            # ── Old format (Codex CLI 2025): {"type":"message","role":"user","content":[...]}
            if msg_type == "message":
                role = obj.get("role", "")
                content_raw = obj.get("content", "")
                session_ts = ts  # use as fallback for subsequent lines

            # ── New format (Codex Desktop 2026): {"type":"response_item","payload":{...}}
            elif msg_type == "response_item":
                payload = obj.get("payload", {})
                role = payload.get("role", "")
                content_raw = payload.get("content", "")

            # ── Session header (old): {"id":"...","git":{...},"timestamp":"..."}
            elif "git" in obj and "id" in obj:
                session_ts = ts
                continue

            # ── Session meta (new): {"type":"session_meta","payload":{...}}
            elif msg_type == "session_meta":
                session_ts = ts
                continue

            else:
                continue  # skip tool calls, reasoning, state snapshots, etc.

            if role not in ("user", "assistant"):
                continue
            if since and ts < since:
                continue

            # Extract text from content blocks
            if isinstance(content_raw, list):
                content = " ".join(
                    block.get("text", "")
                    for block in content_raw
                    if isinstance(block, dict) and block.get("type") in _TEXT_BLOCK_TYPES
                )
            else:
                content = str(content_raw)

            content = content.strip()
            if not content:
                continue

            messages.append(SessionMessage(
                role=role,
                content=content,
                timestamp=ts,
                is_tool_result=False,
            ))

        return messages

    @staticmethod
    def _parse_dt(value: str | None) -> datetime:
        if not value:
            return _EPOCH
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except (ValueError, TypeError):
            return _EPOCH

    @staticmethod
    def _register_mcp_cli() -> bool:
        from smritix.config import MCP_PORT
        url = f"http://localhost:{MCP_PORT}/mcp"
        try:
            result = subprocess.run(
                ["codex", "mcp", "add", "smritix", "--type", "http", url],
                capture_output=True,
                text=True,
                timeout=15,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False
        if result.returncode == 0:
            return True
        logger.debug("codex mcp add failed: %s", result.stderr)
        return False
