from pathlib import Path

from smritix.agents.base import AIAgentReader, AgentSetupResult, RawSession, Session, SessionMessage


def _register():
    """Lazy import to avoid circular deps and missing-SDK errors at import time."""
    from smritix.agents.claude_code import ClaudeCodeReader
    from smritix.agents.codex import CodexReader
    return [ClaudeCodeReader, CodexReader]


def get_registered_readers() -> list[type[AIAgentReader]]:
    """Return all registered reader classes."""
    return _register()


def get_available_readers() -> list[AIAgentReader]:
    """Return instances of all readers whose tool is installed."""
    readers = []
    for cls in _register():
        try:
            instance = cls()
            if instance.is_available():
                readers.append(instance)
        except Exception:
            pass
    return readers


def setup_agents(project_dir: Path) -> list[AgentSetupResult]:
    """Run setup for every registered agent."""
    results = []
    for cls in get_registered_readers():
        results.append(cls().setup(project_dir))
    return results


__all__ = [
    "AIAgentReader", "AgentSetupResult", "RawSession", "Session", "SessionMessage",
    "get_available_readers", "get_registered_readers", "setup_agents",
]
