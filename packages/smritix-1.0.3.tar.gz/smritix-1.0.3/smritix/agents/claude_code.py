from __future__ import annotations

import json
import logging
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from smritix.agents.base import AIAgentReader, AgentSetupResult, Session, SessionMessage
from smritix.agents.instructions import write_instruction_file

logger = logging.getLogger(__name__)

def _mcp_http_url() -> str:
    from smritix.config import MCP_PORT
    return f"http://localhost:{MCP_PORT}/mcp"


_MCP_CONFIG = {"smritix": {"type": "http", "url": _mcp_http_url()}}
_PROJECT_INSTRUCTION_FILES = ("CLAUDE.md", "AGENTS.md")


def _default_base_dir() -> Path:
    from smritix.config import CLAUDE_CODE_SESSIONS_DIR
    return CLAUDE_CODE_SESSIONS_DIR

# JSONL entry types that carry conversation content
_CONTENT_TYPES = frozenset({"user", "assistant"})

# User message content to skip (system noise)
_SKIP_PREFIXES = ("[Request interrupted", "[Compact context")


class ClaudeCodeReader(AIAgentReader):
    """
    Reads sessions from Claude Code by scanning JSONL files directly.
    Sessions stored in ~/.claude/projects/[project-dir]/*.jsonl

    No external SDK required — reads files from disk.
    Reuses Claude Code's own session summary when available via
    get_session_summary().
    """

    def __init__(self, base_dir: Path | None = None) -> None:
        self._base_dir = base_dir or _default_base_dir()

    def is_available(self) -> bool:
        return self._base_dir.exists()

    def setup(self, project_dir: Path) -> AgentSetupResult:
        result = AgentSetupResult(agent="Claude Code", session_dir=self._base_dir)

        if self._register_mcp_cli():
            result.messages.append("Claude Code: MCP registered via CLI")
        else:
            desktop_updates = self._write_desktop_mcp_config()
            if desktop_updates > 0:
                result.messages.append(
                    f"Claude Code: desktop MCP config updated for {desktop_updates} project(s)"
                )
            from smritix.config import MCP_PORT
            result.messages.append(
                f"Claude Code: add MCP manually if needed -> "
                f"claude mcp add --scope user --transport sse smritix http://localhost:{MCP_PORT}/mcp"
            )

        for file_name in _PROJECT_INSTRUCTION_FILES:
            path = project_dir / file_name
            if write_instruction_file(path):
                result.messages.append(f"Claude Code: instructions written to {path}")

        for path in self._global_instruction_files():
            if write_instruction_file(path):
                result.messages.append(f"Claude Code: instructions written to {path}")

        hook_status = self._register_hooks()
        result.messages.append(f"Claude Code: session hooks {hook_status}")
        return result

    def list_sessions(self) -> list[Session]:
        sessions = []
        for jsonl_file in self._base_dir.rglob("*.jsonl"):
            try:
                stat = jsonl_file.stat()
                sessions.append(Session(
                    id=jsonl_file.stem,
                    tool="claude_code",
                    file_path=str(jsonl_file),
                    project_path=self._extract_project_path(jsonl_file),
                    created_at=datetime.fromtimestamp(stat.st_ctime, tz=timezone.utc),
                    last_modified=datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc),
                ))
            except OSError:
                continue
        return sorted(sessions, key=lambda x: x.last_modified, reverse=True)

    def get_messages(
        self, session_id: str, since: datetime | None
    ) -> list[SessionMessage]:
        matches = list(self._base_dir.rglob(f"{session_id}.jsonl"))
        if not matches:
            return []
        return self._parse_jsonl(matches[0], since)

    def get_session_summary(self, session_id: str) -> str | None:
        """
        Return Claude Code's own AI-generated session summary if available.
        Stored in sessions-index.json alongside the JSONL files.
        Avoids an extra AI call in the drafter when a summary already exists.
        """
        matches = list(self._base_dir.rglob(f"{session_id}.jsonl"))
        if not matches:
            return None
        index_file = matches[0].parent / "sessions-index.json"
        if not index_file.exists():
            return None
        try:
            data = json.loads(index_file.read_text(encoding="utf-8"))
            for entry in data.get("entries", []):
                if entry.get("sessionId") == session_id:
                    return entry.get("summary") or None
        except (json.JSONDecodeError, OSError):
            pass
        return None

    def _extract_project_path(self, path: Path) -> str | None:
        """Extract the working directory from the first few lines of a session."""
        try:
            for line in path.read_text(encoding="utf-8", errors="replace").splitlines()[:20]:
                if not line.strip():
                    continue
                try:
                    obj = json.loads(line)
                    cwd = obj.get("cwd") or obj.get("payload", {}).get("cwd")
                    if cwd:
                        return str(cwd)
                except json.JSONDecodeError:
                    continue
        except OSError:
            pass
        return None

    def _parse_jsonl(
        self, path: Path, since: datetime | None
    ) -> list[SessionMessage]:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.debug("Could not read %s: %s", path, exc)
            return []

        messages = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue

            if obj.get("type") not in _CONTENT_TYPES:
                continue

            ts = self._parse_dt(obj.get("timestamp"))
            if since and ts < since:
                continue

            role = obj["type"]  # "user" or "assistant"
            content = obj.get("message", {}).get("content", "")

            # Assistant messages have content as a list of typed blocks.
            # Extract only text blocks; skip tool_use, tool_result, thinking.
            if isinstance(content, list):
                content = " ".join(
                    block.get("text", "")
                    for block in content
                    if isinstance(block, dict) and block.get("type") == "text"
                )

            content = str(content).strip()
            if not content:
                continue
            if content.startswith(_SKIP_PREFIXES):
                continue

            messages.append(SessionMessage(
                role=role,
                content=content,
                timestamp=ts,
                is_tool_result=False,
            ))

        return messages

    @staticmethod
    def _parse_dt(value: str | None) -> datetime:
        if not value:
            return datetime.min.replace(tzinfo=timezone.utc)
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except (ValueError, TypeError):
            return datetime.min.replace(tzinfo=timezone.utc)

    @staticmethod
    def _register_mcp_cli() -> bool:
        from smritix.config import MCP_PORT
        url = f"http://localhost:{MCP_PORT}/mcp"
        try:
            # Remove any existing entry first (may be old stdio registration).
            # Ignore failures — the server may not exist yet.
            subprocess.run(
                ["claude", "mcp", "remove", "smritix", "--scope", "user"],
                capture_output=True, text=True, timeout=10,
            )
            result = subprocess.run(
                ["claude", "mcp", "add", "--scope", "user",
                 "--transport", "sse", "smritix", url],
                capture_output=True, text=True, timeout=15,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False
        if result.returncode == 0:
            return True
        logger.debug("claude mcp add failed: %s", result.stderr)
        return False

    @staticmethod
    def _global_instruction_files() -> tuple[Path, ...]:
        return (Path.home() / ".claude" / "CLAUDE.md",)

    @staticmethod
    def _write_desktop_mcp_config() -> int:
        claude_json = Path.home() / ".claude.json"
        if not claude_json.exists():
            return 0

        try:
            data = json.loads(claude_json.read_text())
        except (json.JSONDecodeError, OSError):
            logger.warning("Could not parse ~/.claude.json - skipping desktop MCP registration")
            return 0

        projects = data.get("projects", {})
        updated = 0
        for proj_data in projects.values():
            if not isinstance(proj_data, dict):
                continue
            servers = proj_data.setdefault("mcpServers", {})
            if "smritix" in servers:
                continue
            servers["smritix"] = _MCP_CONFIG["smritix"]
            updated += 1

        if updated:
            data["projects"] = projects
            claude_json.write_text(json.dumps(data, indent=2))
        return updated

    @staticmethod
    def _register_hooks() -> str:
        settings_path = Path.home() / ".claude" / "settings.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            settings = json.loads(settings_path.read_text()) if settings_path.exists() else {}
        except (json.JSONDecodeError, OSError):
            settings = {}

        hooks = settings.setdefault("hooks", {})

        # Remove any old-style hook entries before registering new ones
        for event, old_cmd in [
            ("SessionStart", "smritix hook --reset"),
            ("UserPromptSubmit", "smritix hook"),
        ]:
            hooks[event] = [
                group for group in hooks.get(event, [])
                if not any(h.get("command") == old_cmd for h in group.get("hooks", []))
            ]

        session_start = hooks.setdefault("SessionStart", [])
        user_prompt_submit = hooks.setdefault("UserPromptSubmit", [])

        session_start_registered = any(
            "--session-start" in hook.get("command", "")
            for group in session_start for hook in group.get("hooks", [])
        )
        if not session_start_registered:
            session_start.append(
                {"hooks": [{"type": "command", "command": "smritix hook --session-start"}]}
            )

        prompt_registered = any(
            "--prompt" in hook.get("command", "")
            for group in user_prompt_submit for hook in group.get("hooks", [])
        )
        if not prompt_registered:
            user_prompt_submit.append(
                {"hooks": [{"type": "command", "command": "smritix hook --prompt"}]}
            )

        if session_start_registered and prompt_registered:
            return "already registered"

        settings_path.write_text(json.dumps(settings, indent=2))
        return f"registered in {settings_path}"
