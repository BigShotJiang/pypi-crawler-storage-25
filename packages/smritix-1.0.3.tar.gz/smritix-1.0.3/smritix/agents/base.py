from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


@dataclass
class SessionMessage:
    role: str               # "user" | "assistant"
    content: str
    timestamp: datetime
    is_tool_result: bool = False


@dataclass
class Session:
    id: str
    tool: str               # "claude_code" | "codex" | "gemini" | ...
    file_path: str | None
    project_path: str | None
    created_at: datetime
    last_modified: datetime


@dataclass
class RawSession:
    session: Session
    messages: list[SessionMessage] = field(default_factory=list)


@dataclass
class AgentSetupResult:
    agent: str
    messages: list[str] = field(default_factory=list)
    session_dir: Path | None = None


class AIAgentReader(ABC):
    """
    Abstract base for reading sessions from an AI coding tool.
    Subclasses implement is_available, list_sessions, get_messages.
    Shared logic (strip_tool_results, get_new_content) lives here.
    """

    def get_new_content(self, checkpoint: datetime | None) -> list[RawSession]:
        """
        Full pipeline: list sessions -> fetch messages -> strip tool results.
        Called by the file watcher every 15 minutes.
        """
        sessions = self.list_sessions()
        result = []
        for s in sessions:
            msgs = self.get_messages(s.id, since=checkpoint)
            stripped = self.strip_tool_results(msgs)
            if stripped:
                result.append(RawSession(session=s, messages=stripped))
        return result

    def strip_tool_results(self, messages: list[SessionMessage]) -> list[SessionMessage]:
        """
        Remove tool call results. Keep only user and assistant text.
        Override only if a tool has non-standard message format.
        """
        return [
            m for m in messages
            if m.role in ("user", "assistant") and not m.is_tool_result
        ]

    @abstractmethod
    def is_available(self) -> bool:
        """Return True if this AI tool is installed on the system."""

    @abstractmethod
    def setup(self, project_dir: Path) -> AgentSetupResult:
        """Perform agent-specific Smritix setup for the current project."""

    @abstractmethod
    def list_sessions(self) -> list[Session]:
        """Return all known sessions, sorted by last_modified descending."""

    @abstractmethod
    def get_messages(
        self, session_id: str, since: datetime | None
    ) -> list[SessionMessage]:
        """
        Return messages for session_id.
        If since is provided, return only messages newer than that timestamp.
        """
