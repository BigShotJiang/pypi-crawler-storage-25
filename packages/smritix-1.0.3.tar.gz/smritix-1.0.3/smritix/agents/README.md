# smritix/agents/

Session readers — one file per supported AI coding tool.

Each reader knows how to:
- Detect if the tool is installed (`is_available()`)
- List session files (`list_sessions()`)
- Read messages from a session (`get_messages()`)
- Register the MCP server with the tool (`setup()`)

| File | Tool |
|------|------|
| `claude_code.py` | Claude Code CLI — reads `~/.claude/projects/**/*.jsonl` |
| `codex.py` | Codex CLI — reads `~/.codex/sessions/**/*.jsonl` |
| `base.py` | `AIAgentReader` ABC + shared data classes |
| `instructions.py` | CLAUDE.md / AGENTS.md content + daemon generators |

To add a new tool: extend `AIAgentReader` in a new file, register in `__init__.py`.
