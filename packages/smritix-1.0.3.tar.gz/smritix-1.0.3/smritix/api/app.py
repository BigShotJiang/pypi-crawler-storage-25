from __future__ import annotations

import logging
from pathlib import Path

import duckdb
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from smritix import __version__, parse_version as _parse_version
from smritix.api.routes import memories, pending
from smritix.storage.memories import list_pending as _list_pending

logger = logging.getLogger(__name__)

_pypi_cache: dict = {}  # {"latest": str, "checked": bool}


def _get_version_context() -> dict:
    """Return template context with version info. PyPI check is cached per process."""
    global _pypi_cache
    if not _pypi_cache.get("checked"):
        try:
            import json
            import urllib.request
            with urllib.request.urlopen(
                "https://pypi.org/pypi/smritix/json", timeout=2
            ) as resp:
                latest = json.loads(resp.read())["info"]["version"]
            _pypi_cache = {"checked": True, "latest": latest}
        except Exception:
            _pypi_cache = {"checked": True, "latest": __version__}

    latest = _pypi_cache.get("latest", __version__)

    return {
        "version": __version__,
        "latest_version": latest,
        "upgrade_available": _parse_version(latest) > _parse_version(__version__),
    }


def create_app(
    conn: duckdb.DuckDBPyConnection | None = None,
    mcp_server=None,
) -> FastAPI:
    if conn is None:
        from smritix.db.connection import get_connection
        from smritix.db.schema import create_schema
        conn = get_connection()
        create_schema(conn)

    app = FastAPI(title="Smritix")

    def get_conn():
        return conn

    app.dependency_overrides[pending.get_conn] = get_conn
    app.dependency_overrides[memories.get_conn] = get_conn

    app.include_router(pending.router)
    app.include_router(memories.router)

    # Health endpoint — used by "already running?" detection in smritix serve
    @app.get("/health")
    def health():
        try:
            mem_count = conn.execute(
                "SELECT COUNT(*) FROM memories WHERE is_archived=false"
            ).fetchone()[0]
            pending_count = conn.execute(
                "SELECT COUNT(*) FROM pending_memories WHERE status='pending'"
            ).fetchone()[0]
        except Exception:
            mem_count = pending_count = 0
        return JSONResponse({
            "status": "ok",
            "version": __version__,
            "memories": mem_count,
            "pending": pending_count,
        })

    # Mount FastMCP SSE transport at /mcp
    # SSE transport is used instead of HTTP transport because Claude Code's HTTP
    # transport triggers OAuth authentication checks, while SSE does not.
    if mcp_server is not None:
        mcp_asgi = mcp_server.http_app(transport="sse", path="/")
        app.mount("/mcp", mcp_asgi)
        logger.info("MCP server mounted at /mcp (SSE transport)")

    _PORTAL_DIR = Path(__file__).parent.parent / "portal"
    if _PORTAL_DIR.exists():
        templates = Jinja2Templates(directory=str(_PORTAL_DIR / "templates"))
        app.mount("/static", StaticFiles(directory=str(_PORTAL_DIR / "static")), name="static")

        from fastapi.responses import RedirectResponse
        @app.get("/favicon.ico", include_in_schema=False)
        def favicon():
            return RedirectResponse(url="/static/favicon.svg")

        @app.get("/", response_class=HTMLResponse)
        def portal_pending(request: Request):
            p = _list_pending(conn)
            ctx = {"pending": p, **_get_version_context()}
            return templates.TemplateResponse(request, "pending.html", ctx)

        @app.get("/memories", response_class=HTMLResponse)
        def portal_memories(request: Request):
            return templates.TemplateResponse(
                request, "memories.html", _get_version_context()
            )

    else:
        logger.warning("Portal directory not found at %s — web UI unavailable", _PORTAL_DIR)

    return app
