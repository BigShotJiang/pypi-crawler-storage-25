import duckdb
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from smritix.storage.memories import archive_memory, get_memory

router = APIRouter(prefix="/api/memories", tags=["memories"])


class MemoryUpdate(BaseModel):
    title: str
    narrative: str = ""
    evidence: str = ""
    tags: list[str] = []
    facts: list[str] = []


def get_conn() -> duckdb.DuckDBPyConnection:
    raise NotImplementedError("dependency override required")


def _full_row(r) -> dict:
    import json
    return {
        "id": r[0], "seq_num": r[1], "title": r[2],
        "obs_type": r[3], "type": r[4],
        "facts": json.loads(r[5]) if r[5] else [],
        "narrative": r[6],
        "tags": json.loads(r[7]) if r[7] else [],
        "files_mentioned": json.loads(r[8]) if r[8] else [],
        "evidence": r[9],
        "project_path": r[10], "source_tool": r[11],
        "confidence": r[12], "confirmed_by_user": r[13],
        "access_count": r[14], "created_at": str(r[15]),
        "investigated": r[16], "learned": r[17],
        "completed": json.loads(r[18]) if r[18] else [],
        "next_steps": r[19],
    }


_SELECT = """
    SELECT id, seq_num, title, obs_type, type, facts, narrative, tags,
           files_mentioned, evidence, project_path, source_tool,
           confidence, confirmed_by_user, access_count, created_at,
           investigated, learned, completed, next_steps
    FROM memories WHERE is_archived=false
"""


@router.get("")
def list_memories(conn: duckdb.DuckDBPyConnection = Depends(get_conn)):
    rows = conn.execute(_SELECT + " ORDER BY created_at DESC").fetchall()
    memories = [_full_row(r) for r in rows]

    # Attach link count to each memory
    if memories:
        ids = [m["id"] for m in memories]
        link_rows = conn.execute(
            "SELECT source_id, COUNT(*) FROM memory_links "
            "WHERE source_id IN ({}) OR target_id IN ({}) "
            "GROUP BY source_id".format(
                ",".join("?" * len(ids)), ",".join("?" * len(ids))
            ),
            ids + ids,
        ).fetchall()
        link_map = {r[0]: r[1] for r in link_rows}
        for m in memories:
            m["link_count"] = link_map.get(m["id"], 0)

    return {"memories": memories}


@router.get("/search")
def search_memories(
    q: str,
    limit: int = 20,
    conn: duckdb.DuckDBPyConnection = Depends(get_conn),
):
    """Vector search — returns memories ranked by semantic similarity to the query."""
    from smritix.embedding.encoder import embed
    from smritix.scoring import score_and_rank
    from smritix.storage.embeddings import search
    from smritix.storage.memories import get_memory

    query_vec = embed(q)
    hits = search(conn, query_vec, limit=limit)
    if not hits:
        return {"memories": [], "query": q}

    enriched = []
    for hit in hits:
        mem = get_memory(conn, hit["memory_id"])
        if mem and not mem["is_archived"]:
            mem["similarity"] = hit["similarity"]
            enriched.append(mem)

    ranked = score_and_rank(enriched)
    return {
        "memories": [
            {**m, "score_pct": int(m["final_score"] * 100)}
            for m in ranked
        ],
        "query": q,
    }


@router.put("/{memory_id}")
def update_memory(
    memory_id: str,
    body: MemoryUpdate,
    conn: duckdb.DuckDBPyConnection = Depends(get_conn),
):
    import json as _json
    affected = conn.execute(
        "UPDATE memories SET title=?, narrative=?, evidence=?, tags=?, facts=? WHERE id=? AND is_archived=false",
        [body.title, body.narrative, body.evidence,
         _json.dumps(body.tags), _json.dumps(body.facts), memory_id],
    ).fetchone()
    if affected is not None and affected[0] == 0:
        raise HTTPException(status_code=404, detail="Memory not found")

    # Re-embed with updated content
    mem = get_memory(conn, memory_id)
    if mem:
        from smritix.embedding.encoder import embed_memory
        from smritix.storage.embeddings import insert_hot, maybe_merge
        insert_hot(conn, memory_id, embed_memory(mem))
        maybe_merge(conn)

    return {"status": "updated"}


@router.delete("/{memory_id}")
def delete_memory(
    memory_id: str,
    conn: duckdb.DuckDBPyConnection = Depends(get_conn),
):
    archive_memory(conn, memory_id)
    return {"status": "archived"}
