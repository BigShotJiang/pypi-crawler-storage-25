import duckdb
from fastapi import APIRouter, Depends, Form, HTTPException
from pydantic import BaseModel

from smritix.embedding.encoder import embed_memory
from smritix.storage.embeddings import insert_hot, maybe_merge
from smritix.storage.memories import (
    confirm_memory,
    get_memory,
    get_pending_content,
    insert_pending,
    list_pending,
    reject_memory,
)

router = APIRouter(prefix="/api/pending", tags=["pending"])


class PendingCreate(BaseModel):
    title: str
    obs_type: str = "discovery"
    type: str = "context"
    facts: list[str] = []
    narrative: str = ""
    tags: list[str] = []
    files_mentioned: list[str] = []
    confidence: float = 0.8
    evidence: str = ""
    source_session_id: str = ""


def get_conn() -> duckdb.DuckDBPyConnection:
    raise NotImplementedError("dependency override required")


@router.get("")
def list_pending_route(conn: duckdb.DuckDBPyConnection = Depends(get_conn)):
    return {"pending": list_pending(conn)}


@router.post("")
def create_pending(
    body: PendingCreate,
    conn: duckdb.DuckDBPyConnection = Depends(get_conn),
):
    pid = insert_pending(
        conn,
        title=body.title,
        obs_type=body.obs_type,
        type_=body.type,
        facts=body.facts,
        narrative=body.narrative,
        tags=body.tags,
        files_mentioned=body.files_mentioned,
        confidence=body.confidence,
        evidence=body.evidence,
        source_session_id=body.source_session_id,
    )
    return {"id": pid}


@router.post("/{pending_id}/confirm")
def confirm_route(
    pending_id: str,
    # Accept both JSON body (API calls) and form data (HTMX buttons)
    final_content: str = Form(default=""),
    conn: duckdb.DuckDBPyConnection = Depends(get_conn),
):
    pending_data = get_pending_content(conn, pending_id)
    if pending_data is None:
        raise HTTPException(status_code=404, detail="Pending memory not found")
    edited_title = final_content if final_content else None
    mid = confirm_memory(conn, pending_id, edited_title=edited_title)
    mem = get_memory(conn, mid) or {}
    insert_hot(conn, mid, embed_memory(mem))
    maybe_merge(conn)
    return {"memory_id": mid}


@router.post("/{pending_id}/reject")
def reject_route(
    pending_id: str,
    conn: duckdb.DuckDBPyConnection = Depends(get_conn),
):
    try:
        reject_memory(conn, pending_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Pending memory not found")
    return {"status": "rejected"}


@router.post("/auto-approve")
def auto_approve_route(
    older_than_hours: int = 12,
    min_confidence: float = 0.75,
    conn: duckdb.DuckDBPyConnection = Depends(get_conn),
):
    """
    Auto-approve all pending memories older than `older_than_hours` with
    confidence >= `min_confidence`. Called by the session-start hook so that
    memories from previous sessions are confirmed before Claude starts work.
    Returns counts of approved and skipped items.
    """
    from datetime import datetime, timedelta, timezone

    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=older_than_hours)

    rows = conn.execute(
        "SELECT id, confidence, created_at FROM pending_memories WHERE status='pending'"
    ).fetchall()

    approved = 0
    skipped = 0
    for pid, confidence, created_at in rows:
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=timezone.utc)
        if created_at < cutoff and confidence >= min_confidence:
            try:
                mid = confirm_memory(conn, pid)
                mem = get_memory(conn, mid) or {}
                insert_hot(conn, mid, embed_memory(mem))
                approved += 1
            except Exception:
                skipped += 1
        else:
            skipped += 1

    if approved:
        maybe_merge(conn)

    return {"approved": approved, "skipped": skipped}
