from importlib.metadata import PackageNotFoundError, version as _pkg_version
import re as _re

try:
    __version__ = _pkg_version("smritix")
except PackageNotFoundError:
    # Running from source without an install — read from hatch-vcs generated file
    try:
        from smritix._version import __version__  # type: ignore[no-redef]
    except ImportError:
        __version__ = "0.0.0+dev"


def parse_version(v: str) -> tuple[int, ...]:
    """Parse a version string into a comparable tuple.

    Strips dev/pre-release/build suffixes:
      '0.2.1.dev17+gabcdef' → (0, 2, 1)
      '0.2.0'               → (0, 2, 0)
    """
    try:
        clean = _re.split(r'[+]|\.dev|[ab]\d|rc\d', str(v))[0]
        return tuple(int(x) for x in clean.split(".") if x.isdigit())
    except (ValueError, AttributeError):
        return (0,)
