from __future__ import annotations

import json
import logging
import os
from pathlib import Path

import typer
import uvicorn

from smritix import __version__, parse_version as _parse_version
from smritix.config import DATA_DIR, MCP_PORT

logger = logging.getLogger(__name__)


def _get_latest_version() -> str | None:
    """Check PyPI for the latest smritix version. Returns None on any failure."""
    try:
        import urllib.request
        with urllib.request.urlopen(
            "https://pypi.org/pypi/smritix/json", timeout=3
        ) as resp:
            data = json.loads(resp.read())
            return data["info"]["version"]
    except Exception:
        return None


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"smritix {__version__}")
        latest = _get_latest_version()
        if latest and _parse_version(latest) > _parse_version(__version__):
            typer.echo(
                f"  A newer version is available: {latest}\n"
                f"  Run: smritix upgrade"
            )
        raise typer.Exit()


app = typer.Typer(
    name="smritix",
    help="Personal AI memory system",
    no_args_is_help=True,
)


@app.callback()
def _main(
    version: bool = typer.Option(
        None, "--version", "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    pass


def _configure_logging(debug: bool) -> None:
    level = logging.DEBUG if debug else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )
    # Always show smritix logs at DEBUG when --debug is set
    logging.getLogger("smritix").setLevel(level)

@app.command()
def init(
    lookback_days: int = typer.Option(
        None,
        "--lookback-days", "-d",
        help="How many days of session history to load (0 = all). Default: asks interactively.",
    )
):
    """Initialize Smritix: create DB, download model, configure AI tools."""
    from smritix.agents import setup_agents
    from smritix.db.connection import get_connection
    from smritix.db.schema import create_schema
    from smritix.embedding.encoder import embed

    typer.echo("Initializing Smritix...")

    # DB setup — skip gracefully if another process holds the lock
    try:
        conn = get_connection()
        create_schema(conn)
        typer.echo(f"  Database: {DATA_DIR / 'smritix.duckdb'}")
    except RuntimeError:
        typer.echo(f"  Database: {DATA_DIR / 'smritix.duckdb'} (already running — skipping schema)")

    typer.echo("  Downloading embedding model (~300MB on first run)...")
    embed("warmup")
    typer.echo("  Model ready.")

    typer.echo("\n  Configuring AI agents...")
    project_dir = Path.cwd()
    setup_results = setup_agents(project_dir)
    for result in setup_results:
        for message in result.messages:
            typer.echo(f"  {message}")

    # Show detected session directories
    typer.echo("\n  Session directories:")
    for result in setup_results:
        if result.session_dir is None:
            continue
        typer.echo(f"    {result.agent}: {result.session_dir}")
        if not result.session_dir.exists():
            typer.echo("      not found - set the matching session directory env var if stored elsewhere")

    # Ask how far back to load sessions
    if lookback_days is None:
        typer.echo("")
        lookback_days = typer.prompt(
            "How many days of session history to load? "
            "(7 = last week, 30 = last month, 0 = all history)",
            default=7,
        )

    # Persist to .env in data dir so future runs remember the choice
    env_file = DATA_DIR / ".env"
    _set_env_value(env_file, "SMRITIX_SESSION_LOOKBACK_DAYS", str(lookback_days))
    if lookback_days == 0:
        typer.echo("  Session history: all (every session will be processed)")
    else:
        typer.echo(f"  Session history: last {lookback_days} day(s)")

    typer.echo(
        "\n  To change later:\n"
        "    smritix init --lookback-days 14\n"
        "    export SMRITIX_SESSION_LOOKBACK_DAYS=14"
    )

    # Set up sync state (incremental + historical jobs) in DB
    try:
        from smritix.db.connection import get_connection
        from smritix.db.schema import create_schema
        from smritix.watcher.sync_setup import setup_sync_state
        _conn = get_connection()
        create_schema(_conn)
        setup_sync_state(_conn, lookback_days=int(lookback_days))
        hist_msg = (
            f"scanning last {lookback_days} day(s)" if int(lookback_days) > 0
            else "scanning all history"
        )
        typer.echo(
            "  Sync state initialised:"
            "\n    incremental — cursor starts from now"
            f"\n    historical  — {hist_msg}"
        )
    except Exception as exc:
        typer.echo(f"  Warning: could not initialise sync state: {exc}", err=True)

    # Provider setup
    typer.echo("")
    typer.echo("AI provider setup")
    typer.echo("  Smritix needs an AI to analyze your sessions and extract memories.")
    providers_configured: list[str] = []
    env_vars_to_write: dict[str, str] = {}
    _run_provider_setup(env_file, providers_configured, env_vars_to_write)

    if providers_configured:
        providers_str = ",".join(providers_configured)
        _set_env_value(env_file, "SMRITIX_PROVIDERS", providers_str)
        typer.echo(f"  Provider configured: {providers_str}")

    typer.echo("\nDone. Start the server: smritix serve")


def _run_provider_setup(
    env_file: Path,
    providers_configured: list,
    env_vars_to_write: dict,
) -> None:
    """Interactive provider selection — shared by init and provider reconfigure."""
    typer.echo("  How do you access AI?")
    typer.echo("    1. Subscription (Claude.ai / Codex — no API key needed)")
    typer.echo("    2. API key (Anthropic / Ollama / Gemini / OpenAI)")
    access_type = typer.prompt("  Select", default="1").strip()

    if access_type == "1":
        _setup_subscription_provider(env_file, providers_configured)
    else:
        _setup_apikey_provider(env_file, providers_configured, env_vars_to_write)


def _setup_subscription_provider(env_file: Path, providers_configured: list) -> None:
    """Interactive setup for subscription-based users (Claude CLI or Codex CLI)."""
    import subprocess as _subprocess
    from smritix.providers.sub_claude import ClaudeCliProvider
    from smritix.providers.sub_codex import CodexCliProvider

    typer.echo("\n  Which CLI do you use?")
    typer.echo("    1. Claude Code (claude)")
    typer.echo("    2. Codex (codex)")
    choice = typer.prompt("  Select", default="1").strip()

    cli_name = "claude" if choice == "1" else "codex"
    provider_name = "sub_claude" if choice == "1" else "sub_codex"
    provider_cls = ClaudeCliProvider if choice == "1" else CodexCliProvider

    try:
        result = _subprocess.run(
            [cli_name, "--version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            typer.echo(f"  Warning: {cli_name} returned non-zero. Continuing anyway.", err=True)
        else:
            typer.echo(f"  {cli_name} found: {result.stdout.strip()[:60]}")
    except FileNotFoundError:
        typer.echo(
            f"  Warning: {cli_name} not found. "
            f"Install it, then run: smritix provider reconfigure",
            err=True,
        )
        return
    except _subprocess.TimeoutExpired:
        typer.echo(
            f"  Warning: {cli_name} --version timed out. "
            f"CLI may be slow to start. Continuing anyway.",
            err=True,
        )

    # Ask which model to use
    model = _ask_model(provider_cls)
    _set_env_value(env_file, "SMRITIX_DRAFTER_MODEL", model)

    _smoke_test_provider(provider_cls())
    providers_configured.append(provider_name)


_SMOKE_CONVERSATION = "User: say the word OK and nothing else\nAI: "


def _smoke_test_provider(provider) -> bool:
    """
    Send a tiny test conversation through the real provider pipeline.
    Returns True if provider responds with any non-empty output, False otherwise.
    Warns but does not block setup — user may fix env vars and retry later.
    """
    typer.echo(f"  Testing provider {provider.name()}...", nl=False)
    try:
        raw = provider.analyze(_SMOKE_CONVERSATION)
        if raw and raw.strip():
            typer.echo(" ✓ OK")
            return True
        typer.echo(" ✗ empty response")
        return False
    except Exception as exc:
        typer.echo(f" ✗ failed: {str(exc)[:120]}")
        return False


def _ask_model(provider_cls, api_key: str | None = None) -> str:
    """Fetch models for a provider and ask user to choose."""
    typer.echo("  Fetching available models...")
    models = provider_cls.list_models(api_key=api_key)
    default = provider_cls.default_model() or (models[0] if models else "")

    if models:
        typer.echo("  Available models:")
        for i, m in enumerate(models, 1):
            marker = " (default)" if m == default else ""
            typer.echo(f"    {i}. {m}{marker}")
        choice = typer.prompt("  Select model number or type name", default=default).strip()
        # If user entered a number, resolve to model name
        if choice.isdigit():
            idx = int(choice) - 1
            if 0 <= idx < len(models):
                return models[idx]
        return choice
    else:
        return typer.prompt("  Model name", default=default).strip()


def _resolve_key_from_env_var(default_var: str) -> tuple[str, str | None]:
    """
    Ask the user which env var holds their API key.
    Returns (var_name, key_value_or_None).
    The key is read from the shell environment — never prompted, never stored.
    """
    typer.echo("  For security, smritix reads your API key from an environment variable.")
    var_name = typer.prompt(
        "  Env var name that holds your key",
        default=default_var,
    ).strip()
    key = os.environ.get(var_name)
    if key:
        typer.echo(f"  ✓ Found key in ${var_name}")
    else:
        typer.echo(f"  ⚠  ${var_name} is not set in the current shell.")
        typer.echo("     Make sure to export it before running 'smritix serve':")
        typer.echo(f"       export {var_name}=<your-api-key>")
        typer.echo("     smritix will read it from the environment at runtime.")
    return var_name, key


def _setup_apikey_provider(
    env_file: Path,
    providers_configured: list,
    env_vars_to_write: dict,
) -> None:
    """
    Interactive setup for API key users.

    API keys are NEVER stored in smritix config files.
    We store only the name of the environment variable that holds the key.
    The provider reads the key directly from the shell environment at runtime.
    """
    from smritix.providers.api_anthropic import AnthropicProvider
    from smritix.providers.api_gemini import GeminiProvider
    from smritix.providers.api_ollama import OllamaProvider
    from smritix.providers.api_openai import OpenAIProvider

    while True:
        typer.echo("\n  Choose AI provider:")
        typer.echo("    1. Anthropic API")
        typer.echo("    2. Ollama (local, no key needed)")
        typer.echo("    3. Gemini API")
        typer.echo("    4. OpenAI API")
        choice = typer.prompt("  Select", default="1").strip()

        if choice == "1":
            var_name, key = _resolve_key_from_env_var("ANTHROPIC_API_KEY")
            if var_name != "ANTHROPIC_API_KEY":
                _set_env_value(env_file, "SMRITIX_ANTHROPIC_KEY_VAR", var_name)
                env_vars_to_write["SMRITIX_ANTHROPIC_KEY_VAR"] = var_name
            model = _ask_model(AnthropicProvider, api_key=key)
            _set_env_value(env_file, "SMRITIX_DRAFTER_MODEL", model)
            env_vars_to_write["SMRITIX_DRAFTER_MODEL"] = model
            _smoke_test_provider(AnthropicProvider())
            providers_configured.append("api_anthropic")

        elif choice == "2":
            model = _ask_model(OllamaProvider)
            _set_env_value(env_file, "SMRITIX_OLLAMA_MODEL", model)
            env_vars_to_write["SMRITIX_OLLAMA_MODEL"] = model
            _smoke_test_provider(OllamaProvider())
            providers_configured.append("api_ollama")

        elif choice == "3":
            var_name, key = _resolve_key_from_env_var("GEMINI_API_KEY")
            if var_name != "GEMINI_API_KEY":
                _set_env_value(env_file, "SMRITIX_GEMINI_KEY_VAR", var_name)
                env_vars_to_write["SMRITIX_GEMINI_KEY_VAR"] = var_name
            model = _ask_model(GeminiProvider, api_key=key)
            _set_env_value(env_file, "SMRITIX_GEMINI_MODEL", model)
            env_vars_to_write["SMRITIX_GEMINI_MODEL"] = model
            _smoke_test_provider(GeminiProvider())
            providers_configured.append("api_gemini")

        elif choice == "4":
            var_name, key = _resolve_key_from_env_var("OPENAI_API_KEY")
            if var_name != "OPENAI_API_KEY":
                _set_env_value(env_file, "SMRITIX_OPENAI_KEY_VAR", var_name)
                env_vars_to_write["SMRITIX_OPENAI_KEY_VAR"] = var_name
            model = _ask_model(OpenAIProvider, api_key=key)
            _set_env_value(env_file, "SMRITIX_OPENAI_MODEL", model)
            env_vars_to_write["SMRITIX_OPENAI_MODEL"] = model
            _smoke_test_provider(OpenAIProvider())
            providers_configured.append("api_openai")

        else:
            typer.echo("  Invalid choice, skipping.")

        if not typer.confirm("  Add another provider?", default=False):
            break


@app.command("provider")
def provider_cmd():
    """Reconfigure the AI provider (model, API key env var, subscription CLI)."""
    env_file = DATA_DIR / ".env"
    providers_configured: list[str] = []
    env_vars_to_write: dict[str, str] = {}

    typer.echo("Reconfiguring AI provider...")
    _run_provider_setup(env_file, providers_configured, env_vars_to_write)

    if providers_configured:
        providers_str = ",".join(providers_configured)
        _set_env_value(env_file, "SMRITIX_PROVIDERS", providers_str)
        typer.echo(f"  Provider set: {providers_str}")
        typer.echo("Restart smritix serve to apply.")
    else:
        typer.echo("No provider configured.", err=True)
        raise typer.Exit(1)




@app.command()
def serve(
    debug: bool = typer.Option(False, "--debug", help="Enable debug logging."),
):
    """Start the MCP HTTP server + web portal on port 8666 (SMRITIX_MCP_PORT).

    Run this once before opening Claude Code or any other AI agent.
    All sessions share this single server — full read/write for everyone.

    Portal: http://localhost:8666
    MCP:    http://localhost:8666/mcp
    """
    import urllib.request

    _configure_logging(debug)

    from smritix.db.connection import clear_pid, get_connection, write_pid
    from smritix.db.schema import create_schema

    # Check if already running
    import urllib.error
    try:
        with urllib.request.urlopen(
            f"http://localhost:{MCP_PORT}/health", timeout=1
        ) as resp:
            if resp.status == 200:
                typer.echo(f"Smritix already running at http://localhost:{MCP_PORT}")
                raise typer.Exit(0)
    except typer.Exit:
        raise
    except (OSError, urllib.error.URLError):
        pass  # not running — proceed

    # Validate AI provider before starting
    from smritix.providers import ProviderValidationError, get_provider_chain
    providers = get_provider_chain()
    if not providers:
        typer.echo(
            "✗ No AI provider configured.\n"
            "  Run: smritix init",
            err=True,
        )
        raise typer.Exit(1)

    try:
        providers[0].validate()
    except ProviderValidationError as exc:
        typer.echo(
            f"✗ Provider '{providers[0].name()}' failed validation:\n  {exc}\n"
            f"\nRun: smritix provider reconfigure",
            err=True,
        )
        raise typer.Exit(1)

    try:
        conn = get_connection()
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)

    write_pid()
    create_schema(conn)

    from smritix.api.app import create_app
    from smritix.mcp.server import mcp as mcp_server, set_connection

    set_connection(conn)
    app_instance = create_app(conn, mcp_server=mcp_server)

    from smritix.watcher.executor import JobExecutor
    executor = JobExecutor(conn=conn, providers=providers)
    executor.start()

    # Show which sync jobs are active — always visible regardless of --debug
    inc_row = conn.execute("SELECT global_cursor FROM sync_state WHERE id='incremental'").fetchone()
    hist_row = conn.execute(
        "SELECT status, global_cursor, start_time, end_time FROM sync_state WHERE id='historical'"
    ).fetchone()

    typer.echo(f"Smritix → http://localhost:{MCP_PORT}")
    typer.echo(f"  Portal:   http://localhost:{MCP_PORT}/")
    typer.echo(f"  MCP:      http://localhost:{MCP_PORT}/mcp")
    typer.echo(f"  Provider: {', '.join(p.name() for p in providers)}")
    if inc_row:
        typer.echo(f"  Sync:     incremental — cursor: {inc_row[0].strftime('%Y-%m-%d %H:%M') if inc_row[0] else 'none'}")
    else:
        typer.echo("  Sync:     ⚠ no sync state — run 'smritix init' first", err=True)
    if hist_row:
        status, cursor, start, end = hist_row
        def fmt(dt): return dt.strftime('%Y-%m-%d %H:%M') if dt else '?'
        if status == "completed":
            typer.echo(f"            historical — ✓ completed [{fmt(start)} → {fmt(end)}]")
        else:
            typer.echo(
                f"            historical — {status} "
                f"[{fmt(start)} → {fmt(end)}] cursor: {fmt(cursor)}"
            )
    log_level = "debug" if debug else "warning"
    try:
        uvicorn.run(app_instance, host="0.0.0.0", port=MCP_PORT, log_level=log_level)
    finally:
        executor.shutdown()
        clear_pid()


@app.command()
def stop():
    """Stop the running smritix serve process."""
    import os
    import signal

    from smritix.db.connection import _PID_FILE

    if not _PID_FILE.exists():
        typer.echo("Smritix is not running (no PID file found).")
        raise typer.Exit(0)

    try:
        pid = int(_PID_FILE.read_text().strip())
    except (ValueError, OSError):
        typer.echo("Could not read PID file. Try: kill $(lsof -ti:8666)", err=True)
        raise typer.Exit(1)

    try:
        os.kill(pid, signal.SIGTERM)
        _PID_FILE.unlink(missing_ok=True)
        typer.echo(f"Smritix stopped (PID {pid}).")
    except ProcessLookupError:
        _PID_FILE.unlink(missing_ok=True)
        typer.echo("Smritix process was already stopped.")
    except PermissionError:
        typer.echo(f"Permission denied killing PID {pid}. Try: kill {pid}", err=True)
        raise typer.Exit(1)


@app.command(hidden=True)
def mcp(
    debug: bool = typer.Option(False, "--debug", help="Enable debug logging."),
):
    """Deprecated: use 'smritix serve' instead."""
    typer.echo(
        "⚠️  'smritix mcp' is deprecated. Use 'smritix serve' instead.\n"
        "   smritix serve now starts both the portal and MCP HTTP server.",
        err=True,
    )
    serve(debug=debug)


@app.command()
def watch(
    debug: bool = typer.Option(False, "--debug", help="Enable debug logging."),
):
    """Run background sync jobs standalone (without the portal/MCP server).

    Prefer 'smritix serve' which starts everything together.
    Use this only if you want sync without the HTTP server.
    """
    import time as _time

    _configure_logging(debug)

    from dotenv import load_dotenv
    load_dotenv(DATA_DIR / ".env", override=True)

    from smritix.providers import ProviderValidationError, get_provider_chain
    from smritix.db.connection import get_connection
    from smritix.db.schema import create_schema
    from smritix.watcher.executor import JobExecutor

    providers = get_provider_chain()
    if not providers:
        typer.echo("No AI provider configured. Run 'smritix init'.", err=True)
        raise typer.Exit(1)

    try:
        providers[0].validate()
    except ProviderValidationError as exc:
        typer.echo(f"✗ Provider '{providers[0].name()}' failed: {exc}", err=True)
        raise typer.Exit(1)

    try:
        conn = get_connection()
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)

    create_schema(conn)
    executor = JobExecutor(conn=conn, providers=providers)
    executor.start()
    typer.echo("Sync jobs running. Ctrl+C to stop.")

    try:
        while True:
            _time.sleep(60)
    except KeyboardInterrupt:
        typer.echo("Stopping sync jobs...")
        executor.shutdown()
        typer.echo("Done.")


@app.command()
def review():
    """Interactive terminal review of pending memories."""
    from smritix.db.connection import get_connection
    from smritix.db.schema import create_schema
    from smritix.embedding.encoder import embed_memory
    from smritix.storage.embeddings import insert_hot, maybe_merge
    from smritix.storage.memories import (
        confirm_memory,
        get_memory,
        list_pending,
        reject_memory,
    )

    try:
        conn = get_connection()
    except RuntimeError:
        typer.echo(
            f"Smritix MCP server is running. Use the portal to review memories:\n"
            f"  http://localhost:{MCP_PORT}"
        )
        raise typer.Exit()
    create_schema(conn)
    pending = list_pending(conn)

    if not pending:
        typer.echo("No pending memories.")
        raise typer.Exit()

    typer.echo(f"\n{len(pending)} pending memories.\n")
    for i, p in enumerate(pending, 1):
        obs = p.get("obs_type", p.get("type", "?")).upper().replace("_", " ")
        typer.echo(f"[{i}/{len(pending)}]  {obs}  ({int(p['confidence'] * 100)}%)")
        typer.echo(f"  {p['title']}")
        if p.get("narrative"):
            typer.echo(f"  {p['narrative']}")
        if p.get("evidence"):
            typer.echo(f"  Evidence: \"{p['evidence']}\"")
        typer.echo()
        action = typer.prompt("(a)pprove / (r)eject / (e)dit title / (s)kip / (q)uit").lower()
        if action == "q":
            break
        elif action == "s":
            continue
        elif action == "r":
            try:
                reject_memory(conn, p["id"])
                typer.echo("Rejected.\n")
            except ValueError as exc:
                typer.echo(f"Error: {exc}\n")
        elif action in ("a", "e"):
            edited_title = None
            if action == "e":
                edited_title = typer.prompt("Edit title", default=p["title"])
            mid = confirm_memory(conn, p["id"], edited_title=edited_title)
            full_mem = get_memory(conn, mid) or {}
            insert_hot(conn, mid, embed_memory(full_mem))
            maybe_merge(conn)
            typer.echo(f"Saved {mid[:8]}...\n")


@app.command()
def upgrade():
    """Upgrade smritix to the latest version from PyPI."""
    import subprocess

    latest = _get_latest_version()
    if latest is None:
        typer.echo("Could not reach PyPI to check for updates. Try manually: pip install --upgrade smritix")
        raise typer.Exit(1)

    if latest == __version__:
        typer.echo(f"Already on the latest version ({__version__}).")
        raise typer.Exit(0)

    typer.echo(f"Upgrading smritix {__version__} → {latest}...")
    result = subprocess.run(
        ["pip", "install", "--upgrade", "smritix"],
        capture_output=False,
    )
    if result.returncode == 0:
        typer.echo(f"Upgraded to {latest}. Restart smritix serve to apply.")
    else:
        typer.echo("Upgrade failed. Try manually: pip install --upgrade smritix", err=True)
        raise typer.Exit(1)


@app.command()
def status():
    """Show memory database stats."""
    import duckdb as _duckdb

    from smritix.config import DB_PATH
    from smritix.db.connection import get_connection
    from smritix.db.schema import create_schema
    from smritix.storage.embeddings import hot_count

    # status is read-only — connect even if another process holds the write lock
    try:
        conn = get_connection()
        create_schema(conn)
    except RuntimeError:
        conn = _duckdb.connect(str(DB_PATH), read_only=True)
        # skip create_schema — read-only connections cannot create tables

    total = conn.execute(
        "SELECT COUNT(*) FROM memories WHERE is_archived=false"
    ).fetchone()[0]
    pending_count = conn.execute(
        "SELECT COUNT(*) FROM pending_memories WHERE status='pending'"
    ).fetchone()[0]
    links = conn.execute("SELECT COUNT(*) FROM memory_links").fetchone()[0]
    hot = hot_count(conn)
    cold = conn.execute("SELECT COUNT(*) FROM cold_embeddings").fetchone()[0]

    typer.echo(f"Memories : {total}")
    typer.echo(f"Pending  : {pending_count}")
    typer.echo(f"Links    : {links}")
    typer.echo(f"Hot vecs : {hot}")
    typer.echo(f"Cold vecs: {cold}")


@app.command()
def cleanup(
    pending: bool = typer.Option(False, "--pending", help="Purge pending (unconfirmed) memories."),
    permanent: bool = typer.Option(False, "--permanent", help="Also purge confirmed memories."),
    days: int = typer.Option(None, "--days", help="Only purge entries older than N days. Omit to purge all."),
    session_summaries: bool = typer.Option(False, "--session-summaries", help="Purge session_summary entries from pending."),
    confirm: bool = typer.Option(False, "--all", "-a", help="Skip confirmation prompt."),
):
    """
    Purge memories from the database.

    Examples:
      smritix cleanup --pending --days=3          # delete pending older than 3 days
      smritix cleanup --pending --permanent       # delete all pending + confirmed
      smritix cleanup --session-summaries --all   # silently purge all session_summary pending
    """
    import duckdb as _duckdb

    from smritix.config import DB_PATH

    if not pending and not permanent and not session_summaries:
        typer.echo("Nothing to do. Specify --pending, --permanent, or --session-summaries.")
        raise typer.Exit(0)

    # Build human-readable description for confirmation prompt
    targets = []
    age_clause = f" older than {days} day(s)" if days else ""
    if session_summaries:
        targets.append(f"all session_summary entries from pending{age_clause}")
    if pending:
        targets.append(f"pending (unconfirmed) memories{age_clause}")
    if permanent:
        targets.append(f"confirmed memories{age_clause}")

    if not confirm:
        typer.confirm(
            f"This will permanently delete: {', '.join(targets)}. Continue?",
            abort=True,
        )

    try:
        conn = _duckdb.connect(str(DB_PATH))
        conn.execute("INSTALL vss; LOAD vss")
    except Exception as exc:
        typer.echo(
            f"Cannot open database exclusively — stop smritix serve first.\n({exc})",
            err=True,
        )
        raise typer.Exit(1)

    age_filter = f" AND created_at < NOW() - INTERVAL '{days} days'" if days else ""
    deleted_pending = 0
    deleted_confirmed = 0
    deleted_summaries = 0

    if session_summaries:
        r1 = conn.execute(
            f"DELETE FROM pending_memories WHERE obs_type='session_summary'{age_filter}"
        ).fetchone()
        r2 = conn.execute(
            f"DELETE FROM memories WHERE obs_type='session_summary'{age_filter}"
        ).fetchone()
        deleted_summaries = (r1[0] if r1 else 0) + (r2[0] if r2 else 0)
        typer.echo(f"Deleted {deleted_summaries} session_summary entries (pending + confirmed).")

    if pending:
        result = conn.execute(
            f"DELETE FROM pending_memories WHERE status='pending'{age_filter}"
        ).fetchone()
        deleted_pending = result[0] if result else 0
        typer.echo(f"Deleted {deleted_pending} pending memories.")

    if permanent:
        # Also remove their embeddings and links
        if days:
            ids = [
                r[0] for r in conn.execute(
                    f"SELECT id FROM memories WHERE created_at < NOW() - INTERVAL '{days} days'"
                ).fetchall()
            ]
        else:
            ids = [r[0] for r in conn.execute("SELECT id FROM memories").fetchall()]

        if ids:
            placeholders = ",".join("?" * len(ids))
            conn.execute(f"DELETE FROM hot_embeddings WHERE memory_id IN ({placeholders})", ids)
            conn.execute(f"DELETE FROM cold_embeddings WHERE memory_id IN ({placeholders})", ids)
            conn.execute(f"DELETE FROM memory_links WHERE source_id IN ({placeholders}) OR target_id IN ({placeholders})", ids + ids)

        result = conn.execute(
            f"DELETE FROM memories WHERE 1=1{age_filter}"
        ).fetchone()
        deleted_confirmed = result[0] if result else 0
        typer.echo(f"Deleted {deleted_confirmed} confirmed memories.")

        if ids:
            conn.execute("DROP INDEX IF EXISTS idx_cold_hnsw")
            typer.echo("HNSW index dropped (will rebuild on next mcp start).")

    conn.close()
    typer.echo("Cleanup complete.")


@app.command()
def hook(
    session_start: bool = typer.Option(
        False, "--session-start",
        help="SessionStart hook: inject unanalyzed count + pending list.",
    ),
    prompt: bool = typer.Option(
        False, "--prompt",
        help="UserPromptSubmit hook: inject relevant memories from stdin prompt.",
    ),
):
    """
    Memory hooks for Claude Code.

    Registered by smritix init:
      SessionStart     → smritix hook --session-start
      UserPromptSubmit → smritix hook --prompt
    """
    if session_start:
        _hook_session_start()
    elif prompt:
        _hook_prompt()
    else:
        raise typer.Exit(0)


def _hook_session_start() -> None:
    """
    SessionStart hook: auto-approve old pending memories via portal, then inject
    remaining context block. Outputs nothing if nothing to do.
    """
    import urllib.request

    import duckdb as _duckdb

    from smritix.config import DB_PATH, HOOK_AUTO_APPROVE_HOURS, MCP_PORT

    # Step 1: Auto-approve memories — rate-limited to once per 5 minutes.
    # Without this, every background `claude -p` analysis call fires SessionStart
    # and would trigger auto-approve dozens of times per minute.
    _RATE_LIMIT_MINUTES = 5
    _rate_file = DATA_DIR / "last-auto-approve.txt"
    auto_approved = 0
    _should_auto_approve = True
    try:
        import time as _time
        if _rate_file.exists():
            last_run = float(_rate_file.read_text().strip())
            if _time.time() - last_run < _RATE_LIMIT_MINUTES * 60:
                _should_auto_approve = False
    except Exception:
        pass

    if _should_auto_approve:
        try:
            url = (
                f"http://localhost:{MCP_PORT}/api/pending/auto-approve"
                f"?older_than_hours={HOOK_AUTO_APPROVE_HOURS}&min_confidence=0.75"
            )
            req = urllib.request.Request(url, method="POST", headers={"Content-Length": "0"})
            with urllib.request.urlopen(req, timeout=3) as resp:
                result = json.loads(resp.read())
                auto_approved = result.get("approved", 0)
            try:
                import time as _time2
                _rate_file.write_text(str(_time2.time()))
            except Exception:
                pass
        except Exception:
            pass  # Portal not running — skip auto-approve

    # Read pending memories (after auto-approve cleared old ones)
    pending_rows = []
    try:
        conn = _duckdb.connect(str(DB_PATH), read_only=True)
        pending_rows = conn.execute(
            "SELECT id, title, obs_type FROM pending_memories "
            "WHERE status='pending' ORDER BY created_at ASC LIMIT 20"
        ).fetchall()
        conn.close()
    except Exception:
        pass

    if not pending_rows:
        raise typer.Exit(0)

    lines = ["[SMRITIX SESSION START]"]

    if auto_approved:
        lines.append(f"Auto-approved {auto_approved} memories from previous sessions.")

    if pending_rows:
        lines.append(f"\nPending memories ({len(pending_rows)}) — recent, needs your review:")
        for i, (pid, title, obs_type) in enumerate(pending_rows, 1):
            lines.append(f"  {i}. [id:{pid[:8]}] {obs_type} — {title}")
        lines.append(
            "\nDefault: approve-all. "
            "If user mentions a specific memory to change/remove, "
            "call confirm_memory_tool(id, 'reject'|'edit'). "
            "Otherwise approve all with confirm_memory_tool(id, 'approve') for each."
        )

    lines.append("\nHandle session init before answering the user's question.")
    lines.append("[END SMRITIX]")
    typer.echo("\n".join(lines))


def _hook_prompt() -> None:
    """
    UserPromptSubmit hook: read prompt from stdin, inject relevant memories.
    Tries portal HTTP first, falls back to DuckDB keyword search.
    Detects remember/save/note keywords.
    Outputs nothing if no memories found and no keyword detected.
    """
    import sys

    prompt_text = ""
    try:
        raw = sys.stdin.read()
        if raw.strip():
            data = json.loads(raw)
            prompt_text = data.get("prompt", "")
    except Exception:
        pass

    # Skip background analysis calls: the watcher calls `claude --print` which also fires
    # UserPromptSubmit. The analysis prompt has a distinctive fixed header — match on that,
    # NOT on length (which would suppress injection for legitimate long user prompts).
    _ANALYSIS_HEADER = "Analyze this developer AI session"
    if prompt_text.startswith(_ANALYSIS_HEADER):
        raise typer.Exit(0)

    parts = []

    memories = _fetch_memories_for_hook(prompt_text)
    if memories:
        mem_lines = ["[SMRITIX MEMORIES]"]
        for m in memories:
            obs = m.get("obs_type", m.get("type", ""))
            title = m.get("title", "")
            narrative = m.get("narrative", "")
            snippet = narrative[:120].rstrip() if narrative else ""
            mem_lines.append(f"• [{obs}] {title}" + (f" — {snippet}" if snippet else ""))
        mem_lines.append("[END SMRITIX MEMORIES]")
        parts.append("\n".join(mem_lines))

    lower = prompt_text.lower()
    if any(kw in lower for kw in ("remember", "save", "note", "don't forget", "dont forget")):
        parts.append("[SMRITIX] User wants to save a memory — call add_memory() now.")

    if parts:
        typer.echo("\n\n".join(parts))


def _fetch_memories_for_hook(query: str, limit: int = 5) -> list[dict]:
    """
    Fetch relevant memories for the hook via the HTTP server.
    Returns list of memory dicts with at least 'title', 'obs_type', 'narrative'.
    """
    if not query.strip():
        return []

    try:
        import urllib.parse
        import urllib.request

        from smritix.config import MCP_PORT
        q = urllib.parse.quote(query[:500])
        url = f"http://localhost:{MCP_PORT}/api/memories/search?q={q}&limit={limit}"
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=2) as resp:
            body = json.loads(resp.read())
            return body.get("memories", [])[:limit]
    except Exception:
        return []


@app.command()
def reset(
    confirm: bool = typer.Option(False, "--all", "-a", help="Skip confirmation prompt."),
    cursor: bool = typer.Option(False, "--cursor", help="Reset sync cursors so all sessions are re-processed."),
):
    """Reset Smritix state.

    Examples:
      smritix reset --cursor --all      # re-process all sessions from scratch
      smritix reset --all               # wipe everything (memories, pending, embeddings, sync state)

    To delete memories by age or type, use: smritix cleanup
    """
    from smritix.config import DB_PATH

    # --cursor: reset sync cursors so all sessions re-process
    if cursor:
        if not confirm:
            typer.confirm("Reset sync cursors? All sessions will be re-processed. Continue?", abort=True)
        try:
            import duckdb as _duckdb
            conn = _duckdb.connect(str(DB_PATH))
            conn.execute("INSTALL vss; LOAD vss")
            conn.execute(
                "UPDATE sync_state SET global_cursor=start_time, status='pending', updated_at=now() "
                "WHERE id='historical'"
            )
            conn.execute("DELETE FROM session_cursors")
            conn.close()
            typer.echo("Sync cursors reset — re-run 'smritix serve' to re-process sessions.")
        except Exception as exc:
            typer.echo(f"Error: {exc}", err=True)
        return

    # Full reset (no specific flag = wipe everything)
    if not confirm:
        typer.confirm(
            "This will permanently delete ALL memories, embeddings, links, "
            "pending queue, and sync state. Continue?",
            abort=True,
        )

    try:
        from smritix.db.connection import get_connection
        conn = get_connection()
        for table in [
            "hot_embeddings", "cold_embeddings",
            "memory_links",
            "pending_memories", "memories", "sessions",
            "sync_state", "session_cursors",
        ]:
            conn.execute(f"DELETE FROM {table}")
        conn.execute("DROP INDEX IF EXISTS idx_cold_hnsw")
        typer.echo(f"Database cleared: {DB_PATH}")
    except Exception as exc:
        typer.echo(f"Could not clear database: {exc}", err=True)

    typer.echo("Reset complete. Run 'smritix init' then 'smritix serve' to start fresh.")


def _set_env_value(env_file: Path, key: str, value: str) -> None:
    """Write or update a KEY=VALUE line in an env file."""
    env_file.parent.mkdir(parents=True, exist_ok=True)
    lines = env_file.read_text().splitlines() if env_file.exists() else []
    updated = False
    for i, line in enumerate(lines):
        if line.startswith(f"{key}="):
            lines[i] = f"{key}={value}"
            updated = True
            break
    if not updated:
        lines.append(f"{key}={value}")
    env_file.write_text("\n".join(lines) + "\n")
