"""Shared helpers and base class for sync jobs."""
from __future__ import annotations

import logging
import threading
from abc import ABC, abstractmethod
from datetime import datetime, timedelta, timezone

logger = logging.getLogger(__name__)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _get_session_cursor(conn, session_key: str) -> tuple[datetime | None, int]:
    row = conn.execute(
        "SELECT last_msg_time, processed_count FROM session_cursors WHERE session_id = ?",
        [session_key],
    ).fetchone()
    return (row[0], row[1]) if row else (None, 0)


def _save_session_cursor(conn, session_key: str, tool: str, last_msg_time: datetime, count: int) -> None:
    conn.execute("""
        INSERT INTO session_cursors (session_id, tool, last_msg_time, processed_count, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT (session_id) DO UPDATE SET
            last_msg_time   = excluded.last_msg_time,
            processed_count = excluded.processed_count,
            updated_at      = excluded.updated_at
    """, [session_key, tool, last_msg_time, count, _now()])


def _save_global_cursor(conn, job_id: str, cursor: datetime, status: str = "running") -> None:
    conn.execute("""
        UPDATE sync_state
        SET global_cursor = ?, status = ?, updated_at = ?
        WHERE id = ?
    """, [cursor, status, _now(), job_id])


def _get_settled_messages(messages, settle_minutes: int = 5):
    cutoff = _now() - timedelta(minutes=settle_minutes)
    return [m for m in messages if m.timestamp.replace(microsecond=0) < cutoff.replace(microsecond=0)]


def _scan_and_process(
    conn,
    job_id: str,
    providers: list,
    range_start: datetime,
    range_end: datetime | None,
    settle_minutes: int = 5,
) -> "datetime | None | bool":
    """
    Scan session files within [range_start, range_end] and run the drafter on new content.

    Return values:
      datetime  — furthest cursor reached (at least one session processed successfully)
      False     — sessions with pending content were found but ALL providers failed (caller should retry)
      None      — no processable sessions in range (caller may advance cursor / mark complete)
    """
    from smritix.agents import get_available_readers
    from smritix.drafter.session_drafter import draft_from_session

    furthest_cursor: datetime | None = None
    found_processable = False   # True if any session had settled messages (needed drafting)
    provider_failed_any = False  # True if at least one session's provider call failed

    logger.debug(
        "_scan_and_process range=[%s, %s]",
        range_start.isoformat(), range_end.isoformat() if range_end else "∞",
    )

    for reader in get_available_readers():
        try:
            sessions = reader.list_sessions()
        except Exception as exc:
            logger.warning("Error listing sessions from %s: %s", reader.__class__.__name__, exc)
            continue

        logger.debug("Reader %s returned %d sessions", reader.__class__.__name__, len(sessions))

        for session in sessions:
            if session.last_modified < range_start:
                continue
            if range_end and session.last_modified > range_end:
                continue

            session_key = f"{session.tool}:{session.id}"
            last_msg_time, prev_count = _get_session_cursor(conn, session_key)

            try:
                msgs = reader.get_messages(session.id, since=last_msg_time)
                stripped = reader.strip_tool_results(msgs)
                settled = _get_settled_messages(stripped, settle_minutes)
            except Exception as exc:
                logger.warning("Error reading session %s: %s", session.id, exc)
                continue

            if not settled:
                logger.debug(
                    "Session %s (%s): no settled messages (last_msg_time=%s)",
                    session.id, session.tool, last_msg_time,
                )
                continue

            found_processable = True
            logger.info(
                "Session %s (%s): %d settled messages — last_msg_time=%s, last_modified=%s",
                session.id, session.tool, len(settled),
                last_msg_time, session.last_modified.isoformat(),
            )

            try:
                success = draft_from_session(session, settled, session.id, conn, providers=providers)
            except Exception as exc:
                logger.error("Drafter raised for session %s — skipping checkpoint: %s", session.id, exc)
                provider_failed_any = True
                continue

            if not success:
                # Provider failed — don't checkpoint, will retry on next run
                logger.warning("Provider failed for session %s — skipping checkpoint", session.id)
                provider_failed_any = True
                continue

            # Only checkpoint after successful draft
            latest_msg_time = max(m.timestamp for m in settled)
            _save_session_cursor(conn, session_key, session.tool, latest_msg_time, prev_count + len(settled))
            logger.debug(
                "Session %s checkpointed: last_msg_time=%s count=%d",
                session.id, latest_msg_time.isoformat(), prev_count + len(settled),
            )

            if furthest_cursor is None or session.last_modified > furthest_cursor:
                furthest_cursor = session.last_modified

            if furthest_cursor:
                _save_global_cursor(conn, job_id, furthest_cursor)

    if furthest_cursor is not None:
        logger.debug("_scan_and_process done: furthest_cursor=%s", furthest_cursor.isoformat())
        return furthest_cursor

    if found_processable and provider_failed_any:
        # Sessions exist and have content, but every provider call failed.
        # Signal caller to retry rather than advancing cursor.
        logger.warning("_scan_and_process: processable sessions found but all providers failed — signalling retry")
        return False

    logger.debug("_scan_and_process: no processable sessions in range")
    return None


class SyncJob(ABC):
    """Base class for all sync jobs. Each job opens its own DuckDB connection."""

    def __init__(self, job_id: str, conn, providers: list, stop_event: threading.Event):
        self.job_id = job_id
        self._conn_arg = conn
        self.providers = providers
        self.stop_event = stop_event

    def _get_conn(self):
        if self._conn_arg is not None:
            return self._conn_arg
        from smritix.config import DB_PATH
        from smritix.db.connection import _load_extensions
        import duckdb
        conn = duckdb.connect(str(DB_PATH))
        _load_extensions(conn)
        return conn

    @abstractmethod
    def run(self) -> None:
        """Run until stop_event is set or job completes."""
