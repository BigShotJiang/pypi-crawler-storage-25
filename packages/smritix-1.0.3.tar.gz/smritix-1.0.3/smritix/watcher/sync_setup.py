"""
Functions called by `smritix init` to set up sync state rows.
Both incremental and historical state are initialised here in one shot.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone


def _now() -> datetime:
    return datetime.now(timezone.utc)


def setup_sync_state(conn, lookback_days: int) -> None:
    """
    Called during `smritix init`. Creates sync_state rows on first run only.

    - 'incremental': cursor = now(), open-ended, runs every 15 min forever
    - 'historical':  range = [now - lookback_days, now], runs once until completed

    Existing rows are NEVER touched — init is for config only, not for resetting
    progress. Use `smritix reset --cursor` to restart sync from scratch.
    """
    now = _now()

    # ── Incremental: insert only if not already present ──────────────────────
    conn.execute("""
        INSERT INTO sync_state (id, job_type, status, start_time, end_time, global_cursor, created_at, updated_at)
        VALUES ('incremental', 'incremental', 'pending', ?, NULL, ?, ?, ?)
        ON CONFLICT (id) DO NOTHING
    """, [now, now, now, now])

    # ── Historical: insert only if not already present ───────────────────────
    if lookback_days == 0:
        start = datetime.min.replace(tzinfo=timezone.utc)
    else:
        start = now - timedelta(days=lookback_days)

    conn.execute("""
        INSERT INTO sync_state (id, job_type, status, start_time, end_time, global_cursor, created_at, updated_at)
        VALUES ('historical', 'historical', 'pending', ?, ?, ?, ?, ?)
        ON CONFLICT (id) DO NOTHING
    """, [start, now, start, now, now])
