"""HistoricalSyncJob — processes sessions in a time range once, then completes."""
from __future__ import annotations

import logging
import time
from datetime import timedelta, timezone

from smritix.watcher.base import SyncJob, _now, _save_global_cursor, _scan_and_process

logger = logging.getLogger(__name__)


class HistoricalSyncJob(SyncJob):
    """
    Processes all sessions in [start_time, end_time], checkpointing after every session.
    Marks itself completed when cursor >= end_time.
    Resumes from last global_cursor if interrupted — does NOT restart from beginning.
    """

    BATCH_SLEEP = 1  # seconds between batches

    def run(self) -> None:
        logger.info("HistoricalSyncJob started")
        conn = self._get_conn()
        conn.execute(
            "UPDATE sync_state SET status='running', updated_at=? WHERE id=?",
            [_now(), self.job_id],
        )

        while not self.stop_event.is_set():
            row = conn.execute(
                "SELECT global_cursor, end_time FROM sync_state WHERE id = ?", [self.job_id]
            ).fetchone()
            if not row:
                break

            cursor, end_time = row[0], row[1]
            if cursor.tzinfo is None:
                cursor = cursor.replace(tzinfo=timezone.utc)
            if end_time and end_time.tzinfo is None:
                end_time = end_time.replace(tzinfo=timezone.utc)

            logger.debug(
                "HistoricalSyncJob loop: cursor=%s end_time=%s",
                cursor.isoformat(), end_time.isoformat() if end_time else "None",
            )

            if end_time and cursor >= end_time:
                _save_global_cursor(conn, self.job_id, cursor, status="completed")
                logger.info("HistoricalSyncJob completed — cursor reached end_time")
                return

            furthest = _scan_and_process(
                conn, self.job_id, self.providers,
                range_start=cursor,
                range_end=end_time,
            )

            if furthest is False:
                # Sessions exist with content but every provider call failed.
                # Do NOT advance cursor. Back off and retry.
                logger.warning(
                    "HistoricalSyncJob: provider failures — will retry in %ds (cursor stays at %s)",
                    self.BATCH_SLEEP * 10, cursor.isoformat(),
                )
                for _ in range(self.BATCH_SLEEP * 10):
                    if self.stop_event.is_set():
                        break
                    time.sleep(1)
                continue

            if furthest is None:
                # No processable sessions remain in range — we're done.
                _save_global_cursor(conn, self.job_id, end_time or cursor, status="completed")
                logger.info("HistoricalSyncJob completed — no more sessions in range")
                return

            # furthest is a datetime — at least one session was processed.
            # Guarantee monotonic advancement so we don't revisit the same timestamp forever.
            if furthest <= cursor:
                furthest = cursor + timedelta(microseconds=1)
                _save_global_cursor(conn, self.job_id, furthest)
                logger.debug("HistoricalSyncJob: cursor bumped to %s (monotonic guard)", furthest.isoformat())

            logger.info("HistoricalSyncJob: cursor now %s", furthest.isoformat())

            if not self.stop_event.is_set():
                time.sleep(self.BATCH_SLEEP)

        logger.info("HistoricalSyncJob stopped (interrupted)")
