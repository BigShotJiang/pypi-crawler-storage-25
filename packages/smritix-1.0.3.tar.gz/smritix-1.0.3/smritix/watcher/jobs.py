"""Re-exports for backward compatibility. Import directly from sub-modules."""
from smritix.watcher.auto_approve import AutoApproveJob
from smritix.watcher.base import (
    SyncJob,
    _get_session_cursor,
    _now,
    _save_global_cursor,
    _save_session_cursor,
    _scan_and_process,
)
from smritix.watcher.historical import HistoricalSyncJob
from smritix.watcher.incremental import IncrementalSyncJob

__all__ = [
    "SyncJob",
    "IncrementalSyncJob",
    "HistoricalSyncJob",
    "AutoApproveJob",
    "_now",
    "_get_session_cursor",
    "_save_session_cursor",
    "_save_global_cursor",
    "_scan_and_process",
]
