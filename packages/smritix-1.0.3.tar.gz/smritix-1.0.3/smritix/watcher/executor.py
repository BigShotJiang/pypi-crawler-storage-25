"""
JobExecutor — manages sync threads like a Java ScheduledExecutorService.

Three fixed slots:
  slot 0: HistoricalSyncJob (optional — only if historical row exists in DB)
  slot 1: IncrementalSyncJob
  slot 2: AutoApproveJob

Each job opens its own DuckDB connection — DuckDB connections are NOT thread-safe,
sharing a single connection across threads causes silent failures.

All jobs share a stop_event so smritix serve shutdown is clean.
"""
from __future__ import annotations

import logging
import threading
from concurrent.futures import ThreadPoolExecutor


logger = logging.getLogger(__name__)


def _open_job_conn():
    """Open a fresh DuckDB connection for a job thread."""
    from smritix.config import DB_PATH
    from smritix.db.connection import _load_extensions
    import duckdb
    conn = duckdb.connect(str(DB_PATH))
    _load_extensions(conn)
    return conn


class JobExecutor:
    """Manages the three sync threads. Each job gets its own DB connection."""

    def __init__(self, conn, providers: list):
        # Main conn used only for reading sync state at startup.
        # Individual jobs open their own connections.
        self._main_conn = conn
        self.providers = providers
        self._stop = threading.Event()
        self._pool = ThreadPoolExecutor(max_workers=3, thread_name_prefix="smritix-sync")
        self._futures = []

    def start(self) -> None:
        """Start all configured jobs."""
        from smritix.watcher.auto_approve import AutoApproveJob
        from smritix.watcher.historical import HistoricalSyncJob
        from smritix.watcher.incremental import IncrementalSyncJob

        # Always start incremental
        inc_row = self._main_conn.execute(
            "SELECT id, global_cursor FROM sync_state WHERE id = 'incremental'"
        ).fetchone()
        if not inc_row:
            logger.warning(
                "No incremental sync state found. "
                "Run 'smritix init' to set up sync — sessions will not be analysed until then."
            )
        if inc_row:
            inc_job = IncrementalSyncJob(
                job_id="incremental",
                conn=None,           # job opens its own connection
                providers=self.providers,
                stop_event=self._stop,
            )
            self._futures.append(self._pool.submit(inc_job.run))
            logger.info("IncrementalSyncJob submitted (cursor: %s)", inc_row[1])

        # Start historical if pending or running
        hist_row = self._main_conn.execute(
            "SELECT id, global_cursor, status FROM sync_state WHERE id = 'historical'"
        ).fetchone()
        if hist_row and hist_row[2] not in ("completed", "failed"):
            hist_job = HistoricalSyncJob(
                job_id="historical",
                conn=None,           # job opens its own connection
                providers=self.providers,
                stop_event=self._stop,
            )
            self._futures.append(self._pool.submit(hist_job.run))
            logger.info("HistoricalSyncJob submitted (cursor: %s, status: %s)", hist_row[1], hist_row[2])

        # Always start auto-approve
        auto_job = AutoApproveJob(
            job_id="auto_approve",
            conn=None,               # job opens its own connection
            providers=self.providers,
            stop_event=self._stop,
        )
        self._futures.append(self._pool.submit(auto_job.run))
        logger.info("AutoApproveJob submitted")

    def shutdown(self) -> None:
        """Signal all jobs to stop and wait up to 3 seconds, then give up."""
        logger.info("JobExecutor: shutting down...")
        self._stop.set()
        # cancel_futures drops queued-but-not-started work immediately.
        # wait=False returns at once; threads will exit on their own once they
        # check stop_event on the next loop iteration — no second Ctrl+C needed.
        self._pool.shutdown(wait=False, cancel_futures=True)
        logger.info("JobExecutor: shutdown signal sent")
