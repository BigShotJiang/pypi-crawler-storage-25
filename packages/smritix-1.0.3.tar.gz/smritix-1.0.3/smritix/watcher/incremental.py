"""IncrementalSyncJob — polls for new sessions every 15 minutes, runs forever."""
from __future__ import annotations

import logging
import time
from datetime import datetime, timezone

from smritix.watcher.base import SyncJob, _now, _scan_and_process

logger = logging.getLogger(__name__)


class IncrementalSyncJob(SyncJob):
    """
    Polls every POLL_INTERVAL_MINUTES for new sessions since the last cursor.
    Cursor grows from init time onward — never completes, stops on stop_event.
    """

    POLL_INTERVAL_MINUTES = 15

    def run(self) -> None:
        logger.info("IncrementalSyncJob started")
        conn = self._get_conn()
        conn.execute(
            "UPDATE sync_state SET status='running', updated_at=? WHERE id=?",
            [_now(), self.job_id],
        )

        while not self.stop_event.is_set():
            try:
                self._poll(conn)
            except Exception as exc:
                logger.error("IncrementalSyncJob poll error: %s", exc)

            for _ in range(self.POLL_INTERVAL_MINUTES * 12):
                if self.stop_event.is_set():
                    break
                time.sleep(5)

        logger.info("IncrementalSyncJob stopped")

    def _poll(self, conn) -> None:
        row = conn.execute(
            "SELECT global_cursor FROM sync_state WHERE id = ?", [self.job_id]
        ).fetchone()
        if not row:
            return

        cursor: datetime = row[0]
        if cursor.tzinfo is None:
            cursor = cursor.replace(tzinfo=timezone.utc)

        logger.debug("IncrementalSyncJob polling since %s", cursor)
        furthest = _scan_and_process(conn, self.job_id, self.providers, range_start=cursor, range_end=None)
        if furthest:
            logger.info("IncrementalSyncJob advanced cursor to %s", furthest)
