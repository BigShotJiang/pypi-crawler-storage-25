"""AutoApproveJob — hourly housekeeping: approve, expire, and purge memories."""
from __future__ import annotations

import logging
import time
from datetime import timedelta

from smritix.watcher.base import SyncJob, _now

logger = logging.getLogger(__name__)


class AutoApproveJob(SyncJob):
    """
    Runs every hour:
      - Auto-approves pending memories older than AUTO_APPROVE_HOURS
      - Expires (rejects) pending memories older than EXPIRE_DAYS
      - Permanently purges archived memories older than ARCHIVE_EXPIRE_DAYS
    """

    INTERVAL_HOURS = 1

    def run(self) -> None:
        logger.info("AutoApproveJob started")
        conn = self._get_conn()

        while not self.stop_event.is_set():
            try:
                self._run_once(conn)
            except Exception as exc:
                logger.error("AutoApproveJob error: %s", exc)

            for _ in range(self.INTERVAL_HOURS * 720):
                if self.stop_event.is_set():
                    break
                time.sleep(5)

        logger.info("AutoApproveJob stopped")

    def _run_once(self, conn) -> None:
        from smritix.config import (
            ARCHIVE_EXPIRE_DAYS,
            AUTO_APPROVE_HOURS,
            AUTO_APPROVE_THRESHOLD,
            EXPIRE_DAYS,
        )
        from smritix.embedding.encoder import embed_memory
        from smritix.storage.embeddings import insert_hot, maybe_merge
        from smritix.storage.memories import confirm_memory, get_memory, reject_memory

        now = _now()
        approve_cutoff = now - timedelta(hours=AUTO_APPROVE_HOURS)
        expire_cutoff = now - timedelta(days=EXPIRE_DAYS)

        pending = conn.execute(
            "SELECT id, confidence, created_at FROM pending_memories WHERE status='pending'"
        ).fetchall()

        approved = rejected = 0
        for pid, confidence, created_at in pending:
            if created_at.tzinfo is None:
                created_at = created_at.replace(tzinfo=now.tzinfo)
            if created_at < expire_cutoff:
                try:
                    reject_memory(conn, pid)
                    rejected += 1
                except ValueError:
                    pass
                continue
            if created_at < approve_cutoff and confidence >= AUTO_APPROVE_THRESHOLD:
                try:
                    mid = confirm_memory(conn, pid)
                    mem = get_memory(conn, mid) or {}
                    insert_hot(conn, mid, embed_memory(mem))
                    approved += 1
                except Exception as exc:
                    logger.warning("auto_approve failed for %s: %s", pid, exc)

        if approved or rejected:
            maybe_merge(conn)
            logger.info("AutoApproveJob: approved=%d rejected=%d", approved, rejected)

        if ARCHIVE_EXPIRE_DAYS > 0:
            purge_cutoff = now - timedelta(days=ARCHIVE_EXPIRE_DAYS)
            expired_ids = [
                r[0] for r in conn.execute(
                    "SELECT id FROM memories WHERE is_archived=true AND created_at < ?",
                    [purge_cutoff],
                ).fetchall()
            ]
            if expired_ids:
                ph = ",".join("?" * len(expired_ids))
                conn.execute(f"DELETE FROM hot_embeddings WHERE memory_id IN ({ph})", expired_ids)
                conn.execute(f"DELETE FROM cold_embeddings WHERE memory_id IN ({ph})", expired_ids)
                conn.execute(
                    f"DELETE FROM memory_links WHERE source_id IN ({ph}) OR target_id IN ({ph})",
                    expired_ids + expired_ids,
                )
                conn.execute(f"DELETE FROM memories WHERE id IN ({ph})", expired_ids)
                logger.info("AutoApproveJob: purged %d expired archives", len(expired_ids))
