import json
import uuid

from fastmcp import FastMCP

from smritix import __version__, parse_version as _parse_version
from smritix.db.connection import get_connection
from smritix.db.schema import create_schema
from smritix.embedding.encoder import embed, embed_memory
from smritix.scoring import enforce_token_budget, score_and_rank
from smritix.storage.embeddings import insert_hot, maybe_merge, search
from smritix.storage.memories import (
    confirm_memory,
    get_memory,
    increment_access,
    list_pending,
    reject_memory,
)

mcp = FastMCP("smritix")

_db_conn = None
_upgrade_warning: str | None = None  # cached once per process



def _check_upgrade() -> str | None:
    """Return upgrade warning string if PyPI has a strictly newer version, else None."""
    global _upgrade_warning
    if _upgrade_warning is not None:
        return _upgrade_warning if _upgrade_warning else None
    try:
        import urllib.request
        with urllib.request.urlopen(
            "https://pypi.org/pypi/smritix/json", timeout=2
        ) as resp:
            latest = json.loads(resp.read())["info"]["version"]
        if _parse_version(latest) > _parse_version(__version__):
            _upgrade_warning = (
                f"[smritix upgrade available: {__version__} → {latest}. "
                f"Run: smritix upgrade]"
            )
        else:
            _upgrade_warning = ""  # empty string = checked, no upgrade needed
    except Exception:
        _upgrade_warning = ""
    return _upgrade_warning if _upgrade_warning else None


def _get_conn():
    global _db_conn
    if _db_conn is None:
        _db_conn = get_connection()
        create_schema(_db_conn)
    return _db_conn


def set_connection(conn):
    """Override the DB connection. Used in tests to inject an in-memory connection."""
    global _db_conn
    _db_conn = conn


@mcp.tool()
def get_memories(query: str, limit: int = 5, project_path: str = "") -> dict:
    """
    Retrieve relevant memories for the current task.
    ALWAYS call this at the start of every new task or question.
    query: the user's task or question
    project_path: current working directory — memories from this project score higher
    Returns scored memories within a 500-token budget.
    """
    conn = _get_conn()
    query_vec = embed(query)
    raw_hits = search(conn, query_vec, limit=limit * 4)
    if not raw_hits:
        return {"memories": [], "token_count": 0, "project": project_path}

    enriched = []
    for hit in raw_hits:
        mem = get_memory(conn, hit["memory_id"])
        if mem and not mem["is_archived"]:
            mem["similarity"] = hit["similarity"]
            mem["_query_project"] = project_path  # passed to scorer
            enriched.append(mem)

    ranked = score_and_rank(enriched)
    selected, token_count = enforce_token_budget(ranked[:limit])

    for m in selected:
        increment_access(conn, m["id"])

    result = {
        "memories": [
            {
                "title": m["title"],
                "narrative": m["narrative"],
                "obs_type": m["obs_type"],
                "type": m["type"],
                "project": (m.get("project_path") or "").split("/")[-1],
                "score": round(m["final_score"], 3),
            }
            for m in selected
        ],
        "token_count": token_count,
        "project": (project_path.rstrip("/").split("/")[-1]) if project_path else "",
    }
    warning = _check_upgrade()
    if warning:
        result["upgrade_warning"] = warning
    return result


@mcp.tool()
def list_pending_memories() -> dict:
    """
    Check for memories awaiting user confirmation.
    Call ONCE at the start of every session, before any other work.
    If pending memories exist, show them inline and ask user to confirm.
    Default is keep — user only acts to remove or correct wrong ones.
    """
    conn = _get_conn()
    pending = list_pending(conn)
    result = {"pending": pending, "count": len(pending)}
    warning = _check_upgrade()
    if warning:
        result["upgrade_warning"] = warning
    return result


@mcp.tool()
def confirm_memory_tool(
    pending_id: str,
    action: str,
    edited_title: str = "",
) -> dict:
    """
    Confirm, reject, or edit a pending memory after user review.
    action: 'approve' | 'reject' | 'edit'
    edited_title is required when action is 'edit'.
    """
    conn = _get_conn()

    if action == "reject":
        try:
            reject_memory(conn, pending_id)
        except ValueError:
            return {"error": f"pending memory {pending_id} not found"}
        return {"status": "rejected", "pending_id": pending_id}

    row = conn.execute(
        "SELECT title, narrative FROM pending_memories WHERE id=?", [pending_id]
    ).fetchone()
    if row is None:
        return {"error": f"pending memory {pending_id} not found"}

    final_title = edited_title if (action == "edit" and edited_title) else None
    mid = confirm_memory(conn, pending_id, edited_title=final_title)
    mem = get_memory(conn, mid) or {}
    vec = embed_memory(mem)
    insert_hot(conn, mid, vec)
    maybe_merge(conn)
    return {"status": "confirmed", "memory_id": mid}


@mcp.tool()
def add_memory(
    title: str,
    narrative: str,
    obs_type: str = "preference",
    type: str = "context",
    facts: list = None,
    tags: list = None,
) -> dict:
    """
    Manually save a memory when user explicitly says remember/note/save/don't forget.
    title: short headline (what was decided/preferred)
    narrative: why it matters, with project context
    obs_type: change|discovery|feature|bug_fix|correction|preference
    type: decision|preference|learning|context|anti_pattern
    """
    conn = _get_conn()
    mid = str(uuid.uuid4())
    conn.execute(
        """INSERT INTO memories (
            id, title, obs_type, type, facts, narrative, tags,
            files_mentioned, confirmed_by_user, confidence
        ) VALUES (?, ?, ?, ?, ?, ?, ?, '[]', true, 1.0)""",
        [
            mid, title, obs_type, type,
            json.dumps(facts or []), narrative,
            json.dumps(tags or []),
        ],
    )
    mem = get_memory(conn, mid) or {}
    insert_hot(conn, mid, embed_memory(mem))
    maybe_merge(conn)
    return {"status": "saved", "memory_id": mid, "title": title}


@mcp.tool()
def delete_memory(memory_id: str) -> dict:
    """
    Archive (soft-delete) a confirmed memory so it no longer appears in searches.
    Use when a memory is outdated, incorrect, or no longer relevant.
    The memory is not permanently deleted — it can be recovered via the portal.
    memory_id: the id field from get_memories results.
    """
    conn = _get_conn()
    mem = get_memory(conn, memory_id)
    if mem is None:
        return {"error": f"memory {memory_id} not found"}
    if mem.get("is_archived"):
        return {"status": "already_archived", "memory_id": memory_id}
    from smritix.storage.memories import archive_memory
    archive_memory(conn, memory_id)
    return {"status": "archived", "memory_id": memory_id, "title": mem.get("title", "")}


# get_unanalyzed_sessions and save_memory_drafts are intentionally removed.
# Session analysis is now handled entirely by the watcher inside smritix serve.
# Hooks are read-only: get_memories, list_pending_memories, confirm_memory_tool.
# Explicit user actions: add_memory, delete_memory.


if __name__ == "__main__":
    mcp.run()
