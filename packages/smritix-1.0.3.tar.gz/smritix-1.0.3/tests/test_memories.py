from smritix.storage.memories import (
    insert_pending, confirm_memory, reject_memory,
    get_memory, list_pending, archive_memory, increment_access,
)


def _insert(conn, title="Use exponential backoff", obs_type="decision",
            type_="decision", confidence=0.9, session_id="s1"):
    return insert_pending(
        conn, title=title, obs_type=obs_type, type_=type_,
        facts=["fact one"], narrative="narrative text",
        tags=["pattern"], files_mentioned=[],
        confidence=confidence, evidence="user said so",
        source_session_id=session_id,
    )


def test_insert_pending(conn):
    pid = _insert(conn)
    row = conn.execute("SELECT status FROM pending_memories WHERE id=?", [pid]).fetchone()
    assert row[0] == "pending"


def test_confirm_memory(conn):
    pid = _insert(conn, title="Use DuckDB not SQLite")
    mid = confirm_memory(conn, pid, edited_title="Use DuckDB for analytics")
    mem = get_memory(conn, mid)
    assert mem["title"] == "Use DuckDB for analytics"
    assert mem["confirmed_by_user"] is True
    status = conn.execute(
        "SELECT status FROM pending_memories WHERE id=?", [pid]
    ).fetchone()[0]
    assert status == "approved"


def test_confirm_memory_no_edit(conn):
    pid = _insert(conn, title="Original title")
    mid = confirm_memory(conn, pid)
    mem = get_memory(conn, mid)
    assert mem["title"] == "Original title"


def test_reject_memory(conn):
    pid = _insert(conn, title="bad draft", obs_type="context", type_="context", confidence=0.4)
    reject_memory(conn, pid)
    status = conn.execute(
        "SELECT status FROM pending_memories WHERE id=?", [pid]
    ).fetchone()[0]
    assert status == "rejected"


def test_list_pending_excludes_actioned(conn):
    pid1 = _insert(conn, title="keep me", obs_type="preference", type_="preference")
    pid2 = _insert(conn, title="reject me", obs_type="context", type_="context")
    confirm_memory(conn, pid1)
    pending = list_pending(conn)
    ids = [p["id"] for p in pending]
    assert pid2 in ids
    assert pid1 not in ids


def test_reject_nonexistent_raises(conn):
    import pytest
    with pytest.raises(ValueError):
        reject_memory(conn, "nonexistent-id-that-does-not-exist")


def test_archive_and_increment(conn):
    pid = _insert(conn, title="mem", obs_type="learning", type_="learning")
    mid = confirm_memory(conn, pid)
    increment_access(conn, mid)
    increment_access(conn, mid)
    mem = get_memory(conn, mid)
    assert mem["access_count"] == 2
    archive_memory(conn, mid)
    assert get_memory(conn, mid)["is_archived"] is True
