"""Tests for the new watcher system (jobs, executor, sync_setup)."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import duckdb
import pytest

from smritix.db.schema import create_schema
from smritix.storage.memories import insert_pending
from smritix.watcher.auto_approve import AutoApproveJob
from smritix.watcher.base import _get_session_cursor, _save_session_cursor
from smritix.watcher.sync_setup import setup_sync_state


def _now():
    return datetime.now(timezone.utc)


@pytest.fixture()
def mem_conn():
    conn = duckdb.connect(":memory:")
    conn.execute("INSTALL vss; LOAD vss")
    create_schema(conn)
    yield conn
    conn.close()


# ── sync_setup ────────────────────────────────────────────────────────────────

def test_setup_sync_state_creates_incremental_row(mem_conn):
    """setup_sync_state creates an incremental row with cursor = now."""
    setup_sync_state(mem_conn, lookback_days=7)
    row = mem_conn.execute(
        "SELECT id, job_type, status, end_time FROM sync_state WHERE id = 'incremental'"
    ).fetchone()
    assert row is not None
    assert row[1] == "incremental"
    assert row[2] == "pending"
    assert row[3] is None  # open-ended


def test_setup_sync_state_creates_historical_row(mem_conn):
    """setup_sync_state creates a historical row with correct range."""
    setup_sync_state(mem_conn, lookback_days=7)
    row = mem_conn.execute(
        "SELECT id, job_type, status, start_time, end_time, global_cursor FROM sync_state WHERE id = 'historical'"
    ).fetchone()
    assert row is not None
    assert row[1] == "historical"
    assert row[2] == "pending"
    start = row[3]
    end = row[4]
    cursor = row[5]
    # start should be ~7 days ago
    age = end - start
    assert timedelta(days=6, hours=23) < age < timedelta(days=7, hours=1)
    # cursor starts at start_time
    assert abs((cursor - start).total_seconds()) < 1


def test_setup_sync_state_idempotent(mem_conn):
    """Second call to setup_sync_state must NOT overwrite existing rows.
    init is for config only — cursor resets happen via `smritix reset --cursor`."""
    setup_sync_state(mem_conn, lookback_days=7)
    setup_sync_state(mem_conn, lookback_days=3)   # second call should be ignored
    count = mem_conn.execute("SELECT COUNT(*) FROM sync_state").fetchone()[0]
    assert count == 2  # still just 2 rows

    # Historical should still reflect the ORIGINAL 7 days (second call ignored)
    row = mem_conn.execute(
        "SELECT start_time, end_time FROM sync_state WHERE id = 'historical'"
    ).fetchone()
    age = row[1] - row[0]
    assert timedelta(days=6, hours=23) < age < timedelta(days=7, hours=1)


def test_setup_sync_state_lookback_zero_uses_epoch(mem_conn):
    """lookback_days=0 means all history — start_time near epoch."""
    setup_sync_state(mem_conn, lookback_days=0)
    row = mem_conn.execute(
        "SELECT start_time FROM sync_state WHERE id = 'historical'"
    ).fetchone()
    assert row[0].year < 2000  # epoch-ish


# ── session cursor operations ─────────────────────────────────────────────────

def test_get_session_cursor_returns_none_for_new_session(mem_conn):
    """Unknown session_id returns (None, 0)."""
    last_time, count = _get_session_cursor(mem_conn, "claude_code:unknown")
    assert last_time is None
    assert count == 0


def test_save_and_get_session_cursor_roundtrip(mem_conn):
    """Saved cursor is returned correctly."""
    ts = _now()
    _save_session_cursor(mem_conn, "claude_code:abc123", "claude_code", ts, 5)
    last_time, count = _get_session_cursor(mem_conn, "claude_code:abc123")
    assert abs((last_time - ts).total_seconds()) < 1
    assert count == 5


def test_save_session_cursor_upsert(mem_conn):
    """Second save updates existing row rather than inserting a duplicate."""
    ts1 = _now()
    ts2 = ts1 + timedelta(minutes=10)
    _save_session_cursor(mem_conn, "claude_code:abc123", "claude_code", ts1, 3)
    _save_session_cursor(mem_conn, "claude_code:abc123", "claude_code", ts2, 8)

    row_count = mem_conn.execute(
        "SELECT COUNT(*) FROM session_cursors WHERE session_id = 'claude_code:abc123'"
    ).fetchone()[0]
    assert row_count == 1  # not duplicated

    _, count = _get_session_cursor(mem_conn, "claude_code:abc123")
    assert count == 8  # updated to latest


# ── AutoApproveJob ────────────────────────────────────────────────────────────

def test_auto_approve_job_approves_old_high_confidence(mem_conn):
    """AutoApproveJob approves pending memories older than threshold."""
    import threading
    import smritix.watcher.jobs as wj

    pid = insert_pending(
        mem_conn, title="Old high confidence memory here", obs_type="preference",
        type_="preference", facts=[], narrative="test", tags=[],
        files_mentioned=[], confidence=0.85, evidence="user said so",
        source_session_id="s1",
    )
    old_time = _now() - timedelta(hours=25)
    mem_conn.execute("UPDATE pending_memories SET created_at=? WHERE id=?", [old_time, pid])

    stop = threading.Event()
    job = AutoApproveJob("auto_approve", mem_conn, [], stop)

    with patch("smritix.config.AUTO_APPROVE_HOURS", 24), \
         patch("smritix.config.AUTO_APPROVE_THRESHOLD", 0.75), \
         patch("smritix.config.EXPIRE_DAYS", 30), \
         patch("smritix.config.ARCHIVE_EXPIRE_DAYS", 0), \
         patch("smritix.embedding.encoder.embed_memory", return_value=[0.0] * 256), \
         patch("smritix.storage.embeddings.insert_hot"), \
         patch("smritix.storage.embeddings.maybe_merge"):
        job._run_once(mem_conn)

    status = mem_conn.execute(
        "SELECT status FROM pending_memories WHERE id=?", [pid]
    ).fetchone()[0]
    assert status == "approved"


def test_auto_approve_job_skips_recent(mem_conn):
    """AutoApproveJob does NOT approve recent pending memories."""
    import threading

    pid = insert_pending(
        mem_conn, title="Recent memory stays pending longer", obs_type="preference",
        type_="preference", facts=[], narrative="test", tags=[],
        files_mentioned=[], confidence=0.85, evidence="user said so",
        source_session_id="s1",
    )

    stop = threading.Event()
    job = AutoApproveJob("auto_approve", mem_conn, [], stop)

    with patch("smritix.config.AUTO_APPROVE_HOURS", 24), \
         patch("smritix.config.AUTO_APPROVE_THRESHOLD", 0.75), \
         patch("smritix.config.EXPIRE_DAYS", 30), \
         patch("smritix.config.ARCHIVE_EXPIRE_DAYS", 0), \
         patch("smritix.embedding.encoder.embed_memory", return_value=[0.0] * 256), \
         patch("smritix.storage.embeddings.insert_hot"), \
         patch("smritix.storage.embeddings.maybe_merge"):
        job._run_once(mem_conn)

    status = mem_conn.execute(
        "SELECT status FROM pending_memories WHERE id=?", [pid]
    ).fetchone()[0]
    assert status == "pending"


def test_auto_approve_job_expires_very_old(mem_conn):
    """AutoApproveJob auto-rejects memories older than EXPIRE_DAYS."""
    import threading

    pid = insert_pending(
        mem_conn, title="Very old memory should be expired now", obs_type="preference",
        type_="preference", facts=[], narrative="test", tags=[],
        files_mentioned=[], confidence=0.60, evidence="user said so",
        source_session_id="s1",
    )
    very_old = _now() - timedelta(days=31)
    mem_conn.execute("UPDATE pending_memories SET created_at=? WHERE id=?", [very_old, pid])

    stop = threading.Event()
    job = AutoApproveJob("auto_approve", mem_conn, [], stop)

    with patch("smritix.config.AUTO_APPROVE_HOURS", 24), \
         patch("smritix.config.AUTO_APPROVE_THRESHOLD", 0.75), \
         patch("smritix.config.EXPIRE_DAYS", 30), \
         patch("smritix.config.ARCHIVE_EXPIRE_DAYS", 0), \
         patch("smritix.storage.embeddings.maybe_merge"):
        job._run_once(mem_conn)

    status = mem_conn.execute(
        "SELECT status FROM pending_memories WHERE id=?", [pid]
    ).fetchone()[0]
    assert status == "rejected"
