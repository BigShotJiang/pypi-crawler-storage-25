from smritix.linker.memory_linker import classify_relationship, run_linking
from smritix.storage.memories import insert_pending, confirm_memory
from smritix.storage.embeddings import insert_hot
from smritix.storage.links import get_links
from smritix.embedding.encoder import embed


def _mem(conn, title, type_="decision"):
    pid = insert_pending(
        conn, title=title, obs_type=type_, type_=type_,
        facts=[], narrative=title, tags=[], files_mentioned=[],
        confidence=0.9, evidence="why", source_session_id="s1",
    )
    mid = confirm_memory(conn, pid)
    insert_hot(conn, mid, embed(title))
    return mid


def test_classify_supports_high_similarity():
    rel = classify_relationship(
        "use exponential backoff",
        "exponential backoff is preferred for retries",
        0.91,
    )
    assert rel == "supports"


def test_classify_related_default():
    rel = classify_relationship("use DuckDB", "prefer columnar storage", 0.70)
    assert rel == "related"


def test_classify_contradicts_negation():
    rel = classify_relationship(
        "always use synchronous calls",
        "never use synchronous calls, prefer async",
        0.78,
    )
    assert rel == "contradicts"


def test_classify_supports_boundary():
    # Exactly 0.85 triggers supports
    rel = classify_relationship("use backoff", "use backoff pattern", 0.85)
    assert rel == "supports"


def test_run_linking_creates_edges(conn):
    m1 = _mem(conn, "use exponential backoff for retries")
    m2 = _mem(conn, "add jitter to retry delays to avoid thundering herd")
    run_linking(conn, [m1, m2], similarity_threshold=0.5)
    links = get_links(conn, m1)
    assert len(links) >= 1


def test_run_linking_skips_duplicates(conn):
    m1 = _mem(conn, "trunk based development preferred")
    m2 = _mem(conn, "short lived branches under two days")
    run_linking(conn, [m1, m2], similarity_threshold=0.5)
    first_count = len(get_links(conn, m1))
    run_linking(conn, [m1], similarity_threshold=0.5)
    assert len(get_links(conn, m1)) == first_count


def test_run_linking_skips_missing_memory(conn):
    # Should not raise even if memory_id doesn't exist
    run_linking(conn, ["nonexistent-id"], similarity_threshold=0.5)


def test_run_linking_below_threshold_creates_no_link(conn):
    m1 = _mem(conn, "python web development")
    m2 = _mem(conn, "quarterly budget planning spreadsheet")
    run_linking(conn, [m1, m2], similarity_threshold=0.99)  # very high threshold
    links = get_links(conn, m1)
    # With threshold=0.99, semantically unrelated content should produce no links
    assert len(links) == 0
