import asyncio
import json

import pytest
from fastmcp import Client

from smritix.mcp.server import mcp, set_connection


def test_all_tools_registered():
    tools = asyncio.run(mcp.list_tools())
    tool_names = {t.name for t in tools}
    assert "get_memories" in tool_names
    assert "list_pending_memories" in tool_names
    assert "confirm_memory_tool" in tool_names
    assert "add_memory" in tool_names
    assert "delete_memory" in tool_names
    # Removed — watcher handles session analysis now
    assert "get_unanalyzed_sessions" not in tool_names
    assert "save_memory_drafts" not in tool_names


def test_ping_removed():
    tools = asyncio.run(mcp.list_tools())
    tool_names = {t.name for t in tools}
    assert "ping" not in tool_names


@pytest.fixture(autouse=True)
def use_test_db(conn):
    """Inject in-memory DuckDB into MCP server so tests never touch the real file."""
    set_connection(conn)
    yield
    set_connection(None)  # reset so next test gets a fresh conn


def _parse(result):
    data = result.data if hasattr(result, "data") else result
    return json.loads(data) if isinstance(data, str) else data


@pytest.mark.asyncio
async def test_list_pending_returns_empty_initially():
    async with Client(mcp) as client:
        data = _parse(await client.call_tool("list_pending_memories", {}))
        assert data["count"] == 0
        assert data["pending"] == []


@pytest.mark.asyncio
async def test_add_memory_and_retrieve():
    async with Client(mcp) as client:
        add_data = _parse(await client.call_tool("add_memory", {
            "title": "Use DuckDB not SQLite for analytics",
            "narrative": "DuckDB was chosen for columnar storage and HNSW indexing support.",
            "obs_type": "decision",
            "type": "decision",
        }))
        assert add_data["status"] == "saved"

        get_data = _parse(await client.call_tool("get_memories", {
            "query": "which database to use for analytics",
            "limit": 5,
        }))
        assert get_data["token_count"] >= 0
        titles = [m["title"] for m in get_data["memories"]]
        assert any("DuckDB" in t for t in titles)


@pytest.mark.asyncio
async def test_delete_memory_archives_it():
    async with Client(mcp) as client:
        # Add a memory first
        add_data = _parse(await client.call_tool("add_memory", {
            "title": "Delete me this is a test memory",
            "narrative": "Temporary memory for delete test.",
            "obs_type": "preference",
            "type": "preference",
        }))
        mid = add_data["memory_id"]

        # Delete it
        del_data = _parse(await client.call_tool("delete_memory", {"memory_id": mid}))
        assert del_data["status"] == "archived"
        assert del_data["memory_id"] == mid

        # Should not appear in search results anymore
        get_data = _parse(await client.call_tool("get_memories", {
            "query": "Delete me this is a test memory",
            "limit": 5,
        }))
        ids = [m.get("id") for m in get_data.get("memories", [])]
        assert mid not in ids


@pytest.mark.asyncio
async def test_delete_memory_not_found():
    async with Client(mcp) as client:
        result = _parse(await client.call_tool("delete_memory", {"memory_id": "nonexistent-id"}))
        assert "error" in result


from unittest.mock import patch, Mock, MagicMock


# save_memory_drafts and get_unanalyzed_sessions tests removed —
# those tools no longer exist. Session analysis is handled by the watcher.
# Their quality-gate logic (session_summary filtering, confidence floor) is
# tested in tests/test_drafter.py and tests/agents/test_ai_providers.py.




# ─── _check_upgrade semver comparison ────────────────────────────────────────

def test_check_upgrade_returns_none_when_on_newer_version():
    """No warning when our version (0.2.0) is newer than PyPI (0.1.3)."""
    import smritix.mcp.server as srv
    original = srv._upgrade_warning
    srv._upgrade_warning = None  # reset cache
    try:
        with patch("smritix.mcp.server.__version__", "0.2.0"), \
             patch("smritix.mcp.server._parse_version", side_effect=lambda v: tuple(int(x) for x in v.split("."))):
            # PyPI returns 0.1.3 — older than our 0.2.0
            with patch("urllib.request.urlopen") as mock_url:
                ctx = MagicMock()
                ctx.read.return_value = b'{"info": {"version": "0.1.3"}}'
                mock_url.return_value.__enter__ = Mock(return_value=ctx)
                mock_url.return_value.__exit__ = Mock(return_value=False)
                result = srv._check_upgrade()
        assert result is None
    finally:
        srv._upgrade_warning = original


def test_check_upgrade_returns_warning_when_pypi_is_newer():
    """Warning shown when PyPI has a strictly higher version than current."""
    import smritix.mcp.server as srv
    original = srv._upgrade_warning
    srv._upgrade_warning = None  # reset cache
    try:
        with patch("smritix.mcp.server.__version__", "0.2.0"), \
             patch("smritix.mcp.server._parse_version", side_effect=lambda v: tuple(int(x) for x in v.split("."))):
            # PyPI returns 0.3.0 — newer than our 0.2.0
            with patch("urllib.request.urlopen") as mock_url:
                ctx = MagicMock()
                ctx.read.return_value = b'{"info": {"version": "0.3.0"}}'
                mock_url.return_value.__enter__ = Mock(return_value=ctx)
                mock_url.return_value.__exit__ = Mock(return_value=False)
                result = srv._check_upgrade()
        assert result is not None
        assert "0.3.0" in result
    finally:
        srv._upgrade_warning = original
