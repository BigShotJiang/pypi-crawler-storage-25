from smritix.storage.embeddings import (
    insert_hot, search, merge_hot_to_cold, hot_count
)
from smritix.embedding.encoder import embed


def test_insert_and_search(conn):
    vec = embed("use exponential backoff in retry logic")
    insert_hot(conn, "mem-1", vec)
    results = search(conn, embed("retry with backoff"), limit=5)
    assert len(results) == 1
    assert results[0]["memory_id"] == "mem-1"
    assert results[0]["similarity"] > 0.7


def test_search_empty_returns_empty(conn):
    results = search(conn, embed("anything"), limit=5)
    assert results == []


def test_merge_moves_hot_to_cold(conn):
    for i in range(3):
        insert_hot(conn, f"mem-{i}", embed(f"memory {i} about python"))
    assert hot_count(conn) == 3
    merge_hot_to_cold(conn)
    assert hot_count(conn) == 0
    cold = conn.execute("SELECT COUNT(*) FROM cold_embeddings").fetchone()[0]
    assert cold == 3


def test_search_finds_across_hot_and_cold(conn):
    insert_hot(conn, "cold-mem", embed("trunk based development"))
    merge_hot_to_cold(conn)
    insert_hot(conn, "hot-mem", embed("feature flags for releases"))
    results = search(conn, embed("branching and development workflow"), limit=5)
    ids = [r["memory_id"] for r in results]
    assert "cold-mem" in ids
    assert "hot-mem" in ids
