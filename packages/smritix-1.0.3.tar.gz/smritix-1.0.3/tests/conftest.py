import pytest
import duckdb

from smritix.db.connection import get_connection
from smritix.db.schema import create_schema


@pytest.fixture
def conn():
    c = get_connection(":memory:")
    create_schema(c)
    yield c
    c.close()


# ── Local integration test options ──────────────────────────────────────────
def pytest_addoption(parser):
    parser.addoption(
        "--provider", default="sub_claude",
        help="Provider to test in integration tests (e.g. sub_claude, api_anthropic)",
    )
    parser.addoption(
        "--model", default=None,
        help="Model override for the provider (uses provider default if omitted)",
    )
    parser.addoption(
        "--session", default=None,
        help="Session ID to analyze (auto-picks a session if omitted)",
    )
    parser.addoption(
        "--pick", default="largest",
        choices=["largest", "smallest"],
        help="When --session is omitted: pick 'largest' (most messages) or 'smallest' (fewest). Default: largest",
    )
