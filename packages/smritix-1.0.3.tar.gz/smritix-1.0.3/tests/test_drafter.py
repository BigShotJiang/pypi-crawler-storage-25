import json
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from smritix.agents.base import SessionMessage
from smritix.drafter.session_drafter import (
    apply_confidence_tiers,
    parse_drafter_response,
    strip_tool_results_from_text,
)


def _msg(role: str, content: str) -> SessionMessage:
    return SessionMessage(role=role, content=content, timestamp=datetime.now(timezone.utc))


def test_strip_returns_user_and_assistant_only():
    msgs = [
        _msg("user", "use duckdb"),
        _msg("assistant", "switching to duckdb"),
        _msg("tool", "file output"),
    ]
    text = strip_tool_results_from_text(msgs)
    assert "User: use duckdb" in text
    assert "AI: switching to duckdb" in text
    assert "tool" not in text.lower() or "file output" not in text


def test_strip_empty_content_excluded():
    msgs = [_msg("user", "  "), _msg("assistant", "hello")]
    text = strip_tool_results_from_text(msgs)
    assert text == "AI: hello"


def test_parse_valid_response():
    raw = json.dumps({
        "memories": [
            {
                "title": "Chose DuckDB over SQLite for analytics",
                "obs_type": "change",
                "type": "decision",
                "facts": ["DuckDB selected"],
                "narrative": "DuckDB was chosen for its columnar storage and HNSW support.",
                "tags": ["architecture"],
                "files_mentioned": [],
                "confidence": 0.95,
                "evidence": "user said: use DuckDB not SQLite",
            },
            {
                "title": "Prefer trunk-based development workflow",
                "obs_type": "preference",
                "type": "preference",
                "facts": ["trunk-based dev preferred"],
                "narrative": "The team prefers trunk-based development for faster iteration.",
                "tags": ["workflow"],
                "files_mentioned": [],
                "confidence": 0.80,
                "evidence": "user said: we use trunk-based dev",
            },
        ],
        "session_summary": {
            "title": "Set up DuckDB and discussed dev workflow",
            "investigated": "Database options",
            "learned": "DuckDB suits analytics needs",
            "completed": ["Switched to DuckDB"],
            "next_steps": "None",
        },
    })
    memories, summary = parse_drafter_response(raw)
    assert len(memories) == 2
    assert memories[0]["title"] == "Chose DuckDB over SQLite for analytics"
    assert memories[1]["confidence"] == 0.80
    assert summary is not None
    assert summary["title"] == "Set up DuckDB and discussed dev workflow"


def test_parse_tolerates_surrounding_text():
    inner = json.dumps({
        "memories": [
            {
                "title": "Async IO preferred for network calls",
                "obs_type": "discovery",
                "type": "decision",
                "facts": ["async IO chosen"],
                "narrative": "For better throughput in network-heavy services.",
                "tags": ["pattern"],
                "files_mentioned": [],
                "confidence": 0.85,
                "evidence": "user said: use async IO",
            }
        ],
        "session_summary": None,
    })
    raw = f"Here are memories:\n{inner}\nDone."
    memories, summary = parse_drafter_response(raw)
    assert len(memories) == 1
    assert memories[0]["title"] == "Async IO preferred for network calls"


def test_parse_invalid_returns_empty():
    assert parse_drafter_response("no json here") == ([], None)
    assert parse_drafter_response("") == ([], None)
    assert parse_drafter_response("[not valid json}") == ([], None)


def test_parse_skips_low_quality():
    raw = json.dumps({
        "memories": [
            {
                "title": "x",  # too short
                "obs_type": "decision",
                "type": "decision",
                "narrative": "some narrative",
                "confidence": 0.9,
                "evidence": "user said x",
            }
        ],
        "session_summary": None,
    })
    memories, _ = parse_drafter_response(raw)
    assert memories == []


def test_confidence_tiers_split_correctly():
    memories = [
        {"title": "auto confirm this memory item", "confidence": 0.92,
         "type": "decision", "obs_type": "decision", "narrative": "n",
         "evidence": "e", "facts": [], "tags": [], "files_mentioned": []},
        {"title": "pending memory item here", "confidence": 0.75,
         "type": "preference", "obs_type": "preference", "narrative": "n",
         "evidence": "e", "facts": [], "tags": [], "files_mentioned": []},
        {"title": "discard this low confidence", "confidence": 0.45,
         "type": "context", "obs_type": "discovery", "narrative": "n",
         "evidence": "e", "facts": [], "tags": [], "files_mentioned": []},
    ]
    auto, pend, disc = apply_confidence_tiers(memories)
    assert len(auto) == 1 and auto[0]["title"].startswith("auto")
    assert len(pend) == 1 and pend[0]["title"].startswith("pending")
    assert len(disc) == 1 and disc[0]["title"].startswith("discard")


def test_confidence_tiers_boundary_auto_confirm():
    mem = {"title": "boundary test memory item", "confidence": 0.88,
           "type": "decision", "obs_type": "decision", "narrative": "n",
           "evidence": "e"}
    auto, pend, disc = apply_confidence_tiers([mem])
    assert len(auto) == 0
    assert len(pend) == 1


def test_confidence_tiers_boundary_discard():
    # New floor is 0.75 — exactly at threshold goes to pending, below goes to discard
    at_floor = {"title": "boundary discard test item", "confidence": 0.75,
                "type": "context", "obs_type": "discovery", "narrative": "n",
                "evidence": "e"}
    below_floor = {"title": "below floor discard item here", "confidence": 0.74,
                   "type": "context", "obs_type": "discovery", "narrative": "n",
                   "evidence": "e"}
    _, pend, disc = apply_confidence_tiers([at_floor])
    assert len(pend) == 1
    _, pend2, disc2 = apply_confidence_tiers([below_floor])
    assert len(disc2) == 1


# --- Provider-based draft_from_session tests ---
# Note: call_provider() and draft_with_fallback() are removed from session_drafter.
# Provider tests live in tests/agents/test_ai_providers.py.

def test_draft_from_session_uses_provider_chain(conn):
    """draft_from_session calls provider.analyze() and stores qualifying memories."""
    from smritix.providers import AIProvider
    from smritix.agents.base import Session
    from smritix.drafter.session_drafter import draft_from_session

    good_response = json.dumps({
        "memories": [{
            "title": "Always use integration tests not mocks",
            "obs_type": "preference",
            "type": "preference",
            "facts": ["use real DB"],
            "narrative": "Mocks caused a prod incident.",
            "tags": ["testing"],
            "files_mentioned": [],
            "confidence": 0.92,
            "evidence": "we got burned by mocked tests",
        }],
        "session_summary": {
            "title": "Discussed testing approach",
            "investigated": "Test patterns",
            "learned": "Mocks are dangerous",
            "completed": [],
            "next_steps": "None",
        },
    })

    class FakeProvider(AIProvider):
        @classmethod
        def name(cls): return "fake"
        def analyze(self, text): return good_response

    session = Session(
        id="test-session", tool="claude_code", file_path=None,
        project_path=None, created_at=datetime.now(timezone.utc),
        last_modified=datetime.now(timezone.utc),
    )
    msgs = [
        SessionMessage(role="user", content="we got burned by mocked tests", timestamp=datetime.now(timezone.utc)),
        SessionMessage(role="assistant", content="I understand", timestamp=datetime.now(timezone.utc)),
    ]

    with patch("smritix.embedding.encoder.embed_memory", return_value=[0.0] * 256), \
         patch("smritix.storage.embeddings.search", return_value=[]), \
         patch("smritix.storage.embeddings.insert_hot"), \
         patch("smritix.storage.embeddings.maybe_merge"):
        draft_from_session(session, msgs, "test-session", conn, providers=[FakeProvider()])

    count = conn.execute("SELECT COUNT(*) FROM pending_memories").fetchone()[0]
    assert count >= 1


def test_draft_from_session_skips_when_no_providers(conn):
    """draft_from_session does nothing when provider list is empty."""
    from smritix.agents.base import Session
    from smritix.drafter.session_drafter import draft_from_session

    session = Session(
        id="test-empty", tool="claude_code", file_path=None,
        project_path=None, created_at=datetime.now(timezone.utc),
        last_modified=datetime.now(timezone.utc),
    )
    draft_from_session(session, [], "test-empty", conn, providers=[])
    count = conn.execute("SELECT COUNT(*) FROM pending_memories").fetchone()[0]
    assert count == 0


# ─── _validate_memory quality gate for session_summary ───────────────────────

def test_validate_memory_rejects_session_summary_obs_type():
    """session_summary obs_type must never pass validation — it's a session log."""
    from smritix.drafter.session_drafter import _validate_memory
    mem = {
        "title": "Investigated dispatcher bug and fixed it today",
        "obs_type": "session_summary",
        "type": "context",
        "narrative": "Fixed head-of-line blocking in the dispatcher.",
        "confidence": 1.0,
        "evidence": "user said: fix the dispatcher",
        "facts": [],
        "tags": [],
        "files_mentioned": [],
    }
    assert _validate_memory(mem) is False


def test_validate_memory_respects_auto_discard_threshold():
    """Confidence below AUTO_DISCARD_THRESHOLD (0.75) must be rejected."""
    from smritix.drafter.session_drafter import _validate_memory
    mem = {
        "title": "Maybe the user prefers this approach",
        "obs_type": "preference",
        "type": "preference",
        "narrative": "Uncertain preference.",
        "confidence": 0.74,
        "evidence": "user said something vague",
        "facts": [],
        "tags": [],
        "files_mentioned": [],
    }
    assert _validate_memory(mem) is False


def test_validate_memory_accepts_at_threshold():
    """Confidence at exactly AUTO_DISCARD_THRESHOLD (0.75) should pass."""
    from smritix.drafter.session_drafter import _validate_memory
    mem = {
        "title": "Always use integration tests not mocks",
        "obs_type": "preference",
        "type": "preference",
        "narrative": "Mocks caused a prod incident.",
        "confidence": 0.75,
        "evidence": "user said: we got burned by mocked tests",
        "facts": [],
        "tags": [],
        "files_mentioned": [],
    }
    assert _validate_memory(mem) is True
