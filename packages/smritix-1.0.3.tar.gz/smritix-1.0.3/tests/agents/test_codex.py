import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

from smritix.agents.codex import CodexReader, _EPOCH


def _make_session_file(tmp_path: Path, session_id: str = "abc123", lines: list | None = None) -> Path:
    # Codex stores in date subdirs: sessions/YYYY/MM/DD/
    session_dir = tmp_path / ".codex" / "sessions" / "2026" / "04" / "14"
    session_dir.mkdir(parents=True)
    f = session_dir / f"{session_id}.jsonl"

    default_lines = [
        # Session header (no "type" field, has "git")
        {"id": session_id, "timestamp": "2026-04-14T10:00:00Z",
         "git": {"branch": "main"}, "instructions": None},
        # User message
        {"type": "message", "role": "user",
         "content": [{"type": "input_text", "text": "use duckdb not sqlite"}]},
        # Assistant message
        {"type": "message", "role": "assistant",
         "content": [{"type": "output_text", "text": "switching to duckdb"}]},
        # Tool call — should be skipped
        {"type": "local_shell_call", "id": "lsh_1", "action": {"command": ["ls"]}},
        # Tool output — should be skipped
        {"type": "function_call_output", "call_id": "c1", "output": "file.txt"},
        # Reasoning — should be skipped
        {"type": "reasoning", "id": "rs_1", "summary": []},
        # State snapshot — should be skipped
        {"record_type": "state"},
    ]
    f.write_text("\n".join(json.dumps(l) for l in (lines or default_lines)))
    return f


def test_is_available_false_when_dir_missing(tmp_path):
    reader = CodexReader(base_dir=tmp_path / "nonexistent")
    assert reader.is_available() is False


def test_is_available_true_when_dir_exists(tmp_path):
    d = tmp_path / ".codex" / "sessions"
    d.mkdir(parents=True)
    reader = CodexReader(base_dir=tmp_path / ".codex")
    assert reader.is_available() is True


def test_list_sessions_finds_nested_jsonl(tmp_path):
    _make_session_file(tmp_path, "abc123")
    reader = CodexReader(base_dir=tmp_path / ".codex")
    sessions = reader.list_sessions()
    assert len(sessions) == 1
    assert sessions[0].id == "abc123"
    assert sessions[0].tool == "codex"


def test_list_sessions_empty_when_no_files(tmp_path):
    d = tmp_path / ".codex" / "sessions"
    d.mkdir(parents=True)
    reader = CodexReader(base_dir=tmp_path / ".codex")
    assert reader.list_sessions() == []


def test_get_messages_parses_message_type(tmp_path):
    _make_session_file(tmp_path, "abc123")
    reader = CodexReader(base_dir=tmp_path / ".codex")
    msgs = reader.get_messages("abc123", since=None)
    # Only user and assistant messages — tool/reasoning/state skipped
    assert len(msgs) == 2
    assert msgs[0].role == "user"
    assert msgs[0].content == "use duckdb not sqlite"
    assert msgs[1].role == "assistant"
    assert msgs[1].content == "switching to duckdb"


def test_get_messages_skips_tool_calls(tmp_path):
    _make_session_file(tmp_path, "abc123")
    reader = CodexReader(base_dir=tmp_path / ".codex")
    msgs = reader.get_messages("abc123", since=None)
    roles = [m.role for m in msgs]
    assert "tool" not in roles
    assert all(r in ("user", "assistant") for r in roles)


def test_get_messages_since_filter(tmp_path):
    lines = [
        {"id": "s1", "timestamp": "2026-04-14T10:00:00Z", "git": {}, "instructions": None},
        {"type": "message", "role": "user",
         "content": [{"type": "input_text", "text": "old message"}]},
        {"type": "message", "role": "user", "timestamp": "2026-04-14T10:30:00Z",
         "content": [{"type": "input_text", "text": "new message"}]},
    ]
    _make_session_file(tmp_path, "s1", lines=lines)
    reader = CodexReader(base_dir=tmp_path / ".codex")
    cutoff = datetime(2026, 4, 14, 10, 15, 0, tzinfo=timezone.utc)
    msgs = reader.get_messages("s1", since=cutoff)
    assert len(msgs) == 1
    assert msgs[0].content == "new message"


def test_get_messages_missing_session_returns_empty(tmp_path):
    _make_session_file(tmp_path, "abc123")
    reader = CodexReader(base_dir=tmp_path / ".codex")
    assert reader.get_messages("nonexistent", since=None) == []


def test_get_messages_skips_malformed_lines(tmp_path):
    session_dir = tmp_path / ".codex" / "sessions" / "2026" / "04" / "14"
    session_dir.mkdir(parents=True)
    f = session_dir / "bad.jsonl"
    f.write_text(
        '{"type":"message","role":"user","content":[{"type":"input_text","text":"ok"}]}\n'
        'not json at all\n'
        '{"type":"message","role":"assistant","content":[{"type":"output_text","text":"fine"}]}\n'
    )
    reader = CodexReader(base_dir=tmp_path / ".codex")
    msgs = reader.get_messages("bad", since=None)
    assert len(msgs) == 2


def test_strip_tool_results_no_op(tmp_path):
    _make_session_file(tmp_path, "abc123")
    reader = CodexReader(base_dir=tmp_path / ".codex")
    msgs = reader.get_messages("abc123", since=None)
    assert reader.strip_tool_results(msgs) == msgs


def test_list_sessions_handles_oserror(tmp_path):
    d = tmp_path / ".codex" / "sessions"
    d.mkdir(parents=True)
    reader = CodexReader(base_dir=tmp_path / ".codex")
    with patch.object(type(reader._sessions_dir), "rglob", side_effect=OSError("no access")):
        result = reader.list_sessions()
    assert result == []


def test_parse_dt_handles_none():
    assert CodexReader._parse_dt(None) == _EPOCH


def test_parse_dt_handles_z_suffix():
    result = CodexReader._parse_dt("2026-04-14T10:00:00Z")
    assert result.year == 2026
    assert result.tzinfo is not None


def test_parse_dt_handles_invalid():
    assert CodexReader._parse_dt("not-a-date") == _EPOCH


def test_setup_writes_agents_instructions(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    reader = CodexReader(base_dir=tmp_path / ".codex")

    with patch("smritix.agents.codex.subprocess.run", side_effect=FileNotFoundError):
        result = reader.setup(project_dir)

    assert (project_dir / "AGENTS.md").exists()
    assert result.agent == "Codex"
    assert any("add MCP manually" in message for message in result.messages)


def test_setup_reports_cli_registration(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    reader = CodexReader(base_dir=tmp_path / ".codex")

    completed = type("Completed", (), {"returncode": 0, "stderr": ""})()
    with patch("smritix.agents.codex.subprocess.run", return_value=completed):
        result = reader.setup(project_dir)

    assert any("MCP registered via CLI" in message for message in result.messages)
