import json
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from smritix.agents.claude_code import ClaudeCodeReader


def _make_session(tmp_path: Path, session_id: str = "abc123", lines: list | None = None) -> Path:
    project_dir = tmp_path / "projects" / "test-project"
    project_dir.mkdir(parents=True)
    f = project_dir / f"{session_id}.jsonl"

    default_lines = [
        {
            "type": "user",
            "message": {"role": "user", "content": "use duckdb not sqlite"},
            "timestamp": "2026-04-14T10:00:00Z",
            "uuid": "u1",
        },
        {
            "type": "assistant",
            "message": {"role": "assistant", "content": [
                {"type": "text", "text": "switching to duckdb"},
                {"type": "tool_use", "id": "t1", "name": "Read", "input": {}},
            ]},
            "timestamp": "2026-04-14T10:01:00Z",
            "uuid": "a1",
        },
        {
            "type": "progress",
            "data": {},
            "timestamp": "2026-04-14T10:02:00Z",
        },
        {
            "type": "user",
            "message": {"role": "user", "content": "[Request interrupted by user]"},
            "timestamp": "2026-04-14T10:03:00Z",
            "uuid": "u2",
        },
    ]
    f.write_text("\n".join(json.dumps(l) for l in (lines or default_lines)))
    return project_dir


def test_is_available_false_when_dir_missing(tmp_path):
    reader = ClaudeCodeReader(base_dir=tmp_path / "nonexistent")
    assert reader.is_available() is False


def test_is_available_true_when_dir_exists(tmp_path):
    d = tmp_path / "projects"
    d.mkdir()
    reader = ClaudeCodeReader(base_dir=d)
    assert reader.is_available() is True


def test_list_sessions_finds_jsonl(tmp_path):
    _make_session(tmp_path, "abc123")
    reader = ClaudeCodeReader(base_dir=tmp_path / "projects")
    sessions = reader.list_sessions()
    assert len(sessions) == 1
    assert sessions[0].id == "abc123"
    assert sessions[0].tool == "claude_code"


def test_get_messages_skips_non_conversation_types(tmp_path):
    _make_session(tmp_path, "abc123")
    reader = ClaudeCodeReader(base_dir=tmp_path / "projects")
    msgs = reader.get_messages("abc123", since=None)
    # progress skipped, [Request interrupted] skipped → 2 messages
    assert len(msgs) == 2
    assert msgs[0].role == "user"
    assert msgs[0].content == "use duckdb not sqlite"
    assert msgs[1].role == "assistant"
    assert msgs[1].content == "switching to duckdb"


def test_get_messages_strips_tool_use_blocks(tmp_path):
    _make_session(tmp_path, "abc123")
    reader = ClaudeCodeReader(base_dir=tmp_path / "projects")
    msgs = reader.get_messages("abc123", since=None)
    for m in msgs:
        assert "tool_use" not in m.content


def test_get_messages_since_filter(tmp_path):
    _make_session(tmp_path, "abc123")
    reader = ClaudeCodeReader(base_dir=tmp_path / "projects")
    cutoff = datetime(2026, 4, 14, 10, 0, 30, tzinfo=timezone.utc)
    msgs = reader.get_messages("abc123", since=cutoff)
    assert len(msgs) == 1
    assert msgs[0].role == "assistant"


def test_get_messages_missing_session_returns_empty(tmp_path):
    _make_session(tmp_path, "abc123")
    reader = ClaudeCodeReader(base_dir=tmp_path / "projects")
    assert reader.get_messages("nonexistent", since=None) == []


def test_get_messages_skips_interrupted_content(tmp_path):
    _make_session(tmp_path, "abc123")
    reader = ClaudeCodeReader(base_dir=tmp_path / "projects")
    msgs = reader.get_messages("abc123", since=None)
    assert all("[Request interrupted" not in m.content for m in msgs)


def test_get_session_summary(tmp_path):
    project_dir = _make_session(tmp_path, "abc123")
    index = {
        "version": 1,
        "entries": [{"sessionId": "abc123", "summary": "Switched to DuckDB", "messageCount": 2}],
    }
    (project_dir / "sessions-index.json").write_text(json.dumps(index))
    reader = ClaudeCodeReader(base_dir=tmp_path / "projects")
    assert reader.get_session_summary("abc123") == "Switched to DuckDB"


def test_get_session_summary_missing_returns_none(tmp_path):
    _make_session(tmp_path, "abc123")
    reader = ClaudeCodeReader(base_dir=tmp_path / "projects")
    assert reader.get_session_summary("abc123") is None


def test_strip_tool_results_no_op(tmp_path):
    _make_session(tmp_path, "abc123")
    reader = ClaudeCodeReader(base_dir=tmp_path / "projects")
    msgs = reader.get_messages("abc123", since=None)
    assert reader.strip_tool_results(msgs) == msgs


def test_parse_dt_handles_z_suffix():
    dt = ClaudeCodeReader._parse_dt("2026-04-14T10:00:00Z")
    assert dt.year == 2026
    assert dt.tzinfo is not None


def test_parse_dt_handles_none():
    result = ClaudeCodeReader._parse_dt(None)
    assert result.tzinfo is not None
    assert result.year < 2000  # epoch sentinel, not now


def test_setup_writes_instructions_and_hooks(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    reader = ClaudeCodeReader(base_dir=tmp_path / ".claude" / "projects")

    with patch("smritix.agents.claude_code.subprocess.run", side_effect=FileNotFoundError):
        result = reader.setup(project_dir)

    assert (project_dir / "CLAUDE.md").exists()
    assert (project_dir / "AGENTS.md").exists()
    assert (tmp_path / ".claude" / "CLAUDE.md").exists()

    settings = json.loads((tmp_path / ".claude" / "settings.json").read_text())
    session_cmds = [
        h["command"]
        for group in settings["hooks"]["SessionStart"]
        for h in group["hooks"]
    ]
    prompt_cmds = [
        h["command"]
        for group in settings["hooks"]["UserPromptSubmit"]
        for h in group["hooks"]
    ]
    assert any("--session-start" in c for c in session_cmds)
    assert any("--prompt" in c for c in prompt_cmds)
    assert not any(c == "smritix hook --reset" for c in session_cmds)
    assert not any(c == "smritix hook" for c in prompt_cmds)
    assert result.agent == "Claude Code"
    assert any("session hooks registered" in message for message in result.messages)


def test_setup_updates_desktop_config_when_cli_unavailable(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    claude_json = tmp_path / ".claude.json"
    claude_json.write_text(json.dumps({"projects": {"/tmp/demo": {}}}))
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    reader = ClaudeCodeReader(base_dir=tmp_path / ".claude" / "projects")

    with patch("smritix.agents.claude_code.subprocess.run", side_effect=FileNotFoundError):
        result = reader.setup(project_dir)

    updated = json.loads(claude_json.read_text())
    assert "smritix" in updated["projects"]["/tmp/demo"]["mcpServers"]
    assert any("desktop MCP config updated" in message for message in result.messages)
