from __future__ import annotations

import subprocess
from unittest.mock import MagicMock, patch

import pytest

from smritix.providers import (
    AnthropicProvider,
    ClaudeCliProvider,
    CodexCliProvider,
    GeminiProvider,
    OllamaProvider,
    OpenAIProvider,
    ProviderValidationError,
    get_provider,
    get_provider_chain,
)


# ── Registry ──────────────────────────────────────────────────────────────────

def test_get_provider_returns_correct_class():
    assert isinstance(get_provider("sub_claude"), ClaudeCliProvider)
    assert isinstance(get_provider("sub_codex"), CodexCliProvider)
    assert isinstance(get_provider("api_anthropic"), AnthropicProvider)
    assert isinstance(get_provider("api_ollama"), OllamaProvider)
    assert isinstance(get_provider("api_gemini"), GeminiProvider)
    assert isinstance(get_provider("api_openai"), OpenAIProvider)


def test_get_provider_raises_for_unknown():
    with pytest.raises(ValueError, match="Unknown provider"):
        get_provider("unknown")


def test_get_provider_chain_empty_when_no_config():
    with patch("smritix.providers.registry.SMRITIX_PROVIDERS", []), \
         patch("smritix.providers.registry.ANTHROPIC_API_KEY", ""):
        chain = get_provider_chain()
    assert chain == []


def test_get_provider_chain_uses_smritix_providers():
    with patch("smritix.providers.registry.SMRITIX_PROVIDERS", ["sub_claude", "api_ollama"]):
        chain = get_provider_chain()
    assert len(chain) == 2
    assert isinstance(chain[0], ClaudeCliProvider)
    assert isinstance(chain[1], OllamaProvider)


def test_get_provider_chain_falls_back_to_anthropic_key():
    with patch("smritix.providers.registry.SMRITIX_PROVIDERS", []), \
         patch("smritix.providers.registry.ANTHROPIC_API_KEY", "sk-ant-test"):
        chain = get_provider_chain()
    assert len(chain) == 1
    assert isinstance(chain[0], AnthropicProvider)


def test_get_provider_chain_skips_unknown_provider_names():
    with patch("smritix.providers.registry.SMRITIX_PROVIDERS", ["sub_claude", "bogus_name"]):
        chain = get_provider_chain()
    assert len(chain) == 1
    assert isinstance(chain[0], ClaudeCliProvider)


# ── ClaudeCliProvider ─────────────────────────────────────────────────────────

def test_claude_cli_provider_name():
    assert ClaudeCliProvider().name() == "sub_claude"


def test_claude_cli_analyze_calls_subprocess():
    # CLI now uses --print and returns a JSON envelope; stdout must be valid JSON envelope.
    envelope = '{"result": "{\\"memories\\": [], \\"session_summary\\": {\\"title\\": \\"t\\"}}", "type": "result"}'
    mock_result = MagicMock()
    mock_result.returncode = 0
    mock_result.stdout = envelope
    with patch("subprocess.run", return_value=mock_result) as mock_run:
        result = ClaudeCliProvider().analyze("test conversation")
    assert mock_run.called
    cmd = mock_run.call_args[0][0]
    assert cmd[0] == "claude"
    assert "--print" in cmd
    assert "memories" in result


def test_claude_cli_analyze_returns_empty_on_nonzero_exit():
    # Failed chunks are logged as warnings; analyze() returns an empty merged response
    # rather than raising, so callers can handle partial results gracefully.
    mock_result = MagicMock()
    mock_result.returncode = 1
    mock_result.stderr = "not logged in"
    with patch("subprocess.run", return_value=mock_result):
        result = ClaudeCliProvider().analyze("text")
    import json
    parsed = json.loads(result)
    assert parsed["memories"] == []


def test_claude_cli_validate_passes_when_cli_exists():
    """validate() only checks binary existence — fast, no live call."""
    with patch("shutil.which", return_value="/usr/local/bin/claude"):
        ClaudeCliProvider().validate()  # should not raise


def test_claude_cli_validate_raises_when_cli_missing():
    with patch("shutil.which", return_value=None):
        with pytest.raises(ProviderValidationError, match="claude"):
            ClaudeCliProvider().validate()


# ── CodexCliProvider ──────────────────────────────────────────────────────────

def test_codex_cli_provider_name():
    assert CodexCliProvider().name() == "sub_codex"


def test_codex_cli_validate_raises_when_cli_missing():
    with patch("shutil.which", return_value=None):
        with pytest.raises(ProviderValidationError, match="codex"):
            CodexCliProvider().validate()


# ── AnthropicProvider ─────────────────────────────────────────────────────────

def test_anthropic_provider_name():
    assert AnthropicProvider().name() == "api_anthropic"


def test_anthropic_analyze_calls_sdk():
    mock_client = MagicMock()
    mock_response = MagicMock()
    mock_response.content = [MagicMock(text='{"memories": []}')]
    mock_client.messages.create.return_value = mock_response
    with patch("smritix.providers.api_anthropic.anthropic") as mock_anthropic:
        mock_anthropic.Anthropic.return_value = mock_client
        result = AnthropicProvider().analyze("text")
    assert "memories" in result


def test_anthropic_validate_raises_when_no_key():
    # Key is now read at call time via _get_api_key() from os.environ
    with patch("smritix.providers.api_anthropic._get_api_key", return_value=""):
        with pytest.raises(ProviderValidationError):
            AnthropicProvider().validate()


def test_anthropic_validate_passes_when_key_set():
    with patch("smritix.providers.api_anthropic._get_api_key", return_value="sk-ant-test"):
        AnthropicProvider().validate()  # should not raise


# ── OllamaProvider ────────────────────────────────────────────────────────────

def test_ollama_provider_name():
    assert OllamaProvider().name() == "api_ollama"


def test_ollama_analyze_posts_to_api():
    mock_resp = MagicMock()
    mock_resp.raise_for_status.return_value = None
    mock_resp.json.return_value = {"message": {"content": '{"memories": []}'}}
    with patch("smritix.providers.api_ollama.requests") as mock_req:
        mock_req.post.return_value = mock_resp
        result = OllamaProvider().analyze("text")
    assert "memories" in result


def test_ollama_validate_raises_when_not_reachable():
    with patch("smritix.providers.api_ollama.requests") as mock_req:
        mock_req.get.side_effect = Exception("connection refused")
        with pytest.raises(ProviderValidationError, match="Ollama not reachable"):
            OllamaProvider().validate()


# ── GeminiProvider ────────────────────────────────────────────────────────────

def test_gemini_provider_name():
    assert GeminiProvider().name() == "api_gemini"


def test_gemini_validate_raises_when_no_key():
    with patch.dict("os.environ", {}, clear=True):
        import os
        os.environ.pop("GEMINI_API_KEY", None)
        with pytest.raises(ProviderValidationError, match="GEMINI_API_KEY"):
            GeminiProvider().validate()


# ── OpenAIProvider ────────────────────────────────────────────────────────────

def test_openai_provider_name():
    assert OpenAIProvider().name() == "api_openai"


def test_openai_validate_raises_when_no_key():
    with patch.dict("os.environ", {}, clear=True):
        import os
        os.environ.pop("OPENAI_API_KEY", None)
        with pytest.raises(ProviderValidationError, match="OPENAI_API_KEY"):
            OpenAIProvider().validate()
