from pathlib import Path

from datetime import datetime, timezone
from smritix.agents.base import AIAgentReader, AgentSetupResult, Session, SessionMessage, RawSession


class ConcreteReader(AIAgentReader):
    def is_available(self) -> bool:
        return True

    def setup(self, project_dir: Path) -> AgentSetupResult:
        return AgentSetupResult(agent="Test", session_dir=project_dir)

    def list_sessions(self) -> list[Session]:
        return [Session(
            id="s1", tool="test",
            file_path="/tmp/s1.jsonl",
            project_path=None,
            created_at=datetime.now(timezone.utc),
            last_modified=datetime.now(timezone.utc),
        )]

    def get_messages(self, session_id: str, since: datetime | None) -> list[SessionMessage]:
        return [
            SessionMessage(role="user", content="hello", timestamp=datetime.now(timezone.utc)),
            SessionMessage(role="assistant", content="world", timestamp=datetime.now(timezone.utc)),
            SessionMessage(role="tool", content="file contents", timestamp=datetime.now(timezone.utc), is_tool_result=True),
        ]


def test_strip_tool_results_removes_tool_messages():
    reader = ConcreteReader()
    msgs = reader.get_messages("s1", None)
    stripped = reader.strip_tool_results(msgs)
    assert len(stripped) == 2
    assert all(m.role in ("user", "assistant") for m in stripped)


def test_get_new_content_returns_raw_sessions():
    reader = ConcreteReader()
    result = reader.get_new_content(checkpoint=None)
    assert len(result) == 1
    assert isinstance(result[0], RawSession)
    assert len(result[0].messages) == 2  # tool result stripped


def test_cannot_instantiate_abstract_reader():
    import pytest
    with pytest.raises(TypeError):
        AIAgentReader()


def test_registry_returns_list():
    from smritix.agents import get_available_readers
    readers = get_available_readers()
    assert isinstance(readers, list)


def test_setup_returns_result():
    reader = ConcreteReader()
    result = reader.setup(Path("/tmp/project"))
    assert result.agent == "Test"
    assert result.session_dir == Path("/tmp/project")
