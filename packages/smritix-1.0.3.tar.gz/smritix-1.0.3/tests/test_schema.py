from smritix.db.connection import get_connection
from smritix.db.schema import create_schema


def test_schema_creates_all_tables():
    conn = get_connection(":memory:")
    create_schema(conn)
    tables = conn.execute(
        "SELECT table_name FROM information_schema.tables WHERE table_schema='main'"
    ).fetchall()
    names = {row[0] for row in tables}
    assert "sessions" in names
    assert "pending_memories" in names
    assert "memories" in names
    assert "memory_links" in names
    assert "hot_embeddings" in names
    assert "cold_embeddings" in names
    conn.close()


def test_schema_is_idempotent():
    conn = get_connection(":memory:")
    create_schema(conn)
    create_schema(conn)  # calling twice must not raise
    conn.close()
