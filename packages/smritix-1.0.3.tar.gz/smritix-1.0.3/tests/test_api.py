import pytest
from fastapi.testclient import TestClient

from smritix.api.app import create_app


@pytest.fixture
def client(conn):
    app = create_app(conn)
    return TestClient(app)


def test_get_pending_empty(client):
    resp = client.get("/api/pending")
    assert resp.status_code == 200
    assert resp.json()["pending"] == []


def test_create_and_confirm_pending(client):
    resp = client.post("/api/pending", json={
        "title": "Use DuckDB not SQLite",
        "obs_type": "decision",
        "type": "decision",
        "confidence": 0.92,
        "evidence": "explicit correction",
        "source_session_id": "s1",
    })
    assert resp.status_code == 200
    pid = resp.json()["id"]

    resp2 = client.post(f"/api/pending/{pid}/confirm", data={"final_content": ""})
    assert resp2.status_code == 200
    assert resp2.json()["memory_id"] is not None


def test_reject_pending(client):
    resp = client.post("/api/pending", json={
        "title": "bad draft",
        "obs_type": "context",
        "type": "context",
        "confidence": 0.4,
        "evidence": "low",
        "source_session_id": "s1",
    })
    pid = resp.json()["id"]
    resp2 = client.post(f"/api/pending/{pid}/reject")
    assert resp2.status_code == 200
    pending = client.get("/api/pending").json()["pending"]
    assert all(p["id"] != pid for p in pending)


def test_reject_nonexistent_returns_404(client):
    resp = client.post("/api/pending/nonexistent-id/reject")
    assert resp.status_code == 404


def test_confirm_nonexistent_returns_404(client):
    resp = client.post("/api/pending/nonexistent-id/confirm", data={"final_content": ""})
    assert resp.status_code == 404


def test_search_memories_empty(client):
    resp = client.get("/api/memories/search?q=DuckDB")
    assert resp.status_code == 200
    data = resp.json()
    assert "memories" in data
    assert data["query"] == "DuckDB"


def test_list_memories(client):
    resp = client.get("/api/memories")
    assert resp.status_code == 200
    assert "memories" in resp.json()


def test_update_nonexistent_returns_404(client):
    resp = client.put("/api/memories/nonexistent-id", json={"title": "new"})
    assert resp.status_code == 404


# ─── POST /api/pending/auto-approve ──────────────────────────────────────────

def test_auto_approve_endpoint_empty_queue(client):
    resp = client.post("/api/pending/auto-approve?older_than_hours=0&min_confidence=0.0")
    assert resp.status_code == 200
    data = resp.json()
    assert data["approved"] == 0


def test_auto_approve_approves_old_high_confidence(client):
    from datetime import datetime, timedelta, timezone

    # Create a pending memory
    resp = client.post("/api/pending", json={
        "title": "Old high confidence memory to approve",
        "obs_type": "preference",
        "type": "preference",
        "confidence": 0.85,
        "evidence": "user said so explicitly",
        "source_session_id": "sess-old",
    })
    pid = resp.json()["id"]

    # Backdate it via direct DB so it's "old"
    from smritix.api.app import create_app
    # Use older_than_hours=0 so everything qualifies regardless of age
    resp2 = client.post("/api/pending/auto-approve?older_than_hours=0&min_confidence=0.80")
    assert resp2.status_code == 200
    data = resp2.json()
    assert data["approved"] >= 1

    # Verify it's no longer pending
    pending = client.get("/api/pending").json()["pending"]
    assert all(p["id"] != pid for p in pending)


def test_auto_approve_skips_low_confidence(client):
    # Create a low-confidence pending memory
    client.post("/api/pending", json={
        "title": "Low confidence should not be approved",
        "obs_type": "preference",
        "type": "preference",
        "confidence": 0.50,
        "evidence": "weak signal",
        "source_session_id": "sess-low",
    })

    resp = client.post("/api/pending/auto-approve?older_than_hours=0&min_confidence=0.80")
    data = resp.json()
    # Low-confidence memory should be in skipped, not approved
    assert data["approved"] == 0


# ─── HTTP MCP server spec tests ──────────────────────────────────────────────

def test_health_endpoint(client):
    """GET /health returns 200 with status, version, memories, pending counts."""
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"
    assert "version" in data
    assert "memories" in data
    assert "pending" in data
    assert isinstance(data["memories"], int)
    assert isinstance(data["pending"], int)


def test_mcp_not_mounted_without_mcp_server():
    """Without mcp_server arg, /mcp returns 404 — not mounted."""
    import duckdb
    from smritix.api.app import create_app
    from smritix.db.schema import create_schema
    conn = duckdb.connect(":memory:")
    conn.execute("INSTALL vss; LOAD vss")
    create_schema(conn)
    app = create_app(conn, mcp_server=None)
    from fastapi.testclient import TestClient
    c = TestClient(app)
    resp = c.get("/mcp")
    assert resp.status_code == 404


def test_init_registers_http_not_stdio(tmp_path, monkeypatch):
    """smritix init writes type:http MCP registration, not type:command."""
    monkeypatch.setenv("HOME", str(tmp_path))
    from smritix.agents.claude_code import ClaudeCodeReader
    from unittest.mock import patch
    (tmp_path / ".claude").mkdir(parents=True)
    with patch("smritix.agents.claude_code.subprocess.run", side_effect=FileNotFoundError):
        ClaudeCodeReader._register_mcp_cli()

    import json
    claude_json = tmp_path / ".claude.json"
    if claude_json.exists():
        data = json.loads(claude_json.read_text())
        for proj in data.get("projects", {}).values():
            for server in proj.get("mcpServers", {}).values():
                assert server.get("type") == "http"
                assert "command" not in server
