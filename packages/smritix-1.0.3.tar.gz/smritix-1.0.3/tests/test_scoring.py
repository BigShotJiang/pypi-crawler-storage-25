from datetime import datetime, timedelta, timezone
from smritix.scoring import score_and_rank, enforce_token_budget


def _mem(memory_id, similarity, confirmed, days_old, access_count,
         title="test memory", narrative="test narrative"):
    return {
        "id": memory_id,
        "title": title,
        "narrative": narrative,
        "similarity": similarity,
        "confirmed_by_user": confirmed,
        "created_at": (datetime.now(timezone.utc) - timedelta(days=days_old)).isoformat(),
        "access_count": access_count,
        "type": "decision",
        "obs_type": "decision",
        "is_archived": False,
    }


def test_confirmed_scores_higher_than_unconfirmed():
    confirmed = _mem("m1", 0.8, True, 1, 0)
    unconfirmed = _mem("m2", 0.8, False, 1, 0)
    ranked = score_and_rank([confirmed, unconfirmed])
    assert ranked[0]["id"] == "m1"


def test_recent_scores_higher_than_old():
    recent = _mem("m1", 0.75, True, 1, 0)
    old = _mem("m2", 0.75, True, 365, 0)
    ranked = score_and_rank([recent, old])
    assert ranked[0]["id"] == "m1"


def test_frequently_accessed_scores_higher():
    frequent = _mem("m1", 0.75, True, 10, 50)
    rare = _mem("m2", 0.75, True, 10, 0)
    ranked = score_and_rank([frequent, rare])
    assert ranked[0]["id"] == "m1"


def test_high_similarity_scores_higher():
    high_sim = _mem("m1", 0.95, True, 10, 0)
    low_sim = _mem("m2", 0.50, True, 10, 0)
    ranked = score_and_rank([high_sim, low_sim])
    assert ranked[0]["id"] == "m1"


def test_final_score_added_to_dict():
    mem = _mem("m1", 0.8, True, 1, 0)
    score_and_rank([mem])
    assert "final_score" in mem
    assert 0.0 <= mem["final_score"] <= 1.0


def test_token_budget_enforced():
    # Each memory has 200-word narrative, budget 300 -> only 1 fits
    mems = [
        _mem("m1", 0.9, True, 0, 0, title="t1", narrative=" ".join(["word"] * 200)),
        _mem("m2", 0.8, True, 0, 0, title="t2", narrative=" ".join(["word"] * 200)),
        _mem("m3", 0.7, True, 0, 0, title="t3", narrative=" ".join(["word"] * 200)),
    ]
    selected, total = enforce_token_budget(mems, token_limit=300)
    assert len(selected) == 1
    assert total == 201  # "t1" + 200 words


def test_token_budget_includes_all_when_under_limit():
    mems = [
        _mem("m1", 0.9, True, 0, 0, title="short", narrative="memory"),
        _mem("m2", 0.8, True, 0, 0, title="another", narrative="short one"),
    ]
    selected, total = enforce_token_budget(mems, token_limit=500)
    assert len(selected) == 2
    assert total == 5  # "short memory" = 2, "another short one" = 3


def test_empty_input_returns_empty():
    assert score_and_rank([]) == []
    selected, total = enforce_token_budget([], token_limit=500)
    assert selected == []
    assert total == 0


def test_score_and_rank_preserves_all_fields():
    mem = _mem("m1", 0.8, True, 1, 5)
    mem["extra_field"] = "keep me"
    ranked = score_and_rank([mem])
    assert ranked[0]["extra_field"] == "keep me"
    assert ranked[0]["id"] == "m1"
