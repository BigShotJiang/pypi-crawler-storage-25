from smritix.embedding.encoder import embed
from smritix.config import EMBEDDING_DIM


def test_embed_returns_correct_dimension():
    vec = embed("use exponential backoff in retry logic")
    assert isinstance(vec, list)
    assert len(vec) == EMBEDDING_DIM
    assert all(isinstance(v, float) for v in vec)


def test_embed_different_texts_differ():
    v1 = embed("use exponential backoff")
    v2 = embed("prefer trunk-based development")
    assert v1 != v2


def test_embed_same_text_is_deterministic():
    v1 = embed("consistent output")
    v2 = embed("consistent output")
    assert v1 == v2
