from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import duckdb
import pytest
from typer.testing import CliRunner

from smritix.agents.base import AgentSetupResult
from smritix.agents.instructions import MEMORY_INSTRUCTIONS, write_instruction_file
from smritix.cli import app
from smritix.db.schema import create_schema

runner = CliRunner()


@pytest.fixture()
def mem_conn():
    """In-memory DuckDB connection with schema applied."""
    conn = duckdb.connect(":memory:")
    row = conn.execute(
        "SELECT installed FROM duckdb_extensions() WHERE extension_name = 'vss'"
    ).fetchone()
    if row is None or not row[0]:
        conn.execute("INSTALL vss")
    conn.execute("LOAD vss")
    create_schema(conn)
    yield conn
    conn.close()


def test_status_command_runs(mem_conn):
    """status command exits 0 and prints expected labels."""
    with patch("smritix.db.connection.get_connection", return_value=mem_conn), \
         patch("smritix.db.schema.create_schema"):
        result = runner.invoke(app, ["status"])
    assert result.exit_code == 0, result.output
    assert "Memories" in result.output
    assert "Pending" in result.output


def test_write_instruction_file_appends(tmp_path):
    instruction_path = tmp_path / "CLAUDE.md"
    instruction_path.write_text("# Existing content\n")
    changed = write_instruction_file(instruction_path)
    content = instruction_path.read_text()
    assert changed is True
    assert "Existing content" in content
    assert MEMORY_INSTRUCTIONS.strip() in content


def test_write_instruction_file_not_appended_twice(tmp_path):
    instruction_path = tmp_path / "CLAUDE.md"
    write_instruction_file(instruction_path)
    first_content = instruction_path.read_text()
    changed = write_instruction_file(instruction_path)
    second_content = instruction_path.read_text()
    assert changed is False
    assert first_content == second_content  # no duplicate appended


def test_init_calls_agent_setup(mem_conn, tmp_path):
    result_payload = [
        AgentSetupResult(agent="Claude Code", messages=["Claude Code: configured"], session_dir=tmp_path / ".claude"),
        AgentSetupResult(agent="Codex", messages=["Codex: configured"], session_dir=tmp_path / ".codex"),
    ]
    import subprocess as _sp
    mock_run = MagicMock()
    mock_run.return_value.returncode = 0
    mock_run.return_value.stdout = "claude 1.0.0"
    with patch("smritix.db.connection.get_connection", return_value=mem_conn), \
         patch("smritix.db.schema.create_schema"), \
         patch("smritix.embedding.encoder.embed"), \
         patch("smritix.agents.setup_agents", return_value=result_payload), \
         patch("smritix.cli._setup_subscription_provider",
               side_effect=lambda ef, pc, *a: pc.append("sub_claude")):
        # input: lookback default (enter), provider type = a (subscription), cli = 1 (claude)
        result = runner.invoke(app, ["init", "--lookback-days", "7"], input="1\n1\n")
    assert result.exit_code == 0, result.output
    assert "Configuring AI agents" in result.output
    assert "Claude Code: configured" in result.output
    assert "Codex: configured" in result.output


def test_help_shows_all_commands():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "init" in result.output
    assert "serve" in result.output    # unified portal + MCP HTTP command
    assert "review" in result.output
    assert "status" in result.output
    assert "mcp" not in result.output  # deprecated, hidden from help


# --- Hook --session-start tests ---

def _make_db(tmp_path):
    """Helper: create a test DuckDB file and return its path."""
    db_file = tmp_path / "test.duckdb"
    conn = duckdb.connect(str(db_file))
    conn.execute("INSTALL vss; LOAD vss")
    create_schema(conn)
    return db_file, conn


def test_hook_session_start_no_pending_silent(tmp_path):
    """No output when no pending memories exist."""
    db_file, conn = _make_db(tmp_path)
    conn.close()

    with patch("smritix.config.DB_PATH", db_file), \
         patch("urllib.request.urlopen", side_effect=OSError("no portal")):
        result = runner.invoke(app, ["hook", "--session-start"])

    assert result.exit_code == 0
    assert result.output.strip() == ""


def test_hook_session_start_shows_pending(tmp_path):
    """Outputs formatted pending list when pending memories exist."""
    from smritix.storage.memories import insert_pending

    db_file, conn = _make_db(tmp_path)
    insert_pending(
        conn, title="Prefer integration tests", obs_type="preference",
        type_="preference", facts=[], narrative="test", tags=[],
        files_mentioned=[], confidence=0.80, evidence="user said so",
        source_session_id="sess1",
    )
    conn.close()

    with patch("smritix.config.DB_PATH", db_file), \
         patch("urllib.request.urlopen", side_effect=OSError("no portal")):
        result = runner.invoke(app, ["hook", "--session-start"])

    assert result.exit_code == 0
    assert "SMRITIX SESSION START" in result.output
    assert "Prefer integration tests" in result.output
    assert "Pending memories" in result.output


# --- Hook --prompt tests ---

def test_hook_prompt_no_input_silent():
    """No stdin, no output."""
    result = runner.invoke(app, ["hook", "--prompt"], input="")
    assert result.exit_code == 0
    assert result.output.strip() == ""


def test_hook_prompt_remember_keyword():
    """'remember' keyword in prompt triggers add_memory reminder."""
    payload = json.dumps({"prompt": "remember to always use integration tests"})
    with patch("smritix.cli._fetch_memories_for_hook", return_value=[]):
        result = runner.invoke(app, ["hook", "--prompt"], input=payload)
    assert result.exit_code == 0
    assert "add_memory()" in result.output


def test_hook_prompt_injects_memories():
    """When memories are found, formats them as SMRITIX MEMORIES block."""
    payload = json.dumps({"prompt": "should I use mocks for database tests?"})
    fake_memories = [
        {"title": "Use integration tests not mocks", "obs_type": "decision",
         "narrative": "Prior incident masked broken migration"},
    ]
    with patch("smritix.cli._fetch_memories_for_hook", return_value=fake_memories):
        result = runner.invoke(app, ["hook", "--prompt"], input=payload)
    assert result.exit_code == 0
    assert "SMRITIX MEMORIES" in result.output
    assert "Use integration tests not mocks" in result.output


def test_hook_prompt_no_memories_no_keyword_silent():
    """No output when no memories and no keyword."""
    payload = json.dumps({"prompt": "fix the login bug"})
    with patch("smritix.cli._fetch_memories_for_hook", return_value=[]):
        result = runner.invoke(app, ["hook", "--prompt"], input=payload)
    assert result.exit_code == 0
    assert result.output.strip() == ""


# ─── _parse_version ──────────────────────────────────────────────────────────

def test_parse_version_basic():
    from smritix.cli import _parse_version
    assert _parse_version("0.2.0") == (0, 2, 0)
    assert _parse_version("1.10.3") == (1, 10, 3)
    assert _parse_version("0.1.0") == (0, 1, 0)


def test_parse_version_comparison():
    from smritix.cli import _parse_version
    assert _parse_version("0.2.0") > _parse_version("0.1.9")
    assert _parse_version("1.0.0") > _parse_version("0.9.9")
    assert _parse_version("0.2.0") > _parse_version("0.1.3")
    assert not (_parse_version("0.2.0") > _parse_version("0.2.0"))


def test_parse_version_bad_input():
    from smritix.cli import _parse_version
    # bad input returns empty tuple or (0,) — both mean "unknown, treat as lowest"
    assert _parse_version("not-a-version") in ((), (0,))
    assert _parse_version("") in ((), (0,))


# ─── smritix --version ───────────────────────────────────────────────────────

def test_version_flag_shows_version():
    from smritix import __version__
    with patch("smritix.cli._get_latest_version", return_value=None):
        result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "smritix" in result.output
    assert __version__ in result.output  # shows whatever is actually installed


def test_version_shows_upgrade_hint_when_newer_available():
    with patch("smritix.cli._get_latest_version", return_value="0.9.0"):
        result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "0.9.0" in result.output
    assert "upgrade" in result.output.lower()


def test_version_no_upgrade_hint_when_current_is_newer():
    # Pin __version__ so the test is deterministic regardless of CI install state.
    # Without this, a dev build (e.g. "0.1.dev1+g...") correctly shows an upgrade
    # hint when PyPI has "0.1.0" — which would fail the assertion.
    with patch("smritix.cli.__version__", "0.2.0"), \
         patch("smritix.cli._get_latest_version", return_value="0.1.0"):
        result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "upgrade" not in result.output.lower()


def test_version_no_upgrade_hint_when_pypi_unreachable():
    with patch("smritix.cli.__version__", "0.2.0"), \
         patch("smritix.cli._get_latest_version", return_value=None):
        result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "upgrade" not in result.output.lower()


# ─── smritix upgrade ─────────────────────────────────────────────────────────

def test_upgrade_already_on_latest():
    with patch("smritix.cli._get_latest_version", return_value="0.2.0"), \
         patch("smritix.cli.__version__", "0.2.0"):
        result = runner.invoke(app, ["upgrade"])
    assert result.exit_code == 0
    assert "latest" in result.output.lower()


def test_upgrade_pypi_unreachable():
    with patch("smritix.cli._get_latest_version", return_value=None):
        result = runner.invoke(app, ["upgrade"])
    assert result.exit_code == 1
    assert "PyPI" in result.output or "manually" in result.output


def test_upgrade_runs_pip_when_newer_available():
    import subprocess
    with patch("smritix.cli._get_latest_version", return_value="9.9.9"), \
         patch("smritix.cli.__version__", "0.2.0"), \
         patch("subprocess.run", return_value=subprocess.CompletedProcess([], 0)) as mock_run:
        result = runner.invoke(app, ["upgrade"])
    assert mock_run.called
    cmd = mock_run.call_args[0][0]
    assert "pip" in cmd
    assert "smritix" in cmd


# ─── smritix cleanup ─────────────────────────────────────────────────────────

def _make_writable_db(tmp_path):
    """Create a writable DuckDB file with schema for cleanup tests."""
    db_file = tmp_path / "smritix.duckdb"
    conn = duckdb.connect(str(db_file))
    conn.execute("INSTALL vss; LOAD vss")
    from smritix.db.schema import create_schema
    create_schema(conn)
    conn.close()
    return db_file


def test_cleanup_no_flags_exits_cleanly():
    result = runner.invoke(app, ["cleanup", "--all"])
    assert result.exit_code == 0
    assert "Nothing to do" in result.output


def test_cleanup_session_summaries_purges_pending(tmp_path):
    from smritix.storage.memories import insert_pending
    db_file = _make_writable_db(tmp_path)
    conn = duckdb.connect(str(db_file))
    conn.execute("INSTALL vss; LOAD vss")
    # Insert one session_summary and one normal pending
    insert_pending(conn, title="Session summary title here", obs_type="session_summary",
                   type_="context", facts=[], narrative="n", tags=[], files_mentioned=[],
                   confidence=1.0, evidence="", source_session_id="s1")
    insert_pending(conn, title="Real preference keep it around", obs_type="preference",
                   type_="preference", facts=[], narrative="n", tags=[], files_mentioned=[],
                   confidence=0.85, evidence="user said so", source_session_id="s2")
    conn.close()

    with patch("smritix.config.DB_PATH", db_file):
        result = runner.invoke(app, ["cleanup", "--session-summaries", "--all"])

    assert result.exit_code == 0
    assert "session_summary" in result.output.lower() or "Deleted" in result.output

    conn = duckdb.connect(str(db_file))
    remaining = conn.execute("SELECT obs_type FROM pending_memories WHERE status='pending'").fetchall()
    conn.close()
    obs_types = [r[0] for r in remaining]
    assert "session_summary" not in obs_types
    assert "preference" in obs_types


def test_cleanup_pending_purges_all_pending(tmp_path):
    from smritix.storage.memories import insert_pending
    db_file = _make_writable_db(tmp_path)
    conn = duckdb.connect(str(db_file))
    conn.execute("INSTALL vss; LOAD vss")
    insert_pending(conn, title="Some pending memory to purge", obs_type="preference",
                   type_="preference", facts=[], narrative="n", tags=[], files_mentioned=[],
                   confidence=0.85, evidence="e", source_session_id="s1")
    conn.close()

    with patch("smritix.config.DB_PATH", db_file):
        result = runner.invoke(app, ["cleanup", "--pending", "--all"])

    assert result.exit_code == 0
    conn = duckdb.connect(str(db_file))
    count = conn.execute("SELECT COUNT(*) FROM pending_memories WHERE status='pending'").fetchone()[0]
    conn.close()
    assert count == 0


# ─── DB lock conflict handling ───────────────────────────────────────────────

def test_serve_shows_friendly_error_when_db_locked_via_mcp_alias():
    """smritix mcp (deprecated alias) also shows DB lock error."""
    from smritix.providers import AnthropicProvider
    with patch("urllib.request.urlopen", side_effect=OSError("not running")), \
         patch("smritix.providers.get_provider_chain", return_value=[AnthropicProvider()]), \
         patch.object(AnthropicProvider, "validate"), \
         patch(
             "smritix.db.connection.get_connection",
             side_effect=RuntimeError(
                 "\nAnother Smritix process is already running.\n"
                 "  • Stop the other process first, then retry.\n"
             ),
         ):
        result = runner.invoke(app, ["mcp"])
    # mcp is a deprecated alias for serve — same error path
    assert result.exit_code == 1 or "Stop the other process" in result.output


def test_serve_shows_friendly_error_when_db_locked():
    """smritix serve exits with code 1 when DB is locked by another process."""
    from smritix.providers import AnthropicProvider
    # Mock health check so serve doesn't short-circuit with "already running"
    # Mock provider chain so validation passes
    # Mock get_connection to simulate DB lock
    with patch("urllib.request.urlopen", side_effect=OSError("not running")), \
         patch("smritix.providers.get_provider_chain", return_value=[AnthropicProvider()]), \
         patch.object(AnthropicProvider, "validate"), \
         patch(
             "smritix.db.connection.get_connection",
             side_effect=RuntimeError("Another Smritix process is already running"),
         ):
        result = runner.invoke(app, ["serve"])
    assert result.exit_code == 1
    assert "Another Smritix" in result.output


def test_db_lock_error_message_mentions_portal_and_stop():
    """The lock error message must tell users where the portal is and how to fix it."""
    from smritix.providers import AnthropicProvider
    with patch("urllib.request.urlopen", side_effect=OSError("not running")), \
         patch("smritix.providers.get_provider_chain", return_value=[AnthropicProvider()]), \
         patch.object(AnthropicProvider, "validate"), \
         patch(
             "smritix.db.connection.get_connection",
             side_effect=RuntimeError(
                 "\nAnother Smritix process is already running and holds the database lock.\n"
                 "  • If smritix serve is running, the portal is already at http://localhost:8666\n"
                 "  • Stop the other process first, then retry.\n"
             ),
         ):
        result = runner.invoke(app, ["serve"])
    assert "localhost:8666" in result.output or "Stop the other process" in result.output
