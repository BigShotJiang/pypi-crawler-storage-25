from smritix.storage.links import create_link, get_links, get_graph
from smritix.storage.memories import insert_pending, confirm_memory


def _mem(conn, title, type_="decision"):
    pid = insert_pending(
        conn, title=title, obs_type=type_, type_=type_,
        facts=[], narrative="", tags=[], files_mentioned=[],
        confidence=0.9, evidence="why", source_session_id="s1",
    )
    return confirm_memory(conn, pid)


def test_create_and_get_link(conn):
    m1 = _mem(conn, "use exponential backoff")
    m2 = _mem(conn, "add jitter to retry delays")
    create_link(conn, m1, m2, "related", 0.82)
    links = get_links(conn, m1)
    assert len(links) == 1
    assert links[0]["target_id"] == m2
    assert links[0]["link_type"] == "related"


def test_get_links_bidirectional(conn):
    m1 = _mem(conn, "memory A")
    m2 = _mem(conn, "memory B")
    create_link(conn, m1, m2, "supports", 0.9)
    links = get_links(conn, m2)
    assert len(links) == 1
    assert links[0]["source_id"] == m1


def test_get_graph_returns_nodes_and_edges(conn):
    m1 = _mem(conn, "memory X")
    m2 = _mem(conn, "memory Y")
    create_link(conn, m1, m2, "contradicts", 0.75)
    graph = get_graph(conn)
    node_ids = [n["id"] for n in graph["nodes"]]
    assert m1 in node_ids and m2 in node_ids
    assert len(graph["edges"]) == 1
    edge = graph["edges"][0]
    assert edge["link_type"] == "contradicts"
    assert edge["source"] == m1
    assert edge["target"] == m2


def test_get_graph_excludes_archived(conn):
    from smritix.storage.memories import archive_memory
    live = _mem(conn, "live memory")
    archived = _mem(conn, "archived memory")
    archive_memory(conn, archived)
    graph = get_graph(conn)
    node_ids = [n["id"] for n in graph["nodes"]]
    assert live in node_ids       # live memory is present
    assert archived not in node_ids  # archived memory is excluded
