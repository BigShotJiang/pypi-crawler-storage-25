---
name: Bug report
about: Something is broken
title: 'bug: '
labels: bug
assignees: ''
---

## What happened

<!-- Describe what went wrong -->

## Expected behaviour

<!-- What should have happened -->

## Steps to reproduce

```
smritix <command>
```

1.
2.
3.

## Environment

- OS:
- Python version: `python --version`
- Smritix version: `smritix --version` (if available) or `pip show smritix`
- AI tool (Claude Code / Codex / Gemini):

## Logs

<!-- Run with --debug and paste the output -->

```
smritix serve --debug
```

```
<paste logs here>
```
