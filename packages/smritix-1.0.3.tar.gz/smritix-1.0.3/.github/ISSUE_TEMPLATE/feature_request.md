---
name: Feature request
about: Suggest an improvement or new capability
title: 'feat: '
labels: enhancement
assignees: ''
---

## Problem

<!-- What problem does this solve? What are you trying to do that you can't? -->

## Proposed solution

<!-- Describe what you'd like to happen -->

## Alternatives considered

<!-- Any other approaches you thought about? -->

## Additional context

<!-- Screenshots, links, or anything else relevant -->
