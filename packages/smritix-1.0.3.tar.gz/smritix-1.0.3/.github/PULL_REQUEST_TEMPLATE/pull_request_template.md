# Summary

<!-- One paragraph: what does this PR do and why? -->

## Changes

-
-

## Type

- [ ] Bug fix
- [ ] New feature
- [ ] Refactor / cleanup
- [ ] Documentation
- [ ] Tests only

## Testing

```bash
hatch run test
```

- [ ] All tests pass
- [ ] New tests added for new behaviour
- [ ] Tested manually with `smritix serve` / `smritix mcp`

## Screenshots (if UI changes)

<!-- Before / after -->

## Checklist

- [ ] `hatch run lint` passes
- [ ] No Co-authored-by lines in commits
- [ ] Breaking changes documented in PR description
