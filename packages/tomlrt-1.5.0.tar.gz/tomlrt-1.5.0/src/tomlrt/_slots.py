"""Physical slot layer.

A document is an ordered intrusive doubly-linked list of physical
slots. Three slot kinds:

- ``KVSlot`` — one ``key = value`` line (possibly dotted).
- ``StructuralHeaderSlot`` — one ``[a.b]`` or ``[[a.b]]`` line.

`SlotRef` is the per-container occurrence of a slot.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field, fields
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from tomlrt._container import Container
    from tomlrt._trivia import EolTrivia, Trivia
    from tomlrt._values import KeyPart, Value

import sys

if sys.version_info >= (3, 12):
    from typing import override
else:  # pragma: no cover -- backport for Python < 3.12
    from typing_extensions import override

from tomlrt._trivia import retarget_eol_newline, retarget_trivia_newlines
from tomlrt._values import render_dotted, retarget_value_newlines

# ---------------------------------------------------------------------------
# AoT entry token (physical ownership marker)
# ---------------------------------------------------------------------------


@dataclass(slots=True, eq=False)
class AoTEntry:
    """Identifies one entry of an array-of-tables.

    Carried by every physical slot that belongs to that entry
    (``owner_aot_entry``). The ``entry_slots`` list is populated by
    the slot-builder so render can iterate without scanning.
    """

    path: tuple[str, ...]
    ordinal: int
    entry_slots: list[Slot] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Slot base + kinds
# ---------------------------------------------------------------------------


@dataclass(slots=True, eq=False)
class Slot:
    """Base for physical slots.

    Subclassed by `KVSlot` and `StructuralHeaderSlot`.
    """

    leading: Trivia
    _prev: Slot | None = field(default=None, repr=False, compare=False)
    _next: Slot | None = field(default=None, repr=False, compare=False)
    owner_aot_entry: AoTEntry | None = None
    """The AoT entry that physically contains this slot, if any.

    Set on every slot regardless of kind so the field is uniformly
    typed at the base; both subclasses preserve `None` defaults.
    """

    _refs: list[SlotRef] = field(default_factory=list, repr=False, compare=False)
    """Back-pointers from this slot to every `SlotRef` that references it.

    Bounded length (≤ path depth + 1). Used by AoT removal to scrub
    refs in O(depth) per slot instead of O(siblings) per container.
    Maintained by `SlotRef.__post_init__` (registers) and
    `unfile_ref` (unregisters).
    """

    def __deepcopy__(self, memo: dict[int, object]) -> Slot:
        """Deep-copy without following ``_refs``/``_prev``/``_next``.

        Cloned slots start with a fresh empty ``_refs`` (callers
        construct new ``SlotRef``s pointing at the clone) and
        unlinked from any doc-stream chain (callers splice them in).
        Following ``_prev``/``_next`` would otherwise drag the entire
        source document into the deepcopy.
        """
        new = type(self).__new__(type(self))
        memo[id(self)] = new
        for f in fields(self):
            match f.name:
                case "_prev" | "_next":
                    value: object = None
                case "_refs":
                    value = []
                case _:
                    value = copy.deepcopy(getattr(self, f.name), memo)
            setattr(new, f.name, value)
        return new

    def render(self) -> str:  # pragma: no cover - overridden
        raise NotImplementedError


@dataclass(slots=True, eq=False)
class KVSlot(Slot):
    """A single ``key = value`` line."""

    host_path: tuple[str, ...] = field(kw_only=True)
    """Full path of the host table — the table whose body this KV
    physically belongs to. For top-level KVs ``()``; for KVs under
    ``[a.b]`` ``("a", "b")``.
    """

    key_parts: list[KeyPart] = field(kw_only=True)
    """The dotted-key parts as written. ``len >= 1``."""

    key_seps: list[str] = field(default_factory=list)
    """Whitespace + ``.`` between parts. Length ``len(key_parts) - 1``."""

    pre_eq: str = ""
    post_eq: str = ""
    value: Value = field(kw_only=True)
    eol: EolTrivia = field(kw_only=True)

    key: tuple[str, ...] = field(kw_only=True)
    """Decoded dotted-key path.

    Set by every construction site (parser, mutation, synthesis).
    The parser passes the tuple it already built for the validator;
    mutation paths pass the path they were given. Read by
    ``_build._apply_kv`` (and any future logic that wants the decoded
    path without re-walking ``key_parts``).
    """

    def render_key(self) -> str:
        return render_dotted(self.key_parts, self.key_seps)

    @override
    def render(self) -> str:
        return (
            f"{self.leading.render()}{self.render_key()}"
            f"{self.pre_eq}={self.post_eq}"
            f"{self.value.render()}{self.eol.render()}"
        )


@dataclass(slots=True, eq=False)
class StructuralHeaderSlot(Slot):
    """One ``[a.b]`` or ``[[a.b]]`` header line.

    ``entry`` is the discriminator: an aot-entry header carries a
    non-``None`` :class:`AoTEntry`; a plain table header carries
    ``None``. The :attr:`kind` property is derived from ``entry``
    so the two cannot drift apart.
    """

    path: tuple[str, ...] = field(kw_only=True)
    """Full decoded path of the section / AoT entry header."""

    key_parts: list[KeyPart] = field(kw_only=True)
    key_seps: list[str] = field(default_factory=list)
    inner_pre: str = ""
    inner_post: str = ""
    eol: EolTrivia = field(kw_only=True)

    entry: AoTEntry | None = None
    """The AoT entry this header opens; ``None`` for a plain table."""

    synthetic: bool = False
    """True iff this header was introduced by mutation."""

    @property
    def kind(self) -> Literal["table", "aot-entry"]:
        """``"aot-entry"`` iff ``entry is not None``, else ``"table"``."""
        return "aot-entry" if self.entry is not None else "table"

    def render_key(self) -> str:
        return render_dotted(self.key_parts, self.key_seps)

    @override
    def render(self) -> str:
        if self.entry is not None:
            open_br, close_br = "[[", "]]"
        else:
            open_br, close_br = "[", "]"
        return (
            f"{self.leading.render()}{open_br}{self.inner_pre}"
            f"{self.render_key()}{self.inner_post}{close_br}{self.eol.render()}"
        )


# Aliases for readability; not separate types.
HeaderSlot = StructuralHeaderSlot
AoTHeaderSlot = StructuralHeaderSlot


# ---------------------------------------------------------------------------
# SlotRef (per-container occurrence)
# ---------------------------------------------------------------------------


class SlotRef:
    """A per-container occurrence of a slot.

    A `SlotRef` records that `slot` contributes to `container`'s
    logical view. The key under which it is filed in
    `container._index` is derived from the geometry of
    (slot, container) and exposed via `local_key`.
    """

    __slots__ = ("container", "slot")

    def __init__(self, slot: Slot, container: Container) -> None:
        self.slot = slot
        self.container = container
        # Register on the slot's back-pointer list so AoT removal
        # can scrub all containers holding refs to a doomed slot
        # without scanning the slot's ancestors.
        slot._refs.append(self)  # noqa: SLF001

    @property
    def local_key(self) -> str | None:
        """Key under which this ref is filed in ``container._index``.

        ``None`` for the container's own header ref (which lives in
        ``_refs`` + ``_header_ref``, not in ``_index``); otherwise a
        single path component, derived from the slot's logical path
        and the container's depth.
        """
        slot = self.slot
        c_path = self.container._path  # noqa: SLF001
        if isinstance(slot, KVSlot):
            return slot.key[len(c_path) - len(slot.host_path)]
        assert isinstance(slot, StructuralHeaderSlot)
        if slot.path == c_path:
            return None
        return slot.path[len(c_path)]


def retarget_slot_newlines(slot: Slot, target: str) -> None:
    """Rewrite every ``NewlineNode.text`` reachable from ``slot`` to ``target``.

    Used by graft paths so cross-document spliced slots adopt the
    destination document's line ending. Walks the slot's leading
    trivia, its EOL (for ``KVSlot`` / ``StructuralHeaderSlot``), and
    recurses into any nested ``ArrayValue`` / ``InlineTableValue``
    on a ``KVSlot``.
    """
    retarget_trivia_newlines(slot.leading, target)
    if isinstance(slot, KVSlot):
        retarget_eol_newline(slot.eol, target)
        retarget_value_newlines(slot.value, target)
    elif isinstance(slot, StructuralHeaderSlot):
        retarget_eol_newline(slot.eol, target)


__all__ = [
    "AoTEntry",
    "AoTHeaderSlot",
    "HeaderSlot",
    "KVSlot",
    "Slot",
    "SlotRef",
    "StructuralHeaderSlot",
    "retarget_slot_newlines",
]
