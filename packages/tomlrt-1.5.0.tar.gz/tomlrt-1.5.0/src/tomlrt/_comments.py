"""Comment side-channel views over slot trivia.

Two primary views per `Container`:

- `Container.comments` — `MutableMapping[str, str]` over the *EOL*
  comment of the direct-KV slot for each key.  Reading returns the
  decoded comment text (the leading ``#`` and one optional space
  are stripped); writing accepts the same shape and re-encodes.
- `Container.leading_comments` — `MutableMapping[str, tuple[str, ...]]`
  over the *leading* comment block on the direct-KV slot for each
  key.  Empty tuple means "no comments above this key".

Implementation notes:

- A slot is exposed under its leaf key on whichever container is its
  immediate parent. For a plain ``key = value``, that's the explicit
  section it sits in; for a dotted KV like ``b.c = 1`` under ``[a]``,
  that's ``a["b"]`` (not ``a``).
- Inline-table containers do not expose a comment view (TOML
  forbids comments inside an inline table).
"""

from __future__ import annotations

import sys
from collections.abc import Iterable, MutableMapping
from typing import TYPE_CHECKING, TypeVar

if sys.version_info >= (3, 12):
    from typing import override
else:  # pragma: no cover -- backport for Python < 3.12
    from typing_extensions import override

from tomlrt._errors import TOMLError
from tomlrt._kind import _Kind
from tomlrt._slots import KVSlot, StructuralHeaderSlot
from tomlrt._trivia import (
    CommentNode,
    NewlineNode,
    WhitespaceNode,
)

if TYPE_CHECKING:
    from collections.abc import Iterator

    from tomlrt._container import Container, Document
    from tomlrt._slots import Slot
    from tomlrt._trivia import (
        EolTrivia,
        Trivia,
        TriviaPiece,
    )


def _validate_comment_text(text: str) -> None:
    """Reject a comment value that would not round-trip via the parser."""
    if "\n" in text or "\r" in text:
        msg = "comment must be single-line"
        raise TOMLError(msg)
    for ch in text:
        cp = ord(ch)
        # TOML comments allow TAB plus any printable Unicode; reject
        # other ASCII control chars and DEL.
        if cp == 0x09:
            continue
        if cp < 0x20 or cp == 0x7F:
            msg = f"comment may not contain control character U+{cp:04X}"
            raise TOMLError(msg)


def _validate_comment_str(value: object, name: str) -> str:
    """Type-check ``value`` is a str and validate its content; return it."""
    if not isinstance(value, str):
        msg = f"{name} must be str, got {type(value).__name__}"
        raise TypeError(msg)
    _validate_comment_text(value)
    return value


def _decode_comment(raw: str) -> str:
    """Strip the leading ``#`` and one optional space from a raw comment."""
    if raw.startswith("#"):
        rest = raw[1:]
        if rest.startswith(" "):
            return rest[1:]
        return rest
    return raw


def _encode_comment(text: str) -> str:
    """Encode a logical comment into a raw ``# ...`` form."""
    if text == "":
        return "#"
    return f"# {text}"


def _direct_kv_slot(c: Container, key: str) -> KVSlot | None:
    """Return the primary direct-KV slot for ``key`` in ``c``, or None."""
    refs = c._index.get(key)  # noqa: SLF001
    if not refs:
        return None
    target = (*c._path, key)  # noqa: SLF001
    for ref in refs:
        slot = ref.slot
        if isinstance(slot, KVSlot) and slot.host_path + slot.key == target:
            return slot
    return None


def _require_attached(c: Container) -> None:
    """Reject comment-view mutation on a container with no slot stream.

    Detached containers (e.g. ``Table.section()`` before assignment into
    a `Document`) have no slot stream, so the comment views have nowhere
    to store the mutation. Raise a clear `TOMLError` pointing at the
    fix instead of a misleading ``KeyError`` from the internal slot
    lookup.
    """
    if c._layout_root is None:  # noqa: SLF001
        msg = (
            "comments view is unavailable on a detached container; "
            "attach the container to a Document first (e.g. doc[k] = table) "
            "and then mutate doc[k].comments"
        )
        raise TOMLError(msg)


_T = TypeVar("_T")


class _SlotKeyedView(MutableMapping[str, _T]):
    """Mapping over Container keys whose direct-KV slot satisfies a predicate.

    Subclasses provide ``_present(slot)`` plus the read/write/delete
    item methods. The base supplies ``__init__``, ``__contains__``,
    ``__iter__``, ``__len__`` and ``__repr__``.
    """

    __slots__ = ("_c",)

    def __init__(self, container: Container) -> None:
        self._c = container

    def _slot(self, key: str) -> KVSlot | None:
        return _direct_kv_slot(self._c, key)

    def _present(self, slot: KVSlot) -> bool:
        raise NotImplementedError

    @override
    def __repr__(self) -> str:
        return repr(dict(self))

    @override
    def __contains__(self, key: object) -> bool:
        if not isinstance(key, str):
            return False
        slot = self._slot(key)
        return slot is not None and self._present(slot)

    @override
    def __iter__(self) -> Iterator[str]:
        seen: set[str] = set()
        for ref in self._c._refs:  # noqa: SLF001
            k = ref.local_key
            if k is None or k in seen:
                continue
            slot = self._slot(k)
            if slot is not None and self._present(slot):
                seen.add(k)
                yield k

    @override
    def __len__(self) -> int:
        return sum(1 for _ in self)


class EolCommentView(_SlotKeyedView[str]):
    __slots__ = ()

    @override
    def _present(self, slot: KVSlot) -> bool:
        return slot.eol.comment is not None

    @override
    def __getitem__(self, key: str) -> str:
        slot = self._slot(key)
        if slot is None or slot.eol.comment is None:
            raise KeyError(key)
        return _decode_comment(slot.eol.comment.text)

    @override
    def __setitem__(self, key: str, value: str) -> None:
        _require_attached(self._c)
        slot = self._slot(key)
        if slot is None:
            msg = f"key {key!r} not in container"
            raise KeyError(msg)
        _validate_comment_str(value, "comment")
        _write_eol_comment(slot.eol, value, self._c._doc_newline)  # noqa: SLF001

    @override
    def __delitem__(self, key: str) -> None:
        _require_attached(self._c)
        slot = self._slot(key)
        if slot is None or slot.eol.comment is None:
            raise KeyError(key)
        slot.eol.comment = None
        # Also drop the gap-whitespace that preceded the comment so we
        # don't leave a dangling tail like `key = 1   \n`.
        if slot.eol.trailing_ws is not None:
            slot.eol.trailing_ws = None


def _split_leading_into_lines(leading: Trivia) -> list[list[TriviaPiece]]:
    """Group trivia pieces into logical "lines" terminated by Newline.

    Returns a list of lists; each inner list is the pieces that
    appeared on a single source line up to and including the
    terminating newline (if any).
    """
    lines: list[list[TriviaPiece]] = []
    cur: list[TriviaPiece] = []
    for p in leading.pieces:
        cur.append(p)
        if isinstance(p, NewlineNode):
            lines.append(cur)
            cur = []
    if cur:
        lines.append(cur)
    return lines


def _line_is_comment(line: list[TriviaPiece]) -> bool:
    return any(isinstance(p, CommentNode) for p in line)


def _split_attached_block(
    leading: Trivia,
) -> tuple[list[list[TriviaPiece]], list[list[TriviaPiece]], list[TriviaPiece]]:
    """Split the leading into (above_blank, attached_comment_lines, slot_indent).

    The "attached" group is the contiguous run of comment lines
    immediately preceding the slot — i.e. with no blank line
    between the run and the slot itself.  Everything before the
    last blank-separator-or-start is "above_blank" (preamble +
    archived blocks).  ``slot_indent`` is any trailing whitespace-
    only, newline-less "indent" line (the slot's own column
    offset) — preserved separately so callers can reapply it
    when rebuilding the leading.
    """
    lines = _split_leading_into_lines(leading)
    indent: list[TriviaPiece] = []
    if lines and not any(isinstance(p, NewlineNode) for p in lines[-1]):
        last = lines[-1]
        # Only treat as indent if it has no comment.
        if not any(isinstance(p, CommentNode) for p in last):
            indent = last
            lines = lines[:-1]
    i = len(lines)
    while i > 0 and _line_is_comment(lines[i - 1]):
        i -= 1
    above = lines[:i]
    attached = lines[i:]
    return above, attached, indent


def _slot_is_doc_head(c: Container, slot: Slot) -> bool:
    """True if ``slot`` is the document's head slot.

    The head slot's above-blank region doubles as
    :attr:`Document.preamble`.  Read/write APIs that expose the slot's
    full leading must omit (resp. preserve) that region for the head
    slot so that round-tripping a section's trivia doesn't migrate
    the preamble into the section body.
    """
    doc = c._layout_root  # noqa: SLF001
    return doc is not None and slot is doc._head  # noqa: SLF001


def _read_leading_block(c: Container, slot: Slot) -> tuple[str | None, ...]:
    """Decoded leading block of ``slot``, omitting any document preamble.

    Comment-bearing lines decode to their text; blank or whitespace-only
    lines become ``None``.  The slot's own trailing indent line (if any)
    is excluded.

    For the document head slot the above-blank prefix is omitted: it is
    exposed separately via :attr:`Document.preamble`.  For every other
    slot the full leading region is returned, in source order.
    """
    above, attached, _indent = _split_attached_block(slot.leading)
    lines = attached if _slot_is_doc_head(c, slot) else (*above, *attached)
    return tuple(_line_to_comment(line) for line in lines)


def _write_leading_block(
    c: Container, slot: Slot, block: tuple[str | None, ...]
) -> None:
    """Replace ``slot``'s leading with ``block``, preserving any preamble.

    The slot's own trailing indent (column offset) is preserved.  Comment
    lines re-use that indent as their prefix; blank lines are emitted as
    a bare newline with no trailing whitespace.

    For the document head slot the above-blank prefix is left in place
    so that :attr:`Document.preamble` survives a round-trip of
    :func:`_read_leading_block`.
    """
    above, _attached, indent = _split_attached_block(slot.leading)
    new_pieces: list[TriviaPiece] = []
    if _slot_is_doc_head(c, slot):
        for line in above:
            new_pieces.extend(line)
    nl = c._doc_newline  # noqa: SLF001
    for entry in block:
        if entry is None:
            new_pieces.append(NewlineNode(nl))
        else:
            new_pieces.extend(indent)
            new_pieces.append(CommentNode(_encode_comment(entry)))
            new_pieces.append(NewlineNode(nl))
    new_pieces.extend(indent)
    slot.leading.pieces = new_pieces


def _validate_block_seq(value: object, name: str) -> tuple[str | None, ...]:
    """Type-check a leading-block tuple; entries are ``str`` or ``None``."""
    if isinstance(value, str):
        msg = f"{name} must be an iterable of comment strings or None"
        raise TypeError(msg)
    if not isinstance(value, Iterable):
        msg = f"{name} must be an iterable of comment strings or None"
        raise TypeError(msg)
    out: list[str | None] = []
    for c in value:
        if c is None:
            out.append(None)
            continue
        if not isinstance(c, str):
            msg = f"{name} entries must be str or None"
            raise TypeError(msg)
        if "\n" in c or "\r" in c:
            msg = f"{name} entries must not contain a line terminator"
            raise TOMLError(msg)
        _validate_comment_text(c)
        out.append(c)
    return tuple(out)


def _extract_leading_comments(leading: Trivia) -> tuple[str, ...]:
    """Return only the *attached* run of comment-bearing lines.

    The "attached" run is the contiguous block immediately above
    the slot — comments separated by a blank line are considered
    preamble or archived blocks and are excluded.
    """
    _above, attached, _indent = _split_attached_block(leading)
    return _lines_to_comments(attached)


def _slot_has_attached_comments(slot: Slot) -> bool:
    leading = slot.leading
    _above, attached, _indent = _split_attached_block(leading)
    return any(_line_is_comment(line) for line in attached)


class LeadingCommentView(_SlotKeyedView[tuple[str, ...]]):
    __slots__ = ()

    @override
    def _present(self, slot: KVSlot) -> bool:
        return _slot_has_attached_comments(slot)

    @override
    def __getitem__(self, key: str) -> tuple[str, ...]:
        slot = self._slot(key)
        if slot is None or not _slot_has_attached_comments(slot):
            raise KeyError(key)
        return _extract_leading_comments(slot.leading)

    @override
    def __setitem__(self, key: str, value: tuple[str, ...]) -> None:
        _require_attached(self._c)
        slot = self._slot(key)
        if slot is None:
            msg = f"key {key!r} not in container"
            raise KeyError(msg)
        comments = _validate_comment_seq(value, "leading_comments")
        _set_attached_block(slot.leading, comments, self._c._doc_newline)  # noqa: SLF001

    @override
    def __delitem__(self, key: str) -> None:
        _require_attached(self._c)
        slot = self._slot(key)
        if slot is None:
            raise KeyError(key)
        if not _slot_has_attached_comments(slot):
            raise KeyError(key)
        above, _attached, indent = _split_attached_block(slot.leading)
        kept: list[TriviaPiece] = []
        for line in above:
            kept.extend(line)
        kept.extend(indent)
        slot.leading.pieces = kept


class LeadingBlockView(_SlotKeyedView[tuple[str | None, ...]]):
    """Mapping view over the full leading-trivia block of each direct key.

    Entries are tuples of comment strings and ``None`` (one ``None`` per
    blank line), in source order; the slot's own column indent is not
    included.  This is the full-fidelity peer of
    :class:`LeadingCommentView`, which only exposes the trailing attached
    block.  Writing replaces the entire leading; the slot's indent is
    re-applied to each comment line and to the slot itself.

    For the document's head slot the above-blank region (preamble) is
    disjoint from this view: it is exposed and mutated via
    :attr:`Document.preamble` instead.
    """

    __slots__ = ()

    @override
    def _present(self, slot: KVSlot) -> bool:
        return bool(_read_leading_block(self._c, slot))

    @override
    def __getitem__(self, key: str) -> tuple[str | None, ...]:
        slot = self._slot(key)
        if slot is None:
            raise KeyError(key)
        block = _read_leading_block(self._c, slot)
        if not block:
            raise KeyError(key)
        return block

    @override
    def __setitem__(self, key: str, value: tuple[str | None, ...]) -> None:
        _require_attached(self._c)
        slot = self._slot(key)
        if slot is None:
            msg = f"key {key!r} not in container"
            raise KeyError(msg)
        block = _validate_block_seq(value, "leading_block")
        _write_leading_block(self._c, slot, block)

    @override
    def __delitem__(self, key: str) -> None:
        _require_attached(self._c)
        slot = self._slot(key)
        if slot is None:
            raise KeyError(key)
        if not _read_leading_block(self._c, slot):
            raise KeyError(key)
        _write_leading_block(self._c, slot, ())


def _header_slot(c: Container) -> StructuralHeaderSlot | None:
    """Return the StructuralHeaderSlot for a section container, or raise.

    Raises TOMLError on inline tables (no header to attach a comment to).
    Returns None if this container has no own header (document root /
    purely-implicit container).
    """
    if c._inline:  # noqa: SLF001
        msg = "header comment API is not available on inline tables"
        raise TOMLError(msg)
    if c._kind is not _Kind.SECTION:  # noqa: SLF001
        return None
    hr = c._header_ref  # noqa: SLF001
    assert hr is not None  # implied by SECTION
    slot = hr.slot
    assert isinstance(slot, StructuralHeaderSlot)
    return slot


def _header_comment_get(c: Container) -> str | None:
    h = _header_slot(c)
    if h is None:
        msg = "container has no header to attach a comment to"
        raise TOMLError(msg)
    eol = h.eol
    if eol.comment is None:
        return None
    return _decode_comment(eol.comment.text)


def _header_comment_set(c: Container, value: str | None) -> None:
    h = _header_slot(c)
    if h is None:
        msg = "container has no header to attach a comment to"
        raise TOMLError(msg)
    eol = h.eol
    if value is None:
        if eol.comment is not None:
            eol.comment = None
            if eol.trailing_ws is not None and eol.trailing_ws.text.strip(" \t") == "":
                eol.trailing_ws = None
        return
    _validate_comment_str(value, "header_comment")
    _write_eol_comment(eol, value, c._doc_newline)  # noqa: SLF001


def _header_leading_get(c: Container) -> tuple[str, ...]:
    h = _header_slot(c)
    if h is None:
        msg = "container has no header to attach leading comments to"
        raise TOMLError(msg)
    return _extract_leading_comments(h.leading)


def _header_leading_set(c: Container, value: tuple[str, ...]) -> None:
    h = _header_slot(c)
    if h is None:
        msg = "container has no header to attach leading comments to"
        raise TOMLError(msg)
    comments = _validate_comment_seq(value, "header_leading_comments")
    _set_attached_block(h.leading, comments, c._doc_newline)  # noqa: SLF001


def _header_leading_block_get(c: Container) -> tuple[str | None, ...]:
    h = _header_slot(c)
    if h is None:
        msg = "container has no header to attach a leading block to"
        raise TOMLError(msg)
    return _read_leading_block(c, h)


def _header_leading_block_set(c: Container, value: tuple[str | None, ...]) -> None:
    h = _header_slot(c)
    if h is None:
        msg = "container has no header to attach a leading block to"
        raise TOMLError(msg)
    block = _validate_block_seq(value, "header_leading_block")
    _write_leading_block(c, h, block)


def _validate_comment_seq(value: object, name: str) -> tuple[str, ...]:
    if isinstance(value, str):
        msg = f"{name} must be an iterable of comment strings"
        raise TypeError(msg)
    if not isinstance(value, Iterable):
        msg = f"{name} must be an iterable of comment strings"
        raise TypeError(msg)
    out: list[str] = []
    for c in value:
        if not isinstance(c, str):
            msg = f"{name} entries must be strings"
            raise TypeError(msg)
        if "\n" in c or "\r" in c:
            msg = "preamble lines must not contain a line terminator"
            raise TOMLError(msg)
        _validate_comment_text(c)
        out.append(c)
    return tuple(out)


def _line_to_comment(line: Iterable[TriviaPiece]) -> str | None:
    """Decoded comment text for a line, or ``None`` if it has no comment."""
    for p in line:
        if isinstance(p, CommentNode):
            return _decode_comment(p.text)
    return None


def _lines_to_comments(lines: Iterable[Iterable[TriviaPiece]]) -> tuple[str, ...]:
    """Extract one decoded comment per line that contains a CommentNode."""
    return tuple(c for line in lines if (c := _line_to_comment(line)) is not None)


def _set_attached_block(leading: Trivia, comments: tuple[str, ...], nl: str) -> None:
    """Replace the attached comment block on ``leading`` with ``comments``.

    Preserves any preamble / archived blocks above any blank-line
    separator and re-applies the slot's own indent before each new
    comment line and the slot itself.
    """
    above, _attached, indent = _split_attached_block(leading)
    kept: list[TriviaPiece] = []
    for line in above:
        kept.extend(line)
    new_pieces: list[TriviaPiece] = []
    for c in comments:
        new_pieces.extend(indent)
        new_pieces.append(CommentNode(_encode_comment(c)))
        new_pieces.append(NewlineNode(nl))
    new_pieces.extend(indent)
    leading.pieces = [*kept, *new_pieces]


def _write_eol_comment(eol: EolTrivia, text: str, nl: str) -> None:
    """Set the EOL comment on ``eol``, ensuring a separator and newline."""
    if eol.trailing_ws is None:
        eol.trailing_ws = WhitespaceNode(" ")
    elif eol.trailing_ws.text == "":
        eol.trailing_ws.text = " "
    eol.comment = CommentNode(_encode_comment(text))
    if eol.newline is None:
        eol.newline = NewlineNode(nl)


def _doc_preamble_get(doc: Document) -> tuple[str, ...]:
    head = doc._head  # noqa: SLF001
    if head is None:
        # Empty doc: read from _trailing.
        return _lines_to_comments(_split_leading_into_lines(doc._trailing))  # noqa: SLF001
    above, _attached, _indent = _split_attached_block(head.leading)
    return _lines_to_comments(above)


def _doc_preamble_set(doc: Document, value: tuple[str, ...]) -> None:
    comments = _validate_comment_seq(value, "preamble")
    nl = doc._newline  # noqa: SLF001
    head = doc._head  # noqa: SLF001
    if head is None:
        # Empty doc: write into _trailing.
        if not comments:
            doc._trailing.pieces = []  # noqa: SLF001
            return
        new_pieces: list[TriviaPiece] = []
        for c in comments:
            new_pieces.append(CommentNode(_encode_comment(c)))
            new_pieces.append(NewlineNode(nl))
        doc._trailing.pieces = new_pieces  # noqa: SLF001
        return
    leading = head.leading
    _above, attached, indent = _split_attached_block(leading)
    if not comments:
        # Drop preamble; keep only the attached block (and indent).
        kept: list[TriviaPiece] = []
        for line in attached:
            kept.extend(line)
        kept.extend(indent)
        leading.pieces = kept
        return
    new_pieces = []
    for c in comments:
        new_pieces.append(CommentNode(_encode_comment(c)))
        new_pieces.append(NewlineNode(nl))
    # Add a blank-line separator between preamble and attached/key.
    new_pieces.append(NewlineNode(nl))
    kept = []
    for line in attached:
        kept.extend(line)
    kept.extend(indent)
    leading.pieces = [*new_pieces, *kept]


def _doc_epilogue_get(doc: Document) -> tuple[str, ...]:
    head = doc._head  # noqa: SLF001
    if head is None:
        # Empty doc: there is no epilogue separate from preamble; both
        # routes read _trailing, but tests expect epilogue == () on an
        # empty doc.
        return ()
    return _lines_to_comments(_split_leading_into_lines(doc._trailing))  # noqa: SLF001


def _doc_epilogue_set(doc: Document, value: tuple[str, ...]) -> None:
    comments = _validate_comment_seq(value, "epilogue")
    head = doc._head  # noqa: SLF001
    if head is None and comments:
        msg = "cannot set epilogue: document has no structural content"
        raise TOMLError(msg)
    nl = doc._newline  # noqa: SLF001
    new_pieces: list[TriviaPiece] = []
    for c in comments:
        new_pieces.append(CommentNode(_encode_comment(c)))
        new_pieces.append(NewlineNode(nl))
    doc._trailing.pieces = new_pieces  # noqa: SLF001


__all__ = ["EolCommentView", "LeadingBlockView", "LeadingCommentView"]
