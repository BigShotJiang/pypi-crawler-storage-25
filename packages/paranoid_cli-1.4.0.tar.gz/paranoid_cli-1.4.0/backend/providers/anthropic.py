"""Anthropic LLM provider implementation."""

import json
from typing import TypeVar

from anthropic import Anthropic, APIError, AuthenticationError, RateLimitError
from pydantic import BaseModel, ValidationError

from backend.models.extended import ImageContent
from backend.providers.base import (
    ProviderAuthError,
    ProviderError,
    ProviderRateLimitError,
    run_sync_in_executor,
    strip_markdown_fences,
)


T = TypeVar("T", bound=BaseModel)

# Module-level cache for model_json_schema() results — these are deterministic
# per class and can be computed once rather than on every API call.
_schema_cache: dict[type, dict] = {}


class AnthropicProvider:
    """Anthropic Claude provider with structured output support.

    Usage as async context manager (recommended):
        async with AnthropicProvider(model="claude-sonnet-4", api_key="...") as provider:
            result = await provider.generate_structured(...)

    The Anthropic sync SDK client doesn't require explicit closing, but the
    context manager interface is provided for consistency with the Protocol.
    """

    def __init__(
        self,
        model: str,
        api_key: str,
        max_retries: int = 3,
        timeout: float = 60.0,
    ):
        """Initialize Anthropic provider.

        Args:
            model: Model identifier (e.g., 'claude-sonnet-4')
            api_key: Anthropic API key
            max_retries: Number of retry attempts for failed requests
            timeout: Request timeout in seconds
        """
        self._model = model
        self._client = Anthropic(
            api_key=api_key,
            max_retries=max_retries,
            timeout=timeout,
        )

    @property
    def name(self) -> str:
        """Provider name."""
        return "anthropic"

    @property
    def model(self) -> str:
        """Model identifier."""
        return self._model

    async def generate_structured(
        self,
        prompt: str,
        response_model: type[T],
        temperature: float = 0.0,
        max_tokens: int | None = None,
        images: list[ImageContent] | None = None,
        shared_context: str | None = None,
    ) -> T:
        """Generate structured output conforming to a Pydantic model.

        Supports vision API for PNG/JPG images via content blocks.

        When shared_context is provided it is sent as a separate content block
        marked with cache_control: ephemeral so Anthropic's prompt cache can
        serve it from cache for every call in the same pipeline run (5-min TTL).
        The system prompt block is always marked cacheable; images are marked
        cacheable when shared_context is also present (they are stable too).
        """
        try:
            # Get JSON schema from Pydantic model (cached per class — deterministic)
            if response_model not in _schema_cache:
                _schema_cache[response_model] = response_model.model_json_schema()
            schema = _schema_cache[response_model]

            # Construct system prompt for JSON output (compact JSON, no indent).
            # Passed as a list of blocks so cache_control can be applied — Anthropic
            # caches the system block across calls that share the exact same content.
            schema_text = (
                f"You must respond with valid JSON matching this schema:\n"
                f"{json.dumps(schema)}\n\n"
                f"Respond ONLY with the JSON object, no other text."
            )
            system = [{"type": "text", "text": schema_text, "cache_control": {"type": "ephemeral"}}]

            # Build user content blocks.
            # Order: images → shared_context (cacheable) → dynamic prompt (not cached).
            # Images and shared_context get cache_control when shared_context is present
            # so the entire stable prefix is served from cache on subsequent calls.
            content: list[dict] = []

            if images:
                for img in images:
                    block: dict = {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": img.media_type,
                            "data": img.data,
                        },
                    }
                    if shared_context:
                        block["cache_control"] = {"type": "ephemeral"}
                    content.append(block)

            if shared_context:
                content.append(
                    {
                        "type": "text",
                        "text": shared_context,
                        "cache_control": {"type": "ephemeral"},
                    }
                )

            content.append({"type": "text", "text": prompt})

            # Call Anthropic API in thread pool (sync SDK)
            response = await run_sync_in_executor(
                self._client.messages.create,
                model=self._model,
                max_tokens=max_tokens or 4096,
                temperature=temperature,
                system=system,
                messages=[{"role": "user", "content": content}],
            )

            # Extract and clean text content
            response_text = response.content[0].text
            response_text = strip_markdown_fences(response_text)

            # Parse JSON and validate against Pydantic model
            try:
                data = json.loads(response_text)
                return response_model.model_validate(data)
            except (json.JSONDecodeError, ValidationError) as e:
                raise ProviderError(
                    provider=self.name,
                    message=f"Failed to parse structured output: {e}",
                    original_error=e,
                )

        except AuthenticationError as e:
            raise ProviderAuthError(
                provider=self.name,
                message="Authentication failed - check API key",
                original_error=e,
            )
        except RateLimitError as e:
            raise ProviderRateLimitError(
                provider=self.name,
                message="Rate limit exceeded",
                original_error=e,
            )
        except APIError as e:
            raise ProviderError(
                provider=self.name,
                message=f"API error: {e!s}",
                original_error=e,
            )

    async def generate(
        self,
        prompt: str,
        temperature: float = 0.0,
        max_tokens: int | None = None,
    ) -> str:
        """Generate plain text output."""
        try:
            # Call Anthropic API in thread pool (sync SDK)
            response = await run_sync_in_executor(
                self._client.messages.create,
                model=self._model,
                max_tokens=max_tokens or 4096,
                temperature=temperature,
                messages=[{"role": "user", "content": prompt}],
            )

            return response.content[0].text

        except AuthenticationError as e:
            raise ProviderAuthError(
                provider=self.name,
                message="Authentication failed - check API key",
                original_error=e,
            )
        except RateLimitError as e:
            raise ProviderRateLimitError(
                provider=self.name,
                message="Rate limit exceeded",
                original_error=e,
            )
        except APIError as e:
            raise ProviderError(
                provider=self.name,
                message=f"API error: {e!s}",
                original_error=e,
            )

    async def __aenter__(self) -> "AnthropicProvider":
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context manager.

        The Anthropic sync SDK client doesn't require explicit resource cleanup,
        but this method is provided for protocol consistency.
        """
        pass  # Anthropic sync client doesn't need explicit closing
