"""
Version and license information.
"""


__version__ = '3.3.2'
__versiondate__ = '2026-04-04'
__license__ = f'Starsim {__version__} ({__versiondate__}) — © 2023-2026 by IDM'
