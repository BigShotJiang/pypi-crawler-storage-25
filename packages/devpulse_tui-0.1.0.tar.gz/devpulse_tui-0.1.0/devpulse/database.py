from datetime import datetime
from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    Float,
    String,
)

from sqlalchemy.orm import (
    declarative_base,
    sessionmaker,
)

Base = declarative_base()


class SystemStat(Base):
    __tablename__ = "system_stats"

    id = Column(Integer, primary_key=True)
    timestamp = Column(
        String,
        default=lambda: datetime.now().isoformat()
    )
    cpu = Column(Float)
    ram = Column(Float)
    disk = Column(Float)

    gpu = Column(String)

    upload = Column(Float)
    download = Column(Float)

    repo = Column(String)
    branch = Column(String)


engine = create_engine(
    "sqlite:///devpulse.db"
)

SessionLocal = sessionmaker(bind=engine)


def init_db():
    Base.metadata.create_all(engine)

def log_system_stats(
    cpu,
    ram,
    disk,
    gpu,
    upload,
    download,
    repo,
    branch,
):
    session = SessionLocal()

    stat = SystemStat(
        cpu=cpu,
        ram=ram,
        disk=disk,
        gpu=gpu,
        upload=upload,
        download=download,
        repo=repo,
        branch=branch,
    )

    session.add(stat)
    session.commit()

    session.close()