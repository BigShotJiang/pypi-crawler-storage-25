import argparse
import logging
import os

from .logger import get_logger

logger = get_logger(__name__)


def parse_args():
    parser = argparse.ArgumentParser(
        prog="aniworld",
        description=(
            "MRX-AniWorld Downloader – WebUI mode. "
            "Run 'aniworld' to start the web interface directly. "
            "The CLI has been removed; all functionality is available via the WebUI."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument(
        "-wP",
        "--web-port",
        type=int,
        default=8080,
        help="Port for the web UI (default: 8080)",
    )

    parser.add_argument(
        "-wN",
        "--no-browser",
        action="store_true",
        help="Don't open the browser automatically when starting the web UI",
    )

    parser.add_argument(
        "-d",
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )

    args = parser.parse_args()

    if args.debug:
        os.environ["ANIWORLD_DEBUG_MODE"] = "1"
        logging.getLogger().setLevel(logging.DEBUG)
        for name in logging.Logger.manager.loggerDict:
            logging.getLogger(name).setLevel(logging.DEBUG)
        logger.debug("Debug mode enabled")

    return args
