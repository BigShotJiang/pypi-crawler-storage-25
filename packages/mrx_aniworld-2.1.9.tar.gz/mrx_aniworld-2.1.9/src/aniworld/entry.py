import sys
import warnings
from pathlib import Path

# authlib internally uses its deprecated jose module — suppress until they fix it
warnings.filterwarnings("ignore", category=DeprecationWarning, module="authlib")

from .arguments import parse_args
from .autodeps import ensure_patchright_chromium
from .config import ANIWORLD_CONFIG_DIR, VERSION
from .env import merge_env
from .logger import get_logger

merge_env(
    Path(__file__).resolve().parent / ".env.example",
    ANIWORLD_CONFIG_DIR / ".env",
)

logger = get_logger(__name__)


def set_terminal_title():
    """Set the terminal title if running in a TTY"""
    if sys.stdout.isatty():
        title = f"AniWorld-Downloader v.{VERSION}"
        print(f"\033]0;{title}\007", end="", flush=True)


def aniworld():
    """Main entry point — always starts the WebUI directly."""
    try:
        logger.debug("Starting WebUI...")
        set_terminal_title()
        ensure_patchright_chromium()

        args = parse_args()

        from .web import start_web_ui

        start_web_ui(
            host="0.0.0.0",
            port=args.web_port,
            open_browser=not args.no_browser,
            auth_enabled=True,
            sso_enabled=False,
            force_sso=False,
        )
        return 0

    except KeyboardInterrupt:
        print("\nQuitting.", file=sys.stderr)
        return 130

    except Exception as err:
        logger.error("Unexpected error occurred", exc_info=True)
        print(f"\nAn unexpected error occurred: {err}", file=sys.stderr)
        print("Please check the logs for more details.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(aniworld())
