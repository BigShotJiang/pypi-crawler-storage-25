import os
import sqlite3

from werkzeug.security import check_password_hash, generate_password_hash

from ..config import ANIWORLD_CONFIG_DIR
from ..logger import get_logger

logger = get_logger(__name__)

DB_PATH = ANIWORLD_CONFIG_DIR / "aniworld.db"

_CREATE_TABLE = """\
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin', 'user')),
    auth_method TEXT NOT NULL DEFAULT 'local',
    sso_subject TEXT,
    sso_issuer TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

_CREATE_SSO_INDEX = """\
CREATE UNIQUE INDEX IF NOT EXISTS idx_sso_identity
ON users (sso_issuer, sso_subject)
WHERE sso_issuer IS NOT NULL AND sso_subject IS NOT NULL;
"""


class ContextConnection(sqlite3.Connection):
    def close(self):
        try:
            from flask import g, has_app_context
            if has_app_context() and g.get("db_conn") is self:
                return  # Do not close if cached in request context
        except Exception:
            pass
        super().close()


def get_db():
    ANIWORLD_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        from flask import g, has_app_context
        if has_app_context():
            if "db_conn" not in g:
                conn = sqlite3.connect(str(DB_PATH), timeout=30, check_same_thread=False, factory=ContextConnection)
                conn.row_factory = sqlite3.Row
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA busy_timeout=30000")
                g.db_conn = conn
            return g.db_conn
    except Exception:
        pass

    conn = sqlite3.connect(str(DB_PATH), timeout=30, check_same_thread=False, factory=ContextConnection)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def _migrate_db(conn):
    rows = conn.execute("PRAGMA table_info(users)").fetchall()
    columns = {r["name"] for r in rows}

    if "auth_method" not in columns:
        conn.execute(
            "ALTER TABLE users ADD COLUMN auth_method TEXT NOT NULL DEFAULT 'local'"
        )
    if "sso_subject" not in columns:
        conn.execute("ALTER TABLE users ADD COLUMN sso_subject TEXT")
    if "sso_issuer" not in columns:
        conn.execute("ALTER TABLE users ADD COLUMN sso_issuer TEXT")

    conn.execute(_CREATE_SSO_INDEX)
    conn.commit()


def init_db():
    conn = get_db()
    try:
        conn.execute(_CREATE_TABLE)
        conn.execute(_CREATE_SSO_INDEX)
        conn.commit()
        _migrate_db(conn)
    finally:
        conn.close()

    if not has_any_admin():
        env_user = os.environ.get("ANIWORLD_WEB_ADMIN_USER", "").strip()
        env_pass = os.environ.get("ANIWORLD_WEB_ADMIN_PASS", "").strip()
        if env_user and env_pass:
            create_user(env_user, env_pass, role="admin")
            logger.info("Auto-created admin user '%s' from environment", env_user)


def has_any_admin():
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS cnt FROM users WHERE role = 'admin'"
        ).fetchone()
        return row["cnt"] > 0
    finally:
        conn.close()


def create_user(username, password, role="user"):
    conn = get_db()
    try:
        cur = conn.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
            (username, generate_password_hash(password), role),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def verify_user(username, password):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id, username, password_hash, role, auth_method FROM users WHERE username = ?",
            (username,),
        ).fetchone()
        if not row:
            return None, "Invalid username or password."
        if row["auth_method"] != "local":
            return None, "This account uses SSO. Please use the SSO login button."
        if check_password_hash(row["password_hash"], password):
            return {
                "id": row["id"],
                "username": row["username"],
                "role": row["role"],
            }, None
        return None, "Invalid username or password."
    finally:
        conn.close()


def find_or_create_sso_user(
    issuer, subject, username, admin_username=None, admin_subject=None
):
    def _should_be_admin():
        if admin_subject and subject == admin_subject:
            return True
        if admin_username and username == admin_username:
            return True
        return False

    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id, username, role FROM users WHERE sso_issuer = ? AND sso_subject = ?",
            (issuer, subject),
        ).fetchone()

        if row:
            user = {"id": row["id"], "username": row["username"], "role": row["role"]}
            if _should_be_admin() and row["role"] != "admin":
                conn.execute(
                    "UPDATE users SET role = 'admin' WHERE id = ?", (row["id"],)
                )
                conn.commit()
                user["role"] = "admin"
            return user

        # Check for username conflict with local users
        existing = conn.execute(
            "SELECT id, auth_method FROM users WHERE username = ?",
            (username,),
        ).fetchone()
        if existing:
            raise ValueError(
                f"Username '{username}' is already taken by a local account."
            )

        role = "admin" if _should_be_admin() else "user"
        cur = conn.execute(
            "INSERT INTO users (username, password_hash, role, auth_method, sso_subject, sso_issuer) "
            "VALUES (?, ?, ?, 'oidc', ?, ?)",
            (username, "", role, subject, issuer),
        )
        conn.commit()
        return {"id": cur.lastrowid, "username": username, "role": role}
    finally:
        conn.close()


def list_users():
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT id, username, role, auth_method, created_at FROM users ORDER BY id"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def delete_user(user_id):
    conn = get_db()
    try:
        row = conn.execute("SELECT role FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            return False, "User not found"
        if row["role"] == "admin":
            cnt = conn.execute(
                "SELECT COUNT(*) AS cnt FROM users WHERE role = 'admin'"
            ).fetchone()["cnt"]
            if cnt <= 1:
                return False, "Cannot delete the last admin"
        conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
        return True, None
    finally:
        conn.close()


def update_user_role(user_id, new_role):
    if new_role not in ("admin", "user"):
        return False, "Invalid role"
    conn = get_db()
    try:
        row = conn.execute("SELECT role FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            return False, "User not found"
        if row["role"] == "admin" and new_role != "admin":
            cnt = conn.execute(
                "SELECT COUNT(*) AS cnt FROM users WHERE role = 'admin'"
            ).fetchone()["cnt"]
            if cnt <= 1:
                return False, "Cannot demote the last admin"
        conn.execute("UPDATE users SET role = ? WHERE id = ?", (new_role, user_id))
        conn.commit()
        return True, None
    finally:
        conn.close()


# ===== Download Queue =====

_CREATE_QUEUE_TABLE = """\
CREATE TABLE IF NOT EXISTS download_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    series_url TEXT NOT NULL,
    episodes TEXT NOT NULL,
    total_episodes INTEGER NOT NULL,
    language TEXT NOT NULL,
    provider TEXT NOT NULL,
    username TEXT,
    status TEXT NOT NULL DEFAULT 'queued'
        CHECK(status IN ('queued','running','completed','partial','failed','cancelled')),
    current_episode INTEGER NOT NULL DEFAULT 0,
    current_url TEXT,
    errors TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    completed_at TEXT
);
"""


def init_queue_db():
    ANIWORLD_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_db()
    try:
        conn.execute(_CREATE_QUEUE_TABLE)
        # Add position column for queue reordering (migration for existing DBs)
        try:
            conn.execute(
                "ALTER TABLE download_queue ADD COLUMN position INTEGER NOT NULL DEFAULT 0"
            )
            # Backfill: set position = id for existing rows
            conn.execute("UPDATE download_queue SET position = id WHERE position = 0")
        except Exception:
            pass  # column already exists
        # Add custom_path_id column (migration for existing DBs)
        try:
            conn.execute("ALTER TABLE download_queue ADD COLUMN custom_path_id INTEGER")
        except Exception:
            pass  # column already exists
        # Add source column (migration for existing DBs) - marks origin: 'manual' or 'sync'
        try:
            conn.execute(
                "ALTER TABLE download_queue ADD COLUMN source TEXT NOT NULL DEFAULT 'manual'"
            )
        except Exception:
            pass  # column already exists
        # Add captcha_url column (migration for existing DBs)
        try:
            conn.execute(
                "ALTER TABLE download_queue ADD COLUMN captcha_url TEXT"
            )
        except Exception:
            pass  # column already exists
        # Add hidden column — rows with hidden=1 are excluded from the queue UI
        # but retained for statistics (migration for existing DBs)
        try:
            conn.execute(
                "ALTER TABLE download_queue ADD COLUMN hidden INTEGER NOT NULL DEFAULT 0"
            )
        except Exception:
            pass  # column already exists
        # Add speed/size columns (migration for existing DBs)
        try:
            conn.execute(
                "ALTER TABLE download_queue ADD COLUMN average_speed_mbps REAL"
            )
        except Exception:
            pass
        try:
            conn.execute(
                "ALTER TABLE download_queue ADD COLUMN total_size_mb REAL"
            )
        except Exception:
            pass
        # Migrate CHECK constraint to include 'partial' status (existing DBs)
        # SQLite cannot ALTER constraints — must recreate the table
        try:
            row = conn.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='download_queue'"
            ).fetchone()
            if row and "'partial'" not in row["sql"]:
                conn.execute("ALTER TABLE download_queue RENAME TO _download_queue_old")
                conn.execute(_CREATE_QUEUE_TABLE)
                conn.execute(
                    """INSERT INTO download_queue
                        SELECT id, title, series_url, episodes, total_episodes, language,
                               provider, username,
                               CASE WHEN status = 'partial' THEN 'partial' ELSE status END,
                               current_episode, current_url, errors, created_at, completed_at
                        FROM _download_queue_old"""
                )
                # Re-add columns added via ALTER TABLE (may not exist in old table)
                for col, sql in [
                    ("position",    "ALTER TABLE download_queue ADD COLUMN position INTEGER NOT NULL DEFAULT 0"),
                    ("custom_path_id", "ALTER TABLE download_queue ADD COLUMN custom_path_id INTEGER"),
                    ("source",      "ALTER TABLE download_queue ADD COLUMN source TEXT NOT NULL DEFAULT 'manual'"),
                    ("captcha_url", "ALTER TABLE download_queue ADD COLUMN captcha_url TEXT"),
                    ("hidden",      "ALTER TABLE download_queue ADD COLUMN hidden INTEGER NOT NULL DEFAULT 0"),
                ]:
                    try:
                        conn.execute(sql)
                    except Exception:
                        pass
                # Copy extra columns from old table if they exist
                try:
                    conn.execute(
                        """UPDATE download_queue AS new SET
                            position = (SELECT position FROM _download_queue_old WHERE id = new.id),
                            custom_path_id = (SELECT custom_path_id FROM _download_queue_old WHERE id = new.id),
                            source = (SELECT source FROM _download_queue_old WHERE id = new.id),
                            captcha_url = (SELECT captcha_url FROM _download_queue_old WHERE id = new.id),
                            hidden = (SELECT hidden FROM _download_queue_old WHERE id = new.id)"""
                    )
                except Exception:
                    pass
                conn.execute("DROP TABLE _download_queue_old")
        except Exception:
            pass  

        conn.commit()
    finally:
        conn.close()


def add_to_queue(
    title,
    series_url,
    episodes,
    language,
    provider,
    username=None,
    custom_path_id=None,
    source="manual",
):
    import json

    conn = get_db()
    try:
        cur = conn.execute(
            "INSERT INTO download_queue (title, series_url, episodes, total_episodes, language, provider, username, custom_path_id, source) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                title,
                series_url,
                json.dumps(episodes),
                len(episodes),
                language,
                provider,
                username,
                custom_path_id,
                source,
            ),
        )
        row_id = cur.lastrowid
        conn.execute(
            "UPDATE download_queue SET position = ? WHERE id = ?", (row_id, row_id)
        )
        conn.commit()
        return row_id
    finally:
        conn.close()


def is_series_queued_or_running(series_url, language=None, requested_episodes=None):
    """Check if a series already has an overlapping set of episodes in the queue."""
    import json
    series_url = series_url.strip().rstrip("/")
    conn = get_db()
    try:
        query = (
            "SELECT episodes FROM download_queue "
            "WHERE (series_url = ? OR series_url = ?) AND status IN ('queued', 'running')"
        )
        params = [series_url, series_url + "/"]
        if language:
            query += " AND language = ?"
            params.append(language)

        rows = conn.execute(query, tuple(params)).fetchall()
        if not rows:
            return False
            
        # If no specific episodes provided, fall back to "any item exists" (stricter)
        if not requested_episodes:
            return len(rows) > 0

        # Check if any requested episode URL is already in the existing items
        requested_set = set(requested_episodes)
        for row in rows:
            try:
                existing_episodes = set(json.loads(row["episodes"]))
                if not requested_set.isdisjoint(existing_episodes):
                    return True # Overlap found!
            except Exception:
                continue
        
        return False
    finally:
        conn.close()


def get_queue():
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM download_queue WHERE hidden = 0 ORDER BY position ASC, id ASC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_queue_item(queue_id):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM download_queue WHERE id = ?", (queue_id,)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_next_queued():
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM download_queue WHERE status = 'queued' "
            "ORDER BY position ASC, id ASC LIMIT 1"
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def move_queue_item(queue_id, direction):
    """Swap position of a queued item with its neighbor. direction: 'up' or 'down'."""
    conn = get_db()
    try:
        item = conn.execute(
            "SELECT id, position FROM download_queue WHERE id = ? AND status = 'queued'",
            (queue_id,),
        ).fetchone()
        if not item:
            return False, "Item not found or not queued"

        if direction == "up":
            neighbor = conn.execute(
                "SELECT id, position FROM download_queue "
                "WHERE status = 'queued' AND position < ? "
                "ORDER BY position DESC LIMIT 1",
                (item["position"],),
            ).fetchone()
        else:
            neighbor = conn.execute(
                "SELECT id, position FROM download_queue "
                "WHERE status = 'queued' AND position > ? "
                "ORDER BY position ASC LIMIT 1",
                (item["position"],),
            ).fetchone()

        if not neighbor:
            return False, "Already at the edge"

        # Swap positions
        conn.execute(
            "UPDATE download_queue SET position = ? WHERE id = ?",
            (neighbor["position"], item["id"]),
        )
        conn.execute(
            "UPDATE download_queue SET position = ? WHERE id = ?",
            (item["position"], neighbor["id"]),
        )
        conn.commit()
        return True, None
    finally:
        conn.close()


def get_running():
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM download_queue WHERE status = 'running' LIMIT 1"
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def update_queue_progress(queue_id, current_episode, current_url):
    conn = get_db()
    try:
        conn.execute(
            "UPDATE download_queue SET current_episode = ?, current_url = ? WHERE id = ?",
            (current_episode, current_url, queue_id),
        )
        conn.commit()
    finally:
        conn.close()


def set_queue_status(queue_id, status):
    conn = get_db()
    try:
        if status in ("completed", "failed"):
            conn.execute(
                "UPDATE download_queue SET status = ?, completed_at = datetime('now') WHERE id = ?",
                (status, queue_id),
            )
        else:
            conn.execute(
                "UPDATE download_queue SET status = ? WHERE id = ?",
                (status, queue_id),
            )
        conn.commit()
    finally:
        conn.close()


def update_queue_errors(queue_id, errors_json):
    conn = get_db()
    try:
        conn.execute(
            "UPDATE download_queue SET errors = ? WHERE id = ?",
            (errors_json, queue_id),
        )
        conn.commit()
    finally:
        conn.close()


def update_queue_stats(queue_id, average_speed_mbps, total_size_mb):
    conn = get_db()
    try:
        conn.execute(
            "UPDATE download_queue SET average_speed_mbps = ?, total_size_mb = ? WHERE id = ?",
            (average_speed_mbps, total_size_mb, queue_id),
        )
        conn.commit()
    finally:
        conn.close()


def cancel_queue_item(queue_id):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT status FROM download_queue WHERE id = ?", (queue_id,)
        ).fetchone()
        if not row:
            return False, "Item not found"
        if row["status"] != "running":
            return False, "Can only cancel running items"
        conn.execute(
            "UPDATE download_queue SET status = 'cancelled' WHERE id = ?",
            (queue_id,),
        )
        conn.commit()
        return True, None
    finally:
        conn.close()


def is_queue_cancelled(queue_id):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT status FROM download_queue WHERE id = ?", (queue_id,)
        ).fetchone()
        return row and row["status"] == "cancelled"
    finally:
        conn.close()


def remove_from_queue(queue_id):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT status FROM download_queue WHERE id = ?", (queue_id,)
        ).fetchone()
        if not row:
            return False, "Item not found"
        status = row["status"]
        if status == "running":
            return False, "Cannot remove a running item (cancel it first)"
        if status == "queued":
            # Never ran — safe to delete permanently (no stats value)
            conn.execute("DELETE FROM download_queue WHERE id = ?", (queue_id,))
        else:
            # completed / failed / cancelled — hide so stats are preserved
            conn.execute(
                "UPDATE download_queue SET hidden = 1 WHERE id = ?", (queue_id,)
            )
        conn.commit()
        return True, None
    finally:
        conn.close()


def restart_queue_item_inplace(queue_id, episodes):
    """Reset an existing queue item back to 'queued' with the given episode list (in-place)."""
    import json as _json
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT status FROM download_queue WHERE id = ?", (queue_id,)
        ).fetchone()
        if not row:
            return False, "Item not found"
        if row["status"] == "running":
            return False, "Item is currently running"
        conn.execute(
            """UPDATE download_queue SET
                status = 'queued',
                hidden = 0,
                episodes = ?,
                total_episodes = ?,
                current_episode = 0,
                errors = '[]',
                current_url = NULL,
                completed_at = NULL
               WHERE id = ?""",
            (_json.dumps(episodes), len(episodes), queue_id),
        )
        conn.commit()
        return True, None
    finally:
        conn.close()


def retry_single_episode(queue_id, ep_url):
    """Retry one failed episode in-place.

    Unlike restart_queue_item_inplace this preserves all OTHER errors so they
    remain visible in the UI.  Only the error entry for *ep_url* is removed.
    total_episodes is kept at the original value so the job still looks like
    the same job in the queue.
    """
    import json as _json
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT status, errors, total_episodes FROM download_queue WHERE id = ?",
            (queue_id,),
        ).fetchone()
        if not row:
            return False, "Item not found"
        if row["status"] == "running":
            return False, "Item is currently running"

        # Remove only the error for the specific episode being retried.
        existing_errors = _json.loads(row["errors"] or "[]")
        kept_errors = [e for e in existing_errors if e.get("url") != ep_url]

        conn.execute(
            """UPDATE download_queue SET
                status = 'queued',
                hidden = 0,
                episodes = ?,
                current_episode = 0,
                errors = ?,
                current_url = NULL,
                completed_at = NULL
               WHERE id = ?""",
            (_json.dumps([ep_url]), _json.dumps(kept_errors), queue_id),
        )
        conn.commit()
        return True, None
    finally:
        conn.close()


def delete_completed_queue_item(queue_id):
    """Delete a queue item only if its status is 'completed'. Used by auto-sync cleanup."""
    conn = get_db()
    try:
        conn.execute(
            "DELETE FROM download_queue WHERE id = ? AND status = 'completed'",
            (queue_id,),
        )
        conn.commit()
    finally:
        conn.close()


def set_captcha_url(queue_id: int, url: str):
    """Store the current captcha URL for a running queue item."""
    conn = get_db()
    try:
        conn.execute(
            "UPDATE download_queue SET captcha_url = ? WHERE id = ?",
            (url, queue_id),
        )
        conn.commit()
    finally:
        conn.close()


def clear_captcha_url(queue_id: int):
    """Clear the captcha URL when captcha has been solved."""
    conn = get_db()
    try:
        conn.execute(
            "UPDATE download_queue SET captcha_url = NULL WHERE id = ?",
            (queue_id,),
        )
        conn.commit()
    finally:
        conn.close()


def clear_completed():
    """Hide all finished entries from the queue UI while keeping them for statistics."""
    conn = get_db()
    try:
        conn.execute(
            "UPDATE download_queue SET hidden = 1 "
            "WHERE status IN ('completed', 'partial', 'failed', 'cancelled')"
        )
        conn.commit()
    finally:
        conn.close()


# ===== Custom Download Paths =====

_CREATE_CUSTOM_PATHS_TABLE = """\
CREATE TABLE IF NOT EXISTS custom_paths (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    path TEXT NOT NULL
);
"""


def init_custom_paths_db():
    ANIWORLD_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_db()
    try:
        conn.execute(_CREATE_CUSTOM_PATHS_TABLE)
        conn.commit()
    finally:
        conn.close()


def get_custom_paths():
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT id, name, path FROM custom_paths ORDER BY id"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def add_custom_path(name, path):
    conn = get_db()
    try:
        cur = conn.execute(
            "INSERT INTO custom_paths (name, path) VALUES (?, ?)",
            (name, path),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def is_custom_path_in_use(path_id):
    """Return True if any autosync job currently references this custom path."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS cnt FROM autosync_jobs WHERE custom_path_id = ?",
            (path_id,),
        ).fetchone()
        return row["cnt"] > 0
    finally:
        conn.close()


def remove_custom_path(path_id):
    """Delete a custom path. Returns (True, None) on success or (False, reason) if blocked."""
    if is_custom_path_in_use(path_id):
        return False, "Dieser Pfad wird von mindestens einem Auto-Sync-Job verwendet und kann nicht gelöscht werden."
    conn = get_db()
    try:
        conn.execute("DELETE FROM custom_paths WHERE id = ?", (path_id,))
        conn.commit()
        return True, None
    finally:
        conn.close()


def get_custom_path_by_id(path_id):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id, name, path FROM custom_paths WHERE id = ?", (path_id,)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


# ===== Auto-Sync Jobs =====

_CREATE_AUTOSYNC_TABLE = """\
CREATE TABLE IF NOT EXISTS autosync_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    series_url TEXT NOT NULL,
    language TEXT NOT NULL DEFAULT 'German Dub',
    provider TEXT NOT NULL DEFAULT 'VOE',
    custom_path_id INTEGER,
    enabled INTEGER NOT NULL DEFAULT 1,
    added_by TEXT,
    last_check TEXT,
    last_new_found TEXT,
    episodes_found INTEGER NOT NULL DEFAULT 0,
    local_episodes_found INTEGER NOT NULL DEFAULT 0,
    last_new_count INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    on_hold INTEGER NOT NULL DEFAULT 0,
    path_unavailable_action TEXT NOT NULL DEFAULT 'skip',
    retry_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
"""


def init_autosync_db():
    ANIWORLD_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_db()
    try:
        conn.execute(_CREATE_AUTOSYNC_TABLE)
        # Migration: add last_new_count for existing DBs
        try:
            conn.execute(
                "ALTER TABLE autosync_jobs ADD COLUMN last_new_count INTEGER NOT NULL DEFAULT 0"
            )
        except Exception:
            pass
        # Migration: add local_episodes_found for existing DBs
        try:
            conn.execute(
                "ALTER TABLE autosync_jobs ADD COLUMN local_episodes_found INTEGER NOT NULL DEFAULT 0"
            )
        except Exception:
            pass
        # Migration: add last_error for existing DBs
        try:
            conn.execute(
                "ALTER TABLE autosync_jobs ADD COLUMN last_error TEXT"
            )
        except Exception:
            pass
        # Migration: add on_hold for existing DBs
        try:
            conn.execute(
                "ALTER TABLE autosync_jobs ADD COLUMN on_hold INTEGER NOT NULL DEFAULT 0"
            )
        except Exception:
            pass
        # Migration: add path_unavailable_action for existing DBs
        try:
            conn.execute(
                "ALTER TABLE autosync_jobs ADD COLUMN path_unavailable_action TEXT NOT NULL DEFAULT 'skip'"
            )
        except Exception:
            pass
        # Migration: add retry_count for existing DBs
        try:
            conn.execute(
                "ALTER TABLE autosync_jobs ADD COLUMN retry_count INTEGER NOT NULL DEFAULT 0"
            )
        except Exception:
            pass
        # Add UNIQUE index on series_url (migration for existing DBs)
        try:
            conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_autosync_series_url "
                "ON autosync_jobs (series_url)"
            )
        except sqlite3.IntegrityError:
            # Duplicates already exist — deduplicate keeping the lowest id
            conn.execute(
                "DELETE FROM autosync_jobs WHERE id NOT IN "
                "(SELECT MIN(id) FROM autosync_jobs GROUP BY series_url)"
            )
            conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_autosync_series_url "
                "ON autosync_jobs (series_url)"
            )
        conn.commit()
    finally:
        conn.close()


def add_autosync_job(
    title, series_url, language, provider, custom_path_id=None, added_by=None,
    path_unavailable_action="skip",
):
    """Create a new autosync job.

    last_check is set to the current UTC time on creation so the background
    worker does NOT immediately trigger a sync — the first run will happen
    after the configured interval has elapsed.  This prevents duplicate
    queue entries when the user creates a job and then also starts a manual
    download in the same browser session.
    """
    from datetime import datetime
    now_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    conn = get_db()
    try:
        cur = conn.execute(
            "INSERT INTO autosync_jobs "
            "(title, series_url, language, provider, custom_path_id, added_by, "
            "path_unavailable_action, last_check) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (title, series_url, language, provider, custom_path_id, added_by,
             path_unavailable_action, now_str),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def get_autosync_jobs(username=None):
    """Return all sync jobs. If *username* is given, only that user's jobs."""
    conn = get_db()
    try:
        if username:
            rows = conn.execute(
                "SELECT * FROM autosync_jobs WHERE added_by = ? ORDER BY id",
                (username,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM autosync_jobs ORDER BY id").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_autosync_job(job_id):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM autosync_jobs WHERE id = ?", (job_id,)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def find_autosync_by_url(series_url):
    """Return the first sync job that matches *series_url*, or None.
    
    Comparison is normalized: trailing slashes and case are ignored.
    """
    series_url_norm = (series_url or "").rstrip("/").lower()
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM autosync_jobs WHERE LOWER(RTRIM(series_url, '/')) = ? LIMIT 1",
            (series_url_norm,),
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def update_autosync_job(job_id, **fields):
    """Update arbitrary columns on a sync job."""
    if not fields:
        return
    allowed = {
        "title",
        "series_url",
        "language",
        "provider",
        "custom_path_id",
        "enabled",
        "last_check",
        "last_new_found",
        "episodes_found",
        "local_episodes_found",
        "last_new_count",
        "last_error",
        "on_hold",
        "path_unavailable_action",
        "retry_count",
    }
    filtered = {k: v for k, v in fields.items() if k in allowed}
    if not filtered:
        return
    set_clause = ", ".join(f"{k} = ?" for k in filtered)
    values = list(filtered.values()) + [job_id]
    conn = get_db()
    try:
        conn.execute(f"UPDATE autosync_jobs SET {set_clause} WHERE id = ?", values)
        conn.commit()
    finally:
        conn.close()


def remove_autosync_job(job_id):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id FROM autosync_jobs WHERE id = ?", (job_id,)
        ).fetchone()
        if not row:
            return False, "Job not found"
        conn.execute("DELETE FROM autosync_jobs WHERE id = ?", (job_id,))
        conn.commit()
        return True, None
    finally:
        conn.close()


# ===== Statistics =====


def get_sync_stats():
    conn = get_db()
    try:
        total = conn.execute("SELECT COUNT(*) AS cnt FROM autosync_jobs").fetchone()[
            "cnt"
        ]
        enabled = conn.execute(
            "SELECT COUNT(*) AS cnt FROM autosync_jobs WHERE enabled = 1"
        ).fetchone()["cnt"]
        disabled = total - enabled
        last_check = conn.execute(
            "SELECT MAX(last_check) AS lc FROM autosync_jobs"
        ).fetchone()["lc"]
        last_new = conn.execute(
            "SELECT MAX(last_new_found) AS ln FROM autosync_jobs"
        ).fetchone()["ln"]
        total_eps = conn.execute(
            "SELECT COALESCE(SUM(episodes_found), 0) AS s FROM autosync_jobs"
        ).fetchone()["s"]
        jobs = conn.execute(
            "SELECT id, title, series_url, language, provider, enabled, "
            "last_check, last_new_found, episodes_found, added_by, created_at "
            "FROM autosync_jobs ORDER BY id"
        ).fetchall()
        return {
            "total_jobs": total,
            "enabled": enabled,
            "disabled": disabled,
            "last_check": last_check,
            "last_new_found": last_new,
            "total_episodes_found": total_eps,
            "jobs": [dict(r) for r in jobs],
        }
    finally:
        conn.close()


def get_queue_stats():
    conn = get_db()
    try:
        total = conn.execute("SELECT COUNT(*) AS cnt FROM download_queue").fetchone()[
            "cnt"
        ]
        by_status = {}
        for row in conn.execute(
            "SELECT status, COUNT(*) AS cnt FROM download_queue GROUP BY status"
        ).fetchall():
            by_status[row["status"]] = row["cnt"]
        running = conn.execute(
            "SELECT id, title, current_episode, total_episodes, language, provider, source "
            "FROM download_queue WHERE status = 'running' LIMIT 1"
        ).fetchone()
        if running:
            r = dict(running)
            cur = r.get("current_episode") or 0
            tot = r.get("total_episodes") or 0
            r["progress_percent"] = round(cur / tot * 100) if tot > 0 else 0
        else:
            r = None
        return {
            "total": total,
            "by_status": by_status,
            "currently_running": r,
        }
    finally:
        conn.close()


def get_general_stats():
    conn = get_db()
    try:
        total_downloads = conn.execute(
            "SELECT COUNT(*) AS cnt FROM download_queue "
            "WHERE status IN ('completed', 'failed')"
        ).fetchone()["cnt"]
        completed = conn.execute(
            "SELECT COUNT(*) AS cnt FROM download_queue WHERE status = 'completed'"
        ).fetchone()["cnt"]
        failed = conn.execute(
            "SELECT COUNT(*) AS cnt FROM download_queue WHERE status = 'failed'"
        ).fetchone()["cnt"]
        total_episodes = conn.execute(
            "SELECT COALESCE(SUM(total_episodes), 0) AS s FROM download_queue "
            "WHERE status = 'completed'"
        ).fetchone()["s"]
        last_24h = conn.execute(
            "SELECT COUNT(*) AS cnt FROM download_queue "
            "WHERE status = 'completed' "
            "AND completed_at >= datetime('now', '-1 day')"
        ).fetchone()["cnt"]
        # Average duration (completed items with both timestamps)
        avg_dur = conn.execute(
            "SELECT AVG("
            "  (julianday(completed_at) - julianday(created_at)) * 86400"
            ") AS avg_s FROM download_queue "
            "WHERE status = 'completed' AND completed_at IS NOT NULL"
        ).fetchone()["avg_s"]
        # Most downloaded titles
        top_titles = conn.execute(
            "SELECT title, COUNT(*) AS cnt FROM download_queue "
            "WHERE status = 'completed' GROUP BY title "
            "ORDER BY cnt DESC LIMIT 10"
        ).fetchall()
        # Episodes per language
        by_language = conn.execute(
            "SELECT language, COUNT(*) AS cnt, "
            "COALESCE(SUM(total_episodes), 0) AS eps "
            "FROM download_queue WHERE status = 'completed' "
            "GROUP BY language ORDER BY cnt DESC"
        ).fetchall()
        # Source breakdown (heuristic by URL)
        anime_count = conn.execute(
            "SELECT COUNT(*) AS cnt FROM download_queue "
            "WHERE status = 'completed' AND series_url LIKE '%aniworld.to%'"
        ).fetchone()["cnt"]
        anime_episodes = conn.execute(
            "SELECT COALESCE(SUM(total_episodes), 0) AS s FROM download_queue "
            "WHERE status = 'completed' AND series_url LIKE '%aniworld.to%'"
        ).fetchone()["s"]
        series_count = conn.execute(
            "SELECT COUNT(*) AS cnt FROM download_queue "
            "WHERE status = 'completed' AND series_url LIKE '%s.to%'"
        ).fetchone()["cnt"]
        series_episodes = conn.execute(
            "SELECT COALESCE(SUM(total_episodes), 0) AS s FROM download_queue "
            "WHERE status = 'completed' AND series_url LIKE '%s.to%'"
        ).fetchone()["s"]
        movie_count = conn.execute(
            "SELECT COUNT(*) AS cnt FROM download_queue "
            "WHERE status = 'completed' AND series_url LIKE '%filmpalast.to%'"
        ).fetchone()["cnt"]
        movie_episodes = conn.execute(
            "SELECT COALESCE(SUM(total_episodes), 0) AS s FROM download_queue "
            "WHERE status = 'completed' AND series_url LIKE '%filmpalast.to%'"
        ).fetchone()["s"]
        # Weekday activity (0=Sunday, 1=Monday, ...)
        weekday_rows = conn.execute(
            "SELECT strftime('%w', completed_at) as weekday, COUNT(*) as cnt "
            "FROM download_queue WHERE status = 'completed' AND completed_at IS NOT NULL "
            "GROUP BY weekday ORDER BY weekday"
        ).fetchall()
        weekday_activity = {r["weekday"]: r["cnt"] for r in weekday_rows}

        # Speed stats
        avg_speed = conn.execute(
            "SELECT AVG(average_speed_mbps) as avg_s FROM download_queue "
            "WHERE status = 'completed' AND average_speed_mbps IS NOT NULL"
        ).fetchone()["avg_s"]

        total_size = conn.execute(
            "SELECT SUM(total_size_mb) as s FROM download_queue "
            "WHERE status = 'completed' AND total_size_mb IS NOT NULL"
        ).fetchone()["s"]

        # Last 20 speeds for details modal
        last_speeds = conn.execute(
            "SELECT title, average_speed_mbps, total_size_mb, completed_at "
            "FROM download_queue WHERE status = 'completed' AND average_speed_mbps IS NOT NULL "
            "ORDER BY completed_at DESC LIMIT 20"
        ).fetchall()

        return {
            "total_downloads": total_downloads,
            "completed": completed,
            "failed": failed,
            "total_episodes": total_episodes,
            "last_24h_completed": last_24h,
            "average_duration_seconds": round(avg_dur, 1) if avg_dur else None,
            "weekday_activity": weekday_activity,
            "average_speed_mbps": round(avg_speed, 3) if avg_speed else None,
            "total_size_mb": round(total_size, 1) if total_size else 0.0,
            "last_speeds": [
                {
                    "title": r["title"],
                    "speed": round(r["average_speed_mbps"], 3),
                    "size": round(r["total_size_mb"], 2),
                    "date": r["completed_at"]
                } for r in last_speeds
            ],
            "top_titles": [
                {"title": r["title"], "count": r["cnt"]} for r in top_titles
            ],
            "by_language": [
                {"language": r["language"], "downloads": r["cnt"], "episodes": r["eps"]}
                for r in by_language
            ],
            "anime_downloads": anime_count,
            "anime_episodes": anime_episodes,
            "series_downloads": series_count,
            "series_episodes": series_episodes,
            "movie_downloads": movie_count,
            "movie_files": movie_episodes,
        }
    finally:
        conn.close()


# ===== Favourites =====

_CREATE_FAVOURITES_TABLE = """\
CREATE TABLE IF NOT EXISTS favourites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    series_url TEXT NOT NULL,
    title TEXT NOT NULL,
    poster_url TEXT,
    added_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(series_url, added_by)
);
"""


def init_favourites_db():
    ANIWORLD_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_db()
    try:
        conn.execute(_CREATE_FAVOURITES_TABLE)
        conn.commit()
    finally:
        conn.close()


def add_favourite(series_url: str, title: str, poster_url: str | None, added_by: str | None):
    conn = get_db()
    try:
        conn.execute(
            "INSERT OR IGNORE INTO favourites (series_url, title, poster_url, added_by) VALUES (?, ?, ?, ?)",
            (series_url, title, poster_url, added_by),
        )
        conn.commit()
    finally:
        conn.close()


def remove_favourite(series_url: str, added_by: str | None):
    conn = get_db()
    try:
        conn.execute(
            "DELETE FROM favourites WHERE series_url = ? AND (added_by = ? OR added_by IS NULL)",
            (series_url, added_by),
        )
        conn.commit()
    finally:
        conn.close()


def get_favourites(added_by: str | None = None):
    conn = get_db()
    try:
        if added_by:
            rows = conn.execute(
                "SELECT * FROM favourites WHERE added_by = ? ORDER BY created_at DESC",
                (added_by,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM favourites ORDER BY created_at DESC"
            ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def is_favourite(series_url: str, added_by: str | None) -> bool:
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT 1 FROM favourites WHERE series_url = ? AND (added_by = ? OR added_by IS NULL) LIMIT 1",
            (series_url, added_by),
        ).fetchone()
        return row is not None
    finally:
        conn.close()


# ============================================================
# Library cache
# ============================================================

def init_library_db():
    conn = get_db()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS library_cache (
                path_key  TEXT PRIMARY KEY,
                data      TEXT NOT NULL DEFAULT '[]',
                scanned_at REAL NOT NULL DEFAULT 0,
                is_scanning INTEGER NOT NULL DEFAULT 0
            )
        """)
        conn.commit()
    finally:
        conn.close()


def get_all_library_cache():
    import json as _json
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT path_key, data, scanned_at, is_scanning FROM library_cache"
        ).fetchall()
        return {
            r["path_key"]: {
                "data": _json.loads(r["data"]),
                "scanned_at": r["scanned_at"],
                "is_scanning": bool(r["is_scanning"]),
            }
            for r in rows
        }
    finally:
        conn.close()


def set_library_cache(path_key, data, scanned_at=None):
    import json as _json, time as _time
    conn = get_db()
    try:
        conn.execute(
            """INSERT INTO library_cache (path_key, data, scanned_at, is_scanning)
               VALUES (?, ?, ?, 0)
               ON CONFLICT(path_key) DO UPDATE SET
                   data       = excluded.data,
                   scanned_at = excluded.scanned_at,
                   is_scanning = 0""",
            (path_key, _json.dumps(data), scanned_at or _time.time()),
        )
        conn.commit()
    finally:
        conn.close()


def set_library_scanning(path_key, is_scanning: bool):
    conn = get_db()
    try:
        conn.execute(
            "UPDATE library_cache SET is_scanning=? WHERE path_key=?",
            (int(is_scanning), path_key),
        )
        if not conn.execute("SELECT changes()").fetchone()[0]:
            conn.execute(
                "INSERT INTO library_cache (path_key, data, scanned_at, is_scanning) VALUES (?, '[]', 0, ?)",
                (path_key, int(is_scanning)),
            )
        conn.commit()
    finally:
        conn.close()


def invalidate_library_cache():
    """Mark all cache entries as stale (scanned_at=0) so next call triggers a rescan."""
    conn = get_db()
    try:
        conn.execute("UPDATE library_cache SET scanned_at=0")
        conn.commit()
    finally:
        conn.close()


# ============================================================
# App settings (persistent key-value store)
# ============================================================

def init_app_settings_db():
    conn = get_db()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS app_settings (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        """)
        conn.commit()
    finally:
        conn.close()


def get_setting(key: str, default: str | None = None) -> str | None:
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT value FROM app_settings WHERE key = ?", (key,)
        ).fetchone()
        return row["value"] if row else default
    finally:
        conn.close()


def set_setting(key: str, value: str) -> None:
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO app_settings (key, value) VALUES (?, ?)"
            " ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )
        conn.commit()
    finally:
        conn.close()



def get_encoding_ffmpeg_opts():
    """Return dict with vcodec, acodec, vopts ready for ffmpeg.output() kwargs.

    Structure:
        {
            "vcodec": str | None,   # None means expert flags override via vopts
            "acodec": str | None,
            "vopts":  dict,         # extra encoder kwargs (preset, crf, etc.)
        }
    """
    import shlex

    def _parse_expert_flags(flags_str):
        """Parse '-c:v libx265 -preset slow -crf 18' -> dict for ffmpeg-python."""
        if not flags_str:
            return {}
        try:
            tokens = shlex.split(flags_str.strip())
        except Exception:
            return {}
        result = {}
        i = 0
        while i < len(tokens):
            t = tokens[i]
            if t.startswith("-"):
                key = t.lstrip("-")
                if i + 1 < len(tokens) and not tokens[i + 1].startswith("-"):
                    val = tokens[i + 1]
                    try:
                        val = int(val)
                    except ValueError:
                        try:
                            val = float(val)
                        except ValueError:
                            pass
                    result[key] = val
                    i += 2
                else:
                    i += 1
            else:
                i += 1
        return result

    mode = get_setting("encoding_mode", "copy") or "copy"

    if mode == "copy":
        audio = get_setting("encoding_audio_copy", "copy") or "copy"
        audio_map = {"copy": "copy", "aac": "aac", "ac3": "ac3"}
        acodec = audio_map.get(audio, "copy")
        return {"vcodec": "copy", "acodec": acodec, "vopts": {}}

    if mode in ("h264", "h265"):
        hw      = get_setting(f"encoding_hw_{mode}", "cpu") or "cpu"
        preset  = get_setting(f"encoding_preset_{mode}", "medium") or "medium"
        crf_def = "23" if mode == "h264" else "28"
        crf     = int(get_setting(f"encoding_crf_{mode}", crf_def) or crf_def)
        audio   = get_setting(f"encoding_audio_{mode}", "copy") or "copy"

        # Map hw + mode -> encoder name
        codec_map = {
            "h264": {
                "cpu":          "libx264",
                "nvenc":        "h264_nvenc",
                "vaapi":        "h264_vaapi",
                "videotoolbox": "h264_videotoolbox",
            },
            "h265": {
                "cpu":          "libx265",
                "nvenc":        "hevc_nvenc",
                "vaapi":        "hevc_vaapi",
                "videotoolbox": "hevc_videotoolbox",
            },
        }
        vcodec = codec_map[mode].get(hw, "libx264" if mode == "h264" else "libx265")

        # Encoder-specific quality options
        vopts = {}
        if hw == "nvenc":
            vopts["preset"] = preset
            vopts["rc"]     = "vbr"
            vopts["cq"]     = crf      # NVENC quality knob
        elif hw == "vaapi":
            vopts["vf"]             = "format=nv12,hwupload"
            vopts["global_quality"] = crf
        elif hw == "videotoolbox":
            pass  # VideoToolbox quality is controlled differently per stream
        else:
            # CPU (libx264 / libx265)
            vopts["preset"] = preset
            vopts["crf"]    = crf

        audio_map = {"copy": "copy", "aac": "aac", "ac3": "ac3"}
        acodec = audio_map.get(audio, "copy")
        return {"vcodec": vcodec, "acodec": acodec, "vopts": vopts}

    if mode == "expert":
        video_flags = get_setting("encoding_expert_video", "") or ""
        audio_flags = get_setting("encoding_expert_audio", "") or ""
        vparsed = _parse_expert_flags(video_flags)
        aparsed = _parse_expert_flags(audio_flags)
        # Extract vcodec/acodec from parsed flags if present
        vcodec = vparsed.pop("c:v", vparsed.pop("vcodec", "copy"))
        acodec = aparsed.pop("c:a", aparsed.pop("acodec", "copy"))
        # Merge remaining audio opts into vopts (prefix a: to scope them to audio stream)
        vopts = dict(vparsed)
        for k, v in aparsed.items():
            vopts[f"a:{k}"] = v
        return {"vcodec": vcodec, "acodec": acodec, "vopts": vopts}

    # Fallback
    return {"vcodec": "copy", "acodec": "copy", "vopts": {}}


def delete_setting(key: str) -> None:
    conn = get_db()
    try:
        conn.execute("DELETE FROM app_settings WHERE key = ?", (key,))
        conn.commit()
    finally:
        conn.close()


# ============================================================
# Notification tables: per-user prefs + push subscriptions
# ============================================================

_CREATE_USER_NOTIF_PREFS_TABLE = """\
CREATE TABLE IF NOT EXISTS user_notification_prefs (
    user_id INTEGER NOT NULL,
    key     TEXT    NOT NULL,
    value   TEXT    NOT NULL DEFAULT '',
    PRIMARY KEY (user_id, key),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
"""

_CREATE_PUSH_SUBSCRIPTIONS_TABLE = """\
CREATE TABLE IF NOT EXISTS push_subscriptions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    endpoint   TEXT    NOT NULL UNIQUE,
    user_id    INTEGER,
    auth       TEXT    NOT NULL,
    p256dh     TEXT    NOT NULL,
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);
"""


def init_notification_db() -> None:
    """Create notification tables and migrate legacy JSON subscription file."""
    ANIWORLD_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_db()
    try:
        conn.execute(_CREATE_USER_NOTIF_PREFS_TABLE)
        conn.execute(_CREATE_PUSH_SUBSCRIPTIONS_TABLE)
        conn.commit()
    finally:
        conn.close()

    # One-time migration: import legacy push_subscriptions.json into DB
    import json as _json
    legacy = ANIWORLD_CONFIG_DIR / "push_subscriptions.json"
    if legacy.exists():
        try:
            data = _json.loads(legacy.read_text())
            if isinstance(data, list):
                for sub in data:
                    ep     = sub.get("endpoint", "")
                    keys   = sub.get("keys", {})
                    auth   = keys.get("auth", "")
                    p256dh = keys.get("p256dh", "")
                    if ep and auth and p256dh:
                        db_add_push_subscription(ep, auth, p256dh)
            legacy.rename(legacy.with_suffix(".json.migrated"))
            logger.info("[DB] Migrated %d push subscription(s) from legacy JSON", len(data))
        except Exception as exc:
            logger.warning("[DB] Push subscription migration failed: %s", exc)

    # One-time migration: retire legacy push_prefs.json (prefs now live in DB)
    legacy_prefs = ANIWORLD_CONFIG_DIR / "push_prefs.json"
    if legacy_prefs.exists():
        try:
            legacy_prefs.rename(legacy_prefs.with_suffix(".json.migrated"))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# User notification preferences
# ---------------------------------------------------------------------------

def get_user_id_by_username(username: str) -> "int | None":
    if not username:
        return None
    # In no-auth mode there is no users table — return 0 (pseudo-user)
    if username == "admin":
        conn = get_db()
        try:
            conn.execute("SELECT 1 FROM users LIMIT 1")
        except Exception:
            conn.close()
            return 0  # no-auth pseudo-user
        conn.close()
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT id FROM users WHERE username = ?", (username,)
        ).fetchone()
        return row["id"] if row else None
    except Exception:
        return None
    finally:
        conn.close()


def get_user_notif_pref(user_id: int, key: str, default: str = "") -> str:
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT value FROM user_notification_prefs WHERE user_id = ? AND key = ?",
            (user_id, key),
        ).fetchone()
        return row["value"] if row else default
    finally:
        conn.close()


def get_user_notif_prefs_all(user_id: int) -> dict:
    """Return all notification prefs for *user_id* as a plain dict."""
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT key, value FROM user_notification_prefs WHERE user_id = ?",
            (user_id,),
        ).fetchall()
        return {r["key"]: r["value"] for r in rows}
    finally:
        conn.close()


def set_user_notif_pref(user_id: int, key: str, value: str) -> None:
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO user_notification_prefs (user_id, key, value) VALUES (?, ?, ?)"
            " ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value",
            (user_id, key, str(value)),
        )
        conn.commit()
    finally:
        conn.close()


def set_user_notif_prefs_bulk(user_id: int, prefs: dict) -> None:
    """Upsert multiple preference keys at once for *user_id*."""
    if not prefs:
        return
    conn = get_db()
    try:
        for key, value in prefs.items():
            conn.execute(
                "INSERT INTO user_notification_prefs (user_id, key, value) VALUES (?, ?, ?)"
                " ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value",
                (user_id, key, str(value)),
            )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Push subscriptions (DB-backed)
# ---------------------------------------------------------------------------

def db_add_push_subscription(
    endpoint: str, auth: str, p256dh: str, user_id: "int | None" = None
) -> None:
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO push_subscriptions (endpoint, user_id, auth, p256dh) VALUES (?, ?, ?, ?)"
            " ON CONFLICT(endpoint) DO UPDATE SET"
            "   user_id = excluded.user_id,"
            "   auth    = excluded.auth,"
            "   p256dh  = excluded.p256dh",
            (endpoint, user_id, auth, p256dh),
        )
        conn.commit()
    finally:
        conn.close()



def db_remove_push_subscription(endpoint):
    conn = get_db()
    try:
        conn.execute("DELETE FROM push_subscriptions WHERE endpoint = ?", (endpoint,))
        conn.commit()
    finally:
        conn.close()


def db_get_push_subscriptions(user_id=None):
    conn = get_db()
    try:
        if user_id is not None:
            rows = conn.execute(
                "SELECT endpoint, user_id, auth, p256dh FROM push_subscriptions WHERE user_id = ?",
                (user_id,),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT endpoint, user_id, auth, p256dh FROM push_subscriptions"
            ).fetchall()
        return [
            {
                "endpoint": r["endpoint"],
                "user_id":  r["user_id"],
                "keys":     {"auth": r["auth"], "p256dh": r["p256dh"]},
            }
            for r in rows
        ]
    finally:
        conn.close()


# ============================================================
# TMDB / CineInfo result cache (persistent, 24 h TTL)
# ============================================================

def init_tmdb_cache_db() -> None:
    conn = get_db()
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS tmdb_cache (
                cache_key  TEXT    PRIMARY KEY,
                data_json  TEXT    NOT NULL,
                cached_at  REAL    NOT NULL
            )
            """
        )
        conn.commit()
    finally:
        conn.close()


def get_tmdb_cache(cache_key: str, ttl: float = 86400.0) -> "dict | None":
    """Return cached TMDB data if it exists and is within TTL, else None."""
    import time as _time
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT data_json, cached_at FROM tmdb_cache WHERE cache_key = ?",
            (cache_key,),
        ).fetchone()
        if row and (_time.time() - row["cached_at"]) < ttl:
            import json as _json
            return _json.loads(row["data_json"])
        return None
    finally:
        conn.close()


def get_tmdb_cache_bulk(cache_keys: list, ttl: float = 86400.0) -> dict:
    """Return dict mapping cache_key -> parsed JSON data for keys within TTL."""
    if not cache_keys:
        return {}
    import time as _time
    import json as _json
    conn = get_db()
    try:
        placeholders = ",".join("?" for _ in cache_keys)
        rows = conn.execute(
            f"SELECT cache_key, data_json, cached_at FROM tmdb_cache WHERE cache_key IN ({placeholders})",
            cache_keys,
        ).fetchall()
        out = {}
        now = _time.time()
        for row in rows:
            if (now - row["cached_at"]) < ttl:
                try:
                    out[row["cache_key"]] = _json.loads(row["data_json"])
                except Exception:
                    pass
        return out
    finally:
        conn.close()


def set_tmdb_cache(cache_key: str, data: dict) -> None:
    """Persist a TMDB result. Upserts so repeated calls refresh the TTL."""
    import json as _json
    import time as _time
    conn = get_db()
    try:
        conn.execute(
            """
            INSERT INTO tmdb_cache (cache_key, data_json, cached_at)
            VALUES (?, ?, ?)
            ON CONFLICT(cache_key) DO UPDATE SET
                data_json = excluded.data_json,
                cached_at = excluded.cached_at
            """,
            (cache_key, _json.dumps(data, ensure_ascii=False), _time.time()),
        )
        conn.commit()
    finally:
        conn.close()


def clear_tmdb_cache() -> None:
    """Wipe all cached TMDB entries (e.g. after API-key change)."""
    conn = get_db()
    try:
        conn.execute("DELETE FROM tmdb_cache")
        conn.commit()
    finally:
        conn.close()


# ===========================================================================
# Upscale Queue
# ===========================================================================

_CREATE_UPSCALE_QUEUE_TABLE = """
CREATE TABLE IF NOT EXISTS upscale_queue (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    title            TEXT    NOT NULL,
    file_path        TEXT    NOT NULL,
    output_path      TEXT,
    files            TEXT,
    total_files      INTEGER NOT NULL DEFAULT 1,
    current_file_idx INTEGER NOT NULL DEFAULT 0,
    status           TEXT    NOT NULL DEFAULT 'queued'
                         CHECK(status IN ('queued','running','completed','failed','cancelled')),
    progress_pct     REAL    NOT NULL DEFAULT 0.0,
    error            TEXT,
    source           TEXT    NOT NULL DEFAULT 'manual',
    created_at       TEXT    NOT NULL DEFAULT (datetime('now')),
    completed_at     TEXT,
    position         INTEGER NOT NULL DEFAULT 0
);
"""


def init_upscale_queue_db():
    ANIWORLD_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_db()
    try:
        conn.execute(_CREATE_UPSCALE_QUEUE_TABLE)
        # Migrate existing DBs: add new columns if missing
        for col, definition in [
            ("files",            "TEXT"),
            ("total_files",      "INTEGER NOT NULL DEFAULT 1"),
            ("current_file_idx", "INTEGER NOT NULL DEFAULT 0"),
            ("position",         "INTEGER NOT NULL DEFAULT 0"),
        ]:
            try:
                conn.execute(f"ALTER TABLE upscale_queue ADD COLUMN {col} {definition}")
            except Exception:
                pass  # column already exists
        # Backfill position = id for rows that still have 0
        conn.execute("UPDATE upscale_queue SET position = id WHERE position = 0")
        conn.commit()
    finally:
        conn.close()


def add_to_upscale_queue(title, file_path, output_path=None, source="manual", files=None):
    """Add one upscale job.
    files: list of {file_path, output_path} for multi-file (batch) jobs.
    When files is set, file_path/output_path are taken from files[0].
    """
    import json as _json
    conn = get_db()
    try:
        if files:
            fp  = files[0]["file_path"]
            out = files[0].get("output_path") or fp
            files_json = _json.dumps(files)
            total = len(files)
        else:
            fp  = str(file_path)
            out = str(output_path) if output_path else fp
            files_json = None
            total = 1
        cur = conn.execute(
            "INSERT INTO upscale_queue (title, file_path, output_path, files, total_files, source) VALUES (?, ?, ?, ?, ?, ?)",
            (title, fp, out, files_json, total, source),
        )
        new_id = cur.lastrowid
        conn.execute("UPDATE upscale_queue SET position = ? WHERE id = ?", (new_id, new_id))
        conn.commit()
        return new_id
    finally:
        conn.close()


def get_upscale_queue():
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM upscale_queue ORDER BY position ASC, id ASC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_upscale_item(item_id):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM upscale_queue WHERE id = ?", (item_id,)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_next_upscale_queued():
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM upscale_queue WHERE status = 'queued' ORDER BY position ASC, id ASC LIMIT 1"
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_upscale_running():
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM upscale_queue WHERE status = 'running' LIMIT 1"
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def set_upscale_status(item_id, status):
    conn = get_db()
    try:
        if status in ("completed", "failed"):
            conn.execute(
                "UPDATE upscale_queue SET status = ?, completed_at = datetime('now') WHERE id = ?",
                (status, item_id),
            )
        else:
            conn.execute(
                "UPDATE upscale_queue SET status = ? WHERE id = ?",
                (status, item_id),
            )
        conn.commit()
    finally:
        conn.close()


def update_upscale_progress(item_id, progress_pct, current_file_idx=None):
    conn = get_db()
    try:
        if current_file_idx is not None:
            conn.execute(
                "UPDATE upscale_queue SET progress_pct = ?, current_file_idx = ? WHERE id = ?",
                (round(float(progress_pct), 1), current_file_idx, item_id),
            )
        else:
            conn.execute(
                "UPDATE upscale_queue SET progress_pct = ? WHERE id = ?",
                (round(float(progress_pct), 1), item_id),
            )
        conn.commit()
    finally:
        conn.close()


def set_upscale_error(item_id, error_msg):
    conn = get_db()
    try:
        conn.execute(
            "UPDATE upscale_queue SET error = ? WHERE id = ?",
            (str(error_msg), item_id),
        )
        conn.commit()
    finally:
        conn.close()


def remove_from_upscale_queue(item_id):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT status FROM upscale_queue WHERE id = ?", (item_id,)
        ).fetchone()
        if not row:
            return False, "Item not found"
        if row["status"] == "running":
            return False, "Cannot remove a running item (cancel it first)"
        conn.execute("DELETE FROM upscale_queue WHERE id = ?", (item_id,))
        conn.commit()
        return True, None
    finally:
        conn.close()


def cancel_upscale_item(item_id):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT status FROM upscale_queue WHERE id = ?", (item_id,)
        ).fetchone()
        if not row:
            return False, "Item not found"
        if row["status"] not in ("running", "queued"):
            return False, "Can only cancel queued or running items"
        conn.execute(
            "UPDATE upscale_queue SET status = 'cancelled' WHERE id = ?", (item_id,)
        )
        conn.commit()
        return True, None
    finally:
        conn.close()


def is_upscale_cancelled(item_id):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT status FROM upscale_queue WHERE id = ?", (item_id,)
        ).fetchone()
        return row and row["status"] == "cancelled"
    finally:
        conn.close()


def clear_upscale_completed():
    conn = get_db()
    try:
        conn.execute(
            "DELETE FROM upscale_queue WHERE status IN ('completed', 'failed', 'cancelled')"
        )
        conn.commit()
    finally:
        conn.close()


def get_upscale_badge_count():
    """Return number of queued + running upscale items (for sidebar badge)."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT COUNT(*) AS cnt FROM upscale_queue WHERE status IN ('queued', 'running')"
        ).fetchone()
        return row["cnt"] if row else 0
    finally:
        conn.close()


def move_upscale_queue_item(item_id, direction):
    """Swap position of a queued upscale item with its neighbor."""
    conn = get_db()
    try:
        item = conn.execute(
            "SELECT id, position FROM upscale_queue WHERE id = ? AND status = 'queued'",
            (item_id,),
        ).fetchone()
        if not item:
            return False, "Item not found or not queued"
        if direction == "up":
            neighbor = conn.execute(
                "SELECT id, position FROM upscale_queue "
                "WHERE status = 'queued' AND position < ? "
                "ORDER BY position DESC LIMIT 1",
                (item["position"],),
            ).fetchone()
        else:
            neighbor = conn.execute(
                "SELECT id, position FROM upscale_queue "
                "WHERE status = 'queued' AND position > ? "
                "ORDER BY position ASC LIMIT 1",
                (item["position"],),
            ).fetchone()
        if not neighbor:
            return False, "Already at edge"
        conn.execute("UPDATE upscale_queue SET position = ? WHERE id = ?", (neighbor["position"], item["id"]))
        conn.execute("UPDATE upscale_queue SET position = ? WHERE id = ?", (item["position"], neighbor["id"]))
        conn.commit()
        return True, None
    finally:
        conn.close()


def reset_running_upscale_items():
    """On startup: reset any stuck 'running' items back to 'queued'."""
    conn = get_db()
    try:
        conn.execute(
            "UPDATE upscale_queue SET status = 'queued', progress_pct = 0 WHERE status = 'running'"
        )
        conn.commit()
    finally:
        conn.close()


# ============================================================
# Browse list cache (persistent, survives restart)
# ============================================================

def init_browse_cache_db() -> None:
    conn = get_db()
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS browse_cache (
                cache_key  TEXT    PRIMARY KEY,
                data_json  TEXT    NOT NULL,
                cached_at  REAL    NOT NULL
            )
            """
        )
        conn.commit()
    finally:
        conn.close()


def get_browse_cache_stale(cache_key: str) -> "tuple | None":
    """Return (data_list, cached_at) regardless of TTL — for stale-while-revalidate."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT data_json, cached_at FROM browse_cache WHERE cache_key = ?",
            (cache_key,),
        ).fetchone()
        if row:
            import json as _json
            return (_json.loads(row["data_json"]), row["cached_at"])
        return None
    finally:
        conn.close()


def set_browse_cache(cache_key: str, data: list) -> None:
    """Persist browse results. Upserts to refresh the timestamp."""
    import json as _json
    import time as _time
    conn = get_db()
    try:
        conn.execute(
            """
            INSERT INTO browse_cache (cache_key, data_json, cached_at)
            VALUES (?, ?, ?)
            ON CONFLICT(cache_key) DO UPDATE SET
                data_json = excluded.data_json,
                cached_at = excluded.cached_at
            """,
            (cache_key, _json.dumps(data, ensure_ascii=False), _time.time()),
        )
        conn.commit()
    finally:
        conn.close()


# ─────────────────────────────────────────────────────────────────────────────
#  MediaScan cache
# ─────────────────────────────────────────────────────────────────────────────

def init_mediascan_db() -> None:
    """Create the mediascan_cache table if it does not exist yet."""
    conn = get_db()
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS mediascan_cache (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                tmdb_id    TEXT,
                imdb_id    TEXT,
                tvdb_id    TEXT,
                title      TEXT,
                media_type TEXT,
                updated_at REAL NOT NULL
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_mediascan_tmdb ON mediascan_cache (tmdb_id)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_mediascan_imdb ON mediascan_cache (imdb_id)"
        )
        conn.commit()
    finally:
        conn.close()


def replace_mediascan_cache(entries: list) -> None:
    """
    Atomically replace the entire mediascan_cache with *entries*.
    Each entry is a dict with keys: tmdb_id, imdb_id, tvdb_id, title, media_type.
    """
    import time as _time
    now = _time.time()
    conn = get_db()
    try:
        conn.execute("DELETE FROM mediascan_cache")
        conn.executemany(
            """
            INSERT INTO mediascan_cache (tmdb_id, imdb_id, tvdb_id, title, media_type, updated_at)
            VALUES (:tmdb_id, :imdb_id, :tvdb_id, :title, :media_type, :updated_at)
            """,
            [
                {
                    "tmdb_id":    str(e.get("tmdb_id") or "").strip() or None,
                    "imdb_id":    str(e.get("imdb_id") or "").strip() or None,
                    "tvdb_id":    str(e.get("tvdb_id") or "").strip() or None,
                    "title":      str(e.get("title") or "").strip() or None,
                    "media_type": str(e.get("media_type") or "").strip() or None,
                    "updated_at": now,
                }
                for e in entries
            ],
        )
        conn.commit()
    finally:
        conn.close()


def get_mediascan_ids() -> dict:
    """Return sets of tmdb_ids, imdb_ids and normalised titles from the mediascan cache."""
    import re as _re
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT tmdb_id, imdb_id, title FROM mediascan_cache"
        ).fetchall()
        tmdb_ids = {r["tmdb_id"] for r in rows if r["tmdb_id"]}
        imdb_ids = {r["imdb_id"] for r in rows if r["imdb_id"]}
        # Normalise titles for fuzzy front-end matching:
        # lowercase, strip year/season suffixes, collapse whitespace
        def _norm(t):
            t = (t or "").lower()
            t = _re.sub(r"\s*\(\d{4}\)\s*$", "", t)   # (2013)
            t = _re.sub(r"\s*:?\s*season\s+\d+\s*$", "", t)
            t = _re.sub(r"\s*:?\s*staffel\s+\d+\s*$", "", t)
            t = _re.sub(r"\s*:?\s*part\s+\d+\s*$", "", t)
            t = _re.sub(r"[^\w\s]", "", t)               # strip punctuation
            return " ".join(t.split())
        titles = {_norm(r["title"]) for r in rows if r["title"]}
        titles.discard("")  # remove empty strings
        return {"tmdb_ids": list(tmdb_ids), "imdb_ids": list(imdb_ids), "titles": list(titles)}
    finally:
        conn.close()


def get_mediascan_count() -> int:
    """Return the number of entries in the mediascan cache."""
    conn = get_db()
    try:
        row = conn.execute("SELECT COUNT(*) AS n FROM mediascan_cache").fetchone()
        return row["n"] if row else 0
    finally:
        conn.close()


def get_mediascan_last_updated() -> "float | None":
    """Return the most recent updated_at timestamp, or None if cache is empty."""
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT MAX(updated_at) AS ts FROM mediascan_cache"
        ).fetchone()
        return row["ts"] if row and row["ts"] else None
    finally:
        conn.close()


def clear_mediascan_cache() -> None:
    """Wipe all mediascan entries."""
    conn = get_db()
    try:
        conn.execute("DELETE FROM mediascan_cache")
        conn.commit()
    finally:
        conn.close()
