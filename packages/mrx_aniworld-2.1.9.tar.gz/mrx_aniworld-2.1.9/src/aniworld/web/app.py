import json
import re
import secrets
import struct
import threading

# Registry of active cancel events keyed by queue item ID.
# Allows api_queue_cancel to kill the active subprocess immediately.
_active_cancel_events: dict = {}
_active_cancel_events_lock = threading.Lock()
import time
import zlib
import os
from html import unescape as _html_unescape
from datetime import datetime, timedelta

from flask import Flask, jsonify, redirect, render_template, request, url_for
from flask_wtf.csrf import CSRFError, CSRFProtect

from ..config import ANIWORLD_CONFIG_DIR, INVERSE_LANG_LABELS, LANG_KEY_MAP, LANG_LABELS, SUPPORTED_PROVIDERS
from ..extractors import provider_functions
from ..logger import get_logger
from ..providers import resolve_provider
from ..search import (
    fetch_new_animes,
    fetch_new_series,
    fetch_popular_animes,
    fetch_popular_series,
    query_s_to,
    random_anime,
)
from ..search import query as aniworld_query
from .db import (
    add_autosync_job,
    add_custom_path,
    add_to_queue,
    cancel_queue_item,
    clear_captcha_url,
    clear_completed,
    delete_completed_queue_item,
    find_autosync_by_url,
    get_autosync_job,
    get_autosync_jobs,
    get_custom_path_by_id,
    get_custom_paths,
    get_general_stats,
    get_next_queued,
    get_queue,
    get_queue_item,
    get_queue_stats,
    get_running,
    get_sync_stats,
    init_autosync_db,
    add_favourite,
    remove_favourite,
    get_favourites,
    is_favourite,
    init_favourites_db,
    init_custom_paths_db,
    init_queue_db,
    init_library_db,
    get_all_library_cache,
    set_library_cache,
    set_library_scanning,
    invalidate_library_cache,
    is_queue_cancelled,
    is_series_queued_or_running,
    move_queue_item,
    remove_autosync_job,
    remove_custom_path,
    is_custom_path_in_use,
    remove_from_queue,
    restart_queue_item_inplace,
    retry_single_episode,
    set_captcha_url,
    set_queue_status,
    update_autosync_job,
    update_queue_errors,
    update_queue_progress,
    update_queue_stats,
    init_app_settings_db,
    get_setting,
    set_setting,
    delete_setting,
    init_tmdb_cache_db,
    get_tmdb_cache,
    get_tmdb_cache_bulk,
    set_tmdb_cache,
    clear_tmdb_cache,
    init_browse_cache_db,
    get_browse_cache_stale,
    set_browse_cache,
    init_notification_db,
    get_user_id_by_username,
    get_user_notif_prefs_all,
    set_user_notif_prefs_bulk,
    db_add_push_subscription,
    db_remove_push_subscription,
    # upscale queue
    add_to_upscale_queue,
    get_upscale_queue,
    get_upscale_item,
    get_next_upscale_queued,
    get_upscale_running,
    set_upscale_status,
    update_upscale_progress,
    set_upscale_error,
    remove_from_upscale_queue,
    cancel_upscale_item,
    is_upscale_cancelled,
    clear_upscale_completed,
    get_upscale_badge_count,
    reset_running_upscale_items,
    init_upscale_queue_db,
    # mediascan
    init_mediascan_db,
    replace_mediascan_cache,
    get_mediascan_ids,
    get_mediascan_count,
    get_mediascan_last_updated,
    clear_mediascan_cache,
)

logger = get_logger(__name__)


def _get_working_providers():
    """Return only providers whose extractors are actually implemented.

    Each extractor is probed with an empty URL string.  If it raises
    NotImplementedError the provider is considered not yet implemented and is
    skipped.  Any other exception means the extractor *is* implemented (it just
    rejected the empty URL as expected).  Logging is silenced during the probe
    so that the intentional empty-URL errors don't spam the terminal on startup.
    """
    import logging as _logging
    working = []
    for p in SUPPORTED_PROVIDERS:
        func_name = f"get_direct_link_from_{p.lower()}"
        if func_name not in provider_functions:
            continue
        _logging.disable(_logging.CRITICAL)  # suppress expected empty-URL errors
        try:
            provider_functions[func_name]("")
        except NotImplementedError:
            continue
        except Exception:
            working.append(p)
        finally:
            _logging.disable(_logging.NOTSET)  # restore normal logging
    return tuple(working)


WORKING_PROVIDERS = _get_working_providers()

# Only match series-level links: /anime/stream/<slug> (no season/episode)
_SERIES_LINK_PATTERN = re.compile(r"^/anime/stream/[a-zA-Z0-9\-]+/?$", re.IGNORECASE)

# Only match s.to series-level links: /serie/<slug> (no season/episode)
_STO_SERIES_LINK_PATTERN = re.compile(
    r"^/serie/(stream/)?[a-zA-Z0-9\-]+/?$", re.IGNORECASE
)


# ---- DNS resolver patch ----

import socket as _socket
import ipaddress as _ipaddress

_DNS_PRESETS = {
    "cloudflare": "1.1.1.1",
    "google":     "8.8.8.8",
    "quad9":      "9.9.9.9",
}

# Map preset names to niquests DoH resolver URLs.
# niquests uses these to resolve DNS over HTTPS directly, bypassing the OS
# resolver entirely — which is why socket.getaddrinfo patching alone doesn't
# affect niquests requests.
_DNS_NIQUESTS_MAP = {
    "cloudflare": ["doh+cloudflare://"],
    "google":     ["doh+google://"],
    "quad9":      ["doh://9.9.9.9/dns-query"],
}

_original_getaddrinfo = _socket.getaddrinfo
_active_dns_server: str | None = None


def _apply_dns_patch(server_ip: str | None, mode: str | None = None) -> None:
    """
    Apply DNS routing for the given mode/server_ip.

    Two layers are updated together:
      1. socket.getaddrinfo patch (covers stdlib HTTP, ffmpeg subprocesses, etc.)
      2. GLOBAL_SESSION niquests rebuild (covers all niquests HTTP requests)

    Args:
        server_ip: IP address for the socket patch, or None to restore system DNS.
        mode:      Preset name ("cloudflare", "google", "quad9") used to pick the
                   matching DoH URL for niquests.  For "custom" mode only the socket
                   patch is applied (no DoH URL available).  Pass None or "system"
                   to reset everything to defaults.
    """
    from ..config import rebuild_global_session

    global _active_dns_server

    if not server_ip:
        # Restore system DNS
        _socket.getaddrinfo = _original_getaddrinfo
        _active_dns_server = None
        rebuild_global_session(None)  # back to default Google DoH
        return

    try:
        import dns.resolver as _dns_resolver  # type: ignore[import-untyped]
    except ImportError:
        logger.warning("dnspython not installed — custom DNS not available")
        return

    _active_dns_server = server_ip

    def _patched_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):  # noqa: A002
        # Don't try to resolve bare IPs or empty strings
        is_ip = False
        if host:
            try:
                _ipaddress.ip_address(host)
                is_ip = True
            except ValueError:
                pass
        if not is_ip and host:
            try:
                res = _dns_resolver.Resolver(configure=False)
                res.nameservers = [server_ip]
                res.timeout = 3
                res.lifetime = 5
                answers = res.resolve(host, "A")
                resolved = str(answers[0])
                return _original_getaddrinfo(resolved, port, family, type, proto, flags)
            except Exception:
                pass  # fall back to system DNS on any error
        return _original_getaddrinfo(host, port, family, type, proto, flags)

    _socket.getaddrinfo = _patched_getaddrinfo

    # Also rebuild the niquests GLOBAL_SESSION with the matching DoH resolver.
    # For presets we have a known DoH URL; for "custom" IPs we can't build a
    # DoH URL so we keep the default Google DoH (socket patch still applies).
    doh_urls = _DNS_NIQUESTS_MAP.get(mode) if mode else None
    rebuild_global_session(doh_urls)


# Queue worker state
_queue_worker_started = False
_queue_lock = threading.Lock()

# Global pause flag — when True the worker waits after finishing the current episode.
# Persisted in app_settings DB so it survives restarts.
_queue_paused = False
_queue_pause_lock = threading.Lock()

# Per-job skip-episode flag — worker checks this after each download attempt.
# When set for a job ID, the current episode is silently skipped (no error recorded).
_skip_episode_ids: set = set()
_skip_episode_lock = threading.Lock()



def is_episode_skip_requested(queue_id: int) -> bool:
    with _skip_episode_lock:
        return queue_id in _skip_episode_ids


def request_episode_skip(queue_id: int):
    with _skip_episode_lock:
        _skip_episode_ids.add(queue_id)


def consume_episode_skip(queue_id: int) -> bool:
    """Return True and clear the flag if a skip was requested, else False."""
    with _skip_episode_lock:
        if queue_id in _skip_episode_ids:
            _skip_episode_ids.discard(queue_id)
            return True
        return False


def _load_queue_paused_from_db() -> None:
    """Read persisted pause state from DB into the in-memory flag."""
    global _queue_paused
    try:
        val = get_setting("queue_paused", "0")
        with _queue_pause_lock:
            _queue_paused = val == "1"
    except Exception:
        pass  # DB not ready yet — keep default False


def is_queue_paused():
    with _queue_pause_lock:
        return _queue_paused


def set_queue_paused(paused: bool):
    global _queue_paused
    with _queue_pause_lock:
        _queue_paused = paused
    try:
        set_setting("queue_paused", "1" if paused else "0")
    except Exception:
        pass  # non-fatal — in-memory state is still correct

# Auto-sync worker state
_autosync_worker_started = False

# Track jobs currently being synced to prevent duplicate runs
_syncing_jobs = set()
_syncing_jobs_lock = threading.Lock()

# Upscale worker state
_upscale_worker_started = False
_upscale_active_cancel_events: dict = {}
_upscale_cancel_lock = threading.Lock()

# Library move job tracking
_move_jobs: dict = {}  # job_id -> {status, copied_bytes, total_bytes, current_file, error}
_move_jobs_lock = threading.Lock()

# Schedule intervals in seconds
SYNC_SCHEDULE_MAP = {
    "1min": 60,
    "30min": 1800,
    "1h": 3600,
    "2h": 7200,
    "4h": 14400,
    "8h": 28800,
    "12h": 43200,
    "16h": 57600,
    "24h": 86400,
}

# Retry delay map
SYNC_RETRY_MAP = {
    "0min": 0,
    "1min": 60,
    "2min": 120,
    "3min": 180,
    "4min": 240,
    "5min": 300,
}



_last_disk_notif_time: "float" = 0.0  # debounce: max once per hour per run


def _check_disk_space_and_notify(username: str | None = None, check_path: str | None = None) -> bool:
    """Check free disk space against the configured minimum.

    Returns True when space is OK, False when below threshold.
    Sends a notification (at most once per hour per process lifetime).
    check_path: path to check (custom download path or default).
    """
    import shutil
    import time as _time

    global _last_disk_notif_time

    raw_gb = None
    try:
        from .db import get_setting as _gs
        raw_gb = _gs("notif_disk_space_min_gb")
    except Exception:
        pass
    try:
        min_gb = float(raw_gb) if raw_gb else 5.0
    except (TypeError, ValueError):
        min_gb = 5.0

    if min_gb <= 0:
        return True  # feature disabled

    try:
        dl_path = check_path or os.environ.get("ANIWORLD_DOWNLOAD_PATH", "") or str(Path.home() / "Downloads")
        usage = shutil.disk_usage(dl_path)
        free_gb = usage.free / (1024 ** 3)
    except Exception:
        return True  # can't determine → don't block

    if free_gb >= min_gb:
        return True

    # Only notify once per hour
    now = _time.time()
    if now - _last_disk_notif_time < 3600:
        return False
    _last_disk_notif_time = now

    try:
        from .notifications import notify_all
        notify_all(
            title="⚠️ Speicherplatz niedrig",
            body=f"Nur noch {free_gb:.1f} GB frei (Limit: {min_gb:.0f} GB). Download wird trotzdem gestartet.",
            event="on_disk_space_low",
            username=username,
        )
    except Exception:
        pass
    return False



def _normalize_media_url(raw: str) -> str:
    """Ensure a media-server URL has an http(s):// scheme."""
    raw = (raw or "").strip().rstrip("/")
    if raw and not raw.startswith(("http://", "https://")):
        raw = "http://" + raw
    return raw

# ─────────────────────────────────────────────────────────────────────────────
#  MediaScan — persistent scan-status (survives page navigation)
# ─────────────────────────────────────────────────────────────────────────────

_mediascan_status: dict = {
    "running":      False,
    "started_at":   None,   # float epoch
    "finished_at":  None,   # float epoch
    "count":        0,
    "total":        0,
    "error":        None,
    "source":       "",     # "plex" | "jellyfin"
}
_mediascan_status_lock = threading.Lock()

# Timer handle for the post-download delayed refresh
_mediascan_delay_timer: threading.Timer | None = None
_mediascan_delay_lock  = threading.Lock()

# 24-h scheduler
_mediascan_scheduler_thread: threading.Thread | None = None
_mediascan_scheduler_stop   = threading.Event()


def _mediascan_get_credentials() -> dict:
    """
    Return credentials for MediaScan from its own settings keys.
    The Plex token (mediaplayer_apikey) is the only shared field — one OAuth
    login works for both MediaPlayer and MediaScan.
    """
    source   = get_setting("mediascan_source", "") or ""
    jf_url   = _normalize_media_url(get_setting("mediascan_jf_url",   "") or "")
    jf_key   = get_setting("mediascan_jf_apikey", "") or ""
    plex_url = _normalize_media_url(get_setting("mediascan_plex_url", "") or "")
    plex_key = get_setting("mediaplayer_apikey", "") or ""  # shared Plex token
    return {
        "svc":      source,
        "jf_url":   jf_url,
        "jf_key":   jf_key,
        "plex_url": plex_url,
        "plex_key": plex_key,
    }


def _mediascan_fetch_jellyfin(jf_url: str, jf_key: str) -> list:
    """Fetch all TV-shows and movies from Jellyfin and return normalised entries."""
    import urllib.request as _req
    import json as _json

    entries = []
    for item_type in ("Series", "Movie"):
        url = (
            f"{jf_url}/Items"
            f"?Recursive=true"
            f"&IncludeItemTypes={item_type}"
            f"&fields=ProviderIds,Name"
            f"&Limit=5000"
            f"&api_key={jf_key}"
        )
        try:
            with _req.urlopen(url, timeout=30) as r:
                data = _json.loads(r.read())
            for item in data.get("Items") or []:
                pids = item.get("ProviderIds") or {}
                entries.append({
                    "tmdb_id":    str(pids.get("Tmdb") or "").strip() or None,
                    "imdb_id":    str(pids.get("Imdb") or "").strip() or None,
                    "tvdb_id":    str(pids.get("Tvdb") or "").strip() or None,
                    "title":      item.get("Name") or "",
                    "media_type": "show" if item_type == "Series" else "movie",
                })
        except Exception as exc:
            logger.warning("[MediaScan] Jellyfin fetch failed for %s: %s", item_type, exc)
    return entries


def _mediascan_parse_plex_guid(guid_str: str) -> tuple:
    """
    Parse a Plex GUID string into (source, id).

    Handles two formats:
    - New Plex agents (Guid array items):  "tmdb://12345", "imdb://tt123", "tvdb://456"
    - Old Plex agents (item.guid field):   "com.plexapp.agents.thetvdb://12345/1/1?lang=en"
                                           "com.plexapp.agents.imdb://tt1234567?lang=en"
                                           "com.plexapp.agents.themoviedb://12345?lang=en"
    Returns ("tmdb"|"imdb"|"tvdb"|"", extracted_id_or_"")
    """
    import re as _re
    g = (guid_str or "").strip()
    # New format
    for prefix, key in (("tmdb://", "tmdb"), ("imdb://", "imdb"), ("tvdb://", "tvdb")):
        if g.startswith(prefix):
            return key, g[len(prefix):]
    # Old agent format  com.plexapp.agents.XYZ://ID/...?...
    m = _re.match(r"com\.plexapp\.agents\.([\w]+)://([^/?]+)", g)
    if m:
        agent = m.group(1).lower()
        raw_id = m.group(2)
        if "themoviedb" in agent or "tmdb" in agent:
            return "tmdb", raw_id
        if "imdb" in agent:
            return "imdb", raw_id
        if "thetvdb" in agent or "tvdb" in agent:
            return "tvdb", raw_id
    return "", ""


def _mediascan_fetch_plex(plex_url: str, plex_key: str) -> list:
    """Fetch all libraries from Plex and return normalised entries."""
    import urllib.request as _req
    import json as _json

    entries = []

    # 1. Get list of sections
    try:
        url = f"{plex_url}/library/sections?X-Plex-Token={plex_key}&Accept=application/json"
        req = _req.Request(url, headers={"Accept": "application/json"})
        with _req.urlopen(req, timeout=15) as r:
            sections_data = _json.loads(r.read())
    except Exception as exc:
        logger.warning("[MediaScan] Plex sections fetch failed: %s", exc)
        return entries

    directories = (
        sections_data.get("MediaContainer", {}).get("Directory") or []
    )

    for section in directories:
        sec_id   = section.get("key", "")
        sec_type = section.get("type", "")   # "show" | "movie"
        if sec_type not in ("show", "movie"):
            continue
        plex_type = 2 if sec_type == "show" else 1
        url = (
            f"{plex_url}/library/sections/{sec_id}/all"
            f"?type={plex_type}"
            f"&includeGuids=1"
            f"&Accept=application/json"
            f"&X-Plex-Token={plex_key}"
        )
        req = _req.Request(url, headers={"Accept": "application/json"})
        try:
            with _req.urlopen(req, timeout=30) as r:
                data = _json.loads(r.read())
        except Exception as exc:
            logger.warning("[MediaScan] Plex section %s fetch failed: %s", sec_id, exc)
            continue

        items = data.get("MediaContainer", {}).get("Metadata") or []
        for item in items:
            tmdb_id = imdb_id = tvdb_id = None

            # New agents: Guid array (list of {id: "tmdb://..."})
            for guid_obj in item.get("Guid") or []:
                key, val = _mediascan_parse_plex_guid(guid_obj.get("id", ""))
                if key == "tmdb" and not tmdb_id:
                    tmdb_id = val
                elif key == "imdb" and not imdb_id:
                    imdb_id = val
                elif key == "tvdb" and not tvdb_id:
                    tvdb_id = val

            # Old agents: single guid string on the item itself
            if not tmdb_id and not imdb_id and not tvdb_id:
                key, val = _mediascan_parse_plex_guid(item.get("guid", ""))
                if key == "tmdb":
                    tmdb_id = val
                elif key == "imdb":
                    imdb_id = val
                elif key == "tvdb":
                    tvdb_id = val

            entries.append({
                "tmdb_id":    tmdb_id,
                "imdb_id":    imdb_id,
                "tvdb_id":    tvdb_id,
                "title":      item.get("title") or "",
                "media_type": sec_type,
            })

    return entries


def _mediascan_resolve_ids(entries: list) -> list:
    """
    Post-fetch resolution pass: for entries missing a tmdb_id, try to find one
    by looking up the imdb_id in the local CineInfo tmdb_cache (free, no API call).
    This helps with Plex anime items that only have TVDB/IMDB GUIDs.
    """
    import json as _json
    country = get_setting("cineinfo_country", "DE") or "DE"
    resolved = improved = 0

    for entry in entries:
        if entry.get("tmdb_id"):
            continue  # already have it
        imdb_id = entry.get("imdb_id")
        if not imdb_id:
            continue
        # Look up  imdb_id|||country  in the CineInfo cache
        cached = get_tmdb_cache(f"{imdb_id}|||{country}")
        if cached and cached.get("found") and cached.get("tmdb_id"):
            entry["tmdb_id"] = str(cached["tmdb_id"])
            improved += 1
        resolved += 1

    if improved:
        logger.info("[MediaScan] Resolved %d/%d IMDB→TMDB IDs from CineInfo cache", improved, resolved)
    return entries


def _run_mediascan(source: str | None = None) -> None:
    """
    Core refresh: fetch library from Plex / Jellyfin and populate mediascan_cache.
    Runs in a background thread. Updates _mediascan_status throughout.
    """
    global _mediascan_status
    import time as _t

    creds = _mediascan_get_credentials()
    # Determine effective source
    if not source:
        source = get_setting("mediascan_source", "") or ""
    if not source:
        source = creds["svc"]  # fall back to whatever mediaplayer has

    with _mediascan_status_lock:
        if _mediascan_status["running"]:
            logger.info("[MediaScan] Scan already running, skipping duplicate request")
            return
        _mediascan_status.update({
            "running":     True,
            "started_at":  _t.time(),
            "finished_at": None,
            "count":       0,
            "total":       0,
            "error":       None,
            "source":      source,
        })

    try:
        logger.info("[MediaScan] Starting library fetch from %s", source)

        if source == "jellyfin":
            if not creds["jf_url"] or not creds["jf_key"]:
                raise ValueError("Jellyfin URL oder API-Key nicht konfiguriert (MediaPlayer-Integration prüfen)")
            entries = _mediascan_fetch_jellyfin(creds["jf_url"], creds["jf_key"])
        elif source == "plex":
            if not creds["plex_url"] or not creds["plex_key"]:
                raise ValueError("Plex URL oder Token nicht konfiguriert (MediaPlayer-Integration prüfen)")
            entries = _mediascan_fetch_plex(creds["plex_url"], creds["plex_key"])
        else:
            raise ValueError(f"Unbekannte MediaScan-Quelle: {source!r}")

        with _mediascan_status_lock:
            _mediascan_status["total"] = len(entries)

        # Resolution pass: fill in missing tmdb_id from local CineInfo cache
        # for items that only have imdb_id. This is cheap (local DB lookup).
        entries = _mediascan_resolve_ids(entries)

        replace_mediascan_cache(entries)

        with _mediascan_status_lock:
            _mediascan_status.update({
                "running":     False,
                "finished_at": _t.time(),
                "count":       len(entries),
                "error":       None,
            })
        logger.info("[MediaScan] Completed — %d entries cached", len(entries))

    except Exception as exc:
        logger.error("[MediaScan] Fetch failed: %s", exc)
        with _mediascan_status_lock:
            _mediascan_status.update({
                "running":     False,
                "finished_at": _t.time(),
                "error":       str(exc),
            })


def _schedule_mediascan_delayed(delay: float = 120.0) -> None:
    """
    Schedule a one-shot mediascan refresh after *delay* seconds.
    If one is already pending, reset the timer.
    """
    global _mediascan_delay_timer
    if get_setting("mediascan_enabled", "0") != "1":
        return
    source = get_setting("mediascan_source", "") or ""
    if source == "folders" or not source:
        return

    def _fire():
        logger.info("[MediaScan] Post-download delayed refresh firing")
        t = threading.Thread(target=_run_mediascan, daemon=True)
        t.start()

    with _mediascan_delay_lock:
        if _mediascan_delay_timer and _mediascan_delay_timer.is_alive():
            _mediascan_delay_timer.cancel()
        _mediascan_delay_timer = threading.Timer(delay, _fire)
        _mediascan_delay_timer.daemon = True
        _mediascan_delay_timer.start()
    logger.info("[MediaScan] Post-download refresh scheduled in %.0fs", delay)


def _start_mediascan_scheduler() -> None:
    """Start a daemon thread that triggers a mediascan every 24 h."""
    global _mediascan_scheduler_thread
    import time as _t

    def _loop():
        # Wait 24 h, then refresh, repeat
        while not _mediascan_scheduler_stop.wait(timeout=86400):
            if get_setting("mediascan_enabled", "0") == "1":
                source = get_setting("mediascan_source", "") or ""
                if source and source != "folders":
                    logger.info("[MediaScan] 24-h scheduled refresh")
                    _run_mediascan()
            _mediascan_scheduler_stop.wait(timeout=1)  # re-check flag quickly

    _mediascan_scheduler_stop.clear()
    _mediascan_scheduler_thread = threading.Thread(target=_loop, name="mediascan-scheduler", daemon=True)
    _mediascan_scheduler_thread.start()
    logger.info("[MediaScan] 24-h scheduler started")


def _trigger_mediaplayer_refresh(title: str | None = None, selected_path: str | None = None) -> None:
    """Trigger a library refresh on Jellyfin or Plex after a successful download."""
    try:
        svc  = get_setting("mediaplayer_type", "")       # "jellyfin" | "plex"
        url  = _normalize_media_url(get_setting("mediaplayer_url",  "") or "")
        key  = get_setting("mediaplayer_apikey", "") or ""
        if not svc or not key:
            return
        # For Plex the URL lives in mediaplayer_plex_url, not mediaplayer_url
        if svc == "plex":
            plex_url_check = _normalize_media_url(get_setting("mediaplayer_plex_url", "") or "")
            if not plex_url_check:
                logger.warning("Plex library refresh skipped: keine Plex-URL konfiguriert")
                return
        elif not url:
            logger.warning("Mediaplayer refresh skipped: keine Server-URL konfiguriert")
            return

        import urllib.request as _urllib_req

        if svc == "jellyfin":
            req = _urllib_req.Request(
                f"{url}/Library/Refresh",
                data=b"",
                method="POST",
                headers={
                    "X-Emby-Token": key,
                    "Content-Type": "application/json",
                },
            )
            _urllib_req.urlopen(req, timeout=10)
            logger.info("Jellyfin library refresh triggered")

        elif svc == "plex":
            # Plex: refresh the specific section or the whole library
            plex_url = _normalize_media_url(get_setting("mediaplayer_plex_url", "") or "") or url
            section = (get_setting("mediaplayer_plex_section", "") or "").strip()
            if section:
                req_url = f"{plex_url}/library/sections/{section}/refresh?X-Plex-Token={key}"
            else:
                req_url = f"{plex_url}/library/sections/all/refresh?X-Plex-Token={key}"
            req = _urllib_req.Request(req_url, method="GET")
            _urllib_req.urlopen(req, timeout=10)
            logger.info("Plex library refresh triggered (section=%s)", section or "all")

    except Exception as exc:
        logger.warning("Media-player refresh failed: %s", exc)


def _is_filmpalast_url(url: str) -> bool:
    return "filmpalast.to/stream/" in url


def _queue_worker():
    """Single global worker that processes one download at a time."""
    while True:
        try:
            item = None
            with _queue_lock:
                if not get_running():
                    item = get_next_queued()
                    if item:
                        set_queue_status(item["id"], "running")

            if not item:
                time.sleep(3)
                continue

            # Don't start a new item while paused
            while is_queue_paused():
                time.sleep(2)

            # Warn if disk space is below configured threshold (non-blocking)
            # Resolve the actual download path for this item (custom path or default)
            _disk_check_path = None
            try:
                _cp_id = item.get("custom_path_id")
                if _cp_id:
                    _cp = get_custom_path_by_id(_cp_id)
                    if _cp:
                        _disk_check_path = str(Path(_cp["path"]).expanduser())
            except Exception:
                pass
            _check_disk_space_and_notify(username=item.get("username"), check_path=_disk_check_path)

            episodes = json.loads(item["episodes"])
            # Carry over any pre-existing errors (e.g. other failed episodes that
            # were kept when the user retried just one specific episode).
            # For brand-new jobs the DB default is '[]', so this is always safe.
            errors = json.loads(item.get("errors") or "[]")

            # Language separation: compute subfolder path if enabled
            import os

            lang_sep = os.environ.get("ANIWORLD_LANG_SEPARATION", "0") == "1"
            if item.get("source") == "sync:all_langs":
                lang_sep = True
            selected_path = None

            from pathlib import Path

            # Determine base path: custom path or default
            custom_path_id = item.get("custom_path_id")
            if custom_path_id:
                cp = get_custom_path_by_id(custom_path_id)
                if cp:
                    base = Path(cp["path"]).expanduser()
                    if not base.is_absolute():
                        base = Path.home() / base
                else:
                    base = None
            else:
                base = None

            if base is None:
                raw = os.environ.get("ANIWORLD_DOWNLOAD_PATH", "")
                if raw:
                    base = Path(raw).expanduser()
                    if not base.is_absolute():
                        base = Path.home() / base
                else:
                    base = Path.home() / "Downloads"

            if lang_sep:
                lang_folder_map = {
                    "German Dub": "german-dub",
                    "English Sub": "english-sub",
                    "German Sub": "german-sub",
                    "English Dub": "english-dub",
                }
                lang_folder = lang_folder_map.get(
                    item["language"], item["language"].lower().replace(" ", "-")
                )
                selected_path = str(base / lang_folder)
            elif custom_path_id:
                selected_path = str(base)

            MAX_EP_RETRIES = 3

            # Create a cancel event for this item so api_queue_cancel can
            # kill the active subprocess immediately.
            _item_cancel = threading.Event()
            with _active_cancel_events_lock:
                _active_cancel_events[item["id"]] = _item_cancel

            # Friendly labels for language-not-available errors
            _LANG_LABELS = {
                ("GERMAN",   "NONE"):    "Deutsch",
                ("ENGLISH",  "NONE"):    "Englisch",
                ("JAPANESE", "GERMAN"):  "Japanisch mit deutschen Untertiteln",
                ("JAPANESE", "ENGLISH"): "Japanisch mit englischen Untertiteln",
                ("GERMAN",   "ENGLISH"): "Deutsch mit englischen Untertiteln",
            }

            def _lang_unavailable_msg(exc):
                """Return a human-readable message if exc is a language-not-found error, else None."""
                msg = str(exc)
                if "No provider data found for language" not in msg:
                    return None
                audio_m = re.search(r"Audio\.(\w+)", msg)
                subs_m  = re.search(r"Subtitles\.(\w+)", msg)
                audio = audio_m.group(1).upper() if audio_m else ""
                subs  = subs_m.group(1).upper()  if subs_m  else "NONE"
                label = _LANG_LABELS.get((audio, subs), f"{audio}" + (f" / UT: {subs}" if subs != "NONE" else ""))
                return f"Nicht verfügbar in: {label}"

            total_bytes_before = 0
            _upscale_after_paths = []  # collect for batch after_download upscaling
            download_start_time = time.time()

            for i, ep_url in enumerate(episodes):
                update_queue_progress(item["id"], i, ep_url)

                last_error = None
                for attempt in range(1, MAX_EP_RETRIES + 1):
                    try:
                        prov = resolve_provider(ep_url)
                        ep_kwargs = {
                            "url": ep_url,
                            "selected_language": item["language"],
                            "selected_provider": item["provider"],
                        }
                        if selected_path:
                            ep_kwargs["selected_path"] = selected_path
                        episode = prov.episode_cls(**ep_kwargs)
                        from ..playwright import captcha as _captcha_mod
                        from ..models.common.common import get_ffmpeg_progress
                        _captcha_mod._local.queue_id = item["id"]

                        # ── Watchdog: run download in a thread so a hung yt-dlp
                        # cannot freeze the entire queue worker forever. ──────
                        _HANG_TIMEOUT   = int(os.environ.get("ANIWORLD_HANG_TIMEOUT", "300"))   # 5 min default
                        _STALL_TIMEOUT  = int(os.environ.get("ANIWORLD_STALL_TIMEOUT", "60"))   # 1 min no progress
                        _dl_exc = [None]
                        _dl_done = threading.Event()

                        def _dl_thread():
                            try:
                                episode.download(cancel_event=_item_cancel)
                            except Exception as _e:
                                _dl_exc[0] = _e
                            finally:
                                _captcha_mod._local.queue_id = None
                                _dl_done.set()

                        _t = threading.Thread(target=_dl_thread, daemon=True)
                        _t.start()

                        # Poll for stall / hard timeout
                        _last_pct    = -1.0
                        _last_change = time.time()
                        _start_watch = time.time()
                        _timed_out   = False
                        while not _dl_done.wait(timeout=5):
                            _now = time.time()
                            if _now - _start_watch > _HANG_TIMEOUT:
                                logger.error(
                                    f"[watchdog] Download hard-timeout ({_HANG_TIMEOUT}s) for {ep_url} — aborting"
                                )
                                _item_cancel.set()
                                _timed_out = True
                                break
                            _prog = get_ffmpeg_progress()
                            _pct  = _prog.get("percent", 0.0)
                            if _pct != _last_pct:
                                _last_pct    = _pct
                                _last_change = _now
                            elif _now - _last_change > _STALL_TIMEOUT:
                                logger.error(
                                    f"[watchdog] No progress for {_STALL_TIMEOUT}s on {ep_url} — aborting"
                                )
                                _item_cancel.set()
                                _timed_out = True
                                break

                        if _timed_out:
                            _dl_done.wait(timeout=10)  # give thread a moment to notice cancel
                            raise RuntimeError(
                                f"Download aborted by watchdog (stalled/hung after {_STALL_TIMEOUT}s without progress)"
                            )

                        if _dl_exc[0] is not None:
                            raise _dl_exc[0]
                        # ── end watchdog ─────────────────────────────────────
                        last_error = None

                        # Track size
                        try:
                            if hasattr(episode, "_episode_path") and episode._episode_path.exists():
                                total_bytes_before += os.path.getsize(episode._episode_path)
                        except Exception:
                            pass

                        # Collect path for batch after_download upscaling
                        try:
                            if hasattr(episode, "_episode_path") and episode._episode_path.exists():
                                _upscale_after_paths.append(str(episode._episode_path))
                        except Exception:
                            pass

                        break  # success — stop retrying
                    except Exception as e:
                        from ..playwright import captcha as _captcha_mod
                        _captcha_mod._local.queue_id = None
                        # If the item was cancelled, stop retrying immediately.
                        if is_queue_cancelled(item["id"]) or "Download cancelled" in str(e):
                            last_error = None
                            break
                        friendly = _lang_unavailable_msg(e)
                        if friendly is not None:
                            # Language simply doesn't exist — no point retrying
                            last_error = Exception(friendly)
                            logger.warning(f"Language unavailable for {ep_url}: {e}")
                            break
                        last_error = e
                        if attempt < MAX_EP_RETRIES:
                            delay = 2
                            logger.warning(
                                f"Episode {ep_url} failed (attempt {attempt}/{MAX_EP_RETRIES}), "
                                f"retrying in {delay}s: {e}"
                            )
                            time.sleep(delay)
                        else:
                            logger.error(
                                f"Episode {ep_url} failed after {MAX_EP_RETRIES} attempts: {e}"
                            )
                    # Check skip flag after each attempt (success or fail)
                    if consume_episode_skip(item["id"]):
                        logger.info(f"Episode {ep_url} skipped by user request")
                        last_error = None  # treat as skipped, not failed
                        break

                from ..models.common.common import print_episode_summary
                if last_error is not None:
                    errors.append({"url": ep_url, "error": str(last_error)})
                    update_queue_errors(item["id"], json.dumps(errors))
                    print_episode_summary(item["title"], ep_url, success=False)
                else:
                    print_episode_summary(item["title"], ep_url, success=True)

                # Mark episode as done: increment counter and clear current URL
                update_queue_progress(item["id"], i + 1, "")

                # Check for cancellation after each episode
                if is_queue_cancelled(item["id"]):
                    logger.info(f"Download cancelled for queue item {item['id']}")
                    break

                # Pause: hold here until resumed (checks every 2s)
                while is_queue_paused():
                    time.sleep(2)

            # Batch-trigger after_download upscaling for all collected episode paths
            if _upscale_after_paths and not is_queue_cancelled(item["id"]):
                try:
                    _trigger_batch_after_download_upscale(_upscale_after_paths, item.get("title", ""))
                except Exception as _ue:
                    logger.warning(f"[Upscale] Batch-Trigger Fehler: {_ue}")

            # Only set final status if not already cancelled
            if not is_queue_cancelled(item["id"]):
                update_queue_progress(item["id"], len(episodes), "")

                # Calculate speed and update stats
                download_end_time = time.time()
                duration = download_end_time - download_start_time
                if duration > 0 and total_bytes_before > 0:
                    total_size_mb = total_bytes_before / (1024 * 1024)
                    avg_speed = total_size_mb / duration
                    update_queue_stats(item["id"], round(avg_speed, 2), round(total_size_mb, 1))

                successful = len(episodes) - len(errors)
                if not errors:
                    status = "completed"
                elif successful > 0:
                    status = "partial"
                else:
                    status = "failed"
                set_queue_status(item["id"], status)

                # Send notifications (all services)
                from .notifications import notify_all
                _is_movie = _is_filmpalast_url(item.get("url", ""))
                if status == "completed":
                    _body = "✅ Film heruntergeladen" if _is_movie else f"✅ {len(episodes)} Episode(n) heruntergeladen"
                    _event = "on_completed"
                elif status == "partial":
                    _body = f"❌ Film-Download fehlgeschlagen ({len(errors)} Fehler)" if _is_movie else f"⚠️ {successful} von {len(episodes)} Episode(n) heruntergeladen, {len(errors)} Fehler"
                    _event = "on_partial"
                else:
                    _body = f"❌ Download fehlgeschlagen ({len(errors)} Fehler)"
                    _event = "on_errors"
                notify_all(
                    title=item.get("title", "Unbekannt"),
                    body=_body,
                    event=_event,
                    username=item.get("username"),
                    status=status,
                    episode_count=len(episodes),
                    errors=errors,
                    is_movie=_is_movie,
                )
                # Trigger Jellyfin/Plex library refresh on completed or partial downloads
                if status in ("completed", "partial"):
                    _trigger_mediaplayer_refresh(title=item.get("title"), selected_path=selected_path)
                    # MediaScan: schedule a delayed library re-fetch (2 min) so
                    # Plex/Jellyfin has time to ingest the new file first
                    _schedule_mediascan_delayed(delay=120.0)
            else:
                from .notifications import notify_all
                notify_all(
                    title=item.get("title", "Unbekannt"),
                    body="⏹️ Download abgebrochen",
                    event="on_cancelled",
                    username=item.get("username"),
                    status="cancelled",
                    episode_count=len(episodes),
                    errors=[],
                )

        except Exception as e:
            logger.error(f"Queue worker error: {e}", exc_info=True)
            time.sleep(3)
        finally:
            # Always deregister the cancel event for this item.
            if item is not None:
                with _active_cancel_events_lock:
                    _active_cancel_events.pop(item["id"], None)


def _ensure_queue_worker():
    """Start the queue worker thread once."""
    global _queue_worker_started
    if _queue_worker_started:
        return
    _queue_worker_started = True

    # Crash recovery: reset any 'running' items back to 'queued'
    from .db import get_db

    conn = get_db()
    try:
        conn.execute(
            "UPDATE download_queue SET status = 'queued' WHERE status = 'running'"
        )
        conn.execute("UPDATE download_queue SET captcha_url = NULL")
        conn.commit()
    finally:
        conn.close()

    thread = threading.Thread(target=_queue_worker, daemon=True)
    thread.start()


def _run_autosync_for_job(job, force_notify=False):
    """Check a single autosync job for new/missing episodes and queue them."""
    import os
    from datetime import datetime
    from pathlib import Path

    job_id = job["id"]
    with _syncing_jobs_lock:
        if job_id in _syncing_jobs:
            logger.info("Auto-sync skipped job %d — already running", job_id)
            return
        _syncing_jobs.add(job_id)

    try:
        # ------------------------------------------------------------------ #
        # Custom Path availability check                                       #
        # If the job has a custom_path_id, verify the directory is accessible #
        # before doing any online fetching. Depending on the job's             #
        # path_unavailable_action setting we either skip or hold.              #
        # ------------------------------------------------------------------ #
        from pathlib import Path as _Path
        _cp_id = job.get("custom_path_id")
        if _cp_id:
            _cp_record = get_custom_path_by_id(_cp_id)
            _cp_available = False
            if _cp_record:
                try:
                    _cp_available = _Path(_cp_record["path"]).expanduser().is_dir()
                except Exception:
                    _cp_available = False

            if not _cp_available:
                _global_action = os.environ.get("ANIWORLD_SYNC_PATH_UNAVAILABLE_ACTION", "skip").lower()
                _action = (job.get("path_unavailable_action") or _global_action or "skip").lower()
                _was_on_hold = bool(job.get("on_hold"))

                if _action == "hold":
                    if not _was_on_hold:
                        # First time going on hold — persist state + notify
                        update_autosync_job(
                            job["id"],
                            on_hold=1,
                            last_error="Custom Path nicht erreichbar — Sync pausiert (Hold)",
                        )
                        logger.warning(
                            "Auto-sync HOLD for '%s' — custom path '%s' not accessible",
                            job.get("title", "?"),
                            _cp_record["path"] if _cp_record else _cp_id,
                        )
                        try:
                            from .notifications import notify_all
                            notify_all(
                                title=job.get("title", "Auto-Sync"),
                                body="⏸ Sync pausiert: Custom Path nicht erreichbar — "
                                     + str(_cp_record['path'] if _cp_record else 'Unbekannt'),
                                event="on_sync_hold",
                                username=job.get("added_by"),
                            )
                        except Exception:
                            pass
                    else:
                        logger.info(
                            "Auto-sync still on HOLD for '%s' — custom path still unavailable",
                            job.get("title", "?"),
                        )
                    return  # wait for next cycle
                else:
                    # action == "skip" (default)
                    logger.info(
                        "Auto-sync SKIP for '%s' — custom path not accessible (action=skip)",
                        job.get("title", "?"),
                    )
                    update_autosync_job(
                        job["id"],
                        last_check=__import__("datetime").datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
                        last_error="Custom Path nicht erreichbar — Sync übersprungen",
                    )
                    return
            else:
                # Path is accessible — if we were on hold, clear it and notify resume
                if job.get("on_hold"):
                    update_autosync_job(job["id"], on_hold=0, last_error=None)
                    logger.info(
                        "Auto-sync RESUME for '%s' — custom path is accessible again",
                        job.get("title", "?"),
                    )
                    try:
                        from .notifications import notify_all
                        notify_all(
                            title=job.get("title", "Auto-Sync"),
                            body="▶️ Sync wird fortgesetzt: Custom Path ist wieder erreichbar — "
                                 + str(_cp_record['path'] if _cp_record else ''),
                            event="on_sync_resume",
                            username=job.get("added_by"),
                        )
                    except Exception:
                        pass

        prov = resolve_provider(job["series_url"])
        series = prov.series_cls(url=job["series_url"])

        lang_sep = os.environ.get("ANIWORLD_LANG_SEPARATION", "0") == "1"
        # Only use lang_sep for "All Languages" when the global setting is enabled;
        # otherwise scan root directory to avoid phantom missing-episode detection.
        if job.get("language") == "All Languages" and not lang_sep:
            logger.warning(
                "Auto-sync job '%s' uses 'All Languages' but lang_separation is off — scanning root.",
                job.get("title", "?"),
            )

        lang_folder_map = {
            "German Dub": "german-dub",
            "English Sub": "english-sub",
            "German Sub": "german-sub",
            "English Dub": "english-dub",
        }

        target_languages = []
        if job.get("language") == "All Languages":
            disable_eng_sub = os.environ.get("ANIWORLD_DISABLE_ENGLISH_SUB", "0") == "1"
            for lang in lang_folder_map.keys():
                if disable_eng_sub and lang == "English Sub":
                    continue
                target_languages.append(lang)
        else:
            target_languages.append(job["language"])

        # Phase 1: Count all episodes available online (language-independent).
        # This is done before any disk scan so we can decide early whether
        # new episodes have appeared since the last check.
        # We keep the episode object so Phase 2 can lazily check language
        # availability via provider_data before actually queuing.
        previous_episodes_found = job.get("episodes_found", 0)
        online_episodes = []  # list of (season_num, ep_num, url, ep_obj)
        for season in series.seasons:
            season_obj = prov.season_cls(url=season.url, series=series)
            if getattr(season_obj, "are_movies", False):
                logger.debug(
                    "Auto-sync: skipping movie season for '%s'",
                    job.get("title", "?"),
                )
                continue
            for ep in season_obj.episodes:
                online_episodes.append(
                    (ep.season.season_number, ep.episode_number, ep.url, ep)
                )

        total_online_count = len(online_episodes)
        is_first_run = previous_episodes_found == 0
        has_new_episodes_online = total_online_count > previous_episodes_found

        now_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

        if not is_first_run and not has_new_episodes_online:
            logger.info(
                "Auto-sync: no new episodes online for '%s' (%d found, unchanged) — will still check local files",
                job["title"],
                total_online_count,
            )

        if has_new_episodes_online:
            new_count = total_online_count - previous_episodes_found
            logger.info(
                "Auto-sync: %d new episode(s) detected for '%s' (was %d, now %d)",
                new_count,
                job["title"],
                previous_episodes_found,
                total_online_count,
            )
            pass  # notification fires in Phase 2 when episodes are actually queued

        # Phase 2: Per language — scan disk and queue missing episodes.
        total_new_queued = 0
        max_local_found = 0

        for target_lang in target_languages:
            job_lang_folder = lang_folder_map.get(
                target_lang, target_lang.lower().replace(" ", "-")
            )

            raw = os.environ.get("ANIWORLD_DOWNLOAD_PATH", "")
            if raw:
                dl_base = Path(raw).expanduser()
                if not dl_base.is_absolute():
                    dl_base = Path.home() / dl_base
            else:
                dl_base = Path.home() / "Downloads"

            scan_roots = [dl_base]
            for cp in get_custom_paths():
                cp_path = Path(cp["path"]).expanduser()
                if not cp_path.is_absolute():
                    cp_path = Path.home() / cp_path
                scan_roots.append(cp_path)

            # Build set of downloaded (season, episode) on disk
            downloaded_eps = set()
            title_clean = (
                getattr(series, "title_cleaned", None) or getattr(series, "title", "")
            ).lower()
            if title_clean:
                ep_re = re.compile(r"S(\d{2})E(\d{2,3})", re.IGNORECASE)
                all_bases = []
                for root in scan_roots:
                    if lang_sep:
                        all_bases.append(root / job_lang_folder)
                    else:
                        all_bases.append(root)
                for base in all_bases:
                    if not base.is_dir():
                        continue
                    for folder in base.iterdir():
                        if not folder.is_dir() or not folder.name.lower().startswith(
                            title_clean
                        ):
                            continue
                        for f in folder.rglob("*"):
                            if f.is_file():
                                m = ep_re.search(f.name)
                                if m:
                                    downloaded_eps.add(
                                        (int(m.group(1)), int(m.group(2)))
                                    )

            if len(downloaded_eps) > max_local_found:
                max_local_found = len(downloaded_eps)

            # Build the lang-enum target for language-availability checks.
            # We compare by string value so it works for both aniworld and s.to
            # enums (which are separate classes with identical values).
            _lang_key = INVERSE_LANG_LABELS.get(target_lang)
            _target_lang_str = None
            if _lang_key:
                _target_enum = LANG_KEY_MAP.get(_lang_key)
                if _target_enum:
                    _target_lang_str = (_target_enum[0].value, _target_enum[1].value)

            # Collect episode URLs that are not yet present on disk AND whose
            # target language is actually available online.
            missing_episodes = []
            for (s_num, e_num, url, ep_obj) in online_episodes:
                if (s_num, e_num) in downloaded_eps:
                    continue
                # Check language availability before queuing to avoid
                # "No provider data found for language" errors in the queue worker.
                if _target_lang_str is not None:
                    try:
                        pd = ep_obj.provider_data
                        # AniworldEpisode returns a ProviderData wrapper (._data);
                        # SerienstreamEpisode returns a plain dict directly.
                        pd_data = pd._data if hasattr(pd, "_data") else pd
                        lang_available = any(
                            (k[0].value, k[1].value) == _target_lang_str
                            for k in pd_data
                        )
                    except Exception as exc:
                        logger.warning(
                            "Auto-sync: could not check language availability for S%02dE%02d of '%s': %s — queuing anyway",
                            s_num, e_num, job["title"], exc,
                        )
                        lang_available = True  # can't verify → let queue try
                    if not lang_available:
                        logger.debug(
                            "Auto-sync: S%02dE%02d not yet available in '%s' for '%s' — skipping",
                            s_num, e_num, target_lang, job["title"],
                        )
                        continue
                missing_episodes.append(url)

            if missing_episodes:
                # Skip if series is already queued or running for THIS language
                if is_series_queued_or_running(job["series_url"], language=target_lang):
                    logger.info(
                        "Auto-sync skipped '%s' (%s) — already queued/running",
                        job["title"],
                        target_lang,
                    )
                    continue

                total_new_queued += len(missing_episodes)
                add_to_queue(
                    title=job["title"],
                    series_url=job["series_url"],
                    episodes=missing_episodes,
                    language=target_lang,
                    provider=job["provider"],
                    username=job.get("added_by"),
                    custom_path_id=job.get("custom_path_id"),
                    source="sync:all_langs"
                    if job.get("language") == "All Languages"
                    else "sync",
                )
                logger.info(
                    "Auto-sync queued %d episodes for '%s' (%s)",
                    len(missing_episodes),
                    job["title"],
                    target_lang,
                )

        update_fields = {
            "last_check": now_str,
            "episodes_found": total_online_count,
            "local_episodes_found": max_local_found,
            "retry_count": 0,
        }

        # Only update last_new_found / last_new_count when episodes genuinely appeared online
        if has_new_episodes_online:
            update_fields["last_new_found"] = now_str
            update_fields["last_new_count"] = total_online_count - previous_episodes_found
        else:
            # Reset badge counter so UI shows "up to date" after a clean check
            update_fields["last_new_count"] = 0

        update_fields["last_error"] = None  # clear any previous error on success
        update_autosync_job(job["id"], **update_fields)

        # Notify when episodes were actually queued for download
        if total_new_queued > 0:
            from .notifications import notify_all
            notify_all(
                title=job["title"],
                body=f"⬇️ {total_new_queued} neue Folge(n) werden heruntergeladen",
                event="on_autosync",
                username=job.get("added_by"),
                episode_count=total_new_queued,
            )
    except Exception as e:
        logger.error("Auto-sync failed for '%s': %s", job.get("title", "?"), e, exc_info=True)
        from datetime import datetime
        
        current_retry = job.get("retry_count", 0)
        max_retries = int(get_setting("sync_error_retries") or os.environ.get("ANIWORLD_SYNC_ERROR_RETRIES", "0"))
        new_retry = current_retry + 1
        
        update_autosync_job(
            job["id"],
            last_check=datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            last_error=str(e),
            retry_count=new_retry,
        )
        
        only_notify_on_all_failed = get_setting("notif_sync_error_only_failed_all", "0") == "1"
        should_notify = True
        if only_notify_on_all_failed:
            if new_retry <= max_retries:
                should_notify = False
                
        if should_notify:
            try:
                from .notifications import notify_all
                notify_all(
                    title=job.get("title", "Auto-Sync"),
                    body=f"❌ Sync-Fehler: {str(e)[:200]}",
                    event="on_sync_error",
                    username=job.get("added_by"),
                )
            except Exception:
                pass
    finally:
        with _syncing_jobs_lock:
            _syncing_jobs.discard(job_id)


def _autosync_worker():
    """Background thread that periodically syncs all enabled autosync jobs.

    Uses short-polling (every 10 s) and checks each job's last_check
    against the configured interval so that schedule changes take effect
    immediately instead of blocking in a long sleep.
    """
    import os
    from datetime import datetime, timedelta

    while True:
        try:
            schedule_key = os.environ.get("ANIWORLD_SYNC_SCHEDULE", "0")
            interval = SYNC_SCHEDULE_MAP.get(schedule_key, 0)
            if not interval:
                time.sleep(10)
                continue

            now = datetime.utcnow()
            jobs = get_autosync_jobs()
            max_retries = int(get_setting("sync_error_retries") or os.environ.get("ANIWORLD_SYNC_ERROR_RETRIES", "0"))
            retry_time_key = get_setting("sync_error_retry_time") or os.environ.get("ANIWORLD_SYNC_ERROR_RETRY_TIME", "5min")
            job_retry_interval = SYNC_RETRY_MAP.get(retry_time_key, 300)

            for job in jobs:
                if not job.get("enabled"):
                    continue
                # Per-job check: only run if enough time has elapsed
                last_check = job.get("last_check")
                if last_check:
                    try:
                        last_dt = datetime.strptime(last_check, "%Y-%m-%d %H:%M:%S")
                    except (ValueError, TypeError):
                        last_dt = datetime.min
                    
                    retry_count = job.get("retry_count", 0)
                    if retry_count > 0 and retry_count <= max_retries:
                        job_interval = job_retry_interval
                    else:
                        job_interval = interval

                    if now < last_dt + timedelta(seconds=job_interval):
                        continue
                _run_autosync_for_job(job)

            time.sleep(10)
        except Exception as e:
            logger.error("Auto-sync worker error: %s", e, exc_info=True)
            time.sleep(30)


def _ensure_autosync_worker():
    """Start the auto-sync worker thread once."""
    global _autosync_worker_started
    if _autosync_worker_started:
        return
    _autosync_worker_started = True
    thread = threading.Thread(target=_autosync_worker, daemon=True)
    thread.start()



# ---------------------------------------------------------------------------
# Upscale Queue Worker
# ---------------------------------------------------------------------------

def _upscale_worker():
    """Single global worker that processes one upscale job at a time."""
    while True:
        try:
            item = None
            if not get_upscale_running():
                item = get_next_upscale_queued()
                if item:
                    set_upscale_status(item["id"], "running")

            if not item:
                time.sleep(4)
                continue

            cancel_ev = threading.Event()
            with _upscale_cancel_lock:
                _upscale_active_cancel_events[item["id"]] = cancel_ev

            try:
                from ..anime4k.anime4k import upscale_file, get_upscale_progress
                from ..anime4k.anime4k import _upscale_progress, _upscale_progress_lock
            except ImportError:
                set_upscale_status(item["id"], "failed")
                set_upscale_error(item["id"], "anime4k Modul nicht gefunden")
                continue

            settings = {
                "preset":     get_setting("upscaling_shader_preset", "B"),
                "quality":    get_setting("upscaling_shader_quality", "high"),
                "resolution": get_setting("upscaling_resolution", "1080p"),
                "engine":     get_setting("upscaling_engine", "auto"),
                "out_vcodec": get_setting("upscaling_out_vcodec", "libx264"),
                "out_crf":    int(get_setting("upscaling_out_crf", "18") or "18"),
                "out_preset": get_setting("upscaling_out_preset", "medium"),
            }

            # Progress-poll thread: mirrors anime4k live progress -> DB every 2s
            import threading as _th
            _poll_stop = _th.Event()
            def _progress_poller():
                while not _poll_stop.wait(2):
                    prog = get_upscale_progress()
                    if prog.get("active") and not is_upscale_cancelled(item["id"]):
                        _cur_idx = item.get("_runtime_file_idx", 0)
                        _tot = max(item.get("total_files", 1), 1)
                        _base = _cur_idx / _tot * 100
                        _file_pct = prog.get("percent", 0.0) / _tot
                        update_upscale_progress(item["id"],
                            min(round(_base + _file_pct, 1), 99.9))
            _pt = _th.Thread(target=_progress_poller, daemon=True)
            _pt.start()

            import json as _wjson
            from pathlib import Path as _WPath

            # Build file list: multi-file entries store JSON in .files column
            _raw_files = item.get("files")
            if _raw_files:
                try:
                    _file_list = _wjson.loads(_raw_files)
                except Exception:
                    _file_list = [{"file_path": item["file_path"],
                                   "output_path": item.get("output_path") or item["file_path"]}]
            else:
                _file_list = [{"file_path": item["file_path"],
                               "output_path": item.get("output_path") or item["file_path"]}]

            _total_files = max(len(_file_list), 1)
            _overall_failed = 0

            for _fi, _fentry in enumerate(_file_list):
                if is_upscale_cancelled(item["id"]):
                    break

                file_path   = _fentry["file_path"]
                output_path = _fentry.get("output_path") or file_path

                _replace_original = (file_path == output_path)
                if _replace_original:
                    actual_output = str(_WPath(file_path).with_suffix(".upscale_tmp.mkv"))
                else:
                    actual_output = output_path

                # Track current file index (poller reads this)
                item["_runtime_file_idx"] = _fi
                update_upscale_progress(item["id"],
                    round(_fi / _total_files * 100, 1),
                    current_file_idx=_fi)

                try:
                    upscale_file(
                        input_path=file_path,
                        output_path=actual_output,
                        settings=settings,
                        cancel_event=cancel_ev,
                        label=item.get("title", ""),
                    )
                    if not is_upscale_cancelled(item["id"]):
                        if _replace_original:
                            _WPath(file_path).unlink(missing_ok=True)
                            _WPath(actual_output).rename(file_path)
                except Exception as _fe:
                    _overall_failed += 1
                    logger.error(f"[Upscale] Fehler bei {file_path}: {_fe}")
                    try:
                        _WPath(actual_output).unlink(missing_ok=True)
                    except Exception:
                        pass
                    # Continue with next file unless cancelled
                    if is_upscale_cancelled(item["id"]):
                        break

            # Final status
            if not is_upscale_cancelled(item["id"]):
                update_upscale_progress(item["id"], 100.0, current_file_idx=_total_files)
                if _overall_failed == 0:
                    set_upscale_status(item["id"], "completed")
                elif _overall_failed < _total_files:
                    set_upscale_status(item["id"], "completed")
                    set_upscale_error(item["id"], f"{_overall_failed}/{_total_files} Datei(en) fehlgeschlagen")
                else:
                    set_upscale_status(item["id"], "failed")
                    set_upscale_error(item["id"], f"Alle {_total_files} Datei(en) fehlgeschlagen")

            _poll_stop.set()
            _pt.join(timeout=3)

            if is_upscale_cancelled(item["id"]):
                set_upscale_status(item["id"], "cancelled")

            with _upscale_cancel_lock:
                _upscale_active_cancel_events.pop(item["id"], None)

        except Exception as e:
            logger.error(f"[Upscale] Worker-Fehler: {e}", exc_info=True)
            time.sleep(5)


def _ensure_upscale_worker():
    """Start the upscale worker thread once."""
    global _upscale_worker_started
    if _upscale_worker_started:
        return
    _upscale_worker_started = True
    reset_running_upscale_items()
    thread = threading.Thread(target=_upscale_worker, daemon=True, name="upscale-worker")
    thread.start()


def _trigger_batch_after_download_upscale(episode_paths, title):
    """Add ALL downloaded episodes as ONE upscale queue entry."""
    try:
        mode = get_setting("upscaling_mode", "disabled")
        if mode != "after_download":
            return
        replace = get_setting("upscaling_replace_original", "1") == "1"
        from pathlib import Path as _Path
        valid = []
        for episode_path in episode_paths:
            ep = _Path(episode_path)
            if not ep.exists():
                continue
            out = str(ep) if replace else str(ep.with_name(ep.stem + " (upscale).mkv"))
            valid.append({"file_path": str(ep), "output_path": out})
        if not valid:
            return
        add_to_upscale_queue(
            title=title,
            file_path=valid[0]["file_path"],
            output_path=valid[0]["output_path"],
            source="download",
            files=valid if len(valid) > 1 else None,
        )
        logger.info(f"[Upscale] {len(valid)} Datei(en) als ein Eintrag in Queue: {title}")
    except Exception as exc:
        logger.warning(f"[Upscale] Batch-Trigger Fehler: {exc}")

def _get_version():
    """Return the base version string from package metadata (e.g. '2.1.6')."""
    try:
        from importlib.metadata import version

        return version("mrx-aniworld")
    except Exception:
        return ""


def _get_dev_install_info():
    """
    Detect whether aniworld was installed from a Git branch (dev install).

    pip writes a ``direct_url.json`` file into the dist-info directory whenever
    a package is installed via ``git+https://...``.  We read that file to get
    the exact commit SHA and the requested revision.

    A git install is only considered a *dev* install when the requested revision
    is a branch name (e.g. ``models``) rather than a version tag (e.g. ``v2.1.7``).

    Returns:
        (is_dev: bool, full_commit_sha: str | None)
    """
    try:
        import importlib.metadata as _meta
        import json as _json
        import re as _re

        dist = _meta.distribution("mrx-aniworld")
        direct_url_text = dist.read_text("direct_url.json")
        if not direct_url_text:
            return False, None
        data = _json.loads(direct_url_text)
        vcs_info = data.get("vcs_info", {})
        if vcs_info.get("vcs") == "git":
            commit_id = vcs_info.get("commit_id", "")
            requested_revision = vcs_info.get("requested_revision", "")
            # Version tags like v2.1.7 or 2.1.7 are release installs, not dev
            if _re.match(r"^v?\d+\.\d+", requested_revision):
                return False, None
            return True, commit_id if commit_id else None
        return False, None
    except Exception:
        return False, None


def _get_display_version():
    """
    Return the version string shown in the UI.

    - Release install (``@v2.1.6``):  ``"2.1.6"``
    - Dev install    (``@models``):   ``"2.1.6-dev+abc1234"``
    """
    base = _get_version()
    if not base:
        return ""
    is_dev, commit_hash = _get_dev_install_info()
    if is_dev and commit_hash:
        return f"{base}-dev+{commit_hash[:7]}"
    return base


# ---------------------------------------------------------------------------
# Update checker
# ---------------------------------------------------------------------------
_GITHUB_RELEASES_URL = (
    "https://api.github.com/repos/TheMRX13/MRX-AniWorld-Downloader/releases/latest"
)
_GITHUB_COMMITS_URL = (
    "https://api.github.com/repos/TheMRX13/MRX-AniWorld-Downloader/commits/models"
)
_UPDATE_CHECK_INTERVAL = 24 * 60 * 60  # 24 hours

_update_cache: dict = {
    "latest_version": None,
    "update_available": False,
    "release_url": None,
    "release_notes": None,
    "checked_at": 0.0,
    "error": None,
    "is_dev_install": False,
}


def _fetch_latest_release():
    """Return (version, release_url, release_notes) from the GitHub Releases API."""
    import json
    import urllib.request as _ureq

    try:
        req = _ureq.Request(
            _GITHUB_RELEASES_URL,
            headers={
                "User-Agent": "aniworld-update-checker/1.0",
                "Accept": "application/vnd.github+json",
            },
        )
        with _ureq.urlopen(req, timeout=10) as resp:
            data = json.load(resp)
        tag = data.get("tag_name", "")
        version = tag.lstrip("v")
        return version, data.get("html_url"), data.get("body") or ""
    except Exception:
        return None, None, None


def _fetch_latest_commit_sha():
    """Return the full SHA of the latest commit on the models branch."""
    import json
    import urllib.request as _ureq

    try:
        req = _ureq.Request(
            _GITHUB_COMMITS_URL,
            headers={
                "User-Agent": "aniworld-update-checker/1.0",
                "Accept": "application/vnd.github+json",
            },
        )
        with _ureq.urlopen(req, timeout=10) as resp:
            data = json.load(resp)
        return data.get("sha", None)
    except Exception:
        return None


def _do_update_check():
    import time
    from packaging.version import InvalidVersion, Version

    is_dev, full_commit_hash = _get_dev_install_info()
    local_base = _get_version()

    _update_cache["checked_at"] = time.time()
    _update_cache["is_dev_install"] = is_dev

    if is_dev:
        # Dev install: compare our commit SHA against the latest on models branch
        latest_sha = _fetch_latest_commit_sha()
        if latest_sha and full_commit_hash:
            update_available = not latest_sha.startswith(full_commit_hash[:7]) and latest_sha != full_commit_hash
            _update_cache["update_available"] = update_available
            _update_cache["latest_version"] = latest_sha[:7]
            _update_cache["release_url"] = (
                "https://github.com/TheMRX13/MRX-AniWorld-Downloader/commits/models"
            )
            _update_cache["release_notes"] = None
            _update_cache["error"] = None
        else:
            _update_cache["update_available"] = False
            _update_cache["latest_version"] = None
            _update_cache["error"] = "GitHub nicht erreichbar"
    else:
        # Release install: compare version numbers against latest GitHub Release
        latest, release_url, release_notes = _fetch_latest_release()
        _update_cache["latest_version"] = latest
        _update_cache["release_url"] = release_url
        _update_cache["release_notes"] = release_notes

        if latest and local_base:
            try:
                _update_cache["update_available"] = Version(latest) > Version(local_base)
                _update_cache["error"] = None
            except InvalidVersion:
                _update_cache["update_available"] = False
                _update_cache["error"] = "Versionsformat unbekannt"
        else:
            _update_cache["update_available"] = False
            _update_cache["error"] = "GitHub nicht erreichbar" if not latest else None



def _generate_pwa_icons():
    """Generate icon-192.png and icon-512.png in the static directory if missing.

    Uses only Python stdlib (struct + zlib) — no Pillow required.
    The icons are a solid #7c3aed (purple) square.
    """
    import os as _os
    static_dir = _os.path.join(_os.path.dirname(__file__), "static")

    def _png_bytes(size: int) -> bytes:
        """Create a minimal valid PNG: solid #7c3aed square of given size."""
        r, g, b = 0x7C, 0x3A, 0xED

        # Build raw image data: one filter byte (0) + RGB pixels per row
        row = bytes([0]) + bytes([r, g, b] * size)
        raw = row * size

        def _chunk(tag: bytes, data: bytes) -> bytes:
            length = struct.pack(">I", len(data))
            crc = struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
            return length + tag + data + crc

        signature = b"\x89PNG\r\n\x1a\n"
        ihdr = _chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0))
        idat = _chunk(b"IDAT", zlib.compress(raw, 9))
        iend = _chunk(b"IEND", b"")
        return signature + ihdr + idat + iend

    for size in (192, 512):
        path = _os.path.join(static_dir, f"icon-{size}.png")
        if not _os.path.exists(path):
            try:
                with open(path, "wb") as f:
                    f.write(_png_bytes(size))
                logger.debug("[PWA] Generated %s", path)
            except Exception as exc:
                logger.warning("[PWA] Could not generate icon-%s.png: %s", size, exc)



def _migrate_dotenv_to_db():
    """One-time migration: read ~/.aniworld/.env (if it exists) and import
    all known variables into the DB.  Runs only once — guarded by the
    'env_migrated' key in app_settings so subsequent starts skip it."""
    if get_setting("env_migrated") == "1":
        return

    from pathlib import Path
    env_path = Path.home() / ".aniworld" / ".env"
    if not env_path.exists():
        # Nothing to import — mark done so we never check again
        set_setting("env_migrated", "1")
        return

    # Parse the .env file: skip comments, handle KEY=VALUE and KEY="VALUE"
    parsed = {}
    try:
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key   = key.strip()
            value = value.strip().strip('"').strip("'")
            if key:
                parsed[key] = value
    except Exception as exc:
        import logging
        logging.getLogger(__name__).warning("env migration: could not read %s: %s", env_path, exc)
        return

    # Map: env var name → DB setting key
    mapping = {
        "ANIWORLD_DOWNLOAD_PATH":     "download_path",
        "ANIWORLD_LANG_SEPARATION":   "lang_separation",
        "ANIWORLD_DISABLE_ENGLISH_SUB": "disable_english_sub",
        "ANIWORLD_LANGUAGE":          "download_language",
        "ANIWORLD_PROVIDER":          "download_provider",
        "ANIWORLD_NAMING_TEMPLATE":   "naming_template",
        "ANIWORLD_SYNC_SCHEDULE":              "sync_schedule",
        "ANIWORLD_SYNC_LANGUAGE":              "sync_language",
        "ANIWORLD_SYNC_PROVIDER":              "sync_provider",
        "ANIWORLD_SYNC_PATH_UNAVAILABLE_ACTION": "sync_path_unavailable_action",
        "ANIWORLD_WEB_BASE_URL":      "web_base_url",
        "ANIWORLD_DEBUG_MODE":        "debug_mode",
        "ANIWORLD_WEB_ADMIN_USER":    "web_admin_user",
        "ANIWORLD_WEB_ADMIN_PASS":    "web_admin_pass",
        "ANIWORLD_WEB_SSO":           "web_sso",
        "ANIWORLD_WEB_FORCE_SSO":     "web_force_sso",
        "ANIWORLD_OIDC_ISSUER_URL":   "oidc_issuer_url",
        "ANIWORLD_OIDC_CLIENT_ID":    "oidc_client_id",
        "ANIWORLD_OIDC_CLIENT_SECRET":"oidc_client_secret",
        "ANIWORLD_OIDC_DISPLAY_NAME": "oidc_display_name",
        "ANIWORLD_OIDC_ADMIN_USER":   "oidc_admin_user",
        "ANIWORLD_OIDC_ADMIN_SUBJECT":"oidc_admin_subject",
    }

    imported = 0
    for env_key, db_key in mapping.items():
        value = parsed.get(env_key, "")
        if not value:
            continue  # not in .env or empty — leave DB default
        # Only import if DB has no value yet (don't overwrite user changes)
        if get_setting(db_key) not in (None, ""):
            continue
        set_setting(db_key, value)
        imported += 1

    set_setting("env_migrated", "1")
    import logging
    logging.getLogger(__name__).info(
        "env migration: imported %d setting(s) from %s", imported, env_path
    )


def _sync_db_settings_to_env():
    """On startup: read all persistent settings from DB and apply to os.environ.
    This means every os.environ.get("ANIWORLD_*") call elsewhere in the app
    will automatically pick up DB values without needing individual changes."""
    import os
    mapping = {
        "download_path":         "ANIWORLD_DOWNLOAD_PATH",
        "lang_separation":       "ANIWORLD_LANG_SEPARATION",
        "disable_english_sub":   "ANIWORLD_DISABLE_ENGLISH_SUB",
        "download_language":     "ANIWORLD_LANGUAGE",
        "download_provider":     "ANIWORLD_PROVIDER",
        "naming_template":       "ANIWORLD_NAMING_TEMPLATE",
        "sync_schedule":                  "ANIWORLD_SYNC_SCHEDULE",
        "sync_language":                  "ANIWORLD_SYNC_LANGUAGE",
        "sync_provider":                  "ANIWORLD_SYNC_PROVIDER",
        "sync_path_unavailable_action":   "ANIWORLD_SYNC_PATH_UNAVAILABLE_ACTION",
        "sync_error_retries":             "ANIWORLD_SYNC_ERROR_RETRIES",
        "sync_error_retry_time":          "ANIWORLD_SYNC_ERROR_RETRY_TIME",
        "web_base_url":          "ANIWORLD_WEB_BASE_URL",
        "debug_mode":            "ANIWORLD_DEBUG_MODE",
        "oidc_issuer_url":       "ANIWORLD_OIDC_ISSUER_URL",
        "oidc_client_id":        "ANIWORLD_OIDC_CLIENT_ID",
        "oidc_client_secret":    "ANIWORLD_OIDC_CLIENT_SECRET",
        "oidc_display_name":     "ANIWORLD_OIDC_DISPLAY_NAME",
        "oidc_admin_user":       "ANIWORLD_OIDC_ADMIN_USER",
        "oidc_admin_subject":    "ANIWORLD_OIDC_ADMIN_SUBJECT",
        "web_sso":               "ANIWORLD_WEB_SSO",
        "web_force_sso":         "ANIWORLD_WEB_FORCE_SSO",
    }
    for db_key, env_key in mapping.items():
        val = get_setting(db_key)
        if val is not None and val != "":
            os.environ[env_key] = val


_tmdb_keywords_worker_started = False

def _tmdb_keywords_sync_worker():
    """Background task to sync the daily TMDB keyword export."""
    import time
    import gzip
    import urllib.request
    from datetime import datetime
    
    while True:
        try:
            from .db import get_setting
            # Only run if advanced search is enabled in config
            if get_setting("cineinfo_advanced_search", "0") != "1":
                time.sleep(3600)
                continue
                
            yesterday_str = (datetime.utcnow() - timedelta(days=1)).strftime("%m_%d_%Y")
            url = f"https://files.tmdb.org/p/exports/keyword_ids_{yesterday_str}.json.gz"
            dest_file = ANIWORLD_CONFIG_DIR / "keyword_ids.json"
            
            download_needed = True
            if dest_file.exists():
                mtime = datetime.utcfromtimestamp(dest_file.stat().st_mtime)
                if mtime.date() == datetime.utcnow().date():
                    download_needed = False
            
            if download_needed:
                logger.info(f"Downloading TMDB keywords from {url}")
                req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
                try:
                    with urllib.request.urlopen(req, timeout=30) as response:
                        with gzip.GzipFile(fileobj=response) as gz:
                            data = gz.read()
                            with open(dest_file, "wb") as f:
                                f.write(data)
                    logger.info("Successfully downloaded TMDB keywords.")
                except Exception as e:
                    logger.warning(f"Failed to download TMDB keywords: {e}")
                    
        except Exception as e:
            logger.error(f"Error in TMDB keywords sync worker: {e}")
            
        time.sleep(3600)  # Check every hour

def _ensure_tmdb_keywords_sync_worker():
    global _tmdb_keywords_worker_started
    if _tmdb_keywords_worker_started:
        return
    _tmdb_keywords_worker_started = True
    thread = threading.Thread(target=_tmdb_keywords_sync_worker, daemon=True)
    thread.start()

def create_app(auth_enabled=False, sso_enabled=False, force_sso=False):
    import os

    _generate_pwa_icons()

    app = Flask(__name__)
    app.config['TEMPLATES_AUTO_RELOAD'] = False # DKS, nur für Entwicklung
    app_version = _get_display_version()

    base_url = os.environ.get("ANIWORLD_WEB_BASE_URL", "").strip().rstrip("/")
    if base_url:
        from urllib.parse import urlparse

        parsed = urlparse(base_url)
        scheme = parsed.scheme or "https"
        host = parsed.netloc

        # WSGI middleware that overrides scheme/host before Flask sees the request
        _inner_wsgi = app.wsgi_app

        def _proxy_wsgi(environ, start_response):
            environ["wsgi.url_scheme"] = scheme
            if host:
                environ["HTTP_HOST"] = host
            return _inner_wsgi(environ, start_response)

        app.wsgi_app = _proxy_wsgi

    if auth_enabled:
        from .auth import (
            auth_bp,
            get_current_user,
            get_or_create_secret_key,
            init_oidc,
            login_required,
            refresh_session_role,
        )
        from .db import has_any_admin, init_db

        app.secret_key = get_or_create_secret_key()
        app.config["SESSION_COOKIE_HTTPONLY"] = True
        app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
        app.config["PERMANENT_SESSION_LIFETIME"] = 86400  # 24 hours

        csrf = CSRFProtect()

        from .auth import limiter as _auth_limiter

        init_db()

        # Check HTTPS AFTER init_db() so the DB-stored web_base_url is available as fallback
        from .db import get_setting as _get_setting
        _db_base_url = (_get_setting("web_base_url") or "").strip().rstrip("/")
        _effective_base_url = base_url or _db_base_url
        _https_forced = os.environ.get("ANIWORLD_HTTPS", "").lower() in ("1", "true", "yes")
        if _effective_base_url.startswith("https") or _https_forced:
            app.config["SESSION_COOKIE_SECURE"] = True
        else:
            import logging as _logging
            _logging.getLogger(__name__).warning(
                "Auth is enabled but no HTTPS was detected. Session cookies will NOT be "
                "marked Secure. Set ANIWORLD_WEB_BASE_URL to an https:// URL or set "
                "ANIWORLD_HTTPS=1 (e.g. when running behind a TLS-terminating reverse proxy)."
            )
        app.register_blueprint(auth_bp)
        app.config["WTF_CSRF_TIME_LIMIT"] = None  # Session lifetime controls expiry
        csrf.init_app(app)
        _auth_limiter.init_app(app)

        @app.errorhandler(CSRFError)
        def handle_csrf_error(e):
            from flask import redirect, render_template, url_for
            # API requests get a JSON error; form submissions go back to login
            if request.is_json or request.path.startswith("/api/"):
                return jsonify({"error": "CSRF token missing or expired"}), 400
            return render_template(
                "login.html",
                error="Your session has expired. Please log in again.",
                oidc_enabled=app.config.get("OIDC_ENABLED", False),
                oidc_display_name=app.config.get("OIDC_DISPLAY_NAME", "SSO"),
                force_sso=app.config.get("FORCE_SSO", False),
            ), 400

        if sso_enabled:
            init_oidc(app, force_sso=force_sso)
        else:
            app.config["OIDC_ENABLED"] = False
            app.config["OIDC_DISPLAY_NAME"] = "SSO"
            app.config["OIDC_ADMIN_USER"] = None
            app.config["OIDC_ADMIN_SUBJECT"] = None
            app.config["FORCE_SSO"] = False

        @app.before_request
        def _check_setup():
            if request.endpoint and request.endpoint.startswith("auth."):
                return None
            if request.endpoint == "static":
                return None
            if not app.config.get("FORCE_SSO", False) and not has_any_admin():
                return redirect(url_for("auth.setup"))
            return None

        @app.before_request
        def _refresh_role():
            return refresh_session_role()

        @app.context_processor
        def _inject_auth():
            from .db import get_setting as _get_setting
            return {
                "current_user": get_current_user(),
                "auth_enabled": True,
                "oidc_enabled": app.config.get("OIDC_ENABLED", False),
                "oidc_display_name": app.config.get("OIDC_DISPLAY_NAME", "SSO"),
                "force_sso": app.config.get("FORCE_SSO", False),
                "app_version": app_version,
                "update_available": _update_cache["update_available"],
                "cineinfo_advanced_search": _get_setting("cineinfo_advanced_search", "0") == "1",
            }
    else:
        # No-auth mode still needs a secret key for flask.session
        if not app.secret_key:
            app.secret_key = secrets.token_hex(32)

        @app.before_request
        def _set_noauth_session():
            """In no-auth mode expose a virtual admin/user=0 so notification APIs work."""
            from flask import session as _sess
            if not _sess.get("user_id"):
                _sess["user_id"]   = 0
                _sess["user_role"] = "admin"
                _sess["user_name"] = "admin"

        @app.context_processor
        def _inject_no_auth():
            from .db import get_setting as _get_setting
            return {
                "current_user": None,
                "auth_enabled": False,
                "oidc_enabled": False,
                "oidc_display_name": "SSO",
                "force_sso": False,
                "app_version": app_version,
                "update_available": _update_cache["update_available"],
                "cineinfo_advanced_search": _get_setting("cineinfo_advanced_search", "0") == "1",
            }

    # Initialize download queue, custom paths and autosync (works with or without auth)
    init_queue_db()
    init_custom_paths_db()
    init_autosync_db()
    init_favourites_db()
    init_library_db()
    init_app_settings_db()
    init_tmdb_cache_db()
    init_browse_cache_db()
    init_notification_db()
    init_upscale_queue_db()
    init_mediascan_db()
    _load_queue_paused_from_db()
    # Start MediaScan 24-h background scheduler
    _start_mediascan_scheduler()

    # Auto-generate external API key on first run
    if not get_setting("external_api_key", ""):
        set_setting("external_api_key", secrets.token_hex(32))

    # Apply saved DNS setting on startup
    _saved_dns_mode   = get_setting("dns_mode", "system")
    _saved_dns_server = get_setting("dns_server", "")
    if _saved_dns_mode != "system":
        _server = _DNS_PRESETS.get(_saved_dns_mode) or _saved_dns_server or None
        if _server:
            _apply_dns_patch(_server, mode=_saved_dns_mode)

    # Apply saved filmpalast subfolder setting on startup
    os.environ["FILMPALAST_MOVIE_SUBFOLDER"] = get_setting("filmpalast_movie_subfolder", "0")

    # One-time migration: import .env values into DB (runs only once)
    _migrate_dotenv_to_db()

    # Apply all persistent DB settings to os.environ on startup
    _sync_db_settings_to_env()

    # Start library file watcher (watchdog-based, event-driven rescans)
    from .library_watcher import get_watcher as _get_lib_watcher
    _lib_watcher = _get_lib_watcher()

    def _lib_watcher_scan_callback(path_key: str):
        """Called by watchdog when files change in a watched folder."""
        import time as _t
        # Find the matching target and rescan only that one
        targets = _lib_build_scan_targets()
        lang_sep = os.environ.get("ANIWORLD_LANG_SEPARATION", "0") == "1"
        for (label, cp_id, base_path) in targets:
            pk = "default" if cp_id is None else str(cp_id)
            if pk == path_key:
                _lib_do_scan([(label, cp_id, base_path)], lang_sep)
                break

    def _start_lib_watcher():
        targets = _lib_build_scan_targets()
        _lib_watcher.start(targets, _lib_watcher_scan_callback)
        # Trigger a full scan on startup so the cache is always fresh
        lang_sep = os.environ.get("ANIWORLD_LANG_SEPARATION", "0") == "1"
        _lib_do_scan(targets, lang_sep)

    # Defer watcher start slightly so Flask is fully up first
    import threading as _threading
    _threading.Timer(1.5, _start_lib_watcher).start()

    # Wire up captcha hooks
    from ..playwright import captcha as _captcha_mod
    _captcha_mod._on_captcha_start = set_captcha_url
    _captcha_mod._on_captcha_end = clear_captcha_url

    # In debug mode, Flask's reloader runs this in both the parent and child
    # process. Only start workers in the child (actual server) process
    # to avoid duplicate ffmpeg downloads.
    _debug = os.getenv("ANIWORLD_DEBUG_MODE", "0") == "1"
    if not _debug or os.environ.get("WERKZEUG_RUN_MAIN") == "true":
        _ensure_queue_worker()
        _ensure_autosync_worker()
        _ensure_upscale_worker()
        _ensure_tmdb_keywords_sync_worker()
        # Auto-download mpv.exe on Windows if missing
        try:
            from ..autodeps import ensure_mpv_windows_async
            ensure_mpv_windows_async()
        except Exception:
            pass

    @app.teardown_appcontext
    def _close_db_connection(exception):
        from flask import g
        conn = g.pop("db_conn", None)
        if conn:
            try:
                conn.close()
            except Exception:
                pass

    @app.after_request
    def _set_security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault(
            "Referrer-Policy", "strict-origin-when-cross-origin"
        )
        # Globally disable browser caching for dynamic settings and notification settings APIs
        if request.path.startswith("/api/settings") or request.path.startswith("/api/notif") or request.path.startswith("/api/autosync"):
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
        return response

    @app.before_request
    def _enforce_json_content_type():
        """Reject non-JSON POST/PUT/DELETE on API routes to prevent form-based CSRF bypass."""
        if request.method in ("POST", "PUT", "DELETE") and request.path.startswith(
            "/api/"
        ):
            if request.content_length and request.content_length > 0:
                ct = request.content_type or ""
                if not ct.startswith("application/json"):
                    return jsonify(
                        {"error": "Content-Type must be application/json"}
                    ), 415

    @app.route("/sw.js")
    def service_worker():
        import os as _os
        from flask import send_from_directory, make_response
        static_dir = _os.path.join(_os.path.dirname(__file__), "static")
        resp = make_response(send_from_directory(static_dir, "sw.js"))
        resp.headers["Service-Worker-Allowed"] = "/"
        resp.headers["Cache-Control"] = "no-cache"
        return resp

    @app.route("/")
    def index():
        sto_lang_labels = {"1": "German Dub", "2": "English Dub"}
        return render_template(
            "index.html",
            lang_labels=LANG_LABELS,
            sto_lang_labels=sto_lang_labels,
            supported_providers=WORKING_PROVIDERS,
        )

    def _filmpalast_search(keyword):
        """Search filmpalast.to via autocomplete and return list of {title, url} dicts."""
        import urllib.parse as _up
        import requests as _req
        try:
            url = f"https://filmpalast.to/autocomplete.php?term={_up.quote(keyword)}"
            resp = _req.get(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "Accept": "application/json, text/javascript, */*",
                    "Accept-Encoding": "gzip, deflate",  # requests decompresses automatically
                },
                timeout=8,
            )
            resp.raise_for_status()
            if not resp.text.strip():
                return []  # empty response = no results
            titles = resp.json()
        except Exception as e:
            logger.warning("FilmPalast autocomplete failed: %s", e)
            return []

        # The API returns either a list ["Title1", "Title2", ...]
        # or a dict {"0": "Title1", "1": "Title2", ...} depending on the query.
        # Normalise to a flat list of title strings.
        if isinstance(titles, dict):
            title_list = list(titles.values())
        elif isinstance(titles, list):
            title_list = titles
        else:
            return []

        candidates = []
        seen = set()
        for title in title_list:
            if not isinstance(title, str) or not title.strip():
                continue
            slug = _filmpalast_title_to_slug(title)
            if not slug:
                continue
            fp_url = f"https://filmpalast.to/stream/{slug}"
            if fp_url not in seen:
                seen.add(fp_url)
                candidates.append({"title": title, "url": fp_url})

        if not candidates:
            return []

        # Validate each candidate URL exists (our slug may differ from the real slug).
        # Run HEAD requests in parallel so the total wait is ~1 request RTT, not N×RTT.
        from concurrent.futures import ThreadPoolExecutor, as_completed
        import requests as _req2

        _val_headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        }

        def _head_ok(candidate):
            try:
                r = _req2.head(candidate["url"], headers=_val_headers, timeout=5, allow_redirects=True)
                return candidate if r.status_code == 200 else None
            except Exception:
                return None

        results = []
        with ThreadPoolExecutor(max_workers=10) as pool:
            futures = {pool.submit(_head_ok, c): c for c in candidates}
            for fut in as_completed(futures):
                ok = fut.result()
                if ok:
                    results.append(ok)

        # Restore original autocomplete order
        order = {c["url"]: i for i, c in enumerate(candidates)}
        results.sort(key=lambda c: order.get(c["url"], 9999))
        return results

    def _filmpalast_title_to_slug(title):
        """Convert a movie title to the filmpalast URL slug.

        Strategy: lowercase, replace umlauts, replace non-alphanumeric with
        hyphens, collapse consecutive hyphens, strip leading/trailing hyphens.
        """
        import unicodedata
        umap = {"ä": "ae", "ö": "oe", "ü": "ue", "Ä": "ae", "Ö": "oe", "Ü": "ue", "ß": "ss"}
        s = title
        for k, v in umap.items():
            s = s.replace(k, v)
        # Normalize remaining unicode chars
        s = unicodedata.normalize("NFKD", s)
        s = s.encode("ascii", "ignore").decode("ascii")
        s = s.lower()
        import re as _r
        s = _r.sub(r"[^a-z0-9]+", "-", s)
        s = s.strip("-")
        return s

    @app.route("/api/search", methods=["POST"])
    def api_search():
        data = request.get_json(silent=True) or {}
        keyword = (data.get("keyword") or "").strip()
        keyword = re.sub(r"!+$", "", keyword).strip()
        site = (data.get("site") or "aniworld").strip()
        if not keyword:
            return jsonify({"error": "keyword is required"}), 400

        results = []

        def _get_site_results(kw, site_name):
            site_res = []
            if site_name == "sto":
                items = query_s_to(kw) or []
                if isinstance(items, dict): items = [items]
                for item in items:
                    link = item.get("link") or item.get("url", "")
                    if _STO_SERIES_LINK_PATTERN.match(link):
                        title = _html_unescape(item.get("title") or item.get("name", "Unknown")).replace("<em>", "").replace("</em>", "")
                        site_res.append({"title": title, "url": f"https://s.to{link}"})
            else:
                items = aniworld_query(kw) or []
                if isinstance(items, dict): items = [items]
                for item in items:
                    link = item.get("link") or item.get("url", "")
                    if _SERIES_LINK_PATTERN.match(link):
                        title = _html_unescape(item.get("title") or item.get("name", "Unknown")).replace("<em>", "").replace("</em>", "")
                        site_res.append({"title": title, "url": f"https://aniworld.to{link}"})
            return site_res

        if site == "filmpalast":
            results = _filmpalast_search(keyword)
        else:
            results = _get_site_results(keyword, site)
            
            # Fallback for apostrophes (AniWorld's search is broken for titles with apostrophes)
            if not results and ("'" in keyword or "’" in keyword):
                # Strategy: search for the part before the apostrophe
                clean = keyword.replace("’", "'").split("'")[0].strip()
                if clean and clean != keyword:
                    logger.debug("[CineInfo] Fallback 1: Searching for %r", clean)
                    results = _get_site_results(clean, site)
                
                # Secondary fallback: just remove the apostrophe
                if not results:
                    clean2 = keyword.replace("'", "").replace("’", "")
                    logger.debug("[CineInfo] Fallback 2: Searching for %r", clean2)
                    results = _get_site_results(clean2, site)

            # Fallback for hyphens / dashes
            if not results and ("-" in keyword or "–" in keyword):
                # Strategy: search for the part before the hyphen
                clean_hyphen = re.split(r"[-–]", keyword)[0].strip()
                if clean_hyphen and clean_hyphen != keyword:
                    logger.debug("[CineInfo] Fallback Hyphen: Searching for %r", clean_hyphen)
                    results = _get_site_results(clean_hyphen, site)

        return jsonify({"results": results})


    @app.route("/api/tmdb/genres")
    def api_tmdb_genres():
        """Fetch TV and Movie genres from TMDB and cache them."""
        import requests as _req
        from .db import get_setting
        api_key = get_setting("cineinfo_tmdb_api_key", "").strip()
        if not api_key:
            return jsonify({"error": "No TMDB API Key"}), 400
        
        try:
            headers = {"accept": "application/json"}
            tv_resp = _req.get(f"https://api.themoviedb.org/3/genre/tv/list?language=de&api_key={api_key}", headers=headers, timeout=10)
            tv_resp.raise_for_status()
            tv_data = tv_resp.json()
            
            movie_resp = _req.get(f"https://api.themoviedb.org/3/genre/movie/list?language=de&api_key={api_key}", headers=headers, timeout=10)
            movie_resp.raise_for_status()
            movie_data = movie_resp.json()
                
            return jsonify({
                "tv": tv_data.get("genres", []),
                "movie": movie_data.get("genres", [])
            })
        except Exception as e:
            logger.error(f"Error fetching TMDB genres: {e}")
            return jsonify({"error": str(e)}), 500

    @app.route("/api/tmdb/keywords")
    def api_tmdb_keywords():
        """Autocomplete search over the downloaded keyword_ids.json file."""
        query = request.args.get("q", "").strip().lower()
        if not query or len(query) < 2:
            return jsonify({"results": []})
        
        dest_file = ANIWORLD_CONFIG_DIR / "keyword_ids.json"
        if not dest_file.exists():
            return jsonify({"error": "Keyword data not downloaded yet. Please wait."}), 404
            
        results = []
        try:
            with open(dest_file, "r", encoding="utf-8") as f:
                for line in f:
                    if query in line.lower():
                        data = json.loads(line)
                        results.append(data)
                        if len(results) >= 20:
                            break
            return jsonify({"results": results})
        except Exception as e:
            logger.error(f"Error searching TMDB keywords: {e}")
            return jsonify({"error": str(e)}), 500

    @app.route("/api/tmdb/discover")
    def api_tmdb_discover():
        """Search TMDB discover API with given params."""
        import requests as _req
        from .db import get_setting
        api_key = get_setting("cineinfo_tmdb_api_key", "").strip()
        if not api_key:
            return jsonify({"error": "No TMDB API Key"}), 400
            
        params = request.args.to_dict()
        media_type = params.pop("type", "tv")
        if media_type not in ["tv", "movie"]:
            media_type = "tv"
            
        import urllib.parse
        args = dict(request.args)
        args["api_key"] = api_key
        args.pop("type", None)
        
        # Map sorting key for TV shows / movies since TMDB uses different release date keys
        if "sort_by" in args:
            sort_val = args["sort_by"]
            if isinstance(sort_val, list):
                sort_val = sort_val[0] if sort_val else ""
            
            if isinstance(sort_val, str):
                if media_type == "tv" and sort_val.startswith("primary_release_date"):
                    args["sort_by"] = sort_val.replace("primary_release_date", "first_air_date")
                elif media_type == "movie" and sort_val.startswith("first_air_date"):
                    args["sort_by"] = sort_val.replace("first_air_date", "primary_release_date")
                    
        qs = urllib.parse.urlencode(args, doseq=True)
        url = f"https://api.themoviedb.org/3/discover/{media_type}?{qs}"
        logger.info(f"Discovering on TMDB: /discover/{media_type} (params redacted)")
        try:
            resp = _req.get(url, headers={"accept": "application/json"}, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            return jsonify(data)
        except Exception as e:
            logger.error(f"Error discovering on TMDB: {e}")
            return jsonify({"error": str(e)}), 500

    @app.route("/api/tmdb/details")
    def api_tmdb_details():
        """Fetch details for a specific TMDB item (e.g., to get number of seasons)."""
        import requests as _req
        from .db import get_setting
        api_key = get_setting("cineinfo_tmdb_api_key", "").strip()
        if not api_key:
            return jsonify({"error": "No TMDB API Key"}), 400
            
        tmdb_id = request.args.get("id")
        media_type = request.args.get("type", "tv")
        
        if not tmdb_id or media_type not in ["tv", "movie"]:
            return jsonify({"error": "Invalid params"}), 400
            
        url = f"https://api.themoviedb.org/3/{media_type}/{tmdb_id}?language=de&api_key={api_key}&append_to_response=translations"
        try:
            resp = _req.get(url, headers={"accept": "application/json"}, timeout=10)
            resp.raise_for_status()
            data = resp.json()
            return jsonify(data)
        except Exception as e:
            logger.error(f"Error fetching TMDB details: {e}")
            return jsonify({"error": str(e)}), 500

    @app.route("/api/series")
    def api_series():
        url = request.args.get("url", "").strip()
        if not url:
            return jsonify({"error": "url is required"}), 400

        # FilmPalast: use episode object directly as metadata source (no series class)
        if _is_filmpalast_url(url):
            try:
                from ..models.filmpalast_to.episode import FilmPalastEpisode
                ep = FilmPalastEpisode(url=url)
                poster = ep.image_url
                if poster and poster.startswith("/"):
                    poster = f"https://filmpalast.to{poster}"
                return jsonify({
                    "title": ep.title_de or "",
                    "poster_url": _poster_proxy(poster),
                    "description": ep.description or "",
                    "genres": ep.genres or [],
                    "release_year": str(ep.release_year) if ep.release_year else "",
                    "is_movie": True,
                    "available_providers": ep.available_providers,
                })
            except Exception as e:
                logger.error(f"FilmPalast series fetch failed: {e}", exc_info=True)
                return jsonify({"error": str(e)}), 500

        try:
            prov = resolve_provider(url)
            series = prov.series_cls(url=url)
            poster = getattr(series, "poster_url", None)
            # s.to returns relative poster paths - make them absolute
            if poster and poster.startswith("/"):
                from urllib.parse import urlparse

                parsed = urlparse(url)
                poster = f"{parsed.scheme}://{parsed.netloc}{poster}"
            return jsonify(
                {
                    "title": _html_unescape(series.title),
                    "poster_url": _poster_proxy(poster),
                    "description": getattr(series, "description", ""),
                    "genres": getattr(series, "genres", []),
                    "release_year": getattr(series, "release_year", ""),
                    "imdb_id": getattr(series, "imdb", None) or None,
                }
            )
        except Exception as e:
            logger.error(f"Series fetch failed: {e}", exc_info=True)
            return jsonify({"error": str(e)}), 500

    @app.route("/api/seasons")
    def api_seasons():
        url = request.args.get("url", "").strip()
        if not url:
            return jsonify({"error": "url is required"}), 400

        # FilmPalast: return a single fake "season 1 / episode 1 = the movie itself"
        if _is_filmpalast_url(url):
            return jsonify({"seasons": [{"url": url, "season_number": 1, "episode_count": 1, "are_movies": True, "is_single_movie": True}]})

        try:
            prov = resolve_provider(url)
            series = prov.series_cls(url=url)
            seasons_data = []
            for season in series.seasons:
                seasons_data.append(
                    {
                        "url": season.url,
                        "season_number": season.season_number,
                        "episode_count": season.episode_count,
                        "are_movies": getattr(season, "are_movies", False),
                    }
                )
            return jsonify({"seasons": seasons_data})
        except Exception as e:
            logger.error(f"Seasons fetch failed: {e}", exc_info=True)
            return jsonify({"error": str(e)}), 500

    @app.route("/api/episodes")
    def api_episodes():
        url = request.args.get("url", "").strip()
        if not url:
            return jsonify({"error": "url is required"}), 400

        # FilmPalast: return the movie itself as a single episode entry
        if _is_filmpalast_url(url):
            try:
                from ..models.filmpalast_to.episode import FilmPalastEpisode
                ep = FilmPalastEpisode(url=url)
                return jsonify({"episodes": [{
                    "url": url,
                    "episode_number": 1,
                    "season_number": 1,
                    "title_de": ep.title_de or "",
                    "title_en": ep.title_de or "",
                    "downloaded": False,
                    "languages": ["German Dub"],
                }]})
            except Exception as e:
                logger.error(f"FilmPalast episodes fetch failed: {e}", exc_info=True)
                return jsonify({"error": str(e)}), 500

        try:
            prov = resolve_provider(url)
            # Pass series to avoid broken series URL reconstruction in s.to
            # season model (its fallback splits on "-" which fails)
            series_url = re.sub(r"/staffel-\d+/?$", "", url)
            series_url = re.sub(r"/filme/?$", "", series_url)
            try:
                series = prov.series_cls(url=series_url)
            except Exception:
                series = None
            season = prov.season_cls(url=url, series=series)

            # Scan download directory for downloaded episodes.
            # Uses S##E### filename matching so it works regardless of
            # which NAMING_TEMPLATE was active when files were downloaded.
            from pathlib import Path

            lang_sep = os.environ.get("ANIWORLD_LANG_SEPARATION", "0") == "1"
            lang_folders = ["german-dub", "english-sub", "german-sub", "english-dub"]

            raw = os.environ.get("ANIWORLD_DOWNLOAD_PATH", "")
            if raw:
                dl_base = Path(raw).expanduser()
                if not dl_base.is_absolute():
                    dl_base = Path.home() / dl_base
            else:
                dl_base = Path.home() / "Downloads"

            # Collect all scan roots: default + custom paths
            scan_roots = [dl_base]
            for cp in get_custom_paths():
                cp_path = Path(cp["path"]).expanduser()
                if not cp_path.is_absolute():
                    cp_path = Path.home() / cp_path
                scan_roots.append(cp_path)

            # Build set of (season_num, episode_num) found on disk
            downloaded_eps = set()
            try:
                title_clean = ""
                if series:
                    title_clean = (
                        getattr(series, "title_cleaned", None)
                        or getattr(series, "title", "")
                    ).lower()
                if title_clean:
                    ep_re = re.compile(r"S(\d{2})E(\d{2,3})", re.IGNORECASE)
                    all_bases = []
                    for root in scan_roots:
                        if lang_sep:
                            all_bases.extend([root / lf for lf in lang_folders])
                        else:
                            all_bases.append(root)
                    for base in all_bases:
                        if not base.is_dir():
                            continue
                        for folder in base.iterdir():
                            if (
                                not folder.is_dir()
                                or not folder.name.lower().startswith(title_clean)
                            ):
                                continue
                            for f in folder.rglob("*"):
                                if f.is_file():
                                    m = ep_re.search(f.name)
                                    if m:
                                        downloaded_eps.add(
                                            (int(m.group(1)), int(m.group(2)))
                                        )
            except Exception:
                pass

            # Parse language flags per episode from the already-fetched season HTML
            # (no extra network requests — flags are embedded in the season page)
            ep_languages: dict[str, list[str]] = {}
            try:
                s_html = getattr(season, "_html", None) or ""
                _is_sto = "serienstream" in url or "/serie/" in url

                if _is_sto:
                    # Determine actual base domain from the season URL
                    _sto_base = "https://serienstream.to" if "serienstream" in url else "https://s.to"
                    # s.to: <tr class="episode-row" onclick="window.location='/serie/.../episode-X'">
                    #         <td class="episode-language-cell"> <svg class="svg-flag-german"> ...
                    # Trailing quote prevents svg-flag-german matching svg-flag-english-german
                    _sto_flag_map = [
                        ('svg-flag-german"',          "German Dub"),
                        ('svg-flag-english"',         "English Dub"),
                        ('svg-flag-english-german"',  "German Sub"),
                        ('svg-flag-english-english"', "English Sub"),
                    ]
                    for _tr_m in re.finditer(r'<tr[^>]+class="episode-row[^"]*"[^>]*onclick="[^"]*\'(/serie/[^\']+)\'"', s_html):
                        _ep_path = _tr_m.group(1)
                        _ep_url = _sto_base + _ep_path
                        _tr_end = s_html.find("</tr>", _tr_m.start())
                        _tr_chunk = s_html[_tr_m.start():_tr_end]
                        _langs = [lbl for _cls, lbl in _sto_flag_map if _cls in _tr_chunk]
                        ep_languages[_ep_url] = _langs
                else:
                    # AniWorld: <td class="editFunctions"> with <img src=".../german.svg">
                    _flag_map = {
                        "/german.svg":           "German Dub",
                        "/japanese-german.svg":  "German Sub",
                        "/japanese-english.svg": "English Sub",
                        "/english.svg":          "English Dub",
                    }
                    _marker = 'itemtype="http://schema.org/Episode"'
                    _pos = 0
                    while True:
                        _pos = s_html.find(_marker, _pos)
                        if _pos == -1:
                            break
                        _tr_s = s_html.rfind("<tr", 0, _pos)
                        _tr_e = s_html.find("</tr>", _pos)
                        if _tr_s == -1 or _tr_e == -1:
                            break
                        _tr = s_html[_tr_s:_tr_e]
                        _ep_url = None
                        _up = _tr.find('itemprop="url"')
                        if _up != -1:
                            _hs = _tr.find('href="', _up) + 6
                            _he = _tr.find('"', _hs)
                            _href = _tr[_hs:_he]
                            _ep_url = ("https://aniworld.to" + _href) if _href.startswith("/") else _href
                        if not _ep_url:
                            _hp = _tr.find("film-")
                            if _hp != -1:
                                _hs = _tr.rfind('href="', 0, _hp) + 6
                                _he = _tr.find('"', _hs)
                                _href = _tr[_hs:_he]
                                _ep_url = ("https://aniworld.to" + _href) if _href.startswith("/") else _href
                        if _ep_url:
                            _ed = _tr.find('class="editFunctions"')
                            if _ed != -1:
                                _ee = _tr.find("</td>", _ed)
                                _edit = _tr[_ed:_ee]
                                _langs = [lbl for src, lbl in _flag_map.items() if src in _edit]
                                ep_languages[_ep_url] = _langs
                        _pos = _tr_e
            except Exception as _lang_exc:
                logger.debug("[api_episodes] language flag parsing failed: %s", _lang_exc)

            episodes_data = []
            for ep in season.episodes:
                downloaded = (
                    ep.season.season_number,
                    ep.episode_number,
                ) in downloaded_eps

                episodes_data.append(
                    {
                        "url": ep.url,
                        "episode_number": ep.episode_number,
                        "title_de": getattr(ep, "title_de", ""),
                        "title_en": getattr(ep, "title_en", ""),
                        "downloaded": downloaded,
                        "languages": ep_languages.get(ep.url, []),
                    }
                )
            return jsonify({"episodes": episodes_data})
        except Exception as e:
            logger.error(f"Episodes fetch failed: {e}", exc_info=True)
            return jsonify({"error": str(e)}), 500

    @app.route("/api/providers")
    def api_providers():
        url = request.args.get("url", "").strip()
        if not url:
            return jsonify({"error": "url is required"}), 400

        try:
            prov = resolve_provider(url)
            episode = prov.episode_cls(url=url)
            pd = episode.provider_data

            disable_eng_sub = os.environ.get("ANIWORLD_DISABLE_ENGLISH_SUB", "0") == "1"
            provider_info = {}

            if hasattr(pd, "_data"):
                # AniWorld: ProviderData object
                lang_tuple_to_label = {}
                for key, (audio, subtitles) in LANG_KEY_MAP.items():
                    label = LANG_LABELS.get(key)
                    if label:
                        lang_tuple_to_label[(audio.value, subtitles.value)] = label

                for (audio, subtitles), providers in pd._data.items():
                    label = lang_tuple_to_label.get((audio.value, subtitles.value))
                    if not label:
                        continue
                    if disable_eng_sub and label == "English Sub":
                        continue
                    working = [p for p in providers.keys() if p in WORKING_PROVIDERS]
                    if working:
                        provider_info[label] = working
            else:
                # s.to: plain dict with (Audio, Subtitles) enum tuple keys
                sto_label_map = {
                    ("German", "None"): "German Dub",
                    ("English", "None"): "English Dub",
                }
                for (audio, subtitles), providers in pd.items():
                    label = sto_label_map.get((audio.value, subtitles.value))
                    if not label:
                        continue
                    working = [p for p in providers.keys() if p in WORKING_PROVIDERS]
                    if working:
                        provider_info[label] = working

            return jsonify({"providers": provider_info})
        except Exception as e:
            logger.error(f"Providers fetch failed: {e}", exc_info=True)
            return jsonify({"error": str(e)}), 500

    @app.route("/api/download", methods=["POST"])
    def api_download():
        data = request.get_json(silent=True) or {}
        episodes = data.get("episodes", [])
        language = data.get("language", "German Dub")
        provider = data.get("provider", "VOE")
        title = data.get("title", "Unknown")
        series_url = str(data.get("series_url", "")).strip().rstrip("/")
        if not series_url:
            return jsonify({"error": "series_url is required"}), 400

        if not episodes:
            return jsonify({"error": "episodes list is required"}), 400

        if (
            language == "English Sub"
            and os.environ.get("ANIWORLD_DISABLE_ENGLISH_SUB", "0") == "1"
        ):
            return jsonify({"error": "English Sub downloads are disabled"}), 403

        username = None
        if auth_enabled:
            user = get_current_user()
            if user:
                username = (
                    user.get("username")
                    if isinstance(user, dict)
                    else getattr(user, "username", None)
                )

        custom_path_id = data.get("custom_path_id")

        # Global lock to prevent race conditions during duplicate check + add
        from threading import Lock
        if not hasattr(app, "_dl_lock"):
            app._dl_lock = Lock()

        with app._dl_lock:
            # Check for duplicates before adding to queue
            from .db import is_series_queued_or_running
            if is_series_queued_or_running(series_url, language, requested_episodes=episodes):
                return jsonify({"error": "Diese Episoden befinden sich bereits in der Warteschlange (gleiche Sprache)."}), 400

            queue_id = add_to_queue(
                title,
                series_url,
                episodes,
                language,
                provider,
                username,
                custom_path_id=custom_path_id,
            )
        return jsonify({"queue_id": queue_id})

    @app.route("/api/queue")
    def api_queue():
        from ..models.common.common import get_ffmpeg_progress
        from .db import get_general_stats

        items = get_queue()
        ffmpeg_pct = get_ffmpeg_progress()
        
        return jsonify({
            "items": items,
            "ffmpeg_progress": ffmpeg_pct,
            "paused": is_queue_paused()
        })

    @app.route("/api/queue/pause", methods=["POST"])
    def api_queue_pause():
        set_queue_paused(True)
        return jsonify({"paused": True})

    @app.route("/api/queue/resume", methods=["POST"])
    def api_queue_resume():
        set_queue_paused(False)
        return jsonify({"paused": False})

    @app.route("/api/push/vapid-public-key")
    def api_vapid_public_key():
        from .notifications import _ensure_vapid_keys
        _, key, _ = _ensure_vapid_keys()
        return jsonify({"vapid_public_key": key})

    @app.route("/api/push/subscribe", methods=["POST"])
    def api_push_subscribe():
        from flask import session as _sess
        from .notifications import add_push_subscription
        sub = request.get_json(silent=True)
        if not sub or "endpoint" not in sub:
            return jsonify({"error": "invalid subscription"}), 400
        add_push_subscription(sub, user_id=_sess.get("user_id"))
        return jsonify({"ok": True})

    @app.route("/api/push/unsubscribe", methods=["POST"])
    def api_push_unsubscribe():
        from .notifications import remove_push_subscription
        data = request.get_json(silent=True)
        if not data or "endpoint" not in data:
            return jsonify({"error": "missing endpoint"}), 400
        remove_push_subscription(data["endpoint"])
        return jsonify({"ok": True})

    # ------------------------------------------------------------------ #
    # Notification settings API                                            #
    # ------------------------------------------------------------------ #

    @app.route("/api/notif/settings")
    def api_notif_settings_get():
        """Return notification settings for the current user.

        Admins receive global admin settings (tokens masked as '*****').
        All users receive their own per-user settings and event prefs.
        """
        from flask import session as _sess
        uid  = _sess.get("user_id")
        role = _sess.get("user_role", "user")

        # Per-user prefs: uid=0 is the no-auth admin pseudo-user
        user_prefs = get_user_notif_prefs_all(uid) if uid is not None else {}

        result = {"user_prefs": user_prefs, "is_admin": role == "admin"}

        # Global admin settings — admins see masked tokens, users see booleans only
        admin_keys = [
            "notif_telegram_bot_token",
            "notif_telegram_enabled",
            "notif_pushover_app_token",
            "notif_pushover_enabled",
            "notif_discord_webhook_url",
            "notif_discord_enabled",
            "notif_discord_on_completed",
            "notif_discord_on_errors",
            "notif_discord_on_partial",
            "notif_discord_on_cancelled",
            "notif_discord_on_autosync",
            "notif_discord_on_sync_error",
            "notif_discord_on_sync_hold",
            "notif_discord_on_disk_space_low",
            "notif_disk_space_min_gb",
            "notif_sync_error_only_failed_all",
            "notif_whatsapp_sid",
            "notif_whatsapp_auth_token",
            "notif_whatsapp_from",
            "notif_whatsapp_enabled",
            "notif_webpush_enabled",
            "notif_ntfy_server",
            "notif_ntfy_topic",
            "notif_ntfy_auth_token",
            "notif_ntfy_user",
            "notif_ntfy_password",
            "notif_ntfy_enabled",
        ]
        admin_data = {}
        for k in admin_keys:
            raw = get_setting(k) or ""
            if role == "admin":
                # Return the real value to admins — they're already authenticated.
                # Sensitive inputs are shown as type=password in the UI (dots),
                # with an explicit eye-button to reveal. No need to mask here.
                admin_data[k] = raw
            else:
                # Non-admins only need to know if the service is configured
                admin_data[k] = bool(raw)
        result["admin"] = admin_data
        return jsonify(result)

    @app.route("/api/notif/admin-settings", methods=["POST"])
    def api_notif_admin_settings_set():
        """Update global admin notification settings. Admin only."""
        from flask import session as _sess
        if _sess.get("user_role") != "admin":
            return jsonify({"error": "admin access required"}), 403

        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"error": "invalid payload"}), 400

        allowed = {
            "notif_telegram_bot_token",
            "notif_telegram_enabled",
            "notif_pushover_app_token",
            "notif_pushover_enabled",
            "notif_discord_webhook_url",
            "notif_discord_enabled",
            "notif_discord_on_completed",
            "notif_discord_on_errors",
            "notif_discord_on_partial",
            "notif_discord_on_cancelled",
            "notif_discord_on_autosync",
            "notif_discord_on_sync_error",
            "notif_discord_on_sync_hold",
            "notif_discord_on_disk_space_low",
            "notif_disk_space_min_gb",
            "notif_sync_error_only_failed_all",
            "notif_whatsapp_sid",
            "notif_whatsapp_auth_token",
            "notif_whatsapp_from",
            "notif_whatsapp_enabled",
            "notif_webpush_enabled",
            "notif_ntfy_server",
            "notif_ntfy_topic",
            "notif_ntfy_auth_token",
            "notif_ntfy_user",
            "notif_ntfy_password",
            "notif_ntfy_enabled",
        }
        for k, v in data.items():
            if k not in allowed:
                continue
            val = str(v).strip()
            if val == "":
                delete_setting(k)
            else:
                set_setting(k, val)

        return jsonify({"ok": True})

    @app.route("/api/notif/user-settings", methods=["POST"])
    def api_notif_user_settings_set():
        """Update per-user notification settings (chat_id, user_key, phone, event prefs)."""
        from flask import session as _sess
        # uid=0 is the synthetic no-auth admin user
        uid = _sess.get("user_id")
        if uid is None:
            return jsonify({"error": "not authenticated"}), 401

        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"error": "invalid payload"}), 400

        allowed_keys = {
            # Web Push prefs
            "webpush_on_completed", "webpush_on_errors",
            "webpush_on_partial", "webpush_on_cancelled", "webpush_on_autosync",
            "webpush_on_sync_error", "webpush_on_sync_hold", "webpush_on_disk_space_low",
            # Telegram
            "telegram_enabled",
            "telegram_chat_id",
            "telegram_on_completed", "telegram_on_errors",
            "telegram_on_partial", "telegram_on_cancelled", "telegram_on_autosync",
            "telegram_on_sync_error", "telegram_on_sync_hold", "telegram_on_disk_space_low",
            # Pushover
            "pushover_enabled",
            "pushover_user_key",
            "pushover_on_completed", "pushover_on_errors",
            "pushover_on_partial", "pushover_on_cancelled", "pushover_on_autosync",
            "pushover_on_sync_error", "pushover_on_sync_hold", "pushover_on_disk_space_low",
            # WhatsApp
            "whatsapp_enabled",
            "whatsapp_phone",
            "whatsapp_on_completed", "whatsapp_on_errors",
            "whatsapp_on_partial", "whatsapp_on_cancelled", "whatsapp_on_autosync",
            "whatsapp_on_sync_error", "whatsapp_on_sync_hold", "whatsapp_on_disk_space_low",
            # NTFY
            "ntfy_enabled",
            "ntfy_on_completed", "ntfy_on_errors",
            "ntfy_on_partial", "ntfy_on_cancelled", "ntfy_on_autosync",
            "ntfy_on_sync_error", "ntfy_on_sync_hold", "ntfy_on_disk_space_low",
        }
        filtered = {k: str(v) for k, v in data.items() if k in allowed_keys}
        set_user_notif_prefs_bulk(uid, filtered)
        return jsonify({"ok": True})

    @app.route("/api/notif/telegram/detect-chat-id")
    def api_telegram_detect_chat_id():
        """Call Telegram getUpdates and return the most recent chat_id."""
        from flask import session as _sess
        # Both admins and users can trigger this (bot token must be set by admin)
        from .notifications import telegram_detect_chat_id
        token = get_setting("notif_telegram_bot_token") or ""
        if not token:
            return jsonify({"error": "Bot-Token wurde noch nicht konfiguriert"}), 400
        chat_id = telegram_detect_chat_id(token)
        if chat_id is None:
            return jsonify({"error": "Keine Nachricht gefunden. Schreib dem Bot zuerst eine Nachricht."}), 404
        return jsonify({"chat_id": chat_id})

    @app.route("/api/notif/test", methods=["POST"])
    def api_notif_test():
        """Send a test notification via the requested service."""
        from flask import session as _sess
        uid      = _sess.get("user_id")
        # In no-auth mode username="admin" is the pseudo-user for per-user pref lookups
        username = _sess.get("user_name")
        data     = request.get_json(silent=True) or {}
        service  = data.get("service", "")

        if service == "webpush":
            from .notifications import notify_webpush
            notify_webpush("AniWorld Downloader", "🔔 Test-Benachrichtigung erfolgreich!", username=username)
        elif service == "telegram":
            from .notifications import notify_telegram
            notify_telegram("AniWorld Downloader", "🔔 Test-Benachrichtigung erfolgreich!", username=username)
        elif service == "pushover":
            from .notifications import notify_pushover
            notify_pushover("AniWorld Downloader", "🔔 Test-Benachrichtigung erfolgreich!", username=username)
        elif service == "whatsapp":
            from .notifications import notify_whatsapp
            notify_whatsapp("AniWorld Downloader", "🔔 Test-Benachrichtigung erfolgreich!", username=username)
        elif service == "ntfy":
            from .notifications import notify_ntfy
            notify_ntfy("AniWorld Downloader", "🔔 Test-Benachrichtigung erfolgreich!", username=username)
        elif service == "discord":
            if _sess.get("user_role") != "admin":
                return jsonify({"error": "admin access required"}), 403
            from .notifications import send_discord_sync
            from .db import get_setting as _gs
            import os as _os
            _wh_url = (_gs("notif_discord_webhook_url") or _os.environ.get("ANIWORLD_DISCORD_WEBHOOK", "")).strip()
            if not _wh_url:
                return jsonify({"error": "Kein Webhook konfiguriert"}), 400
            import json as _json
            _payload = {
                "embeds": [{
                    "title": "AniWorld Downloader — Test",
                    "color": 0x57F287,
                    "fields": [
                        {"name": "Status", "value": "Test erfolgreich ✅", "inline": True},
                    ],
                    "footer": {"text": "AniWorld Downloader"},
                }]
            }
            _code, _err = send_discord_sync(_wh_url, _payload)
            if _code in (200, 204):
                return jsonify({"ok": True, "http": _code})
            else:
                return jsonify({"error": f"Discord antwortete HTTP {_code}: {_err or ''}"}), 502
        else:
            return jsonify({"error": "unknown service"}), 400

        return jsonify({"ok": True})

    @app.route("/api/queue/<int:queue_id>", methods=["DELETE"])
    def api_queue_remove(queue_id):
        ok, err = remove_from_queue(queue_id)
        if not ok:
            return jsonify({"error": err}), 400
        return jsonify({"ok": True})

    @app.route("/api/queue/<int:queue_id>/cancel", methods=["POST"])
    def api_queue_cancel(queue_id):
        ok, err = cancel_queue_item(queue_id)
        if not ok:
            return jsonify({"error": err}), 400
        # Signal the worker to kill the active subprocess immediately.
        with _active_cancel_events_lock:
            ev = _active_cancel_events.get(queue_id)
        if ev is not None:
            ev.set()
        return jsonify({"ok": True})

    @app.route("/api/queue/<int:queue_id>/restart", methods=["POST"])
    def api_queue_restart(queue_id):
        import json as _json
        item = get_queue_item(queue_id)
        if not item:
            return jsonify({"error": "Queue item not found"}), 404
        if item["status"] not in ("failed", "cancelled", "completed"):
            return jsonify({"error": "Only failed, cancelled or completed items can be restarted"}), 400

        # Prefer re-queuing only the failed episode URLs; fall back to full list
        try:
            errors = _json.loads(item.get("errors") or "[]")
            failed_urls = [e["url"] for e in errors if e.get("url")]
        except Exception:
            failed_urls = []

        if failed_urls:
            episodes = failed_urls
        else:
            try:
                episodes = _json.loads(item.get("episodes") or "[]")
            except Exception:
                return jsonify({"error": "Could not parse episode list"}), 500

        if not episodes:
            return jsonify({"error": "No episodes to restart"}), 400

        # Reset the existing row in-place (no new row created)
        ok, err = restart_queue_item_inplace(queue_id, episodes)
        if not ok:
            return jsonify({"error": err}), 400
        return jsonify({"ok": True, "queue_id": queue_id, "episodes": len(episodes)})

    @app.route("/api/queue/<int:queue_id>/skip-episode", methods=["POST"])
    def api_queue_skip_episode(queue_id):
        """Signal the worker to skip the current episode after its active attempt finishes."""
        item = get_queue_item(queue_id)
        if not item:
            return jsonify({"error": "Queue item not found"}), 404
        if item["status"] != "running":
            return jsonify({"error": "Job is not running"}), 400
        request_episode_skip(queue_id)
        return jsonify({"ok": True})

    @app.route("/api/queue/<int:queue_id>/retry-episode", methods=["POST"])
    def api_queue_retry_episode(queue_id):
        """Retry a single failed episode URL, preserving all other episode errors."""
        data = request.get_json(silent=True) or {}
        ep_url = data.get("url", "").strip()
        if not ep_url:
            return jsonify({"error": "Missing episode URL"}), 400
        item = get_queue_item(queue_id)
        if not item:
            return jsonify({"error": "Queue item not found"}), 404
        if item["status"] not in ("failed", "cancelled", "completed"):
            return jsonify({"error": "Only failed, cancelled or completed items support per-episode retry"}), 400
        ok, err = retry_single_episode(queue_id, ep_url)
        if not ok:
            return jsonify({"error": err}), 400
        return jsonify({"ok": True})

    @app.route("/api/queue/<int:queue_id>/move", methods=["POST"])
    def api_queue_move(queue_id):
        data = request.get_json(silent=True) or {}
        direction = data.get("direction", "").strip()
        if direction not in ("up", "down"):
            return jsonify({"error": "direction must be 'up' or 'down'"}), 400
        ok, err = move_queue_item(queue_id, direction)
        if not ok:
            return jsonify({"error": err}), 400
        return jsonify({"ok": True})

    @app.route("/api/queue/completed", methods=["DELETE"])
    def api_queue_clear():
        clear_completed()
        return jsonify({"ok": True})

    @app.route("/library")
    def library_page():
        return render_template("library.html")

    @app.route("/settings")
    def settings_page():
        from pathlib import Path
        import platform

        env_path = Path.home() / ".aniworld" / ".env"
        if platform.system() != "Windows":
            display = "~/.aniworld/.env"
        else:
            display = str(env_path)
        return render_template("settings.html", env_path=display)

    @app.route("/integrations")
    def integrations_page():
        return render_template("integrations.html")

    @app.route("/advanced-search")
    def advanced_search_page():
        from .db import get_setting
        if get_setting("cineinfo_advanced_search", "0") != "1":
            from flask import redirect, url_for
            return redirect(url_for("index"))
        sto_lang_labels = {"1": "German Dub", "2": "English Dub"}
        return render_template(
            "advanced_search.html",
            lang_labels=LANG_LABELS,
            sto_lang_labels=sto_lang_labels,
            supported_providers=WORKING_PROVIDERS,
        )



    @app.route("/encoding")
    def encoding_page():
        return render_template("encoding.html")

    @app.route("/api/encoding/settings", methods=["GET"])
    def api_encoding_settings_get():
        settings = {
            "mode":        get_setting("encoding_mode", "copy"),
            "audio_copy":  get_setting("encoding_audio_copy", "copy"),
            "hw_h264":     get_setting("encoding_hw_h264", "cpu"),
            "preset_h264": get_setting("encoding_preset_h264", "medium"),
            "crf_h264":    int(get_setting("encoding_crf_h264", "23") or "23"),
            "audio_h264":  get_setting("encoding_audio_h264", "copy"),
            "hw_h265":     get_setting("encoding_hw_h265", "cpu"),
            "preset_h265": get_setting("encoding_preset_h265", "medium"),
            "crf_h265":    int(get_setting("encoding_crf_h265", "28") or "28"),
            "audio_h265":  get_setting("encoding_audio_h265", "copy"),
            "expert_video": get_setting("encoding_expert_video", ""),
            "expert_audio": get_setting("encoding_expert_audio", ""),
            "vaapi_device": get_setting("encoding_vaapi_device", ""),
        }
        return jsonify({"ok": True, "settings": settings})

    @app.route("/api/encoding/settings", methods=["POST"])
    def api_encoding_settings_post():
        data = request.get_json(force=True) or {}
        mode = data.get("mode", "copy")
        valid_modes = ("copy", "h264", "h265", "expert")
        if mode not in valid_modes:
            return jsonify({"ok": False, "error": "Invalid mode"}), 400
        set_setting("encoding_mode", mode)
        if mode == "copy":
            audio = data.get("audio", "copy")
            if audio not in ("copy", "aac", "ac3"):
                audio = "copy"
            set_setting("encoding_audio_copy", audio)
        elif mode in ("h264", "h265"):
            hw = data.get("hw", "cpu")
            preset = data.get("preset", "medium")
            crf = str(int(data.get("crf", 23 if mode == "h264" else 28)))
            audio = data.get("audio", "copy")
            valid_presets = ("ultrafast","superfast","veryfast","faster","fast","medium","slow","slower","veryslow")
            valid_hw = ("cpu","nvenc","vaapi","videotoolbox")
            valid_audio = ("copy","aac","ac3")
            if preset not in valid_presets: preset = "medium"
            if hw not in valid_hw: hw = "cpu"
            if audio not in valid_audio: audio = "copy"
            vaapi_device = data.get("vaapi_device", "")
            set_setting(f"encoding_hw_{mode}", hw)
            set_setting(f"encoding_preset_{mode}", preset)
            set_setting(f"encoding_crf_{mode}", crf)
            set_setting(f"encoding_audio_{mode}", audio)
            set_setting("encoding_vaapi_device", vaapi_device)
        elif mode == "expert":
            set_setting("encoding_expert_video", data.get("expert_video", ""))
            set_setting("encoding_expert_audio", data.get("expert_audio", ""))
        return jsonify({"ok": True})

    @app.route("/api/encoding/detect-hw", methods=["POST"])
    def api_encoding_detect_hw():
        import subprocess
        import sys
        import threading

        vaapi_device = get_setting("encoding_vaapi_device", "") or "/dev/dri/renderD128"

        def _reason_from_output(output: str, encoder: str) -> str:
            """Parse FFmpeg stderr and return a human-readable reason why an encoder failed."""
            o = output.lower()
            if encoder in ("h264_nvenc", "hevc_nvenc"):
                if "cannot load libcuda" in o or "libcuda.so" in o:
                    return "NVIDIA-Treiber nicht gefunden. Bei Docker: Container mit --gpus all starten."
                if "no nvenc capable devices" in o:
                    return "Keine NVIDIA-GPU gefunden oder NVENC nicht unterstützt."
                if "driver does not support" in o:
                    return "NVIDIA-Treiber zu alt — bitte aktualisieren."
                if "device or resource busy" in o:
                    return "GPU ist vollständig ausgelastet."
            if encoder in ("h264_vaapi", "hevc_vaapi"):
                if "no such file or directory" in o or "cannot open" in o:
                    return f"VAAPI-Gerät nicht gefunden ({vaapi_device}). Bei Docker: /dev/dri mounten."
                if "permission denied" in o:
                    return f"Kein Zugriff auf {vaapi_device}. Benutzer zur video-Gruppe hinzufügen."
                if "no va display" in o or "failed to initialise" in o:
                    return "VAAPI konnte nicht initialisiert werden — Treiber prüfen."
            if encoder in ("h264_videotoolbox", "hevc_videotoolbox"):
                if sys.platform != "darwin":
                    return "Nur auf macOS verfügbar."
            if "unknown encoder" in o or "encoder not found" in o or "no such encoder" in o:
                return "FFmpeg wurde ohne Support für diesen Encoder kompiliert."
            return "Encoder nicht verfügbar."

        def _probe(encoder: str, cmd: list, results: dict):
            try:
                r = subprocess.run(
                    cmd, capture_output=True, text=True, timeout=10
                )
                output = r.stdout + r.stderr
                if r.returncode == 0:
                    results[encoder] = {"available": True, "reason": None}
                else:
                    results[encoder] = {
                        "available": False,
                        "reason": _reason_from_output(output, encoder),
                    }
            except FileNotFoundError:
                results[encoder] = {"available": False, "reason": "ffmpeg nicht gefunden."}
            except subprocess.TimeoutExpired:
                results[encoder] = {"available": False, "reason": "Timeout — Encoder reagiert nicht."}
            except Exception as exc:
                results[encoder] = {"available": False, "reason": str(exc)}

        _null = ["ffmpeg", "-f", "lavfi", "-i", "nullsrc=size=128x128:rate=1",
                 "-frames:v", "1", "-an"]

        probes = {
            "libx264":            _null + ["-c:v", "libx264",            "-f", "null", "-"],
            "libx265":            _null + ["-c:v", "libx265",            "-f", "null", "-"],
            "h264_nvenc":         _null + ["-c:v", "h264_nvenc",         "-f", "null", "-"],
            "hevc_nvenc":         _null + ["-c:v", "hevc_nvenc",         "-f", "null", "-"],
            "h264_vaapi":         ["ffmpeg", "-vaapi_device", vaapi_device,
                                   "-f", "lavfi", "-i", "nullsrc=size=128x128:rate=1",
                                   "-frames:v", "1", "-an",
                                   "-vf", "format=nv12,hwupload",
                                   "-c:v", "h264_vaapi", "-f", "null", "-"],
            "hevc_vaapi":         ["ffmpeg", "-vaapi_device", vaapi_device,
                                   "-f", "lavfi", "-i", "nullsrc=size=128x128:rate=1",
                                   "-frames:v", "1", "-an",
                                   "-vf", "format=nv12,hwupload",
                                   "-c:v", "hevc_vaapi", "-f", "null", "-"],
            "h264_videotoolbox":  _null + ["-c:v", "h264_videotoolbox",  "-f", "null", "-"],
            "hevc_videotoolbox":  _null + ["-c:v", "hevc_videotoolbox",  "-f", "null", "-"],
        }

        results = {}
        threads = []
        for enc, cmd in probes.items():
            t = threading.Thread(target=_probe, args=(enc, cmd, results))
            t.start()
            threads.append(t)
        for t in threads:
            t.join(timeout=12)

        return jsonify({"ok": True, "encoders": results})


    # =========================================================
    # Upscale Queue API
    # =========================================================

    @app.route("/api/upscale/queue")
    def api_upscale_queue():
        items = get_upscale_queue()
        badge = get_upscale_badge_count()
        return jsonify({"ok": True, "items": items, "badge": badge})

    @app.route("/api/upscale/progress")
    def api_upscale_progress():
        try:
            from ..anime4k.anime4k import get_upscale_progress
            return jsonify({"ok": True, "progress": get_upscale_progress()})
        except Exception:
            return jsonify({"ok": True, "progress": {"active": False, "percent": 0}})

    @app.route("/api/upscale/badge")
    def api_upscale_badge():
        return jsonify({"ok": True, "count": get_upscale_badge_count()})

    @app.route("/api/upscale/queue/<int:item_id>", methods=["DELETE"])
    def api_upscale_queue_delete(item_id):
        ok, err = remove_from_upscale_queue(item_id)
        if ok:
            return jsonify({"ok": True})
        return jsonify({"ok": False, "error": err}), 400

    @app.route("/api/upscale/queue/<int:item_id>/cancel", methods=["POST"])
    def api_upscale_cancel(item_id):
        ok, err = cancel_upscale_item(item_id)
        if ok:
            with _upscale_cancel_lock:
                ev = _upscale_active_cancel_events.get(item_id)
            if ev:
                ev.set()
        if ok:
            return jsonify({"ok": True})
        return jsonify({"ok": False, "error": err}), 400

    @app.route("/api/upscale/queue/clear", methods=["POST"])
    def api_upscale_clear():
        clear_upscale_completed()
        return jsonify({"ok": True})

    @app.route("/api/upscale/queue/<int:item_id>/move", methods=["POST"])
    def api_upscale_move(item_id):
        data = request.get_json(force=True, silent=True) or {}
        direction = data.get("direction", "up")
        ok, err = move_upscale_queue_item(item_id, direction)
        if ok:
            return jsonify({"ok": True})
        return jsonify({"ok": False, "error": err}), 400

    @app.route("/api/upscale/add-library", methods=["POST"])
    def api_upscale_add_library():
        """Add library files to the upscale queue as ONE batch entry."""
        data = request.get_json(force=True) or {}
        files = data.get("files", [])  # list of {title, path}
        if not files:
            return jsonify({"ok": False, "error": "Keine Dateien angegeben"}), 400
        replace = get_setting("upscaling_replace_original", "1") == "1"
        from pathlib import Path as _Path
        import json as _json
        valid = []
        title = None
        for f in files:
            fp = _Path(f.get("path", ""))
            if not fp.exists():
                continue
            if replace:
                out = str(fp)
            else:
                out = str(fp.with_name(fp.stem + " (upscale).mkv"))
            valid.append({"file_path": str(fp), "output_path": out})
            if title is None:
                # Use the series title (strip episode suffix)
                t = f.get("title", fp.stem)
                title = t.split(" – ")[0].strip() if " – " in t else t
        if not valid:
            return jsonify({"ok": False, "error": "Keine Dateien gefunden"}), 400
        add_to_upscale_queue(
            title=title or "Unbekannt",
            file_path=valid[0]["file_path"],
            output_path=valid[0]["output_path"],
            source="library",
            files=valid if len(valid) > 1 else None,
        )
        return jsonify({"ok": True, "added": len(valid)})


    @app.route("/api/upscale/settings", methods=["GET"])
    def api_upscale_settings_get():
        return jsonify({
            "ok": True,
            "settings": {
                "mode":            get_setting("upscaling_mode", "disabled"),
                "engine":          get_setting("upscaling_engine", "auto"),
                "shader_preset":   get_setting("upscaling_shader_preset", "B"),
                "shader_quality":  get_setting("upscaling_shader_quality", "high"),
                "resolution":      get_setting("upscaling_resolution", "1080p"),
                "replace_original":get_setting("upscaling_replace_original", "1"),
                "out_vcodec":      get_setting("upscaling_out_vcodec", "libx264"),
                "out_crf":         get_setting("upscaling_out_crf", "18"),
                "out_preset":      get_setting("upscaling_out_preset", "medium"),
            }
        })

    @app.route("/api/upscale/settings", methods=["POST"])
    def api_upscale_settings_post():
        data = request.get_json(force=True) or {}
        valid_modes    = ("disabled", "during_download", "after_download")
        valid_engines  = ("auto", "mpv", "libplacebo")
        valid_presets  = ("A", "B", "C", "D")
        valid_quality  = ("high", "low")
        valid_res      = ("1080p", "1440p", "4k", "source")
        valid_vcodec   = ("libx264", "libx265", "copy")
        valid_enc_pre  = ("ultrafast","superfast","veryfast","faster","fast",
                          "medium","slow","slower","veryslow")

        def _v(key, valid, default):
            val = data.get(key, default)
            return val if val in valid else default

        set_setting("upscaling_mode",             _v("mode", valid_modes, "disabled"))
        set_setting("upscaling_engine",           _v("engine", valid_engines, "auto"))
        set_setting("upscaling_shader_preset",    _v("shader_preset", valid_presets, "B"))
        set_setting("upscaling_shader_quality",   _v("shader_quality", valid_quality, "high"))
        set_setting("upscaling_resolution",       _v("resolution", valid_res, "1080p"))
        set_setting("upscaling_replace_original", "1" if data.get("replace_original", True) else "0")
        set_setting("upscaling_out_vcodec",       _v("out_vcodec", valid_vcodec, "libx264"))
        crf = str(max(0, min(51, int(data.get("out_crf", 18)))))
        set_setting("upscaling_out_crf",    crf)
        set_setting("upscaling_out_preset", _v("out_preset", valid_enc_pre, "medium"))
        return jsonify({"ok": True})

    @app.route("/api/upscale/mpv-status", methods=["GET"])
    def api_upscale_mpv_status():
        try:
            from ..autodeps import get_mpv_download_status, _bundled_mpv
            import shutil
            present = bool(_bundled_mpv() or shutil.which("mpv"))
            dl = get_mpv_download_status()
            return jsonify({"ok": True, "present": present, "download": dl})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.route("/api/upscale/check-engines", methods=["POST"])
    def api_upscale_check_engines():
        try:
            from ..anime4k.anime4k import get_available_engines, list_available_shaders
            engines  = get_available_engines()
            shaders  = list_available_shaders("high") + list_available_shaders("low")
            shaders  = sorted(set(shaders))
            return jsonify({"ok": True, "engines": engines, "shaders_available": len(shaders) > 0})
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 500

    @app.route("/api/upscale/download-shaders", methods=["POST"])
    def api_upscale_download_shaders():
        """Download Anime4K GLSL shader pack in background."""
        data     = request.get_json(force=True) or {}
        quality  = data.get("quality", "high")
        if quality not in ("high", "low"):
            return jsonify({"ok": False, "error": "quality must be high or low"}), 400

        def _dl():
            try:
                from ..anime4k.anime4k import download_anime4k, extract_anime4k
                files = download_anime4k(mode=quality)
                extract_anime4k(files)
                logger.info(f"[Anime4K] Shader-Download abgeschlossen ({quality})")
            except Exception as exc:
                logger.error(f"[Anime4K] Shader-Download fehlgeschlagen: {exc}")

        threading.Thread(target=_dl, daemon=True).start()
        return jsonify({"ok": True, "message": "Download gestartet"})

    @app.route("/notifications")
    def notifications_page():
        from flask import session as _sess
        # In no-auth mode user_role is set to "admin" by before_request,
        # so this works correctly for both auth and no-auth.
        return render_template(
            "notifications.html",
            is_admin=(_sess.get("user_role") == "admin"),
        )

    @app.route("/api/random")
    def api_random():
        site = request.args.get("site", "aniworld").strip()
        if site == "sto":
            return jsonify({"error": "Random is not available for S.TO"}), 400
        url = random_anime()
        if url:
            return jsonify({"url": url})
        return jsonify({"error": "Failed to fetch random anime"}), 500

    # TTL cache for browse endpoints — in-memory + SQLite persistence
    import time as _time

    _browse_cache = {}
    _BROWSE_TTL = 3600  # 1 hour
    _browse_refresh_locks: dict = {}
    _browse_refresh_mutex = threading.Lock()

    def _cached_browse(key, fetch_fn):
        now = _time.time()
        # 1. In-memory fast path
        entry = _browse_cache.get(key)
        if entry and now - entry[0] < _BROWSE_TTL:
            return entry[1]

        # 2. If nothing in memory, try SQLite (survives restarts)
        if entry is None:
            db_row = get_browse_cache_stale(key)
            if db_row:
                data, cached_at = db_row
                _browse_cache[key] = (cached_at, data)
                entry = _browse_cache[key]

        # 3. Still fresh after DB load?
        if entry and now - entry[0] < _BROWSE_TTL:
            return entry[1]

        # 4. Stale or missing — avoid duplicate concurrent refreshes
        with _browse_refresh_mutex:
            already_refreshing = key in _browse_refresh_locks
            if not already_refreshing:
                _browse_refresh_locks[key] = True

        if entry is not None:
            # Stale-while-revalidate: serve old data immediately, refresh in background
            if not already_refreshing:
                def _bg_refresh(k=key, fn=fetch_fn):
                    try:
                        results = fn()
                        if results:
                            _browse_cache[k] = (_time.time(), results)
                            set_browse_cache(k, results)
                    finally:
                        with _browse_refresh_mutex:
                            _browse_refresh_locks.pop(k, None)
                threading.Thread(target=_bg_refresh, daemon=True,
                                 name=f"browse-refresh-{key}").start()
            return entry[1]

        # 5. Cold start — no data at all, fetch synchronously
        try:
            results = fetch_fn()
            if results is not None:
                _browse_cache[key] = (_time.time(), results)
                set_browse_cache(key, results)
            return results
        finally:
            with _browse_refresh_mutex:
                _browse_refresh_locks.pop(key, None)

    @app.route("/api/new-animes")
    def api_new_animes():
        results = _cached_browse("new_animes", fetch_new_animes)
        if results is None:
            return jsonify({"error": "Failed to fetch new animes"}), 500
        return jsonify({"results": _proxy_result_list(results)})

    @app.route("/api/popular-animes")
    def api_popular_animes():
        results = _cached_browse("popular_animes", fetch_popular_animes)
        if results is None:
            return jsonify({"error": "Failed to fetch popular animes"}), 500
        return jsonify({"results": _proxy_result_list(results)})

    @app.route("/api/new-series")
    def api_new_series():
        results = _cached_browse("new_series", fetch_new_series)
        if results is None:
            return jsonify({"error": "Failed to fetch new series"}), 500
        return jsonify({"results": _proxy_result_list(results)})

    @app.route("/api/popular-series")
    def api_popular_series():
        results = _cached_browse("popular_series", fetch_popular_series)
        if results is None:
            return jsonify({"error": "Failed to fetch popular series"}), 500
        return jsonify({"results": _proxy_result_list(results)})

    def _fetch_new_movies():
        """Scrape the FilmPalast homepage for new movies (filters out SxxExx series episodes)."""
        import re as _re2
        import requests as _req
        series_re = _re2.compile(r"\bS\d{2}E\d{2}\b", _re2.IGNORECASE)
        try:
            resp = _req.get(
                "https://filmpalast.to/",
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "Accept-Encoding": "gzip, deflate",
                    "Accept-Language": "de-DE,de;q=0.9",
                },
                timeout=15,
            )
            resp.raise_for_status()
            html = resp.text
        except Exception as exc:
            logger.warning("FilmPalast new-movies scrape failed: %s", exc)
            return None

        anchors = _re2.findall(
            r'<a\s+href="//filmpalast\.to/stream/([a-zA-Z0-9\-]+)"\s+title="([^"]+)"',
            html,
        )
        imgs = _re2.findall(r'<img\s+src="(/files/movies/[^"]+)"', html)

        results = []
        seen = set()
        for i, (slug, title) in enumerate(anchors):
            if series_re.search(title):
                continue  # skip series episodes like "Show S04E01"
            url = f"https://filmpalast.to/stream/{slug}"
            if url in seen:
                continue
            seen.add(url)
            poster = f"https://filmpalast.to{imgs[i]}" if i < len(imgs) else ""
            results.append({"title": title, "url": url, "poster_url": poster, "genre": ""})
        return results

    @app.route("/api/new-movies")
    def api_new_movies():
        results = _cached_browse("new_movies", _fetch_new_movies)
        if results is None:
            return jsonify({"error": "Failed to fetch new movies"}), 500
        return jsonify({"results": _proxy_result_list(results)})

    @app.route("/api/downloaded-folders")
    def api_downloaded_folders():
        from pathlib import Path
        # If MediaScan is active and using a media-server source,
        # signal the frontend to skip the folder check entirely.
        ms_enabled = get_setting("mediascan_enabled", "0") == "1"
        ms_source  = get_setting("mediascan_source",  "") or ""
        if ms_enabled and ms_source and ms_source != "folders":
            return jsonify({"folders": [], "source": "mediascan", "mediascan_source": ms_source})


        raw = os.environ.get("ANIWORLD_DOWNLOAD_PATH", "")
        if raw:
            p = Path(raw).expanduser()
            if not p.is_absolute():
                p = Path.home() / p
            dl_path = p
        else:
            dl_path = Path.home() / "Downloads"

        lang_sep = os.environ.get("ANIWORLD_LANG_SEPARATION", "0") == "1"
        lang_folders = ["german-dub", "english-sub", "german-sub", "english-dub"]

        # Collect all paths to scan (default + custom)
        scan_roots = [dl_path]
        for cp in get_custom_paths():
            cp_path = Path(cp["path"]).expanduser()
            if not cp_path.is_absolute():
                cp_path = Path.home() / cp_path
            scan_roots.append(cp_path)

        folders = set()
        for root in scan_roots:
            if lang_sep:
                bases = [root / lf for lf in lang_folders]
            else:
                bases = [root]
            for base in bases:
                if not base.is_dir():
                    continue
                for entry in base.iterdir():
                    if entry.is_dir():
                        folders.add(entry.name)
        return jsonify({"folders": sorted(folders)})

    @app.route("/api/update-check", methods=["GET", "POST"])
    def api_update_check():
        import time
        data = request.get_json(silent=True) or {}
        force = data.get("force", False)
        stale = (time.time() - _update_cache["checked_at"]) > _UPDATE_CHECK_INTERVAL
        if force or stale:
            _do_update_check()
        return jsonify({
            "local_version": app_version,
            "latest_version": _update_cache["latest_version"],
            "update_available": _update_cache["update_available"],
            "release_url": _update_cache["release_url"],
            "release_notes": _update_cache["release_notes"],
            "checked_at": _update_cache["checked_at"],
            "error": _update_cache["error"],
            "is_dev_install": _update_cache["is_dev_install"],
        })

    @app.route("/api/settings", methods=["GET"])
    def api_settings():
        from pathlib import Path

        raw = get_setting("download_path") or os.environ.get("ANIWORLD_DOWNLOAD_PATH", "")
        if raw:
            p = Path(raw).expanduser()
            if not p.is_absolute():
                p = Path.home() / p
            resolved = str(p)
        else:
            resolved = str(Path.home() / "Downloads")
        lang_separation      = get_setting("lang_separation")      or os.environ.get("ANIWORLD_LANG_SEPARATION", "0")
        disable_english_sub  = get_setting("disable_english_sub")  or os.environ.get("ANIWORLD_DISABLE_ENGLISH_SUB", "0")
        filmpalast_movie_subfolder = get_setting("filmpalast_movie_subfolder", "0")
        sync_schedule        = get_setting("sync_schedule")        or os.environ.get("ANIWORLD_SYNC_SCHEDULE", "0")
        sync_language               = get_setting("sync_language")               or os.environ.get("ANIWORLD_SYNC_LANGUAGE", "German Dub")
        sync_provider               = get_setting("sync_provider")               or os.environ.get("ANIWORLD_SYNC_PROVIDER", "VOE")
        sync_path_unavailable_action = get_setting("sync_path_unavailable_action") or os.environ.get("ANIWORLD_SYNC_PATH_UNAVAILABLE_ACTION", "skip")
        sync_error_retries   = int(get_setting("sync_error_retries") or os.environ.get("ANIWORLD_SYNC_ERROR_RETRIES", "0"))
        sync_error_retry_time = get_setting("sync_error_retry_time") or os.environ.get("ANIWORLD_SYNC_ERROR_RETRY_TIME", "5min")
        download_language    = get_setting("download_language")    or os.environ.get("ANIWORLD_LANGUAGE", "German Dub")
        download_provider    = get_setting("download_provider")    or os.environ.get("ANIWORLD_PROVIDER", "VOE")
        naming_template      = get_setting("naming_template")      or os.environ.get("ANIWORLD_NAMING_TEMPLATE", "{title} ({year}) [imdbid-{imdbid}]/Season {season}/{title} S{season}E{episode}.mkv")
        web_base_url         = get_setting("web_base_url")         or os.environ.get("ANIWORLD_WEB_BASE_URL", "")
        debug_mode           = get_setting("debug_mode")           or os.environ.get("ANIWORLD_DEBUG_MODE", "0")
        return jsonify(
            {
                "download_path":             resolved,
                "lang_separation":           lang_separation,
                "disable_english_sub":       disable_english_sub,
                "filmpalast_movie_subfolder": filmpalast_movie_subfolder,
                "sync_schedule":             sync_schedule,
                "sync_language":              sync_language,
                "sync_provider":              sync_provider,
                "sync_path_unavailable_action": sync_path_unavailable_action,
                "sync_error_retries":         sync_error_retries,
                "sync_error_retry_time":      sync_error_retry_time,
                "download_language":         download_language,
                "download_provider":         download_provider,
                "naming_template":           naming_template,
                "web_base_url":              web_base_url,
                "debug_mode":                debug_mode,
                "seerr_url":                 get_setting("seerr_url", ""),
                "seerr_api_key":             get_setting("seerr_api_key", ""),
                "dns_mode":                  get_setting("dns_mode", "system"),
                "dns_server":                get_setting("dns_server", ""),
                "cineinfo": {
                    "tmdb_api_key":   get_setting("cineinfo_tmdb_api_key",   ""),
                    "country":        get_setting("cineinfo_country",        "DE"),
                    "show_providers": get_setting("cineinfo_show_providers", "1"),
                    "show_genres":    get_setting("cineinfo_show_genres",    "0"),
                    "show_fsk":       get_setting("cineinfo_show_fsk",       "1"),
                    "show_rating":    get_setting("cineinfo_show_rating",    "0"),
                    "show_recommendations": get_setting("cineinfo_show_recommendations", "1"),
                    "show_trailer":   get_setting("cineinfo_show_trailer",   "1"),
                    "show_hover_rating": get_setting("cineinfo_show_hover_rating", "0"),
                    "show_hover_genres": get_setting("cineinfo_show_hover_genres", "0"),
                    "show_hover_fsk": get_setting("cineinfo_show_hover_fsk", "0"),
                    "advanced_search": get_setting("cineinfo_advanced_search", "0"),
                }
            }
        )

    @app.route("/api/settings/seerr", methods=["PUT"])
    def api_settings_seerr():
        data = request.get_json(silent=True) or {}
        set_setting("seerr_url", str(data.get("seerr_url", "")).strip())
        set_setting("seerr_api_key", str(data.get("seerr_api_key", "")).strip())
        return jsonify({"ok": True})

    @app.route("/api/settings/sso", methods=["GET"])
    def api_settings_sso_get():
        """Return current SSO / OIDC configuration from DB (secrets masked)."""
        return jsonify({
            "sso_enabled":        get_setting("web_sso", "0"),
            "force_sso":          get_setting("web_force_sso", "0"),
            "oidc_issuer_url":    get_setting("oidc_issuer_url", ""),
            "oidc_client_id":     get_setting("oidc_client_id", ""),
            "oidc_client_secret": "***" if get_setting("oidc_client_secret", "") else "",
            "oidc_display_name":  get_setting("oidc_display_name", "SSO"),
            "oidc_admin_user":    get_setting("oidc_admin_user", ""),
            "oidc_admin_subject": get_setting("oidc_admin_subject", ""),
        })

    @app.route("/api/settings/sso", methods=["PUT"])
    def api_settings_sso_put():
        """Save SSO / OIDC configuration to DB and apply immediately."""
        data = request.get_json(silent=True) or {}

        def _save(db_key, env_key, default=""):
            val = str(data.get(db_key, "")).strip()
            set_setting(db_key, val)
            os.environ[env_key] = val

        sso_enabled = "1" if data.get("sso_enabled") else "0"
        force_sso   = "1" if data.get("force_sso")   else "0"
        set_setting("web_sso",       sso_enabled); os.environ["ANIWORLD_WEB_SSO"]       = sso_enabled
        set_setting("web_force_sso", force_sso);   os.environ["ANIWORLD_WEB_FORCE_SSO"] = force_sso

        _save("oidc_issuer_url",    "ANIWORLD_OIDC_ISSUER_URL")
        _save("oidc_client_id",     "ANIWORLD_OIDC_CLIENT_ID")
        _save("oidc_display_name",  "ANIWORLD_OIDC_DISPLAY_NAME")
        _save("oidc_admin_user",    "ANIWORLD_OIDC_ADMIN_USER")
        _save("oidc_admin_subject", "ANIWORLD_OIDC_ADMIN_SUBJECT")

        # Secret: only overwrite if a real value was sent (not the "***" placeholder)
        secret = str(data.get("oidc_client_secret", "")).strip()
        if secret and secret != "***":
            set_setting("oidc_client_secret", secret)
            os.environ["ANIWORLD_OIDC_CLIENT_SECRET"] = secret

        return jsonify({"ok": True, "restart_required": True})

    @app.route("/api/settings/cineinfo", methods=["GET"])
    def api_settings_cineinfo_get():
        return jsonify({
            "tmdb_api_key":   get_setting("cineinfo_tmdb_api_key",   ""),
            "country":        get_setting("cineinfo_country",        "DE"),
            "show_providers": get_setting("cineinfo_show_providers", "1"),
            "show_genres":    get_setting("cineinfo_show_genres",    "0"),
            "show_fsk":       get_setting("cineinfo_show_fsk",       "1"),
            "show_rating":    get_setting("cineinfo_show_rating",    "0"),
            "show_recommendations": get_setting("cineinfo_show_recommendations", "1"),
            "show_trailer":   get_setting("cineinfo_show_trailer",   "1"),
            "show_hover_rating": get_setting("cineinfo_show_hover_rating", "0"),
            "show_hover_genres": get_setting("cineinfo_show_hover_genres", "0"),
            "show_hover_fsk": get_setting("cineinfo_show_hover_fsk", "0"),
            "advanced_search": get_setting("cineinfo_advanced_search", "0"),
        })

    @app.route("/api/settings/cineinfo", methods=["PUT"])
    def api_settings_cineinfo_put():
        data = request.get_json(silent=True) or {}
        old_key = get_setting("cineinfo_tmdb_api_key", "")
        old_country = get_setting("cineinfo_country", "DE")

        for key in ["tmdb_api_key", "country", "show_providers",
                    "show_genres", "show_fsk", "show_rating", "show_recommendations", "show_trailer",
                    "show_hover_rating", "show_hover_genres", "show_hover_fsk", "advanced_search"]:
            if key in data:
                set_setting("cineinfo_" + key, str(data[key]))

        new_key = get_setting("cineinfo_tmdb_api_key", "")
        new_country = get_setting("cineinfo_country", "DE")
        if new_key != old_key or new_country != old_country:
            clear_tmdb_cache()

        return jsonify({"ok": True})



    @app.route("/api/settings/env-file", methods=["GET"])
    def api_settings_env_file_get():
        """Check whether the legacy .env file still exists and has been migrated."""
        from pathlib import Path as _Path
        env_path = _Path.home() / ".aniworld" / ".env"
        return jsonify({
            "exists":   env_path.exists(),
            "migrated": get_setting("env_migrated") == "1",
        })

    @app.route("/api/settings/env-file", methods=["DELETE"])
    def api_settings_env_file_delete():
        """Delete the legacy .env file after migration."""
        import os as _os
        from pathlib import Path as _Path
        env_path = _Path.home() / ".aniworld" / ".env"
        if not env_path.exists():
            return jsonify({"ok": True, "message": "Datei existiert nicht mehr"})
        try:
            env_path.unlink()
            return jsonify({"ok": True})
        except Exception as exc:
            return jsonify({"error": str(exc)}), 500

    @app.route("/api/settings/mediaplayer", methods=["GET"])
    def api_settings_mediaplayer_get():
        svc = get_setting("mediaplayer_type", "")
        token = get_setting("mediaplayer_apikey", "")
        return jsonify({
            "type":         svc,
            "url":          get_setting("mediaplayer_url",          ""),
            "plex_url":     get_setting("mediaplayer_plex_url",     ""),
            "apikey":       token,
            "has_token":    bool(token),
            "plex_section": get_setting("mediaplayer_plex_section", ""),
        })

    @app.route("/api/settings/mediaplayer", methods=["PUT"])
    def api_settings_mediaplayer_put():
        data = request.get_json(silent=True) or {}
        for key in ["type", "url", "plex_url", "apikey", "plex_section"]:
            if key in data:
                set_setting("mediaplayer_" + key, str(data[key]).strip())
        return jsonify({"ok": True})

    @app.route("/api/settings/mediaplayer/test", methods=["POST"])
    def api_settings_mediaplayer_test():
        """Quick connectivity test: try to reach the configured mediaplayer."""
        import urllib.request as _req
        svc = get_setting("mediaplayer_type", "")
        key = get_setting("mediaplayer_apikey", "") or ""
        if not svc or not key:
            return jsonify({"ok": False, "error": "Konfiguration unvollständig"})
        try:
            if svc == "jellyfin":
                url = _normalize_media_url(get_setting("mediaplayer_url", "") or "")
                if not url:
                    return jsonify({"ok": False, "error": "Server-URL fehlt"})
                r = _req.Request(f"{url}/System/Info/Public", headers={"X-Emby-Token": key})
                with _req.urlopen(r, timeout=8) as resp:
                    info = json.loads(resp.read())
                return jsonify({"ok": True, "name": info.get("ServerName", "Jellyfin")})
            elif svc == "plex":
                url = _normalize_media_url(get_setting("mediaplayer_plex_url", "") or "")
                if not url:
                    return jsonify({"ok": False, "error": "Server-URL fehlt"})
                r = _req.Request(
                    f"{url}/?X-Plex-Token={key}",
                    headers={"Accept": "application/json"},
                )
                with _req.urlopen(r, timeout=8) as resp:
                    info = json.loads(resp.read())
                friendly = info.get("MediaContainer", {}).get("friendlyName", "Plex")
                return jsonify({"ok": True, "name": friendly})
            else:
                return jsonify({"ok": False, "error": "Unbekannter Typ"})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)})

    @app.route("/api/settings/mediaplayer/scan-status", methods=["GET"])
    def api_mediaplayer_scan_status():
        """Poll whether the configured media server is currently scanning its library."""
        import urllib.request as _req
        svc = get_setting("mediaplayer_type", "")
        key = get_setting("mediaplayer_apikey", "") or ""
        if not svc or not key:
            return jsonify({"scanning": False, "error": "Kein Mediaplayer konfiguriert"})
        try:
            if svc == "jellyfin":
                url = _normalize_media_url(get_setting("mediaplayer_url", "") or "")
                if not url:
                    return jsonify({"scanning": False, "error": "Keine URL"})
                r = _req.Request(
                    f"{url}/ScheduledTasks",
                    headers={"X-Emby-Token": key, "Accept": "application/json"},
                )
                with _req.urlopen(r, timeout=8) as resp:
                    tasks = json.loads(resp.read())
                scan_keywords = ("scan", "refresh", "bibliothek", "library", "medien")
                scanning = any(
                    t.get("State") == "Running"
                    and any(kw in t.get("Name", "").lower() for kw in scan_keywords)
                    for t in tasks
                )
                running = [t.get("Name") for t in tasks if t.get("State") == "Running"]
                logger.debug("Jellyfin scan-status poll: scanning=%s running_tasks=%s", scanning, running)
                return jsonify({"scanning": scanning})

            elif svc == "plex":
                url = _normalize_media_url(get_setting("mediaplayer_plex_url", "") or "")
                if not url:
                    return jsonify({"scanning": False, "error": "Keine URL"})
                section = (get_setting("mediaplayer_plex_section", "") or "").strip()
                req_url = (
                    f"{url}/library/sections/{section}?X-Plex-Token={key}"
                    if section else
                    f"{url}/library/sections?X-Plex-Token={key}"
                )
                r = _req.Request(req_url, headers={"Accept": "application/json"})
                with _req.urlopen(r, timeout=8) as resp:
                    data = json.loads(resp.read())
                dirs = data.get("MediaContainer", {}).get("Directory", [])
                if isinstance(dirs, dict):
                    dirs = [dirs]
                scanning = any(d.get("refreshing") in (1, True, "1", "true") for d in dirs)
                logger.debug("Plex scan-status poll: refreshing=%s dirs=%s", scanning, [d.get("title","?") + "=" + str(d.get("refreshing")) for d in dirs])
                return jsonify({"scanning": scanning})

            return jsonify({"scanning": False, "error": "Unbekannter Typ"})
        except Exception as e:
            return jsonify({"scanning": False, "error": str(e)})


    # ── Plex OAuth proxy (avoids CORS in the browser) ──────────────────────
    _PLEX_CLIENT_ID = "aniworld-downloader"
    _PLEX_PRODUCT   = "AniWorld Downloader"

    @app.route("/api/settings/mediaplayer/scan", methods=["POST"])
    def api_mediaplayer_scan():
        """Manually trigger a library scan/refresh on the configured media server."""
        svc = get_setting("mediaplayer_type", "")
        url = _normalize_media_url(get_setting("mediaplayer_url", "") or "")
        key = get_setting("mediaplayer_apikey", "") or ""
        if not svc or not key:
            return jsonify({"ok": False, "error": "Kein Mediaplayer konfiguriert"}), 400
        if svc == "plex":
            url = _normalize_media_url(get_setting("mediaplayer_plex_url", "") or "") or url
        if not url:
            return jsonify({"ok": False, "error": "Keine Server-URL konfiguriert"}), 400
        try:
            _trigger_mediaplayer_refresh()
            label = "Jellyfin" if svc == "jellyfin" else "Plex"
            return jsonify({"ok": True, "message": f"{label} Mediascan wurde ausgelöst"})
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 500


    @app.route("/api/settings/mediaplayer/plex-pin", methods=["POST"])
    def api_mediaplayer_plex_pin_create():
        """Create a Plex OAuth pin and return {id, code, auth_url}."""
        import urllib.request as _req
        try:
            req = _req.Request(
                "https://plex.tv/api/v2/pins?strong=true",
                data=b"",
                method="POST",
                headers={
                    "X-Plex-Client-Identifier": _PLEX_CLIENT_ID,
                    "X-Plex-Product":           _PLEX_PRODUCT,
                    "Accept":                   "application/json",
                },
            )
            with _req.urlopen(req, timeout=10) as resp:
                pin = json.loads(resp.read())
            pin_id   = pin["id"]
            pin_code = pin["code"]
            auth_url = (
                f"https://app.plex.tv/auth#?"
                f"clientID={_PLEX_CLIENT_ID}"
                f"&code={pin_code}"
                f"&context%5Bdevice%5D%5Bproduct%5D={_PLEX_PRODUCT.replace(' ', '+')}"
            )
            return jsonify({"ok": True, "id": pin_id, "code": pin_code, "auth_url": auth_url})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)})

    @app.route("/api/settings/mediaplayer/plex-pin/<int:pin_id>", methods=["GET"])
    def api_mediaplayer_plex_pin_poll(pin_id):
        """Poll Plex for the auth token of a pin. Returns {token} once authorized."""
        import urllib.request as _req
        try:
            req = _req.Request(
                f"https://plex.tv/api/v2/pins/{pin_id}",
                headers={
                    "X-Plex-Client-Identifier": _PLEX_CLIENT_ID,
                    "Accept":                   "application/json",
                },
            )
            with _req.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
            token = data.get("authToken") or ""
            if token:
                # Persist the token automatically
                set_setting("mediaplayer_apikey", token)
            return jsonify({"ok": True, "token": token, "authorized": bool(token)})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)})

    @app.route("/api/settings/mediaplayer/plex-libraries", methods=["GET"])
    def api_mediaplayer_plex_libraries():
        """Fetch library sections from the configured Plex server."""
        import urllib.request as _req
        url   = _normalize_media_url(get_setting("mediaplayer_plex_url", "") or "")
        token = get_setting("mediaplayer_apikey", "") or ""
        if not url or not token:
            return jsonify({"ok": False, "error": "Plex nicht konfiguriert", "libraries": []})
        try:
            req = _req.Request(
                f"{url}/library/sections?X-Plex-Token={token}",
                headers={"Accept": "application/json"},
            )
            with _req.urlopen(req, timeout=8) as resp:
                data = json.loads(resp.read())
            dirs = data.get("MediaContainer", {}).get("Directory", [])
            libs = [{"id": str(d["key"]), "title": d["title"], "type": d.get("type", "")}
                    for d in dirs]
            return jsonify({"ok": True, "libraries": libs})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e), "libraries": []})

    # ---------------------------------------------------------------------------
    #  MediaScan endpoints
    # ---------------------------------------------------------------------------

    @app.route("/api/settings/mediascan", methods=["GET"])
    def api_settings_mediascan_get():
        with _mediascan_status_lock:
            status_snap = dict(_mediascan_status)
        last_ts      = get_mediascan_last_updated()
        count        = get_mediascan_count()
        enabled      = get_setting("mediascan_enabled",    "0") == "1"
        source       = get_setting("mediascan_source",     "") or ""
        jf_url_raw   = get_setting("mediascan_jf_url",     "") or ""
        jf_key       = get_setting("mediascan_jf_apikey",  "") or ""
        plex_url_raw = get_setting("mediascan_plex_url",   "") or ""
        plex_section = get_setting("mediascan_plex_section","") or ""
        plex_token   = get_setting("mediaplayer_apikey",   "") or ""  # shared
        has_tmdb     = bool(get_setting("cineinfo_tmdb_api_key", "") or "")
        # Strip scheme for display in frontend inputs
        def _strip(u): return (u or "").replace("https://","").replace("http://","")
        return jsonify({
            "enabled":       enabled,
            "source":        source,
            "jf_url":        _strip(jf_url_raw),
            "jf_apikey":     jf_key,
            "jf_ssl":        jf_url_raw.startswith("https://"),
            "plex_url":      _strip(plex_url_raw),
            "plex_ssl":      plex_url_raw.startswith("https://"),
            "plex_section":  plex_section,
            "has_plex_token": bool(plex_token),
            "plex_token_masked": (plex_token[:4] + "\u2022\u2022\u2022\u2022" + plex_token[-4:]) if len(plex_token) >= 8 else "",
            "has_tmdb":      has_tmdb,
            "last_updated":  last_ts,
            "count":         count,
            "scan_running":  status_snap["running"],
            "scan_started":  status_snap["started_at"],
            "scan_finished": status_snap["finished_at"],
            "scan_count":    status_snap["count"],
            "scan_total":    status_snap["total"],
            "scan_error":    status_snap["error"],
            "scan_source":   status_snap["source"],
        })

    @app.route("/api/settings/mediascan", methods=["PUT"])
    def api_settings_mediascan_put():
        data    = request.get_json(silent=True) or {}
        enabled = "1" if data.get("enabled") else "0"
        source  = str(data.get("source") or "").strip()
        set_setting("mediascan_enabled",     enabled)
        set_setting("mediascan_source",      source)
        # Jellyfin fields
        if "jf_url" in data:
            ssl = data.get("jf_ssl", False)
            raw = (data["jf_url"] or "").strip().lstrip("http://").lstrip("https://")
            set_setting("mediascan_jf_url", ("https://" if ssl else "http://") + raw if raw else "")
        if "jf_apikey" in data:
            set_setting("mediascan_jf_apikey", str(data["jf_apikey"] or "").strip())
        # Plex fields (token is saved separately by the OAuth flow)
        if "plex_url" in data:
            ssl = data.get("plex_ssl", False)
            raw = (data["plex_url"] or "").strip().lstrip("http://").lstrip("https://")
            set_setting("mediascan_plex_url", ("https://" if ssl else "http://") + raw if raw else "")
        if "plex_section" in data:
            set_setting("mediascan_plex_section", str(data["plex_section"] or "").strip())
        return jsonify({"ok": True})

    @app.route("/api/settings/mediascan/refresh", methods=["POST"])
    def api_mediascan_refresh():
        with _mediascan_status_lock:
            if _mediascan_status["running"]:
                return jsonify({"ok": False, "error": "Scan laeuft bereits"})
        source = get_setting("mediascan_source", "") or ""
        if not source or source == "folders":
            return jsonify({"ok": False, "error": "Keine Mediathek-Quelle konfiguriert"})
        t = threading.Thread(target=_run_mediascan, args=(source,), daemon=True)
        t.start()
        return jsonify({"ok": True})

    @app.route("/api/settings/mediascan/status", methods=["GET"])
    def api_mediascan_status():
        with _mediascan_status_lock:
            snap = dict(_mediascan_status)
        last_ts = get_mediascan_last_updated()
        count   = get_mediascan_count()
        return jsonify({
            "running":      snap["running"],
            "started_at":   snap["started_at"],
            "finished_at":  snap["finished_at"],
            "count":        snap["count"],
            "total":        snap["total"],
            "error":        snap["error"],
            "source":       snap["source"],
            "last_updated":  last_ts,
            "cached_count":  count,
        })

    @app.route("/api/settings/mediascan/plex-libraries", methods=["GET"])
    def api_mediascan_plex_libraries():
        import urllib.request as _req
        url   = _normalize_media_url(get_setting("mediascan_plex_url", "") or "")
        token = get_setting("mediaplayer_apikey", "") or ""  # shared token
        if not url or not token:
            return jsonify({"ok": False, "error": "Plex nicht konfiguriert", "libraries": []})
        try:
            req = _req.Request(
                f"{url}/library/sections?X-Plex-Token={token}",
                headers={"Accept": "application/json"},
            )
            with _req.urlopen(req, timeout=8) as resp:
                import json as _j
                data = _j.loads(resp.read())
            dirs = data.get("MediaContainer", {}).get("Directory", [])
            libs = [{"id": str(d["key"]), "title": d["title"], "type": d.get("type", "")}
                    for d in dirs]
            return jsonify({"ok": True, "libraries": libs})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e), "libraries": []})

    @app.route("/api/mediascan/library", methods=["GET"])
    def api_mediascan_library():
        enabled = get_setting("mediascan_enabled", "0") == "1"
        source  = get_setting("mediascan_source",  "") or ""
        if not enabled or not source or source == "folders":
            return jsonify({"enabled": False, "source": source,
                            "tmdb_ids": [], "imdb_ids": [], "titles": []})
        ids = get_mediascan_ids()
        return jsonify({
            "enabled":  True,
            "source":   source,
            "tmdb_ids": ids["tmdb_ids"],
            "imdb_ids": ids["imdb_ids"],
            "titles":   ids["titles"],
        })

    @app.route("/api/mediascan/debug", methods=["GET"])
    def api_mediascan_debug():
        """Return first 50 cache entries for diagnosing match issues."""
        from .db import get_db as _get_db
        conn = _get_db()
        try:
            rows = conn.execute(
                "SELECT tmdb_id, imdb_id, tvdb_id, title, media_type FROM mediascan_cache"
                " ORDER BY id LIMIT 50"
            ).fetchall()
            total = conn.execute("SELECT COUNT(*) AS n FROM mediascan_cache").fetchone()["n"]
        finally:
            conn.close()
        return jsonify({
            "total": total,
            "sample": [{"tmdb_id": r["tmdb_id"], "imdb_id": r["imdb_id"],
                         "tvdb_id": r["tvdb_id"], "title": r["title"],
                         "media_type": r["media_type"]} for r in rows],
        })

    # ---------------------------------------------------------------------------
    # Shared TMDB lookup helper — used by API endpoint AND background prefetch
    # ---------------------------------------------------------------------------
    import requests as _rq_tmdb

    # Token-bucket rate limiter — TMDB allows ~40 req/10 s; we stay at 3 req/s
    # to leave headroom for the prefetch worker, batch endpoint and modal lookups.
    class _TmdbRateLimiter:
        def __init__(self, rate=3.0):
            self._rate = rate
            self._tokens = float(rate)
            self._last = time.monotonic()
            self._lock = threading.Lock()

        def acquire(self):
            with self._lock:
                now = time.monotonic()
                elapsed = now - self._last
                self._last = now
                self._tokens = min(self._rate, self._tokens + elapsed * self._rate)
                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    wait = 0.0
                else:
                    wait = (1.0 - self._tokens) / self._rate
                    self._tokens = 0.0
            if wait > 0:
                time.sleep(wait)

    _tmdb_rl = _TmdbRateLimiter(rate=3.0)

    # In-flight deduplication — prevents duplicate concurrent TMDB lookups
    # for the same cache_key (e.g. two cards with the same title loading at once).
    _tmdb_inflight: dict = {}
    _tmdb_inflight_lock = threading.Lock()

    def _tmdb_lookup_cached(title, imdb_id, api_key, country):
        """
        Look up TMDB data for a title/IMDB-ID and cache in SQLite for 24 h.
        Lookup order:
          1. SQLite cache hit (checks BOTH the imdb_id key AND the title key)
          2. /find/{imdb_id}?external_source=imdb_id  (if imdb_id given)
          3. /search/multi?query={title}              (fallback)
        Results are stored under both keys so card (title) and modal (imdb_id)
        lookups always find the same cached entry.
        Returns dict with keys: found, tmdb_id, media_type, genres, providers, fsk
        """
        imdb_key  = (imdb_id + "|||" + country) if imdb_id else None
        title_key = (title   + "|||" + country) if title   else None

        # Check both cache keys — whichever was written first wins
        for ck in filter(None, [imdb_key, title_key]):
            cached = get_tmdb_cache(ck)
            if cached is not None:
                # Force refresh if missing new keys (trailers/recommendations)
                if not cached.get("found", True) or ("trailer_key" in cached and "recommendations" in cached):
                    # Warm the other key so next call is also a hit
                    other = title_key if ck == imdb_key else imdb_key
                    if other and get_tmdb_cache(other) is None:
                        set_tmdb_cache(other, cached)
                    return cached

        cache_key = imdb_key or title_key  # primary key for the fresh lookup

        # In-flight deduplication: if another thread is already fetching this
        # title, wait for it to finish then return whatever it cached.
        with _tmdb_inflight_lock:
            inflight_ev = _tmdb_inflight.get(cache_key)
            if inflight_ev is None:
                my_ev = threading.Event()
                _tmdb_inflight[cache_key] = my_ev
            else:
                my_ev = None  # we are the waiter

        if inflight_ev is not None:
            # Another thread is doing the lookup — wait up to 25 s then re-check cache
            inflight_ev.wait(timeout=25)
            for ck in filter(None, [imdb_key, title_key]):
                cached = get_tmdb_cache(ck)
                if cached is not None and "trailer_key" in cached and "recommendations" in cached:
                    return cached
            return {"found": False}

        def _call(path, extra=None):
            lang = "de-DE"
            if country == "US":
                lang = "en-US"
            params = {"api_key": api_key}
            if extra is None or "language" not in extra:
                params["language"] = lang
            if extra:
                params.update(extra)
            _tmdb_rl.acquire()  # respect global rate limit (3 req/s)
            r = _rq_tmdb.get(
                "https://api.themoviedb.org/3" + path,
                params=params, timeout=8,
                headers={"User-Agent": "AniWorldDownloader/1.0"},
            )
            r.raise_for_status()
            return r.json()

        try:
            tid = None
            mt  = None
            # 1. Direct IMDB-ID lookup (most accurate)
            if imdb_id:
                try:
                    find_data = _call("/find/" + imdb_id, {"external_source": "imdb_id"})
                    for media_type, key in (("tv", "tv_results"), ("movie", "movie_results")):
                        hits = find_data.get(key, [])
                        if hits:
                            tid = hits[0]["id"]
                            mt  = media_type
                            break
                except Exception as _fe:
                    logger.debug("[CineInfo] /find by imdb_id %r failed: %s", imdb_id, _fe)
            # 2. Fall back to title search
            if tid is None:
                if not title:
                    out = {"found": False}
                    set_tmdb_cache(cache_key, out)
                    return out
                search = _call("/search/multi", {"query": title})
                results = [r for r in search.get("results", []) if r.get("media_type") in ("movie", "tv")]
                
                # Fallback 1: Try without single quotes/apostrophes (e.g. "I'll" -> "Ill" or "I ll")
                if not results:
                    import re
                    # Sometimes TMDB prefers the word without the apostrophe entirely, or with a space.
                    # We'll try removing them first.
                    clean_title = re.sub(r"['’´`]", "", title)
                    if clean_title != title:
                        search = _call("/search/multi", {"query": clean_title})
                        results = [r for r in search.get("results", []) if r.get("media_type") in ("movie", "tv")]
                
                # Fallback 2: Try removing other special punctuation that might differ (like '!', '?', ':')
                if not results:
                    clean_title_2 = re.sub(r"[!\?:;]", "", title)
                    if clean_title_2 != title:
                        search = _call("/search/multi", {"query": clean_title_2})
                        results = [r for r in search.get("results", []) if r.get("media_type") in ("movie", "tv")]
                        
                # Fallback 3: Try removing (Year) tags like (2026)
                if not results:
                    clean_title_3 = re.sub(r"\s*\(\d{4}\)", "", title).strip()
                    if clean_title_3 != title:
                        search = _call("/search/multi", {"query": clean_title_3})
                        results = [r for r in search.get("results", []) if r.get("media_type") in ("movie", "tv")]
                        
                # Fallback 4: Split by hyphen and use first part (e.g. "Occupied - Die Besatzung" -> "Occupied")
                if not results and ("-" in title or "–" in title):
                    clean_title_4 = re.split(r"[-–]", title)[0].strip()
                    if clean_title_4 and clean_title_4 != title:
                        search = _call("/search/multi", {"query": clean_title_4})
                        results = [r for r in search.get("results", []) if r.get("media_type") in ("movie", "tv")]

                if not results:
                    out = {"found": False}
                    set_tmdb_cache(cache_key, out)
                    return out
                best = results[0]
                tid  = best["id"]
                mt   = best["media_type"]
            # 3. Fetch details, watch-providers, FSK
            details  = _call("/" + mt + "/" + str(tid))
            genres   = [g["name"] for g in details.get("genres", [])]
            wp_data  = _call("/" + mt + "/" + str(tid) + "/watch/providers")
            c_data   = wp_data.get("results", {}).get(country, {})
            flatrate = [p["provider_name"] for p in c_data.get("flatrate", [])]
            buy_list = [p["provider_name"] for p in c_data.get("buy", [])]
            rent_list= [p["provider_name"] for p in c_data.get("rent", [])]
            providers = flatrate[:]
            for p in buy_list + rent_list:
                if p not in providers:
                    providers.append(p)
            fsk = ""
            try:
                if mt == "tv":
                    cr = _call("/tv/" + str(tid) + "/content_ratings")
                    for r in cr.get("results", []):
                        if r.get("iso_3166_1") == country:
                            fsk = r.get("rating", "")
                            break
                else:
                    rd = _call("/movie/" + str(tid) + "/release_dates")
                    for entry in rd.get("results", []):
                        if entry.get("iso_3166_1") == country:
                            for rdate in entry.get("release_dates", []):
                                c = rdate.get("certification", "")
                                if c:
                                    fsk = c
                                    break
                            break
            except Exception:
                pass

            # 4. Fetch Trailers (Videos) - Fetch ALL languages first
            trailer_key = ""
            try:
                # Omit language to get all available videos
                videos = _call("/" + mt + "/" + str(tid) + "/videos", {"language": ""}) 
                results = videos.get("results", [])
                
                # Priority 1: German Trailer
                for v in results:
                    if v.get("site") == "YouTube" and v.get("type") == "Trailer" and v.get("iso_639_1") == "de":
                        trailer_key = v.get("key")
                        break
                
                # Priority 2: English Trailer
                if not trailer_key:
                    for v in results:
                        if v.get("site") == "YouTube" and v.get("type") == "Trailer" and v.get("iso_639_1") == "en":
                            trailer_key = v.get("key")
                            break
                            
                # Priority 3: Any Trailer
                if not trailer_key:
                    for v in results:
                        if v.get("site") == "YouTube" and v.get("type") == "Trailer":
                            trailer_key = v.get("key")
                            break
            except Exception:
                pass

            if not trailer_key:
                try:
                    videos = _call("/" + mt + "/" + str(tid) + "/videos", {"language": "en-US"})
                    for v in videos.get("results", []):
                        if v.get("site") == "YouTube" and v.get("type") == "Trailer":
                            trailer_key = v.get("key", "")
                            break
                except Exception:
                    pass

            # 5. Fetch Recommendations
            recommendations = []
            try:
                rec_data = _call("/" + mt + "/" + str(tid) + "/recommendations", {"page": 1, "language": "de-DE"})
                for r in rec_data.get("results", [])[:6]: # Max 6
                    recommendations.append({
                        "id": r.get("id"),
                        "title": r.get("name") or r.get("title"),
                        "poster_path": r.get("poster_path"),
                        "vote_average": r.get("vote_average")
                    })
            except Exception:
                pass

            out = {"found": True, "tmdb_id": tid, "media_type": mt,
                   "genres": genres, "providers": providers, "fsk": fsk,
                   "vote_average": round(details.get("vote_average") or 0, 1),
                   "trailer_key": trailer_key,
                   "recommendations": recommendations}
            # Store under both keys so card (title) and modal (imdb_id) share the entry
            logger.info("[CineInfo] TMDB data for %r: trailer=%s, recs=%d", title, trailer_key, len(recommendations))
            for ck in filter(None, [imdb_key, title_key]):
                set_tmdb_cache(ck, out)
            return out
        except Exception as exc:
            logger.warning("[CineInfo] TMDB lookup failed for %r: %s", title or imdb_id, exc)
            return {"found": False}
        finally:
            # Always release the in-flight event so waiting threads wake up
            if my_ev is not None:
                with _tmdb_inflight_lock:
                    _tmdb_inflight.pop(cache_key, None)
                my_ev.set()

    @app.route("/api/tmdb/info")
    def api_tmdb_info():
        title   = (request.args.get("title")   or "").strip()
        imdb_id = (request.args.get("imdb_id") or "").strip() or None
        if not title and not imdb_id:
            return jsonify({"error": "title or imdb_id required"}), 400
        api_key = get_setting("cineinfo_tmdb_api_key", "")
        if not api_key:
            return jsonify({"found": False, "reason": "no_key"})
        country = get_setting("cineinfo_country", "DE")
        return jsonify(_tmdb_lookup_cached(title, imdb_id, api_key, country))

    @app.route("/api/tmdb/batch", methods=["POST"])
    def api_tmdb_batch():
        """Fetch TMDB data for multiple titles in one request.

        Accepts: {"titles": ["Title A", "Title B", ...]}  (max 25)
        Returns: {"Title A": {found, ...}, "Title B": {found, ...}}

        Internally uses a thread pool (max 3 workers) so lookups for
        already-cached titles complete instantly while cold ones are
        fetched concurrently. All HTTP calls to TMDB still go through
        the shared rate-limiter, so we never exceed 3 req/s globally.
        """
        import concurrent.futures as _cf
        data = request.get_json(silent=True) or {}
        raw_titles = data.get("titles") or []
        titles = [str(t).strip() for t in raw_titles if t][:25]  # cap at 25
        if not titles:
            return jsonify({})
        api_key = get_setting("cineinfo_tmdb_api_key", "")
        if not api_key:
            return jsonify({t: {"found": False, "reason": "no_key"} for t in titles})
        country = get_setting("cineinfo_country", "DE")

        results = {}
        # max_workers=3 limits concurrent lookups; the rate limiter inside
        # _tmdb_lookup_cached serialises the actual TMDB HTTP calls globally.
        with _cf.ThreadPoolExecutor(max_workers=3, thread_name_prefix="tmdb-batch") as pool:
            future_to_title = {
                pool.submit(_tmdb_lookup_cached, t, None, api_key, country): t
                for t in titles
            }
            for fut in _cf.as_completed(future_to_title, timeout=35):
                t = future_to_title[fut]
                try:
                    results[t] = fut.result()
                except Exception as exc:
                    logger.debug("[CineInfo] batch lookup failed for %r: %s", t, exc)
                    results[t] = {"found": False}
        return jsonify(results)


    @app.route("/api/tmdb/cache/clear", methods=["POST"])
    def api_tmdb_cache_clear():
        """Clear all CineInfo/TMDB cached data and trigger a fresh prefetch cycle.

        Steps:
          1. Wipe the SQLite tmdb_cache table (24h persistent data)
          2. Clear the in-memory browse cache so the next browse request
             re-attaches TMDB data from scratch
          3. Kick off a new prefetch cycle in the background so data is
             warmed up without making the caller wait
        """
        clear_tmdb_cache()
        _browse_cache.clear()   # force re-evaluation of inline TMDB data
        # Start a fresh prefetch in background — returns immediately to caller
        threading.Thread(
            target=_prefetch_cycle,
            daemon=True,
            name="cineinfo-manual-refresh",
        ).start()
        logger.info("[CineInfo] Cache manually cleared — prefetch triggered")
        return jsonify({"ok": True, "message": "Cache geleert, Neuladen gestartet"})

    @app.route("/api/settings/dns", methods=["PUT"])
    def api_settings_dns():
        data = request.get_json(silent=True) or {}
        mode   = str(data.get("dns_mode",   "system")).strip()
        server = str(data.get("dns_server", "")).strip()

        valid_modes = {"system", "cloudflare", "google", "quad9", "custom"}
        if mode not in valid_modes:
            return jsonify({"error": f"Ungültiger Modus: {mode}"}), 400
        if mode == "custom" and not server:
            return jsonify({"error": "Benutzerdefinierter DNS-Server fehlt"}), 400

        set_setting("dns_mode",   mode)
        set_setting("dns_server", server)

        # Apply patch immediately (no restart needed)
        if mode == "system":
            _apply_dns_patch(None, mode=None)
        else:
            target = _DNS_PRESETS.get(mode) or server
            _apply_dns_patch(target, mode=mode)

        return jsonify({"ok": True, "active_server": _active_dns_server})

    @app.route("/api/settings/dns/test", methods=["GET"])
    def api_dns_test():
        """
        Test the current DNS configuration by:
          1. Reporting which DNS mode / server is active in memory.
          2. Resolving each hostname via the patched socket (covers ffmpeg etc.).
          3. Making a real GET request to each site via GLOBAL_SESSION (niquests/DoH)
             and verifying the response body contains a known marker so we know we
             actually reached the correct site (not a block page).
        """
        import socket as _sock
        from ..config import GLOBAL_SESSION as _GS

        _saved_mode = get_setting("dns_mode", "system")
        _saved_server = get_setting("dns_server", "")

        # (url, expected-domain-fragment, body-fallback-markers)
        # Verification priority:
        #   1. Final URL after redirects contains the expected domain → verified
        #   2. Response body contains at least one marker → verified
        #   (Cloudflare challenge pages land on the correct domain, so URL check
        #    handles CDN-fronted sites that return JS challenges to bots.)
        sites = {
            "AniWorld":   ("https://aniworld.to",   "aniworld.to",   ["aniworld", "anime"]),
            "S.TO":       ("https://s.to",          "s.to",          ["serienstream", "serie", "s.to"]),
            "FilmPalast": ("https://filmpalast.to", "filmpalast.to", ["filmpalast", "film"]),
        }

        results = {}
        for label, (url, expected_domain, markers) in sites.items():
            hostname = url.replace("https://", "").rstrip("/")
            entry = {"hostname": hostname}

            # --- socket resolve (tests getaddrinfo patch) ---
            try:
                infos = _sock.getaddrinfo(hostname, 443, proto=_sock.IPPROTO_TCP)
                entry["ip"] = infos[0][4][0] if infos else None
                entry["socket_ok"] = True
            except Exception as e:
                entry["ip"] = None
                entry["socket_ok"] = False
                entry["socket_error"] = str(e)

            # --- HTTP reachability + site identity check via GLOBAL_SESSION ---
            try:
                resp = _GS.get(url, allow_redirects=True, timeout=10)
                entry["http_status"] = resp.status_code
                entry["http_ok"] = resp.status_code < 500

                # Primary: check final URL domain (works even through Cloudflare challenges)
                final_url = str(getattr(resp, "url", url) or url)
                url_verified = expected_domain in final_url

                # Fallback: body content check
                body_lower = (resp.text or "").lower()
                body_verified = any(m.lower() in body_lower for m in markers)

                entry["site_verified"] = url_verified or body_verified
            except Exception as e:
                entry["http_ok"] = False
                entry["site_verified"] = False
                entry["http_error"] = str(e)

            results[label] = entry

        return jsonify({
            "dns_mode":          _saved_mode,
            "dns_server_saved":  _saved_server,
            "dns_active_server": _active_dns_server,
            "sites":             results,
        })

    @app.route("/api/seerr/requests")
    def api_seerr_requests():
        import urllib.request as _urllib
        import urllib.parse as _urlparse
        from concurrent.futures import ThreadPoolExecutor, as_completed

        seerr_url = (get_setting("seerr_url") or "").rstrip("/")
        seerr_key = get_setting("seerr_api_key") or ""
        if not seerr_url or not seerr_key:
            return jsonify({"error": "Seerr nicht konfiguriert"}), 400

        def seerr_get(path, params=None):
            url = seerr_url + path
            if params:
                url += "?" + _urlparse.urlencode(params)
            req = _urllib.Request(url, headers={"X-Api-Key": seerr_key})
            with _urllib.urlopen(req, timeout=10) as r:
                return json.loads(r.read())

        take = min(int(request.args.get("take", 20)), 50)
        skip = max(int(request.args.get("skip", 0)), 0)

        # Fetch pending + approved for both TV and movies in parallel (4 requests)
        def fetch_filter(f, media_type):
            return seerr_get("/api/v1/request", {
                "filter": f, "mediaType": media_type,
                "take": 500, "skip": 0,
                "sort": "added", "sortDirection": "desc",
            })

        from concurrent.futures import ThreadPoolExecutor
        try:
            with ThreadPoolExecutor(max_workers=4) as ex:
                fut_tv_pending    = ex.submit(fetch_filter, "pending",  "tv")
                fut_tv_approved   = ex.submit(fetch_filter, "approved", "tv")
                fut_mv_pending    = ex.submit(fetch_filter, "pending",  "movie")
                fut_mv_approved   = ex.submit(fetch_filter, "approved", "movie")
                tv_pending    = fut_tv_pending.result().get("results", [])
                tv_approved   = fut_tv_approved.result().get("results", [])
                mv_pending    = fut_mv_pending.result().get("results", [])
                mv_approved   = fut_mv_approved.result().get("results", [])
        except Exception as e:
            return jsonify({"error": f"Seerr nicht erreichbar: {e}"}), 502

        # Tag each item with its media type so we know which detail endpoint to call
        for r in tv_pending + tv_approved:
            r.setdefault("_media_type", "tv")
        for r in mv_pending + mv_approved:
            r.setdefault("_media_type", "movie")

        # Merge + de-duplicate by request id, sort newest first
        seen = set()
        merged = []
        for r in tv_pending + tv_approved + mv_pending + mv_approved:
            if r["id"] not in seen:
                seen.add(r["id"])
                merged.append(r)
        # Keep only truly pending (1) or approved-but-not-yet-available (2)
        # Also exclude items where the media itself is already fully available (media.status == 5)
        merged = [
            r for r in merged
            if r.get("status") in (1, 2)
            and r.get("media", {}).get("status") != 5
        ]
        merged.sort(key=lambda r: r.get("createdAt", ""), reverse=True)

        total_all = len(merged)
        items = merged[skip: skip + take]

        # Fetch detail pages in parallel (TV → /tv/{id}, Movie → /movie/{id})
        def fetch_detail(req):
            media = req.get("media") or {}
            tmdb_id = media.get("tmdbId")
            media_type = req.get("_media_type", "tv")
            if not tmdb_id:
                return tmdb_id, media_type, {}
            try:
                endpoint = f"/api/v1/{'movie' if media_type == 'movie' else 'tv'}/{tmdb_id}"
                return tmdb_id, media_type, seerr_get(endpoint)
            except Exception:
                return tmdb_id, media_type, {}

        detail_map = {}  # (tmdb_id, media_type) → details
        with ThreadPoolExecutor(max_workers=6) as ex:
            for tmdb_id, media_type, details in ex.map(fetch_detail, items):
                if tmdb_id:
                    detail_map[(tmdb_id, media_type)] = details

        result = []
        for req in items:
            media = req.get("media") or {}
            tmdb_id = media.get("tmdbId")
            media_type = req.get("_media_type", "tv")
            det = detail_map.get((tmdb_id, media_type), {})
            is_movie = media_type == "movie"
            # TV uses "name"/"firstAirDate"/"numberOfSeasons"; Movie uses "title"/"releaseDate"
            title = (det.get("title") if is_movie else det.get("name")) or det.get("originalTitle") or det.get("originalName") or f"TMDB #{tmdb_id}"
            year = ((det.get("releaseDate") if is_movie else det.get("firstAirDate")) or "")[:4]
            result.append({
                "id": req["id"],
                "status": req.get("status"),
                "downloadStatus": req["media"]["status"],
                "createdAt": req.get("createdAt"),
                "requestedBy": (req.get("requestedBy") or {}).get("displayName", ""),
                "tmdbId": tmdb_id,
                "mediaType": media_type,
                "isMovie": is_movie,
                "title": title,
                "posterPath": det.get("posterPath") or "",
                "posterUrl": _poster_proxy("https://image.tmdb.org/t/p/w342" + det["posterPath"]) if det.get("posterPath") else "",
                "backdropUrl": _poster_proxy("https://image.tmdb.org/t/p/w780" + det["backdropPath"]) if det.get("backdropPath") else "",
                "overview": det.get("overview") or "",
                "firstAirDate": year,
                "numberOfSeasons": det.get("numberOfSeasons") or 0,
                "requestedSeasons": sorted(
                    s["seasonNumber"] for s in (req.get("seasons") or [])
                    if isinstance(s, dict) and s.get("seasonNumber") is not None
                ),
            })

        return jsonify({"requests": result, "total": total_all, "skip": skip, "take": take})

    @app.route("/api/settings", methods=["PUT"])
    def api_settings_update():
        data = request.get_json(silent=True) or {}
        logger.info("[Settings] PUT /api/settings received data: %r", data)
        if "download_path" in data:
            val = str(data["download_path"]).strip()
            set_setting("download_path", val)
            os.environ["ANIWORLD_DOWNLOAD_PATH"] = val
        if "lang_separation" in data:
            val = "1" if data["lang_separation"] else "0"
            set_setting("lang_separation", val)
            os.environ["ANIWORLD_LANG_SEPARATION"] = val
        if "disable_english_sub" in data:
            val = "1" if data["disable_english_sub"] else "0"
            set_setting("disable_english_sub", val)
            os.environ["ANIWORLD_DISABLE_ENGLISH_SUB"] = val
        if "filmpalast_movie_subfolder" in data:
            val = "1" if data["filmpalast_movie_subfolder"] else "0"
            set_setting("filmpalast_movie_subfolder", val)
            os.environ["FILMPALAST_MOVIE_SUBFOLDER"] = val
        if "sync_schedule" in data:
            sched = str(data["sync_schedule"])
            if sched != "0" and sched not in SYNC_SCHEDULE_MAP:
                return jsonify({"error": f"Invalid sync_schedule: {sched}"}), 400
            set_setting("sync_schedule", sched)
            os.environ["ANIWORLD_SYNC_SCHEDULE"] = sched
        if "sync_language" in data:
            lang = str(data["sync_language"])
            valid_langs = set(LANG_LABELS.values()) | {"All Languages"}
            if lang not in valid_langs:
                return jsonify({"error": f"Invalid sync_language: {lang}"}), 400
            set_setting("sync_language", lang)
            os.environ["ANIWORLD_SYNC_LANGUAGE"] = lang
        if "sync_provider" in data:
            prov = str(data["sync_provider"])
            if prov not in WORKING_PROVIDERS:
                return jsonify({"error": f"Invalid sync_provider: {prov}"}), 400
            set_setting("sync_provider", prov)
            os.environ["ANIWORLD_SYNC_PROVIDER"] = prov
        if "sync_path_unavailable_action" in data:
            action = str(data["sync_path_unavailable_action"]).strip().lower()
            if action not in ("skip", "hold"):
                return jsonify({"error": "Invalid sync_path_unavailable_action: must be 'skip' or 'hold'"}), 400
            set_setting("sync_path_unavailable_action", action)
            os.environ["ANIWORLD_SYNC_PATH_UNAVAILABLE_ACTION"] = action
        if "sync_error_retries" in data:
            try:
                retries = int(data["sync_error_retries"])
                if retries < 0 or retries > 10:
                    raise ValueError()
            except (ValueError, TypeError):
                return jsonify({"error": "Invalid sync_error_retries: must be integer between 0 and 10"}), 400
            set_setting("sync_error_retries", str(retries))
            os.environ["ANIWORLD_SYNC_ERROR_RETRIES"] = str(retries)
        if "sync_error_retry_time" in data:
            retry_time = str(data["sync_error_retry_time"])
            if retry_time not in SYNC_RETRY_MAP:
                return jsonify({"error": f"Invalid sync_error_retry_time: {retry_time}"}), 400
            set_setting("sync_error_retry_time", retry_time)
            os.environ["ANIWORLD_SYNC_ERROR_RETRY_TIME"] = retry_time
        if "download_language" in data:
            val = str(data["download_language"]).strip()
            set_setting("download_language", val)
            os.environ["ANIWORLD_LANGUAGE"] = val
        if "download_provider" in data:
            val = str(data["download_provider"]).strip()
            set_setting("download_provider", val)
            os.environ["ANIWORLD_PROVIDER"] = val
        if "naming_template" in data:
            val = str(data["naming_template"]).strip()
            set_setting("naming_template", val)
            os.environ["ANIWORLD_NAMING_TEMPLATE"] = val
        if "web_base_url" in data:
            val = str(data["web_base_url"]).strip().rstrip("/")
            set_setting("web_base_url", val)
            os.environ["ANIWORLD_WEB_BASE_URL"] = val
        if "debug_mode" in data:
            val = str(data["debug_mode"])
            if val.lower() in ("true", "1"): val = "1"
            else: val = "0"
            set_setting("debug_mode", val)
            os.environ["ANIWORLD_DEBUG_MODE"] = val
            if val == "1":
                import logging
                logging.getLogger().setLevel(logging.DEBUG)
        return jsonify({"ok": True})

    @app.route("/api/custom-paths")
    def api_custom_paths():
        paths = get_custom_paths()
        return jsonify({"paths": paths})

    @app.route("/api/custom-paths", methods=["POST"])
    def api_custom_paths_add():
        data = request.get_json(silent=True) or {}
        name = (data.get("name") or "").strip()
        path = (data.get("path") or "").strip()
        if not name or not path:
            return jsonify({"error": "name and path are required"}), 400
        path_id = add_custom_path(name, path)
        return jsonify({"ok": True, "id": path_id})

    @app.route("/api/custom-paths/<int:path_id>", methods=["DELETE"])
    def api_custom_paths_delete(path_id):
        ok, err = remove_custom_path(path_id)
        if not ok:
            return jsonify({"error": err}), 409
        return jsonify({"ok": True})

    # ===== Auto-Sync Page =====

    @app.route("/autosync")
    def autosync_page():
        return render_template("autosync.html")

    @app.route("/stats")
    def stats_page():
        return render_template("stats.html")

    @app.route("/seerr")
    def seerr_page():
        sto_lang_labels = {"1": "German Dub", "2": "English Dub"}
        return render_template(
            "seerr.html",
            lang_labels=LANG_LABELS,
            sto_lang_labels=sto_lang_labels,
            supported_providers=WORKING_PROVIDERS,
        )

    @app.route("/api/seerr/requests/<int:req_id>/approve", methods=["POST"])
    def api_seerr_approve(req_id):
        import requests as _req
        seerr_url = (get_setting("seerr_url") or "").rstrip("/")
        seerr_key = get_setting("seerr_api_key") or ""
        if not seerr_url or not seerr_key:
            return jsonify({"error": "Seerr nicht konfiguriert"}), 400
        try:
            # Seerr (Jellyseerr/Overseerr) requires a CSRF token even for API-key requests.
            # Use a session so cookies (including the CSRF cookie) persist across requests.
            session = _req.Session()
            session.headers.update({"X-Api-Key": seerr_key})

            # Step 1: GET to receive cookies/CSRF token from Seerr.
            # Try the Next.js CSRF endpoint first, then fall back to a regular API endpoint.
            csrf_token = ""
            for csrf_path in ["/api/auth/csrf", "/api/v1/settings/public"]:
                try:
                    pre = session.get(f"{seerr_url}{csrf_path}", timeout=10)
                    # Next.js csrf endpoint returns {"csrfToken": "..."}
                    if csrf_path == "/api/auth/csrf" and pre.ok:
                        csrf_token = pre.json().get("csrfToken", "")
                    if not csrf_token:
                        # Double-submit cookie pattern: XSRF-TOKEN or CSRF-TOKEN cookie
                        csrf_token = (
                            session.cookies.get("XSRF-TOKEN")
                            or session.cookies.get("CSRF-TOKEN")
                            or session.cookies.get("csrf_token")
                            or ""
                        )
                    if csrf_token:
                        break
                except Exception:
                    pass

            logger.info("Seerr CSRF token for approve: %r, cookies: %s", csrf_token, dict(session.cookies))

            if csrf_token:
                session.headers.update({
                    "X-CSRF-Token": csrf_token,
                    "X-XSRF-TOKEN": csrf_token,
                })

            # Step 2: POST to the approve endpoint.
            resp = session.post(
                f"{seerr_url}/api/v1/request/{req_id}/approve",
                json={},
                timeout=10,
            )
            logger.info("Seerr approve req %s → %s", req_id, resp.status_code)
            if not resp.ok:
                body = resp.text[:300]
                logger.warning("Seerr approve req %s failed: %s %s", req_id, resp.status_code, body)
                return jsonify({"error": f"Seerr {resp.status_code}: {body}"}), 502
            return jsonify({"ok": True})
        except Exception as e:
            logger.warning("Seerr approve req %s error: %s", req_id, e)
            return jsonify({"error": str(e)}), 502

    @app.route("/api/seerr/requests/<int:req_id>/decline", methods=["POST"])
    def api_seerr_decline(req_id):
        import requests as _req
        seerr_url = (get_setting("seerr_url") or "").rstrip("/")
        seerr_key = get_setting("seerr_api_key") or ""
        if not seerr_url or not seerr_key:
            return jsonify({"error": "Seerr nicht konfiguriert"}), 400
        try:
            session = _req.Session()
            session.headers.update({"X-Api-Key": seerr_key})

            # Fetch CSRF token (same pattern as approve)
            csrf_token = ""
            for csrf_path in ["/api/auth/csrf", "/api/v1/settings/public"]:
                try:
                    pre = session.get(f"{seerr_url}{csrf_path}", timeout=10)
                    if csrf_path == "/api/auth/csrf" and pre.ok:
                        csrf_token = pre.json().get("csrfToken", "")
                    if not csrf_token:
                        csrf_token = (
                            session.cookies.get("XSRF-TOKEN")
                            or session.cookies.get("CSRF-TOKEN")
                            or session.cookies.get("csrf_token")
                            or ""
                        )
                    if csrf_token:
                        break
                except Exception:
                    pass

            if csrf_token:
                session.headers.update({
                    "X-CSRF-Token": csrf_token,
                    "X-XSRF-TOKEN": csrf_token,
                })

            resp = session.post(
                f"{seerr_url}/api/v1/request/{req_id}/decline",
                json={},
                timeout=10,
            )
            logger.info("Seerr decline req %s → %s", req_id, resp.status_code)
            if not resp.ok:
                body = resp.text[:300]
                logger.warning("Seerr decline req %s failed: %s %s", req_id, resp.status_code, body)
                return jsonify({"error": f"Seerr {resp.status_code}: {body}"}), 502
            return jsonify({"ok": True})
        except Exception as e:
            logger.warning("Seerr decline req %s error: %s", req_id, e)
            return jsonify({"error": str(e)}), 502

    @app.route("/api/stats")
    def api_stats():
        return jsonify({
            "general": get_general_stats(),
            "queue": get_queue_stats(),
            "sync": get_sync_stats(),
        })

    # ===== Favourites =====

    @app.route("/favourites")
    def favourites_page():
        return render_template("favourites.html")

    @app.route("/api/favourites")
    def api_get_favourites():
        username = None
        if auth_enabled:
            user = get_current_user()
            username = user.get("username") if user else None
        favs = get_favourites(added_by=username)
        # Proxy poster URLs so the client never hits source sites directly
        for f in favs:
            if f.get("poster_url") and not f["poster_url"].startswith("/api/img"):
                f["poster_url"] = _poster_proxy(f["poster_url"])
        return jsonify({"favourites": favs})

    @app.route("/api/favourites", methods=["POST"])
    def api_add_favourite():
        data = request.get_json(silent=True) or {}
        series_url = (data.get("series_url") or "").strip()
        title = (data.get("title") or "").strip()
        raw_poster = (data.get("poster_url") or "").strip()
        # Unwrap proxy URLs so the DB always stores the original source URL
        if raw_poster.startswith("/api/img?url="):
            from urllib.parse import unquote as _unquote_fav
            raw_poster = _unquote_fav(raw_poster[len("/api/img?url="):])
        poster_url = raw_poster or None
        if not series_url or not title:
            return jsonify({"error": "series_url and title required"}), 400
        username = None
        if auth_enabled:
            user = get_current_user()
            username = user.get("username") if user else None
        add_favourite(series_url, title, poster_url, username)
        return jsonify({"ok": True})

    @app.route("/api/favourites", methods=["DELETE"])
    def api_remove_favourite():
        data = request.get_json(silent=True) or {}
        series_url = (data.get("series_url") or "").strip()
        if not series_url:
            return jsonify({"error": "series_url required"}), 400
        username = None
        if auth_enabled:
            user = get_current_user()
            username = user.get("username") if user else None
        remove_favourite(series_url, username)
        return jsonify({"ok": True})

    @app.route("/api/favourites/check")
    def api_check_favourite():
        series_url = request.args.get("series_url", "").strip()
        if not series_url:
            return jsonify({"is_favourite": False})
        username = None
        if auth_enabled:
            user = get_current_user()
            username = user.get("username") if user else None
        return jsonify({"is_favourite": is_favourite(series_url, username)})

    # ===== Auto-Sync API =====

    def _get_current_user_info():
        """Return (username, is_admin) for the current request."""
        if not auth_enabled:
            return None, True  # no auth → treat as admin
        user = get_current_user()
        if not user:
            return None, False
        username = (
            user.get("username")
            if isinstance(user, dict)
            else getattr(user, "username", None)
        )
        role = (
            user.get("role")
            if isinstance(user, dict)
            else getattr(user, "role", "user")
        )
        return username, role == "admin"

    @app.route("/api/autosync")
    def api_autosync_list():
        username, is_admin = _get_current_user_info()
        # Admins see all jobs; regular users see only their own
        jobs = get_autosync_jobs(username=None if is_admin else username)
        return jsonify({"jobs": jobs})

    @app.route("/api/autosync", methods=["POST"])
    def api_autosync_create():
        data = request.get_json(silent=True) or {}
        title = (data.get("title") or "").strip()
        series_url = (data.get("series_url") or "").strip()
        language = data.get("language", "German Dub")
        provider = data.get("provider", "VOE")
        custom_path_id = data.get("custom_path_id")

        if not title or not series_url:
            return jsonify({"error": "title and series_url are required"}), 400

        existing = find_autosync_by_url(series_url)
        if existing:
            return jsonify(
                {"error": "A sync job for this series already exists", "job": existing}
            ), 409

        username, _ = _get_current_user_info()
        # Resolve path_unavailable_action: request body > global setting > "skip"
        path_action = (
            data.get("path_unavailable_action")
            or get_setting("sync_path_unavailable_action")
            or os.environ.get("ANIWORLD_SYNC_PATH_UNAVAILABLE_ACTION", "skip")
        ).strip().lower()
        if path_action not in ("skip", "hold"):
            path_action = "skip"
        job_id = add_autosync_job(
            title=title,
            series_url=series_url,
            language=language,
            provider=provider,
            custom_path_id=custom_path_id,
            added_by=username,
            path_unavailable_action=path_action,
        )
        return jsonify({"ok": True, "id": job_id})

    @app.route("/api/autosync/<int:job_id>", methods=["PUT"])
    def api_autosync_update(job_id):
        job = get_autosync_job(job_id)
        if not job:
            return jsonify({"error": "Job not found"}), 404
        username, is_admin = _get_current_user_info()
        if not is_admin and job.get("added_by") != username:
            return jsonify({"error": "Not authorized to edit this job"}), 403
        data = request.get_json(silent=True) or {}
        allowed = {"language", "provider", "enabled", "custom_path_id", "path_unavailable_action"}
        filtered = {k: v for k, v in data.items() if k in allowed}
        update_autosync_job(job_id, **filtered)
        return jsonify({"ok": True})

    @app.route("/api/autosync/<int:job_id>", methods=["DELETE"])
    def api_autosync_delete(job_id):
        job = get_autosync_job(job_id)
        if not job:
            return jsonify({"error": "Job not found"}), 404
        username, is_admin = _get_current_user_info()
        if not is_admin and job.get("added_by") != username:
            return jsonify({"error": "Not authorized to delete this job"}), 403
        ok, err = remove_autosync_job(job_id)
        if not ok:
            return jsonify({"error": err}), 404
        return jsonify({"ok": True})

    @app.route("/api/autosync/<int:job_id>/sync", methods=["POST"])
    def api_autosync_trigger(job_id):
        job = get_autosync_job(job_id)
        if not job:
            return jsonify({"error": "Job not found"}), 404
        username, is_admin = _get_current_user_info()
        if not is_admin and job.get("added_by") != username:
            return jsonify({"error": "Not authorized"}), 403
        with _syncing_jobs_lock:
            if job_id in _syncing_jobs:
                return jsonify({"error": "Sync already running for this job"}), 409
        threading.Thread(target=_run_autosync_for_job, args=(job, True), daemon=True).start()
        return jsonify({"ok": True, "message": "Sync started"})

    @app.route("/api/autosync/running")
    def api_autosync_running():
        """Return the set of currently running sync job IDs."""
        with _syncing_jobs_lock:
            return jsonify({"running": list(_syncing_jobs)})

    @app.route("/api/autosync/sync-all", methods=["POST"])
    def api_autosync_sync_all():
        """Trigger sync for all enabled jobs the current user owns (or all if admin)."""
        username, is_admin = _get_current_user_info()
        jobs = get_autosync_jobs()
        started = 0
        skipped = 0
        for job in jobs:
            if not job.get("enabled"):
                continue
            if not is_admin and job.get("added_by") != username:
                continue
            job_id = job["id"]
            with _syncing_jobs_lock:
                if job_id in _syncing_jobs:
                    skipped += 1
                    continue
            threading.Thread(target=_run_autosync_for_job, args=(job,), daemon=True).start()
            started += 1
        return jsonify({"ok": True, "started": started, "skipped": skipped})

    @app.route("/api/autosync/check", methods=["GET"])
    def api_autosync_check():
        """Check if a sync job exists for a given series URL."""
        url = request.args.get("url", "").strip()
        if not url:
            return jsonify({"exists": False})
        job = find_autosync_by_url(url)
        if not job:
            return jsonify({"exists": False})
        # Only expose job details to the owner or admins
        username, is_admin = _get_current_user_info()
        if not is_admin and job.get("added_by") != username:
            return jsonify({"exists": False})
        return jsonify({"exists": True, "job": job})


    @app.route("/api/autosync/export", methods=["GET"])
    def api_autosync_export():
        """Export all autosync jobs the current user can see as JSON."""
        username, is_admin = _get_current_user_info()
        jobs = get_autosync_jobs(username=None if is_admin else username)
        # Strip runtime-only fields that make no sense on import
        export_fields = {"title", "series_url", "language", "provider", "enabled"}
        clean = [{k: j[k] for k in export_fields if k in j} for j in jobs]
        payload = json.dumps({"version": 1, "jobs": clean}, ensure_ascii=False, indent=2)
        from flask import Response
        return Response(
            payload,
            mimetype="application/json",
            headers={"Content-Disposition": 'attachment; filename="autosync_backup.json"'},
        )

    @app.route("/api/autosync/import", methods=["POST"])
    def api_autosync_import():
        """Import autosync jobs from a JSON backup. Skips duplicates."""
        username, is_admin = _get_current_user_info()
        if not is_admin:
            return jsonify({"error": "Nur Admins können Jobs importieren"}), 403
        try:
            data = request.get_json(silent=True)
            if data is None:
                # try raw text body
                data = json.loads(request.data.decode("utf-8"))
        except Exception:
            return jsonify({"error": "Ungültiges JSON"}), 400

        jobs_in = data.get("jobs") if isinstance(data, dict) else data
        if not isinstance(jobs_in, list):
            return jsonify({"error": "Erwartet: {jobs: [...]}"}), 400

        imported = 0
        skipped  = 0
        errors   = []
        for entry in jobs_in:
            title      = (entry.get("title") or "").strip()
            series_url = (entry.get("series_url") or "").strip()
            language   = entry.get("language", "German Dub")
            provider   = entry.get("provider", "VOE")
            enabled    = int(entry.get("enabled", 1))
            if not title or not series_url:
                errors.append(f"Übersprungen (kein title/series_url): {entry}")
                continue
            if find_autosync_by_url(series_url):
                skipped += 1
                continue
            try:
                job_id = add_autosync_job(
                    title=title,
                    series_url=series_url,
                    language=language,
                    provider=provider,
                    added_by=username,
                )
                if not enabled:
                    update_autosync_job(job_id, enabled=0)
                imported += 1
            except Exception as exc:
                errors.append(f"{title}: {exc}")
        return jsonify({"ok": True, "imported": imported, "skipped": skipped, "errors": errors})

    @app.route("/api/autosync/batch", methods=["POST"])
    def api_autosync_batch():
        """Batch-update multiple autosync jobs at once.

        Body: { ids: [int, ...], action: "enable"|"disable"|"set_path", custom_path_id: int|null }
        """
        username, is_admin = _get_current_user_info()
        data   = request.get_json(silent=True) or {}
        ids    = data.get("ids", [])
        action = data.get("action", "")
        if not ids or action not in ("enable", "disable", "set_path", "delete"):
            return jsonify({"error": "ids und action (enable|disable|set_path|delete) erforderlich"}), 400

        updated = 0
        for job_id in ids:
            job = get_autosync_job(job_id)
            if not job:
                continue
            if not is_admin and job.get("added_by") != username:
                continue
            if action == "enable":
                update_autosync_job(job_id, enabled=1)
            elif action == "disable":
                update_autosync_job(job_id, enabled=0)
            elif action == "set_path":
                cp_id = data.get("custom_path_id")  # None = Standard
                update_autosync_job(job_id, custom_path_id=cp_id)
            elif action == "delete":
                ok, _ = remove_autosync_job(job_id)
                if not ok:
                    continue
            updated += 1
        return jsonify({"ok": True, "updated": updated})

    # ===== Stats API =====

    @app.route("/api/stats/sync")
    def api_stats_sync():
        stats = get_sync_stats()
        # Compute next_run_at from last check + schedule interval
        schedule_key = os.environ.get("ANIWORLD_SYNC_SCHEDULE", "0")
        interval = SYNC_SCHEDULE_MAP.get(schedule_key, 0)
        stats["schedule"] = schedule_key
        stats["next_run_at"] = None
        if interval and stats.get("last_check"):
            from datetime import datetime, timedelta

            try:
                last = datetime.strptime(stats["last_check"], "%Y-%m-%d %H:%M:%S")
                nxt = last + timedelta(seconds=interval)
                stats["next_run_at"] = nxt.strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                pass
        return jsonify(stats)

    @app.route("/api/stats/queue")
    def api_stats_queue():
        return jsonify(get_queue_stats())

    @app.route("/api/stats/general")
    def api_stats_general():
        return jsonify(get_general_stats())

    # ---- Image proxy with disk cache ----

    _ALLOWED_IMAGE_HOSTS = {
        "aniworld.to", "www.aniworld.to",
        "s.to", "www.s.to", "serienstream.to",
        "filmpalast.to", "www.filmpalast.to",
        "image.tmdb.org", "cdn.myanimelist.net",
        "cdn.aniworld.to",
    }

    import hashlib as _hashlib
    from pathlib import Path as _Path

    _IMAGE_CACHE_DIR = ANIWORLD_CONFIG_DIR / "image_cache"
    _IMAGE_CACHE_DIR.mkdir(parents=True, exist_ok=True)

    _IMG_FETCH_RETRIES = 3
    _IMG_FETCH_TIMEOUT = 20

    def _img_upstream_headers(raw_url: str) -> dict:
        """Referer + Accept so CDNs don't drop requests that look like off-site hotlinks."""
        from urllib.parse import urlparse as _urlp_img

        try:
            netloc = _urlp_img(raw_url).netloc.lower()
        except Exception:
            return {}
        host = netloc.removeprefix("www.")
        referer_by_host = {
            "filmpalast.to": "https://filmpalast.to/",
            "s.to": "https://s.to/",
            "serienstream.to": "https://s.to/",
            "aniworld.to": "https://aniworld.to/",
            "cdn.aniworld.to": "https://aniworld.to/",
        }
        ref = referer_by_host.get(host)
        if not ref:
            return {}
        return {
            "Referer": ref,
            "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
        }

    def _img_fetch_with_retries(raw_url: str):
        """
        GET with retries over classic HTTPS (TCP).

        GLOBAL_SESSION uses niquests, which may negotiate HTTP/3 (QUIC). Cloudflare
        often resets those connections from Python (logs: quic … Connection close
        0x128).  Plain ``requests`` stays on HTTP/1.1 or HTTP/2 over TLS — same
        approach as FilmPalastEpisode._html (see episode.py).
        """
        import time as _time

        import requests as _rq

        from ..config import DEFAULT_USER_AGENT

        headers = {
            "User-Agent": DEFAULT_USER_AGENT,
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "de-DE,de;q=0.9,en;q=0.8",
        }
        headers.update(_img_upstream_headers(raw_url))

        for attempt in range(_IMG_FETCH_RETRIES):
            try:
                resp = _rq.get(raw_url, timeout=_IMG_FETCH_TIMEOUT, headers=headers)
                if resp.status_code in (502, 503, 504) and attempt + 1 < _IMG_FETCH_RETRIES:
                    _time.sleep(0.25 * (2**attempt))
                    continue
                return resp
            except Exception as e:
                last_exc = e
                if attempt + 1 < _IMG_FETCH_RETRIES:
                    _time.sleep(0.25 * (2**attempt))
                    continue
                raise last_exc from None

    def _img_cache_path(url: str, content_type: str = "image/jpeg") -> _Path:
        """Return the cache file path for a given URL."""
        url_hash = _hashlib.sha256(url.encode()).hexdigest()[:32]
        ext = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp",
               "image/gif": ".gif", "image/avif": ".avif"}.get(content_type, ".jpg")
        return _IMAGE_CACHE_DIR / (url_hash + ext)

    def _img_cache_path_any(url: str) -> "_Path | None":
        """Return existing cache file for a URL (regardless of extension), or None."""
        url_hash = _hashlib.sha256(url.encode()).hexdigest()[:32]
        for ext in (".jpg", ".jpeg", ".png", ".webp", ".gif", ".avif"):
            p = _IMAGE_CACHE_DIR / (url_hash + ext)
            if p.exists():
                return p
        return None

    def cleanup_image_cache(max_age_days: int = 30):
        """Delete cached image files not accessed in the last max_age_days days."""
        import time
        cutoff = time.time() - max_age_days * 86400
        removed = 0
        try:
            for f in _IMAGE_CACHE_DIR.iterdir():
                if f.is_file() and f.stat().st_atime < cutoff:
                    try:
                        f.unlink()
                        removed += 1
                    except OSError:
                        pass
        except Exception as e:
            logger.debug(f"Image cache cleanup error: {e}")
        if removed:
            logger.debug(f"Image cache: removed {removed} stale file(s)")

    # Run cleanup at startup in background
    threading.Thread(target=cleanup_image_cache, daemon=True).start()

    # Thread pool for background image pre-caching
    import concurrent.futures as _cf
    import urllib.parse as _up_img
    _img_pool = _cf.ThreadPoolExecutor(max_workers=2, thread_name_prefix="img-precache")

    def _precache_image_bg(url: str):
        """Fetch and save a single image to disk cache. Runs in background pool."""
        if not url or not url.startswith("http"):
            return
        if _img_cache_path_any(url):
            return  # already on disk
        try:
            resp = _img_fetch_with_retries(url)
            if not resp.ok:
                return
            ct = (resp.headers.get("Content-Type") or "image/jpeg").split(";")[0].strip()
            if not ct.startswith("image/"):
                return
            _img_cache_path(url, ct).write_bytes(resp.content)
        except Exception as exc:
            logger.debug(f"img pre-cache failed for {url}: {exc}")

    def _poster_proxy(url: str) -> str:
        """
        Convert a raw source poster URL to the server-side proxy URL AND
        kick off a background pre-cache fetch.  The client browser will
        NEVER receive a direct URL to aniworld.to / s.to / filmpalast.to /
        image.tmdb.org — it always gets /api/img?url=… served by this server.
        """
        if not url:
            return ""
        if url.startswith("/api/img"):
            return url  # already proxied — no-op
        _img_pool.submit(_precache_image_bg, url)
        return "/api/img?url=" + _up_img.quote(url, safe="")

    def _proxy_result_list(results: list) -> list:
        """Return results with proxied poster URLs and inline cached TMDB data."""
        api_key = get_setting("cineinfo_tmdb_api_key", "")
        country = get_setting("cineinfo_country", "DE")
        tmdb_on = bool(api_key)

        cache_hits = {}
        if tmdb_on and results:
            keys = []
            for r in results:
                if hasattr(r, "get"):
                    title = r.get("title", "")
                    if title:
                        keys.append(title + "|||" + country)
            if keys:
                cache_hits = get_tmdb_cache_bulk(keys)

        out = []
        for r in results:
            r = dict(r)
            if r.get("poster_url"):
                r["poster_url"] = _poster_proxy(r["poster_url"])
            if tmdb_on:
                title = r.get("title", "")
                if title:
                    cached = cache_hits.get(title + "|||" + country)
                    if cached is not None:
                        r["tmdb"] = cached
            out.append(r)
        return out

    @app.route("/api/img")
    def api_image_proxy():
        """
        Server-side image proxy with disk cache.

        Fetches poster/cover images on behalf of the client so mobile devices
        don't need a direct connection to source sites (avoids ISP DNS blocks,
        hotlink protection, and mixed-content issues).  Images are cached to
        disk for 30 days; the cache is served directly without re-fetching.

        Only whitelisted source domains are allowed.
        """
        from urllib.parse import urlparse
        from flask import Response, send_file

        raw_url = request.args.get("url", "").strip()
        if not raw_url:
            return ("", 400)

        try:
            parsed = urlparse(raw_url)
        except Exception:
            return ("Bad URL", 400)

        netloc = parsed.netloc.lower()
        host_stripped = netloc.removeprefix("www.")
        if netloc not in _ALLOWED_IMAGE_HOSTS and host_stripped not in _ALLOWED_IMAGE_HOSTS:
            return ("Forbidden host", 403)

        # --- Serve from disk cache if available ---
        cached = _img_cache_path_any(raw_url)
        if cached and cached.exists():
            # Touch the file to reset the LRU timer
            try:
                cached.touch()
            except OSError:
                pass
            ext = cached.suffix.lower()
            mime = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
                    ".webp": "image/webp", ".gif": "image/gif", ".avif": "image/avif"}.get(ext, "image/jpeg")
            r = send_file(cached, mimetype=mime)
            r.headers["Cache-Control"] = "public, max-age=604800"  # 7 days browser cache
            return r

        # --- Fetch from source ---
        try:
            resp = _img_fetch_with_retries(raw_url)
            resp.raise_for_status()
            content_type = (resp.headers.get("Content-Type") or "image/jpeg").split(";")[0].strip()
            if not content_type.startswith("image/"):
                return ("Not an image", 400)
            data = resp.content
        except Exception as e:
            logger.debug(f"Image proxy fetch failed for {raw_url}: {e}")
            return ("", 502)

        # --- Save to disk cache ---
        cache_file = _img_cache_path(raw_url, content_type)
        try:
            cache_file.write_bytes(data)
        except OSError as e:
            logger.debug(f"Image cache write failed: {e}")

        r = Response(data, content_type=content_type)
        r.headers["Cache-Control"] = "public, max-age=604800"
        return r

    # ---- Library: shared scan helpers (module-level closure) ----

    _LIB_LANG_FOLDERS = ["german-dub", "english-sub", "german-sub", "english-dub"]
    _LIB_VIDEO_EXTS = {".mkv", ".mp4", ".ts"}
    _LIB_EP_RE = re.compile(r"S(\d{2})E(\d{2,3})", re.IGNORECASE)
    _lib_scan_lock = __import__("threading").Lock()

    def _lib_resolve_base():
        from pathlib import Path
        raw = os.environ.get("ANIWORLD_DOWNLOAD_PATH", "")
        if raw:
            dl_base = Path(raw).expanduser()
            if not dl_base.is_absolute():
                dl_base = Path.home() / dl_base
        else:
            dl_base = Path.home() / "Downloads"
        return dl_base

    def _lib_scan_base(base):
        from pathlib import Path
        lang_folder_set = set(_LIB_LANG_FOLDERS)
        titles = {}
        if not base.is_dir():
            return []

        # Zero-th pass: video files sitting DIRECTLY in base (no title subfolder).
        # e.g. CUSTOM_PATH/Interstellar.mkv → title = "Interstellar"
        for f in base.iterdir():
            if not f.is_file():
                continue
            fname = f.name
            if fname.startswith(".temp_") or fname.startswith("."):
                continue
            if ".part" in fname or fname.endswith(".part"):
                continue
            fname_lower = fname.lower()
            if not any(fname_lower.endswith(ext) for ext in _LIB_VIDEO_EXTS):
                continue
            if _LIB_EP_RE.search(fname):
                continue  # episode file loose in root — skip, not a movie
            # Use filename without extension as the title key
            title_name = f.stem
            try:
                fsize = f.stat().st_size
            except OSError:
                fsize = 0
            if title_name not in titles:
                titles[title_name] = {"folder": title_name, "seasons": {}, "total_size": 0, "is_movie": False}
            entry = titles[title_name]
            if "movies" not in entry["seasons"]:
                entry["seasons"]["movies"] = []
            if not any(e["file"] == fname for e in entry["seasons"]["movies"]):
                entry["seasons"]["movies"].append({"episode": 1, "file": fname, "size": fsize, "is_video": True, "is_movie_file": True, "path": str(f)})
                entry["total_size"] += fsize
                entry["is_movie"] = True

        for folder in base.iterdir():
            if not folder.is_dir():
                continue
            name = folder.name
            if name in lang_folder_set:
                continue
            if name not in titles:
                titles[name] = {"folder": name, "seasons": {}, "total_size": 0, "is_movie": False}
            entry = titles[name]

            # First pass: direct video files in the title folder (no season subfolder)
            # These are movies — they never have an SxxExx pattern.
            for f in folder.iterdir():
                if not f.is_file():
                    continue
                fname = f.name
                if fname.startswith(".temp_") or fname.startswith("."):
                    continue
                if ".part" in fname or fname.endswith(".part"):
                    continue
                fname_lower = fname.lower()
                if not any(fname_lower.endswith(ext) for ext in _LIB_VIDEO_EXTS):
                    continue
                if _LIB_EP_RE.search(fname):
                    continue  # has SxxExx → handled as episode below
                # Video file without SxxExx directly in title folder → movie
                try:
                    fsize = f.stat().st_size
                except OSError:
                    fsize = 0
                skey = "movies"
                if skey not in entry["seasons"]:
                    entry["seasons"][skey] = []
                if not any(e["file"] == fname for e in entry["seasons"][skey]):
                    entry["seasons"][skey].append({"episode": 1, "file": fname, "size": fsize, "is_video": True, "is_movie_file": True, "path": str(f)})
                    entry["total_size"] += fsize
                    entry["is_movie"] = True

            # Second pass: recurse into subfolders for SxxExx episodes
            for f in folder.rglob("*"):
                fname = f.name
                if not f.is_file() or fname.startswith(".temp_") or fname.startswith("."):
                    continue
                if ".part" in fname or fname.endswith(".part"):
                    continue
                fname_lower = fname.lower()
                if not any(fname_lower.endswith(ext) for ext in _LIB_VIDEO_EXTS):
                    continue
                m = _LIB_EP_RE.search(fname)
                if not m:
                    continue
                snum = int(m.group(1))
                enum = int(m.group(2))
                try:
                    fsize = f.stat().st_size
                except OSError:
                    fsize = 0
                skey = str(snum)
                if skey not in entry["seasons"]:
                    entry["seasons"][skey] = []
                if not any(e["episode"] == enum and e["file"] == fname for e in entry["seasons"][skey]):
                    entry["seasons"][skey].append({"episode": enum, "file": fname, "size": fsize, "is_video": True, "path": str(f)})
                    entry["total_size"] += fsize

        result = []
        for entry in sorted(titles.values(), key=lambda x: x["folder"].lower()):
            if not any(entry["seasons"].values()):
                continue
            total_eps = sum(sum(1 for e in eps if e.get("is_video", True)) for eps in entry["seasons"].values())
            for skey in entry["seasons"]:
                if skey != "movies":
                    entry["seasons"][skey].sort(key=lambda e: e["episode"])
            result.append({"folder": entry["folder"], "seasons": entry["seasons"],
                           "total_episodes": total_eps, "total_size": entry["total_size"],
                           "is_movie": entry["is_movie"]})
        return result

    def _lib_build_scan_targets():
        from pathlib import Path
        dl_base = _lib_resolve_base()
        targets = [("Default", None, dl_base)]
        for cp in get_custom_paths():
            cp_base = Path(cp["path"]).expanduser()
            if not cp_base.is_absolute():
                cp_base = Path.home() / cp_base
            targets.append((cp["name"], cp["id"], cp_base))
        return targets

    def _lib_do_scan(targets, lang_sep):
        """Perform a full scan and store results in the cache. Runs in background thread."""
        from pathlib import Path
        for (label, cp_id, base_path) in targets:
            path_key = "default" if cp_id is None else str(cp_id)
            set_library_scanning(path_key, True)
            try:
                if lang_sep:
                    loc_lang_folders = []
                    for lf in _LIB_LANG_FOLDERS:
                        lf_titles = _lib_scan_base(base_path / lf)
                        if lf_titles:
                            loc_lang_folders.append({"name": lf, "titles": lf_titles})
                    set_library_cache(path_key, {
                        "label": label, "custom_path_id": cp_id,
                        "lang_folders": loc_lang_folders, "titles": None,
                    })
                else:
                    loc_titles = _lib_scan_base(base_path)
                    set_library_cache(path_key, {
                        "label": label, "custom_path_id": cp_id,
                        "lang_folders": None, "titles": loc_titles,
                    })
            except Exception:
                set_library_scanning(path_key, False)
            else:
                # is_scanning is already set to 0 by set_library_cache
                pass

    def _lib_trigger_scan_async(targets, lang_sep):
        import threading
        t = threading.Thread(target=_lib_do_scan, args=(targets, lang_sep), daemon=True)
        t.start()

    @app.route("/api/library")
    def api_library():
        lang_sep = os.environ.get("ANIWORLD_LANG_SEPARATION", "0") == "1"
        targets = _lib_build_scan_targets()
        cache = get_all_library_cache()

        locations = []
        any_scanning = False
        needs_initial_scan = []

        for (label, cp_id, base_path) in targets:
            path_key = "default" if cp_id is None else str(cp_id)
            entry = cache.get(path_key)
            if entry:
                if entry["is_scanning"]:
                    any_scanning = True
                if entry["data"]:
                    locations.append(entry["data"])
            else:
                # Never scanned yet — trigger once
                needs_initial_scan.append((label, cp_id, base_path))

        if needs_initial_scan and not any_scanning:
            _lib_trigger_scan_async(needs_initial_scan, lang_sep)
            any_scanning = True

        # Watcher status
        watcher = _get_lib_watcher()
        last_updated = max((e["scanned_at"] for e in cache.values()), default=0)

        return jsonify({
            "lang_sep": lang_sep,
            "locations": locations,
            "is_scanning": any_scanning,
            "last_updated": last_updated,
            "watcher": {
                "available": watcher.available,
                "active": watcher.active,
                "watched": watcher.watched,
            },
        })

    @app.route("/api/library/refresh", methods=["POST"])
    def api_library_refresh():
        lang_sep = os.environ.get("ANIWORLD_LANG_SEPARATION", "0") == "1"
        targets = _lib_build_scan_targets()
        invalidate_library_cache()
        _lib_trigger_scan_async(targets, lang_sep)
        # Restart watcher so it picks up any newly configured paths
        _lib_watcher.restart(targets, _lib_watcher_scan_callback)
        return jsonify({"ok": True, "scanning": True})

    @app.route("/api/library/status")
    def api_library_status():
        """Lightweight endpoint: returns only scanning state + last_updated timestamp.
        Used by the UI to detect watcher-triggered rescans without transferring location data."""
        cache = get_all_library_cache()
        any_scanning = any(e["is_scanning"] for e in cache.values())
        last_updated = max((e["scanned_at"] for e in cache.values()), default=0)
        return jsonify({"is_scanning": any_scanning, "last_updated": last_updated})

    @app.route("/api/library/watcher")
    def api_library_watcher():
        watcher = _get_lib_watcher()
        return jsonify({
            "available": watcher.available,
            "active": watcher.active,
            "watched": watcher.watched,
        })

    @app.route("/api/library/delete", methods=["POST"])
    def api_library_delete():
        import shutil
        from pathlib import Path

        data = request.get_json(silent=True) or {}
        folder = data.get("folder", "")
        season = data.get("season")  # int or null
        episode = data.get("episode")  # int or null
        custom_path_id = data.get("custom_path_id")  # int or null

        # Security: reject dangerous folder names
        if (
            not folder
            or ".." in folder
            or "/" in folder
            or "\\" in folder
            or "\x00" in folder
        ):
            return jsonify({"error": "Invalid folder name"}), 400

        # Resolve base path from custom_path_id or default
        if custom_path_id:
            cp = get_custom_path_by_id(custom_path_id)
            if not cp:
                return jsonify({"error": "Custom path not found"}), 404
            dl_base = Path(cp["path"]).expanduser()
            if not dl_base.is_absolute():
                dl_base = Path.home() / dl_base
        else:
            raw = os.environ.get("ANIWORLD_DOWNLOAD_PATH", "")
            if raw:
                dl_base = Path(raw).expanduser()
                if not dl_base.is_absolute():
                    dl_base = Path.home() / dl_base
            else:
                dl_base = Path.home() / "Downloads"

        lang_sep = os.environ.get("ANIWORLD_LANG_SEPARATION", "0") == "1"
        lang_folders = ["german-dub", "english-sub", "german-sub", "english-dub"]
        lang_folder = data.get("lang_folder")  # str or null

        if lang_sep and lang_folder:
            if lang_folder not in lang_folders:
                return jsonify({"error": "Invalid language folder"}), 400
            bases = [dl_base / lang_folder]
        elif lang_sep:
            bases = [dl_base / lf for lf in lang_folders]
        else:
            bases = [dl_base]

        deleted = 0
        for base in bases:
            title_path = base / folder
            # Verify resolved path is a child of the base
            try:
                title_path.resolve().relative_to(base.resolve())
            except ValueError:
                continue
            if not title_path.is_dir():
                continue

            if season is None and episode is None:
                # Delete entire title
                shutil.rmtree(title_path, ignore_errors=True)
                deleted += 1
            else:
                # Build regex pattern
                if episode is not None:
                    pat = re.compile(
                        rf"S{int(season):02d}E{int(episode):03d}(?!\d)", re.IGNORECASE
                    )
                else:
                    pat = re.compile(rf"S{int(season):02d}E\d{{2,3}}", re.IGNORECASE)

                for f in list(title_path.rglob("*")):
                    if f.is_file() and pat.search(f.name):
                        try:
                            f.unlink()
                            deleted += 1
                        except OSError:
                            pass

                # Cleanup empty directories bottom-up
                for dirpath in sorted(
                    title_path.rglob("*"), key=lambda p: len(p.parts), reverse=True
                ):
                    if dirpath.is_dir():
                        try:
                            dirpath.rmdir()  # only succeeds if empty
                        except OSError:
                            pass
                # Remove title folder itself if empty
                try:
                    title_path.rmdir()
                except OSError:
                    pass

        if deleted == 0:
            return jsonify({"error": "Nothing found to delete"}), 404
        invalidate_library_cache()
        return jsonify({"ok": True, "deleted": deleted})

    @app.route("/api/library/rename", methods=["POST"])
    def api_library_rename():
        from pathlib import Path
        data = request.get_json(silent=True) or {}
        folder    = data.get("folder", "")
        new_name  = data.get("new_name", "").strip()
        season    = data.get("season")      # int → rename season folder; None → rename title folder
        episode   = data.get("episode")     # int → rename specific episode file; None → season/title level
        old_file  = data.get("old_file")    # original filename for episode rename
        custom_path_id = data.get("custom_path_id")
        lang_folder    = data.get("lang_folder")

        # Validate inputs
        def _safe(name):
            return name and ".." not in name and "/" not in name and "\\" not in name and "\x00" not in name

        if not _safe(folder) or not new_name:
            return jsonify({"error": "Invalid folder or new name"}), 400
        if not _safe(new_name):
            return jsonify({"error": "New name contains invalid characters"}), 400

        # Resolve base path
        if custom_path_id:
            cp = get_custom_path_by_id(custom_path_id)
            if not cp:
                return jsonify({"error": "Custom path not found"}), 404
            dl_base = Path(cp["path"]).expanduser()
            if not dl_base.is_absolute():
                dl_base = Path.home() / dl_base
        else:
            raw = os.environ.get("ANIWORLD_DOWNLOAD_PATH", "")
            dl_base = Path(raw).expanduser() if raw else Path.home() / "Downloads"
            if not dl_base.is_absolute():
                dl_base = Path.home() / dl_base

        lang_sep = os.environ.get("ANIWORLD_LANG_SEPARATION", "0") == "1"
        if lang_sep and lang_folder:
            if lang_folder not in _LIB_LANG_FOLDERS:
                return jsonify({"error": "Invalid language folder"}), 400
            base = dl_base / lang_folder
        else:
            base = dl_base

        title_path = (base / folder).resolve()
        try:
            title_path.relative_to(base.resolve())
        except ValueError:
            return jsonify({"error": "Path traversal detected"}), 400

        if episode is not None and old_file:
            # Rename a specific episode file
            if season is None:
                return jsonify({"error": "season required for episode rename"}), 400
            season_path = title_path / ("Staffel " + str(int(season)))
            if not season_path.is_dir():
                # Try without Staffel prefix — flat layout
                season_path = title_path
            src = (season_path / old_file).resolve()
            try:
                src.relative_to(base.resolve())
            except ValueError:
                return jsonify({"error": "Path traversal detected"}), 400
            if not src.is_file():
                return jsonify({"error": "File not found"}), 404
            dst = src.parent / new_name
            if dst.exists():
                return jsonify({"error": "Target name already exists"}), 409
            src.rename(dst)
        else:
            # Rename title folder
            if not title_path.is_dir():
                return jsonify({"error": "Folder not found"}), 404
            dst = title_path.parent / new_name
            if dst.exists():
                return jsonify({"error": "Target name already exists"}), 409
            title_path.rename(dst)

        invalidate_library_cache()
        return jsonify({"ok": True})

    def _lib_move_resolve_base(cp_id):
        """Resolve a custom_path_id (or None for default) to an absolute Path."""
        from pathlib import Path
        if cp_id:
            cp = get_custom_path_by_id(cp_id)
            if not cp:
                return None
            p = Path(cp["path"]).expanduser()
        else:
            raw = get_setting("download_path") or os.environ.get("ANIWORLD_DOWNLOAD_PATH", "")
            p = Path(raw).expanduser() if raw else Path.home() / "Downloads"
        return p if p.is_absolute() else Path.home() / p

    def _lib_move_worker(job_id, src, dst):
        """Background thread: copy src→dst with progress tracking, then delete src."""
        import shutil
        from pathlib import Path
        job = _move_jobs[job_id]
        try:
            # Calculate total bytes
            all_files = [f for f in Path(src).rglob("*") if f.is_file()]
            total = sum(f.stat().st_size for f in all_files)
            with _move_jobs_lock:
                job["total_bytes"] = total
                job["status"] = "running"

            copied = 0
            dst_path = Path(dst)
            src_path = Path(src)
            dst_path.mkdir(parents=True, exist_ok=True)

            for src_file in all_files:
                rel = src_file.relative_to(src_path)
                dst_file = dst_path / rel
                dst_file.parent.mkdir(parents=True, exist_ok=True)
                with _move_jobs_lock:
                    job["current_file"] = str(rel)
                # buffered copy for progress
                with open(src_file, "rb") as fin, open(dst_file, "wb") as fout:
                    while True:
                        buf = fin.read(256 * 1024)  # 256 KB chunks
                        if not buf:
                            break
                        fout.write(buf)
                        copied += len(buf)
                        with _move_jobs_lock:
                            job["copied_bytes"] = copied
                try:
                    shutil.copystat(str(src_file), str(dst_file))
                except Exception:
                    pass

            # Also copy empty directories
            for src_dir in sorted(Path(src).rglob("*")):
                if src_dir.is_dir():
                    rel = src_dir.relative_to(src_path)
                    (dst_path / rel).mkdir(parents=True, exist_ok=True)

            # Delete source
            shutil.rmtree(str(src))
            invalidate_library_cache()
            with _move_jobs_lock:
                job["status"] = "done"
                job["current_file"] = ""
        except Exception as exc:
            logger.error("[LibMove] Move job %s failed: %s", job_id, exc, exc_info=True)
            # Clean up partial destination
            try:
                import shutil as _sh
                _sh.rmtree(str(dst), ignore_errors=True)
            except Exception:
                pass
            with _move_jobs_lock:
                job["status"] = "error"
                job["error"] = str(exc)


    def _lib_move_loose_files_worker(job_id, file_paths, dst_dir):
        """Background thread: move individual loose files (movies in root) to dst_dir."""
        import shutil
        from pathlib import Path
        job = _move_jobs[job_id]
        try:
            files = [Path(p) for p in file_paths]
            total = sum(f.stat().st_size for f in files if f.exists())
            with _move_jobs_lock:
                job["total_bytes"] = total
                job["status"] = "running"

            dst_path = Path(dst_dir)
            dst_path.mkdir(parents=True, exist_ok=True)
            copied = 0
            for src_file in files:
                if not src_file.exists():
                    continue
                dst_file = dst_path / src_file.name
                with _move_jobs_lock:
                    job["current_file"] = src_file.name
                with open(src_file, "rb") as fin, open(dst_file, "wb") as fout:
                    while True:
                        buf = fin.read(256 * 1024)
                        if not buf:
                            break
                        fout.write(buf)
                        copied += len(buf)
                        with _move_jobs_lock:
                            job["copied_bytes"] = copied
                try:
                    shutil.copystat(str(src_file), str(dst_file))
                except Exception:
                    pass
                src_file.unlink()

            invalidate_library_cache()
            with _move_jobs_lock:
                job["status"] = "done"
                job["current_file"] = ""
        except Exception as exc:
            logger.error("[LibMove] Loose file move job %s failed: %s", job_id, exc, exc_info=True)
            with _move_jobs_lock:
                job["status"] = "error"
                job["error"] = str(exc)

    @app.route("/api/library/move", methods=["POST"])
    def api_library_move():
        """Start an async move job. Returns {job_id} immediately."""
        import uuid
        from pathlib import Path
        data = request.get_json(silent=True) or {}
        folder      = data.get("folder", "")
        from_cp_id  = data.get("from_custom_path_id")
        to_cp_id    = data.get("to_custom_path_id")
        lang_folder = data.get("lang_folder")

        def _safe(name):
            return name and ".." not in name and "/" not in name and "\\" not in name and "\x00" not in name

        if not _safe(folder):
            return jsonify({"error": "Invalid folder name"}), 400

        from_base = _lib_move_resolve_base(from_cp_id)
        to_base   = _lib_move_resolve_base(to_cp_id)
        if from_base is None or to_base is None:
            return jsonify({"error": "Invalid path configuration"}), 400

        lang_sep = os.environ.get("ANIWORLD_LANG_SEPARATION", "0") == "1"
        if lang_sep and lang_folder:
            if lang_folder not in _LIB_LANG_FOLDERS:
                return jsonify({"error": "Invalid language folder"}), 400
            from_base = from_base / lang_folder
            to_base   = to_base   / lang_folder

        src = (from_base / folder).resolve()
        try:
            src.relative_to(from_base.resolve())
        except ValueError:
            return jsonify({"error": "Path traversal detected"}), 400

        # Check if source is a directory (series) or loose files directly in base (movie)
        loose_files = []
        if not src.is_dir():
            # Movie files sitting directly in the base folder (e.g. Film.mkv, Film.srt)
            loose_files = [f for f in from_base.iterdir()
                           if f.is_file() and f.stem == folder]
            if not loose_files:
                return jsonify({"error": "Source folder not found"}), 404

        if loose_files:
            # Loose files → move each file to to_base (no subfolder)
            dst = to_base
            for lf in loose_files:
                if (dst / lf.name).exists():
                    return jsonify({"error": "Ziel existiert bereits am Speicherort"}), 409
        else:
            dst = to_base / folder
            if dst.resolve() == src.resolve():
                return jsonify({"error": "Quelle und Ziel sind identisch"}), 400
            if dst.exists():
                return jsonify({"error": "Ziel existiert bereits am Speicherort"}), 409

        try:
            to_base.mkdir(parents=True, exist_ok=True)
        except Exception as exc:
            return jsonify({"error": f"Zielordner konnte nicht erstellt werden: {exc}"}), 500

        job_id = uuid.uuid4().hex[:12]
        with _move_jobs_lock:
            _move_jobs[job_id] = {
                "status": "starting",
                "copied_bytes": 0,
                "total_bytes": 0,
                "current_file": "",
                "error": None,
                "folder": folder,
            }

        if loose_files:
            t = threading.Thread(
                target=_lib_move_loose_files_worker,
                args=(job_id, [str(f) for f in loose_files], str(dst)),
                daemon=True,
            )
        else:
            t = threading.Thread(target=_lib_move_worker, args=(job_id, str(src), str(dst)), daemon=True)
        t.start()
        return jsonify({"job_id": job_id})

    @app.route("/api/library/move_status/<job_id>")
    def api_library_move_status(job_id):
        """Poll move job progress."""
        with _move_jobs_lock:
            job = _move_jobs.get(job_id)
            if job is None:
                return jsonify({"error": "Job nicht gefunden"}), 404
            result = dict(job)
            # Clean up finished jobs after first poll of final state
            if job["status"] in ("done", "error"):
                _move_jobs.pop(job_id, None)
        return jsonify(result)

    # ===== External REST API v1 =====
    #
    # All endpoints live under /api/v1/ and require authentication via:
    #   - HTTP header:  X-Api-Key: <key>
    #   - Query param:  ?apikey=<key>
    #
    # The key is auto-generated on first run and stored in app_settings.
    # It can be viewed / regenerated from the Settings page.

    from flask import Response as _FlaskResponse

    def _v1_json(data, status=200):
        """Pretty-printed JSON response for all /api/v1/ endpoints."""
        body = json.dumps(data, indent=2, ensure_ascii=False, default=str) + "\n"
        return _FlaskResponse(body, status=status, mimetype="application/json")

    def _check_api_key():
        """Return a 401 JSON response if the API key is invalid, else None."""
        stored = get_setting("external_api_key", "")
        if not stored:
            return jsonify({"error": "API key not configured"}), 500
        provided = (
            request.headers.get("X-Api-Key", "")
            or request.args.get("apikey", "")
        )
        if not provided or not secrets.compare_digest(provided, stored):
            return _v1_json({
                "error": "Unauthorized",
                "message": (
                    "Provide your API key via the X-Api-Key header "
                    "or the ?apikey= query parameter."
                ),
            }, status=401)
        return None

    @app.route("/api/v1/status")
    def api_v1_status():
        """Overall downloader status — safe to poll frequently."""
        auth_err = _check_api_key()
        if auth_err:
            return auth_err
        from ..models.common.common import get_ffmpeg_progress
        stats  = get_queue_stats()
        ffmpeg = get_ffmpeg_progress()
        r      = stats["currently_running"]

        if r:
            cur = r.get("current_episode") or 0
            tot = r.get("total_episodes") or 0
            # current_episode = i (0-based loop index) → i episodes fully done,
            # episode i+1 is in progress.  Mirror queue.js logic exactly:
            #   epPct  = cur / tot * 100
            #   inEpPct = 100 if ffmpeg phase (download done), else dl percent
            #   overall = epPct + inEpPct / tot
            ep_pct   = round(ffmpeg.get("percent") or 0) if ffmpeg.get("active") else 0
            in_ep    = 100 if (ffmpeg.get("active") and ffmpeg.get("phase") == "ffmpeg") else ep_pct
            overall_pct = round(((cur + in_ep / 100) / tot * 100) if tot > 0 else 0)
            r["episode_progress"] = {
                "percent":       ep_pct,
                "phase":         ffmpeg.get("phase", ""),
                "speed":         ffmpeg.get("speed", ""),
                "bandwidth":     ffmpeg.get("bandwidth", ""),
                "downloaded_mb": round(ffmpeg.get("downloaded_mb", 0.0), 1),
                "active":        ffmpeg.get("active", False),
            }
            r["overall_progress_percent"] = overall_pct

        return _v1_json({
            "version": app_version,
            "paused": is_queue_paused(),
            "queue": {
                "total":     stats["total"],
                "queued":    stats["by_status"].get("queued", 0),
                "running":   stats["by_status"].get("running", 0),
                "completed": stats["by_status"].get("completed", 0),
                "failed":    stats["by_status"].get("failed", 0),
                "cancelled": stats["by_status"].get("cancelled", 0),
            },
            "currently_running": r,
        })

    @app.route("/api/v1/queue")
    def api_v1_queue():
        """All queue items, optionally filtered by ?status=<status>."""
        auth_err = _check_api_key()
        if auth_err:
            return auth_err
        items = get_queue()
        status_filter = request.args.get("status", "").strip().lower()
        if status_filter:
            items = [i for i in items if i.get("status") == status_filter]
        for item in items:
            if isinstance(item.get("episodes"), str):
                try:
                    item["episodes"] = json.loads(item["episodes"])
                except Exception:
                    pass
        return _v1_json(items)

    @app.route("/api/v1/queue/<int:queue_id>")
    def api_v1_queue_item(queue_id):
        """Single queue item detail."""
        auth_err = _check_api_key()
        if auth_err:
            return auth_err
        item = get_queue_item(queue_id)
        if not item:
            return _v1_json({"error": "Not found"}, status=404)
        if isinstance(item.get("episodes"), str):
            try:
                item["episodes"] = json.loads(item["episodes"])
            except Exception:
                pass
        return _v1_json(item)

    def _v1_library_data(only_movies: bool | None = None):
        """Return library cache as a clean list of location objects."""
        cache = get_all_library_cache()
        locations = []
        for path_key, entry in cache.items():
            loc_data = entry.get("data") or {}
            label        = loc_data.get("label", path_key)
            cp_id        = loc_data.get("custom_path_id")
            is_scanning  = entry.get("is_scanning", False)
            scanned_at   = entry.get("scanned_at")

            all_titles = []
            lang_folders = loc_data.get("lang_folders") or []
            if lang_folders:
                for lf in lang_folders:
                    for t in (lf.get("titles") or []):
                        all_titles.append({**t, "_lang_folder": lf.get("name")})
            else:
                for t in (loc_data.get("titles") or []):
                    all_titles.append(t)

            if only_movies is True:
                all_titles = [t for t in all_titles if t.get("is_movie")]
            elif only_movies is False:
                all_titles = [t for t in all_titles if not t.get("is_movie")]

            clean_titles = []
            for t in all_titles:
                seasons_clean = {}
                for skey, eps in (t.get("seasons") or {}).items():
                    seasons_clean[skey] = [
                        {
                            "episode":       e.get("episode"),
                            "file":          e.get("file"),
                            "size":          e.get("size", 0),
                            "is_movie_file": e.get("is_movie_file", False),
                        }
                        for e in eps
                    ]
                clean_titles.append({
                    "folder":         t.get("folder"),
                    "is_movie":       t.get("is_movie", False),
                    "total_episodes": t.get("total_episodes", 0),
                    "total_size":     t.get("total_size", 0),
                    "lang_folder":    t.get("_lang_folder"),
                    "seasons":        seasons_clean,
                })

            locations.append({
                "location":       label,
                "custom_path_id": cp_id,
                "is_scanning":    is_scanning,
                "scanned_at":     scanned_at,
                "title_count":    len(clean_titles),
                "titles":         clean_titles,
            })
        return _v1_json(locations)

    @app.route("/api/v1/library")
    def api_v1_library():
        """Full library — all titles (series + movies)."""
        auth_err = _check_api_key()
        if auth_err:
            return auth_err
        return _v1_library_data(only_movies=None)

    @app.route("/api/v1/library/series")
    def api_v1_library_series():
        """Library — series only (no movies)."""
        auth_err = _check_api_key()
        if auth_err:
            return auth_err
        return _v1_library_data(only_movies=False)

    @app.route("/api/v1/library/movies")
    def api_v1_library_movies():
        """Library — movies only."""
        auth_err = _check_api_key()
        if auth_err:
            return auth_err
        return _v1_library_data(only_movies=True)

    @app.route("/api/v1/stats")
    def api_v1_stats():
        """Download statistics."""
        auth_err = _check_api_key()
        if auth_err:
            return auth_err
        return _v1_json(get_general_stats())

    @app.route("/api/settings/api-key", methods=["GET"])
    def api_settings_api_key_get():
        """Return the current external API key (masked)."""
        key = get_setting("external_api_key", "")
        if key:
            masked = key[:6] + "•" * (len(key) - 6)
        else:
            masked = ""
        return jsonify({"key": key, "masked": masked})

    @app.route("/api/settings/api-key/regenerate", methods=["POST"])
    def api_settings_api_key_regenerate():
        """Generate a new external API key."""
        new_key = secrets.token_hex(32)
        set_setting("external_api_key", new_key)
        return jsonify({"ok": True, "key": new_key})

    # ===== Captcha API =====

    @app.route("/api/captcha/<int:queue_id>/screenshot")
    def api_captcha_screenshot(queue_id):
        """Stream the latest captcha screenshot for a running queue item."""
        from ..playwright import captcha as _captcha_mod
        with _captcha_mod._active_sessions_lock:
            session = _captcha_mod._active_sessions.get(queue_id)
        if session is None:
            return "", 204
        data = session.get_screenshot()
        if not data:
            return "", 204
        from flask import Response
        return Response(data, mimetype="image/jpeg")

    @app.route("/api/captcha/<int:queue_id>/click", methods=["POST"])
    def api_captcha_click(queue_id):
        """Forward a click coordinate to the captcha browser."""
        from ..playwright import captcha as _captcha_mod
        with _captcha_mod._active_sessions_lock:
            session = _captcha_mod._active_sessions.get(queue_id)
        if session is None:
            return jsonify({"error": "No active captcha session"}), 404
        data = request.get_json(silent=True) or {}
        x = int(data.get("x", 0))
        y = int(data.get("y", 0))
        session.enqueue_click(x, y)
        return jsonify({"ok": True})

    @app.route("/api/captcha/<int:queue_id>/status")
    def api_captcha_status(queue_id):
        """Return whether a captcha session is active for the given queue item."""
        from ..playwright import captcha as _captcha_mod
        with _captcha_mod._active_sessions_lock:
            active = queue_id in _captcha_mod._active_sessions
        return jsonify({"active": active})

    if auth_enabled:
        from .auth import admin_required

        # Endpoints that require admin instead of just login
        _admin_only = {
            "settings_page",
            "api_settings",
            "api_settings_update",
            "api_settings_sso_get",
            "api_settings_sso_put",
            "api_settings_env_file_get",
            "api_settings_env_file_delete",
            "api_library_delete",
            "api_library_rename",
            "api_library_move",
            "api_library_refresh",
            "api_custom_paths_add",
            "api_custom_paths_delete",
            "api_autosync_create",
            "api_autosync_update",
            "api_autosync_delete",
            "api_autosync_trigger",
        }

        # Wrap all non-auth, non-static view functions with login_required
        # (admin_required for settings endpoints)
        _exempt = {
            "static",
            "auth.login",
            "auth.logout",
            "auth.setup",
            "auth.oidc_login",
            "auth.oidc_callback",
            # External REST API — authenticated via API key, not session
            "api_v1_status",
            "api_v1_queue",
            "api_v1_queue_item",
            "api_v1_library",
            "api_v1_library_series",
            "api_v1_library_movies",
            "api_v1_stats",
            # API key management is accessible to logged-in users (not exempt from
            # session auth, just listed here to avoid accidental double-wrap)
        }
        for endpoint, view_func in list(app.view_functions.items()):
            if endpoint not in _exempt:
                if endpoint in _admin_only:
                    app.view_functions[endpoint] = admin_required(view_func)
                else:
                    app.view_functions[endpoint] = login_required(view_func)

        # Exempt JSON API routes from CSRF (they use Content-Type: application/json
        # which provides implicit cross-origin protection via CORS preflight)
        for endpoint in list(app.view_functions):
            if endpoint.startswith("api_") or endpoint.startswith("auth.admin_"):
                csrf.exempt(app.view_functions[endpoint])

    # -----------------------------------------------------------------------
    # Background prefetch worker — warms browse lists, poster images and
    # TMDB data so the home page loads instantly instead of fetching lazily.
    # First run ~20 s after startup, then every 15 minutes.
    # -----------------------------------------------------------------------
    _PREFETCH_INTERVAL = 15 * 60   # seconds between cycles
    _PREFETCH_STARTUP  = 3         # initial delay to let server fully start
    _PREFETCH_RATE     = 0.4       # seconds between per-entry TMDB calls

    def _prefetch_cycle():
        """One full pass: warm browse lists → pre-cache posters → fetch TMDB data."""
        api_key = get_setting("cineinfo_tmdb_api_key", "")
        country = get_setting("cineinfo_country", "DE")
        tmdb_on = bool(api_key)

        # Collect all cards from every browse category (uses in-process cache)
        browse_sources = [
            ("new_animes",     fetch_new_animes),
            ("popular_animes", fetch_popular_animes),
            ("new_series",     fetch_new_series),
            ("popular_series", fetch_popular_series),
            ("new_movies",     _fetch_new_movies),
        ]
        all_entries = []
        for bkey, fn in browse_sources:
            try:
                results = _cached_browse(bkey, fn)
                if results:
                    all_entries.extend(results)
            except Exception as exc:
                logger.debug("[Prefetch] Browse %r failed: %s", bkey, exc)

        # Deduplicate by URL
        seen, unique = set(), []
        for e in all_entries:
            url = e.get("url", "")
            if url and url not in seen:
                seen.add(url)
                unique.append(e)

        logger.info("[Prefetch] Warming cache for %d cards (TMDB: %s)", len(unique), tmdb_on)

        for entry in unique:
            url        = entry.get("url", "")
            title      = entry.get("title", "")
            poster_url = entry.get("poster_url", "")

            # Fire-and-forget poster pre-cache
            if poster_url:
                _img_pool.submit(_precache_image_bg, poster_url)

            if not (tmdb_on and title):
                continue

            # Skip if TMDB data already cached (title key) and up to date
            cached = get_tmdb_cache(title + "|||" + country)
            if cached is not None:
                if not cached.get("found", True) or ("trailer_key" in cached and "recommendations" in cached):
                    continue

            # Try to get IMDB ID from the series page for accurate matching
            imdb_id = None
            if not _is_filmpalast_url(url):
                try:
                    prov   = resolve_provider(url)
                    series = prov.series_cls(url=url)
                    imdb_id = getattr(series, "imdb", None) or None
                    # Also check the imdb_id-keyed cache entry
                    if imdb_id and get_tmdb_cache(imdb_id + "|||" + country) is not None:
                        time.sleep(_PREFETCH_RATE)
                        continue
                except Exception:
                    pass  # fall through to title-only lookup

            _tmdb_lookup_cached(title, imdb_id, api_key, country)
            time.sleep(_PREFETCH_RATE)

        logger.info("[Prefetch] Cycle complete.")

    def _prefetch_worker():
        time.sleep(_PREFETCH_STARTUP)
        while True:
            try:
                _prefetch_cycle()
            except Exception as exc:
                logger.warning("[Prefetch] Worker cycle error: %s", exc)
            time.sleep(_PREFETCH_INTERVAL)

    _pt = threading.Thread(target=_prefetch_worker, daemon=True, name="browse-prefetch")
    _pt.start()
    logger.info("[Prefetch] Background worker started (interval=%d min)", _PREFETCH_INTERVAL // 60)

    # Update checker — runs once at startup (after 10 s) then every 24 h
    def _update_check_worker():
        import time as _time
        _time.sleep(10)
        while True:
            try:
                _do_update_check()
                logger.info(
                    "[UpdateCheck] Latest: %s | update_available: %s",
                    _update_cache["latest_version"],
                    _update_cache["update_available"],
                )
            except Exception:
                logger.exception("[UpdateCheck] Unexpected error")
            _time.sleep(_UPDATE_CHECK_INTERVAL)

    _uct = threading.Thread(target=_update_check_worker, daemon=True, name="update-checker")
    _uct.start()

    @app.context_processor
    def override_url_for():
        def dated_url_for(endpoint, **values):
            if endpoint == 'static':
                filename = values.get('filename', None)
                if filename:
                    file_path = os.path.join(app.static_folder, filename)
                    if os.path.exists(file_path):
                        values['v'] = int(os.stat(file_path).st_mtime)
            return url_for(endpoint, **values)
        return dict(url_for=dated_url_for)

    return app


def start_web_ui(
    host="127.0.0.1",
    port=8080,
    open_browser=True,
    auth_enabled=False,
    sso_enabled=False,
    force_sso=False,
):
    """Start the Flask web UI server."""
    import os
    import threading
    import webbrowser

    # Allow env var overrides (Docker-friendly)
    force_sso = force_sso or os.getenv("ANIWORLD_WEB_FORCE_SSO", "0") == "1"
    sso_enabled = sso_enabled or force_sso or os.getenv("ANIWORLD_WEB_SSO", "0") == "1"
    auth_enabled = (
        auth_enabled or force_sso or os.getenv("ANIWORLD_WEB_AUTH", "0") == "1"
    )

    app = create_app(
        auth_enabled=auth_enabled, sso_enabled=sso_enabled, force_sso=force_sso
    )
    display_host = "localhost" if host in ("127.0.0.1", "0.0.0.0") else host
    url = f"http://{display_host}:{port}"
    print(f"Starting AniWorld Web UI on {url}")

    debug = os.getenv("ANIWORLD_DEBUG_MODE", "0") == "1"

    # In debug mode, Flask's reloader spawns a child process that re-executes
    # this function. Only open the browser in the parent (reloader) process
    # to avoid opening it twice.
    is_reloader_child = os.environ.get("WERKZEUG_RUN_MAIN") == "true"
    if open_browser and not is_reloader_child:
        threading.Timer(0.5, webbrowser.open, args=(url,)).start()

    if debug:
        app.run(host=host, port=port, debug=True)
    else:
        import logging
        # Waitress logs a WARNING every time the task queue depth exceeds its
        # threshold — useful for debugging but noisy in normal operation.
        logging.getLogger("waitress.queue").setLevel(logging.ERROR)

        from waitress import serve

        serve(app, host=host, port=port)
