console.log(">>> App JS Version: 1.6 - Unified App & Advanced Search <<<");
const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");
const searchSpinner = document.getElementById("searchSpinner");
const resultsDiv = document.getElementById("results");
const overlay = document.getElementById("overlay");
const languageSelect = document.getElementById("languageSelect");
const providerSelect = document.getElementById("providerSelect");
const seasonAccordion = document.getElementById("seasonAccordion");
const episodeSpinner = document.getElementById("episodeSpinner");
const selectAllCb = document.getElementById("selectAll");
const autoSyncCheck = document.getElementById("autoSyncCheck");
const statusBar = document.getElementById("statusBar");
const statusText = document.getElementById("statusText");
const downloadAllBtn = document.getElementById("downloadAllBtn");
const downloadSelectedBtn = document.getElementById("downloadSelectedBtn");
const browseDiv = document.getElementById("browse");
const newAnimesGrid = document.getElementById("newAnimesGrid");
const popularAnimesGrid = document.getElementById("popularAnimesGrid");
const newAnimesSection = document.getElementById("newAnimesSection");
const popularAnimesSection = document.getElementById("popularAnimesSection");
const newSeriesGrid = document.getElementById("newSeriesGrid");
const popularSeriesGrid = document.getElementById("popularSeriesGrid");
const newSeriesSection = document.getElementById("newSeriesSection");
const popularSeriesSection = document.getElementById("popularSeriesSection");
const newMoviesGrid = document.getElementById("newMoviesGrid");
const newMoviesSection = document.getElementById("newMoviesSection");

let currentSeasons = [];
let currentSeriesTitle = "";
let currentSeriesUrl = "";
// Provider data per language label
let availableProviders = null;
let langSeparationEnabled = false;
// Static list of providers rendered into the template
const staticProviders = providerSelect ? Array.from(providerSelect.options).map((o) => o.value) : [];


// Site toggle state
let currentSite = "aniworld"; // kept for modal language detection via URL

// Downloaded folders cache
let downloadedFolders = [];

// MediaScan: TMDB/IMDB ID sets populated when source = mediascan
let mediascanTmdbIds = new Set();
let mediascanImdbIds = new Set();
let mediascanTitles = new Set(); // normalised titles from Plex/Jellyfin as fallback
let mediascanActive = false;  // true when source is plex/jellyfin (not folders)

// Auto-Sync URLs set (series_url -> job object)
let autoSyncUrlMap = {};

// CineInfo display settings (cached)
let cineinfoSettings = null;
let generalSettings = null;

let _generalSettingsPromise = null;
function loadGeneralSettings() {
  if (!_generalSettingsPromise) {
    _generalSettingsPromise = (async () => {
      try {
        const resp = await fetch("/api/settings");
        const data = await resp.json();
        generalSettings = data;
        cineinfoSettings = data.cineinfo || {};
        console.log("[General] Settings loaded (combined):", generalSettings);
        _reEnrichPendingCards();
        return generalSettings;
      } catch (e) {
        console.error("[General] Failed to load settings:", e);
        generalSettings = {};
        cineinfoSettings = {};
        return {};
      }
    })();
  }
  return _generalSettingsPromise;
}

function loadCineinfoSettings() {
  return loadGeneralSettings().then(() => cineinfoSettings);
}

function _reEnrichPendingCards() {
  if (!cineinfoSettings || !cineinfoSettings.tmdb_api_key) return;
  if (cineinfoSettings.show_providers === '0' &&
      cineinfoSettings.show_fsk === '0' &&
      cineinfoSettings.show_hover_rating !== '1' &&
      cineinfoSettings.show_hover_genres !== '1' &&
      cineinfoSettings.show_hover_fsk !== '1') return;
  document.querySelectorAll('[data-tmdb-title]').forEach(card => {
    const info = card.querySelector('.browse-info');
    if (info && info.querySelector('.browse-tmdb-meta')) return;
    const title = card.dataset.tmdbTitle;
    if (title) _queueTmdbEnrich(card, title); // use batched path
  });
}

// ---------------------------------------------------------------------------
// Batched TMDB enrichment — collects visible-card titles for 80 ms then
// fires ONE /api/tmdb/batch POST instead of N individual /api/tmdb/info GETs.
// This keeps the TMDB rate-limiter happy and stops the UI flooding the server.
// ---------------------------------------------------------------------------

const _tmdbPending = new Map(); // title → [card, ...]
let _tmdbBatchTimer = null;

async function _flushTmdbBatch() {
  _tmdbBatchTimer = null;
  if (!_tmdbPending.size) return;
  if (!cineinfoSettings || !cineinfoSettings.tmdb_api_key) return;
  const batch = [..._tmdbPending.entries()];
  _tmdbPending.clear();
  const titles = batch.map(([t]) => t);
  try {
    const resp = await fetch("/api/tmdb/batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titles }),
    });
    if (!resp.ok) return;
    const results = await resp.json();
    batch.forEach(([title, cards]) => {
      const tmdb = results[title];
      if (tmdb) cards.forEach(card => _applyTmdbToCard(card, tmdb));
    });
  } catch (e) { /* best-effort */ }
}

function _queueTmdbEnrich(card, title) {
  if (!_tmdbPending.has(title)) _tmdbPending.set(title, []);
  _tmdbPending.get(title).push(card);
  clearTimeout(_tmdbBatchTimer);
  _tmdbBatchTimer = setTimeout(_flushTmdbBatch, 80);
}

// IntersectionObserver with tighter margin — only cards near the viewport
// trigger, avoiding eager loading of the entire page at once.
const _tmdbObserver = ('IntersectionObserver' in window)
  ? new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const card = entry.target;
      const title = card.dataset.tmdbTitle;
      if (title) {
        _tmdbObserver.unobserve(card);
        delete card.dataset.tmdbTitle;
        _queueTmdbEnrich(card, title);
      }
    });
  }, { rootMargin: '50px' })
  : null;

function enrichCardWithTmdb(card, title) {
  if (!cineinfoSettings || !cineinfoSettings.tmdb_api_key) return;
  if (_tmdbObserver) {
    card.dataset.tmdbTitle = title;
    _tmdbObserver.observe(card);
  } else {
    _queueTmdbEnrich(card, title);
  }
}

async function loadAutoSyncJobs() {
  try {
    const resp = await fetch("/api/autosync");
    const data = await resp.json();
    autoSyncUrlMap = {};
    (data.jobs || []).forEach(j => {
      const norm = (j.series_url || "").replace(/\/+$/, "").toLowerCase();
      autoSyncUrlMap[norm] = j;
    });
  } catch (e) { /* best-effort */ }
}


// Custom paths select
const customPathSelect = document.getElementById("customPathSelect");

async function loadCustomPaths() {
  if (!customPathSelect) return;
  try {
    const resp = await fetch("/api/custom-paths");
    const data = await resp.json();
    const paths = data.paths || [];
    // Remove old custom options (keep "Default")
    while (customPathSelect.options.length > 1) customPathSelect.remove(1);
    if (paths.length) {
      paths.forEach(function (p) {
        const opt = document.createElement("option");
        opt.value = p.id;
        opt.textContent = p.name;
        customPathSelect.appendChild(opt);
      });
      customPathSelect.style.display = "";
    } else {
      customPathSelect.style.display = "none";
    }
  } catch (e) {
    /* best-effort */
  }
}

async function loadDownloadedFolders() {
  try {
    const resp = await fetch("/api/downloaded-folders");
    const data = await resp.json();

    if (data.source === "mediascan") {
      // MediaScan mode: ignore folder list, use TMDB/IMDB IDs instead
      downloadedFolders = [];
      mediascanActive = false; // will be set true after library fetch below
    } else {
      downloadedFolders = data.folders || [];
      mediascanActive = false;
    }
  } catch (e) {
    /* best-effort */
  }
  // Always try to load mediascan library (returns empty if disabled)
  try {
    const ms = await fetch("/api/mediascan/library");
    const md = await ms.json();
    if (md.enabled) {
      mediascanTmdbIds = new Set((md.tmdb_ids || []).map(id => String(id)));
      mediascanImdbIds = new Set((md.imdb_ids || []).map(id => String(id)));
      mediascanTitles = new Set((md.titles || []));
      mediascanActive = true;
      // Re-evaluate any already-rendered badges that have a tmdb data attribute
      _refreshMediascanBadges();
    } else {
      mediascanTmdbIds = new Set();
      mediascanImdbIds = new Set();
      mediascanTitles = new Set();
      mediascanActive = false;
    }
  } catch (e) {
    /* best-effort */
  }
}

function _refreshMediascanBadges() {
  // Re-check all visible cards that already have a tmdb_id data attribute
  // (set by _applyTmdbToCard after async TMDB load)
  document.querySelectorAll(".browse-card[data-tmdb-id], .card[data-tmdb-id]").forEach(card => {
    const existing = card.querySelector(".downloaded-badge");
    if (existing) existing.remove();
    const tmdbId = card.dataset.tmdbId || "";
    const title = card.dataset.title || "";
    if (_isDownloadedByTmdb(tmdbId) || _isDownloadedByTitle(title)) {
      _attachDownloadedBadge(card);
    } else if (!mediascanActive && title) {
      if (isDownloaded(title)) _attachDownloadedBadge(card);
    }
  });
}

function renderSkeletons(grid, count = 10) {
  if (!document.body.classList.contains("skeleton-loader")) return;
  grid.innerHTML = "";
  for (let i = 0; i < count; i++) {
    const card = document.createElement("div");
    card.className = "browse-card skeleton";
    card.innerHTML = `
      <div style="width:100%; aspect-ratio:2/3; background:rgba(255,255,255,0.03)"></div>
      <div class="browse-info">
        <div style="height:14px; width:80%; background:rgba(255,255,255,0.03); border-radius:4px; margin-bottom:6px"></div>
        <div style="height:12px; width:60%; background:rgba(255,255,255,0.03); border-radius:4px"></div>
      </div>
    `;
    grid.appendChild(card);
  }
}

let stoLoadedAt = 0;
async function loadStoBrowse() {
  if (stoLoadedAt && Date.now() - stoLoadedAt < 3600000) return;
  stoLoadedAt = Date.now();
  renderSkeletons(newSeriesGrid);
  renderSkeletons(popularSeriesGrid);
  try {
    const [newResp, popResp] = await Promise.all([
      fetch("/api/new-series"),
      fetch("/api/popular-series"),
    ]);
    await Promise.all([loadDownloadedFolders(), loadAutoSyncJobs(), loadCineinfoSettings(), loadGeneralSettings()]);
    const newData = await newResp.json();
    const popData = await popResp.json();

    if (newData.results) renderBrowseCards(newSeriesGrid, newData.results);
    else newSeriesGrid.innerHTML = '<div class="queue-empty" style="padding: 20px;">Fehler beim Laden</div>';

    if (popData.results) renderBrowseCards(popularSeriesGrid, popData.results);
    else popularSeriesGrid.innerHTML = '<div class="queue-empty" style="padding: 20px;">Fehler beim Laden</div>';
  } catch (e) {
    stoLoadedAt = 0;
    newSeriesGrid.innerHTML = '<div class="queue-empty" style="padding: 20px;">Fehler beim Laden</div>';
    popularSeriesGrid.innerHTML = '<div class="queue-empty" style="padding: 20px;">Fehler beim Laden</div>';
  }
}

let fpLoadedAt = 0;
async function loadFilmPalastBrowse() {
  if (fpLoadedAt && Date.now() - fpLoadedAt < 3600000) return;
  fpLoadedAt = Date.now();
  renderSkeletons(newMoviesGrid);
  try {
    const resp = await fetch("/api/new-movies");
    await Promise.all([loadDownloadedFolders(), loadAutoSyncJobs(), loadCineinfoSettings(), loadGeneralSettings()]);
    const data = await resp.json();

    if (data.results) renderBrowseCards(newMoviesGrid, data.results);
    else newMoviesGrid.innerHTML = '<div class="queue-empty" style="padding: 20px;">Fehler beim Laden</div>';
  } catch (e) {
    fpLoadedAt = 0;
    newMoviesGrid.innerHTML = '<div class="queue-empty" style="padding: 20px;">Fehler beim Laden</div>';
  }
}

function showBrowseSections() {
  browseDiv.style.display = "";
  loadAniworldBrowse();
  loadStoBrowse();
  loadFilmPalastBrowse();
}

function normalizeQuotes(s) {
  return s
    .replace(/[\u2018\u2019\u2032\u0060]/g, "'")
    .replace(/[\u201C\u201D\u201E]/g, '"');
}

function isDownloaded(title) {
  // Folder-based check (used when mediascan is inactive)
  if (!downloadedFolders.length || !title) return false;
  const clean = normalizeQuotes(
    unesc(title)
      .replace(/\s*\(.*$/, "")
      .trim()
      .toLowerCase(),
  );
  return downloadedFolders.some((f) =>
    normalizeQuotes(f.toLowerCase()).startsWith(clean),
  );
}

function _normalizeForMediascan(title) {
  if (!title) return "";
  return title
    .toLowerCase()
    .replace(/\s*\(\d{4}\)\s*$/, "")       // strip (2013)
    .replace(/\s*:?\s*season\s+\d+\s*$/i, "")
    .replace(/\s*:?\s*staffel\s+\d+\s*$/i, "")
    .replace(/\s*:?\s*part\s+\d+\s*$/i, "")
    .replace(/[^\w\s]/g, "")                  // strip punctuation
    .replace(/\s+/g, " ")
    .trim();
}

function _isDownloadedByTmdb(tmdbId) {
  if (!mediascanActive || !tmdbId) return false;
  return mediascanTmdbIds.has(String(tmdbId));
}

function _isDownloadedByTitle(title) {
  if (!mediascanActive || !title || !mediascanTitles.size) return false;
  const norm = _normalizeForMediascan(title);
  // O(1) Set lookup — prefix loop removed: normalization already strips
  // Season/Part suffixes on both sides, so exact match is sufficient.
  return norm ? mediascanTitles.has(norm) : false;
}

function _attachDownloadedBadge(card) {
  const badge = document.createElement("div");
  badge.className = "downloaded-badge";
  badge.textContent = "✓ Vorhanden";
  badge.style.cssText = [
    "position:absolute", "top:7px", "right:7px",
    "background:var(--success)", "color:#fff",
    "font-size:0.65rem", "font-weight:700",
    "padding:2px 7px", "border-radius:99px",
    "line-height:1.5", "z-index:2", "pointer-events:none"
  ].join(";");
  card.style.position = "relative";
  card.appendChild(badge);
}

function addDownloadedBadge(card, title) {
  if (mediascanActive) {
    // Store title so _applyTmdbToCard can re-check via TMDB ID later.
    card.dataset.title = title || "";
    // Title-based check fires immediately — no TMDB load needed.
    if (_isDownloadedByTitle(title)) {
      _attachDownloadedBadge(card);
    }
    return;
  }
  if (isDownloaded(title)) _attachDownloadedBadge(card);
}

function addSyncBadge(card, url) {
  if (!url) return;
  const normUrl = url.replace(/\/+$/, "").toLowerCase();
  if (!autoSyncUrlMap[normUrl]) return;
  // downloaded-badge: top 7px + ~20px height + 4px gap = 31px → use 34px
  const hasVorhanden = !!card.querySelector(".downloaded-badge");
  const topPx = hasVorhanden ? 34 : 7;
  const badge = document.createElement("div");
  badge.className = "sync-badge";
  badge.textContent = "⟳ Sync";
  badge.style.cssText = [
    "position:absolute", "top:" + topPx + "px", "right:7px",
    "background:var(--info)", "color:#fff",
    "font-size:0.6rem", "font-weight:700",
    "padding:2px 7px", "border-radius:99px",
    "line-height:1.6", "letter-spacing:.03em",
    "z-index:2", "pointer-events:none",
    "box-shadow:0 1px 6px rgba(59,130,246,.4)"
  ].join(";");
  card.style.position = "relative";
  card.appendChild(badge);
}

function refreshSyncBadges() {
  document.querySelectorAll(".browse-card, .card").forEach(card => {
    const img = card.querySelector("img[data-url]");
    if (!img) return;
    const url = img.getAttribute("data-url");
    const existing = card.querySelector(".sync-badge");
    if (existing) existing.remove();
    addSyncBadge(card, url);
  });
}

// Apply already-fetched TMDB data to a browse card synchronously (no network)
function _applyTmdbToCard(card, d) {
  if (!d || !d.found) return;
  const info = card.querySelector(".browse-info");
  if (!info) return;

  // Store TMDB ID on the card element so MediaScan badge matching can use it
  if (d.tmdb_id) {
    card.dataset.tmdbId = String(d.tmdb_id);
    // MediaScan mode: evaluate badge now that we have the TMDB ID
    if (mediascanActive) {
      const existing = card.querySelector(".downloaded-badge");
      if (!existing) {
        const cardTitle = card.dataset.title || "";
        if (_isDownloadedByTmdb(d.tmdb_id) || _isDownloadedByTitle(cardTitle)) {
          _attachDownloadedBadge(card);
        }
      }
    }
  }

  // Update genres if available
  if (d.genres && d.genres.length) {
    const genreEl = info.querySelector(".browse-genre");
    if (genreEl) {
      genreEl.textContent = d.genres.join(", ");
    }
  }

  if (!cineinfoSettings || !cineinfoSettings.tmdb_api_key) return;
  if (cineinfoSettings.show_providers === '0' &&
      cineinfoSettings.show_fsk === '0' &&
      cineinfoSettings.show_hover_rating !== '1' &&
      cineinfoSettings.show_hover_genres !== '1' &&
      cineinfoSettings.show_hover_fsk !== '1') return;

  let meta = info.querySelector(".browse-tmdb-meta");
  if (!meta) {
    meta = document.createElement("div");
    meta.className = "browse-tmdb-meta";
    info.appendChild(meta);
  }
  meta.innerHTML = '';
  if (cineinfoSettings.show_providers !== '0' && d.providers && d.providers.length) {
    const pill = _makeProviderPill(d.providers[0]);
    pill.style.fontSize = '0.7rem';
    pill.style.padding = '2px 8px 2px 6px';
    pill.style.maxWidth = '100%';
    pill.style.overflow = 'hidden';
    pill.title = d.providers.join(', ');
    const lbl = pill.querySelector('span:last-child');
    if (lbl) {
      lbl.style.overflow = 'hidden'; lbl.style.textOverflow = 'ellipsis';
      lbl.style.whiteSpace = 'nowrap'; lbl.style.minWidth = '0';
    }
    meta.appendChild(pill);
  }

  // Populate Browse Info Card
  let tmdb_voting = d.vote_average;
  let tmdb_genres = d.genres;
  let tmdb_fsk = d.fsk;
  renderBrowseHoverCards(card, tmdb_voting, tmdb_genres, tmdb_fsk);
}

// Single-card TMDB fetch — kept for the series modal and other one-off lookups.
// Browse cards use the batched _queueTmdbEnrich() path instead.
async function _doEnrichCard(card, title) {
  if (!cineinfoSettings || !cineinfoSettings.tmdb_api_key) return;
  if (cineinfoSettings.show_providers === '0' &&
      cineinfoSettings.show_fsk === '0' &&
      cineinfoSettings.show_hover_rating !== '1' &&
      cineinfoSettings.show_hover_genres !== '1' &&
      cineinfoSettings.show_hover_fsk !== '1') return;
  try {
    const resp = await fetch("/api/tmdb/info?title=" + encodeURIComponent(title).replace(/'/g, "%27"));
    _applyTmdbToCard(card, await resp.json());
  } catch (e) { /* best-effort */ }
}

function toggleSite() { /* no-op: both sites always shown */ }

function rebuildLanguageSelect() {
  const url = currentSeriesUrl || "";
  const isFilmPalast = url.includes("filmpalast.to");
  languageSelect.innerHTML = "";

  if (isFilmPalast) {
    // FilmPalast movies are always German-dubbed
    const opt = document.createElement("option");
    opt.value = "German Dub";
    opt.textContent = "German Dub";
    languageSelect.appendChild(opt);
    return;
  }

  const isSto = url.includes("s.to");
  const langs = isSto ? window.STO_LANGS || {} : window.ANIWORLD_LANGS || {};

  if (langSeparationEnabled) {
    const opt = document.createElement("option");
    opt.value = "All Languages";
    opt.textContent = "Alle Sprachen";
    languageSelect.appendChild(opt);
  }

  for (const [key, label] of Object.entries(langs)) {
    const opt = document.createElement("option");
    opt.value = label;
    opt.textContent = label;
    languageSelect.appendChild(opt);
  }
}


if (searchInput) {
  searchInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") doSearch();
  });
  searchInput.addEventListener("input", () => {
    if (!searchInput.value.trim()) {
      if (resultsDiv) resultsDiv.innerHTML = "";
      showBrowseSections();
    }
  });
}
if (languageSelect) {
  languageSelect.addEventListener("change", updateProviderDropdown);
}

function renderBrowseCards(grid, items) {
  grid.innerHTML = "";
  items.forEach((item) => {
    const card = document.createElement("div");
    card.className = "browse-card";
    card.dataset.url = item.url;
    card.onclick = () => openSeries(item.url);
    card.innerHTML =
      `<img src="${esc(proxyImg(item.poster_url))}" alt="" onload="this.parentElement.classList.add('loaded')" onerror="this.parentElement.classList.add('loaded'); this.style.display='none'">` +
      `<div class="browse-info">` +
      `<div class="browse-title">${esc(item.title)}</div>` +
      `<div class="browse-genre">${esc(item.genre)}</div>` +
      `</div>`;
    addDownloadedBadge(card, item.title);
    addSyncBadge(card, item.url);
    grid.appendChild(card);
    // If TMDB data came pre-loaded from the server cache → apply instantly (no fetch)
    if (item.tmdb) {
      if (item.tmdb.found) {
        // Defer one tick so cineinfoSettings is guaranteed loaded when aniworld tab is first
        setTimeout(() => _applyTmdbToCard(card, item.tmdb), 0);
      }
    } else {
      // Fall back to lazy loading via IntersectionObserver
      enrichCardWithTmdb(card, item.title);
    }
  });
}

function renderBrowseHoverCards(card, tmdb_voting, tmdb_genres, tmdb_fsk) {
  if (card.querySelector(".browse-hover-overlay")) return;

  const showRating = cineinfoSettings && cineinfoSettings.show_hover_rating === "1";
  const showGenres = cineinfoSettings && cineinfoSettings.show_hover_genres === "1";
  const showFSK = cineinfoSettings && cineinfoSettings.show_hover_fsk === "1";

  if (!showRating && !showGenres && !showFSK) return;

  let votingHtml = "";
  if (showRating && tmdb_voting) {
    const formattedVote = parseFloat(tmdb_voting).toFixed(1);
    votingHtml = `<span style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.72rem; font-weight: 700; padding: 2px 8px 2px 6px; border-radius: 99px; border: 1px solid rgba(74, 222, 128, 0.4); background: rgba(0, 0, 0, 0.6); color: rgb(74, 222, 128); white-space: nowrap; cursor: default; letter-spacing: 0.01em; flex-shrink: 0; vertical-align: middle;"><svg width="10" height="10" viewBox="0 0 24 24" fill="#4ade80" style="flex-shrink:0"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path></svg>${formattedVote}</span>`;
  }

  let genresHtml = "";
  if (showGenres && tmdb_genres && tmdb_genres.length > 0) {
    const genreSpans = tmdb_genres.map(g => `<span>${esc(g)}</span>`).join("");
    genresHtml = `<div class="genres hover-genres">${genreSpans}</div>`;
  }

  let fskHtml = "";
  if (showFSK && tmdb_fsk) {
    const _fskPalette = {
      0: { bg: 'rgba(255,255,255,.07)', bc: 'rgba(255,255,255,.3)', c: '#d1d5db' },
      6: { bg: 'rgba(234,179,8,.12)', bc: 'rgba(234,179,8,.55)', c: '#fbbf24' },
      12: { bg: 'rgba(34,197,94,.12)', bc: 'rgba(34,197,94,.5)', c: '#4ade80' },
      16: { bg: 'rgba(59,130,246,.12)', bc: 'rgba(59,130,246,.5)', c: '#60a5fa' },
      18: { bg: 'rgba(239,68,68,.12)', bc: 'rgba(239,68,68,.5)', c: '#f87171' },
    };
    const fp = _fskPalette[tmdb_fsk] || { bg: 'rgba(148,163,184,.1)', bc: 'rgba(148,163,184,.35)', c: '#94a3b8' };
    fskHtml = `<span style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.72rem; font-weight: 700; padding: 2px 8px 2px 6px; border-radius: 99px; border: 1px solid ${fp.bc}; background: ${fp.bg}; color: ${fp.c}; white-space: nowrap; cursor: default; letter-spacing: 0.01em; flex-shrink: 0; vertical-align: middle;">FSK ${tmdb_fsk}</span>`;
  }

  if (!votingHtml && !genresHtml && !fskHtml) return;

  const overlay = document.createElement("div");
  overlay.className = "browse-hover-overlay";
  overlay.innerHTML = `
    <div class="browse-hover-content">
      ${fskHtml}
      ${votingHtml}
      ${genresHtml}
    </div>
  `;
  card.appendChild(overlay);
}

let aniLoadedAt = 0;
async function loadAniworldBrowse() {
  if (aniLoadedAt && Date.now() - aniLoadedAt < 3600000) return;
  aniLoadedAt = Date.now();
  renderSkeletons(newAnimesGrid);
  renderSkeletons(popularAnimesGrid);
  try {
    const [newResp, popResp] = await Promise.all([
      fetch("/api/new-animes"),
      fetch("/api/popular-animes"),
    ]);
    await Promise.all([loadDownloadedFolders(), loadAutoSyncJobs(), loadCineinfoSettings(), loadGeneralSettings()]);
    const newData = await newResp.json();
    const popData = await popResp.json();

    if (newData.results) renderBrowseCards(newAnimesGrid, newData.results);
    else newAnimesGrid.innerHTML = '<div class="queue-empty" style="padding: 20px;">Fehler beim Laden</div>';

    if (popData.results) renderBrowseCards(popularAnimesGrid, popData.results);
    else popularAnimesGrid.innerHTML = '<div class="queue-empty" style="padding: 20px;">Fehler beim Laden</div>';
  } catch (e) {
    aniLoadedAt = 0;
    newAnimesGrid.innerHTML = '<div class="queue-empty" style="padding: 20px;">Fehler beim Laden</div>';
    popularAnimesGrid.innerHTML = '<div class="queue-empty" style="padding: 20px;">Fehler beim Laden</div>';
  }
}
if (browseDiv) {
  showBrowseSections();
}

function initBrowseScrollButtons() {
  document.querySelectorAll(".browse-section").forEach(function (section) {
    const grid = section.querySelector(".browse-grid");
    const heading = section.querySelector(".browse-heading");
    if (!grid || !heading) return;

    const row = document.createElement("div");
    row.className = "browse-heading-row";
    heading.parentNode.insertBefore(row, heading);
    row.appendChild(heading);

    const btns = document.createElement("div");
    btns.className = "browse-scroll-btns";
    btns.innerHTML =
      '<button class="browse-scroll-btn" onclick="scrollBrowseGrid(this,-1)" aria-label="Zurück">' +
      '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>' +
      '</button>' +
      '<button class="browse-scroll-btn" onclick="scrollBrowseGrid(this,1)" aria-label="Weiter">' +
      '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>' +
      '</button>';
    row.appendChild(btns);
  });
}

function scrollBrowseGrid(btn, dir) {
  const grid = btn.closest(".browse-section").querySelector(".browse-grid");
  if (grid) grid.scrollBy({ left: dir * 460, behavior: "smooth" });
}

initBrowseScrollButtons();

async function doSearch() {
  const keyword = searchInput.value.trim().replace(/!+$/, "");
  if (!keyword) return;
  searchBtn.disabled = true;
  searchSpinner.style.display = "block";
  // Create a search grid with skeletons
  resultsDiv.innerHTML = "";
  const block = document.createElement("div");
  block.className = "browse-provider-block";
  const grid = document.createElement("div");
  grid.className = "results-poster-grid";
  block.appendChild(grid);
  resultsDiv.appendChild(block);
  renderSkeletons(grid, 12);

  browseDiv.style.display = "none";

  const searchSite = async (site) => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);
    try {
      const resp = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ keyword, site }),
        signal: controller.signal
      });
      const data = await resp.json();
      return data.results || [];
    } catch (e) {
      return [];
    } finally {
      clearTimeout(timeoutId);
    }
  };

  try {
    const [aniResults, stoResults, fpResults] = await Promise.all([
      searchSite("aniworld").catch(() => []),
      searchSite("sto").catch(() => []),
      searchSite("filmpalast").catch(() => []),
    ]);
    renderResultsBoth(aniResults, stoResults, fpResults);
  } catch (e) {
    showToast("Suche fehlgeschlagen: " + e.message);
  } finally {
    searchBtn.disabled = false;
    searchSpinner.style.display = "none";
  }
}


function renderResults(results) {
  resultsDiv.innerHTML = "";
  if (!results.length) {
    resultsDiv.innerHTML =
      '<div style="width:100%;text-align:center;color:#888;padding:40px">Keine Ergebnisse gefunden.</div>';
    return;
  }
  results.forEach((r) => {
    const card = document.createElement("div");
    card.className = "card";
    card.onclick = () => openSeries(r.url);
    card.innerHTML = `<img src="" alt="" data-url="${esc(r.url)}"><div class="info"><div class="title">${esc(r.title)}</div></div>`;
    addDownloadedBadge(card, r.title);
    addSyncBadge(card, r.url);
    resultsDiv.appendChild(card);
    loadPoster(r.url, card.querySelector("img"));
  });
}

function renderResultsBoth(aniResults, stoResults, fpResults) {
  fpResults = fpResults || [];
  resultsDiv.innerHTML = "";
  if (!aniResults.length && !stoResults.length && !fpResults.length) {
    resultsDiv.innerHTML =
      '<div style="width:100%;text-align:center;color:#888;padding:40px">Keine Ergebnisse gefunden.</div>';
    return;
  }

  const sections = [
    { label: "AniWorld", cls: "browse-provider-aniworld", results: aniResults },
    { label: "S.TO", cls: "browse-provider-sto", results: stoResults },
    { label: "FilmPalast", cls: "browse-provider-filmpalast", results: fpResults },
  ];

  sections.forEach(function (sec) {
    if (!sec.results.length) return;

    const block = document.createElement("div");
    block.className = "browse-provider-block";

    const header = document.createElement("div");
    header.className = "browse-provider-header " + sec.cls;
    header.textContent = sec.label;
    block.appendChild(header);

    const grid = document.createElement("div");
    grid.className = "results-poster-grid";

    sec.results.forEach(function (r) {
      const card = document.createElement("div");
      card.className = "browse-card";
      card.dataset.url = r.url;
      card.onclick = () => openSeries(r.url);
      card.innerHTML =
        '<img src="" alt="" style="width:100%;aspect-ratio:2/3;object-fit:cover;background:var(--bg-elevated);display:block">' +
        '<div class="browse-info"><div class="browse-title">' + esc(r.title) + '</div><div class="browse-genre"></div></div>';
      addDownloadedBadge(card, r.title);
      addSyncBadge(card, r.url);
      grid.appendChild(card);
      loadPoster(r.url, card.querySelector("img"));
      enrichCardWithTmdb(card, r.title);
    });

    block.appendChild(grid);
    resultsDiv.appendChild(block);
  });
}

/**
 * Marks cards in the overview/search results as "running" if they are currently being downloaded.
 * @param {string[]} runningUrls - List of series URLs currently active in the queue.
 */
window.updateRunningCards = function (runningUrls) {
  const cards = document.querySelectorAll(".browse-card, .result-card, .card");
  cards.forEach(card => {
    const url = card.dataset.url;
    if (url && runningUrls.includes(url)) {
      card.classList.add("running");
    } else {
      card.classList.remove("running");
    }
  });
};

async function loadPoster(url, imgEl) {
  try {
    const resp = await fetch("/api/series?url=" + encodeURIComponent(url));
    const data = await resp.json();
    if (data.poster_url) {
      imgEl.src = proxyImg(data.poster_url);
      imgEl.onload = () => {
        const card = imgEl.closest('.browse-card, .card');
        if (card) card.classList.add('loaded');
      };
      imgEl.onerror = () => {
        const card = imgEl.closest('.browse-card, .card');
        if (card) card.classList.add('loaded');
        imgEl.style.display = 'none';
      };
    } else {
      const card = imgEl.closest('.browse-card, .card');
      if (card) card.classList.add('loaded');
      imgEl.style.display = 'none';
    }
  } catch (e) {
    const card = imgEl.closest('.browse-card, .card');
    if (card) card.classList.add('loaded');
    imgEl.style.display = 'none';
  }
}

async function openSeries(url) {
  if (!generalSettings || Object.keys(generalSettings || {}).length === 0) {
    await loadGeneralSettings();
  }
  if (!cineinfoSettings || Object.keys(cineinfoSettings || {}).length === 0) {
    await loadCineinfoSettings();
  }
  _currentSeriesUrl = url;
  overlay.style.display = "block";
  document.body.style.overflow = "hidden";
  const modal = document.getElementById("modal");
  const isSkeleton = document.body.classList.contains("skeleton-loader");

  document.getElementById("modalPoster").src = "";

  if (isSkeleton) {
    modal.classList.add("skeleton");
    document.getElementById("modalPoster").style.opacity = "0";
    document.getElementById("modalTitle").innerHTML = '<div style="height:28px; width:60%; background:rgba(255,255,255,0.03); border-radius:6px; margin-bottom:8px"></div>';
    document.getElementById("modalGenres").innerHTML = '<div style="height:14px; width:40%; background:rgba(255,255,255,0.03); border-radius:4px"></div>';
    document.getElementById("modalYear").textContent = "";
    document.getElementById("modalDesc").innerHTML = '<div style="height:14px; width:100%; background:rgba(255,255,255,0.03); border-radius:4px; margin-bottom:6px"></div><div style="height:14px; width:80%; background:rgba(255,255,255,0.03); border-radius:4px"></div>';
  } else {
    modal.classList.remove("skeleton");
    document.getElementById("modalPoster").style.opacity = "";
    document.getElementById("modalTitle").textContent = "Lädt...";
    document.getElementById("modalGenres").textContent = "";
    document.getElementById("modalYear").textContent = "";
    document.getElementById("modalDesc").textContent = "";
  }
  const _tp = document.getElementById("tmdbProviders");
  if (_tp) { _tp.innerHTML = ""; _tp.style.display = "none"; }
  const _tfsk = document.getElementById("tmdbFsk");
  if (_tfsk) { _tfsk.textContent = ""; _tfsk.style.display = "none"; }
  const _mtS = document.getElementById("trailerSection");
  if (_mtS) {
    _mtS.style.display = "none";
    _mtS.querySelector('.season-header').classList.remove('expanded');
    _mtS.querySelector('.season-body').classList.remove('expanded');
    document.getElementById("modalTrailer").innerHTML = "";
  }
  const _mrS = document.getElementById("recommendationsSection");
  if (_mrS) {
    _mrS.style.display = "none";
    _mrS.querySelector('.season-header').classList.remove('expanded');
    _mrS.querySelector('.season-body').classList.remove('expanded');
    document.getElementById("modalRecommendations").innerHTML = "";
  }
  const modalMeta = document.querySelector('.modal-meta');
  if (modalMeta) modalMeta.classList.remove('loaded');

  seasonAccordion.innerHTML = "";
  const _lab = document.getElementById("langAvailBanner");
  if (_lab) {
    _lab.style.display = "block";
    _lab.innerHTML = "";
    _lab.className = "lang-avail-banner skeleton";
  }
  statusBar.classList.remove("active");
  availableProviders = null;
  currentSeriesUrl = url;
  currentSeriesTitle = "";
  await checkLangSeparation();
  rebuildLanguageSelect();
  resetProviderDropdown();
  loadCustomPaths();

  try {
    const [seriesResp, seasonsResp] = await Promise.all([
      fetch("/api/series?url=" + encodeURIComponent(url)),
      fetch("/api/seasons?url=" + encodeURIComponent(url)),
    ]);
    const seriesData = await seriesResp.json();
    const seasonsData = await seasonsResp.json();
    document.getElementById("modal").classList.remove("skeleton");
    document.getElementById("modalPoster").style.opacity = "";

    currentSeriesTitle = seriesData.title || "Unbekannt";
    document.getElementById("modalTitle").textContent = currentSeriesTitle;
    if (seriesData.poster_url)
      document.getElementById("modalPoster").src = proxyImg(seriesData.poster_url);
    const _genresEl = document.getElementById("modalGenres");
    _genresEl.innerHTML = "";
    (seriesData.genres || []).forEach(g => {
      const sp = document.createElement("span");
      sp.textContent = g;
      _genresEl.appendChild(sp);
    });
    document.getElementById("modalYear").textContent =
      seriesData.release_year || "";
    document.getElementById("modalDesc").textContent =
      seriesData.description || "";

    if (modalMeta) modalMeta.classList.add('loaded');

    enrichModalWithTmdb(currentSeriesTitle, seriesData.imdb_id || null);

    currentSeasons = seasonsData.seasons || [];
    buildAccordion(currentSeasons);

    // For FilmPalast movies: populate provider dropdown from movie metadata
    const isMovie = !!seriesData.is_movie;
    const epHeading = document.getElementById("episodesHeading");
    if (epHeading) epHeading.style.display = isMovie ? "none" : "";
    if (isMovie && seriesData.available_providers && seriesData.available_providers.length) {
      availableProviders = { "German Dub": seriesData.available_providers };
      updateProviderDropdown();
    }

    // Hide auto-sync and download-all-langs for movies (not applicable)
    if (autoSyncCheck) {
      autoSyncCheck.parentElement.style.display = isMovie ? "none" : "";
    }
    if (downloadAllLangsBtn) {
      // For movies, always hide; for series, defer to langSeparationEnabled setting
      if (isMovie) {
        downloadAllLangsBtn.style.display = "none";
      } else {
        downloadAllLangsBtn.style.display = langSeparationEnabled ? "" : "none";
      }
    }

    // Check if auto-sync exists for this series
    if (autoSyncCheck) {
      autoSyncCheck.checked = false;
      try {
        const syncResp = await fetch(
          "/api/autosync/check?url=" + encodeURIComponent(url),
        );
        const syncData = await syncResp.json();
        autoSyncCheck.checked = !!syncData.exists;
      } catch (e) {
        /* ignore */
      }
    }

    // Check if this series is a favourite
    _updateFavouriteBtn(url, seriesData.title, seriesData.poster_url || "");
  } catch (e) {
    document.getElementById("modal").classList.remove("skeleton");
    document.getElementById("modalPoster").style.opacity = "";
    showToast("Serie konnte nicht geladen werden: " + e.message);
  }
}

function buildAccordion(seasons) {
  seasonAccordion.innerHTML = "";
  episodeSpinner.style.display = "block";
  selectAllCb.checked = false;

  // Fetch all seasons' episodes in parallel
  const fetches = seasons.map((s, i) =>
    fetch("/api/episodes?url=" + encodeURIComponent(s.url))
      .then((r) => r.json())
      .then((data) => ({ index: i, episodes: data.episodes || [] }))
      .catch(() => ({ index: i, episodes: [] })),
  );

  Promise.all(fetches).then((results) => {
    episodeSpinner.style.display = "none";
    let firstProviderUrl = null;

    results.sort((a, b) => a.index - b.index);
    results.forEach(({ index, episodes }) => {
      const season = seasons[index];
      const section = document.createElement("div");
      section.className = "season-section";
      section.dataset.seasonIndex = index;

      const label = season.is_single_movie
        ? "Film"
        : season.are_movies
          ? `Filme (${episodes.length} Episoden)`
          : `Staffel ${season.season_number} (${episodes.length} Episoden)`;

      const isSingleMovie = !!season.is_single_movie;

      // Header — hidden for single movies (no season concept)
      const header = document.createElement("div");
      if (isSingleMovie) {
        header.className = "season-header season-header-movie expanded";
        header.style.display = "none";
      } else {
        const allDownloaded =
          episodes.length > 0 && episodes.every((ep) => ep.downloaded);
        const seasonDlIcon = allDownloaded
          ? '<span class="season-downloaded" title="Alle Episoden heruntergeladen">&#10003;</span>'
          : "";
        header.className = "season-header";
        header.innerHTML =
          `<div class="season-label"><span class="season-arrow">&#9654;</span> ${esc(label)}${seasonDlIcon}</div>` +
          `<label class="season-all-label" onclick="event.stopPropagation()"><input type="checkbox" onchange="toggleSeasonAll(this, ${index})"> Alle</label>`;
        header.addEventListener("click", () => toggleSeason(index));
      }

      // Body
      const body = document.createElement("div");
      body.className = "season-body" + (isSingleMovie ? " expanded" : "");
      body.id = "seasonBody-" + index;

      // Language flags
      const langFlagMap = {
        "German Dub": "/static/flags/german.svg",
        "English Dub": "/static/flags/english.svg",
        "German Sub": "/static/flags/japanese-germanSub.svg",
        "English Sub": "/static/flags/japanese-englishSub.svg",
      };

      episodes.forEach((ep) => {
        const div = document.createElement("div");
        div.className = "episode-item";
        const title = ep.title_en || ep.title_de || "";
        const dlIcon = ep.downloaded
          ? '<span class="ep-downloaded" title="Downloaded">&#10003;</span>'
          : "";

        let langsHtml = "";
        if (ep.languages && ep.languages.length) {
          const pills = ep.languages.map((l) => {
            const src = langFlagMap[l];
            if (!src) return "";
            return `<img class="ep-lang-flag" src="${src}" title="${esc(l)}" alt="${esc(l)}">`;
          }).join("");
          langsHtml = `<span class="ep-langs">${pills}</span>`;
        }

        const epNumHtml = isSingleMovie ? "" : `<span class="ep-num">E${ep.episode_number}</span>`;
        const cb = `<input type="checkbox" value="${esc(ep.url)}" data-season="${index}"${isSingleMovie ? " checked" : ""}>`;
        div.innerHTML = `${cb}${epNumHtml}${dlIcon}<span class="ep-title">${esc(title)}</span>${langsHtml}`;
        body.appendChild(div);
      });

      if (!firstProviderUrl && episodes.length) {
        firstProviderUrl = episodes[0].url;
      }

      section.appendChild(header);
      section.appendChild(body);
      seasonAccordion.appendChild(section);
    });

    // Language availability banner
    renderLangAvailBanner(results);

    // Fetch providers from first episode (skip for FilmPalast — already set in openSeries)
    if (firstProviderUrl && !(currentSeriesUrl || "").includes("filmpalast.to")) {
      fetchProviders(firstProviderUrl);
    }
  });
}

function renderLangAvailBanner(results) {
  const banner = document.getElementById("langAvailBanner");
  if (!banner) return;
  banner.classList.remove("skeleton");
  // FilmPalast movies don't need a language availability banner
  if ((currentSeriesUrl || "").includes("filmpalast.to")) {
    banner.style.display = "none";
    return;
  }

  const LANG_ORDER = ["German Dub", "English Sub", "German Sub", "English Dub"];
  const LANG_SHORT = {
    "German Dub": "Ger. Dub",
    "English Sub": "Eng. Sub",
    "German Sub": "Ger. Sub",
    "English Dub": "Eng. Dub",
  };

  // Count episodes per language and total
  const counts = {};
  let total = 0;
  results.forEach(({ episodes }) => {
    episodes.forEach((ep) => {
      total++;
      if (ep.languages) {
        ep.languages.forEach((l) => {
          counts[l] = (counts[l] || 0) + 1;
        });
      }
    });
  });

  if (total === 0) { banner.style.display = "none"; return; }

  const pills = LANG_ORDER.map((lang) => {
    const n = counts[lang] || 0;
    const pct = Math.round((n / total) * 100);
    const full = n === total;
    const none = n === 0;
    const cls = full ? "lang-avail-pill lang-avail-full"
      : none ? "lang-avail-pill lang-avail-none"
        : "lang-avail-pill lang-avail-partial";
    return `<span class="${cls}" title="${lang}">${LANG_SHORT[lang]}: ${n}&thinsp;/&thinsp;${total}</span>`;
  }).join("");

  banner.innerHTML = pills;
  banner.style.display = "flex";
}

function toggleSeason(index) {
  const section = seasonAccordion.querySelector(
    `[data-season-index="${index}"]`,
  );
  if (!section) return;
  const header = section.querySelector(".season-header");
  const body = section.querySelector(".season-body");
  header.classList.toggle("expanded");
  body.classList.toggle("expanded");
}

function toggleSeasonAll(checkbox, seasonIndex) {
  const body = document.getElementById("seasonBody-" + seasonIndex);
  if (!body) return;
  body
    .querySelectorAll("input[type=checkbox]")
    .forEach((cb) => (cb.checked = checkbox.checked));
  syncSelectAll();
}

function toggleSelectAll() {
  const checked = selectAllCb.checked;
  seasonAccordion
    .querySelectorAll("input[type=checkbox]")
    .forEach((cb) => (cb.checked = checked));
}

function syncSelectAll() {
  const all = seasonAccordion.querySelectorAll(
    ".episode-item input[type=checkbox]",
  );
  const checked = seasonAccordion.querySelectorAll(
    ".episode-item input[type=checkbox]:checked",
  );
  selectAllCb.checked = all.length > 0 && all.length === checked.length;
}

function getAllEpisodeUrls() {
  return Array.from(
    seasonAccordion.querySelectorAll(".episode-item input[type=checkbox]"),
  ).map((cb) => cb.value);
}

function getSelectedEpisodeUrls() {
  return Array.from(
    seasonAccordion.querySelectorAll(
      ".episode-item input[type=checkbox]:checked",
    ),
  ).map((cb) => cb.value);
}

async function fetchProviders(episodeUrl) {
  try {
    const resp = await fetch(
      "/api/providers?url=" + encodeURIComponent(episodeUrl),
    );
    const data = await resp.json();
    if (data.providers) {
      availableProviders = data.providers;
      updateProviderDropdown();
    }
  } catch (e) {
    // If provider fetch fails, keep the static list
  }
}

function resetProviderDropdown() {
  providerSelect.innerHTML = "";
  staticProviders.forEach((p) => {
    const opt = document.createElement("option");
    opt.value = p;
    opt.textContent = p;
    providerSelect.appendChild(opt);
  });
  selectDefaultProvider();
}

function updateProviderDropdown() {
  if (!availableProviders) return;

  const lang = languageSelect.value;
  const providers = availableProviders[lang];

  providerSelect.innerHTML = "";
  if (providers && providers.length) {
    providers.forEach((p) => {
      const opt = document.createElement("option");
      opt.value = p;
      opt.textContent = p;
      providerSelect.appendChild(opt);
    });
  } else {
    staticProviders.forEach((p) => {
      const opt = document.createElement("option");
      opt.value = p;
      opt.textContent = p;
      providerSelect.appendChild(opt);
    });
  }
  selectDefaultProvider();
}

function selectDefaultProvider() {
  for (const opt of providerSelect.options) {
    if (opt.value === "VOE") {
      providerSelect.value = "VOE";
      return;
    }
  }
}

async function startDownload(all) {
  const episodes = all ? getAllEpisodeUrls() : getSelectedEpisodeUrls();
  if (!episodes.length) {
    showToast(all ? "Keine Episoden verfügbar." : "Keine Episoden ausgewählt.");
    return;
  }

  const language = languageSelect.value;
  const provider = providerSelect.value;

  downloadAllBtn.disabled = true;
  downloadSelectedBtn.disabled = true;
  try {
    const dlBody = {
      episodes,
      language,
      provider,
      title: currentSeriesTitle,
      series_url: currentSeriesUrl,
    };
    if (customPathSelect && customPathSelect.value) {
      dlBody.custom_path_id = parseInt(customPathSelect.value);
    }
    const resp = await fetch("/api/download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(dlBody),
    });
    const data = await resp.json();
    if (data.error) {
      showToast(data.error);
      return;
    }

    showToast("Zur Download-Warteschlange hinzugefügt");
    if (typeof loadQueue === "function") loadQueue();
  } catch (e) {
    showToast("Download-Anfrage fehlgeschlagen: " + e.message);
  } finally {
    downloadAllBtn.disabled = false;
    downloadSelectedBtn.disabled = false;
  }
}

function closeModal() {
  overlay.style.display = "none";
  document.body.style.overflow = "";
  if (autoSyncCheck) autoSyncCheck.checked = false;
}
function closeModalOutside(e) {
  if (e.target === overlay) closeModal();
}

// Auto-Sync toggle from modal checkbox
async function toggleAutoSync() {
  if (!autoSyncCheck) return;
  if (autoSyncCheck.checked) {
    // Select all episodes
    selectAllCb.checked = true;
    toggleSelectAll();
    // Create sync job
    try {
      const body = {
        title: currentSeriesTitle,
        series_url: currentSeriesUrl,
        language: languageSelect.value,
        provider: providerSelect.value,
      };
      if (customPathSelect && customPathSelect.value) {
        body.custom_path_id = parseInt(customPathSelect.value);
      }
      const resp = await fetch("/api/autosync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await resp.json();
      if (data.ok) {
        showToast('Auto-Sync aktiviert für "' + currentSeriesTitle + '"');
        autoSyncUrlMap[(currentSeriesUrl || "").replace(/\/+$/, "").toLowerCase()] = { series_url: currentSeriesUrl };
        refreshSyncBadges();
      } else if (resp.status === 409 && data.job) {
        // Job already exists — update it with current modal settings
        const updateBody = {
          language: languageSelect.value,
          provider: providerSelect.value,
          custom_path_id:
            customPathSelect && customPathSelect.value
              ? parseInt(customPathSelect.value)
              : null,
        };
        const putResp = await fetch("/api/autosync/" + data.job.id, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(updateBody),
        });
        const putData = await putResp.json();
        if (putData.ok) {
          showToast('Auto-Sync aktualisiert für "' + currentSeriesTitle + '"');
          autoSyncUrlMap[(currentSeriesUrl || "").replace(/\/+$/, "").toLowerCase()] = { series_url: currentSeriesUrl };
          refreshSyncBadges();
        } else {
          showToast(putData.error || "Sync-Job konnte nicht aktualisiert werden");
        }
      } else if (data.error) {
        showToast(data.error);
      }
    } catch (e) {
      showToast("Sync-Job konnte nicht erstellt werden");
      autoSyncCheck.checked = false;
    }
  } else {
    // Remove sync job
    try {
      const resp = await fetch(
        "/api/autosync/check?url=" + encodeURIComponent(currentSeriesUrl),
      );
      const data = await resp.json();
      if (data.exists && data.job) {
        const delResp = await fetch("/api/autosync/" + data.job.id, {
          method: "DELETE",
        });
        const delData = await delResp.json();
        if (delData.ok) {
          showToast('Auto-Sync deaktiviert für "' + currentSeriesTitle + '"');
          delete autoSyncUrlMap[(currentSeriesUrl || "").replace(/\/+$/, "").toLowerCase()];
          refreshSyncBadges();
        } else {
          showToast(delData.error || "Sync-Job konnte nicht entfernt werden");
          autoSyncCheck.checked = true;
        }
      }
    } catch (e) {
      showToast("Sync-Job konnte nicht entfernt werden");
      autoSyncCheck.checked = true;
    }
  }
}

// Provider → branded color map
const _providerColors = {
  'Netflix': '#E50914',
  'Netflix basic with Ads': '#E50914',
  'Netflix Standard with Ads': '#E50914',
  'Amazon Prime Video': '#00A8E0',
  'Amazon Channel': '#00A8E0',
  'Amazon Prime': '#00A8E0',
  'Disney+': '#0063E5',
  'Disney Plus': '#0063E5',
  'Apple TV+': '#555',
  'Apple TV Plus': '#555',
  'Sky': '#003C8F',
  'WOW': '#00B4D8',
  'RTL+': '#FF6900',
  'Joyn': '#00C896',
  'Paramount+': '#0064FF',
  'Max': '#5822B7',
  'HBO Max': '#5822B7',
  'Crunchyroll': '#F47521',
  'MUBI': '#C2410C',
  'Hulu': '#1CE783',
  'MagentaTV': '#E20074',
  'ARD Mediathek': '#003D5B',
  'ZDFmediathek': '#008CD2',
};

function getProviderColor(name) {
  // 1. Exakter Match (für die Performance und genaue Treffer)
  if (_providerColors[name]) {
    return _providerColors[name];
  }

  // 2. Teilstring-Match (sucht nach "Amazon Channel" im Namen)
  const exactKey = Object.keys(_providerColors).find(key => name.includes(key));

  // Wenn was gefunden wurde, nimm die Farbe, ansonsten Fallback (z.B. grau)
  return exactKey ? _providerColors[exactKey] : '#888';
}

function _makeProviderPill(name) {
  const pill = document.createElement('span');
  pill.className = 'tmdb-provider-pill';
  const color = getProviderColor(name);
  // Always apply full pill style inline – not reliant on cached CSS
  pill.style.cssText = [
    'display:inline-flex',
    'align-items:center',
    'gap:6px',
    'font-size:0.75rem',
    'font-weight:600',
    'padding:4px 12px 4px 8px',
    'border-radius:99px',
    'border:1.5px solid ' + (color ? color + '60' : 'rgba(148,163,184,.35)'),
    'background:var(--bg-elevated,#1a1a28)',
    'color:' + (color || 'var(--text-secondary,#9191b0)'),
    'white-space:nowrap',
    'line-height:1.4',
    'cursor:default',
  ].join(';');
  if (color) {
    const dot = document.createElement('span');
    dot.style.cssText = 'width:7px;height:7px;border-radius:50%;background:' + color + ';flex-shrink:0;display:inline-block';
    pill.appendChild(dot);
  }
  const label = document.createElement('span');
  label.textContent = name;
  pill.appendChild(label);
  return pill;
}

async function enrichModalWithTmdb(title, imdbId) {
  const provEl = document.getElementById('tmdbProviders');
  if (!provEl) return;
  if (!cineinfoSettings || !cineinfoSettings.tmdb_api_key) return;
  try {
    let tmdbUrl = '/api/tmdb/info?title=' + encodeURIComponent(title).replace(/'/g, "%27");
    if (imdbId) tmdbUrl += '&imdb_id=' + encodeURIComponent(imdbId).replace(/'/g, "%27");
    const resp = await fetch(tmdbUrl);
    const d = await resp.json();
    console.log("[CineInfo] Full Modal Data for", title, ":", d);
    console.log("[CineInfo] Settings Debug - General:", generalSettings, "CineInfo:", cineinfoSettings);
    const sTrailer = cineinfoSettings?.show_trailer ?? "1";
    const sRecs = cineinfoSettings?.show_recommendations ?? "1";
    console.log("[CineInfo] Final Checks - show_trailer:", sTrailer, "show_recs:", sRecs);
    if (!d.found) return;
    if (cineinfoSettings.show_providers !== '0' && d.providers && d.providers.length) {
      provEl.innerHTML = '';
      provEl.style.cssText = [
        'display:flex',
        'flex-wrap:wrap',
        'gap:5px',
        'margin:4px 0 16px',
        'max-height:74px',
        'overflow:hidden',
        'position:relative',
      ].join(';');
      const MAX_SHOW = 6;
      const visible = d.providers.slice(0, MAX_SHOW);
      const rest = d.providers.length - MAX_SHOW;
      visible.forEach(p => provEl.appendChild(_makeProviderPill(p)));
      if (rest > 0) {
        const more = document.createElement('span');
        more.textContent = '+' + rest + '\u00a0mehr';
        more.style.cssText = [
          'display:inline-flex',
          'align-items:center',
          'font-size:0.72rem',
          'font-weight:600',
          'padding:4px 10px',
          'border-radius:99px',
          'border:1.5px solid rgba(148,163,184,.3)',
          'background:var(--bg-elevated,#1a1a28)',
          'color:var(--text-muted,#55556a)',
          'white-space:nowrap',
          'cursor:default',
        ].join(';');
        provEl.appendChild(more);
      }
    }
    // TMDB Genres — ersetze die Seiten-Genres wenn aktiviert
    if (cineinfoSettings.show_genres === '1' && d.genres && d.genres.length) {
      const genresEl = document.getElementById('modalGenres');
      if (genresEl) {
        genresEl.innerHTML = '';
        d.genres.forEach(g => {
          const sp = document.createElement('span');
          sp.textContent = g;
          genresEl.appendChild(sp);
        });
      }
    }
    // Bewertung neben dem Titel
    if (cineinfoSettings.show_rating === '1' && d.vote_average) {
      // Badge lives INSIDE the h2 so it sits inline next to the title text
      const titleEl = document.getElementById('modalTitle');
      if (titleEl) {
        // Make h2 a flex row so title text + badge align on one line
        titleEl.style.cssText = [
          'display:flex',
          'align-items:center',
          'flex-wrap:wrap',
          'gap:8px',
          'margin:0 0 4px',
        ].join(';');
        // Remove old badge if modal was reopened
        const old = titleEl.querySelector('#tmdbRating');
        if (old) old.remove();
        const score = d.vote_average.toFixed(1);
        const col = d.vote_average >= 7 ? '#4ade80' : d.vote_average >= 5 ? '#fbbf24' : '#f87171';
        const brd = d.vote_average >= 7 ? 'rgba(74,222,128,.4)' : d.vote_average >= 5 ? 'rgba(251,191,36,.4)' : 'rgba(248,113,113,.4)';
        const ratingEl = document.createElement('span');
        ratingEl.id = 'tmdbRating';
        ratingEl.style.cssText = [
          'display:inline-flex',
          'align-items:center',
          'gap:4px',
          'font-size:0.72rem',
          'font-weight:700',
          'padding:2px 8px 2px 6px',
          'border-radius:99px',
          'border:1px solid ' + brd,
          'background:rgba(0,0,0,.22)',
          'color:' + col,
          'white-space:nowrap',
          'cursor:default',
          'letter-spacing:.01em',
          'flex-shrink:0',
          'vertical-align:middle',
        ].join(';');
        ratingEl.innerHTML =
          '<svg width="10" height="10" viewBox="0 0 24 24" fill="' + col + '" style="flex-shrink:0">' +
          '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>' +
          '</svg>' + score;
        titleEl.appendChild(ratingEl);
      }
    }
    // FSK unterhalb des Covers
    if (cineinfoSettings.show_fsk !== '0' && d.fsk) {
      const fskEl = document.getElementById('tmdbFsk');
      if (fskEl) {
        const fskNum = parseInt(d.fsk, 10);
        const _fskPalette = {
          0: { bg: 'rgba(255,255,255,.07)', bc: 'rgba(255,255,255,.3)', c: '#d1d5db' },
          6: { bg: 'rgba(234,179,8,.12)', bc: 'rgba(234,179,8,.55)', c: '#fbbf24' },
          12: { bg: 'rgba(34,197,94,.12)', bc: 'rgba(34,197,94,.5)', c: '#4ade80' },
          16: { bg: 'rgba(59,130,246,.12)', bc: 'rgba(59,130,246,.5)', c: '#60a5fa' },
          18: { bg: 'rgba(239,68,68,.12)', bc: 'rgba(239,68,68,.5)', c: '#f87171' },
        };
        const fp = _fskPalette[fskNum] || { bg: 'rgba(148,163,184,.1)', bc: 'rgba(148,163,184,.35)', c: '#94a3b8' };
        fskEl.textContent = 'FSK\u00a0' + d.fsk;
        fskEl.style.cssText = [
          'display:block',
          'font-size:0.75rem',
          'font-weight:700',
          'padding:3px 10px',
          'border-radius:99px',
          'border:1px solid ' + fp.bc,
          'background:' + fp.bg,
          'color:' + fp.c,
          'text-align:center',
          'white-space:nowrap',
          'letter-spacing:.02em',
          'width:100%',
          'box-sizing:border-box',
        ].join(';');
      }

    }
    // Trailer
    const trailerEl = document.getElementById('modalTrailer');
    const trailerSection = document.getElementById('trailerSection');
    if (trailerEl && trailerSection) {
      const showT = (cineinfoSettings?.show_trailer !== '0');
      if (showT && d.trailer_key) {
        trailerEl.innerHTML = `<iframe src="https://www.youtube.com/embed/${d.trailer_key}" allowfullscreen></iframe>`;
        trailerSection.style.display = 'block';
      } else {
        trailerEl.innerHTML = '';
        trailerSection.style.display = 'none';
      }
    }
    // Recommendations
    const recEl = document.getElementById('modalRecommendations');
    const recSection = document.getElementById('recommendationsSection');
    if (recEl && recSection) {
      const showR = (cineinfoSettings?.show_recommendations !== '0');
      if (showR && d.recommendations && d.recommendations.length) {
        recSection.style.display = 'block';
        let html = '<div class="recommendations-grid">';
        d.recommendations.forEach(r => {
          const poster = r.poster_path ? `https://image.tmdb.org/t/p/w185${r.poster_path}` : '';
          html += `
            <div class="rec-card" data-title="${esc(r.title)}" onclick="searchForTitle(this.dataset.title)">
              <img class="rec-poster" src="${proxyImg(poster)}" alt="">
              <div class="rec-title" title="${esc(r.title)}">${esc(r.title)}</div>
            </div>
          `;
        });
        html += '</div>';
        recEl.innerHTML = html;
      } else {
        recSection.style.display = 'none';
      }
    }
  } catch (e) { /* best-effort */ }
}

function searchForTitle(title) {
  closeModal();
  const sIn = document.getElementById("searchInput");
  if (sIn) {
    sIn.value = title;
    doSearch();
  } else {
    saveAdvSearchState();
    window.location.href = "/?q=" + encodeURIComponent(title);
  }
}

function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.style.display = "";
  t.classList.remove("show");
  void t.offsetWidth; // reflow so transition fires even on repeated calls
  t.classList.add("show");
  clearTimeout(t._hideTimer);
  t._hideTimer = setTimeout(() => t.classList.remove("show"), 4000);
}

function unesc(s) {
  const d = document.createElement("textarea");
  d.innerHTML = s || "";
  return d.value;
}

function esc(s) {
  const d = document.createElement("div");
  d.textContent = unesc(s);
  return d.innerHTML;
}

const downloadAllLangsBtn = document.getElementById("downloadAllLangsBtn");
let defaultSyncLanguage = "German Dub";

async function checkLangSeparation() {
  try {
    const resp = await fetch("/api/settings");
    const data = await resp.json();
    langSeparationEnabled = data.lang_separation === "1";
    if (data.sync_language) {
      defaultSyncLanguage = data.sync_language;
    }
    if (downloadAllLangsBtn) {
      downloadAllLangsBtn.style.display = langSeparationEnabled ? "" : "none";
    }
  } catch (e) {
    /* ignore */
  }
}

async function startDownloadAllLangs() {
  const episodes = getAllEpisodeUrls();
  if (!episodes.length) {
    showToast("Keine Episoden verfügbar.");
    return;
  }
  if (!availableProviders) {
    showToast("Anbieter-Daten noch nicht geladen.");
    return;
  }

  downloadAllLangsBtn.disabled = true;
  downloadAllBtn.disabled = true;
  downloadSelectedBtn.disabled = true;

  let queued = 0;
  try {
    for (const [lang, providers] of Object.entries(availableProviders)) {
      if (!providers.length) continue;
      const provider = providers.includes("VOE") ? "VOE" : providers[0];
      const dlBody = {
        episodes,
        language: lang,
        provider,
        title: currentSeriesTitle,
        series_url: currentSeriesUrl,
      };
      if (customPathSelect && customPathSelect.value) {
        dlBody.custom_path_id = parseInt(customPathSelect.value);
      }
      const resp = await fetch("/api/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dlBody),
      });
      const data = await resp.json();
      if (!data.error) queued++;
    }
    showToast(queued + " Sprache(n) zur Warteschlange hinzugefügt");
    if (typeof loadQueue === "function") loadQueue();
  } catch (e) {
    showToast("Downloads konnten nicht zur Warteschlange hinzugefügt werden: " + e.message);
  } finally {
    downloadAllLangsBtn.disabled = false;
    downloadAllBtn.disabled = false;
    downloadSelectedBtn.disabled = false;
  }
}

// ===== Favourites =====

let _currentFavUrl = "";
let _currentFavTitle = "";
let _currentFavPoster = "";

async function _updateFavouriteBtn(url, title, posterUrl) {
  _currentFavUrl = url;
  _currentFavTitle = title;
  _currentFavPoster = posterUrl;
  const btn = document.getElementById("favouriteBtn");
  if (!btn) return;
  try {
    const resp = await fetch("/api/favourites/check?series_url=" + encodeURIComponent(url).replace(/'/g, "%27"));
    const data = await resp.json();
    btn.textContent = data.is_favourite ? "♥ Favorit" : "♡ Merken";
    btn.dataset.isFav = data.is_favourite ? "1" : "0";
  } catch (e) { /* ignore */ }
}

async function toggleFavourite() {
  const btn = document.getElementById("favouriteBtn");
  if (!btn || !_currentFavUrl) return;
  const isFav = btn.dataset.isFav === "1";
  try {
    if (isFav) {
      await fetch("/api/favourites", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ series_url: _currentFavUrl }),
      });
      btn.textContent = "♡ Merken";
      btn.dataset.isFav = "0";
      showToast("Aus Favoriten entfernt");
    } else {
      await fetch("/api/favourites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          series_url: _currentFavUrl,
          title: _currentFavTitle,
          poster_url: _currentFavPoster,
        }),
      });
      btn.textContent = "♥ Favorit";
      btn.dataset.isFav = "1";
      showToast("Zu Favoriten hinzugefügt ♥");
    }
  } catch (e) {
    showToast("Fehler: " + e.message);
  }
}

window.openSeriesModal = function (url, title) {
  openSeries(url);
};

// Pre-load autosync map on page start so search results also get badges
loadAutoSyncJobs();
loadCineinfoSettings();
loadGeneralSettings();

// Auto-search if ?q= is in the query string (e.g. from Seerr page)
(function () {
  const params = new URLSearchParams(window.location.search);
  const q = params.get("q");
  if (q && searchInput) {
    window.history.replaceState({}, "", window.location.pathname);
    searchInput.value = q;
    doSearch();
  }
})();

// ── Direkt-Link Modal ────────────────────────────────────────────────────────

function openDirectLinkModal() {
  const overlay = document.getElementById("directLinkOverlay");
  const input = document.getElementById("directLinkInput");
  const error = document.getElementById("directLinkError");
  error.textContent = "";
  error.style.display = "none";
  input.value = "";
  overlay.style.display = "block";
  document.body.style.overflow = "hidden";
  setTimeout(() => input.focus(), 50);
}

function closeDirectLinkModal() {
  document.getElementById("directLinkOverlay").style.display = "none";
  document.body.style.overflow = "";
}

function closeDLModalOutside(event) {
  if (event.target === document.getElementById("directLinkOverlay")) {
    closeDirectLinkModal();
  }
}

function submitDirectLink() {
  const input = document.getElementById("directLinkInput");
  const error = document.getElementById("directLinkError");
  let url = input.value.trim();

  // Normalize: strip trailing slash
  url = url.replace(/\/+$/, "");

  const isSto = /s\.to\/serie\/[^\/]+/.test(url);
  const isAniworld = /aniworld\.to\/anime\/stream\/[^\/]+/.test(url);

  if (!isSto && !isAniworld) {
    error.textContent = "Ungültige URL. Bitte eine s.to oder aniworld.to Serien-URL eingeben.";
    error.style.display = "block";
    input.focus();
    return;
  }

  // Extract base series URL (strip staffel/episode sub-paths)
  let seriesUrl = url;
  if (isSto) {
    const m = url.match(/(https?:\/\/[^/]*s\.to\/serie\/[^\/]+)/);
    if (m) seriesUrl = m[1];
  } else {
    const m = url.match(/(https?:\/\/[^/]*aniworld\.to\/anime\/stream\/[^\/]+)/);
    if (m) seriesUrl = m[1];
  }

  closeDirectLinkModal();
  openSeries(seriesUrl);
}

document.addEventListener("DOMContentLoaded", () => {
  const dlInput = document.getElementById("directLinkInput");
  if (dlInput) {
    dlInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") submitDirectLink();
      if (e.key === "Escape") closeDirectLinkModal();
    });
  }
});

// ── Ende Direkt-Link Modal ───────────────────────────────────────────────────

// Auto-open modal if ?open=<encoded-url> is in the query string (e.g. from Favourites page)
// Or trigger search if ?q=<search> is present
(function () {
  const params = new URLSearchParams(window.location.search);
  const openUrl = params.get("open");
  const searchQuery = params.get("q");

  if (openUrl || searchQuery) {
    // Remove query param from browser history without reload
    const cleanUrl = window.location.pathname;
    window.history.replaceState({}, "", cleanUrl);

    const action = () => {
      if (openUrl) {
        openSeries(decodeURIComponent(openUrl));
      } else if (searchQuery) {
        const input = document.getElementById("searchInput");
        if (input) {
          input.value = decodeURIComponent(searchQuery);
          doSearch();
        }
      }
    };

    // Wait for DOM to be ready
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", action);
    } else {
      action();
    }
  }
})();

// ── Erweiterte Suche ──────────────────────────────────────────────────────────

let currentType = 'tv';
let allGenres = { tv: [], movie: [] };
let selectedKeywords = []; // Array of { id, name }

// Pagination & Buffer State
let allLoadedResults = [];
let totalTmdbResults = 0;
let currentTmdbPage = 0;
let currentPageIndex = 0; // 0-indexed local grid page
let lastSearchParams = null;
let isFetchingTmdb = false;
let activeFetchPromise = null;

function saveAdvSearchState() {
  const filtersContainer = document.getElementById('advFiltersContainer');
  if (!filtersContainer) return;
  const checkedGenres = Array.from(document.querySelectorAll('.genre-checkbox:checked')).map(cb => cb.value);
  const isMenuOpen = filtersContainer.classList.contains('is-open');
  const state = {
    currentType,
    checkedGenres,
    selectedKeywords,
    isMenuOpen,
    yearMin: document.getElementById('yearMin')?.value || '',
    yearMax: document.getElementById('yearMax')?.value || '',
    voteMin: document.getElementById('voteMin')?.value || '0',
    sortBy: document.getElementById('sortBy')?.value || 'popularity.desc',
    allLoadedResults,
    totalTmdbResults,
    currentTmdbPage,
    currentPageIndex,
    lastSearchParamsStr: lastSearchParams ? lastSearchParams.toString() : null,
    timestamp: Date.now()
  };
  localStorage.setItem('advSearchState', JSON.stringify(state));
}

function loadAdvSearchState() {
  const stateStr = localStorage.getItem('advSearchState');
  if (!stateStr) return;
  try {
    const state = JSON.parse(stateStr);
    const ageMs = Date.now() - state.timestamp;
    if (ageMs > 5 * 60 * 1000) { // 5 minutes cache expiration, cause there could be a switch...
      localStorage.removeItem('advSearchState');
      return;
    }

    currentType = state.currentType || 'tv';
    selectedKeywords = state.selectedKeywords || [];
    allLoadedResults = state.allLoadedResults || [];
    totalTmdbResults = state.totalTmdbResults || 0;
    currentTmdbPage = state.currentTmdbPage || 0;
    currentPageIndex = state.currentPageIndex || 0;
    lastSearchParams = state.lastSearchParamsStr ? new URLSearchParams(state.lastSearchParamsStr) : null;

    // Restore DOM inputs
    const mediaTV = document.querySelector('#mediaTypeFilter [data-type="tv"]');
    const mediaMovie = document.querySelector('#mediaTypeFilter [data-type="movie"]');
    if (mediaTV && mediaMovie) {
      mediaTV.classList.toggle('active', currentType === 'tv');
      mediaMovie.classList.toggle('active', currentType === 'movie');
    }

    const yearMinEl = document.getElementById('yearMin');
    if (yearMinEl) yearMinEl.value = state.yearMin || '';

    const yearMaxEl = document.getElementById('yearMax');
    if (yearMaxEl) yearMaxEl.value = state.yearMax || '';

    const voteMinEl = document.getElementById('voteMin');
    if (voteMinEl) {
      voteMinEl.value = state.voteMin || '0';
      const voteLabel = document.getElementById("voteLabel");
      if (voteLabel) {
        const val = parseInt(state.voteMin, 10);
        if (val === 0) voteLabel.textContent = "0 - 10 (Alle)";
        else voteLabel.textContent = `${val} - 10`;
      }
    }

    const sortByEl = document.getElementById('sortBy');
    if (sortByEl) {
      let savedSortBy = state.sortBy || 'popularity.desc';
      if (savedSortBy.startsWith('first_air_date')) {
        savedSortBy = savedSortBy.replace('first_air_date', 'primary_release_date');
      }
      sortByEl.value = savedSortBy;
    }

    const filtersContainer = document.getElementById('advFiltersContainer');
    if (filtersContainer && state.isMenuOpen) {
      filtersContainer.classList.add('is-open');
    }

    renderSelectedKeywords();

    window.checkedGenresToRestore = state.checkedGenres || [];

    // Restore results UI
    if (lastSearchParams !== null) {
      if (totalTmdbResults > 0) {
        document.getElementById('resultsCount').textContent = `${totalTmdbResults} Ergebnisse`;
      } else {
        document.getElementById('resultsCount').textContent = `0 Ergebnisse`;
      }
      renderLocalPage();
    }
  } catch (e) {
    console.error("Error loading advanced search state:", e);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById('advFiltersContainer')) {
    initUI();
    loadAdvSearchState();
    loadGenres();
  }
});

function initUI() {
  // Toggle Filters Panel
  const toggleBtn = document.getElementById('advFiltersToggle');
  const filtersContainer = document.getElementById('advFiltersContainer');
  if (toggleBtn && filtersContainer) {
    toggleBtn.addEventListener('click', () => {
      filtersContainer.classList.toggle('is-open');
      saveAdvSearchState();
    });
  }

  // Media Type Filter
  document.querySelectorAll('#mediaTypeFilter .filter-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('#mediaTypeFilter .filter-btn').forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');
      currentType = e.target.dataset.type;

      // Reset genres on type change
      document.querySelectorAll('.genre-checkbox').forEach(cb => cb.checked = false);
      updateGenreLabel();
      renderGenres();
      saveAdvSearchState();
    });
  });

  // Custom Select for Genres
  const genreSelect = document.getElementById('genreSelect');
  const genreSelectTrigger = document.getElementById('genreSelectTrigger');
  if (genreSelectTrigger) {
    genreSelectTrigger.addEventListener('click', (e) => {
      e.stopPropagation();
      genreSelect.classList.toggle('is-open');
    });
  }
  document.addEventListener('click', (e) => {
    if (genreSelect && !genreSelect.contains(e.target)) {
      genreSelect.classList.remove('is-open');
    }
  });

  // Vote range label
  const voteMin = document.getElementById("voteMin");
  const voteLabel = document.getElementById("voteLabel");
  if (voteMin && voteLabel) {
    voteMin.addEventListener('input', () => {
      const val = parseInt(voteMin.value, 10);
      voteLabel.textContent = `${val} - 10`;
    });
  }

  // Search button
  const runBtn = document.getElementById("runSearchBtn");
  if (runBtn) {
    runBtn.addEventListener('click', () => {
      // Start fresh search
      allLoadedResults = [];
      currentTmdbPage = 0;
      currentPageIndex = 0;
      totalTmdbResults = 0;

      runSearch();
    });
  }

  // Reset button
  const resetBtn = document.getElementById("resetFiltersBtn");
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      document.querySelectorAll('.genre-checkbox').forEach(cb => cb.checked = false);
      updateGenreLabel();
      selectedKeywords = [];
      renderSelectedKeywords();
      document.getElementById('yearMin').value = '';
      document.getElementById('yearMax').value = '';
      document.getElementById('voteMin').value = '0';
      document.getElementById('voteLabel').textContent = '0 - 10';
      document.getElementById('sortBy').value = 'popularity.desc';

      currentType = 'tv';
      const mediaTV = document.querySelector('#mediaTypeFilter [data-type="tv"]');
      const mediaMovie = document.querySelector('#mediaTypeFilter [data-type="movie"]');
      if (mediaTV && mediaMovie) {
        mediaTV.classList.add('active');
        mediaMovie.classList.remove('active');
      }
      renderGenres();

      document.getElementById('resultsGrid').innerHTML = '<div class="adv-empty-state">Filter zurückgesetzt. Bitte wähle deine Filter und klicke auf Suchen.</div>';
      document.getElementById('resultsCount').textContent = '';
      document.getElementById('keywordInput').value = '';
      document.getElementById('advPagination').style.display = 'none';
      lastSearchParams = null;
      localStorage.removeItem('advSearchState');
    });
  }

  // Pagination buttons
  const prevBtn = document.getElementById("prevPageBtn");
  const nextBtn = document.getElementById("nextPageBtn");
  if (prevBtn) prevBtn.addEventListener('click', goToPrevPage);
  if (nextBtn) nextBtn.addEventListener('click', goToNextPage);

  // Add auto-saving listeners to input controls
  const yearMin = document.getElementById("yearMin");
  const yearMax = document.getElementById("yearMax");
  const voteMinInput = document.getElementById("voteMin");
  const sortByInput = document.getElementById("sortBy");

  if (yearMin) yearMin.addEventListener('change', saveAdvSearchState);
  if (yearMax) yearMax.addEventListener('change', saveAdvSearchState);
  if (voteMinInput) voteMinInput.addEventListener('change', saveAdvSearchState);
  if (sortByInput) sortByInput.addEventListener('change', saveAdvSearchState);

  setupKeywordAutocomplete();
}

async function loadGenres() {
  try {
    const r = await fetch("/api/tmdb/genres");
    const d = await r.json();
    if (d.tv && d.movie) {
      allGenres = d;
      renderGenres();
    } else {
      const dd = document.getElementById('genreSelectDropdown');
      if (dd) dd.innerHTML = `<div style="color:var(--error);padding:0.5rem;">API Key Fehler.</div>`;
    }
  } catch (e) {
    const dd = document.getElementById('genreSelectDropdown');
    if (dd) dd.innerHTML = `<div style="color:var(--error);padding:0.5rem;">Netzwerkfehler.</div>`;
  }
}

function renderGenres() {
  const container = document.getElementById('genreSelectDropdown');
  if (!container) return;
  const genres = allGenres[currentType] || [];

  if (genres.length === 0) {
    container.innerHTML = `<div class="skeleton-loader" style="height: 40px; width: 100%; border-radius: 6px;"></div>`;
    return;
  }

  const currentlyChecked = Array.from(document.querySelectorAll('.genre-checkbox:checked')).map(cb => parseInt(cb.value, 10));

  container.innerHTML = '';
  genres.forEach(g => {
    const isChecked = currentlyChecked.includes(g.id) || (window.checkedGenresToRestore && window.checkedGenresToRestore.map(id => parseInt(id, 10)).includes(g.id));
    const cbId = `genre_${g.id}`;

    const item = document.createElement('label');
    item.className = 'custom-select-item';
    item.setAttribute('for', cbId);

    item.innerHTML = `
      <input type="checkbox" id="${cbId}" class="genre-checkbox" value="${g.id}" ${isChecked ? 'checked' : ''} />
      <span>${escapeHtml(g.name)}</span>
    `;

    item.querySelector('input').addEventListener('change', () => {
      updateGenreLabel();
      saveAdvSearchState();
    });
    container.appendChild(item);
  });

  window.checkedGenresToRestore = null;
  updateGenreLabel();
}

function updateGenreLabel() {
  const label = document.getElementById('genreSelectLabel');
  if (!label) return;

  const checkedBoxes = Array.from(document.querySelectorAll('.genre-checkbox:checked'));
  if (checkedBoxes.length === 0) {
    label.textContent = "Alle Genres";
  } else if (checkedBoxes.length <= 2) {
    const names = checkedBoxes.map(cb => cb.nextElementSibling.textContent);
    label.textContent = names.join(', ');
  } else {
    label.textContent = `${checkedBoxes.length} Genres ausgewählt`;
  }
}

function setupKeywordAutocomplete() {
  const input = document.getElementById('keywordInput');
  const autocomplete = document.getElementById('keywordAutocomplete');
  let debounceTimer = null;
  let currentSuggestions = [];

  if (!input || !autocomplete) return;

  document.addEventListener('click', (e) => {
    if (!input.contains(e.target) && !autocomplete.contains(e.target)) {
      autocomplete.style.display = 'none';
      currentSuggestions = [];
    }
  });

  input.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    const q = input.value.trim();
    if (q.length < 2) {
      autocomplete.style.display = 'none';
      currentSuggestions = [];
      return;
    }

    debounceTimer = setTimeout(async () => {
      try {
        const r = await fetch(`/api/tmdb/keywords?q=${encodeURIComponent(q)}`);
        if (r.status === 404) {
          autocomplete.innerHTML = `<div class="kw-item" style="color:var(--text-muted)">Datenbank wird noch geladen...</div>`;
          autocomplete.style.display = 'block';
          currentSuggestions = [];
          return;
        }
        const d = await r.json();

        if (d.results && d.results.length > 0) {
          currentSuggestions = d.results;
          autocomplete.innerHTML = '';
          d.results.forEach(kw => {
            const item = document.createElement('div');
            item.className = 'kw-item';
            item.textContent = kw.name;
            item.addEventListener('click', () => {
              addKeyword(kw);
              input.value = '';
              autocomplete.style.display = 'none';
              currentSuggestions = [];
            });
            autocomplete.appendChild(item);
          });
          autocomplete.style.display = 'block';
        } else {
          autocomplete.innerHTML = `<div class="kw-item" style="color:var(--text-muted)">Keine Ergebnisse</div>`;
          autocomplete.style.display = 'block';
          currentSuggestions = [];
        }
      } catch (e) {
        currentSuggestions = [];
      }
    }, 350);
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (autocomplete.style.display !== 'none' && currentSuggestions.length > 0) {
        addKeyword(currentSuggestions[0]);
        input.value = '';
        autocomplete.style.display = 'none';
        currentSuggestions = [];
      }
    }
  });

  input.addEventListener('focus', () => {
    if (autocomplete.children.length > 0 && input.value.trim().length >= 2) {
      autocomplete.style.display = 'block';
    }
  });
}

function addKeyword(kw) {
  if (selectedKeywords.find(k => k.id === kw.id)) return;
  selectedKeywords.push(kw);
  renderSelectedKeywords();
  saveAdvSearchState();
}

function removeKeyword(id) {
  selectedKeywords = selectedKeywords.filter(k => k.id !== id);
  renderSelectedKeywords();
  saveAdvSearchState();
}

function renderSelectedKeywords() {
  const container = document.getElementById('selectedKeywords');
  if (!container) return;
  container.innerHTML = '';
  selectedKeywords.forEach(kw => {
    const tag = document.createElement('div');
    tag.className = 'kw-tag';
    tag.innerHTML = `
      <span>${escapeHtml(kw.name)}</span>
      <span class="kw-tag-remove" onclick="removeKeyword(${kw.id})">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </span>
    `;
    container.appendChild(tag);
  });
}

function getGridColumns() {
  const grid = document.getElementById("resultsGrid");
  if (!grid) return 1;
  const cols = window.getComputedStyle(grid).getPropertyValue('grid-template-columns').split(' ').length;
  return Math.max(1, cols);
}

function getPageSize() {
  // 10 items, but fill up complete rows... I mean cmon...
  const cols = getGridColumns();
  const rows = Math.max(2, Math.ceil(10 / cols)); // At least 2 rows
  return cols * rows;
}

async function runSearch() {
  //search params
  lastSearchParams = new URLSearchParams();
  lastSearchParams.append("type", currentType);

  const voteMin = parseInt(document.getElementById("voteMin").value, 10);
  if (voteMin > 0) {
    lastSearchParams.append("vote_average.gte", voteMin);
  }

  const yearMin = document.getElementById("yearMin").value;
  if (yearMin) {
    if (currentType === 'tv') lastSearchParams.append("first_air_date.gte", `${yearMin}-01-01`);
    else lastSearchParams.append("primary_release_date.gte", `${yearMin}-01-01`);
  }

  const yearMax = document.getElementById("yearMax").value;
  if (yearMax) {
    if (currentType === 'tv') lastSearchParams.append("first_air_date.lte", `${yearMax}-12-31`);
    else lastSearchParams.append("primary_release_date.lte", `${yearMax}-12-31`);
  }

  const checkedGenres = Array.from(document.querySelectorAll('.genre-checkbox:checked')).map(cb => cb.value);
  if (checkedGenres.length > 0) {
    lastSearchParams.append("with_genres", checkedGenres.join(','));
  }

  if (selectedKeywords.length > 0) {
    lastSearchParams.append("with_keywords", selectedKeywords.map(k => k.id).join(','));
  }

  let sortBy = document.getElementById('sortBy').value || "popularity.desc";
  if (currentType === 'tv') {
    if (sortBy.startsWith("primary_release_date")) {
      sortBy = sortBy.replace("primary_release_date", "first_air_date");
    }
  } else {
    if (sortBy.startsWith("first_air_date")) {
      sortBy = sortBy.replace("first_air_date", "primary_release_date");
    }
  }
  lastSearchParams.append("sort_by", sortBy);

  lastSearchParams.append("language", "de-DE");
  lastSearchParams.append("include_adult", "false");

  // Show loading
  const grid = document.getElementById("resultsGrid");
  const countSpan = document.getElementById("resultsCount");
  grid.innerHTML = '<div class="skeleton-loader" style="grid-column: 1/-1; height: 300px; border-radius: 12px;"></div>';
  countSpan.textContent = "Lädt...";
  document.getElementById('advPagination').style.display = 'none';

  // Fetch first page
  let success = await fetchNextTmdbPage();
  if (success) {
    while (allLoadedResults.length < getPageSize() && allLoadedResults.length < totalTmdbResults) {
      const success = await fetchNextTmdbPage();
      if (!success) break;
    }
    renderLocalPage();
    saveAdvSearchState();
  } else {
    grid.innerHTML = `<div class="adv-empty-state" style="color:var(--error)">Netzwerkfehler bei der Suche.</div>`;
    countSpan.textContent = "Fehler";
  }
}

async function fetchNextTmdbPage() {
  if (!lastSearchParams) return false;
  if (activeFetchPromise) {
    return activeFetchPromise;
  }

  // Prevent fetching if we already reached total results
  if (currentTmdbPage > 0 && allLoadedResults.length >= totalTmdbResults) return true;

  isFetchingTmdb = true;
  const btn = document.getElementById("runSearchBtn");
  if (btn) btn.disabled = true;

  activeFetchPromise = (async () => {
    const searchParamsToUse = new URLSearchParams(lastSearchParams);
    const nextPage = currentTmdbPage + 1;
    searchParamsToUse.append("page", nextPage);

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);
      const r = await fetch(`/api/tmdb/discover?${searchParamsToUse.toString()}`, { signal: controller.signal });
      clearTimeout(timeoutId);

      const d = await r.json();
      if (d.error) throw new Error(d.error);

      totalTmdbResults = d.total_results || 0;
      const countSpan = document.getElementById("resultsCount");
      if (countSpan) countSpan.textContent = `${totalTmdbResults} Ergebnisse`;

      allLoadedResults.push(...(d.results || []));
      currentTmdbPage = nextPage;

      return true;
    } catch (e) {
      console.error("Error fetching TMDB page:", e);
      return false;
    } finally {
      isFetchingTmdb = false;
      if (btn) btn.disabled = false;
      activeFetchPromise = null;
    }
  })();

  return activeFetchPromise;
}

async function goToNextPage() {
  const pageSize = getPageSize();
  const maxPages = Math.ceil(totalTmdbResults / pageSize);
  if (currentPageIndex + 1 >= maxPages) return;

  currentPageIndex++;

  // Check if we have enough items loaded
  const requiredItems = (currentPageIndex + 1) * pageSize;
  if (allLoadedResults.length < requiredItems && allLoadedResults.length < totalTmdbResults) {
    const grid = document.getElementById("resultsGrid");
    grid.innerHTML = '<div class="skeleton-loader" style="grid-column: 1/-1; height: 300px; border-radius: 12px;"></div>';

    while (allLoadedResults.length < requiredItems && allLoadedResults.length < totalTmdbResults) {
      const success = await fetchNextTmdbPage();
      if (!success) break;
    }
  }

  renderLocalPage();
  saveAdvSearchState();
}

function goToPrevPage() {
  if (currentPageIndex > 0) {
    currentPageIndex--;
    renderLocalPage();
    saveAdvSearchState();
  }
}

function updatePaginationUI() {
  const pag = document.getElementById('advPagination');
  if (totalTmdbResults === 0) {
    pag.style.display = 'none';
    return;
  }
  pag.style.display = 'flex';

  const pageSize = getPageSize();
  const maxPages = Math.max(1, Math.ceil(totalTmdbResults / pageSize));

  document.getElementById('pageIndicator').textContent = `Seite ${currentPageIndex + 1} / ${maxPages}`;

  document.getElementById("prevPageBtn").disabled = (currentPageIndex === 0);
  document.getElementById("nextPageBtn").disabled = (currentPageIndex + 1 >= maxPages);
}

function renderLocalPage() {
  const grid = document.getElementById("resultsGrid");
  grid.innerHTML = '';

  const pageSize = getPageSize();
  const startIndex = currentPageIndex * pageSize;
  const pageResults = allLoadedResults.slice(startIndex, startIndex + pageSize);

  if (pageResults.length === 0) {
    if (totalTmdbResults === 0) {
      grid.innerHTML = `<div class="adv-empty-state">Keine Ergebnisse gefunden.</div>`;
    } else {
      grid.innerHTML = `<div class="adv-empty-state">Keine Ergebnisse auf dieser Seite.</div>`;
    }
    updatePaginationUI();
    return;
  }

  pageResults.forEach(r => {
    const title = r.title || r.name;
    const year = r.release_date ? r.release_date.split('-')[0] : (r.first_air_date ? r.first_air_date.split('-')[0] : '');

    const card = document.createElement('div');
    card.className = 'tmdb-card';
    card.dataset.tmdbId = r.id;

    card.onclick = () => {
      openAniSearchModal(title, r.id, currentType, r.poster_path);
    };

    let posterHtml = `<div class="tmdb-card-poster" style="display:flex;align-items:center;justify-content:center;color:var(--text-muted)">Kein Bild</div>`;
    if (r.poster_path) {
      const url = `https://image.tmdb.org/t/p/w342${r.poster_path}`;
      posterHtml = `<img class="tmdb-card-poster" src="${url}" loading="lazy" alt="Poster" />`;
    }

    const rating = r.vote_average ? parseFloat(r.vote_average).toFixed(1) : '-';

    const seasonsHtml = (currentType === 'tv') ? `<span class="tmdb-season-info" style="opacity: 0.5;">...</span>` : '';

    card.innerHTML = `
      ${posterHtml}
      <div class="tmdb-card-info">
        <h4 class="tmdb-card-title" title="${escapeHtml(title)}">${escapeHtml(title)}</h4>
        <div class="tmdb-card-meta">
          <span class="tmdb-rating">
            <svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path></svg>
            ${rating}
          </span>
        </div>
        <div class="tmdb-card-meta">
          ${year ? `<span>${year}</span>` : ''}
          ${seasonsHtml ? `<span>• ${seasonsHtml}</span>` : ''}
        </div>
        <div class="tmdb-card-desc">${escapeHtml(r.overview || 'Keine Beschreibung verfügbar.')}</div>
        <div class="tmdb-card-desc-hover">
          <h4 class="tmdb-card-title-hover">${escapeHtml(title)}</h4>
          <div class="tmdb-card-desc-text-hover">${escapeHtml(r.overview || 'Keine Beschreibung verfügbar.')}</div>
        </div>
      </div>
    `;

    grid.appendChild(card);

    if (currentType === 'tv') {
      fetchSeasonsInfo(r.id, card);
    }
  });

  updatePaginationUI();

  // Pre-fetch next TMDB page immediately if we might need it soon
  ensureBuffer();
}

async function ensureBuffer() {
  const pageSize = getPageSize();
  const requiredNextItems = (currentPageIndex + 2) * pageSize;

  let didFetch = false;
  while (allLoadedResults.length < requiredNextItems && allLoadedResults.length < totalTmdbResults && !isFetchingTmdb) {
    const success = await fetchNextTmdbPage();
    if (!success) break;
    didFetch = true;
  }
  if (didFetch) {
    saveAdvSearchState();
  }
}

async function fetchSeasonsInfo(id, cardElement) {
  try {
    const r = await fetch(`/api/tmdb/details?id=${id}&type=tv`);
    const d = await r.json();
    const infoSpan = cardElement.querySelector('.tmdb-season-info');
    if (infoSpan) {
      if (d.number_of_seasons !== undefined) {
        infoSpan.textContent = `${d.number_of_seasons} Staffel${d.number_of_seasons !== 1 ? 'n' : ''}`;
        infoSpan.style.opacity = '1';
      } else {
        infoSpan.textContent = 'Unbekannt';
        infoSpan.style.opacity = '1';
      }
    }
  } catch (e) {
    const infoSpan = cardElement.querySelector('.tmdb-season-info');
    if (infoSpan) infoSpan.textContent = '';
  }
}

// ---- AniWorld Search Modal Logic ----

function openAniSearchModal(title, tmdbId, type, posterPath) {
  const modal = document.getElementById('aniSearchModalOverlay');
  if (!modal) return;
  modal.style.display = 'flex';
  document.body.style.overflow = 'hidden';

  const cleanTitle = title.trim().replace(/!+$/, "");
  document.getElementById('aniSearchTitle').textContent = `Suche nach "${cleanTitle}"...`;
  document.getElementById('aniSearchSpinner').style.display = 'block';
  document.getElementById('aniSearchResults').innerHTML = '';

  runAniSearch(cleanTitle, tmdbId, type, posterPath);
}

function closeAniSearchModal() {
  const modal = document.getElementById('aniSearchModalOverlay');
  if (modal) {
    modal.style.display = 'none';
    document.body.style.overflow = '';
  }
}

function closeAniSearchModalOutside(event) {
  const modalContent = document.getElementById('aniSearchModal');
  if (modalContent && !modalContent.contains(event.target)) {
    closeAniSearchModal();
  }
}

window.openAniSearchModal = openAniSearchModal;
window.closeAniSearchModal = closeAniSearchModal;
window.closeAniSearchModalOutside = closeAniSearchModalOutside;

async function runAniSearch(primaryTitle, tmdbId, type, posterPath) {
  const grid = document.getElementById('aniSearchResults');
  primaryTitle = primaryTitle.trim().replace(/!+$/, ""); // removes ! at the end of the title
  grid.innerHTML = '<div class="skeleton-loader" style="grid-column: 1/-1; height: 150px; border-radius: 12px;"></div>';

  let searchTitles = [primaryTitle];

  try {
    if (tmdbId && type) {
      const detailRes = await fetch(`/api/tmdb/details?id=${tmdbId}&type=${type}`);
      const detailData = await detailRes.json();

      if (detailData.translations && detailData.translations.translations) {
        const enTrans = detailData.translations.translations.find(t => t.iso_639_1 === 'en');
        if (enTrans && enTrans.data && enTrans.data.name) {
          const enTitle = enTrans.data.name.trim().replace(/!+$/, "");
          if (enTitle.toLowerCase() !== primaryTitle.toLowerCase()) {
            searchTitles.push(enTitle);
          }
        }
      }
    }
  } catch (e) {
    // Ignore translation fetch error
  }

  const searchSite = async (site, kw) => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);
    try {
      const resp = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ keyword: kw, site }),
        signal: controller.signal
      });
      const data = await resp.json();
      return data.results || [];
    } catch (e) {
      return [];
    } finally {
      clearTimeout(timeoutId);
    }
  };

  try {
    let allPromises = [];
    searchTitles.forEach(kw => {
      allPromises.push(searchSite("aniworld", kw));
      allPromises.push(searchSite("sto", kw));
      allPromises.push(searchSite("filmpalast", kw));
    });

    const resultsArrays = await Promise.all(allPromises.map(p => p.catch(() => [])));

    document.getElementById('aniSearchSpinner').style.display = 'none';

    let displayTitle = primaryTitle;
    if (searchTitles.length > 1) {
      displayTitle += ` / ${searchTitles[1]}`;
    }
    document.getElementById('aniSearchTitle').textContent = `Ergebnisse für "${displayTitle}"`;
    grid.innerHTML = '';

    let allResults = [];
    resultsArrays.forEach(arr => {
      allResults = allResults.concat(arr);
    });

    // Deduplicate by URL
    const seenUrls = new Set();
    allResults = allResults.filter(r => {
      if (seenUrls.has(r.url)) return false;
      seenUrls.add(r.url);
      return true;
    });

    // HARD FILTER: Only keep results where title contains ANY of our keywords, or keyword contains title
    allResults = allResults.filter(r => {
      if (!r.title) return false;
      const t = r.title.toLowerCase();

      return searchTitles.some(kw => {
        const k = kw.toLowerCase();
        return t.includes(k) || k.includes(t);
      });
    });

    if (allResults.length === 0) {
      grid.innerHTML = `<div class="adv-empty-state">Keine exakten Treffer für "${escapeHtml(displayTitle)}" auf AniWorld, S.to oder FilmPalast gefunden.</div>`;
      return;
    }

    allResults.forEach(r => {
      const card = document.createElement('div');
      card.className = 'browse-card';
      card.style.cursor = 'pointer';

      // Determine provider styling
      let provClass = '';
      if (r.url.includes('aniworld.to')) provClass = 'prov-ani';
      if (r.url.includes('s.to')) provClass = 'prov-sto';
      if (r.url.includes('filmpalast.to')) provClass = 'prov-fp';

      card.innerHTML = `
        <img src="" loading="lazy" alt="Cover" style="width:100%;aspect-ratio:2/3;object-fit:cover;background:var(--bg-elevated);display:block" />
        <div class="browse-info">
          <div class="browse-title" title="${escapeHtml(r.title)}">${escapeHtml(r.title)}</div>
          <div class="browse-provider ${provClass}">${provClass === 'prov-ani' ? 'AniWorld' : provClass === 'prov-sto' ? 'S.to' : 'FilmPalast'}</div>
        </div>
      `;

      card.onclick = () => {
        closeAniSearchModal();
        openSeries(r.url);
      };

      grid.appendChild(card);

      // Always fetch poster from the source site (like the normal search does)
      advLoadPoster(r.url, card.querySelector('img'));
    });

  } catch (e) {
    document.getElementById('aniSearchSpinner').style.display = 'none';
    grid.innerHTML = `<div class="adv-empty-state" style="color:var(--error)">Fehler bei der Suche.</div>`;
  }
}

async function advLoadPoster(url, imgEl) {
  try {
    const resp = await fetch("/api/series?url=" + encodeURIComponent(url));
    const data = await resp.json();
    if (data.poster_url) {
      imgEl.src = (typeof proxyImg === 'function' ? proxyImg(data.poster_url) : data.poster_url);
      imgEl.onload = () => {
        const card = imgEl.closest('.browse-card');
        if (card) card.classList.add('loaded');
      };
      imgEl.onerror = () => {
        const card = imgEl.closest('.browse-card');
        if (card) card.classList.add('loaded');
        imgEl.style.display = 'none';
      };
    } else {
      const card = imgEl.closest('.browse-card');
      if (card) card.classList.add('loaded');
      imgEl.style.display = 'none';
    }
  } catch (e) {
    const card = imgEl.closest('.browse-card');
    if (card) card.classList.add('loaded');
    imgEl.style.display = 'none';
  }
}

function escapeHtml(unsafe) {
  if (!unsafe) return '';
  return (unsafe + '').replace(/[&<"']/g, function (m) {
    switch (m) {
      case '&': return '&amp;';
      case '<': return '&lt;';
      case '"': return '&quot;';
      case "'": return '&#039;';
    }
  });
}

