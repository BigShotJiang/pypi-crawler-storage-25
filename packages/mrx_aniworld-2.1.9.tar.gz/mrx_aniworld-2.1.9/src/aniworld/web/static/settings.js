// ─── Tab navigation ────────────────────────────────────────────────────────

function switchTab(name) {
  document.querySelectorAll(".settings-tab-btn, .settings-tab").forEach(function (btn) {
    btn.classList.toggle("active", btn.dataset.tab === name);
  });
  document.querySelectorAll(".settings-tab-panel").forEach(function (panel) {
    panel.classList.toggle("active", panel.id === "tab-" + name);
  });
  // Sync sidebar sub-links
  document.querySelectorAll(".sidebar-sub-link[data-settings-tab]").forEach(function (a) {
    a.classList.toggle("active", a.dataset.settingsTab === name);
  });
  // Update URL hash without scrolling
  try {
    history.replaceState(null, "", "#" + name);
    localStorage.setItem("settingsActiveTab", name);
  } catch (e) { }
}

(function restoreTab() {
  var hash = "";
  try { hash = (window.location.hash || "").replace("#", "").trim(); } catch (e) { }
  var validTabs = ["general", "downloads", "autosync", "network", "auth", "api", "updates"];
  var tab = (hash && validTabs.indexOf(hash) !== -1) ? hash : "";
  if (!tab) {
    try { tab = localStorage.getItem("settingsActiveTab") || "downloads"; } catch (e) { tab = "downloads"; }
  }
  if (validTabs.indexOf(tab) === -1) tab = "downloads";
  switchTab(tab);
})();

// ─── Element references ─────────────────────────────────────────────────────

const downloadPathInput = document.getElementById("downloadPath");
const langSeparationCb = document.getElementById("langSeparation");
const disableEnglishSubCb = document.getElementById("disableEnglishSub");
const filmpalastSubfolderCb = document.getElementById("filmpalastSubfolder");
const syncScheduleSelect         = document.getElementById("syncSchedule");
const syncLanguageSelect         = document.getElementById("syncLanguage");
const syncProviderSelect         = document.getElementById("syncProvider");
const syncPathUnavailableSelect  = document.getElementById("syncPathUnavailableAction");

// ─── Load all settings ──────────────────────────────────────────────────────

async function loadSettings() {
  try {
    const resp = await fetch("/api/settings?_=" + Date.now()); //Prohibit Browser Caching because of "new URL"(Yes there was in issue during development)
    const data = await resp.json();

    // Downloads tab
    if (downloadPathInput) downloadPathInput.value = data.download_path || "";
    if (langSeparationCb) langSeparationCb.checked = data.lang_separation === "1";
    if (disableEnglishSubCb) disableEnglishSubCb.checked = data.disable_english_sub === "1";
    if (filmpalastSubfolderCb) filmpalastSubfolderCb.checked = data.filmpalast_movie_subfolder === "1";

    const dlLangEl = document.getElementById("downloadLanguage");
    if (dlLangEl && data.download_language) dlLangEl.value = data.download_language;

    const dlProvEl = document.getElementById("downloadProvider");
    if (dlProvEl && data.download_provider) dlProvEl.value = data.download_provider;

    const nmTplEl = document.getElementById("namingTemplate");
    if (nmTplEl) nmTplEl.value = data.naming_template || "{title} - S{season:02d}E{episode:02d}";

    // Auto-Sync tab
    if (syncScheduleSelect && data.sync_schedule) syncScheduleSelect.value = data.sync_schedule;

    const isLangSep = data.lang_separation === "1";
    let currentSyncLang = data.sync_language;
    if (currentSyncLang === "All Languages" && !isLangSep) currentSyncLang = "German Dub";
    updateSyncLanguageDropdown(isLangSep, currentSyncLang);
    if (syncProviderSelect && data.sync_provider) syncProviderSelect.value = data.sync_provider;
    if (syncPathUnavailableSelect && data.sync_path_unavailable_action) syncPathUnavailableSelect.value = data.sync_path_unavailable_action;
    const syncErrorRetriesEl = document.getElementById("syncErrorRetries");
    if (syncErrorRetriesEl && data.sync_error_retries !== undefined) syncErrorRetriesEl.value = data.sync_error_retries;
    const syncErrorRetryTimeEl = document.getElementById("syncErrorRetryTime");
    if (syncErrorRetryTimeEl && data.sync_error_retry_time) syncErrorRetryTimeEl.value = data.sync_error_retry_time;

    // Netzwerk tab
    const dnsModeEl = document.getElementById("dnsMode");
    const dnsServerEl = document.getElementById("dnsServer");
    if (dnsModeEl) { dnsModeEl.value = data.dns_mode || "system"; onDnsModeChange(); }
    if (dnsServerEl) dnsServerEl.value = data.dns_server || "";

    const webBaseUrlEl = document.getElementById("webBaseUrl");
    if (webBaseUrlEl) webBaseUrlEl.value = data.web_base_url || "";

    const debugModeEl = document.getElementById("debugMode");
    if (debugModeEl) debugModeEl.checked = data.debug_mode === "1";

    // Design tab - Extended Settings
    _loadDesignCheckboxes();

  } catch (e) {
    showToast("Einstellungen konnten nicht geladen werden: " + e.message);
  }
  loadApiKey();
  loadSsoSettings();
}

// ─── Downloads tab ──────────────────────────────────────────────────────────

async function saveLangSeparation() {
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        download_path: downloadPathInput ? downloadPathInput.value.trim() : undefined,
        lang_separation: langSeparationCb ? langSeparationCb.checked : false,
      }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    showToast("Sprachentrennung " + (langSeparationCb && langSeparationCb.checked ? "aktiviert" : "deaktiviert"));
    const isLangSep = langSeparationCb ? langSeparationCb.checked : false;
    let currentSyncLang = syncLanguageSelect ? syncLanguageSelect.value : null;
    if (!isLangSep && currentSyncLang === "All Languages") {
      currentSyncLang = "German Dub";
      updateSyncLanguageDropdown(false, currentSyncLang);
      saveSyncDefaults();
    } else {
      updateSyncLanguageDropdown(isLangSep, currentSyncLang);
    }
  } catch (e) {
    showToast("Einstellung konnte nicht gespeichert werden: " + e.message);
  }
}

function updateSyncLanguageDropdown(isLangSep, currentValue) {
  if (!syncLanguageSelect) return;
  syncLanguageSelect.innerHTML = "";
  if (isLangSep) {
    const opt = document.createElement("option");
    opt.value = "All Languages";
    opt.textContent = "Alle Sprachen";
    syncLanguageSelect.appendChild(opt);
  }
  ["German Dub", "English Sub", "German Sub"].forEach(function (l) {
    const opt = document.createElement("option");
    opt.value = l;
    opt.textContent = l;
    syncLanguageSelect.appendChild(opt);
  });
  if (currentValue) syncLanguageSelect.value = currentValue;
}

async function saveDisableEnglishSub() {
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ disable_english_sub: disableEnglishSubCb ? disableEnglishSubCb.checked : false }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    showToast("Englische Untertitel-Downloads " +
      (disableEnglishSubCb && disableEnglishSubCb.checked ? "deaktiviert" : "aktiviert"));
  } catch (e) {
    showToast("Einstellung konnte nicht gespeichert werden: " + e.message);
  }
}

async function saveFilmpalastSubfolder() {
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filmpalast_movie_subfolder: filmpalastSubfolderCb ? filmpalastSubfolderCb.checked : false }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    showToast("Film-Unterordner " + (filmpalastSubfolderCb && filmpalastSubfolderCb.checked ? "aktiviert" : "deaktiviert"));
  } catch (e) {
    showToast("Einstellung konnte nicht gespeichert werden: " + e.message);
  }
}

async function saveDownloadPath() {
  const download_path = downloadPathInput ? downloadPathInput.value.trim() : "";
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ download_path }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    showToast("Download-Pfad gespeichert");
  } catch (e) {
    showToast("Einstellungen konnten nicht gespeichert werden: " + e.message);
  }
}

async function saveDownloadLanguage() {
  const el = document.getElementById("downloadLanguage");
  if (!el) return;
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ download_language: el.value }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    showToast("Standardsprache gespeichert");
  } catch (e) {
    showToast("Einstellung konnte nicht gespeichert werden: " + e.message);
  }
}

async function saveDownloadProvider() {
  const el = document.getElementById("downloadProvider");
  if (!el) return;
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ download_provider: el.value }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    showToast("Standardanbieter gespeichert");
  } catch (e) {
    showToast("Einstellung konnte nicht gespeichert werden: " + e.message);
  }
}

async function saveNamingTemplate() {
  const el = document.getElementById("namingTemplate");
  if (!el) return;
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ naming_template: el.value.trim() }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    showToast("Namens-Template gespeichert");
  } catch (e) {
    showToast("Einstellung konnte nicht gespeichert werden: " + e.message);
  }
}

function resetNamingTemplate() {
  const el = document.getElementById("namingTemplate");
  if (el) el.value = "{title} - S{season:02d}E{episode:02d}";
  saveNamingTemplate();
}

// ─── Auto-Sync tab ──────────────────────────────────────────────────────────

async function saveSyncSchedule() {
  if (!syncScheduleSelect) return;
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sync_schedule: syncScheduleSelect.value }),
    });
    const data = await resp.json();
    if (data.ok) showToast("Auto-Sync-Zeitplan gespeichert");
    else showToast("Zeitplan konnte nicht gespeichert werden");
  } catch (e) {
    showToast("Zeitplan konnte nicht gespeichert werden: " + e.message);
  }
}

async function saveSyncDefaults() {
  const body = {};
  if (syncLanguageSelect) body.sync_language = syncLanguageSelect.value;
  if (syncProviderSelect) body.sync_provider = syncProviderSelect.value;
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await resp.json();
    if (data.ok) showToast("Auto-Sync-Standards gespeichert");
    else showToast("Standards konnten nicht gespeichert werden");
  } catch (e) {
    showToast("Standards konnten nicht gespeichert werden: " + e.message);
  }
}

async function saveSyncPathAction() {
  if (!syncPathUnavailableSelect) return;
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sync_path_unavailable_action: syncPathUnavailableSelect.value }),
    });
    const data = await resp.json();
    if (data.ok) showToast("Pfad-offline-Verhalten gespeichert");
    else showToast(data.error || "Konnte nicht gespeichert werden");
  } catch (e) {
    showToast("Konnte nicht gespeichert werden: " + e.message);
  }
}

async function saveSyncErrorRetries() {
  const el = document.getElementById("syncErrorRetries");
  if (!el) return;
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sync_error_retries: parseInt(el.value, 10) }),
    });
    const data = await resp.json();
    if (data.ok) showToast("Fehler-Wiederholungen gespeichert");
    else showToast(data.error || "Konnte nicht gespeichert werden");
  } catch (e) {
    showToast("Konnte nicht gespeichert werden: " + e.message);
  }
}

async function saveSyncErrorRetryTime() {
  const el = document.getElementById("syncErrorRetryTime");
  if (!el) return;
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sync_error_retry_time: el.value }),
    });
    const data = await resp.json();
    if (data.ok) showToast("Wiederholungs-Zeit gespeichert");
    else showToast(data.error || "Konnte nicht gespeichert werden");
  } catch (e) {
    showToast("Konnte nicht gespeichert werden: " + e.message);
  }
}

// ─── Netzwerk tab ───────────────────────────────────────────────────────────

async function saveWebBaseUrl() {
  const el = document.getElementById("webBaseUrl");
  if (!el) return;
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ web_base_url: el.value.trim() }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    showToast("Basis-URL gespeichert — Neustart erforderlich");
  } catch (e) {
    showToast("Einstellung konnte nicht gespeichert werden: " + e.message);
  }
}

async function saveDebugMode() {
  const el = document.getElementById("debugMode");
  if (!el) return;
  try {
    const resp = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ debug_mode: el.checked }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    showToast("Debug-Modus " + (el.checked ? "aktiviert" : "deaktiviert"));
  } catch (e) {
    showToast("Einstellung konnte nicht gespeichert werden: " + e.message);
  }
}


// ─── DNS ────────────────────────────────────────────────────────────────────

function dnsTestAppendErrorBtn(container, errorText) {
  const btn = document.createElement("button");
  btn.className = "dns-test-err-btn";
  btn.textContent = "Fehler anzeigen";
  btn.onclick = function () {
    const existing = container.querySelector(".dns-test-err-detail");
    if (existing) {
      existing.remove();
      btn.textContent = "Fehler anzeigen";
    } else {
      const detail = document.createElement("div");
      detail.className = "dns-test-err-detail";
      detail.textContent = errorText;
      container.appendChild(detail);
      btn.textContent = "Fehler ausblenden";
    }
  };
  container.appendChild(btn);
}

function toggleDnsTestPanel() {
  const panel = document.getElementById("dnsTestPanel");
  if (!panel) return;
  const opening = panel.style.display === "none";
  panel.style.display = opening ? "block" : "none";
  if (opening) runDnsTest();
}

async function runDnsTest() {
  const btn = document.getElementById("dnsTestRunBtn");
  const statusEl = document.getElementById("dnsTestStatus");
  if (btn) { btn.disabled = true; btn.textContent = "⏳ Teste…"; }
  if (statusEl) statusEl.innerHTML = '<span class="dns-test-loading">⏳ Lädt…</span>';
  for (const id of ["dnsTestRowAniWorld", "dnsTestRowSTO", "dnsTestRowFilmpalast"]) {
    const row = document.getElementById(id);
    if (row) {
      const res = row.querySelector(".dns-test-site-result");
      if (res) { res.className = "dns-test-site-result dns-test-loading"; res.textContent = "⏳ Teste…"; }
    }
  }
  try {
    const resp = await fetch("/api/settings/dns/test");
    const data = await resp.json();
    if (statusEl) {
      const mode = data.dns_mode || "system";
      const active = data.dns_active_server;
      const modeLabel = { system: "System-DNS", cloudflare: "Cloudflare (1.1.1.1)", google: "Google (8.8.8.8)", quad9: "Quad9 (9.9.9.9)", custom: "Benutzerdefiniert" }[mode] || mode;
      if (mode === "system") {
        statusEl.innerHTML = '<span class="dns-test-ok">✓ System-DNS aktiv (kein eigener DNS konfiguriert)</span>';
      } else if (active) {
        statusEl.innerHTML = '<span class="dns-test-ok">✓ ' + modeLabel + ' aktiv — Server: ' + active + '</span>';
      } else {
        statusEl.innerHTML = '<span class="dns-test-warn">⚠ Gespeicherter Modus: ' + modeLabel + ' — aber kein Server aktiv. Einstellungen erneut speichern?</span>';
      }
    }
    const siteMap = { AniWorld: "dnsTestRowAniWorld", "S.TO": "dnsTestRowSTO", FilmPalast: "dnsTestRowFilmpalast" };
    for (const [label, rowId] of Object.entries(siteMap)) {
      const row = document.getElementById(rowId);
      if (!row) continue;
      const resEl = row.querySelector(".dns-test-site-result");
      if (!resEl) continue;
      const site = data.sites?.[label];
      if (!site) { resEl.className = "dns-test-site-result dns-test-warn"; resEl.textContent = "— Keine Daten"; continue; }
      const ip = site.ip ? " (" + site.ip + ")" : "";
      resEl.innerHTML = "";
      const txt = document.createElement("span");
      resEl.appendChild(txt);
      if (site.http_ok && site.site_verified) {
        resEl.className = "dns-test-site-result dns-test-ok";
        txt.textContent = "✓ Erreichbar & verifiziert" + ip;
      } else if (site.http_ok && !site.site_verified) {
        resEl.className = "dns-test-site-result dns-test-warn";
        txt.textContent = "⚠ Erreichbar" + ip + ", aber Inhalt unbekannt — möglicherweise Sperr-Seite";
      } else if (site.socket_ok) {
        resEl.className = "dns-test-site-result dns-test-warn";
        txt.textContent = "⚠ DNS aufgelöst" + ip + ", aber HTTP fehlgeschlagen";
        if (site.http_error) dnsTestAppendErrorBtn(resEl, site.http_error);
      } else {
        resEl.className = "dns-test-site-result dns-test-fail";
        txt.textContent = "✗ Nicht erreichbar";
        const errMsg = site.socket_error || site.http_error;
        if (errMsg) dnsTestAppendErrorBtn(resEl, errMsg);
      }
    }
  } catch (e) {
    if (statusEl) statusEl.innerHTML = '<span class="dns-test-fail">✗ Fehler: ' + e.message + '</span>';
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "↺ Erneut testen"; }
  }
}

function onDnsModeChange() {
  const mode = document.getElementById("dnsMode")?.value;
  const field = document.getElementById("dnsCustomField");
  const statusEl = document.getElementById("dnsStatus");
  if (field) field.style.display = mode === "custom" ? "" : "none";
  if (statusEl) statusEl.style.display = "none";
}

async function saveDnsSettings() {
  const mode = document.getElementById("dnsMode")?.value || "system";
  const server = (document.getElementById("dnsServer")?.value || "").trim();
  if (mode === "custom" && !server) { showToast("Bitte einen DNS-Server eingeben", "warning"); return; }
  try {
    const resp = await fetch("/api/settings/dns", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dns_mode: mode, dns_server: server }),
    });
    const data = await resp.json();
    if (data.ok) {
      const modeLabel = { system: "System-DNS", cloudflare: "Cloudflare (1.1.1.1)", google: "Google (8.8.8.8)", quad9: "Quad9 (9.9.9.9)", custom: "Benutzerdefiniert" }[mode] || mode;
      showToast(mode === "system" ? "DNS zurückgesetzt — System-DNS aktiv" : "DNS gespeichert — " + modeLabel + " aktiv", "success");
    } else {
      showToast(data.error || "Fehler beim Speichern", "error");
    }
  } catch (e) {
    showToast("Fehler: " + e.message, "error");
  }
}

// ─── SSO / Authentifizierung tab ────────────────────────────────────────────

async function loadSsoSettings() {
  try {
    const resp = await fetch("/api/settings/sso");
    if (!resp.ok) return;
    const data = await resp.json();

    const ssoEl = document.getElementById("ssoEnabled");
    const forceSsoEl = document.getElementById("forceSso");
    const issuerEl = document.getElementById("oidcIssuerUrl");
    const clientIdEl = document.getElementById("oidcClientId");
    const secretEl = document.getElementById("oidcClientSecret");
    const displayEl = document.getElementById("oidcDisplayName");
    const adminUsEl = document.getElementById("oidcAdminUser");
    const adminSubEl = document.getElementById("oidcAdminSubject");

    if (ssoEl) ssoEl.checked = data.sso_enabled === true || data.sso_enabled === "1";
    if (forceSsoEl) forceSsoEl.checked = data.force_sso === true || data.force_sso === "1";
    if (issuerEl) issuerEl.value = data.oidc_issuer_url || "";
    if (clientIdEl) clientIdEl.value = data.oidc_client_id || "";
    if (secretEl) secretEl.value = data.oidc_client_secret || "";
    if (displayEl) displayEl.value = data.oidc_display_name || "";
    if (adminUsEl) adminUsEl.value = data.oidc_admin_user || "";
    if (adminSubEl) adminSubEl.value = data.oidc_admin_subject || "";

    onSsoToggle();
  } catch (e) {
    // non-critical, SSO may not be configured
  }
}

function onSsoToggle() {
  const ssoEl = document.getElementById("ssoEnabled");
  const ssoFields = document.getElementById("ssoFields");
  if (!ssoFields) return;
  ssoFields.style.display = (ssoEl && ssoEl.checked) ? "" : "none";
}

async function saveSsoSettings() {
  const ssoEl = document.getElementById("ssoEnabled");
  const forceSsoEl = document.getElementById("forceSso");
  const issuerEl = document.getElementById("oidcIssuerUrl");
  const clientIdEl = document.getElementById("oidcClientId");
  const secretEl = document.getElementById("oidcClientSecret");
  const displayEl = document.getElementById("oidcDisplayName");
  const adminUsEl = document.getElementById("oidcAdminUser");
  const adminSubEl = document.getElementById("oidcAdminSubject");

  const body = {
    sso_enabled: ssoEl ? ssoEl.checked : false,
    force_sso: forceSsoEl ? forceSsoEl.checked : false,
    oidc_issuer_url: issuerEl ? issuerEl.value.trim() : "",
    oidc_client_id: clientIdEl ? clientIdEl.value.trim() : "",
    oidc_display_name: displayEl ? displayEl.value.trim() : "",
    oidc_admin_user: adminUsEl ? adminUsEl.value.trim() : "",
    oidc_admin_subject: adminSubEl ? adminSubEl.value.trim() : "",
  };
  // Only include secret if user actually typed something (not the masked placeholder)
  if (secretEl && secretEl.value && secretEl.value !== "***") {
    body.oidc_client_secret = secretEl.value;
  }

  try {
    const resp = await fetch("/api/settings/sso", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error, "error"); return; }
    showToast("SSO-Einstellungen gespeichert — Neustart erforderlich");
  } catch (e) {
    showToast("SSO-Einstellungen konnten nicht gespeichert werden: " + e.message, "error");
  }
}

// ─── Custom paths ────────────────────────────────────────────────────────────

const customPathsBody = document.getElementById("customPathsBody");
const customPathsTable = document.getElementById("customPathsTable");

if (customPathsBody) loadCustomPaths();

async function loadCustomPaths() {
  if (!customPathsBody) return;
  try {
    const resp = await fetch("/api/custom-paths");
    const data = await resp.json();
    renderCustomPaths(data.paths || []);
  } catch (e) {
    showToast("Benutzerdefinierte Pfade konnten nicht geladen werden: " + e.message);
  }
}

function renderCustomPaths(paths) {
  customPathsBody.innerHTML = "";
  if (!paths.length) {
    const tr = document.createElement("tr");
    tr.innerHTML = '<td colspan="3" style="color:#6b7280;text-align:center">Keine benutzerdefinierten Pfade</td>';
    customPathsBody.appendChild(tr);
    return;
  }
  paths.forEach(function (p) {
    const tr = document.createElement("tr");
    const delCell = (typeof settingsCanEdit !== "undefined" && settingsCanEdit)
      ? '<td><button class="btn-del" onclick="deleteCustomPath(' + p.id + ')">Löschen</button></td>'
      : '<td></td>';
    tr.innerHTML =
      "<td>" + esc(p.name) + "</td>" +
      "<td style=\"font-family:'SF Mono','Fira Code',monospace;font-size:.82rem\">" + esc(p.path) + "</td>" +
      delCell;
    customPathsBody.appendChild(tr);
  });
}

async function addCustomPath() {
  const name = document.getElementById("newPathName").value.trim();
  const path = document.getElementById("newPathValue").value.trim();
  if (!name || !path) { showToast("Name und Pfad sind erforderlich"); return; }
  try {
    const resp = await fetch("/api/custom-paths", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, path }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    document.getElementById("newPathName").value = "";
    document.getElementById("newPathValue").value = "";
    showToast("Benutzerdefinierter Pfad hinzugefügt");
    loadCustomPaths();
  } catch (e) {
    showToast("Benutzerdefinierter Pfad konnte nicht hinzugefügt werden: " + e.message);
  }
}

async function deleteCustomPath(id) {
  if (!await showConfirm("Diesen benutzerdefinierten Pfad löschen?")) return;
  try {
    const resp = await fetch("/api/custom-paths/" + id, { method: "DELETE" });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    showToast("Benutzerdefinierter Pfad gelöscht");
    loadCustomPaths();
  } catch (e) {
    showToast("Benutzerdefinierter Pfad konnte nicht gelöscht werden: " + e.message);
  }
}

// ─── User management ─────────────────────────────────────────────────────────

const userTableBody = document.getElementById("userTableBody");
if (userTableBody) loadUsers();

async function loadUsers() {
  if (!userTableBody) return;
  try {
    const resp = await fetch("/admin/api/users");
    const data = await resp.json();
    renderUsers(data.users || []);
  } catch (e) {
    showToast("Benutzer konnten nicht geladen werden: " + e.message);
  }
}

function renderUsers(users) {
  const adminCount = users.filter(function (u) { return u.role === "admin"; }).length;
  userTableBody.innerHTML = "";
  users.forEach(function (u) {
    const isLastAdmin = u.role === "admin" && adminCount <= 1;
    const tr = document.createElement("tr");
    const authMethod = u.auth_method || "local";
    const authBadge = authMethod === "oidc"
      ? '<span class="auth-badge auth-sso">SSO</span>'
      : '<span class="auth-badge auth-local">Lokal</span>';
    tr.innerHTML =
      "<td>" + u.id + "</td>" +
      "<td>" + esc(u.username) + "</td>" +
      "<td><select onchange=\"changeRole(" + u.id + ", this.value)\" " + (isLastAdmin ? "disabled" : "") + ">" +
      "<option value=\"user\" " + (u.role === "user" ? "selected" : "") + ">Benutzer</option>" +
      "<option value=\"admin\" " + (u.role === "admin" ? "selected" : "") + ">Administrator</option>" +
      "</select></td>" +
      "<td>" + authBadge + "</td>" +
      "<td>" + esc(u.created_at) + "</td>" +
      "<td>" + (isLastAdmin
        ? '<span style="color:#555">geschützt</span>'
        : '<button class="btn-del" onclick="deleteUser(' + u.id + ')">Löschen</button>') + "</td>";
    userTableBody.appendChild(tr);
  });
}

async function addUser() {
  const username = document.getElementById("newUsername").value.trim();
  const password = document.getElementById("newPassword").value;
  const role = document.getElementById("newRole").value;
  if (!username || !password) { showToast("Benutzername und Passwort sind erforderlich"); return; }
  try {
    const resp = await fetch("/admin/api/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password, role }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    document.getElementById("newUsername").value = "";
    document.getElementById("newPassword").value = "";
    showToast("Benutzer erstellt");
    loadUsers();
  } catch (e) {
    showToast("Benutzer konnte nicht erstellt werden: " + e.message);
  }
}

async function deleteUser(id) {
  if (!await showConfirm("Diesen Benutzer löschen?")) return;
  try {
    const resp = await fetch("/admin/api/users/" + id, { method: "DELETE" });
    const data = await resp.json();
    if (data.error) { showToast(data.error); return; }
    showToast("Benutzer gelöscht");
    loadUsers();
  } catch (e) {
    showToast("Benutzer konnte nicht gelöscht werden: " + e.message);
  }
}

async function changeRole(id, newRole) {
  try {
    const resp = await fetch("/admin/api/users/" + id + "/role", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ role: newRole }),
    });
    const data = await resp.json();
    if (data.error) { showToast(data.error); loadUsers(); return; }
    showToast("Rolle aktualisiert");
    loadUsers();
  } catch (e) {
    showToast("Rolle konnte nicht aktualisiert werden: " + e.message);
  }
}

// ─── External API key ─────────────────────────────────────────────────────────

async function loadApiKey() {
  try {
    const resp = await fetch("/api/settings/api-key");
    const data = await resp.json();
    const el = document.getElementById("externalApiKeyDisplay");
    if (el) el.value = data.key || "";
    const baseUrl = window.location.origin;
    const baseEl = document.getElementById("apiBaseUrlDisplay");
    const exEl = document.getElementById("apiExampleUrl");
    if (baseEl) baseEl.textContent = baseUrl;
    if (exEl) exEl.textContent = baseUrl + "/api/v1/status?apikey=****";
  } catch (e) { /* non-critical */ }
}

function toggleApiKeyVisibility() {
  const el = document.getElementById("externalApiKeyDisplay");
  const btn = document.getElementById("apiKeyToggleBtn");
  if (!el) return;
  const visible = el.type === "text";
  el.type = visible ? "password" : "text";
  btn.textContent = visible ? "Anzeigen" : "Verbergen";
}

async function copyApiKey() {
  const el = document.getElementById("externalApiKeyDisplay");
  if (!el || !el.value) return;
  try {
    await navigator.clipboard.writeText(el.value);
    showToast("API-Key kopiert", "success");
  } catch (e) {
    showToast("Kopieren fehlgeschlagen: " + e.message, "error");
  }
}

async function regenerateApiKey() {
  if (!await showConfirm("API-Key neu generieren? Der alte Key wird sofort ungültig.")) return;
  try {
    const resp = await fetch("/api/settings/api-key/regenerate", { method: "POST" });
    const data = await resp.json();
    if (data.ok) {
      const el = document.getElementById("externalApiKeyDisplay");
      if (el) el.value = data.key;
      const exEl = document.getElementById("apiExampleUrl");
      if (exEl) exEl.textContent = window.location.origin + "/api/v1/status?apikey=****";
      showToast("Neuer API-Key generiert", "success");
    } else {
      showToast("Fehler beim Generieren", "error");
    }
  } catch (e) {
    showToast("Fehler: " + e.message, "error");
  }
}

// ─── Update checker ───────────────────────────────────────────────────────────

function _applyUpdateData(data) {
  const latestEl        = document.getElementById("latestVersion");
  const banner          = document.getElementById("updateBanner");
  const bannerText      = document.getElementById("updateBannerText");
  const changelog       = document.getElementById("updateChangelog");
  const releaseLink     = document.getElementById("updateReleaseLink");
  const status          = document.getElementById("updateStatus");
  const pipCmd          = document.getElementById("updatePipCmd");
  const devHint         = document.getElementById("devChannelHint");

  const isDevInstall = !!data.is_dev_install;

  // "Verfügbar" field
  if (latestEl) latestEl.textContent = data.latest_version || "—";

  // Dev-Channel-Hinweis — nur bei stabilem Release anzeigen
  if (devHint) devHint.style.display = isDevInstall ? "none" : "";

  if (data.error) {
    if (status) status.textContent = "⚠️ " + data.error;
    if (banner) banner.style.display = "none";
  } else if (data.update_available) {
    if (status) status.textContent = "";
    if (banner) banner.style.display = "";

    if (isDevInstall) {
      // Dev install: neuere Commits auf models branch
      if (bannerText) bannerText.textContent =
        "Neuere Commits verfügbar (aktueller Commit: " + data.latest_version + ")";
      if (releaseLink && data.release_url) {
        releaseLink.href = data.release_url;
        releaseLink.textContent = "Commits ansehen";
      }
      if (changelog) changelog.style.display = "none";
      if (pipCmd) pipCmd.textContent =
        'pip install --upgrade "git+https://github.com/TheMRX13/MRX-AniWorld-Downloader.git@models"';
    } else {
      // Release install: neue Version verfügbar
      if (bannerText) bannerText.textContent =
        "Version " + data.latest_version + " verfügbar (installiert: " + data.local_version + ")";
      if (releaseLink && data.release_url) {
        releaseLink.href = data.release_url;
        releaseLink.textContent = "Release öffnen";
      }
      if (changelog) {
        changelog.style.display = "";
        changelog.textContent = data.release_notes || "";
      }
      if (pipCmd) pipCmd.textContent =
        'pip install --upgrade mrx-aniworld';
    }
  } else {
    if (status) status.textContent = "✓ Bereits aktuell.";
    if (banner) banner.style.display = "none";
  }
}

async function copyUpdateCmd() {
  const el = document.getElementById("updatePipCmd");
  if (!el) return;
  try {
    await navigator.clipboard.writeText(el.textContent.trim());
    showToast("Befehl kopiert", "success");
  } catch (e) {
    showToast("Kopieren fehlgeschlagen", "error");
  }
}

async function copyDevChannelCmd() {
  const el = document.getElementById("devChannelCmd");
  if (!el) return;
  try {
    await navigator.clipboard.writeText(el.textContent.trim());
    showToast("Befehl kopiert", "success");
  } catch (e) {
    showToast("Kopieren fehlgeschlagen", "error");
  }
}

async function checkForUpdates(force = false) {
  const btn = document.getElementById("updateCheckBtn");
  const status = document.getElementById("updateStatus");
  if (btn) { btn.disabled = true; btn.textContent = "Prüfe…"; }
  if (status) status.textContent = "";
  try {
    const resp = await fetch("/api/update-check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ force }),
    });
    _applyUpdateData(await resp.json());
  } catch (e) {
    if (status) status.textContent = "⚠️ Fehler: " + e.message;
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "Jetzt prüfen"; }
  }
}

(function initUpdateSection() {
  fetch("/api/update-check", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ force: false }),
  }).then(function (r) { return r.json(); }).then(_applyUpdateData).catch(function () { });
})();

// ─── Toast / helpers ──────────────────────────────────────────────────────────

function showToast(msg, type) {
  const t = document.getElementById("toast");
  if (!t) return;
  t.textContent = msg;
  t.className = "toast" + (type ? " toast-" + type : "");
  t.style.display = "";
  t.classList.remove("show");
  void t.offsetWidth;
  t.classList.add("show");
  clearTimeout(t._hideTimer);
  t._hideTimer = setTimeout(function () { t.classList.remove("show"); }, 4000);
}

function esc(s) {
  const d = document.createElement("div");
  d.textContent = s || "";
  return d.innerHTML;
}

// ─── Kick off ─────────────────────────────────────────────────────────────────
loadSettings();

// ─── .env migration banner ───────────────────────────────────────────────────

(function checkEnvFileBanner() {
  var banner = document.getElementById("envFileBanner");
  if (!banner) return;
  fetch("/api/settings/env-file")
    .then(function (r) { return r.json(); })
    .then(function (data) {
      if (data.exists && data.migrated) {
        banner.style.display = "flex";
      }
    })
    .catch(function () { });
})();

async function deleteEnvFile() {
  const banner = document.getElementById("envFileBanner");
  if (!await showConfirm("~/.aniworld/.env jetzt löschen? Diese Aktion kann nicht rückgängig gemacht werden.")) return;
  try {
    const resp = await fetch("/api/settings/env-file", { method: "DELETE" });
    const data = await resp.json();
    if (data.ok) {
      if (banner) banner.style.display = "none";
      showToast(".env erfolgreich gelöscht", "success");
    } else {
      showToast(data.error || "Fehler beim Löschen", "error");
    }
  } catch (e) {
    showToast("Fehler: " + e.message, "error");
  }
}

// ─── Design / Appearance ───────────────────────────────────────────────────

function _loadDesignCheckboxes() {
  const settings = [
    { id: 'glowEffect', key: 'aw-glow-effect' },
    { id: 'headerColor', key: 'aw-header-color' },
    { id: 'skeletonLoader', key: 'aw-skeleton-loader' },
    { id: 'chooseBorder', key: 'aw-choose-border' },
    { id: 'activeDownloadGlow', key: 'aw-active-download-glow' },
    { id: 'clickEffect', key: 'aw-click-effect' },
    { id: 'iconMove', key: 'aw-icon-move' }
  ];
  settings.forEach(s => {
    const el = document.getElementById(s.id);
    if (el) el.checked = localStorage.getItem(s.key) === 'true';
  });
}

function _toggleDesignSetting(key, id, className, label) {
  const el = document.getElementById(id);
  if (!el) return;
  const active = el.checked;
  localStorage.setItem(key, active);
  document.body.classList.toggle(className, active);
  showToast(label + (active ? " aktiviert" : " deaktiviert"));
}

function saveGlowEffect() {
  _toggleDesignSetting('aw-glow-effect', 'glowEffect', 'glow-effect', 'Glow-Effekt');
}

function saveHeaderColor() {
  _toggleDesignSetting('aw-header-color', 'headerColor', 'header-color', 'Header-Farbe');
}

function saveHeaderColorHelp() {
  _toggleDesignSetting('aw-header-color-help', 'headerColorHelp', 'header-color-help', 'Header-Farbe umgestellt');
}

function saveSkeletonLoader() {
  _toggleDesignSetting('aw-skeleton-loader', 'skeletonLoader', 'skeleton-loader', 'Skeleton Loader');
}

function saveBorder() {
  _toggleDesignSetting('aw-choose-border', 'chooseBorder', 'choose-border', 'Farbliche Markierung');
}

function saveActiveDownloadGlow() {
  _toggleDesignSetting('aw-active-download-glow', 'activeDownloadGlow', 'active-download-glow', 'Download-Markierung');
}

function saveClickEffect() {
  _toggleDesignSetting('aw-click-effect', 'clickEffect', 'click-effect', 'Klick-Effekt');
}

function saveIconMove() {
  _toggleDesignSetting('aw-icon-move', 'iconMove', 'icon-move', 'Icon Movement');
}

// ─── Drag to Scroll for Settings Tabs ─────────────────────────────────────────

document.addEventListener("DOMContentLoaded", () => {
  const tabs = document.getElementById("settingsTabs");
  if (!tabs) return;

  let isDown = false;
  let startX;
  let scrollLeft;
  let dragged = false;

  tabs.addEventListener("mousedown", (e) => {
    isDown = true;
    dragged = false;
    tabs.style.cursor = "grabbing";
    startX = e.pageX - tabs.offsetLeft;
    scrollLeft = tabs.scrollLeft;
  });

  tabs.addEventListener("mouseleave", () => {
    isDown = false;
    tabs.style.cursor = "grab";
  });

  tabs.addEventListener("mouseup", () => {
    isDown = false;
    tabs.style.cursor = "grab";
  });

  tabs.addEventListener("mousemove", (e) => {
    if (!isDown) return;
    const x = e.pageX - tabs.offsetLeft;
    const walk = (x - startX) * 1.5; // scroll speed multiplier
    if (Math.abs(walk) > 5) {
      dragged = true;
    }
    tabs.scrollLeft = scrollLeft - walk;
  });

  // Intercept click event in capture phase to prevent switching tab when dragging
  tabs.addEventListener("click", (e) => {
    if (dragged) {
      e.stopPropagation();
      e.preventDefault();
    }
  }, true);
});

