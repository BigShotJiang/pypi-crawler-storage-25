// ===== Seerr requests page =====

const SEERR_PAGE_SIZE = 20;

// CineInfo settings (loaded once on page init)
let _seerrCineinfo = null;
async function _loadSeerrCineinfo() {
  try {
    const r = await fetch("/api/settings");
    const data = await r.json();
    _seerrCineinfo = data.cineinfo || {};
  } catch (e) { _seerrCineinfo = {}; }
}

// Provider brand colours (mirrors app.js _providerColors)
const _seerrProvColors = {
  'Netflix': '#E50914', 'Netflix basic with Ads': '#E50914', 'Netflix Standard with Ads': '#E50914',
  'Amazon Prime Video': '#00A8E0', 'Amazon Video': '#00A8E0',
  'Disney+': '#113CCF', 'Apple TV+': '#555', 'Apple TV Store': '#555',
  'Crunchyroll': '#F47521', 'WOW': '#00B4D8', 'RTL+': '#FF6900', 'Joyn': '#00C896',
  'Paramount+': '#0064FF', 'Max': '#5822B7', 'HBO Max': '#5822B7',
  'MUBI': '#C2410C', 'Hulu': '#1CE783', 'MagentaTV': '#E20074',
  'ARD Mediathek': '#003D5B', 'ZDFmediathek': '#008CD2',
};

function _seerrMakeProviderPill(name) {
  const color = _seerrProvColors[name];
  const pill = document.createElement('span');
  pill.style.cssText = [
    'display:inline-flex', 'align-items:center', 'gap:6px',
    'font-size:0.75rem', 'font-weight:600', 'padding:4px 12px 4px 8px',
    'border-radius:99px',
    'border:1.5px solid ' + (color ? color + '60' : 'rgba(148,163,184,.35)'),
    'background:var(--bg-elevated,#1a1a28)',
    'color:' + (color || 'var(--text-secondary,#9191b0)'),
    'white-space:nowrap', 'line-height:1.4', 'cursor:default',
  ].join(';');
  if (color) {
    const dot = document.createElement('span');
    dot.style.cssText = 'width:7px;height:7px;border-radius:50%;background:' + color + ';flex-shrink:0;display:inline-block';
    pill.appendChild(dot);
  }
  const lbl = document.createElement('span');
  lbl.textContent = name;
  pill.appendChild(lbl);
  return pill;
}

async function checkAutosyncTitle(searchString) {
    const url = "http://localhost:8080/api/autosync";
    let isAutoSync = false;
    console.info(searchString);
    
    try {
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error(`HTTP-Fehler! Status: ${response.status}`);
        }

        const data = await response.json();

        if (data.jobs && Array.isArray(data.jobs)) {
            for (let job of data.jobs) {
                const title = job.title || "";
                console.log(title.toLowerCase().includes(searchString.toLowerCase()));
                if (title.toLowerCase().includes(searchString.toLowerCase())) {
                    console.log(title.toLowerCase().includes(searchString.toLowerCase()));
                    isAutoSync = true;
                    break; 
                }
            }
        }
    } catch (error) {
        console.error("Fehler bei der API-Abfrage:", error);
    }

    return isAutoSync;
}


async function _enrichSeerrModal(title, imdbId) {
  if (!_seerrCineinfo || !_seerrCineinfo.tmdb_api_key) return;
  try {
    let url = '/api/tmdb/info?title=' + encodeURIComponent(title).replace(/'/g, "%27");
    if (imdbId) url += '&imdb_id=' + encodeURIComponent(imdbId).replace(/'/g, "%27");
    const d = await (await fetch(url)).json();
    if (!d.found) return;

    // ── Providers ────────────────────────────────────────────────
    if (_seerrCineinfo.show_providers !== '0' && d.providers && d.providers.length) {
      const provEl = document.getElementById('seerrTmdbProviders');
      if (provEl) {
        provEl.innerHTML = '';
        provEl.style.cssText = 'display:flex;flex-wrap:wrap;gap:5px;margin:4px 0 16px;max-height:74px;overflow:hidden;position:relative';
        const MAX = 6, visible = d.providers.slice(0, MAX), rest = d.providers.length - MAX;
        visible.forEach(p => provEl.appendChild(_seerrMakeProviderPill(p)));
        if (rest > 0) {
          const more = document.createElement('span');
          more.textContent = '+' + rest + ' mehr';
          more.style.cssText = 'display:inline-flex;align-items:center;font-size:0.72rem;font-weight:600;padding:4px 10px;border-radius:99px;border:1.5px solid rgba(148,163,184,.3);background:var(--bg-elevated,#1a1a28);color:var(--text-muted,#55556a);white-space:nowrap;cursor:default';
          provEl.appendChild(more);
        }
      }
    }

    // ── TMDB Genres (replace site genres if enabled) ─────────────
    if (_seerrCineinfo.show_genres === '1' && d.genres && d.genres.length) {
      const genresEl = document.getElementById('seerrModalGenres');
      if (genresEl) {
        genresEl.innerHTML = '';
        d.genres.forEach(g => { const sp = document.createElement('span'); sp.textContent = g; genresEl.appendChild(sp); });
      }
    }

    // ── Rating badge next to title ────────────────────────────────
    if (_seerrCineinfo.show_rating === '1' && d.vote_average) {
      const titleEl = document.getElementById('seerrModalTitle');
      if (titleEl) {
        titleEl.style.cssText = 'display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin:0 0 4px';
        const old = titleEl.querySelector('#seerrTmdbRating');
        if (old) old.remove();
        const score = d.vote_average.toFixed(1);
        const col = d.vote_average >= 7 ? '#4ade80' : d.vote_average >= 5 ? '#fbbf24' : '#f87171';
        const brd = d.vote_average >= 7 ? 'rgba(74,222,128,.4)' : d.vote_average >= 5 ? 'rgba(251,191,36,.4)' : 'rgba(248,113,113,.4)';
        const badge = document.createElement('span');
        badge.id = 'seerrTmdbRating';
        badge.style.cssText = 'display:inline-flex;align-items:center;gap:4px;font-size:0.72rem;font-weight:700;padding:2px 8px 2px 6px;border-radius:99px;border:1px solid ' + brd + ';background:rgba(0,0,0,.22);color:' + col + ';white-space:nowrap;cursor:default;letter-spacing:.01em;flex-shrink:0';
        badge.innerHTML = '<svg width="10" height="10" viewBox="0 0 24 24" fill="' + col + '" style="flex-shrink:0"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>' + score;
        titleEl.appendChild(badge);
      }
    }

    // ── FSK under poster ─────────────────────────────────────────
    if (_seerrCineinfo.show_fsk !== '0' && d.fsk) {
      const fskEl = document.getElementById('seerrTmdbFsk');
      if (fskEl) {
        const n = parseInt(d.fsk, 10);
        const fp = ({ 0: { bg: 'rgba(255,255,255,.07)', bc: 'rgba(255,255,255,.3)', c: '#d1d5db' }, 6: { bg: 'rgba(234,179,8,.12)', bc: 'rgba(234,179,8,.55)', c: '#fbbf24' }, 12: { bg: 'rgba(34,197,94,.12)', bc: 'rgba(34,197,94,.5)', c: '#4ade80' }, 16: { bg: 'rgba(59,130,246,.12)', bc: 'rgba(59,130,246,.5)', c: '#60a5fa' }, 18: { bg: 'rgba(239,68,68,.12)', bc: 'rgba(239,68,68,.5)', c: '#f87171' } })[n] || { bg: 'rgba(148,163,184,.1)', bc: 'rgba(148,163,184,.35)', c: '#94a3b8' };
        fskEl.textContent = 'FSK ' + d.fsk;
        fskEl.style.cssText = 'display:block;font-size:0.75rem;font-weight:700;padding:3px 10px;border-radius:99px;border:1px solid ' + fp.bc + ';background:' + fp.bg + ';color:' + fp.c + ';text-align:center;white-space:nowrap;letter-spacing:.02em;width:100%;box-sizing:border-box';
      }
    }
  } catch (e) { /* best-effort */ }
}

let _seerrSkip = 0;
let _seerrTotal = null;
let _seerrLoading = false;
let _seerrObserver = null;

// State for the search / series modals
let _seerrIsMovie = false;
let _seerrCurrentReqId = null;   // Seerr request id when series modal is open
let _seerrCurrentStatus = null;  // 1=pending, 2=approved
let _seerrSeriesUrl = null;
let _seerrSeriesTitle = "";
let _seerrCustomPaths = [];

// ---------------------------------------------------------------
// Card list + lazy loading
// ---------------------------------------------------------------

// Load CineInfo settings when page initialises
_loadSeerrCineinfo();

async function seerrLoad() {
  _seerrSkip = 0;
  _seerrTotal = null;
  _seerrLoading = false;
  if (_seerrObserver) { _seerrObserver.disconnect(); _seerrObserver = null; }

  const list = document.getElementById("seerrList");
  list.innerHTML = '<div class="queue-empty" style="padding:40px 0">Lade Anfragen…</div>';
  seerrSetStatus("loading");
  await seerrFetchPage(true);
}

async function seerrFetchPage(isFirst) {
  if (_seerrLoading) return;
  if (_seerrTotal !== null && _seerrSkip >= _seerrTotal) return;
  _seerrLoading = true;

  const list = document.getElementById("seerrList");
  const oldSentinel = document.getElementById("seerrSentinel");
  if (oldSentinel) oldSentinel.remove();

  try {
    const resp = await fetch(`/api/seerr/requests?take=${SEERR_PAGE_SIZE}&skip=${_seerrSkip}`);
    const data = await resp.json();

    if (data.error) {
      if (isFirst) {
        list.innerHTML = data.error.includes("nicht konfiguriert")
          ? '<div class="queue-empty">Seerr ist noch nicht konfiguriert. Bitte trage URL und API-Key unter <a href="/integrations" style="color:var(--accent)">Integrationen</a> ein.</div>'
          : `<div class="queue-empty" style="color:var(--error)">${escS(data.error)}</div>`;
        seerrSetStatus("error");
      }
      _seerrLoading = false;
      return;
    }

    const requests = data.requests || [];
    _seerrTotal = data.total ?? requests.length;
    _seerrSkip += requests.length;

    if (isFirst) {
      if (!requests.length) {
        list.innerHTML = '<div class="queue-empty">Keine ausstehenden oder angenommenen Serien-Anfragen.</div>';
        seerrSetStatus("ok", "0 Anfragen");
        _seerrLoading = false;
        return;
      }
      list.innerHTML = '<div class="seerr-grid" id="seerrGrid"></div>';
      seerrSetStatus("ok", `${_seerrTotal} Anfragen`);
      const badge = document.getElementById("seerrBadge");
      if (badge) { badge.textContent = _seerrTotal; badge.style.display = _seerrTotal > 0 ? "" : "none"; }
    }

    const grid = document.getElementById("seerrGrid");
    requests.forEach(req => grid.insertAdjacentHTML("beforeend", seerrRenderCard(req)));

    if (_seerrSkip < _seerrTotal) {
      const sentinel = document.createElement("div");
      sentinel.id = "seerrSentinel";
      sentinel.className = "seerr-sentinel";
      sentinel.innerHTML = '<span class="lib-scan-spinner" style="display:inline-block"></span>';
      list.appendChild(sentinel);
      if (!_seerrObserver) {
        _seerrObserver = new IntersectionObserver(
          entries => { if (entries[0].isIntersecting) seerrFetchPage(false); },
          { rootMargin: "200px" }
        );
      }
      _seerrObserver.observe(sentinel);
    }
  } catch (e) {
    if (isFirst) {
      list.innerHTML = `<div class="queue-empty" style="color:var(--error)">Fehler: ${escS(e.message)}</div>`;
      seerrSetStatus("error");
    }
  }
  _seerrLoading = false;
}

function seerrRenderCard(req) {
  const poster = req.posterUrl
    ? `<img class="seerr-card-poster" src="${req.posterUrl}" alt="" loading="lazy">`
    : `<div class="seerr-card-poster seerr-card-poster-placeholder"><img src="/static/placeholder.svg" style="width: 100%;object-fit: cover;object-position: center;height: 120%;min-width: 100%;min-height: 120%;"/></div>`;

  const year = req.firstAirDate || "";

  // Season badges
  let seasonBadges = "";
  if (!req.isMovie) {
    const reqSeasons = Array.isArray(req.requestedSeasons) && req.requestedSeasons.length
      ? req.requestedSeasons : [];
    if (reqSeasons.length) {
      seasonBadges = `<div class="seerr-season-badges">
        <span class="seerr-season-label">Staffel${reqSeasons.length !== 1 ? "n" : ""}</span>
        ${reqSeasons.map(n => `<span class="seerr-season-badge">${n}</span>`).join("")}
      </div>`;
    } else if (req.numberOfSeasons) {
      seasonBadges = `<div class="seerr-season-badges"><span class="seerr-season-label">${req.numberOfSeasons} Staffel${req.numberOfSeasons !== 1 ? "n" : ""}</span></div>`;
    }
  } else {
    seasonBadges = `<div class="seerr-season-badges"><span class="seerr-season-label">Film</span></div>`;
  }

  const STATUS_LABEL = { 1: "Ausstehend", 2: "Angenommen" };
  const STATUS_DOWN  = { 3: "Nicht geladen", 4: "Teilweise" };
  const STATUS_CLASS = { 1: "seerr-status-pending", 2: "seerr-status-approved", 3: "seerr-status-notavailable", 4: "seerr-status-partial" };

  const statusLabel     = STATUS_LABEL[req.status] || "";
  const statusClass     = STATUS_CLASS[req.status] || "";
  const statusLabelDown = STATUS_DOWN[req.downloadStatus] || "";
  const statusClassDown = STATUS_CLASS[req.downloadStatus] || "";

  const activePill  = statusLabelDown || statusLabel;
  const activeClass = statusLabelDown ? statusClassDown : statusClass;

  const reqBy = req.requestedBy ? escS(req.requestedBy) : "";
  const date  = req.createdAt ? formatSeerrDate(req.createdAt) : "";
  const overview = req.overview ? escS(req.overview) : "";

  let syncStatus = "";
  if (req.downloadStatus === 4) {
    const uniqueId = `autosync-pill-${req.id}`;
    
    syncStatus = `<div class="seerr-card-status-row">
      <span id="${uniqueId}" class="seerr-status-pill"></span>
    </div>`;

    checkAutosyncTitle(req.title).then(isInSync => {
      setTimeout(() => {
        const pillElement = document.getElementById(uniqueId);
        
        if (!pillElement) {
          console.warn(`[Autosync] Element mit ID ${uniqueId} wurde noch nicht im DOM gefunden!`);
          return;
        }

        if (isInSync) {
          console.log(`[Autosync] Match gefunden für: ${req.title} -> Setze 'In Sync'`);
          pillElement.classList.add('seerr-status-available');
          pillElement.textContent = 'In Sync';
        } else {
          console.log(`[Autosync] Kein Match für: ${req.title}`);
          pillElement.textContent = ''; 
        }
      }, 0);
    }).catch(err => console.error("Fehler beim Updaten der Pill:", err));
  }

  const bodyStyle = req.backdropUrl
    ? `style="--seerr-backdrop:url('${req.backdropUrl}')"`
    : `style="--seerr-backdrop:url('/static/placeholder.svg')"`;

  return `<div class="seerr-card" data-has-backdrop="1">

    ${poster}

    <div class="seerr-card-body"${bodyStyle}>
      <div class="seerr-card-body-inner">
        ${year ? `<div class="seerr-card-year">${escS(year)}</div>` : ""}
        <div class="seerr-card-title">${escS(req.title)}</div>
        ${seasonBadges}
        ${overview ? `<p class="seerr-card-overview">${overview}</p>` : ""}
      </div>
    </div>

    <div class="seerr-card-right">
      ${activePill ? `<div class="seerr-card-status-row">
        <span class="seerr-card-status-label">Status</span>
        <span class="seerr-status-pill ${activeClass}">${activePill}</span>
        ${syncStatus}
      </div>` : ""}
      ${reqBy || date ? `<div class="seerr-card-req-meta">
        Angefragt${date ? ` ${escS(date)}` : ""}${reqBy ? ` von <strong>${reqBy}</strong>` : ""}
      </div>` : ""}
      <div class="seerr-card-actions">
        <button class="btn btn-primary btn-sm seerr-search-btn"
          data-id="${req.id}"
          data-status="${req.status}"
          data-title="${escS(req.title)}"
          data-is-movie="${req.isMovie ? '1' : '0'}">Suchen</button>
         ${(typeof seerrCanDecline !== "undefined" && seerrCanDecline && req.status !== 2) ? `
        <button class="btn btn-sm btn-reject seerr-decline-btn"
          data-id="${req.id}">Ablehnen</button>` : ""}
      </div>
    </div>

  </div>`;
}

// ---------------------------------------------------------------
// Search modal
// ---------------------------------------------------------------

function openSeerrSearch(reqId, title, status, isMovie) {
  _seerrCurrentReqId = reqId;
  _seerrCurrentStatus = status;
  _seerrIsMovie = !!isMovie;

  const titleEl = document.getElementById("seerrSearchTitle");
  if (titleEl) titleEl.textContent = isMovie ? "Film suchen" : "Serie suchen";

  document.getElementById("seerrSearchInput").value = title || "";
  document.getElementById("seerrSearchResults").innerHTML = "";
  document.getElementById("seerrSearchOverlay").style.display = "block";
  document.body.style.overflow = "hidden";
  document.getElementById("seerrSearchInput").focus();

  // Show decline button only for admins with a request ID
  const declineBtn = document.getElementById("seerrSearchDeclineBtn");
  if (declineBtn) declineBtn.style.display = (reqId && (typeof seerrCanDecline !== "undefined" && seerrCanDecline)) ? "" : "none";

  // Auto-search with title
  if (title) seerrDoSearch();
}

function closeSeerrSearch() {
  document.getElementById("seerrSearchOverlay").style.display = "none";
  document.body.style.overflow = "";
}

async function seerrDoSearch() {
  const q = document.getElementById("seerrSearchInput").value.trim();
  if (!q) return;

  document.getElementById("seerrSearchResults").innerHTML =
    '<div class="queue-empty" style="padding:20px 0">Suche läuft…</div>';

  let combined = [];

  if (_seerrIsMovie) {
    // Movies: search FilmPalast only
    const results = await seerrFetchSearch(q, "filmpalast").catch(() => []);
    combined = results.map(r => Object.assign({}, r, { _source: "FilmPalast" }));
  } else {
    // Series: search AniWorld + S.TO in parallel, interleave results
    const [aniRes, stoRes] = await Promise.allSettled([
      seerrFetchSearch(q, "aniworld"),
      seerrFetchSearch(q, "sto"),
    ]);
    const aniList = (aniRes.status === "fulfilled" ? aniRes.value : []).map(r => Object.assign({}, r, { _source: "AniWorld" }));
    const stoList = (stoRes.status === "fulfilled" ? stoRes.value : []).map(r => Object.assign({}, r, { _source: "S.TO" }));
    // Interleave: alternate aniworld/sto so both appear near the top
    const maxLen = Math.max(aniList.length, stoList.length);
    for (let i = 0; i < maxLen; i++) {
      if (i < aniList.length) combined.push(aniList[i]);
      if (i < stoList.length) combined.push(stoList[i]);
    }
  }

  seerrRenderSearchResults(combined);
}

async function seerrFetchSearch(q, site) {
  const resp = await fetch("/api/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ keyword: q, site }),
  });
  const data = await resp.json();
  return data.results || [];
}

function seerrRenderSearchResults(results) {
  const container = document.getElementById("seerrSearchResults");
  if (!results || !results.length) {
    container.innerHTML = '<div class="queue-empty" style="padding:20px 0">Keine Ergebnisse.</div>';
    return;
  }
  container.innerHTML = results.map((r, i) =>
    `<div class="seerr-search-result seerr-result-btn" data-url="${escS(r.url)}">
      <div class="seerr-search-poster seerr-card-poster-placeholder" id="seerrPoster-${i}">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="opacity:.3">
          <rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>
        </svg>
      </div>
      <span class="seerr-search-title">${escS(r.title)}</span>
      ${r._source ? `<span class="seerr-source-pill">${escS(r._source)}</span>` : ""}
    </div>`
  ).join("");

  // Fetch posters in background
  results.forEach((r, i) => {
    fetch("/api/series?url=" + encodeURIComponent(r.url))
      .then(res => res.json())
      .then(data => {
        if (!data.poster_url) return;
        const el = document.getElementById("seerrPoster-" + i);
        if (!el) return;
        el.innerHTML = `<img src="${escS(proxyImg(data.poster_url))}" style="width:100%;height:100%;object-fit:cover;border-radius:4px" alt="" loading="lazy">`;
        el.classList.remove("seerr-card-poster-placeholder");
      })
      .catch(() => { });
  });
}

// ---------------------------------------------------------------
// Series modal
// ---------------------------------------------------------------

async function openSeerrSeries(url) {
  closeSeerrSearch();
  _seerrSeriesUrl = url;

  // Reset modal
  document.getElementById("seerrModalPoster").src = "";
  document.getElementById("seerrModalTitle").textContent = "Lädt…";
  document.getElementById("seerrModalTitle").style.cssText = "";
  document.getElementById("seerrModalGenres").innerHTML = "";
  document.getElementById("seerrModalYear").textContent = "";
  document.getElementById("seerrModalDesc").textContent = "";
  document.getElementById("seerrAccordion").innerHTML = "";
  document.getElementById("seerrEpSpinner").style.display = "block";
  document.getElementById("seerrLangBanner").style.display = "none";
  document.getElementById("seerrSelectAll").checked = false;
  // Reset TMDB elements
  const _rp = document.getElementById("seerrTmdbProviders");
  if (_rp) { _rp.innerHTML = ""; _rp.style.display = "none"; }
  const _rf = document.getElementById("seerrTmdbFsk");
  if (_rf) { _rf.textContent = ""; _rf.style.display = "none"; }
  seerrSetModalActions();
  await seerrLoadCustomPaths();

  document.getElementById("seerrSeriesOverlay").style.display = "block";
  document.body.style.overflow = "hidden";

  // Update lang options based on site
  const isSto = url.includes("s.to");
  const isFp = url.includes("filmpalast.to");
  seerrUpdateLangDropdown(isSto, isFp);

  try {
    const [seriesResp, seasonsResp] = await Promise.all([
      fetch("/api/series?url=" + encodeURIComponent(url)),
      fetch("/api/seasons?url=" + encodeURIComponent(url)),
    ]);
    const seriesData = await seriesResp.json();
    const seasonsData = await seasonsResp.json();

    _seerrSeriesTitle = seriesData.title || "Unbekannt";
    document.getElementById("seerrModalTitle").textContent = _seerrSeriesTitle;
    // Genres as pills (matching main modal style)
    const _ge = document.getElementById("seerrModalGenres");
    _ge.innerHTML = "";
    (seriesData.genres || []).forEach(g => { const sp = document.createElement("span"); sp.textContent = g; _ge.appendChild(sp); });
    document.getElementById("seerrModalYear").textContent = seriesData.release_year || "";
    document.getElementById("seerrModalDesc").textContent = seriesData.description || "";
    if (seriesData.poster_url) document.getElementById("seerrModalPoster").src = proxyImg(seriesData.poster_url);

    // TMDB enrichment (providers, FSK, rating, TMDB genres)
    _enrichSeerrModal(_seerrSeriesTitle, seriesData.imdb_id || null);

    seerrBuildAccordion(seasonsData.seasons || []);

    // Show/hide "Episoden" heading
    const seerrEpHeading = document.getElementById("seerrEpisodesHeading");
    if (seerrEpHeading) seerrEpHeading.style.display = seriesData.is_movie ? "none" : "";

    // FilmPalast movie: populate provider dropdown from metadata
    if (seriesData.is_movie && seriesData.available_providers && seriesData.available_providers.length) {
      const provSel = document.getElementById("seerrProvSelect");
      provSel.innerHTML = "";
      seriesData.available_providers.forEach(p => {
        const opt = document.createElement("option");
        opt.value = opt.textContent = p;
        provSel.appendChild(opt);
      });
      // Prefer VOE if available
      const voeOpt = [...provSel.options].find(o => o.value === "VOE");
      if (voeOpt) provSel.value = "VOE";
    }
  } catch (e) {
    document.getElementById("seerrModalTitle").textContent = "Fehler beim Laden";
    document.getElementById("seerrEpSpinner").style.display = "none";
  }
}

function closeSeerrSeries() {
  document.getElementById("seerrSeriesOverlay").style.display = "none";
  document.body.style.overflow = "";
}

function seerrUpdateLangDropdown(isSto, isFp) {
  const sel = document.getElementById("seerrLangSelect");
  sel.innerHTML = "";
  if (isFp) {
    const opt = document.createElement("option");
    opt.value = opt.textContent = "German Dub";
    sel.appendChild(opt);
    return;
  }
  const langs = isSto
    ? (window.SEERR_STO_LANGS || {})
    : (window.SEERR_ANIWORLD_LANGS || {});
  Object.values(langs).forEach(label => {
    const opt = document.createElement("option");
    opt.value = opt.textContent = label;
    sel.appendChild(opt);
  });
}

async function seerrLoadCustomPaths() {
  try {
    const resp = await fetch("/api/custom-paths");
    const data = await resp.json();
    _seerrCustomPaths = data.paths || [];
    const sel = document.getElementById("seerrPathSelect");
    sel.innerHTML = '<option value="">Standard</option>';
    _seerrCustomPaths.forEach(cp => {
      const opt = document.createElement("option");
      opt.value = cp.id;
      opt.textContent = cp.name;
      sel.appendChild(opt);
    });
    sel.style.display = _seerrCustomPaths.length ? "" : "none";
  } catch (e) { /* ignore */ }
}

function seerrSetModalActions() {
  const div = document.getElementById("seerrModalActions");
  const isPending = _seerrCurrentStatus === 1;
  const mainLabel = isPending ? "Annehmen &amp; Herunterladen" : "Herunterladen";
  const declineBtn = (_seerrCurrentReqId && (typeof seerrCanDecline !== "undefined" && seerrCanDecline))
    ? `<button class="btn-reject" onclick="seerrDeclineRequest(${_seerrCurrentReqId})">Ablehnen</button>`
    : "";
  // "Alle herunterladen" makes no sense for a single movie
  const allBtn = _seerrIsMovie ? "" :
    `<button class="btn-download-all" onclick="seerrStartDownload(true)">Alle ${isPending ? "annehmen &amp; " : ""}herunterladen</button>`;
  div.innerHTML = `
    <div class="modal-action-downloads">
      <button class="btn-download-selected" onclick="seerrStartDownload(false)">${mainLabel}</button>
      ${allBtn}
    </div>
    <div class="modal-action-controls">
      <button class="btn btn-secondary" onclick="closeSeerrSeries()">Abbrechen</button>
      ${declineBtn}
    </div>
  `;
}

// ---------------------------------------------------------------
// Episode accordion (mirrors app.js buildAccordion)
// ---------------------------------------------------------------

const SEERR_LANG_FLAGS = {
  "German Dub": "/static/flags/german.svg",
  "English Dub": "/static/flags/english.svg",
  "German Sub": "/static/flags/japanese-germanSub.svg",
  "English Sub": "/static/flags/japanese-englishSub.svg",
};

function seerrBuildAccordion(seasons) {
  const accordion = document.getElementById("seerrAccordion");
  const spinner = document.getElementById("seerrEpSpinner");
  accordion.innerHTML = "";
  spinner.style.display = "block";

  const fetches = seasons.map((s, i) =>
    fetch("/api/episodes?url=" + encodeURIComponent(s.url))
      .then(r => r.json())
      .then(d => ({ index: i, episodes: d.episodes || [] }))
      .catch(() => ({ index: i, episodes: [] }))
  );

  Promise.all(fetches).then(results => {
    spinner.style.display = "none";
    results.sort((a, b) => a.index - b.index);

    results.forEach(({ index, episodes }) => {
      const season = seasons[index];
      const section = document.createElement("div");
      section.className = "season-section";
      section.dataset.seasonIndex = index;

      const isSingleMovie = !!season.is_single_movie;

      const label = isSingleMovie
        ? "Film"
        : season.are_movies
          ? `Filme (${episodes.length} Episoden)`
          : `Staffel ${season.season_number} (${episodes.length} Episoden)`;

      const header = document.createElement("div");
      if (isSingleMovie) {
        header.className = "season-header season-header-movie expanded";
        header.style.display = "none";
      } else {
        header.className = "season-header";
        header.innerHTML =
          `<div class="season-label"><span class="season-arrow">&#9654;</span> ${seerrEsc(label)}</div>` +
          `<label class="season-all-label" onclick="event.stopPropagation()">` +
          `<input type="checkbox" onchange="seerrToggleSeasonAll(this,${index})"> Alle</label>`;
        header.addEventListener("click", () => seerrToggleSeason(index));
      }

      const body = document.createElement("div");
      body.className = "season-body" + (isSingleMovie ? " expanded" : "");
      body.id = "seerrSeasonBody-" + index;

      episodes.forEach(ep => {
        const div = document.createElement("div");
        div.className = "episode-item";
        const title = ep.title_en || ep.title_de || "";
        const dlIcon = ep.downloaded ? '<span class="ep-downloaded" title="Downloaded">&#10003;</span>' : "";
        let langsHtml = "";
        if (ep.languages && ep.languages.length) {
          langsHtml = `<span class="ep-langs">${ep.languages.map(l => {
            const src = SEERR_LANG_FLAGS[l];
            return src ? `<img class="ep-lang-flag" src="${src}" title="${seerrEsc(l)}" alt="${seerrEsc(l)}">` : "";
          }).join("")}</span>`;
        }
        const epNumHtml = isSingleMovie ? "" : `<span class="ep-num">E${ep.episode_number}</span>`;
        const cb = `<input type="checkbox" value="${seerrEsc(ep.url)}" data-season="${index}"${isSingleMovie ? " checked" : ""}>`;
        div.innerHTML = `${cb}${epNumHtml}${dlIcon}<span class="ep-title">${seerrEsc(title)}</span>${langsHtml}`;
        body.appendChild(div);
      });

      section.appendChild(header);
      section.appendChild(body);
      accordion.appendChild(section);
    });

    // Language availability banner
    seerrRenderLangBanner(results);
  });
}

function seerrToggleSeason(index) {
  const section = document.querySelector(`#seerrAccordion [data-season-index="${index}"]`);
  if (!section) return;
  section.querySelector(".season-header").classList.toggle("expanded");
  section.querySelector(".season-body").classList.toggle("expanded");
}

function seerrToggleSeasonAll(cb, index) {
  const body = document.getElementById("seerrSeasonBody-" + index);
  if (body) body.querySelectorAll(".episode-item input[type=checkbox]").forEach(c => c.checked = cb.checked);
  seerrSyncSelectAll();
}

function seerrToggleSelectAll() {
  const checked = document.getElementById("seerrSelectAll").checked;
  document.querySelectorAll("#seerrAccordion .episode-item input[type=checkbox]").forEach(c => c.checked = checked);
}

function seerrSyncSelectAll() {
  const all = [...document.querySelectorAll("#seerrAccordion .episode-item input[type=checkbox]")];
  document.getElementById("seerrSelectAll").checked = all.length > 0 && all.every(c => c.checked);
}

function seerrGetSelected() {
  return [...document.querySelectorAll("#seerrAccordion .episode-item input[type=checkbox]:checked")].map(c => c.value);
}

function seerrGetAll() {
  return [...document.querySelectorAll("#seerrAccordion .episode-item input[type=checkbox]")].map(c => c.value);
}

function seerrRenderLangBanner(results) {
  const banner = document.getElementById("seerrLangBanner");
  if (!banner) return;
  if ((_seerrSeriesUrl || "").includes("filmpalast.to")) { banner.style.display = "none"; return; }
  const LANG_ORDER = ["German Dub", "English Sub", "German Sub", "English Dub"];
  const LANG_SHORT = { "German Dub": "Ger. Dub", "English Sub": "Eng. Sub", "German Sub": "Ger. Sub", "English Dub": "Eng. Dub" };
  const counts = {};
  let total = 0;
  results.forEach(({ episodes }) => {
    episodes.forEach(ep => {
      total++;
      (ep.languages || []).forEach(l => counts[l] = (counts[l] || 0) + 1);
    });
  });
  if (!total) { banner.style.display = "none"; return; }
  banner.innerHTML = LANG_ORDER.map(lang => {
    const n = counts[lang] || 0;
    const cls = n === total ? "lang-avail-full" : n === 0 ? "lang-avail-none" : "lang-avail-partial";
    return `<span class="lang-avail-pill ${cls}">${LANG_SHORT[lang]}: ${n}&thinsp;/&thinsp;${total}</span>`;
  }).join("");
  banner.style.display = "flex";
}

// ---------------------------------------------------------------
// Download + approve
// ---------------------------------------------------------------

async function seerrStartDownload(all) {
  const episodes = all ? seerrGetAll() : seerrGetSelected();
  if (!episodes.length) return;

  const language = document.getElementById("seerrLangSelect").value;
  const provider = document.getElementById("seerrProvSelect").value;
  const pathSel = document.getElementById("seerrPathSelect");
  const customPathId = pathSel && pathSel.value ? parseInt(pathSel.value) : null;

  // If pending → approve on Seerr first
  if (parseInt(_seerrCurrentStatus) === 1 && _seerrCurrentReqId) {
    try {
      const approveResp = await fetch(`/api/seerr/requests/${_seerrCurrentReqId}/approve`, { method: "POST" });
      if (!approveResp.ok) {
        const err = await approveResp.json().catch(() => ({}));
        console.warn("Seerr approve failed:", approveResp.status, err);
        // Show warning but still proceed with download
        if (typeof showToast === "function") showToast("⚠ Seerr-Genehmigung fehlgeschlagen: " + (err.error || approveResp.status));
      }
    } catch (e) {
      console.warn("Seerr approve error:", e);
    }
  }

  // Start download
  const body = { episodes, language, provider, title: _seerrSeriesTitle, series_url: _seerrSeriesUrl };
  if (customPathId) body.custom_path_id = customPathId;

  try {
    const resp = await fetch("/api/download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await resp.json();
    if (data.error) { alert(data.error); return; }
  } catch (e) { alert("Download fehlgeschlagen: " + e.message); return; }

  closeSeerrSeries();
  // Reload to reflect new status
  seerrLoad();
}

// ---------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------

function seerrSetStatus(state, label) {
  const wrap = document.getElementById("seerrStatus");
  const dot = document.getElementById("seerrStatusDot");
  const lbl = document.getElementById("seerrStatusLabel");
  if (!wrap) return;
  if (state === "loading") {
    wrap.style.display = ""; dot.className = "lib-watcher-dot lib-watcher-starting"; lbl.textContent = "Lädt…";
  } else if (state === "ok") {
    wrap.style.display = ""; dot.className = "lib-watcher-dot lib-watcher-on"; lbl.textContent = label || "Verbunden";
  } else if (state === "error") {
    wrap.style.display = ""; dot.className = "lib-watcher-dot lib-watcher-off"; lbl.textContent = "Fehler";
  } else {
    wrap.style.display = "none";
  }
}

function formatSeerrDate(iso) {
  try { return new Date(iso).toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" }); }
  catch { return ""; }
}

function escS(s) {
  const d = document.createElement("div"); d.textContent = String(s || ""); return d.innerHTML;
}
function seerrEsc(s) { return escS(s); }

// ---------------------------------------------------------------
// Init
// ---------------------------------------------------------------

// ---------------------------------------------------------------
// Decline / Ablehnen
// ---------------------------------------------------------------

async function seerrDeclineRequest(reqId) {
  if (!confirm("Anfrage wirklich ablehnen? Diese Aktion kann nicht rückgängig gemacht werden.")) return;
  try {
    const resp = await fetch(`/api/seerr/requests/${reqId}/decline`, { method: "POST" });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || resp.status);
    closeSeerrSearch();
    closeSeerrSeries();
    seerrLoad();
  } catch (e) {
    alert("Fehler beim Ablehnen: " + e.message);
  }
}

function seerrDeclineFromSearch() {
  if (_seerrCurrentReqId) seerrDeclineRequest(_seerrCurrentReqId);
}

// Event delegation for search buttons on the card list
document.getElementById("seerrList").addEventListener("click", function (e) {
  // Decline button
  const decBtn = e.target.closest(".seerr-decline-btn");
  if (decBtn) {
    seerrDeclineRequest(parseInt(decBtn.dataset.id));
    return;
  }
  // Search button
  const btn = e.target.closest(".seerr-search-btn");
  if (!btn) return;
  openSeerrSearch(
    parseInt(btn.dataset.id),
    btn.dataset.title,
    parseInt(btn.dataset.status),
    btn.dataset.isMovie === "1"
  );
});

// Event delegation for search results → open series modal
document.getElementById("seerrSearchResults").addEventListener("click", function (e) {
  const row = e.target.closest(".seerr-result-btn");
  if (!row) return;
  openSeerrSeries(row.dataset.url);
});

seerrLoad();
