// ─── Tab Navigation ────────────────────────────────────────────────────────

function switchIntegTab(name) {
  document.querySelectorAll("#integTabs .settings-tab").forEach(function (btn) {
    btn.classList.toggle("active", btn.dataset.tab === name);
  });
  document.querySelectorAll(".settings-tab-panel").forEach(function (panel) {
    panel.classList.toggle("active", panel.id === "tab-" + name);
  });
  try {
    history.replaceState(null, "", "#" + name);
    localStorage.setItem("integActiveTab", name);
  } catch (e) {}
}

(function restoreIntegTab() {
  var hash = "";
  try { hash = (window.location.hash || "").replace("#", "").trim(); } catch (e) {}
  var valid = ["seerr", "mediaplayer", "cineinfo"];
  var tab = (hash && valid.indexOf(hash) !== -1) ? hash : "";
  if (!tab) {
    try { tab = localStorage.getItem("integActiveTab") || "seerr"; } catch (e) { tab = "seerr"; }
  }
  if (valid.indexOf(tab) === -1) tab = "seerr";
  switchIntegTab(tab);
})();

// ===== Settings Caching Helper =====
let _combinedSettingsPromise = null;
function _getSettings() {
  if (!_combinedSettingsPromise) {
    _combinedSettingsPromise = (async () => {
      try {
        const resp = await fetch("/api/settings");
        return await resp.json();
      } catch (e) {
        console.error("Failed to load settings:", e);
        return {};
      }
    })();
  }
  return _combinedSettingsPromise;
}

// ===== Seerr =====
async function loadIntegrations() {
  try {
    const data = await _getSettings();
    const el1 = document.getElementById("seerrUrl");
    const el2 = document.getElementById("seerrApiKey");
    if (el1) el1.value = data.seerr_url || "";
    if (el2) el2.value = data.seerr_api_key || "";
  } catch (e) {
    showToast("Einstellungen konnten nicht geladen werden: " + e.message);
  }
}

async function saveSeerrSettings() {
  const url = (document.getElementById("seerrUrl")?.value || "").trim();
  const key = (document.getElementById("seerrApiKey")?.value || "").trim();
  try {
    const resp = await fetch("/api/settings/seerr", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ seerr_url: url, seerr_api_key: key }),
    });
    const data = await resp.json();
    if (data.ok) showToast("Seerr-Einstellungen gespeichert");
    else showToast(data.error || "Fehler beim Speichern");
  } catch (e) {
    showToast("Fehler: " + e.message);
  }
}

// ===== CineInfo =====
async function loadCineinfoSettings() {
  try {
    const data = await _getSettings();
    const d = data.cineinfo || {};

    const keyEl = document.getElementById("cineinfoApiKey");
    const countryEl = document.getElementById("cineinfoCountry");
    const provEl = document.getElementById("cineinfoShowProviders");
    const fskEl = document.getElementById("cineinfoShowFsk");
    const genresEl = document.getElementById("cineinfoShowGenres");
    const ratingEl = document.getElementById("cineinfoShowRating");
    const recEl = document.getElementById("cineinfoShowRecommendations");
    const trailerEl = document.getElementById("cineinfoShowTrailer");
    const hRatingEl = document.getElementById("cineinfoShowHoverRating");
    const hGenresEl = document.getElementById("cineinfoShowHoverGenres");
    const hFskEl = document.getElementById("cineinfoShowHoverFsk");
    const advancedSearchEl = document.getElementById("cineinfoAdvancedSearch");

    if (keyEl) keyEl.value = d.tmdb_api_key || "";
    if (countryEl) countryEl.value = d.country || "DE";
    if (provEl) provEl.checked = d.show_providers !== "0";
    if (fskEl) fskEl.checked = d.show_fsk !== "0";
    if (genresEl) genresEl.checked = d.show_genres === "1";
    if (ratingEl) ratingEl.checked = d.show_rating === "1";
    if (recEl) recEl.checked = d.show_recommendations !== "0";
    if (trailerEl) trailerEl.checked = d.show_trailer !== "0";
    if (hRatingEl) hRatingEl.checked = d.show_hover_rating === "1";
    if (hGenresEl) hGenresEl.checked = d.show_hover_genres === "1";
    if (hFskEl) hFskEl.checked = d.show_hover_fsk === "1";
    if (advancedSearchEl) {
      advancedSearchEl.checked = d.advanced_search === "1";
      const sidebarAdvancedSearch = document.getElementById("sidebarAdvancedSearch");
      if (sidebarAdvancedSearch) {
        sidebarAdvancedSearch.style.display = d.advanced_search === "1" ? "flex" : "none";
      }
    }
  } catch (e) {
    showToast("CineInfo-Einstellungen konnten nicht geladen werden: " + e.message);
  }
}

async function saveCineinfoSettings() {
  const key = (document.getElementById("cineinfoApiKey")?.value || "").trim();
  const country = (document.getElementById("cineinfoCountry")?.value || "DE");
  try {
    const resp = await fetch("/api/settings/cineinfo", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tmdb_api_key: key, country }),
    });
    const data = await resp.json();
    showToast(data.ok ? "CineInfo gespeichert" : (data.error || "Fehler"));
  } catch (e) {
    showToast("Fehler: " + e.message);
  }
}

async function saveCineinfoDisplayOptions() {
  const show_providers = document.getElementById("cineinfoShowProviders")?.checked ? "1" : "0";
  const show_fsk = document.getElementById("cineinfoShowFsk")?.checked ? "1" : "0";
  const show_genres = document.getElementById("cineinfoShowGenres")?.checked ? "1" : "0";
  const show_rating = document.getElementById("cineinfoShowRating")?.checked ? "1" : "0";
  const show_recommendations = document.getElementById("cineinfoShowRecommendations")?.checked ? "1" : "0";
  const show_trailer = document.getElementById("cineinfoShowTrailer")?.checked ? "1" : "0";
  const show_hover_rating = document.getElementById("cineinfoShowHoverRating")?.checked ? "1" : "0";
  const show_hover_genres = document.getElementById("cineinfoShowHoverGenres")?.checked ? "1" : "0";
  const show_hover_fsk = document.getElementById("cineinfoShowHoverFsk")?.checked ? "1" : "0";
  const advanced_search = document.getElementById("cineinfoAdvancedSearch")?.checked ? "1" : "0";

  // Instantly toggle sidebar menu link visibility
  const sidebarAdvancedSearch = document.getElementById("sidebarAdvancedSearch");
  if (sidebarAdvancedSearch) {
    sidebarAdvancedSearch.style.display = advanced_search === "1" ? "flex" : "none";
  }

  try {
    await fetch("/api/settings/cineinfo", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ show_providers, show_fsk, show_genres, show_rating, show_recommendations, show_trailer, show_hover_rating, show_hover_genres, show_hover_fsk, advanced_search }),
    });
  } catch (e) { /* silent */ }
}

// ===== CineInfo Cache =====
async function clearCineinfoCache(btn) {
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Wird geleert…";
  }
  try {
    const resp = await fetch("/api/tmdb/cache/clear", { method: "POST" });
    const data = await resp.json();
    if (data.ok) {
      showToast("Cache geleert — TMDB-Daten werden im Hintergrund neu geladen");
    } else {
      showToast("Fehler beim Leeren des Caches", "error");
    }
  } catch (e) {
    showToast("Fehler: " + e.message, "error");
  } finally {
    if (btn) {
      // Re-enable after a short delay so the user sees feedback
      setTimeout(() => {
        btn.disabled = false;
        btn.textContent = "Cache leeren";
      }, 2000);
    }
  }
}

// ===== Toast =====
function showToast(msg, type) {
  const t = document.getElementById("toast");
  if (!t) return;
  t.textContent = msg;
  t.className = "toast" + (type ? " toast-" + type : "");
  t.style.display = "";
  t.classList.remove("show");
  void t.offsetWidth;
  t.classList.add("show");
  clearTimeout(t._hideTimer);
  t._hideTimer = setTimeout(() => t.classList.remove("show"), 4000);
}

document.addEventListener("DOMContentLoaded", () => {
  loadIntegrations();
  loadCineinfoSettings();
  loadMediaplayerSettings();
  loadMediascanSettings();
});


// ===== Mediaplayer (Jellyfin / Plex) =====
async function loadMediaplayerSettings() {
  try {
    const r = await fetch("/api/settings/mediaplayer");
    const d = await r.json();
    const typeEl = document.getElementById("mediaplayerType");
    if (typeEl) typeEl.value = d.type || "";

    // Jellyfin fields
    const jfUrl = document.getElementById("mediaplayerUrl");
    const jfKey = document.getElementById("mediaplayerApikey");
    const jfSsl = document.getElementById("mediaplayerSsl");
    if (jfUrl) jfUrl.value = _stripScheme(d.url || "");
    if (jfKey) jfKey.value = d.apikey || "";
    if (jfSsl) jfSsl.checked = (d.url || "").startsWith("https://");

    // Plex fields
    const plexUrl = document.getElementById("mediaplayerPlexUrl");
    const plexSect = document.getElementById("mediaplayerPlexSectionId");
    const plexSsl = document.getElementById("mediaplayerPlexSsl");
    if (plexUrl) plexUrl.value = _stripScheme(d.plex_url || "");
    if (plexSect) plexSect.value = d.plex_section || "";
    if (plexSsl) plexSsl.checked = (d.plex_url || "").startsWith("https://");

    // Plex token badge
    _updatePlexTokenBadge(d.has_token, d.apikey);

    onMediaplayerTypeChange();

    // If Plex is configured with a token, pre-load libraries and restore selection
    if (d.type === "plex" && d.has_token) {
      // Store saved ID on select element so loadPlexLibraries can restore it
      const libSel = document.getElementById("mediaplayerPlexSectionId");
      if (libSel) libSel.dataset.saved = d.plex_section || "";
      loadPlexLibraries(d.plex_section || "");
    }
  } catch (e) { /* ignore */ }
}

function _updatePlexTokenBadge(hasToken, token) {
  const badge = document.getElementById("plexTokenBadge");
  if (!badge) return;
  if (hasToken && token) {
    const masked = token.slice(0, 4) + "••••" + token.slice(-4);
    badge.textContent = "✓ Token gespeichert (" + masked + ")";
    badge.style.background = "rgba(34,197,94,.12)";
    badge.style.color = "#4ade80";
    badge.style.border = "1px solid rgba(34,197,94,.3)";
  } else {
    badge.textContent = "Kein Token gespeichert";
    badge.style.background = "rgba(148,163,184,.12)";
    badge.style.color = "var(--text-secondary)";
    badge.style.border = "1px solid var(--border)";
  }
}

function onMediaplayerTypeChange() {
  const svc = (document.getElementById("mediaplayerType")?.value || "");
  const jfFields = document.getElementById("mediaplayerJellyfinFields");
  const plexFields = document.getElementById("mediaplayerPlexFields");
  if (jfFields) jfFields.style.display = svc === "jellyfin" ? "block" : "none";
  if (plexFields) plexFields.style.display = svc === "plex" ? "block" : "none";
}


function _normalizeUrl(raw, useSSL) {
  raw = (raw || "").trim().replace(/\/+$/, "");
  // Strip any existing scheme first
  raw = raw.replace(/^https?:\/\//i, "");
  if (!raw) return "";
  return (useSSL ? "https://" : "http://") + raw;
}

// Strip scheme for display in the input field
function _stripScheme(url) {
  return (url || "").replace(/^https?:\/\//i, "");
}

async function saveMediaplayerSettings() {
  const svc = document.getElementById("mediaplayerType")?.value || "";
  const body = { type: svc };

  if (svc === "jellyfin") {
    const jfSslOn = document.getElementById("mediaplayerSsl")?.checked || false;
    body.url = _normalizeUrl(document.getElementById("mediaplayerUrl")?.value || "", jfSslOn);
    body.apikey = document.getElementById("mediaplayerApikey")?.value || "";
  } else if (svc === "plex") {
    const plexSslOn = document.getElementById("mediaplayerPlexSsl")?.checked || false;
    body.plex_url = _normalizeUrl(document.getElementById("mediaplayerPlexUrl")?.value || "", plexSslOn);
    const libSel = document.getElementById("mediaplayerPlexSectionId");
    body.plex_section = libSel ? libSel.value : "";
    // token is already saved by the OAuth poll – don't overwrite with empty
    const hiddenKey = document.getElementById("mediaplayerPlexApikey");
    if (hiddenKey && hiddenKey.value) body.apikey = hiddenKey.value;
  }

  try {
    const r = await fetch("/api/settings/mediaplayer", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const d = await r.json();
    if (d.ok) showToast("Mediaplayer-Einstellungen gespeichert");
    else showToast(d.error || "Fehler beim Speichern");
  } catch (e) { showToast("Fehler: " + e.message); }
}

// ── Plex OAuth popup ────────────────────────────────────────────────────────
let _plexPollInterval = null;

async function startPlexOAuth() {
  const btn = document.getElementById("plexLoginBtn");
  const status = document.getElementById("plexOAuthStatus");
  if (btn) btn.disabled = true;
  if (status) { status.style.display = "inline"; status.textContent = "Verbinde mit Plex…"; }

  try {
    // Step 1: create pin via backend proxy
    const r = await fetch("/api/settings/mediaplayer/plex-pin", { method: "POST" });
    const d = await r.json();
    if (!d.ok) { _plexOAuthError(d.error || "Pin-Erstellung fehlgeschlagen"); return; }

    // Step 2: open auth popup
    const popup = window.open(d.auth_url, "plex_auth",
      "width=800,height=700,scrollbars=yes,resizable=yes");
    if (!popup) { _plexOAuthError("Popup wurde blockiert – bitte Popup-Blocker deaktivieren"); return; }

    if (status) status.textContent = "Warte auf Plex-Login…";

    // Step 3: poll backend for token
    let attempts = 0;
    _plexPollInterval = setInterval(async () => {
      attempts++;
      if (attempts > 60) {   // 2 min timeout
        clearInterval(_plexPollInterval);
        _plexOAuthError("Timeout – bitte erneut versuchen");
        if (!popup.closed) popup.close();
        if (btn) btn.disabled = false;
        return;
      }
      try {
        const pr = await fetch("/api/settings/mediaplayer/plex-pin/" + d.id);
        const pd = await pr.json();
        if (pd.ok && pd.authorized && pd.token) {
          clearInterval(_plexPollInterval);
          if (!popup.closed) popup.close();
          // Store token in hidden field + update badge
          const hiddenKey = document.getElementById("mediaplayerPlexApikey");
          if (hiddenKey) hiddenKey.value = pd.token;
          _updatePlexTokenBadge(true, pd.token);
          if (status) { status.style.display = "none"; }
          if (btn) btn.disabled = false;
          showToast("\u2713 Plex-Anmeldung erfolgreich!");
          // Auto-save then load libraries
          await saveMediaplayerSettings();
          await loadPlexLibraries();
        }
      } catch (_) { }
    }, 2000);

  } catch (e) {
    _plexOAuthError(e.message);
  }
}

function _plexOAuthError(msg) {
  if (_plexPollInterval) { clearInterval(_plexPollInterval); _plexPollInterval = null; }
  const btn = document.getElementById("plexLoginBtn");
  const status = document.getElementById("plexOAuthStatus");
  if (btn) btn.disabled = false;
  if (status) { status.style.display = "inline"; status.style.color = "#f87171"; status.textContent = "\u2717 " + msg; }
}


// ── SSL toggle ↔ URL input sync ─────────────────────────────────────────────
function onJfSslToggle() {
  // Just visual feedback – actual scheme applied on save
  const url = document.getElementById("mediaplayerUrl");
  if (url) url.placeholder = document.getElementById("mediaplayerSsl")?.checked
    ? "192.168.1.100:8096  (https)"
    : "192.168.1.100:8096";
}
function onPlexSslToggle() {
  const url = document.getElementById("mediaplayerPlexUrl");
  if (url) url.placeholder = document.getElementById("mediaplayerPlexSsl")?.checked
    ? "192.168.1.100:32400  (https)"
    : "192.168.1.100:32400";
}
// Auto-detect scheme if user pastes a full URL with http(s)://
function onJfUrlInput() {
  const url = document.getElementById("mediaplayerUrl");
  const ssl = document.getElementById("mediaplayerSsl");
  if (!url || !ssl) return;
  if (/^https:\/\//i.test(url.value)) { ssl.checked = true; url.value = url.value.replace(/^https:\/\//i, ""); }
  else if (/^http:\/\//i.test(url.value)) { ssl.checked = false; url.value = url.value.replace(/^http:\/\//i, ""); }
}
function onPlexUrlInput() {
  const url = document.getElementById("mediaplayerPlexUrl");
  const ssl = document.getElementById("mediaplayerPlexSsl");
  if (!url || !ssl) return;
  if (/^https:\/\//i.test(url.value)) { ssl.checked = true; url.value = url.value.replace(/^https:\/\//i, ""); }
  else if (/^http:\/\//i.test(url.value)) { ssl.checked = false; url.value = url.value.replace(/^http:\/\//i, ""); }
}
// ── Plex library loader ────────────────────────────────────────────────────
async function loadPlexLibraries(selectedId) {
  const sel = document.getElementById("mediaplayerPlexSectionId");
  const btn = document.getElementById("plexLibLoadBtn");
  if (!sel) return;

  if (btn) { btn.disabled = true; btn.textContent = "…"; }

  try {
    const r = await fetch("/api/settings/mediaplayer/plex-libraries");
    const d = await r.json();

    // Keep "Alle scannen" as first option
    while (sel.options.length > 1) sel.remove(1);

    if (d.ok && d.libraries && d.libraries.length) {
      d.libraries.forEach(lib => {
        const o = document.createElement("option");
        o.value = lib.id;
        o.textContent = lib.title + (lib.type ? "  (" + lib.type + ")" : "");
        sel.appendChild(o);
      });
      // Restore saved selection
      const saved = selectedId !== undefined ? selectedId : sel.dataset.saved || "";
      if (saved) sel.value = saved;
    } else if (!d.ok) {
      showToast("Bibliotheken: " + (d.error || "Fehler"));
    }
  } catch (e) {
    showToast("Bibliotheken konnten nicht geladen werden");
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "↻ Laden"; }
  }
}

// ── Connection test ─────────────────────────────────────────────────────────
async function triggerMediaScan() {
  const btns = ["mediaplayerScanBtn", "mediaplayerScanBtn2"]
    .map(id => document.getElementById(id)).filter(Boolean);
  const toast = msg => { if (typeof showToast === "function") showToast(msg); };
  const setBtns = label => btns.forEach(b => { b.textContent = label; });
  const TIMEOUT_MS = 10 * 60 * 1000; // 10 min max
  const POLL_MS = 2000;
  const NO_SCAN_MAX = 5 * 60 * 1000; // if never seen scanning=true after 5 min, warn

  btns.forEach(b => b.disabled = true);
  setBtns("Wird ausgelöst…");

  // 1. Trigger scan
  try {
    const r = await fetch("/api/settings/mediaplayer/scan", { method: "POST" });
    const d = await r.json();
    if (!d.ok) {
      toast("✗ " + (d.error || "Fehler beim Auslösen"));
      btns.forEach(b => b.disabled = false);
      setBtns("Mediascan testen");
      return;
    }
    console.debug("[MediaScan] Scan ausgelöst:", d.message);
  } catch (e) {
    toast("✗ " + e.message);
    btns.forEach(b => b.disabled = false);
    setBtns("Mediascan testen");
    return;
  }

  // 2. Poll until server reports scanning=true (started), then scanning=false (done)
  setBtns("Scan läuft…");
  const deadline = Date.now() + TIMEOUT_MS;
  const noScanLimit = Date.now() + NO_SCAN_MAX;
  let seenScanning = false;

  const poll = async () => {
    if (Date.now() > deadline) {
      console.warn("[MediaScan] Timeout nach 10 min");
      toast("⚠ Scan-Timeout – möglicherweise läuft er noch im Hintergrund");
      btns.forEach(b => b.disabled = false);
      setBtns("Mediascan testen");
      return;
    }
    try {
      const r = await fetch("/api/settings/mediaplayer/scan-status");
      const d = await r.json();
      console.debug("[MediaScan] Status:", d);
      if (d.scanning) {
        seenScanning = true;
        setTimeout(poll, POLL_MS);
      } else if (seenScanning) {
        console.debug("[MediaScan] Abgeschlossen");
        toast("✓ Mediascan abgeschlossen");
        btns.forEach(b => b.disabled = false);
        setBtns("Mediascan testen");
      } else if (Date.now() > noScanLimit) {
        // Never saw scanning=true after 20s — something may be wrong
        console.warn("[MediaScan] Kein Scan erkannt nach 20s – prüfe Plex/Jellyfin manuell");
        toast("⚠ Kein aktiver Scan erkannt – prüfe ob Plex/Jellyfin scant");
        btns.forEach(b => b.disabled = false);
        setBtns("Mediascan testen");
      } else {
        // Not scanning yet — give it more time to start
        setTimeout(poll, POLL_MS);
      }
    } catch (e) {
      console.warn("[MediaScan] Poll-Fehler:", e.message);
      setTimeout(poll, POLL_MS);
    }
  };

  setTimeout(poll, 1500); // short delay to let server start the scan
}


async function testMediaplayerConnection() {
  const svc = document.getElementById("mediaplayerType")?.value || "";
  const resultId = svc === "plex" ? "mediaplayerTestResult2" : "mediaplayerTestResult";
  const btnId = svc === "plex" ? "mediaplayerTestBtn2" : "mediaplayerTestBtn";
  const btn = document.getElementById(btnId);
  const result = document.getElementById(resultId);
  if (btn) btn.disabled = true;
  if (result) { result.style.display = "none"; result.textContent = ""; }
  try {
    await saveMediaplayerSettings();
    const r = await fetch("/api/settings/mediaplayer/test", { method: "POST" });
    const d = await r.json();
    if (result) {
      result.style.display = "block";
      result.style.background = d.ok ? "rgba(34,197,94,.12)" : "rgba(239,68,68,.12)";
      result.style.color = d.ok ? "#4ade80" : "#f87171";
      result.style.border = "1px solid " + (d.ok ? "rgba(34,197,94,.3)" : "rgba(239,68,68,.3)");
      result.textContent = d.ok
        ? "\u2713 Verbunden mit: " + (d.name || "Server")
        : "\u2717 " + (d.error || "Verbindung fehlgeschlagen");
    }
  } catch (e) {
    if (result) {
      result.style.display = "block";
      result.style.color = "#f87171";
      result.textContent = "\u2717 " + e.message;
    }
  } finally {
    if (btn) btn.disabled = false;
  }
}


// ===== MediaScan =====

let _mediascanPollTimer  = null;
async function loadMediascanSettings() {
  try {
    const resp = await fetch("/api/settings/mediascan");
    const d    = await resp.json();

    const enabledEl = document.getElementById("mediascanEnabled");
    const sourceEl  = document.getElementById("mediascanSource");
    if (enabledEl) enabledEl.checked = !!d.enabled;
    if (sourceEl && d.source) sourceEl.value = d.source;

    // Jellyfin fields
    const jfUrl    = document.getElementById("mediascanJfUrl");
    const jfKey    = document.getElementById("mediascanJfApikey");
    const jfSsl    = document.getElementById("mediascanJfSsl");
    if (jfUrl) jfUrl.value     = d.jf_url    || "";
    if (jfKey) jfKey.value     = d.jf_apikey || "";
    if (jfSsl) jfSsl.checked   = !!d.jf_ssl;

    // Plex fields
    const plexUrl  = document.getElementById("mediascanPlexUrl");
    const plexSsl  = document.getElementById("mediascanPlexSsl");
    const plexSect = document.getElementById("mediascanPlexSection");
    if (plexUrl)  plexUrl.value  = d.plex_url     || "";
    if (plexSsl)  plexSsl.checked = !!d.plex_ssl;
    if (plexSect) plexSect.dataset.saved = d.plex_section || "";

    _updateMsPlexTokenBadge(d.has_plex_token, d.plex_token_masked);
    _applyMediascanUI(d);
    _updateMediascanStatusUI(d);

    // Restore Plex library list if token present
    if (d.source === "plex" && d.has_plex_token) loadMsPlexLibraries(d.plex_section || "");

    // If a scan is running (started before user navigated away) keep polling
    if (d.scan_running) _startMediascanPoll();
  } catch (e) { /* best-effort */ }
}

function _updateMsPlexTokenBadge(hasToken, masked) {
  const badge = document.getElementById("msPlexTokenBadge");
  if (!badge) return;
  if (hasToken) {
    badge.textContent = "✓ Token gespeichert (" + (masked || "••••") + ")";
    badge.style.background = "rgba(34,197,94,.12)";
    badge.style.color = "#4ade80";
    badge.style.border = "1px solid rgba(34,197,94,.3)";
  } else {
    badge.textContent = "Kein Token gespeichert";
    badge.style.background = "rgba(148,163,184,.12)";
    badge.style.color = "var(--text-secondary)";
    badge.style.border = "1px solid var(--border)";
  }
}

function onMediascanToggle() {
  const en = document.getElementById("mediascanEnabled")?.checked;
  const fields = document.getElementById("mediascanFields");
  if (fields) fields.style.display = en ? "block" : "none";
  saveMediascanSettings();
}

function onMediascanSourceChange() {
  const source = document.getElementById("mediascanSource")?.value || "";
  document.getElementById("mediascanJellyfinFields").style.display = source === "jellyfin" ? "block" : "none";
  document.getElementById("mediascanPlexFields").style.display     = source === "plex"     ? "block" : "none";
  saveMediascanSettings();
}

function _applyMediascanUI(d) {
  const en     = !!d.enabled;
  const source = d.source || "";
  const fields = document.getElementById("mediascanFields");
  if (fields) fields.style.display = en ? "block" : "none";

  // Show/hide source-specific fields
  const jfF   = document.getElementById("mediascanJellyfinFields");
  const plexF = document.getElementById("mediascanPlexFields");
  if (jfF)   jfF.style.display   = source === "jellyfin" ? "block" : "none";
  if (plexF) plexF.style.display = source === "plex"     ? "block" : "none";

  // TMDB warning
  const warn = document.getElementById("mediascanNoTmdbWarn");
  if (warn) warn.style.display = en && source && source !== "folders" && !d.has_tmdb ? "block" : "none";

  // Status card
  const card = document.getElementById("mediascanStatusCard");
  if (card) card.style.display = en && source && source !== "folders" ? "block" : "none";
}

function _formatRelTime(ts) {
  if (!ts) return "—";
  const diff = Math.round((Date.now() / 1000) - ts);
  if (diff < 60)  return "Gerade eben";
  if (diff < 3600) return `vor ${Math.round(diff/60)} Min.`;
  if (diff < 86400) return `vor ${Math.round(diff/3600)} Std.`;
  return `vor ${Math.round(diff/86400)} Tag(en)`;
}

function _updateMediascanStatusUI(d) {
  const lastEl   = document.getElementById("mediascanLastUpdated");
  const countEl  = document.getElementById("mediascanCount");
  const statusEl = document.getElementById("mediascanScanStatus");
  const progWrap = document.getElementById("mediascanProgressWrap");
  const progBar  = document.getElementById("mediascanProgressBar");
  const progText = document.getElementById("mediascanProgressText");
  const progPct  = document.getElementById("mediascanProgressPct");
  const refreshBtn = document.getElementById("mediascanRefreshBtn");

  if (lastEl)  lastEl.textContent  = _formatRelTime(d.last_updated || d.scan_finished);
  if (countEl) countEl.textContent = d.cached_count !== undefined ? `${d.cached_count} Einträge` : (d.count ? `${d.count} Einträge` : "—");

  if (d.scan_running || d.running) {
    // Show progress
    if (progWrap) progWrap.style.display = "block";
    if (statusEl) statusEl.textContent = "Scan läuft…";
    if (refreshBtn) { refreshBtn.disabled = true; refreshBtn.textContent = "Scan läuft…"; }

    const total = d.scan_total || d.total || 0;
    const done  = d.scan_count || d.count || 0;
    if (total > 0) {
      const pct = Math.min(100, Math.round((done / total) * 100));
      if (progBar) { progBar.classList.remove("indeterminate"); progBar.style.width = pct + "%"; }
      if (progText) progText.textContent = `${done} / ${total} Einträge`;
      if (progPct)  progPct.textContent  = pct + "%";
    } else {
      if (progBar) { progBar.classList.add("indeterminate"); progBar.style.width = "40%"; }
      if (progText) progText.textContent = "Scan läuft…";
      if (progPct)  progPct.textContent  = "";
    }
  } else {
    // Scan idle
    if (progWrap) progWrap.style.display = "none";
    if (refreshBtn) { refreshBtn.disabled = false; refreshBtn.textContent = "↻ Mediathek jetzt aktualisieren"; }

    if (d.scan_error || d.error) {
      if (statusEl) {
        statusEl.textContent = "Fehler";
        statusEl.style.color = "#f87171";
      }
    } else if (d.scan_finished || d.finished_at) {
      if (statusEl) {
        statusEl.textContent = "Bereit";
        statusEl.style.color = "#4ade80";
      }
    } else {
      if (statusEl) { statusEl.textContent = "Noch kein Scan"; statusEl.style.color = ""; }
    }
  }
}

// ── URL input helpers ─────────────────────────────────────────────────────
function onMsJfUrlInput() {
  const url = document.getElementById("mediascanJfUrl");
  const ssl = document.getElementById("mediascanJfSsl");
  if (!url || !ssl) return;
  if (/^https:\/\//i.test(url.value)) { ssl.checked = true;  url.value = url.value.replace(/^https:\/\//i, ""); }
  else if (/^http:\/\//i.test(url.value)) { ssl.checked = false; url.value = url.value.replace(/^http:\/\//i, ""); }
}
function onMsPlexUrlInput() {
  const url = document.getElementById("mediascanPlexUrl");
  const ssl = document.getElementById("mediascanPlexSsl");
  if (!url || !ssl) return;
  if (/^https:\/\//i.test(url.value)) { ssl.checked = true;  url.value = url.value.replace(/^https:\/\//i, ""); }
  else if (/^http:\/\//i.test(url.value)) { ssl.checked = false; url.value = url.value.replace(/^http:\/\//i, ""); }
}

async function saveMediascanSettings() {
  const enabled = document.getElementById("mediascanEnabled")?.checked || false;
  const source  = document.getElementById("mediascanSource")?.value    || "";
  const body = { enabled, source };

  if (source === "jellyfin") {
    body.jf_url    = document.getElementById("mediascanJfUrl")?.value    || "";
    body.jf_apikey = document.getElementById("mediascanJfApikey")?.value || "";
    body.jf_ssl    = document.getElementById("mediascanJfSsl")?.checked  || false;
  } else if (source === "plex") {
    body.plex_url     = document.getElementById("mediascanPlexUrl")?.value || "";
    body.plex_ssl     = document.getElementById("mediascanPlexSsl")?.checked || false;
    const sect = document.getElementById("mediascanPlexSection");
    body.plex_section = sect ? sect.value : "";
  }

  try {
    const r = await fetch("/api/settings/mediascan", {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const d = await r.json();
    if (d.ok) showToast("MediaScan gespeichert");
    else showToast(d.error || "Fehler beim Speichern");
    await loadMediascanSettings();
  } catch (e) {
    showToast("Fehler: " + e.message);
  }
}

// ── Plex OAuth (reuses the same backend pin endpoints as Mediaplayer) ──────
let _msPollInterval = null;

async function startMsPlexOAuth() {
  const btn    = document.getElementById("msPlexLoginBtn");
  const status = document.getElementById("msPlexOAuthStatus");
  if (btn) btn.disabled = true;
  if (status) { status.style.display = "inline"; status.textContent = "Verbinde mit Plex…"; }
  try {
    const r = await fetch("/api/settings/mediaplayer/plex-pin", { method: "POST" });
    const d = await r.json();
    if (!d.ok) { _msPlexOAuthError(d.error || "Pin-Erstellung fehlgeschlagen"); return; }
    const popup = window.open(d.auth_url, "plex_auth_ms", "width=800,height=700,scrollbars=yes,resizable=yes");
    if (!popup) { _msPlexOAuthError("Popup blockiert — bitte Popup-Blocker deaktivieren"); return; }
    if (status) status.textContent = "Warte auf Plex-Login…";
    let attempts = 0;
    _msPollInterval = setInterval(async () => {
      attempts++;
      if (attempts > 60) {
        clearInterval(_msPollInterval);
        _msPlexOAuthError("Timeout");
        if (!popup.closed) popup.close();
        if (btn) btn.disabled = false;
        return;
      }
      try {
        const pr = await fetch("/api/settings/mediaplayer/plex-pin/" + d.id);
        const pd = await pr.json();
        if (pd.ok && pd.authorized && pd.token) {
          clearInterval(_msPollInterval);
          if (!popup.closed) popup.close();
          _updateMsPlexTokenBadge(true, pd.token.slice(0,4) + "••••" + pd.token.slice(-4));
          if (status) status.style.display = "none";
          if (btn) btn.disabled = false;
          showToast("✓ Plex-Anmeldung erfolgreich!");
          await saveMediascanSettings();
          await loadMsPlexLibraries();
        }
      } catch (_) {}
    }, 2000);
  } catch (e) { _msPlexOAuthError(e.message); }
}

function _msPlexOAuthError(msg) {
  if (_msPollInterval) { clearInterval(_msPollInterval); _msPollInterval = null; }
  const btn    = document.getElementById("msPlexLoginBtn");
  const status = document.getElementById("msPlexOAuthStatus");
  if (btn) btn.disabled = false;
  if (status) { status.style.display = "inline"; status.style.color = "#f87171"; status.textContent = "✗ " + msg; }
}

async function loadMsPlexLibraries(selectedId) {
  const sel = document.getElementById("mediascanPlexSection");
  const btn = document.getElementById("msPlexLibLoadBtn");
  if (!sel) return;
  if (btn) { btn.disabled = true; btn.textContent = "…"; }
  try {
    const r = await fetch("/api/settings/mediascan/plex-libraries");
    const d = await r.json();
    while (sel.options.length > 1) sel.remove(1);
    if (d.ok && d.libraries && d.libraries.length) {
      d.libraries.forEach(lib => {
        const o = document.createElement("option");
        o.value = lib.id;
        o.textContent = lib.title + (lib.type ? "  (" + lib.type + ")" : "");
        sel.appendChild(o);
      });
      const saved = selectedId !== undefined ? selectedId : sel.dataset.saved || "";
      if (saved) sel.value = saved;
    } else if (!d.ok) {
      showToast("Bibliotheken: " + (d.error || "Fehler"));
    }
  } catch (e) {
    showToast("Bibliotheken konnten nicht geladen werden");
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "↻ Laden"; }
  }
}

async function triggerMediascanRefresh() {
  const btn = document.getElementById("mediascanRefreshBtn");
  if (btn) { btn.disabled = true; btn.textContent = "Wird gestartet…"; }

  try {
    const r = await fetch("/api/settings/mediascan/refresh", { method: "POST" });
    const d = await r.json();
    if (!d.ok) {
      showToast("✗ " + (d.error || "Fehler beim Starten"), "error");
      if (btn) { btn.disabled = false; btn.textContent = "↻ Mediathek jetzt aktualisieren"; }
      return;
    }
    showToast("Scan gestartet…");
    _startMediascanPoll();
  } catch (e) {
    showToast("Fehler: " + e.message, "error");
    if (btn) { btn.disabled = false; btn.textContent = "↻ Mediathek jetzt aktualisieren"; }
  }
}

function _startMediascanPoll() {
  if (_mediascanPollTimer) clearInterval(_mediascanPollTimer);
  _mediascanPollTimer = setInterval(async () => {
    try {
      const r = await fetch("/api/settings/mediascan/status");
      const d = await r.json();
      _updateMediascanStatusUI(d);
      if (!d.running) {
        clearInterval(_mediascanPollTimer);
        _mediascanPollTimer = null;
        if (d.error) showToast("✗ Scan fehlgeschlagen: " + d.error, "error");
        else showToast("✓ Mediathek aktualisiert — " + (d.cached_count || d.count || 0) + " Einträge");
        // Update last-updated display
        const lastEl = document.getElementById("mediascanLastUpdated");
        if (lastEl) lastEl.textContent = _formatRelTime(d.last_updated || d.finished_at);
        const countEl = document.getElementById("mediascanCount");
        if (countEl) countEl.textContent = (d.cached_count || d.count || 0) + " Einträge";
      }
    } catch (_) { /* network hiccup — keep polling */ }
  }, 1500);
}
