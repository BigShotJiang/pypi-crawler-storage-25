// Auto-Sync page logic

const autosyncList = document.getElementById("autosyncList");
const autosyncEmpty = document.getElementById("autosyncEmpty");

// Schedule map for computing next check time
const SCHEDULE_INTERVALS = {
  "1min": 60,
  "30min": 1800,
  "1h": 3600,
  "2h": 7200,
  "4h": 14400,
  "8h": 28800,
  "12h": 43200,
  "16h": 57600,
  "24h": 86400,
};
const SCHEDULE_LABELS = {
  "1min": "1 min",
  "30min": "30 min",
  "1h": "1h",
  "2h": "2h",
  "4h": "4h",
  "8h": "8h",
  "12h": "12h",
  "16h": "16h",
  "24h": "24h",
};

let currentSyncSchedule = "0";
let customPathsCache = [];
let langSepEnabled = false;
let _runningJobs = new Set();
let _pollTimer = null;

async function pollRunningJobs() {
  try {
    const res = await fetch("/api/autosync/running");
    const data = await res.json();
    const nowRunning = new Set(data.running || []);
    const changed = nowRunning.size !== _runningJobs.size ||
      [...nowRunning].some(id => !_runningJobs.has(id)) ||
      [..._runningJobs].some(id => !nowRunning.has(id));
    _runningJobs = nowRunning;
    if (changed) loadAutosyncJobs();
    if (_runningJobs.size > 0) {
      _pollTimer = setTimeout(pollRunningJobs, 3000);
    } else {
      _pollTimer = null;
    }
  } catch (_) {}
}

function startPollingIfNeeded() {
  if (_runningJobs.size > 0 && !_pollTimer) {
    _pollTimer = setTimeout(pollRunningJobs, 3000);
  }
}

async function loadSyncSchedule() {
  try {
    const resp = await fetch("/api/settings");
    const data = await resp.json();
    currentSyncSchedule = data.sync_schedule || "0";
    langSepEnabled = data.lang_separation === "1";
  } catch (e) {
    /* ignore */
  }
}

async function loadCustomPathsForEdit() {
  try {
    const resp = await fetch("/api/custom-paths");
    const data = await resp.json();
    customPathsCache = data.paths || [];
  } catch (e) {
    customPathsCache = [];
  }
}

async function loadAutosyncJobs() {
  try {
    // Lade Custom Paths IMMER vor dem Rendern
    await loadCustomPathsForEdit();
    const [jobsRes, runningRes] = await Promise.all([
      fetch("/api/autosync"),
      fetch("/api/autosync/running"),
    ]);
    const jobsData = await jobsRes.json();
    const runningData = await runningRes.json();
    _runningJobs = new Set(runningData.running || []);
    renderJobs(jobsData.jobs || []);
    startPollingIfNeeded();
  } catch (e) {
    let msg = 'Sync-Jobs konnten nicht geladen werden.';
    if (e && e.stack) {
      msg += '<br><pre style="color:#f87171;font-size:.9em">' + esc(e.stack) + '</pre>';
    } else if (e && e.message) {
      msg += '<br><pre style="color:#f87171;font-size:.9em">' + esc(e.message) + '</pre>';
    }
    autosyncList.innerHTML = '<div class="queue-empty">' + msg + '</div>';
    console.error('Fehler beim Laden der Sync-Jobs:', e);
  }
}

function computeNextCheck(lastCheck) {
  if (!lastCheck || currentSyncSchedule === "0") return "—";
  const interval = SCHEDULE_INTERVALS[currentSyncSchedule];
  if (!interval) return "—";
  const lastMs = new Date(lastCheck + "Z").getTime();
  const nextMs = lastMs + interval * 1000;
  const now = Date.now();
  if (!nextMs || nextMs <= now) return "Bald";
  return formatDate(
    new Date(nextMs)
      .toISOString()
      .replace("Z", "")
      .replace("T", " ")
      .slice(0, 19),
  );
}

function renderJobs(jobs) {
  // Keep currentJobs in sync for batch ops
  currentJobs = jobs;
  // Populate batch path dropdown
  const batchPath = document.getElementById("batchPathSelect");
  if (batchPath) {
    while (batchPath.options.length > 1) batchPath.remove(1);
    customPathsCache.forEach(p => {
      const o = document.createElement("option");
      o.value = p.id; o.textContent = p.name + " (" + p.path + ")";
      batchPath.appendChild(o);
    });
  }
  _updateBatchToolbar();
  if (!jobs.length) {
    autosyncList.innerHTML =
      '<div class="queue-empty">Noch keine Sync-Jobs. Füge eine Serie über die Suchseite hinzu.</div>';
    return;
  }

  let html = '<div class="sync-card-grid">';

  for (const job of jobs) {
    const isRunning = _runningJobs.has(job.id);
    const isOnHold = !isRunning && job.on_hold;
    const statusClass = isRunning
      ? "queue-status-running"
      : isOnHold
      ? "queue-status-hold"
      : job.enabled
      ? "queue-status-completed"
      : "queue-status-queued";
    const statusLabel = isRunning
      ? '<span class="sync-spinner"></span>Läuft…'
      : isOnHold
      ? '⏸ Hold'
      : job.enabled ? "Aktiviert" : "Deaktiviert";

    const lastCheck = job.last_check ? formatDate(job.last_check) : "—";
    const nextCheck = job.enabled ? computeNextCheck(job.last_check) : "—";
    const lastNew = job.last_new_found ? formatDate(job.last_new_found) : "—";

    let dlPath = "Standard";
    if (job.custom_path_id != null && job.custom_path_id !== "") {
      const cp = customPathsCache.find((p) => String(p.id) === String(job.custom_path_id));
      dlPath = cp ? cp.name : "Custom #" + job.custom_path_id;
    }

    const localCount = job.local_episodes_found != null ? job.local_episodes_found : "?";
    const newCount = job.last_new_count || 0;

    let lastResultHtml;
    if (!job.last_check) {
      lastResultHtml = '<span class="sync-stat-neutral">—</span>';
    } else if (newCount > 0) {
      lastResultHtml = '<span class="sync-stat-new">✓ ' + newCount + ' neu</span>';
    } else {
      lastResultHtml = '<span class="sync-stat-neutral">Aktuell</span>';
    }

    const syncBtnDisabled = isRunning ? ' disabled style="opacity:.4;cursor:not-allowed"' : '';

    html +=
      '<div class="sync-card">' +
        '<div class="sync-card-header">' +
          (autosyncCanManage ? '<label class="sync-card-cb-wrap" onclick="event.stopPropagation()" title="Auswählen"><input type="checkbox" class="sync-card-checkbox" ' + (selectedJobIds.has(job.id) ? 'checked' : '') + ' onchange="toggleJobSelection(' + job.id + ', this.checked)" /></label>' : '') +
          '<div class="sync-card-title" title="' + esc(job.series_url) + '">' + esc(job.title) + '</div>' +
          '<span class="queue-status ' + statusClass + '">' + statusLabel + '</span>' +
        '</div>' +

        '<div class="sync-card-pills">' +
          '<span class="queue-meta-pill">' + esc(job.language) + '</span>' +
          '<span class="queue-meta-pill">' + esc(job.provider) + '</span>' +
          '<span class="queue-meta-pill">' + esc(dlPath) + '</span>' +
          (job.added_by ? '<span class="queue-meta-pill queue-user">' + esc(job.added_by) + '</span>' : '') +
        '</div>' +

        '<div class="sync-card-stats">' +
          '<div class="sync-stat-row">' +
            '<span class="sync-stat-label">Episoden</span>' +
            '<span class="sync-stat-value" title="' + localCount + ' lokal / ' + job.episodes_found + ' online">' +
              localCount + ' / ' + job.episodes_found +
            '</span>' +
          '</div>' +
          '<div class="sync-stat-row">' +
            '<span class="sync-stat-label">Letztes Ergebnis</span>' +
            '<span class="sync-stat-value">' + lastResultHtml + '</span>' +
          '</div>' +
          '<div class="sync-stat-row">' +
            '<span class="sync-stat-label">Zuletzt geprüft</span>' +
            '<span class="sync-stat-value">' + lastCheck + '</span>' +
          '</div>' +
          '<div class="sync-stat-row">' +
            '<span class="sync-stat-label">Nächste Prüfung</span>' +
            '<span class="sync-stat-value">' + nextCheck + '</span>' +
          '</div>' +
          (lastNew !== '—' ? '<div class="sync-stat-row">' +
            '<span class="sync-stat-label">Zuletzt neu</span>' +
            '<span class="sync-stat-value">' + lastNew + '</span>' +
          '</div>' : '') +
        '</div>' +

        (job.last_error
          ? '<div class="sync-error-row"><strong>Fehler:</strong>' + esc(job.last_error) + '</div>'
          : '') +

        '<div class="sync-card-actions">' +
          (autosyncCanManage ? '<button class="queue-move sync-card-btn" onclick="openEditModal(' + job.id + ')" title="Bearbeiten">✎ Bearbeiten</button>' : '') +
          '<button class="queue-move sync-card-btn sync-card-btn-sync" onclick="syncNow(' + job.id + ')" title="Jetzt synchronisieren"' + syncBtnDisabled + '>⟳ Sync</button>' +
          (autosyncCanManage ? '<button class="queue-remove sync-card-btn" onclick="removeJob(' + job.id + ')" title="Entfernen">✕</button>' : '') +
        '</div>' +
      '</div>';
  }

  html += '</div>';
  autosyncList.innerHTML = html;
}

function formatDate(isoStr) {
  if (!isoStr) return "—";
  const d = new Date(isoStr + "Z");
  if (isNaN(d.getTime())) {
    // Try without adding Z (already formatted)
    const d2 = new Date(isoStr);
    if (isNaN(d2.getTime())) return "—";
    const pad = (n) => String(n).padStart(2, "0");
    return (
      pad(d2.getDate()) +
      "." +
      pad(d2.getMonth() + 1) +
      "." +
      d2.getFullYear() +
      " " +
      pad(d2.getHours()) +
      ":" +
      pad(d2.getMinutes())
    );
  }
  const pad = (n) => String(n).padStart(2, "0");
  return (
    pad(d.getDate()) +
    "." +
    pad(d.getMonth() + 1) +
    "." +
    d.getFullYear() +
    " " +
    pad(d.getHours()) +
    ":" +
    pad(d.getMinutes())
  );
}

async function syncNow(id) {
  try {
    const res = await fetch("/api/autosync/" + id + "/sync", {
      method: "POST",
    });
    const data = await res.json();
    if (data.ok) {
      showToast("Sync gestartet");
      _runningJobs.add(id);
      startPollingIfNeeded();
      setTimeout(loadAutosyncJobs, 500);
    } else {
      showToast(data.error || "Sync konnte nicht gestartet werden");
    }
  } catch (e) {
    showToast("Sync konnte nicht gestartet werden");
  }
}

async function syncAll() {
  const btn = document.getElementById("syncAllBtn");
  if (btn) { btn.disabled = true; btn.textContent = "Synchronisiere…"; }
  try {
    const res = await fetch("/api/autosync/sync-all", { method: "POST" });
    const data = await res.json();
    if (data.ok) {
      const msg = data.started > 0
        ? `${data.started} Job(s) gestartet${data.skipped > 0 ? `, ${data.skipped} bereits aktiv` : ""}`
        : "Keine Jobs zum Starten (alle bereits aktiv oder deaktiviert)";
      showToast(msg);
      setTimeout(loadAutosyncJobs, 2000);
    } else {
      showToast(data.error || "Fehler beim Starten");
    }
  } catch (e) {
    showToast("Fehler beim Starten aller Syncs");
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = "Alle synchronisieren"; }
  }
}

async function removeJob(id) {
  if (!await showConfirm("Diesen Sync-Job entfernen?")) return;
  try {
    const res = await fetch("/api/autosync/" + id, { method: "DELETE" });
    const data = await res.json();
    if (data.ok) {
      showToast("Sync-Job entfernt");
      loadAutosyncJobs();
    } else {
      showToast(data.error || "Entfernen fehlgeschlagen");
    }
  } catch (e) {
    showToast("Sync-Job konnte nicht entfernt werden");
  }
}

// Edit modal
let currentJobs = [];
let selectedJobIds = new Set();

function _updateBatchToolbar() {
  const toolbar   = document.getElementById("batchToolbar");
  const label     = document.getElementById("batchSelectionLabel");
  const selectAll = document.getElementById("selectAllCheckbox");
  if (!toolbar) return;
  const count = selectedJobIds.size;
  toolbar.style.display = count > 0 ? "flex" : "none";
  if (label) label.textContent = count + " ausgewählt";
  // sync selectAll state
  if (selectAll) {
    const total = currentJobs.length;
    selectAll.checked       = count > 0 && count === total;
    selectAll.indeterminate = count > 0 && count < total;
  }
}

function toggleJobSelection(id, checked) {
  if (checked) selectedJobIds.add(id);
  else         selectedJobIds.delete(id);
  _updateBatchToolbar();
}

function toggleSelectAll(checked) {
  selectedJobIds.clear();
  if (checked) currentJobs.forEach(j => selectedJobIds.add(j.id));
  // re-render checkboxes without full reload
  document.querySelectorAll(".sync-card-checkbox").forEach(cb => {
    cb.checked = checked;
  });
  _updateBatchToolbar();
}

function clearSelection() {
  selectedJobIds.clear();
  document.querySelectorAll(".sync-card-checkbox").forEach(cb => { cb.checked = false; });
  _updateBatchToolbar();
}

async function openEditModal(id) {
  try {
    const res = await fetch("/api/autosync");
    const data = await res.json();
    currentJobs = data.jobs || [];
    const job = currentJobs.find((j) => j.id === id);
    if (!job) {
      showToast("Job nicht gefunden");
      return;
    }

    document.getElementById("editJobId").value = id;
    document.getElementById("editJobTitle").textContent =
      job.title || "Unbekannt";

    // Rebuild language dropdown based on lang separation setting
    const langSelect = document.getElementById("editLanguage");
    langSelect.innerHTML = "";
    if (langSepEnabled) {
      const opt = document.createElement("option");
      opt.value = "All Languages";
      opt.textContent = "Alle Sprachen";
      langSelect.appendChild(opt);
    }
    ["German Dub", "English Sub", "German Sub", "English Dub"].forEach((l) => {
      const opt = document.createElement("option");
      opt.value = l;
      opt.textContent = l;
      langSelect.appendChild(opt);
    });
    langSelect.value = job.language || "German Dub";

    document.getElementById("editProvider").value = job.provider || "VOE";
    document.getElementById("editEnabled").value = job.enabled ? "1" : "0";

    // Populate path dropdown
    const pathSelect = document.getElementById("editPath");
    while (pathSelect.options.length > 1) pathSelect.remove(1);
    await loadCustomPathsForEdit();
    customPathsCache.forEach(function (p) {
      const opt = document.createElement("option");
      opt.value = p.id;
      opt.textContent = p.name + " (" + p.path + ")";
      pathSelect.appendChild(opt);
    });
    pathSelect.value = job.custom_path_id ? String(job.custom_path_id) : "";

    const pathActionSelect = document.getElementById("editPathUnavailableAction");
    if (pathActionSelect) {
      pathActionSelect.value = job.path_unavailable_action || "skip";
    }

    document.getElementById("editOverlay").style.display = "block";
  } catch (e) {
    showToast("Job konnte nicht geladen werden");
  }
}

function closeEditModal() {
  document.getElementById("editOverlay").style.display = "none";
}

async function saveEdit() {
  const id = document.getElementById("editJobId").value;
  const pathVal = document.getElementById("editPath").value;
  const pathActionEl = document.getElementById("editPathUnavailableAction");
  const body = {
    language: document.getElementById("editLanguage").value,
    provider: document.getElementById("editProvider").value,
    enabled: parseInt(document.getElementById("editEnabled").value),
    custom_path_id: pathVal ? parseInt(pathVal) : null,
    path_unavailable_action: pathActionEl ? pathActionEl.value : "skip",
  };
  try {
    const res = await fetch("/api/autosync/" + id, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (data.ok) {
      showToast("Job aktualisiert");
      closeEditModal();
      loadAutosyncJobs();
    } else {
      showToast(data.error || "Aktualisierung fehlgeschlagen");
    }
  } catch (e) {
    showToast("Job konnte nicht aktualisiert werden");
  }
}

function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.style.display = "block";
  clearTimeout(t._timer);
  t._timer = setTimeout(() => {
    t.style.display = "none";
  }, 3000);
}

function esc(s) {
  const d = document.createElement("div");
  d.textContent = s || "";
  return d.innerHTML;
}

// Init
Promise.all([loadSyncSchedule()]).then(loadAutosyncJobs);
setInterval(loadAutosyncJobs, 30000);

// ===== Export =====
async function exportAutosync() {
  try {
    const r = await fetch("/api/autosync/export");
    if (!r.ok) { showToast("Export fehlgeschlagen"); return; }
    const blob = await r.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "autosync_backup.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    showToast("Export erfolgreich");
  } catch(e) {
    showToast("Export fehlgeschlagen: " + e.message);
  }
}

// ===== Import =====
async function importAutosync(input) {
  const file = input.files[0];
  if (!file) return;
  input.value = "";  // reset so same file can be re-selected
  try {
    const text = await file.text();
    const r = await fetch("/api/autosync/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: text,
    });
    const d = await r.json();
    if (!r.ok || d.error) { showToast(d.error || "Import fehlgeschlagen"); return; }
    let msg = d.imported + " importiert";
    if (d.skipped)  msg += ", " + d.skipped + " übersprungen";
    if (d.errors && d.errors.length) msg += ", " + d.errors.length + " Fehler";
    showToast(msg);
    loadAutosyncJobs();
  } catch(e) {
    showToast("Import fehlgeschlagen: " + e.message);
  }
}

// ===== Batch =====
async function batchAction(action) {
  const ids = [...selectedJobIds];
  if (!ids.length) return;

  let body = { ids, action };
  if (action === "set_path") {
    const sel = document.getElementById("batchPathSelect");
    const val = sel ? sel.value : "";
    body.custom_path_id = val ? parseInt(val) : null;
  }

  if (action === "delete") {
    const ok = await showConfirm(`${ids.length} Sync-Job(s) wirklich löschen?`);
    if (!ok) return;
  }

  try {
    const r = await fetch("/api/autosync/batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const d = await r.json();
    if (d.ok) {
      const label = { enable: "aktiviert", disable: "deaktiviert", set_path: "Pfad gesetzt", delete: "gelöscht" }[action] || "aktualisiert";
      showToast(d.updated + " Job(s) " + label);
      clearSelection();
      loadAutosyncJobs();
    } else {
      showToast(d.error || "Batch-Aktion fehlgeschlagen");
    }
  } catch(e) {
    showToast("Batch-Aktion fehlgeschlagen: " + e.message);
  }
}
