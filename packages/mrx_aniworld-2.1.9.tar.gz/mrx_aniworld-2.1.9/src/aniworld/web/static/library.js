// ============================================================
// Mediathek — File Explorer
// ============================================================

var libLangSep       = false;
var libLocations     = [];
var libAllTargets    = [];
var libScanPollTimer = null;
var libIdlePollTimer = null;  // slow background poll to catch watcher-triggered rescans
var libLastUpdated   = 0;     // scanned_at timestamp of the last full render
var libSearchQuery   = "";    // current search filter
var _libSearchTimer  = null;  // debounce timer for search input
var libSortKey       = "name"; // "name" | "size" | "episodes"
var libSortAsc       = true;   // ascending = true
var libFilterMode    = "all";  // "all" | "series" | "movies"

// Persistent open-state — updated by libToggle on every expand/collapse so
// re-renders triggered by the idle poll / watcher never collapse open items.
var _libOpenState = {
  locs:    new Set(),   // location body IDs  (positional: "libLocBody0")
  lf:      new Set(),   // lang-folder body IDs ("libLFBody0_1")
  titles:  new Set(),   // "folder|cpId|langFolder"
  seasons: new Set(),   // "folder|cpId|langFolder|sN"
};

// ---- Boot ----

async function libLoad(forceRefresh) {
  if (forceRefresh) {
    var refreshResp = await fetch("/api/library/refresh", { method: "POST" });
    var refreshData = await refreshResp.json();
  }
  await libFetch();
}

async function libFetch() {
  try {
    var resp = await fetch("/api/library");
    var data = await resp.json();
    libLangSep   = !!data.lang_sep;
    libLocations = data.locations || [];
    libAllTargets = libLocations.map(function(loc) {
      return { label: loc.label, custom_path_id: loc.custom_path_id };
    });

    // Track when we last rendered so the idle poll can detect watcher updates
    libLastUpdated = data.last_updated || 0;

    // Use persistent open-state (maintained by libToggle) — no DOM capture needed
    libRender(libLocations, _libOpenState);
    libUpdateWatcherStatus(data.watcher || {});
    libUpdateTotalSize(libLocations);

    if (data.is_scanning) {
      libShowScanBadge(true);
      if (!libScanPollTimer) {
        libScanPollTimer = setInterval(libPollScan, 2500);
      }
    } else {
      libShowScanBadge(false);
      if (libScanPollTimer) {
        clearInterval(libScanPollTimer);
        libScanPollTimer = null;
      }
      libUpdateTimestamp();
    }

    // Start idle poll if not already running
    if (!libIdlePollTimer) {
      libIdlePollTimer = setInterval(libIdlePoll, 8000);
    }
  } catch (e) {
    document.getElementById("libList").innerHTML =
      '<div class="lib-empty">Bibliothek konnte nicht geladen werden.</div>';
  }
}

// Cheap background check: only reads a tiny status object from DB (no disk scan).
// Re-renders only when the watcher has updated the cache since last render.
async function libIdlePoll() {
  // Skip if a scan poll is already running (it will handle the update)
  if (libScanPollTimer) return;
  try {
    var resp = await fetch("/api/library/status");
    var status = await resp.json();
    if (status.is_scanning) {
      // Watcher just triggered a scan — hand off to scan poller
      libShowScanBadge(true);
      if (!libScanPollTimer) {
        libScanPollTimer = setInterval(libPollScan, 2500);
      }
    } else if (status.last_updated > libLastUpdated) {
      // Cache was updated since our last render — fetch and re-render
      await libFetch();
    }
  } catch (e) { /* ignore network errors */ }
}

// Poll only while a scan is running — stops itself when done
async function libPollScan() {
  try {
    var resp = await fetch("/api/library");
    var data = await resp.json();
    libUpdateWatcherStatus(data.watcher || {});
    if (!data.is_scanning) {
      libLangSep   = !!data.lang_sep;
      libLocations = data.locations || [];
      libAllTargets = libLocations.map(function(loc) {
        return { label: loc.label, custom_path_id: loc.custom_path_id };
      });
      libLastUpdated = data.last_updated || 0;
      libRender(libLocations, _libOpenState);
      libUpdateTotalSize(libLocations);
      libShowScanBadge(false);
      clearInterval(libScanPollTimer);
      libScanPollTimer = null;
      libUpdateTimestamp();
    }
  } catch (e) {}
}

function libUpdateTimestamp() {
  var el = document.getElementById("libLastScanned");
  if (el) el.textContent = "Aktualisiert: " + new Date().toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
}

function libShowScanBadge(visible) {
  var badge = document.getElementById("libScanBadge");
  var btn   = document.getElementById("libRefreshBtn");
  if (badge) badge.style.display = visible ? "inline-flex" : "none";
  if (btn)   btn.disabled = visible;
}

function libUpdateWatcherStatus(watcher) {
  var dot   = document.getElementById("libWatcherDot");
  var label = document.getElementById("libWatcherLabel");
  var tip   = document.getElementById("libWatcherTip");
  if (!dot || !label) return;

  if (!watcher.available) {
    dot.className   = "lib-watcher-dot lib-watcher-off";
    label.textContent = "Watcher inaktiv";
    if (tip) tip.title = "watchdog nicht installiert (pip install watchdog)";
    return;
  }
  if (watcher.active) {
    dot.className   = "lib-watcher-dot lib-watcher-on";
    label.textContent = "Watcher aktiv";
    if (tip && watcher.watched && watcher.watched.length) {
      tip.title = "Überwacht: " + watcher.watched.map(function(w){ return w.path; }).join(", ");
    }
  } else {
    dot.className   = "lib-watcher-dot lib-watcher-starting";
    label.textContent = "Watcher startet…";
  }
}

// ---- Total size ----

function libUpdateTotalSize(locations) {
  var total = 0, totalEps = 0, totalMovies = 0;
  locations.forEach(function(loc) {
    var titles = [];
    if (loc.lang_folders) {
      loc.lang_folders.forEach(function(lf) { titles = titles.concat(lf.titles || []); });
    } else if (loc.titles) {
      titles = titles.concat(loc.titles);
    }
    titles.forEach(function(t) {
      total += t.total_size || 0;
      if (t.is_movie) totalMovies++;
      else totalEps += t.total_episodes || 0;
    });
  });
  var el = document.getElementById("libTotalSize");
  if (el) el.textContent = total ? libFmtSize(total) + " gesamt" : "";

  var pillsEl = document.getElementById("libSummaryPills");
  if (pillsEl) {
    var parts = [];
    if (totalEps > 0)    parts.push('<span class="lib-summary-pill">' + totalEps + ' Episoden</span>');
    if (totalMovies > 0) parts.push('<span class="lib-summary-pill lib-summary-pill--film">🎬 ' + totalMovies + ' Film' + (totalMovies !== 1 ? 'e' : '') + '</span>');
    pillsEl.innerHTML = parts.join("");
  }
}

// ---- Sort ----

function libSetSort(key) {
  if (libSortKey === key) {
    libSortAsc = !libSortAsc; // toggle direction on second click
  } else {
    libSortKey = key;
    libSortAsc = key === "name"; // name defaults A→Z, others default big→small
  }
  // Update button active state
  ["name", "size", "episodes"].forEach(function(k) {
    var btn = document.getElementById("libSort-" + k);
    if (!btn) return;
    btn.classList.toggle("active", k === libSortKey);
    if (k === libSortKey) {
      btn.title = (k === "name")
        ? (libSortAsc ? "A–Z (klicken für Z–A)" : "Z–A (klicken für A–Z)")
        : (libSortAsc ? "Aufsteigend" : "Absteigend");
    }
  });
  libRender(libLocations, _libOpenState);
}

function libSetFilter(mode) {
  libFilterMode = mode;
  ["all", "series", "movies"].forEach(function(k) {
    var btn = document.getElementById("libFilter-" + k);
    if (btn) btn.classList.toggle("active", k === mode);
  });
  libRender(libLocations, _libOpenState);
}

function libFilterTitles(titles) {
  if (libFilterMode === "all") return titles;
  return titles.filter(function(t) {
    return libFilterMode === "movies" ? !!t.is_movie : !t.is_movie;
  });
}

function libSortTitles(titles) {
  return titles.slice().sort(function(a, b) {
    var v;
    if (libSortKey === "size")     v = (a.total_size || 0) - (b.total_size || 0);
    else if (libSortKey === "episodes") v = (a.total_episodes || 0) - (b.total_episodes || 0);
    else v = (a.folder || "").localeCompare(b.folder || "", "de", { sensitivity: "base" });
    return libSortAsc ? v : -v;
  });
}

// ---- Search ----

function libOnSearch(value) {
  if (_libSearchTimer) clearTimeout(_libSearchTimer);
  _libSearchTimer = setTimeout(function() {
    libSearchQuery = value.trim();
    // When clearing search, restore open-state; during search results stay collapsed
    var restoreState = libSearchQuery ? null : _libOpenState;
    requestAnimationFrame(function() {
      libRender(libLocations, restoreState);
    });
  }, 200);
}

// ---- Render ----
// Lazy strategy: title bodies are rendered empty and filled on first expand.
// This makes the initial paint near-instant regardless of library size.
//
// State preservation: before every re-render we snapshot which locations,
// lang-folders, titles and seasons were expanded (keyed by stable names, not
// DOM IDs so they survive data changes). After render we restore that state.

var _libLazy = {};
var _libUpscaleTitles = {};  // stores title objects for upscale button // bodyId → render params

// --- State snapshot helpers ---

function libCaptureState() {
  var state = {
    locs:    new Set(),   // location body IDs  (positional — stable unless paths change)
    lf:      new Set(),   // lang-folder body IDs (positional)
    titles:  new Set(),   // "folder|cpId|langFolder"
    seasons: new Set(),   // "folder|cpId|langFolder|sN"
  };

  // Location bodies
  document.querySelectorAll('[id^="libLocBody"]').forEach(function(el) {
    if (el.classList.contains("lib-expanded")) state.locs.add(el.id);
  });

  // Lang-folder bodies
  document.querySelectorAll('[id^="libLFBody"]').forEach(function(el) {
    if (el.classList.contains("lib-expanded")) state.lf.add(el.id);
  });

  // Title bodies — matched by name, not position
  Object.keys(_libLazy).forEach(function(bodyId) {
    var el = document.getElementById(bodyId);
    if (!el || !el.classList.contains("lib-expanded")) return;
    var p   = _libLazy[bodyId];
    var key = _libTitleKey(p);
    state.titles.add(key);

    // Seasons inside this title body
    el.querySelectorAll('[id$="Body"]').forEach(function(sb) {
      var m = sb.id.match(/_s(\d+)Body$/);
      if (m && sb.classList.contains("lib-expanded")) {
        state.seasons.add(key + "|s" + m[1]);
      }
    });
  });

  return state;
}

function libRestoreState(state) {
  if (!state) return;

  // Location bodies
  state.locs.forEach(function(id) { _libExpandEl(document.getElementById(id)); });

  // Lang-folder bodies
  state.lf.forEach(function(id) { _libExpandEl(document.getElementById(id)); });

  // Title bodies — match by name
  Object.keys(_libLazy).forEach(function(bodyId) {
    var p   = _libLazy[bodyId];
    var key = _libTitleKey(p);
    if (!state.titles.has(key)) return;

    var el = document.getElementById(bodyId);
    if (!el) return;
    if (el.classList.contains("lib-lazy-body")) libFillTitleBody(el, p);
    _libExpandEl(el);

    // Restore seasons
    el.querySelectorAll('[id$="Body"]').forEach(function(sb) {
      var m = sb.id.match(/_s(\d+)Body$/);
      if (m && state.seasons.has(key + "|s" + m[1])) _libExpandEl(sb);
    });
  });
}

function _libTitleKey(p) {
  return (p.title.folder || "") + "|" +
         (p.cpId !== null && p.cpId !== undefined ? p.cpId : "default") + "|" +
         (p.langFolder || "");
}

function _libExpandEl(el) {
  if (!el) return;
  el.classList.add("lib-expanded");
  var header = el.previousElementSibling;
  if (header) {
    var arrow = header.querySelector(".lib-arrow");
    if (arrow) arrow.classList.add("lib-arrow-open");
  }
}

// ---

function libRender(locations, savedState) {
  var container = document.getElementById("libList");
  if (!locations.length) {
    container.innerHTML = '<div class="lib-empty">Keine heruntergeladenen Inhalte gefunden.<br>Downloads werden hier automatisch angezeigt.</div>';
    return;
  }

  // Search mode: collect matching titles across all locations and render flat
  if (libSearchQuery) {
    libRenderSearchResults(locations, libSearchQuery);
    return;
  }

  _libLazy = {};
  var html = [];
  locations.forEach(function(loc, li) {
    html.push(libRenderLocation(loc, li));
  });
  container.innerHTML = html.join("");

  // Restore previously expanded nodes (no-op on first load when savedState is empty)
  if (savedState) libRestoreState(savedState);
}

function libRenderSearchResults(locations, query) {
  var q = query.toLowerCase();
  var container = document.getElementById("libList");
  _libLazy = {};
  var matches = [];

  locations.forEach(function(loc, li) {
    var titles = [];
    if (libLangSep && loc.lang_folders) {
      loc.lang_folders.forEach(function(lf) {
        lf.titles.forEach(function(t) {
          if (libTitleMatchesQuery(t, q)) titles.push({ title: t, cpId: loc.custom_path_id, langFolder: lf.name });
        });
      });
    } else if (loc.titles) {
      loc.titles.forEach(function(t) {
        if (libTitleMatchesQuery(t, q)) titles.push({ title: t, cpId: loc.custom_path_id, langFolder: null });
      });
    }
    if (titles.length) matches.push({ loc: loc, titles: titles });
  });

  if (!matches.length) {
    container.innerHTML = '<div class="lib-empty">Keine Ergebnisse für „' + libEsc(query) + '".</div>';
    return;
  }

  var html = [];
  var globalTi = 0;
  matches.forEach(function(m) {
    // Location label as non-clickable header
    html.push('<div class="lib-search-loc-label">' + libEsc(m.loc.label) + '</div>');
    m.titles.forEach(function(entry) {
      if (entry.title.is_movie) {
        html.push(libRenderMovieFlat(entry.title, 0, entry.langFolder, null, entry.cpId));
      } else {
        var shell = libRenderTitleShell(entry.title, 0, entry.langFolder, null, globalTi++, entry.cpId);
        html.push(shell);
      }
    });
  });

  container.innerHTML = html.join("");
  // Restore any titles/seasons the user had open before the re-render
  libRestoreState(_libOpenState);
}

function libTitleMatchesQuery(title, q) {
  // Match against folder name, or individual file names
  if ((title.folder || "").toLowerCase().includes(q)) return true;
  if (title.seasons) {
    for (var si = 0; si < title.seasons.length; si++) {
      var s = title.seasons[si];
      if (s.files) {
        for (var fi = 0; fi < s.files.length; fi++) {
          if ((s.files[fi].name || "").toLowerCase().includes(q)) return true;
        }
      }
    }
  }
  if (title.files) {
    for (var fi2 = 0; fi2 < title.files.length; fi2++) {
      if ((title.files[fi2].name || "").toLowerCase().includes(q)) return true;
    }
  }
  return false;
}

function libRenderLocation(loc, li) {
  var totalEps = 0, totalSize = 0;
  if (libLangSep && loc.lang_folders) {
    loc.lang_folders.forEach(function(lf) {
      lf.titles.forEach(function(t) { totalEps += t.total_episodes; totalSize += t.total_size; });
    });
  } else if (loc.titles) {
    loc.titles.forEach(function(t) { totalEps += t.total_episodes; totalSize += t.total_size; });
  }

  var seriesEps = 0, movieCount = 0;
  if (libLangSep && loc.lang_folders) {
    loc.lang_folders.forEach(function(lf) {
      lf.titles.forEach(function(t) { t.is_movie ? movieCount++ : (seriesEps += t.total_episodes); });
    });
  } else if (loc.titles) {
    loc.titles.forEach(function(t) { t.is_movie ? movieCount++ : (seriesEps += t.total_episodes); });
  }

  var h = [];
  h.push('<div class="lib-location" id="libLoc' + li + '">');
  h.push('<div class="lib-location-header" onclick="libToggle(\'libLocBody' + li + '\',this)">');
  h.push('<div class="lib-row-left">');
  h.push('<svg class="lib-arrow" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>');
  h.push('<svg class="lib-icon lib-icon-folder-root" viewBox="0 0 24 24"><path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>');
  h.push('<span class="lib-location-name">' + libEsc(loc.label) + '</span>');
  h.push('</div>');
  h.push('<div class="lib-row-right">');
  if (seriesEps > 0) h.push('<span class="lib-badge">' + seriesEps + ' Ep.</span>');
  if (movieCount > 0) h.push('<span class="lib-badge">' + movieCount + ' Film' + (movieCount !== 1 ? 'e' : '') + '</span>');
  h.push('<span class="lib-badge lib-badge-size">' + libFmtSize(totalSize) + '</span>');
  h.push('</div>');
  h.push('</div>'); // header

  // Location body is always rendered (it only contains title rows, not episode detail)
  h.push('<div class="lib-body" id="libLocBody' + li + '">');
  if (libLangSep && loc.lang_folders) {
    loc.lang_folders.forEach(function(lf, lfi) {
      h.push(libRenderLangFolder(lf, li, lfi, loc.custom_path_id));
    });
  } else if (loc.titles) {
    libSortTitles(libFilterTitles(loc.titles)).forEach(function(title, ti) {
      if (title.is_movie) {
        h.push(libRenderMovieFlat(title, li, null, null, loc.custom_path_id));
      } else {
        h.push(libRenderTitleShell(title, li, null, null, ti, loc.custom_path_id));
      }
    });
  }
  h.push('</div>'); // body
  h.push('</div>'); // location
  return h.join("");
}

function libRenderLangFolder(lf, li, lfi, cpId) {
  var totalEps = 0, totalSize = 0;
  lf.titles.forEach(function(t) { totalEps += t.total_episodes; totalSize += t.total_size; });
  var seriesEps = 0, movieCount = 0;
  lf.titles.forEach(function(t) { t.is_movie ? movieCount++ : (seriesEps += t.total_episodes); });
  var bodyId = "libLFBody" + li + "_" + lfi;
  var h = [];
  h.push('<div class="lib-lang-section">');
  h.push('<div class="lib-lang-header" onclick="libToggle(\'' + bodyId + '\',this)">');
  h.push('<div class="lib-row-left">');
  h.push('<svg class="lib-arrow" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>');
  h.push('<svg class="lib-icon" viewBox="0 0 24 24"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>');
  h.push('<span class="lib-lang-name">' + libEsc(lf.name) + '</span>');
  h.push('</div>');
  h.push('<div class="lib-row-right">');
  if (seriesEps > 0) h.push('<span class="lib-badge">' + seriesEps + ' Ep.</span>');
  if (movieCount > 0) h.push('<span class="lib-badge">' + movieCount + ' Film' + (movieCount !== 1 ? 'e' : '') + '</span>');
  h.push('<span class="lib-badge lib-badge-size">' + libFmtSize(totalSize) + '</span>');
  h.push('</div>');
  h.push('</div>');
  // Lang folder body = title shells (still lazy inside)
  h.push('<div class="lib-body" id="' + bodyId + '">');
  libSortTitles(libFilterTitles(lf.titles)).forEach(function(title, ti) {
    if (title.is_movie) {
      h.push(libRenderMovieFlat(title, li, lf.name, lfi, cpId));
    } else {
      h.push(libRenderTitleShell(title, li, lf.name, lfi, ti, cpId));
    }
  });
  h.push('</div>');
  h.push('</div>');
  return h.join("");
}

// Renders a movie as a flat, non-expandable row directly in the location/langfolder body.
// No intermediate "title folder" shell — the file is immediately visible.
var _libMovieFlatIdx = 0;
function libRenderMovieFlat(title, li, langFolder, lfi, cpId) {
  var pfx    = "libMFlat" + (_libMovieFlatIdx++);
  var cpIdJs = cpId !== null && cpId !== undefined ? cpId : 'null';
  var lfJs   = langFolder ? "'" + libEscJs(langFolder) + "'" : 'null';
  var files  = (title.seasons && title.seasons["movies"]) ? title.seasons["movies"] : [];
  var h = [];
  files.forEach(function(ep) {
    h.push('<div class="lib-episode-row lib-movie-flat-row lib-hoverable" id="' + pfx + '">');
    h.push('<div class="lib-row-left">');
    h.push('<svg class="lib-icon lib-icon-film" viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="20" rx="2"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="17" y1="7" x2="22" y2="7"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="2" y1="17" x2="7" y2="17"/></svg>');
    h.push('<span class="lib-ep-title" id="' + pfx + 'Name">' + libEsc(title.folder) + '</span>');
    h.push('<span class="lib-movie-pill">Film</span>');
    h.push('</div>');
    h.push('<div class="lib-row-right">');
    if (libraryCanDelete) {
      h.push('<div class="lib-actions" onclick="event.stopPropagation()">');
      h.push('<button class="lib-action-btn lib-btn-rename" onclick="libStartRename(\'' + pfx + '\',\'' + libEscJs(title.folder) + '\',' + cpIdJs + ',' + lfJs + ')" title="Umbenennen"><svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>');
      if (libAllTargets.length > 1) {
        h.push('<button class="lib-action-btn lib-btn-move" onclick="libOpenMove(\'' + libEscJs(title.folder) + '\',' + cpIdJs + ',' + lfJs + ')" title="Verschieben"><svg viewBox="0 0 24 24"><polyline points="5 9 2 12 5 15"/><polyline points="9 5 12 2 15 5"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="12" y1="2" x2="12" y2="22"/></svg></button>');
      }
      h.push('<button class="lib-action-btn lib-btn-delete" onclick="libDeleteTitle(\'' + libEscJs(title.folder) + '\',' + cpIdJs + ',' + lfJs + ')" title="Löschen"><svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg></button>');
      h.push('</div>');
    }
    h.push('<span class="lib-badge lib-badge-size">' + libFmtSize(ep.size) + '</span>');
    h.push('</div>');
    h.push('</div>');
  });
  return h.join("");
}

// Renders only the title header row + an EMPTY body div (lazy).
// Season/episode content is injected on first expand.
function libRenderTitleShell(title, li, langFolder, lfi, ti, cpId) {
  var pfx    = "libT" + li + (lfi !== null ? "_lf" + lfi : "") + "_t" + ti;
  var bodyId = pfx + "Body";
  var cpIdJs = cpId !== null && cpId !== undefined ? cpId : 'null';
  var lfJs   = langFolder ? "'" + libEscJs(langFolder) + "'" : 'null';

  // Store params so libToggle can fill the body on demand
  _libLazy[bodyId] = { title: title, li: li, langFolder: langFolder, lfi: lfi, ti: ti, cpId: cpId, pfx: pfx };

  var h = [];
  h.push('<div class="lib-title-section" id="' + pfx + '">');
  h.push('<div class="lib-title-row lib-hoverable" onclick="libToggle(\'' + bodyId + '\',this)">');
  h.push('<div class="lib-row-left">');
  h.push('<svg class="lib-arrow" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>');
  h.push('<svg class="lib-icon lib-icon-folder" viewBox="0 0 24 24"><path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>');
  h.push('<span class="lib-title-name" id="' + pfx + 'Name">' + libEsc(title.folder) + '</span>');
  if (title.is_movie) h.push('<span class="lib-movie-pill">Film</span>');
  h.push('</div>');
  h.push('<div class="lib-row-right">');
  h.push('<span class="lib-badge">' + title.total_episodes + (title.is_movie ? ' Film' : ' Ep.') + '</span>');
  h.push('<span class="lib-badge lib-badge-size">' + libFmtSize(title.total_size) + '</span>');
  var _upscaleKey = "usc_" + pfx;
  _libUpscaleTitles[_upscaleKey] = title;
  h.push('<div class="lib-actions" onclick="event.stopPropagation()">');
  if (libraryCanDelete) {
    h.push('<button class="lib-action-btn lib-btn-rename" onclick="libStartRename(\'' + pfx + '\',\'' + libEscJs(title.folder) + '\',' + cpIdJs + ',' + lfJs + ')" title="Umbenennen"><svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>');
    if (libAllTargets.length > 1) {
      h.push('<button class="lib-action-btn lib-btn-move" onclick="libOpenMove(\'' + libEscJs(title.folder) + '\',' + cpIdJs + ',' + lfJs + ')" title="Verschieben"><svg viewBox="0 0 24 24"><polyline points="5 9 2 12 5 15"/><polyline points="9 5 12 2 15 5"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="12" y1="2" x2="12" y2="22"/></svg></button>');
    }
    h.push('<button class="lib-action-btn lib-btn-delete" onclick="libDeleteTitle(\'' + libEscJs(title.folder) + '\',' + cpIdJs + ',' + lfJs + ')" title="Löschen"><svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg></button>');
  }
  h.push('<button class="lib-action-btn lib-btn-upscale" onclick="libUpscaleTitle(event,\'' + _upscaleKey + '\',' + cpIdJs + ',' + lfJs + ')" title="Serie upscalen">' +
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></button>');
  h.push('</div>');
  h.push('</div>'); // row-right
  h.push('</div>'); // title-row

  // Empty body — filled lazily on first expand
  h.push('<div class="lib-body lib-lazy-body" id="' + bodyId + '">');
  h.push('</div>');
  h.push('</div>'); // title-section
  return h.join("");
}

// Called lazily from libToggle to populate a title body
function libFillTitleBody(bodyEl, params) {
  var title = params.title, pfx = params.pfx;
  var li = params.li, langFolder = params.langFolder, lfi = params.lfi, ti = params.ti, cpId = params.cpId;
  var html = [];

  if (title.is_movie && title.seasons["movies"]) {
    // Movies: render files directly, no "Staffel X" wrapper
    title.seasons["movies"].forEach(function(ep) {
      html.push(libRenderEpisode(ep, title, "movies", cpId, langFolder));
    });
  } else {
    var seasonKeys = Object.keys(title.seasons).filter(function(k){ return k !== "movies"; })
      .sort(function(a,b){ return parseInt(a)-parseInt(b); });
    seasonKeys.forEach(function(skey) {
      html.push(libRenderSeason(title, skey, pfx, li, langFolder, lfi, ti, cpId));
    });
  }

  bodyEl.innerHTML = html.join("");
  bodyEl.classList.remove("lib-lazy-body");
}

function libRenderSeason(title, skey, titlePfx, li, langFolder, lfi, ti, cpId) {
  var eps      = title.seasons[skey];
  var bodyId   = titlePfx + "_s" + skey + "Body";
  var videoEps = eps.filter(function(e){ return e.is_video !== false; });
  var seasonSize = eps.reduce(function(acc,e){ return acc + e.size; }, 0);
  var cpIdJs = cpId !== null && cpId !== undefined ? cpId : 'null';
  var lfJs   = langFolder ? "'" + libEscJs(langFolder) + "'" : 'null';
  var h = [];
  h.push('<div class="lib-season-section">');
  h.push('<div class="lib-season-row lib-hoverable" onclick="libToggle(\'' + bodyId + '\',this)">');
  h.push('<div class="lib-row-left">');
  h.push('<svg class="lib-arrow" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg>');
  h.push('<svg class="lib-icon lib-icon-season" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>');
  h.push('<span>Staffel ' + skey + '</span>');
  h.push('</div>');
  h.push('<div class="lib-row-right">');
  h.push('<span class="lib-badge">' + videoEps.length + ' Ep.</span>');
  h.push('<span class="lib-badge lib-badge-size">' + libFmtSize(seasonSize) + '</span>');
  if (libraryCanDelete) {
    h.push('<div class="lib-actions" onclick="event.stopPropagation()">');
    h.push('<button class="lib-action-btn lib-btn-delete" onclick="libDeleteSeason(\'' + libEscJs(title.folder) + '\',' + skey + ',' + cpIdJs + ',' + lfJs + ')" title="Staffel löschen"><svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg></button>');
    h.push('</div>');
  }
  h.push('</div>');
  h.push('</div>'); // season-row

  h.push('<div class="lib-body" id="' + bodyId + '">');
  eps.forEach(function(ep) {
    h.push(libRenderEpisode(ep, title, skey, cpId, langFolder));
  });
  h.push('</div>');
  h.push('</div>');
  return h.join("");
}

function libRenderEpisode(ep, title, skey, cpId, langFolder) {
  var cpIdJs = cpId !== null && cpId !== undefined ? cpId : 'null';
  var lfJs   = langFolder ? "'" + libEscJs(langFolder) + "'" : 'null';
  var isVideo = ep.is_video !== false;
  var h = [];
  h.push('<div class="lib-episode-row lib-hoverable">');
  h.push('<div class="lib-row-left">');
  if (isVideo) {
    h.push('<svg class="lib-icon lib-icon-video" viewBox="0 0 24 24"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>');
  } else {
    h.push('<svg class="lib-icon lib-icon-file" viewBox="0 0 24 24"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>');
  }
  if (!ep.is_movie_file) h.push('<span class="lib-ep-num">E' + String(ep.episode).padStart(3,"0") + '</span>');
  h.push('<span class="lib-ep-file" title="' + libEsc(ep.file) + '">' + libEsc(ep.file) + '</span>');
  h.push('</div>');
  h.push('<div class="lib-row-right">');
  h.push('<span class="lib-badge lib-badge-size">' + libFmtSize(ep.size) + '</span>');
  if (isVideo || libraryCanDelete) {
    h.push('<div class="lib-actions" onclick="event.stopPropagation()">');
    if (libraryCanDelete) {
      h.push('<button class="lib-action-btn lib-btn-rename" onclick="libStartEpRename(\'' + libEscJs(title.folder) + '\',' + skey + ',' + ep.episode + ',\'' + libEscJs(ep.file) + '\',' + cpIdJs + ',' + lfJs + ')" title="Umbenennen"><svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>');
      h.push('<button class="lib-action-btn lib-btn-delete" onclick="libDeleteEpisode(\'' + libEscJs(title.folder) + '\',' + skey + ',' + ep.episode + ',' + cpIdJs + ',' + lfJs + ')" title="Löschen"><svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/><path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/></svg></button>');
    }
    if (isVideo && ep.path) {
      var _epPathJs = '\'' + libEscJs(ep.path) + '\'';
      var _epNameJs = '\'' + libEscJs((title.folder || "") + " – " + (ep.file || "")) + '\'';
      h.push('<button class="lib-action-btn lib-btn-upscale" onclick="libUpscaleEpisode(event,' + _epPathJs + ',' + _epNameJs + ')" title="Folge upscalen"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></button>');
    }
    h.push('</div>');
  }
  h.push('</div>');
  h.push('</div>');
  return h.join("");
}

// ---- Toggle ----
// On first open of a lazy title body: fill its content, then expand.

function libToggle(bodyId, headerEl) {
  var body = document.getElementById(bodyId);
  if (!body) return;

  // Lazy fill: if this is a title body not yet rendered, fill it now
  if (body.classList.contains("lib-lazy-body") && !body.classList.contains("lib-expanded")) {
    var params = _libLazy[bodyId];
    if (params) libFillTitleBody(body, params);
  }

  var expanded = body.classList.toggle("lib-expanded");
  if (headerEl) {
    var arrow = headerEl.querySelector(".lib-arrow");
    if (arrow) arrow.classList.toggle("lib-arrow-open", expanded);
  }

  // ---- Maintain persistent open-state ----
  // Location body: "libLocBodyN"
  if (/^libLocBody\d+$/.test(bodyId)) {
    if (expanded) _libOpenState.locs.add(bodyId);
    else _libOpenState.locs.delete(bodyId);
    return;
  }
  // Lang-folder body: "libLFBodyN_M"
  if (/^libLFBody\d+_\d+$/.test(bodyId)) {
    if (expanded) _libOpenState.lf.add(bodyId);
    else _libOpenState.lf.delete(bodyId);
    return;
  }
  // Title body: present in _libLazy
  if (_libLazy[bodyId]) {
    var key = _libTitleKey(_libLazy[bodyId]);
    if (expanded) {
      _libOpenState.titles.add(key);
    } else {
      _libOpenState.titles.delete(key);
      // Also remove all seasons belonging to this title
      var toRemove = [];
      _libOpenState.seasons.forEach(function(sk) {
        if (sk.startsWith(key + "|s")) toRemove.push(sk);
      });
      toRemove.forEach(function(sk) { _libOpenState.seasons.delete(sk); });
    }
    return;
  }
  // Season body: "_sNBody" suffix — find parent title body
  var m = bodyId.match(/_s(\d+)Body$/);
  if (m) {
    var titleBodyId = bodyId.replace(/_s\d+Body$/, "Body");
    if (_libLazy[titleBodyId]) {
      var seasonKey = _libTitleKey(_libLazy[titleBodyId]) + "|s" + m[1];
      if (expanded) _libOpenState.seasons.add(seasonKey);
      else _libOpenState.seasons.delete(seasonKey);
    }
  }
}

// ---- Delete ----

async function libDeleteTitle(folder, cpId, langFolder) {
  if (!await showConfirm('"' + folder + '" vollständig löschen? Dieser Vorgang kann nicht rückgängig gemacht werden.')) return;
  var body = { folder: folder, season: null, episode: null, custom_path_id: cpId };
  if (langFolder) body.lang_folder = langFolder;
  await libApiPost("/api/library/delete", body, "Erfolgreich gelöscht");
}

async function libDeleteSeason(folder, season, cpId, langFolder) {
  if (!await showConfirm('Alle Episoden von Staffel ' + season + ' in "' + folder + '" löschen?')) return;
  var body = { folder: folder, season: season, episode: null, custom_path_id: cpId };
  if (langFolder) body.lang_folder = langFolder;
  await libApiPost("/api/library/delete", body, "Staffel gelöscht");
}

async function libDeleteEpisode(folder, season, episode, cpId, langFolder) {
  if (!await showConfirm('Episode E' + String(episode).padStart(3,"0") + ' in "' + folder + '" löschen?')) return;
  var body = { folder: folder, season: season, episode: episode, custom_path_id: cpId };
  if (langFolder) body.lang_folder = langFolder;
  await libApiPost("/api/library/delete", body, "Episode gelöscht");
}

// ---- Rename ----

function libStartRename(pfx, currentName, cpId, langFolder) {
  var nameEl = document.getElementById(pfx + "Name");
  if (!nameEl) return;
  var section = document.getElementById(pfx);
  if (!section) return;

  // Build inline input
  var input = document.createElement("input");
  input.type = "text";
  input.value = currentName;
  input.className = "lib-inline-input";
  input.onclick = function(e) { e.stopPropagation(); };

  var confirmBtn = document.createElement("button");
  confirmBtn.className = "lib-inline-btn lib-inline-confirm";
  confirmBtn.innerHTML = '&#10003;';
  confirmBtn.title = "Bestätigen";

  var cancelBtn = document.createElement("button");
  cancelBtn.className = "lib-inline-btn lib-inline-cancel";
  cancelBtn.innerHTML = '&#10005;';
  cancelBtn.title = "Abbrechen";

  var origContent = nameEl.innerHTML;
  nameEl.innerHTML = "";
  nameEl.appendChild(input);
  nameEl.appendChild(confirmBtn);
  nameEl.appendChild(cancelBtn);
  input.select();

  var doRename = async function() {
    var newName = input.value.trim();
    if (!newName || newName === currentName) { restoreLib(); return; }
    try {
      var resp = await fetch("/api/library/rename", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folder: currentName, new_name: newName, custom_path_id: cpId, lang_folder: langFolder })
      });
      var data = await resp.json();
      if (data.error) { showToast(data.error); restoreLib(); }
      else { showToast("Umbenannt"); libLoad(false); }
    } catch(e) { showToast("Umbenennen fehlgeschlagen"); restoreLib(); }
  };

  var restoreLib = function() { nameEl.innerHTML = origContent; };

  confirmBtn.onclick = function(e) { e.stopPropagation(); doRename(); };
  cancelBtn.onclick  = function(e) { e.stopPropagation(); restoreLib(); };
  input.addEventListener("keydown", function(e) {
    if (e.key === "Enter")  doRename();
    if (e.key === "Escape") restoreLib();
  });
}

function libStartEpRename(folder, season, episode, oldFile, cpId, langFolder) {
  // Find the episode row and inject rename UI inline
  var rows = document.querySelectorAll(".lib-ep-file");
  var targetRow = null;
  rows.forEach(function(el) {
    if (el.getAttribute("title") === oldFile) targetRow = el;
  });
  if (!targetRow) return;

  var input = document.createElement("input");
  input.type = "text";
  input.value = oldFile;
  input.className = "lib-inline-input";
  input.onclick = function(e) { e.stopPropagation(); };

  var confirmBtn = document.createElement("button");
  confirmBtn.className = "lib-inline-btn lib-inline-confirm";
  confirmBtn.innerHTML = '&#10003;';

  var cancelBtn = document.createElement("button");
  cancelBtn.className = "lib-inline-btn lib-inline-cancel";
  cancelBtn.innerHTML = '&#10005;';

  var origTitle = targetRow.getAttribute("title");
  var origText  = targetRow.textContent;
  targetRow.textContent = "";
  targetRow.appendChild(input);
  targetRow.appendChild(confirmBtn);
  targetRow.appendChild(cancelBtn);
  input.select();

  var doRename = async function() {
    var newName = input.value.trim();
    if (!newName || newName === oldFile) { restore(); return; }
    try {
      var resp = await fetch("/api/library/rename", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folder: folder, season: season, episode: episode, old_file: oldFile, new_name: newName, custom_path_id: cpId, lang_folder: langFolder })
      });
      var data = await resp.json();
      if (data.error) { showToast(data.error); restore(); }
      else { showToast("Umbenannt"); libLoad(false); }
    } catch(e) { showToast("Umbenennen fehlgeschlagen"); restore(); }
  };

  var restore = function() {
    targetRow.textContent = origText;
    targetRow.setAttribute("title", origTitle);
  };

  confirmBtn.onclick = function(e) { e.stopPropagation(); doRename(); };
  cancelBtn.onclick  = function(e) { e.stopPropagation(); restore(); };
  input.addEventListener("keydown", function(e) {
    if (e.key === "Enter")  doRename();
    if (e.key === "Escape") restore();
  });
}

// ---- Move ----

// ── Move job state ──────────────────────────────────────────────
var _libMoveJobId    = null;
var _libMovePollTimer = null;

function libOpenMove(folder, cpId, langFolder) {
  // Don't open select view while a move is already running
  if (_libMoveJobId) { libOpenMoveProgress(); return; }

  var modal   = document.getElementById("libMoveModal");
  var titleEl = document.getElementById("libMoveTitleName");
  var select  = document.getElementById("libMoveTarget");
  if (!modal || !titleEl || !select) return;

  titleEl.textContent = folder;
  modal._folder     = folder;
  modal._cpId       = cpId;
  modal._langFolder = langFolder;

  // Show select view, hide progress view
  var sv = document.getElementById("libMoveSelectView");
  var pv = document.getElementById("libMoveProgressView");
  if (sv) sv.style.display = "";
  if (pv) pv.style.display = "none";

  // Populate target dropdown (exclude current location)
  select.innerHTML = "";
  libAllTargets.forEach(function(t) {
    var isCurrent = (cpId === null || cpId === undefined)
      ? (t.custom_path_id === null || t.custom_path_id === undefined)
      : (String(t.custom_path_id) === String(cpId));
    if (isCurrent) return;
    var opt = document.createElement("option");
    opt.value = t.custom_path_id !== null && t.custom_path_id !== undefined ? t.custom_path_id : "";
    opt.textContent = t.label;
    select.appendChild(opt);
  });

  modal.style.display = "block";
}

function libCloseMoveModal() {
  var modal = document.getElementById("libMoveModal");
  if (modal) modal.style.display = "none";
}

// Called when clicking the background overlay — only close if no active job
function libMoveModalBgClick() {
  if (_libMoveJobId) { libMinimizeMove(); return; }
  libCloseMoveModal();
}

// Minimize to pill — keep job running in background
function libMinimizeMove() {
  libCloseMoveModal();
}

// Reopen progress modal from pill
function libOpenMoveProgress() {
  if (!_libMoveJobId) return;
  var modal = document.getElementById("libMoveModal");
  var sv    = document.getElementById("libMoveSelectView");
  var pv    = document.getElementById("libMoveProgressView");
  if (!modal) return;
  if (sv) sv.style.display = "none";
  if (pv) pv.style.display = "";
  modal.style.display = "block";
}

function _libShowMovePill(pct) {
  var pill = document.getElementById("libMovePill");
  var pctEl = document.getElementById("libMovePillPct");
  if (pill) pill.style.display = "";
  if (pctEl) pctEl.textContent = pct + "%";
}

function _libHideMovePill() {
  var pill = document.getElementById("libMovePill");
  if (pill) pill.style.display = "none";
}

function _libMoveSetProgress(pct, file) {
  var fill  = document.getElementById("libMoveProgressBarFill");
  var pctEl = document.getElementById("libMoveProgressPct");
  var fileEl = document.getElementById("libMoveProgressFile");
  if (fill)  fill.style.width  = pct + "%";
  if (pctEl) pctEl.textContent = pct + "%";
  if (fileEl) fileEl.textContent = file || "";
  _libShowMovePill(pct);
}

function _libMoveFinish(folder) {
  _libMoveJobId = null;
  clearInterval(_libMovePollTimer);
  _libMovePollTimer = null;
  _libHideMovePill();
  libCloseMoveModal();
  if (window.showToast) showToast('"' + folder + '" wurde verschoben');
  libLoad(false);
}

function _libMoveError(msg) {
  _libMoveJobId = null;
  clearInterval(_libMovePollTimer);
  _libMovePollTimer = null;
  _libHideMovePill();

  // Show error in modal
  var pv  = document.getElementById("libMoveProgressView");
  var err = document.getElementById("libMoveProgressError");
  var act = document.getElementById("libMoveProgressActions");
  var modal = document.getElementById("libMoveModal");
  if (modal) modal.style.display = "block";
  if (pv) pv.style.display = "";
  var sv = document.getElementById("libMoveSelectView");
  if (sv) sv.style.display = "none";
  if (err) { err.style.display = ""; err.textContent = "Fehler: " + msg; }
  if (act) act.innerHTML = '<button class="btn btn-secondary btn-sm" onclick="libCloseMoveModal()">Schließen</button>';
}

async function libConfirmMove() {
  var modal  = document.getElementById("libMoveModal");
  var select = document.getElementById("libMoveTarget");
  if (!modal || !select) return;

  var folder     = modal._folder;
  var fromCpId   = modal._cpId    !== undefined ? modal._cpId    : null;
  var langFolder = modal._langFolder !== undefined ? modal._langFolder : null;
  var toVal      = select.value;
  var toCpId     = toVal === "" ? null : parseInt(toVal, 10);

  // Switch to progress view
  var sv = document.getElementById("libMoveSelectView");
  var pv = document.getElementById("libMoveProgressView");
  var pt = document.getElementById("libMoveProgressTitle");
  var err = document.getElementById("libMoveProgressError");
  var act = document.getElementById("libMoveProgressActions");
  if (sv)  sv.style.display  = "none";
  if (pv)  pv.style.display  = "";
  if (pt)  pt.textContent    = folder;
  if (err) err.style.display = "none";
  if (act) act.innerHTML     = '<button class="btn btn-secondary btn-sm" id="libMoveMinimizeBtn" onclick="libMinimizeMove()">Im Hintergrund</button>';
  _libMoveSetProgress(0, "Wird vorbereitet…");

  try {
    var resp = await fetch("/api/library/move", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        folder:               folder,
        from_custom_path_id:  fromCpId,
        to_custom_path_id:    isNaN(toCpId) ? null : toCpId,
        lang_folder:          langFolder || null
      })
    });
    var data = await resp.json();
    if (data.error) {
      _libMoveError(data.error);
      return;
    }
    _libMoveJobId = data.job_id;
    // Start polling
    _libMovePollTimer = setInterval(async function() {
      try {
        var r = await fetch("/api/library/move_status/" + _libMoveJobId);
        if (!r.ok) { _libMoveError("Server-Fehler " + r.status); return; }
        var s = await r.json();
        if (s.error && s.status !== "done") { _libMoveError(s.error); return; }
        var pct = s.total_bytes > 0 ? Math.round(s.copied_bytes / s.total_bytes * 100) : 0;
        _libMoveSetProgress(pct, s.current_file || "");
        if (s.status === "done") { _libMoveFinish(folder); }
        else if (s.status === "error") { _libMoveError(s.error || "Unbekannter Fehler"); }
      } catch(e) { _libMoveError("Verbindung unterbrochen"); }
    }, 400);
  } catch(e) {
    _libMoveError("Netzwerkfehler: " + e.message);
  }
}

// ---- Shared API helper ----

async function libApiPost(url, body, successMsg) {
  try {
    var resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    var data = await resp.json();
    if (data.error) showToast(data.error);
    else { showToast(successMsg); libLoad(false); }
  } catch(e) { showToast("Aktion fehlgeschlagen"); }
}

// ---- Utilities ----

function libFmtSize(bytes) {
  if (!bytes) return "—";
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
  if (bytes < 1073741824) return (bytes / 1048576).toFixed(1) + " MB";
  return (bytes / 1073741824).toFixed(2) + " GB";
}

function libEsc(s) {
  var d = document.createElement("div");
  d.textContent = s || "";
  return d.innerHTML;
}

function libEscJs(s) {
  return (s || "").replace(/\\/g,"\\\\").replace(/'/g,"\\'").replace(/"/g,"\\\"");
}

// ---- Init ----

libLoad(false);

// ── Upscaling ────────────────────────────────────────────────────────
async function libUpscaleTitle(event, titleKey, cpId, langFolder) {
  if (event) event.stopPropagation();
  var title = _libUpscaleTitles[titleKey];
  if (!title) return;

  // Collect all episode file paths for this title.
  // title.seasons is an object: { "1": [{episode, file, size, is_video, path}, ...], ... }
  var files = [];
  function collectFiles(t) {
    if (!t || !t.seasons) return;
    Object.values(t.seasons).forEach(function(eps) {
      eps.forEach(function(ep) {
        if (ep.path && ep.is_video !== false) {
          files.push({title: (t.folder || "") + " – " + (ep.file || ""), path: ep.path});
        }
      });
    });
  }
  collectFiles(title);

  if (!files.length) {
    if (typeof showToast === "function") showToast("Keine Dateipfade gefunden.");
    return;
  }

  try {
    var r = await fetch("/api/upscale/add-library", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({files: files}),
    });
    var d = await r.json();
    if (d.ok) {
      if (typeof showToast === "function") showToast("✓ " + d.added + " Datei(en) zur Upscaling-Queue hinzugefügt");
      // Update badge
      if (typeof _startUpscaleBadgePoll === "function") {
        fetch("/api/upscale/badge").then(function(br) { return br.json(); }).then(function(bd) {
          if (bd.ok && typeof _updateUpscaleBadges === "function") _updateUpscaleBadges(bd.count || 0);
        }).catch(function(){});
      }
    } else {
      if (typeof showToast === "function") showToast("Fehler: " + (d.error || "unbekannt"));
    }
  } catch(e) {
    if (typeof showToast === "function") showToast("Netzwerkfehler");
  }
}

async function libUpscaleEpisode(event, filePath, fileTitle) {
  if (event) event.stopPropagation();
  if (!filePath) { if (typeof showToast === "function") showToast("Kein Dateipfad gefunden."); return; }
  try {
    var r = await fetch("/api/upscale/add-library", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({files: [{title: fileTitle || filePath, path: filePath}]}),
    });
    var d = await r.json();
    if (d.ok) {
      if (typeof showToast === "function") showToast("✓ Folge zur Upscaling-Queue hinzugefügt");
      if (typeof _startUpscaleBadgePoll === "function") {
        fetch("/api/upscale/badge").then(function(br) { return br.json(); }).then(function(bd) {
          if (bd.ok && typeof _updateUpscaleBadges === "function") _updateUpscaleBadges(bd.count || 0);
        }).catch(function(){});
      }
    } else {
      if (typeof showToast === "function") showToast("Fehler: " + (d.error || "unbekannt"));
    }
  } catch(e) {
    if (typeof showToast === "function") showToast("Netzwerkfehler");
  }
}
