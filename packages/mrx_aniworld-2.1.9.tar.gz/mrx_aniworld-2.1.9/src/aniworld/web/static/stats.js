// Stats page logic

async function loadStats() {
  const container = document.getElementById("statsContent");
  // Show skeletons while loading
  renderSkeletons(container);

  try {
    const resp = await fetch("/api/stats");
    const data = await resp.json();
    renderStats(data, container);
  } catch (e) {
    container.innerHTML = '<div class="stats-loading">Fehler beim Laden der Statistiken.</div>';
  }
}

function renderSkeletons(container) {
  let html = '<div class="stats-kpi-row stats-kpi-main">';
  for (let i = 0; i < 8; i++) {
    html += '<div class="stat-card skeleton"></div>';
  }
  html += '</div>';

  html += '<div class="stats-section"><div class="stats-section-title skeleton" style="width:150px;height:24px;margin-bottom:12px"></div><div class="stats-kpi-row">';
  for (let i = 0; i < 5; i++) {
    html += '<div class="stat-card skeleton"></div>';
  }
  html += '</div></div>';

  container.innerHTML = html;
}

function fmtDuration(seconds) {
  if (!seconds) return "—";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

function statCard(label, value, sub, color, onClick) {
  const style = color ? `--kpi-color:${color}` : "";
  const cursor = onClick ? "cursor:pointer" : "";
  return `<div class="stat-card" style="${style};${cursor}" ${onClick ? `onclick="${onClick}"` : ""}>
    <div class="stat-value">${value}</div>
    <div class="stat-label">${label}</div>
    ${sub ? `<div class="stat-sub">${sub}</div>` : ""}
  </div>`;
}

function openSpeedModal() {
  document.getElementById("speedModal").style.display = "flex";
}

function closeSpeedModal() {
  document.getElementById("speedModal").style.display = "none";
}

function renderStats(data, container) {
  const g = data.general || {};
  const q = data.queue || {};
  const s = data.sync || {};

  const byStatus = q.by_status || {};
  const successRate = g.total_downloads > 0
    ? Math.round((g.completed / g.total_downloads) * 100)
    : 0;

  // --- Speed Modal ---
  if (g.last_speeds && g.last_speeds.length) {
    let modalHtml = '<div class="user-table-wrapper"><table class="user-table speed-modal-table"><thead><tr><th>Titel</th><th>Größe</th><th>Geschwindigkeit</th></tr></thead><tbody>';
    for (const item of g.last_speeds) {
      modalHtml += `<tr>
        <td class="speed-modal-title" title="${item.title}">${item.title}</td>
        <td>${item.size.toFixed(2).replace(".", ",")} MB</td>
        <td style="color:var(--accent);font-weight:600">${item.speed.toFixed(3).replace(".", ",")} MB/s</td>
      </tr>`;
    }
    modalHtml += '</tbody></table></div>';
    document.getElementById("speedModalContent").innerHTML = modalHtml;
  }

  // --- KPI row ---
  let html = '<div class="stats-kpi-row stats-kpi-main">';
  html += statCard(
    "Abgeschlossene Downloads",
    g.completed ?? "—",
    "Erfolgreich heruntergeladene Queue-Einträge",
    "#22c55e"
  );
  html += statCard(
    "Heruntergeladene Episoden",
    g.total_episodes ?? "—",
    "Einzelne Episoden über alle Downloads",
    "#6ea8fe"
  );
  html += statCard(
    "Heruntergeladene Filme",
    g.movie_files ?? "—",
    `${g.movie_downloads ?? 0} FilmPalast-Downloads`,
    "#e8914a"
  );
  html += statCard(
    "Fehlgeschlagen",
    g.failed ?? "—",
    "Downloads mit Fehlern oder ohne Stream",
    "#f87171"
  );
  html += statCard(
    "Letzte 24 Stunden",
    g.last_24h_completed ?? "—",
    "Downloads abgeschlossen in den letzten 24h",
    "#a78bfa"
  );
  html += statCard(
    "Ø Download-Dauer",
    fmtDuration(g.average_duration_seconds),
    "Durchschnittliche Zeit pro Queue-Eintrag",
    "#fb923c"
  );
  html += statCard(
    "Ø Geschwindigkeit",
    g.average_speed_mbps ? `${String(g.average_speed_mbps).replace(".", ",")} MB/s` : "—",
    (g.total_size_mb ? `Gesamt: ${g.total_size_mb} MB geladen` : "Keine Daten" + "<br>Klicken für Details"),
    "#06b6d4",
    "openSpeedModal()"
  );
  html += statCard(
    "Auto-Sync Jobs",
    `${s.enabled ?? 0} aktiv`,
    `${s.total_jobs ?? 0} Jobs gesamt konfiguriert`,
    "#34d399"
  );
  html += '</div>';

  // Weekday Activity removed as requested.

  // --- Queue status breakdown ---
  html += '<div class="stats-section"><h2 class="stats-section-title">Queue-Status</h2><div class="stats-kpi-row">';
  const statusLabels = { completed: "Abgeschlossen", failed: "Fehlgeschlagen", cancelled: "Abgebrochen", running: "Läuft", queued: "Wartend" };
  for (const [st, label] of Object.entries(statusLabels)) {
    html += statCard(label, byStatus[st] ?? 0);
  }
  html += '</div></div>';

  // --- Source breakdown ---
  html += '<div class="stats-section"><h2 class="stats-section-title">Quelle</h2><div class="stats-kpi-row">';
  html += statCard("Anime (AniWorld)", g.anime_downloads ?? 0, `${g.anime_episodes ?? 0} Episoden heruntergeladen`, "#6ea8fe");
  html += statCard("Serien (S.TO)", g.series_downloads ?? 0, `${g.series_episodes ?? 0} Episoden heruntergeladen`, "#a78bfa");
  html += statCard("Filme (FilmPalast)", g.movie_downloads ?? 0, `${g.movie_files ?? 0} Filme heruntergeladen`, "#e8914a");
  html += '</div></div>';

  // --- Language breakdown table ---
  if (g.by_language && g.by_language.length) {
    html += '<div class="stats-section"><h2 class="stats-section-title">Nach Sprache</h2>';
    html += '<div class="user-table-wrapper"><table class="user-table"><thead><tr><th>Sprache</th><th>Downloads</th><th>Episoden</th></tr></thead><tbody>';
    for (const row of g.by_language) {
      html += `<tr><td>${row.language || "—"}</td><td>${row.downloads}</td><td>${row.episodes}</td></tr>`;
    }
    html += '</tbody></table></div></div>';
  }

  container.innerHTML = html;
}

loadStats();
