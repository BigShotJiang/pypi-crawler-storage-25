<a id="readme-top"></a>

# MRX-AniWorld Downloader

**MRX-AniWorld Downloader** is a cross-platform WebUI tool for downloading anime from aniworld.to, series from s.to, and movies from filmpalast.to. It runs on Windows, macOS, and Linux.

> This project is a fork of the original [AniWorld-Downloader](https://github.com/phoenixthrush/AniWorld-Downloader) by [phoenixthrush](https://github.com/phoenixthrush), [SiroxCW](https://github.com/SiroxCW) and [Tmaster055](https://github.com/Tmaster055) — maintained and extended here by [TheMRX13](https://github.com/TheMRX13) and [Domekologe](https://github.com/Domekologe).

> **Note:** The CLI has been **completely removed**. This project is now **WebUI-only**. Run `aniworld` to launch the web interface directly — no flags needed.

![GitHub Release](https://img.shields.io/github/v/release/TheMRX13/MRX-AniWorld-Downloader)
![GitHub License](https://img.shields.io/github/license/TheMRX13/MRX-AniWorld-Downloader)
![GitHub Issues or Pull Requests](https://img.shields.io/github/issues/TheMRX13/MRX-AniWorld-Downloader)
![GitHub Repo stars](https://img.shields.io/github/stars/TheMRX13/MRX-AniWorld-Downloader)
![GitHub forks](https://img.shields.io/github/forks/TheMRX13/MRX-AniWorld-Downloader)
[![Discord](https://img.shields.io/badge/Discord-Join%20Server-5865F2?logo=discord&logoColor=white)](https://discord.gg/TGaZ9hFFhC)

WebUI (Landing Page) | WebUI (Auto-Sync)
:-------------------------:|:-------------------------:
![AniWorld Downloader - Demo](https://github.com/TheMRX13/MRX-AniWorld-Downloader/blob/models/.github/assets/demo-menu.png?raw=true) | ![AniWorld Downloader - Demo](https://github.com/TheMRX13/MRX-AniWorld-Downloader/blob/models/.github/assets/demo-sync.png?raw=true)

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## TL;DR - Quick Start

```bash
# Install latest stable release (recommended)
pip install mrx-aniworld

# Install latest development commit (may be unstable)
pip install --upgrade git+https://github.com/TheMRX13/MRX-AniWorld-Downloader.git@models#egg=aniworld

# Launch AniWorld Downloader (starts WebUI directly)
aniworld

# Use a custom port
aniworld -wP 9090
```

> **Installed version:** Run `pip show mrx-aniworld` to see your installed version. Release installs show a plain version number (e.g. `2.1.6`), dev installs show the base version plus the commit hash (e.g. `2.1.6-dev+abc1234`).

> **⚠️ Requirements:** ffmpeg must be installed and available in your system PATH for the downloader to work properly.

The WebUI starts on `0.0.0.0` (all interfaces) with authentication enabled by default. Open your browser and navigate to `http://localhost:8080` (or your custom port).

> **No `.env` file needed.** All settings are configured directly in the WebUI under **Settings**. Existing `.env` files from previous versions are automatically imported into the database on first start.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## CLI Removed

The CLI (interactive menu, direct URL downloads, SyncPlay, AniSkip, Anime4K flags) has been **fully removed** in this fork. All functionality is available through the WebUI. The only command-line flags are:

| Flag | Description |
| --- | --- |
| `-wP` / `--web-port` | Port for the web UI (default: `8080`) |
| `-wN` / `--no-browser` | Don't open the browser automatically on startup |
| `-d` / `--debug` | Enable debug logging |

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## Still in Development

This project is actively being improved. Current work in progress includes:

- [ ] Multi-Language Support — UI currently German only, English and other languages planned
- [ ] More Extractors — additional video host support beyond the current providers
- [ ] Live Transcode / In-Browser Playback — watch downloaded files directly in the UI
- [ ] More Sources — additional anime, series and movie providers (open a feature request)
- [ ] AutoSync Episode Filter — configure per job which seasons/episodes to sync, skip specials/OVAs
- [ ] Provider Fallback Order — automatically try the next provider if the primary one fails
- [ ] Calendar View — show upcoming episode air dates for AutoSync jobs based on TMDB data
- [ ] Bandwidth Limit / Download Time Window — throttle speed or restrict downloads to specific hours
- [ ] Download History — searchable log of all completed downloads with date, size and duration
- [ ] Generic Outgoing Webhook — send a configurable POST request on download completion (Home Assistant, n8n, etc.)
- [ ] Subtitle Support — additional language and subtitle download options

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## Features

### Web Interface
- **Browse & Search** – Explore and search titles from AniWorld, SerienStream and FilmPalast in a modern UI
- **Download Queue** – Manage active, queued, and completed downloads in real time
- **Media Library** – Browse your downloaded files in a built-in file explorer with series/season/episode tree view
- **Favourites** – Bookmark series and access them quickly from a dedicated page
- **AutoSync** – Automatically check for new episodes and download them on a schedule; import/export sync jobs as JSON
- **Statistics** – View detailed download activity: total episodes, storage used, and more
- **Encoding Settings** – Configure FFmpeg encoding mode (Stream Copy, H.264, H.265/HEVC) with hardware acceleration support (NVENC, VAAPI, VideoToolbox) and quality presets
- **Push Notifications** – Get notified on completed downloads via **Web Push**, **Telegram**, **Pushover**, **Discord**, or **WhatsApp**
- **CineInfo** – Enrich series cards and detail views with **TMDB** metadata: streaming providers, FSK age ratings, genres, and audience scores
- **Jellyfin / Plex Integration** – Automatically trigger a library refresh after each download
- **Seerr Integration** – Connect to **Jellyseerr** or **Overseerr** to view and process pending media requests directly in the UI
- **Settings** – All configuration is done through the WebUI — no `.env` file needed. Settings are organized in tabs: General, Downloads, Auto-Sync, Network, Authentication, API, and Updates
- **Authentication & SSO** – Always-on local authentication with multi-user support and roles; optional OIDC Single Sign-On (Keycloak, Authentik, Google, etc.) configurable entirely from the UI
- **Network Exposure** – Binds to `0.0.0.0` by default for LAN/Docker access
- **API** – Full REST API for programmatic access to all download and queue features
- **Docker Ready** – Deploy easily using **Docker** or **Docker Compose**
- **Anime Upscaling** – Upscaling Animes out of the box with **Anime4K**

### Core Download Engine
- **Downloading** – Grab full series, individual seasons, or single episodes for offline viewing
- **Multiple Providers** – Stream from various sources on **aniworld.to**, **s.to** and **filmpalast.to**
- **Language Preferences** – Switch between **German Dub**, **English Sub**, or **German Sub**
- **Muxing** – Automatically combine video and audio streams into a single file

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## Supported Site Providers

These are the websites you can pass URLs from:

| Site | URL | Status | Notes |
| --- | --- | --- | --- |
| AniWorld | aniworld.to | ✅ Working | Anime, German dub & sub |
| SerienStream | s.to | ✅ Working | Series, German dub & sub |
| FilmPalast | filmpalast.to | ✅ Working | Movies only |

## Supported Video Extractors

These are the video hosters used behind the scenes to deliver the stream:

| Extractor | Status | Last Tested |
| --- | --- | --- |
| VOE | ✅ Working | 04/26 |
| Vidoza | ✅ Working | 04/26 |
| Vidmoly | ✅ Working | 04/26 |
| Filemoon | ✅ Working | 04/26 |
| Doodstream | ✅ Working | 04/26 |
| Vidara | ✅ Working | 04/26 |
| Vidsonic | ⏳ Not Implemented | — |
| Upbolt | ⏳ Not Implemented | — |
| Streamtape | ⏳ Not Implemented | — |
| LoadX | ⏳ Not Implemented | — |
| Luluvdo | ⏳ Not Implemented | — |

### Currently Prioritized Extractors per Site

- **AniWorld** – VOE, Filemoon, Vidmoly
- **SerienStream** – VOE, Vidoza
- **FilmPalast** – VOE (soon Vidara and Vidsonic)

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## Docker

Build the AniWorld Downloader Docker image:

```bash
docker build -t aniworld .
```

### Running the Container

- **macOS / Linux (bash/zsh):**

```bash
docker run -it --rm \
  -p 8080:8080 \
  -v "${PWD}/Downloads:/app/Downloads" \
  aniworld
```

- **Windows (PowerShell):**

```powershell
docker run -it --rm `
  -p 8080:8080 `
  -v "${PWD}\Downloads:/app/Downloads" `
  aniworld
```

> **Note:**
> Mount your local `Downloads` folder to `/app/Downloads` in the container to save downloaded episodes. The WebUI is available at `http://localhost:8080`.

### Docker Compose (with Web UI)

Start AniWorld Downloader using Docker Compose:

```bash
docker-compose up -d --build
```

This command will:

- **Build the Docker image** if it hasn't been built yet
- **Start the container** in detached mode (`-d`)
- Launch the **WebUI** automatically
- Automatically **restart the container unless stopped manually** (`restart: unless-stopped`)

To stop the container:

```bash
docker-compose down
```

> All settings (language, provider, SSO, reverse proxy URL, etc.) are configured via the WebUI after first launch — no `.env` file or environment variables required. See `docker-compose.yaml` for optional automation via environment variables (e.g. pre-creating an admin account).

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## Contributing

Contributions to MRX-AniWorld Downloader are **highly appreciated**! You can help improve the project in several ways:

- **Report Bugs** – Identify and report issues to improve functionality
- **Suggest Features** – Share ideas to expand the tool's capabilities
- **Submit Pull Requests** – Contribute code to fix bugs or add new features
- **Improve Documentation** – Help enhance user guides, tutorials, and technical documentation

Before submitting contributions, please check the repository for existing issues or feature requests to avoid duplicates. You're also welcome to discuss ideas on our [Discord](https://discord.gg/TGaZ9hFFhC) before opening a PR.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## Credits

MRX-AniWorld Downloader builds upon the work of several outstanding open-source projects and individuals:

### Original Authors
- **[phoenixthrush](https://github.com/phoenixthrush)** – Original creator of [AniWorld-Downloader](https://github.com/phoenixthrush/AniWorld-Downloader)
- **[SiroxCW](https://github.com/SiroxCW)** – Core contributor to the original codebase
- **[Tmaster055](https://github.com/Tmaster055)** – Core contributor to the original codebase

### Libraries & Tools
- **[mpv](https://github.com/mpv-player/mpv.git)** – A versatile media player used for seamless video streaming
- **[Flask](https://flask.palletsprojects.com/)** – Web framework powering the WebUI
- **[Waitress](https://docs.pylonsproject.org/projects/waitress/)** – Production WSGI server

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## Other Cool Projects

- **[Jellyfin AniWorld Downloader](https://github.com/SiroxCW/Jellyfin-AniWorld-Downloader)** by **[SiroxCW](https://github.com/SiroxCW)** – A Jellyfin plugin that lets you browse and download anime & series directly from AniWorld, fully integrated into your media server.

- **[AniBridge](https://github.com/Zzackllack/AniBridge)** by **[Zzackllack](https://github.com/Zzackllack)** – A minimal FastAPI service that bridges anime and series streaming catalogues (AniWorld, SerienStream/s.to, MegaKino) with automation tools.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## Support

If you need help with MRX-AniWorld Downloader, you have several options:

- **Join the [Discord Server](https://discord.gg/TGaZ9hFFhC)** – the fastest way to get help, ask questions, and chat with other users
- **Submit an issue** on the [GitHub Issues](https://github.com/TheMRX13/MRX-AniWorld-Downloader/issues) page – preferred for installation problems, bug reports, or feature requests, as it helps others benefit from shared solutions

If you find MRX-AniWorld Downloader useful, please star the repository on GitHub. Your support is greatly appreciated and motivates continued development.

Thank you for using MRX-AniWorld Downloader!

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## Legal Disclaimer

MRX-AniWorld Downloader is a **client-side** tool that enables access to content hosted on third-party websites. It **does not host, upload, store, or distribute any media itself**.

This software is **not intended to promote piracy or copyright infringement**. You are solely responsible for how you use MRX-AniWorld Downloader and for ensuring that your use **complies with applicable laws** and the **terms of service of the websites you access**.

The developer provides this project **"as is"** and is **not responsible for**:

- Third-party content
- External links
- The availability, accuracy, legality, or reliability of any third-party service

If you have concerns about specific content, **contact the relevant website owner, administrator, or hosting provider**.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

## License

This project is licensed under the **[MIT License](LICENSE)**.
For full terms and conditions, please see the LICENSE file included with this project.
