"""Tests for v0.2.0: `validate --data-dir` pre-flight check for record YAML."""

from __future__ import annotations

from pathlib import Path

import yaml
from pptx import Presentation
from pptx.util import Inches
from typer.testing import CliRunner

from recombinase.cli import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_simple_template(path: Path) -> None:
    """Template with one text box named 'Field'."""
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    tb = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(5), Inches(2))
    tb.name = "Field"
    tb.text_frame.text = "EXAMPLE"
    prs.save(str(path))


def _build_table_template(path: Path) -> None:
    """Template with one text box ('Field') and one table shape ('MyTable')."""
    from pptx.util import Emu

    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    tb = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(5), Inches(1))
    tb.name = "Field"
    tb.text_frame.text = "EXAMPLE"

    tbl = slide.shapes.add_table(
        2, 2, Emu(int(Inches(0.5))), Emu(int(Inches(2))), Emu(int(Inches(4))), Emu(int(Inches(1)))
    )
    tbl.name = "MyTable"

    prs.save(str(path))


def _write_config(
    config_path: Path,
    template_path: Path,
    placeholders: dict[str, str],
    *,
    tables: dict | None = None,
    sections: dict | None = None,
) -> None:
    data: dict = {
        "template": str(template_path),
        "source_slide_index": 1,
        "clear_source_slide": True,
        "placeholders": placeholders,
    }
    if tables:
        data["tables"] = tables
    if sections:
        data["sections"] = sections
    config_path.write_text(yaml.safe_dump(data), encoding="utf-8")


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_validate_data_dir_happy_path(tmp_path: Path) -> None:
    """Records with all expected fields produce exit 0 and a pass message."""
    template_path = tmp_path / "t.pptx"
    _build_simple_template(template_path)

    config_path = tmp_path / "config.yaml"
    _write_config(config_path, template_path, {"name": "Field"})

    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "r1.yaml").write_text(
        yaml.safe_dump({"id": "r1", "name": "Alice"}),
        encoding="utf-8",
    )

    result = runner.invoke(app, ["validate", "-c", str(config_path), "-d", str(data_dir)])
    assert result.exit_code == 0, result.output
    assert "Data validation passed" in result.output
    assert "Config is valid" in result.output


def test_validate_data_dir_missing_field_warns(tmp_path: Path) -> None:
    """A record missing a placeholder field produces a warning in output."""
    template_path = tmp_path / "t.pptx"
    _build_simple_template(template_path)

    config_path = tmp_path / "config.yaml"
    _write_config(config_path, template_path, {"name": "Field"})

    data_dir = tmp_path / "data"
    data_dir.mkdir()
    # Record has no 'name' field
    (data_dir / "r1.yaml").write_text(
        yaml.safe_dump({"id": "r1", "role": "Consultant"}),
        encoding="utf-8",
    )

    result = runner.invoke(app, ["validate", "-c", str(config_path), "-d", str(data_dir)])
    assert result.exit_code == 0, result.output
    combined = result.output + (result.stderr if hasattr(result, "stderr") else "")
    assert "name" in combined
    assert "missing" in combined


def test_validate_data_dir_wrong_type_table(tmp_path: Path) -> None:
    """A table field that is a scalar (not a list) produces a type warning."""
    template_path = tmp_path / "t.pptx"
    _build_table_template(template_path)

    config_path = tmp_path / "config.yaml"
    _write_config(
        config_path,
        template_path,
        {"name": "Field"},
        tables={"entries": {"shape": "MyTable", "columns": ["col1"]}},
    )

    data_dir = tmp_path / "data"
    data_dir.mkdir()
    # 'entries' is a string instead of a list
    (data_dir / "r1.yaml").write_text(
        yaml.safe_dump({"id": "r1", "name": "Alice", "entries": "not-a-list"}),
        encoding="utf-8",
    )

    result = runner.invoke(app, ["validate", "-c", str(config_path), "-d", str(data_dir)])
    assert result.exit_code == 0, result.output
    combined = result.output + (result.stderr if hasattr(result, "stderr") else "")
    assert "entries" in combined
    assert "list" in combined


def test_validate_data_dir_extra_fields(tmp_path: Path) -> None:
    """A record with fields not in the config produces an extra-field warning."""
    template_path = tmp_path / "t.pptx"
    _build_simple_template(template_path)

    config_path = tmp_path / "config.yaml"
    _write_config(config_path, template_path, {"name": "Field"})

    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "r1.yaml").write_text(
        yaml.safe_dump({"id": "r1", "name": "Alice", "ghost_field": "unexpected"}),
        encoding="utf-8",
    )

    result = runner.invoke(app, ["validate", "-c", str(config_path), "-d", str(data_dir)])
    assert result.exit_code == 0, result.output
    combined = result.output + (result.stderr if hasattr(result, "stderr") else "")
    assert "ghost_field" in combined
    assert "unexpected" in combined


def test_validate_data_dir_strict_exits_2(tmp_path: Path) -> None:
    """With --strict and data warnings, exit code is 2."""
    template_path = tmp_path / "t.pptx"
    _build_simple_template(template_path)

    config_path = tmp_path / "config.yaml"
    _write_config(config_path, template_path, {"name": "Field"})

    data_dir = tmp_path / "data"
    data_dir.mkdir()
    # Missing 'name' will trigger a warning
    (data_dir / "r1.yaml").write_text(
        yaml.safe_dump({"id": "r1"}),
        encoding="utf-8",
    )

    result = runner.invoke(
        app, ["validate", "-c", str(config_path), "-d", str(data_dir), "--strict"]
    )
    assert result.exit_code == 2
