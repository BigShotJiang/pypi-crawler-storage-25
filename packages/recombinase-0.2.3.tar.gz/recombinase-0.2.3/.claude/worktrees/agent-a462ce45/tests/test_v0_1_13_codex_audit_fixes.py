"""v0.1.13: Codex audit fix-ups.

Covers the seven findings from the 2026-04-11 Codex audit:

HIGH
----
1. populate_table clears cells when a row dict is missing a column key
   (previously the duplicated example text leaked into the output).
2. populate_table clears excess data rows when the record has fewer rows
   than the template table can hold (previously example rows leaked).

MED
---
3. cli.validate honours config.tables — table shape typos are now caught.
4. load_records stamps `_recombinase_record_dir` so relative picture paths
   resolve against the YAML file's directory instead of CWD.
5. write_scaffold_config uses yaml.safe_dump so YAML-significant characters
   in shape names are quoted correctly.

LOW
---
6. load_config distinguishes None from wrong-type empty config sections.
7. cli.generate --dry-run uses TemporaryDirectory so the temp dir is
   cleaned up even when generate_deck raises.
"""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from pptx import Presentation
from pptx.util import Inches

from recombinase.config import TableConfig, load_config, write_scaffold_config
from recombinase.generate import (
    find_shape_by_name,
    load_records,
    populate_table,
    set_shape_value,
)

# -- populate_table HIGH fixes ---------------------------------------------


def _build_template_with_table(path: Path, data_rows: int = 2) -> None:
    """Template with a named table: 1 header row + N data rows, all pre-filled."""
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    total_rows = data_rows + 1
    table_shape = slide.shapes.add_table(
        rows=total_rows,
        cols=3,
        left=Inches(0.5),
        top=Inches(0.5),
        width=Inches(8),
        height=Inches(2),
    )
    table_shape.name = "projects"
    table = table_shape.table
    table.cell(0, 0).text = "Client"
    table.cell(0, 1).text = "Role"
    table.cell(0, 2).text = "Outcome"
    for row_index in range(1, total_rows):
        table.cell(row_index, 0).text = f"EXAMPLE CLIENT {row_index}"
        table.cell(row_index, 1).text = f"EXAMPLE ROLE {row_index}"
        table.cell(row_index, 2).text = f"EXAMPLE OUTCOME {row_index}"
    prs.save(str(path))


def _load_table_shape(template_path: Path):
    prs = Presentation(str(template_path))
    shape = find_shape_by_name(prs.slides[0], "projects")
    assert shape is not None
    return prs, shape


def test_missing_column_key_clears_cell_and_warns(tmp_path: Path) -> None:
    """Finding 1: a row dict missing a column key used to leak example text."""
    template = tmp_path / "t.pptx"
    _build_template_with_table(template, data_rows=2)
    _, shape = _load_table_shape(template)

    config = TableConfig(
        shape="projects",
        columns=["client", "role", "outcome"],
        header_row=True,
    )
    # Row 0 is missing 'role'; row 1 is complete
    rows = [
        {"client": "Bank A", "outcome": "Delivered"},
        {"client": "Bank B", "role": "Lead", "outcome": "Designed"},
    ]
    warnings = populate_table(shape, config, rows)

    table = shape.table
    # The missing column should be CLEARED, not left with 'EXAMPLE ROLE 1'
    assert table.cell(1, 0).text == "Bank A"
    assert table.cell(1, 1).text == ""
    assert table.cell(1, 2).text == "Delivered"
    # Row 1 is fully populated
    assert table.cell(2, 0).text == "Bank B"
    assert table.cell(2, 1).text == "Lead"
    assert table.cell(2, 2).text == "Designed"
    # And the user is warned about the missing column
    assert any("missing column 'role'" in w for w in warnings)


def test_none_value_clears_cell(tmp_path: Path) -> None:
    """Finding 1b: explicit None should clear, not skip."""
    template = tmp_path / "t.pptx"
    _build_template_with_table(template, data_rows=2)
    _, shape = _load_table_shape(template)

    config = TableConfig(
        shape="projects",
        columns=["client", "role", "outcome"],
        header_row=True,
    )
    rows = [
        {"client": "Bank A", "role": None, "outcome": "Delivered"},
        {"client": "Bank B", "role": "Lead", "outcome": "Designed"},
    ]
    populate_table(shape, config, rows)
    table = shape.table
    assert table.cell(1, 1).text == ""  # cleared, not "EXAMPLE ROLE 1"


def test_empty_string_value_clears_cell(tmp_path: Path) -> None:
    """Finding 1c: empty string should clear, not skip."""
    template = tmp_path / "t.pptx"
    _build_template_with_table(template, data_rows=2)
    _, shape = _load_table_shape(template)

    config = TableConfig(
        shape="projects",
        columns=["client", "role", "outcome"],
        header_row=True,
    )
    rows = [
        {"client": "Bank A", "role": "", "outcome": "Delivered"},
        {"client": "Bank B", "role": "Lead", "outcome": "Designed"},
    ]
    populate_table(shape, config, rows)
    table = shape.table
    assert table.cell(1, 1).text == ""


def test_short_record_clears_excess_data_rows(tmp_path: Path) -> None:
    """Finding 2: unused data rows used to leak example text."""
    template = tmp_path / "t.pptx"
    _build_template_with_table(template, data_rows=3)  # header + 3 data rows
    _, shape = _load_table_shape(template)

    config = TableConfig(
        shape="projects",
        columns=["client", "role", "outcome"],
        header_row=True,
    )
    rows = [
        {"client": "Bank A", "role": "Lead", "outcome": "Delivered"},
    ]
    warnings = populate_table(shape, config, rows)

    table = shape.table
    # Row 1 populated
    assert table.cell(1, 0).text == "Bank A"
    # Rows 2 and 3 cleared — no leaked EXAMPLE text
    assert table.cell(2, 0).text == ""
    assert table.cell(2, 1).text == ""
    assert table.cell(2, 2).text == ""
    assert table.cell(3, 0).text == ""
    assert table.cell(3, 1).text == ""
    assert table.cell(3, 2).text == ""
    assert any("clearing 2 unused row" in w for w in warnings)


def test_combined_missing_column_and_short_record(tmp_path: Path) -> None:
    """Finding 1 + 2: both bugs at once."""
    template = tmp_path / "t.pptx"
    _build_template_with_table(template, data_rows=3)
    _, shape = _load_table_shape(template)

    config = TableConfig(
        shape="projects",
        columns=["client", "role", "outcome"],
        header_row=True,
    )
    # One record, missing 'outcome'
    rows = [{"client": "Bank A", "role": "Lead"}]
    warnings = populate_table(shape, config, rows)

    table = shape.table
    assert table.cell(1, 0).text == "Bank A"
    assert table.cell(1, 1).text == "Lead"
    assert table.cell(1, 2).text == ""  # missing column cleared
    # Excess rows cleared
    for row_index in (2, 3):
        for col_index in range(3):
            assert table.cell(row_index, col_index).text == ""
    # Both warnings present
    assert any("missing column 'outcome'" in w for w in warnings)
    assert any("clearing 2 unused row" in w for w in warnings)


def test_scalar_value_preserves_run_level_font(tmp_path: Path) -> None:
    """Gemini finding: set_shape_value scalar path must preserve run rPr.

    The prior implementation used `tf.text = text` for single-line scalars,
    which python-pptx implements as `clear()` + new paragraph — wiping both
    pPr AND the first run's rPr (font name, size, weight, color). Every
    scalar-valued shape on a CV template (name, role, summary header) would
    silently lose its run-level font.

    Build a textbox with Calibri 18pt bold red, populate it via
    set_shape_value with a scalar, reopen, and assert the font survived.
    """
    from pptx.dml.color import RGBColor
    from pptx.util import Pt

    template = tmp_path / "scalar_font.pptx"
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    tb = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(5), Inches(1))
    tb.name = "NameField"
    tb.text_frame.text = "EXAMPLE NAME"
    run = tb.text_frame.paragraphs[0].runs[0]
    run.font.name = "Calibri"
    run.font.size = Pt(18)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0xCC, 0x00, 0x00)
    prs.save(str(template))

    prs2 = Presentation(str(template))
    shape = find_shape_by_name(prs2.slides[0], "NameField")
    assert shape is not None

    set_shape_value(shape, "Terry Li")

    # Save-reopen cycle to confirm the rPr actually persists in the pptx
    output = tmp_path / "out.pptx"
    prs2.save(str(output))
    reopened = Presentation(str(output))
    reopened_shape = find_shape_by_name(reopened.slides[0], "NameField")
    assert reopened_shape is not None
    para = reopened_shape.text_frame.paragraphs[0]
    assert para.runs, "text disappeared after set_shape_value"
    run2 = para.runs[0]
    assert run2.text == "Terry Li"
    assert run2.font.name == "Calibri"
    assert run2.font.size == Pt(18)
    assert run2.font.bold is True
    assert run2.font.color.rgb == RGBColor(0xCC, 0x00, 0x00)


def test_merged_cells_do_not_crash_clear(tmp_path: Path) -> None:
    """Gemini finding (post-Codex fix): _clear_cell must skip spanned cells.

    python-pptx raises on `cell.text_frame` for spanned (merged non-origin)
    cells. The Codex audit fix added three unconditional _clear_cell loops —
    any template with merged cells in the data region would crash with
    ValueError before this guard.

    Build a table where two adjacent cells in an excess-row region are merged,
    then provide a short record. The clear-excess-rows path must succeed
    without raising; only the merge origin's text needs to go to empty.
    """
    template = tmp_path / "merged.pptx"
    _build_template_with_table(template, data_rows=3)

    # Merge two cells in row 2 (an excess row we'll clear) BEFORE saving.
    prs = Presentation(str(template))
    shape = find_shape_by_name(prs.slides[0], "projects")
    assert shape is not None
    origin = shape.table.cell(2, 0)
    other = shape.table.cell(2, 1)
    origin.merge(other)
    prs.save(str(template))

    _, shape = _load_table_shape(template)
    config = TableConfig(
        shape="projects",
        columns=["client", "role", "outcome"],
        header_row=True,
    )
    # One record → rows 2 and 3 are excess → the merged cells get cleared
    rows = [{"client": "Bank A", "role": "Lead", "outcome": "Delivered"}]

    # Must NOT raise. Before the is_spanned guard, this raised ValueError
    # on cell.text_frame access for the spanned non-origin cell.
    warnings = populate_table(shape, config, rows)

    table = shape.table
    # Populated row is intact
    assert table.cell(1, 0).text == "Bank A"
    # Excess row 3 fully cleared (non-merged)
    assert table.cell(3, 0).text == ""
    assert table.cell(3, 1).text == ""
    assert table.cell(3, 2).text == ""
    # Merge origin in row 2 is cleared (spanned sibling skipped silently)
    assert table.cell(2, 0).text == ""
    assert any("clearing 2 unused row" in w for w in warnings)


def test_fully_populated_still_works_no_extra_warnings(tmp_path: Path) -> None:
    """Regression: a fully populated table still succeeds with no warnings."""
    template = tmp_path / "t.pptx"
    _build_template_with_table(template, data_rows=2)
    _, shape = _load_table_shape(template)

    config = TableConfig(
        shape="projects",
        columns=["client", "role", "outcome"],
        header_row=True,
    )
    rows = [
        {"client": "Bank A", "role": "Lead", "outcome": "Delivered"},
        {"client": "Bank B", "role": "Advisor", "outcome": "Designed"},
    ]
    warnings = populate_table(shape, config, rows)
    assert warnings == []
    table = shape.table
    assert table.cell(1, 0).text == "Bank A"
    assert table.cell(2, 0).text == "Bank B"


# -- MED: cli validate covers table shapes ---------------------------------


def test_validate_flags_missing_table_shape(tmp_path: Path) -> None:
    """Finding 3: typos in table.shape must be flagged by `recombinase validate`."""
    from typer.testing import CliRunner

    from recombinase.cli import app

    # Build a template with the table named 'projects'
    template = tmp_path / "t.pptx"
    _build_template_with_table(template, data_rows=2)

    # Config references a DIFFERENT table shape name (typo)
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "template": str(template),
                "source_slide_index": 1,
                "clear_source_slide": True,
                "placeholders": {},
                "tables": {
                    "projects": {
                        "shape": "projets",  # typo
                        "columns": ["client", "role", "outcome"],
                        "header_row": True,
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    runner = CliRunner()
    result = runner.invoke(app, ["validate", "--config", str(config_path)])
    assert result.exit_code == 1
    assert "projets" in result.output
    assert "table field" in result.output


def test_validate_accepts_matching_table_shape(tmp_path: Path) -> None:
    """Finding 3b: correct table shape names validate cleanly."""
    from typer.testing import CliRunner

    from recombinase.cli import app

    template = tmp_path / "t.pptx"
    _build_template_with_table(template, data_rows=2)

    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "template": str(template),
                "source_slide_index": 1,
                "clear_source_slide": True,
                "placeholders": {},
                "tables": {
                    "projects": {
                        "shape": "projects",
                        "columns": ["client", "role", "outcome"],
                        "header_row": True,
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    runner = CliRunner()
    result = runner.invoke(app, ["validate", "--config", str(config_path)])
    assert result.exit_code == 0
    assert "valid" in result.output.lower()


# -- MED: load_records stamps record dir -----------------------------------


def test_load_records_stamps_record_dir(tmp_path: Path) -> None:
    """Finding 4: relative picture paths must resolve against the YAML dir."""
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "r1.yaml").write_text(
        yaml.safe_dump({"id": "r1", "name": "Alpha"}),
        encoding="utf-8",
    )
    records = load_records(data_dir)
    assert len(records) == 1
    record = records[0]
    assert record["_recombinase_record_dir"] == str(data_dir)
    # Sanity: stays attached through a Path() conversion, the same way
    # generate_deck uses it to build base_dir for set_picture.
    base_dir = Path(record["_recombinase_record_dir"])
    assert base_dir == data_dir


# -- MED: write_scaffold_config uses yaml.safe_dump ------------------------


def test_scaffold_config_quotes_special_characters(tmp_path: Path) -> None:
    """Finding 5: shape names with YAML-significant chars used to break the scaffold."""
    template_path = tmp_path / "t.pptx"
    # create a minimal dummy so write_scaffold_config has a real path string
    Presentation().save(str(template_path))
    output_path = tmp_path / "scaffold.yaml"

    # Shape names containing YAML-significant characters
    shape_names = [
        "Name: Title",  # colon-space — yaml mapping indicator
        "Role #1",  # hash — comment indicator
        "Summary {short}",  # braces — flow mapping
        "List [bullets]",  # brackets — flow sequence
    ]
    write_scaffold_config(template_path, shape_names, output_path)

    # The file must parse cleanly through load_config
    cfg = load_config(output_path)
    # Every shape name should be present in the round-tripped placeholders
    round_tripped = set(cfg.placeholders.values())
    for name in shape_names:
        assert name in round_tripped, f"shape {name!r} lost in scaffold round-trip"


# -- LOW: load_config distinguishes None from wrong-type ------------------


def test_load_config_rejects_wrong_type_placeholders(tmp_path: Path) -> None:
    """Finding 6: a list where a mapping is expected used to be silently accepted."""
    template_path = tmp_path / "t.pptx"
    Presentation().save(str(template_path))

    config_path = tmp_path / "c.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "template": str(template_path),
                "placeholders": [],  # wrong type — used to short-circuit to {}
                "tables": {
                    "projects": {"shape": "projects", "columns": ["a", "b"]},
                },
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="'placeholders' must be a mapping"):
        load_config(config_path)


def test_load_config_accepts_null_placeholders(tmp_path: Path) -> None:
    """Finding 6b: explicit null should still be treated as empty."""
    template_path = tmp_path / "t.pptx"
    Presentation().save(str(template_path))

    config_path = tmp_path / "c.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "template": str(template_path),
                "placeholders": None,
                "tables": {
                    "projects": {"shape": "projects", "columns": ["a", "b"]},
                },
            }
        ),
        encoding="utf-8",
    )

    cfg = load_config(config_path)
    assert cfg.placeholders == {}
    assert "projects" in cfg.tables


def test_load_config_rejects_wrong_type_table_columns(tmp_path: Path) -> None:
    """Finding 6c: a dict where a list is expected for columns must be rejected."""
    template_path = tmp_path / "t.pptx"
    Presentation().save(str(template_path))

    config_path = tmp_path / "c.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "template": str(template_path),
                "placeholders": {"name": "Field"},
                "tables": {
                    "projects": {"shape": "projects", "columns": {"a": 1}},
                },
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="must be a list of strings"):
        load_config(config_path)


# -- LOW: dry-run tempdir is cleaned up on exception -----------------------


def test_dry_run_uses_context_manager_for_tempdir(monkeypatch, tmp_path: Path) -> None:
    """Finding 7: if generate_deck raises, the tempdir must still be cleaned up.

    We patch generate_deck to raise and confirm TemporaryDirectory semantics —
    namely that after the command returns, no new permanent directory is
    lingering inside the system tempdir. We can't easily observe the exact
    tempdir name, so we rely on the context-manager guarantee: the command's
    own `with` block has exited by the time we inspect state.
    """
    import tempfile

    from typer.testing import CliRunner

    from recombinase import cli as cli_mod
    from recombinase.cli import app

    # Minimal scaffold so the command gets as far as calling generate_deck
    template_path = tmp_path / "t.pptx"
    _build_template_with_table(template_path, data_rows=2)

    data_dir = tmp_path / "data"
    data_dir.mkdir()
    (data_dir / "r1.yaml").write_text(
        yaml.safe_dump(
            {
                "id": "r1",
                "projects": [
                    {"client": "A", "role": "Lead", "outcome": "Delivered"},
                ],
            }
        ),
        encoding="utf-8",
    )

    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "template": str(template_path),
                "source_slide_index": 1,
                "clear_source_slide": True,
                "overflow_ratio": 0,
                "placeholders": {},
                "tables": {
                    "projects": {
                        "shape": "projects",
                        "columns": ["client", "role", "outcome"],
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    captured_tempdirs: list[str] = []
    original_temp_dir_cls = tempfile.TemporaryDirectory

    class TrackingTempDir(original_temp_dir_cls):  # type: ignore[misc, valid-type]
        def __enter__(self) -> str:
            path = super().__enter__()
            captured_tempdirs.append(path)
            return path

    monkeypatch.setattr(tempfile, "TemporaryDirectory", TrackingTempDir)

    def boom(*_args: object, **_kwargs: object) -> None:
        raise RuntimeError("synthetic failure mid-generate")

    monkeypatch.setattr(cli_mod, "generate_deck", boom)

    runner = CliRunner()
    # Writing to a temp output path inside tmp_path so the command doesn't
    # bail on "file exists".
    output_path = tmp_path / "out.pptx"
    result = runner.invoke(
        app,
        [
            "generate",
            "--config",
            str(config_path),
            "--data-dir",
            str(data_dir),
            "--output",
            str(output_path),
            "--dry-run",
        ],
    )
    # The command should have propagated the RuntimeError — but the
    # TemporaryDirectory must have been cleaned up regardless.
    assert result.exit_code != 0
    assert captured_tempdirs, "dry-run did not enter a TemporaryDirectory context"
    for tempdir in captured_tempdirs:
        assert not Path(tempdir).exists(), (
            f"dry-run tempdir {tempdir} leaked after generate_deck raised"
        )


# -- Gemini findings #3-5 ---------------------------------------------------


def test_footer_rows_preserves_static_footer(tmp_path: Path) -> None:
    """TableConfig.footer_rows protects trailing rows from population and clearing.

    A template with a "Total" row at the bottom should survive a short
    record — neither populated as a data row nor wiped by the clear-excess
    pass.
    """
    template = tmp_path / "with_footer.pptx"
    # 1 header + 3 data + 1 footer = 5 rows total
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    table_shape = slide.shapes.add_table(
        rows=5, cols=3, left=Inches(0.5), top=Inches(0.5), width=Inches(8), height=Inches(2)
    )
    table_shape.name = "projects"
    table = table_shape.table
    # Header
    table.cell(0, 0).text = "Client"
    table.cell(0, 1).text = "Role"
    table.cell(0, 2).text = "Outcome"
    # Data placeholders
    for row_index in range(1, 4):
        table.cell(row_index, 0).text = f"EXAMPLE CLIENT {row_index}"
        table.cell(row_index, 1).text = f"EXAMPLE ROLE {row_index}"
        table.cell(row_index, 2).text = f"EXAMPLE OUTCOME {row_index}"
    # Footer (must survive)
    table.cell(4, 0).text = "Total"
    table.cell(4, 1).text = "—"
    table.cell(4, 2).text = "3 projects"
    prs.save(str(template))

    _, shape = _load_table_shape(template)
    config = TableConfig(
        shape="projects",
        columns=["client", "role", "outcome"],
        header_row=True,
        footer_rows=1,
    )
    rows = [{"client": "Bank A", "role": "Lead", "outcome": "Delivered"}]
    warnings = populate_table(shape, config, rows)

    table = shape.table
    # Header preserved
    assert table.cell(0, 0).text == "Client"
    # Data row 1 populated
    assert table.cell(1, 0).text == "Bank A"
    # Rows 2 and 3 cleared (excess data rows)
    assert table.cell(2, 0).text == ""
    assert table.cell(3, 0).text == ""
    # Footer fully preserved — this is the critical assertion
    assert table.cell(4, 0).text == "Total"
    assert table.cell(4, 1).text == "—"
    assert table.cell(4, 2).text == "3 projects"
    # Warning names unused rows but NOT the footer
    assert any("clearing 2 unused row" in w for w in warnings)


def test_footer_rows_load_config_roundtrip(tmp_path: Path, simple_template: Path) -> None:
    """footer_rows must round-trip through load_config."""
    config_path = tmp_path / "c.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "template": str(simple_template),
                "placeholders": {"name": "Field"},
                "tables": {
                    "projects": {
                        "shape": "projects",
                        "columns": ["a", "b"],
                        "footer_rows": 2,
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    cfg = load_config(config_path)
    assert cfg.tables["projects"].footer_rows == 2


def test_footer_rows_rejects_negative_value(tmp_path: Path, simple_template: Path) -> None:
    """Negative footer_rows must raise, not silently clip."""
    config_path = tmp_path / "c.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "template": str(simple_template),
                "placeholders": {"name": "Field"},
                "tables": {
                    "projects": {
                        "shape": "projects",
                        "columns": ["a"],
                        "footer_rows": -1,
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match=r"footer_rows.*must be >= 0"):
        load_config(config_path)


def test_validate_flags_placeholder_on_table_shape(tmp_path: Path) -> None:
    """Gemini #4: a placeholder field pointed at a TABLE shape is a type mismatch."""
    from typer.testing import CliRunner

    from recombinase.cli import app

    template = tmp_path / "mismatch.pptx"
    _build_template_with_table(template, data_rows=2)  # table named 'projects'

    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "template": str(template),
                "source_slide_index": 1,
                "clear_source_slide": True,
                "placeholders": {"wrong_name": "projects"},  # text field -> table shape
                "tables": {},
            }
        ),
        encoding="utf-8",
    )

    runner = CliRunner()
    result = runner.invoke(app, ["validate", "--config", str(config_path)])
    assert result.exit_code == 1
    assert "TABLE shape" in result.output
    assert "wrong_name" in result.output


def test_validate_flags_table_on_non_table_shape(tmp_path: Path) -> None:
    """Gemini #4: a table field pointed at a non-table shape is a type mismatch."""
    from typer.testing import CliRunner

    from recombinase.cli import app

    # Build a template with ONLY a textbox (no table)
    template = tmp_path / "no_table.pptx"
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    tb = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(5), Inches(1))
    tb.name = "just_text"
    tb.text_frame.text = "EXAMPLE"
    prs.save(str(template))

    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "template": str(template),
                "source_slide_index": 1,
                "clear_source_slide": True,
                "placeholders": {},
                "tables": {
                    "wrong_table": {
                        "shape": "just_text",  # table field -> text shape
                        "columns": ["a", "b"],
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    runner = CliRunner()
    result = runner.invoke(app, ["validate", "--config", str(config_path)])
    assert result.exit_code == 1
    assert "NOT a table" in result.output
    assert "wrong_table" in result.output


def test_validate_strict_ignores_decorative_shape_names(tmp_path: Path) -> None:
    """Gemini #5: default decorative shape names (Rectangle N, TextBox N, etc.)
    must NOT count as "unused" under --strict, otherwise real templates fail."""
    from typer.testing import CliRunner

    from recombinase.cli import app

    template = tmp_path / "decor.pptx"
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    # Named shape mapped by config
    tb = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(5), Inches(1))
    tb.name = "Consultant_Name"
    tb.text_frame.text = "EXAMPLE"
    # Decorative shapes with default names
    for left in (3, 5):
        deco = slide.shapes.add_textbox(Inches(left), Inches(3), Inches(1), Inches(1))
        # leave name as default "TextBox N"
        deco.text_frame.text = "decor"
    prs.save(str(template))

    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        yaml.safe_dump(
            {
                "template": str(template),
                "source_slide_index": 1,
                "clear_source_slide": True,
                "placeholders": {"name": "Consultant_Name"},
                "tables": {},
            }
        ),
        encoding="utf-8",
    )

    runner = CliRunner()
    # --strict must exit 0 because the decorative TextBoxes are filtered out
    result = runner.invoke(app, ["validate", "--config", str(config_path), "--strict"])
    assert result.exit_code == 0, (
        f"--strict should ignore decorative shapes, got exit={result.exit_code}, "
        f"output={result.output}"
    )
