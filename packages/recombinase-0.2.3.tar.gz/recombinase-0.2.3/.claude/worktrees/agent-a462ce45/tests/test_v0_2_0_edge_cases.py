"""Tests for v0.2.0 edge case hardening:
- nested dict in table cell value warns and clears
- empty deck with clear_source_slide=True emits advisory warning
- empty deck still saves a valid (openable) pptx file
"""

from __future__ import annotations

from pathlib import Path

from pptx import Presentation
from pptx.util import Inches

from recombinase.config import TableConfig, TemplateConfig
from recombinase.generate import find_shape_by_name, generate_deck, populate_table

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_simple_table_template(path: Path) -> None:
    """Template with a 3-row x 2-col table (header + 2 data rows)."""
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    table_shape = slide.shapes.add_table(
        rows=3,
        cols=2,
        left=Inches(0.5),
        top=Inches(0.5),
        width=Inches(6),
        height=Inches(2),
    )
    table_shape.name = "test_table"
    table = table_shape.table
    table.cell(0, 0).text = "Name"
    table.cell(0, 1).text = "Value"
    table.cell(1, 0).text = "Example A"
    table.cell(1, 1).text = "Example B"
    table.cell(2, 0).text = "Example C"
    table.cell(2, 1).text = "Example D"
    prs.save(str(path))


def _build_minimal_template(path: Path) -> None:
    """Single-slide template with one named text box — no records needed."""
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    tb = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(4), Inches(1))
    tb.name = "Name_Field"
    tb.text_frame.text = "EXAMPLE"
    prs.save(str(path))


# ---------------------------------------------------------------------------
# 6a: nested dict in table cell value
# ---------------------------------------------------------------------------


def test_nested_dict_in_table_cell_warns_and_clears(tmp_path: Path) -> None:
    """A dict value in a table cell should emit a warning and clear the cell."""
    template_path = tmp_path / "tbl.pptx"
    _build_simple_table_template(template_path)

    prs = Presentation(str(template_path))
    shape = find_shape_by_name(prs.slides[0], "test_table")
    assert shape is not None

    config = TableConfig(
        shape="test_table",
        columns=["name", "value"],
        header_row=True,
    )

    rows = [
        {
            "name": "HSBC",
            "value": {"nested": "dict"},
        },
    ]

    warnings = populate_table(shape, config, rows)

    # At least one warning must mention "dict"
    assert any("dict" in w for w in warnings), f"Expected dict warning, got: {warnings}"

    # The cell that had the dict value should now be empty
    table = shape.table
    assert table.cell(1, 1).text == ""


# ---------------------------------------------------------------------------
# 6c: empty deck warning
# ---------------------------------------------------------------------------


def test_empty_deck_warning(tmp_path: Path) -> None:
    """generate_deck with 0 records and clear_source_slide=True should warn."""
    template_path = tmp_path / "tmpl.pptx"
    _build_minimal_template(template_path)

    config = TemplateConfig(
        template=template_path,
        source_slide_index=1,
        clear_source_slide=True,
        overflow_ratio=0,
        placeholders={},
    )

    output_path = tmp_path / "out.pptx"
    result = generate_deck(config, [], output_path)

    assert any("empty" in w for w in result["warnings"]), (
        f"Expected empty-deck warning, got: {result['warnings']}"
    )
    assert result["records_generated"] == 0


def test_empty_deck_actually_saves(tmp_path: Path) -> None:
    """generate_deck with 0 records must save a valid pptx (no crash, openable)."""
    template_path = tmp_path / "tmpl.pptx"
    _build_minimal_template(template_path)

    config = TemplateConfig(
        template=template_path,
        source_slide_index=1,
        clear_source_slide=True,
        overflow_ratio=0,
        placeholders={},
    )

    output_path = tmp_path / "empty_out.pptx"
    generate_deck(config, [], output_path)

    assert output_path.exists(), "Output file was not created"
    # Must be openable by python-pptx without exception
    prs = Presentation(str(output_path))
    assert prs is not None
