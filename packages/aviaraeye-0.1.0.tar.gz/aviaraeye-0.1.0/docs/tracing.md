# Tracing Guide

AviаraEye provides three tracing primitives: **traces**, **spans**, and **events**.

## Traces

A trace is the top-level container for an operation. Create one with `traced()`:

```python
from aviaraeye import traced

with traced("contract-extraction", user_id="u1", session_id="sess-1") as t:
    result = extract_contract(pdf_bytes)
    t.set_output(result)
```

### Parameters

| Parameter    | Type           | Description                              |
|-------------|----------------|------------------------------------------|
| `name`      | `str`          | Name for this trace                      |
| `user_id`   | `str | None`   | User attribution                         |
| `session_id`| `str | None`   | Session grouping                         |
| `org_id`    | `str | None`   | Organization (fallback for user_id)      |
| `tags`      | `list[str]`    | Filterable tags                          |
| `metadata`  | `dict`         | Custom key-value metadata                |

### ObservationHandle

The `traced()` context manager yields an `ObservationHandle` with these methods:

```python
with traced("name") as t:
    t.set_output(result)          # Set the output
    t.set_metadata({"key": "v"}) # Update metadata
    t.score("accuracy", 0.95)    # Score this trace
    t.link_prompt(prompt)        # Link a prompt version

    t.trace_id                    # Access trace ID
    t.observation_id              # Access observation ID
```

## Spans

Spans represent sub-operations within a trace:

```python
from aviaraeye import traced, span

with traced("pipeline") as t:
    with span("step-1-parse", metadata={"pages": 10}) as s:
        parsed = parse_document(doc)
        s.set_output(parsed)

    with span("step-2-extract") as s:
        extracted = extract_fields(parsed)
        s.set_output(extracted)

    t.set_output(extracted)
```

## Events

Events are point-in-time markers (no duration):

```python
from aviaraeye import traced, event

with traced("validation-pipeline"):
    data = fetch_data()
    event("data-fetched", metadata={"rows": len(data)})

    validated = validate(data)
    event("validation-complete", output={"passed": True})
```

## Decorator-Based Tracing

For simpler cases, use the `@observe` decorator:

```python
from aviaraeye import observe

@observe
def process_contract(pdf_bytes: bytes, org_id: str) -> dict:
    return extract(pdf_bytes)

@observe(name="llm-call", as_type="generation")
def call_llm(prompt: str) -> str:
    return client.chat.completions.create(...)
```

The decorator:
- Automatically creates a span (outermost call creates a trace)
- Captures function arguments as input
- Captures return value as output
- Records timing

## Nested Tracing

All primitives nest correctly:

```python
@observe
def outer():
    with span("inner-span"):
        event("something-happened")
        return inner_function()

@observe
def inner_function():
    return "result"
```

## Disabling Tracing

```python
# Globally disable
eye = AviaraEye(enabled=False)

# Or set env var
# LANGFUSE_PUBLIC_KEY=""  (empty = disabled)
```

When disabled, all tracing functions become no-ops with zero overhead.
