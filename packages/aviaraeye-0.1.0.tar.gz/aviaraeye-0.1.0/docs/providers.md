# Provider Integration Guide

AviаraEye supports three LLM providers with automatic tracing.

## OpenAI

### Drop-in Replacement

```python
# Instead of: from openai import OpenAI
from aviaraeye.providers.openai import OpenAI

client = OpenAI()

# All calls are automatically traced — no other changes needed
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello"}],
)
```

### With Trace Metadata

```python
from aviaraeye.providers.openai import OpenAI, build_traced_metadata

client = OpenAI()

response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Analyze this contract"}],
    metadata=build_traced_metadata(
        purpose="contract_analysis",
        user_id="user-123",
        org_id="org-456",
        tags=["analysis", "contracts"],
    ),
)
```

### Async Support

```python
from aviaraeye.providers.openai import AsyncOpenAI

client = AsyncOpenAI()
response = await client.chat.completions.create(...)
```

## Azure OpenAI

```python
from aviaraeye.providers.azure_openai import AzureOpenAI, build_traced_metadata

client = AzureOpenAI(
    api_key="your-api-key",
    api_version="2024-12-01-preview",
    azure_endpoint="https://your-resource.openai.azure.com/",
)

response = client.chat.completions.create(
    model="gpt-4.1",  # Your deployment name
    messages=[{"role": "user", "content": "Hello"}],
    metadata=build_traced_metadata(
        purpose="chat",
        user_id="user-1",
    ),
)
```

### Async Azure

```python
from aviaraeye.providers.azure_openai import AsyncAzureOpenAI

client = AsyncAzureOpenAI(
    api_key="...",
    api_version="2024-12-01-preview",
    azure_endpoint="https://...",
)
response = await client.chat.completions.create(...)
```

## Google Gemini

Gemini uses auto-instrumentation via OpenTelemetry. Call `instrument_gemini()` once at startup:

```python
from aviaraeye.providers.gemini import instrument_gemini

# Call once at app startup
instrument_gemini()

# Then use google.genai normally
from google import genai
from google.genai import types

client = genai.Client(api_key="your-gemini-key")

response = client.models.generate_content(
    model="gemini-2.5-flash",
    contents="Extract data from this document",
    config=types.GenerateContentConfig(temperature=0),
)
```

### With AviаraEye Tracing Context

For richer metadata, wrap Gemini calls in a `traced()` block:

```python
from aviaraeye import traced, build_metadata, build_tags

with traced(
    "contract_extraction",
    org_id="org-1",
    metadata=build_metadata(purpose="pdf_extraction", org_id="org-1"),
    tags=build_tags("extraction", "org-1"),
):
    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=[pdf_part, prompt_part],
    )
```

### Auto-Instrumentation

By default, `AviaraEye()` calls `instrument_gemini()` automatically. Disable with:

```python
eye = AviaraEye(auto_instrument_gemini=False)
```

## Checking Provider Availability

```python
from aviaraeye.providers.openai import is_available as openai_available
from aviaraeye.providers.azure_openai import is_available as azure_available
from aviaraeye.providers.gemini import is_available as gemini_available

print(f"OpenAI tracing: {openai_available()}")
print(f"Azure tracing: {azure_available()}")
print(f"Gemini tracing: {gemini_available()}")
```
