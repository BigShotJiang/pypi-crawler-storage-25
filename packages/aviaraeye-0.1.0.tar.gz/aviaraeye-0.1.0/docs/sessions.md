# User & Session Tracking Guide

AviаraEye provides utilities to group traces by user and session for analytics.

## Concepts

- **User ID**: Associates traces with a specific user (email, UUID, username)
- **Session ID**: Groups related traces into a conversation/workflow session

## Setting User/Session on Traces

### Direct on traced()

```python
from aviaraeye import traced

with traced("chat-response", user_id="user@example.com", session_id="chat-001"):
    response = generate_response(message)
```

### Session Context (Propagates to All Nested Traces)

```python
from aviaraeye import session_context

with session_context(user_id="user@example.com", session_id="chat-001"):
    # All traced() calls and auto-instrumented LLM calls
    # within this block inherit user_id and session_id
    response1 = call_llm(msg1)
    response2 = call_llm(msg2)
    response3 = call_llm(msg3)
```

### User-Only Context

```python
from aviaraeye import user_context

with user_context("user-123"):
    # All traces get user_id="user-123"
    do_work()
```

## Session ID Patterns

Session IDs should be unique per conversation/workflow:

```python
import uuid

# Chat conversations
session_id = f"chat-{conversation_id}"

# Background jobs
session_id = f"job-{celery_task_id}"

# Agent runs
session_id = f"agent-{run_id}"
```

## Combining with Metadata

```python
from aviaraeye import traced, session_context, build_metadata

with session_context(user_id="user-1", session_id="workflow-abc"):
    with traced(
        "contract-analysis",
        metadata=build_metadata(
            purpose="analysis",
            org_id="org-1",
            contract_id="contract-123",
        ),
    ) as t:
        result = analyze(contract)
        t.set_output(result)
```

## Viewing in Langfuse UI

- **Sessions tab**: Groups all traces with the same session_id
- **Users tab**: Shows per-user trace history and metrics
- **Filters**: Filter traces by user_id or session_id in the trace list

## Best Practices

1. Use consistent user IDs across your application (e.g., always email or always UUID)
2. Keep session IDs under 200 characters (Langfuse limit)
3. Use `session_context()` at the request/handler level so all downstream calls inherit it
4. For chatbots, use the conversation ID as the session ID
5. For background jobs, use the job/task ID
