# Getting Started with AviаraEye

## Installation

```bash
# Core package
pip install aviaraeye

# With OpenAI support
pip install aviaraeye[openai]

# With Azure OpenAI support
pip install aviaraeye[azure]

# With Google Gemini support
pip install aviaraeye[gemini]

# All providers
pip install aviaraeye[all]

# Using uv
uv pip install aviaraeye[all]
```

## Configuration

AviаraEye reads Langfuse credentials from environment variables:

```bash
export LANGFUSE_PUBLIC_KEY="pk-lf-..."
export LANGFUSE_SECRET_KEY="sk-lf-..."
export LANGFUSE_HOST="https://aviaraeye.aviaralabs.com"  # or https://cloud.langfuse.com
```

## Quick Start

### 1. Initialize

```python
from aviaraeye import AviaraEye

# Auto-reads env vars
eye = AviaraEye()

# Verify connection
eye.auth_check()
```

### 2. Trace Your First LLM Call

```python
from aviaraeye import traced
from aviaraeye.providers.openai import OpenAI

client = OpenAI()

with traced("my-first-trace", user_id="user-1", tags=["demo"]) as t:
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello!"}],
    )
    t.set_output(response.choices[0].message.content)
    t.score("quality", 1.0)
```

### 3. Use Decorators

```python
from aviaraeye import observe

@observe
def process_document(doc_bytes: bytes) -> dict:
    # All work inside is auto-traced
    extracted = extract_data(doc_bytes)
    return extracted
```

### 4. Shutdown

```python
# In short-lived scripts, flush before exit
eye.flush()
```

## Next Steps

- [Tracing Guide](tracing.md) — traces, spans, events
- [Providers Guide](providers.md) — OpenAI, Azure, Gemini setup
- [Prompt Management](prompts.md) — versioned prompts
- [Scoring Guide](scoring.md) — evaluation and feedback
- [Sessions Guide](sessions.md) — user and session tracking
