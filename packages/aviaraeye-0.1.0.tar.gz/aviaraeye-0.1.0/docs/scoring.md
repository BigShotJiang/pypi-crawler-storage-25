# Scoring & Evaluation Guide

AviаraEye provides scoring utilities to attach quality metrics, feedback, and evaluation results to traces.

## Score Types

| Type          | Value          | Example                                    |
|--------------|----------------|---------------------------------------------|
| `NUMERIC`    | float          | Accuracy: 0.95, latency: 1.2               |
| `BOOLEAN`    | 0 or 1         | Correct: 1, hallucinated: 0                |
| `CATEGORICAL`| string         | Quality: "good", sentiment: "positive"     |
| `TEXT`       | string (≤500)  | Free-form feedback text                     |

## Inline Scoring (Within a Trace)

```python
from aviaraeye import traced

with traced("evaluation-pipeline") as t:
    result = evaluate_document(doc)

    # Numeric score
    t.score("accuracy", 0.92)

    # Boolean score
    t.score("contains_pii", 0, data_type="BOOLEAN")

    # Categorical score
    t.score("quality_tier", "high", data_type="CATEGORICAL")

    # Text feedback
    t.score("reviewer_notes", "Extraction was complete", data_type="TEXT")
```

## Score by Trace ID

For scoring after-the-fact (e.g., from a review queue):

```python
from aviaraeye import score_trace

# Score a previously completed trace
score_trace("trace-id-123", "human_approval", 1, data_type="BOOLEAN")
score_trace("trace-id-123", "accuracy", 0.88, comment="Minor date error")
```

## Score Specific Observations

```python
from aviaraeye import score_observation

# Score a specific LLM generation within a trace
score_observation(
    trace_id="trace-id-123",
    observation_id="gen-456",
    name="response_quality",
    value=0.9,
)
```

## Common Scoring Patterns

### User Feedback

```python
# After user gives thumbs up/down
score_trace(trace_id, "user_feedback", 1, data_type="BOOLEAN")
```

### Automated Evaluation

```python
from aviaraeye import traced, score_trace

with traced("auto-eval") as t:
    response = llm_call(prompt)
    # Run evaluation
    eval_score = evaluate_response(response, expected)
    t.score("auto_eval", eval_score)
```

### LLM-as-Judge

```python
with traced("llm-judge") as t:
    # Original generation
    output = generate(prompt)

    # Judge the output
    judge_result = judge_llm.evaluate(output)
    t.score("judge_score", judge_result.score)
    t.score("judge_reasoning", judge_result.reasoning, data_type="TEXT")
```
