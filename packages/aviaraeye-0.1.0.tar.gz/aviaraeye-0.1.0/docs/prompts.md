# Prompt Management Guide

AviаraEye wraps Langfuse's prompt management system for versioned, cached prompt retrieval.

## Overview

Langfuse stores prompts centrally with:
- **Versioning**: Each update creates a new version
- **Labels**: Tag versions with labels like `production`, `staging`
- **Caching**: Client-side cache means zero latency after first fetch
- **Variables**: `{{variable}}` placeholders compiled at runtime

## Fetching Prompts

```python
from aviaraeye import get_prompt

# Fetch latest version
prompt = get_prompt("contract-extraction")

# Fetch specific label
prompt = get_prompt("contract-extraction", label="production")

# Fetch specific version
prompt = get_prompt("contract-extraction", version=3)
```

## Compiling Prompts

Prompts use `{{variable}}` syntax for placeholders:

```python
prompt = get_prompt("extraction-prompt")

# Compile with variables
compiled = prompt.compile(
    schema=json_schema_string,
    today="05/05/2026",
    org_name="Acme Corp",
)

# Get as text (for completion APIs)
text = compiled.to_text()

# Get as messages (for chat APIs)
messages = compiled.to_messages()
```

## Using with LLM Calls

```python
from aviaraeye import get_prompt, traced
from aviaraeye.providers.openai import OpenAI

client = OpenAI()
prompt = get_prompt("analysis-prompt", label="production")
compiled = prompt.compile(document=doc_text)

with traced("analysis") as t:
    response = client.chat.completions.create(
        model="gpt-4",
        messages=compiled.to_messages(),
    )
    # Link the prompt version to the trace for tracking
    t.link_prompt(prompt.raw)
    t.set_output(response.choices[0].message.content)
```

## Prompt Properties

```python
prompt = get_prompt("my-prompt")

prompt.name       # "my-prompt"
prompt.version    # 3
prompt.labels     # ["production", "v3"]
prompt.raw        # Underlying Langfuse prompt object
```

## Error Handling

```python
from aviaraeye import get_prompt
from aviaraeye.exceptions import AviaraEyePromptError

try:
    prompt = get_prompt("nonexistent-prompt")
except AviaraEyePromptError as e:
    print(f"Prompt error: {e}")
```

## Cache Behavior

- Prompts are cached client-side by the Langfuse SDK
- First call fetches from server; subsequent calls use cache
- Cache refreshes automatically based on TTL
- Override TTL per-prompt: `get_prompt("name", cache_ttl_seconds=300)`
