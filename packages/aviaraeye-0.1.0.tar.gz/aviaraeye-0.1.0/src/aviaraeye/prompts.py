"""Prompt management for AviаraEye.

Wraps Langfuse prompt versioning, fetching, and compilation.
"""

from __future__ import annotations

import logging
from typing import Any

from aviaraeye.exceptions import AviaraEyePromptError

logger = logging.getLogger(__name__)


class Prompt:
    """Wrapper around a Langfuse prompt with compilation helpers.

    Usage::

        from aviaraeye import get_prompt

        prompt = get_prompt("contract-extraction", label="production")
        compiled = prompt.compile(schema=my_schema, today="05/05/2026")
        messages = compiled.to_messages()  # For chat prompts
        text = compiled.to_text()          # For text prompts
    """

    def __init__(self, langfuse_prompt: Any) -> None:
        self._prompt = langfuse_prompt

    @property
    def name(self) -> str:
        """Prompt name."""
        return self._prompt.name

    @property
    def version(self) -> int:
        """Prompt version number."""
        return self._prompt.version

    @property
    def labels(self) -> list[str]:
        """Labels assigned to this prompt version."""
        return getattr(self._prompt, "labels", [])

    @property
    def raw(self) -> Any:
        """Access the underlying Langfuse prompt object (for link_prompt)."""
        return self._prompt

    def compile(self, **variables: Any) -> "CompiledPrompt":
        """Compile the prompt by substituting {{variables}}.

        Args:
            **variables: Key-value pairs to substitute in the prompt template.

        Returns:
            CompiledPrompt with to_text() and to_messages() methods.
        """
        try:
            compiled = self._prompt.compile(**variables)
            return CompiledPrompt(compiled, self._prompt)
        except Exception as e:
            raise AviaraEyePromptError(
                f"Failed to compile prompt '{self.name}': {e}"
            ) from e


class CompiledPrompt:
    """A compiled prompt ready for use in an LLM call."""

    def __init__(self, compiled: Any, source_prompt: Any) -> None:
        self._compiled = compiled
        self._source = source_prompt

    def to_text(self) -> str:
        """Get compiled prompt as a single text string.

        Works for text-type prompts.
        """
        if isinstance(self._compiled, str):
            return self._compiled
        # For chat prompts, join messages
        if isinstance(self._compiled, list):
            return "\n\n".join(
                msg.get("content", "") if isinstance(msg, dict) else str(msg)
                for msg in self._compiled
            )
        return str(self._compiled)

    def to_messages(self) -> list[dict[str, str]]:
        """Get compiled prompt as a list of chat messages.

        Returns list of dicts with 'role' and 'content' keys.
        Works for chat-type prompts.
        """
        if isinstance(self._compiled, list):
            return self._compiled
        # Wrap text prompt as a single user message
        return [{"role": "user", "content": str(self._compiled)}]

    @property
    def source(self) -> Any:
        """The source Langfuse prompt object (for linking to traces)."""
        return self._source


def get_prompt(
    name: str,
    *,
    version: int | None = None,
    label: str | None = None,
    cache_ttl_seconds: int | None = None,
) -> Prompt:
    """Fetch a prompt from Langfuse by name.

    Prompts are cached client-side by the Langfuse SDK, so repeated calls
    have zero latency after the first fetch.

    Args:
        name: The prompt name as defined in Langfuse.
        version: Specific version number to fetch. Mutually exclusive with label.
        label: Label to fetch (e.g., "production", "staging").
        cache_ttl_seconds: Override the cache TTL for this prompt.

    Returns:
        A Prompt object with compile() method.

    Raises:
        AviaraEyePromptError: If the prompt cannot be fetched.

    Usage::

        prompt = get_prompt("extraction-v2", label="production")
        compiled = prompt.compile(schema=json_schema)
    """
    from aviaraeye.client import get_langfuse

    langfuse = get_langfuse()
    if langfuse is None:
        raise AviaraEyePromptError(
            f"Cannot fetch prompt '{name}': Langfuse is not available"
        )

    try:
        kwargs: dict[str, Any] = {"name": name}
        if version is not None:
            kwargs["version"] = version
        if label is not None:
            kwargs["label"] = label
        if cache_ttl_seconds is not None:
            kwargs["cache_ttl_seconds"] = cache_ttl_seconds

        lf_prompt = langfuse.get_prompt(**kwargs)
        return Prompt(lf_prompt)
    except Exception as e:
        raise AviaraEyePromptError(
            f"Failed to fetch prompt '{name}': {e}"
        ) from e
