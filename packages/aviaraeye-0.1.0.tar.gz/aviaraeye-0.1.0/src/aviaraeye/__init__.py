"""AviаraEye — Ergonomic LLM observability wrapper around Langfuse.

Provides tracing, prompt management, scoring, and auto-instrumentation
for OpenAI, Azure OpenAI, and Google Gemini.

Quickstart::

    from aviaraeye import AviaraEye, traced, observe

    # Initialize (reads LANGFUSE_* env vars)
    eye = AviaraEye()

    # Trace a block of work
    with traced("my-pipeline", user_id="u1", tags=["extraction"]) as t:
        result = do_work()
        t.set_output(result)
        t.score("quality", 0.95)

    # Or use decorators
    @observe
    def my_function(data):
        return process(data)
"""

from __future__ import annotations

__version__ = "0.1.0"

# --- Client ---
from aviaraeye.client import AviaraEye, get_client, get_langfuse

# --- Tracing ---
from aviaraeye.tracing import ObservationHandle, event, span, traced

# --- Decorators ---
from aviaraeye.decorators import generation, observe

# --- Metadata ---
from aviaraeye.metadata import Metadata, Tags, build_metadata, build_tags

# --- Sessions ---
from aviaraeye.sessions import session_context, user_context

# --- Scoring ---
from aviaraeye.scoring import score_observation, score_trace

# --- Prompts ---
from aviaraeye.prompts import CompiledPrompt, Prompt, get_prompt

# --- Exceptions ---
from aviaraeye.exceptions import (
    AviaraEyeAuthError,
    AviaraEyeError,
    AviaraEyeNotInitializedError,
    AviaraEyePromptError,
    AviaraEyeProviderError,
)

# --- Types ---
from aviaraeye.types import MetadataDict, ObservationType, Provider, ScoreDataType, TagList

__all__ = [
    # Client
    "AviaraEye",
    "get_client",
    "get_langfuse",
    # Tracing
    "traced",
    "span",
    "event",
    "ObservationHandle",
    # Decorators
    "observe",
    "generation",
    # Metadata
    "Metadata",
    "Tags",
    "build_metadata",
    "build_tags",
    # Sessions
    "session_context",
    "user_context",
    # Scoring
    "score_trace",
    "score_observation",
    # Prompts
    "get_prompt",
    "Prompt",
    "CompiledPrompt",
    # Exceptions
    "AviaraEyeError",
    "AviaraEyeAuthError",
    "AviaraEyeNotInitializedError",
    "AviaraEyePromptError",
    "AviaraEyeProviderError",
    # Types
    "ObservationType",
    "ScoreDataType",
    "Provider",
    "MetadataDict",
    "TagList",
]
