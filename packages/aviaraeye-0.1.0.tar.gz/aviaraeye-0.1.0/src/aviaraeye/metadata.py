"""Metadata and tag builders for standardised trace annotation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from aviaraeye.types import MetadataDict, TagList


@dataclass
class Metadata:
    """Structured metadata for traces and spans.

    Usage::

        meta = Metadata(
            purpose="contract_extraction",
            org_id="org-1",
            user_id="user-1",
            custom={"contract_id": "c-123"},
        )
        meta_dict = meta.to_dict()
    """

    purpose: str
    org_id: str | int | None = None
    user_id: str | int | None = None
    user_email: str | None = None
    contract_id: str | None = None
    invoice_id: str | None = None
    po_id: str | None = None
    run_id: str | None = None
    agent_name: str | None = None
    custom: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> MetadataDict:
        """Convert to a flat metadata dictionary for Langfuse."""
        meta: MetadataDict = {"purpose": self.purpose}
        if self.org_id is not None:
            meta["org_id"] = str(self.org_id)
        if self.user_id is not None:
            meta["user_id"] = str(self.user_id)
        if self.user_email:
            meta["user_email"] = self.user_email
        if self.contract_id:
            meta["contract_id"] = str(self.contract_id)
        if self.invoice_id:
            meta["invoice_id"] = str(self.invoice_id)
        if self.po_id:
            meta["po_id"] = str(self.po_id)
        if self.run_id:
            meta["run_id"] = self.run_id
        if self.agent_name:
            meta["agent_name"] = self.agent_name
        if self.custom:
            meta.update(self.custom)
        return meta


@dataclass
class Tags:
    """Structured tag builder for Langfuse traces.

    Usage::

        tags = Tags("extraction", org_id="org-1", extra=["priority:high"])
        tag_list = tags.to_list()
    """

    purpose: str
    org_id: str | int | None = None
    extra: list[str] = field(default_factory=list)

    def to_list(self) -> TagList:
        """Convert to a tag list for Langfuse."""
        tags: TagList = [self.purpose]
        if self.org_id is not None:
            tags.append(f"org:{self.org_id}")
        if self.extra:
            tags.extend(self.extra)
        return tags


# --- Functional API (mirrors existing aviara_connect patterns) ---


def build_metadata(
    *,
    purpose: str,
    org_id: str | int | None = None,
    user_id: str | int | None = None,
    user_email: str | None = None,
    contract_id: str | None = None,
    invoice_id: str | None = None,
    po_id: str | None = None,
    run_id: str | None = None,
    agent_name: str | None = None,
    extra: dict[str, Any] | None = None,
) -> MetadataDict:
    """Build a standardised metadata dict for Langfuse traces/spans.

    Functional alternative to the Metadata dataclass.
    """
    return Metadata(
        purpose=purpose,
        org_id=org_id,
        user_id=user_id,
        user_email=user_email,
        contract_id=contract_id,
        invoice_id=invoice_id,
        po_id=po_id,
        run_id=run_id,
        agent_name=agent_name,
        custom=extra or {},
    ).to_dict()


def build_tags(
    purpose: str,
    org_id: str | int | None = None,
    extra: list[str] | None = None,
) -> TagList:
    """Build a consistent tag list for Langfuse traces.

    Functional alternative to the Tags dataclass.
    """
    return Tags(purpose=purpose, org_id=org_id, extra=extra or []).to_list()
