"""AviаraEye client — wraps Langfuse initialization and provides a singleton."""

from __future__ import annotations

import logging
import os
from typing import Any

from langfuse import Langfuse

from aviaraeye.exceptions import AviaraEyeAuthError, AviaraEyeNotInitializedError

logger = logging.getLogger(__name__)

_instance: AviaraEye | None = None


class AviaraEye:
    """Main entry point for AviаraEye observability.

    Wraps the Langfuse client and provides a singleton pattern so all modules
    share the same connection.

    Usage::

        from aviaraeye import AviaraEye

        # Reads LANGFUSE_PUBLIC_KEY, LANGFUSE_SECRET_KEY, LANGFUSE_HOST from env
        eye = AviaraEye()

        # Or explicit config
        eye = AviaraEye(
            public_key="pk-lf-...",
            secret_key="sk-lf-...",
            host="https://aviaraeye.aviaralabs.com",
        )
    """

    def __init__(
        self,
        *,
        public_key: str | None = None,
        secret_key: str | None = None,
        host: str | None = None,
        enabled: bool = True,
        auto_instrument_gemini: bool = True,
        **kwargs: Any,
    ) -> None:
        global _instance

        self._enabled = enabled
        self._langfuse: Langfuse | None = None
        self._gemini_instrumented = False

        if not enabled:
            logger.info("AviaraEye disabled — tracing will be no-op")
            _instance = self
            return

        self._langfuse = Langfuse(
            public_key=public_key or os.getenv("LANGFUSE_PUBLIC_KEY"),
            secret_key=secret_key or os.getenv("LANGFUSE_SECRET_KEY"),
            host=host or os.getenv("LANGFUSE_HOST"),
            **kwargs,
        )

        if auto_instrument_gemini:
            self._instrument_gemini()

        _instance = self
        logger.info("AviaraEye initialized successfully")

    @classmethod
    def init(
        cls,
        *,
        public_key: str | None = None,
        secret_key: str | None = None,
        host: str | None = None,
        enabled: bool = True,
        auto_instrument_gemini: bool = True,
        **kwargs: Any,
    ) -> "AviaraEye":
        """Alternative constructor — same as AviaraEye(...)."""
        return cls(
            public_key=public_key,
            secret_key=secret_key,
            host=host,
            enabled=enabled,
            auto_instrument_gemini=auto_instrument_gemini,
            **kwargs,
        )

    @property
    def enabled(self) -> bool:
        """Whether tracing is enabled."""
        return self._enabled

    @property
    def langfuse(self) -> Langfuse:
        """Access the underlying Langfuse client."""
        if self._langfuse is None:
            raise AviaraEyeNotInitializedError()
        return self._langfuse

    def auth_check(self) -> bool:
        """Verify the Langfuse connection is working.

        Raises AviaraEyeAuthError if authentication fails.
        """
        if not self._enabled:
            return True
        try:
            self.langfuse.auth_check()
            logger.info("AviaraEye auth check passed")
            return True
        except Exception as e:
            raise AviaraEyeAuthError(f"Langfuse auth failed: {e}") from e

    def flush(self) -> None:
        """Flush all pending events to Langfuse.

        Call this before application shutdown in short-lived processes.
        """
        if self._langfuse:
            self._langfuse.flush()

    def shutdown(self) -> None:
        """Flush and release resources."""
        self.flush()
        if self._langfuse:
            self._langfuse.shutdown()
            logger.info("AviaraEye shut down")

    def _instrument_gemini(self) -> None:
        """Auto-instrument Google GenAI SDK if available."""
        if self._gemini_instrumented:
            return
        try:
            from openinference.instrumentation.google_genai import GoogleGenAIInstrumentor

            GoogleGenAIInstrumentor().instrument()
            self._gemini_instrumented = True
            logger.info("GoogleGenAIInstrumentor activated by AviaraEye")
        except ImportError:
            logger.debug(
                "openinference-instrumentation-google-genai not installed — "
                "Gemini auto-instrumentation skipped"
            )
        except Exception as e:
            logger.warning("Gemini instrumentor setup failed: %s", e)


def get_client() -> AviaraEye:
    """Get the global AviaraEye instance.

    If not yet initialized, creates one using environment variables.
    """
    global _instance
    if _instance is None:
        _instance = AviaraEye()
    return _instance


def get_langfuse() -> Langfuse | None:
    """Get the underlying Langfuse client, or None if disabled."""
    client = get_client()
    if not client.enabled:
        return None
    return client._langfuse
