"""Core tracing primitives — context managers for traces, spans, and events."""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Generator

from aviaraeye.types import MetadataDict, ScoreDataType, TagList

logger = logging.getLogger(__name__)


class ObservationHandle:
    """Wrapper around a Langfuse observation, providing a clean API for scoring and output."""

    def __init__(self, observation: Any, langfuse_client: Any = None) -> None:
        self._observation = observation
        self._langfuse = langfuse_client

    @property
    def trace_id(self) -> str | None:
        """Get the trace ID for this observation."""
        if self._observation and hasattr(self._observation, "trace_id"):
            return self._observation.trace_id
        return None

    @property
    def observation_id(self) -> str | None:
        """Get the observation ID."""
        if self._observation and hasattr(self._observation, "id"):
            return self._observation.id
        return None

    def set_output(self, output: Any) -> None:
        """Set the output of this observation."""
        if self._observation and hasattr(self._observation, "update"):
            self._observation.update(output=output)

    def set_metadata(self, metadata: MetadataDict) -> None:
        """Update metadata on this observation."""
        if self._observation and hasattr(self._observation, "update"):
            self._observation.update(metadata=metadata)

    def score(
        self,
        name: str,
        value: float | int | str,
        *,
        data_type: ScoreDataType = "NUMERIC",
        comment: str | None = None,
    ) -> None:
        """Add a score to this observation's trace.

        Args:
            name: Score name (e.g., "accuracy", "quality").
            value: Score value. Numeric for NUMERIC, 0/1 for BOOLEAN, string for CATEGORICAL/TEXT.
            data_type: One of NUMERIC, BOOLEAN, CATEGORICAL, TEXT.
            comment: Optional comment (max 500 chars).
        """
        if not self._langfuse:
            return
        try:
            kwargs: dict[str, Any] = {
                "name": name,
                "value": value,
                "data_type": data_type,
            }
            if self.trace_id:
                kwargs["trace_id"] = self.trace_id
            if self.observation_id:
                kwargs["observation_id"] = self.observation_id
            if comment:
                kwargs["comment"] = comment
            self._langfuse.create_score(**kwargs)
        except Exception as e:
            logger.warning("Failed to create score '%s': %s", name, e)

    def link_prompt(self, prompt: Any) -> None:
        """Link a Langfuse prompt object to this observation."""
        if self._observation and hasattr(self._observation, "update"):
            self._observation.update(prompt=prompt)


@contextmanager
def traced(
    name: str,
    *,
    user_id: str | None = None,
    session_id: str | None = None,
    tags: TagList | None = None,
    metadata: MetadataDict | None = None,
    org_id: str | int | None = None,
) -> Generator[ObservationHandle, None, None]:
    """Create a traced observation that parents all nested LLM calls.

    This is the primary context manager for AviаraEye tracing. All auto-instrumented
    calls (OpenAI, Gemini) made within this block will be nested under this trace.

    Usage::

        from aviaraeye import traced

        with traced("contract-extraction", user_id="u1", tags=["extraction"]) as t:
            result = llm.call(...)
            t.set_output(result)
            t.score("quality", 0.95)

    Falls back to a no-op if Langfuse is unavailable.
    """
    from aviaraeye.client import get_langfuse

    _meta = metadata or {}
    _tags = tags or [name]

    # Resolve effective user: explicit user_id > org_id fallback
    _user = str(user_id) if user_id is not None else (
        str(org_id) if org_id is not None else None
    )

    langfuse = get_langfuse()
    if langfuse is None:
        yield ObservationHandle(None)
        return

    try:
        from langfuse import propagate_attributes

        with langfuse.start_as_current_observation(
            as_type="span",
            name=name,
            metadata=_meta,
        ) as observation:
            with propagate_attributes(
                trace_name=name,
                user_id=_user,
                session_id=session_id,
                tags=_tags,
                metadata=_meta,
            ):
                yield ObservationHandle(observation, langfuse)
    except Exception as e:
        logger.warning("AviaraEye traced() failed, falling back to no-op: %s", e)
        yield ObservationHandle(None)


@contextmanager
def span(
    name: str,
    *,
    metadata: MetadataDict | None = None,
) -> Generator[ObservationHandle, None, None]:
    """Create a nested span within an existing trace.

    Use inside a `traced()` block to create sub-spans for non-LLM operations.

    Usage::

        with traced("pipeline") as t:
            with span("pdf-parsing", metadata={"pages": 5}) as s:
                result = parse_pdf(data)
                s.set_output(result)
    """
    from aviaraeye.client import get_langfuse

    langfuse = get_langfuse()
    if langfuse is None:
        yield ObservationHandle(None)
        return

    try:
        with langfuse.start_as_current_observation(
            as_type="span",
            name=name,
            metadata=metadata or {},
        ) as observation:
            yield ObservationHandle(observation, langfuse)
    except Exception as e:
        logger.warning("AviaraEye span() failed: %s", e)
        yield ObservationHandle(None)


def event(
    name: str,
    *,
    metadata: MetadataDict | None = None,
    output: Any = None,
) -> None:
    """Log a point-in-time event within the current trace.

    Events have no duration — they mark something that happened.

    Usage::

        with traced("pipeline"):
            event("validation-passed", metadata={"checks": 12})
    """
    from aviaraeye.client import get_langfuse

    langfuse = get_langfuse()
    if langfuse is None:
        return

    try:
        with langfuse.start_as_current_observation(
            as_type="event",
            name=name,
            metadata=metadata or {},
        ) as obs:
            if output is not None and hasattr(obs, "update"):
                obs.update(output=output)
    except Exception as e:
        logger.warning("AviaraEye event() failed: %s", e)
