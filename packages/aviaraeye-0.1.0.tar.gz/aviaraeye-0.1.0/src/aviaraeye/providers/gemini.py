"""Google Gemini integration with automatic Langfuse tracing.

Uses the OpenInference GoogleGenAIInstrumentor to auto-capture all
google.genai SDK calls.

Usage::

    from aviaraeye.providers.gemini import instrument_gemini

    # Call once at app startup
    instrument_gemini()

    # Then use google.genai normally — all calls are auto-traced
    from google import genai
    client = genai.Client(api_key="...")
    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents="Extract data from this document",
    )
"""

from __future__ import annotations

import logging

from aviaraeye.exceptions import AviaraEyeProviderError

logger = logging.getLogger(__name__)

_instrumented = False


def instrument_gemini(*, force: bool = False) -> bool:
    """Instrument the Google GenAI SDK for automatic Langfuse tracing.

    This function is idempotent — calling it multiple times is safe.
    The AviaraEye client calls this automatically on initialization
    if `auto_instrument_gemini=True` (the default).

    Args:
        force: Re-instrument even if already done (useful for testing).

    Returns:
        True if instrumentation succeeded, False if skipped (already done).

    Raises:
        AviaraEyeProviderError: If the required package is not installed.
    """
    global _instrumented

    if _instrumented and not force:
        logger.debug("Gemini already instrumented — skipping")
        return False

    try:
        from openinference.instrumentation.google_genai import GoogleGenAIInstrumentor
    except ImportError as e:
        raise AviaraEyeProviderError(
            "gemini",
            "Missing dependency. Install with: pip install 'aviaraeye[gemini]'",
        ) from e

    try:
        GoogleGenAIInstrumentor().instrument()
        _instrumented = True
        logger.info("GoogleGenAIInstrumentor activated")
        return True
    except Exception as e:
        raise AviaraEyeProviderError(
            "gemini",
            f"Instrumentation failed: {e}",
        ) from e


def is_instrumented() -> bool:
    """Check if Gemini auto-instrumentation is active."""
    return _instrumented


def is_available() -> bool:
    """Check if the Gemini instrumentation package is installed."""
    try:
        from openinference.instrumentation.google_genai import GoogleGenAIInstrumentor  # noqa: F401

        return True
    except ImportError:
        return False
