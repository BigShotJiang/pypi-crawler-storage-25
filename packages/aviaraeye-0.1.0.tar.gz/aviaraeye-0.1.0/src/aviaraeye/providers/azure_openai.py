"""Azure OpenAI integration with automatic Langfuse tracing.

Usage::

    from aviaraeye.providers.azure_openai import AzureOpenAI, AsyncAzureOpenAI

    client = AzureOpenAI(
        api_key="...",
        api_version="2024-12-01-preview",
        azure_endpoint="https://your-resource.openai.azure.com/",
    )

    # All calls auto-traced via Langfuse
    response = client.chat.completions.create(
        model="gpt-4.1",
        messages=[{"role": "user", "content": "Hello"}],
    )

To add trace metadata::

    from aviaraeye.providers.azure_openai import AzureOpenAI, build_traced_metadata

    response = client.chat.completions.create(
        model="gpt-4.1",
        messages=[...],
        metadata=build_traced_metadata(
            purpose="contract_analysis",
            org_id="org-1",
            user_id="user-1",
        ),
    )
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

try:
    # Langfuse patches both AzureOpenAI and AsyncAzureOpenAI
    from langfuse.openai import (  # noqa: F401
        AsyncAzureOpenAI,
        AzureOpenAI,
    )

    _available = True
except ImportError:
    _available = False
    logger.debug(
        "langfuse.openai not available — install 'aviaraeye[azure]' for Azure OpenAI tracing"
    )

    # Fallback to raw openai Azure classes
    try:
        from openai import AsyncAzureOpenAI, AzureOpenAI  # type: ignore[assignment]  # noqa: F401
    except ImportError:
        pass


# Re-export the metadata builder from openai module (same mechanism)
from aviaraeye.providers.openai import build_traced_metadata  # noqa: F401


def is_available() -> bool:
    """Check if the traced Azure OpenAI integration is available."""
    return _available
