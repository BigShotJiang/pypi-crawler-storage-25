"""LLM provider integrations for AviаraEye.

Provides auto-traced wrappers for OpenAI, Azure OpenAI, and Google Gemini.
"""

from aviaraeye.providers.gemini import instrument_gemini

__all__ = ["instrument_gemini"]
