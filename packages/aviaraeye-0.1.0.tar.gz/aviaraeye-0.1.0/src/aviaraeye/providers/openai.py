"""OpenAI drop-in replacement with automatic Langfuse tracing.

Usage::

    from aviaraeye.providers.openai import openai

    # Use exactly like the normal OpenAI SDK — all calls auto-traced
    response = openai.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
    )

To attach trace-level metadata, pass extra keys via the `metadata` kwarg::

    response = openai.chat.completions.create(
        model="gpt-4",
        messages=[...],
        metadata={
            "langfuse_user_id": "user-123",
            "langfuse_session_id": "session-456",
            "langfuse_tags": ["chat"],
            "purpose": "extraction",
        },
    )
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

try:
    # The langfuse.openai module is a drop-in replacement that auto-instruments
    # all OpenAI API calls with Langfuse tracing.
    from langfuse.openai import openai  # noqa: F401
    from langfuse.openai import (  # noqa: F401
        AsyncOpenAI,
        OpenAI,
    )

    _available = True
except ImportError:
    _available = False
    logger.debug(
        "langfuse.openai not available — install 'aviaraeye[openai]' for OpenAI tracing"
    )

    # Provide fallback imports from raw openai if langfuse wrapper unavailable
    try:
        import openai  # type: ignore[no-redef]  # noqa: F401
        from openai import AsyncOpenAI, OpenAI  # type: ignore[no-redef,assignment]  # noqa: F401
    except ImportError:
        pass


def build_traced_metadata(
    *,
    purpose: str | None = None,
    user_id: str | None = None,
    session_id: str | None = None,
    tags: list[str] | None = None,
    org_id: str | int | None = None,
    **extra: Any,
) -> dict[str, Any]:
    """Build a metadata dict for OpenAI calls with Langfuse trace-level keys.

    This maps AviаraEye conventions to the langfuse_* keys that the
    langfuse.openai wrapper recognizes.

    Usage::

        from aviaraeye.providers.openai import OpenAI, build_traced_metadata

        client = OpenAI()
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[...],
            metadata=build_traced_metadata(
                purpose="compliance_eval",
                user_id="user-1",
                org_id="org-1",
                tags=["compliance"],
            ),
        )
    """
    from aviaraeye.metadata import build_tags

    meta: dict[str, Any] = {}

    if purpose:
        meta["purpose"] = purpose
    if org_id is not None:
        meta["org_id"] = str(org_id)

    # Trace-level: user
    effective_user = str(user_id) if user_id else (
        str(org_id) if org_id is not None else None
    )
    if effective_user:
        meta["langfuse_user_id"] = effective_user

    # Trace-level: session
    if session_id:
        meta["langfuse_session_id"] = session_id

    # Trace-level: tags
    if tags:
        meta["langfuse_tags"] = tags
    elif purpose:
        meta["langfuse_tags"] = build_tags(purpose, org_id)

    # Extra metadata
    meta.update(extra)

    return meta


def is_available() -> bool:
    """Check if the traced OpenAI integration is available."""
    return _available
