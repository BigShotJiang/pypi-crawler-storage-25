"""Scoring and feedback utilities for AviаraEye.

Provides helpers to attach scores to traces and observations.
"""

from __future__ import annotations

import logging
from typing import Any

from aviaraeye.types import ScoreDataType

logger = logging.getLogger(__name__)


def score_trace(
    trace_id: str,
    name: str,
    value: float | int | str,
    *,
    data_type: ScoreDataType = "NUMERIC",
    comment: str | None = None,
) -> None:
    """Score a trace by its ID.

    Usage::

        from aviaraeye import score_trace
        score_trace("tr-123", "accuracy", 0.92)
        score_trace("tr-123", "approved", 1, data_type="BOOLEAN")
        score_trace("tr-123", "category", "good", data_type="CATEGORICAL")
    """
    from aviaraeye.client import get_langfuse

    langfuse = get_langfuse()
    if langfuse is None:
        return

    try:
        kwargs: dict[str, Any] = {
            "name": name,
            "value": value,
            "trace_id": trace_id,
            "data_type": data_type,
        }
        if comment:
            kwargs["comment"] = comment
        langfuse.create_score(**kwargs)
    except Exception as e:
        logger.warning("Failed to score trace '%s': %s", trace_id, e)


def score_observation(
    trace_id: str,
    observation_id: str,
    name: str,
    value: float | int | str,
    *,
    data_type: ScoreDataType = "NUMERIC",
    comment: str | None = None,
) -> None:
    """Score a specific observation within a trace.

    Usage::

        from aviaraeye import score_observation
        score_observation("tr-123", "obs-456", "latency", 1.2)
    """
    from aviaraeye.client import get_langfuse

    langfuse = get_langfuse()
    if langfuse is None:
        return

    try:
        kwargs: dict[str, Any] = {
            "name": name,
            "value": value,
            "trace_id": trace_id,
            "observation_id": observation_id,
            "data_type": data_type,
        }
        if comment:
            kwargs["comment"] = comment
        langfuse.create_score(**kwargs)
    except Exception as e:
        logger.warning("Failed to score observation '%s': %s", observation_id, e)
