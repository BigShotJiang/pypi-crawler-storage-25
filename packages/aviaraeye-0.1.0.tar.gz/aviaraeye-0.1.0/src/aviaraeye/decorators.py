"""Decorator-based tracing for AviаraEye.

Provides @observe for automatic function tracing, capturing inputs/outputs.
"""

from __future__ import annotations

import functools
import logging
from typing import Any, Callable, TypeVar, overload

from aviaraeye.types import ObservationType

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


@overload
def observe(func: F) -> F: ...


@overload
def observe(
    *,
    name: str | None = None,
    as_type: ObservationType = "span",
    capture_input: bool = True,
    capture_output: bool = True,
) -> Callable[[F], F]: ...


def observe(
    func: F | None = None,
    *,
    name: str | None = None,
    as_type: ObservationType = "span",
    capture_input: bool = True,
    capture_output: bool = True,
) -> F | Callable[[F], F]:
    """Decorator to auto-trace a function as a Langfuse observation.

    Can be used with or without arguments::

        @observe
        def my_function(data):
            return process(data)

        @observe(name="custom-name", as_type="generation")
        def call_llm(prompt):
            return llm.call(prompt)

    Args:
        name: Custom observation name. Defaults to the function name.
        as_type: Observation type — "span" (default), "generation", or "event".
        capture_input: Whether to log function arguments as input.
        capture_output: Whether to log the return value as output.
    """

    def decorator(fn: F) -> F:
        try:
            from langfuse.decorators import observe as langfuse_observe

            # Use Langfuse's native @observe with our defaults
            wrapped = langfuse_observe(
                name=name or fn.__name__,
                as_type=as_type,
                capture_input=capture_input,
                capture_output=capture_output,
            )(fn)
            return wrapped  # type: ignore[return-value]
        except ImportError:
            logger.debug("Langfuse decorators not available — @observe is no-op")
            return fn

    if func is not None:
        # Called as @observe without parens
        return decorator(func)

    return decorator


def generation(
    func: F | None = None,
    *,
    name: str | None = None,
    model: str | None = None,
    capture_input: bool = True,
    capture_output: bool = True,
) -> F | Callable[[F], F]:
    """Decorator for LLM generation functions.

    Shorthand for @observe(as_type="generation")::

        @generation(model="gpt-4.1")
        def call_openai(messages):
            return client.chat.completions.create(...)

    Args:
        name: Custom observation name. Defaults to the function name.
        model: Model name to record on the generation.
        capture_input: Whether to log function arguments.
        capture_output: Whether to log the return value.
    """

    def decorator(fn: F) -> F:
        try:
            from langfuse.decorators import observe as langfuse_observe

            @langfuse_observe(
                name=name or fn.__name__,
                as_type="generation",
                capture_input=capture_input,
                capture_output=capture_output,
            )
            @functools.wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                result = fn(*args, **kwargs)
                # If model is specified, try to update the current observation
                if model:
                    try:
                        from langfuse import get_client as lf_get_client

                        client = lf_get_client()
                        # The decorator handles most of this, model is recorded via metadata
                    except Exception:
                        pass
                return result

            return wrapper  # type: ignore[return-value]
        except ImportError:
            logger.debug("Langfuse decorators not available — @generation is no-op")
            if func is not None:
                return func
            return lambda f: f  # type: ignore[return-value]

    if func is not None:
        return decorator(func)

    return decorator
