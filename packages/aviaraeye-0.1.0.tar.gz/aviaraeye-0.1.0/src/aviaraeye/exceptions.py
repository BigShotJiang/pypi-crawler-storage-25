"""AviаraEye custom exceptions."""

from __future__ import annotations


class AviaraEyeError(Exception):
    """Base exception for all AviаraEye errors."""


class AviaraEyeAuthError(AviaraEyeError):
    """Raised when Langfuse authentication fails."""

    def __init__(self, message: str = "Langfuse authentication failed") -> None:
        super().__init__(message)


class AviaraEyeNotInitializedError(AviaraEyeError):
    """Raised when trying to use AviаraEye before initialization."""

    def __init__(self) -> None:
        super().__init__(
            "AviaraEye has not been initialized. "
            "Call AviaraEye() or AviaraEye.init() first."
        )


class AviaraEyePromptError(AviaraEyeError):
    """Raised when prompt fetch or compile fails."""


class AviaraEyeProviderError(AviaraEyeError):
    """Raised when a provider integration fails."""

    def __init__(self, provider: str, message: str) -> None:
        super().__init__(f"[{provider}] {message}")
        self.provider = provider
