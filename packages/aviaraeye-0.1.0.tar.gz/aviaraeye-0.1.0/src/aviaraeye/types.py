"""Shared type definitions for AviаraEye."""

from __future__ import annotations

from enum import Enum
from typing import Any, Literal


# Observation types supported by Langfuse
ObservationType = Literal["span", "generation", "event"]

# Score data types
ScoreDataType = Literal["NUMERIC", "BOOLEAN", "CATEGORICAL", "TEXT"]


class Provider(str, Enum):
    """Supported LLM providers."""

    OPENAI = "openai"
    AZURE_OPENAI = "azure_openai"
    GEMINI = "gemini"


# Type alias for metadata dictionaries
MetadataDict = dict[str, Any]

# Type alias for tag lists
TagList = list[str]
