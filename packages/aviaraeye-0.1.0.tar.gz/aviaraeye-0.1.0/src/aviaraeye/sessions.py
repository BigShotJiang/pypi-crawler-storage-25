"""User and session context propagation for AviаraEye.

Provides utilities to set user_id and session_id on all traces within a block.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Generator

from aviaraeye.types import MetadataDict, TagList

logger = logging.getLogger(__name__)


@contextmanager
def session_context(
    *,
    user_id: str | None = None,
    session_id: str | None = None,
    tags: TagList | None = None,
    metadata: MetadataDict | None = None,
) -> Generator[None, None, None]:
    """Propagate user and session info to all nested observations.

    All traces and spans created within this block will inherit the
    specified user_id, session_id, tags, and metadata.

    Usage::

        from aviaraeye import session_context

        with session_context(user_id="user@example.com", session_id="chat-789"):
            # All LLM calls here share the same user/session
            response1 = call_llm(msg1)
            response2 = call_llm(msg2)
    """
    try:
        from langfuse import propagate_attributes

        with propagate_attributes(
            user_id=user_id,
            session_id=session_id,
            tags=tags,
            metadata=metadata,
        ):
            yield
    except ImportError:
        logger.debug("Langfuse not available — session_context is no-op")
        yield
    except Exception as e:
        logger.warning("session_context failed: %s", e)
        yield


@contextmanager
def user_context(user_id: str) -> Generator[None, None, None]:
    """Convenience: propagate only user_id to all nested observations.

    Usage::

        with user_context("user-123"):
            do_work()
    """
    with session_context(user_id=user_id):
        yield
