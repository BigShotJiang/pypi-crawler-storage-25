import sys
import unittest
from unittest.mock import MagicMock, patch
from datetime import datetime
from mongograph_helper import MongoGraphHelper, MongoGraphConfig

class TestMongoGraphMultiTenant(unittest.TestCase):
    def setUp(self):
        self.config = MongoGraphConfig(database="test_db")
        self.helper = MongoGraphHelper(self.config)
        self.mock_client = MagicMock()
        self.mock_db = MagicMock()
        self.mock_client.__getitem__.return_value = self.mock_db
        self.helper._client = self.mock_client
        self.helper._db = self.mock_db

    def test_setup_indexes_drops_legacy(self):
        """Verify that _setup_indexes attempts to drop legacy indexes."""
        mock_nodes = MagicMock()
        mock_edges = MagicMock()
        self.mock_db.__getitem__.side_effect = lambda x: mock_nodes if "nodes" in x else mock_edges
        
        self.helper._setup_indexes()
        
        # Verify drops
        mock_nodes.drop_index.assert_any_call("id_1_label_1")
        mock_edges.drop_index.assert_any_call("from_id_1_to_id_1_type_1")
        
        # Verify new multi-tenant indexes
        mock_nodes.create_index.assert_any_call([("id", 1), ("label", 1), ("company_id", 1)], unique=True)
        mock_edges.create_index.assert_any_call([("from_id", 1), ("to_id", 1), ("type", 1), ("company_id", 1)], unique=True)

    def test_merge_node_includes_company_id_in_filter(self):
        """Verify merge_node includes company_id in the filter query."""
        mock_nodes = MagicMock()
        self.mock_db.__getitem__.return_value = mock_nodes
        
        label = "Person"
        properties = {"id": "p1", "name": "Alice", "company_id": "comp-1"}
        
        self.helper.merge_node(label, properties)
        
        args, kwargs = mock_nodes.update_one.call_args
        filter_query = args[0]
        
        self.assertEqual(filter_query["company_id"], "comp-1")
        self.assertEqual(filter_query["id"], "p1")
        self.assertEqual(filter_query["label"], "Person")

    def test_merge_relationship_includes_company_id_in_filter(self):
        """Verify merge_relationship includes company_id in the filter query."""
        mock_edges = MagicMock()
        self.mock_db.__getitem__.return_value = mock_edges
        
        source = {"id": "p1", "company_id": "comp-1"}
        target = {"id": "p2"}
        rel_type = "KNOWS"
        rel_props = {"company_id": "comp-1", "strength": 0.9}
        
        self.helper.merge_relationship("Person", source, "Person", target, rel_type, rel_props)
        
        args, kwargs = mock_edges.update_one.call_args
        filter_query = args[0]
        
        self.assertEqual(filter_query["company_id"], "comp-1")
        self.assertEqual(filter_query["from_id"], "p1")
        self.assertEqual(filter_query["to_id"], "p2")
        self.assertEqual(filter_query["type"], "KNOWS")

    def test_bulk_merge_edges_includes_company_id_in_filter(self):
        """Verify bulk_merge_edges includes company_id in the filter query."""
        mock_edges = MagicMock()
        self.mock_db.__getitem__.return_value = mock_edges
        
        edges = [
            {"from_id": "p1", "to_id": "p2", "type": "KNOWS", "company_id": "comp-1"},
            {"from_id": "p1", "to_id": "p3", "type": "KNOWS", "company_id": "comp-2"}
        ]
        
        # We need to mock UpdateOne to check its arguments
        with patch('mongograph_helper.UpdateOne') as mock_update_one:
            self.helper.bulk_merge_edges(edges)
            
            # Check first call
            call_args = mock_update_one.call_args_list[0][0][0]
            self.assertEqual(call_args["company_id"], "comp-1")
            
            # Check second call
            call_args = mock_update_one.call_args_list[1][0][0]
            self.assertEqual(call_args["company_id"], "comp-2")

if __name__ == '__main__':
    unittest.main()
