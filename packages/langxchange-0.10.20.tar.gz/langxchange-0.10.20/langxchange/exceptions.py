class LangXchangeError(Exception):
    """Base exception for all langxchange errors."""
    pass

class InsufficientQuotaError(LangXchangeError):
    """Raised when the LLM provider API quota has been exceeded (e.g., 429 quota/credit exceeded)."""
    def __init__(self, message="API quota exceeded. Please check your billing or usage limit."):
        self.message = message
        super().__init__(self.message)
