"""Tests for scripts/paddy_format.py — lisp-style closing-bracket formatter.

The formatter takes Python source where closing brackets dangle on their own
line (Black/ruff style) and rewrites them to stack on the previous line
(lisp style). It's idempotent: running twice produces the same output.
"""

from __future__ import annotations

import sys
import textwrap
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from paddy_format import paddy_format  # noqa: E402


def dedent(s: str) -> str:
    return textwrap.dedent(s).lstrip("\n")


@pytest.mark.parametrize("name,src,expected", [("call_with_trailing_comma", """
            func(
                a,
                b,
            )
            """, """
            func(a, b)
            """), ("call_no_trailing_comma", """
            func(
                a,
                b
            )
            """, """
            func(
                a,
                b)
            """), ("list_literal", """
            xs = [
                1,
                2,
                3,
            ]
            """, """
            xs = [1, 2, 3]
            """), ("dict_literal", """
            d = {
                'a': 1,
                'b': 2,
            }
            """, """
            d = {'a': 1, 'b': 2}
            """), ("tuple_with_parens", """
            t = (
                1,
                2,
                3,
            )
            """, """
            t = (1, 2, 3)
            """), ("set_literal", """
            s = {
                1,
                2,
                3,
            }
            """, """
            s = {1, 2, 3}
            """), ("nested_list_in_call", """
            func(
                [
                    1,
                    2,
                ],
            )
            """, """
            func([1, 2])
            """), ("function_def", """
            def f(
                a,
                b,
                c,
            ):
                return a
            """, """
            def f(a, b, c):
                return a
            """), ("from_import", """
            from x import (
                foo,
                bar,
            )
            """, """
            from x import (foo, bar)
            """), (
            "long_call_greedy_wrap",
            # 203 chars on one line — should wrap greedily at 120,
            # continuation indented at line_indent + 4 (here, 0 + 4 = 4).
            """
            result = some_function_name(very_long_argument_1, very_long_argument_2, very_long_argument_3, very_long_argument_4, very_long_argument_5, very_long_argument_6, very_long_argument_7, very_long_argument_8)
            """,
            """
            result = some_function_name(very_long_argument_1, very_long_argument_2, very_long_argument_3, very_long_argument_4,
                very_long_argument_5, very_long_argument_6, very_long_argument_7, very_long_argument_8)
            """), (
            "multiline_collapse_target_too_long_wraps_instead",
            # Trailing-comma multiline; collapsed form would be 203 chars.
            # Don't collapse — wrap greedily instead. Trailing comma is dropped.
            """
            result = some_function_name(
                very_long_argument_1,
                very_long_argument_2,
                very_long_argument_3,
                very_long_argument_4,
                very_long_argument_5,
                very_long_argument_6,
                very_long_argument_7,
                very_long_argument_8,
            )
            """,
            """
            result = some_function_name(very_long_argument_1, very_long_argument_2, very_long_argument_3, very_long_argument_4,
                very_long_argument_5, very_long_argument_6, very_long_argument_7, very_long_argument_8)
            """), (
            "long_list_greedy_wrap",
            # 162 chars on one line — wrap greedily.
            """
            long_xs = [very_long_value_1, very_long_value_2, very_long_value_3, very_long_value_4, very_long_value_5, very_long_value_6, very_long_value_7, very_long_value_8]
            """,
            """
            long_xs = [very_long_value_1, very_long_value_2, very_long_value_3, very_long_value_4, very_long_value_5,
                very_long_value_6, very_long_value_7, very_long_value_8]
            """), (
            "skip_wrap_inside_fstring_for_py311_compat",
            # Real case from buckaroo/file_cache/base.py. paddy wrapped
            # a Call inside an f-string, which is a SyntaxError on
            # Python 3.11 (PEP 701 multi-line f-strings only landed in
            # 3.12). Don't wrap any Call/List/Set/Dict whose ancestor is
            # a FormattedString — leave the f-string's expression on a
            # single line, even when the line is over budget.
            """
            log_msg = f"prefix {len(state.get('aaaaaaaaaaa', []))}, {len(state.get('bbbbbbbbbbbbbbbbbbbb', []))}, {len(state.get('cccccccccccccccccccccc', []))}"
            """,
            """
            log_msg = f"prefix {len(state.get('aaaaaaaaaaa', []))}, {len(state.get('bbbbbbbbbbbbbbbbbbbb', []))}, {len(state.get('cccccccccccccccccccccc', []))}"
            """), (
            "long_funcdef_greedy_wrap",
            # Real case from buckaroo/dataflow/column_executor_dataflow.py
            # compute_summary_with_executor — collapsed form is 400+ chars.
            # Continuation indent for FunctionDef params is line_indent + 8
            # (NOT + 4 like Call/List/Set/Dict) so the args sit visually
            # distinct from the body, which is at line_indent + 4. PEP 8
            # explicitly recommends this for "distinguishing arguments
            # from the rest".
            """
            def compute_summary_with_executor(self, file_cache: Optional[FileCache] = None, progress_listener: Optional[ProgressListener] = None, file_path: MaybeFilepathLike = None, planning_function: Optional["PlanningFunction"] = None, timeout_secs: Optional[float] = None, cached_merged_sd_override: Optional[Dict[str, Dict[str, Any]]] = None) -> None:
                pass
            """,
            """
            def compute_summary_with_executor(self, file_cache: Optional[FileCache] = None,
                    progress_listener: Optional[ProgressListener] = None, file_path: MaybeFilepathLike = None,
                    planning_function: Optional["PlanningFunction"] = None, timeout_secs: Optional[float] = None,
                    cached_merged_sd_override: Optional[Dict[str, Dict[str, Any]]] = None) -> None:
                pass
            """), (
            "reindent_continuation_to_indent_plus_4",
            # Continuation line of a multi-line call sits at column 0 (legal
            # inside parens, but visually broken). Re-indent it to
            # original_indent + 4. Trailing space after the comma on line 1
            # is also cleaned up — kept as `\n` in this fixture so the
            # trailing space survives editor whitespace-stripping.
            (
                "class C:\n"
                "    def f(self, ser):\n"
                "        return dict(str_bool_frac=str_bool_frac(ser), \n"
                "regular_int_parse_frac=regular_int_parse_frac(ser))\n"
            ),
            (
                "class C:\n"
                "    def f(self, ser):\n"
                "        return dict(str_bool_frac=str_bool_frac(ser),\n"
                "            regular_int_parse_frac=regular_int_parse_frac(ser))\n"
            )), (
            "reindent_skipped_when_group_has_blank_line_subgroups",
            # Real case from buckaroo/customizations/pandas_commands.py
            # AGG_METHODS_WITH_HELP. The list groups its tuples into
            # visual subgroups separated by blank lines. Today the
            # re-indent pass half-applies: `_reindent_pw` skips any
            # whitespace with `empty_lines`, so elements right after a
            # blank line stay at col 0 (the user's chosen indent), but
            # elements with a plain `,\n` before them get bumped to
            # line_indent + 4. The result is mixed indentation. When
            # the user has used blank lines to structure the group,
            # leave the WHOLE group's continuation alone.
            """
            data = [
            ('a', 1),
            ('b', 2),

            ('c', 3),
            ('d', 4)]
            """,
            """
            data = [
            ('a', 1),
            ('b', 2),

            ('c', 3),
            ('d', 4)]
            """), (
            "reindent_preserves_hanging_indent_aligned_with_first_element",
            # Real case from buckaroo/customizations/all_transforms.py.
            # The `[` opens with item 1 inline on the same line; items 2-3
            # are aligned with item 1 (one column past the `[`). That's a
            # legitimate hanging-indent style — re-indent must NOT shift it
            # to line_indent+4, which would leave item 1 left of items 2-3.
            """
            class C:
                def transform_to_py(df, col):
                    return chr(10).join(
                        ["old_col = df",
                         "df.drop(col)",
                         "df.index = old_col.values"])
            """,
            """
            class C:
                def transform_to_py(df, col):
                    return chr(10).join(
                        ["old_col = df",
                         "df.drop(col)",
                         "df.index = old_col.values"])
            """), (
            "preserve_dict_with_multiline_values",
            # Real case from buckaroo/.../analysis_management_test.py.
            # Outer dict has trailing comma → collapse rule would fire,
            # but its values are multi-line (each value is itself a
            # dict spanning several lines). Collapsing produces output
            # like `}, 'b': {` where the previous value's close brace
            # collides with the next key on the same line, making the
            # keys hard to spot. Skip collapse when a Dict has 2+ items
            # and any value spans multiple lines.
            """
            assert_dict_eq({
                'a': {
                    'orig_col_name': 'aaa',
                    'len': 4
                },
                'b': {
                    'orig_col_name': 'bbb',
                    'len': 5
                },
            }, sdf)
            """,
            """
            assert_dict_eq({
                'a': {
                    'orig_col_name': 'aaa',
                    'len': 4
                },
                'b': {
                    'orig_col_name': 'bbb',
                    'len': 5
                },
            }, sdf)
            """), (
            "preserve_tabular_dict_hanging_indent",
            # Real case from buckaroo/dataflow/customizable_dataflow_test.py
            # DFVIEWER_CONFIG_DEFAULT. The user opens `{` at end of line
            # then puts every key at a chosen "tabular" column (col 19
            # here) — not line_indent + 4 (canonical) and not aligned
            # with the bracket. Multiple sibling dicts in the file share
            # the same column so they read as comparable tables.
            # Preserve: skip collapse (despite trailing comma), wrap and
            # re-indent.
            """
            CFG = {
                               'pinned_rows': [],
                               'column_config': [],
                               'left_col_configs': [],
                               'component_config': {},
                               'extra_grid_config': {},
            }
            """,
            """
            CFG = {
                               'pinned_rows': [],
                               'column_config': [],
                               'left_col_configs': [],
                               'component_config': {},
                               'extra_grid_config': {},
            }
            """), (
            "wrap_continuation_uses_col_after_open_when_shallow",
            # Real case from buckaroo/dataflow/styling_core.py
            # ThemeColorConfig. The inner Dict's `{` is at col 4 with item 1
            # inline at col 5; the canonical line_indent + 4 = col 8 puts
            # continuations DEEPER than item 1, leaving item 1 visually
            # offset. Use col_after_open_bracket instead, since it's
            # shallower than line_indent + 4. Rule:
            # continuation_col = min(line_indent + 4, col_after_open_bracket)
            # (FunctionDef stays at line_indent + 8 unconditionally.)
            """
            ThemeColorConfig = TypedDict('ThemeColorConfig', {
                'accentColor': NotRequired[str],
                'accentHoverColor': NotRequired[str],
                'backgroundColor': NotRequired[str],
                'foregroundColor': NotRequired[str],
                'oddRowBackgroundColor': NotRequired[str],
                'borderColor': NotRequired[str],
                'headerBorderColor': NotRequired[str],
                'headerBackgroundColor': NotRequired[str],
                'spacing': NotRequired[int],
                'cellHorizontalPaddingScale': NotRequired[float],
                'rowVerticalPaddingScale': NotRequired[float],
            })
            """,
            """
            ThemeColorConfig = TypedDict('ThemeColorConfig',
                {'accentColor': NotRequired[str], 'accentHoverColor': NotRequired[str], 'backgroundColor': NotRequired[str],
                 'foregroundColor': NotRequired[str], 'oddRowBackgroundColor': NotRequired[str], 'borderColor': NotRequired[str],
                 'headerBorderColor': NotRequired[str], 'headerBackgroundColor': NotRequired[str], 'spacing': NotRequired[int],
                 'cellHorizontalPaddingScale': NotRequired[float], 'rowVerticalPaddingScale': NotRequired[float]})
            """), (
            "table_format_single_col_floats",
            # `# table-format` directive on the line above forces a column
            # table layout — each element on its own line, decimal points
            # right-aligned. Other paddy rules (collapse / stack) are
            # overridden when the directive is present.
            """
            # table-format
            data = [1.23, 45.6, 7.89, 100.5]
            """,
            """
            # table-format
            data = [1.23, 45.6, 7.89, 100.5]
            """), (
            "table_format_single_col_floats_wrap",
            # When the single-line form exceeds 120 chars, table-format
            # wraps using strict uniform cells: each cell is
            # max_int_width + 1 + max_frac_width chars wide (left-pad int,
            # right-pad frac). Continuation indent = position right after
            # the open bracket, so decimals align across rows at fixed
            # 8-column strides. Trailing spaces inside cells before commas
            # are accepted as the cost of strict alignment.
            """
            # table-format
            data = [1.23, 45.6, 7.89, 100.5, 1.23, 45.6, 7.89, 100.5, 1.23, 45.6, 7.89, 100.5, 1.23, 45.6, 7.89, 100.5, 1.23, 45.6, 7.89, 100.5, 1.23, 45.6, 7.89, 100.5]
            """,
            """
            # table-format
            data = [  1.23,  45.6 ,   7.89, 100.5 ,   1.23,  45.6 ,   7.89, 100.5 ,   1.23,  45.6 ,   7.89, 100.5 ,   1.23,  45.6 ,
                      7.89, 100.5 ,   1.23,  45.6 ,   7.89, 100.5 ,   1.23,  45.6 ,   7.89, 100.5 ]
            """), (
            "table_format_ints_only_wrap",
            # Int-only column: max_int_width = 5 (for 40000), max_frac = 0,
            # so each cell is 5 chars right-aligned. Sep is ", " (2 chars),
            # decimal-equivalent stride is 7. 24 items = 16 on row 1 + 8 on
            # row 2. The "least significant digit" (rightmost char of each
            # int) lines up across rows at fixed columns.
            """
            # table-format
            data = [10, 200, 3000, 40000, 10, 200, 3000, 40000, 10, 200, 3000, 40000, 10, 200, 3000, 40000, 10, 200, 3000, 40000, 10, 200, 3000, 40000]
            """,
            """
            # table-format
            data = [   10,   200,  3000, 40000,    10,   200,  3000, 40000,    10,   200,  3000, 40000,    10,   200,  3000, 40000,
                       10,   200,  3000, 40000,    10,   200,  3000, 40000]
            """), (
            "table_format_mixed_ints_floats_wrap",
            # Mixed ints and floats long enough to wrap: max_int_width = 2
            # (for 30), max_frac_width = 3 (for 4.567). Cell width = 6.
            # Ints sitting in a column with floats get trailing padding to
            # fill the cell (so "1" renders as " 1    " — 1 leading +
            # "1" + 4 trailing for the missing ".XXX"). Decimal column
            # is at offset 2 within each cell, lined up across rows at
            # an 8-char stride.
            """
            # table-format
            data = [1, 2.5, 30, 4.567, 1, 2.5, 30, 4.567, 1, 2.5, 30, 4.567, 1, 2.5, 30, 4.567, 1, 2.5, 30, 4.567, 1, 2.5, 30, 4.567]
            """,
            """
            # table-format
            data = [ 1    ,  2.5  , 30    ,  4.567,  1    ,  2.5  , 30    ,  4.567,  1    ,  2.5  , 30    ,  4.567,  1    ,  2.5  ,
                    30    ,  4.567,  1    ,  2.5  , 30    ,  4.567,  1    ,  2.5  , 30    ,  4.567]
            """), (
            "table_format_mixed_ints_floats",
            # Mixed ints and floats: ints align by least-significant digit
            # (the position the decimal point would occupy). Decimal column
            # = max integer-part width across all items.
            """
            # table-format
            data = [1, 2.5, 30, 4.567, 50000]
            """,
            """
            # table-format
            data = [1, 2.5, 30, 4.567, 50000]
            """), (
            "table_format_multi_col_tuples",
            # Short multi-col list — directive is a no-op when single-line
            # form already fits in budget.
            """
            # table-format
            data = [(1.23, 5), (4.56, 600), (7.89, 70)]
            """,
            """
            # table-format
            data = [(1.23, 5), (4.56, 600), (7.89, 70)]
            """), (
            "table_format_list_of_dicts_wrap",
            # List of dicts that share the same keys and have numeric
            # values. Each key becomes a column; values in that column
            # are decimal-aligned with uniform cell widths so the keys
            # line up across rows.
            #
            # Per-column padding:
            #   'a': max_int=2, max_frac=3, cell width 6
            #   'b': max_int=4, max_frac=0, cell width 4
            #   'c': max_int=2, max_frac=3, cell width 6
            #
            # Per the design discussion: each dict is < 100 chars and
            # has no nested dicts.
            """
            # table-format
            data = [{'a': 1.5, 'b': 100, 'c': 0.001}, {'a': 23.456, 'b': 7, 'c': 99.9}, {'a': 0.5, 'b': 8000, 'c': 1.0}, {'a': 12.34, 'b': 50, 'c': 3.14}, {'a': 7.89, 'b': 1000, 'c': 0.5}]
            """,
            """
            # table-format
            data = [
                {'a':  1.5  , 'b':  100, 'c':  0.001},
                {'a': 23.456, 'b':    7, 'c': 99.9  },
                {'a':  0.5  , 'b': 8000, 'c':  1.0  },
                {'a': 12.34 , 'b':   50, 'c':  3.14 },
                {'a':  7.89 , 'b': 1000, 'c':  0.5  },
            ]
            """), (
            "table_format_multi_col_tuples_wrap",
            # Long multi-col list — single-line form exceeds 120 chars.
            # Each tuple goes on its own line; cells within tuples are
            # aligned across rows. Continuation = line_indent + 4 (the
            # standard paddy rule); cross-row decimal alignment is
            # automatic because every row has the same shape.
            """
            # table-format
            data = [(1.23, 5), (4.56, 600), (7.89, 70), (1.23, 5), (4.56, 600), (7.89, 70), (1.23, 5), (4.56, 600), (7.89, 70), (1.23, 5), (4.56, 600), (7.89, 70)]
            """,
            """
            # table-format
            data = [
                (1.23,   5),
                (4.56, 600),
                (7.89,  70),
                (1.23,   5),
                (4.56, 600),
                (7.89,  70),
                (1.23,   5),
                (4.56, 600),
                (7.89,  70),
                (1.23,   5),
                (4.56, 600),
                (7.89,  70),
            ]
            """), (
            "idempotent_outer_call_continuation_shifts_inner_dict",
            # Minimal repro from buckaroo/pluggable_analysis_framework/
            # safe_summary_df.py. The outer Call's continuation lands at
            # col 8 (line_indent + 4). For the inner Dict, the new
            # continuation rule is min(line_indent + 4, col_after_open):
            # `{` at col 8, col_after_{ = 9, line_indent + 4 = 12, so
            # 9 wins — the inner Dict's continuation aligns with key 1.
            """
            def f(dct):
                cleaned_dct = val_replace(dct,
                                   {pd.NA: UnquotedString("pd.NA"),
                                    np.nan: UnquotedString("np.nan")})
                return cleaned_dct
            """,
            """
            def f(dct):
                cleaned_dct = val_replace(dct,
                    {pd.NA: UnquotedString("pd.NA"),
                     np.nan: UnquotedString("np.nan")})
                return cleaned_dct
            """), (
            "idempotent_nested_list_inside_dict_value",
            # Minimal repro from buckaroo/ddd_library.py. The outer Dict
            # has multi-line values (the 'timedelta' Call spans several
            # lines), so it falls under the user-formatted preservation
            # rule: skip collapse / wrap / re-indent on the outer Dict
            # AND on its Dict/List/Call values. Output equals input.
            """
            def f():
                return pd.DataFrame({
                    'categorical': pd.Categorical(['red', 'green', 'blue', 'red', 'green']),
                    'timedelta': pd.to_timedelta(['1 days 02:03:04', '0 days 00:00:01',
                                                   '365 days', '0 days 00:00:00.001',
                                                   '0 days 00:00:00.000100']),
                    'int_col': [10, 20, 30, 40, 50],
                })
            """,
            """
            def f():
                return pd.DataFrame({
                    'categorical': pd.Categorical(['red', 'green', 'blue', 'red', 'green']),
                    'timedelta': pd.to_timedelta(['1 days 02:03:04', '0 days 00:00:01',
                                                   '365 days', '0 days 00:00:00.001',
                                                   '0 days 00:00:00.000100']),
                    'int_col': [10, 20, 30, 40, 50],
                })
            """), (
            "comment_in_args_blocks_collapse_close_stays_at_col0",
            # A comment in mid-args whitespace blocks the collapse rule.
            # The close bracket sat at col 0 in the source — re-indent
            # must NOT drift it to col 4. Today it does (reindent runs
            # over the last arg's clean comma.whitespace_after even when
            # an earlier arg's comma carries a comment). The PR docstring
            # promises "we never eat a comment"; widening that to "we
            # don't relocate the close when a comment blocked collapse"
            # is the fix.
            """
            func(
                a,  # note
                b,
            )
            """,
            """
            func(
                a,  # note
                b,
            )
            """), (
            "kwonly_only_multiline_collapses",
            # _collapse_funcdef only walks Parameters.params today, so
            # `*, a, b,` (where a/b live in kwonly_params and the `*`
            # marker lives in star_arg) is left untouched. Should
            # collapse to a single line.
            """
            def f(
                *,
                a,
                b,
            ):
                pass
            """,
            """
            def f(*, a, b):
                pass
            """), (
            "kwonly_after_regular_multiline_collapses",
            # Mixed regular + kwonly: today produces a half-collapsed
            # `def f(a, b, *,\n    c,\n):` because only `params.params`
            # gets touched, leaving kwonly_params + their separator on
            # their own lines.
            """
            def f(
                a,
                b,
                *,
                c,
            ):
                pass
            """,
            """
            def f(a, b, *, c):
                pass
            """), (
            "posonly_multiline_collapses",
            # posonly_params (a, b) are in their own field; today they
            # get left multi-line while the regular param `c` collapses
            # next to `/`, producing the bizarre
            # `def f(a,\n    b,\n    /,\n    c):`.
            """
            def f(
                a,
                b,
                /,
                c,
            ):
                pass
            """,
            """
            def f(a, b, /, c):
                pass
            """), (
            "unsplittable_single_arg_overflows",
            # Single arg > 120 chars; nothing to break on, stays as-is.
            """
            result = func(extremely_long_single_argument_that_cannot_be_broken_apart_into_smaller_pieces_and_must_overflow_the_line_budget)
            """,
            """
            result = func(extremely_long_single_argument_that_cannot_be_broken_apart_into_smaller_pieces_and_must_overflow_the_line_budget)
            """), ("single_line_unchanged", """
            func(a, b, c)
            """, """
            func(a, b, c)
            """), ("empty_call_unchanged", """
            func()
            """, """
            func()
            """), ("no_args_multiline_unchanged", """
            func(
            )
            """, """
            func()
            """)])
def test_paddy_format_golden(name, src, expected):
    got = paddy_format(dedent(src))
    assert got == dedent(expected), (
        f"\n--- input ---\n{dedent(src)}"
        f"\n--- expected ---\n{dedent(expected)}"
        f"\n--- got ---\n{got}"
    )
    # Idempotency: a second pass over `got` must be a no-op.
    again = paddy_format(got)
    assert again == got, (
        f"\n--- not idempotent for {name} ---"
        f"\n--- once ---\n{got}"
        f"\n--- twice ---\n{again}"
    )


@pytest.mark.parametrize("name,src,expected", [
        (
            "one_per_line_dict_call_kwargs",
            # Real case from buckaroo/customizations/pd_fracs.py. Collapsed
            # form is 158 chars — over budget. With wrap_mode="one_per_line",
            # each kwarg goes on its own line at line_indent + 4; close
            # bracket stacks on last item.
            """
            class C:
                def f(self, ser):
                    return dict(
                        str_bool_frac=str_bool_frac(ser),
                        regular_int_parse_frac=regular_int_parse_frac(ser),
                        strip_int_parse_frac=strip_int_parse_frac(ser),
                        us_dates_frac=us_dates_frac(ser),
                    )
            """,
            """
            class C:
                def f(self, ser):
                    return dict(
                        str_bool_frac=str_bool_frac(ser),
                        regular_int_parse_frac=regular_int_parse_frac(ser),
                        strip_int_parse_frac=strip_int_parse_frac(ser),
                        us_dates_frac=us_dates_frac(ser))
            """),
        (
            "one_per_line_dict_literal_overlong",
            # Dict literal collapsed exceeds 120 → one item per line.
            """
            frac_name_to_command = {
                "str_bool_frac": "str_bool",
                "regular_int_parse_frac": "regular_int_parse",
                "strip_int_parse_frac": "strip_int_parse",
                "us_dates_frac": "us_date",
            }
            """,
            """
            frac_name_to_command = {
                "str_bool_frac": "str_bool",
                "regular_int_parse_frac": "regular_int_parse",
                "strip_int_parse_frac": "strip_int_parse",
                "us_dates_frac": "us_date"}
            """),
        (
            "one_per_line_funcdef_overlong",
            # Long function signature — each param on its own line at
            # line_indent + 8 in one_per_line mode (FunctionDef-specific
            # so args sit distinct from the body at line_indent + 4).
            """
            def compute_summary_with_executor(self, file_cache=None, progress_listener=None, file_path=None, planning_function=None, timeout_secs=None) -> None:
                pass
            """,
            """
            def compute_summary_with_executor(
                    self,
                    file_cache=None,
                    progress_listener=None,
                    file_path=None,
                    planning_function=None,
                    timeout_secs=None) -> None:
                pass
            """),
        (
            "one_per_line_short_call_collapses_to_single_line",
            # Collapsed form fits in 120 → still single-line, mode is a
            # no-op (parity with greedy mode for short cases).
            """
            result = some_function_name(
                arg1,
                arg2,
                arg3,
            )
            """,
            """
            result = some_function_name(arg1, arg2, arg3)
            """),
    ])
def test_paddy_format_one_per_line(name, src, expected):
    got = paddy_format(dedent(src), wrap_mode="one_per_line")
    assert got == dedent(expected), (
        f"\n--- input ---\n{dedent(src)}"
        f"\n--- expected ---\n{dedent(expected)}"
        f"\n--- got ---\n{got}"
    )
    again = paddy_format(got, wrap_mode="one_per_line")
    assert again == got, (
        f"\n--- not idempotent for {name} ---"
        f"\n--- once ---\n{got}"
        f"\n--- twice ---\n{again}"
    )


def test_idempotent():
    src = dedent(
        """
        result = func(
            arg1,
            arg2,
            [
                1,
                2,
            ],
        )
        """)
    once = paddy_format(src)
    twice = paddy_format(once)
    assert (
        once == twice
    ), f"not idempotent:\n--- once ---\n{once}\n--- twice ---\n{twice}"


def test_preserves_comment_before_close():
    """If a comment sits immediately before the close, leave it alone — don't
    eat the comment by stacking the close."""
    src = dedent(
        """
        func(
            a,
            b,
            # important note
        )
        """)
    got = paddy_format(src)
    assert "# important note" in got


def test_handles_syntax_error_gracefully():
    """Invalid Python should not crash — return input unchanged."""
    src = "this is not python ((("
    assert paddy_format(src) == src


def test_table_format_directive_outside_top_level_is_ignored():
    """The `# table-format` directive only fires for Assign/AnnAssign in
    a module body or IndentedBlock. A directive sitting in front of a
    list inside a function-call argument is intentionally not picked up
    by `_find_directive_lists` — the list goes through the normal wrap
    path. Regression-pin this so future "directive everywhere" changes
    have to update the test deliberately."""
    src = dedent(
        """
        func(
            # table-format
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        )
        """)
    out = paddy_format(src)
    assert "table-format" in out  # directive comment preserved
    # Result is whatever the normal collapse / wrap produces — the key
    # property is that it is NOT the row-per-element table layout.
    assert "],\n" not in out or out.count("\n") <= 4


def test_cli_check_returns_1_when_changes_needed(tmp_path):
    """`paddy_format --check <file>` exits 1 when the file would change,
    and does NOT rewrite the file."""
    from paddy_format import main

    p = tmp_path / "a.py"
    original = "xs = [\n    1,\n    2,\n]\n"
    p.write_text(original)
    rc = main(["--check", str(p)])
    assert rc == 1
    assert p.read_text() == original  # untouched


def test_cli_check_returns_0_when_no_changes_needed(tmp_path):
    from paddy_format import main

    p = tmp_path / "a.py"
    p.write_text("xs = [1, 2]\n")
    rc = main(["--check", str(p)])
    assert rc == 0


def test_cli_rewrites_in_place(tmp_path):
    from paddy_format import main

    p = tmp_path / "a.py"
    p.write_text("xs = [\n    1,\n    2,\n]\n")
    rc = main([str(p)])
    assert rc == 0
    assert p.read_text() == "xs = [1, 2]\n"


def test_cli_multi_file_run(tmp_path):
    """A single CLI invocation handles each file independently."""
    from paddy_format import main

    a = tmp_path / "a.py"
    b = tmp_path / "b.py"
    a.write_text("xs = [\n    1,\n    2,\n]\n")
    b.write_text("ys = (\n    3,\n    4,\n)\n")
    rc = main([str(a), str(b)])
    assert rc == 0
    assert a.read_text() == "xs = [1, 2]\n"
    assert b.read_text() == "ys = (3, 4)\n"


@pytest.mark.slow
@pytest.mark.parametrize("path", sorted((REPO_ROOT / "buckaroo").rglob("*.py")),
    ids=lambda p: str(p.relative_to(REPO_ROOT)))
def test_paddy_format_smoke_on_buckaroo(path):
    """Round-trip every file under `buckaroo/`: format, re-parse, and
    re-format. Catches regressions where paddy produces invalid Python
    or a non-idempotent result on real code. Marked `slow` because
    formatting ~90 files takes ~25s; CI's `-m "not slow"` skips it.
    Run locally with `pytest -m slow tests/unit/test_paddy_format.py`."""
    import ast

    src = path.read_text()
    out = paddy_format(src)
    ast.parse(out)  # output must still be valid Python
    again = paddy_format(out)
    assert again == out, f"non-idempotent: {path}"
