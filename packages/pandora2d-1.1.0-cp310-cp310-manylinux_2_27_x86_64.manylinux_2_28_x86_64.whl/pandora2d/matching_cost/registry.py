#  This file is part of PANDORA2D
#
#      https://github.com/CNES/Pandora2D
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
"""
Registry used for all matching cost methods.
"""

from pandora2d.common import Registry

from .base import BaseMatchingCost
from .pandora import PandoraMatchingCostMethods

MatchingCostRegistry = Registry[BaseMatchingCost](  # pylint: disable=invalid-name # NOSONAR
    default=PandoraMatchingCostMethods
)
