"""
OmniGrid main pipeline: orchestrates the full Just-In-Time parameterisation
and AutoGrid4 run for a single ligand or an entire batch folder.

Parallel processing:
    Use :func:`process_batch_parallel` to spread work across CPU cores.
    Each worker is fully independent — safe for shared filesystems because
    every ligand writes to its own subdirectory under output_dir.
"""

from __future__ import annotations

import logging
import multiprocessing as mp
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Set, Tuple

from .atom_params import get_uff_params
from .gpf_generator import (
    GridConfig,
    auto_grid_box,
    detect_receptor_types,
    generate_gpf,
)
from .ligand_reader import extract_atom_types, extract_charges, list_ligand_files
from .params_writer import UFFAuditLog, write_temp_params
from .runner import AutoDockGPUError, AutoGridError, run_adgpu, run_autogrid

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Pipeline configuration
# ---------------------------------------------------------------------------


@dataclass
class PipelineConfig:
    """All knobs exposed to the user / CLI."""

    # Paths
    receptor_pdbqt: Path  # prepared receptor file
    ligands_dir: Path  # folder with ligand files
    output_dir: Path  # where per-ligand results land
    base_dat: Optional[Path] = None  # standard AD4_parameters.dat

    # Grid
    # When center is None the bounding-box centre is computed automatically.
    center: Optional[Tuple[float, float, float]] = None
    # npts is used only when center is explicitly provided.
    # In auto mode npts is derived from the bounding box + grid_padding.
    npts: Tuple[int, int, int] = (40, 40, 40)
    spacing: float = 0.375
    smooth: float = 0.5
    dielectric: float = -0.1465
    grid_padding: float = 5.0  # Å added to each face in auto mode

    # Transparency / audit
    # Path to the UFF injection audit log. Defaults to output_dir/uff_audit.log
    audit_log_path: Optional[Path] = None

    # Execution
    autogrid_bin: str = "autogrid4"
    timeout: int = 3600
    dry_run: bool = False  # generate files but do not run AutoGrid4
    auto_install: bool = True  # auto-install AutoGrid4 if missing
    stop_on_error: bool = False  # abort batch on first failure
    extensions: Tuple[str, ...] = (".sdf", ".mol2", ".pdb", ".pdbqt")

    # Pre-computed receptor types (set by batch processors to avoid re-parsing per ligand)
    receptor_types: Optional[List[str]] = None

    # Charge computation scheme
    # "auto"   → GFN2-xTB for exotic molecules, Gasteiger for organic (default)
    # "gasteiger" → always use Gasteiger (RDKit)
    # "xtb"    → always use GFN2-xTB (semi-empirical QM)
    charge_scheme: str = "auto"

    # Docking
    do_dock: bool = False
    adgpu_bin: str = "adgpu"
    n_mc_runs: int = 20
    seed: int = 42

    def _resolved_audit_log_path(self) -> Path:
        return self.audit_log_path or (self.output_dir / "uff_audit.log")


# ---------------------------------------------------------------------------
# Single-ligand processing
# ---------------------------------------------------------------------------


@dataclass
class LigandResult:
    ligand: Path
    success: bool
    log: Optional[Path] = None
    error: Optional[str] = None
    all_types: List[str] = field(default_factory=list)
    exotic_types: List[str] = field(default_factory=list)
    charge_source: str = "none"
    pdbqt_prepared: bool = False
    missing_maps: List[str] = field(default_factory=list)
    docked: bool = False
    dlg_path: Optional[Path] = None


def process_ligand(ligand_path: Path, cfg: PipelineConfig) -> LigandResult:
    """Full JIT pipeline for one ligand.

    Steps:
      1. Detect partial charges — preserve pre-existing QM charges (PDBQT),
         or note that Gasteiger was computed as a fallback (SDF/MOL2/PDB).
      2. Extract AD4 atom types (PDBQT parser or RDKit element mapping).
      3. Identify exotic types not covered by the standard AD4 parameter set.
      4. Validate UFF coverage for every exotic type.
      5. Write AD4_parameters_temp.dat (base + only this ligand's exotic types).
         Every injected type is recorded in the UFF audit log.
      6. Determine grid centre + npts:
           • Explicit cfg.center → use as-is with cfg.npts.
           • None → bounding-box centre + auto npts via auto_grid_box().
      7. Generate the .gpf referencing the temp params file.
      8. Run AutoGrid4 (unless cfg.dry_run).
    """
    stem = ligand_path.stem
    work = cfg.output_dir / stem
    work.mkdir(parents=True, exist_ok=True)

    # Symlink receptor into work dir so relative paths in .gpf resolve correctly
    rec_link = work / cfg.receptor_pdbqt.name
    if not rec_link.exists():
        try:
            rec_link.symlink_to(cfg.receptor_pdbqt.resolve())
        except OSError:
            shutil.copy2(cfg.receptor_pdbqt, rec_link)

    # Resolve the PDBQT path used for coordinate extraction and grid generation
    pdbqt_prepared = False
    if ligand_path.suffix.lower() != ".pdbqt":
        dest_lig = work / ligand_path.name
        if not dest_lig.exists():
            shutil.copy2(ligand_path, dest_lig)
        pdbqt_candidate = work / (stem + ".pdbqt")
        if not pdbqt_candidate.exists():
            # Auto-convert SDF/MOL2/PDB → PDBQT using pdbqt_writer (exotic-element safe)
            try:
                from .pdbqt_writer import prepare_pdbqt

                prepare_pdbqt(
                    ligand_path, pdbqt_candidate, charge_scheme=cfg.charge_scheme
                )
                pdbqt_prepared = True
                logger.info("[%s] auto-generated PDBQT: %s", stem, pdbqt_candidate.name)
            except Exception as exc:
                logger.warning(
                    "[%s] PDBQT auto-generation failed (%s). "
                    "Grid maps will be generated but docking requires a prepared PDBQT.",
                    stem,
                    exc,
                )
        if pdbqt_candidate.exists():
            ligand_pdbqt = pdbqt_candidate
        else:
            ligand_pdbqt = ligand_path
    else:
        ligand_pdbqt = ligand_path
        lig_link = work / ligand_pdbqt.name
        if not lig_link.exists():
            try:
                lig_link.symlink_to(ligand_pdbqt.resolve())
            except OSError:
                shutil.copy2(ligand_pdbqt, lig_link)

    # ── Step 1: charge detection ─────────────────────────────────────────────
    charge_info = extract_charges(ligand_path)
    if charge_info.source == "pdbqt_preexisting":
        logger.info("[%s] charges: PRESERVED from input (source=QM/RESP)", stem)
    elif charge_info.source == "gasteiger":
        logger.info(
            "[%s] charges: Gasteiger fallback (%d atoms)",
            stem,
            len(charge_info.charges),
        )
    else:
        logger.debug("[%s] charges: none / will be assigned externally", stem)

    # ── Step 2–3: extract atom types ────────────────────────────────────────
    try:
        all_types, exotic_types = extract_atom_types(ligand_path)
    except ValueError as exc:
        return LigandResult(
            ligand=ligand_path,
            success=False,
            error=str(exc),
            charge_source=charge_info.source,
            pdbqt_prepared=pdbqt_prepared,
        )

    logger.info("[%s] atom types: %s", stem, sorted(all_types))
    if exotic_types:
        logger.info("[%s] exotic types: %s", stem, sorted(exotic_types))

    all_types_sorted = sorted(all_types)
    exotic_types_sorted = sorted(exotic_types)

    # ── Step 4: validate UFF coverage ────────────────────────────────────────
    missing = [t for t in exotic_types if get_uff_params(t) is None]
    if missing:
        err = (
            f"No UFF parameters for: {missing}. "
            "Add entries to atom_params._UFF_RAW or provide manual AtomParams overrides."
        )
        logger.error("[%s] %s", stem, err)
        return LigandResult(
            ligand=ligand_path,
            success=False,
            error=err,
            all_types=all_types_sorted,
            exotic_types=exotic_types_sorted,
            charge_source=charge_info.source,
            pdbqt_prepared=pdbqt_prepared,
        )

    # ── Step 5: detect receptor types (needed before writing temp params) ────
    rec_types = (
        cfg.receptor_types
        if cfg.receptor_types is not None
        else detect_receptor_types(cfg.receptor_pdbqt)
    )
    needed_types: Set[str] = set(all_types) | set(rec_types)

    # ── Step 6: write temp params with audit logging ─────────────────────────
    temp_dat = work / "AD4_parameters_temp.dat"
    audit_log: Optional[UFFAuditLog] = None
    if exotic_types:
        audit_log = UFFAuditLog(cfg._resolved_audit_log_path())

    try:
        write_temp_params(
            exotic_types,
            temp_dat,
            base_dat=cfg.base_dat,
            audit_log=audit_log,
            ligand_name=stem,
            needed_types=needed_types,
        )
    except RuntimeError as exc:
        return LigandResult(
            ligand=ligand_path,
            success=False,
            error=str(exc),
            all_types=all_types_sorted,
            exotic_types=exotic_types_sorted,
            charge_source=charge_info.source,
            pdbqt_prepared=pdbqt_prepared,
        )

    # ── Step 7: determine grid centre + npts ─────────────────────────────────
    if cfg.center:
        grid_center = cfg.center
        grid_npts = cfg.npts
    else:
        grid_center, grid_npts = auto_grid_box(
            ligand_pdbqt,
            padding=cfg.grid_padding,
            spacing=cfg.spacing,
        )
        logger.info(
            "[%s] auto grid  centre=(%.3f, %.3f, %.3f)  npts=(%d, %d, %d)",
            stem,
            *grid_center,
            *grid_npts,
        )

    # ── Step 8: generate .gpf ────────────────────────────────────────────────
    grid_cfg = GridConfig(
        receptor_pdbqt=cfg.receptor_pdbqt,
        receptor_types=rec_types,
        ligand_pdbqt=ligand_pdbqt,
        temp_params_dat=temp_dat,
        center=grid_center,
        npts=grid_npts,
        spacing=cfg.spacing,
        smooth=cfg.smooth,
        dielectric=cfg.dielectric,
    )
    gpf_path = work / f"{stem}.gpf"
    generate_gpf(all_types, grid_cfg, gpf_path)
    logger.info("[%s] GPF written: %s", stem, gpf_path)

    # ── Step 8: run AutoGrid4 ────────────────────────────────────────────────
    if cfg.dry_run:
        logger.info("[%s] dry-run: skipping AutoGrid4 execution.", stem)
        return LigandResult(
            ligand=ligand_path,
            success=True,
            all_types=all_types_sorted,
            exotic_types=exotic_types_sorted,
            charge_source=charge_info.source,
            pdbqt_prepared=pdbqt_prepared,
        )

    try:
        log_file = run_autogrid(
            gpf_path,
            cfg.autogrid_bin,
            work_dir=work,
            timeout=cfg.timeout,
            auto_install=cfg.auto_install,
        )
    except (AutoGridError, FileNotFoundError) as exc:
        return LigandResult(
            ligand=ligand_path,
            success=False,
            error=str(exc),
            all_types=all_types_sorted,
            exotic_types=exotic_types_sorted,
            charge_source=charge_info.source,
            pdbqt_prepared=pdbqt_prepared,
        )

    # ── Step 9: validate expected .map files ──────────────────────────────
    prefix = cfg.receptor_pdbqt.stem
    expected_maps = [f"{prefix}.{t}.map" for t in all_types_sorted]
    expected_maps += [f"{prefix}.e.map", f"{prefix}.d.map"]
    missing: List[str] = []
    for map_name in expected_maps:
        if not (work / map_name).exists():
            missing.append(map_name)
    if missing:
        logger.warning(
            "[%s] missing %d of %d expected map(s): %s",
            stem,
            len(missing),
            len(expected_maps),
            ", ".join(missing),
        )

    # ── Step 10: run AutoDock-GPU (optional) ──────────────────────────────
    dlg_path: Optional[Path] = None
    docked = False
    if cfg.do_dock:
        prefix = cfg.receptor_pdbqt.stem
        try:
            dlg_path = run_adgpu(
                ligand_pdbqt=ligand_pdbqt,
                maps_prefix=prefix,
                output_prefix=stem,
                adgpu_bin=cfg.adgpu_bin,
                work_dir=work,
                n_runs=cfg.n_mc_runs,
                seed=cfg.seed,
                timeout=cfg.timeout,
                auto_install=cfg.auto_install,
            )
            docked = True
            logger.info("[%s] docking complete: %s", stem, dlg_path)
        except (AutoDockGPUError, FileNotFoundError) as exc:
            logger.warning("[%s] docking failed: %s", stem, exc)

    return LigandResult(
        ligand=ligand_path,
        success=True,
        log=log_file,
        all_types=all_types_sorted,
        exotic_types=exotic_types_sorted,
        charge_source=charge_info.source,
        pdbqt_prepared=pdbqt_prepared,
        missing_maps=missing,
        docked=docked,
        dlg_path=dlg_path,
    )


# ---------------------------------------------------------------------------
# Batch processing — sequential
# ---------------------------------------------------------------------------


def process_batch(cfg: PipelineConfig) -> List[LigandResult]:
    """Run the JIT pipeline over every ligand in cfg.ligands_dir (sequential).

    Use :func:`process_batch_parallel` for CPU-bound batches.
    """
    ligands = list_ligand_files(cfg.ligands_dir, cfg.extensions)
    if not ligands:
        logger.warning("No ligand files found in: %s", cfg.ligands_dir)
        return []

    total = len(ligands)
    results: List[LigandResult] = []

    # Cache receptor types once for the entire batch
    if cfg.receptor_types is None:
        cfg.receptor_types = detect_receptor_types(cfg.receptor_pdbqt)

    logger.info("=" * 60)
    logger.info("OmniGrid batch  —  %d ligand(s)  →  %s", total, cfg.output_dir)
    logger.info("=" * 60)

    for idx, lig in enumerate(ligands, 1):
        logger.info("[%d/%d] Processing: %s", idx, total, lig.name)
        result = process_ligand(lig, cfg)
        results.append(result)

        if not result.success:
            logger.error("  FAILED: %s", result.error)
            if cfg.stop_on_error:
                logger.error("Aborting batch (stop_on_error=True).")
                break
        else:
            exotic_tag = (
                " [exotic: " + ", ".join(result.exotic_types) + "]"
                if result.exotic_types
                else ""
            )
            charge_tag = f" [charges: {result.charge_source}]"
            logger.info("  OK%s%s", exotic_tag, charge_tag)

    _log_summary(results, total)
    return results


# ---------------------------------------------------------------------------
# Batch processing — parallel (multiprocessing)
# ---------------------------------------------------------------------------


def _init_worker(log_level: int) -> None:
    """Initialise basic logging in each worker process."""
    logging.basicConfig(
        level=log_level,
        format="[%(processName)s] %(levelname)s %(name)s: %(message)s",
    )


def _worker_fn(args: Tuple[Path, PipelineConfig]) -> LigandResult:
    """Top-level picklable worker function for multiprocessing.Pool."""
    ligand_path, cfg = args
    return process_ligand(ligand_path, cfg)


def process_batch_parallel(
    cfg: PipelineConfig,
    n_workers: Optional[int] = None,
) -> List[LigandResult]:
    """Run the JIT pipeline over all ligands using a multiprocessing pool.

    Each ligand is processed in a separate OS process, which:
    • bypasses Python's GIL for true CPU parallelism;
    • keeps each ligand's file I/O and AutoGrid4 call fully independent.

    The UFF audit log is written by individual workers; because each entry is a
    single line flush, Linux kernel append-atomicity keeps the file consistent
    for typical line sizes.

    Args:
        cfg:       Pipeline configuration shared by all workers.
        n_workers: CPU cores to use.  Defaults to min(cpu_count, n_ligands).

    Returns:
        List of :class:`LigandResult` objects (order matches input ligand list).
    """
    ligands = list_ligand_files(cfg.ligands_dir, cfg.extensions)
    if not ligands:
        logger.warning("No ligand files found in: %s", cfg.ligands_dir)
        return []

    workers = n_workers or min(mp.cpu_count(), len(ligands))
    total = len(ligands)
    log_lvl = logging.getLogger().level or logging.INFO

    # Cache receptor types once for the entire batch (shared via pickled cfg)
    if cfg.receptor_types is None:
        cfg.receptor_types = detect_receptor_types(cfg.receptor_pdbqt)

    logger.info("=" * 60)
    logger.info(
        "OmniGrid parallel batch  —  %d ligand(s)  /  %d worker(s)  →  %s",
        total,
        workers,
        cfg.output_dir,
    )
    logger.info("=" * 60)

    args_list = [(lig, cfg) for lig in ligands]

    with mp.Pool(
        processes=workers,
        initializer=_init_worker,
        initargs=(log_lvl,),
    ) as pool:
        results: List[LigandResult] = pool.map(_worker_fn, args_list)

    _log_summary(results, total)
    return results


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _log_summary(results: List[LigandResult], total: int) -> None:
    ok = sum(1 for r in results if r.success)
    err = sum(1 for r in results if not r.success)
    logger.info("=" * 60)
    logger.info(
        "Batch complete:  %d succeeded  /  %d failed  /  %d total",
        ok,
        err,
        total,
    )
    logger.info("=" * 60)
