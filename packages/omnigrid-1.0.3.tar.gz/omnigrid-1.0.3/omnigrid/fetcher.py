"""
Structure fetcher: downloads ligand files from PubChem (by CID) or the RCSB PDB.

Uses only Python stdlib (urllib) — no additional dependencies required.
Parallel downloads are handled via multiprocessing so the GIL is not a bottleneck.

APIs used:
    PubChem REST : https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/SDF
    RCSB PDB     : https://files.rcsb.org/download/{pdb_id}.pdb

Typical usage::

    from omnigrid.fetcher import fetch_pubchem_structures, fetch_pdb_structures
    from pathlib import Path

    downloaded = fetch_pubchem_structures([2519, 5090, 702], Path("ligands/"), n_workers=4)
    # downloaded → {2519: Path("ligands/CID_2519.sdf"), ...}

    pdb_files = fetch_pdb_structures(["1HVR", "4DKL"], Path("ligands/"), n_workers=2)
    # pdb_files → {"1HVR": Path("ligands/1HVR.pdb"), ...}
"""

from __future__ import annotations

import logging
import multiprocessing as mp
import urllib.error
import urllib.request
from pathlib import Path
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)

_PUBCHEM_SDF_URL = "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/SDF"
_PDB_URL = "https://files.rcsb.org/download/{pdb_id}.pdb"

# User-agent string — NCBI guidelines ask bots to identify themselves
_UA = "OmniGrid/1.0 (automated structure fetch; contact: omnigrid-pipeline)"


class FetchError(RuntimeError):
    """Raised when a structure file cannot be downloaded."""


# ---------------------------------------------------------------------------
# Low-level download helper
# ---------------------------------------------------------------------------


def _download(url: str, dest: Path, timeout: int = 30) -> Path:
    """Fetch *url* and write the response body to *dest*.

    Raises:
        FetchError: on HTTP errors or network failures.
    """
    req = urllib.request.Request(url, headers={"User-Agent": _UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            dest.write_bytes(resp.read())
    except urllib.error.HTTPError as exc:
        raise FetchError(f"HTTP {exc.code} fetching {url}") from exc
    except urllib.error.URLError as exc:
        raise FetchError(f"Network error fetching {url}: {exc.reason}") from exc
    return dest


# ---------------------------------------------------------------------------
# Per-record worker functions (must be module-level for pickling)
# ---------------------------------------------------------------------------


def _fetch_pubchem_record(
    args: Tuple[int, Path, int],
) -> Tuple[int, bool, str]:
    """Download one PubChem CID as SDF.

    Returns (cid, success, message_or_path).
    """
    cid, output_dir, timeout = args
    dest = output_dir / f"CID_{cid}.sdf"
    if dest.exists():
        return cid, True, f"cached:{dest}"
    url = _PUBCHEM_SDF_URL.format(cid=cid)
    try:
        _download(url, dest, timeout)
        return cid, True, str(dest)
    except FetchError as exc:
        return cid, False, str(exc)


def _fetch_pdb_record(
    args: Tuple[str, Path, int],
) -> Tuple[str, bool, str]:
    """Download one RCSB PDB entry as .pdb.

    Returns (pdb_id_upper, success, message_or_path).
    """
    pdb_id, output_dir, timeout = args
    pdb_id = pdb_id.upper()
    dest = output_dir / f"{pdb_id}.pdb"
    if dest.exists():
        return pdb_id, True, f"cached:{dest}"
    url = _PDB_URL.format(pdb_id=pdb_id)
    try:
        _download(url, dest, timeout)
        return pdb_id, True, str(dest)
    except FetchError as exc:
        return pdb_id, False, str(exc)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def fetch_pubchem_structures(
    cids: List[int],
    output_dir: Path,
    n_workers: int = 4,
    timeout: int = 30,
) -> Dict[int, Path]:
    """Download SDF files from PubChem for the given CID list.

    Files are saved as ``CID_<cid>.sdf`` inside *output_dir*.
    Already-present files are skipped without re-downloading.

    Args:
        cids:       PubChem compound IDs to fetch.
        output_dir: Destination folder (created if absent).
        n_workers:  Parallel download processes (default 4).
        timeout:    HTTP timeout per request in seconds (default 30).

    Returns:
        Mapping of CID → Path for every successfully downloaded file.
        Failed CIDs are logged as errors and omitted from the result.
    """
    if not cids:
        return {}
    output_dir.mkdir(parents=True, exist_ok=True)
    workers = min(n_workers, len(cids))
    args_list = [(cid, output_dir, timeout) for cid in cids]

    logger.info(
        "Fetching %d PubChem structure(s) with %d worker(s)…", len(cids), workers
    )
    results: Dict[int, Path] = {}

    with mp.Pool(processes=workers) as pool:
        for cid, success, msg in pool.map(_fetch_pubchem_record, args_list):
            if success:
                path_str = msg.replace("cached:", "")
                logger.info("  CID %-10d → %s", cid, path_str)
                results[cid] = Path(path_str)
            else:
                logger.error("  CID %-10d FAILED: %s", cid, msg)

    logger.info("PubChem fetch complete: %d/%d succeeded.", len(results), len(cids))
    return results


def fetch_pdb_structures(
    pdb_ids: List[str],
    output_dir: Path,
    n_workers: int = 4,
    timeout: int = 30,
) -> Dict[str, Path]:
    """Download .pdb files from RCSB PDB for the given accession list.

    Files are saved as ``<PDB_ID>.pdb`` (upper-case) inside *output_dir*.
    Already-present files are skipped without re-downloading.

    Args:
        pdb_ids:    4-character RCSB PDB accession codes (case-insensitive).
        output_dir: Destination folder (created if absent).
        n_workers:  Parallel download processes (default 4).
        timeout:    HTTP timeout per request in seconds (default 30).

    Returns:
        Mapping of upper-case PDB ID → Path for every successful download.
        Failed IDs are logged as errors and omitted from the result.
    """
    if not pdb_ids:
        return {}
    output_dir.mkdir(parents=True, exist_ok=True)
    workers = min(n_workers, len(pdb_ids))
    args_list = [(pid, output_dir, timeout) for pid in pdb_ids]

    logger.info(
        "Fetching %d PDB structure(s) with %d worker(s)…", len(pdb_ids), workers
    )
    results: Dict[str, Path] = {}

    with mp.Pool(processes=workers) as pool:
        for pdb_id, success, msg in pool.map(_fetch_pdb_record, args_list):
            if success:
                path_str = msg.replace("cached:", "")
                logger.info("  PDB %-6s → %s", pdb_id, path_str)
                results[pdb_id] = Path(path_str)
            else:
                logger.error("  PDB %-6s FAILED: %s", pdb_id, msg)

    logger.info("PDB fetch complete: %d/%d succeeded.", len(results), len(pdb_ids))
    return results
