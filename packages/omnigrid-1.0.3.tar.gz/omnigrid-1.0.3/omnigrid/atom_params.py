"""
UFF-based atomic parameters for AutoGrid4 extension to the full periodic table.

Reference: Rappé, A. K. et al. (1992) JACS 114(25):10024-10035.
"""

from __future__ import annotations

import logging
import math
import os
import re
import subprocess
import tempfile
from dataclasses import dataclass
from typing import Any, Dict, Optional, Set, Tuple

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class AtomParams:
    """AutoGrid4 parameters for a single atom type."""

    symbol: str  # AD4 type name (case-sensitive, e.g. 'Pt', 'B', 'Ru')
    Rii: float  # vdW pairwise-distance parameter (Å)  — Rii_contact = Rii_i + Rii_j
    epsii: float  # well depth (kcal/mol)
    vol: float  # atomic solvation volume (Å³)
    solpar: float  # atomic solvation parameter
    r_cov: float  # single-bond covalent radius (Å)
    hbond: int = 0  # H-bond type: 0 = none, 1–6 = AD4 donor/acceptor subtypes


# ---------------------------------------------------------------------------
# Standard AD4 elements — already present in every AD4_parameters.dat
# ---------------------------------------------------------------------------
STANDARD_AD4_ELEMENTS: Set[str] = {
    "H",
    "C",
    "N",
    "O",
    "S",
    "P",
    "F",
    "Cl",
    "Br",
    "I",
    "Mg",
    "Mn",
    "Fe",
    "Ca",
    "Zn",
}

# Canonical element → preferred AD4 type for PDBQT labelling
# (used when converting non-PDBQT inputs).
ELEMENT_TO_AD4_TYPE: Dict[str, str] = {
    "H": "HD",  # polar H (safe default; apolar H usually removed)
    "C": "C",
    "N": "NA",  # default: H-bond acceptor
    "O": "OA",  # default: H-bond acceptor
    "S": "SA",  # default: H-bond acceptor
    "P": "P",
    "F": "F",
    "Cl": "CL",
    "Br": "BR",
    "I": "I",
    "Mg": "MG",
    "Mn": "MN",
    "Fe": "FE",
    "Ca": "CA",
    "Zn": "ZN",
}

# ---------------------------------------------------------------------------
# Standard AD4 atom-type parameters (embedded copy of AD4_parameters.dat)
# Columns: symbol → AtomParams
# Rii values here are vdW pairwise-distance parameters (not raw radii).
# Vol validated with: vol = (4/3)π(Rii/2)³  (exact for organic atoms).
# Metal volumes are empirically calibrated in the original AD4 file.
# ---------------------------------------------------------------------------
STANDARD_AD4_PARAMS: Dict[str, AtomParams] = {
    p.symbol: p
    for p in [
        AtomParams("H", 2.000, 0.0200, 0.000, 0.00051, 0.370, 0),
        AtomParams("HD", 2.000, 0.0200, 0.000, 0.00051, 0.370, 0),
        AtomParams("HS", 2.000, 0.0200, 0.000, 0.00051, 0.370, 1),
        AtomParams("C", 4.000, 0.1500, 33.510, -0.00143, 0.770, 0),
        AtomParams("A", 4.000, 0.1500, 33.510, -0.00143, 0.770, 0),
        AtomParams("N", 3.500, 0.1600, 22.449, -0.00162, 0.750, 0),
        AtomParams("NA", 3.500, 0.1600, 22.449, -0.00162, 0.750, 4),
        AtomParams("NS", 3.500, 0.1600, 22.449, -0.00162, 0.750, 4),
        AtomParams("OA", 3.200, 0.2000, 17.157, -0.00238, 0.660, 5),
        AtomParams("OS", 3.200, 0.2000, 17.157, -0.00238, 0.660, 5),
        AtomParams("SA", 4.000, 0.2000, 33.510, -0.00249, 1.020, 6),
        AtomParams("S", 4.000, 0.2000, 33.510, -0.00249, 1.020, 0),
        AtomParams("P", 4.200, 0.2000, 38.792, -0.00110, 1.100, 0),
        AtomParams("F", 3.094, 0.0800, 15.448, -0.00109, 0.640, 0),
        AtomParams("I", 4.723, 0.5500, 55.059, -0.00143, 1.330, 0),
        AtomParams("CL", 4.090, 0.2760, 35.823, -0.00143, 0.990, 0),
        AtomParams("BR", 4.330, 0.3890, 42.566, -0.00143, 1.140, 0),
        AtomParams("MG", 1.300, 0.8750, 1.560, -0.00143, 0.740, 0),
        AtomParams("MN", 1.300, 0.8750, 2.140, -0.00143, 0.790, 0),
        AtomParams("FE", 1.300, 0.0100, 1.840, -0.00143, 1.300, 0),
        AtomParams("CA", 1.980, 0.5500, 2.770, -0.00143, 0.990, 0),
        AtomParams("ZN", 1.100, 0.2500, 1.000, -0.00143, 1.310, 0),
    ]
}

# Validate that every element in STANDARD_AD4_ELEMENTS maps to a parameter
# entry via ELEMENT_TO_AD4_TYPE or direct/case-insensitive key match.
_param_keys_upper = {k.upper() for k in STANDARD_AD4_PARAMS}
_elements_missing = []
for e in STANDARD_AD4_ELEMENTS:
    mapped = ELEMENT_TO_AD4_TYPE.get(e, e)
    if mapped not in STANDARD_AD4_PARAMS and mapped.upper() not in _param_keys_upper:
        _elements_missing.append(e)
if _elements_missing:
    raise AssertionError(
        "Elements in STANDARD_AD4_ELEMENTS without corresponding "
        f"STANDARD_AD4_PARAMS entry: {_elements_missing}. "
        "Add AtomParams entry or update ELEMENT_TO_AD4_TYPE mapping."
    )

# ---------------------------------------------------------------------------
# UFF raw data for exotic elements
# Source: Rappé et al. (1992), Table 1
# Tuple layout: (x1 Å, D1 kcal/mol, r_1 Å)
#   x1  = vdW distance parameter used as Rii in AutoGrid4
#   D1  = well depth used as epsii
#   r_1 = single-bond radius used as r_cov
# ---------------------------------------------------------------------------
_UFF_RAW: Dict[str, Tuple[float, float, float]] = {
    # ── Period 2 / 3 main-group ─────────────────────────────────────────────
    "Li": (2.451, 0.025, 1.225),
    "Be": (2.745, 0.085, 0.985),
    "B": (3.637, 0.095, 0.804),
    "Al": (4.008, 0.505, 1.244),
    "Si": (4.295, 0.402, 1.176),
    "Na": (2.983, 0.030, 1.491),
    "K": (3.812, 0.035, 1.975),
    # ── Period 4 main-group ──────────────────────────────────────────────────
    "Ga": (3.905, 0.415, 1.225),
    "Ge": (4.420, 0.379, 1.212),
    "As": (4.359, 0.309, 1.210),
    "Se": (4.205, 0.291, 1.190),
    "Rb": (4.061, 0.040, 2.260),
    "Sr": (3.235, 0.235, 2.170),
    # ── Period 5 main-group ──────────────────────────────────────────────────
    "In": (3.976, 0.599, 1.408),
    "Sn": (4.209, 0.567, 1.485),
    "Sb": (4.331, 0.449, 1.480),
    "Te": (4.470, 0.337, 1.380),
    "Cs": (4.517, 0.045, 2.496),
    "Ba": (3.299, 0.364, 2.504),
    # ── Period 6 main-group ──────────────────────────────────────────────────
    "Tl": (3.873, 0.680, 1.518),
    "Pb": (4.168, 0.663, 1.459),
    "Bi": (4.316, 0.518, 1.512),
    # ── Period 4 transition metals ───────────────────────────────────────────
    "Sc": (3.295, 0.019, 1.374),
    "Ti": (2.828, 0.071, 1.412),
    "V": (2.800, 0.054, 1.402),
    "Cr": (2.693, 0.031, 1.345),
    "Co": (2.559, 0.014, 1.392),
    "Ni": (2.525, 0.015, 1.392),
    "Cu": (3.114, 0.005, 1.457),
    # ── Period 5 transition metals ───────────────────────────────────────────
    "Y": (3.345, 0.072, 1.698),
    "Zr": (2.783, 0.069, 1.564),
    "Nb": (2.820, 0.059, 1.473),
    "Mo": (2.719, 0.056, 1.484),
    "Tc": (2.671, 0.048, 1.322),
    "Ru": (2.963, 0.056, 1.483),
    "Rh": (2.998, 0.053, 1.526),
    "Pd": (2.909, 0.048, 1.376),
    "Ag": (3.148, 0.036, 1.646),
    "Cd": (2.537, 0.228, 1.685),
    # ── Period 6 transition metals ───────────────────────────────────────────
    "La": (3.953, 0.017, 1.872),
    "Hf": (2.798, 0.072, 1.611),
    "Ta": (2.824, 0.081, 1.511),
    "W": (2.734, 0.067, 1.526),
    "Re": (2.892, 0.066, 1.372),
    "Os": (2.789, 0.037, 1.372),
    "Ir": (2.530, 0.073, 1.371),
    "Pt": (2.453, 0.080, 1.364),
    "Au": (2.934, 0.039, 1.262),
    "Hg": (2.410, 0.385, 1.340),
    # ── Lanthanides ─────────────────────────────────────────────────────────
    "Ce": (3.556, 0.013, 1.841),
    "Pr": (3.606, 0.010, 1.823),
    "Nd": (3.575, 0.010, 1.816),
    "Sm": (3.520, 0.008, 1.780),
    "Eu": (3.493, 0.008, 1.771),
    "Gd": (3.368, 0.009, 1.735),
    "Tb": (3.451, 0.007, 1.732),
    "Dy": (3.428, 0.007, 1.710),
    "Ho": (3.409, 0.007, 1.696),
    "Er": (3.391, 0.007, 1.673),
    "Yb": (3.355, 0.228, 1.637),
    "Lu": (3.640, 0.041, 1.671),
}

# Solvation class → calibrated S constant.
# solpar = S / vol  (validated: C → S = -0.00143 × 33.51 = -4.792e-2)
_SOLV_S: Dict[str, float] = {
    "nonpolar": -4.792e-2,  # C-like
    "polar": -3.637e-2,  # N-like
    "metal": -2.860e-3,  # conservative transition-metal default
    "lanthanide": -6.000e-3,  # +3 lanthanides (higher charge density)
}

_NONPOLAR_EXOTIC: frozenset = frozenset(
    {
        "B",
        "Al",
        "Si",
        "Ge",
        "Sn",
        "Pb",
        "Ga",
        "In",
        "Tl",
        "As",
        "Sb",
        "Bi",
    }
)
_POLAR_EXOTIC: frozenset = frozenset({"Se", "Te"})
_LANTHANIDE_EXOTIC: frozenset = frozenset(
    {
        "La",
        "Ce",
        "Pr",
        "Nd",
        "Sm",
        "Eu",
        "Gd",
        "Tb",
        "Dy",
        "Ho",
        "Er",
        "Yb",
        "Lu",
    }
)


def _solvation_class(symbol: str) -> str:
    if symbol in _NONPOLAR_EXOTIC:
        return "nonpolar"
    if symbol in _POLAR_EXOTIC:
        return "polar"
    if symbol in _LANTHANIDE_EXOTIC:
        return "lanthanide"
    return "metal"


def compute_vol(Rii: float) -> float:
    """Solvation volume from vdW pairwise-distance parameter.

    Formula: (4/3)π(Rii/2)³
    Validated for standard atoms: C Rii=4.00 → 33.51 Å³ ✓
                                   N Rii=3.50 → 22.45 Å³ ✓
    """
    return (4.0 / 3.0) * math.pi * (Rii / 2.0) ** 3


def compute_solpar(symbol: str, vol: float) -> float:
    """Atomic solvation parameter (Stouten model, AD4 convention).

    solpar = S_class / vol, where S_class is calibrated per element class.
    Returns a safe fallback if vol is zero or near-zero.
    """
    if vol < 1e-6:
        return -0.00143
    cls = _solvation_class(symbol)
    return _SOLV_S[cls] / vol


def get_uff_params(symbol: str) -> Optional[AtomParams]:
    """Derive AutoGrid4-compatible AtomParams from UFF data.

    Returns None if the element is unknown (caller should warn and skip).
    """
    entry = _UFF_RAW.get(symbol)
    if entry is None:
        return None
    x1, d1, r_cov = entry
    vol = round(compute_vol(x1), 4)
    solpar = round(compute_solpar(symbol, vol), 6)
    return AtomParams(
        symbol=symbol,
        Rii=x1,
        epsii=d1,
        vol=vol,
        solpar=solpar,
        r_cov=r_cov,
        hbond=0,
    )


# ---------------------------------------------------------------------------
# Metal charge lookup — common oxidation states for drug-discovery metals
# Used as fallback when Gasteiger fails and RDKit formal charge is 0.
# These serve as a starting point; input from QM/RESP or SDF formal charges
# always take precedence.
# ---------------------------------------------------------------------------

COMMON_METAL_CHARGES: Dict[str, int] = {
    # Alkali
    "Li": 1,
    "Na": 1,
    "K": 1,
    "Rb": 1,
    "Cs": 1,
    # Alkaline earth
    "Be": 2,
    "Mg": 2,
    "Ca": 2,
    "Sr": 2,
    "Ba": 2,
    # d-block (most common in drug discovery)
    "Sc": 3,
    "Ti": 4,
    "V": 5,
    "Cr": 3,
    "Mn": 2,
    "Fe": 2,
    "Co": 2,
    "Ni": 2,
    "Cu": 2,
    "Zn": 2,
    "Y": 3,
    "Zr": 4,
    "Nb": 5,
    "Mo": 6,
    "Tc": 7,
    "Ru": 3,
    "Rh": 3,
    "Pd": 2,
    "Ag": 1,
    "Cd": 2,
    "Hf": 4,
    "Ta": 5,
    "W": 6,
    "Re": 7,
    "Os": 4,
    "Ir": 3,
    "Pt": 2,
    "Au": 3,
    "Hg": 2,
    # p-block metals
    "Al": 3,
    "Ga": 3,
    "In": 3,
    "Tl": 3,
    "Sn": 4,
    "Pb": 4,
    "Bi": 5,
    "Sb": 5,
    "Te": 6,
    "Po": 6,
    # Lanthanide
    "La": 3,
}


def _find_xtb() -> Optional[str]:
    """Locate the xtb binary. Checks PATH and common install locations."""
    import shutil

    path = shutil.which("xtb")
    if path:
        return path
    candidates = [
        "/tmp/xtb-dist/bin/xtb",
        "/usr/local/bin/xtb",
        os.path.expanduser("~/.local/bin/xtb"),
    ]
    for c in candidates:
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    return None


def _compute_xtb_charges(mol, net_charge: int = 0) -> Optional[Dict[int, float]]:
    """Compute partial charges via GFN2-xTB (GFN2-xTB).

    Args:
        mol: RDKit Mol with hydrogens and 3D coordinates.
        net_charge: Total molecular charge (default 0).

    Returns:
        {atom_idx: charge} or None if xtb fails / is unavailable.
    """
    xtb_path = _find_xtb()
    if xtb_path is None:
        logger.info("xtb not found — skipping GFN2-xTB charge computation.")
        return None

    try:
        conf = mol.GetConformer()
    except ValueError:
        logger.warning("xtb: molecule has no 3D coordinates.")
        return None

    n_atoms = mol.GetNumAtoms()
    lines = [f"{n_atoms}", "charges"]
    for atom in mol.GetAtoms():
        pos = conf.GetAtomPosition(atom.GetIdx())
        lines.append(f"{atom.GetSymbol()} {pos.x:.6f} {pos.y:.6f} {pos.z:.6f}")

    with tempfile.TemporaryDirectory(prefix="xtb_") as tmp:
        xyz_path = os.path.join(tmp, "mol.xyz")
        with open(xyz_path, "w") as f:
            f.write("\n".join(lines) + "\n")

        try:
            cmd = [
                xtb_path,
                xyz_path,
                "--chrg",
                str(net_charge),
                "--esp",
                "--parallel",
                "1",
            ]
            env = os.environ.copy()
            env["OMP_NUM_THREADS"] = "1"
            env["MKL_NUM_THREADS"] = "1"

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120,
                env=env,
            )

            if result.returncode != 0:
                logger.debug(
                    "xtb failed (rc=%d): %s", result.returncode, result.stderr[:200]
                )
                return None

        except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
            logger.debug("xtb execution error: %s", exc)
            return None

        # Parse Mulliken charges from xtb output.
        # xtb prints two tables with charge-like columns:
        #   1. Mulliken charges (e.g. "1   7 N    2.590   -0.287   27.408   7.775")
        #   2. Wiberg/Mayer bond orders with '--' in charge column.
        # We collect from the FIRST table only.
        charges: Dict[int, float] = {}
        table_seen = False
        for line in result.stdout.split("\n"):
            # Match lines like: "     1   7 N        2.590    -0.287    27.408     7.775"
            match = re.match(
                r"^\s+(\d+)\s+\d+\s+[A-Z][a-z]?\s+"
                r"\d+\.?\d*\s+"  # covCN (e.g. 2.590)
                r"(-?\d+\.\d+)",  # charge (e.g. -0.287)
                line,
            )
            if match:
                atom_idx = int(match.group(1)) - 1
                q = float(match.group(2))
                charges[atom_idx] = round(q, 5)
                table_seen = True
            elif table_seen:
                # We've moved past the charge table
                break

        if len(charges) == n_atoms:
            logger.info(
                "GFN2-xTB charges computed for %d atoms (method: GFN2-xTB).",
                n_atoms,
            )
            return charges

        logger.debug("xtb: parsed %d/%d charges — falling back.", len(charges), n_atoms)
        return None


def _charge_fallback(atom: Any) -> float:
    """Determine partial charge when Gasteiger and xtb both fail.

    Priority:
      1. RDKit formal charge from the molecule (comes from SDF/MOL2 input).
      2. Lookup table for common metal oxidation states.
      3. Zero — no information available.
    """
    formal = atom.GetFormalCharge()
    if formal != 0:
        return float(formal)

    element = atom.GetSymbol()
    charge = COMMON_METAL_CHARGES.get(element)
    if charge is not None:
        return float(charge)

    return 0.0


def compute_gasteiger_charges(mol, scheme: str = "auto") -> Dict[int, float]:
    """Compute partial charges with hybrid strategy.

    Priority:
      1. GFN2-xTB (semi-empirical QM) — when exotic atoms are detected.
      2. Gasteiger (RDKit) — works for organic elements.
      3. GFN2-xTB (fallback for any element when Gasteiger fails on organics).
      4. Formal charge from input file (preserved by RDKit from SDF/MOL2).
      5. Lookup table of common metal oxidation states.
      6. Zero — no information available.

    Args:
        mol: An RDKit Mol (hydrogens should already be added for accuracy).
        scheme: Charge computation scheme.
            "auto"  — cascade: xtb (exotic) → Gasteiger → fallback (default).
            "gasteiger" — skip xtb entirely, use Gasteiger → fallback.
            "xtb"   — force xtb; raise ValueError if unavailable or fails.

    This ensures that metallodrugs and exotic-element systems get
    quantum-mechanical charges (GFN2-xTB) rather than NaN→0 fallback
    from Gasteiger, which is not parametrised for transition metals
    or heavier p-block elements.

    Logs a clear message for every fallback level used.

    Args:
        mol: An RDKit Mol (hydrogens should already be added for accuracy).

    Returns:
        {atom_idx: charge} for every atom in the molecule.
    """
    try:
        from rdkit.Chem import AllChem
    except ImportError:
        raise ImportError(
            "RDKit is required. Install with: conda install -c conda-forge rdkit"
        )

    charges: Dict[int, float] = {}
    has_exotic = any(is_exotic(atom.GetSymbol()) for atom in mol.GetAtoms())

    if scheme == "xtb":
        # Force xtb — fail if unavailable
        xtb_charges = _compute_xtb_charges(mol)
        if xtb_charges is None or len(xtb_charges) != mol.GetNumAtoms():
            missing = sum(
                1 for i in range(mol.GetNumAtoms()) if i not in (xtb_charges or {})
            )
            if missing > 0 or xtb_charges is None:
                raise ValueError(
                    f"xtb charge scheme forced but xtb failed "
                    f"(got {len(xtb_charges or [])}/{mol.GetNumAtoms()} charges)."
                )
        return xtb_charges

    # ── Level 1: GFN2-xTB (for exotic-containing molecules, auto/gasteiger) ──
    if has_exotic and scheme != "gasteiger":
        xtb_charges = _compute_xtb_charges(mol)
        if xtb_charges is not None and len(xtb_charges) == mol.GetNumAtoms():
            missing = sum(1 for i in range(mol.GetNumAtoms()) if i not in xtb_charges)
            if missing == 0:
                logger.info(
                    "GFN2-xTB charges computed for %d atoms (method: GFN2-xTB).",
                    len(xtb_charges),
                )
                return xtb_charges
        logger.warning(
            "Exotic atoms detected but xtb failed — falling back to Gasteiger."
        )

    # ── Level 2: Gasteiger (organic default or xtb fallback) ─────────────────
    gasteiger_nan = False
    try:
        AllChem.ComputeGasteigerCharges(mol)
        for atom in mol.GetAtoms():
            try:
                q = float(atom.GetDoubleProp("_GasteigerCharge"))
            except KeyError:
                q = float("nan")
            if math.isnan(q) or math.isinf(q):
                gasteiger_nan = True
                break
            idx = atom.GetIdx()
            charges[idx] = round(q, 5)
    except Exception:
        gasteiger_nan = True

    if not gasteiger_nan:
        source = "Gasteiger" if not has_exotic else "Gasteiger (xtb unavailable)"
        logger.info(
            "%s charges computed for %d atoms (method: Gasteiger).",
            source,
            len(charges),
        )
        return charges

    # ── Level 3: xtb fallback (when Gasteiger fails, e.g. exotic with no xtb) ─
    if not has_exotic:
        xtb_charges = _compute_xtb_charges(mol)
        if xtb_charges is not None and len(xtb_charges) == mol.GetNumAtoms():
            missing = sum(1 for i in range(mol.GetNumAtoms()) if i not in xtb_charges)
            if missing == 0:
                logger.info(
                    "GFN2-xTB charges computed for %d atoms (Gasteiger failed, method: GFN2-xTB).",
                    len(xtb_charges),
                )
                return xtb_charges

    # ── Level 4: fallback (formal charge → lookup table → zero) ─────────────
    logger.warning("Gasteiger and xtb both failed — using fallback charge assignment.")

    formal_count = 0
    table_count = 0
    zeroed_count = 0

    for atom in mol.GetAtoms():
        idx = atom.GetIdx()
        q = _charge_fallback(atom)

        if q != 0.0:
            if atom.GetFormalCharge() != 0:
                formal_count += 1
            else:
                table_count += 1
        else:
            zeroed_count += 1

        charges[idx] = round(q, 5)

    total_assigned = sum(charges.values())
    expected = sum(atom.GetFormalCharge() for atom in mol.GetAtoms())
    delta = total_assigned - expected
    if abs(delta) > 0.01:
        if expected == 0:
            correction = -delta / mol.GetNumAtoms()
            for idx in charges:
                charges[idx] = round(charges[idx] + correction, 5)
            logger.warning(
                "Neutral molecule with net charge %.4f — redistributing "
                "%.6f evenly across %d atoms (placeholder). "
                "Install xtb for physically meaningful charges.",
                total_assigned,
                correction,
                mol.GetNumAtoms(),
            )
        else:
            logger.warning(
                "Net charge %.4f (target %+d). Install xtb for accurate charges.",
                total_assigned,
                expected,
            )

    total = formal_count + table_count + zeroed_count
    if total:
        parts = []
        if formal_count:
            parts.append(f"{formal_count} from formal charges")
        if table_count:
            parts.append(f"{table_count} from lookup table")
        if zeroed_count:
            parts.append(f"{zeroed_count} set to 0.000 (no data)")
        logger.warning(
            "%d atom(s) with fallback charges: %s. "
            "For accurate charges on metals, install xtb "
            "(https://github.com/grimme-lab/xtb).",
            total,
            ", ".join(parts),
        )

    return charges


def is_exotic(element: str) -> bool:
    """True when the element/type has no native entry in the standard AD4 parameter set."""
    if element in STANDARD_AD4_PARAMS:
        return False
    if element in STANDARD_AD4_ELEMENTS:
        return False
    return True
