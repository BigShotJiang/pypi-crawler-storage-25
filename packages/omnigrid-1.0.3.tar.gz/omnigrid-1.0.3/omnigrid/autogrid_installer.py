"""
AutoGrid4 auto-installer.

Detects whether ``autogrid4`` is available in PATH and, if not, offers to
install it automatically via the system package manager or download.

Strategy (in order):
  1. ``shutil.which("autogrid4")`` — already installed → nothing to do.
  2. ``apt install autogrid`` (Linux Debian/Ubuntu) — official package.
  3. Direct download from the AutoDock4 GitHub release (Linux binary).
  4. Manual download link as fallback.
"""

from __future__ import annotations

import logging
import os
import shutil
import stat
import subprocess
import tempfile
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_USER_AGENT = "OmniGrid/1.0 (autogrid auto-installer; contact: omnigrid-pipeline)"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def ensure_autogrid(
    autogrid_bin: str = "autogrid4",
    prompt: bool = True,
    install_dir: Optional[Path] = None,
) -> str:
    """Return the path to an autogrid4 executable, installing if necessary.

    Args:
        autogrid_bin: Name or path to check (default: ``"autogrid4"``).
        prompt:       If ``True``, ask the user before downloading.
        install_dir:  Where to place the binary (not used for apt install).

    Returns:
        Absolute path to the autogrid4 executable.

    Raises:
        RuntimeError: if autogrid4 cannot be found or installed.
    """
    resolved = shutil.which(autogrid_bin)
    if resolved is not None:
        logger.debug("AutoGrid4 found: %s", resolved)
        return resolved

    if not prompt:
        raise RuntimeError(
            f"AutoGrid4 binary '{autogrid_bin}' not found. "
            "Install AutoGrid4 and ensure it is in your PATH."
        )

    logger.warning("AutoGrid4 not found — attempting auto-install...")

    strategies = [
        _install_via_apt,
        _install_via_github_release,
    ]

    for strategy in strategies:
        try:
            dest = strategy(install_dir)
            if dest is not None:
                resolved = str(dest.resolve())
                logger.info("AutoGrid4 ready: %s", resolved)
                return resolved
        except Exception as exc:
            logger.debug("Strategy %s failed: %s", strategy.__name__, exc)
            continue

    raise RuntimeError(
        "AutoGrid4 could not be auto-installed.\n"
        "Install it manually:\n"
        "  Ubuntu/Debian:  sudo apt install autogrid\n"
        "  Other:          https://ccsb.scripps.edu/mgltools/\n"
        "                  https://github.com/ccsb-scripps/AutoDock4/releases"
    )


# ---------------------------------------------------------------------------
# Strategy 1 — apt (Linux Debian/Ubuntu)
# ---------------------------------------------------------------------------


def _install_via_apt(install_dir: Optional[Path] = None) -> Optional[Path]:
    """Install autogrid4 via ``apt install autogrid``."""
    if not shutil.which("apt"):
        logger.debug("apt not available — skipping apt strategy")
        return None

    if not _confirm(
        "AutoGrid4 not found. Install it via apt? (requires sudo: apt install autogrid)"
    ):
        return None

    logger.info("Installing autogrid via apt (sudo required)...")
    result = subprocess.run(
        ["sudo", "apt", "install", "-y", "autogrid"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        logger.debug("apt install failed:\n%s", result.stderr)
        return None

    resolved = shutil.which("autogrid4")
    return Path(resolved) if resolved else None


# ---------------------------------------------------------------------------
# Strategy 2 — GitHub release (AutoDock4, Linux binary)
# ---------------------------------------------------------------------------


def _install_via_github_release(
    install_dir: Optional[Path] = None,
) -> Optional[Path]:
    """Download autogrid4 from the official AutoDock4 GitHub release."""
    import json

    system = _detect_platform()
    if system != "Linux":
        logger.debug("GitHub release only provides Linux binaries — skipping")
        return None

    if not _confirm(
        "AutoGrid4 not found. Download from the official AutoDock4 repository?"
    ):
        return None

    api_url = "https://api.github.com/repos/ccsb-scripps/AutoDock4/releases"
    logger.info("Searching for autogrid4 binary in AutoDock4 releases...")

    try:
        req = urllib.request.Request(
            api_url,
            headers={"User-Agent": _USER_AGENT, "Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            releases = json.loads(resp.read().decode())
    except Exception as exc:
        logger.debug("Failed to fetch releases: %s", exc)
        return None

    binary_url: Optional[str] = None
    for rel in releases:
        for asset in rel.get("assets", []):
            name: str = asset.get("name", "")
            if "autogrid4" in name and ("linux" in name.lower()):
                binary_url = asset.get("browser_download_url")
                break
        if binary_url:
            break

    if not binary_url:
        logger.debug("No autogrid4 binary found in AutoDock4 releases")
        return None

    dest_dir = _resolve_install_dir(install_dir)
    dest_path = dest_dir / "autogrid4"

    logger.info("Downloading autogrid4...")
    _download_binary(binary_url, dest_path)
    return dest_path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _detect_platform() -> str:
    """Return the platform system name (Linux/Darwin/Windows)."""
    import platform

    return platform.system()


def _resolve_install_dir(install_dir: Optional[Path] = None) -> Path:
    """Pick a writable directory in PATH for the binary."""
    if install_dir is not None:
        install_dir.mkdir(parents=True, exist_ok=True)
        return install_dir

    conda_prefix = os.environ.get("CONDA_PREFIX")
    if conda_prefix:
        candidate = Path(conda_prefix) / "bin"
        if candidate.is_dir():
            return candidate

    fallback = Path.home() / ".local" / "bin"
    fallback.mkdir(parents=True, exist_ok=True)
    return fallback


def _confirm(message: str) -> bool:
    """Ask the user for confirmation."""
    try:
        reply = input(f"{message} [Y/n] ").strip().lower()
        return reply in ("", "y", "yes", "s", "sim")
    except (EOFError, KeyboardInterrupt):
        return False


def _download_binary(url: str, dest: Path) -> None:
    """Download a binary file from *url* to *dest*."""
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            dest.write_bytes(resp.read())
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"HTTP {exc.code} downloading autogrid4 from {url}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(
            f"Network error downloading autogrid4: {exc.reason}"
        ) from exc

    _make_executable(dest)


def _make_executable(path: Path) -> None:
    """Set the executable bit on *path*."""
    mode = path.stat().st_mode
    path.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


# ---------------------------------------------------------------------------
# xtb installer — GFN2-xTB binary for quantum-level charges
# ---------------------------------------------------------------------------

_XTB_URL = (
    "https://github.com/grimme-lab/xtb/releases/download/v6.7.1/"
    "xtb-6.7.1-linux-x86_64.tar.xz"
)


def ensure_xtb(
    prompt: bool = True,
    install_dir: Optional[Path] = None,
) -> Optional[str]:
    """Return the path to an xtb executable, downloading if necessary.

    Args:
        prompt:       If ``True``, ask user before downloading.
        install_dir:  Where to place the binary.

    Returns:
        Absolute path to the xtb executable, or ``None`` if unavailable.
    """
    resolved = shutil.which("xtb")
    if resolved is not None:
        logger.debug("xtb found: %s", resolved)
        return resolved

    candidates = [
        os.path.expanduser("~/.local/bin/xtb"),
        "/usr/local/bin/xtb",
    ]
    for c in candidates:
        if os.path.isfile(c) and os.access(c, os.X_OK):
            logger.info("xtb found: %s", c)
            return c

    if not prompt:
        logger.info("xtb not found and prompt=False — skipping install.")
        return None

    try:
        import tarfile
    except ImportError:
        logger.warning("tarfile not available — cannot extract xtb.")
        return None

    if not _confirm(
        "xtb (GFN2-xTB) not found. This enables quantum-level partial charges "
        "for ANY element. Download (~61 MB)?"
    ):
        return None

    dest_dir = _resolve_install_dir(install_dir)
    logger.info("Downloading xtb v6.7.1 (~61 MB)...")

    tmp_path = None
    try:
        req = urllib.request.Request(_XTB_URL, headers={"User-Agent": _USER_AGENT})
        with urllib.request.urlopen(req, timeout=300) as resp:
            tmp_path = Path(tempfile.mktemp(suffix=".tar.xz"))
            tmp_path.write_bytes(resp.read())

        logger.info("Extracting xtb...")
        with tarfile.open(str(tmp_path)) as tar:
            # Extract just the xtb binary, not the whole tree
            for member in tar.getmembers():
                if member.name.endswith("/bin/xtb"):
                    member.name = os.path.basename(member.name)
                    tar.extract(member, path=str(dest_dir))
                    break

        xtb_path = dest_dir / "xtb"
        if xtb_path.exists():
            _make_executable(xtb_path)
            logger.info(
                "xtb ready: %s (%d MB)",
                xtb_path,
                xtb_path.stat().st_size // 1024 // 1024,
            )
            return str(xtb_path)

        logger.warning("xtb binary not found in downloaded archive.")
        return None

    except (
        urllib.error.HTTPError,
        urllib.error.URLError,
        OSError,
        tarfile.TarError,
    ) as exc:
        logger.warning("Failed to download/extract xtb: %s", exc)
        return None
    finally:
        if tmp_path and tmp_path.exists():
            tmp_path.unlink()


# ── AutoDock-GPU ────────────────────────────────────────────────────────────

_ADGPU_VERSION = "v1.6"

_ADGPU_URLS = {
    "linux_cuda12": (
        "adgpu-v1.6_linux_x64_cuda12_128wi",
        f"https://github.com/ccsb-scripps/AutoDock-GPU/releases/download/{_ADGPU_VERSION}/adgpu-v1.6_linux_x64_cuda12_128wi",
    ),
    "linux_cuda11": (
        "adgpu-v1.6_linux_x64_cuda11_128wi",
        f"https://github.com/ccsb-scripps/AutoDock-GPU/releases/download/{_ADGPU_VERSION}/adgpu-v1.6_linux_x64_cuda11_128wi",
    ),
    "linux_ocl": (
        "adgpu-v1.6_linux_x64_ocl_128wi",
        f"https://github.com/ccsb-scripps/AutoDock-GPU/releases/download/{_ADGPU_VERSION}/adgpu-v1.6_linux_x64_ocl_128wi",
    ),
}


def _detect_cuda() -> bool:
    try:
        result = subprocess.run(
            ["nvidia-smi"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def ensure_adgpu(
    prompt: bool = True,
    install_dir: Optional[Path] = None,
) -> Optional[str]:
    """Return path to AutoDock-GPU binary, downloading if necessary.

    Detection order:
      1. ``adgpu`` in PATH
      2. CUDA 12 (if nvidia-smi works)
      3. CUDA 11
      4. OpenCL

    Args:
        prompt:      Ask user before downloading.
        install_dir: Where to place the binary.

    Returns:
        Absolute path to the AutoDock-GPU executable, or ``None``.
    """
    resolved = shutil.which("adgpu")
    if resolved is not None:
        logger.debug("AutoDock-GPU found: %s", resolved)
        return resolved

    candidates = [
        os.path.expanduser("~/.local/bin/adgpu"),
        "/usr/local/bin/adgpu",
    ]
    for c in candidates:
        if os.path.isfile(c) and os.access(c, os.X_OK):
            logger.info("AutoDock-GPU found: %s", c)
            return c

    if not prompt:
        logger.info("AutoDock-GPU not found and prompt=False — skipping install.")
        return None

    if not _confirm(
        "AutoDock-GPU not found. Download GPU-accelerated docking engine "
        "from GitHub (v1.6, ~12 MB)?"
    ):
        return None

    if _detect_cuda():
        import subprocess as _sp

        cuda_ver = "12"
        try:
            nv = _sp.run(["nvidia-smi"], capture_output=True, text=True, timeout=10)
            if "CUDA Version: 11" in nv.stdout:
                cuda_ver = "11"
        except Exception:
            pass
        variant = f"linux_cuda{cuda_ver}"
    else:
        variant = "linux_ocl"

    binary_name, url = _ADGPU_URLS[variant]
    dest_dir = _resolve_install_dir(install_dir)
    logger.info("Downloading AutoDock-GPU %s (%s)...", _ADGPU_VERSION, variant)

    tmp_path: Optional[Path] = None
    try:
        req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
        with urllib.request.urlopen(req, timeout=300) as resp:
            tmp_path = Path(tempfile.mktemp(suffix=".bin"))
            tmp_path.write_bytes(resp.read())

        adgpu_path = dest_dir / "adgpu"
        shutil.copy2(str(tmp_path), str(adgpu_path))
        _make_executable(adgpu_path)
        logger.info(
            "AutoDock-GPU ready: %s (%d MB)",
            adgpu_path,
            adgpu_path.stat().st_size // 1024 // 1024,
        )
        return str(adgpu_path)

    except (
        urllib.error.HTTPError,
        urllib.error.URLError,
        OSError,
    ) as exc:
        logger.warning("Failed to download AutoDock-GPU: %s", exc)
        return None
    finally:
        if tmp_path and tmp_path.exists():
            tmp_path.unlink()
