"""
PDBQT writer for exotic-element ligands.

Converts any RDKit-readable molecular file (.sdf, .mol2, .pdb) to a valid
AutoDock4 PDBQT, handling the full periodic table — replacing AutoDock Tools
(prepare_ligand4.py) which rejects elements like Pt, Ru, B, Si, Ir, Au.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

try:
    from rdkit import Chem
    from rdkit.Chem import AllChem
except ImportError:
    raise ImportError(
        "RDKit is required. Install with: conda install -c conda-forge rdkit"
    )

from .atom_params import compute_gasteiger_charges
from .ligand_reader import _element_to_ad4, _read_mol_rdkit

logger = logging.getLogger(__name__)

# Type alias: per-atom data tuple (name, x, y, z, charge, ad4_type)
_AtomData = Dict[int, Tuple[str, float, float, float, float, str]]


# ---------------------------------------------------------------------------
# PDBQT format
# ---------------------------------------------------------------------------


def _atom_line(
    serial: int, name: str, x: float, y: float, z: float, charge: float, ad4_type: str
) -> str:
    """Return a formatted PDBQT ATOM record (79 chars + newline = 80).

    Column layout (standard PDBQT, columns 1-indexed):
        1-6   record name (ATOM  )
        7-11  serial
        13-16 atom name
        17-20 residue name (LIG)
        22    chain
        23-26 residue number
        31-54 coordinates (x, y, z, 8 cols each)
        55-60 occupancy
        61-66 B-factor
        67-69 padding
        70-76 charge
        78-79 AD4 type
    """
    return (
        f"ATOM  {serial:5d} {name:<4s} LIG A   1    "
        f"{x:8.3f}{y:8.3f}{z:8.3f}  1.00  0.00   "
        f"{charge:7.3f} {ad4_type:<2s}\n"
    )


def _make_atom_names(mol: Chem.Mol, included: List[int]) -> Dict[int, str]:
    """Generate PDBQT atom names: element_UPPER + 1-based counter (≤4 chars)."""
    counts: Dict[str, int] = {}
    names: Dict[int, str] = {}
    for idx in included:
        sym = mol.GetAtomWithIdx(idx).GetSymbol().upper()
        counts[sym] = counts.get(sym, 0) + 1
        names[idx] = f"{sym}{counts[sym]}"[:4]
    return names


# ---------------------------------------------------------------------------
# Charge assignment
# ---------------------------------------------------------------------------


def _gasteiger_charges(mol: Chem.Mol) -> Dict[int, float]:
    """Compute Gasteiger charges (delegates to shared implementation)."""
    return compute_gasteiger_charges(mol)


# ---------------------------------------------------------------------------
# Atom selection
# ---------------------------------------------------------------------------


def _included_atoms(mol: Chem.Mol) -> List[int]:
    """Indices to include in the PDBQT.

    Keeps all heavy atoms plus polar H (bonded to N, O, S → type HD).
    Non-polar H are omitted following AutoDock4 convention.
    """
    out: List[int] = []
    for atom in mol.GetAtoms():
        if atom.GetAtomicNum() == 1:
            parent = next(iter(atom.GetNeighbors()), None)
            if parent and parent.GetAtomicNum() in (7, 8, 16):
                out.append(atom.GetIdx())
        else:
            out.append(atom.GetIdx())
    return out


# ---------------------------------------------------------------------------
# Torsion-tree helpers
# ---------------------------------------------------------------------------


def _rotatable_bond_set(mol: Chem.Mol, included_set: Set[int]) -> Set[FrozenSet[int]]:
    """Single non-ring bonds between non-terminal heavy atoms among included atoms."""
    rot: Set[FrozenSet[int]] = set()
    for bond in mol.GetBonds():
        ai, bi = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        if ai not in included_set or bi not in included_set:
            continue
        a_at = mol.GetAtomWithIdx(ai)
        b_at = mol.GetAtomWithIdx(bi)
        if a_at.GetAtomicNum() == 1 or b_at.GetAtomicNum() == 1:
            continue
        if bond.GetBondTypeAsDouble() != 1.0 or bond.IsInRing():
            continue

        def _hdeg(at: Chem.Atom) -> int:
            return sum(1 for n in at.GetNeighbors() if n.GetAtomicNum() != 1)

        if _hdeg(a_at) < 2 or _hdeg(b_at) < 2:
            continue
        rot.add(frozenset({ai, bi}))
    return rot


def _build_adjacency(mol: Chem.Mol, included_set: Set[int]) -> Dict[int, List[int]]:
    adj: Dict[int, List[int]] = {i: [] for i in included_set}
    for bond in mol.GetBonds():
        a, b = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        if a in included_set and b in included_set:
            adj[a].append(b)
            adj[b].append(a)
    return adj


def _find_root(mol: Chem.Mol, heavy_included: List[int]) -> int:
    """Root = heavy atom with highest heavy-atom connectivity."""

    def _hdeg(idx: int) -> int:
        return sum(
            1 for n in mol.GetAtomWithIdx(idx).GetNeighbors() if n.GetAtomicNum() != 1
        )

    return max(heavy_included, key=_hdeg)


def _bfs_fragment(
    start: int,
    adj: Dict[int, List[int]],
    rot_bonds: Set[FrozenSet[int]],
    excluded: Optional[Set[int]] = None,
) -> List[int]:
    """BFS from *start* without crossing rotatable bonds, skipping *excluded* atoms."""
    blocked: Set[int] = excluded or set()
    visited: Set[int] = {start} | blocked
    queue: List[int] = [start]
    order: List[int] = []
    while queue:
        node = queue.pop(0)
        order.append(node)
        for nb in sorted(adj.get(node, [])):
            if nb in visited:
                continue
            if frozenset({node, nb}) in rot_bonds:
                continue
            visited.add(nb)
            queue.append(nb)
    return order


def _gen_branch(
    from_idx: int,
    to_idx: int,
    adj: Dict[int, List[int]],
    rot_bonds: Set[FrozenSet[int]],
    atom_data: _AtomData,
    serial_map: Dict[int, int],
    counter: List[int],
) -> Tuple[List[str], int]:
    """Write ATOM lines and nested BRANCH blocks for one rotatable bond.

    Returns (lines, n_torsions_in_this_subtree).
    """
    # Identify atoms in this branch fragment (don't go back to already-visited atoms)
    fragment = _bfs_fragment(to_idx, adj, rot_bonds, excluded=set(serial_map.keys()))

    lines: List[str] = []
    n_tors = 0

    # Assign serials and write ATOM lines for fragment atoms
    for idx in fragment:
        serial_map[idx] = counter[0]
        counter[0] += 1
        name, x, y, z, charge, ad4_type = atom_data[idx]
        lines.append(_atom_line(serial_map[idx], name, x, y, z, charge, ad4_type))

    # Recurse into nested rotatable bonds from this fragment
    for f_idx in fragment:
        for t_idx in sorted(adj.get(f_idx, [])):
            if t_idx in serial_map:
                continue
            if frozenset({f_idx, t_idx}) not in rot_bonds:
                continue
            branch_serial = counter[0]
            lines.append(f"BRANCH {serial_map[f_idx]:3d} {branch_serial:3d}\n")
            sub_lines, n_sub = _gen_branch(
                f_idx,
                t_idx,
                adj,
                rot_bonds,
                atom_data,
                serial_map,
                counter,
            )
            lines.extend(sub_lines)
            lines.append(f"ENDBRANCH {serial_map[f_idx]:3d} {serial_map[t_idx]:3d}\n")
            n_tors += 1 + n_sub

    return lines, n_tors


def _build_torsion_tree(
    root: int,
    adj: Dict[int, List[int]],
    rot_bonds: Set[FrozenSet[int]],
    atom_data: _AtomData,
) -> Tuple[List[str], List[str], int]:
    """Two-pass torsion-tree builder.

    Pass 1: BFS to identify root-fragment atoms (no rotatable-bond crossing).
    Pass 2: Assign serials, write ATOM lines, then recurse into branches.

    Returns (root_atom_lines, branch_block_lines, total_torsions).
    """
    serial_map: Dict[int, int] = {}
    counter = [1]

    # Pass 1: root fragment via BFS
    root_fragment = _bfs_fragment(root, adj, rot_bonds)

    # Pass 2a: write root atoms in BFS order
    root_lines: List[str] = []
    for idx in root_fragment:
        serial_map[idx] = counter[0]
        counter[0] += 1
        name, x, y, z, charge, ad4_type = atom_data[idx]
        root_lines.append(_atom_line(serial_map[idx], name, x, y, z, charge, ad4_type))

    # Pass 2b: branches from root fragment
    branch_lines: List[str] = []
    n_tors = 0

    for f_idx in root_fragment:
        for t_idx in sorted(adj.get(f_idx, [])):
            if t_idx in serial_map:
                continue
            if frozenset({f_idx, t_idx}) not in rot_bonds:
                continue
            branch_serial = counter[0]
            branch_lines.append(f"BRANCH {serial_map[f_idx]:3d} {branch_serial:3d}\n")
            sub_lines, n_sub = _gen_branch(
                f_idx,
                t_idx,
                adj,
                rot_bonds,
                atom_data,
                serial_map,
                counter,
            )
            branch_lines.extend(sub_lines)
            branch_lines.append(
                f"ENDBRANCH {serial_map[f_idx]:3d} {serial_map[t_idx]:3d}\n"
            )
            n_tors += 1 + n_sub

    return root_lines, branch_lines, n_tors


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def prepare_pdbqt(
    mol_path: Path,
    output_path: Path,
    base_dat: Optional[Path] = None,
    charge_scheme: str = "auto",
) -> Path:
    """Convert a molecular file to an AutoDock4 PDBQT supporting exotic elements.

    Handles Pt, Ru, B, Si, Ir, Au, and all elements in the UFF table by
    using the element symbol directly as the AD4 type when it is not in the
    standard AD4 set.

    Charge strategy:
        GFN2-xTB (semi-empirical QM) for molecules containing exotic atoms
        (metals, lanthanides, heavy p-block).  Falls back to Gasteiger (RDKit)
        for purely organic molecules, with further fallback to
        formal-charge → lookup table → zero when neither method is available.
        For accurate docking, provide a PDBQT with pre-existing QM/RESP charges.

    Args:
        mol_path:      Input file (.sdf, .mol2, .pdb).
        output_path:   Destination .pdbqt (created or overwritten).
        base_dat:      Reserved; currently unused.
        charge_scheme: Charge computation scheme ("auto", "gasteiger", "xtb").

    Returns:
        output_path.

    Raises:
        ValueError: if the file cannot be parsed or 3D embedding fails.
    """
    mol = _read_mol_rdkit(mol_path)
    if mol is None:
        raise ValueError(
            f"RDKit could not parse '{mol_path.name}'. "
            "Check for unsupported atoms, valence errors, or missing stereo."
        )

    # ── Ensure 3D coordinates ─────────────────────────────────────────────────
    has_3d = mol.GetNumConformers() > 0
    if has_3d:
        mol_h = AllChem.AddHs(mol, addCoords=True)
    else:
        mol_h = AllChem.AddHs(mol)
        status = AllChem.EmbedMolecule(mol_h, AllChem.ETKDGv3())
        if status == -1:
            status = AllChem.EmbedMolecule(mol_h, AllChem.ETKDG())
        if status == -1:
            raise ValueError(
                f"3D embedding failed for '{mol_path.name}'. "
                "Provide an input file with pre-computed 3D coordinates."
            )
        AllChem.MMFFOptimizeMolecule(mol_h)
        logger.info("%s: 3D conformer generated (ETKDGv3 + MMFF).", mol_path.name)

    # ── Atom selection and property assignment ────────────────────────────────
    included = _included_atoms(mol_h)
    included_s = set(included)
    heavy_incl = [i for i in included if mol_h.GetAtomWithIdx(i).GetAtomicNum() != 1]

    if not heavy_incl:
        raise ValueError(f"No heavy atoms found in '{mol_path.name}'.")

    charges = compute_gasteiger_charges(mol_h, scheme=charge_scheme)
    conf = mol_h.GetConformer()
    atom_names = _make_atom_names(mol_h, included)

    # Redistribute non-polar H charges into parent heavy atoms.
    # AutoDock united-atom model removes H not bonded to N/O/S;
    # their partial charges must merge into the parent carbon.
    charges = dict(charges)  # mutable copy
    for atom in mol_h.GetAtoms():
        if atom.GetAtomicNum() == 1 and atom.GetIdx() not in included_s:
            parent = next(iter(atom.GetNeighbors()), None)
            if parent is not None:
                h_q = charges.pop(atom.GetIdx(), 0.0)
                charges[parent.GetIdx()] = charges.get(parent.GetIdx(), 0.0) + h_q

    atom_data: _AtomData = {}
    for idx in included:
        atom = mol_h.GetAtomWithIdx(idx)
        ad4_type = _element_to_ad4(atom.GetSymbol(), atom)
        pos = conf.GetAtomPosition(idx)
        atom_data[idx] = (
            atom_names[idx],
            float(pos.x),
            float(pos.y),
            float(pos.z),
            charges.get(idx, 0.0),
            ad4_type,
        )

    # Verify net charge is conserved after H-removal redistribution
    net_charge = sum(charges.get(i, 0.0) for i in included)
    if abs(net_charge) > 0.01:
        logger.warning(
            "Net charge after H-redistribution: %+.4f (expected ~0). "
            "This may affect electrostatic grid maps.",
            net_charge,
        )

    # ── Torsion tree ──────────────────────────────────────────────────────────
    adj = _build_adjacency(mol_h, included_s)
    rot_bonds = _rotatable_bond_set(mol_h, included_s)
    root = _find_root(mol_h, heavy_incl)

    root_lines, branch_lines, n_tors = _build_torsion_tree(
        root,
        adj,
        rot_bonds,
        atom_data,
    )

    # ── Write file ────────────────────────────────────────────────────────────
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w") as fh:
        fh.write(f"REMARK  OmniGrid pdbqt_writer — {mol_path.name}\n")
        fh.write(
            "REMARK  Charges: GFN2-xTB (exotic atoms) / Gasteiger (organic). See OmniGrid docs.\n"
        )
        fh.write("ROOT\n")
        fh.writelines(root_lines)
        fh.write("ENDROOT\n")
        fh.writelines(branch_lines)
        fh.write(f"TORSDOF {n_tors}\n")

    logger.info(
        "Wrote PDBQT: %s  (%d atoms, %d torsions)",
        output_path,
        len(included),
        n_tors,
    )
    return output_path
