from __future__ import annotations

import sys
from pathlib import Path

if __name__ == "__main__" and __package__ is None:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from omnigrid.cli import main

if __name__ == "__main__":
    sys.exit(main())
