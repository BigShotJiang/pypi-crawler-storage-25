"""
Dynamic AD4_parameters_temp.dat writer.

Strategy (Just-In-Time):
  1. Read the base AD4_parameters.dat (the standard file shipped with AutoDock4).
  2. For each ligand, identify which atom types are NOT in the base file.
  3. Append only those exotic types (UFF-derived) to a fresh temp file.
  4. AutoGrid4 is then invoked with -p AD4_parameters_temp.dat.

This avoids the classic AutoGrid4 buffer-overflow crash caused by loading
the entire periodic table at once.
"""

from __future__ import annotations

import datetime
import logging
from pathlib import Path
from typing import Dict, Optional, Set

from .atom_params import AtomParams, STANDARD_AD4_PARAMS, get_uff_params

logger = logging.getLogger(__name__)

# Free-energy coefficients header required by AutoGrid4 / AutoDock4.
_FE_HEADER = """\
# OmniGrid — dynamic parameter file (Just-In-Time, per-ligand)
# Base: standard AD4_parameters.dat  +  UFF-derived exotic types
#
FE_coeff_vdW    0.1662
FE_coeff_hbond  0.1209
FE_coeff_estat  0.1406
FE_coeff_desolv 0.1322
FE_coeff_tors   0.2983
#
# NAME      Rii       epsii     vol       solpar    Rij_hb    epsij_hb  hbond
"""

_PARAM_LINE_FMT = (
    "atom_par {symbol:<6s} {Rii:>6.4f} {epsii:>7.4f} {vol:>9.4f} "
    "{solpar:>9.6f} {r_hb:>5.1f} {e_hb:>5.1f} {hbond:d}  "
    "{rec_index:d} {map_index:d} {bond_index:d}\n"
)


class UFFAuditLog:
    """Append-only audit trail recording every UFF parameter injection.

    Each call to :meth:`record` writes one line to the log file, making the
    provenance of exotic-atom parameters fully traceable per ligand per run.
    The file is created with a header on first instantiation; subsequent runs
    append to it so the full campaign history is preserved.

    Format (tab-aligned for easy grep / spreadsheet import)::

        <timestamp>  <ligand>  <type>  Rii=<>  epsii=<>  vol=<>  solpar=<>  r_cov=<>  hbond=<>  source=UFF_Rappe1992
    """

    def __init__(self, log_path: Path) -> None:
        self.log_path = log_path
        log_path.parent.mkdir(parents=True, exist_ok=True)
        if not log_path.exists():
            with log_path.open("w") as fh:
                fh.write(
                    "# OmniGrid — UFF Parameter Injection Audit Log\n"
                    f"# Created : {datetime.datetime.now().isoformat(timespec='seconds')}\n"
                    "# Source  : Rappé, A.K. et al. (1992) JACS 114(25):10024-10035\n"
                    "# Columns : timestamp | ligand | ad4_type | Rii(Å) | epsii(kcal/mol) "
                    "| vol(Å³) | solpar | r_cov(Å) | hbond | source\n"
                    f"# {'─' * 76}\n"
                )

    def record(self, ligand_name: str, params: AtomParams) -> None:
        """Append one audit entry (one exotic atom type for one ligand)."""
        ts = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        line = (
            f"{ts}  {ligand_name:<28s}  {params.symbol:<6s}  "
            f"Rii={params.Rii:8.4f}  epsii={params.epsii:8.4f}  "
            f"vol={params.vol:10.4f}  solpar={params.solpar:10.6f}  "
            f"r_cov={params.r_cov:6.4f}  hbond={params.hbond}  "
            "source=UFF_Rappe1992\n"
        )
        with self.log_path.open("a") as fh:
            fh.write(line)


def _format_param_line(p: AtomParams, bond_index: int = 0) -> str:
    return _PARAM_LINE_FMT.format(
        symbol=p.symbol,
        Rii=p.Rii,
        epsii=p.epsii,
        vol=p.vol,
        solpar=p.solpar,
        r_hb=0.0,
        e_hb=0.0,
        hbond=p.hbond,
        rec_index=-1,
        map_index=-1,
        bond_index=bond_index,
    )


def read_base_params(base_dat: Path) -> Dict[str, str]:
    """Parse a base AD4_parameters.dat and return symbol → raw-line mapping.

    Comment lines and free-energy coefficient lines are skipped.
    Returns an empty dict if *base_dat* is None or does not exist (the embedded
    STANDARD_AD4_PARAMS will be used as fallback).
    """
    param_lines: Dict[str, str] = {}
    if base_dat is None or not base_dat.exists():
        logger.warning(
            "Base AD4_parameters.dat not found at '%s'. "
            "Using embedded standard parameters as fallback.",
            base_dat,
        )
        return param_lines

    with base_dat.open() as fh:
        for raw in fh:
            stripped = raw.strip()
            if not stripped or stripped.startswith("#") or stripped.startswith("FE_"):
                continue
            parts = stripped.split()
            if parts:
                param_lines[parts[0]] = raw
    return param_lines


def write_temp_params(
    exotic_types: Set[str],
    dest: Path,
    base_dat: Optional[Path] = None,
    audit_log: Optional[UFFAuditLog] = None,
    ligand_name: str = "unknown",
    needed_types: Optional[Set[str]] = None,
) -> Path:
    """Write *dest* (AD4_parameters_temp.dat) for the current ligand.

    The file contains:
      • Free-energy header
      • Standard AD4 atom types (filtered to *needed_types* when provided)
      • Only the exotic types needed for this specific ligand (UFF-derived, JIT)

    .. note::

       AutoGrid4 is compiled with ``MAX_ATOM_TYPES=14``.  Writing all 22+
       embedded standard types fills the table before exotic types are read,
       causing ``unknown ligand atom type X`` errors.  Always pass
       ``needed_types`` so the parameter file stays below the limit.

    Args:
        exotic_types: Set of exotic AD4 type strings (e.g. {'Pt', 'Ru'}).
        dest:         Destination path for the temp file.
        base_dat:     Optional path to the original AD4_parameters.dat to
                      use as the canonical base instead of the embedded copy.
        audit_log:    Optional :class:`UFFAuditLog` instance. When provided,
                      every injected exotic-type entry is recorded there.
        ligand_name:  Human-readable ligand identifier used in audit log entries.
        needed_types: Set of AD4 types that should be included in the file.
                      When provided, only standard types present in this set
                      are written (keeping total types ≤ MAX_ATOM_TYPES).

    Returns:
        *dest* (for chaining / logging convenience).

    Raises:
        RuntimeError: if UFF parameters are unavailable for a required exotic type.
    """
    base_lines = read_base_params(base_dat) if base_dat else {}

    if needed_types is not None:
        standard_to_write = {
            s: p for s, p in STANDARD_AD4_PARAMS.items() if s in needed_types
        }
    else:
        standard_to_write = dict(STANDARD_AD4_PARAMS)

    with dest.open("w") as out:
        out.write(_FE_HEADER)

        # ── Standard atom types (filtered when needed_types is given) ──────
        for symbol, p in standard_to_write.items():
            if symbol in base_lines:
                out.write(base_lines[symbol])
            else:
                out.write(_format_param_line(p))

        # ── Exotic atom types (JIT, only what this ligand needs) ────────────
        if exotic_types:
            out.write("\n# ── UFF-derived exotic types for this ligand ──\n")

        for ad4_type in sorted(exotic_types):
            params = get_uff_params(ad4_type)
            if params is None:
                raise RuntimeError(
                    f"No UFF parameters available for exotic type '{ad4_type}'. "
                    "Add an entry to atom_params._UFF_RAW or provide a manual override."
                )
            logger.info(
                "  [UFF] %s  Rii=%.4f  epsii=%.4f  vol=%.4f  solpar=%.6f",
                ad4_type,
                params.Rii,
                params.epsii,
                params.vol,
                params.solpar,
            )
            if audit_log is not None:
                audit_log.record(ligand_name, params)
            out.write(_format_param_line(params))

    logger.debug("Wrote temp params to: %s", dest)
    return dest
