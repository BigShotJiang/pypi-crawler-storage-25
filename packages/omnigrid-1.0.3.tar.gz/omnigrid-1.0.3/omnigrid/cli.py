from __future__ import annotations

import argparse
import atexit
import logging
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Optional, Tuple

from rdkit import Chem
from rdkit.Chem import AllChem

from omnigrid.autogrid_installer import ensure_autogrid, ensure_xtb
from omnigrid.pdbqt_writer import prepare_pdbqt
from omnigrid.pipeline import PipelineConfig, process_batch, process_batch_parallel


# ═════════════════════════════════════════════════════════════════════════════
# Legacy (flat) argument parser — used when no subcommand is given
# ═════════════════════════════════════════════════════════════════════════════


def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="omnigrid",
        description="OmniGrid — Just-In-Time AutoGrid4 parameterisation for the full periodic table",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  omnigrid --receptor receptors/target.pdbqt --ligands ligands/ --output results/
  omnigrid --dry-run --receptor rec.pdbqt --ligands lig/ --out res/ --workers 8
""",
    )
    p.add_argument(
        "--receptor", required=True, type=Path, metavar="PDBQT", help="Receptor PDBQT"
    )
    p.add_argument(
        "--ligands", required=True, type=Path, metavar="DIR", help="Ligands directory"
    )
    p.add_argument(
        "--output", required=True, type=Path, metavar="DIR", help="Output directory"
    )
    p.add_argument(
        "--base-dat",
        type=Path,
        default=None,
        metavar="FILE",
        help="Base AD4_parameters.dat",
    )
    p.add_argument(
        "--center",
        type=float,
        nargs=3,
        default=None,
        metavar=("X", "Y", "Z"),
        help="Grid center",
    )
    p.add_argument(
        "--npts",
        type=int,
        nargs=3,
        default=[40, 40, 40],
        metavar=("NX", "NY", "NZ"),
        help="Grid points",
    )
    p.add_argument("--spacing", type=float, default=0.375, help="Grid spacing")
    p.add_argument("--smooth", type=float, default=0.5, help="Smoothing factor")
    p.add_argument("--dielectric", type=float, default=-0.1465, help="Dielectric")
    p.add_argument("--autogrid", default="autogrid4", help="AutoGrid4 executable")
    p.add_argument("--timeout", type=int, default=3600, help="Per-ligand timeout")
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Generate files without running AutoGrid4",
    )
    p.add_argument("--stop-on-error", action="store_true", help="Stop on first error")
    p.add_argument(
        "--extensions",
        nargs="+",
        default=[".sdf", ".mol2", ".pdb", ".pdbqt"],
        help="File extensions",
    )
    p.add_argument("--workers", type=int, default=1, help="Parallel workers")
    p.add_argument("--padding", type=float, default=5.0, help="Grid padding")
    p.add_argument(
        "--audit-log", type=Path, default=None, metavar="FILE", help="Audit log path"
    )
    p.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Log level",
    )
    p.add_argument(
        "--charge-scheme",
        default="auto",
        choices=["auto", "gasteiger", "xtb"],
        help="Charge scheme",
    )
    p.add_argument(
        "--auto-install", action="store_true", default=True, help="Auto-install deps"
    )
    p.add_argument(
        "--no-auto-install",
        dest="auto_install",
        action="store_false",
        help="Skip auto-install",
    )
    return p.parse_args(argv)


def legacy_main(argv: Optional[list[str]] = None) -> int:
    import warnings

    warnings.warn(
        "Flat CLI (omnigrid --receptor ...) is deprecated. "
        "Use `omnigrid screen --receptor ...` instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    args = parse_args(argv)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )

    errors: list[str] = []
    if not args.receptor.exists():
        errors.append(f"Receptor not found: {args.receptor}")
    if not args.ligands.is_dir():
        errors.append(f"Ligands directory not found: {args.ligands}")
    if args.base_dat and not args.base_dat.exists():
        errors.append(f"Base AD4_parameters.dat not found: {args.base_dat}")
    if errors:
        for e in errors:
            print(f"ERROR: {e}", file=sys.stderr)
        return 1

    args.output.mkdir(parents=True, exist_ok=True)

    if args.auto_install:
        try:
            resolved = ensure_autogrid(args.autogrid, prompt=True)
            args.autogrid = resolved
        except RuntimeError:
            pass
        ensure_xtb(prompt=True)

    center: Optional[Tuple[float, float, float]] = (
        tuple(args.center) if args.center else None
    )

    cfg = PipelineConfig(
        receptor_pdbqt=args.receptor,
        ligands_dir=args.ligands,
        output_dir=args.output,
        base_dat=args.base_dat,
        center=center,
        npts=tuple(args.npts),
        spacing=args.spacing,
        smooth=args.smooth,
        dielectric=args.dielectric,
        grid_padding=args.padding,
        audit_log_path=args.audit_log,
        autogrid_bin=args.autogrid,
        timeout=args.timeout,
        dry_run=args.dry_run,
        auto_install=args.auto_install,
        stop_on_error=args.stop_on_error,
        extensions=tuple(args.extensions),
        charge_scheme=args.charge_scheme,
    )

    if args.workers > 1:
        results = process_batch_parallel(cfg, n_workers=args.workers)
    else:
        results = process_batch(cfg)

    failed = [r for r in results if not r.success]
    if failed:
        print("\nFailed ligands:")
        for r in failed:
            print(f"  {r.ligand.name}: {r.error}")
        return 2

    succeeded = len(results) - len(failed)
    print(f"\nDone: {succeeded}/{len(results)} ligands processed successfully.")
    return 0


# ═════════════════════════════════════════════════════════════════════════════
# Subcommands
# ═════════════════════════════════════════════════════════════════════════════


def _smiles_to_sdf(smiles: str, output_path: Path) -> Path:
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Invalid SMILES: {smiles}")
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())
    AllChem.MMFFOptimizeMolecule(mol)
    writer = Chem.SDWriter(str(output_path))
    writer.write(mol)
    writer.close()
    return output_path


_temp_dirs: list[Path] = []


def _cleanup_temp_dirs() -> None:
    for d in _temp_dirs:
        shutil.rmtree(d, ignore_errors=True)


atexit.register(_cleanup_temp_dirs)


def _resolve_input(input_str: str) -> Path:
    p = Path(input_str)
    if p.exists():
        return p
    tmp_dir = Path(tempfile.mkdtemp())
    _temp_dirs.append(tmp_dir)
    tmp = tmp_dir / "mol.sdf"
    _smiles_to_sdf(input_str, tmp)
    return tmp


def _build_convert_parser(subparsers) -> None:
    p = subparsers.add_parser("convert", help="Convert molecule to PDBQT")
    p.add_argument("input", help="SMILES string or path to SDF/MOL2/PDB/MOL/XYZ")
    p.add_argument("-o", "--output", type=Path, default=None, help="Output PDBQT path")
    p.add_argument(
        "--charge-method",
        default="auto",
        choices=["auto", "xtb", "gasteiger", "formal", "lookup", "none"],
        help="Charge method",
    )
    p.add_argument(
        "--xtb", action="store_true", help="Shortcut for --charge-method xtb"
    )
    p.add_argument(
        "--keep-fragments",
        action="store_true",
        help="Keep non-ligand molecules (experimental)",
    )
    p.add_argument(
        "--dock",
        action="store_true",
        help="Run AutoGrid4 + AutoDock-GPU after conversion (requires --receptor)",
    )
    p.add_argument(
        "-r",
        "--receptor",
        type=Path,
        default=None,
        help="Receptor PDBQT (required for --dock)",
    )
    p.add_argument("--center-x", type=float, dest="center_x", help="Grid center X")
    p.add_argument("--center-y", type=float, dest="center_y", help="Grid center Y")
    p.add_argument("--center-z", type=float, dest="center_z", help="Grid center Z")
    p.add_argument(
        "--size-x", type=float, default=22.5, dest="size_x", help="Grid size X"
    )
    p.add_argument(
        "--size-y", type=float, default=22.5, dest="size_y", help="Grid size Y"
    )
    p.add_argument(
        "--size-z", type=float, default=22.5, dest="size_z", help="Grid size Z"
    )
    p.add_argument(
        "--gpu-accel", action="store_true", help="Use GPU-accelerated docking"
    )
    p.add_argument("--n-mc-runs", type=int, default=20, help="MC runs per ligand")
    p.add_argument("--seed", type=int, default=42, help="Random seed")
    p.add_argument("-v", "--verbose", action="store_true", help="Verbose output")


def _build_screen_parser(subparsers) -> None:
    p = subparsers.add_parser(
        "screen", help="Screen multiple ligands (AutoGrid4 pipeline)"
    )
    p.add_argument("-r", "--receptor", type=Path, required=True, help="Receptor PDBQT")
    p.add_argument(
        "-l", "--ligands", type=Path, required=True, help="Ligands directory"
    )
    p.add_argument("-o", "--output", type=Path, required=True, help="Output directory")
    p.add_argument("--center-x", type=float, dest="center_x", help="Grid center X")
    p.add_argument("--center-y", type=float, dest="center_y", help="Grid center Y")
    p.add_argument("--center-z", type=float, dest="center_z", help="Grid center Z")
    p.add_argument(
        "--size-x", type=float, default=22.5, dest="size_x", help="Grid size X"
    )
    p.add_argument(
        "--size-y", type=float, default=22.5, dest="size_y", help="Grid size Y"
    )
    p.add_argument(
        "--size-z", type=float, default=22.5, dest="size_z", help="Grid size Z"
    )
    p.add_argument("--spacing", type=float, default=0.375, help="Grid spacing")
    p.add_argument("--smooth", type=float, default=0.5, help="Smoothing factor")
    p.add_argument(
        "--dielectric", type=float, default=-0.1465, help="Dielectric constant"
    )
    p.add_argument(
        "--max-workers", type=int, default=4, dest="workers", help="Parallel workers"
    )
    p.add_argument(
        "--npts",
        type=int,
        nargs=3,
        default=[40, 40, 40],
        metavar=("NX", "NY", "NZ"),
        help="Grid points",
    )
    p.add_argument("--padding", type=float, default=5.0, help="Grid padding")
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Generate files without running AutoGrid4",
    )
    p.add_argument("--stop-on-error", action="store_true", help="Stop on first error")
    p.add_argument("--xtb", action="store_true", help="Use GFN2-xTB charges")
    p.add_argument(
        "--charge-scheme",
        default="auto",
        choices=["auto", "gasteiger", "xtb"],
        help="Charge scheme",
    )
    p.add_argument(
        "--gpu",
        action="store_true",
        help="GPU-accelerated docking (requires AutoDock-GPU)",
    )
    p.add_argument(
        "--n-mc-runs", type=int, default=20, dest="n_mc_runs", help="MC runs per ligand"
    )
    p.add_argument("--rescore", action="store_true", help="Rescore only (no docking)")
    p.add_argument("-v", "--verbose", action="store_true", help="Verbose output")


def _build_setup_parser(subparsers) -> None:
    p = subparsers.add_parser("setup", help="Install dependencies")
    p.add_argument("--xtb", action="store_true", help="Install GFN2-xTB (~61 MB)")
    p.add_argument("--all", action="store_true", help="Install xtb and all extras")
    p.add_argument("--autogrid", action="store_true", help="Install AutoGrid4 only")


def _build_info_parser(subparsers) -> None:
    subparsers.add_parser("info", help="Show system information")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="omnigrid",
        description="OmniGrid: Just-in-Time AutoGrid4 Parameterization for 61 Elements via UFF",
    )
    subparsers = parser.add_subparsers(dest="command", title="subcommands")
    _build_convert_parser(subparsers)
    _build_screen_parser(subparsers)
    _build_setup_parser(subparsers)
    _build_info_parser(subparsers)
    return parser


def cmd_convert(args: argparse.Namespace) -> int:
    charge_scheme = "xtb" if args.xtb else args.charge_method
    if charge_scheme == "none":
        charge_scheme = "auto"

    input_path = _resolve_input(args.input)
    output = args.output or input_path.with_suffix(".pdbqt")

    prepare_pdbqt(input_path, output, charge_scheme=charge_scheme)
    print(f"PDBQT written to {output}")

    if args.dock:
        if not args.receptor:
            print("ERROR: --dock requires --receptor", file=sys.stderr)
            return 1

        from .gpf_generator import auto_grid_box, detect_receptor_types
        from .params_writer import write_temp_params
        from .runner import run_autogrid

        work = output.parent
        stem = output.stem
        receptor = args.receptor

        ligand_pdbqt = output

        rec_types = detect_receptor_types(receptor)

        from .ligand_reader import extract_atom_types

        all_types, exotic_types = extract_atom_types(ligand_pdbqt)
        needed_types = set(all_types) | set(rec_types)

        temp_dat = work / "AD4_parameters_temp.dat"
        write_temp_params(
            exotic_types,
            temp_dat,
            audit_log=None,
            ligand_name=stem,
            needed_types=needed_types,
        )

        center: Optional[Tuple[float, float, float]] = None
        if args.center_x is not None:
            center = (args.center_x, args.center_y or 0, args.center_z or 0)

        if center:
            grid_center = center
            grid_npts = (
                int(args.size_x / 0.375),
                int(args.size_y / 0.375),
                int(args.size_z / 0.375),
            )
        else:
            grid_center, grid_npts = auto_grid_box(
                ligand_pdbqt, padding=5.0, spacing=0.375
            )

        from .gpf_generator import GridConfig, generate_gpf

        grid_cfg = GridConfig(
            receptor_pdbqt=receptor,
            receptor_types=rec_types,
            ligand_pdbqt=ligand_pdbqt,
            temp_params_dat=temp_dat,
            center=grid_center,
            npts=grid_npts,
            spacing=0.375,
        )
        gpf_path = work / f"{stem}.gpf"
        generate_gpf(all_types, grid_cfg, gpf_path)

        run_autogrid(gpf_path, "autogrid4", work_dir=work, auto_install=True)

        from .runner import run_adgpu

        prefix = receptor.stem
        dlg = run_adgpu(
            ligand_pdbqt=ligand_pdbqt,
            maps_prefix=prefix,
            output_prefix=stem,
            work_dir=work,
            n_runs=args.n_mc_runs,
            seed=args.seed,
            auto_install=True,
        )
        print(f"Docking complete: {dlg}")

    return 0


def cmd_screen(args: argparse.Namespace) -> int:
    log_level = "DEBUG" if args.verbose else "INFO"
    logging.basicConfig(
        level=getattr(logging, log_level),
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )

    if not args.receptor.exists():
        print(f"ERROR: Receptor not found: {args.receptor}", file=sys.stderr)
        return 1
    if not args.ligands.is_dir():
        print(f"ERROR: Ligands directory not found: {args.ligands}", file=sys.stderr)
        return 1

    args.output.mkdir(parents=True, exist_ok=True)

    center: Optional[Tuple[float, float, float]] = None
    if args.center_x is not None:
        center = (args.center_x, args.center_y or 0, args.center_z or 0)

    npts = tuple(args.npts)

    charge_scheme = "xtb" if args.xtb else args.charge_scheme

    cfg = PipelineConfig(
        receptor_pdbqt=args.receptor,
        ligands_dir=args.ligands,
        output_dir=args.output,
        center=center,
        npts=npts,
        spacing=args.spacing,
        smooth=args.smooth,
        dielectric=args.dielectric,
        grid_padding=args.padding,
        dry_run=args.dry_run,
        stop_on_error=args.stop_on_error,
        charge_scheme=charge_scheme,
        do_dock=args.gpu,
        adgpu_bin="adgpu",
        n_mc_runs=args.n_mc_runs,
        seed=42,
    )

    if args.workers and args.workers > 1:
        results = process_batch_parallel(cfg, n_workers=args.workers)
    else:
        results = process_batch(cfg)

    failed = [r for r in results if not r.success]
    if failed:
        print("\nFailed ligands:")
        for r in failed:
            print(f"  {r.ligand.name}: {r.error}")
        return 2

    succeeded = len(results) - len(failed)
    print(f"\nDone: {succeeded}/{len(results)} ligands processed successfully.")
    return 0


def cmd_setup(args: argparse.Namespace) -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )

    print("=" * 55)
    print("  OmniGrid Setup")
    print("=" * 55)

    if args.autogrid or args.all:
        try:
            resolved = ensure_autogrid(prompt=True)
            print(f"  ✓ AutoGrid4: {resolved}")
        except RuntimeError as exc:
            print(f"  ✗ AutoGrid4: {exc}")

    if args.xtb or args.all:
        xtb_path = ensure_xtb(prompt=True)
        if xtb_path:
            print(f"  ✓ xtb: {xtb_path}")

    if not args.autogrid and not args.xtb and not args.all:
        try:
            resolved = ensure_autogrid(prompt=True)
            print(f"  ✓ AutoGrid4: {resolved}")
        except RuntimeError as exc:
            print(f"  ✗ AutoGrid4: {exc}")
        xtb_path = ensure_xtb(prompt=True)
        if xtb_path:
            print(f"  ✓ xtb: {xtb_path}")

    print()
    return 0


def cmd_info(args: argparse.Namespace) -> int:
    import omnigrid

    try:
        import rdkit

        rdkit_ver = rdkit.__version__
    except Exception:
        rdkit_ver = "?"
    try:
        import numpy  # type: ignore[import-untyped]

        np_ver = numpy.__version__
    except ImportError:
        np_ver = "n/a (optional)"

    print(f"OmniGrid   v{omnigrid.__version__}")
    print(f"RDKit      {rdkit_ver}")
    print(f"NumPy      {np_ver}")
    print(f"AutoGrid4  {shutil.which('autogrid4') or 'not found'}")
    print(f"xtb        {ensure_xtb(prompt=False) or 'not found'}")
    print(f"Python     {sys.version.split()[0]}")
    return 0


# ═════════════════════════════════════════════════════════════════════════════
# Entry point
# ═════════════════════════════════════════════════════════════════════════════


def main(argv: Optional[list[str]] = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    if not argv:
        build_parser().print_help()
        return 0

    # Dispatch to legacy if no subcommand is given
    if argv[0] not in ("convert", "screen", "setup", "info"):
        return legacy_main(argv)

    parser = build_parser()
    args = parser.parse_args(argv)

    commands = {
        "convert": cmd_convert,
        "screen": cmd_screen,
        "setup": cmd_setup,
        "info": cmd_info,
    }
    return commands[args.command](args)
