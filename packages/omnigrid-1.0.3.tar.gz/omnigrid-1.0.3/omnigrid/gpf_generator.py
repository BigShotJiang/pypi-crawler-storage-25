"""
AutoGrid4 .gpf (Grid Parameter File) generator.

Generates a .gpf that references:
  - The receptor PDBQT
  - The per-ligand temp parameter file (AD4_parameters_temp.dat)
  - Only the atom-type maps strictly required for the current ligand
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


@dataclass
class GridConfig:
    """All grid parameters needed to generate a .gpf from scratch."""

    receptor_pdbqt: Path
    receptor_types: List[str]  # AD4 types present in the receptor
    ligand_pdbqt: Path
    temp_params_dat: Path  # path to AD4_parameters_temp.dat
    center: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    npts: Tuple[int, int, int] = (40, 40, 40)
    spacing: float = 0.375
    smooth: float = 0.5
    dielectric: float = -0.1465
    # output prefix for map files (defaults to receptor stem)
    map_prefix: Optional[str] = None

    def __post_init__(self) -> None:
        if self.map_prefix is None:
            self.map_prefix = self.receptor_pdbqt.stem


def generate_gpf(
    ligand_types: Set[str],
    config: GridConfig,
    dest: Path,
) -> Path:
    """Write a .gpf file for AutoGrid4.

    Args:
        ligand_types:  All AD4 atom types present in the ligand (standard + exotic).
        config:        Grid configuration (receptor, dimensions, spacing, …).
        dest:          Destination path for the .gpf file.

    Returns:
        *dest* for chaining.
    """
    prefix = config.map_prefix
    cx, cy, cz = config.center
    nx, ny, nz = config.npts
    types_str = " ".join(sorted(ligand_types))
    rec_types = " ".join(sorted(set(config.receptor_types)))

    lines: List[str] = [
        f"# OmniGrid — generated .gpf for ligand: {config.ligand_pdbqt.name}\n",
        f"parameter_file {config.temp_params_dat.name}\n",
        "\n",
        f"npts {nx} {ny} {nz}\n",
        f"gridfld {prefix}.maps.fld\n",
        f"spacing {config.spacing:.4f}\n",
        f"receptor_types {rec_types}\n",
        f"ligand_types {types_str}\n",
        f"receptor {config.receptor_pdbqt.name}\n",
        f"gridcenter {cx:.4f} {cy:.4f} {cz:.4f}\n",
        f"smooth {config.smooth}\n",
    ]

    # One affinity-map line per ligand atom type
    for ad4_type in sorted(ligand_types):
        lines.append(f"map {prefix}.{ad4_type}.map\n")

    lines += [
        f"elecmap {prefix}.e.map\n",
        f"dsolvmap {prefix}.d.map\n",
        f"dielectric {config.dielectric}\n",
    ]

    dest.write_text("".join(lines))
    logger.debug("Wrote GPF: %s  ligand_types=[%s]", dest, types_str)
    return dest


def detect_receptor_types(receptor_pdbqt: Path) -> List[str]:
    """Parse the receptor PDBQT and return the unique AD4 atom types found."""
    types: Set[str] = set()
    with receptor_pdbqt.open() as fh:
        for line in fh:
            if line.startswith(("ATOM", "HETATM")):
                parts = line.split()
                if parts:
                    types.add(parts[-1].strip())
    return sorted(types)


def auto_grid_box(
    ligand_path: Path,
    padding: float = 5.0,
    spacing: float = 0.375,
) -> Tuple[Tuple[float, float, float], Tuple[int, int, int]]:
    """Compute grid centre and npts from the ligand axis-aligned bounding box.

    The centre is the midpoint of the bounding box (not the centroid).
    This ensures the grid fully encloses the ligand even for elongated molecules.

    npts per axis = ceil((extent + 2 × padding) / spacing), rounded up to
    the nearest even integer (AutoGrid4 requires even npts values).

    Args:
        ligand_path: PDBQT or PDB file whose ATOM/HETATM records are parsed.
        padding:     Extra margin beyond the bounding box on each face (Å).
                     Default 5.0 Å as recommended for AutoDock workflows.
        spacing:     Grid point spacing in Å — must match GridConfig.spacing.

    Returns:
        (center_xyz, npts_xyz) ready to drop into GridConfig.
    """
    xs: List[float] = []
    ys: List[float] = []
    zs: List[float] = []

    with ligand_path.open() as fh:
        for line in fh:
            if not line.startswith(("ATOM", "HETATM")):
                continue
            try:
                x = float(line[30:38])
                y = float(line[38:46])
                z = float(line[46:54])
            except ValueError:
                continue
            if max(abs(x), abs(y), abs(z)) > 1e4:
                logger.warning(
                    "Suspicious coordinate (%.2f, %.2f, %.2f) in %s — skipping.",
                    x,
                    y,
                    z,
                    ligand_path.name,
                )
                continue
            xs.append(x)
            ys.append(y)
            zs.append(z)

    if not xs:
        logger.warning(
            "No valid coordinates found in %s — returning default box (0,0,0)/(40,40,40).",
            ligand_path.name,
        )
        return (0.0, 0.0, 0.0), (40, 40, 40)

    def _axis(coords: List[float]) -> Tuple[float, int]:
        lo, hi = min(coords), max(coords)
        centre = round((lo + hi) / 2.0, 4)
        n = math.ceil((hi - lo + 2.0 * padding) / spacing)
        if n % 2 != 0:
            n += 1
        return centre, max(n, 2)

    cx, nx = _axis(xs)
    cy, ny = _axis(ys)
    cz, nz = _axis(zs)

    logger.debug(
        "auto_grid_box %s: centre=(%.3f, %.3f, %.3f)  npts=(%d, %d, %d)  padding=%.1f Å",
        ligand_path.name,
        cx,
        cy,
        cz,
        nx,
        ny,
        nz,
        padding,
    )
    return (cx, cy, cz), (nx, ny, nz)


def center_from_ligand(ligand_pdbqt: Path) -> Tuple[float, float, float]:
    """Compute the geometric centre of a ligand from its PDBQT coordinates."""
    xs, ys, zs = [], [], []
    with ligand_pdbqt.open() as fh:
        for line in fh:
            if not line.startswith(("ATOM", "HETATM")):
                continue
            try:
                x = float(line[30:38])
                y = float(line[38:46])
                z = float(line[46:54])
            except ValueError:
                continue
            if max(abs(x), abs(y), abs(z)) > 1e4:
                logger.warning(
                    "Suspicious coordinate (%.2f, %.2f, %.2f) in %s — skipping.",
                    x,
                    y,
                    z,
                    ligand_pdbqt.name,
                )
                continue
            xs.append(x)
            ys.append(y)
            zs.append(z)
    if not xs:
        logger.warning(
            "No valid coordinates found in %s — using (0,0,0) as grid centre.",
            ligand_pdbqt.name,
        )
        return (0.0, 0.0, 0.0)
    return (
        round(sum(xs) / len(xs), 4),
        round(sum(ys) / len(ys), 4),
        round(sum(zs) / len(zs), 4),
    )
