"""
Ligand reader: extracts AD4 atom types from molecular files using RDKit.

Supported formats: .sdf, .mol2, .pdb, .pdbqt
For .pdbqt the atom types are read directly from column 77+ (AD4 convention).
For other formats RDKit parses the structure and elements are mapped to AD4 types.

Charge handling:
  - .pdbqt: columns 71-76 hold the partial charge. If any atom carries a
    non-zero value the file is flagged as pre-charged (e.g. from QM/RESP)
    and the charges are preserved verbatim.
  - Other formats: Gasteiger charges are computed via RDKit as a fallback,
    so downstream PDBQT preparation tools receive a reasonable starting point.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

try:
    from rdkit import Chem
    from rdkit.Chem import AllChem
except ImportError:
    raise ImportError(
        "RDKit is required. Install with: conda install -c conda-forge rdkit"
    )

from .atom_params import (
    ELEMENT_TO_AD4_TYPE,
    compute_gasteiger_charges,
    is_exotic,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

AtomTypeSet = Set[str]  # set of AD4 atom-type strings for one ligand


@dataclass
class ChargeInfo:
    """Partial-charge metadata returned by :func:`extract_charges`.

    Attributes:
        source:    'pdbqt_preexisting' | 'gasteiger' | 'none'
        preserved: True when charges originated from the input file (not recomputed).
        charges:   atom serial (PDBQT) or atom index (RDKit) → partial charge.
    """

    source: str
    preserved: bool
    charges: Dict[int, float] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _detect_pdbqt_charges(path: Path) -> Tuple[bool, Dict[int, float]]:
    """Parse columns 70-76 of a PDBQT file for partial charges.

    Returns (has_nonzero_charges, {atom_serial: charge}).
    A charge is considered "significant" when |q| > 1e-4.
    """
    charges: Dict[int, float] = {}
    with path.open() as fh:
        for line in fh:
            if not line.startswith(("ATOM", "HETATM")):
                continue
            try:
                serial = int(line[6:11])
                charge_str = line[69:76].strip()
                if charge_str:
                    charges[serial] = float(charge_str)
            except (ValueError, IndexError):
                continue
    has_nonzero = any(abs(q) > 1e-4 for q in charges.values())
    return has_nonzero, charges


def _compute_gasteiger(mol: "Chem.Mol") -> Dict[int, float]:
    """Compute Gasteiger partial charges via RDKit (wrapper around shared implementation)."""
    mol_h = AllChem.AddHs(mol)
    return compute_gasteiger_charges(mol_h)


def _element_to_ad4(element: str, atom: Optional["Chem.Atom"] = None) -> str:
    """Map an RDKit element symbol to an AD4 atom-type string.

    Exotic elements are returned unchanged (they become their own type).
    Standard elements fall back to their canonical AD4 type.
    """
    if is_exotic(element):
        return element  # e.g. 'Pt', 'Ru', 'B', 'Si'

    # For standard elements, refine by hybridisation / H-bond role if possible.
    if atom is not None:
        if element == "C":
            return "A" if atom.GetIsAromatic() else "C"
        if element == "N":
            # donor if has H neighbours
            has_h = any(n.GetAtomicNum() == 1 for n in atom.GetNeighbors())
            return "N" if not atom.GetIsAromatic() and not has_h else "NA"
        if element == "O":
            return "OA"
        if element == "S":
            return (
                "SA"
                if any(n.GetSymbol() in ("O", "N") for n in atom.GetNeighbors())
                else "S"
            )
        if element == "H":
            # HD for H on heteroatom
            parent = next(iter(atom.GetNeighbors()), None)
            if parent and parent.GetAtomicNum() in (7, 8, 16):
                return "HD"
            return "H"

    return ELEMENT_TO_AD4_TYPE.get(element, element)


def _read_mol_rdkit(path: Path) -> Optional["Chem.Mol"]:
    """Load a molecule with RDKit, trying several sanitisation strategies."""
    suffix = path.suffix.lower()
    mol: Optional[Chem.Mol] = None

    try:
        if suffix == ".sdf" or suffix == ".mol":
            mol = Chem.MolFromMolFile(str(path), removeHs=False, sanitize=True)
            if mol is None:
                mol = Chem.MolFromMolFile(str(path), removeHs=False, sanitize=False)
        elif suffix == ".mol2":
            mol = Chem.MolFromMol2File(str(path), removeHs=False, sanitize=True)
            if mol is None:
                mol = Chem.MolFromMol2File(str(path), removeHs=False, sanitize=False)
        elif suffix in (".pdb", ".ent"):
            mol = Chem.MolFromPDBFile(str(path), removeHs=False, sanitize=True)
            if mol is None:
                mol = Chem.MolFromPDBFile(str(path), removeHs=False, sanitize=False)
        else:
            logger.warning(
                "Unsupported format '%s' for RDKit reader: %s", suffix, path.name
            )
    except Exception as exc:
        logger.warning("RDKit raised an exception reading %s: %s", path.name, exc)

    return mol


def _parse_pdbqt_types(path: Path) -> AtomTypeSet:
    """Extract AD4 atom types from a PDBQT file (column 78–79 convention)."""
    types: AtomTypeSet = set()
    with path.open() as fh:
        for line in fh:
            if not line.startswith(("ATOM", "HETATM")):
                continue
            # AD4 atom type occupies the last non-whitespace field
            parts = line.split()
            if parts:
                ad4_type = parts[-1].strip()
                if ad4_type and not ad4_type.startswith(
                    ("ROOT", "ENDROOT", "BRANCH", "ENDBRANCH", "TORSDOF")
                ):
                    types.add(ad4_type)
    return types


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def extract_atom_types(path: Path) -> Tuple[AtomTypeSet, AtomTypeSet]:
    """Return (all_ad4_types, exotic_ad4_types) for the ligand at *path*.

    For .pdbqt files the types are read verbatim from the file.
    For other formats RDKit assigns them based on element and hybridisation.

    Raises:
        ValueError: if the file cannot be parsed by any strategy.
    """
    suffix = path.suffix.lower()

    if suffix == ".pdbqt":
        all_types = _parse_pdbqt_types(path)
        if not all_types:
            raise ValueError(f"No ATOM/HETATM records with atom types found in: {path}")
        exotic_types = {t for t in all_types if is_exotic(t)}
        return all_types, exotic_types

    # RDKit path
    mol = _read_mol_rdkit(path)
    if mol is None:
        raise ValueError(
            f"RDKit could not parse '{path.name}'. "
            "Check for unsupported atom types, missing charge information, or valence errors."
        )

    all_types: AtomTypeSet = set()
    for atom in mol.GetAtoms():
        element = atom.GetSymbol()
        if element == "*":
            logger.warning("Wildcard atom '*' in %s — skipping.", path.name)
            continue
        ad4_type = _element_to_ad4(element, atom)
        all_types.add(ad4_type)

    exotic_types = {t for t in all_types if is_exotic(t)}
    return all_types, exotic_types


def extract_charges(
    path: Path,
    compute_gasteiger_fallback: bool = True,
) -> ChargeInfo:
    """Detect and return partial-charge information for the ligand at *path*.

    Strategy by format:

    *.pdbqt*
        Reads columns 70-76 for each ATOM/HETATM record.
        • Non-zero charges → ``ChargeInfo(source='pdbqt_preexisting', preserved=True)``.
          The caller should pass the file to AutoDock as-is without recharging.
        • All-zero charges → ``ChargeInfo(source='none', preserved=False)``.
          The file was prepared without QM charges; an external tool (Meeko, RDKit)
          should add Gasteiger charges before docking.

    *SDF / MOL2 / PDB*
        • ``compute_gasteiger_fallback=True`` → charges computed via the
          ``compute_gasteiger_charges`` cascade, which **uses GFN2-xTB (QM)
          when exotic atoms are detected** and falls back to RDKit Gasteiger
          for purely organic molecules.
        • ``compute_gasteiger_fallback=False`` → returns ``source='none'``.
    """
    suffix = path.suffix.lower()

    if suffix == ".pdbqt":
        has_charges, charges = _detect_pdbqt_charges(path)
        if has_charges:
            logger.info(
                "%s: pre-existing partial charges detected (QM/RESP origin assumed) "
                "— preserving without modification.",
                path.name,
            )
            return ChargeInfo(
                source="pdbqt_preexisting", preserved=True, charges=charges
            )
        logger.debug(
            "%s: no significant charges in PDBQT — treating as uncharged.", path.name
        )
        return ChargeInfo(source="none", preserved=False, charges=charges)

    # ── Non-PDBQT: optional Gasteiger fallback ───────────────────────────────
    if not compute_gasteiger_fallback:
        return ChargeInfo(source="none", preserved=False)

    mol = _read_mol_rdkit(path)
    if mol is None:
        logger.warning(
            "%s: RDKit parse failed — cannot compute Gasteiger charges.", path.name
        )
        return ChargeInfo(source="none", preserved=False)

    charges = _compute_gasteiger(mol)
    if charges:
        logger.info(
            "%s: charges computed for %d atoms (method: Gasteiger/xtb cascade).",
            path.name,
            len(charges),
        )
        return ChargeInfo(source="gasteiger", preserved=False, charges=charges)

    return ChargeInfo(source="none", preserved=False)


def list_ligand_files(
    folder: Path, extensions: Tuple[str, ...] = (".sdf", ".mol2", ".pdb", ".pdbqt")
) -> List[Path]:
    """Recursively collect ligand files with the given extensions from *folder*."""
    files: List[Path] = []
    for ext in extensions:
        files.extend(sorted(folder.rglob(f"*{ext}")))
    return files
