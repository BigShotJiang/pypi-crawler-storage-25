"""OmniGrid: Just-In-Time AutoGrid4/AutoDock-GPU parameterization for 61 elements via UFF."""

__version__ = "1.0.3"
__authors__ = [
    "Cleiton Augusto Correa Bezerra",
    "Fernando Berton Zanchi",
]
__author__ = ", ".join(__authors__)
__email__ = "augusto.cleiton@gmail.com, fernando.zanchi@fiocruz.br"
__orcid__ = "https://orcid.org/0009-0003-5543-8026"
__orcid_zanchi = "https://orcid.org/0000-0003-3386-0069"
__license__ = "MIT OR Apache-2.0"
__url__ = "https://github.com/cleitonaugusto/OmniGrid"


def description() -> None:
    """Print description of OmniGrid."""
    print(__doc__)


def authors() -> None:
    """Print authors of OmniGrid."""
    print("OmniGrid authors:")
    print(f"  1. {__authors__[0]} — {__orcid__}")
    print(f"  2. {__authors__[1]} — {__orcid_zanchi}")


def cite() -> None:
    """Print citation information for OmniGrid.

    Call this function to get the references needed when publishing results
    obtained with OmniGrid.

    Example::

        import omnigrid
        omnigrid.cite()
    """
    print(
        "\n"
        "=" * 65 + "\n"
        " OmniGrid — Como Citar / How to Cite\n"
        "=" * 65 + "\n"
        "\n"
        "Se você usar OmniGrid em uma publicação, por favor cite:\n"
        "If you use OmniGrid in a publication, please cite:\n"
        "\n"
        "  [1] Bezerra, C. A. C. (2026). OmniGrid: Pipeline de triagem\n"
        "      virtual de alta escala com parametrização just-in-time\n"
        "      para 61 elementos via UFF (v1.0.1) [Software].\n"
        "      GitHub. https://github.com/cleitonaugusto/OmniGrid\n"
        "      ORCID: https://orcid.org/0009-0003-5543-8026\n"
        "\n"
        "  [2] Rappé, A. K. et al. UFF, a full periodic table force\n"
        "      field for molecular mechanics and molecular dynamics\n"
        "      simulations. J. Am. Chem. Soc. 1992, 114, 10024-10035.\n"
        "      DOI: 10.1021/ja00051a040\n"
        "\n"
        "BibTeX e ABNT disponíveis em: README.md e CITATION.cff\n"
        "=" * 65 + "\n"
    )
