"""
Receptor preparer: converts PDB → PDBQT via RDKit with hydrogens and charges.

Replaces MGLTools (prepare_receptor4.py) and Open Babel entirely.
Uses RDKit to add hydrogens, assigns charges from pre-computed residue
tables (standard amino acids) with Gasteiger fallback for HETATM/cofactors.

Charge strategy:
    • Standard residues (ALA…VAL, HIS variants) → pre-computed charges
      from residue_charges.py (validated vs Gasteiger on sanitized templates).
    • HETATM / cofactors / metals → Gasteiger via RDKit, fallback to 0.000
      with explicit WARNING listing affected atoms.

Usage:
    from omnigrid.receptor_preparer import prepare_receptor
    prepare_receptor(Path("3ZNT.pdb"), Path("3ZNT.pdbqt"))
"""

from __future__ import annotations

import logging
import math
from pathlib import Path
from typing import Dict, List

try:
    from rdkit import Chem
    from rdkit.Chem import AllChem
except ImportError:
    raise ImportError(
        "RDKit is required. Install with: conda install -c conda-forge rdkit"
    )

from .atom_params import ELEMENT_TO_AD4_TYPE
from .residue_charges import get_hetatm_charges, get_residue_charges

logger = logging.getLogger(__name__)

_HETATM_SKIP: frozenset = frozenset(
    {
        # Waters
        "HOH",
        "WAT",
        "DOD",
        # Monatomic ions
        "NA",
        "CL",
        "K",
        "CA",
        "MG",
        "ZN",
        "MN",
        "FE",
        "CO",
        "CU",
        "NI",
        "CD",
        "HG",
        "SR",
        "BA",
        "LI",
        "CS",
        "RB",
        "AL",
        "GA",
        "IN",
        "TL",
        "PB",
        "BI",
        # Halides
        "F",
        "I",
        "BR",
        # Polyatomic ions
        "SO4",
        "PO4",
        "NO3",
        "CO3",
        # Crystallisation agents / buffers / common additives
        "ACT",
        "ACY",
        "BME",
        "CIT",
        "DMS",
        "EDO",
        "EOH",
        "FMT",
        "GOL",
        "IMD",
        "IPA",
        "MPD",
        "PEG",
        "TRS",
        "DTT",
        "MES",
        "HEP",
        "BEN",
    }
)

_STANDARD_RESIDUES: frozenset = frozenset(
    {
        "ALA",
        "ARG",
        "ASN",
        "ASP",
        "CYS",
        "GLN",
        "GLU",
        "GLY",
        "HIS",
        "ILE",
        "LEU",
        "LYS",
        "MET",
        "PHE",
        "PRO",
        "SER",
        "THR",
        "TRP",
        "TYR",
        "VAL",
        "ASH",
        "CYM",
        "GLH",
        "HID",
        "HIE",
        "HIP",
        "LYN",
        "TYS",
    }
)


def _detect_element_from_pdb(name: str, element_col: str) -> str:
    """Extract element symbol from PDB atom name or element column."""
    elem = element_col.strip()
    if elem and elem != "":
        return elem.capitalize() if len(elem) <= 2 else elem[:2].capitalize()
    name = name.strip()
    if not name:
        return "C"
    if name[0].isdigit():
        return name[1:3].strip().capitalize()
    return name[:2].strip().capitalize()


def _pdbqt_type(element: str, atom: "Chem.Atom") -> str:
    """Map element + RDKit atom properties to AD4 type."""
    ad4 = ELEMENT_TO_AD4_TYPE.get(element)
    if ad4:
        if element == "C":
            return "A" if atom.GetIsAromatic() else "C"
        if element == "N":
            has_h = any(n.GetAtomicNum() == 1 for n in atom.GetNeighbors())
            return "N" if not atom.GetIsAromatic() and not has_h else "NA"
        return ad4
    return element


def _compute_hetatm_charges(mol_h: "Chem.Mol") -> Dict[int, float]:
    """Compute partial charges for HETATM / non-standard residues.

    Returns {atom_idx: charge}. Standard residue atoms are excluded —
    they get pre-computed charges from residue_charges.py instead.

    Strategy:
       0. Pre-computed HETATM table (residue_charges.py) — for known cofactors.
       1. Gasteiger (RDKit) — fast, works for organic elements.
       2. GFN2-xTB — semi-empirical QM, works for ANY element.
       3. Formal charge from input file.
       4. Lookup table of common metal oxidation states.
       5. Zero.
    """
    from .atom_params import (
        _charge_fallback,
        _compute_xtb_charges,
        _find_xtb,
        is_exotic,
    )

    charges: Dict[int, float] = {}
    hetatm_indices = []
    hetatm_resnames: Dict[int, str] = {}

    for atom in mol_h.GetAtoms():
        res_info = atom.GetPDBResidueInfo()
        resname = res_info.GetResidueName().strip() if res_info else ""
        if resname not in _STANDARD_RESIDUES:
            hetatm_indices.append(atom.GetIdx())
            hetatm_resnames[atom.GetIdx()] = resname

    if not hetatm_indices:
        return charges

    # ── Level 0: pre-computed HETATM charges ──────────────────────────────────
    # Group hetatm indices by residue name
    by_resname: Dict[str, List[int]] = {}
    for idx in hetatm_indices:
        rn = hetatm_resnames.get(idx, "")
        by_resname.setdefault(rn, []).append(idx)

    all_from_table = True
    for resname, indices in by_resname.items():
        table = get_hetatm_charges(resname)
        if table is not None:
            for idx in indices:
                atom = mol_h.GetAtomWithIdx(idx)
                res_info = atom.GetPDBResidueInfo()
                atom_name = res_info.GetName().strip() if res_info else ""
                q = table.get(atom_name)
                if q is not None:
                    charges[idx] = q
                else:
                    charges[idx] = 0.0
        else:
            all_from_table = False

    if all_from_table:
        return charges

    # Build sub-molecule for charge computation
    submol = Chem.PathToSubmol(mol_h, hetatm_indices)
    has_exotic_hetatm = any(is_exotic(atom.GetSymbol()) for atom in submol.GetAtoms())

    # ── Level 1a: xtb first for HETATMs with exotic atoms ─────────────────────
    # Consistent with ligand charge strategy (xtb first for exotics).
    if has_exotic_hetatm and _find_xtb() is not None and submol.GetNumConformers() > 0:
        try:
            xtb_result = _compute_xtb_charges(submol)
            if xtb_result is not None and len(xtb_result) == submol.GetNumAtoms():
                for i, orig_idx in enumerate(hetatm_indices):
                    charges[orig_idx] = xtb_result.get(i, 0.0)
                return charges
        except Exception:
            pass

    # ── Level 1b/2: Gasteiger (organic HETATMs, or xtb fallback) ────────────
    gasteiger_nan = False
    try:
        AllChem.ComputeGasteigerCharges(submol)
        for atom in submol.GetAtoms():
            try:
                q = float(atom.GetDoubleProp("_GasteigerCharge"))
            except KeyError:
                q = float("nan")
            if math.isnan(q) or math.isinf(q):
                gasteiger_nan = True
                break
    except Exception:
        gasteiger_nan = True

    if not gasteiger_nan:
        try:
            for orig_idx in hetatm_indices:
                atom = mol_h.GetAtomWithIdx(orig_idx)
                q = float(atom.GetDoubleProp("_GasteigerCharge"))
                charges[orig_idx] = round(q, 4)
            return charges
        except Exception:
            gasteiger_nan = True

    # ── Level 3: xtb fallback (when Gasteiger fails, e.g. metals without xtb) ─
    if (
        not has_exotic_hetatm
        and _find_xtb() is not None
        and submol.GetNumConformers() > 0
    ):
        try:
            xtb_result = _compute_xtb_charges(submol)
            if xtb_result is not None and len(xtb_result) == submol.GetNumAtoms():
                for i, orig_idx in enumerate(hetatm_indices):
                    charges[orig_idx] = xtb_result.get(i, 0.0)
                return charges
        except Exception:
            pass

    # ── Level 3: fallback ────────────────────────────────────────────────────
    logger.warning(
        "Gasteiger and xtb failed for HETATM — using fallback charge assignment."
    )
    for orig_idx in hetatm_indices:
        atom = mol_h.GetAtomWithIdx(orig_idx)
        q = _charge_fallback(atom)
        charges[orig_idx] = round(q, 4)

    return charges


def prepare_receptor(pdb_path: Path, output_path: Path) -> Path:
    """Convert a PDB file to PDBQT format with hydrogens and charges.

    Uses RDKit to:
    1. Parse the PDB and add hydrogens at pH 7.4
    2. Assign charges: pre-computed tables for standard residues,
       Gasteiger fallback for HETATM/cofactors
    3. Map elements to AD4 atom types
    4. Write standard PDBQT columns

    Args:
        pdb_path: Input PDB file.
        output_path: Output PDBQT file.

    Returns:
        output_path.
    """
    mol = Chem.MolFromPDBFile(str(pdb_path), removeHs=False, sanitize=False)
    if mol is None:
        mol = Chem.MolFromPDBFile(str(pdb_path), removeHs=False, sanitize=True)
    if mol is None:
        raise ValueError(f"RDKit could not parse '{pdb_path.name}'.")

    mol_h = Chem.AddHs(mol, addCoords=True)

    if mol_h.GetNumConformers() == 0:
        raise ValueError(f"No coordinates found in '{pdb_path.name}'.")

    # Optimise hydrogen positions with UFF (cheap for small molecules, skipped
    # for large receptors where PDB lacks bond-order → UFF has no effect).
    if mol_h.GetNumAtoms() < 200:
        try:
            AllChem.UFFOptimizeMolecule(mol_h, maxIters=50)
        except Exception:
            pass

    conf = mol_h.GetConformer()

    # ── Charge assignment ────────────────────────────────────────────────────
    # Strategy: pre-computed for standard residues, Gasteiger for HETATM
    charges: Dict[int, float] = {}
    standard_count = 0
    hetatm_charges = _compute_hetatm_charges(mol_h)
    zeroed_atoms: List[str] = []

    for atom in mol_h.GetAtoms():
        idx = atom.GetIdx()
        res_info = atom.GetPDBResidueInfo()
        resname = res_info.GetResidueName().strip() if res_info else ""
        atom_name = res_info.GetName().strip() if res_info else ""

        if resname in _STANDARD_RESIDUES:
            # Use pre-computed charges from residue_charges.py
            residue_charges = get_residue_charges(resname)
            if residue_charges and atom_name in residue_charges:
                charges[idx] = residue_charges[atom_name]
                standard_count += 1
            else:
                # Atom name not in table — fallback to 0.000
                charges[idx] = 0.0
        else:
            # HETATM / cofactor / metal — use Gasteiger
            charges[idx] = hetatm_charges.get(idx, 0.0)
            if hetatm_charges.get(idx) == 0.0 and atom.GetAtomicNum() > 1:
                zeroed_atoms.append(f"{atom.GetSymbol()}@{resname}:{atom_name}")

    # ── PDBQT generation ─────────────────────────────────────────────────────
    lines_out: list[str] = []
    serial = 0
    atom_count = 0
    water_count = 0

    for atom in mol_h.GetAtoms():
        res_info = atom.GetPDBResidueInfo()
        if res_info is None:
            # RDKit-added hydrogen without residue info — inherit from parent
            if atom.GetAtomicNum() != 1:
                continue
            parent = next(iter(atom.GetNeighbors()), None)
            parent_res = parent.GetPDBResidueInfo() if parent else None
            if parent_res is None:
                continue
            resname = parent_res.GetResidueName().strip()
            if resname in _HETATM_SKIP:
                water_count += 1
                continue
            is_standard = resname in _STANDARD_RESIDUES
            record = "HETATM" if not is_standard else "ATOM"
            chain = parent_res.GetChainId() or "A"
            resseq = parent_res.GetResidueNumber()
            atom_name = f"H{serial}"
            ad4_type = "HD"
        else:
            resname = res_info.GetResidueName().strip()
            if resname in _HETATM_SKIP:
                water_count += 1
                continue

            is_standard = resname in _STANDARD_RESIDUES
            record = "HETATM" if not is_standard else "ATOM"
            element = atom.GetSymbol()
            ad4_type = _pdbqt_type(element, atom)
            chain = res_info.GetChainId() or "A"
            resseq = res_info.GetResidueNumber()
            atom_name = res_info.GetName().strip() or f"{element:<2s}"

        charge = charges.get(atom.GetIdx(), 0.0)
        pos = conf.GetAtomPosition(atom.GetIdx())

        pdbqt_line = (
            f"{record:<6s}{serial:5d} {atom_name:<4s} {resname:<3s} {chain:>1s}{resseq:>4d}    "
            f"{pos.x:8.3f}{pos.y:8.3f}{pos.z:8.3f}"
            f"  1.00  0.00   {charge:>7.3f} {ad4_type:<2s}\n"
        )
        lines_out.append(pdbqt_line)
        atom_count += 1

    lines_out.append("TER\n")
    lines_out.append("END\n")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("".join(lines_out))

    # ── Logging ──────────────────────────────────────────────────────────────
    non_standard_count = atom_count - standard_count
    if standard_count:
        logger.info(
            "Prepared receptor: %s → %s (%d atoms, %d standard charges, %d HETATM, %d waters skipped)",
            pdb_path.name,
            output_path.name,
            atom_count,
            standard_count,
            non_standard_count,
            water_count,
        )
    else:
        logger.warning(
            "Prepared receptor: %s → %s (%d atoms, NO standard charges found — all set to 0.000). "
            "Verify residue names match PDB convention (ALA, ARG, ...).",
            pdb_path.name,
            output_path.name,
            atom_count,
        )

    if zeroed_atoms:
        logger.warning(
            "%d HETATM atom(s) with NaN Gasteiger charges → 0.000: %s. "
            "Use QM/RESP charges for metal cofactors in production.",
            len(zeroed_atoms),
            ", ".join(zeroed_atoms[:10]) + ("..." if len(zeroed_atoms) > 10 else ""),
        )

    return output_path
