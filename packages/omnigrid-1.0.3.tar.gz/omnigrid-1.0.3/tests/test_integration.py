"""
Integration tests for OmniGrid — end-to-end pipeline validation with real
receptor stubs and exotic-element ligands.

These tests verify that:
    1. The JIT parameter file (AD4_parameters_temp.dat) is generated correctly.
    2. The .gpf references the right types and maps.
    3. The UFF audit log records exotic-element injections.
    4. AutoGrid4 runs without buffer-overflow crashes (when autogrid4 is installed).

Tests that require AutoGrid4 are marked with @pytest.mark.skipif so they
are gracefully skipped on CI/workstations without the binary.
"""
from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

import pytest
from rdkit import Chem
from rdkit.Chem import AllChem

from omnigrid.atom_params import get_uff_params
from omnigrid.gpf_generator import GridConfig, generate_gpf
from omnigrid.params_writer import UFFAuditLog, write_temp_params
from omnigrid.pipeline import PipelineConfig, process_ligand
from omnigrid.receptor_preparer import prepare_receptor
from omnigrid.runner import run_autogrid

autogrid4_required = pytest.mark.skipif(
    shutil.which("autogrid4") is None,
    reason="autogrid4 not in PATH",
)

_RECEPTOR_PDBQT = (
    "REMARK  Minimal test receptor — CA/C/N/OA types only\n"
    "ATOM      1 CA   REC A   1       0.000   0.000   0.000  1.00  0.00      0.034 CA\n"
    "ATOM      2 C    REC A   1       3.800   0.000   0.000  1.00  0.00      0.036 C \n"
    "ATOM      3 N    REC A   1       7.600   0.000   0.000  1.00  0.00     -0.030 N \n"
    "ATOM      4 OA   REC A   1      11.400   0.000   0.000  1.00  0.00     -0.060 OA\n"
    "TER\n"
    "END\n"
)


def _build_sdf(mol: Chem.Mol, path: Path) -> None:
    writer = Chem.SDWriter(str(path))
    writer.write(mol)
    writer.close()


def _make_cfg(tmp: Path) -> PipelineConfig:
    rec = tmp / "receptor.pdbqt"
    rec.write_text(_RECEPTOR_PDBQT)
    ligands = tmp / "ligands"
    ligands.mkdir()
    output = tmp / "output"
    output.mkdir()
    return PipelineConfig(
        receptor_pdbqt=rec,
        ligands_dir=ligands,
        output_dir=output,
        center=(5.0, 0.0, 0.0),
        npts=(40, 40, 40),
        dry_run=True,
    )


# ---------------------------------------------------------------------------
# Test 1: Smoke-run with Boron ligand (phenylboronic acid) — dry_run=True
# ---------------------------------------------------------------------------

def test_smoke_run_boron_dry() -> None:
    """Full pipeline for a B-containing ligand — verify files are generated."""
    mol = Chem.MolFromSmiles("B(O)(O)c1ccccc1")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path)
        sdf = cfg.ligands_dir / "phenylboronic.sdf"
        _build_sdf(mol, sdf)

        result = process_ligand(sdf, cfg)

        assert result.success, f"Pipeline failed: {result.error}"
        assert "B" in result.exotic_types

        stem = "phenylboronic"
        work = cfg.output_dir / stem

        # AD4_parameters_temp.dat
        dat = work / "AD4_parameters_temp.dat"
        assert dat.exists(), "AD4_parameters_temp.dat not created"
        dat_content = dat.read_text()
        assert "atom_par B " in dat_content, \
            "B line not found in AD4_parameters_temp.dat"
        assert "parameter_file" not in dat_content or "FE_coeff" in dat_content

        # .gpf
        gpf = work / f"{stem}.gpf"
        assert gpf.exists(), ".gpf not created"
        gpf_text = gpf.read_text()
        assert "ligand_types" in gpf_text
        assert "B" in gpf_text, "B not in ligand_types declaration"
        assert "receptor.B.map" in gpf_text or f".B.map" in gpf_text, \
            "map receptor.B.map not found"
        assert "parameter_file AD4_parameters_temp.dat" in gpf_text

        # UFF audit log
        audit = cfg.output_dir / "uff_audit.log"
        assert audit.exists(), "uff_audit.log not created"
        audit_text = audit.read_text()
        assert "B" in audit_text, "B not recorded in UFF audit log"


# ---------------------------------------------------------------------------
# Test 2: Smoke-run with Pt ligand (cisplatin analogue) — dry_run=True
# ---------------------------------------------------------------------------

def test_smoke_run_platinum_dry() -> None:
    """Full pipeline for a Pt-containing ligand — verify files are generated."""
    mol = Chem.MolFromSmiles("N[Pt](N)(Cl)Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path)
        sdf = cfg.ligands_dir / "cisplatin.sdf"
        _build_sdf(mol, sdf)

        result = process_ligand(sdf, cfg)

        assert result.success, f"Pipeline failed: {result.error}"
        assert "Pt" in result.exotic_types

        stem = "cisplatin"
        work = cfg.output_dir / stem

        dat = work / "AD4_parameters_temp.dat"
        assert dat.exists()
        dat_content = dat.read_text()
        assert "Pt" in dat_content, "Pt not found in AD4_parameters_temp.dat"

        gpf = work / f"{stem}.gpf"
        assert gpf.exists()
        gpf_text = gpf.read_text()
        assert "Pt" in gpf_text
        assert ".Pt.map" in gpf_text, "map for Pt not found"
        assert "parameter_file AD4_parameters_temp.dat" in gpf_text

        audit = cfg.output_dir / "uff_audit.log"
        assert audit.exists()
        audit_text = audit.read_text()
        assert "Pt" in audit_text


# ---------------------------------------------------------------------------
# Test 3: Charge source documentation for exotic elements
# ---------------------------------------------------------------------------

def test_charge_source_for_exotic() -> None:
    """Verify charge_source is 'gasteiger' or 'none' for exotic ligands (not QM)."""
    mol = Chem.MolFromSmiles("N[Pt](N)(Cl)Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path)
        sdf = cfg.ligands_dir / "cisplatin.sdf"
        _build_sdf(mol, sdf)

        result = process_ligand(sdf, cfg)
        assert result.charge_source in ("gasteiger", "none"), \
            f"Unexpected charge_source for exotic ligand: {result.charge_source}"
        assert result.pdbqt_prepared, "PDBQT should have been auto-prepared for SDF input"


# ---------------------------------------------------------------------------
# Test 4: Regression — parse generated .dat and compare with reference values
# ---------------------------------------------------------------------------

def test_param_regression_b_pt_ru() -> None:
    """After write_temp_params, parse the .dat and verify Rii/epsii/vol match UFF reference."""
    reference = {
        "B":  {"Rii": 3.637, "epsii": 0.095},
        "Pt": {"Rii": 2.453, "epsii": 0.080},
        "Ru": {"Rii": 2.963, "epsii": 0.056},
    }

    with tempfile.TemporaryDirectory() as tmp:
        dat = Path(tmp) / "AD4_parameters_temp.dat"
        write_temp_params(
            exotic_types={"B", "Pt", "Ru"},
            dest=dat,
            ligand_name="regression_test",
        )

        content = dat.read_text()
        for line in content.splitlines():
            stripped = line.strip()
            if not stripped or not stripped.startswith("atom_par "):
                continue
            parts = stripped.split()
            if len(parts) < 5:
                continue
            symbol = parts[1]
            if symbol not in reference:
                continue
            ref = reference[symbol]
            rii = float(parts[2])
            epsii = float(parts[3])
            assert abs(rii - ref["Rii"]) < 1e-3, \
                f"{symbol} Rii: expected {ref['Rii']}, got {rii}"
            assert abs(epsii - ref["epsii"]) < 1e-3, \
                f"{symbol} epsii: expected {ref['epsii']}, got {epsii}"

            uff = get_uff_params(symbol)
            assert uff is not None
            vol = float(parts[4])
            assert abs(vol - uff.vol) < 0.1, \
                f"{symbol} vol: expected {uff.vol}, got {vol}"


# ---------------------------------------------------------------------------
# Test 5: AutoGrid4 smoke-run with B ligand (requires autogrid4 binary)
# ---------------------------------------------------------------------------

@autogrid4_required
def test_autogrid4_run_boron() -> None:
    """Run AutoGrid4 for real with a B-containing ligand — exit code must be 0."""
    mol = Chem.MolFromSmiles("B(O)(O)c1ccccc1")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path)
        cfg.dry_run = False
        sdf = cfg.ligands_dir / "phenylboronic.sdf"
        _build_sdf(mol, sdf)

        result = process_ligand(sdf, cfg)
        assert result.success, f"AutoGrid4 failed: {result.error}"
        assert result.log is not None
        assert result.log.exists()


# ---------------------------------------------------------------------------
# Test 6: AutoGrid4 smoke-run with Pt ligand (requires autogrid4 binary)
# ---------------------------------------------------------------------------

@autogrid4_required
def test_autogrid4_run_platinum() -> None:
    """Run AutoGrid4 for real with a Pt-containing ligand — no buffer overflow."""
    mol = Chem.MolFromSmiles("N[Pt](N)(Cl)Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path)
        cfg.dry_run = False
        sdf = cfg.ligands_dir / "cisplatin.sdf"
        _build_sdf(mol, sdf)

        result = process_ligand(sdf, cfg)
        assert result.success, f"AutoGrid4 failed with Pt: {result.error}"
        assert result.log is not None
        assert result.log.exists()


# ---------------------------------------------------------------------------
# Test 7: GPF generation — ligand_types and map lines for exotic elements
# ---------------------------------------------------------------------------

def test_gpf_exotic_map_lines() -> None:
    """Verify .gpf has correct map lines for exotic + standard types."""
    ligand_types = {"B", "Pt", "C", "OA", "HD"}

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        rec = tmp_path / "receptor.pdbqt"
        rec.write_text(_RECEPTOR_PDBQT)
        lig = tmp_path / "ligand.pdbqt"
        lig.write_text("")
        dat = tmp_path / "AD4_parameters_temp.dat"
        dat.write_text("")
        gpf = tmp_path / "ligand.gpf"

        cfg = GridConfig(
            receptor_pdbqt=rec,
            receptor_types=["C", "N", "OA", "CA"],
            ligand_pdbqt=lig,
            temp_params_dat=dat,
            center=(0.0, 0.0, 0.0),
            npts=(40, 40, 40),
        )
        generate_gpf(ligand_types, cfg, gpf)

        gpf_text = gpf.read_text()
        for t in ligand_types:
            assert f".{t}.map" in gpf_text, f"map for {t} missing"
        for t in ligand_types:
            assert t in gpf_text, f"type {t} not in GPF"


# ---------------------------------------------------------------------------
# Test 8: Audit log records all exotic types
# ---------------------------------------------------------------------------

def test_audit_log_records_exotic() -> None:
    """UFFAuditLog must record one entry per exotic type per ligand."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        log_path = tmp_path / "uff_audit.log"
        dat = tmp_path / "AD4_parameters_temp.dat"
        audit = UFFAuditLog(log_path)

        write_temp_params(
            exotic_types={"B", "Pt", "Ru", "Au"},
            dest=dat,
            audit_log=audit,
            ligand_name="test_metal_complex",
        )

        log_text = log_path.read_text()
        for sym in ("B", "Pt", "Ru", "Au"):
            assert sym in log_text, f"{sym} not recorded in audit log"
            assert "UFF_Rappe1992" in log_text


# ---------------------------------------------------------------------------
# Test 9: Minimal exotic-element map pipeline — validates both atom_par
# format in .dat AND PDBQT column alignment in receptor
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def exotic_pipeline_output(tmp_path_factory):
    """Run full pipeline with B ligand + PDB-derived receptor, return all outputs."""
    tmp = tmp_path_factory.mktemp("exotic_pipeline")

    # Write a PDB and prepare via prepare_receptor to test column alignment
    pdb = tmp / "receptor.pdb"
    pdb.write_text(
        "ATOM      1  CA  ALA A   1       0.000   0.000   0.000  1.00  0.00           C  \n"
        "ATOM      2  C   ALA A   1       3.800   0.000   0.000  1.00  0.00           C  \n"
        "ATOM      3  N   ALA A   1       7.600   0.000   0.000  1.00  0.00           N  \n"
        "ATOM      4  O   ALA A   1      11.400   0.000   0.000  1.00  0.00           O  \n"
        "END\n"
    )
    rec = tmp / "receptor.pdbqt"
    prepare_receptor(pdb, rec)

    ligands = tmp / "ligands"
    ligands.mkdir()
    output = tmp / "output"
    output.mkdir()

    cfg = PipelineConfig(
        receptor_pdbqt=rec,
        ligands_dir=ligands,
        output_dir=output,
        center=(5.0, 0.0, 0.0),
        npts=(40, 40, 40),
        dry_run=True,
    )

    mol = Chem.MolFromSmiles("B(O)(O)c1ccccc1")
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())
    sdf = ligands / "phenylboronic.sdf"
    _build_sdf(mol, sdf)

    result = process_ligand(sdf, cfg)
    assert result.success, f"Pipeline failed: {result.error}"
    return cfg, result


def test_exotic_param_file_has_atom_par(exotic_pipeline_output):
    """The .dat file must use atom_par prefix for all atom types."""
    cfg, result = exotic_pipeline_output
    dat = cfg.output_dir / "phenylboronic" / "AD4_parameters_temp.dat"
    content = dat.read_text()
    param_lines = [l for l in content.splitlines()
                   if l.strip() and not l.startswith("#") and not l.startswith("FE_")]
    for line in param_lines:
        parts = line.split()
        assert parts[0] == "atom_par", \
            f"Line does not start with 'atom_par': {line!r}"


def test_exotic_param_values_are_uff(exotic_pipeline_output):
    """Exotic-type Rii/epsii in .dat must match UFF reference."""
    cfg, result = exotic_pipeline_output
    dat = cfg.output_dir / "phenylboronic" / "AD4_parameters_temp.dat"
    content = dat.read_text()
    for line in content.splitlines():
        if "atom_par B " not in line:
            continue
        parts = line.split()
        rii = float(parts[2])
        epsii = float(parts[3])
        assert abs(rii - 3.637) < 0.001, f"B Rii: expected 3.637, got {rii}"
        assert abs(epsii - 0.095) < 0.001, f"B epsii: expected 0.095, got {epsii}"


def test_exotic_gpf_has_map_lines(exotic_pipeline_output):
    """GPF must include map lines for exotic and standard types."""
    cfg, result = exotic_pipeline_output
    gpf = cfg.output_dir / "phenylboronic" / "phenylboronic.gpf"
    gpf_text = gpf.read_text()
    assert "atom_par" not in gpf_text
    assert "parameter_file AD4_parameters_temp.dat" in gpf_text
    for t in ("B", "A", "OA", "HD"):
        assert f".{t}.map" in gpf_text, f"map for {t} missing"


def test_exotic_receptor_types_detected(exotic_pipeline_output):
    """detect_receptor_types must return clean type strings (no charge contamination)."""
    from omnigrid.gpf_generator import detect_receptor_types

    cfg, result = exotic_pipeline_output
    types = detect_receptor_types(cfg.receptor_pdbqt)
    for t in types:
        assert t.isalpha(), f"Type contains non-alpha chars: {t!r}"
    assert "C" in types
    assert "OA" in types


def test_exotic_pdbqt_column_alignment(exotic_pipeline_output):
    """Receptor PDBQT must have charge at 70-76, space at 77, type at 78-79."""
    cfg, result = exotic_pipeline_output
    lines = cfg.receptor_pdbqt.read_text().splitlines()
    for line in lines:
        if not line.startswith(("ATOM", "HETATM")):
            continue
        charge_str = line[69:76].strip()
        charge = float(charge_str)
        assert line[76] == " ", f"Column 77 should be space, got {line[76]!r}"
        ad4_type = line[77:79].strip()
        assert len(ad4_type) >= 1
        # Verify type appears in the last space-delimited token
        assert line.split()[-1] == ad4_type, \
            f"Last split token {line.split()[-1]!r} != type {ad4_type!r}"
