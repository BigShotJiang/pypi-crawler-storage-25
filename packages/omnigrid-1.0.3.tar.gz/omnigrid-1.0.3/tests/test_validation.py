"""
Unit-validation tests for OmniGrid JIT parameterisation.

Runnable without pytest::

    python tests/test_validation.py

Or with pytest::

    pytest tests/test_validation.py -v

Coverage:
    1. UFF parameter values for B (Boron) and Pt (Platinum) — Rappé 1992 reference.
    2. AD4_parameters_temp.dat generation — case-sensitive symbol fidelity.
    3. .gpf generation — map lines and ligand_types perfectly aligned.
    4. auto_grid_box — bounding-box centre + even npts with 5 Å padding.
    5. Charge detection — PDBQT pre-existing vs Gasteiger fallback logic.
"""
from __future__ import annotations

import math
import sys
import tempfile
from pathlib import Path

# ── Lightweight test harness (no pytest required) ────────────────────────────

_PASS: list[str] = []
_FAIL: list[str] = []


def _check(condition: bool, msg: str) -> None:
    tag = "PASS" if condition else "FAIL"
    print(f"  [{tag}] {msg}")
    ((_PASS if condition else _FAIL).append(msg))


# ── B + Pt reference dictionary ──────────────────────────────────────────────

B_PT_REFERENCE = {
    "B": {
        "Rii":   3.637,
        "epsii": 0.095,
        "r_cov": 0.804,
        "source": "Rappé 1992 Table 1",
    },
    "Pt": {
        "Rii":   2.453,
        "epsii": 0.080,
        "r_cov": 1.364,
        "source": "Rappé 1992 Table 1",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Test 1: UFF parameter values
# ─────────────────────────────────────────────────────────────────────────────

def test_uff_b_pt() -> None:
    print("\n── Test 1: UFF parameters for B and Pt ──")
    from omnigrid.atom_params import get_uff_params, compute_vol

    for symbol, ref in B_PT_REFERENCE.items():
        p = get_uff_params(symbol)
        _check(p is not None, f"get_uff_params('{symbol}') returns a result")
        if p is None:
            continue

        _check(abs(p.Rii   - ref["Rii"])   < 1e-3, f"{symbol}.Rii   = {ref['Rii']}  (got {p.Rii})")
        _check(abs(p.epsii - ref["epsii"]) < 1e-3, f"{symbol}.epsii = {ref['epsii']} (got {p.epsii})")
        _check(abs(p.r_cov - ref["r_cov"]) < 1e-3, f"{symbol}.r_cov = {ref['r_cov']} (got {p.r_cov})")

        # Validate vol = (4/3)π(Rii/2)³
        expected_vol = round((4.0 / 3.0) * math.pi * (p.Rii / 2.0) ** 3, 4)
        _check(abs(p.vol - expected_vol) < 0.01,
               f"{symbol}.vol matches (4/3)π(Rii/2)³ = {expected_vol:.4f}  (got {p.vol})")

        print(f"  {symbol}: {p}")


# ─────────────────────────────────────────────────────────────────────────────
# Test 2: AD4_parameters_temp.dat — symbol case fidelity
# ─────────────────────────────────────────────────────────────────────────────

def test_dat_generation() -> None:
    print("\n── Test 2: AD4_parameters_temp.dat for {B, Pt} ──")
    from omnigrid.params_writer import write_temp_params

    with tempfile.TemporaryDirectory() as tmp:
        dat = Path(tmp) / "AD4_parameters_temp.dat"
        write_temp_params(exotic_types={'B', 'Pt'}, dest=dat, ligand_name="BPt_test")

        content = dat.read_text()
        print("\n" + content)

        lines = content.splitlines()
        param_lines = [l for l in lines if l and not l.startswith('#') and not l.startswith('FE_')]

        # Case-sensitive presence check (atom_par prefix expected)
        def _has_symbol(sym: str) -> bool:
            target = f"atom_par {sym} "
            return any(target in l for l in param_lines)

        _check(_has_symbol('B'),  "Symbol 'B'  (Boron)    found in temp .dat")
        _check(_has_symbol('Pt'), "Symbol 'Pt' (Platinum) found in temp .dat")

        # Negative: no case mutations
        bad_b  = any("atom_par b " in l for l in param_lines)
        bad_PT = any("atom_par PT " in l for l in param_lines)
        bad_pt = any("atom_par pt " in l for l in param_lines)

        _check(not bad_b,  "No lowercase 'b ' symbol in temp .dat")
        _check(not bad_PT, "No uppercase 'PT ' in temp .dat")
        _check(not bad_pt, "No lowercase 'pt ' in temp .dat")

        # Numerical plausibility — B line should show Rii ≈ 3.637
        b_line = next((l for l in param_lines if "atom_par B " in l), None)
        if b_line:
            b_rii = float(b_line.split()[2])
            _check(abs(b_rii - 3.637) < 1e-3, f"B Rii in .dat = 3.637 (got {b_rii})")

        pt_line = next((l for l in param_lines if "atom_par Pt " in l), None)
        if pt_line:
            pt_rii = float(pt_line.split()[2])
            _check(abs(pt_rii - 2.453) < 1e-3, f"Pt Rii in .dat = 2.453 (got {pt_rii})")


# ─────────────────────────────────────────────────────────────────────────────
# Test 3: .gpf — ligand_types and map lines perfectly aligned
# ─────────────────────────────────────────────────────────────────────────────

def test_gpf_alignment() -> None:
    print("\n── Test 3: .gpf map lines / ligand_types alignment (case-sensitive) ──")
    from omnigrid.gpf_generator import GridConfig, generate_gpf

    # Molecule with both exotic (B, Pt) and standard types
    ligand_types = {'B', 'Pt', 'C', 'OA', 'NA', 'HD'}

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        rec = tmp_path / "receptor.pdbqt"
        lig = tmp_path / "BPt_mol.pdbqt"
        dat = tmp_path / "AD4_parameters_temp.dat"
        gpf = tmp_path / "BPt_mol.gpf"

        # Minimal stubs — gpf_generator reads only the names, not content
        rec.write_text(
            "ATOM      1  CA  REC A   1       0.000   0.000   0.000  1.00  0.00    CA\n"
        )
        lig.write_text("")
        dat.write_text("")

        cfg = GridConfig(
            receptor_pdbqt  = rec,
            receptor_types  = ['C', 'N', 'OA', 'CA'],
            ligand_pdbqt    = lig,
            temp_params_dat = dat,
            center          = (10.0, 20.0, 30.0),
            npts            = (40, 40, 40),
        )
        generate_gpf(ligand_types, cfg, gpf)

        gpf_text = gpf.read_text()
        print("\n" + gpf_text)

        # ── ligand_types line ────────────────────────────────────────────────
        lig_types_line = next(
            (l for l in gpf_text.splitlines() if l.startswith('ligand_types')), ''
        )
        declared = set(lig_types_line.split()[1:])  # tokens after 'ligand_types'

        for t in ligand_types:
            _check(t in declared,
                   f"Type '{t}' in ligand_types declaration  (line: {lig_types_line!r})")

        # ── map lines ────────────────────────────────────────────────────────
        # Expected pattern: "map receptor.TYPE.map"
        map_lines = [l for l in gpf_text.splitlines() if l.startswith('map ')]
        for t in ligand_types:
            fragment = f".{t}.map"
            _check(
                any(fragment in ml for ml in map_lines),
                f"map line contains '{fragment}'  (case-sensitive)",
            )

        # No duplicate map lines
        _check(len(map_lines) == len(ligand_types),
               f"Exactly {len(ligand_types)} map lines (got {len(map_lines)})")


# ─────────────────────────────────────────────────────────────────────────────
# Test 4: auto_grid_box — bounding box + padding arithmetic
# ─────────────────────────────────────────────────────────────────────────────

def test_auto_grid_box() -> None:
    print("\n── Test 4: auto_grid_box centre + even npts (5 Å padding) ──")
    from omnigrid.gpf_generator import auto_grid_box

    # Two atoms at known positions
    pdbqt_content = (
        "ATOM      1  C1  LIG A   1       0.000   0.000   0.000  1.00  0.00     0.000 C \n"
        "ATOM      2  C2  LIG A   1      10.000   8.000   6.000  1.00  0.00     0.000 C \n"
    )
    spacing = 0.375
    padding = 5.0

    with tempfile.TemporaryDirectory() as tmp:
        lig = Path(tmp) / "test.pdbqt"
        lig.write_text(pdbqt_content)

        centre, npts = auto_grid_box(lig, padding=padding, spacing=spacing)

        # Expected centre: midpoint of bounding box
        _check(abs(centre[0] - 5.0) < 0.01, f"centre.x = 5.000 (got {centre[0]:.4f})")
        _check(abs(centre[1] - 4.0) < 0.01, f"centre.y = 4.000 (got {centre[1]:.4f})")
        _check(abs(centre[2] - 3.0) < 0.01, f"centre.z = 3.000 (got {centre[2]:.4f})")

        # Expected npts.x: ceil((10 - 0 + 2*5) / 0.375) = ceil(53.33) = 54 (even ✓)
        # Expected npts.y: ceil((8  - 0 + 2*5) / 0.375) = ceil(48)    = 48 (even ✓)
        # Expected npts.z: ceil((6  - 0 + 2*5) / 0.375) = ceil(42.67) = 43 → 44 (even)
        def _expected_n(lo: float, hi: float) -> int:
            n = math.ceil((hi - lo + 2 * padding) / spacing)
            return n + 1 if n % 2 != 0 else n

        exp_nx = _expected_n(0.0, 10.0)
        exp_ny = _expected_n(0.0,  8.0)
        exp_nz = _expected_n(0.0,  6.0)

        _check(npts[0] == exp_nx, f"npts.x = {exp_nx} (got {npts[0]})")
        _check(npts[1] == exp_ny, f"npts.y = {exp_ny} (got {npts[1]})")
        _check(npts[2] == exp_nz, f"npts.z = {exp_nz} (got {npts[2]})")

        # AutoGrid4 requirement: all npts must be even
        _check(npts[0] % 2 == 0, f"npts.x = {npts[0]} is even")
        _check(npts[1] % 2 == 0, f"npts.y = {npts[1]} is even")
        _check(npts[2] % 2 == 0, f"npts.z = {npts[2]} is even")

        print(f"  centre={centre}  npts={npts}")


# ─────────────────────────────────────────────────────────────────────────────
# Test 5: Charge detection — PDBQT pre-existing vs none
# ─────────────────────────────────────────────────────────────────────────────

def test_charge_detection() -> None:
    print("\n── Test 5: charge detection in PDBQT ──")
    from omnigrid.ligand_reader import extract_charges

    charged_pdbqt = (
        "ATOM      1  C1  LIG A   1       0.000   0.000   0.000  1.00  0.00    -0.243 C \n"
        "ATOM      2  N1  LIG A   1       1.300   0.000   0.000  1.00  0.00    +0.401 NA\n"
    )
    zero_pdbqt = (
        "ATOM      1  C1  LIG A   1       0.000   0.000   0.000  1.00  0.00     0.000 C \n"
        "ATOM      2  N1  LIG A   1       1.300   0.000   0.000  1.00  0.00     0.000 NA\n"
    )

    with tempfile.TemporaryDirectory() as tmp:
        charged_file = Path(tmp) / "charged.pdbqt"
        zero_file    = Path(tmp) / "zero.pdbqt"
        charged_file.write_text(charged_pdbqt)
        zero_file.write_text(zero_pdbqt)

        info_charged = extract_charges(charged_file)
        _check(info_charged.source    == 'pdbqt_preexisting', "Charged PDBQT → source='pdbqt_preexisting'")
        _check(info_charged.preserved == True,                "Charged PDBQT → preserved=True")
        _check(len(info_charged.charges) == 2,               f"Charged PDBQT → 2 charges parsed (got {len(info_charged.charges)})")

        info_zero = extract_charges(zero_file)
        _check(info_zero.source    == 'none',  "Zero-charge PDBQT → source='none'")
        _check(info_zero.preserved == False,   "Zero-charge PDBQT → preserved=False")


# ─────────────────────────────────────────────────────────────────────────────
# Simulation printout — B + Pt test dictionary
# ─────────────────────────────────────────────────────────────────────────────

def print_bpt_simulation() -> None:
    print("\n── Simulation: B + Pt molecule — full test dictionary ──")
    import json
    from omnigrid.atom_params import get_uff_params

    test_dict = {
        "molecule":        "BPt_synthetic",
        "all_ad4_types":   sorted(['B', 'Pt', 'C', 'NA', 'OA', 'HD']),
        "exotic_types":    ['B', 'Pt'],
        "standard_types":  sorted(['C', 'NA', 'OA', 'HD']),
        "uff_params": {
            sym: {
                "Rii":    p.Rii,
                "epsii":  p.epsii,
                "vol":    p.vol,
                "solpar": p.solpar,
                "r_cov":  p.r_cov,
                "hbond":  p.hbond,
                "source": "UFF Rappé 1992",
            }
            for sym in ('B', 'Pt')
            if (p := get_uff_params(sym)) is not None
        },
        "reference": B_PT_REFERENCE,
    }
    print(json.dumps(test_dict, indent=2))


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def run_all() -> int:
    test_uff_b_pt()
    test_dat_generation()
    test_gpf_alignment()
    test_auto_grid_box()
    test_charge_detection()
    print_bpt_simulation()

    print(f"\n{'=' * 55}")
    print(f"Results: {len(_PASS)} passed  /  {len(_FAIL)} failed")
    if _FAIL:
        print("FAILED assertions:")
        for f in _FAIL:
            print(f"  ✗ {f}")
        return 1
    print("All assertions passed.")
    return 0


if __name__ == "__main__":
    # Allow running from repo root: python tests/test_validation.py
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    sys.exit(run_all())


# ── pytest-compatible wrappers ───────────────────────────────────────────────

def test_uff_params_pytest() -> None:
    test_uff_b_pt()
    assert not _FAIL, f"Failures: {_FAIL}"


def test_dat_pytest() -> None:
    n_before = len(_FAIL)
    test_dat_generation()
    assert len(_FAIL) == n_before, f"New failures: {_FAIL[n_before:]}"


def test_gpf_pytest() -> None:
    n_before = len(_FAIL)
    test_gpf_alignment()
    assert len(_FAIL) == n_before, f"New failures: {_FAIL[n_before:]}"


def test_grid_box_pytest() -> None:
    n_before = len(_FAIL)
    test_auto_grid_box()
    assert len(_FAIL) == n_before, f"New failures: {_FAIL[n_before:]}"


def test_charges_pytest() -> None:
    n_before = len(_FAIL)
    test_charge_detection()
    assert len(_FAIL) == n_before, f"New failures: {_FAIL[n_before:]}"