"""
Tests for heavy and complex elements already supported by OmniGrid.

Covers all transition metals and heavy main-group elements present in _UFF_RAW:
    Ag, Au, Cd, Co, Cr, Cu, Hf, Hg, Ir, Mo, Nb, Ni, Os, Pd, Pt, Re, Rh, Ru,
    Sc, Tc, Ta, Ti, V, W, Y, Zr, plus heavy main-group: Al, Ga, In, Tl,
    Ge, Sn, Pb, As, Sb, Bi, Se, Te, Ba, Sr, Rb, Cs, Li, Na, K, Be.

Validates:
    1. UFF parameter derivation for every supported element
    2. PDBQT generation for complex coordination compounds
    3. Full pipeline (GPF + .dat) with multi-metal ligands
    4. Volume/solvation consistency across the periodic table
    5. Edge cases: high-Z elements, multiple metals in one molecule
"""
from __future__ import annotations

import math
import tempfile
from pathlib import Path

import pytest
from rdkit import Chem
from rdkit.Chem import AllChem

from omnigrid.atom_params import (
    _UFF_RAW,
    _solvation_class,
    compute_solpar,
    compute_vol,
    get_uff_params,
    is_exotic,
)
from omnigrid.gpf_generator import GridConfig, auto_grid_box, detect_receptor_types, generate_gpf
from omnigrid.params_writer import UFFAuditLog, write_temp_params
from omnigrid.pipeline import PipelineConfig, process_ligand
from omnigrid.receptor_preparer import prepare_receptor


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def simple_receptor(tmp_path_factory):
    """Create a minimal receptor PDB for testing."""
    tmp = tmp_path_factory.mktemp("receptor")
    pdb = tmp / "dummy.pdb"
    pdb.write_text(
        "ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00  0.00           N  \n"
        "ATOM      2  CA  ALA A   1       1.458   0.000   0.000  1.00  0.00           C  \n"
        "ATOM      3  C   ALA A   1       2.009   1.420   0.000  1.00  0.00           C  \n"
        "ATOM      4  O   ALA A   1       1.245   2.390   0.000  1.00  0.00           O  \n"
        "ATOM      5  CB  ALA A   1       1.961  -0.730  -1.237  1.00  0.00           C  \n"
        "END\n"
    )
    pdbqt = tmp / "dummy.pdbqt"
    prepare_receptor(pdb, pdbqt)
    return pdbqt


def _build_sdf(mol: Chem.Mol, path: Path) -> None:
    """Write an RDKit mol to SDF."""
    w = Chem.SDWriter(str(path))
    w.write(mol)
    w.close()


def _make_cfg(tmp: Path, receptor_pdbqt: Path, dry_run: bool = True) -> PipelineConfig:
    ligands = tmp / "ligands"
    ligands.mkdir()
    output = tmp / "output"
    output.mkdir()
    return PipelineConfig(
        receptor_pdbqt=receptor_pdbqt,
        ligands_dir=ligands,
        output_dir=output,
        center=(0.0, 0.0, 0.0),
        npts=(40, 40, 40),
        dry_run=dry_run,
    )


# ---------------------------------------------------------------------------
# Heavy element list — everything in _UFF_RAW that is exotic
# ---------------------------------------------------------------------------

_ALL_HEAVY = sorted(_UFF_RAW.keys())


# ---------------------------------------------------------------------------
# Group 1: All UFF elements — parameter derivation sanity checks
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("symbol", _ALL_HEAVY)
def test_uff_params_exist_for_all_elements(symbol: str) -> None:
    """Every element in _UFF_RAW must produce valid AtomParams."""
    p = get_uff_params(symbol)
    assert p is not None, f"No params for {symbol}"
    assert p.Rii > 0, f"{symbol}: Rii must be positive"
    assert p.epsii > 0, f"{symbol}: epsii must be positive"
    assert p.r_cov > 0, f"{symbol}: r_cov must be positive"
    assert p.vol > 0, f"{symbol}: vol must be positive"


@pytest.mark.parametrize("symbol", _ALL_HEAVY)
def test_uff_volume_formula_consistency(symbol: str) -> None:
    """vol must equal (4/3)*pi*(Rii/2)^3 within rounding tolerance."""
    p = get_uff_params(symbol)
    assert p is not None
    expected = compute_vol(p.Rii)
    assert abs(p.vol - round(expected, 4)) < 0.01, (
        f"{symbol}: vol={p.vol}, expected≈{expected:.4f}"
    )


@pytest.mark.parametrize("symbol", _ALL_HEAVY)
def test_uff_solpar_reasonable(symbol: str) -> None:
    """solpar must be finite and in a plausible range."""
    p = get_uff_params(symbol)
    assert p is not None
    assert math.isfinite(p.solpar), f"{symbol}: solpar is not finite ({p.solpar})"
    # solpar is typically between -0.1 and +0.1 for AD4 convention
    assert -1.0 < p.solpar < 1.0, f"{symbol}: solpar={p.solpar} out of plausible range"


@pytest.mark.parametrize("symbol", _ALL_HEAVY)
def test_uff_is_exotic(symbol: str) -> None:
    """Every element in _UFF_RAW must be classified as exotic."""
    assert is_exotic(symbol), f"{symbol} should be exotic"


# ---------------------------------------------------------------------------
# Group 2: Heavy main-group elements — solvation classification
# ---------------------------------------------------------------------------

_NONPOLAR = {'B', 'Al', 'Si', 'Ge', 'Sn', 'Pb', 'Ga', 'In', 'Tl', 'As', 'Sb', 'Bi'}
_POLAR = {'Se', 'Te'}
_LANTHANIDE = {'La', 'Ce', 'Pr', 'Nd', 'Sm', 'Eu', 'Gd', 'Tb', 'Dy', 'Ho', 'Er', 'Yb', 'Lu'}
_METALS = set(_ALL_HEAVY) - _NONPOLAR - _POLAR - _LANTHANIDE


def test_solvation_class_nonpolar() -> None:
    for sym in _NONPOLAR:
        assert _solvation_class(sym) == 'nonpolar', f"{sym} should be nonpolar"


def test_solvation_class_polar() -> None:
    for sym in _POLAR:
        assert _solvation_class(sym) == 'polar', f"{sym} should be polar"


def test_solvation_class_metal() -> None:
    for sym in _METALS:
        assert _solvation_class(sym) == 'metal', f"{sym} should be metal"


def test_solvation_class_lanthanide() -> None:
    for sym in _LANTHANIDE:
        assert _solvation_class(sym) == 'lanthanide', f"{sym} should be lanthanide"


# ---------------------------------------------------------------------------
# Group 3: Complex coordination compounds — full pipeline dry run
# ---------------------------------------------------------------------------

def test_tungsten_complex(simple_receptor: Path) -> None:
    """W-containing organometallic: tungsten hexacarbonyl fragment."""
    mol = Chem.MolFromSmiles("[W](C)(C)(C)(C)(C)C")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "tungstate.sdf")

        result = process_ligand(cfg.ligands_dir / "tungstate.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "W" in result.exotic_types

        work = cfg.output_dir / "tungstate"
        gpf = (work / "tungstate.gpf").read_text()
        assert ".W.map" in gpf


def test_gold_complex(simple_receptor: Path) -> None:
    """Au(I) phosphine complex: Au-PPh3 simplified."""
    mol = Chem.MolFromSmiles("Cl[Au]P(c1ccccc1)(c2ccccc2)c3ccccc3")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "auph3.sdf")

        result = process_ligand(cfg.ligands_dir / "auph3.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Au" in result.exotic_types


def test_mercury_complex(simple_receptor: Path) -> None:
    """Hg organometallic: dimethylmercury."""
    mol = Chem.MolFromSmiles("C[Hg]C")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "hgdme.sdf")

        result = process_ligand(cfg.ligands_dir / "hgdme.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Hg" in result.exotic_types


def test_iridium_complex(simple_receptor: Path) -> None:
    """Ir organometallic fragment (Vaska's complex simplified)."""
    mol = Chem.MolFromSmiles("Cl[Ir](Cl)(P(c1ccccc1)(c2ccccc2)c3ccccc3)")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "ir_complex.sdf")

        result = process_ligand(cfg.ligands_dir / "ir_complex.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Ir" in result.exotic_types


def test_rhenium_complex(simple_receptor: Path) -> None:
    """Re organometallic: methyltrioxorhenium(VII)."""
    mol = Chem.MolFromSmiles("C[Re](=O)(=O)=O")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "mto.sdf")

        result = process_ligand(cfg.ligands_dir / "mto.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Re" in result.exotic_types


def test_palladium_complex(simple_receptor: Path) -> None:
    """Pd(II) square planar complex: PdCl2(PPh3)2 simplified."""
    mol = Chem.MolFromSmiles("Cl[Pd](Cl)(P(c1ccccc1)c2ccccc2)P(c3ccccc3)c4ccccc4")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "pd_complex.sdf")

        result = process_ligand(cfg.ligands_dir / "pd_complex.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Pd" in result.exotic_types


def test_ruthenium_complex(simple_receptor: Path) -> None:
    """Ru organometallic: ruthenocene fragment."""
    mol = Chem.MolFromSmiles("C1=C[CH]C=C1[Ru]C2=CC=C[CH]C=2")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "ruthenocene.sdf")

        result = process_ligand(cfg.ligands_dir / "ruthenocene.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Ru" in result.exotic_types


# ---------------------------------------------------------------------------
# Group 4: Multi-metal complexes — several heavy elements in one molecule
# ---------------------------------------------------------------------------

def test_multi_metal_pt_w(simple_receptor: Path) -> None:
    """Pt-W heterobimetallic complex (JIT must handle multiple exotics)."""
    mol = Chem.MolFromSmiles("O=[W](=O)(=O)O[Pt](N)(N)Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "ptw.sdf")

        result = process_ligand(cfg.ligands_dir / "ptw.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "W" in result.exotic_types
        assert "Pt" in result.exotic_types

        dat = (cfg.output_dir / "ptw" / "AD4_parameters_temp.dat").read_text()
        assert "atom_par W " in dat
        assert "atom_par Pt " in dat


def test_multi_metal_au_hg(simple_receptor: Path) -> None:
    """Au-Hg heterobimetallic."""
    mol = Chem.MolFromSmiles("Cl[Au]P(c1ccccc1)(c2ccccc2)c3ccccc3.[Hg]Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "au_hg.sdf")

        result = process_ligand(cfg.ligands_dir / "au_hg.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Au" in result.exotic_types
        assert "Hg" in result.exotic_types


def test_multi_metal_tri_iridium_rhenium_tungsten(simple_receptor: Path) -> None:
    """Three heavy metals: Ir + Re + W in one ligand."""
    mol = Chem.MolFromSmiles("C[Re](=O)(=O)=O.Cl[Ir](Cl)(Cl)Cl.[W](Cl)(Cl)(Cl)(Cl)(Cl)Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "ir_re_w.sdf")

        result = process_ligand(cfg.ligands_dir / "ir_re_w.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Ir" in result.exotic_types
        assert "Re" in result.exotic_types
        assert "W" in result.exotic_types

        gpf = (cfg.output_dir / "ir_re_w" / "ir_re_w.gpf").read_text()
        assert ".Ir.map" in gpf
        assert ".Re.map" in gpf
        assert ".W.map" in gpf


# ---------------------------------------------------------------------------
# Group 5: Heavy main-group — large organic molecules with metalloid atoms
# ---------------------------------------------------------------------------

def test_tin_organometallic(simple_receptor: Path) -> None:
    """Tetra-n-butyltin (organotin compound)."""
    mol = Chem.MolFromSmiles("CCCC[Sn](CCCC)(CCCC)CCCC")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "tbt.sdf")

        result = process_ligand(cfg.ligands_dir / "tbt.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Sn" in result.exotic_types


def test_lead_complex(simple_receptor: Path) -> None:
    """Tetraethyllead."""
    mol = Chem.MolFromSmiles("CC[Pb](CC)(CC)CC")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "tel.sdf")

        result = process_ligand(cfg.ligands_dir / "tel.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Pb" in result.exotic_types


def test_bismuth_complex(simple_receptor: Path) -> None:
    """Bismuth subsalicylate fragment."""
    mol = Chem.MolFromSmiles("O=C(Oc1ccccc1)O[Bi](O)(O)O")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "bi_subsalc.sdf")

        result = process_ligand(cfg.ligands_dir / "bi_subsalc.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Bi" in result.exotic_types


# ---------------------------------------------------------------------------
# Group 6: Period 4/5 transition metals — catalysis-relevant complexes
# ---------------------------------------------------------------------------

def test_copper_complex(simple_receptor: Path) -> None:
    """Cu(II) complex."""
    mol = Chem.MolFromSmiles("C[N+]1=C(C)C(=C(C)N=C1C)[Cu]N2C=CC=CC=2")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "cu_complex.sdf")

        result = process_ligand(cfg.ligands_dir / "cu_complex.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Cu" in result.exotic_types


def test_nickel_complex(simple_receptor: Path) -> None:
    """Ni(II) square planar complex."""
    mol = Chem.MolFromSmiles("C[Ni](C)(C)C")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "ni_complex.sdf")

        result = process_ligand(cfg.ligands_dir / "ni_complex.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Ni" in result.exotic_types


def test_silver_complex(simple_receptor: Path) -> None:
    """Ag(I) complex."""
    mol = Chem.MolFromSmiles("N#[Ag]")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "ag_cyanide.sdf")

        result = process_ligand(cfg.ligands_dir / "ag_cyanide.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Ag" in result.exotic_types


def test_cadmium_complex(simple_receptor: Path) -> None:
    """Cd(II) chloride."""
    mol = Chem.MolFromSmiles("Cl[Cd]Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "cdcl2.sdf")

        result = process_ligand(cfg.ligands_dir / "cdcl2.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Cd" in result.exotic_types


def test_cobalt_complex(simple_receptor: Path) -> None:
    """Co(III) ammine complex."""
    mol = Chem.MolFromSmiles("N[Co](N)(N)(N)(N)N")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "co_hexammine.sdf")

        result = process_ligand(cfg.ligands_dir / "co_hexammine.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Co" in result.exotic_types


def test_chromium_complex(simple_receptor: Path) -> None:
    """Cr(VI) chromate fragment."""
    mol = Chem.MolFromSmiles("O=[Cr](=O)(=O)=O")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "chromate.sdf")

        result = process_ligand(cfg.ligands_dir / "chromate.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Cr" in result.exotic_types


# ---------------------------------------------------------------------------
# Group 7: Early transition metals — Groups 3-5
# ---------------------------------------------------------------------------

def test_zirconium_complex(simple_receptor: Path) -> None:
    """Zr(IV) organometallic (zirconocene fragment)."""
    mol = Chem.MolFromSmiles("Cl[Zr](Cl)(C1=CC=CC=C1)C2=CC=CC=C2")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "zirconocene.sdf")

        result = process_ligand(cfg.ligands_dir / "zirconocene.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Zr" in result.exotic_types


def test_titanium_complex(simple_receptor: Path) -> None:
    """Ti(IV) alkoxide."""
    mol = Chem.MolFromSmiles("CCO[Ti](OCC)(OCC)OCC")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "ti_ethylate.sdf")

        result = process_ligand(cfg.ligands_dir / "ti_ethylate.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Ti" in result.exotic_types


def test_hafnium_complex(simple_receptor: Path) -> None:
    """Hf(IV) complex (hafnocene analog)."""
    mol = Chem.MolFromSmiles("Cl[Hf](Cl)(Cl)Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "hfcl4.sdf")

        result = process_ligand(cfg.ligands_dir / "hfcl4.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Hf" in result.exotic_types


def test_tantalum_complex(simple_receptor: Path) -> None:
    """Ta(V) chloride."""
    mol = Chem.MolFromSmiles("Cl[Ta](Cl)(Cl)(Cl)Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "tacl5.sdf")

        result = process_ligand(cfg.ligands_dir / "tacl5.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Ta" in result.exotic_types


def test_molybdenum_complex(simple_receptor: Path) -> None:
    """Mo(VI) oxo complex."""
    mol = Chem.MolFromSmiles("O=[Mo](=O)(O)O")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "molybdate.sdf")

        result = process_ligand(cfg.ligands_dir / "molybdate.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Mo" in result.exotic_types


def test_osmium_complex(simple_receptor: Path) -> None:
    """Os(VIII) oxide."""
    mol = Chem.MolFromSmiles("O=[Os](=O)(=O)=O")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "oso4.sdf")

        result = process_ligand(cfg.ligands_dir / "oso4.sdf", cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Os" in result.exotic_types


# ---------------------------------------------------------------------------
# Group 8: Audit log verification for heavy elements
# ---------------------------------------------------------------------------

def test_audit_log_heavy_elements(simple_receptor: Path) -> None:
    """Audit log must record entries for W, Ir, Re, Au, Hg runs."""
    mol = Chem.MolFromSmiles("[W](Cl)(Cl)(Cl)(Cl)(Cl)Cl")
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "tungstate.sdf")

        process_ligand(cfg.ligands_dir / "tungstate.sdf", cfg)

        audit = cfg.output_dir / "uff_audit.log"
        assert audit.exists()
        audit_text = audit.read_text()
        assert "W" in audit_text
        assert "UFF_Rappe1992" in audit_text


def test_audit_log_multi_metal(simple_receptor: Path) -> None:
    """Audit log must record ALL exotic types for multi-metal ligands."""
    mol = Chem.MolFromSmiles("C[Re](=O)(=O)=O.Cl[Ir](Cl)(Cl)Cl")
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, simple_receptor)
        _build_sdf(mol, cfg.ligands_dir / "re_ir.sdf")

        process_ligand(cfg.ligands_dir / "re_ir.sdf", cfg)

        audit = cfg.output_dir / "uff_audit.log"
        audit_text = audit.read_text()
        assert "Re" in audit_text
        assert "Ir" in audit_text


# ---------------------------------------------------------------------------
# Group 9: Parameter regression — verify Rii/epsii for heavy metals
# ---------------------------------------------------------------------------

_HEAVY_REFERENCE = {
    "W":  {"Rii": 2.734, "epsii": 0.067, "r_cov": 1.526},
    "Re": {"Rii": 2.892, "epsii": 0.066, "r_cov": 1.372},
    "Os": {"Rii": 2.789, "epsii": 0.037, "r_cov": 1.372},
    "Ir": {"Rii": 2.530, "epsii": 0.073, "r_cov": 1.371},
    "Pt": {"Rii": 2.453, "epsii": 0.080, "r_cov": 1.364},
    "Au": {"Rii": 2.934, "epsii": 0.039, "r_cov": 1.262},
    "Hg": {"Rii": 2.410, "epsii": 0.385, "r_cov": 1.340},
    "Ru": {"Rii": 2.963, "epsii": 0.056, "r_cov": 1.483},
    "Rh": {"Rii": 2.998, "epsii": 0.053, "r_cov": 1.526},
    "Pd": {"Rii": 2.909, "epsii": 0.048, "r_cov": 1.376},
    "Ag": {"Rii": 3.148, "epsii": 0.036, "r_cov": 1.646},
    "Mo": {"Rii": 2.719, "epsii": 0.056, "r_cov": 1.484},
    "Cu": {"Rii": 3.114, "epsii": 0.005, "r_cov": 1.457},
    "Sn": {"Rii": 4.209, "epsii": 0.567, "r_cov": 1.485},
    "Pb": {"Rii": 4.168, "epsii": 0.663, "r_cov": 1.459},
    "Bi": {"Rii": 4.316, "epsii": 0.518, "r_cov": 1.512},
}


@pytest.mark.parametrize("symbol,ref", _HEAVY_REFERENCE.items())
def test_heavy_element_regression(symbol: str, ref: dict) -> None:
    """Rii, epsii, r_cov must match Rappé 1992 within tolerance."""
    p = get_uff_params(symbol)
    assert p is not None
    assert abs(p.Rii - ref["Rii"]) < 1e-3, f"{symbol} Rii: {p.Rii} != {ref['Rii']}"
    assert abs(p.epsii - ref["epsii"]) < 1e-3, f"{symbol} epsii: {p.epsii} != {ref['epsii']}"
    assert abs(p.r_cov - ref["r_cov"]) < 1e-3, f"{symbol} r_cov: {p.r_cov} != {ref['r_cov']}"
