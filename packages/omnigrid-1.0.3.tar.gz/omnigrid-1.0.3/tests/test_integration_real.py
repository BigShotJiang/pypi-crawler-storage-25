"""
Integration tests with real receptor structures from RCSB PDB.

Validates that OmniGrid produces correct AutoGrid4 maps for biologically
relevant targets:
    - 3ZNT (OXA-24 carbapenemase) — beta-lactamase target
    - 8FQM (ADC-7 beta-lactamase) — AmpC target
    - 3UDX (PBP1a from MRSA) — penicillin-binding protein

Tests download real PDB files, convert them to PDBQT, prepare exotic-element
ligands, run the full OmniGrid pipeline, and verify AutoGrid4 exit codes.
"""
from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

import pytest
from rdkit import Chem
from rdkit.Chem import AllChem

from omnigrid.fetcher import fetch_pdb_structures
from omnigrid.gpf_generator import GridConfig, auto_grid_box, detect_receptor_types, generate_gpf
from omnigrid.params_writer import UFFAuditLog, write_temp_params
from omnigrid.pipeline import PipelineConfig, process_ligand
from omnigrid.receptor_preparer import prepare_receptor
from omnigrid.runner import run_autogrid

autogrid4_required = pytest.mark.skipif(
    shutil.which("autogrid4") is None,
    reason="autogrid4 not in PATH",
)


def _build_sdf(mol: Chem.Mol, path: Path) -> None:
    writer = Chem.SDWriter(str(path))
    writer.write(mol)
    writer.close()


def _make_cfg(tmp: Path, receptor_pdbqt: Path, dry_run: bool = True) -> PipelineConfig:
    ligands = tmp / "ligands"
    ligands.mkdir()
    output = tmp / "output"
    output.mkdir()
    return PipelineConfig(
        receptor_pdbqt=receptor_pdbqt,
        ligands_dir=ligands,
        output_dir=output,
        center=(0.0, 0.0, 0.0),
        npts=(40, 40, 40),
        dry_run=dry_run,
    )


# ---------------------------------------------------------------------------
# Fixture: download and prepare real PDB receptors
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def real_receptors():
    """Download 3ZNT, 8FQM, 3UDX from RCSB and prepare as PDBQT.

    Returns dict: {"3ZNT": Path, "8FQM": Path, "3UDX": Path}
    Skipped if network is unavailable.
    """
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        pdbs = fetch_pdb_structures(["3ZNT", "8FQM", "3UDX"], tmp_path, n_workers=3)
        if not pdbs:
            pytest.skip("Could not download PDB structures — network unavailable")

        prepared = {}
        for pdb_id, pdb_file in pdbs.items():
            pdbqt = tmp_path / f"{pdb_id}.pdbqt"
            prepare_receptor(pdb_file, pdbqt)
            assert pdbqt.exists(), f"PDBQT not created for {pdb_id}"
            prepared[pdb_id] = pdbqt

        yield prepared


# ---------------------------------------------------------------------------
# Test 1: Real receptor — detect valid AD4 types
# ---------------------------------------------------------------------------

def test_real_receptor_has_standard_types(real_receptors):
    """Each real receptor should contain standard AD4 types (C, N, OA, etc.)."""
    for pdb_id, pdbqt_path in real_receptors.items():
        types = detect_receptor_types(pdbqt_path)
        assert len(types) > 2, f"{pdb_id}: expected multiple atom types, got {types}"
        assert "C" in types or "A" in types, f"{pdb_id}: no carbon type found in {types}"
        assert "OA" in types or "N" in types or "NA" in types, \
            f"{pdb_id}: no oxygen/nitrogen type found in {types}"


# ---------------------------------------------------------------------------
# Test 2: Real receptor + Boron ligand — dry run
# ---------------------------------------------------------------------------

def test_real_receptor_boron_dry_run(real_receptors):
    """Run pipeline with real 3UDX receptor and B-containing ligand (dry run)."""
    receptor = real_receptors["3UDX"]

    mol = Chem.MolFromSmiles("B(O)(O)c1ccccc1")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, receptor)
        sdf = cfg.ligands_dir / "phenylboronic.sdf"
        _build_sdf(mol, sdf)

        result = process_ligand(sdf, cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "B" in result.exotic_types
        assert result.pdbqt_prepared, "PDBQT should have been auto-generated"

        work = cfg.output_dir / "phenylboronic"
        assert (work / "AD4_parameters_temp.dat").exists()
        assert (work / "phenylboronic.gpf").exists()
        assert "B" in (work / "phenylboronic.gpf").read_text()


# ---------------------------------------------------------------------------
# Test 3: Real receptor + Platinum ligand — dry run
# ---------------------------------------------------------------------------

def test_real_receptor_platinum_dry_run(real_receptors):
    """Run pipeline with real 3ZNT receptor and Pt-containing ligand (dry run)."""
    receptor = real_receptors["3ZNT"]

    mol = Chem.MolFromSmiles("N[Pt](N)(Cl)Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, receptor)
        sdf = cfg.ligands_dir / "cisplatin.sdf"
        _build_sdf(mol, sdf)

        result = process_ligand(sdf, cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "Pt" in result.exotic_types

        work = cfg.output_dir / "cisplatin"
        gpf_text = (work / "cisplatin.gpf").read_text()
        assert "Pt" in gpf_text
        assert ".Pt.map" in gpf_text
        assert "parameter_file AD4_parameters_temp.dat" in gpf_text


# ---------------------------------------------------------------------------
# Test 4: Real receptor + multi-exotic ligand (B + Si) — dry run
# ---------------------------------------------------------------------------

def test_real_receptor_multi_exotic_dry_run(real_receptors):
    """Run pipeline with receptor and ligand containing B + Si (borono-silane)."""
    receptor = real_receptors["8FQM"]

    mol = Chem.MolFromSmiles("B(O)C[Si](C)(C)C")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, receptor)
        sdf = cfg.ligands_dir / "borono_silane.sdf"
        _build_sdf(mol, sdf)

        result = process_ligand(sdf, cfg)
        assert result.success, f"Pipeline failed: {result.error}"
        assert "B" in result.exotic_types
        assert "Si" in result.exotic_types

        dat_content = (cfg.output_dir / "borono_silane" / "AD4_parameters_temp.dat").read_text()
        assert "atom_par B " in dat_content
        assert "atom_par Si " in dat_content


# ---------------------------------------------------------------------------
# Test 5: Real receptor — auto_grid_box computes valid grid
# ---------------------------------------------------------------------------

def test_real_receptor_auto_grid_box(real_receptors):
    """auto_grid_box should produce even npts and valid centre for real PDBQT."""
    receptor = real_receptors["3UDX"]

    mol = Chem.MolFromSmiles("CCO")
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        sdf = tmp_path / "ethanol.sdf"
        _build_sdf(mol, sdf)

        cfg = _make_cfg(tmp_path, receptor)
        result = process_ligand(sdf, cfg)
        assert result.success

        work = cfg.output_dir / "ethanol"
        pdbqt = work / "ethanol.pdbqt"
        assert pdbqt.exists()

        centre, npts = auto_grid_box(pdbqt)
        assert all(n % 2 == 0 for n in npts), f"npts not all even: {npts}"
        assert all(-1000 < c < 1000 for c in centre), f"centre out of range: {centre}"


# ---------------------------------------------------------------------------
# Test 6: AutoGrid4 smoke-run with real receptor + Boron ligand
# ---------------------------------------------------------------------------

@autogrid4_required
def test_autogrid4_real_receptor_boron(real_receptors):
    """Run AutoGrid4 for real with 3UDX + B ligand — exit code 0, maps generated."""
    receptor = real_receptors["3UDX"]

    mol = Chem.MolFromSmiles("B(O)(O)c1ccccc1")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, receptor, dry_run=False)
        sdf = cfg.ligands_dir / "phenylboronic.sdf"
        _build_sdf(mol, sdf)

        result = process_ligand(sdf, cfg)
        assert result.success, f"AutoGrid4 failed: {result.error}"
        assert result.log is not None
        assert result.log.exists()

        work = cfg.output_dir / "phenylboronic"
        map_files = list(work.glob("*.map"))
        assert len(map_files) > 0, "No .map files generated"

        b_maps = [m for m in map_files if ".B.map" in str(m)]
        assert len(b_maps) == 1, "Expected exactly one B.map file"


# ---------------------------------------------------------------------------
# Test 7: AutoGrid4 smoke-run with real receptor + Platinum ligand
# ---------------------------------------------------------------------------

@autogrid4_required
def test_autogrid4_real_receptor_platinum(real_receptors):
    """Run AutoGrid4 for real with 3ZNT + Pt ligand — no buffer overflow."""
    receptor = real_receptors["3ZNT"]

    mol = Chem.MolFromSmiles("N[Pt](N)(Cl)Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, receptor, dry_run=False)
        sdf = cfg.ligands_dir / "cisplatin.sdf"
        _build_sdf(mol, sdf)

        result = process_ligand(sdf, cfg)
        assert result.success, f"AutoGrid4 failed with Pt: {result.error}"
        assert result.log is not None

        work = cfg.output_dir / "cisplatin"
        map_files = list(work.glob("*.map"))
        pt_maps = [m for m in map_files if ".Pt.map" in str(m)]
        assert len(pt_maps) == 1, "Expected exactly one Pt.map file"


# ---------------------------------------------------------------------------
# Test 8: AutoGrid4 with all three real receptors (regression)
# ---------------------------------------------------------------------------

@autogrid4_required
def test_autogrid4_all_real_receptors(real_receptors):
    """Run AutoGrid4 with all three receptors + B ligand — all must succeed."""
    mol = Chem.MolFromSmiles("B(O)(O)c1ccccc1")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    for pdb_id, receptor in real_receptors.items():
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            cfg = _make_cfg(tmp_path, receptor, dry_run=False)
            sdf = cfg.ligands_dir / "phenylboronic.sdf"
            _build_sdf(mol, sdf)

            result = process_ligand(sdf, cfg)
            assert result.success, \
                f"AutoGrid4 failed for {pdb_id}: {result.error}"

            work = cfg.output_dir / "phenylboronic"
            map_files = list(work.glob("*.map"))
            assert len(map_files) >= 5, \
                f"{pdb_id}: expected >= 5 map files, got {len(map_files)}: {[m.name for m in map_files]}"


# ---------------------------------------------------------------------------
# Test 9: Audit log records all exotic types for real-receptor runs
# ---------------------------------------------------------------------------

def test_audit_log_real_receptors(real_receptors):
    """UFF audit log must record B, Pt, Si entries for real-receptor pipeline runs."""
    receptor = real_receptors["3UDX"]

    mol = Chem.MolFromSmiles("B(O)(O)c1ccccc1")
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, receptor)
        sdf = cfg.ligands_dir / "phenylboronic.sdf"
        _build_sdf(mol, sdf)

        process_ligand(sdf, cfg)

        audit = cfg.output_dir / "uff_audit.log"
        assert audit.exists()
        audit_text = audit.read_text()
        assert "B" in audit_text
        assert "UFF_Rappe1992" in audit_text


# ---------------------------------------------------------------------------
# Test 10: Parameter regression with real-receptor generated .dat
# ---------------------------------------------------------------------------

def test_param_regression_real_receptor(real_receptors):
    """Parse .dat generated during real-receptor run and verify UFF values."""
    receptor = real_receptors["3ZNT"]

    mol = Chem.MolFromSmiles("N[Pt](N)(Cl)Cl")
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cfg = _make_cfg(tmp_path, receptor)
        sdf = cfg.ligands_dir / "cisplatin.sdf"
        _build_sdf(mol, sdf)

        process_ligand(sdf, cfg)

        dat = cfg.output_dir / "cisplatin" / "AD4_parameters_temp.dat"
        content = dat.read_text()

        reference = {
            "Pt": {"Rii": 2.453, "epsii": 0.080},
            "CL": None,
        }

        for line in content.splitlines():
            stripped = line.strip()
            if not stripped or not stripped.startswith("atom_par "):
                continue
            parts = stripped.split()
            if len(parts) < 5:
                continue
            symbol = parts[1]
            if symbol in reference and reference[symbol] is not None:
                ref = reference[symbol]
                rii = float(parts[2])
                epsii = float(parts[3])
                assert abs(rii - ref["Rii"]) < 1e-3, \
                    f"{symbol} Rii: expected {ref['Rii']}, got {rii}"
                assert abs(epsii - ref["epsii"]) < 1e-3, \
                    f"{symbol} epsii: expected {ref['epsii']}, got {epsii}"
