"""
Tests for pdbqt_writer — preparation of PDBQT files with exotic elements.

Coverage:
    1. Pt (Platinum) — exotic element: type='Pt', charge=0.000 (Gasteiger NaN fallback).
    2. B (Boron) — exotic main-group: type='B' present in PDBQT.
    3. Carbon hybridisation: aromatic → 'A', aliphatic → 'C'.
    4. PDBQT structural integrity: ROOT/ENDROOT, TORSDOF, column layout.
    5. Round-trip: SDF → PDBQT → read-back charge conservation.
"""
from __future__ import annotations

import tempfile
from pathlib import Path

import pytest
from rdkit import Chem
from rdkit.Chem import AllChem

from omnigrid.pdbqt_writer import prepare_pdbqt


def _build_sdf(mol: Chem.Mol, path: Path) -> None:
    writer = Chem.SDWriter(str(path))
    writer.write(mol)
    writer.close()


def _parse_pdbqt_lines(pdbqt_path: Path) -> list[str]:
    return [
        line for line in pdbqt_path.read_text().splitlines()
        if line.startswith(("ATOM", "HETATM"))
    ]


# ---------------------------------------------------------------------------
# Test 1: Pt — exotic metal, Gasteiger NaN → charge 0.000
# ---------------------------------------------------------------------------

def test_platinum_pdbqt_has_pt_type() -> None:
    """Pt atom must appear with type 'Pt' in columns 78-79 (case-sensitive)."""
    mol = Chem.MolFromSmiles("[Pt]")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        sdf = Path(tmp) / "pt.sdf"
        pdbqt = Path(tmp) / "pt.pdbqt"
        _build_sdf(mol, sdf)

        prepare_pdbqt(sdf, pdbqt)
        assert pdbqt.exists()

        atom_lines = _parse_pdbqt_lines(pdbqt)
        pt_lines = [l for l in atom_lines if l[77:79].strip() == "Pt"]
        assert len(pt_lines) >= 1, "No atom with AD4 type 'Pt' found in PDBQT"


def test_platinum_charge_is_zero() -> None:
    """Gasteiger fails for Pt → charge must be 0.000 in columns 70-76."""
    mol = Chem.MolFromSmiles("[Pt]")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        sdf = Path(tmp) / "pt.sdf"
        pdbqt = Path(tmp) / "pt.pdbqt"
        _build_sdf(mol, sdf)

        prepare_pdbqt(sdf, pdbqt)

        atom_lines = _parse_pdbqt_lines(pdbqt)
        pt_lines = [l for l in atom_lines if l[77:79].strip() == "Pt"]
        assert len(pt_lines) >= 1

        for line in pt_lines:
            charge_str = line[69:76].strip()
            charge = float(charge_str)
            assert abs(charge) < 1e-6, f"Pt charge expected 0.000, got {charge}"


def test_platinum_has_root_and_torsdof() -> None:
    """PDBQT must contain ROOT and TORSDOF keywords."""
    mol = Chem.MolFromSmiles("[Pt]")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        sdf = Path(tmp) / "pt.sdf"
        pdbqt = Path(tmp) / "pt.pdbqt"
        _build_sdf(mol, sdf)

        prepare_pdbqt(sdf, pdbqt)
        content = pdbqt.read_text()

        assert "ROOT" in content, "ROOT keyword missing from PDBQT"
        assert "ENDROOT" in content, "ENDROOT keyword missing from PDBQT"
        assert "TORSDOF" in content, "TORSDOF keyword missing from PDBQT"


# ---------------------------------------------------------------------------
# Test 2: Boron — exotic main-group element
# ---------------------------------------------------------------------------

def test_boron_pdbqt_has_b_type() -> None:
    """B atom must appear with type 'B' in columns 78-79."""
    mol = Chem.MolFromSmiles("Bc1ccccc1")  # phenylboronic acid
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        sdf = Path(tmp) / "boron.sdf"
        pdbqt = Path(tmp) / "boron.pdbqt"
        _build_sdf(mol, sdf)

        prepare_pdbqt(sdf, pdbqt)
        assert pdbqt.exists()

        atom_lines = _parse_pdbqt_lines(pdbqt)
        b_lines = [l for l in atom_lines if l[77:79].strip() == "B"]
        assert len(b_lines) >= 1, "No atom with AD4 type 'B' found in PDBQT"


# ---------------------------------------------------------------------------
# Test 3: Carbon hybridisation — aromatic vs aliphatic
# ---------------------------------------------------------------------------

def test_aromatic_carbon_is_type_a() -> None:
    """Aromatic carbons in benzene must be typed 'A' (not 'C')."""
    mol = Chem.MolFromSmiles("c1ccccc1")  # benzene
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        sdf = Path(tmp) / "benzene.sdf"
        pdbqt = Path(tmp) / "benzene.pdbqt"
        _build_sdf(mol, sdf)

        prepare_pdbqt(sdf, pdbqt)

        atom_lines = _parse_pdbqt_lines(pdbqt)
        c_types = {l[77:79].strip() for l in atom_lines if l[77:79].strip() in ("A", "C")}
        assert "A" in c_types, "Aromatic carbons should be typed 'A'"


def test_aliphatic_carbon_is_type_c() -> None:
    """Aliphatic carbons in ethane must be typed 'C' (not 'A')."""
    mol = Chem.MolFromSmiles("CC")  # ethane
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        sdf = Path(tmp) / "ethane.sdf"
        pdbqt = Path(tmp) / "ethane.pdbqt"
        _build_sdf(mol, sdf)

        prepare_pdbqt(sdf, pdbqt)

        atom_lines = _parse_pdbqt_lines(pdbqt)
        c_types = {l[77:79].strip() for l in atom_lines if l[77:79].strip() in ("A", "C")}
        assert "C" in c_types, "Aliphatic carbons should be typed 'C'"
        assert "A" not in c_types, "Aliphatic carbons should NOT be typed 'A'"


# ---------------------------------------------------------------------------
# Test 4: PDBQT column layout fidelity
# ---------------------------------------------------------------------------

def test_pdbqt_column_layout() -> None:
    """Verify fixed-column format: record, serial, name, resname, xyz, occ, B, charge, type."""
    mol = Chem.MolFromSmiles("CCO")  # ethanol
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        sdf = Path(tmp) / "ethanol.sdf"
        pdbqt = Path(tmp) / "ethanol.pdbqt"
        _build_sdf(mol, sdf)

        prepare_pdbqt(sdf, pdbqt)
        atom_lines = _parse_pdbqt_lines(pdbqt)
        assert len(atom_lines) >= 3  # at least C, C, O heavy atoms

        for line in atom_lines:
            assert line[0:6] in ("ATOM  ", "HETATM"), f"Bad record type: {line[0:6]!r}"
            serial = int(line[6:11])
            assert serial > 0, f"Invalid serial: {serial}"
            resname = line[17:20].strip()
            assert resname == "LIG", f"Expected residue name 'LIG', got {resname!r}"
            x = float(line[30:38])
            y = float(line[38:46])
            z = float(line[46:54])
            assert -999 < x < 999, f"X out of range: {x}"
            assert -999 < y < 999, f"Y out of range: {y}"
            assert -999 < z < 999, f"Z out of range: {z}"
            occ = float(line[54:60])
            assert abs(occ - 1.0) < 1e-6, f"Expected occupancy 1.0, got {occ}"
            bfac = float(line[60:66])
            assert abs(bfac) < 1e-6, f"Expected B-factor 0.0, got {bfac}"
            charge_str = line[69:76].strip()
            float(charge_str)  # must be parseable
            ad4_type = line[77:79].strip()
            assert len(ad4_type) >= 1, f"Empty AD4 type in line: {line!r}"


# ---------------------------------------------------------------------------
# Test 5: Cisplatin-like Pt complex (organometallic)
# ---------------------------------------------------------------------------

def test_cisplatin_pdbqt() -> None:
    """Cisplatin analogue [Pt] with Cl and N ligands — all exotic types present."""
    mol = Chem.MolFromSmiles("[NH3][Pt]([NH3])(Cl)Cl")
    assert mol is not None
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())

    with tempfile.TemporaryDirectory() as tmp:
        sdf = Path(tmp) / "cisplatin.sdf"
        pdbqt = Path(tmp) / "cisplatin.pdbqt"
        _build_sdf(mol, sdf)

        prepare_pdbqt(sdf, pdbqt)
        content = pdbqt.read_text()
        atom_lines = _parse_pdbqt_lines(pdbqt)

        types_found = {l[77:79].strip() for l in atom_lines}
        assert "Pt" in types_found, "Pt type missing from cisplatin PDBQT"

        assert "ROOT" in content
        assert "TORSDOF" in content


# ---------------------------------------------------------------------------
# Test 6: Round-trip — SDF → PDBQT → read-back charge conservation
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("smiles, name", [
    ("CCO", "ethanol"),
    ("[NH3][Pt]([NH3])(Cl)Cl", "cisplatin"),
    ("CC(C)C[C@@H](B(O)O)NC(=O)[C@H](Cc1ccccc1)NC(=O)c1cnccn1", "bortezomib"),
])
def test_pdbqt_roundtrip_charge_conservation(smiles: str, name: str) -> None:
    """PDBQT write-then-read-back: total charge ≈ 0, heavy-atom count preserved."""
    mol = Chem.MolFromSmiles(smiles)
    assert mol is not None, f"SMILES failed: {smiles}"
    mol = Chem.AddHs(mol)
    AllChem.EmbedMolecule(mol, AllChem.ETKDGv3())
    n_heavy = sum(1 for a in mol.GetAtoms() if a.GetAtomicNum() != 1)

    with tempfile.TemporaryDirectory() as tmp:
        sdf = Path(tmp) / f"{name}.sdf"
        pdbqt = Path(tmp) / f"{name}.pdbqt"
        _build_sdf(mol, sdf)
        prepare_pdbqt(sdf, pdbqt)
        assert pdbqt.exists()

        atom_lines = _parse_pdbqt_lines(pdbqt)

        # All heavy atoms from the original must appear in the PDBQT
        # (polar H on N/O/S may also be kept as HD type — extra is OK)
        assert len(atom_lines) >= n_heavy, (
            f"PDBQT has {len(atom_lines)} atoms, expected ≥{n_heavy} heavy atoms"
        )

        # Identify the heavy-element lines in the PDBQT by non-HD type
        heavy_in_pdbqt = [
            l for l in atom_lines
            if l[77:79].strip() != "HD"
        ]
        assert len(heavy_in_pdbqt) == n_heavy, (
            f"Expected {n_heavy} non-HD atoms, got {len(heavy_in_pdbqt)}"
        )

        # Every charge must be parseable and sum ≈ 0
        total_q = 0.0
        for line in atom_lines:
            charge_str = line[69:76].strip()
            assert charge_str, f"Empty charge field in: {line!r}"
            total_q += float(charge_str)

        assert abs(total_q) < 0.01, (
            f"Net charge after H-redistribution: {total_q:+.4f} (expected ~0)"
        )
