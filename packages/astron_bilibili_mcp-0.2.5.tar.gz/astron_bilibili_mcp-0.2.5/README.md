# 哔哩哔哩公开内容 MCP Server

## 概述

`Astron-bilibili-mcp` 是一个基于 MCP 协议的哔哩哔哩工具服务，直接调用哔哩哔哩游客态公开接口获取公开内容，无需额外部署后端服务。

当前推荐工程形态：
- 使用 `MCP Python SDK`
- 使用单文件 `server.py` 承载工具定义和 HTTP 调用
- 通过独立 `pyproject` 打包
- 支持 `uvx` 一键启动
- 通过环境变量配置超时和 User-Agent

当前提供 6 个原子工具：
- `get_hot_list`
- `get_feed_list`
- `search_content`
- `get_content_detail`
- `get_author_profile`
- `get_author_content_list`


## 工具列表

### 1. 获取热榜 `get_hot_list`
- 描述：读取 Bilibili 热榜。
- 参数：
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 2. 获取信息流 `get_feed_list`
- 描述：读取 Bilibili 公开信息流。
- 参数：
  - `channel`：频道，当前游客态实现中保留该参数但不强依赖
  - `cursor`：分页游标，默认空，内部按页码处理
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 3. 搜索内容 `search_content`
- 描述：搜索 Bilibili 公开视频内容。
- 参数：
  - `query`：搜索词，必填
  - `cursor`：分页游标，默认空，内部按页码处理
  - `limit`：返回条数，默认 `20`

### 4. 获取内容详情 `get_content_detail`
- 描述：读取 Bilibili 视频详情。
- 参数：
  - `content_id`：内容 ID，例如 `BV1RYXQBKEEd`
  - `url`：内容完整 URL

### 5. 获取作者主页 `get_author_profile`
- 描述：读取 Bilibili 作者公开主页。
- 参数：
  - `author_id`：作者 ID 或作者名
  - `url`：作者主页 URL

### 6. 获取作者作品列表 `get_author_content_list`
- 描述：读取 Bilibili 作者公开作品列表。
- 参数：
  - `author_id`：作者 ID 或作者名
  - `url`：作者主页 URL
  - `cursor`：分页游标，默认空，内部按页码处理
  - `limit`：返回条数，默认 `20`


## 环境变量

这个包默认不需要认证信息。

可选环境变量：

```bash
export BILIBILI_MCP_TIMEOUT_SECONDS="30"
export BILIBILI_MCP_USER_AGENT="Mozilla/5.0 ..."
```

说明：
- `BILIBILI_MCP_TIMEOUT_SECONDS` 控制公开接口请求超时。
- `BILIBILI_MCP_USER_AGENT` 用于覆盖默认请求头。


## 安装与启动

### 推荐方式：使用 uvx 一键启动

由于 `bilibili-mcp` 这个项目名已被占用，当前包名使用 `Astron-bilibili-mcp`。

```bash
uvx --from astron-bilibili-mcp astron-bilibili-mcp
```

如果你还没有安装 `uv` / `uvx`，可先执行：

```bash
curl -fsSL https://install.astral.sh/uv | bash
```

### 使用 pip 安装

```bash
pip install astron-bilibili-mcp
bilibili-mcp
```

### 本地源码运行

```bash
cd MCP/bilibili-mcp
PYTHONPATH=src python3 -m bilibili_mcp.server
```


## 客户端配置

### 使用 uvx

```json
{
  "mcpServers": {
    "bilibili-mcp": {
      "command": "uvx",
      "args": ["--from", "astron-bilibili-mcp", "astron-bilibili-mcp"],
      "env": {
        "BILIBILI_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```

### 使用本地源码

```json
{
  "mcpServers": {
    "bilibili-mcp": {
      "command": "python3",
      "args": ["-m", "bilibili_mcp.server"],
      "env": {
        "PYTHONPATH": "/path/to/MCP/bilibili-mcp/src",
        "BILIBILI_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```


## 平台差异说明

1. 这个 MCP 直接请求哔哩哔哩游客态公开接口，不依赖额外的 Astron 后端服务。
2. 当前仅面向公开内容能力，不包含登录态、私有内容或用户专属数据。
3. 返回结果尽量保持结构化 JSON，便于 Cursor、Claude Desktop 等客户端继续消费。
4. 游客态公开接口可能受网络、地区或平台风控影响，偶发失败时建议稍后重试。


## 发布说明

```bash
cd MCP/bilibili-mcp
rm -rf build dist src/*.egg-info
python3 -m build --no-isolation
python3 -m twine check dist/*
python3 -m twine upload dist/*
```


## License

Apache License 2.0. See `LICENSE`.
