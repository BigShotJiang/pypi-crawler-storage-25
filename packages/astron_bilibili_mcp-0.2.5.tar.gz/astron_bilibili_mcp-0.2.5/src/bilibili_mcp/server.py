"""Astron Bilibili MCP server."""

from __future__ import annotations

import html as html_lib
import os
import re
from urllib.parse import quote
from datetime import datetime, timezone
from typing import Any

import requests
from mcp.server.fastmcp import Context, FastMCP

from bilibili_mcp import __version__


HOME_URL = "https://www.bilibili.com/"
POPULAR_API_URL = "https://api.bilibili.com/x/web-interface/popular"
SEARCH_TYPE_API_URL = "https://api.bilibili.com/x/web-interface/search/type"
VIDEO_VIEW_API_URL = "https://api.bilibili.com/x/web-interface/view"
AUTHOR_CARD_API_URL = "https://api.bilibili.com/x/web-interface/card"
SPACE_URL_TEMPLATE = "https://space.bilibili.com/{author_id}"
VIDEO_URL_TEMPLATE = "https://www.bilibili.com/video/{content_id}"
SEARCH_URL_TEMPLATE = "https://search.bilibili.com/all?keyword={query}"

AUTHOR_CONTENT_SCAN_MAX_PAGES = 8
AUTHOR_CONTENT_SEARCH_PAGE_SIZE = 50

SPACE_ID_RE = re.compile(r"space\.bilibili\.com/(\d+)")
BV_RE = re.compile(r"(BV[0-9A-Za-z]+)")
AV_RE = re.compile(r"(?:^|/)(av\d+)(?:$|[/?#])", re.IGNORECASE)
TAG_RE = re.compile(r"<[^>]+>")
PLACEHOLDER_TEXT_RE = re.compile(r"^[-_=~.·•,，。!！?？:：/\\\\|]+$")


def get_timeout_seconds() -> float:
    raw = os.getenv("BILIBILI_MCP_TIMEOUT_SECONDS", "30").strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError("BILIBILI_MCP_TIMEOUT_SECONDS 必须是数字") from exc
    if value <= 0:
        raise RuntimeError("BILIBILI_MCP_TIMEOUT_SECONDS 必须大于 0")
    return value


def get_user_agent() -> str:
    value = os.getenv("BILIBILI_MCP_USER_AGENT", "").strip()
    if value:
        return value
    return (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 "
        f"Astron-Bilibili-MCP/{__version__}"
    )


def create_session(*, prime_home: bool = False) -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "Accept": "application/json, text/plain, */*",
            "User-Agent": get_user_agent(),
        }
    )
    if prime_home:
        _prime_home(session)
    return session


def _prime_home(session: requests.Session) -> None:
    try:
        session.get(HOME_URL, timeout=get_timeout_seconds())
    except requests.RequestException:
        pass


def _request_json(
    session: requests.Session,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    referer: str = "",
    prime_before_request: bool = True,
):
    if prime_before_request:
        _prime_home(session)

    for attempt in range(2):
        headers = {"Referer": referer or HOME_URL}
        try:
            response = session.get(
                url,
                params=params,
                headers=headers,
                timeout=get_timeout_seconds(),
            )
        except requests.RequestException as exc:
            raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

        if response.status_code == 412 and attempt == 0:
            _prime_home(session)
            continue
        if response.status_code != 200:
            raise RuntimeError(
                f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:500]}"
            )

        try:
            payload = response.json()
        except ValueError as exc:
            raise RuntimeError(f"调用失败: 响应不是合法 JSON; url={response.url}") from exc

        if not isinstance(payload, dict):
            raise RuntimeError(f"调用失败: 响应不是对象; url={response.url}")

        code = payload.get("code")
        if code in {-412, -799} and attempt == 0:
            _prime_home(session)
            continue
        if code != 0:
            raise RuntimeError(
                f"调用失败: url={response.url}; code={code}; message={payload.get('message')}"
            )
        return payload

    raise RuntimeError(f"调用失败: 访问 {url} 时触发风控，请稍后重试")


def _normalize_limit(limit: int, *, maximum: int = 50) -> int:
    value = _to_int(limit)
    if value is None:
        return 20
    return max(1, min(value, maximum))


def _parse_page_cursor(cursor: str) -> int:
    value = _to_int(cursor)
    if value is None or value <= 0:
        return 1
    return value


def _to_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    text = str(value).strip().replace(",", "")
    if not text:
        return None
    try:
        return int(text)
    except ValueError:
        try:
            return int(float(text))
        except ValueError:
            return None


def _as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _as_list(value: Any) -> list[Any]:
    return value if isinstance(value, list) else []


def _unix_to_iso(value: int | str | None) -> str:
    timestamp = _to_int(value)
    if timestamp is None:
        return ""
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).astimezone().isoformat()


def _current_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat()


def clean_text(value: str) -> str:
    text = html_lib.unescape(value or "")
    text = TAG_RE.sub(" ", text)
    return " ".join(text.split())


def normalize_body_text(value: str) -> str:
    text = clean_text(value)
    if not text:
        return ""
    if PLACEHOLDER_TEXT_RE.fullmatch(text):
        return ""
    if text in {"-", "--", "---", "暂无简介", "暂无描述", "简介", "无"}:
        return ""
    return text


def _extract_video_body(item: dict[str, Any]) -> str:
    desc_v2 = item.get("desc_v2")
    desc_v2_parts: list[str] = []
    if isinstance(desc_v2, list):
        for part in desc_v2:
            if isinstance(part, dict):
                text = normalize_body_text(str(part.get("raw_text") or part.get("text") or ""))
                if text:
                    desc_v2_parts.append(text)
    return normalize_body_text(
        _first_text(
            item.get("desc"),
            item.get("description"),
            "\n".join(desc_v2_parts),
            item.get("dynamic"),
            item.get("subtitle"),
        )
    )


def _normalized_result_type(value: Any) -> str:
    text = clean_text(str(value or ""))
    return text or "real"


def _is_real_content_item(item: dict[str, Any]) -> bool:
    if not item:
        return False
    return _normalized_result_type(item.get("result_type")) == "real" and bool(clean_text(str(item.get("content", ""))))


def _filter_real_content_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [item for item in items if _is_real_content_item(item)]


def _resolve_list_meta(items: list[dict[str, Any]]) -> tuple[str, str]:
    if not items:
        return "empty", ""
    result_types = [_normalized_result_type(item.get("result_type")) for item in items]
    if any(result_type == "real" for result_type in result_types):
        return "ok", "real"
    unique = {result_type for result_type in result_types if result_type}
    if len(unique) == 1:
        return "degraded", next(iter(unique))
    return "degraded", "mixed"


def _contains_keyword(item: dict[str, Any], keyword: str) -> bool:
    normalized_keyword = clean_text(keyword).lower()
    if not normalized_keyword:
        return False
    haystack = " ".join(
        [
            clean_text(str(item.get("title", ""))),
            clean_text(str(item.get("summary", ""))),
            clean_text(str(item.get("content", ""))),
            clean_text(str(item.get("author_name", ""))),
            " ".join(_parse_tags(item.get("tags", []))),
        ]
    ).lower()
    return normalized_keyword in haystack


def _parse_tags(raw: Any) -> list[str]:
    text = clean_text(str(raw or ""))
    if not text:
        return []
    return [tag for tag in (clean_text(part) for part in text.split(",")) if tag]


def _normalize_cover(url: str) -> str:
    text = str(url or "").strip()
    if text.startswith("//"):
        return f"https:{text}"
    return text


def _first_text(*values: Any) -> str:
    for value in values:
        if isinstance(value, str) and value.strip():
            return value
    return ""


def _build_video_url(*, bvid: str = "", aid: str = "", fallback: str = "") -> str:
    if fallback:
        url = fallback.strip()
        if url.startswith("http://"):
            return f"https://{url[len('http://'):]}"
        if url.startswith("//"):
            return f"https:{url}"
        return url
    if bvid:
        return VIDEO_URL_TEMPLATE.format(content_id=bvid)
    if aid:
        aid_text = aid if str(aid).startswith("av") else f"av{aid}"
        return VIDEO_URL_TEMPLATE.format(content_id=aid_text)
    return ""


def _build_space_url(author_id: str = "") -> str:
    value = author_id.strip()
    if not value:
        return ""
    return SPACE_URL_TEMPLATE.format(author_id=value)


def _build_search_url(query: str) -> str:
    return SEARCH_URL_TEMPLATE.format(query=quote(query.strip(), safe=""))


def _extract_author_query(author_id: str, url: str) -> str:
    text = author_id.strip()
    if text:
        return text
    match = SPACE_ID_RE.search(url.strip())
    if match:
        return match.group(1)
    return ""


def _extract_content_identifier(content_id: str, url: str) -> str:
    text = content_id.strip()
    if text:
        return text
    raw_url = url.strip()
    if not raw_url:
        return ""
    match = BV_RE.search(raw_url)
    if match:
        return match.group(1)
    match = AV_RE.search(raw_url)
    if match:
        return match.group(1)
    return ""


def _build_paging(*, has_more: bool = False, next_cursor: str = "") -> dict[str, Any]:
    return {
        "has_more": bool(has_more),
        "next_cursor": next_cursor if has_more else "",
    }


def _build_list_result(
    capability: str,
    items: list[dict[str, Any]],
    *,
    has_more: bool = False,
    next_cursor: str = "",
) -> dict[str, Any]:
    if capability == "search":
        items = _filter_real_content_items(items)
    status, result_type = _resolve_list_meta(items)
    result = {
        "platform": "bilibili",
        "capability": capability,
        "status": status,
        "update_time": _current_iso(),
        "items": items,
        "paging": _build_paging(has_more=has_more, next_cursor=next_cursor),
    }
    if result_type:
        result["result_type"] = result_type
    return result


def _build_author_result(author: dict[str, Any]) -> dict[str, Any]:
    status = "empty" if not author else ("degraded" if _normalized_result_type(author.get("result_type")) != "real" else "ok")
    result = {
        "platform": "bilibili",
        "status": status,
        "author": author,
    }
    if author:
        result["result_type"] = _normalized_result_type(author.get("result_type"))
    return result


def _build_detail_result(item: dict[str, Any]) -> dict[str, Any]:
    status = "empty" if not item else ("degraded" if _normalized_result_type(item.get("result_type")) != "real" else "ok")
    result = {
        "platform": "bilibili",
        "status": status,
        "item": item,
    }
    if item:
        result["result_type"] = _normalized_result_type(item.get("result_type"))
    return result


def parse_popular_item(item: dict[str, Any], rank: int) -> dict[str, Any]:
    stat = _as_dict(item.get("stat"))
    owner = _as_dict(item.get("owner"))
    bvid = str(item.get("bvid") or "").strip()
    aid = str(item.get("aid") or "").strip()
    content = _extract_video_body(item)
    return {
        "id": str(bvid or aid or _build_video_url(bvid=bvid, aid=aid)),
        "title": clean_text(str(item.get("title", ""))),
        "summary": content,
        "content": content,
        "url": _build_video_url(bvid=bvid, aid=aid),
        "cover": str(item.get("pic", "")),
        "author_name": clean_text(str(owner.get("name", ""))),
        "author_id": str(owner.get("mid", "")),
        "publish_time": _unix_to_iso(item.get("pubdate")),
        "rank": rank,
        "hot_value": _to_int(stat.get("view")),
        "hot_text": f"{stat.get('view')} 播放" if stat.get("view") else "",
        "comment_count": _to_int(stat.get("reply")),
        "like_count": _to_int(stat.get("like")),
        "share_count": _to_int(stat.get("share")),
        "collect_count": _to_int(stat.get("favorite")),
        "view_count": _to_int(stat.get("view")),
        "source_type": "video",
        "result_type": "real" if content else "preview",
        "tags": _parse_tags(item.get("tag") or item.get("tags") or ""),
    }


def parse_search_video_item(
    item: dict[str, Any],
    rank: int,
    *,
    author_name: str = "",
    author_id: str = "",
) -> dict[str, Any]:
    bvid = str(item.get("bvid") or "").strip()
    aid = str(item.get("aid", item.get("id", "")) or "").strip()
    summary = _extract_video_body(item)
    return {
        "id": str(bvid or aid or _build_video_url(bvid=bvid, aid=aid)),
        "title": clean_text(str(item.get("title", ""))),
        "summary": summary,
        "content": summary,
        "url": _build_video_url(
            bvid=bvid,
            aid=aid,
            fallback=str(item.get("arcurl", "")),
        ),
        "cover": _normalize_cover(str(item.get("pic", ""))),
        "author_name": clean_text(str(item.get("author") or item.get("uname") or author_name)),
        "author_id": str(item.get("mid", author_id or "")),
        "publish_time": _unix_to_iso(item.get("pubdate") or item.get("senddate")),
        "rank": rank,
        "hot_value": _to_int(item.get("play")),
        "hot_text": f"{item.get('play')} 播放" if item.get("play") else "",
        "comment_count": _to_int(item.get("review") or item.get("video_review") or item.get("dm")),
        "like_count": _to_int(item.get("like")),
        "share_count": _to_int(item.get("share")),
        "collect_count": _to_int(item.get("favorites") or item.get("fav")),
        "view_count": _to_int(item.get("play")),
        "source_type": "video",
        "result_type": "real" if summary else "preview",
        "tags": _parse_tags(item.get("tag") or item.get("tags") or ""),
    }


def parse_video_search_items(
    payload: dict[str, Any],
    *,
    author_id: str = "",
    author_name: str = "",
) -> list[dict[str, Any]]:
    data = _as_dict(payload.get("data"))
    results = _as_list(data.get("result"))
    normalized_author_id = author_id.strip()
    normalized_author_name = author_name.strip().lower()
    items: list[dict[str, Any]] = []
    for raw_item in results:
        if not isinstance(raw_item, dict):
            continue
        raw_author_id = str(raw_item.get("mid", "")).strip()
        raw_author_name = clean_text(str(raw_item.get("author") or raw_item.get("uname") or ""))
        if normalized_author_id and raw_author_id != normalized_author_id:
            continue
        if not normalized_author_id and normalized_author_name and raw_author_name.lower() != normalized_author_name:
            continue
        items.append(
            parse_search_video_item(
                raw_item,
                len(items) + 1,
                author_name=author_name or raw_author_name,
                author_id=author_id or raw_author_id,
            )
        )
    return items


def _pick_user_result(
    results: list[dict[str, Any]],
    *,
    author_id: str = "",
    query: str = "",
) -> dict[str, Any] | None:
    if not results:
        return None
    normalized_author_id = author_id.strip().lower()
    normalized_query = query.strip().lower()
    if normalized_author_id:
        for item in results:
            mid = str(item.get("mid", "")).strip().lower()
            uname = clean_text(str(item.get("uname", ""))).lower()
            if mid == normalized_author_id or uname == normalized_author_id:
                return item
    if normalized_query:
        for item in results:
            uname = clean_text(str(item.get("uname", ""))).lower()
            if uname == normalized_query:
                return item
        for item in results:
            uname = clean_text(str(item.get("uname", ""))).lower()
            usign = clean_text(str(item.get("usign", ""))).lower()
            if normalized_query in uname or normalized_query in usign:
                return item
    return results[0]


def parse_author_profile_from_card(
    payload: dict[str, Any],
    *,
    url: str = "",
    author_id: str = "",
) -> dict[str, Any]:
    data = _as_dict(payload.get("data"))
    card = _as_dict(data.get("card"))
    official = _as_dict(card.get("official_verify"))
    resolved_author_id = str(card.get("mid", author_id or ""))
    return {
        "id": resolved_author_id,
        "name": clean_text(str(card.get("name", ""))),
        "url": url.strip() or _build_space_url(resolved_author_id or author_id),
        "avatar": str(card.get("face", "")),
        "bio": clean_text(
            str(card.get("sign") or card.get("description") or official.get("desc", ""))
        ),
        "follower_count": _to_int(card.get("fans")),
        "following_count": _to_int(card.get("friend") or card.get("attention")),
        "content_count": _to_int(card.get("archive_count")),
    }


def parse_author_profile_from_user_search(
    payload: dict[str, Any],
    *,
    url: str = "",
    author_id: str = "",
    query: str = "",
) -> dict[str, Any]:
    data = _as_dict(payload.get("data"))
    results = _as_list(data.get("result"))
    selected = _pick_user_result(results, author_id=author_id, query=query or author_id)
    if selected is None:
        return {
            "id": author_id,
            "name": "",
            "url": url.strip() or _build_space_url(author_id),
            "avatar": "",
            "bio": "",
            "follower_count": None,
            "following_count": None,
            "content_count": None,
        }
    verify_info = selected.get("official_verify")
    if isinstance(verify_info, dict):
        bio = clean_text(str(selected.get("usign") or verify_info.get("desc", "")))
    else:
        bio = clean_text(str(selected.get("usign") or verify_info or ""))
    resolved_author_id = str(selected.get("mid", author_id or ""))
    return {
        "id": resolved_author_id,
        "name": clean_text(str(selected.get("uname", ""))),
        "url": url.strip() or _build_space_url(resolved_author_id or author_id),
        "avatar": _normalize_cover(str(selected.get("upic", ""))),
        "bio": bio,
        "follower_count": _to_int(selected.get("fans")),
        "following_count": None,
        "content_count": _to_int(selected.get("videos")),
    }


def parse_author_preview_items(
    payload: dict[str, Any],
    *,
    limit: int,
    author_id: str = "",
    query: str = "",
) -> list[dict[str, Any]]:
    data = _as_dict(payload.get("data"))
    results = _as_list(data.get("result"))
    selected = _pick_user_result(results, author_id=author_id, query=query or author_id)
    if selected is None:
        return []
    resolved_author_id = str(selected.get("mid", author_id or ""))
    resolved_author_name = clean_text(str(selected.get("uname", "")))
    preview_items = _as_list(selected.get("res"))
    items: list[dict[str, Any]] = []
    for raw_item in preview_items:
        if not isinstance(raw_item, dict):
            continue
        items.append(
            parse_search_video_item(
                raw_item,
                len(items) + 1,
                author_name=resolved_author_name,
                author_id=resolved_author_id,
            )
        )
        if len(items) >= limit:
            break
    return items


def _dedupe_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    unique: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for item in items:
        item_id = str(item.get("id", "")).strip()
        if not item_id or item_id in seen_ids:
            continue
        seen_ids.add(item_id)
        unique.append(item)
    for index, item in enumerate(unique, start=1):
        item["rank"] = index
    return unique


def fetch_hot_list_data(*, limit: int, refresh: bool) -> dict[str, Any]:
    del refresh
    safe_limit = _normalize_limit(limit)
    session = create_session()
    payload = _request_json(
        session,
        POPULAR_API_URL,
        params={"ps": safe_limit, "pn": 1},
        referer=HOME_URL,
    )
    data = _as_dict(payload.get("data"))
    raw_list = _as_list(data.get("list"))
    items = [parse_popular_item(item, index + 1) for index, item in enumerate(raw_list[:safe_limit])]
    return _build_list_result("hot_list", items)


def fetch_feed_list_data(
    *,
    channel: str,
    cursor: str,
    limit: int,
    refresh: bool,
) -> dict[str, Any]:
    del refresh
    normalized_channel = clean_text(channel).lower()
    if normalized_channel and normalized_channel not in {"", "all", "hot", "hot_list", "recommend", "recommended", "home", "热门", "推荐"}:
        return _build_list_result(
            "feed_list",
            [],
            has_more=False,
            next_cursor="",
        )
    safe_limit = _normalize_limit(limit)
    page = _parse_page_cursor(cursor)
    session = create_session()
    payload = _request_json(
        session,
        POPULAR_API_URL,
        params={"ps": safe_limit, "pn": page},
        referer=HOME_URL,
    )
    data = _as_dict(payload.get("data"))
    raw_list = _as_list(data.get("list"))
    items = [parse_popular_item(item, index + 1) for index, item in enumerate(raw_list[:safe_limit])]
    has_more = len(raw_list) >= safe_limit
    next_cursor = str(page + 1) if has_more else ""
    return _build_list_result("feed_list", items, has_more=has_more, next_cursor=next_cursor)


def fetch_search_content_data(*, query: str, cursor: str, limit: int) -> dict[str, Any]:
    keyword = query.strip()
    if not keyword:
        return _build_list_result("search", [], has_more=False, next_cursor="")
    safe_limit = _normalize_limit(limit)
    page = _parse_page_cursor(cursor)
    session = create_session(prime_home=True)
    payload = _request_json(
        session,
        SEARCH_TYPE_API_URL,
        params={
            "search_type": "video",
            "keyword": keyword,
            "page": page,
            "page_size": safe_limit,
            "order": "pubdate",
        },
        referer=_build_search_url(keyword),
        prime_before_request=False,
    )
    data = _as_dict(payload.get("data"))
    items = parse_video_search_items(payload)
    if items and not any(_contains_keyword(item, keyword) for item in items):
        items = []
    num_pages = _to_int(data.get("numPages")) or page
    has_more = bool(items) and page < num_pages
    return _build_list_result(
        "search",
        items[:safe_limit],
        has_more=has_more,
        next_cursor=str(page + 1) if has_more else "",
    )


def fetch_content_detail_data(*, content_id: str, url: str) -> dict[str, Any]:
    identifier = _extract_content_identifier(content_id, url)
    if not identifier:
        return _build_detail_result({})
    params: dict[str, Any]
    if identifier.lower().startswith("bv"):
        params = {"bvid": identifier}
    else:
        aid = identifier[2:] if identifier.lower().startswith("av") else identifier
        params = {"aid": aid}
    session = create_session()
    payload = _request_json(
        session,
        VIDEO_VIEW_API_URL,
        params=params,
        referer=url.strip() or _build_video_url(bvid=identifier if identifier.lower().startswith("bv") else "", aid=params.get("aid", "")),
    )
    data = _as_dict(payload.get("data"))
    item = parse_popular_item(data, 1)
    item["url"] = url.strip() or item.get("url") or _build_video_url(
        bvid=str(data.get("bvid", "")),
        aid=str(data.get("aid", "")),
    )
    if identifier:
        item["id"] = identifier
    if not clean_text(str(item.get("content", ""))) and clean_text(str(item.get("title", ""))):
        item["summary"] = clean_text(str(item.get("title", "")))
        item["result_type"] = "real"
    return _build_detail_result(item)


def fetch_author_profile_data(*, author_id: str, url: str) -> dict[str, Any]:
    query = _extract_author_query(author_id, url)
    if not query or (query.startswith("__") and query.endswith("__")):
        return _build_author_result({})
    if not author_id.strip() and url.strip() and not SPACE_ID_RE.search(url.strip()):
        return _build_author_result({})
    session = create_session(prime_home=not query.isdigit())
    if query.isdigit():
        payload = _request_json(
            session,
            AUTHOR_CARD_API_URL,
            params={"mid": query},
            referer=url.strip() or _build_space_url(query),
        )
        author = parse_author_profile_from_card(payload, url=url, author_id=query)
        return _build_author_result(author)

    search_payload = _request_json(
        session,
        SEARCH_TYPE_API_URL,
        params={
            "search_type": "bili_user",
            "keyword": query,
            "page": 1,
            "page_size": 10,
        },
        referer=_build_search_url(query),
    )
    author = parse_author_profile_from_user_search(
        search_payload,
        url=url,
        author_id=query,
        query=query,
    )
    resolved_author_id = str(author.get("id", "")).strip()
    if resolved_author_id.isdigit():
        try:
            card_payload = _request_json(
                session,
                AUTHOR_CARD_API_URL,
                params={"mid": resolved_author_id},
                referer=url.strip() or _build_space_url(resolved_author_id),
            )
            author = parse_author_profile_from_card(
                card_payload,
                url=url,
                author_id=resolved_author_id,
            )
            return _build_author_result(author)
        except RuntimeError:
            pass
    return _build_author_result(author)


def fetch_author_content_list_data(
    *,
    author_id: str,
    url: str,
    cursor: str,
    limit: int,
) -> dict[str, Any]:
    query = _extract_author_query(author_id, url)
    if not query or (query.startswith("__") and query.endswith("__")):
        return _build_list_result("author_content_list", [], has_more=False, next_cursor="")
    if not author_id.strip() and url.strip() and not SPACE_ID_RE.search(url.strip()):
        return _build_list_result("author_content_list", [], has_more=False, next_cursor="")

    safe_limit = _normalize_limit(limit)
    start_page = _parse_page_cursor(cursor)
    profile_data = fetch_author_profile_data(author_id=query, url=url)
    author = profile_data["author"]
    resolved_author_id = str(author.get("id", "") or query).strip()
    resolved_author_name = str(author.get("name", "") or query).strip()

    session = create_session(prime_home=True)
    preview_items: list[dict[str, Any]] = []
    if start_page == 1:
        preview_payload = _request_json(
            session,
            SEARCH_TYPE_API_URL,
            params={
                "search_type": "bili_user",
                "keyword": resolved_author_name or query,
                "page": 1,
                "page_size": 10,
            },
            referer=_build_search_url(resolved_author_name or query),
        )
        preview_items = parse_author_preview_items(
            preview_payload,
            limit=safe_limit,
            author_id=resolved_author_id,
            query=resolved_author_name or query,
        )

    items = _dedupe_items(preview_items) if start_page == 1 else []
    current_page = start_page
    pages_scanned = 0
    empty_streak = 0
    found_exact_match = False
    num_pages = 0

    while len(items) < safe_limit and pages_scanned < AUTHOR_CONTENT_SCAN_MAX_PAGES:
        payload = _request_json(
            session,
            SEARCH_TYPE_API_URL,
            params={
                "search_type": "video",
                "keyword": resolved_author_name or query,
                "page": current_page,
                "page_size": AUTHOR_CONTENT_SEARCH_PAGE_SIZE,
                "order": "pubdate",
            },
            referer=_build_search_url(resolved_author_name or query),
        )
        pages_scanned += 1
        data = _as_dict(payload.get("data"))
        raw_list = _as_list(data.get("result"))
        page_items = parse_video_search_items(
            payload,
            author_id=resolved_author_id,
            author_name=resolved_author_name,
        )
        num_pages = max(num_pages, _to_int(data.get("numPages")) or 0)
        if page_items:
            found_exact_match = True
            empty_streak = 0
            items.extend(page_items)
            items = _dedupe_items(items)
        else:
            empty_streak += 1

        if current_page >= num_pages or not raw_list:
            current_page += 1
            break
        current_page += 1
        if not found_exact_match and empty_streak >= 2:
            break
        if found_exact_match and empty_streak > 2:
            break

    if not items:
        return _build_list_result("author_content_list", [], has_more=False, next_cursor="")

    has_more = found_exact_match and current_page <= num_pages
    return _build_list_result(
        "author_content_list",
        items[:safe_limit],
        has_more=has_more,
        next_cursor=str(current_page) if has_more else "",
    )


mcp = FastMCP(
    "BILIBILI_MCP",
    instructions=(
        "Astron Bilibili MCP server，基于哔哩哔哩游客态公开接口提供公开内容工具能力，"
        "无需额外部署后端服务。"
    ),
)


@mcp.tool()
def get_hot_list(
    ctx: Context,
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """
    获取 Bilibili 热榜。

    参数：
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否请求刷新数据。
    """
    del ctx
    return fetch_hot_list_data(limit=limit, refresh=refresh)


@mcp.tool()
def get_feed_list(
    ctx: Context,
    channel: str = "",
    cursor: str = "",
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """
    获取 Bilibili 信息流。

    参数：
    - channel: 频道名，可为空。
    - cursor: 分页游标，可为空。
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否请求刷新数据。
    """
    del ctx
    return fetch_feed_list_data(
        channel=channel,
        cursor=cursor,
        limit=limit,
        refresh=refresh,
    )


@mcp.tool()
def search_content(
    ctx: Context,
    query: str,
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """
    搜索 Bilibili 公开内容。

    参数：
    - query: 搜索关键词。
    - cursor: 分页游标，可为空。
    - limit: 返回条数，范围建议 1-50。
    """
    del ctx
    return fetch_search_content_data(query=query, cursor=cursor, limit=limit)


@mcp.tool()
def get_content_detail(
    ctx: Context,
    content_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取 Bilibili 内容详情。

    参数：
    - content_id: 内容 ID，例如 BVID。
    - url: 内容完整 URL。
    """
    del ctx
    return fetch_content_detail_data(content_id=content_id, url=url)


@mcp.tool()
def get_author_profile(
    ctx: Context,
    author_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取 Bilibili 作者主页。

    参数：
    - author_id: 作者 ID 或作者名。
    - url: 作者主页 URL。
    """
    del ctx
    return fetch_author_profile_data(author_id=author_id, url=url)


@mcp.tool()
def get_author_content_list(
    ctx: Context,
    author_id: str = "",
    url: str = "",
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """
    获取 Bilibili 作者公开作品列表。

    参数：
    - author_id: 作者 ID 或作者名。
    - url: 作者主页 URL。
    - cursor: 分页游标，可为空。
    - limit: 返回条数，范围建议 1-50。
    """
    del ctx
    return fetch_author_content_list_data(
        author_id=author_id,
        url=url,
        cursor=cursor,
        limit=limit,
    )


def main() -> None:
    """Run the MCP server over stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
