from trusted_pub_demo_hello import greet


def test_greet():
    assert greet("world") == "hello world"
