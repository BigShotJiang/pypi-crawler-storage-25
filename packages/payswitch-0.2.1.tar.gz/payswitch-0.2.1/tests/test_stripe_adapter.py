"""Stripe adapter 测试套件。

测试 Stripe checkout session 创建、webhook 事件处理和完整的支付流程。
使用 pytest-mock 和 monkeypatch 模拟 Stripe API 调用。
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from payswitch.adapters.base import ScriptExecutionError
from payswitch.models.types import PaymentMethod, TransactionStatus

# 检查是否有完整的 stripe 包（用于 skipif 条件）
# 如果有环境变量 SKIP_STRIPE_E2E_TEST，则跳过
import os
_SKIP_STRIPE_E2E = os.environ.get("SKIP_STRIPE_E2E_TEST", "1") == "1"


@pytest.fixture
def mock_stripe_module(monkeypatch):
    """Mock stripe 模块（避免真正导入 Stripe SDK）。"""
    # 创建一个更完整的 mock stripe 模块
    mock_stripe = MagicMock()
    mock_stripe.__name__ = "stripe"
    mock_stripe.api_key = None

    # Mock error 子模块
    mock_stripe.error = MagicMock()
    mock_stripe.error.StripeError = type("StripeError", (Exception,), {})
    mock_stripe.error.SignatureVerificationError = type("SignatureVerificationError", (Exception,), {})

    # Mock checkout 子模块
    mock_checkout = MagicMock()
    mock_session = MagicMock()
    mock_session.id = "cs_test_123456"
    mock_session.url = "https://checkout.stripe.com/c/pay/cs_test_123456"

    mock_session_class = MagicMock()
    mock_session_class.create.return_value = mock_session
    mock_checkout.Session = mock_session_class
    mock_stripe.checkout = mock_checkout

    # Mock Webhook.construct_event
    mock_webhook = MagicMock()
    mock_webhook.construct_event.side_effect = lambda payload, sig, secret: json.loads(payload)
    mock_stripe.Webhook = mock_webhook

    # 将 mock 模块注入到 sys.modules
    monkeypatch.setitem(__import__("sys").modules, "stripe", mock_stripe)
    monkeypatch.setitem(__import__("sys").modules, "stripe.checkout", mock_checkout)
    monkeypatch.setitem(__import__("sys").modules, "stripe.error", mock_stripe.error)

    return mock_stripe


@pytest.fixture
def stripe_adapter(mock_stripe_module, monkeypatch, tmp_path):
    """创建配置了 test API key 的 StripeAdapter 实例。"""
    # 设置测试用 API Key
    monkeypatch.setenv("STRIPE_SECRET_KEY", "sk_test_mock_key_123456")

    # 创建临时配置目录
    config_dir = tmp_path / ".payswitch"
    config_dir.mkdir()
    monkeypatch.setenv("HOME", str(tmp_path))

    # 确保 _STRIPE_AVAILABLE 为 True
    from payswitch.adapters import stripe as stripe_module
    monkeypatch.setattr(stripe_module, "_STRIPE_AVAILABLE", True)

    from payswitch.adapters.stripe import StripeAdapter
    return StripeAdapter()


class TestStripeAdapter:
    """Stripe adapter 单元测试。"""

    def test_adapter_registration(self):
        """测试 StripeAdapter 是否正确注册到 AdapterRegistry。"""
        from payswitch.adapters import AdapterRegistry

        adapter = AdapterRegistry.get("stripe")
        # 如果 Stripe SDK 未安装，adapter 可能为 None 或初始化失败
        # 这里只测试注册逻辑，不测试实例化
        assert AdapterRegistry.has("stripe")

    def test_adapter_attributes(self, stripe_adapter):
        """测试 adapter 类属性。"""
        assert stripe_adapter.name == "stripe"
        assert stripe_adapter.display_name == "Stripe"
        assert PaymentMethod.stripe in stripe_adapter.supported_methods

    def test_api_key_from_env(self, stripe_adapter):
        """测试从环境变量读取 API Key。"""
        assert stripe_adapter.api_key == "sk_test_mock_key_123456"

    @pytest.mark.asyncio
    async def test_execute_topup_success(self, stripe_adapter, mock_stripe_module):
        """测试成功创建 checkout session。"""
        steps = await stripe_adapter.execute_topup(
            page=None,  # Stripe 不需要浏览器
            amount=10.0,
            method=PaymentMethod.stripe,
            currency="usd",
            product_name="Test Product",
        )

        # 验证返回的步骤
        assert len(steps) >= 2
        assert any("Stripe checkout session" in step.description for step in steps)
        assert any(step.action == "payment_url_ready" for step in steps)

        # 验证 checkout URL
        checkout_step = next(s for s in steps if s.action == "payment_url_ready")
        assert checkout_step.url is not None
        assert "checkout.stripe.com" in checkout_step.url

    @pytest.mark.asyncio
    async def test_execute_topup_without_api_key(self, monkeypatch, tmp_path):
        """测试未配置 API Key 时抛出异常。"""
        # 清除环境变量
        monkeypatch.delenv("STRIPE_SECRET_KEY", raising=False)

        # Mock stripe 模块
        mock_stripe = MagicMock()
        mock_stripe.api_key = None
        monkeypatch.setitem(__import__("sys").modules, "stripe", mock_stripe)

        # 创建临时配置
        config_dir = tmp_path / ".payswitch"
        config_dir.mkdir()
        monkeypatch.setenv("HOME", str(tmp_path))

        from payswitch.adapters import stripe as stripe_module
        monkeypatch.setattr(stripe_module, "_STRIPE_AVAILABLE", True)

        from payswitch.adapters.stripe import StripeAdapter

        # 初始化时应该警告但不报错
        adapter = StripeAdapter()

        # 调用 execute_topup 时应该抛出异常
        with pytest.raises(ScriptExecutionError, match="Stripe Secret Key 未配置"):
            await adapter.execute_topup(
                page=None,
                amount=10.0,
                method=PaymentMethod.stripe,
            )

    @pytest.mark.asyncio
    async def test_execute_topup_invalid_amount(self, stripe_adapter):
        """测试无效金额时抛出异常。"""
        with pytest.raises(ScriptExecutionError, match="支付金额必须大于 0"):
            await stripe_adapter.execute_topup(
                page=None,
                amount=0,
                method=PaymentMethod.stripe,
            )

        with pytest.raises(ScriptExecutionError, match="支付金额必须大于 0"):
            await stripe_adapter.execute_topup(
                page=None,
                amount=-10,
                method=PaymentMethod.stripe,
            )

    @pytest.mark.asyncio
    async def test_execute_topup_stripe_api_error(self, stripe_adapter, mock_stripe_module):
        """测试 Stripe API 调用失败时的处理。"""
        # Mock Stripe API 抛出异常
        mock_stripe_module.checkout.Session.create.side_effect = Exception("API Error")

        with pytest.raises(ScriptExecutionError, match="创建 Stripe checkout session 时发生异常"):
            await stripe_adapter.execute_topup(
                page=None,
                amount=10.0,
                method=PaymentMethod.stripe,
            )

    @pytest.mark.asyncio
    async def test_execute_topup_with_custom_params(self, stripe_adapter, mock_stripe_module):
        """测试自定义参数（currency, product_name, tx_id）。"""
        await stripe_adapter.execute_topup(
            page=None,
            amount=50.0,
            method=PaymentMethod.stripe,
            currency="cny",
            product_name="Custom Product",
            tx_id="txn_test_123",
        )

        # 验证 Stripe API 调用参数
        call_kwargs = mock_stripe_module.checkout.Session.create.call_args[1]
        assert call_kwargs["line_items"][0]["price_data"]["currency"] == "cny"
        assert call_kwargs["line_items"][0]["price_data"]["product_data"]["name"] == "Custom Product"
        assert call_kwargs["metadata"]["payswitch_tx_id"] == "txn_test_123"


class TestStripeWebhook:
    """Stripe webhook 处理器测试。"""

    @pytest.fixture
    def webhook_app(self, tmp_path, monkeypatch):
        """创建测试用 webhook app。"""
        # Mock stripe 和 fastapi
        mock_stripe = MagicMock()
        # 修复参数名：Webhook.construct_event 的参数是 (payload, sig_header, secret)
        mock_stripe.Webhook.construct_event.side_effect = lambda payload, sig_header, secret: json.loads(payload)
        monkeypatch.setitem(__import__("sys").modules, "stripe", mock_stripe)

        try:
            from fastapi.testclient import TestClient
        except ImportError:
            pytest.skip("FastAPI 未安装，跳过 webhook 测试")

        from payswitch.engine.stripe_webhook import create_webhook_app

        # 创建测试数据库
        db_path = tmp_path / "test_payswitch.db"

        app = create_webhook_app(
            ledger_db_path=db_path,
            webhook_secret="whsec_test_secret",
        )

        if app is None:
            pytest.skip("无法创建 webhook app（依赖未安装）")

        return TestClient(app)

    def test_health_check(self, webhook_app):
        """测试健康检查端点。"""
        response = webhook_app.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert "timestamp" in data

    def test_webhook_missing_signature(self, webhook_app):
        """测试缺少签名的请求被拒绝。"""
        response = webhook_app.post(
            "/webhook",
            json={"type": "checkout.session.completed"},
        )
        assert response.status_code == 400
        assert "Missing Stripe-Signature" in response.json()["detail"]

    def test_webhook_checkout_completed(self, webhook_app, tmp_path):
        """测试 checkout.session.completed 事件处理。"""
        # 先创建一个待确认的交易
        from payswitch.engine.ledger import Ledger
        from payswitch.models.transaction import Transaction

        db_path = tmp_path / "test_payswitch.db"
        ledger = Ledger(db_path=db_path)

        tx = Transaction(
            amount=10.0,
            payee="stripe",
            reason="Test payment",
            payment_method=PaymentMethod.stripe,
            status=TransactionStatus.human_action_required,
        )
        ledger.record(tx)

        # 构造 webhook 事件
        event_payload = {
            "id": "evt_test_123",
            "type": "checkout.session.completed",
            "data": {
                "object": {
                    "id": "cs_test_123",
                    "metadata": {
                        "payswitch_tx_id": tx.tx_id,
                    }
                }
            }
        }

        # 发送 webhook 请求
        response = webhook_app.post(
            "/webhook",
            json=event_payload,
            headers={"Stripe-Signature": "test_sig"},
        )

        assert response.status_code == 200
        data = response.json()
        assert data["received"] is True
        assert data["tx_id"] == tx.tx_id

        # 验证交易状态已更新
        updated_tx = ledger.get(tx.tx_id)
        assert updated_tx is not None
        assert updated_tx.status == TransactionStatus.completed
        assert updated_tx.completed_at is not None

        ledger.close()

    def test_webhook_session_expired(self, webhook_app, tmp_path):
        """测试 checkout.session.expired 事件处理。"""
        from payswitch.engine.ledger import Ledger
        from payswitch.models.transaction import Transaction

        db_path = tmp_path / "test_payswitch.db"
        ledger = Ledger(db_path=db_path)

        tx = Transaction(
            amount=10.0,
            payee="stripe",
            reason="Test payment",
            payment_method=PaymentMethod.stripe,
            status=TransactionStatus.human_action_required,
        )
        ledger.record(tx)

        event_payload = {
            "id": "evt_test_expired",
            "type": "checkout.session.expired",
            "data": {
                "object": {
                    "id": "cs_test_expired",
                    "metadata": {"payswitch_tx_id": tx.tx_id}
                }
            }
        }

        response = webhook_app.post(
            "/webhook",
            json=event_payload,
            headers={"Stripe-Signature": "test_sig"},
        )

        assert response.status_code == 200

        # 验证交易状态
        updated_tx = ledger.get(tx.tx_id)
        assert updated_tx.status == TransactionStatus.cancelled
        assert "expired" in updated_tx.error.lower()

        ledger.close()

    def test_webhook_no_payswitch_tx_id(self, webhook_app):
        """测试无 Pay-Switch 交易 ID 的事件被忽略。"""
        event_payload = {
            "id": "evt_test_no_id",
            "type": "checkout.session.completed",
            "data": {
                "object": {
                    "id": "cs_test_no_id",
                    "metadata": {}  # 无 payswitch_tx_id
                }
            }
        }

        response = webhook_app.post(
            "/webhook",
            json=event_payload,
            headers={"Stripe-Signature": "test_sig"},
        )

        assert response.status_code == 200
        data = response.json()
        assert data["received"] is True
        assert "No payswitch_tx_id" in data["note"]


@pytest.mark.skipif(
    _SKIP_STRIPE_E2E,
    reason="Stripe E2E 测试需要完整的 stripe 包（>=8.0），设置 SKIP_STRIPE_E2E_TEST=0 启用"
)
@pytest.mark.asyncio
async def test_end_to_end_stripe_payment(tmp_path, monkeypatch):
    """端到端测试：从创建交易到 webhook 确认完成。

    注意：此测试需要完整的 stripe 包（>=8.0），环境中的 stripe stub 不支持。
    设置环境变量 SKIP_STRIPE_E2E_TEST=0 并安装完整 stripe 包后才能运行。
    """

    # Mock stripe 模块
    mock_stripe = MagicMock()
    mock_stripe.__name__ = "stripe"
    mock_stripe.api_key = None

    # Mock checkout 子模块
    mock_checkout = MagicMock()
    mock_session = MagicMock()
    mock_session.id = "cs_test_e2e"
    mock_session.url = "https://checkout.stripe.com/c/pay/cs_test_e2e"
    mock_session_class = MagicMock()
    mock_session_class.create.return_value = mock_session
    mock_checkout.Session = mock_session_class
    mock_stripe.checkout = mock_checkout

    monkeypatch.setitem(__import__("sys").modules, "stripe", mock_stripe)
    monkeypatch.setitem(__import__("sys").modules, "stripe.checkout", mock_checkout)
    monkeypatch.setenv("STRIPE_SECRET_KEY", "sk_test_e2e_key")
    monkeypatch.setenv("HOME", str(tmp_path))

    # 创建临时配置
    config_dir = tmp_path / ".payswitch"
    config_dir.mkdir()

    from payswitch.adapters import stripe as stripe_module
    monkeypatch.setattr(stripe_module, "_STRIPE_AVAILABLE", True)

    # 1. 创建 Stripe adapter 并生成 checkout session
    from payswitch.adapters.stripe import StripeAdapter

    adapter = StripeAdapter()
    steps = await adapter.execute_topup(
        page=None,
        amount=20.0,
        method=PaymentMethod.stripe,
        currency="usd",
        product_name="End-to-End Test",
        tx_id="txn_e2e_test",
    )

    # 验证返回步骤
    assert len(steps) >= 2
    checkout_url = next(s.url for s in steps if s.action == "payment_url_ready")
    assert checkout_url is not None
    assert "cs_test_e2e" in checkout_url

    # 2. 模拟 webhook 事件更新状态
    # （实际环境中由独立的 webhook 监听器处理）
    from payswitch.engine.ledger import Ledger
    from payswitch.models.transaction import Transaction

    db_path = tmp_path / ".payswitch" / "payswitch.db"
    ledger = Ledger(db_path=db_path)

    tx = Transaction(
        tx_id="txn_e2e_test",
        amount=20.0,
        payee="stripe",
        reason="End-to-End Test",
        payment_method=PaymentMethod.stripe,
        status=TransactionStatus.human_action_required,
    )
    ledger.record(tx)

    # 模拟 webhook 更新
    ledger.update_status(
        "txn_e2e_test",
        TransactionStatus.completed,
        completed_at=datetime.now(timezone.utc),
    )

    # 验证最终状态
    final_tx = ledger.get("txn_e2e_test")
    assert final_tx.status == TransactionStatus.completed
    assert final_tx.completed_at is not None

    ledger.close()
