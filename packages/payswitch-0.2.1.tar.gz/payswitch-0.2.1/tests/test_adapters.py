"""Pay-Switch 适配器（AdapterRegistry + 各平台适配器）单元测试。

覆盖范围：
- AdapterRegistry.register：注册装饰器正常工作 / 重名覆盖警告
- AdapterRegistry.get：返回正确适配器实例 / 未注册时返回 None
- AdapterRegistry.has：已注册返回 True / 未注册返回 False
- AdapterRegistry.list_platforms：列出所有已注册平台的基本信息
- DeepSeekAdapter / KimiAdapter / QwenAdapter：
    - 已在 registry 中注册且可正常获取实例
    - name / display_name / top_up_url / login_url / supported_methods 属性正确
    - validate_amount 的合法/非法金额校验
- SiteAdapter ABC：
    - 未实现抽象方法时不能实例化
- ScriptStep 数据模型：
    - 基本创建与字段验证
"""

from __future__ import annotations

import warnings

import pytest

from payswitch.adapters import AdapterRegistry, ScriptExecutionError, ScriptStep, SiteAdapter
from payswitch.adapters.deepseek import DeepSeekAdapter
from payswitch.adapters.kimi import KimiAdapter
from payswitch.adapters.qwen import QwenAdapter
from payswitch.models.types import PaymentMethod


# ===========================================================================
# AdapterRegistry 测试
# ===========================================================================


class TestAdapterRegistry:
    """AdapterRegistry 注册表测试。"""

    def test_get_deepseek返回DeepSeekAdapter实例(self):
        """AdapterRegistry.get('deepseek') 应返回 DeepSeekAdapter 实例。"""
        adapter = AdapterRegistry.get("deepseek")
        assert adapter is not None
        assert isinstance(adapter, DeepSeekAdapter)

    def test_get_kimi返回KimiAdapter实例(self):
        """AdapterRegistry.get('kimi') 应返回 KimiAdapter 实例。"""
        adapter = AdapterRegistry.get("kimi")
        assert adapter is not None
        assert isinstance(adapter, KimiAdapter)

    def test_get_qwen返回QwenAdapter实例(self):
        """AdapterRegistry.get('qwen') 应返回 QwenAdapter 实例。"""
        adapter = AdapterRegistry.get("qwen")
        assert adapter is not None
        assert isinstance(adapter, QwenAdapter)

    def test_get_不存在的平台返回None(self):
        """查询未注册平台时，get 应返回 None。"""
        result = AdapterRegistry.get("nonexistent_platform")
        assert result is None

    def test_get_空字符串返回None(self):
        """查询空字符串时，get 应返回 None。"""
        result = AdapterRegistry.get("")
        assert result is None

    def test_has_已注册平台返回True(self):
        """has('deepseek') 对已注册平台应返回 True。"""
        assert AdapterRegistry.has("deepseek") is True
        assert AdapterRegistry.has("kimi") is True
        assert AdapterRegistry.has("qwen") is True

    def test_has_未注册平台返回False(self):
        """has 对未注册平台应返回 False。"""
        assert AdapterRegistry.has("ghost_platform") is False

    def test_list_platforms包含3个平台(self):
        """list_platforms 应至少包含 3 个已注册平台（deepseek / kimi / qwen）。"""
        platforms = AdapterRegistry.list_platforms()
        names = [p["name"] for p in platforms]
        assert "deepseek" in names
        assert "kimi" in names
        assert "qwen" in names

    def test_list_platforms每项包含必要字段(self):
        """list_platforms 每项应包含 name / display_name / top_up_url / login_url / supported_methods。"""
        platforms = AdapterRegistry.list_platforms()
        for platform in platforms:
            assert "name" in platform
            assert "display_name" in platform
            assert "top_up_url" in platform
            assert "login_url" in platform
            assert "supported_methods" in platform
            # supported_methods 是字符串列表（StrEnum 序列化为值）
            assert isinstance(platform["supported_methods"], list)

    def test_register_重名时发出警告(self):
        """重复注册同名平台时，应发出 UserWarning 警告。"""
        # 创建一个临时的重复适配器类用于测试，不污染全局注册表
        original_adapters = dict(AdapterRegistry._adapters)
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")

                @AdapterRegistry.register
                class _TempAdapter(SiteAdapter):
                    name = "deepseek"  # 与已注册的 DeepSeekAdapter 重名
                    display_name = "Temp"
                    top_up_url = "https://temp.example.com"
                    login_url = "https://temp.example.com/login"
                    supported_methods = [PaymentMethod.alipay_qr]

                    async def execute_topup(self, page, amount, method=None):
                        return []

            # 应有警告被触发
            assert len(caught) >= 1
            assert any(issubclass(w.category, UserWarning) for w in caught)
        finally:
            # 恢复注册表，避免污染其他测试
            AdapterRegistry._adapters = original_adapters

    def test_register_返回原适配器类(self):
        """register 装饰器应原样返回适配器类（保持装饰器语义）。"""
        original_adapters = dict(AdapterRegistry._adapters)
        try:
            class _NewAdapter(SiteAdapter):
                name = "test_register_return"
                display_name = "Test"
                top_up_url = "https://test.example.com"
                login_url = "https://test.example.com/login"
                supported_methods = [PaymentMethod.alipay_qr]

                async def execute_topup(self, page, amount, method=None):
                    return []

            result = AdapterRegistry.register(_NewAdapter)
            assert result is _NewAdapter
        finally:
            AdapterRegistry._adapters = original_adapters

    def test_get_每次返回新实例(self):
        """get 每次调用应返回新实例，不共享状态。"""
        adapter1 = AdapterRegistry.get("deepseek")
        adapter2 = AdapterRegistry.get("deepseek")
        assert adapter1 is not adapter2


# ===========================================================================
# DeepSeekAdapter 测试
# ===========================================================================


class TestDeepSeekAdapter:
    """DeepSeekAdapter 属性和方法测试。"""

    def test_name属性(self):
        """name 属性应为 'deepseek'。"""
        assert DeepSeekAdapter.name == "deepseek"

    def test_display_name属性(self):
        """display_name 应为 'DeepSeek'。"""
        assert DeepSeekAdapter.display_name == "DeepSeek"

    def test_top_up_url属性(self):
        """top_up_url 应指向 DeepSeek 充值页。"""
        assert "deepseek.com" in DeepSeekAdapter.top_up_url
        assert DeepSeekAdapter.top_up_url.startswith("https://")

    def test_login_url属性(self):
        """login_url 应指向 DeepSeek 登录页。"""
        assert "deepseek.com" in DeepSeekAdapter.login_url
        assert DeepSeekAdapter.login_url.startswith("https://")

    def test_supported_methods包含alipay_qr(self):
        """DeepSeek 适配器应支持支付宝扫码支付。"""
        assert PaymentMethod.alipay_qr in DeepSeekAdapter.supported_methods

    async def test_validate_amount_合法金额(self):
        """金额 >= 10 时，validate_amount 应返回 True。"""
        adapter = DeepSeekAdapter()
        assert await adapter.validate_amount(10.0) is True
        assert await adapter.validate_amount(100.0) is True
        assert await adapter.validate_amount(1000.0) is True

    async def test_validate_amount_非法金额(self):
        """金额 < 10 时，validate_amount 应返回 False。"""
        adapter = DeepSeekAdapter()
        assert await adapter.validate_amount(9.99) is False
        assert await adapter.validate_amount(0.0) is False
        assert await adapter.validate_amount(-1.0) is False

    def test_get_login_url(self):
        """get_login_url 应返回 login_url 属性值。"""
        adapter = DeepSeekAdapter()
        assert adapter.get_login_url() == DeepSeekAdapter.login_url

    def test_get_top_up_url(self):
        """get_top_up_url 应返回 top_up_url 属性值。"""
        adapter = DeepSeekAdapter()
        assert adapter.get_top_up_url() == DeepSeekAdapter.top_up_url


# ===========================================================================
# KimiAdapter 测试
# ===========================================================================


class TestKimiAdapter:
    """KimiAdapter 属性和方法测试。"""

    def test_name属性(self):
        """name 属性应为 'kimi'。"""
        assert KimiAdapter.name == "kimi"

    def test_display_name属性(self):
        """display_name 应包含 Kimi 标识。"""
        assert "Kimi" in KimiAdapter.display_name

    def test_top_up_url属性(self):
        """top_up_url 应指向 Kimi 充值页。"""
        assert "moonshot" in KimiAdapter.top_up_url or "kimi" in KimiAdapter.top_up_url
        assert KimiAdapter.top_up_url.startswith("https://")

    def test_supported_methods包含alipay_qr(self):
        """Kimi 适配器应支持支付宝扫码支付。"""
        assert PaymentMethod.alipay_qr in KimiAdapter.supported_methods

    async def test_validate_amount_合法金额(self):
        """金额 >= 10 时，validate_amount 应返回 True。"""
        adapter = KimiAdapter()
        assert await adapter.validate_amount(10.0) is True
        assert await adapter.validate_amount(500.0) is True

    async def test_validate_amount_非法金额(self):
        """金额 < 10 时，validate_amount 应返回 False。"""
        adapter = KimiAdapter()
        assert await adapter.validate_amount(9.0) is False
        assert await adapter.validate_amount(0.01) is False


# ===========================================================================
# QwenAdapter 测试
# ===========================================================================


class TestQwenAdapter:
    """QwenAdapter 属性和方法测试。"""

    def test_name属性(self):
        """name 属性应为 'qwen'。"""
        assert QwenAdapter.name == "qwen"

    def test_display_name属性(self):
        """display_name 应包含 Qwen 或通义千问标识。"""
        assert "Qwen" in QwenAdapter.display_name or "通义" in QwenAdapter.display_name

    def test_top_up_url属性(self):
        """top_up_url 应指向阿里云相关充值页。"""
        assert QwenAdapter.top_up_url.startswith("https://")

    def test_supported_methods包含alipay_qr(self):
        """Qwen 适配器应支持支付宝扫码支付。"""
        assert PaymentMethod.alipay_qr in QwenAdapter.supported_methods

    async def test_validate_amount_合法金额(self):
        """金额 >= 10 时，validate_amount 应返回 True。"""
        adapter = QwenAdapter()
        assert await adapter.validate_amount(10.0) is True
        assert await adapter.validate_amount(2000.0) is True

    async def test_validate_amount_非法金额(self):
        """金额 < 10 时，validate_amount 应返回 False。"""
        adapter = QwenAdapter()
        assert await adapter.validate_amount(5.0) is False
        assert await adapter.validate_amount(0.0) is False


# ===========================================================================
# SiteAdapter 抽象类测试
# ===========================================================================


class TestSiteAdapterABC:
    """SiteAdapter 抽象基类测试。"""

    def test_未实现execute_topup时不能实例化(self):
        """未实现 execute_topup 抽象方法的子类不应能被实例化。"""
        class IncompleteAdapter(SiteAdapter):
            name = "incomplete"
            display_name = "Incomplete"
            top_up_url = "https://example.com"
            login_url = "https://example.com/login"
            supported_methods = [PaymentMethod.alipay_qr]
            # 故意不实现 execute_topup

        with pytest.raises(TypeError):
            IncompleteAdapter()

    def test_完整实现可以实例化(self):
        """实现了所有抽象方法的子类应能正常实例化。"""
        class CompleteAdapter(SiteAdapter):
            name = "complete"
            display_name = "Complete"
            top_up_url = "https://example.com"
            login_url = "https://example.com/login"
            supported_methods = [PaymentMethod.alipay_qr]

            async def execute_topup(self, page, amount, method=None):
                return []

        adapter = CompleteAdapter()
        assert adapter is not None

    async def test_validate_amount默认实现_正数通过(self):
        """SiteAdapter 基类的 validate_amount 默认实现：amount > 0 返回 True。"""
        class MinimalAdapter(SiteAdapter):
            name = "minimal"
            display_name = "Minimal"
            top_up_url = "https://example.com"
            login_url = "https://example.com/login"
            supported_methods = []

            async def execute_topup(self, page, amount, method=None):
                return []

        adapter = MinimalAdapter()
        assert await adapter.validate_amount(0.01) is True
        assert await adapter.validate_amount(100.0) is True
        assert await adapter.validate_amount(0.0) is False


# ===========================================================================
# ScriptStep 测试
# ===========================================================================


class TestScriptStep:
    """ScriptStep 数据模型测试。"""

    def test_基本创建_navigate类型(self):
        """navigate 类型的 ScriptStep 应能正确创建。"""
        step = ScriptStep(
            description="导航到充值页",
            action="navigate",
            url="https://example.com/recharge",
        )
        assert step.description == "导航到充值页"
        assert step.action == "navigate"
        assert step.url == "https://example.com/recharge"
        assert step.selector is None
        assert step.value is None

    def test_基本创建_click类型(self):
        """click 类型的 ScriptStep 应能正确创建。"""
        step = ScriptStep(
            description="点击充值按钮",
            action="click",
            selector="button:has-text('充值')",
        )
        assert step.action == "click"
        assert step.selector == "button:has-text('充值')"

    def test_基本创建_fill类型(self):
        """fill 类型的 ScriptStep 应能携带 selector 和 value。"""
        step = ScriptStep(
            description="填写金额",
            action="fill",
            selector="input[name='amount']",
            value="100",
        )
        assert step.action == "fill"
        assert step.selector == "input[name='amount']"
        assert step.value == "100"

    def test_基本创建_detect_payment类型(self):
        """detect_payment 类型的 ScriptStep 用于通知检测器接管。"""
        step = ScriptStep(
            description="等待扫码",
            action="detect_payment",
            selector="[class*='qrcode']",
        )
        assert step.action == "detect_payment"

    def test_model_dump序列化(self):
        """model_dump 应返回包含所有字段的字典。"""
        step = ScriptStep(
            description="测试步骤",
            action="wait",
            selector="text=支付宝",
        )
        data = step.model_dump()
        assert "description" in data
        assert "action" in data
        assert "selector" in data
        assert "value" in data
        assert "url" in data


# ===========================================================================
# ScriptExecutionError 测试
# ===========================================================================


class TestScriptExecutionError:
    """ScriptExecutionError 异常类测试。"""

    def test_可以正常抛出和捕获(self):
        """ScriptExecutionError 应能被正常抛出并被 Exception 捕获。"""
        with pytest.raises(ScriptExecutionError, match="选择器失效"):
            raise ScriptExecutionError("选择器失效，触发回退")

    def test_携带错误消息(self):
        """ScriptExecutionError 应能携带具体错误描述信息。"""
        error_msg = "充值页 DOM 结构已变更，无法定位金额按钮"
        try:
            raise ScriptExecutionError(error_msg)
        except ScriptExecutionError as e:
            assert str(e) == error_msg

    def test_是Exception的子类(self):
        """ScriptExecutionError 应继承自 Exception。"""
        assert issubclass(ScriptExecutionError, Exception)
