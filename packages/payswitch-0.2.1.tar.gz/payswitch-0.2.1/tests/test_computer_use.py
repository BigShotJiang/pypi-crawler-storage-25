"""Controlled Computer Use explorer tests."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from payswitch.browser.computer_use import ComputerUseExplorer, ComputerUseUnavailableError
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import StepRecord
from payswitch.models.types import StepCategory, StepRisk


def _config(tmp_path: Path, **kwargs) -> PaySwitchConfig:
    return PaySwitchConfig(data_dir=tmp_path, llm_api_key="encoded-test-key", **kwargs)


def test_computer_use_explorer_availability_respects_config(tmp_path: Path):
    with patch("payswitch.browser.skyvern.SkyvernEngine") as MockSkyvern:
        mock_engine = MagicMock()
        mock_engine.is_available.return_value = True
        MockSkyvern.return_value = mock_engine

        explorer = ComputerUseExplorer(_config(tmp_path, computer_use_enabled=False))

    assert explorer.is_available() is False


@pytest.mark.asyncio
async def test_computer_use_explorer_marks_steps_as_checkout_prep(tmp_path: Path):
    raw_steps = [StepRecord(step_index=0, description="找到会员入口", status="success")]

    with patch("payswitch.browser.skyvern.SkyvernEngine") as MockSkyvern:
        mock_engine = MagicMock()
        mock_engine.is_available.return_value = True
        mock_engine.execute_task = AsyncMock(return_value=raw_steps)
        MockSkyvern.return_value = mock_engine

        explorer = ComputerUseExplorer(_config(tmp_path))
        steps = await explorer.explore_checkout(
            page=MagicMock(),
            payee="kimi",
            amount=10.0,
            method="alipay_qr",
            url="https://www.kimi.com",
        )

    assert steps[0].category == StepCategory.checkout_prep
    assert steps[0].risk == StepRisk.medium
    mock_engine.execute_task.assert_awaited_once()


@pytest.mark.asyncio
async def test_computer_use_explorer_blocks_when_policy_disallows_checkout_prep(
    tmp_path: Path,
):
    with patch("payswitch.browser.skyvern.SkyvernEngine") as MockSkyvern:
        mock_engine = MagicMock()
        mock_engine.is_available.return_value = True
        MockSkyvern.return_value = mock_engine

        explorer = ComputerUseExplorer(
            _config(
                tmp_path,
                computer_use_max_autonomous_category=StepCategory.identity,
            )
        )

        with pytest.raises(ComputerUseUnavailableError):
            await explorer.explore_checkout(
                page=MagicMock(),
                payee="kimi",
                amount=10.0,
                method="alipay_qr",
                url="https://www.kimi.com",
            )
