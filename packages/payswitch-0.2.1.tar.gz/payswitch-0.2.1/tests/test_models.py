"""Pay-Switch 数据模型单元测试。

覆盖范围：
- TransactionStatus / PaymentMethod / ExecutionMode / DisplayMode 枚举
- Transaction 的自动生成 tx_id、add_step、is_terminal 等方法
- StepRecord 和 HumanAction 的创建与计时方法
- PaySwitchConfig 的加载、保存、更新和 API Key 编解码
- PlatformProfile 的校验器和状态方法
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import pytest
from pydantic import ValidationError

from payswitch.models.config import PaySwitchConfig
from payswitch.models.profile import PlatformProfile
from payswitch.models.transaction import HumanAction, StepRecord, Transaction
from payswitch.models.types import (
    ComputerUseDriver,
    DisplayMode,
    ExecutionMode,
    PaymentMethod,
    StepCategory,
    StepRisk,
    TransactionStatus,
)


# ===========================================================================
# StrEnum 枚举测试
# ===========================================================================


class TestTransactionStatus:
    """TransactionStatus 枚举测试。"""

    def test_所有枚举值可用字符串访问(self):
        """验证所有枚举成员都能通过字符串值反向查找。"""
        assert TransactionStatus("pending") == TransactionStatus.pending
        assert TransactionStatus("executing") == TransactionStatus.executing
        assert TransactionStatus("human_action_required") == TransactionStatus.human_action_required
        assert TransactionStatus("completed") == TransactionStatus.completed
        assert TransactionStatus("failed") == TransactionStatus.failed
        assert TransactionStatus("cancelled") == TransactionStatus.cancelled
        assert TransactionStatus("timeout") == TransactionStatus.timeout

    def test_枚举值等于字符串(self):
        """StrEnum 成员应直接等于其字符串值。"""
        assert TransactionStatus.pending == "pending"
        assert TransactionStatus.completed == "completed"
        assert TransactionStatus.failed == "failed"

    def test_终态集合包含正确成员(self):
        """验证终态枚举值集合的完整性（供 is_terminal 逻辑使用）。"""
        terminal_statuses = {
            TransactionStatus.completed,
            TransactionStatus.failed,
            TransactionStatus.cancelled,
            TransactionStatus.timeout,
        }
        # pending 和 executing 不是终态
        assert TransactionStatus.pending not in terminal_statuses
        assert TransactionStatus.executing not in terminal_statuses
        assert TransactionStatus.human_action_required not in terminal_statuses


class TestPaymentMethod:
    """PaymentMethod 枚举测试。"""

    def test_所有枚举值可用字符串访问(self):
        assert PaymentMethod("alipay_qr") == PaymentMethod.alipay_qr
        assert PaymentMethod("bankcard") == PaymentMethod.bankcard
        assert PaymentMethod("stripe") == PaymentMethod.stripe
        assert PaymentMethod("auto") == PaymentMethod.auto

    def test_枚举值等于字符串(self):
        assert PaymentMethod.alipay_qr == "alipay_qr"
        assert PaymentMethod.auto == "auto"


class TestExecutionMode:
    """ExecutionMode 枚举测试。"""

    def test_所有枚举值可用字符串访问(self):
        assert ExecutionMode("script") == ExecutionMode.script
        assert ExecutionMode("smart") == ExecutionMode.smart
        assert ExecutionMode("computer_use") == ExecutionMode.computer_use
        assert ExecutionMode("human_takeover") == ExecutionMode.human_takeover


class TestDisplayMode:
    """DisplayMode 枚举测试。"""

    def test_所有枚举值可用字符串访问(self):
        assert DisplayMode("headed") == DisplayMode.headed
        assert DisplayMode("novnc") == DisplayMode.novnc


class TestComputerUseEnums:
    """Computer Use 相关枚举测试。"""

    def test_step_category_values(self):
        assert StepCategory("nav") == StepCategory.nav
        assert StepCategory("checkout_prep") == StepCategory.checkout_prep
        assert StepCategory("final_authorization") == StepCategory.final_authorization

    def test_step_risk_values(self):
        assert StepRisk("low") == StepRisk.low
        assert StepRisk("human_required") == StepRisk.human_required

    def test_computer_use_driver_values(self):
        assert ComputerUseDriver("external") == ComputerUseDriver.external
        assert ComputerUseDriver("internal") == ComputerUseDriver.internal
        assert ComputerUseDriver("hybrid") == ComputerUseDriver.hybrid


class TestComputerUseConfigDefaults:
    """Computer Use 配置默认值测试。"""

    def test_computer_use_defaults_to_external_checkout_prep(self):
        config = PaySwitchConfig()
        assert config.computer_use_enabled is True
        assert config.computer_use_driver == ComputerUseDriver.external
        assert config.computer_use_max_autonomous_category == StepCategory.checkout_prep
        assert config.chrome_cdp_url == ""
        assert config.chrome_user_data_dir == ""
        assert config.chrome_profile_directory == ""
        assert config.chrome_expected_profile_email == ""
        assert config.browser_channel == "chrome"

    def test_config_update_validates_computer_use_enums(self, tmp_path: Path):
        config = PaySwitchConfig(data_dir=tmp_path)

        with patch.object(PaySwitchConfig, "save") as mock_save:
            updated = config.update(
                computer_use_driver="hybrid",
                computer_use_max_autonomous_category="identity",
            )

        assert updated.computer_use_driver == ComputerUseDriver.hybrid
        assert updated.computer_use_max_autonomous_category == StepCategory.identity
        mock_save.assert_called_once()


# ===========================================================================
# Transaction 测试
# ===========================================================================


class TestTransaction:
    """Transaction 模型测试。"""

    def test_tx_id自动生成且带txn前缀(self):
        """未指定 tx_id 时，应自动生成 txn_ 前缀的唯一 ID。"""
        tx = Transaction(amount=100.0, payee="deepseek")
        assert tx.tx_id.startswith("txn_")
        # 格式为 txn_ + 12 位十六进制字符
        assert len(tx.tx_id) == 4 + 12

    def test_不同交易的tx_id唯一(self):
        """连续创建多笔交易，tx_id 应各不相同。"""
        ids = {Transaction(amount=10.0, payee="kimi").tx_id for _ in range(20)}
        assert len(ids) == 20

    def test_tx_id格式校验_非txn前缀应报错(self):
        """手动指定不以 txn_ 开头的 tx_id 时应抛出 ValidationError。"""
        with pytest.raises(ValidationError):
            Transaction(tx_id="invalid_id", amount=100.0, payee="deepseek")

    def test_货币代码自动转大写(self):
        """传入小写货币代码时，应自动转为大写。"""
        tx = Transaction(amount=50.0, payee="kimi", currency="cny")
        assert tx.currency == "CNY"

    def test_默认状态为pending(self):
        """新创建的交易默认状态应为 pending。"""
        tx = Transaction(amount=10.0, payee="deepseek")
        assert tx.status == TransactionStatus.pending

    def test_金额必须大于0(self):
        """amount <= 0 时应抛出 ValidationError。"""
        with pytest.raises(ValidationError):
            Transaction(amount=0.0, payee="deepseek")
        with pytest.raises(ValidationError):
            Transaction(amount=-1.0, payee="deepseek")

    def test_is_terminal_completed状态返回True(self):
        """completed 是终态，is_terminal 应返回 True。"""
        tx = Transaction(
            amount=100.0, payee="deepseek", status=TransactionStatus.completed
        )
        assert tx.is_terminal() is True

    def test_is_terminal_failed状态返回True(self):
        """failed 是终态，is_terminal 应返回 True。"""
        tx = Transaction(
            amount=100.0, payee="deepseek", status=TransactionStatus.failed
        )
        assert tx.is_terminal() is True

    def test_is_terminal_cancelled状态返回True(self):
        """cancelled 是终态，is_terminal 应返回 True。"""
        tx = Transaction(
            amount=100.0, payee="deepseek", status=TransactionStatus.cancelled
        )
        assert tx.is_terminal() is True

    def test_is_terminal_timeout状态返回True(self):
        """timeout 是终态，is_terminal 应返回 True。"""
        tx = Transaction(
            amount=100.0, payee="deepseek", status=TransactionStatus.timeout
        )
        assert tx.is_terminal() is True

    def test_is_terminal_pending状态返回False(self):
        """pending 不是终态，is_terminal 应返回 False。"""
        tx = Transaction(amount=100.0, payee="deepseek")
        assert tx.is_terminal() is False

    def test_is_terminal_executing状态返回False(self):
        """executing 不是终态，is_terminal 应返回 False。"""
        tx = Transaction(
            amount=100.0, payee="deepseek", status=TransactionStatus.executing
        )
        assert tx.is_terminal() is False

    def test_add_step返回新实例且原实例不变(self):
        """add_step 应遵循不可变设计，返回新实例，原实例步骤列表不变。"""
        original = Transaction(amount=50.0, payee="kimi")
        updated = original.add_step("导航到充值页面")
        # 原实例步骤不变
        assert len(original.steps) == 0
        # 新实例包含新增步骤
        assert len(updated.steps) == 1
        assert updated.steps[0].description == "导航到充值页面"
        assert updated.steps[0].step_index == 0

    def test_add_step多次追加步骤索引递增(self):
        """多次调用 add_step 时，step_index 应从 0 依次递增。"""
        tx = Transaction(amount=100.0, payee="qwen")
        tx = tx.add_step("第一步")
        tx = tx.add_step("第二步")
        tx = tx.add_step("第三步")
        assert len(tx.steps) == 3
        assert tx.steps[0].step_index == 0
        assert tx.steps[1].step_index == 1
        assert tx.steps[2].step_index == 2

    def test_model_dump和model_validate往返序列化(self):
        """model_dump + model_validate 应能完整还原对象。"""
        tx = Transaction(
            amount=200.0,
            payee="deepseek",
            reason="测试充值",
            payment_method=PaymentMethod.alipay_qr,
            execution_mode=ExecutionMode.script,
            idempotency_key="test-key-001",
        )
        dumped = tx.model_dump()
        restored = Transaction.model_validate(dumped)
        assert restored.tx_id == tx.tx_id
        assert restored.amount == tx.amount
        assert restored.payee == tx.payee
        assert restored.reason == tx.reason
        assert restored.payment_method == tx.payment_method
        assert restored.idempotency_key == tx.idempotency_key

    def test_is_waiting_human(self):
        """当状态为 human_action_required 时，is_waiting_human 应返回 True。"""
        tx = Transaction(
            amount=50.0,
            payee="kimi",
            status=TransactionStatus.human_action_required,
        )
        assert tx.is_waiting_human() is True
        # 其他状态应返回 False
        tx2 = Transaction(amount=50.0, payee="kimi")
        assert tx2.is_waiting_human() is False

    def test_duration_seconds未完成返回None(self):
        """未设置 completed_at 时，duration_seconds 应返回 None。"""
        tx = Transaction(amount=10.0, payee="deepseek")
        assert tx.duration_seconds() is None

    def test_duration_seconds已完成返回正确值(self):
        """设置了 created_at 和 completed_at 时，duration_seconds 应返回正确秒数。"""
        from datetime import timedelta

        created = datetime(2025, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        completed = created + timedelta(seconds=42)
        tx = Transaction(
            amount=10.0,
            payee="deepseek",
            status=TransactionStatus.completed,
            created_at=created,
            completed_at=completed,
        )
        assert tx.duration_seconds() == pytest.approx(42.0)


# ===========================================================================
# StepRecord 测试
# ===========================================================================


class TestStepRecord:
    """StepRecord 模型测试。"""

    def test_基本创建(self):
        """验证 StepRecord 能正确创建并携带必要字段。"""
        step = StepRecord(step_index=0, description="导航到充值页面")
        assert step.step_index == 0
        assert step.description == "导航到充值页面"
        assert step.status == "pending"
        assert step.category == StepCategory.nav
        assert step.risk == StepRisk.low

    def test_step_index不能为负数(self):
        """step_index 不允许小于 0。"""
        with pytest.raises(ValidationError):
            StepRecord(step_index=-1, description="非法步骤")

    def test_duration_seconds未完成返回None(self):
        """未设置 completed_at 时应返回 None。"""
        step = StepRecord(step_index=0, description="测试步骤")
        assert step.duration_seconds() is None

    def test_duration_seconds已完成返回正确值(self):
        """设置了开始和完成时间时，应返回正确耗时秒数。"""
        from datetime import timedelta

        started = datetime(2025, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        completed = started + timedelta(seconds=5)
        step = StepRecord(
            step_index=0,
            description="测试步骤",
            started_at=started,
            completed_at=completed,
        )
        assert step.duration_seconds() == pytest.approx(5.0)

    def test_model_dump序列化包含所有字段(self):
        """model_dump 应包含所有定义字段。"""
        step = StepRecord(step_index=1, description="点击按钮", status="success")
        data = step.model_dump()
        assert "step_index" in data
        assert "description" in data
        assert "status" in data
        assert "category" in data
        assert "risk" in data


# ===========================================================================
# HumanAction 测试
# ===========================================================================


class TestHumanAction:
    """HumanAction 模型测试。"""

    def test_基本创建(self):
        """验证 HumanAction 能正确创建。"""
        now = datetime.now(timezone.utc)
        action = HumanAction(action_type="scan_qr", requested_at=now)
        assert action.action_type == "scan_qr"
        assert action.completed_at is None

    def test_is_completed_未完成时返回False(self):
        """未设置 completed_at 时，is_completed 应返回 False。"""
        action = HumanAction(
            action_type="scan_qr", requested_at=datetime.now(timezone.utc)
        )
        assert action.is_completed() is False

    def test_is_completed_已完成时返回True(self):
        """设置了 completed_at 时，is_completed 应返回 True。"""
        now = datetime.now(timezone.utc)
        action = HumanAction(
            action_type="scan_qr",
            requested_at=now,
            completed_at=now,
        )
        assert action.is_completed() is True

    def test_waiting_seconds计算等待时间(self):
        """设置了 requested_at 和 completed_at 时，waiting_seconds 应返回正确值。"""
        from datetime import timedelta

        requested = datetime(2025, 1, 1, 10, 0, 0, tzinfo=timezone.utc)
        completed = requested + timedelta(seconds=30)
        action = HumanAction(
            action_type="confirm",
            requested_at=requested,
            completed_at=completed,
        )
        assert action.waiting_seconds() == pytest.approx(30.0)

    def test_waiting_seconds未完成时返回None(self):
        """未完成时 waiting_seconds 应返回 None。"""
        action = HumanAction(
            action_type="fill_form", requested_at=datetime.now(timezone.utc)
        )
        assert action.waiting_seconds() is None


# ===========================================================================
# PaySwitchConfig 测试
# ===========================================================================


class TestPaySwitchConfig:
    """PaySwitchConfig 模型测试。"""

    def test_默认值正确(self):
        """验证所有字段的默认值符合预期。"""
        config = PaySwitchConfig()
        assert config.max_per_transaction == 500.0
        assert config.daily_limit == 2000.0
        assert config.whitelist == []
        assert config.auto_confirm_threshold == 0.0
        assert config.default_currency == "CNY"
        assert config.llm_provider == "openai"
        assert config.llm_api_key == ""
        assert config.llm_model == "gpt-4o"
        assert config.display_mode is None
        assert config.novnc_port == 6080
        assert config.transaction_timeout == 300

    def test_load_文件不存在时创建默认配置(self, tmp_path):
        """配置文件不存在时，load 应自动创建并返回默认配置。"""
        config_file = tmp_path / "config.json"
        assert not config_file.exists()
        config = PaySwitchConfig.load(config_file)
        # 自动创建了文件
        assert config_file.exists()
        # 返回默认配置
        assert config.max_per_transaction == 500.0
        assert config.daily_limit == 2000.0

    def test_save和load往返持久化(self, tmp_path):
        """save 写入的文件应能被 load 完整还原。"""
        config_file = tmp_path / "config.json"
        original = PaySwitchConfig(
            max_per_transaction=300.0,
            daily_limit=1000.0,
            whitelist=["deepseek", "kimi"],
            llm_provider="anthropic",
        )
        original.save(config_file)
        restored = PaySwitchConfig.load(config_file)
        assert restored.max_per_transaction == 300.0
        assert restored.daily_limit == 1000.0
        assert restored.whitelist == ["deepseek", "kimi"]
        assert restored.llm_provider == "anthropic"

    def test_save自动创建父目录(self, tmp_path):
        """配置文件父目录不存在时，save 应自动创建。"""
        nested_file = tmp_path / "a" / "b" / "config.json"
        config = PaySwitchConfig()
        config.save(nested_file)
        assert nested_file.exists()

    def test_load_json损坏时返回默认配置(self, tmp_path):
        """配置文件内容不合法时，load 应降级返回默认配置。"""
        config_file = tmp_path / "config.json"
        config_file.write_text("{invalid json{{", encoding="utf-8")
        config = PaySwitchConfig.load(config_file)
        # 解析失败，返回默认值
        assert config.max_per_transaction == 500.0

    def test_update返回新实例且原实例不变(self, tmp_path):
        """update 应返回新实例，原实例不被修改（不可变语义）。"""
        config_file = tmp_path / "config.json"
        original = PaySwitchConfig(max_per_transaction=500.0)
        original.save(config_file)
        # update 会调用 save()，使用默认路径，此处只验证返回值
        updated = original.model_copy(update={"max_per_transaction": 200.0})
        assert original.max_per_transaction == 500.0
        assert updated.max_per_transaction == 200.0

    def test_get_llm_api_key_空字符串返回空(self):
        """未设置 llm_api_key 时，get_llm_api_key 应返回空字符串。"""
        config = PaySwitchConfig()
        assert config.get_llm_api_key() == ""

    def test_set_llm_api_key编码解码往返(self, tmp_path):
        """set_llm_api_key 应将明文 key 编码后存储，get_llm_api_key 可正确解码。"""
        import base64

        config_file = tmp_path / "config.json"
        config = PaySwitchConfig()
        config.save(config_file)
        # 手动模拟编码逻辑（不调用 save 到默认路径）
        plaintext = "sk-test-api-key-12345"
        encoded = base64.b64encode(plaintext.encode("utf-8")).decode("ascii")
        config_with_key = config.model_copy(update={"llm_api_key": encoded})
        assert config_with_key.get_llm_api_key() == plaintext

    def test_data_dir字符串路径自动转Path(self):
        """传入字符串路径时，data_dir 应自动转换为 Path 对象。"""
        config = PaySwitchConfig(data_dir="/tmp/payswitch_test")
        assert isinstance(config.data_dir, Path)

    def test_max_per_transaction不能为负(self):
        """max_per_transaction < 0 时应抛出 ValidationError。"""
        with pytest.raises(ValidationError):
            PaySwitchConfig(max_per_transaction=-1.0)

    def test_novnc_port范围校验(self):
        """novnc_port 不在 1024-65535 范围内时应抛出 ValidationError。"""
        with pytest.raises(ValidationError):
            PaySwitchConfig(novnc_port=80)
        with pytest.raises(ValidationError):
            PaySwitchConfig(novnc_port=70000)

    def test_transaction_timeout最小值(self):
        """transaction_timeout < 30 时应抛出 ValidationError。"""
        with pytest.raises(ValidationError):
            PaySwitchConfig(transaction_timeout=10)

    def test_model_dump_mode_json序列化(self):
        """model_dump(mode='json') 应返回可 JSON 序列化的字典。"""
        config = PaySwitchConfig()
        data = config.model_dump(mode="json")
        # 确保能正常 JSON 序列化（不抛出异常）
        json_str = json.dumps(data)
        assert isinstance(json_str, str)


# ===========================================================================
# PlatformProfile 测试
# ===========================================================================


class TestPlatformProfile:
    """PlatformProfile 模型测试。"""

    def _make_profile(self, platform: str = "deepseek", **kwargs) -> PlatformProfile:
        """创建测试用 PlatformProfile 的辅助方法。"""
        defaults = {
            "platform": platform,
            "display_name": "DeepSeek",
            "profile_dir": "/tmp/payswitch/profiles/deepseek",
        }
        defaults.update(kwargs)
        return PlatformProfile(**defaults)

    def test_基本创建(self):
        """验证 PlatformProfile 能正确创建并携带基本字段。"""
        profile = self._make_profile()
        assert profile.platform == "deepseek"
        assert profile.display_name == "DeepSeek"
        assert isinstance(profile.profile_dir, Path)

    def test_platform校验器_大写字母应报错(self):
        """平台标识符包含大写字母时，校验器应抛出 ValidationError。"""
        with pytest.raises(ValidationError, match="平台标识符只能包含小写字母"):
            self._make_profile(platform="DeepSeek")

    def test_platform校验器_含空格应报错(self):
        """平台标识符包含空格时，校验器应抛出 ValidationError。"""
        with pytest.raises(ValidationError, match="平台标识符只能包含小写字母"):
            self._make_profile(platform="deep seek")

    def test_platform校验器_含连字符应报错(self):
        """平台标识符包含连字符（-）时，校验器应抛出 ValidationError。"""
        with pytest.raises(ValidationError, match="平台标识符只能包含小写字母"):
            self._make_profile(platform="deep-seek")

    def test_platform校验器_下划线合法(self):
        """平台标识符含下划线时，校验器应通过。"""
        profile = self._make_profile(platform="my_platform")
        assert profile.platform == "my_platform"

    def test_platform校验器_数字合法(self):
        """平台标识符含数字时，校验器应通过。"""
        profile = self._make_profile(platform="platform2")
        assert profile.platform == "platform2"

    def test_profile_dir字符串路径转Path(self):
        """传入字符串路径时，profile_dir 应自动转换为 Path 对象。"""
        profile = self._make_profile()
        assert isinstance(profile.profile_dir, Path)

    def test_默认状态为unknown(self):
        """新创建的 Profile 默认状态应为 unknown。"""
        profile = self._make_profile()
        assert profile.status == "unknown"

    def test_is_active_active状态返回True(self):
        """status=active 时，is_active 应返回 True。"""
        profile = self._make_profile(status="active")
        assert profile.is_active() is True

    def test_is_active_非active状态返回False(self):
        """status 不是 active 时，is_active 应返回 False。"""
        profile = self._make_profile(status="expired")
        assert profile.is_active() is False
        profile2 = self._make_profile(status="unknown")
        assert profile2.is_active() is False

    def test_mark_expired返回新实例状态为expired(self):
        """mark_expired 应返回 status=expired 的新实例，原实例不变。"""
        original = self._make_profile(status="active")
        expired = original.mark_expired()
        assert original.status == "active"
        assert expired.status == "expired"

    def test_mark_used更新last_used_at(self):
        """mark_used 应在新实例上设置 last_used_at，原实例不变。"""
        original = self._make_profile()
        assert original.last_used_at is None
        used = original.mark_used()
        assert original.last_used_at is None  # 原实例不变
        assert used.last_used_at is not None  # 新实例已更新

    def test_model_dump和model_validate往返序列化(self):
        """model_dump + model_validate 应能完整还原 PlatformProfile。"""
        now = datetime.now(timezone.utc)
        profile = PlatformProfile(
            platform="kimi",
            display_name="Kimi (Moonshot)",
            profile_dir="/tmp/payswitch/profiles/kimi",
            logged_in_at=now,
            status="active",
            top_up_url="https://kimi.moonshot.cn/recharge",
        )
        dumped = profile.model_dump()
        restored = PlatformProfile.model_validate(dumped)
        assert restored.platform == profile.platform
        assert restored.display_name == profile.display_name
        assert restored.status == profile.status
        assert restored.top_up_url == profile.top_up_url
