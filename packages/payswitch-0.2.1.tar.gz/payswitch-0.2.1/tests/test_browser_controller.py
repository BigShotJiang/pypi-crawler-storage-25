"""BrowserController 轻量 computer-use 能力测试。"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from payswitch.browser.controller import BrowserController, BrowserControllerError


@pytest.mark.asyncio
async def test_list_clickable_elements缓存识别结果() -> None:
    ctrl = BrowserController()
    fake_page = MagicMock()
    fake_page.evaluate = AsyncMock(
        return_value=[
            {
                "index": 0,
                "tag": "button",
                "text": "立即购买",
                "selector": "#buy",
                "x": 100,
                "y": 200,
            },
            {"index": 1, "tag": "a", "text": "去支付", "selector": "a.pay", "x": 120, "y": 220},
        ]
    )
    ctrl._page = fake_page

    items = await ctrl.list_clickable_elements(limit=10)

    assert len(items) == 2
    assert ctrl._last_clickables == items
    fake_page.evaluate.assert_awaited_once()


@pytest.mark.asyncio
async def test_click_clickable_index按selector点击() -> None:
    ctrl = BrowserController()
    fake_page = MagicMock()
    fake_page.click = AsyncMock()
    fake_page.mouse = MagicMock()
    fake_page.mouse.click = AsyncMock()
    ctrl._page = fake_page
    ctrl._last_clickables = [
        {"index": 0, "tag": "button", "text": "提交", "selector": "#submit", "x": 50, "y": 60}
    ]

    target = await ctrl.click_clickable_index(0)

    assert target["text"] == "提交"
    fake_page.click.assert_awaited_once_with("#submit", timeout=5_000)
    fake_page.mouse.click.assert_not_called()


@pytest.mark.asyncio
async def test_click_clickable_text模糊匹配() -> None:
    ctrl = BrowserController()
    fake_page = MagicMock()
    fake_page.click = AsyncMock()
    fake_page.mouse = MagicMock()
    fake_page.mouse.click = AsyncMock()
    ctrl._page = fake_page
    ctrl._last_clickables = [
        {
            "index": 0,
            "tag": "button",
            "text": "确认并支付",
            "selector": "button.pay",
            "x": 11,
            "y": 22,
        }
    ]

    target = await ctrl.click_clickable_text("支付")

    assert target["index"] == 0
    fake_page.click.assert_awaited_once()


@pytest.mark.asyncio
async def test_click_clickable_text未命中抛错() -> None:
    ctrl = BrowserController()
    fake_page = MagicMock()
    fake_page.evaluate = AsyncMock(return_value=[])
    ctrl._page = fake_page

    with pytest.raises(BrowserControllerError, match="未找到匹配文本"):
        await ctrl.click_clickable_text("不存在的按钮")
