"""Chrome profile identity helpers."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from payswitch.browser.chrome_profiles import (
    identity_matches_email,
    list_profile_identities,
    resolve_cdp_profile_identity,
    resolve_profile_identity,
)


def _write_local_state(root: Path, email: str) -> None:
    root.mkdir(parents=True, exist_ok=True)
    (root / "Local State").write_text(
        json.dumps(
            {
                "profile": {
                    "info_cache": {
                        "Default": {
                            "name": "用户1",
                            "user_name": email,
                            "gaia_name": "G Leon",
                        }
                    }
                }
            }
        ),
        encoding="utf-8",
    )


def test_resolve_profile_identity_matches_expected_email(tmp_path: Path) -> None:
    _write_local_state(tmp_path, "cine.dreamer.one@gmail.com")

    identity = resolve_profile_identity(tmp_path, "Default")

    assert identity is not None
    assert identity.user_name == "cine.dreamer.one@gmail.com"
    assert identity_matches_email(identity, "CINE.DREAMER.ONE@gmail.com")


def test_list_profile_identities_shows_directory_email_and_names(
    tmp_path: Path,
) -> None:
    (tmp_path / "Default").mkdir(parents=True)
    (tmp_path / "Profile 2").mkdir(parents=True)
    (tmp_path / "Profile 10").mkdir(parents=True)
    (tmp_path / "Profile 9").mkdir(parents=True)
    (tmp_path / "Local State").write_text(
        json.dumps(
            {
                "profile": {
                    "info_cache": {
                        "Profile 2": {
                            "name": "Work",
                            "user_name": "work@example.com",
                            "gaia_name": "Work User",
                            "gaia_given_name": "Work",
                            "is_consented_primary_account": True,
                            "active_time": 123.5,
                        },
                        "Profile 10": {
                            "name": "Later",
                            "user_name": "later@example.com",
                        },
                        "Default": {
                            "name": "Personal",
                            "user_name": "cine.dreamer.one@gmail.com",
                            "gaia_name": "Leon",
                        },
                        "Deleted": {
                            "name": "Old",
                            "user_name": "old@example.com",
                        },
                    }
                }
            }
        ),
        encoding="utf-8",
    )

    identities = list_profile_identities(tmp_path)

    assert [identity.profile_directory for identity in identities] == [
        "Default",
        "Profile 2",
        "Profile 10",
    ]
    assert identities[0].user_name == "cine.dreamer.one@gmail.com"
    assert identities[1].name == "Work"
    assert identities[1].gaia_name == "Work User"
    assert identities[1].gaia_given_name == "Work"
    assert identities[1].is_consented_primary_account is True
    assert identities[1].active_time == 123.5


def test_resolve_cdp_profile_identity_parses_user_data_dir_with_spaces(
    tmp_path: Path,
) -> None:
    user_data_dir = tmp_path / "Application Support" / "Google" / "Chrome"
    _write_local_state(user_data_dir, "cine.dreamer.one@gmail.com")
    ps_output = (
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome "
        f"--user-data-dir={user_data_dir} "
        "--profile-directory=Default "
        "--remote-debugging-address=127.0.0.1 "
        "--remote-debugging-port=9238 about:blank\n"
    )

    with patch("subprocess.check_output", return_value=ps_output):
        identity = resolve_cdp_profile_identity("http://127.0.0.1:9238")

    assert identity is not None
    assert identity.user_data_dir == user_data_dir
    assert identity.profile_directory == "Default"
    assert identity.user_name == "cine.dreamer.one@gmail.com"
