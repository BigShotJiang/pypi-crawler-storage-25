"""Pay-Switch Ledger（账本）模块单元测试。

覆盖范围：
- record：插入交易记录及主键冲突校验
- get：按 tx_id 查询单条记录
- update_status：状态更新及不存在时的错误处理
- check_idempotency：48小时幂等窗口内命中 / 窗口外未命中
- get_daily_total：仅统计 completed 状态，其余状态不参与
- list_transactions：分页（limit/offset）和状态过滤
- close / context manager：连接释放
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from payswitch.engine.ledger import Ledger
from payswitch.models.transaction import Transaction
from payswitch.models.types import TransactionStatus


# ===========================================================================
# Fixtures
# ===========================================================================


@pytest.fixture
def ledger(tmp_path: Path) -> Ledger:
    """每个测试用例使用独立的临时数据库（自动关闭）。"""
    db_file = tmp_path / "test_payswitch.db"
    with Ledger(db_file) as l:
        yield l


def _make_tx(
    amount: float = 100.0,
    payee: str = "deepseek",
    status: TransactionStatus = TransactionStatus.pending,
    idempotency_key: str | None = None,
    created_at: datetime | None = None,
) -> Transaction:
    """创建测试用 Transaction 的辅助函数。"""
    kwargs = {
        "amount": amount,
        "payee": payee,
        "status": status,
        "idempotency_key": idempotency_key,
    }
    if created_at is not None:
        kwargs["created_at"] = created_at
    return Transaction(**kwargs)


# ===========================================================================
# record 测试
# ===========================================================================


class TestLedgerRecord:
    """Ledger.record 方法测试。"""

    def test_record成功插入交易(self, ledger: Ledger):
        """record 后应能通过 get 查到该交易。"""
        tx = _make_tx(amount=50.0, payee="kimi")
        ledger.record(tx)
        retrieved = ledger.get(tx.tx_id)
        assert retrieved is not None
        assert retrieved.tx_id == tx.tx_id
        assert retrieved.amount == 50.0
        assert retrieved.payee == "kimi"

    def test_record重复tx_id抛出IntegrityError(self, ledger: Ledger):
        """插入相同 tx_id 的记录时应抛出 sqlite3.IntegrityError。"""
        import sqlite3

        tx = _make_tx()
        ledger.record(tx)
        with pytest.raises(sqlite3.IntegrityError):
            ledger.record(tx)

    def test_record保留状态字段(self, ledger: Ledger):
        """record 时指定的 status 应被正确存储。"""
        tx = _make_tx(status=TransactionStatus.completed)
        ledger.record(tx)
        retrieved = ledger.get(tx.tx_id)
        assert retrieved is not None
        assert retrieved.status == TransactionStatus.completed

    def test_record保留幂等键(self, ledger: Ledger):
        """record 时指定的 idempotency_key 应被正确存储。"""
        tx = _make_tx(idempotency_key="my-unique-key-001")
        ledger.record(tx)
        retrieved = ledger.get(tx.tx_id)
        assert retrieved is not None
        assert retrieved.idempotency_key == "my-unique-key-001"

    def test_record含steps的交易(self, ledger: Ledger):
        """含步骤记录的交易应能正确序列化/反序列化。"""
        tx = _make_tx()
        tx = tx.add_step("步骤一：导航到充值页")
        tx = tx.add_step("步骤二：填写金额")
        ledger.record(tx)
        retrieved = ledger.get(tx.tx_id)
        assert retrieved is not None
        assert len(retrieved.steps) == 2
        assert retrieved.steps[0].description == "步骤一：导航到充值页"
        assert retrieved.steps[1].description == "步骤二：填写金额"


# ===========================================================================
# get 测试
# ===========================================================================


class TestLedgerGet:
    """Ledger.get 方法测试。"""

    def test_get不存在的tx_id返回None(self, ledger: Ledger):
        """查询不存在的 tx_id 时，get 应返回 None。"""
        result = ledger.get("txn_nonexistent")
        assert result is None

    def test_get返回正确对象(self, ledger: Ledger):
        """get 应返回完整的 Transaction 对象，字段与插入时一致。"""
        tx = _make_tx(amount=300.0, payee="qwen")
        ledger.record(tx)
        retrieved = ledger.get(tx.tx_id)
        assert retrieved is not None
        assert retrieved.amount == 300.0
        assert retrieved.payee == "qwen"


# ===========================================================================
# update_status 测试
# ===========================================================================


class TestLedgerUpdateStatus:
    """Ledger.update_status 方法测试。"""

    def test_update_status更新状态为completed(self, ledger: Ledger):
        """将交易状态更新为 completed 后应能查到新状态。"""
        tx = _make_tx()
        ledger.record(tx)
        now = datetime.now(timezone.utc)
        ledger.update_status(
            tx.tx_id,
            TransactionStatus.completed,
            completed_at=now,
        )
        retrieved = ledger.get(tx.tx_id)
        assert retrieved is not None
        assert retrieved.status == TransactionStatus.completed
        assert retrieved.completed_at is not None

    def test_update_status更新状态为failed并携带error(self, ledger: Ledger):
        """更新为 failed 状态并传入 error 消息时，应能查到 error 字段。"""
        tx = _make_tx()
        ledger.record(tx)
        ledger.update_status(
            tx.tx_id,
            TransactionStatus.failed,
            error="页面加载超时",
        )
        retrieved = ledger.get(tx.tx_id)
        assert retrieved is not None
        assert retrieved.status == TransactionStatus.failed
        assert retrieved.error == "页面加载超时"

    def test_update_status不存在的tx_id抛出ValueError(self, ledger: Ledger):
        """对不存在的 tx_id 调用 update_status 时，应抛出 ValueError。"""
        with pytest.raises(ValueError, match="交易不存在"):
            ledger.update_status("txn_ghost", TransactionStatus.completed)

    def test_update_status更新步骤列表(self, ledger: Ledger):
        """通过 update_status 更新 steps 列表后，应能查到新步骤。"""
        from payswitch.models.transaction import StepRecord

        tx = _make_tx()
        ledger.record(tx)
        steps = [
            StepRecord(step_index=0, description="第一步", status="success"),
            StepRecord(step_index=1, description="第二步", status="pending"),
        ]
        ledger.update_status(
            tx.tx_id, TransactionStatus.executing, steps=steps
        )
        retrieved = ledger.get(tx.tx_id)
        assert retrieved is not None
        assert len(retrieved.steps) == 2
        assert retrieved.steps[0].status == "success"


# ===========================================================================
# check_idempotency 测试
# ===========================================================================


class TestLedgerCheckIdempotency:
    """Ledger.check_idempotency 方法测试。"""

    def test_窗口内相同key命中返回已有交易(self, ledger: Ledger):
        """48小时内使用相同 idempotency_key 应命中并返回已有交易。"""
        key = "idem-key-001"
        tx = _make_tx(idempotency_key=key)
        ledger.record(tx)
        result = ledger.check_idempotency(key)
        assert result is not None
        assert result.tx_id == tx.tx_id

    def test_窗口外超过48小时未命中(self, ledger: Ledger):
        """超过 48 小时的旧交易，即使 key 相同也不应命中。"""
        key = "idem-key-002"
        # created_at 设置为 49 小时前
        old_time = datetime.now(timezone.utc) - timedelta(hours=49)
        tx = _make_tx(idempotency_key=key, created_at=old_time)
        ledger.record(tx)
        result = ledger.check_idempotency(key)
        # 超出 48 小时窗口，应返回 None
        assert result is None

    def test_不同key不互相干扰(self, ledger: Ledger):
        """不同 idempotency_key 的交易不应互相影响。"""
        tx1 = _make_tx(idempotency_key="key-A", payee="kimi")
        tx2 = _make_tx(idempotency_key="key-B", payee="qwen")
        ledger.record(tx1)
        ledger.record(tx2)
        assert ledger.check_idempotency("key-A") is not None
        assert ledger.check_idempotency("key-B") is not None
        assert ledger.check_idempotency("key-C") is None

    def test_无key的交易不影响幂等查询(self, ledger: Ledger):
        """没有 idempotency_key 的交易应被忽略，不影响有 key 的查询。"""
        tx_no_key = _make_tx()  # idempotency_key=None
        ledger.record(tx_no_key)
        # 查询一个从未出现过的 key，应返回 None
        assert ledger.check_idempotency("nonexistent-key") is None

    def test_窗口内恰好48小时的交易可命中(self, ledger: Ledger):
        """创建时间恰好在 48 小时内的交易，应能被幂等查询命中。"""
        key = "idem-key-boundary"
        # 47 小时 59 分钟前，仍在窗口内
        recent_time = datetime.now(timezone.utc) - timedelta(hours=47, minutes=59)
        tx = _make_tx(idempotency_key=key, created_at=recent_time)
        ledger.record(tx)
        result = ledger.check_idempotency(key)
        assert result is not None
        assert result.tx_id == tx.tx_id


# ===========================================================================
# get_daily_total 测试
# ===========================================================================


class TestLedgerGetDailyTotal:
    """Ledger.get_daily_total 方法测试。"""

    def test_无记录时返回0(self, ledger: Ledger):
        """数据库为空时，get_daily_total 应返回 0.0。"""
        assert ledger.get_daily_total() == 0.0

    def test_仅统计completed状态(self, ledger: Ledger):
        """只有 completed 状态的交易才应被计入日总额。"""
        # completed：应被统计
        tx_ok = _make_tx(amount=100.0, status=TransactionStatus.completed)
        # pending：不应被统计
        tx_pending = _make_tx(amount=200.0, status=TransactionStatus.pending)
        # failed：不应被统计
        tx_failed = _make_tx(amount=50.0, status=TransactionStatus.failed)
        ledger.record(tx_ok)
        ledger.record(tx_pending)
        ledger.record(tx_failed)
        total = ledger.get_daily_total()
        assert total == pytest.approx(100.0)

    def test_多笔completed交易求和(self, ledger: Ledger):
        """多笔 completed 交易的金额应正确累加。"""
        for amount in [10.0, 20.0, 30.0]:
            tx = _make_tx(amount=amount, status=TransactionStatus.completed)
            ledger.record(tx)
        total = ledger.get_daily_total()
        assert total == pytest.approx(60.0)

    def test_过去日期的交易不计入今日总额(self, ledger: Ledger):
        """昨天的 completed 交易不应计入今日日总额。"""
        from datetime import date

        yesterday = datetime.now(timezone.utc) - timedelta(days=1)
        tx_yesterday = _make_tx(
            amount=500.0,
            status=TransactionStatus.completed,
            created_at=yesterday,
        )
        ledger.record(tx_yesterday)
        # 今日无记录
        assert ledger.get_daily_total() == pytest.approx(0.0)
        # 昨天有记录
        total_yesterday = ledger.get_daily_total(yesterday.date())
        assert total_yesterday == pytest.approx(500.0)

    def test_指定目标日期统计(self, ledger: Ledger):
        """传入 target_date 时，应统计指定日期的 completed 总额。"""
        from datetime import date

        target = date(2025, 1, 15)
        target_dt = datetime(2025, 1, 15, 10, 0, 0, tzinfo=timezone.utc)
        tx = _make_tx(
            amount=888.0,
            status=TransactionStatus.completed,
            created_at=target_dt,
        )
        ledger.record(tx)
        assert ledger.get_daily_total(target) == pytest.approx(888.0)
        assert ledger.get_daily_total(date(2025, 1, 16)) == pytest.approx(0.0)


# ===========================================================================
# list_transactions 测试
# ===========================================================================


class TestLedgerListTransactions:
    """Ledger.list_transactions 方法测试。"""

    def _insert_n(self, ledger: Ledger, n: int, **kwargs) -> list[Transaction]:
        """批量插入 n 条交易记录，返回插入的 Transaction 列表。"""
        txs = [_make_tx(**kwargs) for _ in range(n)]
        for tx in txs:
            ledger.record(tx)
        return txs

    def test_无记录时返回空列表(self, ledger: Ledger):
        """数据库为空时，list_transactions 应返回空列表。"""
        result = ledger.list_transactions()
        assert result == []

    def test_limit参数限制返回数量(self, ledger: Ledger):
        """limit 参数应限制返回的最大记录数。"""
        self._insert_n(ledger, 5)
        result = ledger.list_transactions(limit=3)
        assert len(result) == 3

    def test_offset参数跳过记录(self, ledger: Ledger):
        """offset 参数应跳过前 N 条记录。"""
        self._insert_n(ledger, 5)
        result_all = ledger.list_transactions(limit=10)
        result_offset = ledger.list_transactions(limit=10, offset=2)
        assert len(result_all) == 5
        assert len(result_offset) == 3

    def test_分页结果不重叠(self, ledger: Ledger):
        """两次分页查询结果的 tx_id 不应重叠。"""
        self._insert_n(ledger, 6)
        page1 = ledger.list_transactions(limit=3, offset=0)
        page2 = ledger.list_transactions(limit=3, offset=3)
        ids_page1 = {tx.tx_id for tx in page1}
        ids_page2 = {tx.tx_id for tx in page2}
        assert ids_page1.isdisjoint(ids_page2)

    def test_按status过滤(self, ledger: Ledger):
        """传入 status 过滤参数时，结果应只包含该状态的交易。"""
        self._insert_n(ledger, 3, status=TransactionStatus.completed)
        self._insert_n(ledger, 2, status=TransactionStatus.failed)
        completed = ledger.list_transactions(status=TransactionStatus.completed)
        failed = ledger.list_transactions(status=TransactionStatus.failed)
        assert len(completed) == 3
        assert len(failed) == 2
        assert all(tx.status == TransactionStatus.completed for tx in completed)

    def test_按payee过滤(self, ledger: Ledger):
        """传入 payee 过滤参数时，结果应只包含该收款方的交易。"""
        self._insert_n(ledger, 2, payee="kimi")
        self._insert_n(ledger, 3, payee="qwen")
        kimi_txs = ledger.list_transactions(payee="kimi")
        qwen_txs = ledger.list_transactions(payee="qwen")
        assert len(kimi_txs) == 2
        assert len(qwen_txs) == 3
        assert all(tx.payee == "kimi" for tx in kimi_txs)

    def test_status和payee联合过滤(self, ledger: Ledger):
        """同时传入 status 和 payee 时，两个条件应取交集。"""
        # kimi + completed
        self._insert_n(ledger, 2, payee="kimi", status=TransactionStatus.completed)
        # kimi + failed
        self._insert_n(ledger, 1, payee="kimi", status=TransactionStatus.failed)
        # deepseek + completed
        self._insert_n(ledger, 3, payee="deepseek", status=TransactionStatus.completed)
        result = ledger.list_transactions(
            status=TransactionStatus.completed, payee="kimi"
        )
        assert len(result) == 2
        assert all(tx.payee == "kimi" for tx in result)
        assert all(tx.status == TransactionStatus.completed for tx in result)

    def test_结果按created_at降序排列(self, ledger: Ledger):
        """list_transactions 结果应按 created_at 降序排列（最新在前）。"""
        import time

        for i in range(3):
            ledger.record(_make_tx(amount=float(i + 1) * 10))
            time.sleep(0.01)  # 确保时间戳不同

        result = ledger.list_transactions(limit=10)
        # 验证相邻记录的时间有序（降序）
        for i in range(len(result) - 1):
            assert result[i].created_at >= result[i + 1].created_at


# ===========================================================================
# 连接管理测试
# ===========================================================================


class TestLedgerConnectionManagement:
    """Ledger 连接管理测试。"""

    def test_context_manager自动关闭连接(self, tmp_path: Path):
        """使用 with 语句时，退出后连接应自动关闭。"""
        db_file = tmp_path / "cm_test.db"
        with Ledger(db_file) as ledger:
            tx = _make_tx()
            ledger.record(tx)
        # 退出 with 后，连接已关闭（再次操作应抛出异常）
        import sqlite3

        with pytest.raises(Exception):
            ledger.get(tx.tx_id)

    def test_close后数据仍持久化(self, tmp_path: Path):
        """关闭连接后重新打开数据库，数据应仍然存在。"""
        db_file = tmp_path / "persist_test.db"
        tx = _make_tx(amount=999.0)
        with Ledger(db_file) as ledger:
            ledger.record(tx)
        # 重新打开数据库
        with Ledger(db_file) as ledger2:
            retrieved = ledger2.get(tx.tx_id)
            assert retrieved is not None
            assert retrieved.amount == 999.0
