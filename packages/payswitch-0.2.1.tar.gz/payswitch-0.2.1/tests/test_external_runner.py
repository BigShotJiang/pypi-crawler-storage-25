"""External-agent checkout runner tests."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from payswitch.engine.external_runner import ExternalAction, ExternalCheckoutRunner
from payswitch.models.config import PaySwitchConfig
from payswitch.models.types import DisplayMode, PaymentMethod, TransactionStatus


def _config(tmp_path: Path) -> PaySwitchConfig:
    return PaySwitchConfig(
        data_dir=tmp_path,
        display_mode=DisplayMode.headed,
        transaction_timeout=30,
    )


@pytest.mark.asyncio
async def test_external_runner_stops_on_qr_human_gate(tmp_path: Path) -> None:
    mock_browser = MagicMock()
    mock_browser.launch = AsyncMock()
    mock_browser.close = AsyncMock()
    mock_browser.page = MagicMock()

    qr_detection = MagicMock()
    qr_detection.action_type = "scan_qr"
    qr_detection.detector_name = "QRCodeDetector"
    qr_detection.description = "请扫码完成支付"
    qr_detection.data = {"qr_count": 1}

    qr_detector = MagicMock()
    qr_detector.name = "QRCodeDetector"
    qr_detector.requires_human.return_value = True

    mock_pipeline = MagicMock()
    mock_pipeline._detectors = [qr_detector]
    mock_pipeline.scan = AsyncMock(return_value=qr_detection)

    mock_display = MagicMock()
    mock_display.mode = DisplayMode.headed
    mock_display.get_display_info.return_value = {"mode": "headed"}
    mock_display.notify_human = AsyncMock()
    mock_display.wait_for_completion = AsyncMock()

    with (
        patch(
            "payswitch.engine.external_runner.BrowserController",
            return_value=mock_browser,
        ),
        patch(
            "payswitch.engine.external_runner.DetectorPipeline",
            return_value=mock_pipeline,
        ),
        patch(
            "payswitch.engine.external_runner.DisplayManager",
            return_value=mock_display,
        ),
    ):
        runner = ExternalCheckoutRunner(_config(tmp_path))
        try:
            tx = await runner.run(
                amount=0.9,
                payee="unknown_site",
                method=PaymentMethod.alipay_qr,
                actions=[ExternalAction(type="scan", description="检测支付状态")],
                stop_on_human=True,
            )
        finally:
            runner.close()

    assert tx.status == TransactionStatus.human_action_required
    assert tx.human_action is not None
    assert tx.human_action.action_type == "scan_qr"
    mock_display.notify_human.assert_awaited_once()
    mock_display.wait_for_completion.assert_not_called()
