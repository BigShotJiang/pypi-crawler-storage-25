# Pay-Switch v1 — 开发计划（PLAN）

> 基于 PRD.md 生成 | 2026-05-08
> 目标：实现 MVP 全部功能，通过 4 个验证场景

---

## 总体架构概览

```
payswitch CLI (Typer)
    │
    ├── engine/orchestrator.py    ← 支付流程编排（脚本/智能双模式）
    │   ├── engine/guard.py       ← 安全守卫（限额/白名单/去重）
    │   └── engine/ledger.py      ← 交易记录（SQLite）
    │
    ├── browser/controller.py     ← Playwright 控制器
    │   ├── browser/skyvern.py    ← Skyvern 智能模式
    │   ├── browser/profiles.py   ← Profile 管理
    │   ├── browser/display.py    ← 人类交互（弹窗/noVNC 自动适配）
    │   ├── browser/novnc.py      ← noVNC 会话管理
    │   ├── browser/detector.py   ← 支付环节检测
    │   └── browser/safety.py     ← 浏览器安全层
    │
    └── adapters/                 ← 站点脚本适配器
        ├── deepseek.py
        ├── kimi.py
        └── qwen.py
```

**依赖链**：
```
数据模型 → 配置系统 → SQLite/Ledger
                ↓
Playwright 控制器 → Profile 管理 → Display 层
                ↓
支付检测器 → 安全层 → 站点适配器 → 编排引擎 → 安全守卫
                ↓
CLI 命令层（setup → login → spend → confirm/status/history/config/platforms）
                ↓
Skyvern 集成 → 双模式回退链
                ↓
noVNC → Docker 部署
                ↓
集成测试
```

---

## 阶段一：项目基础 (Task 1-3)

### Task 1: 项目脚手架与包结构

**目标**：搭建 Python 包骨架，配置打包、CLI 入口点，确保 `pip install -e .` 和 `payswitch --help` 可用。

**产出文件**：
- `pyproject.toml`
- `payswitch/__init__.py`
- `payswitch/cli.py`（CLI 骨架，所有子命令占位）
- `payswitch/engine/__init__.py`
- `payswitch/browser/__init__.py`
- `payswitch/adapters/__init__.py`
- `payswitch/models/__init__.py`
- `.gitignore`（更新）

**AI 提示词**：

```
ultrathink

你是一位资深 Python 打包专家，精通 pyproject.toml、Typer CLI 框架、和现代 Python 项目结构。

请为 Pay-Switch 项目创建完整的项目脚手架。

## 要求

1. 创建 `pyproject.toml`：
   - 项目名 `payswitch`，版本 `0.1.0`
   - 使用 Typer 作为 CLI 框架
   - 配置 CLI 入口点：`payswitch = "payswitch.cli:app"`
   - 依赖项：typer[all], playwright, rich（终端美化输出）, pydantic（数据模型）
   - 可选依赖组 `smart`：skyvern
   - 可选依赖组 `remote`：websockify（noVNC）
   - Python >= 3.11

2. 创建 `payswitch/cli.py`：
   - 使用 Typer 定义主 app
   - 创建所有子命令占位（setup/login/spend/confirm/status/history/config/platforms）
   - 每个命令暂时只输出 "尚未实现" 提示
   - `--version` 回调
   - 顶级 `--json` 和 `--verbose` 全局选项
   - `--help` 文本要用中文，清晰描述每个命令的用途（这是 Agent 理解 Pay-Switch 的唯一入口）

3. 创建各模块的 `__init__.py`（空文件或简单 docstring）

4. 更新 `.gitignore`，添加：
   - profiles/（浏览器 Profile 数据）
   - *.db（SQLite 数据库）
   - .payswitch/（用户配置目录）

5. 确保执行以下命令后 CLI 可用：
   ```bash
   pip install -e ".[smart,remote]"
   payswitch --help
   ```

## 代码规范
- 所有代码注释使用中文
- 使用 Rich 库美化终端输出（颜色、表格、进度条）
- 类型注解完整（使用 Python 3.11+ 语法）
```

**验收条件**：
- [x] `pip install -e .` 成功
- [x] `payswitch --help` 输出中文帮助信息，列出所有子命令
- [x] `payswitch --version` 输出版本号
- [x] 项目目录结构与 PRD 6.2 一致

---

### Task 2: 数据模型与配置系统

**目标**：定义所有核心数据模型（Pydantic），实现配置文件的读写（存储在 `~/.payswitch/`）。

**产出文件**：
- `payswitch/models/transaction.py` — 交易记录模型
- `payswitch/models/config.py` — 配置模型
- `payswitch/models/profile.py` — Profile 元数据模型
- `payswitch/models/types.py` — 枚举和共用类型
- `payswitch/models/__init__.py` — 导出

**AI 提示词**：

```
ultrathink

你是一位资深 Python 数据建模专家，精通 Pydantic V2 和类型系统设计。

请为 Pay-Switch 创建所有核心数据模型。

## 数据模型清单

### 1. 枚举类型 (types.py)
- TransactionStatus: pending / executing / human_action_required / completed / failed / cancelled / timeout
- PaymentMethod: alipay_qr / bankcard / stripe / auto
- ExecutionMode: script / smart / human_takeover
- DisplayMode: headed / novnc

### 2. 配置模型 (config.py)
```python
class PaySwitchConfig(BaseModel):
    """Pay-Switch 全局配置，存储在 ~/.payswitch/config.json"""
    max_per_transaction: float = 500.0      # 单笔限额（元）
    daily_limit: float = 2000.0             # 日累计限额（元）
    whitelist: list[str] = []               # 商户白名单（空=不限制）
    auto_confirm_threshold: float = 0.0     # 自动确认阈值（0=关闭）
    default_currency: str = "CNY"
    llm_provider: str = "openai"            # Skyvern LLM 后端
    llm_api_key: str = ""                   # LLM API Key（加密存储）
    llm_model: str = "gpt-4o"              # LLM 模型名
    display_mode: DisplayMode | None = None # None=自动检测
    novnc_port: int = 6080                  # noVNC 端口
    transaction_timeout: int = 300          # 支付超时（秒）
    data_dir: Path                          # 数据目录（默认 ~/.payswitch/）
```

实现 `load()` / `save()` / `update()` 方法，配置文件路径 `~/.payswitch/config.json`。
首次运行时自动创建默认配置。

### 3. Profile 元数据 (profile.py)
```python
class PlatformProfile(BaseModel):
    """已登录平台的 Profile 元数据"""
    platform: str                           # 如 "deepseek"
    display_name: str                       # 如 "DeepSeek"
    profile_dir: Path                       # Playwright persistent context 路径
    logged_in_at: datetime | None
    last_used_at: datetime | None
    status: Literal["active", "expired", "unknown"]
    top_up_url: str | None                  # 充值页 URL
```

### 4. 交易记录 (transaction.py)
```python
class Transaction(BaseModel):
    """一次支付编排的完整记录"""
    tx_id: str                              # txn_xxx 格式
    amount: float
    currency: str = "CNY"
    payee: str                              # 商户标识
    reason: str = ""                        # 支付原因
    payment_method: PaymentMethod | None
    execution_mode: ExecutionMode | None
    status: TransactionStatus
    idempotency_key: str | None
    steps: list[StepRecord] = []            # 执行步骤记录
    human_action: HumanAction | None        # 人类介入记录
    created_at: datetime
    completed_at: datetime | None
    error: str | None

class StepRecord(BaseModel):
    """单个执行步骤的记录"""
    step_index: int
    description: str
    status: Literal["pending", "success", "failed", "skipped"]
    started_at: datetime | None
    completed_at: datetime | None
    screenshot_path: str | None

class HumanAction(BaseModel):
    """人类介入记录"""
    action_type: str                        # scan_qr / fill_form / confirm / takeover
    requested_at: datetime
    completed_at: datetime | None
    display_mode: DisplayMode | None
    novnc_url: str | None
```

## 要求
- 所有模型使用 Pydantic V2 (model_config)
- tx_id 使用 `txn_` + nanoid 格式自动生成
- 所有时间使用 UTC datetime
- 配置文件的 LLM API Key 字段加密存储（简单 base64 即可，MVP 阶段）
- 代码注释使用中文
```

**验收条件**：
- [x] 所有模型可正常实例化和序列化
- [x] 配置文件可正确读写到 `~/.payswitch/config.json`
- [x] 首次运行自动创建默认配置
- [x] tx_id 自动生成且唯一

---

### Task 3: SQLite 数据库与交易账本

**目标**：实现 SQLite 数据库初始化、交易记录的 CRUD 操作（append-only 写入）。

**产出文件**：
- `payswitch/engine/ledger.py` — 交易账本（SQLite 操作）
- `payswitch/engine/__init__.py`

**AI 提示词**：

```
ultrathink

你是一位资深 Python 数据库专家，精通 SQLite 和 Python 标准库 sqlite3。

请为 Pay-Switch 实现交易账本模块。

## 要求

1. 数据库文件路径：`~/.payswitch/payswitch.db`

2. 表结构：
   - `transactions` 表：存储 Transaction 模型的所有字段（JSON 序列化 steps 和 human_action）
   - `daily_totals` 视图：按日期汇总消费总额（用于日限额检查）

3. Ledger 类：
   ```python
   class Ledger:
       def __init__(self, db_path: Path):
           """初始化数据库连接，自动建表"""

       def record(self, tx: Transaction) -> None:
           """插入一条交易记录（append-only，不允许删除）"""

       def update_status(self, tx_id: str, status: TransactionStatus, **kwargs) -> None:
           """更新交易状态（只允许更新 status/completed_at/error/steps/human_action）"""

       def get(self, tx_id: str) -> Transaction | None:
           """按 tx_id 查询单条记录"""

       def check_idempotency(self, key: str) -> Transaction | None:
           """检查幂等 key 是否已存在（48小时内）"""

       def get_daily_total(self, date: date | None = None) -> float:
           """获取指定日期的消费总额（默认今天）"""

       def list_transactions(self, limit: int = 10, offset: int = 0,
                            status: TransactionStatus | None = None,
                            payee: str | None = None) -> list[Transaction]:
           """查询交易列表"""

       def export_csv(self, filepath: Path, **filters) -> int:
           """导出为 CSV"""
   ```

4. 关键实现细节：
   - 数据库自动初始化（首次运行自动建表）
   - 使用 WAL 模式（支持并发读写）
   - append-only：record() 只做 INSERT，不做 UPDATE/DELETE
   - update_status() 通过添加新的 status 字段值实现，保留历史
   - 线程安全（使用 `check_same_thread=False` + 连接池）
   - JSON 序列化复杂字段（steps、human_action）

5. 代码注释使用中文
```

**验收条件**：
- [x] 数据库自动创建和初始化
- [x] 交易记录可正常插入和查询
- [x] 幂等检查正确工作（48小时内）
- [x] 日累计查询准确
- [x] CSV 导出功能正常

---

### 🔶 验收检查点 1：项目基础

```
验收内容：
  ✅ payswitch --help 输出中文帮助，列出所有子命令
  ✅ 数据模型可正常创建和序列化
  ✅ 配置文件读写正常（~/.payswitch/config.json）
  ✅ SQLite 数据库自动初始化，交易记录 CRUD 正常
  ✅ pip install -e . 成功

验证命令：
  pip install -e ".[smart,remote]"
  payswitch --help
  python -c "from payswitch.models import Transaction, PaySwitchConfig; print('Models OK')"
  python -c "from payswitch.engine.ledger import Ledger; print('Ledger OK')"
```

---

## 阶段二：浏览器基础 (Task 4-6)

### Task 4: Playwright 浏览器控制器

**目标**：封装 Playwright 的核心操作（启动、导航、截图、关闭），提供统一的浏览器控制接口。

**产出文件**：
- `payswitch/browser/controller.py`

**AI 提示词**：

```
ultrathink

你是一位资深 Python 浏览器自动化专家，精通 Playwright 异步 API。

请为 Pay-Switch 实现 Playwright 浏览器控制器。

## 要求

1. BrowserController 类（异步）：
   ```python
   class BrowserController:
       """Playwright 浏览器控制器，提供统一的浏览器操作接口"""

       async def launch(self, profile_dir: Path | None = None,
                        headless: bool = False) -> None:
           """启动浏览器
           - profile_dir: 指定 persistent context 目录（复用登录状态）
           - headless: 是否无头模式（noVNC 场景下为 False + Xvfb）
           """

       async def navigate(self, url: str) -> None:
           """导航到指定 URL"""

       async def screenshot(self, path: Path | None = None) -> bytes:
           """截取当前页面截图，返回 PNG 字节"""

       async def get_page_content(self) -> str:
           """获取页面 HTML 内容"""

       async def click(self, selector: str) -> None:
           """点击元素"""

       async def fill(self, selector: str, value: str) -> None:
           """填写输入框"""

       async def wait_for_selector(self, selector: str,
                                    timeout: float = 30.0) -> bool:
           """等待元素出现"""

       async def execute_script(self, script: str) -> Any:
           """执行 JavaScript"""

       async def get_current_url(self) -> str:
           """获取当前 URL"""

       async def close(self) -> None:
           """关闭浏览器，保存 context"""

       @property
       def page(self) -> Page:
           """获取当前 Page 对象（供高级操作使用）"""
   ```

2. 关键实现细节：
   - 使用 `playwright.async_api` 异步 API
   - 支持 persistent context（复用登录状态）
   - launch() 自动安装 stealth 插件（`playwright-stealth`）
   - 错误处理：超时、页面崩溃、网络断开
   - 浏览器窗口大小默认 1280x800
   - User-Agent 设置为常见桌面浏览器
   - 上下文管理器支持 `async with BrowserController() as browser:`
   - 日志记录（使用 logging 模块）

3. 代码注释使用中文
```

**验收条件**：
- [x] 可正常启动/关闭浏览器
- [x] 支持 persistent context 复用
- [x] 截图功能正常
- [x] 导航和基本操作可用

---

### Task 5: 浏览器 Profile 管理

**目标**：管理多平台的登录状态（Playwright persistent context），支持创建、加载、检查过期。

**产出文件**：
- `payswitch/browser/profiles.py`

**AI 提示词**：

```
ultrathink

你是一位资深 Python 开发专家，精通 Playwright persistent context 和用户数据管理。

请为 Pay-Switch 实现浏览器 Profile 管理模块。

## 要求

1. ProfileManager 类：
   ```python
   class ProfileManager:
       """管理多平台的浏览器 Profile（登录状态）"""

       def __init__(self, data_dir: Path):
           """data_dir: ~/.payswitch/profiles/"""

       def get_profile(self, platform: str) -> PlatformProfile | None:
           """获取指定平台的 Profile 元数据"""

       def list_profiles(self) -> list[PlatformProfile]:
           """列出所有已保存的 Profile"""

       def create_profile(self, platform: str,
                          display_name: str,
                          top_up_url: str | None = None) -> PlatformProfile:
           """创建新的 Profile 目录和元数据"""

       def get_profile_dir(self, platform: str) -> Path:
           """获取 Profile 的 Playwright persistent context 目录"""

       def update_login_time(self, platform: str) -> None:
           """更新登录时间"""

       def check_session(self, platform: str) -> Literal["active", "expired", "unknown"]:
           """检查登录状态是否可能已过期
           简单策略：超过 7 天未使用则标记为 expired
           """

       def delete_profile(self, platform: str) -> None:
           """删除 Profile（退出登录）"""
   ```

2. Profile 元数据存储在 `~/.payswitch/profiles/{platform}/metadata.json`
3. Playwright context 数据存储在 `~/.payswitch/profiles/{platform}/browser_data/`
4. 代码注释使用中文
```

**验收条件**：
- [x] Profile 可正常创建、加载、删除
- [x] 元数据正确持久化
- [x] Session 过期检查逻辑正确

---

### Task 6: 人类交互层 — 本地弹窗模式

**目标**：实现环境检测（有桌面 vs 无桌面）和本地桌面弹窗交互逻辑。

**产出文件**：
- `payswitch/browser/display.py`

**AI 提示词**：

```
ultrathink

你是一位资深 Python 开发专家，精通跨平台桌面交互和 Playwright headed 模式。

请为 Pay-Switch 实现人类交互层（Display 模块）。

## 要求

1. 环境检测函数：
   ```python
   def detect_display_mode() -> DisplayMode:
       """自动检测部署环境，选择人类交互方式
       - Windows → headed
       - macOS → headed
       - Linux + DISPLAY 环境变量 → headed
       - 其他 → novnc
       """
   ```

2. DisplayManager 类：
   ```python
   class DisplayManager:
       """管理人类交互方式（弹窗 / noVNC）"""

       def __init__(self, mode: DisplayMode | None = None):
           """mode=None 时自动检测"""

       async def notify_human(self, message: str,
                              action_type: str,
                              details: dict | None = None) -> None:
           """通知人类需要介入
           - headed 模式：在终端输出提示（浏览器窗口已经可见）
           - novnc 模式：输出 noVNC URL + 终端提示
           """

       async def wait_for_completion(self,
                                      detector_callback: Callable,
                                      timeout: int = 300) -> bool:
           """等待人类操作完成
           - 轮询 detector_callback 检测页面变化
           - 超时返回 False
           - 使用 Rich 显示等待动画和倒计时
           """

       def get_display_info(self) -> dict:
           """返回当前显示信息
           headed: {"mode": "headed"}
           novnc: {"mode": "novnc", "url": "http://..."}
           """
   ```

3. 终端输出使用 Rich 库美化：
   - 彩色提示信息
   - 等待时的 spinner 动画
   - 倒计时显示

4. 代码注释使用中文
```

**验收条件**：
- [x] Windows/macOS 正确检测为 headed 模式
- [x] 无桌面环境检测为 novnc 模式
- [x] 终端输出美观（Rich 格式化）
- [x] 等待超时逻辑正确

---

### 🔶 验收检查点 2：浏览器基础

```
验收内容：
  ✅ Playwright 可正常启动 headed 浏览器
  ✅ Profile 可创建、加载（persistent context）
  ✅ 环境检测正确（headed / novnc）
  ✅ 人类通知和等待机制可用

验证方式：
  python -c "
  import asyncio
  from payswitch.browser.controller import BrowserController
  async def test():
      async with BrowserController() as browser:
          await browser.launch(headless=False)
          await browser.navigate('https://www.baidu.com')
          print('Browser OK')
          await asyncio.sleep(3)
  asyncio.run(test())
  "
```

---

## 阶段三：支付检测与安全 (Task 7-8)

### Task 7: 支付环节检测器

**目标**：实现四种支付环节检测器（QR码/敏感表单/确认按钮/支付完成），可插拔架构。

**产出文件**：
- `payswitch/browser/detector.py`

**AI 提示词**：

```
ultrathink

你是一位资深 Python 开发专家，精通网页内容分析和 Playwright 页面检测。

请为 Pay-Switch 实现支付环节检测器模块。

## 要求

1. 检测器基类：
   ```python
   class PaymentDetector(ABC):
       """支付环节检测器基类"""
       name: str

       @abstractmethod
       async def detect(self, page: Page) -> DetectionResult | None:
           """检测当前页面是否匹配此检测器"""

       @abstractmethod
       def requires_human(self) -> bool:
           """是否需要人类介入"""

       @abstractmethod
       async def detect_completion(self, page: Page) -> bool:
           """检测操作是否完成（人类完成操作后）"""

   class DetectionResult(BaseModel):
       """检测结果"""
       detector_name: str
       action_type: str            # scan_qr / fill_form / confirm / completed
       description: str            # 中文描述
       data: dict = {}             # 附加数据（QR URL、截图路径等）
   ```

2. 四个具体检测器：

   **QRCodeDetector**:
   - 检测页面中的 QR 码（img 标签、canvas、特定 class/id）
   - 支持支付宝 QR 码特征（qr.alipay.com 域名、特定容器 class）
   - 支持微信支付 QR 码特征
   - detect_completion: 检测 QR 码消失或页面跳转到成功页

   **SensitiveFormDetector**:
   - 检测密码输入框（type="password"）
   - 检测银行卡号输入框（name/id 包含 card、cvv、expiry 等）
   - 检测支付密码输入框
   - detect_completion: 检测表单提交或页面跳转

   **PaymentConfirmDetector**:
   - 检测"确认支付"、"立即支付"、"确认订单"等按钮
   - 支持中英文匹配
   - detect_completion: 按钮消失或页面跳转

   **CompletionDetector**:
   - 检测"支付成功"、"充值成功"、"交易完成"等文本
   - 检测成功图标/动画
   - 这个检测器 requires_human() 返回 False

3. DetectorPipeline 类：
   ```python
   class DetectorPipeline:
       """按优先级依次运行检测器"""
       def __init__(self, detectors: list[PaymentDetector] | None = None):
           """默认加载所有内置检测器"""

       async def scan(self, page: Page) -> DetectionResult | None:
           """依次运行检测器，返回第一个匹配的结果"""

       async def wait_for_completion(self, page: Page,
                                      result: DetectionResult,
                                      timeout: int = 300) -> bool:
           """等待对应检测器报告完成"""
   ```

4. 检测策略：
   - 优先检测 CompletionDetector（已经成功了就不用暂停）
   - 然后是 QRCodeDetector（最常见的暂停场景）
   - 然后是 SensitiveFormDetector
   - 最后是 PaymentConfirmDetector
   - 使用 page.evaluate() 执行 JS 进行 DOM 检测
   - 结合截图分析作为补充（为 Skyvern 预留）

5. 代码注释使用中文
```

**验收条件**：
- [x] QR 码检测器能识别支付宝/微信 QR 码
- [x] 敏感表单检测器能识别密码/卡号字段
- [x] 完成检测器能识别"支付成功"文本
- [x] 检测器管道按优先级正确运行
- [x] 可插拔——新增检测器只需实现基类

---

### Task 8: 浏览器安全层

**目标**：实现浏览器安全检查（敏感页暂停、域名白名单、Agent 不碰密码框）。

**产出文件**：
- `payswitch/browser/safety.py`

**AI 提示词**：

```
你是一位资深 Python 安全工程师，精通浏览器安全策略。

请为 Pay-Switch 实现浏览器安全层。

## 要求

1. BrowserSafety 类：
   ```python
   class BrowserSafety:
       """浏览器安全层，保护敏感操作"""

       def __init__(self, domain_whitelist: list[str] | None = None):
           """domain_whitelist: 允许访问的域名列表（None=不限制）"""

       async def check_navigation(self, url: str) -> SafetyCheckResult:
           """检查即将访问的 URL 是否安全
           - 域名白名单检查
           - 已知钓鱼域名检查（简单黑名单）
           """

       async def check_page_safety(self, page: Page) -> SafetyCheckResult:
           """检查当前页面是否包含敏感元素
           - 密码/CVV 输入框 → 标记需要人类操作
           - 银行页面 → 标记需要人类操作
           """

       def is_sensitive_field(self, field_type: str, field_name: str) -> bool:
           """判断表单字段是否为敏感字段"""

   class SafetyCheckResult(BaseModel):
       safe: bool
       reason: str | None = None
       requires_human: bool = False
   ```

2. 敏感字段列表：password, cvv, cvc, card_number, card-number, expiry, 支付密码, 银行卡号
3. 敏感域名模式：*bank*, *pay*, *checkout*（仅作为提示，不阻断）
4. 代码注释使用中文
```

**验收条件**：
- [x] 域名白名单正确拦截
- [x] 敏感字段正确识别
- [x] 安全检查结果包含清晰的中文原因

---

### 🔶 验收检查点 3：支付检测与安全

```
验收内容：
  ✅ 四种检测器可正确识别对应的支付环节
  ✅ 检测管道按优先级运行
  ✅ 安全层正确识别敏感字段和域名
  ✅ 检测器架构可插拔

验证方式：手动测试 + 单元测试
```

---

## 阶段四：支付编排引擎 (Task 9-12)

### Task 9: 站点适配器基类与注册机制

**目标**：实现站点适配器基类、适配器注册表，为具体站点（DeepSeek/Kimi/Qwen）提供统一接口。

**产出文件**：
- `payswitch/adapters/base.py`
- `payswitch/adapters/__init__.py`（注册表）

**AI 提示词**：

```
你是一位资深 Python 架构师，精通插件模式和注册表设计。

请为 Pay-Switch 实现站点适配器的基类和注册机制。

## 要求

1. SiteAdapter 基类：
   ```python
   class SiteAdapter(ABC):
       """站点脚本适配器基类"""
       name: str                    # 如 "deepseek"
       display_name: str            # 如 "DeepSeek"
       top_up_url: str              # 充值页 URL
       supported_methods: list[PaymentMethod]  # 支持的支付方式

       @abstractmethod
       async def execute_topup(self, page: Page,
                                amount: float,
                                method: PaymentMethod) -> list[ScriptStep]:
           """执行充值脚本，返回执行的步骤列表
           在触发支付检测器时自动暂停
           """

       async def validate_amount(self, amount: float) -> bool:
           """验证金额是否在平台支持范围内"""

       def get_login_url(self) -> str:
           """获取平台登录页 URL"""

   class ScriptStep(BaseModel):
       description: str
       action: str          # navigate / click / fill / wait / detect_payment
       selector: str | None = None
       value: str | None = None
   ```

2. AdapterRegistry 注册表：
   ```python
   class AdapterRegistry:
       """站点适配器注册表"""
       _adapters: dict[str, type[SiteAdapter]] = {}

       @classmethod
       def register(cls, adapter_class: type[SiteAdapter]) -> type[SiteAdapter]:
           """装饰器：注册适配器"""

       @classmethod
       def get(cls, platform: str) -> SiteAdapter | None:
           """获取指定平台的适配器实例"""

       @classmethod
       def list_platforms(cls) -> list[dict]:
           """列出所有已注册的平台信息"""

       @classmethod
       def has(cls, platform: str) -> bool:
           """是否有指定平台的适配器"""
   ```

3. 使用装饰器注册：`@AdapterRegistry.register`
4. 代码注释使用中文
```

**验收条件**：
- [x] 基类定义清晰，子类只需实现 execute_topup
- [x] 注册表可正确注册和查询适配器
- [x] list_platforms() 返回完整的平台信息

---

### Task 10: DeepSeek 站点适配器

**目标**：实现 DeepSeek 充值的完整脚本适配器（第一个具体适配器，验证架构）。

**产出文件**：
- `payswitch/adapters/deepseek.py`

**AI 提示词**：

```
ultrathink
use context7

你是一位资深 Python 浏览器自动化专家，精通 Playwright 和网页操作脚本编写。

请为 Pay-Switch 实现 DeepSeek 充值的站点适配器。

## 要求

1. 继承 SiteAdapter 基类
2. DeepSeek 充值流程（以 platform.deepseek.com 为例）：
   - 导航到充值页
   - 选择套餐金额（或自定义金额）
   - 选择支付方式（支付宝）
   - 点击"确认充值"
   - 等待 QR 码出现 → 由检测器暂停

3. 实现细节：
   - 使用 CSS 选择器操作页面元素
   - 每个步骤都记录 ScriptStep
   - 每个步骤前检查页面加载状态
   - 选择器找不到时抛出明确异常（触发 Skyvern 回退）
   - 支持"最接近金额"匹配（如用户要 200，选 ¥200 套餐）
   - 添加适当的 wait（页面加载、动画完成）

4. 注意：
   - 这个脚本可能因为 DeepSeek 网站改版而失效
   - 这没关系——Skyvern 智能模式会作为回退
   - 脚本的价值是：对于稳定的网站，比 Skyvern 更快更便宜
   - 选择器可能需要后续调整

5. 代码注释使用中文
6. 使用 @AdapterRegistry.register 装饰器注册
```

**验收条件**：
- [x] 适配器正确注册到 AdapterRegistry
- [x] execute_topup 返回完整的步骤列表
- [x] 选择器异常时抛出可捕获的异常

---

### Task 11: 安全守卫

**目标**：实现支付前的安全检查（限额、白名单、幂等去重）。

**产出文件**：
- `payswitch/engine/guard.py`

**AI 提示词**：

```
你是一位资深 Python 后端开发专家，精通支付安全和风控逻辑。

请为 Pay-Switch 实现安全守卫模块。

## 要求

1. SpendingGuard 类：
   ```python
   class SpendingGuard:
       """支付安全守卫，每次 spend 前检查"""

       def __init__(self, config: PaySwitchConfig, ledger: Ledger):
           pass

       def check(self, amount: float, payee: str,
                 idempotency_key: str | None = None) -> GuardResult:
           """执行所有安全检查，返回结果"""

       def _check_per_transaction_limit(self, amount: float) -> str | None:
           """单笔限额检查，返回拒绝原因或 None"""

       def _check_daily_limit(self, amount: float) -> str | None:
           """日累计限额检查"""

       def _check_whitelist(self, payee: str) -> str | None:
           """商户白名单检查（白名单为空=不限制）"""

       def _check_idempotency(self, key: str | None) -> Transaction | None:
           """幂等去重检查，返回已存在的交易或 None"""

   class GuardResult(BaseModel):
       allowed: bool
       reason: str | None = None       # 拒绝原因（中文）
       existing_tx: Transaction | None = None  # 幂等命中时返回
   ```

2. 检查顺序：幂等 → 单笔限额 → 日限额 → 白名单
3. 所有拒绝原因使用中文
4. 代码注释使用中文
```

**验收条件**：
- [x] 单笔限额正确拦截
- [x] 日累计限额正确拦截
- [x] 白名单正确工作（空白名单=不限制）
- [x] 幂等去重正确命中
- [x] 拒绝原因为清晰的中文

---

### Task 12: 支付流程编排引擎

**目标**：实现核心编排逻辑——接收 spend 请求后，调度浏览器、适配器、检测器、安全守卫，走完整个支付流程。

**产出文件**：
- `payswitch/engine/orchestrator.py`

**AI 提示词**：

```
ultrathink

你是一位资深 Python 架构师，精通异步编排和状态机设计。

请为 Pay-Switch 实现支付流程编排引擎。这是整个系统的核心。

## 要求

1. PaymentOrchestrator 类：
   ```python
   class PaymentOrchestrator:
       """支付流程编排引擎——Pay-Switch 的大脑"""

       def __init__(self, config: PaySwitchConfig,
                    ledger: Ledger,
                    guard: SpendingGuard,
                    profile_manager: ProfileManager,
                    display: DisplayManager):
           pass

       async def spend(self, amount: float, payee: str,
                       reason: str = "",
                       method: PaymentMethod = PaymentMethod.auto,
                       idempotency_key: str | None = None,
                       url: str | None = None,
                       dry_run: bool = False) -> Transaction:
           """执行一次完整的支付编排流程

           流程：
           1. 安全检查（guard.check）
           2. 创建交易记录
           3. 加载 Profile
           4. 启动浏览器
           5. 执行支付脚本（脚本模式 or 智能模式）
           6. 检测支付环节 → 暂停让人类介入
           7. 等待人类完成 → 检测支付成功
           8. 更新交易记录
           9. 关闭浏览器
           """

       async def _execute_script_mode(self, adapter: SiteAdapter,
                                       browser: BrowserController,
                                       tx: Transaction,
                                       amount: float,
                                       method: PaymentMethod) -> None:
           """脚本模式执行"""

       async def _execute_smart_mode(self, browser: BrowserController,
                                      tx: Transaction,
                                      amount: float,
                                      payee: str,
                                      url: str) -> None:
           """智能模式执行（Skyvern）—— 在 Task 17 中实现，这里先留接口"""

       async def _handle_human_interaction(self,
                                            browser: BrowserController,
                                            detection: DetectionResult,
                                            tx: Transaction) -> bool:
           """处理人类介入流程"""

       async def confirm(self, tx_id: str) -> Transaction:
           """人类手动确认支付完成"""

       async def get_status(self, tx_id: str) -> Transaction:
           """查询交易状态"""
   ```

2. 执行流程详细设计：
   ```
   spend() 入口
     │
     ├─ guard.check() → 不通过 → 返回拒绝
     │
     ├─ dry_run? → 返回模拟结果
     │
     ├─ ledger.record(tx) → 创建交易记录
     │
     ├─ 查找适配器：AdapterRegistry.get(payee)
     │   ├─ 找到 → 脚本模式
     │   └─ 没找到 → 检查 url 参数 → 智能模式（或报错）
     │
     ├─ profile_manager.get_profile(payee)
     │   └─ 没有 → 返回错误"请先 payswitch login {payee}"
     │
     ├─ browser.launch(profile_dir=...)
     │
     ├─ 执行支付脚本（脚本模式 or 智能模式）
     │   └─ 每个步骤后运行 detector_pipeline.scan()
     │       └─ 检测到支付环节 → _handle_human_interaction()
     │
     ├─ _handle_human_interaction()
     │   ├─ display.notify_human(...)
     │   └─ display.wait_for_completion(detector_callback, timeout)
     │       ├─ 完成 → 继续
     │       └─ 超时 → 标记 timeout
     │
     ├─ ledger.update_status(tx_id, completed/failed/timeout)
     │
     └─ browser.close()
   ```

3. 脚本模式失败时的回退：
   - 捕获 adapter.execute_topup() 的异常
   - 记录错误日志
   - 如果 Skyvern 可用 → 自动切换智能模式
   - 如果 Skyvern 不可用 → 通知人类接管

4. 状态更新要实时写入 SQLite（每个步骤完成后都更新）

5. 代码注释使用中文
```

**验收条件**：
- [x] spend() 流程完整可执行
- [x] 安全检查正确拦截不合规请求
- [x] 脚本模式可正常调用适配器
- [x] 人类介入流程可正常暂停和恢复
- [x] 交易记录实时更新
- [x] dry_run 模式不触发真实操作

---

### 🔶 验收检查点 4：支付编排引擎

```
验收内容：
  ✅ 安全守卫正确拦截超限/重复/非白名单请求
  ✅ DeepSeek 适配器注册成功
  ✅ 编排引擎可执行完整的脚本模式支付流程
  ✅ 人类介入（暂停 → 通知 → 等待 → 恢复）流程完整
  ✅ 交易记录正确写入 SQLite

验证方式：
  payswitch spend 200 deepseek --dry-run（模拟执行）
```

---

## 阶段五：CLI 命令层 (Task 13-16)

### Task 13: CLI — setup 命令

**目标**：实现首次运行引导（下载 Playwright 浏览器 + 配置 Skyvern LLM + 检测环境）。

**产出文件**：
- 更新 `payswitch/cli.py`（setup 命令实现）

**AI 提示词**：

```
你是一位资深 CLI 开发专家，精通 Typer 和 Rich 终端 UI。

请为 Pay-Switch 实现 `payswitch setup` 命令。

## 要求

1. 三步引导流程（参考 PRD 4.2 的设计）：
   - 步骤 1：下载 Playwright Chromium 浏览器（调用 playwright install chromium）
   - 步骤 2：配置 Skyvern LLM 后端（选择 provider + 输入 API Key）
   - 步骤 3：检测运行环境（headed / novnc）

2. 使用 Rich 美化输出：
   - 步骤进度条
   - 彩色提示（✅ ⚠️ ❌）
   - 选择列表（交互式）

3. 跳过已完成的步骤（重复运行不报错）
4. 保存配置到 PaySwitchConfig
5. 代码注释使用中文
```

**验收条件**：
- [x] 首次运行完成三步配置
- [x] 重复运行跳过已完成步骤
- [x] 配置正确保存

---

### Task 14: CLI — login 命令

**目标**：实现平台登录管理（弹浏览器让人登录 + 保存 Profile）。

**产出文件**：
- 更新 `payswitch/cli.py`（login 命令实现）

**AI 提示词**：

```
ultrathink

你是一位资深 CLI 开发专家，精通 Typer、Playwright 和异步编程。

请为 Pay-Switch 实现 `payswitch login` 命令。

## 要求

1. 三种用法（参考 PRD 4.2）：
   ```
   payswitch login <platform>       # 登录指定平台
   payswitch login --list            # 列出所有已登录平台及状态
   payswitch login <platform> --logout  # 退出指定平台登录
   ```

2. 登录流程：
   - 查找平台适配器 → 获取登录 URL
   - 没有适配器 → 提示用户输入登录 URL
   - 创建 Profile → 启动 headed 浏览器 → 打开登录页
   - 在终端提示用户手动登录
   - 等待用户确认（按回车键 or 检测到特定页面变化）
   - 保存 Profile 元数据

3. 远程环境（noVNC 模式）：
   - 启动 noVNC → 输出 URL → 用户远程操作
   - （noVNC 集成在 Task 21，这里先用 headed 模式）

4. --list 输出格式：表格，显示平台名、状态、最后登录时间
5. 使用 Rich 美化输出
6. 使用 asyncio.run() 包装异步操作
7. 代码注释使用中文
```

**验收条件**：
- [x] 可弹出浏览器让用户登录
- [x] 登录状态正确保存到 Profile
- [x] --list 正确显示所有平台状态
- [x] --logout 正确删除 Profile

---

### Task 15: CLI — spend 命令（核心）

**目标**：实现最核心的 `payswitch spend` 命令——调用编排引擎，实时显示执行进度。

**产出文件**：
- 更新 `payswitch/cli.py`（spend 命令实现）

**AI 提示词**：

```
ultrathink

你是一位资深 CLI 开发专家，精通 Typer、Rich 终端 UI 和异步编程。

请为 Pay-Switch 实现 `payswitch spend` 命令。这是整个产品最核心的命令。

## 要求

1. 命令签名（参考 PRD 4.2）：
   ```
   payswitch spend <amount> <payee> [OPTIONS]

   OPTIONS:
     --reason TEXT        支付原因
     --method TEXT        支付方式（alipay/bankcard/auto）
     --budget FLOAT       本次预算上限
     --auto-confirm       小额自动确认
     --dry-run            模拟执行
     --url TEXT           未知网站入口 URL（无适配器时必填）
     --json               JSON 格式输出
     --verbose            详细日志输出
   ```

2. 执行流程和终端输出（参考 PRD 4.2 的 spend 设计）：
   - 显示支付计划摘要（商户、金额、方式、步骤）
   - 实时显示每个步骤的执行状态（✅ / ⏸️ / ❌）
   - 到达人类介入步骤时显示等待提示和倒计时
   - 完成后显示交易结果

3. --json 模式：
   - 抑制所有 Rich 美化输出
   - 只输出 JSON 格式的交易结果
   - 供 Agent 程序化解析

4. --dry-run 模式：
   - 完成安全检查
   - 显示将要执行的步骤
   - 不启动浏览器，不执行真实操作

5. 错误处理：
   - 未登录 → 提示 "请先运行 payswitch login {payee}"
   - 被安全守卫拒绝 → 显示拒绝原因
   - 超时 → 显示超时信息
   - 脚本失败 → 显示回退信息

6. 使用 asyncio.run() 包装异步操作
7. 代码注释使用中文
```

**验收条件**：
- [x] 基本流程可正常执行（不含 Skyvern 回退）
- [x] 终端输出美观，步骤进度实时更新
- [x] --json 模式输出结构化 JSON
- [x] --dry-run 模式不产生真实操作
- [x] 错误信息清晰友好

---

### Task 16: CLI — 辅助命令集

**目标**：实现 confirm / status / history / config / platforms 五个辅助命令。

**产出文件**：
- 更新 `payswitch/cli.py`（五个辅助命令实现）

**AI 提示词**：

```
你是一位资深 CLI 开发专家，精通 Typer 和 Rich 终端 UI。

请为 Pay-Switch 实现五个辅助 CLI 命令。

## 要求（参考 PRD 4.2 的各命令设计）

1. `payswitch confirm <tx_id>`：
   - 查询交易状态
   - 显示待确认信息
   - 交互式确认（Y/N/O）
   - 更新交易状态

2. `payswitch status <tx_id>`：
   - 查询并显示交易详情
   - --json 模式

3. `payswitch history`：
   - 显示最近 N 笔交易（默认 10）
   - 支持 --limit, --status, --payee 过滤
   - --json 和 --csv 输出格式
   - 表格展示（Rich Table）

4. `payswitch config`：
   - 无参数：显示当前配置
   - --set KEY VALUE：设置配置项
   - --add-whitelist PLATFORM：添加白名单
   - --remove-whitelist PLATFORM：移除白名单
   - --reset：恢复默认配置

5. `payswitch platforms`：
   - 列出所有已注册的站点适配器
   - 显示：平台名、描述、支持的支付方式
   - 提示用户使用 payswitch login

6. 所有命令支持 --json 全局选项
7. 使用 Rich 美化输出
8. 代码注释使用中文
```

**验收条件**：
- [x] 所有五个命令可正常运行
- [x] --json 模式输出结构化数据
- [x] config 修改正确持久化
- [x] history 表格美观

---

### 🔶 验收检查点 5：CLI 命令层

```
验收内容：
  ✅ payswitch setup 完成首次配置
  ✅ payswitch login deepseek 弹出浏览器
  ✅ payswitch spend 200 deepseek --dry-run 显示模拟执行结果
  ✅ payswitch spend 200 deepseek 实际执行（脚本模式 + 本地弹窗）
  ✅ payswitch history 显示交易记录
  ✅ payswitch config 正确管理配置
  ✅ payswitch platforms 列出可用平台
  ✅ 所有命令支持 --json 输出

验证方式：
  完整跑通 PRD 7.3 场景一（本地桌面 + 脚本模式）
```

---

## 阶段六：Skyvern 智能模式 (Task 17-18)

### Task 17: Skyvern 集成层

**目标**：集成 Skyvern Python SDK，封装为 Pay-Switch 可用的智能执行引擎。

**产出文件**：
- `payswitch/browser/skyvern.py`

**AI 提示词**：

```
ultrathink
use context7

你是一位资深 Python AI 应用开发专家，精通 Skyvern SDK 和 LLM 视觉模型集成。

请为 Pay-Switch 实现 Skyvern 智能执行引擎集成。

## 背景
Skyvern 是一个 LLM 视觉驱动的浏览器自动化框架。它通过截图让 AI "看" 网页，用自然语言理解页面元素并操作，不依赖 CSS 选择器。

## 要求

1. SkyvernEngine 类：
   ```python
   class SkyvernEngine:
       """Skyvern 智能执行引擎，使用 LLM 视觉理解网页"""

       def __init__(self, config: PaySwitchConfig):
           """初始化 Skyvern，配置 LLM 后端"""

       def is_available(self) -> bool:
           """检查 Skyvern 是否已安装和配置"""

       async def execute_task(self, page: Page,
                              task_description: str,
                              url: str | None = None) -> list[StepRecord]:
           """使用 Skyvern 执行自然语言描述的任务

           例如：
           task_description="打开充值页，选择 200 元套餐，选择支付宝支付"

           返回执行的步骤列表
           在检测到支付环节时自动暂停（由 DetectorPipeline 处理）
           """

       async def navigate_and_act(self, page: Page,
                                  prompt: str) -> bool:
           """执行单个 Skyvern 动作
           等价于 page.act(prompt=...)
           """
   ```

2. 关键实现：
   - 使用 Skyvern 的 Python SDK（如果可用）
   - 如果 Skyvern SDK 不可用，回退到直接调用 LLM API（GPT-4o/Claude 视觉模型）
   - 将支付任务拆分为多个步骤，每步截图 → LLM 分析 → 执行动作
   - 每个步骤后运行 DetectorPipeline 检查是否到达支付环节
   - LLM 调用使用配置中的 provider/api_key/model

3. 降级策略：
   - Skyvern 未安装 → 使用简化版（直接 LLM API + Playwright）
   - LLM 调用失败 → 记录错误，返回失败（触发人类接管）
   - 3 次 LLM 调用未能完成任务 → 放弃，触发人类接管

4. 代码注释使用中文
```

**验收条件**：
- [x] Skyvern 引擎可正常初始化
- [x] is_available() 正确检测 Skyvern 状态
- [x] execute_task() 可执行自然语言任务
- [x] 降级策略正确工作

---

### Task 18: 双模式回退链

**目标**：在编排引擎中实现完整的双模式回退链：脚本模式 → Skyvern → 人类接管。

**产出文件**：
- 更新 `payswitch/engine/orchestrator.py`（完善 _execute_smart_mode 和回退逻辑）

**AI 提示词**：

```
ultrathink

你是一位资深 Python 架构师，精通错误处理和降级策略。

请在 Pay-Switch 的编排引擎中实现完整的双模式回退链。

## 要求

1. 在 orchestrator.py 的 spend() 方法中实现：
   ```
   脚本模式 → 失败 → Skyvern 智能模式 → 失败 → 人类接管
   ```

2. 具体逻辑：
   ```python
   async def spend(...):
       # ... 安全检查、创建交易 ...

       # 确定执行模式
       adapter = AdapterRegistry.get(payee)
       skyvern = SkyvernEngine(self.config)

       if adapter:
           try:
               # 尝试脚本模式
               await self._execute_script_mode(adapter, browser, tx, amount, method)
           except ScriptExecutionError as e:
               # 脚本失败，尝试智能模式
               logger.warning(f"脚本模式失败: {e}，切换到智能模式")
               tx.execution_mode = ExecutionMode.smart
               if skyvern.is_available():
                   try:
                       await self._execute_smart_mode(browser, tx, amount, payee, adapter.top_up_url)
                   except SmartModeError:
                       # 智能模式也失败，人类接管
                       await self._human_takeover(browser, tx)
               else:
                   await self._human_takeover(browser, tx)
       elif url:
           # 无适配器，直接智能模式
           if skyvern.is_available():
               await self._execute_smart_mode(browser, tx, amount, payee, url)
           else:
               await self._human_takeover(browser, tx)
       else:
           raise PaySwitchError(f"平台 '{payee}' 没有适配器且未提供 --url 参数")
   ```

3. _human_takeover() 方法：
   - 通知人类："自动化执行失败，请手动完成操作"
   - 保持浏览器打开
   - 等待人类操作完成（通过检测器检测支付成功页面）
   - 或等待人类通过 CLI 确认

4. 回退过程中的 CLI 输出：
   ```
   ⚠️ 脚本模式执行失败（选择器未找到），正在切换到智能模式...
   🤖 Skyvern 正在分析页面...
   ✅ Skyvern 已接管，继续执行
   ---
   或者：
   ⚠️ 脚本模式执行失败
   ⚠️ Skyvern 智能模式也执行失败
   🙋 请在浏览器窗口中手动完成支付操作
   ```

5. 代码注释使用中文
```

**验收条件**：
- [x] 脚本模式成功时不触发回退
- [x] 脚本失败时自动切换 Skyvern
- [x] Skyvern 失败时切换人类接管
- [x] 无适配器 + 有 URL 时直接用 Skyvern
- [x] CLI 输出清晰反映当前模式

---

### 🔶 验收检查点 6：Skyvern 智能模式

```
验收内容：
  ✅ Skyvern 引擎可正常执行 LLM 视觉任务
  ✅ 双模式回退链完整：脚本 → Skyvern → 人类
  ✅ 跑通 PRD 7.3 场景二（脚本回退 Skyvern）
  ✅ 跑通 PRD 7.3 场景四（未知网站 + Skyvern）

验证方式：
  payswitch spend 200 deepseek（正常脚本模式）
  payswitch spend 100 some-new-platform --url "https://example.com/billing"（Skyvern 模式）
```

---

## 阶段七：更多站点适配器 (Task 19-20)

### Task 19: Kimi 站点适配器

**产出文件**：`payswitch/adapters/kimi.py`

**AI 提示词**：

```
use context7

你是一位资深 Python 浏览器自动化专家。

请为 Pay-Switch 实现 Kimi (Moonshot) 充值的站点适配器。

## 要求
1. 继承 SiteAdapter 基类
2. 目标网站：kimi.moonshot.cn（或 platform.moonshot.cn）
3. 充值流程：登录 → 找到充值入口 → 选金额 → 选支付方式 → 等待 QR 码
4. 使用 @AdapterRegistry.register 注册
5. 代码注释使用中文
6. 选择器可能需要后续调整
```

---

### Task 20: Qwen 站点适配器

**产出文件**：`payswitch/adapters/qwen.py`

**AI 提示词**：

```
use context7

你是一位资深 Python 浏览器自动化专家。

请为 Pay-Switch 实现通义千问（Qwen）充值的站点适配器。

## 要求
1. 继承 SiteAdapter 基类
2. 目标网站：tongyi.aliyun.com（或相关充值页面）
3. 充值流程：登录 → 找到充值入口 → 选金额 → 选支付方式 → 等待 QR 码
4. 使用 @AdapterRegistry.register 注册
5. 代码注释使用中文
6. 选择器可能需要后续调整
```

---

### 🔶 验收检查点 7：站点适配器

```
验收内容：
  ✅ payswitch platforms 显示 3 个平台（deepseek/kimi/qwen）
  ✅ 每个适配器可正常注册和获取
  ✅ 至少 1 个适配器可实际跑通支付流程
```

---

## 阶段八：远程部署 (Task 21-23)

### Task 21: noVNC 会话管理

**目标**：实现 noVNC 会话的启动、URL 生成、用户认证。

**产出文件**：
- `payswitch/browser/novnc.py`

**AI 提示词**：

```
ultrathink

你是一位资深 DevOps 工程师，精通 noVNC、Xvfb、x11vnc 和 websockify。

请为 Pay-Switch 实现 noVNC 会话管理模块。

## 要求

1. NoVNCManager 类：
   ```python
   class NoVNCManager:
       """noVNC 会话管理（远程/Docker 场景）"""

       def __init__(self, port: int = 6080, vnc_port: int = 5900):
           pass

       async def start(self) -> str:
           """启动 noVNC 服务，返回访问 URL
           1. 启动 Xvfb 虚拟显示
           2. 启动 x11vnc（连接到 Xvfb）
           3. 启动 websockify + noVNC
           4. 返回 http://host:port/vnc.html?...
           """

       async def stop(self) -> None:
           """停止 noVNC 服务"""

       def get_url(self, session_token: str | None = None) -> str:
           """获取 noVNC 访问 URL"""

       def is_running(self) -> bool:
           """检查 noVNC 是否在运行"""

       def get_display(self) -> str:
           """获取 DISPLAY 环境变量（如 :99）"""
   ```

2. 在 DisplayManager 中集成：
   - novnc 模式时自动启动 NoVNCManager
   - notify_human() 输出 noVNC URL
   - 浏览器启动时使用 Xvfb 的 DISPLAY

3. 安全：
   - 生成随机 session token
   - 一次性 URL（可选）

4. 代码注释使用中文
```

**验收条件**：
- [x] noVNC 服务可正常启动
- [x] 生成的 URL 可在浏览器中打开
- [x] 可看到 Playwright 控制的浏览器画面
- [x] 可在 noVNC 中操作浏览器

---

### Task 22: Docker 部署配置

**目标**：创建 Dockerfile 和 docker-compose.yml，实现一键部署。

**产出文件**：
- `docker/Dockerfile`
- `docker/docker-compose.yml`

**AI 提示词**：

```
ultrathink

你是一位资深 Docker 专家，精通多阶段构建和容器化部署。

请为 Pay-Switch 创建 Docker 部署配置。

## 要求

1. Dockerfile：
   - 基础镜像：python:3.12-slim
   - 安装系统依赖：Xvfb, x11vnc, xterm, noVNC, websockify
   - 安装 Playwright 和 Chromium
   - 安装 payswitch 包
   - 入口点：启动 Xvfb + x11vnc + noVNC + bash
   - 暴露端口：6080（noVNC）

2. docker-compose.yml：
   - payswitch 服务
   - 端口映射：6080:6080
   - 持久化卷：
     - ~/.payswitch（配置和数据库）
     - profiles/（浏览器 Profile）
   - 环境变量：DISPLAY=:99

3. 使用说明（作为注释）：
   ```
   docker compose up -d
   # 访问 http://localhost:6080 查看浏览器
   # 执行命令：docker compose exec payswitch payswitch --help
   ```

4. 代码注释使用中文
```

**验收条件**：
- [x] docker compose up -d 成功启动
- [x] http://localhost:6080 可访问 noVNC
- [x] 容器内 payswitch 命令可用
- [x] 持久化卷正确挂载

---

### Task 23: Display 层集成 noVNC

**目标**：将 noVNC 集成到 DisplayManager 中，实现自动环境检测和模式切换。

**产出文件**：
- 更新 `payswitch/browser/display.py`（集成 noVNC）

**AI 提示词**：

```
你是一位资深 Python 开发专家。

请将 noVNC 集成到 Pay-Switch 的 DisplayManager 中。

## 要求

1. 更新 DisplayManager：
   - 初始化时检测环境（headed / novnc）
   - novnc 模式时自动启动 NoVNCManager
   - notify_human() 在 novnc 模式下输出 noVNC URL
   - wait_for_completion() 在两种模式下都正常工作

2. 更新 BrowserController.launch()：
   - novnc 模式时设置 DISPLAY 环境变量为 Xvfb 的虚拟显示

3. 代码注释使用中文
```

**验收条件**：
- [x] 自动环境检测正确
- [x] noVNC 模式下自动启动并输出 URL
- [x] headed 模式下不启动 noVNC

---

### 🔶 验收检查点 8：远程部署

```
验收内容：
  ✅ docker compose up -d 成功
  ✅ noVNC 可在浏览器中访问
  ✅ 跑通 PRD 7.3 场景三（Docker + noVNC）

验证方式：
  docker compose up -d
  docker compose exec payswitch payswitch setup
  docker compose exec payswitch payswitch login deepseek
  # 通过 noVNC 手动登录
  docker compose exec payswitch payswitch spend 200 deepseek
  # 通过 noVNC 扫码
```

---

## 阶段九：打磨与测试 (Task 24-26)

### Task 24: --dry-run 完善与 --verbose 模式

**目标**：完善沙箱模式和调试输出。

**产出文件**：
- 更新相关文件

**AI 提示词**：

```
你是一位资深 Python 开发专家。

请完善 Pay-Switch 的 --dry-run 和 --verbose 模式。

## 要求

1. --dry-run 完善：
   - spend 命令：完成安全检查 → 显示将执行的步骤 → 不启动浏览器
   - 显示模拟的交易摘要
   - 在交易记录中标记为 dry_run

2. --verbose 模式：
   - 输出详细的执行日志
   - 包括：Playwright 操作日志、检测器执行日志、安全检查详情
   - 使用 Python logging 模块

3. 代码注释使用中文
```

---

### Task 25: 单元测试

**目标**：为核心模块编写单元测试。

**产出文件**：
- `tests/test_models.py`
- `tests/test_ledger.py`
- `tests/test_guard.py`
- `tests/test_detector.py`
- `tests/test_adapters.py`

**AI 提示词**：

```
你是一位资深 Python 测试专家，精通 pytest 和异步测试。

请为 Pay-Switch 核心模块编写单元测试。

## 要求

1. test_models.py：
   - 测试所有数据模型的创建、序列化、反序列化
   - 测试 tx_id 自动生成
   - 测试配置的 load/save

2. test_ledger.py：
   - 测试交易记录 CRUD
   - 测试幂等检查（48小时窗口）
   - 测试日累计查询
   - 使用临时数据库

3. test_guard.py：
   - 测试单笔限额
   - 测试日限额
   - 测试白名单（空白名单、有白名单）
   - 测试幂等去重

4. test_detector.py：
   - 测试 QR 码检测逻辑
   - 测试敏感表单检测逻辑
   - 测试完成检测逻辑
   - 使用 mock 的页面内容

5. test_adapters.py：
   - 测试适配器注册机制
   - 测试平台列表查询
   - 测试适配器获取

6. 使用 pytest + pytest-asyncio
7. 代码注释使用中文
```

---

### Task 26: 集成测试与最终验收

**目标**：跑通 PRD 7.3 中定义的 4 个验证场景，修复所有问题。

**产出文件**：
- `tests/test_integration.py`
- 可能的 bug 修复

**AI 提示词**：

```
ultrathink

你是一位资深 QA 工程师，精通端到端测试和集成验证。

请为 Pay-Switch 编写集成测试，覆盖 PRD 7.3 的 4 个验证场景。

## 4 个场景

### 场景一：本地桌面 + 脚本模式
- pip install -e . && payswitch setup && payswitch login deepseek
- payswitch spend 200 deepseek --reason "充值API额度"
- 验证：脚本模式 + 本地弹窗 + 支付检测

### 场景二：脚本模式 → Skyvern 回退
- 模拟脚本执行失败
- 验证自动切换 Skyvern
- 验证 Skyvern 可继续执行

### 场景三：Docker + noVNC
- docker compose up
- 验证 noVNC 可访问
- 验证容器内 payswitch 命令可用

### 场景四：未知网站 + Skyvern
- payswitch spend 100 new-platform --url "https://example.com"
- 验证直接使用 Skyvern

## 要求
- 尽可能自动化测试（使用 mock 和 fixture）
- 需要真实浏览器的测试标记为 @pytest.mark.browser
- 需要 Docker 的测试标记为 @pytest.mark.docker
- 生成测试报告
- 代码注释使用中文
```

---

### 🔶 最终验收检查点

```
验收内容：
  ✅ 所有单元测试通过
  ✅ PRD 7.3 场景一跑通（本地 + 脚本模式）
  ✅ PRD 7.3 场景二跑通（Skyvern 回退）
  ✅ PRD 7.3 场景三跑通（Docker + noVNC）
  ✅ PRD 7.3 场景四跑通（未知网站 + Skyvern）
  ✅ payswitch --help 输出完整且美观
  ✅ --json 模式所有命令可用
  ✅ --dry-run 模式可用
  ✅ 代码注释全部中文
  ✅ 无明显安全漏洞

最终验证命令：
  pytest tests/ -v
  payswitch --help
  payswitch setup
  payswitch platforms
  payswitch config
  payswitch spend 200 deepseek --dry-run
```

---

## 任务总览

| # | 任务 | 阶段 | 预计时长 | 依赖 |
|---|------|------|---------|------|
| 1 | 项目脚手架与包结构 | 一 | 1h | - |
| 2 | 数据模型与配置系统 | 一 | 1.5h | 1 |
| 3 | SQLite 数据库与交易账本 | 一 | 1.5h | 2 |
| 4 | Playwright 浏览器控制器 | 二 | 1.5h | 1 |
| 5 | 浏览器 Profile 管理 | 二 | 1h | 2, 4 |
| 6 | 人类交互层 — 本地弹窗 | 二 | 1h | 4 |
| 7 | 支付环节检测器 | 三 | 2h | 4 |
| 8 | 浏览器安全层 | 三 | 1h | 4 |
| 9 | 站点适配器基类与注册 | 四 | 1h | 2 |
| 10 | DeepSeek 站点适配器 | 四 | 1.5h | 9 |
| 11 | 安全守卫 | 四 | 1h | 2, 3 |
| 12 | 支付流程编排引擎 | 四 | 2h | 3-11 |
| 13 | CLI — setup 命令 | 五 | 1h | 4, 2 |
| 14 | CLI — login 命令 | 五 | 1.5h | 5, 6, 9 |
| 15 | CLI — spend 命令 | 五 | 2h | 12 |
| 16 | CLI — 辅助命令集 | 五 | 1.5h | 3, 9 |
| 17 | Skyvern 集成层 | 六 | 2h | 4, 7 |
| 18 | 双模式回退链 | 六 | 1.5h | 12, 17 |
| 19 | Kimi 站点适配器 | 七 | 1h | 9 |
| 20 | Qwen 站点适配器 | 七 | 1h | 9 |
| 21 | noVNC 会话管理 | 八 | 2h | 6 |
| 22 | Docker 部署配置 | 八 | 1.5h | 21 |
| 23 | Display 层集成 noVNC | 八 | 1h | 6, 21 |
| 24 | --dry-run 与 --verbose | 九 | 1h | 15 |
| 25 | 单元测试 | 九 | 2h | 1-16 |
| 26 | 集成测试与最终验收 | 九 | 2h | ALL |

**总计：26 个任务，9 个阶段，9 个验收检查点**
**预计总工时：~38 小时**

---

## 验收检查点汇总

- [x] **检查点 1**（Task 1-3 后）：项目基础 — CLI 骨架 + 数据模型 + SQLite
- [x] **检查点 2**（Task 4-6 后）：浏览器基础 — Playwright + Profile + Display
- [x] **检查点 3**（Task 7-8 后）：支付检测 — 四种检测器 + 安全层
- [x] **检查点 4**（Task 9-12 后）：编排引擎 — 适配器 + 守卫 + 编排
- [x] **检查点 5**（Task 13-16 后）：CLI 命令 — 所有 8 个子命令可用
- [x] **检查点 6**（Task 17-18 后）：Skyvern — 智能模式 + 回退链
- [x] **检查点 7**（Task 19-20 后）：适配器 — 3 个平台完整
- [x] **检查点 8**（Task 21-23 后）：远程部署 — noVNC + Docker
- [x] **最终验收**（Task 24-26 后）：4 个场景全部跑通
