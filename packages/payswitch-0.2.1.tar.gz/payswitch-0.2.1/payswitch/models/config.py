"""Pay-Switch 全局配置模型。

配置文件存储在 ~/.payswitch/config.json，首次运行自动创建默认配置。
LLM API Key 使用 base64 编码存储（MVP 阶段，后续升级为 keyring）。
"""

from __future__ import annotations

import base64
import json
import logging
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

from payswitch.models.types import ComputerUseDriver, DisplayMode, StepCategory

logger = logging.getLogger(__name__)

# 默认配置文件目录和路径
_DEFAULT_CONFIG_DIR = Path.home() / ".payswitch"
_DEFAULT_CONFIG_FILE = _DEFAULT_CONFIG_DIR / "config.json"


class PaySwitchConfig(BaseModel):
    """Pay-Switch 全局配置，存储在 ~/.payswitch/config.json。

    所有金额单位为人民币元（CNY），超时单位为秒。
    """

    # ---- 安全限额 ----
    max_per_transaction: float = Field(
        default=500.0,
        ge=0.0,
        description="单笔交易限额（元），0 表示不限制",
    )
    daily_limit: float = Field(
        default=2000.0,
        ge=0.0,
        description="每日累计消费限额（元），0 表示不限制",
    )
    whitelist: list[str] = Field(
        default_factory=list,
        description="商户白名单（平台标识列表），空列表表示不限制",
    )
    auto_confirm_threshold: float = Field(
        default=0.0,
        ge=0.0,
        description="自动确认阈值（元），低于此金额时自动确认，0 表示关闭自动确认",
    )

    # ---- 货币与语言 ----
    default_currency: str = Field(
        default="CNY",
        description="默认结算货币（ISO 4217 代码）",
    )

    # ---- LLM 后端（smart 模式使用） ----
    llm_provider: str = Field(
        default="openai",
        description="LLM 服务提供商标识（openai / anthropic 等）",
    )
    llm_api_key: str = Field(
        default="",
        description="LLM API Key（base64 编码存储，读取时自动解码）",
    )
    llm_model: str = Field(
        default="gpt-4o",
        description="LLM 模型名称",
    )

    # ---- Stripe 支付通道配置 ----
    stripe_secret_key: str = Field(
        default="",
        description="Stripe Secret Key（base64 编码存储，sk_test_... 或 sk_live_...）",
    )
    stripe_webhook_secret: str = Field(
        default="",
        description="Stripe Webhook Signing Secret（base64 编码存储，whsec_...）",
    )
    stripe_webhook_port: int = Field(
        default=4242,
        ge=1024,
        le=65535,
        description="Stripe Webhook 监听端口",
    )
    stripe_default_currency: str = Field(
        default="usd",
        description="Stripe 默认货币（ISO 4217 代码，如 usd / cny / hkd）",
    )

    # ---- Computer Use（未知站点兜底探索）----
    computer_use_enabled: bool = Field(
        default=True,
        description="是否启用 Computer Use 作为未知站点/脚本失败时的兜底探索能力",
    )
    computer_use_driver: ComputerUseDriver = Field(
        default=ComputerUseDriver.external,
        description="Computer Use 推理来源：external / internal / hybrid",
    )
    computer_use_max_autonomous_category: StepCategory = Field(
        default=StepCategory.checkout_prep,
        description="Computer Use 可自动推进的最高步骤类别，敏感/最终授权必须交给人类闸门",
    )

    # ---- 用户 Chrome 上下文（真实日常 Profile / 已打开浏览器）----
    chrome_cdp_url: str = Field(
        default="",
        description=(
            "已有 Chrome 的 remote-debugging 地址。设置后 Payswitch 将连接该浏览器，"
            "而不是启动自管 Chromium。示例：http://127.0.0.1:9222"
        ),
    )
    chrome_user_data_dir: str = Field(
        default="",
        description=(
            "用户指定的 Chrome User Data 目录。设置后 Payswitch 使用该真实 Chrome "
            "profile 根目录，而不是 ~/.payswitch/profiles 下的自管 profile。"
        ),
    )
    chrome_profile_directory: str = Field(
        default="",
        description="Chrome profile 子目录名，例如 Default / Profile 1 / Profile 2。",
    )
    chrome_expected_profile_email: str = Field(
        default="",
        description="期望使用的 Chrome profile 登录邮箱。设置后启动前会校验，避免接错 profile。",
    )
    browser_channel: str = Field(
        default="chrome",
        description="Playwright 浏览器 channel。真实 Chrome profile 默认使用 chrome。",
    )

    # ---- 显示与远程访问 ----
    display_mode: Optional[DisplayMode] = Field(
        default=None,
        description="浏览器显示模式，None 表示自动检测（有显示器用 headed，否则用 novnc）",
    )
    novnc_port: int = Field(
        default=6080,
        ge=1024,
        le=65535,
        description="noVNC Web 界面监听端口",
    )

    # ---- 超时与重试 ----
    transaction_timeout: int = Field(
        default=300,
        ge=30,
        description="单笔交易最大等待时间（秒）",
    )

    # ---- 数据存储 ----
    data_dir: Path = Field(
        default_factory=lambda: _DEFAULT_CONFIG_DIR,
        description="数据目录，存放数据库和浏览器 Profile",
    )

    @field_validator("data_dir", mode="before")
    @classmethod
    def _coerce_data_dir(cls, v: Any) -> Path:
        """将字符串路径转换为 Path 对象，并展开用户目录 (~)。"""
        return Path(v).expanduser() if not isinstance(v, Path) else v.expanduser()

    # ------------------------------------------------------------------
    # 类方法：加载 / 保存 / 更新
    # ------------------------------------------------------------------

    @classmethod
    def load(cls, config_path: Path = _DEFAULT_CONFIG_FILE) -> "PaySwitchConfig":
        """从 JSON 文件加载配置。

        若文件不存在，自动创建包含默认值的配置文件并返回默认配置。

        Args:
            config_path: 配置文件路径，默认 ~/.payswitch/config.json

        Returns:
            PaySwitchConfig 实例
        """
        if not config_path.exists():
            logger.info("配置文件不存在，创建默认配置：%s", config_path)
            instance = cls()
            instance.save(config_path)
            return instance

        try:
            raw = json.loads(config_path.read_text(encoding="utf-8"))
            return cls.model_validate(raw)
        except (json.JSONDecodeError, ValueError) as e:
            logger.warning("配置文件解析失败（%s），使用默认配置：%s", e, config_path)
            return cls()

    def save(self, config_path: Path = _DEFAULT_CONFIG_FILE) -> None:
        """将当前配置序列化为 JSON 并写入文件。

        自动创建父目录（若不存在）。

        Args:
            config_path: 配置文件路径，默认 ~/.payswitch/config.json
        """
        config_path.parent.mkdir(parents=True, exist_ok=True)
        # 将 Path 对象转换为字符串以便 JSON 序列化
        data = self.model_dump(mode="json")
        data["data_dir"] = str(self.data_dir)
        config_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        logger.debug("配置已保存：%s", config_path)

    def update(self, **kwargs: Any) -> "PaySwitchConfig":
        """返回一个更新了指定字段的新配置实例，同时写入磁盘。

        Args:
            **kwargs: 要更新的字段名及新值

        Returns:
            更新后的新 PaySwitchConfig 实例
        """
        data = self.model_dump(mode="python")
        data.update(kwargs)
        updated = type(self).model_validate(data)
        updated.save()
        return updated

    # ------------------------------------------------------------------
    # API Key 辅助方法（base64 编解码）
    # ------------------------------------------------------------------

    def get_llm_api_key(self) -> str:
        """解码并返回明文 LLM API Key。

        Returns:
            明文 API Key 字符串，若未设置则返回空字符串
        """
        if not self.llm_api_key:
            return ""
        try:
            return base64.b64decode(self.llm_api_key.encode()).decode("utf-8")
        except Exception:
            # 若解码失败，可能是旧版明文存储，直接返回
            return self.llm_api_key

    def set_llm_api_key(self, plaintext_key: str) -> "PaySwitchConfig":
        """编码 API Key 并保存配置。

        Args:
            plaintext_key: 明文 API Key

        Returns:
            更新后的新 PaySwitchConfig 实例
        """
        encoded = base64.b64encode(plaintext_key.encode("utf-8")).decode("ascii")
        return self.update(llm_api_key=encoded)

    # ------------------------------------------------------------------
    # Stripe API Key 辅助方法
    # ------------------------------------------------------------------

    def get_stripe_secret_key(self) -> str:
        """解码并返回明文 Stripe Secret Key。

        Returns:
            明文 Stripe Secret Key，若未设置则返回空字符串
        """
        if not self.stripe_secret_key:
            return ""
        try:
            return base64.b64decode(self.stripe_secret_key.encode()).decode("utf-8")
        except Exception:
            # 若解码失败，可能是旧版明文存储，直接返回
            return self.stripe_secret_key

    def set_stripe_secret_key(self, plaintext_key: str) -> "PaySwitchConfig":
        """编码 Stripe Secret Key 并保存配置。

        Args:
            plaintext_key: 明文 Stripe Secret Key

        Returns:
            更新后的新 PaySwitchConfig 实例
        """
        encoded = base64.b64encode(plaintext_key.encode("utf-8")).decode("ascii")
        return self.update(stripe_secret_key=encoded)

    def get_stripe_webhook_secret(self) -> str:
        """解码并返回明文 Stripe Webhook Secret。

        Returns:
            明文 Webhook Secret，若未设置则返回空字符串
        """
        if not self.stripe_webhook_secret:
            return ""
        try:
            return base64.b64decode(self.stripe_webhook_secret.encode()).decode("utf-8")
        except Exception:
            return self.stripe_webhook_secret

    def set_stripe_webhook_secret(self, plaintext_secret: str) -> "PaySwitchConfig":
        """编码 Stripe Webhook Secret 并保存配置。

        Args:
            plaintext_secret: 明文 Webhook Secret

        Returns:
            更新后的新 PaySwitchConfig 实例
        """
        encoded = base64.b64encode(plaintext_secret.encode("utf-8")).decode("ascii")
        return self.update(stripe_webhook_secret=encoded)
