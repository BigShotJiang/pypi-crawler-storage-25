"""Pay-Switch 枚举类型与共用基础类型定义。

集中定义所有跨模块使用的枚举，避免循环引用。
"""

from __future__ import annotations

from enum import StrEnum


class TransactionStatus(StrEnum):
    """交易状态枚举。

    状态流转：pending → executing → human_action_required → completed
                                                           ↘ failed
                                 → failed / cancelled / timeout
    """

    # 已创建，尚未开始执行
    pending = "pending"
    # 正在自动执行中
    executing = "executing"
    # 等待人类介入（扫码/确认/填写敏感信息）
    human_action_required = "human_action_required"
    # 支付成功完成
    completed = "completed"
    # 执行失败（见 error 字段）
    failed = "failed"
    # 被用户或系统主动取消
    cancelled = "cancelled"
    # 超过配置的超时时间
    timeout = "timeout"


class PaymentMethod(StrEnum):
    """支付方式枚举。"""

    # 支付宝扫码支付
    alipay_qr = "alipay_qr"
    # 银行卡（借记卡/信用卡）
    bankcard = "bankcard"
    # Stripe 国际支付
    stripe = "stripe"
    # 自动选择最优方式
    auto = "auto"


class ExecutionMode(StrEnum):
    """支付执行模式枚举。"""

    # 纯脚本模式：基于 Playwright 录制的固定步骤执行
    script = "script"
    # 智能模式：结合 LLM 动态规划操作步骤（需要 smart 依赖）
    smart = "smart"
    # Computer Use 探索模式：模型驱动的受控浏览器探索
    computer_use = "computer_use"
    # 人类接管模式：启动可视化浏览器，完全由人类操作
    human_takeover = "human_takeover"


class DisplayMode(StrEnum):
    """浏览器显示模式枚举。"""

    # 本地有头浏览器（需要显示器）
    headed = "headed"
    # 通过 noVNC 远程可视化（无显示器服务器场景）
    novnc = "novnc"


class StepCategory(StrEnum):
    """流程步骤类别，用于区分可自动探索和必须人工授权的边界。"""

    # 普通导航：找入口、滚动、关闭非业务弹窗
    nav = "nav"
    # 登录态 / 身份验证：检测登录、触发登录入口
    identity = "identity"
    # 付款准备：选择套餐、进入 checkout、填写非敏感信息
    checkout_prep = "checkout_prep"
    # 敏感信息：CVV、OTP、支付密码、卡号等
    sensitive = "sensitive"
    # 最终授权：确认付款、订阅、支付宝确认等
    final_authorization = "final_authorization"
    # 结果确认：支付成功页、receipt、订单状态
    result = "result"


class StepRisk(StrEnum):
    """步骤风险等级，供 Computer Use 和 Orchestrator 做权限判断。"""

    low = "low"
    medium = "medium"
    high = "high"
    human_required = "human_required"


class ComputerUseDriver(StrEnum):
    """Computer Use 推理来源。"""

    # 外部 Agent 负责推理，Pay-Switch 只做受控执行和验证
    external = "external"
    # Pay-Switch 内部模型负责页面理解和导航
    internal = "internal"
    # 外部 Agent 给目标/建议，内部模型做局部页面理解
    hybrid = "hybrid"
