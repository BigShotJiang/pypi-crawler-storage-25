"""Pay-Switch 浏览器自动化模块。

基于 Playwright 实现浏览器操作，支持持久化 Profile 管理，
并通过安全层保护敏感支付操作。
"""

from payswitch.browser.controller import BrowserController, BrowserControllerError, BrowserNotLaunchedError
from payswitch.browser.safety import BrowserSafety, SafetyCheckResult

__all__ = [
    "BrowserController",
    "BrowserControllerError",
    "BrowserNotLaunchedError",
    "BrowserSafety",
    "SafetyCheckResult",
]
