"""Chrome profile identity helpers.

These helpers intentionally avoid launching Chrome. They only inspect Chrome's
Local State metadata and, for CDP endpoints, the local process command line.
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


@dataclass(frozen=True)
class ChromeProfileIdentity:
    """Resolved Chrome profile identity from Local State metadata."""

    user_data_dir: Path
    profile_directory: str
    name: str
    user_name: str
    gaia_name: str
    gaia_given_name: str = ""
    is_consented_primary_account: bool = False
    active_time: float = 0.0


def default_chrome_user_data_dirs(browser: str = "chrome") -> list[Path]:
    """Return likely Chrome/Chromium User Data roots for the current OS."""
    browser_key = browser.strip().lower()
    home = Path.home()

    if sys.platform == "darwin":
        if browser_key in {"chromium"}:
            return [home / "Library/Application Support/Chromium"]
        return [home / "Library/Application Support/Google/Chrome"]

    if sys.platform.startswith("win"):
        local_app_data = Path.home() / "AppData/Local"
        if browser_key in {"chromium"}:
            return [local_app_data / "Chromium/User Data"]
        return [local_app_data / "Google/Chrome/User Data"]

    if browser_key in {"chromium"}:
        return [home / ".config/chromium"]
    return [home / ".config/google-chrome", home / ".config/chromium"]


def discover_chrome_user_data_dirs(browser: str = "chrome") -> list[Path]:
    """Return existing Chrome/Chromium User Data roots for the current OS."""
    return [path for path in default_chrome_user_data_dirs(browser) if path.exists()]


def list_profile_identities(user_data_dir: str | Path) -> list[ChromeProfileIdentity]:
    """List profile identities available under a Chrome User Data directory."""
    root = Path(user_data_dir).expanduser()
    local_state = root / "Local State"
    if not local_state.exists():
        return []

    try:
        raw = json.loads(local_state.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []

    info_cache = raw.get("profile", {}).get("info_cache", {})
    if not isinstance(info_cache, dict):
        return []

    identities: list[ChromeProfileIdentity] = []
    for profile_directory, info in info_cache.items():
        if not isinstance(profile_directory, str) or not isinstance(info, dict):
            continue
        if not (root / profile_directory).exists():
            continue
        identities.append(_identity_from_info(root, profile_directory, info))

    return sorted(
        identities,
        key=_profile_sort_key,
    )


def resolve_profile_identity(
    user_data_dir: str | Path,
    profile_directory: str,
) -> ChromeProfileIdentity | None:
    """Resolve a Chrome profile identity from ``Local State``.

    Args:
        user_data_dir: Chrome User Data root directory.
        profile_directory: Chrome profile subdirectory, e.g. ``Default``.

    Returns:
        Profile identity, or ``None`` when metadata is missing.
    """
    root = Path(user_data_dir).expanduser()
    local_state = root / "Local State"
    if not local_state.exists():
        return None

    try:
        raw = json.loads(local_state.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    info = raw.get("profile", {}).get("info_cache", {}).get(profile_directory)
    if not isinstance(info, dict):
        return None

    return _identity_from_info(root, profile_directory, info)


def identity_matches_email(
    identity: ChromeProfileIdentity | None,
    expected_email: str,
) -> bool:
    """Return whether identity matches an expected Chrome account email."""
    expected = expected_email.strip().lower()
    if not expected:
        return True
    if identity is None:
        return False
    return identity.user_name.strip().lower() == expected


def resolve_cdp_profile_identity(cdp_url: str) -> ChromeProfileIdentity | None:
    """Best-effort resolve the Chrome profile behind a local CDP endpoint."""
    port = _extract_port(cdp_url)
    if port is None:
        return None

    try:
        output = subprocess.check_output(
            ["ps", "-axo", "command"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return None

    for line in output.splitlines():
        if "Google Chrome" not in line:
            continue
        if f"--remote-debugging-port={port}" not in line:
            continue

        user_data_dir = _extract_arg(line, "user-data-dir")
        profile_directory = _extract_arg(line, "profile-directory") or "Default"
        if user_data_dir:
            return resolve_profile_identity(user_data_dir, profile_directory)

    return None


def _extract_port(cdp_url: str) -> str | None:
    parsed = urlparse(cdp_url)
    if parsed.port is None:
        return None
    return str(parsed.port)


def _identity_from_info(
    root: Path,
    profile_directory: str,
    info: dict[str, Any],
) -> ChromeProfileIdentity:
    return ChromeProfileIdentity(
        user_data_dir=root,
        profile_directory=profile_directory,
        name=str(info.get("name") or ""),
        user_name=str(info.get("user_name") or ""),
        gaia_name=str(info.get("gaia_name") or ""),
        gaia_given_name=str(info.get("gaia_given_name") or ""),
        is_consented_primary_account=bool(
            info.get("is_consented_primary_account") or False
        ),
        active_time=float(info.get("active_time") or 0.0),
    )


def _profile_sort_key(
    identity: ChromeProfileIdentity,
) -> tuple[bool, tuple[tuple[int, int | str], ...]]:
    parts = re.split(r"(\d+)", identity.profile_directory.lower())
    natural = tuple(
        (0, int(part)) if part.isdigit() else (1, part)
        for part in parts
    )
    return identity.profile_directory != "Default", natural


def _extract_arg(command: str, name: str) -> str | None:
    needle = f"--{name}="
    start = command.find(needle)
    if start == -1:
        return None

    start += len(needle)
    if start >= len(command):
        return ""

    quote = command[start]
    if quote in {"'", '"'}:
        end = command.find(quote, start + 1)
        value = command[start + 1 :] if end == -1 else command[start + 1 : end]
        return value

    next_arg = command.find(" --", start)
    value = command[start:] if next_arg == -1 else command[start:next_arg]
    value = value.strip()
    if (value.startswith('"') and value.endswith('"')) or (
        value.startswith("'") and value.endswith("'")
    ):
        value = value[1:-1]
    return value
