"""Controlled Computer Use explorer for unknown checkout flows.

This module is intentionally a thin wrapper around the existing SkyvernEngine.
It gives the current architecture a clearer product boundary: Skyvern is the
LLM vision driver, while ComputerUseExplorer is the payment-aware explorer that
must stop before sensitive input or final authorization.
"""

from __future__ import annotations

import logging
from typing import Any

from payswitch.browser import skyvern as skyvern_module
from payswitch.browser.skyvern import SmartModeError
from payswitch.engine.risk import RiskGate
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import StepRecord
from payswitch.models.types import StepCategory, StepRisk

logger = logging.getLogger(__name__)


class ComputerUseUnavailableError(SmartModeError):
    """Raised when the controlled Computer Use explorer cannot run."""


class ComputerUseExplorer:
    """Payment-aware wrapper for model-driven browser exploration.

    The explorer is allowed to discover and prepare checkout paths, but the
    prompt and returned metadata make the boundary explicit: sensitive fields
    and final payment authorization belong to HumanGate / VerifiedExecutor.
    """

    def __init__(self, config: PaySwitchConfig) -> None:
        self._config = config
        self._engine = skyvern_module.SkyvernEngine(config)
        self._risk_gate = RiskGate(config)

    def is_available(self) -> bool:
        """Return whether the internal model-backed Computer Use path can run."""
        return self._config.computer_use_enabled and self._engine.is_available()

    async def explore_checkout(
        self,
        page: Any,
        *,
        payee: str,
        amount: float,
        method: str,
        url: str | None,
        max_steps: int = 10,
    ) -> list[StepRecord]:
        """Explore an unknown or changed checkout flow until a handoff point."""
        if not self._config.computer_use_enabled:
            raise ComputerUseUnavailableError("Computer Use 已在配置中关闭")

        if not self._engine.is_available():
            raise ComputerUseUnavailableError(
                "Computer Use 需要可用的 LLM 后端：请配置 llm_api_key 并安装 smart 依赖"
            )

        decision = self._risk_gate.can_run_autonomously(
            category=StepCategory.checkout_prep,
            risk=StepRisk.medium,
        )
        if not decision.allowed:
            raise ComputerUseUnavailableError(
                f"Computer Use 当前配置不允许自动推进到 checkout_prep：{decision.reason}"
            )

        task_description = self._build_task_description(
            payee=payee,
            amount=amount,
            method=method,
        )
        logger.info(
            "Computer Use 探索启动：payee=%s amount=%.2f method=%s url=%s",
            payee,
            amount,
            method,
            url,
        )
        steps = await self._engine.execute_task(
            page=page,
            task_description=task_description,
            url=url,
            max_steps=max_steps,
        )
        return [
            step.model_copy(
                update={
                    "category": StepCategory.checkout_prep,
                    "risk": StepRisk.medium,
                }
            )
            for step in steps
        ]

    @staticmethod
    def _build_task_description(*, payee: str, amount: float, method: str) -> str:
        """Build a bounded prompt for checkout discovery, not final payment."""
        return (
            f"目标：在 {payee} 页面中探索并推进到付款前的 checkout 候选状态。"
            f"期望金额为 {amount:.2f}，期望支付方式为 {method}。"
            "你可以检查登录态、寻找充值/会员/购买入口、关闭普通弹窗、选择套餐候选、"
            "进入订单或收银台页面。"
            "严格边界：遇到 CVV、银行卡号、短信验证码、支付密码、支付宝/微信确认、"
            "最终 Pay/Subscribe/确认付款按钮、自动续费或协议确认时，必须返回 done，"
            "不要填写敏感信息，不要提交最终付款，不要勾选协议。"
            "到达二维码、支付确认页、CVV/OTP 页面或最终付款按钮可见时，也返回 done。"
        )
