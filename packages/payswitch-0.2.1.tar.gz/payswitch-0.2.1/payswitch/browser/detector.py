"""支付环节检测器模块。

通过 Playwright page.evaluate() 在浏览器上下文中执行 JS 检测页面状态，
识别当前处于哪个支付环节，并判断是否需要人类介入。
"""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod

from playwright.async_api import Page
from pydantic import BaseModel

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 结果模型
# ---------------------------------------------------------------------------


class DetectionResult(BaseModel):
    """检测结果数据模型。"""

    detector_name: str
    # 动作类型：scan_qr / fill_form / confirm / completed
    action_type: str
    # 中文描述，用于日志和用户提示
    description: str
    # 附加数据，例如 QR 图片 URL、截图路径等
    data: dict = {}


# ---------------------------------------------------------------------------
# 检测器基类
# ---------------------------------------------------------------------------


class PaymentDetector(ABC):
    """支付环节检测器基类。

    每个检测器对应一种支付页面状态，负责：
    1. detect()           — 判断当前页面是否处于此状态
    2. requires_human()   — 是否需要暂停等待人类操作
    3. detect_completion()— 等待操作完成（人类操作完后调用）
    """

    name: str

    @abstractmethod
    async def detect(self, page: Page) -> DetectionResult | None:
        """检测当前页面是否匹配此检测器。

        Returns:
            DetectionResult 表示匹配；None 表示不匹配。
        """

    @abstractmethod
    def requires_human(self) -> bool:
        """是否需要人类介入才能完成此环节。"""

    @abstractmethod
    async def detect_completion(self, page: Page) -> bool:
        """检测该环节的操作是否已完成。

        Args:
            page: 当前 Playwright 页面实例。

        Returns:
            True 表示操作已完成，可进入下一环节。
        """


# ---------------------------------------------------------------------------
# QR 码检测器
# ---------------------------------------------------------------------------


class QRCodeDetector(PaymentDetector):
    """检测页面中的支付 QR 码。

    覆盖场景：
    - 普通 img 标签的 src/alt/title 含 qr 关键词
    - canvas 元素位于典型 QR 容器内
    - 支付宝 QR（qr.alipay.com 域名 / class 包含 qrcode）
    - 微信支付 QR（wx.tenpay.com 域名）
    """

    name = "QRCodeDetector"

    # 检测 QR 码是否存在的 JS 脚本
    _JS_DETECT = """
() => {
    // 检测 img 标签：src、alt 或 title 包含 qr 相关关键词
    const qrImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        const src   = (img.src   || '').toLowerCase();
        const alt   = (img.alt   || '').toLowerCase();
        const title = (img.title || '').toLowerCase();
        return src.includes('qr') || src.includes('qrcode')
            || alt.includes('二维码') || alt.includes('qr')
            || title.includes('二维码') || title.includes('qr')
            || src.includes('qr.alipay.com')
            || src.includes('wx.tenpay.com');
    });

    if (qrImgs.length > 0) {
        return {
            found: true,
            type: 'img',
            src: qrImgs[0].src || ''
        };
    }

    // 检测 canvas：在典型 QR 容器（class 含 qrcode/qr-code/qr_code）内
    const qrContainers = document.querySelectorAll(
        '[class*="qrcode"], [class*="qr-code"], [class*="qr_code"], ' +
        '[id*="qrcode"], [id*="qr-code"], [id*="qr_code"]'
    );
    for (const container of qrContainers) {
        const canvas = container.querySelector('canvas');
        if (canvas) {
            return { found: true, type: 'canvas', src: '' };
        }
    }

    // 检测支付宝特征：class 含 qrcode 且在支付宝域内，或 src 直接含 alipay
    const alipayImgs = Array.from(document.querySelectorAll('img')).filter(img =>
        (img.src || '').includes('alipay')
    );
    if (alipayImgs.length > 0) {
        return { found: true, type: 'alipay_img', src: alipayImgs[0].src || '' };
    }

    return { found: false, type: '', src: '' };
}
"""

    # 检测 QR 码是否消失（或出现成功文本）的 JS 脚本
    _JS_COMPLETION = """
() => {
    const qrImgs = Array.from(document.querySelectorAll('img')).filter(img => {
        const src   = (img.src   || '').toLowerCase();
        const alt   = (img.alt   || '').toLowerCase();
        const title = (img.title || '').toLowerCase();
        return src.includes('qr') || src.includes('qrcode')
            || src.startsWith('data:image/')
            || alt.includes('二维码') || alt.includes('qr')
            || title.includes('二维码') || title.includes('qr')
            || src.includes('qr.alipay.com')
            || src.includes('wx.tenpay.com')
            || src.includes('alipay');
    });

    // QR 容器消失
    const containers = document.querySelectorAll(
        '[class*="qrcode"], [class*="qr-code"], [class*="qr_code"], ' +
        '[id*="qrcode"], [id*="qr-code"]'
    );
    const hasContainerQR = Array.from(containers).some(el => el.offsetParent !== null);
    const hasImageQR = qrImgs.some(img => img.offsetParent !== null);
    const hasQR = hasContainerQR || hasImageQR;

    if (!hasQR) {
        return { done: true, reason: 'qr_disappeared' };
    }

    // 页面出现支付成功文本
    const bodyText = document.body.innerText || '';
    const successKeywords = ['支付成功', '充值成功', '交易完成', 'Payment Successful',
                              'top up successfully', 'successfully paid'];
    const hasSuccess = successKeywords.some(kw =>
        bodyText.toLowerCase().includes(kw.toLowerCase())
    );
    if (hasSuccess) {
        return { done: true, reason: 'success_text' };
    }

    return { done: false, reason: 'qr_still_present' };
}
"""

    async def detect(self, page: Page) -> DetectionResult | None:
        """检测页面是否存在 QR 码。"""
        try:
            result: dict = await page.evaluate(self._JS_DETECT)
            if not result.get("found"):
                return None
            return DetectionResult(
                detector_name=self.name,
                action_type="scan_qr",
                description="检测到支付二维码，请使用手机扫码完成支付",
                data={"qr_src": result.get("src", ""), "qr_type": result.get("type", "")},
            )
        except Exception:
            logger.debug("%s.detect 发生异常，跳过", self.name, exc_info=True)
            return None

    def requires_human(self) -> bool:
        """扫码操作必须由人类完成。"""
        return True

    async def detect_completion(self, page: Page) -> bool:
        """QR 码消失或出现成功文本时视为完成。"""
        try:
            result: dict = await page.evaluate(self._JS_COMPLETION)
            return bool(result.get("done", False))
        except Exception:
            logger.debug("%s.detect_completion 发生异常", self.name, exc_info=True)
            return False


# ---------------------------------------------------------------------------
# 敏感表单检测器
# ---------------------------------------------------------------------------


class SensitiveFormDetector(PaymentDetector):
    """检测页面中的敏感支付表单。

    覆盖场景：
    - type="password" 输入框（支付密码）
    - name/id 含银行卡相关关键词的输入框
    - 标签文本含"支付密码"、"银行卡号"、"信用卡"等中文关键词
    """

    name = "SensitiveFormDetector"

    # 检测敏感表单字段的 JS 脚本
    _JS_DETECT = """
() => {
    // 检测 type=password 输入框
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    if (passwordInputs.length > 0) {
        return { found: true, reason: 'password_input' };
    }

    // 检测 name 或 id 含卡号/CVV/有效期相关关键词的输入框
    const cardKeywords = ['card', 'cvv', 'cvc', 'expiry', 'card_number',
                           'card-number', 'cardnumber', 'pan', 'bankcard'];
    const allInputs = Array.from(document.querySelectorAll('input'));
    const cardInput = allInputs.find(input => {
        const name = (input.name || '').toLowerCase();
        const id   = (input.id   || '').toLowerCase();
        return cardKeywords.some(kw => name.includes(kw) || id.includes(kw));
    });
    if (cardInput) {
        return {
            found: true,
            reason: 'card_input',
            field: cardInput.name || cardInput.id || ''
        };
    }

    // 检测标签文本含中文敏感关键词
    const chineseKeywords = ['支付密码', '银行卡号', '信用卡', '借记卡', '卡号', 'CVV', 'CVC'];
    const labels = Array.from(document.querySelectorAll('label, span, div, p'));
    const sensitiveLabel = labels.find(el => {
        const text = (el.innerText || el.textContent || '').trim();
        // 避免匹配大段落文本，只匹配短文本节点
        if (text.length > 30) return false;
        return chineseKeywords.some(kw => text.includes(kw));
    });
    if (sensitiveLabel) {
        return {
            found: true,
            reason: 'chinese_label',
            label: (sensitiveLabel.innerText || '').trim()
        };
    }

    return { found: false, reason: '' };
}
"""

    # 通过 URL 变化检测表单提交完成的 JS 脚本（配合外部记录初始 URL 使用）
    _JS_COMPLETION_FORM_GONE = """
() => {
    // 敏感输入框是否已消失（表单已提交并跳转或隐藏）
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    const visiblePasswords = Array.from(passwordInputs).filter(
        el => el.offsetParent !== null
    );
    return { formGone: visiblePasswords.length === 0 };
}
"""

    def __init__(self) -> None:
        # 记录进入此环节时的初始 URL，用于检测跳转
        self._initial_url: str = ""

    async def detect(self, page: Page) -> DetectionResult | None:
        """检测页面是否存在敏感支付表单。"""
        try:
            result: dict = await page.evaluate(self._JS_DETECT)
            if not result.get("found"):
                return None
            # 记录当前 URL 供 detect_completion 使用
            self._initial_url = page.url
            return DetectionResult(
                detector_name=self.name,
                action_type="fill_form",
                description="检测到敏感支付表单，请填写银行卡/支付密码等信息",
                data={
                    "reason": result.get("reason", ""),
                    "field": result.get("field", "") or result.get("label", ""),
                },
            )
        except Exception:
            logger.debug("%s.detect 发生异常，跳过", self.name, exc_info=True)
            return None

    def requires_human(self) -> bool:
        """填写敏感信息必须由人类完成。"""
        return True

    async def detect_completion(self, page: Page) -> bool:
        """表单提交后页面跳转（URL 变化）或表单消失时视为完成。"""
        try:
            # URL 已变化：表单已提交并跳转
            if self._initial_url and page.url != self._initial_url:
                return True
            # 密码框已消失（已隐藏或页面内刷新）
            result: dict = await page.evaluate(self._JS_COMPLETION_FORM_GONE)
            return bool(result.get("formGone", False))
        except Exception:
            logger.debug("%s.detect_completion 发生异常", self.name, exc_info=True)
            return False


# ---------------------------------------------------------------------------
# 支付确认检测器
# ---------------------------------------------------------------------------


class PaymentConfirmDetector(PaymentDetector):
    """检测支付确认按钮或链接。

    覆盖场景：
    - 按钮/链接文本含"确认支付"、"立即支付"、"确认订单"等中文
    - 按钮/链接文本含"Confirm Payment"、"Pay Now"等英文
    """

    name = "PaymentConfirmDetector"

    # 检测确认按钮的 JS 脚本
    _JS_DETECT = """
() => {
    const keywords = [
        '确认支付', '立即支付', '确认订单', '去支付', '马上支付',
        '提交订单', '去付款', '付款', '支付',
        'Confirm Payment', 'Pay Now', 'Confirm Order', 'Submit Payment',
        'Complete Payment', 'Pay', 'Checkout'
    ];

    // 检测按钮和 a 标签
    const clickables = Array.from(
        document.querySelectorAll('button, a, [role="button"], input[type="submit"]')
    );

    const matchedEl = clickables.find(el => {
        const text = (el.innerText || el.textContent || el.value || '').trim();
        // 过滤过长文本（防止误匹配段落）
        if (text.length > 20) return false;
        return keywords.some(kw => text.includes(kw));
    });

    if (matchedEl) {
        return {
            found: true,
            text: (matchedEl.innerText || matchedEl.textContent || '').trim(),
            tag: matchedEl.tagName
        };
    }

    return { found: false, text: '', tag: '' };
}
"""

    # 检测确认按钮是否已消失的 JS 脚本
    _JS_COMPLETION = """
() => {
    const keywords = [
        '确认支付', '立即支付', '确认订单', '去支付', '马上支付',
        'Confirm Payment', 'Pay Now', 'Confirm Order'
    ];

    const clickables = Array.from(
        document.querySelectorAll('button, a, [role="button"], input[type="submit"]')
    );

    const stillPresent = clickables.some(el => {
        const text = (el.innerText || el.textContent || el.value || '').trim();
        if (text.length > 20) return false;
        const visible = el.offsetParent !== null;
        return visible && keywords.some(kw => text.includes(kw));
    });

    return { buttonGone: !stillPresent };
}
"""

    def __init__(self) -> None:
        self._initial_url: str = ""

    async def detect(self, page: Page) -> DetectionResult | None:
        """检测页面是否出现支付确认按钮。"""
        try:
            result: dict = await page.evaluate(self._JS_DETECT)
            if not result.get("found"):
                return None
            self._initial_url = page.url
            return DetectionResult(
                detector_name=self.name,
                action_type="confirm",
                description=f"检测到支付确认按钮「{result.get('text', '')}」，请确认后点击",
                data={"button_text": result.get("text", ""), "tag": result.get("tag", "")},
            )
        except Exception:
            logger.debug("%s.detect 发生异常，跳过", self.name, exc_info=True)
            return None

    def requires_human(self) -> bool:
        """支付确认需要人类确认操作。"""
        return True

    async def detect_completion(self, page: Page) -> bool:
        """确认按钮消失或页面跳转时视为完成。"""
        try:
            if self._initial_url and page.url != self._initial_url:
                return True
            result: dict = await page.evaluate(self._JS_COMPLETION)
            return bool(result.get("buttonGone", False))
        except Exception:
            logger.debug("%s.detect_completion 发生异常", self.name, exc_info=True)
            return False


# ---------------------------------------------------------------------------
# 完成状态检测器
# ---------------------------------------------------------------------------


class CompletionDetector(PaymentDetector):
    """检测支付已完成状态。

    覆盖场景：
    - 页面包含"支付成功"、"充值成功"、"交易完成"等中文文本
    - 页面包含"Payment Successful"、"top up successfully"等英文文本
    - 页面存在 class 含 success / check / done 的图标元素
    """

    name = "CompletionDetector"

    # 检测完成状态的 JS 脚本
    _JS_DETECT = """
() => {
    const successTextKeywords = [
        '支付成功', '充值成功', '交易完成', '付款成功', '订单完成',
        '支付已完成', '转账成功',
        'Payment Successful', 'top up successfully', 'successfully paid',
        'Payment Complete', 'Transaction Complete', 'Order Complete',
        'Successfully Paid', 'Payment Confirmed'
    ];

    const bodyText = document.body.innerText || '';

    const matchedText = successTextKeywords.find(kw =>
        bodyText.toLowerCase().includes(kw.toLowerCase())
    );
    if (matchedText) {
        return { found: true, reason: 'success_text', matched: matchedText };
    }

    // 检测成功图标元素（class 含 success / check / done / tick / complete）
    const iconKeywords = ['success', 'check', 'done', 'tick', 'complete', 'finish'];
    const iconSelectors = iconKeywords.flatMap(kw => [
        `[class*="${kw}"]`
    ]).join(', ');

    const iconElements = document.querySelectorAll(iconSelectors);
    const visibleIcon = Array.from(iconElements).find(el => {
        // 只匹配小型图标元素（宽高在合理范围内）
        const rect = el.getBoundingClientRect();
        const isSmall = rect.width > 0 && rect.width < 200 && rect.height < 200;
        const isVisible = el.offsetParent !== null;
        // 排除整页容器（避免误匹配 body/main 级别的 success 容器）
        const tagName = el.tagName.toLowerCase();
        const isIconLike = ['i', 'span', 'svg', 'img', 'div'].includes(tagName);
        return isSmall && isVisible && isIconLike;
    });

    if (visibleIcon) {
        return {
            found: true,
            reason: 'success_icon',
            matched: visibleIcon.className || visibleIcon.tagName
        };
    }

    return { found: false, reason: '', matched: '' };
}
"""

    async def detect(self, page: Page) -> DetectionResult | None:
        """检测页面是否已显示支付成功状态。"""
        try:
            result: dict = await page.evaluate(self._JS_DETECT)
            if not result.get("found"):
                return None
            return DetectionResult(
                detector_name=self.name,
                action_type="completed",
                description="支付已完成，检测到成功状态页面",
                data={
                    "reason": result.get("reason", ""),
                    "matched": result.get("matched", ""),
                },
            )
        except Exception:
            logger.debug("%s.detect 发生异常，跳过", self.name, exc_info=True)
            return None

    def requires_human(self) -> bool:
        """支付完成状态不需要人类介入。"""
        return False

    async def detect_completion(self, page: Page) -> bool:
        """已完成状态始终返回 True。"""
        return True


# ---------------------------------------------------------------------------
# 检测器流水线
# ---------------------------------------------------------------------------


class DetectorPipeline:
    """按优先级依次运行检测器，返回第一个匹配的结果。

    默认优先级：
    1. CompletionDetector    — 已成功就不再暂停
    2. QRCodeDetector        — 等待扫码
    3. SensitiveFormDetector — 等待填写敏感信息
    4. PaymentConfirmDetector— 等待确认支付
    """

    def __init__(self, detectors: list[PaymentDetector] | None = None) -> None:
        if detectors is not None:
            self._detectors = detectors
        else:
            # 按优先级顺序加载所有内置检测器
            self._detectors: list[PaymentDetector] = [
                CompletionDetector(),
                QRCodeDetector(),
                SensitiveFormDetector(),
                PaymentConfirmDetector(),
            ]

    async def scan(self, page: Page) -> DetectionResult | None:
        """依次运行所有检测器，返回第一个匹配的结果。

        Args:
            page: 当前 Playwright 页面实例。

        Returns:
            第一个匹配的 DetectionResult；若均未匹配则返回 None。
        """
        for detector in self._detectors:
            try:
                result = await detector.detect(page)
                if result is not None:
                    logger.debug(
                        "检测器 %s 命中：%s", detector.name, result.action_type
                    )
                    return result
            except Exception:
                # 单个检测器异常不影响后续检测器执行
                logger.warning(
                    "检测器 %s 执行异常，跳过", detector.name, exc_info=True
                )
        return None

    async def wait_for_completion(
        self,
        page: Page,
        result: DetectionResult,
        timeout: int = 300,
    ) -> bool:
        """等待对应检测器报告操作完成。

        通过检测器名称找回负责该结果的检测器实例，
        每秒轮询一次 detect_completion()，直到完成或超时。

        Args:
            page:    当前 Playwright 页面实例。
            result:  scan() 返回的检测结果，用于定位检测器。
            timeout: 最长等待秒数，默认 300 秒（5 分钟）。

        Returns:
            True 表示在超时前完成；False 表示超时。
        """
        # 根据检测结果找到对应的检测器实例
        detector = self._find_detector(result.detector_name)
        if detector is None:
            logger.warning(
                "找不到名为 %s 的检测器，无法等待完成", result.detector_name
            )
            return False

        logger.info(
            "等待检测器 %s 报告完成，最长等待 %d 秒…",
            detector.name,
            timeout,
        )

        elapsed = 0
        poll_interval = 1  # 每秒轮询一次

        while elapsed < timeout:
            try:
                done = await detector.detect_completion(page)
                if done:
                    logger.info("检测器 %s 报告操作已完成", detector.name)
                    return True
            except Exception:
                logger.debug(
                    "等待完成时检测器 %s 发生异常，继续等待", detector.name, exc_info=True
                )

            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

        logger.warning(
            "等待检测器 %s 完成超时（%d 秒）", detector.name, timeout
        )
        return False

    def _find_detector(self, name: str) -> PaymentDetector | None:
        """按名称查找检测器实例。"""
        for detector in self._detectors:
            if detector.name == name:
                return detector
        return None
