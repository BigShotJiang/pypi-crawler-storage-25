"""Pay-Switch 平台适配器模块。

每个适配器对应一个支付平台（如 DeepSeek、Kimi），
封装该平台特定的充值流程和页面交互逻辑。

使用方式::

    # 注册适配器（在各平台模块中声明）
    @AdapterRegistry.register
    class DeepSeekAdapter(SiteAdapter):
        name = "deepseek"
        ...

    # 在引擎或 CLI 中查询和实例化
    adapter = AdapterRegistry.get("deepseek")
    platforms = AdapterRegistry.list_platforms()
"""

from __future__ import annotations

from payswitch.adapters.base import ScriptExecutionError, ScriptStep, SiteAdapter


class AdapterRegistry:
    """站点适配器注册表。

    以类变量 _adapters 维护平台名称到适配器类的映射，
    提供注册（装饰器）、查询和枚举三类操作。
    所有方法均为类方法，无需实例化注册表本身。
    """

    # 平台名称（str） → 适配器类（type[SiteAdapter]）的映射
    _adapters: dict[str, type[SiteAdapter]] = {}

    @classmethod
    def register(cls, adapter_class: type[SiteAdapter]) -> type[SiteAdapter]:
        """将适配器类注册到全局注册表（用作类装饰器）。

        以 adapter_class.name 为键存储适配器类，
        重复注册同名适配器时新类会覆盖旧类并发出警告。

        用法::

            @AdapterRegistry.register
            class MyAdapter(SiteAdapter):
                name = "my_platform"
                ...

        Args:
            adapter_class: 继承自 SiteAdapter 的适配器类。

        Returns:
            原样返回 adapter_class，保持装饰器语义不变。

        Raises:
            AttributeError: adapter_class 未定义 name 属性时抛出。
        """
        platform_name: str = adapter_class.name
        if platform_name in cls._adapters:
            import warnings

            warnings.warn(
                f"适配器 '{platform_name}' 已注册，将被 {adapter_class.__name__} 覆盖。",
                stacklevel=2,
            )
        cls._adapters[platform_name] = adapter_class
        return adapter_class

    @classmethod
    def get(cls, platform: str) -> SiteAdapter | None:
        """获取指定平台的适配器实例。

        每次调用均创建新实例，适配器本身应保持无状态。

        Args:
            platform: 平台标识符，与 SiteAdapter.name 一致（大小写敏感）。

        Returns:
            适配器实例；平台未注册时返回 None。
        """
        adapter_class = cls._adapters.get(platform)
        if adapter_class is None:
            return None
        return adapter_class()

    @classmethod
    def list_platforms(cls) -> list[dict]:
        """列出所有已注册平台的基本信息。

        返回的字典包含平台标识符、展示名称、充值 URL、
        登录 URL 以及支持的支付方式列表。

        Returns:
            按注册顺序排列的平台信息字典列表，例如::

                [
                    {
                        "name": "deepseek",
                        "display_name": "DeepSeek",
                        "top_up_url": "https://...",
                        "login_url": "https://...",
                        "supported_methods": ["alipay_qr"],
                    },
                    ...
                ]
        """
        result: list[dict] = []
        for adapter_class in cls._adapters.values():
            result.append(
                {
                    "name": adapter_class.name,
                    "display_name": adapter_class.display_name,
                    "top_up_url": adapter_class.top_up_url,
                    "login_url": adapter_class.login_url,
                    # StrEnum 成员直接序列化为字符串值，便于 JSON 输出
                    "supported_methods": [m.value for m in adapter_class.supported_methods],
                }
            )
        return result

    @classmethod
    def has(cls, platform: str) -> bool:
        """判断指定平台是否已有注册的适配器。

        Args:
            platform: 平台标识符（大小写敏感）。

        Returns:
            True 表示已注册，False 表示未注册。
        """
        return platform in cls._adapters


__all__ = [
    "AdapterRegistry",
    "SiteAdapter",
    "ScriptStep",
    "ScriptExecutionError",
]

# ---------------------------------------------------------------------------
# 导入所有内置适配器，触发 @AdapterRegistry.register 装饰器完成注册。
# 此处 import 必须在 AdapterRegistry 类定义之后，避免循环引用问题。
# 新增适配器时，在此处添加对应的 import 语句。
# ---------------------------------------------------------------------------
from payswitch.adapters import deepseek as _deepseek  # noqa: F401
from payswitch.adapters import kimi as _kimi  # noqa: F401
from payswitch.adapters import nineemail as _nineemail  # noqa: F401
from payswitch.adapters import qwen as _qwen  # noqa: F401

# Stripe 适配器（可选依赖，导入失败时静默跳过）
try:
    from payswitch.adapters import stripe as _stripe  # noqa: F401
except ImportError:
    # Stripe SDK 未安装，适配器不可用（用户可通过 pip install payswitch[stripe] 安装）
    pass
