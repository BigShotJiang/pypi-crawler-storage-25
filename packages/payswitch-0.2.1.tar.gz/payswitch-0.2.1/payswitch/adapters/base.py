"""站点适配器基类定义。

所有平台适配器必须继承 SiteAdapter 并实现 execute_topup 方法。
ScriptStep 描述单个页面操作步骤，供执行引擎记录和回放。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel, Field

from payswitch.models.types import PaymentMethod, StepCategory, StepRisk


class ScriptStep(BaseModel):
    """单个脚本步骤的结构化定义。

    执行引擎将每个操作封装为 ScriptStep，
    便于日志记录、调试和失败回放。
    """

    # 步骤描述，使用中文说明该步骤的意图
    description: str
    # 操作类型：navigate / click / fill / wait / detect_payment
    action: str
    # CSS 选择器或 XPath，navigate 和 detect_payment 步骤可为空
    selector: str | None = None
    # fill 动作填入的值，其他动作可为空
    value: str | None = None
    # navigate 动作的目标 URL
    url: str | None = None
    # 步骤类别：默认当作普通导航，适配器可将高风险步骤标为 checkout_prep/final_authorization
    category: StepCategory = StepCategory.nav
    # 风险等级：financial/sensitive 步骤应显式升级
    risk: StepRisk = StepRisk.low
    # 执行前后应出现的文本信号（最小版本先用文本断言表达）
    expected_texts: list[str] = Field(default_factory=list)
    # 执行前后不应出现的文本信号，如自动续费/订阅等
    forbidden_texts: list[str] = Field(default_factory=list)
    # 是否必须用户授权后才允许执行
    requires_human_authorization: bool = False


class ScriptExecutionError(Exception):
    """脚本执行失败异常。

    当适配器在固定脚本模式下遇到无法处理的情况时抛出此异常，
    执行引擎捕获后将自动回退到 Skyvern 智能模式重试。
    """


class SiteAdapter(ABC):
    """站点脚本适配器基类。

    每个平台实现一个子类，并通过 @AdapterRegistry.register 注册。
    子类必须声明类属性 name / display_name / top_up_url / login_url /
    supported_methods，并实现 execute_topup 抽象方法。

    示例::

        @AdapterRegistry.register
        class DeepSeekAdapter(SiteAdapter):
            name = "deepseek"
            display_name = "DeepSeek"
            top_up_url = "https://platform.deepseek.com/top_up"
            login_url = "https://platform.deepseek.com/sign_in"
            supported_methods = [PaymentMethod.alipay_qr]

            async def execute_topup(self, page, amount, method=None):
                ...
    """

    # 平台唯一标识符（小写英文），用作注册表的键
    name: str
    # 平台展示名称（用于 CLI 输出和日志）
    display_name: str
    # 充值页面 URL
    top_up_url: str
    # 登录页面 URL
    login_url: str
    # 该平台支持的支付方式列表
    supported_methods: list[PaymentMethod]

    @abstractmethod
    async def execute_topup(
        self,
        page: Any,
        amount: float,
        method: PaymentMethod | None = None,
    ) -> list[ScriptStep]:
        """执行充值脚本，返回本次执行的步骤列表。

        实现者应按顺序完成以下工作：
        1. 导航到充值页（如尚未在该页）
        2. 填写金额
        3. 选择支付方式
        4. 触发支付二维码或跳转（最后一步应包含 detect_payment 动作）

        遇到页面结构变更或无法定位元素时，应抛出 ScriptExecutionError，
        由上层引擎决定是否回退到 Skyvern。

        Args:
            page: Playwright 的 Page 对象（使用 Any 类型避免强依赖 playwright）。
            amount: 充值金额（人民币元）。
            method: 指定支付方式；为 None 时由适配器自行选择默认方式。

        Returns:
            按执行顺序排列的 ScriptStep 列表，用于日志和审计。

        Raises:
            ScriptExecutionError: 脚本执行失败，触发上层回退逻辑。
        """

    async def validate_amount(self, amount: float) -> bool:
        """验证充值金额是否在平台支持的范围内。

        子类可覆盖此方法以添加平台特定的金额限制，
        例如最小充值额或特定面额限制。

        Args:
            amount: 待验证的充值金额（人民币元）。

        Returns:
            True 表示金额合法，False 表示不合法。
        """
        return amount > 0

    def get_login_url(self) -> str:
        """获取平台登录页 URL。

        Returns:
            登录页面的完整 URL 字符串。
        """
        return self.login_url

    def get_top_up_url(self) -> str:
        """获取平台充值页 URL。

        Returns:
            充值页面的完整 URL 字符串。
        """
        return self.top_up_url
