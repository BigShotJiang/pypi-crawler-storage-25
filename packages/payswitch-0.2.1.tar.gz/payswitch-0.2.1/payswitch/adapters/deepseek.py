"""DeepSeek 平台充值适配器。

封装 DeepSeek 开放平台（platform.deepseek.com）充值页的完整操作流程，
支持支付宝扫码支付。当页面结构发生变更导致选择器失效时，
会抛出 ScriptExecutionError，由上层引擎自动回退至 Skyvern 智能模式。
"""

from __future__ import annotations

import re
from typing import Any

from payswitch.adapters import AdapterRegistry
from payswitch.adapters.base import ScriptExecutionError, ScriptStep, SiteAdapter
from payswitch.models.types import PaymentMethod

# DeepSeek 平台预设充值套餐（人民币元），按从小到大排列
# 实际套餐以页面展示为准，此列表仅用于金额匹配优先级排序
_PRESET_AMOUNTS: list[float] = [10, 20, 50, 100, 200, 500, 1000, 2000]

# Playwright 操作默认超时（毫秒）
_TIMEOUT_MS = 15_000


def _find_closest_preset(amount: float) -> float:
    """从预设套餐中找到与目标金额最接近的面值。

    Args:
        amount: 用户期望的充值金额（人民币元）。

    Returns:
        与 amount 差值绝对值最小的预设金额；若差值相同，优先返回较大金额。
    """
    return min(_PRESET_AMOUNTS, key=lambda p: (abs(p - amount), -p))


@AdapterRegistry.register
class DeepSeekAdapter(SiteAdapter):
    """DeepSeek 开放平台充值适配器。

    支持通过支付宝扫码完成人民币充值。执行流程：
    1. 导航到充值页
    2. 选择预设套餐金额（优先精确匹配，次选最接近面值）
    3. 若无预设匹配，尝试填写自定义金额
    4. 选择支付宝支付方式
    5. 点击确认充值，等待二维码出现
    6. 返回 detect_payment 步骤，由检测器暂停并引导用户扫码

    选择器失效时抛出 ScriptExecutionError，触发 Skyvern 智能模式回退。
    """

    name = "deepseek"
    display_name = "DeepSeek"
    top_up_url = "https://platform.deepseek.com/top_up"
    login_url = "https://platform.deepseek.com/sign_in"
    supported_methods = [PaymentMethod.alipay_qr]

    async def validate_amount(self, amount: float) -> bool:
        """DeepSeek 最低充值金额为 10 元。"""
        return amount >= 10

    async def execute_topup(
        self,
        page: Any,
        amount: float,
        method: PaymentMethod | None = None,
    ) -> list[ScriptStep]:
        """执行 DeepSeek 充值完整脚本。

        Args:
            page: Playwright Page 对象。
            amount: 充值金额（人民币元，须 >= 10）。
            method: 指定支付方式；None 时默认使用支付宝扫码。

        Returns:
            按执行顺序排列的 ScriptStep 列表。

        Raises:
            ScriptExecutionError: 任意步骤无法定位元素或操作超时时抛出。
        """
        steps: list[ScriptStep] = []

        # ------------------------------------------------------------------
        # 步骤 1：导航到充值页
        # ------------------------------------------------------------------
        step = ScriptStep(
            description="导航到 DeepSeek 充值页面",
            action="navigate",
            url=self.top_up_url,
        )
        steps.append(step)
        try:
            await page.goto(self.top_up_url, wait_until="domcontentloaded", timeout=_TIMEOUT_MS)
            await page.wait_for_load_state("networkidle", timeout=_TIMEOUT_MS)
        except Exception as exc:
            raise ScriptExecutionError(f"导航充值页失败：{exc}") from exc

        # ------------------------------------------------------------------
        # 步骤 2：检测并处理登录态（若被重定向到登录页则报错）
        # ------------------------------------------------------------------
        current_url: str = page.url
        if "sign_in" in current_url or "login" in current_url:
            raise ScriptExecutionError(
                "检测到未登录状态，请先完成登录后重试。当前 URL：" + current_url
            )

        # ------------------------------------------------------------------
        # 步骤 3：选择充值金额（优先预设套餐，次选自定义输入）
        # ------------------------------------------------------------------
        amount_selected = await self._select_amount(page, amount, steps)
        if not amount_selected:
            # 预设套餐中无合适金额，尝试自定义输入
            await self._fill_custom_amount(page, amount, steps)

        # ------------------------------------------------------------------
        # 步骤 4：选择支付方式（支付宝）
        # ------------------------------------------------------------------
        await self._select_payment_method(page, steps)

        # ------------------------------------------------------------------
        # 步骤 5：点击确认充值按钮
        # ------------------------------------------------------------------
        await self._click_confirm(page, steps)

        # ------------------------------------------------------------------
        # 步骤 6：等待支付二维码出现，通知检测器暂停
        # ------------------------------------------------------------------
        await self._wait_for_qr(page, steps)

        return steps

    # ------------------------------------------------------------------
    # 私有辅助方法
    # ------------------------------------------------------------------

    async def _select_amount(
        self,
        page: Any,
        amount: float,
        steps: list[ScriptStep],
    ) -> bool:
        """尝试在预设套餐列表中点击匹配的金额按钮。

        先尝试精确匹配，再尝试最接近的预设面值。

        Returns:
            True 表示成功点击了某个预设按钮；False 表示未找到任何预设按钮。
        """
        # DeepSeek 充值页套餐金额按钮的候选选择器策略（按优先级排列）
        # 实际 DOM 结构基于对 React SPA 的合理推断，可能需要随版本调整
        amount_button_selectors = [
            # 策略 A：包含人民币符号和数字的按钮（最常见模式）
            f"button:has-text('¥{amount:.0f}')",
            f"button:has-text('¥ {amount:.0f}')",
            # 策略 B：通用套餐卡片，文本含金额数字
            f"[class*='amount']:has-text('{amount:.0f}')",
            f"[class*='package']:has-text('{amount:.0f}')",
            f"[class*='preset']:has-text('{amount:.0f}')",
            # 策略 C：data 属性匹配（部分站点用 data-amount）
            f"[data-amount='{amount:.0f}']",
            f"[data-value='{amount:.0f}']",
        ]

        # 尝试精确金额匹配
        for selector in amount_button_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if element:
                    step = ScriptStep(
                        description=f"点击预设套餐金额 ¥{amount:.0f}",
                        action="click",
                        selector=selector,
                    )
                    steps.append(step)
                    await element.click(timeout=_TIMEOUT_MS)
                    return True
            except Exception:
                # 选择器未命中，继续尝试下一个
                continue

        # 精确匹配失败，尝试最接近的预设金额
        closest = _find_closest_preset(amount)
        if closest != amount:
            closest_selectors = [
                f"button:has-text('¥{closest:.0f}')",
                f"button:has-text('¥ {closest:.0f}')",
                f"[class*='amount']:has-text('{closest:.0f}')",
                f"[class*='package']:has-text('{closest:.0f}')",
                f"[data-amount='{closest:.0f}']",
            ]
            for selector in closest_selectors:
                try:
                    element = await page.wait_for_selector(selector, timeout=3_000)
                    if element:
                        step = ScriptStep(
                            description=(
                                f"精确金额 ¥{amount:.0f} 无匹配套餐，"
                                f"改选最接近预设金额 ¥{closest:.0f}"
                            ),
                            action="click",
                            selector=selector,
                        )
                        steps.append(step)
                        await element.click(timeout=_TIMEOUT_MS)
                        return True
                except Exception:
                    continue

        return False

    async def _fill_custom_amount(
        self,
        page: Any,
        amount: float,
        steps: list[ScriptStep],
    ) -> None:
        """在自定义金额输入框中填写目标金额。

        Raises:
            ScriptExecutionError: 找不到自定义金额输入框时抛出。
        """
        # 自定义金额输入框的候选选择器
        custom_input_selectors = [
            "input[placeholder*='自定义']",
            "input[placeholder*='金额']",
            "input[placeholder*='请输入']",
            "input[type='number'][class*='amount']",
            "input[type='text'][class*='amount']",
            # 通用兜底：充值表单内的数字输入框
            "form input[type='number']",
        ]

        for selector in custom_input_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=3_000)
                if element:
                    # 先点击激活输入框，清空已有内容，再填入金额
                    await element.click(timeout=_TIMEOUT_MS)
                    await element.fill("", timeout=_TIMEOUT_MS)
                    amount_str = str(int(amount)) if amount == int(amount) else str(amount)
                    await element.fill(amount_str, timeout=_TIMEOUT_MS)

                    step = ScriptStep(
                        description=f"在自定义金额输入框中填写 {amount_str} 元",
                        action="fill",
                        selector=selector,
                        value=amount_str,
                    )
                    steps.append(step)
                    return
            except Exception:
                continue

        # 所有选择器均失败
        raise ScriptExecutionError(
            f"未找到预设套餐金额 ¥{amount:.0f} 的按钮，"
            "且自定义金额输入框也无法定位，"
            "页面结构可能已变更，触发 Skyvern 回退。"
        )

    async def _select_payment_method(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """选择支付宝支付方式。

        Raises:
            ScriptExecutionError: 找不到支付宝选项时抛出。
        """
        # 支付宝选项的候选选择器
        alipay_selectors = [
            # 文本匹配（最通用）
            "[class*='payment']:has-text('支付宝')",
            "[class*='method']:has-text('支付宝')",
            "button:has-text('支付宝')",
            "label:has-text('支付宝')",
            # 图标/logo 的 alt 或 aria-label
            "[aria-label*='支付宝']",
            "[alt='支付宝']",
            # data 属性
            "[data-method='alipay']",
            "[data-payment='alipay']",
            # 通用含 alipay 关键词的可点击元素
            "[class*='alipay']",
        ]

        for selector in alipay_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=4_000)
                if element:
                    step = ScriptStep(
                        description="选择支付宝扫码支付方式",
                        action="click",
                        selector=selector,
                    )
                    steps.append(step)
                    await element.click(timeout=_TIMEOUT_MS)
                    return
            except Exception:
                continue

        # 若支付方式只有支付宝一种（无需主动选择），静默跳过
        # 先检查页面是否已经默认展示了支付宝相关内容
        try:
            await page.wait_for_selector(
                "text=支付宝",
                timeout=2_000,
            )
            # 页面上存在"支付宝"文字说明已默认选中，记录步骤后返回
            steps.append(
                ScriptStep(
                    description="支付宝已为默认支付方式，无需主动选择",
                    action="wait",
                    selector="text=支付宝",
                )
            )
            return
        except Exception:
            pass

        raise ScriptExecutionError(
            "无法定位支付宝支付选项，页面结构可能已变更，触发 Skyvern 回退。"
        )

    async def _click_confirm(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """点击确认充值/去支付按钮。

        Raises:
            ScriptExecutionError: 找不到确认按钮时抛出。
        """
        # 确认充值按钮的候选选择器（中文文案优先）
        confirm_selectors = [
            "button:has-text('确认充值')",
            "button:has-text('去支付')",
            "button:has-text('立即支付')",
            "button:has-text('确认支付')",
            "button:has-text('充值')",
            "button:has-text('Pay')",
            "button:has-text('Confirm')",
            # 通用提交按钮
            "[type='submit']:has-text('充值')",
            "[class*='confirm']:has-text('充值')",
            "[class*='submit'][class*='pay']",
        ]

        for selector in confirm_selectors:
            try:
                element = await page.wait_for_selector(selector, timeout=4_000)
                if element:
                    # 等待按钮可点击（非 disabled 状态）
                    await element.wait_for_element_state("enabled", timeout=_TIMEOUT_MS)
                    step = ScriptStep(
                        description="点击确认充值按钮，触发支付流程",
                        action="click",
                        selector=selector,
                    )
                    steps.append(step)
                    await element.click(timeout=_TIMEOUT_MS)
                    return
            except Exception:
                continue

        raise ScriptExecutionError(
            "未找到充值确认按钮，页面结构可能已变更，触发 Skyvern 回退。"
        )

    async def _wait_for_qr(
        self,
        page: Any,
        steps: list[ScriptStep],
    ) -> None:
        """等待支付二维码出现，记录 detect_payment 步骤。

        二维码出现后，检测器将接管并暂停脚本，等待用户扫码。

        Raises:
            ScriptExecutionError: 超时后仍未检测到二维码时抛出。
        """
        # 支付二维码的候选选择器（canvas / img / svg 均有可能）
        qr_selectors = [
            # 二维码图片（src 或 class 含 qr/qrcode 关键词）
            "img[class*='qr']",
            "img[class*='qrcode']",
            "img[alt*='二维码']",
            "img[alt*='qr']",
            # Canvas 渲染的二维码（常见于 qrcode.js）
            "canvas[class*='qr']",
            "canvas[class*='qrcode']",
            # SVG 格式
            "svg[class*='qr']",
            # 包含二维码的容器
            "[class*='qrcode']",
            "[class*='qr-code']",
            "[class*='pay-qr']",
            # 通用弹窗/对话框（支付页面通常以弹窗形式展示）
            "[class*='modal']:has(img)",
            "[class*='dialog']:has(img)",
            "[class*='popup']:has(img)",
        ]

        qr_selector_found: str | None = None
        for selector in qr_selectors:
            try:
                await page.wait_for_selector(selector, timeout=8_000)
                qr_selector_found = selector
                break
            except Exception:
                continue

        if qr_selector_found is None:
            raise ScriptExecutionError(
                "等待支付二维码超时，未在页面上检测到二维码元素，"
                "触发 Skyvern 回退以智能定位二维码。"
            )

        # 记录 detect_payment 步骤，通知检测器接管
        steps.append(
            ScriptStep(
                description="检测到支付宝二维码，等待用户扫码完成支付",
                action="detect_payment",
                selector=qr_selector_found,
            )
        )
