"""NineEmail 商品购买适配器。

针对 https://www.nineemail.com/buy/14 的最小可用购买流程：
1. 打开商品页
2. 根据目标总金额推导购买数量
3. 填写邮箱和查询密码
4. 选择支付宝并提交订单
5. 进入确认页后点击“立即支付”
6. 等待支付宝二维码出现
"""

from __future__ import annotations

import math
import re
from datetime import datetime, timezone
from typing import Any

from payswitch.adapters import AdapterRegistry
from payswitch.adapters.base import ScriptExecutionError, ScriptStep, SiteAdapter
from payswitch.models.types import PaymentMethod

_TIMEOUT_MS = 15_000
_PRODUCT_URL = "https://www.nineemail.com/buy/14"


def _utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")


@AdapterRegistry.register
class NineEmailAdapter(SiteAdapter):
    """九邮商品 14 购买适配器。"""

    name = "nineemail"
    display_name = "NineEmail"
    top_up_url = _PRODUCT_URL
    login_url = _PRODUCT_URL
    supported_methods = [PaymentMethod.alipay_qr]

    async def execute_topup(
        self,
        page: Any,
        amount: float,
        method: PaymentMethod | None = None,
    ) -> list[ScriptStep]:
        if method not in (None, PaymentMethod.alipay_qr, PaymentMethod.auto):
            raise ScriptExecutionError("NineEmail 当前仅支持支付宝扫码支付")

        steps: list[ScriptStep] = []

        unit_price = await self._open_product_page(page, steps)
        quantity = self._derive_quantity(amount, unit_price)
        email = f"payswitch-test-{_utc_stamp()}@example.com"
        search_pwd = f"PgTest-{_utc_stamp()}"

        await self._fill_order_form(
            page=page,
            steps=steps,
            quantity=quantity,
            email=email,
            search_pwd=search_pwd,
        )
        await self._submit_order(page, steps)
        await self._click_pay_now(page, steps)
        await self._wait_for_qr(page, steps)

        return steps

    async def _open_product_page(self, page: Any, steps: list[ScriptStep]) -> float:
        step = ScriptStep(
            description="导航到 NineEmail 商品购买页",
            action="navigate",
            url=self.top_up_url,
        )
        steps.append(step)
        try:
            await page.goto(self.top_up_url, wait_until="domcontentloaded", timeout=_TIMEOUT_MS)
            await page.wait_for_load_state("networkidle", timeout=_TIMEOUT_MS)
        except Exception as exc:
            raise ScriptExecutionError(f"打开 NineEmail 商品页失败：{exc}") from exc

        page_text = await page.locator("body").inner_text(timeout=_TIMEOUT_MS)
        match = re.search(r"￥\s*([0-9]+(?:\.[0-9]+)?)", page_text)
        if match is None:
            raise ScriptExecutionError("无法从 NineEmail 页面解析商品单价")
        return float(match.group(1))

    def _derive_quantity(self, amount: float, unit_price: float) -> int:
        if unit_price <= 0:
            raise ScriptExecutionError(f"商品单价无效：{unit_price}")

        quantity = max(1, int(round(amount / unit_price)))
        expected_total = unit_price * quantity
        if not math.isclose(expected_total, amount, rel_tol=0.0, abs_tol=0.02):
            raise ScriptExecutionError(
                f"目标金额 ¥{amount:.2f} 无法稳定映射到商品数量（单价 ¥{unit_price:.2f}）"
            )
        return quantity

    async def _fill_order_form(
        self,
        page: Any,
        steps: list[ScriptStep],
        quantity: int,
        email: str,
        search_pwd: str,
    ) -> None:
        quantity_step = ScriptStep(
            description=f"填写购买数量 {quantity}",
            action="fill",
            selector="#orderNumber",
            value=str(quantity),
        )
        steps.append(quantity_step)
        await page.locator("#orderNumber").fill(str(quantity), timeout=_TIMEOUT_MS)

        email_step = ScriptStep(
            description=f"填写通知邮箱 {email}",
            action="fill",
            selector="input[name='email']",
            value=email,
        )
        steps.append(email_step)
        await page.locator("input[name='email']").fill(email, timeout=_TIMEOUT_MS)

        pwd_step = ScriptStep(
            description="填写查询密码",
            action="fill",
            selector="input[name='search_pwd']",
            value=search_pwd,
        )
        steps.append(pwd_step)
        await page.locator("input[name='search_pwd']").fill(search_pwd, timeout=_TIMEOUT_MS)

        alipay_step = ScriptStep(
            description="确认支付方式为支付宝",
            action="click",
            selector="text=支付宝",
        )
        steps.append(alipay_step)
        try:
            await page.locator("text=支付宝").first.click(timeout=3_000)
        except Exception:
            pass
        await page.locator("input[name='payway']").evaluate("el => el.value = '1'")

    async def _submit_order(self, page: Any, steps: list[ScriptStep]) -> None:
        step = ScriptStep(
            description="提交 NineEmail 订单",
            action="click",
            selector="text=下单",
        )
        steps.append(step)
        try:
            await page.get_by_role("button", name="下单").click(timeout=_TIMEOUT_MS)
            await page.wait_for_url("**/bill/**", timeout=_TIMEOUT_MS)
        except Exception as exc:
            raise ScriptExecutionError(f"提交订单失败：{exc}") from exc

    async def _click_pay_now(self, page: Any, steps: list[ScriptStep]) -> None:
        step = ScriptStep(
            description="在确认订单页点击立即支付",
            action="click",
            selector="text=立即支付",
        )
        steps.append(step)
        try:
            await page.get_by_text("立即支付", exact=True).click(timeout=_TIMEOUT_MS)
            await page.wait_for_url("**/pay/alipay/**", timeout=_TIMEOUT_MS)
        except Exception as exc:
            raise ScriptExecutionError(f"进入支付宝支付页失败：{exc}") from exc

    async def _wait_for_qr(self, page: Any, steps: list[ScriptStep]) -> None:
        step = ScriptStep(
            description="等待支付宝二维码出现",
            action="detect_payment",
        )
        steps.append(step)
        qr_selectors = [
            "img[src^='data:image/png;base64,']",
            "img[src*='base64']",
            "text=扫码支付",
        ]
        for selector in qr_selectors:
            try:
                await page.wait_for_selector(selector, timeout=5_000)
                return
            except Exception:
                continue
        raise ScriptExecutionError("未检测到 NineEmail 支付二维码")
