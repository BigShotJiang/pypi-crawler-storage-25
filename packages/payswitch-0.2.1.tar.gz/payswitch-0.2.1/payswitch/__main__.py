"""支持 python -m payswitch 方式调用 CLI。"""

from payswitch.cli import app

app()
