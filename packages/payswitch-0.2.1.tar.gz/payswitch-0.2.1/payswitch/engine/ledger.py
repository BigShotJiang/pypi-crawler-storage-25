"""Pay-Switch 交易账本模块。

基于 SQLite 实现 append-only 的交易记录管理。
采用 WAL 模式支持并发读写，复杂字段（steps/human_action）序列化为 JSON 存储。
"""

from __future__ import annotations

import csv
import json
import logging
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Generator, Optional

from payswitch.models.transaction import HumanAction, StepRecord, Transaction
from payswitch.models.types import TransactionStatus

logger = logging.getLogger(__name__)

# 默认数据库路径
_DEFAULT_DB_PATH = Path.home() / ".payswitch" / "payswitch.db"

# 建表 SQL
_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS transactions (
    tx_id           TEXT PRIMARY KEY,
    amount          REAL NOT NULL,
    currency        TEXT NOT NULL DEFAULT 'CNY',
    payee           TEXT NOT NULL,
    reason          TEXT NOT NULL DEFAULT '',
    payment_method  TEXT,
    execution_mode  TEXT,
    status          TEXT NOT NULL DEFAULT 'pending',
    idempotency_key TEXT,
    steps           TEXT NOT NULL DEFAULT '[]',
    human_action    TEXT,
    created_at      TEXT NOT NULL,
    completed_at    TEXT,
    error           TEXT
);
"""

# 用于快速查询的索引
_CREATE_INDEXES_SQL = [
    "CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status);",
    "CREATE INDEX IF NOT EXISTS idx_transactions_payee ON transactions(payee);",
    "CREATE INDEX IF NOT EXISTS idx_transactions_created_at ON transactions(created_at);",
    "CREATE INDEX IF NOT EXISTS idx_transactions_idempotency_key ON transactions(idempotency_key);",
]


def _dt_to_iso(dt: Optional[datetime]) -> Optional[str]:
    """将 datetime 对象序列化为 ISO 8601 字符串（UTC）。"""
    if dt is None:
        return None
    # 确保时区为 UTC
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.isoformat()


def _iso_to_dt(s: Optional[str]) -> Optional[datetime]:
    """将 ISO 8601 字符串反序列化为带时区的 datetime 对象。"""
    if s is None:
        return None
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _row_to_transaction(row: sqlite3.Row) -> Transaction:
    """将数据库行（sqlite3.Row）转换为 Transaction 对象。"""
    # 反序列化 JSON 字段
    steps_data: list[dict[str, Any]] = json.loads(row["steps"] or "[]")
    steps = [StepRecord.model_validate(s) for s in steps_data]

    human_action: Optional[HumanAction] = None
    if row["human_action"]:
        human_action = HumanAction.model_validate(json.loads(row["human_action"]))

    return Transaction(
        tx_id=row["tx_id"],
        amount=row["amount"],
        currency=row["currency"],
        payee=row["payee"],
        reason=row["reason"] or "",
        payment_method=row["payment_method"] or None,
        execution_mode=row["execution_mode"] or None,
        status=TransactionStatus(row["status"]),
        idempotency_key=row["idempotency_key"] or None,
        steps=steps,
        human_action=human_action,
        created_at=_iso_to_dt(row["created_at"]),  # type: ignore[arg-type]
        completed_at=_iso_to_dt(row["completed_at"]),
        error=row["error"] or None,
    )


def _transaction_to_row(tx: Transaction) -> dict[str, Any]:
    """将 Transaction 对象转换为适合插入数据库的字典。"""
    return {
        "tx_id": tx.tx_id,
        "amount": tx.amount,
        "currency": tx.currency,
        "payee": tx.payee,
        "reason": tx.reason,
        "payment_method": tx.payment_method.value if tx.payment_method else None,
        "execution_mode": tx.execution_mode.value if tx.execution_mode else None,
        "status": tx.status.value,
        "idempotency_key": tx.idempotency_key,
        "steps": json.dumps(
            [s.model_dump(mode="json") for s in tx.steps],
            ensure_ascii=False,
        ),
        "human_action": (
            json.dumps(tx.human_action.model_dump(mode="json"), ensure_ascii=False)
            if tx.human_action
            else None
        ),
        "created_at": _dt_to_iso(tx.created_at),
        "completed_at": _dt_to_iso(tx.completed_at),
        "error": tx.error,
    }


class Ledger:
    """交易账本——基于 SQLite 的 append-only 交易记录管理。

    设计原则：
    - 只允许 INSERT（record），不允许 DELETE
    - UPDATE 只允许修改状态相关字段（status / completed_at / error / steps / human_action）
    - 使用 WAL 模式支持读写并发
    - 所有时间字段统一存储为 UTC ISO 8601 字符串
    """

    def __init__(self, db_path: Path = _DEFAULT_DB_PATH) -> None:
        """初始化数据库连接，自动建表。

        Args:
            db_path: SQLite 数据库文件路径，默认 ~/.payswitch/payswitch.db
        """
        self._db_path = db_path
        # 确保父目录存在
        db_path.parent.mkdir(parents=True, exist_ok=True)

        self._conn = sqlite3.connect(
            str(db_path),
            check_same_thread=False,  # 允许多线程共享连接（配合外部锁使用）
            detect_types=sqlite3.PARSE_DECLTYPES,
        )
        self._conn.row_factory = sqlite3.Row  # 支持按列名访问

        # 启用 WAL 模式，提升并发读写性能
        self._conn.execute("PRAGMA journal_mode=WAL;")
        # 启用外键约束
        self._conn.execute("PRAGMA foreign_keys=ON;")
        # 适当的同步策略（WAL 下 NORMAL 即可保证数据安全）
        self._conn.execute("PRAGMA synchronous=NORMAL;")

        self._init_schema()
        logger.debug("账本数据库已初始化：%s", db_path)

    def _init_schema(self) -> None:
        """创建数据表和索引（幂等操作，使用 IF NOT EXISTS）。"""
        with self._transaction() as cur:
            cur.execute(_CREATE_TABLE_SQL)
            for idx_sql in _CREATE_INDEXES_SQL:
                cur.execute(idx_sql)

    @contextmanager
    def _transaction(self) -> Generator[sqlite3.Cursor, None, None]:
        """提供带自动提交/回滚的数据库事务上下文管理器。"""
        cur = self._conn.cursor()
        try:
            yield cur
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise
        finally:
            cur.close()

    # ------------------------------------------------------------------
    # 核心读写方法
    # ------------------------------------------------------------------

    def record(self, tx: Transaction) -> None:
        """插入一条交易记录（append-only，不允许删除）。

        Args:
            tx: 要记录的 Transaction 对象

        Raises:
            sqlite3.IntegrityError: 若 tx_id 已存在（主键冲突）
        """
        row = _transaction_to_row(tx)
        sql = """
            INSERT INTO transactions (
                tx_id, amount, currency, payee, reason,
                payment_method, execution_mode, status,
                idempotency_key, steps, human_action,
                created_at, completed_at, error
            ) VALUES (
                :tx_id, :amount, :currency, :payee, :reason,
                :payment_method, :execution_mode, :status,
                :idempotency_key, :steps, :human_action,
                :created_at, :completed_at, :error
            )
        """
        with self._transaction() as cur:
            cur.execute(sql, row)
        logger.info("交易已记录：%s（金额=%.2f %s，收款方=%s）",
                    tx.tx_id, tx.amount, tx.currency, tx.payee)

    def update_status(
        self,
        tx_id: str,
        status: TransactionStatus,
        *,
        completed_at: Optional[datetime] = None,
        error: Optional[str] = None,
        steps: Optional[list[StepRecord]] = None,
        human_action: Optional[HumanAction] = None,
    ) -> None:
        """更新交易状态及相关字段。

        只允许更新以下字段：status / completed_at / error / steps / human_action。
        不允许修改金额、收款方等核心字段（保持账本不可篡改性）。

        Args:
            tx_id: 交易 ID
            status: 新的交易状态
            completed_at: 完成时间（终态时传入）
            error: 错误信息（失败时传入）
            steps: 更新后的步骤列表
            human_action: 人类介入记录

        Raises:
            ValueError: 若交易不存在
        """
        # 构建动态 SET 子句（只更新传入的字段）
        updates: dict[str, Any] = {"status": status.value, "tx_id": tx_id}

        if completed_at is not None:
            updates["completed_at"] = _dt_to_iso(completed_at)
        if error is not None:
            updates["error"] = error
        if steps is not None:
            updates["steps"] = json.dumps(
                [s.model_dump(mode="json") for s in steps], ensure_ascii=False
            )
        if human_action is not None:
            updates["human_action"] = json.dumps(
                human_action.model_dump(mode="json"), ensure_ascii=False
            )

        # 构建 SET 子句（排除 tx_id，它是 WHERE 条件）
        set_fields = [k for k in updates if k != "tx_id"]
        set_clause = ", ".join(f"{f} = :{f}" for f in set_fields)

        sql = f"UPDATE transactions SET {set_clause} WHERE tx_id = :tx_id"

        with self._transaction() as cur:
            cur.execute(sql, updates)
            if cur.rowcount == 0:
                raise ValueError(f"交易不存在：{tx_id}")

        logger.debug("交易状态已更新：%s → %s", tx_id, status.value)

    def get(self, tx_id: str) -> Optional[Transaction]:
        """按 tx_id 查询单条交易记录。

        Args:
            tx_id: 交易 ID

        Returns:
            Transaction 对象，若不存在则返回 None
        """
        cur = self._conn.cursor()
        try:
            cur.execute(
                "SELECT * FROM transactions WHERE tx_id = ?", (tx_id,)
            )
            row = cur.fetchone()
            return _row_to_transaction(row) if row else None
        finally:
            cur.close()

    def check_idempotency(self, key: str) -> Optional[Transaction]:
        """检查幂等 key 在 48 小时内是否已存在对应交易。

        Args:
            key: 幂等键字符串

        Returns:
            已存在的 Transaction，若不存在或超过 48 小时则返回 None
        """
        cutoff = datetime.now(timezone.utc) - timedelta(hours=48)
        cutoff_iso = _dt_to_iso(cutoff)

        cur = self._conn.cursor()
        try:
            cur.execute(
                """
                SELECT * FROM transactions
                WHERE idempotency_key = ?
                  AND created_at >= ?
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (key, cutoff_iso),
            )
            row = cur.fetchone()
            return _row_to_transaction(row) if row else None
        finally:
            cur.close()

    def get_daily_total(self, target_date: Optional[date] = None) -> float:
        """获取指定日期的消费总额（仅统计 completed 状态的交易）。

        Args:
            target_date: 目标日期，默认为今天（本地时区）

        Returns:
            当日消费总额（元），若无记录则返回 0.0
        """
        if target_date is None:
            target_date = date.today()

        # 构建该日的 UTC 时间范围（以 ISO 前缀匹配，简化处理）
        date_prefix = target_date.isoformat()  # 如 "2025-01-15"

        cur = self._conn.cursor()
        try:
            cur.execute(
                """
                SELECT COALESCE(SUM(amount), 0.0) AS total
                FROM transactions
                WHERE status = 'completed'
                  AND date(created_at) = ?
                """,
                (date_prefix,),
            )
            row = cur.fetchone()
            return float(row["total"]) if row else 0.0
        finally:
            cur.close()

    def list_transactions(
        self,
        limit: int = 10,
        offset: int = 0,
        status: Optional[TransactionStatus] = None,
        payee: Optional[str] = None,
    ) -> list[Transaction]:
        """查询交易列表，支持按状态和收款方过滤。

        结果按 created_at 降序排列（最新在前）。

        Args:
            limit: 最多返回的记录数（默认 10）
            offset: 分页偏移量（默认 0）
            status: 按状态过滤，None 表示不过滤
            payee: 按收款方过滤，None 表示不过滤

        Returns:
            Transaction 列表
        """
        conditions: list[str] = []
        params: list[Any] = []

        if status is not None:
            conditions.append("status = ?")
            params.append(status.value)

        if payee is not None:
            conditions.append("payee = ?")
            params.append(payee)

        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        sql = f"""
            SELECT * FROM transactions
            {where_clause}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        """
        params.extend([limit, offset])

        cur = self._conn.cursor()
        try:
            cur.execute(sql, params)
            rows = cur.fetchall()
            return [_row_to_transaction(row) for row in rows]
        finally:
            cur.close()

    def export_csv(
        self,
        filepath: Path,
        status: Optional[TransactionStatus] = None,
        payee: Optional[str] = None,
    ) -> int:
        """将交易记录导出为 CSV 文件。

        Args:
            filepath: 导出文件路径
            status: 按状态过滤，None 表示导出全部
            payee: 按收款方过滤，None 表示不过滤

        Returns:
            实际导出的记录条数
        """
        # 不分页，导出全量匹配记录
        transactions = self.list_transactions(
            limit=999_999,
            offset=0,
            status=status,
            payee=payee,
        )

        if not transactions:
            logger.info("无匹配交易记录，跳过 CSV 导出")
            return 0

        # CSV 列定义（中英文列头）
        fieldnames = [
            "tx_id", "amount", "currency", "payee", "reason",
            "payment_method", "execution_mode", "status",
            "idempotency_key", "created_at", "completed_at", "error",
        ]

        filepath.parent.mkdir(parents=True, exist_ok=True)
        with filepath.open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for tx in transactions:
                writer.writerow({
                    "tx_id": tx.tx_id,
                    "amount": tx.amount,
                    "currency": tx.currency,
                    "payee": tx.payee,
                    "reason": tx.reason,
                    "payment_method": tx.payment_method.value if tx.payment_method else "",
                    "execution_mode": tx.execution_mode.value if tx.execution_mode else "",
                    "status": tx.status.value,
                    "idempotency_key": tx.idempotency_key or "",
                    "created_at": _dt_to_iso(tx.created_at) or "",
                    "completed_at": _dt_to_iso(tx.completed_at) or "",
                    "error": tx.error or "",
                })

        logger.info("已导出 %d 条交易记录到：%s", len(transactions), filepath)
        return len(transactions)

    def close(self) -> None:
        """关闭数据库连接，释放文件锁。"""
        try:
            self._conn.close()
            logger.debug("账本数据库连接已关闭：%s", self._db_path)
        except Exception as e:
            logger.warning("关闭数据库连接时发生错误：%s", e)

    def __enter__(self) -> "Ledger":
        """支持 with 语句使用。"""
        return self

    def __exit__(self, *args: object) -> None:
        """退出 with 语句时自动关闭连接。"""
        self.close()
