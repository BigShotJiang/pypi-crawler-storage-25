"""External-agent driven checkout runner.

The external runner is the concrete `computer_use_driver=external` path:
the caller supplies page decisions as structured actions, while Payswitch owns
the browser context, safety gates, payment-state detection, human gate, and
ledger updates.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field

from payswitch.browser.controller import BrowserController
from payswitch.browser.detector import DetectionResult, DetectorPipeline
from payswitch.browser.display import DisplayManager
from payswitch.browser.profiles import ProfileManager
from payswitch.engine.guard import SpendingGuard
from payswitch.engine.ledger import Ledger
from payswitch.engine.risk import RiskGate
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import HumanAction, StepRecord, Transaction
from payswitch.models.types import (
    DisplayMode,
    ExecutionMode,
    PaymentMethod,
    StepCategory,
    StepRisk,
    TransactionStatus,
)

logger = logging.getLogger(__name__)


class ExternalAction(BaseModel):
    """One bounded browser action proposed by an external agent."""

    type: Literal[
        "observe",
        "navigate",
        "fill",
        "set_value",
        "click_text",
        "click_index",
        "wait",
        "scan",
    ]
    description: str = ""
    url: str | None = None
    selector: str | None = None
    value: str | None = None
    text: str | None = None
    exact: bool = False
    index: int | None = None
    seconds: float = Field(default=1.0, ge=0.0, le=30.0)
    category: StepCategory = StepCategory.checkout_prep
    risk: StepRisk = StepRisk.low
    detect_after: bool = True


class ExternalCheckoutRunner:
    """Run an externally reasoned checkout inside Payswitch guardrails."""

    def __init__(self, config: PaySwitchConfig) -> None:
        self._config = config
        self._ledger = Ledger(config.data_dir / "payswitch.db")
        self._guard = SpendingGuard(config, self._ledger)
        self._profile_manager = ProfileManager(config.data_dir / "profiles")
        self._display_manager = DisplayManager(config.display_mode)
        self._detector_pipeline = DetectorPipeline()
        self._risk_gate = RiskGate(config)

    async def run(
        self,
        *,
        amount: float,
        payee: str,
        actions: list[ExternalAction],
        reason: str = "",
        method: PaymentMethod = PaymentMethod.auto,
        idempotency_key: str | None = None,
        stop_on_human: bool = False,
    ) -> Transaction:
        """Execute a caller-supplied external action plan."""
        guard_result = self._guard.check(
            amount=amount,
            payee=payee,
            idempotency_key=idempotency_key,
        )
        if guard_result.existing_tx is not None:
            return guard_result.existing_tx

        if not guard_result.allowed:
            now = datetime.now(timezone.utc)
            return Transaction(
                amount=amount,
                payee=payee,
                reason=reason,
                payment_method=method if method != PaymentMethod.auto else None,
                execution_mode=ExecutionMode.computer_use,
                status=TransactionStatus.failed,
                completed_at=now,
                error=guard_result.reason,
            )

        tx = Transaction(
            amount=amount,
            payee=payee,
            reason=reason,
            payment_method=method if method != PaymentMethod.auto else None,
            idempotency_key=idempotency_key,
            execution_mode=ExecutionMode.computer_use,
            status=TransactionStatus.pending,
        )
        self._ledger.record(tx)
        self._ledger.update_status(tx.tx_id, TransactionStatus.executing)
        tx = tx.model_copy(update={"status": TransactionStatus.executing})

        browser = BrowserController()
        try:
            await browser.launch(
                profile_dir=self._profile_dir(payee),
                headless=(self._display_manager.mode != DisplayMode.headed),
                **self._chrome_launch_kwargs(),
            )

            for action in actions:
                tx = await self._run_action(browser, tx, action)
                if not action.detect_after:
                    continue
                detection = await self._detector_pipeline.scan(browser.page)
                if detection is None:
                    continue

                if detection.action_type == "completed":
                    return self._complete(tx)

                if self._requires_human(detection):
                    return await self._handle_human_detection(
                        browser=browser,
                        detection=detection,
                        tx=tx,
                        stop_on_human=stop_on_human,
                    )

            return tx
        except Exception as exc:
            error = f"external checkout failed: {type(exc).__name__}: {exc}"
            logger.exception("External checkout failed for %s", tx.tx_id)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(timezone.utc),
                error=error,
                steps=tx.steps,
            )
            return tx.model_copy(
                update={
                    "status": TransactionStatus.failed,
                    "completed_at": datetime.now(timezone.utc),
                    "error": error,
                }
            )
        finally:
            await browser.close()

    async def _run_action(
        self,
        browser: BrowserController,
        tx: Transaction,
        action: ExternalAction,
    ) -> Transaction:
        decision = self._risk_gate.can_run_autonomously(
            category=action.category,
            risk=action.risk,
        )
        if not decision.allowed:
            raise RuntimeError(f"action blocked by RiskGate: {decision.reason}")

        now = datetime.now(timezone.utc)
        step = StepRecord(
            step_index=len(tx.steps),
            description=action.description or self._describe_action(action),
            status="pending",
            started_at=now,
            category=action.category,
            risk=action.risk,
        )
        tx = tx.model_copy(update={"steps": [*tx.steps, step]})
        self._ledger.update_status(tx.tx_id, TransactionStatus.executing, steps=tx.steps)

        await self._execute_action(browser, action)

        completed = step.model_copy(
            update={
                "status": "success",
                "completed_at": datetime.now(timezone.utc),
            }
        )
        tx = tx.model_copy(update={"steps": [*tx.steps[:-1], completed]})
        self._ledger.update_status(tx.tx_id, TransactionStatus.executing, steps=tx.steps)
        return tx

    async def _execute_action(
        self,
        browser: BrowserController,
        action: ExternalAction,
    ) -> Any:
        page = browser.page
        if action.type == "observe":
            return await browser.list_clickable_elements()
        if action.type == "navigate":
            if not action.url:
                raise ValueError("navigate action requires url")
            await browser.navigate(action.url)
            await self._settle(page)
            return None
        if action.type == "fill":
            if not action.selector or action.value is None:
                raise ValueError("fill action requires selector and value")
            await page.locator(action.selector).fill(action.value, timeout=15_000)
            return None
        if action.type == "set_value":
            if not action.selector or action.value is None:
                raise ValueError("set_value action requires selector and value")
            await page.locator(action.selector).evaluate(
                """(el, value) => {
                  el.value = value;
                  el.dispatchEvent(new Event('input', { bubbles: true }));
                  el.dispatchEvent(new Event('change', { bubbles: true }));
                }""",
                action.value,
            )
            return None
        if action.type == "click_text":
            if not action.text:
                raise ValueError("click_text action requires text")
            await browser.list_clickable_elements()
            await browser.click_clickable_text(action.text, exact=action.exact)
            await self._settle(page)
            return None
        if action.type == "click_index":
            if action.index is None:
                raise ValueError("click_index action requires index")
            await browser.list_clickable_elements()
            await browser.click_clickable_index(action.index)
            await self._settle(page)
            return None
        if action.type == "wait":
            await asyncio.sleep(action.seconds)
            return None
        if action.type == "scan":
            return None
        raise ValueError(f"unsupported external action: {action.type}")

    async def _settle(self, page: Any) -> None:
        try:
            await page.wait_for_load_state("networkidle", timeout=8_000)
        except Exception:
            pass

    def _complete(self, tx: Transaction) -> Transaction:
        now = datetime.now(timezone.utc)
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.completed,
            completed_at=now,
            steps=tx.steps,
        )
        return tx.model_copy(
            update={"status": TransactionStatus.completed, "completed_at": now}
        )

    async def _handle_human_detection(
        self,
        *,
        browser: BrowserController,
        detection: DetectionResult,
        tx: Transaction,
        stop_on_human: bool,
    ) -> Transaction:
        human_action = HumanAction(
            action_type=detection.action_type,
            requested_at=datetime.now(timezone.utc),
            display_mode=self._display_manager.mode,
            novnc_url=self._display_manager.get_display_info().get("url"),
        )
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            human_action=human_action,
            steps=tx.steps,
        )

        await self._display_manager.notify_human(
            message=detection.description,
            action_type=detection.action_type,
            details={
                **detection.data,
                "tx_id": tx.tx_id,
                "amount": f"¥{tx.amount:.2f}",
                "payee": tx.payee,
            },
        )

        if stop_on_human:
            return tx.model_copy(
                update={
                    "status": TransactionStatus.human_action_required,
                    "human_action": human_action,
                }
            )

        async def _completion_callback() -> bool:
            for detector in self._detector_pipeline._detectors:
                if detector.name == detection.detector_name:
                    return await detector.detect_completion(browser.page)
            return False

        success = await self._display_manager.wait_for_completion(
            detector_callback=_completion_callback,
            timeout=self._config.transaction_timeout,
        )
        if success:
            completed_action = human_action.model_copy(
                update={"completed_at": datetime.now(timezone.utc)}
            )
            completed_tx = self._complete(tx)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.completed,
                completed_at=completed_tx.completed_at,
                human_action=completed_action,
                steps=tx.steps,
            )
            return completed_tx.model_copy(update={"human_action": completed_action})

        now = datetime.now(timezone.utc)
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.timeout,
            completed_at=now,
            error="等待人工操作超时",
            human_action=human_action,
            steps=tx.steps,
        )
        return tx.model_copy(
            update={
                "status": TransactionStatus.timeout,
                "completed_at": now,
                "error": "等待人工操作超时",
                "human_action": human_action,
            }
        )

    def _requires_human(self, detection: DetectionResult) -> bool:
        for detector in self._detector_pipeline._detectors:
            if detector.name == detection.detector_name:
                return detector.requires_human()
        return True

    def _profile_dir(self, payee: str) -> Path | None:
        if self._uses_user_chrome_context():
            return None
        return self._profile_manager.get_profile_dir(payee)

    def _uses_user_chrome_context(self) -> bool:
        return bool(
            self._config.chrome_cdp_url.strip()
            or self._config.chrome_user_data_dir.strip()
        )

    def _chrome_launch_kwargs(self) -> dict[str, Any]:
        self._validate_user_chrome_identity()
        kwargs: dict[str, Any] = {}
        if self._config.chrome_cdp_url.strip():
            kwargs["chrome_cdp_url"] = self._config.chrome_cdp_url.strip()
        if self._config.chrome_user_data_dir.strip():
            kwargs["chrome_user_data_dir"] = Path(
                self._config.chrome_user_data_dir
            ).expanduser()
        if self._config.chrome_profile_directory.strip():
            kwargs["chrome_profile_directory"] = (
                self._config.chrome_profile_directory.strip()
            )
        if self._config.browser_channel.strip():
            kwargs["browser_channel"] = self._config.browser_channel.strip()
        return kwargs

    def _validate_user_chrome_identity(self) -> None:
        expected_email = self._config.chrome_expected_profile_email.strip()
        if not expected_email:
            return

        from payswitch.browser.chrome_profiles import (
            identity_matches_email,
            resolve_cdp_profile_identity,
            resolve_profile_identity,
        )

        identity = None
        if self._config.chrome_cdp_url.strip():
            identity = resolve_cdp_profile_identity(self._config.chrome_cdp_url.strip())
        elif self._config.chrome_user_data_dir.strip():
            identity = resolve_profile_identity(
                self._config.chrome_user_data_dir,
                self._config.chrome_profile_directory or "Default",
            )

        if identity_matches_email(identity, expected_email):
            return

        actual = "<unknown>"
        if identity is not None:
            actual = (
                f"{identity.user_name or '<empty>'} "
                f"({identity.profile_directory}, {identity.user_data_dir})"
            )
        raise RuntimeError(
            "Chrome profile identity mismatch: "
            f"expected {expected_email}, got {actual}. "
            "Refusing to continue to avoid spending from the wrong browser profile."
        )

    @staticmethod
    def _describe_action(action: ExternalAction) -> str:
        if action.type == "navigate":
            return f"外部 Agent 导航到 {action.url}"
        if action.type == "fill":
            return f"外部 Agent 填写 {action.selector}"
        if action.type == "set_value":
            return f"外部 Agent 设置 {action.selector}"
        if action.type == "click_text":
            return f"外部 Agent 点击文本 {action.text}"
        if action.type == "click_index":
            return f"外部 Agent 点击元素索引 {action.index}"
        if action.type == "wait":
            return f"外部 Agent 等待 {action.seconds:.1f}s"
        if action.type == "scan":
            return "外部 Agent 请求支付状态检测"
        return "外部 Agent 观察页面"

    def close(self) -> None:
        self._ledger.close()
