"""Pay-Switch 支付流程编排引擎。

PaymentOrchestrator 是整个系统的大脑，负责将所有子系统（守卫、账本、浏览器、
检测器、适配器）串联为完整的支付流程。

执行流程：
  guard.check → 幂等去重 → dry_run → 创建交易 → 加载 Profile → 启动浏览器
  → 脚本模式 or 智能模式 → 步骤检测 → 人类介入（按需）→ 完成 → 关闭浏览器
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from payswitch.adapters import AdapterRegistry, ScriptExecutionError
from payswitch.browser.controller import BrowserController
from payswitch.browser.detector import DetectionResult, DetectorPipeline
from payswitch.browser.display import DisplayManager
from payswitch.browser.profiles import ProfileManager
from payswitch.engine.guard import SpendingGuard
from payswitch.engine.ledger import Ledger
from payswitch.models.config import PaySwitchConfig
from payswitch.models.transaction import HumanAction, StepRecord, Transaction
from payswitch.models.types import ExecutionMode, PaymentMethod, TransactionStatus

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 自定义异常
# ---------------------------------------------------------------------------


class PaySwitchError(Exception):
    """Pay-Switch 通用异常。

    用于封装各子系统抛出的异常，统一对外接口。
    """


class SmartModeError(Exception):
    """智能模式执行失败异常。

    Task 17 实现 Skyvern 集成后，此异常将携带具体的失败原因。
    当前（桩实现阶段）在导航到目标 URL 后立即抛出，
    触发上层的人类接管逻辑。
    """


# ---------------------------------------------------------------------------
# 主类：PaymentOrchestrator
# ---------------------------------------------------------------------------


class PaymentOrchestrator:
    """支付流程编排引擎——Pay-Switch 的大脑。

    负责将 SpendingGuard、Ledger、BrowserController、ProfileManager、
    DisplayManager、DetectorPipeline 和各 SiteAdapter 串联为完整的支付流程。

    使用示例::

        config = PaySwitchConfig.load()
        orchestrator = PaymentOrchestrator(config)
        tx = await orchestrator.spend(amount=100.0, payee="deepseek")
        print(tx.status)  # completed / human_action_required / failed
        orchestrator.close()
    """

    def __init__(self, config: PaySwitchConfig) -> None:
        """初始化所有子系统。

        Args:
            config: Pay-Switch 全局配置，含限额、超时、路径等设置
        """
        self._config = config

        # 初始化账本（SQLite 持久化）
        db_path = config.data_dir / "payswitch.db"
        self._ledger = Ledger(db_path=db_path)
        logger.debug("账本已初始化：%s", db_path)

        # 初始化安全守卫（依赖 ledger 查询日累计额）
        self._guard = SpendingGuard(config=config, ledger=self._ledger)
        logger.debug("安全守卫已初始化")

        # 初始化 Profile 管理器（浏览器登录状态）
        profiles_dir = config.data_dir / "profiles"
        self._profile_manager = ProfileManager(data_dir=profiles_dir)
        logger.debug("Profile 管理器已初始化：%s", profiles_dir)

        # 初始化显示管理器（headed / noVNC 模式选择）
        self._display_manager = DisplayManager(mode=config.display_mode)
        logger.debug("显示管理器已初始化，模式：%s", self._display_manager.mode)

        # 初始化检测器流水线（按优先级：完成 → QR → 敏感表单 → 确认按钮）
        self._detector_pipeline = DetectorPipeline()
        logger.debug("检测器流水线已初始化")

    # ------------------------------------------------------------------
    # 核心公开接口
    # ------------------------------------------------------------------

    async def spend(
        self,
        amount: float,
        payee: str,
        reason: str = "",
        method: PaymentMethod = PaymentMethod.auto,
        idempotency_key: Optional[str] = None,
        url: Optional[str] = None,
        dry_run: bool = False,
    ) -> Transaction:
        """执行一次完整的支付编排流程。

        这是 Pay-Switch 的核心入口，调用方只需提供金额和收款方，
        编排引擎负责完成从安全检查到支付确认的全部流程。

        Args:
            amount:          支付金额（元，必须 > 0）
            payee:           收款方平台标识，如 deepseek / kimi
            reason:          支付原因（记录用，非必填）
            method:          指定支付方式，默认 auto（由适配器自选）
            idempotency_key: 幂等键，相同 key 在 48 小时内不重复支付
            url:             智能模式时的目标 URL（无适配器时必须提供）
            dry_run:         试运行模式，通过安全检查后不启动浏览器，直接返回模拟结果

        Returns:
            Transaction 对象，含最终状态（completed / failed / timeout 等）

        Raises:
            不抛出异常：所有错误均通过 Transaction.status 和 Transaction.error 反映
        """
        logger.info(
            "开始支付编排：payee=%s，amount=%.2f，method=%s，dry_run=%s",
            payee, amount, method, dry_run,
        )

        # ---- 第一步：安全检查（guard.check）----
        guard_result = self._guard.check(
            amount=amount,
            payee=payee,
            idempotency_key=idempotency_key,
        )

        # 安全检查未通过 → 构造被拒绝的交易记录并返回
        if not guard_result.allowed:
            logger.warning("安全检查拒绝：%s", guard_result.reason)
            rejected_tx = Transaction(
                amount=amount,
                payee=payee,
                reason=reason,
                payment_method=method,
                idempotency_key=idempotency_key,
                status=TransactionStatus.failed,
                completed_at=datetime.now(timezone.utc),
                error=guard_result.reason,
            )
            # 拒绝记录同样写入账本，保留审计痕迹
            self._ledger.record(rejected_tx)
            return rejected_tx

        # ---- 第二步：幂等命中 → 直接返回已有交易 ----
        if guard_result.existing_tx is not None:
            logger.info(
                "幂等命中，返回已有交易：%s", guard_result.existing_tx.tx_id
            )
            return guard_result.existing_tx

        # ---- 第三步：dry_run 模式 → 模拟结果，不启动浏览器 ----
        if dry_run:
            adapter = AdapterRegistry.get(payee)
            simulated_mode = ExecutionMode.script if adapter is not None else ExecutionMode.smart
            simulated_executor = (
                "支付脚本"
                if adapter is not None
                else "Computer Use 兜底探索"
            )
            # 显示将执行的操作摘要（让用户清楚 dry_run 会走哪些步骤）
            logger.info("========== dry_run 模式：以下为模拟执行计划 ==========")
            logger.info("[步骤 1/4] 安全检查（guard.check）：已通过")
            logger.info(
                "[步骤 2/4] 查找平台适配器：payee=%s（%s）",
                payee,
                "已注册适配器" if adapter is not None else "无适配器，将使用 Computer Use 兜底",
            )
            logger.info(
                "[步骤 3/4] 将启动浏览器并导航到充值页面，"
                "执行%s（amount=%.2f，method=%s）",
                simulated_executor,
                amount,
                method.value if method else "auto",
            )
            logger.info("[步骤 4/4] 等待支付确认（扫码 / 密码 / 点击确认）")
            logger.info("========== dry_run 模式结束：不启动浏览器，不执行实际支付 ==========")

            # 记录各模拟步骤，让 CLI 可以展示执行计划
            now = datetime.now(timezone.utc)
            sim_tx = Transaction(
                amount=amount,
                payee=payee,
                reason=reason,
                payment_method=method,
                idempotency_key=idempotency_key,
                execution_mode=simulated_mode,
                status=TransactionStatus.completed,
                completed_at=now,
                steps=[
                    StepRecord(
                        step_index=0,
                        description="[dry_run] 安全检查通过",
                        status="success",
                        started_at=now,
                        completed_at=now,
                    ),
                    StepRecord(
                        step_index=1,
                        description=(
                            f"[dry_run] 查找适配器：{payee} — "
                            + (
                                f"找到适配器 {adapter.__class__.__name__}"
                                if adapter is not None
                                else "无适配器，将使用 Computer Use 兜底"
                            )
                        ),
                        status="success",
                        started_at=now,
                        completed_at=now,
                    ),
                    StepRecord(
                        step_index=2,
                        description=(
                            f"[dry_run] 模拟{simulated_executor}"
                            f"（金额={amount:.2f}，方式={method.value if method else 'auto'}）"
                        ),
                        status="success",
                        started_at=now,
                        completed_at=now,
                    ),
                    StepRecord(
                        step_index=3,
                        description="[dry_run] 模拟支付完成确认",
                        status="success",
                        started_at=now,
                        completed_at=now,
                    ),
                ],
            )
            # dry_run 结果不写入账本（避免污染真实数据）
            return sim_tx

        # ---- 第四步：创建正式交易记录 ----
        tx = Transaction(
            amount=amount,
            payee=payee,
            reason=reason,
            payment_method=method if method != PaymentMethod.auto else None,
            idempotency_key=idempotency_key,
            status=TransactionStatus.pending,
        )
        self._ledger.record(tx)
        logger.info("交易已创建：%s", tx.tx_id)

        # ---- Stripe 特殊分支：不需要浏览器，直接调用 API ----
        if method == PaymentMethod.stripe:
            logger.info("检测到 Stripe 支付方式，走 API 分支（无需浏览器）")
            try:
                tx = await self._execute_stripe_mode(
                    tx=tx,
                    amount=amount,
                    method=method,
                )
                return tx
            except Exception as exc:
                error_msg = f"Stripe 支付失败：{type(exc).__name__}: {exc}"
                logger.exception("Stripe 支付执行异常")
                self._ledger.update_status(
                    tx.tx_id,
                    TransactionStatus.failed,
                    completed_at=datetime.now(timezone.utc),
                    error=error_msg,
                    steps=tx.steps,
                )
                return tx.model_copy(
                    update={
                        "status": TransactionStatus.failed,
                        "completed_at": datetime.now(timezone.utc),
                        "error": error_msg,
                    }
                )

        # ---- 第五步：加载浏览器上下文 ----
        # 默认使用 Pay-Switch 自管 profile；若配置了用户 Chrome/CDP，则使用用户
        # 指定的真实 Chrome 上下文，不再强制要求 ~/.payswitch/profiles 下存在同名 profile。
        uses_user_chrome = self._uses_user_chrome_context()
        profile = self._profile_manager.get_profile(payee)
        if profile is None and not uses_user_chrome:
            # Profile 不存在：可能用户从未登录过该平台
            error_msg = (
                f"平台 '{payee}' 的 Profile 不存在，"
                f"请先执行 'payswitch login {payee}' 完成登录"
            )
            logger.error(error_msg)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(timezone.utc),
                error=error_msg,
            )
            return tx.model_copy(
                update={
                    "status": TransactionStatus.failed,
                    "completed_at": datetime.now(timezone.utc),
                    "error": error_msg,
                }
            )

        profile_dir: Path | None = None
        if uses_user_chrome:
            logger.info(
                "使用用户 Chrome 上下文执行：cdp=%s user_data_dir=%s profile=%s",
                self._config.chrome_cdp_url or "<未设置>",
                self._config.chrome_user_data_dir or "<未设置>",
                self._config.chrome_profile_directory or "<default>",
            )
        else:
            profile_dir = self._profile_manager.get_profile_dir(payee)
            logger.info("已加载 Pay-Switch 自管 Profile：%s（目录=%s）", payee, profile_dir)

        # ---- 第六步：启动浏览器 ----
        browser = BrowserController()
        try:
            # 判断是否需要有头模式（headed = 用户能看到浏览器窗口）
            from payswitch.models.types import DisplayMode
            headless = (self._display_manager.mode != DisplayMode.headed)
            await browser.launch(
                profile_dir=profile_dir,
                headless=headless,
                **self._chrome_launch_kwargs(),
            )
            logger.info("浏览器已启动（headless=%s）", headless)

            # 更新交易状态为执行中
            self._ledger.update_status(tx.tx_id, TransactionStatus.executing)
            tx = tx.model_copy(update={"status": TransactionStatus.executing})

            # ---- 第七步：执行支付脚本 ----
            adapter = AdapterRegistry.get(payee)

            if adapter is not None:
                # --- 脚本模式 ---
                logger.info("找到适配器 %s，使用脚本模式", adapter.__class__.__name__)
                tx = tx.model_copy(update={"execution_mode": ExecutionMode.script})
                try:
                    tx = await self._execute_script_mode(
                        adapter=adapter,
                        browser=browser,
                        tx=tx,
                        amount=amount,
                        method=method,
                    )
                except ScriptExecutionError as exc:
                    # 脚本模式失败 → 尝试回退到智能模式
                    logger.warning(
                        "脚本模式失败（%s），尝试回退到智能模式", exc
                    )
                    # 记录脚本失败步骤
                    fail_step = StepRecord(
                        step_index=len(tx.steps),
                        description=f"脚本模式失败，准备回退到智能模式：{exc}",
                        status="failed",
                        started_at=datetime.now(timezone.utc),
                        completed_at=datetime.now(timezone.utc),
                    )
                    tx = tx.model_copy(update={"steps": [*tx.steps, fail_step]})

                    # 确定智能模式所用 URL：优先 url 参数，其次适配器的 top_up_url
                    smart_url = url or adapter.top_up_url
                    try:
                        tx = await self._execute_smart_mode(
                            browser=browser,
                            tx=tx,
                            amount=amount,
                            payee=payee,
                            method=method,
                            url=smart_url,
                        )
                    except SmartModeError as smart_exc:
                        # 智能模式也失败 → 人类接管
                        logger.warning(
                            "智能模式失败（%s），切换到人类接管模式", smart_exc
                        )
                        await self._prepare_handoff_page(browser, smart_url)
                        tx = await self._human_takeover(browser=browser, tx=tx)

            elif url is not None:
                # --- 无适配器 + 有 url → 智能模式 ---
                logger.info(
                    "未找到适配器，使用智能模式，目标 URL=%s", url
                )
                tx = tx.model_copy(update={"execution_mode": ExecutionMode.smart})
                try:
                    tx = await self._execute_smart_mode(
                        browser=browser,
                        tx=tx,
                        amount=amount,
                        payee=payee,
                        method=method,
                        url=url,
                    )
                except SmartModeError as smart_exc:
                    logger.warning(
                        "智能模式失败（%s），切换到人类接管模式", smart_exc
                    )
                    await self._prepare_handoff_page(browser, url)
                    tx = await self._human_takeover(browser=browser, tx=tx)

            else:
                # --- 无适配器 无 url → 报错 ---
                error_msg = (
                    f"平台 '{payee}' 未找到适配器，且未提供 url 参数，"
                    f"无法执行支付。请注册适配器或通过 --url 参数指定充值页面。"
                )
                logger.error(error_msg)
                self._ledger.update_status(
                    tx.tx_id,
                    TransactionStatus.failed,
                    completed_at=datetime.now(timezone.utc),
                    error=error_msg,
                    steps=tx.steps,
                )
                return tx.model_copy(
                    update={
                        "status": TransactionStatus.failed,
                        "completed_at": datetime.now(timezone.utc),
                        "error": error_msg,
                    }
                )

        except asyncio.TimeoutError:
            # 全局超时处理
            timeout_msg = f"交易超时（>{self._config.transaction_timeout}s）"
            logger.error("交易 %s 超时", tx.tx_id)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.timeout,
                completed_at=datetime.now(timezone.utc),
                error=timeout_msg,
                steps=tx.steps,
            )
            tx = tx.model_copy(
                update={
                    "status": TransactionStatus.timeout,
                    "completed_at": datetime.now(timezone.utc),
                    "error": timeout_msg,
                }
            )

        except Exception as exc:
            # 其他未预期异常 → 标记为 failed
            error_msg = f"支付流程异常终止：{type(exc).__name__}: {exc}"
            logger.exception("交易 %s 执行时发生未预期异常", tx.tx_id)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(timezone.utc),
                error=error_msg,
                steps=tx.steps,
            )
            tx = tx.model_copy(
                update={
                    "status": TransactionStatus.failed,
                    "completed_at": datetime.now(timezone.utc),
                    "error": error_msg,
                }
            )

        finally:
            # 无论成功失败，浏览器都必须关闭（防止资源泄露）
            logger.info("关闭浏览器（交易 %s）", tx.tx_id)
            await browser.close()

        logger.info(
            "支付编排完成：tx_id=%s，status=%s", tx.tx_id, tx.status
        )
        return tx

    def _uses_user_chrome_context(self) -> bool:
        """Return whether execution should use the user's real Chrome context."""
        return bool(
            self._config.chrome_cdp_url.strip()
            or self._config.chrome_user_data_dir.strip()
        )

    async def _prepare_handoff_page(
        self,
        browser: BrowserController,
        url: str | None,
    ) -> None:
        """Navigate to the best known checkout URL before human takeover."""
        if not url:
            return
        try:
            logger.info("人类接管前导航到候选页面：%s", url)
            await browser.navigate(url)
        except Exception as exc:
            logger.warning("人类接管前导航失败，保留当前页面：%s", exc)

    def _chrome_launch_kwargs(self) -> dict:
        """Build BrowserController kwargs for real Chrome/CDP execution."""
        self._validate_user_chrome_identity()
        kwargs: dict = {}
        if self._config.chrome_cdp_url.strip():
            kwargs["chrome_cdp_url"] = self._config.chrome_cdp_url.strip()
        if self._config.chrome_user_data_dir.strip():
            kwargs["chrome_user_data_dir"] = Path(
                self._config.chrome_user_data_dir
            ).expanduser()
        if self._config.chrome_profile_directory.strip():
            kwargs["chrome_profile_directory"] = (
                self._config.chrome_profile_directory.strip()
            )
        if self._config.browser_channel.strip():
            kwargs["browser_channel"] = self._config.browser_channel.strip()
        return kwargs

    def _validate_user_chrome_identity(self) -> None:
        """Fail closed when configured Chrome identity does not match."""
        expected_email = self._config.chrome_expected_profile_email.strip()
        if not expected_email:
            return

        from payswitch.browser.chrome_profiles import (
            identity_matches_email,
            resolve_cdp_profile_identity,
            resolve_profile_identity,
        )

        identity = None
        if self._config.chrome_cdp_url.strip():
            identity = resolve_cdp_profile_identity(self._config.chrome_cdp_url.strip())
        elif self._config.chrome_user_data_dir.strip():
            identity = resolve_profile_identity(
                self._config.chrome_user_data_dir,
                self._config.chrome_profile_directory or "Default",
            )

        if identity_matches_email(identity, expected_email):
            return

        actual = "<unknown>"
        if identity is not None:
            actual = (
                f"{identity.user_name or '<empty>'} "
                f"({identity.profile_directory}, {identity.user_data_dir})"
            )
        raise RuntimeError(
            "Chrome profile identity mismatch: "
            f"expected {expected_email}, got {actual}. "
            "Refusing to continue to avoid spending from the wrong browser profile."
        )

    # ------------------------------------------------------------------
    # 脚本模式执行
    # ------------------------------------------------------------------

    async def _execute_script_mode(
        self,
        adapter,
        browser: BrowserController,
        tx: Transaction,
        amount: float,
        method: PaymentMethod,
    ) -> Transaction:
        """脚本模式执行：调用适配器的 execute_topup，逐步处理支付环节。

        Args:
            adapter:  已实例化的 SiteAdapter 子类
            browser:  已启动的 BrowserController
            tx:       当前交易对象
            amount:   支付金额
            method:   支付方式

        Returns:
            更新后的 Transaction 对象

        Raises:
            ScriptExecutionError: 适配器内部失败，上层捕获后回退智能模式
        """
        logger.info(
            "脚本模式启动：adapter=%s，amount=%.2f", adapter.__class__.__name__, amount
        )

        # 记录脚本模式开始步骤
        start_step = StepRecord(
            step_index=len(tx.steps),
            description=f"脚本模式启动（适配器：{adapter.__class__.__name__}）",
            status="success",
            started_at=datetime.now(timezone.utc),
            completed_at=datetime.now(timezone.utc),
        )
        tx = tx.model_copy(
            update={
                "execution_mode": ExecutionMode.script,
                "steps": [*tx.steps, start_step],
            }
        )
        self._ledger.update_status(
            tx.tx_id, TransactionStatus.executing, steps=tx.steps
        )

        # 调用适配器执行充值脚本
        # ScriptExecutionError 不在此处捕获，交由 spend() 的外层处理
        script_steps: list = await adapter.execute_topup(
            page=browser.page,
            amount=amount,
            method=method if method != PaymentMethod.auto else None,
        )
        logger.info("适配器脚本执行完毕，共 %d 个步骤", len(script_steps))

        # 将适配器返回的 ScriptStep 列表转换为 StepRecord 并追加到交易
        for i, script_step in enumerate(script_steps):
            step_record = StepRecord(
                step_index=len(tx.steps),
                description=script_step.description,
                status="success",
                started_at=datetime.now(timezone.utc),
                completed_at=datetime.now(timezone.utc),
            )
            tx = tx.model_copy(update={"steps": [*tx.steps, step_record]})

            # 每个步骤后实时更新账本
            self._ledger.update_status(
                tx.tx_id, TransactionStatus.executing, steps=tx.steps
            )

            # ---- 第八步：每个步骤后运行检测器流水线 ----
            detection = await self._detector_pipeline.scan(browser.page)

            if detection is not None:
                logger.info(
                    "检测器命中：%s（action_type=%s）",
                    detection.detector_name, detection.action_type,
                )

                # 检测到支付已完成 → 直接标记成功
                if detection.action_type == "completed":
                    logger.info("检测到支付完成状态，标记交易成功")
                    now = datetime.now(timezone.utc)
                    self._ledger.update_status(
                        tx.tx_id,
                        TransactionStatus.completed,
                        completed_at=now,
                        steps=tx.steps,
                    )
                    return tx.model_copy(
                        update={
                            "status": TransactionStatus.completed,
                            "completed_at": now,
                        }
                    )

                # ---- 第九步：检测到需要人类介入的支付环节 ----
                if self._requires_human(detection):
                    logger.info(
                        "检测到需要人类介入：%s", detection.action_type
                    )
                    # ---- 第十步：等待人类完成 ----
                    human_success = await self._handle_human_interaction(
                        browser=browser,
                        detection=detection,
                        tx=tx,
                    )

                    # 从账本重新加载最新状态（_handle_human_interaction 已更新）
                    refreshed = self._ledger.get(tx.tx_id)
                    if refreshed is not None:
                        tx = refreshed

                    if human_success:
                        logger.info("人类操作完成，检测支付结果")
                        # 再次扫描，确认支付完成
                        final_detection = await self._detector_pipeline.scan(
                            browser.page
                        )
                        if (
                            final_detection is not None
                            and final_detection.action_type == "completed"
                        ):
                            now = datetime.now(timezone.utc)
                            self._ledger.update_status(
                                tx.tx_id,
                                TransactionStatus.completed,
                                completed_at=now,
                                steps=tx.steps,
                            )
                            return tx.model_copy(
                                update={
                                    "status": TransactionStatus.completed,
                                    "completed_at": now,
                                }
                            )
                        else:
                            # 人类操作完成但未检测到明确的完成状态
                            # 根据 guard 配置决定是否自动确认
                            logger.info(
                                "人类操作已完成，未检测到明确完成状态，"
                                "视为完成（用户手动确认）"
                            )
                            now = datetime.now(timezone.utc)
                            self._ledger.update_status(
                                tx.tx_id,
                                TransactionStatus.completed,
                                completed_at=now,
                                steps=tx.steps,
                            )
                            return tx.model_copy(
                                update={
                                    "status": TransactionStatus.completed,
                                    "completed_at": now,
                                }
                            )
                    else:
                        # 人类操作超时
                        timeout_msg = "等待人类操作超时"
                        logger.warning("交易 %s：%s", tx.tx_id, timeout_msg)
                        self._ledger.update_status(
                            tx.tx_id,
                            TransactionStatus.timeout,
                            completed_at=datetime.now(timezone.utc),
                            error=timeout_msg,
                            steps=tx.steps,
                        )
                        return tx.model_copy(
                            update={
                                "status": TransactionStatus.timeout,
                                "completed_at": datetime.now(timezone.utc),
                                "error": timeout_msg,
                            }
                        )

        # 所有脚本步骤执行完毕，最终检测一次
        final_detection = await self._detector_pipeline.scan(browser.page)
        if final_detection is not None and final_detection.action_type == "completed":
            now = datetime.now(timezone.utc)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.completed,
                completed_at=now,
                steps=tx.steps,
            )
            return tx.model_copy(
                update={
                    "status": TransactionStatus.completed,
                    "completed_at": now,
                }
            )

        # 脚本执行完毕但状态不明确：保持 executing，由 spend() 上层处理
        logger.info("脚本模式执行完毕，当前状态待最终确认")
        return tx

    # ------------------------------------------------------------------
    # Computer Use 智能探索（内部复用 SkyvernEngine）
    # ------------------------------------------------------------------

    async def _execute_smart_mode(
        self,
        browser: BrowserController,
        tx: Transaction,
        amount: float,
        payee: str,
        method: PaymentMethod,
        url: Optional[str],
    ) -> Transaction:
        """Computer Use 兜底探索（内部复用 SkyvernEngine）。

        使用受控 ComputerUseExplorer 替代固定选择器脚本，
        通过模型视觉能力探索未知/变更站点的 checkout 路径。
        该模式只应推进到支付前或人类接管点，不应自主完成最终付款。

        执行流程：
        1. 检查 ComputerUseExplorer 是否可用（LLM 已配置且 openai 已安装）
        2. 构建受控探索任务
        3. 调用 ComputerUseExplorer.explore_checkout() 执行任务
        4. 将 Computer Use 返回的步骤合并到交易记录
        5. 执行最终检测，确认支付状态

        Args:
            browser: 已启动的 BrowserController
            tx:      当前交易对象
            amount:  支付金额
            payee:   收款方平台标识
            method:  期望支付方式
            url:     智能模式目标 URL（无适配器时必须提供）

        Returns:
            更新后的 Transaction 对象

        Raises:
            SmartModeError: Computer Use 不可用或探索失败
        """
        from payswitch.browser.computer_use import ComputerUseExplorer

        logger.info(
            "Computer Use 兜底探索启动：url=%s，amount=%.2f，payee=%s",
            url, amount, payee,
        )

        # ---- 检查 Computer Use 是否可用 ----
        explorer = ComputerUseExplorer(self._config)
        if not explorer.is_available():
            raise SmartModeError(
                "Computer Use 兜底探索不可用：LLM 未配置、openai 未安装或 computer_use 已关闭。"
                "请在配置文件中设置 llm.api_key，"
                "并安装智能模式依赖：uv pip install 'payswitch[smart]'"
            )

        # ---- 记录 Computer Use 启动步骤 ----
        smart_start_step = StepRecord(
            step_index=len(tx.steps),
            description=f"Computer Use 兜底探索启动（SkyvernEngine 驱动），目标：{url}",
            status="pending",
            started_at=datetime.now(timezone.utc),
        )
        tx = tx.model_copy(
            update={
                "execution_mode": ExecutionMode.smart,
                "steps": [*tx.steps, smart_start_step],
            }
        )
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.executing,
            steps=tx.steps,
        )

        # ---- 调用 Computer Use 执行受控探索 ----
        try:
            computer_use_steps = await explorer.explore_checkout(
                page=browser.page,
                payee=payee,
                amount=amount,
                method=(method.value if method else PaymentMethod.auto.value),
                url=url,
            )
        except Exception as exc:
            # Computer Use 执行失败：更新启动步骤状态，抛出 SmartModeError
            logger.warning("Computer Use 探索失败：%s", exc)
            failed_start_step = smart_start_step.model_copy(
                update={
                    "status": "failed",
                    "completed_at": datetime.now(timezone.utc),
                }
            )
            tx = tx.model_copy(
                update={"steps": [*tx.steps[:-1], failed_start_step]}
            )
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.executing,
                steps=tx.steps,
            )
            raise SmartModeError(
                f"Computer Use 探索失败：{type(exc).__name__}: {exc}"
            ) from exc

        # ---- 将 Computer Use 返回的步骤合并到交易记录 ----
        # 先将启动步骤标记为成功
        success_start_step = smart_start_step.model_copy(
            update={
                "status": "success",
                "completed_at": datetime.now(timezone.utc),
            }
        )
        tx = tx.model_copy(
            update={"steps": [*tx.steps[:-1], success_start_step]}
        )

        # 追加 Computer Use 各执行步骤
        for computer_use_step in computer_use_steps:
            # 重新编号 step_index 以保持连续性
            indexed_step = computer_use_step.model_copy(
                update={"step_index": len(tx.steps)}
            )
            tx = tx.model_copy(update={"steps": [*tx.steps, indexed_step]})

            # 实时同步账本（每步更新，便于监控进度）
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.executing,
                steps=tx.steps,
            )

        logger.info(
            "Computer Use 探索完毕，共 %d 个步骤", len(computer_use_steps)
        )

        # ---- 最终检测：确认支付状态 ----
        final_detection = await self._detector_pipeline.scan(browser.page)
        if final_detection is not None and final_detection.action_type == "completed":
            # 检测到支付成功完成
            now = datetime.now(timezone.utc)
            logger.info("Computer Use：检测到支付完成状态")
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.completed,
                completed_at=now,
                steps=tx.steps,
            )
            return tx.model_copy(
                update={
                    "status": TransactionStatus.completed,
                    "completed_at": now,
                }
            )

        if final_detection is not None and self._requires_human(final_detection):
            # 检测到需要人类介入（如支付宝二维码等待扫码）
            logger.info(
                "Computer Use：检测到需要人类介入（%s），移交人类处理",
                final_detection.action_type,
            )
            human_success = await self._handle_human_interaction(
                browser=browser,
                detection=final_detection,
                tx=tx,
            )

            # 重新加载交易（_handle_human_interaction 已更新账本）
            refreshed = self._ledger.get(tx.tx_id)
            if refreshed is not None:
                tx = refreshed

            if human_success:
                now = datetime.now(timezone.utc)
                self._ledger.update_status(
                    tx.tx_id,
                    TransactionStatus.completed,
                    completed_at=now,
                    steps=tx.steps,
                )
                return tx.model_copy(
                    update={
                        "status": TransactionStatus.completed,
                        "completed_at": now,
                    }
                )
            else:
                # 等待人类操作超时
                timeout_msg = "Computer Use：等待人类操作超时"
                logger.warning(timeout_msg)
                raise SmartModeError(timeout_msg)

        # Computer Use 执行完毕，但状态未明确（交由上层处理）
        logger.info("Computer Use 探索完毕，当前状态待最终确认")
        return tx

    # ------------------------------------------------------------------
    # Stripe API 模式（无需浏览器）
    # ------------------------------------------------------------------

    async def _execute_stripe_mode(
        self,
        tx: Transaction,
        amount: float,
        method: PaymentMethod,
    ) -> Transaction:
        """执行 Stripe API 支付流程（无需浏览器自动化）。

        Stripe 与其他浏览器自动化适配器不同，它直接调用 Stripe REST API 创建 hosted checkout session，
        用户通过返回的 URL 或二维码完成支付，webhook 监听器负责更新交易状态。

        执行流程：
        1. 获取 StripeAdapter 实例
        2. 调用 adapter.execute_topup 创建 checkout session
        3. 从返回的 steps 提取 checkout URL
        4. 更新交易状态为 human_action_required
        5. 通过 display_manager 通知用户（输出 URL 和二维码）
        6. 返回交易（状态为 human_action_required，webhook 将异步更新状态）

        Args:
            tx: 当前交易对象
            amount: 支付金额
            method: 支付方式（应为 PaymentMethod.stripe）

        Returns:
            更新后的 Transaction 对象（状态为 human_action_required）

        Raises:
            ScriptExecutionError: Stripe API 调用失败
        """
        logger.info(
            "Stripe API 模式启动：amount=%.2f, method=%s",
            amount, method
        )

        # 记录 Stripe 模式启动步骤
        start_step = StepRecord(
            step_index=len(tx.steps),
            description="Stripe API 模式启动（无需浏览器）",
            status="success",
            started_at=datetime.now(timezone.utc),
            completed_at=datetime.now(timezone.utc),
        )
        tx = tx.model_copy(
            update={
                "execution_mode": ExecutionMode.script,  # Stripe 也算脚本模式（确定性 API 调用）
                "steps": [*tx.steps, start_step],
            }
        )
        self._ledger.update_status(
            tx.tx_id, TransactionStatus.executing, steps=tx.steps
        )

        # 获取 StripeAdapter
        adapter = AdapterRegistry.get("stripe")
        if adapter is None:
            raise ScriptExecutionError(
                "Stripe 适配器未注册。请确保已安装 payswitch[stripe] 依赖。"
            )

        # 调用 adapter 创建 checkout session（不需要 page 参数）
        try:
            # 从配置读取默认货币
            currency = self._config.stripe_default_currency or "usd"
            product_name = tx.reason or f"Pay-Switch 支付 - {amount} {currency.upper()}"

            script_steps = await adapter.execute_topup(
                page=None,  # Stripe 不需要浏览器
                amount=amount,
                method=method,
                currency=currency,
                product_name=product_name,
                tx_id=tx.tx_id,  # 传递交易 ID，用于 webhook 关联
            )
            logger.info("Stripe checkout session 已创建，共 %d 个步骤", len(script_steps))
        except ScriptExecutionError as exc:
            # Stripe API 调用失败
            logger.error("Stripe API 调用失败：%s", exc)
            fail_step = StepRecord(
                step_index=len(tx.steps),
                description=f"Stripe API 调用失败：{exc}",
                status="failed",
                started_at=datetime.now(timezone.utc),
                completed_at=datetime.now(timezone.utc),
            )
            tx = tx.model_copy(update={"steps": [*tx.steps, fail_step]})
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(timezone.utc),
                error=str(exc),
                steps=tx.steps,
            )
            return tx.model_copy(
                update={
                    "status": TransactionStatus.failed,
                    "completed_at": datetime.now(timezone.utc),
                    "error": str(exc),
                }
            )

        # 将 adapter 返回的步骤追加到交易记录
        for script_step in script_steps:
            step_record = StepRecord(
                step_index=len(tx.steps),
                description=script_step.description,
                status="success",
                started_at=datetime.now(timezone.utc),
                completed_at=datetime.now(timezone.utc),
            )
            tx = tx.model_copy(update={"steps": [*tx.steps, step_record]})

        # 提取 checkout URL（从 steps 中查找 action="payment_url_ready" 的步骤）
        checkout_url: Optional[str] = None
        for script_step in script_steps:
            if script_step.action == "payment_url_ready" and script_step.url:
                checkout_url = script_step.url
                break

        if not checkout_url:
            # 未找到 checkout URL，标记失败
            error_msg = "Stripe checkout session 创建成功，但未返回支付 URL"
            logger.error(error_msg)
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(timezone.utc),
                error=error_msg,
                steps=tx.steps,
            )
            return tx.model_copy(
                update={
                    "status": TransactionStatus.failed,
                    "completed_at": datetime.now(timezone.utc),
                    "error": error_msg,
                }
            )

        # 创建 HumanAction 记录（Stripe 支付通过外部 URL 完成）
        now = datetime.now(timezone.utc)
        human_action = HumanAction(
            action_type="stripe_checkout",
            requested_at=now,
            display_mode=self._display_manager.mode,
            novnc_url=checkout_url,  # 复用 novnc_url 字段存储 checkout URL
        )

        # 更新交易状态为 human_action_required
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            human_action=human_action,
            steps=tx.steps,
        )
        logger.info(
            "交易 %s 进入人类确认状态（Stripe checkout）：%s",
            tx.tx_id, checkout_url
        )

        # 通知终端用户（CLI 输出 URL 和二维码）
        await self._display_manager.notify_human(
            message=f"请访问以下 Stripe checkout 链接完成支付（{amount} {currency.upper()}）",
            action_type="stripe_checkout",
            details={
                "tx_id": tx.tx_id,
                "amount": f"{amount} {currency.upper()}",
                "checkout_url": checkout_url,
                "说明": "支付完成后，webhook 将自动更新交易状态",
            },
        )

        logger.info(
            "Stripe 支付 URL 已生成，等待 webhook 通知支付结果：%s", checkout_url
        )

        # 返回交易（状态为 human_action_required）
        # webhook 监听器将异步更新状态为 completed 或 failed
        return tx.model_copy(
            update={
                "status": TransactionStatus.human_action_required,
                "human_action": human_action,
            }
        )

    # ------------------------------------------------------------------
    # 人类介入处理
    # ------------------------------------------------------------------

    async def _handle_human_interaction(
        self,
        browser: BrowserController,
        detection: DetectionResult,
        tx: Transaction,
    ) -> bool:
        """处理需要人类介入的支付环节。

        流程：
        1. 更新交易状态为 human_action_required
        2. 创建 HumanAction 记录（含显示模式和 noVNC URL）
        3. 通过 display.notify_human 通知终端用户
        4. 等待检测器报告操作完成（带倒计时 spinner）
        5. 返回是否成功完成

        Args:
            browser:   已启动的 BrowserController
            detection: 检测器扫描结果，包含操作类型和描述
            tx:        当前交易对象

        Returns:
            True 表示人类操作在超时前完成；False 表示等待超时
        """
        now = datetime.now(timezone.utc)

        # ---- 构建显示信息（headed / noVNC URL）----
        display_info = self._display_manager.get_display_info()
        novnc_url: Optional[str] = display_info.get("url")

        # ---- 创建 HumanAction 记录 ----
        human_action = HumanAction(
            action_type=detection.action_type,
            requested_at=now,
            display_mode=self._display_manager.mode,
            novnc_url=novnc_url,
        )

        # ---- 更新交易状态：human_action_required ----
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            human_action=human_action,
            steps=tx.steps,
        )
        logger.info(
            "交易 %s 进入人类介入状态：%s", tx.tx_id, detection.action_type
        )

        # ---- 通知终端用户 ----
        await self._display_manager.notify_human(
            message=detection.description,
            action_type=detection.action_type,
            details={
                **detection.data,
                "tx_id": tx.tx_id,
                "amount": f"¥{tx.amount:.2f}",
                "payee": tx.payee,
            },
        )

        # ---- 等待检测器报告完成（使用 display.wait_for_completion）----
        # 构建与 DetectorPipeline.wait_for_completion 对应的异步回调
        async def _completion_callback() -> bool:
            """轮询检测器，检测人类操作是否完成。"""
            # 找到对应检测器并调用 detect_completion
            for detector in self._detector_pipeline._detectors:
                if detector.name == detection.detector_name:
                    return await detector.detect_completion(browser.page)
            return False

        success = await self._display_manager.wait_for_completion(
            detector_callback=_completion_callback,
            timeout=self._config.transaction_timeout,
        )

        # ---- 更新 HumanAction 完成时间 ----
        if success:
            completed_action = human_action.model_copy(
                update={"completed_at": datetime.now(timezone.utc)}
            )
            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.human_action_required,
                human_action=completed_action,
                steps=tx.steps,
            )
            logger.info("人类操作已完成（action_type=%s）", detection.action_type)
        else:
            logger.warning(
                "等待人类操作超时（action_type=%s，timeout=%ds）",
                detection.action_type,
                self._config.transaction_timeout,
            )

        return success

    # ------------------------------------------------------------------
    # 人类完全接管模式
    # ------------------------------------------------------------------

    async def _human_takeover(
        self,
        browser: BrowserController,
        tx: Transaction,
    ) -> Transaction:
        """人类完全接管模式：通知用户直接操控浏览器完成支付。

        当脚本模式和智能模式均失败时调用此方法。
        浏览器已导航到某个页面，用户需要手动完成剩余操作。

        Args:
            browser: 已启动的 BrowserController
            tx:      当前交易对象

        Returns:
            更新后的 Transaction 对象
        """
        logger.info("进入人类接管模式（交易 %s）", tx.tx_id)

        # 构建接管说明文本
        current_url = await browser.get_current_url()
        takeover_message = (
            f"自动化流程失败，请在浏览器中手动完成支付。\n"
            f"当前页面：{current_url}"
        )

        # 创建接管 HumanAction 记录
        now = datetime.now(timezone.utc)
        display_info = self._display_manager.get_display_info()
        novnc_url: Optional[str] = display_info.get("url")

        human_action = HumanAction(
            action_type="takeover",
            requested_at=now,
            display_mode=self._display_manager.mode,
            novnc_url=novnc_url,
        )

        # 追加接管步骤记录
        takeover_step = StepRecord(
            step_index=len(tx.steps),
            description="自动化失败，进入人类接管模式",
            status="pending",
            started_at=now,
        )
        tx = tx.model_copy(
            update={
                "execution_mode": ExecutionMode.human_takeover,
                "steps": [*tx.steps, takeover_step],
                "human_action": human_action,
            }
        )

        # 更新数据库：状态设为 human_action_required
        self._ledger.update_status(
            tx.tx_id,
            TransactionStatus.human_action_required,
            human_action=human_action,
            steps=tx.steps,
        )

        # 通知终端用户接管
        await self._display_manager.notify_human(
            message=takeover_message,
            action_type="takeover",
            details={
                "tx_id": tx.tx_id,
                "amount": f"¥{tx.amount:.2f}",
                "payee": tx.payee,
                "current_url": current_url,
                "说明": "请在浏览器中完成支付后，在终端按 Enter 确认或等待自动检测",
            },
        )

        # 等待人类完成操作（检测器持续轮询支付成功状态）
        async def _takeover_completion_callback() -> bool:
            """在接管模式下轮询页面，检测支付完成状态。"""
            detection = await self._detector_pipeline.scan(browser.page)
            return detection is not None and detection.action_type == "completed"

        success = await self._display_manager.wait_for_completion(
            detector_callback=_takeover_completion_callback,
            timeout=self._config.transaction_timeout,
        )

        now = datetime.now(timezone.utc)
        if success:
            # 人类接管后支付完成
            completed_action = human_action.model_copy(
                update={"completed_at": now}
            )
            completed_step = takeover_step.model_copy(
                update={"status": "success", "completed_at": now}
            )
            updated_steps = [*tx.steps[:-1], completed_step]

            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.completed,
                completed_at=now,
                human_action=completed_action,
                steps=updated_steps,
            )
            logger.info("人类接管完成，交易 %s 支付成功", tx.tx_id)
            return tx.model_copy(
                update={
                    "status": TransactionStatus.completed,
                    "completed_at": now,
                    "human_action": completed_action,
                    "steps": updated_steps,
                }
            )
        else:
            # 接管超时
            timeout_msg = "人类接管超时，用户未在规定时间内完成支付"
            failed_step = takeover_step.model_copy(
                update={"status": "failed", "completed_at": now}
            )
            updated_steps = [*tx.steps[:-1], failed_step]

            self._ledger.update_status(
                tx.tx_id,
                TransactionStatus.timeout,
                completed_at=now,
                error=timeout_msg,
                steps=updated_steps,
            )
            logger.warning("交易 %s 人类接管超时", tx.tx_id)
            return tx.model_copy(
                update={
                    "status": TransactionStatus.timeout,
                    "completed_at": now,
                    "error": timeout_msg,
                    "steps": updated_steps,
                }
            )

    # ------------------------------------------------------------------
    # 辅助方法
    # ------------------------------------------------------------------

    def _requires_human(self, detection: DetectionResult) -> bool:
        """根据检测结果判断是否需要暂停等待人类介入。

        通过检测器名称找到对应检测器实例，调用其 requires_human() 方法。
        若找不到对应检测器，则保守地返回 True（触发人类介入）。

        Args:
            detection: 检测器扫描结果

        Returns:
            True 表示需要暂停等待人类；False 表示可继续自动执行
        """
        for detector in self._detector_pipeline._detectors:
            if detector.name == detection.detector_name:
                return detector.requires_human()
        # 未知检测器：保守处理，触发人类介入
        logger.warning(
            "未找到检测器 %s，保守处理为需要人类介入", detection.detector_name
        )
        return True

    # ------------------------------------------------------------------
    # 手动确认与状态查询
    # ------------------------------------------------------------------

    async def confirm(self, tx_id: str) -> Transaction:
        """人类手动确认支付完成。

        适用于检测器未能自动识别完成状态的情况，
        用户通过 CLI 或 API 手动告知系统支付已完成。

        Args:
            tx_id: 要确认的交易 ID

        Returns:
            更新状态为 completed 的 Transaction 对象

        Raises:
            PaySwitchError: 交易不存在或已处于终态
        """
        tx = self._ledger.get(tx_id)
        if tx is None:
            raise PaySwitchError(f"交易不存在：{tx_id}")

        if tx.is_terminal() and tx.status != TransactionStatus.human_action_required:
            raise PaySwitchError(
                f"交易 {tx_id} 已处于终态（{tx.status}），无法再次确认"
            )

        now = datetime.now(timezone.utc)

        # 若有 HumanAction 记录，更新其完成时间
        updated_human_action: Optional[HumanAction] = None
        if tx.human_action is not None and tx.human_action.completed_at is None:
            updated_human_action = tx.human_action.model_copy(
                update={"completed_at": now}
            )

        self._ledger.update_status(
            tx_id,
            TransactionStatus.completed,
            completed_at=now,
            human_action=updated_human_action,
            steps=tx.steps,
        )

        logger.info("交易 %s 已手动确认为完成", tx_id)

        return tx.model_copy(
            update={
                "status": TransactionStatus.completed,
                "completed_at": now,
                "human_action": updated_human_action or tx.human_action,
            }
        )

    async def get_status(self, tx_id: str) -> Transaction:
        """查询交易当前状态。

        Args:
            tx_id: 交易 ID

        Returns:
            对应的 Transaction 对象

        Raises:
            PaySwitchError: 交易不存在
        """
        tx = self._ledger.get(tx_id)
        if tx is None:
            raise PaySwitchError(f"交易不存在：{tx_id}")
        return tx

    def close(self) -> None:
        """清理资源，关闭数据库连接。

        编排器使用完毕后必须调用此方法，否则 SQLite 连接不会被释放。
        通常在 CLI 入口或 FastAPI 应用生命周期结束时调用。
        """
        self._ledger.close()
        logger.info("PaymentOrchestrator 已关闭，所有资源已释放")

    # ------------------------------------------------------------------
    # 上下文管理器支持（async with 语法）
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "PaymentOrchestrator":
        """支持 async with 语句。"""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        """退出 async with 块时自动调用 close()。"""
        self.close()
