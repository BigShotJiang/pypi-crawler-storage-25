"""Risk gates for controlled payment automation."""

from __future__ import annotations

from dataclasses import dataclass

from payswitch.models.config import PaySwitchConfig
from payswitch.models.types import StepCategory, StepRisk

_CATEGORY_ORDER: dict[StepCategory, int] = {
    StepCategory.nav: 0,
    StepCategory.identity: 1,
    StepCategory.checkout_prep: 2,
    StepCategory.sensitive: 3,
    StepCategory.final_authorization: 4,
    StepCategory.result: 5,
}


@dataclass(frozen=True)
class RiskDecision:
    """Result of deciding whether a step can run without human authorization."""

    allowed: bool
    reason: str


class RiskGate:
    """Small policy helper for Computer Use autonomy boundaries."""

    def __init__(self, config: PaySwitchConfig) -> None:
        self._config = config

    def can_run_autonomously(
        self,
        *,
        category: StepCategory,
        risk: StepRisk,
    ) -> RiskDecision:
        """Return whether a step may be executed without a human gate."""
        if risk == StepRisk.human_required:
            return RiskDecision(False, "步骤明确要求人类授权")

        if category in {StepCategory.sensitive, StepCategory.final_authorization}:
            return RiskDecision(False, f"{category.value} 步骤必须交给 HumanGate")

        max_category = self._config.computer_use_max_autonomous_category
        if _CATEGORY_ORDER[category] > _CATEGORY_ORDER[max_category]:
            return RiskDecision(
                False,
                f"步骤类别 {category.value} 超过配置允许的 {max_category.value}",
            )

        if risk == StepRisk.high:
            return RiskDecision(False, "高风险步骤需要人类确认")

        return RiskDecision(True, "允许自动执行")

