"""Pay-Switch CLI 入口模块。

基于 Typer 定义所有命令行子命令，提供 AI Agent 支付编排的完整 CLI 接口。
"""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
import sys
import time
from pathlib import Path
from typing import Annotated, Optional

import io

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.text import Text

from payswitch import __version__

# ---------------------------------------------------------------------------
# 在 Windows GBK 终端下将 stdout/stderr 重新包装为 UTF-8 编码，
# 以支持 Unicode 字符（中文、符号等）正常输出。
# 必须在创建 Rich Console 之前执行。
# ---------------------------------------------------------------------------
if sys.stdout.encoding and sys.stdout.encoding.lower() in ("gbk", "cp936", "cp950"):
    sys.stdout = io.TextIOWrapper(
        sys.stdout.buffer,
        encoding="utf-8",
        errors="replace",
        line_buffering=True,
    )
if sys.stderr.encoding and sys.stderr.encoding.lower() in ("gbk", "cp936", "cp950"):
    sys.stderr = io.TextIOWrapper(
        sys.stderr.buffer,
        encoding="utf-8",
        errors="replace",
        line_buffering=True,
    )

# ---------------------------------------------------------------------------
# 全局 Rich 控制台（stderr 用于状态输出，stdout 用于结构化数据）
# ---------------------------------------------------------------------------
console = Console(stderr=False)
err_console = Console(stderr=True)

# ---------------------------------------------------------------------------
# 全局状态容器（通过 Typer callback 注入）
# ---------------------------------------------------------------------------
class AppState:
    """保存顶级全局选项的运行时状态。"""

    json_output: bool = False
    verbose: bool = False


_state = AppState()

# ---------------------------------------------------------------------------
# 主 app
# ---------------------------------------------------------------------------
app = typer.Typer(
    name="payswitch",
    help="Pay-Switch：让 AI Agent 学会花钱的支付编排工具。",
    no_args_is_help=True,
    rich_markup_mode="rich",
    add_completion=True,
)
settings_app = typer.Typer(
    help="交互式配置浏览器 profile、Computer Use 驱动等运行时设置。",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
app.add_typer(settings_app, name="settings")

stripe_app = typer.Typer(
    help="Stripe 支付通道相关命令（启动 webhook 监听器等）。",
    no_args_is_help=True,
    rich_markup_mode="rich",
)
app.add_typer(stripe_app, name="stripe")


def _version_callback(value: bool) -> None:
    """打印版本号后退出。"""
    if value:
        console.print(f"payswitch {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    ctx: typer.Context,
    version: Annotated[
        Optional[bool],
        typer.Option(
            "--version",
            "-V",
            callback=_version_callback,
            is_eager=True,
            help="显示版本号并退出。",
        ),
    ] = None,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="以 JSON 格式输出结果（适合 Agent 程序解析）。",
            is_eager=False,
        ),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-v",
            help="启用详细日志输出（显示调试信息）。",
        ),
    ] = False,
) -> None:
    """[bold cyan]Pay-Switch[/bold cyan] — AI Agent 支付编排工具。

    让 Agent 自动完成支付流程，在关键步骤请人类确认。

    [dim]更多信息请访问：https://github.com/your-org/pay-switch[/dim]
    """
    _state.json_output = json_output
    _state.verbose = verbose

    # --verbose 时输出所有 DEBUG 及以上日志，方便排查问题；
    # 普通用户默认只看到 WARNING 及以上，减少日志噪音。
    log_level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
        # 若 basicConfig 已被调用过，force=True 可强制覆盖已有配置
        force=True,
    )


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def _print_json(data: object) -> None:
    """将数据序列化为 JSON 并直接写入 stdout（绕过 Rich 的 Windows 渲染器）。
    使用 ensure_ascii=True 确保在任何终端编码下均可安全输出。
    """
    sys.stdout.write(json.dumps(data, ensure_ascii=True, indent=2))
    sys.stdout.write("\n")
    sys.stdout.flush()


def _print_json_str(json_str: str) -> None:
    """将已序列化的 JSON 字符串直接写入 stdout。
    将字符串重新序列化为 ASCII-safe 格式以兼容 Windows GBK 终端。
    """
    # 重新解析并以 ASCII-safe 格式输出
    try:
        data = json.loads(json_str)
        sys.stdout.write(json.dumps(data, ensure_ascii=True, indent=2))
    except (json.JSONDecodeError, TypeError):
        sys.stdout.write(json_str)
    sys.stdout.write("\n")
    sys.stdout.flush()


def _print_error(message: str) -> None:
    """统一输出错误信息到 stderr。"""
    if _state.json_output:
        _print_json({"error": message})
    else:
        err_console.print(f"[bold red]错误：[/bold red]{message}")


def _get_status_style(status: str) -> str:
    """根据交易状态返回对应的 Rich 样式颜色。"""
    styles = {
        "completed": "green",
        "failed": "red",
        "pending": "yellow",
        "executing": "cyan",
        "human_action_required": "magenta",
        "cancelled": "dim",
        "timeout": "red",
    }
    return styles.get(status, "white")


def _get_status_label(status: str) -> str:
    """将交易状态值转换为中文标签。"""
    labels = {
        "completed": "已完成",
        "failed": "失败",
        "pending": "待处理",
        "executing": "执行中",
        "human_action_required": "等待人工",
        "cancelled": "已取消",
        "timeout": "超时",
    }
    return labels.get(status, status)


def _format_amount(amount: float, currency: str = "CNY") -> str:
    """格式化金额显示。CNY 使用 CNY 前缀（避免 Windows GBK 终端编码问题）。"""
    if currency == "CNY":
        return f"CNY {amount:.2f}"
    return f"{amount:.2f} {currency}"


def _format_datetime(dt) -> str:
    """将 datetime 对象格式化为本地时间字符串，None 时返回 '-'。"""
    if dt is None:
        return "-"
    # 转换为本地时间显示
    try:
        from datetime import timezone
        local_dt = dt.astimezone()
        return local_dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(dt)


# ---------------------------------------------------------------------------
# settings — 交互式配置真实浏览器上下文和 Computer Use 模式
# ---------------------------------------------------------------------------
@settings_app.command("wizard")
def settings_wizard(
    browser: Annotated[
        str | None,
        typer.Option(
            "--browser",
            help=(
                "浏览器类型：chrome / chromium / firefox。"
                "当前 profile 发现主路径支持 chrome/chromium。"
            ),
        ),
    ] = None,
    profile_query: Annotated[
        str | None,
        typer.Option(
            "--profile-query",
            "-q",
            help="按邮箱、昵称、用户名或 profile 目录过滤。",
        ),
    ] = None,
    profile_index: Annotated[
        int | None,
        typer.Option(
            "--profile-index",
            min=1,
            help="非交互选择第 N 个过滤后的 profile。",
        ),
    ] = None,
    yes: Annotated[
        bool,
        typer.Option(
            "--yes",
            "-y",
            help="使用推荐默认值：第一个匹配 profile、external、checkout_prep。",
        ),
    ] = False,
    clear_cdp: Annotated[
        bool,
        typer.Option(
            "--clear-cdp",
            help="清空已有 chrome_cdp_url；默认保留，适合继续连接已打开的 Chrome。",
        ),
    ] = False,
) -> None:
    """配置引导页：先选浏览器，再选 profile，然后设置 Computer Use。"""
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import ComputerUseDriver, StepCategory

    config = PaySwitchConfig.load()

    if not _state.json_output:
        _print_wizard_intro()

    selected_browser = browser.strip().lower() if browser else None
    if selected_browser is None:
        if yes:
            selected_browser = "chrome"
        else:
            _print_browser_explainer()
            default_browser = (
                config.browser_channel
                if config.browser_channel in {"chrome", "chromium"}
                else "chrome"
            )
            selected_browser = _prompt_choice(
                "选择要启用的浏览器",
                ["chrome", "chromium", "firefox"],
                default=default_browser,
            )
    _validate_profile_browser(selected_browser)

    selected_profile_query = profile_query
    if selected_profile_query is None and not yes:
        _print_profile_explainer(selected_browser, config.chrome_expected_profile_email)
        selected_profile_query = typer.prompt(
            "可选：输入关键词缩小列表，直接回车显示全部",
            default="",
            show_default=False,
        ).strip() or None

    selected_index = profile_index
    if selected_index is None and yes:
        selected_index = 1

    settings_profile(
        browser=selected_browser,
        user_data_dir=None,
        list_only=False,
        query=selected_profile_query,
        index=selected_index,
        keep_cdp=not clear_cdp,
    )

    config = PaySwitchConfig.load()
    if yes:
        driver = ComputerUseDriver.external.value
        max_category = StepCategory.checkout_prep.value
        enable = True
    else:
        _print_computer_use_explainer()
        driver = _prompt_choice(
            "页面操作由谁驱动",
            [item.value for item in ComputerUseDriver],
            default=config.computer_use_driver.value,
        )
        _print_autonomy_explainer()
        max_category = _prompt_choice(
            "允许自动走到哪一步",
            [item.value for item in StepCategory],
            default=config.computer_use_max_autonomous_category.value,
        )
        enable = typer.confirm(
            "是否启用 Computer Use 兜底能力？",
            default=config.computer_use_enabled,
        )

    settings_computer_use(
        driver=driver,
        max_category=max_category,
        enable=enable,
        disable=not enable,
    )

    updated = PaySwitchConfig.load()
    if _state.json_output:
        _print_json(
            {
                "browser": selected_browser,
                "chrome_user_data_dir": updated.chrome_user_data_dir,
                "chrome_profile_directory": updated.chrome_profile_directory,
                "chrome_expected_profile_email": updated.chrome_expected_profile_email,
                "chrome_cdp_url": updated.chrome_cdp_url,
                "computer_use_enabled": updated.computer_use_enabled,
                "computer_use_driver": updated.computer_use_driver.value,
                "computer_use_max_autonomous_category": (
                    updated.computer_use_max_autonomous_category.value
                ),
            }
        )
        return

    console.print(
        Panel(
            "[green]配置引导完成[/green]\n\n"
            f"Browser: {selected_browser}\n"
            f"Profile: {updated.chrome_expected_profile_email or '<未识别邮箱>'} "
            f"({updated.chrome_profile_directory or '<未设置>'})\n"
            f"Computer Use: {updated.computer_use_driver.value} / "
            f"{updated.computer_use_max_autonomous_category.value}\n\n"
            "下一步可运行：\n"
            "  uv run payswitch spend 1 nineemail --reason "
            "\"smoke dry run checkout\" --dry-run --method alipay_qr\n\n"
            "[dim]这条命令只做模拟，不会真实支付。真正付款前，"
            "Pay-Switch 会在二维码、CVV、验证码、付款确认等位置停下来等你。[/dim]",
            title="Ready",
            border_style="green",
        )
    )


@settings_app.command("profile")
def settings_profile(
    browser: Annotated[
        str,
        typer.Option(
            "--browser",
            help="浏览器类型：chrome / chromium。目前主路径是 chrome。",
        ),
    ] = "chrome",
    user_data_dir: Annotated[
        Path | None,
        typer.Option(
            "--user-data-dir",
            help="Chrome User Data 根目录；留空则自动扫描本机默认目录。",
        ),
    ] = None,
    list_only: Annotated[
        bool,
        typer.Option("--list-only", help="只列出可选 profile，不写入配置。"),
    ] = False,
    query: Annotated[
        str | None,
        typer.Option(
            "--query",
            "-q",
            help="按邮箱、昵称、用户名或 profile 目录过滤。",
        ),
    ] = None,
    index: Annotated[
        int | None,
        typer.Option(
            "--index",
            min=1,
            help="非交互选择第 N 个 profile，适合脚本/测试。",
        ),
    ] = None,
    keep_cdp: Annotated[
        bool,
        typer.Option(
            "--keep-cdp",
            help="保留已有 chrome_cdp_url；默认选择真实 profile 后清空 CDP 地址。",
        ),
    ] = False,
) -> None:
    """发现本机 Chrome profiles，并选择一个作为真实支付浏览器上下文。

    这个命令会同时展示 Chrome 的 profile 子目录名、邮箱、昵称/用户名。
    保存后，Pay-Switch 运行浏览器链路时会优先使用这个用户指定的真实
    Chrome profile，而不是新建空白 Chromium。
    """
    from payswitch.browser.chrome_profiles import (
        discover_chrome_user_data_dirs,
        list_profile_identities,
    )
    from payswitch.models.config import PaySwitchConfig

    browser = browser.strip().lower()
    _validate_profile_browser(browser)

    roots = [Path(user_data_dir).expanduser()] if user_data_dir else (
        discover_chrome_user_data_dirs(browser)
    )
    profiles = []
    for root in roots:
        profiles.extend(list_profile_identities(root))
    if query:
        needle = query.strip().lower()
        profiles = [
            profile for profile in profiles
            if needle in profile.profile_directory.lower()
            or needle in profile.user_name.lower()
            or needle in profile.name.lower()
            or needle in profile.gaia_name.lower()
            or needle in profile.gaia_given_name.lower()
        ]

    if _state.json_output:
        _print_json(
            [
                {
                    "index": position,
                    "user_data_dir": str(profile.user_data_dir),
                    "profile_directory": profile.profile_directory,
                    "email": profile.user_name,
                    "name": profile.name,
                    "gaia_name": profile.gaia_name,
                    "gaia_given_name": profile.gaia_given_name,
                    "is_consented_primary_account": (
                        profile.is_consented_primary_account
                    ),
                    "active_time": profile.active_time,
                }
                for position, profile in enumerate(profiles, start=1)
            ]
        )
        if list_only:
            return

    if not profiles:
        searched = ", ".join(str(root) for root in roots) or "默认 Chrome 目录"
        _print_error(f"没有发现可用 Chrome profile。已搜索：{searched}")
        raise typer.Exit(code=1)

    if not _state.json_output:
        _print_profile_table(profiles, browser)

    if list_only:
        return

    selected_index = index
    if selected_index is None:
        selected_index = typer.prompt(
            "请选择要绑定的 profile 序号",
            type=int,
            default=1,
        )

    if selected_index < 1 or selected_index > len(profiles):
        _print_error(f"profile 序号超出范围：{selected_index}")
        raise typer.Exit(code=1)

    selected = profiles[selected_index - 1]
    updates = {
        "browser_channel": "chrome" if browser == "chrome" else browser,
        "chrome_user_data_dir": str(selected.user_data_dir),
        "chrome_profile_directory": selected.profile_directory,
        "chrome_expected_profile_email": selected.user_name,
    }
    if not keep_cdp:
        updates["chrome_cdp_url"] = ""

    config = PaySwitchConfig.load().update(**updates)

    if _state.json_output:
        _print_json(
            {
                "updated": updates,
                "selected": {
                    "user_data_dir": str(selected.user_data_dir),
                    "profile_directory": selected.profile_directory,
                    "email": selected.user_name,
                    "name": selected.name,
                    "gaia_name": selected.gaia_name,
                },
                "chrome_cdp_url": config.chrome_cdp_url,
            }
        )
        return

    console.print("[green]OK[/green] 已绑定真实 Chrome profile：")
    console.print(
        f"  [bold]目录[/bold] {selected.user_data_dir} / "
        f"{selected.profile_directory}"
    )
    console.print(
        f"  [bold]身份[/bold] "
        f"{selected.user_name or selected.gaia_name or selected.name or '未识别'}"
    )
    if keep_cdp and config.chrome_cdp_url:
        console.print(f"  [bold]CDP[/bold] 保留 {config.chrome_cdp_url}")
    elif not keep_cdp:
        console.print("  [bold]CDP[/bold] 已清空，后续将按所选 profile 启动/校验。")
    if not selected.user_name:
        console.print(
            "[yellow]提示：[/yellow]这个 profile 没有读到邮箱，运行时只能校验目录名。"
        )


@settings_app.command("computer-use")
def settings_computer_use(
    driver: Annotated[
        str | None,
        typer.Option(
            "--driver",
            help="Computer Use 驱动：external / internal / hybrid。",
        ),
    ] = None,
    max_category: Annotated[
        str | None,
        typer.Option(
            "--max-category",
            help=(
                "Computer Use 可自治推进的最高步骤：nav / identity / "
                "checkout_prep / sensitive / final_authorization / result。"
            ),
        ),
    ] = None,
    enable: Annotated[
        bool,
        typer.Option("--enable", help="启用 Computer Use 兜底能力。"),
    ] = False,
    disable: Annotated[
        bool,
        typer.Option("--disable", help="禁用 Computer Use 兜底能力。"),
    ] = False,
) -> None:
    """配置 external / internal / hybrid 的 Computer Use 推理模式。"""
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import ComputerUseDriver, StepCategory

    if enable and disable:
        _print_error("--enable 和 --disable 不能同时使用")
        raise typer.Exit(code=1)

    config = PaySwitchConfig.load()
    updates = {}

    if driver is None and max_category is None and not enable and not disable:
        driver = _prompt_choice(
            "Computer Use 驱动",
            [item.value for item in ComputerUseDriver],
            default=config.computer_use_driver.value,
        )
        max_category = _prompt_choice(
            "可自治推进的最高步骤",
            [item.value for item in StepCategory],
            default=config.computer_use_max_autonomous_category.value,
        )
        enabled = typer.confirm(
            "是否启用 Computer Use 兜底能力？",
            default=config.computer_use_enabled,
        )
        updates["computer_use_enabled"] = enabled

    if driver is not None:
        try:
            updates["computer_use_driver"] = ComputerUseDriver(driver).value
        except ValueError:
            _print_error(f"不支持的 Computer Use driver：{driver}")
            raise typer.Exit(code=1)

    if max_category is not None:
        try:
            updates["computer_use_max_autonomous_category"] = (
                StepCategory(max_category).value
            )
        except ValueError:
            _print_error(f"不支持的步骤类别：{max_category}")
            raise typer.Exit(code=1)

    if enable:
        updates["computer_use_enabled"] = True
    if disable:
        updates["computer_use_enabled"] = False

    if not updates:
        _print_error("没有可更新的配置")
        raise typer.Exit(code=1)

    updated = config.update(**updates)

    if _state.json_output:
        _print_json(
            {
                "updated": updates,
                "computer_use_enabled": updated.computer_use_enabled,
                "computer_use_driver": updated.computer_use_driver.value,
                "computer_use_max_autonomous_category": (
                    updated.computer_use_max_autonomous_category.value
                ),
            }
        )
        return

    console.print("[green]OK[/green] Computer Use 配置已更新：")
    console.print(f"  enabled = {updated.computer_use_enabled}")
    console.print(f"  driver = {updated.computer_use_driver.value}")
    console.print(
        "  max_category = "
        f"{updated.computer_use_max_autonomous_category.value}"
    )


@settings_app.command("stripe")
def settings_stripe(
    secret_key: Annotated[
        Optional[str],
        typer.Option(
            "--secret-key",
            help="Stripe Secret Key（sk_test_... 或 sk_live_...）",
        ),
    ] = None,
    webhook_secret: Annotated[
        Optional[str],
        typer.Option(
            "--webhook-secret",
            help="Stripe Webhook Signing Secret（whsec_...）",
        ),
    ] = None,
    webhook_port: Annotated[
        Optional[int],
        typer.Option(
            "--webhook-port",
            help="Webhook 监听端口（默认 4242）",
        ),
    ] = None,
    currency: Annotated[
        Optional[str],
        typer.Option(
            "--currency",
            help="默认货币（ISO 4217 代码，如 usd / cny / hkd）",
        ),
    ] = None,
) -> None:
    """配置 Stripe 支付通道（API Key、Webhook Secret、默认货币等）。"""
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()
    updates = {}

    # 交互式配置（未提供参数时）
    if secret_key is None and webhook_secret is None and webhook_port is None and currency is None:
        console.print("[bold cyan]Stripe 配置向导[/bold cyan]\n")

        # Secret Key
        current_key = config.get_stripe_secret_key()
        if current_key:
            console.print(f"当前 Secret Key: {current_key[:16]}...（已配置）")
        else:
            console.print("当前 Secret Key: [dim]未配置[/dim]")

        new_key = typer.prompt(
            "请输入 Stripe Secret Key（留空跳过）",
            default="",
            show_default=False,
        )
        if new_key.strip():
            updates["stripe_secret_key"] = new_key.strip()

        # Webhook Secret
        current_webhook = config.get_stripe_webhook_secret()
        if current_webhook:
            console.print(f"当前 Webhook Secret: {current_webhook[:16]}...（已配置）")
        else:
            console.print("当前 Webhook Secret: [dim]未配置[/dim]")

        new_webhook = typer.prompt(
            "请输入 Webhook Signing Secret（留空跳过）",
            default="",
            show_default=False,
        )
        if new_webhook.strip():
            updates["stripe_webhook_secret"] = new_webhook.strip()

        # Webhook Port
        new_port = typer.prompt(
            "Webhook 监听端口",
            default=config.stripe_webhook_port,
        )
        if new_port != config.stripe_webhook_port:
            updates["stripe_webhook_port"] = new_port

        # Default Currency
        new_currency = typer.prompt(
            "默认货币（ISO 4217 代码）",
            default=config.stripe_default_currency,
        ).strip().lower()
        if new_currency != config.stripe_default_currency:
            updates["stripe_default_currency"] = new_currency

    else:
        # 命令行参数配置
        if secret_key is not None:
            updates["stripe_secret_key"] = secret_key
        if webhook_secret is not None:
            updates["stripe_webhook_secret"] = webhook_secret
        if webhook_port is not None:
            updates["stripe_webhook_port"] = webhook_port
        if currency is not None:
            updates["stripe_default_currency"] = currency.lower()

    if not updates:
        console.print("[yellow]未修改任何配置[/yellow]")
        return

    # 对 secret key 和 webhook secret 进行编码存储
    if "stripe_secret_key" in updates:
        config = config.set_stripe_secret_key(updates.pop("stripe_secret_key"))
    if "stripe_webhook_secret" in updates:
        config = config.set_stripe_webhook_secret(updates.pop("stripe_webhook_secret"))

    # 更新其他字段
    if updates:
        config = config.update(**updates)

    if _state.json_output:
        _print_json({
            "updated": True,
            "stripe_secret_key_set": bool(config.get_stripe_secret_key()),
            "stripe_webhook_secret_set": bool(config.get_stripe_webhook_secret()),
            "webhook_port": config.stripe_webhook_port,
            "default_currency": config.stripe_default_currency,
        })
        return

    console.print("[green]OK[/green] Stripe 配置已更新：")
    if config.get_stripe_secret_key():
        console.print(f"  secret_key = {config.get_stripe_secret_key()[:16]}...（已配置）")
    else:
        console.print("  secret_key = [dim]未配置[/dim]")
    if config.get_stripe_webhook_secret():
        console.print(f"  webhook_secret = {config.get_stripe_webhook_secret()[:16]}...（已配置）")
    else:
        console.print("  webhook_secret = [dim]未配置[/dim]")
    console.print(f"  webhook_port = {config.stripe_webhook_port}")
    console.print(f"  default_currency = {config.stripe_default_currency}")


# ---------------------------------------------------------------------------
# Stripe 子命令组
# ---------------------------------------------------------------------------


@stripe_app.command("listen")
def stripe_listen(
    port: Annotated[
        Optional[int],
        typer.Option(
            "--port",
            "-p",
            help="Webhook 监听端口（默认从配置读取，通常为 4242）",
        ),
    ] = None,
    host: Annotated[
        str,
        typer.Option(
            "--host",
            help="监听地址（默认 0.0.0.0）",
        ),
    ] = "0.0.0.0",
) -> None:
    """启动 Stripe webhook 监听器（接收支付完成事件并更新交易状态）。

    使用示例：
      payswitch stripe listen              # 使用配置文件中的端口
      payswitch stripe listen --port 8080  # 使用指定端口
      payswitch stripe listen --host 127.0.0.1  # 仅本地监听

    注意：
    - 需要先配置 Stripe Webhook Secret：payswitch settings stripe
    - 生产环境需要配置 Stripe Dashboard 的 webhook URL
    - 本地测试可使用 Stripe CLI 的 webhook 转发功能
    """
    from payswitch.models.config import PaySwitchConfig

    config = PaySwitchConfig.load()

    # 确定监听端口
    listen_port = port if port is not None else config.stripe_webhook_port

    # 检查 Stripe 依赖是否安装
    try:
        from payswitch.engine.stripe_webhook import create_webhook_app
    except ImportError:
        _print_error(
            "Stripe 依赖未安装。请运行：uv pip install 'payswitch[stripe]' "
            "或 pip install stripe fastapi uvicorn"
        )
        raise typer.Exit(code=1)

    # 创建 webhook app
    app = create_webhook_app()
    if app is None:
        _print_error("无法创建 webhook 监听器，请检查依赖安装")
        raise typer.Exit(code=1)

    # 输出启动信息
    console.print(f"[bold cyan]Stripe Webhook 监听器启动中...[/bold cyan]")
    console.print(f"  监听地址: {host}:{listen_port}")
    console.print(f"  Webhook URL: http://{host}:{listen_port}/webhook")
    console.print(f"  健康检查: http://{host}:{listen_port}/health")

    webhook_secret = config.get_stripe_webhook_secret()
    if not webhook_secret:
        console.print(
            "[yellow]警告：[/yellow] Webhook Secret 未配置，签名验证将被跳过（不安全）"
        )
        console.print("  请运行 [cyan]payswitch settings stripe[/cyan] 配置 Webhook Secret")

    console.print("\n按 Ctrl+C 停止监听器\n")

    # 启动 uvicorn 服务器
    try:
        import uvicorn
        uvicorn.run(app, host=host, port=listen_port, log_level="info")
    except KeyboardInterrupt:
        console.print("\n[yellow]监听器已停止[/yellow]")
    except Exception as exc:
        _print_error(f"启动监听器失败：{exc}")
        raise typer.Exit(code=1)


def _print_profile_table(profiles, browser: str) -> None:
    table = Table(
        title=f"{browser} profiles",
        border_style="cyan",
        show_lines=False,
    )
    table.add_column("#", justify="right", style="bold cyan", no_wrap=True)
    table.add_column("Profile 目录", style="bold", no_wrap=True)
    table.add_column("邮箱", overflow="fold")
    table.add_column("昵称 / 用户名", overflow="fold")
    table.add_column("User Data", style="dim", overflow="fold")

    for position, profile in enumerate(profiles, start=1):
        display_name = (
            profile.gaia_name
            or profile.gaia_given_name
            or profile.name
            or "-"
        )
        if profile.is_consented_primary_account:
            display_name = f"{display_name} [green](primary)[/green]"
        table.add_row(
            str(position),
            profile.profile_directory,
            profile.user_name or "[dim]未识别[/dim]",
            display_name,
            str(profile.user_data_dir),
        )

    console.print(table)


def _print_wizard_intro() -> None:
    console.print(
        Panel(
            "[bold]Pay-Switch 配置引导[/bold]\n\n"
            "这个向导会把 Pay-Switch 连接到你真实使用的浏览器环境，"
            "这样它进入充值、订阅、收银台时，能使用你已经登录过、"
            "被网站信任过的 profile。\n\n"
            "配置流程：\n"
            "1. 选择浏览器\n"
            "2. 从该浏览器读取并选择 profile\n"
            "3. 设置 Computer Use 的思考/执行边界\n"
            "4. 给出下一步测试命令",
            title="Settings Wizard",
            border_style="cyan",
        )
    )


def _print_browser_explainer() -> None:
    table = Table(title="Step 1: 选择浏览器", border_style="cyan")
    table.add_column("选项", style="bold", no_wrap=True)
    table.add_column("说明")
    table.add_column("当前状态", style="dim")
    table.add_row(
        "chrome",
        "你平时使用的 Google Chrome。推荐用于真实支付测试。",
        "支持读取 profile",
    )
    table.add_row(
        "chromium",
        "Chromium 用户目录。适合开发机或非 Google Chrome 环境。",
        "支持读取 profile",
    )
    table.add_row(
        "firefox",
        "Firefox。后续可以扩展，但当前还没有 profile 读取实现。",
        "路线图",
    )
    console.print(table)
    console.print(
        "[dim]为什么先选浏览器：不同浏览器的 profile 存储位置和格式不同，"
        "必须先确定浏览器，才能正确列出可选身份。[/dim]\n"
    )


def _print_profile_explainer(browser: str, current_email: str) -> None:
    current = current_email or "未设置"
    console.print(
        Panel(
            f"[bold]Step 2: 选择 {browser} profile[/bold]\n\n"
            "profile 可以理解成 Chrome 右上角的那个用户身份。"
            "它保存了网站登录态、Cookie、设备信任、历史风控状态等信息。"
            "付款成功率往往取决于这里选得对不对。\n\n"
            "表格里的含义：\n"
            "- Profile 目录：机器真正使用的目录名，例如 Default / Profile 6\n"
            "- 邮箱：Chrome Local State 里读到的账号邮箱\n"
            "- 昵称 / 用户名：Chrome 显示名或 GAIA 名称\n\n"
            f"当前已绑定邮箱：{current}\n\n"
            "如果 profile 很多，可以输入邮箱、昵称或 Profile 目录的一部分来过滤；"
            "也可以直接回车看全部。",
            title="Profile Guide",
            border_style="cyan",
        )
    )


def _print_computer_use_explainer() -> None:
    table = Table(title="Step 3: Computer Use 驱动模式", border_style="cyan")
    table.add_column("模式", style="bold", no_wrap=True)
    table.add_column("谁来思考")
    table.add_column("适合场景")
    table.add_row(
        "external",
        "外部 Agent 思考；Pay-Switch 只做受控点击、校验、记录和人工闸门。",
        "推荐。适合把 Pay-Switch 当成 MCP/工具交给你的 Agent 使用。",
    )
    table.add_row(
        "internal",
        "Pay-Switch 自己调用配置的模型理解页面。",
        "本地 demo 或没有外部 Agent 时使用，需要额外配置模型。",
    )
    table.add_row(
        "hybrid",
        "外部 Agent 给目标，Pay-Switch 内部模型做局部页面理解。",
        "未来用于适配器失效后的自愈。",
    )
    console.print(table)
    console.print(
        "[dim]推荐 external：你的 Agent 当大脑，Pay-Switch 当手、刹车和账本。[/dim]\n"
    )


def _print_autonomy_explainer() -> None:
    table = Table(title="Computer Use 可以自动推进到哪一步", border_style="cyan")
    table.add_column("步骤", style="bold", no_wrap=True)
    table.add_column("含义")
    table.add_column("建议")
    table.add_row("nav", "打开页面、滚动、找入口、关普通弹窗。", "安全")
    table.add_row("identity", "检查是否登录、点登录入口。密码/2FA 仍要人来。", "通常可用")
    table.add_row("checkout_prep", "选择套餐、进入收银台、准备付款前信息。", "推荐默认")
    table.add_row("sensitive", "CVV、验证码、支付密码、银行卡等。", "不要自动")
    table.add_row("final_authorization", "确认付款、订阅、开通自动续费。", "必须人确认")
    table.add_row("result", "支付后读取结果页、收据、订单状态。", "后续确认")
    console.print(table)
    console.print(
        "[dim]建议保持 checkout_prep：系统可以帮你走到付款前，"
        "但真正付钱、扫码、输密码、点最终确认时停下来等你。[/dim]\n"
    )


def _prompt_choice(label: str, choices: list[str], default: str) -> str:
    choices_text = " / ".join(choices)
    while True:
        value = typer.prompt(
            f"{label} ({choices_text})",
            default=default,
        ).strip()
        if value in choices:
            return value
        console.print(f"[yellow]请输入以下选项之一：[/yellow]{choices_text}")


def _validate_profile_browser(browser: str) -> None:
    if browser == "firefox":
        _print_error(
            "Firefox profile 发现还没有实现。当前引导支持 chrome/chromium；"
            "多浏览器与多 profile 选择会放入后续路线图。"
        )
        raise typer.Exit(code=1)
    if browser not in {"chrome", "chromium"}:
        _print_error(f"不支持的浏览器：{browser}。可选：chrome / chromium")
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# setup — 初始化环境
# ---------------------------------------------------------------------------
@app.command("setup")
def setup(
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="强制重新初始化，覆盖已有配置。"),
    ] = False,
) -> None:
    """初始化 Pay-Switch 运行环境。

    安装 Playwright 浏览器、创建配置目录 (~/.payswitch/)，
    并引导完成首次配置（限额、LLM API Key 等）。

    示例：
      payswitch setup
      payswitch setup --force
    """
    from payswitch.models.config import PaySwitchConfig
    from payswitch.browser.display import detect_display_mode

    # 加载或创建配置
    config_path = Path.home() / ".payswitch" / "config.json"
    config = PaySwitchConfig.load()

    # 检测是否已完成 setup（配置文件存在且有 API Key）
    already_configured = config_path.exists() and bool(config.llm_api_key)

    if already_configured and not force:
        console.print(
            Panel(
                "[green]Pay-Switch 已完成初始化配置。[/green]\n"
                "使用 [bold]--force[/bold] 选项重新配置。",
                title="[cyan]初始化状态[/cyan]",
                border_style="cyan",
            )
        )
        raise typer.Exit(code=0)

    console.print(
        Panel(
            "[bold cyan]Pay-Switch 初始化向导[/bold cyan]\n"
            "[dim]将引导您完成三步配置流程[/dim]",
            border_style="cyan",
            padding=(1, 2),
        )
    )

    # ----------------------------------------------------------------
    # 步骤 1：安装 Playwright Chromium
    # ----------------------------------------------------------------
    console.print("\n[bold yellow]步骤 1/3[/bold yellow]  安装 Playwright Chromium 浏览器")

    # 检测 chromium 是否已安装（通过尝试列出已安装的浏览器）
    chromium_installed = False
    try:
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "install", "--dry-run"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        # dry-run 不实际安装，仅检测；若退出码为 0 视为环境可用
        chromium_installed = False  # 始终重新安装以确保最新版本
    except Exception:
        chromium_installed = False

    if chromium_installed and not force:
        console.print("  [green]OK[/green] Playwright Chromium 已安装，跳过")
    else:
        console.print("  正在下载并安装 Chromium，请稍候...")
        try:
            result = subprocess.run(
                [sys.executable, "-m", "playwright", "install", "chromium"],
                capture_output=not _state.verbose,
                text=True,
                timeout=300,
            )
            if result.returncode == 0:
                console.print("  [green]OK[/green] Chromium 安装成功")
            else:
                error_detail = result.stderr if result.stderr else "未知错误"
                _print_error(f"Chromium 安装失败：{error_detail}")
                raise typer.Exit(code=1)
        except subprocess.TimeoutExpired:
            _print_error("Chromium 安装超时（超过 5 分钟），请检查网络连接后重试")
            raise typer.Exit(code=1)
        except FileNotFoundError:
            _print_error("未找到 Python 解释器，请确认 Playwright 已通过 pip 安装")
            raise typer.Exit(code=1)

    # ----------------------------------------------------------------
    # 步骤 2：配置 LLM 后端
    # ----------------------------------------------------------------
    console.print("\n[bold yellow]步骤 2/3[/bold yellow]  配置 Skyvern LLM 后端")

    # 若已有配置且非 force 模式，询问是否跳过
    if config.llm_api_key and not force:
        skip = typer.confirm(
            "  已检测到已有 LLM 配置，是否跳过重新配置？",
            default=True,
        )
        if skip:
            console.print("  [green]OK[/green] 跳过 LLM 配置（使用已有配置）")
        else:
            config = _configure_llm(config)
    else:
        config = _configure_llm(config)

    # ----------------------------------------------------------------
    # 步骤 3：检测运行环境
    # ----------------------------------------------------------------
    console.print("\n[bold yellow]步骤 3/3[/bold yellow]  检测运行环境")

    display_mode = detect_display_mode()
    mode_desc = {
        "headed": "本地有头浏览器（有图形界面）",
        "novnc": "noVNC 远程访问（无图形界面服务器）",
    }.get(display_mode.value, display_mode.value)

    console.print(f"  [green]OK[/green] 检测到运行环境：[bold]{mode_desc}[/bold]")

    # 将检测到的 display_mode 保存到配置
    config = config.update(display_mode=display_mode)

    # 完成提示
    console.print(
        Panel(
            "[bold green]Pay-Switch 初始化完成！[/bold green]\n\n"
            "接下来您可以：\n"
            "  [cyan]payswitch login <platform>[/cyan]   — 登录支付平台\n"
            "  [cyan]payswitch spend <amount> <payee>[/cyan] — 发起支付\n"
            "  [cyan]payswitch --help[/cyan]             — 查看完整帮助",
            title="[green]初始化成功[/green]",
            border_style="green",
            padding=(1, 2),
        )
    )


def _configure_llm(config) -> object:
    """引导用户配置 LLM 后端，返回更新后的配置。"""
    from payswitch.models.config import PaySwitchConfig

    console.print("  请选择 LLM Provider：")
    console.print("    [bold]1[/bold] OpenAI（GPT-4o）")
    console.print("    [bold]2[/bold] Anthropic（Claude）")
    console.print("    [bold]3[/bold] Google（Gemini）")
    console.print("    [bold]4[/bold] 本地（Ollama / LM Studio）")

    provider_choice = typer.prompt(
        "  请输入选项编号",
        default="1",
    )

    provider_map = {
        "1": ("openai", "gpt-4o"),
        "2": ("anthropic", "claude-3-5-sonnet-20241022"),
        "3": ("google", "gemini-1.5-pro"),
        "4": ("local", "llama3"),
    }

    if provider_choice not in provider_map:
        console.print(f"  [yellow]无效选项 '{provider_choice}'，使用默认 OpenAI[/yellow]")
        provider_choice = "1"

    provider_name, default_model = provider_map[provider_choice]

    if provider_choice == "4":
        # 本地模型不需要 API Key
        api_key_plain = ""
        console.print("  [dim]本地模式无需 API Key[/dim]")
    else:
        api_key_plain = typer.prompt(
            f"  请输入 {provider_name.title()} API Key",
            hide_input=True,
        )
        if not api_key_plain.strip():
            console.print("  [yellow]警告：未输入 API Key，智能模式将无法使用[/yellow]")

    # 允许用户自定义模型名称
    model_name = typer.prompt(
        "  模型名称",
        default=default_model,
    )

    # 保存配置
    config = config.update(llm_provider=provider_name, llm_model=model_name)
    if api_key_plain.strip():
        config = config.set_llm_api_key(api_key_plain.strip())

    console.print(
        f"  [green]OK[/green] LLM 配置已保存："
        f"[bold]{provider_name}[/bold] / [bold]{model_name}[/bold]"
    )
    return config


# ---------------------------------------------------------------------------
# login — 登录平台
# ---------------------------------------------------------------------------
@app.command("login")
def login(
    platform: Annotated[
        Optional[str],
        typer.Argument(help="平台标识，如 deepseek / kimi / zhipu。"),
    ] = None,
    headed: Annotated[
        bool,
        typer.Option("--headed", help="强制使用有头浏览器（默认自动检测）。"),
    ] = False,
    list_profiles: Annotated[
        bool,
        typer.Option("--list", "-l", help="列出所有已登录的 Profile。"),
    ] = False,
    logout: Annotated[
        bool,
        typer.Option("--logout", help="退出登录（删除指定平台的 Profile）。"),
    ] = False,
) -> None:
    """登录并保存指定平台的浏览器 Profile。

    打开浏览器引导你完成登录，登录状态会持久化保存，
    后续支付操作无需重新登录。

    示例：
      payswitch login deepseek
      payswitch login kimi --headed
      payswitch login --list
      payswitch login deepseek --logout
    """
    from payswitch.models.config import PaySwitchConfig
    from payswitch.browser.profiles import ProfileManager

    config = PaySwitchConfig.load()
    profiles_dir = config.data_dir / "profiles"
    profile_manager = ProfileManager(data_dir=profiles_dir)

    # --list 模式：列出所有 Profile
    if list_profiles:
        _login_list_profiles(profile_manager)
        return

    # platform 参数对于 --logout 和正常登录都是必须的
    if platform is None:
        _print_error("请指定平台标识，例如：payswitch login deepseek")
        raise typer.Exit(code=1)

    # --logout 模式：删除指定平台的 Profile
    if logout:
        _login_logout(platform, profile_manager)
        return

    # 正常登录流程
    asyncio.run(_login_browser(platform, headed, config, profile_manager))


def _login_list_profiles(profile_manager) -> None:
    """列出所有已保存的 Profile。"""
    profiles = profile_manager.list_profiles()

    if _state.json_output:
        data = [
            {
                "platform": p.platform,
                "display_name": p.display_name,
                "status": p.status,
                "logged_in_at": str(p.logged_in_at) if p.logged_in_at else None,
                "last_used_at": str(p.last_used_at) if p.last_used_at else None,
            }
            for p in profiles
        ]
        _print_json(data)
        return

    if not profiles:
        console.print("[dim]暂无已登录的平台 Profile。[/dim]")
        console.print(
            "使用 [bold cyan]payswitch login <platform>[/bold cyan] 登录平台。"
        )
        return

    table = Table(title="已登录的平台 Profile", border_style="cyan")
    table.add_column("平台标识", style="bold cyan")
    table.add_column("展示名称")
    table.add_column("状态")
    table.add_column("登录时间")
    table.add_column("最近使用")

    for profile in profiles:
        status_style = {
            "active": "green",
            "expired": "yellow",
            "unknown": "dim",
        }.get(profile.status, "white")

        status_label = {
            "active": "活跃",
            "expired": "已过期",
            "unknown": "未知",
        }.get(profile.status, profile.status)

        table.add_row(
            profile.platform,
            profile.display_name,
            f"[{status_style}]{status_label}[/{status_style}]",
            _format_datetime(profile.logged_in_at),
            _format_datetime(profile.last_used_at),
        )

    console.print(table)


def _login_logout(platform: str, profile_manager) -> None:
    """退出登录，删除指定平台 Profile。"""
    existing = profile_manager.get_profile(platform)
    if existing is None:
        _print_error(f"平台 '{platform}' 的 Profile 不存在，无需退出登录")
        raise typer.Exit(code=1)

    confirmed = typer.confirm(
        f"确认退出 '{platform}' 的登录？此操作将删除本地保存的登录状态。",
        default=False,
    )
    if not confirmed:
        console.print("[dim]已取消退出登录操作。[/dim]")
        return

    profile_manager.delete_profile(platform)

    if _state.json_output:
        _print_json({"success": True, "platform": platform})
    else:
        console.print(f"[green]OK[/green] 已退出 [bold]{platform}[/bold] 的登录。")


async def _login_browser(
    platform: str,
    headed: bool,
    config,
    profile_manager,
) -> None:
    """启动浏览器引导用户完成登录。"""
    from payswitch.adapters import AdapterRegistry
    from payswitch.browser.controller import BrowserController
    from payswitch.browser.display import detect_display_mode

    # 查找适配器获取 login_url
    adapter = AdapterRegistry.get(platform)
    if adapter is not None:
        login_url = adapter.__class__.login_url
        display_name = adapter.__class__.display_name
    else:
        # 无适配器：提示用户输入登录 URL
        console.print(
            f"[yellow]未找到平台 '{platform}' 的适配器，请手动输入登录页面 URL。[/yellow]"
        )
        login_url = typer.prompt("请输入登录页面 URL")
        display_name = platform

    if not login_url:
        _print_error("登录 URL 为空，无法继续")
        raise typer.Exit(code=1)

    # 创建或获取 Profile
    profile = profile_manager.create_profile(
        platform=platform,
        display_name=display_name,
        top_up_url=adapter.__class__.top_up_url if adapter else None,
    )
    profile_dir = profile_manager.get_profile_dir(platform)

    # 判断是否使用有头模式
    if headed:
        use_headless = False
    else:
        detected_mode = detect_display_mode()
        from payswitch.models.types import DisplayMode
        use_headless = (detected_mode != DisplayMode.headed)

    console.print(
        Panel(
            f"[bold]平台：[/bold]{display_name}\n"
            f"[bold]登录页面：[/bold]{login_url}\n"
            f"[bold]浏览器模式：[/bold]{'有头（可见窗口）' if not use_headless else '无头'}",
            title="[cyan]准备登录[/cyan]",
            border_style="cyan",
        )
    )

    browser = BrowserController()
    try:
        console.print("[dim]正在启动浏览器...[/dim]")
        await browser.launch(profile_dir=profile_dir, headless=use_headless)

        console.print(f"[dim]正在导航到登录页面：{login_url}[/dim]")
        await browser.navigate(login_url)

        console.print(
            Panel(
                f"[bold yellow]请在浏览器中完成 {display_name} 的登录操作[/bold yellow]\n\n"
                "完成登录后，返回此终端并按 [bold]Enter[/bold] 键确认保存登录状态。",
                title="[yellow]等待登录[/yellow]",
                border_style="yellow",
                padding=(1, 2),
            )
        )

        # 等待用户在浏览器中完成登录
        typer.prompt("按 Enter 键确认已完成登录", default="", show_default=False)

        # 登录确认后做一次轻量校验，避免误将未登录状态写成 active。
        if not await _verify_login_state(browser.page, platform):
            _print_error(
                f"未检测到 {display_name} 的有效登录态，请在浏览器中完成登录后重试。"
            )
            raise typer.Exit(code=1)

        # 保存 Profile：更新登录时间和状态
        profile_manager.update_login_time(platform)

        if _state.json_output:
            _print_json({
                "success": True,
                "platform": platform,
                "display_name": display_name,
                "status": "active",
            })
        else:
            console.print(
                f"[green]OK[/green] 已成功保存 [bold]{display_name}[/bold] 的登录状态。"
            )

    except Exception as exc:
        _print_error(f"登录过程中发生错误：{exc}")
        raise typer.Exit(code=1)
    finally:
        await browser.close()


async def _verify_login_state(page, platform: str) -> bool:
    """在用户按 Enter 后做一次轻量登录态校验。"""
    current_url = page.url.lower()
    if any(token in current_url for token in ("login", "sign_in", "signin", "passport")):
        return False

    if platform == "kimi":
        # Kimi 未登录首页通常包含这个提示文案。
        return await page.locator("text=登录以同步历史会话").count() == 0

    return True


# ---------------------------------------------------------------------------
# browser-lite — 轻量浏览器识别/点击（本地 computer-use 能力）
# ---------------------------------------------------------------------------
@app.command("browser-lite")
def browser_lite(
    platform: Annotated[
        str,
        typer.Argument(help="平台标识（用于复用本地登录 Profile），如 kimi / deepseek。"),
    ],
    url: Annotated[
        str,
        typer.Option("--url", help="目标页面 URL。"),
    ],
    click_index: Annotated[
        Optional[int],
        typer.Option("--click-index", help="识别后按索引点击（0-based）。"),
    ] = None,
    click_text: Annotated[
        Optional[str],
        typer.Option("--click-text", help="识别后按文本匹配点击（模糊匹配）。"),
    ] = None,
    exact: Annotated[
        bool,
        typer.Option("--exact", help="与 --click-text 搭配，启用精确匹配。"),
    ] = False,
    limit: Annotated[
        int,
        typer.Option("--limit", help="最多输出多少个可点击元素。"),
    ] = 40,
    wait_seconds: Annotated[
        float,
        typer.Option("--wait-seconds", help="导航完成后额外等待多少秒再识别。"),
    ] = 2.0,
    headed: Annotated[
        bool,
        typer.Option("--headed", help="强制使用有头浏览器。"),
    ] = False,
) -> None:
    """轻量 browser control 调试命令：识别可点击元素并执行一次点击。"""
    from payswitch.models.config import PaySwitchConfig
    from payswitch.browser.profiles import ProfileManager

    config = PaySwitchConfig.load()
    profile_manager = ProfileManager(data_dir=config.data_dir / "profiles")
    profile = profile_manager.get_profile(platform)
    uses_user_chrome = bool(config.chrome_cdp_url.strip() or config.chrome_user_data_dir.strip())
    if profile is None and not uses_user_chrome:
        _print_error(f"平台 '{platform}' 的 Profile 不存在，请先执行 payswitch login {platform}")
        raise typer.Exit(code=1)

    asyncio.run(
        _browser_lite_run(
            platform=platform,
            url=url,
            headed=headed,
            limit=limit,
            wait_seconds=wait_seconds,
            click_index=click_index,
            click_text=click_text,
            exact=exact,
            config=config,
            profile_manager=profile_manager,
        )
    )


async def _browser_lite_run(
    platform: str,
    url: str,
    headed: bool,
    limit: int,
    wait_seconds: float,
    click_index: Optional[int],
    click_text: Optional[str],
    exact: bool,
    config,
    profile_manager,
) -> None:
    from payswitch.browser.controller import BrowserController, BrowserControllerError
    from payswitch.browser.display import detect_display_mode
    from payswitch.models.types import DisplayMode

    uses_user_chrome = bool(
        config.chrome_cdp_url.strip() or config.chrome_user_data_dir.strip()
    )
    profile_dir = None if uses_user_chrome else profile_manager.get_profile_dir(platform)
    use_headless = not headed and (detect_display_mode() != DisplayMode.headed)
    chrome_kwargs = {}
    expected_email = config.chrome_expected_profile_email.strip()
    if expected_email:
        from payswitch.browser.chrome_profiles import (
            identity_matches_email,
            resolve_cdp_profile_identity,
            resolve_profile_identity,
        )

        identity = None
        if config.chrome_cdp_url.strip():
            identity = resolve_cdp_profile_identity(config.chrome_cdp_url.strip())
        elif config.chrome_user_data_dir.strip():
            identity = resolve_profile_identity(
                config.chrome_user_data_dir,
                config.chrome_profile_directory or "Default",
            )
        if not identity_matches_email(identity, expected_email):
            actual = "<unknown>"
            if identity is not None:
                actual = (
                    f"{identity.user_name or '<empty>'} "
                    f"({identity.profile_directory}, {identity.user_data_dir})"
                )
            raise BrowserControllerError(
                "Chrome profile identity mismatch: "
                f"expected {expected_email}, got {actual}"
            )

    if config.chrome_cdp_url.strip():
        chrome_kwargs["chrome_cdp_url"] = config.chrome_cdp_url.strip()
    if config.chrome_user_data_dir.strip():
        chrome_kwargs["chrome_user_data_dir"] = Path(
            config.chrome_user_data_dir
        ).expanduser()
    if config.chrome_profile_directory.strip():
        chrome_kwargs["chrome_profile_directory"] = config.chrome_profile_directory.strip()
    if config.browser_channel.strip():
        chrome_kwargs["browser_channel"] = config.browser_channel.strip()

    browser = BrowserController()
    try:
        await browser.launch(
            profile_dir=profile_dir,
            headless=use_headless,
            **chrome_kwargs,
        )
        await browser.navigate(url)
        try:
            await browser.page.wait_for_load_state("networkidle", timeout=5_000)
        except Exception:
            pass
        if wait_seconds > 0:
            await browser.page.wait_for_timeout(wait_seconds * 1000)
        clickables = await browser.list_clickable_elements(limit=limit)

        clicked_payload = None
        if click_index is not None and click_text:
            raise BrowserControllerError("--click-index 与 --click-text 不能同时使用")
        if click_index is not None:
            clicked_payload = await browser.click_clickable_index(click_index)
        elif click_text:
            clicked_payload = await browser.click_clickable_text(click_text, exact=exact)

        if _state.json_output:
            _print_json(
                {
                    "platform": platform,
                    "url": await browser.get_current_url(),
                    "count": len(clickables),
                    "clicked": clicked_payload,
                    "clickables": clickables,
                }
            )
            return

        console.print(
            Panel(
                f"[bold]平台：[/bold]{platform}\n"
                f"[bold]URL：[/bold]{await browser.get_current_url()}\n"
                f"[bold]识别结果：[/bold]{len(clickables)} 个可点击元素",
                title="[cyan]Browser Lite[/cyan]",
                border_style="cyan",
            )
        )
        table = Table(title="可点击元素（前 N 项）", border_style="cyan")
        table.add_column("Index", style="bold cyan")
        table.add_column("Tag", style="magenta")
        table.add_column("Text")
        table.add_column("Selector", overflow="fold")
        for item in clickables:
            table.add_row(
                str(item.get("index")),
                str(item.get("tag")),
                str(item.get("text") or ""),
                str(item.get("selector") or ""),
            )
        console.print(table)
        if clicked_payload is not None:
            console.print(
                f"[green]OK[/green] 已点击 index={clicked_payload.get('index')} "
                f"text={clicked_payload.get('text')!r}"
            )

    except Exception as exc:
        _print_error(f"browser-lite 执行失败：{exc}")
        raise typer.Exit(code=1)
    finally:
        await browser.close()


# ---------------------------------------------------------------------------
# external-run — 外部 Agent 驱动的受控 checkout
# ---------------------------------------------------------------------------
@app.command("external-run")
def external_run(
    amount: Annotated[float, typer.Argument(help="支付金额（单位：元）。")],
    payee: Annotated[str, typer.Argument(help="收款方标识。")],
    actions: Annotated[
        Path,
        typer.Option("--actions", help="外部 Agent 动作 JSON 文件。"),
    ],
    reason: Annotated[
        str,
        typer.Option("--reason", "-r", help="支付原因（记录用途）。"),
    ] = "",
    method: Annotated[
        Optional[str],
        typer.Option("--method", "-m", help="支付方式：alipay_qr / bankcard / stripe / auto。"),
    ] = None,
    idempotency_key: Annotated[
        Optional[str],
        typer.Option("--idempotency-key", "-k", help="幂等键（防止重复支付）。"),
    ] = None,
    stop_on_human: Annotated[
        bool,
        typer.Option("--stop-on-human", help="检测到二维码/敏感/确认时通知后立即返回。"),
    ] = False,
) -> None:
    """由外部 Agent 提供动作，Payswitch 执行、检测、通知、记账。"""
    from payswitch.engine.external_runner import ExternalAction, ExternalCheckoutRunner
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import PaymentMethod

    if amount <= 0:
        _print_error(f"支付金额必须大于 0，当前值：{amount}")
        raise typer.Exit(code=1)
    if not actions.exists():
        _print_error(f"动作文件不存在：{actions}")
        raise typer.Exit(code=1)

    payment_method = PaymentMethod.auto
    if method:
        try:
            payment_method = PaymentMethod(method)
        except ValueError:
            valid_methods = [m.value for m in PaymentMethod]
            _print_error(
                f"不支持的支付方式：'{method}'，有效选项：{', '.join(valid_methods)}"
            )
            raise typer.Exit(code=1)

    try:
        raw_actions = json.loads(actions.read_text(encoding="utf-8"))
        action_items = [ExternalAction.model_validate(item) for item in raw_actions]
    except Exception as exc:
        _print_error(f"动作文件解析失败：{type(exc).__name__}: {exc}")
        raise typer.Exit(code=1)

    config = PaySwitchConfig.load()
    runner = ExternalCheckoutRunner(config)
    try:
        tx = asyncio.run(
            runner.run(
                amount=amount,
                payee=payee,
                actions=action_items,
                reason=reason,
                method=payment_method,
                idempotency_key=idempotency_key,
                stop_on_human=stop_on_human,
            )
        )
    finally:
        runner.close()

    _spend_print_result(tx, dry_run=False)


# ---------------------------------------------------------------------------
# spend — 发起支付（核心命令）
# ---------------------------------------------------------------------------
@app.command("spend")
def spend(
    amount: Annotated[float, typer.Argument(help="支付金额（单位：元）。")],
    payee: Annotated[str, typer.Argument(help="收款方标识，如 deepseek / kimi。")],
    reason: Annotated[
        str,
        typer.Option("--reason", "-r", help="支付原因（记录用途）。"),
    ] = "",
    method: Annotated[
        Optional[str],
        typer.Option("--method", "-m", help="指定支付方式：alipay_qr / bankcard / stripe / auto。"),
    ] = None,
    mode: Annotated[
        Optional[str],
        typer.Option("--mode", help="执行模式：script / smart / human_takeover。"),
    ] = None,
    idempotency_key: Annotated[
        Optional[str],
        typer.Option("--idempotency-key", "-k", help="幂等键（防止重复支付）。"),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="模拟执行，不实际发起支付。"),
    ] = False,
    url: Annotated[
        Optional[str],
        typer.Option("--url", help="智能模式目标 URL（无适配器时需要提供）。"),
    ] = None,
) -> None:
    """发起一笔支付请求。

    Agent 调用此命令后，Pay-Switch 自动完成支付流程的 80-90%，
    在需要人类确认时暂停等待（扫码/输密码/点确认）。

    示例：
      payswitch spend 200 deepseek --reason "充值 API 额度"
      payswitch spend 50 kimi --method alipay_qr
      payswitch spend 100 deepseek --idempotency-key task-abc-123
      payswitch spend 200 deepseek --dry-run
    """
    from payswitch.models.config import PaySwitchConfig
    from payswitch.models.types import PaymentMethod
    from payswitch.engine.orchestrator import PaymentOrchestrator, PaySwitchError

    # 金额校验
    if amount <= 0:
        _print_error(f"支付金额必须大于 0，当前值：{amount}")
        raise typer.Exit(code=1)

    # 解析支付方式
    payment_method = PaymentMethod.auto
    if method:
        try:
            payment_method = PaymentMethod(method)
        except ValueError:
            valid_methods = [m.value for m in PaymentMethod]
            _print_error(
                f"不支持的支付方式：'{method}'，"
                f"有效选项：{', '.join(valid_methods)}"
            )
            raise typer.Exit(code=1)

    # 加载配置
    config = PaySwitchConfig.load()

    # 非 JSON 模式：显示支付计划面板
    if not _state.json_output:
        plan_lines = [
            f"[bold]收款方：[/bold]{payee}",
            f"[bold]金额：[/bold][yellow]{_format_amount(amount)}[/yellow]",
        ]
        if reason:
            plan_lines.append(f"[bold]用途：[/bold]{reason}")
        if method:
            plan_lines.append(f"[bold]支付方式：[/bold]{method}")
        if idempotency_key:
            plan_lines.append(f"[bold]幂等键：[/bold]{idempotency_key}")
        if dry_run:
            plan_lines.append("[bold yellow]模式：[/bold yellow][yellow]模拟执行（不实际支付）[/yellow]")
        if url:
            plan_lines.append(f"[bold]目标 URL：[/bold]{url}")

        console.print(
            Panel(
                "\n".join(plan_lines),
                title="[cyan]支付计划[/cyan]",
                border_style="cyan",
            )
        )
        console.print("\n[bold]正在执行...[/bold]")

    # 执行支付
    tx = asyncio.run(
        _spend_execute(
            amount=amount,
            payee=payee,
            reason=reason,
            payment_method=payment_method,
            idempotency_key=idempotency_key,
            dry_run=dry_run,
            url=url,
            config=config,
        )
    )

    # 显示结果
    _spend_print_result(tx, dry_run)


async def _spend_execute(
    amount: float,
    payee: str,
    reason: str,
    payment_method,
    idempotency_key: Optional[str],
    dry_run: bool,
    url: Optional[str],
    config,
):
    """异步执行支付编排，返回 Transaction 对象。"""
    from payswitch.engine.orchestrator import PaymentOrchestrator

    orchestrator = PaymentOrchestrator(config)
    try:
        tx = await orchestrator.spend(
            amount=amount,
            payee=payee,
            reason=reason,
            method=payment_method,
            idempotency_key=idempotency_key,
            dry_run=dry_run,
            url=url,
        )
        return tx
    finally:
        orchestrator.close()


def _spend_print_result(tx, dry_run: bool) -> None:
    """显示支付结果。"""
    from payswitch.models.types import TransactionStatus

    if _state.json_output:
        _print_json_str(tx.model_dump_json(indent=2))
        return

    # 根据状态显示不同的结果面板
    if tx.status == TransactionStatus.completed:
        if dry_run:
            # dry_run 模式：展示模拟执行计划（步骤摘要）
            title = "[yellow]dry-run 模拟执行完成[/yellow]"

            # 显示每个模拟步骤（[dry_run] 前缀步骤）
            if tx.steps:
                total = len(tx.steps)
                console.print(
                    f"\n[bold yellow]模拟执行计划（共 {total} 步）：[/bold yellow]"
                )
                for i, step in enumerate(tx.steps):
                    step_icon = {
                        "success": "[green]OK[/green]",
                        "failed": "[red]FAIL[/red]",
                        "pending": "[yellow]WAIT[/yellow]",
                        "skipped": "[dim]SKIP[/dim]",
                    }.get(step.status, "•")
                    console.print(f"  {step_icon} {i + 1}/{total}：{step.description}")

            result_lines = [
                f"[bold]交易 ID（模拟）：[/bold]{tx.tx_id}",
                f"[bold]金额：[/bold][yellow]{_format_amount(tx.amount, tx.currency)}[/yellow]",
                f"[bold]收款方：[/bold]{tx.payee}",
            ]
            if tx.reason:
                result_lines.append(f"[bold]用途：[/bold]{tx.reason}")
            result_lines.append(
                "\n[bold yellow]注意：以上为模拟执行，未启动浏览器，未发起真实支付。[/bold yellow]"
            )
            result_lines.append(
                "[dim]去掉 --dry-run 选项后重新运行即可执行真实支付。[/dim]"
            )

            console.print(
                Panel(
                    "\n".join(result_lines),
                    title=title,
                    border_style="yellow",
                    padding=(1, 2),
                )
            )
        else:
            # 真实支付完成：显示步骤列表
            if tx.steps:
                total = len(tx.steps)
                for i, step in enumerate(tx.steps):
                    step_icon = {
                        "success": "[green]OK[/green]",
                        "failed": "[red]FAIL[/red]",
                        "pending": "[yellow]WAIT[/yellow]",
                        "skipped": "[dim]SKIP[/dim]",
                    }.get(step.status, "•")
                    console.print(f"  {step_icon} 步骤 {i + 1}/{total}：{step.description}")

            result_lines = [
                f"[bold]交易 ID：[/bold]{tx.tx_id}",
                f"[bold]金额：[/bold][green]{_format_amount(tx.amount, tx.currency)}[/green]",
                f"[bold]收款方：[/bold]{tx.payee}",
            ]
            if tx.completed_at:
                result_lines.append(f"[bold]完成时间：[/bold]{_format_datetime(tx.completed_at)}")

            console.print(
                Panel(
                    "\n".join(result_lines),
                    title="[green]支付完成[/green]",
                    border_style="green",
                    padding=(1, 2),
                )
            )

    elif tx.status == TransactionStatus.human_action_required:
        # 需要人类介入
        action_desc = ""
        if tx.human_action:
            action_type_labels = {
                "scan_qr": "请在弹出的浏览器窗口中扫码支付",
                "fill_form": "请在浏览器中填写支付信息",
                "confirm": "请在浏览器中确认支付",
                "takeover": "请在浏览器中手动完成支付",
            }
            action_desc = action_type_labels.get(
                tx.human_action.action_type,
                f"请完成操作：{tx.human_action.action_type}"
            )

        console.print(
            Panel(
                f"[bold magenta]需要人工操作[/bold magenta]\n\n"
                f"{action_desc}\n\n"
                f"[bold]交易 ID：[/bold]{tx.tx_id}\n"
                f"[bold]金额：[/bold]{_format_amount(tx.amount, tx.currency)}\n\n"
                f"[dim]操作完成后，运行以下命令确认：[/dim]\n"
                f"  [cyan]payswitch confirm {tx.tx_id}[/cyan]",
                title="[magenta]等待人工操作[/magenta]",
                border_style="magenta",
                padding=(1, 2),
            )
        )

    elif tx.status == TransactionStatus.failed:
        error_msg = tx.error or "未知错误"
        console.print(
            Panel(
                f"[bold red]支付失败[/bold red]\n\n"
                f"[bold]原因：[/bold]{error_msg}\n\n"
                f"[bold]交易 ID：[/bold]{tx.tx_id}",
                title="[red]支付失败[/red]",
                border_style="red",
                padding=(1, 2),
            )
        )
        raise typer.Exit(code=1)

    elif tx.status == TransactionStatus.timeout:
        console.print(
            Panel(
                f"[bold red]支付超时[/bold red]\n\n"
                f"[bold]交易 ID：[/bold]{tx.tx_id}\n"
                f"操作在规定时间内未完成，请检查后重试。",
                title="[red]超时[/red]",
                border_style="red",
                padding=(1, 2),
            )
        )
        raise typer.Exit(code=1)

    else:
        # 其他状态
        status_label = _get_status_label(tx.status.value)
        console.print(
            Panel(
                f"[bold]交易 ID：[/bold]{tx.tx_id}\n"
                f"[bold]当前状态：[/bold]{status_label}",
                title=f"[cyan]交易状态：{status_label}[/cyan]",
                border_style="cyan",
            )
        )


# ---------------------------------------------------------------------------
# confirm — 确认人类操作已完成
# ---------------------------------------------------------------------------
@app.command("confirm")
def confirm(
    tx_id: Annotated[str, typer.Argument(help="交易 ID（格式：txn_xxxxxxxx）。")],
    success: Annotated[
        bool,
        typer.Option("--success/--failed", help="确认操作是否成功（默认成功）。"),
    ] = True,
) -> None:
    """确认人类介入操作已完成，恢复支付流程。

    当 Pay-Switch 等待人类操作（如扫码支付）时，
    人类完成操作后运行此命令通知 Pay-Switch 继续。

    示例：
      payswitch confirm txn_abc123ef
      payswitch confirm txn_abc123ef --failed
    """
    from payswitch.models.config import PaySwitchConfig
    from payswitch.engine.orchestrator import PaymentOrchestrator, PaySwitchError
    from payswitch.models.types import TransactionStatus

    config = PaySwitchConfig.load()

    # 先查询交易是否存在
    db_path = config.data_dir / "payswitch.db"
    from payswitch.engine.ledger import Ledger
    ledger = Ledger(db_path=db_path)

    try:
        tx = ledger.get(tx_id)
        if tx is None:
            _print_error(f"交易不存在：{tx_id}")
            raise typer.Exit(code=1)

        # 显示待确认信息
        if not _state.json_output:
            console.print(
                Panel(
                    f"[bold]交易 ID：[/bold]{tx_id}\n"
                    f"[bold]金额：[/bold]{_format_amount(tx.amount, tx.currency)}\n"
                    f"[bold]收款方：[/bold]{tx.payee}\n"
                    f"[bold]当前状态：[/bold]{_get_status_label(tx.status.value)}\n"
                    f"[bold]操作：[/bold]{'确认成功' if success else '标记失败'}",
                    title="[cyan]确认交易[/cyan]",
                    border_style="cyan",
                )
            )

        if not success:
            # 标记为失败
            from datetime import datetime, timezone
            ledger.update_status(
                tx_id,
                TransactionStatus.failed,
                completed_at=datetime.now(timezone.utc),
                error="用户确认：操作失败",
                steps=tx.steps,
            )
            updated_tx = ledger.get(tx_id)
            if _state.json_output:
                _print_json_str(updated_tx.model_dump_json(indent=2) if updated_tx else "{}")
            else:
                console.print(f"[red]FAIL[/red] 交易 [bold]{tx_id}[/bold] 已标记为失败。")
            return

        # 调用 orchestrator.confirm() 确认成功
        orchestrator = PaymentOrchestrator(config)
        try:
            updated_tx = asyncio.run(orchestrator.confirm(tx_id))
        except PaySwitchError as exc:
            _print_error(str(exc))
            raise typer.Exit(code=1)
        finally:
            orchestrator.close()

        if _state.json_output:
            _print_json_str(updated_tx.model_dump_json(indent=2))
        else:
            console.print(
                Panel(
                    f"[bold]交易 ID：[/bold]{updated_tx.tx_id}\n"
                    f"[bold]金额：[/bold][green]{_format_amount(updated_tx.amount, updated_tx.currency)}[/green]\n"
                    f"[bold]状态：[/bold][green]{_get_status_label(updated_tx.status.value)}[/green]\n"
                    f"[bold]完成时间：[/bold]{_format_datetime(updated_tx.completed_at)}",
                    title="[green]交易已确认[/green]",
                    border_style="green",
                    padding=(1, 2),
                )
            )
    finally:
        ledger.close()


# ---------------------------------------------------------------------------
# status — 查询交易状态
# ---------------------------------------------------------------------------
@app.command("status")
def status(
    tx_id: Annotated[str, typer.Argument(help="交易 ID（格式：txn_xxxxxxxx）。")],
    watch: Annotated[
        bool,
        typer.Option("--watch", "-w", help="持续监控交易状态直到终态。"),
    ] = False,
    interval: Annotated[
        int,
        typer.Option("--interval", help="--watch 模式下的轮询间隔（秒）。"),
    ] = 3,
) -> None:
    """查询指定交易的当前状态。

    显示交易的完整执行步骤、当前状态和错误信息（如有）。

    示例：
      payswitch status txn_abc123ef
      payswitch status txn_abc123ef --watch
      payswitch status txn_abc123ef --watch --interval 5
    """
    from payswitch.models.config import PaySwitchConfig
    from payswitch.engine.ledger import Ledger
    from payswitch.models.types import TransactionStatus

    config = PaySwitchConfig.load()
    db_path = config.data_dir / "payswitch.db"
    ledger = Ledger(db_path=db_path)

    # 终态集合：达到这些状态后不再轮询
    terminal_statuses = {
        TransactionStatus.completed,
        TransactionStatus.failed,
        TransactionStatus.cancelled,
        TransactionStatus.timeout,
    }

    try:
        if not watch:
            # 单次查询
            tx = ledger.get(tx_id)
            if tx is None:
                _print_error(f"交易不存在：{tx_id}")
                raise typer.Exit(code=1)
            _status_print_tx(tx)
        else:
            # --watch 模式：循环轮询直到终态
            if not _state.json_output:
                console.print(f"[dim]正在监控交易 {tx_id}，按 Ctrl+C 停止...[/dim]")

            try:
                while True:
                    tx = ledger.get(tx_id)
                    if tx is None:
                        _print_error(f"交易不存在：{tx_id}")
                        raise typer.Exit(code=1)

                    _status_print_tx(tx)

                    if tx.status in terminal_statuses:
                        break

                    if not _state.json_output:
                        console.print(
                            f"[dim]等待 {interval} 秒后重新查询...[/dim]"
                        )
                    time.sleep(interval)

            except KeyboardInterrupt:
                if not _state.json_output:
                    console.print("\n[dim]已停止监控。[/dim]")
    finally:
        ledger.close()


def _status_print_tx(tx) -> None:
    """将交易详情打印到终端。"""
    if _state.json_output:
        _print_json_str(tx.model_dump_json(indent=2))
        return

    # 状态样式
    status_style = _get_status_style(tx.status.value)
    status_label = _get_status_label(tx.status.value)

    # 构建基本信息
    info_lines = [
        f"[bold]交易 ID：[/bold]{tx.tx_id}",
        f"[bold]收款方：[/bold]{tx.payee}",
        f"[bold]金额：[/bold]{_format_amount(tx.amount, tx.currency)}",
        f"[bold]状态：[/bold][{status_style}]{status_label}[/{status_style}]",
        f"[bold]创建时间：[/bold]{_format_datetime(tx.created_at)}",
    ]

    if tx.reason:
        info_lines.append(f"[bold]用途：[/bold]{tx.reason}")
    if tx.payment_method:
        info_lines.append(f"[bold]支付方式：[/bold]{tx.payment_method.value}")
    if tx.execution_mode:
        mode_labels = {
            "script": "脚本模式",
            "smart": "智能模式",
            "human_takeover": "人类接管",
        }
        info_lines.append(
            f"[bold]执行模式：[/bold]{mode_labels.get(tx.execution_mode.value, tx.execution_mode.value)}"
        )
    if tx.completed_at:
        info_lines.append(f"[bold]完成时间：[/bold]{_format_datetime(tx.completed_at)}")
    if tx.error:
        info_lines.append(f"[bold red]错误信息：[/bold red]{tx.error}")
    if tx.idempotency_key:
        info_lines.append(f"[bold]幂等键：[/bold]{tx.idempotency_key}")

    console.print(
        Panel(
            "\n".join(info_lines),
            title=f"[{status_style}]交易状态[/{status_style}]",
            border_style=status_style,
            padding=(1, 2),
        )
    )

    # 显示执行步骤
    if tx.steps:
        console.print(f"\n[bold]执行步骤（共 {len(tx.steps)} 步）：[/bold]")
        for step in tx.steps:
            step_icon = {
                "success": "[green]OK[/green]",
                "failed": "[red]FAIL[/red]",
                "pending": "[yellow]WAIT[/yellow]",
                "skipped": "[dim]SKIP[/dim]",
            }.get(step.status, "•")
            duration = step.duration_seconds()
            dur_str = f" [dim]({duration:.1f}s)[/dim]" if duration else ""
            console.print(
                f"  {step_icon} [{step.step_index + 1}] {step.description}{dur_str}"
            )

    # 若正在等待人类操作，显示提示
    if tx.human_action and not tx.human_action.is_completed():
        action_label = {
            "scan_qr": "扫码支付",
            "fill_form": "填写表单",
            "confirm": "确认支付",
            "takeover": "手动操作",
        }.get(tx.human_action.action_type, tx.human_action.action_type)

        console.print(
            Panel(
                f"[yellow]正在等待人工操作：{action_label}[/yellow]\n\n"
                f"完成后请运行：[cyan]payswitch confirm {tx.tx_id}[/cyan]",
                border_style="yellow",
                padding=(0, 2),
            )
        )


# ---------------------------------------------------------------------------
# history — 查看历史交易
# ---------------------------------------------------------------------------
@app.command("history")
def history(
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="最多显示的记录数。"),
    ] = 10,
    offset: Annotated[
        int,
        typer.Option("--offset", help="分页偏移量。"),
    ] = 0,
    payee: Annotated[
        Optional[str],
        typer.Option("--payee", help="按收款方过滤。"),
    ] = None,
    status_filter: Annotated[
        Optional[str],
        typer.Option("--status", help="按状态过滤：pending / completed / failed 等。"),
    ] = None,
    export_csv: Annotated[
        Optional[str],
        typer.Option("--export-csv", help="导出为 CSV 文件（指定文件路径）。"),
    ] = None,
) -> None:
    """查看历史支付记录。

    以表格形式展示交易历史，支持按收款方、状态过滤，
    也可导出为 CSV 文件。

    示例：
      payswitch history
      payswitch history --limit 20 --payee deepseek
      payswitch history --status completed --export-csv ./records.csv
    """
    from payswitch.models.config import PaySwitchConfig
    from payswitch.engine.ledger import Ledger
    from payswitch.models.types import TransactionStatus

    config = PaySwitchConfig.load()
    db_path = config.data_dir / "payswitch.db"
    ledger = Ledger(db_path=db_path)

    # 解析状态过滤参数
    status_enum = None
    if status_filter:
        try:
            status_enum = TransactionStatus(status_filter)
        except ValueError:
            valid_statuses = [s.value for s in TransactionStatus]
            _print_error(
                f"无效的状态过滤值：'{status_filter}'，"
                f"有效选项：{', '.join(valid_statuses)}"
            )
            ledger.close()
            raise typer.Exit(code=1)

    try:
        # 导出 CSV 模式
        if export_csv:
            csv_path = Path(export_csv)
            count = ledger.export_csv(
                filepath=csv_path,
                status=status_enum,
                payee=payee,
            )
            if _state.json_output:
                _print_json({
                    "success": True,
                    "exported_count": count,
                    "file": str(csv_path.resolve()),
                })
            else:
                if count > 0:
                    console.print(
                        f"[green]OK[/green] 已导出 [bold]{count}[/bold] 条记录到："
                        f"[bold]{csv_path.resolve()}[/bold]"
                    )
                else:
                    console.print("[yellow]没有匹配的记录，CSV 文件未创建。[/yellow]")
            return

        # 查询交易列表
        transactions = ledger.list_transactions(
            limit=limit,
            offset=offset,
            status=status_enum,
            payee=payee,
        )

        if _state.json_output:
            data = [json.loads(tx.model_dump_json()) for tx in transactions]
            _print_json(data)
            return

        if not transactions:
            console.print("[dim]暂无匹配的交易记录。[/dim]")
            return

        # 构建表格
        filter_desc = []
        if payee:
            filter_desc.append(f"收款方={payee}")
        if status_filter:
            filter_desc.append(f"状态={status_filter}")
        filter_str = f"（过滤：{', '.join(filter_desc)}）" if filter_desc else ""

        table = Table(
            title=f"历史交易记录{filter_str}",
            border_style="cyan",
            show_lines=False,
        )
        table.add_column("交易 ID", style="dim", no_wrap=True)
        table.add_column("收款方", style="bold")
        table.add_column("金额", justify="right")
        table.add_column("状态")
        table.add_column("用途", max_width=20)
        table.add_column("创建时间", no_wrap=True)

        for tx in transactions:
            status_style = _get_status_style(tx.status.value)
            status_label = _get_status_label(tx.status.value)

            table.add_row(
                tx.tx_id,
                tx.payee,
                _format_amount(tx.amount, tx.currency),
                f"[{status_style}]{status_label}[/{status_style}]",
                tx.reason or "-",
                _format_datetime(tx.created_at),
            )

        console.print(table)
        console.print(
            f"[dim]显示 {len(transactions)} 条记录（偏移量 {offset}），"
            f"使用 --limit / --offset 分页[/dim]"
        )

    finally:
        ledger.close()


# ---------------------------------------------------------------------------
# config — 查看和修改配置
# ---------------------------------------------------------------------------
@app.command("config")
def config_cmd(
    key: Annotated[
        Optional[str],
        typer.Argument(help="配置项名称（留空则显示全部配置）。"),
    ] = None,
    value: Annotated[
        Optional[str],
        typer.Argument(help="要设置的新值（留空则显示当前值）。"),
    ] = None,
    reset: Annotated[
        bool,
        typer.Option("--reset", help="重置为默认配置。"),
    ] = False,
) -> None:
    """查看或修改 Pay-Switch 配置。

    不带参数时显示全部配置；指定 KEY 显示单项；
    指定 KEY VALUE 更新配置项。

    示例：
      payswitch config
      payswitch config max_per_transaction
      payswitch config max_per_transaction 1000
      payswitch config --reset
    """
    from payswitch.models.config import PaySwitchConfig

    config_path = Path.home() / ".payswitch" / "config.json"

    # --reset 模式：重置为默认值
    if reset:
        confirmed = typer.confirm(
            "确认将所有配置重置为默认值？此操作不可撤销。",
            default=False,
        )
        if not confirmed:
            console.print("[dim]已取消重置操作。[/dim]")
            return

        default_config = PaySwitchConfig()
        default_config.save(config_path)

        if _state.json_output:
            _print_json(json.loads(default_config.model_dump_json()))
        else:
            console.print("[green]OK[/green] 配置已重置为默认值。")
        return

    config = PaySwitchConfig.load(config_path)

    # 显示单项配置
    if key is not None and value is None:
        config_dict = json.loads(config.model_dump_json())
        if key not in config_dict:
            _print_error(
                f"不存在的配置项：'{key}'，"
                f"使用 'payswitch config' 查看所有可用配置项"
            )
            raise typer.Exit(code=1)

        if _state.json_output:
            _print_json({key: config_dict[key]})
        else:
            console.print(f"[bold]{key}[/bold] = {config_dict[key]}")
        return

    # 更新配置项
    if key is not None and value is not None:
        config_dict = json.loads(config.model_dump_json())
        if key not in config_dict:
            _print_error(
                f"不存在的配置项：'{key}'，"
                f"使用 'payswitch config' 查看所有可用配置项"
            )
            raise typer.Exit(code=1)

        # 类型推断与转换
        original_value = config_dict[key]
        try:
            converted_value = _coerce_config_value(key, value, original_value)
        except (ValueError, TypeError) as exc:
            _print_error(f"配置值格式错误：{exc}")
            raise typer.Exit(code=1)

        config = config.update(**{key: converted_value})

        if _state.json_output:
            _print_json({key: converted_value})
        else:
            console.print(
                f"[green]OK[/green] 配置已更新：[bold]{key}[/bold] = {converted_value}"
            )
        return

    # 显示全部配置
    config_dict = json.loads(config.model_dump_json())

    if _state.json_output:
        _print_json(config_dict)
        return

    # 配置项中文描述映射
    config_descriptions = {
        "max_per_transaction": ("单笔限额（元）", "安全限额"),
        "daily_limit": ("日累计限额（元）", "安全限额"),
        "whitelist": ("商户白名单", "安全限额"),
        "auto_confirm_threshold": ("自动确认阈值（元）", "安全限额"),
        "default_currency": ("默认货币", "货币"),
        "llm_provider": ("LLM 服务商", "LLM 配置"),
        "llm_api_key": ("LLM API Key（已加密）", "LLM 配置"),
        "llm_model": ("LLM 模型", "LLM 配置"),
        "computer_use_enabled": ("是否启用 Computer Use 兜底", "Computer Use"),
        "computer_use_driver": ("Computer Use 驱动：external/internal/hybrid", "Computer Use"),
        "computer_use_max_autonomous_category": (
            "Computer Use 可自治推进的最高步骤类别",
            "Computer Use",
        ),
        "chrome_cdp_url": ("已有 Chrome remote-debugging 地址", "浏览器上下文"),
        "chrome_user_data_dir": ("用户 Chrome User Data 根目录", "浏览器上下文"),
        "chrome_profile_directory": ("Chrome profile 子目录名", "浏览器上下文"),
        "chrome_expected_profile_email": ("期望 Chrome profile 登录邮箱", "浏览器上下文"),
        "browser_channel": ("Playwright 浏览器 channel", "浏览器上下文"),
        "display_mode": ("浏览器显示模式", "显示配置"),
        "novnc_port": ("noVNC 端口", "显示配置"),
        "transaction_timeout": ("交易超时时间（秒）", "超时配置"),
        "data_dir": ("数据目录", "存储配置"),
    }

    table = Table(title="Pay-Switch 当前配置", border_style="cyan")
    table.add_column("配置项", style="bold cyan", no_wrap=True)
    table.add_column("当前值")
    table.add_column("说明", style="dim")
    table.add_column("分类", style="dim")

    for cfg_key, cfg_value in config_dict.items():
        desc, category = config_descriptions.get(cfg_key, (cfg_key, "其他"))

        # 对 API Key 进行脱敏处理
        display_value = cfg_value
        if cfg_key == "llm_api_key" and cfg_value:
            display_value = "***已设置***"
        elif cfg_value is None:
            display_value = "[dim]（未设置）[/dim]"
        elif isinstance(cfg_value, list):
            display_value = ", ".join(cfg_value) if cfg_value else "[dim]（空）[/dim]"

        table.add_row(cfg_key, str(display_value), desc, category)

    console.print(table)
    console.print(
        "\n[dim]使用 [bold]payswitch config <key> <value>[/bold] 修改配置项[/dim]"
    )


def _coerce_config_value(key: str, value_str: str, original) -> object:
    """将字符串配置值转换为与原始值类型匹配的 Python 对象。"""
    if isinstance(original, bool):
        return value_str.lower() in ("true", "1", "yes", "on")
    elif isinstance(original, int):
        return int(value_str)
    elif isinstance(original, float):
        return float(value_str)
    elif isinstance(original, list):
        # 列表类型：逗号分隔的字符串
        if value_str.strip() == "":
            return []
        return [item.strip() for item in value_str.split(",") if item.strip()]
    elif original is None:
        # None 类型：尝试解析数字，否则保持字符串
        try:
            return int(value_str)
        except ValueError:
            try:
                return float(value_str)
            except ValueError:
                return value_str
    else:
        return value_str


# ---------------------------------------------------------------------------
# platforms — 管理已登录的平台
# ---------------------------------------------------------------------------
@app.command("platforms")
def platforms(
    action: Annotated[
        str,
        typer.Argument(help="操作：list / remove / refresh。"),
    ] = "list",
    platform: Annotated[
        Optional[str],
        typer.Argument(help="平台标识（remove/refresh 操作需要）。"),
    ] = None,
) -> None:
    """管理已登录的支付平台。

    列出所有已保存的平台 Profile、删除指定平台登录状态，
    或刷新 Profile 的有效性检测。

    示例：
      payswitch platforms list
      payswitch platforms remove deepseek
      payswitch platforms refresh kimi
    """
    from payswitch.models.config import PaySwitchConfig
    from payswitch.browser.profiles import ProfileManager
    from payswitch.adapters import AdapterRegistry

    config = PaySwitchConfig.load()
    profiles_dir = config.data_dir / "profiles"
    profile_manager = ProfileManager(data_dir=profiles_dir)

    if action == "list":
        _platforms_list(profile_manager, AdapterRegistry)

    elif action == "remove":
        if platform is None:
            _print_error("remove 操作需要指定平台标识，例如：payswitch platforms remove deepseek")
            raise typer.Exit(code=1)
        _platforms_remove(platform, profile_manager)

    elif action == "refresh":
        if platform is None:
            _print_error("refresh 操作需要指定平台标识，例如：payswitch platforms refresh deepseek")
            raise typer.Exit(code=1)
        _platforms_refresh(platform, profile_manager)

    else:
        _print_error(
            f"未知操作：'{action}'，有效操作：list / remove / refresh"
        )
        raise typer.Exit(code=1)


def _platforms_list(profile_manager, adapter_registry) -> None:
    """列出所有已注册适配器和已登录 Profile 状态。"""
    # 获取所有已注册适配器信息
    registered_adapters = adapter_registry.list_platforms()

    # 获取所有已登录的 Profile
    profiles = profile_manager.list_profiles()
    profile_by_platform = {p.platform: p for p in profiles}

    # 合并：已注册适配器 + 已登录但无适配器的 Profile
    all_platforms = {}
    for adapter_info in registered_adapters:
        name = adapter_info["name"]
        all_platforms[name] = {
            "name": name,
            "display_name": adapter_info["display_name"],
            "has_adapter": True,
            "login_url": adapter_info.get("login_url", ""),
            "top_up_url": adapter_info.get("top_up_url", ""),
            "supported_methods": adapter_info.get("supported_methods", []),
            "profile": profile_by_platform.get(name),
        }

    # 已登录但未注册适配器的平台
    for p_name, profile in profile_by_platform.items():
        if p_name not in all_platforms:
            all_platforms[p_name] = {
                "name": p_name,
                "display_name": profile.display_name,
                "has_adapter": False,
                "login_url": "",
                "top_up_url": "",
                "supported_methods": [],
                "profile": profile,
            }

    if _state.json_output:
        data = []
        for p_info in all_platforms.values():
            profile = p_info["profile"]
            data.append({
                "name": p_info["name"],
                "display_name": p_info["display_name"],
                "has_adapter": p_info["has_adapter"],
                "supported_methods": p_info["supported_methods"],
                "logged_in": profile is not None,
                "status": profile.status if profile else None,
                "logged_in_at": str(profile.logged_in_at) if profile and profile.logged_in_at else None,
            })
        _print_json(data)
        return

    if not all_platforms:
        console.print("[dim]暂无已注册的平台或已登录的 Profile。[/dim]")
        return

    table = Table(title="支付平台列表", border_style="cyan")
    table.add_column("平台标识", style="bold cyan", no_wrap=True)
    table.add_column("展示名称")
    table.add_column("适配器")
    table.add_column("支付方式")
    table.add_column("登录状态")
    table.add_column("最近登录")

    for p_info in sorted(all_platforms.values(), key=lambda x: x["name"]):
        profile = p_info["profile"]

        adapter_badge = "[green]✓ 已注册[/green]" if p_info["has_adapter"] else "[dim]无适配器[/dim]"
        methods_str = ", ".join(p_info["supported_methods"]) if p_info["supported_methods"] else "-"

        if profile is None:
            login_status = "[dim]未登录[/dim]"
            login_time = "-"
        else:
            status_colors = {"active": "green", "expired": "yellow", "unknown": "dim"}
            status_labels = {"active": "已登录", "expired": "已过期", "unknown": "状态未知"}
            s_color = status_colors.get(profile.status, "white")
            s_label = status_labels.get(profile.status, profile.status)
            login_status = f"[{s_color}]{s_label}[/{s_color}]"
            login_time = _format_datetime(profile.logged_in_at)

        table.add_row(
            p_info["name"],
            p_info["display_name"],
            adapter_badge,
            methods_str,
            login_status,
            login_time,
        )

    console.print(table)
    console.print(
        "\n[dim]使用 [bold]payswitch login <platform>[/bold] 登录平台[/dim]"
    )


def _platforms_remove(platform: str, profile_manager) -> None:
    """删除指定平台的 Profile。"""
    existing = profile_manager.get_profile(platform)
    if existing is None:
        _print_error(f"平台 '{platform}' 的 Profile 不存在")
        raise typer.Exit(code=1)

    if not _state.json_output:
        confirmed = typer.confirm(
            f"确认删除 '{platform}' 的登录状态？",
            default=False,
        )
        if not confirmed:
            console.print("[dim]已取消删除操作。[/dim]")
            return

    profile_manager.delete_profile(platform)

    if _state.json_output:
        _print_json({"success": True, "platform": platform})
    else:
        console.print(f"[green]OK[/green] 已删除 [bold]{platform}[/bold] 的登录状态。")


def _platforms_refresh(platform: str, profile_manager) -> None:
    """刷新指定平台 Profile 的有效性检测。"""
    session_status = profile_manager.check_session(platform)

    if session_status == "unknown":
        _print_error(f"平台 '{platform}' 的 Profile 不存在，请先运行 payswitch login {platform}")
        raise typer.Exit(code=1)

    if _state.json_output:
        _print_json({
            "platform": platform,
            "session_status": session_status,
        })
        return

    status_info = {
        "active": ("[green]活跃[/green]", "登录状态有效，无需重新登录"),
        "expired": ("[yellow]已过期[/yellow]", f"登录状态已超过 7 天，建议运行 payswitch login {platform} 重新登录"),
    }

    status_label, status_desc = status_info.get(
        session_status,
        (session_status, "状态未知")
    )

    console.print(
        Panel(
            f"[bold]平台：[/bold]{platform}\n"
            f"[bold]会话状态：[/bold]{status_label}\n"
            f"[dim]{status_desc}[/dim]",
            title="[cyan]会话状态检测[/cyan]",
            border_style="cyan",
        )
    )


# ---------------------------------------------------------------------------
# 主入口（开发调试用）
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    app()
