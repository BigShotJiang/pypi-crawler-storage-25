# Pay-Switch 🚦

> **Teach your AI agents how to spend money — safely.**
> AI Agent 支付编排层：不是钱包，不是充值系统，是支付 GPS。

[![PyPI version](https://img.shields.io/badge/pypi-v0.1.0-blue)]()
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-green)]()
[![License: MIT](https://img.shields.io/badge/license-MIT-yellow)]()
[![Docker Ready](https://img.shields.io/badge/docker-ready-2496ED)]()

---

## Why Pay-Switch?

LLM Agents 已经能写代码、发邮件、订机票 —— **但它们不会花钱**。

现实是：
- 🤖 Agent 想给 DeepSeek 充 API 额度，卡在登录页。
- 🙈 直接把信用卡暴露给 LLM？没人敢。
- 🔁 每个网站的支付流程都不一样，硬编码难以维护。
- 🛑 失控的 Agent 可能把预算一次刷爆。

**Pay-Switch 把"花钱"抽象成一条 CLI 命令**，让 Agent 只需要说 *"spend 200 on deepseek"*，剩下的导航 / 登录 / 确认 / 风控 / 人类兜底全部由 Pay-Switch 处理。

> Agent 写意图，Pay-Switch 管执行。

---

## Core Concept

Pay-Switch 不是浏览器自动化库，也不是支付网关。它是一个**支付编排器（Payment Orchestrator）**，核心是"确定性接口优先 + 受控 Computer Use 兜底 + 人类授权"。

```
┌─────────────────────────────────────────────────────────────┐
│                    AI Agent (Claude / GPT / ...)            │
│                            │                                │
│                  payswitch spend 200 deepseek                  │
└────────────────────────────┼────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                 Pay-Switch CLI / MCP Server                  │
│    ┌──────────────┬──────────────┬──────────────┐           │
│    │ Safety Guard │  Idempotency │   Audit Log  │           │
│    └──────────────┴──────────────┴──────────────┘           │
└────────────────────────────┬────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────┐
│              Execution Engine (Policy Gated)                 │
│                                                             │
│ Official API/A2A/MCP ▶ Script Adapter ▶ Computer Use        │
│       │                    │                  │             │
│       └────────────── Risk Gate + Evidence Log ─────────────┤
│                                                │             │
│                                                ▼             │
│                                  Human Authorization         │
│                                  (Chrome / noVNC / QR)       │
└────────────────────────────┬────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────┐
│               4-Layer Browser Architecture                   │
│  ① Smart Engine   ② Profile Isolation                       │
│  ③ Human Bridge   ④ Security Sandbox                        │
└─────────────────────────────────────────────────────────────┘
```

**Detection signals** Pay-Switch 会识别：QR 码、敏感表单、确认按钮、支付完成页 —— 在正确的时机切换模式或召唤人类。

---

## Quick Start

### 30 秒上手

```bash
# 1. 安装
pip install payswitch

# 2. 初始化（下载 Playwright 浏览器、创建 ~/.payswitch/）
payswitch setup

# 3. 登录目标站点（首次需人类完成，之后复用 profile）
payswitch login deepseek

# 4. 让 Agent 花钱
payswitch spend 200 deepseek --reason "充值 API 额度"
```

典型输出：

```
✓ Safety check passed (limit: 500/day, remaining: 500)
✓ Idempotency key: spd_01HXYZ...
→ Trying script mode for deepseek... OK
→ Navigating to topup page... OK
→ Filling amount: 200 CNY... OK
⚠ Payment confirmation required
  → Launching human takeover (local popup)
✓ Payment completed in 47s
  Transaction: TXN-20250115-8832
```

---

## CLI Reference

| Command | 说明 |
|---|---|
| `payswitch setup` | 首次初始化环境（浏览器、数据库、配置） |
| `payswitch login <platform>` | 登录并持久化 session profile |
| `payswitch browser-lite <platform> --url <url>` | 识别页面可点击元素，并可按索引/文本点击一次（轻量 computer-use） |
| `payswitch spend <amount> <platform> [--reason]` | **核心命令**：执行一次支付 |
| `payswitch confirm <txn_id>` | 二次确认待处理交易 |
| `payswitch status <txn_id>` | 查看交易状态 |
| `payswitch history [--limit N]` | 查询历史交易记录 |
| `payswitch config [--set KEY VALUE]` | 读写配置（限额、白名单、LLM Key 等） |
| `payswitch platforms` | 列出支持的站点适配器 |

> All commands 支持 `--json` 输出，方便 Agent 程序化解析。

---

## Execution Ladder

Pay-Switch 对同一个支付意图按稳定性和风险逐级执行：

1. **Official API / A2A / MCP**：当支付宝、Stripe、平台方提供官方 Agent/商户接口时优先使用。
2. **Script Adapter**：已知站点使用确定性的 Playwright 路径，适合 Kimi、DeepSeek、九号邮箱这类可沉淀经验的流程。
3. **Controlled Computer Use**：未知或改版站点用模型视觉能力探索登录态、入口、套餐、收银台，但只能推进到付款前或人工接管点。
4. **Human Authorization**：二维码、CVV、OTP、支付密码、最终付款、自动续费协议等必须交给人。

### 🏎️ Script Mode（已知站点快速路径）

针对适配过的站点（DeepSeek / Kimi / Qwen / ...），使用预先调校好的 Playwright 脚本：

- ✅ **快** — 10 秒内完成，无 LLM 调用成本
- ✅ **稳** — 确定性路径，可重放
- ❌ 站点改版可能失效 → 自动回退到 Controlled Computer Use

### 🧠 Controlled Computer Use（智能兜底）

用 LLM + 视觉理解实时解析页面。当前实现先复用 SkyvernEngine 作为视觉驱动，但外面包了一层 Pay-Switch 自己的 `ComputerUseExplorer` 和 `RiskGate`：

- ✅ **通用** — 理论上任何支付页都能跑
- ✅ **自愈** — 站点改版不需要手动修脚本
- ✅ **可控** — 步骤会标记 `category` / `risk`，超过边界就停止
- ❌ 慢 + 有 LLM 成本 → 作为回退存在

自治边界：

| Step category | 可自治 | 说明 |
|---|---:|---|
| `nav` | ✅ | 打开页面、滚动、关闭普通弹窗 |
| `identity` | ✅/⚠️ | 检查登录态；真正登录密码/2FA 仍交给人 |
| `checkout_prep` | ✅ | 找入口、选套餐候选、进入收银台 |
| `sensitive` | ❌ | CVV、验证码、支付密码、银行卡等 |
| `final_authorization` | ❌ | 确认付款、订阅、自动续费协议 |

默认配置：

```yaml
computer_use_enabled: true
computer_use_driver: external
computer_use_max_autonomous_category: checkout_prep
```

浏览器上下文也必须分清楚：

| Context | 说明 |
|---|---|
| Pay-Switch managed profile | 默认的 `~/.payswitch/profiles/<platform>/browser_data`，适合隔离测试，但不是用户日常 Chrome |
| User Chrome profile | `chrome_user_data_dir` + `chrome_profile_directory` 指向用户正常 Chrome profile |
| Existing Chrome via CDP | `chrome_cdp_url` 连接已经用 `--remote-debugging-port` 打开的 Chrome |

真实支付/订阅测试应优先使用用户指定的 Chrome 上下文，而不是让 Pay-Switch 新建一个空 Chromium：

```bash
payswitch settings wizard
payswitch settings profile
```

`settings wizard` 是推荐的配置引导入口。它会用新手可理解的说明带你完成：先选择要启用的浏览器（当前 profile 发现支持 `chrome` / `chromium`，Firefox 放在后续路线图），再解释 profile 是什么并读取该浏览器的全部本地 profile，展示 profile 子目录名、邮箱、昵称/用户名供你选择。当前默认绑定一个 profile，后续路线图允许一个用户配置多个候选 profile。`settings profile` 只配置浏览器身份。

```bash
payswitch config chrome_user_data_dir "$HOME/Library/Application Support/Google/Chrome"
payswitch config chrome_profile_directory "Profile 2"
payswitch config chrome_expected_profile_email "user@example.com"
payswitch config browser_channel chrome
```

如果日常 Chrome 已经打开，不能直接抢占同一个 User Data 目录；这时应使用 CDP 模式，先用 remote-debugging 端口启动一个用户确认过的 Chrome，再配置：

```bash
payswitch config chrome_cdp_url http://127.0.0.1:9222
```

Computer Use 有三种驱动形态：

| Driver | 谁负责思考 | Pay-Switch 负责什么 | 适用场景 |
|---|---|---|---|
| `external` | 用户自己的 Agent | 浏览器会话、动作审核、检测、人工闸门、账本 | MCP/API 产品主路径 |
| `internal` | Pay-Switch 配置的 LLM | 全流程受控探索和停止点判断 | 本地 demo / 无外部 Agent |
| `hybrid` | 外部 Agent + Pay-Switch 内部模型 | 适配器失败后的局部修复和兜底 | 生产自愈路径 |

推荐产品形态是 `external`：用户 Agent 当脑子，Pay-Switch 当手和闸门。外部 Agent 可以观察页面并提出点击、滚动、填写非敏感字段等动作，但 Pay-Switch 必须在执行前做风控判断；遇到 CVV、OTP、支付密码、二维码、最终确认付款、订阅协议等状态时，必须进入 Human Gate。

```bash
payswitch settings computer-use --driver external --max-category checkout_prep --enable
```

### 👤 Human Takeover

当系统检测到以下情况时，**主动交回控制权**：

- 风控验证码 / 2FA
- 扫码支付（QR Code detected）
- 敏感确认按钮（"确认付款 ¥500"）
- 连续两次自动化失败

交互方式：
- **本地模式**：弹出 Chrome 窗口，人类直接操作
- **远程模式**：noVNC 暴露浏览器画面，适合 Docker / 远程 Agent

---

## Safety & Guardrails

Pay-Switch 的设计原则是 **"Agent 犯错不能损失真金白银"**：

| 机制 | 作用 |
|---|---|
| 💰 **Limit Guard** | 单笔 / 每日限额，可按平台细分 |
| 🔒 **Platform Whitelist** | 未在白名单的平台直接拒绝 |
| 🔁 **Idempotency** | 每笔支付生成幂等键，重复调用不会重复扣款 |
| ✋ **Manual Confirm** | 超过阈值的金额必须二次确认 |
| 📜 **Audit Log** | SQLite 全量审计，append-only 不可篡改 |
| 🧊 **Profile Isolation** | 每个平台独立浏览器 profile，cookie 不互相污染 |
| 🛡️ **Sensitive Field Masking** | 检测到密码/CVV 时 Agent 不可操作 |

---

## Docker Deployment

一键启动，带 noVNC 的 Web UI：

```bash
cd docker/
docker compose up -d

# 访问 http://localhost:6080 查看浏览器画面
# 在容器内执行命令：
docker compose exec payswitch payswitch --help
```

`docker-compose.yml` 已内含：
- Xvfb 虚拟显示
- x11vnc + websockify + noVNC
- Playwright + Chromium
- 持久化卷（配置 + Profile + 数据库）

---

## Development

```bash
# 1. Clone
git clone https://github.com/Arxchibobo/payswitch.git
cd payswitch

# 2. Install with dev deps
pip install -e ".[smart,remote,dev]"
playwright install chromium

# 3. Run tests
pytest tests/ -v

# 4. Lint & format
ruff check .
ruff format .

# 5. Run locally
payswitch --help
```

### 项目结构

```
payswitch/
├── payswitch/
│   ├── cli.py            # Typer CLI 入口（所有子命令）
│   ├── engine/           # 编排引擎 + 安全守卫 + 账本
│   │   ├── orchestrator.py
│   │   ├── guard.py
│   │   └── ledger.py
│   ├── browser/          # 4 层浏览器架构
│   │   ├── controller.py
│   │   ├── detector.py
│   │   ├── display.py
│   │   ├── novnc.py
│   │   ├── profiles.py
│   │   ├── safety.py
│   │   └── skyvern.py
│   ├── adapters/         # 站点适配器
│   │   ├── deepseek.py
│   │   ├── kimi.py
│   │   └── qwen.py
│   └── models/           # Pydantic 数据模型
├── docker/               # Docker 部署
├── specs/                # 开发计划
├── tests/                # pytest 测试套件
└── PRD.md                # 产品需求文档
```

### 贡献一个站点适配器

```python
# payswitch/adapters/my_platform.py
from payswitch.adapters.base import SiteAdapter, AdapterRegistry
from payswitch.models.types import PaymentMethod

@AdapterRegistry.register
class MyPlatformAdapter(SiteAdapter):
    name = "my_platform"
    display_name = "My Platform"
    top_up_url = "https://example.com/billing"
    supported_methods = [PaymentMethod.alipay_qr]

    async def execute_topup(self, page, amount, method):
        # Your script here
        ...
```

欢迎 PR 新适配器！

### Versioning

Pay-Switch follows SemVer. The current version is stored in `VERSION`, and user-facing changes are recorded in `CHANGELOG.md` under `Unreleased` until a release is cut.

---

## Tech Stack

| Layer | Technology |
|---|---|
| CLI | Python 3.11+ / Typer / Rich |
| Browser | Playwright / Skyvern (LLM vision) |
| Storage | SQLite (append-only audit) |
| Remote | noVNC / Xvfb / websockify |
| Deploy | Docker / Docker Compose |
| Models | Pydantic V2 |

---

## Roadmap

- [x] CLI core (`setup` / `login` / `spend` / `confirm` / `status` / `history`)
- [x] Script + Skyvern dual mode with fallback chain
- [x] Human takeover (local popup + noVNC)
- [x] Adapters: DeepSeek / Kimi / Qwen
- [x] Safety: limits / whitelist / idempotency / audit
- [x] Docker deployment
- [ ] **v0.2** — HTTP API mode (for remote Agents without shell access)
- [ ] **v0.2** — Multi-account switching
- [ ] **v0.3** — Budget policies DSL (spending rules as code)
- [ ] **v0.3** — Webhook notifications (Slack / DingTalk)
- [ ] **v0.4** — More adapters: OpenAI / Anthropic / Replicate / HuggingFace
- [ ] **v0.5** — MCP Server（让 Claude Desktop 直连）
- [ ] **v0.5** — MPP / AP2 protocol compatibility
- [ ] **v1.0** — Production-ready + security audit

---

## License

[MIT](./LICENSE)

---

<p align="center">
  <sub>If Pay-Switch saved your agent from burning budget, give us a ⭐</sub>
</p>
