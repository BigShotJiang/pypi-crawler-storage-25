# Changelog

All notable changes to Pay-Switch are recorded here.

## [0.2.0] - 2026-05-11

### What changed

- Added Stripe payment channel adapter for international credit/debit card payments via Stripe hosted checkout.
- Added FastAPI-based Stripe webhook listener to receive payment completion events and update transaction status asynchronously.
- Added Stripe configuration fields (`stripe_secret_key`, `stripe_webhook_secret`, `stripe_webhook_port`, `stripe_default_currency`) in PaySwitchConfig with base64 encoding for secure storage.
- Added orchestrator logic to handle Stripe payments without browser automation (API-only flow).
- Added CLI commands: `payswitch settings stripe` for configuration wizard, `payswitch stripe listen` to start webhook server.
- Added `PaymentMethod.stripe` enum value and support for `--method stripe` in spend command.
- Added comprehensive test suite for Stripe adapter with mocked Stripe API calls and webhook event handling (14 new tests).
- Rolled `stripe`, `fastapi`, `uvicorn`, and `httpx` into the dev extras so `uv run --extra dev pytest` works out of the box.

## [0.1.0] - 2026-05-10

### What changed

- Added controlled Computer Use policy primitives for checkout step categories, risk gates, and external/internal/hybrid driver selection.
- Added user Chrome context support so Pay-Switch can bind to a real Chrome User Data directory, profile directory, expected email, or existing CDP browser.
- Added a NineEmail Alipay checkout adapter for end-to-end QR handoff testing.
- Added an external checkout runner so a caller agent can drive browser actions while Pay-Switch enforces guardrails and human gates.
- Added a dated checkout control-plane roadmap for adapter, skill-memory, Computer Use fallback, notification, and audit flows.
- Added interactive CLI settings for discovering Chrome profiles, binding a profile by email/name/directory, and configuring Computer Use driver mode.
- Added a guided `payswitch settings wizard` onboarding flow that asks for browser first, then lists local profiles for selection, then configures Computer Use.
- Improved the settings wizard with beginner-friendly explanations for browser choice, profile identity, Computer Use driver modes, and autonomous checkout boundaries.

### Why

**Stripe adapter:** Stripe is a critical payment channel for international credit/debit card transactions. Unlike browser-automation adapters (Alipay QR code via Playwright), Stripe uses REST API to create hosted checkout sessions, returning a URL for users to complete payment in Stripe's secure environment. Webhook listeners enable asynchronous payment confirmation without blocking the orchestrator.

**Other changes:** Pay-Switch needs to behave like a payment control plane, not a one-off browser script. These changes make the runtime configurable, auditable, and usable with a real user browser profile while preserving human authorization at sensitive or final payment points.

### Impact

- **Stripe adapter:** Agents can now accept international payments via `payswitch spend 10 --method stripe --currency usd`. Users receive a Stripe checkout URL (or QR code), complete payment on Stripe's secure page, and webhook automatically updates transaction status to `completed`. No browser automation needed.
- **Stripe webhook:** Operators must run `payswitch stripe listen` (default port 4242) to receive Stripe events. In production, configure Stripe Dashboard webhook URL to point to this endpoint.
- **Configuration:** Use `payswitch settings stripe` to configure `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET` (stored base64-encoded in `~/.payswitch/config.json`). Environment variables `STRIPE_SECRET_KEY` / `STRIPE_WEBHOOK_SECRET` take precedence.
- Agents can use `external` mode as the default brain/hand split: the caller agent reasons, while Pay-Switch owns execution policy, browser context, guardrails, and ledger state.
- Operators can select the correct Chrome profile from the CLI instead of hard-coding `Default` or guessing `Profile N`.
- Unknown checkout pages can be explored through governed browser actions up to `checkout_prep`, then handed back to the human for QR scan, CVV, OTP, payment password, or final authorization.

### Verification

- `uv add stripe` or `pip install 'payswitch[stripe]'` to install Stripe dependencies.
- `uv run --extra dev pytest tests/test_stripe_adapter.py -v` to run Stripe-specific tests.
- `uv run --extra dev pytest -q` to ensure all 242 existing tests still pass.
- `uv run --extra dev ruff check payswitch/` to lint new code.
- `uv run --with mypy mypy payswitch/adapters/stripe.py payswitch/engine/stripe_webhook.py` for type checking.
- Manual test: Set `STRIPE_SECRET_KEY=sk_test_...`, run `payswitch spend 10 --method stripe --dry-run`, verify it simulates Stripe checkout creation.
- Webhook test: Start `payswitch stripe listen`, use Stripe CLI (`stripe listen --forward-to localhost:4242/webhook`) to forward test events.
- `uv run python -m compileall -q payswitch tests`
- `rm -rf dist && uv build`
- `uv run payswitch settings profile --list-only --query cine.dreamer.one`
- `uv run payswitch --json config`
- `uv run --extra dev ruff check payswitch/browser/chrome_profiles.py tests/test_chrome_profiles.py`
- `uv run --with mypy mypy payswitch/browser/chrome_profiles.py tests/test_chrome_profiles.py`
- `printf '\ncine.dreamer.one\n1\n\n\n\n' | uv run payswitch settings wizard`
- `uv run payswitch settings wizard --browser chrome --profile-index 1 --yes`

### Files

- `pyproject.toml` (added `stripe` optional dependency group)
- `payswitch/models/types.py` (added `PaymentMethod.stripe`)
- `payswitch/models/config.py` (added Stripe config fields and helper methods)
- `payswitch/adapters/stripe.py` (new: StripeAdapter implementation)
- `payswitch/adapters/__init__.py` (registered StripeAdapter)
- `payswitch/engine/orchestrator.py` (added Stripe API branch in spend(), new `_execute_stripe_mode()` method)
- `payswitch/engine/stripe_webhook.py` (new: FastAPI webhook listener with signature verification)
- `payswitch/cli.py` (added `settings stripe` and `stripe listen` commands)
- `tests/test_stripe_adapter.py` (new: comprehensive Stripe adapter and webhook tests)
- `CHANGELOG.md` (this file)
- `README.md`
- `VERSION`
- `uv.lock`
- `payswitch/engine/external_runner.py`
- `payswitch/browser/chrome_profiles.py`
- `payswitch/browser/controller.py`
- `payswitch/adapters/nineemail.py`
- `doc/plans/2026-05-10-agent-checkout-control-plane-roadmap.md`
- `tests/test_chrome_profiles.py`
- `tests/test_computer_use.py`
- `tests/test_external_runner.py`
- `tests/test_models.py`

## [0.1.0] - 2026-05-10

### What changed

- Established the initial Pay-Switch Python package metadata and README concept documentation.

### Why

This records the first public baseline version before the control-plane changes are published.

### Impact

- The project has a SemVer starting point for future releases.

### Verification

- Baseline source tree was present before this changelog was introduced.

### Files

- `README.md`
- `pyproject.toml`
