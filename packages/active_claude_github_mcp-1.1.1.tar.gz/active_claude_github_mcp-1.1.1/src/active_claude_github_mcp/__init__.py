"""active-claude-github MCP server."""

__version__ = "1.1.1"
