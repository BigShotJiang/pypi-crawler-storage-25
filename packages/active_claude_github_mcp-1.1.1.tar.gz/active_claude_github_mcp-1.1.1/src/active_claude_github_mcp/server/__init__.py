"""active-claude-github-mcp server package (#82 Phase 2b).

Re-exports everything that handlers look up late-bound via
`active_claude_github_mcp.server.<name>`. This preserves the monkey-
patch contract that tests across `tests/` and `tests/tools/` rely on,
while letting handlers live in `handlers/*.py` and pick up test
replacements at call time.

Order matters:

  1. Re-export the full github / classifier / buffer surface. These
     MUST be bound at package import because handlers reference them
     via `_s.<name>` at call time — the module dict has to contain
     them by the time any handler runs.

  2. Re-export internal exceptions that tests catch or that the
     dispatch router needs (`GitHubError`, `ClassificationError`,
     `InvalidNodeIdError`).

  3. `.build` (dispatch router) and `.cli` (subprocess entry point)
     are exposed via PEP 562 `__getattr__` — lazy-loaded on first
     attribute access (#94). Eagerly importing them would make
     `:handler_*` Bazel targets transitively pull `:server_build` /
     `:server_cli` into the runfiles of every tool test, which
     defeats per-handler incremental test selection. The public API
     is unchanged: `from active_claude_github_mcp.server import
     build_server` still resolves, it just doesn't execute `.build`'s
     module body until the name is looked up.

Public API for code outside this package:

    from active_claude_github_mcp.server import build_server, main

Test monkey-patch targets (kept working):

    patch("active_claude_github_mcp.server.add_discussion_comment", ...)
    patch("active_claude_github_mcp.server.validate_node_id", ...)
    # ... etc
"""
from __future__ import annotations

# 1. Re-exports — MUST precede .build import.
from ..buffer import clear_pending, has_pending, read_pending, write_pending
from ..classification import ClassificationError, classify_turn, detect_theme_change
from ..github.core import GitHubError, InvalidNodeIdError
from ..github.discussions import (
    add_discussion_comment,
    create_discussion,
    get_discussion_body,
    get_discussion_comments,
    mark_discussion_answer,
    update_discussion_body,
)
from ..github.issues import (
    add_issue_comment,
    close_issue,
    create_issue,
    get_issue_body,
    get_label_id,
    update_issue_body,
)
from ..github.projects import (
    add_item_to_project,
    create_projectv2,
    get_project_item_id,
    get_project_status_field,
    link_projectv2_to_repo,
    list_owner_projects,
    move_project_item,
    update_projectv2_status_options,
)
from ..github.recovery import (
    get_milestone_by_title,
    list_milestones_with_progress,
    list_open_issues,
    list_recent_discussions,
    list_thread_comments,
)
from ..github.resolvers import (
    get_file_content,
    get_repo_node_id,
    get_repo_visibility,
    resolve_thread_id,
    validate_node_id,
)
from ..github.scaffold import (
    create_label,
    create_repository,
    enable_discussions,
    get_organization_id,
    get_repo_discussions_state,
)

# 2. Lazy access to .build and .cli — see module docstring for why (#94).


def __getattr__(name: str):
    if name == "build_server":
        from .build import build_server as _bs
        return _bs
    if name == "main":
        from .cli import main as _main
        return _main
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "build_server",
    "main",
    # Re-exports kept public for tests and downstream callers:
    "ClassificationError",
    "GitHubError",
    "InvalidNodeIdError",
    "classify_turn",
    "detect_theme_change",
    "add_discussion_comment",
    "create_discussion",
    "get_discussion_body",
    "get_discussion_comments",
    "mark_discussion_answer",
    "update_discussion_body",
    "add_issue_comment",
    "close_issue",
    "create_issue",
    "get_issue_body",
    "get_label_id",
    "update_issue_body",
    "add_item_to_project",
    "create_projectv2",
    "get_project_item_id",
    "get_project_status_field",
    "link_projectv2_to_repo",
    "list_owner_projects",
    "move_project_item",
    "update_projectv2_status_options",
    "get_milestone_by_title",
    "list_milestones_with_progress",
    "list_open_issues",
    "list_recent_discussions",
    "list_thread_comments",
    "get_file_content",
    "get_repo_node_id",
    "get_repo_visibility",
    "resolve_thread_id",
    "validate_node_id",
    "create_label",
    "create_repository",
    "enable_discussions",
    "get_organization_id",
    "get_repo_discussions_state",
    "clear_pending",
    "has_pending",
    "read_pending",
    "write_pending",
]
