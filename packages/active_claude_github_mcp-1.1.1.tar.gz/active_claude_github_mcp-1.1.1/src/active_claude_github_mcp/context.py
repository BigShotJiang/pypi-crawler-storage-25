"""Per-session server context (#82 Phase 2a).

ServerContext bundles the state that `build_server` previously held in
its closure. Introducing it is a prerequisite for Phase 2b, where the
inner async handlers move out of `build_server` into their own modules
and receive `ctx` as an explicit parameter instead of closing over it.

Phase 2a itself is behavior-neutral: the handlers still live inside
`build_server`, still capture `ctx` by closure, and still read / mutate
the same underlying state — just through attribute access on `ctx`
rather than separate closure variables.

Concurrency model matches `SessionActivity`: one instance per
`build_server()` call (i.e. per MCP stdio subprocess). Serialized
handler dispatch means no locking is needed as long as that assumption
holds.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from .models import GithubConfig
from .utils import SessionActivity


@dataclass
class ServerContext:
    config: GithubConfig
    github_token: str
    anthropic_api_key: str
    project_dir: Path
    current_session: dict | None = None
    activity: SessionActivity = field(default_factory=SessionActivity)
