# Changelog

All notable changes to omgformer are documented here.

---

## [2.0.1] — 2026-05-02

### Bug Fixes

- **`modeling.py`** — `_forward_blocks` type annotation corrected: `t_emb` is now `Optional[torch.Tensor]` (was incorrectly typed as non-optional, causing false type-checker errors).
- **`training.py`** — Replaced deprecated `torch.cuda.amp.GradScaler(...)` with the new cross-device `torch.amp.GradScaler("cuda", ...)` API (PyTorch ≥ 2.3 compatibility).
- **`training.py`** — Fixed `enable_gradient_checkpointing`: the checkpoint wrapper no longer passes a `dummy` tensor as `t_emb` when `t_emb is None`. The block now receives the correct `None` value, preserving the pre-norm fallback branch behaviour.
- **`tokenization.py`** — Fixed potential infinite recursion in `__getattr__`: accessing `_tok` before it was set could recurse forever. Now uses `object.__getattribute__` to guard the lookup.
- **`diffusion.py`** — `generate_stream` now supports the full parameter set: `temperature`, `top_k`, `top_p`, and `remask_prob` — matching `generate()`. Final-step forced unmasking is also applied.
- **`configuration.py`** — Replaced bare `assert` statements (silenceable with `-O`) with explicit `ValueError` raises for validation logic.
- **`pipeline.py`** — Replaced bare `assert task == …` with `ValueError` for the same reason.

### Improvements

- **`utils.py`** (new) — Helper utilities: `set_seed`, `count_parameters`, `get_model_size_mb`, `get_device`, `tokens_per_second`, `format_number`.
- **`modeling.py`** — Added `OMGModel.generate()` convenience method so users don't need to manually instantiate `MaskScheduler` + `ParallelDecoder`.
- **`configuration.py`** — Added `OMGConfig.from_json_string()` classmethod and `validate()` method.
- **`auto.py`** — `AutoModel.from_pretrained` now accepts a `device` keyword argument passed through to `from_pretrained`.
- **`pyproject.toml`** — PyPI-ready: added `authors`, `keywords`, `classifiers`, `[project.urls]`, `[tool.ruff]`, `[tool.mypy]`, and `py.typed` package-data entry.
- **`MANIFEST.in`** (new) — Ensures `LICENSE`, `README.md`, `CHANGELOG.md`, and `py.typed` are included in sdist.
- **`py.typed`** (new) — PEP 561 marker: downstream users get type information from mypy/pyright.
- **`tests/`** — Test directory moved to top-level `tests/` (standard layout); added new tests for `utils`, `OMGConfig.validate()`, `OMGConfig.from_json_string()`, `generate_stream` with params, and `OMGModel.generate()`.
- **Version bumped** to `2.0.1` in `pyproject.toml` and `omgformer/__init__.py`.

---

## [2.0.0] — 2026-05-01

### Added
- Grouped Query Attention (GQA) with configurable `num_kv_heads`
- AdaLN-Zero timestep conditioning (DiT-style) via `use_adaLN`
- Self-conditioning: previous step's soft predictions fed into next step
- Absorbing diffusion: 80/10/10 MASK / random-token / original split
- Sigmoid noise schedule in addition to cosine / linear / sqrt
- Remasking during inference (`remask_prob`)
- BF16 AMP + gradient accumulation in `Trainer`
- `torch.compile()` integration
- FSDP multi-GPU helper (`wrap_fsdp`)
- Gradient checkpointing (`enable_gradient_checkpointing`)
- WandB logging hook in `Trainer`
- `generate_stream()` for step-by-step visualisation
- `safetensors` as primary checkpoint format (PyTorch `.pt` fallback)
- Six model presets: tiny / small / base / large / xl / 3b

---

## [1.0.0] — 2025-12-01

- Initial release: parallel masked diffusion language model with standard MHA.
