"""tests/test_omgformer.py  v2.0.1"""

import pytest
import torch

from omgformer import (
    OMGConfig, OMGModel, MaskScheduler, ParallelDecoder,
    AutoConfig, AutoModel, OMGBlock, RMSNorm,
    GroupedQueryAttention, SwiGLUFFN, AdaLNModulation,
    set_seed, count_parameters, get_model_size_mb, format_number,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def cfg():
    return OMGConfig(
        vocab_size=500, hidden_size=64, num_layers=2, num_heads=4,
        num_kv_heads=2, intermediate_size=128, max_length=64,
        use_adaLN=True, self_conditioning=True,
    )


@pytest.fixture
def model(cfg):
    return OMGModel(cfg).eval()


@pytest.fixture
def sched(cfg):
    return MaskScheduler(
        steps=16, mask_token_id=cfg.mask_token_id,
        pad_token_id=cfg.pad_token_id, vocab_size=cfg.vocab_size,
    )


# ── Config ────────────────────────────────────────────────────────────────────

def test_config_preset():
    c = OMGConfig.from_preset("omgformer-tiny")
    assert c.hidden_size == 256


def test_config_gqa_validation():
    c = OMGConfig(hidden_size=512, num_heads=8, num_kv_heads=4)
    assert c.gqa_ratio == 2


def test_config_gqa_invalid():
    with pytest.raises(ValueError):
        OMGConfig(hidden_size=512, num_heads=8, num_kv_heads=3)


def test_config_divisibility_invalid():
    """hidden_size % num_heads != 0 → ValueError (eskiden AssertionError)."""
    with pytest.raises(ValueError):
        OMGConfig(hidden_size=65, num_heads=8)


def test_config_auto_intermediate():
    c = OMGConfig(hidden_size=512, num_heads=8)
    assert c.intermediate_size > 0 and c.intermediate_size % 256 == 0


def test_config_save_load(tmp_path, cfg):
    cfg.save(str(tmp_path))
    c2 = OMGConfig.load(str(tmp_path))
    assert c2.hidden_size == cfg.hidden_size
    assert c2.num_kv_heads == cfg.num_kv_heads
    assert c2.use_adaLN == cfg.use_adaLN


def test_config_load_missing_file(tmp_path):
    """Dosya yoksa anlamlı hata mesajı."""
    with pytest.raises(FileNotFoundError, match="config.json not found"):
        OMGConfig.load(str(tmp_path))


def test_config_from_json_string(cfg):
    """NEW (2.0.1): from_json_string round-trip."""
    json_str = cfg.to_json()
    c2 = OMGConfig.from_json_string(json_str)
    assert c2.hidden_size == cfg.hidden_size
    assert c2.num_kv_heads == cfg.num_kv_heads


def test_config_validate_ok(cfg):
    """Geçerli konfigürasyon hata fırlatmamalı."""
    cfg.validate()  # no raise


def test_config_validate_bad_schedule():
    cfg = OMGConfig(vocab_size=100, hidden_size=64, num_heads=4, num_kv_heads=4,
                    intermediate_size=128)
    cfg.mask_schedule = "unknown"
    with pytest.raises(ValueError, match="mask_schedule"):
        cfg.validate()


def test_config_validate_bad_dropout():
    with pytest.raises(ValueError, match="dropout"):
        OMGConfig(
            vocab_size=100, hidden_size=64, num_heads=4, num_kv_heads=4,
            intermediate_size=128, dropout=1.5,
        ).validate()


def test_config_parameter_count(cfg):
    assert cfg.num_parameters() > 0


def test_config_preset_unknown():
    with pytest.raises(ValueError, match="Unknown preset"):
        OMGConfig.from_preset("omgformer-nonexistent")


# ── Katmanlar ─────────────────────────────────────────────────────────────────

def test_rmsnorm(cfg):
    norm = RMSNorm(cfg.hidden_size)
    x = torch.randn(2, 10, cfg.hidden_size)
    assert norm(x).shape == x.shape


def test_gqa_shape(cfg):
    attn = GroupedQueryAttention(cfg)
    x = torch.randn(2, 32, cfg.hidden_size)
    assert attn(x).shape == x.shape


def test_gqa_mha_equiv():
    cfg = OMGConfig(vocab_size=100, hidden_size=64, num_heads=4, num_kv_heads=4,
                    intermediate_size=128)
    attn = GroupedQueryAttention(cfg)
    x = torch.randn(1, 8, 64)
    assert attn(x).shape == x.shape


def test_swiglu_shape(cfg):
    ffn = SwiGLUFFN(cfg)
    x = torch.randn(2, 32, cfg.hidden_size)
    assert ffn(x).shape == x.shape


def test_adaLN_modulation(cfg):
    ada = AdaLNModulation(cfg.hidden_size)
    t = torch.randn(2, cfg.hidden_size)
    mods = ada(t)
    assert len(mods) == 6
    assert all(m.shape == (2, 1, cfg.hidden_size) for m in mods)
    assert all(m.abs().max().item() < 1e-6 for m in mods)


def test_block_with_adaLN(cfg):
    block = OMGBlock(cfg)
    x = torch.randn(2, 32, cfg.hidden_size)
    t_emb = torch.randn(2, cfg.hidden_size)
    assert block(x, t_emb=t_emb).shape == x.shape


def test_block_without_adaLN():
    cfg = OMGConfig(vocab_size=100, hidden_size=64, num_heads=4, num_kv_heads=4,
                    intermediate_size=128, use_adaLN=False)
    block = OMGBlock(cfg)
    x = torch.randn(2, 32, 64)
    assert block(x).shape == x.shape


def test_block_none_t_emb_fallback(cfg):
    """FIX (2.0.1): t_emb=None ile çağrıldığında blok pre-norm fallback'e düşmeli."""
    block = OMGBlock(cfg)
    x = torch.randn(2, 32, cfg.hidden_size)
    # t_emb=None → use_adaLN=True olsa bile fallback dalına girer
    out = block(x, t_emb=None)
    assert out.shape == x.shape


# ── Model ─────────────────────────────────────────────────────────────────────

def test_model_forward_shape(model, cfg):
    ids = torch.randint(5, cfg.vocab_size, (2, 32))
    out = model(ids)
    assert out.logits.shape == (2, 32, cfg.vocab_size)


def test_model_with_timesteps(model, cfg):
    ids = torch.randint(5, cfg.vocab_size, (2, 32))
    t = torch.randint(1, 16, (2,))
    out = model(ids, timesteps=t)
    assert out.logits.shape == (2, 32, cfg.vocab_size)


def test_model_no_timesteps(model, cfg):
    """FIX (2.0.1): timesteps=None ile forward Optional olarak düzgün işlenmeli."""
    ids = torch.randint(5, cfg.vocab_size, (2, 32))
    out = model(ids, timesteps=None)  # t_emb=None → pre-norm fallback
    assert out.logits.shape == (2, 32, cfg.vocab_size)


def test_model_full_sequence(model, cfg):
    ids = torch.randint(5, cfg.vocab_size, (1, 60))
    out = model(ids)
    assert out.logits.shape[1] == 60


def test_model_self_conditioning(model, cfg):
    ids = torch.randint(5, cfg.vocab_size, (2, 32))
    t = torch.randint(1, 16, (2,))
    out1 = model(ids, timesteps=t)
    self_cond = model.get_soft_embedding(out1.logits)
    out2 = model(ids, timesteps=t, self_cond=self_cond)
    assert out2.logits.shape == out1.logits.shape
    assert not torch.allclose(out1.logits, out2.logits)


def test_model_save_load(model, tmp_path):
    model.save_pretrained(str(tmp_path))
    m2 = OMGModel.from_pretrained(str(tmp_path))
    for p1, p2 in zip(model.parameters(), m2.parameters()):
        assert torch.allclose(p1, p2, atol=1e-6)


def test_auto_model(cfg):
    m = AutoModel.from_config(cfg)
    assert isinstance(m, OMGModel)


def test_model_convenience_generate(model, cfg):
    """NEW (2.0.1): OMGModel.generate() kolaylık metodu."""
    prompt = torch.randint(5, cfg.vocab_size, (1, 4))
    out = model.generate(prompt, new_tokens=8, steps=3)
    assert out.shape == (1, 12)
    assert (out != cfg.mask_token_id).all()


# ── Diffusion ─────────────────────────────────────────────────────────────────

def test_corrupt_shape(sched, cfg):
    ids = torch.randint(5, cfg.vocab_size, (2, 20))
    noisy, mask, t = sched.corrupt(ids)
    assert noisy.shape == ids.shape and mask.shape == ids.shape


def test_corrupt_high_t(sched, cfg):
    ids = torch.randint(5, cfg.vocab_size, (4, 32))
    noisy, mask, _ = sched.corrupt(ids, t=torch.full((4,), 16))
    assert mask.float().mean() > 0.80


def test_corrupt_pad_safe(sched, cfg):
    ids = torch.randint(5, cfg.vocab_size, (2, 20))
    ids[:, 10:] = cfg.pad_token_id
    noisy, mask, _ = sched.corrupt(ids)
    assert not mask[:, 10:].any()


def test_absorbing_random_tokens(sched, cfg):
    ids = torch.randint(5, cfg.vocab_size, (8, 64))
    noisy, mask, _ = sched.corrupt(ids, t=torch.full((8,), 16))
    changed = (noisy != ids) & mask
    assert (noisy == sched.mask_token_id).any()
    assert (noisy[changed] != sched.mask_token_id).any()


def test_diffusion_loss(sched, model, cfg):
    ids = torch.randint(5, cfg.vocab_size, (2, 20))
    noisy, mask, t = sched.corrupt(ids)
    loss = sched.loss(model, noisy, ids, mask, t, self_cond_prob=0.0)
    assert loss.item() > 0 and not torch.isnan(loss)


def test_diffusion_loss_with_self_cond(sched, model, cfg):
    ids = torch.randint(5, cfg.vocab_size, (2, 20))
    noisy, mask, t = sched.corrupt(ids)
    loss = sched.loss(model, noisy, ids, mask, t, self_cond_prob=1.0)
    assert loss.item() > 0 and not torch.isnan(loss)


def test_schedule_invalid():
    with pytest.raises(ValueError, match="must be one of"):
        MaskScheduler(steps=10, schedule="bad", mask_token_id=1,
                      pad_token_id=0, vocab_size=1000)


def test_top_p_filter_correct():
    from omgformer.diffusion import _top_p_filter
    torch.manual_seed(42)
    logits = torch.randn(2, 10, 100)
    filtered = _top_p_filter(logits, p=0.9)
    assert (filtered <= logits + 1e-6).all()
    assert (filtered > float("-inf")).any(dim=-1).all()


# ── Üretim ────────────────────────────────────────────────────────────────────

def test_generate_shape(model, sched, cfg):
    decoder = ParallelDecoder(model, sched)
    prompt  = torch.randint(5, cfg.vocab_size, (1, 4))
    out     = decoder.generate(prompt, new_tokens=8, steps=3)
    assert out.shape == (1, 12)


def test_prompt_unchanged(model, sched, cfg):
    decoder = ParallelDecoder(model, sched)
    prompt  = torch.randint(5, cfg.vocab_size, (1, 6))
    out     = decoder.generate(prompt, new_tokens=8, steps=3)
    assert torch.equal(out[:, :6], prompt)


def test_generate_no_masks_remain(model, sched, cfg):
    decoder = ParallelDecoder(model, sched)
    prompt  = torch.randint(5, cfg.vocab_size, (1, 4))
    out     = decoder.generate(prompt, new_tokens=8, steps=5)
    assert (out != sched.mask_token_id).all()


def test_generate_batch(model, sched, cfg):
    decoder = ParallelDecoder(model, sched)
    prompt  = torch.randint(5, cfg.vocab_size, (3, 4))
    out     = decoder.generate(prompt, new_tokens=8, steps=3)
    assert out.shape == (3, 12)


def test_generate_with_temperature(model, sched, cfg):
    """Farklı temperature değerleri çalışmalı."""
    decoder = ParallelDecoder(model, sched)
    prompt  = torch.randint(5, cfg.vocab_size, (1, 4))
    out     = decoder.generate(prompt, new_tokens=8, steps=3, temperature=0.7, top_p=0.9)
    assert out.shape == (1, 12)


def test_generate_stream(model, sched, cfg):
    decoder = ParallelDecoder(model, sched)
    prompt  = torch.randint(5, cfg.vocab_size, (1, 4))
    frames  = list(decoder.generate_stream(prompt, new_tokens=8, steps=3))
    assert len(frames) == 3
    assert frames[-1].shape == (1, 12)
    counts = [(f[:, 4:] != sched.mask_token_id).sum().item() for f in frames]
    assert all(counts[i] <= counts[i + 1] for i in range(len(counts) - 1))


def test_generate_stream_no_masks_remain(model, sched, cfg):
    """FIX (2.0.1): generate_stream son adımda MASK kalmıyor."""
    decoder = ParallelDecoder(model, sched)
    prompt  = torch.randint(5, cfg.vocab_size, (1, 4))
    frames  = list(decoder.generate_stream(prompt, new_tokens=8, steps=5))
    final   = frames[-1]
    assert (final != sched.mask_token_id).all()


def test_generate_stream_with_params(model, sched, cfg):
    """FIX (2.0.1): generate_stream temperature/top_p parametrelerini destekliyor."""
    decoder = ParallelDecoder(model, sched)
    prompt  = torch.randint(5, cfg.vocab_size, (1, 4))
    frames  = list(decoder.generate_stream(
        prompt, new_tokens=8, steps=3, temperature=0.8, top_p=0.9
    ))
    assert len(frames) == 3


# ── Utils ─────────────────────────────────────────────────────────────────────

def test_set_seed():
    set_seed(42)
    a = torch.randn(10)
    set_seed(42)
    b = torch.randn(10)
    assert torch.allclose(a, b)


def test_count_parameters(model):
    n = count_parameters(model)
    assert n > 0
    assert n == model.num_parameters(trainable=True)


def test_get_model_size_mb(model):
    mb = get_model_size_mb(model)
    assert mb > 0.0


def test_format_number():
    assert "M" in format_number(1_500_000)
    assert "B" in format_number(3_000_000_000)
    assert "K" in format_number(5_000)


def test_tokens_per_second():
    from omgformer import tokens_per_second
    import time

    with tokens_per_second(batch_size=4, seq_len=128) as meter:
        time.sleep(0.01)  # симулируем работу

    assert meter.value > 0


# ── Tokenization ──────────────────────────────────────────────────────────────

def test_tokenizer_getattr_no_recurse():
    """FIX (2.0.1): _tok ayarlanmadan __getattr__ erişimi sonsuz döngüye girmemeli."""
    from omgformer.tokenization import OMGTokenizer
    tok = object.__new__(OMGTokenizer)  # __init__ çağırmadan oluştur
    with pytest.raises(AttributeError, match="not yet initialised"):
        _ = tok.some_attr


# ── Training ──────────────────────────────────────────────────────────────────

def test_training_config_validate_ok():
    from omgformer.training import TrainingConfig
    cfg = TrainingConfig(steps=100, warmup_steps=10, device="cpu",
                         use_amp=False, use_compile=False)
    cfg.validate()  # no raise


def test_training_config_validate_bad_warmup():
    from omgformer.training import TrainingConfig
    cfg = TrainingConfig(steps=100, warmup_steps=200, device="cpu",
                         use_amp=False, use_compile=False)
    with pytest.raises(ValueError, match="warmup_steps"):
        cfg.validate()


def test_training_config_validate_bad_accum():
    from omgformer.training import TrainingConfig
    cfg = TrainingConfig(steps=100, warmup_steps=10, grad_accum_steps=0,
                         device="cpu", use_amp=False, use_compile=False)
    with pytest.raises(ValueError, match="grad_accum_steps"):
        cfg.validate()


def test_trainer_fit(cfg):
    """Kısa eğitim döngüsü hatasız tamamlanmalı."""
    from omgformer.training import Trainer, TrainingConfig

    model = OMGModel(cfg)
    sched = MaskScheduler(steps=4, mask_token_id=cfg.mask_token_id,
                          pad_token_id=cfg.pad_token_id, vocab_size=cfg.vocab_size)
    train_cfg = TrainingConfig(
        steps=4, batch_size=2, seq_len=16, lr=1e-3,
        warmup_steps=1, use_amp=False, use_compile=False,
        grad_accum_steps=1, log_every=2, save_every=1000,
        device="cpu",
    )

    def get_batch(B):
        return torch.randint(5, cfg.vocab_size, (B, train_cfg.seq_len))

    trainer = Trainer(model, sched, train_cfg, get_batch=get_batch)
    trainer.fit()


# ── LoRA ──────────────────────────────────────────────────────────────────────

from omgformer.lora import add_lora, merge_lora, save_lora, load_lora, lora_parameter_count, LoRAConfig

def test_lora_add(cfg):
    model = OMGModel(cfg)
    total_before = sum(p.numel() for p in model.parameters())
    model = add_lora(model, rank=4, alpha=8.0)
    trainable, total = lora_parameter_count(model)
    assert trainable > 0
    assert trainable < total
    assert total > total_before  # LoRA parametreleri eklendi

def test_lora_forward(cfg):
    model = OMGModel(cfg).eval()
    model = add_lora(model, rank=4)
    ids = torch.randint(5, cfg.vocab_size, (2, 16))
    out = model(ids)
    assert out.logits.shape == (2, 16, cfg.vocab_size)

def test_lora_merge(cfg):
    model = OMGModel(cfg).eval()
    model = add_lora(model, rank=4)
    ids = torch.randint(5, cfg.vocab_size, (1, 16))
    out_before = model(ids).logits.detach()
    model = merge_lora(model)
    out_after = model(ids).logits.detach()
    # Merge sonrası çıktı aynı olmalı (sayısal hassasiyet payıyla)
    assert torch.allclose(out_before, out_after, atol=1e-4)

def test_lora_save_load(cfg, tmp_path):
    model = OMGModel(cfg)
    model = add_lora(model, rank=4)
    save_lora(model, str(tmp_path))
    # Yeni model oluştur, aynı LoRA config ile yükle
    model2 = OMGModel(cfg)
    model2 = add_lora(model2, rank=4)
    model2 = load_lora(model2, str(tmp_path))
    # LoRA ağırlıkları aynı olmalı
    for (n1, p1), (n2, p2) in zip(model.named_parameters(), model2.named_parameters()):
        if "lora" in n1:
            assert torch.allclose(p1, p2)

def test_lora_config():
    cfg_lora = LoRAConfig(rank=32, alpha=64.0, train_ffn=True)
    assert cfg_lora.rank == 32
    assert cfg_lora.scaling == 2.0
    assert "gate" in cfg_lora.target_modules

def test_lora_frozen_base(cfg):
    model = OMGModel(cfg)
    model = add_lora(model, rank=4)
    for name, param in model.named_parameters():
        if "lora_A" not in name and "lora_B" not in name:
            assert not param.requires_grad, f"{name} dondurulmuş olmalı"


# ── Data ──────────────────────────────────────────────────────────────────────

from omgformer.data import TextDataset, PackedDataset, DataCollator

def test_text_dataset(cfg):
    ids = torch.randint(5, cfg.vocab_size, (1024,))
    ds = TextDataset(ids, seq_len=64)
    assert len(ds) > 0
    assert ds[0].shape == (64,)

def test_packed_dataset(cfg):
    seqs = [torch.randint(5, cfg.vocab_size, (32,)) for _ in range(20)]
    ds = PackedDataset(seqs, seq_len=64, eos_token_id=2)
    assert len(ds) > 0
    assert ds[0].shape == (64,)

def test_data_collator(cfg):
    collator = DataCollator(pad_token_id=cfg.pad_token_id)
    batch = [torch.randint(5, cfg.vocab_size, (l,)) for l in [10, 20, 15]]
    result = collator(batch)
    assert result["input_ids"].shape == (3, 20)
    assert result["attention_mask"].shape == (3, 20)
    assert result["attention_mask"][0, 15:].sum() == 0  # padded kısım 0

# ── Eval ──────────────────────────────────────────────────────────────────────

from omgformer.eval import Evaluator, EvalResults

def test_evaluator(model, sched, cfg):
    ids = torch.randint(5, cfg.vocab_size, (1024,))
    from omgformer.data import TextDataset
    ds = TextDataset(ids, seq_len=32)
    ev = Evaluator(model, sched)
    results = ev.evaluate(ds, batch_size=4, max_batches=3)
    assert isinstance(results, EvalResults)
    assert results.loss > 0
    assert results.perplexity > 1
    assert results.bpb > 0
    assert results.tokens_per_sec > 0

# ── Quantize ──────────────────────────────────────────────────────────────────

from omgformer.quantize import quantize_int8, quantize_int4, model_size_mb

def test_quantize_int8(cfg):
    model = OMGModel(cfg).eval()
    size_before = model_size_mb(model)
    model = quantize_int8(model, verbose=False)
    size_after = model_size_mb(model)
    assert size_after < size_before
    # Forward pass hâlâ çalışmalı
    ids = torch.randint(5, cfg.vocab_size, (1, 16))
    out = model(ids)
    assert out.logits.shape == (1, 16, cfg.vocab_size)

def test_quantize_int4(cfg):
    model = OMGModel(cfg).eval()
    size_before = model_size_mb(model)
    model = quantize_int4(model, group_size=32, verbose=False)
    size_after = model_size_mb(model)
    assert size_after < size_before

# ── Callbacks ─────────────────────────────────────────────────────────────────

from omgformer.callbacks import EarlyStopping, LossLogger

def test_early_stopping():
    cb = EarlyStopping(patience=3, min_delta=0.01)

    class FakeTrainer:
        _stop_training = False
        config = type("C", (), {"steps": 100})()

    trainer = FakeTrainer()
    # Loss düşmüyor — 3 adım sonra dur
    for i in range(5):
        cb.on_log(trainer, i, {"train/loss": 5.0})
    assert trainer._stop_training

def test_loss_logger(tmp_path):
    logger = LossLogger()

    class FakeTrainer:
        pass

    trainer = FakeTrainer()
    for i in range(5):
        logger.on_log(trainer, i, {"train/loss": 5.0 - i * 0.1, "train/lr": 3e-4})

    assert len(logger.steps) == 5
    assert len(logger.losses) == 5
    log_path = str(tmp_path / "log.csv")
    logger.save(log_path)
    import os
    assert os.path.exists(log_path)

# ── MoE ──────────────────────────────────────────────────────────────────────

from omgformer.moe import MoEFFN, RouterLoadBalancingLoss
from omgformer.configuration import MoEConfig

def test_moe_config():
    moe = MoEConfig(num_experts=8, num_experts_per_token=2)
    assert moe.num_experts == 8
    assert moe.num_experts_per_token == 2

def test_router_load_balancing():
    probs = torch.softmax(torch.randn(16, 8), dim=-1)
    topk_idx = probs.topk(2, dim=-1).indices
    loss = RouterLoadBalancingLoss.compute(probs, topk_idx, num_experts=8)
    assert loss.item() > 0
    assert not torch.isnan(loss)
