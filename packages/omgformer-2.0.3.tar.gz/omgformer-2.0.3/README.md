# omgformer v2.0.1

**Paralel Diffusion Dil Modeli** — aynı anda tüm tokenleri üretir.

Klasik GPT 256 token için 256 forward pass yapar.  
omgformer aynı çıktıyı **8–10 forward pass** ile üretir.

```bash
pip install omgformer
```

---

## Temel Fikir

```
Adım 0: "Merhaba [MASK] [MASK] [MASK] [MASK] [MASK]"
Adım 1: "Merhaba dünya  [MASK] [MASK] [MASK] [MASK]"
Adım 2: "Merhaba dünya  nasıl  gidiyor [MASK] [MASK]"
Adım 3: "Merhaba dünya  nasıl  gidiyor  bugün   ?"
```

Her adımda tüm sequence bir forward pass'ten geçer.  
Model hem sola hem sağa bakar.  
En yüksek güvenli tokenlar açılır.  
Python for loop yok — tamamen vektörize.

---

## Hızlı Başlangıç

```python
from omgformer import OMGConfig, OMGModel, MaskScheduler, ParallelDecoder

cfg   = OMGConfig.from_preset("omgformer-base")
model = OMGModel(cfg).eval()

# Doğrudan model üzerinden üretim (v2.0.1 yeni)
prompt_ids = tokenizer.encode("İstanbul'un tarihi")
out = model.generate(prompt_ids, new_tokens=128, steps=10)
print(tokenizer.decode(out[0]))
```

### Manuel decoder

```python
sched   = MaskScheduler(steps=64, mask_token_id=cfg.mask_token_id, vocab_size=cfg.vocab_size)
decoder = ParallelDecoder(model, sched)

out = decoder.generate(
    prompt_ids,
    new_tokens=128,
    steps=10,
    temperature=0.9,
    top_p=0.95,
    remask_prob=0.05,
)
```

### Pipeline

```python
from omgformer import pipeline

gen    = pipeline("text-generation", model="omgformer-base")
result = gen("Yapay zeka", new_tokens=256, steps=10)
print(result["generated_text"])
```

### Eğitim

```python
from omgformer.training import Trainer, TrainingConfig

train_cfg = TrainingConfig(
    steps=100_000,
    batch_size=32,
    lr=3e-4,
    use_amp=True,
    use_compile=True,
    grad_accum_steps=4,
    self_cond_prob=0.5,
    use_wandb=True,
)

trainer = Trainer(model, sched, train_cfg, get_batch=my_data_loader)
trainer.fit()
```

### Çok GPU (FSDP)

```python
from omgformer.training import wrap_fsdp

model = wrap_fsdp(model, device_id=local_rank)
# torchrun --nproc_per_node=8 train.py
```

---

## v2.0.1 — Hata Düzeltmeleri

| Dosya | Hata | Düzeltme |
|-------|------|----------|
| `modeling.py` | `_forward_blocks` t_emb tipi `Tensor` (Optional değil) | `Optional[torch.Tensor]` yapıldı |
| `training.py` | `torch.cuda.amp.GradScaler` deprecated (PyTorch ≥ 2.3) | `torch.amp.GradScaler("cuda", …)` kullanıldı |
| `training.py` | Gradient checkpointing `t_emb=None` → dummy tensor → yanlış dal | `None` değerleri doğru iletiliyor |
| `tokenization.py` | `__getattr__` sonsuz özyineleme | `object.__getattribute__` ile korundu |
| `diffusion.py` | `generate_stream` `temperature/top_k/top_p/remask_prob` yok sayılıyordu | Tam parametre desteği eklendi |
| `diffusion.py` | `generate_stream` son adımda MASK token kalabiliyordu | Son adım forced-unmask eklendi |
| `configuration.py` | `assert` → `-O` ile devre dışı bırakılabilir | `ValueError` ile değiştirildi |
| `pipeline.py` | `assert task == …` | `ValueError` ile değiştirildi |

### Yeni Eklentiler

- **`utils.py`** — `set_seed`, `count_parameters`, `get_model_size_mb`, `get_device`, `tokens_per_second`, `format_number`
- **`OMGModel.generate()`** — MaskScheduler + ParallelDecoder oluşturmadan doğrudan üretim
- **`OMGConfig.from_json_string()`** — JSON dizisinden konfigürasyon
- **`OMGConfig.validate()`** — erken değer doğrulaması
- **`TrainingConfig.validate()`** — eğitim başlamadan tutarsızlık tespiti
- **`AutoModel.from_pretrained(device=…)`** — cihaz parametresi eklendi
- **`py.typed`** — PEP 561 tip marker
- **PyPI metadata** — `classifiers`, `keywords`, `authors`, `[project.urls]`

---

## v2.0.0 Mimarisi

### GQA (Grouped Query Attention)

```python
cfg = OMGConfig(num_heads=16, num_kv_heads=4)  # 4× bellek tasarrufu
```

### AdaLN-Zero

```
x_attn = norm(x) * (1 + scale) + shift
x = x + gate.tanh() * attention(x_attn)
```

Gate'ler sıfır başlatılır → eğitim başında blok = tam geçirgen.

### Self-Conditioning

```
Adım N:   logits_n  = model(noisy, self_cond=None)
Adım N+1: logits_n1 = model(noisy, self_cond=soft_embed(logits_n))
```

### Absorbing Diffusion

```
%80 → MASK token
%10 → rastgele başka token
%10 → orijinal token kalır
```

---

## Model Boyutları

| Preset         | Katman | Hidden | Heads (Q/KV) | ~Parametre |
|----------------|--------|--------|--------------|------------|
| omgformer-tiny | 4      | 256    | 4/4          | ~14M       |
| omgformer-small| 8      | 512    | 8/4          | ~87M       |
| omgformer-base | 12     | 768    | 12/4         | ~180M      |
| omgformer-large| 24     | 1024   | 16/4         | ~600M      |
| omgformer-xl   | 24     | 2048   | 16/2         | ~2.1B      |
| omgformer-3b   | 32     | 2560   | 32/8         | ~3.2B      |

---

## Hız Karşılaştırması

| Model                      | 256 token üretim  | Yöntem             |
|----------------------------|-------------------|--------------------|
| GPT-2                      | 256 forward pass  | Otoregresif        |
| omgformer (steps=10)       | 10 forward pass   | Paralel diffusion  |
| omgformer (steps=6, SC)    | 6 forward pass    | + Self-conditioning|

---

## Kurulum

```bash
# Minimum
pip install omgformer

# Eğitim araçlarıyla
pip install "omgformer[train]"

# Geliştirici araçlarıyla
pip install "omgformer[dev]"
```

---

## Testler

```bash
pytest tests/ -v
```

---

## Referanslar

- [MDLM: Masked Diffusion Language Models](https://arxiv.org/abs/2406.07524)
- [DiT: Scalable Diffusion Transformers](https://arxiv.org/abs/2212.09748)
- [Self-Conditioning in Diffusion Models](https://arxiv.org/abs/2208.04202)
- [GQA: Training Generalized Multi-Query Attention](https://arxiv.org/abs/2305.13245)
- [Mercury: Ultra-Fast Language Models (Inception Labs)](https://www.inceptionlabs.ai/mercury)

---

## Lisans

Apache-2.0
