"""
omgformer/modeling.py  v2.0.1
------------------------------
Değişiklikler (2.0.1):
  - BUG FIX: ``_forward_blocks`` imzasındaki ``t_emb`` artık
    ``Optional[torch.Tensor]`` olarak doğru işaretlendi.
    Önceki ``torch.Tensor`` anotasyonu, tip denetleyicilerinde
    (mypy/pyright) yanlış uyarılara neden oluyordu.
  - YENİ: ``OMGModel.generate()`` — MaskScheduler + ParallelDecoder
    olmadan doğrudan modelden metin üretme kolaylık metodu.
"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from omgformer.configuration import OMGConfig
from omgformer.layers import RMSNorm, OMGBlock, SelfCondProjection


# ── Output ────────────────────────────────────────────────────────────────────

@dataclass
class OMGModelOutput:
    logits: torch.Tensor                        # (B, T, vocab_size)
    last_hidden_state: Optional[torch.Tensor] = None
    loss: Optional[torch.Tensor] = None


# ── Timestep Embedding ────────────────────────────────────────────────────────

class TimestepEmbedding(nn.Module):
    """
    Sinüzoidal embedding → 2 katlı MLP.
    Çıktı her katmandaki AdaLN modülüne verilir.
    """

    def __init__(self, dim: int):
        super().__init__()
        self.dim = dim
        self.mlp = nn.Sequential(
            nn.Linear(dim, dim * 4),
            nn.SiLU(),
            nn.Linear(dim * 4, dim),
            nn.SiLU(),
        )

    def forward(self, t: torch.Tensor) -> torch.Tensor:
        """t: (B,) tamsayı timestep → (B, dim)"""
        half = self.dim // 2
        freqs = torch.exp(
            -math.log(10_000)
            * torch.arange(half, device=t.device, dtype=torch.float32)
            / half
        )
        args = t.float()[:, None] * freqs[None]
        emb = torch.cat([args.sin(), args.cos()], dim=-1)  # (B, dim)
        return self.mlp(emb)


# ── Ana Model ─────────────────────────────────────────────────────────────────

class OMGModel(nn.Module):
    """
    OMGModel v2 — paralel diffusion dil modeli.

    Temel çalışma prensibi:
      1. Tüm sequence maskelenir: [prompt | MASK MASK MASK...]
      2. Her adımda tüm sequence bir forward pass ile işlenir.
      3. En yüksek güvenli tokenlar açılır.
      4. (Opsiyonel) Önceki adımın tahminleri bir sonrakine beslenir.
    """

    config_class = OMGConfig

    def __init__(self, config: OMGConfig):
        super().__init__()
        self.config = config

        self.embed = nn.Embedding(
            config.vocab_size,
            config.hidden_size,
            padding_idx=config.pad_token_id,
        )
        self.time_emb = TimestepEmbedding(config.hidden_size)

        self.self_cond_proj: Optional[SelfCondProjection] = None
        if config.self_conditioning:
            self.self_cond_proj = SelfCondProjection(config)

        self.blocks = nn.ModuleList(
            [OMGBlock(config) for _ in range(config.num_layers)]
        )
        self.norm = RMSNorm(config.hidden_size, config.rms_norm_eps)

        if config.tie_word_embeddings:
            self.lm_head = None
        else:
            self.lm_head = nn.Linear(config.hidden_size, config.vocab_size, bias=False)

        self._init_weights()

    # ── Ağırlık başlatma ──────────────────────────────────────────────

    def _init_weights(self) -> None:
        """
        Scaled init: residual katmanlar için std / sqrt(2 * num_layers).
        Derin ağlarda training stabilitesi iyileşir.
        """
        std = self.config.hidden_size ** -0.5
        depth_scale = (2 * self.config.num_layers) ** -0.5

        for name, m in self.named_modules():
            if isinstance(m, nn.Linear):
                if "out" in name or "down" in name:
                    nn.init.trunc_normal_(
                        m.weight, std=std * depth_scale, a=-3 * std, b=3 * std
                    )
                else:
                    nn.init.trunc_normal_(m.weight, std=std, a=-3 * std, b=3 * std)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Embedding):
                nn.init.trunc_normal_(m.weight, std=std)

    # ── İç forward geçişi ─────────────────────────────────────────────

    def _forward_blocks(
        self,
        x: torch.Tensor,                            # (B, T, C)
        t_emb: Optional[torch.Tensor],              # (B, C) veya None — FIX: Optional
        attn_bias: Optional[torch.Tensor],
        self_cond: Optional[torch.Tensor],          # (B, T, C)
    ) -> torch.Tensor:

        if self_cond is not None and self.self_cond_proj is not None:
            x = x + self.self_cond_proj(self_cond)

        for block in self.blocks:
            x = block(x, t_emb=t_emb, attn_bias=attn_bias)

        return self.norm(x)

    def _logits(self, hidden: torch.Tensor) -> torch.Tensor:
        if self.lm_head is not None:
            return self.lm_head(hidden)
        return F.linear(hidden, self.embed.weight)

    # ── Forward ───────────────────────────────────────────────────────

    def forward(
        self,
        input_ids: torch.Tensor,                        # (B, T)
        attention_mask: Optional[torch.Tensor] = None,  # (B, T)
        timesteps: Optional[torch.Tensor] = None,       # (B,)
        labels: Optional[torch.Tensor] = None,          # (B, T)
        self_cond: Optional[torch.Tensor] = None,       # (B, T, C)
        return_hidden: bool = False,
    ) -> OMGModelOutput:
        B, T = input_ids.shape

        x = self.embed(input_ids)                       # (B, T, C)

        t_emb: Optional[torch.Tensor] = None
        if timesteps is not None:
            t_emb = self.time_emb(timesteps)            # (B, C)

        attn_bias: Optional[torch.Tensor] = None
        if attention_mask is not None:
            attn_bias = (
                (1.0 - attention_mask.float()).unsqueeze(1).unsqueeze(2) * -1e4
            ).to(x.dtype)

        hidden = self._forward_blocks(x, t_emb, attn_bias, self_cond)
        logits = self._logits(hidden)                   # (B, T, V)

        loss: Optional[torch.Tensor] = None
        if labels is not None:
            mask = labels != self.config.pad_token_id
            loss = F.cross_entropy(
                logits[mask].float(),
                labels[mask],
                reduction="mean",
            )

        return OMGModelOutput(
            logits=logits,
            last_hidden_state=hidden if return_hidden else None,
            loss=loss,
        )

    # ── Self-conditioning yardımcısı ──────────────────────────────────

    @torch.no_grad()
    def get_soft_embedding(self, logits: torch.Tensor) -> torch.Tensor:
        """
        Logit dağılımından beklenen embedding hesapla.
        soft_emb = Σ_v  p(v) · embed(v)
        """
        probs = logits.float().softmax(-1)              # (B, T, V)
        return torch.einsum(
            "btv,vc->btc", probs, self.embed.weight.float()
        ).to(logits.dtype)

    # ── Kolaylık üretim metodu ────────────────────────────────────────

    @torch.no_grad()
    def generate(
        self,
        prompt_ids: torch.Tensor,
        new_tokens: int = 128,
        steps: int = 10,
        temperature: float = 1.0,
        top_k: int = 0,
        top_p: float = 1.0,
        remask_prob: float = 0.0,
        show_steps: bool = False,
    ) -> torch.Tensor:
        """
        MaskScheduler ve ParallelDecoder oluşturmadan doğrudan üretim.

        Model konfigürasyonundaki ``mask_token_id``, ``pad_token_id``,
        ``vocab_size`` ve ``num_diffusion_steps`` değerleri kullanılır.

        Args:
            prompt_ids: (B, P) veya (P,) prompt token id'leri.
            new_tokens: Üretilecek yeni token sayısı.
            steps: Diffusion adım sayısı (az = hızlı, çok = kaliteli).
            temperature: Örnekleme sıcaklığı.
            top_k: Top-k filtreleme (0 = kapalı).
            top_p: Nucleus sampling eşiği (1.0 = kapalı).
            remask_prob: Düşük güvenli tokenleri yeniden maskeleme oranı.
            show_steps: Her adımda ilerleme yazdır.

        Returns:
            (B, P + new_tokens) token tensor.
        """
        from omgformer.diffusion import MaskScheduler, ParallelDecoder

        cfg = self.config
        sched = MaskScheduler(
            steps=cfg.num_diffusion_steps,
            schedule=cfg.mask_schedule,
            mask_token_id=cfg.mask_token_id,
            pad_token_id=cfg.pad_token_id,
            vocab_size=cfg.vocab_size,
            random_token_prob=cfg.random_token_prob,
        )
        decoder = ParallelDecoder(self, sched)
        return decoder.generate(
            prompt_ids,
            new_tokens=new_tokens,
            steps=steps,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            remask_prob=remask_prob,
            show_steps=show_steps,
        )

    # ── Kayıt / Yükleme ───────────────────────────────────────────────

    def save_pretrained(self, directory: str) -> None:
        os.makedirs(directory, exist_ok=True)
        self.config.save(directory)

        try:
            from safetensors.torch import save_file
            save_file(self.state_dict(), os.path.join(directory, "model.safetensors"))
        except ImportError:
            torch.save(self.state_dict(), os.path.join(directory, "model.pt"))
            print(
                "[omgformer] Warning: safetensors not installed. "
                "Saved as model.pt. Install with: pip install safetensors"
            )

        print(f"[omgformer] Saved → {directory}")

    @classmethod
    def from_pretrained(cls, directory: str, map_location: str = "cpu") -> "OMGModel":
        config = OMGConfig.load(directory)
        model = cls(config)

        st_path = os.path.join(directory, "model.safetensors")
        pt_path = os.path.join(directory, "model.pt")

        if os.path.exists(st_path):
            try:
                from safetensors.torch import load_file
                state = load_file(st_path, device=map_location)
            except ImportError:
                state = torch.load(st_path, map_location=map_location, weights_only=True)
            model.load_state_dict(state)
        elif os.path.exists(pt_path):
            state = torch.load(pt_path, map_location=map_location, weights_only=True)
            model.load_state_dict(state)
        else:
            print(
                f"[omgformer] No weights found in '{directory}'. "
                "Initialising with random weights."
            )

        print(f"[omgformer] Loaded ← {directory}")
        return model

    @classmethod
    def from_config(cls, config: OMGConfig) -> "OMGModel":
        return cls(config)

    def num_parameters(self, trainable: bool = True) -> int:
        return sum(p.numel() for p in self.parameters() if not trainable or p.requires_grad)

    def __repr__(self) -> str:
        p = self.num_parameters()
        unit, val = ("B", p / 1e9) if p >= 1e9 else ("M", p / 1e6)
        return f"OMGModel({self.config!r}, actual={val:.1f}{unit} params)"
