"""
omgformer/eval.py  v2.0.3
--------------------------
Değerlendirme metrikleri.

    from omgformer.eval import Evaluator

    ev = Evaluator(model, sched, tokenizer)
    results = ev.evaluate(test_dataset)
    print(results)
    # → {"perplexity": 45.2, "bpb": 1.82, "loss": 3.81}
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Optional

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset


__all__ = ["EvalResults", "Evaluator", "compute_perplexity"]


@dataclass
class EvalResults:
    loss:       float
    perplexity: float
    bpb:        float          # bits per byte — dil modeli kalitesi
    tokens_per_sec: float
    num_tokens: int

    def __str__(self) -> str:
        return (
            f"Loss: {self.loss:.4f} | "
            f"Perplexity: {self.perplexity:.2f} | "
            f"BPB: {self.bpb:.4f} | "
            f"Hız: {self.tokens_per_sec:,.0f} tok/s | "
            f"Token: {self.num_tokens:,}"
        )

    def to_dict(self) -> dict:
        return {
            "loss": self.loss,
            "perplexity": self.perplexity,
            "bpb": self.bpb,
            "tokens_per_sec": self.tokens_per_sec,
            "num_tokens": self.num_tokens,
        }


class Evaluator:
    """
    Model değerlendirici.

    Kullanım::

        ev = Evaluator(model, scheduler, tokenizer)

        # Dataset üzerinde değerlendir
        results = ev.evaluate(test_dataset, batch_size=16)
        print(results)

        # Tek metin üzerinde perplexity
        ppl = ev.perplexity_of("Bu bir test cümlesidir.")
        print(f"PPL: {ppl:.2f}")
    """

    def __init__(self, model, scheduler, tokenizer=None):
        self.model = model
        self.scheduler = scheduler
        self.tokenizer = tokenizer
        self.device = next(model.parameters()).device

    @torch.no_grad()
    def evaluate(
        self,
        dataset: Dataset,
        batch_size: int = 16,
        max_batches: Optional[int] = None,
    ) -> EvalResults:
        """Dataset üzerinde tam değerlendirme."""
        self.model.eval()

        total_loss   = 0.0
        total_tokens = 0
        t0 = time.perf_counter()

        loader = DataLoader(dataset, batch_size=batch_size, shuffle=False)

        for i, batch in enumerate(loader):
            if max_batches and i >= max_batches:
                break

            if isinstance(batch, dict):
                input_ids = batch["input_ids"].to(self.device)
                attn_mask = batch.get("attention_mask")
                if attn_mask is not None:
                    attn_mask = attn_mask.to(self.device)
            else:
                input_ids = batch.to(self.device)
                attn_mask = None

            # Diffusion loss
            noisy, mask, t = self.scheduler.corrupt(input_ids)
            loss = self.scheduler.loss(
                self.model, noisy, input_ids, mask, t,
                attention_mask=attn_mask,
                self_cond_prob=0.0,   # eval'de self-cond kapalı
            )

            n_tokens = mask.sum().item()
            total_loss   += loss.item() * n_tokens
            total_tokens += n_tokens

        elapsed = time.perf_counter() - t0

        avg_loss = total_loss / max(total_tokens, 1)
        perplexity = math.exp(min(avg_loss, 20))    # overflow koruması
        bpb = avg_loss / math.log(2)                # nats → bits

        return EvalResults(
            loss=avg_loss,
            perplexity=perplexity,
            bpb=bpb,
            tokens_per_sec=total_tokens / max(elapsed, 1e-9),
            num_tokens=total_tokens,
        )

    @torch.no_grad()
    def perplexity_of(self, text: str, seq_len: int = 512) -> float:
        """Tek metin için perplexity hesapla."""
        if self.tokenizer is None:
            raise ValueError("tokenizer gerekli")

        ids = self.tokenizer.encode(text)
        if not isinstance(ids, torch.Tensor):
            ids = torch.tensor(ids, dtype=torch.long)

        # seq_len'e kırp veya pad et
        if len(ids) > seq_len:
            ids = ids[:seq_len]

        input_ids = ids.unsqueeze(0).to(self.device)
        noisy, mask, t = self.scheduler.corrupt(input_ids)

        if not mask.any():
            return float("inf")

        loss = self.scheduler.loss(
            self.model, noisy, input_ids, mask, t, self_cond_prob=0.0
        )
        return math.exp(min(loss.item(), 20))


def compute_perplexity(
    model,
    scheduler,
    dataset: Dataset,
    batch_size: int = 16,
    device: str = "cpu",
) -> float:
    """
    Hızlı perplexity hesaplama fonksiyonu.

    Kullanım::

        ppl = compute_perplexity(model, sched, test_dataset)
        print(f"Perplexity: {ppl:.2f}")
    """
    ev = Evaluator(model, scheduler)
    results = ev.evaluate(dataset, batch_size=batch_size, max_batches=100)
    return results.perplexity
