"""
omgformer/callbacks.py  v2.0.3
-------------------------------
Eğitim sırasında olayları yakalamak için callback sistemi.

Kullanım:
    from omgformer.callbacks import (
        EarlyStopping, ModelCheckpoint, LearningRateFinder, ProgressBar
    )

    trainer = Trainer(model, sched, cfg, callbacks=[
        ProgressBar(),
        EarlyStopping(patience=5),
        ModelCheckpoint("./best_model"),
    ])
"""

from __future__ import annotations

import os
import time
from typing import Optional


__all__ = [
    "Callback",
    "EarlyStopping",
    "ModelCheckpoint",
    "ProgressBar",
    "LossLogger",
    "LearningRateFinder",
]


# ── Base Callback ─────────────────────────────────────────────────────────────

class Callback:
    """Base class. İstediğin metodu override et."""

    def on_train_begin(self, trainer): pass
    def on_train_end(self, trainer): pass
    def on_step_begin(self, trainer, step: int): pass
    def on_step_end(self, trainer, step: int, loss: float): pass
    def on_log(self, trainer, step: int, metrics: dict): pass
    def on_save(self, trainer, step: int, path: str): pass


# ── Early Stopping ────────────────────────────────────────────────────────────

class EarlyStopping(Callback):
    """
    Loss iyileşmediğinde eğitimi durdur.

    Kullanım::

        EarlyStopping(patience=10, min_delta=0.001)
    """

    def __init__(self, patience: int = 10, min_delta: float = 1e-4):
        self.patience = patience
        self.min_delta = min_delta
        self.best_loss = float("inf")
        self.wait = 0
        self.stopped = False

    def on_log(self, trainer, step: int, metrics: dict):
        loss = metrics.get("train/loss", float("inf"))
        if loss < self.best_loss - self.min_delta:
            self.best_loss = loss
            self.wait = 0
        else:
            self.wait += 1
            if self.wait >= self.patience:
                print(f"\n[EarlyStopping] {self.patience} log adımı boyunca iyileşme yok. Durduruluyor.")
                trainer._stop_training = True
                self.stopped = True


# ── Model Checkpoint ──────────────────────────────────────────────────────────

class ModelCheckpoint(Callback):
    """
    En iyi modeli otomatik kaydet.

    Kullanım::

        ModelCheckpoint("./best_model", monitor="loss", save_best_only=True)
    """

    def __init__(
        self,
        directory: str = "./best_checkpoint",
        monitor: str = "loss",
        save_best_only: bool = True,
    ):
        self.directory = directory
        self.monitor = monitor
        self.save_best_only = save_best_only
        self.best = float("inf")

    def on_log(self, trainer, step: int, metrics: dict):
        current = metrics.get(f"train/{self.monitor}", float("inf"))

        if not self.save_best_only or current < self.best:
            self.best = current
            path = os.path.join(self.directory, f"step-{step:07d}")
            trainer.raw_model.save_pretrained(path)
            print(f"[ModelCheckpoint] Kaydedildi → {path}  ({self.monitor}={current:.4f})")

    def on_save(self, trainer, step: int, path: str):
        pass


# ── Progress Bar ──────────────────────────────────────────────────────────────

class ProgressBar(Callback):
    """
    Güzel progress bar. tqdm varsa tqdm, yoksa basit.

    Kullanım::

        ProgressBar()
    """

    def __init__(self):
        self._tqdm = None
        self._t0 = None

    def on_train_begin(self, trainer):
        self._t0 = time.perf_counter()
        try:
            from tqdm import tqdm
            self._tqdm = tqdm(
                total=trainer.config.steps,
                desc="Eğitim",
                unit="adım",
                dynamic_ncols=True,
            )
        except ImportError:
            print("[ProgressBar] tqdm kurulu değil: pip install tqdm")

    def on_step_end(self, trainer, step: int, loss: float):
        if self._tqdm:
            elapsed = time.perf_counter() - self._t0
            tps = (step * trainer.config.batch_size * trainer.config.seq_len) / elapsed
            self._tqdm.update(1)
            self._tqdm.set_postfix(loss=f"{loss:.4f}", tok_s=f"{tps:,.0f}")

    def on_train_end(self, trainer):
        if self._tqdm:
            self._tqdm.close()
        elapsed = time.perf_counter() - self._t0
        print(f"\n[ProgressBar] Eğitim tamamlandı. Toplam süre: {elapsed:.1f}s")


# ── Loss Logger ───────────────────────────────────────────────────────────────

class LossLogger(Callback):
    """
    Loss geçmişini kaydet. Plot için kullanışlı.

    Kullanım::

        logger = LossLogger()
        # eğitimden sonra:
        logger.plot()          # matplotlib ile çiz
        logger.save("log.csv") # CSV'ye kaydet
    """

    def __init__(self):
        self.steps: list[int] = []
        self.losses: list[float] = []
        self.lrs: list[float] = []

    def on_log(self, trainer, step: int, metrics: dict):
        self.steps.append(step)
        self.losses.append(metrics.get("train/loss", 0.0))
        self.lrs.append(metrics.get("train/lr", 0.0))

    def plot(self, save_path: Optional[str] = None):
        try:
            import matplotlib.pyplot as plt
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
            ax1.plot(self.steps, self.losses)
            ax1.set_xlabel("Adım"); ax1.set_ylabel("Loss"); ax1.set_title("Eğitim Loss")
            ax2.plot(self.steps, self.lrs)
            ax2.set_xlabel("Adım"); ax2.set_ylabel("LR"); ax2.set_title("Learning Rate")
            plt.tight_layout()
            if save_path:
                plt.savefig(save_path)
                print(f"[LossLogger] Graf kaydedildi → {save_path}")
            else:
                plt.show()
        except ImportError:
            print("[LossLogger] matplotlib kurulu değil: pip install matplotlib")

    def save(self, path: str = "training_log.csv"):
        with open(path, "w") as f:
            f.write("step,loss,lr\n")
            for s, l, lr in zip(self.steps, self.losses, self.lrs):
                f.write(f"{s},{l:.6f},{lr:.8f}\n")
        print(f"[LossLogger] Log kaydedildi → {path}")


# ── Learning Rate Finder ──────────────────────────────────────────────────────

class LearningRateFinder(Callback):
    """
    Otomatik en iyi LR bulma.

    LR'yi logaritmik artırarak loss'u izler.
    Loss artmaya başlamadan önceki LR en iyidir.

    Kullanım::

        finder = LearningRateFinder(min_lr=1e-7, max_lr=1.0, num_steps=100)
        trainer = Trainer(model, sched, cfg, callbacks=[finder])
        trainer.fit()
        print(f"Önerilen LR: {finder.best_lr:.2e}")
        finder.plot()
    """

    def __init__(
        self,
        min_lr: float = 1e-7,
        max_lr: float = 1.0,
        num_steps: int = 100,
    ):
        self.min_lr = min_lr
        self.max_lr = max_lr
        self.num_steps = num_steps
        self.lrs: list[float] = []
        self.losses: list[float] = []
        self.best_lr: Optional[float] = None
        self._step = 0

    def on_train_begin(self, trainer):
        # num_steps adımda min→max arasını log-linear tara
        import math
        self._lr_schedule = [
            self.min_lr * (self.max_lr / self.min_lr) ** (i / self.num_steps)
            for i in range(self.num_steps)
        ]
        print(f"[LRFinder] {self.num_steps} adımda LR taranıyor: {self.min_lr:.2e} → {self.max_lr:.2e}")

    def on_step_begin(self, trainer, step: int):
        if step < len(self._lr_schedule):
            lr = self._lr_schedule[step]
            for g in trainer.optimizer.param_groups:
                g["lr"] = lr

    def on_step_end(self, trainer, step: int, loss: float):
        if step < self.num_steps:
            self.lrs.append(self._lr_schedule[step])
            self.losses.append(loss)
        if step >= self.num_steps:
            trainer._stop_training = True
            self._find_best()

    def _find_best(self):
        if not self.losses:
            return
        # En hızlı düşüşün olduğu LR
        min_grad_idx = 0
        best_grad = 0
        for i in range(1, len(self.losses)):
            grad = self.losses[i - 1] - self.losses[i]
            if grad > best_grad:
                best_grad = grad
                min_grad_idx = i
        self.best_lr = self.lrs[min_grad_idx]
        print(f"\n[LRFinder] Önerilen LR: {self.best_lr:.2e}")

    def plot(self, save_path: Optional[str] = None):
        try:
            import matplotlib.pyplot as plt
            plt.figure(figsize=(8, 4))
            plt.semilogx(self.lrs, self.losses)
            if self.best_lr:
                plt.axvline(x=self.best_lr, color="red", linestyle="--",
                           label=f"Önerilen: {self.best_lr:.2e}")
            plt.xlabel("Learning Rate"); plt.ylabel("Loss")
            plt.title("LR Finder")
            plt.legend()
            if save_path:
                plt.savefig(save_path)
            else:
                plt.show()
        except ImportError:
            print("[LRFinder] matplotlib kurulu değil: pip install matplotlib")
