"""omgformer v2.0.3 — Paralel Diffusion Dil Modeli"""

from omgformer.configuration import OMGConfig, OMGCONFIG_REGISTRY, MoEConfig
from omgformer.layers import (
    RMSNorm, RotaryEmbedding, GroupedQueryAttention,
    SwiGLUFFN, AdaLNModulation, SelfCondProjection, OMGBlock,
)
from omgformer.modeling import OMGModel, OMGModelOutput, TimestepEmbedding
from omgformer.diffusion import MaskScheduler, ParallelDecoder
from omgformer.tokenization import OMGTokenizer
from omgformer.auto import AutoConfig, AutoModel
from omgformer.pipeline import pipeline
from omgformer.lora import (
    LoRAConfig, LoRALinear, add_lora, merge_lora, save_lora, load_lora,
)
from omgformer.utils import (
    set_seed, count_parameters, get_model_size_mb,
    get_device, tokens_per_second, format_number,
)
from omgformer.data import (
    TextDataset, PackedDataset, DataCollator,
    load_text_file, infinite_loader,
)
from omgformer.eval import Evaluator, EvalResults, compute_perplexity
from omgformer.callbacks import (
    Callback, EarlyStopping, ModelCheckpoint,
    ProgressBar, LossLogger, LearningRateFinder,
)
from omgformer.quantize import quantize_int8, quantize_int4, model_size_mb
from omgformer.moe import MoEFFN, RouterLoadBalancingLoss

__version__ = "2.0.3"
__all__ = [
    # Config
    "OMGConfig", "OMGCONFIG_REGISTRY", "MoEConfig",
    # Layers
    "RMSNorm", "RotaryEmbedding", "GroupedQueryAttention",
    "SwiGLUFFN", "AdaLNModulation", "SelfCondProjection", "OMGBlock",
    # Model
    "OMGModel", "OMGModelOutput", "TimestepEmbedding",
    # Diffusion
    "MaskScheduler", "ParallelDecoder",
    # Tokenizer
    "OMGTokenizer",
    # Auto
    "AutoConfig", "AutoModel",
    # Pipeline
    "pipeline",
    # LoRA
    "LoRAConfig", "LoRALinear", "add_lora", "merge_lora", "save_lora", "load_lora",
    # Utils
    "set_seed", "count_parameters", "get_model_size_mb",
    "get_device", "tokens_per_second", "format_number",
    # Data
    "TextDataset", "PackedDataset", "DataCollator",
    "load_text_file", "infinite_loader",
    # Eval
    "Evaluator", "EvalResults", "compute_perplexity",
    # Callbacks
    "Callback", "EarlyStopping", "ModelCheckpoint",
    "ProgressBar", "LossLogger", "LearningRateFinder",
    # Quantize
    "quantize_int8", "quantize_int4", "model_size_mb",
    # MoE
    "MoEFFN", "RouterLoadBalancingLoss",
]
