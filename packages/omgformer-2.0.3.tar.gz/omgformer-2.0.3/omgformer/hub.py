"""
omgformer/hub.py  v2.0.2
-------------------------
HuggingFace Hub entegrasyonu.

Kullanım:
    from omgformer.hub import push_to_hub, load_from_hub

    push_to_hub(model, "kullanici/omgformer-base", token="hf_xxx")
    model = load_from_hub("kullanici/omgformer-base")
"""

from __future__ import annotations

import os
import tempfile
from typing import Optional

from omgformer.modeling import OMGModel


__all__ = ["push_to_hub", "load_from_hub"]


def push_to_hub(
    model: OMGModel,
    repo_id: str,
    token: Optional[str] = None,
    private: bool = False,
    commit_message: str = "omgformer modeli yüklendi",
):
    """
    Modeli HuggingFace Hub'a yükle.

    Kullanım::

        push_to_hub(model, "kullanici/benim-modelim", token="hf_xxx")

    Args:
        model: Yüklenecek OMGModel.
        repo_id: "kullanici/model-adi" formatında HuggingFace repo ID'si.
        token: HuggingFace API token'ı. None ise HF_TOKEN env değişkenine bakılır.
        private: True ise repo gizli olur.
        commit_message: Commit mesajı.
    """
    try:
        from huggingface_hub import HfApi, create_repo
    except ImportError:
        raise ImportError(
            "huggingface_hub kurulu değil. "
            "Kurmak için: pip install huggingface-hub"
        )

    token = token or os.environ.get("HF_TOKEN")
    api   = HfApi(token=token)

    # Repo oluştur (zaten varsa atla)
    try:
        create_repo(repo_id, token=token, private=private, exist_ok=True)
        print(f"  Repo hazır: https://huggingface.co/{repo_id}")
    except Exception as e:
        print(f"  Uyarı: Repo oluşturulamadı: {e}")

    # Geçici klasöre kaydet, oradan yükle
    with tempfile.TemporaryDirectory() as tmpdir:
        model.save_pretrained(tmpdir)

        # Model kartı ekle
        _write_model_card(tmpdir, repo_id, model)

        api.upload_folder(
            folder_path=tmpdir,
            repo_id=repo_id,
            commit_message=commit_message,
        )

    print(f"  Yüklendi ✓  →  https://huggingface.co/{repo_id}")


def load_from_hub(
    repo_id: str,
    token: Optional[str] = None,
    map_location: str = "cpu",
) -> OMGModel:
    """
    HuggingFace Hub'dan model indir ve yükle.

    Kullanım::

        model = load_from_hub("kullanici/omgformer-base")

    Args:
        repo_id: "kullanici/model-adi" formatında repo ID'si.
        token: Gizli repo için HuggingFace token'ı.
        map_location: Model hangi cihaza yüklensin.

    Returns:
        Yüklenmiş OMGModel.
    """
    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        raise ImportError(
            "huggingface_hub kurulu değil. "
            "Kurmak için: pip install huggingface-hub"
        )

    token = token or os.environ.get("HF_TOKEN")

    print(f"  İndiriliyor: {repo_id} ...")
    local_dir = snapshot_download(repo_id, token=token)
    print(f"  İndirildi ✓  →  {local_dir}")

    return OMGModel.from_pretrained(local_dir, map_location=map_location)


def _write_model_card(directory: str, repo_id: str, model: OMGModel):
    """Otomatik model kartı oluştur."""
    cfg = model.config
    p   = model.num_parameters()
    unit, val = ("B", p / 1e9) if p >= 1e9 else ("M", p / 1e6)

    card = f"""---
license: apache-2.0
library_name: omgformer
tags:
  - diffusion
  - language-model
  - masked-diffusion
  - parallel-decoding
  - pytorch
---

# {repo_id.split('/')[-1]}

Paralel diffusion dil modeli — [omgformer](https://pypi.org/project/omgformer/) kütüphanesiyle eğitildi.

## Model Bilgisi

| | |
|--|--|
| Parametre | ~{val:.1f}{unit} |
| Katman | {cfg.num_layers} |
| Hidden | {cfg.hidden_size} |
| Heads (Q/KV) | {cfg.num_heads}/{cfg.num_kv_heads} |
| AdaLN-Zero | {'✓' if cfg.use_adaLN else '✗'} |
| Self-conditioning | {'✓' if cfg.self_conditioning else '✗'} |

## Kullanım

```python
pip install omgformer
```

```python
from omgformer.hub import load_from_hub
from omgformer.diffusion import MaskScheduler, ParallelDecoder

model = load_from_hub("{repo_id}")
sched = MaskScheduler(steps=10, mask_token_id=model.config.mask_token_id,
                      pad_token_id=model.config.pad_token_id,
                      vocab_size=model.config.vocab_size)
decoder = ParallelDecoder(model, sched)
```
"""
    with open(os.path.join(directory, "README.md"), "w", encoding="utf-8") as f:
        f.write(card)
