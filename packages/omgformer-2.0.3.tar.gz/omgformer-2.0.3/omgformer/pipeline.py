"""omgformer/pipeline.py  v2.0.1"""

from __future__ import annotations

from typing import Optional

import torch

from omgformer.configuration import OMGConfig
from omgformer.diffusion import MaskScheduler, ParallelDecoder
from omgformer.modeling import OMGModel
from omgformer.tokenization import OMGTokenizer


def pipeline(
    task: str,
    model: str | OMGModel = "omgformer-base",
    tokenizer: str | OMGTokenizer | None = None,
    device: str = "auto",
    **kwargs,
):
    """
    Yüksek seviyeli üretim pipeline'ı.

    Args:
        task: Şu an yalnızca ``"text-generation"`` desteklenir.
        model: Preset adı, checkpoint dizini veya ``OMGModel`` örneği.
        tokenizer: HuggingFace tokenizer adı veya ``OMGTokenizer`` örneği.
        device: ``"auto"``, ``"cuda"``, ``"mps"``, ``"cpu"``.

    Returns:
        Çağrılabilir bir üretim fonksiyonu.

    Raises:
        ValueError: Desteklenmeyen görev verilirse.
    """
    if task != "text-generation":
        raise ValueError(
            f"Unsupported task '{task}'. Currently only 'text-generation' is supported."
        )

    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"

    if isinstance(model, str):
        try:
            cfg = OMGConfig.from_preset(model)
        except ValueError:
            cfg = OMGConfig.load(model)
        mdl = OMGModel(cfg).to(device).eval()
    else:
        mdl = model
        cfg = mdl.config

    tok = tokenizer
    if tok is None or isinstance(tok, str):
        tok_name = tok or "bert-base-uncased"
        tok = OMGTokenizer.from_pretrained(tok_name)

    sched = MaskScheduler(
        steps=cfg.num_diffusion_steps,
        schedule=cfg.mask_schedule,
        mask_token_id=cfg.mask_token_id,
        pad_token_id=cfg.pad_token_id,
        vocab_size=cfg.vocab_size,
        random_token_prob=cfg.random_token_prob,
    )
    decoder = ParallelDecoder(mdl, sched)

    def _generate(
        prompt: str,
        new_tokens: int = 128,
        steps: int = 10,
        temperature: float = 1.0,
        top_k: int = 0,
        top_p: float = 0.9,
        remask_prob: float = 0.05,
        **gen_kwargs,
    ) -> dict:
        prompt_ids = tok.encode(prompt).unsqueeze(0).to(device)
        out = decoder.generate(
            prompt_ids,
            new_tokens=new_tokens,
            steps=steps,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            remask_prob=remask_prob,
            **gen_kwargs,
        )
        return {"generated_text": tok.decode(out[0])}

    return _generate
