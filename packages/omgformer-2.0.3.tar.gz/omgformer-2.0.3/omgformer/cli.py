"""
omgformer/cli.py  v2.0.2
-------------------------
Komut satırı arayüzü. Sıradan kullanıcılar için.

Kullanım:
    omgformer info                          # model bilgisi
    omgformer generate --prompt "Merhaba"  # metin üret
    omgformer benchmark                     # hız testi
    omgformer train --data metin.txt       # basit eğitim
"""

from __future__ import annotations

import argparse
import sys
import time


def cmd_info(args):
    """Kurulu omgformer hakkında bilgi ver."""
    import torch
    from omgformer import __version__, OMGConfig, OMGCONFIG_REGISTRY

    print(f"\n  omgformer v{__version__}")
    print(f"  PyTorch   : {torch.__version__}")
    print(f"  CUDA      : {'✓  ' + torch.version.cuda if torch.cuda.is_available() else '✗  Yok'}")
    print(f"  MPS       : {'✓' if torch.backends.mps.is_available() else '✗  Yok'}")
    print()
    print("  Hazır presetler:")
    for name in OMGCONFIG_REGISTRY:
        cfg = OMGConfig.from_preset(name)
        p = cfg.num_parameters()
        unit = "B" if p >= 1e9 else "M"
        val  = p / 1e9 if p >= 1e9 else p / 1e6
        print(f"    {name:<20} ~{val:.1f}{unit} parametre")
    print()

    # İsteğe bağlı paketler
    optional = {"safetensors": "safetensors", "wandb": "wandb", "triton": "triton"}
    print("  İsteğe bağlı paketler:")
    for pkg, pip_name in optional.items():
        try:
            __import__(pkg)
            print(f"    ✓  {pkg}")
        except ImportError:
            print(f"    ✗  {pkg}  (pip install {pip_name})")
    print()


def cmd_generate(args):
    """Modelden metin üret."""
    import torch
    from omgformer import OMGConfig, OMGModel
    from omgformer.diffusion import MaskScheduler, ParallelDecoder

    print(f"\n  Preset: {args.preset}")
    print(f"  Prompt: {args.prompt!r}")
    print(f"  Yeni token: {args.new_tokens}  |  Adım: {args.steps}")
    print()

    cfg   = OMGConfig.from_preset(args.preset)
    model = OMGModel(cfg).eval()

    p = model.num_parameters()
    unit = "B" if p >= 1e9 else "M"
    print(f"  Model yüklendi  ({p / 1e9:.1f}B)" if p >= 1e9 else f"  Model yüklendi  ({p / 1e6:.1f}M)")

    try:
        from omgformer.tokenization import OMGTokenizer
        tok = OMGTokenizer.from_pretrained("bert-base-uncased")
        prompt_ids = tok.encode(args.prompt).unsqueeze(0)
    except Exception:
        # tokenizer yoksa basit char-level simülasyon
        prompt_ids = torch.randint(2, cfg.vocab_size, (1, min(len(args.prompt), 32)))
        tok = None

    sched   = MaskScheduler(steps=args.steps, mask_token_id=cfg.mask_token_id,
                            pad_token_id=cfg.pad_token_id, vocab_size=cfg.vocab_size)
    decoder = ParallelDecoder(model, sched)

    print("  Üretiliyor", end="", flush=True)
    t0  = time.perf_counter()
    out = decoder.generate(prompt_ids, new_tokens=args.new_tokens, steps=args.steps,
                           temperature=args.temperature, show_steps=False)
    elapsed = time.perf_counter() - t0
    tps = args.new_tokens / elapsed
    print(f"\r  Üretildi ✓  ({tps:.0f} tok/s, {elapsed:.2f}s)\n")

    if tok:
        print("  Çıktı:", tok.decode(out[0]))
    else:
        print("  Çıktı: (tokenizer kurulu değil, ham token ID'ler üretildi)")
    print()


def cmd_benchmark(args):
    """Hız testi."""
    import torch
    from omgformer import OMGConfig, OMGModel
    from omgformer.diffusion import MaskScheduler, ParallelDecoder
    from omgformer.utils import get_device, format_number

    device = get_device()
    print(f"\n  Cihaz: {device}")
    print(f"  Preset: {args.preset}\n")

    cfg   = OMGConfig.from_preset(args.preset)
    model = OMGModel(cfg).to(device).eval()
    sched = MaskScheduler(steps=10, mask_token_id=cfg.mask_token_id,
                          pad_token_id=cfg.pad_token_id, vocab_size=cfg.vocab_size)
    decoder = ParallelDecoder(model, sched)

    B, N = args.batch, args.new_tokens
    prompt = torch.randint(2, cfg.vocab_size, (B, 16)).to(device)

    # Warmup
    print("  Warmup...", end="", flush=True)
    for _ in range(2):
        decoder.generate(prompt, new_tokens=N, steps=5)
    print("\r           \r", end="")

    # Benchmark
    print("  Ölçülüyor...", end="", flush=True)
    runs = []
    for _ in range(args.runs):
        t0 = time.perf_counter()
        decoder.generate(prompt, new_tokens=N, steps=10)
        runs.append(time.perf_counter() - t0)

    avg  = sum(runs) / len(runs)
    tps  = B * N / avg
    print(f"\r  Sonuç:")
    print(f"    Ortalama süre : {avg * 1000:.1f} ms")
    print(f"    Token/sn      : {format_number(tps)}")
    print(f"    Batch×token   : {B}×{N} = {format_number(B * N)} token\n")


def cmd_train(args):
    """Basit eğitim. Yeni başlayanlar için."""
    import torch
    from omgformer import OMGConfig, OMGModel
    from omgformer.diffusion import MaskScheduler
    from omgformer.training import Trainer, TrainingConfig

    print(f"\n  Veri: {args.data}")
    print(f"  Preset: {args.preset}")
    print(f"  Adım: {args.steps}\n")

    # Veriyi oku
    try:
        with open(args.data, encoding="utf-8") as f:
            text = f.read()
        print(f"  Veri yüklendi: {len(text):,} karakter")
    except FileNotFoundError:
        print(f"  Hata: '{args.data}' bulunamadı.")
        sys.exit(1)

    try:
        from omgformer.tokenization import OMGTokenizer
        tok = OMGTokenizer.from_pretrained("bert-base-uncased")
        all_ids = tok.encode(text)
    except Exception as e:
        print(f"  Tokenizer hatası: {e}")
        sys.exit(1)

    cfg   = OMGConfig.from_preset(args.preset)
    model = OMGModel(cfg)
    sched = MaskScheduler(steps=64, mask_token_id=cfg.mask_token_id,
                          pad_token_id=cfg.pad_token_id, vocab_size=cfg.vocab_size)

    seq_len = 128

    def get_batch(B):
        starts = torch.randint(0, max(1, len(all_ids) - seq_len), (B,))
        return torch.stack([all_ids[s:s + seq_len] for s in starts])

    train_cfg = TrainingConfig(
        steps=args.steps,
        batch_size=args.batch_size,
        seq_len=seq_len,
        lr=3e-4,
        warmup_steps=min(100, args.steps // 10),
        use_amp=torch.cuda.is_available(),
        use_compile=False,
        log_every=max(1, args.steps // 20),
        save_every=args.steps,
        output_dir=args.output,
        device="cuda" if torch.cuda.is_available() else "cpu",
    )

    trainer = Trainer(model, sched, train_cfg, get_batch=get_batch)
    trainer.fit()
    print(f"\n  Model kaydedildi → {args.output}\n")


def main():
    parser = argparse.ArgumentParser(
        prog="omgformer",
        description="omgformer — Paralel Diffusion Dil Modeli",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Örnekler:
  omgformer info
  omgformer generate --prompt "Yapay zeka"
  omgformer benchmark --preset omgformer-small
  omgformer train --data metin.txt --steps 1000
        """,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # info
    sub.add_parser("info", help="Kurulum ve preset bilgisi")

    # generate
    gen = sub.add_parser("generate", help="Metin üret")
    gen.add_argument("--prompt",     default="Merhaba", help="Başlangıç metni")
    gen.add_argument("--preset",     default="omgformer-tiny")
    gen.add_argument("--new-tokens", dest="new_tokens", type=int, default=64)
    gen.add_argument("--steps",      type=int, default=10)
    gen.add_argument("--temperature",type=float, default=1.0)

    # benchmark
    bench = sub.add_parser("benchmark", help="Hız testi")
    bench.add_argument("--preset",     default="omgformer-tiny")
    bench.add_argument("--batch",      type=int, default=4)
    bench.add_argument("--new-tokens", dest="new_tokens", type=int, default=128)
    bench.add_argument("--runs",       type=int, default=5)

    # train
    train = sub.add_parser("train", help="Basit eğitim")
    train.add_argument("--data",       required=True, help="Metin dosyası (.txt)")
    train.add_argument("--preset",     default="omgformer-tiny")
    train.add_argument("--steps",      type=int, default=1000)
    train.add_argument("--batch-size", dest="batch_size", type=int, default=4)
    train.add_argument("--output",     default="./omgformer_output")

    args = parser.parse_args()

    commands = {
        "info":      cmd_info,
        "generate":  cmd_generate,
        "benchmark": cmd_benchmark,
        "train":     cmd_train,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
