"""omgformer/auto.py  v2.0.1"""

from omgformer.configuration import OMGConfig
from omgformer.modeling import OMGModel


class AutoConfig:
    @classmethod
    def from_pretrained(cls, directory: str) -> OMGConfig:
        return OMGConfig.load(directory)


class AutoModel:
    @classmethod
    def from_config(cls, config: OMGConfig) -> OMGModel:
        return OMGModel(config)

    @classmethod
    def from_pretrained(cls, directory: str, device: str = "cpu", **kwargs) -> OMGModel:
        return OMGModel.from_pretrained(directory, map_location=device, **kwargs)
