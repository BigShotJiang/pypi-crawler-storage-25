"""
omgformer/configuration.py  v2.0.1
-----------------------------------
Değişiklikler (2.0.1):
  - Bare ``assert`` ifadeleri ``ValueError`` ile değiştirildi
    (-O bayrağıyla devre dışı bırakılamazlar artık).
  - ``from_json_string()`` classmethod eklendi.
  - ``validate()`` metodu eklendi (konfigürasyonu erken doğrular).
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class OMGConfig:
    # ── Model boyutları ────────────────────────────────────────────────
    vocab_size: int = 32_000
    hidden_size: int = 768
    num_layers: int = 12
    num_heads: int = 12
    num_kv_heads: int | None = None      # None = MHA. 1-4 = GQA
    head_dim: int | None = None
    intermediate_size: int | None = None
    max_length: int = 4096
    dropout: float = 0.0
    rms_norm_eps: float = 1e-6

    # ── Vocab / özel tokenlar ──────────────────────────────────────────
    pad_token_id: int = 0
    mask_token_id: int = 1
    bos_token_id: int = 2
    eos_token_id: int = 3

    # ── Mimari flagler ────────────────────────────────────────────────
    tie_word_embeddings: bool = True
    use_flash_attention: bool = True
    rope_base: int = 10_000
    rope_scaling: float = 1.0

    # ── AdaLN-Zero (DiT'ten ilham) ────────────────────────────────────
    use_adaLN: bool = True

    # ── Self-conditioning ─────────────────────────────────────────────
    self_conditioning: bool = True
    self_cond_prob: float = 0.5

    # ── Diffusion ─────────────────────────────────────────────────────
    num_diffusion_steps: int = 64
    mask_schedule: str = "cosine"        # cosine | linear | sqrt | sigmoid
    random_token_prob: float = 0.1
    remask_prob: float = 0.0

    # ── Model kimliği ─────────────────────────────────────────────────
    model_type: str = "omgformer"
    name_or_path: str = ""
    architectures: list[str] = field(default_factory=lambda: ["OMGModel"])

    def __post_init__(self) -> None:
        if self.head_dim is None:
            if self.hidden_size % self.num_heads != 0:
                raise ValueError(
                    f"hidden_size ({self.hidden_size}) must be divisible by "
                    f"num_heads ({self.num_heads})."
                )
            self.head_dim = self.hidden_size // self.num_heads

        if self.num_kv_heads is None:
            self.num_kv_heads = self.num_heads

        if self.num_heads % self.num_kv_heads != 0:
            raise ValueError(
                f"num_heads ({self.num_heads}) must be divisible by "
                f"num_kv_heads ({self.num_kv_heads})."
            )

        if self.intermediate_size is None:
            raw = int(self.hidden_size * 8 / 3)
            self.intermediate_size = (raw + 255) // 256 * 256

    # ── Doğrulama ─────────────────────────────────────────────────────

    def validate(self) -> None:
        """
        Konfigürasyonu erken doğrula.

        ``__post_init__`` temel aritmetik kısıtları kontrol eder; bu metod
        değer aralıklarını ve mantıksal tutarsızlıkları kontrol eder.
        Geçersizse ``ValueError`` fırlatır.
        """
        if self.vocab_size < 10:
            raise ValueError(f"vocab_size must be ≥ 10, got {self.vocab_size}.")
        if self.hidden_size < 16:
            raise ValueError(f"hidden_size must be ≥ 16, got {self.hidden_size}.")
        if self.num_layers < 1:
            raise ValueError(f"num_layers must be ≥ 1, got {self.num_layers}.")
        if not (0.0 <= self.dropout < 1.0):
            raise ValueError(f"dropout must be in [0, 1), got {self.dropout}.")
        if not (0.0 <= self.self_cond_prob <= 1.0):
            raise ValueError(
                f"self_cond_prob must be in [0, 1], got {self.self_cond_prob}."
            )
        if not (0.0 <= self.random_token_prob <= 0.5):
            raise ValueError(
                f"random_token_prob must be in [0, 0.5], got {self.random_token_prob}."
            )
        valid_schedules = {"cosine", "linear", "sqrt", "sigmoid"}
        if self.mask_schedule not in valid_schedules:
            raise ValueError(
                f"mask_schedule must be one of {valid_schedules}, "
                f"got '{self.mask_schedule}'."
            )
        if self.num_diffusion_steps < 1:
            raise ValueError(
                f"num_diffusion_steps must be ≥ 1, got {self.num_diffusion_steps}."
            )

    # ── I/O ───────────────────────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

    def save(self, directory: str) -> None:
        os.makedirs(directory, exist_ok=True)
        with open(os.path.join(directory, "config.json"), "w", encoding="utf-8") as f:
            f.write(self.to_json())

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "OMGConfig":
        known = set(cls.__dataclass_fields__)
        return cls(**{k: v for k, v in d.items() if k in known})

    @classmethod
    def from_json_string(cls, json_str: str) -> "OMGConfig":
        """
        JSON dizisinden doğrudan bir ``OMGConfig`` oluştur.

        Kullanım::

            cfg = OMGConfig.from_json_string(open("config.json").read())
        """
        return cls.from_dict(json.loads(json_str))

    @classmethod
    def load(cls, directory: str) -> "OMGConfig":
        path = os.path.join(directory, "config.json")
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"config.json not found in '{directory}'. "
                "Make sure you saved the config with OMGConfig.save()."
            )
        with open(path, encoding="utf-8") as f:
            return cls.from_dict(json.load(f))

    @classmethod
    def from_preset(cls, name: str) -> "OMGConfig":
        if name not in OMGCONFIG_REGISTRY:
            raise ValueError(
                f"Unknown preset '{name}'. "
                f"Available presets: {list(OMGCONFIG_REGISTRY)}."
            )
        return cls(**OMGCONFIG_REGISTRY[name])

    def num_parameters(self) -> int:
        """Tahmini parametre sayısı (analitik hesap)."""
        E = self.vocab_size * self.hidden_size
        q_size = self.num_heads * self.head_dim
        kv_size = self.num_kv_heads * self.head_dim
        attn = self.num_layers * self.hidden_size * (q_size + 2 * kv_size + self.hidden_size)
        ffn = self.num_layers * 3 * self.hidden_size * self.intermediate_size
        norms = self.num_layers * 4 * self.hidden_size
        adaLN = (
            self.num_layers * 6 * self.hidden_size * self.hidden_size
            if self.use_adaLN
            else 0
        )
        head = 0 if self.tie_word_embeddings else self.vocab_size * self.hidden_size
        return E + attn + ffn + norms + adaLN + head

    @property
    def gqa_ratio(self) -> int:
        """Q head / KV head oranı."""
        return self.num_heads // self.num_kv_heads

    def __repr__(self) -> str:
        p = self.num_parameters()
        unit, val = ("B", p / 1e9) if p >= 1e9 else ("M", p / 1e6)
        gqa = f", GQA={self.num_kv_heads}kv" if self.num_kv_heads != self.num_heads else ""
        sc = ", SC=on" if self.self_conditioning else ""
        return (
            f"OMGConfig(hidden={self.hidden_size}, layers={self.num_layers}, "
            f"heads={self.num_heads}{gqa}, AdaLN={self.use_adaLN}{sc}, "
            f"~{val:.1f}{unit} params)"
        )


# ── Presetler ─────────────────────────────────────────────────────────────────

OMGCONFIG_REGISTRY: dict[str, dict] = {
    "omgformer-tiny": dict(
        hidden_size=256, num_layers=4, num_heads=4, num_kv_heads=4,
        intermediate_size=512, vocab_size=32_000,
        use_adaLN=True, self_conditioning=True,
    ),
    "omgformer-small": dict(
        hidden_size=512, num_layers=8, num_heads=8, num_kv_heads=4,
        vocab_size=32_000,
        use_adaLN=True, self_conditioning=True,
    ),
    "omgformer-base": dict(
        hidden_size=768, num_layers=12, num_heads=12, num_kv_heads=4,
        vocab_size=32_000,
        use_adaLN=True, self_conditioning=True,
    ),
    "omgformer-large": dict(
        hidden_size=1024, num_layers=24, num_heads=16, num_kv_heads=4,
        vocab_size=32_000,
        use_adaLN=True, self_conditioning=True,
    ),
    "omgformer-xl": dict(
        hidden_size=2048, num_layers=24, num_heads=16, num_kv_heads=2,
        vocab_size=32_000,
        use_adaLN=True, self_conditioning=True,
    ),
    "omgformer-3b": dict(
        hidden_size=2560, num_layers=32, num_heads=32, num_kv_heads=8,
        vocab_size=32_000,
        use_adaLN=True, self_conditioning=True,
    ),
}


# ── MoE alanları (v2.0.3) ─────────────────────────────────────────────────────
# Bu alanlar OMGConfig'e eklenebilmesi için OMGCONFIG_REGISTRY güncellenmeli.
# Şimdilik ayrı bir dataclass olarak tutuyoruz — tam entegrasyon v2.1.0'da.

from dataclasses import dataclass as _dc

@_dc
class MoEConfig:
    """
    Mixture of Experts konfigürasyonu.

    Kullanım::

        from omgformer.configuration import MoEConfig
        moe_cfg = MoEConfig(num_experts=8, num_experts_per_token=2)
    """
    num_experts: int = 8
    num_experts_per_token: int = 2       # Top-K routing
    aux_loss_weight: float = 0.01        # Load balancing loss ağırlığı
