"""
omgformer/lora.py  v2.0.2
--------------------------
omgformer için LoRA (Low-Rank Adaptation) desteği.

Sıradan kullanıcı için:
    from omgformer import OMGConfig, OMGModel
    from omgformer.lora import add_lora, merge_lora

    model = OMGModel(cfg)
    model = add_lora(model, rank=16)   # tek satır — bitti
    # eğit...
    model = merge_lora(model)          # deployment için birleştir

Teknik detay:
    - Attention q/k/v/out projeksiyonları LoRA ile wrap edilir
    - FFN gate/up/down projeksiyonları opsiyonel
    - Merge & unload ile inference'ta sıfır yük
    - safetensors ile sadece LoRA ağırlıklarını kaydet/yükle
"""

from __future__ import annotations

import math
import os
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


__all__ = [
    "LoRAConfig",
    "LoRALinear",
    "add_lora",
    "merge_lora",
    "save_lora",
    "load_lora",
    "lora_parameter_count",
]


# ── LoRA Konfigürasyonu ───────────────────────────────────────────────────────

class LoRAConfig:
    """
    LoRA ayarları.

    Args:
        rank: LoRA rank (r). Küçük = hızlı & az bellek, büyük = daha iyi kalite.
              Önerilen: 8, 16, 32, 64.
        alpha: LoRA scaling faktörü. Genellikle rank ile aynı değer.
        dropout: LoRA dropout oranı. 0.0 = kapalı.
        target_modules: Hangi katmanlar LoRA ile wrap edilsin.
                        None = otomatik (q/k/v/out).
        train_ffn: FFN katmanlarını da eğit. Daha iyi kalite, daha fazla parametre.
    """
    def __init__(
        self,
        rank: int = 16,
        alpha: float = 32.0,
        dropout: float = 0.05,
        target_modules: Optional[list[str]] = None,
        train_ffn: bool = False,
    ):
        self.rank = rank
        self.alpha = alpha
        self.dropout = dropout
        self.scaling = alpha / rank
        self.target_modules = target_modules or ["q_proj", "k_proj", "v_proj", "out"]
        if train_ffn:
            self.target_modules += ["gate", "up", "down"]

    def __repr__(self) -> str:
        return (
            f"LoRAConfig(rank={self.rank}, alpha={self.alpha}, "
            f"dropout={self.dropout}, targets={self.target_modules})"
        )


# ── LoRA Linear Katmanı ───────────────────────────────────────────────────────

class LoRALinear(nn.Module):
    """
    Orijinal Linear katmanı LoRA ile wrap eder.

    Forward:
        output = W·x + scaling · B·A·x

    W → dondurulmuş (frozen)
    A, B → eğitilebilir (küçük matrisler)
    """

    def __init__(
        self,
        original: nn.Linear,
        rank: int,
        alpha: float,
        dropout: float = 0.0,
    ):
        super().__init__()
        self.original = original
        self.rank = rank
        self.scaling = alpha / rank

        in_features  = original.in_features
        out_features = original.out_features

        # LoRA matrisler
        self.lora_A = nn.Linear(in_features,  rank,         bias=False)
        self.lora_B = nn.Linear(rank,          out_features, bias=False)
        self.dropout = nn.Dropout(dropout) if dropout > 0.0 else nn.Identity()

        # Başlatma: A → normal, B → sıfır (başlangıçta katkı = 0)
        nn.init.kaiming_uniform_(self.lora_A.weight, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B.weight)

        # Orijinal ağırlıkları dondur
        for p in self.original.parameters():
            p.requires_grad = False

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Orijinal çıktı + LoRA katkısı
        return self.original(x) + self.lora_B(self.lora_A(self.dropout(x))) * self.scaling

    def merge(self) -> nn.Linear:
        """LoRA ağırlıklarını orijinal ağırlıklara birleştir, LoRALinear'ı kaldır."""
        merged_weight = (
            self.original.weight.data
            + (self.lora_B.weight @ self.lora_A.weight) * self.scaling
        )
        new_linear = nn.Linear(
            self.original.in_features,
            self.original.out_features,
            bias=self.original.bias is not None,
            device=self.original.weight.device,
            dtype=self.original.weight.dtype,
        )
        new_linear.weight.data = merged_weight
        if self.original.bias is not None:
            new_linear.bias.data = self.original.bias.data.clone()
        return new_linear

    def extra_repr(self) -> str:
        return (
            f"in={self.original.in_features}, out={self.original.out_features}, "
            f"rank={self.rank}, scaling={self.scaling:.3f}"
        )


# ── Ana Fonksiyonlar ──────────────────────────────────────────────────────────

def add_lora(model: nn.Module, config: Optional[LoRAConfig] = None, **kwargs) -> nn.Module:
    """
    Modele LoRA ekle. Orijinal ağırlıklar dondurulur, sadece LoRA eğitilir.

    Kullanım::

        model = add_lora(model)                          # varsayılan ayarlar
        model = add_lora(model, rank=32, train_ffn=True) # özel ayarlar
        model = add_lora(model, LoRAConfig(rank=64))     # tam config

    Args:
        model: omgformer modeli (veya herhangi bir nn.Module).
        config: LoRAConfig nesnesi. None ise kwargs ile oluşturulur.
        **kwargs: LoRAConfig'e doğrudan geçirilir (rank, alpha, dropout, train_ffn).

    Returns:
        LoRA eklenmiş model (aynı nesne, in-place).
    """
    if config is None:
        config = LoRAConfig(**kwargs)

    replaced = 0
    for name, module in list(model.named_modules()):
        # Modül adını parçala
        parts = name.split(".")
        if not parts:
            continue

        # Hedef modül mü?
        leaf_name = parts[-1]
        if not isinstance(module, nn.Linear):
            continue
        if not any(t in name for t in config.target_modules):
            continue

        # Parent modülü bul
        parent = model
        for part in parts[:-1]:
            parent = getattr(parent, part)

        # LoRALinear ile değiştir
        lora_layer = LoRALinear(
            module,
            rank=config.rank,
            alpha=config.alpha,
            dropout=config.dropout,
        )
        setattr(parent, leaf_name, lora_layer)
        replaced += 1

    # Tüm orijinal ağırlıkları dondur (LoRA dışı)
    for name, param in model.named_parameters():
        if "lora_A" not in name and "lora_B" not in name:
            param.requires_grad = False

    trainable, total = lora_parameter_count(model)
    print(
        f"[omgformer LoRA] {replaced} katman wrap edildi | "
        f"rank={config.rank} | "
        f"eğitilebilir: {trainable:,} / {total:,} "
        f"(%{100 * trainable / total:.2f})"
    )
    return model


def merge_lora(model: nn.Module) -> nn.Module:
    """
    LoRA ağırlıklarını orijinal ağırlıklara birleştir.
    Deployment için — inference'ta sıfır yük.

    Kullanım::

        model = merge_lora(model)
        model.save_pretrained("./merged_model")
    """
    merged = 0
    for name, module in list(model.named_modules()):
        if not isinstance(module, LoRALinear):
            continue
        parts = name.split(".")
        parent = model
        for part in parts[:-1]:
            parent = getattr(parent, part)
        setattr(parent, parts[-1], module.merge())
        merged += 1

    # Tüm parametreleri tekrar eğitilebilir yap
    for param in model.parameters():
        param.requires_grad = True

    print(f"[omgformer LoRA] {merged} katman birleştirildi ✓")
    return model


def save_lora(model: nn.Module, directory: str):
    """
    Sadece LoRA ağırlıklarını kaydet (çok küçük dosya).

    Kullanım::

        save_lora(model, "./my_lora")
        # → ./my_lora/lora_weights.safetensors  (~MB boyutunda)
    """
    os.makedirs(directory, exist_ok=True)

    lora_state = {
        name: param
        for name, param in model.named_parameters()
        if "lora_A" in name or "lora_B" in name
    }

    if not lora_state:
        print("[omgformer LoRA] Uyarı: LoRA ağırlığı bulunamadı.")
        return

    try:
        from safetensors.torch import save_file
        save_file(lora_state, os.path.join(directory, "lora_weights.safetensors"))
    except ImportError:
        torch.save(lora_state, os.path.join(directory, "lora_weights.pt"))

    size_mb = sum(p.numel() * 2 for p in lora_state.values()) / 1e6
    print(f"[omgformer LoRA] Kaydedildi → {directory}  (~{size_mb:.1f} MB)")


def load_lora(model: nn.Module, directory: str) -> nn.Module:
    """
    Kaydedilmiş LoRA ağırlıklarını modele yükle.

    Not: Önce ``add_lora(model)`` çağırmalısın, sonra bu fonksiyonu.

    Kullanım::

        model = add_lora(model, rank=16)
        model = load_lora(model, "./my_lora")
    """
    st_path = os.path.join(directory, "lora_weights.safetensors")
    pt_path = os.path.join(directory, "lora_weights.pt")

    if os.path.exists(st_path):
        try:
            from safetensors.torch import load_file
            state = load_file(st_path)
        except ImportError:
            state = torch.load(st_path, map_location="cpu", weights_only=True)
    elif os.path.exists(pt_path):
        state = torch.load(pt_path, map_location="cpu", weights_only=True)
    else:
        raise FileNotFoundError(f"LoRA ağırlığı bulunamadı: {directory}")

    missing, unexpected = model.load_state_dict(state, strict=False)
    lora_missing = [k for k in missing if "lora" in k]
    if lora_missing:
        print(f"[omgformer LoRA] Uyarı: {len(lora_missing)} LoRA ağırlığı yüklenemedi.")
    print(f"[omgformer LoRA] Yüklendi ← {directory} ✓")
    return model


def lora_parameter_count(model: nn.Module) -> tuple[int, int]:
    """Eğitilebilir ve toplam parametre sayısını döndür."""
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total     = sum(p.numel() for p in model.parameters())
    return trainable, total
