"""
omgformer/layers.py  v2.0.1
----------------------------
v2.0.0'dan bu sürüme değişiklik yok — katman kodu hatasız.
Minor: tür açıklamaları temizlendi.
"""

from __future__ import annotations

import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from omgformer.configuration import OMGConfig


# ── Normalization ─────────────────────────────────────────────────────────────

class RMSNorm(nn.Module):
    """Root Mean Square Layer Normalization."""

    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x_f = x.float()
        rms = x_f.pow(2).mean(-1, keepdim=True).add(self.eps).rsqrt()
        return (x_f * rms).to(x.dtype) * self.weight


# ── Rotary Embedding ──────────────────────────────────────────────────────────

class RotaryEmbedding(nn.Module):
    """
    RoPE — artımlı cache, sıfırdan yeniden inşa etmez.
    Her yeni uzunluk için sadece eksik pozisyonlar hesaplanır.
    """

    def __init__(
        self,
        head_dim: int,
        max_length: int = 4096,
        base: int = 10_000,
        scaling: float = 1.0,
    ):
        super().__init__()
        self.head_dim = head_dim
        inv_freq = 1.0 / (base ** (torch.arange(0, head_dim, 2).float() / head_dim))
        inv_freq = inv_freq / scaling
        self.register_buffer("inv_freq", inv_freq, persistent=False)
        self._cache_len: int = 0
        self._cos_cache: Optional[torch.Tensor] = None
        self._sin_cache: Optional[torch.Tensor] = None
        self._extend(max_length)

    def _extend(self, new_len: int) -> None:
        """Sadece yeni pozisyonları hesapla ve cache'e ekle."""
        if new_len <= self._cache_len:
            return
        start = self._cache_len
        t = torch.arange(start, new_len, device=self.inv_freq.device, dtype=self.inv_freq.dtype)
        freqs = torch.outer(t, self.inv_freq)       # (yeni_pos, D/2)
        emb = torch.cat([freqs, freqs], dim=-1)     # (yeni_pos, D)
        cos_new = emb.cos()[None, None]             # (1,1,yeni_pos,D)
        sin_new = emb.sin()[None, None]
        if self._cos_cache is None:
            self._cos_cache = cos_new
            self._sin_cache = sin_new
        else:
            self._cos_cache = torch.cat([self._cos_cache, cos_new], dim=2)
            self._sin_cache = torch.cat([self._sin_cache, sin_new], dim=2)
        self._cache_len = new_len

    def forward(
        self, q: torch.Tensor, k: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        T = q.shape[2]
        self._extend(T)
        cos = self._cos_cache[:, :, :T, :]
        sin = self._sin_cache[:, :, :T, :]
        return _apply_rope(q, cos, sin), _apply_rope(k, cos, sin)


def _rotate_half(x: torch.Tensor) -> torch.Tensor:
    h = x.shape[-1] // 2
    return torch.cat([-x[..., h:], x[..., :h]], dim=-1)


def _apply_rope(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    return x * cos + _rotate_half(x) * sin


# ── Grouped Query Attention ───────────────────────────────────────────────────

class GroupedQueryAttention(nn.Module):
    """
    GQA: Q head sayısı tam, KV head sayısı daha az.

    num_kv_heads = num_heads → klasik MHA
    num_kv_heads = 1         → MQA (en az bellek)
    num_kv_heads = arası     → GQA (denge)
    """

    def __init__(self, config: OMGConfig):
        super().__init__()
        self.H   = config.num_heads
        self.Hkv = config.num_kv_heads
        self.D   = config.head_dim
        self.C   = config.hidden_size
        self.ratio = self.H // self.Hkv
        self.drop_p = config.dropout

        self.q_proj = nn.Linear(self.C, self.H   * self.D, bias=False)
        self.k_proj = nn.Linear(self.C, self.Hkv * self.D, bias=False)
        self.v_proj = nn.Linear(self.C, self.Hkv * self.D, bias=False)
        self.out    = nn.Linear(self.C, self.C,             bias=False)
        self.rope   = RotaryEmbedding(
            self.D, config.max_length, config.rope_base, config.rope_scaling
        )

    def forward(
        self,
        x: torch.Tensor,                            # (B, T, C)
        attn_bias: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        B, T, C = x.shape

        q = self.q_proj(x).reshape(B, T, self.H,   self.D).transpose(1, 2)
        k = self.k_proj(x).reshape(B, T, self.Hkv, self.D).transpose(1, 2)
        v = self.v_proj(x).reshape(B, T, self.Hkv, self.D).transpose(1, 2)

        q, k = self.rope(q, k)

        if self.ratio > 1:
            k = k.repeat_interleave(self.ratio, dim=1)
            v = v.repeat_interleave(self.ratio, dim=1)

        out = F.scaled_dot_product_attention(
            q, k, v,
            attn_mask=attn_bias,
            dropout_p=self.drop_p if self.training else 0.0,
            is_causal=False,
        )

        out = out.transpose(1, 2).reshape(B, T, C)
        return self.out(out)


# ── Feed-forward ──────────────────────────────────────────────────────────────

class SwiGLUFFN(nn.Module):
    """SwiGLU: down(silu(gate) * up). Bias yok."""

    def __init__(self, config: OMGConfig):
        super().__init__()
        C, I = config.hidden_size, config.intermediate_size
        self.gate = nn.Linear(C, I, bias=False)
        self.up   = nn.Linear(C, I, bias=False)
        self.down = nn.Linear(I, C, bias=False)
        self.drop = nn.Dropout(config.dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.down(self.drop(F.silu(self.gate(x)) * self.up(x)))


# ── AdaLN-Zero Modülasyonu ────────────────────────────────────────────────────

class AdaLNModulation(nn.Module):
    """
    DiT (Diffusion Transformer) mimarisinden: AdaLN-Zero.

    Timestep embedding'i 6 parçaya dönüştürür:
      (scale_attn, shift_attn, gate_attn, scale_ffn, shift_ffn, gate_ffn)

    Gate'ler sıfır başlatılır → eğitim başında residual = kimlik.
    """

    def __init__(self, hidden_size: int):
        super().__init__()
        self.act  = nn.SiLU()
        self.proj = nn.Linear(hidden_size, 6 * hidden_size, bias=True)
        nn.init.zeros_(self.proj.weight)
        nn.init.zeros_(self.proj.bias)

    def forward(self, t_emb: torch.Tensor) -> tuple[torch.Tensor, ...]:
        """t_emb: (B, C) → 6 ayrı (B, 1, C) tensör"""
        mods = self.proj(self.act(t_emb)).unsqueeze(1)   # (B, 1, 6C)
        return mods.chunk(6, dim=-1)                     # her biri (B, 1, C)


# ── Self-conditioning Projeksiyonu ───────────────────────────────────────────

class SelfCondProjection(nn.Module):
    """
    Önceki adımın soft logit tahminlerini hidden uzayına yansıtır.
    Model bu ek bağlamı kullanarak daha doğru tahmin yapar.
    """

    def __init__(self, config: OMGConfig):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(config.hidden_size, config.hidden_size, bias=False),
            nn.SiLU(),
            nn.Linear(config.hidden_size, config.hidden_size, bias=False),
        )
        # Sıfır başlatma: başlangıçta self-cond katkısı = 0
        nn.init.zeros_(self.proj[-1].weight)

    def forward(self, soft_emb: torch.Tensor) -> torch.Tensor:
        """soft_emb: (B, T, C) — önceki tahminlerin embedding ortalaması"""
        return self.proj(soft_emb)


# ── Transformer Block ─────────────────────────────────────────────────────────

class OMGBlock(nn.Module):
    """
    Tek transformer bloğu.

    use_adaLN=True  → AdaLN-Zero koşullandırması (önerilen)
    use_adaLN=False → klasik pre-norm (v1 uyumlu)
    """

    def __init__(self, config: OMGConfig):
        super().__init__()
        self.use_adaLN = config.use_adaLN

        self.attn_norm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.attn      = GroupedQueryAttention(config)
        self.ffn_norm  = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.ffn       = SwiGLUFFN(config)

        if config.use_adaLN:
            self.adaLN = AdaLNModulation(config.hidden_size)

    def forward(
        self,
        x: torch.Tensor,                            # (B, T, C)
        t_emb: Optional[torch.Tensor] = None,       # (B, C)
        attn_bias: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:

        if self.use_adaLN and t_emb is not None:
            sa, sha, ga, sf, shf, gf = self.adaLN(t_emb)
            x_a = self.attn_norm(x) * (1 + sa) + sha
            x = x + ga.tanh() * self.attn(x_a, attn_bias)
            x_f = self.ffn_norm(x) * (1 + sf) + shf
            x = x + gf.tanh() * self.ffn(x_f)
        else:
            x = x + self.attn(self.attn_norm(x), attn_bias)
            x = x + self.ffn(self.ffn_norm(x))

        return x
