"""
omgformer/utils.py  v2.0.1
---------------------------
Genel yardımcı fonksiyonlar.
"""

from __future__ import annotations

import random
import time
from typing import Union

import torch
import torch.nn as nn


__all__ = [
    "set_seed",
    "count_parameters",
    "get_model_size_mb",
    "get_device",
    "tokens_per_second",
    "format_number",
]


def set_seed(seed: int, deterministic: bool = False) -> None:
    """
    Tüm raslantısallık kaynaklarını aynı anda sabitle.

    Args:
        seed: Kullanılacak seed değeri.
        deterministic: True ise CUDA deterministik moda alınır
            (yavaşlayabilir, test/araştırma için uygundur).
    """
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def count_parameters(model: nn.Module, trainable_only: bool = True) -> int:
    """
    Modelin parametre sayısını döndürür.

    Args:
        model: Sayılacak PyTorch modülü.
        trainable_only: True ise sadece eğitilebilir parametreler sayılır.

    Returns:
        Parametre sayısı (int).
    """
    return sum(
        p.numel()
        for p in model.parameters()
        if not trainable_only or p.requires_grad
    )


def get_model_size_mb(model: nn.Module) -> float:
    """
    Modelin yaklaşık bellek boyutunu MB cinsinden hesapla.

    Yalnızca parametre ve buffer boyutlarını dikkate alır;
    aktivasyon belleğini içermez.

    Returns:
        Boyut (MB, float).
    """
    total_bytes = sum(
        p.nelement() * p.element_size()
        for p in (*model.parameters(), *model.buffers())
    )
    return total_bytes / (1024 ** 2)


def get_device(prefer: str = "auto") -> torch.device:
    """
    Kullanılabilir en iyi cihazı seç.

    Args:
        prefer: ``"auto"`` → CUDA > MPS > CPU sırasıyla dener.
                ``"cuda"``, ``"mps"``, ``"cpu"`` → doğrudan o cihaz.

    Returns:
        ``torch.device`` nesnesi.
    """
    if prefer != "auto":
        return torch.device(prefer)
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


class tokens_per_second:  # noqa: N801  (context manager — küçük harf convention)
    """
    Token/saniye ölçer (bağlam yöneticisi).

    Kullanım::

        with tokens_per_second(batch_size=4, seq_len=256) as meter:
            out = decoder.generate(prompt, new_tokens=256, steps=10)
        print(f"Hız: {meter.value:.0f} tok/s")
    """

    def __init__(self, batch_size: int, seq_len: int):
        self.batch_size = batch_size
        self.seq_len = seq_len
        self.value: float = 0.0
        self._start: float = 0.0

    def __enter__(self) -> "tokens_per_second":
        self._start = time.perf_counter()
        return self

    def __exit__(self, *_) -> None:
        elapsed = time.perf_counter() - self._start
        self.value = (self.batch_size * self.seq_len) / max(elapsed, 1e-9)


def format_number(n: Union[int, float]) -> str:
    """
    Büyük sayıları okunabilir formata çevir.

    Örnekler::

        format_number(1_500_000) → "1.50M"
        format_number(3_200_000_000) → "3.20B"
        format_number(42_000) → "42.0K"
    """
    if abs(n) >= 1e9:
        return f"{n / 1e9:.2f}B"
    if abs(n) >= 1e6:
        return f"{n / 1e6:.2f}M"
    if abs(n) >= 1e3:
        return f"{n / 1e3:.1f}K"
    return str(int(n))
