"""
omgformer/moe.py  v2.0.3
-------------------------
Mixture of Experts (MoE) — aynı compute ile çok daha büyük model kapasitesi.

Her token sadece K uzman FFN'den geçer (sparse routing).
Toplam parametre artar ama compute sabit kalır.

GPT-4'ün de MoE kullandığı tahmin ediliyor.
Mistral Mixtral 8x7B bunu açıkça kullanıyor.

Kullanım:
    cfg = OMGConfig(use_moe=True, num_experts=8, num_experts_per_token=2)
    model = OMGModel(cfg)
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from omgformer.configuration import OMGConfig


__all__ = ["MoEFFN", "RouterLoadBalancingLoss"]


class MoEFFN(nn.Module):
    """
    Sparse Mixture of Experts FFN.

    Her token için:
      1. Router: hangi K uzman kullanılacak seçilir
      2. Sadece o K uzman hesaplanır
      3. Ağırlıklı toplam döndürülür

    Bu sayede toplam parametre = num_experts × FFN_boyutu
    Ama compute = K × FFN_boyutu (çok daha az)
    """

    def __init__(self, config: OMGConfig):
        super().__init__()
        self.num_experts = config.num_experts
        self.K = config.num_experts_per_token
        C, I = config.hidden_size, config.intermediate_size

        # Router: hangi uzman seçilecek
        self.router = nn.Linear(C, self.num_experts, bias=False)

        # Uzmanlar — her biri tam bir SwiGLU FFN
        self.experts = nn.ModuleList([
            _ExpertFFN(C, I) for _ in range(self.num_experts)
        ])

        # Load balancing loss için auxiliary loss ağırlığı
        self.aux_loss_weight = 0.01

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Returns:
            output: (B, T, C)
            aux_loss: load balancing loss (eğitimde toplam loss'a ekle)
        """
        B, T, C = x.shape
        x_flat = x.reshape(B * T, C)

        # Router logitleri ve top-K seçimi
        logits = self.router(x_flat)                        # (BT, E)
        router_probs = F.softmax(logits, dim=-1)            # (BT, E)
        topk_probs, topk_idx = router_probs.topk(self.K, dim=-1)  # (BT, K)

        # Normalize top-K probabilities
        topk_probs = topk_probs / topk_probs.sum(dim=-1, keepdim=True)

        # Her uzman için hangi tokenlar gelecek
        output = torch.zeros_like(x_flat)

        for i, expert in enumerate(self.experts):
            # Bu uzmanı seçen tokenlar
            mask = (topk_idx == i).any(dim=-1)              # (BT,)
            if not mask.any():
                continue

            # Token'ları uzmandan geçir
            expert_input = x_flat[mask]
            expert_output = expert(expert_input)

            # Uzman ağırlığını bul
            expert_weight = topk_probs[mask][topk_idx[mask] == i].unsqueeze(-1)
            output[mask] += expert_weight * expert_output

        output = output.reshape(B, T, C)

        # Load balancing loss: uzmanların eşit yüklenmesini teşvik et
        aux_loss = RouterLoadBalancingLoss.compute(router_probs, topk_idx, self.num_experts)

        return output, aux_loss


class _ExpertFFN(nn.Module):
    """Tek uzman — SwiGLU FFN."""
    def __init__(self, C: int, I: int):
        super().__init__()
        self.gate = nn.Linear(C, I, bias=False)
        self.up   = nn.Linear(C, I, bias=False)
        self.down = nn.Linear(I, C, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.down(F.silu(self.gate(x)) * self.up(x))


class RouterLoadBalancingLoss:
    """
    Auxiliary load balancing loss.

    Uzmanların eşit kullanılmasını teşvik eder.
    Bazı uzmanlar aşırı yüklenirken diğerleri boş kalmasın.

    Referans: Switch Transformer (Fedus et al., 2022)
    """

    @staticmethod
    def compute(
        router_probs: torch.Tensor,   # (BT, E)
        topk_idx: torch.Tensor,       # (BT, K)
        num_experts: int,
    ) -> torch.Tensor:
        BT = router_probs.shape[0]

        # Her uzmanın seçilme frekansı
        expert_mask = F.one_hot(topk_idx, num_experts).float()  # (BT, K, E)
        expert_usage = expert_mask.sum(dim=1).mean(dim=0)       # (E,)

        # Router'ın her uzmana verdiği ortalama olasılık
        router_mean = router_probs.mean(dim=0)                  # (E,)

        # İkisinin noktasal çarpımı minimize edilmeli
        aux_loss = num_experts * (router_mean * expert_usage).sum()
        return aux_loss
