"""
omgformer/data.py  v2.0.3
--------------------------
Veri yükleme ve ön işleme araçları.

Sıradan kullanıcı için tek satırda veri hazırlama:
    from omgformer.data import TextDataset, DataCollator, load_text_file

    dataset = load_text_file("metin.txt", tokenizer, seq_len=512)
    collator = DataCollator(pad_token_id=0)
"""

from __future__ import annotations

import os
import random
from typing import Optional, Iterator

import torch
from torch.utils.data import Dataset, DataLoader


__all__ = [
    "TextDataset",
    "PackedDataset",
    "DataCollator",
    "load_text_file",
    "infinite_loader",
]


class TextDataset(Dataset):
    """
    Basit metin dataset'i.

    Uzun metni seq_len boyutunda parçalara böler.
    Stride ile örtüşen pencereler oluşturabilir (daha fazla veri).

    Kullanım::

        dataset = TextDataset(token_ids, seq_len=512)
        dataset = TextDataset(token_ids, seq_len=512, stride=256)  # örtüşen
    """

    def __init__(
        self,
        token_ids: torch.Tensor,       # (N,) — tüm token ID'leri
        seq_len: int = 512,
        stride: Optional[int] = None,  # None = seq_len (örtüşme yok)
    ):
        self.ids = token_ids
        self.seq_len = seq_len
        self.stride = stride or seq_len

        # Geçerli başlangıç pozisyonları
        self.starts = list(range(0, len(token_ids) - seq_len, self.stride))

    def __len__(self) -> int:
        return len(self.starts)

    def __getitem__(self, idx: int) -> torch.Tensor:
        start = self.starts[idx]
        return self.ids[start: start + self.seq_len]


class PackedDataset(Dataset):
    """
    Sequence packing — padding sıfır, throughput maksimum.

    Birden fazla kısa sequence'ı eos_token ile ayırarak
    tek uzun sequence'a paketler. Padding israfı olmaz.

    Mercury ve LLaMA eğitiminde kullanılan teknik.

    Kullanım::

        dataset = PackedDataset(sequences, seq_len=2048, eos_token_id=2)
    """

    def __init__(
        self,
        sequences: list[torch.Tensor],
        seq_len: int = 2048,
        eos_token_id: int = 2,
    ):
        self.seq_len = seq_len
        self.packed = self._pack(sequences, eos_token_id)

    def _pack(self, sequences: list[torch.Tensor], eos: int) -> torch.Tensor:
        """Tüm sequence'ları eos ile ayırarak tek tensor'a birleştir."""
        chunks = []
        for seq in sequences:
            chunks.append(seq)
            chunks.append(torch.tensor([eos]))
        flat = torch.cat(chunks)
        # seq_len'in katına tamamla
        trim = (len(flat) // self.seq_len) * self.seq_len
        return flat[:trim].reshape(-1, self.seq_len)

    def __len__(self) -> int:
        return len(self.packed)

    def __getitem__(self, idx: int) -> torch.Tensor:
        return self.packed[idx]


class DataCollator:
    """
    DataLoader için collate fonksiyonu.

    Farklı uzunluktaki sequence'ları pad_token_id ile pad'ler.
    attention_mask otomatik oluşturur.

    Kullanım::

        collator = DataCollator(pad_token_id=0)
        loader = DataLoader(dataset, batch_size=32, collate_fn=collator)
    """

    def __init__(self, pad_token_id: int = 0, max_length: Optional[int] = None):
        self.pad_token_id = pad_token_id
        self.max_length = max_length

    def __call__(self, batch: list[torch.Tensor]) -> dict[str, torch.Tensor]:
        max_len = max(len(x) for x in batch)
        if self.max_length:
            max_len = min(max_len, self.max_length)

        input_ids      = torch.full((len(batch), max_len), self.pad_token_id, dtype=torch.long)
        attention_mask = torch.zeros(len(batch), max_len, dtype=torch.long)

        for i, seq in enumerate(batch):
            length = min(len(seq), max_len)
            input_ids[i, :length]      = seq[:length]
            attention_mask[i, :length] = 1

        return {"input_ids": input_ids, "attention_mask": attention_mask}


def load_text_file(
    path: str,
    tokenizer,
    seq_len: int = 512,
    stride: Optional[int] = None,
    encoding: str = "utf-8",
) -> TextDataset:
    """
    Metin dosyasını yükle, tokenize et, dataset oluştur.

    Kullanım::

        from omgformer.tokenization import OMGTokenizer
        tok = OMGTokenizer.from_pretrained("bert-base-uncased")
        dataset = load_text_file("metin.txt", tok, seq_len=512)

    Args:
        path: Metin dosyası yolu.
        tokenizer: OMGTokenizer veya HuggingFace tokenizer.
        seq_len: Sequence uzunluğu.
        stride: Örtüşen pencere adımı. None = örtüşme yok.
        encoding: Dosya encoding'i.

    Returns:
        TextDataset
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Dosya bulunamadı: {path}")

    with open(path, encoding=encoding) as f:
        text = f.read()

    print(f"[omgformer data] Yüklendi: {len(text):,} karakter")

    # Tokenize
    if hasattr(tokenizer, "encode"):
        ids = tokenizer.encode(text)
        if not isinstance(ids, torch.Tensor):
            ids = torch.tensor(ids, dtype=torch.long)
    else:
        raise ValueError("tokenizer.encode() metodu bulunamadı")

    print(f"[omgformer data] Tokenize: {len(ids):,} token → {len(ids) // seq_len:,} sequence")

    return TextDataset(ids, seq_len=seq_len, stride=stride)


def infinite_loader(dataset: Dataset, batch_size: int, **kwargs) -> Iterator:
    """
    Sonsuz DataLoader — eğitim döngüsü için.
    Dataset bitince yeniden başlar.

    Kullanım::

        loader = infinite_loader(dataset, batch_size=32)
        for batch in loader:
            ...
    """
    while True:
        loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, **kwargs)
        yield from loader
