"""
omgformer/tokenization.py  v2.0.1
-----------------------------------
Değişiklikler (2.0.1):
  - BUG FIX: ``__getattr__`` sonsuz özyineleme hatası giderildi.
    ``_tok`` niteliğine erişim başarısız olursa (ör. ``__init__``
    sırasında veya unpickling sırasında) ``__getattr__`` kendini
    çağırıyordu. ``object.__getattribute__`` ile korundu.
"""

from __future__ import annotations

import torch
from transformers import AutoTokenizer


class OMGTokenizer:
    """
    ``transformers.AutoTokenizer`` etrafında ince bir sarmalayıcı.

    ``OMGModel`` bileşenleriyle entegrasyon için torch tensor
    dönüşümlerini ve ``__getattr__`` proxy'sini sağlar.
    """

    def __init__(self, hf_tokenizer) -> None:
        # object.__setattr__ kullanarak _tok'u direct set et
        # Bu, __setattr__ override varsa güvenli olmayı sağlar
        object.__setattr__(self, "_tok", hf_tokenizer)

    @classmethod
    def from_pretrained(cls, name: str, **kwargs) -> "OMGTokenizer":
        return cls(AutoTokenizer.from_pretrained(name, **kwargs))

    def encode(self, text: str, **kwargs) -> torch.Tensor:
        ids = self._tok.encode(text, **kwargs)
        return torch.tensor(ids, dtype=torch.long)

    def decode(self, ids, **kwargs) -> str:
        if hasattr(ids, "tolist"):
            ids = ids.tolist()
        return self._tok.decode(ids, skip_special_tokens=True, **kwargs)

    def __getattr__(self, name: str):
        # FIX: object.__getattribute__ ile _tok'u al.
        # Bu, _tok henüz set edilmemişse AttributeError fırlatır
        # ve sonsuz özyinelemeyi önler.
        try:
            tok = object.__getattribute__(self, "_tok")
        except AttributeError as exc:
            raise AttributeError(
                f"'{type(self).__name__}' object has no attribute '{name}' "
                "(underlying tokenizer not yet initialised)"
            ) from exc
        return getattr(tok, name)

    def __repr__(self) -> str:
        try:
            inner = repr(self._tok)
        except AttributeError:
            inner = "<uninitialised>"
        return f"OMGTokenizer({inner})"
