"""
omgformer/diffusion.py  v2.0.1
--------------------------------
Değişiklikler (2.0.1):
  - BUG FIX: ``generate_stream`` artık ``generate`` ile aynı parametre
    setini destekliyor: ``temperature``, ``top_k``, ``top_p``,
    ``remask_prob``. Önceki sürümde bu parametreler ``**kwargs`` ile
    alınıp sessizce görmezden geliniyordu.
  - BUG FIX: ``generate_stream`` son adımda kalan MASK tokenlarını
    zorla açıyor (``generate`` ile tutarlı).
  - ``generate_stream`` dokümantasyonu güncellendi.
"""

from __future__ import annotations

import math
from typing import Iterator, Literal, Optional

import torch
import torch.nn.functional as F


ScheduleType = Literal["cosine", "linear", "sqrt", "sigmoid"]


# ── Mask Scheduler ────────────────────────────────────────────────────────────

class MaskScheduler:
    """
    Diffusion mask oranı α(t) kontrolcüsü.

    α(0) = 0  → temiz metin
    α(T) = 1  → tamamen maskeli

    Absorbing diffusion:
      %80 → MASK token
      %10 → rastgele başka bir token
      %10 → orijinal kalır
    """

    def __init__(
        self,
        steps: int = 64,
        schedule: ScheduleType = "cosine",
        mask_token_id: int = 1,
        pad_token_id: int = 0,
        vocab_size: int = 32_000,
        random_token_prob: float = 0.1,
    ):
        self.steps = steps
        self.schedule = schedule
        self.mask_token_id = mask_token_id
        self.pad_token_id = pad_token_id
        self.vocab_size = vocab_size
        self.random_token_prob = random_token_prob
        self._alphas = self._build(steps, schedule)

    def _build(self, T: int, schedule: ScheduleType) -> torch.Tensor:
        t = torch.linspace(0.0, 1.0, T + 1)
        if schedule == "cosine":
            a = 1.0 - torch.cos(t * math.pi / 2).pow(2)
        elif schedule == "linear":
            a = t
        elif schedule == "sqrt":
            a = t.sqrt()
        elif schedule == "sigmoid":
            k = 10.0
            a = torch.sigmoid(k * (t - 0.5))
            a = (a - a[0]) / (a[-1] - a[0])
        else:
            raise ValueError(
                f"schedule must be one of cosine|linear|sqrt|sigmoid, got '{schedule}'."
            )
        return a.clamp(0.0, 0.9999)

    def alpha(self, t: torch.Tensor) -> torch.Tensor:
        return self._alphas[t.long().cpu()].to(t.device)

    # ── İleri süreç (eğitim için bozma) ──────────────────────────────

    def corrupt(
        self,
        input_ids: torch.Tensor,            # (B, T)
        t: Optional[torch.Tensor] = None,   # (B,) — None ise rastgele
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Absorbing diffusion: tokenlara gürültü ekle.

        Returns:
            Tuple of (noisy_ids, bool_mask, t).
            ``bool_mask=True`` olan pozisyonlarda loss hesaplanır.
        """
        B, T = input_ids.shape
        device = input_ids.device

        if t is None:
            t = torch.randint(1, self.steps + 1, (B,), device=device)

        rate = self.alpha(t)[:, None].expand(B, T)
        rate = rate.masked_fill(input_ids == self.pad_token_id, 0.0)

        affected = torch.bernoulli(rate).bool()

        noisy = input_ids.clone()

        # %80 → MASK
        mask_frac = 1.0 - self.random_token_prob - 0.1
        is_masked = affected & (torch.rand_like(rate) < mask_frac)
        noisy[is_masked] = self.mask_token_id

        # %10 → random token (özel tokenları atla: id ≥ 4)
        rand_threshold = self.random_token_prob / (self.random_token_prob + 0.1)
        is_random = affected & ~is_masked & (torch.rand_like(rate) < rand_threshold)
        random_ids = torch.randint(4, self.vocab_size, (B, T), device=device)
        noisy[is_random] = random_ids[is_random]

        # %10 → orijinal (affected & ~is_masked & ~is_random)

        return noisy, affected, t

    # ── Training loss — self-conditioning desteğiyle ─────────────────

    def loss(
        self,
        model,
        noisy_ids: torch.Tensor,
        original_ids: torch.Tensor,
        mask: torch.Tensor,
        t: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        self_cond_prob: float = 0.5,
    ) -> torch.Tensor:
        """
        Self-conditioning eğitimi:
          1. %50 ihtimalle: grad_yok geçişiyle soft embedding al.
          2. Bu embedding'i self_cond olarak ana geçişe ekle.
          3. Masked pozisyonlar üzerinden cross-entropy hesapla.
        """
        self_cond: Optional[torch.Tensor] = None

        if model.config.self_conditioning and torch.rand(1).item() < self_cond_prob:
            with torch.no_grad():
                first_out = model(
                    noisy_ids,
                    attention_mask=attention_mask,
                    timesteps=t,
                    self_cond=None,
                )
                self_cond = model.get_soft_embedding(first_out.logits).detach()

        out = model(
            noisy_ids,
            attention_mask=attention_mask,
            timesteps=t,
            self_cond=self_cond,
        )
        logits = out.logits

        if mask.sum() == 0:
            return logits.sum() * 0.0

        return F.cross_entropy(
            logits[mask].float(),
            original_ids[mask],
            reduction="mean",
        )


# ── Paralel Decoder ───────────────────────────────────────────────────────────

class ParallelDecoder:
    """
    Paralel iteratif unmask.

    Her adımda:
      1. Tüm sequence model'den geçer (full attention).
      2. En yüksek güvenli tokenlar açılır.
      3. (Opsiyonel) Önceki adımın tahminleri bir sonraki adıma beslenir.
      4. (Opsiyonel) Düşük güvenli tokenlar yeniden maskelenir.

    steps=10 → GPT'ye kıyasla ~25× daha hızlı üretim.
    Self-conditioning ile steps=6–8 çoğunlukla yeterlidir.
    """

    def __init__(self, model, scheduler: MaskScheduler):
        self.model = model
        self.sched = scheduler
        self.device = next(model.parameters()).device

    @torch.no_grad()
    def generate(
        self,
        prompt_ids: torch.Tensor,       # (B, P) veya (P,)
        new_tokens: int = 128,
        steps: int = 10,
        temperature: float = 1.0,
        top_k: int = 0,
        top_p: float = 1.0,
        remask_prob: float = 0.0,
        show_steps: bool = False,
    ) -> torch.Tensor:                  # (B, P + new_tokens)
        """Tam vektörize paralel üretim — Python for loop yok."""
        self.model.eval()
        if prompt_ids.dim() == 1:
            prompt_ids = prompt_ids.unsqueeze(0)

        B, P = prompt_ids.shape
        N = new_tokens
        mask_id = self.sched.mask_token_id
        device = self.device

        seq = torch.cat([
            prompt_ids.to(device),
            torch.full((B, N), mask_id, dtype=torch.long, device=device),
        ], dim=1)

        attn   = torch.ones(B, P + N, dtype=torch.long, device=device)
        counts = _cosine_counts(N, steps)
        self_cond: Optional[torch.Tensor] = None

        for step in range(steps):
            t = torch.full((B,), steps - step, dtype=torch.long, device=device)

            out    = self.model(seq, attention_mask=attn, timesteps=t, self_cond=self_cond)
            logits = out.logits[:, P:, :]               # (B, N, V)

            if self.model.config.self_conditioning:
                self_cond = self.model.get_soft_embedding(out.logits).detach()

            # ── Sampling ──────────────────────────────────────────────
            if temperature != 1.0:
                logits = logits / max(temperature, 1e-8)
            logits[..., self.sched.mask_token_id] = float("-inf")
            if top_k > 0:
                logits = _top_k_filter(logits, top_k)
            if top_p < 1.0:
                logits = _top_p_filter(logits, top_p)

            probs = F.softmax(logits, dim=-1)
            pred  = torch.multinomial(probs.reshape(B * N, -1), 1).reshape(B, N)
            conf  = probs.gather(-1, pred.unsqueeze(-1)).squeeze(-1)

            # ── Vektörize unmask ──────────────────────────────────────
            still_masked = seq[:, P:] == mask_id
            conf_masked  = conf.masked_fill(~still_masked, -1.0)
            n_unmask     = min(counts[step], int(still_masked.sum(-1).max().item()))

            if n_unmask > 0:
                _, top_idx   = conf_masked.topk(n_unmask, dim=-1)
                unmask_mask  = torch.zeros(B, N, dtype=torch.bool, device=device)
                unmask_mask.scatter_(1, top_idx, True)
                unmask_mask  = unmask_mask & still_masked
                seq[:, P:]   = torch.where(unmask_mask, pred, seq[:, P:])

            # ── Son adımda kalan MASK tokenlarını zorla aç ────────────
            if step == steps - 1:
                remaining = seq[:, P:] == mask_id
                if remaining.any():
                    seq[:, P:] = torch.where(remaining, pred, seq[:, P:])

            # ── Remasking ─────────────────────────────────────────────
            if remask_prob > 0.0 and step < steps - 1:
                unmasked    = seq[:, P:] != mask_id
                low_conf    = conf < conf.median()
                should_remask = (
                    unmasked & low_conf
                    & (torch.rand(B, N, device=device) < remask_prob)
                )
                seq[:, P:] = torch.where(
                    should_remask,
                    torch.full_like(seq[:, P:], mask_id),
                    seq[:, P:],
                )

            if show_steps:
                pct = (seq[:, P:] != mask_id).float().mean().item()
                print(f"  step {step + 1}/{steps}  unmasked={pct:.1%}")

        return seq

    def generate_stream(
        self,
        prompt_ids: torch.Tensor,
        new_tokens: int = 128,
        steps: int = 10,
        temperature: float = 1.0,       # FIX: bu parametreler artık gerçekten kullanılıyor
        top_k: int = 0,
        top_p: float = 1.0,
        remask_prob: float = 0.0,
    ) -> Iterator[torch.Tensor]:
        """
        Her adımda ara sequence'ı yield eder.

        Aşamalı unmask'i görselleştirmek için kullanışlı.
        Artık ``temperature``, ``top_k``, ``top_p`` ve ``remask_prob``
        parametrelerini de destekliyor — ``generate`` ile tam uyumlu.
        """
        self.model.eval()
        if prompt_ids.dim() == 1:
            prompt_ids = prompt_ids.unsqueeze(0)

        B, P = prompt_ids.shape
        N    = new_tokens
        mask_id = self.sched.mask_token_id
        device  = self.device

        seq = torch.cat([
            prompt_ids.to(device),
            torch.full((B, N), mask_id, dtype=torch.long, device=device),
        ], dim=1)
        attn   = torch.ones(B, P + N, dtype=torch.long, device=device)
        counts = _cosine_counts(N, steps)
        self_cond: Optional[torch.Tensor] = None

        with torch.no_grad():
            for step in range(steps):
                t = torch.full((B,), steps - step, dtype=torch.long, device=device)
                out    = self.model(seq, attention_mask=attn, timesteps=t, self_cond=self_cond)
                logits = out.logits[:, P:, :]

                if self.model.config.self_conditioning:
                    self_cond = self.model.get_soft_embedding(out.logits).detach()

                # ── Sampling ──────────────────────────────────────────
                if temperature != 1.0:
                    logits = logits / max(temperature, 1e-8)
                logits[..., self.sched.mask_token_id] = float("-inf")
                if top_k > 0:
                    logits = _top_k_filter(logits, top_k)
                if top_p < 1.0:
                    logits = _top_p_filter(logits, top_p)

                probs = F.softmax(logits, dim=-1)
                pred  = torch.multinomial(probs.reshape(B * N, -1), 1).reshape(B, N)
                conf  = probs.gather(-1, pred.unsqueeze(-1)).squeeze(-1)

                # ── Unmask ────────────────────────────────────────────
                still_masked = seq[:, P:] == mask_id
                conf_masked  = conf.masked_fill(~still_masked, -1.0)
                n_unmask = min(counts[step], int(still_masked.sum(-1).max().item()))

                if n_unmask > 0:
                    _, top_idx  = conf_masked.topk(n_unmask, dim=-1)
                    unmask_mask = torch.zeros(B, N, dtype=torch.bool, device=device)
                    unmask_mask.scatter_(1, top_idx, True)
                    unmask_mask = unmask_mask & still_masked
                    seq[:, P:] = torch.where(unmask_mask, pred, seq[:, P:])

                # ── Son adımda kalan MASK tokenlarını zorla aç ────────  FIX
                if step == steps - 1:
                    remaining = seq[:, P:] == mask_id
                    if remaining.any():
                        seq[:, P:] = torch.where(remaining, pred, seq[:, P:])

                # ── Remasking ─────────────────────────────────────────
                if remask_prob > 0.0 and step < steps - 1:
                    unmasked = seq[:, P:] != mask_id
                    low_conf = conf < conf.median()
                    should_remask = (
                        unmasked & low_conf
                        & (torch.rand(B, N, device=device) < remask_prob)
                    )
                    seq[:, P:] = torch.where(
                        should_remask,
                        torch.full_like(seq[:, P:], mask_id),
                        seq[:, P:],
                    )

                yield seq.clone()


# ── Yardımcılar ───────────────────────────────────────────────────────────────

def _cosine_counts(total: int, steps: int) -> list[int]:
    """Cosine eğrisiyle unmask sayılarını dağıt."""
    counts, left = [], total
    for s in range(steps):
        frac = (
            math.cos(math.pi * s / steps)
            - math.cos(math.pi * (s + 1) / steps)
        ) / 2
        n = max(1, round(frac * total))
        n = min(n, left)
        counts.append(n)
        left -= n
    if left > 0:
        counts[-1] += left
    return counts


def _top_k_filter(logits: torch.Tensor, k: int) -> torch.Tensor:
    vals, _ = torch.topk(logits, k, dim=-1)
    return logits.masked_fill(logits < vals[..., -1:], float("-inf"))


def _top_p_filter(logits: torch.Tensor, p: float) -> torch.Tensor:
    """
    Top-p (nucleus) sampling.
    Filtrelenmiş değerler orijinal sıraya doğru scatter ile geri yazılır.
    """
    sorted_logits, sorted_idx = torch.sort(logits, descending=True, dim=-1)
    cum_probs = sorted_logits.softmax(-1).cumsum(-1)
    # İlk eleman her zaman dahil
    remove = (cum_probs - sorted_logits.softmax(-1)) > p
    sorted_logits = sorted_logits.masked_fill(remove, float("-inf"))
    result = torch.empty_like(logits)
    result.scatter_(-1, sorted_idx, sorted_logits)
    return result
