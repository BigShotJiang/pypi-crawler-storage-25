"""
LangChain tools for NEAR Protocol.
Generated for: Build LangChain Tool: NEAR Price & Market Data
"""
import requests
import json
import base64
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


class NEARPriceInput(BaseModel):
    tokens: Optional[List[str]] = Field(default=["near"], description="Token symbols or IDs to fetch price data for")
    include_history: bool = Field(default=False, description="Include 7-day historical price data")
    vs_currency: str = Field(default="usd", description="Quote currency (usd, eur, btc)")

class NEARPriceMarketTool(BaseTool):
    name: str = "near_price_market_data"
    description: str = (
        "Fetch real-time NEAR and NEAR ecosystem token prices, market cap, volume, "
        "24h change, and optional 7-day historical data. Aggregates from CoinGecko and "
        "Ref Finance on-chain pools. Use for market analysis, price alerts, and trading signals."
    )
    args_schema: Type[BaseModel] = NEARPriceInput
    _cache: Dict[str, Any] = {}
    _cache_ts: Dict[str, float] = {}

    def _fetch_coingecko(self, tokens: List[str], vs_currency: str, include_history: bool) -> Dict[str, Any]:
        import time
        COINGECKO_IDS = {"near": "near", "usdc": "usd-coin", "usdt": "tether", "aurora": "aurora-near", "ref": "ref-finance"}
        ids = [COINGECKO_IDS.get(t.lower(), t.lower()) for t in tokens]
        ids_str = ",".join(ids)
        cache_key = f"{ids_str}_{vs_currency}_{include_history}"
        now = time.time()
        if cache_key in self._cache and now - self._cache_ts.get(cache_key, 0) < 60:
            return self._cache[cache_key]
        base = "https://api.coingecko.com/api/v3"
        url = f"{base}/coins/markets?vs_currency={vs_currency}&ids={ids_str}&order=market_cap_desc&per_page=20&page=1&sparkline={str(include_history).lower()}&price_change_percentage=1h,24h,7d"
        resp = requests.get(url, timeout=10)
        data = {}
        if resp.status_code == 200:
            for coin in resp.json():
                entry = {
                    "symbol": coin.get("symbol", "").upper(),
                    "price": coin.get("current_price"),
                    "market_cap": coin.get("market_cap"),
                    "volume_24h": coin.get("total_volume"),
                    "change_1h": coin.get("price_change_percentage_1h_in_currency"),
                    "change_24h": coin.get("price_change_percentage_24h"),
                    "change_7d": coin.get("price_change_percentage_7d_in_currency"),
                    "ath": coin.get("ath"),
                    "atl": coin.get("atl"),
                    "source": "coingecko",
                }
                if include_history and coin.get("sparkline_in_7d"):
                    entry["history_7d"] = coin["sparkline_in_7d"].get("price", [])
                data[coin.get("id", coin.get("symbol", ""))] = entry
        self._cache[cache_key] = data
        self._cache_ts[cache_key] = now
        return data

    def _fetch_ref_finance_near_price(self) -> Optional[float]:
        try:
            params = {"request_type": "call_function", "finality": "final", "account_id": "v2.ref-finance.near", "method_name": "get_return", "args_base64": __import__("base64").b64encode(b'{"pool_id":79,"token_in":"wrap.near","amount_in":"1000000000000000000000000","token_out":"dac17f958d2ee523a2206206994597c13d831ec7.factory.bridge.near"}').decode()}
            result = _near_rpc("query", params)
            if result and "result" in result:
                raw = bytes(result["result"])
                import json as _json
                usdt_out = int(_json.loads(raw.decode())) / 1e6
                return usdt_out
        except Exception:
            pass
        return None

    def _run(self, tokens: List[str] = None, include_history: bool = False, vs_currency: str = "usd") -> str:
        if tokens is None:
            tokens = ["near"]
        data = self._fetch_coingecko(tokens, vs_currency, include_history)
        ref_near = self._fetch_ref_finance_near_price()
        output = []
        for cg_id, info in data.items():
            line = (f"{info['symbol']}: ${info['price']:,.4f} {vs_currency.upper()} | "
                    f"MCap: ${info['market_cap']:,.0f} | Vol24h: ${info['volume_24h']:,.0f} | "
                    f"1h: {info['change_1h']:+.2f}% | 24h: {info['change_24h']:+.2f}% | 7d: {info['change_7d']:+.2f}%")
            if include_history and "history_7d" in info:
                prices = info["history_7d"]
                line += f" | 7d range: ${min(prices):,.4f}-${max(prices):,.4f}"
            output.append(line)
        if ref_near and "near" in [t.lower() for t in tokens]:
            output.append(f"NEAR on-chain (Ref Finance pool): ~${ref_near:,.4f} USDT")
        return "\n".join(output) if output else "No price data found for requested tokens."

    async def _arun(self, tokens: List[str] = None, include_history: bool = False, vs_currency: str = "usd") -> str:
        return self._run(tokens=tokens, include_history=include_history, vs_currency=vs_currency)


class NEARPriceAlertInput(BaseModel):
    token: str = Field(default="near", description="Token to check (near, aurora, ref, etc.)")
    threshold_above: Optional[float] = Field(default=None, description="Alert if price is above this USD value")
    threshold_below: Optional[float] = Field(default=None, description="Alert if price is below this USD value")

class NEARPriceAlertTool(BaseTool):
    name: str = "near_price_alert_check"
    description: str = (
        "Check if NEAR or ecosystem token price has crossed a threshold. "
        "Returns alert status with current price vs. your target levels. "
        "Use for conditional agent logic: 'buy if NEAR < $3', 'sell if > $7'."
    )
    args_schema: Type[BaseModel] = NEARPriceAlertInput

    def _run(self, token: str = "near", threshold_above: Optional[float] = None, threshold_below: Optional[float] = None) -> str:
        COINGECKO_IDS = {"near": "near", "aurora": "aurora-near", "ref": "ref-finance", "usdc": "usd-coin"}
        cg_id = COINGECKO_IDS.get(token.lower(), token.lower())
        url = f"https://api.coingecko.com/api/v3/simple/price?ids={cg_id}&vs_currencies=usd&include_24hr_change=true"
        resp = requests.get(url, timeout=10)
        if resp.status_code != 200:
            return f"Failed to fetch price for {token}: HTTP {resp.status_code}"
        result = resp.json().get(cg_id, {})
        price = result.get("usd")
        change = result.get("usd_24h_change", 0)
        if price is None:
            return f"No price data available for token: {token}"
        alerts = []
        if threshold_above is not None:
            status = "🔴 TRIGGERED" if price > threshold_above else "✅ not triggered"
            alerts.append(f"Above ${threshold_above}: {status}")
        if threshold_below is not None:
            status = "🔴 TRIGGERED" if price < threshold_below else "✅ not triggered"
            alerts.append(f"Below ${threshold_below}: {status}")
        alert_str = " | ".join(alerts) if alerts else "No thresholds set"
        return f"{token.upper()} price: ${price:,.4f} USD (24h: {change:+.2f}%) — Alerts: {alert_str}"

    async def _arun(self, token: str = "near", threshold_above: Optional[float] = None, threshold_below: Optional[float] = None) -> str:
        return self._run(token=token, threshold_above=threshold_above, threshold_below=threshold_below)