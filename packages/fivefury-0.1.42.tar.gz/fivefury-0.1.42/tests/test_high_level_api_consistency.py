from __future__ import annotations

from fivefury import BoundSphere, BoundType, CutCamera, CutScene, EntityDef, Texture, TextureFormat, Ybn, Ymap, Ytd, Ytyp


def _simple_bound() -> BoundSphere:
    return BoundSphere(
        bound_type=BoundType.SPHERE,
        sphere_radius=1.0,
        box_max=(1.0, 1.0, 1.0),
        margin=0.0,
        box_min=(-1.0, -1.0, -1.0),
        box_center=(0.0, 0.0, 0.0),
        sphere_center=(0.0, 0.0, 0.0),
    )


def test_high_level_consistency_surface() -> None:
    ytd = Ytd()
    ytd.add_texture(
        Texture.from_raw(
            bytes([255, 0, 0, 255] * 16),
            width=4,
            height=4,
            format=TextureFormat.A8R8G8B8,
            mip_count=1,
            name="test",
        )
    )
    assert ytd.build().validate() == []

    ybn = Ybn.from_bound(_simple_bound())
    ybn.set_bound(_simple_bound())
    assert ybn.build().validate() == []

    ytyp = Ytyp(name="test")
    ytyp.create_archetype("prop_box")
    ytyp.add_dependency("props")
    assert ytyp.build().validate() == []

    ymap = Ymap(name="test")
    ymap.add_entity(EntityDef(archetype_name="prop_box"))
    assert ymap.build(auto_flags=True).validate() == []

    cut = CutScene.create(duration=1.0)
    cut.add_binding(CutCamera("cam_main"))
    assert cut.build().validate() == []
