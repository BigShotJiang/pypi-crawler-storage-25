from __future__ import annotations

from pathlib import Path

import pytest

from fivefury import CutScene, MetaHash, read_ycd


TESTS_DIR = Path(__file__).resolve().parent
CUT_PATH = TESTS_DIR / "maude_mcs_1.cut"
YCD_PATHS = [TESTS_DIR / f"maude_mcs_1-{i}.ycd" for i in range(3)]

has_samples = CUT_PATH.is_file() and all(p.is_file() for p in YCD_PATHS)
pytestmark = pytest.mark.skipif(not has_samples, reason="maude_mcs_1 samples not available")


@pytest.fixture()
def ycds():
    return [read_ycd(p) for p in YCD_PATHS]


# --- play_animation ---


def test_play_animation_creates_load_and_set() -> None:
    scene = CutScene.create(duration=10.0)
    mgr = scene.add_animation_manager()
    ped = scene.add_ped("csb_maude")

    events = scene.play_animation(0.0, ped, "maude_mcs_1-0")

    assert len(events) == 2
    assert events[0].event_name == "load_anim_dict"
    assert events[0].label == "maude_mcs_1-0"
    assert events[1].event_name == "set_anim"


def test_play_animation_with_end_creates_cleanup() -> None:
    scene = CutScene.create(duration=10.0)
    mgr = scene.add_animation_manager()
    ped = scene.add_ped("csb_maude")

    events = scene.play_animation(0.0, ped, "maude_mcs_1-0", end=8.0)

    assert len(events) == 4
    names = [e.event_name for e in events]
    assert names == ["load_anim_dict", "set_anim", "clear_anim", "unload_anim_dict"]
    assert events[2].start == 8.0
    assert events[3].start == 8.0


# --- attach_clip_dict ---


def test_attach_clip_dict(ycds) -> None:
    scene = CutScene.create(duration=10.0)
    assert len(scene.clip_dicts) == 0

    for ycd in ycds:
        scene.attach_clip_dict(ycd)

    assert len(scene.clip_dicts) == 3


def test_attach_clip_dict_rejects_non_ycd() -> None:
    scene = CutScene.create(duration=10.0)
    with pytest.raises(TypeError):
        scene.attach_clip_dict("not a ycd")


# --- get_clip / get_animation ---


def test_get_clip_from_attached(ycds) -> None:
    scene = CutScene.create(duration=10.0)
    scene.attach_clip_dict(ycds[0])

    clip = scene.get_clip("exportcamera-0")
    assert clip is not None
    assert clip.short_name == "exportcamera-0"


def test_get_clip_returns_none_when_missing(ycds) -> None:
    scene = CutScene.create(duration=10.0)
    scene.attach_clip_dict(ycds[0])

    assert scene.get_clip("nonexistent_clip") is None


def test_get_animation_from_attached(ycds) -> None:
    scene = CutScene.create(duration=10.0)
    scene.attach_clip_dict(ycds[0])

    clip = scene.get_clip("exportcamera-0")
    assert clip is not None and clip.animation is not None
    anim = scene.get_animation(clip.animation.hash)
    assert anim is not None
    assert anim.frames == 241


# --- available_clips ---


def test_available_clips_merges_all_ycds(ycds) -> None:
    scene = CutScene.create(duration=10.0)
    for ycd in ycds:
        scene.attach_clip_dict(ycd)

    clips = scene.available_clips(cut_index=0)
    assert len(clips) > 0
    assert MetaHash("exportcamera").uint in clips


# --- validate_animations ---


def test_validate_animations_empty_when_no_dicts() -> None:
    scene = CutScene.create(duration=10.0)
    mgr = scene.add_animation_manager()
    ped = scene.add_ped("csb_maude")
    scene.play_animation(0.0, ped, "maude_mcs_1-0")

    assert scene.validate_animations() == []


def test_validate_animations_warns_on_missing_dict(ycds) -> None:
    scene = CutScene.create(duration=10.0)
    scene.attach_clip_dict(ycds[0])
    mgr = scene.add_animation_manager()
    ped = scene.add_ped("csb_maude")
    scene.play_animation(0.0, ped, "totally_fake_dict")

    warnings = scene.validate_animations()
    assert any("totally_fake_dict" in w for w in warnings)


def test_validate_animations_passes_with_matching_dict(ycds) -> None:
    scene = CutScene.create(duration=10.0)
    scene.attach_clip_dict(ycds[0])
    mgr = scene.add_animation_manager()
    ped = scene.add_ped("csb_maude")
    scene.play_animation(0.0, ped, "maude_mcs_1-0")

    warnings = scene.validate_animations()
    dict_warnings = [w for w in warnings if "unknown dict" in w]
    assert dict_warnings == []


# --- real scene + YCD ---


def test_real_scene_attach_and_query(ycds) -> None:
    scene = CutScene.create(duration=10.0)
    for ycd in ycds:
        scene.attach_clip_dict(ycd)

    clips = scene.available_clips(cut_index=0)
    assert len(clips) > 0
