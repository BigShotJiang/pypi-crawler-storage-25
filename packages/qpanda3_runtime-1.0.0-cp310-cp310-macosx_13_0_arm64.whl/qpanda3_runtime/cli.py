
"""
Command-line interface for QPanda3 Runtime Client.

This module provides CLI commands for the QPanda3 runtime client,
primarily for displaying version information.

Examples
--------
>>> python -m qpanda3_runtime.cli --version
"""
import click
import qpanda3_runtime
from click import version_option


cli = click.Group('cli', help='Command-line interface for QPanda3 Runtime Client')

@cli.command(help='Display version information')
@click.option('--version', help='Display version information')
def version_command(version):
    """
    Display the version of QPanda3 Runtime Client.
    
    Parameters
    ----------
    version : bool, optional
        When provided (any value), displays the version information.
        This parameter is typically invoked with '--version' flag.
    
    Returns
    -------
    None
    
    Examples
    --------
    >>> python -m qpanda3_runtime.cli --version
    >>> python -m qpanda3_runtime.cli version_command --version
    
    Notes
    -----
    The version information is retrieved from the package's __version__
    attribute defined in qpanda3_runtime module.
    """
    click.echo(f'QPanda3 Runtime: {qpanda3_runtime.__version__}')

if __name__ == '__main__':
    cli()