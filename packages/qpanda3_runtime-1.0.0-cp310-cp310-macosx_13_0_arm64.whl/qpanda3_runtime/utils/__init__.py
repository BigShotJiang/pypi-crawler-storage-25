"""
Utility functions for QPanda3 Runtime client.

This module provides various utility functions for data conversion,
type handling, and serialization in quantum computing applications.

Modules
-------
convert_json_bytes : Functions for JSON serialization of bytes data
convert_json_ndarray : Functions for JSON serialization of NumPy arrays
union_type : Type definitions and conversion functions for quantum objects
exception : Custom exception classes for error handling

Notes
-----
All functions follow NumPy-style documentation format for consistency.
"""

from .convert_json_bytes import (
    bytes_to_json_safe,
    json_safe_to_bytes,
    demo_bytes_serialization
)

from .convert_json_ndarray import (
    ndarray_to_binary_json,
    binary_json_to_ndarray,
    demo_basic_conversion
)

from .union_type import (
    QProgUnionType,
    ObservableUnionType,
    get_qprog,
    get_observable
)

# Import exception module
from .exception import *

__all__ = [
    # convert_json_bytes exports
    'bytes_to_json_safe',
    'json_safe_to_bytes',
    'demo_bytes_serialization',
    
    # convert_json_ndarray exports
    'ndarray_to_binary_json',
    'binary_json_to_ndarray',
    'demo_basic_conversion',
    
    # union_type exports
    'QProgUnionType',
    'ObservableUnionType',
    'get_qprog',
    'get_observable',
    
    # exception exports (handled by wildcard import)
]