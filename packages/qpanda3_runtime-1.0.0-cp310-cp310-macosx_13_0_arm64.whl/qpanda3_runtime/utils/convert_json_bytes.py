import json
import base64


def bytes_to_json_safe(data):
    """
    Convert data containing bytes to JSON-safe format.
    
    This function recursively traverses the data structure and converts any
    bytes objects to a JSON-safe dictionary format using base64 encoding.
    
    Parameters
    ----------
    data : any
        The input data that may contain bytes objects. Can be a simple value,
        list, tuple, or dictionary.
    
    Returns
    -------
    any
        JSON-safe data structure where bytes objects are replaced with
        dictionaries containing base64-encoded strings.
    
    Notes
    -----
    - Bytes objects are encoded as dictionaries with '__bytes__': True key
      and base64-encoded 'data' field
    - The function handles nested structures recursively
    - Use `json_safe_to_bytes` to restore the original data
    
    Examples
    --------
    >>> data = {"text": "Hello", "binary": b"\x00\x01\x02"}
    >>> json_safe = bytes_to_json_safe(data)
    >>> json_str = json.dumps(json_safe)
    """
    def convert_bytes(obj):
        if isinstance(obj, bytes):
            # Convert bytes to base64 string
            return {
                '__bytes__': True,
                'data': base64.b64encode(obj).decode('utf-8')
            }
        elif isinstance(obj, (list, tuple)):
            return [convert_bytes(item) for item in obj]
        elif isinstance(obj, dict):
            return {key: convert_bytes(value) for key, value in obj.items()}
        else:
            return obj

    return convert_bytes(data)


def json_safe_to_bytes(data):
    """
    Restore bytes data from JSON-safe format.
    
    This function recursively traverses the JSON-safe data structure and
    restores bytes objects from the base64-encoded dictionary format.
    
    Parameters
    ----------
    data : any
        JSON-safe data structure that may contain dictionaries with
        '__bytes__': True key and base64-encoded 'data' field.
    
    Returns
    -------
    any
        Original data structure with bytes objects restored.
    
    Raises
    ------
    ValueError
        If the base64 decoding fails for any reason.
    
    Notes
    -----
    - This function is the inverse of `bytes_to_json_safe`
    - It handles nested structures recursively
    - The input should be the output of `bytes_to_json_safe` or compatible format
    
    Examples
    --------
    >>> json_safe = {"text": "Hello", "binary": {"__bytes__": True, "data": "AAEC"}}
    >>> restored = json_safe_to_bytes(json_safe)
    >>> restored["binary"] == b"\x00\x01\x02"
    True
    """
    def restore_bytes(obj):
        if isinstance(obj, dict) and obj.get('__bytes__', False):
            return base64.b64decode(obj['data'])
        elif isinstance(obj, (list, tuple)):
            return [restore_bytes(item) for item in obj]
        elif isinstance(obj, dict):
            return {key: restore_bytes(value) for key, value in obj.items()}
        else:
            return obj

    return restore_bytes(data)


def demo_bytes_serialization():
    """
    Demonstrate bytes serialization and deserialization.
    
    This function shows a complete example of converting data containing
    bytes to JSON-safe format and restoring it back.
    
    Examples
    --------
    >>> demo_bytes_serialization()
    === Bytes Serialization Demo ===
    Original data:
      binary_data: b'\\x00\\x01\\x02\\x03\\x04\\x05'
      nested.image_data: b'fake_image_data_here'
    ...
    """
    print("=== Bytes Serialization Demo ===")

    # Data containing bytes
    original_data = {
        "text": "Hello World",
        "binary_data": b"\x00\x01\x02\x03\x04\x05",  # bytes data
        "nested": {
            "image_data": b"fake_image_data_here",
            "numbers": [1, 2, 3]
        }
    }

    print("Original data:")
    print(f"  binary_data: {original_data['binary_data']}")
    print(f"  nested.image_data: {original_data['nested']['image_data']}")

    # Serialization
    json_safe_data = bytes_to_json_safe(original_data)
    json_str = json.dumps(json_safe_data, indent=2)

    print(f"\nJSON data:")
    print(json_str[:200] + "..." if len(json_str) > 200 else json_str)

    # Deserialization
    loaded_data = json.loads(json_str)
    restored_data = json_safe_to_bytes(loaded_data)

    print(f"\nRestored data:")
    print(f"  binary_data: {restored_data['binary_data']}")
    print(f"  Data consistency: {restored_data['binary_data'] == original_data['binary_data']}")

if __name__ == '__main__':
    demo_bytes_serialization()