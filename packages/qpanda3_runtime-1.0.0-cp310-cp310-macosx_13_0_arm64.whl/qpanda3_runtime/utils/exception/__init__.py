"""
Exception module for quantum computing runtime client.

This module provides error handling classes and utilities for the
QPanda3 runtime client. It includes error type enumerations and
response error containers for consistent error reporting across
the quantum computing service stack.

Classes
-------
ErrorType
    Enumeration of error types for quantum computing runtime errors.
ResponseError
    Container class for response errors with serialization support.

Examples
--------
>>> from qpanda3_runtime.utils.exception import ErrorType, ResponseError
>>> 
>>> # Create a resource unavailable error
>>> error = ResponseError.resource_unavailable(
...     'quantum_device',
...     1001,
...     'Device calibration in progress',
...     ['device_status', 'calibration_check']
... )
>>> 
>>> # Convert to JSON for transmission
>>> json_str = error.json()
>>> print(json_str)
{"position": "quantum_device", "error_code": 1001, ...}
"""

from .response_error import ErrorType, ResponseError

__all__ = ['ErrorType', 'ResponseError']