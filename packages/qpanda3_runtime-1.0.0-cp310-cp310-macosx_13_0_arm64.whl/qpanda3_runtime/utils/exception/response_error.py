import json
from enum import Enum
from typing import Union


class ErrorType(Enum):
    """
    Error type enumeration for response errors.
    
    This enum defines the types of errors that can occur in the quantum computing
    runtime system. Each error type corresponds to a specific category of failures.
    
    Attributes
    ----------
    Undefined : int
        Default error type when the specific error category is not determined.
    ResourceUnavailable : int
        Error type for when required resources (quantum devices, services, etc.)
        are not available or accessible.
    InvalidRequest : int
        Error type for when the client request contains invalid parameters,
        malformed data, or violates system constraints.
    ServiceFailure : int
        Error type for when internal service operations fail due to unexpected
        conditions or system errors.
    """
    Undefined = 0
    ResourceUnavailable = 5
    InvalidRequest = 4
    ServiceFailure = 6


class ResponseError:
    """
    Response error container for quantum computing runtime operations.
    
    This class encapsulates error information returned from quantum computing
    services, including error location, code, description, type, and trace records.
    
    Parameters
    ----------
    position : str
        The location or component where the error occurred (e.g., function name,
        module name, or service endpoint).
    error_code : int
        Numeric error code identifying the specific error condition.
    error_info : str
        Human-readable description of the error.
    error_type : ErrorType
        Category of the error (see ErrorType enum).
    trace_record : Union[list, None]
        List of trace records providing detailed error context, or None for
        no trace information.
    
    Attributes
    ----------
    position : str
        Error location identifier.
    error_code : int
        Numeric error code.
    error_info : str
        Error description.
    error_type : ErrorType
        Error category.
    trace_record : list
        List of trace records for debugging.
    help_info : str
        Additional help information (optional, initialized as empty string).
    """
    def __init__(self, position: str, error_code: int, error_info: str, error_type: ErrorType,
                 trace_record: Union[list, None]):
        self.position = position
        self.error_code = error_code
        self.error_info = error_info
        self.error_type: ErrorType = error_type
        if trace_record is None:
            self.trace_record = []
        else:
            self.trace_record = trace_record
        self.help_info = ''

    def dict_data(self):
        """
        Convert the error object to a dictionary representation.
        
        Returns
        -------
        dict
            Dictionary containing all error attributes with keys:
            - 'position': error location
            - 'error_code': numeric error code
            - 'error_info': error description
            - 'error_type': error type value (integer)
            - 'trace_record': list of trace records
            - 'help_info': additional help information
            
        Examples
        --------
        >>> error = ResponseError('service_endpoint', 1001, 'Device not found', 
        ...                       ErrorType.ResourceUnavailable, None)
        >>> error_dict = error.dict_data()
        >>> print(error_dict['error_code'])
        1001
        """
        return {'position': self.position, 'error_code': self.error_code, 'error_info': self.error_info,
                'error_type': self.error_type.value, 'trace_record': self.trace_record, 'help_info': self.help_info}

    def __str__(self):
        """
        Return a string representation of the error object.
        
        Returns
        -------
        str
            String representation of the error dictionary with error type
            converted to its name (string) instead of numeric value.
            
        Notes
        -----
        This method overrides the default string representation to provide
        more readable error information, including the error type name.
        """
        data = self.dict_data()
        data['error_type'] = self.error_type.name
        return str(data)

    def json(self):
        """
        Convert the error object to a JSON string representation.
        
        Returns
        -------
        str
            JSON-formatted string containing all error attributes.
            
        See Also
        --------
        dict_data : Get dictionary representation of the error.
        
        Examples
        --------
        >>> error = ResponseError('auth_service', 2001, 'Invalid API key', 
        ...                       ErrorType.InvalidRequest, ['auth_check', 'key_validation'])
        >>> json_str = error.json()
        >>> print(json_str[:50])
        {"position": "auth_service", "error_code": 2001, ...
        """
        return json.dumps(self.dict_data())

    @staticmethod
    def from_dict(data):
        """
        Create a ResponseError object from a dictionary.
        
        Parameters
        ----------
        data : dict
            Dictionary containing error information with keys:
            - 'position': error location (string)
            - 'error_code': numeric error code (int)
            - 'error_info': error description (string)
            - 'error_type': error type value (int)
            - 'trace_record': list of trace records (list)
            - 'help_info': optional help information (string, optional)
            
        Returns
        -------
        ResponseError
            New ResponseError instance populated from the dictionary data.
            
        Raises
        ------
        KeyError
            If required dictionary keys are missing.
        ValueError
            If error_type value is not a valid ErrorType enum value.
            
        Examples
        --------
        >>> error_dict = {
        ...     'position': 'quantum_device',
        ...     'error_code': 3001,
        ...     'error_info': 'Device calibration failed',
        ...     'error_type': 6,  # ServiceFailure
        ...     'trace_record': ['calibration', 'hardware_check'],
        ...     'help_info': 'Try restarting the device'
        ... }
        >>> error = ResponseError.from_dict(error_dict)
        >>> print(error.error_info)
        Device calibration failed
        """
        res = ResponseError('', 0, '', ErrorType(0), None)
        res.position = data['position']
        res.error_code = data['error_code']
        res.error_info = data['error_info']
        res.error_type = ErrorType(data['error_type'])
        res.trace_record = data['trace_record']
        if data.get('help_info'):
            res.help_info = data['help_info']
        else:
            res.help_info = ''
        return res

    @staticmethod
    def from_json(json_data):
        """
        Create a ResponseError object from a JSON string.
        
        Parameters
        ----------
        json_data : str
            JSON-formatted string containing error information.
            
        Returns
        -------
        ResponseError
            New ResponseError instance populated from the JSON data.
            
        See Also
        --------
        from_dict : Create ResponseError from dictionary.
        json : Convert ResponseError to JSON string.
        
        Examples
        --------
        >>> json_str = '''{
        ...     "position": "network_layer",
        ...     "error_code": 4001,
        ...     "error_info": "Connection timeout",
        ...     "error_type": 5,
        ...     "trace_record": ["socket_connect", "retry_attempt"]
        ... }'''
        >>> error = ResponseError.from_json(json_str)
        >>> print(error.position)
        network_layer
        """
        return ResponseError.from_dict(json.loads(json_data))

    @staticmethod
    def resource_unavailable(position: str, error_code: int, error_info: str, trace_record: Union[list, None]):
        """
        Create a ResponseError for resource unavailable errors.
        
        Parameters
        ----------
        position : str
            Location where the resource error occurred.
        error_code : int
            Numeric error code specific to the resource issue.
        error_info : str
            Description of the resource error.
        trace_record : Union[list, None]
            Trace records for debugging, or None for no trace.
            
        Returns
        -------
        ResponseError
            ResponseError instance with error_type set to ResourceUnavailable.
            
        Examples
        --------
        >>> error = ResponseError.resource_unavailable(
        ...     'quantum_processor',
        ...     5001,
        ...     'Quantum device is currently undergoing maintenance',
        ...     ['device_status_check', 'maintenance_schedule']
        ... )
        >>> print(error.error_type)
        ErrorType.ResourceUnavailable
        """
        res = ResponseError('', 0, '', ErrorType(0), None)
        res.position = position
        res.error_code = error_code
        res.error_info = error_info
        res.error_type = ErrorType.ResourceUnavailable
        res.trace_record = trace_record
        return res

    @staticmethod
    def invalid_request(position: str, error_code: int, error_info: str, trace_record: Union[list, None]):
        """
        Create a ResponseError for invalid request errors.
        
        Parameters
        ----------
        position : str
            Location where the request validation failed.
        error_code : int
            Numeric error code specific to the validation failure.
        error_info : str
            Description of why the request is invalid.
        trace_record : Union[list, None]
            Trace records for debugging, or None for no trace.
            
        Returns
        -------
        ResponseError
            ResponseError instance with error_type set to InvalidRequest.
            
        Examples
        --------
        >>> error = ResponseError.invalid_request(
        ...     'parameter_validation',
        ...     6001,
        ...     'Qubit count must be between 1 and 20',
        ...     ['param_check', 'range_validation']
        ... )
        >>> print(error.error_type)
        ErrorType.InvalidRequest
        """
        res = ResponseError('', 0, '', ErrorType(0), None)
        res.position = position
        res.error_code = error_code
        res.error_info = error_info
        res.error_type = ErrorType.InvalidRequest
        res.trace_record = trace_record
        return res
