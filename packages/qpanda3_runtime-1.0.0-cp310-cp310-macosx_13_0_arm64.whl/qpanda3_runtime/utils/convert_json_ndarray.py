import numpy as np
import json
import base64


def ndarray_to_binary_json(arr):
    """
    Convert NumPy array to binary JSON format.
    
    This function serializes a NumPy array into a JSON-safe dictionary
    containing the array's data, dtype, and shape encoded in base64.
    
    Parameters
    ----------
    arr : numpy.ndarray
        The NumPy array to be serialized.
    
    Returns
    -------
    dict
        JSON-safe dictionary with the following keys:
        - '__ndarray__': True (identifier for ndarray data)
        - 'dtype': string representation of array dtype
        - 'shape': tuple of array dimensions
        - 'data': base64-encoded array bytes
    
    Notes
    -----
    - The array is converted to bytes using `tobytes()` method
    - Base64 encoding ensures JSON compatibility
    - Use `binary_json_to_ndarray` to restore the array
    
    Examples
    --------
    >>> import numpy as np
    >>> arr = np.array([[1, 2], [3, 4]], dtype=np.float32)
    >>> json_data = ndarray_to_binary_json(arr)
    >>> json_str = json.dumps(json_data)
    """
    # Convert array to bytes
    arr_bytes = arr.tobytes()

    # Encode to base64 string (suitable for JSON transmission)
    arr_base64 = base64.b64encode(arr_bytes).decode('utf-8')

    # JSON object containing metadata
    json_data = {
        '__ndarray__': True,
        'dtype': str(arr.dtype),
        'shape': arr.shape,
        'data': arr_base64
    }

    return json_data


def binary_json_to_ndarray(json_data):
    """
    Restore NumPy array from binary JSON format.
    
    This function deserializes a JSON-safe dictionary back into a NumPy array
    by decoding the base64-encoded data and reconstructing the array with
    its original dtype and shape.
    
    Parameters
    ----------
    json_data : dict
        JSON-safe dictionary containing ndarray data. Must have the following
        keys:
        - '__ndarray__': True (identifier for ndarray data)
        - 'dtype': string representation of array dtype
        - 'shape': tuple of array dimensions
        - 'data': base64-encoded array bytes
    
    Returns
    -------
    numpy.ndarray
        Restored NumPy array with original data, dtype, and shape.
    
    Raises
    ------
    ValueError
        If the input dictionary does not contain '__ndarray__': True key.
    TypeError
        If the dtype string cannot be parsed or the shape is invalid.
    
    Notes
    -----
    - This function is the inverse of `ndarray_to_binary_json`
    - The dtype string is parsed using numpy's dtype constructor
    - Missing shape information results in a 1D array
    
    Examples
    --------
    >>> json_data = {
    ...     '__ndarray__': True,
    ...     'dtype': 'float32',
    ...     'shape': [2, 2],
    ...     'data': 'AACAPwAAAEAAAEBA'
    ... }
    >>> arr = binary_json_to_ndarray(json_data)
    >>> arr.shape
    (2, 2)
    """
    if not json_data.get('__ndarray__', False):
        raise ValueError("Invalid ndarray JSON data")

    # Decode base64 data
    arr_bytes = base64.b64decode(json_data['data'])

    # Reconstruct array from bytes
    arr = np.frombuffer(arr_bytes, dtype=json_data['dtype'])

    # Reshape if shape information is provided
    if 'shape' in json_data:
        arr = arr.reshape(json_data['shape'])

    return arr


def demo_basic_conversion():
    """
    Demonstrate basic binary conversion for NumPy arrays.
    
    This function shows a complete example of converting a NumPy array
    to JSON format and restoring it back.
    
    Examples
    --------
    >>> demo_basic_conversion()
    === Basic Binary Conversion Demo ===
    Original array:
    [[1. 2. 3.]
     [4. 5. 6.]]
    Shape: (2, 3), dtype: float32
    ...
    """
    print("=== Basic Binary Conversion Demo ===")

    # Create test array
    original_array = np.array([[1, 2, 3], [4, 5, 6]], dtype=np.float32)
    print(f"Original array:\n{original_array}")
    print(f"Shape: {original_array.shape}, dtype: {original_array.dtype}")

    # Convert to JSON
    json_data = ndarray_to_binary_json(original_array)
    json_str = json.dumps(json_data)

    print(f"\nJSON data size: {len(json_str)} characters")
    print(f"JSON keys: {list(json_data.keys())}")

    # Transmission (simulate network transmission)
    transmitted_data = json.loads(json_str)

    # Restore array
    recovered_array = binary_json_to_ndarray(transmitted_data)

    print(f"\nRecovered array:\n{recovered_array}")
    print(f"Shape: {recovered_array.shape}, dtype: {recovered_array.dtype}")
    print(f"Data consistency: {np.array_equal(original_array, recovered_array)}")

if __name__ == '__main__':
    demo_basic_conversion()