from typing import Union, List, Tuple, Any

from pyqpanda3.hamiltonian import Hamiltonian, PauliOperator
from pyqpanda3.core import QProg, QCircuit


QProgUnionType = Union[QProg, str, QCircuit]
"""Union type for quantum program representations.

This type alias defines the acceptable input types for quantum programs:
- QProg: Native quantum program object
- str: Quantum program in string format (e.g., QASM, originir)
- QCircuit: Quantum circuit object

Notes
-----
- Used for type hints in functions that accept multiple quantum program formats
- Provides flexibility in API design while maintaining type safety
"""

ObservableUnionType = Union[Hamiltonian, PauliOperator, str]
"""Union type for quantum observable representations.

This type alias defines the acceptable input types for quantum observables:
- Hamiltonian: Native Hamiltonian object
- PauliOperator: Pauli operator object
- str: Observable in string format (e.g., Pauli string representation)

Notes
-----
- Used for type hints in functions that accept multiple observable formats
- Enables flexible input while ensuring type checking
"""


def get_qprog(prog: QProgUnionType, res_type: str):
    """
    Convert quantum program to specified representation format.
    
    This function normalizes quantum program input to a consistent output
    format based on the requested representation type.
    
    Parameters
    ----------
    prog : QProgUnionType
        Quantum program input in any supported format:
        - QProg object
        - String representation
        - QCircuit object
    res_type : str
        Desired output format. Valid values:
        - 'object': Return QProg object
        - 'ir' or 'originir': Return string representation
    
    Returns
    -------
    QProg or str
        Quantum program in the requested format.
    
    Raises
    ------
    RuntimeError
        If `res_type` is not one of the valid options.
    
    Notes
    -----
    - For 'object' output, string inputs are converted to QProg objects
    - For 'ir'/'originir' output, QProg objects are converted to strings
      with 15-digit precision
    - QCircuit objects are automatically wrapped in QProg when needed
    
    Examples
    --------
    >>> prog_str = "H 0\\nCNOT 0 1"
    >>> qprog = get_qprog(prog_str, 'object')
    >>> isinstance(qprog, QProg)
    True
    """
    if res_type == 'object':
        if isinstance(prog, QProg):
            return prog
        else:
            return QProg(prog)
    elif res_type == 'ir' or res_type == 'originir':
        if isinstance(prog, QProg):
            return prog.originir(precision=15)
        elif isinstance(prog, QCircuit):
            return QProg(prog).originir(precision=15)
        else:
            return prog
    else:
        raise RuntimeError(f"Invalid res_type: {res_type}")

def get_observable(observable: ObservableUnionType, res_type: str):
    """
    Convert quantum observable to specified representation format.
    
    This function normalizes quantum observable input to a consistent output
    format based on the requested representation type.
    
    Parameters
    ----------
    observable : ObservableUnionType
        Quantum observable input in any supported format:
        - Hamiltonian object
        - PauliOperator object
        - String representation
    res_type : str
        Desired output format. Valid values:
        - 'hamiltonian': Return Hamiltonian object
        - 'paulioperator': Return PauliOperator object
        - 'str': Return string representation
    
    Returns
    -------
    Hamiltonian, PauliOperator, or str
        Quantum observable in the requested format.
    
    Raises
    ------
    RuntimeError
        If `res_type` is not one of the valid options.
    
    Notes
    -----
    - String inputs are parsed assuming comma-separated key:value pairs
    - Quotes in Pauli operator strings are automatically removed
    - Complex coefficients in string format are supported
    - For 'str' output, coefficients are formatted as real numbers
    
    Examples
    --------
    >>> obs_str = "Z0: 1.0, X0: 0.5"
    >>> hamiltonian = get_observable(obs_str, 'hamiltonian')
    >>> isinstance(hamiltonian, Hamiltonian)
    True
    """
    def prepare_input(observable: str):
        """
        Parse string representation of observable to dictionary.
        
        Parameters
        ----------
        observable : str
            String representation in format "key1: value1, key2: value2"
        
        Returns
        -------
        dict
            Dictionary mapping Pauli operators to complex coefficients.
        """
        items = observable.strip().split(',')
        tmp = {}
        for item in items:
            item = item.strip()
            if item == '':
                continue
            k_v = item.split(':')
            pauli_op = k_v[0].strip()
            pauli_op = pauli_op.replace('\'', '')
            pauli_op = pauli_op.replace('\"', '')
            tmp[pauli_op] = complex(k_v[1])

        return tmp
    
    res_type = res_type.lower()
    if res_type == 'hamiltonian':
        if isinstance(observable, Hamiltonian):
            return observable
        elif isinstance(observable, PauliOperator):
            return Hamiltonian(observable)
        else:
            return Hamiltonian(prepare_input(observable))

    elif res_type == 'paulioperator':
        if isinstance(observable, PauliOperator):
            return observable
        elif isinstance(observable, str):
            return PauliOperator(prepare_input(observable))
        else:
            return observable.pauli_operator()
    elif res_type == 'str':
        if isinstance(observable, str):
            return observable
        elif isinstance(observable, PauliOperator):
            return observable.data_dict_str(
                is_coeff_complex=False,
                double_quote=True)
        else:
            return observable.pauli_operator().data_dict_str(
                is_coeff_complex=False,
                double_quote=True)
    else:
        raise RuntimeError(f'Invalid res_type: {res_type}')


