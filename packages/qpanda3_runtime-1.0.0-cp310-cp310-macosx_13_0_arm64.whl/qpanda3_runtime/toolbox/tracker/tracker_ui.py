from typing import Dict, Any, Optional, List
import os
import sys

from .tracker_trace import TrackerTrace
from .tracker_system import TrackerSystem


class Tracker:
    """User interface for tracking operations with three usage patterns.
    
    This class provides a unified interface for tracking operations with support
    for manual tracking, context manager usage, and decorator-based tracking.
    
    Attributes
    ----------
    is_active : bool
        Indicates whether the tracker is currently active.
    
    Examples
    --------
    >>> # Manual tracking
    >>> tracker = Tracker(service)
    >>> tracker.start("operation_name")
    >>> tracker.record({"key": "value"})
    >>> tracker.end()
    
    >>> # Context manager usage
    >>> with Tracker(service, name="operation") as t:
    ...     t.record({"data": 123})
    
    >>> # Decorator usage
    >>> @tracker(service)
    ... def my_function():
    ...     pass
    """
    
    def __init__(self, service: TrackerSystem, name: str = None, data: Dict[str, Any] = None):
        """Initialize a tracker instance.
        
        Parameters
        ----------
        service : TrackerSystem
            The underlying tracking system service.
        name : str, optional
            Operation name for context manager usage.
        data : Dict[str, Any], optional
            Additional data to associate with the tracking context.
        
        Notes
        -----
        When using as a context manager, both `name` and `data` parameters
        are required to provide meaningful tracking context.
        """
        self._service = service
        self._is_active = False
        self._name = name
        self._tracker_data = data
    
    def start(self, context_name: str, labels: List[str] = None, 
              data: Dict[str, Any] = None) -> 'Tracker':
        """Start tracking an operation.
        
        Parameters
        ----------
        context_name : str
            Name of the operation or context being tracked.
        labels : List[str], optional
            List of labels to categorize the tracking session.
        data : Dict[str, Any], optional
            Initial data to record for this tracking session.
        
        Returns
        -------
        Tracker
            Self reference for method chaining.
        
        Raises
        ------
        RuntimeError
            If the tracker is already active or service is not available.
        """
        if labels is None:
            labels = []
        if self._service and not self._is_active:
            self._is_active = True
            self._service.enter(context_name, labels, data)
        return self
    
    def end(self, result_data: Dict[str, Any] = None, labels: List[str] = None) -> 'Tracker':
        """End the current tracking session.
        
        Parameters
        ----------
        result_data : Dict[str, Any], optional
            Result data to record at the end of the operation.
        labels : List[str], optional
            Additional labels to apply to the end record.
        
        Returns
        -------
        Tracker
            Self reference for method chaining.
        
        Notes
        -----
        If the tracker is not active, this method does nothing and returns
        the tracker instance unchanged.
        """
        if labels is None:
            labels = []
        if self._is_active:
            self._is_active = False
            self._service.exit(result_data=result_data, labels=labels)
        return self
    
    def record(self, data: Dict[str, Any], labels: List[str] = None) -> 'Tracker':
        """Record data during an active tracking session.
        
        Parameters
        ----------
        data : Dict[str, Any]
            Data to record in the current tracking session.
        labels : List[str], optional
            Labels to associate with this data record.
        
        Returns
        -------
        Tracker
            Self reference for method chaining.
        
        Raises
        ------
        RuntimeError
            If the tracker is not active when attempting to record data.
        """
        if labels is None:
            labels = []
        if self._is_active:
            self._service.record(record=data, labels=labels)
        return self

    def exit_broken_context(self) -> None:
        """Exit a broken context when used as a context manager.
        
        This method is called internally when a context manager exits
        due to an exception. It ensures proper cleanup of tracking state.
        """
        if self._is_active:
            self._service.exit_broken_context()
    
    def __enter__(self) -> 'Tracker':
        """Enter context manager mode.
        
        Returns
        -------
        Tracker
            Self reference for use within the context.
        
        Raises
        ------
        RuntimeError
            If the tracker was created without a name for context usage.
        """
        if self._name is None or self._name == '':
            raise RuntimeError("For context, tracker should be with name")
        self.start(self._name, [], self._tracker_data)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit context manager mode.
        
        Parameters
        ----------
        exc_type : type
            Type of exception that caused exit, or None.
        exc_val : Exception
            Exception instance that caused exit, or None.
        exc_tb : traceback
            Traceback object for the exception, or None.
        """
        self.end({'exc_type': str(exc_type), 'exc_val': str(exc_val), 'exc_tb': str(exc_tb)})
    
    @property
    def is_active(self) -> bool:
        """Check if the tracker is currently active.
        
        Returns
        -------
        bool
            True if the tracker is actively tracking, False otherwise.
        """
        return self._is_active
    
    def get_current_record(self) -> TrackerTrace:
        """Get the current tracking record.
        
        Returns
        -------
        TrackerTrace
            The current trace record if tracking is active.
        
        Notes
        -----
        Returns None if no tracking session is active or if the service
        does not have a current trace.
        """
        return self._service._trace


class TrackerRef:
    """Reference wrapper for tracker instances in decorator scenarios.
    
    This class provides a way to reference a tracker instance from within
    a decorated function without direct access to the tracker object.
    
    Attributes
    ----------
    name : str
        Reference name for identification.
    is_active : bool
        Indicates whether the referenced tracker is currently active.
    
    Examples
    --------
    >>> ref = TrackerRef("my_tracker")
    >>> @tracker(service, ref=ref)
    ... def my_function():
    ...     ref.record({"data": "value"})
    """
    
    def __init__(self, name: str = ""):
        """Initialize a tracker reference.
        
        Parameters
        ----------
        name : str, optional
            Reference name for identification and debugging.
        """
        self.name = name
        self.tracker = None  # Will be set by decorator
    
    def record(self, data: Dict[str, Any], labels: List[str] = None) -> None:
        """Record data through the referenced tracker.
        
        Parameters
        ----------
        data : Dict[str, Any]
            Data to record in the current tracking session.
        labels : List[str], optional
            Labels to associate with this data record.
        
        Raises
        ------
        RuntimeError
            If the tracker reference is not properly initialized or
            if no tracker is currently active.
        """
        if labels is None:
            labels = []
        if self.tracker is None:
            raise RuntimeError(
                f"TrackerRef('{self.name}') is not properly initialized. "
                "Ensure it's used within a function decorated with @tracker"
            )
        self.tracker.record(data, labels)
    
    @property
    def is_active(self) -> bool:
        """Check if the referenced tracker is active.
        
        Returns
        -------
        bool
            True if the referenced tracker exists and is active.
        """
        return self.tracker is not None and self.tracker.is_active


def tracker(service: TrackerSystem, ref: Optional[TrackerRef] = None, data: Any = None):
    """Decorator for automatic function tracking.
    
    This decorator automatically tracks function execution including
    start time, end time, and any exceptions that occur.
    
    Parameters
    ----------
    service : TrackerSystem
        The tracking system service to use.
    ref : TrackerRef, optional
        Tracker reference for accessing the tracker from within
        the decorated function.
    data : Any, optional
        Additional data to associate with the tracking session.
    
    Returns
    -------
    function
        Decorator function that wraps the original function.
    
    Examples
    --------
    >>> @tracker(service)
    ... def process_data(data):
    ...     return data * 2
    
    >>> ref = TrackerRef()
    >>> @tracker(service, ref=ref)
    ... def complex_operation():
    ...     ref.record({"step": "started"})
    ...     # operation logic
    """
    
    def decorator(func):
        def wrapper(*args, **kwargs):
            internal_tracker = Tracker(service)
            
            if ref:
                ref.tracker = internal_tracker
            
            try:
                internal_tracker.start(func.__name__, data=data)
                result = func(*args, **kwargs)
                internal_tracker.end({'result': str(result)})
                return result
            except Exception as e:
                internal_tracker.end({'error': e})
                raise
            finally:
                if ref:
                    ref.tracker = None
        
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper
    
    return decorator
