from abc import ABC, abstractmethod
from typing import Any, List
from .tracker_trace import TrackerTrace


class TrackingRule(ABC):
    """Abstract base class for tracking analysis rules.
    
    This class defines the interface for tracking analysis rules that can
    process tracker traces and produce analysis results. Each rule must
    implement a unique identifier and an analysis method.
    
    Subclasses should implement specific analysis logic for different
    types of tracking data or analysis requirements.
    
    Examples
    --------
    >>> class MyTrackingRule(TrackingRule):
    ...     @property
    ...     def rule_id(self) -> str:
    ...         return "my_rule"
    ...     
    ...     def analyze(self, data: TrackerTrace) -> Any:
    ...         # Custom analysis logic
    ...         return {"result": "analysis_complete"}
    """
    
    @property
    @abstractmethod
    def rule_id(self) -> str:
        """Get the unique identifier for this rule.
        
        Returns
        -------
        str
            Unique rule identifier string.
        
        Notes
        -----
        Rule IDs should be descriptive and unique within the system.
        They are used to register and retrieve rules from the rule manager.
        """
        pass
    
    @abstractmethod
    def analyze(self, data: TrackerTrace) -> Any:
        """Analyze tracking data using this rule.
        
        Parameters
        ----------
        data : TrackerTrace
            Tracking trace data to analyze. Must be a valid TrackerTrace
            instance containing tracking session information.
        
        Returns
        -------
        Any
            Analysis result. The type and structure of the result
            depends on the specific rule implementation.
        
        Raises
        ------
        ValueError
            If the input data is not a valid TrackerTrace instance.
        RuntimeError
            If analysis cannot be performed due to invalid data state.
        """
        pass


class TrackingRules:
    """Manager for tracking analysis rules.
    
    This class manages a collection of tracking rules, providing
    registration, retrieval, and rule selection functionality.
    
    Attributes
    ----------
    available_rules : List[str]
        List of registered rule IDs.
    default_rule : TrackingRule
        The default rule used when no specific rule is requested.
    
    Examples
    --------
    >>> default_rule = DefaultTrackingRule()
    >>> rule_manager = TrackingRules(default_rule)
    >>> rule_manager.register_rule(MyTrackingRule())
    >>> rule = rule_manager.get_rule("my_rule")
    >>> result = rule.analyze(trace_data)
    """

    def __init__(self, default_rule: TrackingRule):
        """Initialize the rule manager with a default rule.
        
        Parameters
        ----------
        default_rule : TrackingRule
            The default rule to use when no specific rule is requested
            or when a requested rule is not found.
        
        Notes
        -----
        The default rule is automatically registered with its rule_id
        during initialization.
        """
        self._rules = {}
        self._default_rule = default_rule
        self._rules[self._default_rule.rule_id] = self._default_rule

    def register_rule(self, rule: TrackingRule) -> None:
        """Register a new tracking rule.
        
        Parameters
        ----------
        rule : TrackingRule
            Rule instance to register.
        
        Raises
        ------
        ValueError
            If a rule with the same rule_id is already registered.
        
        Notes
        -----
        Registered rules can be retrieved later using their rule_id.
        If a rule with the same ID already exists, it will be replaced.
        """
        self._rules[rule.rule_id] = rule

    def get_rule(self, rule_id: str) -> TrackingRule:
        """Get a rule by its identifier.
        
        Parameters
        ----------
        rule_id : str
            Identifier of the rule to retrieve.
        
        Returns
        -------
        TrackingRule
            The requested rule instance, or the default rule if
            the requested rule is not found.
        
        Notes
        -----
        This method provides a safe way to retrieve rules, falling back
        to the default rule when the requested rule is not available.
        """
        return self._rules.get(rule_id, self._default_rule)

    def get_default_rule(self) -> TrackingRule:
        """Get the default rule.
        
        Returns
        -------
        TrackingRule
            The default rule instance.
        """
        return self._default_rule

    def get_available_rules(self) -> List[str]:
        """Get list of available rule identifiers.
        
        Returns
        -------
        List[str]
            List of registered rule IDs.
        
        Notes
        -----
        The list includes the default rule ID and all registered
        custom rule IDs.
        """
        return list(self._rules.keys())

    def decide_rule(self, data: Any) -> TrackingRule:
        """Determine which rule to use for analyzing given data.
        
        Parameters
        ----------
        data : Any
            Data to be analyzed. The type and structure may influence
            rule selection.
        
        Returns
        -------
        TrackingRule
            Rule instance selected for analyzing the data.
        
        Notes
        -----
        The default implementation always returns the default rule.
        Subclasses can override this method to implement custom
        rule selection logic based on data characteristics.
        """
        return self._default_rule
