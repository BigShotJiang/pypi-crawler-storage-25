import time
from typing import Dict, Any, Optional,List
import os
import sys


from .tracker_trace import TrackerTrace
from .tracking_rule import TrackingRules
from .tracking_rules.default_tracking_rule import DefaultTrackingRule    


class TrackerSystem:
    """
    Global tracking process manager combining RuntimeService and GlobalTracker responsibilities.
    
    This class provides a unified interface for tracking quantum program execution,
    managing trace data, and handling tracking rules. It serves as the central
    coordinator between user-facing tracking operations and internal trace storage.
    
    Attributes
    ----------
    save_to_file : bool
        Whether to save tracking records to file
    name : str
        Name identifier for this tracker system
    _trace : TrackerTrace
        Internal trace data storage and management
    _rules : TrackingRules
        Manager for tracking analysis rules
        
    Examples
    --------
    >>> tracker = TrackerSystem("my_tracker", "trace.jsonl")
    >>> tracker.enter("quantum_circuit", ["qiskit", "simulation"])
    >>> tracker.record({"qubits": 5, "depth": 10})
    >>> tracker.exit({"result": "success"})
    >>> tracker.close()
    """
    
    def __init__(self, name: str = "TrackerSystem",trace_record_file: Optional[str] = None,
        load_history_records: bool = True,save_to_file:bool=True):
        """
        Initialize the tracker system.
        
        Parameters
        ----------
        name : str, optional
            Name identifier for the tracker system, default is "TrackerSystem"
        trace_record_file : str, optional
            Path to trace record file for persistent storage
        load_history_records : bool, optional
            Whether to load existing records from file, default is True
        save_to_file : bool, optional
            Whether to save new records to file, default is True
            
        Notes
        -----
        - If trace_record_file is provided and load_history_records is True,
          existing records will be loaded into memory
        - The system uses default tracking rules which can be extended
        """
        self.save_to_file = save_to_file
        self.name = name
        
        # Integrate TrackerTrace for data storage
        self._trace = TrackerTrace(trace_record_file,load_history_records)
        
        # Integrate TrackingRules for rule management
        self._rules = TrackingRules(DefaultTrackingRule())
        
    
    def enter(self, context_name: str
        , tracking_labels: List[str] = []
        ,context_data: Dict[str, Any] = None
        ) -> None:
        """
        Enter a new tracking context.
        
        Parameters
        ----------
        context_name : str
            Name of the context to enter
        tracking_labels : List[str], optional
            Labels for categorizing the context
        context_data : Dict[str, Any], optional
            Additional data associated with the context
            
        Notes
        -----
        - Contexts can be nested to represent hierarchical operations
        - Each context must be matched with a corresponding exit() call
        - Labels can be used for filtering and analysis
        """
        self._trace.begin_context(context_name,tracking_labels,context_data,self.save_to_file)
    
    def exit(self, result_data:Dict[str,Any]=None,labels:List[str]=[]) -> None:
        """
        Exit the current tracking context.
        
        Parameters
        ----------
        result_data : Dict[str, Any], optional
            Result data to associate with the completed context
        labels : List[str], optional
            Additional labels for the exit operation
            
        Raises
        ------
        RuntimeError
            If there is no active context to exit
            
        Notes
        -----
        - Must be called to match each enter() call
        - Result data is recorded as part of the context completion
        """
        self._trace.end_context(result_data=result_data,save_to_file=self.save_to_file,labels=labels)
    
    def record(self, record: Dict[str, Any],labels:List[str]=[]) -> None:
        """
        Record data within the current tracking context.
        
        Parameters
        ----------
        record : Dict[str, Any]
            Data to record, typically key-value pairs
        labels : List[str], optional
            Labels for categorizing the recorded data
            
        Raises
        ------
        RuntimeError
            If there is no active context for recording
            
        Notes
        -----
        - Data is recorded under the current active context
        - Multiple records can be added within a single context
        - Labels help organize and filter recorded data
        """
        # Record to Trace
        self._trace.add_record(record=record,save_to_file=self.save_to_file,labels=labels)
    
    
    def close(self) -> None:
        """
        Close the tracker system and release resources.
        
        Notes
        -----
        - Flushes any buffered data to file
        - Closes file handles and cleans up internal resources
        - Should be called when tracking is complete
        """
        self._trace.close()

    def exit_broken_context(self):
        """
        Exit a broken context (e.g., due to exception).
        
        Notes
        -----
        - Used when a context cannot be properly exited via normal flow
        - Marks the context as broken for later analysis
        - Helps maintain trace integrity during error conditions
        """
        self._trace.exit_broken_context()
