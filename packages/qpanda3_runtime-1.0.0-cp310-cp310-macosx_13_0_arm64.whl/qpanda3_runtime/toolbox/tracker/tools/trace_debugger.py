import json
from typing import Dict, Any, List, Optional, Set, Tuple
from collections import defaultdict, deque
import os


class TraceDebugger:
    """Debugging tool for analyzing tracker records and reconstructing hierarchy trees.
    
    This class provides comprehensive functionality for loading, analyzing,
    visualizing, and exporting tracker trace data stored in JSONL format.
    
    Features
    --------
    1. Loads records from .jsonl files
    2. Reconstructs hierarchy trees based on parent_id relationships
    3. Provides various display formats for hierarchy visualization
    4. Detects and reports issues in trace data
    5. Supports filtering and searching records
    6. Exports hierarchy trees to text files
    7. Analyzes data integrity and provides statistics
    
    Examples
    --------
    >>> debugger = TraceDebugger("trace.jsonl")
    >>> debugger.print_summary()
    >>> debugger.display_tree()
    >>> debugger.export_to_text("hierarchy.txt")
    
    Notes
    -----
    The trace file should be in JSONL format with each line containing
    a JSON object with 'id', 'parent_id', 'type', and 'data' fields.
    """

    def __init__(self, trace_file: Optional[str] = None):
        """Initialize the trace debugger.

        Parameters
        ----------
        trace_file : Optional[str], default=None
            Path to trace file (.jsonl format). Can be loaded later.
        """
        self.records = []  # List of all loaded records
        self.records_by_id = {}  # Mapping from ID to record
        self.children_by_parent = defaultdict(list)  # Mapping from parent ID to child records
        self.root_records = []  # Records with parent_id = 0

        if trace_file:
            self.load_trace_file(trace_file)

    def load_trace_file(self, trace_file: str) -> None:
        """Load tracker records from a JSONL trace file.
        
        This method reads a trace file in JSONL format, parses each line as JSON,
        validates the required fields, and builds internal data structures for
        efficient hierarchy traversal and analysis.
        
        Parameters
        ----------
        trace_file : str
            Path to trace file in JSONL format.
            
        Raises
        ------
        FileNotFoundError
            If the specified trace file does not exist.
        ValueError
            If the trace file contains invalid JSON or missing required fields.
            
        Notes
        -----
        Each line in the trace file should be a JSON object with the following
        required fields:
        - id: Unique integer identifier
        - parent_id: Integer identifier of parent record (0 for root records)
        - type: Record type string
        - data: Dictionary containing record-specific data
        
        After loading, the following internal structures are built:
        - records: List of all records
        - records_by_id: Dictionary mapping ID to record
        - children_by_parent: Dictionary mapping parent ID to list of child records
        - root_records: List of records with parent_id = 0
        """
        if not os.path.exists(trace_file):
            raise FileNotFoundError(f"Trace file not found: {trace_file}")

        self.records = []
        self.records_by_id = {}
        self.children_by_parent = defaultdict(list)
        self.root_records = []

        with open(trace_file, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue

                try:
                    record = json.loads(line)

                    # Ensure ID and parent_id are integers
                    record['id'] = int(record['id'])
                    record['parent_id'] = int(record['parent_id'])

                    self.records.append(record)
                    self.records_by_id[record['id']] = record

                    # Build parent-child relationships
                    self.children_by_parent[record['parent_id']].append(record)

                    # Identify root records
                    if record['parent_id'] == 0:
                        self.root_records.append(record)

                except (json.JSONDecodeError, KeyError, ValueError) as e:
                    raise ValueError(f"Error parsing line {line_num}: {e}\nLine: {line[:100]}...")

        print(f"Loaded {len(self.records)} records from {trace_file}")
        print(f"Found {len(self.root_records)} root records")

    def get_record(self, record_id: int) -> Optional[Dict[str, Any]]:
        """Get a record by its ID.

        Parameters
        ----------
        record_id : int
            Record ID to look up.

        Returns
        -------
        Optional[Dict[str, Any]]
            The record if found, None otherwise.
        """
        return self.records_by_id.get(record_id)

    def get_children(self, parent_id: int) -> List[Dict[str, Any]]:
        """Get all child records of a parent record.

        Parameters
        ----------
        parent_id : int
            Parent record ID.

        Returns
        -------
        List[Dict[str, Any]]
            List of child records.
        """
        return self.children_by_parent.get(parent_id, [])

    def get_ancestors(self, record_id: int) -> List[Dict[str, Any]]:
        """Get all ancestors of a record (from root to parent).

        Parameters
        ----------
        record_id : int
            Record ID to find ancestors for.

        Returns
        -------
        List[Dict[str, Any]]
            List of ancestor records, starting from root.
        """
        ancestors = []
        current_id = record_id

        while current_id in self.records_by_id:
            record = self.records_by_id[current_id]
            ancestors.insert(0, record)  # Insert at beginning to maintain order
            current_id = record['parent_id']
            if current_id == 0:
                break

        return ancestors

    def get_descendants(self, record_id: int) -> List[Dict[str, Any]]:
        """Get all descendants of a record (breadth-first).

        Parameters
        ----------
        record_id : int
            Record ID to find descendants for.

        Returns
        -------
        List[Dict[str, Any]]
            List of descendant records in breadth-first order.
        """
        descendants = []
        queue = deque([record_id])

        while queue:
            current_id = queue.popleft()
            children = self.get_children(current_id)

            for child in children:
                descendants.append(child)
                queue.append(child['id'])

        return descendants

    def display_tree(self,
                     root_id: int = 0,
                     max_depth: Optional[int] = None,
                     show_data: bool = False,
                     indent_size: int = 2) -> None:
        """Display hierarchy tree with indentation.
        
        This method prints a visual representation of the record hierarchy
        using ASCII art for tree structure visualization.
        
        Parameters
        ----------
        root_id : int, default=0
            Root record ID to start display from. Use 0 to display all
            root trees (records with parent_id = 0).
        max_depth : Optional[int], default=None
            Maximum depth to display. If None, displays the entire tree.
        show_data : bool, default=False
            Whether to show record data summaries. When True, includes
            key information from the data field.
        indent_size : int, default=2
            Number of spaces per indentation level for tree visualization.
            
        Notes
        -----
        The tree display uses the following symbols:
        - ├─ : Branch connector (has siblings below)
        - └─ : Last child connector
        - [id] : Record ID in brackets
        - type : Record type
        
        When show_data=True, a summary of the data field is shown after
        the record type, truncated for readability.
        
        Examples
        --------
        >>> # Display all root trees
        >>> debugger.display_tree()
        >>> 
        >>> # Display specific tree with data
        >>> debugger.display_tree(root_id=123, show_data=True)
        >>> 
        >>> # Display with depth limit
        >>> debugger.display_tree(max_depth=3)
        """
        if root_id == 0:
            # Display all root trees
            for root_record in self.root_records:
                print(f"\n=== Root Tree (ID: {root_record['id']}) ===")
                self._display_subtree(root_record['id'], 0, max_depth, show_data, indent_size)
        elif root_id in self.records_by_id:
            # Display specific tree
            print(f"\n=== Tree for Record {root_id} ===")
            self._display_subtree(root_id, 0, max_depth, show_data, indent_size)
        else:
            print(f"Record {root_id} not found")

    def _display_subtree(self,
                         current_id: int,
                         depth: int,
                         max_depth: Optional[int],
                         show_data: bool,
                         indent_size: int) -> None:
        """Recursively display a subtree.

        Parameters
        ----------
        current_id : int
            Current record ID.
        depth : int
            Current depth in tree.
        max_depth : Optional[int]
            Maximum depth to display.
        show_data : bool
            Whether to show record data.
        indent_size : int
            Number of spaces per indentation level.
        """
        if max_depth is not None and depth > max_depth:
            return

        record = self.records_by_id.get(current_id)
        if not record:
            return

        # Create indentation
        indent = " " * (depth * indent_size)

        # Display current record
        line = f"{indent}├─ [{record['id']}] {record['type']}"

        if show_data:
            # Show simplified data
            data_summary = self._summarize_data(record['data'])
            if data_summary:
                line += f" - {data_summary}"

        # Add timestamp if available
        if 'timestamp' in record:
            # Extract just the time part for brevity
            timestamp = record['timestamp']
            if 'T' in timestamp:
                time_part = timestamp.split('T')[1].split('.')[0]
                line += f" ({time_part})"

        print(line)

        # Recursively display children
        children = self.get_children(current_id)
        for i, child in enumerate(children):
            # Use different prefix for last child
            if i == len(children) - 1:
                prefix = "└─"
            else:
                prefix = "├─"

            child_indent = " " * (depth * indent_size) + prefix
            self._display_subtree(child['id'], depth + 1, max_depth, show_data, indent_size)

    def _summarize_data(self, data: Dict[str, Any]) -> str:
        """Create a summary string from record data.

        Parameters
        ----------
        data : Dict[str, Any]
            Record data dictionary.

        Returns
        -------
        str
            Summary string.
        """
        summary_parts = []

        # Common fields to summarize
        common_fields = ['message', 'metric_name', 'event_name', 'context_name',
                         'error_code', 'warning_code']

        for field in common_fields:
            if field in data:
                value = data[field]
                if isinstance(value, str):
                    # Truncate long strings
                    if len(value) > 30:
                        value = value[:27] + "..."
                    summary_parts.append(f"{field}: {value}")
                else:
                    summary_parts.append(f"{field}: {value}")
                break  # Only show first matching field

        # Add result for context end
        if 'result' in data:
            summary_parts.append(f"result: {data['result']}")

        # Add metric value if present
        if 'metric_value' in data and 'metric_unit' in data:
            summary_parts.append(f"{data['metric_value']} {data['metric_unit']}")
        elif 'metric_value' in data:
            summary_parts.append(f"value: {data['metric_value']}")

        return ", ".join(summary_parts)

    def display_context_tree(self,
                             show_incomplete: bool = True,
                             show_data: bool = True) -> None:
        """Display context hierarchy with special formatting for contexts.
        
        This method provides a specialized view focused on context records
        (CONTEXT_START and CONTEXT_END), showing their relationships and
        completeness status.
        
        Parameters
        ----------
        show_incomplete : bool, default=True
            Whether to highlight incomplete contexts (CONTEXT_START without
            matching CONTEXT_END). Incomplete contexts are marked with a
            warning symbol.
        show_data : bool, default=True
            Whether to show record data summaries for context records.
            
        Notes
        -----
        Contexts are displayed with status indicators:
        - ✓ : Complete context (has both START and END)
        - ✗ : Incomplete context (missing END)
        - ⚠ : Incomplete context when show_incomplete=True
        
        For each context, the method shows:
        1. Context name (from data['context_name'] or generated)
        2. Context ID
        3. Start data summary (if show_data=True)
        4. End data summary (if complete and show_data=True)
        5. Context contents (direct children)
        
        Examples
        --------
        >>> # Display all contexts
        >>> debugger.display_context_tree()
        >>> 
        >>> # Display contexts without highlighting incomplete ones
        >>> debugger.display_context_tree(show_incomplete=False)
        >>> 
        >>> # Display contexts without data
        >>> debugger.display_context_tree(show_data=False)
        """
        print("\n=== Context Hierarchy ===")

        # Find all context start records
        context_starts = []
        context_ends = set()

        for record in self.records:
            if record['type'] == 'CONTEXT_START':
                context_starts.append(record)
            elif record['type'] == 'CONTEXT_END':
                context_ends.add(record['parent_id'])

        print(f"Total contexts: {len(context_starts)}")

        for context_start in context_starts:
            context_id = context_start['id']
            is_complete = context_id in context_ends

            # Context status indicator
            status = "✓" if is_complete else "✗"
            if not is_complete and show_incomplete:
                status = "⚠"  # Warning for incomplete

            context_name = context_start['data'].get('context_name', f"Context_{context_id}")
            print(f"\n{status} Context: {context_name} (ID: {context_id})")

            if show_data:
                data_summary = self._summarize_data(context_start['data'])
                if data_summary:
                    print(f"   Start: {data_summary}")

            # Find context end record
            if is_complete:
                for record in self.records:
                    if record['type'] == 'CONTEXT_END' and record['parent_id'] == context_id:
                        data_summary = self._summarize_data(record['data'])
                        if data_summary:
                            print(f"   End: {data_summary}")

            # Display context contents
            self._display_context_contents(context_id, is_complete, show_data)

    def _display_context_contents(self,
                                  context_id: int,
                                  is_complete: bool,
                                  show_data: bool,
                                  indent: int = 3) -> None:
        """Display contents of a context.

        Parameters
        ----------
        context_id : int
            Context record ID.
        is_complete : bool
            Whether context is complete.
        show_data : bool
            Whether to show record data.
        indent : int, default=3
            Indentation level.
        """
        # Get direct children (excluding context end)
        children = self.get_children(context_id)

        # Filter out context end record
        children = [child for child in children if child['type'] != 'CONTEXT_END']

        if not children:
            print(" " * indent + "(empty)")
            return

        for child in children:
            indent_str = " " * indent
            line = f"{indent_str}• {child['type']}"

            if show_data:
                data_summary = self._summarize_data(child['data'])
                if data_summary:
                    line += f": {data_summary}"

            print(line)

            # Recursively show grandchildren
            grandchildren = self.get_children(child['id'])
            for grandchild in grandchildren:
                sub_indent = indent + 2
                sub_indent_str = " " * sub_indent
                sub_line = f"{sub_indent_str}◦ {grandchild['type']}"

                if show_data:
                    data_summary = self._summarize_data(grandchild['data'])
                    if data_summary:
                        sub_line += f": {data_summary}"

                print(sub_line)

    def find_records(self,
                     record_type: Optional[str] = None,
                     search_text: Optional[str] = None,
                     parent_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """Find records matching specified criteria.
        
        This method provides flexible filtering capabilities to search for
        records based on type, text content, and parent-child relationships.
        
        Parameters
        ----------
        record_type : Optional[str], default=None
            Record type to filter by (e.g., 'CONTEXT_START', 'METRIC', 'EVENT').
            If None, all record types are included.
        search_text : Optional[str], default=None
            Text to search for in record data. The search is case-insensitive
            and looks in both the record type and data fields.
        parent_id : Optional[int], default=None
            Parent record ID to filter by. If None, records with any parent
            are included. Use 0 to find root records.
            
        Returns
        -------
        List[Dict[str, Any]]
            List of matching records in the order they appear in the trace.
            
        Notes
        -----
        When multiple filters are provided, records must match all criteria
        to be included in the results.
        
        The text search looks for matches in:
        - Record type (case-insensitive)
        - String values in the data dictionary (case-insensitive)
        - Numeric values converted to string (exact match)
        
        Examples
        --------
        >>> # Find all CONTEXT_START records
        >>> contexts = debugger.find_records(record_type='CONTEXT_START')
        >>> 
        >>> # Find records containing "error" in their data
        >>> errors = debugger.find_records(search_text='error')
        >>> 
        >>> # Find children of a specific parent
        >>> children = debugger.find_records(parent_id=123)
        """
        results = []

        for record in self.records:
            # Filter by type
            if record_type and record['type'] != record_type:
                continue

            # Filter by parent ID
            if parent_id is not None and record['parent_id'] != parent_id:
                continue

            # Filter by search text
            if search_text:
                text_found = False

                # Search in type
                if search_text.lower() in record['type'].lower():
                    text_found = True

                # Search in data
                if not text_found:
                    for key, value in record['data'].items():
                        if isinstance(value, str) and search_text.lower() in value.lower():
                            text_found = True
                            break
                        elif isinstance(value, (int, float)) and str(value) == search_text:
                            text_found = True
                            break

                if not text_found:
                    continue

            results.append(record)

        return results

    def analyze_integrity(self) -> Dict[str, Any]:
        """Analyze trace data integrity and report potential issues.
        
        This method performs comprehensive integrity checks on the loaded
        trace data, including validation of parent-child relationships,
        context completeness, and data consistency.
        
        Returns
        -------
        Dict[str, Any]
            Dictionary containing analysis results with the following keys:
            - total_records: Total number of loaded records
            - root_records: Number of root records (parent_id = 0)
            - statistics: Dictionary of record counts by type
            - issues: List of detected issues
            - has_issues: Boolean indicating if any issues were found
            
        Notes
        -----
        The following checks are performed:
        1. Missing parent records (references to non-existent parents)
        2. Incomplete contexts (CONTEXT_START without CONTEXT_END)
        3. Cycles in parent-child relationships
        4. Duplicate record IDs
        
        Each issue in the 'issues' list contains:
        - type: Issue category (e.g., 'missing_parents', 'incomplete_contexts')
        - message: Human-readable description
        - details: List of relevant IDs or additional information
        """
        issues = []
        statistics = defaultdict(int)

        # Count records by type
        for record in self.records:
            statistics[record['type']] += 1

        # Check for missing parent records
        missing_parents = set()
        for record in self.records:
            parent_id = record['parent_id']
            if parent_id != 0 and parent_id not in self.records_by_id:
                missing_parents.add(parent_id)

        if missing_parents:
            issues.append({
                'type': 'missing_parents',
                'message': f"Found {len(missing_parents)} records referencing missing parents",
                'details': list(missing_parents)[:10]  # Show first 10
            })

        # Check for incomplete contexts
        context_starts = set()
        context_ends = set()

        for record in self.records:
            if record['type'] == 'CONTEXT_START':
                context_starts.add(record['id'])
            elif record['type'] == 'CONTEXT_END':
                context_ends.add(record['parent_id'])

        incomplete_contexts = context_starts - context_ends
        if incomplete_contexts:
            issues.append({
                'type': 'incomplete_contexts',
                'message': f"Found {len(incomplete_contexts)} incomplete contexts",
                'details': list(incomplete_contexts)[:10]
            })

        # Check for cycles (should not happen with stack-based tracking)
        # Simple check: ensure no record is its own ancestor
        for record in self.records:
            ancestors = self.get_ancestors(record['id'])
            ancestor_ids = [a['id'] for a in ancestors]
            if record['id'] in ancestor_ids:
                issues.append({
                    'type': 'cycle_detected',
                    'message': f"Cycle detected involving record {record['id']}",
                    'details': [record['id']]
                })
                break

        # Check for duplicate IDs (should not happen)
        id_counts = defaultdict(int)
        for record in self.records:
            id_counts[record['id']] += 1

        duplicate_ids = [id for id, count in id_counts.items() if count > 1]
        if duplicate_ids:
            issues.append({
                'type': 'duplicate_ids',
                'message': f"Found {len(duplicate_ids)} duplicate IDs",
                'details': duplicate_ids[:10]
            })

        return {
            'total_records': len(self.records),
            'root_records': len(self.root_records),
            'statistics': dict(statistics),
            'issues': issues,
            'has_issues': len(issues) > 0
        }

    def print_summary(self) -> None:
        """Print a comprehensive summary of loaded trace data.
        
        This method displays a formatted summary including record counts,
        type statistics, and integrity analysis results.
        
        Notes
        -----
        The summary includes:
        1. Total number of records
        2. Number of root records
        3. Record type statistics (sorted by count)
        4. Integrity issues (if any)
        
        If no records are loaded, a message is printed indicating this.
        
        Examples
        --------
        >>> debugger.print_summary()
        === Trace Data Summary ===
        Total records: 150
        Root records: 3
        
        Record type statistics:
          METRIC: 75
          EVENT: 50
          CONTEXT_START: 15
          CONTEXT_END: 10
        
        ✓ No integrity issues found
        """
        if not self.records:
            print("No records loaded")
            return

        analysis = self.analyze_integrity()

        print("\n=== Trace Data Summary ===")
        print(f"Total records: {analysis['total_records']}")
        print(f"Root records: {analysis['root_records']}")

        print("\nRecord type statistics:")
        for record_type, count in sorted(analysis['statistics'].items(),
                                         key=lambda x: x[1], reverse=True):
            print(f"  {record_type}: {count}")

        if analysis['has_issues']:
            print("\n⚠ Issues found:")
            for issue in analysis['issues']:
                print(f"  • {issue['message']}")
                if 'details' in issue and issue['details']:
                    details_str = ", ".join(str(d) for d in issue['details'][:5])
                    if len(issue['details']) > 5:
                        details_str += f", ... (+{len(issue['details']) - 5} more)"
                    print(f"    Details: {details_str}")
        else:
            print("\n✓ No integrity issues found")

    def export_to_text(self,
                       output_file: str,
                       root_id: int = 0,
                       max_depth: Optional[int] = None,
                       show_data: bool = True) -> None:
        """Export hierarchy tree to a text file.
        
        This method saves the visual tree representation to a text file,
        useful for documentation, sharing, or offline analysis.
        
        Parameters
        ----------
        output_file : str
            Path to output text file. The file will be created or overwritten.
        root_id : int, default=0
            Root record ID to start from. Use 0 to export all root trees.
        max_depth : Optional[int], default=None
            Maximum depth to export. If None, exports the entire tree.
        show_data : bool, default=True
            Whether to include record data summaries in the export.
            
        Notes
        -----
        The exported file contains the same visual representation as
        displayed by the `display_tree` method, including ASCII art
        for tree structure.
        
        The output is UTF-8 encoded and includes a header with export
        information.
        
        Examples
        --------
        >>> # Export all trees to a file
        >>> debugger.export_to_text("hierarchy.txt")
        >>> 
        >>> # Export specific tree without data
        >>> debugger.export_to_text("tree_123.txt", root_id=123, show_data=False)
        >>> 
        >>> # Export with depth limit
        >>> debugger.export_to_text("shallow.txt", max_depth=2)
        """
        import sys
        from io import StringIO

        # Redirect stdout to capture output
        old_stdout = sys.stdout
        sys.stdout = StringIO()

        try:
            self.display_tree(root_id, max_depth, show_data)
            output = sys.stdout.getvalue()
        finally:
            sys.stdout = old_stdout

        # Write to file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"Trace Hierarchy Export\n")
            f.write(f"======================\n\n")
            f.write(output)

        print(f"Exported hierarchy to {output_file}")

    def get_hierarchy_stats(self) -> Dict[str, Any]:
        """Get hierarchy statistics for the loaded trace data.
        
        This method calculates various statistics about the hierarchy
        structure, useful for understanding the complexity and shape
        of the trace data.
        
        Returns
        -------
        Dict[str, Any]
            Dictionary containing the following hierarchy statistics:
            - max_depth: Maximum depth of the hierarchy (root = depth 0)
            - avg_children_per_parent: Average number of children per parent node
            - max_children: Maximum number of children for any parent
            - leaf_nodes: Number of leaf nodes (nodes with no children)
            - branch_nodes: Number of branch nodes (nodes with children)
            
        Notes
        -----
        Root records (parent_id = 0) are not counted as leaf or branch nodes
        since they are not part of the parent-child hierarchy for statistics
        purposes.
        
        The statistics are calculated using breadth-first traversal to
        ensure accurate depth calculations.
        
        Examples
        --------
        >>> stats = debugger.get_hierarchy_stats()
        >>> print(f"Max depth: {stats['max_depth']}")
        >>> print(f"Leaf nodes: {stats['leaf_nodes']}")
        >>> print(f"Branch nodes: {stats['branch_nodes']}")
        """
        stats = {
            'max_depth': 0,
            'avg_children_per_parent': 0,
            'max_children': 0,
            'leaf_nodes': 0,
            'branch_nodes': 0
        }

        if not self.records:
            return stats

        # Calculate depths and child counts
        depths = {}
        child_counts = {}

        # Start with root records
        queue = deque([(0, 0)])  # (parent_id, depth)

        while queue:
            parent_id, depth = queue.popleft()
            children = self.get_children(parent_id)

            if parent_id != 0:
                depths[parent_id] = depth

            if children:
                child_counts[parent_id] = len(children)
                stats['branch_nodes'] += 1

                for child in children:
                    queue.append((child['id'], depth + 1))
            else:
                if parent_id != 0:
                    stats['leaf_nodes'] += 1

        if depths:
            stats['max_depth'] = max(depths.values())

        if child_counts:
            stats['avg_children_per_parent'] = sum(child_counts.values()) / len(child_counts)
            stats['max_children'] = max(child_counts.values())

        return stats


