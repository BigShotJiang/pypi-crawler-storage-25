from ast import Str
import time
import json
from tkinter import NO
from typing import Dict, Any, List,Union, Optional
from datetime import datetime
from enum import Enum
from dataclasses import dataclass
import asyncio
from threading import Lock
from collections import deque
import os

class TraceRowIdManager:
    """
    Manager for generating unique IDs for trace rows.
    
    This class provides thread-safe and async-safe ID generation for
    tracking trace rows. It maintains a counter that increments with
    each ID request.
    
    Attributes
    ----------
    current_id : int
        Current ID counter value
    _lock : threading.Lock
        Thread lock for synchronous operations
    _async_lock : asyncio.Lock
        Async lock for asynchronous operations
    """
    def __init__(self) -> None:
        """
        Initialize the trace row ID manager.
        
        Notes
        -----
        - Initial ID is set to -1, first call returns 0
        - Uses both thread and async locks for concurrency safety
        """
        self.current_id = -1
        # Use thread lock for concurrency safety
        self._lock = Lock()
        self._async_lock = asyncio.Lock()

    def get_next_id(self) -> int:
        """
        Get next unique ID (thread-safe).
        
        Returns
        -------
        int
            Next unique ID
            
        Notes
        -----
        - Thread-safe using threading.Lock
        - IDs are monotonically increasing
        """
        with self._lock:
            self.current_id += 1
            return self.current_id
    
    async def get_next_id_async(self) -> int:
        """
        Get next unique ID (async-safe).
        
        Returns
        -------
        int
            Next unique ID
            
        Notes
        -----
        - Async-safe using asyncio.Lock
        - Suitable for async/await contexts
        """
        async with self._async_lock:
            self.current_id += 1
            return self.current_id
        return self.current_id

    def reset_current_id(self,id:int):
        """
        Reset the current ID counter.
        
        Parameters
        ----------
        id : int
            New value for current_id
            
        Notes
        -----
        - Use with caution as it affects ID generation
        - Typically used for testing or special scenarios
        """
        self.current_id = id

class TraceRowType(str,Enum):
    """
    Enumeration of trace row types.
    
    Defines the possible types of rows in a tracking trace.
    
    Attributes
    ----------
    CONTEXT_START : str
        Marks the beginning of a tracking context
    CONTEXT_END : str
        Marks the end of a tracking context
    DATA : str
        Represents data recorded within a context
    """
    CONTEXT_START = "CONTEXT_START"
    CONTEXT_END = "CONTEXT_END"
    DATA = "DATA"

@dataclass
class TraceRow:
    """
    Data structure for a tracking record row.
    
    Represents a single row in a tracking trace with metadata and payload data.
    
    Attributes
    ----------
    row_id : int
        Numeric identifier for the row
    row_type : TraceRowType
        Type of the row (context start, context end, or data)
    row_parent_id : int
        Numeric identifier of parent row for hierarchical relationships
    data : Dict[str, Any]
        Payload data associated with the row
    labels : List[str]
        Categorization labels for filtering and analysis
    timestamp : str
        ISO 8601 timestamp of when the row was created
    """

    row_id: int  # Numeric ID
    row_type: TraceRowType  # Record type identifier
    row_parent_id: int  # Numeric parent ID
    data: Dict[str, Any]  # Record data payload
    labels:List[str] # Label list
    timestamp: str =datetime.now().isoformat() # ISO 8601 timestamp

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert the record to dictionary format.
        
        Returns
        -------
        Dict[str, Any]
            Dictionary representation of the record.
            
        Notes
        -----
        - Used for serialization and storage
        - Maintains all original field names and values
        """
        return {
            'row_id': self.row_id,
            'row_type': self.row_type.value,
            'row_parent_id': self.row_parent_id,
            'data': self.data,
            'labels': self.labels,
            'timestamp': self.timestamp,
        }

    def to_json(self) -> str:
        """
        Convert the record to JSON string (single line).
        
        Returns
        -------
        str
            JSON string representation of the record.
            
        Notes
        -----
        - Uses compact JSON format without extra whitespace
        - Ensures ASCII characters are properly handled
        - Suitable for line-based storage in JSONL files
        """
        return json.dumps(self.to_dict(), ensure_ascii=False, separators=(',', ':'))

class TraceTreeNodeBase:
    """
    Base class for trace tree nodes.
    
    Represents a node in the hierarchical trace tree structure, which can
    contain either data rows or child context nodes.
    
    Attributes
    ----------
    is_data : bool
        Whether this node represents data (True) or context (False)
    start_row : TraceRow
        Starting row for context nodes, None for data nodes
    content : List[Union[TraceRow, TraceTreeNodeBase]]
        Child elements (data rows or nested context nodes)
    end_row : TraceRow
        Ending row for context nodes, None for open contexts
    closed : bool
        Whether the context is closed (completed)
    labels : List[str]
        Categorization labels for the node
    row_id_manager : TraceRowIdManager
        Manager for generating unique row IDs
    """
    def __init__(self,row_id:Union[int,TraceRowIdManager],labels:List[str],closed: bool = False,is_data: bool = False) -> None:
        """
        Initialize a trace tree node.
        
        Parameters
        ----------
        row_id : Union[int, TraceRowIdManager]
            Either an integer ID or a TraceRowIdManager instance
        labels : List[str]
            Categorization labels for the node
        closed : bool, optional
            Whether the node is closed, default is False
        is_data : bool, optional
            Whether this is a data node, default is False
            
        Notes
        -----
        - If row_id is an integer, creates a new TraceRowIdManager with that ID
        - If row_id is a TraceRowIdManager, uses it directly for ID generation
        """
        self.is_data: bool = is_data
        self.start_row: TraceRow = None
        self.content: List[Union[TraceRow,TraceTreeNodeBase]] = []
        self.end_row: TraceRow = None
        self.closed: bool = closed
        self.labels: List[str] = labels
        
        # Handle row_id parameter: could be int or TraceRowIdManager
        if isinstance(row_id, int):
            # If int, create a new TraceRowIdManager
            self.row_id_manager = TraceRowIdManager()
            # Set initial ID
            self.row_id_manager.current_id = row_id
        else:
            # If TraceRowIdManager, use directly
            self.row_id_manager = row_id

    def id(self):
        """
        Get the node's ID.
        
        Returns
        -------
        int
            ID from the start_row
            
        Notes
        -----
        - Only valid for context nodes with start_row
        - Data nodes may not have an ID
        """
        return self.start_row.row_id

    def parent_id(self):
        """
        Get the parent node's ID.
        
        Returns
        -------
        int
            Parent ID from the start_row
            
        Notes
        -----
        - Represents hierarchical relationship in trace tree
        - Root node typically has parent_id of 0
        """
        return self.start_row.row_parent_id

    def set_parent_id(self,parent_id:int) -> None:
        """
        Set the parent node ID.
        
        Parameters
        ----------
        parent_id : int
            New parent ID value
            
        Notes
        -----
        - Updates the start_row's parent_id field
        - Affects hierarchical relationships in trace tree
        """
        self.start_row.row_parent_id = parent_id

    def set_node_id(self,node_id:int) -> None:
        """
        Set the node ID and update child relationships.
        
        Parameters
        ----------
        node_id : int
            New node ID value
            
        Notes
        -----
        - Updates the node's own ID in start_row
        - Updates parent_id of all child TraceRow objects
        - Recursively updates parent_id of child TraceTreeNodeBase objects
        """
        self.start_row.row_id = node_id
        for item in self.content:
            if isinstance(item,TraceRow):
                item.row_parent_id = node_id
            elif isinstance(item,TraceTreeNodeBase):
                item.set_parent_id(node_id)

    def set_labels(self,labels:List[str]) -> None:
        """
        Set the node's labels.
        
        Parameters
        ----------
        labels : List[str]
            New label list
            
        Notes
        -----
        - Overwrites existing labels
        - Labels are used for categorization and filtering
        """
        self.start_row.labels = labels

    def set_closed(self,closed: bool = True) -> None:
        """
        Set the node's closed status.
        
        Parameters
        ----------
        closed : bool, optional
            New closed status, default is True
            
        Notes
        -----
        - Closed nodes represent completed contexts
        - Open nodes represent ongoing operations
        """
        self.closed = closed

    def is_closed(self) -> bool:
        """
        Check if the node is closed.
        
        Returns
        -------
        bool
            True if node is closed, False otherwise
            
        Notes
        -----
        - Closed status indicates context completion
        - Data nodes are typically always closed
        """
        return self.closed

    def to_trace_rows(self) -> List[TraceRow]:
        """
        Convert node and descendants to flat list of trace rows.
        
        Returns
        -------
        List[TraceRow]
            Flat list of all trace rows in this node and its descendants
            
        Notes
        -----
        - Recursively processes child nodes
        - Maintains hierarchical order (parent before children)
        - Includes start_row, content rows, and end_row if present
        """
        rows = [self.start_row]
        for item in self.content:
            if isinstance(item,TraceRow):
                rows.append(item)
            elif isinstance(item,TraceTreeNodeBase):
                rows.extend(item.to_trace_rows())
        
        if self.end_row is not None:
            rows.append(self.end_row)
        return rows

    def timestamp(self):
        """
        Get the node's timestamp.
        
        Returns
        -------
        str
            ISO 8601 timestamp from start_row
            
        Notes
        -----
        - Represents when the context started
        - Used for chronological ordering
        """
        return self.start_row.timestamp

    def order_by_row_id(self):
        """
        Sort content by row ID.
        
        Recursively sorts child TraceTreeNodeBase elements and then sorts
        the content list by row ID.
        
        Notes
        -----
        - Recursively processes child TraceTreeNodeBase elements first
        - Uses row_id for TraceRow elements and id() for TraceTreeNodeBase
        - Results in chronological order based on ID assignment
        """
        # First recursively process all TraceTreeNodeBase child elements
        for item in self.content:
            if isinstance(item, TraceTreeNodeBase):
                item.order_by_timestamp()
        
        def get_row_id(item):
            if isinstance(item,TraceRow):
                return item.row_id
            elif isinstance(item, TraceTreeNodeBase):
                return item.id()
            else:
                raise TypeError("item should be TraceRow or TraceTreeNodeBase")
        
        self.content.sort(key=get_row_id)

    def order_by_timestamp(self):
        """
        Sort content by timestamp.
        
        Recursively sorts child TraceTreeNodeBase elements and then sorts
        the content list by timestamp.
        
        Notes
        -----
        - Recursively processes child TraceTreeNodeBase elements first
        - Uses timestamp for TraceRow elements and timestamp() for TraceTreeNodeBase
        - Results in chronological order based on actual timing
        """
        # First recursively process all TraceTreeNodeBase child elements
        for item in self.content:
            if isinstance(item, TraceTreeNodeBase):
                item.order_by_timestamp()
        
        def get_timestamp(item):
            if isinstance(item,TraceRow):
                return item.timestamp
            elif isinstance(item, TraceTreeNodeBase):
                return item.timestamp()
            else:
                raise TypeError("item should be TraceRow or TraceTreeNodeBase")
        
        # Sort by timestamp
        self.content.sort(key=get_timestamp)



class TraceTreeContextNode(TraceTreeNodeBase):
    """
    Context node for trace tree structure.
    
    Specialized node type for representing tracking contexts with
    start and end markers, and containing data records or nested contexts.
    
    Attributes
    ----------
    Inherits all attributes from TraceTreeNodeBase
    
    Examples
    --------
    >>> node = TraceTreeContextNode(1, 0, "quantum_circuit", ["simulation"])
    >>> data_row = node.add_data({"qubits": 5})
    >>> node.start_context()
    """
    def __init__(self
        ,row_id:Union[int,TraceRowIdManager]
        ,parent_id:int
        ,node_name:str
        ,labels:List[str]
        ,closed: bool = False
        ,start_row:TraceRow = None) -> None:
        """
        Initialize a trace tree context node.
        
        Parameters
        ----------
        row_id : Union[int, TraceRowIdManager]
            Either an integer ID or a TraceRowIdManager instance
        parent_id : int
            ID of parent node in trace hierarchy
        node_name : str
            Name identifier for this context
        labels : List[str]
            Categorization labels for the context
        closed : bool, optional
            Whether the context is closed, default is False
        start_row : TraceRow, optional
            Pre-existing start row, if None creates new
            
        Notes
        -----
        - Creates a CONTEXT_START TraceRow if start_row is not provided
        - Sets is_data=False to indicate this is a context node
        """
        super().__init__(row_id,labels,closed=False,is_data=False)
        if start_row is not None:
            self.start_row = start_row
        else:
            self.start_row: TraceRow = TraceRow(
                row_id=row_id if isinstance(row_id, int) else row_id.get_next_id(),
                row_type=TraceRowType.CONTEXT_START,
                row_parent_id=parent_id,
                data={'node_name':node_name},
                labels=labels,
            )

    def add_data(self,data:Union[TraceRow,Dict[str, Any]],row_id:Union[int,None] = None,labels:List[str]=[]) -> TraceRow:
        """
        Add data record to the context.
        
        Parameters
        ----------
        data : Union[TraceRow, Dict[str, Any]]
            Either an existing TraceRow or a dictionary of data
        row_id : Union[int, None], optional
            Specific row ID to use, if None generates new ID
        labels : List[str], optional
            Categorization labels for the data
            
        Returns
        -------
        TraceRow
            The added or existing trace row
            
        Notes
        -----
        - If data is already a TraceRow, appends it directly
        - If data is a dict, creates a new DATA TraceRow
        - Sets parent_id to this context's ID for hierarchical relationship
        """
        if isinstance(data,TraceRow):
            self.content.append(data)
            return data

        new_row = TraceRow(
            row_id=row_id if row_id is not None else self.row_id_manager.get_next_id(),
            row_type=TraceRowType.DATA,
            row_parent_id=self.start_row.row_id,
            data=data,
            labels=labels,
        )
        self.content.append(new_row)
        return new_row

    def start_context(self) -> TraceRow:
        """
        Get the context start row.
        
        Returns
        -------
        TraceRow
            The CONTEXT_START row for this context
            
        Notes
        -----
        - Returns the row that marks the beginning of this context
        - Used for reference and debugging purposes
        """
        return self.start_row

    def add_child(self
        ,node_name:str
        ,labels:List[str]
        ,closed: bool = False,
        child_node: 'TraceTreeContextNode'=None) -> 'TraceTreeContextNode':
        """
        Add a child context node.
        
        Parameters
        ----------
        node_name : str
            Name identifier for the child context
        labels : List[str]
            Categorization labels for the child context
        closed : bool, optional
            Whether the child context is closed, default is False
        child_node : TraceTreeContextNode, optional
            Pre-existing child node to add
            
        Returns
        -------
        TraceTreeContextNode
            The added or existing child node
            
        Notes
        -----
        - If child_node is provided, appends it directly
        - Otherwise creates a new child context node
        - Sets parent-child relationship automatically
        """
        if child_node is not None:
            self.content.append(child_node)
            return child_node
        
        new_node = TraceTreeContextNode(
            row_id=self.row_id_manager,
            parent_id=self.start_row.row_id,
            node_name=node_name,
            labels=labels,
            closed=closed,
        )
        self.content.append(new_node)
        return new_node

    def end_context(self,data:Union[TraceRow,Dict[str, Any]],row_id:Union[int,None] = None,labels:List[str]=[]) -> TraceRow:
        """
        End the context with result data.
        
        Parameters
        ----------
        data : Union[TraceRow, Dict[str, Any]]
            Either an existing TraceRow or dictionary of result data
        row_id : Union[int, None], optional
            Specific row ID to use, if None generates new ID
        labels : List[str], optional
            Categorization labels for the end operation
            
        Returns
        -------
        TraceRow
            The CONTEXT_END row
            
        Notes
        -----
        - Creates a CONTEXT_END TraceRow to mark context completion
        - Sets the context as closed
        - Result data is recorded in the end row
        """
        if isinstance(data,TraceRow):
            self.end_row = TraceRow
        else:
            self.end_row = TraceRow(
                row_id=row_id if isinstance(row_id, int) else self.row_id_manager.get_next_id(),
                row_type=TraceRowType.CONTEXT_END,
                row_parent_id=self.start_row.row_id,
                data=data,
                labels=labels,
            )
        self.set_closed(True)
        return self.end_row

class TraceRecorder:
    """
    General hierarchical tracking recorder with numeric IDs and write buffer.

    Features:
    1. Uses numeric IDs (auto-increment integers), no string IDs
    2. Manages parent reference ID hierarchy using a stack
    3. Automatically generates numeric IDs and sets parent references
    4. Supports enter/exit level operations
    5. Users cannot customize ID generation
    6. Uses write buffer with queue (deque) for ordered writes
    7. When buffer reaches limit or immediate write is needed:
       - First write all buffer data to file
       - Then write the immediate record to file
    8. Supports tracking any type of information, not limited to state
    """

    def __init__(self,
                 output_file: Optional[str] = None,
                 buffer_size: int = 1000):
        """Initialize the tracking recorder.

        Parameters
        ----------
        output_file : Optional[str]
            Path to output file. None means no file output.
        start_id : int, default=1
            Starting ID for numeric ID generation.
        buffer_size : int, default=1000
            Size of write buffer. When buffer reaches this size,
            all buffered records are written to file.
        """
        self.output_file = output_file
        self.buffer_size = buffer_size



        # Write buffer: uses deque for ordered storage
        self.write_buffer = deque()


        # Open output file
        if output_file:
            if os.path.exists(output_file):
                self.file_handle = open(output_file,'at+',encoding='utf-8')
            else:
                os.makedirs(os.path.dirname(output_file) if os.path.dirname(output_file) else '.',exist_ok=True)
                self.file_handle = open(output_file, 'wt+', encoding='utf-8')
            self.file_handle.write('\n')
            self.file_handle.flush()
        else:
            self.file_handle = None

          


    def _write_buffer_to_file(self) -> None:
        """Write all records from buffer to file in order.

        Notes
        -----
        Uses FIFO order: records are written in the same order
        they were added to buffer.
        """
        if not self.file_handle or not self.write_buffer:
            return

        # Write all buffered records to file in order
        while self.write_buffer:
            row = self.write_buffer.popleft()
            json_str = row.to_json()
            self.file_handle.write(json_str + '\n')

        # Flush to ensure data persistence
        self.file_handle.flush()

    def _write_row_with_buffer_check(self,
                                     row: 'TraceRow',
                                     immediate: bool = False) -> None:
        """Write row with buffer management.

        Parameters
        ----------
        row : 'TraceRow'
            Record row to write.
        immediate : bool, default=False
            Whether to write immediately. If True:
            - First write all buffer data to file
            - Then write this row to file
        """
        # Check if we need to flush buffer
        if immediate:
            # For immediate write: flush buffer first, then write the row
            self._write_buffer_to_file()

            # Write the immediate row
            if self.file_handle:
                json_str = row.to_json()
                self.file_handle.write(json_str + '\n')
                self.file_handle.flush()
        else:
            print('TraceRecorder no immediate')
            # For buffered write: add to buffer
            self.write_buffer.append(row)

            # Check if buffer reached limit
            if len(self.write_buffer) >= self.buffer_size:
                self._write_buffer_to_file()



    def record(self,trace_row:'TraceRow',immediate: bool = False) -> None:
        """Record a trace row.

        Parameters
        ----------
        trace_row : 'TraceRow'
            Trace row to record.
        immediate : bool, default=False
            Whether to write immediately.
        """
        self._write_row_with_buffer_check(trace_row, immediate)

    

    def get_buffer_size(self) -> int:
        """Get current buffer size.

        Returns
        -------
        int
            Number of records currently in buffer.
        """
        return len(self.write_buffer)

    def is_buffer_empty(self) -> bool:
        """Check if buffer is empty.

        Returns
        -------
        bool
            True if buffer is empty, False otherwise.
        """
        return len(self.write_buffer) == 0

    def get_row_count(self) -> int:
        """Get total number of rows recorded.

        Returns
        -------
        int
            Total number of rows recorded.
        """
        # Simple implementation: return buffer size
        return len(self.write_buffer)

    def _get_timestamp(self) -> str:
        """Get current timestamp as ISO format string.

        Returns
        -------
        str
            Current timestamp in ISO format.
        """
        from datetime import datetime
        return datetime.now().isoformat()

    def flush(self) -> None:
        """Flush buffer to file and ensure data persistence."""
        self._write_buffer_to_file()

    def close(self) -> None:
        """Close the tracking recorder and release resources."""
        # Flush buffer before closing
        self.flush()

    
        # Write shutdown marker
        if self.file_handle:
            # Close file
            self.file_handle.close()
            self.file_handle = None


    def clear(self) -> None:
        """Clear all records and reset the recorder.

        Notes
        -----
        This method:
        1. Clears the write buffer
        2. Clears the record mapping
        3. Resets the ID counter
        4. Resets the parent stack
        5. Truncates the output file if it exists
        """
        # Clear buffer
        self.write_buffer.clear()

    

        # Truncate the output file
        if self.file_handle:
            self.file_handle.seek(0)
            self.file_handle.truncate()
            self.file_handle.flush()

    def __del__(self):
        """Destructor to ensure resource release."""
        try:
            if hasattr(self, 'file_handle') and self.file_handle:
                self.close()
        except:
            pass




class TrackerTrace:
    """
    Memory/historical data object for tracking traces.
    
    Main class for managing tracking trace data in memory, supporting
    hierarchical context management, data recording, and file persistence.
    
    Attributes
    ----------
    _trace_row_id_manager : TraceRowIdManager
        Manager for generating unique row IDs
    _records : TraceTreeContextNode
        Root node of the trace tree
    _context_stack : deque[TraceTreeContextNode]
        Stack for managing nested contexts
    _record_file_path : str
        Path to trace record file for persistence
    _recorder : TraceRecorder
        Recorder for writing trace data to file
    _broken_contexts : List[TraceTreeContextNode]
        List of contexts that were exited abnormally
        
    Examples
    --------
    >>> trace = TrackerTrace("trace.jsonl")
    >>> trace.begin_context("quantum_circuit", ["simulation"])
    >>> trace.add_record({"qubits": 5})
    >>> trace.end_context({"result": "success"})
    """
    
    def __init__(self,record_file_path:str,load_history_records: bool = True) -> None:
        """
        Initialize the tracker trace.
        
        Parameters
        ----------
        record_file_path : str
            Path to trace record file for persistence
        load_history_records : bool, optional
            Whether to load existing records from file, default is True
            
        Notes
        -----
        - Creates a root context node named "TrackerTrace"
        - Initializes with empty context stack containing root node
        - If load_history_records is True, loads existing data from file
        - Uses buffer size of 1000 for file recording
        """
        self._trace_row_id_manager = TraceRowIdManager()
        self._records: TraceTreeContextNode = None
        self._context_stack: deque[TraceTreeContextNode] = deque()
        self._record_file_path = record_file_path
        self._recorder = TraceRecorder(self._record_file_path,buffer_size=1000)
        self._broken_contexts: List[TraceTreeContextNode] = []
        
        self._records: TraceTreeContextNode = TraceTreeContextNode(
            row_id=self._trace_row_id_manager,
            parent_id=0,
            node_name="TrackerTrace",
            labels=[],
            closed=False,
        )
        self._context_stack.appendleft(self._records)

        if load_history_records:
            self._load_from_file(record_file_path)

        
        
        
        
        

    def get_current_context(self) -> TraceTreeContextNode:
        """
        Get the current active context.
        
        Returns
        -------
        TraceTreeContextNode
            Current context node from top of stack, or None if stack is empty
            
        Notes
        -----
        - Returns the most recently entered context
        - Used for adding records to the correct context
        - Root context is always available as fallback
        """
        if self._context_stack and len(self._context_stack) > 0:
            return self._context_stack[0]
        return None


    
    def add_record(self, record: Dict[str, Any], save_to_file: bool = False,labels:List[str]=[]) -> None:
        """
        Add a data record to the current context.
        
        Parameters
        ----------
        record : Dict[str, Any]
            Data to record as key-value pairs
        save_to_file : bool, optional
            Whether to save the record to file, default is False
        labels : List[str], optional
            Categorization labels for the record
            
        Raises
        ------
        RuntimeError
            If there is no current context (should not happen with root)
            
        Notes
        -----
        - Records are added to the current active context
        - File saving can be deferred for performance
        - Labels help with filtering and analysis
        """
        new_row = self.get_current_context().add_data(data=record,labels=labels)
        if save_to_file:
            # Record to file
            self._recorder.record(new_row,True)
    
    def begin_context(self, context_name: str
        , context_labels: List[str] = []
        ,context_data: Dict[str, Any] = None
        ,save_to_file: bool = False) -> None:
        """
        Begin a new nested context.
        
        Parameters
        ----------
        context_name : str
            Name identifier for the new context
        context_labels : List[str], optional
            Categorization labels for the context
        context_data : Dict[str, Any], optional
            Initial data associated with context start
        save_to_file : bool, optional
            Whether to save context start to file, default is False
            
        Notes
        -----
        - Creates a new context as child of current context
        - Pushes new context onto the context stack
        - Contexts can be nested arbitrarily deep
        - Each begin_context should have matching end_context
        """
        new_node = self.get_current_context().add_child(
            node_name=context_name,
            labels=context_labels,
            closed=False,
        )
        start_row = new_node.start_context()
        data_row = new_node.add_data(data=context_data)
        self._context_stack.appendleft(new_node)

        if save_to_file:
            self._recorder.record(start_row,True)
            self._recorder.record(data_row,True)
    
    def end_context(self, result_data:Dict[str,Any]=None,save_to_file: bool = False,labels:List[str]=[]) -> None:
        """
        End the current context.
        
        Parameters
        ----------
        result_data : Dict[str, Any], optional
            Result data to associate with context completion
        save_to_file : bool, optional
            Whether to save context end to file, default is False
        labels : List[str], optional
            Categorization labels for the end operation
            
        Raises
        ------
        RuntimeError
            If there is no context to end (stack underflow)
            
        Notes
        -----
        - Pops current context from the context stack
        - Marks context as closed with result data
        - Must match a previous begin_context call
        - Uses immediate file writing for context completion
        """
        end_row = self.get_current_context().end_context(data=result_data,labels=labels)
        self._context_stack.popleft()
        # Record to file
        if save_to_file:
            self._recorder.record(end_row,immediate=True)

    def exit_broken_context(self):
        """
        Exit a broken context (e.g., due to exception).
        
        Notes
        -----
        - Moves current context to broken_contexts list
        - Removes context from active stack
        - Used for error handling when normal end_context cannot be called
        - Broken contexts can be analyzed separately
        """
        self._broken_contexts.append(self._context_stack[-1])
        self._context_stack.popleft()
    
    def get_records(self) -> List[Dict[str, Any]]:
        """
        Get all trace records.
        
        Returns
        -------
        List[Dict[str, Any]]
            List of all trace records (currently returns root node)
            
        Notes
        -----
        - Currently returns the root trace tree node
        - Future implementation may flatten the hierarchy
        """
        return self._records
    
    def get_context_stack(self) -> List[Any]:
        """
        Get current context stack.
        
        Returns
        -------
        List[Any]
            Copy of current context stack as list
            
        Notes
        -----
        - Returns a copy to prevent external modification
        - Stack order: most recent context first (index 0)
        """
        return list(self._context_stack)

    def rebuild_context_stack(self):
        """
        Rebuild context stack from trace tree structure.
        
        Returns
        -------
        deque[TraceTreeContextNode]
            Rebuilt context stack
            
        Notes
        -----
        - Clears existing stack and rebuilds from trace tree
        - Only includes open (unclosed) contexts
        - Recursively processes nested contexts
        - Useful after loading trace data from file
        """
        self._context_stack.clear()
        def process_node(node):
            for data_node in node.content:
                if isinstance(data_node,TraceTreeNodeBase):
                    if data_node.is_closed() is False:
                        self._context_stack.appendleft(data_node)
                        process_node(data_node)
                        break
        if self._records and self._records.is_closed() is False:
            self._context_stack.appendleft(self._records)
            process_node(self._records)
        return self._context_stack

    def _load_from_file(self, file_path: str) -> None:
        """
        Load trace data from file.
        
        Parameters
        ----------
        file_path : str
            Path to trace file to load
            
        Raises
        ------
        FileNotFoundError
            If the trace file does not exist
        json.JSONDecodeError
            If the trace file contains invalid JSON
        RuntimeError
            If the trace file is corrupted (inconsistent hierarchy)
            
        Notes
        -----
        - Parses JSONL format (one JSON object per line)
        - Reconstructs trace tree hierarchy from flat records
        - Updates row ID manager with maximum ID found
        - Sorts records by timestamp after loading
        """
        rowid_node:Dict[int,TraceTreeContextNode] = {}
        other_rows:List[TraceRow] = []
        max_row_id = -1
        # Load data
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        row_data = json.loads(line.strip())
                        row = TraceRow(
                            row_id=row_data['row_id'],
                            row_type=TraceRowType(row_data['row_type']),
                            row_parent_id=row_data['row_parent_id'],
                            data=row_data['data'],
                            labels=row_data['labels'],
                            timestamp=row_data['timestamp']
                        )
                        if row.row_id > max_row_id:
                            max_row_id = row.row_id
                        if row.row_type == TraceRowType.CONTEXT_START:
                            rowid_node[row.row_id]= TraceTreeContextNode(
                                row_id=self._trace_row_id_manager,
                                parent_id=-1,
                                node_name='',
                                labels=[],
                                start_row=row
                            )
                        else:
                            other_rows.append(row)                        
        except Exception as e:
            print(f"加载文件失败: {e}")
        # Reset row_id_manager
        self._trace_row_id_manager.reset_current_id(max_row_id)
        # Rebuild tree
        for row in other_rows:
            node = rowid_node[row.row_parent_id]
            if row.row_type == TraceRowType.DATA:
                node.add_data(row)
            else:
                node.end_context(row)
        for id,node in rowid_node.items():
            parent_id = node.parent_id()
            if id == 0:
                continue
            elif parent_id == 0:
                self._records.add_child('',[],child_node=node)
            elif rowid_node.get(parent_id) != None:
                rowid_node[parent_id].add_child('',[],child_node=node)
            else:
                raise RuntimeError(f"TrackerTrace文件{file_path}损坏")
        self._records.order_by_timestamp()
    
    def clear(self,clear_record_file: bool = True) -> None:
        """
        Clear all trace data.
        
        Parameters
        ----------
        clear_record_file : bool, optional
            Whether to also clear the record file, default is True
            
        Notes
        -----
        - Resets in-memory trace data structures
        - Optionally clears the persistent record file
        - Maintains the root context node structure
        """
        self._records = []
        self._context_stack.clear()
        if clear_record_file:
            self._recorder.clear()

    def close(self) -> None:
        """
        Close the trace and release resources.
        
        Notes
        -----
        - Closes the file recorder
        - Flushes any buffered data to disk
        - Should be called when trace operations are complete
        """
        self._recorder.close()
