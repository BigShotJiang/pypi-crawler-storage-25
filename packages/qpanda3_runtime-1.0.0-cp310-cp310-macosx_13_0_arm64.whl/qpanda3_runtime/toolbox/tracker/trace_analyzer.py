from typing import List, Any

from .tracking_rule import TrackingRules,TrackingRule
from .tracker_trace import TrackerTrace
from .tracking_rules import DefaultTrackingRule,QTaskFailureRule


class TraceAnalyzer:
    """
    Trace data analyzer for rule-based analysis of tracking traces.
    
    This class provides analysis capabilities for tracking trace files using
    registered analysis rules. It supports automatic rule selection and
    manual rule specification.
    
    Attributes
    ----------
    _rules : TrackingRules
        Manager for tracking analysis rules
    _trace : TrackerTrace
        Currently loaded trace data for analysis
        
    Examples
    --------
    >>> analyzer = TraceAnalyzer()
    >>> result = analyzer.analyze_file("trace.jsonl")
    >>> available_rules = analyzer.get_available_rules()
    """
    
    def __init__(self):
        """
        Initialize the trace analyzer with default rules.
        
        Notes
        -----
        - Registers default tracking rule and QTask failure rule
        - Additional rules can be registered using register_rule()
        """
        self._rules = TrackingRules(DefaultTrackingRule())
        self._rules.register_rule(QTaskFailureRule())
    
    def analyze_file(self, file_path: str, rule_id: str = None) -> Any:
        """
        Analyze historical trace file using specified or automatic rule.
        
        Parameters
        ----------
        file_path : str
            Path to the trace file to analyze
        rule_id : str, optional
            ID of the rule to use for analysis. If None, automatic rule
            selection is performed based on default rule.
            
        Returns
        -------
        Any
            Analysis result, format depends on the rule used
            
        Raises
        ------
        FileNotFoundError
            If the specified trace file does not exist
        ValueError
            If the specified rule_id is not registered
            
        Notes
        -----
        - Trace files are loaded with history records enabled
        - Analysis results are printed to console for debugging
        """
        # Load file data
        self._trace = TrackerTrace(file_path,load_history_records=True)
        
        # Get rule
        if rule_id:
            rule = self._rules.get_rule(rule_id)
        else:
            # Simplified implementation, actual should be data-driven
            rule = self._rules.get_default_rule()
        
        # Analyze data
        result = rule.analyze(self._trace)
        
        print(f"[{self.__class__.__name__}] Using rule '{rule.rule_id}' to analyze file: {file_path}")
        print(f"Analysis result: {result}")
        
        return result
    
    def get_available_rules(self) -> List[str]:
        """
        Get list of available analysis rule IDs.
        
        Returns
        -------
        List[str]
            List of registered rule IDs
            
        Examples
        --------
        >>> analyzer = TraceAnalyzer()
        >>> rules = analyzer.get_available_rules()
        >>> print(rules)
        ['default', 'qtask_failure']
        """
        return self._rules.get_available_rules()
    
    def register_rule(self, rule: TrackingRule) -> None:
        """
        Register a new analysis rule.
        
        Parameters
        ----------
        rule : TrackingRule
            Rule instance to register
            
        Notes
        -----
        - Registered rules become available for analyze_file()
        - Rules must have unique rule_id values
        """
        self._rules.register_rule(rule)
