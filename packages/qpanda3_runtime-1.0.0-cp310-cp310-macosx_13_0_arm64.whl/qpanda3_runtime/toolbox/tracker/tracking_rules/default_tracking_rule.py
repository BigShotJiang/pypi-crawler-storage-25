from ..tracking_rule import TrackingRule
from ..tracker_trace import TrackerTrace
from typing import Any

class DefaultTrackingRule(TrackingRule):
    """Default tracking rule - passes data through unchanged.
    
    This rule implements the simplest tracking behavior where data is
    returned unchanged without any processing or transformation.
    
    Notes
    -----
    Use this rule as a baseline or when no special processing is needed.
    """
    
    @property
    def rule_id(self) -> str:
        """Get the unique identifier for this tracking rule.
        
        Returns
        -------
        str
            Rule identifier string.
        """
        return "Default"
    
    def analyze(self, data: TrackerTrace) -> Any:
        """Analyze tracker trace data.
        
        Parameters
        ----------
        data : TrackerTrace
            The tracker trace data to analyze.
            
        Returns
        -------
        Any
            The input data unchanged.
            
        Notes
        -----
        This implementation simply returns the input data without modification.
        """
        return data

    
