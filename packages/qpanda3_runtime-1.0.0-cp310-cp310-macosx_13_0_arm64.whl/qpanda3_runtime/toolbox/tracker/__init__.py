"""
Tracker toolbox module for quantum program execution tracking and analysis.

This module provides a comprehensive tracking system for monitoring quantum
program execution, including context management, data recording, and trace analysis.

Classes
-------
TrackerSystem : Global tracking process manager
Tracker : User interface class for tracking operations
TrackerRef : Tracking reference for decorator scenarios
TrackerTrace : Memory/historical data object for tracking traces
TraceAnalyzer : Trace data analyzer with rule-based analysis
TrackingRule : Base class for tracking analysis rules
TrackingRules : Manager for tracking rules
TraceDebugger : Debugging tool for trace analysis

Functions
---------
tracker : Decorator for automatic function tracking

Notes
-----
- The tracker system supports both synchronous and asynchronous operations
- Traces can be saved to files for later analysis
- Multiple analysis rules can be registered for different use cases
"""

from .tracker_system import TrackerSystem
from .tracker_ui import Tracker, TrackerRef, tracker
from .tracker_trace import TrackerTrace
from .trace_analyzer import TraceAnalyzer
from .tracking_rule import TrackingRule, TrackingRules
from .tracking_rules import DefaultTrackingRule
from .tracking_rules import *
from .tools import TraceDebugger

