import threading
import datetime
import re

class ClientTaskIdGenerator:
    """
    Generate and parse 32-character fixed-length client task IDs.
    
    Format: [Unix timestamp in milliseconds (11)][minute-second (3)][Token summary][separator '_'][sequence]
    
    Notes
    -----
    - Total length: fixed 32 characters
    - Thread-safe sequence generation
    - Supports token-based ID generation and parsing
    
    Examples
    --------
    >>> generator = ClientTaskIdGenerator()
    >>> generator.update_token_info("beaccdc1-7f17-4eb2-a286-c4c00630c9d2", datetime.now())
    >>> task_id = generator.generate_client_task_id(datetime.now())
    >>> parsed = generator.parse_timestamp(task_id)
    """
    
    def __init__(self, initial_sequence: int = 0):
        """
        Initialize client task ID generator.
        
        Parameters
        ----------
        initial_sequence : int, optional
            Initial sequence number, by default 0.
        
        Raises
        ------
        ValueError
            If initial_sequence is negative.
        """
        if initial_sequence < 0:
            raise ValueError("Initial sequence must be non-negative")
        self.sequence = initial_sequence
        self._lock = threading.Lock()
        self._last_timestamp = None
        self.token = None
        self.token_receive_time = None
    
    def update_token_info(self, token: str, token_receive_time: datetime.datetime) -> None:
        """
        Thread-safely update token information.
        
        Parameters
        ----------
        token : str
            Token string (e.g., "beaccdc1-7f17-4eb2-a286-c4c00630c9d2").
        token_receive_time : datetime.datetime
            Token receive time.
        
        Raises
        ------
        TypeError
            If parameter type is incorrect.
        
        Notes
        -----
        - Must be called before generate_client_task_id()
        - Token is cleaned by removing hyphens
        """
        if not isinstance(token, str):
            raise TypeError("token must be a string")
        if not isinstance(token_receive_time, datetime.datetime):
            raise TypeError("token_receive_time must be a datetime object")
        
        with self._lock:
            self.token = token
            self.token_receive_time = token_receive_time
    
    def generate_client_task_id(
        self, 
        task_define_time: datetime.datetime
    ) -> str:
        """
        Generate 32-character fixed-length client task ID.
        
        Parameters
        ----------
        task_define_time : datetime.datetime
            Task definition time (used for timestamp).
        
        Returns
        -------
        str
            32-character hexadecimal string.
        
        Raises
        ------
        ValueError
            If parameter format is invalid or length calculation error.
        TypeError
            If parameter type is incorrect.
        RuntimeError
            If token information is not set.
        
        Notes
        -----
        - Format: [Unix timestamp in milliseconds (11)][minute-second (3)][Token summary][separator '_'][sequence]
        - Total length: fixed 32 characters
        - Token information must be set via update_token_info() first
        - Thread-safe sequence generation
        """
        # Validate input parameters
        if not isinstance(task_define_time, datetime.datetime):
            raise TypeError("task_define_time must be a datetime object")
        
        # Validate token information is set
        if self.token is None or self.token_receive_time is None:
            raise RuntimeError("Token information not set. Call update_token_info() first.")
        
        # Clean token
        cleaned_token = self.token.strip().replace('-', '')
        if len(cleaned_token) != 32:
            raise ValueError("Token must be 32 characters after removing hyphens")
        
        # Calculate timestamp part
        # Unix timestamp in milliseconds
        unix_timestamp_ms = int(task_define_time.timestamp() * 1000)
        timestamp_hex = hex(unix_timestamp_ms)[2:].zfill(11)
        
        # Minute-second
        minute_second = self._extract_minute_second(self.token_receive_time)
        minute_second_hex = hex(minute_second)[2:].zfill(3)
        
        # Timestamp part (first 14 characters)
        timestamp_part = timestamp_hex + minute_second_hex
        
        # Get next sequence number
        sequence = self._get_next_sequence(unix_timestamp_ms)
        sequence_hex = hex(sequence)[2:]
        
        # Calculate token summary length
        total_fixed_length = 14  # Timestamp part length
        sequence_length = len(sequence_hex)
        separator_length = 1  # '_' separator
        token_summary_length = 32 - total_fixed_length - separator_length - sequence_length
        
        if token_summary_length < 1:
            raise ValueError("Token summary length calculation error")
        
        # Adaptive sample token summary
        token_summary = self._adaptive_sample(cleaned_token, token_summary_length)
        
        # Combine parts
        client_task_id = f"{timestamp_part}{token_summary}_{sequence_hex}"
        
        # Verify total length
        if len(client_task_id) != 32:
            raise ValueError(f"Generated client task ID length is {len(client_task_id)}, expected 32")
        
        return client_task_id
    
    @staticmethod
    def parse_timestamp(client_task_id: str) -> dict:
        """
        Parse timestamp part of client task ID.
        
        Parameters
        ----------
        client_task_id : str
            32-character client task ID.
        
        Returns
        -------
        dict
            Dictionary containing:
            - 'unix_timestamp_ms': Unix timestamp in milliseconds (int)
            - 'datetime': Python datetime object (UTC)
            - 'minute_second': Minute-second value (int, 0-3599)
            - 'readable_minute_second': String format (e.g., "32:45")
            - 'timestamp_hex': Hexadecimal string of timestamp part (first 14 characters)
            - 'is_valid': Boolean indicating if time is valid
        
        Raises
        ------
        ValueError
            If ID length is not 32 characters or format is invalid.
        
        Notes
        -----
        - Only parses timestamp part (first 14 characters)
        - Returns UTC datetime object
        - Validates minute-second range (0-3599)
        """
        # Verify ID length
        if len(client_task_id) != 32:
            raise ValueError(f"Client task ID length is {len(client_task_id)}, expected 32")
        
        # Verify hexadecimal string format (allowing underscore)
        hex_pattern = r'^[0-9a-f]+_[0-9a-f]+$'
        if not re.match(hex_pattern, client_task_id):
            raise ValueError("Client task ID must be a hexadecimal string with underscore separator")
        
        # Extract timestamp part
        timestamp_hex = client_task_id[:11]
        minute_second_hex = client_task_id[11:14]
        timestamp_part = timestamp_hex + minute_second_hex
        
        # Convert timestamp
        try:
            unix_timestamp_ms = int(timestamp_hex, 16)
            minute_second = int(minute_second_hex, 16)
            
            # Verify minute-second range
            if not 0 <= minute_second <= 3599:
                raise ValueError("Minute second value out of range (0-3599)")
            
            # Convert to datetime object
            dt = datetime.datetime.fromtimestamp(unix_timestamp_ms / 1000, datetime.timezone.utc)
            
            # Convert minute-second to readable format
            minutes = minute_second // 60
            seconds = minute_second % 60
            readable_minute_second = f"{minutes:02d}:{seconds:02d}"
            
            return {
                'unix_timestamp_ms': unix_timestamp_ms,
                'datetime': dt,
                'minute_second': minute_second,
                'readable_minute_second': readable_minute_second,
                'timestamp_hex': timestamp_part,
                'is_valid': True
            }
        except (ValueError, OverflowError) as e:
            raise ValueError(f"Invalid timestamp format: {e}")
    
    @staticmethod
    def decode_client_task_id(client_task_id: str) -> dict:
        """
        Fully parse all components of client task ID.
        
        Parameters
        ----------
        client_task_id : str
            32-character client task ID.
        
        Returns
        -------
        dict
            Dictionary containing:
            - 'full_id': Original ID string
            - 'unix_timestamp_ms': Unix timestamp in milliseconds
            - 'datetime': Python datetime object
            - 'minute_second': Minute-second value (int)
            - 'token_summary': Token summary string
            - 'sequence': Sequence number (int)
            - 'separator_position': Separator position in dynamic part (0-17)
            - 'token_summary_length': Token summary length
            - 'sequence_length': Sequence hexadecimal length
        
        Raises
        ------
        ValueError
            If ID format is invalid or missing separator.
        
        Notes
        -----
        - Parses all components including token summary and sequence
        - Uses parse_timestamp() for timestamp parsing
        - Validates separator presence and format
        """
        # Verify ID length
        if len(client_task_id) != 32:
            raise ValueError(f"Client task ID length is {len(client_task_id)}, expected 32")
        
        # Parse time part
        time_info = ClientTaskIdGenerator.parse_timestamp(client_task_id)
        
        # Find separator position
        separator_pos = client_task_id.find('_')
        if separator_pos == -1:
            raise ValueError("Client task ID missing separator '_'")
        
        # Extract parts
        timestamp_part = client_task_id[:14]
        dynamic_part = client_task_id[14:]
        separator_pos_in_dynamic = dynamic_part.find('_')
        
        if separator_pos_in_dynamic == -1:
            raise ValueError("Client task ID missing separator in dynamic part")
        
        token_summary = dynamic_part[:separator_pos_in_dynamic]
        sequence_hex = dynamic_part[separator_pos_in_dynamic + 1:]
        
        # Verify sequence format
        try:
            sequence = int(sequence_hex, 16)
        except ValueError:
            raise ValueError("Invalid sequence format")
        
        # Calculate part lengths
        token_summary_length = len(token_summary)
        sequence_length = len(sequence_hex)
        
        return {
            'full_id': client_task_id,
            'unix_timestamp_ms': time_info['unix_timestamp_ms'],
            'datetime': time_info['datetime'],
            'minute_second': time_info['minute_second'],
            'token_summary': token_summary,
            'sequence': sequence,
            'separator_position': separator_pos_in_dynamic,
            'token_summary_length': token_summary_length,
            'sequence_length': sequence_length
        }
    
    def _extract_minute_second(self, dt: datetime.datetime) -> int:
        """
        Extract minute-second from datetime object.
        
        Parameters
        ----------
        dt : datetime.datetime
            Datetime object.
        
        Returns
        -------
        int
            Minute-second value (0-3599).
        
        Notes
        -----
        - Converts to UTC if timezone-aware
        - Validates range (0-3599)
        """
        # Convert to UTC
        if dt.tzinfo is not None:
            dt = dt.astimezone(datetime.timezone.utc)
        
        # Calculate minute-second
        minute_second = dt.minute * 60 + dt.second
        
        # Verify range
        if not 0 <= minute_second <= 3599:
            raise ValueError(f"Minute second value {minute_second} out of range (0-3599)")
        
        return minute_second
    
    def _adaptive_sample(self, uuid_str: str, target_length: int) -> str:
        """
        Perform equidistant sampling on UUID string.
        
        Parameters
        ----------
        uuid_str : str
            32-character UUID string (without hyphens).
        target_length : int
            Target sampling length (1-17).
        
        Returns
        -------
        str
            Sampled string.
        
        Raises
        ------
        ValueError
            If uuid_str length is not 32 or target_length is out of valid range.
        
        Notes
        -----
        - Uses equidistant sampling algorithm
        - For target_length=1, returns middle character
        - For target_length>=32, returns full string
        """
        # Validate input
        if len(uuid_str) != 32:
            raise ValueError("UUID string must be 32 characters")
        if target_length < 0:
            raise ValueError("Target length must be non-negative")
        if target_length > 17:
            raise ValueError("Target length must be at most 17")
        
        # Handle boundary cases
        if target_length == 0:
            return ""
        if target_length == 1:
            return uuid_str[15]  # Middle character
        if target_length >= 32:
            return uuid_str[:32]
        
        # Equidistant sampling
        step = 32 // target_length
        sample_indices = [i * step for i in range(target_length)]
        
        # Ensure last index does not exceed 31
        if len(sample_indices) > target_length:
            sample_indices = sample_indices[:target_length]
        
        # Generate sampled string
        sampled = ''.join([uuid_str[i] for i in sample_indices])
        
        return sampled
    
    def _get_next_sequence(self, current_timestamp_ms: int) -> int:
        """
        Thread-safely get next sequence number.
        
        Parameters
        ----------
        current_timestamp_ms : int
            Current timestamp in milliseconds.
        
        Returns
        -------
        int
            Next sequence number.
        
        Notes
        -----
        - Thread-safe with lock
        - Resets sequence when timestamp changes
        - Handles overflow (16-bit maximum)
        """
        with self._lock:
            # Check if timestamp has updated
            if self._last_timestamp != current_timestamp_ms:
                self.sequence = 0
                self._last_timestamp = current_timestamp_ms
            
            # Get current sequence
            current_sequence = self.sequence
            
            # Increment sequence
            self.sequence += 1
            
            # Handle sequence overflow (simple reset to 0)
            if self.sequence > 0xFFFF:  # 16-bit maximum
                self.sequence = 0
            
            return current_sequence
