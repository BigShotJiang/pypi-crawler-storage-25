"""Failure orchestrator module for managing and coordinating failure handling.

This module provides components for orchestrating failure handling strategies
in distributed quantum computing systems. It includes mechanisms for detecting,
analyzing, and responding to failures in a coordinated manner.

The failure orchestrator works in conjunction with the tracking system to
provide comprehensive failure management capabilities.

Modules
-------
failure_orchestrator : Main orchestrator class and related components.

Examples
--------
>>> from qpanda3_runtime.toolbox.failure_orchestrator import FailureOrchestrator
>>> orchestrator = FailureOrchestrator()
>>> orchestrator.register_handler("timeout", timeout_handler)
>>> orchestrator.handle_failure("timeout", context_data)

Notes
-----
This module is designed to be extensible, allowing custom failure handlers
to be registered for different types of failures.
"""

from .failure_orchestrator import (
    FailureOrchestrator,
    FailureHandler,
    FailureContext,
    FailureSeverity,
    OrchestrationStrategy
)

__all__ = [
    "FailureOrchestrator",
    "FailureHandler", 
    "FailureContext",
    "FailureSeverity",
    "OrchestrationStrategy"
]

__version__ = "1.0.0"
__author__ = "QPanda3 Runtime Team"
__description__ = "Failure orchestration system for quantum computing runtime"