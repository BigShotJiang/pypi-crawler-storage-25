import json
import os
from typing import Any, Dict, Optional
import time
from datetime import datetime
from ..version import __version__


class VersionMismatchError(Exception):
    """Exception raised for version mismatch errors.
    
    Attributes
    ----------
    message : str
        Explanation of the error
    """
    pass


class CheckPoint:
    """
    Manual checkpointing and recovery tool for quantum computation states.
    
    A non-semantic key-value container where users are responsible for knowing
    what they store and how to interpret it. No automatic operations are
    performed, and no decisions are made on behalf of the user.
    
    Notes
    -----
    - Two access channels: recovery (load) with strict version checking, and
      export (export_data) without version checking
    - Version strategy: uses global package version, immutable per instance
    - Storage strategy: local filesystem only, no backend abstraction
    - Task state acquisition: supports dict or objects with get_task_state()
    
    See Also
    --------
    qpanda3_runtime.runtime_service : Main runtime service client.
    qpanda3_runtime.device : Quantum device interfaces.
    
    Examples
    --------
    >>> from qpanda3_runtime.toolbox import CheckPoint
    >>> checkpoint = CheckPoint()
    >>> filepath = checkpoint.save(task_state=quantum_state, user_data={'algorithm': 'VQE'})
    >>> loaded_data = checkpoint.load(filepath)
    """

    def __init__(self):
        """
        Initialize checkpoint tool with package version.
        
        The version is obtained from the package and used for:
        - Injecting into checkpoint metadata during save()
        - Version checking during load()
        
        Attributes
        ----------
        version : str
            Current software version, read-only. Determined during initialization,
            immutable during instance lifecycle.
        
        Notes
        -----
        - Version cannot be passed or modified by user
        - Different minor versions are treated as different versions
        - No internal state is maintained
        """
        self._version = __version__

    @property
    def version(self):
        """
        str: Current software version, read-only.
        """
        return self._version

    def save(self, filepath: Optional[str] = None, task_state: Any = None, user_data: Optional[Dict] = None) -> str:
        """
        Save checkpoint data to file.
        
        Parameters
        ----------
        filepath : str, optional
            Checkpoint file save path. If None, generates default filename
            in current working directory.
        task_state : any, optional
            Task state. Supports:
            - dict: Direct reference, no copy performed
            - Object with get_task_state() method: Returns state dict
            - None or other types: Treated as no task state
        user_data : dict, optional
            User-defined data dictionary. Values must be JSON-serializable.
        
        Returns
        -------
        str
            Actual written file path (absolute path).
        
        Raises
        ------
        TypeError
            If task_state is non-dict and does not implement get_task_state() method,
            or if user_data is not a dict.
        
        Notes
        -----
        - System does not manage checkpoint identifiers or guarantee filename uniqueness
        - Default filename format: checkpoint_YYYYMMDD_HHMMSS.json
        - When task_state is dict, it is directly referenced (no copy)
        - Version is automatically injected into metadata
        - Existing files are overwritten
        - Not thread-safe for concurrent writes to same file
        """
        if filepath is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = os.path.join(os.getcwd(), f"checkpoint_{timestamp}.json")
        else:
            filepath = os.path.abspath(filepath)

        task_state_dict = None
        if isinstance(task_state, dict):
            task_state_dict = task_state
        elif task_state is not None:
            if hasattr(task_state, "get_task_state") and callable(task_state.get_task_state):
                task_state_dict = task_state.get_task_state()
                if not isinstance(task_state_dict, dict):
                    raise TypeError("get_task_state() method must return a dict")
            else:
                raise TypeError("task_state must be a dict or an object with get_task_state() method")

        if user_data is None:
            user_data = {}
        elif not isinstance(user_data, dict):
            raise TypeError("user_data must be a dict")

        checkpoint_data = {
            "meta": {
                "version": self.version,
                "created_at": datetime.now().isoformat()
            },
            "task_state": task_state_dict or {},
            "user_data": user_data
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(checkpoint_data, f, ensure_ascii=False, indent=2)

        return filepath

    def load(self, filepath: str) -> Dict:
        """
        Load checkpoint data with strict version checking (recovery channel).
        
        Parameters
        ----------
        filepath : str
            Checkpoint file path, must exist and be readable.
        
        Returns
        -------
        dict
            Dictionary with three fixed keys:
            - 'meta': dict - Read-only metadata, including version, creation time
            - 'task_state': dict - Task state dictionary, may be empty
            - 'user_data': dict - User-defined data
        
        Raises
        ------
        VersionMismatchError
            If checkpoint version does not match self.version.
        FileNotFoundError
            If checkpoint file not found.
        JSONDecodeError
            If file content is not valid JSON format.
        
        Notes
        -----
        - Strict version checking: version in metadata must equal self.version
        - System does not maintain checkpoint index
        - No automatic recovery operations performed
        """
        filepath = os.path.abspath(filepath)

        if not os.path.exists(filepath):
            raise FileNotFoundError(f"CheckPoint file not found: {filepath}")

        with open(filepath, "r", encoding="utf-8") as f:
            checkpoint_data = json.load(f)

        if not isinstance(checkpoint_data, dict):
            raise ValueError("Invalid checkpoint file format")

        meta = checkpoint_data.get("meta", {})
        checkpoint_version = meta.get("version")
        if checkpoint_version != self.version:
            raise VersionMismatchError(
                f"Version mismatch: checkpoint version {checkpoint_version} != current version {self.version}"
            )

        return {
            "meta": meta,
            "task_state": checkpoint_data.get("task_state", {}),
            "user_data": checkpoint_data.get("user_data", {})
        }

    def export_data(self, filepath: str) -> Dict:
        """
        Export checkpoint data without version checking (export channel).
        
        Parameters
        ----------
        filepath : str
            Checkpoint file path, must exist and be readable.
        
        Returns
        -------
        dict
            Dictionary with following keys:
            - 'meta': dict - Complete built-in metadata, including version
            - 'user_data': dict - Complete user-defined data
            - 'task_state_available': bool - Whether task state data exists
        
        Raises
        ------
        FileNotFoundError
            If checkpoint file not found.
        JSONDecodeError
            If file content is not valid JSON format.
        
        Notes
        -----
        - No version checking: can be called across versions
        - Never returns task_state content
        - Read-only operation, does not modify data
        - Metadata includes version information for version comparison
        """
        filepath = os.path.abspath(filepath)

        if not os.path.exists(filepath):
            raise FileNotFoundError(f"CheckPoint file not found: {filepath}")

        with open(filepath, "r", encoding="utf-8") as f:
            checkpoint_data = json.load(f)

        if not isinstance(checkpoint_data, dict):
            raise ValueError("Invalid checkpoint file format")

        task_state_available = "task_state" in checkpoint_data and isinstance(checkpoint_data["task_state"], dict)

        return {
            "meta": checkpoint_data.get("meta", {}),
            "user_data": checkpoint_data.get("user_data", {}),
            "task_state_available": task_state_available
        }
