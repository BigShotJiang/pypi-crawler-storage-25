"""
Message classes for quantum computing tasks.

This module provides classes for constructing task messages for quantum
computing operations, including sampling and estimation tasks.
"""

import json
from typing import List


class ChipSampleTaskMsg:
    """
    Message builder for quantum chip sampling tasks.
    
    This class constructs messages for submitting quantum circuit sampling
    tasks to remote quantum computing services.
    
    Attributes
    ----------
    _msg : dict
        Internal message dictionary containing task configuration.
    
    Methods
    -------
    build(progs, chip_id, shot, is_amend, is_mapping, is_optimization, 
          specified_block, priority, point_label, token, task_describe)
        Build a complete sampling task message.
    msg_dict()
        Get the message as a dictionary.
    msg_json()
        Get the message as a JSON string.
    from_json_str(json_str)
        Load message from JSON string.
    is_equal_with(other)
        Compare equality with another message instance.
    """
    
    def __init__(self):
        """Initialize an empty message dictionary."""
        self._msg = {}

    def msg(self):
        """
        Get the internal message dictionary.
        
        Returns
        -------
        dict
            Current message dictionary.
        """
        return self._msg

    def build(self,
              progs: List[str],
              chip_id: str,
              shot: int,
              is_amend: bool,
              is_mapping: bool,
              is_optimization: bool,
              specified_block: [int],
              priority: int,
              point_label: int,
              token: str,
              task_describe: str
              ):
        """
        Build a sampling task message with all required parameters.
        
        Parameters
        ----------
        progs : List[str]
            List of quantum programs/circuits to execute.
        chip_id : str
            Identifier of the target quantum chip.
        shot : int
            Number of measurement shots to perform.
        is_amend : bool
            Whether to apply amplitude correction.
        is_mapping : bool
            Whether to apply qubit mapping.
        is_optimization : bool
            Whether to apply circuit optimization.
        specified_block : List[int]
            List of specific blocks to execute on.
        priority : int
            Task priority level.
        point_label : int
            Label for calibration point.
        token : str
            Authentication token.
        task_describe : str
            Human-readable task description.
        
        Returns
        -------
        dict
            Complete task message dictionary.
        
        Notes
        -----
        The message structure follows the PilotOS API specification for
        quantum sampling tasks.
        """
        self._msg = {'PilotOSMachineFlag': True, 'taskDescribe': task_describe, 'QProg': progs, 'QMachineType': '5',
                     'TaskType': 0, 'ChipID': chip_id, 'Priority': priority, 'callbackAddr': 'TCP_CB', 'token': token}
        cfg = {'shot': shot, 'amendFlag': is_amend, 'PointLabel': point_label, 'mappingFlag': is_mapping,
               'circuitOptimization': is_optimization, 'IsProbCount': False, 'specified_block': specified_block}
        self._msg['Configuration'] = cfg

        return self._msg

    def msg_dict(self):
        """
        Get the message as a dictionary.
        
        Returns
        -------
        dict
            Message dictionary.
        """
        return self._msg

    def msg_json(self):
        """
        Get the message as a JSON string.
        
        Returns
        -------
        str
            JSON-encoded message string.
        """
        return json.dumps(self._msg)

    def from_json_str(self, json_str: str):
        """
        Load message from JSON string.
        
        Parameters
        ----------
        json_str : str
            JSON string containing the task message.
        
        Notes
        -----
        This method parses the JSON and populates the internal message
        dictionary with the extracted data.
        """
        msg = json.loads(json_str)
        keys = ['PilotOSMachineFlag', 'taskDescribe', 'QProg', 'QMachineType', 'TaskType', 'ChipID', 'Priority',
                'callbackAddr', 'token']
        for k in keys:
            self._msg[k] = msg[k]
        self._msg['Configuration'] = {}
        cfg = self._msg['Configuration']
        cfg_ = msg['Configuration']
        cfg_keys = ['shot', 'amendFlag', 'PointLabel', 'mappingFlag', 'circuitOptimization', 'IsProbCount',
                    'specified_block']
        for k in cfg_keys:
            cfg[k] = cfg_[k]

    def is_equal_with(self, other):
        """
        Compare equality with another message instance.
        
        Parameters
        ----------
        other : ChipSampleTaskMsg
            Another message instance to compare with.
        
        Returns
        -------
        bool
            True if messages are equal, False otherwise.
        
        Notes
        -----
        This method performs deep comparison of all message fields,
        including nested configuration data.
        """
        keys = self._msg.keys()
        for k in keys:
            if k == 'Configuration':
                for v in self._msg[k].keys():
                    if self._msg[k][v] != other.msg()[k][v]:
                        return False
                pass
            else:
                if self._msg[k] != other.msg()[k]:
                    return False
        return True


class ChipEstimateTaskMsg:
    """
    Message builder for quantum chip estimation tasks.
    
    This class constructs messages for submitting quantum expectation value
    estimation tasks to remote quantum computing services.
    
    Attributes
    ----------
    _msg : dict
        Internal message dictionary containing task configuration.
    
    Methods
    -------
    build(progs, hamiltonian, qubits, shot, chip_id, is_amend, is_mapping,
          is_optimization, specified_block, task_describe, token)
        Build a complete estimation task message.
    from_json_str(json_str)
        Load message from JSON string.
    is_equal_with(other)
        Compare equality with another message instance.
    update_hamiltonian(ham)
        Update the Hamiltonian in the message.
    update_progs(progs)
        Update the quantum programs in the message.
    msg_dict()
        Get the message as a dictionary.
    msg_json()
        Get the message as a JSON string.
    """
    
    def __init__(self):
        """Initialize an empty message dictionary."""
        self._msg = {}

    def build(self,
              progs: [str],
              hamiltonian,
              qubits: List[int],
              shot: int,
              chip_id: str,
              is_amend: bool,
              is_mapping: bool,
              is_optimization: bool,
              specified_block: List[int],
              task_describe: str,
              token: str
              ):
        """
        Build an estimation task message with all required parameters.
        
        Parameters
        ----------
        progs : List[str]
            List of quantum programs/circuits to execute.
        hamiltonian
            Hamiltonian operator for expectation value calculation.
        qubits : List[int]
            List of qubit indices involved in the calculation.
        shot : int
            Number of measurement shots to perform.
        chip_id : str
            Identifier of the target quantum chip.
        is_amend : bool
            Whether to apply amplitude correction.
        is_mapping : bool
            Whether to apply qubit mapping.
        is_optimization : bool
            Whether to apply circuit optimization.
        specified_block : List[int]
            List of specific blocks to execute on.
        task_describe : str
            Human-readable task description.
        token : str
            Authentication token.
        
        Returns
        -------
        dict
            Complete task message dictionary.
        
        Notes
        -----
        The message structure follows the PilotOS API specification for
        quantum expectation value estimation tasks.
        """
        self._msg = {'PilotOSMachineFlag': True, 'taskDescribe': task_describe, 'QProg': progs, 'QMachineType': '5',
                     'TaskType': 5, 'ChipID': chip_id, 'callbackAddr': 'TCP_CB', 'token': token}
        cfg = {'shot': shot, 'amendFlag': is_amend, 'mappingFlag': is_mapping, 'circuitOptimization': is_optimization,
               'hamiltonian': hamiltonian, 'qubits': qubits, 'specified_block': specified_block}
        self._msg['Configuration'] = cfg

        return self._msg

    def from_json_str(self, json_str: str):
        """
        Load message from JSON string.
        
        Parameters
        ----------
        json_str : str
            JSON string containing the task message.
        
        Notes
        -----
        This method parses the JSON and populates the internal message
        dictionary with the extracted data.
        """
        msg = json.loads(json_str)
        keys = ['PilotOSMachineFlag', 'taskDescribe', 'QProg', 'QMachineType', 'TaskType', 'ChipID', 'callbackAddr',
                'token']
        for k in keys:
            self._msg[k] = msg[k]
        self._msg['Configuration'] = {}
        cfg = self._msg['Configuration']
        cfg_ = msg['Configuration']
        cfg_keys = ['shot', 'amendFlag', 'mappingFlag', 'circuitOptimization', 'hamiltonian', 'specified_block',
                    'qubits']
        for k in cfg_keys:
            cfg[k] = cfg_[k]

    def is_equal_with(self, other):
        """
        Compare equality with another message instance.
        
        Parameters
        ----------
        other : ChipEstimateTaskMsg
            Another message instance to compare with.
        
        Returns
        -------
        bool
            True if messages are equal, False otherwise.
        
        Notes
        -----
        This method performs deep comparison of all message fields,
        including nested configuration data.
        """
        keys = self._msg.keys()
        for k in keys:
            if k == 'Configuration':
                for v in self._msg[k].keys():
                    if self._msg[k][v] != other.msg()[k][v]:
                        return False
                pass
            else:
                if self._msg[k] != other.msg()[k]:
                    return False
        return True

    def update_hamiltonian(self, ham):
        """
        Update the Hamiltonian in the message.
        
        Parameters
        ----------
        ham
            New Hamiltonian operator to set.
        """
        self._msg['Configuration']['hamiltonian'] = ham

    def update_progs(self, progs):
        """
        Update the quantum programs in the message.
        
        Parameters
        ----------
        progs : List[str]
            New list of quantum programs to set.
        """
        self._msg['QProg'] = progs

    def msg_dict(self):
        """
        Get the message as a dictionary.
        
        Returns
        -------
        dict
            Message dictionary.
        """
        return self._msg

    def msg_json(self):
        """
        Get the message as a JSON string.
        
        Returns
        -------
        str
            JSON-encoded message string.
        """
        return json.dumps(self._msg)
