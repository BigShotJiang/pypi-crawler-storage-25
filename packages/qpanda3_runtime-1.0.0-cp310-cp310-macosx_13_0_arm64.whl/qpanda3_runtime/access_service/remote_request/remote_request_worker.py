"""
Asynchronous request worker for quantum computing services.

This module provides a threaded worker that handles asynchronous HTTP
requests to remote quantum computing services, supporting various
quantum operations and task management.
"""

import asyncio
import copy
import threading
import concurrent.futures
import time

from typing import Union, Optional, List

from ..network.http_client import HTTPClient
from ..channel.default_channel import default_channel


class RequestWorker(threading.Thread):
    """
    Threaded worker for handling asynchronous quantum service requests.
    
    This class runs an asyncio event loop in a separate thread to handle
    concurrent HTTP requests to quantum computing services. It provides
    synchronous interfaces that internally use asynchronous operations.
    
    Attributes
    ----------
    loop : asyncio.AbstractEventLoop
        Asyncio event loop running in the worker thread.
    _http_client : HTTPClient
        HTTP client for making requests to quantum services.
    _base_url : str
        Base URL for the quantum service API.
    _outbound_raw_requests_logfile : str
        Path to log file for recording outbound requests.
    
    Methods
    -------
    login(msg, channel)
        Authenticate with the quantum service.
    query_task(channel, task_id, token, additional_info)
        Query status of submitted tasks.
    list_devices(channel, target)
        List available quantum devices.
    query_device_config(channel, msg)
        Query configuration of a quantum device.
    estimate(channel, msg)
        Submit an expectation value estimation task.
    sample(channel, msg)
        Submit a circuit sampling task.
    circuit_chunking_submit(channel, circuits, common_msg, task_type,
                            max_byte_num_per_packet, max_cir_num_per_packet, encode_type)
        Submit large circuits in chunks.
    sample_program_set(channel, msg)
        Submit a program set for sampling.
    apply_vqsession(channel, msg)
        Apply for a variational quantum session.
    release_session(channel, msg)
        Release a variational quantum session.
    run_vqtask(channel, msg)
        Run a variational quantum task.
    close()
        Stop the worker thread.
    """
    
    def __init__(self, base_url, outbound_raw_requests_logfile):
        """
        Initialize the request worker.
        
        Parameters
        ----------
        base_url : str
            Base URL for the quantum service API.
        outbound_raw_requests_logfile : str
            Path to log file for recording outbound requests.
        
        Notes
        -----
        The worker thread starts automatically during initialization
        and runs an asyncio event loop for handling asynchronous operations.
        """
        super().__init__(daemon=True)
        self.loop = None
        self._http_client: Union[HTTPClient, None] = None
        self._base_url = base_url
        self._outbound_raw_requests_logfile = outbound_raw_requests_logfile

        self.start()
        while not self.loop:
            time.sleep(0.01)


    def login(self, msg: dict, channel: str = default_channel):
        """
        Authenticate with the quantum service.
        
        Parameters
        ----------
        msg : dict
            Authentication message containing credentials.
        channel : str, optional
            Communication channel identifier (default: default_channel).
        
        Returns
        -------
        dict
            Authentication response from the server.
        
        Notes
        -----
        This method sends login credentials to obtain an authentication
        token for subsequent API calls.
        """
        msg['channel'] = channel
        return self._process(self._http_client.post_request_async(f'/{channel}/login', msg))

    def query_task(self, channel: str, task_id: list, token: str,
                               additional_info: Optional[List[str]] = None):
        """
        Query status of submitted tasks.
        
        Parameters
        ----------
        channel : str
            Communication channel identifier.
        task_id : list
            List of task IDs to query.
        token : str
            Authentication token.
        additional_info : Optional[List[str]], optional
            Additional information fields to request (default: None).
        
        Returns
        -------
        list
            List of task status responses.
        
        Notes
        -----
        This method queries the status of multiple tasks concurrently
        and returns their results.
        """
        return self._process(self.query_task_async(channel, task_id, token, additional_info))

    def list_devices(self, channel=default_channel, target: Union[int, str] = ''):
        """
        List available quantum devices.
        
        Parameters
        ----------
        channel : str, optional
            Communication channel identifier (default: default_channel).
        target : Union[int, str], optional
            Target device identifier or type (default: '').
        
        Returns
        -------
        dict
            List of available quantum devices and their properties.
        
        Notes
        -----
        This method retrieves information about quantum computing
        devices available through the service.
        """
        return self._process(self._list_devices(channel, target))

    def query_device_config(self, channel: str, msg: dict):
        """
        Query configuration of a quantum device.
        
        Parameters
        ----------
        channel : str
            Communication channel identifier.
        msg : dict
            Message containing device query parameters.
        
        Returns
        -------
        dict
            Device configuration information.
        """
        return self._process(self._query_device_config_async(channel, msg))

    def estimate(self, channel, msg):
        """
        Submit an expectation value estimation task.
        
        Parameters
        ----------
        channel : str
            Communication channel identifier.
        msg : dict
            Task message containing circuit and Hamiltonian information.
        
        Returns
        -------
        dict
            Task submission response.
        """
        msg['channel'] = channel
        return self._process(self._http_client.post_request_async(f'/{channel}/task/submit/estimate', msg))

    def sample(self, channel, msg):
        """
        Submit a circuit sampling task.
        
        Parameters
        ----------
        channel : str
            Communication channel identifier.
        msg : dict
            Task message containing circuit information.
        
        Returns
        -------
        dict
            Task submission response.
        """
        return self._process(self._http_client.post_request_async(f'/{channel}/task/submit/sample', msg))

    def circuit_chunking_submit(self, channel, circuits: List[str], common_msg, task_type,
                                       max_byte_num_per_packet, max_cir_num_per_packet, encode_type='ascii'):
        """
        Submit large circuits in chunks.
        
        Parameters
        ----------
        channel : str
            Communication channel identifier.
        circuits : List[str]
            List of quantum circuits to submit.
        common_msg : dict
            Common message parameters for all circuits.
        task_type : str
            Type of task ('sample' or other supported types).
        max_byte_num_per_packet : int
            Maximum bytes per network packet.
        max_cir_num_per_packet : int
            Maximum circuits per network packet.
        encode_type : str, optional
            Encoding type for circuit strings (default: 'ascii').
        
        Returns
        -------
        list
            List of submission results for each chunk.
        
        Notes
        -----
        This method splits large circuit submissions into smaller chunks
        to avoid network packet size limitations.
        """
        
        return self._process(self.circuit_chunking_submit_(channel, circuits, common_msg, task_type, max_byte_num_per_packet, max_cir_num_per_packet, encode_type))

    def sample_program_set(self, channel, msg):
        return self._process(self._sample_program_set_async(channel,msg))

    def apply_vqsession(self, channel, msg):
        return self._process(self._apply_vqsession(channel,msg))

    def release_session(self, channel, msg):
        return self._process(self._release_session(channel,msg))

    def run_vqtask(self, channel, msg):
        return self._process(self._run_vqtask(channel,msg))

    async def _run_vqtask(self,channel,msg):
        msg['channel']=channel
        return await self._http_client.post_request_async(f'/{channel}/session/vqsession/qtask/add_run', msg)
    async def _sample_program_set_async(self, channel, msg):
        msg['channel'] = channel
        return await self._http_client.post_request_async(f'/{channel}/task/submit/sample/program_set', msg)

    async def _sample(self,channel,circuits,common_msg):
        msg = copy.deepcopy(common_msg)
        msg['QProg'] = circuits
        msg['channel'] = channel
        return await self._http_client.post_request_async(f'/{channel}/task/submit/sample', msg)

    async def circuit_chunking_submit_(self, channel, circuits: List[str], common_msg, task_type,
                                       max_byte_num_per_packet, max_cir_num_per_packet, encode_type='ascii'):
        sub_tasks = []
        tmp_byte_num = 0
        tmp_cir_num = 0
        start_idx = 0
        end_idx = 0
        for cir in circuits:
            if tmp_cir_num < max_cir_num_per_packet and tmp_byte_num < max_byte_num_per_packet:
                    tmp_cir_num += 1
                    tmp_byte_num += len(cir.encode(encode_type, errors='ignore'))
                    end_idx += 1

            if tmp_cir_num >= max_cir_num_per_packet or tmp_byte_num >= max_byte_num_per_packet:
                if task_type == 'sample':
                    sub_tasks.append(
                        asyncio.create_task(self._sample(channel, circuits[start_idx:end_idx], common_msg)))
                tmp_cir_num = 0
                tmp_byte_num = 0
                start_idx = end_idx


                

        if start_idx != end_idx:
            if task_type == 'sample':
                sub_tasks.append(asyncio.create_task(self._sample(channel, circuits[start_idx:end_idx], common_msg)))

        results = await asyncio.gather(
            *sub_tasks,
            return_exceptions=True
        )
        return results

    async def _query_device_config_async(self, channel,msg):
        return await self._http_client.post_request_async(f'/{channel}/device/query_cfg', msg)

    async def _list_devices(self, channel=default_channel, target: Union[int, str] = ''):
        if isinstance(target, int):
            target = str(target)
        msg = {'channel': channel, "Backend": target}
        return await self._http_client.post_request_async(f'/{channel}/device/list', msg)


    async def query_task_(self, channel: str, task_id: int, token:str,additional_info: Optional[List[str]] = None):
        if additional_info is None:
            additional_info = []
        try:
            msg = {'taskId': task_id, 'token': token, 'msgType': 'sliceTaskResult',
                   'additional_info': additional_info,'channel':channel}
            response = await self._http_client.post_request_async(f'/{channel}/task/query', msg)
            if response:
                return response
            else:
                raise RuntimeError("The server did not return the expected data.")

        except RuntimeError as e:
            raise e

    async def _apply_vqsession(self, channel,msg):
        return await self._http_client.post_request_async(f'/{channel}/session/vqsession/apply', msg)

    async def _release_session(self, channel,msg):
        msg['channel']=channel
        return await self._http_client.post_request_async(f'/{channel}/session/release', msg)


    async def query_task_async(self, channel: str, task_id: list,token:str, additional_info: Optional[List[str]] = None):
        if additional_info is None:
            additional_info = []
        try:
            # if channel not in self.tokens:
            #     raise RuntimeError('please input correct channel string')
            tasks = []
            for id_ in task_id:
                tasks.append(asyncio.create_task(self.query_task_(channel, id_,token, additional_info)))
            results = await asyncio.gather(
                *tasks,
                return_exceptions=True
            )
            return results
        except RuntimeError as e:
            raise e

    @staticmethod
    def handle_task_result(async_future, threading_future):
        try:
            result = async_future.result()
            if not threading_future.done():
                threading_future.set_result(result)
        except Exception as e:
            # Failure: set exception
            if not threading_future.done():
                threading_future.set_exception(e)
    def _process(self, task):
        """
        Process an asynchronous task synchronously.
        
        Parameters
        ----------
        task : coroutine
            Asynchronous task to execute.
        
        Returns
        -------
        Any
            Result of the asynchronous task.
        
        Notes
        -----
        This method bridges the synchronous interface with the asynchronous
        event loop running in the worker thread.
        """
        future = concurrent.futures.Future()
        # asyncio.run_coroutine_threadsafe(task, self.loop).add_done_callback(
        #     # lambda t: future.set_result(t.result())
        #     self.handle_task_result(task,future)
        # )
        async_future = asyncio.run_coroutine_threadsafe(task, self.loop)
        async_future.add_done_callback(
            lambda t: self.handle_task_result(t, future)
        )
        return future.result()

    def run(self):
        """
        Main thread entry point for the worker.
        
        Notes
        -----
        This method sets up the asyncio event loop and HTTP client,
        then runs the event loop indefinitely to process asynchronous tasks.
        """
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self._http_client = HTTPClient(self._base_url, self._outbound_raw_requests_logfile)
        if self._http_client is None:
            raise RuntimeError('HTTPClient init failed')
        self.loop.run_forever()


    def execute(self, data):
        future = concurrent.futures.Future()

        async def task():
            for i in range(5):
                await asyncio.sleep(0.1)
            return f"Result: {data}"

        asyncio.run_coroutine_threadsafe(task(), self.loop).add_done_callback(
            lambda t: future.set_result(t.result())
        )

        return future.result()

    def close(self):
        """
        Stop the worker thread.
        
        Notes
        -----
        This method safely stops the asyncio event loop, allowing
        the worker thread to terminate gracefully.
        """
        if self.loop and self.loop.is_running():
            self.loop.call_soon_threadsafe(self.loop.stop)