"""
Remote request module for quantum computing services.

This package provides classes and utilities for constructing and sending
requests to remote quantum computing services, including task message
builders and asynchronous request workers.

Modules
-------
chip_task_msg
    Message builders for quantum computing tasks.
remote_request_worker
    Asynchronous worker for handling quantum service requests.
"""

from .chip_task_msg import ChipSampleTaskMsg, ChipEstimateTaskMsg
from .remote_request_worker import RequestWorker

__all__ = [
    'ChipSampleTaskMsg',
    'ChipEstimateTaskMsg',
    'RequestWorker'
]