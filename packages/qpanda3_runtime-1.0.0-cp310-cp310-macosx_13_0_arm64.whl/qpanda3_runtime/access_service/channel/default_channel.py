import os

setting = os.environ.get('DEFAULT_CHANNEL')
if setting and setting != '':
    default_channel = setting
else:
    default_channel = 'qcloud'
