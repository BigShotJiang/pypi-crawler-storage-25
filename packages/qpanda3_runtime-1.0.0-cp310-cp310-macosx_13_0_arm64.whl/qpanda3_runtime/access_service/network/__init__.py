"""
Network communication module for quantum computing runtime service.

This module provides HTTP and TCP client implementations for communicating with
quantum computing backend services. It supports both synchronous and asynchronous
communication patterns.

Modules
-------
http_client : HTTPClient
    Asynchronous HTTP client for REST API communication with quantum backend.
query_task_tcp : TCPQueryTask
    TCP-based client for querying quantum task execution results.

Notes
-----
- The HTTP client supports SSL/TLS with certificate verification disabled for
  development environments.
- The TCP client implements custom binary protocol for efficient data transfer.
- Both clients are designed for high-throughput quantum task management.

Examples
--------
>>> from .http_client import HTTPClient
>>> client = HTTPClient(base_url='http://localhost:8080')
>>> result = client.get_request('/api/status')

>>> from .query_task_tcp import TCPQueryTask
>>> result = TCPQueryTask.query_task_tcp('localhost', 8080, 'task-123')
"""

from .http_client import HTTPClient
from .query_task_tcp import TCPQueryTask

__all__ = ['HTTPClient', 'TCPQueryTask']