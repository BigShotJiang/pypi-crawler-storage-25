import json
import os.path
import ssl

import aiohttp
import asyncio
from typing import Union


class HTTPClient:
    """
    Asynchronous HTTP client for quantum computing backend communication.
    
    Provides synchronous and asynchronous methods for making HTTP requests
    to quantum computing backend services. Supports request logging and
    SSL/TLS configuration.
    
    Parameters
    ----------
    base_url : str, optional
        Base URL for all HTTP requests (default: 'http://localhost:8080').
    outbound_raw_requests_logfile : Union[str, None], optional
        Path to log file for recording outbound request data.
        If provided, all request payloads will be logged to this file.
    
    Attributes
    ----------
    _base_url : str
        Base URL for HTTP requests.
    _outbound_raw_requests_logfile : Union[str, None]
        Path to request logging file.
    
    Notes
    -----
    - SSL certificate verification is disabled for development environments.
    - All requests use JSON format for both request and response.
    - Timeout handling is managed by aiohttp default settings.
    
    Examples
    --------
    >>> client = HTTPClient(base_url='http://quantum-backend:8080')
    >>> result = client.get_request('/api/status')
    >>> async_result = await client.post_request_async('/api/task', {'task_id': '123'})
    """
    
    def __init__(self, base_url='http://localhost:8080', outbound_raw_requests_logfile: Union[str, None] = None):
        self._base_url = base_url
        self._outbound_raw_requests_logfile = outbound_raw_requests_logfile

    async def _make_request(self, method, endpoint, data=None):
        """
        Internal method to make HTTP requests asynchronously.
        
        Handles request logging, SSL configuration, and response processing.
        All exceptions are propagated to the caller.
        
        Parameters
        ----------
        method : str
            HTTP method (GET, POST, PUT, DELETE).
        endpoint : str
            API endpoint path relative to base URL.
        data : dict, optional
            JSON-serializable data for POST/PUT requests.
        
        Returns
        -------
        dict
            Parsed JSON response from the server.
        
        Raises
        ------
        RuntimeError
            If server returns non-2xx status code.
        aiohttp.ClientError
            For network or connection errors.
        
        Notes
        -----
        - Request data is logged to file if outbound_raw_requests_logfile is set.
        - SSL verification is disabled for development compatibility.
        - Only status codes 200 and 201 are considered successful.
        """
        if self._outbound_raw_requests_logfile is not None and os.path.exists(self._outbound_raw_requests_logfile):
            with open(self._outbound_raw_requests_logfile, mode='at', encoding='utf8') as file:
                json_str = json.dumps(data)
                file.write(json_str)
                file.write('\n')
                file.flush()

        url = f"{self._base_url}{endpoint}"
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE

        connector = aiohttp.TCPConnector(ssl=ssl_context)

        try:
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.request(
                        method=method,
                        url=url,
                        json=data if data else None,
                        headers={'Content-Type': 'application/json'}
                ) as response:

                    if response.status in [200, 201]:
                        response_data = await response.json()
                        return response_data
                    else:
                        error_text = await response.text()
                        help_info = 'Possible causes and corresponding solutions:\n'
                        if response.status in [404]:
                            help_info += '\t 1> Maybe channel qcloud is error or unreachable, \n' \
                                         '\t\t 1>>please check if channel string meets the expectations.\n' \
                                         '\t\t 2>> or please connect to qpanda3_runtime service provider to get help.\n'

                        raise RuntimeError(
                            f'request/target url:{url}, response code:{response.status}, '
                            f'response info:{error_text}, {help_info}')

        except aiohttp.ClientError as e:
            raise e
        except RuntimeError as e:
            raise e

    def get_request(self, endpoint):
        """
        Synchronous GET request.
        
        Parameters
        ----------
        endpoint : str
            API endpoint path.
        
        Returns
        -------
        dict
            Parsed JSON response.
        
        See Also
        --------
        _make_request : Internal request implementation.
        """
        return asyncio.run(self._make_request('GET', endpoint))

    def post_request(self, endpoint, data):
        """
        Synchronous POST request.
        
        Parameters
        ----------
        endpoint : str
            API endpoint path.
        data : dict
            JSON-serializable request data.
        
        Returns
        -------
        dict
            Parsed JSON response.
        """
        return asyncio.run(self._make_request('POST', endpoint, data))

    async def post_request_async(self, endpoint, data):
        """
        Asynchronous POST request.
        
        Parameters
        ----------
        endpoint : str
            API endpoint path.
        data : dict
            JSON-serializable request data.
        
        Returns
        -------
        dict
            Parsed JSON response.
        
        Notes
        -----
        Use this method in async contexts to avoid blocking.
        """
        return await self._make_request('POST', endpoint, data)

    def put_request(self, endpoint, data):
        """
        Synchronous PUT request.
        
        Parameters
        ----------
        endpoint : str
            API endpoint path.
        data : dict
            JSON-serializable request data.
        
        Returns
        -------
        dict
            Parsed JSON response.
        """
        return asyncio.run(self._make_request('PUT', endpoint, data))

    def delete_request(self, endpoint):
        """
        Synchronous DELETE request.
        
        Parameters
        ----------
        endpoint : str
            API endpoint path.
        
        Returns
        -------
        dict
            Parsed JSON response.
        """
        return asyncio.run(self._make_request('DELETE', endpoint))
