"""
TCP client module for network communication and data processing.

This module provides components for TCP-based network communication,
including heartbeat monitoring, data processing, and memory management.

Modules
-------
application_processor : Application-level data block processing
est : Example and test utilities
heart_beat : TCP heartbeat monitoring
memory_pool : Dual-thread memory pool management
tcp_data_client : TCP data client implementation

Notes
-----
This module is designed for high-performance TCP data reception
and processing with separate threads for network I/O and application
processing.

Examples
--------
>>> from .tcp_data_client import TCPDataClient
>>> from .application_processor import ApplicationProcessor
>>> 
>>> # Create a TCP client
>>> client = TCPDataClient(host='127.0.0.1', port=8888, heartbeat_msg='PING')
>>> 
>>> # Create an application processor
>>> processor = ApplicationProcessor(client.memory_pool)
"""

from .application_processor import ApplicationProcessor
from .heart_beat import TCPHeartbeat
from .tcp_data_client import TCPDataClient

__all__ = [
    'ApplicationProcessor',
    'TCPHeartbeat',
    'TCPDataClient',
]

__version__ = '1.0.0'