import asyncio
import threading
import time
from typing import Optional, Deque, List, Callable, Any
from collections import deque
import logging

logger = logging.getLogger(__name__)

from .memory_pool import DualThreadMemoryPool


class ApplicationProcessor:
    """
    Application processor for handling data blocks from memory pool.
    
    This class provides an interface for external applications to process
    data blocks retrieved from a dual-thread memory pool. It manages
    block fetching, processing, and statistics tracking.
    
    Attributes
    ----------
    memory_pool : DualThreadMemoryPool
        The memory pool instance for block management.
    stats : dict
        Statistics dictionary containing:
        - blocks_processed: Number of blocks successfully processed
        - total_bytes: Total bytes processed
        - processing_errors: Number of processing errors encountered
        
    Examples
    --------
    >>> from .memory_pool import DualThreadMemoryPool
    >>> memory_pool = DualThreadMemoryPool(block_count=50)
    >>> processor = ApplicationProcessor(memory_pool)
    >>> 
    >>> def my_processor(data_view):
    ...     return f"Processed {len(data_view)} bytes"
    >>> 
    >>> # Process a single block
    >>> block_index = processor.fetch_block(timeout_ms=100)
    >>> if block_index is not None:
    ...     success = processor.process_block(block_index, my_processor)
    """
    
    def __init__(self, memory_pool: DualThreadMemoryPool):
        """
        Initialize the application processor.
        
        Parameters
        ----------
        memory_pool : DualThreadMemoryPool
            The memory pool instance to use for block management.
            
        Notes
        -----
        The processor maintains its own statistics separate from the
        memory pool statistics. This allows for application-level
        monitoring independent of the underlying memory management.
        """
        self.memory_pool = memory_pool
        self.stats = {
            'blocks_processed': 0,
            'total_bytes': 0,
            'processing_errors': 0,
        }

    def fetch_block(self, timeout_ms: int = 100) -> Optional[int]:
        """
        Fetch a filled block from the memory pool.
        
        This method polls the memory pool for filled blocks within the
        specified timeout period. It uses a busy-wait approach with
        short sleeps to avoid excessive CPU usage.
        
        Parameters
        ----------
        timeout_ms : int, optional
            Maximum time to wait for a block, in milliseconds.
            Default is 100ms.
            
        Returns
        -------
        Optional[int]
            The index of the fetched block, or None if no block
            is available within the timeout period.
            
        Notes
        -----
        The method uses a polling interval of 1ms to balance between
        responsiveness and CPU usage. For high-throughput applications,
        consider using a smaller timeout value or implementing a
        callback-based notification mechanism.
        
        See Also
        --------
        process_block : Process a fetched block with a custom function.
        continuous_processing : Continuously fetch and process blocks.
        """
        start_time = time.time()

        while True:
            block_index = self.memory_pool.take_filled_block()
            if block_index is not None:
                return block_index

            elapsed = (time.time() - start_time) * 1000
            if elapsed >= timeout_ms:
                return None

            time.sleep(0.001)

    def process_block(self, block_index: int, processor_func: Callable[[memoryview], Any]) -> bool:
        """
        Process a data block with a custom processor function.
        
        This method retrieves data from the specified block, applies
        the processor function, updates statistics, and marks the block
        for recycling. Error handling is built-in to ensure blocks are
        properly recycled even when processing fails.
        
        Parameters
        ----------
        block_index : int
            Index of the block to process.
        processor_func : Callable[[memoryview], Any]
            Function that takes a memoryview of the block data and
            returns any value. The return value is currently ignored
            but can be used for application-specific purposes.
            
        Returns
        -------
        bool
            True if processing succeeded, False otherwise.
            
        Raises
        ------
        None
            All exceptions are caught and logged internally.
            
        Notes
        -----
        The block is always marked for recycling after processing,
        regardless of success or failure. This ensures memory pool
        consistency and prevents memory leaks.
        
        The processor function should be designed to handle memoryview
        objects efficiently, as they provide zero-copy access to the
        underlying data.
        
        See Also
        --------
        fetch_block : Get a block index before processing.
        continuous_processing : Automated block processing loop.
        """
        try:
            data_view = self.memory_pool.get_block_data(block_index)
            if data_view is None:
                logger.error(f"No data in block {block_index}")
                return False

            result = processor_func(data_view)

            self.stats['blocks_processed'] += 1
            self.stats['total_bytes'] += len(data_view)

            self.memory_pool.mark_for_recycle(block_index)

            return True

        except Exception as e:
            logger.error(f"Error processing block {block_index}: {e}")
            self.stats['processing_errors'] += 1
            self.memory_pool.mark_for_recycle(block_index)

            return False

    def continuous_processing(self, processor_func: Callable[[memoryview], Any], 
                            check_interval_ms: int = 10) -> None:
        """
        Continuously fetch and process blocks in an infinite loop.
        
        This method implements a continuous processing loop that fetches
        blocks and processes them using the provided function. It's
        designed to run in a separate thread for background processing.
        
        Parameters
        ----------
        processor_func : Callable[[memoryview], Any]
            Function to process each block's data.
        check_interval_ms : int, optional
            Polling interval for checking new blocks, in milliseconds.
            Default is 10ms.
            
        Returns
        -------
        None
            This method runs indefinitely until interrupted.
            
        Notes
        -----
        This method is intended to run in a daemon thread. It will
        continue running until the thread is interrupted or the
        program exits.
        
        The check interval controls how frequently the method polls
        for new blocks. Smaller intervals provide lower latency but
        higher CPU usage. For most applications, 10-50ms provides
        a good balance.
        
        Warning
        -------
        This method contains an infinite loop and should only be
        called from a thread that can be properly terminated.
        
        See Also
        --------
        fetch_block : Method used internally to get blocks.
        process_block : Method used internally to process blocks.
        """
        while True:
            block_index = self.fetch_block(timeout_ms=check_interval_ms)
            if block_index is not None:
                self.process_block(block_index, processor_func)
            else:
                time.sleep(check_interval_ms / 1000)
