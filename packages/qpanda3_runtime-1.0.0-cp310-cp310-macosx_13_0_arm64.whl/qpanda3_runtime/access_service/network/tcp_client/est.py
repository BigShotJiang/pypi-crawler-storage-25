import asyncio
import threading
from typing import Optional, Deque, List
from collections import deque
import logging

from .memory_pool import DualThreadMemoryPool
from .application_processor import ApplicationProcessor
from .tcp_data_client import TCPDataClient

logger = logging.getLogger(__name__)


def external_application_thread(memory_pool: DualThreadMemoryPool, processor: ApplicationProcessor) -> None:
    """
    External application thread for processing data blocks.
    
    This function runs in a separate thread and uses an ApplicationProcessor
    to continuously process data blocks from a memory pool. It provides
    a template for implementing custom data processing logic.
    
    Parameters
    ----------
    memory_pool : DualThreadMemoryPool
        The memory pool instance for block management.
    processor : ApplicationProcessor
        The application processor instance for block processing.
        
    Returns
    -------
    None
        This function runs indefinitely in a separate thread.
        
    Notes
    -----
    This is a template function that demonstrates how to implement
    a data processing thread. The actual processing logic should be
    customized based on application requirements.
    
    The function uses a simple example processing function that
    demonstrates basic data access patterns. In production code,
    this should be replaced with actual business logic.
    
    Examples
    --------
    >>> from .memory_pool import DualThreadMemoryPool
    >>> from .application_processor import ApplicationProcessor
    >>> 
    >>> memory_pool = DualThreadMemoryPool(block_count=50)
    >>> processor = ApplicationProcessor(memory_pool)
    >>> 
    >>> # Start the external application thread
    >>> import threading
    >>> thread = threading.Thread(
    ...     target=external_application_thread,
    ...     args=(memory_pool, processor),
    ...     daemon=True
    ... )
    >>> thread.start()
    """
    logger.info("External application thread started")

    def process_data(data_view: memoryview) -> str:
        """
        Example data processing function.
        
        This is a template function that demonstrates how to process
        data blocks. In production code, replace this with actual
        business logic.
        
        Parameters
        ----------
        data_view : memoryview
            Memory view of the data block to process.
            
        Returns
        -------
        str
            Processing result message.
            
        Notes
        -----
        This example function demonstrates basic data access patterns
        using memoryview. It processes data in chunks to simulate
        CPU-intensive operations.
        
        Warning
        -------
        This is example code only. Replace with actual processing logic
        for production use.
        """
        data_size = len(data_view)

        # Example: Simple data processing
        # Note: This is CPU-intensive and runs in a separate thread
        processed_bytes = 0
        for i in range(0, min(1000, data_size), 100):
            # Simulate processing (read partial data)
            chunk = data_view[i: i + 100]
            processed_bytes += len(chunk)

        return f"Processed {data_size} bytes"

    # Start continuous processing
    processor.continuous_processing(process_data, check_interval_ms=50)


async def main() -> None:
    """
    Complete example: Start a dual-thread TCP client.
    
    This function demonstrates how to set up and run a complete
    TCP data client with external application processing thread.
    It creates a TCP client, connects to a server, starts an
    application processing thread, and runs the receive loop.
    
    Returns
    -------
    None
    
    Notes
    -----
    This is an example function that demonstrates the complete
    workflow of the TCP data client system. It shows:
    1. TCP client initialization and connection
    2. External application thread startup
    3. Main receive loop execution
    4. Proper shutdown and statistics display
    
    The example uses localhost (127.0.0.1) and port 8888 for
    demonstration purposes. In production code, these should be
    configured appropriately.
    
    The function runs for 120 seconds by default, then displays
    statistics. It can be interrupted with Ctrl+C.
    
    Examples
    --------
    >>> import asyncio
    >>> asyncio.run(main())
    """
    # Create TCP client
    client = TCPDataClient(host='127.0.0.1', port=8888)

    # Connect to server
    if not await client.connect():
        logger.error("Failed to connect")
        return

    # Start external application thread
    import threading
    app_thread = threading.Thread(
        target=external_application_thread,
        args=(client.memory_pool, client.app_processor),
        daemon=True,
        name="AppProcessor"
    )
    app_thread.start()

    # Start TCP receive (main thread)
    try:
        await client.receive_loop()
        await asyncio.sleep(120)
    except KeyboardInterrupt:
        logger.info("Received interrupt, stopping...")
    finally:
        await client.stop()

    # Display final statistics
    stats = client.memory_pool.get_stats()
    app_stats = client.app_processor.stats

    print("\n=== Final Statistics ===")
    print(f"Memory Pool: {stats}")
    print(f"Application: {app_stats}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())