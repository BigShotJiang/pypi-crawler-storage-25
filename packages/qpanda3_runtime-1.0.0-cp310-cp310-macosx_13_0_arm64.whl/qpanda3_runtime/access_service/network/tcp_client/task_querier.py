from .heart_beat import TCPHeartbeat


class TaskQuerier:
    """
    Task query client with heartbeat mechanism for TCP connections.
    
    This class manages task query operations with automatic heartbeat
    to maintain connection health with the server.
    
    Attributes
    ----------
    host : str
        Server hostname or IP address.
    port : int
        Server port number.
    heart_beat : TCPHeartbeat
        Heartbeat manager instance.
    
    Notes
    -----
    - Automatically starts heartbeat on initialization.
    - Stops heartbeat on destruction.
    - Designed for long-running task query operations.
    
    Examples
    --------
    >>> querier = TaskQuerier("localhost", 8080, "HEARTBEAT")
    >>> # Task query operations would be implemented here
    """
    
    def __init__(self, host: str, port: int, heartbeat_msg: str):
        """
        Initialize task querier with server connection details.
        
        Parameters
        ----------
        host : str
            Server hostname or IP address.
        port : int
            Server port number.
        heartbeat_msg : str
            Message to send for heartbeat.
            
        Notes
        -----
        - Creates and starts TCP heartbeat immediately.
        - Heartbeat runs in background thread.
        """
        self.host = host
        self.port = port
        self.heart_beat = TCPHeartbeat(self.host, self.port, heartbeat_msg=heartbeat_msg)
        self.heart_beat.start()

    def __del__(self):
        """
        Destructor to ensure heartbeat is stopped.
        
        Notes
        -----
        - Called automatically when object is garbage collected.
        - Ensures cleanup of heartbeat resources.
        """
        self.stop()

    def stop(self):
        """
        Stop the heartbeat mechanism.
        
        Notes
        -----
        - Should be called explicitly for clean shutdown.
        - Also called automatically in destructor.
        """
        if hasattr(self, 'heart_beat'):
            self.heart_beat.stop()