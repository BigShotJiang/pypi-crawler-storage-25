import asyncio
import threading
from typing import Optional, Deque, List
from collections import deque
import logging

from .memory_pool import DualThreadMemoryPool
from .application_processor import ApplicationProcessor

logger = logging.getLogger(__name__)


class TCPDataClient:
    """
    Asynchronous TCP data client for high-throughput data reception.
    
    This client receives data over TCP, buffers it in a memory pool,
    and processes it through an application processor.
    
    Attributes
    ----------
    host : str
        Server hostname or IP address.
    port : int
        Server port number.
    memory_pool : DualThreadMemoryPool
        Memory pool for data buffering.
    app_processor : ApplicationProcessor
        Processor for handling received data.
    reader : Optional[asyncio.StreamReader]
        Async stream reader for TCP connection.
    writer : Optional[asyncio.StreamWriter]
        Async stream writer for TCP connection.
    running : bool
        Flag indicating if client is active.
    
    Notes
    -----
    - Uses asyncio for non-blocking I/O operations.
    - Implements length-prefixed protocol for data framing.
    - Integrates with memory pool for efficient buffer management.
    
    Examples
    --------
    >>> client = TCPDataClient("localhost", 8080, "HEARTBEAT")
    >>> # Connect and start receiving
    >>> # await client.connect()
    >>> # await client.receive_loop()
    """
    
    def __init__(self, host: str, port: int, heartbeat_msg: str):
        """
        Initialize TCP data client.
        
        Parameters
        ----------
        host : str
            Server hostname or IP address.
        port : int
            Server port number.
        heartbeat_msg : str
            Heartbeat message (currently unused in this class).
            
        Notes
        -----
        - Creates memory pool with 50 blocks.
        - Initializes application processor with memory pool.
        - Connection must be established via `connect()` method.
        """
        self.host = host
        self.port = port

        self.memory_pool = DualThreadMemoryPool(block_count=50)
        self.app_processor = ApplicationProcessor(self.memory_pool)

        self.reader: Optional[asyncio.StreamReader] = None
        self.writer: Optional[asyncio.StreamWriter] = None

        self.running = False

    async def connect(self):
        """
        Establish TCP connection to server.
        
        Returns
        -------
        bool
            True if connection successful, False otherwise.
            
        Notes
        -----
        - Uses asyncio.open_connection for non-blocking connection.
        - Sets up reader and writer streams for data transfer.
        """
        try:
            self.reader, self.writer = await asyncio.open_connection(
                self.host, self.port
            )
            return True
        except Exception as e:
            return False

    async def receive_loop(self):
        """
        Main receive loop for continuous data reception.
        
        Notes
        -----
        - Implements length-prefixed protocol (4-byte header).
        - Sends 'OK' acknowledgment after each received message.
        - Handles connection errors and incomplete reads gracefully.
        - Runs until `stop()` is called or connection fails.
        
        Raises
        ------
        RuntimeError
            If called without establishing connection first.
        """
        if not self.reader:
            logger.error("Not connected")
            return

        self.running = True

        while self.running:
            try:
                header = await self.reader.readexactly(4)
                data_length = int.from_bytes(header, 'big')

                data = await self.reader.readexactly(data_length)

                await self._process_received_data(data)

                self.writer.write(b'OK')
                await self.writer.drain()

            except asyncio.IncompleteReadError:
                logger.warning("Connection closed by server")
                break
            except Exception as e:
                logger.error(f"Receive error: {e}")
                break

        self.running = False

    async def _process_received_data(self, data: bytes):
        """
        Process received data by storing in memory pool.
        
        Parameters
        ----------
        data : bytes
            Received data to process.
            
        Notes
        -----
        - Attempts to allocate a free block from memory pool.
        - Drops data if no free blocks available.
        - Marks block for recycling if fill operation fails.
        """
        block_index = self.memory_pool.take_free_block()
        if block_index is None:
            logger.warning("No free blocks, dropping data")
            return

        # Fill data into block
        if not self.memory_pool.fill_and_queue(block_index, data):
            logger.error(f"Failed to fill block {block_index}")
            self.memory_pool.mark_for_recycle(block_index)

        # stats = self.memory_pool.get_stats()
        # if stats['free_blocks'] < 5:
        #     logger.warning(f"Low free blocks: {stats['free_blocks']}")

    async def stop(self):
        """
        Stop the client and close connection.
        
        Notes
        -----
        - Sets running flag to False to exit receive loop.
        - Closes writer stream and waits for closure.
        - Should be called for clean shutdown.
        """
        self.running = False

        if self.writer:
            self.writer.close()
            await self.writer.wait_closed()

