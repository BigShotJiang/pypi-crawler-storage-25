import asyncio
import threading
import time
from typing import Optional, Deque, List
from collections import deque
import logging

logger = logging.getLogger(__name__)


class DualThreadMemoryPool:
    """
    A dual-thread memory pool for efficient data buffer management.
    
    This class implements a memory pool with separate threads for allocation
    and recycling, designed for high-throughput TCP data processing.
    
    Attributes
    ----------
    BLOCK_SIZE : int
        Size of each memory block in bytes (default: 10MB).
    block_count : int
        Total number of memory blocks in the pool.
    free_blocks : Deque[int]
        Queue of indices for available blocks.
    filled_blocks : Deque[int]
        Queue of indices for blocks containing data.
    blocks : List[memoryview]
        List of memoryview objects for each block.
    data_sizes : List[int]
        List of data sizes for each block.
    
    Notes
    -----
    - Uses separate threads for memory recycling to avoid blocking main operations.
    - Thread-safe operations for concurrent access from multiple threads.
    - Memory blocks are recycled by zeroing out content before reuse.
    
    Examples
    --------
    >>> pool = DualThreadMemoryPool(block_count=50)
    >>> block_index = pool.take_free_block()
    >>> if block_index is not None:
    ...     success = pool.fill_and_queue(block_index, b"test data")
    """
    
    BLOCK_SIZE = 10 * 1024 * 1024  # 10MB

    def __init__(self, block_count: int = 100):
        """
        Initialize the memory pool with specified number of blocks.
        
        Parameters
        ----------
        block_count : int, optional
            Number of memory blocks to allocate (default: 100).
            
        Notes
        -----
        - Each block is allocated with size `BLOCK_SIZE`.
        - Starts a background thread for memory recycling.
        """
        self.block_count = block_count

        self.free_blocks: Deque[int] = deque()
        self.filled_blocks: Deque[int] = deque()

        self.blocks: List[memoryview] = []
        self.data_sizes: List[int] = []

        self._recycle_queue: Deque[int] = deque()
        self._recycle_lock = threading.Lock()

        self._init_pool()

        self._start_recycle_thread()

    def _init_pool(self):
        """
        Initialize memory blocks and populate free blocks queue.
        
        Notes
        -----
        - Creates bytearray objects and wraps them with memoryview.
        - All blocks start with zero data size.
        """
        for i in range(self.block_count):
            block = bytearray(self.BLOCK_SIZE)
            self.blocks.append(memoryview(block))
            self.data_sizes.append(0)

            self.free_blocks.append(i)


    def take_free_block(self) -> Optional[int]:
        """
        Get an available memory block from the pool.
        
        Returns
        -------
        Optional[int]
            Index of the free block, or None if no blocks are available.
            
        Notes
        -----
        - Removes the block from free_blocks queue.
        - Caller is responsible for filling the block with data.
        """
        if self.free_blocks:
            return self.free_blocks.popleft()
        return None

    def fill_and_queue(self, block_index: int, data: bytes) -> bool:
        """
        Fill a block with data and move it to filled queue.
        
        Parameters
        ----------
        block_index : int
            Index of the block to fill.
        data : bytes
            Data to write into the block.
            
        Returns
        -------
        bool
            True if successful, False if block index is invalid or data is too large.
            
        Notes
        -----
        - Data size must not exceed BLOCK_SIZE.
        - After filling, block is moved to filled_blocks queue for processing.
        """
        if block_index < 0 or block_index >= self.block_count:
            return False

        data_size = len(data)
        if data_size > self.BLOCK_SIZE:
            logger.error(f"Data too large: {data_size}B")
            return False

        self.blocks[block_index][0:data_size] = data
        self.data_sizes[block_index] = data_size
        self.filled_blocks.append(block_index)

        # logger.debug(f"TCP: Filled block {block_index} with {data_size}B")
        return True

    def take_filled_block(self) -> Optional[int]:
        """
        Get a block that contains data ready for processing.
        
        Returns
        -------
        Optional[int]
            Index of a filled block, or None if no filled blocks are available.
            
        Notes
        -----
        - Removes the block from filled_blocks queue.
        - Caller should process data and then mark block for recycling.
        """
        if self.filled_blocks:
            return self.filled_blocks.popleft()
        return None

    def get_block_data(self, block_index: int) -> Optional[memoryview]:
        """
        Get data from a specific block.
        
        Parameters
        ----------
        block_index : int
            Index of the block to retrieve data from.
            
        Returns
        -------
        Optional[memoryview]
            Memoryview of the data, or None if block index is invalid or empty.
            
        Notes
        -----
        - Returns a memoryview for zero-copy access to the data.
        - Does not remove the block from any queue.
        """
        if 0 <= block_index < self.block_count:
            data_size = self.data_sizes[block_index]
            if data_size > 0:
                return self.blocks[block_index][0:data_size]
        return None

    def mark_for_recycle(self, block_index: int):
        """
        Schedule a block for recycling.
        
        Parameters
        ----------
        block_index : int
            Index of the block to recycle.
            
        Notes
        -----
        - Adds block to recycle queue for background processing.
        - Thread-safe operation.
        """
        with self._recycle_lock:
            self._recycle_queue.append(block_index)

    def _start_recycle_thread(self):
        """
        Start background thread for memory recycling.
        
        Notes
        -----
        - Creates a daemon thread that continuously recycles blocks.
        - Thread sleeps briefly when no blocks need recycling.
        """
        def recycle_worker():
            while True:
                block_index = self._take_from_recycle_queue()
                if block_index is not None:
                    self._recycle_block(block_index)
                else:
                    time.sleep(0.01)

        recycle_thread = threading.Thread(
            target=recycle_worker,
            daemon=True,
            name="MemoryRecycler"
        )
        recycle_thread.start()

    def _take_from_recycle_queue(self) -> Optional[int]:
        """
        Get next block from recycle queue.
        
        Returns
        -------
        Optional[int]
            Index of block to recycle, or None if queue is empty.
            
        Notes
        -----
        - Thread-safe operation using lock.
        """
        with self._recycle_lock:
            if self._recycle_queue:
                return self._recycle_queue.popleft()
        return None

    def _recycle_block(self, block_index: int):
        """
        Recycle a memory block by zeroing it and returning to free pool.
        
        Parameters
        ----------
        block_index : int
            Index of the block to recycle.
            
        Notes
        -----
        - Zeroes out the entire block for security.
        - Resets data size to 0.
        - Adds block back to free_blocks queue.
        """
        self.blocks[block_index][0:self.BLOCK_SIZE] = b'\x00' * self.BLOCK_SIZE
        self.data_sizes[block_index] = 0
        self.free_blocks.append(block_index)

    def get_stats(self) -> dict:
        """
        Get current statistics of the memory pool.
        
        Returns
        -------
        dict
            Dictionary containing pool statistics:
            - free_blocks: Number of available blocks
            - filled_blocks: Number of blocks with data
            - pending_recycle: Number of blocks waiting for recycling
            - total_blocks: Total number of blocks in pool
            
        Notes
        -----
        - Thread-safe operation for recycle queue count.
        """
        with self._recycle_lock:
            recycle_count = len(self._recycle_queue)

        return {
            'free_blocks': len(self.free_blocks),
            'filled_blocks': len(self.filled_blocks),
            'pending_recycle': recycle_count,
            'total_blocks': self.block_count,
        }