import socket
import threading
import time
import logging
from typing import Optional, Callable, Any


class TCPHeartbeat:
    """
    TCP heartbeat monitor for connection health checking.
    
    This class implements a background thread that periodically sends
    heartbeat messages to a TCP server and monitors the connection
    status. It provides callback mechanisms for handling heartbeat
    success and failure events.
    
    Attributes
    ----------
    host : str
        Target server hostname or IP address.
    port : int
        Target server port number.
    heartbeat_msg : str
        Message to send as heartbeat.
    heartbeat_interval : float
        Interval between heartbeat sends, in seconds.
    timeout : float
        Socket timeout for connection attempts, in seconds.
    on_heartbeat_failed : Optional[Callable[[str], Any]]
        Callback function invoked when heartbeat fails.
    on_heartbeat_success : Optional[Callable[[], Any]]
        Callback function invoked when heartbeat succeeds.
    enable_logging : bool
        Whether to enable logging for this instance.
    log_level : int
        Logging level for this instance.
    logger_name : Optional[str]
        Custom logger name, defaults to "TCPHeartbeat_host:port".
        
    Examples
    --------
    >>> heartbeat = TCPHeartbeat(
    ...     host="127.0.0.1",
    ...     port=8080,
    ...     heartbeat_msg="PING",
    ...     heartbeat_interval=10.0,
    ...     timeout=5.0
    ... )
    >>> 
    >>> def on_failure(reason: str):
    ...     print(f"Heartbeat failed: {reason}")
    >>> 
    >>> def on_success():
    ...     print("Heartbeat succeeded")
    >>> 
    >>> heartbeat.on_heartbeat_failed = on_failure
    >>> heartbeat.on_heartbeat_success = on_success
    >>> heartbeat.start()
    """
    
    def __init__(self,
                 host: str,
                 port: int,
                 heartbeat_msg: str = "HEARTBEAT",
                 heartbeat_interval: float = 5.0,
                 timeout: float = 3.0,
                 on_heartbeat_failed: Optional[Callable[[str], Any]] = None,
                 on_heartbeat_success: Optional[Callable[[], Any]] = None,
                 enable_logging: bool = True,
                 log_level: int = logging.INFO,
                 logger_name: Optional[str] = None):

        """
        Initialize the TCP heartbeat monitor.
        
        Parameters
        ----------
        host : str
            Target server hostname or IP address.
        port : int
            Target server port number.
        heartbeat_msg : str, optional
            Message to send as heartbeat. Default is "HEARTBEAT".
        heartbeat_interval : float, optional
            Interval between heartbeat sends, in seconds. Default is 5.0.
        timeout : float, optional
            Socket timeout for connection attempts, in seconds. Default is 3.0.
        on_heartbeat_failed : Optional[Callable[[str], Any]], optional
            Callback function invoked when heartbeat fails consecutively.
        on_heartbeat_success : Optional[Callable[[], Any]], optional
            Callback function invoked when heartbeat succeeds.
        enable_logging : bool, optional
            Whether to enable logging. Default is True.
        log_level : int, optional
            Logging level. Default is logging.INFO.
        logger_name : Optional[str], optional
            Custom logger name. If None, uses "TCPHeartbeat_host:port".
            
        Notes
        -----
        The heartbeat monitor starts in a stopped state. Call `start()`
        to begin sending heartbeats.
        
        The failure callback is triggered after 3 consecutive failures
        by default. This threshold is hardcoded in the implementation.
        
        Logging can be disabled entirely by setting `enable_logging=False`,
        which improves performance in high-frequency monitoring scenarios.
        """
        self.host = host
        self.port = port
        self.heartbeat_msg = heartbeat_msg
        self.heartbeat_interval = heartbeat_interval
        self.timeout = timeout

        self.on_heartbeat_failed = on_heartbeat_failed
        self.on_heartbeat_success = on_heartbeat_success

        self._is_running = False
        self._heartbeat_thread: Optional[threading.Thread] = None

        self._socket: Optional[socket.socket] = None

        self.enable_logging = enable_logging
        self.logger = self._setup_logger(logger_name, log_level)

        if self.enable_logging:
            self.logger.info(f"TCP heartbeat monitor initialized for {host}:{port}")
            self.logger.info(f"Heartbeat interval: {heartbeat_interval}s, timeout: {timeout}s")

    def _setup_logger(self, logger_name: Optional[str], log_level: int) -> logging.Logger:
        if not self.enable_logging:
            logger = logging.getLogger(__name__ + '.null')
            logger.addHandler(logging.NullHandler())
            logger.disabled = True
            return logger

        if logger_name:
            name = logger_name
        else:
            name = f"TCPHeartbeat_{self.host}:{self.port}"

        logger = logging.getLogger(name)

        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(log_level)
            logger.propagate = False

        return logger

    def _log(self, level: int, message: str, *args):
        if self.enable_logging and self.logger.isEnabledFor(level):
            self.logger.log(level, message, *args)

    def _create_connection(self) -> bool:
        try:
            self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._socket.settimeout(self.timeout)
            self._socket.connect((self.host, self.port))
            self._log(logging.INFO, f"Success in connecting the server {self.host}:{self.port}")
            return True
        except Exception as e:
            self._log(logging.ERROR, f"Failed to connect the server: {e}")
            self._cleanup_socket()
            return False

    def _cleanup_socket(self):
        if self._socket:
            try:
                self._socket.close()
            except:
                pass
            finally:
                self._socket = None

    def _heartbeat_worker(self):
        self._log(logging.INFO, "HeartBeat thread start running")

        consecutive_failures = 0
        max_consecutive_failures = 3

        while self._is_running:
            try:
                if self._socket is None:
                    if not self._create_connection():
                        time.sleep(self.heartbeat_interval)
                        continue

                self._log(logging.DEBUG, f"Send heartbeat_msg: {self.heartbeat_msg}")
                self._socket.sendall(self.heartbeat_msg)

                # response = self._socket.recv(1024)
                # if response:
                #     self._log(logging.DEBUG, f"Received heartbeat response: {response}")

                consecutive_failures = 0
                if self.on_heartbeat_success:
                    try:
                        self.on_heartbeat_success()
                    except Exception as e:
                        self._log(logging.ERROR, f"Failed to run callback function on_heartbeat_success: {e}")

                self._log(logging.DEBUG, f"Success in sending heartbeat, wait {self.heartbeat_interval} seconds")

            except socket.timeout:
                self._log(logging.WARNING, "Heartbeat timeout occurred")
                consecutive_failures += 1
            except (socket.error, ConnectionError, OSError) as e:
                self._log(logging.ERROR, f"Failed to send heartbeat msg: {e}")
                consecutive_failures += 1
                self._cleanup_socket()
            except Exception as e:
                self._log(logging.ERROR, f"Unknown error: {e}")
                consecutive_failures += 1

            if consecutive_failures >= max_consecutive_failures:
                self._log(logging.ERROR, f"Heartbeat failed {consecutive_failures} times consecutively, triggering failure callback")
                if self.on_heartbeat_failed:
                    try:
                        self.on_heartbeat_failed(f"Heartbeat failed {consecutive_failures} times consecutively.")
                    except Exception as e:
                        self._log(logging.ERROR, f"Heartbeat failure callback execution failed: {e}")
                consecutive_failures = 0

            if self._is_running:
                time.sleep(self.heartbeat_interval)

        self._log(logging.INFO, "Stopped heartbeat thread")
        self._cleanup_socket()

    def start(self) -> None:
        """
        Start the heartbeat monitoring thread.
        
        This method creates and starts a daemon thread that periodically
        sends heartbeat messages to the target server. If the thread is
        already running, this method does nothing.
        
        Returns
        -------
        None
        
        Notes
        -----
        The heartbeat thread runs as a daemon thread, which means it will
        automatically terminate when the main program exits.
        
        The thread name is set to "HeartbeatThread_host:port" for
        identification in thread dumps and debugging tools.
        
        See Also
        --------
        stop : Stop the heartbeat monitoring thread.
        is_running : Check if the heartbeat thread is running.
        """
        if self._is_running:
            self._log(logging.WARNING, "Heartbeat thread is already running")
            return

        self._is_running = True
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_worker,
            name=f"HeartbeatThread_{self.host}:{self.port}",
            daemon=True
        )
        self._heartbeat_thread.start()
        self._log(logging.INFO, "Started heartbeat thread")

    def stop(self) -> None:
        """
        Stop the heartbeat monitoring thread.
        
        This method signals the heartbeat thread to stop and waits for
        it to terminate. It also cleans up the socket connection.
        
        Returns
        -------
        None
        
        Notes
        -----
        The method uses a join timeout of twice the heartbeat interval
        to allow the thread to complete its current cycle. If the thread
        doesn't terminate within this timeout, it may continue running
        as a daemon thread until program exit.
        
        Socket cleanup is performed regardless of whether the thread
        terminates successfully, ensuring no resource leaks.
        
        See Also
        --------
        start : Start the heartbeat monitoring thread.
        is_running : Check if the heartbeat thread is running.
        """
        if not self._is_running:
            self._log(logging.WARNING, "Heartbeat thread is not running")
            return

        self._is_running = False
        self._log(logging.INFO, "Stopping heartbeat monitor...")

        if self._heartbeat_thread and self._heartbeat_thread.is_alive():
            self._heartbeat_thread.join(timeout=self.heartbeat_interval * 2)

        self._cleanup_socket()
        self._log(logging.INFO, "Heartbeat monitor stopped")

    def is_running(self) -> bool:
        """
        Check if the heartbeat monitoring thread is running.
        
        Returns
        -------
        bool
            True if the heartbeat thread is running, False otherwise.
            
        Notes
        -----
        This method only checks the internal running flag. It does not
        verify that the thread is actually alive or functioning correctly.
        
        See Also
        --------
        start : Start the heartbeat monitoring thread.
        stop : Stop the heartbeat monitoring thread.
        """
        return self._is_running

    def get_status(self) -> dict:
        """
        Get the current status of the heartbeat monitor.
        
        Returns
        -------
        dict
            Dictionary containing status information with keys:
            - host: Target server hostname
            - port: Target server port
            - is_running: Whether the heartbeat thread is running
            - heartbeat_interval: Current heartbeat interval in seconds
            - timeout: Current socket timeout in seconds
            - enable_logging: Whether logging is enabled
            - thread_alive: Whether the heartbeat thread is alive
            - socket_connected: Whether a socket connection exists
            
        Notes
        -----
        The status dictionary provides a snapshot of the monitor's
        current state. It can be used for monitoring, debugging, or
        integration with external monitoring systems.
        
        The 'thread_alive' field checks the actual thread state, while
        'is_running' reflects the internal control flag. These may differ
        during thread startup or shutdown.
        """
        return {
            "host": self.host,
            "port": self.port,
            "is_running": self._is_running,
            "heartbeat_interval": self.heartbeat_interval,
            "timeout": self.timeout,
            "enable_logging": self.enable_logging,
            "thread_alive": self._heartbeat_thread.is_alive() if self._heartbeat_thread else False,
            "socket_connected": self._socket is not None
        }

    def enable_logs(self, enabled: bool = True) -> None:
        """
        Enable or disable logging for this heartbeat monitor.
        
        Parameters
        ----------
        enabled : bool, optional
            Whether to enable logging. Default is True.
            
        Returns
        -------
        None
            
        Notes
        -----
        Disabling logging can improve performance in high-frequency
        monitoring scenarios or when integrating with external
        logging systems.
        
        When logging is disabled, all log messages are suppressed,
        including error messages. Consider implementing custom
        error handling if logging is disabled.
        """
        self.enable_logging = enabled
        if not enabled:
            self.logger.disabled = True
        else:
            self.logger.disabled = False

    def __del__(self):
        self.stop()

