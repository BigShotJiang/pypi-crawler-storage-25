import threading
import time

import socket
from builtins import bytes
from enum import Enum



class ByteBuffer:
    """
    Mutable byte buffer for building binary protocol messages.
    
    Provides chainable methods for appending different data types to a
    bytearray buffer. Used for constructing TCP messages in custom binary
    protocol.
    
    Parameters
    ----------
    initial_data : bytes, optional
        Initial byte data to populate the buffer (default: empty bytes).
    
    Attributes
    ----------
    _buffer : bytearray
        Internal mutable byte array.
    
    Examples
    --------
    >>> buffer = ByteBuffer()
    >>> buffer.append_int(42, 4, 'little').append_str('task_id')
    >>> bytes(buffer)
    b'\\x2a\\x00\\x00\\x00task_id'
    """
    
    def __init__(self, initial_data: bytes = b''):
        self._buffer = bytearray(initial_data)

    def append_int(self, value: int, byte_num, byteorder):
        """
        Append integer value to buffer.
        
        Parameters
        ----------
        value : int
            Integer value to append.
        byte_num : int
            Number of bytes for integer representation.
        byteorder : str
            Byte order ('little' or 'big').
        
        Returns
        -------
        ByteBuffer
            Self for method chaining.
        """
        tmp = value.to_bytes(length=byte_num, byteorder=byteorder)
        self._buffer.extend(tmp)
        return self

    def append_byte(self, value):
        """
        Append single byte to buffer.
        
        Parameters
        ----------
        value : bytes
            Single byte value (must be length 1).
        
        Returns
        -------
        ByteBuffer
            Self for method chaining.
        
        Raises
        ------
        AssertionError
            If value length is not exactly 1 byte.
        """
        assert len(value) == 1
        self._buffer.extend(value)
        return self

    def extend_bytes(self, bytes_):
        """
        Append raw bytes to buffer.
        
        Parameters
        ----------
        bytes_ : bytes
            Raw byte data to append.
        
        Returns
        -------
        ByteBuffer
            Self for method chaining.
        """
        self._buffer.extend(bytes_)
        return self

    def append_str(self, value: str, encoding='ascii'):
        """
        Append string to buffer with specified encoding.
        
        Parameters
        ----------
        value : str
            String to append.
        encoding : str, optional
            Character encoding (default: 'ascii').
        
        Returns
        -------
        ByteBuffer
            Self for method chaining.
        """
        tmp = value.encode(encoding=encoding)
        tmp = bytes(tmp)
        self._buffer.extend(tmp)
        return self

    def get_bytes(self) -> bytes:
        """
        Get immutable bytes representation of buffer.
        
        Returns
        -------
        bytes
            Immutable bytes containing all appended data.
        """
        return bytes(self._buffer)

    def __bytes__(self) -> bytes:
        """Return bytes representation (same as get_bytes())."""
        return self.get_bytes()

    def __len__(self) -> int:
        """Return current buffer length in bytes."""
        return len(self._buffer)

    def __repr__(self) -> str:
        """Return hexadecimal representation of buffer."""
        return f'ByteBuffer({self._buffer.hex()})'


class TcpMsgType(Enum):
    """
    TCP message types for quantum task query protocol.
    
    Defines the message type codes used in custom binary protocol for
    communicating with quantum computing backend services.
    
    Attributes
    ----------
    UNKNOW_MSG_TYPE : int
        Unknown or undefined message type (0).
    STATE_MSG : int
        State update message (1).
    RESULT_MSG : int
        Task result message (2).
    TASK_ID_MSG : int
        Task ID query message (3).
    RESULT_ACK_MSG : int
        Result acknowledgment message (4).
    """
    
    UNKNOW_MSG_TYPE = 0
    STATE_MSG = 1
    RESULT_MSG = 2
    TASK_ID_MSG = 3
    RESULT_ACK_MSG = 4




class QueryTaskMsg:
    """
    Message builder for quantum task query protocol.
    
    Constructs and parses binary messages for TCP-based quantum task queries.
    Implements custom protocol with header, body, and CRC sections.
    
    Parameters
    ----------
    task_id : str
        Unique identifier for quantum computing task.
    
    Attributes
    ----------
    MSG_HEAD_LEN : int
        Length of message header in bytes (constant: 4).
    MSG_HAD_FLAG : str
        Header flag string marking start of message ('***<').
    CRC_FLAG_LEN : int
        Length of CRC field in bytes (constant: 4).
    _task_id : str
        Task identifier.
    _query_msg : bytes
        Pre-built query message bytes.
    _ack_msg : bytes
        Pre-built acknowledgment message bytes.
    _heart_msg : bytes
        Pre-built heartbeat message bytes.
    
    Notes
    -----
    Message format: [HEADER_FLAG][TYPE][SN_ID][BODY_LEN][BODY][CRC]
    - HEADER_FLAG: 4-byte string '***<'
    - TYPE: 2-byte message type (TcpMsgType)
    - SN_ID: 2-byte sequence number
    - BODY_LEN: 4-byte body length
    - BODY: variable length message body
    - CRC: 4-byte body length (simple CRC)
    """
    
    MSG_HEAD_LEN = 4
    MSG_HAD_FLAG = '***<'
    CRC_FLAG_LEN = 4
    
    def __init__(self, task_id: str):
        self._task_id = task_id
        self._query_msg = self.build_query_msg()
        self._ack_msg = self.build_result_ack_msg()
        self._heart_msg = self._query_msg

    def task_id(self):
        """
        Get task identifier.
        
        Returns
        -------
        str
            Task ID string.
        """
        return self._task_id

    def get_query_msg(self):
        """
        Get pre-built query message.
        
        Returns
        -------
        bytes
            Binary query message ready for transmission.
        """
        return self._query_msg

    def get_ack_msg(self):
        """
        Get pre-built acknowledgment message.
        
        Returns
        -------
        bytes
            Binary acknowledgment message ready for transmission.
        """
        return self._ack_msg

    def get_heart_msg(self):
        """
        Get pre-built heartbeat message.
        
        Returns
        -------
        bytes
            Binary heartbeat message (same as query message).
        """
        return self._heart_msg

    @staticmethod
    def set_tcp_msg_head(res_buf: ByteBuffer, head_flag: str, type: TcpMsgType, sn_id: int, body_len: int):
        """
        Set TCP message header fields.
        
        Parameters
        ----------
        res_buf : ByteBuffer
            Target buffer for header data.
        head_flag : str
            Header flag string (e.g., '***<').
        type : TcpMsgType
            Message type enumeration.
        sn_id : int
            Sequence number for message tracking.
        body_len : int
            Length of message body in bytes.
        
        Returns
        -------
        ByteBuffer
            Updated buffer with header fields.
        """
        res_buf.append_str(head_flag)
        res_buf.append_int(type.value, 2, 'little')
        res_buf.append_int(sn_id, 2, 'little')
        res_buf.append_int(body_len, 4, 'little')
        return res_buf

    @staticmethod
    def set_msg_body(res_buf: ByteBuffer, msg_body: str):
        """
        Set TCP message body.
        
        Parameters
        ----------
        res_buf : ByteBuffer
            Target buffer for body data.
        msg_body : str
            Message body content as string.
        """
        res_buf.append_str(msg_body)

    @staticmethod
    def set_msg_crc(res_buffer: ByteBuffer, body_len: int, crc_len=CRC_FLAG_LEN):
        """
        Set CRC field for message.
        
        Parameters
        ----------
        res_buffer : ByteBuffer
            Target buffer for CRC data.
        body_len : int
            Body length to encode as CRC.
        crc_len : int, optional
            CRC field length in bytes (default: CRC_FLAG_LEN).
        
        Returns
        -------
        ByteBuffer
            Updated buffer with CRC field.
        
        Notes
        -----
        Uses simple CRC: body length encoded as 4-byte little-endian integer.
        """
        res_buffer.append_int(body_len, 4, 'little')
        return res_buffer

    @staticmethod
    def verify_msg_crc(msg: bytes, head_flag):
        """
        Verify message CRC integrity.
        
        Parameters
        ----------
        msg : bytes
            Complete message bytes.
        head_flag : str
            Header flag string used in message.
        
        Returns
        -------
        bool
            True if CRC matches body length, False otherwise.
        """
        len_msg = len(msg)
        len_extra = len(head_flag) + 2 + 2 + 4 + 4
        len_body = len_msg - len_extra
        if len_body < 0:
            return False
        crc_ = msg[-4:]
        crc_ = int.from_bytes(crc_, byteorder='little')
        return len_body == crc_

    @staticmethod
    def get_msg_body(msg: bytes, head_flag: str):
        """
        Extract message body from complete message.
        
        Parameters
        ----------
        msg : bytes
            Complete message bytes.
        head_flag : str
            Header flag string used in message.
        
        Returns
        -------
        bytes
            Message body bytes (excluding header and CRC).
        """
        len_extra = len(head_flag) + 2 + 2 + 4
        return msg[len_extra:-4]

    @staticmethod
    def build_msg(data: str, type: TcpMsgType):
        """
        Build complete TCP message from data and type.
        
        Parameters
        ----------
        data : str
            Message body content.
        type : TcpMsgType
            Message type enumeration.
        
        Returns
        -------
        bytes
            Complete binary message ready for transmission.
        """
        buffer = ByteBuffer()
        body_len = len(data)
        QueryTaskMsg.set_tcp_msg_head(buffer, head_flag='***<', type=type, sn_id=0, body_len=body_len)
        QueryTaskMsg.set_msg_body(buffer, data)
        QueryTaskMsg.set_msg_crc(buffer, body_len)
        return buffer.get_bytes()

    def build_query_msg(self):
        """
        Build task query message.
        
        Returns
        -------
        bytes
            Binary query message with TASK_ID_MSG type.
        """
        return QueryTaskMsg.build_msg(self._task_id, type=TcpMsgType.TASK_ID_MSG)

    def build_result_ack_msg(self):
        """
        Build result acknowledgment message.
        
        Returns
        -------
        bytes
            Binary acknowledgment message with RESULT_ACK_MSG type.
        """
        return QueryTaskMsg.build_msg(self._task_id, type=TcpMsgType.RESULT_ACK_MSG)

    def build_heart_msg(self):
        """
        Build heartbeat message.
        
        Returns
        -------
        bytes
            Binary heartbeat message (same as query message).
        """
        return self.build_query_msg()

    @staticmethod
    def get_result(response_msg: bytes):
        """
        Extract result from response message.
        
        Parameters
        ----------
        response_msg : bytes
            Complete response message bytes.
        
        Returns
        -------
        bytes
            Result body extracted from response.
        
        See Also
        --------
        get_msg_body : Generic message body extraction.
        """
        return QueryTaskMsg.get_msg_body(response_msg, '***<')




class TCPQueryTask:
    """
    TCP client for querying quantum task execution results.
    
    Implements custom binary protocol over TCP for efficient querying of
    quantum computing task results. Includes heartbeat mechanism to keep
    connections alive during long-running queries.
    
    Notes
    -----
    - Uses port+1 for TCP queries (e.g., if HTTP port is 8080, TCP port is 8081).
    - Implements simple timeout mechanism based on non-target message count.
    - Heartbeat daemon runs in background thread to prevent connection timeout.
    
    Examples
    --------
    >>> result = TCPQueryTask.query_task_tcp('localhost', 8080, 'task-123')
    >>> print(result)  # JSON string with task results
    """
    
    @staticmethod
    def drain_msg(client_socket, res: memoryview, msg_len: int, received_byte_total):
        """
        Drain complete message from socket into buffer.
        
        Parameters
        ----------
        client_socket : socket.socket
            Connected TCP socket.
        res : memoryview
            Memory view of target buffer.
        msg_len : int
            Total expected message length.
        received_byte_total : int
            Bytes already received.
        
        Returns
        -------
        int
            Total bytes received after draining.
        """
        while True:
            remain_len = msg_len - received_byte_total
            if remain_len == 0:
                break
            received_byte_total += client_socket.recv_into(res[received_byte_total:], remain_len)
        return received_byte_total

    @staticmethod
    def start_heartbeat_daemon_no_lock(shared_socket, heartmsg: bytes, interval):
        """
        Start heartbeat daemon thread for connection keep-alive.
        
        Parameters
        ----------
        shared_socket : socket.socket
            Socket to send heartbeat messages on.
        heartmsg : bytes
            Heartbeat message bytes.
        interval : int
            Heartbeat interval in seconds.
        
        Notes
        -----
        - Daemon thread automatically stops when socket connection breaks.
        - No synchronization locks used (assumes single-threaded socket access).
        """
        def heartbeat():
            while True:
                time.sleep(interval)
                try:
                    shared_socket.send(heartmsg)
                except:
                    break

        threading.Thread(target=heartbeat, daemon=True).start()
    
    @staticmethod
    def query_task_tcp(host: str, port: int, task_id: str, timeout=50):
        """
        Query quantum task results via TCP protocol.
        
        Establishes TCP connection, sends query message, waits for result,
        and returns decoded response. Includes error handling and timeout
        management.
        
        Parameters
        ----------
        host : str
            Server hostname or IP address.
        port : int
            Base HTTP port (TCP port will be port+1).
        task_id : str
            Unique task identifier to query.
        timeout : int, optional
            Socket timeout in seconds (default: 50).
        
        Returns
        -------
        str
            JSON string containing task results.
        
        Raises
        ------
        ConnectionRefusedError
            If server is not running or not listening.
        socket.gaierror
            If hostname resolution fails.
        RuntimeError
            If timeout occurs or protocol error detected.
        
        Notes
        -----
        - TCP connection uses port+1 (e.g., HTTP port 8080 → TCP port 8081).
        - Socket options optimized for low latency (TCP_NODELAY, TCP_QUICKACK).
        - Timeout based on count of non-result messages received.
        - Heartbeat daemon prevents connection idle timeout.
        
        Examples
        --------
        >>> result = TCPQueryTask.query_task_tcp('localhost', 8080, 'task-123')
        >>> import json
        >>> data = json.loads(result)
        """
        task_msg = QueryTaskMsg(task_id)
        res = None
        try:
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.settimeout(timeout)
            client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                client_socket.setsockopt(socket.SOL_TCP, 12, 1)  # TCP_QUICKACK
            except:
                pass
            client_socket.connect((host, port+1))
            TCPQueryTask.start_heartbeat_daemon_no_lock(client_socket,task_msg.get_heart_msg(),50)
            client_socket.send(task_msg.get_query_msg())

            flag_error_count = 0

            while True:
                response = client_socket.recv(1024, 0)
                flag = int.from_bytes(response[4:6], 'little')
                if flag == 2:
                    msg_len = int.from_bytes(response[8:12], 'little') + 16
                    recv_buffer = bytearray(msg_len)
                    mv = memoryview(recv_buffer)
                    mv[0:len(response)] = response
                    TCPQueryTask.drain_msg(client_socket, mv, msg_len, len(response))
                    res = recv_buffer[12:-4].decode('ascii')
                    client_socket.send(task_msg.get_ack_msg())
                    client_socket.close()
                    return res
                else:
                    flag_error_count += 1
                    if flag_error_count>=int(timeout):
                        raise RuntimeError(f"Timeout while fetching target data, continuously receiving non-target data{flag_error_count} times.")

        except ConnectionRefusedError as e:
            print(f"Connection refused. Please check if the server is running on {host}:{port}.")
            raise e
        except socket.gaierror as e:
            print(f"Address resolution failed: {host}")
            raise e
        except Exception as e:
            print(f"Error: {e}")
            raise e

        return res
