import base64
import concurrent
import datetime
import io
import json
import os.path
from typing import Any, Union, List, Tuple, Optional,Dict
from concurrent.futures import ProcessPoolExecutor
from urllib.parse import urlparse

import numpy as np
import yaml
import numpy

from pyqpanda3.vqcircuit import VQCircuit
from pyqpanda3.core import *
from pyqpanda3.utils import CommProtocolConfig, convert_vqcircuit_with_run_config_to_bytes

from .access_service.network.query_task_tcp import TCPQueryTask
from .access_service.remote_request.chip_task_msg import ChipSampleTaskMsg, ChipEstimateTaskMsg
from .access_service.channel import default_channel
from .access_service.remote_request.remote_request_worker import RequestWorker

from .device.qdevice import QDevice
from .device.fake_backend import FakeBackend

from .task.qtask_manager import QTaskManager
from .task.program_set.gate_params_bind_rule import AnsatzParamsBinding
from .task.program_set.observable_bind_rule import CircuitObservableBinding, AnsatzObservableBinding
from .task.session.vqsession import VQSession
from .task.session.fake_vqsession import FakeVQSession
from .task.qtask_info import SampleQTaskInfo,EstimateQTaskInfo

from .toolbox.client_task_id_generator import ClientTaskIdGenerator
from .toolbox.checkpoint import CheckPoint
from .toolbox.tracker import TrackerSystem,Tracker,tracker

from .utils.union_type import ObservableUnionType,QProgUnionType, get_observable,get_qprog
from .utils.exception.response_error import ResponseError


class RuntimeService(TrackerSystem):
    """
    QPanda3 Runtime Service Client Manager Class.

    Manages user requests and response data for quantum runtime services.

    Parameters
    ----------
    url_or_cfgfile : str
        Either a URL address or a path to a YAML configuration file.
        - URL: Quantum runtime server access address (e.g., 'https://localhost:8080')
        - File path: YAML file containing server URL and API key credentials

    trace_record_file : str, optional
        Path to trace record file for tracking operations. Required if auto_track is True.

    auto_track : bool, optional
        Whether to automatically track operations. Default is False.

    Attributes
    ----------
    tokens : dict
        Currently logged-in compute backend access channels and their corresponding access tokens.

    base_url : str
        QPanda3 Runtime server URL.

    Examples
    --------
    Method 1: Direct URL

    >>> service = RuntimeService('https://localhost:8080')

    Method 2: Configuration file

    >>> # config.yml
    ... api_key: '9B41FB6534584E45BD6BE0E6'
    ... server_url: 'https://localhost:8080'
    >>> service = RuntimeService(r'config.yml')
    """
    def __init__(self, url_or_cfgfile: str,trace_record_file: str = None, auto_track: bool = False):
        self.tokens = {}
        """Currently logged-in compute backend access channels and their corresponding access tokens."""

        self._backend_hosts = {}
        self._backend_ports = {}
        self._client_task_id_generators:Dict[str,ClientTaskIdGenerator] = {}
        self._chip_sample_task_msg = None
        self._chip_estimate_task_msg = None
        self.base_url = None
        """QPanda3 Runtime server URL"""

        self._outbound_raw_requests_logfile = None
        self._request_worker = None

        """tracker system"""
        self._tracker:Tracker = None
        self._auto_track:bool = auto_track
        if auto_track:
            if trace_record_file is None:
                raise RuntimeError('If auto_track is True, a valid trace_record_file path must be specified.')
            if os.path.exists(trace_record_file) is False:
                os.makedirs(os.path.dirname(trace_record_file), exist_ok=True)
                super().__init__(trace_record_file=trace_record_file,load_history_records=False)
            else:
                super().__init__(trace_record_file=trace_record_file,load_history_records=True)
        else:
            super().__init__(trace_record_file=trace_record_file,load_history_records=False)
        tracker = Tracker(self)
        
        
        self._start_tracking(tracker,'init runtime service',labels=['RUNTIME_SERVICE'])   
        try:
            
            parsed = urlparse(url_or_cfgfile)

            cfg = None
            if parsed.scheme and parsed.netloc:
                self.base_url = url_or_cfgfile
            elif os.path.exists(url_or_cfgfile) is False:
                raise RuntimeError(
                    "The input is not a valid URL, it might be a configuration file, but the file does not exist.")
            elif url_or_cfgfile.endswith(('.yaml', '.yml')):
                with open(url_or_cfgfile, 'r', encoding='utf-8') as file:
                    cfg = yaml.safe_load(file)
                    parsed = urlparse(cfg['server_url'])
                    if parsed.scheme and parsed.netloc:
                        self.base_url = cfg['server_url']
                    else:
                        raise RuntimeError(f'server_url in configure file({url_or_cfgfile}) is error, please check.')
                    if cfg.get('outbound_raw_requests_logfile') is not None:
                        self._outbound_raw_requests_logfile = cfg['outbound_raw_requests_logfile']
            else:
                raise RuntimeError(
                    f"The configuration file is {url_or_cfgfile} with error suffix, but the file does not exist.")
            if (self._outbound_raw_requests_logfile is not None) and (self._outbound_raw_requests_logfile != ''):
                if os.path.exists(self._outbound_raw_requests_logfile) is False:
                    with open(self._outbound_raw_requests_logfile, 'wt', encoding='utf8'):
                        pass
            self._request_worker = RequestWorker(self.base_url,self._outbound_raw_requests_logfile)
            self.tokens = {}
            self._chip_sample_task_msg = ChipSampleTaskMsg()
            self._chip_estimate_task_msg = ChipEstimateTaskMsg()
            if cfg is not None and cfg.get('api_key') is not None:
                self.login(cfg['api_key'])

            self._end_tracking(tracker,data={},labels=['SUCCESS'])
        except RuntimeError as e:
            self._end_tracking(tracker,data={'error':str(e)},labels=['ERROR'])
            raise e

    def _start_tracking(self,tracker:Tracker,context_name,labels: List[str] = []
        ,data: Dict[str, Any] = None) -> 'Tracker':
        if self._auto_track:
            tracker.start(context_name,labels,data)
    def _end_tracking(self,tracker:Tracker,data:Dict[str,Any],labels:List[str]=[]) -> 'Tracker':
        if self._auto_track:
            tracker.end(data,labels)
    def _tracker_record(self,tracker:Tracker,data:Dict[str,Any]) -> 'Tracker':
        if self._auto_track:
            tracker.record(data)

    def login(self, api_key, channel: str = default_channel):
        """
        Authenticate to the specified compute backend access channel.

        Parameters
        ----------
        api_key : str
            API key credentials for authentication.

        channel : str, optional
            Compute backend access channel. Default is default_channel.

        Returns
        -------
        str
            Access token for the specified compute backend.

        Raises
        ------
        RuntimeError
            If authentication fails or server returns unexpected response.

        Examples
        --------
        >>> service = RuntimeService('https://localhost:8080')
        >>> token = service.login('9B41FB6534584E45BD6BE0E6')
        """
  
        tracker = Tracker(self) 
        self._start_tracking(tracker,'login',labels=['LOGIN'])
        try:
            msg = {'apiKey': api_key, 'channel': channel}
            response = self._request_worker.login(msg,channel)
            # response = self.http_client.post_request(f'/{channel}/login', msg)
            if response:
                if response.get('token') is not None:
                    if self._client_task_id_generators.get(channel) is None:
                        self._client_task_id_generators[channel]=ClientTaskIdGenerator()
                    self._client_task_id_generators[channel].update_token_info(response['token'],datetime.datetime.now())
                    self.tokens[channel] = response['token']
                    self._backend_hosts[channel]= response['backend_host']
                    self._backend_ports[channel] = response['backend_port']
                    self._end_tracking(tracker,data={},labels=['SUCCESS'])
                    return response['token']
                else:
                    error = ResponseError.from_dict(response)
                    raise RuntimeError(error)
            else:
                self.tokens[channel] = None
                self._token_received_timestamps[channel]=None
                self._backend_hosts[channel] = None
                self._backend_ports[channel] = None

                error = ResponseError("The server did not return the expected data. Please check server'url, api_key and server "
                    "status.")
                raise RuntimeError(error)
        except RuntimeError as e:
            self._end_tracking(tracker,data={'error':str(e),**msg},labels=['ERROR'])
            raise e

    def query_task(self, channel: str, task_id: list, additional_info: Optional[List[str]] = None, using_http=True):
        """
        Query execution results and related information for specified compute tasks.

        Parameters
        ----------
        channel : str
            Compute backend access channel.

        task_id : List[str]
            List of subtask IDs uniquely identifying the compute task.

        additional_info : Optional[List[str]], optional
            Additional query fields for task execution information.
            Refer to compute backend documentation for available fields.

        using_http : bool, optional
            Protocol to use for query transmission.
            - True: Use HTTP protocol (default)
            - False: Use TCP protocol

        Returns
        -------
        list
            Execution results and related information for each task.

        Raises
        ------
        RuntimeError
            If channel is not logged in or query fails.
        """

        if additional_info is None:
            additional_info = []

        if channel not in self.tokens:
            error = ResponseError("The channel is not logged in. Please login first.")
            raise RuntimeError(error)
        if using_http:
            res = self._request_worker.query_task(channel,task_id,self.tokens[channel],additional_info)
            return res
        else:
            res = []
            for id_ in task_id:
                data = TCPQueryTask.query_task_tcp(host=self._backend_hosts[channel],port=self._backend_ports[channel],task_id=id_)
                res.append(json.loads(data))
        return res

    def list_devices(self, channel=default_channel, target: Union[int, str] = ''):
        """
        List quantum computing devices available on the specified compute backend.

        Parameters
        ----------
        channel : str, optional
            Compute backend access channel. Default is default_channel.

        target : Union[int, str], optional
            Single device ID to retrieve. If empty, returns all devices.

        Returns
        -------
        Union[List[QDevice], QDevice]
            - If target is empty: List of all available QDevice objects
            - If target is specified: Single QDevice object for the specified device

        Raises
        ------
        RuntimeError
            If target device is not available or server returns unexpected response.
        """
        tracker = Tracker(self) 
        self._start_tracking(tracker,'list devices',labels=['QUERY_DEVICE'])
        try:
            if isinstance(target, int):
                target = str(target)
            response = self._request_worker.list_devices(channel, target)
            if response:
                devs: List[QDevice] = []
                for dev_info in response['devices']:
                    devs.append(QDevice(self, dev_info,update_basic_info=False))
                if target != '':
                    if devs:
                        self._end_tracking(tracker,data={},labels=['SUCCESS'])
                        return devs[0]
                    else:
                        error = f"No device with chip_id {target} is available on channel {channel}"
                        raise RuntimeError(error)
                else:
                    self._end_tracking(tracker,data={},labels=['SUCCESS'])
                    return devs
            else:
                error = ResponseError("The server did not return the expected data.")
                raise RuntimeError(error)
        except Exception as e:
            self._end_tracking(tracker,data={'error':str(e),'channel':str(channel),'target':str(target)},labels=['ERROR'])
            raise e

    def _estimate(self, channel, msg):
        # response = await self.http_client.post_request_async(f'/{channel}/task/submit/estimate', msg)
        response = self._request_worker.estimate(channel,msg)
        if response.get('taskId') is not None:
            return response
        else:
            if 'Error: the value of field \'ChipID\' =' in response['error_info']:
                response['help_info'] = 'Please check if the chip id is correct or the real chip is accessible.'
            error = ResponseError.from_dict(response)
            raise RuntimeError(error)


    def query_device_config(self, dev: QDevice):
        """
        Query configuration and parameter information of the specified quantum computing device.

        Parameters
        ----------
        dev : QDevice
            Quantum computing device to query.

        Returns
        -------
        dict
            Device configuration and parameter information, including:
            - Quantum topology structure
            - Noise statistics (T1, T2, readout error rates)
            - Other device-specific parameters

        Raises
        ------
        RuntimeError
            If query fails or server returns unexpected response.
        """
        tracker = Tracker(self)
        self._start_tracking(tracker,'query device config',labels=['QUERY_DEVICE'])
        try:
            msg = {'ChipID': dev.chip_id(), 'channel': dev.channel(),'token':self.tokens[dev.channel()]}
            response = self._request_worker.query_device_config(dev.channel(), msg)
            # response = await self.http_client.post_request_async(f'/{dev.channel()}/device/query_cfg', msg)
            if response:
                if 'error_info' in response:
                    error = ResponseError.from_dict(response)
                    raise RuntimeError(error)
                self._end_tracking(tracker,data={},labels=['SUCCESS'])
                return response
            else:
                error = ResponseError("The server did not return the expected data.")
                raise RuntimeError(error)
        except Exception as e:
            self._end_tracking(tracker,data={'error':str(e),'ChipID': dev.chip_id(), 'channel': dev.channel()},labels=['ERROR'])
            raise e

    def sample(self,
               circuits: Union[
                   QProgUnionType,
                   List[QProgUnionType],
                   AnsatzParamsBinding,
                   Tuple[
                       VQCircuit,
                       List[numpy.ndarray]
                   ]
               ],
               device: Union[QDevice, FakeBackend],
               measure_qubits: Optional[List[int]] = None,
               specified_block: Optional[List[int]] = None,
               shots: int = 10,
               is_amend: bool = True,
               is_mapping: bool = True,
               is_optimization: bool = True,
               point_label: int = 0,
               task_describe: str = '',
               ) -> QTaskManager:
        """
        Submit sampling computation task to quantum runtime server.

        Core quantum computing operation for sampling measurement results.

        Parameters
        ----------
        circuits : Union[QProgUnionType, List[QProgUnionType], AnsatzParamsBinding, Tuple[VQCircuit, List[numpy.ndarray]]]
            Quantum circuits for sampling task.
            - QProgUnionType: Single quantum program
            - List[QProgUnionType]: Multiple quantum programs
            - AnsatzParamsBinding: Parameterized ansatz circuits
            - Tuple[VQCircuit, List[numpy.ndarray]]: VQCircuit with parameter arrays

        device : Union[QDevice, FakeBackend]
            Quantum computing device.
            - QDevice: Real quantum computer/chip
            - FakeBackend: Local simulation with noise models

        measure_qubits : Optional[List[int]], optional
            Qubits to measure. If circuit has measurement nodes, replaces them.
            If circuit has no measurement nodes, must be provided.

        specified_block : Optional[List[int]], optional
            Physical qubit indices to use. Empty list enables automatic selection.

        shots : int, optional
            Number of sampling trials. Default is 10.

        is_amend : bool, optional
            Enable error mitigation amendment. Default is True.

        is_mapping : bool, optional
            Enable qubit mapping. Default is True.

        is_optimization : bool, optional
            Enable circuit optimization. Default is True.

        point_label : int, optional
            Currently disabled parameter.

        task_describe : str, optional
            Currently disabled parameter.

        Returns
        -------
        QTaskManager
            Local task manager for monitoring and retrieving results.

        Raises
        ------
        RuntimeError
            If parameters are invalid or task submission fails.
        """
        tracker = Tracker(self)
        self._start_tracking(tracker,'RuntimeService sample',labels=['QTASK','SAMPLE'])
        try:
            task_metadata = SampleQTaskInfo(
                circuits=circuits,
                device=device,
                measure_qubits=measure_qubits,
                specified_block=specified_block,
                shots=shots, is_amend=is_amend,
                is_mapping=is_mapping,
                is_optimization=is_optimization,
                point_label=point_label,
                task_describe=task_describe
            )
            if measure_qubits is None:
                measure_qubits = []
            if specified_block is None:
                specified_block = []
            if shots <=0:
                raise RuntimeError("shots must be greater than 0")
            self._check_specified_block(specified_block)
            if isinstance(device, QDevice):
                if isinstance(circuits, str) or isinstance(circuits,QProg) or isinstance(circuits,list):
                    circuits = RuntimeService._preprocess_circuits(circuits, update_measure_qubits=measure_qubits,
                                                                specified_block=specified_block)
                res = self._sample_on_real_chip(circuits=circuits,
                                                device=device,
                                                update_measure_qubits=measure_qubits,
                                                specified_block=specified_block,
                                                shots=shots, is_amend=is_amend,
                                                is_mapping=is_mapping,
                                                is_optimization=is_optimization,
                                                point_label=point_label,
                                                task_describe=task_describe,
                                                task_metadata=task_metadata
                                                )
                self._end_tracking(tracker,data={'task_id':res.id(),'channel':device.channel()},labels=['SUCCESS'])
                
            elif isinstance(device, FakeBackend):
                res = self._sample_on_fake_backend(circuits=circuits,
                                                    device=device,
                                                    update_measure_qubits=measure_qubits,
                                                    specified_block=specified_block,
                                                    shots=shots, is_amend=is_amend,
                                                    is_mapping=is_mapping,
                                                    is_optimization=is_optimization,
                                                    point_label=point_label,
                                                    task_describe=task_describe,
                                                    task_metadata=task_metadata
                                                    )
                self._end_tracking(tracker,data={'task_id':[],'channel':device.channel()},labels=['SUCCESS'])
            
            return res
        except Exception as e:
            self._end_tracking(tracker,{'error':str(e),'task_metadata':task_metadata.to_json_dict()},labels=['ERROR'])
            raise e

    def _sample_on_fake_backend(self,
                                circuits: Union[
                                    List[str],
                                    AnsatzParamsBinding,
                                    Tuple[
                                        VQCircuit,
                                        List[numpy.ndarray]
                                    ],
                                    # QTaskManager
                                ],
                                device: Union[QDevice, FakeBackend],
                                update_measure_qubits: Optional[List[int]] = None,
                                specified_block: Optional[List[int]] = None,
                                shots=10,
                                is_amend=True,
                                is_mapping=True,
                                is_optimization=True,
                                point_label = 0,
                                task_describe='',
                                task_metadata:SampleQTaskInfo=None
                                ) -> QTaskManager:

        if update_measure_qubits is None:
            update_measure_qubits = []
        if specified_block is None:
            specified_block = []
        cirs, _ = self._get_circuits(circuits)
        transpiled_progs, failed_transpiled_circuits = device.transpile(progs=cirs, specified_block=specified_block,
                                                                        is_optimization=is_optimization)
        res = []
        for prog in transpiled_progs:
            res.append(device.sample(prog, shots))
        task_data = {'task_id': [], 'result': res, 'is_transpile_successed': True, 'metadata':task_metadata.to_json_dict()}

        res = QTaskManager(self, task_data, used_remote_backend=False, used_fake_backend=True)
        return res

    @staticmethod
    def _process_ir_str(ir_str: str, new_measure_qubits: Optional[List[int]] = None):
        measure_qbits = []

        if new_measure_qubits is not None and len(new_measure_qubits) > 0:
            measure_qbits = new_measure_qubits

        res = ''
        with io.StringIO(ir_str) as f:
            f.seek(0)
            for line in f:
                if 'QINIT' in line:
                    max_qbit_idx = int(line.strip().split(' ')[-1]) - 1
                    if len(new_measure_qubits) > 0 and max(new_measure_qubits) > max_qbit_idx:
                        raise RuntimeError(
                            "There are some qubits in new_measure_qubits that are not in original qprog.")
                    continue
                elif 'CREG' in line:
                    continue
                elif 'MEASURE' in line:
                    if len(new_measure_qubits) == 0:
                        sub_str = line.strip().split(']')[0]
                        q = int(sub_str.split('[')[-1])
                        measure_qbits.append(q)
                    continue
                res += line
        for q in measure_qbits:
            res += f'MEASURE q[{q}],c[{q}]\n'

        head_str = f'QINIT {max_qbit_idx + 1}\n' + f'CREG {max_qbit_idx + 1}\n'
        return head_str + res, measure_qbits, max_qbit_idx

    @staticmethod
    def _preprocess_circuits(
            circuits: Union[QProgUnionType, List[QProgUnionType]],
            update_measure_qubits: List[int], specified_block: Optional[List[int]] = None):
        if specified_block is None:
            specified_block = []
        phy_qbit_total = len(specified_block)
        if isinstance(circuits, list) is False:
            circuits = [circuits]
        cirs = []
        for cir in circuits:
            # if isinstance(cir, QProg):
            #     ir_str = cir.originir(precision=15)
            # else:
            #     ir_str = cir
            ir_str = get_qprog(cir,res_type='originir')
            new_ir, measure_qbits, max_qbit_idx = (RuntimeService
                                                   ._process_ir_str(ir_str=ir_str,
                                                                    new_measure_qubits=update_measure_qubits))
            if phy_qbit_total != 0 and len(measure_qbits) > phy_qbit_total:
                error_info = (
                    f'For circuit ({new_ir}),which from ({ir_str} and new measure qubits({update_measure_qubits}), '
                    f' the number of measured qubits exceeds that in the specified block.')
                raise RuntimeError(error_info)
            cirs.append(new_ir)
        return cirs

    def _sample_on_real_chip(self,
                             circuits: Union[
                                 List[str],
                                 AnsatzParamsBinding,
                                 Tuple[
                                     VQCircuit,
                                     List[numpy.ndarray]
                                 ],
                                 # QTaskManager
                             ],
                             device: Union[QDevice, FakeBackend],
                             update_measure_qubits: Optional[List[int]] = None,
                             specified_block: Optional[List[int]] = None,
                             shots=10,
                             is_amend=True,
                             is_mapping=True,
                             is_optimization=True,
                             point_label=0,
                             task_describe='',
                             task_metadata:SampleQTaskInfo=None
                             ) -> QTaskManager:

        if update_measure_qubits is None:
            update_measure_qubits = []
        if specified_block is None:
            specified_block = []
        try:
            channel = device.channel()

            if channel not in self.tokens:
                error = ResponseError("Please input correct channel string.")
                raise RuntimeError(error)
            if self.tokens[channel] is None:
                error = ResponseError("Using without correct token.")
                raise RuntimeError(error)
            
            self._chip_sample_task_msg.build(
                progs=[],
                chip_id=device.chip_id(),
                shot=shots,
                is_amend=is_amend,
                is_mapping=is_mapping,
                is_optimization=is_optimization,
                specified_block=specified_block,
                priority=0,
                point_label=point_label,
                token=self.tokens[channel],
                task_describe=task_describe
            )

            qtask_define_time = datetime.datetime.now()
            task_data = {'channel': channel,'qtask_define_time':qtask_define_time.isoformat()}
            # task_data = {'channel': channel, 'qtask_define_time': qtask_define_time.isoformat(),
            #              'client_task_id': self._generate_client_task_id(channel, qtask_define_time)}
            response = None
            try:
                msg = self._chip_sample_task_msg.msg_dict()
                if isinstance(circuits, list):
                    response = self._request_worker.circuit_chunking_submit(
                        channel,circuits,msg,'sample',max_byte_num_per_packet=1000,max_cir_num_per_packet=10)
                    # response = self.circuit_chunking_submit(channel, circuits, msg, 'sample', 1000, 2)
                elif isinstance(circuits, AnsatzParamsBinding):
                    if len(update_measure_qubits) == 0:
                        raise RuntimeError("There aren't qubits, please ")
                    req_msg = {'task_config': msg, 'program_set': circuits.json(),
                               'measure_qubits': update_measure_qubits}
                    response = self._request_worker.sample_program_set(channel, req_msg)
                    # response = self._sample_program_set(channel, req_msg)
                elif isinstance(circuits, tuple):
                    ansatz, params = circuits
                    ansatz_with_params = AnsatzParamsBinding([ansatz], params)
                    ansatz_with_params.product([0], [id_ for id_ in range(len(params))])
                    req_msg = {'task_config': msg, 'program_set': ansatz_with_params.json(),
                               'measure_qubits': update_measure_qubits}
                    # response = self._sample_program_set(channel, req_msg)
                    response = self._request_worker.sample_program_set(channel, req_msg)
                # elif isinstance(circuits, QTaskManager):
                #     req_msg = {'task_config': msg, 'old_task_id': circuits.id(),
                #                'measure_qubits': update_measure_qubits}

                task_data['task_id'] = []
                for res in response:
                    if isinstance(res, dict):
                        if res.get('taskId') is not None:
                            task_data['task_id'].append(res['taskId'])
                        else:
                            error = ResponseError.from_dict(res)
                            raise RuntimeError(error)
                    else:
                        raise RuntimeError(res)

                task_data['task_type'] = 'sample'
                task_data['metadata']=task_metadata.to_json_dict()
                if response:
                    res = QTaskManager(self, task_data, used_remote_backend=True, used_program_set=False)
                    return res
                else:
                    error = "The server did not return the expected data."
                    raise RuntimeError(error)

            except RuntimeError as e:
                raise RuntimeError(error)
        except RuntimeError as e:
            raise RuntimeError(error)

    @staticmethod
    def _check_specified_block(specified_block: List[int], max_qubit_idx=-1):
        if len(specified_block) == 0:
            return
        q_set = set()
        for q in specified_block:
            q_set.add(q)
        if len(q_set) != len(specified_block):
            raise RuntimeError('There are qubits that occur more than once in specified')
        if len(specified_block) < max_qubit_idx + 1:
            raise RuntimeError(
                'The number of qubits in specified_block does not match the circuit/observable\'s max_qubit_idx value')

    def estimate(self,
                 circuit_with_observable: Union[
                     Tuple[
                         Union[QProgUnionType, List[QProgUnionType]],
                         ObservableUnionType
                     ],
                     CircuitObservableBinding,
                     AnsatzObservableBinding
                 ],
                 device: Union[QDevice, FakeBackend],
                 specified_block: Optional[List[int]] = None,
                 shots: int = 1000,
                 is_amend: bool = True,
                 is_mapping: bool = True,
                 is_optimization: bool = True,
                 task_describe: str = ''
                 ) -> QTaskManager:
        """
        Submit Hamiltonian expectation estimation task to quantum runtime server.

        Core quantum computing operation for estimating observable expectations.

        Parameters
        ----------
        circuit_with_observable : Union[Tuple[Union[QProgUnionType, List[QProgUnionType]], ObservableUnionType], CircuitObservableBinding, AnsatzObservableBinding]
            Quantum circuits and observables for expectation estimation.
            - Tuple: (circuit(s), observable)
            - CircuitObservableBinding: Pre-bound circuit-observable pairs
            - AnsatzObservableBinding: Parameterized ansatz with observables

        device : Union[QDevice, FakeBackend]
            Quantum computing device.
            - QDevice: Real quantum computer/chip
            - FakeBackend: Local simulation with noise models

        specified_block : Optional[List[int]], optional
            Physical qubit indices to use. Empty list enables automatic selection.

        shots : int, optional
            Number of sampling trials. Default is 1000.

        is_amend : bool, optional
            Enable error mitigation amendment. Default is True.

        is_mapping : bool, optional
            Enable qubit mapping. Default is True.

        is_optimization : bool, optional
            Enable circuit optimization. Default is True.

        task_describe : str, optional
            Currently disabled parameter.

        Returns
        -------
        QTaskManager
            Local task manager for monitoring and retrieving results.

        Raises
        ------
        RuntimeError
            If parameters are invalid or task submission fails.
        """
        tracker = Tracker(self)
        self._start_tracking(tracker,'estimate',labels=['QTASK','ESTIMATE'])
        try:
            task_metadata = EstimateQTaskInfo(
                circuit_with_observable=circuit_with_observable,
                device=device,
                specified_block=specified_block,
                shots=shots,
                is_amend=is_amend,
                is_mapping=is_mapping,
                is_optimization=is_optimization,
                task_describe=task_describe
            )
            if specified_block is None:
                specified_block = []
            if shots <= 0:
                error = ResponseError("The number of shots must be greater than zero.")
                error = RuntimeError(error)
                raise error
            if isinstance(device, QDevice):
                res = self._estimate_on_real_chip(circuit_with_observable=circuit_with_observable,
                                                device=device,
                                                specified_block=specified_block,
                                                shots=shots,
                                                is_amend=is_amend,
                                                is_mapping=is_mapping,
                                                is_optimization=is_optimization,
                                                task_describe=task_describe,
                                                task_metadata=task_metadata
                                                ) 
                self._end_tracking(tracker,data={'task_id':res.id(),'channel':device.channel()},labels=['SUCCESS'])
            elif isinstance(device, FakeBackend):
                res = self._estimate_on_fake_backend(circuit_with_observable=circuit_with_observable,
                                                    device=device,
                                                    specified_block=specified_block,
                                                    shots=shots,
                                                    is_amend=is_amend,
                                                    is_mapping=is_mapping,
                                                    is_optimization=is_optimization,
                                                    task_describe=task_describe,
                                                    task_metadata=task_metadata
                                                    )
                self._end_tracking(tracker,data={'task_id':[],'channel':device.channel()},labels=['SUCCESS'])
           
            return res
        except Exception as e:
            self._end_tracking(tracker,data={'error':str(e),'channel':device.channel(),'task_metadata':task_metadata},labels=['ERROR'])
            raise e

    def _estimate_on_fake_backend(self,
                                  circuit_with_observable: Union[
                                      Tuple[
                                          Union[QProgUnionType, List[QProgUnionType]],
                                          ObservableUnionType
                                      ],
                                      CircuitObservableBinding,
                                      AnsatzObservableBinding
                                  ],
                                  device: FakeBackend,
                                  specified_block: Optional[List[int]] = None,
                                  shots=1000,
                                  is_amend=True,
                                  is_mapping=True,
                                  is_optimization=True,
                                  task_describe='',
                                  task_metadata:EstimateQTaskInfo=None
                                  ) -> QTaskManager:
        if specified_block is None:
            specified_block = []
        if isinstance(circuit_with_observable, AnsatzObservableBinding):
            circuit_with_observable_ = circuit_with_observable
        else:
            if isinstance(circuit_with_observable, CircuitObservableBinding):
                circuit_with_observable_ = circuit_with_observable
            else:
                circuit_with_observable_ = CircuitObservableBinding.from_tuple(circuit_with_observable)

        progs = circuit_with_observable_.circuits(serialized=False)
        max_qbit_idx = circuit_with_observable_.max_qubit_idx()
        self._check_specified_block(specified_block, max_qbit_idx)
        cirs = []
        for prog in progs:
            tmp_prog = QProg()
            tmp_prog << prog
            for q in range(0, max_qbit_idx + 1):
                tmp_prog << measure(q, q)
            cirs.append(tmp_prog)
        hams = circuit_with_observable_.observables(serialized=False)
        cir_id__ham_id_s = circuit_with_observable_.get_all_circuit_observable_id_pairs()
        transpiled_progs, failed_transpiled_circuits = device.transpile(progs=cirs, specified_block=specified_block,
                                                                        is_optimization=is_optimization)

        if len(failed_transpiled_circuits) > 0:
            error = RuntimeError(f"Failed to transpile some circuits. They are {failed_transpiled_circuits}")
            raise error
        res = []
        for cir_id, ham_id in cir_id__ham_id_s:
            res.append(device.estimate(cirs[cir_id], hams[ham_id]))

        task_data = {'task_id': [], 'result': res, 'is_transpile_successed': True, 'metadata':task_metadata.to_json_dict()}

        res = QTaskManager(self, task_data, used_remote_backend=False, used_fake_backend=True)
        return res

    def _estimate_on_real_chip(self,
                               circuit_with_observable: Union[
                                   Tuple[
                                       Union[QProgUnionType, List[QProgUnionType]],
                                       ObservableUnionType
                                   ],
                                   CircuitObservableBinding,
                                   AnsatzObservableBinding
                               ],
                               device: QDevice,
                               specified_block: Optional[List[int]] = None,
                               shots=1000,
                               is_amend=True,
                               is_mapping=True,
                               is_optimization=True,
                               task_describe='',
                               task_metadata:EstimateQTaskInfo=None
                               ) -> QTaskManager:
        if specified_block is None:
            specified_block = []
        try:
            channel = device.channel()

            if channel not in self.tokens:
                if self.http_client:
                    error = RuntimeError('please input correct channel string')
                    raise error
                else:
                    error = RuntimeError('server connected failed')
                    raise error
            if self.tokens[channel] is None:
                error = RuntimeError('Using without correct token')
                raise error

            self._chip_estimate_task_msg.build(
                progs=[],
                hamiltonian=[],
                qubits=[],
                shot=shots,
                chip_id=device.chip_id(),
                is_amend=is_amend,
                is_mapping=is_mapping,
                is_optimization=is_optimization,
                specified_block=specified_block,
                task_describe=task_describe,
                token=self.tokens[channel],
            )

            qtask_define_time = datetime.datetime.now()
            task_data = {'channel': channel, 'qtask_define_time': qtask_define_time.isoformat()}
            # task_data = {'channel': channel, 'qtask_define_time': qtask_define_time.isoformat(),
            #              'client_task_id': self._generate_client_task_id(channel, qtask_define_time)}
            try:
                msg = self._chip_estimate_task_msg.msg_dict()
                if isinstance(circuit_with_observable, AnsatzObservableBinding):
                    circuit_with_observable_ = circuit_with_observable
                    # msg['QProg'] = RuntimeService._preprocess_circuits(circuit_with_observable._circuits, qubits)
                    msg['QProg'] = circuit_with_observable_.ansatzs(serialized=True, encode_type='b64_ascii')
                    msg['ParamList'], msg['ParamDim'] = circuit_with_observable_.gate_params(flatten=True)
                    msg['vqc_with_param'] = circuit_with_observable_.ansatz_params_bind_rules()
                else:
                    if isinstance(circuit_with_observable, CircuitObservableBinding):
                        circuit_with_observable_ = circuit_with_observable
                    else:
                        circuit_with_observable_ = CircuitObservableBinding.from_tuple(circuit_with_observable)

                    msg = self._chip_estimate_task_msg.msg_dict()
                    msg['QProg'] = circuit_with_observable_.circuits(serialized=True)

                max_qbit_idx = circuit_with_observable_.max_qubit_idx()
                self._check_specified_block(specified_block, max_qbit_idx)

                msg['Configuration']['hamiltonian'] = circuit_with_observable_.observables(serialized=True)
                msg['Configuration']['circuit_with_observable'] = circuit_with_observable_.rules()
                msg['Configuration']['qubits'] = list(range(circuit_with_observable_.max_qubit_idx()))

                response = self._estimate(channel, msg)
                task_data['task_id'] = [response['taskId']]
                task_data['task_type'] = 'estimate'
                task_data['metadata']=task_metadata.to_json_dict()

                if response:
                    res = QTaskManager(self, task_data, used_remote_backend=True, used_program_set=True)
                    return res
                else:
                    error = RuntimeError("The server did not return the expected data.")
                    raise error

            except RuntimeError as e:
                raise e
        except RuntimeError as e:
            raise e

    def get_task(self, task_id: Union[str, List[str]], channel=default_channel):
        """
        Create local task management object for existing computation tasks.

        Parameters
        ----------
        task_id : Union[str, List[str]]
            Computation task ID(s).
            - str: Single task ID
            - List[str]: Collection of subtask IDs

        channel : str, optional
            Backend access channel where the task resides. Default is default_channel.

        Returns
        -------
        QTaskManager
            Local task management object for monitoring and retrieving results.

        Notes
        -----
        This method creates a management object for tasks already submitted to the runtime server.
        """
        used_program_set = False
        if isinstance(task_id, str):
            task_id = [task_id]
            used_program_set = True

        task_data = {'channel': channel, 'task_id': task_id}
        res = QTaskManager(self, task_data, used_program_set=used_program_set)
        return res

    def device(self, chip_id: Union[int, str], channel=default_channel) -> QDevice:
        """
        Create local management object for quantum computing device.

        Parameters
        ----------
        chip_id : Union[int, str]
            Device identifier.

        channel : str, optional
            Backend access channel. Default is default_channel.

        Returns
        -------
        QDevice
            Local device management object.

        Raises
        ------
        RuntimeError
            If chip_id is empty or device creation fails.
        """
        if isinstance(chip_id, int):
            chip_id = str(chip_id)
        if chip_id == '':
            error = RuntimeError('chip_id is empty')
            raise error
        res = QDevice(self, {'channel': channel, 'chip_id': chip_id})
        return res

    def fake_backend(self, real_device: QDevice, channel='local_simulator',
                     noise_info: Union[dict, None] = None) -> FakeBackend:
        """
        Create FakeBackend for local simulation of real quantum device.

        Parameters
        ----------
        real_device : QDevice
            Real quantum computer/chip to simulate.

        channel : str, optional
            Simulation channel. Currently must be 'local_simulator'.

        noise_info : Union[dict, None], optional
            Noise model dictionary for simulation.
            - None: Use noise data from corresponding real device
            - dict: Custom noise model parameters

        Returns
        -------
        FakeBackend
            Local simulation backend with noise models.
        """
        tracker = Tracker(self)
        res = FakeBackend(self, real_device, channel=channel, noise_info=noise_info)
        return res

    @staticmethod
    def _get_circuits(
            src: Union[
                Tuple[
                    Union[
                        QProgUnionType,
                        List[QProgUnionType]
                    ],
                    ObservableUnionType
                ],
                CircuitObservableBinding,
                AnsatzObservableBinding,
                QProgUnionType,
                List[QProgUnionType],
                AnsatzParamsBinding,
                Tuple[
                    VQCircuit,
                    List[numpy.ndarray]
                ],
                QTaskManager
            ]
    ):
        cirs = []
        help_info = None

        def func1(src, cirs):
            # if isinstance(src, str | QProg):
            #     cirs.append(src)
            # elif isinstance(src, list):
            #     for v in src:
            #         if isinstance(v, str):
            #             cirs.append(v)
            #         elif isinstance(v, QProg):
            #             cirs.append(v.originir(precision=15))

            if isinstance(src,list):
                for v in src:
                    cirs.append(get_qprog(v,'originir'))
            else:
                cirs.append(get_qprog(src,'originir'))

        def func2(src, cirs):
            if isinstance(src, tuple):
                func1(src[0], cirs)
                if isinstance(src[0], VQCircuit):
                    pass

        func1(src, cirs)
        func2(src, cirs)

        return cirs, help_info

    @staticmethod
    def transpile_safe(prog: str, chip_topology_edges: List[List[int]], basic_gates: List[str],
                       compensate_angle_map_json: str, specified_block: List[int], optim_level: int):
        """
        Transpile quantum circuits using multi-processing for exception isolation.

        This method executes locally on the client side and must be called within
        `__name__ == '__main__'` environment due to Python multiprocessing restrictions.

        Parameters
        ----------
        prog : str
            Quantum circuit to transpile (OriginIR format).

        chip_topology_edges : List[List[int]]
            Physical qubit topology edges of the quantum computing backend.

        basic_gates : List[str]
            Basic quantum gates supported at physical level.

        compensate_angle_map_json : str
            Compensation angle mapping data in JSON format.

        specified_block : List[int]
            Physical qubit indices for circuit placement.
            Empty list enables automatic selection.

        optim_level : int
            Transpilation optimization level.

        Returns
        -------
        str
            Transpiled quantum circuit in OriginIR format.

        Raises
        ------
        RuntimeError
            If transpilation fails or times out.

        Notes
        -----
        For detailed documentation, refer to:
        - https://qcloud.originqc.com.cn/document/qpanda-3/cn/d3/df1/tutorial_quantum_circuit_transpiler.html
        - https://qcloud.originqc.com.cn/document/qpanda-3/cn/d7/d65/tutorial_quantum_program_of_content__origin_i_r.html
        """

        results = []
        with ProcessPoolExecutor(max_workers=1) as executor:
            future_to_op = {
                executor.submit(FakeBackend.transpile_, prog, chip_topology_edges, basic_gates,
                                compensate_angle_map_json, specified_block, optim_level)
            }
            for future in concurrent.futures.as_completed(future_to_op):
                try:
                    result = future.result(timeout=15)
                    results.append(result)
                except Exception as e:
                    raise RuntimeError("Failed to transpile.")
        return results[0]


    def vqsession(self, vqcircuit: VQCircuit,
                  device: Union[QDevice, FakeBackend],
                  shots=1000,
                  life_time=360,
                  observable: Union[ObservableUnionType, None] = None):
        """
        Request variational quantum computing session from runtime service.

        Parameters
        ----------
        vqcircuit : VQCircuit
            Variational quantum circuit (Ansatz structure) for parameterized circuits.

        device : Union[QDevice, FakeBackend]
            Quantum computing device for the session.
            - QDevice: Real quantum computer/chip
            - FakeBackend: Local simulation

        shots : int, optional
            Number of sampling trials per circuit. Default is 1000.

        life_time : float, optional
            Session lifespan in seconds. Default is 360.

        observable : Union[ObservableUnionType, None], optional
            Observable for expectation estimation tasks.

        Returns
        -------
        Union[VQSession, FakeVQSession]
            Local session management object.


        Notes
        -----
        Use the `with` statement to manage VQSession context lifecycle.
        """
        tracker = Tracker(self)
        self._start_tracking(tracker,'get vqsession',labels=['SESSION','VQSESSION'])
        try:
            channel = device.channel()
            if channel not in self.tokens:
                error = RuntimeError('server connected failed')
                raise error
            if self.tokens[channel] is None:
                error = RuntimeError('Using without correct token')
                raise error
            if isinstance(device,FakeBackend):
                res = FakeVQSession(self, vqcircuit, device, channel)
                return res

            msg = {'PilotOSMachineFlag': True, 'taskDescribe': '', 'QProg': '', 'QMachineType': '5',
                'TaskType': 17, 'ChipID': device.chip_id(), 'Priority': 0, 'callbackAddr': 'TCP_CB', 'token': self.tokens[channel]}
            cfg = {'shot': shots, 'amendFlag': False, 'PointLabel': 0, 'mappingFlag': True,
                'circuitOptimization': True, 'IsProbCount': False, 'specified_block': []}
            msg['Configuration'] = cfg
            config = CommProtocolConfig()
            config.open_mapping = True
            config.open_error_mitigation = False
            config.optimization_level = 3
            config.circuits_num = 1
            config.shots = shots
            vqc_cfig_dat = convert_vqcircuit_with_run_config_to_bytes(vqcircuit, config)
            msg["QProg"] = base64.b64encode(vqc_cfig_dat).decode("ascii")
            msg['LifeTime']=life_time
            msg['channel']=channel
            try:
                response = self._request_worker.apply_vqsession(channel=channel,msg=msg)
                if response.get('SessionId') is None or response.get('taskId') is None:
                    raise RuntimeError(str(response))
                res = VQSession(self,task_ids=[response['taskId']],session_id=response['SessionId'],chip_id=device.chip_id(),channel=channel,info = msg)
                self._end_tracking(tracker,data={'channel':str(channel),'session_id':response['SessionId']},labels=['SUCCESS'])
                return res
            except Exception as e:
                raise e
        except Exception as e:
            self._end_tracking(tracker
                ,data={'error':str(e),'vqcircuit':msg["QProg"],'life_time':life_time,'channel': channel
                    ,'observable':get_observable(observable,'str') if observable else None
                }
                ,labels=['ERROR'])
            raise e

    def run_vqtask(self, session_id, gate_params, measure_list: list = [],channel=default_channel, return_type: str = 'QTaskManager'):
        """
        Add quantum computing task to variational computing session.

        Parameters
        ----------
        session_id : str
            Variational computing session ID.

        gate_params : array-like
            Quantum gate parameters for Ansatz structure.

        measure_list : list, optional
            Qubit indices to measure. Default is empty list.

        channel : str, optional
            Access channel to quantum computing device. Default is default_channel.

        return_type : str, optional
            Return value type control.
            - 'QTaskManager': Returns QTaskManager object (default)
            - Other: Returns dictionary with task information

        Returns
        -------
        Union[QTaskManager, dict]
            Task management object or task information dictionary.

        Raises
        ------
        RuntimeError
            If session is invalid or task submission fails.
        """
        tracker = Tracker(self)
        self._start_tracking(tracker,'run vqtask',labels=['QTASK','VQTASK'])
        try:
            param = np.array(gate_params)
            shape = list(param.shape)
            paramList = param.reshape(-1).tolist()
            msg = {"ParamList": paramList, "ParamDim": shape, "MeasureList": measure_list,'SessionId':session_id,"TaskType":17
                ,'token':self.tokens[channel]
                }
            response = self._request_worker.run_vqtask(channel=channel,msg=msg)
            # response = json.loads(response)

            if response:
                if response.get('errCode') is not None and response['errCode']!=0:
                    error = RuntimeError(response['errInfo'])
                    raise error
                task_data = {'channel': channel, 'task_id': [response['taskId']],'session_id':session_id,'task_info':msg}
                if return_type == 'QTaskManager':
                    res = QTaskManager(self, task_data, used_remote_backend=True, used_program_set=False)
                else:
                    res = task_data
                self._end_tracking(tracker,data={'channel':channel,'task_id':response['taskId']},labels=['SUCCESS'])
                return res
            else:
                error = RuntimeError("The server did not return the expected data.")
                raise error
        except Exception as e:
            self._end_tracking(tracker
                ,data={'error':str(e),'session_id':session_id,'gate_params':gate_params
                    , 'measure_list':measure_list
                    ,'channel':channel,'return_type':return_type
                }
                ,labels=['ERROR'])
            raise e

    def release_session(self, session_id: str, chip_id: str, channel: str = default_channel):
        """
        Release quantum runtime service session.

        Parameters
        ----------
        session_id : str
            Quantum runtime service session ID.

        chip_id : str
            Quantum runtime service chip ID ID.

        channel : str, optional
            Access channel of the session. Default is default_channel.

        Returns
        -------
        dict
            Server response data.

        Raises
        ------
        RuntimeError
            If session release fails.
        """
        tracker = Tracker(self)
        self._start_tracking(tracker,'release session',labels=['VQSESSION','RELEASE'])
        try:
            msg = {"SessionId" : session_id,"Token" : self.tokens[channel],"ChipID":chip_id}
            response = self._request_worker.release_session(channel=channel,msg=msg)
            self._end_tracking(tracker,data={'channel':channel,'session_id':session_id},labels=['SUCCESS'])
            return response
        except Exception as e:
            self._end_tracking(tracker,data={'error':str(e),'session_id':session_id,'channel':channel,'chip_id':chip_id},labels=['ERROR'])
            raise e

    def _generate_client_task_id(self,channel:str =default_channel,task_define_time=datetime.datetime.now()):
        return self._client_task_id_generators[channel].generate_client_task_id(task_define_time=task_define_time)

    def recover_qtask_manager(self, checkpoint_file: str, recover_completely: bool = True) -> QTaskManager:
        """
        Recover QTaskManager object from checkpoint file.

        Parameters
        ----------
        checkpoint_file : str
            Checkpoint file path.

        recover_completely : bool, optional
            Recovery mode.
            - True: Complete recovery, task_state must contain all information (default)
            - False: Partial recovery, allow default values for missing fields

        Returns
        -------
        QTaskManager
            Recovered task management object.

        Raises
        ------
        FileNotFoundError
            If checkpoint file does not exist.

        ValueError
            If recover_completely is True and task_state is missing required fields.

        RuntimeError
            Other exceptions during recovery process.
        """
        
        checkpoint = CheckPoint()
        data = checkpoint.load(checkpoint_file)
        task_state = data.get('task_state')
        
        if not task_state:
            error = ValueError("No task_state found in checkpoint file")
            raise error
        
        res = QTaskManager.from_task_state(self, task_state, recover_completely)

        return res

