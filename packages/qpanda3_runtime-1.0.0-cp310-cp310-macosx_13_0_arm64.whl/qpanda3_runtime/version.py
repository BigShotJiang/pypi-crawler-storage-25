"""
Version information for the qpanda3_runtime package.

This module defines the package version which is used by:
1. Package metadata (setup.py)
2. Runtime version checking
3. API compatibility verification

Attributes
----------
__version__ : str
    The current version of the qpanda3_runtime package.
    Follows semantic versioning (major.minor.patch).
"""

__version__ = "1.0.0"
