"""
QPanda3 Runtime Client Package.

This package provides the client-side interface for QPanda3 quantum computing runtime services.
It includes modules for quantum device management, task execution, and runtime service interaction.

Modules
-------
runtime_service : RuntimeService
    Main client manager class for quantum runtime services.
access_service : Access service modules
    Network communication and channel management.
device : Quantum device modules
    Quantum device interfaces and fake backends.
toolbox : Utility tools
    Checkpointing, tracking, and debugging utilities.
task : Task management
    Quantum task execution and session management.
utils : Utility functions
    Helper functions and exception handling.

Examples
--------
>>> from qpanda3_runtime import RuntimeService
>>> service = RuntimeService('https://localhost:8080')
>>> device = service.get_device('quantum_backend')
>>> task = device.run(circuit, shots=1000)

See Also
--------
qpanda3_runtime_server : Server-side package for QPanda3 runtime services.
pyqpanda3 : Core quantum computing library.

Notes
-----
- This package requires a running QPanda3 runtime server.
- Authentication tokens are managed automatically by the RuntimeService.
- All quantum operations are tracked for debugging and monitoring.
"""

from .version import __version__
from .runtime_service import RuntimeService
from .access_service.channel import default_channel
from .device.qdevice import QDevice
from .device.fake_backend import FakeBackend
from .toolbox.checkpoint import CheckPoint
from .toolbox.tracker import Tracker,tracker,TraceAnalyzer,TrackerRef
from .task.qtask_manager import QTaskManager
from .task.session.vqsession import VQSession
from .task.session import FakeVQSession
from .task.program_set.gate_params_bind_rule import AnsatzParamsBinding
from .task.program_set.observable_bind_rule import CircuitObservableBinding,AnsatzObservableBinding



