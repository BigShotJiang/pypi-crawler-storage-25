
from abc import ABC, abstractmethod
from typing import Dict


class DeviceABC:
    """
    Abstract base class for quantum device interfaces.
    
    This class defines the common interface that all quantum device implementations
    must follow, ensuring consistent serialization behavior across different device types.
    
    Notes
    -----
    - All concrete device classes should inherit from this base class.
    - The `to_json_dict` method must be implemented to support device serialization.
    - This enables device state persistence and configuration sharing.
    
    See Also
    --------
    QDevice : Concrete implementation for real quantum devices.
    FakeBackend : Concrete implementation for simulated quantum backends.
    """
    
    @abstractmethod
    def to_json_dict(self) -> Dict:
        """
        Serialize the device object to a JSON-serializable dictionary.
        
        Returns
        -------
        Dict
            A dictionary representation of the device that can be serialized to JSON.
            The dictionary should contain all necessary information to reconstruct
            the device state.
        
        Notes
        -----
        - The returned dictionary must be JSON-serializable.
        - Should include device type, configuration, and state information.
        - Used for device persistence, configuration sharing, and debugging.
        
        Examples
        --------
        >>> device = QDevice(runtime_service, dev_info)
        >>> json_data = device.to_json_dict()
        >>> # Save to file or transmit over network
        """
        pass