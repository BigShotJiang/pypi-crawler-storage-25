from .device_abc import DeviceABC


class QDevice(DeviceABC):
    """
    Interface to real quantum computing devices.
    
    Represents a physical quantum computer/chip backend, providing access to
    device information, configuration, and the ability to create simulated
    counterparts for testing.
    
    Parameters
    ----------
    runtime_service : RuntimeService
        Local management object for the QPanda3 Runtime Service, used for
        defining and submitting quantum computing tasks.
    
    dev_info : Dict
        Metadata dictionary containing device information such as:
        - 'chip_id': Unique identifier for the device
        - 'channel': Access channel identifier
        - 'nameDetail': Human-readable device name
        - 'qubitNum': Number of qubits (may be populated later)
    
    update_basic_info : bool, optional
        Whether to immediately update device information from the server.
        Default is True.
    
    Attributes
    ----------
    _basic_info : Dict
        Basic device information (name, ID, qubit count, etc.).
    _config_info : Dict
        Detailed configuration information (topology, gates, noise, etc.).
    _runtime_service : RuntimeService
        Runtime service for device management and task submission.
    
    Notes
    -----
    - This class represents actual quantum hardware, not simulations.
    - Device information is lazily loaded when accessed.
    - Can generate a FakeBackend for simulation based on real device data.
    - Implements the DeviceABC interface for serialization.
    
    Examples
    --------
    >>> from qpanda3_runtime import RuntimeService
    >>> from qpanda3_runtime.device import QDevice
    >>> 
    >>> # Create a QDevice from device list
    >>> runtime = RuntimeService()
    >>> devices = runtime.list_devices()
    >>> real_device = QDevice(runtime, devices[0].basic_info())
    >>> 
    >>> # Access device information
    >>> print(f"Device: {real_device.name()}, Qubits: {real_device.qubit_num()}")
    >>> 
    >>> # Create a simulated version for testing
    >>> fake_device = real_device.fake_backend()
    
    See Also
    --------
    FakeBackend : Simulated version of a quantum device.
    DeviceABC : Abstract base class for quantum devices.
    RuntimeService.list_devices : Get available quantum devices.
    """
    def __init__(self, runtime_service, dev_info,update_basic_info=True):
        self._basic_info = dev_info
        self._config_info = {}
        self._runtime_service = runtime_service
        if update_basic_info:
            self.update_basic_info()

    def __str__(self):
        return str(self._basic_info)

    def __repr__(self):
        return self.__str__()

    def channel(self):
        """
        Get the access channel for the quantum device.
        
        Returns
        -------
        str
            Access channel identifier (e.g., 'qcloud', 'local_simulator').
        
        Notes
        -----
        - The channel determines how the device is accessed (cloud, local, etc.).
        - Used internally for routing quantum computing tasks.
        - Typically set during device initialization.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> print(f"Access channel: {device.channel()}")
        """
        return self._basic_info['channel']

    def chip_id(self):
        """
        Get the unique identifier of the quantum device.
        
        Returns
        -------
        str
            Unique device identifier (e.g., 'chip_001', 'quantum_backend_1').
        
        Notes
        -----
        - The chip ID is used to uniquely identify the device in the system.
        - Required for device-specific operations and configuration queries.
        - Should be present in the dev_info provided during initialization.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> print(f"Device ID: {device.chip_id()}")
        """
        if self._basic_info.get('chip_id'):
            return str(self._basic_info['chip_id'])

    def basic_info(self):
        """
        Get the basic information dictionary for the quantum device.
        
        Returns
        -------
        Dict
            Dictionary containing basic device information, typically including:
            - 'chip_id': Unique device identifier
            - 'channel': Access channel
            - 'nameDetail': Human-readable name
            - 'qubitNum': Number of qubits (may be None initially)
            - Other device-specific metadata
        
        Notes
        -----
        - This is the same dictionary passed during initialization.
        - May be updated by update_basic_info().
        - Useful for debugging or displaying device information.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> info = device.basic_info()
        >>> print(f"Device info keys: {list(info.keys())}")
        """
        return self._basic_info

    def update_basic_info(self):
        """
        Update basic device information from the server.
        
        Fetches the latest device information from the runtime service
        and updates the local basic_info dictionary.
        
        Notes
        -----
        - Queries the server for the most up-to-date device information.
        - Updates fields like nameDetail, qubitNum, and other metadata.
        - Called automatically during initialization if update_basic_info=True.
        - Can be called manually to refresh device information.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info, update_basic_info=False)
        >>> # Later, update information
        >>> device.update_basic_info()
        >>> print(f"Updated name: {device.name()}")
        
        See Also
        --------
        basic_info : Get the current basic information.
        name : Get the device name (calls update_basic_info if needed).
        """
        res = self._runtime_service.list_devices(target=self.chip_id(),channel=self.channel())
        for v in res.basic_info():
            self._basic_info[v] = res.basic_info()[v]

    def name(self):
        """
        Get the human-readable name of the quantum device.
        
        Returns
        -------
        str
            Device name (e.g., 'Origin Quantum Chip v1.0', 'IBM Quantum Montreal').
        
        Notes
        -----
        - The name is stored in the 'nameDetail' field of basic_info.
        - If not available locally, updates basic_info from the server.
        - Useful for user interfaces and logging.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> print(f"Device name: {device.name()}")
        """
        if self._basic_info.get('nameDetail'):
            return self._basic_info['nameDetail']
        else:
            self.update_basic_info()
            return self._basic_info['nameDetail']

    def available_qubits(self):
        """
        Get the list of available qubits on the quantum device.
        
        Returns
        -------
        list
            List of qubit indices that are available for use.
        """
        if self._basic_info.get('qubitNum'):
            return self._basic_info['qubitNum']
  
        self.update_basic_info()
        if self._basic_info.get('qubitNum'):
            return self._basic_info['qubitNum']
            
        self.update_config_info()
        qbits = [int(v) for v in self._config_info['adjMatrix']]
        return qbits




    def config_info(self):
        """
        Get the detailed configuration information dictionary.
        
        Returns
        -------
        Dict
            Dictionary containing detailed device configuration, typically including:
            - 'BasicQGate': List of supported basic quantum gates
            - 'CompensateAngle': Angle compensation mapping
            - 'adjMatrix': Adjacency matrix for qubit connectivity
            - 'QGateClock': Gate timing information
            - 'QubitParamsOrigin': Qubit-specific parameters (T1, T2, etc.)
        
        Notes
        -----
        - Configuration information is lazily loaded on first access.
        - Contains technical details needed for circuit compilation.
        - Used by FakeBackend to create accurate simulations.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> config = device.config_info()
        >>> print(f"Supported gates: {config.get('BasicQGate', [])}")
        """
        return self._config_info

    def update_config_info(self):
        """
        Update configuration information from the server.
        
        Fetches the latest device configuration from the runtime service
        and updates the local config_info dictionary.
        
        Notes
        -----
        - Queries the server for detailed device configuration.
        - Updates fields like gate set, topology, noise parameters.
        - Called automatically when configuration information is first accessed.
        - Can be called manually to refresh configuration.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> # Force update of configuration
        >>> device.update_config_info()
        >>> print(f"Updated gate set: {device.basic_gates()}")
        
        See Also
        --------
        config_info : Get the current configuration information.
        basic_gates : Get supported gates (calls update_config_info if needed).
        """
        chip_cfg_dict = self._runtime_service.query_device_config(self)
        for v in chip_cfg_dict:
            self.config_info()[v] = chip_cfg_dict[v]

    def basic_gates(self, update_info: bool = False):
        """
        Get the basic quantum gates supported by the device.
        
        Parameters
        ----------
        update_info : bool, optional
            If True, force an update from the server before returning.
            If False, use cached information if available.
            Default is False.
        
        Returns
        -------
        List[str]
            List of basic quantum gate names supported at the physical level.
        
        Notes
        -----
        - These are the gates that can be directly executed on the hardware.
        - Circuit transpilation decomposes higher-level gates into these.
        - Information is cached after first retrieval.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> gates = device.basic_gates()
        >>> print(f"Device supports: {gates}")
        >>> 
        >>> # Force update from server
        >>> gates = device.basic_gates(update_info=True)
        """
        if self._config_info.get('BasicQGate') is None or update_info:
            self.update_config_info()
        return self._config_info['BasicQGate']

    def compensate_angle_map(self, update_info: bool = False):
        """
        Get the angle compensation mapping for two-qubit gates.
        
        Parameters
        ----------
        update_info : bool, optional
            If True, force an update from the server before returning.
            If False, use cached information if available.
            Default is False.
        
        Returns
        -------
        Dict
            Dictionary mapping qubit pairs to angle compensation values.
            Used to correct systematic errors in two-qubit gate operations.
        
        Notes
        -----
        - Compensation angles are device-specific calibration data.
        - Applied during circuit transpilation to improve gate fidelity.
        - Information is cached after first retrieval.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> comp_map = device.compensate_angle_map()
        >>> print(f"Compensation map has {len(comp_map)} entries")
        """
        if self._config_info.get('CompensateAngle') is None or update_info:
            self.update_config_info()
        return self._config_info['CompensateAngle']

    def chip_topo_adjoint_matrix(self, update_info: bool = False):
        """
        Get the qubit connectivity as an adjacency matrix.
        
        Parameters
        ----------
        update_info : bool, optional
            If True, force an update from the server before returning.
            If False, use cached information if available.
            Default is False.
        
        Returns
        -------
        Dict[int, List[Dict[str, int]]]
            Adjacency matrix representation of qubit connectivity.
            Keys are qubit indices, values are lists of connected qubits
            with additional information (e.g., {'v': connected_qubit_index}).
        
        Notes
        -----
        - Represents which qubit pairs can directly interact.
        - Used for circuit compilation and qubit mapping.
        - Information is cached after first retrieval.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> adj_matrix = device.chip_topo_adjoint_matrix()
        >>> print(f"Qubit 0 connects to: {adj_matrix.get(0, [])}")
        """
        if self._config_info.get('adjMatrix') is None or update_info:
            self.update_config_info()
        return self._config_info['adjMatrix']

    def chip_topo_edges(self, update_info: bool = False):
        """
        Get the qubit connectivity as a list of edges.
        
        Parameters
        ----------
        update_info : bool, optional
            If True, force an update from the server before returning.
            If False, use cached information if available.
            Default is False.
        
        Returns
        -------
        List[List[int]]
            List of edges representing qubit connectivity.
            Each edge is [q1, q2] where q1 < q2 and qubits can directly interact.
        
        Notes
        -----
        - Derived from the adjacency matrix for easier processing.
        - Each edge appears only once (q1 < q2).
        - Used by FakeBackend and circuit transpilation algorithms.
        - Information is cached after first computation.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> edges = device.chip_topo_edges()
        >>> print(f"Device has {len(edges)} direct connections")
        >>> for q1, q2 in edges[:5]:
        >>>     print(f"  {q1} -- {q2}")
        """
        if self._config_info.get('chip_topology_edges') is None or update_info:
            adj_matrix_ = self.chip_topo_adjoint_matrix()
            adj_matrix = {int(k): adj_matrix_[k] for k in adj_matrix_}
            self._config_info['chip_topology_edges'] = []
            for v in sorted(adj_matrix.keys()):
                for adj_v in adj_matrix[v]:
                    adj_v = adj_v['v']
                    if adj_v > v:
                        self._config_info['chip_topology_edges'].append([int(v), int(adj_v)])
        return self._config_info['chip_topology_edges']

    def gate_clock(self, update_info: bool = False):
        """
        Get the timing information for quantum gate operations.
        
        Parameters
        ----------
        update_info : bool, optional
            If True, force an update from the server before returning.
            If False, use cached information if available.
            Default is False.
        
        Returns
        -------
        Dict
            Dictionary containing gate timing information, typically including
            execution times for different gate types (single-qubit, two-qubit, etc.).
        
        Notes
        -----
        - Gate timing affects decoherence error modeling in simulations.
        - Used by FakeBackend to create accurate noise models.
        - Information is cached after first retrieval.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> clock_info = device.gate_clock()
        >>> print(f"Gate timing: {clock_info}")
        """
        if self._config_info.get('QGateClock') is None or update_info:
            self.update_config_info()
        return self._config_info['QGateClock']

    def qubit_info(self, update_info: bool = False):
        """
        Get detailed information about individual qubits.
        
        Parameters
        ----------
        update_info : bool, optional
            If True, force an update from the server before returning.
            If False, use cached information if available.
            Default is False.
        
        Returns
        -------
        Dict[str, Dict]
            Dictionary mapping qubit indices (as strings) to qubit parameter dictionaries.
            Each qubit dictionary typically includes:
            - 'T1': T1 decoherence time
            - 'T2': T2 decoherence time  
            - 'FidelityMat': Readout fidelity matrix
            - Other qubit-specific calibration data
        
        Notes
        -----
        - Used for noise modeling in simulations.
        - Qubit parameters vary across the device due to manufacturing variations.
        - Information is cached after first retrieval.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> qubits = device.qubit_info()
        >>> q0_info = qubits.get('0', {})
        >>> print(f"Qubit 0 T1: {q0_info.get('T1', 'N/A')}")
        """
        if self._config_info.get('QubitParamsOrigin') is None or update_info:
            self.update_config_info()
        return self._config_info['QubitParamsOrigin']

    def fake_backend(self):
        """
        Create a simulated version of this quantum device.
        
        Returns
        -------
        FakeBackend
            A FakeBackend object configured with this device's topology,
            gate set, and noise characteristics.
        
        Notes
        -----
        - The FakeBackend uses the same configuration as this real device.
        - Useful for testing algorithms before running on real hardware.
        - Noise models are derived from device calibration data.
        
        Examples
        --------
        >>> device = QDevice(runtime, dev_info)
        >>> # Create a simulated version for testing
        >>> simulator = device.fake_backend()
        >>> # Test circuit on simulator
        >>> result = simulator.sample(test_circuit, shots=1000)
        
        See Also
        --------
        FakeBackend : The simulated quantum device class.
        """
        from .fake_backend import FakeBackend
        return FakeBackend(self._runtime_service, self)

    def to_json_dict(self):
        """
        Serialize the QDevice to a JSON-serializable dictionary.
        
        Returns
        -------
        Dict
            Dictionary containing all necessary information to reconstruct
            the QDevice, including:
            - 'type': Always 'QDevice'
            - 'basic_info': Basic device information
            - 'config_info': Detailed configuration information
        
        Notes
        -----
        - Implements the abstract method from DeviceABC.
        - The dictionary is JSON-serializable for storage or transmission.
        - Can be used with from_json_dict to recreate the object.
        - Configuration information may be empty if not yet loaded.
        
        See Also
        --------
        from_json_dict : Reconstruct a QDevice from serialized data.
        DeviceABC.to_json_dict : Abstract base class method.
        """
        dev_data = {}
        dev_data['type'] = 'QDevice'
        dev_data['basic_info'] = self._basic_info
        dev_data['config_info'] = self._config_info
        return dev_data

    @staticmethod
    def from_json_dict(runtime_service, dev_data):
        """
        Reconstruct a QDevice from serialized data.
        
        Parameters
        ----------
        runtime_service : RuntimeService
            Runtime service for device management.
        
        dev_data : Dict
            Dictionary containing serialized QDevice data,
            as returned by to_json_dict().
        
        Returns
        -------
        QDevice
            Reconstructed QDevice object.
        
        Notes
        -----
        - This is a static method for object reconstruction.
        - The reconstructed device will have cached configuration if present.
        - Basic information update is disabled during reconstruction.
        
        See Also
        --------
        to_json_dict : Serialize a QDevice to dictionary.
        """
        return QDevice(
            runtime_service=runtime_service,
            dev_info=dev_data['basic_info'],
            update_basic_info=False
        )


