import json
import re
import warnings
from typing import Union, List, Dict, Optional

from pyqpanda3.core import NoiseModel, QProg, CPUQVM, decoherence_error, GateType, expval_pauli_operator, I
from pyqpanda3.qcloud import ChipBackend
from pyqpanda3.transpilation import Transpiler
from pyqpanda3.hamiltonian import PauliOperator

from .qdevice import QDevice
from ..utils.union_type import QProgUnionType,get_qprog
from .device_abc import DeviceABC


class FakeBackend(DeviceABC):
    """
    Simulated quantum backend that mimics a real quantum computer/chip.
    
    This class creates a simulated quantum device with topology and noise characteristics
    based on configuration information from a real quantum device. It can be used for
    algorithm development, testing, and debugging without requiring access to actual
    quantum hardware.
    
    Parameters
    ----------
    runtime_service : RuntimeService
        Local management object for the QPanda3 Runtime Service, used for defining
        and submitting quantum computing tasks, and for generating a QTaskManager.
    
    real_device : Union[str, QDevice]
        Reference to the real quantum device being simulated.
        - QDevice: The real quantum computer/chip object.
        - str: The ID of the real quantum computer/chip.
    
    channel : str, optional
        The access channel to the real quantum computer/chip.
        Default is 'local_simulator'.
    
    noise_info : Union[Dict, None], optional
        Custom noise model metadata for simulation. If provided, this overrides
        the noise information from the real device configuration.
        Default is None (use real device noise information).
    
    Attributes
    ----------
    _real_device : Union[str, QDevice]
        Reference to the real quantum device.
    _runtime_service : RuntimeService
        Runtime service for device management.
    _chip_topology_edges : List[List[int]]
        Physical qubit topology edges.
    _basic_gates : List[str]
        Basic quantum gates supported by the device.
    _compensate_angle_map : dict
        Angle compensation mapping for gate operations.
    _noise_info : Union[Dict, None]
        Custom noise model information.
    _qubit_params_origin : dict
        Original qubit parameters from device configuration.
    _channel : str
        Access channel identifier.
    
    Notes
    -----
    - The simulated backend uses the same topology and gate set as the real device.
    - Noise models can be customized or derived from real device statistics.
    - Useful for testing quantum algorithms before running on real hardware.
    - Supports both sampling and expectation value calculations.
    
    Examples
    --------
    >>> from qpanda3_runtime.device import FakeBackend
    >>> from qpanda3_runtime import RuntimeService
    >>> 
    >>> # Create a fake backend based on a real device ID
    >>> runtime = RuntimeService()
    >>> fake_device = FakeBackend(runtime, 'quantum_chip_001')
    >>> 
    >>> # Run a sampling calculation
    >>> result = fake_device.sample(quantum_circuit, shots=1000)
    >>> 
    >>> # Calculate expectation value
    >>> expectation = fake_device.estimate(quantum_circuit, observable, shots=1000)
    
    See Also
    --------
    QDevice : Real quantum device interface.
    DeviceABC : Abstract base class for quantum devices.
    """
    def __init__(self, runtime_service, real_device: Union[str, QDevice], channel='local_simulator',
                 noise_info: Union[Dict, None] = None):
        if isinstance(real_device,str):
            self._real_device = runtime_service.device(real_device)
        else:
            self._real_device = real_device
        self._runtime_service = runtime_service
        self._chip_topology_edges: List[List[int]] = []
        self._basic_gates: List[str] = []
        self._compensate_angle_map: dict = {}
        self._noise_info = noise_info
        self._qubit_params_origin: dict = {}
        self._channel = channel
        self._init_from_device()

    def real_device(self):
        """
        Get the reference to the real quantum device being simulated.
        
        Returns
        -------
        Union[str, QDevice]
            Reference to the real quantum device:
            - QDevice: The real quantum computer/chip object.
            - str: The ID of the real quantum computer/chip.
        
        Notes
        -----
        - This method returns the original reference passed during initialization.
        - Useful for tracking which real device the simulation is based on.
        - Can be used to switch between simulated and real execution.
        
        Examples
        --------
        >>> fake_backend = FakeBackend(runtime, 'chip_001')
        >>> device_ref = fake_backend.real_device()
        >>> print(f"Simulating device: {device_ref}")
        """
        return self._real_device

    def _gen_noise_model_from_noise_info(self, remap_qubits: dict):
        res = NoiseModel()

        def process_decoherence_error():
            if self._noise_info.get('decoherence_error') is None:
                return
            for error_ in self._noise_info['decoherence_error']:
                qbits = []
                if isinstance(remap_qubits, dict):
                    valid = True
                    for q in error_['qbits']:
                        if q not in remap_qubits:
                            valid = False
                            break
                        qbits.append(remap_qubits[q])
                    if valid is False:
                        continue
                else:
                    qbits = error_['qbits']
                if error_['gatetype'] == GateType.CZ:
                    continue
                res.add_quantum_error(decoherence_error(error_['T1'], error_['T2'], error_['time']), error_['gatetype'],
                                      qbits)

        def process_read_out_error():
            if self._noise_info.get('qubit_read_error') is None:
                return
            for error_ in self._noise_info['qubit_read_error']:
                if error_['qbit'] not in remap_qubits.keys():
                    continue
                res.add_read_out_error(probs=error_['fidelity_mat'], qubit=remap_qubits[error_['qbit']])

        process_decoherence_error()
        process_read_out_error()
        return res

    def _gen_noise_model_or_info_from_chip_info(self, result_type: str, remap_qubits: dict):
        def process_decoherence_error(res: Union[Dict, NoiseModel], remap_qubits: dict, nodes: List[int],
                                      edges: List[List[int]]):
            cz_clock = {'type': GateType.CZ}
            rphi_clock = {'type': GateType.RPHI}

            for v in self._qgate_clock:
                if int(v['IntValue']) == 0:
                    continue
                else:
                    time_ = int(v['IntValue'])
                if v['gateType'] == 'CZ':
                    cz_clock['time'] = time_
                elif v['gateType'] == 'RPhi':
                    rphi_clock['time'] = time_

            for node in nodes:
                q = self._qubit_params_origin.get(str(node),None)
                if q is None:
                    continue
                if isinstance(res, dict):
                    error_ = {'T1': q['T1'], 'T2': q['T2'], 'time': rphi_clock['time'], 'gatetype': rphi_clock['type'],
                              'qbits': [remap_qubits[node]]}
                    res['decoherence_error'].append(error_)
                else:
                    res.add_quantum_error(decoherence_error(q['T1'], q['T2'], rphi_clock['time']),
                                          rphi_clock['type'],
                                          [remap_qubits[node]])

            for edge in edges:
                q1 = self._qubit_params_origin[str(edge[0])]
                q2 = self._qubit_params_origin[str(edge[1])]
                t1 = min(q1['T1'], q2['T1'])
                t2 = min(q1['T2'], q2['T2'])
                if isinstance(res, dict):
                    error_ = {'T1': t1, 'T2': t2, 'time': cz_clock['time'], 'gatetype': cz_clock['type'],
                              'qbits': [remap_qubits[v] for v in edge]}
                    self._noise_info['decoherence_error'].append(error_)
                else:
                    res.add_quantum_error(decoherence_error(t1, t2, cz_clock['time']),
                                          cz_clock['type'],
                                          [remap_qubits[v] for v in edge])

        def process_read_out_error(res: Union[Dict,NoiseModel], remap_qubits: dict, nodes: List[int]):
            for node in nodes:
                q = self._qubit_params_origin.get(str(node),None)
                if q is None:
                    continue
                if q.get('FidelityMat') is None:
                    warnings.warn(
                        'No FidelityMat, no read_out_error noise model',
                        RuntimeWarning,
                        stacklevel=2
                    )
                    return
                fidelity_mat = q['FidelityMat']
                mat_ = [[fidelity_mat[0][0], fidelity_mat[1][0]], [fidelity_mat[0][1], fidelity_mat[1][1]]]
                if isinstance(res, dict):
                    error_ = {'qbit': remap_qubits[node], 'fidelity_mat': mat_}
                    res['qubit_read_error'].append(error_)
                else:
                    res.add_read_out_error(probs=mat_, qubit=remap_qubits[node])

        if result_type == 'noise_info':
            res = {'decoherence_error': []}
        elif result_type == 'noise_model':
            res = NoiseModel()
        else:
            raise RuntimeError("input result_type is not supported")
        edges = []
        for edge in self._chip_topology_edges:
            if edge[0] in remap_qubits.keys() and edge[1] in remap_qubits.keys():
                edges.append(edge)
        nodes = [int(q) for q in remap_qubits.keys()]
        process_decoherence_error(res, remap_qubits, nodes, edges)
        process_read_out_error(res, remap_qubits, nodes)

        return res

    def _gen_noise_model_from_chip_info(self, remap_qubits: dict) -> NoiseModel:
        return self._gen_noise_model_or_info_from_chip_info(result_type='noise_model', remap_qubits=remap_qubits)

    def noise_model(self, remap_qubits: Union[dict, None] = None):
        """
        Generate a noise model for quantum circuit simulation.
        
        Creates a NoiseModel object based on statistical information from the real
        quantum device, simulating its noise environment for more realistic simulations.
        
        Parameters
        ----------
        remap_qubits : Union[dict, None], optional
            Dictionary for qubit index remapping. Keys are original qubit indices,
            values are new indices. If None, uses identity mapping.
            Default is None.
        
        Returns
        -------
        NoiseModel
            A noise model object containing decoherence errors and readout errors
            based on the real device's statistical information.
        
        Notes
        -----
        - The noise model includes T1/T2 decoherence times and readout fidelity matrices.
        - If custom noise_info was provided during initialization, it overrides the
          device's statistical information.
        - Qubit remapping allows simulating circuits with different qubit indexing.
        
        Examples
        --------
        >>> # Get noise model with default qubit mapping
        >>> noise_model = fake_backend.noise_model()
        >>> 
        >>> # Get noise model with custom qubit remapping
        >>> remap = {0: 2, 1: 3, 2: 0, 3: 1}
        >>> noise_model = fake_backend.noise_model(remap_qubits=remap)
        
        See Also
        --------
        noise_info : Get noise information as a dictionary.
        pyqpanda3.core.NoiseModel : The noise model class from pyqpanda3.
        """
        if remap_qubits is None:
            remap_qubits_ = {int(q): int(q) for q in self._qubit_params_origin.keys()}
        else:
            remap_qubits_ = remap_qubits

        if self._noise_info is None:
            return self._gen_noise_model_from_chip_info(remap_qubits_)
        else:
            return self._gen_noise_model_from_noise_info(remap_qubits_)

    def noise_info(self, remap_qubits: Union[dict, None] = None):
        """
        Get noise information as a dictionary.
        
        Retrieves noise model information in dictionary format, containing decoherence
        errors and readout errors based on the real device's statistical data.
        
        Parameters
        ----------
        remap_qubits : Union[dict, None], optional
            Dictionary for qubit index remapping. Keys are original qubit indices,
            values are new indices. If None, uses identity mapping.
            Default is None.
        
        Returns
        -------
        Dict
            Dictionary containing noise information with the following structure:
            - 'decoherence_error': List of dictionaries with T1, T2, time, gatetype, qbits
            - 'qubit_read_error': List of dictionaries with qbit and fidelity_mat
        
        Notes
        -----
        - Returns the same information as noise_model() but in dictionary format.
        - Useful for inspecting noise parameters or custom noise model creation.
        - If custom noise_info was provided during initialization, returns that instead.
        
        Examples
        --------
        >>> # Get noise information
        >>> noise_data = fake_backend.noise_info()
        >>> print(f"Decoherence errors: {noise_data.get('decoherence_error', [])}")
        >>> print(f"Readout errors: {noise_data.get('qubit_read_error', [])}")
        
        See Also
        --------
        noise_model : Get noise information as a NoiseModel object.
        """
        if remap_qubits is None:
            remap_qubits_ = {int(q): int(q) for q in self._qubit_params_origin.keys()}
        else:
            remap_qubits_ = remap_qubits

        if self._noise_info is None:
            return self._gen_noise_model_or_info_from_chip_info(result_type='noise_info', remap_qubits=remap_qubits_)
        else:
            return self._noise_info

    def topo_deges(self, specified_block: Optional[List[int]] = None):
        """
        Get the qubit topology as a set of edges.
        
        Returns the connectivity graph of physical qubits as a list of edges,
        where each edge is a pair of qubit indices that can interact directly.
        
        Parameters
        ----------
        specified_block : Optional[List[int]], optional
            List of qubit indices to filter the topology. Only edges where both
            vertices are in this list will be included. If None or empty, returns
            all edges.
            Default is None.
        
        Returns
        -------
        List[List[int]]
            List of edges representing the qubit topology. Each edge is a list
            of two qubit indices [q1, q2] where q1 < q2.
        
        Raises
        ------
        RuntimeError
            If specified_block is provided but no edges contain only qubits from
            the specified block.
        
        Notes
        -----
        - The topology is derived from the real device's adjacency matrix.
        - Useful for circuit compilation and qubit mapping algorithms.
        - Filtering by specified_block enables subgraph selection for compilation.
        
        Examples
        --------
        >>> # Get full topology
        >>> edges = fake_backend.topo_deges()
        >>> print(f"Device has {len(edges)} connections")
        >>> 
        >>> # Get topology for specific qubits
        >>> sub_edges = fake_backend.topo_deges(specified_block=[0, 1, 2])
        >>> print(f"Subgraph has {len(sub_edges)} connections")
        """
        if specified_block is not None and len(specified_block) > 0:
            topo_edges = []
            for edge in self._chip_topology_edges:
                if edge[0] in specified_block and edge[1] in specified_block:
                    topo_edges.append(edge)
            if len(topo_edges) == 0:
                raise RuntimeError("There is no topology that meets the compilation requirements.")
        else:
            topo_edges = self._chip_topology_edges
        return topo_edges

    def _init_from_device(self):
        chip_cfg_dict = self._runtime_service.query_device_config(self._real_device)
        self._basic_gates = chip_cfg_dict['BasicQGate']
        self._compensate_angle_map = chip_cfg_dict['CompensateAngle']
        adj_matrix_ = chip_cfg_dict['adjMatrix']
        adj_matrix = {int(k): adj_matrix_[k] for k in adj_matrix_}
        self._chip_topology_edges = []
        for v in sorted(adj_matrix.keys()):
            for adj_v in adj_matrix[v]:
                adj_v = adj_v['v']
                if adj_v > v:
                    self._chip_topology_edges.append([int(v), int(adj_v)])

        self._qubit_params_origin = chip_cfg_dict['QubitParamsOrigin']
        self._qgate_clock = chip_cfg_dict['QGateClock']

    def _transpile(self,progs:List[QProgUnionType],specified_block:Union[List,None]=None,is_optimization=True):
        cirs = []
        for prog in progs:
            cirs.append(get_qprog(prog, 'originir'))
            # if isinstance(prog, QProg):
            #     cirs.append(prog.originir(precision=15))
            # else:
            #     cirs.append(prog)

        if is_optimization:
            optim_level = 2
        else:
            optim_level = 0

        if specified_block is None:
            specified_block = []
        topo_edges = self.topo_deges(specified_block)

        transpiled_progs = []
        failed_transpiled_circuits = []
        for cir in cirs:
            try:
                transpiled_progs.append(
                    self.transpile_(prog=cir,
                                    chip_topology_edges=topo_edges,
                                    basic_gates=self._basic_gates,
                                    compensate_angle_map_json=json.dumps(
                                        self._compensate_angle_map
                                    ),
                                    specified_block=specified_block,
                                    optim_level=optim_level)
                )
            except Exception as e:
                transpiled_progs.append(None)
                failed_transpiled_circuits.append(cir)
        if len(failed_transpiled_circuits) > 0:
            raise RuntimeError(f'These progs failed to trainspile on the fake backend:{failed_transpiled_circuits}')

        return transpiled_progs, failed_transpiled_circuits

    @staticmethod
    def transpile_(prog: str, chip_topology_edges: List[List[int]], basic_gates: List[str],
                   compensate_angle_map_json: str, specified_block: List[int], optim_level: int):
        """
        Transpile a quantum circuit for a specific quantum backend.
        
        Compiles a quantum circuit to match the constraints of a target quantum
        device, including topology, gate set, and compensation angles.
        
        Parameters
        ----------
        prog : str
            Quantum circuit to transpile in OriginIR format.
        
        chip_topology_edges : List[List[int]]
            Physical qubit connectivity as a list of edges [q1, q2].
        
        basic_gates : List[str]
            Set of basic quantum gates supported by the physical device.
        
        compensate_angle_map_json : str
            JSON string containing angle compensation mapping for two-qubit gates.
        
        specified_block : List[int]
            Physical qubit indices where the circuit should be placed.
            Must be a subset of vertices in the chip_topology_edges graph.
        
        optim_level : int
            Transpilation optimization level (0-2, higher means more optimization).
        
        Returns
        -------
        str
            Transpiled quantum circuit in OriginIR format.
        
        Raises
        ------
        RuntimeError
            If transpilation fails due to unsupported gates or topology constraints.
        
        Notes
        -----
        - This is a low-level static method that performs actual transpilation.
        - Uses pyqpanda3's Transpiler and ChipBackend for compilation.
        - If transpilation fails, the program may terminate immediately.
        - For safer transpilation, use the instance method `transpile()` instead.
        
        References
        ----------
        - Quantum Circuit Transpiler Tutorial: https://qcloud.originqc.com.cn/document/qpanda-3/cn/d3/df1/tutorial_quantum_circuit_transpiler.html
        - OriginIR Format Documentation: https://qcloud.originqc.com.cn/document/qpanda-3/cn/d7/d65/tutorial_quantum_program_of_content__origin_i_r.html
        
        See Also
        --------
        transpile : Safer instance method for circuit transpilation.
        """
        compensate_angle_map = {}
        compensate_angle_map_dict = json.loads(compensate_angle_map_json)
        for _, v in compensate_angle_map_dict.items():
            qs = list(v.keys())
            compensate_angle_map[(int(qs[0]), int(qs[1]))] = (v[qs[0]], v[qs[1]])
        backend = ChipBackend(
            _chip_topology_edges=chip_topology_edges,
            _basic_gates=basic_gates,
            _compensate_angle_map=compensate_angle_map,
            _echo_gate_timing=0,
            _barrier_gate_timing=0,
            _single_gate_timing=0,
            _double_gate_timing=0,
            _patterns={}
        )
        init_mapping = {}
        transpiler = Transpiler()
        transpiled_prog = transpiler.transpile(prog=QProg(prog), backend=backend, init_mapping=init_mapping,
                                               optimization_level=optim_level)

        return transpiled_prog.originir(precision=15)

    def sample(self, prog: QProgUnionType, shots: int = 1):
        """
        Perform sampling calculation on a quantum circuit.
        
        Executes the quantum circuit multiple times (shots) and returns the
        measurement outcome probabilities, simulating the behavior of a real
        quantum device with noise.
        
        Parameters
        ----------
        prog : QProgUnionType
            Quantum circuit to execute. Can be a QProg object or OriginIR string.
        
        shots : int, optional
            Number of measurement shots (circuit executions).
            Default is 1.
        
        Returns
        -------
        Dict[str, float]
            Dictionary mapping measurement bitstrings to their probabilities.
            Keys are binary strings (e.g., '0101'), values are probabilities.
        
        Notes
        -----
        - Uses CPUQVM for simulation with the device's noise model.
        - Automatically handles qubit remapping for the simulation.
        - The noise model includes decoherence and readout errors.
        - For noiseless simulation, create a FakeBackend with noise_info=None.
        
        Examples
        --------
        >>> # Sample a quantum circuit
        >>> circuit = QProg() << H(0) << CNOT(0, 1) << Measure([0, 1])
        >>> results = fake_backend.sample(circuit, shots=1000)
        >>> print(f"Measurement probabilities: {results}")
        
        See Also
        --------
        estimate : Calculate expectation values of observables.
        """
        # if isinstance(prog, str):
        #     prog = QProg(prog)
        prog = get_qprog(prog,'object')
        count = 0
        mp_remap = {}
        mp_rremap = {}
        for qbit in prog.qubits():
            mp_remap[qbit] = count
            mp_rremap[count] = qbit
            count += 1

        prog.remap(remap_qubits=mp_remap)

        model = self.noise_model(remap_qubits=mp_remap)
        # try:
        #     qvm = GPUQVM()
        #     qvm.run(prog, shots, model)
        #     res = qvm.result().get_prob_dict()
        # except Exception:
        #     qvm = CPUQVM()
        #     qvm.run(prog, shots, model)
        #     res = qvm.result().get_prob_dict()
        qvm = CPUQVM()
        qvm.run(prog, shots, model)
        res = qvm.result().get_prob_dict()
        prog.remap(remap_qubits=mp_rremap)
        return res

    @staticmethod
    def remap_qbits_pauli(pauli_op: PauliOperator, remap_qbits: Dict[int, int]) -> PauliOperator:
        """
        Remap qubit indices in a Pauli operator.
        
        Creates a new PauliOperator with qubit indices remapped according to
        the provided mapping. The original operator is not modified.
        
        Parameters
        ----------
        pauli_op : PauliOperator
            Original Pauli operator to remap.
        
        remap_qbits : Dict[int, int]
            Qubit index mapping dictionary. Keys are original qubit indices,
            values are new qubit indices.
        
        Returns
        -------
        PauliOperator
            New Pauli operator with remapped qubit indices.
        
        Notes
        -----
        - The original PauliOperator is not modified.
        - Useful when circuit qubits are remapped for simulation.
        - Maintains the same coefficients and Pauli terms, only changes qubit indices.
        
        Examples
        --------
        >>> # Original Pauli operator
        >>> pauli = PauliOperator([("Z0 Z1", 1.0), ("X2", 0.5)])
        >>> 
        >>> # Remap qubits 0->2, 1->3, 2->0
        >>> remap = {0: 2, 1: 3, 2: 0}
        >>> remapped = FakeBackend.remap_qbits_pauli(pauli, remap)
        >>> # Result: Z2 Z3 with coefficient 1.0, X0 with coefficient 0.5
        
        See Also
        --------
        pyqpanda3.hamiltonian.PauliOperator : The Pauli operator class.
        """
        data = pauli_op.data_3tuple_list_float_coeff()
        tmp = []
        for pauli, qbits, coeff in data:
            tmp_qbits = []
            for q in qbits:
                tmp_qbits.append(remap_qbits[q])
            tmp.append((pauli, tmp_qbits, coeff))
        return PauliOperator(tmp)

    def estimate(self, prog: QProgUnionType, observable: PauliOperator, shots: int = 1):
        """
        Calculate the expectation value of an observable on a quantum circuit.
        
        Computes the expectation value ⟨ψ|O|ψ⟩ where |ψ⟩ is the state prepared by
        the circuit and O is the observable (Pauli operator).
        
        Parameters
        ----------
        prog : QProgUnionType
            Quantum circuit that prepares the state |ψ⟩.
            Can be a QProg object or OriginIR string.
        
        observable : PauliOperator
            Observable operator O whose expectation value is to be calculated.
        
        shots : int, optional
            Number of measurement shots for expectation value estimation.
            Default is 1.
        
        Returns
        -------
        float
            Expectation value ⟨ψ|O|ψ⟩.
        
        Notes
        -----
        - Uses the device's noise model for realistic simulation.
        - Automatically handles qubit remapping and identity gate insertion.
        - Tries GPU acceleration first, falls back to CPU if GPU is unavailable.
        - For variational algorithms, this is typically the cost function.
        
        Examples
        --------
        >>> # Define a simple circuit
        >>> circuit = QProg() << H(0) << CNOT(0, 1)
        >>> 
        >>> # Define an observable (Z0 Z1)
        >>> observable = PauliOperator([("Z0 Z1", 1.0)])
        >>> 
        >>> # Calculate expectation value
        >>> expectation = fake_backend.estimate(circuit, observable, shots=1000)
        >>> print(f"Expectation value: {expectation}")
        
        See Also
        --------
        sample : Perform sampling measurements on a circuit.
        pyqpanda3.core.expval_pauli_operator : Low-level expectation value function.
        """

        # if isinstance(prog, str):
        #     prog = QProg(prog)
        prog = get_qprog(prog,'object')

        qbits1, qbits2 = observable.qubits()
        observable_qbits = [*qbits1, *qbits2]
        prog_max_qbit = max(prog.qubits())
        for q in observable_qbits:
            if q > prog_max_qbit:
                prog << I(q)

        count = 0
        mp_remap: Dict[int, int] = {}
        mp_rremap = {}
        for qbit in prog.qubits():
            mp_remap[qbit] = count
            mp_rremap[count] = qbit
            count += 1

        prog.remap(remap_qubits=mp_remap)
        model = self.noise_model(remap_qubits=mp_remap)
        pauli_op = self.remap_qbits_pauli(pauli_op=observable, remap_qbits=mp_remap)
        # try:
        #     res = expval_pauli_operator(node=prog, pauli_operator=pauli_op, shots=shots, model=model, backend='GPU')
        # except Exception:
        res = expval_pauli_operator(node=prog, pauli_operator=pauli_op, shots=shots,backend="CPU")
        prog.remap(remap_qubits=mp_rremap)
        return res

    def transpile(self, progs: List[QProgUnionType], specified_block: Optional[List[int]] = None, 
                  is_optimization: bool = True):
        """
        Transpile multiple quantum circuits safely.
        
        Compiles quantum circuits to match the device constraints using a safe
        multiprocessing approach that isolates exceptions. This method should be
        called within `if __name__ == '__main__':` block due to Python's
        multiprocessing restrictions.
        
        Parameters
        ----------
        progs : List[QProgUnionType]
            List of quantum circuits to transpile.
        
        specified_block : Optional[List[int]], optional
            Physical qubit indices where circuits should be placed.
            Default is None (use all available qubits).
        
        is_optimization : bool, optional
            Whether to enable circuit optimization during transpilation.
            Default is True.
        
        Returns
        -------
        Tuple[List[str], List[str]]
            A tuple containing:
            - List[str]: Successfully transpiled circuits in OriginIR format.
            - List[str]: Circuits that failed to transpile.
        
        Raises
        ------
        RuntimeError
            If any circuit fails to transpile.
        
        Notes
        -----
        - Uses multiprocessing for isolation and safety.
        - Must be called within `if __name__ == '__main__':` block.
        - Delegates to runtime_service.transpile_safe for actual transpilation.
        - Returns both successful and failed circuits for error handling.
        
        References
        ----------
        - Quantum Circuit Transpiler Tutorial: https://qcloud.originqc.com.cn/document/qpanda-3/cn/d3/df1/tutorial_quantum_circuit_transpiler.html
        - OriginIR Format Documentation: https://qcloud.originqc.com.cn/document/qpanda-3/cn/d7/d65/tutorial_quantum_program_of_content__origin_i_r.html
        
        Examples
        --------
        >>> if __name__ == '__main__':
        >>>     circuits = [circuit1, circuit2, circuit3]
        >>>     transpiled, failed = fake_backend.transpile(circuits)
        >>>     print(f"Transpiled {len(transpiled)} circuits, failed: {len(failed)}")
        
        See Also
        --------
        transpile_ : Low-level static method for single circuit transpilation.
        """
        cirs = []
        for prog in progs:
            cirs.append(get_qprog(prog,'originir'))
            # if isinstance(prog, QProg):
            #     cirs.append(prog.originir(precision=15))
            # else:
            #     cirs.append(prog)

        if is_optimization:
            optim_level = 2
        else:
            optim_level = 0

        if specified_block is None:
            specified_block = []
        topo_edges = self.topo_deges(specified_block)

        transpiled_progs = []
        failed_transpiled_circuits = []
        for cir in cirs:
            try:
                transpiled_progs.append(
                    self._runtime_service.transpile_safe(prog=cir,
                                                         chip_topology_edges=topo_edges,
                                                         basic_gates=self._basic_gates,
                                                         compensate_angle_map_json=json.dumps(
                                                             self._compensate_angle_map),
                                                         specified_block=specified_block,
                                                         optim_level=optim_level))
            except Exception as e:
                transpiled_progs.append(None)
                failed_transpiled_circuits.append(cir)
        if len(failed_transpiled_circuits) > 0:
            raise RuntimeError(f'These progs failed to trainspile on the fake backend:{failed_transpiled_circuits}')

        return transpiled_progs, failed_transpiled_circuits

    def to_json_dict(self):
        """
        Serialize the FakeBackend to a JSON-serializable dictionary.
        
        Returns
        -------
        Dict
            Dictionary containing all necessary information to reconstruct
            the FakeBackend, including:
            - 'type': Always 'FakeBackend'
            - 'real_device': ID of the real device being simulated
            - 'chip_topology_edges': Physical qubit connectivity
            - 'basic_gates': Supported gate set
            - 'compensate_angle_map': Angle compensation data
            - 'noise_info': Noise model information
            - 'qubit_params_origin': Original qubit parameters
            - 'channel': Access channel identifier
        
        Notes
        -----
        - Implements the abstract method from DeviceABC.
        - The dictionary is JSON-serializable for storage or transmission.
        - Can be used with from_json_dict to recreate the object.
        
        See Also
        --------
        from_json_dict : Reconstruct a FakeBackend from serialized data.
        DeviceABC.to_json_dict : Abstract base class method.
        """
        dev_data = {}
        dev_data['type'] = 'FakeBackend'
        dev_data['real_device'] = self._real_device.chip_id()
        dev_data['chip_topology_edges'] = self._chip_topology_edges
        dev_data['basic_gates'] = self._basic_gates
        dev_data['compensate_angle_map'] = self._compensate_angle_map
        dev_data['noise_info'] = self.noise_info
        dev_data['qubit_params_origin'] = self._qubit_params_origin
        dev_data['channel'] = self._channel
        return dev_data

    @staticmethod
    def from_json_dict(runtime_service, dev_data):
        """
        Reconstruct a FakeBackend from serialized data.
        
        Parameters
        ----------
        runtime_service : RuntimeService
            Runtime service for device management.
        
        dev_data : Dict
            Dictionary containing serialized FakeBackend data,
            as returned by to_json_dict().
        
        Returns
        -------
        FakeBackend
            Reconstructed FakeBackend object.
        
        Notes
        -----
        - This is a static method for object reconstruction.
        - Requires a runtime_service for device configuration queries.
        - The noise_info from dev_data overrides device statistics.
        
        See Also
        --------
        to_json_dict : Serialize a FakeBackend to dictionary.
        """
        return FakeBackend(
            runtime_service=runtime_service,
            real_device=dev_data['real_device'],
            noise_info=dev_data['noise_info']
        )

    def channel(self):
        return self._channel

    
