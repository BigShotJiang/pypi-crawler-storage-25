"""
Quantum device interfaces for QPanda3 Runtime.

This module provides interfaces to quantum computing devices, including real quantum
backends and simulated fake backends for testing and development.

Classes
-------
QDevice : class
    Interface to quantum computing devices (real or simulated).
FakeBackend : class
    Simulated quantum backend for testing without real hardware.

Examples
--------
>>> from qpanda3_runtime.device import QDevice, FakeBackend
>>> # Connect to a real quantum device
>>> real_device = QDevice('quantum_backend_url', access_token='token')
>>> result = real_device.run(circuit, shots=1000)

>>> # Use a fake backend for testing
>>> fake_device = FakeBackend()
>>> test_result = fake_device.run(test_circuit, shots=100)

Methods
-------
QDevice.run(circuit, shots=1000, **kwargs)
    Execute a quantum circuit on the device.
    
    Parameters
    ----------
    circuit : QuantumCircuit or str
        Quantum circuit to execute.
    shots : int, optional
        Number of measurement shots (default: 1000).
    **kwargs : dict
        Additional device-specific parameters.
    
    Returns
    -------
    dict
        Measurement results and metadata.

FakeBackend.run(circuit, shots=100, noise_model=None)
    Execute a circuit on a simulated backend.
    
    Parameters
    ----------
    circuit : QuantumCircuit
        Circuit to simulate.
    shots : int, optional
        Number of shots (default: 100).
    noise_model : dict, optional
        Noise model for simulation.

See Also
--------
qpanda3_runtime.runtime_service : Main service client for device management.
pyqpanda3 : Core quantum circuit library.

Notes
-----
- Real quantum devices require valid access tokens and backend URLs.
- Fake backends are useful for algorithm development and testing.
- Device calibration and availability may vary by provider.
"""

from .qdevice import QDevice
from .fake_backend import FakeBackend