from abc import abstractmethod
from ast import Dict
from typing import Union,List,Tuple,Optional
import numpy

from pyqpanda3.vqcircuit import VQCircuit
from pyqpanda3.utils.utils import convert_vqcircuit_to_originbis, convert_originbis_to_vqcircuit
from pyqpanda3.core import QProg, QCircuit

from .program_set.observable_bind_rule import AnsatzParamsBinding,CircuitObservableBinding,AnsatzObservableBinding
from ..utils.union_type import QProgUnionType, get_qprog,ObservableUnionType,get_observable
from ..device import QDevice,FakeBackend
from ..utils.convert_json_ndarray import ndarray_to_binary_json, binary_json_to_ndarray
from ..utils.convert_json_bytes import bytes_to_json_safe, json_safe_to_bytes

class QTaskInfo:
    """
    Abstract base class for quantum task information.
    
    This class defines the common interface for all quantum task information
    classes, including sampling and estimation tasks.
    
    Parameters
    ----------
    qtask_type : str
        Type of quantum task (e.g., 'sample', 'estimate').
    
    Attributes
    ----------
    qtask_type : str
        Type of quantum task.
    
    Notes
    -----
    This is an abstract base class. Subclasses must implement the
    `to_json_dict` method for serialization.
    """
    def __init__(self,qtask_type:str) -> None:
        self.qtask_type = qtask_type

    
    @abstractmethod
    def to_json_dict(self):
        """
        Convert task information to JSON-serializable dictionary.
        
        Returns
        -------
        dict
            JSON-serializable dictionary representation of task information.
        
        Raises
        ------
        NotImplementedError
            This method must be implemented by subclasses.
        """
        pass

class SampleQTaskInfo(QTaskInfo):
    """
    Information container for quantum sampling tasks.
    
    This class encapsulates all parameters required for quantum circuit
    sampling tasks, including circuits, device configuration, and
    execution parameters.
    
    Parameters
    ----------
    circuits : Union[QProgUnionType, List[QProgUnionType], AnsatzParamsBinding, Tuple[VQCircuit, List[numpy.ndarray]]]
        Quantum circuits to sample. Can be:
        - Single quantum program
        - List of quantum programs
        - Ansatz with parameter binding
        - Tuple of variational circuit and parameter list
    device : Union[QDevice, FakeBackend]
        Quantum device or simulator to execute the circuits.
    measure_qubits : Optional[List[int]], default=None
        Specific qubits to measure. If None, all qubits are measured.
    specified_block : Optional[List[int]], default=None
        Specific circuit blocks to execute. Used for partial execution.
    shots : int, default=10
        Number of measurement shots per circuit.
    is_amend : bool, default=True
        Whether to apply measurement error mitigation.
    is_mapping : bool, default=True
        Whether to apply qubit mapping for device topology.
    is_optimization : bool, default=True
        Whether to apply circuit optimization.
    point_label : int, default=0
        Label for parameter point in variational algorithms.
    task_describe : str, default=''
        Human-readable description of the task.
    
    Attributes
    ----------
    circuits : Union[QProgUnionType, List[QProgUnionType], AnsatzParamsBinding, Tuple[VQCircuit, List[numpy.ndarray]]]
        Quantum circuits to sample.
    device : Union[QDevice, FakeBackend]
        Execution device.
    measure_qubits : Optional[List[int]]
        Measurement qubits.
    specified_block : Optional[List[int]]
        Circuit blocks to execute.
    shots : int
        Number of shots.
    is_amend : bool
        Error mitigation flag.
    is_mapping : bool
        Qubit mapping flag.
    is_optimization : bool
        Circuit optimization flag.
    point_label : int
        Parameter point label.
    task_describe : str
        Task description.
    
    Examples
    --------
    >>> from qpanda3_runtime.task import SampleQTaskInfo
    >>> from qpanda3_runtime.device import QDevice
    >>> # Create sampling task for single circuit
    >>> task_info = SampleQTaskInfo(
    ...     circuits=quantum_circuit,
    ...     device=qdevice,
    ...     shots=1000,
    ...     task_describe='Ground state sampling'
    ... )
    """
    def __init__(self, circuits: Union[
                   QProgUnionType,
                   List[QProgUnionType],
                   AnsatzParamsBinding,
                   Tuple[
                       VQCircuit,
                       List[numpy.ndarray]
                   ]
               ],
               device: Union[QDevice, FakeBackend],
               measure_qubits: Optional[List[int]] = None,
               specified_block: Optional[List[int]] = None,
               shots:int=10,
               is_amend:bool=True,
               is_mapping:bool=True,
               is_optimization:bool=True,
               point_label:int=0,
               task_describe:str=''):
        super().__init__(qtask_type='sample')
        self.circuits = circuits
        self.device = device
        self.measure_qubits = measure_qubits
        self.specified_block = specified_block
        self.shots = shots
        self.is_amend = is_amend
        self.is_mapping = is_mapping
        self.is_optimization = is_optimization
        self.point_label = point_label
        self.task_describe = task_describe

    def circuits2dict(self):
        """
        Convert circuits to JSON-serializable dictionary.
        
        This method serializes the circuits attribute into a dictionary
        format suitable for JSON serialization and network transmission.
        
        Returns
        -------
        dict
            Dictionary with 'type' and 'data' keys representing the
            serialized circuits.
        
        Raises
        ------
        RuntimeError
            If the circuits type is not recognized.
        
        Notes
        -----
        The serialization format depends on the circuits type:
        - QProgUnionType: Serialized as OriginIR string
        - List[QProgUnionType]: List of OriginIR strings
        - AnsatzParamsBinding: JSON representation from binding object
        - Tuple[VQCircuit, List[numpy.ndarray]]: Serialized ansatz and parameters
        """
        cirs = {}
        if isinstance(self.circuits, (QProg, str, QCircuit)):
            cirs['type']='QProgUnionType'
            cirs['data']=get_qprog(self.circuits,res_type='originir')
        elif isinstance(self.circuits,List):
            cirs['type']='List[QProgUnionType]'
            cirs['data']=[]
            for cir in self.circuits:
                cirs['data'].append(get_qprog(cir,res_type='originir'))
        elif isinstance(self.circuits,AnsatzParamsBinding):
            cirs['type'] = 'AnsatzParamsBinding'
            cirs['data']=AnsatzParamsBinding.json()
        elif isinstance(self.circuits,Tuple):
            cirs['type'] = 'Tuple[VQCircuit,List[numpy.ndarray]]'
            ansatz = bytes_to_json_safe(convert_vqcircuit_to_originbis(self.circuits[0]))
            params = ndarray_to_binary_json(self.circuits[1])
            cirs['data']=(ansatz,params)
        else:
            raise RuntimeError("The type of circuits is invalid")
        return cirs

    @staticmethod
    def json_dict_to_ciruits(cirs:Dict):
        """
        Convert JSON dictionary back to circuits object.
        
        This method deserializes a dictionary representation back into
        the original circuits object format.
        
        Parameters
        ----------
        cirs : Dict
            Dictionary with 'type' and 'data' keys representing
            serialized circuits.
        
        Returns
        -------
        Union[QProgUnionType, List[QProgUnionType], AnsatzParamsBinding, Tuple[VQCircuit, List[numpy.ndarray]]]
            Deserialized circuits object.
        
        Raises
        ------
        RuntimeError
            If the dictionary is missing required keys or contains
            invalid data.
        
        Notes
        -----
        This is the inverse operation of `circuits2dict`.
        """
        if cirs.get('type') is None or cirs.get('data') is None:
            raise RuntimeError('Error data for converting to circuits')
        type = cirs['type']
        data = cirs['data']
        if type == 'QProgUnionType':
            if isinstance(data,str) is False:
                raise RuntimeError('Error data for converting to circuits')
            circuits = get_qprog(data,res_type='object')
        elif type == 'List[QProgUnionType]':
            circuits = []
            for cir in data:
                if isinstance(cir,str) is False:
                    raise RuntimeError('Error data for converting to circuits')
                circuits.append(get_qprog(cir,res_type='object'))
        elif type == 'AnsatzParamsBinding':
            if isinstance(data,AnsatzParamsBinding) is False:
                raise RuntimeError('Error data for converting to circuits')
            circuits = AnsatzParamsBinding.from_json(data)
        elif type == 'Tuple[VQCircuit,List[numpy.ndarray]]':
            ansatz = convert_originbis_to_vqcircuit(json_safe_to_bytes(data[0]))
            params = binary_json_to_ndarray(data[1])
            circuits = (ansatz,params)
        else:
            raise RuntimeError("Error type for converting to circuits")
        return circuits

    def to_json_dict(self):
        """
        Convert sampling task information to JSON-serializable dictionary.
        
        Returns
        -------
        dict
            Dictionary containing all task parameters in JSON-serializable
            format with the following structure:
            - type: Class name
            - qtask_type: Task type identifier
            - circuits: Serialized circuits from circuits2dict()
            - device: Serialized device information
            - measure_qubits: Measurement qubit indices
            - specified_block: Circuit block indices
            - shots: Number of measurement shots
            - is_amend: Error mitigation flag
            - is_mapping: Qubit mapping flag
            - is_optimization: Circuit optimization flag
            - point_label: Parameter point label
            - task_describe: Task description
        
        Notes
        -----
        This method implements the abstract method from QTaskInfo.
        """
        data = {'type':'SampleQTaskInfo'}
        data['qtask_type'] = self.qtask_type
        data['circuits'] = self.circuits2dict()
        data['device'] = self.device.to_json_dict()
        data['measure_qubits']=self.measure_qubits
        data['specified_block']=self.specified_block
        data['shots']=self.shots
        data['is_amend']=self.is_amend
        data['is_mapping']=self.is_mapping
        data['is_optimization']=self.is_optimization
        data['point_label']=self.point_label
        data['task_describe'] = self.task_describe
        return data
        
    @staticmethod
    def from_json_dict(runtime_service,data):
        circuits = SampleQTaskInfo.json_dict_to_ciruits(cirs=data['circuits'])
        if data['device']['type'] == 'FakeBackend':
            device = FakeBackend.from_json_dict(runtime_service,data['device'])
        elif data['device']['type'] == 'QDevice':
            device = QDevice.from_json_dict(runtime_service,data['device'])
        else:
            raise RuntimeError("The data of device is invalid")
        return SampleQTaskInfo(
            circuits=circuits,
            device=device,
            measure_qubits=data['measure_qubits'],
            specified_block=data['specified_block'],
            shots=data['shots'],
            is_amend=data['is_amend'],
            is_mapping=data['is_mapping'],
            is_optimization=data['is_optimization'],
            point_label=data['point_label'],
            task_describe=data['task_describe']
        )

    def input_for_service_sample(self):
        return (self.circuits,
            self.device,
            self.measure_qubits,
            self.specified_block,
            self.shots,
            self.is_amend,
            self.is_mapping,
            self.is_optimization,
            self.point_label,
            self.task_describe
        )
        

class EstimateQTaskInfo(QTaskInfo):
    """
    Information container for quantum expectation value estimation tasks.
    
    This class encapsulates all parameters required for estimating
    expectation values of observables on quantum circuits.
    
    Parameters
    ----------
    circuit_with_observable : Union[Tuple[Union[QProgUnionType, List[QProgUnionType]], ObservableUnionType], CircuitObservableBinding, AnsatzObservableBinding]
        Quantum circuit(s) with associated observable(s). Can be:
        - Tuple of circuit(s) and observable
        - CircuitObservableBinding object
        - AnsatzObservableBinding object
    device : Union[QDevice, FakeBackend]
        Quantum device or simulator to execute the circuits.
    specified_block : Optional[List[int]], default=None
        Specific circuit blocks to execute. Used for partial execution.
    shots : int, default=1000
        Number of measurement shots per circuit.
    is_amend : bool, default=True
        Whether to apply measurement error mitigation.
    is_mapping : bool, default=True
        Whether to apply qubit mapping for device topology.
    is_optimization : bool, default=True
        Whether to apply circuit optimization.
    task_describe : str, default=''
        Human-readable description of the task.
    
    Attributes
    ----------
    circuit_with_observable : Union[Tuple[Union[QProgUnionType, List[QProgUnionType]], ObservableUnionType], CircuitObservableBinding, AnsatzObservableBinding]
        Circuit-observable combination.
    device : Union[QDevice, FakeBackend]
        Execution device.
    specified_block : Optional[List[int]]
        Circuit blocks to execute.
    shots : int
        Number of shots.
    is_amend : bool
        Error mitigation flag.
    is_mapping : bool
        Qubit mapping flag.
    is_optimization : bool
        Circuit optimization flag.
    task_describe : str
        Task description.
    
    Examples
    --------
    >>> from qpanda3_runtime.task import EstimateQTaskInfo
    >>> from qpanda3_runtime.device import QDevice
    >>> # Create estimation task for single circuit and observable
    >>> task_info = EstimateQTaskInfo(
    ...     circuit_with_observable=(quantum_circuit, observable),
    ...     device=qdevice,
    ...     shots=5000,
    ...     task_describe='Energy expectation estimation'
    ... )
    """
    def __init__(self,
        
        circuit_with_observable: Union[
            Tuple[
                Union[QProgUnionType, List[QProgUnionType]],
                ObservableUnionType
            ],
            CircuitObservableBinding,
            AnsatzObservableBinding
        ],
        device: Union[QDevice, FakeBackend],
        specified_block: Optional[List[int]] = None,
        shots:int=1000,
        is_amend:bool=True,
        is_mapping:bool=True,
        is_optimization:bool=True,
        task_describe:str=''
        ):

        super().__init__(qtask_type='estimate')
        self.circuit_with_observable = circuit_with_observable
        self.device = device
        self.specified_block = specified_block
        self.shots = shots
        self.is_amend = is_amend
        self.is_mapping = is_mapping
        self.is_optimization = is_optimization
        self.task_describe = task_describe
    
    def to_json_dict_circuit_with_observable(self):
        data = {}
        if isinstance(self.circuit_with_observable,Tuple):
            prog_ = self.circuit_with_observable[0]
            if isinstance(prog_, list):
                data['type']='Tuple[List[QProgUnionType],ObservableUnionType]'
                prog = []
                for cir in prog_:
                    prog.append(get_qprog(cir,'originir'))
            else:
                data['type']='Tuple[QProgUnionType,ObservableUnionType]'
                prog = get_qprog(prog_,res_type='originir')
            observable_ = self.circuit_with_observable[1]
            observable = get_observable(observable_,res_type='str')
            data['data']=(prog,observable)
        elif isinstance(self.circuit_with_observable,CircuitObservableBinding):
            data['type']='CircuitObservableBinding'
            data['data'] = self.circuit_with_observable.to_json_dict()
        elif isinstance(self.circuit_with_observable,AnsatzObservableBinding):
            data['type']='AnsatzObservableBinding'
            data['data']=self.circuit_with_observable.to_json_dict()
        else:
            raise RuntimeError('Invalid circuit_with_observable data')
        return data

    @staticmethod
    def json_dict_to_circuit_with_observable(data:Dict):
        if data.get('type') is None or data.get('data') is None:
            raise RuntimeError("The data for circuit_with_observable is invalid")
        if data['type'] in ['Tuple[QProgUnionType,ObservableUnionType]','Tuple[List[QProgUnionType],ObservableUnionType]']:
            res = data['data']
        elif data['type'] == 'CircuitObservableBinding':
            res = CircuitObservableBinding.from_json_dict(data['data'])
        elif data['type'] == 'AnsatzObservableBinding':
            res = AnsatzObservableBinding.from_json_dict(data['data'])
        else:
            raise RuntimeError("The data for circuit_with_observable is invalid")
        return res

    def to_json_dict(self):
        data = {'type':'EstimateQTaskInfo'}
        data['qtask_type'] = self.qtask_type
        data['circuit_with_observable'] = self.to_json_dict_circuit_with_observable()
        data['device'] = self.device.to_json_dict()
        data['specified_block']=self.specified_block
        data['shots']=self.shots
        data['is_amend']=self.is_amend
        data['is_mapping']=self.is_mapping
        data['is_optimization']=self.is_optimization
        data['task_describe'] = self.task_describe
        return data

    

    @staticmethod
    def from_json_dict(runtime_service,data):
        circuit_with_observable = EstimateQTaskInfo.json_dict_to_circuit_with_observable(data['circuit_with_observable'])
        if data['device']['type'] == 'FakeBackend':
            device = FakeBackend.from_json_dict(runtime_service,data['device'])
        elif data['device']['type'] == 'QDevice':
            device = QDevice.from_json_dict(runtime_service,data['device'])
        else:
            raise RuntimeError("The data of device is invalid")
        return EstimateQTaskInfo(
            circuit_with_observable=circuit_with_observable,
            device=device,
            specified_block=data['specified_block'],
            shots=data['shots'],
            is_amend=data['is_amend'],
            is_mapping=data['is_mapping'],
            is_optimization=data['is_optimization'],
            task_describe=data['task_describe']
        )

    def input_for_service_estimate(self):
        return (self.circuit_with_observable,
            self.device,
            self.specified_block,
            self.shots,
            self.is_amend,
            self.is_mapping,
            self.is_optimization,
            self.task_describe
        )