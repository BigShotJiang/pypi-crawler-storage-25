import time
from typing import Dict, Union

from pyqpanda3.core import QProg, measure
from pyqpanda3.vqcircuit import VQCircuit

from qpanda3_runtime.access_service.channel import default_channel
from .vqsession_abc import VQSessionABC
from ..qtask_manager import QTaskManager
from qpanda3_runtime.device.fake_backend import FakeBackend


class FakeVQSession(VQSessionABC):
    """
    Fake variational quantum session for local testing and simulation.
    
    This class provides a mock implementation of VQSessionABC that runs quantum
    circuits locally using a fake backend device, without requiring remote
    quantum computing services.
    
    Parameters
    ----------
    runtime_service : object
        Runtime service instance for task management.
    vqcircuit : VQCircuit
        Variational quantum circuit (ansatz) structure.
    device : FakeBackend
        Fake backend device for local quantum circuit simulation.
    channel : object, optional
        Communication channel (default is default_channel).
    info : Dict or None, optional
        Additional session information.
    
    Attributes
    ----------
    _ansatz : VQCircuit
        Internal storage for the variational quantum circuit.
    _device : FakeBackend
        Internal storage for the fake backend device.
    """

    def __init__(self, runtime_service, vqcircuit: VQCircuit, device: FakeBackend, channel=default_channel,
                 info=Union[Dict, None]):
        timestamp = time.strftime('%Y%m%d%H%M%S')
        session_id = 'FakeVQSession' + timestamp
        task_ids = [session_id + '#0']
        chip_id = device.chip_id()
        super().__init__(runtime_service, session_id, chip_id, task_ids, channel, info)
        self._ansatz = vqcircuit
        self._device = device
        # self._tasks: Dict[str, Union[QTaskManager, None]] = {task_ids[0]: None}

    def run_vqtask(self,
                   gate_params,
                   measure_list: list
                   )->QTaskManager:
        """
        Execute a variational quantum task using the session's ansatz structure.
        
        This method generates quantum circuits from the variational ansatz using
        the provided gate parameters, transpiles them for the fake backend device,
        and simulates quantum measurements.
        
        Parameters
        ----------
        gate_params : array-like
            Quantum gate parameters adapted to the ansatz structure.
            Used for generating quantum computing tasks.
        measure_list : list
            List of qubit indices to be measured.
        
        Returns
        -------
        QTaskManager
            Task manager object for the computing task.
        
        Raises
        ------
        RuntimeError
            If called outside of a VQSession context manager.
        
        Notes
        -----
        This method must be called within a VQSession context manager.
        The generated circuits are transpiled for the fake backend device
        before simulation.
        
        Examples
        --------
        >>> with FakeVQSession(...) as session:
        ...     task_manager = session.run_vqtask(gate_params, [0, 1])
        ...     result = task_manager.get_result()
        """
        if not self._in_context:
            raise RuntimeError("This method can only be called within a with context.")
        cirs = self._ansatz(gate_params).circuits()
        progs = []
        for cir in cirs:
            prog = QProg(cir)
            for q in measure_list:
                prog << measure(q, q)
            progs.append(prog)

        transpiled_progs, failed_transpiled_circuits = self._device._transpile(progs=progs)

        res = []
        # transpiled_progs = progs
        for prog in transpiled_progs:
            res.append(self._device.sample(prog))

        task_id = self._session_id + '#' + str(len(self._task_ids))
        self._task_ids.append(task_id)

        task_info = {
            'type': 'sample',
            'circuits': progs,
            'device': self._device.real_device()
        }
        task_data = {'task_id': [task_id], 'result': res, 'is_transpile_successed': True, 'task_info': task_info,
                     'session_id': self._session_id}
        return QTaskManager(self._runtime_service, task_data, used_remote_backend=False, used_fake_backend=True)

    def release(self):
        """
        Release the fake variational quantum session.
        
        This method is a no-op for fake sessions as they don't require
        remote resource cleanup.
        
        Notes
        -----
        Fake sessions don't hold remote resources, so this method
        doesn't perform any actual cleanup operations.
        """
        pass
