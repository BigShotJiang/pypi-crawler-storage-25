"""
Session management for variational quantum algorithms.

This module provides interfaces for managing variational quantum computing sessions,
including abstract base classes and concrete implementations.

Classes
-------
FakeVQSession : class
    Simulated variational quantum session for testing purposes.

See Also
--------
VQSession : Concrete implementation for real quantum backends.
VQSessionABC : Abstract base class for variational quantum sessions.

Notes
-----
- Sessions should be used within context managers (`with` statements).
- Variational sessions support parameterized quantum circuit execution.
"""

from .fake_vqsession import FakeVQSession