"""
Abstract base class for variational quantum computing sessions.

This module defines the abstract interface for variational quantum algorithm sessions,
providing a common contract for all session implementations.

Classes
-------
VQSessionABC : ABC
    Abstract base class for variational quantum computing sessions.

See Also
--------
VQSession : Concrete implementation for real quantum backends.
FakeVQSession : Simulated session for testing.

Notes
-----
- All concrete implementations must inherit from this base class.
- Sessions are designed to be used as context managers.
"""

from abc import ABC, abstractmethod
from typing import List, Union, Dict
from ..qtask_manager import QTaskManager


class VQSessionABC(ABC):
    """
    Abstract base class for variational quantum computing sessions.
    
    Defines the common interface for all variational quantum session implementations.
    Sessions manage the lifecycle of variational quantum computing tasks and provide
    context management for resource cleanup.
    
    Parameters
    ----------
    runtime_service : object
        Runtime service instance for task management.
    session_id : str
        Unique identifier for the session.
    task_ids : list
        List of task identifiers associated with the session.
    channel : str
        Communication channel identifier.
    info : dict or None, optional
        Additional session information (default: None).
    
    Attributes
    ----------
    _runtime_service : object
        Runtime service instance.
    _in_context : bool
        Flag indicating if session is within a context manager.
    _session_id : str
        Session identifier.
    _task_ids : list
        List of task identifiers.
    _channel : str
        Communication channel.
    _info : dict or None
        Additional session information.
    """
    
    def __init__(self, runtime_service, session_id:str, chip_id:str, task_ids:list, channel:str, info=Union[Dict, None]):
        self._runtime_service = runtime_service
        self._in_context = False
        self._session_id = session_id
        self._chip_id = chip_id
        self._task_ids = task_ids
        self._channel = channel
        self._info = info
       
        
    def __enter__(self):
        """
        Enter the session context.
        
        Returns
        -------
        VQSessionABC
            The session instance.
        """
        self._in_context = True
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Exit the session context.
        
        Parameters
        ----------
        exc_type : type or None
            Exception type if an exception occurred.
        exc_val : Exception or None
            Exception value if an exception occurred.
        exc_tb : traceback or None
            Traceback if an exception occurred.
        
        Returns
        -------
        bool
            False to propagate exceptions, True to suppress them.
        """
        self.release()
        self._in_context = False
        return False

    @abstractmethod
    def run_vqtask(self, gate_params, measure_list: list) -> QTaskManager:
        """
        Submit a variational quantum task to the session.
        
        Parameters
        ----------
        gate_params : array-like
            Quantum gate parameters for the variational circuit.
        measure_list : list
            List of qubit indices to measure.
        
        Returns
        -------
        QTaskManager
            Task manager instance for the submitted task.
        
        Raises
        ------
        NotImplementedError
            This method must be implemented by subclasses.
        """
        pass

    def task_ids(self) -> List:
        """
        Get the list of task identifiers associated with this session.
        
        Returns
        -------
        List[str]
            List of task identifiers.
        """
        return self._task_ids

    @abstractmethod
    def release(self):
        """
        Release session resources.
        
        This method should clean up any resources associated with the session
        and notify the backend that the session is no longer needed.
        
        Raises
        ------
        NotImplementedError
            This method must be implemented by subclasses.
        """
        pass
