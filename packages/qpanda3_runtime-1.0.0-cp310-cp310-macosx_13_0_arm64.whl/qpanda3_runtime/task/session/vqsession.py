"""
Concrete implementation of variational quantum computing session.

This module provides the main implementation of variational quantum algorithm sessions
for real quantum computing backends.

Classes
-------
VQSession : VQSessionABC
    Concrete implementation for variational quantum computing sessions.

See Also
--------
VQSessionABC : Abstract base class for variational quantum sessions.
FakeVQSession : Simulated session for testing.

Notes
-----
- This class should be instantiated through RuntimeService.vqsession() factory method.
- Sessions must be used within context managers for proper resource cleanup.
"""

from typing import Dict, Union
from ...access_service.channel import default_channel
from .vqsession_abc import VQSessionABC
from ..qtask_manager import QTaskManager


class VQSession(VQSessionABC):
    """
    Concrete implementation of variational quantum computing session.
    
    A client-side management object for variational quantum computing sessions
    that interfaces with QPanda3 quantum computing runtime service.
    
    Parameters
    ----------
    runtime_service : RuntimeService
        Local management object for QPanda3 Runtime Service, used for defining
        and submitting quantum computing tasks.
    session_id : str
        Unique identifier for the variational computing session.
    task_ids : list
        List of IDs for quantum computing tasks in the session.
    channel : str, optional
        Access channel for variational quantum computing sessions (default: default_channel).
    info : dict or None, optional
        Additional session information (reserved for future use, default: None).
    
    Notes
    -----
    This class should be used within a context manager (`with` statement) to ensure
    proper resource cleanup. Instances are typically created through the
    RuntimeService.vqsession() factory method.
    
    Examples
    --------
    >>> from qpanda3_runtime import RuntimeService
    >>> service = RuntimeService('config.yml')
    >>> with service.vqsession(vqcircuit=ansatz, device=quantum_device) as session:
    ...     task = session.run_vqtask(gate_params, measure_list=[0, 1])
    ...     result = task.get_result_sync()
    """
    
    def __init__(self, runtime_service, session_id:str, chip_id:str, task_ids:list, channel:str=default_channel, info=Union[Dict, None]):
        super().__init__(runtime_service, session_id, chip_id, task_ids, channel, info) 

    def run_vqtask(self, gate_params, measure_list: list) -> QTaskManager:
        """
        Submit a variational quantum task to the session.
        
        Parameters
        ----------
        gate_params : array-like
            Quantum gate parameters adapted to the Ansatz structure.
            Used for generating quantum computing tasks.
        measure_list : list
            List of qubit indices to measure.
        
        Returns
        -------
        QTaskManager
            Client management object for the computing task.
        
        Raises
        ------
        RuntimeError
            If called outside of a session context.
        
        Notes
        -----
        This method can only be called within a VQSession context manager.
        The submitted task is automatically added to the session's task list.
        
        See Also
        --------
        QTaskManager : Task management interface for submitted tasks.
        """
        if not self._in_context:
            raise RuntimeError("This method can only be called within a with context.")
        task = self._runtime_service.run_vqtask(self._session_id, gate_params, measure_list, channel=self._channel,
                                                return_type='QTaskManager')
        self._task_ids.append(task.id())
        return task

    def release(self):
        """
        Release the quantum runtime service session.
        
        Requests the release of the quantum runtime service session using
        the specified session ID. This method is automatically called when
        exiting the session context.
        
        Notes
        -----
        This method is idempotent and can be called multiple times safely.
        It only takes effect when called within a session context.
        """
        if self._in_context:
            response = self._runtime_service.release_session(session_id=self._session_id,
                chip_id=self._chip_id, channel=self._channel)
            self._in_context = False
