import json
from shutil import ExecError
import threading
import time
from typing import Callable, Any, List, Optional, Dict

from .qtask_info import QTaskInfo,SampleQTaskInfo,EstimateQTaskInfo
from ..utils.exception.response_error import ResponseError
from ..toolbox.checkpoint import CheckPoint
from ..toolbox.tracker import Tracker


class QTaskManager:
    """
    Quantum Computing Task Manager for QPanda3 Runtime Service.
    
    This class provides local management for quantum computing tasks,
    including task submission, result retrieval, and state management.
    It supports synchronous, asynchronous, and background execution modes.
    
    Parameters
    ----------
    runtime_service : RuntimeService
        Runtime service instance for task execution and communication.
    task_data : Dict
        Task metadata containing task ID, session information, and
        other configuration parameters.
    used_remote_backend : bool, default=True
        Whether the task uses a remote computational backend.
    used_fake_backend : bool, default=False
        Whether the task uses a FakeBackend simulator.
    used_program_set : bool, default=False
        Whether the task uses ProgramSet for parameterized circuits.
    
    Attributes
    ----------
    _runtime_service : RuntimeService
        Reference to the runtime service.
    _id : Union[str, List[str]]
        Task ID or list of sub-task IDs.
    _session_id : str
        Session identifier for variational algorithms.
    _data : Dict
        Original task metadata.
    _used_remote_backend : bool
        Remote backend usage flag.
    _used_program_set : bool
        ProgramSet usage flag.
    _client_task_id : Optional[str]
        Client-generated task identifier.
    _sub_task_id__result_id : Dict[str, int]
        Mapping from sub-task ID to result index.
    _result : List[Any]
        Task execution results.
    _is_transpile_successed : bool
        Circuit transpilation success flag.
    _processing_sub_task_ids : List[str]
        List of sub-task IDs still being processed.
    _used_fake_backend : bool
        FakeBackend usage flag.
    _data_lock : threading.Lock
        Thread lock for concurrent access.
    _result_fetching_thread : Optional[threading.Thread]
        Background result fetching thread.
    
    Examples
    --------
    >>> from qpanda3_runtime import RuntimeService
    >>> from qpanda3_runtime.task import QTaskManager
    >>> # Create task manager for submitted task
    >>> runtime_service = RuntimeService()
    >>> task_data = {'task_id': 'task_123', 'channel': 'qcloud'}
    >>> task_manager = QTaskManager(runtime_service, task_data)
    >>> # Retrieve results
    >>> results, finished, progress = task_manager.try_get_result()
    
    Notes
    -----
    - Thread-safe design for concurrent access
    - Supports checkpoint saving and recovery
    - Provides multiple result retrieval strategies
    - Integrates with tracking system for monitoring
    """
    def __init__(self, runtime_service, task_data, used_remote_backend=True, used_fake_backend=False,
                 used_program_set=False):
        from ..runtime_service import RuntimeService
        self._qtask_manager_init_time = time.time()
        self._runtime_service: RuntimeService = runtime_service
        self._id = task_data['task_id']
        self._session_id = ''
        if task_data.get('session_id') is not None:
            self._session_id = task_data['session_id']
        self._data = task_data
        self._used_remote_backend: bool = used_remote_backend
        self._used_program_set: bool = used_program_set
        self._client_task_id = task_data.get('client_task_id',None)

        if used_remote_backend:
            self._sub_task_id__result_id = {sub_task_id: result_id for result_id, sub_task_id in enumerate(self._id)}
            self._result = ['Status:Processing' for _ in range(len(self._id))]
            self._is_transpile_successed = False
        else:
            self._sub_task_id__result_id = {}
            self._result = task_data['result']
            self._is_transpile_successed = task_data['is_transpile_successed']

        self._processing_sub_task_ids = self._id
        self._result_fetching_thread = None
        self._data_lock = threading.Lock()
        self._used_fake_backend = used_fake_backend

    def _parse_res_item(self, data):
        tmp_ = []
        task_type = data.get('taskType')
        if task_type is None:
            return data.get('taskResult')
        for res_item in data.get('taskResult'):
            if task_type == 'sample':
                tmp_.append(self._parse_sample_task_res(res_item))
            elif task_type== 'estimate':
                tmp_.append(self._parse_estimate_task_res(res_item))
        return tmp_

    def try_get_result(self, additional_info: Optional[List[str]] = None):
        """
        Query task execution results with incremental strategy.
        
        This method queries the current status of computational tasks and
        returns available results. It only queries unfinished subtasks but
        returns all currently obtained result data. Subsequent calls use
        incremental strategy, storing fetched results internally.
        
        Parameters
        ----------
        additional_info : Optional[List[str]], default=None
            Additional query fields for task execution information.
            Refer to backend documentation for supported fields.
        
        Returns
        -------
        Tuple[List[Any], bool, str]
            Three-element tuple containing:
            - List of task results (unavailable results marked as "Status:Processing")
            - Boolean indicating if all results are complete
            - String showing completion percentage (e.g., "finished 75%")
        
        Raises
        ------
        RuntimeError
            If task query fails or returns error response.
        
        Notes
        -----
        - Uses incremental fetching: only queries unfinished subtasks
        - Results are cached internally for subsequent calls
        - For batch tasks, queries all sub-task results
        - Integrates with tracking system for monitoring
        
        Examples
        --------
        >>> results, finished, progress = task_manager.try_get_result()
        >>> while not finished:
        ...     print(f"Progress: {progress}")
        ...     time.sleep(5)
        ...     results, finished, progress = task_manager.try_get_result()
        >>> print(f"Final results: {results}")
        """
        tracker = Tracker(self._runtime_service)
        self._runtime_service._start_tracking(tracker,'QTaskManager try_get_result',labels=['QUERY_TASK'])

        try:
            if additional_info is None:
                additional_info = []
            if self.used_remote_backend():
                res = self._runtime_service.query_task(self.channel(), self._processing_sub_task_ids, additional_info)
                _processing_sub_task_ids = []
                for id_ in range(len(self._processing_sub_task_ids)):
                    if isinstance(res[id_],Exception):
                        raise res[id_]
                    if res[id_].get('taskResult') is None:
                        error = ResponseError.from_dict(res[id_])
                        error = RuntimeError(error)
                        raise error 
                    if isinstance(res[id_].get('taskResult'), list) and (
                            len(res[id_].get('taskResult')) == 0 or res[id_].get('taskResult')[0] == ''):
                        _processing_sub_task_ids.append(self._processing_sub_task_ids[id_])
                    else:
                        self._result[
                            self._sub_task_id__result_id[self._processing_sub_task_ids[id_]]] = self._parse_res_item(
                            res[id_])

                self._processing_sub_task_ids = _processing_sub_task_ids
            all_finished = False
            if len(self._sub_task_id__result_id) == 0:
                finished_rate = 100
                all_finished = True
            else:
                finished_rate = (1.0 - len(self._processing_sub_task_ids) / len(self._sub_task_id__result_id)) * 100
                if abs(finished_rate - 100) < 1e-4:
                    finished_rate = 100
                    all_finished = True
            if self._used_program_set and all_finished:
                res = self._result[0][0], all_finished, f'finished {finished_rate}%'
            else:
                res = self._result, all_finished, f'finished {finished_rate}%'
            self._runtime_service._end_tracking(tracker,data={},labels=['SUCCESS'])
            return res
        except Exception as e:
            self._runtime_service._end_tracking(tracker,{'error':str(e),'task_state':self.get_task_state()},labels=['ERROR'])
            raise e

    @staticmethod
    def _parse_estimate_task_res(item_data: str):
        res = []
        for item in item_data.split(','):
            res.append(float(item))
        return res

    @staticmethod
    def _parse_sample_task_res(item_data: str):
        res = json.loads(item_data)
        return res

    async def get_result_async(self, additional_info: Optional[List[str]] = None, timeout=1800):
        """
        A coroutine function wrapped for the asyncio asynchronous library.

        Parameters
        ----------
        additional_info: Optional[List[str]]
            Query fields related to compute task execution information. For specific details about these fields, please
            refer to the support documentation of the respective compute backend.

        timeout: int
            The maximum duration for querying the task process. Once this time length (in seconds) is exceeded, the
            system will start canceling the query requests for the task.

        Returns
        -------
        list
            The execution results of the computational task
        """
        tracker = Tracker(self._runtime_service)
        self._runtime_service._start_tracking(tracker,'get_result_async',labels=['QUERY_TASK'])
        try:
            res = self._get_result(additional_info,timeout)
            self._runtime_service._end_tracking(tracker,data={},labels=['SUCCESS'])
        except Exception as e:
            self._runtime_service._end_tracking(tracker,data={},labels=['ERROR'])
        return res

    def _get_result(self, additional_info: Optional[List[str]] = None, timeout=1800,using_http=True):
        if additional_info is None:
            additional_info = []
        if self.used_remote_backend():
            if timeout < 120:
                raise RuntimeError("timeout shouldn't be smaller than 120 seconds")
            time_start = self._qtask_manager_init_time
            while len(self._processing_sub_task_ids) != 0:
                res = self._runtime_service.query_task(self.channel(),self._processing_sub_task_ids,additional_info,using_http=using_http)
                _processing_sub_task_ids = []
                for id_ in range(len(self._processing_sub_task_ids)):
                    if res[id_].get('taskResult') is None:
                        error = ResponseError.from_dict(res[id_])
                        raise RuntimeError(error)
                    if isinstance(res[id_].get('taskResult'), list) and (
                            len(res[id_].get('taskResult')) == 0 or res[id_].get('taskResult')[0] == ''):
                        _processing_sub_task_ids.append(self._processing_sub_task_ids[id_])
                    else:
                        if len(additional_info) > 0:
                            self._result[self._sub_task_id__result_id[self._processing_sub_task_ids[id_]]] = res[id_]
                            continue
                        tmp_ = self._parse_res_item(res[id_])

                        self._result[self._sub_task_id__result_id[self._processing_sub_task_ids[id_]]] = tmp_

                self._processing_sub_task_ids = _processing_sub_task_ids
                finished_task_num = len(self._sub_task_id__result_id) - len(self._processing_sub_task_ids)
                time_span = time.time() - time_start
                if len(self._processing_sub_task_ids) > 0 and time_span > timeout:
                    raise RuntimeError(
                        f"The query result took more than {time_span} seconds to resolve. If you wish to change the "
                        f"timeout limit, please modify parameter {timeout}.")
                if finished_task_num == 0:
                    time.sleep(time_span*0.1)
                else:
                    if len(self._processing_sub_task_ids) != 0:
                        time_wait = time_span / finished_task_num * (len(self._processing_sub_task_ids))
                        if time_wait >= 1.2:
                            time_wait = 1.2
                        time.sleep(time_wait)
        if self._used_program_set:
            res = self._result[0][0]
        else:
            res = self._result
        return res

    def get_result_sync(self, additional_info: Optional[List[str]] = None, timeout=1000*1800, using_http=True):
        """
        Synchronously query task execution results with blocking behavior.
        
        This method blocks the client program until all result data is
        returned or timeout is reached. It continuously polls for results
        until completion.
        
        Parameters
        ----------
        additional_info : Optional[List[str]], default=None
            Additional query fields for task execution information.
        timeout : int, default=1,800,000
            Maximum query duration in seconds before raising timeout error.
        using_http : bool, default=True
            Protocol to use for query:
            - True: HTTP protocol
            - False: TCP protocol
        
        Returns
        -------
        List[Any]
            Complete task execution results.
        
        Raises
        ------
        RuntimeError
            If query timeout is exceeded or task execution fails.
        
        Notes
        -----
        - Blocks until all results are available or timeout
        - Uses polling strategy with adaptive wait times
        - Supports both HTTP and TCP protocols
        - Timeout value should be sufficiently large for quantum tasks
        
        Examples
        --------
        >>> # Block until results are available (up to 30 minutes)
        >>> results = task_manager.get_result_sync(timeout=1800)
        >>> print(f"Synchronous results: {results}")
        """
        tracker = Tracker(self._runtime_service)
        self._runtime_service._start_tracking(tracker,'try get result sync',labels=['QUERY_TASK'])
        try:
            if additional_info is None:
                additional_info = []
            if self.used_remote_backend():
                res = self._get_result(additional_info,timeout,using_http=using_http)
            if self._used_program_set:
                res = self._result[0]
            else:
                res = self._result
            self._runtime_service._end_tracking(tracker,data={},labels=['SUCCESS'])
            return res
        except Exception as e:
             self._runtime_service._end_tracking(tracker,data={'error':str(e)},labels=['ERROR'])
             raise e

    def get_result_background(self, call_back: Callable[[Any], None], additional_info: Optional[List[str]] = None,
                              timeout=1800):
        """
        Use a sub-thread to pull the execution results of the computational task in the background.

        Termination of the sub‑thread
            The sub‑thread ends after returning all result data, or is terminated when the main thread ends.

        Monitoring the status of the sub‑thread
            QTaskManager.get_result_background returns a monitoring function.
            The return value of the monitoring function is a Boolean: True indicates that the background sub‑thread has ended; otherwise, it returns False.


        Parameters
        ----------
        call_back: Callable[[Any], None]
            A callback function can be passed to `QTaskManager.get_result_background`.

        additional_info: Optional[List[str]]
            Query fields related to compute task execution information. For specific details about these fields, please
            refer to the support documentation of the respective compute backend.

        timeout: int
            The maximum duration for querying the task process. Once this time length (in seconds) is exceeded, the
            system will start canceling the query requests for the task.


        Returns
        -------
        list
            The execution results of the computational task
        """
        def check_status():
            with self._data_lock:
                return len(self._processing_sub_task_ids) == 0
        tracker = Tracker(self._runtime_service)
        self._runtime_service._start_tracking(tracker,'try get result background',labels=['QUERY_TASK'])
        try:
            if additional_info is None:
                additional_info = []
            if self.used_remote_backend():
                def func(call_back_: Callable[[Any], None]):
                    with self._data_lock:
                        res = self._get_result(additional_info,timeout)
                    call_back_(res)

                thread = threading.Thread(
                    target=func,
                    args=(call_back,),
                    daemon=True
                )
                thread.start()

            self._runtime_service._end_tracking(tracker,data={},labels=['SUCCESS'])
            return check_status
        except Exception as e:
            self._runtime_service._end_tracking(tracker,data={'error':str(e)},labels=['ERROR'])
            raise e
        

    def id(self):
        """
        Get the ID of the computational task (represented by the set of subtask IDs).

        Returns
        -------
        list
            The ID of the computational task, a set of subtask IDs.
        str
            The ID of the computational task,a subtask's id.
        """
        if self._used_remote_backend:
            if self._used_program_set or self._session_id != '':
                return self._id[0]
            else:
                return self._id
        else:
            raise RuntimeError("This task is without task id, because the task was generated without a remote backend.")

    def progs(self):
        """
        Retrieve all quantum circuits from the metadata of the quantum computing task.

        Returns
        -------
        list
            All quantum circuits from the metadata of the quantum computing task
        """
        return self._data['progs']

    def used_remote_backend(self):
        """
        Determine whether the quantum computing task uses a remote computing backend.

        Returns
        -------
        bool
            True: Yes

            False: No
        """
        return self._used_remote_backend

    def used_fake_backend(self):
        """
        Determine whether the quantum computing task uses a FakeBackend.

        Returns
        -------
        bool
            True: Yes

            False: No
        """
        return self._used_fake_backend

    def run_on_real_device(self, shots=1000):
        """
        Execute pre-verified task on real quantum hardware.
        
        Submit a quantum computing task that was previously verified on
        a FakeBackend to real quantum hardware for execution. This method
        is only available when the current task uses a FakeBackend and
        transpilation was successful.
        
        Parameters
        ----------
        shots : int, default=1000
            Number of measurement shots for the experiment.
        
        Returns
        -------
        QTaskManager
            New task manager for the real hardware execution.
        
        Raises
        ------
        RuntimeError
            If task doesn't use FakeBackend or transpilation failed.
        
        Notes
        -----
        - Requires successful transpilation on FakeBackend
        - Creates new task on real quantum hardware
        - Preserves all task parameters except backend
        - Useful for simulation-to-hardware workflow
        
        Examples
        --------
        >>> # First run on FakeBackend for verification
        >>> fake_task = runtime_service.sample(circuit, fake_backend, shots=100)
        >>> # If successful, run on real hardware
        >>> if fake_task.used_fake_backend():
        ...     real_task = fake_task.run_on_real_device(shots=1000)
        ...     results = real_task.get_result_sync()
        """
        tracker = Tracker(self._runtime_service)
        self._runtime_service._start_tracking(tracker,'run_on_real_device',labels=['QTASK','QPU'])
        try:
            if self._used_fake_backend:
                if self._is_transpile_successed:
                    if 'metadata' not in self._data:
                        raise KeyError("No task metadata found in _data")
                    
                    if self._data['metadata']['qtask_type'] == 'sample':
                        task_metadata = SampleQTaskInfo.from_json_dict(self._runtime_service,self._data['metadata'])                        
                        tracker.record(data=[],labels=['SAMPLE'])
                        
                        sample_args = task_metadata.input_for_service_sample()
                        res = self._runtime_service.sample(
                            circuits=sample_args[0],
                            device=sample_args[1].real_device(),
                            measure_qubits=sample_args[2],
                            specified_block=sample_args[3],
                            shots=sample_args[4],
                            is_amend=sample_args[5],
                            is_mapping=sample_args[6],
                            is_optimization=sample_args[7],
                            point_label=sample_args[8],
                            task_describe=sample_args[9]
                        )
                    elif self._data['metadata']['qtask_type'] == 'estimate':
                        task_metadata = EstimateQTaskInfo.from_json_dict(self._runtime_service,self._data['metadata'])
                        tracker.record(data=[],labels=['ESTIMATE'])
                        estimate_args = task_metadata.input_for_service_estimate()
                        res = self._runtime_service.estimate(
                            estimate_args[0],
                            estimate_args[1].real_device(),
                            estimate_args[2],
                            estimate_args[3],
                            estimate_args[4],
                            estimate_args[5],
                            estimate_args[6],
                            estimate_args[7]
                        
                        )
                    else:
                        raise KeyError("The metadata is invalid")
                        
                    self._runtime_service._end_tracking(tracker,data={},labels=['SUCCESS'])
                    return res
                else:
                    error = RuntimeError("This task's data couldn't be used to run on real device, because the circuits "
                                    "failed to transpile with the fake backend.")
                    raise error
            else:
                error = RuntimeError("This task's data couldn't be used to run on real device, because the task was "
                                "generated without fake backend.")
                raise error
        except Exception as e:
            self._runtime_service._end_tracking(tracker,data={'error':str(e),'task_state':self.get_task_state()},labels=['ERROR'])
            raise e

    def channel(self):
        """
        For getting the backend access channel where the computation task resides

        Returns
        -------
        str
            The backend access channel where the computation task resides
        """
        return self._data['channel']

    def get_task_state(self) -> Dict:
        """
        Get serializable state of quantum computing task.
        
        Returns a dictionary containing serializable members of QTaskManager instance,
        used for checkpoint saving and recovery.
        
        Returns
        -------
        dict
            Dictionary containing the following serializable members:
            - qtask_manager_init_time: QTaskManager initialization time (timestamp)
            - session_id: Session ID
            - data: Task metadata
            - used_remote_backend: Whether remote backend is used
            - used_program_set: Whether ProgramSet is used
            - sub_task_id__result_id: Mapping from sub-task ID to result ID
            - result: Task execution result
            - is_transpile_successed: Whether transpilation succeeded
            - processing_sub_task_ids: List of sub-task IDs being processed
            - used_fake_backend: Whether FakeBackend is used
        """
        return {
            'qtask_manager_init_time':self._qtask_manager_init_time,
            'session_id': self._session_id,
            'data': self._data,
            'used_remote_backend': self._used_remote_backend,
            'used_program_set': self._used_program_set,
            'sub_task_id__result_id': self._sub_task_id__result_id,
            'result': self._result,
            'is_transpile_successed': self._is_transpile_successed,
            'processing_sub_task_ids': self._processing_sub_task_ids,
            'used_fake_backend': self._used_fake_backend,
        }

    def check_point(self, filepath: Optional[str] = None, user_data: Optional[Dict] = None) -> str:
        """
        Save checkpoint data for quantum computing task.
        
        Saves the current task state to a checkpoint file using the
        CheckPoint.save method, enabling task state recovery later.
        
        Parameters
        ----------
        filepath : str, optional
            Checkpoint file save path. If None, system generates a default
            filename and writes to current working directory.
        user_data : Dict, optional
            User-defined data dictionary with JSON-serializable values.
        
        Returns
        -------
        str
            Absolute path to the written checkpoint file.
        
        Raises
        ------
        TypeError
            If task_state is not a dict and lacks get_task_state() method.
        Exception
            Original exception from get_task_state() is propagated.
        
        Notes
        -----
        - System does not manage checkpoint identifiers or guarantee
          filename uniqueness
        - Default filename format: checkpoint_YYYYMMDD_HHMMSS.json
        - Default filename does not guarantee global uniqueness
        - When filepath exists, it is overwritten by default
        - Not thread-safe/process-safe for concurrent writes
        - File deletion is user's responsibility
        
        Warnings
        --------
        - Concurrent writes to same file may cause data corruption
        - User must handle filename uniqueness in concurrent scenarios
        - user_data must be JSON-serializable
        
        Examples
        --------
        >>> # Save checkpoint with default filename
        >>> checkpoint_path = task_manager.check_point()
        >>> print(f"Checkpoint saved to: {checkpoint_path}")
        >>> 
        >>> # Save checkpoint with custom filename and user data
        >>> user_data = {'experiment_id': 'exp_123', 'note': 'VQE iteration 50'}
        >>> checkpoint_path = task_manager.check_point(
        ...     filepath='vqe_iteration_50.json',
        ...     user_data=user_data
        ... )
        """
        checkpoint = CheckPoint()
        return checkpoint.save(filepath=filepath, task_state=self, user_data=user_data)

    @staticmethod
    def from_task_state(runtime_service, task_state, recover_completely=True):
        """
        Create QTaskManager object from task state and RuntimeService instance.
        
        Parameters
        ----------
        runtime_service: RuntimeService
            RuntimeService instance used for executing quantum computing tasks.
        task_state: dict
            Task state dictionary returned by get_task_state method.
        recover_completely: bool, optional
            Whether to completely recover task state. Default is True.
            - True: Completely recover original task state, task_state must contain all information
            - False: Create a new task using state data, allow default values
        
        Returns
        -------
        QTaskManager
            QTaskManager instance created from task state.
        
        Raises
        ------
        ValueError
            If recover_completely is True and task_state is missing required fields.
        """
        if recover_completely:

            required_fields = [
                'qtask_manager_init_time', 'session_id', 'data', 'used_remote_backend',
                'used_program_set', 'sub_task_id__result_id', 'result',
                'is_transpile_successed', 'processing_sub_task_ids', 'used_fake_backend',
            ]
            
            missing_fields = [field for field in required_fields if field not in task_state]
            if missing_fields:
                raise ValueError(f"Missing required fields in task_state for complete recovery: {missing_fields}")
            
            task_data = task_state['data']
            used_remote_backend = task_state['used_remote_backend']
            used_fake_backend = task_state['used_fake_backend']
            used_program_set = task_state['used_program_set']
        else:

            task_data = task_state.get('data', {})
            used_remote_backend = task_state.get('used_remote_backend', True)
            used_fake_backend = task_state.get('used_fake_backend', False)
            used_program_set = task_state.get('used_program_set', False)
            required_fields2 = [
                'task_id', 'client_task_id','qtask_define_time','channel','task_type'
            ]

            missing_fields2 = [field for field in required_fields2 if field not in task_data]
            if missing_fields2:
                raise ValueError(f"Missing required fields in qtask meta data for complete recovery: {missing_fields2}")
        

        qtask_manager = QTaskManager(
            runtime_service=runtime_service,
            task_data=task_data,
            used_remote_backend=used_remote_backend,
            used_fake_backend=used_fake_backend,
            used_program_set=used_program_set
        )
        
        if recover_completely:

            qtask_manager._qtask_manager_init_time = task_state['qtask_manager_init_time']
            qtask_manager._id = task_state['data']['task_id']
            qtask_manager._session_id = task_state['session_id']
            qtask_manager._sub_task_id__result_id = task_state['sub_task_id__result_id']
            qtask_manager._result = task_state['result']
            qtask_manager._is_transpile_successed = task_state['is_transpile_successed']
            qtask_manager._processing_sub_task_ids = task_state['processing_sub_task_ids']
            qtask_manager._client_task_id = task_state['data'].get('client_task_id',-1)
        else:
            pass
        
        return qtask_manager
