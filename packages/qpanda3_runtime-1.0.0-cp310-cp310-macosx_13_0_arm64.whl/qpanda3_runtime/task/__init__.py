"""
Task management module for QPanda3 Runtime.

This module provides comprehensive quantum task management capabilities,
including task execution, session handling, and program set management
for variational quantum algorithms.

Submodules
----------
session : Session management
    Quantum session interfaces for variational algorithms.
program_set : Program set management
    Circuit parameter binding and observable management.
utils : Utility functions
    Task-related helper functions.

Exported Classes
----------------
QTaskManager : class
    Manager for quantum task execution and monitoring.
VQSession : class
    Variational quantum algorithm session.
FakeVQSession : class
    Simulated session for testing.
AnsatzParamsBinding : class
    Parameter binding for quantum ansatz circuits.
CircuitObservableBinding : class
    Observable binding for quantum circuits.
AnsatzObservableBinding : class
    Observable binding for ansatz circuits.

Examples
--------
>>> from qpanda3_runtime.task import QTaskManager, VQSession
>>> # Create a task manager
>>> task_manager = QTaskManager(runtime_service)
>>> task = task_manager.submit(circuit, device='quantum_backend')

>>> # Create a variational quantum session
>>> session = VQSession(ansatz_circuit, observable, initial_params)
>>> result = session.optimize(method='COBYLA', max_iter=100)

See Also
--------
qpanda3_runtime.runtime_service : Main service client.
qpanda3_runtime.device : Quantum device interfaces.

Notes
-----
- Task execution may be queued depending on backend availability.
- Variational sessions support multiple optimization algorithms.
- Program sets enable parameterized circuit execution.
- All task operations are thread-safe and support asynchronous execution.
"""

from ..version import __version__