"""
Program set binding module for quantum computing tasks.

This module provides classes for binding quantum circuits, ansatzs, gate parameters,
and observables with flexible binding rules (zip and product).

Classes
-------
AnsatzParamsBinding
    Binding manager for ansatz circuits and gate parameters.
CircuitObservableBinding
    Binding manager for quantum circuits and observables.
AnsatzObservableBinding
    Binding manager for ansatz-parameter combinations and observables.

Examples
--------
>>> from pyqpanda3.vqcircuit import VQCircuit
>>> from pyqpanda3.hamiltonian import Hamiltonian
>>> from qpanda3_runtime.task.program_set import (
...     AnsatzParamsBinding,
...     CircuitObservableBinding,
...     AnsatzObservableBinding
... )

>>> # Create ansatz-parameter binding
>>> ansatzs = [vqcircuit1, vqcircuit2]
>>> params = [[0.1, 0.2], [0.3, 0.4]]
>>> ansatz_binder = AnsatzParamsBinding(ansatzs, params)
>>> ansatz_binder.zip([0, 1], [0, 1])

>>> # Create circuit-observable binding
>>> circuits = [qprog1, qprog2]
>>> observables = [hamiltonian1, hamiltonian2]
>>> circuit_binder = CircuitObservableBinding(circuits, observables)
>>> circuit_binder.product([0], [0, 1])

>>> # Create ansatz-observable binding
>>> ansatz_obs_binder = AnsatzObservableBinding(ansatz_binder, observables)
>>> ansatz_obs_binder.zip([0, 1], [0, 1])
"""

from .gate_params_bind_rule import AnsatzParamsBinding
from .observable_bind_rule import CircuitObservableBinding, AnsatzObservableBinding

__all__ = [
    'AnsatzParamsBinding',
    'CircuitObservableBinding',
    'AnsatzObservableBinding'
]