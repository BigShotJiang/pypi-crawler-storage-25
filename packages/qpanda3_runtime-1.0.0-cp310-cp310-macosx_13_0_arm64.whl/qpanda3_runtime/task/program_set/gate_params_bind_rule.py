import base64
import itertools
import logging
from typing import List, Tuple
from itertools import product
import numpy as np

from pyqpanda3.vqcircuit import VQCircuit
from pyqpanda3.vqcircuit import VQCResult
from pyqpanda3.utils.utils import convert_vqcircuit_to_originbis, convert_originbis_to_vqcircuit
from pyqpanda3.core import *

from ...utils.convert_json_ndarray import ndarray_to_binary_json, binary_json_to_ndarray
from ...utils.convert_json_bytes import bytes_to_json_safe, json_safe_to_bytes



class AnsatzParamsBinding:
    """
    Binding manager for ansatz circuits and gate parameters.
    
    This class provides flexible binding rules (zip and product) to combine
    variational quantum circuits (ansatzs) with their corresponding gate parameters.
    
    Parameters
    ----------
    ansatzs : List[VQCircuit]
        List of variational quantum circuits (ansatzs).
    gate_params_s : List
        List of gate parameter sets corresponding to the ansatzs.
    
    Attributes
    ----------
    _ansatzs : List[VQCircuit]
        Internal storage for ansatz circuits.
    _gate_params_s : List
        Internal storage for gate parameter sets.
    _bind_rules : List[Tuple[List[int], List[int], int]]
        Binding rules where 0 represents zip rule and 1 represents product rule.
    _circuits : List
        Generated quantum circuits after applying binding rules.
    
    Examples
    --------
    >>> ansatzs = [vqcircuit1, vqcircuit2]
    >>> params = [[0.1, 0.2], [0.3, 0.4]]
    >>> binder = AnsatzParamsBinding(ansatzs, params)
    >>> binder.zip([0, 1], [0, 1])  # One-to-one binding
    >>> binder.product([0], [0, 1])  # Cartesian product binding
    """
    def __init__(self, ansatzs: [VQCircuit], gate_params_s: List):
        self._ansatzs = ansatzs
        self._gate_params_s = gate_params_s
        self._bind_rules: List[Tuple[List[int], List[int], int]] = []
        self._circuits = []

    def zip(self, ansatz_idx_s, gate_params_idx_s):
        """
        Add a zip binding rule (one-to-one correspondence).
        
        This method creates a binding rule where ansatzs and gate parameters
        are paired in one-to-one correspondence, similar to Python's zip function.
        
        Parameters
        ----------
        ansatz_idx_s : List[int]
            Indices of ansatzs to bind.
        gate_params_idx_s : List[int]
            Indices of gate parameter sets to bind.
            
        Raises
        ------
        RuntimeError
            If any index exceeds the bounds of the corresponding list.
            
        Notes
        -----
        The two lists must have the same length for proper one-to-one binding.
        """
        if max(ansatz_idx_s) >= len(self._ansatzs):
            raise RuntimeError('idx in ansatz_idx_s should smaller than the len of ansatzs')
        if max(gate_params_idx_s) >= len(self._gate_params_s):
            raise RuntimeError('idx in gate_params_idx_s should smaller than the len of gate_params_s')
        self._bind_rules.append((ansatz_idx_s, gate_params_idx_s, 0))

    def product(self, ansatz_idx_s, gate_params_idx_s):
        """
        Add a product binding rule (Cartesian product).
        
        This method creates a binding rule where all combinations of specified
        ansatzs and gate parameters are generated, similar to Python's itertools.product.
        
        Parameters
        ----------
        ansatz_idx_s : List[int]
            Indices of ansatzs to bind.
        gate_params_idx_s : List[int]
            Indices of gate parameter sets to bind.
            
        Notes
        -----
        This generates all possible combinations between the specified ansatzs
        and gate parameters, unlike zip which creates one-to-one pairs.
        """
        self._bind_rules.append((ansatz_idx_s, gate_params_idx_s, 1))

    def ansatzs(self, serialized=True, encode_type: str = 'b64_ascii'):
        """
        Get the ansatz circuits.
        
        Parameters
        ----------
        serialized : bool, optional
            If True, return serialized representation of ansatzs.
            If False, return the original VQCircuit objects.
        encode_type : str, optional
            Encoding type for serialization. Currently only 'b64_ascii' is supported.
            
        Returns
        -------
        List
            If serialized is True: List of serialized ansatz strings.
            If serialized is False: List of VQCircuit objects.
            
        Notes
        -----
        Serialization converts VQCircuit objects to base64-encoded strings for
        transmission or storage purposes.
        """
        if not serialized:
            return self._ansatzs
        res = []
        for ansatz in self._ansatzs:
            tmp = convert_vqcircuit_to_originbis(ansatz)
            if encode_type == 'b64_ascii':
                tmp = base64.b64encode(tmp).decode('ascii')
            res.append(tmp)
        return res

    def rules(self):
        """
        Get all binding rules.
        
        Returns
        -------
        List[Tuple[List[int], List[int], int]]
            List of binding rules where each rule is a tuple containing:
            - List[int]: Ansatz indices
            - List[int]: Gate parameter indices
            - int: Binding type (0 for zip, 1 for product)
        """
        return self._bind_rules

    def gate_params(self, flatten):
        """
        Get gate parameters.
        
        Parameters
        ----------
        flatten : bool
            If True, flatten the gate parameters and return both flattened lists
            and their dimensions. If False, return the original parameter structure.
            
        Returns
        -------
        Union[List, Tuple[List, List]]
            If flatten is False: Original gate parameter structure.
            If flatten is True: Tuple containing:
                - List[List[float]]: Flattened parameter lists
                - List[int]: Dimensions of each parameter list
                
        Notes
        -----
        Flattening is useful for serialization or when parameters need to be
        transmitted as flat arrays.
        """
        if not flatten:
            return self._gate_params_s
        param_list_s = []
        param_list_dim_s = []
        for gate_params in self._gate_params_s:
            data_list = np.array(gate_params).ravel().astype(float).tolist()
            param_list_s.append(data_list)
            param_list_dim_s.append(len(data_list))
        return param_list_s, param_list_dim_s

    def _append_circuit_by_zip(self, ansatz_idx_s, gate_params_idx_s):
        if len(ansatz_idx_s) != len(gate_params_idx_s):
            raise Exception('len of ansatz_idx_s and gate_params_idx_s should be same.')
        for i in range(len(ansatz_idx_s)):
            res: VQCResult = self._ansatzs[ansatz_idx_s[i]](self._gate_params_s[gate_params_idx_s[i]])
            self._circuits.extend(res.circuits())

    def _append_circuit_by_product(self, ansatz_idx_s, gate_params_idx_s):
        for ansatz_id in ansatz_idx_s:
            for gate_params_idx in gate_params_idx_s:
                res: VQCResult = self._ansatzs[ansatz_id](self._gate_params_s[gate_params_idx])
                self._circuits.extend(res.circuits())

    def circuits(self):
        """
        Generate quantum circuits by applying all binding rules.
        
        Returns
        -------
        List
            List of generated quantum circuits.
            
        Notes
        -----
        This method applies all registered binding rules to generate the final
        quantum circuits. The circuits are cached internally after generation.
        """
        for ansatz_idx_s, gate_params_idx_s, bind_mode in self._bind_rules:
            if bind_mode == 'zip':
                self._append_circuit_by_zip(ansatz_idx_s, gate_params_idx_s)
            else:
                self._append_circuit_by_product(ansatz_idx_s, gate_params_idx_s)
        return self._circuits

    def data(self):
        """
        Get internal data representation.
        
        Returns
        -------
        Dict
            Dictionary containing:
            - 'gate_params_s': Gate parameters
            - 'bind_rules': Binding rules
            - 'ansatzs': Ansatz circuits
        """
        return {'gate_params_s': self._gate_params_s, 'bind_rules': self._bind_rules, 'ansatzs': self._ansatzs}

    def __str__(self):
        return str(self.data())

    def to_json_dict(self):
        """
        Convert to JSON-serializable dictionary.
        
        Returns
        -------
        Dict
            JSON-serializable dictionary containing:
            - 'gate_params_s': Binary JSON representation of gate parameters
            - 'bind_rules': Binding rules
            - 'ansatzs': JSON-safe byte representation of ansatz circuits
            
        Notes
        -----
        This method prepares the data for JSON serialization by converting
        binary data to JSON-safe formats.
        """
        res = {'gate_params_s': [], 'bind_rules': self._bind_rules, 'ansatzs': []}
        for ansatz in self._ansatzs:
            res['ansatzs'].append(bytes_to_json_safe(convert_vqcircuit_to_originbis(ansatz)))
        for params in self._gate_params_s:
            res['gate_params_s'].append(ndarray_to_binary_json(params))
        return res

    @staticmethod
    def from_json_dict(json_data):
        """
        Create AnsatzParamsBinding instance from JSON dictionary.
        
        Parameters
        ----------
        json_data : Dict
            JSON dictionary containing:
            - 'bind_rules': Binding rules
            - 'ansatzs': JSON-safe byte representation of ansatz circuits
            - 'gate_params_s': Binary JSON representation of gate parameters
            
        Returns
        -------
        AnsatzParamsBinding
            Reconstructed AnsatzParamsBinding instance.
            
        Notes
        -----
        This is the inverse operation of to_json_dict().
        """
        res = AnsatzParamsBinding([], [])
        res._bind_rules = json_data['bind_rules']
        for ansatz in json_data['ansatzs']:
            res._ansatzs.append(convert_originbis_to_vqcircuit(json_safe_to_bytes(ansatz)))
        for params in json_data['gate_params_s']:
            res._gate_params_s.append(binary_json_to_ndarray(params))
        return res

    def get_prog_groups_with_measure(self, max_circuit_num_per_group, measure_qubits: list,
                                     return_originir: bool = True):
        """
        Get quantum programs grouped with measurement operations.
        
        Parameters
        ----------
        max_circuit_num_per_group : int
            Maximum number of circuits per group.
        measure_qubits : List[int]
            List of qubit indices to measure.
        return_originir : bool, optional
            If True, return programs as OriginIR strings.
            If False, return QProg objects.
            
        Returns
        -------
        List[Dict]
            List of program groups where each group contains:
            - 'ansatz_id__gate_params_id_s': List of (ansatz_id, gate_params_id) pairs
            - 'progs': List of quantum programs with measurement operations
            
        Notes
        -----
        This method adds measurement operations to all specified qubits
        and groups the resulting programs for batch processing.
        """
        groups = self.get_ansatz_params_group(max_circuit_num_per_group)
        logging.info(f'groups:{groups}')
        res = []
        for group in groups:
            prog_groups = {'ansatz_id__gate_params_id_s': [], 'progs': []}
            for ansatz_id, gate_params_id in group:
                prog_groups['ansatz_id__gate_params_id_s'].append((ansatz_id, gate_params_id))
                cirs = self._ansatzs[ansatz_id](self._gate_params_s[gate_params_id]).circuits()
                for cir in cirs:
                    prog = QProg(cir)
                    for qbit in measure_qubits:
                        prog << measure(qbit, qbit)
                    if return_originir:
                        prog_groups['progs'].append(prog.originir(precision=15))
                    else:
                        prog_groups['progs'].append(prog)
            res.append(prog_groups)
        return res

    def get_progs(self, return_originir: bool = True):
        """
        Get all quantum programs generated by binding rules.
        
        Parameters
        ----------
        return_originir : bool, optional
            If True, return programs as OriginIR strings.
            If False, return QProg objects.
            
        Returns
        -------
        List[Dict]
            List of dictionaries where each contains:
            - 'ansatz_id__gate_params_id': Tuple of (ansatz_id, gate_params_id)
            - 'progs': List of quantum programs
            
        Notes
        -----
        This method applies all binding rules to generate the complete set
        of quantum programs with their corresponding ansatz-parameter mappings.
        """
        res = []
        for ansatz_ids, params_ids, rule_type in self._bind_rules:
            pairs = []
            if rule_type == 'zip':
                pairs = zip(ansatz_ids, params_ids)
            elif rule_type == 'product':
                pairs = itertools.product(ansatz_ids, params_ids)
            for ansatz_id, params_id in pairs:
                cirs = self._ansatzs[ansatz_id](self._gate_params_s[params_id]).circuits()
                if return_originir:
                    tmp = {'ansatz_id__gate_params_id': (ansatz_id, params_id),
                           'progs': [QProg(cir).originir(precision=15) for cir in cirs]
                           }
                else:
                    tmp = {'ansatz_id__gate_params_id': (ansatz_id, params_id),
                           'progs': [QProg(cir) for cir in cirs]
                           }
                res.append(tmp)
        return res

    @staticmethod
    def _get_ansatz_params_pair_by_zip(ansatz_idx_s, gate_params_idx_s):
        if len(ansatz_idx_s) != len(gate_params_idx_s):
            raise Exception('len of ansatz_idx_s and gate_params_idx_s should be same.')
        return list(zip(ansatz_idx_s, gate_params_idx_s))

    @staticmethod
    def _get_ansatz_params_pair_by_product(ansatz_idx_s, gate_params_idx_s):
        return list(product(ansatz_idx_s, gate_params_idx_s))

    def get_all_ansatz_params_pair(self):
        """
        Get all ansatz-parameter pairs according to binding rules.
        
        Returns
        -------
        List[Tuple[int, int]]
            List of (ansatz_index, parameter_index) pairs generated by
            applying all registered binding rules.
            
        Raises
        ------
        RuntimeError
            If an unknown binding type is encountered.
        """
        res = []
        for ansatz_idx_s, gate_params_idx_s, bind_type in self._bind_rules:
            if bind_type == 'zip':
                res.extend(AnsatzParamsBinding._get_ansatz_params_pair_by_zip(ansatz_idx_s, gate_params_idx_s))
            elif bind_type == 'product':
                res.extend(AnsatzParamsBinding._get_ansatz_params_pair_by_product(ansatz_idx_s, gate_params_idx_s))
            else:
                logging.error('bind_type error')
        return res

    def get_ansatz_params_group(self, max_circuit_num_per_group):
        """
        Group ansatz-parameter pairs for batch processing.
        
        Parameters
        ----------
        max_circuit_num_per_group : int
            Maximum number of pairs per group.
            
        Returns
        -------
        List[List[Tuple[int, int]]]
            List of groups where each group contains up to
            max_circuit_num_per_group ansatz-parameter pairs.
            
        Notes
        -----
        This method is useful for dividing large sets of quantum circuits
        into manageable batches for parallel or sequential execution.
        """
        groups = []
        all_pairs = self.get_all_ansatz_params_pair()
        total = len(all_pairs)

        num = int(total / max_circuit_num_per_group)
        for i in range(num):
            group = []
            for j in range(max_circuit_num_per_group):
                group.append(all_pairs[i * max_circuit_num_per_group + j])
            groups.append(group)
        if num * max_circuit_num_per_group != total:
            groups.append(all_pairs[num * max_circuit_num_per_group:])
        return groups


