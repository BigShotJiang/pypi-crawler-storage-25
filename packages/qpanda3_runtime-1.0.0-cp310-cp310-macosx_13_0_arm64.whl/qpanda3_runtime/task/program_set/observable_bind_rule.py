import itertools
import logging
from turtle import circle
from typing import Union, List, Tuple, Optional,Dict

from pyqpanda3.core import QProg, I
from pyqpanda3.hamiltonian import Hamiltonian

from .gate_params_bind_rule import AnsatzParamsBinding
from ...utils.union_type import QProgUnionType, ObservableUnionType, get_observable, get_qprog


class CircuitObservableBinding:
    """
    Binding manager for quantum circuits and observables.
    
    This class provides flexible binding rules (zip and product) to combine
    quantum circuits with their corresponding observables in quantum
    multi-objective decision-making scenarios.
    
    Parameters
    ----------
    circuits : Optional[List[QProgUnionType]]
        List of exploratory quantum circuits.
    observables : Optional[List[ObservableUnionType]]
        List of target observables.
        
    Attributes
    ----------
    _circuits : List[QProg]
        Internal storage for quantum circuits.
    _observables : List[Hamiltonian]
        Internal storage for observables.
    _bind_rules : List[Tuple[List[int], List[int], int]]
        Binding rules where 0 represents zip rule and 1 represents product rule.
    _max_qubit_idx : int
        Maximum qubit index across all circuits and observables.
        
    Raises
    ------
    RuntimeError
        If circuits and observables are not provided together.
        If circuits and observables don't share the same maximum qubit index.
        
    Examples
    --------
    >>> circuits = [qprog1, qprog2]
    >>> observables = [hamiltonian1, hamiltonian2]
    >>> binder = CircuitObservableBinding(circuits, observables)
    >>> binder.zip([0, 1], [0, 1])  # One-to-one binding
    >>> binder.product([0], [0, 1])  # Cartesian product binding
    """
    def __init__(self, circuits: Optional[List[QProgUnionType]] = None,
                 observables: Optional[List[ObservableUnionType]] = None):
        if circuits is None:
            circuits = []
        if observables is None:
            observables = []
        self._circuits: List[QProg] = []
        self._observables: List[Hamiltonian] = []
        self._bind_rules: List[Tuple[List[int], List[int], int]] = []
        self._max_qubit_idx = 0
        if (len(circuits) != 0 and len(observables) == 0) or (len(circuits) == 0 and len(observables) != 0):
            raise RuntimeError('The two parameters (circuits and observables) must be provided together or omitted '
                               'together')

        for cir in circuits:
            self._circuits.append(get_qprog(cir, res_type='object'))
        for ham in observables:
            self._observables.append(get_observable(ham, res_type='paulioperator'))

        def check_qubit_idx():
            self._max_qubit_idx = self._observables[0].max_qbit_idx()
            for i in range(1, len(observables)):
                if self._observables[i].max_qbit_idx() != self._max_qubit_idx:
                    raise RuntimeError(
                        "All circuits(with or without measure nodes) and observables must share the same maximum "
                        "qubit index.")
            for prog in self._circuits:
                if max(prog.qubits()) != self._max_qubit_idx:
                    raise RuntimeError(
                        "All circuits(with or without measure nodes) and observables must share the same maximum "
                        "qubit index.")

        check_qubit_idx()

        def update_measure_nodes_by_igate():
            progs = []
            for prog in self._circuits:
                nodes = prog.get_measure_nodes()
                if len(nodes) == 0:
                    progs.append(prog)
                    continue
                else:
                    tmp_prog = QProg(prog.to_circuit())
                    tmp_prog << I(self.max_qubit_idx())
                    progs.append(tmp_prog)
            self._circuits = progs

        update_measure_nodes_by_igate()

    def max_qubit_idx(self):
        """
        Get the maximum qubit index across all circuits and observables.
        
        Returns
        -------
        int
            Maximum qubit index value.
            
        Notes
        -----
        This value is validated during initialization to ensure all circuits
        and observables operate on the same qubit register.
        """
        return self._max_qubit_idx
        return self._max_qubit_idx

    @staticmethod
    def from_tuple(circuit_with_observable: Tuple[
        Union[QProgUnionType, List[QProgUnionType]],
        ObservableUnionType]
                   ):
        """
        Create CircuitObservableBinding from a tuple.
        
        Parameters
        ----------
        circuit_with_observable : Tuple[Union[QProgUnionType, List[QProgUnionType]], ObservableUnionType]
            Tuple containing:
            - First element: Single quantum circuit or list of quantum circuits
            - Second element: Single observable
            
        Returns
        -------
        CircuitObservableBinding
            Binding object with product rule applied between circuits and observable.
            
        Notes
        -----
        This convenience method automatically applies a product binding rule
        between all provided circuits and the single observable.
        """

        if isinstance(circuit_with_observable[0],list):
            res = CircuitObservableBinding(circuit_with_observable[0], [circuit_with_observable[1]])
        else:
            res = CircuitObservableBinding([circuit_with_observable[0]], [circuit_with_observable[1]])
        res.product(list(range(len(res._circuits))), [0])
        return res

    def zip(self, circuit_idx_s, observable_idx_s):
        """
        Add a zip binding rule (one-to-one correspondence).
        
        This method creates a binding rule where circuits and observables
        are paired in one-to-one correspondence, similar to Python's zip function.
        
        Parameters
        ----------
        circuit_idx_s : List[int]
            Indices of circuits to bind.
        observable_idx_s : List[int]
            Indices of observables to bind.
            
        Raises
        ------
        RuntimeError
            If any index exceeds the bounds of the corresponding list.
            
        Notes
        -----
        The two lists must have the same length for proper one-to-one binding.
        """
        if max(circuit_idx_s) >= len(self._circuits):
            raise RuntimeError('idx in circuit_idx_s should smaller than the len of circuits')
        if max(observable_idx_s) >= len(self._observables):
            raise RuntimeError('idx in observable_idx_s should smaller than the len of observables')
        self._bind_rules.append((circuit_idx_s, observable_idx_s, 0))

    def product(self, circuit_idx_s, observable_idx_s):
        """
        Add a product binding rule (Cartesian product).
        
        This method creates a binding rule where all combinations of specified
        circuits and observables are generated, similar to Python's itertools.product.
        
        Parameters
        ----------
        circuit_idx_s : List[int]
            Indices of circuits to bind.
        observable_idx_s : List[int]
            Indices of observables to bind.
            
        Notes
        -----
        This generates all possible combinations between the specified circuits
        and observables, unlike zip which creates one-to-one pairs.
        """
        self._bind_rules.append((circuit_idx_s, observable_idx_s, 1))

    def observables(self, serialized=True):
        """
        Get the observables.
        
        Parameters
        ----------
        serialized : bool, optional
            If True, return serialized representation of observables.
            If False, return the original Hamiltonian objects.
            
        Returns
        -------
        Union[List[Hamiltonian], List[str]]
            If serialized is True: List of serialized observable strings.
            If serialized is False: List of Hamiltonian objects.
            
        Notes
        -----
        Serialization converts Hamiltonian objects to string representations
        for transmission or storage purposes.
        """
        if not serialized:
            return self._observables
        res = []
        for ham in self._observables:
            res.append(ham.data_dict_str(is_coeff_complex=False, double_quote=True))
        return res

    def circuits(self, serialized=True):
        """
        Get the quantum circuits.
        
        Parameters
        ----------
        serialized : bool, optional
            If True, return serialized representation of circuits.
            If False, return the original QProg objects.
            
        Returns
        -------
        Union[List[QProg], List[str]]
            If serialized is True: List of OriginIR strings.
            If serialized is False: List of QProg objects.
            
        Notes
        -----
        Serialization converts QProg objects to OriginIR strings for
        transmission or storage purposes.
        """
        if serialized is False:
            return self._circuits
        return [prog.originir(precision=15) for prog in self._circuits]
        if serialized is False:
            return self._circuits
        return [prog.originir(precision=15) for prog in self._circuits]

    def data(self):
        """
        Get internal data representation.
        
        Returns
        -------
        Dict
            Dictionary containing:
            - 'observables': Observable objects
            - 'bind_rules': Binding rules
            - 'circuits': Quantum circuit objects
        """
        return {'observables': self._observables, 'bind_rules': self._bind_rules, 'circuits': self._circuits}
        return {'observables': self._observables, 'bind_rules': self._bind_rules, 'circuits': self._circuits}

    def __str__(self):
        return str(self.data())

    def rules(self):
        """
        Get all binding rules.
        
        Returns
        -------
        List[Tuple[List[int], List[int], int]]
            List of binding rules where each rule is a tuple containing:
            - List[int]: Circuit indices
            - List[int]: Observable indices
            - int: Binding type (0 for zip, 1 for product)
        """
        return self._bind_rules
        return self._bind_rules

    def get_all_circuit_observable_id_pairs(self):
        """
        Get all circuit-observable pairs according to binding rules.
        
        Returns
        -------
        List[Tuple[int, int]]
            List of (circuit_index, observable_index) pairs generated by
            applying all registered binding rules.
            
        Notes
        -----
        This method applies both zip and product rules to generate the complete
        set of circuit-observable combinations.
        """
        res = []
        for cir_ids, observable_ids, rule_type in self._bind_rules:
            if rule_type == 0 or rule_type == '0' or rule_type == 'zip':
                res.extend(zip(cir_ids, observable_ids))
            elif rule_type == 1 or rule_type == '1' or rule_type == 'product':
                res.extend(list(itertools.product(cir_ids, observable_ids)))
        return res
        res = []
        for cir_ids, observable_ids, rule_type in self._bind_rules:
            if rule_type == 0 or rule_type == '0' or rule_type == 'zip':
                res.extend(zip(cir_ids, observable_ids))
            elif rule_type == 1 or rule_type == '1' or rule_type == 'product':
                res.extend(list(itertools.product(cir_ids, observable_ids)))
        return res

    def to_json_dict(self)->Dict:
        """
        Convert to JSON-serializable dictionary.
        
        Returns
        -------
        Dict
            JSON-serializable dictionary containing:
            - 'type': 'CircuitObservableBinding'
            - 'circuits': OriginIR strings of quantum circuits
            - 'observables': String representations of observables
            - 'bind_rules': Binding rules
            - 'max_qubit_idx': Maximum qubit index
            
        Notes
        -----
        This method prepares the data for JSON serialization by converting
        quantum objects to string representations.
        """
        data = {'type':'CircuitObservableBinding'}
        data['circuits']=[get_qprog(cir,res_type='originir') for cir in self._circuits]
        data['observables'] = [get_observable(ham,res_type='str') for ham in self._observables]
        data['bind_rules'] = self._bind_rules
        data['max_qubit_idx'] = self._max_qubit_idx
        return data

    @staticmethod
    def from_json_dict(data:Dict):
        """
        Create CircuitObservableBinding instance from JSON dictionary.
        
        Parameters
        ----------
        data : Dict
            JSON dictionary containing:
            - 'circuits': OriginIR strings of quantum circuits
            - 'observables': String representations of observables
            - 'bind_rules': Binding rules
            - 'max_qubit_idx': Maximum qubit index
            
        Returns
        -------
        CircuitObservableBinding
            Reconstructed CircuitObservableBinding instance.
            
        Notes
        -----
        This is the inverse operation of to_json_dict().
        """
        obj = CircuitObservableBinding(data['circuits'],data['observables'])
        obj._bind_rules = data['bind_rules']
        obj._max_qubit_idx = data['max_qubit_idx']
        return obj


class AnsatzObservableBinding:
    """
    Binding manager for ansatz-parameter combinations and observables.
    
    This class provides flexible binding rules (zip and product) to combine
    ansatz-parameter combinations (from AnsatzParamsBinding) with observables.
    
    Parameters
    ----------
    ansatz_with_params : AnsatzParamsBinding
        Binding object containing ansatz circuits and their parameters.
    observables : List[ObservableUnionType]
        List of target observables.
        
    Attributes
    ----------
    _ansatz_with_params : AnsatzParamsBinding
        Internal storage for ansatz-parameter bindings.
    _observables : List[Hamiltonian]
        Internal storage for observables.
    _bind_rules : List[Tuple[List[int], List[int], int]]
        Binding rules where 0 represents zip rule and 1 represents product rule.
    _max_qubit_idx : int
        Maximum qubit index across all ansatzs and observables.
        
    Examples
    --------
    >>> ansatz_binder = AnsatzParamsBinding(ansatzs, params)
    >>> observables = [hamiltonian1, hamiltonian2]
    >>> binder = AnsatzObservableBinding(ansatz_binder, observables)
    >>> binder.zip([0, 1], [0, 1])  # One-to-one binding
    >>> binder.product([0], [0, 1])  # Cartesian product binding
    """
    def __init__(self, ansatz_with_params: AnsatzParamsBinding, observables: List[ObservableUnionType]):
        self._ansatz_with_params = ansatz_with_params
        self._observables = observables
        self._bind_rules: List[Tuple[List[int], List[int], int]] = []
        self._max_qubit_idx = get_observable(observables[0],res_type='paulioperator').max_qbit_idx()

    def max_qubit_idx(self):
        """
        Get the maximum qubit index across all ansatzs and observables.
        
        Returns
        -------
        int
            Maximum qubit index value.
        """
        return self._max_qubit_idx

    def ansatzs(self, serialized=True, encode_type: str = 'b64_ascii'):
        """
        Get the ansatz circuits.
        
        Parameters
        ----------
        serialized : bool, optional
            If True, return serialized representation of ansatzs.
            If False, return the original VQCircuit objects.
        encode_type : str, optional
            Encoding type for serialization.
            
        Returns
        -------
        List
            Result from underlying AnsatzParamsBinding.ansatzs() method.
        """
        return self._ansatz_with_params.ansatzs(serialized=serialized, encode_type=encode_type)

    def gate_params(self, flatten):
        """
        Get the gate parameters.
        
        Parameters
        ----------
        flatten : bool
            If True, flatten the gate parameters.
            
        Returns
        -------
        Union[List, Tuple[List, List]]
            Result from underlying AnsatzParamsBinding.gate_params() method.
        """
        return self._ansatz_with_params.gate_params(flatten=flatten)

    def ansatz_params_bind_rules(self):
        """
        Get ansatz-parameter binding rules.
        
        Returns
        -------
        List[Tuple[List[int], List[int], int]]
            Binding rules from the underlying AnsatzParamsBinding object.
        """
        return self._ansatz_with_params.rules()

    def observables(self, serialized=True):
        """
        Get the observables.
        
        Parameters
        ----------
        serialized : bool, optional
            If True, return serialized representation of observables.
            If False, return the original Hamiltonian objects.
            
        Returns
        -------
        Union[List[Hamiltonian], List[str]]
            If serialized is True: List of serialized observable strings.
            If serialized is False: List of Hamiltonian objects.
        """
        if not serialized:
            return self._observables
        res = []
        for ham in self._observables:
            res.append(ham.pauli_operator().data_dict_str(is_coeff_complex=False, double_quote=True))
        return res

    def rules(self):
        """
        Get all binding rules.
        
        Returns
        -------
        List[Tuple[List[int], List[int], int]]
            List of binding rules where each rule is a tuple containing:
            - List[int]: Ansatz-parameter combination indices
            - List[int]: Observable indices
            - int: Binding type (0 for zip, 1 for product)
        """
        return self._bind_rules

    def zip(self, ansatz_with_param_idx_s, observable_idx_s):
        """
        Add a zip binding rule (one-to-one correspondence).
        
        Parameters
        ----------
        ansatz_with_param_idx_s : List[int]
            Indices of ansatz-parameter combinations to bind.
        observable_idx_s : List[int]
            Indices of observables to bind.
            
        Raises
        ------
        RuntimeError
            If any index exceeds the bounds of the corresponding list.
            
        Notes
        -----
        The two lists must have the same length for proper one-to-one binding.
        """
        if max(ansatz_with_param_idx_s) >= len(self._ansatz_with_params.ansatzs(serialized=False)):
            raise RuntimeError('idx in ansatz_with_param_idx_s should smaller than the len of ansatz_with_params')
        if max(observable_idx_s) >= len(self._observables):
            raise RuntimeError('idx in observable_idx_s should smaller than the len of observables')
        self._bind_rules.append((ansatz_with_param_idx_s, observable_idx_s, 0))

    def product(self, ansatz_with_param_idx_s, observable_idx_s):
        """
        Add a product binding rule (Cartesian product).
        
        Parameters
        ----------
        ansatz_with_param_idx_s : List[int]
            Indices of ansatz-parameter combinations to bind.
        observable_idx_s : List[int]
            Indices of observables to bind.
            
        Notes
        -----
        This generates all possible combinations between the specified
        ansatz-parameter combinations and observables.
        """
        self._bind_rules.append((ansatz_with_param_idx_s, observable_idx_s, 1))

    def data(self):
        """
        Get internal data representation.
        
        Returns
        -------
        Dict
            Dictionary containing:
            - 'observables': Observable objects
            - 'bind_rules': Binding rules
            - 'ansatz_with_params': AnsatzParamsBinding object
        """
        return {'observables': self._observables, 'bind_rules': self._bind_rules,
                'ansatz_with_params': self._ansatz_with_params}

    def __str__(self):
        return str(self.data())

    # def json(self):
    #     res = {'observables': self._observables, 'bind_rules': self._bind_rules,
    #            'ansatz_with_params': []}
    #     for v in self._ansatz_with_params:
    #         res['ansatz_with_params'].append(v.json())
    #     return json.dumps(res)

    # @staticmethod
    # def from_json(json_data):
    #     res = AnsatzObservableBinding([], [])
    #     json_dict = json.loads(json_data)
    #     res._bind_rules = json_dict['bind_rules']
    #     logging.debug(f'bind_rules:{res._bind_rules}')
    #     res._observables = json_dict['observables']
    #     res._ansatz_with_params = []
    #     for v in json_dict['ansatz_with_params']:
    #         logging.debug(f'ansatz_with_params v:{v}')
    #         res._ansatz_with_params.append(AnsatzParamsBinding.from_json(v))
    #     return res

    def get_all_ansatz_observable_id_pairs(self):
        """
        Get all ansatz-observable pairs according to binding rules.
        
        Returns
        -------
        List[Tuple[int, int]]
            List of (ansatz_index, observable_index) pairs generated by
            applying all registered binding rules.
        """
        res = []
        for ansatz_ids, observable_ids, rule_type in self._bind_rules:
            if rule_type == 0:
                res.extend(zip(ansatz_ids, observable_ids))
            elif rule_type == 1:
                res.extend(list(itertools.product(ansatz_ids, observable_ids)))
        logging.debug(f'res:{res}')
        return res

    def get_observables(self):
        """
        Get the observables.
        
        Returns
        -------
        List[Hamiltonian]
            List of Hamiltonian objects.
        """
        return self._observables

    def get_progs_grouped_by_ansatz_with_params(self, using_originir: bool = True):
        """
        Get quantum programs grouped by ansatz-parameter combinations.
        
        Parameters
        ----------
        using_originir : bool, optional
            If True, return programs as OriginIR strings.
            If False, return QProg objects.
            
        Returns
        -------
        List[Dict]
            Result from underlying AnsatzParamsBinding.get_progs() method.
        """
        return self._ansatz_with_params.get_progs(return_originir=using_originir)

    def to_json_dict(self)->Dict:
        """
        Convert to JSON-serializable dictionary.
        
        Returns
        -------
        Dict
            JSON-serializable dictionary containing:
            - 'type': 'AnsatzObservableBinding'
            - 'ansatz_with_params': JSON representation from AnsatzParamsBinding
            - 'observables': String representations of observables
            - 'bind_rules': Binding rules
            - 'max_qubit_idx': Maximum qubit index
            
        Notes
        -----
        This method prepares the data for JSON serialization by converting
        quantum objects to string representations.
        """
        data = {'type':'AnsatzObservableBinding'}      
        data['ansatz_with_params']=self._ansatz_with_params.to_json_dict()
        data['observables'] = [get_observable(ham,res_type='str') for ham in self._observables]
        data['bind_rules'] = self._bind_rules
        data['max_qubit_idx'] = self._max_qubit_idx
        return data

    @staticmethod
    def from_json_dict(data:Dict):
        """
        Create AnsatzObservableBinding instance from JSON dictionary.
        
        Parameters
        ----------
        data : Dict
            JSON dictionary containing:
            - 'ansatz_with_params': JSON representation from AnsatzParamsBinding
            - 'observables': String representations of observables
            - 'bind_rules': Binding rules
            - 'max_qubit_idx': Maximum qubit index
            
        Returns
        -------
        AnsatzObservableBinding
            Reconstructed AnsatzObservableBinding instance.
            
        Notes
        -----
        This is the inverse operation of to_json_dict().
        """
        obj = AnsatzObservableBinding(AnsatzParamsBinding.from_json_dict(data['ansatz_with_params'])
            , data['observables'])
        obj._bind_rules = data['bind_rules']
        obj._max_qubit_idx = data['max_qubit_idx']
        return obj
