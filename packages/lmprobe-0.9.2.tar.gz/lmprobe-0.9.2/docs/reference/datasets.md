# Datasets

Functions and classes for sharing activation datasets via HuggingFace.

See the [HuggingFace Datasets guide](../guides/datasets.md) for a walkthrough.

---

## Extraction

::: lmprobe.unified_cache.UnifiedCache
    options:
      show_root_heading: true
      show_source: false
      heading_level: 3
      members_order: source

::: lmprobe.unified_cache.WarmupStats
    options:
      show_root_heading: true
      show_source: false
      heading_level: 3

---

## Loading

::: lmprobe.sharing.load_activations
    options:
      show_root_heading: true
      show_source: false

---

## Publishing

::: lmprobe.sharing.push_dataset
    options:
      show_root_heading: true
      show_source: false

::: lmprobe.sharing.pull_dataset
    options:
      show_root_heading: true
      show_source: false

::: lmprobe.sharing.load_activation_dataset
    options:
      show_root_heading: true
      show_source: false

::: lmprobe.sharing.fetch_dataset_metadata
    options:
      show_root_heading: true
      show_source: false

::: lmprobe.sharing.migrate_dataset
    options:
      show_root_heading: true
      show_source: false

::: lmprobe.sharing.upgrade_dataset_format
    options:
      show_root_heading: true
      show_source: false

::: lmprobe.sharing.DatasetMetadata
    options:
      show_root_heading: true
      show_source: false
      heading_level: 3
