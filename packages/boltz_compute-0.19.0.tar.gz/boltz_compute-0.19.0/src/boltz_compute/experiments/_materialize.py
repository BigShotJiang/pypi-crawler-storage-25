from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from urllib.parse import urlparse

from ._errors import ExperimentError
from .._client import BoltzCompute
from ._progress import ProgressSink


def prediction_paths(run_dir: Path, archive_url: str) -> tuple[Path, Path]:
    suffix = archive_suffix_from_url(archive_url)
    return run_dir / "outputs" / f"archive{suffix}", run_dir / "outputs" / "files"


def pipeline_paths(run_dir: Path, result_id: str, archive_url: str) -> tuple[Path, Path]:
    suffix = archive_suffix_from_url(archive_url)
    return run_dir / "results" / result_id / f"archive{suffix}", run_dir / "results" / result_id / "files"


def archive_suffix_from_url(url: str) -> str:
    name = Path(urlparse(url).path).name
    suffixes = Path(name).suffixes
    if not suffixes:
        raise ExperimentError(f"Archive URL does not include a file suffix: {url}")
    return "".join(suffixes)


def is_materialized(archive_path: Path, extracted_dir: Path) -> bool:
    return archive_path.exists() and extracted_dir.is_dir()


def materialize_archive(
    *,
    client: BoltzCompute,
    archive_url: str,
    archive_path: Path,
    extracted_dir: Path,
    sink: ProgressSink,
) -> None:
    archive_path.parent.mkdir(parents=True, exist_ok=True)

    if not archive_path.exists():
        sink.info(f"Downloading archive to {archive_path}")
        _download_archive(client=client, url=archive_url, destination=archive_path)

    if extracted_dir.is_dir():
        return

    sink.info(f"Extracting archive to {extracted_dir}")
    _extract_archive(archive_path=archive_path, destination=extracted_dir)


def _download_archive(*, client: BoltzCompute, url: str, destination: Path) -> None:
    tmp_path = destination.with_name(f"{destination.name}.part")
    if tmp_path.exists():
        tmp_path.unlink()

    with client._client.stream("GET", url, follow_redirects=True) as response:
        response.raise_for_status()
        with tmp_path.open("wb") as file:
            for chunk in response.iter_bytes():
                file.write(chunk)

    tmp_path.replace(destination)


def _extract_archive(*, archive_path: Path, destination: Path) -> None:
    if destination.exists():
        shutil.rmtree(destination)

    base_dir = destination.parent
    base_dir.mkdir(parents=True, exist_ok=True)
    temp_dir_path = Path(
        tempfile.mkdtemp(prefix=f"{destination.name}.tmp-", dir=str(base_dir))
    )
    try:
        shutil.unpack_archive(str(archive_path), str(temp_dir_path))
        temp_dir_path.replace(destination)
    except Exception as exc:
        shutil.rmtree(temp_dir_path, ignore_errors=True)
        if isinstance(exc, shutil.ReadError):
            raise ExperimentError(f"Unsupported archive format for {archive_path}") from exc
        raise
