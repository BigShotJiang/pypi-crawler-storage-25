# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["StructureAndBindingEstimateCostResponse", "Breakdown"]


class Breakdown(BaseModel):
    """Cost breakdown for the billed application."""

    application: Literal[
        "structure_and_binding",
        "small_molecule_design",
        "small_molecule_library_screen",
        "protein_design",
        "protein_library_screen",
    ]

    cost_per_unit_usd: str
    """Cost per unit as a decimal string"""

    num_units: int


class StructureAndBindingEstimateCostResponse(BaseModel):
    """
    Estimate response with monetary values encoded as decimal strings to preserve precision.
    """

    breakdown: Breakdown
    """Cost breakdown for the billed application."""

    disclaimer: str

    estimated_cost_usd: str
    """Estimated total cost as a decimal string"""
