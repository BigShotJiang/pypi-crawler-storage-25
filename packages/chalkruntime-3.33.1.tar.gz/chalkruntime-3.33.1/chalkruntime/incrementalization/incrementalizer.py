from __future__ import annotations

import dataclasses
from datetime import datetime, timezone

import sqlglot
import sqlglot.expressions as sqlglot_expressions
from chalk.sql import FinalizedChalkQuery, IncrementalSettings, SQLSourceGroup
from chalk.sql._internal.sql_source import BaseSQLSource
from chalk.utils.collections import get_unique_item
from chalk.utils.log_with_context import get_logger, get_public_logger
from sqlalchemy import column, select, text
from sqlalchemy.sql.elements import TextClause

from chalkruntime.constants import CLOSE_TO_MIN_UTC
from chalkruntime.incrementalization.group_incrementalizer import incrementalize_grouped_query
from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter
from chalkruntime.sql_rewriter.query_rewriter_helper import to_sqlglot

_logger = get_logger(__name__)


_public_logger = get_public_logger(__name__)


class IncrementalBindParam:
    feature_time = "chalk_incremental_timestamp"
    resolver_execution_time = "chalk_last_execution_timestamp"


@dataclasses.dataclass(frozen=True)
class HighWaterMark:
    max_ingested_timestamp: datetime | None
    last_execution_timestamp: datetime | None

    @staticmethod
    def empty() -> "HighWaterMark":
        return HighWaterMark(max_ingested_timestamp=None, last_execution_timestamp=None)


def apply_incremental_settings(settings: IncrementalSettings, ts: datetime | None) -> datetime:
    if ts is None:
        return datetime.min.replace(tzinfo=timezone.utc)
    if settings.lookback_period is None:
        return ts
    else:
        # Handle overflow; can't sub timedelta from datetime.min & we have that on the first run.
        if ts < CLOSE_TO_MIN_UTC:
            return ts
        else:
            return ts - settings.lookback_period


@dataclasses.dataclass(frozen=True)
class Incrementalizer(QueryRewriter):
    upper_bound: datetime | None
    lower_bound: datetime | None
    hwm: HighWaterMark | None
    use_sqlglot: bool

    # FIXME: paginate this
    def __call__(
        self,
        chalk_query: FinalizedChalkQuery,
        resolver_fqn: str,
    ) -> FinalizedChalkQuery:
        settings = chalk_query.incremental_settings
        if settings is None:
            return chalk_query
        _logger.info(f"HWM For {resolver_fqn} is: {self.hwm}")
        if self.hwm is None:
            lower_bound_ts = datetime.min.replace(tzinfo=timezone.utc)
            last_execution_ts = datetime.min.replace(tzinfo=timezone.utc)
        else:
            lower_bound_ts = apply_incremental_settings(settings=settings, ts=self.hwm.max_ingested_timestamp)
            last_execution_ts = apply_incremental_settings(settings=settings, ts=self.hwm.last_execution_timestamp)

        has_bounds = any((self.lower_bound, self.upper_bound))
        if has_bounds:
            _public_logger.info(
                (
                    f"Bounds for triggering resolver '{resolver_fqn}' are manually provided: "
                    f"upper_bound={self.upper_bound} lower_bound={self.lower_bound}"
                )
            )
            start_ts, end_ts = self.lower_bound, self.upper_bound
        else:
            _public_logger.info(
                (
                    f"Incremental settings for {resolver_fqn} is {settings}, resulting in lower bound "
                    f"timestamp of '{lower_bound_ts}' and last execution timestamp '{last_execution_ts}'"
                )
            )
            start_ts = lower_bound_ts if settings.incremental_timestamp == "feature_time" else last_execution_ts
            end_ts = None

        if isinstance(chalk_query.query, TextClause):
            assert isinstance(chalk_query.source, (BaseSQLSource, SQLSourceGroup))

            chalk_query_normalized = str(chalk_query.query)
            """
            This string will be "normalized", in particular to remove any trailing ';'.
            """
            try:
                dialect = chalk_query.source.get_sqlglot_dialect()
                # Note: we are deliberately usinge `sqlglot.parse` instead of `sqlglot.parse_one`
                # because we want to leniently permit SQL queries which end with a trailing semicolon.
                chalk_query_parsed = sqlglot.parse(sql=chalk_query_normalized, read=dialect)
                chalk_query_parsed = [expr for expr in chalk_query_parsed if expr != None]
                if len(chalk_query_parsed) != 1:
                    # If there aren't any queries, or there are 2 or more, it is unclear which should be used.
                    # In practice we expect that this won't happen.
                    raise ValueError(
                        f"Parsed SQL statement has {len(chalk_query_parsed)} queries instead of expected 1"
                    )
                # This normalization can change capitalization / indent / comment styles etc. but it will not
                # change the semantics of the query.
                chalk_query_normalized = chalk_query_parsed[0].sql(dialect=dialect)
            except Exception as e:
                # We expect that this should never happen; but if it does, we can continue under the assumption
                # that the original query string is already normalized.
                _logger.error(
                    f"Failed to normalize SQL string {repr(str(chalk_query.query))} with sqlglot because {str(e)}"
                )

            if settings.mode == "parameter":
                if has_bounds:
                    raise NotImplementedError(
                        "'parameter' mode incrementalization not supported with explicit upper/lower bounds"
                    )
                params = dict(chalk_query.params)
                params[IncrementalBindParam.feature_time] = lower_bound_ts
                params[IncrementalBindParam.resolver_execution_time] = last_execution_ts
                return FinalizedChalkQuery(
                    query=chalk_query.query,
                    params=params,
                    finalizer=chalk_query.finalizer,
                    incremental_settings=None,
                    source=chalk_query.source,
                    fields=chalk_query.fields,
                    temp_tables=chalk_query.temp_tables,
                    is_empty=chalk_query.is_empty,
                )
            elif settings.mode == "row":
                assert settings.incremental_column is not None, "incremental column must be specified if mode is row"

                apply_lower_bound = start_ts is not None and start_ts != datetime.min.replace(tzinfo=timezone.utc)
                apply_upper_bound = end_ts is not None and end_ts != datetime.max.replace(tzinfo=timezone.utc)
                if not apply_lower_bound and not apply_upper_bound:
                    return chalk_query

                if self.use_sqlglot:
                    sqlglot_query = to_sqlglot(chalk_query)
                    temporary_table_name = "temp_table_for_incrementalization"
                    sqlglot_query = sqlglot.select("*").from_(
                        sqlglot_expressions.alias_(sqlglot_query, temporary_table_name)
                    )
                    START_TS_PARAM = "incremental_start_ts"
                    END_TS_PARAM = "incremental_end_ts"
                    if apply_lower_bound:
                        sqlglot_query = sqlglot_query.where(
                            sqlglot.column(settings.incremental_column)
                            >= sqlglot_expressions.Placeholder(this=START_TS_PARAM)
                        )
                    if apply_upper_bound:
                        sqlglot_query = sqlglot_query.where(
                            sqlglot.column(settings.incremental_column)
                            < sqlglot_expressions.Placeholder(this=END_TS_PARAM)
                        )
                    return FinalizedChalkQuery(
                        query=text(sqlglot_query.sql(dialect=chalk_query.source.get_sqlglot_dialect())),
                        params={**chalk_query.params, START_TS_PARAM: start_ts, END_TS_PARAM: end_ts},
                        finalizer=chalk_query.finalizer,
                        incremental_settings=None,
                        source=chalk_query.source,
                        fields=chalk_query.fields,
                        temp_tables=chalk_query.temp_tables,
                        is_empty=chalk_query.is_empty,
                    )

                else:
                    sq = (
                        TextClause(chalk_query_normalized)
                        .columns(column(settings.incremental_column))
                        .subquery("original_query")
                    )
                    new_query = select("*").select_from(sq)
                    if apply_lower_bound:
                        new_query = new_query.where(sq.c[settings.incremental_column] >= start_ts)
                    if apply_upper_bound:
                        new_query = new_query.where(sq.c[settings.incremental_column] < end_ts)

                    return FinalizedChalkQuery(
                        params=chalk_query.params,
                        finalizer=chalk_query.finalizer,
                        incremental_settings=None,
                        source=chalk_query.source,
                        query=new_query,
                        fields=chalk_query.fields,
                        temp_tables=chalk_query.temp_tables,
                        is_empty=chalk_query.is_empty,
                    )
            elif settings.mode == "group":
                if has_bounds:
                    raise NotImplementedError(
                        "'group' mode incrementalization not supported with explicit upper/lower bounds"
                    )

                assert settings.incremental_column is not None, "incremental column must be specified if mode is group"
                bind_param_name = (
                    IncrementalBindParam.feature_time
                    if settings.incremental_timestamp == "feature_time"
                    else IncrementalBindParam.resolver_execution_time
                )
                new_query = incrementalize_grouped_query(
                    query=chalk_query_normalized,
                    dialect=chalk_query.source.get_sqlglot_dialect(),
                    updated_at_column=settings.incremental_column,
                    bind_param_name=bind_param_name,
                )
                _logger.info(f"New query: {new_query=}, {str(lower_bound_ts)}")
                params = dict(chalk_query.params)
                params[IncrementalBindParam.feature_time] = lower_bound_ts
                params[IncrementalBindParam.resolver_execution_time] = last_execution_ts
                return FinalizedChalkQuery(
                    params=params,
                    # nosemgrep: avoid-sqlalchemy-text -- sqlglot returns text
                    query=text(new_query),
                    finalizer=chalk_query.finalizer,
                    incremental_settings=None,
                    source=chalk_query.source,
                    fields=chalk_query.fields,
                    temp_tables=chalk_query.temp_tables,
                    is_empty=chalk_query.is_empty,
                )
            else:
                raise ValueError(f"Unsupported incremental mode: {settings.mode}")

        else:
            sq = chalk_query.query.subquery()

            # e.g. [{'name': 'user.id', 'type': String(), 'aliased': False, 'expr': ..., 'entity': ...}, ...]
            ft = get_unique_item((f for f in chalk_query.fields.values() if f.is_feature_time), "feature time feature")

            updated = select(sq)
            if start_ts is not None:
                updated = updated.filter(sq.c[ft.fqn] >= start_ts)
            if end_ts is not None:
                updated = updated.filter(sq.c[ft.fqn] < end_ts)
            updated = updated.order_by(sq.c[ft.fqn].asc())

            return FinalizedChalkQuery(
                query=updated,
                params=chalk_query.params,
                finalizer=chalk_query.finalizer,
                incremental_settings=None,
                source=chalk_query.source,
                fields=chalk_query.fields,
                temp_tables=chalk_query.temp_tables,
                is_empty=chalk_query.is_empty,
            )


EMPTY_INCREMENTALIZER = Incrementalizer(
    hwm=HighWaterMark.empty(),
    upper_bound=None,
    lower_bound=None,
    use_sqlglot=False,
)
