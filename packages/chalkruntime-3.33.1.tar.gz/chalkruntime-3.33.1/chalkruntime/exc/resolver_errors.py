import traceback
from datetime import datetime, timedelta, timezone
from typing import Collection, Sequence

from chalk.client.models import ChalkError, ChalkException, ErrorCode, ErrorCodeCategory
from chalk.features.resolver import ResourceHint
from chalk.utils.chalk_record_batch import ChalkRecordBatch
from chalk.utils.df_utils import to_pylist
from chalk.utils.string import pluralize, readable_duration, resolver_name


class ResolverErrors:
    @staticmethod
    def wrong_resource_hint(resolver: str, provided_hint: ResourceHint, correct_hint: ResourceHint, reason: str):
        return ChalkError.create(
            code=ErrorCode.RESOLVER_FAILED,
            message=(
                f"Resolver '{resolver}' is annotated with a resource hint of '{provided_hint}', but it should instead be marked as '{correct_hint}'. "
                f"Please update the resolver definition for this resolver -- e.g. @online(resource_hint='{correct_hint}')."
                f"The underlying reason was: {reason}"
            ),
            resolver=resolver,
        )

    @staticmethod
    def source_code_not_available(resolver: str):
        return ChalkError.create(
            code=ErrorCode.RESOLVER_FAILED,
            message=(
                f"The source code for resolver '{resolver}' is not available, so Chalk is unable to execute it."
                "Ensure that the environment variable 'CHALK_DISABLE_SOURCE_CODE_PARSING' is not set."
            ),
            resolver=resolver,
        )

    @staticmethod
    def wrong_inputs(
        *,
        message: str,
        resolver_fqn: str,
    ) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=message,
            resolver=resolver_fqn,
            exception=None,
        )

    @staticmethod
    def wrong_output_type(
        *,
        expected_type_name: str,
        result_type_name: str,
        resolver_fqn: str,
        feature_fqn: str | None,
    ) -> ChalkError:
        message = f'Expected "{expected_type_name}", got "{result_type_name}" from resolver "{resolver_fqn}"'
        if feature_fqn:
            message += f' for feature "{feature_fqn}"'
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=message,
            resolver=resolver_fqn,
            feature=feature_fqn,
            exception=None,
        )

    @staticmethod
    def static_operator_not_supported(*, resolver_fqn: str, reason: str):
        message = f"Resolver '{resolver_fqn}' is marked as static; however, static operators are not supported in this context. To fix, remove the `static=True` from the resolver definition: {reason}"
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=message,
            resolver=resolver_fqn,
            feature=None,
            exception=None,
        )

    @staticmethod
    def wrong_output_count(*, expected_count: int, actual_count: int, resolver_fqn: str) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=f'Expected "{expected_count}" feature outputs from "{resolver_fqn}", got "{actual_count}". instead',
            resolver=resolver_fqn,
            feature=None,
            exception=None,
        )

    @staticmethod
    def ft_missing_timezone(*, resolver_fqn: str, feature_fqn: str) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=f'Expected feature_time "{feature_fqn}", output from resolver "{resolver_fqn}", to specify tzinfo."',
            resolver=resolver_fqn,
            exception=None,
        )

    @staticmethod
    def mismatched_streaming_window_invocation(
        *,
        resolver_fqn: str,
        given_window_size_sec: int,
        available_window_sizes: Sequence[int],
    ) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.RESOLVER_FAILED,
            message=(
                f"Attempt to invoke windowed stream resolver with configured periods={available_window_sizes}"
                f" with a mismatched period value {given_window_size_sec}."
                f" This is likely caused by a recent deployment changing the resolver's window window size."
                f" This job will be marked as failed and retried up to the max retry limit"
            ),
            resolver=resolver_fqn,
            exception=None,
        )

    @staticmethod
    def streaming_window_resolvers_cannot_use_state(resolver_fqn: str) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message="State is not supported for windowed stream resolvers",
            resolver=resolver_fqn,
            exception=None,
        )

    @staticmethod
    def streaming_resolver_not_found(resolver_fqn: str) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=(
                f"Could not find the requested streaming resolver '{resolver_fqn}'. "
                f"This could mean that your resolver has not yet been promoted to production."
            ),
            resolver=resolver_fqn,
            exception=None,
        )

    @staticmethod
    def streaming_resolvers_without_key_cannot_use_state(resolver_fqn: str) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=(
                "State is not supported for this resolver because the StreamSource it's connected to "
                " did not supply a key for this message. To use State with this resolver, please include a key on "
                " all messages to your underlying streaming provider"
            ),
            resolver=resolver_fqn,
            exception=None,
        )

    @staticmethod
    def resolver_missing_pkey_output(resolver_fqn: str) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=(
                "This resolver did not include primary key features data in its output."
                " You must include pkeys in your output to tell Chalk which entities you're generating features for"
            ),
            resolver=resolver_fqn,
            exception=None,
        )

    @staticmethod
    def failed_upstream_arguments(resolver_fqn: str, missing_args: Sequence[str]) -> ChalkError:
        return ChalkError.create(
            message=f'Could not execute "{resolver_fqn}" because required {pluralize("argument", missing_args)} could not be computed. This is likely because the selected resolver returned `None` for this feature, crashed, or a join did not match.',
            code=ErrorCode.UPSTREAM_FAILED,
            category=ErrorCodeCategory.FIELD,
            resolver=resolver_fqn,
        )

    @staticmethod
    def failed_to_convert_to_dataframe(*, resolver_fqn: str, exception: ChalkException | None) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=f'The resolver "{resolver_fqn}" returned a result that could not be converted into a DataFrame.',
            exception=exception,
            feature=None,
            resolver=resolver_fqn,
        )

    @staticmethod
    def dataframe_instead_of_scalar(
        *,
        resolver_fqn: str,
        dataframe_shape: tuple[int, ...] | None = None,
        dataframe_columns: Sequence[str] | None = None,
    ) -> ChalkError:
        message = f'The resolver "{resolver_fqn}" was expected to return a scalar, but returned a DataFrame'
        if dataframe_shape is not None:
            message += f" shape=({dataframe_shape[0]} rows, {dataframe_shape[1]} cols)"
        if dataframe_columns is not None:
            message += f" with columns {repr(dataframe_columns)}"
        message += "."
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=message,
            exception=None,
            feature=None,
            resolver=resolver_fqn,
        )

    @staticmethod
    def wrong_df_columns(
        resolver_fqn: str,
        expected: Collection[str],
        actual: Collection[str],
        path: str | None = None,
        include_additional_in_output: bool = True,
    ) -> ChalkError:
        additional = sorted(x for x in actual if x not in expected)
        missing = sorted(x for x in expected if x not in actual)

        error = f'Resolver "{resolver_fqn}" returned DataFrame with invalid columns'
        if path:
            error += f" at return for '{path}'"

        if include_additional_in_output and len(additional) > 0:
            error += f".\nOutput DataFrame contained unexpected {pluralize('column', additional)}"

        if len(missing) > 0:
            error += f".\nOutput DataFrame missing expected {pluralize('column', missing)}"

        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=error,
            resolver=resolver_fqn,
            exception=None,
        )

    @staticmethod
    def sub_plan_join_duplicate_rows(duplicate_rows: ChalkRecordBatch):
        # Unfortunately we don't have the resolver at this point in the plan :/

        # This is kinda hacky but makes the error message nicer
        duplicate_rows = duplicate_rows.select(
            x for x in duplicate_rows.column_names if not x.startswith("__chalk__temp_")
        ).slice(0, 10)
        if len(duplicate_rows.column_names) == 1:
            feature_fqn = duplicate_rows.column_names[0]
            feature_fqn_formatted = f" {feature_fqn!r}"
            duplicate_rows_formatted = (
                f"Some of the duplicate values are {to_pylist(duplicate_rows.column(feature_fqn))}"
            )
        else:
            feature_fqn = None
            feature_fqn_formatted = ""
            duplicate_rows_formatted = f"Some of the duplicate values are {duplicate_rows.pprint_string()}"
        error = (
            f"A resolver returned duplicate rows for the foreign join feature{feature_fqn_formatted} for a has-one relationship. "
            "This is not permitted as a has-one relationship must have at most one foreign row for each local row. "
            "Try changing the relationship to a has-many, or modifying the upstream resolvers to ensure that foreign rows are not duplicated. "
            f"{duplicate_rows_formatted}"
        )
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=error,
            feature=feature_fqn,
            resolver=None,
            exception=None,
        )

    @staticmethod
    def df_has_duplicate_pkey_ts_rows(
        resolver_fqn: str,
        pkey_fqn: str,
        ts_fqn: str | None,
        pkeys: list[str | int],
        timestamps: list[datetime | None] | None,
        path: str | None,
    ) -> ChalkError:
        if timestamps:
            pkey_list = sorted((pkey, ts) for pkey, ts in zip(pkeys, timestamps))
            error = (
                f'The resolver "{resolver_fqn}" returned a DataFrame with at least one primary '
                + "key showing up twice at exactly the same time. "
                + "This means that the underlying data is inconsistent: "
                + "it is impossible to know which of the values from the row represents the true state of the world. "
                + f'Duplicate primary key shows up for the column "{pkey_fqn}"'
                + ("" if ts_fqn is None else f" the timestamp column {ts_fqn}")
                + ". For a concrete example, the following primary key and timestamp combination "
                + f"({pkey_fqn}, {ts_fqn}) shows up multiple times: "
                + "; ".join(
                    f"({pkey}, {'null' if ts is None else ts.astimezone(timezone.utc).isoformat()})"
                    for (pkey, ts) in pkey_list
                )
            )
        else:
            error = (
                f'The resolver "{resolver_fqn}" returned a DataFrame with at least one primary key showing up twice. '
                + "This means that the underlying data is inconsistent: "
                + "it is impossible to know which of the values from the row represents the true state of the world. "
                + f"Duplicate primary key shows up for the column {pkey_fqn}. "
                + f"For a concrete example, the following {pkey_fqn} shows up multiple times: "
                + "; ".join(str(x) for x in sorted(pkeys))
            )

        if path:
            error += f'. This error happened in computing "{path}".'

        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=error,
            resolver=resolver_fqn,
            exception=None,
        )

    @staticmethod
    def unrecognized_streaming_resolver_arg(resolver_fqn: str, argument_name: str) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=(
                f"Parameter '{argument_name}' has unrecognized or unsupported Python type."
                f" Streaming resolver parameters must be one of:\n"
                f"    - The message body, which must be one of `bytes`, `str`, a Pydantic model, or a dataclass"
                f"    - A State[] parameter"
            ),
            resolver=resolver_fqn,
            exception=None,
        )

    @staticmethod
    def unrecognized_streaming_window_resolver_arg(resolver_fqn: str, argument_name: str) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=(
                f"Parameter '{argument_name}' has unrecognized or unsupported Python type."
                f" Windowed streaming resolver parameters must be:\n"
                f"    - A Sequence[T] or List[T] of message bodies, where T is one of `bytes`, `str`, a Pydantic model, or a dataclass"
            ),
            resolver=resolver_fqn,
            exception=None,
        )

    @staticmethod
    def missing_remote_primary_key(for_ns: str, resolver_fqn: str) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=(
                f"Resolver '{resolver_fqn}' returned features in feature set '{for_ns}', but did not return a"
                f" primary key for feature class '{for_ns}'."
            ),
            resolver=resolver_fqn,
        )

    @staticmethod
    def multiple_missing_features(for_features: Sequence[str]) -> ChalkError:
        return ChalkError.create(
            category=ErrorCodeCategory.REQUEST,
            code=ErrorCode.RESOLVER_NOT_FOUND,
            feature=str(for_features[0]),
            message=f"Failed to find any valid resolver for {pluralize('feature', [str(f) for f in for_features])}",
        )

    @staticmethod
    def missing_resolver_no_fallback(for_feature: str) -> ChalkError:
        return ChalkError.create(
            category=ErrorCodeCategory.REQUEST,
            code=ErrorCode.RESOLVER_NOT_FOUND,
            feature=str(for_feature),
            message=(
                f"Failed to find any valid resolver for feature: '{for_feature}' and no `default` value or `max_staleness`"
                f" was specified for '{for_feature}', so the feature cannot be defaulted or resolved from the online store."
            ),
        )

    @staticmethod
    def missing_uncached_feature(fqn: str) -> ChalkError:
        return ChalkError.create(
            category=ErrorCodeCategory.REQUEST,
            code=ErrorCode.VALIDATION_FAILED,
            feature=fqn,
            message=f"Failed to find any value for feature: '{fqn}', and '{fqn}' was not found in the online store.",
        )

    @staticmethod
    def missing_namedtuple_element(feature_fqn: str) -> ChalkError:
        return ChalkError.create(
            category=ErrorCodeCategory.FIELD,
            code=ErrorCode.INVALID_QUERY,
            message=f"Could not compute feature '{str(feature_fqn)}'",
            feature=feature_fqn,
        )

    @staticmethod
    def bad_sql_query(resolver_fqn: str, exception: Exception) -> ChalkError:
        return ChalkError.create(
            category=ErrorCodeCategory.FIELD,
            code=ErrorCode.INVALID_QUERY,
            message=f"Could not execute SQL query: '{str(exception)}'",
            resolver=resolver_fqn,
        )

    @staticmethod
    def resolver_timed_out(resolver_fqn: str, timeout: timedelta) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.RESOLVER_TIMED_OUT,
            message=(
                f"Resolver '{resolver_fqn}' timed out because its execution took longer than "
                f"the specified maximum duration {readable_duration(timeout)}"
            ),
            resolver=resolver_fqn,
        )

    @staticmethod
    def resolver_raised_exception(resolver_fqn: str, exception: BaseException) -> ChalkError:
        first_non_internal_frame = 1
        frames = traceback.format_exception(exception)
        for idx in range(len(frames) - 1, -1, -1):
            if "chalkruntime" in frames[idx]:
                first_non_internal_frame = idx + 1
                break

        stacktrace = "".join(frames[first_non_internal_frame:])
        return ChalkError.create(
            code=ErrorCode.RESOLVER_FAILED,
            message=exception.__class__.__name__ + ": " + str(exception),
            exception=ChalkException.create(
                kind=type(exception).__name__,
                message=str(exception),
                stacktrace=stacktrace,
                internal_stacktrace="".join(frames),
            ),
            feature=None,
            resolver=resolver_fqn,
        )

    @staticmethod
    def cycle_detected(repeating_node: str, path: list[str]) -> ChalkError:
        name = resolver_name(repeating_node)
        try:
            path = path[path.index(repeating_node) + 1 :]
        except (ValueError, IndexError):
            return ChalkError.create(
                code=ErrorCode.PARSE_FAILED,
                message=f"Resolver cycle detected for resolver '{repeating_node}'",
            )

        # Not using FQN because it's too long and gets truncated by our CLI.
        # and the --json flag converts '->' to some weird representation.
        path_string = " -> ".join([resolver_name(p) for p in path])
        return ChalkError.create(
            code=ErrorCode.PARSE_FAILED,
            message=f"Resolver cycle detected: {name} -> {path_string} -> {name}",
        )

    @staticmethod
    def df_resolver_cant_join_ts_to_output(
        resolver_fqn: str, relevant_inputs: ChalkRecordBatch | None, relevant_outputs: ChalkRecordBatch | None
    ) -> ChalkError:
        num_error_rows = 10
        error_msg = f"""\
DataFrame-taking resolver '{resolver_fqn}' produced output with ambiguous primary keys that
could not be joined against input timestamps. This usually occurs when a query samples the same data at multiple
timestamps, but the output of the resolver has some missing/duplicate rows.

To fix this, either add a FeatureTime column to your resolver's output to disambiguate,
or, if the resolver drops rows that have null values, make sure that null rows are explicitly
included in the output."""

        if relevant_inputs is not None:
            error_msg += f"""\

Relevant input rows (first {num_error_rows}):
{relevant_inputs.slice(0, num_error_rows).pprint_string()}"""

        if relevant_outputs is not None:
            error_msg += f"""\
Relevant output rows (first {num_error_rows}):
{relevant_outputs.slice(0, num_error_rows).pprint_string()}"""

        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message=error_msg,
            resolver=resolver_fqn,
        )

    @staticmethod
    def too_many_has_many_outputs(
        resolver_fqn: str,
    ) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.INVALID_QUERY,
            message=f"Resolver '{resolver_fqn}' returned 2 has-many outputs in the same relationship. Please combine them into a single has-many output.",
            resolver=resolver_fqn,
        )

    @staticmethod
    def failed_validation(
        validation: str,
        example_value: str,
        feature: str,
    ) -> ChalkError:
        return ChalkError.create(
            code=ErrorCode.RESOLVER_FAILED,
            # TODO: should this be VALIDATION_FAILED? If not, should we also give the resolver_fqn?
            message=f"Expected `{validation}`, but received `{example_value}`",
            feature=feature,
        )

    @staticmethod
    def unparsable_input_feature_time_features(
        resolver_fqn: str | None,
        ts_feature_fqn: str,
    ):
        reason = f"Resolver '{resolver_fqn}" if resolver_fqn is not None else "The query"
        return ChalkError.create(
            code=ErrorCode.INVALID_QUERY,
            message=f"""{reason} requested a feature time feature '{ts_feature_fqn}' as input,
but its inputs does not contain a scalar feature in the same namespace.
The value of {ts_feature_fqn} cannot be resolved.""",
            resolver=resolver_fqn,
            feature=ts_feature_fqn,
        )

    @staticmethod
    def unparsable_output_feature_time_features(
        resolver_fqn: str | None,
        ts_feature_fqn: str,
    ):
        reason = f"Resolver '{resolver_fqn}" if resolver_fqn is not None else "The query"
        return ChalkError.create(
            code=ErrorCode.INVALID_QUERY,
            message=f"""{reason} returned a feature time feature '{ts_feature_fqn}' as output,
but its output does not contain a scalar feature in the same namespace.
The returned value of {ts_feature_fqn} will never be used.""",
            resolver=resolver_fqn,
            feature=ts_feature_fqn,
        )

    @staticmethod
    def cannot_accelerate_python_resolver(
        resolver_fqn: str,
        reason: BaseException | None,
    ):
        if isinstance(reason, BaseException):
            exception = ChalkException.from_exception(reason)
        else:
            exception = None

        return ChalkError.create(
            code=ErrorCode.VALIDATION_FAILED,
            message="Cannot accelerate resolver marked `accelerate_python='required'`",
            exception=exception,
            resolver=resolver_fqn,
        )
