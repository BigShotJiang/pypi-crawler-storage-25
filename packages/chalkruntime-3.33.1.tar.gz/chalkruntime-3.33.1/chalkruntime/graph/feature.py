from __future__ import annotations

import collections.abc
import copy
import dataclasses
import functools
import re
from datetime import datetime, timedelta
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    FrozenSet,
    Generic,
    Iterable,
    List,
    Literal,
    Mapping,
    NewType,
    NoReturn,
    Optional,
    Sequence,
    Set,
    Tuple,
    TypeGuard,
    TypeVar,
    Union,
    cast,
    overload,
)

import pyarrow as pa
from chalk.features import CacheStrategy, DataFrame, Feature, Filter, TPrimitive, Underscore
from chalk.features._encoding.converter import (
    FeatureConverter,
    PrimitiveFeatureConverter,
    pyarrow_to_polars,
)
from chalk.features._encoding.serialized_rich_type import SerializedRichType
from chalk.features.pseudofeatures import CHALK_TS_FEATURE, PSEUDONAMESPACE
from chalk.parsed.expressions import Operation
from chalk.parsed.expressions import is_valid_operation as _is_valid_operation
from chalk.serialization.parsed_annotation import ParsedAnnotation
from chalk.utils.collections import (
    FrozenOrderedSet,
    OrderedSet,
    get_unique_item,
    unwrap_annotated_if_needed,
    unwrap_optional,
)
from chalk.utils.dataclass_slots_patch import (
    install_dataclass_slots_patch_if_needed,
)
from chalk.utils.duration import timedelta_to_duration
from chalk.utils.log_with_context import get_logger
from typing_extensions import Final, get_args, get_origin

from chalkruntime.graph.global_graph import get_global_graph
from chalkruntime.utils.internal_pl_utils import CompatPlDataType

if TYPE_CHECKING:
    from chalkruntime.graph.graph import GraphCached, ResolvedGraph
    from chalkruntime.graph.materializations import MaterializationWindowConfigParsed
    from chalkruntime.graph.nearest_neighbor import NearestNeighborJoinInfo
    from chalkruntime.graph.underscore import FilterExpressionParsed

T = TypeVar("T")

install_dataclass_slots_patch_if_needed()
_logger = get_logger(__name__)


class FeatureType:
    """Base class for FeatureTypes"""

    __slots__ = ()  # Subclasses must define the slots

    __exclude_from_state__: tuple[str, ...] = ()
    """Members to exclude from the state, because they cannot be pickled"""

    @property
    def is_schema_feature_type(self) -> bool:
        raise NotImplementedError

    @property
    def is_value_schema_feature_type(self) -> bool:
        raise NotImplementedError

    @property
    def display_name(self) -> str:
        raise NotImplementedError

    def __getstate__(self):
        state = []
        for k in self.__slots__:
            if k in self.__exclude_from_state__ or not hasattr(self, k):
                state.append(...)
            else:
                state.append(getattr(self, k))
        return tuple(state)

    def __setstate__(self, state: tuple[Any, ...]):
        for k, v in zip(self.__slots__, state):
            if k in self.__exclude_from_state__:
                continue
            if v is ...:
                continue
            object.__setattr__(self, k, v)


AliasPrefix = NewType("AliasPrefix", str)
"""
An `AliasPrefix` is the string that appears before `:` in an alias-prefixed namespace.

A feature like "user.id" can be optionally prefixed as in "alpha:user.id" with a string.
The string must be non-empty, and cannot contain ':' or '.'.

Alias-prefixed features are treated identically to their original counterparts, except
that references to other features are also aliased. For example, `alpha:user.account.id`
has the underlying feature `alpha:account.id`.
"""


def get_alias_prefix_from_str(name: str) -> AliasPrefix | None:
    """
    Features can optionally be prefixed with an 'alias', which is a non-empty
    string of characters excluding '.' and ':', followed by a colon.

    For example, 'alpha:user.id' is the 'alpha'-prefixed version of 'user.id'.

    If the provided string does not have a prefix, then `None` is returned.

    To get the un-aliased name, call `get_unaliased_str(s, alias_prefix="alpha")`.
    """
    if ":" not in name:
        return None
    alias_colon_index = name.index(":")
    if name[alias_colon_index:].startswith("::"):
        return None

    alias_prefix = AliasPrefix(name[:alias_colon_index])
    if "." in alias_prefix:
        return None
    return alias_prefix


def remove_alias_prefix_from_str(
    s: str,
    *,
    alias_prefix: AliasPrefix,
    raise_if_not_aliased: bool = True,
) -> str:
    """
    Returns the input string with the specified alias prefix removed.

    If the string does not have the alias prefix, then it will either be returned unchanged
    or an exception will be raised, depending on `raise_if_not_aliased`.
    """
    if alias_prefix == "" or ":" in alias_prefix or "." in alias_prefix:
        raise ValueError(f"Alias prefix {repr(alias_prefix)} is illegal; it cannot be removed from string {repr(s)}")
    if s.startswith(alias_prefix + ":"):
        # Remove the aliasing prefix from the string.
        return s[len(alias_prefix) + 1 :]

    if raise_if_not_aliased:
        # The string does not start with the specified prefix, so raise an exception.
        raise ValueError(f"The alias prefix {repr(alias_prefix)} cannot be removed from the string {repr(s)}")

    # The string does not start with the specified prefix, so return it unchanged.
    return s


def add_alias_prefix_to_str(s: str, *, alias_prefix: AliasPrefix):
    if alias_prefix == "" or ":" in alias_prefix or "." in alias_prefix:
        raise ValueError(f"Alias prefix {repr(alias_prefix)} is illegal; it cannot be added to string {repr(s)}")

    existing_alias = get_alias_prefix_from_str(s)
    if existing_alias is not None:
        raise ValueError(
            f"Cannot add alias prefix {repr(alias_prefix)} to string {repr(s)} because it already has an alias prefix"
        )

    return alias_prefix + ":" + s


@dataclasses.dataclass(frozen=True, repr=False)
class NamedFeatureType(FeatureType):
    """This mixin class is used by FeatureTypes that have a name. Notably, DataFrameType features do NOT have a name.
    All other feature types do have a name.

    Args:
        name (str): The feature name.
        namespace (str): The feature namespace.
        root_prefix (str): The full namespace path, relative to the root, without the feature name.
            If the feature is an input feature, the rooted prefix will begin with the root namespace of the resolver,
            and contain the feature names of all relationships (except for the feature name in foreign features class).
            For example, if a resolver referenced ``Child.parent.name``, then this would be ``child.parent``.

            Otherwise, this is equivalent to :attr:`namespace`.
    """

    __slots__ = ()

    name: str
    namespace: str
    _graph: ResolvedGraph = dataclasses.field(compare=False)
    root_prefix: str = dataclasses.field(init=False)
    root_namespace: str = dataclasses.field(init=False, compare=False)
    """The first component of the namespace.

    If the feature is an input feature, the root namespace should be the root namespace of the resolver.
    For example, if a resolver referenced ``Child.parent.name``, then this would be ``child``.

    Otherwise, this is equivalent to :attr:`namespace`.
    """

    root_fqn: str = dataclasses.field(init=False, compare=False)
    """The fqn, relative to the root namespace.

    If the feature is an input feature, the rooted fqn will begin with the root namespace of the resolver,
    and contain all feature names of all relationships, including the feature name.
    For example, if a resolver referenced ``Child.parent.name``, then this would be ``child.parent.name``.

    Otherwise, this is equivalent to :attr:`fqn`.
    """

    fqn: str = dataclasses.field(init=False, compare=False)

    original_python_attribute_name: str | None = dataclasses.field(compare=False)
    """The name of the feature as it's defined in the Python code.

    Typically, this will be the same as the `name` attribute, but
    for a feature defined as `name: feature(name="other_name")`
    - `name` is "other_name"
    - `original_python_attribute_name` is "name"
    """

    attribute_name: str | None = dataclasses.field(compare=False)
    """
    Name of the feature when used as a kwarg for the feature class constructor,
    or member access for a feature class object. This might include a version number as well.

    It's only None if the raw Feature object does not have self.attribute_name defined
    ```
    @features
    class Owl:
        id: int
        wingspan: float = feature(version=2, name="the_wingspan")

    f = Owl.wingspan@2
    assert f.name == "the_wingspan@2"
    assert f.attribute_name == "wingspan_v2"
    assert f.unversioned_attribute_name == "wingspan"

    # Below, the kwarg name is the `attribute_name`
    o = Owl(id=1, wingspan_v2="xyz")
    print(o.wingspan_v2)
    ```
    """

    is_externally_defined: bool = dataclasses.field(compare=False)
    """
    Whether this feature exists in the deployment code or was externally defined in a notebook.
    Notebook-defined features can be used in queries by providing an 'overlay graph', in which case the raw Feature object
    (i.e. customer python code) will not be available in the feature registry. (specifically, Feature.from_root_fqn(x) won't work)
    """

    @property
    def display_name(self) -> str:
        return self.root_fqn

    def __post_init__(self):
        # Using object.__setattr__ since the class is frozen
        # Default the root_prefix to the namespace unless if a subclass sets it differently
        object.__setattr__(self, "root_prefix", self.namespace)
        object.__setattr__(self, "root_namespace", self.root_prefix.split(".")[0])
        object.__setattr__(self, "root_fqn", f"{self.root_prefix}.{self.name}")
        object.__setattr__(self, "fqn", f"{self.namespace}.{self.name}")

    def __str__(self):
        return self.root_fqn

    def __repr__(self):
        return f"{type(self).__name__}({self.root_fqn})"

    def __setstate__(self, state: tuple[Any, ...]):
        FeatureType.__setstate__(self, state)

    @property
    def graph(self):
        if not hasattr(self, "_graph"):
            object.__setattr__(self, "_graph", get_global_graph())
        return self._graph

    def __getattr__(self, name: str):
        if name == "_graph":
            # Attribute might not exist because it is set lazily when loading from a pickle dump
            object.__setattr__(self, "_graph", get_global_graph())
            return self.graph
        raise AttributeError(f"{type(self)!r} object has no attribute {name!r}")

    def get_root_alias(self) -> str | None:
        """
        A feature can have an "aliased name" like
        `active_u:user.id` - the part before the colon is the "root alias".

        These features behave exactly like their non-aliased counterparts, but
        allow for "duplicate" features to be distinguished.
        """
        return get_alias_prefix_from_str(self.root_namespace)

    def copy_with_root_alias(self, root_alias: AliasPrefix) -> "NamedFeatureType":
        """
        Create a copy of the current feature with the specified root alias prepended.
        """

        # This must be overridden in the subclass.
        raise ValueError(f"Unable to copy with root alias '{root_alias}' unsupported feature type '{self}'")

    def copy_without_root_alias(self, root_alias: AliasPrefix, *, allow_unaliased: bool) -> "NamedFeatureType":
        """
        Create a copy of the current feature with the specified root alias removed.
        If `allow_unaliased` is `False`, then raise an exception if it does not have the specified alias prefix.
        """

        # This must be overridden in the subclass.
        raise ValueError(f"Unable to copy without root alias '{root_alias}' unsupported feature type '{self}'")

    def to_feature(self) -> Feature:
        return Feature.from_root_fqn(self.root_fqn)


class StatePKey:
    __slots__ = ("input_position", "_pkey_root_fqn", "_hash")

    def __init__(self, input_position: int, pkey_fqn: str) -> None:
        super().__init__()
        self.input_position: Final = input_position
        self._pkey_root_fqn: Final = pkey_fqn

    @property
    def pkey(self) -> Feature[Any, Any]:
        return Feature.from_root_fqn(self._pkey_root_fqn)

    def __eq__(self, other: object):
        if not isinstance(other, StatePKey):
            return NotImplemented
        return other.input_position == self.input_position and other._pkey_root_fqn == self._pkey_root_fqn

    def __hash__(self) -> int:
        return hash((self.input_position, self._pkey_root_fqn))


@dataclasses.dataclass(frozen=True)
class StateDescriptorParsed:
    position: int
    kwarg: str
    initial: object
    typ: type[object]
    pkey: StatePKey | None


class _CompatibleWithNestedFeatureTypeMixin(NamedFeatureType, FeatureType):
    """Marker for feature type subclasses to mark that they can go within an NestedFeatureType.

    Notably, DataFrameType and NestedFeatureType cannot be the underlying of NestedFeatureType

    Using a subclass rather than a union type to support covariance
    """

    __slots__ = ()


_InputT_co = TypeVar("_InputT_co", bound=_CompatibleWithNestedFeatureTypeMixin, covariant=True)
_InputT = TypeVar("_InputT", bound=_CompatibleWithNestedFeatureTypeMixin)


@dataclasses.dataclass(frozen=True, repr=False, slots=True)
class NestedFeatureType(NamedFeatureType, FeatureType, Generic[_InputT_co]):
    """FeatureType used to represent the children of has-one or attred has-many relationships."""

    name: str = dataclasses.field(init=False)
    namespace: str = dataclasses.field(init=False)
    original_python_attribute_name: str | None = dataclasses.field(init=False, default=None)
    # attribute_name / is_externally_defined is ill-defined for NestedFeatureType
    # TODO (should probably move these fields out of NamedFeatureType)
    attribute_name: str | None = dataclasses.field(init=False, compare=False, default=None)
    is_externally_defined: bool = dataclasses.field(init=False, compare=False, default=False)
    underlying_ref: dataclasses.InitVar[_CompatibleWithNestedFeatureTypeMixin | str]
    _underlying_ref: str | HasManyFeatureType = dataclasses.field(init=False)

    # Excluding the path from the comparison as the root prefix is sufficient
    path: tuple[HasOnePathObjParsed, ...] = dataclasses.field(compare=False)
    _is_nullable_graph_cache: GraphCached[bool] = dataclasses.field(init=False, compare=False)
    _underlying_graph_cache: GraphCached[_InputT_co] = dataclasses.field(init=False, compare=False)
    _join_path_keys_graph_cache: GraphCached[OrderedSet[ScalarFeatureType]] = dataclasses.field(
        init=False, compare=False
    )

    __exclude_from_state__ = (
        "_is_nullable_graph_cache",
        "_underlying_graph_cache",
        "_join_path_keys_graph_cache",
        "_graph",
    )

    @property
    def is_schema_feature_type(self) -> bool:
        return self.underlying.is_schema_feature_type

    @property
    def is_value_schema_feature_type(self) -> bool:
        return self.underlying.is_value_schema_feature_type

    def __post_init__(self, underlying_ref: _CompatibleWithNestedFeatureTypeMixin | str):
        if isinstance(underlying_ref, str):
            underlying_fqn = underlying_ref
        else:
            underlying_fqn = underlying_ref.fqn
            underlying_ref = underlying_ref if isinstance(underlying_ref, HasManyFeatureType) else underlying_fqn
        object.__setattr__(self, "_underlying_ref", underlying_ref)
        parent_namespace = self.path[0].parent_fqn.split(".")[0]
        root_prefix = parent_namespace + "." + ".".join(x.parent_fqn.split(".")[1] for x in self.path)
        namespace, name = underlying_fqn.split(".")
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "namespace", namespace)
        object.__setattr__(self, "root_prefix", root_prefix)
        object.__setattr__(self, "root_namespace", parent_namespace)
        object.__setattr__(self, "root_fqn", f"{self.root_prefix}.{self.name}")
        object.__setattr__(self, "fqn", f"{self.namespace}.{self.name}")

    def __getstate__(self):
        return FeatureType.__getstate__(self)

    def __setstate__(self, state: tuple[Any, ...]):
        NamedFeatureType.__setstate__(self, state)

    @property
    def is_feature_nullable(self) -> bool:
        """
        for `a.b.c.d`, if any of `a.b`, `b.c`, or `c.d` are nullable, we consider the whole chain nullable.
        """
        if not hasattr(self, "_is_nullable_graph_cache"):
            object.__setattr__(
                self,
                "_is_nullable_graph_cache",
                self.graph.graph_cached(self._get_is_nullable),
            )
        return self._is_nullable_graph_cache()

    def _get_underlying(self):
        if isinstance(self._underlying_ref, str):
            ans = unwrap_optional(self.graph.feature_from_fqn(self._underlying_ref))
            assert isinstance(
                ans,
                (
                    ScalarFeatureType,
                    HasOneFeatureType,
                    FeatureTimeFeatureType,
                    WindowedFeatureType,
                ),
            )
            return ans
        else:
            assert isinstance(self._underlying_ref, HasManyFeatureType)
            return self._underlying_ref

    def _get_is_nullable(self):
        for step in self.walk_all_steps():
            if isinstance(step, (ScalarFeatureType, HasOneFeatureType)) and step.is_feature_nullable:
                return True
        return False

    def walk_path_joins(self) -> Iterable[HasOneFeatureType | HasManyFeatureType]:
        for x in self.path:
            yield x.parent

    def walk_all_steps(self) -> Iterable[FeatureType]:
        yield from self.walk_path_joins()
        yield self.underlying

    @property
    def underlying(self) -> _InputT_co:
        if not hasattr(self, "_underlying_graph_cache"):
            object.__setattr__(
                self,
                "_underlying_graph_cache",
                self.graph.graph_cached(self._get_underlying),
            )
        return self._underlying_graph_cache()

    @property
    def join_path_keys(self) -> OrderedSet[ScalarFeatureType]:
        if not hasattr(self, "_join_path_keys_graph_cache"):
            object.__setattr__(
                self,
                "_join_path_keys_graph_cache",
                self.graph.graph_cached(self._get_join_path_keys),
            )
        return self._join_path_keys_graph_cache()

    def _get_join_path_keys(self) -> OrderedSet["ScalarFeatureType"]:
        ret: OrderedSet[ScalarFeatureType] = OrderedSet()
        for p in self.path:
            ret.update(x for x in p.parent.join.all_referenced_features() if isinstance(x, ScalarFeatureType))
        return ret

    @property
    def max_staleness(self) -> timedelta:
        if isinstance(self.underlying, ScalarFeatureType):
            return self.underlying.max_staleness
        raise RuntimeError("Max staleness is not applicable")

    def starts_with(self, prefix: HasOneFeatureType):
        """If this is a.b.c.d.e.f, true if prefix is a.b"""
        return self.path[0].parent == prefix

    def pop_prefix(self) -> _InputT_co | NestedFeatureType[_InputT_co]:
        """X.y.z => Y.z"""
        if len(self.path) == 1:
            return self.underlying
        return NestedFeatureType(
            underlying_ref=self._underlying_ref,
            path=self.path[1:],
            _graph=self.graph,
        )

    @overload
    @staticmethod
    def replace_suffix(
        original_feature: FeatureType, new_suffix_feature: ScalarFeatureType
    ) -> ScalarFeatureType | NestedFeatureType[ScalarFeatureType]: ...

    @overload
    @staticmethod
    def replace_suffix(
        original_feature: FeatureType, new_suffix_feature: FeatureTimeFeatureType
    ) -> FeatureTimeFeatureType | NestedFeatureType[FeatureTimeFeatureType]: ...

    @overload
    @staticmethod
    def replace_suffix(
        original_feature: NestedFeatureType, new_suffix_feature: HasManyFeatureType
    ) -> NestedFeatureType[HasManyFeatureType]: ...

    @overload
    @staticmethod
    def replace_suffix(
        original_feature: FeatureType, new_suffix_feature: HasManyFeatureType
    ) -> HasManyFeatureType | NestedFeatureType[HasManyFeatureType]: ...

    @staticmethod
    def replace_suffix(
        original_feature: FeatureType,
        new_suffix_feature: (ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType),
    ) -> (
        ScalarFeatureType
        | FeatureTimeFeatureType
        | HasManyFeatureType
        | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
    ):
        """X.y.a, Y.z => X.y.z"""
        if not isinstance(original_feature, NestedFeatureType):
            return new_suffix_feature
        return NestedFeatureType(
            underlying_ref=new_suffix_feature,
            _graph=original_feature.graph,
            path=original_feature.path[:-1]
            + (HasOnePathObjParsed(parent=original_feature.path[-1].parent, child=new_suffix_feature),),
        )

    def pop_suffix(
        self,
    ) -> HasOneFeatureType | HasManyFeatureType | NestedFeatureType[HasOneFeatureType | HasManyFeatureType]:
        if len(self.path) == 1:
            return self.path[0].parent
        return NestedFeatureType(
            underlying_ref=self.path[-1].parent,
            _graph=self.graph,
            path=self.path[:-1],
        )

    def flatten(
        self,
    ) -> list["NestedFeatureType[FeatureTimeFeatureType | ScalarFeatureType | HasManyFeatureType]"]:
        if is_nested_feature_time(self) or is_nested_scalar(self) or is_underlying_has_many(self):
            assert isinstance(self, NestedFeatureType)
            return [self]
        if isinstance(self.underlying, HasOneFeatureType):
            return [
                NestedFeatureType(
                    underlying_ref=x.underlying,
                    _graph=self.graph,
                    path=(*self.path, *x.path),
                )
                for x in self.underlying.flatten()
            ]
        raise TypeError(
            f"Feature {self} cannot be flattened, as the underlying is not a Scalar, FeatureTime, or a Has-One."
        )

    def split_at_first(
        self,
    ) -> tuple[HasOneFeatureType | HasManyFeatureType, _InputT_co | NestedFeatureType[_InputT_co]]:
        """
        Splits the `NestedFeatureType` `A.b.c.d` into `(A.b, B.c.d)`.
        This is the reverse of `NestedFeatureType.join_at_first`.
        """
        return (self.path[0].parent, self.pop_prefix())

    @staticmethod
    def join_at_first(
        prefix: HasOneFeatureType | HasManyFeatureType,
        suffix: _InputT | NestedFeatureType[_InputT],
    ) -> NestedFeatureType[_InputT]:
        """
        Joins two features into an `NestedFeatureType`.
        Given `(A.b, B.c.d)` makes `A.b.c.d`.


        This is the reverse of `NestedFeatureType.split_at_first`.
        """

        if get_alias_prefix_from_str(suffix.root_namespace) is not None:
            raise ValueError(
                f"Cannot push a namespaced underlying feature '{suffix}' onto a has-one/has-many relationship '{prefix}'"
            )

        prefix_match_namespace = prefix.foreign_namespace()
        suffix_match_namespace = suffix.root_namespace
        if alias_prefix := get_alias_prefix_from_str(prefix_match_namespace):
            # When considering matching, we ignore alias prefixes.
            prefix_match_namespace = remove_alias_prefix_from_str(
                prefix_match_namespace,
                alias_prefix=alias_prefix,
            )

        if prefix_match_namespace != suffix_match_namespace:
            raise ValueError(
                f"The features '{prefix.root_fqn}' and '{suffix.root_fqn}' cannot be joined together into a chained feature, because their inner namespaces '{prefix_match_namespace}' and '{suffix_match_namespace}' do not match"
            )

        if isinstance(suffix, NestedFeatureType):
            return NestedFeatureType(
                underlying_ref=suffix.underlying,
                _graph=prefix.graph,
                path=(
                    HasOnePathObjParsed(parent=prefix, child=suffix.path[0].parent),
                    *suffix.path,
                ),
            )
        assert isinstance(
            suffix,
            (
                ScalarFeatureType,
                HasManyFeatureType,
                HasOneFeatureType,
                WindowedFeatureType,
                FeatureTimeFeatureType,
            ),
        )
        return NestedFeatureType(
            underlying_ref=suffix,
            _graph=prefix.graph,
            path=(HasOnePathObjParsed(parent=prefix, child=suffix),),
        )

    @staticmethod
    def join_from_parts(
        prefix: HasOneFeatureType | HasManyFeatureType | NestedFeatureType[HasOneFeatureType | HasManyFeatureType],
        suffix: _InputT | NestedFeatureType[_InputT],
    ) -> NestedFeatureType[_InputT]:
        """
        Joins two features into a single chained feature:
        (A.b, B.c) --> (A.b.c)
        (A.b.c.d, D.e.f.g) -> (A.b.c.d.e.f.g)
        (A.b, B.c.d.e) -> (A.b.c.d.e)

        If the features do not have a matching "inner" namespace, a `ValueError` will be raised.

        You can split up a joined NestedFeatureType using `.split_at_first()` or `.split_at_last()`.
        """
        if isinstance(prefix, NestedFeatureType):
            prefix_start, prefix_end = prefix.split_at_first()
            return NestedFeatureType.join_at_first(
                prefix=prefix_start,
                suffix=NestedFeatureType.join_from_parts(
                    prefix=prefix_end,
                    suffix=suffix,
                ),
            )
        else:
            return NestedFeatureType.join_at_first(prefix, suffix)

    @staticmethod
    def join_at_last(
        prefix: HasOneFeatureType | HasManyFeatureType | NestedFeatureType[HasOneFeatureType | HasManyFeatureType],
        suffix: _InputT,
    ) -> NestedFeatureType[_InputT]:
        """
        This is the reverse of `NestedFeatureType.split_at_last()`.
        """
        return NestedFeatureType.join_from_parts(prefix=prefix, suffix=suffix)

    def split_at_last(
        self,
    ) -> tuple[
        HasOneFeatureType | HasManyFeatureType | NestedFeatureType[HasOneFeatureType | HasManyFeatureType], _InputT_co
    ]:
        """
        Splits a chained has_one feature like `A.b.c.d` into `(A.b.c, C.d)`.

        This is the reverse of `NestedFeatureType.join_at_last(...)`.
        """
        return (self.pop_suffix(), self.underlying)

    def relative_to(
        self,
        base: (NestedFeatureType[HasManyFeatureType | HasOneFeatureType] | HasManyFeatureType | HasOneFeatureType),
    ) -> _InputT_co | NestedFeatureType[_InputT_co]:
        """X.y.z, X.y => Y.z"""
        path: tuple[HasOnePathObjParsed, ...] = base.path if isinstance(base, NestedFeatureType) else ()
        assert path == self.path[: len(path)]
        assert self.path[len(path)].parent == base.underlying
        if len(self.path) == len(path) + 1:
            return self.underlying
        return NestedFeatureType(
            path=self.path[len(path) + 1 :],
            _graph=self.graph,
            underlying_ref=self.underlying,
        )

    @staticmethod
    def absolute_to(
        relative: _InputT_co | NestedFeatureType[_InputT_co],
        base: (NestedFeatureType[HasManyFeatureType | HasOneFeatureType] | HasManyFeatureType | HasOneFeatureType),
    ) -> NestedFeatureType[_InputT_co]:
        """Y.z, X.y => X.y.z"""
        path: tuple[HasOnePathObjParsed, ...] = base.path if isinstance(base, NestedFeatureType) else ()
        assert isinstance(base.underlying, (HasManyFeatureType, HasOneFeatureType))
        if isinstance(relative, NestedFeatureType):
            return NestedFeatureType(
                path=path
                + (
                    HasOnePathObjParsed(
                        parent=base.underlying,
                        child=relative.path[0].parent,
                    ),
                )
                + relative.path,
                underlying_ref=relative.underlying,
                _graph=relative.graph,
            )
        else:
            assert isinstance(
                relative,
                (
                    ScalarFeatureType,
                    FeatureTimeFeatureType,
                    HasManyFeatureType,
                    HasOneFeatureType,
                    WindowedFeatureType,
                ),
            )
            return NestedFeatureType(
                path=path
                + (
                    HasOnePathObjParsed(
                        parent=base.underlying,
                        child=relative,
                    ),
                ),
                underlying_ref=relative,
                _graph=base.graph,
            )

    def copy_with_renamed_fqn(
        self,
        new_fqn: str,
    ) -> "NestedFeatureType[_InputT_co]":
        """
        Returns a copy of this feature with the provided new fqn.
        """
        new_instance = dataclasses.replace(self)
        object.__setattr__(new_instance, "root_fqn", new_fqn)
        return new_instance

    def copy_with_root_alias(self, root_alias: AliasPrefix) -> "NestedFeatureType[_InputT_co]":
        """
        Copies a feature like `a.b.c` into the alias-prefixed version `prefix:a.b.c`.
        """
        prefix, suffix = self.split_at_first()
        return NestedFeatureType.join_at_first(
            prefix.copy_with_root_alias(
                root_alias=root_alias,
            ),
            suffix,
        )

    def copy_without_root_alias(
        self,
        root_alias: AliasPrefix,
        *,
        allow_unaliased: bool,
    ) -> "NestedFeatureType[_InputT_co]":
        """
        Copies an alias-prefixed feature like `prefix:a.b.c` into the unprefixed `a.b.c`.
        """
        prefix, suffix = self.split_at_first()
        return NestedFeatureType.join_at_first(
            prefix.copy_without_root_alias(
                root_alias=root_alias,
                allow_unaliased=allow_unaliased,
            ),
            cast(
                Any,
                suffix.copy_without_root_alias(
                    root_alias=root_alias,
                    allow_unaliased=allow_unaliased,
                ),
            ),
        )


InputFeatureType = NestedFeatureType
"""
`NestedFeatureType` used to be called `InputFeatureType`.
This is a deprecated, legacy alias.
"""

UnderlyingFeatureType = _InputT_co | NestedFeatureType[_InputT_co]

_TIMESTAMP_PRIMITIVE_CONVERTER = PrimitiveFeatureConverter(
    "__chalk__.ts", is_nullable=False, pyarrow_dtype=pa.timestamp("us", "UTC")
)


@dataclasses.dataclass(frozen=True, repr=False, slots=True)
class FeatureTimeFeatureType(_CompatibleWithNestedFeatureTypeMixin, NamedFeatureType, FeatureType):
    autogenerated: bool

    __exclude_from_state__ = ("_graph",)

    def __hash__(self):
        return hash(self.root_fqn)

    def __getstate__(self):
        return FeatureType.__getstate__(self)

    def __setstate__(self, state: tuple[Any, ...]):
        NamedFeatureType.__setstate__(self, state)

    @property
    def underlying(self):
        """Helper method to match NestedFeatureType.underlying"""
        return self

    def flatten(self):
        return [self]

    @property
    def pyarrow_dtype(self) -> pa.DataType:
        return _TIMESTAMP_PRIMITIVE_CONVERTER.pyarrow_dtype

    @property
    def polars_dtype(self) -> CompatPlDataType:
        return _TIMESTAMP_PRIMITIVE_CONVERTER.polars_dtype  # pyright: ignore[reportReturnType]

    @property
    def primitive_converter(self) -> PrimitiveFeatureConverter[datetime, datetime]:
        return _TIMESTAMP_PRIMITIVE_CONVERTER

    def copy_with_root_alias(self, root_alias: AliasPrefix) -> "FeatureTimeFeatureType":
        """
        Returns a copy of this feature with the specified root alias.
        For example, `user.ts` becomes `prefix:user.ts`.
        """
        return dataclasses.replace(
            self,
            namespace=add_alias_prefix_to_str(self.namespace, alias_prefix=root_alias),
        )

    def copy_without_root_alias(
        self,
        root_alias: AliasPrefix,
        *,
        allow_unaliased: bool,
    ) -> "FeatureTimeFeatureType":
        existing_alias = get_alias_prefix_from_str(self.namespace)
        if existing_alias != root_alias:
            if allow_unaliased:
                return self
            raise ValueError(
                f"Cannot remove alias '{root_alias}' from feature '{self.root_fqn}' which does not have that alias"
            )

        return dataclasses.replace(
            self,
            namespace=remove_alias_prefix_from_str(
                self.namespace,
                alias_prefix=root_alias,
                raise_if_not_aliased=not allow_unaliased,
            ),
        )

    @property
    def is_value_schema_feature_type(self) -> bool:
        return False

    @property
    def is_schema_feature_type(self) -> bool:
        return True

    @property
    def is_feature_nullable(self) -> bool:
        return False


@dataclasses.dataclass(frozen=True, slots=True)
class FeatureValidationsParsed:
    min: int | float | None
    max: int | float | None
    min_length: int | None
    max_length: int | None
    contains: ellipsis
    strict: bool


@dataclasses.dataclass(frozen=True)
class VersionInfoParsed:
    default: int
    maximum: int


@dataclasses.dataclass(frozen=True, slots=True)
class WindowConfig:
    window_duration: timedelta
    materialization_config: MaterializationWindowConfigParsed | None

    def __init__(  # type: ignore[reportMissingSuperCall]
        self,
        window_duration: timedelta,
        materialization_config: MaterializationWindowConfigParsed | None = None,
    ) -> None:
        object.__setattr__(self, "window_duration", window_duration)
        object.__setattr__(self, "materialization_config", materialization_config)

    def __lt__(self, other: WindowConfig) -> bool:
        return self.window_duration < other.window_duration


def _to_old_style_type(origin: object):
    if origin is list:
        return List
    elif origin is tuple:
        return Tuple
    elif origin is set:
        return Set
    elif origin is frozenset:
        return FrozenSet
    elif origin is dict:
        return Dict
    elif origin is type(int | None):
        return Union
    return origin


def canonicalize_typ(x: object):
    """Canonicalize a type annotation for equality checking.
    New-style types are replaced with old-style types, and
    annotated markers are ignored. Specifically:

    - typing.Annotated -> unwrapped
    - list             -> typing.List
    - tuple            -> typing.Tuple
    - set              -> typing.Set
    - frozenset        -> typing.Frozenset
    - dict             -> typing.Dict
    - union            -> typing.Union
    """

    if x is None:
        x = type(None)
    x = unwrap_annotated_if_needed(x)
    origin, args = get_origin(x), get_args(x)
    if origin is None:
        return _to_old_style_type(x)
    origin = _to_old_style_type(origin)
    args = tuple(canonicalize_typ(x) for x in args)
    return origin[args]  # type: ignore -- pyright doesn't understand metaprogramming


@dataclasses.dataclass(frozen=True, slots=True)
class RichConverterInfo:
    has_nontrivial_rich_type: bool
    rich_type: SerializedRichType | None = None
    rich_type_name: str | None = None

    @classmethod
    def from_converter(cls, conv: FeatureConverter):
        if conv.rich_type is None:  # pyright: ignore[reportUnnecessaryComparison]
            return cls(
                has_nontrivial_rich_type=conv.has_nontrivial_rich_type(),
                rich_type=None,
                rich_type_name=None,
            )
        return cls(
            has_nontrivial_rich_type=conv.has_nontrivial_rich_type(),
            rich_type=SerializedRichType.from_typ(conv.rich_type),
            rich_type_name=str(conv.rich_type),
        )


@dataclasses.dataclass(frozen=True, repr=False, slots=True)
class ScalarFeatureType(_CompatibleWithNestedFeatureTypeMixin, NamedFeatureType, FeatureType):
    __exclude_from_state__ = ("_graph",)

    # Excluding the converter from the comparison as it does not
    # implement hash/eq -- and it would use an identity-based comparison.
    # Default values may not be hashable (i.e. structs)
    autogenerated: bool
    is_windowed_pseudofeature: bool = dataclasses.field(repr=False)
    is_distance_pseudofeature: bool = dataclasses.field(repr=False)
    is_windowed: bool = dataclasses.field(repr=False)
    is_scalar_feature_nullable: bool = dataclasses.field(repr=False)

    @property
    def display_name(self) -> str:
        if self.window_config is None:
            return self.root_fqn
        return f"{self.window_stem_root_fqn}[{timedelta_to_duration(self.window_config.window_duration)}]"

    @property
    def is_feature_nullable(self) -> bool:
        return self.is_scalar_feature_nullable

    converter: dataclasses.InitVar[FeatureConverter[Any, Any]]
    primitive_converter: PrimitiveFeatureConverter[Any, Any] = dataclasses.field(repr=False, compare=False, init=False)
    rich_type_info: RichConverterInfo = dataclasses.field(repr=False, compare=False)
    primary: bool = dataclasses.field(default=False)
    description: str | None = dataclasses.field(default=None, repr=False)
    owner: str | None = dataclasses.field(default=None, repr=False)
    tags: FrozenOrderedSet[str] = dataclasses.field(repr=False, default_factory=FrozenOrderedSet)
    max_staleness: timedelta = dataclasses.field(default=timedelta(0), repr=False)
    """The default read-staleness for this feature. This value should _not_ be used
    to determine whether or not to write to the online store. Instead, use
    `write_max_staleness`."""

    minimum_write_max_staleness: timedelta = dataclasses.field(default=timedelta(0), repr=False)
    """
    WARNING: DO NOT READ THIS FIELD DIRECTLY; instead, see `graph.get_write_max_staleness(feature)`


    To support Advanced™ features, we split configuration for when to read
    from the online store by default (`max_staleness`) from the configuration
    for when to write to the online store (`write_max_staleness`).

    Usually, you want `max_staleness` == `write_max_staleness`, but there are
    two times right now where you want `write_max_staleness` to greater than
    `max_staleness`:

        1. Caching relationships, where the read staleness depends on the path by
        which a feature is requested. For example:

           >>> x: MyClass = has_many(..., max_staleness=timedelta(days=1))

        2. Using `Last[...]`, where we cache `MyClass.xyz`, but don't want to read
        that feature from the cache unless it's as `Last[...]`. When `Last[ABC.xyz]`
        is spotted in any resolver, `ABC.xyz` is given `write_max_staleness=timedelta.max`
        and `max_staleness` is typically set to 0.

           >>> @online
           ... def fn(x: Last[MyClass.xyz]) -> ...:

    This field here is the MINIMUM write max staleness.
    """

    cache_strategy: CacheStrategy = dataclasses.field(default=CacheStrategy.ALL, repr=False)
    store_online: bool = dataclasses.field(default=True, repr=False)
    store_offline: bool = dataclasses.field(default=True, repr=False)
    offline_ttl: timedelta = dataclasses.field(default=timedelta(0), repr=False)
    etl_offline_to_online: bool = dataclasses.field(default=False, repr=False)
    # Excluding the validations from the hash, as the "in" condition may contain unhashable values
    validations: tuple[FeatureValidationsParsed, ...] | None = dataclasses.field(default=None, hash=False, repr=False)

    window_config: WindowConfig | None = dataclasses.field(default=None, repr=False)
    version: VersionInfoParsed | None = dataclasses.field(default=None, repr=False)
    last_for_fqn: str | None = dataclasses.field(default=None, repr=False)
    """If this feature is a `Last[...]` feature, this field specifies the feature for which it is last

    For example:
       fqn=user.__chalklast__fico_score => last_for=user.fico_score
       fqn=user.fico_score              => last_for=None
    """
    is_singleton: bool = dataclasses.field(default=False, repr=False)

    is_deprecated: bool = dataclasses.field(repr=False, default=False)
    """Whether the user has marked this feature as deprecated."""

    # CHA-4871: Comparison here needs to be made correct
    underscore_expression: Underscore | None = dataclasses.field(default=None, repr=False)
    offline_underscore_expression: Underscore | None = dataclasses.field(default=None, repr=False)

    @property
    def last_for(self) -> ScalarFeatureType | None:
        if self.last_for_fqn is None:
            return None
        last_for = unwrap_optional(self.graph.feature_from_fqn(self.last_for_fqn))
        assert isinstance(last_for, ScalarFeatureType)
        return last_for

    @property
    def underlying(self) -> ScalarFeatureType:
        """Helper method to match `NestedFeatureType.underlying`"""
        return self

    @property
    def window_stem_root_fqn(self) -> str:
        if not self.is_windowed_pseudofeature:
            return self.root_fqn
        return re.sub(r"__\d+__$", "", self.root_fqn)

    @property
    def window_stem(self) -> str:
        if not self.is_windowed_pseudofeature:
            return self.name
        return re.sub(r"__\d+__$", "", self.name)

    def flatten(self) -> tuple[ScalarFeatureType]:
        return (self,)

    def __hash__(self):
        return hash(self.root_fqn)

    def __getstate__(self):
        return FeatureType.__getstate__(self)

    def __setstate__(self, state: tuple[Any, ...]):
        NamedFeatureType.__setstate__(self, state)

    def __post_init__(self, converter: FeatureConverter[Any, Any]):
        NamedFeatureType.__post_init__(self)
        # Constructing a new primitive converter, because the Rich converter subclasses the primitive converter,
        # and that is not pickleable
        object.__setattr__(
            self,
            "primitive_converter",
            PrimitiveFeatureConverter(
                name=self.fqn,
                is_nullable=converter.is_nullable,
                primitive_default=(converter.primitive_default if converter.has_default else ...),
                pyarrow_dtype=converter.pyarrow_dtype,
            ),
        )

    @property
    def pyarrow_dtype(self) -> pa.DataType:
        return self.primitive_converter.pyarrow_dtype

    @property
    def polars_dtype(self) -> CompatPlDataType:
        return self.primitive_converter.polars_dtype  # pyright: ignore[reportReturnType]

    def copy_with_root_alias(
        self,
        root_alias: AliasPrefix,
    ) -> "ScalarFeatureType":
        """
        Returns a copy of this feature with the provided alias prefix.
        For example, `user.is_active` becomes `prefix:user.is_active`.
        """
        return dataclasses.replace(
            self,
            namespace=add_alias_prefix_to_str(self.namespace, alias_prefix=root_alias),
            converter=self.primitive_converter,
            last_for_fqn=add_alias_prefix_to_str(self.namespace, alias_prefix=root_alias)
            if self.last_for_fqn is not None
            else None,
        )

    def copy_with_renamed_fqn(
        self,
        new_fqn: str,
    ) -> "ScalarFeatureType":
        """
        Returns a copy of this feature with the provided new fqn.
        """
        new_instance = dataclasses.replace(self, converter=self.primitive_converter)
        object.__setattr__(new_instance, "root_fqn", new_fqn)
        return new_instance

    def copy_without_root_alias(
        self,
        root_alias: AliasPrefix,
        *,
        allow_unaliased: bool,
    ) -> "ScalarFeatureType":
        """
        Returns a copy of this ScalarFeatureType with the specified alias removed.
        Raises an error if it doesn't have the specified alias, unless `allow_unaliased=True`,
        in which case it returns `self` unchanged.
        """
        existing_alias = get_alias_prefix_from_str(self.namespace)
        if existing_alias != root_alias:
            if allow_unaliased:
                return self
            raise ValueError(
                f"Cannot remove alias '{root_alias}' from feature '{self.root_fqn}' which does not have that alias",
            )

        if self.last_for_fqn is not None:
            raise ValueError(f"Cannot remove alias '{root_alias}' from Last[...] feature '{self.root_fqn}'")

        return dataclasses.replace(
            self,
            namespace=remove_alias_prefix_from_str(
                self.namespace,
                alias_prefix=root_alias,
                raise_if_not_aliased=not allow_unaliased,
            ),
            converter=self.primitive_converter,
        )

    @property
    def is_value_schema_feature_type(self) -> bool:
        return True

    @property
    def is_schema_feature_type(self) -> bool:
        return True

    @property
    def skip_persistence(self) -> bool:
        return self.store_offline is False and self.store_online is False


@dataclasses.dataclass(frozen=True, repr=False, slots=True)
class DetachedColumnFeatureType(FeatureType):
    """A feature-type that has a name but is not registered in the graph.

    (E.g. columns in spine sql queires which do not correspond to Chalk features)

    They align with whatever namespace they appear in.
    In multi-namespace queries, all root namespaces are aligned, so a column from spine can map to multiple namespaces.
    """

    # Not providing name, fqn or root_fqn, because we do fqn.split(".") in many places
    column_name: str
    pyarrow_dtype: pa.DataType
    primary: bool = False

    def __repr__(self):
        return f"anon({self.column_name})"

    @property
    def underlying(self) -> DetachedColumnFeatureType:
        """Helper method to match `NestedFeatureType.underlying`"""
        return self

    @property
    def is_value_schema_feature_type(self) -> bool:
        return False

    @property
    def is_schema_feature_type(self) -> bool:
        return False


@dataclasses.dataclass(frozen=True, repr=False, slots=True)
class OutputUnderscoreFeatureType(FeatureType):
    """
    Simple struct of an output column which should be the result of an expression.
    """

    root_namespace: str | None
    output_name: str
    underscore: Underscore
    primary: bool = False

    def __repr__(self):
        return f"{self.output_name}({self.underscore})"

    @property
    def underlying(self) -> OutputUnderscoreFeatureType:
        return self

    @property
    def is_value_schema_feature_type(self) -> bool:
        return False

    @property
    def is_schema_feature_type(self) -> bool:
        return False


@dataclasses.dataclass(frozen=True, repr=False, slots=True)
class WindowedFeatureType(_CompatibleWithNestedFeatureTypeMixin, NamedFeatureType, FeatureType):
    """A Feature that represents multiple windows.

    Values for this feature ARE NOT PERSISTED in any way, shape, or form.
    Instead, figure out what window you want, and then get the underlying ScalarFeatureType corresponding
    to that window.
    """

    autogenerated: bool
    windows: FrozenOrderedSet[int]
    original_python_attribute_name: str | None = dataclasses.field(default=None, repr=False, init=False, compare=False)
    attribute_name: str | None = dataclasses.field(default=None, repr=False, init=False, compare=False)
    _primitive_converter_graph_cached: GraphCached[PrimitiveFeatureConverter[Any, Any]] = dataclasses.field(
        repr=False, compare=False, init=False
    )

    __exclude_from_state__ = ("_graph", "_primitive_converter_graph_cached")

    def __post_init__(self):
        NamedFeatureType.__post_init__(self)
        # Constructing a new primitive converter, because the Rich converter subclasses the primitive converter,
        # and that is not pickleable

    def _get_primitive_converter(self):
        from chalk.streams import get_name_with_duration

        example_name = get_name_with_duration(self.fqn, next(iter(self.windows)))
        f = self.graph.fqn_to_feature[example_name]
        assert isinstance(f, ScalarFeatureType)
        return f.primitive_converter

    @property
    def windowed_pseudo_features(self) -> Sequence[ScalarFeatureType]:
        from chalk.streams import get_name_with_duration

        pseudos = []
        for w in self.windows:
            name = get_name_with_duration(self.fqn, w)
            f = self.graph.fqn_to_feature[name]
            assert isinstance(f, ScalarFeatureType)
            pseudos.append(f)
        return pseudos

    @property
    def underlying(self) -> WindowedFeatureType:
        """Helper method to match NestedFeatureType.underlying"""
        return self

    def flatten(self) -> NoReturn:
        raise NotImplementedError("TODO -- need to figure out what it means to flatten a WindowedFeatureType")

    def __getstate__(self):
        return FeatureType.__getstate__(self)

    def __setstate__(self, state: tuple[Any, ...]):
        NamedFeatureType.__setstate__(self, state)

    @property
    def pyarrow_dtype(self) -> pa.DataType:
        return self.primitive_converter.pyarrow_dtype

    @property
    def polars_dtype(self) -> CompatPlDataType:
        return self.primitive_converter.polars_dtype  # pyright: ignore[reportReturnType]

    @property
    def primitive_converter(self) -> PrimitiveFeatureConverter[Any, Any]:
        if not hasattr(self, "_primitive_converter_graph_cached"):
            object.__setattr__(
                self,
                "_primitive_converter_graph_cached",
                self.graph.graph_cached(self._get_primitive_converter),
            )
        return self._primitive_converter_graph_cached()

    def copy_with_root_alias(
        self,
        root_alias: AliasPrefix,
    ) -> "WindowedFeatureType":
        """
        Returns a copy of this feature with the provided alias prefix.
        For example, `user.is_active` becomes `prefix:user.is_active`.
        """
        return dataclasses.replace(
            self,
            converter=self.primitive_converter,
            namespace=add_alias_prefix_to_str(self.namespace, alias_prefix=root_alias),
        )

    def copy_without_root_alias(
        self,
        root_alias: AliasPrefix,
        *,
        allow_unaliased: bool,
    ) -> "WindowedFeatureType":
        """
        Returns a copy of this WindowedFeatureType with the specified alias removed.
        Raises an error if it doesn't have the specified alias, unless `allow_unaliased=True`,
        in which case it returns `self` unchanged.
        """
        existing_alias = get_alias_prefix_from_str(self.namespace)
        if existing_alias != root_alias:
            if allow_unaliased:
                return self
            raise ValueError(
                f"Cannot remove alias '{root_alias}' from feature '{self.root_fqn}' which does not have that alias",
            )

        return dataclasses.replace(
            self,
            namespace=remove_alias_prefix_from_str(
                self.namespace,
                alias_prefix=root_alias,
                raise_if_not_aliased=not allow_unaliased,
            ),
        )

    @property
    def is_value_schema_feature_type(self) -> bool:
        return False

    @property
    def is_schema_feature_type(self) -> bool:
        return False


def is_valid_operation(operation: str) -> TypeGuard[Operation]:
    return _is_valid_operation(operation)


class FeatureFqnMarker:
    def __init__(self, root_fqn: str, graph: ResolvedGraph):
        super().__init__()
        self.root_fqn: Final = root_fqn
        self._graph = graph

    @property
    def graph(self):
        if not hasattr(self, "_graph"):
            object.__setattr__(self, "_graph", get_global_graph())
        return self._graph

    def __getstate__(self):
        return (self.root_fqn,)

    def __setstate__(self, state: tuple[Any, ...]):
        (root_fqn,) = state
        object.__setattr__(self, "root_fqn", root_fqn)

    def __repr__(self):
        return f"FeatureFqnMarker(root_fqn={self.root_fqn!r})"

    def __eq__(self, other: object):
        if not isinstance(other, FeatureFqnMarker):
            return NotImplemented
        return self.root_fqn == other.root_fqn

    def __hash__(self) -> int:
        return hash((self.root_fqn,))

    __slots__ = ("root_fqn", "_graph")


class FilterParsed:
    # Excluding the LHS and RHS from the hash as they may be literal values that cannot be hashed (e.g. a list or unhashable struct)
    # However, they should still be checked on equality tests.
    # This effectively means that filters will be hashed based on the Operation -- not ideal, but there really isn't
    # a reason to use a filter as a hash key.

    # IMPORTANT: The FilterParsed object represents a _python_ filter object. This means, for example, a filter like
    # `x not in ('a', 'b', 'c')` should not be parsed in SQL as-is, but rather should be
    # `x not in ('a', 'b', 'c') OR x IS NULL`

    __slots__ = ("_lhs", "_rhs", "operation", "_all_referenced_features_cache")

    def __init__(
        self,
        lhs: (
            TPrimitive
            | FilterParsed
            | ScalarFeatureType
            | FeatureTimeFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
            | FeatureFqnMarker
        ),
        operation: Operation,
        rhs: (
            TPrimitive
            | FilterParsed
            | ScalarFeatureType
            | FeatureTimeFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
            | FeatureFqnMarker
        ),
    ) -> None:
        super().__init__()
        self.operation: Final = operation
        self._all_referenced_features_cache: (
            FrozenOrderedSet[
                ScalarFeatureType
                | FeatureTimeFeatureType
                | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
            ]
            | None
        ) = None
        if isinstance(lhs, (ScalarFeatureType, FeatureTimeFeatureType)):
            # If a scalar or feature time, then we reference the feature by fqn,
            # so the filter will stay up-to-date even through graph updates
            self._validate_feature_type(lhs)
            self._lhs = FeatureFqnMarker(lhs.root_fqn, graph=lhs.graph)
        else:
            # If an input feature type or not a feature, store it literally
            # Input feature types already reference all path components via fqn,
            # so they will stay up to date
            self._lhs = lhs

        if isinstance(rhs, (ScalarFeatureType, FeatureTimeFeatureType)):
            self._validate_feature_type(rhs)
            self._rhs = FeatureFqnMarker(rhs.root_fqn, graph=rhs.graph)
        else:
            self._rhs = rhs

        if self.operation == "in":
            if not isinstance(self.rhs, collections.abc.Collection):
                raise TypeError("If the operation is 'in', the RHS must be a collection")

    @property
    def lhs(
        self,
    ) -> (
        TPrimitive
        | FilterParsed
        | ScalarFeatureType
        | FeatureTimeFeatureType
        | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    ):
        if isinstance(self._lhs, FeatureFqnMarker):
            maybe_lhs = self._lhs.graph.feature_from_fqn(self._lhs.root_fqn)
            if maybe_lhs is None:
                raise ValueError(f"Feature {self._lhs.root_fqn!r} not found")
            ans = unwrap_optional(maybe_lhs)
            if not isinstance(ans, (ScalarFeatureType, FeatureTimeFeatureType)):
                raise ValueError(
                    f"Feature {self._lhs.root_fqn!r}, is not a scalar or feature time; got {ans!r} for filter {self!r}"
                )
            return ans
        return self._lhs

    @property
    def rhs(
        self,
    ) -> (
        TPrimitive
        | FilterParsed
        | ScalarFeatureType
        | FeatureTimeFeatureType
        | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    ):
        if isinstance(self._rhs, FeatureFqnMarker):
            maybe_feature = self._rhs.graph.feature_from_fqn(self._rhs.root_fqn)
            assert isinstance(maybe_feature, (ScalarFeatureType, FeatureTimeFeatureType)), (
                f"No feature for {self._rhs.root_fqn}, got {maybe_feature}, for filter {self}"
            )
            return maybe_feature
        return self._rhs

    @classmethod
    def from_filters(cls, fs: list[FilterParsed]) -> "FilterParsed | None":
        if len(fs) == 0:
            return None
        if len(fs) == 1:
            return fs[0]
        return functools.reduce(lambda a, b: a & b, fs)

    def __eq__(self, other: object):
        if not isinstance(other, FilterParsed):
            return NotImplemented

        def are_equal(my_side: Any, other_side: Any):
            if isinstance(my_side, Sequence) and isinstance(other_side, Sequence):
                return tuple(my_side) == tuple(other_side)
            else:
                return my_side == other_side

        return (
            self.operation == other.operation and are_equal(self._lhs, other._lhs) and are_equal(self._rhs, other._rhs)
        )

    def __hash__(self) -> int:
        def _hash_side(entry: Any):
            if isinstance(entry, (FilterParsed, str, int, FeatureType, float)):
                return entry
            else:
                return "unhashable"

        return hash((self.operation, _hash_side(self.lhs), _hash_side(self.rhs)))

    def _validate_feature_type(self, f: FeatureType):
        if not is_underlying_scalar(f) and not is_underlying_feature_time(f):
            raise TypeError("FeatureTypes used in filters must be scalarish")

    def __and__(self, other: object):
        if not isinstance(other, FilterParsed):
            return NotImplemented
        return FilterParsed(lhs=self, operation="and", rhs=other)

    def __or__(self, other: object):
        if not isinstance(other, FilterParsed):
            return NotImplemented
        return FilterParsed(lhs=self, operation="or", rhs=other)

    def is_single_key_simple_join(self):
        return (
            isinstance(self.lhs, ScalarFeatureType)
            and isinstance(self.rhs, ScalarFeatureType)
            and self.operation == "=="
        )

    def is_simple_join(self):
        def _is_simple_join(filt: FilterParsed):
            if filt.operation == "and" and isinstance(filt.lhs, FilterParsed) and isinstance(filt.rhs, FilterParsed):
                return _is_simple_join(filt.lhs) and _is_simple_join(filt.rhs)
            return (
                isinstance(filt.lhs, ScalarFeatureType)
                and isinstance(filt.rhs, ScalarFeatureType)
                and filt.operation == "=="
            )

        return _is_simple_join(self)

    def is_simple_nearest_neighbor_join(self):
        """If this filter reprsents a nearest-neighbor join w/o any additional conditions."""
        return self.operation in ("is_near_l2", "is_near_ip", "is_near_cos")

    def all_referenced_features(
        self,
    ) -> FrozenOrderedSet[
        ScalarFeatureType | FeatureTimeFeatureType | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    ]:
        """Get all referenced features, recursively."""
        if self._all_referenced_features_cache is not None:
            return self._all_referenced_features_cache

        ans: OrderedSet[
            ScalarFeatureType | FeatureTimeFeatureType | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
        ] = OrderedSet()
        if isinstance(self.lhs, FeatureType):
            ans.add(self.lhs)
        if isinstance(self.lhs, FilterParsed):
            ans.update(self.lhs.all_referenced_features())
        if isinstance(self.rhs, FeatureType):
            ans.add(self.rhs)
        if isinstance(self.rhs, FilterParsed):
            ans.update(self.rhs.all_referenced_features())

        self._all_referenced_features_cache = FrozenOrderedSet(ans)
        return self._all_referenced_features_cache

    def to_filter(self) -> Filter:
        """Convert a FilterParsed into a Filter"""
        lhs = self.lhs
        if isinstance(lhs, FilterParsed):
            lhs = lhs.to_filter()
        if isinstance(lhs, FeatureType):
            lhs = lhs.to_feature()
        rhs = self.rhs
        if isinstance(rhs, FilterParsed):
            rhs = rhs.to_filter()
        if isinstance(rhs, FeatureType):
            rhs = rhs.to_feature()
        return Filter(
            lhs=lhs,
            operation=self.operation,
            rhs=rhs,
        )

    def pprint(self) -> str:
        lhs = FilterParsed.pprint_side(self.lhs)
        rhs = FilterParsed.pprint_side(self.rhs)
        if self.operation == "not":
            assert self.rhs is None
            return f"not {lhs}"
        return f"{lhs} {self.operation} {rhs}"

    @staticmethod
    def pprint_side(
        side: (
            TPrimitive
            | FilterParsed
            | ScalarFeatureType
            | FeatureTimeFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
        ),
    ) -> str:
        if isinstance(side, FilterParsed):
            return f"({side.pprint()})"
        if is_underlying_feature_time(side) or is_underlying_feature_time(side):
            return side.root_fqn
        return str(side)  # literal value

    def __repr__(self):
        return f"FilterParsed(lhs={self._lhs!r}, operation={self.operation!r}, rhs={self._rhs!r})"


def pprint_filters(filters: Iterable[FilterParsed]) -> str:
    return " and ".join(sorted(x.pprint() for x in filters))


# in a lot of places we allow None as a filter which stands True
GeneralizedFilter = Optional[FilterParsed]


@dataclasses.dataclass(frozen=True, repr=False, slots=True)
class HasOneFeatureType(_CompatibleWithNestedFeatureTypeMixin, NamedFeatureType, FeatureType):
    is_has_one_feature_nullable: bool

    @property
    def is_feature_nullable(self) -> bool:
        return self.is_has_one_feature_nullable

    autogenerated: bool
    """Whether this is an autogenerated has-one (and thus should not be shown to the User)"""

    join: FilterParsed = dataclasses.field(compare=False)
    """The has-one join condition. It is excluded from the comparison, as the fqn is sufficient to verify equality"""

    _primitive_converter_graph_cache: GraphCached[PrimitiveFeatureConverter[Any, Any]] = dataclasses.field(
        init=False, compare=False
    )

    __exclude_from_state__ = (
        "_features_graph_cache",
        "_flatten_graph_cache",
        "_graph",
        "_primitive_converter_graph_cache",
    )

    _features_graph_cache: GraphCached[
        FrozenOrderedSet[
            ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType | HasOneFeatureType | WindowedFeatureType
        ]
    ] = dataclasses.field(init=False, compare=False)
    _flatten_graph_cache: GraphCached[
        FrozenOrderedSet[NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]]
    ] = dataclasses.field(init=False, compare=False)

    def __post_init__(self):
        NamedFeatureType.__post_init__(self)

    def _get_primitive_converter(self) -> PrimitiveFeatureConverter[Any, Any]:
        return PrimitiveFeatureConverter(
            name=self.fqn,
            is_nullable=self.is_feature_nullable,
            pyarrow_dtype=pa.struct({x.root_fqn: x.underlying.pyarrow_dtype for x in self.flatten()}),
        )

    def _get_polars_dtype(self) -> CompatPlDataType:
        return pyarrow_to_polars(self.pyarrow_dtype, self.root_fqn)  # pyright: ignore[reportReturnType]

    @property
    def pyarrow_dtype(self) -> pa.DataType:
        return self.primitive_converter.pyarrow_dtype

    @property
    def primitive_converter(self) -> PrimitiveFeatureConverter[Any, Any]:
        if not hasattr(self, "_primitive_converter_graph_cache"):
            object.__setattr__(
                self,
                "_primitive_converter_graph_cache",
                self.graph.graph_cached(self._get_primitive_converter),
            )
        return self._primitive_converter_graph_cache()

    @property
    def polars_dtype(self) -> CompatPlDataType:
        return self.primitive_converter.polars_dtype  # pyright: ignore[reportReturnType]

    def __hash__(self):
        return hash(self.root_fqn)

    def __getstate__(self):
        return FeatureType.__getstate__(self)

    def __setstate__(self, state: tuple[Any, ...]):
        NamedFeatureType.__setstate__(self, state)

    def only_local_feature(self) -> ScalarFeatureType:
        # this will be replaced once support for multiple join conditions is fully implemented

        referenced_features = [f for f in self.join.all_referenced_features() if isinstance(f, ScalarFeatureType)]
        if alias_prefix := get_alias_prefix_from_str(self.root_namespace):
            # The 'join' is not modified for namespaced features, so instead we need to replace
            # the features we return with the versions that are namespaced.
            referenced_features = FrozenOrderedSet(f.copy_with_root_alias(alias_prefix) for f in referenced_features)

        return get_unique_item(x for x in referenced_features if x.namespace == self.namespace)

    def get_local_join_features(self) -> tuple[ScalarFeatureType, ...]:
        """
        Returns the sequence of features used as the local join key.
        (Note: currently joins are restricted to being a single feature equijoin, but we want
        to generalize this in the future)
        """

        referenced_features = [f for f in self.join.all_referenced_features() if isinstance(f, ScalarFeatureType)]
        if alias_prefix := get_alias_prefix_from_str(self.root_namespace):
            # The 'join' is not modified for namespaced features, so instead we need to replace
            # the features we return with the versions that are namespaced.
            referenced_features = FrozenOrderedSet(f.copy_with_root_alias(alias_prefix) for f in referenced_features)

        if self.join.is_simple_join():
            return tuple(x for x in referenced_features if x.namespace == self.namespace)
        return (get_unique_item(x for x in referenced_features if x.namespace == self.namespace),)

    def only_foreign_feature(self) -> ScalarFeatureType:
        # this will be replaced once support for multiple join conditions is fully implemented

        referenced_features = [f for f in self.join.all_referenced_features() if isinstance(f, ScalarFeatureType)]
        if alias_prefix := get_alias_prefix_from_str(self.root_namespace):
            # The 'join' is not modified for namespaced features, so instead we need to replace
            # the features we return with the versions that are namespaced.
            referenced_features = FrozenOrderedSet(f.copy_with_root_alias(alias_prefix) for f in referenced_features)

        return get_unique_item(x for x in referenced_features if x.namespace != self.namespace)

    def get_foreign_join_features(self) -> tuple[ScalarFeatureType, ...]:
        """
        Returns the sequence of features used as the foreign join key.
        (Note: currently joins are restricted to being a single feature equijoin, but we want
        to generalize this in the future)
        """
        referenced_features = [f for f in self.join.all_referenced_features() if isinstance(f, ScalarFeatureType)]
        if alias_prefix := get_alias_prefix_from_str(self.root_namespace):
            # The 'join' is not modified for namespaced features, so instead we need to replace
            # the features we return with the versions that are namespaced.
            referenced_features = FrozenOrderedSet(f.copy_with_root_alias(alias_prefix) for f in referenced_features)

        if self.join.is_simple_join():
            return tuple(x for x in referenced_features if x.namespace != self.namespace)
        return (get_unique_item(x for x in referenced_features if x.namespace != self.namespace),)

    def foreign_namespace(self) -> str:
        return get_unique_item(set(feat.namespace for feat in self.get_foreign_join_features()))

    def get_nearest_neighbor_join_info(self) -> "NearestNeighborJoinInfo | None":
        return None

    def local_namespace(self) -> str:
        return self.namespace

    @property
    def features(
        self,
    ) -> FrozenOrderedSet[
        ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType | HasOneFeatureType | WindowedFeatureType
    ]:
        """The features of the sub-namespace of the has-one"""
        if not hasattr(self, "_features_graph_cache"):
            object.__setattr__(
                self,
                "_features_graph_cache",
                self.graph.graph_cached(self._get_features),
            )
        return self._features_graph_cache()

    def _get_features(self):
        return FrozenOrderedSet(
            x
            for x in self.graph.features_for_feature_namespace(self.foreign_namespace())
            if isinstance(
                x,
                (
                    ScalarFeatureType,
                    FeatureTimeFeatureType,
                    HasManyFeatureType,
                    HasOneFeatureType,
                    WindowedFeatureType,
                ),
            )
        )

    def _flatten(self):
        # Explode the has-one into a bunch of input feature types
        return FrozenOrderedSet(
            NestedFeatureType(
                underlying_ref=f,
                path=(HasOnePathObjParsed(self, f),),
                _graph=self.graph,
            )
            for f in self.features
            if isinstance(f, ScalarFeatureType | FeatureTimeFeatureType)
        )

    def flatten(
        self,
    ) -> FrozenOrderedSet[NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]]:
        """The expected output features when requesting a has-one relationship"""
        if not hasattr(self, "_flatten_graph_cache"):
            object.__setattr__(self, "_flatten_graph_cache", self.graph.graph_cached(self._flatten))
        return self._flatten_graph_cache()

    @property
    def underlying(self):
        return self

    def copy_with_root_alias(
        self,
        root_alias: AliasPrefix,
    ) -> "HasOneFeatureType":
        """
        Copies this has-one feature with the provided alias prefix.
        For example, `account.owner` becomes `prefix:account.owner`.
        """
        return dataclasses.replace(
            self,
            namespace=add_alias_prefix_to_str(self.namespace, alias_prefix=root_alias),
        )

    def copy_without_root_alias(
        self,
        root_alias: AliasPrefix,
        *,
        allow_unaliased: bool,
    ) -> "HasOneFeatureType":
        existing_alias = get_alias_prefix_from_str(self.namespace)
        if existing_alias != root_alias:
            if allow_unaliased:
                return self
            raise ValueError(
                f"Cannot remove alias '{root_alias}' from feature '{self.root_fqn}' which does not have that alias"
            )

        return dataclasses.replace(
            self,
            namespace=remove_alias_prefix_from_str(
                self.namespace,
                alias_prefix=root_alias,
                raise_if_not_aliased=not allow_unaliased,
            ),
        )

    def is_reverse_of(
        self,
        other: HasOneFeatureType | HasManyFeatureType,
    ):
        """Returns whether this feature shares the same join in the reverse direction as the other feature."""
        # CHA-4857
        self_local = self.get_local_join_features()
        self_foreign = self.get_foreign_join_features()
        other_local = other.get_local_join_features()
        other_foreign = other.get_foreign_join_features()

        if (
            len(self_local) != len(self_foreign)
            or len(self_foreign) != len(other_local)
            or len(other_local) != len(other_foreign)
        ):
            return False
        for sl, sf, ol, of in zip(
            self_local,
            self_foreign,
            other_local,
            other_foreign,
            strict=True,
        ):
            if sf != ol or sl != of:
                return False
        return True

    @property
    def is_value_schema_feature_type(self) -> bool:
        return False

    @property
    def is_schema_feature_type(self) -> bool:
        return False


@dataclasses.dataclass(frozen=True, repr=False, slots=True)
class DataFrameType(FeatureType):
    # DataFrameTypes must be rooted in a features cls, but they may contain multiple features, including has-ones
    # As such, they have no name, namespace, or root_prefix, though they do have a root namespace
    root_namespace: str = dataclasses.field(init=False)
    limit: int | None
    """The limit from the slice expression of the DataFrame -- i.e. DataFrame[Transactions, :10]"""
    filter: FilterParsed | None

    required_column_refs: dataclasses.InitVar[
        FrozenOrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
            | str
        ]
    ]
    """The required columns for a dataframe. Can be feature types, or a string to represent the entire namespace."""

    _required_column_refs: FrozenOrderedSet[
        str
        | HasManyFeatureType
        | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
    ] = dataclasses.field(init=False, hash=False)
    """The stored representation of the required columns. Strings are used to represent terminal features (scalars, feature time, and windowed); input feature types
    and has-many are referenced by feature, as internally they already represent the underlying feature by fqn, and we don't want to lose the column names or join conditions.

    Excluding this field from the hash due to the custom equality logic.
    """

    optional_column_refs: dataclasses.InitVar[
        FrozenOrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
            | str
        ]
    ]
    """The optional columns for a dataframe. Can be feature types, or a string to represent the entire namespace."""

    _optional_column_refs: FrozenOrderedSet[
        str
        | HasManyFeatureType
        | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
    ] = dataclasses.field(init=False, hash=False)
    """The stored representation of the required columns. Strings are used to represent terminal features (scalars, feature time, and windowed); input feature types
    and has-many are referenced by feature, as internally they already represent the underlying feature by fqn, and we don't want to lose the column names or join conditions.

    Excluding this field from the hash due to the custom equality logic.
    """

    def __eq__(self, other: object):
        if not isinstance(other, DataFrameType):
            return NotImplemented
        # FIXME: This is a bit of a hack, but we consider DataFrameFeatures as equal if their effective columns are the same
        # That is, if one Dataframe references an entire namespace, and another references each column in the namespace,
        # we will consider them as equal, even though their internal representations differ
        # Generally speaking, this does not cause an issue, because we should discard any cached objects when the graph changes
        if (
            self.root_namespace != other.root_namespace
            or self.limit != other.limit
            or self.filter != other.filter
            or self.filter_expression != other.filter_expression
        ):
            return False

        are_required_equal = (
            self._required_column_refs == other._required_column_refs or self.required_columns == other.required_columns
        )
        if not are_required_equal:
            return False
        return (
            self._optional_column_refs == other._optional_column_refs or self.optional_columns == other.optional_columns
        )

    _graph: ResolvedGraph = dataclasses.field(compare=False)

    filter_expression: "FilterExpressionParsed | None" = None

    _required_columns_graph_cache: GraphCached[
        FrozenOrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
        ]
    ] = dataclasses.field(init=False, compare=False)

    _optional_columns_graph_cache: GraphCached[
        FrozenOrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
        ]
    ] = dataclasses.field(init=False, compare=False)

    _columns_graph_cached: GraphCached[
        FrozenOrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
        ]
    ] = dataclasses.field(init=False, compare=False)

    _all_referenced_features_graph_cached: GraphCached[
        OrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
        ]
    ] = dataclasses.field(init=False, compare=False)
    _feature_graph_cached: GraphCached[type[DataFrame]] = dataclasses.field(init=False, compare=False)

    __exclude_from_state__ = (
        "_required_columns_graph_cache",
        "_optional_columns_graph_cache",
        "_columns_graph_cached",
        "_all_referenced_features_graph_cached",
        "_feature_graph_cached",
        "_graph",
    )

    @property
    def required_columns(
        self,
    ) -> FrozenOrderedSet[
        ScalarFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | HasManyFeatureType
        | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
    ]:
        """All required columns. In a materialized DataFrame, all of these columns will never be null for missing rows -- instead,
        missing rows would have already been dropped. Null may still be returned if it is a true null, and not missing.
        """
        if not hasattr(self, "_required_columns_graph_cache"):
            object.__setattr__(
                self,
                "_required_columns_graph_cache",
                self.graph.graph_cached(lambda: self._get_columns(self._required_column_refs)),
            )
        return self._required_columns_graph_cache()

    @property
    def is_value_schema_feature_type(self) -> bool:
        return True

    @property
    def is_schema_feature_type(self) -> bool:
        return True

    @property
    def optional_columns(
        self,
    ) -> FrozenOrderedSet[
        ScalarFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | HasManyFeatureType
        | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
    ]:
        """All of the optional columns. In a materialized DataFrame, these columns may be null if the feature is null or missing."""
        if not hasattr(self, "_optional_columns_graph_cache"):
            object.__setattr__(
                self,
                "_optional_columns_graph_cache",
                self.graph.graph_cached(lambda: self._get_columns(self._optional_column_refs)),
            )
        return self._optional_columns_graph_cache()

    @property
    def columns(
        self,
    ) -> FrozenOrderedSet[
        ScalarFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | HasManyFeatureType
        | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
    ]:
        """All the feature columns that the materialized DataFrame will return."""
        if not hasattr(self, "_columns_graph_cached"):
            object.__setattr__(
                self,
                "_columns_graph_cached",
                self.graph.graph_cached(lambda: self.required_columns | self.optional_columns),
            )
        return self._columns_graph_cached()

    def __post_init__(
        self,
        required_column_refs: FrozenOrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
            | str
        ],
        optional_column_refs: FrozenOrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
            | str
        ],
    ):
        # Validate there is one root namespace for all columns
        root_namespaces: list[str] = []

        # We need to convert the input args into how we will actually want to store the columns
        # We store non-nested scalars, windowed, and feature time by fqn. Everything else is stored as a feature, since internally,
        # they reference other features by fqn and we don't want to loose the columns / filters / etc...
        parsed_required_column_refs: OrderedSet[
            str
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
        ] = OrderedSet()

        parsed_optional_column_refs: OrderedSet[
            str
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
        ] = OrderedSet()

        for inputs, parsed_inputs in (
            (required_column_refs, parsed_required_column_refs),
            (optional_column_refs, parsed_optional_column_refs),
        ):
            for x in inputs:
                if isinstance(x, str):
                    if "." in x:
                        raise ValueError(
                            f"Root fqn '{x}' was passed into the DataFrameType Constructor. Only root namespaces, not root fqns, should be passed as strings"
                        )
                    root_ns = x
                    parsed_inputs.add(x)
                else:
                    root_ns = x.root_namespace
                    parsed_inputs.add(
                        x.fqn
                        if isinstance(
                            x,
                            (
                                ScalarFeatureType,
                                FeatureTimeFeatureType,
                                WindowedFeatureType,
                            ),
                        )
                        else x
                    )
                if root_ns != PSEUDONAMESPACE:
                    root_namespaces.append(root_ns)

        object.__setattr__(self, "_required_column_refs", FrozenOrderedSet(parsed_required_column_refs))
        object.__setattr__(self, "_optional_column_refs", FrozenOrderedSet(parsed_optional_column_refs))

        object.__setattr__(
            self,
            "root_namespace",
            get_unique_item(root_namespaces),
        )

    def __getstate__(self):
        ans = FeatureType.__getstate__(self)
        return ans

    def __setstate__(self, state: tuple[Any, ...]):
        FeatureType.__setstate__(self, state)

    @property
    def graph(self):
        if not hasattr(self, "_graph"):
            object.__setattr__(self, "_graph", get_global_graph())
        return self._graph

    def _get_columns(
        self,
        ref_list: FrozenOrderedSet[
            str
            | HasManyFeatureType
            | NestedFeatureType[HasManyFeatureType | ScalarFeatureType | WindowedFeatureType | FeatureTimeFeatureType]
        ],
    ):
        ans: list[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
        ] = []
        for x in ref_list:
            if isinstance(x, str):
                if "." not in x:
                    # Special case: References an entire namespace
                    ans.extend(
                        x
                        for x in self.graph.get_features_in_namespace(x)
                        if (is_underlying_feature_time(x) or is_underlying_scalar(x)) and not x.underlying.autogenerated
                    )
                else:
                    f = unwrap_optional(self.graph.feature_from_fqn(x))
                    # Only scalars, feature time, and windowed are represented by string
                    assert isinstance(
                        f,
                        (
                            ScalarFeatureType,
                            FeatureTimeFeatureType,
                            WindowedFeatureType,
                        ),
                    )
                    ans.append(f)
            else:
                assert isinstance(x, (NestedFeatureType, HasManyFeatureType)), (
                    f"Feature {x} is not Input or HasMany. It should have been serialized as a string"
                )
                ans.append(x)
        return FrozenOrderedSet(ans)

    def all_referenced_features(self):
        if not hasattr(self, "_all_referenced_features_graph_cached"):
            object.__setattr__(
                self,
                "_all_referenced_features_graph_cached",
                self.graph.graph_cached(self._get_all_referenced_features),
            )
        return self._all_referenced_features_graph_cached()

    def _get_all_referenced_features(
        self,
    ) -> OrderedSet[
        ScalarFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | NestedFeatureType[
            ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasOneFeatureType | HasManyFeatureType
        ]
    ]:
        ret: OrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasOneFeatureType
            | HasManyFeatureType
            | NestedFeatureType[
                ScalarFeatureType
                | FeatureTimeFeatureType
                | WindowedFeatureType
                | HasOneFeatureType
                | HasManyFeatureType
            ]
        ] = OrderedSet()

        ret.update(self.columns)

        if self.filter_expression is not None:
            ret.update(
                [
                    input
                    for input in self.filter_expression.all_referenced_filter_inputs()
                    if not input.fqn or input.fqn != "__chalk__.now"
                ]
            )
        elif self.filter is not None:
            ret.update(self.filter.all_referenced_features())
        return ret

    def __str__(self):
        return f"DataFrame[columns={self.columns}, filter={self.filter_expression.expr if self.filter_expression is not None else self.filter}]"

    def __repr__(self):
        return str(self)

    def to_feature(self) -> type[DataFrame]:
        if not hasattr(self, "_feature_graph_cached"):
            object.__setattr__(
                self,
                "_feature_graph_cached",
                self.graph.graph_cached(self._get_feature),
            )
        return self._feature_graph_cached()

    def _get_feature(self) -> type[DataFrame]:
        elements: list[Feature | Filter] = [x.to_feature() for x in self.columns]
        if self.filter is not None:
            elements.append(self.filter.to_filter())
        return DataFrame[tuple(elements)]

    if TYPE_CHECKING:

        def replace(
            self,
            *,
            limit: int | None = ...,
            filter: FilterParsed | None = ...,
            required_column_refs: FrozenOrderedSet[
                ScalarFeatureType
                | FeatureTimeFeatureType
                | WindowedFeatureType
                | HasManyFeatureType
                | NestedFeatureType[
                    ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType
                ]
                | str
            ] = ...,
            optional_column_refs: FrozenOrderedSet[
                ScalarFeatureType
                | FeatureTimeFeatureType
                | WindowedFeatureType
                | HasManyFeatureType
                | NestedFeatureType[
                    ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType
                ]
                | str
            ] = ...,
        ) -> DataFrameType: ...

    else:

        def replace(self, **kwargs):
            return dataclasses.replace(self, **kwargs)

    def copy_with_root_alias(
        self,
        root_alias: AliasPrefix,
    ) -> "DataFrameType":
        """
        Dataframe features cannot be aliased.
        This function always raises an exception.
        This method exists to provide a consistent interface with other aliasable features.
        """
        raise ValueError(f"DataFrame feature {self} cannot be aliased with prefix {repr(root_alias)}")

    def copy_without_root_alias(
        self,
        root_alias: AliasPrefix,
        *,
        allow_unaliased: bool,
    ) -> "DataFrameType":
        """
        DataFrame features cannot be aliased.
        This function always raises an exception.
        This method exists to provide a consistent interface with other aliasable features.
        """
        if allow_unaliased:
            return self
        raise ValueError(
            f"DataFrame feature {self} cannot be unaliased with prefix {repr(root_alias)} because it is not aliased"
        )

    @staticmethod
    def combine(features: tuple[DataFrameType, ...]) -> DataFrameType:
        """
        Returns the smallest dataframe type which contains all of features.
        """
        if len(features) == 0:
            raise ValueError("No features to combine")
        union_filter = features[0].filter
        for f in features[1:]:
            union_filter = FilterParsed(lhs=union_filter, operation="or", rhs=f.filter)
        union_optional_columns = FrozenOrderedSet(col for f in features for col in f.optional_columns)
        union_columns = FrozenOrderedSet(col for f in features for col in f.columns)
        max_limit = features[0].limit
        for f in features[1:]:
            max_limit = None if (max_limit is None or f.limit is None) else max(max_limit, f.limit)
        return DataFrameType(
            filter=union_filter,
            optional_column_refs=union_optional_columns,
            required_column_refs=(union_columns - union_optional_columns),
            limit=max_limit,
            _graph=features[0].graph,
        )

    @property
    def display_name(self) -> str:
        items: list[str] = []
        if self.filter_expression is not None:
            items.append(self.filter_expression.pprint())
        elif self.filter is not None:
            items.append(self.filter.pprint())
        if len(self.columns) <= 3:
            items.extend(x.display_name for x in self.columns)

        getitem = "" if len(items) > 0 else f"[{', '.join(items)}]"
        return f"DataFrame<{len(self.columns)}>{getitem}"


@dataclasses.dataclass(frozen=True, repr=False, slots=True)
class GroupByFeatureType(_CompatibleWithNestedFeatureTypeMixin, NamedFeatureType, FeatureType):
    """
    A feature that is a pointer to a materialized group-by window DataFrame.
    For this example:

        @features
        class Transaction:
            id: int
            mcc: str
            amount: float
            user_id: "User.id"

        @features
        class User:
            id: int
            transactions: DataFrame[TransactionX]
            valid_spend_by_merchant: DataFrame = group_by_windowed(
                "30d", "90d",
                materialization={"bucket_duration": "1d"},
                expression=_.transactions.group_by(_.mcc).agg(_.amount.sum()),
            )

    We would expect:

        MaterializedGroupByWindowDF(
            namespace="user",
            name="valid_spend_by_merchant",
            config=MaterializationWindowConfigParsed(
                namespace="transaction",
                group_by_fqns=("transaction.user_id", "transaction.mcc"),
                bucket_duration=timedelta(days=1),
                aggregation="sum",
                aggregate_on="transaction.amount",
                pyarrow_dtype=pa.float64(),
            ),
            windows=FrozenOrderedSet({30 * 86400, 90 * 86400}),
        )
    """

    window_materialization: MaterializationWindowConfigParsed
    windows: FrozenOrderedSet[int]

    def __getstate__(self):
        return FeatureType.__getstate__(self)

    def __setstate__(self, state: tuple[Any, ...]):
        NamedFeatureType.__setstate__(self, state)

    def __post_init__(self):
        NamedFeatureType.__post_init__(self)

    @property
    def pyarrow_dtype(self) -> pa.DataType:
        return self.window_materialization.pyarrow_dtype

    @property
    def primitive_converter(self) -> PrimitiveFeatureConverter[int | float, int | float]:
        return PrimitiveFeatureConverter(
            name="helper",
            is_nullable=False,
            pyarrow_dtype=self.window_materialization.pyarrow_dtype,
        )

    @property
    def underlying(self) -> GroupByFeatureType:
        return self

    @property
    def is_feature_nullable(self) -> bool:
        return False

    def flatten(self):
        # TODO(nathan, courtesy of emarx): I don't know what this should be
        return (self,)

    def copy_with_root_alias(self, root_alias: AliasPrefix) -> "GroupByFeatureType":
        """
        Returns a copy of this feature with the specified root alias prefix set.
        `user.transactions` becomes `prefix:user.transactions`.
        """
        return dataclasses.replace(
            self,
            namespace=add_alias_prefix_to_str(self.namespace, alias_prefix=root_alias),
        )

    def __repr__(self):
        return f"{type(self).__name__}<{[g.fqn for g in self.window_materialization.group_by]}>({self.root_fqn})"

    @property
    def is_value_schema_feature_type(self) -> bool:
        return False

    @property
    def is_schema_feature_type(self) -> bool:
        return False


@dataclasses.dataclass(frozen=True, repr=False, slots=True)
class HasManyFeatureType(_CompatibleWithNestedFeatureTypeMixin, NamedFeatureType, FeatureType):
    autogenerated: bool
    join: FilterParsed = dataclasses.field(compare=False)
    df: DataFrameType
    max_staleness: timedelta | None = dataclasses.field(default=None, repr=False)
    online_store_max_items: int | None = dataclasses.field(default=None, repr=False)
    _primitive_converter_graph_cache: GraphCached[PrimitiveFeatureConverter[Any, Any]] = dataclasses.field(
        init=False, compare=False
    )
    _feature_graph_cached: GraphCached[Feature[Any, Any]] = dataclasses.field(init=False, compare=False)
    _nearest_neighbor_join_info: NearestNeighborJoinInfo | None = dataclasses.field(init=False, compare=False)

    def __getstate__(self):
        return FeatureType.__getstate__(self)

    def __setstate__(self, state: tuple[Any, ...]):
        NamedFeatureType.__setstate__(self, state)

    __exclude_from_state__ = (
        "_graph",
        "_primitive_converter_graph_cache",
        "_feature_graph_cached",
        "_nearest_neighbor_join_info",
    )

    def __hash__(self) -> int:
        return hash((self.root_fqn, self.df.columns, self.df.filter, self.df.filter_expression))

    def __post_init__(self):
        NamedFeatureType.__post_init__(self)

    @property
    def is_value_schema_feature_type(self) -> bool:
        return True

    @property
    def is_schema_feature_type(self) -> bool:
        return True

    @property
    def pyarrow_dtype(self) -> pa.DataType:
        return self.primitive_converter.pyarrow_dtype

    @property
    def primitive_converter(self) -> PrimitiveFeatureConverter[Any, Any]:
        if not hasattr(self, "_primitive_converter_graph_cache"):
            object.__setattr__(
                self,
                "_primitive_converter_graph_cache",
                self.graph.graph_cached(self._get_primitive_converter_graph_cache),
            )
        return self._primitive_converter_graph_cache()

    @property
    def polars_dtype(self) -> CompatPlDataType:
        return self.primitive_converter.polars_dtype  # pyright: ignore[reportReturnType]

    def _get_primitive_converter_graph_cache(self) -> PrimitiveFeatureConverter[Any, Any]:
        return PrimitiveFeatureConverter(
            name=self.fqn,
            is_nullable=False,
            pyarrow_dtype=pa.large_list(pa.struct({x.root_fqn: x.underlying.pyarrow_dtype for x in self.df.columns})),
            primitive_default=[],
        )

    @property
    def all_referenced_features(
        self,
    ) -> FrozenOrderedSet[
        ScalarFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | NestedFeatureType[
            ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasOneFeatureType | HasManyFeatureType
        ]
    ]:
        """All referenced features, from the join and filters"""
        return FrozenOrderedSet(self.join.all_referenced_features()) | self.df.all_referenced_features()

    def only_local_feature(self) -> ScalarFeatureType:
        # this will be replaced once support for multiple join conditions is fully implemented
        return get_unique_item(
            x
            for x in self.join.all_referenced_features()
            if x.namespace == self.namespace and isinstance(x, ScalarFeatureType)
        )

    def get_local_join_features(self) -> tuple[ScalarFeatureType, ...]:
        """
        Returns the sequence of local features used to compute the equijoin.
        """
        return tuple(
            x
            for x in self.join.all_referenced_features()
            if x.namespace == self.namespace and isinstance(x, ScalarFeatureType)
        )

    def only_foreign_feature(self) -> ScalarFeatureType:
        # this will be replaced once support for multiple join conditions is fully implemented
        return get_unique_item(
            x
            for x in self.join.all_referenced_features()
            if x.namespace != self.namespace and isinstance(x, ScalarFeatureType)
        )

    def get_foreign_join_features(self) -> tuple[ScalarFeatureType, ...]:
        """
        Returns the sequence of foreign features used to compute the equijoin.
        """
        return tuple(
            x
            for x in self.join.all_referenced_features()
            if x.namespace != self.namespace and isinstance(x, ScalarFeatureType)
        )

    def foreign_namespace(self) -> str:
        return get_unique_item(set(feat.namespace for feat in self.get_foreign_join_features()))

    def local_namespace(self) -> str:
        return self.namespace

    @property
    def underlying(self) -> HasManyFeatureType:
        return self

    @property
    def is_feature_nullable(self) -> bool:
        return False

    def flatten(self):
        # TODO (rkargon) Is this correct? i.e. I don't think we want to explode into individual columns.
        return (self,)

    def __repr__(self):
        return f"{type(self).__name__}(fqn={self.root_fqn!r}, autogenerated={self.autogenerated!r}, join={self.join!r}, df={self.df!r}, max_staleness={self.max_staleness!r})"

    def select(
        self,
        *,
        required_columns: FrozenOrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
        ],
        optional_columns: FrozenOrderedSet[
            ScalarFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | HasManyFeatureType
            | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
        ],
    ) -> HasManyFeatureType:
        """A new has-many feature type with only the selected columns"""
        hm_feature = dataclasses.replace(
            self,
            df=DataFrameType(
                filter=self.df.filter,
                filter_expression=self.df.filter_expression,
                required_column_refs=required_columns,
                optional_column_refs=optional_columns,
                limit=self.df.limit,
                _graph=self.df.graph,
            ),
        )
        return hm_feature

    def is_subfilter(
        self,
        other: HasManyFeatureType,
    ) -> bool:
        """Returns True only if (not always if) results for `other` could be used to compute results for `self`"""
        if not self.fqn == other.fqn:
            return False
        # If they have same fqn, then they correspond to the same has-many "feature", so they would have the same join, same namespaces, etc.
        # If `other` has
        return surely_is_subfilter(self.df.filter, other.df.filter)

    def _get_feature_graph_cached(self):
        hm = NamedFeatureType.to_feature(self)
        hm = copy.copy(hm)
        hm.typ = ParsedAnnotation(underlying=self.df.to_feature())
        return hm

    def to_feature(self):
        if not hasattr(self, "_feature_graph_cached"):
            object.__setattr__(
                self,
                "_feature_graph_cached",
                self.graph.graph_cached(self._get_feature_graph_cached),
            )
        return self._feature_graph_cached()

    def copy_with_root_alias(self, root_alias: AliasPrefix) -> "HasManyFeatureType":
        """
        Returns a copy of this feature with the specified root alias prefix set.
        `user.transactions` becomes `prefix:user.transactions`.
        """
        return dataclasses.replace(
            self,
            namespace=add_alias_prefix_to_str(self.namespace, alias_prefix=root_alias),
        )

    def copy_without_root_alias(
        self,
        root_alias: AliasPrefix,
        *,
        allow_unaliased: bool,
    ) -> "HasManyFeatureType":
        """
        Returns a copy of this feature with the specified root alias prefix removed.
        `prefix:user.transactions` becomes `user.transactions`.
        """
        return dataclasses.replace(
            self,
            namespace=remove_alias_prefix_from_str(
                self.namespace,
                alias_prefix=root_alias,
                raise_if_not_aliased=not allow_unaliased,
            ),
        )

    def replace_df(self, df: DataFrameType) -> HasManyFeatureType:
        return dataclasses.replace(self, df=df)

    @staticmethod
    def combine(features: tuple[HasManyFeatureType, ...]):
        if len(features) == 0:
            raise ValueError("No has-many feature to combine")
        return features[0].replace_df(DataFrameType.combine(tuple(x.df for x in features)))

    def get_nearest_neighbor_join_info(self) -> "NearestNeighborJoinInfo | None":
        from chalkruntime.graph.nearest_neighbor import NearestNeighborJoinInfo

        if not hasattr(self, "_nearest_neighbor_join_info"):
            object.__setattr__(
                self,
                "_nearest_neighbor_join_info",
                NearestNeighborJoinInfo.maybe_from_feature(self),
            )
        return self._nearest_neighbor_join_info


@overload
def _translate_feature(
    f: ScalarFeatureType,
    has_many_path: tuple[HasOnePathObjParsed, ...],
) -> NestedFeatureType[ScalarFeatureType]: ...


@overload
def _translate_feature(
    f: FeatureTimeFeatureType,
    has_many_path: tuple[HasOnePathObjParsed, ...],
) -> NestedFeatureType[FeatureTimeFeatureType]: ...


@overload
def _translate_feature(
    f: NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType],
    has_many_path: tuple[HasOnePathObjParsed, ...],
) -> NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]: ...


def _is_prefixed_local_feature(
    f: (ScalarFeatureType | FeatureTimeFeatureType | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]),
    local_root_namespace: str,
    local_join_namespace: str,
    has_many_path: tuple[HasOnePathObjParsed, ...],
):
    """Determine whether the feature f is already properly prefixed. Properly handles cyclic features."""
    if f.root_namespace != local_root_namespace:
        return False
    if local_root_namespace != local_join_namespace:
        return True
    # If we are here, then there is a cycle.
    # Assume that f is already prefixed (Return true) if the path of f starts with the has many path
    if isinstance(f, (ScalarFeatureType, FeatureTimeFeatureType)):
        # If it's scalar, it's not prefixed, so definitely no path
        return False
    for i, path_elmt in enumerate(has_many_path):
        if i < len(f.path) and f.path[i] == path_elmt:
            continue
        return False
    return True


def _translate_feature(
    f: (ScalarFeatureType | FeatureTimeFeatureType | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]),
    has_many_path: tuple[HasOnePathObjParsed, ...],
) -> FeatureType:
    assert len(has_many_path) > 0, "Must be at least one element in the has-many path"
    local_root_namespace = has_many_path[0].parent.root_namespace
    child = has_many_path[-1].child
    local_join_namespace = child.namespace
    assert isinstance(child, (HasOneFeatureType, HasManyFeatureType))
    foreign_namespace = child.foreign_namespace()
    if f.root_namespace in (
        CHALK_TS_FEATURE.namespace,
        foreign_namespace,
    ) or _is_prefixed_local_feature(
        f,
        local_root_namespace=local_root_namespace,
        local_join_namespace=local_join_namespace,
        has_many_path=has_many_path,
    ):
        # Leave the TS feature and already-local or foreign features as-is
        return f
    if f.root_namespace == local_join_namespace:
        if isinstance(f, NestedFeatureType):
            return NestedFeatureType(
                underlying_ref=f.underlying,
                path=(
                    *has_many_path[:-1],
                    HasOnePathObjParsed(parent=has_many_path[-1].parent, child=f.path[0].parent),
                    *f.path,
                ),
                _graph=f.graph,
            )
        else:
            assert not isinstance(f, NestedFeatureType)
            return NestedFeatureType(
                underlying_ref=f,
                path=(
                    *has_many_path[:-1],
                    HasOnePathObjParsed(parent=has_many_path[-1].parent, child=f),
                ),
                _graph=f.graph,
            )
    else:
        raise ValueError(
            f"Invalid root namespace: '{f.root_namespace}'. Features must be rooted in the local root namespace '{local_root_namespace}', local join namespace '{local_join_namespace}', or foreign namespace"
        )


def _translate_filter(
    f: FilterParsed,
    foreign_namespace: str,
    has_many_path: tuple[HasOnePathObjParsed, ...],
) -> FilterParsed:
    lhs = f.lhs
    if isinstance(lhs, FilterParsed):
        lhs = _translate_filter(lhs, foreign_namespace, has_many_path)
    if isinstance(lhs, FeatureType) and lhs.root_prefix != foreign_namespace:
        lhs = _translate_feature(lhs, has_many_path)
    rhs = f.rhs
    if isinstance(rhs, FilterParsed):
        rhs = _translate_filter(rhs, foreign_namespace, has_many_path)
    if isinstance(rhs, FeatureType) and rhs.root_prefix != foreign_namespace:
        rhs = _translate_feature(rhs, has_many_path)
    return FilterParsed(
        lhs=lhs,
        operation=f.operation,
        rhs=rhs,
    )


# FIXME: There are more hacky filter logic in QueryRewriterFactory.py. We should consolidate
def surely_is_subfilter(f1: GeneralizedFilter, f2: GeneralizedFilter):
    """If it returns True, then f1 is a subfilter of f2"""
    if f2 is None:
        return True
    return f1 == f2


def rewrite_local_join_features_with_input_path(
    hm_input: (NestedFeatureType[HasManyFeatureType | HasOneFeatureType] | HasManyFeatureType | HasOneFeatureType),
    include_filters: bool = True,
) -> FilterParsed:
    """Rewrite the join condition and DataFrame filters to incorporate the path from the input feature

    For example, given the resolver:

    >>> def resolver(
    ...    transactions: User.checking_account.transactions[
    ...        Transaction.amount > Account.average_balance
    ...    ]
    ... ) -> ...:

    this function will rewrite the join conditions and filters to be rooted in the `User` namespace
    For example:

    >>> Transaction.account_id == Account.id -> Transaction.account_id == User.checking_account.id
    >>> Transaction.amount > Account.average_balance -> Transaction.amount > User.checking_account.average_balance

    """
    if isinstance(hm_input, HasManyFeatureType):
        ans = hm_input.join
        if include_filters and hm_input.df.filter is not None:
            ans &= hm_input.df.filter
        return ans
    elif isinstance(hm_input, HasOneFeatureType):
        return hm_input.join
    elif is_nested_has_one(hm_input):
        filt = hm_input.underlying.join
    else:
        assert is_nested_has_many(hm_input)
        filt = hm_input.underlying.join
        if include_filters and hm_input.underlying.df.filter is not None:
            filt &= hm_input.underlying.df.filter
    foreign_namespace = hm_input.underlying.foreign_namespace()
    ans = _translate_filter(filt, foreign_namespace=foreign_namespace, has_many_path=hm_input.path)

    assert all(
        x.root_namespace in (hm_input.root_namespace, foreign_namespace, CHALK_TS_FEATURE.namespace)
        for x in ans.all_referenced_features()
    ), "all translated join features should either be in the hm_input.root_namespace or the foreign namespace"
    return ans


def replace_featuretypes_with_features(hs: Filter | FilterParsed | Any) -> Filter | Any:
    if not isinstance(hs, (Filter, FilterParsed)):
        return hs
    lhs = hs.lhs
    rhs = hs.rhs
    if root_fqn := getattr(lhs, "root_fqn", None):
        lhs = Feature.from_root_fqn(root_fqn)
    if root_fqn := getattr(rhs, "root_fqn", None):
        rhs = Feature.from_root_fqn(root_fqn)
    lhs = replace_featuretypes_with_features(lhs)
    rhs = replace_featuretypes_with_features(rhs)
    return Filter(lhs=lhs, operation=hs.operation, rhs=rhs)


def get_filters_from_has_many_feature_type(
    has_many_feature_type: HasManyFeatureType | NestedFeatureType[HasManyFeatureType],
) -> list[Filter]:
    filters: list[FilterParsed] = []
    _get_filters_rec(has_many_feature_type, filters)
    return [replace_featuretypes_with_features(filter) for filter in filters]


def get_filters_parsed_from_has_many_feature_type(
    has_many_feature_type: HasManyFeatureType | NestedFeatureType[HasManyFeatureType],
) -> list[FilterParsed]:
    filters: list[FilterParsed] = []
    _get_filters_rec(has_many_feature_type, filters)
    return filters


def _get_filters_rec(
    item: HasManyFeatureType | NestedFeatureType[HasManyFeatureType],
    filter_storage_list: list[FilterParsed],
):
    if isinstance(item, HasManyFeatureType) and item.df.filter is not None:
        filter_storage_list.append(item.df.filter)
        return

    if isinstance(item, NestedFeatureType):
        _get_filters_rec(item.underlying, filter_storage_list)


class HasOnePathObjParsed:
    slots = ("_parent_ref", "_child_fqn", "_graph")

    def __init__(
        self,
        parent: HasOneFeatureType | HasManyFeatureType,
        child: (
            ScalarFeatureType
            | HasManyFeatureType
            | HasOneFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | GroupByFeatureType
        ),
    ):
        super().__init__()
        if isinstance(parent, HasManyFeatureType):
            # The ONLY column we want from the parent is the child feature
            if isinstance(child, GroupByFeatureType):
                raise ValueError(f"Child <{child!r}> is not allowed as a child of a has-many feature")
            elif isinstance(child, HasOneFeatureType):
                children = child.flatten()
            elif isinstance(child, HasManyFeatureType):
                # Selecting only the local feature(s) to match
                # https://github.com/chalk-ai/chalk-private/blob/a480c8518ee2f4c3a97250741a3513167ab650ae/chalkruntime/chalkruntime/loader/converter.py#L517
                children = list(child.get_local_join_features())
            else:
                children = [child]
            parent = parent.select(required_columns=FrozenOrderedSet(), optional_columns=FrozenOrderedSet(children))

        self._parent_ref = parent if isinstance(parent, HasManyFeatureType) else parent.fqn

        # The final child in a path will not be a HasOneFeatureType,
        # and all other intermediate children will be HasOneFeatureType
        self._child_ref = child if isinstance(child, HasManyFeatureType) else child.fqn
        self._graph = parent.graph

    @property
    def parent(self) -> HasOneFeatureType | HasManyFeatureType:
        parent = self._parent_ref
        if isinstance(parent, str):
            parent = unwrap_optional(self.graph.feature_from_fqn(parent))
            assert isinstance(parent, HasOneFeatureType)
        else:
            assert isinstance(parent, HasManyFeatureType)
        return parent

    @property
    def parent_fqn(self):
        parent = self._parent_ref
        if not isinstance(parent, str):
            parent = parent.fqn
        return parent

    @property
    def child(
        self,
    ) -> ScalarFeatureType | HasManyFeatureType | HasOneFeatureType | FeatureTimeFeatureType | WindowedFeatureType:
        child = self._child_ref
        if isinstance(child, str):
            child = unwrap_optional(self.graph.feature_from_fqn(child))
            assert isinstance(
                child,
                (
                    ScalarFeatureType,
                    HasOneFeatureType,
                    FeatureTimeFeatureType,
                    WindowedFeatureType,
                ),
            )
        else:
            assert isinstance(child, HasManyFeatureType)
        return child

    def __eq__(self, other: object):
        if not isinstance(other, HasOnePathObjParsed):
            return NotImplemented
        return self._parent_ref == other._parent_ref and self._child_ref == other._child_ref

    def __hash__(self) -> int:
        return hash((self._parent_ref, self._child_ref))

    def __getstate__(self) -> object:
        return (self._parent_ref, self._child_ref)

    def __setstate__(self, state: tuple[Any, ...]):
        (self._parent_ref, self._child_ref) = state

    @property
    def graph(self):
        if not hasattr(self, "_graph"):
            object.__setattr__(self, "_graph", get_global_graph())
        return self._graph


UnderlyingScalarFeatureType = ScalarFeatureType | NestedFeatureType[ScalarFeatureType]
UnderlyingFeatureTimeFeatureType = FeatureTimeFeatureType | NestedFeatureType[FeatureTimeFeatureType]
UnderlyingHasManyFeatureType = HasManyFeatureType | NestedFeatureType[HasManyFeatureType]
UnderlyingHasOneFeatureType = HasOneFeatureType | NestedFeatureType[HasOneFeatureType]
UnderlyingWindowedFeatureType = WindowedFeatureType | NestedFeatureType[WindowedFeatureType]
SchemaFeatureType = (
    ScalarFeatureType
    | FeatureTimeFeatureType
    | HasManyFeatureType
    | DataFrameType
    | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
)


def is_underlying_scalar(ft: object) -> TypeGuard[UnderlyingScalarFeatureType]:
    return isinstance(ft, ScalarFeatureType) or is_nested_scalar(ft)


def is_underlying_nullable_scalar(ft: object) -> TypeGuard[ScalarFeatureType]:
    if is_underlying_scalar(ft):
        return ft.is_feature_nullable
    return False


def is_scalar_feature_type(ft: object) -> TypeGuard[ScalarFeatureType]:
    """This function's signature works better with Pyright's strict type checking mode:
    `isinstance` will narrow to the type `ScalarFeatureType` which produces red
    squigglies, when we want to get the type `ScalarFeatureType` for convenience."""
    return isinstance(ft, ScalarFeatureType)


def is_underlying_has_one(
    ft: object,
) -> TypeGuard[HasOneFeatureType | NestedFeatureType[HasOneFeatureType]]:
    return isinstance(ft, HasOneFeatureType) or is_nested_has_one(ft)


def is_underlying_has_many(ft: object) -> TypeGuard[UnderlyingHasManyFeatureType]:
    return isinstance(ft, HasManyFeatureType) or is_nested_has_many(ft)


def all_has_many_subfeatures(
    ft: FeatureType,
) -> Tuple[UnderlyingHasManyFeatureType, ...]:
    """
    Given an arbitrarily nested feature, returns a tuple of all has-many features in the join path,
        all expressed in attribute notation and rooted in ft's root namespace, ordered local to foreign namespaces,
        including the feature itself if it is a has-many.
    """
    # TODO: cache this
    subfeatures: list[UnderlyingHasManyFeatureType] = []
    if isinstance(ft, NestedFeatureType):
        # FIXME: Support parsing nested has-many using index notation e.g.
        # User.accounts[Account.type == 'CHECKING', Account.transactions[Transaction.amount > 100, Transaction.amount]]
        for i, x in enumerate(list(ft.walk_path_joins())):
            if isinstance(x, HasManyFeatureType):
                if i == 0:
                    subfeatures.append(x)
                else:
                    subfeatures.append(
                        NestedFeatureType(
                            underlying_ref=x,
                            path=ft.path[:i],
                            _graph=ft.graph,
                        )
                    )

    # for a has-many feature type expressed in X.y.col, normalize to X.y[Y.col]
    # Note that X.y.z.col will become X.y[Y.z.col], we need to remember to change namespace later
    if is_underlying_has_many(ft):
        subfeatures.append(ft)
    elif len(subfeatures) >= 1:
        assert isinstance(ft, NestedFeatureType)
        subfeatures[-1] = has_many_subfeatures_to_projection(
            subfeatures[-1], [x.relative_to(subfeatures[-1]) for x in ft.flatten()]
        )
    return tuple(subfeatures)


def is_general_has_many(
    ft: object,
) -> TypeGuard[HasManyFeatureType | NestedFeatureType[HasManyFeatureType]]:
    if isinstance(ft, FeatureType):
        return len(all_has_many_subfeatures(ft)) >= 1
    return False


def is_has_many_has_many(ft: object) -> TypeGuard[NestedFeatureType[HasManyFeatureType]]:
    if isinstance(ft, NestedFeatureType):
        return len(all_has_many_subfeatures(ft)) >= 2
    return False


def is_underlying_windowed(
    ft: object,
) -> TypeGuard[WindowedFeatureType | NestedFeatureType[WindowedFeatureType]]:
    return isinstance(ft, WindowedFeatureType) or is_nested_windowed(ft)


def is_underlying_feature_time(
    ft: object,
) -> TypeGuard[UnderlyingFeatureTimeFeatureType]:
    return isinstance(ft, FeatureTimeFeatureType) or is_nested_feature_time(ft)


def is_nested_scalar(ft: object) -> TypeGuard[NestedFeatureType[ScalarFeatureType]]:
    return isinstance(ft, NestedFeatureType) and isinstance(ft.underlying, ScalarFeatureType)


def is_nested_has_one(ft: object) -> TypeGuard[NestedFeatureType[HasOneFeatureType]]:
    return isinstance(ft, NestedFeatureType) and isinstance(ft.underlying, HasOneFeatureType)


def is_nested_has_many(ft: object) -> TypeGuard[NestedFeatureType[HasManyFeatureType]]:
    return isinstance(ft, NestedFeatureType) and isinstance(ft.underlying, HasManyFeatureType)


# FIXME: I don't think this special casing is needed anymore after the hm-hm fix, since has-many should work recursively
def parse_has_many_subfeature(
    ft: (
        ScalarFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | WindowedFeatureType
        | FeatureTimeFeatureType
        | GroupByFeatureType
        | DataFrameType
        | NestedFeatureType[
            ScalarFeatureType | HasManyFeatureType | WindowedFeatureType | FeatureTimeFeatureType | HasOneFeatureType
        ]
    ),
):
    """
    Parses a feature that references a sub-feature of a has-many (e.g. User.transactions.amount)
    :return: Returns the root has-many and the child feature separately (e.g. User.transactions, Transactions.amount)
    If a feature is not a has-many sub-feature, returns None
    """
    if not isinstance(ft, NestedFeatureType):
        return None
    if is_underlying_has_many(ft):
        return None
    root_hasmany_feature = None
    nested_feature = ft
    # Walk the path until we come across a has-many
    for idx, path_obj in enumerate(ft.path):
        assert isinstance(nested_feature, NestedFeatureType)
        nested_feature = nested_feature.pop_prefix()
        if isinstance(path_obj.parent, HasManyFeatureType):
            # This only happens in the first path node, otherwise we'd have encountered a has-many child first
            assert idx == 0
            root_hasmany_feature = path_obj.parent
            break
        elif isinstance(path_obj.child, HasManyFeatureType):
            # Pop an extra prefix off if we want the child node
            assert isinstance(nested_feature, NestedFeatureType)
            nested_feature = nested_feature.pop_prefix()
            root_hasmany_feature = NestedFeatureType(
                underlying_ref=path_obj.child,
                path=ft.path[: idx + 1],
                _graph=path_obj.child.graph,
            )
            break
    if root_hasmany_feature is not None:
        return root_hasmany_feature, nested_feature
    else:
        return None


def parse_innermost_has_many_subfeature(
    ft: (
        ScalarFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | WindowedFeatureType
        | FeatureTimeFeatureType
        | GroupByFeatureType
        | DataFrameType
        | NestedFeatureType[
            ScalarFeatureType | HasManyFeatureType | WindowedFeatureType | FeatureTimeFeatureType | HasOneFeatureType
        ]
    ),
):
    """
    Parses a feature that references a sub-feature of a has-many (e.g. User.accounts.transactions.amount)
    :return: Returns the root has-many and the child feature separately (e.g. User.accounts.transactions, Transactions.amount)
    If a feature is not a has-many sub-feature, returns None
    """
    innermost_so_far = None
    root_so_far: HasManyFeatureType | NestedFeatureType | None = None
    curr_ft = ft

    while (next_res := parse_has_many_subfeature(curr_ft)) is not None:
        innermost_so_far = curr_ft = next_res[1]
        root_so_far = (
            next_res[0] if root_so_far is None else NestedFeatureType.join_from_parts(root_so_far, next_res[0])
        )

    if innermost_so_far is None or root_so_far is None:
        return None
    return root_so_far, innermost_so_far


def split_at_last_hm(f: NestedFeatureType[HasManyFeatureType]):
    rest, end = f, None
    while isinstance(rest, NestedFeatureType):
        split_res = rest.split_at_last()
        rest, new_end = split_res
        end = new_end if end is None else NestedFeatureType.join_from_parts(new_end, end)
        if is_underlying_has_many(rest):
            return rest, end
    return rest, end


# Whether a feature is a sub-feature of a has-many,
# e.g. user.transactions.amount
def is_has_many_subfeature(
    ft: (
        ScalarFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | WindowedFeatureType
        | FeatureTimeFeatureType
        | NestedFeatureType[
            ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType | HasOneFeatureType
        ]
    ),
) -> bool:
    return parse_has_many_subfeature(ft) is not None


def has_many_subfeatures_to_projection(
    has_many: UnderlyingHasManyFeatureType,
    sub_features: Iterable[
        ScalarFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | HasManyFeatureType
        | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType | HasManyFeatureType]
    ],
) -> UnderlyingHasManyFeatureType:
    """
    Convert every has-many subfeatures into a has-many w/ a projection
    e.g. User.transactions.amount --> User.transactions[Transactions.amount]
    :param has_many: root has-many, e.g. User.card.transactions
    :param sub_features: e.g. Transaction.amount, Transaction.fraud_score
    :return: Has-many feature type w/ the given projection
    """
    underlying = has_many.underlying
    df = has_many.underlying.df

    new_df = df.replace(
        required_column_refs=FrozenOrderedSet(),
        optional_column_refs=FrozenOrderedSet(sub_features),
    )
    new_hm_feat = HasManyFeatureType(
        name=underlying.name,
        namespace=underlying.namespace,
        attribute_name=underlying.attribute_name,
        original_python_attribute_name=underlying.original_python_attribute_name,
        autogenerated=underlying.autogenerated,
        max_staleness=underlying.max_staleness,
        online_store_max_items=underlying.online_store_max_items,
        join=underlying.join,
        _graph=has_many.graph,
        df=new_df,
        is_externally_defined=underlying.is_externally_defined,
    )
    if isinstance(has_many, HasManyFeatureType):
        return new_hm_feat
    else:
        assert isinstance(has_many, NestedFeatureType)
        return NestedFeatureType(path=has_many.path, underlying_ref=new_hm_feat, _graph=has_many.graph)


def is_nested_windowed(
    ft: object,
) -> TypeGuard[NestedFeatureType[WindowedFeatureType]]:
    return isinstance(ft, NestedFeatureType) and isinstance(ft.underlying, WindowedFeatureType)


def is_nested_feature_time(
    ft: object,
) -> TypeGuard[NestedFeatureType[FeatureTimeFeatureType]]:
    return isinstance(ft, NestedFeatureType) and isinstance(ft.underlying, FeatureTimeFeatureType)


def is_dataframe_feature_type(ft: object) -> TypeGuard[DataFrameType]:
    return isinstance(ft, DataFrameType)


def is_primary_key_feature_type(ft: object) -> TypeGuard[ScalarFeatureType]:
    """Returns true if the feature is a primary key feature (and not a nested/input feature)"""
    return isinstance(ft, ScalarFeatureType) and ft.primary


def is_optional_has_one(ft: FeatureType) -> bool:
    return isinstance(ft, NestedFeatureType) and any(
        isinstance(feature_step, HasOneFeatureType) and feature_step.is_feature_nullable
        for feature_step in ft.walk_all_steps()
    )


def default_version_fqn(scalar_ft: ScalarFeatureType) -> str | None:
    if "@" not in scalar_ft.fqn:
        return f"{scalar_ft.fqn}@1"
    return None


def required_features_to_sample(
    ft: (
        HasManyFeatureType
        | ScalarFeatureType
        | FeatureTimeFeatureType
        | HasOneFeatureType
        | NestedFeatureType[HasManyFeatureType | FeatureTimeFeatureType | ScalarFeatureType | HasOneFeatureType]
    ),
) -> Sequence[
    HasManyFeatureType
    | FeatureTimeFeatureType
    | ScalarFeatureType
    | NestedFeatureType[HasManyFeatureType | FeatureTimeFeatureType | ScalarFeatureType]
]:
    # TODO: cache this
    # please, use this function when you mean to use it, since this might change in the future depending on the memory format we store has-many features in
    """
    Given a feature, get all the features that we expect to be in the schema in order to run a resolve with it as input.
    This can include the feature itself and any additional joins we need to do.
    Features which are needed to compute it, but are no longer needed to run resolvers with it, are excluded.
    """
    if not is_general_has_many(ft):
        assert not isinstance(ft, DataFrameType)
        # here and in code below, we separately treat FeatureTimeFeatureType, because it cannot be nested through has-one
        # i.e. X.y.ts == X.ts. The batch planner will naturally include ts as well, so we shouldn't worry about it
        # FIXME: if we see a FeatureTimeFeatureType, we need to mark the feature as a has-many
        return tuple(x for x in ft.flatten() if is_underlying_scalar(x))

    subfeatures = list(all_has_many_subfeatures(ft))
    recolumned_subfeatures: list[HasManyFeatureType | NestedFeatureType[HasManyFeatureType]] = []
    new_underlying_features: list[HasManyFeatureType] = []
    sampling_features: list[
        ScalarFeatureType
        | FeatureTimeFeatureType
        | HasManyFeatureType
        | NestedFeatureType[HasManyFeatureType | FeatureTimeFeatureType | ScalarFeatureType]
    ] = []
    for i, hmsf in enumerate(all_has_many_subfeatures(ft)):
        if i == 0:
            relative_feature = hmsf
        else:
            assert is_nested_has_many(hmsf)
            relative_feature = hmsf.relative_to(subfeatures[i - 1])
        rewritten_filter = rewrite_local_join_features_with_input_path(relative_feature, include_filters=True)
        local_sampling_features: OrderedSet[
            ScalarFeatureType | FeatureTimeFeatureType | NestedFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
        ] = OrderedSet()
        for f in rewritten_filter.all_referenced_features():
            if f.root_namespace == relative_feature.root_namespace:
                # I'm a little worried that old batch planner relies on FeatureTime features for temporal consistency
                local_sampling_features.add(f)
        # HACK: batch planners automatically add the foreign join key and primary key in _compute_has_one_operator and _compute_has_many_operator, so we don't need it here.
        if i == 0:
            sampling_features.extend(local_sampling_features)
        else:
            # Batch planner is not very smart yet about deduplicating similar has-many features. For example, if we want X.y[Y.a] and X.y[Y.a, Y.b], it'll resolve X.y and Y.a twice.
            # To avoid this, we assimilate all the sampling features to have the same paths.
            new_underlying_features.append(
                subfeatures[i - 1].underlying.select(
                    # Maybe these should be required? after all, the feature is useless without them
                    required_columns=FrozenOrderedSet(x for x in subfeatures[i - 1].underlying.df.required_columns),
                    optional_columns=FrozenOrderedSet(local_sampling_features),
                )
            )
    if len(subfeatures) > 0:
        new_underlying_features.append(subfeatures[-1].underlying)

    recolumned_subfeatures.append(NestedFeatureType.replace_suffix(subfeatures[0], new_underlying_features[0]))
    for i in range(1, len(subfeatures)):
        subfeature = subfeatures[i]
        assert isinstance(subfeature, NestedFeatureType)
        new_relative = NestedFeatureType.replace_suffix(
            subfeature.relative_to(subfeatures[i - 1]), new_underlying_features[i]
        )
        recolumned_subfeatures.append(NestedFeatureType.absolute_to(new_relative, recolumned_subfeatures[i - 1]))
    sampling_features.extend(recolumned_subfeatures)

    return sampling_features


def is_singleton_feature(feature: FeatureType) -> TypeGuard[ScalarFeatureType]:
    # we might have non-scalar singletons some day
    return isinstance(feature, ScalarFeatureType) and feature.is_singleton


def associated_ts_feature(
    feature: ScalarFeatureType | NestedFeatureType[ScalarFeatureType],
    *,
    scope_feature_time_to_namespace: bool,
) -> FeatureTimeFeatureType | NestedFeatureType[FeatureTimeFeatureType] | None:
    if feature.namespace == PSEUDONAMESPACE:
        return None
    if not scope_feature_time_to_namespace:
        return unwrap_optional(feature.graph.ts_feature_for_namespace(feature.root_namespace))
    if feature.underlying.primary:
        return None  # oat of primary features is always NULL
    foreign_ts_feature = unwrap_optional(feature.graph.ts_feature_for_namespace(feature.namespace))
    return NestedFeatureType.replace_suffix(feature, foreign_ts_feature)


def grammatical_associated_ts_feature(
    feature: NamedFeatureType,
    scope_feature_time_to_namespace: bool,
) -> FeatureTimeFeatureType | NestedFeatureType[FeatureTimeFeatureType]:
    if not scope_feature_time_to_namespace:
        return unwrap_optional(feature.graph.ts_feature_for_namespace(feature.root_namespace))
    foreign_ts_feature = unwrap_optional(feature.graph.ts_feature_for_namespace(feature.namespace))
    return NestedFeatureType.replace_suffix(feature, foreign_ts_feature)


def is_schema_feature_type(f: Any) -> TypeGuard[SchemaFeatureType]:
    return isinstance(f, FeatureType) and f.is_schema_feature_type


def is_materialized_aggregate(f: FeatureType) -> TypeGuard[ScalarFeatureType]:
    return (
        (
            isinstance(f, ScalarFeatureType)
            and f.window_config is not None
            and f.window_config.materialization_config is not None
        )
        or (
            isinstance(f, WindowedFeatureType)
            and any(
                p.window_config is not None and p.window_config.materialization_config is not None
                for p in f.windowed_pseudo_features
            )
        )
        or isinstance(f, GroupByFeatureType)
    )


@dataclasses.dataclass
class SimpleTemporalFilter:
    # A filter which compares a feature to a timedelta, which we special-case interpret as Now + timedelta
    feature: UnderlyingScalarFeatureType | UnderlyingFeatureTimeFeatureType
    operation: Literal["<", "<=", ">", ">="]
    timedelta: timedelta
    # feature operation Now + timedelta

    @staticmethod
    def match(f: FilterParsed) -> Optional["SimpleTemporalFilter"]:
        INVERSE_MAP: Mapping[Literal["<", "<=", ">", ">="], Literal["<", "<=", ">", ">="]] = {
            "<": ">",
            "<=": ">=",
            ">": "<",
            ">=": "<=",
        }

        if (is_underlying_feature_time(f.lhs) or is_underlying_scalar(f.lhs)) and isinstance(f.rhs, timedelta):
            if f.operation in INVERSE_MAP:
                return SimpleTemporalFilter(feature=f.lhs, timedelta=f.rhs, operation=f.operation)
            _logger.warning(f"Unexpected operation {f.operation} in temporal filter {f}.")
            return None
        if (is_underlying_feature_time(f.rhs) or is_underlying_scalar(f.rhs)) and isinstance(f.lhs, timedelta):
            if f.operation in INVERSE_MAP:
                return SimpleTemporalFilter(feature=f.rhs, timedelta=f.lhs, operation=INVERSE_MAP[f.operation])
            _logger.warning(f"Unexpected operation {f.operation} in temporal filter {f}.")
            return None


def is_filter_time_sensitive(f: FilterParsed) -> bool:
    if any(isinstance(x, FeatureTimeFeatureType) for x in f.all_referenced_features()):
        return True
    if SimpleTemporalFilter.match(f) is not None:
        return True
    if isinstance(f.lhs, FilterParsed) and is_filter_time_sensitive(f.lhs):
        return True
    if isinstance(f.rhs, FilterParsed) and is_filter_time_sensitive(f.rhs):
        return True
    return False


def intersect_filters(lhs: FilterParsed | None, rhs: FilterParsed | None) -> FilterParsed | None:
    if lhs is None:
        return rhs
    if rhs is None:
        return lhs
    return FilterParsed(lhs=lhs, operation="and", rhs=rhs)
