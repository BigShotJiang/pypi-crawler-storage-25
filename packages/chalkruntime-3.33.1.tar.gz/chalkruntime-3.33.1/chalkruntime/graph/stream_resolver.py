from __future__ import annotations

import dataclasses
import datetime as dt
import inspect
from functools import cached_property
from inspect import isclass
from typing import (
    TYPE_CHECKING,
    Callable,
    Collection,
    List,
    Literal,
    Mapping,
    Type,
    TypeVar,
    cast,
)

import pyarrow as pa
from chalk.features import DataFrame
from chalk.features._encoding.pyarrow import rich_to_pyarrow
from chalk.features.resolver import RESOLVER_REGISTRY, FunctionCapturedGlobal, StreamResolver
from chalk.streams.base import StreamSource
from chalk.streams.types import (
    StreamResolverParamKeyedState,
    StreamResolverParamMessage,
    StreamResolverParamMessageWindow,
    StreamResolverWindowType,
)
from pydantic.version import VERSION
from typing_extensions import get_args, get_origin, override

from chalkruntime.graph.feature import (
    FeatureTimeFeatureType,
    InputFeatureType,
    ScalarFeatureType,
    UnderlyingFeatureTimeFeatureType,
    UnderlyingScalarFeatureType,
    WindowedFeatureType,
    is_underlying_feature_time,
    is_underlying_has_many,
)
from chalkruntime.graph.graph_impl import graph_cached_property
from chalkruntime.graph.resolver import (
    ResolverParsed,
    TResolverFeatureType,
    feature_to_reference,
)
from chalkruntime.graph.underscore import UnderscoreValue
from libchalk.chalktable import Expr

if TYPE_CHECKING:
    from pydantic import BaseModel
    from pydantic.fields import FieldInfo, ModelField
else:
    try:
        from pydantic.v1 import BaseModel
    except ImportError:
        from pydantic import BaseModel


PydanticType = TypeVar("PydanticType", bound="BaseModel")


pydantic_version: Literal[1, 2] = 1 if VERSION.startswith("1.") else 2


def _convert_field(mf: "ModelField") -> pa.Field:
    typ_ = rich_to_pyarrow(mf.type_, mf.alias if mf.alias is not None else mf.name)  # pyright: ignore[reportUnnecessaryComparison]
    return pa.field(
        metadata={"chalk_field_name": mf.name},
        name=mf.alias if mf.alias is not None else mf.name,  # pyright: ignore[reportUnnecessaryComparison]
        nullable=mf.allow_none,  # noqa
        type=typ_,
    )


def _convert_field_v2(name: str, info: "FieldInfo") -> pa.Field:
    annotation = info.annotation  # pyright: ignore -- two versions of pydantic
    nullable = info.is_required() is False  # pyright: ignore -- two versions of pydantic

    alias = info.alias
    typ_ = rich_to_pyarrow(annotation, alias if alias is not None else name)
    return pa.field(
        metadata={"chalk_field_name": name},
        name=name,
        nullable=nullable,
        type=typ_,
    )


def pydantic_to_pyarrow_schema_v1(x: Type[PydanticType]) -> pa.Schema:
    return pa.schema([_convert_field(mf) for mf in x.__fields__.values()])


def pydantic_to_pyarrow_schema_v2(x: Type[PydanticType]) -> pa.Schema:
    model_fields = x.model_fields  # pyright: ignore -- two versions of pydantic
    model_fields_casted = cast(dict[str, FieldInfo], model_fields)
    return pa.schema([_convert_field_v2(name=name, info=mf) for name, mf in model_fields_casted.items()])


pydantic_to_pyarrow_schema = pydantic_to_pyarrow_schema_v1 if pydantic_version == 1 else pydantic_to_pyarrow_schema_v2


@dataclasses.dataclass(frozen=True)
class StreamResolverParamParsed:
    name: str
    # TODO Currently this doesn't work if a pydantic basemodel field has a type annotation 'Any'
    # Possibly we want to raise an error in that case anyway, since that means the model
    # does not have a well-defined schema

    # Arrow dtype representing the datatype of the parameter (e.g. bytes/string/a struct type w/ the appropriate fields)
    # Not always available, e.g. if a BaseModel field as type annotation 'Any' we can't know the dtype
    dtype: pa.DataType | None


@dataclasses.dataclass(frozen=True)
class StreamResolverParamMessageParsed(StreamResolverParamParsed):
    # Reference to the customer-defined message type (e.g. a proto or BaseModel)
    captured_message_type: FunctionCapturedGlobal | None


class StreamResolverParamMessageWindowParsed(StreamResolverParamParsed):
    pass


class StreamResolverParamKeyedStateParsed(StreamResolverParamParsed):
    pass


@dataclasses.dataclass(frozen=True)
class StreamResolverSignatureParsed:
    params: list[StreamResolverParamParsed]
    output_feature_fqns: set[str]


@dataclasses.dataclass(frozen=True)
class ParseInfoParsed:
    # TODO include more info here if we need it (e.g. dtype / classpath of the user-defined input/output types)
    output_is_optional: bool
    input_type_name: str
    output_type_name: str
    function_name: str
    parse_expression: UnderscoreValue | None


TStreamOutputFeatureType = (
    ScalarFeatureType
    | FeatureTimeFeatureType
    | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
    | WindowedFeatureType
)


@dataclasses.dataclass(frozen=True)
class StreamResolverParsed(ResolverParsed):
    signature_parsed: StreamResolverSignatureParsed
    source: StreamSource
    mode: Literal["continuous", "tumbling", "cdc"]
    # Dictionary mapping (window in secs, original feature type) to the windowed pseudo-feature
    windowed_pseudofeatures_refs: dataclasses.InitVar[dict[int, dict[WindowedFeatureType, ScalarFeatureType]]]
    _windowed_pseudofeatures_refs: dict[int, dict[str, str]] = dataclasses.field(
        init=False,
        repr=False,
        compare=False,
    )
    window_index: int | None
    parse_info_parsed: ParseInfoParsed | None
    keys_refs: dataclasses.InitVar[dict[str, TStreamOutputFeatureType] | None]
    _keys_refs: (
        dict[
            str,
            str | TStreamOutputFeatureType,
        ]
        | None
    ) = dataclasses.field(
        init=False,
        repr=False,
        compare=False,
    )
    timestamp: str | None
    updates_materialized_aggregations: bool
    feature_expressions: Mapping[UnderlyingScalarFeatureType | UnderlyingFeatureTimeFeatureType, UnderscoreValue] | None
    stream_sink_config: StreamSinkConfigParsed | None = None
    skip_online: bool = False
    skip_offline: bool = False
    use_message_envelope: bool = False
    """
    If True, the input to the resolver is not a `bytes` message body but a struct containing the body alongside other metadata.
    Customer's parse function will operate on this struct instead of bytes.
    If no custom parse function is provided, then the default protobuf/json/etc. parsing still happens on the original message.
    """

    header_equality_filters: list[tuple[str, bytes]] | None = None
    """
    TODO: Not yet implemented, currently ignored
    Series of equality filters to apply to message headers. Stream server filters out messages that don't match before sending them to the engine.
    For every (k,v) pair in `header_equality_filters`, a message must have a header `v` with value `k` in order to be processed.
    i.e.:
    ```
    message_matches := all(message.headers.get(k) == v for k,v in header_equality_filters)
    ```
    """

    deduplication_policy: DeduplicationPolicyParsed | None = None

    def __post_init__(
        self,
        input_refs: Collection[TResolverFeatureType],
        output_refs: Collection[TResolverFeatureType],
        windowed_pseudofeatures_refs: dict[int, dict[WindowedFeatureType, ScalarFeatureType]],
        keys_refs: dict[str, TStreamOutputFeatureType] | None,
    ):
        super().__post_init__(input_refs=input_refs, output_refs=output_refs)
        _keys_refs = None
        if keys_refs is not None:
            _keys_refs = {k: feature_to_reference(f) for k, f in keys_refs.items()}  # pyright: ignore
        object.__setattr__(self, "_keys_refs", _keys_refs)

        _windowed_pseudofeatures_refs = {}
        if windowed_pseudofeatures_refs:
            _windowed_pseudofeatures_refs = {
                w_size: {feature_to_reference(w): feature_to_reference(s) for w, s in fmap.items()}
                for w_size, fmap in windowed_pseudofeatures_refs.items()
            }
        object.__setattr__(self, "_windowed_pseudofeatures_refs", _windowed_pseudofeatures_refs)

    @cached_property
    def raw_resolver(self) -> StreamResolver:
        raw_resolver = RESOLVER_REGISTRY.get_resolver(self.fqn)
        if raw_resolver is None:
            raise ValueError(f"Stream resolver {self.fqn} not found. ")
        assert isinstance(raw_resolver, StreamResolver)
        return raw_resolver

    def get_fn(self) -> Callable:
        return self.raw_resolver.fn

    @graph_cached_property
    def windowed_pseudofeatures(self) -> dict[int, dict[WindowedFeatureType, ScalarFeatureType]]:
        out: dict[int, dict[WindowedFeatureType, ScalarFeatureType]] = {}
        for w, f_dict in self._windowed_pseudofeatures_refs.items():
            out[w] = {}
            for w_fqn, s_fqn in f_dict.items():
                w_ft = self.graph.feature_from_fqn(w_fqn)
                s_ft = self.graph.feature_from_fqn(s_fqn)
                if w_ft is None:
                    raise ValueError(f"Failed to find windowed pseudofeature '{w_fqn}' for stream resolver {self.fqn}")
                if not isinstance(w_ft, WindowedFeatureType):
                    raise ValueError(
                        f"Expected feature '{w_fqn}' to be a windowed feature type, but instead got {type(w_ft)} (while initializing stream resolver {self.fqn})"
                    )
                if s_ft is None:
                    raise ValueError(
                        f"Failed to find scalar feature '{s_fqn}' for windowed pseudofeature '{w_fqn}' for stream resolver {self.fqn}"
                    )
                if not isinstance(s_ft, ScalarFeatureType):
                    raise ValueError(
                        f"Expected feature '{s_fqn}' to be a scalar feature type, but instead got {type(s_ft)} (while initializing stream resolver {self.fqn})"
                    )
                out[w][w_ft] = s_ft

        return out

    @graph_cached_property
    def keys(self) -> dict[str, TStreamOutputFeatureType] | None:
        if self._keys_refs is None:
            return None
        keys_out: dict[str, TStreamOutputFeatureType] = {}
        for k, f_ref in self._keys_refs.items():
            if isinstance(f_ref, str):
                f = self.graph.feature_from_fqn(f_ref)
            else:
                f = f_ref
            keys_out[k] = f  # pyright: ignore
        return keys_out

    @property
    def message(self) -> "type[BaseModel] | type[bytes] | None":
        raw_resolver: StreamResolver = self.raw_resolver
        if raw_resolver.message is not None:
            # TODO: unclear if raw_resolver.message is always a pydantic basemodel here.
            # I think in practice this is never used.
            return cast(Type[BaseModel], raw_resolver.message)
        for s in raw_resolver.signature.params:
            if isinstance(s, StreamResolverParamMessage):
                if s.typ is bytes:
                    return s.typ
                return s.typ  # pyright: ignore -- todo, bad types here.
            elif isinstance(s, StreamResolverParamMessageWindow) and is_list_typ_annotation(s.typ):
                item_typ = get_list_item_typ(s.typ)
                if isclass(item_typ) and issubclass(item_typ, BaseModel):
                    return item_typ
            elif (
                isinstance(s, StreamResolverParamMessageWindow)
                and inspect.isclass(s.typ)
                and issubclass(s.typ, DataFrame)
                and (pydantic_model := s.typ.__pydantic_model__) is not None
            ):
                return pydantic_model
        return None

    # pyright complains because the `self` type param is contravariant in a weird way for graph_cached_property
    @graph_cached_property
    @override
    def expected_output_columns(  # pyright: ignore[reportIncompatibleVariableOverride]
        self,
    ) -> Mapping[
        str,
        ScalarFeatureType
        | FeatureTimeFeatureType
        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | WindowedFeatureType]
        | WindowedFeatureType,
    ]:
        cols = self.output_features
        ans: dict[
            str,
            ScalarFeatureType
            | FeatureTimeFeatureType
            | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
            | WindowedFeatureType,
        ] = {}
        for col in cols:
            if col.underlying.autogenerated:
                continue
            if is_underlying_has_many(col):
                raise ValueError(f"Stream resolvers cannot contain has-many feature '{col.fqn}' as output")
            if isinstance(col, InputFeatureType) and is_underlying_feature_time(col.underlying):
                raise ValueError(f"Stream resolvers cannot contain input feature time feature '{col.fqn}' as output")

            ans[col.root_fqn] = cast(
                ScalarFeatureType
                | FeatureTimeFeatureType
                | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
                | WindowedFeatureType,
                col,
            )
        if self.keys is not None:
            for _, feature in self.keys.items():
                if feature.fqn not in ans:
                    ans[feature.fqn] = feature
        return ans

    @property
    def schema(self) -> pa.Schema:
        assert self.message is not None
        if self.message is bytes:
            raise ValueError(f"Stream resolver {self.fqn} message type is bytes, which has no pyarrow schema")
        return pydantic_to_pyarrow_schema(self.message)  # pyright: ignore -- todo bad types

    @property
    def is_windowed(self):
        return len(self.window_periods) > 0

    @property
    def window_periods(self):
        return list(self.windowed_pseudofeatures.keys())

    @property
    def window_alignments(self):
        # TODO -- support non-epoch alignments
        return [0 for _ in self.window_periods]

    @property
    def max_window_period(self):
        return max(size for size in self.window_periods) if len(self.window_periods) > 0 else 0

    @property
    def state_param(self) -> StreamResolverParamKeyedState | None:
        return next(
            (p for p in self.raw_resolver.signature.params if isinstance(p, StreamResolverParamKeyedState)), None
        )

    def __hash__(self):
        return hash(self.fqn)


def get_list_item_typ(annotation: StreamResolverWindowType):
    assert is_list_typ_annotation(annotation)
    return get_args(annotation)[0]


def is_list_typ_annotation(annotation: StreamResolverWindowType):
    return get_origin(annotation) in (list, List)


@dataclasses.dataclass
class StreamSinkConfigParsed:
    output_features: Collection[TResolverFeatureType]
    format: Literal["json", "ipc_stream"]
    send_to: StreamSource | None
    feature_expressions: Mapping[UnderlyingScalarFeatureType | UnderlyingFeatureTimeFeatureType, UnderscoreValue]


@dataclasses.dataclass
class DeduplicationPolicyParsed:
    expr: Expr
    duration: dt.timedelta


STREAM_RESOLVER_MESSAGE_HEADERS_TYPE = pa.map_(pa.large_utf8(), pa.large_binary())
STREAM_RESOLVER_MESSAGE_ENVELOPE_TYPE = pa.struct(
    [
        pa.field("message_key", pa.large_utf8()),
        pa.field("message_data", pa.large_binary()),
        pa.field("publish_timestamp", pa.timestamp("us", "UTC")),
        pa.field("message_headers", STREAM_RESOLVER_MESSAGE_HEADERS_TYPE),
    ]
)
