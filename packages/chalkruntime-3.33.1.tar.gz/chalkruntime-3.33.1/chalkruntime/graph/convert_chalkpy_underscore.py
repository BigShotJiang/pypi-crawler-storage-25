# pyright: reportPrivateUsage=false

from __future__ import annotations

import dataclasses
import uuid
from dataclasses import dataclass
from datetime import timedelta
from typing import Collection, Literal, Mapping, Protocol, Sequence

import chalk.functions as F
import pyarrow as pa
from _chalk_shared_public.chalk_function_registry import (
    CHALK_FUNCTION_REGISTRY,
    get_chalk_function_registry_overload,
)
from chalk import Now
from chalk._lsp.error_builder import LSPErrorBuilder
from chalk.client.models import ChalkError, ErrorCode, ErrorCodeCategory
from chalk.features.underscore import (
    Underscore,
    UnderscoreAttr,
    UnderscoreCall,
    UnderscoreCast,
    UnderscoreFunction,
    UnderscoreItem,
    UnderscoreRoot,
)
from chalk.features.underscore import Underscore as ChalkpyUnderscore
from chalk.ml.model_reference import ModelReference
from chalk.utils.collections import FrozenOrderedSet
from chalk.utils.duration import parse_chalk_duration
from chalkdf.catalog import get_active_catalog
from frozendict import frozendict

from chalkruntime.graph.feature import (
    FeatureTimeFeatureType,
    GroupByFeatureType,
    HasManyFeatureType,
    HasOneFeatureType,
    NestedFeatureType,
    OutputUnderscoreFeatureType,
    ScalarFeatureType,
    WindowedFeatureType,
    is_underlying_scalar,
)
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.jinja_parser import JinjaInputsSynthesizer
from chalkruntime.graph.materializations import MaterializationWindowConfigParsed, MaterializedAggregationType
from chalkruntime.graph.maybe_named_collection import (
    MaybeNamedCollection,
    MaybeNamedCollectionBuilder,
)
from chalkruntime.graph.prompt_service import PromptService
from chalkruntime.graph.resolver import MainProcOfflineResolver, MainProcOnlineResolver, ResolverParsed
from chalkruntime.graph.sklearn_model_parser import SUPPORTED_MODELS, parse_sklearn_model
from chalkruntime.graph.underscore import (
    CHALK_UNDERSCORE,
    FeatureKeySource,
    FromCppRegCodecInfo,
    UnderscoreCallbackType,
    UnderscoreColumn,
    UnderscoreConstant,
    UnderscoreFeature,
    UnderscoreIncompleteGroupByAggregation,
    UnderscoreItemParsed,
    UnderscoreLambda,
    UnderscoreLambdaParameter,
    UnderscoreMaterializedAggregation,
    UnderscoreMaterializedState,
    UnderscoreMaterializedStateOperation,
    UnderscoreNamespace,
    UnderscoreNever,
    UnderscoreOperation,
    UnderscoreOperationExpression,
    UnderscoreParsed,
    UnderscoreResultDataFrameType,
    UnderscoreResultScalarType,
    UnderscoreTable,
    UnderscoreValidationError,
    UnderscoreValue,
    UnderscoreWindowed,
    get_struct_pack_operation,
    get_struct_subfield_operation,
)
from chalkruntime.graph.underscore_operation_registry import UnderscoreOperationRegistry
from chalkruntime.loader.converter import ConversionException, ConversionExceptionContext
from libchalk.chalkfunction import (
    ArgumentType,
    CallbackType,
    ChalkFunctionOverloadFailed,
    ChalkFunctionOverloadResolved,
    DataFrameParameterType,
)


class RootUnderscoreBehavior(Protocol):
    def make_copy(self) -> RootUnderscoreBehavior: ...
    def parse_root_underscore(
        self,
        underscore: UnderscoreRoot,
        namespace: str,
    ) -> UnderscoreParsed: ...


class ResolverRootUnderscoreBehavior(RootUnderscoreBehavior):
    """
    For underscore expressions used in feature definitions, the 'root' is a feature namespace, so expressions like `_.transactions` mean
    "resolve the 'transactions' feature in the current namespace."
    """

    def make_copy(self) -> ResolverRootUnderscoreBehavior:
        return ResolverRootUnderscoreBehavior()

    def parse_root_underscore(
        self,
        underscore: UnderscoreRoot,
        namespace: str,
    ) -> UnderscoreParsed:
        return UnderscoreNamespace(
            _path=tuple(),
            _root_namespace=namespace,
            original_underscore=underscore,
        )


class StreamResolverRootUnderscoreBehavior(RootUnderscoreBehavior):
    """
    For streaming resolvers whose outputs are defined as underscore expressions, the 'root' is a table
    with a column named 'message', whose dtype is the type of the message per the resolver definition
    (e.g. it could be a struct type corresponding to a proto/BaseModel, or just raw bytes/str)

    Thus, `_.user_id` represents accessing struct field 'user_id' on the input message.
    """

    def __init__(self, message_dtype: pa.DataType):
        super().__init__()
        self._message_dtype: pa.DataType = message_dtype
        self._root_table_schema: pa.Schema = pa.schema({"message_data": message_dtype})

    @property
    def message_dtype(self):
        return self._message_dtype

    def make_copy(self) -> StreamResolverRootUnderscoreBehavior:
        return StreamResolverRootUnderscoreBehavior(message_dtype=self._message_dtype)

    def parse_root_underscore(
        self,
        underscore: UnderscoreRoot,
        namespace: str,
    ) -> UnderscoreParsed:
        """
        :param namespace: In practice this param is set to the root namespace of the stream resolver itself but is not used for anything.
        (all downstream underscore ops are all column projections on a table, w/o any references to actual Chalk Features)
        """
        field_idx = self._root_table_schema.get_field_index("message_data")
        if field_idx < 0:
            raise ValueError(
                f'Column with name "message_data" is not present in input table with schema {self._root_table_schema!r}.'
            )
        return UnderscoreColumn(
            field=self._root_table_schema.field(field_idx),
            column_name="message_data",
            original_underscore=underscore,
            expression_id=underscore._chalk__expr_id,
        )


@dataclass
class UnderscoreConversionContext:
    prompt_service: PromptService | None
    root_underscore_behavior: RootUnderscoreBehavior
    for_offline_resolver: bool


def convert_underscore_expression(
    *,
    underscore: ChalkpyUnderscore,
    for_feature: ScalarFeatureType
    | NestedFeatureType[ScalarFeatureType]
    | FeatureTimeFeatureType
    | NestedFeatureType[FeatureTimeFeatureType]
    | GroupByFeatureType
    | OutputUnderscoreFeatureType
    | None,
    graph: ResolvedGraph,
    prompt_service: PromptService | None,
    root_namespace: str,
    root_underscore_behavior: RootUnderscoreBehavior,
    error_message_context: str | None = None,
    for_offline_resolver: bool,
) -> UnderscoreValue:
    """
    Converts a chalkpy `Underscore` expression into a parsed `UnderscoreValue`.
    """
    if error_message_context is not None:
        name = error_message_context
    elif for_feature is not None:
        name = for_feature
    else:
        name = "N/A"

    with ConversionExceptionContext(obj=underscore, name=f"<underscore expression for {name}>"):
        with UnderscoreValidationError.error_info_context(
            feature_fqn=str(for_feature) if for_feature is not None else None,
            original_underscore=underscore,
        ):
            context = UnderscoreConversionContext(
                prompt_service=prompt_service,
                root_underscore_behavior=root_underscore_behavior,
                for_offline_resolver=for_offline_resolver,
            )
            if (
                isinstance(for_feature, ScalarFeatureType)
                and for_feature.window_config is not None
                and for_feature.window_config.materialization_config is not None
                and not context.for_offline_resolver
            ):
                result = _convert_underscore_materialized_aggregation(
                    underscore=underscore,
                    for_feature=for_feature,
                    window_materialization=for_feature.window_config.materialization_config,
                    window_duration=for_feature.window_config.window_duration,
                    graph=graph,
                    context=context,
                )
                return result
            parsed = _convert_underscore_expression(
                underscore=underscore,
                namespace=root_namespace,
                graph=graph,
                for_feature=for_feature,
                local_scope={},
                parent_op=None,
                context=context,
            )
            if isinstance(parsed, UnderscoreConstant):
                raise ValueError(
                    f"Expected underscore expression to resolve to a non-constant expression, but got constant `{repr(parsed.value)}`"
                )
            if not isinstance(parsed, UnderscoreValue):
                raise ValueError(f"Expected underscore expression to resolve to a value, but got {parsed}.")
            # recursively check that types and paths are valid in subexpressions, erroring gracefully
            _ = parsed.underscore_result_type, parsed.root_namespace
            return parsed


def underscore_operands_to_input_types(
    operation_name: str,
    arg_collection: MaybeNamedCollection[UnderscoreValue | UnderscoreConstant],
    original_underscore: ChalkpyUnderscore | None,
) -> MaybeNamedCollection[ArgumentType]:
    operand_scalar_types = MaybeNamedCollectionBuilder[ArgumentType]()
    for location, operand in MaybeNamedCollection.enumerate(arg_collection):
        operand_type = operand.underscore_result_type
        if isinstance(operand_type, UnderscoreResultScalarType):
            operand_scalar_types.add(location, operand_type.scalar_type)
        elif isinstance(operand_type, UnderscoreCallbackType):
            operand_scalar_types.add(
                location,
                CallbackType(
                    input_types=operand_type.input_parameters,
                    output_type=operand_type.output_type,
                ),
            )
        elif isinstance(operand_type, UnderscoreResultDataFrameType):
            if operand_type.column_types == "all_columns":
                raise ValueError(
                    f"Operand '{operand}' has a column type of 'all_columns', expected a single column name"
                )
            # TODO - arbitrary column names should be supported
            operand_scalar_types.add(
                location, DataFrameParameterType(columns={"series": list(operand_type.column_types.values())[0]})
            )
        else:
            if original_underscore is None:
                raise ValueError(
                    f"Cannot call chalk-synthesized function '{operation_name}' with arguments {arg_collection}"
                )
            if isinstance(location, int):
                raise ValueError(
                    f"Cannot call function '{operation_name}' with non-scalar argument expression '{original_underscore._chalk__args[location]}'"
                )
            raise ValueError(
                f"Cannot call function '{operation_name}' with non-scalar keyword argument expression '{original_underscore._chalk__kwargs[location]}'"
            )
    return operand_scalar_types


def resolve_chalk_registry_overload(
    operation_name: str,
    arg_collection: MaybeNamedCollection[UnderscoreValue | UnderscoreConstant],
    original_underscore: ChalkpyUnderscore | None,
) -> UnderscoreOperationExpression:
    resolved_overload = get_chalk_function_registry_overload(
        function_name=operation_name,
        input_types=underscore_operands_to_input_types(operation_name, arg_collection, original_underscore),
    )

    if resolved_overload is None:
        # This should not happen - the value is only `None` if the underscore function is not
        # in the 'CHALK_FUNCTION_REGISTRY' registry at all.
        raise ValueError(
            f"The underscore function '{original_underscore._chalk__function_name if original_underscore is not None else operation_name}' is not found in the function registry"
        )

    if isinstance(resolved_overload, ChalkFunctionOverloadFailed):
        raise ValueError(f"Invalid function call '{original_underscore}': {resolved_overload.failure_message}")

    if operation_name in {"min_by_n", "max_by_n"}:
        # Crazy hack!
        posargs = getattr(original_underscore, "_chalk__args", [])
        if len(posargs) not in {2, 3}:
            # FIXME(Q-51 cleanup)
            raise ValueError(
                f"Invalid function call '{original_underscore}': expected 3 positional args, got {len(posargs)}"
            )
        parsed_kwargs = FrozenOrderedSet((("k", list(posargs)[-1]),))
    elif operation_name == "approx_top_k":
        # `by=_.weight_feature` is a feature reference, not a literal, so it cannot round-trip
        # through `convert_proto_expr_to_literal` during plan serde. The weight column is
        # already captured in the materialization's `aggregate_on` slot upstream (chalkpy's
        # `_parse_agg_function_call` appends it to `additional_features`)
        parsed_kwargs = FrozenOrderedSet(
            (k, v) for k, v in getattr(original_underscore, "_chalk__kwargs", {}).items() if k != "by"
        )
    else:
        parsed_kwargs = FrozenOrderedSet()

    return UnderscoreOperationExpression(
        operands=arg_collection,
        operation=UnderscoreOperation.from_overload_resolved(
            resolved_overload=resolved_overload,
            codec_info=FromCppRegCodecInfo(function_name=operation_name),
        ),
        original_underscore=original_underscore,
        args=getattr(original_underscore, "_chalk__args", ())
        if operation_name == "approx_percentile"
        else (),  # FIXME: Dominic - hack for  "approx_percentile"
        kwargs=parsed_kwargs,  # TODO(q): Another hack, for `approx_top_k`...
        expression_id=original_underscore._chalk__expr_id if original_underscore is not None else str(uuid.uuid4()),
    )


def resolve_method_chaining(underscore: UnderscoreCall) -> ChalkpyUnderscore | None:
    if not isinstance(underscore._chalk__parent, UnderscoreAttr):
        raise ValueError(f"Cannot call non-attribute {underscore._chalk__parent}.")

    operation_name = underscore._chalk__parent._chalk__attr
    caller = underscore._chalk__parent._chalk__parent
    if (op := getattr(F, operation_name, None)) is not None:
        if getattr(op, "_chalk__method_chaining_predicate", lambda _: True)(underscore):
            if isinstance(caller, UnderscoreRoot):
                raise ValueError(
                    f"Cannot call function '_.{operation_name}(...)' on root '_' - perhaps you meant 'chalk.functions.{operation_name}(...)' instead?"
                )
            resolved_underscore = op(caller, *underscore._chalk__args, **underscore._chalk__kwargs)
            assert isinstance(resolved_underscore, ChalkpyUnderscore), (
                "chalk.functions should always return an Underscore"
            )
            return resolved_underscore

    return None


def _convert_underscore_expression(
    *,
    underscore: ChalkpyUnderscore,
    namespace: str,
    graph: ResolvedGraph,
    for_feature: ScalarFeatureType
    | NestedFeatureType[ScalarFeatureType]
    | FeatureTimeFeatureType
    | NestedFeatureType[FeatureTimeFeatureType]
    | GroupByFeatureType
    | OutputUnderscoreFeatureType
    | None,
    local_scope: Mapping[str, pa.DataType],
    parent_op: str | None,  # used for logic on overloading the ts/duration comparisons
    context: UnderscoreConversionContext,
) -> UnderscoreParsed | UnderscoreConstant:
    """
    Converts the provided `underscore: ChalkpyUnderscore` into an `UnderscoreParsed`.

    `namespace` is used to know which namespace the feature should be resolved in.
    `graph` allows features to be looked up by fqn.
    `for_feature` is used for reporting errors.
    `local_scope` lists lambda parameters available in the current scope and their types.
    Clashing lambda parameter names will be an error.
    """

    def _process_expr(expr: object, parent_op: str | None):
        if not isinstance(expr, ChalkpyUnderscore):
            return UnderscoreConstant(value=expr)
        so = _convert_underscore_expression(
            underscore=expr,
            namespace=namespace,
            graph=graph,
            for_feature=for_feature,
            local_scope=local_scope,
            parent_op=parent_op,
            context=context,
        )
        if not isinstance(so, (UnderscoreValue, UnderscoreConstant)):
            raise ValueError(
                (
                    f"Invalid call to chalk.functions.{parent_op}: "
                    "expected underscore expression to reference scalar feature, "
                    f"got {so} instead."
                )
            )
        return so

    # recursively parse the underscore expression
    if isinstance(underscore, UnderscoreRoot):
        return context.root_underscore_behavior.parse_root_underscore(underscore, namespace)

    elif isinstance(underscore, UnderscoreAttr):
        parent = _convert_underscore_expression(
            underscore=underscore._chalk__parent,
            namespace=namespace,
            graph=graph,
            for_feature=for_feature,
            local_scope=local_scope,
            parent_op=None,
            context=context,
        )

        if isinstance(parent, UnderscoreTable):
            # For a table expression (as opposed to a feature namespace),
            # _.xyz means "get column 'xyz' from the input table."
            field_idx = parent.schema.get_field_index(underscore._chalk__attr)
            if field_idx < 0:
                raise ValueError(
                    f"The underscore expression '{underscore}' cannot be parsed, because the attribute '.{underscore._chalk__attr}' did not correspond to a unique column in the input table. Available colum names: {parent.schema.names}"
                )
            return UnderscoreColumn(
                field=parent.schema.field(field_idx),
                column_name=underscore._chalk__attr,
                original_underscore=underscore,
                expression_id=underscore._chalk__expr_id,
            )

        elif not isinstance(parent, UnderscoreNamespace):
            if isinstance(parent, UnderscoreParsed):
                source = repr(parent.original_underscore)
            else:
                source = repr(parent.value)

            if underscore._chalk__attr == "chalk_now":
                return UnderscoreOperationExpression(
                    operands=MaybeNamedCollectionBuilder(positional_items=[]),
                    operation=UnderscoreOperationRegistry.resolve("chalk_execution_ts", params=frozendict()),
                    original_underscore=underscore,
                    expression_id=underscore._chalk__expr_id,
                )

            if (
                isinstance(parent, (UnderscoreValue, UnderscoreConstant))
                and isinstance(parent.underscore_result_type, UnderscoreResultScalarType)
                and isinstance(parent.underscore_result_type.scalar_type, pa.StructType)
            ):
                field_idx = parent.underscore_result_type.scalar_type.get_field_index(underscore._chalk__attr)
                if field_idx >= 0:
                    field = parent.underscore_result_type.scalar_type.field(field_idx)
                    return UnderscoreOperationExpression(
                        operands=MaybeNamedCollectionBuilder(
                            positional_items=[parent, UnderscoreConstant(value=underscore._chalk__attr)]
                        ),
                        operation=get_struct_subfield_operation(field.type),
                        original_underscore=underscore,
                        expression_id=underscore._chalk__expr_id,
                    )
                else:
                    raise ValueError(
                        f"The underscore expression '{underscore}' cannot be parsed, because the attribute '.{underscore._chalk__attr}' did not correspond to a field in the struct-like feature '{source}'"
                    )
            if isinstance(parent, UnderscoreWindowed) and underscore._chalk__attr == "materialized_state":
                return UnderscoreMaterializedState(
                    original_underscore=underscore, window_feature=parent, scalar_feature=None
                )

            raise ValueError(
                f"The underscore expression '{underscore}' cannot be parsed, because the attribute '.{underscore._chalk__attr}' cannot be accessed on '{source}' because the latter expression does not resolve to a feature namespace."
            )

        if (
            underscore._chalk__attr == "chalk_window"
            and is_underlying_scalar(for_feature)
            and for_feature.underlying.window_config is not None
        ):
            pos_delta = for_feature.underlying.window_config.window_duration
            neg_delta = -for_feature.underlying.window_config.window_duration
            return UnderscoreConstant(value=neg_delta if parent_op in ("<", "<=", ">", ">=") else pos_delta)

        if underscore._chalk__attr == "chalk_now":
            now_feature = graph.fqn_to_feature.get(Now.fqn)
            if not isinstance(now_feature, ScalarFeatureType):
                # This should not happen, but this ensures that we extract the feature with the correct type.
                raise ValueError(f"The 'now' pseudofeature is not a scalar feature type, it is {now_feature}")
            return UnderscoreFeature(
                _path=(),
                underlying=now_feature,
                original_underscore=underscore,
                expression_id=underscore._chalk__expr_id,
            )

        feature = graph.fqn_to_feature.get(parent.underlying + "." + underscore._chalk__attr)
        if feature is None:
            attr_name = underscore._chalk__attr
            if attr_name == "chalk_window":
                raise ValueError(
                    f"Feature `{parent.underlying}.{attr_name}` does not exist; "
                    + "did you mean to use a windowed feature? "
                    + "`_.chalk_window` is a special attribute that can be used "
                    + "to access the window duration of a windowed feature."
                )
            raise ValueError(f"Feature `{parent.underlying}.{attr_name}` does not exist")

        if isinstance(feature, HasManyFeatureType) or isinstance(feature, HasOneFeatureType):
            return UnderscoreNamespace(
                _path=parent.path + (feature,),
                original_underscore=underscore,
            )
        elif isinstance(feature, ScalarFeatureType) or isinstance(feature, FeatureTimeFeatureType):
            return UnderscoreFeature(
                _path=tuple(x for x in parent.path if isinstance(x, HasOneFeatureType)),
                underlying=feature,
                original_underscore=underscore,
                expression_id=underscore._chalk__expr_id,
            )
        elif isinstance(feature, WindowedFeatureType):
            return UnderscoreWindowed(
                _path=tuple(x for x in parent.path if isinstance(x, HasOneFeatureType)),
                underlying=feature,
                original_underscore=underscore,
            )
        elif isinstance(feature, GroupByFeatureType):  # pyright: ignore[reportUnnecessaryIsInstance]
            # TODO: The has_many should actually be configured on the `GroupByFeatureType`.
            # But we probably can't find it right now.
            matching_has_manys: list[HasManyFeatureType] = []
            for f in graph.get_features_in_namespace(namespace):
                if (
                    isinstance(f, HasManyFeatureType)
                    and f.foreign_namespace() == feature.window_materialization.namespace
                ):
                    matching_has_manys.append(f)

            if len(matching_has_manys) == 0:
                raise ValueError(
                    f"Missing has_many feature on namespace '{namespace}' to match underscore expression '{underscore}' which aggregates namespace '{feature.window_materialization.namespace}'; found candidates {[f.foreign_namespace() for f in graph.get_features_in_namespace(namespace) if isinstance(f, HasManyFeatureType)]}"
                )
            if len(matching_has_manys) >= 2:
                raise ValueError(
                    f"Ambiguous has_many features on namespace '{namespace}' to match underscore expression '{underscore}': got {matching_has_manys}"
                )
            matching_has_many = matching_has_manys[0]

            window_duration: timedelta | None = None
            if (
                isinstance(for_feature, ScalarFeatureType)
                and for_feature.is_windowed_pseudofeature
                and for_feature.window_config is not None
            ):
                if round(for_feature.window_config.window_duration.total_seconds()) not in feature.windows:
                    raise ValueError(
                        (
                            f"Feature {for_feature} has a window duration of {for_feature.window_config.window_duration}, "
                            f"which is not one of the allowed values for the feature {feature.windows}."
                        )
                    )
                window_duration = for_feature.window_config.window_duration

            return UnderscoreIncompleteGroupByAggregation(
                original_underscore=underscore,
                has_many=matching_has_many,
                materialization=feature.window_materialization,
                group_features=None,
                window_duration=window_duration,
                source_aggregation_namespace=namespace,
                allowed_window_values=tuple(timedelta(seconds=t) for t in feature.windows),
                expression_id=underscore._chalk__expr_id,
            )
        else:
            raise ValueError(f"Feature type {feature} is not supported in underscore expression.")

    elif isinstance(underscore, UnderscoreItem):
        parent = _convert_underscore_expression(
            underscore=underscore._chalk__parent,
            namespace=namespace,
            graph=graph,
            for_feature=for_feature,
            local_scope=local_scope,
            parent_op=None,
            context=context,
        )
        keys = underscore._chalk__key
        assert isinstance(keys, tuple)
        if isinstance(parent, UnderscoreIncompleteGroupByAggregation):
            if parent.window_duration is not None:
                raise ValueError(
                    f"The sub-expression '{underscore}' is invalid because the windowed group-by expression '{parent.original_underscore}' already has a window specified"
                )
            if len(keys) != 1:
                raise ValueError(
                    f"The sub-expression '{underscore}' is invalid because only a single window value can be selected, but {len(keys)} values were selected"
                )
            window_value = keys[0]
            if not isinstance(window_value, str):
                raise ValueError(
                    f"The sub-expression '{underscore}' is invalid because the provided window value `{window_value}` is not a string"
                )

            try:
                window_duration = parse_chalk_duration(window_value)
            except Exception as e:
                raise ValueError(
                    f"Unable to parse window expression {repr(window_value)} as Chalk duration: {e}"
                ) from e

            if window_duration not in parent.allowed_window_values:
                raise ValueError(
                    f"The sub-expression '{underscore}' is invalid because the provided window value `{window_value}` ({repr(window_duration)}) is not one of the allowed values for the feature {parent.allowed_window_values}"
                )

            return parent.replace_window(window_duration)

        feature_keys_parsed: list[UnderscoreValue] = []
        filters_parsed: list[UnderscoreOperationExpression] = []
        for key in keys:
            # This loop handles two broad cases:
            #   (1) windowed access: _.num_seen_trains["1d"]
            #   (2) projection & filtering on has-many: _.all_trains[_.id, _.color == "red"]

            if (
                isinstance(key, UnderscoreAttr)
                and key._chalk__attr == "chalk_window"
                and isinstance(for_feature, ScalarFeatureType)
                and for_feature.window_config is not None
            ):
                # `_.chalk_window` can be used as a key that matches the window duration of `for_feature`:
                #
                # seen_over_count: Windowed[int] = windowed(
                #     "1d", "30d",
                #     expression=(
                #        _.num_seen_trains[_.chalk_window] /
                #        _.num_trains[_.chalk_window]
                #     )
                # )
                key = for_feature.window_config.window_duration

            if isinstance(parent, UnderscoreWindowed) and isinstance(key, (str, int, timedelta)):
                # Case (1): Handle _.seen_trains["1d"]; raise if someone tries _.seen_trains["1d", "7d"].
                # This if branch early returns since we know there is only a single elem in 'keys'

                if len(keys) != 1:
                    raise ValueError(
                        f"When indexing a windowed feature using a time-window, only a single key inside {str(parent.underlying)}[...] is supported. Instead, received multiple: {keys}."
                    )

                feature_fqn = parent.get_windowed_feature_fqn(key)
                feature = graph.fqn_to_feature.get(feature_fqn)
                if feature is None:
                    raise ValueError(f"Feature {feature_fqn} does not exist")
                if not isinstance(feature, ScalarFeatureType):
                    raise ValueError(
                        f"Feature {feature_fqn} should be a scalar feature, as it is a window from a windowed feature."
                    )
                return UnderscoreFeature(
                    _path=parent._path,
                    underlying=feature,
                    original_underscore=underscore,
                    expression_id=underscore._chalk__expr_id,
                )

            if (
                isinstance(parent, UnderscoreMaterializedState)
                and parent.scalar_feature is None
                and isinstance(key, (str, int, timedelta))
            ):
                if len(keys) != 1:
                    raise ValueError(
                        f"When indexing a windowed feature using a time-window, only a single key inside {str(parent.original_underscore)}[...] is supported. Instead, received multiple: {keys}."
                    )

                feature_fqn = parent.window_feature.get_windowed_feature_fqn(key)
                feature = graph.feature_from_fqn(feature_fqn)
                if feature is None:
                    raise ValueError(f"Feature {feature_fqn} does not exist")
                if not isinstance(feature, ScalarFeatureType):
                    raise ValueError(
                        f"Feature {feature_fqn} should be a scalar feature, as it is a window from a windowed feature."
                    )

                return dataclasses.replace(parent, scalar_feature=feature)

            elif isinstance(key, ChalkpyUnderscore):
                # Case (2): Handle _.all_trains[_.id, _.color == "red"]
                if not isinstance(parent, UnderscoreNamespace):
                    raise ValueError(
                        f"Cannot project or filter a non has-many feature '{parent}'. Attempting to access {parent}[{key}] is invalid."
                    )

                has_manys = [join for join in parent._path if isinstance(join, HasManyFeatureType)]
                if len(has_manys) == 0:
                    raise ValueError(
                        f"Cannot access {parent.original_underscore}[{key}] using '__getitem__' because the underlying namespace reference '{parent.original_underscore}' is not a has-many relationship. Use attribute notation (e.g. {parent.original_underscore}.{key}) instead."
                    )

                key_parsed = _convert_underscore_expression(
                    underscore=key,
                    namespace=parent.underlying,
                    graph=graph,
                    for_feature=for_feature,
                    local_scope=local_scope,
                    parent_op=None,
                    context=context,
                )
                if isinstance(key_parsed, UnderscoreConstant):
                    raise ValueError(
                        f"Cannot get constant `{repr(key_parsed.value)}` as column from namespace expression."
                    )
                if not isinstance(key_parsed, UnderscoreValue):
                    raise ValueError("Cannot get namespace item. Use nested notation (e.g. _.y[_.z[_.a]]) instead.)")

                if isinstance(key_parsed, UnderscoreOperationExpression):
                    filters_parsed.append(key_parsed)
                    # TODO: We need to eventually move to an explicit 'filter' syntax, so that we can select
                    # non-feature columns too.
                elif isinstance(key_parsed, UnderscoreFeature):
                    feature_keys_parsed.append(key_parsed)
                else:
                    raise ValueError(f"Unexpected index for {parent}: {key}")

            else:
                raise ValueError(f"Invalid key {key} in underscore expression {underscore}")

        feature_key_source = FeatureKeySource.explicit
        if len(feature_keys_parsed) == 0 and isinstance(parent, UnderscoreNamespace) and len(filters_parsed) > 0:
            # If no column is explicitly selected but there are some filters, synthesize the primary key
            # as the selected column instead.
            primary_key = graph.primary_feature_for_namespace(parent.underlying)
            if primary_key is not None and len(filters_parsed) > 0:
                feature_key_source = FeatureKeySource.inferred
                feature_keys_parsed = [
                    UnderscoreFeature(
                        underlying=primary_key,
                        _path=(),
                        original_underscore=underscore,
                        expression_id=str(uuid.uuid4()),
                    )
                ]

        if len(feature_keys_parsed) == 0:
            raise ValueError(f"Must select at least one column from {parent}, but selected no columns.")

        # Redundant isinstance check to satisfy Pyright; can only be in this condition if parent is a HasManyFeatureType.
        if not isinstance(parent, UnderscoreNamespace):
            raise ValueError(f"Cannot project or filter a non has-many feature '{parent}'.")

        return UnderscoreItemParsed(
            parent=parent,
            feature_keys=feature_keys_parsed,
            filters=tuple(filters_parsed),
            original_underscore=underscore,
            feature_key_source=feature_key_source,
            expression_id=underscore._chalk__expr_id,
        )

    elif isinstance(underscore, UnderscoreCall):
        if not isinstance(underscore._chalk__parent, UnderscoreAttr):
            raise ValueError(f"Cannot call non-attribute {underscore._chalk__parent}.")

        if (method_underscore := resolve_method_chaining(underscore)) is not None:
            return _convert_underscore_expression(
                underscore=method_underscore,
                namespace=namespace,
                graph=graph,
                for_feature=for_feature,
                local_scope=local_scope,
                parent_op=parent_op,
                context=context,
            )

        operation_name = underscore._chalk__parent._chalk__attr
        caller = underscore._chalk__parent._chalk__parent

        parent = _convert_underscore_expression(
            underscore=caller,
            namespace=namespace,
            graph=graph,
            for_feature=for_feature,
            local_scope=local_scope,
            parent_op=None,
            context=context,
        )

        if operation_name == "where" and isinstance(parent, UnderscoreValue):
            if not isinstance(parent.underscore_result_type, UnderscoreResultDataFrameType):
                raise ValueError(
                    f"Cannot call filter function `.where(...)` on non-dataframe underscore expression `{repr(parent)}` inside of underscore expression `{repr(underscore)}`"
                )

            if len(underscore._chalk__kwargs) != 0:
                raise ValueError(
                    f"Cannot call filter function `.where(...)` with keyword arguments in expression `{repr(underscore)}`"
                )
            if len(underscore._chalk__args) == 0:
                raise ValueError(
                    f"Cannot call filter function `.where(...)` without passing in any filter expressions to `{repr(underscore)}`"
                )

            if not isinstance(parent, UnderscoreItemParsed):
                raise ValueError(
                    f"Cannot call filter function `.where(...)` on non-dataframe underscore feature `{repr(parent)}` inside of underscore expression `{repr(underscore)}`"
                )

            # Evaluate each of the filters as underscore expressions in the target namespace.

            filter_values: list[UnderscoreOperationExpression] = []
            for arg in underscore._chalk__args:
                if len(parent.feature_keys) == 0:
                    raise ValueError("Must select at least one feature from a namespace")
                for feature_key in parent.feature_keys:
                    if feature_key.root_namespace is None:
                        raise ValueError(
                            f"The feature column '{feature_key.original_underscore}' is invalid because it does not belong to the relationship's namespace in '{parent.original_underscore}'"
                        )
                namespace = parent.feature_keys[0].root_namespace  # pyright: ignore[reportAssignmentType]
                assert namespace is not None, "feature_key should have associated namespace"
                arg_converted = _convert_underscore_expression(
                    underscore=arg,
                    namespace=namespace,
                    graph=graph,
                    for_feature=for_feature,
                    local_scope=local_scope,
                    parent_op=None,
                    context=context,
                )
                if not isinstance(arg_converted, UnderscoreValue):
                    raise ValueError(
                        f"Cannot filter by constant `{repr(arg)}` inside of `.where(...)` function call in underscore expression `{repr(underscore)}`"
                    )

                if not isinstance(arg_converted.underscore_result_type, UnderscoreResultScalarType):
                    raise ValueError(
                        f"Cannot filter by non-scalar underscore expression `{repr(arg)}` inside of `.where(...)` function call in underscore expression `{repr(underscore)}`"
                    )

                if arg_converted.underscore_result_type.scalar_type != pa.bool_():
                    raise ValueError(
                        f"Cannot filter by non-boolean underscore expression `{repr(arg)}` of type '{arg_converted.underscore_result_type.scalar_type}' inside of `.where(...)` function call in underscore expression `{repr(underscore)}`"
                    )

                if not isinstance(arg_converted, UnderscoreOperationExpression):
                    raise ValueError(
                        f"Cannot filter by plain feature underscore expression - `{repr(arg)}` inside of `.where(...)` clause; add `== True` to make this a valid filter in underscore expression `{repr(underscore)}`"
                    )

                filter_values.append(arg_converted)

            return UnderscoreItemParsed(
                parent=parent.parent,
                feature_keys=parent.feature_keys,
                feature_key_source=parent.feature_key_source,
                filters=(*parent.filters, *filter_values),
                original_underscore=underscore,
                expression_id=underscore._chalk__expr_id,
            )

        if isinstance(parent, UnderscoreConstant):
            raise ValueError(f"Cannot call constant expression `{repr(parent.value)}`")

        if isinstance(parent, UnderscoreIncompleteGroupByAggregation):
            if parent.group_features is not None:
                raise ValueError(
                    f"The sub-expression '{underscore}' is invalid, because '{parent.original_underscore}' already specifies its groups"
                )

            if operation_name != "group":
                raise ValueError(
                    f"The sub-expression '{underscore}' is invalid, because '{operation_name}' is not an operation available on a partially-configured windowed aggregation underscore expression"
                )

            if len(underscore._chalk__args) != 0:
                raise ValueError(
                    f"The sub-expression '{underscore}' is invalid, because '.group()' must only be given keyword arguments corresponding to the columns {parent.materialization.group_by}, but got {len(underscore._chalk__args)} position argument(s)"
                )

            # If we have an agg by foreign columns (foreign.foo, foreign.bar, foreign.qux) then we
            # expect the kwargs to be 'foo', 'bar', and 'qux'.
            #
            # Except that at least one of them MUST be the has_many foreign join key, so that argument
            # will be provided by our local join key automatically, instead of coming from the args here.

            def _fqn_to_kwarg(fqn: str) -> str:
                return fqn.split(".")[-1]

            kwarg_name_to_fqn: dict[str, str] = {}
            for expected_feat in parent.materialization.group_by:
                short_kwarg_name = _fqn_to_kwarg(expected_feat.fqn)
                if short_kwarg_name in kwarg_name_to_fqn:
                    raise ValueError(
                        f"The group-by expression '{underscore}' is invalid and unusable, because multiple of the configured join columns '{parent.materialization.group_by}' are the same"
                    )
                kwarg_name_to_fqn[short_kwarg_name] = expected_feat.fqn

            # CHA-4857
            implicit_join_kwargs = [
                _fqn_to_kwarg(foreign_feat.root_fqn) for foreign_feat in parent.has_many.get_foreign_join_features()
            ]
            for i, implicit_join_kwarg in enumerate(implicit_join_kwargs):
                if implicit_join_kwarg not in kwarg_name_to_fqn:
                    raise ValueError(
                        f"The group-by expression '{underscore}' is invalid and unusable, because the foreign join key '{parent.has_many.get_foreign_join_features()[i]}' from the has_many relationship '{parent.has_many}' is not one of the expected group-by features {parent.materialization.group_by}"
                    )

            expected_args_str = ", ".join(
                f"{kwarg}=..." for kwarg in kwarg_name_to_fqn.keys() if kwarg not in implicit_join_kwargs
            )

            kwarg_to_feature_map: dict[str, ScalarFeatureType | NestedFeatureType[ScalarFeatureType]] = {}

            for kwarg_name, kwarg_value in underscore._chalk__kwargs.items():
                if kwarg_name not in kwarg_name_to_fqn:
                    raise ValueError(
                        f"The group-by expression '{underscore}' is invalid because the keyword argument '{kwarg_name}' is not expected; we expect the keyword arguments ({expected_args_str})"
                    )
                if kwarg_name in implicit_join_kwargs:
                    raise ValueError(
                        f"The group-by expression '{underscore}' is invalid because the keyword argument '{kwarg_name}' is not expected; it is provided automatically the has_many relationship '{parent.has_many}'; we expect the keyword arguments ({expected_args_str})"
                    )
                if not isinstance(kwarg_value, UnderscoreAttr):
                    raise ValueError(
                        f"The group-by expression '{underscore}' is invalid because the keyword argument '{kwarg_name}' has an invalid value {repr(kwarg_value)}; an underscore expression representing a feature in the namespace '{namespace}' must be provided"
                    )

                kwarg_feature = _convert_underscore_expression(
                    underscore=kwarg_value,
                    namespace=namespace,
                    graph=graph,
                    for_feature=for_feature,
                    local_scope=local_scope,
                    parent_op=None,
                    context=context,
                )
                if not isinstance(kwarg_feature, UnderscoreFeature):
                    raise ValueError(
                        f"The group-by expression '{underscore}' is invalid because the keyword argument '{kwarg_name}' has an invalid value {repr(kwarg_value)}; an underscore expression representing a scalar feature in the namespace '{namespace}' must be provided"
                    )
                if not is_underlying_scalar(kwarg_feature.input_feature):
                    raise ValueError(
                        f"The group-by expression '{underscore}' is invalid because the keyword argument '{kwarg_name}' has an invalid value {repr(kwarg_value)}; an underscore expression representing a scalar feature in the namespace '{namespace}' must be provided, but got a non-scalar feature '{kwarg_feature.input_feature}'"
                    )
                kwarg_to_feature_map[kwarg_name] = kwarg_feature.input_feature

            group_features: dict[str, ScalarFeatureType | NestedFeatureType[ScalarFeatureType]] = {}
            foreign_fqns = [foreign_feat.root_fqn for foreign_feat in parent.has_many.get_foreign_join_features()]
            for group in parent.materialization.group_by:
                # CHA-4857
                if group.fqn in foreign_fqns:
                    idx = foreign_fqns.index(group.fqn)
                    group_features[group.fqn] = parent.has_many.get_local_join_features()[idx]
                else:
                    group_kwarg = _fqn_to_kwarg(group.fqn)
                    if group_kwarg not in kwarg_to_feature_map:
                        raise ValueError(
                            f"The group-by expression '{underscore}' is invalid because the keyword argument '{group_kwarg}' is missing; the keyword argument(s) ({expected_args_str}) are expected"
                        )
                    group_features[group.fqn] = kwarg_to_feature_map[group_kwarg]

            return parent.replace_group_features(frozendict(group_features))

        if isinstance(parent, UnderscoreMaterializedState):
            if operation_name != "sparse_buckets":
                raise ValueError(
                    f"The sub-expression '{underscore}' is invalid, because '{operation_name}' is not an operation available on materialized aggregation state"
                )

            if len(underscore._chalk__args) > 0 or not set(underscore._chalk__kwargs).issubset({"window"}):
                raise ValueError("sparse_buckets() only accepts a single keyword argument 'window'")

            scalar_feature = parent.get_scalar_feature(graph)
            if (
                scalar_feature.underscore_expression is None
                or scalar_feature.window_config is None
                or scalar_feature.window_config.materialization_config is None
            ):
                raise ValueError(
                    f"Cannot access materialized state for '{parent.window_feature.underlying}' because it does not refer to a materialized aggregation"
                )

            # TODO: this is redundant but best way to stay consistent
            underlying_mat_agg = _convert_underscore_materialized_aggregation(
                underscore=scalar_feature.underscore_expression,
                for_feature=scalar_feature,
                graph=graph,
                window_duration=scalar_feature.window_config.window_duration,
                window_materialization=scalar_feature.window_config.materialization_config,
                context=context,
            )

            mat_agg_def = underlying_mat_agg

            if (window := underscore._chalk__kwargs.get("window")) is not None:
                window_underscore = _process_expr(window, operation_name)
                if not isinstance(window_underscore, UnderscoreConstant):
                    raise ValueError("'window' argument should be a constant expression")
                window_expr = window_underscore.value
                if not isinstance(window_expr, (str, int, timedelta)):
                    raise ValueError("'window' argument should represent a duration")

                try:
                    window_duration = parse_chalk_duration(window_expr)
                except Exception as e:
                    raise ValueError("Failed to parse 'window' argument as a duration") from e

                mat_agg_def = dataclasses.replace(mat_agg_def, window_duration=window_duration)

            return UnderscoreMaterializedStateOperation(
                expression_id=underscore._chalk__expr_id,
                original_underscore=underscore,
                mat_agg_definition=mat_agg_def,
                for_offline_resolver=context.for_offline_resolver,
            )

        if (
            operation_name == "count"
            and isinstance(parent, UnderscoreNamespace)
            and isinstance(parent.path[-1], HasManyFeatureType)
            and len(underscore._chalk__args) == 0
            and len(underscore._chalk__kwargs) == 0
        ):
            """
            If the user writes `_.accounts.count()`, we can treat this as `_.accounts[_.id].count()`
            by looking up the primary key for the foreign namespace.

            This is a special case provided for convenience, since other dataframe operations like
            `.sum()` only work when selecting a single column.
            """
            foreign_namespace = parent.path[-1].foreign_namespace()
            foreign_pkey = graph.primary_feature_for_namespace(foreign_namespace)
            if foreign_pkey is not None:
                parent = UnderscoreItemParsed(
                    parent=parent,
                    feature_keys=[
                        UnderscoreFeature(
                            underlying=foreign_pkey,
                            _path=(),
                            original_underscore=underscore,
                            expression_id=str(uuid.uuid4()),
                        )
                    ],
                    original_underscore=underscore,
                    feature_key_source=FeatureKeySource.explicit,
                    expression_id=str(uuid.uuid4()),
                )

        if (
            operation_name != "count"
            and isinstance(parent, UnderscoreItemParsed)
            and parent.feature_key_source == FeatureKeySource.inferred
        ):
            raise ValueError(
                f"The operation '{operation_name}' must specify a column to operate on, but none was provided"
                if operation_name != "agg"
                else "The operation 'agg' should be preceded by a `.group_by()`"
            )

        if not isinstance(parent, UnderscoreValue):
            if (
                isinstance(parent.original_underscore, UnderscoreRoot)
                and isinstance(parent, UnderscoreNamespace)
                and parent.path == ()
            ):
                raise ValueError(
                    f"Cannot call function '_.{operation_name}(...)' on root '_' - perhaps you meant 'chalk.functions.{operation_name}(...)' instead?"
                )
            raise ValueError(
                f"Cannot compute method '{operation_name}' called on non-value expression '{parent.original_underscore}' in expression `{underscore}`."
            )

        # If our call function is one of the max_by's, then we need to add in the other columns
        if operation_name in ("max_by", "min_by", "max_by_n", "min_by_n"):
            if not isinstance(parent, UnderscoreItemParsed):
                raise ValueError(f"'{operation_name}' must be called on a column")
            if len(underscore._chalk__args) <= 0:
                raise ValueError(f"'{operation_name}' must have at least one argument")
            if parent.feature_keys[0].root_namespace is None:
                raise ValueError(f"'{operation_name}' must be called with a feature with a valid parent namespace")
            column_arg = _convert_underscore_expression(
                underscore=underscore._chalk__args[0],
                namespace=parent.feature_keys[0].root_namespace,
                graph=graph,
                for_feature=for_feature,
                local_scope=local_scope,
                parent_op=parent_op,
                context=context,
            )
            if not isinstance(column_arg, UnderscoreValue):
                raise ValueError(
                    f"Expected first argument to '{operation_name}' to be an UnderscoreValue, received '{type(column_arg)}'"
                )
            additional_args: list[UnderscoreValue | UnderscoreConstant] = [column_arg]
            if len(underscore._chalk__args) == 2:
                n_arg = _process_expr(underscore._chalk__args[1], parent_op)
                if not isinstance(n_arg, UnderscoreConstant):
                    raise ValueError(f"2nd argument to of '{operation_name}' must be constant")
                additional_args.append(n_arg)
        else:
            additional_args: list[UnderscoreValue | UnderscoreConstant] = []

        arg_collection = MaybeNamedCollectionBuilder(positional_items=[parent, *additional_args])

        if operation_name in CHALK_FUNCTION_REGISTRY:
            return resolve_chalk_registry_overload(operation_name, arg_collection, underscore)

        raise ValueError(f"Unsupported underscore operation: '{operation_name}'")

    elif isinstance(underscore, UnderscoreFunction):
        operation_name = underscore._chalk__function_name
        if (model_config := SUPPORTED_MODELS.get(operation_name, None)) is not None:
            # for model parsing, it is easier to first parse the model and then convert it to an expression:
            # we do that here
            if "model_path" not in underscore._chalk__kwargs:
                raise ValueError(
                    f"Invalid call to chalk.functions.{operation_name}: expected argument 'model_path', got {underscore._chalk__kwargs} instead."
                )

            model_parsed_underscore = parse_sklearn_model(
                *underscore._chalk__args, model_config=model_config, **underscore._chalk__kwargs
            )

            return convert_underscore_expression(
                underscore=model_parsed_underscore,
                for_feature=for_feature,
                graph=graph,
                prompt_service=context.prompt_service,
                root_underscore_behavior=context.root_underscore_behavior,
                root_namespace=namespace,
                for_offline_resolver=context.for_offline_resolver,
            )
        if operation_name == "inference":
            if not {"model", "inputs"}.issubset(underscore._chalk__kwargs.keys()) and len(underscore._chalk__args) != 1:
                raise ValueError(
                    f"Invalid call to chalk.functions.inference: expected two keyword argument 'model' and 'inputs', got {underscore._chalk__kwargs} instead."
                )
            model = underscore._chalk__kwargs.get("model", None)
            _ = underscore._chalk__kwargs.get("inputs", None)
            if not isinstance(model, ModelReference):
                raise ValueError(
                    f"Invalid call to chalk.functions.inference: expected first argument to be a ModelReference, got {repr(model)} instead."
                )

            raise ValueError("Invalid model type provided to F.inference")

        if underscore._chalk__function_name == "lambda":
            # This is a special syntactic form, not a genuine function call.
            num_args = len(underscore._chalk__args)
            if len(underscore._chalk__kwargs) != 0 or num_args < 3 or (num_args % 2) != 1:
                raise ValueError(
                    f"Illegal lambda expression: must have at least 3 and an odd number positional arguments and  , got {underscore}"
                )

            *lambda_parameters, lambda_body = underscore._chalk__args

            parameters_cleaned: dict[str, pa.pa.DataType] = {}

            for i in range(len(lambda_parameters) // 2):
                lambda_parameter_name, lambda_parameter_type = lambda_parameters[2 * i : 2 * i + 2]
                if not isinstance(lambda_parameter_name, str):
                    raise ValueError(
                        f"The first argument to the 'lambda' constructor must be a `str` parameter name, but got {repr(lambda_parameter_name)} instead"
                    )
                if not isinstance(lambda_parameter_type, (pa.DataType, pa.Scalar)):
                    raise ValueError(
                        f"The second argument to the 'lambda' constructor must be a null-valued `pyarrow.Scalar` or `pyarrow.DataType` parameter type, but got {repr(lambda_parameter_type)} instead"
                    )
                if isinstance(lambda_parameter_type, pa.Scalar):
                    # Scalar values are just used as placeholders for their types.
                    lambda_parameter_type = lambda_parameter_type.type

                if lambda_parameter_name in local_scope:
                    raise ValueError(
                        (
                            f"The lambda parameter '{lambda_parameter_name}: {lambda_parameter_type}' shadows enclosing parameter lambda "
                            f"'{lambda_parameter_name}: {local_scope[lambda_parameter_name]}' which is not permitted - "
                            "give these lambda parameters different names"
                        )
                    )

                parameters_cleaned[lambda_parameter_name] = lambda_parameter_type

            if not isinstance(lambda_body, ChalkpyUnderscore):
                raise ValueError(
                    f"The third argument to the 'lambda' constructor must be an underscore expression, but got {repr(lambda_body)} instead"
                )

            converted_lambda_body = _convert_underscore_expression(
                underscore=lambda_body,
                namespace=namespace,
                graph=graph,
                for_feature=for_feature,
                local_scope={
                    **local_scope,
                    # Add in the new parameter to the scope.
                    **parameters_cleaned,
                },
                parent_op=None,
                context=context,
            )
            if isinstance(converted_lambda_body, UnderscoreConstant):
                raise ValueError(f"Lambda body cannot be constant expression, but got '{lambda_body}'")

            if not isinstance(converted_lambda_body, UnderscoreValue):
                raise ValueError(f"Lambda body must be a scalar underscore expression, but got '{lambda_body}'")

            return UnderscoreLambda(
                parameters=tuple(parameters_cleaned.items()),
                lambda_body=converted_lambda_body,
                original_underscore=underscore,
                expression_id=underscore._chalk__expr_id,
            )

        if underscore._chalk__function_name == "lambda_parameter":
            # This is a special syntactic form, not a genuine function call.
            if len(underscore._chalk__kwargs) != 0 or len(underscore._chalk__args) != 2:
                raise ValueError(
                    f"Illegal lambda parameter expression: must have 2 positional arguments, got {underscore}"
                )

            (lambda_parameter_name, lambda_parameter_type) = underscore._chalk__args
            if not isinstance(lambda_parameter_name, str):
                raise ValueError(
                    f"The first argument to the 'lambda' constructor must be a `str` parameter name, but got {repr(lambda_parameter_name)} instead"
                )
            if not isinstance(lambda_parameter_type, (pa.Scalar, pa.DataType)):
                raise ValueError(
                    f"The second argument to the 'lambda' constructor must be a null-valued `pyarrow.Scalar` or `pyarrow.DataType` parameter type, but got {repr(lambda_parameter_type)} instead"
                )

            if isinstance(lambda_parameter_type, pa.Scalar):
                lambda_parameter_type = lambda_parameter_type.type

            if lambda_parameter_name not in local_scope:
                raise ValueError(
                    f"The lambda parameter value '{lambda_parameter_name}: {lambda_parameter_type}' is not in scope in the underscore expression '{underscore}' - the enclosing lambda expression is missing"
                )
            if local_scope[lambda_parameter_name] != lambda_parameter_type:
                raise ValueError(
                    f"The lambda parameter value '{lambda_parameter_name}: {lambda_parameter_type}' has the wrong type; the expected type is '{local_scope[lambda_parameter_name]}' - the enclosing lambda expression expression might be incorrect"
                )

            return UnderscoreLambdaParameter(
                parameter_name=lambda_parameter_name,
                parameter_type=lambda_parameter_type,
                original_underscore=underscore,
                expression_id=underscore._chalk__expr_id,
            )

        parsed_args: list[UnderscoreValue | UnderscoreConstant] = []
        parsed_kwargs: dict[str, UnderscoreValue | UnderscoreConstant] = {}
        operation_name = underscore._chalk__function_name
        if operation_name in ("min_by", "max_by", "min_by_n", "max_by_n"):
            # For max_by and min_by, second operand is in the namespace of the has-many
            if len(underscore._chalk__args) == 2:
                val1, val2 = underscore._chalk__args
                val3 = None
            else:
                assert len(underscore._chalk__args) == 3
                val1, val2, val3 = underscore._chalk__args
            op1 = _process_expr(val1, underscore._chalk__function_name)
            assert isinstance(op1, UnderscoreItemParsed)
            op2 = _convert_underscore_expression(
                underscore=val2,
                namespace=op1.parent.underlying,
                graph=graph,
                for_feature=for_feature,
                local_scope=local_scope,
                parent_op=None,
                context=context,
            )
            assert isinstance(op2, UnderscoreValue)
            parsed_args.append(op1)
            parsed_args.append(op2)
            if val3 is not None:
                op3 = _process_expr(val3, underscore._chalk__function_name)
                if not isinstance(op3, UnderscoreConstant):
                    raise TypeError(
                        f"third argument to {operation_name} must be a constant, received {op3}"
                    )  # n parameter of max/min_by_n is a constant
                parsed_args.append(op3)
        else:
            for arg in underscore._chalk__args:
                parsed_args.append(_process_expr(arg, underscore._chalk__function_name))
            for k, v in underscore._chalk__kwargs.items():
                parsed_kwargs[k] = _process_expr(v, underscore._chalk__function_name)

        operation_name = underscore._chalk__function_name

        # Handle bool == (0, 1) comparisons
        if len(parsed_args) == 2 and operation_name in ("==", "!="):
            for op1, op2 in (parsed_args, reversed(parsed_args)):
                if (
                    isinstance(op1, UnderscoreFeature)
                    and isinstance(op1.underscore_result_type, UnderscoreResultScalarType)
                    and op1.underscore_result_type.scalar_type == pa.bool_()
                    and isinstance(op2, UnderscoreConstant)
                    and op2.underscore_result_type.scalar_type in (pa.int8(), pa.int16(), pa.int32(), pa.int64())
                ):
                    if op2.value not in (0, 1):
                        raise ValueError(
                            f"Comparison of boolean feature with int constant only allowed if the constant is 0 or 1, received {op2.value}"
                        )
                    parsed_args = [op1, UnderscoreConstant(value=op2.value == 1)]

        # Handle negative timedelta comparisons
        if len(parsed_args) == 2 and operation_name in ("<", "<=", ">", ">="):
            for i, (op1, op2) in enumerate((parsed_args, reversed(parsed_args))):
                if (
                    isinstance(op1, UnderscoreFeature)
                    and isinstance(op1.underscore_result_type, UnderscoreResultScalarType)
                    and op1.underscore_result_type.scalar_type == pa.timestamp("us", "UTC")
                    and isinstance(op2, UnderscoreConstant)
                    and op2.underscore_result_type.scalar_type == pa.duration("us")
                ):
                    now_feat = graph.fqn_to_feature.get(Now.fqn)
                    assert isinstance(now_feat, ScalarFeatureType) or isinstance(now_feat, FeatureTimeFeatureType)
                    now_feature_underscore = UnderscoreFeature(
                        _path=(),
                        underlying=now_feat,
                        original_underscore=underscore,
                        expression_id=str(uuid.uuid4()),
                    )
                    # Reverse the timedelta
                    if isinstance(op2.value, timedelta):
                        op2 = UnderscoreConstant(value=-op2.value)
                    implicit_subtraction_underscore = resolve_chalk_registry_overload(
                        operation_name="-",
                        arg_collection=MaybeNamedCollectionBuilder([now_feature_underscore, op2]),
                        original_underscore=underscore,
                    )
                    parsed_args = (
                        [implicit_subtraction_underscore, op1] if i == 1 else [op1, implicit_subtraction_underscore]
                    )

        if operation_name == "if_else":
            if isinstance(for_feature, ScalarFeatureType):
                if_true = parsed_args[1]
                if_false = parsed_args[2]
                if if_false == UnderscoreConstant(None):
                    if_false = UnderscoreConstant(None, default_pa_type=for_feature.primitive_converter.pyarrow_dtype)
                if if_true == UnderscoreConstant(None):
                    if_true = UnderscoreConstant(None, default_pa_type=for_feature.primitive_converter.pyarrow_dtype)
                parsed_args = [parsed_args[0], if_true, if_false]

        elif operation_name == "struct_pack":
            if not isinstance(parsed_args[0], UnderscoreConstant):
                raise ValueError(
                    f"First argument to struct_pack must be a constant value, but got {parsed_args[0]} instead"
                )
            struct_names = parsed_args[0].value
            if isinstance(struct_names, pa.Scalar):
                # Attempt to unpack the scalar into a pylist
                if not pa.types.is_list(struct_names.type) and not pa.types.is_large_list(struct_names.type):
                    raise ValueError(
                        f"First argument to struct_pack was an arrow scalar, but the arrow scalar should be a list of strings representing struct field names, the scalar was of type {struct_names.type} instead"
                    )
                assert isinstance(struct_names.type, (pa.ListType, pa.LargeListType)), (
                    "struct_names datatype should be list or large list"
                )
                child_type = struct_names.type.value_type
                if not pa.types.is_string(child_type) and not pa.types.is_large_string(child_type):
                    raise ValueError(
                        f"First argument to struct_pack was an arrow scalar, but the arrow scalar should be a list of strings representing struct field names, the scalar was of type {struct_names.type} instead"
                    )
                struct_names = struct_names.as_py()  # At this point, this will guarantee return us a list of strings
            if not isinstance(struct_names, Collection):
                raise ValueError(
                    f"First argument to struct_pack must be an iterable of strings representing struct field names, but got {type(struct_names)} instead"
                )
            for name in struct_names:
                if not isinstance(name, str):
                    raise ValueError(
                        f"First argument to struct_pack must be an iterable of strings, but element {name} was of type {type(name)}"
                    )
            if len(struct_names) != len(parsed_args) - 1:
                raise ValueError(
                    f"Invalid struct_pack call: got {len(struct_names)} field names, but got {len(parsed_args) - 1} field values"
                )
            struct_values = parsed_args[1:]
            for value in struct_values:
                if not isinstance(value.underscore_result_type, UnderscoreResultScalarType):
                    raise ValueError(
                        f"Invalid struct_pack call: all field values must be scalar types, but field {value} is of type {type(value)}"
                    )
            return UnderscoreOperationExpression(
                operands=MaybeNamedCollectionBuilder(struct_values),
                operation=get_struct_pack_operation(
                    tuple(struct_names),
                    tuple(value.underscore_result_type.scalar_type for value in struct_values),  # pyright: ignore[reportAttributeAccessIssue]
                ),
                args=tuple(struct_names),
                original_underscore=underscore,
                expression_id=underscore._chalk__expr_id,
            )

        elif operation_name == "run_prompt" and context.prompt_service is not None:
            if len(underscore._chalk__args) != 0:
                raise ValueError("No positional arguments are allowed to `F.run_prompt` in the underscore expression")
            if "prompt_id" in underscore._chalk__kwargs:
                prompt_id = underscore._chalk__kwargs["prompt_id"]
                if not isinstance(prompt_id, int):
                    raise ValueError(
                        f"The `prompt_id` argument to `F.run_prompt` must be a constant integer, not {prompt_id}"
                    )
                actual_prompt = context.prompt_service.get_prompt_by_id_sync(prompt_id)
                if actual_prompt is None:
                    feature_fqn: str | None = None
                    if isinstance(for_feature, OutputUnderscoreFeatureType):
                        feature_fqn = for_feature.output_name
                    elif for_feature is not None:
                        feature_fqn = for_feature.fqn
                    return UnderscoreNever(
                        expression_id=underscore._chalk__expr_id,
                        original_underscore=underscore,
                        root_namespace_=namespace,
                        error=invalid_underscore_error(
                            f"Prompt with ID {prompt_id} does not exist",
                            feature_fqn=feature_fqn,
                        ),
                    )
            elif "prompt_name" in underscore._chalk__kwargs:
                prompt_name = underscore._chalk__kwargs["prompt_name"]
                if not isinstance(prompt_name, str):
                    raise ValueError(
                        f"The `prompt_name` argument to `F.run_prompt` must be a constant string, not {prompt_name}"
                    )
                actual_prompt = context.prompt_service.get_prompt_by_name_sync(prompt_name)
                if actual_prompt is None:
                    feature_fqn: str | None = None
                    if isinstance(for_feature, OutputUnderscoreFeatureType):
                        feature_fqn = for_feature.output_name
                    elif for_feature is not None:
                        feature_fqn = for_feature.fqn

                    return UnderscoreNever(
                        expression_id=underscore._chalk__expr_id,
                        original_underscore=underscore,
                        root_namespace_=namespace,
                        error=invalid_underscore_error(
                            f"Prompt with name '{prompt_name}' does not exist",
                            feature_fqn=feature_fqn,
                        ),
                    )
            else:
                raise ValueError("Exactly one of `id` or `name` must be provided to `F.run_prompt`")
            actual_prompt._chalk__expr_id = underscore._chalk__expr_id
            return _convert_underscore_expression(
                underscore=actual_prompt,
                for_feature=for_feature,
                namespace=namespace,
                graph=graph,
                local_scope=local_scope,
                parent_op="run_prompt",
                context=context,
            )

        elif operation_name == "jinja":
            if underscore._chalk__args:
                raise ValueError(
                    f"Invalid call to chalk.functions.jinja: expected no positional arguments, got {underscore._chalk__args} instead."
                )
            if set(underscore._chalk__kwargs) != {"template"}:
                raise ValueError(
                    f"Invalid call to chalk.functions.jinja: expected argument 'template', got {underscore._chalk__kwargs} instead."
                )
            template = underscore._chalk__kwargs["template"]
            if not isinstance(template, str):
                raise ValueError(
                    f"Invalid call to chalk.functions.jinja: expected 'template' argument to be a string, got {template} instead."
                )
            input_op = JinjaInputsSynthesizer().compute_input(jinja_string=template, namespace=namespace, graph=graph)
            operands = MaybeNamedCollectionBuilder((parsed_kwargs["template"], input_op))
            if not isinstance(input_op.underscore_result_type, UnderscoreResultScalarType):
                raise ValueError(f"Input to jinja function must be a scalar, but got {input_op.underscore_result_type}")
            operand_types = MaybeNamedCollectionBuilder(
                (pa.large_string(), input_op.underscore_result_type.scalar_type)
            )
            resolved_overload = get_chalk_function_registry_overload(function_name="jinja", input_types=operand_types)
            if not isinstance(resolved_overload, ChalkFunctionOverloadResolved):
                raise ValueError(f"Failed to find overload for jinja function: {resolved_overload}")
            return UnderscoreOperationExpression(
                original_underscore=underscore,
                operation=UnderscoreOperation.from_overload_resolved(
                    resolved_overload=resolved_overload,
                    codec_info=FromCppRegCodecInfo(function_name="jinja"),
                ),
                operands=operands,
                expression_id=underscore._chalk__expr_id,
            )

        elif operation_name == "catalog_call":
            # F.catalog_call(qualified_name, *args)
            # Extract qualified_name as first positional argument
            if not underscore._chalk__args or len(underscore._chalk__args) < 1:
                raise ValueError("catalog_call requires at least one argument (qualified_name)")

            qualified_name_arg = underscore._chalk__args[0]
            if not isinstance(qualified_name_arg, str):
                raise ValueError(
                    f"First argument to catalog_call must be a constant string (qualified_name), got {type(qualified_name_arg)}"
                )

            qualified_name = qualified_name_arg

            # Extract and convert remaining arguments
            if len(underscore._chalk__args) < 2:
                raise ValueError("catalog_call requires at least one data argument besides qualified_name")

            parsed_args = []
            for arg in underscore._chalk__args[1:]:
                parsed_arg = _process_expr(arg, parent_op="catalog_call")
                if not isinstance(parsed_arg, UnderscoreValue):
                    raise ValueError(f"Arguments to catalog_call must be value expressions, got {type(parsed_arg)}")
                parsed_args.append(parsed_arg)

            # Check for an explicit output_type hint (e.g. for model/resolver FQNs
            # that aren't in the local catalog).
            output_dtype = underscore._chalk__kwargs.get("output_type")

            if output_dtype is None:
                catalog = get_active_catalog()
                catalog_entry = catalog.get(qualified_name)
                if catalog_entry is None:
                    raise ValueError(f"catalog entry not found for {qualified_name}")
                output_dtype = catalog_entry.output_type

            if not isinstance(output_dtype, pa.DataType):
                raise ValueError(f"catalog_call output_type must be a pa.DataType, got {type(output_dtype)}")

            # Create an operation expression for catalog_call
            operands = MaybeNamedCollectionBuilder(positional_items=parsed_args)

            operation = UnderscoreOperationRegistry.resolve(
                "catalog_call",
                frozendict(
                    {
                        "qualified_name": qualified_name,
                        "output_type": output_dtype,
                    }
                ),
            )

            return UnderscoreOperationExpression(
                original_underscore=underscore,
                operation=operation,
                operands=operands,
                expression_id=underscore._chalk__expr_id,
            )

        elif operation_name == "call_resolver":
            # F.call_resolver(resolver_fqn, output_type, *args)
            if len(underscore._chalk__args) < 2:
                raise ValueError("call_resolver requires at least two arguments (resolver_fqn, output_type)")

            resolver_fqn_arg = underscore._chalk__args[0]
            if not isinstance(resolver_fqn_arg, str):
                raise ValueError(
                    f"First argument to call_resolver must be a constant string (resolver_fqn), got {type(resolver_fqn_arg)}"
                )

            output_type_arg = underscore._chalk__args[1]
            if not isinstance(output_type_arg, pa.DataType):
                raise ValueError(
                    f"Second argument to call_resolver must be a pa.DataType (output_type), got {type(output_type_arg)}"
                )

            parsed_args = []
            for arg in underscore._chalk__args[2:]:
                parsed_arg = _process_expr(arg, parent_op="call_resolver")
                if not isinstance(parsed_arg, UnderscoreValue):
                    raise ValueError(f"Arguments to call_resolver must be value expressions, got {type(parsed_arg)}")
                parsed_args.append(parsed_arg)

            operands = MaybeNamedCollectionBuilder(positional_items=parsed_args)

            operation = UnderscoreOperationRegistry.resolve(
                "call_resolver",
                frozendict(
                    {
                        "resolver_fqn": resolver_fqn_arg,
                        "output_type": output_type_arg,
                    }
                ),
            )

            return UnderscoreOperationExpression(
                original_underscore=underscore,
                operation=operation,
                operands=operands,
                expression_id=underscore._chalk__expr_id,
            )

        arg_collection = MaybeNamedCollectionBuilder(
            positional_items=parsed_args,
            named_items=parsed_kwargs,
        )
        del parsed_args
        del parsed_kwargs

        if operation_name in CHALK_FUNCTION_REGISTRY:
            return resolve_chalk_registry_overload(operation_name, arg_collection, underscore)

        raise ValueError(f"Unsupported underscore operation: '{operation_name}'")

    elif isinstance(underscore, UnderscoreCast):
        singular_op = _convert_underscore_expression(
            underscore=underscore._chalk__value,
            namespace=namespace,
            graph=graph,
            for_feature=for_feature,
            local_scope=local_scope,
            parent_op=None,
            context=context,
        )
        if not isinstance(singular_op, UnderscoreValue):
            raise ValueError(
                f"Invalid call to chalk.functions.cast: expected first argument to be a scalar feature, got {singular_op} instead."
            )

        return UnderscoreOperationExpression(
            operands=MaybeNamedCollectionBuilder(positional_items=[singular_op]),
            operation=UnderscoreOperationRegistry.resolve(
                function_name="cast", params=frozendict({"_chalk__to_type": underscore._chalk__to_type})
            ),
            original_underscore=underscore,
            expression_id=underscore._chalk__expr_id,
        )

    raise TypeError(f"Unsupported underscore: {underscore}")


def _convert_underscore_materialized_aggregation(
    *,
    underscore: ChalkpyUnderscore,
    for_feature: ScalarFeatureType,
    graph: ResolvedGraph,
    window_duration: timedelta,
    window_materialization: MaterializationWindowConfigParsed,
    context: UnderscoreConversionContext,
) -> UnderscoreMaterializedAggregation:
    # First, attempt to resolve the underscore expression in the ordinary way.
    resolved_underscore = _convert_underscore_expression(
        underscore=underscore,
        namespace=for_feature.root_namespace,
        graph=graph,
        for_feature=for_feature,
        local_scope={},
        parent_op=None,
        context=context,
    )

    if not isinstance(resolved_underscore, UnderscoreOperationExpression):
        raise ValueError("A windowed materialized aggregate expression must end in an aggregation expression")

    if window_materialization.aggregation in (MaterializedAggregationType.MaxByN, MaterializedAggregationType.MinByN):
        if not resolved_underscore.operands.has_exactly_n_and_only_positional_items(3):
            raise ValueError(
                f"The windowed aggregation operation '{window_materialization.aggregation}' accepts 3 positional arguments, but received {len(resolved_underscore.operands.positional_items)} arguments"
            )
        # The second argument is the comparator column (the `by=` feature): min/max_by_n
        # picks the top-N rows by this column.
        first_arg = resolved_underscore.operands.positional_items[1]
        if not isinstance(first_arg, UnderscoreFeature):
            raise ValueError(f"The second argument to '{window_materialization.aggregation}' should be a feature")
    elif not resolved_underscore.operands.has_exactly_n_and_only_positional_items(1):
        raise ValueError(
            f"The windowed aggregation operation '{window_materialization.aggregation}' only accepts a single positional argument, but received {len(resolved_underscore.operands.positional_items)} arguments"
        )

    aggregate_operand = resolved_underscore.operands.positional_items[0]

    if not isinstance(aggregate_operand, UnderscoreItemParsed):
        raise ValueError(
            f"The windowed aggregation operation '{window_materialization.aggregation}' can only be applied to a has-many with a single selected column"
        )

    # TODO: we can double-check that this matches the aggregate in the window, but it should
    _aggregate_key = aggregate_operand.feature_keys[0]

    aggregate_hasmany_parsed = aggregate_operand.parent
    if len(aggregate_hasmany_parsed.path) != 1:
        raise ValueError(
            f"The windowed aggregation operation '{window_materialization.aggregation}' can only be applied to a has-many, not a nested relationship"
        )

    aggregate_hasmany: HasOneFeatureType | HasManyFeatureType = aggregate_hasmany_parsed.path[0]

    if isinstance(aggregate_hasmany, HasOneFeatureType):
        raise ValueError(
            f"The windowed aggregation operation '{window_materialization.aggregation}' can only be applied to a has-many, not to a has-one relationship '{aggregate_hasmany}'"
        )

    return UnderscoreMaterializedAggregation(
        unmaterialized_underscore=resolved_underscore,
        original_underscore=underscore,
        materialization=window_materialization,
        group_by_keys=(*aggregate_hasmany.get_local_join_features(),),
        window_duration=window_duration,
        source_aggregation_namespace=for_feature.root_namespace,
        has_many=aggregate_hasmany,
        expression_id=underscore._chalk__expr_id,
    )


def get_underscore_fqn_from_feature_fqn(
    feature_fqn: str,
    *,
    resolver_kind: Literal["online", "offline"],
    tag: str | None = None,
) -> str:
    resolver_fqn = f"{CHALK_UNDERSCORE}.{feature_fqn.replace('dot', '_odot_').replace('.', '_dot_')}"

    if resolver_kind == "offline":
        resolver_fqn += "_offline"

    if tag is not None:
        resolver_fqn += f"_{tag}"

    return resolver_fqn


def underscore_to_online_resolver(
    *,
    underscore: UnderscoreValue,
    for_feature: ScalarFeatureType,
    tag: str | None,
    graph: ResolvedGraph,
) -> ResolverParsed:
    source_line: int | None = None
    if (
        underscore.original_underscore is not None
        and underscore.original_underscore._chalk_definition_location is not None
    ):
        source_line = underscore.original_underscore._chalk_definition_location.line
    return MainProcOnlineResolver(
        function_definition=repr(underscore.original_underscore),
        module=None,
        source_line=source_line,
        function_captured_globals={},
        filename="",
        # resolvers are identified by the last segment of their fqn, so we need to make sure it's unique
        fqn=get_underscore_fqn_from_feature_fqn(for_feature.fqn, resolver_kind="online", tag=tag),
        doc=str(underscore),
        input_refs=underscore.inputs,
        state=None,
        output_refs=[for_feature],
        fn=underscore.fn,
        environment=None,
        is_generator=False,
        resource_hint="cpu",
        tags=tuple() if tag is None else (tag,),
        machine_type=None,
        synthetic_inputs=FrozenOrderedSet(),
        default_args=[None for _ in underscore.inputs],
        owner=for_feature.owner,
        graph=graph,
        timeout=None,
        cron=None,
        cron_filter=None,
        when=None,
        data_sources=(),
        underscore_definition=underscore,
        static=False,
        # Underscore resolvers are technically static, but we set static=False so we'll instead use the underscore compilation logic
        accelerate_python="never",  # Underscore resolvers aren't python resolvers in the first place
        is_total=False,
        unique_on=FrozenOrderedSet(),
        partitioned_by=FrozenOrderedSet(),
        static_operation=None,
        sql_settings=None,
        incremental_settings=None,
        is_externally_defined=False,
        output_row_order=None,
        venv=None,
        postprocessing=None,
    )


def underscore_to_offline_resolver(
    *,
    underscore: UnderscoreValue,
    for_feature: ScalarFeatureType,
    graph: ResolvedGraph,
) -> ResolverParsed:
    source_line: int | None = None
    if (
        underscore.original_underscore is not None
        and underscore.original_underscore._chalk_definition_location is not None
    ):
        source_line = underscore.original_underscore._chalk_definition_location.line
    return MainProcOfflineResolver(
        function_definition=repr(underscore.original_underscore),
        source_line=source_line,
        function_captured_globals={},
        module=None,
        filename="",
        # resolvers are identified by the last segment of their fqn, so we need to make sure it's unique
        fqn=get_underscore_fqn_from_feature_fqn(feature_fqn=for_feature.fqn, resolver_kind="offline"),
        doc=str(underscore),
        input_refs=underscore.inputs,
        state=None,
        is_generator=False,
        output_refs=[for_feature],
        fn=underscore.fn,
        environment=None,
        resource_hint="cpu",
        tags=tuple(),
        machine_type=None,
        synthetic_inputs=FrozenOrderedSet(),
        default_args=[None for _ in underscore.inputs],
        owner=for_feature.owner,
        graph=graph,
        timeout=None,
        cron=None,
        cron_filter=None,
        when=None,
        data_sources=(),
        underscore_definition=underscore,
        static=False,
        # Underscore resolvers are technically static, but we set static=False so we'll instead use the underscore compilation logic
        accelerate_python="never",  # Underscore resolvers aren't python resolvers in the first place
        is_total=False,
        unique_on=FrozenOrderedSet(),
        partitioned_by=FrozenOrderedSet(),
        static_operation=None,
        sql_settings=None,
        incremental_settings=None,
        is_externally_defined=False,
        output_row_order=None,
        venv=None,
        postprocessing=None,
    )


def _apply_coalesce_default(
    feature_type: ScalarFeatureType, underscore_value: UnderscoreValue, underscore_expression: Underscore
):
    if (
        feature_type.primitive_converter.has_default
        and feature_type.primitive_converter.primitive_default is not None
        and (feature_type.window_config is None or feature_type.window_config.materialization_config is None)
    ):
        cast_underscore = F.cast(underscore_expression, feature_type.primitive_converter.pyarrow_dtype)
        return resolve_chalk_registry_overload(
            operation_name="coalesce",
            arg_collection=MaybeNamedCollectionBuilder(
                positional_items=[
                    UnderscoreOperationExpression(
                        operands=MaybeNamedCollectionBuilder(positional_items=[underscore_value]),
                        operation=UnderscoreOperationRegistry.resolve(
                            function_name="cast",
                            params=frozendict({"_chalk__to_type": feature_type.primitive_converter.pyarrow_dtype}),
                        ),
                        original_underscore=cast_underscore,
                        expression_id=cast_underscore._chalk__expr_id,
                    ),
                    UnderscoreConstant(
                        value=feature_type.primitive_converter.primitive_default,
                        default_pa_type=feature_type.primitive_converter.pyarrow_dtype,
                    ),
                ]
            ),
            original_underscore=F.coalesce(cast_underscore, feature_type.primitive_converter.primitive_default),
        )
    else:
        return underscore_value


def scalar_feature_types_to_resolvers(
    scalars: Sequence[ScalarFeatureType],
    graph: ResolvedGraph,
) -> list[ResolverParsed]:
    resolvers: list[ResolverParsed] = []
    for feature_type in scalars:
        try:
            online_underscore_expression = feature_type.underscore_expression
            offline_underscore_expression = (
                feature_type.offline_underscore_expression
                if feature_type.offline_underscore_expression is not None
                else online_underscore_expression
            )

            if online_underscore_expression is not None:
                underscore_value_online = _apply_coalesce_default(
                    feature_type,
                    convert_underscore_expression(
                        underscore=online_underscore_expression,
                        for_feature=feature_type,
                        graph=graph,
                        prompt_service=None,
                        root_namespace=feature_type.root_namespace,
                        root_underscore_behavior=ResolverRootUnderscoreBehavior(),
                        for_offline_resolver=False,
                    ),
                    online_underscore_expression,
                )
                resolvers.append(
                    underscore_to_online_resolver(
                        underscore=underscore_value_online,
                        for_feature=feature_type,
                        tag=None,
                        graph=graph,
                    )
                )
                if (
                    isinstance(underscore_value_online, UnderscoreMaterializedAggregation)
                    and underscore_value_online.unmaterialized_underscore is not None
                ):
                    tag_flagged_online_resolver = underscore_to_online_resolver(
                        underscore=underscore_value_online.unmaterialized_underscore,
                        for_feature=feature_type,
                        tag="unit_testing",
                        graph=graph,
                    )
                    resolvers.append(tag_flagged_online_resolver)
            if offline_underscore_expression is not None:
                underscore_value_offline = _apply_coalesce_default(
                    feature_type,
                    convert_underscore_expression(
                        underscore=offline_underscore_expression,
                        for_feature=feature_type,
                        graph=graph,
                        prompt_service=None,
                        root_namespace=feature_type.root_namespace,
                        root_underscore_behavior=ResolverRootUnderscoreBehavior(),
                        for_offline_resolver=True,
                    ),
                    offline_underscore_expression,
                )
                resolvers.append(
                    underscore_to_offline_resolver(
                        underscore=underscore_value_offline,
                        for_feature=feature_type,
                        graph=graph,
                    )
                )

        except ConversionException as ce:
            if LSPErrorBuilder.lsp and ce.is_lsp_error:
                continue
            raise ce

    return resolvers


def invalid_underscore_error(message: str, feature_fqn: str | None) -> ChalkError:
    return ChalkError.create(
        code=ErrorCode.INVALID_QUERY,
        category=ErrorCodeCategory.FIELD,
        message=message,
        feature=feature_fqn,
    )
