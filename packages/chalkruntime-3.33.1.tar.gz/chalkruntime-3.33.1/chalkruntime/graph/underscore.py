from __future__ import annotations

import dataclasses
import functools
import uuid
from abc import ABC, abstractmethod
from contextlib import contextmanager
from datetime import timedelta
from enum import Enum
from functools import cached_property
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    List,
    Literal,
    Optional,
    Sequence,
    Tuple,
    TypeAlias,
    TypeVar,
    Union,
    cast,
)

import pyarrow as pa
from chalk.client.models import ChalkError
from chalk.features._encoding.primitive import TPrimitive
from chalk.features._encoding.pyarrow import rich_to_pyarrow
from chalk.features.dataframe import DataFrame
from chalk.features.pseudofeatures import PSEUDONAMESPACE, Now
from chalk.features.underscore import Underscore as ChalkpyUnderscore
from chalk.features.underscore import UnderscoreRoot
from chalk.utils.collections import FrozenOrderedSet, OrderedSet, get_unique_item, unwrap_optional
from frozendict import frozendict

from chalkruntime.graph.feature import (
    DataFrameType,
    FeatureFqnMarker,
    FeatureTimeFeatureType,
    FilterParsed,
    HasManyFeatureType,
    HasOneFeatureType,
    HasOnePathObjParsed,
    InputFeatureType,
    NamedFeatureType,
    NestedFeatureType,
    ScalarFeatureType,
    UnderlyingHasManyFeatureType,
    WindowedFeatureType,
    is_underlying_feature_time,
    is_underlying_has_many,
    is_valid_operation,
    required_features_to_sample,
)
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.materializations import (
    MaterializationWindowConfigParsed,
    convert_materialized_aggregation_type_to_timeseries_rule_aggregation_type,
)
from chalkruntime.graph.maybe_named_collection import (
    MaybeNamedCollection,
    MaybeNamedCollectionBuilder,
)
from chalkruntime.graph.underscore_codec_info import (
    FromCppRegCodecInfo,
    UnderscoreOperationCodecInfo,
)

if TYPE_CHECKING:
    from chalkruntime.graph.chalk_overload import ChalkFunctionOverloadResolved

NamespacePath = Tuple[HasOneFeatureType | HasManyFeatureType, ...]

CHALK_UNDERSCORE = "__chalk_underscore__"


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreResultScalarType:
    """
    The type of scalar expression, like `_.id` or `_.hasmany.count()`.
    """

    scalar_type: pa.DataType

    def __str__(self) -> str:
        return f"{self.scalar_type}"


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreResultDataFrameType:
    """
    The type of a dataframe expression, like `_.hasmany` or `_.hasmany[_.id, _.color == 'red']`
    """

    column_types: (
        Literal["all_columns"]
        | frozendict[HasManyFeatureType | NestedFeatureType[HasManyFeatureType] | str, pa.DataType]
    )

    def __str__(self) -> str:
        if self.column_types == "all_columns":
            return "DataFrame[*]"
        return "DataFrame[" + ", ".join(str(column_type) for column_type in self.column_types) + "]"


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreSpecialCaseType:
    """
    This type is used for expression which are intermediates, and therefore must be special-cased.
    In general, if an underscore expression produces a result of this type, it must be wrapped
    and converted by a parent expression before it can be used.

    For example, if we define a group-by feature like
    ```
    num_theorem_lines_by_author: DataFrame = group_by_windowed(
        "30d",
        "90d",
        materialization={
            "bucket_duration": "1d",
        },
        expression=_.theorems.group_by(_.author).agg(_.num_lines.sum()),
    )
    ```
    and then we refer to the feature `_.num_theorem_lines_by_author` in the larger
    expression `_.num_theorem_lines_by_author["30d"]`, the inner expression produces
    a special form that can be composed with the `"30d"` to include the window time,
    and then must be composed again with `.group(author = ...)` in order to produce
    a properly scalar expression.
    """


@dataclasses.dataclass(kw_only=True, frozen=True)
class UnderscoreCallbackType:
    """
    This is the type of a callback.
    Currently, callbacks are restricted to have scalar inputs and scalar outputs.
    """

    input_parameters: tuple[pa.DataType, ...]

    output_type: pa.DataType


UnderscoreResultType = (
    UnderscoreResultScalarType | UnderscoreResultDataFrameType | UnderscoreCallbackType | UnderscoreSpecialCaseType
)
"""
The result type of an underscore expression.
It is either a scalar or a dataframe.
"""


def _infer_pa_scalar(obj: object) -> pa.Scalar:
    """
    Construct a pyarrow scalar from a Python value.
    Manual conversion here because:
    (1) when obj is a dict, pa.scalar(obj) returns a struct by default instead of a map
    (2) Chalk function registry has preferences defined by rich_to_pyarrow
    """
    try:
        if isinstance(obj, dict):
            key_val = rich_to_pyarrow(type(next(iter(obj))), "key")
            for v in obj.values():
                if v is not None:
                    value_type = _infer_pa_scalar(v).type
                    return pa.scalar(obj, type=pa.map_(key_val, value_type))
            return pa.scalar(obj, type=pa.map_(key_val, pa.null()))
        elif isinstance(obj, (list, set, frozenset, tuple)):
            for v in obj:
                if v is not None:
                    value_type = _infer_pa_scalar(v).type
                    return pa.scalar(obj, type=pa.large_list(value_type))
            return pa.scalar(obj, type=pa.large_list(pa.null()))
        else:
            return pa.scalar(obj, type=rich_to_pyarrow(type(obj), "python_type"))
    except Exception:
        return pa.scalar(obj)


@dataclasses.dataclass(frozen=True)
class UnderscoreConstant:
    value: object
    default_pa_type: Optional[pa.DataType] = None

    def __post_init__(self):
        assert not isinstance(self.value, UnderscoreParsed)

    @cached_property
    def pa_value(self):
        if self.default_pa_type:
            return pa.scalar(self.value, type=self.default_pa_type)
        else:
            # Alternative: Try to coerce this python value to the desired type
            return _infer_pa_scalar(self.value)

    @property
    def root_namespace(self):
        raise NotImplementedError

    @cached_property
    def underscore_result_type(self) -> UnderscoreResultScalarType:
        return UnderscoreResultScalarType(scalar_type=self.pa_value.type)

    @cached_property
    def pretty(self):
        return f"'{self.value}'" if isinstance(self.value, str) else str(self.value)


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreParsed(ABC):
    """
    An underscore expression type. This is the "client-facing" side for an underscore expression.
    It contains type and path information and abstracts away the actual operation this represents.
    """

    @cached_property
    @abstractmethod
    def root_namespace(self) -> str | None:
        """
        The root namespace is `None` if no namespace is used.
        """
        ...

    # Some synthesized underscores do not have an original_underscore
    original_underscore: ChalkpyUnderscore | None = dataclasses.field(compare=False)

    @property
    def pretty(self) -> str:
        if self.original_underscore:
            return str(self.original_underscore)
        return str(self)


UnderscoreInputFeatureType = (
    ScalarFeatureType
    | FeatureTimeFeatureType
    | HasManyFeatureType
    | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
)


@dataclasses.dataclass(frozen=True, kw_only=True)
class DataFrameResultType:
    """
    This is used to represent the type of intermediate expressions which are dataframes.
    """

    ...


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreImplicitDependencies:
    has_named_prompts: bool

    @staticmethod
    def merge(*dependencies: UnderscoreImplicitDependencies) -> UnderscoreImplicitDependencies:
        return UnderscoreImplicitDependencies(
            has_named_prompts=any(dep.has_named_prompts for dep in dependencies),
        )

    @staticmethod
    def empty() -> UnderscoreImplicitDependencies:
        return UnderscoreImplicitDependencies(
            has_named_prompts=False,
        )


UnderscoreId: TypeAlias = str


@dataclasses.dataclass(frozen=True)
class UnderscoreValue(UnderscoreParsed, ABC):
    """
    An underscore expression which underlies a value.
    All underscore expressions are either values or namespaces.
    E.g. _.a: int, _.y[_.b]: DataFrame[int], _.a + _.b are underscore value.
    """

    expression_id: UnderscoreId = dataclasses.field(compare=False, repr=False)

    @cached_property
    @abstractmethod
    def underscore_result_type(self) -> UnderscoreResultType:
        """
        The type of the result of this expression.

        Expressions can either produce scalars or dataframes, though dataframes can
        currently only be used as intermediate expressions.

        For example, `_.hasmany` is a dataframe, so it cannot be used as a complete
        resolver expression, but `_.hasmany.count()` is a legal scalar-result underscore.
        """
        raise NotImplementedError

    @cached_property
    @abstractmethod
    def inputs(
        self,
    ) -> Tuple[UnderscoreInputFeatureType, ...]:
        """Features which are used to compute this"""
        raise NotImplementedError

    @abstractmethod
    def fn(self, *args: Any, **kwargs: Any) -> object:
        """
        The function which computes this from inputs. The output of fn is scalar at the root namespace level.
        Has-many inputs are DataFrames, but outputs are pa.array. Scalar input/outputs are python values.
        Used to convert a underscore expression into a resolver.
        """
        raise NotImplementedError

    @cached_property
    @abstractmethod
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        """
        The implicit dependencies of this underscore expression.
        """
        ...


@dataclasses.dataclass(frozen=True)
class UnderscoreNamespace(UnderscoreParsed):
    """
    An underscore expression which underlies a feature class.
    E.g. _.y: DataFrame[Y], _.z: Z, _: X are underscore namespaces.
    """

    _path: NamespacePath
    _root_namespace: Optional[str] = None

    def __post_init__(self):
        if len(self._path) == 0:
            assert self._root_namespace is not None
        else:
            for i, x in enumerate(self._path[:-1]):
                # assert isinstance(x, HasOneFeatureType), "underscore namespace must be a has-one (TODO: remove this restriction)"
                assert x.foreign_namespace() == self._path[i + 1].namespace
            assert self._root_namespace is None

    @cached_property
    def path(self) -> NamespacePath:
        return self._path

    @cached_property
    def namespace_path_shape(self) -> tuple[HasManyFeatureType, ...]:
        return tuple(x for x in self._path if isinstance(x, HasManyFeatureType))

    @cached_property
    def root_namespace(self) -> str:
        return self._root_namespace or self.path[0].namespace

    @cached_property
    def underlying(self) -> str:
        return self._root_namespace or self.path[-1].foreign_namespace()


@dataclasses.dataclass(frozen=True)
class UnderscoreTable(UnderscoreParsed):
    """
    Represents a table w/ a specific schema, but not tied to a specific Chalk feature or namespace.
    Similar to UnderscoreNamespace in that it is a 'root' node that downstream underscore operations can use as inputs.
    """

    @cached_property
    def root_namespace(self) -> str | None:
        return None

    schema: pa.Schema


_FeatureT = TypeVar("_FeatureT", bound=ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType)


def make_input_feature_type(
    underlying: _FeatureT,
    path: NamespacePath,
) -> _FeatureT | InputFeatureType[_FeatureT]:
    """
    Converts a FeatureType + a path to it from root namespace, into an InputFeatureType
    If the path is empty, returns the underlying FeatureType
    """
    if len(path) == 0:
        return underlying
    expanded_path: List[HasOnePathObjParsed] = []
    for i, node in enumerate(path):
        next_node = path[i + 1] if i + 1 < len(path) else underlying
        expanded_path.append(HasOnePathObjParsed(node, next_node))
    return InputFeatureType(underlying_ref=underlying, path=tuple(expanded_path), _graph=underlying.graph)


@dataclasses.dataclass(frozen=True)
class UnderscoreFeature(UnderscoreValue):
    """
    An underscore expression which underlies a feature, with no computation on top of it.
    E.g. _.a: int, _.y.b are underscore features.
    """

    underlying: ScalarFeatureType | FeatureTimeFeatureType
    _path: NamespacePath

    def __post_init__(self):
        # These happen to be always scalarish because non-scalarish features are only declared with indexing syntax
        for i, x in enumerate(self._path):
            assert isinstance(x, HasOneFeatureType)
            if i < len(self._path) - 1:
                assert x.foreign_namespace() == self._path[i + 1].namespace
            else:
                assert x.foreign_namespace() == self.underlying.namespace

    @cached_property
    def underscore_result_type(self) -> UnderscoreResultType:
        if isinstance(self.underlying, ScalarFeatureType):
            return UnderscoreResultScalarType(scalar_type=self.underlying.pyarrow_dtype)
        elif isinstance(self.underlying, FeatureTimeFeatureType):  # pyright: ignore[reportUnnecessaryIsInstance]
            return UnderscoreResultScalarType(scalar_type=pa.timestamp("us", "UTC"))
        raise NotImplementedError

    @cached_property
    def root_namespace(self) -> str:
        return self.input_feature.root_namespace

    @cached_property
    def input_feature(self) -> UnderscoreInputFeatureType:
        return make_input_feature_type(self.underlying, self._path)

    @staticmethod
    def from_underlying_scalar(
        feature: ScalarFeatureType | InputFeatureType[ScalarFeatureType],
        *,
        original_underscore: ChalkpyUnderscore,
    ) -> "UnderscoreFeature":
        return UnderscoreFeature(
            underlying=feature.underlying,
            _path=tuple([p.parent for p in feature.path]) if isinstance(feature, InputFeatureType) else (),
            original_underscore=original_underscore,
            expression_id=original_underscore._chalk__expr_id,  # pyright: ignore[reportPrivateUsage]
        )

    @cached_property
    def inputs(
        self,
    ) -> Tuple[UnderscoreInputFeatureType, ...]:
        return (self.input_feature,)

    def fn(self, x: Any):
        return x

    @cached_property
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        return UnderscoreImplicitDependencies.empty()


@dataclasses.dataclass(frozen=True)
class UnderscoreColumn(UnderscoreValue):
    """
    Represents a single column from an input table. Different from UnderscoreFeature in that it doesn't correspond to a feature in a namespace.
    Used to build column projection expressions using Underscores that don't necessarily have features as inputs. (e.g. streaming resolver message parsing)
    """

    column_name: str
    field: pa.Field

    @cached_property
    def root_namespace(self) -> str | None:
        return None

    @cached_property
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        return UnderscoreImplicitDependencies.empty()

    def fn(self, input_df: DataFrame) -> pa.Array:
        raise NotImplementedError("'UnderscoreColumn' has no python implementation")

    @cached_property
    def inputs(self) -> Tuple[UnderscoreInputFeatureType, ...]:
        return tuple()

    @cached_property
    def underscore_result_type(self) -> UnderscoreResultType:
        return UnderscoreResultScalarType(scalar_type=self.field.type)


@dataclasses.dataclass(frozen=True)
class UnderscoreLambda(UnderscoreValue):
    """
    A lambda expression, having callback type.
    """

    parameters: tuple[tuple[str, pa.DataType], ...]

    lambda_body: UnderscoreValue

    @cached_property
    def root_namespace(self) -> str | None:
        return self.lambda_body.root_namespace

    @cached_property
    def underscore_result_type(self) -> UnderscoreCallbackType:
        body_result_type = self.lambda_body.underscore_result_type
        if not isinstance(body_result_type, UnderscoreResultScalarType):
            raise ValueError(
                f"A lambda must have a scalar return type, but '{self.lambda_body}' has non-scalar result type {body_result_type}"
            )

        return UnderscoreCallbackType(
            input_parameters=tuple(param_type for _, param_type in self.parameters),
            output_type=body_result_type.scalar_type,
        )

    @cached_property
    def inputs(
        self,
    ) -> Tuple[UnderscoreInputFeatureType, ...]:
        return self.lambda_body.inputs

    def fn(self, *args: Any, **kwargs: Any):
        raise ValueError(f"Lambda expression '{self.original_underscore}' cannot be computed in Python backend")

    @cached_property
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        return self.lambda_body.implicit_dependencies


@dataclasses.dataclass(frozen=True)
class UnderscoreLambdaParameter(UnderscoreValue):
    """
    The parameter of an `UnderscoreLambda`, inside of that lambda body.
    """

    parameter_name: str
    parameter_type: pa.DataType

    @cached_property
    def root_namespace(self) -> None:
        return None

    @cached_property
    def underscore_result_type(self) -> UnderscoreResultScalarType:
        return UnderscoreResultScalarType(
            scalar_type=self.parameter_type,
        )

    @cached_property
    def inputs(
        self,
    ) -> Tuple[UnderscoreInputFeatureType, ...]:
        return ()

    def fn(self, *args: Any, **kwargs: Any):
        raise ValueError(f"Lambda parameter '{self.original_underscore}' cannot be computed in Python backend")

    @cached_property
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        return UnderscoreImplicitDependencies.empty()


@dataclasses.dataclass(frozen=True)
class UnderscoreWindowed(UnderscoreParsed):
    """
    An underscore expression which underlies a windowed feature.
    E.g. _.a : Windowed[int] = windowed("30m", "1d") is an underscore windowed feature.
    """

    _path: NamespacePath
    underlying: WindowedFeatureType
    _root_namespace: Optional[str] = None

    @cached_property
    def root_namespace(self) -> str:
        return self._root_namespace or self._path[0].namespace

    def get_windowed_feature_fqn(self, window: Union[str, int, timedelta]) -> str:
        from chalk.streams import get_name_with_duration

        return get_name_with_duration(self.underlying.fqn, window)

    @cached_property
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        return UnderscoreImplicitDependencies.empty()


class FeatureKeySource(str, Enum):
    inferred = "inferred"
    explicit = "explicit"


@dataclasses.dataclass(frozen=True)
class UnderscoreItemParsed(UnderscoreValue):
    parent: UnderscoreNamespace
    feature_keys: list[UnderscoreValue]  # the feature rooted in the foreign namespace which we're obtaining
    feature_key_source: FeatureKeySource
    """The provenance of the feature key, whether it was inferred or explicitly provided.
    We allow writing `_.has_many.count()`, and take `feature_key` to be the primary key of the `has_many` namespace.
    Other aggregations (like `sum()`) should not use the `feature_key` when the source is `inferred`."""
    filters: "Sequence[UnderscoreOperationExpression]" = dataclasses.field(default_factory=lambda: tuple())

    def __post_init__(self):
        with UnderscoreValidationError.error_info_context(original_underscore=self.original_underscore):
            if not isinstance(self.parent, UnderscoreNamespace):  # pyright: ignore[reportUnnecessaryIsInstance]
                raise ValueError(
                    "An underscore get-item expression was incorrectly applied to an unparsed underscore expression"
                )
            if not all(isinstance(feature_key, UnderscoreValue) for feature_key in self.feature_keys):  # pyright: ignore[reportUnnecessaryIsInstance]
                raise ValueError("An underscore get-item expression is not a parsed underscore value")
            for feature_key in self.feature_keys:
                if self.parent.underlying != feature_key.root_namespace:
                    raise ValueError(
                        f"Expected the feature key '{feature_key.original_underscore}' in underscore expression '{self.original_underscore}' to have root namespace '{self.parent.underlying}' but actually has root namespace '{feature_key.root_namespace}'"
                    )

    @cached_property
    def underscore_result_type(self) -> UnderscoreResultType:
        column_types: dict[str | UnderlyingHasManyFeatureType, pa.DataType] = {}
        for i, feature_key in enumerate(self.feature_keys):
            key_type = feature_key.underscore_result_type
            if not isinstance(key_type, UnderscoreResultScalarType):
                # The key type must be a scalar type.
                raise ValueError(
                    f"namespace path '{self.parent.path}' cannot be indexed by dataframe-returning expression `{feature_key.original_underscore}` with type {key_type}"
                )

            col_key = (
                feature_key.input_feature.root_fqn if isinstance(feature_key, UnderscoreFeature) else f"series_{i}"
            )

            column_types[col_key] = key_type.scalar_type
        # Dominic thinks that this UnderscoreResultDataFrameType is almost certainly useless
        return UnderscoreResultDataFrameType(column_types=frozendict(column_types))

    @cached_property
    def root_namespace(self) -> str:
        return self.parent.root_namespace

    @cached_property
    def input_as_has_many(self) -> HasManyFeatureType | InputFeatureType[HasManyFeatureType]:
        # assert len(self.parent.namespace_path_shape) == 1
        orig_hm_feature = self.parent.path[-1]
        assert isinstance(orig_hm_feature, HasManyFeatureType)

        # TODO: fully deprecate the `filter` parameter
        filter_expression = FilterExpressionParsed.from_exprs(list(self.filters))
        tmp_filter = None
        try:
            tmp_filter = (
                filter_expression.tmp_convert_to_exact_filter_parsed() if filter_expression is not None else None
            )
        except FilterParsedBackwardsCompatibilityError:
            pass

        required_column_refs = OrderedSet[UnderscoreInputFeatureType]()
        for feature_key in self.feature_keys:
            required_column_refs.update(feature_key.inputs)
        df_type = DataFrameType(
            filter_expression=filter_expression,
            filter=tmp_filter,  # some downstream exprs use the old filter
            required_column_refs=FrozenOrderedSet(required_column_refs),
            optional_column_refs=FrozenOrderedSet(),
            limit=None,
            _graph=orig_hm_feature.graph,
        )
        hm_feature = orig_hm_feature.replace_df(df_type)
        return make_input_feature_type(hm_feature, self.parent.path[:-1])

    @cached_property
    def inputs(
        self,
    ) -> Tuple[UnderscoreInputFeatureType, ...]:
        required_to_sample = tuple(required_features_to_sample(self.input_as_has_many))
        multiple_hm_features = len(tuple(filter(lambda f: is_underlying_has_many(f), required_to_sample))) > 1
        # If there are multiple has-many features in the required_to_sample set, then we need all of these features as inputs
        return required_to_sample if multiple_hm_features else (self.input_as_has_many,)

    def fn(self, input_df: DataFrame, *additional_inputs: Any) -> pa.Array:
        if len(additional_inputs) > 0:
            raise ValueError(f"cannot compute nested dataframe expression with inputs '{self.inputs}'")
        assert isinstance(input_df, DataFrame)
        outputs: list[object] = []
        for row in input_df:
            for feature_key in self.feature_keys:
                sample = [_get_feature(row, f) for f in feature_key.inputs]
                outputs.append(feature_key.fn(*sample))

        with UnderscoreValidationError.error_info_context(original_underscore=self.original_underscore):
            assert isinstance(self.underscore_result_type, UnderscoreResultDataFrameType)
            if self.underscore_result_type.column_types == "all_columns":
                raise ValueError(
                    f"cannot compute dataframe expression with type '{self.underscore_result_type}' since selected columns are not specified"
                )
            if len(self.underscore_result_type.column_types) != 1:
                raise ValueError(
                    f"cannot compute dataframe expression with type '{self.underscore_result_type}' since {len(self.underscore_result_type.column_types)} columns are selected instead of the expected 1 column"
                )

        outputs_arr = pa.array(outputs, type=get_unique_item(self.underscore_result_type.column_types.values()))
        assert isinstance(outputs_arr, pa.Array), "chunked arrays are not supported yet"
        return outputs_arr

    @cached_property
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        child_deps = [child.implicit_dependencies for child in self.filters] + [
            feature_key.implicit_dependencies for feature_key in self.feature_keys
        ]
        return UnderscoreImplicitDependencies.merge(*child_deps)


def _get_feature(features_obj: Any, feature: NamedFeatureType):
    obj = features_obj
    for x in feature.root_fqn.split(".")[1:]:
        obj = getattr(obj, x)
    return obj


class UnderscoreValidationError(Exception):
    def __init__(
        self,
        *,
        original_underscore: ChalkpyUnderscore | None,
        feature_fqn: str | None,
        feature_underscore: ChalkpyUnderscore | None,
    ):
        self.original_underscore = original_underscore
        self.feature_fqn = feature_fqn

        message_prefix = "error validating underscore expression"
        if original_underscore is not None:
            message_prefix += f" '{str(feature_underscore if feature_underscore is not None else original_underscore)}'"

        if feature_fqn is not None:
            message_prefix += f" for feature '{feature_fqn}'"

        super().__init__(message_prefix)

    def add_context(
        self,
        *,
        original_underscore: ChalkpyUnderscore | None = None,
        feature_fqn: str | None = None,
    ):
        """
        Copies this exception and adds additional context.
        The values will not overwrite already-assigned properties; if no values are
        updated, then the original exception instance is returned unchanged.
        """

        new_error = UnderscoreValidationError(
            original_underscore=self.original_underscore
            if self.original_underscore is not None
            else original_underscore,
            feature_fqn=self.feature_fqn or feature_fqn,
            feature_underscore=original_underscore,
        )
        if new_error.original_underscore is self.original_underscore and new_error.feature_fqn == self.feature_fqn:
            return self
        return new_error

    @contextmanager
    @staticmethod
    def error_info_context(
        *,
        feature_fqn: str | None = None,
        original_underscore: ChalkpyUnderscore | None = None,
    ):
        """
        Wraps all exceptions in `UnderscoreValidationError`, and adds the specified
        context if it was not already set.
        """
        try:
            yield
        except UnderscoreValidationError as e:
            new_e = e.add_context(
                original_underscore=original_underscore,
                feature_fqn=feature_fqn,
            )
            if new_e is not e:
                raise new_e from e
            raise e
        except Exception as e:
            raise UnderscoreValidationError(
                original_underscore=original_underscore,
                feature_fqn=feature_fqn,
                feature_underscore=original_underscore,
            ) from e


OperationSupplier = Callable[[str], "UnderscoreOperation"]

by_aggregate_fns = ("max_by", "min_by", "max_by_n", "min_by_n")


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreOperationExpression(UnderscoreValue):
    operands: MaybeNamedCollection[UnderscoreValue | UnderscoreConstant]
    """
    Operands are the input expressions for an underscore expression.

    - `_.a + _.b` has operands `_.a` and `_.b`, which will be `UnderscoreValue`.
    - `_.accounts[_.value].sum()` has operand `_.accounts[_.value]`, which is a `UnderscoreItemParsed`
        that represents an array/dataframe expression.
    """
    operation: UnderscoreOperation

    args: Tuple[object, ...] = dataclasses.field(default_factory=tuple)
    kwargs: FrozenOrderedSet[Tuple[str, Any]] = dataclasses.field(default_factory=FrozenOrderedSet)
    """
    Args and kwargs are options for aggregations. They're populated when the underscore is a method call.
    If the underscore was a function, then operands will be populated instead.
    """

    def __post_init__(self):
        root_namespaces = set(
            op.root_namespace
            for _, op in MaybeNamedCollection.enumerate(self.operands)
            if isinstance(op, UnderscoreValue)
            and op.root_namespace is not None
            and op.root_namespace != PSEUDONAMESPACE
        )
        if len(root_namespaces) >= 1:
            if len(root_namespaces) != 1 and not (
                len(root_namespaces) == 2 and self.operation_name in by_aggregate_fns
            ):
                raise ValueError(
                    f"cannot construct operation '{self.operation_name}' with inputs from multiple namespaces: {sorted(root_namespaces)}"
                )

        if not isinstance(self.kwargs, FrozenOrderedSet):  # pyright: ignore[reportUnnecessaryIsInstance]
            raise TypeError(
                f"Expected kwargs to be a 'FrozenOrderedSet', but is actually a '{type(self.kwargs).__name__}'."
            )

    @cached_property
    def has_aggregate_input(self):
        # Used to parse max_by and min_by aggregations
        if self.operation_name in by_aggregate_fns and len(self.operands.positional_items) not in (2, 3):  # max/min_by
            raise ValueError(
                f"Expected 2 or 3 operands while converting expression to DataFrame filter; got: {self.operands.pprint()}"
            )
        base_has_many, sort_col, *_ = self.operands.positional_items
        if not isinstance(base_has_many, UnderscoreItemParsed):
            raise ValueError(
                f"Expected a DataFrame expression as the first argument to the operation '{self.operation_name}', but got '{base_has_many}'"
            )
        if not isinstance(sort_col, UnderscoreFeature):
            raise ValueError(
                f"Expected a feature as the second argument to the operation '{self.operation_name}', but got '{sort_col}'"
            )

        if len(base_has_many.parent.namespace_path_shape) != 1:
            raise ValueError(
                f"Expected a DataFrame expression as the first argument to the operation '{self.operation_name}', but got '{base_has_many}'"
            )
        orig_hm_feature = base_has_many.parent.path[-1]
        if not isinstance(orig_hm_feature, HasManyFeatureType):
            raise ValueError(
                f"Expected a DataFrame expression as the first argument to the operation '{self.operation_name}', but got '{base_has_many}'"
            )

        # TODO: fully deprecate the `filter` parameter
        filter_expression = FilterExpressionParsed.from_exprs(list(base_has_many.filters))
        tmp_filter = None
        try:
            tmp_filter = (
                filter_expression.tmp_convert_to_exact_filter_parsed() if filter_expression is not None else None
            )
        except FilterParsedBackwardsCompatibilityError:
            pass

        feature_key_inputs: list[UnderscoreInputFeatureType] = []
        for feature_key in base_has_many.feature_keys:
            feature_key_inputs.extend(feature_key.inputs)
        df_type = DataFrameType(
            filter_expression=filter_expression,
            filter=tmp_filter,  # some downstream exprs use the old filter
            required_column_refs=FrozenOrderedSet((*feature_key_inputs, *sort_col.inputs)),
            optional_column_refs=FrozenOrderedSet(),
            limit=None,
            _graph=orig_hm_feature.graph,
        )
        hm_feature = orig_hm_feature.replace_df(df_type)
        updated_feature_type = make_input_feature_type(hm_feature, base_has_many.parent.path[:-1])
        return updated_feature_type

    @property
    def operation_name(self) -> str:
        return self.operation.operation_name

    @cached_property
    def root_namespace(self) -> str | None:
        if self.operation_name in by_aggregate_fns:
            # These functions are special
            special_namespaces = [
                op.root_namespace
                for _, op in MaybeNamedCollection.enumerate(self.operands)
                if isinstance(op, UnderscoreValue) and op.root_namespace != PSEUDONAMESPACE
            ]
            if len(special_namespaces) == 0:
                raise ValueError(
                    f"The operation '{self.operation_name}' must be computed over a namespace, but the inputs {self.operands} do not query from any namespace"
                )
            return special_namespaces[0]

        namespaces_in_input = FrozenOrderedSet(
            op.root_namespace
            for _, op in MaybeNamedCollection.enumerate(self.operands)
            if isinstance(op, UnderscoreValue)
            and op.root_namespace is not None
            and op.root_namespace != PSEUDONAMESPACE
        )
        if len(namespaces_in_input) == 0:
            return None
        if len(namespaces_in_input) == 1:
            return list(namespaces_in_input)[0]

        raise ValueError(
            f"The operation '{self.operation_name}' cannot be computed over multiple namespaces {list(namespaces_in_input)}"
        )

    @cached_property
    def underscore_result_type(self) -> UnderscoreResultType:
        with UnderscoreValidationError.error_info_context(original_underscore=self.original_underscore):
            return UnderscoreResultScalarType(
                scalar_type=self.operation.return_type(
                    UnderscoreOperationInputMetadata(
                        underscore_input_types=tuple(
                            op.underscore_result_type for op in self.operands.positional_items
                        ),
                        input_underscores=tuple(
                            op.original_underscore if isinstance(op, UnderscoreParsed) else None
                            for op in self.operands.positional_items
                        ),
                        operation_underscore=self.original_underscore,
                    ),
                )
            )

    @cached_property
    def inputs(self) -> tuple[UnderscoreInputFeatureType, ...]:
        all_inputs: list[UnderscoreInputFeatureType] = []
        if self.operation_name in by_aggregate_fns:
            if isinstance(self.operands.positional_items[0], UnderscoreValue):
                all_inputs.append(self.has_aggregate_input)
                return tuple(all_inputs)
        for _, op in MaybeNamedCollection.enumerate(self.operands):
            if isinstance(op, UnderscoreValue):
                all_inputs.extend(op.inputs)
        return tuple(all_inputs)

    def fn(self, *input_values: Tuple[Any, ...]):
        assert len(input_values) == len(self.inputs)
        idx = 0
        operand_values = MaybeNamedCollectionBuilder[object]()
        for param_identifier, op in MaybeNamedCollection.enumerate(self.operands):
            if isinstance(op, UnderscoreValue):
                value = op.fn(*input_values[idx : idx + len(op.inputs)])
                idx += len(op.inputs)
            else:
                value = op.value
            operand_values.add(param_identifier, value)

        if self.operation.fn is None:
            raise ValueError(f"No python fallback defined for '{self.operation_name}'")
        return self.operation.fn(
            *operand_values.positional_items, *self.args, **operand_values.named_items, **dict(self.kwargs)
        )

    @cached_property
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        child_deps = [
            child.implicit_dependencies
            for _, child in MaybeNamedCollection.enumerate(self.operands)
            if not isinstance(child, UnderscoreConstant)
        ]
        self_dep = UnderscoreImplicitDependencies(has_named_prompts=(self.operation_name == "run_prompt"))
        return UnderscoreImplicitDependencies.merge(self_dep, *child_deps)


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreNever(UnderscoreValue):
    """
    An underscore expression which indicates a bug if we try to compute it.
    """

    error: ChalkError
    root_namespace_: str

    @cached_property
    def root_namespace(self):
        return self.root_namespace_

    @cached_property
    def underscore_result_type(self) -> UnderscoreResultType:
        return UnderscoreResultScalarType(scalar_type=pa.null())

    @cached_property
    def inputs(self) -> tuple[UnderscoreInputFeatureType, ...]:
        return ()

    def fn(self, *input_values: Tuple[Any, ...]):
        del input_values
        raise ValueError(f"Cannot compute underscore expression '{self.original_underscore}', error: {self.error}")

    @cached_property
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        return UnderscoreImplicitDependencies.empty()


@dataclasses.dataclass(kw_only=True, frozen=True)
class UnderscoreOperationInputMetadata:
    underscore_input_types: tuple[UnderscoreResultType, ...]
    input_underscores: tuple[ChalkpyUnderscore | None, ...]
    operation_underscore: ChalkpyUnderscore | None


UnderscoreReturnType = Callable[[UnderscoreOperationInputMetadata], pa.DataType]


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreOperation(ABC):
    operation_name: str
    return_type: UnderscoreReturnType = dataclasses.field(repr=False, compare=False)
    resolved_overload: ChalkFunctionOverloadResolved | None = dataclasses.field(repr=False, compare=False, default=None)
    convert_input_errors_to_none: bool = False
    fn: Callable[..., object] | None = dataclasses.field(
        repr=False, compare=False
    )  # called like fn(*input_values, *args, **kwargs)
    codec_info: UnderscoreOperationCodecInfo = dataclasses.field(repr=False, compare=False)

    @staticmethod
    def from_overload_resolved(
        resolved_overload: ChalkFunctionOverloadResolved, codec_info: FromCppRegCodecInfo
    ) -> UnderscoreOperation:
        return UnderscoreOperation(
            operation_name=resolved_overload.function_name,
            return_type=lambda _: resolved_overload.output_type,
            resolved_overload=resolved_overload,
            convert_input_errors_to_none=resolved_overload.convert_input_errors_to_none,
            fn=resolved_overload.python_fallback,
            codec_info=codec_info,
        )


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreMaterializedAggregation(UnderscoreValue):
    unmaterialized_underscore: UnderscoreOperationExpression | None

    materialization: MaterializationWindowConfigParsed
    """
    The configuration to use for the materialization.
    """

    window_duration: timedelta
    """
    The duration of the window to aggregate (backwards, relative to the current time).
    """

    source_aggregation_namespace: str
    """
    The root namespace.
    """

    @cached_property
    def root_namespace(self) -> str:
        return self.source_aggregation_namespace

    group_by_keys: tuple[ScalarFeatureType | InputFeatureType[ScalarFeatureType], ...]
    """
    These are the keys used to compute the group-by.
    (In the future, these could be generalized to arbitrary expressions.)
    """

    has_many: HasManyFeatureType

    @cached_property
    def underscore_result_type(self) -> UnderscoreResultType:
        return UnderscoreResultScalarType(scalar_type=self.materialization.pyarrow_dtype)

    @cached_property
    def input_as_has_many(self) -> HasManyFeatureType:
        materialization = self.materialization
        filters = list(self.materialization.filters)
        if materialization.continuous_buffer_duration is not None:
            # add a bucket duration so we can round the lower bound down by a bucket
            total_range = materialization.continuous_buffer_duration + materialization.bucket_duration
            # TODO: check sign
            filters.append(FilterParsed(materialization.bucket_feature, ">", -total_range))

        hm_df = DataFrameType(
            filter=FilterParsed.from_filters(filters),
            required_column_refs=FrozenOrderedSet(
                (materialization.bucket_feature, *materialization.aggregate_on, *materialization.group_by)
            ),
            optional_column_refs=FrozenOrderedSet(),
            limit=None,
            _graph=self.has_many.graph,
        )

        return self.has_many.replace_df(hm_df)

    @cached_property
    def inputs(self) -> tuple[UnderscoreInputFeatureType, ...]:
        if self.materialization.continuous_buffer_duration is None:
            return self.group_by_keys

        return (*self.group_by_keys, self.input_as_has_many)

    def fn(self, *input_values: Tuple[Any, ...]):
        raise ValueError(
            f"UnderscoreMaterializedAggregation '{self.original_underscore}' cannot be computed at runtime like an ordinary underscore resolver"
        )

    @cached_property
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        return (
            self.unmaterialized_underscore.implicit_dependencies
            if self.unmaterialized_underscore is not None
            else UnderscoreImplicitDependencies.empty()
        )


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreMaterializedState(UnderscoreParsed):
    """
    Represents a reference to `_.windowed_agg.materialized_state, possibly with a specified window key`
    """

    window_feature: UnderscoreWindowed
    scalar_feature: ScalarFeatureType | None

    def get_scalar_feature(self, graph: ResolvedGraph) -> ScalarFeatureType:
        if self.scalar_feature is not None:
            return self.scalar_feature
        if len(self.window_feature.underlying.windowed_pseudo_features) == 0:
            raise ValueError(
                f"Cannot access materialized state for '{self.window_feature.underlying}' because it does not define any aggregation windows"
            )
        # choose an arbitrary scalar for backcompat
        return max(
            self.window_feature.underlying.windowed_pseudo_features,
            key=lambda feat: unwrap_optional(feat.window_config).window_duration,
        )

    @cached_property
    def root_namespace(self) -> str | None:
        return self.window_feature.root_namespace


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreMaterializedStateOperation(UnderscoreValue):
    """
    Represents an operation applied to `_.windowed_agg.materialized_state`

    Right now, only sparse_buckets is supported
    """

    mat_agg_definition: UnderscoreMaterializedAggregation

    # whether this expression is part of the definition of an offline resolver
    # should maybe make this a different class? not really sure
    for_offline_resolver: bool

    @cached_property
    def underscore_result_type(self) -> UnderscoreResultType:
        agg_ty = self.mat_agg_definition.materialization.aggregation
        input_types = [f.pyarrow_dtype for f in self.mat_agg_definition.materialization.aggregate_on]
        return UnderscoreResultScalarType(
            scalar_type=pa.large_list(
                pa.struct(
                    {"ts": pa.timestamp("ns", "UTC")}
                    | {
                        ty.time_series_rule_name(): ty.bucket_result_type(input_types)
                        for ty in convert_materialized_aggregation_type_to_timeseries_rule_aggregation_type(agg_ty)
                    }
                )
            )
        )

    @cached_property
    def inputs(self) -> tuple[UnderscoreInputFeatureType, ...]:
        if not self.for_offline_resolver:
            return self.mat_agg_definition.group_by_keys
        return unwrap_optional(self.mat_agg_definition.unmaterialized_underscore).inputs

    def fn(self, *input_values: Tuple[Any, ...]):
        raise ValueError(
            f"UnderscoreMaterializedStateOperation '{self.original_underscore}' cannot be computed at runtime like an ordinary underscore resolver"
        )

    @cached_property
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        return self.mat_agg_definition.implicit_dependencies

    @cached_property
    def root_namespace(self) -> str | None:
        return self.mat_agg_definition.root_namespace


@dataclasses.dataclass(frozen=True, kw_only=True)
class UnderscoreIncompleteGroupByAggregation(UnderscoreValue):
    """
    This represents an INCOMPLETE expression like:
    - `_.grouped_windowed_agg["30d"]`
    - `_.grouped_windowed_agg.group(agg_col = _.f)`

    if you combine both the window and the groups together, it composes
    into `UnderscoreMaterializedAggregation` instead:
    - `_.grouped_windowed_agg.group(agg_col = _.f)["30d"]`
    - `_.grouped_windowed_agg.group["30d"](agg_col = _.f)`
    """

    has_many: HasManyFeatureType

    materialization: MaterializationWindowConfigParsed
    """
    The configuration to use for the materialization.
    """

    group_features: frozendict[str, ScalarFeatureType | InputFeatureType[ScalarFeatureType]] | None
    """
    These are the features to use for the group-by lookup.
    If `None`, they have not yet been specified.
    """

    window_duration: timedelta | None
    """
    The duration of the window to aggregate (backwards, relative to the current time).

    If it is `None`, then the group-by is still incomplete.
    """

    allowed_window_values: tuple[timedelta, ...]
    """
    These are the values which are permitted for the window duration.
    """

    source_aggregation_namespace: str
    """The root namespace where this underscore expression was defined."""

    @cached_property
    def root_namespace(self) -> str:
        return self.source_aggregation_namespace

    @cached_property
    def underscore_result_type(self) -> UnderscoreResultType:
        return UnderscoreSpecialCaseType()

    @cached_property
    def inputs(self) -> tuple[UnderscoreInputFeatureType, ...]:
        return ()

    def fn(self, *input_values: Tuple[Any, ...]):
        raise ValueError(
            f"Incomplete group-by aggregation underscore expression '{self.original_underscore}' cannot be evaluated"
        )

    def as_completed_aggregation(self) -> UnderscoreMaterializedAggregation | None:
        if self.window_duration is None or self.group_features is None:
            return None

        return UnderscoreMaterializedAggregation(
            unmaterialized_underscore=None,
            original_underscore=self.original_underscore,
            materialization=self.materialization,
            window_duration=self.window_duration,
            source_aggregation_namespace=self.source_aggregation_namespace,
            group_by_keys=tuple(self.group_features[group.fqn] for group in self.materialization.group_by),
            has_many=self.has_many,
            expression_id=str(uuid.uuid4()),
        )

    def replace_group_features(
        self,
        new_group_features: frozendict[str, ScalarFeatureType | InputFeatureType[ScalarFeatureType]],
    ) -> "UnderscoreIncompleteGroupByAggregation | UnderscoreMaterializedAggregation":
        """
        Replace the group values with the provided argument.
        If this completes the aggregation parameters, a completed `UnderscoreMaterializedAggregation` will be returned instead.
        """
        updated = dataclasses.replace(self, group_features=new_group_features)
        return updated.as_completed_aggregation() or updated

    def replace_window(
        self,
        new_window_duration: timedelta,
    ) -> "UnderscoreIncompleteGroupByAggregation | UnderscoreMaterializedAggregation":
        """
        Replace the window duration with the provided argument.
        If this completes the aggregation parameters, a completed `UnderscoreMaterializedAggregation` will be returned instead.
        """
        updated = dataclasses.replace(self, window_duration=new_window_duration)
        return updated.as_completed_aggregation() or updated

    @cached_property
    def implicit_dependencies(self) -> UnderscoreImplicitDependencies:
        return UnderscoreImplicitDependencies.empty()


class FilterParsedBackwardsCompatibilityError(Exception):
    def __init__(self, message: str):
        super().__init__(message)


class FilterExpressionParsed:
    __slots__ = ("expr",)

    def __init__(self, expr: UnderscoreValue) -> None:
        super().__init__()
        self.expr = expr
        expr_type = expr.underscore_result_type
        if not isinstance(expr_type, UnderscoreResultScalarType):
            raise ValueError(
                f"Invalid return type for filter expression: Expected the filter expression to return an UnderscoreResultScalarType, received {type(expr_type)}"
            )
        if not expr_type.scalar_type == pa.bool_():
            raise ValueError(
                f"Invalid return type for filter expression {expr}: Expected boolean, received {expr_type.scalar_type}"
            )

    def all_referenced_filter_inputs(self):
        """
        Returns all of the inputs referenced by this filter expression.
        """
        return self.expr.inputs

    def __eq__(self, other: object):
        if not isinstance(other, FilterExpressionParsed):
            return NotImplemented
        return self.expr == other.expr

    def __hash__(self):
        return hash(f"{self.expr}")

    @classmethod
    def from_exprs(cls, exprs: list[UnderscoreValue]) -> "FilterExpressionParsed | None":
        if len(exprs) == 0:
            return None
        if len(exprs) == 1:
            return cls(expr=exprs[0])
        return cls(
            expr=functools.reduce(
                cls._expr_reduce_fn,
                exprs,
            )
        )

    @staticmethod
    def _expr_reduce_fn(a: UnderscoreValue, b: UnderscoreValue) -> UnderscoreValue:
        from _chalk_shared_public.chalk_function_registry import get_chalk_function_registry_overload

        if not isinstance(a.underscore_result_type, UnderscoreResultScalarType) or not isinstance(
            b.underscore_result_type, UnderscoreResultScalarType
        ):
            raise ValueError(
                f"Expected both sides of the filter expression to be scalar types, received {a.underscore_result_type}, {b.underscore_result_type}"
            )

        input_types = MaybeNamedCollectionBuilder(
            [a.underscore_result_type.scalar_type, b.underscore_result_type.scalar_type]
        )
        and_op = get_chalk_function_registry_overload(
            function_name="&",
            input_types=input_types,
        )
        assert and_op is not None, "& should be in the function registry"

        from chalkruntime.graph.chalk_overload import ChalkFunctionOverloadFailed

        if isinstance(and_op, ChalkFunctionOverloadFailed):
            raise ValueError(
                "Expected both sides of the filter expression to be scalar boolean types, received {a.underscore_result_type}, {b.underscore_result_type}"
            )

        return UnderscoreOperationExpression(
            operation=UnderscoreOperation.from_overload_resolved(
                resolved_overload=and_op,
                codec_info=FromCppRegCodecInfo(function_name="&"),
            ),
            operands=MaybeNamedCollectionBuilder(positional_items=[a, b]),
            original_underscore=UnderscoreRoot(),
            expression_id=str(uuid.uuid4()),  # "&" is deterministic, so it's safe to recompute this every time
        )

    def tmp_convert_to_approximate_filter_parsed(
        self,
    ) -> FilterParsed | None:
        """
        Converts this expression to an approximately equivalent legacy `FilterParsed` value.
        The resulting `FilterParsed` may evaluate to `True` more often than the original expression.
        This means that it be can used to pre-filter values (e.g. for filter pushdown) but isn't equivalent.
        """
        return FilterExpressionParsed._convert_approx_positive(self.expr)

    @staticmethod
    def _convert_approx_positive(
        expr: UnderscoreValue | UnderscoreConstant,
    ) -> FilterParsed | None:
        """
        Returns an approximately-equivalent filter, that may return `True` more often than the original.
        A value of `None` means "no filter", so it's equivalent to a "const True" expression.

        This function won't throw.
        """

        if isinstance(expr, UnderscoreConstant):
            return None

        # Convert left/right sides of boolean operators independently.
        if (
            isinstance(expr, UnderscoreOperationExpression)
            and expr.operation_name == "&"
            and len(expr.operands.positional_items) == 2
        ):
            left = FilterExpressionParsed._convert_approx_positive(expr.operands.positional_items[0])
            right = FilterExpressionParsed._convert_approx_positive(expr.operands.positional_items[1])
            if left is None:
                return right
            if right is None:
                return left
            return FilterParsed(
                lhs=left,
                operation="and",
                rhs=right,
            )

        if (
            isinstance(expr, UnderscoreOperationExpression)
            and expr.operation_name == "|"
            and len(expr.operands.positional_items) == 2
        ):
            left = FilterExpressionParsed._convert_approx_positive(expr.operands.positional_items[0])
            right = FilterExpressionParsed._convert_approx_positive(expr.operands.positional_items[1])
            if left is None:
                return None
            if right is None:
                return None
            return FilterParsed(
                lhs=left,
                operation="or",
                rhs=right,
            )

        # Note: we CANNOT recursively apply this same logic to `not`, since the "polarity" of
        # the fallback would need to switch from 'default True' to 'default False'.

        # Try to convert to a `FilterParsed`. If the conversion fails, return a fallback of `None`
        # instead.
        try:
            return FilterExpressionParsed(expr).tmp_convert_to_exact_filter_parsed()
        except:
            return None

    def tmp_convert_to_exact_filter_parsed(self) -> FilterParsed:
        """
        Converts this expression to an equivalent legacy `FilterParsed` value.
        If this cannot be done, raises an exception.
        """
        if not isinstance(self.expr, UnderscoreOperationExpression):
            raise FilterParsedBackwardsCompatibilityError(
                f"Expected an UnderscoreOperationExpression as the root of this filter expression; got {type(self.expr)}"
            )
        if len(self.expr.operands.positional_items) != 2:
            raise FilterParsedBackwardsCompatibilityError(
                f"Expected 2 operands while converting _ expression to DataFrame filter; got {len(self.expr.operands.positional_items)}: {self.expr.operands}"
            )

        def _convert_op(operation: str, lhs: Any, rhs: Any) -> FilterParsed:
            if operation == "|":
                operation = "or"
            elif operation == "&":
                operation = "and"
            elif operation == "contains":
                # Intentionally swapped the sides here
                # F.contains({"food", "drink"}, _.kind) is equivalent to `_.kind in {"food", "drink"}`
                lhs, rhs = rhs, lhs
                operation = "in"
            elif not is_valid_operation(operation):
                raise FilterParsedBackwardsCompatibilityError(
                    f"Invalid operation for DataFrame filter {operation}; could not convert to Filter."
                )

            return FilterParsed(
                operation=operation,
                lhs=cast(
                    (
                        TPrimitive
                        | FilterParsed
                        | ScalarFeatureType
                        | FeatureTimeFeatureType
                        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
                        | FeatureFqnMarker
                    ),
                    lhs,
                ),
                rhs=cast(
                    (
                        TPrimitive
                        | FilterParsed
                        | ScalarFeatureType
                        | FeatureTimeFeatureType
                        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType]
                        | FeatureFqnMarker
                    ),
                    rhs,
                ),
            )

        def _convert_filter_side(
            side: UnderscoreValue | UnderscoreConstant | UnderscoreOperationExpression,
            side_name: str,
        ):
            if isinstance(side, UnderscoreFeature):
                if side.input_feature.fqn == Now.fqn:
                    return timedelta()
                return side.input_feature
            elif isinstance(side, UnderscoreConstant):
                return side.value
            elif isinstance(side, UnderscoreOperationExpression):
                if len(side.operands.positional_items) != 2:
                    raise FilterParsedBackwardsCompatibilityError(
                        f"Expected 2 operands while converting _ expression to DataFrame filter; got {len(side.operands.positional_items)}: {side.operands}"
                    )

                lhs = _convert_filter_side(side.operands.positional_items[0], "left")
                rhs = _convert_filter_side(side.operands.positional_items[1], "right")
                # The value of `chalk_window` is converted into a constant timedelta value.
                # So if we encounter arithmetic between two timedelta constants, we should merge them together.
                # The value of `chalk_window` and is converted to a constant
                if side.operation_name == "+" and isinstance(lhs, timedelta) and isinstance(rhs, timedelta):
                    return lhs + rhs
                if side.operation_name == "-" and isinstance(lhs, timedelta) and isinstance(rhs, timedelta):
                    return lhs - rhs
                return _convert_op(side.operation_name, lhs, rhs)
            raise FilterParsedBackwardsCompatibilityError(
                f"Expected a feature as the {side_name}-hand side of the filter; got {side}"
            )

        return _convert_op(
            operation=self.expr.operation.operation_name,
            lhs=_convert_filter_side(self.expr.operands.positional_items[0], "left"),
            rhs=_convert_filter_side(self.expr.operands.positional_items[1], "right"),
        )

    def pprint(self) -> str:
        if self.expr.original_underscore is not None:
            return repr(self.expr.original_underscore)
        return repr(self.expr)


def is_filter_expression_time_sensitive(expr: UnderscoreValue):
    for input in expr.inputs:
        if is_underlying_feature_time(input):
            return True
        if input.fqn == "__chalk__.now":
            return True
    return False


def get_filter_expressions_parsed_from_has_many_feature_type(
    has_many_feature_type: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
) -> list[FilterExpressionParsed]:
    filter_expressions: list[FilterExpressionParsed] = []
    _get_filter_expressions_rec(has_many_feature_type, filter_expressions)
    return filter_expressions


def _get_filter_expressions_rec(
    item: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
    filter_storage_list: list[FilterExpressionParsed],
):
    if isinstance(item, HasManyFeatureType) and item.df.filter_expression is not None:
        filter_storage_list.append(item.df.filter_expression)
        return

    if isinstance(item, InputFeatureType):
        _get_filter_expressions_rec(item.underlying, filter_storage_list)


def get_struct_pack_operation(names: tuple[str, ...], types: tuple[pa.DataType, ...]) -> UnderscoreOperation:
    from chalkruntime.graph.underscore_operation_registry import UnderscoreOperationRegistry

    return UnderscoreOperationRegistry.resolve(
        function_name="struct_pack",
        params=frozendict(
            {
                "names": names,
                "types": types,
            }
        ),
    )


def get_struct_subfield_operation(return_type: pa.DataType) -> UnderscoreOperation:
    from chalkruntime.graph.underscore_operation_registry import UnderscoreOperationRegistry

    return UnderscoreOperationRegistry.resolve(
        function_name="get_struct_subfield", params=frozendict({"return_type": return_type})
    )
