from __future__ import annotations

import dataclasses
from typing import Callable, Iterator, Mapping, Protocol, Sequence, TypeVar, runtime_checkable

TItem_co = TypeVar("TItem_co", covariant=True)
TItem = TypeVar("TItem")
TOther = TypeVar("TOther")


@runtime_checkable
class MaybeNamedCollection(Protocol[TItem_co]):
    """
    Protocol for a read-only collection of items, with each item keyed by either position or name.

    One concrete implementation is 'MaybeNamedCollectionBuilder'.
    """

    @property
    def positional_items(self) -> Sequence[TItem_co]: ...
    @property
    def named_items(self) -> Mapping[str, TItem_co]: ...

    @staticmethod
    def enumerate(collection: MaybeNamedCollection[TOther]) -> Iterator[tuple[int | str, TOther]]:
        yield from enumerate(collection.positional_items)
        yield from collection.named_items.items()

    # TODO: unused now?
    @staticmethod
    def zip(
        left: MaybeNamedCollection[TItem],
        right: MaybeNamedCollection[TOther],
    ) -> MaybeNamedCollection[tuple[TItem, TOther]]:
        if set(left.named_items) != set(right.named_items):
            raise ValueError("Cannot zip collections with different item names")
        return MaybeNamedCollectionBuilder(
            positional_items=list(zip(left.positional_items, right.positional_items, strict=True)),
            named_items={name: (item, right.named_items[name]) for name, item in left.named_items.items()},
        )

    @staticmethod
    def map(collection: MaybeNamedCollection[TItem], fn: Callable[[TItem], TOther]) -> MaybeNamedCollection[TOther]:
        return MaybeNamedCollectionBuilder(
            positional_items=[fn(item) for item in collection.positional_items],
            named_items={name: fn(item) for name, item in collection.named_items.items()},
        )

    def pprint(self):
        return f"({', '.join([str(x) for x in self.positional_items] + [f'{name}={item}' for name, item in self.named_items.items()])})"

    def get(self, location: int | str) -> TItem_co:
        if isinstance(location, int):
            return self.positional_items[location]
        return self.named_items[location]

    def has_exactly_n_and_only_positional_items(self, n: int) -> bool:
        return len(self.positional_items) == n and len(self.named_items) == 0

    def has_exactly_n_positional_items(self, n: int) -> bool:
        return len(self.positional_items) == n


class MaybeNamedCollectionBuilder(MaybeNamedCollection[TItem]):
    """A concrete implementation of 'MaybeNamedCollection'."""

    positional_items_: list[TItem] = dataclasses.field(default_factory=list)
    named_items_: dict[str, TItem] = dataclasses.field(default_factory=dict)

    @property
    def positional_items(self) -> Sequence[TItem]:
        return self.positional_items_

    @property
    def named_items(self) -> Mapping[str, TItem]:
        return self.named_items_

    def __init__(self, positional_items: Sequence[TItem] | None = None, named_items: Mapping[str, TItem] | None = None):
        super().__init__()
        self.positional_items_ = list(positional_items or [])
        self.named_items_ = dict(named_items or {})

    def __repr__(self) -> str:
        return f"MaybeNamedCollectionBuilder(positional_items={repr(self.positional_items)}, named_items={repr(self.named_items)})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, MaybeNamedCollection):
            return False
        key = lambda coll: (coll.positional_items, coll.named_items)
        return key(self) == key(other)

    def __hash__(self) -> int:
        return hash((self.positional_items, self.named_items))

    def add(self, location: int | str, item: TItem):
        if isinstance(location, int):
            if location != len(self.positional_items):
                raise ValueError("Cannot add to a specific index in a positional collection")
            self.positional_items_.append(item)
        else:
            self.named_items_[location] = item
