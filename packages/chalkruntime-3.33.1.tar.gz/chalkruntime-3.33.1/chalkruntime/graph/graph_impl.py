from __future__ import annotations

import contextlib
import dataclasses
import functools
import threading
from collections import defaultdict, deque
from datetime import timedelta
from typing import (
    TYPE_CHECKING,
    Callable,
    Collection,
    Generic,
    Iterable,
    Mapping,
    ParamSpec,
    Protocol,
    Sequence,
    TypeVar,
    overload,
)

from chalk.features.pseudofeatures import PSEUDOFEATURES, PSEUDONAMESPACE
from chalk.sql._internal.sql_source import BaseSQLSource, SQLSourceKind
from chalk.sql._internal.sql_source_group import SQLSourceGroup
from chalk.utils.collections import FrozenOrderedSet, OrderedSet
from pyarrow import DataType as PyArrowDataType
from pyarrow import Schema as PyArrowSchema
from pyarrow import schema as make_schema
from typing_extensions import Self, final

from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.metadata import compute_resolver_id

if TYPE_CHECKING:
    from chalkruntime.graph.feature import (
        FeatureTimeFeatureType,
        FeatureType,
        GroupByFeatureType,
        HasManyFeatureType,
        HasOneFeatureType,
        HasOnePathObjParsed,
        InputFeatureType,
        ScalarFeatureType,
        WindowedFeatureType,
    )
    from chalkruntime.graph.protograph_deserializer import OnlineStoreConfigParsed
    from chalkruntime.graph.resolver import (
        OfflineResolverParsed,
        OnlineResolverParsed,
        ResolverParsed,
        SinkResolverParsed,
    )
    from chalkruntime.graph.stream_resolver import StreamResolverParsed

T = TypeVar("T")
TSelf = TypeVar("TSelf")
P = ParamSpec("P")


class GraphCached(Generic[T]):
    def __init__(self, fn: Callable[[], T], graph: _GraphState):
        super().__init__()
        self._cache: T | ellipsis = ...
        self._version: int | ellipsis = ...
        self._graph = graph
        self._fn = fn

    def __call__(self) -> T:
        if self._cache is ... or self._version is ... or self._version < self._graph.version:
            self._cache = self._fn()
            self._version = self._graph.version

        return self._cache

    def reset(self):
        self._cache = ...

    __slots__ = ("_cache", "_version", "_graph", "_fn")


class HasGraph(Protocol):
    """Protocol for a class that provides a graph"""

    @property
    def graph(self) -> ResolvedGraph: ...


THasGraph_contra = TypeVar("THasGraph_contra", bound=HasGraph, contravariant=True)
T_co = TypeVar("T_co", covariant=True)


class _GraphCachedProperty(Protocol[THasGraph_contra, T_co]):
    @overload
    def __get__(self, instance: None, owner: type[THasGraph_contra], /) -> "_GraphCachedProperty":
        """Called when an attribute is accessed via class not an instance"""

    @overload
    def __get__(self, instance: THasGraph_contra, owner: type[THasGraph_contra], /) -> T_co:
        """Called when an attribute is accessed on an instance variable"""

    def __set_name__(self, owner: object, name: str): ...


class graph_cached_property(Generic[THasGraph_contra, T_co]):
    """Decorator to graph cache a method that takes no arguments but depends on the (latest) graph

    Behaves like a ``@property`` -- e.g.

    ```
    class MyClass(HasGraph):
        @property
        def graph(self):
            # Class must provide the graph
            return self._graph
        @graph_cached_property
        def foo(self):
            ...
    x = MyClass().foo
    ```
    """

    def __init__(self, fn: Callable[[THasGraph_contra], T_co]):
        super().__init__()
        self.fn = fn
        self.attrname: str | None = None
        self.lock = threading.RLock()

    def __set_name__(self, owner: object, name: str):
        # Copied from functools.cached_property
        # FIXME: Use the same name as the attribute, but that doesn't seem to work...
        name = f"__chalk_graph_cached__{name}"
        if self.attrname is None:
            self.attrname = name
        elif name != self.attrname:
            raise TypeError(
                (f"Cannot assign the same cached_property to two different names ({self.attrname!r} and {name!r}).")
            )

    @overload
    def __get__(self, instance: None, owner: object = None) -> Self: ...

    @overload
    def __get__(self, instance: THasGraph_contra, owner: object = None) -> T_co: ...

    def __get__(self, instance: THasGraph_contra | None, owner: object = None) -> T_co | Self:
        # Partially copied from functools.cached_property
        try:
            if instance is None:
                return self
            if self.attrname is None:
                raise TypeError("Cannot use cached_property instance without calling __set_name__ on it.")
            try:
                cache = instance.__dict__
            except AttributeError:  # not all objects have __dict__ (e.g. class defines slots)
                msg = (
                    f"No '__dict__' attribute on {type(instance).__name__!r} "
                    f"instance to cache {self.attrname!r} property."
                )
                raise TypeError(msg) from None

            maybe_obj = cache.get(self.attrname, None)
            if maybe_obj is not None:
                assert isinstance(maybe_obj, GraphCached)
                ans = maybe_obj()
                return ans

            with self.lock:
                # Check again, now with the lock
                maybe_obj = cache.get(self.attrname, None)
                if maybe_obj is not None:
                    assert isinstance(maybe_obj, GraphCached)
                    ans = maybe_obj()
                    return ans
                maybe_obj = instance.graph.graph_cached(functools.partial(self.fn, instance))
                cache[self.attrname] = maybe_obj
            ans = maybe_obj()
            return ans
        except:
            raise


class GraphTransactionContext:
    """This GraphTransactionContext is what is yielded by ResolvedGraph.ensure_transaction(). It is a proxy class that exposes
    the methods to update the graph, thereby ensuring that all graph mutations are performed within a context
    """

    def __init__(self, state: _GraphState):
        super().__init__()
        self._state = state

    def upsert_features(
        self,
        new_features: Collection[
            ScalarFeatureType
            | HasManyFeatureType
            | HasOneFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | GroupByFeatureType
        ],
    ):
        self._state.upsert_features(new_features)

    def upsert_resolvers(self, resolvers: Iterable[ResolverParsed], *, replace_on_conflict: bool):
        self._state.upsert_resolvers(resolvers, replace_on_conflict=replace_on_conflict)


@dataclasses.dataclass(frozen=True)
class _GraphSnapshot:
    """The GraphSnapshot is used to restore the state of the graph to the previous version, if there was an issue during
    a transaction. This allows us to ensure that the ResolvedGraph never leaves the transaction in a corrupted state, even
    if an exception was thrown."""

    namespace_to_features: Mapping[
        str,
        dict[
            str,
            ScalarFeatureType
            | HasManyFeatureType
            | HasOneFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | GroupByFeatureType,
        ],
    ]
    namespace_to_primary_feature: Mapping[str, ScalarFeatureType]
    namespace_to_feature_time_feature: Mapping[str, FeatureTimeFeatureType]
    short_name_to_resolver: Mapping[str, ResolverParsed]
    online_and_offline_resolvers: FrozenOrderedSet[OnlineResolverParsed | OfflineResolverParsed]
    stream_resolvers: FrozenOrderedSet[StreamResolverParsed]
    sink_resolvers: FrozenOrderedSet[SinkResolverParsed]
    resolver_id_to_resolver: Mapping[int, ResolverParsed]


class _GraphState:
    """This private graph state is where all data about the graph is stored. Its methods are exposed via the ResolvedGraph,
    or the GraphTransactionContext."""

    def __init__(self):
        super().__init__()
        # Feature caches
        self.fqn_to_feature: dict[
            str,
            ScalarFeatureType
            | HasManyFeatureType
            | HasOneFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | GroupByFeatureType,
        ] = {}
        self.namespace_to_features: dict[
            str,
            dict[
                str,
                ScalarFeatureType
                | HasManyFeatureType
                | HasOneFeatureType
                | FeatureTimeFeatureType
                | WindowedFeatureType
                | GroupByFeatureType,
            ],
        ] = {}
        self.namespace_to_primary_feature: dict[str, ScalarFeatureType] = {}
        self.namespace_to_feature_time_feature: dict[str, FeatureTimeFeatureType] = {}

        # Resolver caches
        self.short_name_to_resolver: dict[str, ResolverParsed] = {}
        self.online_and_offline_resolvers: OrderedSet[OnlineResolverParsed | OfflineResolverParsed] = OrderedSet()
        self.stream_resolvers: OrderedSet[StreamResolverParsed] = OrderedSet()
        self.sink_resolvers: OrderedSet[SinkResolverParsed] = OrderedSet()
        self.resolver_id_to_resolver: dict[int, ResolverParsed] = {}

        # featuresqls only
        self.singleton_namespaces: OrderedSet[str] = OrderedSet()

        # Strong references to stuff that is internally graph cached
        self._in_transaction = False
        self._namespace_timedelta_transforms_graph_cache = self.graph_cached(self._get_namespace_timedelta_transforms)
        self._foreign_keys_graph_cache = self.graph_cached(self._get_foreign_keys)
        self._feature_to_joined_feature_graph_cache = self.graph_cached(self._get_feature_to_joined_feature)
        self.version = 0

    def upsert_resolvers(self, resolvers: Iterable[ResolverParsed], *, replace_on_conflict: bool):
        """Update internal data structures of the graph for the given resolvers"""
        from chalkruntime.graph.resolver import (
            OfflineResolverParsed,
            OnlineResolverParsed,
            SinkResolverParsed,
        )
        from chalkruntime.graph.stream_resolver import StreamResolverParsed

        # Generate resolver ids
        if not self._in_transaction:
            raise ValueError("Must use the ensure_transaction context manager to perform a graph mutation")
        for resolver in resolvers:
            existing_resolver = self.short_name_to_resolver.get(resolver.short_name)
            if existing_resolver is not None and not replace_on_conflict:
                raise ValueError(
                    (
                        f"Multiple resolvers with the same short name when parsing the graph: "
                        f"'{self.short_name_to_resolver[resolver.short_name].fqn}' and '{resolver.fqn}'"
                        f"both have the same short name '{resolver.short_name}'"
                    ),
                )
            resolver_id = compute_resolver_id(resolver.short_name)
            if resolver_id in self.resolver_id_to_resolver and not replace_on_conflict:
                raise ValueError(
                    (
                        f"Multiple resolvers with the same ID when parsing the graph: "
                        f"'{self.resolver_id_to_resolver[resolver_id].fqn}' and '{resolver.fqn}' both have "
                        f"the same id {resolver_id}"
                    ),
                )
            if existing_resolver is not None:
                if isinstance(existing_resolver, (OnlineResolverParsed, OfflineResolverParsed)):
                    self.online_and_offline_resolvers.remove(existing_resolver)
                elif isinstance(existing_resolver, (StreamResolverParsed)):
                    self.stream_resolvers.remove(existing_resolver)
                elif isinstance(existing_resolver, SinkResolverParsed):
                    self.sink_resolvers.remove(existing_resolver)
                else:
                    raise TypeError(f"Unsupported resolver type: {type(existing_resolver)}")

                self.short_name_to_resolver.pop(existing_resolver.short_name, None)
                self.resolver_id_to_resolver.pop(resolver_id, None)

            if isinstance(resolver, (OnlineResolverParsed, OfflineResolverParsed)):
                self.online_and_offline_resolvers.add(resolver)
            elif isinstance(resolver, StreamResolverParsed):
                self.stream_resolvers.add(resolver)
            elif isinstance(resolver, SinkResolverParsed):
                self.sink_resolvers.add(resolver)
            else:
                raise TypeError(f"Unsupported resolver type: {type(resolver)}")

            self.short_name_to_resolver[resolver.short_name] = resolver
            self.resolver_id_to_resolver[resolver_id] = resolver
        self.invalidate_graph_caches()

    def invalidate_graph_caches(self):
        """Invalidate the graph caches by increasing the version.

        All GraphCached objects check this version before returning cached data. If the GraphCached's version is less than the version on the GraphState,
        then the GraphCached will invalidate its cached state at read time. This allows invalidate to be O(1) regardless of how many cached objects there are
        """
        self.version += 1

    def _add_feature(
        self,
        feature: (
            ScalarFeatureType
            | HasManyFeatureType
            | HasOneFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | GroupByFeatureType
        ),
    ):
        from chalkruntime.graph.feature import (
            FeatureTimeFeatureType,
            ScalarFeatureType,
        )

        self.fqn_to_feature[feature.fqn] = feature
        if feature.namespace not in self.namespace_to_features:
            self.namespace_to_features[feature.namespace] = {}
        self.namespace_to_features[feature.namespace][feature.name] = feature
        if isinstance(feature, ScalarFeatureType):
            if feature.primary:
                self.namespace_to_primary_feature[feature.namespace] = feature
            if feature.is_singleton:
                self.singleton_namespaces.add(feature.namespace)
        if isinstance(feature, FeatureTimeFeatureType):
            self.namespace_to_feature_time_feature[feature.namespace] = feature

    def _remove_feature(
        self,
        feature: (
            ScalarFeatureType
            | HasManyFeatureType
            | HasOneFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | GroupByFeatureType
        ),
    ):
        from chalkruntime.graph.feature import (
            FeatureTimeFeatureType,
            ScalarFeatureType,
        )

        self.fqn_to_feature.pop(feature.fqn, None)
        self.namespace_to_features[feature.namespace].pop(feature.name, None)
        if isinstance(feature, ScalarFeatureType):
            if feature.primary:
                self.namespace_to_primary_feature.pop(feature.namespace, None)
        if isinstance(feature, FeatureTimeFeatureType):
            self.namespace_to_feature_time_feature.pop(feature.namespace, None)

    def upsert_features(
        self,
        new_features: Collection[
            ScalarFeatureType
            | HasManyFeatureType
            | HasOneFeatureType
            | FeatureTimeFeatureType
            | WindowedFeatureType
            | GroupByFeatureType
        ],
    ):
        """Modify the graph with the new feature definitions. New features can be added, and existing features can be replaced if they are
        of the same type"""
        if len(new_features) == 0:
            return

        if not self._in_transaction:
            raise ValueError("Must use the ensure_transaction context manager to perform a graph mutation")
        existing_features_being_removed = (
            existing_f for x in new_features if (existing_f := self.fqn_to_feature.get(x.fqn)) is not None
        )
        for existing_feature in existing_features_being_removed:
            self._remove_feature(existing_feature)

        for x in new_features:
            self._add_feature(x)
        self.invalidate_graph_caches()

    def _get_feature_to_joined_feature(
        self,
    ) -> Mapping[ScalarFeatureType, OrderedSet[tuple[ScalarFeatureType, HasOneFeatureType | HasManyFeatureType]]]:
        from chalkruntime.graph.feature import (
            FilterParsed,
            HasManyFeatureType,
            HasOneFeatureType,
            ScalarFeatureType,
        )

        feature_to_joined_feature: dict[
            ScalarFeatureType, OrderedSet[tuple[ScalarFeatureType, HasOneFeatureType | HasManyFeatureType]]
        ] = {}

        def _get_feature_to_joined_feature_recurse(join: FilterParsed, feat: HasManyFeatureType | HasOneFeatureType):
            if isinstance(join.lhs, FilterParsed) and isinstance(join.rhs, FilterParsed) and join.operation == "and":
                _get_feature_to_joined_feature_recurse(join.lhs, feat)
                _get_feature_to_joined_feature_recurse(join.rhs, feat)
                return
            assert isinstance(join.lhs, ScalarFeatureType)
            assert isinstance(join.rhs, ScalarFeatureType)
            if join.lhs not in feature_to_joined_feature:
                feature_to_joined_feature[join.lhs] = OrderedSet()
            feature_to_joined_feature[join.lhs].add((join.rhs, feat))
            if join.rhs not in feature_to_joined_feature:
                feature_to_joined_feature[join.rhs] = OrderedSet()
            feature_to_joined_feature[join.rhs].add((join.lhs, feat))

        for feature in self.fqn_to_feature.values():
            if isinstance(feature, (HasOneFeatureType, HasManyFeatureType)):
                _get_feature_to_joined_feature_recurse(feature.join, feature)
        return feature_to_joined_feature

    @property
    def feature_to_joined_feature(self):
        return self._feature_to_joined_feature_graph_cache()

    def _get_namespace_timedelta_transforms(self):
        from chalkruntime.graph.feature import (
            HasManyFeatureType,
        )

        namespace_timedelta_transforms: defaultdict[str, timedelta] = defaultdict(timedelta)
        for feature in self.fqn_to_feature.values():
            if (
                isinstance(feature, HasManyFeatureType)
                and feature.max_staleness is not None
                and feature.max_staleness > timedelta()
            ):
                namespace_timedelta_transforms[feature.foreign_namespace()] = max(
                    namespace_timedelta_transforms[feature.foreign_namespace()],
                    feature.max_staleness,
                )
        return namespace_timedelta_transforms

    @property
    def namespace_timedelta_transforms(self):
        return self._namespace_timedelta_transforms_graph_cache()

    def _get_foreign_keys(self):
        from chalkruntime.graph.feature import (
            HasManyFeatureType,
        )

        foreign_keys: OrderedSet[ScalarFeatureType] = OrderedSet()
        for feature in self.fqn_to_feature.values():
            if (
                isinstance(feature, HasManyFeatureType)
                and feature.max_staleness is not None
                and feature.max_staleness > timedelta()
            ):
                for foreign in feature.get_foreign_join_features():
                    foreign_keys.add(foreign)
        return foreign_keys

    @property
    def foreign_keys(self):
        return self._foreign_keys_graph_cache()

    def graph_cached(self, fn: Callable[[], T]) -> GraphCached[T]:
        """Cache the result of ``fn``, and invalidate it whenever the graph is updated"""
        return GraphCached(fn, self)

    @contextlib.contextmanager
    def ensure_transaction(self):
        if self._in_transaction:
            yield
            return
        self._in_transaction = True
        snapshot = _GraphSnapshot(
            namespace_to_features={ns: dict(features) for (ns, features) in self.namespace_to_features.items()},
            namespace_to_primary_feature=dict(self.namespace_to_primary_feature),
            namespace_to_feature_time_feature=dict(self.namespace_to_feature_time_feature),
            short_name_to_resolver=dict(self.short_name_to_resolver),
            online_and_offline_resolvers=FrozenOrderedSet(self.online_and_offline_resolvers),
            stream_resolvers=FrozenOrderedSet(self.stream_resolvers),
            sink_resolvers=FrozenOrderedSet(self.sink_resolvers),
            resolver_id_to_resolver=dict(self.resolver_id_to_resolver),
        )
        try:
            yield
        except:
            # If there was an exception, restore the previous graph state
            self._restore_from_snapshot(snapshot)
            raise
        else:
            try:
                for namespace in self.namespace_to_features:
                    if namespace == PSEUDONAMESPACE:
                        continue
                    if (
                        namespace not in self.namespace_to_primary_feature
                        and namespace not in self.singleton_namespaces
                    ):
                        raise ValueError(f"No primary feature found for namespace {namespace}")
                    if namespace not in self.namespace_to_feature_time_feature:
                        raise ValueError(f"No ts feature found for namespace {namespace}")
            except:
                self._restore_from_snapshot(snapshot)
                raise
        finally:
            self._in_transaction = False

    def _restore_from_snapshot(self, snapshot: _GraphSnapshot):
        self.namespace_to_features = {ns: dict(features) for ns, features in snapshot.namespace_to_features.items()}
        self.namespace_to_primary_feature = dict(snapshot.namespace_to_primary_feature)
        self.short_name_to_resolver = dict(snapshot.short_name_to_resolver)
        self.online_and_offline_resolvers = OrderedSet(snapshot.online_and_offline_resolvers)
        self.stream_resolvers = OrderedSet(snapshot.stream_resolvers)
        self.sink_resolvers = OrderedSet(snapshot.sink_resolvers)
        self.resolver_id_to_resolver = dict(snapshot.resolver_id_to_resolver)


@final
class ResolvedGraphImpl(ResolvedGraph):
    def __init__(
        self,
        sql_sources: Sequence[BaseSQLSource],
        sql_source_groups: Sequence[SQLSourceGroup],
        online_store_configs: Sequence["OnlineStoreConfigParsed"] | None = None,
    ):
        super().__init__()
        from chalkruntime.graph.feature import (
            ScalarFeatureType,
        )
        from chalkruntime.loader.converter import RegistryConverter

        # To support forward references with graph updates, we will LAZILY collect all updates, and then apply
        # them when the graph state is actually needed. This allows the import to fully finish before we begin
        # to parse type annotations
        # To ensure that we are always using the up-to-date graph state, all methods on the ResolvedGraph
        # should access the "_state". This property applies all updates that were registered with the
        # lazily_update_features() and lazily_update_resolvers (and applies them in order), ensuring that you are working with an
        # up-to-date graph. The ONLY thing that should access the maybe_out_of_date_state is the _state property
        # Since updates are infrequent, we do not consider thread safety with this mutable ResolvedGraph object
        self._materializing = False
        self._sql_sources = {(k.kind, k.name): k for k in sql_sources}
        self._sql_source_groups = {k.name: k for k in sql_source_groups}
        self._sql_sources_by_name = {k.name: k for k in sql_sources}
        self._online_store_configs = tuple(online_store_configs or [])
        self._maybe_out_of_date_state = _GraphState()
        self._lazy_feature_updates: deque[Callable[[], object]] = deque()
        self._lazy_resolver_updates: deque[Callable[[], object]] = deque()

        with self.ensure_transaction() as ctx:
            converter = RegistryConverter(self)
            converted_psuedofeatures: list[ScalarFeatureType] = []
            for x in PSEUDOFEATURES:
                converted = converter.convert_type(x)
                assert isinstance(converted, ScalarFeatureType)
                converted_psuedofeatures.append(converted)
            ctx.upsert_features(converted_psuedofeatures)

        self._root_fqn_to_feature_cache: GraphCached[
            dict[
                str,
                ScalarFeatureType
                | HasOneFeatureType
                | HasManyFeatureType
                | WindowedFeatureType
                | FeatureTimeFeatureType
                | GroupByFeatureType
                | InputFeatureType[
                    ScalarFeatureType
                    | HasOneFeatureType
                    | HasManyFeatureType
                    | WindowedFeatureType
                    | FeatureTimeFeatureType
                ]
                | None,
            ]
        ] = self.graph_cached(dict)

    @property
    def sql_sources(self):
        return self._sql_sources.values()

    def get_sql_source_by_name(self, name: str) -> BaseSQLSource | None:
        return self._sql_sources_by_name.get(name)

    def get_sql_source(self, kind: SQLSourceKind, name: str | None) -> BaseSQLSource | None:
        return self._sql_sources.get((kind, name))

    def get_sql_source_group(self, name: str) -> SQLSourceGroup | None:
        return self._sql_source_groups.get(name)

    @property
    def online_store_configs(self):
        return self._online_store_configs

    def lazily_update_features(self, hook: Callable[[], object]):
        """Register a hook that will be invoked the next time the graph state is accessed. Hooks will
        be applied in the order that they are registered."""
        self._lazy_feature_updates.append(hook)

        # Also resetting all graph cache hooks, as they may trigger materialization when invalidated
        self._maybe_out_of_date_state.invalidate_graph_caches()

    def lazily_update_resolvers(self, hook: Callable[[], object]):
        """Register a hook that will be invoked the next time the graph state is accessed. Hooks will
        be applied in the order that they are registered."""
        self._lazy_resolver_updates.append(hook)

        # Also resetting all graph cache hooks, as they may trigger materialization when invalidated

        self._maybe_out_of_date_state.invalidate_graph_caches()

    def materialize(self):
        """Register run all lazy state updates, and materialize the graph"""
        if self._materializing or (len(self._lazy_feature_updates) == 0 and len(self._lazy_resolver_updates) == 0):
            # Prevent recursion errors: If you are materializing, and you access the graph
            # Then you will see the current, partially materialized graph state
            # Also, if you have no updates to make, then short circuit
            return
        self._materializing = True
        try:
            with self._state.ensure_transaction():
                while len(self._lazy_feature_updates) > 0:
                    updater = self._lazy_feature_updates.popleft()
                    updater()
                while len(self._lazy_resolver_updates) > 0:
                    updater = self._lazy_resolver_updates.popleft()
                    updater()
        finally:
            self._materializing = False

    @property
    def _state(self) -> _GraphState:
        """Get the up-to-date, internal graph state."""
        self.materialize()
        # Now the state is up-to-date
        return self._maybe_out_of_date_state

    @property
    def features(
        self,
    ) -> Iterable[
        ScalarFeatureType
        | HasManyFeatureType
        | HasOneFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | GroupByFeatureType
    ]:
        return self._state.fqn_to_feature.values()

    @property
    def fqn_to_feature(
        self,
    ) -> Mapping[
        str,
        ScalarFeatureType
        | HasManyFeatureType
        | HasOneFeatureType
        | GroupByFeatureType
        | FeatureTimeFeatureType
        | WindowedFeatureType
        | GroupByFeatureType,
    ]:
        return self._state.fqn_to_feature

    def feature_from_fqn(
        self, fqn: str
    ) -> (
        ScalarFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | WindowedFeatureType
        | FeatureTimeFeatureType
        | GroupByFeatureType
        | InputFeatureType[
            ScalarFeatureType | HasOneFeatureType | HasManyFeatureType | WindowedFeatureType | FeatureTimeFeatureType
        ]
        | None
    ):
        fqn_cache = self._root_fqn_to_feature_cache()
        if fqn in fqn_cache:
            return fqn_cache[fqn]

        from chalkruntime.graph.feature import (
            get_alias_prefix_from_str,
            remove_alias_prefix_from_str,
        )

        if alias_prefix := get_alias_prefix_from_str(fqn):
            # Prefix-aliased features look like `"alpha:user.id"` - they are a string followed by a colon, followed by
            # an ordinary feature. They are identical to the 'unprefixed' feature in every way, except that they exist
            # in their own parallel namespace with their own parallel relationships.
            #
            # This allows the same feature/namespace to be 'reused' in different parts of a plan, while distinguishing
            # them so that they can be told apart.
            #
            # We load them by looking up the original feature, and then copying it to include the alias prefix.
            unaliased_fqn = remove_alias_prefix_from_str(fqn, alias_prefix=alias_prefix)
            feature = self.feature_from_fqn(unaliased_fqn)
            if feature is None:
                return None

            # Add the specified alias prefix to the returned feature.
            return feature.copy_with_root_alias(root_alias=alias_prefix)

        components = fqn.split(".")
        if len(components) < 2:
            # Invalid
            return None
        if len(components) == 2:
            # Not a root fqn, simply return from the fqn_to_features dict. No need to cache
            feature = self._state.fqn_to_feature.get(fqn)
            if feature is None and fqn.endswith("@1"):
                feature = self._state.fqn_to_feature.get(fqn.replace("@1", ""))
            return feature

        ans = self._compute_input_feature_type(components)
        fqn_cache[fqn] = ans
        return ans

    def fqns_to_schema(self, fqns: Iterable[str]) -> PyArrowSchema | None:
        fields: dict[str, PyArrowDataType] = {}
        for fqn in fqns:
            feature = self.feature_from_fqn(fqn)
            if feature is None:
                return None

            fields[fqn] = feature.underlying.pyarrow_dtype

        return make_schema(fields)

    def _compute_input_feature_type(self, fqn_components: Sequence[str]):
        # Keep track of all features we accessed when computing this (input) feature type, so we can efficiently reset the cache if needed
        from chalkruntime.graph.feature import (
            HasManyFeatureType,
            HasOneFeatureType,
            HasOnePathObjParsed,
            InputFeatureType,
        )

        assert len(fqn_components) > 2, "Should only be called if given a fqn that produces an input feature type"

        has_relation = self._state.fqn_to_feature.get(".".join(fqn_components[0:2]))
        if has_relation is None:
            return None
        path: list[HasOnePathObjParsed] = []
        for component in fqn_components[2:]:
            if not isinstance(has_relation, (HasOneFeatureType, HasManyFeatureType)):
                return None
            next_feature_fqn = f"{has_relation.foreign_namespace()}.{component}"
            next_step = self._state.fqn_to_feature.get(next_feature_fqn)
            if next_step is None:
                return None
            path.append(
                HasOnePathObjParsed(
                    parent=has_relation,
                    child=next_step,
                )
            )
            has_relation = next_step

        return InputFeatureType(underlying_ref=path[-1].child, path=tuple(path), _graph=self)

    def get_write_max_staleness(self, f: ScalarFeatureType) -> timedelta:
        if f.namespace in self._state.namespace_timedelta_transforms and (
            # In any case, the primary key and foreign key should be cached.
            f.primary or f in self._state.foreign_keys
        ):
            return max(
                f.minimum_write_max_staleness,
                self._state.namespace_timedelta_transforms[f.namespace],
            )
        else:
            return f.minimum_write_max_staleness

    def get_features_in_namespace(
        self, namespace: str
    ) -> Collection[
        ScalarFeatureType
        | HasOneFeatureType
        | HasManyFeatureType
        | WindowedFeatureType
        | FeatureTimeFeatureType
        | GroupByFeatureType
    ]:
        from chalkruntime.graph.feature import (
            get_alias_prefix_from_str,
            remove_alias_prefix_from_str,
        )

        if alias_prefix := get_alias_prefix_from_str(namespace):
            # See `ResolvedGraph.feature_from_fqn` or `remove_alias_prefix_from_str` for
            # additional information.
            #
            # The namespace might have an alias prefix - remove it, and then get the original features,
            # and lastly add the alias prefix to each of them before returning the result.
            unaliased_namespace = remove_alias_prefix_from_str(namespace, alias_prefix=alias_prefix)
            unaliased_features = self.get_features_in_namespace(unaliased_namespace)
            return tuple(f.copy_with_root_alias(root_alias=alias_prefix) for f in unaliased_features)

        return self._state.namespace_to_features[namespace].values()

    def primary_feature_for_namespace(self, namespace: str) -> ScalarFeatureType | None:
        from chalkruntime.graph.feature import (
            get_alias_prefix_from_str,
            remove_alias_prefix_from_str,
        )

        if alias_prefix := get_alias_prefix_from_str(namespace):
            unaliased_namespace = remove_alias_prefix_from_str(namespace, alias_prefix=alias_prefix)
            original_pkey = self.primary_feature_for_namespace(unaliased_namespace)
            if original_pkey is not None:
                return original_pkey.copy_with_root_alias(alias_prefix)
            return None
        return self._state.namespace_to_primary_feature.get(namespace)

    @property
    def all_namespaces(self):
        return self._state.namespace_to_features

    def ts_feature_for_namespace(self, output_namespace: str) -> FeatureTimeFeatureType | None:
        from chalkruntime.graph.feature import (
            get_alias_prefix_from_str,
            remove_alias_prefix_from_str,
        )

        if alias_prefix := get_alias_prefix_from_str(output_namespace):
            unaliased_output_namespace = remove_alias_prefix_from_str(output_namespace, alias_prefix=alias_prefix)
            original_ts = self.ts_feature_for_namespace(unaliased_output_namespace)
            if original_ts is not None:
                return original_ts.copy_with_root_alias(alias_prefix)
            return None
        return self._state.namespace_to_feature_time_feature.get(output_namespace)

    @property
    def resolvers(self):
        return self._state.short_name_to_resolver.values()

    @property
    def resolver_id_to_resolver(self) -> Mapping[int, ResolverParsed]:
        return self._state.resolver_id_to_resolver

    @property
    def stream_resolvers(self):
        return self._state.stream_resolvers

    @property
    def sink_resolvers(self):
        return self._state.sink_resolvers

    def resolver_by_name(self, short_name_or_fqn: str) -> ResolverParsed | None:
        short_name = short_name_or_fqn.split(".")[-1]
        return self._state.short_name_to_resolver.get(short_name)

    # FIXME: We should probably do something smart here to avoid dealing with loading the whole relationship tree
    # strictly. Need to think really hard about this.
    def features_for_feature_namespace(self, namespace: str) -> Collection[FeatureType]:
        from chalkruntime.graph.feature import (
            NamedFeatureType,
            get_alias_prefix_from_str,
            remove_alias_prefix_from_str,
        )

        if alias_prefix := get_alias_prefix_from_str(namespace):
            unaliased_namespace = remove_alias_prefix_from_str(namespace, alias_prefix=alias_prefix)
            unaliased_features = self.features_for_feature_namespace(unaliased_namespace)
            return tuple(
                f.copy_with_root_alias(alias_prefix) if isinstance(f, NamedFeatureType) else f
                for f in unaliased_features
            )
        return self._state.namespace_to_features.get(namespace, {}).values()

    @property
    def feature_to_joined_feature(self):
        return self._state.feature_to_joined_feature

    def graph_cached(self, fn: Callable[[], T]) -> GraphCached[T]:
        """Cache the result of ``fn``, and invalidate it whenever the graph is updated"""
        return self._state.graph_cached(fn)

    def graph_cached_with_graph(self, fn: Callable[[ResolvedGraph], T]) -> GraphCached[T]:
        """Cache the result of ``fn``, and invalidate it whenever the graph is updated"""
        return self._state.graph_cached(lambda: fn(self))

    @contextlib.contextmanager
    def ensure_transaction(self):
        with self._state.ensure_transaction():
            yield GraphTransactionContext(self._state)
