import dataclasses
import json
from typing import TYPE_CHECKING, Type

from chalk.client import ChalkError
from chalk.utils.log_with_context import get_logger, get_public_logger

from chalkruntime.graph.stream_resolver import StreamResolverParsed
from chalkruntime.streaming.types import (
    DataClassAny,
)

if TYPE_CHECKING:
    from pydantic import BaseModel
else:
    try:
        from pydantic.v1 import BaseModel
    except ImportError:
        from pydantic import BaseModel

FAILURE_RETRY_SLEEP_SECONDS = 5

_logger = get_logger(__name__)
_public_logger = get_public_logger(__name__)


def coerce_streaming_message_body(
    value_raw: bytes, typ: "Type[BaseModel | DataClassAny | str | bytes]"
) -> "BaseModel | DataClassAny | str | bytes":
    if typ is bytes:
        return value_raw
    elif typ is str:
        return value_raw.decode("utf8")
    elif issubclass(typ, BaseModel):
        return typ.parse_raw(value_raw, encoding="utf8")
    elif dataclasses.is_dataclass(typ):
        return typ(**json.loads(value_raw.decode("utf8")))
    else:
        raise TypeError(f"Unsupported message body type {typ}")


def serialize_state_value(value: "BaseModel | DataClassAny"):
    return value.json() if isinstance(value, BaseModel) else json.dumps(dataclasses.asdict(value))


def deserialize_state_value(value: str, typ: "Type[BaseModel | DataClassAny]"):
    if issubclass(typ, BaseModel):
        return typ.parse_raw(value)
    elif dataclasses.is_dataclass(typ):
        return typ(**json.loads(value))
    raise TypeError(f"Unsupported state type {typ}")


def log_resolver_error(resolver: StreamResolverParsed, error: ChalkError, public: bool):
    message = (
        f"{error.exception.kind}: {error.exception.message}\n{error.exception.stacktrace}"
        if error.exception is not None
        else f"exception {error}: {error.message}"
    )

    _logger.debug(f"While evaluating '{resolver.fqn}, received error: {message}")
    if public:
        _public_logger.error(message)
