from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import (
    AsyncIterator,
)

import pyarrow as pa
from chalk.client.models import ChalkError, ErrorCode
from chalk.sql._internal.query_execution_parameters import QueryExecutionParameters
from chalk.utils.chalk_record_batch import ChalkRecordBatch
from chalk.utils.threading import (
    ChalkThreadPoolExecutor,
)
from chalk.utils.tracing import PerfTimer
from typing_extensions import final

from chalkruntime.constants import (
    INDEX_COL_NAME,
    TS_COL_NAME,
)
from chalkruntime.exc.resolver_errors import (
    ResolverErrors,
)
from chalkruntime.exc.wrapped_resolver_exception import WrappedResolverException
from chalkruntime.graph.feature import (
    ScalarFeatureType,
)
from chalkruntime.graph.resolver import OfflineResolverParsed, OnlineResolverParsed, ResourceHintType
from chalkruntime.invoker.batch_result_collector import (
    ResolverOutputMetadata,
    ResultCollector,
)
from chalkruntime.invoker.bound_invoker import (
    BoundInvokerProtocol,
    InvokerConfig,
    InvokerContext,
)
from chalkruntime.invoker.overlay_features import OverlayFeatureRegistry, overlay_registry_ctx
from chalkruntime.invoker.resolver_input import LocalResolverInputs
from chalkruntime.invoker.resolver_result import BatchResolverResult
from chalkruntime.invoker.resolver_runner import get_resolver_runner
from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter


@final
class NoArgScalarBoundInvoker(BoundInvokerProtocol):
    def __init__(
        self,
        resolver: OnlineResolverParsed | OfflineResolverParsed,
        pkey_feature: ScalarFeatureType,
        resolver_executor: ChalkThreadPoolExecutor,
        fallback_resource_hint: ResourceHintType,
        query_execution_parameters: QueryExecutionParameters,
        overlay_feature_registry: OverlayFeatureRegistry | None,
    ):
        super().__init__()
        self._registry = overlay_feature_registry
        with overlay_registry_ctx(self._registry):
            resolver_output_metadata = ResolverOutputMetadata.from_resolver(
                resolver=resolver, pkey_feature=pkey_feature
            )
            self._resolver = resolver
            self._pkey_feature = pkey_feature
            self._resolver_executor = resolver_executor
            self._resolver_output_metadata = resolver_output_metadata
            self._query_execution_parameters = query_execution_parameters
            self._registry = overlay_feature_registry
            self.resolver_runner = get_resolver_runner(
                resolver=self._resolver,
                resolver_output_metadata=self._resolver_output_metadata,
                resolver_executor=self._resolver_executor,
                effective_resource_hint=fallback_resource_hint
                if resolver.resource_hint is None
                else resolver.resource_hint,
            )

    async def single_call(
        self,
        batch: LocalResolverInputs,
        config: InvokerConfig,
        rewriter: QueryRewriter,
    ) -> BatchResolverResult:
        with overlay_registry_ctx(self._registry):
            observed_at_fallback = batch.observed_at_fallback
            ran_at = datetime.now(timezone.utc)
            assert observed_at_fallback is None or observed_at_fallback.utcoffset() == timedelta(0)

            result_collector = ResultCollector(
                resolver_fqn=self._resolver.fqn,
                strict_validations=self._resolver.strict_validations,
                resolver_metadata=self._resolver_output_metadata,
                observed_at_fallback=observed_at_fallback,
                check_duplicate_rows=False,
                feature_fqn_to_resolver_fqn={},
                error_on_ellipsis=True,
            )

            with PerfTimer() as pt:
                try:
                    result = await anext(
                        self.resolver_runner.run_resolver(
                            resolver_args=[],
                            rewriter=rewriter,
                            execution_context=None,
                            query_execution_parameters=self._query_execution_parameters,
                        ),
                        ChalkError.create(
                            message="Failed to return any values",
                            code=ErrorCode.RESOLVER_FAILED,
                        ),
                    )

                except WrappedResolverException as e:
                    result = ResolverErrors.resolver_raised_exception(
                        resolver_fqn=self._resolver.fqn,
                        exception=e,
                    )

            if isinstance(result, ChalkError):
                return BatchResolverResult(
                    data=None,
                    errors=[result],
                    ran_at=ran_at,
                    num_failed_invocations=1,
                    num_successful_invocations=0,
                    resolver_invocation_secs=pt.duration_seconds,
                    num_resolver_timeouts=0,
                    num_skipped_invocations=0,
                    result_collector_num_rows=0,
                )

            output_root_fqns = result.output_root_fqns
            if result_collector.override_output_fqns(output_root_fqns):
                # there's a few mutations here, but it's fine because this should only happen
                # once before anything important is done
                assert output_root_fqns is not None
                resolver_output_metadata = self._resolver_output_metadata.subset(output_root_fqns)
                result_collector._metadata = resolver_output_metadata  # pyright: ignore[reportPrivateUsage]
            result_collector.add_result(
                index=0,
                pkey=None,
                execution_timestamp=None,
                result=result.data,
            )

            """Collect the results in the results collector into a BatchResolverResult"""
            result_table_or_err = result_collector.collect_results()

            errors = [x.error for x in result_collector.errors]
            if isinstance(result_table_or_err, ChalkError):
                errors.append(result_table_or_err)

            if len(errors) > 0:
                return BatchResolverResult(
                    data=None,
                    errors=errors,
                    ran_at=ran_at,
                    num_failed_invocations=1,
                    num_successful_invocations=0,
                    num_resolver_timeouts=0,
                    resolver_invocation_secs=pt.duration_seconds,
                    num_skipped_invocations=0,
                    result_collector_num_rows=0,
                )
                return

            assert batch.scalarish_features is not None
            assert not isinstance(result_table_or_err, ChalkError), "Handled errors above"
            scalarish_features = batch.scalarish_features
            num_input_rows = len(scalarish_features)

            d: dict[str, pa.Array | pa.ChunkedArray] = {
                k: pa.array([v[0]] * num_input_rows, type=v.type) for k, v in result_table_or_err.data.items()
            }
            d[TS_COL_NAME] = scalarish_features.column(TS_COL_NAME)
            d[INDEX_COL_NAME] = scalarish_features.column(INDEX_COL_NAME)
            if not result_table_or_err.contains_column_name(self._pkey_feature.fqn):
                d[self._pkey_feature.fqn] = scalarish_features.column(self._pkey_feature.fqn)

            data_tbl = ChalkRecordBatch.from_pydict(d).to_record_batch()

            return BatchResolverResult(
                data=data_tbl,
                errors=errors,
                num_failed_invocations=0,
                num_successful_invocations=num_input_rows,
                num_resolver_timeouts=0,
                ran_at=ran_at,
                resolver_invocation_secs=pt.duration_seconds,
                num_skipped_invocations=0,
                result_collector_num_rows=num_input_rows,
            )

    async def __call__(
        self,
        batch: LocalResolverInputs,
        config: InvokerConfig,
        rewriter: QueryRewriter,
        invoker_context: InvokerContext,
    ) -> AsyncIterator[BatchResolverResult]:
        yield await self.single_call(batch=batch, config=config, rewriter=rewriter)
