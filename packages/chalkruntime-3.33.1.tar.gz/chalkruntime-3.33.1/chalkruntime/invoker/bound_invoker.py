from __future__ import annotations

import dataclasses
from typing import (
    TYPE_CHECKING,
    Any,
    AsyncIterator,
    Protocol,
)

from chalk.queries.query_context import ContextJsonDict
from chalk.utils.log_with_context import (
    get_logger,
)

from chalkruntime.invoker.resolver_input import LocalResolverInputs
from chalkruntime.invoker.resolver_result import BatchResolverResult
from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter

if TYPE_CHECKING:
    from pydantic import BaseModel
else:
    try:
        from pydantic.v1 import BaseModel
    except ImportError:
        from pydantic import BaseModel


class PlanTimeInvokerConfig(BaseModel, frozen=True):
    """InvokerConfig that is known at planning time"""

    environment_id: str
    deployment_id: str
    operation_kind: str
    query_name: str | None
    query_name_version: str | None
    query_tags: frozenset[str]
    branch_id: str | None
    store_plan_stages: bool
    use_pa_for_vectorized_args: bool
    needs_pkey_feature_values_in_inputs: bool
    ensure_distinct_resolver_results: bool
    scope_feature_time_to_namespace: bool
    velox_preferred_output_batch_bytes: int
    enable_indexed_has_many_joins: bool
    skip_batch_filter_partitioning_logic: bool
    # TODO: remove (no longer used)
    eager_join_matching: bool
    oom_slim_hm_by_dates: bool
    oom_slim_hm_by_join_keys: bool
    short_circuit_on_no_hm_rows: bool
    oom_max_num_inputs_per_hm_sample: int
    # should correspond to the planner option value
    allow_planner_postponed_has_many_sampling: bool
    invoker_uses_strict_timeouts: bool


class InvokerConfig(PlanTimeInvokerConfig, frozen=True):
    operation_id: str
    correlation_id: str | None
    query_context: ContextJsonDict | None


_logger = get_logger(__name__)


class InvokerContext(BaseModel, frozen=True):
    operator_id: str | None
    dfs_id: int | None
    batch_idx: int
    chunk_idx: int | None
    use_one_to_one_invoker: bool

    if TYPE_CHECKING:

        def replace(self, *, chunk_idx: int | None = ...) -> InvokerContext: ...
    else:

        def replace(self, **kwargs: Any) -> InvokerContext:
            return self.copy(update=kwargs)


@dataclasses.dataclass
class ResolverRunStats:
    num_skipped_invocations: int = 0
    num_successful_invocations: int = 0
    num_failed_invocations: int = 0
    num_resolver_timeouts: int = 0
    resolver_invocation_secs: float = 0.0

    def __add__(self, other: ResolverRunStats):
        return ResolverRunStats(
            num_skipped_invocations=self.num_skipped_invocations + other.num_skipped_invocations,
            num_successful_invocations=self.num_successful_invocations + other.num_successful_invocations,
            num_failed_invocations=self.num_failed_invocations + other.num_failed_invocations,
            num_resolver_timeouts=self.num_resolver_timeouts + other.num_resolver_timeouts,
            resolver_invocation_secs=self.resolver_invocation_secs + other.resolver_invocation_secs,
        )


class BoundInvokerProtocol(Protocol):
    def __call__(
        self,
        batch: LocalResolverInputs,
        config: InvokerConfig,
        rewriter: QueryRewriter,
        invoker_context: InvokerContext,
    ) -> AsyncIterator[BatchResolverResult]: ...
