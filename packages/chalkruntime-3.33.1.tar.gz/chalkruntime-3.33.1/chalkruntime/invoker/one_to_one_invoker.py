from __future__ import annotations

import asyncio
import itertools
import time
from concurrent.futures import Future
from datetime import datetime, timezone
from typing import (
    Any,
    AsyncIterator,
    ContextManager,
    Coroutine,
    Iterable,
    Sequence,
    cast,
)

import polars as pl
import pyarrow as pa
from chalk.client.models import ChalkError
from chalk.features import DataFrame, Feature, Features
from chalk.sql import FinalizedChalkQuery
from chalk.sql._internal.chalk_query import ChalkQuery
from chalk.sql._internal.query_execution_parameters import QueryExecutionParameters
from chalk.sql._internal.string_chalk_query import StringChalkQuery
from chalk.utils.async_helpers import run_coroutine_fn_threadsafe
from chalk.utils.chalk_record_batch import ChalkRecordBatch
from chalk.utils.collections import FrozenOrderedSet, OrderedSet, get_unique_item, unwrap_optional
from chalk.utils.df_utils import describe_type_of_dataframe, to_pydict, to_pylist
from chalk.utils.log_with_context import add_logging_context
from chalk.utils.threading import (
    ChalkThreadPoolExecutor,
)
from chalk.utils.tracing import PerfTimer, safe_trace
from typing_extensions import final

from chalkruntime.constants import (
    INDEX_COL_NAME,
    TS_COL_NAME,
)
from chalkruntime.exc.failed_argument import (
    FailedArgument,
)
from chalkruntime.exc.resolver_errors import ResolverErrors
from chalkruntime.exc.wrapped_resolver_exception import WrappedResolverException
from chalkruntime.graph.feature import (
    DataFrameType,
    HasManyFeatureType,
    InputFeatureType,
    WindowedFeatureType,
    is_general_has_many,
    is_optional_has_one,
    is_underlying_feature_time,
    is_underlying_has_one,
    is_underlying_scalar,
)
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.resolver import (
    MainProcOnlineResolver,
    OfflineResolverParsed,
    OnlineResolverParsed,
    ResolverArgErrorHandlerParsed,
    TResolverFeatureType,
)
from chalkruntime.graph.singletons import CHALK_GLOBAL_SINGLETON_ID, CHALK_SINGLETON_VALUE
from chalkruntime.invoker.batch_result_collector import (
    ResolverOutputMetadata,
    ResultCollector,
)
from chalkruntime.invoker.bound_invoker import (
    BoundInvokerProtocol,
    InvokerConfig,
    InvokerContext,
    ResolverRunStats,
)
from chalkruntime.invoker.overlay_features import OverlayFeatureRegistry, overlay_registry_ctx
from chalkruntime.invoker.resolver_args_builder import ResolverArgsBuilder
from chalkruntime.invoker.resolver_input import LocalResolverInputs
from chalkruntime.invoker.resolver_result import BatchResolverResult
from chalkruntime.invoker.resolver_runner import (
    async_handle_batch,
    sync_handle_batch,
)
from chalkruntime.metadata import (
    get_chalk_fix_invalid_result_propagation,
)
from chalkruntime.sql_rewriter.query_rewriter import QueryRewriter
from chalkruntime.utils.async_helpers import wait_for_futures
from chalkruntime.utils.internal_pl_utils import PolarsPanicErrorCompat  # pyright: ignore

pd = None

try:
    import pandas as pd
except ImportError:
    pass

_PKey = int | str

_COUNTER = itertools.count()


def _assimilate_resolvers(
    resolvers: FrozenOrderedSet[OnlineResolverParsed | OfflineResolverParsed],
    executor: ChalkThreadPoolExecutor,
):
    root_ns = get_unique_item(res.unique_input_root_ns for res in resolvers)
    graph = get_unique_item(res.graph for res in resolvers)
    # Note: this is mutated below if any of the resolvers are async to prevent crashes
    is_cpu_bound = get_unique_item(res.resource_hint == "cpu" for res in resolvers)
    pkey_feature = graph.primary_feature_for_namespace(root_ns)
    assert pkey_feature is not None

    input_refs: dict[TResolverFeatureType, int] = {}
    output_refs: OrderedSet[TResolverFeatureType] = OrderedSet()

    resolver_to_input_fqns_has_default_and_defaults: dict[
        OnlineResolverParsed | OfflineResolverParsed,
        tuple[ResolverOutputMetadata, Sequence[tuple[TResolverFeatureType, int, bool, Any]]],
    ] = {}

    default_args: list[ResolverArgErrorHandlerParsed | None] = []

    for resolver in resolvers:
        inputs: list[tuple[TResolverFeatureType, int, bool, Any]] = []
        for i, inp_feature in enumerate(resolver.inputs):
            if inp_feature not in input_refs:
                input_refs[inp_feature] = len(input_refs)
            position = input_refs[inp_feature]
            maybe_default_arg = resolver.default_args[i]
            if maybe_default_arg is None:
                assert not isinstance(inp_feature, DataFrameType)
                if inp_feature.underlying.primitive_converter.has_default:
                    inputs.append(
                        (inp_feature, position, True, Feature.from_root_fqn(inp_feature.fqn).converter.rich_default)
                    )
                    default_args.append(ResolverArgErrorHandlerParsed(default_value=...))
                else:
                    inputs.append((inp_feature, position, False, None))
                    default_args.append(ResolverArgErrorHandlerParsed(default_value=...))
            else:
                inputs.append((inp_feature, position, True, maybe_default_arg.default_value))
                default_args.append(maybe_default_arg)
        for out in resolver.output:
            output_refs.add(out)
        metadata = ResolverOutputMetadata.from_resolver(resolver, pkey_feature)
        resolver_to_input_fqns_has_default_and_defaults[resolver] = (
            metadata,
            tuple(inputs),
        )
        if metadata.is_async:
            is_cpu_bound = False

    if not get_chalk_fix_invalid_result_propagation():
        default_args = [ResolverArgErrorHandlerParsed(default_value=...) for _ in input_refs]
    if is_cpu_bound:
        fn = CPUBoundParallelResolver(
            resolver_to_input_fqns_has_default_and_defaults,
            input_refs=input_refs,
            output_refs=output_refs,
            default_args=default_args,
        )
    else:
        fn = IOBoundParallelResolver(
            resolver_to_input_fqns_has_default_and_defaults,
            executor,
            input_refs=input_refs,
            output_refs=output_refs,
            default_args=default_args,
        )
    return fn


_SPECIAL_CLASSES = (
    pl.LazyFrame,
    DataFrame,
    pa.RecordBatch,
    pa.Table,
    pl.DataFrame,
) + ((pd.DataFrame,) if pd is not None else ())


def _handle_resolver_result(
    result: Any,
    resolver: OnlineResolverParsed | OfflineResolverParsed,
    metadata: ResolverOutputMetadata,
) -> Sequence[tuple[str, Any]] | ChalkError:
    if result.__class__ in _SPECIAL_CLASSES:
        if pd is not None and isinstance(result, pd.DataFrame):
            result = pl.from_pandas(result)

        if isinstance(result, DataFrame):
            result = result.to_polars().collect()

        if isinstance(result, pa.RecordBatch):
            result = pa.Table.from_batches([result])

        if isinstance(result, (pa.Table, pl.DataFrame)):
            # we returned a dataframe when we were expecting a single row
            if metadata.single_output_feature is not None:
                if is_underlying_scalar(metadata.single_output_feature):
                    if result.shape == (0, 1):
                        expected_type_name = (
                            metadata.single_output_feature.underlying.to_feature().converter.rich_type.__name__
                        )
                        if expected_type_name != "Optional":
                            return ResolverErrors.wrong_output_type(
                                resolver_fqn=resolver.fqn,
                                expected_type_name=expected_type_name,
                                result_type_name="NoneType",
                                feature_fqn=metadata.single_output_feature.fqn,
                            )
                        else:
                            result = pl.DataFrame(
                                {
                                    col: [None]
                                    for col in (
                                        result.columns if isinstance(result, pl.DataFrame) else result.column_names
                                    )
                                }
                            )
                    elif result.shape != (1, 1):
                        return ResolverErrors.wrong_output_type(
                            resolver_fqn=resolver.fqn,
                            expected_type_name=(
                                f"{metadata.single_output_feature.underlying.to_feature().converter.rich_type.__name__} "
                                f"(underlying type of feature '{metadata.single_output_feature.root_fqn}')"
                            ),
                            result_type_name=describe_type_of_dataframe(result),
                            feature_fqn=metadata.single_output_feature.fqn,
                        )
                    # Extract the single item from the DF and discard the columns
                    result = result.item() if isinstance(result, pl.DataFrame) else to_pydict(result).popitem()[1][0]
                else:
                    # This is a has-many feature, so we put it in a dictionary to escape the detection of a dataframe
                    # We also convert it to the DataFrame type, since its columns will be features anyway
                    if isinstance(result, pa.Table):
                        result = pl.DataFrame(result)
                    expected_columns = cast(HasManyFeatureType, metadata.single_output_feature.underlying).df.columns
                    expected_schema = {
                        col.root_fqn: col.underlying.polars_dtype
                        for col in expected_columns
                        if not isinstance(col.underlying, WindowedFeatureType)
                    }
                    if result.schema != expected_schema:
                        return ResolverErrors.wrong_df_columns(
                            resolver_fqn=resolver.fqn,
                            expected=expected_schema.keys(),
                            actual=FrozenOrderedSet(result.columns),
                            path=metadata.single_output_feature.underlying.fqn,
                        )
                    result = {metadata.single_output_feature.root_fqn: DataFrame(result)}
            else:
                all_output_columns_optional = [
                    is_underlying_scalar(out_feat) and out_feat.underlying.is_feature_nullable
                    for out_feat in metadata.output_schema
                ]
                if len(result) == 0 and all_output_columns_optional:
                    column_names = result.columns if isinstance(result, pl.DataFrame) else result.column_names
                    # Intentionally not passing a schema here, because
                    # we will just turn this DF into a dict of {fqn: None}
                    # below
                    result = pl.DataFrame({col: [None] for col in column_names})
                elif len(result) != 1:
                    return ResolverErrors.dataframe_instead_of_scalar(
                        resolver_fqn=resolver.fqn,
                        dataframe_shape=result.shape,
                        dataframe_columns=(result.column_names if isinstance(result, pa.Table) else result.columns),
                    )
                result = result.to_dicts()[0] if isinstance(result, pl.DataFrame) else result.to_pylist()[0]
    if getattr(result, "__is_features__", False):  # This is faster than the subclass check
        result_dict: dict[str, Any] = {}

        def recurse_over_results(r: Any, fqn_parent: str):
            for f in cast(Features, r).features:
                if hasattr(r, f.attribute_name) and not f.no_display:
                    f_attr = getattr(r, f.attribute_name)
                    path = f.root_fqn if fqn_parent == "" else fqn_parent + f.root_fqn.split(".", 1)[-1]
                    if getattr(f_attr, "__is_features__", False):
                        recurse_over_results(f_attr, path + ".")
                    else:
                        result_dict[path] = getattr(r, f.attribute_name)

        recurse_over_results(result, "")
    elif isinstance(result, dict):
        result_dict = {str(k): v for k, v in result.items()}
    elif metadata.single_output_feature is not None and metadata.is_one_to_one_resolver:
        result_dict = {metadata.single_output_feature.root_fqn: result}
    elif result is None and all(
        is_optional_has_one(f) or (is_underlying_scalar(f) and f.underlying.is_feature_nullable)
        for f in metadata.output_schema
    ):
        result_dict = {col.root_fqn: ... for col in metadata.output_schema}
    else:
        return ResolverErrors.wrong_output_type(
            resolver_fqn=resolver.fqn,
            expected_type_name="DataFrame, Mapping, or Features set",
            result_type_name=type(result).__name__,
            feature_fqn=None,
        )
    key_err = _check_keys(result_dict, metadata, resolver.fqn)
    if key_err is not None:
        return key_err
    return tuple((k, v) for (k, v) in result_dict.items() if k in metadata.resolver_output_root_fqns)


def _check_keys(result_row: dict[str, Any], metadata: ResolverOutputMetadata, resolver_fqn: str) -> ChalkError | None:
    if result_row.keys() != metadata.resolver_output_root_fqns._items.keys():  # pyright: ignore[reportPrivateUsage]
        # Hack to fix a bug where we allowed returning the sub-class directly without it being wrapped in the parent class
        output_fqns_to_features = {x.root_fqn: x for x in metadata.output_schema}
        for k in tuple(result_row):
            if (
                k not in metadata.resolver_output_root_fqns
                and (root_fqn := metadata.resolver_output_fqn_to_root_fqn.get(k)) is not None
            ):
                if root_fqn not in result_row:
                    # If the root fqn is already there, then prefer that
                    result_row[root_fqn] = result_row[k]
                del result_row[k]
            else:
                root_fqn = k
            if root_fqn in output_fqns_to_features:
                root_feature = output_fqns_to_features[root_fqn]
                if (
                    isinstance(root_feature, InputFeatureType)
                    and root_feature.underlying in root_feature.join_path_keys
                ):
                    # CHA-4857
                    for local_join_feat, foreign_join_feat in zip(
                        root_feature.path[-1].parent.get_local_join_features(),
                        root_feature.path[-1].parent.get_foreign_join_features(),
                    ):
                        if foreign_join_feat == root_feature.underlying:
                            result_row[local_join_feat.root_fqn] = result_row[root_fqn]
        if FrozenOrderedSet(result_row.keys()) != metadata.resolver_output_root_fqns:
            return ResolverErrors.wrong_df_columns(
                resolver_fqn=resolver_fqn,
                expected=metadata.resolver_output_root_fqns,
                actual=result_row,
            )
    return None


@final
class CPUBoundParallelResolver:
    __slots__ = ("resolver_to_input_fqns_has_default_and_defaults", "input_refs", "output_refs", "default_args")

    def __init__(
        self,
        resolver_to_input_fqns_has_default_and_defaults: dict[
            OnlineResolverParsed | OfflineResolverParsed,
            tuple[ResolverOutputMetadata, Sequence[tuple[TResolverFeatureType, int, bool, Any]]],
        ],
        input_refs: dict[TResolverFeatureType, int],
        output_refs: OrderedSet[TResolverFeatureType],
        default_args: list[ResolverArgErrorHandlerParsed | None],
    ) -> None:
        super().__init__()
        self.resolver_to_input_fqns_has_default_and_defaults = resolver_to_input_fqns_has_default_and_defaults
        self.input_refs = input_refs
        self.output_refs = output_refs
        self.default_args = default_args

    def __call__(
        self,
        *features: Any,
        error_collector: list[ChalkError],
    ) -> dict[str, Any]:
        ans: dict[str, Any] = {}
        for resolver, (metadata, inputs) in self.resolver_to_input_fqns_has_default_and_defaults.items():
            args: list[Any] = []
            missing_args: list[str] = []
            for feature, position, has_default, default in inputs:
                val = features[position]
                if val is ...:
                    if has_default:
                        args.append(default)
                    else:
                        missing_args.append(str(feature))
                        args.append(None)
                else:
                    args.append(val)
            if len(missing_args) > 0:
                error_collector.append(
                    ResolverErrors.failed_upstream_arguments(resolver_fqn=resolver.fqn, missing_args=missing_args)
                )
                for k in metadata.resolver_output_root_fqns:
                    ans.setdefault(k, ...)
                continue
            assert resolver.resource_hint == "cpu", "Resolver is not cpu bound"
            with add_logging_context(resolver_fqn=resolver.fqn, labels={"resolver_fqn": resolver.fqn}):
                try:
                    result = metadata.fn(*args)
                    if isinstance(result, pl.LazyFrame):
                        result = result.collect()
                except (Exception, PolarsPanicErrorCompat) as e:
                    error_collector.append(ResolverErrors.resolver_raised_exception(resolver.fqn, e))
                    for k in metadata.resolver_output_root_fqns:
                        ans.setdefault(k, ...)
                    continue
                else:
                    if result.__class__ in _SQL_QUERY_CLASSES:
                        # SQL queries cannot be CPU bound; they are definitional IO bound!
                        error_collector.append(
                            ResolverErrors.wrong_resource_hint(
                                resolver=resolver.fqn,
                                provided_hint="cpu",
                                correct_hint="io",
                                reason="resolvers that invoke SQL queries must be marked as IO bound.",
                            ),
                        )
                        continue
                    err_or_keys = _handle_resolver_result(result, resolver, metadata)
                    if type(err_or_keys) is ChalkError:
                        error_collector.append(err_or_keys)
                        for k in metadata.resolver_output_root_fqns:
                            ans.setdefault(k, ...)
                    else:
                        ans.update(err_or_keys)
        return ans


@final
class IOBoundParallelResolver:
    __slots__ = (
        "resolver_to_input_fqns_has_default_and_defaults",
        "executor",
        "input_refs",
        "output_refs",
        "default_args",
    )

    def __init__(
        self,
        resolver_to_input_fqns_has_default_and_defaults: dict[
            OnlineResolverParsed | OfflineResolverParsed,
            tuple[ResolverOutputMetadata, Sequence[tuple[TResolverFeatureType, int, bool, Any]]],
        ],
        executor: ChalkThreadPoolExecutor,
        input_refs: dict[TResolverFeatureType, int],
        output_refs: OrderedSet[TResolverFeatureType],
        default_args: list[ResolverArgErrorHandlerParsed | None],
    ) -> None:
        super().__init__()
        self.resolver_to_input_fqns_has_default_and_defaults = resolver_to_input_fqns_has_default_and_defaults
        self.executor = executor
        self.input_refs = input_refs
        self.output_refs = output_refs
        self.default_args = default_args

    def _call_sync_io_bound_resolver(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        resolver: OnlineResolverParsed | OfflineResolverParsed,
        metadata: ResolverOutputMetadata,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> Sequence[tuple[str, Any]] | ChalkError:
        with add_logging_context(resolver_fqn=resolver.fqn, labels={"resolver_fqn": resolver.fqn}):
            try:
                if execution_context is None:
                    start = time.perf_counter()
                    result = metadata.fn(*resolver_args)
                    duration = time.perf_counter() - start
                else:
                    with execution_context:
                        start = time.perf_counter()
                        result = metadata.fn(*resolver_args)
                        duration = time.perf_counter() - start

            except (Exception, PolarsPanicErrorCompat) as e:
                return ResolverErrors.resolver_raised_exception(resolver.fqn, e)
            try:
                for batch in sync_handle_batch(
                    resolver=resolver,
                    resolver_output_metadata=metadata,
                    result=result,
                    rewriter=rewriter,
                    query_execution_parameters=query_execution_parameters,
                    duration_seconds=duration,
                ):
                    if isinstance(batch, ChalkError):
                        return batch
                    else:
                        return _handle_resolver_result(batch.data, resolver, metadata)
            except WrappedResolverException as e:
                return ResolverErrors.resolver_raised_exception(resolver.fqn, e.original_exception)
            return ResolverErrors.wrong_output_type(
                resolver_fqn=resolver.fqn,
                expected_type_name="DataFrame, Mapping, or Features set",
                result_type_name=type(result).__name__,
                feature_fqn=None,
            )

    async def _call_async_io_bound_resolver(
        self,
        resolver_args: Sequence[Any],
        rewriter: QueryRewriter,
        resolver: OnlineResolverParsed | OfflineResolverParsed,
        metadata: ResolverOutputMetadata,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> Sequence[tuple[str, Any]] | ChalkError:
        with add_logging_context(resolver_fqn=resolver.fqn, labels={"resolver_fqn": resolver.fqn}):
            try:
                if execution_context is None:
                    start = time.perf_counter()
                    result = await metadata.fn(*resolver_args)
                    duration = time.perf_counter() - start
                else:
                    with execution_context:
                        start = time.perf_counter()
                        result = await metadata.fn(*resolver_args)
                        duration = time.perf_counter() - start

            except (Exception, PolarsPanicErrorCompat) as e:
                return ResolverErrors.resolver_raised_exception(resolver.fqn, e)
            try:
                async for batch in async_handle_batch(
                    resolver=resolver,
                    resolver_output_metadata=metadata,
                    result=result,
                    rewriter=rewriter,
                    query_execution_parameters=query_execution_parameters,
                    duration_seconds=duration,
                    resolver_executor=self.executor,
                ):
                    if isinstance(batch, ChalkError):
                        return batch
                    else:
                        return _handle_resolver_result(batch.data, resolver, metadata)
            except WrappedResolverException as e:
                return ResolverErrors.resolver_raised_exception(resolver.fqn, e.original_exception)
            return ResolverErrors.wrong_output_type(
                resolver_fqn=resolver.fqn,
                expected_type_name="DataFrame, Mapping, or Features set",
                result_type_name=type(result).__name__,
                feature_fqn=None,
            )

    async def __call__(
        self,
        features: Sequence[Any],
        error_collector: list[ChalkError],
        rewriter: QueryRewriter,
        execution_context: ContextManager | None,
        query_execution_parameters: QueryExecutionParameters,
    ) -> dict[str, Any]:
        ans: dict[str, Any] = {}
        futures: dict[
            OnlineResolverParsed | OfflineResolverParsed, Coroutine[Any, Any, Sequence[tuple[str, Any]] | ChalkError]
        ] = {}
        for resolver, (metadata, inputs) in self.resolver_to_input_fqns_has_default_and_defaults.items():
            args: list[Any] = []
            missing_args: list[str] = []
            for feature, position, has_default, default in inputs:
                val = features[position]
                if val is ...:
                    if has_default:
                        args.append(default)
                    else:
                        if not is_optional_has_one(feature):
                            missing_args.append(str(feature))
                        args.append(None)
                else:
                    args.append(val)
            if len(missing_args) > 0:
                error_collector.append(
                    ResolverErrors.failed_upstream_arguments(resolver_fqn=resolver.fqn, missing_args=missing_args)
                )
                for k in metadata.resolver_output_root_fqns:
                    ans.setdefault(k, ...)
                continue
            elif metadata.is_async:
                futures[resolver] = self._call_async_io_bound_resolver(
                    args,
                    rewriter,
                    resolver,
                    metadata,
                    execution_context,
                    query_execution_parameters,
                )

            else:
                futures[resolver] = self.executor.submit_async(
                    self._call_sync_io_bound_resolver,
                    args,
                    rewriter,
                    resolver,
                    metadata,
                    execution_context,
                    query_execution_parameters,
                )

        for resolver, data in (await wait_for_futures(futures)).items():
            if type(data) is ChalkError:
                metadata = self.resolver_to_input_fqns_has_default_and_defaults[resolver][0]
                error_collector.append(data)
                for k in metadata.resolver_output_root_fqns:
                    ans.setdefault(k, ...)
            else:
                ans.update(data)
        return ans


_SQL_QUERY_CLASSES = (ChalkQuery, StringChalkQuery, FinalizedChalkQuery)


class ParallelResolverInvoker(BoundInvokerProtocol):
    def __init__(
        self,
        resolvers: FrozenOrderedSet[OnlineResolverParsed | OfflineResolverParsed],
        graph: ResolvedGraph,
        resolver_executor: ChalkThreadPoolExecutor,
        query_execution_params: QueryExecutionParameters,
        overlay_feature_registry: OverlayFeatureRegistry | None,
    ):
        super().__init__()
        self._registry = overlay_feature_registry
        with overlay_registry_ctx(self._registry):
            self._resolvers = resolvers
            self._query_execution_params = query_execution_params
            self._graph = graph
            self._resolver_executor = resolver_executor
            fn = _assimilate_resolvers(resolvers, resolver_executor)
            self._is_cpu_bound = isinstance(fn, CPUBoundParallelResolver)
            if len(fn.input_refs) == 0:
                self._unique_input_root_ns = get_unique_item(o.root_namespace for o in fn.output_refs)
            else:
                self._unique_input_root_ns = get_unique_item(
                    x.root_namespace for x in fn.input_refs if x.root_namespace != "__chalk__"
                )
            self._pkey_feature = unwrap_optional(graph.primary_feature_for_namespace(self._unique_input_root_ns))
            # The easiest way to construct the metadata is from a (fake) resolver
            fake_resolver_to_compute_metadata = MainProcOnlineResolver(
                function_definition="",
                source_line=None,
                function_captured_globals={},
                fn=fn,
                static=False,
                module=None,
                filename="",
                # NOTE: Each resolver MUST have a unique FQN, as this is the ONLY key that is used for hashing and equality
                # We do NOT want any two assimilated resolvers to be "equal", since it's only used locally within this class
                fqn=f"__chalk__.__assimilated_resolver__.{next(_COUNTER)}",
                doc="",
                input_refs=fn.input_refs,
                synthetic_inputs=FrozenOrderedSet(),
                state=None,
                underscore_definition=None,
                is_generator=False,
                resource_hint="cpu" if self._is_cpu_bound else "io",
                output_refs=fn.output_refs,
                graph=self._graph,
                environment=None,
                tags=tuple(),
                cron=None,
                cron_filter=None,
                machine_type=None,
                when=None,
                default_args=fn.default_args,
                owner=None,
                timeout=None,
                data_sources=(),
                is_total=False,
                accelerate_python="auto",
                unique_on=FrozenOrderedSet(),
                partitioned_by=FrozenOrderedSet(),
                static_operation=None,
                sql_settings=None,
                incremental_settings=None,
                is_externally_defined=False,
                output_row_order=None,
                venv=None,
                postprocessing=None,
            )
            self._metadata = ResolverOutputMetadata.from_resolver(
                fake_resolver_to_compute_metadata,
                self._pkey_feature,
            )
            self._input_feature_to_resolver = {
                resolver_input_feature_type: resolver
                for resolver in resolvers
                for resolver_input_feature_type in resolver.inputs
            }
            self._feature_fqn_to_resolver_fqn = {
                of.root_fqn: resolver.fqn for resolver in resolvers for of in resolver.output_features
            }
            self._resolver_args_builder = ResolverArgsBuilder(graph=self._graph)

    def sync_call(
        self,
        batch: LocalResolverInputs,
        config: InvokerConfig,
        rewriter: QueryRewriter,
        loop: asyncio.AbstractEventLoop,
    ) -> BatchResolverResult:
        """Call without asyncio. This is a blocking function"""
        with overlay_registry_ctx(self._registry):
            ran_at = datetime.now(timezone.utc)
            indices, pkeys, tses, resolver_input_sequences = self._make_resolver_input_sequences(batch, config)
            resolver_input_sequences = cast(
                list[Sequence[object]], resolver_input_sequences
            )  # because we have no has-many features, we have no iterables

            result_collector = ResultCollector(
                resolver_fqn="<multi_resolver>",
                strict_validations={},
                resolver_metadata=self._metadata,
                observed_at_fallback=None,
                check_duplicate_rows=config.ensure_distinct_resolver_results,
                feature_fqn_to_resolver_fqn=self._feature_fqn_to_resolver_fqn,
                error_on_ellipsis=False,
            )

            stats = ResolverRunStats()

            with PerfTimer() as pt:
                error_collectors: list[list[ChalkError]] = []
                sequnce_indices: list[int] = []  # indexes into input_sequences
                futures: list[Future] = []

                for i in range(len(indices)):
                    has_failed_args = any(
                        resolver_input_sequence[i].__class__ is FailedArgument
                        for resolver_input_sequence in resolver_input_sequences
                    )
                    if has_failed_args:
                        for x in self._resolvers:
                            result_collector.add_error(
                                indices[i],
                                pkeys[i],
                                tses[i],
                                ResolverErrors.failed_upstream_arguments(
                                    x.fqn,
                                    [
                                        failed_arg.expected_feature
                                        for resolver_input_sequence in resolver_input_sequences
                                        if isinstance(failed_arg := resolver_input_sequence[i], FailedArgument)
                                    ],
                                ),
                            )
                        stats.num_skipped_invocations += 1
                        continue

                    error_collector: list[ChalkError] = []
                    if self._is_cpu_bound:
                        assert isinstance(self._metadata.fn, CPUBoundParallelResolver)
                        future = Future()
                        # run function in thread
                        future.set_result(
                            self._metadata.fn(
                                *(resolver_input_sequence[i] for resolver_input_sequence in resolver_input_sequences),
                                error_collector=error_collector,
                            )
                        )
                    else:
                        assert isinstance(self._metadata.fn, IOBoundParallelResolver)
                        future = run_coroutine_fn_threadsafe(
                            loop,
                            self._metadata.fn,
                            tuple(resolver_input_sequence[i] for resolver_input_sequence in resolver_input_sequences),
                            error_collector=error_collector,
                            rewriter=rewriter,
                            execution_context=None,
                            query_execution_parameters=self._query_execution_params,
                        )

                    sequnce_indices.append(i)
                    error_collectors.append(error_collector)
                    futures.append(future)

                results: list[dict[str, Any]] = []
                for fut in futures:
                    results.append(fut.result())

                for seq_index, error_collector, result in zip(sequnce_indices, error_collectors, results):
                    for x in error_collector:
                        result_collector.add_error(
                            index=None,
                            pkey=pkeys[seq_index],
                            execution_timestamp=tses[seq_index],
                            error=x,
                        )
                    result_collector.add_result(indices[seq_index], pkeys[seq_index], tses[seq_index], result)
                    stats.num_successful_invocations += 1

            stats.resolver_invocation_secs += pt.duration_seconds

            outputs = self._collect_results(
                result_collector=result_collector,
                stats=stats,
                offset=0,
                batch=batch,
                ran_at=ran_at,
                resolver_output_metadata=self._metadata,
            )
            return outputs

    async def __call__(
        self,
        batch: LocalResolverInputs,
        config: InvokerConfig,
        rewriter: QueryRewriter,
        invoker_context: InvokerContext,
    ) -> AsyncIterator[BatchResolverResult]:
        with overlay_registry_ctx(self._registry):
            ran_at = datetime.now(timezone.utc)
            indices, pkeys, tses, resolver_input_sequences = self._make_resolver_input_sequences(batch, config)
            resolver_input_sequences = cast(
                list[Sequence[object]], resolver_input_sequences
            )  # because we have no has-many features, we have no iterables

            result_collector = ResultCollector(
                resolver_fqn="<multi_resolver>",
                strict_validations={},
                resolver_metadata=self._metadata,
                observed_at_fallback=None,
                check_duplicate_rows=config.ensure_distinct_resolver_results,
                feature_fqn_to_resolver_fqn=self._feature_fqn_to_resolver_fqn,
                error_on_ellipsis=False,
            )

            stats = ResolverRunStats()

            with PerfTimer() as pt:
                for i in range(len(indices)):
                    has_failed_args = any(
                        resolver_input_sequence[i].__class__ is FailedArgument
                        for resolver_input_sequence in resolver_input_sequences
                    )
                    if has_failed_args:
                        for x in self._resolvers:
                            result_collector.add_error(
                                indices[i],
                                pkeys[i],
                                tses[i],
                                ResolverErrors.failed_upstream_arguments(
                                    x.fqn,
                                    [
                                        failed_arg.expected_feature
                                        for resolver_input_sequence in resolver_input_sequences
                                        if isinstance(failed_arg := resolver_input_sequence[i], FailedArgument)
                                    ],
                                ),
                            )
                        stats.num_skipped_invocations += 1
                        continue

                    error_collector: list[ChalkError] = []
                    if self._is_cpu_bound:
                        assert isinstance(self._metadata.fn, CPUBoundParallelResolver)
                        res = self._metadata.fn(
                            *(resolver_input_sequence[i] for resolver_input_sequence in resolver_input_sequences),
                            error_collector=error_collector,
                        )
                    else:
                        assert isinstance(self._metadata.fn, IOBoundParallelResolver)
                        res = await self._metadata.fn(
                            tuple(resolver_input_sequence[i] for resolver_input_sequence in resolver_input_sequences),
                            error_collector=error_collector,
                            rewriter=rewriter,
                            execution_context=None,
                            query_execution_parameters=self._query_execution_params,
                        )
                    for x in error_collector:
                        result_collector.add_error(
                            index=None,
                            pkey=pkeys[i],
                            execution_timestamp=tses[i],
                            error=x,
                        )
                    result_collector.add_result(indices[i], pkeys[i], tses[i], res)
                    stats.num_successful_invocations += 1

            stats.resolver_invocation_secs += pt.duration_seconds

            outputs = self._collect_results(
                result_collector=result_collector,
                stats=stats,
                offset=0,
                batch=batch,
                ran_at=ran_at,
                resolver_output_metadata=self._metadata,
            )
            yield outputs

    def _collect_results(
        self,
        result_collector: ResultCollector,
        stats: ResolverRunStats,
        offset: int,
        batch: LocalResolverInputs,
        resolver_output_metadata: ResolverOutputMetadata,
        ran_at: datetime,
    ) -> BatchResolverResult:
        """Collect the results in the results collector into a BatchResolverResult"""
        result_table_or_err = result_collector.collect_results()

        errors = [x.error for x in result_collector.errors]
        if isinstance(result_table_or_err, ChalkError):
            errors.append(result_table_or_err)

        if isinstance(result_table_or_err, ChalkError):
            data_tbl = None
        else:
            assert resolver_output_metadata.is_one_to_one_resolver
            # If it's a 1:1 mapping, then the result collector does not track the pkey, index col name, or ts col name
            # Note that the pkey might already be in this table if the resolver returned its input pkey
            assert batch.scalarish_features is not None
            if len(result_table_or_err) != result_collector.num_collected_rows:
                raise ValueError(
                    f"The number of collected rows {result_collector.num_collected_rows} did not match the length of the result table {len(result_table_or_err)}"
                )
            scalarish_features = batch.scalarish_features
            sliced_ts = scalarish_features.column(TS_COL_NAME).slice(offset, result_collector.num_collected_rows)
            if len(sliced_ts) != len(result_table_or_err):
                raise ValueError(
                    f"Input table of length {len(sliced_ts)} does not have enough rows to support slicing with offset {offset} and num collected rows {result_collector.num_collected_rows}"
                )
            sliced_index = scalarish_features.column(INDEX_COL_NAME).slice(offset, result_collector.num_collected_rows)
            new_cols = {
                TS_COL_NAME: sliced_ts,
                INDEX_COL_NAME: sliced_index,
            }

            if not result_table_or_err.contains_column_name(self._pkey_feature.fqn):
                if self._pkey_feature.name == CHALK_GLOBAL_SINGLETON_ID:
                    # inject the "pkey" of singleton features
                    singleton_id_col = pa.array([CHALK_SINGLETON_VALUE] * len(sliced_index), pa.uint8())
                    assert isinstance(singleton_id_col, pa.Array)
                    new_cols[self._pkey_feature.fqn] = singleton_id_col
                else:
                    new_cols[self._pkey_feature.fqn] = scalarish_features.column(self._pkey_feature.fqn).slice(
                        offset, result_collector.num_collected_rows
                    )
            result_table_or_err = result_table_or_err.append_columns(new_cols)

            data = result_table_or_err

            data_tbl = data.to_record_batch()

        return BatchResolverResult(
            data=data_tbl,
            errors=errors,
            num_failed_invocations=stats.num_failed_invocations,
            num_successful_invocations=stats.num_successful_invocations,
            ran_at=ran_at,
            resolver_invocation_secs=stats.resolver_invocation_secs,
            num_resolver_timeouts=stats.num_resolver_timeouts,
            num_skipped_invocations=stats.num_skipped_invocations,
            result_collector_num_rows=result_collector.num_collected_rows,
        )

    def _make_resolver_input_sequences(
        self,
        resolver_inputs: LocalResolverInputs,
        config: InvokerConfig,
    ) -> tuple[Sequence[int], Sequence[int | str | None], Sequence[datetime | None], list[Iterable[object]]]:
        # Generate pyarrow and polars representations of resolver_inputs. We prefer to work in pyarrow where possible
        # since it's a bit more robust and correct, but still offer the polars dataframe to the
        # self._produce_resolver_args_(...) methods in case they'd like to use polars to perform the vectorized
        # operations instead
        resolver_inputs_table: ChalkRecordBatch = resolver_inputs.to_metadata_data_reconciled_chalk_table()
        # These are needed to generate the Sample instances later
        pkeys = cast(
            list[_PKey],
            (
                to_pylist(resolver_inputs_table[self._pkey_feature.fqn])
                if resolver_inputs_table.contains_column_name(self._pkey_feature.fqn)
                else [None] * len(resolver_inputs_table)
            ),
        )

        if config.needs_pkey_feature_values_in_inputs and not resolver_inputs_table.contains_column_name(
            self._pkey_feature.fqn
        ):
            raise ValueError("Couldn't find pkey feature!")

        resolver_argument_iterables: list[Iterable[object]] = []

        # For each feature type that is a part of the resolver's inputs, we generate the concrete python objects which
        # are the values for the resolver. We loop through each feature type input for the resolver. For each of those
        # feature types, we use the appropriate self._produce_resolver_args_(...) method to generate a list of
        # arguments for that feature type (in the original ordering of pkeys / arguments as they appeared in
        # resolver_inputs)
        assert isinstance(self._metadata.fn, (CPUBoundParallelResolver, IOBoundParallelResolver))
        for resolver_arg, resolver_input_feature_type in zip(
            self._metadata.fn.default_args, self._metadata.fn.input_refs
        ):
            if is_underlying_feature_time(resolver_input_feature_type):
                with safe_trace("_vectorized_sample_generator__add_feature_time_arg"):
                    resolver_argument_iterables.append(
                        self._resolver_args_builder.produce_resolver_args_feature_time(
                            unique_input_root_ns=self._unique_input_root_ns,
                            feature_type=resolver_input_feature_type,
                            resolver_inputs_table=resolver_inputs_table,
                            scope_feature_time_to_namespace=config.scope_feature_time_to_namespace,
                        )
                    )
            # It's possible for hasmany's underlying to be other feature types, so we check for hasmany case first.
            elif is_general_has_many(resolver_input_feature_type):
                raise ValueError("The ParallelResolverInvoker does NOT support has-many inputs")
            elif is_underlying_scalar(resolver_input_feature_type):
                with safe_trace("_vectorized_sample_generator__add_scalar_arg"):
                    resolver_argument_iterables.append(
                        self._resolver_args_builder.produce_resolver_args_scalar(
                            resolver_arg=resolver_arg,
                            feature_type=resolver_input_feature_type,
                            resolver_inputs_table=resolver_inputs_table,
                        )
                    )
            elif is_underlying_has_one(resolver_input_feature_type):
                with safe_trace("_vectorized_sample_generator__add_has_one_arg"):
                    resolver_argument_iterables.append(
                        self._resolver_args_builder.produce_resolver_args_has_one(
                            unique_input_root_ns=self._unique_input_root_ns,
                            feature_type=resolver_input_feature_type,
                            resolver_inputs_table=resolver_inputs_table,
                            scope_feature_time_to_namespace=config.scope_feature_time_to_namespace,
                        )
                    )
            else:
                raise TypeError((f"Unsupported feature type {resolver_input_feature_type} for ParallelResolver"))
        return (
            cast(list[int], to_pylist(resolver_inputs_table[INDEX_COL_NAME])),
            pkeys,
            cast(list[datetime | None], to_pylist(resolver_inputs_table[TS_COL_NAME])),
            resolver_argument_iterables,
        )
