# chalkruntime

Runtime support library used by Chalk AI's execution engine.

This package is an internal component of the Chalk platform and is not intended
to be consumed as a standalone library. See https://chalk.ai for more
information.
