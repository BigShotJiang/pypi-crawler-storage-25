#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #


#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import copy

import numpy as np
from AnyQt.QtGui import QTextCursor
from AnyQt.QtWidgets import QMessageBox, QApplication
from AnyQt.QtCore import QRect

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from oasys2.canvas.util.canvas_util import add_widget_parameters_to_module
from oasys2.widget import gui as oasysgui
from oasys2.widget.gui import ConfirmDialog
from oasys2.widget.util import congruence
from oasys2.widget.widget import OWWidget, OWAction

from orangewidget import gui
from orangewidget.settings import Setting
from orangewidget.widget import Output

from wofryokona.util.surface_errors import generate_figure_error_from_psd, generate_figure_error_from_ar_model

from orangecontrib.okona.util.okona_objects import SurfaceErrorsData

class OWFigureErrorGenerator(OWWidget):
    maintainer = "Luca Rebuffi"
    maintainer_email = "lrebuffi(@at@)anl.gov"
    keywords = ["data", "file", "load", "read"]
    category = "OKONA Optical Elements"
    name = "Figure Error Generator"
    description = "OKONA: Figure Error Generator"
    icon = "icons/figure_error.png"
    priority = 1

    class Outputs:
        okona_data = Output(name="Surface Errors Data", type=SurfaceErrorsData, id="Surface Errors Data", default=True, auto_summary=False)

    mirror_length = Setting(0.0)
    slope_error_rms = Setting(0.0)
    sampling_step = Setting(1e-3)

    algorithm = Setting(0)

    beta = Setting(2.5)
    ar_coefficients  = Setting(0)
    ar_coefficient_1 = Setting(0.0)
    ar_coefficient_2 = Setting(0.0)
    ar_coefficient_3 = Setting(0.0)

    figure_error_data_file = Setting("figure_error_data_file.txt")

    want_main_area = 1

    figure_error_x  = None
    figure_error_hp = None

    TABS_AREA_HEIGHT   = 515
    CONTROL_AREA_WIDTH = 450

    MAX_WIDTH = 1320
    MAX_HEIGHT = 650

    def __init__(self):
        super(OWFigureErrorGenerator, self).__init__()

        self.runaction = OWAction("Generate Data", self)
        self.runaction.triggered.connect(self._send_data)
        self.addAction(self.runaction)

        self.runaction = OWAction("Save Data", self)
        self.runaction.triggered.connect(self._save_data)
        self.addAction(self.runaction)

        self._button_box = oasysgui.widgetBox(self.controlArea, "", addSpace=False, orientation="horizontal", width=self.CONTROL_AREA_WIDTH - 10)

        button = gui.button(self._button_box, self, "Generate Data", callback=self._send_data)
        button.setStyleSheet("color: darkblue; font-weight: bold; height: 45px;")

        button = gui.button(self._button_box, self, "Save Data", callback=self._save_data)
        button.setStyleSheet("color: darkblue; font-weight: bold; height: 45px;")

        button = gui.button(self._button_box, self, "Reset Fields", callback=self._call_reset_settings)
        button.setStyleSheet("color: darkred; font-weight: bold; font-style: italic; height: 45px; width: 150px;")

        gui.separator(self.controlArea)

        geom = QApplication.primaryScreen().geometry()
        self.setGeometry(QRect(round(geom.width() * 0.05),
                               round(geom.height() * 0.05),
                               round(min(geom.width() * 0.98, self.MAX_WIDTH)),
                               round(min(geom.height() * 0.95, self.MAX_HEIGHT))))

        self.setMaximumHeight(self.geometry().height())
        self.setMaximumWidth(self.geometry().width())

        self.controlArea.setFixedWidth(self.CONTROL_AREA_WIDTH)

        self._tabs_setting = oasysgui.tabWidget(self.controlArea)
        self._tabs_setting.setFixedHeight(self.TABS_AREA_HEIGHT)
        self._tabs_setting.setFixedWidth(self.CONTROL_AREA_WIDTH - 5)

        self._tab_bas = oasysgui.createTabPage(self._tabs_setting, "Figure Error Settings")

        self._figure_error_box = oasysgui.widgetBox(self._tab_bas, "Input Parameters", addSpace=True, orientation="vertical")

        oasysgui.lineEdit(self._figure_error_box, self, "mirror_length", "Mirror Length [m]", labelWidth=320, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self._figure_error_box, self, "slope_error_rms", "Slope Error RMS [rad]", labelWidth=320, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self._figure_error_box, self, "sampling_step", "Sampling Step [m]", labelWidth=320, valueType=float, orientation="horizontal")

        gui.comboBox(self._figure_error_box, self, "algorithm", label="Algorithm", items=["From PSD", "From Autoregressive Model"],
                     labelWidth=150, sendSelectedValue=False, orientation="horizontal", callback=self._set_algorithm)

        self._figure_error_box_1 = oasysgui.widgetBox(self._figure_error_box, "", addSpace=False, orientation="vertical", height=150)
        self._figure_error_box_2 = oasysgui.widgetBox(self._figure_error_box, "", addSpace=False, orientation="vertical", height=150)

        oasysgui.lineEdit(self._figure_error_box_1, self, "beta", "Beta", labelWidth=320, valueType=float, orientation="horizontal")

        gui.comboBox(self._figure_error_box_2, self, "ar_coefficients", label="AR Coefficients", items=["Default", "User Defined"],
                     labelWidth=150, sendSelectedValue=False, orientation="horizontal", callback=self._set_ar_coefficients)

        self._figure_error_box_2_1 = oasysgui.widgetBox(self._figure_error_box_2, "", addSpace=False, orientation="vertical", height=90)
        self._figure_error_box_2_2 = oasysgui.widgetBox(self._figure_error_box_2, "", addSpace=False, orientation="vertical", height=90)

        oasysgui.lineEdit(self._figure_error_box_2_2, self, "ar_coefficient_1", "A-R Coefficient 1", labelWidth=320, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self._figure_error_box_2_2, self, "ar_coefficient_2", "A-R Coefficient 2", labelWidth=320, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self._figure_error_box_2_2, self, "ar_coefficient_3", "A-R Coefficient 3", labelWidth=320, valueType=float, orientation="horizontal")

        self._set_algorithm()

        self._output_box = oasysgui.widgetBox(self._tab_bas, "Output Parameters", addSpace=True, orientation="vertical")

        file_box =  oasysgui.widgetBox(self._output_box, "", addSpace=False, orientation="horizontal")
        self._le_figure_error_data_file = oasysgui.lineEdit(file_box, self, "figure_error_data_file", "Figure Error data file", labelWidth=125, valueType=str, orientation="horizontal")
        gui.button(file_box, self, "...", callback=self._select_figure_error_data_file, width=30)

        self._main_tabs = oasysgui.tabWidget(self.mainArea)
        self._plot_tab = oasysgui.createTabPage(self._main_tabs, "Result")
        self._figure_error_plot_canvas = self._get_standard_figure_canvas()

        self._plot_tab.layout().addWidget(self._figure_error_plot_canvas)

    @staticmethod
    def _get_standard_figure_canvas(): return FigureCanvas(Figure(figsize=(8, 6)))

    def _set_algorithm(self):
        self._figure_error_box_1.setVisible(self.algorithm == 0)
        self._figure_error_box_2.setVisible(self.algorithm == 1)

        if self.algorithm == 1: self._set_ar_coefficients()

    def _set_ar_coefficients(self):
        self._figure_error_box_2_1.setVisible(self.ar_coefficients == 0)
        self._figure_error_box_2_2.setVisible(self.ar_coefficients == 1)

    def _select_figure_error_data_file(self):
        self._le_figure_error_data_file.setText(oasysgui.selectFileFromDialog(self, self.figure_error_data_file, "Height profile data file"))

    def _check_data(self):
        congruence.checkStrictlyPositiveNumber(self.mirror_length, "Mirror Length")
        congruence.checkStrictlyPositiveNumber(self.slope_error_rms, "Slope Error RMS")
        congruence.checkStrictlyPositiveNumber(self.sampling_step, "Sampling Step")
        if self.algorithm == 0: congruence.checkStrictlyPositiveNumber(self.beta, "Beta")

    def _send_data(self):
        try:
            self._check_data()

            if self.algorithm == 0:
                x, height_profile = generate_figure_error_from_psd(mirror_length=self.mirror_length,
                                                                   slope_error_rms=self.slope_error_rms,
                                                                   sampling_step=self.sampling_step,
                                                                   beta=self.beta)
            elif self.algorithm == 1:
                ar_coefficients = (None if self.ar_coefficients == 0 else
                                   np.array([self.ar_coefficient_1, self.ar_coefficient_2, self.ar_coefficient_3]))

                x, height_profile = generate_figure_error_from_ar_model(mirror_length=self.mirror_length,
                                                                        slope_error_rms=self.slope_error_rms,
                                                                        sampling_step=self.sampling_step,
                                                                        ar_coefficients=ar_coefficients)
            else: raise Exception("Unknown algorithm selected")

            self.figure_error_x  = x
            self.figure_error_hp = height_profile

            self._plot_figure_error_data()

            QMessageBox.information(self, "Figure Error Generated", f"Click on Save Figure Error to save the file", QMessageBox.Ok)
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e.args[0]), QMessageBox.Ok)

            self.setStatusMessage("")
            self.progressBarFinished()

            if self.IS_DEVELOP: raise e

    def _save_data(self):
        try:
           if not self.figure_error_x is None and not self.figure_error_hp is None:
               np.savetxt(self.figure_error_data_file,
                           np.column_stack([self.figure_error_x, self.figure_error_hp]),
                           fmt="%.9e",
                           delimiter="\t",
                           header="# Position (m)\tHeight Error (m)")

               QMessageBox.information(self, "Info", f"File {self.figure_error_data_file} written on disk", QMessageBox.Ok)

               self.Outputs.okona_data.send(SurfaceErrorsData(figure_error_data_file=self.figure_error_data_file))
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e.args[0]), QMessageBox.Ok)

            self.setStatusMessage("")
            self.progressBarFinished()

            if self.IS_DEVELOP: raise e

    def _plot_figure_error_data(self):
        figure = self._figure_error_plot_canvas.figure
        figure.clear()

        ax = figure.gca()
        ax.plot(self.figure_error_x * 1000, self.figure_error_hp * 1e9)
        ax.set_title(f"Figure Error (RMS: {np.std(self.figure_error_hp * 1e9):.3f} nm)", fontsize=8)
        ax.set_ylabel("Height (nm)")
        ax.set_xlabel("Position (mm)")
        ax.grid(True)

        figure.tight_layout()

        self._figure_error_plot_canvas.draw()

    def _call_reset_settings(self):
        if ConfirmDialog.confirmed(parent=self, message="Confirm Reset of the Fields?"):
            try:    self._reset_settings()
            except: pass

add_widget_parameters_to_module(__name__)

