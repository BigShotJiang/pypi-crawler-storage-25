#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from orangecontrib.okona.util.okona_objects import SurfaceErrorsData
from orangewidget import gui
from orangewidget.settings import Setting

from oasys2.widget import gui as oasysgui
from oasys2.widget.util import congruence

from orangecontrib.okona.widgets.gui.ow_optical_element import OWOpticalElementWithSurfaceShape
from orangewidget.widget import Input
from wofryokona.beamline.okona_beamline import OKONABeamline
from wofryokona.beamline.okona_beamline_element import OKONAHighPassWavelengthCutoff


# --------------------------------------------------------------

class OWMirror(OWOpticalElementWithSurfaceShape):
    figure_error_data_file          = Setting("figure_error_data_file.txt")
    psd_data_file                   = Setting("psd_data_file.txt")
    axis_points_exp                 = Setting(15)
    add_high_pass_wavelength_cutoff = Setting(0)
    high_pass_wavelength_cutoff_m   = Setting(0.0)

    MAX_HEIGHT = 780
    TABS_AREA_HEIGHT = 635

    class Inputs:
        okona_data        = Input(name="OKONA Data", type=OKONABeamline, id="OKONA Data", auto_summary=False)
        figure_error_data = Input(name="Figure Error Data", type=SurfaceErrorsData, id="Figure Error Data", auto_summary=False)
        psd_data          = Input(name="PSD Data", type=SurfaceErrorsData, id="PSD Data", auto_summary=False)

    def __init__(self, show_automatic_box:bool = True):
        super(OWMirror, self).__init__(show_automatic_box=show_automatic_box)

    def _draw_specific_box(self):
        super()._draw_specific_box()

        self._tabs_mirror = oasysgui.tabWidget(self._tab_bas)
        self._tab_error   = oasysgui.createTabPage(self._tabs_mirror, "Error Profile")
        self._error_box   = oasysgui.widgetBox(self._tab_error, "", addSpace=False, orientation="vertical")

        file_box =  oasysgui.widgetBox(self._error_box, "", addSpace=False, orientation="horizontal")
        self._le_figure_error_data_file = oasysgui.lineEdit(file_box, self, "figure_error_data_file", "Figure Error data file", labelWidth=125, valueType=str, orientation="horizontal")
        gui.button(file_box, self, "...", callback=self._select_figure_error_data_file, width=30)

        file_box =  oasysgui.widgetBox(self._error_box, "", addSpace=False, orientation="horizontal")
        self._le_psd_data_file = oasysgui.lineEdit(file_box, self, "psd_data_file", "PSD data file", labelWidth=125, valueType=str, orientation="horizontal")
        gui.button(file_box, self, "...", callback=self._select_psd_data_file, width=30)

        oasysgui.lineEdit(self._error_box, self, "axis_points_exp", "Axis Point exponent:                                                                     2^", labelWidth=390, controlWidth=40, valueType=int, orientation="horizontal")

        gui.comboBox(self._error_box, self, "add_high_pass_wavelength_cutoff", label="Add High Pass Wavelength cut-off",
                     items=["No", "Ashenbach", "User Defined"], labelWidth=300, callback=self._set_add_high_pass_wavelength_cutoff,
                     sendSelectedValue=False, orientation="horizontal")

        self._le_high_pass_wavelength_cutoff_m = oasysgui.lineEdit(self._error_box, self, "high_pass_wavelength_cutoff_m", "High Pass Wavelength cut-off", labelWidth=320, valueType=float, orientation="horizontal")

        self._set_add_high_pass_wavelength_cutoff()

    def _select_figure_error_data_file(self):
        self._le_figure_error_data_file.setText(oasysgui.selectFileFromDialog(self, self.figure_error_data_file, "Height profile data file"))

    def _select_psd_data_file(self):
        self._le_psd_data_file.setText(oasysgui.selectFileFromDialog(self, self.psd_data_file, "PSD data file"))

    def _set_add_high_pass_wavelength_cutoff(self):
        self._le_high_pass_wavelength_cutoff_m.setEnabled(self.add_high_pass_wavelength_cutoff == 2)

    def _get_high_pass_wavelength_cutoff_m(self):
        if   self.add_high_pass_wavelength_cutoff == 0: return None
        elif self.add_high_pass_wavelength_cutoff == 1: return OKONAHighPassWavelengthCutoff.ASHENBACH
        elif self.add_high_pass_wavelength_cutoff == 2: return self.high_pass_wavelength_cutoff_m
        else: raise ValueError("Invalid value for add_high_pass_wavelength_cutoff")

    def _check_data(self):
        super()._check_data()

        congruence.checkFile(self.figure_error_data_file)
        congruence.checkFile(self.psd_data_file)
        if self.add_high_pass_wavelength_cutoff == 2: congruence.checkPositiveNumber(self.high_pass_wavelength_cutoff_m)

    @Inputs.okona_data
    def receive_okona_data(self, data: OKONABeamline):
        super(OWMirror, self).receive_okona_data(data)

    @Inputs.figure_error_data
    def receive_figure_error_data(self, data: SurfaceErrorsData):
        if not data is None and not data.figure_error_data_file is None:
            self.figure_error_data_file = data.figure_error_data_file
            self._le_figure_error_data_file.setText(data.figure_error_data_file)

    @Inputs.psd_data
    def receive_psd_data(self, data: SurfaceErrorsData):
        if not data is None and not data.power_spectral_density_data_file is None:
            self.psd_data_file = data.power_spectral_density_data_file
            self._le_psd_data_file.setText(data.power_spectral_density_data_file)