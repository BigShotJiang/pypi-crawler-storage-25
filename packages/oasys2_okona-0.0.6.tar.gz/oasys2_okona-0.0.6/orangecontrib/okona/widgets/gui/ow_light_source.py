#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from AnyQt.QtWidgets import QMessageBox, QApplication
from AnyQt.QtCore import QRect

from orangewidget import gui
from orangewidget.settings import Setting
from orangewidget.widget import Output

from oasys2.widget.widget import OWWidget, OWAction
from oasys2.widget import gui as oasysgui
from oasys2.widget.util import congruence
from oasys2.widget.gui import ConfirmDialog

from syned.widget.widget_decorator import WidgetDecorator
from syned.storage_ring.light_source import LightSource

from wofryokona.beamline.okona_beamline import OKONABeamline
from wofryokona.storage_ring.okona_light_source import OKONASimulationPlane, OKONASourceModel, OKONANumberOfModes


class OWLightSource(OWWidget, WidgetDecorator, openclass=True):
    maintainer = "Luca Rebuffi"
    maintainer_email = "lrebuffi(@at@)anl.gov"
    category = "OKONA Light Sources"
    keywords = ["data", "file", "load", "read"]


    class Inputs:
        syned_data = WidgetDecorator.syned_input_data(multi_input=True)

    class Outputs:
        okona_data = Output(name="OKONA Data", type=OKONABeamline, id="OKONAData", default=True, auto_summary=False)

    source_name      = Setting("OKONA Source")
    simulation_plane = Setting(0)
    wavelength       = Setting(1.0e-9)

    type_of_properties = Setting(0)

    target_size_fwhm           = Setting(0.0)
    target_divergence_fwhm     = Setting(0.0)

    electron_beam_size_h       = Setting(0.0)
    electron_beam_divergence_h = Setting(0.0)
    electron_beam_size_v       = Setting(0.0)
    electron_beam_divergence_v = Setting(0.0)

    source_model           = Setting(0)
    num_modes_type         = Setting(0)
    num_modes              = Setting(1024)
    N                      = Setting(8192)
    input_coherence_length = Setting(0)
    coherence_length       = Setting(0.0)

    want_main_area=0

    MAX_WIDTH = 460
    MAX_HEIGHT = 640

    TABS_AREA_HEIGHT = 535
    CONTROL_AREA_WIDTH = 450

    def __init__(self):
        super().__init__()

        self.runaction = OWAction("Send Data", self)
        self.runaction.triggered.connect(self.send_data)
        self.addAction(self.runaction)

        button_box = oasysgui.widgetBox(self.controlArea, "", addSpace=False, orientation="horizontal")

        button = gui.button(button_box, self, "Send Data", callback=self.send_data)
        button.setStyleSheet("color: darkblue; font-weight: bold; height: 45px;")

        button = gui.button(button_box, self, "Reset Fields", callback=self._call_reset_settings)
        button.setStyleSheet("color: darkred; font-weight: bold; font-style: italic; height: 45px; width: 150px;")

        gui.separator(self.controlArea)

        geom = QApplication.primaryScreen().geometry()
        self.setGeometry(QRect(round(geom.width()*0.05),
                               round(geom.height()*0.05),
                               round(min(geom.width()*0.98, self.MAX_WIDTH)),
                               round(min(geom.height()*0.95, self.MAX_HEIGHT))))

        self.setMaximumHeight(self.geometry().height())
        self.setMaximumWidth(self.geometry().width())

        self.controlArea.setFixedWidth(self.CONTROL_AREA_WIDTH)

        self.tabs_setting = oasysgui.tabWidget(self.controlArea)
        self.tabs_setting.setFixedHeight(self.TABS_AREA_HEIGHT)
        self.tabs_setting.setFixedWidth(self.CONTROL_AREA_WIDTH-5)

        self.tab_sou = oasysgui.createTabPage(self.tabs_setting, "Light Source Setting")

        oasysgui.lineEdit(self.tab_sou, self, "source_name", "Light Source Name", labelWidth=150, valueType=str, orientation="horizontal")
        gui.comboBox(self.tab_sou, self, "simulation_plane", label="Simulation Plane", labelWidth=350, items=["Horizontal", "Vertical"], sendSelectedValue=False, orientation="horizontal")

        self.electron_beam_box = oasysgui.widgetBox(self.tab_sou, "Photon Source Parameters", addSpace=False, orientation="vertical")

        oasysgui.lineEdit(self.electron_beam_box, self, "wavelength", "Wavelength [m]", labelWidth=260, valueType=float, orientation="horizontal")

        gui.comboBox(self.electron_beam_box, self, "type_of_properties", label="Source Properties", labelWidth=150,
                     items=["Target Photon Size/Divergence", "From Size/Divergence"],
                     callback=self._set_type_of_properties,
                     sendSelectedValue=False, orientation="horizontal")

        self.left_box_2_1 = oasysgui.widgetBox(self.electron_beam_box, "", addSpace=False, orientation="vertical", height=115)

        oasysgui.lineEdit(self.left_box_2_1, self, "target_size_fwhm",        "Target Size FWHM   [m]",        labelWidth=260, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self.left_box_2_1, self, "target_divergence_fwhm",  "Target Size Divergence  [rad]", labelWidth=260, valueType=float, orientation="horizontal")

        self.left_box_2_2 = oasysgui.widgetBox(self.electron_beam_box, "", addSpace=False, orientation="vertical", height=115)

        oasysgui.lineEdit(self.left_box_2_2, self, "electron_beam_size_h",       "Horizontal Beam Size \u03c3x [m]",          labelWidth=260, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self.left_box_2_2, self, "electron_beam_size_v",       "Vertical Beam Size \u03c3y [m]",            labelWidth=260, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self.left_box_2_2, self, "electron_beam_divergence_h", "Horizontal Beam Divergence \u03c3'x [rad]", labelWidth=260, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self.left_box_2_2, self, "electron_beam_divergence_v", "Vertical Beam Divergence \u03c3'y [rad]",   labelWidth=260, valueType=float, orientation="horizontal")

        self._set_type_of_properties()

        self.source_box = oasysgui.widgetBox(self.tab_sou, "Source Model Parameters", addSpace=True, orientation="vertical")

        gui.comboBox(self.source_box, self, "source_model", label="Model", labelWidth=350, items=["Partially Coherent", "Gaussian Shell Model"], sendSelectedValue=False, orientation="horizontal")
        gui.comboBox(self.source_box, self, "num_modes_type", label="Modes", labelWidth=350, items=["Automatic", "User Defined"], sendSelectedValue=False, orientation="horizontal", callback=self._set_num_modes_type)
        self._le_num_modes = oasysgui.lineEdit(self.source_box, self, "num_modes", "Number of Modes", labelWidth=260, valueType=int, orientation="horizontal")
        gui.comboBox(self.source_box, self, "input_coherence_length", label="Input Coherence Length", labelWidth=350,
                     items=["No", "Yes"], sendSelectedValue=False, orientation="horizontal", callback=self._set_coherence_length)
        self.le_coherence_length = oasysgui.lineEdit(self.source_box, self, "coherence_length", "Coherence Lenght [m]", labelWidth=260, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self.source_box, self, "N", "Number of Points", labelWidth=260, valueType=int, orientation="horizontal")

        gui.rubber(self.controlArea)

        self._set_type_of_properties()
        self._set_num_modes_type()
        self._set_coherence_length()

    def _set_num_modes_type(self):
        self._le_num_modes.setEnabled(self.num_modes_type==1)

    def _set_type_of_properties(self):
        self.left_box_2_1.setVisible(self.type_of_properties == 0)
        self.left_box_2_2.setVisible(self.type_of_properties == 1)

    def _set_coherence_length(self):
        self.le_coherence_length.setEnabled(self.input_coherence_length == 1)

    def _call_reset_settings(self):
        if ConfirmDialog.confirmed(parent=self, message="Confirm Reset of the Fields?"):
            try:    self._reset_settings()
            except: pass

    def _check_data(self):
        congruence.checkStrictlyPositiveNumber(self.wavelength, "Wavelength")

        if self.type_of_properties == 0:
            congruence.checkPositiveNumber(self.target_size_fwhm, "Target Size FWHM")
            congruence.checkPositiveNumber(self.target_divergence_fwhm, "Target Divergence FWHM")
        elif self.type_of_properties == 1:
            congruence.checkPositiveNumber(self.electron_beam_size_h, "Horizontal Beam Size")
            congruence.checkPositiveNumber(self.electron_beam_divergence_h, "Vertical Beam Size")
            congruence.checkPositiveNumber(self.electron_beam_size_v, "Horizontal Beam Divergence")
            congruence.checkPositiveNumber(self.electron_beam_divergence_v, "Vertical Beam Divergence")

        if self.num_modes_type == 1: congruence.checkStrictlyPositiveNumber(self.num_modes, "Number of Modes")
        congruence.checkStrictlyPositiveNumber(self.N, "Number of Points")
        if self.input_coherence_length == 1: congruence.checkStrictlyPositiveNumber(self.coherence_length, "Coherence Length")

    def _get_light_source(self):
        source_name      = self.source_name
        simulation_plane = OKONASimulationPlane.HORIZONTAL if self.simulation_plane == 0 else OKONASimulationPlane.VERTICAL
        wavelength       = self.wavelength

        if self.type_of_properties == 0:
            target_size_fwhm           = self.target_size_fwhm
            target_divergence_fwhm     = self.target_divergence_fwhm
            electron_beam_size_h       = None
            electron_beam_divergence_h = None
            electron_beam_size_v       = None
            electron_beam_divergence_v = None
        else:
            target_size_fwhm           = None
            target_divergence_fwhm     = None
            electron_beam_size_h       = self.electron_beam_size_h
            electron_beam_divergence_h = self.electron_beam_divergence_h
            electron_beam_size_v       = self.electron_beam_size_v
            electron_beam_divergence_v = self.electron_beam_divergence_v

        source_model = OKONASourceModel.PARTIALLY_COHERENT if self.source_model == 0 else OKONASourceModel.GAUSSIAN_SHELL_MODEL
        num_modes    = OKONANumberOfModes.AUTOMATIC if self.num_modes_type==0 else self.num_modes
        N            = self.N

        coherence_length = self.coherence_length if self.input_coherence_length == 1 else None

        return self._instantiate_light_source(source_name,
                                              simulation_plane,
                                              wavelength,
                                              target_size_fwhm,
                                              target_divergence_fwhm,
                                              electron_beam_size_h,
                                              electron_beam_divergence_h,
                                              electron_beam_size_v,
                                              electron_beam_divergence_v,
                                              source_model,
                                              num_modes,
                                              N,
                                              coherence_length)

    def _instantiate_light_source(self,
                                  source_name,
                                  simulation_plane,
                                  wavelength,
                                  target_size_fwhm,
                                  target_divergence_fwhm,
                                  electron_beam_size_h,
                                  electron_beam_divergence_h,
                                  electron_beam_size_v,
                                  electron_beam_divergence_v,
                                  source_model,
                                  num_modes,
                                  N,
                                  coherence_length):
        raise NotImplementedError

    @Inputs.syned_data
    def set_syned_data(self, index, syned_data):
        self.receive_syned_data(syned_data)

    @Inputs.syned_data.insert
    def insert_syned_data(self, index, syned_data):
        self.receive_syned_data(syned_data)

    @Inputs.syned_data.remove
    def remove_syned_data(self, index):
        pass

    def receive_syned_data(self, data):
        if not data is None:
            try:
                if not data._light_source is None and isinstance(data._light_source, LightSource):
                    light_source = data._light_source

                    self.source_name   = light_source.get_name()
                    electron_beam      = light_source.get_electron_beam()
                    magnetic_structure = light_source.get_magnetic_structure()

                    self._check_received_magnetic_structure(magnetic_structure)

                    self.type_of_properties = 1

                    x, xp, y, yp = electron_beam.get_sigmas_all(dispersion=False)

                    self.electron_beam_size_h       = round(x, 10)
                    self.electron_beam_divergence_h = round(xp, 10)
                    self.electron_beam_size_v       = round(y, 10)
                    self.electron_beam_divergence_v = round(yp, 10)

                    self._receive_syned_magnetic_structure(magnetic_structure)

                    self._set_type_of_properties()

            except Exception as exception:
                QMessageBox.critical(self, "Error", str(exception), QMessageBox.Ok)

    def _check_received_magnetic_structure(self, magnetic_structure):
        pass

    def _receive_syned_magnetic_structure(self, magnetic_structure):
        pass

    # -----------------------------------------------------
    # EXECUTION

    def send_data(self):
        try:
            self._check_data()
            self.Outputs.okona_data.send(OKONABeamline(light_source=self._get_light_source()))
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e.args[0]), QMessageBox.Ok)

            self.setStatusMessage("")
            self.progressBarFinished()

            if self.IS_DEVELOP: raise e




