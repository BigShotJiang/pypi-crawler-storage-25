import copy

from AnyQt.QtWidgets import QMessageBox, QApplication
from AnyQt.QtCore import QRect

from orangewidget import gui
from orangewidget.settings import Setting
from orangewidget.widget import Input, Output

from oasys2.widget.widget import OWWidget, OWAction
from oasys2.widget import gui as oasysgui
from oasys2.widget.util import congruence
from oasys2.widget.gui import ConfirmDialog

from syned.beamline.shape import *
from wofryokona.beamline.okona_beamline import OKONABeamline
from wofryokona.beamline.okona_beamline_element import OKONAPropagators
from wofryokona.beamline.optical_elements.mirrors.okona_mirror import MirrorOrientation

class OWOpticalElement(OWWidget, openclass=True):
    maintainer = "Luca Rebuffi"
    maintainer_email = "lrebuffi(@at@)anl.gov"
    keywords = ["data", "file", "load", "read"]
    category = "OKONA Optical Elements"

    class Inputs:
        okona_data = Input(name="OKONA Data", type=OKONABeamline, id="OKONA Data", auto_summary=False)

    class Outputs:
        okona_data = Output(name="OKONA Data", type=OKONABeamline, id="OKONA Data", default=True, auto_summary=False)

    oe_name           = Setting("OKONA O.E.")
    distance          = Setting(0.0)
    propagator        = Setting(0)
    max_points_before = Setting(0)
    is_automatic_run  = Setting(1)

    want_main_area = 0
    beamline       = None

    MAX_WIDTH = 460
    MAX_HEIGHT = 650

    TABS_AREA_HEIGHT = 505
    CONTROL_AREA_WIDTH = 450

    def __init__(self, show_automatic_box= True):
        super(OWOpticalElement, self).__init__()

        self.runaction = OWAction(self._get_button_text(), self)
        self.runaction.triggered.connect(self._send_data)
        self.addAction(self.runaction)

        self._button_box = oasysgui.widgetBox(self.controlArea, "", addSpace=False, orientation="horizontal", width=self.CONTROL_AREA_WIDTH-10)

        button = gui.button( self._button_box, self, self._get_button_text(), callback=self._send_data)
        button.setStyleSheet("color: darkblue; font-weight: bold; height: 45px;")

        button = gui.button( self._button_box, self, "Reset Fields", callback=self._call_reset_settings)
        button.setStyleSheet("color: darkred; font-weight: bold; font-style: italic; height: 45px; width: 150px;")

        gui.separator(self.controlArea)

        geom = QApplication.primaryScreen().geometry()
        self.setGeometry(QRect(round(geom.width()*0.05),
                               round(geom.height()*0.05),
                               round(min(geom.width()*0.98, self.MAX_WIDTH)),
                               round(min(geom.height()*0.95, self.MAX_HEIGHT))))

        self.setMaximumHeight(self.geometry().height())
        self.setMaximumWidth(self.geometry().width())

        self.controlArea.setFixedWidth(self.CONTROL_AREA_WIDTH)

        if show_automatic_box :
            gui.checkBox(self.controlArea, self, 'is_automatic_run', 'Automatic Execution')

        self._tabs_setting = oasysgui.tabWidget(self.controlArea)
        self._tabs_setting.setFixedHeight(self.TABS_AREA_HEIGHT)
        self._tabs_setting.setFixedWidth(self.CONTROL_AREA_WIDTH - 5)

        self._tab_bas = oasysgui.createTabPage(self._tabs_setting, "O.E. Setting")

        oasysgui.lineEdit(self._tab_bas, self, "oe_name", "O.E. Name", labelWidth=120, valueType=str, orientation="horizontal")

        self._propagation_box = oasysgui.widgetBox(self._tab_bas, "Propagation", addSpace=True, orientation="vertical")

        oasysgui.lineEdit(self._propagation_box, self, "distance", "Propagation Distance [m]", labelWidth=320, valueType=float, orientation="horizontal")
        gui.comboBox(self._propagation_box, self, "propagator", label="Propagator", items=["Fresnel", "Huygens"], labelWidth=300, sendSelectedValue=False, orientation="horizontal")
        oasysgui.lineEdit(self._propagation_box, self, "max_points_before", "Max Points Before", labelWidth=320, valueType=int, orientation="horizontal")

        self._draw_specific_box()

    def _get_button_text(self): return "Send Data"

    def _draw_specific_box(self): pass

    def _check_data(self):
        congruence.checkPositiveNumber(self.distance, "Propagation Distance")
        congruence.checkPositiveNumber(self.max_points_before, "Max Points Before")

    def _send_data(self):
        try:
            self._check_data()

            if self.beamline is None: raise Exception("Beamline is not initialized")

            beamline_element = self._get_beamline_element()

            output_beamline = copy.deepcopy(self.beamline)
            output_beamline.append_beamline_element(beamline_element=beamline_element)

            self.Outputs.okona_data.send(output_beamline)

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e.args[0]), QMessageBox.Ok)

            self.setStatusMessage("")
            self.progressBarFinished()

            if self.IS_DEVELOP: raise e

    def _get_propagator(self):
        if self.propagator == 0:   return OKONAPropagators.FRESNEL
        elif self.propagator == 1: return OKONAPropagators.HUYGENS
        else: raise ValueError("Invalid propagator")

    def _get_beamline_element(self):
        raise NotImplementedError()

    @Inputs.okona_data
    def receive_okona_data(self, data):
        if not data is None:
            self.beamline = data
            self._process_beamline_data()
            if self.is_automatic_run: self._send_data()

    def _call_reset_settings(self):
        if ConfirmDialog.confirmed(parent=self, message="Confirm Reset of the Fields?"):
            try:    self._reset_settings()
            except: pass

    def _process_beamline_data(self): pass

# --------------------------------------------------------------

class OWOpticalElementWithBoundaryShape(OWOpticalElement):
    # BOUNDARY

    width  = Setting(0.0)
    height = Setting(0.0)

    def __init__(self, show_automatic_box:bool = True):
        super(OWOpticalElementWithBoundaryShape, self).__init__(show_automatic_box=show_automatic_box)

    def _draw_specific_box(self):
        self._shape_box = oasysgui.widgetBox(self._tab_bas, "Boundary Shape", addSpace=True, orientation="vertical")

        self._rectangle_box = oasysgui.widgetBox(self._shape_box, "", addSpace=False, orientation="vertical", height=60)

        oasysgui.lineEdit(self._rectangle_box, self, "width", "Width/Sagittal [m]", labelWidth=260, valueType=float, orientation="horizontal")
        oasysgui.lineEdit(self._rectangle_box, self, "height", "Height/Tangential [m]", labelWidth=260, valueType=float, orientation="horizontal")

    
    def _check_data(self):
        super()._check_data()

        congruence.checkStrictlyPositiveNumber(self.width, "Width/Sagittal")
        congruence.checkStrictlyPositiveNumber(self.height, "Height/Tangential")

# --------------------------------------------------------------

class OWOpticalElementWithSurfaceShape(OWOpticalElementWithBoundaryShape):

    angle_radial          = Setting(0.0)
    orientation_azimuthal = Setting(0)
    angle_radial_mrad     = Setting(0.0)

    p_surface       = Setting(0.0)
    q_surface       = Setting(0.0)

    def __init__(self, show_automatic_box:bool = True):
        super(OWOpticalElementWithSurfaceShape, self).__init__(show_automatic_box=show_automatic_box)

    def _draw_specific_box(self):
        self._orientation_box = oasysgui.widgetBox(self._tab_bas, "Orientation", addSpace=True, orientation="vertical")

        self._le_angle_radial = oasysgui.lineEdit(self._orientation_box, self, "angle_radial", "Incident Angle (to normal) [deg]", labelWidth=260, valueType=float, orientation="horizontal", callback=self._calculate_angle_radial_mrad)
        self._le_angle_radial_mrad = oasysgui.lineEdit(self._orientation_box, self, "angle_radial_mrad", "Incident Angle (from surface) [mrad]", labelWidth=260, valueType=float, orientation="horizontal", callback=self._calculate_angle_radial_deg)

        gui.comboBox(self._orientation_box, self, "orientation_azimuthal", label="Orientation of central normal vector",
                     items=["Up", "Down", "Left", "Right"], labelWidth=300,
                     sendSelectedValue=False, orientation="horizontal")

        self._calculate_angle_radial_mrad()

        super(OWOpticalElementWithSurfaceShape, self)._draw_specific_box()

    def _calculate_angle_radial_mrad(self):
        self.angle_radial_mrad = round(numpy.radians(90-self.angle_radial)*1000, 7)

    def _calculate_angle_radial_deg(self):
        self.angle_radial = round(numpy.degrees(0.5 * numpy.pi - (self.angle_radial_mrad / 1000)), 10)

    def _get_orientation(self):
        if   self.orientation_azimuthal == 0: return MirrorOrientation.UP
        elif self.orientation_azimuthal == 1: return MirrorOrientation.DOWN
        elif self.orientation_azimuthal == 2: return MirrorOrientation.LEFT
        elif self.orientation_azimuthal == 3: return MirrorOrientation.RIGHT
        else: raise ValueError("Invalid orientation value")
