#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import copy
import sys
import time

from AnyQt.QtWidgets import QMessageBox
from AnyQt.QtGui import QTextCursor
from AnyQt.QtCore import QThread, pyqtSignal, QMutex

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from oasys2.canvas.util.canvas_util import add_widget_parameters_to_module
from oasys2.widget import gui as oasysgui
from oasys2.widget.util import congruence
from oasys2.widget.util.widget_util import EmittingStream
from orangewidget import gui
from orangewidget.settings import Setting

from orangecontrib.okona.widgets.gui.ow_optical_element import OWOpticalElementWithBoundaryShape
from orangecontrib.okona.util.python_script import PythonScript

from wofryokona.beamline.okona_beamline import OKONABeamline
from wofryokona.beamline.optical_elements.ideal_elements.okona_detector import OKONADetectorElement
from wofryokona.propagator.okona_propagation_manager import OKONAPropagationManager, OKONAPropagationModes
from wofryokona.util.plots import draw_detector_figure, draw_source_figure, draw_oe_intensity_figures, draw_oe_surface_errors_figures, get_oe_names, get_oe_with_surface_errors_names

class OWDetector(OWOpticalElementWithBoundaryShape):
    name = "Detector"
    description = "OKONA: Detector"
    icon = "icons/detector.png"
    priority = 4

    N = Setting(50048)
    propagation_mode = Setting(0)
    run_parallel = Setting(1)

    want_main_area = 1

    TABS_AREA_HEIGHT = 515
    MAX_WIDTH = 1320

    def __init__(self):
        super(OWDetector, self).__init__(show_automatic_box=True)

        self._main_tabs = oasysgui.tabWidget(self.mainArea)
        out_tab  = oasysgui.createTabPage(self._main_tabs, "Log")
        plot_tab = oasysgui.createTabPage(self._main_tabs, "Results")

        # script tab
        script_tab = oasysgui.createTabPage(self._main_tabs, "Script")
        self._okona_script = PythonScript()
        self._okona_script.code_area.setFixedHeight(365)

        script_box = gui.widgetBox(script_tab, "Python script", addSpace=False, orientation="vertical")

        button = gui.button(script_box, self, "Refresh Python Script", callback=self._refresh_python_script)
        button.setStyleSheet("color: darkblue; font-style: italic; height: 35px;")

        script_box.layout().addWidget(self._okona_script)

        self._tab = []
        self._tabs = oasysgui.tabWidget(plot_tab)

        self._tab_source   = oasysgui.createTabPage(self._tabs, "Source")
        self._tab_oes      = oasysgui.createTabPage(self._tabs, "Optical Elements")
        self._tab_detector = oasysgui.createTabPage(self._tabs, "Detector")

        self._source_plot_canvas   = self._get_standard_figure_canvas()
        self._optical_element_tabs = oasysgui.tabWidget(self._tab_oes)
        self._tab_intensity        = oasysgui.createTabPage(self._optical_element_tabs, "Intensity")
        self._tabs_intensity       = oasysgui.tabWidget(self._tab_intensity)
        self._tab_errors           = oasysgui.createTabPage(self._optical_element_tabs, "Error Profiles")
        self._tabs_errors          = oasysgui.tabWidget(self._tab_errors)
        self._detector_plot_canvas = self._get_standard_figure_canvas()

        self._tab_source.layout().addWidget(self._source_plot_canvas)
        self._tab_detector.layout().addWidget(self._detector_plot_canvas)

        self._okona_output = oasysgui.textArea(height=555, width=800)

        out_box = gui.widgetBox(out_tab, "System Output", addSpace=True, orientation="horizontal")
        out_box.layout().addWidget(self._okona_output)

    @staticmethod
    def _get_standard_figure_canvas(): return FigureCanvas(Figure(figsize=(8, 6)))

    def _get_button_text(self): return "Run Simulation"

    def _write_stdout(self, text):
        cursor = self._okona_output.textCursor()
        cursor.movePosition(QTextCursor.End)
        cursor.insertText(text)
        self._okona_output.setTextCursor(cursor)
        self._okona_output.ensureCursorVisible()

        if "-> Progress: " in text:
            try:
                current_progress = float(text.split("(")[1].split("%)")[0])
                if current_progress - self._last_progress > 5.0:
                    self.progressBarSet(current_progress)
                    self._last_progress = current_progress
            except:
                pass

    def _draw_specific_box(self):
        super(OWDetector, self)._draw_specific_box()

        gui.comboBox(self._propagation_box, self, "propagation_mode", label="Propagation Mode",
                     items=["Wave Optics", "Ray Tracing"], labelWidth=300, sendSelectedValue=False, orientation="horizontal")

        gui.comboBox(self._propagation_box, self, "run_parallel", label="Parallel Calculation",
                     items=["No", "Yes"], labelWidth=300, sendSelectedValue=False, orientation="horizontal")

        self.detector_box = oasysgui.widgetBox(self._tab_bas, "Detector Parameters", addSpace=False, orientation="vertical")

        oasysgui.lineEdit(self.detector_box, self, "N", "Number of Points", labelWidth=320, valueType=int, orientation="horizontal")


    def _check_data(self):
        super(OWDetector, self)._check_data()

        congruence.checkStrictlyPositiveNumber(self.N, "Number of Points")

    def _get_beamline_element(self):
        return OKONADetectorElement(name=self.oe_name,
                                    width=self.width,
                                    height=self.height,
                                    N=self.N,
                                    distance=self.distance,
                                    propagator=self._get_propagator(),
                                    max_points_before=None if self.max_points_before==0 else self.max_points_before)

    def _get_propagation_mode(self):
        if   self.propagation_mode == 0: return OKONAPropagationModes.WAVE_OPTICS
        elif self.propagation_mode == 1: return OKONAPropagationModes.RAY_TRACING
        else: raise ValueError("Unknown propagation mode")

    def _process_beamline_data(self):
        self._refresh_python_script()

    def _refresh_python_script(self):
        if not self.beamline is None:
            beamline = copy.deepcopy(self.beamline)
            try:
                self._check_data()
                beamline.append_beamline_element(beamline_element=self._get_beamline_element())
            except:
                beamline.append_beamline_element(beamline_element=OKONADetectorElement(name="Input Error in Detector", N=0))

            self._okona_script.set_code(beamline.to_python_code(propagation_mode=self._get_propagation_mode(),
                                                                run_parallel=self.run_parallel == 1))

    def _send_data(self):
        try:
            self._check_data()

            if not self.beamline is None:
                self._main_tabs.setCurrentIndex(0)
                self._okona_output.setText("")

                detector_element = self._get_beamline_element()

                beamline = copy.deepcopy(self.beamline)
                beamline.append_beamline_element(beamline_element=detector_element)

                self._last_progress = 0.0

                self._thread = PropagationThread(beamline=beamline,
                                                 propagation_mode=self._get_propagation_mode(),
                                                 run_parallel=self.run_parallel == 1,
                                                 widget=self)
                self._thread.begin.connect(self._begin)
                self._thread.error.connect(self._error)
                self._thread.finished.connect(self._finished)
                self._thread.write_stdout.connect(self._write_stdout)
                self._thread.start()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e.args[0]), QMessageBox.Ok)

            self.setStatusMessage("")
            self.progressBarFinished()

            if self.IS_DEVELOP: raise e

    def _begin(self):
        self._thread.mutex.tryLock()
        self._button_box.setEnabled(False)
        self.controlArea.setEnabled(False)

        self.progressBarInit()
        self.setStatusMessage("OKONA Propagation Started")

        self._thread.mutex.unlock()

    def _error(self, e: Exception):
        QMessageBox.critical(self, "Error", str(e.args[0]), QMessageBox.Ok)

        self._button_box.setEnabled(True)
        self.controlArea.setEnabled(True)

        self.progressBarFinished()

        if self.IS_DEVELOP: raise e

    def _finished(self, results: dict):
        self.setStatusMessage("OKONA Propagation completed")

        self._button_box.setEnabled(True)
        self.controlArea.setEnabled(True)

        self._main_tabs.setCurrentIndex(1)

        draw_source_figure(self._source_plot_canvas.figure, results)
        self._source_plot_canvas.draw()

        draw_detector_figure(self._detector_plot_canvas.figure, results)
        self._detector_plot_canvas.draw()

        self._tabs_intensity.clear()
        oes        = get_oe_names(results)
        figures_oe = []
        for oe in oes:
            tab = oasysgui.createTabPage(self._tabs_intensity, oe)
            figure_canvas = self._get_standard_figure_canvas()
            tab.layout().addWidget(figure_canvas)
            figures_oe.append(figure_canvas.figure)
        draw_oe_intensity_figures(figures_oe, results)

        self._tabs_errors.clear()
        oes_with_errors = get_oe_with_surface_errors_names(results)
        figures_errors  = []
        for oe in oes_with_errors:
            tab = oasysgui.createTabPage(self._tabs_errors, oe)
            figure_canvas = self._get_standard_figure_canvas()
            tab.layout().addWidget(figure_canvas)
            figures_errors.append(figure_canvas.figure)
        draw_oe_surface_errors_figures(figures_errors, results)

        self.progressBarFinished()

class PropagationThread(QThread):
    begin        = pyqtSignal()
    error        = pyqtSignal(str)
    finished     = pyqtSignal(dict)
    write_stdout = pyqtSignal(str)
    mutex        = QMutex()

    def __init__(self,
                 beamline: OKONABeamline,
                 propagation_mode: str,
                 run_parallel: bool,
                 widget: OWDetector,
                 parent=None):
        super(PropagationThread, self).__init__(parent)

        self._beamline = beamline
        self._propagation_mode = propagation_mode
        self._run_parallel = run_parallel
        self._widget = widget

    def _write_stdout(self, text): self.write_stdout.emit(text)

    def run(self):
        self.begin.emit()

        try:
            sys.stdout = EmittingStream(textWritten=self._write_stdout)

            results = OKONAPropagationManager.do_propagation(beamline=self._beamline,
                                                             propagation_mode=self._propagation_mode,
                                                             run_parallel=self._run_parallel)
            self.finished.emit(results)
        except Exception as e:
            self.error.emit(e)

add_widget_parameters_to_module(__name__)

