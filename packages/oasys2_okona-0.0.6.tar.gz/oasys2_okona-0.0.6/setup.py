#! /usr/bin/env python3

# coding: utf-8
# /*##########################################################################
#
# Copyright (c) 2026-now Lawrence Berkley National Laboratory and
#                        Argonne National Laboratory
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
# ###########################################################################*/

__authors__ = ["Lorenzo Raimondi, Luca Rebuffi"]
__license__ = "BSD3"
__date__ = "13/05/2026"

import os
from setuptools import find_packages, setup

NAME = 'OASYS2-OKONA'
VERSION = '0.0.6'
ISRELEASED = False

DESCRIPTION = 'OASYS2-OKONA: Oasys 2 widgets for OKONA'
README_FILE = os.path.join(os.path.dirname(__file__), 'README.md')
LONG_DESCRIPTION = open(README_FILE).read()
AUTHOR = 'Lorenzo Raimondi, L. Rebuffi'
AUTHOR_EMAIL = 'lrebuffi@anl.gov'
URL = 'https://github.com/oasys-kit/OASYS2-OKONA'
DOWNLOAD_URL = 'https://github.com/oasys-kit/OASYS2-OKONA'
LICENSE = 'BSD3'

KEYWORDS = [
    'ray tracing',
    'x-ray optics',
    'oasys2',
    ]

CLASSIFIERS = [
    'Development Status :: 4 - Beta',
    'Environment :: X11 Applications :: Qt',
    'Environment :: Console',
    'Environment :: Plugins',
    'Programming Language :: Python',
    'Programming Language :: Python :: 3',
    'Intended Audience :: Science/Research',
    ]

INSTALL_REQUIRES = (
    'oasys2>=0.0.42',
    'wofryokona>=0.0.4',
)

PACKAGES = find_packages(exclude=('*.tests', '*.tests.*', 'tests.*', 'tests'))

PACKAGE_DATA = {
    "orangecontrib.okona.widgets.sources":["icons/*.png", "icons/*.jpg"],
    "orangecontrib.okona.widgets.optics": ["icons/*.png", "icons/*.jpg"],
    "orangecontrib.okona.widgets.tools":["icons/*.png", "icons/*.jpg"],
    "orangecontrib.okona.tutorials": ["*.ows"],
    }

ENTRY_POINTS = {
    'oasys2.addons' : ("OKONA = orangecontrib.okona", ),
    'oasys2.widgets' : (
            "OKONA Sources = orangecontrib.okona.widgets.sources",
            "OKONA Optics = orangecontrib.okona.widgets.optics",
            "OKONA Tools = orangecontrib.okona.widgets.tools",
    ),
    'oasys2.menus' : ("okonamenu = orangecontrib.okona.menu",),
    'oasys2.tutorials' : ("okonatutorial = orangecontrib.okona.tutorials",)
    }

if __name__ == '__main__':
    setup(
          name = NAME,
          version = VERSION,
          description = DESCRIPTION,
          long_description = LONG_DESCRIPTION,
          long_description_content_type='text/markdown',
          author = AUTHOR,
          author_email = AUTHOR_EMAIL,
          url = URL,
          download_url = DOWNLOAD_URL,
          license = LICENSE,
          keywords = KEYWORDS,
          classifiers = CLASSIFIERS,
          packages = PACKAGES,
          package_data = PACKAGE_DATA,
          install_requires = INSTALL_REQUIRES,
          entry_points = ENTRY_POINTS,
          include_package_data = True,
          zip_safe = False,
          )
