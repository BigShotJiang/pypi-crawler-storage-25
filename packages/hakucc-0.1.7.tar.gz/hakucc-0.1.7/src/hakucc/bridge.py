"""Core bridge: orchestrates Feishu ↔ Claude Agent communication."""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions
from claude_agent_sdk.types import (
    PermissionResultAllow,
    PermissionResultDeny,
    ToolPermissionContext,
    AssistantMessage,
    ResultMessage,
    TextBlock,
    ThinkingBlock,
    ToolUseBlock,
    ServerToolUseBlock,
    UserMessage,
)

from . import logger
from . import commands  # noqa: F401 — register built-in commands
from .config import ResolvedConfig
from .session import SessionStore
from .lock import release_lock
from .feishu.client import FeishuClient
from .feishu.ws import FeishuWS
from .feishu.reaction import ReactionManager
from .feishu.message import (
    reply_card,
    send_text,
    send_tool_card,
    build_header_tags,
)
from .feishu.image import download_image
from .feishu.file import download_file, DownloadedFile

# Tools that don't need card visualization
_SILENT_TOOLS = {"ExitPlanMode", "TodoWrite", "NotebookEdit", "CronCreate", "CronDelete", "CronList"}

# Tool name → Chinese label mapping
_TOOL_LABELS: dict[str, str] = {
    "Read": "读取文件",
    "Write": "写入文件",
    "Edit": "编辑文件",
    "Bash": "执行命令",
    "Glob": "搜索文件",
    "Grep": "搜索内容",
    "Agent": "子任务",
    "WebSearch": "搜索网络",
    "mcp__web_reader__webReader": "读取网页",
    "AskUserQuestion": "用户确认",
}


def _tool_label(name: str) -> str:
    return _TOOL_LABELS.get(name, name)


def _tool_detail(name: str, inp: dict[str, Any]) -> str:
    """Format tool input for display."""
    if name == "Read":
        return inp.get("file_path", "")
    if name == "Write":
        return inp.get("file_path", "")
    if name == "Edit":
        return inp.get("file_path", "")
    if name == "Bash":
        cmd = inp.get("command", "")
        return cmd[:120] + "..." if len(cmd) > 120 else cmd
    if name == "Glob":
        return inp.get("pattern", "")
    if name == "Grep":
        return inp.get("pattern", "")
    return json.dumps(inp, ensure_ascii=False)[:120]


@dataclass
class EventAccumulator:
    """Accumulates text and thinking from agent events."""

    text: str = ""
    thinking: str = ""
    stream_text: str = ""
    tool_count: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    duration_ms: int = 0
    cost_usd: float = 0.0
    model: str | None = None
    _start_time: float = field(default_factory=time.time)

    def accumulate_text(self, text: str) -> None:
        self.text += text

    def accumulate_thinking(self, thinking: str) -> None:
        self.thinking += thinking

    def accumulate_stream(self, text: str) -> None:
        self.stream_text += text

    def increment_tool_count(self) -> None:
        self.tool_count += 1

    def set_usage(self, usage: Any, cost: float | None, duration_ms: int | None) -> None:
        if usage:
            if isinstance(usage, dict):
                self.input_tokens = usage.get("input_tokens", 0) or 0
                self.output_tokens = usage.get("output_tokens", 0) or 0
            else:
                self.input_tokens = getattr(usage, "input_tokens", 0) or 0
                self.output_tokens = getattr(usage, "output_tokens", 0) or 0
        if cost is not None:
            self.cost_usd = cost
        if duration_ms is not None:
            self.duration_ms = duration_ms
        else:
            self.duration_ms = int((time.time() - self._start_time) * 1000)

    @property
    def full_text(self) -> str:
        """Combined text (stream + final)."""
        return self.stream_text or self.text

    def reset(self) -> None:
        self.text = ""
        self.thinking = ""
        self.stream_text = ""
        self.tool_count = 0
        self.input_tokens = 0
        self.output_tokens = 0
        self.duration_ms = 0
        self.cost_usd = 0.0
        self.model = None
        self._start_time = time.time()


class Bridge:
    """Core orchestrator connecting Feishu messages with Claude Agent."""

    def __init__(self, config: ResolvedConfig, profile: str):
        self.config = config
        self.profile = profile
        self.feishu: FeishuClient | None = None
        self.ws: FeishuWS | None = None
        self.agent: ClaudeSDKClient | None = None
        self.session: SessionStore | None = None
        self.reaction: ReactionManager | None = None
        self.cardkit: Any | None = None  # CardKitController, set later

        self._processing = False
        self._events = EventAccumulator()
        self._tool_cards: dict[str, str] = {}  # tool_use_id → message_id
        self._seen_messages: dict[str, float] = {}  # dedup: senderId:msgId → time
        self._start_time = time.time()
        self._format_guide: str = ""

    async def start(self, cwd: str, continue_session: bool = False, force: bool = False) -> None:
        """Initialize and start the bridge."""
        logger.info(f"Starting hakucc bridge (profile={self.profile}, cwd={cwd})")

        # Init session
        self.session = SessionStore(self.config.state_file)
        self.session.load()

        # Init Feishu client
        self.feishu = FeishuClient(
            app_id=self.config.feishu.app_id,
            app_secret=self.config.feishu.app_secret,
            domain=self.config.feishu_domain,
        )
        self.reaction = ReactionManager(self.feishu, self.config.reaction)

        # Get bot open_id for @ detection in groups
        self._bot_open_id: str | None = None
        try:
            self._bot_open_id = await self.feishu.get_bot_open_id()
            if self._bot_open_id:
                logger.info(f"Bot open_id: {self._bot_open_id}")
        except Exception:
            pass  # Non-critical, will fall back to checking if any mention exists

        # Load format guide
        self._format_guide = self._load_format_guide()

        # Init Claude Agent (lazy — actual connection on first message)
        self._cwd = cwd

        # Start Feishu WS
        self.ws = FeishuWS(
            app_id=self.config.feishu.app_id,
            app_secret=self.config.feishu.app_secret,
            domain=self.config.feishu_domain,
            on_event=self._on_feishu_event,
        )

        logger.success("hakucc bridge ready, connecting to Feishu WS...")
        await self.ws.start()

    async def shutdown(self) -> None:
        """Graceful shutdown."""
        logger.info("Shutting down bridge...")
        if self.agent:
            await self.agent.disconnect()
            self.agent = None
        if self.ws:
            await self.ws.stop()
        release_lock(self.config.lock_file)
        logger.success("Bridge shutdown complete")

    # --- Feishu event handling ---

    async def _on_feishu_event(self, event: dict[str, Any]) -> None:
        """Handle incoming Feishu WS event."""
        try:
            header = event.get("header", {})
            event_type = header.get("event_type", "")

            if event_type != "im.message.receive_v1":
                return

            body = event.get("event", {})
            msg = body.get("message", {})
            sender = body.get("sender", {})

            message_id = msg.get("message_id", "")
            chat_id = msg.get("chat_id", "")
            chat_type = msg.get("chat_type", "")
            msg_type = msg.get("message_type", "")  # noqa: F841
            create_time = float(msg.get("create_time", "0"))

            sender_id = sender.get("sender_id", {})
            user_id = sender_id.get("open_id", "") or sender_id.get("user_id", "")
            sender_type = sender.get("sender_type", "")

            # Filter: skip messages from bot itself
            if sender_type == "app":
                return

            # Filter: skip messages before start time (30s buffer)
            if create_time and create_time / 1000 < self._start_time - 30:
                return

            # Filter: skip non-user messages in group chats
            if sender_type not in ("user",):
                return

            # Dedup
            dedup_key = f"{user_id}:{message_id}"
            now = time.time()
            if dedup_key in self._seen_messages:
                return
            self._seen_messages[dedup_key] = now
            # Clean old entries (>30s)
            self._seen_messages = {k: v for k, v in self._seen_messages.items() if now - v < 30}

            # Group chat: only respond when @mentioned or replying to bot
            if chat_type == "group":
                mentions = msg.get("mentions", [])
                if self._bot_open_id:
                    bot_mentioned = any(
                        m.get("id", {}).get("open_id") == self._bot_open_id
                        for m in mentions
                    )
                else:
                    # Unknown bot open_id: respond to any @mention
                    bot_mentioned = len(mentions) > 0
                # Also check if replying to bot message
                parent_id = msg.get("parent_id", "")
                if not bot_mentioned and not parent_id:
                    return

            # Auto-detect owner
            if self.session and not self.session.owner_open_id:
                self.session.owner_open_id = user_id
                self.session.save()

            # Owner-only check
            if self.config.feishu.owner_open_id and user_id != self.config.feishu.owner_open_id:
                return

            # Concurrent request protection
            if self._processing:
                elapsed = time.time() - self._events._start_time
                await self.feishu.reply_text(
                    message_id,
                    f"Processing... ({elapsed:.0f}s elapsed). Please wait.",
                )
                return

            # Parse message content
            text, images, files = await self._parse_message(msg, message_id, chat_id)
            if not text and not images and not files:
                return

            # Check for commands
            if text:
                cmd_result = await self._try_command(text, message_id, chat_id)
                if cmd_result:
                    return

            # Save chat_id for startup notification
            if self.session and not self.session.chat_id:
                self.session.chat_id = chat_id
                self.session.save()

            logger.msg(text or "(file/image)")
            await self._handle_turn(text, images, files, message_id, chat_id)

        except Exception as e:
            logger.error(f"Event handling error: {e}")
            import traceback
            traceback.print_exc()

    async def _parse_message(
        self, msg: dict[str, Any], message_id: str, chat_id: str
    ) -> tuple[str, list[dict], list[DownloadedFile]]:
        """Parse Feishu message into text, images, and files."""
        msg_type = msg.get("message_type", "")
        content_str = msg.get("content", "{}")

        try:
            content = json.loads(content_str) if isinstance(content_str, str) else content_str
        except json.JSONDecodeError:
            content = {}

        text = ""
        images: list[dict] = []
        files: list[DownloadedFile] = []

        if msg_type == "text":
            text = content.get("text", "").strip()

        elif msg_type == "post":
            # Rich text — extract text and inline images
            title = content.get("title", "")
            lines: list[str] = []
            if title:
                lines.append(title)
            for paragraph in content.get("content", []):
                for element in paragraph:
                    tag = element.get("tag", "")
                    if tag == "text":
                        lines.append(element.get("text", ""))
                    elif tag == "at":
                        lines.append(element.get("user_name", "@"))
                    elif tag == "a":
                        lines.append(element.get("text", element.get("href", "")))
                    elif tag == "image":
                        img_key = element.get("image_key", "")
                        if img_key and self.feishu:
                            img_data = await download_image(self.feishu, message_id, img_key)
                            if img_data:
                                images.append(img_data)
            text = "\n".join(lines).strip()

        elif msg_type == "image":
            img_key = content.get("image_key", "")
            if img_key and self.feishu:
                img_data = await download_image(self.feishu, message_id, img_key)
                if img_data:
                    images.append(img_data)
            text = ""

        elif msg_type == "file":
            file_key = content.get("file_key", "")
            filename = content.get("file_name", "unnamed")
            if file_key and self.feishu:
                f = await download_file(
                    self.feishu, message_id, file_key,
                    self.config.temp_dir, filename,
                )
                if f:
                    files.append(f)
            text = ""

        return text, images, files

    # --- Agent interaction ---

    async def _handle_turn(
        self,
        text: str,
        images: list[dict],
        files: list[DownloadedFile],
        message_id: str,
        chat_id: str,
    ) -> None:
        """Execute one conversation turn."""
        self._processing = True
        self._events.reset()
        self._message_id = message_id
        self._chat_id = chat_id

        timeout_seconds = self.config.processing_timeout_ms / 1000

        try:
            # Set reaction
            if self.reaction:
                await self.reaction.set_processing(message_id)

            # Connect agent if needed
            if self.agent is None:
                await self._connect_agent()

            # Build prompt content
            prompt = self._build_prompt(text, images, files)

            # Send query with timeout
            async with asyncio.timeout(timeout_seconds):
                await self.agent.query(prompt)

                # Receive response
                async for message in self.agent.receive_response():
                    await self._on_agent_message(message)

            # Finalize: format and send reply
            await self._finalize_response(message_id, chat_id)

        except asyncio.TimeoutError:
            logger.warn(f"Turn timed out after {timeout_seconds}s")
            if self.agent:
                try:
                    await self.agent.interrupt()
                except Exception:
                    pass
            if self.feishu:
                await self.feishu.reply_text(message_id, f"⏰ Processing timed out ({timeout_seconds:.0f}s)")
            if self.reaction:
                await self.reaction.set_timeout()

        except asyncio.CancelledError:
            logger.warn("Turn cancelled")
            if self.agent:
                try:
                    await self.agent.interrupt()
                except Exception:
                    pass
            if self.reaction:
                await self.reaction.set_aborted()
            return

        except Exception as e:
            logger.error(f"Turn error: {e}")
            import traceback
            traceback.print_exc()
            if self.feishu:
                error_msg = f"Error: {str(e)[:500]}"
                try:
                    await self.feishu.reply_text(message_id, error_msg)
                except Exception:
                    pass
            if self.reaction:
                await self.reaction.set_error()
            return

        finally:
            self._processing = False
            if self.reaction:
                await self.reaction.set_done()

    async def _connect_agent(self) -> None:
        """Create and connect the Claude Agent SDK client."""
        # Build system prompt with format guide
        system_prompt: dict[str, Any] = {
            "type": "preset",
            "preset": "claude_code",
        }
        if self._format_guide:
            system_prompt["append"] = self._format_guide

        # Build options
        options = ClaudeAgentOptions(
            system_prompt=system_prompt,
            permission_mode=self.config.agent.permission_mode,
            allowed_tools=self.config.agent.allowed_tools,
            disallowed_tools=self.config.agent.disallowed_tools or None,
            model=self.config.agent.model,
            cwd=self._cwd,
            resume=self.session.session_id if self.session and self.session.has_session() else None,
            include_partial_messages=True,
            can_use_tool=self._auto_approve,
            thinking=self.config.agent.thinking,
            effort=self.config.agent.effort,
            max_turns=200,
        )

        self.agent = ClaudeSDKClient(options)
        await self.agent.connect()
        logger.success("Claude Agent connected")

    async def _auto_approve(
        self, tool_name: str, input_data: dict[str, Any], context: ToolPermissionContext
    ) -> PermissionResultAllow | PermissionResultDeny:
        """Auto-approve tools based on config."""
        # Allowed tools — auto approve
        if tool_name in self.config.agent.allowed_tools:
            return PermissionResultAllow()

        # Check exec security
        if tool_name == "Bash" and self.config.exec_security.enabled:
            cmd = input_data.get("command", "")
            for pattern in self.config.exec_security.blacklist:
                if pattern in cmd:
                    return PermissionResultDeny(
                        message=f"Blocked: command matches security blacklist pattern '{pattern}'"
                    )

        # Default: allow (user-initiated = authorized)
        return PermissionResultAllow()

    def _build_prompt(
        self, text: str, images: list[dict], files: list[DownloadedFile]
    ) -> str | list[dict]:
        """Build the prompt content for the agent."""
        if not images and not files:
            return text

        # Build multi-modal content blocks
        blocks: list[dict[str, Any]] = []

        if text:
            blocks.append({"type": "text", "text": text})

        for img in images:
            blocks.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": img["media_type"],
                    "data": img["base64"],
                },
            })

        for f in files:
            prompt_template = self.config.file.prompt
            file_prompt = prompt_template.format(
                filename=f.filename,
                size=f"{f.size} bytes",
                mime_type=f.mime_type,
            )
            blocks.append({"type": "text", "text": file_prompt})

            # Read file content if text-based
            if f.mime_type.startswith("text/"):
                try:
                    content = Path(f.filepath).read_text(encoding="utf-8", errors="replace")
                    blocks.append({"type": "text", "text": f"```\n{content}\n```"})
                except Exception:
                    pass

        return blocks

    async def _on_agent_message(self, message: Any) -> None:
        """Dispatch SDK messages to appropriate handlers."""
        if isinstance(message, AssistantMessage):
            await self._handle_assistant_message(message)
        elif isinstance(message, UserMessage):
            pass  # Echo of user input, ignore
        elif isinstance(message, ResultMessage):
            await self._handle_result_message(message)

    async def _handle_assistant_message(self, msg: AssistantMessage) -> None:
        """Handle an AssistantMessage from the SDK."""
        # Capture model info from assistant message
        if msg.model:
            self._events.model = msg.model
        for block in msg.content:
            if isinstance(block, TextBlock):
                self._events.accumulate_text(block.text)
                # Stream to cardkit if active
                if self.cardkit and self.config.streaming.enabled:
                    await self._stream_text(block.text)

            elif isinstance(block, ThinkingBlock):
                self._events.accumulate_thinking(block.thinking)

            elif isinstance(block, ToolUseBlock):
                if block.name not in _SILENT_TOOLS:
                    await self._show_tool_start(block)

            elif isinstance(block, ServerToolUseBlock):
                pass  # Server-side tool, ignore

    async def _handle_result_message(self, msg: ResultMessage) -> None:
        """Handle the final ResultMessage."""
        # Save session
        if self.session and msg.session_id:
            self.session.session_id = msg.session_id
            self.session.save()

        # Extract usage
        self._events.set_usage(
            msg.usage,
            msg.total_cost_usd,
            msg.duration_ms,
        )

    async def _stream_text(self, text: str) -> None:
        """Stream text to CardKit controller."""
        if self.cardkit:
            self._events.accumulate_stream(text)
            await self.cardkit.append(self._events.stream_text)

    async def _show_tool_start(self, block: ToolUseBlock) -> None:
        """Show a tool execution card."""
        if not self.feishu:
            return

        self._events.increment_tool_count()
        label = _tool_label(block.name)
        detail = _tool_detail(block.name, block.input)

        msg_id = await send_tool_card(
            self.feishu, self._message_id,
            label=label, detail=detail,
            status="running", tool_name=block.name,
        )
        if msg_id:
            self._tool_cards[block.id] = msg_id

    async def _show_tool_result(self, tool_use_id: str, result: str | None = None) -> None:
        """Update a tool card with result."""
        if not self.feishu or tool_use_id not in self._tool_cards:
            return

        msg_id = self._tool_cards.pop(tool_use_id)  # noqa: F841
        # For now, just update with done status
        # The actual result comes from assistant text
        # TODO: wire up tool result display

    async def _finalize_response(self, message_id: str, chat_id: str) -> None:
        """Format and send the final response."""
        text = self._events.full_text
        if not text.strip():
            return

        # Check overflow
        overflow_config = self.config.overflow
        needs_overflow = len(text) > overflow_config.threshold

        # Build header tags
        tags = build_header_tags(
            model=self._events.model,
            input_tokens=self._events.input_tokens,
            output_tokens=self._events.output_tokens,
            duration_ms=self._events.duration_ms,
            tool_count=self._events.tool_count,
        )

        thinking = self._events.thinking if self._events.thinking else None

        stats = {
            "input_tokens": self._events.input_tokens,
            "output_tokens": self._events.output_tokens,
            "tool_count": self._events.tool_count,
            "duration_ms": self._events.duration_ms,
        }

        if needs_overflow and overflow_config.mode == "document":
            # Try to create cloud document
            await self._send_overflow_document(text, message_id, chat_id, tags, thinking, stats)
        else:
            # Normal card reply
            await reply_card(
                self.feishu,
                message_id,
                markdown=text,
                title=self.config.card.title,
                header_icon_img_key=self.config.card.header_icon_img_key,
                template="green" if not thinking else "blue",
                tags=tags,
                thinking=thinking,
                stats=stats,
            )

    async def _send_overflow_document(
        self,
        text: str,
        message_id: str,
        chat_id: str,
        tags: list[dict],
        thinking: str | None,
        stats: dict,
    ) -> None:
        """Send overflow content as a cloud document."""
        # Lazy import to avoid circular dependency
        from .feishu.document import create_document_with_content

        doc_url = await create_document_with_content(
            self.feishu, self.config, text, self.profile, self._cwd,
        )

        if doc_url:
            doc_card = f"📝 内容较长，已写入云文档：{doc_url}"
            await reply_card(
                self.feishu, message_id,
                markdown=doc_card,
                title=self.config.card.title,
                header_icon_img_key=self.config.card.header_icon_img_key,
                template="green",
                tags=tags,
                thinking=thinking,
                stats=stats,
            )
        else:
            # Fallback: send as regular card (might be truncated)
            await reply_card(
                self.feishu, message_id,
                markdown=text,
                title=self.config.card.title,
                header_icon_img_key=self.config.card.header_icon_img_key,
                template="green",
                tags=tags,
                thinking=thinking,
                stats=stats,
            )

    # --- Command handling ---

    async def _try_command(self, text: str, message_id: str, chat_id: str) -> bool:
        """Try to handle as a command. Returns True if handled."""
        if not text.startswith("/"):
            return False

        parts = text.split(None, 1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""

        # Lazy import
        from .commands.registry import match_command
        result = match_command(cmd, args, self.config, self)
        if result is not None:
            response = await result
            if response and self.feishu:
                await reply_card(
                    self.feishu, message_id,
                    markdown=response,
                    title=self.config.card.title,
                    header_icon_img_key=self.config.card.header_icon_img_key,
                )
            return True
        return False

    # --- Format guide ---

    def _load_format_guide(self) -> str:
        """Load the format guide (user > built-in)."""
        # Check for user-provided guide
        guide_path = Path.home() / ".hakucc" / "format-guide.md"
        if guide_path.exists():
            return guide_path.read_text(encoding="utf-8")

        # Built-in guide
        return _BUILTIN_FORMAT_GUIDE

    # --- Utility ---

    async def send_message(self, text: str) -> None:
        """Send a message to the current chat."""
        if self.feishu and self.session and self.session.chat_id:
            await send_text(self.feishu, self.session.chat_id, text)


    # --- Multi-file mode ---

    async def _handle_multifile(self, text: str, message_id: str) -> bool:
        """Handle multi-file mode commands. Returns True if handled."""
        if text.strip() == "/mf start":
            self._mf_mode = True
            self._mf_files: list[DownloadedFile] = []
            self._mf_texts: list[str] = []
            self._mf_start_time = time.time()
            await self.feishu.reply_text(message_id, "Multi-file mode started. Send files or text, then /mf done to analyze.")
            return True

        if text.strip() == "/mf done":
            if not getattr(self, "_mf_mode", False):
                return False
            self._mf_mode = False

            # Combine all files and text
            combined_text = "\n".join(self._mf_texts) if self._mf_texts else ""
            files = self._mf_files

            # Build prompt
            if combined_text:
                prompt = self.config.file.multifile_prompt.format(
                    files=", ".join(f.filename for f in files),
                    text=combined_text,
                )
            else:
                prompt = self.config.file.multifile_prompt.format(
                    files=", ".join(f.filename for f in files),
                    text="",
                )

            await self._handle_turn(prompt, [], files, message_id, self._chat_id)
            return True

        # In multi-file mode, cache files
        if getattr(self, "_mf_mode", False):
            return False  # Let normal flow handle it, files will be cached

        return False


# Built-in format guide (Feishu-specific Markdown rules)
_BUILTIN_FORMAT_GUIDE = """# 飞书格式规范

你的回复会通过飞书展示。短内容显示为交互式卡片，长内容写入飞书云文档。

## 通用规则

### 代码块
- 必须标注语言：```typescript、```python、```bash 等
- 不要使用无语言标记的代码块

### 表格
- 列数不超过 5 列
- 单元格内容尽量简短

### 不要使用
- 外部图片链接 ![alt](https://...)
- HTML 标签
- 脚注 [^1]
- 折叠 <details>

## 卡片规则（短内容）

- 标题只用 #### (H4) 和 ##### (H5)
- 不要使用 # ## ###
- 不支持 $$ 数学公式
- 不支持嵌套列表

## 文档规则（长内容）

- Callout 语法：> [!NOTE]、> [!TIP]、> [!WARNING]、> [!DANGER]
- 代码块标注语言
- 标题使用 H1-H6
"""
