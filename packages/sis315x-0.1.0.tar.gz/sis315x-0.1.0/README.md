# SIS315x

This module provides a lightweight Python interface for the SIS3153 (USB 3.0/Ethernet) and SIS3150 (USB 2.0) VME bus master/system controller cards, thereby enabling access to a VME system via USB.

It is assumed that the device driver included with the device is already installed on the system and ready for use. Drivers are available for Windows (32-bit/64-bit) and Linux (32-bit/64-bit).
For more information on installing the driver, please refer to the SIS3153 / SIS3150 documentation.

## Installation

> [!NOTE]
> Python version >= 3.13.0 is required

From [PyPI](https://test.pypi.org/project/sis315x):
```
pip3 install sis315x
```
 
## Examples

The following example demonstrates how to access the local registers of a SIS3153:
```
from sis315x import Sis315x, Sis315xError

interface = Sis315x('usb')

try:
    interface.open()
except Sis315xError as e:
    print(e)
    exit()

# read from register SIS3153_SERIAL_NUMBER_REG (0x2)
sn = interface.read_register(0x2)
print('Serial number: %s' % str(sn&0xFFFF))

# write to register SIS3153_CONTROL_STATUS (0x0)
# switch user LED A on
interface.write_register(0x0, 0x1)

interface.close()
```

The following brief example illustrates how to access the VME system:
```
from sis315x import Sis315x, Sis315xError

interface = Sis315x('usb')

try:
    interface.open()
except Sis315xError as e:
    print(e)
    exit()

interface.reset_vme_system()

vme_base_addr = 0x41000000

# write to register 0x4
# use A32-D32
print(hex(interface.write_vme('a32_d32', vme_base_addr + 0x4, , 0x11223344)))

# read from register 0x4
# use A32-D32
print(hex(interface.read_vme('a32_d32', vme_base_addr + 0x4)))

interface.close()
```

## Supported VME Mods

Overview of supported VME read/write modes. A list of the corresponding mode names required as parameters for the `read_vme()` and `write_vme()` functions is provided below.

### VME master read cycles:

- CRCSR, A16, A24, A32
- D8/D16/D32/BLT32/MBLT64/2eVME/2eSST160/2eSST267/2eSST320

### VME master write cycles:

- CRCSR, A16, A24, A32
- D8/D16/D32/BLT32/MBLT64/2eVME/2eSST160/2eSST267/2eSST320

### VME IACK

The register SIS3153_VME_INTERRUPT_STATUS (0x12) reflects the status of the VME IRQ line. An interrupt acknowledge cycle (IACK cycle) can be triggered as follows. The interrupt vector is returned:
```
irq_vector = interface.read_iack(vme_irq_level)
```

### Mode names

Corresponding mode names required as parameters for `read_vme()` and `write_vme()`:

| Address width | Mode names |
| ------------- | ---------- |
| CRCSR | crcsr_d8, crcsr_d16, crcsr_d32 |
| A16 | a16_d8, a16_d16, a16_d32 | 
| A24 | a24_d8, a24_d16, a24_d32, a24_blt32, a24_blt32_fifo, a24_blt64, a24_blt64_fifo, a24_d32_dma, a24_d32_dma_fifo |
| A32 | a32_d8, a32_d16, a32_d32, a32_blt32, a32_blt32_fifo, a32_blt64, a32_blt64_fifo, a32_d32_dma, a32_d32_dma_fifo, a32_2evme, a32_2evme_fifo, a32_2esst160, a32_2esst160_fifo, a32_2esst267, a32_2esst267_fifo, a32_2esst320, a32_2esst320_fifo |