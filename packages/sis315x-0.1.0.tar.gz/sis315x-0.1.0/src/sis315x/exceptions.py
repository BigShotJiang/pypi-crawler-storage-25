#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Function:
    Converts a SIS315x VME interface error code
    into a more readable error message.

Author:              CT
Date:                27.03.2026
Last modification:   27.03.2026

---------------------------------------------

SIS  Struck Innovative Systeme GmbH

Harksheider Str. 102A
22399 Hamburg

Tel. +49 (0)40 60 87 305 0

https://www.struck.de

© 2026
"""


class Sis315xUsbStatus(Exception):
    sis315x_status = [
        'Stat315xSuccess', # code: 0x0
        'Stat315xNullArgument',
        'Stat315xInvalidDeviceIndex',
        'Stat315xInvalidArgument',
        'Stat315xErrorDeviceOpen',
        'Stat315xErrorDeviceHold',
        'Stat315xErrorDeviceDownload',
        'Stat315xErrorDeviceRun',
        'Stat315xErrorDeviceClose',
        'Stat315xErrorSetInterface',
        'Stat315xErrorDescriptorOpen',
        'Stat315xErrorIo',
        'Stat315xErrorFileOpen',
        'Stat315xErrorFileAlloc',
        'Stat315xErrorPromId',
        'Stat315xErrorPromTimeout',
        'Stat315xErrorVfyAlloc',
        'Stat315xErrorVfyFailed',
    ]
    sis315x_local_status = [
        'Stat315xInvalidParameter', # code: 0x110
        'Stat315xUsbWriteError',
        'Stat315xUsbReadError,',
        'Stat315xUsbReadLengthError'
    ]
    sis315x_remote_status = [
        'Stat315xVmeBerr', # code: 0x211
        'Stat315xVmeRetry',
        'Stat315xVme',
        'Stat315xVmeArbitrationTimeout',
    ]

    def __init__(self, code=None, msg=None):
        self.msg = msg
        self.code = code

        if code != None:
            if code >= 0x200:
                self.type = 'Remote side error'
                self.disc = Sis315xUsbStatus.sis315x_remote_status[code - 0x211]
            elif code >= 0x100:
                self.type = 'Local side error'
                self.disc = Sis315xUsbStatus.sis315x_local_status[code - 0x110]
            elif code > 0x0:
                self.type = 'Internal error'
                self.disc = Sis315xUsbStatus.sis315x_status[code]
            else:
                self.code = None
                self.type = ''
                self.disc = ''
        else:
            self.type = ''
            self.disc = ''

        super().__init__(self.msg)

    def __str__(self):
        msg = ''
        if self.msg != None:
            msg += '[%s] %s' % (self.disc, self.msg) if self.code != None else '%s' % self.msg
        else:
            msg += '%s' % self.disc if self.code != None else ''
        return msg