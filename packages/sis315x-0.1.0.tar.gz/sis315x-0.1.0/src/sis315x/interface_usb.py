#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Function:
    Use the provided libraries for Windows and Linux 
    to access a SIS3153 VME interface device via USB.

Author:              CT
Date:                27.03.2026
Last modification:   27.03.2026

---------------------------------------------

SIS  Struck Innovative Systeme GmbH

Harksheider Str. 102A
22399 Hamburg

Tel. +49 (0)40 60 87 305 0

https://www.struck.de

© 2026
"""

import sys
from ctypes import *
from .exceptions import Sis315xUsbStatus


class Sis315xUsbDeviceStructWin(Structure):
    _fields_ = [
        ('hDev', c_void_p), 
        ('hUsb', c_void_p),
        ('cDName', c_char_p),
        ('readableName', c_char_p),
        ('VendID', c_uint16),
        ('ProdID', c_uint16),
        ('SerNo', c_uint16),
        ('DriverVer', c_uint16),
        ('FxFW', c_uint16),
        ('FPGAFW', c_uint16)
    ]
class Sis315xUsbLibVersionWin(Structure):
    _fields_ = [
         ('SisMajor', c_uint8),
         ('SisMinor', c_uint8),
    ]
    
class Sis315xUsbDeviceStructLinux(Structure):
    _fields_ = [
        ('cDName', c_char * 128), # Max length
        ('VendID', c_uint16),
        ('ProdID', c_uint16),
        ('SerNo', c_uint16),
        ('FPGAFW', c_uint16),
        ('hDev', c_void_p),
        ('pDeviceStruct', c_void_p)
    ]
class Sis315xUsbLibVersionLinux(Structure):
    _fields_ = [
         ('SisMajor', c_uint8),
         ('SisMinor', c_uint8),
         ('SisPatch', c_uint8)
    ]


class Sis315xUsb:
    def __init__(self):
        
        if sys.platform == 'win32':
            if sys.maxsize > 0x100000000:
                base = '64Bit'
                lib = 'sis3153w_x64.dll'
            else:
                base = '32Bit'
                lib = 'sis3153w.dll'
        elif sys.platform == 'linux':
            if sys.maxsize > 0x100000000:
                base = '64Bit'
                lib = 'libsis3150.so'
            else:
                base = '32Bit'
                lib = 'libsis3150.so'
        else:
            raise Sis315xUsbStatus(msg='OS \'%s\' is not supported!' % sys.platform)

        try:
            self.__lib = CDLL(lib)
        except FileNotFoundError as error:
            raise Sis315xUsbStatus(msg=error.__str__())

        self.__max_devices = 5
        self.__found_devices = 0
        self.__device_sel = 0
        
        if sys.platform == 'win32':
            self.__device_list = (Sis315xUsbDeviceStructWin * self.__max_devices)()
        else:
            self.__device_list = (Sis315xUsbDeviceStructLinux * self.__max_devices)()
    
        self.__device_open = [False] * self.__max_devices
        
    def get_lib_version(self):
        if sys.platform == 'win32':
            lib_ver = Sis315xUsbLibVersionWin()
            func = self.__lib.sis3153Usb_version
            func.argtypes = [POINTER(Sis315xUsbLibVersionWin)]
        else:
            lib_ver = Sis315xUsbLibVersionLinux()
            func = self.__lib.Sis3150usb_Version
            func.argtypes = [POINTER(Sis315xUsbLibVersionLinux)]
        func.restype = c_int32
        
        func(lib_ver)
        
        return {
            'os': 'linux' if sys.platform != 'win32' else 'win',
            'version': '%d.%d.%d' % (lib_ver.SisMajor, lib_ver.SisMinor, lib_ver.SisPatch if sys.platform != 'win32' else 0)
        }
    
    def get_device_info(self):
        return {
            'VendID': hex(self.__device_list[self.__device_sel].VendID),
            'ProdID': hex(self.__device_list[self.__device_sel].ProdID),
            'SerNo': self.__device_list[self.__device_sel].SerNo if self.__device_open[self.__device_sel] else 0,
            'FPGAFW': hex(self.__device_list[self.__device_sel].FPGAFW if self.__device_open[self.__device_sel] else 0)
        }

    def select_device(self, device_index = 0):
        if self.__found_devices <= device_index:
            raise Sis315xUsbStatus(msg='Device index %d out of range! Found: %d' % (device_index, self.__found_devices))
        
        self.__device_sel = device_index

    def find_all_devices(self):               
        if sys.platform == 'win32':
            func = self.__lib.FindAll_SIS3153USB_Devices
            func.argtypes = [POINTER(Sis315xUsbDeviceStructWin), POINTER(c_uint32), c_uint32]
        else:
            func = self.__lib.FindAll_SIS3150USB_Devices
            func.argtypes = [POINTER(Sis315xUsbDeviceStructLinux), POINTER(c_uint32), c_uint32]
        func.restype = c_int32
        
        nof_devices = c_uint32()

        ret = func(self.__device_list, nof_devices, self.__max_devices)
        if ret:
            raise Sis315xUsbStatus(ret)
        
        self.__found_devices = nof_devices.value
        return self.__found_devices

    def open(self):
        if self.__found_devices == 0:
            raise Sis315xUsbStatus(0x4, 'No active device connection detected')
            
        if sys.platform == 'win32':
            func = self.__lib.Sis3153usb_OpenDriver
            func.argtypes = [POINTER(Sis315xUsbDeviceStructWin)]
            func.restype = c_int32
            
            ret = func(self.__device_list[self.__device_sel])

        else:
            func = self.__lib.Sis3150usb_OpenDriver_And_Download_FX2_Setup
            func.argtypes = [POINTER(c_char), POINTER(Sis315xUsbDeviceStructLinux)]
            func.restype = c_int32
            
            ret = func(None, self.__device_list[self.__device_sel])

        if ret:
            raise Sis315xUsbStatus(ret, 'Can\'t open device on index %d' % self.__device_sel)
        self.__device_open[self.__device_sel] = True

    def close(self, device_index = 0):        
        if sys.platform == 'win32':
            func = self.__lib.Sis3153usb_CloseDriver
            func.argtypes = [POINTER(Sis315xUsbDeviceStructWin)]
            func.restype = c_int32
            ret = func(self.__device_list[self.__device_sel])
        else:
            func = self.__lib.Sis3150usb_CloseDriver
            func.argtypes = [c_void_p]
            func.restype = c_int32
            ret = func(self.__device_list[self.__device_sel].hDev)
        
        if ret:
            raise Sis315xUsbStatus(ret)
        
        self.__device_open[self.__device_sel] = False

    def read_register(self, addr):
        usbDevice = c_void_p
        
        if sys.platform == 'win32':
            func = self.__lib.sis3153Usb_Register_Single_Read
            usbDevice = self.__device_list[self.__device_sel].hUsb
        else:
            func = self.__lib.sis3150Usb_Register_Single_Read
            usbDevice = self.__device_list[self.__device_sel].hDev
        
        func.argtypes = [c_void_p, c_uint32, POINTER(c_uint32)]
        func.restype = c_int32
        
        data = c_uint32()    
        
        ret = func(usbDevice, addr, data)
        if ret:
            raise Sis315xUsbStatus(ret)

        return data.value
    
    def write_register(self, addr, data):
        usbDevice = c_void_p
        
        if sys.platform == 'win32':
            func = self.__lib.sis3153Usb_Register_Single_Write
            usbDevice = self.__device_list[self.__device_sel].hUsb
        else:
            func = self.__lib.sis3150Usb_Register_Single_Write
            usbDevice = self.__device_list[self.__device_sel].hDev
        
        func.argtypes = [c_void_p, c_uint32, c_uint32]
        func.restype = c_int32  
        
        ret = func(usbDevice, addr, data)
        if ret:
            raise Sis315xUsbStatus(ret)
        
    def read_register_dma(self, addr, req_nof_data):
        usbDevice = c_void_p
        
        if sys.platform == 'win32':
            func = self.__lib.sis3153Usb_Register_Dma_Read
            usbDevice = self.__device_list[self.__device_sel].hUsb
        else:
            func = self.__lib.sis3150Usb_Register_Dma_Read
            usbDevice = self.__device_list[self.__device_sel].hDev
        
        func.argtypes = [c_void_p, c_uint32, POINTER(c_uint32), c_uint32, POINTER(c_uint32)]
        func.restype = c_int32
        
        data = (c_uint32 * req_nof_data)()
        got_nof_data = c_uint32()
        
        ret = func(usbDevice, addr, data, req_nof_data, got_nof_data)
        if ret:
            raise Sis315xUsbStatus(ret)

        return data[:]
    
    def write_register_dma(self, addr, data):
        usbDevice = c_void_p
        
        if sys.platform == 'win32':
            func = self.__lib.sis3153Usb_Register_Dma_Write
            usbDevice = self.__device_list[self.__device_sel].hUsb
        else:
            func = self.__lib.sis3150Usb_Register_Dma_Write
            usbDevice = self.__device_list[self.__device_sel].hDev
        
        func.argtypes = [c_void_p, c_uint32, POINTER(c_uint32), c_uint32, POINTER(c_uint32)]
        func.restype = c_int32 
        
        tr_data = (c_uint32 * len(data))(*data)
        got_nof_data = c_uint32()
                
        ret = func(usbDevice, addr, tr_data, len(data), got_nof_data)
        if ret:
            raise Sis315xUsbStatus(ret)
        
    def read_vme(self, addr, am, size):
        usbDevice = c_void_p
        
        if sys.platform == 'win32':
            func = self.__lib.sis3153Usb_Vme_Single_Read
            usbDevice = self.__device_list[self.__device_sel].hUsb
        else:
            func = self.__lib.sis3150Usb_Vme_Single_Read
            usbDevice = self.__device_list[self.__device_sel].hDev
        
        func.argtypes = [c_void_p, c_uint32, c_uint32, c_uint32, POINTER(c_uint32)]
        func.restype = c_int32
        
        data = c_uint32()    
        
        ret = func(usbDevice, addr, am, size, data)
        if ret:
            raise Sis315xUsbStatus(ret)

        return data.value
    
    def write_vme(self, addr, am, size, data):
        usbDevice = c_void_p
        
        if sys.platform == 'win32':
            func = self.__lib.sis3153Usb_Vme_Single_Write
            usbDevice = self.__device_list[self.__device_sel].hUsb
        else:
            func = self.__lib.sis3150Usb_Vme_Single_Write
            usbDevice = self.__device_list[self.__device_sel].hDev
        
        func.argtypes = [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32]
        func.restype = c_int32  
        
        ret = func(usbDevice, addr, am, size, data)
        if ret:
            raise Sis315xUsbStatus(ret)
    
    def read_vme_dma(self, addr, am, size, fifo_mode, req_nof_data):
        usbDevice = c_void_p
        
        if sys.platform == 'win32':
            func = self.__lib.sis3153Usb_Vme_Dma_Read
            usbDevice = self.__device_list[self.__device_sel].hUsb
        else:
            func = self.__lib.sis3150Usb_Vme_Dma_Read
            usbDevice = self.__device_list[self.__device_sel].hDev
        
        func.argtypes = [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, POINTER(c_uint32), c_uint32, POINTER(c_uint32)]
        func.restype = c_int32
        
        data = (c_uint32 * req_nof_data)()
        got_nof_data = c_uint32()
        
        ret = func(usbDevice, addr, am, size, fifo_mode, data, req_nof_data, got_nof_data)
        if ret:
            raise Sis315xUsbStatus(ret)

        return data[:]
    
    def write_vme_dma(self, addr, am, size, fifo_mode, data):
        usbDevice = c_void_p
        
        if sys.platform == 'win32':
            func = self.__lib.sis3153Usb_Vme_Dma_Write
            usbDevice = self.__device_list[self.__device_sel].hUsb
        else:
            func = self.__lib.sis3150Usb_Vme_Dma_Write
            usbDevice = self.__device_list[self.__device_sel].hDev
        
        func.argtypes = [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, POINTER(c_uint32), c_uint32, POINTER(c_uint32)]
        func.restype = c_int32 
        
        tr_data = (c_uint32 * len(data))(*data)
        got_nof_data = c_uint32()
                
        ret = func(usbDevice, addr, am, size, fifo_mode, tr_data, len(data), got_nof_data)
        if ret:
            raise Sis315xUsbStatus(ret)
    
    def reset_vme_system(self):
        usbDevice = c_void_p
        
        if sys.platform == 'win32':
            func = self.__lib.sis3153Usb_VmeSysreset
            usbDevice = self.__device_list[self.__device_sel].hUsb
        else:
            func = self.__lib.sis3150Usb_VmeSysreset
            usbDevice = self.__device_list[self.__device_sel].hDev
        
        func.argtypes = [c_void_p]
        func.restype = c_int32 
  
        ret = func(usbDevice)
        if ret:
            raise Sis315xUsbStatus(ret)