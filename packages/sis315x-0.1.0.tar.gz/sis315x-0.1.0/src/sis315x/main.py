#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Function:
    Entry point for the SIS835x Python module.
    Provides functions for accessing local
    interface registers and VME resources.

Author:              CT
Date:                27.03.2026
Last modification:   27.03.2026

---------------------------------------------

SIS  Struck Innovative Systeme GmbH

Harksheider Str. 102A
22399 Hamburg

Tel. +49 (0)40 60 87 305 0

https://www.struck.de

© 2026
"""

from .version import __version__
from .interface_usb import Sis315xUsb, Sis315xUsbStatus


class Sis315xError(Exception):
    def __init__(self, iface, err=None, msg:str=None):
        self.iface = iface
        self.err = err
        self.msg = msg
        
        super().__init__(self.msg)
        
    def __str__(self):
        msg = ''
        if self.msg != None:
            msg += '[%s] %s' % (self.err.disc, self.msg) if self.err != None else '%s' % self.msg
        elif self.err != None:
            msg += '[%s - %s] %s' %(self.err.disc, hex(self.err.code), self.err.msg) if self.err.msg != None else '[%s - %s]' %(self.err.disc, hex(self.err.code))
            
        return msg


class Sis315x():
    
    vme_access_modes = [
        {'name': 'crcsr_d8',          'am': 0x02F, 'size': 1, 'dma': False, 'fifo': False},
        {'name': 'crcsr_d16',         'am': 0x02F, 'size': 2, 'dma': False, 'fifo': False},
        {'name': 'crcsr_d32',         'am': 0x02F, 'size': 4, 'dma': False, 'fifo': False},
        #----------------------------------------------------------------------------------
        {'name': 'a16_d8',            'am': 0x029, 'size': 1, 'dma': False, 'fifo': False},
        {'name': 'a16_d16',           'am': 0x029, 'size': 2, 'dma': False, 'fifo': False},
        {'name': 'a16_d32',           'am': 0x029, 'size': 4, 'dma': False, 'fifo': False},
        #----------------------------------------------------------------------------------
        {'name': 'a24_d8',            'am': 0x039, 'size': 1, 'dma': False, 'fifo': False},
        {'name': 'a24_d16',           'am': 0x039, 'size': 2, 'dma': False, 'fifo': False},
        {'name': 'a24_d32',           'am': 0x039, 'size': 4, 'dma': False, 'fifo': False},
        {'name': 'a24_blt32',         'am': 0x03B, 'size': 4, 'dma': True,  'fifo': False},
        {'name': 'a24_blt32_fifo',    'am': 0x03B, 'size': 4, 'dma': True,  'fifo': True },
        {'name': 'a24_blt64',         'am': 0x038, 'size': 8, 'dma': True,  'fifo': False},
        {'name': 'a24_blt64_fifo',    'am': 0x038, 'size': 8, 'dma': True,  'fifo': True },
        {'name': 'a24_d32_dma',       'am': 0x039, 'size': 4, 'dma': True,  'fifo': False},
        {'name': 'a24_d32_dma_fifo',  'am': 0x039, 'size': 4, 'dma': True,  'fifo': True },
        #----------------------------------------------------------------------------------
        {'name': 'a32_d8',            'am': 0x009, 'size': 1, 'dma': False, 'fifo': False},
        {'name': 'a32_d16',           'am': 0x009, 'size': 2, 'dma': False, 'fifo': False},
        {'name': 'a32_d32',           'am': 0x009, 'size': 4, 'dma': False, 'fifo': False},
        {'name': 'a32_blt32',         'am': 0x00B, 'size': 4, 'dma': True,  'fifo': False},
        {'name': 'a32_blt32_fifo',    'am': 0x00B, 'size': 4, 'dma': True,  'fifo': True },
        {'name': 'a32_blt64',         'am': 0x008, 'size': 8, 'dma': True,  'fifo': False},
        {'name': 'a32_blt64_fifo',    'am': 0x008, 'size': 8, 'dma': True,  'fifo': True },
        {'name': 'a32_d32_dma',       'am': 0x009, 'size': 4, 'dma': True,  'fifo': False},
        {'name': 'a32_d32_dma_fifo',  'am': 0x009, 'size': 4, 'dma': True,  'fifo': True },
        {'name': 'a32_2evme',         'am': 0x020, 'size': 8, 'dma': True,  'fifo': False},
        {'name': 'a32_2evme_fifo',    'am': 0x020, 'size': 8, 'dma': True,  'fifo': True },
        {'name': 'a32_2esst160',      'am': 0x060, 'size': 8, 'dma': True,  'fifo': False},
        {'name': 'a32_2esst160_fifo', 'am': 0x060, 'size': 8, 'dma': True,  'fifo': True },
        {'name': 'a32_2esst267',      'am': 0x160, 'size': 8, 'dma': True,  'fifo': False},
        {'name': 'a32_2esst267_fifo', 'am': 0x160, 'size': 8, 'dma': True,  'fifo': True },
        {'name': 'a32_2esst320',      'am': 0x260, 'size': 8, 'dma': True,  'fifo': False},
        {'name': 'a32_2esst320_fifo', 'am': 0x260, 'size': 8, 'dma': True,  'fifo': True },
        #----------------------------------------------------------------------------------
        {'name': 'iack_d8',           'am': 0x4000, 'size': 1, 'dma': False, 'fifo': False}
    ]
      
    def __init__(self, iface):
        if iface != 'usb' and iface != 'eth':
            raise Sis315xError('None', msg='Interface type \'%s\' is not supported (expected are \'usb\' or \'eth\')!' % iface)
        
        if iface == 'usb':
            # for USB interface
            self.__iface_type = 'usb'
            self.__device = Sis315xUsb()
            self.__nof_devices = self.__device.find_all_devices()
        
    def get_list_of_vme_modes(self):
        """Returns a list of all supportetd VME read/write modes
        """
        
        return [vme_access_mode['name'] for vme_access_mode in self.vme_access_modes]
    
    def get_version(self):
        """Returns a list of module and library/driver version information

        Returns:
            package: Version of the SIS315x python package
            lib: Version of the included library (Linux) / used driver (Windows)
        """
        
        ver = {}
        ver['package'] = __version__
        ver['lib'] = self.__device.get_lib_version()
        
        return ver
    
    def open(self):
        """Tries to open a handle for a interface
        """
        
        try:
            self.__device.open()
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e)
    
    def close(self):
        """Closes a previously opened interface handle
        """
        
        try:
            self.__device.close()
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e)
    
    def get_device_info(self):
        """Returns revision information of the opend interface

        Returns:
            type: Device ID (0x3150, 0x3153)
            serial_num: Device serial number
            fw_ver: FPGA firmware version
        """
        
        info = self.__device.get_device_info()
        
        return {
            'type': info['ProdID'],
            'serial_num': info['SerNo'],
            'fw_ver': info['FPGAFW']
        }
        
    
    def read_register(self, addr:int) -> int:
        """Reads from the interfaces internal control register space

        Args:
            addr (int): Register offset to read from
            
        Return:
            data (int): Read 32bit word
        """
        
        try:
            data = self.__device.read_register(addr)
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, e)
        
        return data
    
    def write_register(self, addr:int, data:int):
        """Writes to the interfaces internal register space

        Args:
            addr (int): Register offset to write to
            data (int): 32bit word to wirte
        """
        
        try:
            self.__device.write_register(addr, data)
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e)
        
    def read_register_dma(self, addr:int, req_nof_data:int) -> list:
        """Reads, using block transfer access, from internal register space of the interface

        Args:
            addr (int): Register offset to read from
            req_nof_data (nit): Requested number of 32bit word to read

        Returns:
            data (int list): Transferred 32bit words
        """
        try:
            data = self.__device.read_register_dma(addr, req_nof_data)
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, e)
        
        return data
        
    def write_register_dma(self, addr:int, data:list):
        """Writes, using block transfer access, to internal register space of the interface

        Args:
            addr (int): Register offset to write to
            data (int list): 32bit words to transferred
        """
        try:
            self.__device.write_register_dma(addr, data)
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e)
    
    def __read_vme(self, addr:int, am:int, size:int) -> int:
        """Reads, using single cycle access from VME address space
        Note: This is a general function definition. Several VME wrapper functions
        are provided based on this function. These functions allow access to the VME
        bus using standardized settings for mode and size.

        Args:
            addr (int): VME address offset
            am (int): VME address modifier
            size (int): Transfer size (1, 2, 4 or 8 bytes)

        Returns:
            data (int): Read data
        """
        
        try:
            data = self.__device.read_vme(addr, am, size)
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e)

        if size == 1:
            data &= 0xFF
        elif size == 2:
            data &= 0xFFFF
        
        return data
    
    def __write_vme(self, addr:int, am:int, size:int, data:int):
        """Writes, using single cycle access to VME address space
        Note: This is a general function definition. Several VME wrapper functions
        are provided based on this function. These functions allow access to the VME
        bus using standardized settings for mode and size.

        Args:
            addr (int): VME address offset
            am (int): VME address modifier
            size (int): Transfer size (1, 2, 4 or 8 bytes)
            data (int): Data to write
        """
        
        try:
            self.__device.write_vme(addr, am, size, data)
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e)

    def __read_vme_dma(self, addr:int, am:int, size:int, fifo_mode:bool, req_nof_data:int) -> list:
        """Reads, using block transfer access from VME address space
        Note: This is a general function definition. Several VME wrapper functions
        are provided based on this function. These functions allow access to the VME
        bus using standardized settings for mode, size and fifo_mode.

        Args:
            addr (int): VME address offset
            am (int): VME address modifier
            size (int): Transfer size (1, 2, 4 or 8 bytes)
            fifo_mode (bool): True = Keep VME address static
            req_nof_data (int): Requested number of 32bit word to read

        Returns:
           data (int list): Transferred 32bit words
        """
        
        if fifo_mode:
            fifo = 1
        else:
            fifo = 0
        
        try:
            data = self.__device.read_vme_dma(addr, am, size, fifo, req_nof_data)
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e)
        
        return data

    def __write_vme_dma(self, addr:int, am:int, size:int, fifo_mode:bool, data:list):
        """Writes, using block transfer access to VME address space.
        Note: This is a general function definition. Several VME wrapper functions
        are provided based on this function. These functions allow access to the VME
        bus using standardized settings for mode, size and fifo_mode.

        Args:
            addr (int): VME address offset
            am (int): VME address modifier
            size (int): Transfer size (1, 2, 4 or 8 bytes)
            fifo_mode (bool): True = Keep VME address static
            data (int list): 32bit words to transferred
        """
        
        if fifo_mode:
            fifo = 1
        else:
            fifo = 0
            
        try:
            self.__device.write_vme_dma(addr, am, size, fifo, data)
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e)
        
    def reset_vme_system(self):
        """Issues a 300ms Sysreset to the VME crate
        """
        
        try:
            self.__device.reset_vme_system()
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e)
        
    def read_vme(self, mode:str, addr:int, req_nof_data:int=1):
        """Reads, using the selected transfer mode from VME address space

        Args:
            mode (str): crcsr_d8', 'crcsr_d16', 'crcsr_d32',
                        'a16_d8', 'a16_d16', 'a16_d32',
                        'a24_d8', 'a24_d16', 'a24_d32', 'a24_blt32', 'a24_blt32_fifo', 'a24_blt64', 'a24_blt64_fifo', 'a24_d32_dma', 'a24_d32_dam_fifo',
                        'a32_d8', 'a32_d16', 'a32_d32', 'a32_blt32', 'a32_blt32_fifo', 'a32_blt64', 'a32_blt64_fifo', 'a32_d32_dma', 'a32_d32_dma_fifo',
                        'a32_2evme', 'a32_2evme_fifo', 'a32_2esst160', 'a32_2esst160_fifo', 'a32_2esst267', 'a32_2esst267_fifo', 'a32_2esst320', 'a32_2esst320_fifo'
            addr (int): VME address offset
            req_nof_data (int, optional): Requested number of 32bit word to read. Defaults to 1.

        Returns:
            int or list: Read data
        """
        
        access_mode = next((vme_access_mode for vme_access_mode in self.vme_access_modes if vme_access_mode['name'] == mode), None)
        if access_mode == None:
            raise Sis315xError(self.__iface_type, msg='VME access mode \'%s\' is not supported' % mode)
        
        try:
            if access_mode['dma']:
                return self.__read_vme_dma(addr, access_mode['am'], access_mode['size'], access_mode['fifo'], req_nof_data)
            else:
                return self.__read_vme(addr, access_mode['am'], access_mode['size'])
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e)

    def write_vme(self, mode:str, addr:int, data):
        """Writes, using the selected transfer mode to VME address space

        Args:
            mode (str): crcsr_d8', 'crcsr_d16', 'crcsr_d32',
                        'a16_d8', 'a16_d16', 'a16_d32',
                        'a24_d8', 'a24_d16', 'a24_d32', 'a24_blt32', 'a24_blt32_fifo', 'a24_blt64', 'a24_blt64_fifo', 'a24_d32_dma', 'a24_d32_dam_fifo',
                        'a32_d8', 'a32_d16', 'a32_d32', 'a32_blt32', 'a32_blt32_fifo', 'a32_blt64', 'a32_blt64_fifo', 'a32_d32_dma', 'a32_d32_dma_fifo',
                        'a32_2evme', 'a32_2evme_fifo', 'a32_2esst160', 'a32_2esst160_fifo', 'a32_2esst267', 'a32_2esst267_fifo', 'a32_2esst320', 'a32_2esst320_fifo',
            addr (int): VME address offset
            data (int or list): _description_
        """
        
        access_mode = next((vme_access_mode for vme_access_mode in self.vme_access_modes if vme_access_mode['name'] == mode), None)
        if access_mode == None:
            raise Sis315xError(self.__iface_type, 'VME access mode \'%s\' is not supported' % mode)
        
        try:
            if access_mode['dma']:
                if type(data) != list:
                    raise Sis315xError(self.__iface_type, msg='write_vme_dma expects list of int')
                    
                self.__write_vme_dma(addr, access_mode['am'], access_mode['size'], access_mode['fifo'], data)
            else:
                self.__write_vme(addr, access_mode['am'], access_mode['size'], data)
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e) 
            
    def read_iack(self, vme_irq_level:int):
        """Performs a interrupt acknowledge cycle (IACK cycle) and returns the interrupt vector
        
        Args:
            vme_irq_level (int): VME IRQ level (1 - 7)
        
        Returns:
            int: VME interrupt vector
        """
        
        if (vme_irq_level < 1) or (vme_irq_level > 7):
            raise Sis315xError(self.__iface_type, msg='vme_irq_level is out of range (1 - 7): %d' % vme_irq_level)
        
        try:
            return self.__read_vme((vme_irq_level << 1) + 1, 0x4000, 1)
        except Sis315xUsbStatus as e:
            raise Sis315xError(self.__iface_type, err=e)