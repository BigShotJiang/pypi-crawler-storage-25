#!/usr/bin/env python

from .main import Sis315x, Sis315xError