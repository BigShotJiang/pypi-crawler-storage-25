#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Function:
    This sample application shows how to access the VME bus
    via a SIS315x VME interface using Python.
    A second example (base-test.py) illustrates how to
    access the device's local registers.
    

Author:              CT
Date:                01.04.2026
Last modification:   01.04.2026

---------------------------------------------

SIS  Struck Innovative Systeme GmbH

Harksheider Str. 102A
22399 Hamburg

Tel. +49 (0)40 60 87 305 0

https://www.struck.de

© 2026
"""

from sis315x import Sis315x, Sis315xError


interface = Sis315x('usb')
version = interface.get_version()
print('Python package version: %s' % version['package'])
print()

try:
    interface.open()
except Sis315xError as e:
    print(e)
    exit()

interface.reset_vme_system()

vme_base_addr = 0x41000000

print('* Single cycle vme read/write...')
# D32 Litle endien -> Bit 0 = MSB
interface.write_vme('a32_d32', vme_base_addr+ 0x0, 0x11223344)

print(' Read A32-D8..')
print(' ',hex(interface.read_vme('a32_d8', vme_base_addr + 0x0)))
print(' ',hex(interface.read_vme('a32_d8', vme_base_addr + 0x1)))
print(' ',hex(interface.read_vme('a32_d8', vme_base_addr + 0x2)))
print(' ',hex(interface.read_vme('a32_d8', vme_base_addr + 0x3)))
print()

print(' Read A32-D16..')
print(' ',hex(interface.read_vme('a32_d16', vme_base_addr + 0x0)))
print(' ',hex(interface.read_vme('a32_d16', vme_base_addr + 0x2)))
print()

print(' Read A32-D32..')
print(' ',hex(interface.read_vme('a32_d32', vme_base_addr + 0x0)))
print()


print('* DMA cycle vme read/write...')
mem_size = 0x2000000 # 32MByte
#mem_size = 0x100000  #  1MByte
#mem_size = 0x400     #  1kByte

print(' Write A32-BLT32..')
wr_data = list(range(0, int(mem_size/4-1)))
interface.write_vme('a32_blt32', vme_base_addr + 0x0, wr_data)

print(' Read A32-BLT32..')
rd_data = interface.read_vme('a32_blt32', vme_base_addr + 0x0, len(wr_data))

print(' Compare written and read data.. ', end='')
for i in range(0, int(mem_size/4-1)):
    if wr_data[i] != rd_data[i]:
        raise Exception('epx.: %s - red.: %s' % (hex(wr_data[i]), hex(rd_data[i])))
print('okay')
interface.close()