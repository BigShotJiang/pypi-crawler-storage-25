#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Function:
    This example application shows how to access the
    local registers of a SIS315x VME interface using Python.
    The second example (vme-test.py) illustrates how to use
    the device to access the VME bus.

Author:              CT
Date:                01.04.2026
Last modification:   01.04.2026

---------------------------------------------

SIS  Struck Innovative Systeme GmbH

Harksheider Str. 102A
22399 Hamburg

Tel. +49 (0)40 60 87 305 0

https://www.struck.de

© 2026
"""

from time import sleep
from sis315x import Sis315x, Sis315xError

print(' *** SIS315x base test ***')
print()

interface = Sis315x('usb')
versions = interface.get_version()
print('Driver version:          %s' % versions['lib']['version'])
print('Python package version:  %s' % versions['package'])
print()

try:
    interface.open()
except Sis315xError as e:
    print(e)
    exit()

print('Device:')
type_fwv = interface.read_register(0x1)
sn = interface.read_register(0x2)
print('  Type:                  %s' % ('SIS3153' if (type_fwv>>16)==0x3153 else 'SIS3150'))
print('  Serial number:         %s' % str(sn&0xFFFF) if not sn&0x10000 else 'not valid')
print('  Firmware version:      %s' % hex(type_fwv&0xFFFF))
print()

print('Start LED test for 5sec...')
interface.write_register(0x0, 0x2)
sleep(5)

print('LED test stoped')
interface.write_register(0x0, 0x20000)
print()

print('Toggle Led A for 5 times...')
interface.write_register(0x0, 0x10000)

for i in range(0, 5):
    interface.write_register(0x0, 0x1)
    sleep(0.5)
    interface.write_register(0x0, 0x10000)
    sleep(0.5)
print()

interface.close()