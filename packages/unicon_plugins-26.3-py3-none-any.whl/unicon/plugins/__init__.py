__version__ = "26.3"

supported_chassis = [
    'single_rp',
    'dual_rp',
    'stack',
    'quad',
    'stackwise_virtual'
]

supported_os = [
    'aci',
    'aireos',
    'apic',
    'asa',
    'cheetah',
    'cimc',
    'comware',
    'confd',
    'dnos6',
    'dnos10',
    'eos',
    'fxos',
    'gaia',
    'generic',
    'hvrp',
    'ios',
    'iosxe',
    'iosxr',
    'ironware',
    'ise',
    'junos',
    'linux',
    'nd',
    'nso',
    'nxos',
    'ons',
    'sdwan',
    'slxos',
    'sonic',
    'sros',
    'staros',
    'viptela',
    'vos',
    'windows'
]
