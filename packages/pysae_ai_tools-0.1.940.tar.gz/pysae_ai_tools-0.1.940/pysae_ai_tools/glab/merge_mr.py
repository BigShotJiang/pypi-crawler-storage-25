"""Merge a GitLab merge request, handling every ``detailed_merge_status``.

Centralises the dispatch logic that used to live in the ``glab-mr-merge``
SKILL.md prose: inspects the MR via ``glab``, applies auto-fixes (flip draft
to ready, short-poll transient states), and otherwise reports back to the
caller — either as a plain text summary (default) or as a JSON payload
(``--json``) consumable by the Claude skill.

The script delegates two kinds of fixes to the calling skill rather than
performing them itself:
  * ``conflict`` / ``requires_rebase`` / ``need_rebase`` → ``/glab-mr-rebase``;
  * ``ci_must_pass`` / ``ci_still_running`` and pipeline-gated transients
    when a pipeline is running → ``/ci-run``.

In those cases the script exits with ``status="needs_skill"``, naming the
skill and the arguments to pass. The caller invokes the sub-skill, then
re-runs ``pysae-ai-tools glab merge-mr <IID>`` to resume.

Usage:
    pysae-ai-tools glab merge-mr <IID> [--json]
"""

import json
import re
import subprocess
import sys
import time
from dataclasses import dataclass, field
from typing import Annotated, Any, Literal, Self

import typer

# This script never invokes the high-level `glab mr ...` subcommands —
# they have been observed to inject body fields the GitLab API rejects
# (e.g. 405 on `glab mr merge`). Every MR mutation goes through
# `glab api -X <METHOD> projects/<id>/merge_requests/<iid>[/merge]`,
# letting the server fall back to its project-level defaults.

_REMOTE_RE = re.compile(r"gitlab\.com[:/](.+?)(?:\.git)?/?$")

# Fix loop only protects against runaway auto-fixes (draft flip → re-fetch …).
# Pipeline / CI waits go through their own dedicated polling and are not
# bound by this cap.
AUTO_FIX_CAP = 10

# Short-poll cap for transient states that should resolve in seconds
# (preparing / approvals_syncing / cannot_be_merged_rechecking).
SHORT_POLL_ATTEMPTS = 6
SHORT_POLL_INTERVAL_S = 5

# Long-poll cap for transient states with no active pipeline (checking /
# unchecked falling through to the silent fallback). The pipeline-aware
# branch escalates to /ci-run instead, so this only fires on edge cases.
LONG_POLL_ATTEMPTS = 60
LONG_POLL_INTERVAL_S = 30

PIPELINE_RUNNING_STATES = {"running", "pending", "created", "manual"}

REBASE_STATUSES = {"conflict", "requires_rebase", "need_rebase"}
CI_STATUSES = {"ci_must_pass", "ci_still_running"}
LONG_TRANSIENT = {"checking", "unchecked"}
SHORT_TRANSIENT = {"preparing", "approvals_syncing", "cannot_be_merged_rechecking"}

HARD_BLOCKERS = {
    "not_open",
    "not_approved",
    "discussions_not_resolved",
    "external_status_checks",
    "jira_association_missing",
    "requested_changes",
    "policies_denied",
    "commits_status",
    "blocked_status",
    "merge_request_blocked",
    "cannot_be_merged",
    "cannot_be_merged_recheck",
}

OutcomeStatus = Literal["merged", "blocked", "needs_skill", "error"]


@dataclass
class MergeOutcome:
    """Final result of a merge attempt."""

    status: OutcomeStatus
    mr_iid: int
    mr_url: str = ""
    detailed_merge_status: str = ""
    # status == "merged"
    sha: str = ""
    issue_transitioned: str = ""
    # status == "needs_skill"
    skill: str = ""
    skill_args: list[str] = field(default_factory=list)
    # status == "blocked" / "error"
    blocker: str = ""
    message: str = ""

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "status": self.status,
            "mr_iid": self.mr_iid,
            "mr_url": self.mr_url,
            "detailed_merge_status": self.detailed_merge_status,
        }
        if self.status == "merged":
            out["sha"] = self.sha
            out["issue_transitioned"] = self.issue_transitioned
        elif self.status == "needs_skill":
            out["skill"] = self.skill
            out["skill_args"] = self.skill_args
        elif self.status in ("blocked", "error"):
            out["blocker"] = self.blocker
            out["message"] = self.message
        return out

    def to_text(self) -> str:
        url = self.mr_url or f"!{self.mr_iid}"
        if self.status == "merged":
            line = f"✓ MR mergée : {url} ({self.sha[:8]})"
            if self.issue_transitioned:
                line += f" — {self.issue_transitioned}"
            return line
        if self.status == "needs_skill":
            args = " ".join(self.skill_args) if self.skill_args else ""
            return f"⤴ MR {url} : statut {self.detailed_merge_status} — " f"déléguer à /{self.skill} {args}".rstrip()
        if self.status == "blocked":
            extra = f" — {self.message}" if self.message else ""
            return f"✗ MR {url} : bloquée ({self.blocker}){extra}"
        return f"✗ MR {url} : erreur — {self.message}"


# ---------------------------------------------------------------------------
# Subprocess helpers
# ---------------------------------------------------------------------------


@dataclass
class GlabResult:
    returncode: int
    stdout: str
    stderr: str


def _run_glab(*args: str, timeout: int = 30) -> GlabResult:
    """Run a glab command, capturing stdout/stderr."""
    try:
        result = subprocess.run(
            ["glab", *args],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            stdin=subprocess.DEVNULL,
        )
        return GlabResult(result.returncode, result.stdout, result.stderr)
    except FileNotFoundError:
        return GlabResult(127, "", "glab CLI not found")
    except subprocess.TimeoutExpired:
        return GlabResult(124, "", f"glab timed out after {timeout}s")


def _glab_api(method: str, path: str, *form: str) -> GlabResult:
    """Call ``glab api -X <method> <path>`` with optional ``-f key=value`` body."""
    args = ["api", "-X", method, path]
    for kv in form:
        args.extend(["-f", kv])
    return _run_glab(*args)


def _resolve_project_path() -> str:
    """Resolve the GitLab project path (``group/repo``) from the CWD's git remote.

    Reading ``git remote get-url origin`` is the only non-API call we make:
    every subsequent GitLab interaction goes through ``glab api`` so we can
    bypass the buggy higher-level wrappers entirely.
    """
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=5,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return ""
    if result.returncode != 0:
        return ""
    match = _REMOTE_RE.search((result.stdout or "").strip())
    return match.group(1) if match else ""


def _project_path_encoded(project_path: str) -> str:
    return project_path.replace("/", "%2F")


# ---------------------------------------------------------------------------
# MR inspection
# ---------------------------------------------------------------------------


@dataclass
class MRSnapshot:
    iid: int
    web_url: str
    detailed_merge_status: str
    pipeline_status: str
    project_path: str
    issue_iid: str  # closed by this MR via "Closes #N"

    @classmethod
    def from_json(cls, raw: dict[str, Any]) -> Self:
        pipeline = raw.get("head_pipeline") or raw.get("pipeline") or {}
        web_url = raw.get("web_url", "") or ""
        project_path = ""
        if "/-/merge_requests/" in web_url:
            tail = web_url.split("/-/merge_requests/", 1)[0]
            for prefix in ("https://gitlab.com/", "http://gitlab.com/"):
                if tail.startswith(prefix):
                    project_path = tail[len(prefix) :]
                    break
        # Issue closed by this MR (best-effort: look for "Closes #N" in description).
        issue_iid = ""
        description = raw.get("description") or ""
        for token in description.split():
            stripped = token.strip(".,;:()")
            if stripped.startswith("#") and stripped[1:].isdigit():
                issue_iid = stripped[1:]
                break
        return cls(
            iid=int(raw.get("iid", 0)),
            web_url=web_url,
            detailed_merge_status=str(raw.get("detailed_merge_status", "") or ""),
            pipeline_status=str(pipeline.get("status", "") or ""),
            project_path=project_path,
            issue_iid=issue_iid,
        )


def _fetch_mr(project_path: str, iid: int) -> MRSnapshot | None:
    """Fetch the MR JSON via ``glab api projects/<id>/merge_requests/<iid>``."""
    if not project_path:
        return None
    res = _glab_api("GET", f"projects/{_project_path_encoded(project_path)}/merge_requests/{iid}")
    if res.returncode != 0:
        return None
    try:
        return MRSnapshot.from_json(json.loads(res.stdout))
    except (json.JSONDecodeError, ValueError, TypeError):
        return None


# ---------------------------------------------------------------------------
# Auto-fixes
# ---------------------------------------------------------------------------


def _flip_draft_to_ready(snap: MRSnapshot) -> bool:
    """Mark the MR as ready by setting ``draft=false`` via the Update API.

    Modern GitLab (16+) exposes ``draft`` as a real boolean parameter on
    ``PUT /projects/:id/merge_requests/:iid`` — no need to manipulate the
    title prefix anymore.
    """
    res = _glab_api(
        "PUT",
        f"projects/{_project_path_encoded(snap.project_path)}/merge_requests/{snap.iid}",
        "draft=false",
    )
    return res.returncode == 0


def _short_poll(project_path: str, iid: int) -> str:
    """Poll for SHORT_POLL_ATTEMPTS × SHORT_POLL_INTERVAL_S, return final status."""
    last = ""
    for _ in range(SHORT_POLL_ATTEMPTS):
        time.sleep(SHORT_POLL_INTERVAL_S)
        snap = _fetch_mr(project_path, iid)
        if snap is None:
            return ""
        last = snap.detailed_merge_status
        if last not in SHORT_TRANSIENT:
            return last
    return last


def _long_poll(project_path: str, iid: int) -> str:
    """Silent fallback poll for LONG_TRANSIENT states with no active pipeline."""
    last = ""
    for _ in range(LONG_POLL_ATTEMPTS):
        time.sleep(LONG_POLL_INTERVAL_S)
        snap = _fetch_mr(project_path, iid)
        if snap is None:
            return ""
        last = snap.detailed_merge_status
        if last not in LONG_TRANSIENT:
            return last
    return last


# ---------------------------------------------------------------------------
# Merge step
# ---------------------------------------------------------------------------


def _merge(snap: MRSnapshot) -> tuple[bool, str, str]:
    """Merge the MR via the raw API (``PUT projects/<id>/merge_requests/<iid>/merge``).

    No body — let GitLab apply the project-level defaults (``squash_option``,
    ``remove_source_branch_after_merge``, …). The high-level ``glab mr merge``
    is intentionally never used: it injects body fields the server
    sometimes rejects with 405 even on otherwise-mergeable MRs.

    Returns ``(merged, sha, error_message)``.
    """
    res = _glab_api(
        "PUT",
        f"projects/{_project_path_encoded(snap.project_path)}/merge_requests/{snap.iid}/merge",
    )
    if res.returncode != 0:
        return False, "", (res.stderr or "").strip()
    try:
        data = json.loads(res.stdout) if res.stdout.strip() else {}
        sha = str(data.get("merge_commit_sha") or data.get("squash_commit_sha") or "")
    except json.JSONDecodeError:
        sha = ""
    return True, sha, ""


# ---------------------------------------------------------------------------
# Issue transition
# ---------------------------------------------------------------------------


def _transition_linked_issue(snap: MRSnapshot) -> str:
    """Move the linked issue to ``workflow::To deploy``.

    Returns a human-readable summary suitable for the success report
    (e.g. ``#123 → workflow::To deploy``), or empty when no linked issue
    is detected or the transition fails.
    """
    if not snap.issue_iid:
        return ""
    from .workflow_transition import transition

    result = transition(snap.issue_iid, "workflow::To deploy")
    if result.startswith("set:"):
        return f"#{snap.issue_iid} → workflow::To deploy"
    return ""


# ---------------------------------------------------------------------------
# Main dispatch loop
# ---------------------------------------------------------------------------


def _classify(status: str) -> str:
    """Map a detailed_merge_status to a coarse category for dispatch."""
    if status == "mergeable":
        return "mergeable"
    if status == "draft_status":
        return "draft"
    if status in REBASE_STATUSES:
        return "needs_rebase"
    if status in CI_STATUSES:
        return "needs_ci"
    if status in LONG_TRANSIENT:
        return "transient_long"
    if status in SHORT_TRANSIENT:
        return "transient_short"
    if status in HARD_BLOCKERS:
        return "blocker"
    return "unknown"


def merge_mr(iid: int) -> MergeOutcome:
    """Run the full dispatch loop for ``iid`` and return the outcome."""
    project_path = _resolve_project_path()
    if not project_path:
        return MergeOutcome(
            status="error",
            mr_iid=iid,
            blocker="no_project_path",
            message="impossible de résoudre le chemin du projet via `git remote get-url origin`",
        )

    for _ in range(AUTO_FIX_CAP):
        snap = _fetch_mr(project_path, iid)
        if snap is None:
            return MergeOutcome(
                status="error",
                mr_iid=iid,
                blocker="fetch_failed",
                message=f"impossible de récupérer la MR !{iid} via l'API GitLab",
            )

        category = _classify(snap.detailed_merge_status)

        if category == "mergeable":
            merged, sha, err = _merge(snap)
            if not merged:
                return MergeOutcome(
                    status="error",
                    mr_iid=iid,
                    mr_url=snap.web_url,
                    detailed_merge_status=snap.detailed_merge_status,
                    blocker="merge_failed",
                    message=err or "PUT /merge_requests/<iid>/merge a échoué",
                )
            issue_transitioned = _transition_linked_issue(snap)
            return MergeOutcome(
                status="merged",
                mr_iid=iid,
                mr_url=snap.web_url,
                detailed_merge_status=snap.detailed_merge_status,
                sha=sha,
                issue_transitioned=issue_transitioned,
            )

        if category == "draft":
            if not _flip_draft_to_ready(snap):
                return MergeOutcome(
                    status="error",
                    mr_iid=iid,
                    mr_url=snap.web_url,
                    detailed_merge_status=snap.detailed_merge_status,
                    blocker="draft_flip_failed",
                    message="PUT du nouveau titre (sans préfixe Draft:) a échoué",
                )
            continue  # re-fetch

        if category == "needs_rebase":
            return MergeOutcome(
                status="needs_skill",
                mr_iid=iid,
                mr_url=snap.web_url,
                detailed_merge_status=snap.detailed_merge_status,
                skill="glab-mr-rebase",
                skill_args=[f"!{iid}"],
            )

        if category == "needs_ci":
            return MergeOutcome(
                status="needs_skill",
                mr_iid=iid,
                mr_url=snap.web_url,
                detailed_merge_status=snap.detailed_merge_status,
                skill="ci-run",
                skill_args=["start"],
            )

        if category == "transient_long":
            if snap.pipeline_status in PIPELINE_RUNNING_STATES:
                return MergeOutcome(
                    status="needs_skill",
                    mr_iid=iid,
                    mr_url=snap.web_url,
                    detailed_merge_status=snap.detailed_merge_status,
                    skill="ci-run",
                    skill_args=["start"],
                )
            new_status = _long_poll(project_path, iid)
            if new_status in LONG_TRANSIENT or not new_status:
                return MergeOutcome(
                    status="blocked",
                    mr_iid=iid,
                    mr_url=snap.web_url,
                    detailed_merge_status=new_status or snap.detailed_merge_status,
                    blocker="transient_timeout",
                    message=(
                        f"statut encore {snap.detailed_merge_status} "
                        f"après {LONG_POLL_ATTEMPTS * LONG_POLL_INTERVAL_S // 60} min"
                    ),
                )
            continue  # re-classify with new status

        if category == "transient_short":
            new_status = _short_poll(project_path, iid)
            if new_status in SHORT_TRANSIENT or not new_status:
                return MergeOutcome(
                    status="blocked",
                    mr_iid=iid,
                    mr_url=snap.web_url,
                    detailed_merge_status=new_status or snap.detailed_merge_status,
                    blocker=snap.detailed_merge_status,
                    message=(
                        f"statut encore {snap.detailed_merge_status} après "
                        f"{SHORT_POLL_ATTEMPTS * SHORT_POLL_INTERVAL_S} s"
                    ),
                )
            continue  # re-classify

        if category == "blocker":
            return MergeOutcome(
                status="blocked",
                mr_iid=iid,
                mr_url=snap.web_url,
                detailed_merge_status=snap.detailed_merge_status,
                blocker=snap.detailed_merge_status,
            )

        # Unknown status — never assume mergeability.
        return MergeOutcome(
            status="blocked",
            mr_iid=iid,
            mr_url=snap.web_url,
            detailed_merge_status=snap.detailed_merge_status,
            blocker="unknown_status",
            message=(f"detailed_merge_status='{snap.detailed_merge_status}' inconnu — " "vérifier manuellement la MR"),
        )

    return MergeOutcome(
        status="error",
        mr_iid=iid,
        blocker="auto_fix_loop_exceeded",
        message=f"plus de {AUTO_FIX_CAP} itérations d'auto-fix sans atteindre mergeable",
    )


# ---------------------------------------------------------------------------
# Typer entry
# ---------------------------------------------------------------------------


def main(
    iid: Annotated[int, typer.Argument(help="MR IID to merge (e.g. 2445)")],
    as_json: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Emit the outcome as a JSON object on stdout (for skill consumption).",
        ),
    ] = False,
) -> None:
    """Merge a GitLab merge request, handling every detailed_merge_status.

    Default output is human-readable; pass ``--json`` for a structured payload.
    Exit code is ``0`` on ``merged``, ``2`` on ``needs_skill`` (caller must
    invoke the named skill and re-run), ``1`` otherwise.
    """
    outcome = merge_mr(iid)
    if as_json:
        json.dump(outcome.to_dict(), sys.stdout, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        typer.echo(outcome.to_text())

    if outcome.status == "merged":
        return
    if outcome.status == "needs_skill":
        raise typer.Exit(code=2)
    raise typer.Exit(code=1)
