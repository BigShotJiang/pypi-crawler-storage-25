"""Tests for slowai.hardware — Jetson SKU detection and DLA gating.

V9 P0: SKU matching, DLA gating, detection chain.
V10 P0: Multi-source detection (BoardID > compatible > model), --force-sku,
    container-aware fallback. Grok demanded we stop relying on a single
    unreliable source (/proc/device-tree/model).
"""

import os
import pytest
from unittest.mock import patch, MagicMock

from slowai.hardware import (
    JetsonInfo,
    JetsonSKU,
    DLANotAvailableError,
    detect_jetson,
    require_dla,
    format_hardware_report,
    list_force_sku_aliases,
    _match_sku,
    _match_board_sku,
    _extract_board_id_from_compatible,
    _BOARD_SKU_MAP,
    _FORCE_SKU_ALIASES,
)


# ---------------------------------------------------------------------------
# SKU matching tests (keyword-based, V9 carry-forward)
# ---------------------------------------------------------------------------

class TestSKUMatching:
    """Test that model strings map to the correct SKU."""

    def test_orin_nano_super(self):
        sku = _match_sku("nvidia orin nano super developer kit")
        assert sku is not None
        assert sku.name == "Jetson Orin Nano Super"
        assert sku.dla_cores == 0
        assert sku.series == "orin_nano"

    def test_orin_nano_8gb(self):
        sku = _match_sku("nvidia jetson orin nano 8gb")
        assert sku is not None
        assert sku.dla_cores == 0
        assert sku.series == "orin_nano"

    def test_orin_nano_4gb(self):
        sku = _match_sku("nvidia jetson orin nano 4gb module")
        assert sku is not None
        assert sku.dla_cores == 0
        assert sku.gpu_cores == 512

    def test_orin_nano_generic(self):
        """Unknown Orin Nano variant still gets zero DLA."""
        sku = _match_sku("jetson orin nano something new")
        assert sku is not None
        assert sku.dla_cores == 0

    def test_orin_nx_16gb(self):
        sku = _match_sku("nvidia jetson orin nx 16gb")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.series == "orin_nx"

    def test_orin_nx_8gb(self):
        sku = _match_sku("nvidia jetson orin nx 8gb")
        assert sku is not None
        assert sku.dla_cores == 1  # NX 8GB has only 1 DLA core

    def test_orin_nx_super(self):
        sku = _match_sku("nvidia jetson orin nx super")
        assert sku is not None
        assert sku.dla_cores == 2

    def test_agx_orin_64gb(self):
        sku = _match_sku("nvidia jetson agx orin 64gb developer kit")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.unified_memory_gb == 64.0

    def test_agx_orin_32gb(self):
        sku = _match_sku("nvidia jetson agx orin developer kit")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.series == "agx_orin"

    def test_agx_xavier(self):
        sku = _match_sku("nvidia jetson agx xavier developer kit")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.series == "agx_xavier"

    def test_xavier_nx(self):
        sku = _match_sku("nvidia xavier nx developer kit")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.series == "xavier_nx"

    def test_unknown_model_returns_none(self):
        sku = _match_sku("some random desktop computer")
        assert sku is None

    def test_thor(self):
        sku = _match_sku("nvidia jetson thor")
        assert sku is not None
        assert sku.dla_cores == 2
        assert sku.series == "thor"

    def test_specificity_ordering(self):
        """Orin Nano Super matches before generic Orin Nano."""
        super_sku = _match_sku("orin nano super")
        generic_sku = _match_sku("orin nano developer kit")
        assert super_sku is not None
        assert generic_sku is not None
        assert super_sku.name == "Jetson Orin Nano Super"
        assert super_sku.max_power_watts == 25
        assert generic_sku.max_power_watts == 15

    def test_real_device_string_fuzzy_match(self):
        """Real Jetson model string with extra words between key identifiers."""
        sku = _match_sku("nvidia jetson orin nano engineering reference developer kit super")
        assert sku is not None
        assert sku.name == "Jetson Orin Nano Super"


# ---------------------------------------------------------------------------
# V10: BoardID-based matching tests
# ---------------------------------------------------------------------------

class TestBoardSKUMatching:
    """Test the stable BoardID matching path (V10 primary)."""

    def test_orin_nano_super_board_id(self):
        sku = _match_board_sku("3767", "0005")
        assert sku is not None
        assert sku.name == "Jetson Orin Nano Super"
        assert sku.dla_cores == 0

    def test_orin_nano_8gb_board_id(self):
        sku = _match_board_sku("3767", "0003")
        assert sku is not None
        assert sku.name == "Jetson Orin Nano 8GB"
        assert sku.dla_cores == 0

    def test_orin_nano_4gb_board_id(self):
        sku = _match_board_sku("3767", "0004")
        assert sku is not None
        assert sku.name == "Jetson Orin Nano 4GB"

    def test_orin_nx_16gb_board_id(self):
        sku = _match_board_sku("3767", "0000")
        assert sku is not None
        assert sku.name == "Jetson Orin NX 16GB"
        assert sku.dla_cores == 2

    def test_orin_nx_8gb_board_id(self):
        sku = _match_board_sku("3767", "0001")
        assert sku is not None
        assert sku.name == "Jetson Orin NX 8GB"
        assert sku.dla_cores == 1

    def test_agx_orin_32gb_board_id(self):
        sku = _match_board_sku("3509", "0000")
        assert sku is not None
        assert sku.name == "Jetson AGX Orin 32GB"

    def test_agx_orin_64gb_board_id(self):
        sku = _match_board_sku("3509", "0004")
        assert sku is not None
        assert sku.name == "Jetson AGX Orin 64GB"

    def test_unknown_board_id_returns_none(self):
        sku = _match_board_sku("9999", "9999")
        assert sku is None

    def test_board_map_populated(self):
        """Ensure the board map has entries."""
        assert len(_BOARD_SKU_MAP) >= 7


class TestExtractBoardFromCompatible:
    """Test extracting BoardID from compatible string.

    V10 P1: Returns list of ALL board pairs, not just first match.
    Field testing showed carrier board (3768) appearing before module (3767).
    """

    def test_standard_compatible_returns_all_pairs(self):
        """P1 regression: must find module ID even when carrier appears first."""
        pairs = _extract_board_id_from_compatible(
            "nvidia,p3767-0005+p3768-0000 nvidia,p3767-0005 nvidia,tegra234"
        )
        assert len(pairs) >= 2
        assert ("3767", "0005") in pairs
        assert ("3768", "0000") in pairs

    def test_carrier_first_module_second(self):
        """P1 field bug: carrier board 3768-0000 appeared before module 3767-0005."""
        pairs = _extract_board_id_from_compatible(
            "nvidia,p3768-0000+p3767-0005 nvidia,tegra234"
        )
        assert len(pairs) == 2
        # Module board IS in the list even though carrier came first
        assert ("3767", "0005") in pairs

    def test_no_board_in_compatible(self):
        pairs = _extract_board_id_from_compatible("nvidia,tegra234")
        assert pairs == []

    def test_agx_orin_compatible(self):
        pairs = _extract_board_id_from_compatible(
            "nvidia,p3509-0000+p3737-0000 nvidia,tegra234"
        )
        assert ("3509", "0000") in pairs
        assert ("3737", "0000") in pairs

    def test_single_board_id(self):
        """Single board ID still works."""
        pairs = _extract_board_id_from_compatible("nvidia,p3767-0005 nvidia,tegra234")
        assert pairs == [("3767", "0005")]


# ---------------------------------------------------------------------------
# V10: --force-sku tests
# ---------------------------------------------------------------------------

class TestForceSKU:
    """Test the Docker/fleet --force-sku escape hatch."""

    def test_force_sku_orin_nano_super(self):
        hw = detect_jetson(force_sku="orin-nano-super")
        assert hw.is_jetson
        assert hw.forced
        assert hw.sku is not None
        assert hw.sku.name == "Jetson Orin Nano Super"
        assert hw.sku.dla_cores == 0
        assert "force-sku" in hw.detection_source

    def test_force_sku_agx_orin(self):
        hw = detect_jetson(force_sku="agx-orin-64gb")
        assert hw.is_jetson
        assert hw.forced
        assert hw.sku.dla_cores == 2

    def test_force_sku_case_insensitive(self):
        hw = detect_jetson(force_sku="Orin-Nano-Super")
        assert hw.is_jetson
        assert hw.sku.name == "Jetson Orin Nano Super"

    def test_force_sku_invalid_falls_through(self):
        """Invalid force_sku should warn but still try auto-detection."""
        hw = detect_jetson(force_sku="nonexistent-board")
        assert len(hw.detection_warnings) > 0
        assert "nonexistent-board" in hw.detection_warnings[0]

    @patch.dict(os.environ, {"SLOWAI_FORCE_SKU": "orin-nx-16gb"})
    def test_force_sku_via_env_var(self):
        hw = detect_jetson()
        assert hw.is_jetson
        assert hw.forced
        assert hw.sku.name == "Jetson Orin NX 16GB"

    def test_list_aliases_not_empty(self):
        aliases = list_force_sku_aliases()
        assert len(aliases) >= 10
        assert "orin-nano-super" in aliases
        assert "agx-orin-64gb" in aliases

    def test_all_aliases_resolve(self):
        """Every alias in the list must resolve to a valid SKU."""
        for alias in list_force_sku_aliases():
            assert alias in _FORCE_SKU_ALIASES
            assert _FORCE_SKU_ALIASES[alias] is not None


# ---------------------------------------------------------------------------
# V10: Container-aware detection tests
# ---------------------------------------------------------------------------

class TestContainerAwareness:
    """Test graceful handling when /proc/device-tree is unavailable."""

    @patch("slowai.hardware._device_tree_available", return_value=False)
    @patch("slowai.hardware._check_tegra_release", return_value=None)
    @patch("slowai.hardware._check_nvpmodel", return_value=False)
    def test_no_device_tree_warns(self, *mocks):
        hw = detect_jetson()
        assert not hw.is_jetson
        assert len(hw.detection_warnings) > 0
        assert "/proc/device-tree not found" in hw.detection_warnings[0]
        assert "--force-sku" in hw.detection_warnings[0]

    @patch("slowai.hardware._device_tree_available", return_value=False)
    @patch("slowai.hardware._check_tegra_release", return_value=None)
    @patch("slowai.hardware._check_nvpmodel", return_value=False)
    def test_force_sku_bypasses_missing_device_tree(self, *mocks):
        """--force-sku works even without /proc/device-tree."""
        hw = detect_jetson(force_sku="orin-nano-super")
        assert hw.is_jetson
        assert hw.forced
        assert hw.sku.dla_cores == 0


# ---------------------------------------------------------------------------
# V10: Multi-source detection priority tests
# ---------------------------------------------------------------------------

class TestDetectionPriority:
    """Test that detection sources are tried in priority order."""

    @patch("slowai.hardware._device_tree_available", return_value=True)
    @patch("slowai.hardware._read_plugin_manager_ids", return_value=("3767", "0005"))
    @patch("slowai.hardware._read_device_tree_model", return_value="NVIDIA Jetson Orin Nano Super")
    def test_board_id_takes_priority_over_model(self, *mocks):
        hw = detect_jetson()
        assert hw.is_jetson
        assert hw.sku.name == "Jetson Orin Nano Super"
        assert "plugin-manager" in hw.detection_source
        assert hw.board_id == "3767"
        assert hw.board_sku == "0005"

    @patch("slowai.hardware._device_tree_available", return_value=True)
    @patch("slowai.hardware._read_plugin_manager_ids", return_value=("", ""))
    @patch("slowai.hardware._read_device_tree_compatible",
           return_value="nvidia,p3767-0005+p3768-0000 nvidia,tegra234")
    @patch("slowai.hardware._read_device_tree_model", return_value="NVIDIA Orin Nano Super")
    def test_compatible_fallback_with_board_id(self, *mocks):
        hw = detect_jetson()
        assert hw.is_jetson
        assert hw.sku.name == "Jetson Orin Nano Super"
        assert "compatible" in hw.detection_source

    @patch("slowai.hardware._device_tree_available", return_value=True)
    @patch("slowai.hardware._read_plugin_manager_ids", return_value=("", ""))
    @patch("slowai.hardware._read_device_tree_compatible", return_value=None)
    @patch("slowai.hardware._read_device_tree_model",
           return_value="NVIDIA Jetson Orin Nano Engineering Reference Developer Kit Super")
    def test_model_string_last_resort_keyword(self, *mocks):
        hw = detect_jetson()
        assert hw.is_jetson
        assert hw.sku.name == "Jetson Orin Nano Super"
        assert "model" in hw.detection_source

    @patch("slowai.hardware._device_tree_available", return_value=True)
    @patch("slowai.hardware._read_plugin_manager_ids", return_value=("3767", "9999"))
    @patch("slowai.hardware._read_device_tree_compatible", return_value="nvidia,tegra234")
    @patch("slowai.hardware._read_device_tree_model", return_value="Custom Carrier Board")
    def test_unknown_board_sku_warns(self, *mocks):
        """Known BoardID family but unknown SKU variant."""
        hw = detect_jetson()
        assert hw.is_jetson
        assert hw.board_id == "3767"
        assert len(hw.detection_warnings) > 0


# ---------------------------------------------------------------------------
# DLA gating tests — the critical safety gate (V9 carry-forward)
# ---------------------------------------------------------------------------

class TestDLAGating:
    """Test that require_dla raises on hardware without DLA."""

    def test_require_dla_on_non_jetson_raises(self):
        hw = JetsonInfo(is_jetson=False)
        with pytest.raises(DLANotAvailableError, match="not a Jetson"):
            require_dla(hw)

    def test_require_dla_on_orin_nano_raises(self):
        """THE critical test — Grok's bug. Orin Nano has no DLA."""
        nano_sku = _match_sku("orin nano super")
        hw = JetsonInfo(
            is_jetson=True,
            model_string="NVIDIA Orin Nano Super Developer Kit",
            sku=nano_sku,
        )
        with pytest.raises(DLANotAvailableError, match="not available"):
            require_dla(hw)

    def test_require_dla_on_orin_nano_error_message_is_helpful(self):
        """Error message must name the hardware and suggest alternatives."""
        nano_sku = _match_sku("orin nano super")
        hw = JetsonInfo(
            is_jetson=True,
            model_string="NVIDIA Orin Nano Super Developer Kit",
            sku=nano_sku,
        )
        with pytest.raises(DLANotAvailableError) as exc_info:
            require_dla(hw)

        msg = str(exc_info.value)
        assert "Orin Nano" in msg
        assert "DLA cores: 0" in msg
        assert "Orin NX" in msg
        assert "--precision=fp16" in msg

    def test_require_dla_on_agx_orin_passes(self):
        """AGX Orin has 2 DLA cores — should not raise."""
        agx_sku = _match_sku("agx orin 32gb")
        hw = JetsonInfo(
            is_jetson=True,
            model_string="NVIDIA Jetson AGX Orin Developer Kit",
            sku=agx_sku,
        )
        require_dla(hw, dla_core=0)
        require_dla(hw, dla_core=1)

    def test_require_dla_invalid_core_index(self):
        """Requesting core 1 on NX 8GB (1 core) should fail."""
        nx8_sku = _match_sku("orin nx 8gb")
        hw = JetsonInfo(
            is_jetson=True,
            model_string="NVIDIA Jetson Orin NX 8GB",
            sku=nx8_sku,
        )
        require_dla(hw, dla_core=0)
        with pytest.raises(DLANotAvailableError, match="does not exist"):
            require_dla(hw, dla_core=1)

    def test_require_dla_on_forced_sku(self):
        """--force-sku should still enforce DLA gating."""
        hw = detect_jetson(force_sku="orin-nano-super")
        with pytest.raises(DLANotAvailableError):
            require_dla(hw)

    def test_require_dla_on_forced_agx_passes(self):
        hw = detect_jetson(force_sku="agx-orin-64gb")
        require_dla(hw, dla_core=0)  # Should not raise


# ---------------------------------------------------------------------------
# JetsonInfo tests
# ---------------------------------------------------------------------------

class TestJetsonInfo:
    """Test the JetsonInfo dataclass and its properties."""

    def test_non_jetson_defaults(self):
        hw = JetsonInfo()
        assert not hw.is_jetson
        assert not hw.has_dla
        assert hw.dla_cores == 0
        assert hw.sku_name == "Not a Jetson"
        assert hw.series == "unknown"
        assert hw.detection_source == ""
        assert hw.forced is False

    def test_jetson_with_sku(self):
        sku = _match_sku("orin nano super")
        hw = JetsonInfo(is_jetson=True, model_string="test", sku=sku)
        assert hw.is_jetson
        assert not hw.has_dla
        assert hw.dla_cores == 0
        assert hw.max_power_watts == 25
        assert hw.gpu_cores == 1024

    def test_jetson_without_sku(self):
        hw = JetsonInfo(is_jetson=True, model_string="Mystery Board")
        assert hw.is_jetson
        assert "Unknown Jetson" in hw.sku_name
        assert "Mystery Board" in hw.sku_name

    def test_capability_matrix_non_jetson(self):
        hw = JetsonInfo()
        matrix = hw.capability_matrix()
        assert matrix["is_jetson"] is False
        assert matrix["has_dla"] is False
        assert matrix["dla_cores"] == 0
        assert "detection_source" in matrix

    def test_capability_matrix_jetson(self):
        sku = _match_sku("agx orin 64gb")
        hw = JetsonInfo(is_jetson=True, model_string="test", sku=sku,
                       detection_source="plugin-manager/ids:3509-0004",
                       board_id="3509", board_sku="0004")
        matrix = hw.capability_matrix()
        assert matrix["is_jetson"] is True
        assert matrix["has_dla"] is True
        assert matrix["dla_cores"] == 2
        assert matrix["unified_memory_gb"] == 64.0
        assert matrix["gpu_cores"] == 2048
        assert matrix["series"] == "agx_orin"
        assert matrix["board_id"] == "3509"
        assert "detection_source" in matrix

    def test_capability_matrix_with_warnings(self):
        hw = JetsonInfo(detection_warnings=["test warning"])
        matrix = hw.capability_matrix()
        assert "detection_warnings" in matrix
        assert matrix["detection_warnings"] == ["test warning"]


# ---------------------------------------------------------------------------
# Display formatting (V10 updated)
# ---------------------------------------------------------------------------

class TestFormatReport:
    """Test the human-readable hardware report."""

    def test_non_jetson_report(self):
        hw = JetsonInfo()
        report = format_hardware_report(hw)
        assert "Desktop / Server" in report
        assert "not a Jetson" in report
        assert "--force-sku" in report

    def test_orin_nano_report_warns_no_dla(self):
        sku = _match_sku("orin nano super")
        hw = JetsonInfo(is_jetson=True, model_string="NVIDIA Orin Nano Super",
                       sku=sku, detection_source="plugin-manager/ids:3767-0005")
        report = format_hardware_report(hw)
        assert "DLA cores:       0" in report
        assert "ERROR" in report
        assert "Detection via:" in report

    def test_agx_orin_report_shows_dla(self):
        sku = _match_sku("agx orin 32gb")
        hw = JetsonInfo(is_jetson=True, model_string="NVIDIA AGX Orin",
                       sku=sku, detection_source="device-tree/model:keyword")
        report = format_hardware_report(hw)
        assert "DLA cores:       2" in report
        assert "SUPPORTED" in report

    def test_forced_sku_report(self):
        hw = detect_jetson(force_sku="orin-nano-super")
        report = format_hardware_report(hw)
        assert "FORCED" in report
        assert "auto-detection bypassed" in report

    def test_report_shows_warnings(self):
        hw = JetsonInfo(
            is_jetson=True,
            model_string="Custom Board",
            detection_warnings=["BoardID not in database"]
        )
        report = format_hardware_report(hw)
        assert "Warnings:" in report
        assert "BoardID not in database" in report

    def test_v10_header(self):
        hw = JetsonInfo()
        report = format_hardware_report(hw)
        assert "V10" in report
        assert "multi-source" in report
