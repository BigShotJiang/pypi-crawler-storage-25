"""
slowai.hardware — Jetson SKU detection and hardware capability matrix.

V9 P0: Fixed DLA lie — Orin Nano Super has ZERO DLA cores.
V10 P0: Grok (Devil's Advocate) tore apart V9's single-source detection.
    /proc/device-tree/model is marketing text, not a stable identifier.
    NVIDIA has changed these strings across L4T releases and they break
    on Docker containers, custom carrier boards, and JetPack upgrades.

V10 detection strategy (multi-source, version-agnostic):
    1. --force-sku override      — Docker/fleet/custom-board escape hatch
    2. plugin-manager/ids/       — BoardID + SKU (NVIDIA's stable identifiers)
    3. /proc/device-tree/compatible — tegra chip ID + board ID
    4. /proc/device-tree/model   — demoted to fallback (was V9 primary)
    5. /etc/nv_tegra_release     — JetPack release string
    6. nvpmodel -q               — last resort, confirms Jetson

Container-aware: gracefully handles missing /proc/device-tree with clear
warnings instead of crashes. Supports --force-sku for Docker/fleet.

Usage:
    from slowai.hardware import detect_jetson, JetsonInfo
    hw = detect_jetson()                           # auto-detect
    hw = detect_jetson(force_sku="orin-nano-8gb-super")  # Docker override
    if hw.has_dla:
        print(f"DLA available: {hw.dla_cores} cores")
    else:
        print(f"{hw.sku_name} does not have DLA hardware")
"""

from __future__ import annotations

import os
import re
import subprocess
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Hardware capability database
# ---------------------------------------------------------------------------
# Sources:
#   - NVIDIA Jetson Orin Module Data Sheet (DA-11060-001)
#   - NVIDIA Jetson Linux Developer Guide (JetPack 6.x)
#   - Grok V8 review (DLA core counts per SKU)
#   - Grok V9 review (multi-source detection, BoardID/SKU)
#   - /proc/device-tree/chosen/plugin-manager/ids/ (BoardID + SKU files)
#
# Two matching paths:
#   1. BoardID-based (stable): "3767-0005" → Orin Nano Super
#   2. Keyword-based (fallback): "orin nano super" → same SKU
#
# Real device-tree model strings can be verbose, e.g.:
#   "NVIDIA Jetson Orin Nano Engineering Reference Developer Kit Super"

@dataclass(frozen=True)
class JetsonSKU:
    """Static capability record for a Jetson SKU."""
    name: str
    series: str                 # "orin_nano" | "orin_nx" | "agx_orin" | "thor" | "xavier_nx" | "agx_xavier"
    dla_cores: int              # 0, 1, or 2
    max_power_watts: int        # max nvpmodel wattage
    tensor_core_type: str       # "3rd_gen" (Ampere), "4th_gen" (Ada/Orin), etc.
    sm_version: str             # e.g. "8.7" for Orin (Ampere GA10B)
    unified_memory_gb: float    # shared CPU+GPU memory
    gpu_cores: int              # CUDA cores
    notes: str = ""


# Ordered most-specific first so substring matching picks the right SKU.
_KNOWN_SKUS: list[tuple[list[str], JetsonSKU]] = [
    # --- Orin Nano (ZERO DLA) ---
    (
        ["orin nano super", "orin nano 8gb super"],
        JetsonSKU(
            name="Jetson Orin Nano Super",
            series="orin_nano",
            dla_cores=0,
            max_power_watts=25,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=8.0,
            gpu_cores=1024,
            notes="No DLA hardware. GPU-only inference.",
        ),
    ),
    (
        ["orin nano 8gb"],
        JetsonSKU(
            name="Jetson Orin Nano 8GB",
            series="orin_nano",
            dla_cores=0,
            max_power_watts=15,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=8.0,
            gpu_cores=1024,
            notes="No DLA hardware. GPU-only inference.",
        ),
    ),
    (
        ["orin nano 4gb"],
        JetsonSKU(
            name="Jetson Orin Nano 4GB",
            series="orin_nano",
            dla_cores=0,
            max_power_watts=10,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=4.0,
            gpu_cores=512,
            notes="No DLA hardware. GPU-only inference. Reduced CUDA cores.",
        ),
    ),
    (
        ["orin nano"],  # catch-all for any other Orin Nano variant
        JetsonSKU(
            name="Jetson Orin Nano (unknown variant)",
            series="orin_nano",
            dla_cores=0,
            max_power_watts=15,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=8.0,
            gpu_cores=1024,
            notes="No DLA hardware. GPU-only inference.",
        ),
    ),
    # --- Orin NX (2 DLA cores) ---
    (
        ["orin nx 16gb"],
        JetsonSKU(
            name="Jetson Orin NX 16GB",
            series="orin_nx",
            dla_cores=2,
            max_power_watts=25,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=16.0,
            gpu_cores=1024,
        ),
    ),
    (
        ["orin nx 8gb"],
        JetsonSKU(
            name="Jetson Orin NX 8GB",
            series="orin_nx",
            dla_cores=1,
            max_power_watts=20,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=8.0,
            gpu_cores=768,
        ),
    ),
    (
        ["orin nx super"],
        JetsonSKU(
            name="Jetson Orin NX Super",
            series="orin_nx",
            dla_cores=2,
            max_power_watts=25,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=16.0,
            gpu_cores=1024,
        ),
    ),
    (
        ["orin nx"],  # catch-all
        JetsonSKU(
            name="Jetson Orin NX (unknown variant)",
            series="orin_nx",
            dla_cores=2,
            max_power_watts=25,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=16.0,
            gpu_cores=1024,
        ),
    ),
    # --- AGX Orin (2 DLA cores, big GPU) ---
    (
        ["agx orin 64gb"],
        JetsonSKU(
            name="Jetson AGX Orin 64GB",
            series="agx_orin",
            dla_cores=2,
            max_power_watts=60,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=64.0,
            gpu_cores=2048,
        ),
    ),
    (
        ["agx orin 32gb", "agx orin developer kit"],
        JetsonSKU(
            name="Jetson AGX Orin 32GB",
            series="agx_orin",
            dla_cores=2,
            max_power_watts=60,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=32.0,
            gpu_cores=1792,
        ),
    ),
    (
        ["agx orin"],  # catch-all
        JetsonSKU(
            name="Jetson AGX Orin (unknown variant)",
            series="agx_orin",
            dla_cores=2,
            max_power_watts=60,
            tensor_core_type="4th_gen",
            sm_version="8.7",
            unified_memory_gb=32.0,
            gpu_cores=2048,
        ),
    ),
    # --- Thor (next-gen, 2 DLA cores) ---
    (
        ["thor"],
        JetsonSKU(
            name="Jetson Thor",
            series="thor",
            dla_cores=2,
            max_power_watts=100,
            tensor_core_type="5th_gen",
            sm_version="10.0",
            unified_memory_gb=128.0,
            gpu_cores=16384,
            notes="Next-gen. Specs may change.",
        ),
    ),
    # --- Xavier family (legacy, included for completeness) ---
    (
        ["agx xavier"],
        JetsonSKU(
            name="Jetson AGX Xavier",
            series="agx_xavier",
            dla_cores=2,
            max_power_watts=30,
            tensor_core_type="3rd_gen",
            sm_version="7.2",
            unified_memory_gb=32.0,
            gpu_cores=512,
        ),
    ),
    (
        ["xavier nx"],
        JetsonSKU(
            name="Jetson Xavier NX",
            series="xavier_nx",
            dla_cores=2,
            max_power_watts=20,
            tensor_core_type="3rd_gen",
            sm_version="7.2",
            unified_memory_gb=8.0,
            gpu_cores=384,
        ),
    ),
]


# ---------------------------------------------------------------------------
# BoardID → SKU mapping (NVIDIA's stable hardware identifiers)
# ---------------------------------------------------------------------------
# These come from /proc/device-tree/chosen/plugin-manager/ids/
# Files like: boardid (e.g. "3767"), boardsku (e.g. "0005")
# Combined as "3767-0005" → Orin Nano Super
#
# This is MORE RELIABLE than model strings because:
#   - BoardIDs are burned into the hardware/EEPROM
#   - They don't change across L4T/JetPack versions
#   - They work on custom carrier boards (module ID stays the same)
#   - They survive DT overlays and dynamic DTBOs
#
# Source: NVIDIA Jetson Module Datasheets + community documentation
_BOARD_SKU_MAP: dict[str, JetsonSKU] = {}

# Build the map — iterate _KNOWN_SKUS to reuse existing SKU objects
def _build_board_map() -> dict[str, JetsonSKU]:
    """Map BoardID-SKU strings to JetsonSKU objects."""
    m: dict[str, JetsonSKU] = {}

    # Find SKU objects by name for board mapping
    _sku_by_name: dict[str, JetsonSKU] = {}
    for _, sku in _KNOWN_SKUS:
        _sku_by_name[sku.name] = sku

    # Orin Nano family (module board 3767)
    if "Jetson Orin Nano Super" in _sku_by_name:
        m["3767-0005"] = _sku_by_name["Jetson Orin Nano Super"]
    if "Jetson Orin Nano 8GB" in _sku_by_name:
        m["3767-0003"] = _sku_by_name["Jetson Orin Nano 8GB"]
    if "Jetson Orin Nano 4GB" in _sku_by_name:
        m["3767-0004"] = _sku_by_name["Jetson Orin Nano 4GB"]

    # Orin NX family (module board 3767, different SKUs)
    if "Jetson Orin NX 16GB" in _sku_by_name:
        m["3767-0000"] = _sku_by_name["Jetson Orin NX 16GB"]
    if "Jetson Orin NX 8GB" in _sku_by_name:
        m["3767-0001"] = _sku_by_name["Jetson Orin NX 8GB"]

    # AGX Orin family (module board 3509)
    if "Jetson AGX Orin 32GB" in _sku_by_name:
        m["3509-0000"] = _sku_by_name["Jetson AGX Orin 32GB"]
    if "Jetson AGX Orin 64GB" in _sku_by_name:
        m["3509-0004"] = _sku_by_name["Jetson AGX Orin 64GB"]

    # Xavier family (module board 2888 / 3668)
    if "Jetson AGX Xavier" in _sku_by_name:
        m["2888-0001"] = _sku_by_name["Jetson AGX Xavier"]
        m["2888-0004"] = _sku_by_name["Jetson AGX Xavier"]
    if "Jetson Xavier NX" in _sku_by_name:
        m["3668-0001"] = _sku_by_name["Jetson Xavier NX"]
        m["3668-0003"] = _sku_by_name["Jetson Xavier NX"]

    return m

_BOARD_SKU_MAP = _build_board_map()


# ---------------------------------------------------------------------------
# --force-sku alias map (Docker / fleet escape hatch)
# ---------------------------------------------------------------------------
# Users in containers or on custom carrier boards can do:
#   slowai hardware --force-sku=orin-nano-8gb-super
#   SLOWAI_FORCE_SKU=orin-nano-8gb-super slowai hardware
#
# Aliases are lowercase, hyphen-separated, and unambiguous.
_FORCE_SKU_ALIASES: dict[str, JetsonSKU] = {}

def _build_force_aliases() -> dict[str, JetsonSKU]:
    m: dict[str, JetsonSKU] = {}
    _sku_by_name: dict[str, JetsonSKU] = {}
    for _, sku in _KNOWN_SKUS:
        _sku_by_name[sku.name] = sku

    alias_map = {
        # Orin Nano
        "orin-nano-super": "Jetson Orin Nano Super",
        "orin-nano-8gb-super": "Jetson Orin Nano Super",
        "orin-nano-8gb": "Jetson Orin Nano 8GB",
        "orin-nano-4gb": "Jetson Orin Nano 4GB",
        "orin-nano": "Jetson Orin Nano (unknown variant)",
        # Orin NX
        "orin-nx-16gb": "Jetson Orin NX 16GB",
        "orin-nx-8gb": "Jetson Orin NX 8GB",
        "orin-nx-super": "Jetson Orin NX Super",
        "orin-nx": "Jetson Orin NX (unknown variant)",
        # AGX Orin
        "agx-orin-64gb": "Jetson AGX Orin 64GB",
        "agx-orin-32gb": "Jetson AGX Orin 32GB",
        "agx-orin": "Jetson AGX Orin (unknown variant)",
        # Thor
        "thor": "Jetson Thor",
        # Xavier
        "agx-xavier": "Jetson AGX Xavier",
        "xavier-nx": "Jetson Xavier NX",
    }
    for alias, name in alias_map.items():
        if name in _sku_by_name:
            m[alias] = _sku_by_name[name]
    return m

_FORCE_SKU_ALIASES = _build_force_aliases()


def list_force_sku_aliases() -> list[str]:
    """Return all valid --force-sku alias strings."""
    return sorted(_FORCE_SKU_ALIASES.keys())


# ---------------------------------------------------------------------------
# Runtime detection result
# ---------------------------------------------------------------------------

@dataclass
class JetsonInfo:
    """Result of runtime hardware detection.

    This is the single source of truth for what the current device can do.
    Other modules (optimize.py, cli.py) should query this instead of
    guessing from is_jetson booleans.
    """
    is_jetson: bool = False
    model_string: str = ""          # raw /proc/device-tree/model content
    sku: JetsonSKU | None = None    # matched SKU from database, or None
    detection_source: str = ""      # V10: which method found this SKU
    board_id: str = ""              # V10: raw BoardID (e.g. "3767")
    board_sku: str = ""             # V10: raw board SKU (e.g. "0005")
    forced: bool = False            # V10: True if --force-sku was used
    detection_warnings: list = field(default_factory=list)  # V10: issues found

    # Convenience accessors (derived from sku)
    @property
    def sku_name(self) -> str:
        if self.sku:
            return self.sku.name
        if self.is_jetson:
            return f"Unknown Jetson ({self.model_string})"
        return "Not a Jetson"

    @property
    def has_dla(self) -> bool:
        return self.sku is not None and self.sku.dla_cores > 0

    @property
    def dla_cores(self) -> int:
        return self.sku.dla_cores if self.sku else 0

    @property
    def series(self) -> str:
        return self.sku.series if self.sku else "unknown"

    @property
    def max_power_watts(self) -> int:
        return self.sku.max_power_watts if self.sku else 0

    @property
    def unified_memory_gb(self) -> float:
        return self.sku.unified_memory_gb if self.sku else 0.0

    @property
    def gpu_cores(self) -> int:
        return self.sku.gpu_cores if self.sku else 0

    def capability_matrix(self) -> dict:
        """Return a flat dict of capabilities for JSON/CLI output."""
        base = {
            "is_jetson": self.is_jetson,
            "model_string": self.model_string,
            "sku_name": self.sku_name,
            "detection_source": self.detection_source,
            "forced": self.forced,
        }
        if self.board_id:
            base["board_id"] = self.board_id
        if self.board_sku:
            base["board_sku"] = self.board_sku
        if self.detection_warnings:
            base["detection_warnings"] = self.detection_warnings

        if not self.sku:
            base["dla_cores"] = 0
            base["has_dla"] = False
            return base

        base.update({
            "series": self.sku.series,
            "dla_cores": self.sku.dla_cores,
            "has_dla": self.has_dla,
            "max_power_watts": self.sku.max_power_watts,
            "tensor_core_type": self.sku.tensor_core_type,
            "sm_version": self.sku.sm_version,
            "unified_memory_gb": self.sku.unified_memory_gb,
            "gpu_cores": self.sku.gpu_cores,
            "notes": self.sku.notes,
        })
        return base


# ---------------------------------------------------------------------------
# Detection logic
# ---------------------------------------------------------------------------

def _read_dt_file(path: str) -> bytes | None:
    """Read a device-tree file safely. Returns None on any error."""
    try:
        return Path(path).read_bytes()
    except (FileNotFoundError, OSError, PermissionError):
        return None


def _read_dt_string(path: str) -> str | None:
    """Read a null-terminated device-tree string."""
    raw = _read_dt_file(path)
    if raw is None:
        return None
    return raw.decode("utf-8", errors="ignore").strip("\x00").strip()


def _read_device_tree_model() -> str | None:
    """Read /proc/device-tree/model (null-terminated string on Jetson Linux)."""
    return _read_dt_string("/proc/device-tree/model")


def _read_device_tree_compatible() -> str | None:
    """Read /proc/device-tree/compatible — fallback for chip identification."""
    raw = _read_dt_file("/proc/device-tree/compatible")
    if raw is None:
        return None
    return raw.decode("utf-8", errors="ignore").replace("\x00", " ").strip()


def _read_plugin_manager_ids() -> tuple[str, str]:
    """Read BoardID and BoardSKU from plugin-manager/ids.

    These are NVIDIA's stable hardware identifiers, burned into EEPROM.
    More reliable than model strings across L4T/JetPack versions.

    Returns:
        (board_id, board_sku) — e.g. ("3767", "0005") for Orin Nano Super.
        Both empty strings if files not found.
    """
    base = "/proc/device-tree/chosen/plugin-manager/ids"

    board_id = _read_dt_string(f"{base}/boardid") or ""
    board_sku = _read_dt_string(f"{base}/boardsku") or ""

    # Some JetPack versions use slightly different paths
    if not board_id:
        board_id = _read_dt_string(f"{base}/board-id") or ""
    if not board_sku:
        board_sku = _read_dt_string(f"{base}/board-sku") or ""

    return board_id.strip(), board_sku.strip()


def _extract_board_id_from_compatible(compat: str) -> list[tuple[str, str]]:
    """Extract ALL BoardID-SKU pairs from compatible string.

    Compatible strings look like:
        nvidia,p3767-0005+p3768-0000 nvidia,p3767-0005 nvidia,tegra234
    Multiple board IDs appear — module (3767) AND carrier (3768).
    We return ALL pairs so the caller can match against the database,
    since the carrier board ID won't be in our map but the module will.

    V10 P1: Changed from re.search (first-match-only) to re.findall
    after field testing showed carrier board ID appearing first on
    Orin Nano Super (3768-0000 before 3767-0005).
    """
    # Pattern: p<boardid>-<sku> — find ALL matches
    # Don't require nvidia, prefix — carrier board after + separator lacks it
    # e.g. "nvidia,p3767-0005+p3768-0000" has both module and carrier
    matches = re.findall(r'p(\d{4})-(\d{4})', compat)
    # Deduplicate while preserving order
    seen = set()
    unique = []
    for pair in matches:
        if pair not in seen:
            seen.add(pair)
            unique.append(pair)
    return unique


def _match_sku(model_lower: str) -> JetsonSKU | None:
    """Match a model string against the known SKU database.

    Iterates most-specific first so "orin nano super" matches before
    the generic "orin nano" catch-all.

    Each keyword phrase can match either as a contiguous substring OR
    as individual words all present in the model string (handles cases
    like "Orin Nano Engineering Reference Developer Kit Super" matching
    the "orin nano super" pattern).
    """
    for keywords_list, sku in _KNOWN_SKUS:
        for keywords in keywords_list:
            # Try contiguous substring first (fast path)
            if keywords in model_lower:
                return sku
            # Fallback: check if all words in the keyword phrase appear
            # anywhere in the model string (handles extra words between)
            words = keywords.split()
            if len(words) > 1 and all(w in model_lower for w in words):
                return sku
    return None


def _match_board_sku(board_id: str, board_sku: str) -> JetsonSKU | None:
    """Match a BoardID-SKU pair against the hardware database.

    This is the most reliable matching path — BoardIDs are EEPROM-burned
    and don't change across JetPack versions or DT overlays.
    """
    key = f"{board_id}-{board_sku}"
    return _BOARD_SKU_MAP.get(key)


def _check_tegra_release() -> str | None:
    """Read /etc/nv_tegra_release to confirm this is a Jetson.

    Returns the release string if found, None otherwise.
    """
    try:
        content = Path("/etc/nv_tegra_release").read_text(errors="ignore").strip()
        return content if content else None
    except (FileNotFoundError, OSError, PermissionError):
        return None


def _check_nvpmodel() -> bool:
    """Check if nvpmodel exists — confirms Jetson even without device-tree."""
    try:
        result = subprocess.run(
            ["nvpmodel", "-q"], capture_output=True, text=True, timeout=2,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _device_tree_available() -> bool:
    """Check if /proc/device-tree is mounted and accessible."""
    return Path("/proc/device-tree").exists()


def detect_jetson(force_sku: str | None = None) -> JetsonInfo:
    """Detect the current Jetson hardware and return a capability record.

    V10: Multi-source detection chain. No single point of failure.

    Detection order:
        1. --force-sku override (env var or parameter)
        2. plugin-manager/ids BoardID+SKU (most stable)
        3. /proc/device-tree/compatible (board+chip ID)
        4. /proc/device-tree/model (marketing text — least stable)
        5. /etc/nv_tegra_release
        6. nvpmodel -q

    Args:
        force_sku: Override auto-detection with a known SKU alias.
            Also checks SLOWAI_FORCE_SKU environment variable.
            Valid aliases: see list_force_sku_aliases().

    Returns:
        JetsonInfo with is_jetson=False on non-Jetson systems.
        JetsonInfo with populated sku on recognized Jetson hardware.
        JetsonInfo with is_jetson=True but sku=None on unrecognized Jetson.
    """
    info = JetsonInfo()

    # Strategy 0: --force-sku override (Docker/fleet/custom-board escape hatch)
    force = force_sku or os.environ.get("SLOWAI_FORCE_SKU", "").strip()
    if force:
        force_lower = force.lower().strip()
        sku = _FORCE_SKU_ALIASES.get(force_lower)
        if sku:
            info.is_jetson = True
            info.sku = sku
            info.forced = True
            info.detection_source = f"force-sku:{force_lower}"
            info.model_string = f"(forced: {sku.name})"
            return info
        else:
            valid = ", ".join(list_force_sku_aliases())
            info.detection_warnings.append(
                f"Unknown --force-sku '{force}'. Valid aliases: {valid}"
            )
            # Fall through to auto-detection

    # Check if device-tree is available (container-awareness)
    dt_available = _device_tree_available()
    if not dt_available:
        info.detection_warnings.append(
            "/proc/device-tree not found. "
            "If running in Docker, mount it with: "
            "--privileged --volume /proc/device-tree:/proc/device-tree:ro "
            "or use --force-sku=<your-sku> to bypass detection."
        )

    # Strategy 1: plugin-manager/ids (NVIDIA's stable BoardID + SKU)
    # This is the MOST RELIABLE source — EEPROM-burned, survives JetPack upgrades
    if dt_available:
        board_id, board_sku = _read_plugin_manager_ids()
        if board_id:
            info.board_id = board_id
            info.board_sku = board_sku
            sku = _match_board_sku(board_id, board_sku)
            if sku:
                info.is_jetson = True
                info.sku = sku
                info.detection_source = f"plugin-manager/ids:{board_id}-{board_sku}"
                # Still grab model string for display
                model_str = _read_device_tree_model()
                info.model_string = model_str or f"BoardID {board_id}-{board_sku}"
                return info
            else:
                # BoardID found but not in our database — still a Jetson
                info.is_jetson = True
                info.detection_warnings.append(
                    f"BoardID {board_id}-{board_sku} not in slowai database. "
                    f"Hardware detected as Jetson but SKU capabilities unknown. "
                    f"Consider --force-sku or filing a GitHub issue."
                )

    # Strategy 2: /proc/device-tree/compatible (board + chip ID)
    if dt_available:
        compat = _read_device_tree_compatible()
        if compat:
            compat_lower = compat.lower()
            if "tegra" in compat_lower or "nvidia" in compat_lower:
                info.is_jetson = True
                # Try to extract board IDs from compatible string
                # P1: iterate ALL matches — carrier board often appears first
                board_pairs = _extract_board_id_from_compatible(compat_lower)
                if board_pairs and not info.board_id:
                    # Store first pair as raw board info
                    info.board_id = board_pairs[0][0]
                    info.board_sku = board_pairs[0][1]
                if not info.sku:
                    # Try each board pair against database (module ID will match)
                    for c_board_id, c_board_sku in board_pairs:
                        sku = _match_board_sku(c_board_id, c_board_sku)
                        if sku:
                            info.sku = sku
                            info.board_id = c_board_id
                            info.board_sku = c_board_sku
                            info.detection_source = f"compatible:{c_board_id}-{c_board_sku}"
                            model_str = _read_device_tree_model()
                            info.model_string = model_str or compat
                            return info
                    # Try keyword match from compatible
                    sku = _match_sku(compat_lower)
                    if sku:
                        info.sku = sku
                        info.detection_source = "compatible:keyword"
                        info.model_string = compat
                        return info

    # Strategy 3: /proc/device-tree/model (V9's primary, now demoted)
    if dt_available:
        model_str = _read_device_tree_model()
        if model_str:
            info.model_string = model_str
            model_lower = model_str.lower()
            if "jetson" in model_lower or "orin" in model_lower or "xavier" in model_lower or "nvidia" in model_lower:
                info.is_jetson = True
                if not info.sku:
                    info.sku = _match_sku(model_lower)
                    if info.sku:
                        info.detection_source = "device-tree/model:keyword"
                    return info

    # If we already confirmed Jetson from strategies 1-2 but couldn't match SKU
    if info.is_jetson and not info.sku:
        model_str = _read_device_tree_model()
        if model_str:
            info.model_string = model_str
        info.detection_source = "partial (Jetson confirmed, SKU unknown)"
        return info

    # Strategy 4: /etc/nv_tegra_release
    tegra_release = _check_tegra_release()
    if tegra_release:
        info.is_jetson = True
        info.model_string = f"(detected via nv_tegra_release)"
        info.detection_source = "nv_tegra_release"
        return info

    # Strategy 5: nvpmodel
    if _check_nvpmodel():
        info.is_jetson = True
        info.model_string = "(detected via nvpmodel)"
        info.detection_source = "nvpmodel"
        return info

    return info


# ---------------------------------------------------------------------------
# DLA gating — the whole reason this module exists
# ---------------------------------------------------------------------------

class DLANotAvailableError(RuntimeError):
    """Raised when --dla is requested on hardware that has no DLA cores.

    This is not a generic error — it's a specific, actionable message
    that names the hardware and explains what it lacks.
    """
    pass


def require_dla(hw: JetsonInfo, dla_core: int = 0) -> None:
    """Validate that DLA is available on this hardware. Raise if not.

    Call this before passing --useDLACore to trtexec.

    Args:
        hw: JetsonInfo from detect_jetson().
        dla_core: Which DLA core (0 or 1).

    Raises:
        DLANotAvailableError: If hardware has no DLA or core index is invalid.
    """
    if not hw.is_jetson:
        raise DLANotAvailableError(
            "DLA offloading requires NVIDIA Jetson hardware. "
            "This system is not a Jetson device."
        )

    if not hw.has_dla:
        raise DLANotAvailableError(
            f"DLA offloading is not available on {hw.sku_name}.\n"
            f"  Hardware: {hw.model_string}\n"
            f"  DLA cores: 0\n"
            f"\n"
            f"DLA hardware exists on: Orin NX, AGX Orin, and Thor series.\n"
            f"The Orin Nano family does not have DLA cores.\n"
            f"\n"
            f"To run inference on this device, use GPU-only mode:\n"
            f"  slowai optimize model.py --precision=fp16  (no --dla flag)"
        )

    if dla_core >= hw.dla_cores:
        raise DLANotAvailableError(
            f"{hw.sku_name} has {hw.dla_cores} DLA core(s) (index 0..{hw.dla_cores - 1}).\n"
            f"Requested DLA core {dla_core} does not exist.\n"
            f"Use --dla-core=0" + (f" or --dla-core=1" if hw.dla_cores > 1 else "") + "."
        )


# ---------------------------------------------------------------------------
# CLI display helper
# ---------------------------------------------------------------------------

def format_hardware_report(hw: JetsonInfo) -> str:
    """Format a human-readable hardware report for `slowai hardware`."""
    lines = []
    lines.append("=" * 62)
    lines.append("  slowai V10 — HARDWARE DETECTION (multi-source)")
    lines.append("=" * 62)
    lines.append("")

    if not hw.is_jetson:
        lines.append("  Platform: Desktop / Server (not a Jetson)")
        lines.append("  DLA: not applicable")
        lines.append("")
        if hw.detection_warnings:
            lines.append("  Warnings:")
            for w in hw.detection_warnings:
                lines.append(f"    ! {w}")
            lines.append("")
        lines.append("  slowai hardware detection is designed for NVIDIA Jetson.")
        lines.append("  On desktop GPUs, use `slowai capabilities` for backend info.")
        lines.append("  In Docker, use --force-sku=<sku> or mount /proc/device-tree.")
        lines.append("")
        lines.append("=" * 62)
        return "\n".join(lines)

    # Jetson detected
    lines.append(f"  Detected: {hw.sku_name}")
    lines.append(f"  Model string: {hw.model_string}")
    lines.append(f"  Detection via: {hw.detection_source}")
    if hw.board_id:
        lines.append(f"  Board ID/SKU:  {hw.board_id}-{hw.board_sku}")
    if hw.forced:
        lines.append(f"  ** FORCED via --force-sku (auto-detection bypassed) **")
    lines.append("")

    if hw.sku:
        sku = hw.sku
        lines.append(f"  Series:          {sku.series}")
        lines.append(f"  CUDA cores:      {sku.gpu_cores}")
        lines.append(f"  SM version:      {sku.sm_version}")
        lines.append(f"  Tensor cores:    {sku.tensor_core_type}")
        lines.append(f"  Unified memory:  {sku.unified_memory_gb:.0f} GB")
        lines.append(f"  Max power:       {sku.max_power_watts} W")
        lines.append("")

        # DLA section — the critical part
        if sku.dla_cores > 0:
            lines.append(f"  DLA cores:       {sku.dla_cores}  ✓ --dla flag is SUPPORTED")
        else:
            lines.append(f"  DLA cores:       0  ✗ --dla flag will ERROR on this device")
            lines.append(f"  DLA note:        {sku.notes}")
        lines.append("")

        if sku.notes and sku.dla_cores > 0:
            lines.append(f"  Notes: {sku.notes}")
            lines.append("")
    else:
        lines.append("  SKU: not recognized (Jetson detected but model not in database)")
        lines.append(f"  Raw model: {hw.model_string}")
        lines.append("  DLA: unknown — check /sys/devices/platform/host1x/ for nvdla* nodes")
        lines.append("  Tip: use --force-sku=<sku> to set capabilities manually")
        lines.append("")

    # V10: Show warnings
    if hw.detection_warnings:
        lines.append("  Warnings:")
        for w in hw.detection_warnings:
            lines.append(f"    ! {w}")
        lines.append("")

    lines.append("=" * 62)
    return "\n".join(lines)
