"""Tests for project_hub/forge/auth.py — unified forge auth resolution."""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path

import pytest

import project_hub.forge.auth as forge_auth


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def tmp_auth_file(tmp_path, monkeypatch):
    """Return a tmp auth.json path and point AUTH_FILE at it."""
    auth_file = tmp_path / "auth.json"
    monkeypatch.setattr(forge_auth, "AUTH_FILE", auth_file)
    return auth_file


@pytest.fixture()
def tmp_python_gitlab_cfg(tmp_path, monkeypatch):
    """Return a tmp .python-gitlab.cfg path and point PYTHON_GITLAB_CFG at it."""
    cfg_file = tmp_path / "python-gitlab.cfg"
    monkeypatch.setattr(forge_auth, "PYTHON_GITLAB_CFG", cfg_file)
    return cfg_file


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    """Remove forge env vars from the test environment by default."""
    monkeypatch.delenv("GITLAB_TOKEN", raising=False)
    monkeypatch.delenv("GITHUB_TOKEN", raising=False)


# ---------------------------------------------------------------------------
# resolve_token — auth.json
# ---------------------------------------------------------------------------


def test_resolve_from_auth_file(tmp_auth_file):
    """Token stored in auth.json is returned for any forge_type."""
    tmp_auth_file.write_text(json.dumps({"gitlab.example.com": "secret123"}))
    assert forge_auth.resolve_token("gitlab.example.com") == "secret123"
    assert forge_auth.resolve_token("gitlab.example.com", forge_type="gitlab") == "secret123"
    assert forge_auth.resolve_token("gitlab.example.com", forge_type="github") == "secret123"


def test_resolve_auth_file_missing_returns_none(tmp_auth_file):
    """No auth.json → None."""
    assert forge_auth.resolve_token("gitlab.com") is None


def test_resolve_auth_file_unknown_instance_returns_none(tmp_auth_file):
    """Instance not in auth.json → None (no forge env fallbacks active)."""
    tmp_auth_file.write_text(json.dumps({"other.example.com": "tok"}))
    assert forge_auth.resolve_token("gitlab.com", forge_type=None) is None


# ---------------------------------------------------------------------------
# resolve_token — GITLAB_TOKEN env fallback
# ---------------------------------------------------------------------------


def test_gitlab_token_env_gitlab_com(tmp_auth_file, monkeypatch):
    """GITLAB_TOKEN activates for forge_type='gitlab' on gitlab.com."""
    monkeypatch.setenv("GITLAB_TOKEN", "gl-env-token")
    assert forge_auth.resolve_token("gitlab.com", forge_type="gitlab") == "gl-env-token"


def test_gitlab_token_env_not_for_self_hosted(tmp_auth_file, monkeypatch):
    """GITLAB_TOKEN does NOT activate for self-hosted instances."""
    monkeypatch.setenv("GITLAB_TOKEN", "gl-env-token")
    assert forge_auth.resolve_token("gitlab.example.com", forge_type="gitlab") is None


def test_gitlab_token_env_not_for_github_type(tmp_auth_file, monkeypatch):
    """GITLAB_TOKEN does NOT activate when forge_type='github'."""
    monkeypatch.setenv("GITLAB_TOKEN", "gl-env-token")
    assert forge_auth.resolve_token("gitlab.com", forge_type="github") is None


def test_gitlab_token_env_not_for_none_type(tmp_auth_file, monkeypatch):
    """GITLAB_TOKEN does NOT activate when forge_type=None."""
    monkeypatch.setenv("GITLAB_TOKEN", "gl-env-token")
    assert forge_auth.resolve_token("gitlab.com", forge_type=None) is None


# ---------------------------------------------------------------------------
# resolve_token — GITHUB_TOKEN env fallback
# ---------------------------------------------------------------------------


def test_github_token_env_github_type(tmp_auth_file, monkeypatch):
    """GITHUB_TOKEN activates for forge_type='github'."""
    monkeypatch.setenv("GITHUB_TOKEN", "gh-env-token")
    assert forge_auth.resolve_token("github.com", forge_type="github") == "gh-env-token"


def test_github_token_env_not_for_gitlab_type(tmp_auth_file, monkeypatch):
    """GITHUB_TOKEN does NOT activate when forge_type='gitlab'."""
    monkeypatch.setenv("GITHUB_TOKEN", "gh-env-token")
    assert forge_auth.resolve_token("github.com", forge_type="gitlab") is None


def test_github_token_env_not_for_none_type(tmp_auth_file, monkeypatch):
    """GITHUB_TOKEN does NOT activate when forge_type=None."""
    monkeypatch.setenv("GITHUB_TOKEN", "gh-env-token")
    assert forge_auth.resolve_token("github.com", forge_type=None) is None


# ---------------------------------------------------------------------------
# resolve_token — python-gitlab.cfg fallback
# ---------------------------------------------------------------------------


def test_python_gitlab_cfg_fallback(tmp_auth_file, tmp_python_gitlab_cfg, monkeypatch):
    """~/.python-gitlab.cfg is used for forge_type='gitlab'."""
    tmp_python_gitlab_cfg.write_text(
        "[global]\n"
        "default = mylab\n"
        "[mylab]\n"
        "url = https://gitlab.example.com\n"
        "private_token = cfg-token\n"
    )
    result = forge_auth.resolve_token("gitlab.example.com", forge_type="gitlab")
    assert result == "cfg-token"


def test_python_gitlab_cfg_not_for_github_type(tmp_auth_file, tmp_python_gitlab_cfg, monkeypatch):
    """python-gitlab.cfg is NOT consulted for forge_type='github'."""
    tmp_python_gitlab_cfg.write_text(
        "[global]\n"
        "[mylab]\n"
        "url = https://gitlab.example.com\n"
        "private_token = cfg-token\n"
    )
    result = forge_auth.resolve_token("gitlab.example.com", forge_type="github")
    assert result is None


def test_python_gitlab_cfg_not_for_none_type(tmp_auth_file, tmp_python_gitlab_cfg):
    """python-gitlab.cfg is NOT consulted when forge_type=None."""
    tmp_python_gitlab_cfg.write_text(
        "[global]\n"
        "[mylab]\n"
        "url = https://gitlab.example.com\n"
        "private_token = cfg-token\n"
    )
    result = forge_auth.resolve_token("gitlab.example.com", forge_type=None)
    assert result is None


# ---------------------------------------------------------------------------
# auth.json takes precedence over env vars
# ---------------------------------------------------------------------------


def test_auth_file_takes_precedence_over_env(tmp_auth_file, monkeypatch):
    """auth.json token wins over GITLAB_TOKEN env."""
    tmp_auth_file.write_text(json.dumps({"gitlab.com": "file-token"}))
    monkeypatch.setenv("GITLAB_TOKEN", "env-token")
    assert forge_auth.resolve_token("gitlab.com", forge_type="gitlab") == "file-token"


# ---------------------------------------------------------------------------
# store_token / round-trip
# ---------------------------------------------------------------------------


def test_store_token_round_trip(tmp_auth_file):
    """store_token persists and resolve_token retrieves the token."""
    forge_auth.store_token("myforge.example.com", "round-trip-token")
    assert forge_auth.resolve_token("myforge.example.com") == "round-trip-token"


def test_store_token_sets_permissions(tmp_auth_file):
    """store_token creates auth.json with 0o600 permissions."""
    forge_auth.store_token("myforge.example.com", "tok")
    mode = tmp_auth_file.stat().st_mode & 0o777
    assert mode == 0o600


def test_store_token_preserves_existing(tmp_auth_file):
    """Storing a second instance doesn't erase the first."""
    forge_auth.store_token("forge-a.example.com", "token-a")
    forge_auth.store_token("forge-b.example.com", "token-b")
    assert forge_auth.resolve_token("forge-a.example.com") == "token-a"
    assert forge_auth.resolve_token("forge-b.example.com") == "token-b"


# ---------------------------------------------------------------------------
# auth_status
# ---------------------------------------------------------------------------


def test_auth_status_returns_all_instances(tmp_auth_file):
    """auth_status returns one AuthInfo per instance in auth.json."""
    tmp_auth_file.write_text(json.dumps({
        "forge-a.example.com": "tok-a",
        "forge-b.example.com": "tok-b",
    }))
    statuses = forge_auth.auth_status()
    assert len(statuses) == 2
    instances = {s.instance for s in statuses}
    assert instances == {"forge-a.example.com", "forge-b.example.com"}
    for s in statuses:
        assert s.has_token is True
        assert s.authenticated is True


def test_auth_status_empty_when_no_file(tmp_auth_file):
    """auth_status returns [] when auth.json doesn't exist."""
    assert forge_auth.auth_status() == []


# ---------------------------------------------------------------------------
# forge/__init__.py re-exports
# ---------------------------------------------------------------------------


def test_forge_package_re_exports():
    """AuthInfo, auth_status, resolve_token, store_token are importable from project_hub.forge."""
    from project_hub.forge import AuthInfo, auth_status, resolve_token, store_token  # noqa: F401
    assert callable(resolve_token)
    assert callable(store_token)
    assert callable(auth_status)
    assert isinstance(AuthInfo("x", True, True), AuthInfo)
