//! Shared dynamic-capability service used by both the REST API
//! (#654) and the MCP wrapper tools (#655).
//!
//! Keeping REST and MCP on top of a single service guarantees parity
//! without duplication — the only difference between a
//! `POST /v1/call` and a `call_tool` MCP invocation is the transport
//! adapter. That is the same invariant the tracking issue #657 calls
//! out as the "success criterion":
//!
//! > REST and MCP wrapper paths share the same routing/call
//! > implementation.
//!
//! The service is deliberately **async-free** for search/describe —
//! those operations never need to await because the capability index
//! is an in-process `parking_lot::RwLock`. The call path does await
//! on the backend HTTP forward but otherwise is a thin wrapper around
//! [`super::backend_client::forward_tools_call`].

use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use uuid::Uuid;

use dcc_mcp_jsonrpc::McpTool;
use dcc_mcp_transport::discovery::types::ServiceEntry;

use super::backend_client::{forward_tools_call, try_describe_tool};
use super::capability::{
    CapabilityIndex, CapabilityRecord, RefreshReason, SearchHit, SearchQuery, parse_slug,
    refresh_instance, remove_instance, search,
};
use super::state::GatewayState;
use dcc_mcp_gateway_core::naming::instance_short;

/// Shape of a structured error emitted by the call / describe paths.
///
/// Lives on the wire as JSON so REST and MCP callers see identical
/// error payloads — the `kind` discriminator lets agents dispatch on
/// failure class without parsing the free-form `message`.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServiceError {
    /// Short kebab-case discriminator (`unknown-slug`,
    /// `instance-offline`, `ambiguous`, `backend-error`).
    pub kind: String,
    /// Human-readable message. Safe to display to end users.
    pub message: String,
    /// Candidate slugs for `ambiguous` errors, empty otherwise.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub candidates: Vec<CapabilityRecord>,
    /// Why a prior instance is no longer routable (`deregistered`,
    /// `heartbeat-timeout`, `never-registered`) — issue #996.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub previous_status: Option<String>,
    /// Last known instance UUID when `kind = instance-offline`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub previous_instance_id: Option<String>,
}

impl ServiceError {
    /// Convenience constructor used by the handlers.
    pub fn new(kind: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            kind: kind.into(),
            message: message.into(),
            candidates: Vec::new(),
            previous_status: None,
            previous_instance_id: None,
        }
    }

    /// Attach disambiguation candidates (for `kind = "ambiguous"`).
    pub fn with_candidates(mut self, candidates: Vec<CapabilityRecord>) -> Self {
        self.candidates = candidates;
        self
    }

    /// Attach instance lifecycle provenance (issue #996).
    pub fn with_instance_provenance(
        mut self,
        previous_status: impl Into<String>,
        previous_instance_id: Option<Uuid>,
    ) -> Self {
        self.previous_status = Some(previous_status.into());
        self.previous_instance_id = previous_instance_id.map(|id| id.to_string());
        self
    }
}

/// Run a capability search against the index. Pure and synchronous —
/// every callable path reuses this function.
pub fn search_service(index: &CapabilityIndex, query: &SearchQuery) -> Vec<SearchHit> {
    let snap = index.snapshot();
    search(&snap, query)
}

/// Search and materialise transport-neutral JSON rows. Unloaded
/// capability hits include a machine-executable `next_step` that both
/// MCP wrappers and REST clients can call directly.
pub fn search_service_rows(index: &CapabilityIndex, query: &SearchQuery) -> Vec<Value> {
    search_service(index, query)
        .into_iter()
        .map(search_hit_to_value)
        .collect()
}

pub fn search_hit_to_value(hit: SearchHit) -> Value {
    let mut value = serde_json::to_value(&hit).unwrap_or(Value::Null);
    if !hit.record.loaded
        && let Some(skill_name) = &hit.record.skill_name
    {
        value["next_step"] = json!({
            "action": "load_skill",
            "arguments": {
                "skill_name": skill_name,
                "dcc": &hit.record.dcc_type,
                "dcc_type": &hit.record.dcc_type,
                "instance_id": hit.record.instance_id.to_string(),
            },
            "rest": {
                "method": "POST",
                "path": "/v1/load_skill",
            },
            "mcp": {
                "name": "load_skill",
            },
        });
    }
    value
}

/// Resolve `slug` to its record. Returns a structured error when the
/// slug is malformed, unknown, or matches more than one row (the
/// ambiguous case can happen if callers pass a record that has since
/// been evicted but an older one with the same backend tool remains).
pub fn describe_service(
    index: &CapabilityIndex,
    slug: &str,
) -> Result<CapabilityRecord, ServiceError> {
    let Some((dcc, instance_hint, tool)) = parse_slug(slug) else {
        return Err(ServiceError::new(
            "unknown-slug",
            format!("slug {slug:?} is not in the <dcc>.<instance-id-prefix>.<tool> form"),
        ));
    };
    let snap = index.snapshot();
    let matches: Vec<&CapabilityRecord> = snap
        .records
        .iter()
        .filter(|r| record_matches_slug(r, dcc, instance_hint, tool))
        .collect();
    match matches.as_slice() {
        [] => Err(ServiceError::new(
            "instance-offline",
            format!("no capability registered with slug {slug:?}"),
        )
        .with_instance_provenance("never-registered", parse_instance_uuid(instance_hint))),
        [one] => Ok((*one).clone()),
        many => {
            let candidates: Vec<CapabilityRecord> = many.iter().map(|r| (*r).clone()).collect();
            Err(ServiceError::new(
                "ambiguous",
                format!(
                    "slug {slug:?} matches {} capability records — pick an instance by UUID",
                    candidates.len(),
                ),
            )
            .with_candidates(candidates))
        }
    }
}

fn record_matches_slug(
    record: &CapabilityRecord,
    dcc: &str,
    instance_hint: &str,
    tool: &str,
) -> bool {
    if !record.dcc_type.eq_ignore_ascii_case(dcc) || record.callable_id != tool {
        return false;
    }
    if let Ok(uuid) = Uuid::parse_str(instance_hint) {
        return record.instance_id == uuid;
    }
    record
        .instance_id
        .simple()
        .to_string()
        .starts_with(&instance_hint.to_ascii_lowercase())
}

/// Resolve `slug` and return the exact backend tool definition for that
/// capability. This is the schema-bearing describe path shared by REST and MCP.
///
/// Uses `POST /v1/describe` on the backend to fetch the **full** `input_schema`
/// (including `properties`), rather than the schema-free `/v1/search` response.
/// This fixes issue #992 where schemas were stripped.
pub async fn describe_tool_full(
    gs: &GatewayState,
    slug: &str,
) -> Result<(CapabilityRecord, McpTool), ServiceError> {
    let record = describe_service(&gs.capability_index, slug)?;
    let reg = gs.registry.read().await;
    let all = gs.live_instances(&reg);
    let Some(entry) = all.iter().find(|e| e.instance_id == record.instance_id) else {
        return Err(ServiceError::new(
            "instance-offline",
            format!(
                "instance {} ({}) is no longer live; refresh and retry",
                record.instance_id, record.dcc_type,
            ),
        )
        .with_instance_provenance("deregistered", Some(record.instance_id)));
    };
    let url = format!("http://{}:{}/mcp", entry.host, entry.port);
    drop(reg);

    // Use /v1/describe to get the full input_schema (issue #992).
    // The backend's resolve_slug accepts bare action names as well as
    // full <dcc>.<skill>.<action> slugs, so we can pass callable_id directly.
    let tool = try_describe_tool(
        &gs.http_client,
        &url,
        &record.callable_id,
        gs.backend_timeout,
    )
    .await
    .map_err(|e| {
        ServiceError::new(
            "schema-unavailable",
            format!("backend /v1/describe failed: {e}"),
        )
    })?;
    Ok((record, tool))
}

/// Call a backend action by slug. Returns the raw backend
/// `tools/call` envelope on success so REST and MCP wrappers can
/// forward it verbatim.
pub async fn call_service(
    gs: &GatewayState,
    slug: &str,
    arguments: Value,
    meta: Option<Value>,
) -> Result<Value, ServiceError> {
    let record = describe_service(&gs.capability_index, slug)?;
    // Resolve the backend endpoint using the live registry — the
    // capability record's `instance_id` is authoritative even if the
    // backend's port changed since indexing, because we always
    // look it up fresh here.
    let reg = gs.registry.read().await;
    let all = gs.live_instances(&reg);
    let Some(entry) = all.iter().find(|e| e.instance_id == record.instance_id) else {
        return Err(ServiceError::new(
            "instance-offline",
            format!(
                "instance {} ({}) is no longer live; refresh and retry",
                record.instance_id, record.dcc_type,
            ),
        )
        .with_instance_provenance("deregistered", Some(record.instance_id)));
    };
    let url = format!("http://{}:{}/mcp", entry.host, entry.port);
    let entry = entry.clone();
    drop(reg);

    match forward_tools_call(
        &gs.http_client,
        &url,
        &record.callable_id,
        Some(arguments),
        meta,
        None,
        gs.backend_timeout,
    )
    .await
    {
        Ok(mut result) => {
            inject_call_instance_meta(&mut result, &entry);
            Ok(result)
        }
        Err(e) => {
            if is_host_died_backend_error(&e) {
                record_host_died(gs, &entry, &record, &e);
                return Err(ServiceError::new(
                    "host-died",
                    format!("backend host died during {}: {e}", record.callable_id),
                ));
            }
            Err(ServiceError::new(
                "backend-error",
                format!("backend call failed: {e}"),
            ))
        }
    }
}

/// Helper — materialise a `SearchQuery` from the REST / MCP JSON
/// payload shape (`{query, dcc_type, tags, scene_hint, limit}`).
pub fn parse_search_payload(payload: &Value) -> SearchQuery {
    serde_json::from_value(payload.clone()).unwrap_or_default()
}

/// Refresh the capability index for every currently-live backend.
///
/// Called on-demand by the REST / MCP dynamic-capability entry
/// points so the first agent query after startup (or after a skill
/// load/unload) always sees fresh data without waiting for the
/// periodic watcher. Each backend's slice is short-circuited on an
/// unchanged fingerprint, so the extra `tools/list` round-trips are
/// free in the steady state.
///
/// Evicts records owned by instances that have disappeared from the
/// live registry — this is how `instance-offline` errors stay rare
/// after a backend crashes.
pub async fn refresh_all_live_backends(gs: &GatewayState, reason: RefreshReason) {
    let reg = gs.registry.read().await;
    let instances: Vec<_> = gs
        .live_instances(&reg)
        .into_iter()
        .filter(|e| {
            !matches!(
                e.status,
                dcc_mcp_transport::discovery::types::ServiceStatus::Unreachable
            )
        })
        .collect();
    drop(reg);

    // Remove records owned by instances that left between refreshes.
    let current: std::collections::HashSet<uuid::Uuid> =
        instances.iter().map(|e| e.instance_id).collect();
    let snap = gs.capability_index.snapshot();
    for iid in snap.fingerprints.keys() {
        if !current.contains(iid) {
            remove_instance(&gs.capability_index, *iid);
        }
    }

    // Refresh every live instance in parallel. Errors are logged and
    // swallowed — a single flaky backend must not break the others.
    let refreshes = instances.iter().map(|entry| {
        let url = format!("http://{}:{}/mcp", entry.host, entry.port);
        async move {
            refresh_instance(
                &gs.capability_index,
                &gs.http_client,
                &url,
                entry.instance_id,
                &entry.dcc_type,
                gs.backend_timeout,
                reason,
            )
            .await
        }
    });
    futures::future::join_all(refreshes).await;
}

/// Convert a [`ServiceError`] into the gateway's existing
/// `to_text_result` envelope shape so MCP wrappers return the same
/// error format as every other gateway meta-tool.
pub fn service_error_to_json(err: &ServiceError) -> Value {
    json!({
        "error": {
            "kind": err.kind,
            "message": err.message,
            "candidates": err.candidates,
            "previous_status": err.previous_status,
            "previous_instance_id": err.previous_instance_id,
        }
    })
}

fn inject_call_instance_meta(result: &mut Value, entry: &ServiceEntry) {
    let Some(obj) = result.as_object_mut() else {
        return;
    };

    let meta = obj.entry("_meta".to_string()).or_insert_with(|| json!({}));
    if !meta.is_object() {
        *meta = json!({});
    }
    let meta_obj = meta.as_object_mut().expect("_meta just normalised");
    let dcc = meta_obj
        .entry("dcc".to_string())
        .or_insert_with(|| json!({}));
    if !dcc.is_object() {
        *dcc = json!({});
    }
    let dcc_obj = dcc.as_object_mut().expect("_meta.dcc just normalised");
    dcc_obj.insert("dcc_type".to_string(), json!(entry.dcc_type));
    dcc_obj.insert(
        "instance_id".to_string(),
        json!(entry.instance_id.to_string()),
    );
    dcc_obj.insert(
        "instance_short".to_string(),
        json!(instance_short(&entry.instance_id)),
    );
    dcc_obj.insert("display_id".to_string(), json!(entry.display_id()));
}

fn is_host_died_backend_error(message: &str) -> bool {
    let lower = message.to_ascii_lowercase();
    lower.contains("host-died") || lower.contains("host_died")
}

fn record_host_died(
    gs: &GatewayState,
    entry: &ServiceEntry,
    record: &CapabilityRecord,
    backend_error: &str,
) {
    let mut reason = format!(
        "call={} display_id={} error={}",
        record.callable_id,
        entry.display_id(),
        backend_error
    );
    const MAX_REASON_CHARS: usize = 512;
    if reason.chars().count() > MAX_REASON_CHARS {
        reason = reason.chars().take(MAX_REASON_CHARS).collect();
        reason.push_str("...");
    }

    crate::gateway::event_log::record_event(
        &gs.event_log,
        #[cfg(feature = "prometheus")]
        &gs.gateway_metrics,
        crate::gateway::event_log::EventKind::HostDied,
        entry.dcc_type.clone(),
        instance_short(&entry.instance_id),
        Some(reason),
    );

    if gs.events_tx.receiver_count() > 0 {
        let notif = serde_json::to_string(&json!({
            "jsonrpc": "2.0",
            "method": "notifications/resources/updated",
            "params": {"uri": crate::gateway::handlers::resources::GATEWAY_EVENTS_URI}
        }))
        .unwrap_or_default();
        let _ = gs.events_tx.send(notif);
    }
}

fn parse_instance_uuid(instance_hint: &str) -> Option<Uuid> {
    Uuid::parse_str(instance_hint).ok()
}

#[cfg(test)]
mod unit_tests {
    use super::*;
    use crate::gateway::capability::{CapabilityRecord, InstanceFingerprint, tool_slug};
    use uuid::Uuid;

    fn push(index: &CapabilityIndex, dcc: &str, iid: Uuid, backend_tool: &str, loaded: bool) {
        let rec = CapabilityRecord::new(
            tool_slug(dcc, &iid, backend_tool),
            backend_tool.to_string(),
            backend_tool.to_string(),
            None,
            "",
            Vec::new(),
            dcc.to_string(),
            iid,
            false, // has_schema
            loaded,
        );
        index.upsert_instance(iid, vec![rec], InstanceFingerprint(1));
    }

    #[test]
    fn describe_returns_record_for_known_slug() {
        let idx = CapabilityIndex::new();
        let iid = Uuid::from_u128(0xabcd);
        push(&idx, "maya", iid, "create_sphere", true);
        let slug = tool_slug("maya", &iid, "create_sphere");
        let rec = describe_service(&idx, &slug).expect("slug should resolve");
        assert_eq!(rec.backend_tool, "create_sphere");
        assert_eq!(rec.dcc_type, "maya");
    }

    #[test]
    fn describe_accepts_full_uuid_slug() {
        let idx = CapabilityIndex::new();
        let iid = Uuid::parse_str("abcdef0123456789abcdef0123456789").unwrap();
        push(&idx, "maya", iid, "create_sphere", true);
        let slug = format!("maya.{iid}.create_sphere");

        let rec = describe_service(&idx, &slug).expect("full UUID slug should resolve");

        assert_eq!(rec.instance_id, iid);
        assert_eq!(rec.backend_tool, "create_sphere");
    }

    #[test]
    fn describe_rejects_malformed_slug() {
        let idx = CapabilityIndex::new();
        let err = describe_service(&idx, "not-a-slug").unwrap_err();
        assert_eq!(err.kind, "unknown-slug");
        // The malformed-slug error points at the expected shape so
        // the agent can fix its input instead of retrying blind.
        assert!(err.message.contains("<dcc>.<instance-id-prefix>.<tool>"));
    }

    #[test]
    fn describe_returns_unknown_for_live_but_unindexed_slug() {
        let idx = CapabilityIndex::new();
        // Shape is valid but nothing is indexed.
        let err = describe_service(&idx, "maya.abcdef01.create_sphere").unwrap_err();
        assert_eq!(err.kind, "instance-offline");
        assert_eq!(err.previous_status.as_deref(), Some("never-registered"));
    }

    #[test]
    fn search_service_uses_the_same_ranking_as_the_raw_helper() {
        // The REST / MCP surfaces MUST route through `search_service`;
        // this test pins that route by calling both paths and
        // checking the outputs are byte-identical.
        let idx = CapabilityIndex::new();
        let iid = Uuid::from_u128(1);
        push(&idx, "maya", iid, "create_sphere", true);
        push(&idx, "maya", iid, "open_scene", true);

        let q = SearchQuery {
            query: "sphere".into(),
            ..Default::default()
        };
        let via_service = search_service(&idx, &q);
        let via_raw = {
            let snap = idx.snapshot();
            search(&snap, &q)
        };
        let service_slugs: Vec<&str> = via_service
            .iter()
            .map(|h| h.record.tool_slug.as_str())
            .collect();
        let raw_slugs: Vec<&str> = via_raw
            .iter()
            .map(|h| h.record.tool_slug.as_str())
            .collect();
        assert_eq!(service_slugs, raw_slugs);
    }

    #[test]
    fn search_service_rows_adds_executable_load_skill_next_step() {
        let idx = CapabilityIndex::new();
        let iid = Uuid::parse_str("abcdef0123456789abcdef0123456789").unwrap();
        let rec = CapabilityRecord::new(
            tool_slug("maya", &iid, "maya_primitives__create_sphere"),
            "maya_primitives__create_sphere".to_string(),
            "maya_primitives__create_sphere".to_string(),
            Some("maya-primitives".to_string()),
            "Create a sphere",
            Vec::new(),
            "maya".to_string(),
            iid,
            true,
            false,
        );
        idx.upsert_instance(iid, vec![rec], InstanceFingerprint(1));

        let rows = search_service_rows(
            &idx,
            &SearchQuery {
                query: "sphere".into(),
                loaded_only: Some(false),
                ..Default::default()
            },
        );

        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0]["next_step"]["action"], "load_skill");
        assert_eq!(
            rows[0]["next_step"]["arguments"]["skill_name"],
            "maya-primitives"
        );
        assert_eq!(rows[0]["next_step"]["arguments"]["dcc"], "maya");
        assert_eq!(
            rows[0]["next_step"]["arguments"]["instance_id"],
            iid.to_string()
        );
        assert_eq!(rows[0]["next_step"]["rest"]["path"], "/v1/load_skill");
    }

    #[test]
    fn service_error_to_json_preserves_shape() {
        // The REST + MCP wrappers both serialise ServiceError through
        // this helper; the wire shape must stay stable so clients can
        // branch on `error.kind` without fuzzy matching.
        let err = ServiceError::new("unknown-slug", "x").with_candidates(Vec::new());
        let j = service_error_to_json(&err);
        assert_eq!(j["error"]["kind"], "unknown-slug");
        assert_eq!(j["error"]["message"], "x");
        assert_eq!(j["error"]["candidates"].as_array().unwrap().len(), 0);
    }

    #[test]
    fn call_result_meta_includes_display_id() {
        let mut entry =
            dcc_mcp_transport::discovery::types::ServiceEntry::new("maya", "127.0.0.1", 8765);
        entry.instance_id = Uuid::parse_str("abcdef0123456789abcdef0123456789").unwrap();
        entry.version = Some("2026".to_string());
        let mut result = json!({"slug": "maya.test.tool", "output": {"ok": true}});

        inject_call_instance_meta(&mut result, &entry);

        assert_eq!(result["_meta"]["dcc"]["dcc_type"], "maya");
        assert_eq!(
            result["_meta"]["dcc"]["instance_id"],
            "abcdef01-2345-6789-abcd-ef0123456789"
        );
        assert_eq!(result["_meta"]["dcc"]["instance_short"], "abcdef01");
        assert_eq!(result["_meta"]["dcc"]["display_id"], "maya@2026-abcdef01");
    }

    #[test]
    fn host_died_classifier_matches_kebab_and_snake_case() {
        assert!(is_host_died_backend_error(
            r#"HTTP 502: {"error":{"kind":"host-died"}}"#
        ));
        assert!(is_host_died_backend_error("event=host_died"));
        assert!(!is_host_died_backend_error(
            "transport error: connection refused"
        ));
    }

    #[test]
    fn parse_search_payload_defaults_when_fields_missing() {
        // Both REST and MCP wrappers pass the caller's JSON straight
        // in; missing fields must default rather than fail so empty
        // queries (`{}`) become a catalogue browse.
        let q = parse_search_payload(&json!({}));
        assert!(q.query.is_empty());
        assert!(q.dcc_type.is_none());
        assert!(q.tags.is_empty());
        assert!(q.scene_hint.is_none());
        assert!(q.limit.is_none());
    }
}
