# find-skills

Teach Claude Code how to search for and install skills from the
[AgentPowers](https://agentpowers.ai) marketplace without leaving your session.

## Searching for skills

```bash
ap search <query>
```

Returns a ranked list of skills with title, author, price, and security status.

### Examples

```bash
ap search "code review"
ap search clerk          # find all skills by the clerk seller
ap search pdf parsing
```

## Installing a skill

```bash
# By slug (searches all sellers)
ap install <slug>

# By author/slug (resolves to a specific seller's skill)
ap install <author>/<slug>

# Install globally (always to the tool's config dir)
ap install --global <slug>

# Install for a specific AI tool
ap install --for codex <slug>       # installs to ~/.codex/skills/
ap install --for claude-code <slug> # installs to ~/.claude/skills/ (default)
```

When you run `ap install` from a directory that already has a `.claude/` folder,
the skill is installed project-locally to `<cwd>/.claude/skills/`. Otherwise it
installs globally to `~/.claude/skills/`.

The `--for` flag targets a specific AI tool. Supported values: `claude-code`,
`codex`. Use `--global` with `--for claude-code` to force global install even
when a local `.claude/` directory exists.

### Install examples

```bash
ap install clerk/webhooks-assistant
ap install pdf-parser
ap install --global git-commit-helper
ap install --for codex pdf-parser           # install for OpenAI Codex CLI
ap install --for claude-code --global pdf-parser  # force global claude-code install
```

## Checking what's installed

```bash
ap list             # list all installed skills with versions
ap status <slug>    # show security status + pin info for one skill
```

## Updating a skill

```bash
ap update <slug>    # update to the latest version
ap update --all     # update all pinned skills
```

## How to use this skill

When a user asks you to find, search, or install a skill:

1. Suggest running `ap search <relevant-query>` in the terminal.
2. Show the user the results and ask which one to install.
3. Run `ap install <author>/<slug>` for the chosen skill.
4. Confirm the install path shown in the success message.

The `ap` CLI tool is part of the
[AgentPowers CLI](https://agentpowers.ai/docs/cli-usage). Install it with:

```bash
pip install agentpowers-cli
```
