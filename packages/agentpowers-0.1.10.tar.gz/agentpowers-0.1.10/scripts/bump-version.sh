#!/usr/bin/env bash
# Bump the CLI package version, generate changelog, commit, and tag.
#
# Usage:
#   ./scripts/bump-version.sh patch   # 0.1.0 → 0.1.1
#   ./scripts/bump-version.sh minor   # 0.1.0 → 0.2.0
#   ./scripts/bump-version.sh major   # 0.1.0 → 1.0.0
#   ./scripts/bump-version.sh 0.2.0   # explicit version

set -euo pipefail

cd "$(dirname "$0")/.."

PYPROJECT="pyproject.toml"
CHANGELOG="CHANGELOG.md"
BUMP="${1:-patch}"

# Read current version
CURRENT=$(grep '^version' "$PYPROJECT" | head -1 | sed 's/version = "\(.*\)"/\1/')
echo "Current version: $CURRENT"

# Compute new version
if [[ "$BUMP" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    NEW="$BUMP"
else
    IFS='.' read -r MAJOR MINOR PATCH <<< "$CURRENT"
    case "$BUMP" in
        major) NEW="$((MAJOR + 1)).0.0" ;;
        minor) NEW="$MAJOR.$((MINOR + 1)).0" ;;
        patch) NEW="$MAJOR.$MINOR.$((PATCH + 1))" ;;
        *) echo "Usage: $0 {patch|minor|major|X.Y.Z}" >&2; exit 1 ;;
    esac
fi
echo "New version: $NEW"

# Update pyproject.toml
# Portable in-place sed (macOS needs -i '', Linux needs -i without arg)
if sed --version 2>/dev/null | grep -q GNU; then
    sed -i "s/^version = \"$CURRENT\"/version = \"$NEW\"/" "$PYPROJECT"
else
    sed -i '' "s/^version = \"$CURRENT\"/version = \"$NEW\"/" "$PYPROJECT"
fi

# Generate changelog entry from git log since last tag
LAST_TAG=$(git tag --list 'cli-v*' --sort=-version:refname | head -1)
if [ -z "$LAST_TAG" ]; then
    COMMITS=$(git log --oneline --no-decorate -- agentpowers-cli/ | head -20)
else
    COMMITS=$(git log --oneline --no-decorate "$LAST_TAG"..HEAD -- agentpowers-cli/ | head -20)
fi

DATE=$(date +%Y-%m-%d)
ENTRY="## [$NEW] - $DATE

### Changes

$(echo "$COMMITS" | sed 's/^[a-f0-9]* /- /')
"

# Prepend to CHANGELOG.md (create if missing)
if [ -f "$CHANGELOG" ]; then
    # Insert after the first heading line
    TEMP=$(mktemp)
    echo "# Changelog" > "$TEMP"
    echo "" >> "$TEMP"
    echo "$ENTRY" >> "$TEMP"
    # Append everything after the first line of the existing changelog
    tail -n +2 "$CHANGELOG" >> "$TEMP"
    mv "$TEMP" "$CHANGELOG"
else
    echo "# Changelog" > "$CHANGELOG"
    echo "" >> "$CHANGELOG"
    echo "$ENTRY" >> "$CHANGELOG"
fi

echo ""
echo "Updated $PYPROJECT: $CURRENT → $NEW"
echo "Updated $CHANGELOG"
echo ""
echo "Next steps:"
echo "  git add $PYPROJECT $CHANGELOG"
echo "  git commit -m 'release: agentpowers v$NEW'"
echo "  git tag cli-v$NEW"
echo "  git push origin main --tags"
