"""AgentPowers CLI banner — brand mark and version display."""

from __future__ import annotations

from importlib.metadata import version as pkg_version

from rich.console import Console

# Brand teal: #5fbab8
TEAL = "#5fbab8"


def _get_version() -> str:
    """Return the installed CLI version, falling back to 0.1.0."""
    try:
        return pkg_version("agentpowers")
    except Exception:
        return "0.1.0"


def print_banner(console: Console | None = None) -> None:
    """Print the AgentPowers brand banner to the console.

    Three geometric teal shapes forming a stylized 'A' mark.

    Args:
        console: Rich Console instance. Creates one if not provided.
    """
    if console is None:
        console = Console()

    ver = _get_version()

    console.print()
    console.print(f"  [{TEAL}]    ████[/{TEAL}]")
    console.print(
        f"  [{TEAL}]     ████[/{TEAL}]"
        f"       [bold]AgentPowers[/bold]  [dim]v{ver}[/dim]"
    )
    console.print(
        f"  [{TEAL}]      ████[/{TEAL}]"
        f"      [dim]Premium Claude skills & agents[/dim]"
    )
    console.print(
        f"  [{TEAL}] █[/{TEAL}]"
        f"     [{TEAL}]████[/{TEAL}]"
        f"     [dim]agentpowers.ai[/dim]"
    )
    console.print(
        f"  [{TEAL}]███[/{TEAL}]"
        f"     [{TEAL}]████[/{TEAL}]"
    )
    console.print(f"  [{TEAL}]   ██████[/{TEAL}]")
    console.print(f"  [{TEAL}]    ████[/{TEAL}]")
    console.print(f"  [{TEAL}]     ██[/{TEAL}]")
    console.print()
