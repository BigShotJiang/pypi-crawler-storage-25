"""HTTP client for the AgentPowers API.

Provides an APIClient class that wraps httpx for making authenticated
requests to the AgentPowers backend.
"""

from __future__ import annotations

from typing import Any

import httpx

from agentpowers_cli.services.auth_store import load_token
from agentpowers_cli.services.config import API_BASE_URL


class APIError(Exception):
    """Raised when an API request fails with a non-2xx status code.

    Attributes:
        status_code: The HTTP status code from the response.
    """

    def __init__(self, message: str, status_code: int = 0) -> None:
        super().__init__(message)
        self.status_code = status_code


class APIClient:
    """HTTP client for interacting with the AgentPowers API.

    Args:
        base_url: The base URL of the API server.
    """

    def __init__(self, base_url: str = API_BASE_URL, timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _get_auth_headers(self, auth: bool) -> dict[str, str]:
        """Build authorization headers if auth is required.

        Args:
            auth: Whether to include the Bearer token.

        Returns:
            Headers dict, possibly including Authorization.

        Raises:
            APIError: If auth is required but no token is stored.
        """
        if not auth:
            return {}
        token = load_token()
        if token is None:
            raise APIError("Not authenticated. Run `ap login` first.", status_code=401)
        return {"Authorization": f"Bearer {token}"}

    def _do_request(
        self,
        method: str,
        path: str,
        *,
        headers: dict[str, str],
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Issue a single HTTP request with consistent network-error handling.

        Translates httpx.ConnectError / TimeoutException / ConnectTimeout
        into APIError so callers only need to catch one exception type.
        Previously these errors bubbled raw and dumped a Python traceback
        to the user's terminal on any transient network blip.
        """
        url = f"{self.base_url}{path}"
        try:
            with httpx.Client(timeout=self.timeout) as client:
                # Dispatch to the appropriate method so existing tests that
                # mock client.get/post/patch (not client.request) still work.
                if method == "GET":
                    return client.get(
                        url, headers=headers, params=params or {}
                    )
                if method == "POST":
                    return client.post(url, headers=headers, json=json_data)
                if method == "PATCH":
                    return client.patch(url, headers=headers, json=json_data)
                # Fallback for any future method
                return client.request(
                    method,
                    url,
                    headers=headers,
                    params=params or {},
                    json=json_data,
                )
        except httpx.ConnectError as exc:
            raise APIError(
                f"Could not connect to {self.base_url}. "
                "Check your network connection and try again.",
                status_code=0,
            ) from exc
        except httpx.TimeoutException as exc:
            raise APIError(
                "Request timed out. The API may be temporarily unavailable.",
                status_code=0,
            ) from exc
        except httpx.RequestError as exc:
            # Catch-all for other transport-layer failures (DNS, SSL, etc.)
            # so we never leak a raw traceback for network-layer issues.
            raise APIError(
                f"Network error contacting {self.base_url}: {exc}",
                status_code=0,
            ) from exc

    def _handle_response(self, response: httpx.Response) -> Any:
        """Process an HTTP response, raising on errors.

        Args:
            response: The httpx Response object.

        Returns:
            Parsed JSON response body.

        Raises:
            APIError: If the response status is not successful.
        """
        if not response.is_success:
            try:
                detail = response.json().get("detail", "Unknown error")
            except Exception:
                detail = "Unknown error"
            # Format FastAPI 422 validation errors into readable messages
            if isinstance(detail, list):
                messages = []
                for err in detail:
                    if isinstance(err, dict):
                        msg = err.get("msg", "")
                        loc = err.get("loc", [])
                        field = ".".join(str(p) for p in loc) if loc else ""
                        messages.append(f"{field}: {msg}" if field else msg)
                    else:
                        messages.append(str(err))
                detail = "; ".join(messages) if messages else "Validation error"
            raise APIError(str(detail), status_code=response.status_code)
        try:
            return response.json()
        except Exception:
            raise APIError(
                "Server returned invalid JSON",
                status_code=response.status_code,
            )

    def get(
        self,
        path: str,
        auth: bool = False,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Send a GET request to the API.

        Args:
            path: The API endpoint path (e.g., "/v1/skills").
            auth: Whether to include authentication headers.
            params: Optional query parameters.

        Returns:
            Parsed JSON response.

        Raises:
            APIError: On authentication failure or non-2xx response.
        """
        headers = self._get_auth_headers(auth)
        response = self._do_request("GET", path, headers=headers, params=params)
        return self._handle_response(response)

    def post(
        self,
        path: str,
        json_data: dict[str, Any] | None = None,
        auth: bool = False,
    ) -> Any:
        """Send a POST request to the API.

        Args:
            path: The API endpoint path.
            json_data: JSON body to send.
            auth: Whether to include authentication headers.

        Returns:
            Parsed JSON response.

        Raises:
            APIError: On authentication failure or non-2xx response.
        """
        headers = self._get_auth_headers(auth)
        response = self._do_request("POST", path, headers=headers, json_data=json_data)
        return self._handle_response(response)

    def patch(
        self,
        path: str,
        json_data: dict[str, Any] | None = None,
        auth: bool = False,
    ) -> Any:
        """Send a PATCH request to the API.

        Args:
            path: The API endpoint path.
            json_data: JSON body to send.
            auth: Whether to include authentication headers.

        Returns:
            Parsed JSON response.

        Raises:
            APIError: On authentication failure or non-2xx response.
        """
        headers = self._get_auth_headers(auth)
        response = self._do_request("PATCH", path, headers=headers, json_data=json_data)
        return self._handle_response(response)

    def record_installation(
        self,
        source_slug: str,
        platform: str,
        source: str,
        hostname: str,
    ) -> None:
        """Fire-and-forget installation tracking. Never raises on failure.

        Sends the auth token if one is stored; omits it otherwise.
        """
        token = load_token()
        headers: dict[str, str] = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        try:
            with httpx.Client(timeout=self.timeout) as client:
                client.post(
                    f"{self.base_url}/v1/installations",
                    headers=headers,
                    json={
                        "source_slug": source_slug,
                        "platform": platform,
                        "source": source,
                        "hostname": hostname,
                    },
                )
        except Exception:
            pass

    def upload(
        self,
        path: str,
        file_data: bytes,
        filename: str,
        auth: bool = True,
    ) -> Any:
        """Upload a file to the API.

        Args:
            path: The API endpoint path.
            file_data: Raw file bytes to upload.
            filename: The filename for the upload.
            auth: Whether to include authentication headers.

        Returns:
            Parsed JSON response.

        Raises:
            APIError: On authentication failure or non-2xx response.
        """
        headers = self._get_auth_headers(auth)
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                f"{self.base_url}{path}",
                headers=headers,
                files={"file": (filename, file_data)},
            )
        return self._handle_response(response)
