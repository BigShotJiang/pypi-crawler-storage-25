"""Package a skill or agent directory into a ZIP archive.

Handles metadata extraction from SKILL.md frontmatter (skills) or
agent ``.md`` files with YAML frontmatter containing ``name`` and
``description`` fields (agents), plus directory packaging with
sensible exclusions.
"""

from __future__ import annotations

import io
import re
import zipfile
from pathlib import Path

EXCLUDE_DIRS: set[str] = {".git", ".venv", "__pycache__", "node_modules", ".claude"}
EXCLUDE_EXTENSIONS: set[str] = {".pyc", ".pyo"}

# Required frontmatter fields for agent detection
_AGENT_REQUIRED_FIELDS: set[str] = {"name", "description"}


def load_skill_metadata(directory: Path) -> dict[str, str] | None:
    """Load skill or agent metadata from a directory.

    Detection logic:

    1. If the directory contains ``SKILL.md`` -> type is ``"skill"``.
    2. Otherwise, scan for ``.md`` files with YAML frontmatter that
       contains both ``name`` and ``description`` fields -> type is
       ``"agent"``.  The first matching file wins.

    Claude Code agents are individual ``.md`` files (e.g.
    ``code-reviewer.md``) with YAML frontmatter fields like ``name``,
    ``description``, ``tools``, ``model``, etc.

    Args:
        directory: The directory to search for metadata files.

    Returns:
        Dict with name, description, and type keys, or None if no
        metadata file is found.
    """
    # Priority 1: SKILL.md -> skill
    skill_md = directory / "SKILL.md"
    if skill_md.exists():
        text = skill_md.read_text(encoding="utf-8")
        meta = _parse_frontmatter(text)
        meta["type"] = "skill"
        return meta

    # Priority 2: any .md file with name + description frontmatter -> agent
    for md_file in sorted(directory.glob("*.md")):
        text = md_file.read_text(encoding="utf-8")
        meta = _parse_frontmatter(text)
        if _AGENT_REQUIRED_FIELDS.issubset(meta.keys()):
            meta["type"] = "agent"
            return meta

    return None


def _parse_frontmatter(text: str) -> dict[str, str]:
    """Extract YAML frontmatter key-value pairs from text.

    Parses simple ``key: value`` lines between ``---`` delimiters.
    Does not handle nested YAML structures.

    Args:
        text: The full file text including frontmatter.

    Returns:
        Dict of parsed frontmatter fields.
    """
    match = re.search(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not match:
        return {}

    result: dict[str, str] = {}
    for line in match.group(1).splitlines():
        line = line.strip()
        if ":" in line:
            key, _, value = line.partition(":")
            result[key.strip()] = value.strip().strip('"').strip("'")
    return result


def package_directory(directory: Path) -> bytes:
    """Package a directory into an in-memory ZIP archive.

    Walks the directory tree, excluding hidden parent directories,
    known non-essential directories, and compiled file extensions.

    Args:
        directory: The root directory to package.

    Returns:
        Raw bytes of the ZIP archive.
    """
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for file_path in sorted(directory.rglob("*")):
            if file_path.is_dir():
                continue

            relative = file_path.relative_to(directory)

            # Skip files inside excluded directories
            if any(part in EXCLUDE_DIRS for part in relative.parts):
                continue

            # Skip files inside hidden directories (starting with '.')
            if any(part.startswith(".") for part in relative.parent.parts):
                continue

            # Skip excluded file extensions
            if file_path.suffix in EXCLUDE_EXTENSIONS:
                continue

            zf.write(file_path, relative)

    return buf.getvalue()
