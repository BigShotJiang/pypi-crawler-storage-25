"""Version pinning manager -- tracks installed skill hashes.

Stores version pins at ~/.agentpowers/pins.json to enable integrity
verification and update detection for installed skills.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

DEFAULT_PINS_PATH = str(Path.home() / ".agentpowers" / "pins.json")


def load_pins(pins_path: str = DEFAULT_PINS_PATH) -> dict:
    """Load all version pins from disk.

    Args:
        pins_path: Path to the pins JSON file.

    Returns:
        Dict mapping slug to pin metadata, or empty dict if file missing.
    """
    path = Path(pins_path)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def save_pin(
    slug: str,
    source: str,
    version: str | None,
    content_hash: str,
    security_status: str,
    skill_type: str = "skill",
    pins_path: str = DEFAULT_PINS_PATH,
    install_location: str | None = None,
) -> None:
    """Save a version pin for an installed skill.

    Creates the parent directory if needed and writes the pin data
    as JSON. Overwrites any existing pin for the same slug.

    Args:
        slug: The skill slug.
        source: Origin source (e.g. "clawhub", "agentpowers").
        version: The version string, or None if unknown.
        content_hash: SHA-256 hash of the package contents.
        security_status: Security scan result ("pass", "warn", "block").
        skill_type: Either "skill" or "agent".
        pins_path: Path to the pins JSON file.
        install_location: Absolute path to the installed directory.
    """
    path = Path(pins_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pins = load_pins(pins_path)
    now = datetime.now(UTC).isoformat()
    pins[slug] = {
        "source": source,
        "version": version,
        "content_hash": content_hash,
        "installed_at": now,
        "scanned_at": now,
        "security_status": security_status,
        "type": skill_type,
        "install_location": install_location,
    }
    path.write_text(json.dumps(pins, indent=2))


def verify_pin(
    slug: str, content_hash: str, pins_path: str = DEFAULT_PINS_PATH
) -> bool | None:
    """Verify a skill's content hash against its stored pin.

    Args:
        slug: The skill slug to check.
        content_hash: The current content hash to verify.
        pins_path: Path to the pins JSON file.

    Returns:
        True if hash matches, False if mismatch, None if no pin exists.
    """
    pins = load_pins(pins_path)
    if slug not in pins:
        return None
    stored_hash = pins[slug].get("content_hash")
    if stored_hash is None:
        return None
    return stored_hash == content_hash
