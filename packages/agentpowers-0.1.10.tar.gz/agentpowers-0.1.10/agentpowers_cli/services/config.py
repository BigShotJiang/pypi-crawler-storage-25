"""CLI configuration constants."""

import os

API_BASE_URL = os.environ.get(
    "AGENTPOWERS_API_URL", "https://api.agentpowers.ai"
)
AUTH_CALLBACK_HOST = "127.0.0.1"
SITE_URL = os.environ.get(
    "AGENTPOWERS_SITE_URL", "https://agentpowers.ai"
)
CLERK_FRONTEND_URL = os.environ.get(
    "CLERK_FRONTEND_URL", "https://accounts.agentpowers.ai"
)
