"""Credential storage for AgentPowers CLI.

Stores authentication tokens at ~/.agentpowers/auth.json with
restricted file permissions (0o600) for security.
"""

from __future__ import annotations

import json
from pathlib import Path


def get_auth_dir() -> Path:
    """Return the AgentPowers config directory path.

    Returns:
        Path to ~/.agentpowers directory.
    """
    return Path.home() / ".agentpowers"


def get_auth_file() -> Path:
    """Return the auth token file path.

    Returns:
        Path to ~/.agentpowers/auth.json.
    """
    return get_auth_dir() / "auth.json"


def save_token(token: str) -> None:
    """Save an authentication token to disk.

    Creates the config directory if it doesn't exist and sets
    file permissions to 0o600 (owner read/write only).

    Args:
        token: The JWT token to persist.
    """
    auth_file = get_auth_file()
    auth_dir = auth_file.parent
    auth_dir.mkdir(parents=True, exist_ok=True)
    auth_dir.chmod(0o700)
    auth_file.write_text(json.dumps({"token": token}))
    auth_file.chmod(0o600)


def load_token() -> str | None:
    """Load the stored authentication token.

    Returns:
        The JWT token string, or None if no token is stored
        or the file is invalid.
    """
    auth_file = get_auth_file()
    if not auth_file.exists():
        return None
    try:
        data = json.loads(auth_file.read_text())
        return data.get("token")
    except (json.JSONDecodeError, KeyError):
        return None


def delete_token() -> None:
    """Remove the stored authentication token file.

    Does nothing if the file doesn't exist.
    """
    auth_file = get_auth_file()
    if auth_file.exists():
        auth_file.unlink()
