"""Content hashing utility -- SHA-256 hash of directory or file contents.

Used by the external installer to compute deterministic content hashes
for security scan caching and version pinning.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

# OS-generated files and directories to exclude from content hashing.
# Including these causes false "Edited" detection when Finder visits a
# skill directory or Python bytecode is generated.
_EXCLUDED_NAMES = {".DS_Store", "Thumbs.db", "__pycache__"}
_EXCLUDED_SUFFIXES = {".pyc", ".pyo"}


def _should_skip(file_path: Path) -> bool:
    """Return True if the file is an OS artifact that should be excluded."""
    if file_path.name in _EXCLUDED_NAMES:
        return True
    if file_path.suffix in _EXCLUDED_SUFFIXES:
        return True
    # Skip files inside excluded directories (e.g. __pycache__/foo.pyc)
    for part in file_path.parts:
        if part in _EXCLUDED_NAMES:
            return True
    return False


def hash_directory(dir_path: str) -> str:
    """Compute a SHA-256 hash of all file contents in a directory.

    Files are sorted by relative path for deterministic results.
    OS-generated files (.DS_Store, __pycache__, .pyc, Thumbs.db)
    are excluded so that browsing a directory in Finder or importing
    Python modules does not change the hash.

    Args:
        dir_path: Path to the directory to hash.

    Returns:
        A string like "sha256:abcdef1234...".
    """
    root = Path(dir_path)
    hasher = hashlib.sha256()
    for file_path in sorted(root.rglob("*")):
        if file_path.is_file() and not _should_skip(file_path.relative_to(root)):
            rel = str(file_path.relative_to(root))
            hasher.update(rel.encode("utf-8"))
            hasher.update(file_path.read_bytes())
    return f"sha256:{hasher.hexdigest()}"


def hash_bytes(data: bytes) -> str:
    """Compute a SHA-256 hash of raw bytes.

    Args:
        data: Raw bytes to hash.

    Returns:
        A string like "sha256:abcdef1234...".
    """
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


def hash_files(files: dict[str, bytes]) -> str:
    """Compute a SHA-256 hash of a file dict (filename -> bytes).

    Files are sorted by key for deterministic results.

    Args:
        files: Mapping of file paths to their byte contents.

    Returns:
        A string like "sha256:abcdef1234...".
    """
    hasher = hashlib.sha256()
    for name in sorted(files.keys()):
        hasher.update(name.encode("utf-8"))
        hasher.update(files[name])
    return f"sha256:{hasher.hexdigest()}"
