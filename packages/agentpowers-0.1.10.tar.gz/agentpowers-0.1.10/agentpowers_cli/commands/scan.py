"""Scan command -- download external skill to sandbox, scan, display results.

Downloads an external skill to a temporary sandbox, uploads the ZIP to the
server for security scanning, displays findings, and cleans up. No
installation occurs.
"""

from __future__ import annotations

import io
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

import httpx
import typer
from rich.console import Console
from rich.panel import Panel

from agentpowers_cli.services.api_client import APIClient, APIError
from agentpowers_cli.services.auth_store import load_token
from agentpowers_cli.services.config import API_BASE_URL

console = Console()


def get_api_client() -> APIClient:
    """Create and return an APIClient instance."""
    return APIClient()


class _NativeSkillError(Exception):
    """Raised when the slug is a native AgentPowers skill, not external."""

    def __init__(self, slug: str) -> None:
        self.slug = slug
        super().__init__(f"'{slug}' is a native AgentPowers skill")


def _resolve_source(client: APIClient, slug: str) -> str | None:
    """Search for a slug across external sources and return the source name.

    Returns:
        Source name (e.g. "clawhub") or None if not found.

    Raises:
        _NativeSkillError: If the skill is found in the agentpowers section.
    """
    try:
        data = client.get("/v1/search", params={"q": slug, "limit": 50})
    except (APIError, httpx.TimeoutException, httpx.ConnectError):
        return None

    # Check if it's a native AgentPowers skill first
    ap_section = data.get("agentpowers", {})
    for item in ap_section.get("items", []):
        if item.get("slug") == slug:
            raise _NativeSkillError(slug)

    # Check external sections for an exact slug match
    for source_name, section in data.items():
        if source_name == "agentpowers":
            continue
        items = section.get("items", [])
        for item in items:
            if item.get("slug") == slug:
                return source_name

    return None


def _download_to_sandbox(slug: str, source: str) -> tuple[str, str]:
    """Download skill to a temporary sandbox directory.

    Args:
        slug: The skill slug.
        source: External source name (e.g. "clawhub").

    Returns:
        Tuple of (sandbox_path, source_name).

    Raises:
        RuntimeError: If download fails.
    """
    sandbox = tempfile.mkdtemp(prefix="ap-scan-")
    result = subprocess.run(
        ["npx", source, "install", slug, "--no-input", "--dir", sandbox],
        capture_output=True,
        text=True,
        timeout=60,
    )
    if result.returncode != 0:
        shutil.rmtree(sandbox, ignore_errors=True)
        raise RuntimeError(f"Download failed: {result.stderr}")

    return sandbox, source


def _upload_for_scan(
    sandbox_dir: str,
    source: str,
    slug: str,
    skill_type: str = "skill",
) -> dict:
    """Package sandbox contents and upload for security scanning.

    Args:
        sandbox_dir: Path to the sandbox directory.
        source: External source name.
        slug: The skill slug.
        skill_type: Either "skill" or "agent".

    Returns:
        Server response dict with content_hash, security_status, etc.

    Raises:
        RuntimeError: On upload failure.
    """
    buf = io.BytesIO()
    sandbox_path = Path(sandbox_dir)
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for file_path in sorted(sandbox_path.rglob("*")):
            if file_path.is_file():
                arcname = str(file_path.relative_to(sandbox_path))
                zf.write(file_path, arcname)
    buf.seek(0)

    token = load_token()
    headers: dict[str, str] = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    try:
        with httpx.Client() as http:
            resp = http.post(
                f"{API_BASE_URL}/v1/security/scan-package",
                data={
                    "content_hash": "",
                    "source": source,
                    "source_slug": slug,
                    "source_version": "",
                    "skill_type": skill_type,
                },
                files={"package": ("package.zip", buf, "application/zip")},
                headers=headers,
                timeout=120,
            )
            resp.raise_for_status()
            return resp.json()
    except httpx.HTTPError as exc:
        raise RuntimeError(f"Scan upload failed: {exc}")


def _format_status(status: str) -> str:
    """Format security status with Rich color."""
    if status == "pass":
        return "[green]PASS[/green]"
    if status == "warn":
        return "[yellow]WARN[/yellow]"
    if status == "block":
        return "[red]BLOCK[/red]"
    return status.upper()


def _layer_icon(status: str) -> str:
    """Return a colored icon for a layer status."""
    if status == "pass":
        return "[green]OK[/green]"
    if status in ("skip", "not_applicable"):
        return "[dim]--[/dim]"
    return "[red]!![/red]"


def _severity_color(severity: str) -> str:
    """Map severity to a Rich color."""
    s = severity.upper()
    if s == "HIGH":
        return "red"
    if s == "MEDIUM":
        return "yellow"
    return "dim"


def _extract_detail(finding: dict | str) -> str:
    """Extract a human-readable detail string from a finding."""
    if isinstance(finding, str):
        return finding
    # Try common field names in order of preference
    for key in ("detail", "message", "description"):
        val = finding.get(key)
        if val and isinstance(val, str):
            # Trim verbose VirusTotal analysis IDs
            if "did not complete within" in val:
                return "VirusTotal analysis timed out (non-blocking)"
            return val
    # Last resort: stringify the dict
    return str(finding)


def _display_results(slug: str, source: str, result: dict) -> None:
    """Render scan results with per-layer breakdown and actionable guidance."""
    status_str = result.get("security_status", "unknown")
    layers = result.get("layers", [])
    findings = result.get("findings", [])

    border = (
        "green" if status_str == "pass"
        else "yellow" if status_str == "warn"
        else "red"
    )
    header = f"Security Scan: {_format_status(status_str)}"

    lines: list[str] = [f"Skill: [bold]{slug}[/bold]  Source: {source}", ""]

    # Per-layer breakdown (only if server returned layer details)
    if layers:
        lines.append("[bold]Scans Run:[/bold]")
    for layer in layers:
        name = layer.get("name", "Unknown")
        lstatus = layer.get("status", "pass")
        icon = _layer_icon(lstatus)
        layer_findings = layer.get("findings", [])

        if not layer_findings:
            lines.append(f"  {icon}  {name}")
        else:
            count = len(layer_findings)
            sfx = "s" if count != 1 else ""
            lines.append(
                f"  {icon}  {name}  ({count} finding{sfx})"
            )
            for f in layer_findings:
                sev = f.get("severity", "INFO") if isinstance(f, dict) else "INFO"
                detail = _extract_detail(f)
                color = _severity_color(sev)
                lines.append(f"       [{color}]{sev}[/{color}] {detail}")

    # Fallback: if no layers but there are findings, show them flat
    if not layers and findings:
        # Separate actionable findings from informational notes
        actionable = []
        notes = []
        for f in findings:
            detail = _extract_detail(f)
            if isinstance(f, dict):
                sev = f.get("severity", "INFO")
                if sev == "INFO":
                    notes.append(detail)
                else:
                    color = _severity_color(sev)
                    actionable.append(f"  [{color}]{sev}[/{color}] {detail}")
            else:
                actionable.append(f"  {detail}")

        if actionable:
            lines.append("")
            lines.append("[bold]Findings:[/bold]")
            lines.extend(actionable)

        if notes:
            lines.append("")
            lines.append("[dim]Notes:[/dim]")
            for note in notes:
                lines.append(f"  [dim]{note}[/dim]")

    # If no layers and no findings, show a generic message
    if not layers and not findings:
        lines.append("[dim]No detailed scan breakdown available (cached result).[/dim]")

    # Actionable guidance
    lines.append("")
    if status_str == "pass":
        lines.append(
            f"[green]Safe to install.[/green] Run: "
            f"[bold]ap install {slug} --source {source}[/bold]"
        )
    elif status_str == "warn":
        lines.append(
            "[yellow]Warnings detected.[/yellow] "
            "Review the findings above before installing."
        )
        lines.append(
            "To install anyway: "
            f"[bold]ap install {slug} --source {source}[/bold]"
        )
    elif status_str == "block":
        lines.append(
            "[red]Blocked.[/red] This skill failed security "
            "checks and cannot be installed."
        )
        lines.append(
            "If you believe this is a false positive, "
            "report it to the skill author."
        )

    console.print(Panel("\n".join(lines), title=header, border_style=border))


def scan(
    slug: str = typer.Argument(..., help="Skill slug to scan"),
    source: str | None = typer.Option(
        None, "--source", "-s",
        help="Source to download from (auto-detected if omitted)",
    ),
    skill_type: str = typer.Option(
        "skill", "--type", "-t", help="Type: skill or agent"
    ),
) -> None:
    """Download an external skill, scan it for security issues, and display results.

    Does NOT install the skill -- only scans and reports.
    """
    from agentpowers_cli.commands import validate_slug
    slug = validate_slug(slug)

    client = get_api_client()

    # Resolve source if not provided
    if not source:
        with console.status("Resolving source...", spinner="dots"):
            try:
                source = _resolve_source(client, slug)
            except _NativeSkillError:
                console.print(
                    f"[yellow]'{slug}' is a native AgentPowers skill.[/yellow]\n"
                    "Native skills are scanned automatically during publishing.\n"
                    f"Use [bold]ap detail {slug}[/bold] "
                    "to view its security status."
                )
                raise typer.Exit(code=0)
        if not source:
            console.print(
                f"[red]Skill '{slug}' not found in "
                "any external source.[/red]"
            )
            raise typer.Exit(code=1)

    # Download to sandbox
    sandbox = None
    try:
        with console.status(
            f"Downloading {slug} from {source}...", spinner="dots"
        ) as status:
            try:
                sandbox, _ = _download_to_sandbox(slug, source)
            except RuntimeError as exc:
                console.print(f"[red]Download failed:[/red] {exc}")
                raise typer.Exit(code=1)

            # Upload for scanning
            status.update("Uploading for security scan...")
            try:
                result = _upload_for_scan(sandbox, source, slug, skill_type)
            except RuntimeError as exc:
                console.print(f"[red]Scan failed:[/red] {exc}")
                raise typer.Exit(code=1)

        _display_results(slug, source, result)

        if result.get("security_status") == "block":
            raise typer.Exit(code=1)

    finally:
        if sandbox:
            shutil.rmtree(sandbox, ignore_errors=True)
