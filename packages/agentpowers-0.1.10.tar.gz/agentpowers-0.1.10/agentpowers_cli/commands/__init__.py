"""Shared command utilities."""

import re

import typer
from rich.console import Console

# Matches a valid slug: lowercase letters, digits, hyphens. 1-128 chars.
_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,127}$")

_console = Console()


def validate_slug(slug: str) -> str:
    """Validate and return a cleaned slug, or exit with an error.

    Rejects empty, whitespace-only, or malformed slugs before
    they reach the API.
    """
    slug = slug.strip()
    if not slug:
        _console.print("[red]Slug cannot be empty.[/red]")
        raise typer.Exit(code=1)
    if not _SLUG_RE.match(slug):
        _console.print(
            f"[red]Invalid slug '{slug}'.[/red] "
            "Slugs must contain only lowercase letters, digits, and hyphens."
        )
        raise typer.Exit(code=1)
    return slug
