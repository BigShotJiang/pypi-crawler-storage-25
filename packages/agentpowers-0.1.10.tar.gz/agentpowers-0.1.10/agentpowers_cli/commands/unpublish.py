"""Unpublish command — soft-archive a skill from marketplace discovery."""

from __future__ import annotations

import httpx
import typer
from rich.console import Console

from agentpowers_cli.services.api_client import APIClient, APIError

console = Console()


def get_api_client() -> APIClient:
    """Create and return an APIClient instance.

    Returns:
        A configured APIClient.
    """
    return APIClient()


def unpublish(
    slug: str = typer.Argument(help="Slug of the skill to unpublish"),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip the confirmation prompt (for scripts / CI).",
    ),
) -> None:
    """Unpublish a skill from marketplace discovery.

    Soft-archives the skill so it no longer appears in search or listings.
    Existing purchasers keep access. Reversible via ``ap republish``.

    Args:
        slug: The URL slug identifying the skill to unpublish.
        yes: If true, skip the y/N prompt. Use in non-interactive scripts.
    """
    from agentpowers_cli.commands import validate_slug
    slug = validate_slug(slug)

    if not yes:
        confirm = typer.confirm(
            f"Are you sure you want to unpublish '{slug}'? "
            "Existing purchasers will keep access.",
            default=False,
        )
        if not confirm:
            # Non-zero exit so shell scripts can detect the cancellation
            # (previously returned 0 which couldn't be distinguished from
            # a successful unpublish).
            console.print("[dim]Aborted.[/dim]")
            raise typer.Exit(code=1)

    client = get_api_client()

    try:
        result = client.post(
            f"/v1/skills/{slug}/unpublish",
            auth=True,
        )
    except httpx.ConnectError:
        console.print(
            "[red]Could not connect to the AgentPowers API.[/red] "
            "Check your network connection and try again."
        )
        raise typer.Exit(code=1)
    except httpx.TimeoutException:
        console.print(
            "[red]Request timed out.[/red] "
            "The API may be temporarily unavailable. Try again later."
        )
        raise typer.Exit(code=1)
    except APIError as exc:
        if exc.status_code == 401:
            console.print("[red]Not logged in.[/red] Run `ap login` first.")
        elif exc.status_code == 404:
            console.print(f"[red]Skill '{slug}' not found.[/red]")
        elif exc.status_code == 403:
            console.print(
                f"[red]You are not the owner/author of '{slug}'.[/red]"
            )
        elif exc.status_code == 409:
            console.print(
                f"[yellow]Skill '{slug}' is already unpublished.[/yellow]"
            )
        elif exc.status_code == 429:
            console.print(
                "[yellow]Too many requests.[/yellow] "
                "Please try again in a few moments."
            )
        else:
            console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    message = result.get("message", "Skill unpublished.")
    console.print(f"[green]{message}[/green]")
