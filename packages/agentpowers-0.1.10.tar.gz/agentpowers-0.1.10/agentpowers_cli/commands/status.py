"""Status command for the AgentPowers CLI.

Shows locally installed skills and agents with source, security,
version, and install date from install metadata.
"""

from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from agentpowers_cli.services.auth_store import load_token
from agentpowers_cli.services.installer import get_install_candidate_dirs
from agentpowers_cli.services.pin_manager import DEFAULT_PINS_PATH

console = Console()


def _list_installed_with_location(
    base_dirs: list[Path], subdir: str
) -> list[tuple[str, str]]:
    """List installed package slugs across multiple parent dirs.

    The first dir in base_dirs is treated as project-local; the rest as
    global. If a slug appears in both, project-local wins (it shadows
    the global install at install/uninstall time).

    Args:
        base_dirs: Candidate parent dirs from get_install_candidate_dirs.
        subdir: Either "skills" or "agents".

    Returns:
        Sorted list of (slug, location) tuples. location is "project"
        for the first dir when multiple are scanned; "global" otherwise.
    """
    seen: set[str] = set()
    entries: list[tuple[str, str]] = []
    multiple = len(base_dirs) > 1

    for idx, base_dir in enumerate(base_dirs):
        location = "project" if idx == 0 and multiple else "global"
        target = base_dir / subdir
        try:
            if not target.is_dir():
                continue
            for d in target.iterdir():
                if not d.is_dir() or d.name.startswith("."):
                    continue
                if d.name in seen:
                    continue
                seen.add(d.name)
                entries.append((d.name, location))
        except OSError:
            continue

    return sorted(entries, key=lambda e: e[0])


def _load_pins(pins_path: str) -> dict:
    """Load pins from disk, returning empty dict on any error."""
    path = Path(pins_path)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def _format_security(status: str | None) -> str:
    """Format security status with color."""
    if not status:
        return "-"
    s = status.lower()
    if s == "pass":
        return "[green]pass[/green]"
    if s == "warn":
        return "[yellow]warn[/yellow]"
    if s == "block":
        return "[red]block[/red]"
    return status


def _format_date(iso_str: str | None) -> str:
    """Extract date portion from ISO datetime string."""
    if not iso_str:
        return "-"
    return iso_str[:10]


def _build_table(
    entries: list[tuple[str, str]], pins: dict, kind: str
) -> Table | None:
    """Build a Rich table for installed items.

    Args:
        entries: List of (slug, location) tuples from _list_installed_with_location.
        pins: Loaded pins dict.
        kind: Either "Skills" or "Agents" for the title.

    Returns:
        A Rich Table, or None if no items.
    """
    if not entries:
        return None

    # Only show the Location column when at least one project-local entry
    # exists — keeps output identical for users who never use cwd installs.
    has_project = any(loc == "project" for _, loc in entries)

    table = Table(title=f"Installed {kind} ({len(entries)})")
    table.add_column("Slug", style="cyan", no_wrap=True)
    table.add_column("Source", style="yellow")
    table.add_column("Security")
    table.add_column("Version")
    table.add_column("Installed")
    if has_project:
        table.add_column("Location")

    for slug, location in entries:
        pin = pins.get(slug, {})
        source = pin.get("source", "local")
        security = _format_security(pin.get("security_status"))
        version = pin.get("version") or "-"
        installed = _format_date(pin.get("installed_at"))

        row = [slug, source, security, version, installed]
        if has_project:
            row.append(location)
        table.add_row(*row)

    return table


def _filter_by_source(
    entries: list[tuple[str, str]], pins: dict, source_filter: str
) -> list[tuple[str, str]]:
    """Filter (slug, location) entries by source.

    Args:
        entries: List of (slug, location) tuples.
        pins: Loaded pins dict.
        source_filter: Source to filter by. "local" means items not in pins
            or without a source. Other values match the pin's source field.

    Returns:
        Filtered list of (slug, location) tuples.
    """
    source_lower = source_filter.lower()
    if source_lower == "local":
        return [
            (s, loc) for s, loc in entries
            if s not in pins or not pins[s].get("source")
        ]
    return [
        (s, loc) for s, loc in entries
        if pins.get(s, {}).get("source", "").lower() == source_lower
    ]


def status(
    source: str | None = typer.Option(
        None, "--source", "-s",
        help="Filter by source (e.g. agentpowers, clawhub, local)",
    ),
) -> None:
    """Show installed skills and agents with their status."""
    token = load_token()
    if token:
        console.print(
            "[green]Logged in[/green] [dim](run `ap whoami` to verify)[/dim]"
        )
    else:
        console.print(
            "[yellow]Not logged in.[/yellow] Run "
            "[bold]ap login[/bold] to purchase and publish skills."
        )
    console.print()

    candidate_dirs = get_install_candidate_dirs()
    pins = _load_pins(DEFAULT_PINS_PATH)

    skills = _list_installed_with_location(candidate_dirs, "skills")
    agents = _list_installed_with_location(candidate_dirs, "agents")

    if source:
        skills = _filter_by_source(skills, pins, source)
        agents = _filter_by_source(agents, pins, source)

    skills_table = _build_table(skills, pins, "Skills")
    if skills_table:
        console.print(skills_table)
    else:
        console.print("No skills installed.")

    agents_table = _build_table(agents, pins, "Agents")
    if agents_table:
        console.print()
        console.print(agents_table)
    else:
        console.print("No agents installed.")
