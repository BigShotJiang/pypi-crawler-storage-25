"""Republish command — restore an archived skill to marketplace discovery."""

from __future__ import annotations

from typing import Any

import httpx
import typer
from rich.console import Console

from agentpowers_cli.services.api_client import APIClient, APIError

console = Console()


def get_api_client() -> APIClient:
    """Create and return an APIClient instance."""
    return APIClient()


def _fetch_skill_details(client: APIClient, slug: str) -> dict[str, Any] | None:
    """Fetch skill details for the confirmation prompt.

    Returns the skill dict on success, or None if the skill cannot be found
    or the user is not authorized.
    """
    try:
        return client.get(f"/v1/skills/{slug}", auth=True)
    except APIError as exc:
        if exc.status_code == 404:
            console.print(
                f"[red]Skill '{slug}' not found.[/red] "
                "It may have never been published, or the slug may be misspelled.\n"
                "[dim]Run `ap profile` to see your published skills.[/dim]"
            )
            raise typer.Exit(code=1)
        if exc.status_code == 403:
            console.print(
                f"[red]This skill belongs to another seller.[/red] "
                f"You cannot republish '{slug}' because you are not its author."
            )
            raise typer.Exit(code=1)
        if exc.status_code == 401:
            console.print("[red]Not logged in.[/red] Run `ap login` first.")
            raise typer.Exit(code=1)
        # For other errors, return None and let the republish call handle it
        return None
    except (httpx.ConnectError, httpx.TimeoutException):
        # Network errors — skip pre-flight, let the main call handle it
        return None


def republish(
    slug: str = typer.Argument(help="Slug of the skill to republish"),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip the confirmation prompt (for scripts / CI).",
    ),
) -> None:
    """Republish a previously archived skill.

    Restores the skill to marketplace search and listings.
    """
    from agentpowers_cli.commands import validate_slug
    slug = validate_slug(slug)

    client = get_api_client()

    # Pre-flight: fetch skill details for a richer confirmation prompt.
    # Skip when --yes because we don't need to show the prompt anyway —
    # this also avoids the pre-existing bug where /v1/skills/{slug}
    # returns 404 for archived skills, which aborts republish before
    # the actual POST /republish call. (Tracked as a separate issue.)
    if not yes:
        skill = _fetch_skill_details(client, slug)

        if skill:
            status = "archived" if skill.get("archived_at") else "published"
            name = skill.get("name", slug)
            console.print(f"\n  Skill:   [bold]{name}[/bold] ({slug})")
            console.print(f"  Status:  {status}")
            version = skill.get("version") or skill.get("current_version")
            if version:
                console.print(f"  Version: {version}")
            console.print()

        confirm = typer.confirm(
            f"Are you sure you want to republish '{slug}'?",
            default=False,
        )
        if not confirm:
            # Non-zero exit so scripts can distinguish cancel from success.
            console.print("[dim]Aborted.[/dim]")
            raise typer.Exit(code=1)

    try:
        result = client.post(
            f"/v1/skills/{slug}/republish",
            auth=True,
        )
    except httpx.ConnectError:
        console.print(
            "[red]Could not connect to the AgentPowers API.[/red] "
            "Check your network connection and try again."
        )
        raise typer.Exit(code=1)
    except httpx.TimeoutException:
        console.print(
            "[red]Request timed out.[/red] "
            "The API may be temporarily unavailable. Try again later."
        )
        raise typer.Exit(code=1)
    except APIError as exc:
        if exc.status_code == 401:
            console.print("[red]Not logged in.[/red] Run `ap login` first.")
        elif exc.status_code == 404:
            console.print(
                f"[red]Skill '{slug}' not found.[/red] "
                "It may have never been published, or the slug may be misspelled.\n"
                "[dim]Run `ap profile` to see your published skills.[/dim]"
            )
        elif exc.status_code == 403:
            console.print(
                f"[red]This skill belongs to another seller.[/red] "
                f"You cannot republish '{slug}' because you are not its author."
            )
        elif exc.status_code == 409:
            console.print(
                f"[yellow]Skill '{slug}' is not archived.[/yellow] "
                "It is already published and visible in the marketplace."
            )
        elif exc.status_code == 429:
            console.print(
                "[yellow]Too many requests.[/yellow] "
                "Please try again in a few moments."
            )
        else:
            console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    message = result.get("message", "Skill republished.")
    console.print(f"[green]{message}[/green]")
