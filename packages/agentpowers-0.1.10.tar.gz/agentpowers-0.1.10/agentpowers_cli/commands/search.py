"""Search command for the AgentPowers CLI.

Provides a search command that queries the marketplace API and displays
results in a single unified Rich table. All sources (native and external)
are combined with a Source column, AgentPowers items first, paid before free.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from agentpowers_cli.services.api_client import APIClient, APIError
from agentpowers_cli.services.content_hasher import hash_directory
from agentpowers_cli.services.pin_manager import DEFAULT_PINS_PATH, load_pins

console = Console()


def get_api_client() -> APIClient:
    """Create and return an APIClient instance.

    Returns:
        A configured APIClient.
    """
    return APIClient()


def _format_price(price_cents: int | None) -> str:
    """Format a price in cents for display.

    Args:
        price_cents: Price in cents (0 or None means free).

    Returns:
        Formatted price string, e.g. "Free" or "$12.00".
    """
    if not price_cents:
        return "Free"
    dollars = price_cents / 100
    return f"${dollars:.2f}"


def _format_security(status: str) -> str:
    """Format a security status with Rich color markup.

    Args:
        status: The security status string (pass, warn, block).

    Returns:
        Rich-formatted security status string.
    """
    status_lower = status.lower()
    if status_lower == "pass":
        return "[green]pass[/green]"
    if status_lower == "warn":
        return "[yellow]warn[/yellow]"
    if status_lower == "block":
        return "[red]block[/red]"
    return status


def _sort_key(item: dict[str, Any]) -> int:
    """Sort key: paid items (price_cents > 0) before free (0)."""
    return 0 if item.get("price_cents", 0) > 0 else 1


def _format_title(title: str, installs: Any, stars: Any) -> str:
    """Format title with inline installs/stars stats.

    Args:
        title: The skill/agent title.
        installs: Install count (int or None).
        stars: Star count (int or None).

    Returns:
        Title string, with stats appended when available.
    """
    i = installs if installs is not None else 0
    s = stars if stars is not None else 0
    return f"{title} ({i}, {s})"


def _get_installed_slugs() -> dict[str, str]:
    """Return a dict of slugs with their install state.

    Checks both pins.json (external installs) and the ~/.claude/skills/
    and ~/.claude/agents/ directories (native installs). For pinned skills,
    checks if content hash matches to detect local edits.

    Returns:
        Dict mapping slug to "clean" or "edited".
    """
    slugs: dict[str, str] = {}

    # Check pins.json for pinned installs
    pins = load_pins(DEFAULT_PINS_PATH)
    claude_dir = Path.home() / ".claude"

    for slug, pin_data in pins.items():
        pinned_hash = pin_data.get("content_hash")
        if not pinned_hash:
            slugs[slug] = "clean"
            continue

        # Find the install directory and check hash
        edited = False
        for subdir in ("skills", "agents"):
            install_dir = claude_dir / subdir / slug
            if install_dir.exists():
                try:
                    current_hash = hash_directory(str(install_dir))
                    if current_hash != pinned_hash:
                        edited = True
                except Exception:
                    pass
                break

        slugs[slug] = "edited" if edited else "clean"

    # Check filesystem for non-pinned installs
    for subdir in ("skills", "agents"):
        parent = claude_dir / subdir
        if parent.is_dir():
            for child in parent.iterdir():
                if child.is_dir() and child.name not in slugs:
                    slugs[child.name] = "clean"

    return slugs


def _format_installed(slug: str, installed_slugs: dict[str, str]) -> str:
    """Format the installed status with Rich color markup.

    Args:
        slug: The skill/agent slug to check.
        installed_slugs: Dict mapping slug to "clean" or "edited".

    Returns:
        Rich-formatted "Yes" (green), "Edited" (yellow), or "No".
    """
    state = installed_slugs.get(slug)
    if state == "edited":
        return "[yellow]Edited[/yellow]"
    if state is not None:
        return "[bright_green]Yes[/bright_green]"
    return "No"


def _build_unified_table(
    native_items: list[dict[str, Any]],
    external_sections: dict[str, dict[str, Any]],
    max_results: int | None = None,
) -> Table:
    """Build a single Rich Table combining native and external results.

    Args:
        native_items: List of native skill/agent dicts.
        external_sections: Dict mapping source name to {items, total, ...}.
        max_results: Maximum total rows to include. None means no limit.

    Returns:
        A Rich Table with all results, native first, paid before free.
    """
    installed_slugs = _get_installed_slugs()

    table = Table()
    table.add_column("Slug", style="cyan", no_wrap=True)
    table.add_column("Title (Installs, Stars)")
    table.add_column("Source", style="yellow")
    table.add_column("Type")
    table.add_column("Price", justify="right")
    table.add_column("Security")
    table.add_column("Installed")

    row_count = 0

    for item in sorted(native_items, key=_sort_key):
        if max_results is not None and row_count >= max_results:
            break
        slug = item.get("slug", "")
        dl = item.get("download_count")
        table.add_row(
            slug,
            _format_title(item.get("title", ""), dl, None),
            "agentpowers",
            item.get("type", ""),
            _format_price(item.get("price_cents", 0)),
            _format_security(item.get("security_status", "")),
            _format_installed(slug, installed_slugs),
        )
        row_count += 1

    for _source, section in external_sections.items():
        if max_results is not None and row_count >= max_results:
            break
        ext_items = section.get("items", [])
        for item in sorted(ext_items, key=_sort_key):
            if max_results is not None and row_count >= max_results:
                break
            slug = item.get("slug", "")
            security = item.get("ap_security_status") or "not scanned"
            installs = item.get("source_installs")
            stars = item.get("source_stars")
            table.add_row(
                slug,
                _format_title(item.get("title", ""), installs, stars),
                item.get("source", _source),
                item.get("type") or "\u2014",
                _format_price(item.get("price_cents", 0)),
                _format_security(security),
                _format_installed(slug, installed_slugs),
            )
            row_count += 1

    return table


def search(
    query_words: list[str] = typer.Argument(
        ..., help="Search query (multiple words allowed without quotes)"
    ),
    category: str | None = typer.Option(
        None, "--category", "-c", help="Filter by category"
    ),
    type: str | None = typer.Option(
        None, "--type", "-t",
        help="Filter by type (skill or agent)",
    ),
    source: str | None = typer.Option(
        None, "--source", "-s",
        help="Filter by source (e.g. agentpowers, clawhub)",
    ),
    limit: int = typer.Option(20, "--limit", "-l", help="Maximum number of results"),
) -> None:
    """Search the AgentPowers marketplace for skills and agents."""
    query = " ".join(query_words)
    if not query.strip():
        console.print("[red]Search query cannot be empty.[/red]")
        raise typer.Exit(code=1)

    if limit < 1:
        console.print("[red]--limit must be at least 1.[/red]")
        raise typer.Exit(code=1)

    if type and type not in ("skill", "agent"):
        console.print(
            f"[red]Invalid --type '{type}'. Must be 'skill' or 'agent'.[/red]"
        )
        raise typer.Exit(code=1)

    client = get_api_client()

    params: dict[str, Any] = {"q": query, "limit": limit}
    if category:
        params["category"] = category
    if type:
        params["type"] = type
    if source:
        params["source"] = source

    with console.status("Searching...", spinner="dots"):
        try:
            data = client.get("/v1/search", params=params)
        except APIError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(code=1)

    # Sectioned response: {agentpowers: {items, total}, clawhub: {items, total}, ...}
    native = data.get("agentpowers", {})
    native_items: list[dict[str, Any]] = native.get("items", [])

    # Collect external source sections (everything except "agentpowers")
    external_sections = {k: v for k, v in data.items() if k != "agentpowers"}

    # Client-side source filtering
    if source:
        source_lower = source.lower()
        if source_lower == "agentpowers":
            external_sections = {}
        else:
            native_items = []
            external_sections = {
                k: v for k, v in external_sections.items()
                if k.lower() == source_lower
            }

    has_results = bool(native_items) or any(
        v.get("items") for v in external_sections.values()
    )

    if not has_results:
        console.print("No results found.")
        return

    # Count total results across all sources
    total_results = len(native_items) + sum(
        len(v.get("items", [])) for v in external_sections.values()
    )

    console.print(
        _build_unified_table(native_items, external_sections, max_results=limit)
    )

    if total_results > limit:
        console.print(
            f"[dim](showing {limit} of {total_results} results)[/dim]"
        )
