"""Profile command for the AgentPowers CLI.

View and update your seller profile (display name, bio).
"""

from __future__ import annotations

import typer
from rich.console import Console

from agentpowers_cli.services.api_client import APIClient, APIError

console = Console()


def get_api_client() -> APIClient:
    """Create and return an APIClient instance.

    Returns:
        A configured APIClient.
    """
    return APIClient()


def _print_profile(profile: dict) -> None:  # type: ignore[type-arg]
    """Print profile fields to the console.

    Args:
        profile: A dict containing profile data from the API.
    """
    display_name = profile.get("display_name") or ""
    email = profile.get("email") or ""
    bio = profile.get("bio") or ""
    created_at = profile.get("created_at") or ""

    console.print(
        f"[bold]Display name:[/bold] {display_name or '[dim]not set[/dim]'}"
    )
    console.print(f"[bold]Email:[/bold]        {email}")
    console.print(f"[bold]Bio:[/bold]          {bio or '[dim]not set[/dim]'}")
    console.print(f"[bold]Joined:[/bold]       {created_at}")

    if not display_name:
        console.print(
            "[dim]No display name set. Run `ap profile --set` to add one.[/dim]"
        )


def profile(
    set_profile: bool = typer.Option(
        False, "--set", help="Interactively set profile fields"
    ),
) -> None:
    """View or update your AgentPowers seller profile.

    Without flags, displays your current profile. With --set, prompts
    for display name and bio interactively.
    """
    client = get_api_client()

    try:
        current = client.get("/v1/users/profile", auth=True)
    except APIError as exc:
        if exc.status_code == 401:
            console.print("[red]Not logged in.[/red] Run `ap login` first.")
        else:
            console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    if not set_profile:
        _print_profile(current)
        return

    # --set mode: prompt for display_name and bio
    current_display_name = current.get("display_name") or ""
    current_bio = current.get("bio") or ""

    display_name = typer.prompt(
        "Display name",
        default=current_display_name,
        show_default=True,
    ).strip()
    bio = typer.prompt(
        "Bio (optional)",
        default=current_bio,
        show_default=True,
    )

    patch_data: dict[str, str] = {}
    if display_name:
        patch_data["display_name"] = display_name
    if bio is not None:
        patch_data["bio"] = bio

    try:
        updated = client.patch(
            "/v1/users/profile", json_data=patch_data, auth=True
        )
        console.print("[green]Profile updated![/green]")
        _print_profile(updated)
    except APIError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)
