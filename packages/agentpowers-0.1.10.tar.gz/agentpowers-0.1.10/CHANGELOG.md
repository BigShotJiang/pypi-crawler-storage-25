# Changelog

## [0.1.10] - 2026-04-28

### Changes




## [0.1.8] - 2026-04-09

### Changes




## [0.1.7] - 2026-04-09

### Security

- Add CSRF state validation to CLI OAuth callback server to prevent cross-origin token injection



## [0.1.6] - 2026-04-07

### Changes




## [0.1.4] - 2026-04-04

### Changes




## [0.1.3] - 2026-04-01

### Changes




## [0.1.2] - 2026-04-01

### Changes




## [0.1.1] - 2026-04-01

### Changes



