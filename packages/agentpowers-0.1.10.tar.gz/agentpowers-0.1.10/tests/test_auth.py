"""Tests for CSRF state validation in the OAuth callback handler."""

from __future__ import annotations

import socket
import threading
from http.server import HTTPServer
from urllib.request import Request, urlopen

import pytest

from agentpowers_cli.commands.auth import _CallbackHandler


def _free_port() -> int:
    """Find an available TCP port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _make_server(expected_state: str) -> HTTPServer:
    """Create an HTTPServer with _CallbackHandler and CSRF state configured."""
    port = _free_port()
    server = HTTPServer(("127.0.0.1", port), _CallbackHandler)
    server.received_token = None  # type: ignore[attr-defined]
    server.expected_state = expected_state  # type: ignore[attr-defined]
    server.timeout = 5
    return server


class TestCallbackStateValidation:
    """Tests for CSRF state parameter validation in _CallbackHandler."""

    def test_callback_rejects_wrong_state(self) -> None:
        """Server with expected_state='correct' rejects request with state='wrong'."""
        server = _make_server("correct")
        port = server.server_address[1]

        thread = threading.Thread(target=server.handle_request, daemon=True)
        thread.start()

        url = f"http://127.0.0.1:{port}/callback?token=my-jwt&state=wrong"
        req = Request(url)
        try:
            response = urlopen(req, timeout=5)
            status = response.getcode()
        except Exception as exc:
            # urllib raises on 4xx/5xx
            status = exc.code  # type: ignore[attr-defined]

        thread.join(timeout=5)
        server.server_close()

        assert status == 403
        assert server.received_token is None  # type: ignore[attr-defined]

    def test_callback_accepts_correct_state(self) -> None:
        """Server with expected_state='correct' accepts request with state='correct'."""
        server = _make_server("correct")
        port = server.server_address[1]

        thread = threading.Thread(target=server.handle_request, daemon=True)
        thread.start()

        url = f"http://127.0.0.1:{port}/callback?token=my-jwt&state=correct"
        req = Request(url)
        response = urlopen(req, timeout=5)
        status = response.getcode()

        thread.join(timeout=5)
        server.server_close()

        assert status == 200
        assert server.received_token == "my-jwt"  # type: ignore[attr-defined]

    def test_callback_rejects_missing_state(self) -> None:
        """Server with expected_state set rejects request with no state param."""
        server = _make_server("correct")
        port = server.server_address[1]

        thread = threading.Thread(target=server.handle_request, daemon=True)
        thread.start()

        url = f"http://127.0.0.1:{port}/callback?token=my-jwt"
        req = Request(url)
        try:
            response = urlopen(req, timeout=5)
            status = response.getcode()
        except Exception as exc:
            status = exc.code  # type: ignore[attr-defined]

        thread.join(timeout=5)
        server.server_close()

        assert status == 403
        assert server.received_token is None  # type: ignore[attr-defined]

    def test_callback_skips_state_check_when_none(self) -> None:
        """Server with no expected_state accepts any request (backward compat)."""
        server = _make_server("unused")
        server.expected_state = None  # type: ignore[attr-defined]
        port = server.server_address[1]

        thread = threading.Thread(target=server.handle_request, daemon=True)
        thread.start()

        url = f"http://127.0.0.1:{port}/callback?token=my-jwt"
        req = Request(url)
        response = urlopen(req, timeout=5)
        status = response.getcode()

        thread.join(timeout=5)
        server.server_close()

        assert status == 200
        assert server.received_token == "my-jwt"  # type: ignore[attr-defined]
