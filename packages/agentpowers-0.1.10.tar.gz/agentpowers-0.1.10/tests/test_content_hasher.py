"""Tests for content_hasher -- hash_directory OS artifact exclusion."""

from __future__ import annotations

from pathlib import Path

from agentpowers_cli.services.content_hasher import hash_directory


class TestHashDirectoryExcludesOSArtifacts:
    """hash_directory must ignore OS-generated files that aren't skill content."""

    def test_ds_store_does_not_change_hash(self, tmp_path: Path) -> None:
        """macOS .DS_Store should be excluded from hash computation."""
        (tmp_path / "SKILL.md").write_text("# Hello")
        h1 = hash_directory(str(tmp_path))

        (tmp_path / ".DS_Store").write_bytes(b"\x00\x00\x00\x01Bud1")
        h2 = hash_directory(str(tmp_path))

        assert h1 == h2

    def test_pycache_dir_does_not_change_hash(self, tmp_path: Path) -> None:
        """__pycache__ directories should be excluded from hash computation."""
        (tmp_path / "main.py").write_text("print('hi')")
        h1 = hash_directory(str(tmp_path))

        cache = tmp_path / "__pycache__"
        cache.mkdir()
        (cache / "main.cpython-310.pyc").write_bytes(b"\x00\x00\x00\x00")
        h2 = hash_directory(str(tmp_path))

        assert h1 == h2

    def test_thumbs_db_does_not_change_hash(self, tmp_path: Path) -> None:
        """Windows Thumbs.db should be excluded from hash computation."""
        (tmp_path / "SKILL.md").write_text("# Hello")
        h1 = hash_directory(str(tmp_path))

        (tmp_path / "Thumbs.db").write_bytes(b"\x00\x00")
        h2 = hash_directory(str(tmp_path))

        assert h1 == h2

    def test_pyc_files_do_not_change_hash(self, tmp_path: Path) -> None:
        """.pyc files at any level should be excluded."""
        (tmp_path / "module.py").write_text("x = 1")
        h1 = hash_directory(str(tmp_path))

        (tmp_path / "module.pyc").write_bytes(b"\x00\x00")
        h2 = hash_directory(str(tmp_path))

        assert h1 == h2

    def test_nested_ds_store_excluded(self, tmp_path: Path) -> None:
        """.DS_Store in subdirectories also excluded."""
        sub = tmp_path / "lib"
        sub.mkdir()
        (sub / "util.py").write_text("pass")
        h1 = hash_directory(str(tmp_path))

        (sub / ".DS_Store").write_bytes(b"\x00\x00\x00\x01Bud1")
        h2 = hash_directory(str(tmp_path))

        assert h1 == h2

    def test_actual_content_changes_detected(self, tmp_path: Path) -> None:
        """Real content changes DO affect the hash (sanity check)."""
        (tmp_path / "SKILL.md").write_text("# Version 1")
        h1 = hash_directory(str(tmp_path))

        (tmp_path / "SKILL.md").write_text("# Version 2")
        h2 = hash_directory(str(tmp_path))

        assert h1 != h2

    def test_new_real_file_changes_hash(self, tmp_path: Path) -> None:
        """Adding a real skill file changes the hash (sanity check)."""
        (tmp_path / "SKILL.md").write_text("# Hello")
        h1 = hash_directory(str(tmp_path))

        (tmp_path / "helper.py").write_text("def foo(): pass")
        h2 = hash_directory(str(tmp_path))

        assert h1 != h2


# ---------------------------------------------------------------------------
# NEW: hash_bytes tests (line 65)
# ---------------------------------------------------------------------------


class TestHashBytes:
    """Tests for the hash_bytes function."""

    def test_hash_bytes_returns_sha256_prefix(self) -> None:
        """hash_bytes returns a string starting with 'sha256:'."""
        from agentpowers_cli.services.content_hasher import hash_bytes

        result = hash_bytes(b"hello world")
        assert result.startswith("sha256:")

    def test_hash_bytes_deterministic(self) -> None:
        """Same input bytes produce the same hash."""
        from agentpowers_cli.services.content_hasher import hash_bytes

        h1 = hash_bytes(b"test data")
        h2 = hash_bytes(b"test data")
        assert h1 == h2

    def test_hash_bytes_different_input_different_hash(self) -> None:
        """Different input bytes produce different hashes."""
        from agentpowers_cli.services.content_hasher import hash_bytes

        h1 = hash_bytes(b"data1")
        h2 = hash_bytes(b"data2")
        assert h1 != h2

    def test_hash_bytes_empty_input(self) -> None:
        """Empty bytes still produce a valid sha256 hash."""
        from agentpowers_cli.services.content_hasher import hash_bytes

        result = hash_bytes(b"")
        assert result.startswith("sha256:")
        # SHA-256 of empty string is a known value
        assert len(result) == len("sha256:") + 64


# ---------------------------------------------------------------------------
# NEW: hash_files tests (lines 79-83)
# ---------------------------------------------------------------------------


class TestHashFiles:
    """Tests for the hash_files function."""

    def test_hash_files_returns_sha256_prefix(self) -> None:
        """hash_files returns a string starting with 'sha256:'."""
        from agentpowers_cli.services.content_hasher import hash_files

        result = hash_files({"a.txt": b"hello"})
        assert result.startswith("sha256:")

    def test_hash_files_deterministic(self) -> None:
        """Same file dict produces the same hash."""
        from agentpowers_cli.services.content_hasher import hash_files

        files = {"a.txt": b"hello", "b.txt": b"world"}
        h1 = hash_files(files)
        h2 = hash_files(files)
        assert h1 == h2

    def test_hash_files_order_independent(self) -> None:
        """File dict order does not affect hash (sorted by key)."""
        from agentpowers_cli.services.content_hasher import hash_files

        h1 = hash_files({"z.txt": b"last", "a.txt": b"first"})
        h2 = hash_files({"a.txt": b"first", "z.txt": b"last"})
        assert h1 == h2

    def test_hash_files_different_content_different_hash(self) -> None:
        """Different file contents produce different hashes."""
        from agentpowers_cli.services.content_hasher import hash_files

        h1 = hash_files({"a.txt": b"v1"})
        h2 = hash_files({"a.txt": b"v2"})
        assert h1 != h2

    def test_hash_files_empty_dict(self) -> None:
        """Empty file dict still produces a valid hash."""
        from agentpowers_cli.services.content_hasher import hash_files

        result = hash_files({})
        assert result.startswith("sha256:")
        assert len(result) == len("sha256:") + 64

    def test_hash_files_different_names_different_hash(self) -> None:
        """Same content with different filenames produces different hash."""
        from agentpowers_cli.services.content_hasher import hash_files

        h1 = hash_files({"a.txt": b"data"})
        h2 = hash_files({"b.txt": b"data"})
        assert h1 != h2


# ---------------------------------------------------------------------------
# NEW: _should_skip tests (line 28, various OS artifacts)
# ---------------------------------------------------------------------------


class TestShouldSkip:
    """Tests for the _should_skip helper."""

    def test_skip_ds_store(self) -> None:
        """_should_skip returns True for .DS_Store."""
        from agentpowers_cli.services.content_hasher import _should_skip

        assert _should_skip(Path(".DS_Store")) is True

    def test_skip_thumbs_db(self) -> None:
        """_should_skip returns True for Thumbs.db."""
        from agentpowers_cli.services.content_hasher import _should_skip

        assert _should_skip(Path("Thumbs.db")) is True

    def test_skip_pycache_dir(self) -> None:
        """_should_skip returns True for __pycache__ itself."""
        from agentpowers_cli.services.content_hasher import _should_skip

        assert _should_skip(Path("__pycache__")) is True

    def test_skip_pyc_suffix(self) -> None:
        """_should_skip returns True for .pyc files."""
        from agentpowers_cli.services.content_hasher import _should_skip

        assert _should_skip(Path("module.pyc")) is True

    def test_skip_pyo_suffix(self) -> None:
        """_should_skip returns True for .pyo files."""
        from agentpowers_cli.services.content_hasher import _should_skip

        assert _should_skip(Path("module.pyo")) is True

    def test_skip_file_inside_pycache_dir(self) -> None:
        """_should_skip returns True for files inside __pycache__/ directories."""
        from agentpowers_cli.services.content_hasher import _should_skip

        assert _should_skip(Path("__pycache__/main.cpython-311.pyc")) is True

    def test_skip_nested_pycache(self) -> None:
        """_should_skip returns True for files in nested __pycache__."""
        from agentpowers_cli.services.content_hasher import _should_skip

        assert _should_skip(Path("lib/__pycache__/util.cpython-311.pyc")) is True

    def test_no_skip_regular_python(self) -> None:
        """_should_skip returns False for regular .py files."""
        from agentpowers_cli.services.content_hasher import _should_skip

        assert _should_skip(Path("main.py")) is False

    def test_no_skip_regular_markdown(self) -> None:
        """_should_skip returns False for .md files."""
        from agentpowers_cli.services.content_hasher import _should_skip

        assert _should_skip(Path("SKILL.md")) is False

    def test_no_skip_nested_regular_file(self) -> None:
        """_should_skip returns False for regular files in subdirectories."""
        from agentpowers_cli.services.content_hasher import _should_skip

        assert _should_skip(Path("lib/util.py")) is False
