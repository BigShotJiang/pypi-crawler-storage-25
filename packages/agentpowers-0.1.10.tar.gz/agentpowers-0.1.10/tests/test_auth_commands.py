"""Tests for the auth commands (login, logout, whoami)."""

from __future__ import annotations

import threading
from io import BytesIO
from unittest.mock import MagicMock, patch

import httpx
from typer.testing import CliRunner

from agentpowers_cli.commands.auth import (
    _CallbackHandler,
    _find_free_port,
    get_api_client,
    start_auth_server,
)
from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIClient, APIError

runner = CliRunner()


class TestLogin:
    """Tests for the `ap login` command."""

    @patch("agentpowers_cli.commands.auth.get_api_client")
    @patch("agentpowers_cli.commands.auth.open_browser")
    @patch(
        "agentpowers_cli.commands.auth.start_auth_server",
        return_value="jwt-token-123",
    )
    @patch("agentpowers_cli.commands.auth.save_token")
    @patch("agentpowers_cli.commands.auth._find_free_port", return_value=9999)
    def test_login_success(
        self,
        mock_port: MagicMock,
        mock_save: MagicMock,
        mock_server: MagicMock,
        mock_browser: MagicMock,
        mock_client_factory: MagicMock,
    ) -> None:
        """Successful login saves token and prints confirmation."""
        mock_client = MagicMock()
        mock_client.post.return_value = {
            "token": "ap_cli_exchanged",
            "expires_at": "2026-06-01T00:00:00+00:00",
        }
        mock_client_factory.return_value = mock_client

        result = runner.invoke(app, ["login"])

        assert result.exit_code == 0
        assert "Logged in" in result.output
        mock_browser.assert_called_once()
        mock_server.assert_called_once()
        call_args = mock_server.call_args
        assert call_args[0][0] == 9999  # port
        assert "state" in call_args[1]  # CSRF state nonce

    @patch("agentpowers_cli.commands.auth.open_browser")
    @patch("agentpowers_cli.commands.auth.start_auth_server", return_value=None)
    @patch("agentpowers_cli.commands.auth._find_free_port", return_value=9999)
    def test_login_timeout(
        self,
        mock_port: MagicMock,
        mock_server: MagicMock,
        mock_browser: MagicMock,
    ) -> None:
        """Login times out when no callback received."""
        result = runner.invoke(app, ["login"])

        assert result.exit_code == 1
        assert "timed out" in result.output

    @patch("agentpowers_cli.commands.auth.get_api_client")
    @patch("agentpowers_cli.commands.auth.open_browser")
    @patch(
        "agentpowers_cli.commands.auth.start_auth_server",
        return_value="jwt-token-123",
    )
    @patch("agentpowers_cli.commands.auth.save_token")
    @patch("agentpowers_cli.commands.auth._find_free_port", return_value=9999)
    def test_login_opens_correct_url(
        self,
        mock_port: MagicMock,
        mock_save: MagicMock,
        mock_server: MagicMock,
        mock_browser: MagicMock,
        mock_client_factory: MagicMock,
    ) -> None:
        """Login opens browser with correct Clerk URL and callback redirect."""
        mock_client = MagicMock()
        mock_client.post.return_value = {
            "token": "ap_cli_exchanged",
            "expires_at": "2026-06-01T00:00:00+00:00",
        }
        mock_client_factory.return_value = mock_client

        result = runner.invoke(app, ["login"])

        assert result.exit_code == 0
        call_args = mock_browser.call_args[0][0]
        assert "sign-in" in call_args
        assert "redirect_to=http://127.0.0.1:9999/callback" in call_args
        assert "cli-callback" in call_args

    @patch("agentpowers_cli.commands.auth.get_api_client")
    @patch("agentpowers_cli.commands.auth.open_browser")
    @patch(
        "agentpowers_cli.commands.auth.start_auth_server",
        return_value="short-lived-jwt",
    )
    @patch("agentpowers_cli.commands.auth.save_token")
    @patch("agentpowers_cli.commands.auth._find_free_port", return_value=9999)
    def test_login_exchanges_jwt_for_cli_token(
        self,
        mock_port: MagicMock,
        mock_save: MagicMock,
        mock_server: MagicMock,
        mock_browser: MagicMock,
        mock_client_factory: MagicMock,
    ) -> None:
        """Login exchanges Clerk JWT for long-lived CLI token."""
        mock_client = MagicMock()
        mock_client.post.return_value = {
            "token": "ap_cli_abc123",
            "expires_at": "2026-06-01T00:00:00+00:00",
        }
        mock_client_factory.return_value = mock_client

        result = runner.invoke(app, ["login"])

        assert result.exit_code == 0
        # Should save the CLI token (second call to save_token)
        assert mock_save.call_count == 2
        # First call saves Clerk JWT temporarily
        mock_save.assert_any_call("short-lived-jwt")
        # Second call saves the CLI token
        mock_save.assert_any_call("ap_cli_abc123")
        # Should have called the exchange endpoint
        mock_client.post.assert_called_once_with("/v1/auth/cli-token", auth=True)

    @patch("agentpowers_cli.commands.auth.get_api_client")
    @patch("agentpowers_cli.commands.auth.open_browser")
    @patch(
        "agentpowers_cli.commands.auth.start_auth_server",
        return_value="short-lived-jwt",
    )
    @patch("agentpowers_cli.commands.auth.save_token")
    @patch("agentpowers_cli.commands.auth._find_free_port", return_value=9999)
    def test_login_falls_back_on_exchange_failure(
        self,
        mock_port: MagicMock,
        mock_save: MagicMock,
        mock_server: MagicMock,
        mock_browser: MagicMock,
        mock_client_factory: MagicMock,
    ) -> None:
        """Login saves raw JWT if exchange fails (graceful fallback)."""
        mock_client = MagicMock()
        mock_client.post.side_effect = APIError("Exchange failed", status_code=500)
        mock_client_factory.return_value = mock_client

        result = runner.invoke(app, ["login"])

        assert result.exit_code == 0
        assert "session token" in result.output


class TestLogout:
    """Tests for the `ap logout` command."""

    @patch("agentpowers_cli.commands.auth.get_api_client")
    @patch("agentpowers_cli.commands.auth.delete_token")
    def test_logout(
        self, mock_delete: MagicMock, mock_client_factory: MagicMock
    ) -> None:
        """Logout deletes token and prints confirmation."""
        mock_client = MagicMock()
        mock_client_factory.return_value = mock_client

        result = runner.invoke(app, ["logout"])

        assert result.exit_code == 0
        assert "Logged out" in result.output
        mock_delete.assert_called_once()

    @patch("agentpowers_cli.commands.auth.get_api_client")
    @patch("agentpowers_cli.commands.auth.delete_token")
    def test_logout_revokes_server_side(
        self, mock_delete: MagicMock, mock_client_factory: MagicMock
    ) -> None:
        """Logout calls revoke endpoint before deleting local token."""
        mock_client = MagicMock()
        mock_client_factory.return_value = mock_client

        result = runner.invoke(app, ["logout"])

        assert result.exit_code == 0
        mock_client.post.assert_called_once_with(
            "/v1/auth/revoke-cli-token", auth=True
        )
        mock_delete.assert_called_once()

    @patch("agentpowers_cli.commands.auth.get_api_client")
    @patch("agentpowers_cli.commands.auth.delete_token")
    def test_logout_succeeds_even_if_revoke_fails(
        self, mock_delete: MagicMock, mock_client_factory: MagicMock
    ) -> None:
        """Logout still deletes local token if server revoke fails."""
        mock_client = MagicMock()
        mock_client.post.side_effect = APIError("Server error", status_code=500)
        mock_client_factory.return_value = mock_client

        result = runner.invoke(app, ["logout"])

        assert result.exit_code == 0
        assert "Logged out" in result.output
        mock_delete.assert_called_once()


class TestWhoami:
    """Tests for the `ap whoami` command."""

    @patch("agentpowers_cli.commands.auth.get_api_client")
    def test_whoami_logged_in(self, mock_client_factory: MagicMock) -> None:
        """Whoami shows user email when authenticated."""
        mock_client = MagicMock()
        mock_client.get.return_value = {
            "email": "nate@example.com",
            "name": "Nate Ritter",
            "id": "user_abc123",
        }
        mock_client_factory.return_value = mock_client

        result = runner.invoke(app, ["whoami"])

        assert result.exit_code == 0
        assert "nate@example.com" in result.output
        assert "Nate Ritter" in result.output
        mock_client.get.assert_called_once_with("/v1/auth/me", auth=True)

    @patch("agentpowers_cli.commands.auth.get_api_client")
    def test_whoami_not_logged_in(self, mock_client_factory: MagicMock) -> None:
        """Whoami fails with exit code 1 when not authenticated."""
        mock_client = MagicMock()
        mock_client.get.side_effect = APIError(
            "Not authenticated. Run `ap login` first.", status_code=401
        )
        mock_client_factory.return_value = mock_client

        result = runner.invoke(app, ["whoami"])

        assert result.exit_code == 1
        assert "Not logged in" in result.output

    @patch("agentpowers_cli.commands.auth.get_api_client")
    def test_whoami_api_error(self, mock_client_factory: MagicMock) -> None:
        """Whoami handles non-auth API errors gracefully."""
        mock_client = MagicMock()
        mock_client.get.side_effect = APIError("Server error", status_code=500)
        mock_client_factory.return_value = mock_client

        result = runner.invoke(app, ["whoami"])

        assert result.exit_code == 1
        assert "Error" in result.output

    @patch("agentpowers_cli.commands.auth.get_api_client")
    def test_whoami_minimal_user(self, mock_client_factory: MagicMock) -> None:
        """Whoami works with minimal user data (email only)."""
        mock_client = MagicMock()
        mock_client.get.return_value = {"email": "minimal@example.com"}
        mock_client_factory.return_value = mock_client

        result = runner.invoke(app, ["whoami"])

        assert result.exit_code == 0
        assert "minimal@example.com" in result.output


class TestFindFreePort:
    """Tests for the _find_free_port helper."""

    def test_returns_valid_port(self) -> None:
        """Returns an integer port in the valid range."""
        port = _find_free_port()
        assert isinstance(port, int)
        assert 1024 <= port <= 65535

    def test_returns_different_ports(self) -> None:
        """Consecutive calls can return different ports (non-deterministic)."""
        ports = {_find_free_port() for _ in range(5)}
        # At least 2 unique ports from 5 calls (probabilistic but safe)
        assert len(ports) >= 1


class TestGetApiClient:
    """Tests for the get_api_client helper."""

    def test_returns_api_client(self) -> None:
        """Returns an APIClient instance."""
        client = get_api_client()
        assert isinstance(client, APIClient)


class TestCallbackHandler:
    """Tests for the _CallbackHandler HTTP handler."""

    @staticmethod
    def _make_handler(
        path: str,
    ) -> tuple[_CallbackHandler, MagicMock]:
        """Create a _CallbackHandler with a mock request.

        Args:
            path: The request path (e.g., "/callback?token=abc").

        Returns:
            A tuple of (handler, mock_server).
        """
        handler = _CallbackHandler.__new__(_CallbackHandler)
        handler.path = path
        handler.wfile = BytesIO()
        handler.requestline = f"GET {path} HTTP/1.1"
        handler.request_version = "HTTP/1.1"
        handler.client_address = ("127.0.0.1", 12345)

        mock_server = MagicMock()
        mock_server.received_token = None
        mock_server.expected_state = None  # No CSRF check for unit tests
        handler.server = mock_server

        # Mock response methods
        handler.send_response = MagicMock()  # type: ignore[assignment]
        handler.send_header = MagicMock()  # type: ignore[assignment]
        handler.end_headers = MagicMock()  # type: ignore[assignment]

        return handler, mock_server

    def test_callback_with_token(self) -> None:
        """Handler extracts token from query string and stores it."""
        handler, mock_server = self._make_handler("/callback?token=test-jwt-123")
        handler.do_GET()

        assert mock_server.received_token == "test-jwt-123"
        handler.send_response.assert_called_once_with(200)
        output = handler.wfile.getvalue()
        assert b"Logged in to AgentPowers" in output

    def test_callback_without_token(self) -> None:
        """Handler returns 400 when token is missing."""
        handler, mock_server = self._make_handler("/callback")
        handler.do_GET()

        assert mock_server.received_token is None
        handler.send_response.assert_called_once_with(400)
        output = handler.wfile.getvalue()
        assert b"Missing token" in output

    def test_non_callback_path(self) -> None:
        """Handler returns 404 for non-callback paths."""
        handler, mock_server = self._make_handler("/other")
        handler.do_GET()

        handler.send_response.assert_called_once_with(404)

    def test_log_message_suppressed(self) -> None:
        """Handler suppresses HTTP log messages."""
        handler, _ = self._make_handler("/callback?token=x")
        # Should not raise
        handler.log_message("GET /callback 200")


class TestStartAuthServer:
    """Tests for the start_auth_server function."""

    def test_receives_token_via_callback(self) -> None:
        """Server receives token from an HTTP callback request."""
        port = _find_free_port()

        def send_callback() -> None:
            """Send a callback request after a short delay."""
            import time

            time.sleep(0.3)
            try:
                httpx.get(
                    f"http://127.0.0.1:{port}/callback?token=integration-jwt",
                    timeout=5,
                )
            except httpx.ConnectError:
                pass

        thread = threading.Thread(target=send_callback, daemon=True)
        thread.start()

        token = start_auth_server(port, timeout=5)
        assert token == "integration-jwt"

    def test_returns_none_on_timeout(self) -> None:
        """Server returns None when timeout expires without callback."""
        port = _find_free_port()
        token = start_auth_server(port, timeout=1)
        assert token is None


class TestOpenBrowser:
    """Test the open_browser helper."""

    @patch("agentpowers_cli.commands.auth.webbrowser.open")
    def test_open_browser_calls_webbrowser(self, mock_open: MagicMock) -> None:
        """open_browser delegates to webbrowser.open."""
        from agentpowers_cli.commands.auth import open_browser

        open_browser("https://example.com")
        mock_open.assert_called_once_with("https://example.com")
