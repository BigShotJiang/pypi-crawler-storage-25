"""Smoke tests for all 16 CLI commands — happy-path only.

Each test class covers one command, verifying exit_code 0 and
key output strings with mocked API calls.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------------


class TestSmokeVersion:
    """Smoke tests for ap --version."""

    def test_version_flag(self) -> None:
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "agentpowers" in result.output


# ---------------------------------------------------------------------------
# Whoami
# ---------------------------------------------------------------------------


class TestSmokeWhoami:
    """Smoke tests for ap whoami."""

    @patch("agentpowers_cli.commands.auth.get_api_client")
    def test_whoami_happy_path(self, mock_get_client: MagicMock) -> None:
        client = MagicMock()
        client.get.return_value = {
            "email": "test@example.com",
            "name": "Test User",
        }
        mock_get_client.return_value = client

        result = runner.invoke(app, ["whoami"])
        assert result.exit_code == 0
        assert "test@example.com" in result.output


# ---------------------------------------------------------------------------
# Logout
# ---------------------------------------------------------------------------


class TestSmokeLogout:
    """Smoke tests for ap logout."""

    @patch("agentpowers_cli.commands.auth.delete_token")
    @patch("agentpowers_cli.commands.auth.get_api_client")
    def test_logout_happy_path(
        self, mock_get_client: MagicMock, mock_delete: MagicMock
    ) -> None:
        client = MagicMock()
        client.post.return_value = {}
        mock_get_client.return_value = client

        result = runner.invoke(app, ["logout"])
        assert result.exit_code == 0
        assert "Logged out" in result.output
        mock_delete.assert_called_once()


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


class TestSmokeSearch:
    """Smoke tests for ap search."""

    @patch("agentpowers_cli.commands.search._get_installed_slugs", return_value={})
    @patch("agentpowers_cli.commands.search.get_api_client")
    def test_search_happy_path(
        self, mock_get_client: MagicMock, _mock_slugs: MagicMock
    ) -> None:
        client = MagicMock()
        client.get.return_value = {
            "agentpowers": {
                "items": [
                    {
                        "slug": "cool-skill",
                        "title": "Cool Skill",
                        "price_cents": 0,
                        "security_status": "pass",
                        "type": "skill",
                    }
                ],
                "total": 1,
                "limit": 20,
                "offset": 0,
            },
            "clawhub": {"items": [], "total": 0, "limit": 20, "offset": 0},
        }
        mock_get_client.return_value = client

        result = runner.invoke(app, ["search", "cool"])
        assert result.exit_code == 0
        assert "cool-skill" in result.output

    @patch("agentpowers_cli.commands.search._get_installed_slugs", return_value={})
    @patch("agentpowers_cli.commands.search.get_api_client")
    def test_search_with_type_filter(
        self, mock_get_client: MagicMock, _mock_slugs: MagicMock
    ) -> None:
        client = MagicMock()
        client.get.return_value = {
            "agentpowers": {
                "items": [
                    {
                        "slug": "test-skill",
                        "title": "Test Skill",
                        "price_cents": 0,
                        "security_status": "pass",
                        "type": "skill",
                    }
                ],
                "total": 1,
                "limit": 20,
                "offset": 0,
            },
            "clawhub": {"items": [], "total": 0, "limit": 20, "offset": 0},
        }
        mock_get_client.return_value = client

        result = runner.invoke(app, ["search", "--type", "skill", "test"])
        assert result.exit_code == 0
        # Verify the type filter was sent to the API
        call_params = client.get.call_args[1].get("params", {})
        assert call_params.get("type") == "skill"

    @patch("agentpowers_cli.commands.search._get_installed_slugs", return_value={})
    @patch("agentpowers_cli.commands.search.get_api_client")
    def test_search_with_all_filters(
        self, mock_get_client: MagicMock, _mock_slugs: MagicMock
    ) -> None:
        client = MagicMock()
        client.get.return_value = {
            "agentpowers": {
                "items": [],
                "total": 0,
                "limit": 5,
                "offset": 0,
            },
            "clawhub": {"items": [], "total": 0, "limit": 5, "offset": 0},
        }
        mock_get_client.return_value = client

        result = runner.invoke(
            app, ["search", "--category", "dev", "--type", "agent", "--limit", "5", "test"]
        )
        assert result.exit_code == 0
        # Verify all filter params were sent to the API
        call_params = client.get.call_args[1].get("params", {})
        assert call_params.get("category") == "dev"
        assert call_params.get("type") == "agent"
        assert call_params.get("limit") == 5
        assert call_params.get("q") == "test"


# ---------------------------------------------------------------------------
# Detail
# ---------------------------------------------------------------------------


class TestSmokeDetail:
    """Smoke tests for ap detail."""

    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_detail_happy_path(self, mock_get_client: MagicMock) -> None:
        client = MagicMock()
        client.get.return_value = {
            "slug": "my-skill",
            "title": "My Skill",
            "description": "A great skill",
            "price_cents": 0,
            "security_status": "pass",
            "type": "skill",
            "version": "1.0.0",
            "category": "development",
            "platforms": ["claude-code"],
        }
        mock_get_client.return_value = client

        result = runner.invoke(app, ["detail", "my-skill"])
        assert result.exit_code == 0
        assert "My Skill" in result.output

    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_detail_with_source(self, mock_get_client: MagicMock) -> None:
        client = MagicMock()
        client.get.return_value = {
            "slug": "my-skill",
            "title": "My Skill",
            "description": "External skill",
            "price_cents": 0,
            "security_status": "pass",
            "type": "skill",
            "source": "clawhub",
            "platforms": [],
        }
        mock_get_client.return_value = client

        result = runner.invoke(app, ["detail", "my-skill", "--source", "clawhub"])
        assert result.exit_code == 0
        # Verify source param was sent to the API
        call_params = client.get.call_args[1].get("params", {})
        assert call_params.get("source") == "clawhub"


# ---------------------------------------------------------------------------
# Scan
# ---------------------------------------------------------------------------


class TestSmokeScan:
    """Smoke tests for ap scan."""

    @patch("agentpowers_cli.commands.scan.shutil")
    @patch("agentpowers_cli.commands.scan._upload_for_scan")
    @patch("agentpowers_cli.commands.scan._download_to_sandbox")
    @patch("agentpowers_cli.commands.scan._resolve_source")
    @patch("agentpowers_cli.commands.scan.get_api_client")
    def test_scan_happy_path(
        self,
        mock_get_client: MagicMock,
        mock_resolve: MagicMock,
        mock_download: MagicMock,
        mock_upload: MagicMock,
        mock_shutil: MagicMock,
    ) -> None:
        mock_get_client.return_value = MagicMock()
        mock_resolve.return_value = "clawhub"
        mock_download.return_value = ("/tmp/ap-scan-test", "clawhub")
        mock_upload.return_value = {
            "security_status": "pass",
            "security_score": 10,
            "layers": [],
            "findings": [],
        }

        result = runner.invoke(app, ["scan", "some-skill"])
        assert result.exit_code == 0
        assert "PASS" in result.output
        # Verify scan pipeline was invoked
        mock_resolve.assert_called_once()
        mock_download.assert_called_once()
        mock_upload.assert_called_once()


# ---------------------------------------------------------------------------
# Install
# ---------------------------------------------------------------------------


class TestSmokeInstall:
    """Smoke tests for ap install."""

    @patch("agentpowers_cli.commands.install._record_installation")
    @patch("agentpowers_cli.commands.install.save_pin")
    @patch("agentpowers_cli.commands.install.hash_directory", return_value="abc123")
    @patch("agentpowers_cli.commands.install.install_from_url")
    @patch("agentpowers_cli.commands.install.detect_install_base", return_value=None)
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_free_skill(
        self,
        mock_get_client: MagicMock,
        mock_detect: MagicMock,
        mock_install_url: MagicMock,
        mock_hash: MagicMock,
        mock_save_pin: MagicMock,
        mock_record: MagicMock,
    ) -> None:
        client = MagicMock()
        client.get.side_effect = [
            # /v1/skills/{slug}
            {
                "slug": "my-skill",
                "title": "My Skill",
                "price_cents": 0,
                "security_status": "pass",
                "type": "skill",
                "version": "1.0.0",
                "source": "agentpowers",
            },
            # /v1/skills/{slug}/download
            {"url": "https://example.com/package.zip", "slug": "my-skill"},
        ]
        mock_get_client.return_value = client
        mock_install_url.return_value = "/tmp/skills/my-skill"

        result = runner.invoke(app, ["install", "my-skill"])
        assert result.exit_code == 0
        assert "my-skill" in result.output
        # Verify the correct API endpoints were called in order
        assert client.get.call_count == 2
        first_call_url = client.get.call_args_list[0][0][0]
        assert "/v1/skills/my-skill" in first_call_url
        mock_install_url.assert_called_once()
        mock_save_pin.assert_called_once()

    @patch("agentpowers_cli.commands.install._record_installation")
    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.detect_install_base", return_value=None)
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_for_codex(
        self,
        mock_get_client: MagicMock,
        mock_detect: MagicMock,
        mock_ext_install: MagicMock,
        mock_record: MagicMock,
    ) -> None:
        client = MagicMock()
        from agentpowers_cli.services.api_client import APIError

        # All lookups return 404 so the code falls through to the external-search
        # path (which is mocked at a higher level via _search_external_sources).
        client.get.side_effect = APIError("Not found", status_code=404)
        mock_get_client.return_value = client
        mock_ext_install.return_value = "/home/.codex/skills/my-skill"

        with patch(
            "agentpowers_cli.commands.install._search_external_sources"
        ) as mock_search_ext:
            mock_search_ext.return_value = [
                {"slug": "my-skill", "source": "clawhub", "title": "My Skill"}
            ]
            result = runner.invoke(app, ["install", "my-skill", "--for", "codex"])

        assert result.exit_code == 0
        assert "my-skill" in result.output


# ---------------------------------------------------------------------------
# Uninstall
# ---------------------------------------------------------------------------


class TestSmokeUninstall:
    """Smoke tests for ap uninstall."""

    @patch("agentpowers_cli.commands.uninstall.get_install_candidate_dirs")
    def test_uninstall_happy_path(
        self, mock_claude_dir: MagicMock, tmp_path: Path
    ) -> None:
        mock_claude_dir.return_value = [tmp_path]
        skill_dir = tmp_path / "skills" / "my-skill"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("# skill")

        # Write a pins.json with the slug
        pins_path = tmp_path / "pins.json"
        pins_path.write_text(json.dumps({"my-skill": {"source": "agentpowers"}}))

        with patch(
            "agentpowers_cli.commands.uninstall.DEFAULT_PINS_PATH",
            str(pins_path),
        ):
            result = runner.invoke(app, ["uninstall", "my-skill", "--force"])

        assert result.exit_code == 0
        assert "Uninstalled" in result.output


# ---------------------------------------------------------------------------
# Status
# ---------------------------------------------------------------------------


class TestSmokeStatus:
    """Smoke tests for ap status."""

    @patch("agentpowers_cli.commands.status.load_token", return_value="tok")
    @patch("agentpowers_cli.commands.status.get_install_candidate_dirs")
    def test_status_happy_path(
        self, mock_claude_dir: MagicMock, mock_token: MagicMock, tmp_path: Path
    ) -> None:
        mock_claude_dir.return_value = [tmp_path]
        # Create empty skills/agents directories
        (tmp_path / "skills").mkdir()
        (tmp_path / "agents").mkdir()

        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "Logged in" in result.output


# ---------------------------------------------------------------------------
# Update
# ---------------------------------------------------------------------------


class TestSmokeUpdate:
    """Smoke tests for ap update."""

    @patch("agentpowers_cli.commands.update.get_api_client")
    @patch("agentpowers_cli.commands.update.load_pins")
    def test_update_no_updates(
        self, mock_load_pins: MagicMock, mock_get_client: MagicMock
    ) -> None:
        mock_load_pins.return_value = {}
        mock_get_client.return_value = MagicMock()

        result = runner.invoke(app, ["update"])
        assert result.exit_code == 0
        assert "No skills installed" in result.output


# ---------------------------------------------------------------------------
# Verify
# ---------------------------------------------------------------------------


class TestSmokeVerify:
    """Smoke tests for ap verify."""

    @patch("agentpowers_cli.commands.verify.get_install_candidate_dirs")
    @patch("agentpowers_cli.commands.verify.load_pins")
    @patch("agentpowers_cli.commands.verify.hash_directory")
    def test_verify_happy_path(
        self,
        mock_hash: MagicMock,
        mock_load_pins: MagicMock,
        mock_claude_dir: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_claude_dir.return_value = [tmp_path]
        (tmp_path / "skills" / "my-skill").mkdir(parents=True)

        mock_load_pins.return_value = {
            "my-skill": {
                "content_hash": "abc123",
                "source": "agentpowers",
            }
        }
        mock_hash.return_value = "abc123"

        result = runner.invoke(app, ["verify"])
        assert result.exit_code == 0
        assert "OK" in result.output


# ---------------------------------------------------------------------------
# Publish
# ---------------------------------------------------------------------------


class TestSmokePublish:
    """Smoke tests for ap publish."""

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_new_skill(
        self, mock_get_client: MagicMock, skill_dir: Path
    ) -> None:
        client = MagicMock()
        client.post.return_value = {"slug": "test-skill"}
        client.upload.return_value = {}
        mock_get_client.return_value = client

        result = runner.invoke(app, ["publish", "--dir", str(skill_dir)])
        assert result.exit_code == 0
        assert "Published" in result.output
        assert "test-skill" in result.output


# ---------------------------------------------------------------------------
# Unpublish
# ---------------------------------------------------------------------------


class TestSmokeUnpublish:
    """Smoke tests for ap unpublish."""

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_happy_path(self, mock_get_client: MagicMock) -> None:
        client = MagicMock()
        client.post.return_value = {"message": "Skill unpublished."}
        mock_get_client.return_value = client

        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code == 0
        assert "unpublished" in result.output.lower()


# ---------------------------------------------------------------------------
# Republish
# ---------------------------------------------------------------------------


class TestSmokeRepublish:
    """Smoke tests for ap republish."""

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_happy_path(self, mock_get_client: MagicMock) -> None:
        client = MagicMock()
        client.post.return_value = {"message": "Skill republished."}
        mock_get_client.return_value = client

        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 0
        assert "republished" in result.output.lower()


# Note: `ap claim` was removed in commit 2829cec ("not ready for public release").
# TestSmokeClaim removed to match.


# ---------------------------------------------------------------------------
# Profile
# ---------------------------------------------------------------------------


class TestSmokeProfile:
    """Smoke tests for ap profile."""

    @patch("agentpowers_cli.commands.profile.get_api_client")
    def test_profile_view(self, mock_get_client: MagicMock) -> None:
        client = MagicMock()
        client.get.return_value = {
            "display_name": "Test User",
            "email": "test@example.com",
            "bio": "I build things",
            "created_at": "2026-01-01T00:00:00Z",
        }
        mock_get_client.return_value = client

        result = runner.invoke(app, ["profile"])
        assert result.exit_code == 0
        assert "Test User" in result.output
