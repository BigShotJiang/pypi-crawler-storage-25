"""Tests for the AgentPowers CLI banner module."""

from io import StringIO
from unittest.mock import patch

from rich.console import Console

from agentpowers_cli.banner import TEAL, _get_version, print_banner


class TestGetVersion:
    """Tests for _get_version helper."""

    def test_returns_version_string(self):
        """Should return a version string."""
        ver = _get_version()
        assert isinstance(ver, str)
        assert len(ver) > 0

    def test_fallback_on_error(self):
        """Should return fallback version when package is not installed."""
        with patch(
            "agentpowers_cli.banner.pkg_version",
            side_effect=Exception("not found"),
        ):
            assert _get_version() == "0.1.0"


class TestPrintBanner:
    """Tests for print_banner display."""

    def test_prints_brand_mark(self):
        """Banner should contain the geometric icon characters."""
        buf = StringIO()
        console = Console(file=buf, force_terminal=True, width=80)
        print_banner(console)
        output = buf.getvalue()
        assert "████" in output
        assert "██████" in output
        assert "██" in output

    def test_prints_wordmark(self):
        """Banner should contain the AgentPowers wordmark."""
        buf = StringIO()
        console = Console(file=buf, force_terminal=True, width=80)
        print_banner(console)
        output = buf.getvalue()
        assert "AgentPowers" in output

    def test_prints_tagline(self):
        """Banner should contain the tagline."""
        buf = StringIO()
        console = Console(file=buf, force_terminal=True, width=80)
        print_banner(console)
        output = buf.getvalue()
        assert "Premium Claude skills & agents" in output

    def test_prints_url(self):
        """Banner should contain the website URL."""
        buf = StringIO()
        console = Console(file=buf, force_terminal=True, width=80)
        print_banner(console)
        output = buf.getvalue()
        assert "agentpowers.ai" in output

    def test_prints_version(self):
        """Banner should contain a version indicator."""
        buf = StringIO()
        console = Console(file=buf, force_terminal=True, width=80)
        print_banner(console)
        output = buf.getvalue()
        assert "v" in output

    def test_creates_console_when_none(self):
        """Should create its own console if none provided."""
        # Just verify it doesn't raise
        print_banner(None)

    def test_teal_color_constant(self):
        """Brand teal constant should be the correct hex."""
        assert TEAL == "#5fbab8"
