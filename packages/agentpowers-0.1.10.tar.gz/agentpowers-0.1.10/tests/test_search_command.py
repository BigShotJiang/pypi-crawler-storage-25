"""Tests for the search command."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError

runner = CliRunner()

# All tests mock _get_installed_slugs to avoid filesystem access.
# The "installed" decorator must come BEFORE get_api_client (outermost = last arg).
_NO_INSTALLS = patch(
    "agentpowers_cli.commands.search._get_installed_slugs", return_value={}
)


def _make_mock_client(return_value: dict) -> MagicMock:
    """Create a mock APIClient that returns the given value from get().

    Args:
        return_value: The dict to return from client.get().

    Returns:
        A configured MagicMock.
    """
    mock_client = MagicMock()
    mock_client.get.return_value = return_value
    return mock_client


def _sectioned(native_items=None, clawhub_items=None):
    """Build a sectioned search response."""
    return {
        "agentpowers": {
            "items": native_items or [],
            "total": len(native_items or []),
            "limit": 20,
            "offset": 0,
        },
        "clawhub": {
            "total": len(clawhub_items or []),
            "items": clawhub_items or [],
        },
    }


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_with_native_results(mock_get_client: MagicMock, _m) -> None:
    """Search with native results displays slug, price, and source."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "code-reviewer",
                    "title": "Code Reviewer",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 1200,
                    "download_count": 42,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "reviewer"])

    assert result.exit_code == 0
    assert "code-reviewer" in result.output
    assert "$12" in result.output
    # Source may be truncated by Rich table width
    assert "agentpow" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_native_title_shows_downloads(mock_get_client: MagicMock, _m) -> None:
    """Native results show download count inline with title."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "popular-skill",
                    "title": "Popular Skill",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 0,
                    "download_count": 99,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "popular"])

    assert result.exit_code == 0
    # Download count should appear inline with title
    assert "99" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_with_external_results(mock_get_client: MagicMock, _m) -> None:
    """External results display with installs/stars inline in title."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "ext-skill",
                    "title": "External Skill",
                    "source": "clawhub",
                    "source_installs": 500,
                    "source_stars": 42,
                    "version": "1.0.0",
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "ext"])

    assert result.exit_code == 0
    assert "ext-skill" in result.output
    assert "clawhub" in result.output
    assert "500" in result.output  # Installs inline
    assert "42" in result.output  # Stars inline


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_external_null_fields_show_no_stats(
    mock_get_client: MagicMock, _m
) -> None:
    """External results with null installs/stars show title without stats."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "stripe-best-practices",
                    "title": "Stripe Best Practices",
                    "source": "clawhub",
                    "source_installs": None,
                    "source_stars": None,
                    "version": None,
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "stripe"])

    assert result.exit_code == 0
    assert "stripe-best-practices" in result.output
    assert "None" not in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_no_results(mock_get_client: MagicMock, _m) -> None:
    """Empty results display 'No results found.' message."""
    mock_client = _make_mock_client(_sectioned())
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "nonexistent"])

    assert result.exit_code == 0
    assert "No results found." in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_free_skill_shows_free(mock_get_client: MagicMock, _m) -> None:
    """A skill with price_cents=0 displays 'Free' in the output."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "free-tool",
                    "title": "Free Tool",
                    "type": "skill",
                    "category": "utilities",
                    "price_cents": 0,
                    "download_count": 100,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "free"])

    assert result.exit_code == 0
    assert "Free" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_unified_table_has_installs_stars_inline(
    mock_get_client: MagicMock,
    _m,
) -> None:
    """External results show installs and stars inline with title."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "starry-skill",
                    "title": "Starry",
                    "source": "clawhub",
                    "source_installs": 10,
                    "source_stars": 99,
                    "version": "2.0.0",
                    "ap_security_status": "pass",
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "starry"])

    assert result.exit_code == 0
    assert "99" in result.output
    assert "10" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_external_null_stars_no_star_in_title(
    mock_get_client: MagicMock,
    _m,
) -> None:
    """External results with null stars omit star stat from title."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "no-stars",
                    "title": "No Stars",
                    "source": "clawhub",
                    "source_installs": 5,
                    "source_stars": None,
                    "version": "1.0.0",
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "no-stars"])

    assert result.exit_code == 0
    assert "5" in result.output  # installs still shown
    assert "None" not in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_with_category_filter(mock_get_client: MagicMock, _m) -> None:
    """Passing --category includes category in API request params."""
    mock_client = _make_mock_client(_sectioned())
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "test", "--category", "dev-tools"])

    assert result.exit_code == 0
    call_kwargs = mock_client.get.call_args
    params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
    assert params["category"] == "dev-tools"


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_mixed_results_native_first(mock_get_client: MagicMock, _m) -> None:
    """Native items appear before external items in the unified table."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "native-skill",
                    "title": "Native Skill",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 0,
                    "download_count": 10,
                    "security_status": "pass",
                },
            ],
            clawhub_items=[
                {
                    "slug": "ext-skill",
                    "title": "External Skill",
                    "source": "clawhub",
                    "source_installs": 5,
                    "source_stars": 3,
                    "version": "1.0.0",
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ],
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "skill"])

    assert result.exit_code == 0
    assert "native-skill" in result.output
    assert "ext-skill" in result.output
    native_pos = result.output.index("native-skill")
    ext_pos = result.output.index("ext-skill")
    assert native_pos < ext_pos


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_paid_before_free(mock_get_client: MagicMock, _m) -> None:
    """Paid items sort above free items within the same source group."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "free-skill",
                    "title": "Free Skill",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 0,
                    "download_count": 100,
                    "security_status": "pass",
                },
                {
                    "slug": "paid-skill",
                    "title": "Paid Skill",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 500,
                    "download_count": 50,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "skill"])

    assert result.exit_code == 0
    paid_pos = result.output.index("paid-skill")
    free_pos = result.output.index("free-skill")
    assert paid_pos < free_pos


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_no_category_or_version_columns(mock_get_client: MagicMock, _m) -> None:
    """Unified table does not have Category or Version column headers."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "some-skill",
                    "title": "Some Skill",
                    "type": "skill",
                    "category": "dev-tools",
                    "price_cents": 0,
                    "version": "1.0.0",
                    "download_count": 5,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "some"])

    assert result.exit_code == 0
    # These columns should NOT appear as headers
    assert "Category" not in result.output
    assert "Version" not in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_external_item_shows_type_skill(mock_get_client: MagicMock, _m) -> None:
    """External items show type 'skill' in the Type column."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "self-improving-agent",
                    "title": "Self-Improving Agent",
                    "source": "clawhub",
                    "type": "skill",
                    "source_installs": 951,
                    "source_stars": 1040,
                    "version": "1.0.11",
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "agent"])

    assert result.exit_code == 0
    assert "skill" in result.output
    # The em-dash should NOT appear when type is present
    assert "\u2014" not in result.output


# --- Installed column tests ---


@patch(
    "agentpowers_cli.commands.search._get_installed_slugs",
    return_value={"code-reviewer": "clean"},
)
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_installed_column_header(mock_get_client: MagicMock, _m) -> None:
    """The Installed column header appears in the table output."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "code-reviewer",
                    "title": "Code Reviewer",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 10,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "code"])

    assert result.exit_code == 0
    assert "Installed" in result.output


@patch(
    "agentpowers_cli.commands.search._get_installed_slugs",
    return_value={"my-skill": "clean"},
)
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_installed_skill_shows_yes(mock_get_client: MagicMock, _m) -> None:
    """An installed skill displays 'Yes' in the Installed column."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "my-skill",
                    "title": "My Skill",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 5,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "my"])

    assert result.exit_code == 0
    assert "Yes" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_not_installed_skill_shows_no(mock_get_client: MagicMock, _m) -> None:
    """A skill that is NOT installed displays 'No' in the Installed column."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "other-skill",
                    "title": "Other Skill",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 5,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "other"])

    assert result.exit_code == 0
    assert "No" in result.output


@patch(
    "agentpowers_cli.commands.search._get_installed_slugs",
    return_value={"native-skill": "clean"},
)
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_mixed_installed_and_not(mock_get_client: MagicMock, _m) -> None:
    """Mixed results correctly show Yes for installed and No for not installed."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "native-skill",
                    "title": "Installed Skill",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 10,
                    "security_status": "pass",
                },
                {
                    "slug": "not-installed",
                    "title": "Not Installed Skill",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 5,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "skill"])

    assert result.exit_code == 0
    assert "Yes" in result.output
    assert "No" in result.output


@patch(
    "agentpowers_cli.commands.search._get_installed_slugs",
    return_value={"ext-installed": "clean"},
)
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_external_installed_shows_yes(mock_get_client: MagicMock, _m) -> None:
    """An installed external skill displays 'Yes' in the Installed column."""
    mock_client = _make_mock_client(
        _sectioned(
            clawhub_items=[
                {
                    "slug": "ext-installed",
                    "title": "Ext Installed",
                    "source": "clawhub",
                    "source_installs": 100,
                    "source_stars": 50,
                    "version": "1.0.0",
                    "ap_security_status": "pass",
                    "price_cents": 0,
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "ext"])

    assert result.exit_code == 0
    assert "Yes" in result.output


# --------------- Additional coverage tests ---------------


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_api_error(mock_get_client: MagicMock, _m) -> None:
    """Search exits with code 1 when API returns an error."""
    mock_client = MagicMock()
    mock_client.get.side_effect = APIError("Server error", status_code=500)
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "test"])

    assert result.exit_code == 1
    assert "Error" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_with_type_filter(mock_get_client: MagicMock, _m) -> None:
    """Passing --type skill includes type in API request params."""
    mock_client = _make_mock_client(_sectioned())
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "test", "--type", "skill"])

    assert result.exit_code == 0
    call_kwargs = mock_client.get.call_args
    params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
    assert params["type"] == "skill"


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_invalid_type(mock_get_client: MagicMock, _m) -> None:
    """Passing an invalid --type exits with code 1."""
    mock_client = _make_mock_client(_sectioned())
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "test", "--type", "bogus"])

    assert result.exit_code == 1
    assert "Invalid --type" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_limit_less_than_one(mock_get_client: MagicMock, _m) -> None:
    """Passing --limit 0 exits with code 1."""
    mock_client = _make_mock_client(_sectioned())
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "test", "--limit", "0"])

    assert result.exit_code == 1
    assert "--limit must be at least 1" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_multi_word_query(mock_get_client: MagicMock, _m) -> None:
    """Multiple words are joined with spaces for the query."""
    mock_client = _make_mock_client(_sectioned())
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "code", "review", "tool"])

    assert result.exit_code == 0
    call_kwargs = mock_client.get.call_args
    params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
    assert params["q"] == "code review tool"


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_empty_query(mock_get_client: MagicMock, _m) -> None:
    """Empty query string exits with code 1."""
    mock_client = _make_mock_client(_sectioned())
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", " "])

    assert result.exit_code == 1
    assert "empty" in result.output.lower()


class TestGetInstalledSlugs:
    """Tests for _get_installed_slugs function using real filesystem."""

    @patch("agentpowers_cli.commands.search.load_pins")
    def test_pins_without_hash_marked_clean(self, mock_load_pins, tmp_path):
        """Pinned skills without content_hash are marked clean."""
        from agentpowers_cli.commands.search import _get_installed_slugs

        mock_load_pins.return_value = {
            "my-skill": {"source": "clawhub", "version": "1.0.0"},
        }

        with patch.object(Path, "home", return_value=tmp_path):
            result = _get_installed_slugs()

        assert result["my-skill"] == "clean"

    @patch("agentpowers_cli.commands.search.hash_directory")
    @patch("agentpowers_cli.commands.search.load_pins")
    def test_pins_with_matching_hash_marked_clean(
        self, mock_load_pins, mock_hash, tmp_path
    ):
        """Pinned skills with matching content_hash are clean."""
        from agentpowers_cli.commands.search import _get_installed_slugs

        mock_load_pins.return_value = {
            "my-skill": {"content_hash": "abc123"},
        }
        # Create the install directory on real filesystem
        install_dir = tmp_path / ".claude" / "skills" / "my-skill"
        install_dir.mkdir(parents=True)
        mock_hash.return_value = "abc123"

        with patch.object(Path, "home", return_value=tmp_path):
            result = _get_installed_slugs()

        assert result["my-skill"] == "clean"

    @patch("agentpowers_cli.commands.search.hash_directory")
    @patch("agentpowers_cli.commands.search.load_pins")
    def test_pins_with_mismatched_hash_marked_edited(
        self, mock_load_pins, mock_hash, tmp_path
    ):
        """Pinned skills with different content_hash are marked edited."""
        from agentpowers_cli.commands.search import _get_installed_slugs

        mock_load_pins.return_value = {
            "my-skill": {"content_hash": "abc123"},
        }
        install_dir = tmp_path / ".claude" / "skills" / "my-skill"
        install_dir.mkdir(parents=True)
        mock_hash.return_value = "different-hash"

        with patch.object(Path, "home", return_value=tmp_path):
            result = _get_installed_slugs()

        assert result["my-skill"] == "edited"

    @patch("agentpowers_cli.commands.search.load_pins")
    def test_filesystem_non_pinned_skills_detected(self, mock_load_pins, tmp_path):
        """Skills in ~/.claude/skills/ not in pins are detected as clean."""
        from agentpowers_cli.commands.search import _get_installed_slugs

        mock_load_pins.return_value = {}
        # Create a skill directory on real filesystem
        skill_dir = tmp_path / ".claude" / "skills" / "local-skill"
        skill_dir.mkdir(parents=True)

        with patch.object(Path, "home", return_value=tmp_path):
            result = _get_installed_slugs()

        assert result["local-skill"] == "clean"

    @patch("agentpowers_cli.commands.search.hash_directory")
    @patch("agentpowers_cli.commands.search.load_pins")
    def test_hash_error_falls_back_to_clean(
        self, mock_load_pins, mock_hash, tmp_path
    ):
        """If hash_directory raises, the skill is still marked clean."""
        from agentpowers_cli.commands.search import _get_installed_slugs

        mock_load_pins.return_value = {
            "my-skill": {"content_hash": "abc123"},
        }
        install_dir = tmp_path / ".claude" / "skills" / "my-skill"
        install_dir.mkdir(parents=True)
        mock_hash.side_effect = OSError("permission denied")

        with patch.object(Path, "home", return_value=tmp_path):
            result = _get_installed_slugs()

        assert result["my-skill"] == "clean"


class TestFormatInstalled:
    """Tests for _format_installed helper."""

    def test_edited_returns_yellow(self):
        from agentpowers_cli.commands.search import _format_installed

        result = _format_installed("my-skill", {"my-skill": "edited"})
        assert "Edited" in result
        assert "yellow" in result

    def test_clean_returns_green(self):
        from agentpowers_cli.commands.search import _format_installed

        result = _format_installed("my-skill", {"my-skill": "clean"})
        assert "Yes" in result

    def test_not_installed_returns_no(self):
        from agentpowers_cli.commands.search import _format_installed

        result = _format_installed("my-skill", {})
        assert result == "No"


class TestBuildUnifiedTable:
    """Tests for _build_unified_table."""

    @patch(
        "agentpowers_cli.commands.search._get_installed_slugs", return_value={}
    )
    def test_empty_inputs(self, _m):
        """Empty native and external inputs produce a table with only headers."""
        from agentpowers_cli.commands.search import _build_unified_table

        table = _build_unified_table([], {})

        assert table.row_count == 0

    @patch(
        "agentpowers_cli.commands.search._get_installed_slugs", return_value={}
    )
    def test_native_and_external(self, _m):
        """Table includes both native and external rows."""
        from agentpowers_cli.commands.search import _build_unified_table

        native = [
            {
                "slug": "n-skill",
                "title": "Native",
                "type": "skill",
                "price_cents": 0,
                "download_count": 1,
                "security_status": "pass",
            }
        ]
        external = {
            "clawhub": {
                "items": [
                    {
                        "slug": "e-skill",
                        "title": "External",
                        "source": "clawhub",
                        "source_installs": 10,
                        "source_stars": 5,
                        "price_cents": 0,
                        "ap_security_status": None,
                    }
                ]
            }
        }

        table = _build_unified_table(native, external)

        assert table.row_count == 2

    @patch(
        "agentpowers_cli.commands.search._get_installed_slugs", return_value={}
    )
    def test_max_results_limits_total_rows(self, _m):
        """max_results limits total rows across native and external."""
        from agentpowers_cli.commands.search import _build_unified_table

        native = [
            {
                "slug": f"native-{i}",
                "title": f"Native {i}",
                "type": "skill",
                "price_cents": 0,
                "download_count": 1,
                "security_status": "pass",
            }
            for i in range(5)
        ]
        external = {
            "clawhub": {
                "items": [
                    {
                        "slug": f"ext-{i}",
                        "title": f"External {i}",
                        "source": "clawhub",
                        "source_installs": 10,
                        "source_stars": 5,
                        "price_cents": 0,
                        "ap_security_status": None,
                    }
                    for i in range(5)
                ]
            }
        }

        table = _build_unified_table(native, external, max_results=3)
        assert table.row_count == 3

    @patch(
        "agentpowers_cli.commands.search._get_installed_slugs", return_value={}
    )
    def test_max_results_none_shows_all(self, _m):
        """max_results=None shows all rows."""
        from agentpowers_cli.commands.search import _build_unified_table

        native = [
            {
                "slug": f"native-{i}",
                "title": f"Native {i}",
                "type": "skill",
                "price_cents": 0,
                "download_count": 1,
                "security_status": "pass",
            }
            for i in range(5)
        ]

        table = _build_unified_table(native, {}, max_results=None)
        assert table.row_count == 5


# --- Limit enforcement integration tests ---


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_limit_truncates_total_results(mock_get_client: MagicMock, _m) -> None:
    """--limit 2 with 3 native + 3 external shows only 2 rows and truncation note."""
    native_items = [
        {
            "slug": f"native-{i}",
            "title": f"Native {i}",
            "type": "skill",
            "price_cents": 0,
            "download_count": 1,
            "security_status": "pass",
        }
        for i in range(3)
    ]
    clawhub_items = [
        {
            "slug": f"ext-{i}",
            "title": f"External {i}",
            "source": "clawhub",
            "source_installs": 10,
            "source_stars": 5,
            "version": "1.0.0",
            "ap_security_status": None,
            "price_cents": 0,
        }
        for i in range(3)
    ]
    mock_client = _make_mock_client(_sectioned(native_items, clawhub_items))
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "test", "--limit", "2"])

    assert result.exit_code == 0
    assert "showing 2 of 6 results" in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_limit_no_truncation_note_when_within_limit(
    mock_get_client: MagicMock, _m
) -> None:
    """No truncation note when total results <= limit."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "only-one",
                    "title": "Only One",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 1,
                    "security_status": "pass",
                },
            ]
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "test", "--limit", "20"])

    assert result.exit_code == 0
    assert "showing" not in result.output


# --------------- --source filter tests ---------------


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_source_filter_agentpowers(mock_get_client: MagicMock, _m) -> None:
    """--source agentpowers shows only native results."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "native-skill",
                    "title": "Native Skill",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 10,
                    "security_status": "pass",
                },
            ],
            clawhub_items=[
                {
                    "slug": "ext-skill",
                    "title": "External Skill",
                    "source": "clawhub",
                    "source_installs": 5,
                    "source_stars": 3,
                    "version": "1.0.0",
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ],
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "skill", "--source", "agentpowers"])

    assert result.exit_code == 0
    assert "native-skill" in result.output
    assert "ext-skill" not in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_source_filter_clawhub(mock_get_client: MagicMock, _m) -> None:
    """--source clawhub shows only external results."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "native-skill",
                    "title": "Native Skill",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 10,
                    "security_status": "pass",
                },
            ],
            clawhub_items=[
                {
                    "slug": "ext-skill",
                    "title": "External Skill",
                    "source": "clawhub",
                    "source_installs": 5,
                    "source_stars": 3,
                    "version": "1.0.0",
                    "ap_security_status": None,
                    "price_cents": 0,
                },
            ],
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "skill", "--source", "clawhub"])

    assert result.exit_code == 0
    assert "ext-skill" in result.output
    assert "native-skill" not in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_source_filter_passes_param_to_api(
    mock_get_client: MagicMock, _m
) -> None:
    """--source passes source param to the API request."""
    mock_client = _make_mock_client(_sectioned())
    mock_get_client.return_value = mock_client

    runner.invoke(app, ["search", "test", "--source", "clawhub"])

    call_kwargs = mock_client.get.call_args
    params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
    assert params["source"] == "clawhub"


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_source_filter_no_results(mock_get_client: MagicMock, _m) -> None:
    """--source with no matching results shows 'No results found.'."""
    mock_client = _make_mock_client(
        _sectioned(
            native_items=[
                {
                    "slug": "native-skill",
                    "title": "Native",
                    "type": "skill",
                    "price_cents": 0,
                    "download_count": 10,
                    "security_status": "pass",
                },
            ],
        )
    )
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "skill", "--source", "clawhub"])

    assert result.exit_code == 0
    assert "No results found." in result.output


@_NO_INSTALLS
@patch("agentpowers_cli.commands.search.get_api_client")
def test_search_source_short_flag(mock_get_client: MagicMock, _m) -> None:
    """-s short flag works for --source."""
    mock_client = _make_mock_client(_sectioned())
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["search", "test", "-s", "agentpowers"])

    assert result.exit_code == 0
    call_kwargs = mock_client.get.call_args
    params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
    assert params["source"] == "agentpowers"
