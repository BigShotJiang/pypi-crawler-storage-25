"""Tests for the ap scan command."""

import io
import zipfile
from unittest.mock import MagicMock, patch

import click.exceptions
import httpx
import pytest

from agentpowers_cli.commands.scan import (
    _display_results,
    _download_to_sandbox,
    _extract_detail,
    _format_status,
    _layer_icon,
    _NativeSkillError,
    _resolve_source,
    _severity_color,
    _upload_for_scan,
    scan,
)
from agentpowers_cli.services.api_client import APIError


def _make_zip(files: dict[str, str]) -> bytes:
    """Create a valid ZIP archive from a dict of filename -> content."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, content in files.items():
            zf.writestr(name, content)
    return buf.getvalue()


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
@patch("agentpowers_cli.commands.scan._upload_for_scan")
def test_scan_pass(mock_upload, mock_download, mock_client, tmp_path, capsys):
    """ap scan <slug> shows pass result and cleans up sandbox."""
    # Setup sandbox with a skill file
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "SKILL.md").write_text("# Test Skill")
    mock_download.return_value = (str(sandbox), "clawhub")

    mock_upload.return_value = {
        "content_hash": "sha256:abc123",
        "security_status": "pass",
        "security_score": 0,
        "findings": [],
    }

    scan(slug="test-skill")

    # Verify download was called
    mock_download.assert_called_once()
    # Verify upload was called with sandbox path
    mock_upload.assert_called_once()


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
@patch("agentpowers_cli.commands.scan._upload_for_scan")
def test_scan_warn(mock_upload, mock_download, mock_client, tmp_path):
    """ap scan shows warnings when security_status is warn."""
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "SKILL.md").write_text("# Warn Skill")
    mock_download.return_value = (str(sandbox), "clawhub")

    mock_upload.return_value = {
        "content_hash": "sha256:def456",
        "security_status": "warn",
        "security_score": 4,
        "findings": [{"type": "warning", "message": "Suspicious pattern"}],
    }

    scan(slug="warn-skill")

    mock_upload.assert_called_once()


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
@patch("agentpowers_cli.commands.scan._upload_for_scan")
def test_scan_block(mock_upload, mock_download, mock_client, tmp_path):
    """ap scan shows block result and exits with code 1."""
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "SKILL.md").write_text("# Evil Skill")
    mock_download.return_value = (str(sandbox), "clawhub")

    mock_upload.return_value = {
        "content_hash": "sha256:evil789",
        "security_status": "block",
        "security_score": 10,
        "findings": [{"type": "critical", "message": "Malware detected"}],
    }

    with pytest.raises(click.exceptions.Exit) as exc_info:
        scan(slug="evil-skill")
    assert exc_info.value.exit_code == 1


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
def test_scan_download_failure(mock_download, mock_client):
    """ap scan exits with error when download fails."""
    mock_download.side_effect = RuntimeError("npx failed")

    with pytest.raises(click.exceptions.Exit) as exc_info:
        scan(slug="broken-skill")
    assert exc_info.value.exit_code == 1


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._resolve_source")
def test_scan_not_found(mock_resolve, mock_client):
    """ap scan exits with error when skill not found in any source."""
    mock_resolve.return_value = None

    with pytest.raises(click.exceptions.Exit) as exc_info:
        scan(slug="nonexistent-skill", source=None)
    assert exc_info.value.exit_code == 1


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
@patch("agentpowers_cli.commands.scan._upload_for_scan")
def test_scan_cleans_up_sandbox(mock_upload, mock_download, mock_client, tmp_path):
    """ap scan cleans up the sandbox directory after completion."""
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "SKILL.md").write_text("# Cleanup Test")
    mock_download.return_value = (str(sandbox), "clawhub")

    mock_upload.return_value = {
        "content_hash": "sha256:cleanup",
        "security_status": "pass",
        "security_score": 0,
        "findings": [],
    }

    scan(slug="cleanup-skill")

    # Sandbox should be cleaned up
    assert not sandbox.exists()


@patch("agentpowers_cli.commands.scan.get_api_client")
@patch("agentpowers_cli.commands.scan._download_to_sandbox")
@patch("agentpowers_cli.commands.scan._upload_for_scan")
def test_scan_uses_server_hash(mock_upload, mock_download, mock_client, tmp_path):
    """ap scan displays the server-computed hash, not any client-side hash."""
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "SKILL.md").write_text("# Hash Test")
    mock_download.return_value = (str(sandbox), "clawhub")

    mock_upload.return_value = {
        "content_hash": "sha256:server-computed-hash",
        "security_status": "pass",
        "security_score": 0,
        "findings": [],
    }

    scan(slug="hash-skill")

    # The upload function should have been called (we verify it sends to server)
    mock_upload.assert_called_once()


class TestResolveSource:
    """Tests for the _resolve_source helper."""

    def test_native_skill_raises_error(self):
        """_resolve_source raises _NativeSkillError for native AgentPowers skills."""
        client = MagicMock()
        client.get.return_value = {
            "agentpowers": {
                "items": [{"slug": "hello-world-test", "title": "Hello World"}],
                "total": 1,
            },
        }
        with pytest.raises(_NativeSkillError) as exc_info:
            _resolve_source(client, "hello-world-test")
        assert exc_info.value.slug == "hello-world-test"

    def test_external_skill_returns_source(self):
        """_resolve_source returns source name for external skills."""
        client = MagicMock()
        client.get.return_value = {
            "agentpowers": {"items": [], "total": 0},
            "clawhub": {
                "items": [{"slug": "ext-skill", "title": "External Skill"}],
                "total": 1,
            },
        }
        result = _resolve_source(client, "ext-skill")
        assert result == "clawhub"

    def test_not_found_returns_none(self):
        """_resolve_source returns None when slug not found anywhere."""
        client = MagicMock()
        client.get.return_value = {
            "agentpowers": {"items": [], "total": 0},
            "clawhub": {"items": [], "total": 0},
        }
        result = _resolve_source(client, "nonexistent")
        assert result is None

    def test_timeout_returns_none(self):
        """_resolve_source returns None on httpx.TimeoutException."""
        client = MagicMock()
        client.get.side_effect = httpx.ReadTimeout("timed out")
        result = _resolve_source(client, "any-skill")
        assert result is None

    def test_connect_error_returns_none(self):
        """_resolve_source returns None on httpx.ConnectError."""
        client = MagicMock()
        client.get.side_effect = httpx.ConnectError("connection refused")
        result = _resolve_source(client, "any-skill")
        assert result is None

    def test_api_error_returns_none(self):
        """_resolve_source returns None on APIError."""
        client = MagicMock()
        client.get.side_effect = APIError("Server error", status_code=500)
        result = _resolve_source(client, "any-skill")
        assert result is None


class TestScanNativeSkill:
    """Tests for ap scan handling of native AgentPowers skills."""

    @patch("agentpowers_cli.commands.scan.get_api_client")
    @patch("agentpowers_cli.commands.scan._resolve_source")
    def test_native_skill_exits_zero(self, mock_resolve, mock_client):
        """ap scan exits with code 0 and helpful message for native skills."""
        mock_resolve.side_effect = _NativeSkillError("hello-world-test")

        with pytest.raises(click.exceptions.Exit) as exc_info:
            scan(slug="hello-world-test", source=None)
        assert exc_info.value.exit_code == 0


# --------------- Additional coverage tests ---------------



class TestSeverityColor:
    """Tests for _severity_color helper."""

    def test_high(self):
        assert _severity_color("HIGH") == "red"

    def test_medium(self):
        assert _severity_color("MEDIUM") == "yellow"

    def test_low(self):
        assert _severity_color("LOW") == "dim"

    def test_info(self):
        assert _severity_color("INFO") == "dim"

    def test_case_insensitive_high(self):
        assert _severity_color("high") == "red"

    def test_case_insensitive_medium(self):
        assert _severity_color("medium") == "yellow"


class TestExtractDetail:
    """Tests for _extract_detail helper."""

    def test_string_finding(self):
        assert _extract_detail("plain text") == "plain text"

    def test_dict_with_detail_key(self):
        assert _extract_detail({"detail": "found it"}) == "found it"

    def test_dict_with_message_key(self):
        assert _extract_detail({"message": "msg here"}) == "msg here"

    def test_dict_with_description_key(self):
        assert _extract_detail({"description": "desc"}) == "desc"

    def test_dict_prefers_detail_over_message(self):
        assert _extract_detail({"detail": "d", "message": "m"}) == "d"

    def test_dict_virustotal_timeout(self):
        finding = {"detail": "xyz did not complete within the timeout"}
        result = _extract_detail(finding)
        assert result == "VirusTotal analysis timed out (non-blocking)"

    def test_dict_no_known_keys_stringifies(self):
        finding = {"foo": "bar", "baz": 1}
        result = _extract_detail(finding)
        assert "foo" in result  # str(dict) representation


class TestLayerIcon:
    """Tests for _layer_icon helper."""

    def test_pass(self):
        assert "OK" in _layer_icon("pass")

    def test_skip(self):
        assert "--" in _layer_icon("skip")

    def test_not_applicable(self):
        assert "--" in _layer_icon("not_applicable")

    def test_fail(self):
        assert "!!" in _layer_icon("fail")

    def test_warn(self):
        assert "!!" in _layer_icon("warn")


class TestFormatStatus:
    """Tests for _format_status helper."""

    def test_unknown_status(self):
        result = _format_status("unknown")
        assert result == "UNKNOWN"


class TestDownloadToSandbox:
    """Tests for _download_to_sandbox."""

    @patch("agentpowers_cli.commands.scan.shutil.rmtree")
    @patch("agentpowers_cli.commands.scan.subprocess.run")
    @patch("agentpowers_cli.commands.scan.tempfile.mkdtemp")
    def test_success(self, mock_mkdtemp, mock_run, mock_rmtree):
        mock_mkdtemp.return_value = "/tmp/ap-scan-abc"
        mock_run.return_value = MagicMock(returncode=0, stderr="", stdout="ok")

        sandbox, source = _download_to_sandbox("my-skill", "clawhub")

        assert sandbox == "/tmp/ap-scan-abc"
        assert source == "clawhub"
        mock_run.assert_called_once_with(
            [
                "npx", "clawhub", "install", "my-skill",
                "--no-input", "--dir", "/tmp/ap-scan-abc",
            ],
            capture_output=True,
            text=True,
            timeout=60,
        )

    @patch("agentpowers_cli.commands.scan.shutil.rmtree")
    @patch("agentpowers_cli.commands.scan.subprocess.run")
    @patch("agentpowers_cli.commands.scan.tempfile.mkdtemp")
    def test_failure_cleans_up(self, mock_mkdtemp, mock_run, mock_rmtree):
        mock_mkdtemp.return_value = "/tmp/ap-scan-fail"
        mock_run.return_value = MagicMock(returncode=1, stderr="npx error")

        with pytest.raises(RuntimeError, match="Download failed"):
            _download_to_sandbox("bad-skill", "clawhub")

        mock_rmtree.assert_called_once_with("/tmp/ap-scan-fail", ignore_errors=True)


class TestUploadForScan:
    """Tests for _upload_for_scan."""

    @patch("agentpowers_cli.commands.scan.load_token", return_value="my-token")
    @patch("agentpowers_cli.commands.scan.httpx.Client")
    def test_success(self, mock_client_cls, mock_token, tmp_path):
        # Create sandbox with a file
        (tmp_path / "SKILL.md").write_text("# Test")
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"security_status": "pass", "findings": []}
        mock_client.post.return_value = mock_resp

        result = _upload_for_scan(str(tmp_path), "clawhub", "test-skill")

        assert result == {"security_status": "pass", "findings": []}
        call_kwargs = mock_client.post.call_args
        assert "Authorization" in call_kwargs.kwargs.get("headers", {})

    @patch("agentpowers_cli.commands.scan.load_token", return_value=None)
    @patch("agentpowers_cli.commands.scan.httpx.Client")
    def test_no_token_no_auth_header(self, mock_client_cls, mock_token, tmp_path):
        (tmp_path / "SKILL.md").write_text("# Test")
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_resp = MagicMock()
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {"security_status": "pass"}
        mock_client.post.return_value = mock_resp

        _upload_for_scan(str(tmp_path), "clawhub", "test-skill")

        call_kwargs = mock_client.post.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert "Authorization" not in headers

    @patch("agentpowers_cli.commands.scan.load_token", return_value=None)
    @patch("agentpowers_cli.commands.scan.httpx.Client")
    def test_http_error_raises_runtime(self, mock_client_cls, mock_token, tmp_path):
        (tmp_path / "SKILL.md").write_text("# Test")
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_client.post.side_effect = httpx.HTTPStatusError(
            "500", request=MagicMock(), response=MagicMock()
        )

        with pytest.raises(RuntimeError, match="Scan upload failed"):
            _upload_for_scan(str(tmp_path), "clawhub", "test-skill")


class TestDisplayResults:
    """Tests for _display_results rendering."""

    def test_pass_with_layers(self):
        result = {
            "security_status": "pass",
            "layers": [
                {"name": "Static Analysis", "status": "pass", "findings": []},
                {
                    "name": "Pattern Scan",
                    "status": "warn",
                    "findings": [
                        {"severity": "MEDIUM", "detail": "Suspicious pattern found"}
                    ],
                },
            ],
            "findings": [],
        }
        _display_results("test-skill", "clawhub", result)

    def test_warn_with_fallback_findings(self):
        result = {
            "security_status": "warn",
            "layers": [],
            "findings": [
                {"severity": "HIGH", "detail": "Dangerous command"},
                {"severity": "INFO", "detail": "Informational note"},
                "Plain string finding",
            ],
        }
        _display_results("test-skill", "clawhub", result)

    def test_block_no_layers_no_findings(self):
        result = {
            "security_status": "block",
            "layers": [],
            "findings": [],
        }
        _display_results("blocked-skill", "clawhub", result)

    def test_layer_with_multiple_findings(self):
        result = {
            "security_status": "warn",
            "layers": [
                {
                    "name": "AI Review",
                    "status": "warn",
                    "findings": [
                        {"severity": "HIGH", "message": "Injection risk"},
                        {"severity": "LOW", "description": "Minor issue"},
                    ],
                },
            ],
            "findings": [],
        }
        _display_results("multi-finding", "clawhub", result)

    def test_findings_only_actionable(self):
        """Fallback findings with only actionable (non-INFO) entries."""
        result = {
            "security_status": "warn",
            "layers": [],
            "findings": [
                {"severity": "HIGH", "detail": "Critical issue"},
                {"severity": "MEDIUM", "detail": "Medium issue"},
            ],
        }
        _display_results("actionable-only", "clawhub", result)

    def test_findings_only_notes(self):
        """Fallback findings with only INFO notes."""
        result = {
            "security_status": "pass",
            "layers": [],
            "findings": [
                {"severity": "INFO", "detail": "All good"},
            ],
        }
        _display_results("notes-only", "clawhub", result)


class TestScanCommandErrorPaths:
    """Tests for scan command error handling paths."""

    @patch("agentpowers_cli.commands.scan.get_api_client")
    @patch("agentpowers_cli.commands.scan._download_to_sandbox")
    @patch("agentpowers_cli.commands.scan._upload_for_scan")
    def test_upload_failure_exits(
        self, mock_upload, mock_download, mock_client, tmp_path
    ):
        """ap scan exits with error when upload/scan fails."""
        sandbox = tmp_path / "sandbox"
        sandbox.mkdir()
        (sandbox / "SKILL.md").write_text("# Test")
        mock_download.return_value = (str(sandbox), "clawhub")
        mock_upload.side_effect = RuntimeError("Upload failed: 500")

        with pytest.raises(click.exceptions.Exit) as exc_info:
            scan(slug="fail-skill")
        assert exc_info.value.exit_code == 1

    @patch("agentpowers_cli.commands.scan.get_api_client")
    @patch("agentpowers_cli.commands.scan._download_to_sandbox")
    @patch("agentpowers_cli.commands.scan._upload_for_scan")
    def test_scan_with_explicit_source_skips_resolve(
        self, mock_upload, mock_download, mock_client, tmp_path
    ):
        """ap scan --source clawhub skips source resolution."""
        sandbox = tmp_path / "sandbox"
        sandbox.mkdir()
        (sandbox / "SKILL.md").write_text("# Test")
        mock_download.return_value = (str(sandbox), "clawhub")
        mock_upload.return_value = {
            "security_status": "pass",
            "findings": [],
        }

        scan(slug="test-skill", source="clawhub")

        mock_download.assert_called_once()
        mock_upload.assert_called_once()


class TestDisplayClamAVSkipped:
    """Tests for ClamAV daemon-unavailable display as skip, not error."""

    def test_clamav_skipped_shows_dash_icon(self, capsys):
        """ClamAV with skip status shows -- icon, not !! (error)."""
        result = {
            "security_status": "pass",
            "layers": [
                {"name": "File Type Validation", "status": "pass", "findings": []},
                {
                    "name": "ClamAV Signature Scan",
                    "status": "skip",
                    "findings": [
                        {
                            "severity": "INFO",
                            "detail": "ClamAV scan skipped -- daemon not running",
                        }
                    ],
                },
            ],
            "findings": [],
        }
        # Should not raise -- the skip status renders with "--" icon
        _display_results("test-skill", "clawhub", result)


class TestDisplayHiddenLayers:
    """Tests for layers hidden by the server when scanner not configured."""

    def test_no_snyk_layer_when_unconfigured(self):
        """When Snyk layer is missing from server response, display works fine."""
        result = {
            "security_status": "pass",
            "layers": [
                {"name": "File Type Validation", "status": "pass", "findings": []},
                {"name": "Pattern Scanning", "status": "pass", "findings": []},
            ],
            "findings": [],
        }
        # Should render without error -- Snyk layer simply absent
        _display_results("test-skill", "clawhub", result)
