"""Tests for the publish command and packager service."""

from __future__ import annotations

import zipfile
from io import BytesIO
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.packager import load_skill_metadata, package_directory

runner = CliRunner()

SKILL_FRONTMATTER = """\
---
name: my-cool-skill
description: A really cool skill
---

# My Cool Skill

Instructions here.
"""

AGENT_FRONTMATTER = """\
---
name: my-agent
description: An autonomous agent
tools: Read, Glob, Grep, Bash
model: sonnet
---

You are an autonomous agent that helps with tasks.
"""

AGENT_FRONTMATTER_MINIMAL = """\
---
name: my-agent
description: An autonomous agent
---

Agent instructions.
"""


# ---------------------------------------------------------------------------
# Packager service tests
# ---------------------------------------------------------------------------


class TestPackageSkillDirectory:
    """Tests for the package_directory function."""

    def test_package_skill_directory(self, tmp_path: Path) -> None:
        """Package a directory with SKILL.md and README.md into a ZIP."""
        (tmp_path / "SKILL.md").write_text(SKILL_FRONTMATTER)
        (tmp_path / "README.md").write_text("# Readme")

        zip_bytes = package_directory(tmp_path)

        with zipfile.ZipFile(BytesIO(zip_bytes)) as zf:
            names = zf.namelist()
            assert "SKILL.md" in names
            assert "README.md" in names

    def test_package_excludes_hidden_dirs(self, tmp_path: Path) -> None:
        """Hidden directories like .git are excluded from the package."""
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "config").write_text("git config")
        (tmp_path / "data.txt").write_text("data")

        zip_bytes = package_directory(tmp_path)

        with zipfile.ZipFile(BytesIO(zip_bytes)) as zf:
            names = zf.namelist()
            assert "data.txt" in names
            assert not any(".git" in name for name in names)


class TestLoadSkillMetadata:
    """Tests for the load_skill_metadata function."""

    def test_load_skill_metadata_from_skill_md(self, tmp_path: Path) -> None:
        """SKILL.md frontmatter is parsed with type='skill'."""
        (tmp_path / "SKILL.md").write_text(SKILL_FRONTMATTER)

        meta = load_skill_metadata(tmp_path)

        assert meta is not None
        assert meta["name"] == "my-cool-skill"
        assert meta["description"] == "A really cool skill"
        assert meta["type"] == "skill"

    def test_load_agent_metadata_from_frontmatter_md(self, tmp_path: Path) -> None:
        """An .md file with name+description frontmatter is detected as agent."""
        (tmp_path / "code-reviewer.md").write_text(AGENT_FRONTMATTER)

        meta = load_skill_metadata(tmp_path)

        assert meta is not None
        assert meta["name"] == "my-agent"
        assert meta["description"] == "An autonomous agent"
        assert meta["type"] == "agent"
        assert meta["tools"] == "Read, Glob, Grep, Bash"

    def test_load_agent_metadata_minimal_frontmatter(self, tmp_path: Path) -> None:
        """Agent with only name+description (no tools) is still detected."""
        (tmp_path / "helper.md").write_text(AGENT_FRONTMATTER_MINIMAL)

        meta = load_skill_metadata(tmp_path)

        assert meta is not None
        assert meta["name"] == "my-agent"
        assert meta["type"] == "agent"

    def test_skill_md_takes_priority_over_agent(self, tmp_path: Path) -> None:
        """SKILL.md is preferred over agent .md files."""
        (tmp_path / "SKILL.md").write_text(SKILL_FRONTMATTER)
        (tmp_path / "code-reviewer.md").write_text(AGENT_FRONTMATTER)

        meta = load_skill_metadata(tmp_path)

        assert meta is not None
        assert meta["type"] == "skill"
        assert meta["name"] == "my-cool-skill"

    def test_load_metadata_missing_skill_file(self, tmp_path: Path) -> None:
        """Returns None when no SKILL.md or agent .md exists."""
        (tmp_path / "README.md").write_text("# Just a readme")

        meta = load_skill_metadata(tmp_path)

        assert meta is None

    def test_md_without_frontmatter_not_detected(self, tmp_path: Path) -> None:
        """A plain .md file without frontmatter is not detected as agent."""
        (tmp_path / "notes.md").write_text("# Just some notes\n\nNo frontmatter.")

        meta = load_skill_metadata(tmp_path)

        assert meta is None

    def test_md_with_partial_frontmatter_not_detected(self, tmp_path: Path) -> None:
        """An .md file with frontmatter missing description is not an agent."""
        partial = "---\nname: incomplete\n---\n\nMissing description field.\n"
        (tmp_path / "incomplete.md").write_text(partial)

        meta = load_skill_metadata(tmp_path)

        assert meta is None


# ---------------------------------------------------------------------------
# Publish command tests
# ---------------------------------------------------------------------------


class TestPublishCommand:
    """Tests for the `ap publish` CLI command."""

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_success(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """Successful publish exits with code 0."""
        mock_load_meta.return_value = {
            "name": "my-skill",
            "description": "A skill",
            "type": "skill",
        }
        client = MagicMock()
        mock_get_client.return_value = client
        client.post.return_value = {"slug": "my-skill"}
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(app, ["publish"])

        assert result.exit_code == 0
        assert "my-skill" in result.output
        client.post.assert_called_once()
        client.upload.assert_called_once()

    @patch("agentpowers_cli.commands.publish.load_skill_metadata", return_value=None)
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_no_skill_file(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
    ) -> None:
        """Missing metadata file exits with code 1 and error message."""
        result = runner.invoke(app, ["publish"])

        assert result.exit_code == 1
        assert "No skill found" in result.output
        assert "name/description frontmatter" in result.output


class TestPublishGetApiClient:
    """Test get_api_client factory in publish module."""

    def test_get_api_client_returns_instance(self) -> None:
        from agentpowers_cli.commands.publish import get_api_client

        client = get_api_client()
        assert client is not None


class TestPublishNegativePrice:
    """Test publish rejects negative price."""

    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_negative_price(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
    ) -> None:
        """Negative price exits with code 1."""
        mock_load_meta.return_value = {
            "name": "my-skill",
            "description": "A skill",
            "type": "skill",
        }
        result = runner.invoke(app, ["publish", "--price", "-5"])

        assert result.exit_code == 1
        assert "negative" in result.output.lower()


class TestPublishBumpVersionConflict:
    """Test publish --bump and --version conflict."""

    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_bump_and_version_conflict(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
    ) -> None:
        """Using --bump minor and --version together exits 1."""
        mock_load_meta.return_value = {
            "name": "my-skill",
            "description": "A skill",
            "type": "skill",
        }
        result = runner.invoke(
            app, ["publish", "--bump", "minor", "--version", "2.0.0"]
        )

        assert result.exit_code == 1
        assert "Cannot use" in result.output


class TestPublishDisplayNameRequired:
    """Test DISPLAY_NAME_REQUIRED flow during publish."""

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_display_name_required_prompt(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """DISPLAY_NAME_REQUIRED triggers inline prompt and retry."""
        from agentpowers_cli.services.api_client import APIError

        mock_load_meta.return_value = {
            "name": "my-skill",
            "description": "A skill",
            "type": "skill",
        }
        client = MagicMock()
        mock_get_client.return_value = client
        # First post: DISPLAY_NAME_REQUIRED, second post: success
        client.post.side_effect = [
            APIError("DISPLAY_NAME_REQUIRED", status_code=400),
            {"slug": "my-skill"},
        ]
        client.patch.return_value = {}
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(app, ["publish"], input="Jane Dev\n")

        assert result.exit_code == 0
        # Display name was set via patch call
        client.patch.assert_called()

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_display_name_required_then_409_is_update(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """DISPLAY_NAME_REQUIRED then 409 on retry triggers update path."""
        from agentpowers_cli.services.api_client import APIError

        mock_load_meta.return_value = {
            "name": "my-skill",
            "description": "A skill",
            "type": "skill",
        }
        client = MagicMock()
        mock_get_client.return_value = client
        # First: DISPLAY_NAME_REQUIRED, retry: 409 (existing slug)
        client.post.side_effect = [
            APIError("DISPLAY_NAME_REQUIRED", status_code=400),
            APIError("Conflict", status_code=409),
        ]
        client.patch.side_effect = [
            {},  # display name set
            {"new_version": "1.0.1"},  # skill update
        ]
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(app, ["publish"], input="Jane Dev\n")

        assert result.exit_code == 0
        assert "Updated" in result.output or "1.0.1" in result.output

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_display_name_required_then_other_error(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """DISPLAY_NAME_REQUIRED then non-409 error on retry exits 1."""
        from agentpowers_cli.services.api_client import APIError

        mock_load_meta.return_value = {
            "name": "my-skill",
            "description": "A skill",
            "type": "skill",
        }
        client = MagicMock()
        mock_get_client.return_value = client
        client.post.side_effect = [
            APIError("DISPLAY_NAME_REQUIRED", status_code=400),
            APIError("Server error", status_code=500),
        ]
        client.patch.return_value = {}  # display name set
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(app, ["publish"], input="Jane Dev\n")

        assert result.exit_code == 1
        assert "Failed" in result.output


class TestPublishUpdateErrors:
    """Test _handle_update_error paths during publish update."""

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_update_with_explicit_version(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """Publish with --version sends version in patch_data."""
        from agentpowers_cli.services.api_client import APIError

        mock_load_meta.return_value = {
            "name": "my-skill",
            "description": "A skill",
            "type": "skill",
        }
        client = MagicMock()
        mock_get_client.return_value = client
        client.post.side_effect = APIError("Conflict", status_code=409)
        client.patch.return_value = {"new_version": "2.0.0"}
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(app, ["publish", "--version", "2.0.0"])

        assert result.exit_code == 0
        patch_call = client.patch.call_args
        assert patch_call[1]["json_data"]["version"] == "2.0.0"


class TestPublishPriceCentsErrorMessage:
    """Test that price_cents validation errors show user-friendly messages."""

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_create_price_cents_error_shows_friendly_message(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """API error mentioning price_cents on create shows friendly message."""
        from agentpowers_cli.services.api_client import APIError

        mock_load_meta.return_value = {
            "name": "my-skill",
            "description": "A skill",
            "type": "skill",
        }
        client = MagicMock()
        mock_get_client.return_value = client
        client.post.side_effect = APIError(
            "body.price_cents: Input should be a valid integer",
            status_code=422,
        )

        result = runner.invoke(app, ["publish", "--price", "0.5"])

        assert result.exit_code == 1
        assert "Invalid price" in result.output
        assert "--price 0" in result.output
        assert "price_cents" not in result.output

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_update_price_cents_error_shows_friendly_message(
        self,
        mock_get_client: MagicMock,
        mock_load_meta: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """API error mentioning price_cents on update shows friendly message."""
        from agentpowers_cli.services.api_client import APIError

        mock_load_meta.return_value = {
            "name": "my-skill",
            "description": "A skill",
            "type": "skill",
        }
        client = MagicMock()
        mock_get_client.return_value = client
        client.post.side_effect = APIError("Conflict", status_code=409)
        client.patch.side_effect = APIError(
            "body.price_cents: ensure this value is greater than or equal to 0",
            status_code=422,
        )

        result = runner.invoke(app, ["publish", "--price", "0.5"])

        assert result.exit_code == 1
        assert "Invalid price" in result.output
        assert "--price 0" in result.output
        assert "price_cents" not in result.output

    def test_humanize_price_error_returns_none_for_unrelated(self) -> None:
        """_humanize_price_error returns None for non-price errors."""
        from agentpowers_cli.commands.publish import _humanize_price_error

        assert _humanize_price_error("some other error") is None

    def test_humanize_price_error_matches_price_cents(self) -> None:
        """_humanize_price_error returns friendly message for price_cents."""
        from agentpowers_cli.commands.publish import _humanize_price_error

        result = _humanize_price_error("body.price_cents: invalid")
        assert result is not None
        assert "Invalid price" in result


class TestPackagerExcludesExtensions:
    """Test packager excludes .pyc and .pyo files."""

    def test_package_excludes_pyc_files(self, tmp_path: Path) -> None:
        """Compiled Python files are excluded from package."""
        (tmp_path / "SKILL.md").write_text("---\nname: test\ndescription: t\n---\n")
        (tmp_path / "code.py").write_text("print('hi')")
        (tmp_path / "code.pyc").write_bytes(b"\x00\x00\x00\x00")

        zip_bytes = package_directory(tmp_path)

        with zipfile.ZipFile(BytesIO(zip_bytes)) as zf:
            names = zf.namelist()
            assert "code.py" in names
            assert "code.pyc" not in names

    def test_package_excludes_hidden_parent_dirs(self, tmp_path: Path) -> None:
        """Files inside hidden parent directories are excluded."""
        hidden = tmp_path / ".hidden"
        hidden.mkdir()
        (hidden / "secret.txt").write_text("secret")
        (tmp_path / "public.txt").write_text("public")

        zip_bytes = package_directory(tmp_path)

        with zipfile.ZipFile(BytesIO(zip_bytes)) as zf:
            names = zf.namelist()
            assert "public.txt" in names
            assert not any(".hidden" in n for n in names)
