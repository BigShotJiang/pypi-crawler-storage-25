"""Shared test fixtures for CLI tests."""

from pathlib import Path

import pytest


@pytest.fixture
def tmp_auth_dir(tmp_path: Path) -> Path:
    """Temporary directory simulating ~/.agentpowers."""
    return tmp_path / ".agentpowers"


@pytest.fixture
def tmp_auth_file(tmp_auth_dir: Path) -> Path:
    """Temporary auth file simulating ~/.agentpowers/auth.json."""
    return tmp_auth_dir / "auth.json"


@pytest.fixture
def skill_dir(tmp_path: Path) -> Path:
    """Create a temporary directory with a valid SKILL.md."""
    md = tmp_path / "SKILL.md"
    md.write_text("---\nname: test-skill\ndescription: A test skill\n---\nContent here\n")
    return tmp_path
