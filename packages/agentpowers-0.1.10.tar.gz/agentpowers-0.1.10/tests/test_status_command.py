"""Tests for the status command."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from agentpowers_cli.main import app

runner = CliRunner()


def _patch_status(tmp_path: Path, pins_path: Path):
    """Return context managers to patch claude dir and pins path."""
    return (
        patch("agentpowers_cli.commands.status.get_install_candidate_dirs", return_value=[tmp_path]),
        patch("agentpowers_cli.commands.status.DEFAULT_PINS_PATH", str(pins_path)),
    )


class TestStatus:
    """Tests for the ap status command."""

    def test_status_shows_installed_skills(self, tmp_path: Path) -> None:
        """List installed skill directories."""
        (tmp_path / "skills" / "weather").mkdir(parents=True)
        (tmp_path / "skills" / "pdf").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "weather" in result.output
        assert "pdf" in result.output
        assert "Installed Skills" in result.output

    def test_status_shows_installed_agents(self, tmp_path: Path) -> None:
        """List installed agent directories."""
        (tmp_path / "agents" / "my-agent").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "my-agent" in result.output
        assert "Installed Agents" in result.output

    def test_status_shows_pin_data(self, tmp_path: Path) -> None:
        """Skills with pins show source, security, version, date."""
        (tmp_path / "skills" / "weather").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text(json.dumps({
            "weather": {
                "source": "clawhub",
                "version": "1.0.0",
                "content_hash": "sha256:abc",
                "installed_at": "2026-02-28T12:00:00+00:00",
                "scanned_at": "2026-02-28T12:00:00+00:00",
                "security_status": "pass",
            }
        }))

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert "clawhub" in result.output
        assert "pass" in result.output
        assert "1.0.0" in result.output
        assert "2026-02-28" in result.output

    def test_status_local_skills_show_local_source(self, tmp_path: Path) -> None:
        """Skills without pins show 'local' as source."""
        (tmp_path / "skills" / "my-skill").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert "local" in result.output

    def test_status_empty(self, tmp_path: Path) -> None:
        """No skills or agents installed."""
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "No skills installed" in result.output
        assert "No agents installed" in result.output

    def test_status_ignores_non_directories(self, tmp_path: Path) -> None:
        """Files in skills/ dir are not listed as installed skills."""
        skills_dir = tmp_path / "skills"
        skills_dir.mkdir(parents=True)
        (skills_dir / "README.md").write_text("# readme")
        (skills_dir / "real-skill").mkdir()
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert "real-skill" in result.output
        assert "README" not in result.output

    def test_status_counts_in_title(self, tmp_path: Path) -> None:
        """Table title includes count of installed items."""
        (tmp_path / "skills" / "a").mkdir(parents=True)
        (tmp_path / "skills" / "b").mkdir(parents=True)
        (tmp_path / "skills" / "c").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert "3" in result.output

    def test_status_shows_logged_in(self, tmp_path: Path) -> None:
        """When a token exists, status shows 'Logged in'."""
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2, patch(
            "agentpowers_cli.commands.status.load_token", return_value="some-jwt"
        ):
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Logged in" in result.output

    def test_status_shows_not_logged_in(self, tmp_path: Path) -> None:
        """When no token, status shows 'Not logged in' and suggests login."""
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2, patch(
            "agentpowers_cli.commands.status.load_token", return_value=None
        ):
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "Not logged in" in result.output
        assert "ap login" in result.output


# ---------------------------------------------------------------------------
# Additional coverage tests
# ---------------------------------------------------------------------------


class TestFormatSecurity:
    """Tests for _format_security in status module."""

    def test_format_security_none(self) -> None:
        from agentpowers_cli.commands.status import _format_security

        assert _format_security(None) == "-"

    def test_format_security_empty(self) -> None:
        from agentpowers_cli.commands.status import _format_security

        assert _format_security("") == "-"

    def test_format_security_pass(self) -> None:
        from agentpowers_cli.commands.status import _format_security

        result = _format_security("pass")
        assert "green" in result
        assert "pass" in result

    def test_format_security_warn(self) -> None:
        from agentpowers_cli.commands.status import _format_security

        result = _format_security("warn")
        assert "yellow" in result

    def test_format_security_block(self) -> None:
        from agentpowers_cli.commands.status import _format_security

        result = _format_security("block")
        assert "red" in result

    def test_format_security_unknown_returns_raw(self) -> None:
        from agentpowers_cli.commands.status import _format_security

        assert _format_security("pending") == "pending"


class TestLoadPins:
    """Tests for _load_pins in status module."""

    def test_load_pins_nonexistent_file(self, tmp_path: Path) -> None:
        from agentpowers_cli.commands.status import _load_pins

        result = _load_pins(str(tmp_path / "no-such-file.json"))
        assert result == {}

    def test_load_pins_invalid_json(self, tmp_path: Path) -> None:
        from agentpowers_cli.commands.status import _load_pins

        bad_file = tmp_path / "bad.json"
        bad_file.write_text("{not valid json")
        result = _load_pins(str(bad_file))
        assert result == {}

    def test_load_pins_valid(self, tmp_path: Path) -> None:
        from agentpowers_cli.commands.status import _load_pins

        pins_file = tmp_path / "pins.json"
        pins_file.write_text('{"my-skill": {"source": "clawhub"}}')
        result = _load_pins(str(pins_file))
        assert result["my-skill"]["source"] == "clawhub"


class TestStatusNoSkills:
    """Test status when no skills dirs exist."""

    def test_status_no_skills_or_agents_dirs(self, tmp_path: Path) -> None:
        """Status with no skills/ or agents/ directories shows 'No X installed'."""
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "No skills installed" in result.output
        assert "No agents installed" in result.output


# ---------------------------------------------------------------------------
# --source filter tests
# ---------------------------------------------------------------------------


class TestStatusSourceFilter:
    """Tests for --source filtering in ap status."""

    def test_source_local_shows_only_unpinned(self, tmp_path: Path) -> None:
        """--source local shows only skills not in pins."""
        (tmp_path / "skills" / "local-skill").mkdir(parents=True)
        (tmp_path / "skills" / "pinned-skill").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text(json.dumps({
            "pinned-skill": {"source": "clawhub", "version": "1.0.0"},
        }))

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status", "--source", "local"])

        assert result.exit_code == 0
        assert "local-skill" in result.output
        assert "pinned-skill" not in result.output

    def test_source_clawhub_shows_only_clawhub(self, tmp_path: Path) -> None:
        """--source clawhub shows only skills pinned from clawhub."""
        (tmp_path / "skills" / "local-skill").mkdir(parents=True)
        (tmp_path / "skills" / "clawhub-skill").mkdir(parents=True)
        (tmp_path / "skills" / "ap-skill").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text(json.dumps({
            "clawhub-skill": {"source": "clawhub", "version": "1.0.0"},
            "ap-skill": {"source": "agentpowers", "version": "2.0.0"},
        }))

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status", "--source", "clawhub"])

        assert result.exit_code == 0
        assert "clawhub-skill" in result.output
        assert "local-skill" not in result.output
        assert "ap-skill" not in result.output

    def test_source_agentpowers_shows_only_native(self, tmp_path: Path) -> None:
        """--source agentpowers shows only skills pinned from agentpowers."""
        (tmp_path / "skills" / "ap-skill").mkdir(parents=True)
        (tmp_path / "skills" / "clawhub-skill").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text(json.dumps({
            "ap-skill": {"source": "agentpowers", "version": "1.0.0"},
            "clawhub-skill": {"source": "clawhub", "version": "1.0.0"},
        }))

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status", "--source", "agentpowers"])

        assert result.exit_code == 0
        assert "ap-skill" in result.output
        assert "clawhub-skill" not in result.output

    def test_source_no_match_shows_empty(self, tmp_path: Path) -> None:
        """--source with no matching items shows 'No skills installed'."""
        (tmp_path / "skills" / "local-skill").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status", "--source", "clawhub"])

        assert result.exit_code == 0
        assert "No skills installed" in result.output

    def test_source_short_flag(self, tmp_path: Path) -> None:
        """-s short flag works for --source."""
        (tmp_path / "skills" / "local-skill").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text("{}")

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status", "-s", "local"])

        assert result.exit_code == 0
        assert "local-skill" in result.output

    def test_no_source_shows_all(self, tmp_path: Path) -> None:
        """Without --source, all items are shown (default behavior)."""
        (tmp_path / "skills" / "local-skill").mkdir(parents=True)
        (tmp_path / "skills" / "pinned-skill").mkdir(parents=True)
        pins_path = tmp_path / "pins.json"
        pins_path.write_text(json.dumps({
            "pinned-skill": {"source": "clawhub", "version": "1.0.0"},
        }))

        p1, p2 = _patch_status(tmp_path, pins_path)
        with p1, p2:
            result = runner.invoke(app, ["status"])

        assert result.exit_code == 0
        assert "local-skill" in result.output
        assert "pinned-skill" in result.output
