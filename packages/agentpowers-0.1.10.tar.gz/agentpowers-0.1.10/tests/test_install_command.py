"""Tests for the install command and installer service."""

from __future__ import annotations

import io
import zipfile
from pathlib import Path
from unittest.mock import ANY, MagicMock, patch

import click.exceptions
import httpx
import pytest
from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError
from agentpowers_cli.services.installer import extract_package

runner = CliRunner()


def _make_zip(files: dict[str, str]) -> bytes:
    """Create an in-memory ZIP archive from a dict of filename -> content.

    Args:
        files: Mapping of file paths to their string contents.

    Returns:
        Raw bytes of the ZIP archive.
    """
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, content in files.items():
            zf.writestr(name, content)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Installer service tests
# ---------------------------------------------------------------------------


class TestExtractPackage:
    """Tests for the extract_package function."""

    def test_extract_zip_to_skills_dir(self, tmp_path: Path) -> None:
        """Extract a skill ZIP into the skills/ subdirectory."""
        zip_data = _make_zip({"CLAUDE.md": "# My Skill", "main.py": "print('hi')"})

        dest = extract_package(zip_data, "my-skill", "skill", base_dir=tmp_path)

        assert dest == tmp_path / "skills" / "my-skill"
        assert (dest / "CLAUDE.md").read_text() == "# My Skill"
        assert (dest / "main.py").read_text() == "print('hi')"

    def test_extract_zip_to_agents_dir(self, tmp_path: Path) -> None:
        """Extract an agent ZIP into the agents/ subdirectory."""
        zip_data = _make_zip({"agent.yaml": "name: test"})

        dest = extract_package(zip_data, "my-agent", "agent", base_dir=tmp_path)

        assert dest == tmp_path / "agents" / "my-agent"
        assert (dest / "agent.yaml").read_text() == "name: test"

    def test_extract_overwrites_existing(self, tmp_path: Path) -> None:
        """Extracting twice overwrites the previous installation."""
        zip_v1 = _make_zip({"version.txt": "v1", "old_file.txt": "remove me"})
        zip_v2 = _make_zip({"version.txt": "v2"})

        extract_package(zip_v1, "my-skill", "skill", base_dir=tmp_path)
        dest = extract_package(zip_v2, "my-skill", "skill", base_dir=tmp_path)

        assert (dest / "version.txt").read_text() == "v2"
        assert not (dest / "old_file.txt").exists()


# ---------------------------------------------------------------------------
# Install command tests
# ---------------------------------------------------------------------------


def _mock_skill(
    slug: str = "cool-skill",
    price_cents: int = 0,
    security_status: str = "pass",
    skill_type: str = "skill",
) -> dict:
    """Build a mock skill response dict."""
    return {
        "slug": slug,
        "name": "Cool Skill",
        "price_cents": price_cents,
        "security_status": security_status,
        "type": skill_type,
    }


class TestInstallCommand:
    """Tests for the `ap install` CLI command."""

    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/cool-skill",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_free_skill(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """Free skill installs successfully with exit code 0."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(price_cents=0),
            {"url": "https://cdn.example.com/cool-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "cool-skill"])

        assert result.exit_code == 0
        assert "Installed" in result.output
        mock_install_url.assert_called_once()

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_blocked_skill_rejected(
        self, mock_get_client: MagicMock
    ) -> None:
        """Blocked skill is rejected with exit code 1."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = _mock_skill(security_status="block")

        result = runner.invoke(app, ["install", "bad-skill"])

        assert result.exit_code == 1
        assert "blocked" in result.output.lower()

    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/paid-skill",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_with_license_code(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """License code triggers a redeem POST call."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(price_cents=1000),
            {"url": "https://cdn.example.com/paid-skill.zip"},
        ]
        client.post.return_value = {"status": "redeemed"}

        result = runner.invoke(app, ["install", "paid-skill", "--code", "ABC-123"])

        assert result.exit_code == 0
        client.post.assert_called_once_with(
            "/v1/purchases/redeem",
            json_data={"license_code": "ABC-123"},
            auth=True,
        )

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_not_found_anywhere(self, mock_get_client: MagicMock) -> None:
        """Skill not found natively or externally returns exit code 1."""
        client = MagicMock()
        mock_get_client.return_value = client
        # First call: /v1/skills/{slug} -> 404
        # Second call: /v1/detail/{slug} -> 404
        # Third call: /v1/search -> no matching slugs
        client.get.side_effect = [
            APIError("Not found", status_code=404),
            APIError("Not found", status_code=404),
            {
                "agentpowers": {"items": [], "total": 0},
                "clawhub": {"items": [], "total": 0},
            },
        ]

        result = runner.invoke(app, ["install", "nonexistent"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_waterfall_detail_finds_external(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """Skill not found natively but found via /v1/detail (external source)."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            # /v1/skills/{slug} -> 404
            APIError("Not found", status_code=404),
            # /v1/detail/{slug} -> found on clawhub
            {
                "slug": "weather",
                "title": "Weather",
                "source": "clawhub",
                "type": "skill",
                "source_installs": 587,
                "version": "1.0.0",
            },
        ]
        mock_ext_install.return_value = "/tmp/installed"

        result = runner.invoke(app, ["install", "weather"])

        assert result.exit_code == 0
        assert "Installed" in result.output
        mock_ext_install.assert_called_once_with(
            client, "weather", "clawhub", "skill",
            version="1.0.0", base_dir=ANY,
        )

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_waterfall_search_fallback(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """Detail 404 falls back to search-based external lookup."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            # /v1/skills/{slug} -> 404
            APIError("Not found", status_code=404),
            # /v1/detail/{slug} -> 404
            APIError("Not found", status_code=404),
            # /v1/search -> found on clawhub
            {
                "agentpowers": {"items": [], "total": 0},
                "clawhub": {
                    "total": 1,
                    "items": [
                        {
                            "slug": "weather",
                            "title": "Weather",
                            "source": "clawhub",
                            "source_installs": 587,
                            "version": "1.0.0",
                        }
                    ],
                },
            },
        ]
        mock_ext_install.return_value = "/tmp/installed"

        result = runner.invoke(app, ["install", "weather"])

        assert result.exit_code == 0
        assert "Installed" in result.output
        mock_ext_install.assert_called_once_with(
            client, "weather", "clawhub", base_dir=ANY
        )


# ---------------------------------------------------------------------------
# Native install saves pin tests
# ---------------------------------------------------------------------------


class TestNativeInstallSavesPin:
    """Verify that _install_native saves a pin after extraction."""

    @patch("agentpowers_cli.commands.install.save_pin")
    @patch(
        "agentpowers_cli.commands.install.hash_directory",
        return_value="sha256:abc123",
    )
    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/my-skill",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_native_install_saves_pin(
        self,
        mock_get_client: MagicMock,
        mock_install_url: MagicMock,
        mock_hash: MagicMock,
        mock_save_pin: MagicMock,
    ) -> None:
        """Installing a free native skill saves a pin with correct hash."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(slug="my-skill", price_cents=0, security_status="pass"),
            {"url": "https://cdn.example.com/my-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "my-skill"])

        assert result.exit_code == 0
        mock_hash.assert_called_once_with("/home/.claude/skills/my-skill")
        mock_save_pin.assert_called_once_with(
            slug="my-skill",
            source="agentpowers",
            version=None,
            content_hash="sha256:abc123",
            security_status="pass",
            skill_type="skill",
            install_location="/home/.claude/skills/my-skill",
        )

    @patch("agentpowers_cli.commands.install.save_pin")
    @patch(
        "agentpowers_cli.commands.install.hash_directory",
        return_value="sha256:def456",
    )
    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/warn-skill",
    )
    @patch("agentpowers_cli.commands.install.typer.confirm", return_value=True)
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_native_install_saves_pin_with_warn_status(
        self,
        mock_get_client: MagicMock,
        mock_confirm: MagicMock,
        mock_install_url: MagicMock,
        mock_hash: MagicMock,
        mock_save_pin: MagicMock,
    ) -> None:
        """Pin records the actual security status (warn, not just pass)."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(slug="warn-skill", price_cents=0, security_status="warn"),
            {"url": "https://cdn.example.com/warn-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "warn-skill"])

        assert result.exit_code == 0
        mock_confirm.assert_called_once_with("Install anyway?", default=False)
        mock_save_pin.assert_called_once_with(
            slug="warn-skill",
            source="agentpowers",
            version=None,
            content_hash="sha256:def456",
            security_status="warn",
            skill_type="skill",
            install_location="/home/.claude/skills/warn-skill",
        )

    @patch("agentpowers_cli.commands.install.typer.confirm", return_value=False)
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_native_install_warn_declined_cancels(
        self,
        mock_get_client: MagicMock,
        mock_confirm: MagicMock,
    ) -> None:
        """Declining the warn confirmation cancels installation."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = _mock_skill(
            slug="warn-skill", price_cents=0, security_status="warn",
        )

        result = runner.invoke(app, ["install", "warn-skill"])

        assert result.exit_code == 0
        assert "cancelled" in result.output.lower()
        mock_confirm.assert_called_once_with("Install anyway?", default=False)

    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/warn-skill",
    )
    @patch("agentpowers_cli.commands.install.hash_directory", return_value="sha256:x")
    @patch("agentpowers_cli.commands.install.save_pin")
    @patch("agentpowers_cli.commands.install.typer.confirm", return_value=True)
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_native_install_warn_shows_findings(
        self,
        mock_get_client: MagicMock,
        mock_confirm: MagicMock,
        mock_save_pin: MagicMock,
        mock_hash: MagicMock,
        mock_install_url: MagicMock,
    ) -> None:
        """Warn status displays security_findings when available."""
        client = MagicMock()
        mock_get_client.return_value = client
        skill = _mock_skill(
            slug="warn-skill", price_cents=0, security_status="warn",
        )
        skill["security_findings"] = ["Uses eval()", "Accesses env vars"]
        client.get.side_effect = [
            skill,
            {"url": "https://cdn.example.com/warn-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "warn-skill"])

        assert result.exit_code == 0
        assert "Uses eval()" in result.output
        assert "Accesses env vars" in result.output

    @patch("agentpowers_cli.commands.install.typer.confirm", return_value=True)
    @patch("agentpowers_cli.commands.install.install_from_url",
           return_value="/home/.claude/skills/w")
    @patch("agentpowers_cli.commands.install.hash_directory", return_value="sha256:x")
    @patch("agentpowers_cli.commands.install.save_pin")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_native_install_warn_shows_score_when_no_findings(
        self,
        mock_get_client: MagicMock,
        mock_save_pin: MagicMock,
        mock_hash: MagicMock,
        mock_install_url: MagicMock,
        mock_confirm: MagicMock,
    ) -> None:
        """Warn status shows security_score when findings are absent."""
        client = MagicMock()
        mock_get_client.return_value = client
        skill = _mock_skill(
            slug="warn-skill", price_cents=0, security_status="warn",
        )
        skill["security_score"] = 42
        client.get.side_effect = [
            skill,
            {"url": "https://cdn.example.com/warn-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "warn-skill"])

        assert result.exit_code == 0
        assert "42" in result.output

    @patch("agentpowers_cli.commands.install.save_pin")
    @patch(
        "agentpowers_cli.commands.install.hash_directory",
        return_value="sha256:ghi789",
    )
    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/versioned",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_native_install_saves_pin_with_version(
        self,
        mock_get_client: MagicMock,
        mock_install_url: MagicMock,
        mock_hash: MagicMock,
        mock_save_pin: MagicMock,
    ) -> None:
        """Pin includes version from skill metadata when available."""
        client = MagicMock()
        mock_get_client.return_value = client
        skill = _mock_skill(slug="versioned", price_cents=0)
        skill["version"] = "1.2.3"
        client.get.side_effect = [
            skill,
            {"url": "https://cdn.example.com/versioned.zip"},
        ]

        result = runner.invoke(app, ["install", "versioned"])

        assert result.exit_code == 0
        mock_save_pin.assert_called_once_with(
            slug="versioned",
            source="agentpowers",
            version="1.2.3",
            content_hash="sha256:ghi789",
            security_status="pass",
            skill_type="skill",
            install_location="/home/.claude/skills/versioned",
        )

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_blocked_skill_does_not_save_pin(
        self, mock_get_client: MagicMock
    ) -> None:
        """Blocked skill exits before saving any pin."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = _mock_skill(security_status="block")

        with patch("agentpowers_cli.commands.install.save_pin") as mock_save_pin:
            result = runner.invoke(app, ["install", "bad-skill"])

        assert result.exit_code == 1
        mock_save_pin.assert_not_called()


class TestRecordInstallationTracking:
    """Verify that record_installation is called correctly after installs."""

    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/tracked-skill",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_record_installation_called_after_native_install(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """record_installation is called after a successful native AP install."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(slug="tracked-skill"),
            {"url": "https://cdn.example.com/tracked-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "tracked-skill"])

        assert result.exit_code == 0
        client.record_installation.assert_called_once()
        call_kwargs = client.record_installation.call_args
        assert call_kwargs[0][0] == "tracked-skill"  # source_slug
        assert call_kwargs[0][1] == "cli"             # platform
        assert call_kwargs[0][2] == "agentpowers"     # source

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_record_installation_not_called_on_failure(
        self, mock_get_client: MagicMock
    ) -> None:
        """record_installation is NOT called when install is blocked or fails."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = _mock_skill(security_status="block")

        result = runner.invoke(app, ["install", "bad-skill"])

        assert result.exit_code == 1
        client.record_installation.assert_not_called()


# ---------------------------------------------------------------------------
# _parse_slug tests
# ---------------------------------------------------------------------------


from agentpowers_cli.commands.install import _parse_slug  # noqa: E402


class TestParseSlug:
    """Tests for the _parse_slug helper function."""

    def test_parse_slug_with_author(self) -> None:
        """author/slug splits into (author, slug)."""
        assert _parse_slug("clerk/my-skill") == ("clerk", "my-skill")

    def test_parse_slug_without_author(self) -> None:
        """Plain slug returns (None, slug)."""
        assert _parse_slug("my-skill") == (None, "my-skill")

    def test_parse_slug_empty_author(self) -> None:
        """Leading slash treats author as None."""
        assert _parse_slug("/my-skill") == (None, "my-skill")

    def test_parse_slug_nested_slashes_rejected(self) -> None:
        """Multiple slashes are rejected as invalid format."""
        import typer
        with pytest.raises(typer.BadParameter, match="Invalid slug format"):
            _parse_slug("author/part/extra")


# ---------------------------------------------------------------------------
# detect_install_base tests
# ---------------------------------------------------------------------------


from agentpowers_cli.services.installer import detect_install_base  # noqa: E402


class TestDetectInstallBase:
    """Tests for the detect_install_base function."""

    def test_detect_install_base_local(self, tmp_path: Path) -> None:
        """When .claude/ exists in cwd, returns cwd/.claude."""
        local_claude = tmp_path / ".claude"
        local_claude.mkdir()

        with patch(
            "agentpowers_cli.services.installer.Path.cwd",
            return_value=tmp_path,
        ):
            result = detect_install_base(force_global=False)

        assert result == local_claude

    def test_detect_install_base_global_no_local(self, tmp_path: Path) -> None:
        """No .claude/ in cwd falls back to ~/.claude."""
        with patch(
            "agentpowers_cli.services.installer.Path.cwd",
            return_value=tmp_path,
        ):
            result = detect_install_base(force_global=False)

        assert result == Path.home() / ".claude"

    def test_detect_install_base_force_global(self, tmp_path: Path) -> None:
        """--global always returns ~/.claude even when .claude/ exists in cwd."""
        local_claude = tmp_path / ".claude"
        local_claude.mkdir()

        with patch(
            "agentpowers_cli.services.installer.Path.cwd",
            return_value=tmp_path,
        ):
            result = detect_install_base(force_global=True)

        assert result == Path.home() / ".claude"

    def test_detect_install_base_for_codex(self, tmp_path: Path) -> None:
        """--for codex always returns ~/.codex regardless of local .claude/."""
        local_claude = tmp_path / ".claude"
        local_claude.mkdir()

        with patch(
            "agentpowers_cli.services.installer.Path.cwd",
            return_value=tmp_path,
        ):
            result = detect_install_base(force_global=False, for_tool="codex")

        assert result == Path.home() / ".codex"

    @pytest.mark.parametrize(
        "tool,expected_dir",
        [
            ("claude-code", ".claude"),
            ("claude-desktop", ".claude"),
            ("codex", ".codex"),
            ("gemini", ".gemini"),
            ("kiro", ".kiro"),
        ],
    )
    def test_detect_install_base_for_all_supported_tools(
        self, tmp_path: Path, tool: str, expected_dir: str
    ) -> None:
        """Each supported tool maps to the correct global config directory."""
        with patch(
            "agentpowers_cli.services.installer.Path.cwd",
            return_value=tmp_path,
        ):
            result = detect_install_base(force_global=False, for_tool=tool)

        assert result == Path.home() / expected_dir

    def test_detect_install_base_unknown_tool_raises(self) -> None:
        """Unknown tool name raises ValueError with helpful message."""
        with pytest.raises(ValueError, match="Unknown tool 'unknown-tool'"):
            detect_install_base(for_tool="unknown-tool")

    def test_detect_install_base_codex_ignores_local_claude(
        self, tmp_path: Path
    ) -> None:
        """For codex, local .claude/ dir is ignored -- always returns ~/.codex."""
        local_claude = tmp_path / ".claude"
        local_claude.mkdir()

        with patch(
            "agentpowers_cli.services.installer.Path.cwd",
            return_value=tmp_path,
        ):
            result = detect_install_base(force_global=False, for_tool="codex")

        # Must not return the local claude dir
        assert result != local_claude
        assert result == Path.home() / ".codex"


# ---------------------------------------------------------------------------
# --for flag integration tests
# ---------------------------------------------------------------------------


class TestForToolFlag:
    """Tests for the --for <tool> flag on ap install."""

    runner = CliRunner()

    @patch("agentpowers_cli.commands.install.install_from_url")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_for_codex_installs_to_codex_dir(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """--for codex passes ~/.codex as base_dir to install_from_url."""
        client = MagicMock()
        mock_get_client.return_value = client
        skill = _mock_skill(slug="pdf-parser")
        client.get.return_value = skill
        mock_install_url.return_value = str(
            Path.home() / ".codex" / "skills" / "pdf-parser"
        )

        result = self.runner.invoke(app, ["install", "--for", "codex", "pdf-parser"])

        assert result.exit_code == 0, result.output
        # base_dir passed to install_from_url must be ~/.codex
        call_kwargs = mock_install_url.call_args
        base_dir_arg = call_kwargs.kwargs.get("base_dir") or call_kwargs.args[2]
        assert base_dir_arg == Path.home() / ".codex"

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_for_unknown_tool_exits_with_error(
        self, mock_get_client: MagicMock
    ) -> None:
        """--for with an unknown tool name shows an error and exits non-zero."""
        result = self.runner.invoke(app, ["install", "--for", "vscode", "pdf-parser"])
        assert result.exit_code != 0
        assert "vscode" in result.output or "vscode" in str(result.exception)

    def test_for_claude_code_default_behavior(self, tmp_path: Path) -> None:
        """--for claude-code (default) preserves existing local .claude/ detection."""
        from agentpowers_cli.services.installer import detect_install_base

        local = tmp_path / ".claude"
        local.mkdir()

        with patch(
            "agentpowers_cli.services.installer.Path.cwd",
            return_value=tmp_path,
        ):
            result = detect_install_base(force_global=False, for_tool="claude-code")

        assert result == local


# ---------------------------------------------------------------------------
# Author/slug install tests
# ---------------------------------------------------------------------------


class TestAuthorSlugInstall:
    """Tests for ap install <author>/<slug> format."""

    @patch(
        "agentpowers_cli.commands.install.install_from_url",
        return_value="/home/.claude/skills/my-skill",
    )
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_author_slug_resolves_seller(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """author/slug resolves via GET /v1/sellers/{author}/skills."""
        client = MagicMock()
        mock_get_client.return_value = client
        skill = _mock_skill(slug="my-skill")
        client.get.side_effect = [
            # Seller skills listing
            {"items": [skill], "total": 1},
            # Download URL
            {"url": "https://cdn.example.com/my-skill.zip"},
        ]

        result = runner.invoke(app, ["install", "clerk/my-skill"])

        assert result.exit_code == 0
        assert "Installed" in result.output
        client.get.assert_any_call("/v1/sellers/clerk/skills")

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_author_slug_seller_not_found(self, mock_get_client: MagicMock) -> None:
        """Unknown seller returns exit code 1 with an error message."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = APIError("Not found", status_code=404)

        result = runner.invoke(app, ["install", "nobody/my-skill"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_author_slug_skill_not_in_seller_list(
        self, mock_get_client: MagicMock
    ) -> None:
        """Seller found but skill not in their list returns exit code 1."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = {"items": [], "total": 0}

        result = runner.invoke(app, ["install", "clerk/nonexistent"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()


# ---------------------------------------------------------------------------
# NEW: _record_installation tests (fire-and-forget, lines 64-65)
# ---------------------------------------------------------------------------


class TestRecordInstallationHelper:
    """Tests for the _record_installation helper function directly."""

    def test_record_installation_swallows_all_exceptions(self) -> None:
        """_record_installation catches any exception without re-raising."""
        from agentpowers_cli.commands.install import _record_installation

        client = MagicMock()
        client.record_installation.side_effect = RuntimeError("network down")

        # Should not raise
        _record_installation(client, "my-skill", "cli", "agentpowers")

    def test_record_installation_forwards_args(self) -> None:
        """_record_installation passes slug, platform, source to client."""
        from agentpowers_cli.commands.install import _record_installation

        client = MagicMock()
        _record_installation(client, "my-skill", "cli", "clawhub")

        client.record_installation.assert_called_once()
        args = client.record_installation.call_args[0]
        assert args[0] == "my-skill"
        assert args[1] == "cli"
        assert args[2] == "clawhub"

    def test_record_installation_includes_hostname(self) -> None:
        """_record_installation passes hostname as 4th positional arg."""
        from agentpowers_cli.commands.install import _record_installation

        client = MagicMock()
        _record_installation(client, "slug", "cli", "agentpowers")

        args = client.record_installation.call_args[0]
        # 4th arg is hostname -- should be a non-empty string
        assert isinstance(args[3], str)
        assert len(args[3]) > 0


# ---------------------------------------------------------------------------
# NEW: _install_native paid skill / download failure (lines 380-392)
# ---------------------------------------------------------------------------


class TestInstallNativePaidAndFailure:
    """Tests for _install_native with license code errors and download errors."""

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_license_redeem_api_error_exits(self, mock_get_client: MagicMock) -> None:
        """Failed license redeem prints error and exits code 1."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.return_value = _mock_skill(price_cents=1000)
        client.post.side_effect = APIError("Invalid code", status_code=400)

        result = runner.invoke(app, ["install", "paid-skill", "--code", "BAD-CODE"])

        assert result.exit_code == 1
        assert "redeem" in result.output.lower() or "failed" in result.output.lower()

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_download_endpoint_failure_exits(self, mock_get_client: MagicMock) -> None:
        """Download endpoint returning error exits with code 1."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(price_cents=0),
            APIError("Download error", status_code=500),
        ]

        result = runner.invoke(app, ["install", "broken-download"])

        assert result.exit_code == 1
        assert "download failed" in result.output.lower()


# ---------------------------------------------------------------------------
# NEW: install_from_url (lines 97-108)
# ---------------------------------------------------------------------------


class TestInstallFromUrl:
    """Tests for the install_from_url function."""

    @patch("agentpowers_cli.commands.install.extract_package")
    @patch("agentpowers_cli.commands.install.httpx.Client")
    def test_install_from_url_success(
        self, mock_http_cls: MagicMock, mock_extract: MagicMock, tmp_path: Path
    ) -> None:
        """Successful download and extract returns destination path."""
        from agentpowers_cli.commands.install import install_from_url

        mock_response = MagicMock()
        mock_response.content = b"zipdata"
        mock_client_instance = MagicMock()
        mock_client_instance.get.return_value = mock_response
        mock_http_cls.return_value.__enter__ = MagicMock(
            return_value=mock_client_instance
        )
        mock_http_cls.return_value.__exit__ = MagicMock(return_value=False)

        mock_extract.return_value = tmp_path / "skills" / "my-skill"

        result = install_from_url(
            "https://cdn.example.com/my.zip", "my-skill", "skill", base_dir=tmp_path
        )
        assert "my-skill" in result
        mock_extract.assert_called_once()

    @patch("agentpowers_cli.commands.install.httpx.Client")
    def test_install_from_url_http_error_exits(
        self, mock_http_cls: MagicMock
    ) -> None:
        """HTTP error during download raises typer.Exit (click.exceptions.Exit)."""
        from agentpowers_cli.commands.install import install_from_url

        mock_client_instance = MagicMock()
        mock_client_instance.get.side_effect = httpx.ConnectError("connection refused")
        mock_http_cls.return_value.__enter__ = MagicMock(
            return_value=mock_client_instance
        )
        mock_http_cls.return_value.__exit__ = MagicMock(return_value=False)

        with pytest.raises(click.exceptions.Exit):
            install_from_url("https://cdn.example.com/bad.zip", "bad-skill", "skill")


# ---------------------------------------------------------------------------
# NEW: _search_external_sources / _prompt_source_choice (lines 158-159, 181-198)
# ---------------------------------------------------------------------------


class TestLookupExternalDetail:
    """Tests for _lookup_external_detail."""

    def test_returns_external_detail(self) -> None:
        """Returns detail dict when found on external source."""
        from agentpowers_cli.commands.install import _lookup_external_detail

        client = MagicMock()
        client.get.return_value = {
            "slug": "weather",
            "title": "Weather Skill",
            "source": "clawhub",
            "type": "skill",
            "version": "1.0.0",
            "source_installs": 100,
        }

        result = _lookup_external_detail(client, "weather")
        assert result is not None
        assert result["source"] == "clawhub"
        client.get.assert_called_once_with("/v1/detail/weather")

    def test_returns_none_for_native_source(self) -> None:
        """Returns None when detail is from agentpowers (native)."""
        from agentpowers_cli.commands.install import _lookup_external_detail

        client = MagicMock()
        client.get.return_value = {
            "slug": "my-skill",
            "source": "agentpowers",
        }

        result = _lookup_external_detail(client, "my-skill")
        assert result is None

    def test_returns_none_on_api_error(self) -> None:
        """Returns None on any API error."""
        from agentpowers_cli.commands.install import _lookup_external_detail

        client = MagicMock()
        client.get.side_effect = APIError("Not found", status_code=404)

        result = _lookup_external_detail(client, "missing")
        assert result is None


class TestSearchExternalSources:
    """Tests for _search_external_sources."""

    def test_api_error_returns_empty_list(self) -> None:
        """APIError from /v1/search returns empty list."""
        from agentpowers_cli.commands.install import _search_external_sources

        client = MagicMock()
        client.get.side_effect = APIError("Server error", status_code=500)

        result = _search_external_sources(client, "some-slug")
        assert result == []

    def test_filters_agentpowers_source(self) -> None:
        """Results from agentpowers source are excluded."""
        from agentpowers_cli.commands.install import _search_external_sources

        client = MagicMock()
        client.get.return_value = {
            "agentpowers": {"items": [{"slug": "test"}], "total": 1},
            "clawhub": {"items": [{"slug": "test", "title": "Test"}], "total": 1},
        }

        result = _search_external_sources(client, "test")
        assert len(result) == 1
        assert result[0]["source"] == "clawhub"

    def test_non_matching_slugs_excluded(self) -> None:
        """Items with different slug are not included in matches."""
        from agentpowers_cli.commands.install import _search_external_sources

        client = MagicMock()
        client.get.return_value = {
            "clawhub": {
                "items": [
                    {"slug": "target", "title": "Target"},
                    {"slug": "other", "title": "Other"},
                ],
                "total": 2,
            },
        }

        result = _search_external_sources(client, "target")
        assert len(result) == 1
        assert result[0]["slug"] == "target"


class TestPromptSourceChoice:
    """Tests for _prompt_source_choice."""

    @patch("agentpowers_cli.commands.install.typer.prompt", return_value=1)
    def test_valid_choice_returns_first_item(self, mock_prompt: MagicMock) -> None:
        """Choosing 1 returns the first matching item."""
        from agentpowers_cli.commands.install import _prompt_source_choice

        matches = [
            {"source": "clawhub", "title": "Weather", "version": "1.0",
             "source_installs": 10},
            {"source": "otherhub", "title": "Weather", "version": "2.0",
             "source_installs": 5},
        ]
        result = _prompt_source_choice(matches, "weather")
        assert result == matches[0]

    @patch("agentpowers_cli.commands.install.typer.prompt", return_value=2)
    def test_second_choice_returns_second_item(self, mock_prompt: MagicMock) -> None:
        """Choosing 2 returns the second match."""
        from agentpowers_cli.commands.install import _prompt_source_choice

        matches = [
            {"source": "clawhub", "title": "A", "version": "1.0",
             "source_installs": 0},
            {"source": "otherhub", "title": "B", "version": "2.0",
             "source_installs": 0},
        ]
        result = _prompt_source_choice(matches, "test")
        assert result == matches[1]

    @patch("agentpowers_cli.commands.install.typer.prompt", return_value=0)
    def test_zero_choice_returns_none(self, mock_prompt: MagicMock) -> None:
        """Zero (out-of-range) choice returns None."""
        from agentpowers_cli.commands.install import _prompt_source_choice

        matches = [
            {"source": "clawhub", "title": "A", "version": "1.0",
             "source_installs": 0},
        ]
        result = _prompt_source_choice(matches, "test")
        assert result is None

    @patch("agentpowers_cli.commands.install.typer.prompt", return_value=99)
    def test_too_high_choice_returns_none(self, mock_prompt: MagicMock) -> None:
        """Choice exceeding list length returns None."""
        from agentpowers_cli.commands.install import _prompt_source_choice

        matches = [
            {"source": "clawhub", "title": "A", "version": "1.0",
             "source_installs": 0},
        ]
        result = _prompt_source_choice(matches, "test")
        assert result is None


# ---------------------------------------------------------------------------
# NEW: install with --source flag edge cases (lines 277-278)
# ---------------------------------------------------------------------------


class TestInstallSourceFlagEdgeCases:
    """Edge cases for install command with --source flag."""

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_source_flag_with_skill_lookup_api_error(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """--source with API error on skill lookup still proceeds to external."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = APIError("Not found", status_code=404)
        mock_ext_install.return_value = "/tmp/installed"

        result = runner.invoke(app, ["install", "ext-skill", "--source", "clawhub"])

        assert result.exit_code == 0
        mock_ext_install.assert_called_once()


# ---------------------------------------------------------------------------
# NEW: Multiple external sources prompt (lines 341-347)
# ---------------------------------------------------------------------------


class TestMultipleExternalSourcesPrompt:
    """Tests for the multi-source prompt path in install."""

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_multiple_sources_user_picks_first(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """Multiple external matches, user picks 1."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            APIError("Not found", status_code=404),
            # /v1/detail -> 404
            APIError("Not found", status_code=404),
            {
                "agentpowers": {"items": [], "total": 0},
                "clawhub": {
                    "total": 1,
                    "items": [{"slug": "multi", "title": "Multi",
                               "source": "clawhub", "source_installs": 10,
                               "version": "1.0"}],
                },
                "otherhub": {
                    "total": 1,
                    "items": [{"slug": "multi", "title": "Multi",
                               "source": "otherhub", "source_installs": 5,
                               "version": "2.0"}],
                },
            },
        ]
        mock_ext_install.return_value = "/tmp/installed"

        result = runner.invoke(app, ["install", "multi"], input="1\n")

        assert result.exit_code == 0
        mock_ext_install.assert_called_once()

    @patch("agentpowers_cli.commands.install.install_external_skill")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_multiple_sources_invalid_choice_exits(
        self, mock_get_client: MagicMock, mock_ext_install: MagicMock
    ) -> None:
        """Invalid choice (0) for multiple sources exits code 1."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            APIError("Not found", status_code=404),
            # /v1/detail -> 404
            APIError("Not found", status_code=404),
            {
                "agentpowers": {"items": [], "total": 0},
                "clawhub": {
                    "total": 1,
                    "items": [{"slug": "multi", "title": "Multi",
                               "source": "clawhub", "source_installs": 10,
                               "version": "1.0"}],
                },
                "otherhub": {
                    "total": 1,
                    "items": [{"slug": "multi", "title": "Multi",
                               "source": "otherhub", "source_installs": 5,
                               "version": "2.0"}],
                },
            },
        ]

        result = runner.invoke(app, ["install", "multi"], input="0\n")

        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# NEW: Non-404 API error (lines 294-295) and --for flag variants
# ---------------------------------------------------------------------------


class TestInstallMiscEdgeCases:
    """Misc edge case tests for install command."""

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_non_404_api_error_exits(self, mock_get_client: MagicMock) -> None:
        """Non-404 API error from skill lookup exits with code 1."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = APIError("Server error", status_code=500)

        result = runner.invoke(app, ["install", "server-error-skill"])

        assert result.exit_code == 1
        assert "error" in result.output.lower()

    @patch("agentpowers_cli.commands.install.install_from_url")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_for_gemini_flag(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """--for gemini passes ~/.gemini as base_dir."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(slug="my-skill"),
            {"url": "https://cdn.example.com/my-skill.zip"},
        ]
        mock_install_url.return_value = str(
            Path.home() / ".gemini" / "skills" / "my-skill"
        )

        result = runner.invoke(app, ["install", "--for", "gemini", "my-skill"])

        assert result.exit_code == 0
        call_kwargs = mock_install_url.call_args
        base_dir_arg = call_kwargs.kwargs.get("base_dir")
        assert base_dir_arg == Path.home() / ".gemini"

    @patch("agentpowers_cli.commands.install.install_from_url")
    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_for_kiro_flag(
        self, mock_get_client: MagicMock, mock_install_url: MagicMock
    ) -> None:
        """--for kiro passes ~/.kiro as base_dir."""
        client = MagicMock()
        mock_get_client.return_value = client
        client.get.side_effect = [
            _mock_skill(slug="my-skill"),
            {"url": "https://cdn.example.com/my-skill.zip"},
        ]
        mock_install_url.return_value = str(
            Path.home() / ".kiro" / "skills" / "my-skill"
        )

        result = runner.invoke(app, ["install", "--for", "kiro", "my-skill"])

        assert result.exit_code == 0
        call_kwargs = mock_install_url.call_args
        base_dir_arg = call_kwargs.kwargs.get("base_dir")
        assert base_dir_arg == Path.home() / ".kiro"
