"""Extended adversarial tests — boundary values and auth edge cases.

These tests cover boundary value testing for search, publish, install,
and detail commands, plus authentication edge cases across all
auth-requiring commands.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError

runner = CliRunner()


# ---------------------------------------------------------------------------
# Search boundary values
# ---------------------------------------------------------------------------


class TestSearchBoundaryValues:
    """Boundary value tests for the search command."""

    @patch("agentpowers_cli.commands.search._get_installed_slugs", return_value={})
    @patch("agentpowers_cli.commands.search.get_api_client")
    def test_search_huge_limit(
        self, mock_client_fn: MagicMock, mock_slugs: MagicMock
    ) -> None:
        """A very large --limit should pass through to the API without error."""
        client = MagicMock()
        client.get.return_value = {"agentpowers": {"items": [], "total": 0}}
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["search", "--limit", "999999", "test"])
        assert result.exit_code == 0
        client.get.assert_called_once()
        call_params = client.get.call_args[1].get("params", {})
        assert call_params.get("limit") == 999999

    def test_search_float_limit(self) -> None:
        """Typer rejects non-integer --limit values."""
        result = runner.invoke(app, ["search", "--limit", "1.5", "test"])
        assert result.exit_code != 0

    def test_search_non_numeric_limit(self) -> None:
        """Typer rejects non-numeric --limit values."""
        result = runner.invoke(app, ["search", "--limit", "abc", "test"])
        assert result.exit_code != 0

    def test_search_empty_query(self) -> None:
        """An empty query string should be rejected."""
        result = runner.invoke(app, ["search", ""])
        assert result.exit_code != 0
        assert "empty" in result.output.lower()

    @patch("agentpowers_cli.commands.search.get_api_client")
    def test_search_invalid_type(self, mock_client_fn: MagicMock) -> None:
        """An invalid --type value should be rejected client-side."""
        result = runner.invoke(app, ["search", "--type", "invalid", "test"])
        assert result.exit_code != 0
        assert "invalid" in result.output.lower()


# ---------------------------------------------------------------------------
# Publish boundary values
# ---------------------------------------------------------------------------


class TestPublishBoundaryValues:
    """Boundary value tests for the publish command."""

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_price_zero(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """Price 0 should be accepted (free skill)."""
        client = MagicMock()
        client.post.return_value = {"slug": "test-skill"}
        client.upload.return_value = {}
        mock_client_fn.return_value = client

        result = runner.invoke(
            app, ["publish", "--price", "0", "--dir", str(skill_dir)]
        )
        assert result.exit_code == 0
        # Verify API was called with price_cents=0
        post_call = client.post.call_args
        payload = post_call[1].get("json_data", {})
        assert payload.get("price_cents") == 0

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_price_fractional_cents(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """Fractional cent price (0.001) converts to int via int(0.001*100)=0."""
        client = MagicMock()
        client.post.return_value = {"slug": "test-skill"}
        client.upload.return_value = {}
        mock_client_fn.return_value = client

        result = runner.invoke(
            app, ["publish", "--price", "0.001", "--dir", str(skill_dir)]
        )
        # Should succeed — int(0.001 * 100) = 0, treated as free
        assert result.exit_code == 0

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_price_above_cap(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """Price above $1000 cap — no client-side validation, passes to API.

        The $1000 cap is enforced server-side. The CLI passes the value
        through, so the API would reject it with a 422.
        """
        client = MagicMock()
        client.post.side_effect = APIError(
            "Price exceeds maximum", status_code=422
        )
        mock_client_fn.return_value = client

        result = runner.invoke(
            app, ["publish", "--price", "1001", "--dir", str(skill_dir)]
        )
        assert result.exit_code != 0

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_bump_invalid(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """An invalid --bump value should be rejected by the API on update."""
        client = MagicMock()
        # First publish: 409 (exists), then update with bad bump
        client.post.side_effect = APIError("exists", status_code=409)
        client.patch.side_effect = APIError(
            "Invalid bump value", status_code=422
        )
        mock_client_fn.return_value = client

        result = runner.invoke(
            app, ["publish", "--bump", "invalid", "--dir", str(skill_dir)]
        )
        # The API rejects the invalid bump value with a 422
        assert result.exit_code != 0
        # Verify the invalid bump was actually sent to the API
        patch_call = client.patch.call_args
        patch_data = patch_call[1].get("json_data", {})
        assert patch_data.get("bump") == "invalid"

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_bump_uppercase(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """Uppercase --bump value (MAJOR) passes through to API.

        No client-side case normalization — API decides acceptance.
        """
        client = MagicMock()
        # First publish: 409 (exists), then update
        client.post.side_effect = APIError("exists", status_code=409)
        client.patch.return_value = {"new_version": "2.0.0"}
        client.upload.return_value = {}
        mock_client_fn.return_value = client

        result = runner.invoke(
            app, ["publish", "--bump", "MAJOR", "--dir", str(skill_dir)]
        )
        # Verify the bump value was sent as-is
        patch_call = client.patch.call_args
        patch_data = patch_call[1].get("json_data", {})
        assert patch_data.get("bump") == "MAJOR"

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_version_not_semver(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """Non-semver --version string passes to API (server validates)."""
        client = MagicMock()
        client.post.side_effect = APIError("exists", status_code=409)
        client.patch.side_effect = APIError(
            "Invalid version format", status_code=422
        )
        mock_client_fn.return_value = client

        result = runner.invoke(
            app,
            ["publish", "--version", "abc", "--dir", str(skill_dir)],
        )
        assert result.exit_code != 0

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_version_partial(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """Partial version string (1.2) passes to API (server validates)."""
        client = MagicMock()
        client.post.side_effect = APIError("exists", status_code=409)
        client.patch.side_effect = APIError(
            "Invalid version format", status_code=422
        )
        mock_client_fn.return_value = client

        result = runner.invoke(
            app,
            ["publish", "--version", "1.2", "--dir", str(skill_dir)],
        )
        assert result.exit_code != 0

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_version_v_prefix(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """Version with v prefix (v1.0.0) passes to API (server validates)."""
        client = MagicMock()
        client.post.side_effect = APIError("exists", status_code=409)
        client.patch.side_effect = APIError(
            "Invalid version format", status_code=422
        )
        mock_client_fn.return_value = client

        result = runner.invoke(
            app,
            ["publish", "--version", "v1.0.0", "--dir", str(skill_dir)],
        )
        assert result.exit_code != 0

    def test_publish_no_skill_md(self, tmp_path: Path) -> None:
        """Publishing from a directory without SKILL.md should fail."""
        result = runner.invoke(
            app, ["publish", "--dir", str(tmp_path)]
        )
        assert result.exit_code != 0
        assert "no skill" in result.output.lower()

    def test_publish_nonexistent_dir(self) -> None:
        """Publishing from a nonexistent directory should fail."""
        result = runner.invoke(
            app, ["publish", "--dir", "/tmp/nonexistent-ap-test-dir"]
        )
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Install boundary values
# ---------------------------------------------------------------------------


class TestInstallBoundaryValues:
    """Boundary value tests for the install command."""

    def test_install_for_invalid_tool(self) -> None:
        """An invalid --for tool name should be rejected."""
        result = runner.invoke(app, ["install", "my-skill", "--for", "invalid-tool"])
        assert result.exit_code != 0
        assert "unknown tool" in result.output.lower() or "supported" in result.output.lower()

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_code_empty(self, mock_client_fn: MagicMock) -> None:
        """An empty --code string should be passed through (API validates)."""
        client = MagicMock()
        # The skill lookup succeeds, then redeem with empty code fails
        client.get.return_value = {
            "slug": "my-skill",
            "price_cents": 500,
            "security_status": "pass",
            "type": "skill",
        }
        client.post.side_effect = APIError("Invalid license code", status_code=400)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["install", "my-skill", "--code", ""])
        assert result.exit_code != 0
        assert "license" in result.output.lower() or "redeem" in result.output.lower()

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_code_whitespace(self, mock_client_fn: MagicMock) -> None:
        """A whitespace-only --code should be passed through (API validates)."""
        client = MagicMock()
        client.get.return_value = {
            "slug": "my-skill",
            "price_cents": 500,
            "security_status": "pass",
            "type": "skill",
        }
        client.post.side_effect = APIError("Invalid license code", status_code=400)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["install", "my-skill", "--code", "   "])
        assert result.exit_code != 0
        assert "license" in result.output.lower() or "redeem" in result.output.lower()

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_empty_author(self, mock_client_fn: MagicMock) -> None:
        """Slug with empty author ('/my-skill') treats author as None.

        _parse_slug returns (None, 'my-skill') for '/my-skill' since
        the empty author becomes None via ``author or None``. The command
        then falls through to normal slug lookup (no author resolution).
        """
        client = MagicMock()
        # Simulate skill not found natively
        client.get.side_effect = APIError("Not found", status_code=404)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["install", "/my-skill"])
        assert result.exit_code != 0
        # Verify it didn't try the author/slug path (no /v1/sellers/ call)
        calls = [str(c) for c in client.get.call_args_list]
        assert not any("/v1/sellers/" in c for c in calls)


# ---------------------------------------------------------------------------
# Detail boundary values
# ---------------------------------------------------------------------------


class TestDetailBoundaryValues:
    """Boundary value tests for the detail command."""

    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_detail_source_empty(self, mock_client_fn: MagicMock) -> None:
        """An empty --source string should be passed as a param (API decides)."""
        client = MagicMock()
        client.get.return_value = {
            "title": "My Skill",
            "slug": "my-skill",
            "description": "A skill",
            "price_cents": 0,
        }
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["detail", "my-skill", "--source", ""])
        # Empty source is passed as a param; API returns data normally
        assert result.exit_code == 0

    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_detail_source_whitespace(self, mock_client_fn: MagicMock) -> None:
        """A whitespace-only --source is passed through to the API."""
        client = MagicMock()
        client.get.return_value = {
            "title": "My Skill",
            "slug": "my-skill",
            "description": "A skill",
            "price_cents": 0,
        }
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["detail", "my-skill", "--source", "   "])
        # Whitespace source is sent to API; response is still rendered
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# Auth edge cases
# ---------------------------------------------------------------------------


class TestAuthEdgeCases:
    """Auth-related edge cases across commands."""

    @patch("agentpowers_cli.commands.auth.get_api_client")
    def test_whoami_expired_token_401(self, mock_client_fn: MagicMock) -> None:
        """whoami with an expired token (API returns 401) should fail."""
        client = MagicMock()
        client.get.side_effect = APIError("Token expired", status_code=401)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["whoami"])
        assert result.exit_code == 1
        assert "not logged in" in result.output.lower()

    @patch("agentpowers_cli.commands.auth.get_api_client")
    def test_whoami_no_token(self, mock_client_fn: MagicMock) -> None:
        """whoami with no stored token should fail."""
        client = MagicMock()
        client.get.side_effect = APIError(
            "Not authenticated. Run `ap login` first.", status_code=401
        )
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["whoami"])
        assert result.exit_code == 1

    # Note: test_claim_no_token removed — `ap claim` command was removed in
    # commit 2829cec ("not ready for public release").

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_no_token(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """publish with no token should fail with exit code 1."""
        client = MagicMock()
        client.post.side_effect = APIError(
            "Not authenticated. Run `ap login` first.", status_code=401
        )
        mock_client_fn.return_value = client

        result = runner.invoke(
            app, ["publish", "--dir", str(skill_dir)]
        )
        assert result.exit_code != 0
        assert "not authenticated" in result.output.lower() or "login" in result.output.lower()

    @patch("agentpowers_cli.commands.profile.get_api_client")
    def test_profile_expired_token(self, mock_client_fn: MagicMock) -> None:
        """profile with expired token (401) should fail."""
        client = MagicMock()
        client.get.side_effect = APIError("Token expired", status_code=401)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["profile"])
        assert result.exit_code == 1
        assert "not logged in" in result.output.lower()

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_expired_token(self, mock_client_fn: MagicMock) -> None:
        """unpublish with expired token (401) should fail."""
        client = MagicMock()
        client.post.side_effect = APIError("Token expired", status_code=401)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "not logged in" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_expired_token(self, mock_client_fn: MagicMock) -> None:
        """republish with expired token (401) should fail."""
        client = MagicMock()
        client.post.side_effect = APIError("Token expired", status_code=401)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "not logged in" in result.output.lower()

    @patch(
        "agentpowers_cli.commands.auth.delete_token",
        return_value=None,
    )
    @patch("agentpowers_cli.commands.auth.get_api_client")
    def test_logout_when_already_logged_out(
        self, mock_client_fn: MagicMock, mock_delete: MagicMock
    ) -> None:
        """logout when already logged out should still succeed gracefully."""
        client = MagicMock()
        # Revocation fails because no token — that's fine, best-effort
        client.post.side_effect = APIError("Not authenticated", status_code=401)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["logout"])
        assert result.exit_code == 0
        assert "logged out" in result.output.lower()
        mock_delete.assert_called_once()

    @patch("agentpowers_cli.commands.auth.get_api_client")
    def test_whoami_corrupted_auth_json(self, mock_client_fn: MagicMock) -> None:
        """whoami when load_token returns None (corrupted file) should fail."""
        client = MagicMock()
        client.get.side_effect = APIError(
            "Not authenticated. Run `ap login` first.", status_code=401
        )
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["whoami"])
        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# Input injection tests
# ---------------------------------------------------------------------------


class TestInputInjection:
    """Tests that shell metacharacters and special inputs are safely handled."""

    def test_slug_shell_dollar(self) -> None:
        """install '$HOME' should be rejected (invalid slug chars)."""
        result = runner.invoke(app, ["install", "$HOME"])
        assert result.exit_code != 0
        assert "invalid slug" in result.output.lower()

    def test_slug_shell_backtick(self) -> None:
        """install '`whoami`' should be rejected."""
        result = runner.invoke(app, ["install", "`whoami`"])
        assert result.exit_code != 0
        assert "invalid slug" in result.output.lower()

    def test_slug_shell_pipe(self) -> None:
        """install 'foo|bar' should be rejected."""
        result = runner.invoke(app, ["install", "foo|bar"])
        assert result.exit_code != 0
        assert "invalid slug" in result.output.lower()

    def test_slug_shell_semicolon(self) -> None:
        """install 'foo;ls' should be rejected."""
        result = runner.invoke(app, ["install", "foo;ls"])
        assert result.exit_code != 0
        assert "invalid slug" in result.output.lower()

    def test_slug_shell_ampersand(self) -> None:
        """install 'foo&&ls' should be rejected."""
        result = runner.invoke(app, ["install", "foo&&ls"])
        assert result.exit_code != 0
        assert "invalid slug" in result.output.lower()

    def test_slug_unicode_emoji(self) -> None:
        """install 'skill-\U0001f680' should be rejected."""
        result = runner.invoke(app, ["install", "skill-\U0001f680"])
        assert result.exit_code != 0
        assert "invalid slug" in result.output.lower()

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_slug_max_length_128(self, mock_client_fn: MagicMock) -> None:
        """128-char slug passes validate_slug (may fail at API level)."""
        client = MagicMock()
        client.get.side_effect = APIError("Not found", status_code=404)
        mock_client_fn.return_value = client

        long_slug = "a" * 128
        result = runner.invoke(app, ["install", long_slug])
        # validate_slug accepts it; fails at API level (404) which is fine
        assert result.exit_code != 0
        # Key point: no "invalid slug" error — it passed slug validation
        assert "invalid slug" not in result.output.lower()

    def test_slug_over_max_length_129(self) -> None:
        """129-char slug should be rejected by validate_slug."""
        long_slug = "a" * 129
        result = runner.invoke(app, ["install", long_slug])
        assert result.exit_code != 0
        assert "invalid slug" in result.output.lower()

    @patch("agentpowers_cli.commands.search._get_installed_slugs", return_value={})
    @patch("agentpowers_cli.commands.search.get_api_client")
    def test_search_sql_injection(
        self, mock_client_fn: MagicMock, mock_slugs: MagicMock
    ) -> None:
        """SQL injection in search query should not crash."""
        client = MagicMock()
        client.get.return_value = {"agentpowers": {"items": [], "total": 0}}
        mock_client_fn.return_value = client

        result = runner.invoke(
            app, ["search", "'; DROP TABLE skills; --"]
        )
        assert result.exit_code == 0

    @patch("agentpowers_cli.commands.search._get_installed_slugs", return_value={})
    @patch("agentpowers_cli.commands.search.get_api_client")
    def test_search_very_long_input(
        self, mock_client_fn: MagicMock, mock_slugs: MagicMock
    ) -> None:
        """1001-char search query should not crash."""
        client = MagicMock()
        client.get.return_value = {"agentpowers": {"items": [], "total": 0}}
        mock_client_fn.return_value = client

        long_query = "x" * 1001
        result = runner.invoke(app, ["search", long_query])
        assert result.exit_code == 0

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_changelog_shell_metachar(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """Changelog with shell metachar should be passed as literal string."""
        client = MagicMock()
        # First publish succeeds (409 = exists), then update
        client.post.side_effect = APIError("exists", status_code=409)
        client.patch.return_value = {"new_version": "1.0.1"}
        client.upload.return_value = {}
        mock_client_fn.return_value = client

        result = runner.invoke(
            app,
            [
                "publish",
                "--changelog",
                "$(rm -rf /)",
                "--dir",
                str(skill_dir),
            ],
        )
        # Verify the changelog was passed as a literal string
        patch_call = client.patch.call_args
        patch_data = patch_call[1].get("json_data", {})
        assert patch_data.get("changelog") == "$(rm -rf /)"


# ---------------------------------------------------------------------------
# Network failure modes
# ---------------------------------------------------------------------------


class TestNetworkFailureModes:
    """Tests that every command handles API failures gracefully."""

    @patch("agentpowers_cli.commands.search._get_installed_slugs", return_value={})
    @patch("agentpowers_cli.commands.search.get_api_client")
    def test_search_connection_timeout(
        self, mock_client_fn: MagicMock, mock_slugs: MagicMock
    ) -> None:
        """Search when API times out should fail with error message."""
        client = MagicMock()
        client.get.side_effect = APIError("Connection timed out", status_code=0)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["search", "test"])
        assert result.exit_code != 0
        assert "error" in result.output.lower() or "timed out" in result.output.lower()

    @patch("agentpowers_cli.commands.search._get_installed_slugs", return_value={})
    @patch("agentpowers_cli.commands.search.get_api_client")
    def test_search_http_500(
        self, mock_client_fn: MagicMock, mock_slugs: MagicMock
    ) -> None:
        """Search when API returns 500 should fail with error message."""
        client = MagicMock()
        client.get.side_effect = APIError("Internal server error", status_code=500)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["search", "test"])
        assert result.exit_code != 0
        assert "error" in result.output.lower()

    @patch("agentpowers_cli.commands.install.get_api_client")
    def test_install_http_500(self, mock_client_fn: MagicMock) -> None:
        """Install when API returns 500 should fail with error message."""
        client = MagicMock()
        client.get.side_effect = APIError("Internal server error", status_code=500)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["install", "my-skill"])
        assert result.exit_code != 0
        assert "error" in result.output.lower()

    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_detail_http_500(self, mock_client_fn: MagicMock) -> None:
        """Detail when API returns 500 should fail with error message."""
        client = MagicMock()
        client.get.side_effect = APIError("Internal server error", status_code=500)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["detail", "my-skill"])
        assert result.exit_code != 0
        assert "error" in result.output.lower()

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_http_500(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """Publish when API returns 500 should fail with error message."""
        client = MagicMock()
        client.post.side_effect = APIError("Internal server error", status_code=500)
        mock_client_fn.return_value = client

        result = runner.invoke(
            app, ["publish", "--dir", str(skill_dir)]
        )
        assert result.exit_code != 0
        assert "error" in result.output.lower()

    # Note: test_claim_http_500 removed — `ap claim` was removed in commit 2829cec.

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_http_429(self, mock_client_fn: MagicMock) -> None:
        """Unpublish when rate limited (429) should fail with error message."""
        client = MagicMock()
        client.post.side_effect = APIError("Too many requests", status_code=429)
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code != 0
        assert "error" in result.output.lower() or "too many" in result.output.lower()

    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_connection_error(
        self, mock_client_fn: MagicMock, mock_load_pins: MagicMock
    ) -> None:
        """Update when connection refused should fail gracefully."""
        client = MagicMock()
        client.get.side_effect = APIError("Connection refused", status_code=0)
        mock_client_fn.return_value = client

        # Need pins with a skill to trigger the update check
        mock_load_pins.return_value = {
            "my-skill": {
                "source": "agentpowers",
                "version": "1.0.0",
                "content_hash": "abc123",
                "security_status": "pass",
            }
        }

        result = runner.invoke(app, ["update", "my-skill"])
        assert result.exit_code != 0


# ---------------------------------------------------------------------------
# Filesystem adversarial tests
# ---------------------------------------------------------------------------


class TestFileSystemAdversarial:
    """Tests filesystem edge cases."""

    def test_publish_sensitive_path(self) -> None:
        """Publishing from /etc should error (no SKILL.md there)."""
        result = runner.invoke(app, ["publish", "--dir", "/etc"])
        assert result.exit_code != 0
        assert "no skill" in result.output.lower()

    @patch("agentpowers_cli.commands.verify.load_pins")
    def test_verify_corrupted_pins(
        self, mock_load_pins: MagicMock
    ) -> None:
        """Verify when pins file returns empty (corrupt JSON) handles gracefully."""
        mock_load_pins.return_value = {}

        result = runner.invoke(app, ["verify"])
        assert result.exit_code == 0
        assert "no installed" in result.output.lower()

    @patch("agentpowers_cli.commands.status.get_install_candidate_dirs")
    @patch("agentpowers_cli.commands.status.load_token", return_value=None)
    def test_status_no_skills_dir(
        self,
        mock_token: MagicMock,
        mock_claude_dir: MagicMock,
        tmp_path: Path,
    ) -> None:
        """Status when claude dir has no skills/agents subdirs."""
        mock_claude_dir.return_value = [tmp_path]
        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "no skills" in result.output.lower()

    @patch("agentpowers_cli.commands.uninstall.get_install_candidate_dirs")
    def test_uninstall_nonexistent_skill(
        self, mock_claude_dir: MagicMock, tmp_path: Path
    ) -> None:
        """Uninstall of a nonexistent skill should report not found."""
        mock_claude_dir.return_value = [tmp_path]
        result = runner.invoke(
            app, ["uninstall", "nonexistent-skill", "--force"]
        )
        assert result.exit_code != 0
        assert "not found" in result.output.lower()


# ---------------------------------------------------------------------------
# Race conditions / state tests
# ---------------------------------------------------------------------------


class TestRaceConditionsState:
    """Tests state-related edge cases."""

    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_no_skills_installed(
        self, mock_client_fn: MagicMock, mock_load_pins: MagicMock
    ) -> None:
        """Update with empty pins should show 'No skills' message."""
        mock_load_pins.return_value = {}
        client = MagicMock()
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["update"])
        assert result.exit_code == 0
        assert "no skills" in result.output.lower()

    @patch("agentpowers_cli.commands.update.load_pins")
    @patch("agentpowers_cli.commands.update.get_api_client")
    def test_update_single_not_installed(
        self, mock_client_fn: MagicMock, mock_load_pins: MagicMock
    ) -> None:
        """Update for a nonexistent slug should show 'not installed'."""
        mock_load_pins.return_value = {}
        client = MagicMock()
        mock_client_fn.return_value = client

        result = runner.invoke(app, ["update", "nonexistent-slug"])
        assert result.exit_code != 0
        assert "not installed" in result.output.lower()


# ---------------------------------------------------------------------------
# Flag combination tests
# ---------------------------------------------------------------------------


class TestFlagCombinations:
    """Tests unusual but valid flag combinations."""

    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_price_zero_with_category(
        self, mock_client_fn: MagicMock, skill_dir: Path
    ) -> None:
        """Publish with --price 0 --category security should succeed."""
        client = MagicMock()
        client.post.return_value = {"slug": "test-skill"}
        client.upload.return_value = {}
        mock_client_fn.return_value = client

        result = runner.invoke(
            app,
            [
                "publish",
                "--price",
                "0",
                "--category",
                "security",
                "--dir",
                str(skill_dir),
            ],
        )
        assert result.exit_code == 0
        post_call = client.post.call_args
        payload = post_call[1].get("json_data", {})
        assert payload.get("price_cents") == 0
        assert payload.get("category") == "security"

    @patch("agentpowers_cli.commands.detail._resolve_source", return_value="clawhub")
    @patch("agentpowers_cli.commands.detail._download_to_sandbox")
    @patch("agentpowers_cli.commands.detail._upload_for_scan")
    @patch("agentpowers_cli.commands.detail.shutil")
    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_detail_scan_with_source(
        self,
        mock_client_fn: MagicMock,
        mock_shutil: MagicMock,
        mock_upload: MagicMock,
        mock_download: MagicMock,
        mock_resolve: MagicMock,
    ) -> None:
        """detail my-skill --scan --source clawhub should succeed."""
        client = MagicMock()
        client.get.return_value = {
            "title": "My Skill",
            "slug": "my-skill",
            "description": "A skill",
            "price_cents": 0,
            "type": "skill",
        }
        mock_client_fn.return_value = client

        mock_download.return_value = ("/tmp/sandbox", "/tmp/sandbox/pkg.zip")
        mock_upload.return_value = {
            "security_status": "pass",
            "security_score": 10,
            "findings": [],
        }

        result = runner.invoke(
            app, ["detail", "my-skill", "--scan", "--source", "clawhub"]
        )
        assert result.exit_code == 0
