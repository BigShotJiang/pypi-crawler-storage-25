"""Tests for version pinning manager."""

from __future__ import annotations

import json

from agentpowers_cli.services.pin_manager import load_pins, save_pin, verify_pin


class TestLoadPins:
    """Tests for load_pins function."""

    def test_load_pins_empty(self, tmp_path):
        """Returns empty dict when file does not exist."""
        pins = load_pins(str(tmp_path / "nonexistent.json"))
        assert pins == {}

    def test_load_pins_with_data(self, tmp_path):
        """Returns stored data from an existing pins file."""
        pins_file = tmp_path / "pins.json"
        pins_file.write_text(json.dumps({"my-skill": {"source": "clawhub"}}))
        pins = load_pins(str(pins_file))
        assert pins["my-skill"]["source"] == "clawhub"


class TestSavePin:
    """Tests for save_pin function."""

    def test_save_and_load_pin(self, tmp_path):
        """Saved pin is retrievable via load_pins."""
        pins_file = tmp_path / "pins.json"
        save_pin(
            slug="test-skill",
            source="clawhub",
            version="1.0.0",
            content_hash="sha256:abc123",
            security_status="pass",
            pins_path=str(pins_file),
        )
        pins = load_pins(str(pins_file))
        assert "test-skill" in pins
        assert pins["test-skill"]["content_hash"] == "sha256:abc123"
        assert pins["test-skill"]["source"] == "clawhub"
        assert pins["test-skill"]["version"] == "1.0.0"
        assert pins["test-skill"]["security_status"] == "pass"
        assert "installed_at" in pins["test-skill"]
        assert "scanned_at" in pins["test-skill"]

    def test_save_pin_creates_parent_dirs(self, tmp_path):
        """Parent directories are created if they do not exist."""
        pins_file = tmp_path / "nested" / "dir" / "pins.json"
        save_pin("s1", "clawhub", "1.0", "sha256:aaa", "pass", pins_path=str(pins_file))
        assert pins_file.exists()

    def test_save_pin_overwrites_existing(self, tmp_path):
        """Saving a pin for the same slug overwrites the previous one."""
        pins_file = tmp_path / "pins.json"
        save_pin("s1", "clawhub", "1.0", "sha256:old", "pass", pins_path=str(pins_file))
        save_pin("s1", "clawhub", "2.0", "sha256:new", "warn", pins_path=str(pins_file))
        pins = load_pins(str(pins_file))
        assert pins["s1"]["content_hash"] == "sha256:new"
        assert pins["s1"]["version"] == "2.0"
        assert pins["s1"]["security_status"] == "warn"

    def test_save_multiple_pins(self, tmp_path):
        """Multiple slugs coexist in the same pins file."""
        pins_file = tmp_path / "pins.json"
        save_pin("s1", "clawhub", "1.0", "sha256:aaa", "pass", pins_path=str(pins_file))
        save_pin("s2", "clawhub", "2.0", "sha256:bbb", "warn", pins_path=str(pins_file))
        pins = load_pins(str(pins_file))
        assert len(pins) == 2
        assert "s1" in pins
        assert "s2" in pins

    def test_save_pin_with_none_version(self, tmp_path):
        """Version can be None for skills with unknown versions."""
        pins_file = tmp_path / "pins.json"
        save_pin("s1", "clawhub", None, "sha256:aaa", "pass", pins_path=str(pins_file))
        pins = load_pins(str(pins_file))
        assert pins["s1"]["version"] is None


class TestVerifyPin:
    """Tests for verify_pin function."""

    def test_verify_pin_match(self, tmp_path):
        """Returns True when content hash matches stored pin."""
        pins_file = tmp_path / "pins.json"
        save_pin("s1", "clawhub", "1.0", "sha256:aaa", "pass", pins_path=str(pins_file))
        assert verify_pin("s1", "sha256:aaa", str(pins_file)) is True

    def test_verify_pin_mismatch(self, tmp_path):
        """Returns False when content hash does not match stored pin."""
        pins_file = tmp_path / "pins.json"
        save_pin("s1", "clawhub", "1.0", "sha256:aaa", "pass", pins_path=str(pins_file))
        assert verify_pin("s1", "sha256:bbb", str(pins_file)) is False

    def test_verify_pin_missing(self, tmp_path):
        """Returns None when no pin exists for the slug."""
        assert verify_pin("missing", "sha256:x", str(tmp_path / "pins.json")) is None

    def test_verify_pin_missing_file(self, tmp_path):
        """Returns None when the pins file does not exist at all."""
        assert verify_pin("any", "sha256:x", str(tmp_path / "nope.json")) is None


class TestLoadPinsEdgeCases:
    """Additional edge cases for load_pins."""

    def test_load_pins_invalid_json(self, tmp_path):
        """Returns empty dict for corrupted JSON file."""
        bad = tmp_path / "pins.json"
        bad.write_text("{not valid")
        result = load_pins(str(bad))
        assert result == {}


class TestVerifyPinNoneHash:
    """Test verify_pin when stored hash is None."""

    def test_verify_pin_stored_hash_none(self, tmp_path):
        """Returns None when stored content_hash is None."""
        pins_file = tmp_path / "pins.json"
        # Manually write a pin without content_hash
        import json
        pins_file.write_text(json.dumps({
            "my-skill": {
                "source": "clawhub",
                "version": "1.0.0",
            }
        }))
        result = verify_pin("my-skill", "sha256:abc", str(pins_file))
        assert result is None
