"""Tests for the main CLI entry point."""

from __future__ import annotations

from unittest.mock import patch

from typer.testing import CliRunner

from agentpowers_cli.main import app

runner = CliRunner()


class TestVersionFlag:
    """Tests for --version and -V flags."""

    def test_version_flag_shows_version(self) -> None:
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "agentpowers" in result.output

    def test_short_version_flag_shows_version(self) -> None:
        result = runner.invoke(app, ["-V"])
        assert result.exit_code == 0
        assert "agentpowers" in result.output

    @patch("agentpowers_cli.main._pkg_version", side_effect=Exception("not found"))
    def test_version_fallback_on_package_not_found(self, _mock: object) -> None:
        """Falls back to 'dev' when package metadata is unavailable."""
        from importlib.metadata import PackageNotFoundError

        with patch(
            "agentpowers_cli.main._pkg_version",
            side_effect=PackageNotFoundError("agentpowers"),
        ):
            result = runner.invoke(app, ["--version"])
            assert result.exit_code == 0
            assert "dev" in result.output


class TestNoArgsShowsHelp:
    """Verify no-args triggers help output."""

    def test_no_args_shows_help(self) -> None:
        result = runner.invoke(app, [])
        # Typer's no_args_is_help returns exit code 0 or 2 depending on version
        assert result.exit_code in (0, 2)
        assert "Usage" in result.output or "agentpowers" in result.output.lower()


class TestMainModule:
    """Test the __main__ entry point."""

    def test_main_module_is_callable(self) -> None:
        """The app module defines an app that is callable."""
        from agentpowers_cli.main import app

        assert app is not None
        # Verify all expected commands are registered
        command_names = [cmd.name for cmd in app.registered_commands]
        assert "login" in command_names
        assert "search" in command_names
        assert "install" in command_names
