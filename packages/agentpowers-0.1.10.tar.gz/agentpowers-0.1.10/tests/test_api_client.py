"""Tests for api_client module."""

from unittest.mock import MagicMock, patch

import pytest

from agentpowers_cli.services.api_client import APIClient, APIError


class TestAPIError:
    """Tests for APIError exception."""

    def test_has_status_code(self) -> None:
        err = APIError("not found", status_code=404)
        assert err.status_code == 404

    def test_has_message(self) -> None:
        err = APIError("server error", status_code=500)
        assert str(err) == "server error"


class TestAPIClientGet:
    """Tests for APIClient.get method."""

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_get_without_auth_no_authorization_header(
        self, mock_client_cls: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"data": "ok"}
        mock_response.is_success = True
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        result = client.get("/v1/skills", auth=False)

        assert result == {"data": "ok"}
        call_kwargs = mock_client.get.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert "Authorization" not in headers

    @patch(
        "agentpowers_cli.services.api_client.load_token",
        return_value="jwt-token-abc",
    )
    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_get_with_auth_includes_bearer_token(
        self, mock_client_cls: MagicMock, mock_load: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"skills": []}
        mock_response.is_success = True
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        result = client.get("/v1/skills", auth=True)

        assert result == {"skills": []}
        call_kwargs = mock_client.get.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert headers["Authorization"] == "Bearer jwt-token-abc"

    @patch("agentpowers_cli.services.api_client.load_token", return_value=None)
    def test_get_auth_required_but_no_token_raises(
        self, mock_load: MagicMock
    ) -> None:
        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError, match="Not authenticated"):
            client.get("/v1/skills", auth=True)

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_get_with_params(self, mock_client_cls: MagicMock) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"results": []}
        mock_response.is_success = True
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        client.get("/v1/search", auth=False, params={"q": "test"})

        call_kwargs = mock_client.get.call_args
        assert call_kwargs.kwargs["params"] == {"q": "test"}

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_get_http_error_raises_api_error(
        self, mock_client_cls: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.is_success = False
        mock_response.json.return_value = {"detail": "Skill not found"}
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.get("/v1/skills/missing", auth=False)

        assert exc_info.value.status_code == 404
        assert "Skill not found" in str(exc_info.value)


class TestAPIClientPost:
    """Tests for APIClient.post method."""

    @patch("agentpowers_cli.services.api_client.load_token", return_value="token-123")
    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_post_with_json_body(
        self, mock_client_cls: MagicMock, mock_load: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {"id": "skill-1"}
        mock_response.is_success = True
        mock_client.post.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        result = client.post(
            "/v1/skills", json_data={"name": "my-skill"}, auth=True
        )

        assert result == {"id": "skill-1"}
        call_kwargs = mock_client.post.call_args
        assert call_kwargs.kwargs["json"] == {"name": "my-skill"}
        headers = call_kwargs.kwargs.get("headers", {})
        assert headers["Authorization"] == "Bearer token-123"

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_post_http_error_raises_api_error(
        self, mock_client_cls: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 422
        mock_response.is_success = False
        mock_response.json.return_value = {"detail": "Validation error"}
        mock_client.post.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.post("/v1/skills", json_data={}, auth=False)

        assert exc_info.value.status_code == 422


class TestAPIClientUpload:
    """Tests for APIClient.upload method."""

    @patch("agentpowers_cli.services.api_client.load_token", return_value="token-xyz")
    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_upload_sends_file(
        self, mock_client_cls: MagicMock, mock_load: MagicMock
    ) -> None:
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"url": "https://r2.example.com/f"}
        mock_response.is_success = True
        mock_client.post.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        result = client.upload(
            "/v1/skills/upload",
            file_data=b"zip-content",
            filename="skill.zip",
        )

        assert result == {"url": "https://r2.example.com/f"}
        call_kwargs = mock_client.post.call_args
        # files kwarg should have the file tuple
        files = call_kwargs.kwargs["files"]
        assert files["file"][0] == "skill.zip"
        assert files["file"][1] == b"zip-content"


# --------------- Additional coverage tests ---------------


class TestHandleResponse422Validation:
    """Tests for _handle_response with 422 validation error lists."""

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_422_validation_list_of_dicts(self, mock_client_cls: MagicMock) -> None:
        """422 with list of {msg, loc} dicts formats into readable message."""
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 422
        mock_response.is_success = False
        mock_response.json.return_value = {
            "detail": [
                {"msg": "field required", "loc": ["body", "name"]},
                {"msg": "invalid value", "loc": ["body", "price_cents"]},
            ]
        }
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.get("/v1/skills", auth=False)

        assert exc_info.value.status_code == 422
        msg = str(exc_info.value)
        assert "body.name: field required" in msg
        assert "body.price_cents: invalid value" in msg

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_422_validation_list_of_strings(self, mock_client_cls: MagicMock) -> None:
        """422 with list of plain strings formats them joined."""
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 422
        mock_response.is_success = False
        mock_response.json.return_value = {
            "detail": ["error one", "error two"]
        }
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.get("/v1/skills", auth=False)

        msg = str(exc_info.value)
        assert "error one" in msg
        assert "error two" in msg

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_422_validation_dict_without_loc(self, mock_client_cls: MagicMock) -> None:
        """422 validation dict with msg but no loc still works."""
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 422
        mock_response.is_success = False
        mock_response.json.return_value = {
            "detail": [{"msg": "something wrong"}]
        }
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.get("/v1/test", auth=False)

        assert "something wrong" in str(exc_info.value)

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_422_empty_validation_list(self, mock_client_cls: MagicMock) -> None:
        """422 with empty list falls back to 'Validation error'."""
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 422
        mock_response.is_success = False
        mock_response.json.return_value = {"detail": []}
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.get("/v1/test", auth=False)

        assert "Validation error" in str(exc_info.value)


class TestHandleResponseInvalidJSON:
    """Tests for _handle_response with invalid JSON."""

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_success_invalid_json_raises(self, mock_client_cls: MagicMock) -> None:
        """Successful response with invalid JSON body raises APIError."""
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.is_success = True
        mock_response.json.side_effect = ValueError("No JSON")
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError, match="Server returned invalid JSON"):
            client.get("/v1/test", auth=False)

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_error_invalid_json_falls_back(self, mock_client_cls: MagicMock) -> None:
        """Error response with unparseable JSON uses 'Unknown error'."""
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.is_success = False
        mock_response.json.side_effect = ValueError("No JSON")
        mock_client.get.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.get("/v1/test", auth=False)

        assert exc_info.value.status_code == 500
        assert "Unknown error" in str(exc_info.value)


class TestAPIClientPostMethod:
    """Additional tests for post() method."""

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_post_without_auth(self, mock_client_cls: MagicMock) -> None:
        """post() without auth sends no Authorization header."""
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"ok": True}
        mock_response.is_success = True
        mock_client.post.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        result = client.post("/v1/public-endpoint", json_data={"key": "val"})

        assert result == {"ok": True}
        call_kwargs = mock_client.post.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert "Authorization" not in headers

    @patch("agentpowers_cli.services.api_client.load_token", return_value=None)
    def test_post_auth_required_but_no_token(self, mock_load: MagicMock) -> None:
        """post() with auth=True but no token raises APIError."""
        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError, match="Not authenticated"):
            client.post("/v1/skills", json_data={}, auth=True)


class TestAPIClientPatch:
    """Tests for APIClient.patch method."""

    @patch("agentpowers_cli.services.api_client.load_token", return_value="patch-token")
    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_patch_with_auth(
        self, mock_client_cls: MagicMock, mock_load: MagicMock
    ) -> None:
        """patch() with auth sends Bearer token and JSON body."""
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"updated": True}
        mock_response.is_success = True
        mock_client.patch.return_value = mock_response

        client = APIClient(base_url="https://api.test.com")
        result = client.patch("/v1/users/profile", json_data={"bio": "new"}, auth=True)

        assert result == {"updated": True}
        call_kwargs = mock_client.patch.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert headers["Authorization"] == "Bearer patch-token"
        assert call_kwargs.kwargs["json"] == {"bio": "new"}


class TestRecordInstallation:
    """Tests for record_installation fire-and-forget method."""

    @patch("agentpowers_cli.services.api_client.load_token", return_value="inst-token")
    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_record_installation_with_token(
        self, mock_client_cls: MagicMock, mock_load: MagicMock
    ) -> None:
        """record_installation sends auth header when token is present."""
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_client.post.return_value = MagicMock()

        client = APIClient(base_url="https://api.test.com")
        client.record_installation("my-skill", "cli", "agentpowers", "host1")

        call_kwargs = mock_client.post.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert headers["Authorization"] == "Bearer inst-token"

    @patch("agentpowers_cli.services.api_client.load_token", return_value=None)
    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_record_installation_no_token(
        self, mock_client_cls: MagicMock, mock_load: MagicMock
    ) -> None:
        """record_installation sends no auth header when no token."""
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_client.post.return_value = MagicMock()

        client = APIClient(base_url="https://api.test.com")
        client.record_installation("my-skill", "cli", "clawhub", "host2")

        call_kwargs = mock_client.post.call_args
        headers = call_kwargs.kwargs.get("headers", {})
        assert "Authorization" not in headers

    @patch("agentpowers_cli.services.api_client.load_token", return_value=None)
    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_record_installation_swallows_exceptions(
        self, mock_client_cls: MagicMock, mock_load: MagicMock
    ) -> None:
        """record_installation never raises, even on network errors."""
        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_client.post.side_effect = Exception("network error")

        client = APIClient(base_url="https://api.test.com")
        # Should not raise
        client.record_installation("my-skill", "cli", "agentpowers", "host1")


class TestNetworkErrorTranslation:
    """Tests that httpx transport exceptions are caught and re-raised as
    APIError with a friendly message. Previously these leaked a raw
    traceback to the terminal — see QA finding
    python-cli:network:traceback-leak in reports/cli-qa-2026-04-24.
    """

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_connect_error_raises_api_error(
        self, mock_client_cls: MagicMock
    ) -> None:
        import httpx

        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_client.get.side_effect = httpx.ConnectError("DNS failure")

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.get("/v1/anything")
        assert "connect" in str(exc_info.value).lower()
        assert exc_info.value.status_code == 0

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_timeout_exception_raises_api_error(
        self, mock_client_cls: MagicMock
    ) -> None:
        import httpx

        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_client.get.side_effect = httpx.ConnectTimeout("timeout")

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.get("/v1/anything")
        assert "timed out" in str(exc_info.value).lower()
        assert exc_info.value.status_code == 0

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_connect_error_on_post_raises_api_error(
        self, mock_client_cls: MagicMock
    ) -> None:
        import httpx

        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_client.post.side_effect = httpx.ConnectError("offline")

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError):
            client.post("/v1/anything", json_data={})

    @patch("agentpowers_cli.services.api_client.httpx.Client")
    def test_generic_request_error_raises_api_error(
        self, mock_client_cls: MagicMock
    ) -> None:
        """Any other transport-layer httpx exception (e.g. SSL errors,
        protocol errors) is also wrapped rather than leaked raw."""
        import httpx

        mock_client = mock_client_cls.return_value.__enter__.return_value
        mock_client.get.side_effect = httpx.RequestError("SSL handshake failed")

        client = APIClient(base_url="https://api.test.com")
        with pytest.raises(APIError) as exc_info:
            client.get("/v1/anything")
        assert "network" in str(exc_info.value).lower()
