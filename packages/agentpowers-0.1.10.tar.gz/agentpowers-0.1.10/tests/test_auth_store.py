"""Tests for auth_store module."""

import json
from pathlib import Path
from unittest.mock import patch

from agentpowers_cli.services.auth_store import (
    delete_token,
    get_auth_dir,
    get_auth_file,
    load_token,
    save_token,
)


class TestGetAuthDir:
    """Tests for get_auth_dir."""

    def test_returns_path_ending_with_agentpowers(self) -> None:
        auth_dir = get_auth_dir()
        assert auth_dir.name == ".agentpowers"

    def test_returns_path_object(self) -> None:
        assert isinstance(get_auth_dir(), Path)


class TestGetAuthFile:
    """Tests for get_auth_file."""

    def test_returns_auth_json_path(self) -> None:
        auth_file = get_auth_file()
        assert auth_file.name == "auth.json"
        assert auth_file.parent.name == ".agentpowers"


class TestSaveToken:
    """Tests for save_token."""

    @patch("agentpowers_cli.services.auth_store.get_auth_file")
    def test_saves_token_to_json(
        self, mock_get_auth_file: object, tmp_auth_file: Path
    ) -> None:
        mock_get_auth_file.return_value = tmp_auth_file
        save_token("test-jwt-token-123")

        data = json.loads(tmp_auth_file.read_text())
        assert data["token"] == "test-jwt-token-123"

    @patch("agentpowers_cli.services.auth_store.get_auth_file")
    def test_creates_parent_directory(
        self, mock_get_auth_file: object, tmp_auth_file: Path
    ) -> None:
        mock_get_auth_file.return_value = tmp_auth_file
        assert not tmp_auth_file.parent.exists()

        save_token("token")
        assert tmp_auth_file.parent.exists()

    @patch("agentpowers_cli.services.auth_store.get_auth_file")
    def test_sets_file_permissions_to_600(
        self, mock_get_auth_file: object, tmp_auth_file: Path
    ) -> None:
        mock_get_auth_file.return_value = tmp_auth_file
        save_token("token")

        mode = oct(tmp_auth_file.stat().st_mode)[-3:]
        assert mode == "600"

    @patch("agentpowers_cli.services.auth_store.get_auth_file")
    def test_overwrites_existing_token(
        self, mock_get_auth_file: object, tmp_auth_file: Path
    ) -> None:
        mock_get_auth_file.return_value = tmp_auth_file
        save_token("old-token")
        save_token("new-token")

        data = json.loads(tmp_auth_file.read_text())
        assert data["token"] == "new-token"


class TestLoadToken:
    """Tests for load_token."""

    @patch("agentpowers_cli.services.auth_store.get_auth_file")
    def test_loads_saved_token(
        self, mock_get_auth_file: object, tmp_auth_file: Path
    ) -> None:
        mock_get_auth_file.return_value = tmp_auth_file
        tmp_auth_file.parent.mkdir(parents=True, exist_ok=True)
        tmp_auth_file.write_text(json.dumps({"token": "my-token"}))

        assert load_token() == "my-token"

    @patch("agentpowers_cli.services.auth_store.get_auth_file")
    def test_returns_none_when_file_missing(
        self, mock_get_auth_file: object, tmp_auth_file: Path
    ) -> None:
        mock_get_auth_file.return_value = tmp_auth_file
        assert load_token() is None

    @patch("agentpowers_cli.services.auth_store.get_auth_file")
    def test_returns_none_on_invalid_json(
        self, mock_get_auth_file: object, tmp_auth_file: Path
    ) -> None:
        mock_get_auth_file.return_value = tmp_auth_file
        tmp_auth_file.parent.mkdir(parents=True, exist_ok=True)
        tmp_auth_file.write_text("not json")

        assert load_token() is None


class TestDeleteToken:
    """Tests for delete_token."""

    @patch("agentpowers_cli.services.auth_store.get_auth_file")
    def test_removes_auth_file(
        self, mock_get_auth_file: object, tmp_auth_file: Path
    ) -> None:
        mock_get_auth_file.return_value = tmp_auth_file
        tmp_auth_file.parent.mkdir(parents=True, exist_ok=True)
        tmp_auth_file.write_text(json.dumps({"token": "token"}))

        delete_token()
        assert not tmp_auth_file.exists()

    @patch("agentpowers_cli.services.auth_store.get_auth_file")
    def test_no_error_when_file_missing(
        self, mock_get_auth_file: object, tmp_auth_file: Path
    ) -> None:
        mock_get_auth_file.return_value = tmp_auth_file
        delete_token()  # Should not raise
