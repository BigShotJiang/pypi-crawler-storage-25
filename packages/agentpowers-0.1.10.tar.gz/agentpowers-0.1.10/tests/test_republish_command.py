"""Tests for the republish CLI command."""

from unittest.mock import MagicMock, patch

import httpx
from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError

runner = CliRunner()


class TestRepublishCommand:

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_success(self, mock_get_client: MagicMock) -> None:
        """Confirmed republish prints success message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.return_value = {
            "slug": "my-skill",
            "name": "My Skill",
            "archived_at": "2026-01-01T00:00:00Z",
            "version": "1.0.0",
        }
        mock_client.post.return_value = {
            "slug": "my-skill",
            "archived_at": None,
            "message": "Skill republished.",
        }
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 0
        assert "republish" in result.output.lower()
        mock_client.post.assert_called_once_with(
            "/v1/skills/my-skill/republish",
            auth=True,
        )

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_shows_skill_details_before_confirm(
        self, mock_get_client: MagicMock
    ) -> None:
        """Pre-flight GET shows skill name, status, and version."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.return_value = {
            "slug": "my-skill",
            "name": "My Skill",
            "archived_at": "2026-01-01T00:00:00Z",
            "version": "2.1.0",
        }
        mock_client.post.return_value = {"message": "Skill republished."}
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 0
        assert "My Skill" in result.output
        assert "archived" in result.output.lower()
        assert "2.1.0" in result.output

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_shows_published_status(
        self, mock_get_client: MagicMock
    ) -> None:
        """Pre-flight GET shows published status when not archived."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.return_value = {
            "slug": "my-skill",
            "name": "My Skill",
            "archived_at": None,
        }
        mock_client.post.return_value = {"message": "Skill republished."}
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert "published" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_confirmation_declined(self, mock_get_client: MagicMock) -> None:
        """Declining confirmation exits non-zero so scripts can distinguish
        a user-cancelled abort from a successful republish."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.return_value = {
            "slug": "my-skill",
            "name": "My Skill",
            "archived_at": "2026-01-01T00:00:00Z",
        }
        result = runner.invoke(app, ["republish", "my-skill"], input="n\n")
        assert result.exit_code == 1
        mock_client.post.assert_not_called()
        assert "abort" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_yes_flag_skips_prompt_and_preflight(
        self, mock_get_client: MagicMock
    ) -> None:
        """--yes bypasses both the confirmation prompt AND the pre-flight
        GET (which 404s on archived skills — the bug that previously
        prevented republish from working via the CLI). The POST then
        succeeds."""
        mock_client = MagicMock()
        mock_client.post.return_value = {
            "slug": "my-skill",
            "message": "Skill re-listed.",
        }
        mock_get_client.return_value = mock_client

        result = runner.invoke(app, ["republish", "my-skill", "--yes"])
        assert result.exit_code == 0, f"stdout: {result.output}"
        # Pre-flight GET must NOT have happened when --yes is used.
        mock_client.get.assert_not_called()
        mock_client.post.assert_called_once_with(
            "/v1/skills/my-skill/republish",
            auth=True,
        )
        assert "Are you sure" not in result.output

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_default_no(self, mock_get_client: MagicMock) -> None:
        """Empty input (default N) aborts."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.return_value = {
            "slug": "my-skill",
            "name": "My Skill",
            "archived_at": "2026-01-01T00:00:00Z",
        }
        _result = runner.invoke(app, ["republish", "my-skill"], input="\n")
        mock_client.post.assert_not_called()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_401_login_prompt(self, mock_get_client: MagicMock) -> None:
        """401 error tells user to login."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.side_effect = APIError("Unauthorized", status_code=401)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "login" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_preflight_404_shows_guidance(
        self, mock_get_client: MagicMock
    ) -> None:
        """Pre-flight 404 shows helpful guidance about ap profile."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.side_effect = APIError("Skill not found", status_code=404)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "not found" in result.output.lower()
        assert "ap profile" in result.output
        assert "never been published" in result.output.lower() or "misspelled" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_preflight_403_shows_seller_message(
        self, mock_get_client: MagicMock
    ) -> None:
        """Pre-flight 403 shows clear 'belongs to another seller' message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.side_effect = APIError("Not the author", status_code=403)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "another seller" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_post_404_shows_guidance(
        self, mock_get_client: MagicMock
    ) -> None:
        """Post 404 (pre-flight succeeded but republish 404) shows guidance."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        # Pre-flight succeeds
        mock_client.get.return_value = {
            "slug": "my-skill",
            "name": "My Skill",
            "archived_at": "2026-01-01T00:00:00Z",
        }
        # But republish endpoint returns 404
        mock_client.post.side_effect = APIError("Skill not found", status_code=404)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "not found" in result.output.lower()
        assert "ap profile" in result.output

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_post_403_shows_seller_message(
        self, mock_get_client: MagicMock
    ) -> None:
        """Post 403 shows clear 'belongs to another seller' message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.return_value = {
            "slug": "my-skill",
            "name": "My Skill",
            "archived_at": "2026-01-01T00:00:00Z",
        }
        mock_client.post.side_effect = APIError("Not the author", status_code=403)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "another seller" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_409_not_archived(self, mock_get_client: MagicMock) -> None:
        """409 error shows skill is not archived message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.return_value = {
            "slug": "my-skill",
            "name": "My Skill",
            "archived_at": None,
        }
        mock_client.post.side_effect = APIError("Not archived", status_code=409)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert (
            "not archived" in result.output.lower()
            or "already published" in result.output.lower()
        )

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_generic_error(self, mock_get_client: MagicMock) -> None:
        """Unexpected status code (e.g., 500) shows generic error."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.return_value = {
            "slug": "my-skill",
            "name": "My Skill",
            "archived_at": "2026-01-01T00:00:00Z",
        }
        mock_client.post.side_effect = APIError(
            "Internal Server Error", status_code=500
        )
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "error" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_network_error_connect(self, mock_get_client: MagicMock) -> None:
        """Connection refused shows friendly network error."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        # Pre-flight network error is swallowed; confirmation still shows
        mock_client.get.side_effect = httpx.ConnectError("Connection refused")
        mock_client.post.side_effect = httpx.ConnectError("Connection refused")
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "connect" in result.output.lower() or "network" in result.output.lower()

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_network_error_timeout(self, mock_get_client: MagicMock) -> None:
        """Timeout shows friendly timeout error."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.side_effect = httpx.TimeoutException("Request timed out")
        mock_client.post.side_effect = httpx.TimeoutException("Request timed out")
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert (
            "timed out" in result.output.lower()
            or "timeout" in result.output.lower()
        )

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_429_rate_limited(self, mock_get_client: MagicMock) -> None:
        """429 rate limit shows appropriate message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get.return_value = {
            "slug": "my-skill",
            "name": "My Skill",
            "archived_at": "2026-01-01T00:00:00Z",
        }
        mock_client.post.side_effect = APIError("Rate limit exceeded", status_code=429)
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert (
            "rate" in result.output.lower()
            or "too many" in result.output.lower()
            or "try again" in result.output.lower()
        )

    def test_republish_requires_slug(self) -> None:
        """Running republish without a slug shows usage help."""
        result = runner.invoke(app, ["republish"])
        assert result.exit_code != 0

    @patch("agentpowers_cli.commands.republish.get_api_client")
    def test_republish_preflight_failure_still_allows_republish(
        self, mock_get_client: MagicMock
    ) -> None:
        """If pre-flight GET fails with unexpected error, republish still proceeds."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        # Pre-flight returns 500 — returns None, doesn't abort
        mock_client.get.side_effect = APIError("Server error", status_code=500)
        mock_client.post.return_value = {"message": "Skill republished."}
        result = runner.invoke(app, ["republish", "my-skill"], input="y\n")
        assert result.exit_code == 0
        assert "republished" in result.output.lower()
