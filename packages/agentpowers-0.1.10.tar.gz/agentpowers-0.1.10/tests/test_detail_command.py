"""Tests for the detail command."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError

runner = CliRunner()


def _make_mock_client(return_value: dict) -> MagicMock:
    """Create a mock APIClient that returns the given value from get().

    Args:
        return_value: The dict to return from client.get().

    Returns:
        A configured MagicMock.
    """
    mock_client = MagicMock()
    mock_client.get.return_value = return_value
    return mock_client


def _make_error_client(message: str, status_code: int) -> MagicMock:
    """Create a mock APIClient whose get() raises APIError.

    Args:
        message: Error message.
        status_code: HTTP status code.

    Returns:
        A configured MagicMock that raises on get().
    """
    mock_client = MagicMock()
    mock_client.get.side_effect = APIError(message, status_code=status_code)
    return mock_client


NATIVE_SKILL = {
    "slug": "code-reviewer",
    "title": "Code Reviewer",
    "type": "skill",
    "category": "dev-tools",
    "version": "2.1.0",
    "source": "agentpowers",
    "security_status": "pass",
    "price_cents": 1200,
    "download_count": 42,
    "description": "A short description.",
    "long_description": "A detailed description of the code reviewer skill.",
    "author": {"display_name": "Jane Dev"},
}

EXTERNAL_SKILL = {
    "slug": "ext-helper",
    "title": "External Helper",
    "source": "clawhub",
    "version": "1.0.0",
    "ap_security_status": "warn",
    "price_cents": 0,
    "source_url": "https://clawhub.ai/skills/ext-helper",
    "source_downloads": 300,
    "source_installs": 150,
    "source_stars": 25,
    "description": "An external skill from ClawHub.",
    "author": {"display_name": "octocat"},
}


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_native_skill(mock_get_client: MagicMock) -> None:
    """Detail for a native skill displays key fields in a panel."""
    mock_get_client.return_value = _make_mock_client(NATIVE_SKILL)

    result = runner.invoke(app, ["detail", "code-reviewer"])

    assert result.exit_code == 0
    assert "Code Reviewer" in result.output
    assert "Jane Dev" in result.output
    assert "2.1.0" in result.output
    assert "dev-tools" in result.output
    assert "skill" in result.output
    assert "agentpowers" in result.output
    assert "$12.00" in result.output
    assert "42" in result.output


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_external_skill(mock_get_client: MagicMock) -> None:
    """Detail for an external skill displays source-specific fields."""
    mock_get_client.return_value = _make_mock_client(EXTERNAL_SKILL)

    result = runner.invoke(app, ["detail", "ext-helper"])

    assert result.exit_code == 0
    assert "External Helper" in result.output
    assert "clawhub" in result.output
    assert "octocat" in result.output
    assert "https://clawhub.ai/skills/ext-helper" in result.output
    assert "150" in result.output  # source_installs
    assert "25" in result.output  # source_stars
    assert "Free" in result.output


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_not_found(mock_get_client: MagicMock) -> None:
    """404 response shows a 'not found' error and exits with code 1."""
    mock_get_client.return_value = _make_error_client("Not found", status_code=404)

    result = runner.invoke(app, ["detail", "nonexistent"])

    assert result.exit_code == 1
    assert "not found" in result.output.lower()
    assert "nonexistent" in result.output


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_with_source_flag(mock_get_client: MagicMock) -> None:
    """Passing --source includes source in API request params."""
    mock_client = _make_mock_client(EXTERNAL_SKILL)
    mock_get_client.return_value = mock_client

    result = runner.invoke(app, ["detail", "my-skill", "--source", "clawhub"])

    assert result.exit_code == 0
    call_args = mock_client.get.call_args
    params = call_args.kwargs.get("params") or call_args[1].get("params")
    assert params["source"] == "clawhub"


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_api_error(mock_get_client: MagicMock) -> None:
    """Non-404 API error exits with code 1 and shows error message."""
    mock_get_client.return_value = _make_error_client(
        "Server error", status_code=500
    )

    result = runner.invoke(app, ["detail", "broken-skill"])

    assert result.exit_code == 1
    assert "Error" in result.output


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_shows_description(mock_get_client: MagicMock) -> None:
    """Long description text appears in the panel output."""
    mock_get_client.return_value = _make_mock_client(NATIVE_SKILL)

    result = runner.invoke(app, ["detail", "code-reviewer"])

    assert result.exit_code == 0
    assert "detailed description of the code reviewer" in result.output


# ---------------------------------------------------------------------------
# Unified layout tests
# ---------------------------------------------------------------------------


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_all_fields_always_present_external(
    mock_get_client: MagicMock,
) -> None:
    """All field labels appear even when values are missing (external)."""
    mock_get_client.return_value = _make_mock_client(EXTERNAL_SKILL)

    result = runner.invoke(app, ["detail", "ext-helper"])

    assert result.exit_code == 0
    out = result.output
    # All field labels must be present
    for label in ["Author:", "Version:", "Category:", "Type:", "Source:",
                   "Security:", "Price:", "Stats:", "URL:"]:
        assert label in out, f"Missing field label: {label}"
    # Missing values show --
    assert "Category: --" in out
    assert "Type: --" in out


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_all_fields_always_present_native(
    mock_get_client: MagicMock,
) -> None:
    """All field labels appear even when values are missing (native)."""
    mock_get_client.return_value = _make_mock_client(NATIVE_SKILL)

    result = runner.invoke(app, ["detail", "code-reviewer"])

    assert result.exit_code == 0
    out = result.output
    # All field labels must be present
    for label in ["Author:", "Version:", "Category:", "Type:", "Source:",
                   "Security:", "Price:", "Stats:", "URL:"]:
        assert label in out, f"Missing field label: {label}"
    # Native skills show the AgentPowers page URL
    assert "agentpowers.ai/skills/code-reviewer" in out


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_security_on_separate_line(
    mock_get_client: MagicMock,
) -> None:
    """Security and Price are always on a separate line from identity fields."""
    mock_get_client.return_value = _make_mock_client(EXTERNAL_SKILL)

    result = runner.invoke(app, ["detail", "ext-helper"])

    assert result.exit_code == 0
    lines = result.output.splitlines()
    source_line = next(
        (i for i, line in enumerate(lines) if "Source:" in line), None
    )
    security_line = next(
        (i for i, line in enumerate(lines) if "Security:" in line), None
    )
    assert source_line is not None
    assert security_line is not None
    assert security_line != source_line


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_stats_always_present(mock_get_client: MagicMock) -> None:
    """Stats line always present with Downloads, Source Installs, Stars."""
    mock_get_client.return_value = _make_mock_client(EXTERNAL_SKILL)

    result = runner.invoke(app, ["detail", "ext-helper"])

    assert result.exit_code == 0
    assert "Downloads: 300" in result.output
    assert "Source Installs: 150" in result.output
    assert "Stars: 25" in result.output


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_stats_native_shows_downloads(
    mock_get_client: MagicMock,
) -> None:
    """Native items show downloads but omit missing source fields."""
    mock_get_client.return_value = _make_mock_client(NATIVE_SKILL)

    result = runner.invoke(app, ["detail", "code-reviewer"])

    assert result.exit_code == 0
    assert "Downloads: 42" in result.output
    # Source fields not present for native skills
    assert "Source Installs" not in result.output
    assert "Stars" not in result.output


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_stats_native_with_view_and_install_counts(
    mock_get_client: MagicMock,
) -> None:
    """Native skills with view_count/install_count show those stats."""
    skill_with_counts = {
        **NATIVE_SKILL,
        "view_count": 500,
        "install_count": 120,
    }
    mock_get_client.return_value = _make_mock_client(skill_with_counts)

    result = runner.invoke(app, ["detail", "code-reviewer"])

    assert result.exit_code == 0
    assert "Views: 500" in result.output
    assert "Installs: 120" in result.output


# ---------------------------------------------------------------------------
# Scan-related tests (--scan flag)
# ---------------------------------------------------------------------------

SAMPLE_RESULT_PASS = {
    "content_hash": "sha256:abc123",
    "security_status": "pass",
    "security_score": 0,
    "findings": [],
    "layers": [
        {"name": "File Type Validation", "status": "pass", "findings": []},
        {"name": "Pattern Scanning", "status": "pass", "findings": []},
    ],
}

SAMPLE_RESULT_WITH_FINDINGS = {
    "content_hash": "sha256:abc123",
    "security_status": "warn",
    "security_score": 3,
    "findings": [],
    "layers": [
        {
            "name": "Pattern Scanning",
            "status": "fail",
            "findings": [
                {
                    "category": "env_harvesting",
                    "detail": (
                        "Shell variable referencing"
                        " sensitive env var in config.sh"
                    ),
                    "severity": "MEDIUM",
                    "match": "$API_KEY",
                    "file": "config.sh",
                    "line": 5,
                    "context": [
                        {"line": 3, "text": "# Setup env"},
                        {"line": 4, "text": "export DB_HOST=localhost"},
                        {
                            "line": 5,
                            "text": 'curl -H "Auth: $API_KEY" https://api.com',
                            "highlight": True,
                        },
                        {"line": 6, "text": "echo done"},
                    ],
                    "explanation": (
                        "Accessing environment variables that hold"
                        " secrets could allow credential exfiltration."
                    ),
                }
            ],
        },
    ],
}

SAMPLE_RESULT_BLOCKED = {
    "content_hash": "sha256:bad",
    "security_status": "block",
    "security_score": 8,
    "findings": [
        {
            "category": "disallowed_file_type",
            "detail": "File not allowed: payload.exe",
            "severity": "HIGH",
            "file": "payload.exe",
            "explanation": "Only .json, .md, .txt, .yaml, .yml files are allowed.",
        }
    ],
    "layers": [],
}


@patch("agentpowers_cli.commands.detail.shutil")
@patch("agentpowers_cli.commands.detail._upload_for_scan")
@patch("agentpowers_cli.commands.detail._download_to_sandbox")
@patch("agentpowers_cli.commands.detail._resolve_source")
@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_with_scan_flag_pass(
    mock_client_fn, mock_resolve, mock_download, mock_upload, mock_shutil
) -> None:
    """ap detail slug --scan shows metadata + 'No security findings'."""
    mock_client_fn.return_value = _make_mock_client(EXTERNAL_SKILL)
    mock_resolve.return_value = "clawhub"
    mock_download.return_value = ("/tmp/sandbox", "clawhub")
    mock_upload.return_value = SAMPLE_RESULT_PASS

    result = runner.invoke(app, ["detail", "ext-helper", "--scan"])

    assert result.exit_code == 0
    # Metadata panel rendered
    assert "External Helper" in result.output
    # Scan results rendered
    assert "PASS" in result.output
    assert "No security findings" in result.output


@patch("agentpowers_cli.commands.detail.shutil")
@patch("agentpowers_cli.commands.detail._upload_for_scan")
@patch("agentpowers_cli.commands.detail._download_to_sandbox")
@patch("agentpowers_cli.commands.detail._resolve_source")
@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_with_scan_flag_findings(
    mock_client_fn, mock_resolve, mock_download, mock_upload, mock_shutil
) -> None:
    """--scan with findings shows code context, severity, explanation."""
    mock_client_fn.return_value = _make_mock_client(EXTERNAL_SKILL)
    mock_resolve.return_value = "clawhub"
    mock_download.return_value = ("/tmp/sandbox", "clawhub")
    mock_upload.return_value = SAMPLE_RESULT_WITH_FINDINGS

    result = runner.invoke(app, ["detail", "ext-helper", "--scan"])

    assert result.exit_code == 0
    assert "config.sh" in result.output
    assert "MEDIUM" in result.output
    assert "5" in result.output  # Line number
    assert "Why" in result.output
    assert (
        "credential" in result.output.lower()
        or "exfiltration" in result.output.lower()
    )


@patch("agentpowers_cli.commands.detail.shutil")
@patch("agentpowers_cli.commands.detail._upload_for_scan")
@patch("agentpowers_cli.commands.detail._download_to_sandbox")
@patch("agentpowers_cli.commands.detail._resolve_source")
@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_with_scan_flag_blocked_exits_1(
    mock_client_fn, mock_resolve, mock_download, mock_upload, mock_shutil
) -> None:
    """Blocked scan exits with code 1."""
    mock_client_fn.return_value = _make_mock_client(EXTERNAL_SKILL)
    mock_resolve.return_value = "clawhub"
    mock_download.return_value = ("/tmp/sandbox", "clawhub")
    mock_upload.return_value = SAMPLE_RESULT_BLOCKED

    result = runner.invoke(app, ["detail", "ext-helper", "--scan"])

    assert result.exit_code == 1
    assert "BLOCK" in result.output


@patch("agentpowers_cli.commands.detail._resolve_source")
@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_scan_not_found_exits_1(mock_client_fn, mock_resolve) -> None:
    """--scan with unresolvable source exits 1."""
    mock_client_fn.return_value = _make_mock_client(EXTERNAL_SKILL)
    mock_resolve.return_value = None

    result = runner.invoke(app, ["detail", "no-source-skill", "--scan"])

    assert result.exit_code == 1
    assert "not found" in result.output.lower()


@patch("agentpowers_cli.commands.detail.shutil")
@patch("agentpowers_cli.commands.detail._upload_for_scan")
@patch("agentpowers_cli.commands.detail._download_to_sandbox")
@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_scan_explicit_source(
    mock_client_fn, mock_download, mock_upload, mock_shutil
) -> None:
    """--scan --source clawhub skips resolve and uses provided source."""
    mock_client_fn.return_value = _make_mock_client(EXTERNAL_SKILL)
    mock_download.return_value = ("/tmp/sandbox", "clawhub")
    mock_upload.return_value = SAMPLE_RESULT_PASS

    result = runner.invoke(
        app, ["detail", "ext-helper", "--scan", "--source", "clawhub"]
    )

    assert result.exit_code == 0
    # _resolve_source is NOT patched, so if it were called, it would fail.
    # The fact that we pass means resolve was skipped.


@patch("agentpowers_cli.commands.detail.shutil")
@patch("agentpowers_cli.commands.detail._upload_for_scan")
@patch("agentpowers_cli.commands.detail._download_to_sandbox")
@patch("agentpowers_cli.commands.detail._resolve_source")
@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_scan_sandbox_cleanup(
    mock_client_fn, mock_resolve, mock_download, mock_upload, mock_shutil
) -> None:
    """Sandbox rmtree called in finally block."""
    mock_client_fn.return_value = _make_mock_client(EXTERNAL_SKILL)
    mock_resolve.return_value = "clawhub"
    mock_download.return_value = ("/tmp/ap-scan-xyz", "clawhub")
    mock_upload.return_value = SAMPLE_RESULT_PASS

    runner.invoke(app, ["detail", "ext-helper", "--scan"])

    mock_shutil.rmtree.assert_called_once_with(
        "/tmp/ap-scan-xyz", ignore_errors=True
    )


@patch("agentpowers_cli.commands.detail.shutil")
@patch("agentpowers_cli.commands.detail._download_to_sandbox")
@patch("agentpowers_cli.commands.detail._resolve_source")
@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_scan_download_failure(
    mock_client_fn, mock_resolve, mock_download, mock_shutil
) -> None:
    """Download error shows message and exits 1."""
    mock_client_fn.return_value = _make_mock_client(EXTERNAL_SKILL)
    mock_resolve.return_value = "clawhub"
    mock_download.side_effect = RuntimeError("npx failed")

    result = runner.invoke(app, ["detail", "ext-helper", "--scan"])

    assert result.exit_code == 1
    assert "Download failed" in result.output


# ---------------------------------------------------------------------------
# Additional coverage tests
# ---------------------------------------------------------------------------


class TestFormatSecurity:
    """Tests for _format_security helper."""

    def test_format_security_none(self) -> None:
        """None returns 'not scanned'."""
        from agentpowers_cli.commands.detail import _format_security

        assert _format_security(None) == "not scanned"

    def test_format_security_empty_string(self) -> None:
        """Empty string returns 'not scanned'."""
        from agentpowers_cli.commands.detail import _format_security

        assert _format_security("") == "not scanned"

    def test_format_security_pass(self) -> None:
        """'pass' returns green markup."""
        from agentpowers_cli.commands.detail import _format_security

        result = _format_security("pass")
        assert "green" in result
        assert "pass" in result

    def test_format_security_warn(self) -> None:
        """'warn' returns yellow markup."""
        from agentpowers_cli.commands.detail import _format_security

        result = _format_security("warn")
        assert "yellow" in result

    def test_format_security_block(self) -> None:
        """'block' returns red markup."""
        from agentpowers_cli.commands.detail import _format_security

        result = _format_security("block")
        assert "red" in result

    def test_format_security_unknown(self) -> None:
        """Unknown status returns raw string."""
        from agentpowers_cli.commands.detail import _format_security

        assert _format_security("pending") == "pending"


class TestSeverityStyle:
    """Tests for _severity_style helper."""

    def test_high(self) -> None:
        from agentpowers_cli.commands.detail import _severity_style

        assert _severity_style("HIGH") == "bold red"

    def test_medium(self) -> None:
        from agentpowers_cli.commands.detail import _severity_style

        assert _severity_style("MEDIUM") == "bold yellow"

    def test_low(self) -> None:
        from agentpowers_cli.commands.detail import _severity_style

        assert _severity_style("LOW") == "dim yellow"

    def test_info(self) -> None:
        from agentpowers_cli.commands.detail import _severity_style

        assert _severity_style("INFO") == "dim"

    def test_unknown(self) -> None:
        from agentpowers_cli.commands.detail import _severity_style

        assert _severity_style("OTHER") == "dim"


class TestRenderFindingCard:
    """Tests for _render_finding_card helper."""

    def test_finding_with_line_number_no_context(self) -> None:
        """Finding with line number but no context shows 'Line N'."""
        from agentpowers_cli.commands.detail import _render_finding_card

        finding = {
            "severity": "MEDIUM",
            "detail": "Some issue",
            "file": "test.py",
            "line": 42,
            "context": [],
        }
        panel = _render_finding_card(finding)
        content = panel.renderable
        assert "Line 42" in content

    def test_finding_no_file_uses_category(self) -> None:
        """Finding without file uses category as panel title."""
        from agentpowers_cli.commands.detail import _render_finding_card

        finding = {
            "severity": "LOW",
            "detail": "Minor issue",
            "category": "env_harvesting",
        }
        panel = _render_finding_card(finding)
        assert panel.title == "env_harvesting"

    def test_finding_with_virustotal_timeout(self) -> None:
        """VirusTotal timeout detail is cleaned up."""
        from agentpowers_cli.commands.detail import _render_finding_card

        finding = {
            "severity": "INFO",
            "detail": "Analysis xyz123 did not complete within 60s",
        }
        panel = _render_finding_card(finding)
        content = panel.renderable
        assert "timed out" in content
        assert "non-blocking" in content

    def test_finding_with_context_highlights(self) -> None:
        """Finding with context includes highlighted lines."""
        from agentpowers_cli.commands.detail import _render_finding_card

        finding = {
            "severity": "HIGH",
            "detail": "Dangerous pattern",
            "file": "script.sh",
            "context": [
                {"line": 1, "text": "echo hello"},
                {"line": 2, "text": "rm -rf /", "highlight": True},
                {"line": 3, "text": "echo done"},
            ],
            "match": "rm -rf /",
            "explanation": "Deletes filesystem",
        }
        panel = _render_finding_card(finding)
        content = panel.renderable
        assert "Matched" in content
        assert "Why" in content


class TestDetailScanUploadFailure:
    """Tests for scan upload failure in detail --scan."""

    @patch("agentpowers_cli.commands.detail.shutil")
    @patch("agentpowers_cli.commands.detail._upload_for_scan")
    @patch("agentpowers_cli.commands.detail._download_to_sandbox")
    @patch("agentpowers_cli.commands.detail._resolve_source")
    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_detail_scan_upload_failure_exits_1(
        self, mock_client_fn, mock_resolve, mock_download, mock_upload, mock_shutil
    ) -> None:
        """Upload/scan failure shows error and exits 1."""
        mock_client_fn.return_value = _make_mock_client(EXTERNAL_SKILL)
        mock_resolve.return_value = "clawhub"
        mock_download.return_value = ("/tmp/sandbox", "clawhub")
        mock_upload.side_effect = RuntimeError("Scan pipeline unavailable")

        result = runner.invoke(app, ["detail", "ext-helper", "--scan"])

        assert result.exit_code == 1
        assert "Scan failed" in result.output


class TestDetailFindingsGrouping:
    """Tests for findings grouped by file and no-file findings."""

    @patch("agentpowers_cli.commands.detail.shutil")
    @patch("agentpowers_cli.commands.detail._upload_for_scan")
    @patch("agentpowers_cli.commands.detail._download_to_sandbox")
    @patch("agentpowers_cli.commands.detail._resolve_source")
    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_detail_scan_findings_no_file_association(
        self, mock_client_fn, mock_resolve, mock_download, mock_upload, mock_shutil
    ) -> None:
        """Findings without file association are still displayed."""
        mock_client_fn.return_value = _make_mock_client(EXTERNAL_SKILL)
        mock_resolve.return_value = "clawhub"
        mock_download.return_value = ("/tmp/sandbox", "clawhub")

        result_data = {
            "content_hash": "sha256:abc",
            "security_status": "warn",
            "security_score": 2,
            "findings": [
                {
                    "category": "suspicious_pattern",
                    "detail": "Unusual network activity",
                    "severity": "MEDIUM",
                }
            ],
            "layers": [],
        }
        mock_upload.return_value = result_data

        result = runner.invoke(app, ["detail", "ext-helper", "--scan"])

        assert result.exit_code == 0
        assert "MEDIUM" in result.output
        assert "Unusual network activity" in result.output


class TestDetailURLDisplay:
    """Tests for URL display logic."""

    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_native_skill_shows_agentpowers_url(
        self, mock_get_client: MagicMock
    ) -> None:
        """Native skills show https://agentpowers.ai/skills/{slug}."""
        mock_get_client.return_value = _make_mock_client(NATIVE_SKILL)

        result = runner.invoke(app, ["detail", "code-reviewer"])

        assert result.exit_code == 0
        assert "https://agentpowers.ai/skills/code-reviewer" in result.output

    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_external_skill_shows_source_url(
        self, mock_get_client: MagicMock
    ) -> None:
        """External skills show source_url from API response."""
        mock_get_client.return_value = _make_mock_client(EXTERNAL_SKILL)

        result = runner.invoke(app, ["detail", "ext-helper"])

        assert result.exit_code == 0
        assert "https://clawhub.ai/skills/ext-helper" in result.output

    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_no_platforms_row(self, mock_get_client: MagicMock) -> None:
        """Platforms row should not appear in output."""
        mock_get_client.return_value = _make_mock_client(NATIVE_SKILL)

        result = runner.invoke(app, ["detail", "code-reviewer"])

        assert result.exit_code == 0
        assert "Platforms:" not in result.output


class TestDetailAuthorDisplay:
    """Tests for author display from nested author object."""

    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_author_from_nested_object(self, mock_get_client: MagicMock) -> None:
        """Author display_name is extracted from nested author object."""
        skill = {
            **NATIVE_SKILL,
            "author": {"display_name": "Nested Author"},
        }
        mock_get_client.return_value = _make_mock_client(skill)

        result = runner.invoke(app, ["detail", "code-reviewer"])

        assert result.exit_code == 0
        assert "Nested Author" in result.output

    @patch("agentpowers_cli.commands.detail.get_api_client")
    def test_author_fallback_to_flat_fields(
        self, mock_get_client: MagicMock
    ) -> None:
        """Falls back to author_display_name when author is not a dict."""
        skill = dict(NATIVE_SKILL)
        skill.pop("author", None)
        skill["author_display_name"] = "Flat Author"
        mock_get_client.return_value = _make_mock_client(skill)

        result = runner.invoke(app, ["detail", "code-reviewer"])

        assert result.exit_code == 0
        assert "Flat Author" in result.output


# ---------------------------------------------------------------------------
# Security detail display tests
# ---------------------------------------------------------------------------


WARN_SKILL_WITH_FINDINGS = {
    "slug": "sketchy-tool",
    "title": "Sketchy Tool",
    "type": "skill",
    "category": "dev-tools",
    "version": "1.0.0",
    "source": "agentpowers",
    "security_status": "warn",
    "security_score": 4,
    "security_findings": [
        {
            "severity": "MEDIUM",
            "detail": "Accesses sensitive environment variables",
        },
        {
            "severity": "LOW",
            "detail": "Uses network calls without validation",
        },
    ],
    "price_cents": 0,
    "description": "A tool with warnings.",
    "author": {"display_name": "Suspect Dev"},
}

BLOCK_SKILL_WITH_FINDINGS = {
    "slug": "bad-actor",
    "title": "Bad Actor",
    "type": "skill",
    "category": "security",
    "version": "0.1.0",
    "source": "agentpowers",
    "security_status": "block",
    "security_score": 9,
    "security_findings": [
        {
            "severity": "HIGH",
            "detail": "Attempts to exfiltrate credentials",
        },
    ],
    "price_cents": 0,
    "description": "A blocked skill.",
    "author": {"display_name": "Bad Guy"},
}

WARN_SKILL_NO_FINDINGS = {
    "slug": "mild-warn",
    "title": "Mild Warn",
    "type": "skill",
    "version": "1.0.0",
    "source": "agentpowers",
    "security_status": "warn",
    "price_cents": 0,
    "description": "Warn but no findings list.",
    "author": {"display_name": "Someone"},
}

EXTERNAL_WARN_SKILL = {
    "slug": "ext-warn",
    "title": "External Warn",
    "source": "clawhub",
    "version": "1.0.0",
    "ap_security_status": "warn",
    "ap_security_score": 3,
    "security_findings": [
        {
            "severity": "MEDIUM",
            "detail": "Suspicious pattern detected",
        },
    ],
    "price_cents": 0,
    "description": "External skill with warnings.",
    "author": {"display_name": "ext-author"},
}


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_warn_shows_score_and_findings(
    mock_get_client: MagicMock,
) -> None:
    """Warn status displays security score and individual findings."""
    mock_get_client.return_value = _make_mock_client(WARN_SKILL_WITH_FINDINGS)

    result = runner.invoke(app, ["detail", "sketchy-tool"])

    assert result.exit_code == 0
    assert "Security Score: 4/10" in result.output
    assert "Findings (2)" in result.output
    assert "Accesses sensitive environment variables" in result.output
    assert "Uses network calls without validation" in result.output
    assert "MEDIUM" in result.output
    assert "LOW" in result.output


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_block_shows_score_and_findings(
    mock_get_client: MagicMock,
) -> None:
    """Block status displays security score and findings in red."""
    mock_get_client.return_value = _make_mock_client(BLOCK_SKILL_WITH_FINDINGS)

    result = runner.invoke(app, ["detail", "bad-actor"])

    assert result.exit_code == 0
    assert "Security Score: 9/10" in result.output
    assert "Findings (1)" in result.output
    assert "Attempts to exfiltrate credentials" in result.output
    assert "HIGH" in result.output


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_warn_no_findings_shows_scan_hint(
    mock_get_client: MagicMock,
) -> None:
    """Warn without findings list shows hint to use --scan."""
    mock_get_client.return_value = _make_mock_client(WARN_SKILL_NO_FINDINGS)

    result = runner.invoke(app, ["detail", "mild-warn"])

    assert result.exit_code == 0
    assert "security warnings" in result.output
    assert "--scan" in result.output


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_block_no_findings_shows_scan_hint(
    mock_get_client: MagicMock,
) -> None:
    """Block without findings list shows hint to use --scan."""
    skill = {
        **WARN_SKILL_NO_FINDINGS,
        "security_status": "block",
    }
    mock_get_client.return_value = _make_mock_client(skill)

    result = runner.invoke(app, ["detail", "mild-warn"])

    assert result.exit_code == 0
    assert "blocked due to security issues" in result.output
    assert "--scan" in result.output


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_external_warn_shows_ap_score(
    mock_get_client: MagicMock,
) -> None:
    """External skill with ap_security_status/ap_security_score shows details."""
    mock_get_client.return_value = _make_mock_client(EXTERNAL_WARN_SKILL)

    result = runner.invoke(app, ["detail", "ext-warn"])

    assert result.exit_code == 0
    assert "Security Score: 3/10" in result.output
    assert "Suspicious pattern detected" in result.output


@patch("agentpowers_cli.commands.detail.get_api_client")
def test_detail_pass_no_extra_security_section(
    mock_get_client: MagicMock,
) -> None:
    """Pass status does not show expanded security details."""
    mock_get_client.return_value = _make_mock_client(NATIVE_SKILL)

    result = runner.invoke(app, ["detail", "code-reviewer"])

    assert result.exit_code == 0
    assert "Security Score" not in result.output
    assert "Findings" not in result.output
    assert "security warnings" not in result.output


class TestGetApiClient:
    """Test the get_api_client factory."""

    def test_get_api_client_returns_api_client(self) -> None:
        from agentpowers_cli.commands.detail import get_api_client

        client = get_api_client()
        assert client is not None
