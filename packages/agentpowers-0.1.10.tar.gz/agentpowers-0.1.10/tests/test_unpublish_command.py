"""Tests for the unpublish CLI command."""

from unittest.mock import MagicMock, patch

import httpx
from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError

runner = CliRunner()


class TestUnpublishCommand:

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_success(self, mock_get_client: MagicMock) -> None:
        """Confirmed unpublish prints success message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.return_value = {
            "slug": "my-skill",
            "archived_at": "2026-03-02T00:00:00",
            "message": "Skill unpublished.",
        }
        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code == 0
        assert (
            "unpublish" in result.output.lower()
            or "archived" in result.output.lower()
        )
        mock_client.post.assert_called_once_with(
            "/v1/skills/my-skill/unpublish",
            auth=True,
        )

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_confirmation_declined(self, mock_get_client: MagicMock) -> None:
        """Declining confirmation exits non-zero so scripts can distinguish
        a user-cancelled abort from a successful unpublish."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        result = runner.invoke(app, ["unpublish", "my-skill"], input="n\n")
        assert result.exit_code == 1
        mock_client.post.assert_not_called()
        assert "abort" in result.output.lower() or "cancel" in result.output.lower()

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_yes_flag_skips_prompt(
        self, mock_get_client: MagicMock
    ) -> None:
        """--yes bypasses the prompt so scripts/CI can unpublish non-
        interactively (e.g. during QA teardown)."""
        mock_client = MagicMock()
        mock_client.post.return_value = {"message": "Skill unpublished."}
        mock_get_client.return_value = mock_client
        result = runner.invoke(app, ["unpublish", "my-skill", "--yes"])
        assert result.exit_code == 0, f"stdout: {result.output}"
        mock_client.post.assert_called_once_with(
            "/v1/skills/my-skill/unpublish",
            auth=True,
        )
        assert "Are you sure" not in result.output

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_default_no(self, mock_get_client: MagicMock) -> None:
        """Empty input (default N) aborts."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        _result = runner.invoke(app, ["unpublish", "my-skill"], input="\n")
        mock_client.post.assert_not_called()

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_401_login_prompt(self, mock_get_client: MagicMock) -> None:
        """401 error tells user to login."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Unauthorized", status_code=401)
        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "login" in result.output.lower()

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_404_not_found(self, mock_get_client: MagicMock) -> None:
        """404 error shows not found message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Skill not found", status_code=404)
        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_403_not_owner(self, mock_get_client: MagicMock) -> None:
        """403 error shows not owner message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Not the author", status_code=403)
        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "owner" in result.output.lower() or "author" in result.output.lower()

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_409_already_archived(self, mock_get_client: MagicMock) -> None:
        """409 error shows already archived message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Already archived", status_code=409)
        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "already" in result.output.lower()

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_generic_error(self, mock_get_client: MagicMock) -> None:
        """Unexpected status code (e.g., 500) shows generic error."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError(
            "Internal Server Error", status_code=500
        )
        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "error" in result.output.lower()

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_network_error_connect(self, mock_get_client: MagicMock) -> None:
        """Connection refused shows friendly network error."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = httpx.ConnectError("Connection refused")
        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert "connect" in result.output.lower() or "network" in result.output.lower()

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_network_error_timeout(self, mock_get_client: MagicMock) -> None:
        """Timeout shows friendly timeout error."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = httpx.TimeoutException("Request timed out")
        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert (
            "timed out" in result.output.lower()
            or "timeout" in result.output.lower()
        )

    @patch("agentpowers_cli.commands.unpublish.get_api_client")
    def test_unpublish_429_rate_limited(self, mock_get_client: MagicMock) -> None:
        """429 rate limit shows appropriate message."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.post.side_effect = APIError("Rate limit exceeded", status_code=429)
        result = runner.invoke(app, ["unpublish", "my-skill"], input="y\n")
        assert result.exit_code == 1
        assert (
            "rate" in result.output.lower()
            or "too many" in result.output.lower()
            or "try again" in result.output.lower()
        )

    def test_unpublish_requires_slug(self) -> None:
        """Running unpublish without a slug shows usage help."""
        result = runner.invoke(app, ["unpublish"])
        assert result.exit_code != 0
