"""Tests for the publish command upsert (create or update) behavior."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from agentpowers_cli.main import app
from agentpowers_cli.services.api_client import APIError

runner = CliRunner()

_SKILL_META = {
    "name": "test-skill",
    "description": "A test skill for testing",
    "type": "skill",
}

_AGENT_META = {
    "name": "test-agent",
    "description": "A test agent for testing",
    "type": "agent",
}


class TestPublishFirstTime:
    """Tests for first-time publish (POST succeeds)."""

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_first_publish_success(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """First publish creates skill and uploads package."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.return_value = {
            "slug": "test-skill", "id": "s1", "status": "pending"
        }
        client.upload.return_value = {"slug": "test-skill", "storage_key": "key"}

        result = runner.invoke(app, ["publish", "--dir", "/tmp/fake"])

        assert result.exit_code == 0
        assert "Published" in result.output
        assert "test-skill" in result.output
        client.post.assert_called_once()
        client.upload.assert_called_once()
        # No patch call on first publish
        client.patch.assert_not_called()

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_first_publish_agent_type(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """First publish with agent type sends correct type field."""
        mock_metadata.return_value = _AGENT_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.return_value = {"slug": "test-agent", "id": "s2"}
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(app, ["publish", "--dir", "/tmp/fake"])

        assert result.exit_code == 0
        post_kwargs = client.post.call_args
        assert post_kwargs[1]["json_data"]["type"] == "agent"


class TestPublishUpsert:
    """Tests for upsert behavior (POST returns 409 -> PATCH)."""

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_upsert_with_bump(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """Re-publish triggers PATCH with bump and uploads with version param."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.side_effect = APIError("slug taken", status_code=409)
        client.patch.return_value = {
            "slug": "test-skill",
            "previous_version": "1.0.0",
            "new_version": "1.0.1",
            "version_id": "v1",
            "status": "pending",
            "message": "ok",
        }
        client.upload.return_value = {"slug": "test-skill", "storage_key": "key"}

        result = runner.invoke(app, ["publish", "--dir", "/tmp/fake"])

        assert result.exit_code == 0
        assert "Updated" in result.output
        assert "1.0.1" in result.output
        client.patch.assert_called_once()
        # Upload path should include version query param
        upload_call = client.upload.call_args
        assert "version=1.0.1" in upload_call[1].get("path", upload_call[0][0])

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_upsert_with_explicit_version(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """Re-publish with --version sends explicit version in PATCH."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.side_effect = APIError("slug taken", status_code=409)
        client.patch.return_value = {
            "slug": "test-skill",
            "new_version": "2.0.0",
            "version_id": "v2",
            "status": "pending",
        }
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(
            app, ["publish", "--dir", "/tmp/fake", "--version", "2.0.0"]
        )

        assert result.exit_code == 0
        patch_kwargs = client.patch.call_args
        assert patch_kwargs[1]["json_data"]["version"] == "2.0.0"


class TestPublishUpdateErrors:
    """Tests for update error handling (PATCH failures)."""

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_update_403_not_author(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """PATCH returning 403 shows 'not the author' error."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.side_effect = APIError("slug taken", status_code=409)
        client.patch.side_effect = APIError("SKILL_NOT_OWNER", status_code=403)

        result = runner.invoke(app, ["publish", "--dir", "/tmp/fake"])

        assert result.exit_code == 1
        assert "not the author" in result.output

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_update_409_archived(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """PATCH returning 409 with SKILL_ARCHIVED shows archived error."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.side_effect = APIError("slug taken", status_code=409)
        client.patch.side_effect = APIError("SKILL_ARCHIVED", status_code=409)

        result = runner.invoke(app, ["publish", "--dir", "/tmp/fake"])

        assert result.exit_code == 1
        assert "archived" in result.output.lower()
        assert "republish" in result.output.lower()

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_update_409_pending_version(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """PATCH returning 409 with SKILL_VERSION_PENDING shows pending error."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.side_effect = APIError("slug taken", status_code=409)
        client.patch.side_effect = APIError("SKILL_VERSION_PENDING", status_code=409)

        result = runner.invoke(app, ["publish", "--dir", "/tmp/fake"])

        assert result.exit_code == 1
        assert "pending scan" in result.output.lower()


class TestPublishPriceFlag:
    """Tests for the --price flag on publish and upsert."""

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_first_publish_with_price_sends_correct_cents(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """ap publish --price 3.00 sends price_cents=300 in POST body."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.return_value = {"slug": "test-skill", "id": "s1"}
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(
            app, ["publish", "--dir", "/tmp/fake", "--price", "3.00"]
        )

        assert result.exit_code == 0
        post_kwargs = client.post.call_args
        assert post_kwargs[1]["json_data"]["price_cents"] == 300

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_first_publish_with_high_price(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """ap publish --price 5.99 sends price_cents=599."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.return_value = {"slug": "test-skill", "id": "s1"}
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(
            app, ["publish", "--dir", "/tmp/fake", "--price", "5.99"]
        )

        assert result.exit_code == 0
        post_kwargs = client.post.call_args
        assert post_kwargs[1]["json_data"]["price_cents"] == 599

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_default_price_sends_zero(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """ap publish without --price sends price_cents=0."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.return_value = {"slug": "test-skill", "id": "s1"}
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(app, ["publish", "--dir", "/tmp/fake"])

        assert result.exit_code == 0
        post_kwargs = client.post.call_args
        assert post_kwargs[1]["json_data"]["price_cents"] == 0

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_upsert_with_price_sends_in_patch(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """ap publish --price 5.99 on existing skill sends price_cents=599 in PATCH."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.side_effect = APIError("slug taken", status_code=409)
        client.patch.return_value = {
            "slug": "test-skill",
            "previous_version": "1.0.0",
            "new_version": "1.0.1",
            "version_id": "v1",
            "status": "pending",
        }
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(
            app, ["publish", "--dir", "/tmp/fake", "--price", "5.99"]
        )

        assert result.exit_code == 0
        patch_kwargs = client.patch.call_args
        assert patch_kwargs[1]["json_data"]["price_cents"] == 599

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_upsert_without_price_omits_price_from_patch(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """ap publish without --price omits price_cents from PATCH."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.side_effect = APIError("slug taken", status_code=409)
        client.patch.return_value = {
            "slug": "test-skill",
            "new_version": "1.0.1",
            "version_id": "v1",
        }
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(app, ["publish", "--dir", "/tmp/fake"])

        assert result.exit_code == 0
        patch_kwargs = client.patch.call_args
        # price_cents should NOT be in the PATCH body when --price not specified
        assert "price_cents" not in patch_kwargs[1]["json_data"]

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_upsert_with_explicit_zero_price_sends_zero(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """ap publish --price 0 explicitly sends price_cents=0 (switch to free)."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.side_effect = APIError("slug taken", status_code=409)
        client.patch.return_value = {
            "slug": "test-skill",
            "new_version": "1.0.1",
            "version_id": "v1",
        }
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(app, ["publish", "--dir", "/tmp/fake", "--price", "0"])

        assert result.exit_code == 0
        patch_kwargs = client.patch.call_args
        assert patch_kwargs[1]["json_data"]["price_cents"] == 0

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_upsert_with_price_and_bump(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """ap publish --price 9.99 --bump minor sends both in PATCH."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.side_effect = APIError("slug taken", status_code=409)
        client.patch.return_value = {
            "slug": "test-skill",
            "new_version": "1.1.0",
            "version_id": "v2",
        }
        client.upload.return_value = {"status": "ok"}

        result = runner.invoke(
            app,
            ["publish", "--dir", "/tmp/fake", "--price", "9.99", "--bump", "minor"],
        )

        assert result.exit_code == 0
        patch_kwargs = client.patch.call_args
        assert patch_kwargs[1]["json_data"]["price_cents"] == 999
        assert patch_kwargs[1]["json_data"]["bump"] == "minor"

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_publish_422_from_server_shows_validation_error(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """Server rejecting invalid price (422) shows validation error in CLI."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.side_effect = APIError("slug taken", status_code=409)
        client.patch.side_effect = APIError(
            "Paid skills must be at least $3.00", status_code=422
        )

        result = runner.invoke(
            app, ["publish", "--dir", "/tmp/fake", "--price", "0.01"]
        )

        assert result.exit_code == 1
        assert "Validation error" in result.output


class TestPublishValidation:
    """Tests for input validation before API calls."""

    @patch("agentpowers_cli.commands.publish.load_skill_metadata", return_value=None)
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_no_skill_metadata_found(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
    ) -> None:
        """Missing metadata file exits with code 1."""
        result = runner.invoke(app, ["publish", "--dir", "/tmp/empty"])

        assert result.exit_code == 1
        assert "No skill found" in result.output
        mock_client_fn.return_value.post.assert_not_called()

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_version_and_bump_conflict(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """Using both --version and --bump (non-default) exits with error."""
        mock_metadata.return_value = _SKILL_META.copy()

        result = runner.invoke(
            app,
            ["publish", "--dir", "/tmp/fake", "--version", "2.0.0", "--bump", "minor"],
        )

        assert result.exit_code == 1
        assert "Cannot use --bump and --version together" in result.output
        mock_client_fn.return_value.post.assert_not_called()

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_upload_failure(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """Upload failure shows error and exits with code 1."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.return_value = {"slug": "test-skill"}
        client.upload.side_effect = APIError(
            "Upload failed: storage error", status_code=500
        )

        result = runner.invoke(app, ["publish", "--dir", "/tmp/fake"])

        assert result.exit_code == 1
        assert "Upload failed" in result.output

    @patch(
        "agentpowers_cli.commands.publish.package_directory",
        return_value=b"fake-zip",
    )
    @patch("agentpowers_cli.commands.publish.load_skill_metadata")
    @patch("agentpowers_cli.commands.publish.get_api_client")
    def test_create_non_409_error(
        self,
        mock_client_fn: MagicMock,
        mock_metadata: MagicMock,
        mock_package: MagicMock,
    ) -> None:
        """POST returning non-409 error (e.g. 500) shows generic error."""
        mock_metadata.return_value = _SKILL_META.copy()
        client = MagicMock()
        mock_client_fn.return_value = client
        client.post.side_effect = APIError("Internal server error", status_code=500)

        result = runner.invoke(app, ["publish", "--dir", "/tmp/fake"])

        assert result.exit_code == 1
        assert "Failed to create skill" in result.output
