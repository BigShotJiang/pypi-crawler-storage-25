# AgentPowers CLI

The `ap` command-line tool for the AgentPowers marketplace.

## Status

**Production.** 658 passing tests covering every command, full security pipeline, and the publish lifecycle.

## Commands

Auth:

- `ap login` -- Open browser for Clerk auth, store CLI token locally
- `ap logout` -- Revoke server-side token and remove stored credentials
- `ap whoami` -- Show current user info

Read:

- `ap search <query> [--category --type --source --limit]` -- Search the marketplace (Rich table output)
- `ap detail <slug> [--source --scan]` -- Show full details for a skill (use `--scan` for live security scan)
- `ap status` -- List installed skills and agents with metadata
- `ap verify` -- Check installed skills against content-hash pins

Install lifecycle:

- `ap install <slug> [--code XXXX] [--source clawhub] [--for codex|gemini|kiro] [--global]` -- Install a skill or agent
- `ap update [<slug>]` -- Check for and install updates
- `ap uninstall <slug> [--force]` -- Remove an installed skill or agent
- `ap scan <slug>` -- Run a security scan on an external skill (native AgentPowers skills are pre-scanned at publish time)

Publish lifecycle (requires Stripe Connect onboarding for paid skills):

- `ap publish [--price N] [--dir .] [--category dev] [--bump patch|minor|major | --version X.Y.Z] [--changelog ...]`
- `ap unpublish <slug> [--yes]` -- Soft-archive from marketplace discovery (existing buyers keep access)
- `ap republish <slug> [--yes]` -- Restore an archived skill
- `ap profile [--set]` -- View or interactively edit your seller profile

## Development

```bash
cd agentpowers-cli
uv venv .venv && source .venv/bin/activate
uv pip install -e ".[dev]"
ap --help
pytest tests/ -v    # Run tests
```

## Auth

Credentials stored at `~/.agentpowers/auth.json` (permissions: 600). Shared with the Claude Code plugin's MCP server.
