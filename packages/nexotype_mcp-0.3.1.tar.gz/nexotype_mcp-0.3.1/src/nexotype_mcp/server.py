"""
Nexotype MCP Server

FastMCP instance with all tools registered.
Entrypoint: nexotype-mcp (stdio transport for Claude Desktop/Code/Cursor)
"""

from fastmcp import FastMCP

mcp = FastMCP(
    "Nexotype",
    instructions=(
        "Nexotype — biomedical knowledge graph for drug discovery, genomics, and market intelligence.\n\n"
        "IMPORTANT: Before using any tools, the user must have run 'nexotype-cli login' in their terminal.\n\n"
        "Core capabilities:\n"
        "1. GRAPH INTELLIGENCE — traverse the biomedical knowledge graph:\n"
        "   - explore_network() — see what's connected to any entity\n"
        "   - find_path() — find how two entities are related\n"
        "   - find_similar() — entities sharing the most relationships\n"
        "   - company_deep_dive() — full portfolio of a pharma/biotech company\n"
        "   - drug_discovery() — targets, pathways, indications for a drug\n"
        "   - competitive_landscape() — all drugs and companies targeting a protein\n\n"
        "2. AI QUERY — natural language question → grounded answer from graph:\n"
        "   - ask_knowledge_graph() — asks the AI agent which traverses the graph\n\n"
        "3. SEARCH & BROWSE — find entities across 61 types in 10 domains:\n"
        "   - search_entities() — list entities of any type with filters\n"
        "   - get_entity() — get full details for a specific entity\n\n"
        "4. PERSONALIZED HEALTH (requires set_subject() first):\n"
        "   - Genomic variants, biomarker readings, treatment logs, pathway scores, recommendations\n"
        "   - VCF/23andMe file upload and processing\n\n"
        "5. COMMERCIAL INTELLIGENCE (Enterprise tier):\n"
        "   - Companies, patents, pipelines, regulatory approvals, licensing, M&A\n\n"
        "Workflow: get_permissions() → graph tools for questions → search for specifics.\n"
        "For personal health: set_subject() first, then access user data.\n"
        "Entity types use snake_case: gene, protein, therapeutic_asset, market_organization, etc."
    ),
    mask_error_details=True,
)

# Register all tools by importing tool modules
# Each module uses @mcp.tool decorator from this instance
from .tools import context  # noqa: F401, E402
from .tools import graph  # noqa: F401, E402
from .tools import ai  # noqa: F401, E402
from .tools import search  # noqa: F401, E402
from .tools import user  # noqa: F401, E402
from .tools import commercial  # noqa: F401, E402


def main():
    """Entrypoint for nexotype-mcp command. Runs stdio transport for Claude Desktop/Code/Codex."""
    mcp.run()


def main_http():
    """Entrypoint for nexotype-mcp-http command. Runs Streamable HTTP transport for ChatGPT / remote clients."""
    mcp.run(transport="http", host="0.0.0.0", port=8811)
