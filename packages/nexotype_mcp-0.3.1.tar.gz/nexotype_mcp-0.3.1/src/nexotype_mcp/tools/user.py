"""
User & personalization tools — personal health data access.

All tools require nexotype.subject_id to be set via set_subject().
Covers: genomic variants, biomarker readings, treatment logs,
pathway scores, recommendations, and VCF file upload.
"""

import os

from ..server import mcp
from ..client import nexotype


def _require_subject() -> str | None:
    """Check if subject context is set. Returns error message or None."""
    if not nexotype.subject_id:
        return "Error: No subject set. Use set_subject() first to select a biological identity."
    return None


@mcp.tool(annotations={"readOnlyHint": True})
async def get_user_profile() -> str:
    """Get the user profile linked to the current subject.
    Shows personal info: name, date of birth, blood type, ethnicity, sex."""
    result = await nexotype.get("/nexotype/user-profiles/")
    items = result.get("data", [])

    if not items:
        return "No user profile found. Create one in the Nexotype dashboard."

    # Find the profile linked to the current subject (if set)
    profile = None
    if nexotype.subject_id:
        for p in items:
            if p.get("subject_id") == nexotype.subject_id:
                profile = p
                break
    if not profile:
        profile = items[0]

    lines = [f"User Profile (id={profile['id']}):"]
    fields = [
        ("first_name", "First Name"),
        ("last_name", "Last Name"),
        ("email", "Email"),
        ("phone", "Phone"),
        ("date_of_birth", "Date of Birth"),
        ("blood_type", "Blood Type"),
        ("ethnicity", "Ethnicity"),
        ("sex", "Sex"),
        ("subject_id", "Subject ID"),
        ("user_id", "User ID"),
    ]
    for key, label in fields:
        val = profile.get(key)
        if val is not None:
            lines.append(f"  {label}: {val}")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def list_user_variants(limit: int = 50) -> str:
    """List detected genomic variants for the current subject.
    Shows variant ID, zygosity (heterozygous/homozygous), and linked variant details.
    Requires set_subject() first."""
    err = _require_subject()
    if err:
        return err

    result = await nexotype.get("/nexotype/user-variants/", params={"limit": limit})
    items = result.get("data", [])

    if not items:
        return "No variants detected for this subject. Upload a VCF file first."

    lines = [f"User Variants ({len(items)}):"]
    for v in items:
        variant_id = v.get("variant_id", "?")
        zygosity = v.get("zygosity", "?")
        lines.append(f"  - variant_id={variant_id}, zygosity={zygosity} (id={v.get('id')})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def list_biomarker_readings(limit: int = 50) -> str:
    """List biomarker readings (time-series health data) for the current subject.
    Shows biomarker, value, unit, measurement date, and data source.
    Requires set_subject() first."""
    err = _require_subject()
    if err:
        return err

    result = await nexotype.get("/nexotype/user-biomarker-readings/", params={"limit": limit})
    items = result.get("data", [])

    if not items:
        return "No biomarker readings found for this subject."

    lines = [f"Biomarker Readings ({len(items)}):"]
    for r in items:
        biomarker_id = r.get("biomarker_id", "?")
        value = r.get("value", "?")
        unit_id = r.get("unit_id", "?")
        measured = r.get("measured_at", "?")
        source_id = r.get("source_id", "?")
        lines.append(
            f"  - biomarker={biomarker_id}, value={value}, unit={unit_id}, "
            f"measured={measured}, source={source_id} (id={r.get('id')})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_biomarker_reading(
    biomarker_id: int,
    source_id: int,
    value: float,
    unit_id: int,
    measured_at: str,
) -> str:
    """Create a new biomarker reading for the current subject.
    Requires set_subject() first.

    biomarker_id: ID of the biomarker being measured
    source_id: ID of the data source (wearable, lab, manual)
    value: the measured value
    unit_id: ID of the unit of measure
    measured_at: ISO datetime string (e.g. "2025-01-15T08:30:00Z")"""
    err = _require_subject()
    if err:
        return err

    payload = {
        "subject_id": nexotype.subject_id,
        "biomarker_id": biomarker_id,
        "source_id": source_id,
        "value": value,
        "unit_id": unit_id,
        "measured_at": measured_at,
    }

    result = await nexotype.post("/nexotype/user-biomarker-readings/", data=payload)
    data = result.get("data", result)
    return f"Biomarker reading created successfully (id={data.get('id', '?')})."


@mcp.tool(annotations={"readOnlyHint": True})
async def list_treatment_logs(limit: int = 50) -> str:
    """List treatment logs (intervention history) for the current subject.
    Shows therapeutic asset, dosage, start/end dates.
    Requires set_subject() first."""
    err = _require_subject()
    if err:
        return err

    result = await nexotype.get("/nexotype/user-treatment-logs/", params={"limit": limit})
    items = result.get("data", [])

    if not items:
        return "No treatment logs found for this subject."

    lines = [f"Treatment Logs ({len(items)}):"]
    for t in items:
        asset_id = t.get("asset_id", "?")
        dosage = t.get("dosage", "?")
        started = t.get("started_at", "?")
        ended = t.get("ended_at", "ongoing")
        lines.append(
            f"  - asset={asset_id}, dosage={dosage}, "
            f"started={started}, ended={ended} (id={t.get('id')})"
        )

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def create_treatment_log(
    asset_id: int,
    dosage: str,
    started_at: str,
    ended_at: str | None = None,
) -> str:
    """Create a new treatment log for the current subject.
    Requires set_subject() first.

    asset_id: ID of the therapeutic asset being taken
    dosage: dosage description (e.g. "500mcg subcutaneous")
    started_at: start date (ISO format, e.g. "2025-01-15")
    ended_at: end date or None if ongoing"""
    err = _require_subject()
    if err:
        return err

    payload: dict = {
        "subject_id": nexotype.subject_id,
        "asset_id": asset_id,
        "dosage": dosage,
        "started_at": started_at,
    }
    if ended_at is not None:
        payload["ended_at"] = ended_at

    result = await nexotype.post("/nexotype/user-treatment-logs/", data=payload)
    data = result.get("data", result)
    return f"Treatment log created successfully (id={data.get('id', '?')})."


@mcp.tool(annotations={"readOnlyHint": True})
async def list_pathway_scores() -> str:
    """List pathway health scores for the current subject.
    Shows pathway, score value, and calculation date.
    Requires set_subject() first."""
    err = _require_subject()
    if err:
        return err

    result = await nexotype.get("/nexotype/pathway-scores/")
    items = result.get("data", [])

    if not items:
        return "No pathway scores calculated for this subject yet."

    lines = [f"Pathway Scores ({len(items)}):"]
    for ps in items:
        pathway_id = ps.get("pathway_id", "?")
        score = ps.get("score", "?")
        calculated = ps.get("calculated_at", "?")
        lines.append(f"  - pathway={pathway_id}, score={score}, calculated={calculated} (id={ps.get('id')})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def list_recommendations() -> str:
    """List personalized treatment recommendations for the current subject.
    Shows recommended therapeutic asset, reason, and priority.
    Requires set_subject() first."""
    err = _require_subject()
    if err:
        return err

    result = await nexotype.get("/nexotype/recommendations/")
    items = result.get("data", [])

    if not items:
        return "No recommendations generated for this subject yet."

    lines = [f"Recommendations ({len(items)}):"]
    for rec in items:
        asset_id = rec.get("asset_id", "?")
        reason = rec.get("reason", "—")
        priority = rec.get("priority", "—")
        if len(reason) > 80:
            reason = reason[:77] + "..."
        lines.append(f"  - asset={asset_id}, priority={priority}, reason: {reason} (id={rec.get('id')})")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def upload_genomic_file(file_path: str, subject_id: int) -> str:
    """Upload a VCF or 23andMe genomic file for processing.
    The file is parsed in the background — use get_processing_status() to check progress.

    file_path: absolute path to the local file (.vcf, .vcf.gz, or .txt)
    subject_id: the subject this genomic data belongs to

    Supported formats: VCF (.vcf, .vcf.gz), 23andMe (.txt)
    Max file size: 500MB"""
    # Validate file exists
    if not os.path.isfile(file_path):
        return f"Error: File not found at '{file_path}'."

    # Validate extension
    lower = file_path.lower()
    if not (lower.endswith(".vcf") or lower.endswith(".vcf.gz") or lower.endswith(".txt")):
        return "Error: Unsupported file format. Use .vcf, .vcf.gz, or .txt files."

    # Check file size (500MB max)
    size = os.path.getsize(file_path)
    if size > 500 * 1024 * 1024:
        return f"Error: File too large ({size / 1024 / 1024:.1f} MB). Maximum is 500 MB."

    result = await nexotype.post_file(
        "/nexotype/genomic-files/upload",
        file_path=file_path,
        form_data={"subject_id": str(subject_id)},
    )

    data = result.get("data", result)
    file_id = data.get("id", "?")
    status = data.get("status", "Uploaded")

    return (
        f"Genomic file uploaded successfully.\n"
        f"  File ID: {file_id}\n"
        f"  Status: {status}\n"
        f"  Use get_processing_status({file_id}) to check progress."
    )


@mcp.tool(annotations={"readOnlyHint": True})
async def get_processing_status(genomic_file_id: int) -> str:
    """Check the processing status of an uploaded genomic file.
    Status flow: Uploaded → Processing → Analyzed (success) or Failed (error).

    genomic_file_id: the ID returned by upload_genomic_file()"""
    result = await nexotype.get(f"/nexotype/genomic-files/{genomic_file_id}/status")

    status = result.get("status", "Unknown")
    variant_count = result.get("variant_count")
    error_message = result.get("error_message")

    lines = [f"Genomic File #{genomic_file_id}:"]
    lines.append(f"  Status: {status}")

    if status == "Analyzed" and variant_count is not None:
        lines.append(f"  Variants matched: {variant_count}")
        lines.append(f"\nUse list_user_variants() to see the detected variants.")
    elif status == "Failed" and error_message:
        lines.append(f"  Error: {error_message}")
    elif status in ("Uploaded", "Processing"):
        lines.append("  Processing in progress... Check again in a few seconds.")

    return "\n".join(lines)
