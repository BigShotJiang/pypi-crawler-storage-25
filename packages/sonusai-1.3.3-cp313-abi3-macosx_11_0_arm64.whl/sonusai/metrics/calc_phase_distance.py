"""Calculate weighted phase distance error."""

import numpy as np


def calc_phase_distance(
    reference: np.ndarray, hypothesis: np.ndarray, eps: float = 1e-9
) -> tuple[float, np.ndarray, np.ndarray]:
    """Calculate weighted phase distance error.

    Uses weight normalization over bins per frame.

    Args:
        reference: Complex [frames, bins] reference data.
        hypothesis: Complex [frames, bins] hypothesis data.
        eps: Epsilon value to avoid division by zero.

    Returns:
        tuple[float, np.ndarray, np.ndarray]: A tuple containing:
            - mean: Weighted mean phase distance error.
            - mean per bin: Weighted mean error calculated per frequency bin.
            - mean per frame: Weighted mean error calculated per time frame.

    """
    ang_diff = np.angle(reference) - np.angle(hypothesis)
    phd_mod = (ang_diff + np.pi) % (2 * np.pi) - np.pi
    rh_angle_diff = phd_mod * 180 / np.pi  # angle diff in deg

    # weighted mean over all (scalar)
    reference_mag = np.abs(reference)
    ref_weight = reference_mag / (np.sum(reference_mag) + eps)  # frames x bins
    err = float(np.around(np.sum(ref_weight * rh_angle_diff), 3))

    # weighted mean over frames (value per bin)
    err_b = np.zeros(reference.shape[1])
    for bi in range(reference.shape[1]):
        ref_weight = reference_mag[:, bi] / (np.sum(reference_mag[:, bi], axis=0) + eps)
        err_b[bi] = np.around(np.sum(ref_weight * rh_angle_diff[:, bi]), 3)

    # weighted mean over bins (value per frame)
    err_f = np.zeros(reference.shape[0])
    for fi in range(reference.shape[0]):
        ref_weight = reference_mag[fi, :] / (np.sum(reference_mag[fi, :]) + eps)
        err_f[fi] = np.around(np.sum(ref_weight * rh_angle_diff[fi, :]), 3)

    return err, err_b, err_f
