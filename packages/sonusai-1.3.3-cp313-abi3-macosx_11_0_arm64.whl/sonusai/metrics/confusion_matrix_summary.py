"""Calculate confusion matrix summary for a specified class."""

# ruff: noqa: F821
import numpy as np
import pandas as pd

from sonusai.datatypes import GeneralizedIDs
from sonusai.datatypes import Predict
from sonusai.datatypes import Truth
from sonusai.mixture.mixdb import MixtureDatabase


def confusion_matrix_summary(  # noqa: PLR0913
    mixdb: MixtureDatabase,
    mixids: GeneralizedIDs,
    truth_f: Truth,
    predict: Predict,
    class_idx: int,
    predict_thr: float | np.ndarray = 0,
    truth_thr: float = 0.5,
    timesteps: int = 0,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Calculate confusion matrix for a specified class.

    Uses truth and prediction data of shape [features, num_classes].

    Args:
        mixdb: Mixture database.
        mixids: List of mixture IDs.
        truth_f: Truth data.
        predict: Prediction data.
        class_idx: Index of the class to calculate the confusion matrix for.
        predict_thr: Decision threshold(s) applied to prediction data.
            If 0, it will infer 0.5 for multi-label mode.
        truth_thr: Truth threshold.
        timesteps: Number of timesteps.

    Returns:
        tuple[pd.DataFrame, pd.DataFrame]: A tuple containing:
            - cmdf: Confusion matrix DataFrame.
            - cmndf: Normalized confusion matrix DataFrame.

    """
    from sonusai.metrics.one_hot import one_hot  # noqa: PLC0415 (Circular dependency)

    num_classes = truth_f.shape[1]
    # TODO: re-work for modern mixdb API
    ytrue, ypred = get_mixids_data(mixdb=mixdb, mixids=mixids, truth_f=truth_f, predict=predict)  # type: ignore[name-defined]

    # Check predict_thr array or scalar and return final scalar predict_thr value
    if num_classes > 1:
        if not isinstance(predict_thr, np.ndarray):
            predict_thr = np.atleast_1d(0.5) if predict_thr == 0 else np.atleast_1d(predict_thr)
        elif predict_thr.ndim == 1:
            predict_thr = np.atleast_1d(0.5) if predict_thr[0] == 0 else predict_thr[0]
        else:
            # multi-label predict_thr array scalar set = array[class_idx]
            predict_thr = predict_thr[class_idx]

    if len(mixdb.class_labels) == num_classes:
        class_names = mixdb.class_labels
    else:
        class_names = [f"Class {i}" for i in range(1, num_classes + 1)]

    _, _, cm, cmn, _, _ = one_hot(ytrue[:, class_idx], ypred[:, class_idx], predict_thr, truth_thr, timesteps)
    cname = class_names[class_idx]
    row_n = ["TrueN", "TrueP"]
    col_n = ["N-" + cname, "P-" + cname]
    cmdf = pd.DataFrame(cm, index=row_n, columns=col_n, dtype=np.int32)
    cmndf = pd.DataFrame(cmn, index=row_n, columns=col_n, dtype=np.float32)
    # add thresholds in 3rd row
    pdnote = pd.DataFrame(np.atleast_2d([predict_thr, truth_thr]), index=["p/t thr:"], columns=col_n)
    cmdf = pd.concat([cmdf, pdnote])
    cmndf = pd.concat([cmndf, pdnote])

    return cmdf, cmndf
