"""Calculate metrics summary per SNR."""

# ruff: noqa: F821
import warnings

import numpy as np
import pandas as pd

from sonusai.datatypes import GeneralizedIDs
from sonusai.datatypes import Predict
from sonusai.datatypes import Segsnr
from sonusai.datatypes import Truth
from sonusai.metrics.one_hot import one_hot
from sonusai.mixture.mixdb import MixtureDatabase
from sonusai.queries.queries import get_mixids_from_snr


def snr_summary(  # noqa: PLR0913
    mixdb: MixtureDatabase,
    mixid: GeneralizedIDs,
    truth_f: Truth,
    predict: Predict,
    segsnr: Segsnr | None = None,
    predict_thr: float | np.ndarray = 0,
    truth_thr: float = 0.5,
    timesteps: int = 0,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]:
    """Calculate average-over-class metrics per SNR for a list of mixtures.

    Args:
        mixdb: Mixture database.
        mixid: Generalized mixture IDs.
        truth_f: Truth data.
        predict: Prediction data.
        segsnr: Optional segmental SNR data.
        predict_thr: Decision threshold(s) applied to predict data.
            If 0, it will infer 0.5 for multi-label mode.
        truth_thr: Decision threshold(s) applied to truth data.
        timesteps: Number of timesteps.

    Returns:
        tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]: A tuple containing:
            - snr_macrodf: Macro-average metrics per SNR.
            - snr_microdf: Micro-average metrics per SNR.
            - snr_wghtdf: Weighted-average metrics per SNR.
            - snr_mixids: Dictionary of mixture IDs grouped by SNR.

    """
    num_classes = truth_f.shape[1]

    snr_mixids = get_mixids_from_snr(mixdb=mixdb, mixids=mixid)

    # Check predict_thr array or scalar and return final scalar predict_thr value
    if num_classes > 1:
        if not isinstance(predict_thr, np.ndarray):
            predict_thr = np.atleast_1d(0.5) if predict_thr == 0 else np.atleast_1d(predict_thr)
        elif predict_thr.ndim == 1 and len(predict_thr) == 1:
            predict_thr = np.atleast_1d(0.5) if predict_thr[0] == 0 else predict_thr[0]

    macro_avg = np.zeros((len(snr_mixids), 7), dtype=np.float32)
    micro_avg = np.zeros((len(snr_mixids), 7), dtype=np.float32)
    wghtd_avg = np.zeros((len(snr_mixids), 7), dtype=np.float32)
    ssnr_stats = None
    segsnr_f = None

    if segsnr is not None:
        # prep segsnr if provided, transform frames to feature frames via mean()
        # expected to always be an integer
        feature_frames = int(segsnr.shape[0] / truth_f.shape[0])
        segsnr_f = np.mean(
            np.reshape(segsnr, (truth_f.shape[0], feature_frames)),
            axis=1,
            keepdims=True,
        )
        ssnr_stats = np.zeros((len(snr_mixids), 3), dtype=np.float32)

    for ii, snr in enumerate(snr_mixids):
        # TODO: re-work for modern mixdb API
        y_truth, y_predict = get_mixids_data(mixdb, snr_mixids[snr], truth_f, predict)  # type: ignore[name-defined]
        _, _, _, _, _, mavg = one_hot(y_truth, y_predict, predict_thr, truth_thr, timesteps)

        # mavg macro, micro, weighted: [PPV, TPR, F1, FPR, ACC, mAP, mAUC, TPSUM]
        macro_avg[ii, :] = mavg[0, 0:7]
        micro_avg[ii, :] = mavg[1, 0:7]
        wghtd_avg[ii, :] = mavg[2, 0:7]
        if segsnr is not None:
            # TODO: re-work for modern mixdb API
            y_truth, y_segsnr = get_mixids_data(mixdb, snr_mixids[snr], truth_f, segsnr_f)  # type: ignore[name-defined]
            with warnings.catch_warnings():
                warnings.filterwarnings(action="ignore", message="divide by zero encountered in log10")
                # segmental SNR mean = mixture_snr and target_snr
                ssnr_stats[ii, 0] = 10 * np.log10(np.mean(y_segsnr))  # type: ignore[index]
                # segmental SNR 80% percentile
                ssnr_stats[ii, 1] = 10 * np.log10(np.percentile(y_segsnr, 80, method="midpoint"))  # type: ignore[index]
                # segmental SNR max
                ssnr_stats[ii, 2] = 10 * np.log10(max(y_segsnr))  # type: ignore[index]

    # SNR format: PPV, TPR, F1, FPR, ACC, AP, AUC
    col_n = ["PPV", "TPR", "F1", "FPR", "ACC", "AP", "AUC"]
    snr_macrodf = pd.DataFrame(macro_avg, index=list(snr_mixids.keys()), columns=col_n)
    snr_macrodf = snr_macrodf.sort_index(ascending=False)

    snr_microdf = pd.DataFrame(micro_avg, index=list(snr_mixids.keys()), columns=col_n)
    snr_microdf = snr_microdf.sort_index(ascending=False)

    snr_wghtdf = pd.DataFrame(wghtd_avg, index=list(snr_mixids.keys()), columns=col_n)
    snr_wghtdf = snr_wghtdf.sort_index(ascending=False)

    # Add segmental SNR columns if provided
    if segsnr is not None:
        ssnrdf = pd.DataFrame(
            ssnr_stats,
            index=list(snr_mixids.keys()),
            columns=["SSNRavg", "SSNR80p", "SSNRmax"],
        )
        ssnrdf = ssnrdf.sort_index(ascending=False)
        snr_macrodf = pd.concat([snr_macrodf, ssnrdf], axis=1)
        snr_microdf = pd.concat([snr_microdf, ssnrdf], axis=1)
        snr_wghtdf = pd.concat([snr_wghtdf, ssnrdf], axis=1)

    return snr_macrodf, snr_microdf, snr_wghtdf, snr_mixids
