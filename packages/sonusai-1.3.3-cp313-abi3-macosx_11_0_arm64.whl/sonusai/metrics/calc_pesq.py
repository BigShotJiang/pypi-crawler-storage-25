"""Calculate PESQ (Perceptual Evaluation of Speech Quality) score."""

import numpy as np

from sonusai.constants import SAMPLE_RATE


def calc_pesq(
    hypothesis: np.ndarray,
    reference: np.ndarray,
    error_value: float = 0.0,
    sample_rate: int = SAMPLE_RATE,
) -> float:
    """Compute the PESQ score of hypothesis vs. reference.

    Upon error, assigns a value of 0, or user specified value in error_value.

    Args:
        hypothesis: Estimated audio.
        reference: Reference audio.
        error_value: Value to use if an error occurs.
        sample_rate: Sample rate of the audio.

    Raises:
        ValueError: If an error occurs.

    """
    import warnings  # noqa: PLC0415

    from pesq import pesq  # noqa: PLC0415 (Heavy loading: ~260ms)

    from sonusai import logger  # noqa: PLC0415

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            score = pesq(fs=sample_rate, ref=reference, deg=hypothesis, mode="wb")
    except Exception as e:  # noqa: BLE001 (pesq can raise various backend-specific errors)
        logger.debug(f"PESQ error {e}")
        score = error_value

    return score
