"""Calculate metrics for a given mixture from the database."""

from __future__ import annotations

import functools
from typing import TYPE_CHECKING
from typing import Any

import numpy as np
from pystoi import stoi

from sonusai.constants import SAMPLE_RATE
from sonusai.utils.asr import calc_asr
from sonusai.utils.db import linear_to_db

if TYPE_CHECKING:
    from collections.abc import Callable

    from sonusai.datatypes import AudioF
    from sonusai.datatypes import AudioStatsMetrics
    from sonusai.datatypes import AudioT
    from sonusai.datatypes import Segsnr
    from sonusai.datatypes import SpeechMetrics
    from sonusai.mixture.mixdb import MixtureDatabase

from .calc_audio_stats import calc_audio_stats
from .calc_pesq import calc_pesq
from .calc_phase_distance import calc_phase_distance
from .calc_segsnr_f import calc_segsnr_f
from .calc_segsnr_f import calc_segsnr_f_bin
from .calc_speech import calc_speech
from .calc_wer import calc_wer
from .calc_wsdr import calc_wsdr

supported_metrics_names = [
    "mxssnr_avg",
    "mxssnr_std",
    "mxssnr_avg_db",
    "mxssnr_std_db",
    "mxssnrdb_avg",
    "mxssnrdb_std",
    "mxssnrf_avg",
    "mxssnrf_std",
    "mxssnrdbf_avg",
    "mxssnrdbf_std",
    "mxpesq",
    "mxcsig",
    "mxcbak",
    "mxcovl",
    "mxwsdr",
    "mxpd",
    "mxstoi",
    "mxdco",
    "mxmin",
    "mxmax",
    "mxpkdb",
    "mxlrms",
    "mxpkr",
    "mxtr",
    "mxcr",
    "mxfl",
    "mxpkc",
    "sdco",
    "smin",
    "smax",
    "spkdb",
    "slrms",
    "spkr",
    "str",
    "scr",
    "sfl",
    "spkc",
    "mxsdco",
    "mxsmin",
    "mxsmax",
    "mxspkdb",
    "mxslrms",
    "mxspkr",
    "mxstr",
    "mxscr",
    "mxsfl",
    "mxspkc",
    "ndco",
    "nmin",
    "nmax",
    "npkdb",
    "nlrms",
    "npkr",
    "ntr",
    "ncr",
    "nfl",
    "npkc",
    "sedavg",
    "sedcnt",
    "sedtop3",
    "sedtopn",
    "ssnr",
]

supported_metrics_pretty = ", ".join(supported_metrics_names)


def calculate_metrics(  # noqa: C901, PLR0915
    mixdb: MixtureDatabase,
    m_id: int,
    metrics: list[str],
    force: bool = False,
) -> dict[str, Any]:
    """Calculate metrics data for the given mixture ID.

    Args:
        mixdb: Mixture database object.
        m_id: Zero-based mixture ID.
        metrics: List of metrics to calculate.
        force: Force computing data from original sources regardless of
            whether cached data exists.

    Returns:
        dict[str, Any]: Dictionary of metric data.

    """

    # Define cached functions for expensive operations
    @functools.lru_cache(maxsize=1)
    def mixture_sources() -> dict[str, AudioT]:
        return mixdb.mixture_sources(m_id)

    @functools.lru_cache(maxsize=1)
    def mixture_source() -> AudioT:
        return mixdb.mixture_source(m_id)

    @functools.lru_cache(maxsize=1)
    def mixture_source_f() -> AudioF:
        return mixdb.mixture_source_f(m_id)

    @functools.lru_cache(maxsize=1)
    def mixture_noise() -> AudioT:
        return mixdb.mixture_noise(m_id)

    @functools.lru_cache(maxsize=1)
    def mixture_noise_f() -> AudioF:
        return mixdb.mixture_noise_f(m_id)

    @functools.lru_cache(maxsize=1)
    def mixture_mixture() -> AudioT:
        return mixdb.mixture_mixture(m_id)

    @functools.lru_cache(maxsize=1)
    def mixture_mixture_f() -> AudioF:
        return mixdb.mixture_mixture_f(m_id)

    @functools.lru_cache(maxsize=1)
    def mixture_segsnr() -> Segsnr:
        return mixdb.mixture_segsnr(m_id)

    @functools.lru_cache(maxsize=1)
    def calculate_pesq() -> dict[str, float]:
        return {category: calc_pesq(mixture_mixture(), audio) for category, audio in mixture_sources().items()}

    @functools.lru_cache(maxsize=1)
    def calculate_speech() -> dict[str, SpeechMetrics]:
        return {
            category: calc_speech(mixture_mixture(), audio, calculate_pesq()[category])
            for category, audio in mixture_sources().items()
        }

    @functools.lru_cache(maxsize=1)
    def mixture_stats() -> AudioStatsMetrics:
        return calc_audio_stats(mixture_mixture(), mixdb.fg_info.ft_config.length / SAMPLE_RATE)

    @functools.lru_cache(maxsize=1)
    def sources_stats() -> dict[str, AudioStatsMetrics]:
        return {
            category: calc_audio_stats(audio, mixdb.fg_info.ft_config.length / SAMPLE_RATE)
            for category, audio in mixture_sources().items()
        }

    @functools.lru_cache(maxsize=1)
    def source_stats() -> AudioStatsMetrics:
        return calc_audio_stats(mixture_source(), mixdb.fg_info.ft_config.length / SAMPLE_RATE)

    @functools.lru_cache(maxsize=1)
    def noise_stats() -> AudioStatsMetrics:
        return calc_audio_stats(mixture_noise(), mixdb.fg_info.ft_config.length / SAMPLE_RATE)

    # Cache ASR configurations
    @functools.lru_cache(maxsize=32)
    def get_asr_config(asr_name: str) -> dict:
        value = mixdb.asr_configs.get(asr_name, None)
        if value is None:
            msg = f"Unrecognized ASR name: '{asr_name}'"
            raise ValueError(msg)
        return value

    # Cache ASR results for sources, source and mixture
    @functools.lru_cache(maxsize=16)
    def sources_asr(asr_name: str) -> dict[str, str]:
        return {
            category: calc_asr(audio, **get_asr_config(asr_name)).text for category, audio in mixture_sources().items()
        }

    @functools.lru_cache(maxsize=16)
    def source_asr(asr_name: str) -> str:
        return calc_asr(mixture_source(), **get_asr_config(asr_name)).text

    @functools.lru_cache(maxsize=16)
    def mixture_asr(asr_name: str) -> str:
        return calc_asr(mixture_mixture(), **get_asr_config(asr_name)).text

    def get_asr_name(m: str) -> str:
        parts = m.split(".")
        if len(parts) != 2:
            msg = f"Unrecognized format: '{m}'; must be of the form: '<metric>.<name>'"
            raise ValueError(msg)
        return parts[1]

    def get_metric_stat(metric_name: str, metric_getter: Callable[[], AudioStatsMetrics]) -> float:
        stat_map = {
            "dco": lambda stats: stats.dco,
            "min": lambda stats: stats.min,
            "max": lambda stats: stats.max,
            "pkdb": lambda stats: stats.pkdb,
            "lrms": lambda stats: stats.lrms,
            "pkr": lambda stats: stats.pkr,
            "tr": lambda stats: stats.tr,
            "cr": lambda stats: stats.cr,
            "fl": lambda stats: stats.fl,
            "pkc": lambda stats: stats.pkc,
        }
        stat_value = stat_map.get(metric_name)
        if stat_value is None:
            msg = f"Unrecognized stat metric: '{metric_name}'"
            raise AttributeError(msg)
        return stat_value(metric_getter())

    def get_metrics_by_category(metric_name: str) -> dict[str, float]:
        stat_map = {
            "sdco": "dco",
            "smin": "min",
            "smax": "max",
            "spkdb": "pkdb",
            "slrms": "lrms",
            "spkr": "pkr",
            "str": "tr",
            "scr": "cr",
            "sfl": "fl",
            "spkc": "pkc",
        }
        stat_name = stat_map.get(metric_name)
        if stat_name is None:
            msg = f"Unrecognized source metric: '{metric_name}'"
            raise AttributeError(msg)
        return {category: getattr(stats, stat_name) for category, stats in sources_stats().items()}

    def calc_mxwer(m: str) -> float:
        asr_name = get_asr_name(m)
        if mixdb.mixture(m_id).is_noise_only:
            return float("nan")
        source_text = source_asr(asr_name)
        if source_text:
            return calc_wer(mixture_asr(asr_name), source_text).wer * 100
        return float(0)

    def calc_basewer(m: str) -> dict[str, float]:
        asr_name = get_asr_name(m)
        text = mixdb.mixture_speech_metadata(m_id, "text")
        return {
            category: calc_wer(source, str(text[category])).wer * 100 if isinstance(text[category], str) else 0
            for category, source in sources_asr(asr_name).items()
        }

    def calc_mxasr(m: str) -> str:
        return mixture_asr(get_asr_name(m))

    def calc_sources_asr(m: str) -> dict[str, str]:
        return sources_asr(get_asr_name(m))

    def calc_source_asr(m: str) -> str:
        return source_asr(get_asr_name(m))

    def calc_mxwsdr() -> float:
        mixture = mixture_mixture()[:, np.newaxis]
        target = mixture_source()[:, np.newaxis]
        noise = mixture_noise()[:, np.newaxis]
        return calc_wsdr(
            hypothesis=np.concatenate((mixture, noise), axis=1),
            reference=np.concatenate((target, noise), axis=1),
            with_log=True,
        )[0]

    def calc_speech_metric(metric_name: str) -> dict[str, float]:
        if mixdb.mixture(m_id).is_noise_only:
            return dict.fromkeys(calculate_speech(), 0)
        speech_metrics = calculate_speech()
        speech_map = {
            "mxcsig": lambda speech: speech.csig,
            "mxcbak": lambda speech: speech.cbak,
            "mxcovl": lambda speech: speech.covl,
        }
        speech_value = speech_map.get(metric_name)
        if speech_value is None:
            msg = f"Unrecognized speech metric: '{metric_name}'"
            raise AttributeError(msg)
        return {category: speech_value(speech) for category, speech in speech_metrics.items()}

    exact_metric_handlers: dict[str, Callable[[], Any]] = {
        "mxssnr_avg": lambda: calc_segsnr_f(mixture_segsnr()).avg,
        "mxssnr_std": lambda: calc_segsnr_f(mixture_segsnr()).std,
        "mxssnr_avg_db": lambda: (
            linear_to_db(value) if (value := calc_segsnr_f(mixture_segsnr()).avg) is not None else None
        ),
        "mxssnr_std_db": lambda: (
            linear_to_db(value) if (value := calc_segsnr_f(mixture_segsnr()).std) is not None else None
        ),
        "mxssnrdb_avg": lambda: calc_segsnr_f(mixture_segsnr()).db_avg,
        "mxssnrdb_std": lambda: calc_segsnr_f(mixture_segsnr()).db_std,
        "mxssnrf_avg": lambda: calc_segsnr_f_bin(mixture_source_f(), mixture_noise_f()).avg,
        "mxssnrf_std": lambda: calc_segsnr_f_bin(mixture_source_f(), mixture_noise_f()).std,
        "mxssnrdbf_avg": lambda: calc_segsnr_f_bin(mixture_source_f(), mixture_noise_f()).db_avg,
        "mxssnrdbf_std": lambda: calc_segsnr_f_bin(mixture_source_f(), mixture_noise_f()).db_std,
        "mxpesq": lambda: dict.fromkeys(calculate_pesq(), 0) if mixdb.mixture(m_id).is_noise_only else calculate_pesq(),
        "mxcsig": lambda: calc_speech_metric("mxcsig"),
        "mxcbak": lambda: calc_speech_metric("mxcbak"),
        "mxcovl": lambda: calc_speech_metric("mxcovl"),
        "mxwsdr": calc_mxwsdr,
        "mxpd": lambda: calc_phase_distance(hypothesis=mixture_mixture_f(), reference=mixture_source_f())[0],
        "mxstoi": lambda: stoi(x=mixture_source(), y=mixture_mixture(), fs_sig=SAMPLE_RATE, extended=False),
        "mxdco": lambda: get_metric_stat("dco", mixture_stats),
        "mxmin": lambda: get_metric_stat("min", mixture_stats),
        "mxmax": lambda: get_metric_stat("max", mixture_stats),
        "mxpkdb": lambda: get_metric_stat("pkdb", mixture_stats),
        "mxlrms": lambda: get_metric_stat("lrms", mixture_stats),
        "mxpkr": lambda: get_metric_stat("pkr", mixture_stats),
        "mxtr": lambda: get_metric_stat("tr", mixture_stats),
        "mxcr": lambda: get_metric_stat("cr", mixture_stats),
        "mxfl": lambda: get_metric_stat("fl", mixture_stats),
        "mxpkc": lambda: get_metric_stat("pkc", mixture_stats),
        "sdco": lambda: get_metrics_by_category("sdco"),
        "smin": lambda: get_metrics_by_category("smin"),
        "smax": lambda: get_metrics_by_category("smax"),
        "spkdb": lambda: get_metrics_by_category("spkdb"),
        "slrms": lambda: get_metrics_by_category("slrms"),
        "spkr": lambda: get_metrics_by_category("spkr"),
        "str": lambda: get_metrics_by_category("str"),
        "scr": lambda: get_metrics_by_category("scr"),
        "sfl": lambda: get_metrics_by_category("sfl"),
        "spkc": lambda: get_metrics_by_category("spkc"),
        "mxsdco": lambda: get_metric_stat("dco", source_stats),
        "mxsmin": lambda: get_metric_stat("min", source_stats),
        "mxsmax": lambda: get_metric_stat("max", source_stats),
        "mxspkdb": lambda: get_metric_stat("pkdb", source_stats),
        "mxslrms": lambda: get_metric_stat("lrms", source_stats),
        "mxspkr": lambda: get_metric_stat("pkr", source_stats),
        "mxstr": lambda: get_metric_stat("tr", source_stats),
        "mxscr": lambda: get_metric_stat("cr", source_stats),
        "mxsfl": lambda: get_metric_stat("fl", source_stats),
        "mxspkc": lambda: get_metric_stat("pkc", source_stats),
        "ndco": lambda: get_metric_stat("dco", noise_stats),
        "nmin": lambda: get_metric_stat("min", noise_stats),
        "nmax": lambda: get_metric_stat("max", noise_stats),
        "npkdb": lambda: get_metric_stat("pkdb", noise_stats),
        "nlrms": lambda: get_metric_stat("lrms", noise_stats),
        "npkr": lambda: get_metric_stat("pkr", noise_stats),
        "ntr": lambda: get_metric_stat("tr", noise_stats),
        "ncr": lambda: get_metric_stat("cr", noise_stats),
        "nfl": lambda: get_metric_stat("fl", noise_stats),
        "npkc": lambda: get_metric_stat("pkc", noise_stats),
        "sedavg": lambda: 0,
        "sedcnt": lambda: 0,
        "sedtop3": lambda: np.zeros(3, dtype=np.float32),
        "sedtopn": lambda: 0,
        "ssnr": mixture_segsnr,
    }

    prefix_metric_handlers: tuple[tuple[str, Callable[[str], Any]], ...] = (
        ("mxwer", calc_mxwer),
        ("basewer", calc_basewer),
        ("mxasr", calc_mxasr),
        ("sasr", calc_sources_asr),
        ("mxsasr", calc_source_asr),
    )

    def calc(m: str) -> Any:  # noqa: ANN401
        if m == "mxsnr":
            return {category: source.snr for category, source in mixdb.mixture(m_id).all_sources.items()}

        # Get cached data first, if exists
        if not force:
            value = mixdb.read_mixture_data(m_id, m)[m]
            if value is not None:
                return value

        for prefix, handler in prefix_metric_handlers:
            if m.startswith(prefix):
                return handler(m)

        handler = exact_metric_handlers.get(m)
        if handler is not None:
            return handler()

        msg = f"Unrecognized metric: '{m}'"
        raise AttributeError(msg)

    result: dict[str, Any] = {}
    for metric in metrics:
        result[metric] = calc(metric)

        # Check for metrics dependencies and add them even if not explicitly requested.
        if metric.startswith("mxwer"):
            dependencies = ("mxasr." + metric[6:], "sasr." + metric[6:])
            for dependency in dependencies:
                result[dependency] = calc(dependency)

    return result
