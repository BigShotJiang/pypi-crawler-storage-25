"""Calculate optimal thresholds for classification."""

import numpy as np

from sonusai.datatypes import Predict
from sonusai.datatypes import Truth


def calc_optimal_thresholds(
    truth: Truth,
    predict: Predict,
    timesteps: int = 0,
    truth_thr: float = 0.5,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Calculate optimal thresholds for each class from one-hot prediction and truth data.

    Supports one-hot probabilities (or quantized decisions) with size
    [frames, num_classes] or [frames, timesteps, num_classes].

    Args:
        truth: Truth data.
        predict: Prediction data.
        timesteps: Number of timesteps.
        truth_thr: The decision threshold(s) applied to truth one-hot input,
            allowing truth to optionally be continuous probabilities.

    Returns:
        tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]: A tuple containing:
            - thresholds_opt_pr: [num_classes, 1] optimal thresholds for PR-curve (F1) performance.
            - thresholds_opt_roc: [num_classes, 1] optimal thresholds for ROC-curve (TPR/FPR) performance.
            - AP: [num_classes, 1] Average Precision.
            - AUC: [num_classes, 1] Area Under the Curve.

    Raises:
        ValueError: If truth and predict are not the same shape.

    """
    from sklearn.metrics import average_precision_score  # noqa: PLC0415 (Heavy loading: ~593ms)
    from sklearn.metrics import precision_recall_curve  # noqa: PLC0415
    from sklearn.metrics import roc_auc_score  # noqa: PLC0415
    from sklearn.metrics import roc_curve  # noqa: PLC0415

    from sonusai.utils.reshape import (  # noqa: PLC0415
        get_num_classes_from_predict,  # noqa: PLC0415 (Heavy loading: ~473ms via sonusai.utils.asr)
    )  # noqa: PLC0415
    from sonusai.utils.reshape import reshape_outputs  # noqa: PLC0415

    if truth.shape != predict.shape:
        msg = "truth and predict are not the same shape"
        raise ValueError(msg)

    predict, truth = reshape_outputs(predict=predict, truth=truth, timesteps=timesteps)  # type: ignore[assignment]
    num_classes = get_num_classes_from_predict(predict=predict, timesteps=timesteps)

    # Apply decision to truth input
    truth_binary = np.array(truth >= truth_thr).astype(np.int8)

    ap = np.zeros((num_classes, 1))  # noqa: N806  # Metric: Average Precision
    auc = np.zeros((num_classes, 1))  # noqa: N806  # Metric: Area Under Curve
    thresholds_opt_pr = np.zeros((num_classes, 1))
    thresholds_opt_roc = np.zeros((num_classes, 1))
    eps = np.finfo(float).eps
    for nci in range(num_classes):
        # Average Precision also called area under the PR curve AUCPR and
        # AUC ROC curve using binary-ized truth and continuous prediction probabilities
        # sklearn returns nan if no active truth in a class but w/un-suppressible div-by-zero warning
        if sum(truth_binary[:, nci]) == 0:  # no active truth must be NaN
            thresholds_opt_pr[nci] = np.nan
            thresholds_opt_roc[nci] = np.nan
            auc[nci] = np.nan  # noqa: N806
            ap[nci] = np.nan  # noqa: N806
        else:
            ap[nci] = average_precision_score(truth_binary[:, nci], predict[:, nci], average=None)  # noqa: N806
            auc[nci] = roc_auc_score(truth_binary[:, nci], predict[:, nci], average=None)  # noqa: N806

            # Optimal threshold from PR curve, optimizes f-score
            precision, recall, thrpr = precision_recall_curve(truth_binary[:, nci], predict[:, nci])
            fscore = (2 * precision * recall) / (precision + recall + eps)
            ix = np.argmax(fscore)  # index of largest f1 score
            thresholds_opt_pr[nci] = thrpr[ix]

            # Optimal threshold from ROC curve, optimizes J-statistic (TPR-FPR) or gmean
            fpr, tpr, thrroc = roc_curve(truth_binary[:, nci], predict[:, nci])
            gmeans = np.sqrt(tpr * (1 - fpr))  # gmean seems better behaved
            ix = np.argmax(gmeans)
            thresholds_opt_roc[nci] = thrroc[ix]

    return thresholds_opt_pr, thresholds_opt_roc, ap, auc  # noqa: N806
