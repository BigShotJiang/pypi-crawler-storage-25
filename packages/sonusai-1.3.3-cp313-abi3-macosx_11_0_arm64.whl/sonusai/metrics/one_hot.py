"""Calculate metrics from one-hot prediction and truth data."""

import warnings

import numpy as np
from sklearn.metrics import average_precision_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import multilabel_confusion_matrix
from sklearn.metrics import precision_recall_fscore_support
from sklearn.metrics import roc_auc_score

from sonusai.datatypes import Predict
from sonusai.datatypes import Truth
from sonusai.utils.reshape import get_num_classes_from_predict
from sonusai.utils.reshape import reshape_outputs


def _normalize_predict_threshold(
    predict_thr: float | np.ndarray,
    num_classes: int,
) -> np.ndarray:
    if not isinstance(predict_thr, np.ndarray):
        if predict_thr == 0:
            return np.atleast_1d(0.5) if num_classes == 1 else np.atleast_1d(0)
        return np.atleast_1d(predict_thr)

    if predict_thr.ndim > 1:
        if predict_thr.shape[0] != num_classes:
            msg = "predict_thr has wrong shape"
            raise ValueError(msg)
        return predict_thr

    if predict_thr == 0:
        return np.atleast_1d(0.5)

    return np.atleast_1d(predict_thr)


def _build_decisions(
    truth: np.ndarray,
    predict: np.ndarray,
    predict_thr: np.ndarray,
    truth_thr: float,
    num_classes: int,
) -> tuple[list[int], np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if num_classes == 1:
        labels = list(range(2))
        plabel = np.int8(predict >= predict_thr)
        tlabel = np.int8(truth >= truth_thr)
        return labels, plabel, tlabel, np.array(plabel), np.array(tlabel)

    labels = list(range(num_classes))
    plabel = np.argmax(predict, axis=-1)
    tlabel = np.argmax(truth, axis=-1)

    if predict_thr[0] == 0:
        predb = np.zeros(predict.shape, dtype=np.int8)
        truthb = np.zeros(truth.shape, dtype=np.int8)
        predb[np.arange(predb.shape[0]), plabel] = 1
        if np.sum(truth):
            truthb[np.arange(truthb.shape[0]), tlabel] = 1
        return labels, plabel, tlabel, predb, truthb

    predb = np.array(predict >= predict_thr.transpose()).astype(np.int8)
    truthb = np.array(truth >= truth_thr).astype(np.int8)
    return labels, plabel, tlabel, predb, truthb


def _calculate_per_class_metrics(
    mcm: np.ndarray,
    truthb: np.ndarray,
    predict: np.ndarray,
    num_classes: int,
    eps: float,
) -> np.ndarray:
    metrics = np.zeros((num_classes, 14))
    for nci in range(num_classes):
        TN = mcm[nci, 0, 0]  # noqa: N806  # Math notation: True Negatives
        FP = mcm[nci, 0, 1]  # noqa: N806  # Math notation: False Positives
        FN = mcm[nci, 1, 0]  # noqa: N806  # Math notation: False Negatives
        TP = mcm[nci, 1, 1]  # noqa: N806  # Math notation: True Positives
        ACC = (TP + TN) / (TP + TN + FP + FN + eps)  # noqa: N806  # Metric: Accuracy
        TPR = TP / (TP + FN + eps)  # noqa: N806  # Metric: True Positive Rate
        PPV = TP / (TP + FP + eps)  # noqa: N806  # Metric: Positive Predictive Value
        TNR = TN / (TN + FP + eps)  # noqa: N806  # Metric: True Negative Rate
        FPR = FP / (TN + FP + eps)  # noqa: N806  # Metric: False Positive Rate
        HITFA = TPR - FPR  # noqa: N806  # Metric: Hit minus False Alarm
        F1 = 2 * TP / (2 * TP + FP + FN + eps)  # noqa: N806  # Metric: F1-score
        MCC = (TP * TN - FP * FN) / (np.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)) + eps)  # noqa: N806  # Metric: Matthews Correlation Coefficient
        NT = sum(mcm[nci, 0, :])  # noqa: N806  # Math notation: Number of Negatives
        PT = sum(mcm[nci, 1, :])  # noqa: N806  # Math notation: Number of Positives

        if np.sum(truthb[:, nci]) == 0:
            AP = np.nan  # noqa: N806  # Metric: Average Precision
            AUC = np.nan  # noqa: N806  # Metric: Area Under Curve
        else:
            AP = average_precision_score(truthb[:, nci], predict[:, nci], average=None)  # noqa: N806  # Metric: Average Precision
            if len(np.unique(truthb[:, nci])) < 2:
                AUC = np.nan  # noqa: N806  # Metric: Area Under Curve
            else:
                AUC = roc_auc_score(truthb[:, nci], predict[:, nci], average=None)  # noqa: N806  # Metric: Area Under Curve

        metrics[nci, :] = [
            ACC,
            TPR,
            PPV,
            TNR,
            FPR,
            HITFA,
            F1,
            MCC,
            NT,
            PT,
            TP,
            FP,
            AP,
            AUC,
        ]

    return metrics


def _calculate_average_metrics(
    metrics: np.ndarray,
    mcm: np.ndarray,
    truthb: np.ndarray,
    predb: np.ndarray,
    predict: np.ndarray,
) -> np.ndarray:
    num_classes = metrics.shape[0]
    eps = np.finfo(float).eps
    mavg = np.zeros((3, 8), dtype=np.float32)
    s = np.sum(metrics[:, 9].astype(int))

    with warnings.catch_warnings():
        warnings.filterwarnings(action="ignore", message="Mean of empty slice")
        mavg[0, :] = [
            np.mean(metrics[:, 2]),
            np.mean(metrics[:, 1]),
            np.mean(metrics[:, 6]),
            np.mean(metrics[:, 4]),
            np.mean(metrics[:, 0]),
            np.nanmean(metrics[:, 12]),
            np.nanmean(metrics[:, 13]),
            s,
        ]

    if num_classes > 1:
        tp_sum = np.sum(metrics[:, 10])
        rm = tp_sum / (np.sum(metrics[:, 9]) + eps)
        fp_sum = np.sum(metrics[:, 11])
        fpm = fp_sum / (np.sum(metrics[:, 8]) + eps)
        pm = tp_sum / (tp_sum + fp_sum + eps)
        fn_sum = sum(mcm[:, 1, 0])
        f1m = 2 * tp_sum / (2 * tp_sum + fp_sum + fn_sum + eps)
        tn_sum = sum(mcm[:, 0, 0])
        accm = (tp_sum + tn_sum) / (tp_sum + tn_sum + fp_sum + fn_sum + eps)
        with warnings.catch_warnings():
            warnings.filterwarnings(action="ignore", message="invalid value encountered in true_divide")
            miap = average_precision_score(truthb, predict, average="micro")
        miauc = roc_auc_score(truthb, predict, average="micro") if np.sum(truthb) else np.nan

        mavg[1, :] = [
            pm,
            rm,
            f1m,
            fpm,
            accm,
            miap,
            miauc,
            s,
        ]

        wp, wr, wf1, _ = precision_recall_fscore_support(truthb, predb, average="weighted", zero_division=0)
        if np.sum(truthb):
            taidx = np.sum(truthb, axis=0) > 0
            wap = average_precision_score(truthb[:, taidx], predict[:, taidx], average="weighted")
            if len(np.unique(truthb[:, taidx])) < 2:
                wauc = np.nan
            else:
                wauc = roc_auc_score(truthb[:, taidx], predict[:, taidx], average="weighted")
        else:
            wap = np.nan
            wauc = np.nan

        mavg[2, :] = [wp, wr, wf1, 0, 0, wap, wauc, s]
    else:
        mavg[1, :] = mavg[0, :]
        mavg[2, :] = mavg[0, :]

    return mavg


def one_hot(
    truth: Truth,
    predict: Predict,
    predict_thr: float | np.ndarray = 0,
    truth_thr: float = 0.5,
    timesteps: int = -1,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Calculate metrics from one-hot prediction and truth data.

    Both are one-hot probabilities (or quantized decisions) for each class
    with size [frames, num_classes] or [frames, timesteps, num_classes].

    For metrics that require it, truth and prediction decisions will be made
    using threshold comparison. Some metrics like AP and AUC do not depend on
    `predict_thr` for predictions, but still use `truth_thr` for truth.

    `predict_thr` behavior:
        1. Default = 0: Infers thresholds.
           - Binary (num_classes = 1): Uses >= 0.5.
           - Multi-class/single-label: Uses argmax() on both truth and predict.
        2. `predict_thr` > 0: Scalar or vector [num_classes, 1].
           - Uses `predict_thr` as a binary decision threshold in each class.

    Args:
        truth: Truth data.
        predict: Prediction data.
        predict_thr: Decision threshold(s) applied to predict data.
        truth_thr: Decision threshold applied to truth data.
        timesteps: Number of timesteps. Only set > 0 if ambiguous.

    Returns:
        tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
            A tuple containing:
            - mcm: [num_classes, 2, 2] multiclass confusion matrix counts.
            - metrics: [num_classes, 14] array of metrics:
              [ACC, TPR, PPV, TNR, FPR, HITFA, F1, MCC, NT, PT, TP, FP, AP, AUC].
            - cm: [num_classes, num_classes] confusion matrix.
            - cmn: [num_classes, num_classes] normalized confusion matrix.
            - rmse: [num_classes, 1] root-mean-square error before thresholding.
            - mavg: [3, 8] macro, micro, weighted averages:
              [PPV, TPR, F1, FPR, ACC, mAP, mAUC, TPSUM].

    Raises:
        ValueError: If truth and predict are not the same shape.
        TypeError: If predict_thr is of an invalid type.

    """
    if truth.shape != predict.shape:
        msg = "truth and predict are not the same shape"
        raise ValueError(msg)

    predict, truth = reshape_outputs(predict=predict, truth=truth, timesteps=timesteps)  # type: ignore[assignment]
    num_classes = get_num_classes_from_predict(predict=predict, timesteps=timesteps)

    # Regression metric root-mean-square-error always works
    rmse = np.sqrt(np.mean(np.square(truth - predict), axis=0))

    predict_thr = _normalize_predict_threshold(predict_thr=predict_thr, num_classes=num_classes)

    if not isinstance(predict_thr, np.ndarray):
        msg = f"predict_thr is invalid type: {type(predict_thr)}"
        raise TypeError(msg)

    labels, plabel, tlabel, predb, truthb = _build_decisions(
        truth=truth,
        predict=predict,
        predict_thr=predict_thr,
        truth_thr=truth_thr,
        num_classes=num_classes,
    )

    # Create [num_classes, 2, 2] multilabel confusion matrix (mcm)
    # Note - must include labels or sklearn func. will omit non-exiting classes
    mcm = multilabel_confusion_matrix(truthb, predb, labels=labels)

    if num_classes == 1:
        mcm = mcm[1:]  # remove dim 0 if binary

    # Create [num_classes, num_classes] normalized confusion matrix
    cmn = confusion_matrix(tlabel, plabel, labels=labels, normalize="true")

    # Create [num_classes, num_classes] confusion matrix
    cm = confusion_matrix(tlabel, plabel, labels=labels)

    eps = np.finfo(float).eps
    metrics = _calculate_per_class_metrics(
        mcm=mcm,
        truthb=truthb,
        predict=predict,
        num_classes=num_classes,
        eps=eps,
    )
    mavg = _calculate_average_metrics(
        metrics=metrics,
        mcm=mcm,
        truthb=truthb,
        predb=predb,
        predict=predict,
    )

    return mcm, metrics, cm, cmn, rmse, mavg
