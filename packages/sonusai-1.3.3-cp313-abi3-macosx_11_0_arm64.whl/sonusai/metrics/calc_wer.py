"""Calculate Word Error Rate (WER)."""

from typing import NamedTuple


class WerResult(NamedTuple):
    """Result of a WER calculation.

    Attributes:
        wer: Word Error Rate.
        words: Total number of words in the reference.
        substitutions: Rate of substitutions.
        deletions: Rate of deletions.
        insertions: Rate of insertions.

    """

    wer: float
    words: int
    substitutions: float
    deletions: float
    insertions: float


def calc_wer(hypothesis: list[str] | str, reference: list[str] | str) -> WerResult:
    """Compute average Word Error Rate between two texts.

    Supports strings or lists of strings.

    Args:
        hypothesis: The hypothesis sentence(s) as a string or list of strings.
        reference: The reference sentence(s) as a string or list of strings.

    Returns:
        WerResult: Result object containing WER and its components.

    """
    import jiwer  # noqa: PLC0415 (Heavy loading: ~860ms)

    transformation = jiwer.Compose(
        [
            jiwer.ToLowerCase(),
            jiwer.RemovePunctuation(),
            jiwer.RemoveWhiteSpace(replace_by_space=True),
            jiwer.RemoveMultipleSpaces(),
            jiwer.Strip(),
            jiwer.RemoveEmptyStrings(),
            jiwer.ReduceToListOfListOfWords(word_delimiter=" "),
        ]
    )

    if isinstance(reference, str):
        reference = [reference]
    if isinstance(hypothesis, str):
        hypothesis = [hypothesis]

    # jiwer does not allow empty string
    measures = {"insertions": 0, "substitutions": 0, "deletions": 0, "hits": 0}
    if any(len(t) == 0 for t in reference):
        if any(len(t) != 0 for t in hypothesis):
            measures["insertions"] = len(hypothesis)
    else:
        measures = jiwer.compute_measures(
            truth=reference,
            hypothesis=hypothesis,
            truth_transform=transformation,
            hypothesis_transform=transformation,
        )

    errors = measures["substitutions"] + measures["deletions"] + measures["insertions"]
    words = measures["hits"] + measures["substitutions"] + measures["deletions"]

    if words != 0:
        wer = errors / words
        substitutions_rate = measures["substitutions"] / words
        deletions_rate = measures["deletions"] / words
        insertions_rate = measures["insertions"] / words
    else:
        wer = float("inf")
        substitutions_rate = float("inf")
        deletions_rate = float("inf")
        insertions_rate = float("inf")

    return WerResult(
        wer=wer,
        words=int(words),
        substitutions=substitutions_rate,
        deletions=deletions_rate,
        insertions=insertions_rate,
    )
