"""SonusAI variables CLI.

Usage:
  vars [-h]

Options:
  -h, --help   Display this help.

List custom SonusAI variables.
"""

from os import environ

from docopt import docopt
from rich.console import Console

from sonusai import __version__ as sai_version
from sonusai import exception_handler
from sonusai.utils.docstring import trim_docstring
from sonusai.utils.keyboard_interrupt import register_keyboard_interrupt


def main() -> None:
    """Run the vars CLI."""
    console = Console()
    docopt(trim_docstring(__doc__), version=sai_version, options_first=True)

    items = ["DEEPGRAM_API_KEY", "GOOGLE_SPEECH_API_KEY"]
    items += sorted([item for item in environ if item.upper().startswith("AIXP_WHISPER_")])

    for item in items:
        if item in environ:
            console.print(f"{item}={environ[item]}")
        else:
            console.print(f"{item} is not set")


if __name__ == "__main__":
    register_keyboard_interrupt()
    try:
        main()
    except Exception as e:  # noqa: BLE001 (Global CLI exception handler)
        exception_handler(e)
