"""Parser for rand() expressions in source and mixture definitions."""

from __future__ import annotations

import decimal
import re
from random import uniform

import pyparsing as pp

SIGNIFICANT_DIGITS = 6
RAND_EXPRESSION_PATTERN = r"rand\s*(\()?(?:[^()]|\([^()]*\))*\)?"
MISSING_COMMA_PATTERN = r"\d+\s+[-+]?\d+"


def _build_rand_parser(parse_action: pp.ParseAction | None = None) -> pp.ParserElement:
    """Build a recursive parser for `rand(min, max)` expressions."""
    expr = pp.Forward()
    number = pp.pyparsing_common.number
    rand_parser = (
        pp.Literal("rand")
        + pp.Literal("(").suppress()
        + pp.Optional(pp.White()).suppress()
        + (number | expr)("min_val")
        + pp.Optional(pp.White()).suppress()
        + pp.Literal(",").suppress()
        + pp.Optional(pp.White()).suppress()
        + (number | expr)("max_val")
        + pp.Optional(pp.White()).suppress()
        + pp.Literal(")").suppress()
    )
    expr << rand_parser

    if parse_action is not None:
        rand_parser.set_parse_action(parse_action)

    return rand_parser


def _randomize_values(tokens: pp.ParseResults) -> str:
    """Generate a random value for a parsed `rand(min, max)` expression."""
    min_val = float(tokens["min_val"])
    max_val = float(tokens["max_val"])

    if min_val > max_val:
        msg = f"Min value ({min_val}) cannot be greater than max value ({max_val})"
        raise ValueError(msg)

    value = uniform(min_val, max_val)  # noqa: S311
    decimal.getcontext().prec = SIGNIFICANT_DIGITS
    return str(decimal.Decimal(value).normalize())


def _count_top_level_commas(text: str) -> int:
    """Count commas that are not nested inside parentheses."""
    nesting_level = 0
    comma_count = 0

    for char in text:
        if char == "(":
            nesting_level += 1
        elif char == ")":
            nesting_level -= 1
        elif char == "," and nesting_level == 0:
            comma_count += 1

    return comma_count


def _validate_nested_expression(expr_text: str, validator: pp.ParserElement) -> bool:
    """Validate a nested rand expression."""
    try:
        validator.parse_string(expr_text, parse_all=True)
    except pp.ParseException:
        return False
    return True


def _validate_non_numeric_params(params: list[str], expr_text: str, validator: pp.ParserElement) -> list[str]:
    """Collect malformed messages for invalid non-numeric parameters."""
    malformations: list[str] = []

    for idx, param in enumerate(params):
        if "rand" in param:
            if not _validate_nested_expression(param, validator):
                malformations.append(f"Invalid nested expression '{param}' in '{expr_text}'")
            continue

        if not is_numeric(param):
            param_name = "first" if idx == 0 else "second"
            malformations.append(f"Non-numeric {param_name} parameter '{param}' in '{expr_text}'")

    return malformations


def _validate_expression(match_text: str, validator: pp.ParserElement) -> list[str]:
    """Validate one potential rand expression and return malformation messages."""
    malformations: list[str] = []

    if "rand" in match_text and "(" not in match_text:
        malformations.append(f"Missing opening parenthesis in '{match_text}'")
    elif not match_text.endswith(")"):
        malformations.append(f"Missing closing parenthesis in '{match_text}'")
    else:
        try:
            validator.parse_string(match_text, parse_all=True)
        except pp.ParseException:
            param_text = match_text[match_text.find("(") + 1 : match_text.rfind(")")]
            comma_count = _count_top_level_commas(param_text)

            if comma_count == 0:
                if not param_text.strip():
                    malformations.append(f"Missing parameters in '{match_text}' (expected 2)")
                elif re.search(MISSING_COMMA_PATTERN, param_text):
                    malformations.append(f"Missing comma between parameters in '{match_text}'")
                else:
                    malformations.append(f"Too few parameters in '{match_text}' (expected 2, got 1)")
            elif comma_count > 1:
                malformations.append(f"Too many parameters in '{match_text}' (expected 2, got {comma_count + 1})")
            else:
                params = [p.strip() for p in split_params_respecting_nesting(param_text)]
                malformations.extend(_validate_non_numeric_params(params, match_text, validator))

    return malformations


def _collect_malformations(directive: str, validator: pp.ParserElement) -> list[str]:
    """Collect all malformed rand expression messages from a directive string."""
    malformations: list[str] = []
    potential_expressions = re.finditer(RAND_EXPRESSION_PATTERN, directive)
    for match in potential_expressions:
        malformations.extend(_validate_expression(match.group(0), validator))
    return malformations


def rand(directive: str) -> str:
    """Evaluate the 'rand(min, max)' directive.

    Replaces all 'rand' directives in the text with a random value within
    the specified range. Supports nested 'rand' expressions.

    Args:
        directive: Directive string to evaluate.

    Returns:
        str: Text with all 'rand' directives replaced with random values.

    Raises:
        ValueError: If the expression cannot be parsed or is malformed.

    """
    if not directive:
        return directive

    rand_function = _build_rand_parser(parse_action=_randomize_values)
    validator = _build_rand_parser()

    try:
        malformations = _collect_malformations(directive, validator)

        if malformations:
            msg = f"Malformed rand directive: {'; '.join(malformations)}"
            raise ValueError(msg)

        # If validation passes, try to transform
        result = rand_function.transform_string(directive)
    except pp.ParseException as e:
        msg = f"Invalid rand expression in '{directive}': {e!s}"
        raise ValueError(msg) from e

    return result


def is_numeric(text: str) -> bool:
    """Check if the text is a valid number (including scientific notation)."""
    numeric_pattern = r"^[-+]?(\d+(\.\d*)?|\.\d+)([eE][-+]?\d+)?$"
    return bool(re.match(numeric_pattern, text))


def split_params_respecting_nesting(param_text: str) -> list:
    """Split parameters by comma while respecting nested parentheses."""
    result = []
    current_param = []
    nesting_level = 0

    for char in param_text:
        if char == "(":
            nesting_level += 1
            current_param.append(char)
        elif char == ")" and nesting_level > 0:
            nesting_level -= 1
            current_param.append(char)
        elif char == "," and nesting_level == 0:
            result.append("".join(current_param))
            current_param = []
        else:
            current_param.append(char)

    if current_param:
        result.append("".join(current_param))

    return result
