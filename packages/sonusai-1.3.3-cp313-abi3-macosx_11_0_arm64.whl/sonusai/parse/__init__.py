"""Directives parsing utilities for source and mixture definitions."""
