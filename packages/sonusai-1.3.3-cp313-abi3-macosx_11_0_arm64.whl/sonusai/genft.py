"""Generate SonusAI feature/truth data from a SonusAI mixture database.

Usage:
    genft [-hvsn] [-i MIXID] LOC

Options:
    -h, --help
    -v, --verbose               Be verbose.
    -i MIXID, --mixid MIXID     Mixture ID(s) to generate. [default: *].
    -s, --segsnr                Save segsnr. [default: False].
    -n, --nopar                 Do not run in parallel. [default: False].

Inputs:
    LOC         A SonusAI mixture database directory.
    MIXID       A glob of mixture ID(s) to generate.

Outputs the following to the mixture database directory:
    <id>/
        feature.pkl
        truth_f.pkl
        segsnr.pkl (optional)
        metadata.txt
    genft.log
"""

import time
from dataclasses import dataclass
from functools import partial
from pathlib import Path
from typing import Any

from docopt import docopt

import sonusai
from sonusai import create_file_handler
from sonusai import exception_handler
from sonusai import initial_log_messages
from sonusai import logger
from sonusai import update_console_handler
from sonusai.constants import SAMPLE_RATE
from sonusai.datatypes import GeneralizedIDs
from sonusai.datatypes import GenFTData
from sonusai.mixture import MixtureDatabase
from sonusai.mixture.data_io import write_cached_data
from sonusai.mixture.helpers import check_audio_files_exist
from sonusai.mixture.helpers import write_mixture_metadata
from sonusai.utils.docstring import trim_docstring
from sonusai.utils.human_readable_size import human_readable_size
from sonusai.utils.keyboard_interrupt import register_keyboard_interrupt
from sonusai.utils.parallel import par_track
from sonusai.utils.parallel import track
from sonusai.utils.seconds_to_hms import seconds_to_hms


@dataclass(frozen=True)
class GenFTOptions:
    """Runtime options for feature/truth generation."""

    compute_truth: bool = True
    compute_segsnr: bool = False
    cache: bool = False
    show_progress: bool = False
    force: bool = True


def genft(
    location: str | Path,
    mixids: GeneralizedIDs = "*",
    options: GenFTOptions | None = None,
    no_par: bool = False,
) -> list[GenFTData]:
    """Generate features and truth for specified mixtures.

    Args:
        location: Path to the mixture database.
        mixids: IDs of mixtures to process.
        options: Runtime generation options.
        no_par: If True, do not use parallel processing.

    Returns:
        A list of GenFTData objects containing the generated data.

    """
    effective_options = options or GenFTOptions()
    mixdb = MixtureDatabase(location)
    mixids = mixdb.mixids_to_list(mixids)

    progress = track(total=len(mixids), disable=not effective_options.show_progress)
    results = par_track(
        partial(
            _genft_kernel,
            mixdb=mixdb,
            options=effective_options,
        ),
        mixids,
        progress=progress,
        no_par=no_par,
    )
    progress.close()

    return results


def _genft_kernel(
    m_id: int,
    mixdb: MixtureDatabase,
    options: GenFTOptions,
) -> GenFTData:
    """Kernel function for generating features and truth for a single mixture.

    Args:
        m_id: Mixture ID to process.
        mixdb: MixtureDatabase instance.
        options: Runtime generation options.

    Returns:
        A GenFTData object containing the generated data.

    """
    write_func = partial(write_cached_data, location=mixdb.location, name="mixture", index=mixdb.mixture(m_id).name)

    result = GenFTData()

    mixture = mixdb.mixture_mixture(m_id)

    feature, truth_f = mixdb.mixture_ft(m_id=m_id, mixture=mixture, force=options.force)
    result.feature = feature
    items: dict[str, Any] = {"feature": feature}

    if options.compute_truth:
        result.truth_f = truth_f
        items["truth_f"] = truth_f

    if options.compute_segsnr:
        segsnr_t = mixdb.mixture_segsnr_t(m_id)
        result.segsnr = mixdb.mixture_segsnr(m_id=m_id, segsnr_t=segsnr_t, force=options.force, cache=options.cache)

    if options.cache:
        write_func(items=items)
        write_mixture_metadata(mixdb, m_id=m_id)

    return result


def main() -> None:
    """Execute the genft CLI."""
    args = docopt(trim_docstring(__doc__), version=sonusai.__version__, options_first=True)

    verbose = args["--verbose"]
    mixids = args["--mixid"]
    compute_segsnr = args["--segsnr"]
    no_par = args["--nopar"]
    location = args["LOC"]

    start_time = time.monotonic()

    create_file_handler(str(Path(location) / "genft.log"), verbose)
    update_console_handler(verbose)
    initial_log_messages("genft")

    logger.info(f"Load mixture database from {location}")
    mixdb = MixtureDatabase(location)
    mixids = mixdb.mixids_to_list(mixids)

    total_samples = mixdb.total_samples(mixids)
    duration = total_samples / SAMPLE_RATE
    total_transform_frames = total_samples // mixdb.ft_config.overlap
    total_feature_frames = total_samples // mixdb.feature_step_samples

    logger.info("")
    logger.info(f"Found {len(mixids):,} mixtures to process")
    logger.info(
        f"{total_samples:,} samples, "
        f"{total_transform_frames:,} transform frames, "
        f"{total_feature_frames:,} feature frames"
    )

    check_audio_files_exist(mixdb)

    genft(
        location=location,
        mixids=mixids,
        options=GenFTOptions(compute_segsnr=compute_segsnr, cache=True, show_progress=True),
        no_par=no_par,
    )

    logger.info(f"Wrote {len(mixids)} mixtures to {location}")
    logger.info("")
    logger.info(f"Duration: {seconds_to_hms(seconds=duration)}")
    logger.info(
        f"feature:  {human_readable_size(total_feature_frames * mixdb.fg_stride * mixdb.feature_parameters * 4, 1)}"
    )
    logger.info(f"truth_f:  {human_readable_size(total_feature_frames * mixdb.num_classes * 4, 1)}")
    if compute_segsnr:
        logger.info(f"segsnr:   {human_readable_size(total_transform_frames * 4, 1)}")

    end_time = time.monotonic()
    logger.info(f"Completed in {seconds_to_hms(seconds=end_time - start_time)}")
    logger.info("")


if __name__ == "__main__":
    register_keyboard_interrupt()
    try:
        main()
    except Exception as e:  # noqa: BLE001 (Global CLI exception handler)
        exception_handler(e)
