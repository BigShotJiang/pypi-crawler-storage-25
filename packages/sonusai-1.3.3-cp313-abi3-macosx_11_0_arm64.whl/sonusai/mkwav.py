"""Create WAV files from a SonusAI database.

Usage:
    mkwav [-hvtsn] [-i MIXID] LOC

Options:
    -h, --help
    -v, --verbose                   Be verbose.
    -i MIXID, --mixid MIXID         Mixture ID(s) to generate. [default: *].
    -t, --source                    Write source file.
    -s, --sources                   Write sources files.
    -n, --noise                     Write noise file.

Inputs:
    LOC         A SonusAI mixture database directory.
    MIXID       A glob of mixture ID(s) to generate.

Outputs the following to the mixture database directory:
    <id>/
        mixture.wav:        mixture
        source.wav:         source (optional)
        source_<c>.wav:     source <category> (optional)
        noise.wav:          noise (optional)
        metadata.txt
    mkwav.log
"""

from __future__ import annotations

import time
from functools import partial
from pathlib import Path

from docopt import docopt

import sonusai
from sonusai import create_file_handler
from sonusai import exception_handler
from sonusai import initial_log_messages
from sonusai import logger
from sonusai import update_console_handler
from sonusai.mixture import MixtureDatabase
from sonusai.mixture.helpers import check_audio_files_exist
from sonusai.mixture.helpers import write_mixture_metadata
from sonusai.utils.docstring import trim_docstring
from sonusai.utils.keyboard_interrupt import register_keyboard_interrupt
from sonusai.utils.numeric_conversion import float_to_int16
from sonusai.utils.parallel import par_track
from sonusai.utils.parallel import track
from sonusai.utils.seconds_to_hms import seconds_to_hms
from sonusai.utils.write_audio import write_audio


def _process_mixture(m_id: int, location: str, write_target: bool, write_targets: bool, write_noise: bool) -> None:
    """Process a single mixture and write requested WAV files.

    Args:
        m_id: Mixture ID to process.
        location: Path to the mixture database.
        write_target: Whether to write the primary source WAV file.
        write_targets: Whether to write all source category WAV files.
        write_noise: Whether to write the noise WAV file.

    """
    mixdb = MixtureDatabase(location)

    index = mixdb.mixture(m_id).name
    location_path = Path(mixdb.location) / "mixture" / index
    location_path.mkdir(parents=True, exist_ok=True)

    write_audio(name=str(location_path / "mixture.wav"), audio=float_to_int16(mixdb.mixture_mixture(m_id)))
    if write_target:
        write_audio(name=str(location_path / "source.wav"), audio=float_to_int16(mixdb.mixture_source(m_id)))
    if write_targets:
        for category, source in mixdb.mixture_sources(m_id).items():
            write_audio(name=str(location_path / f"sources_{category}.wav"), audio=float_to_int16(source))
    if write_noise:
        write_audio(name=str(location_path / "noise.wav"), audio=float_to_int16(mixdb.mixture_noise(m_id)))

    write_mixture_metadata(mixdb, m_id=m_id)


def main() -> None:
    """Execute the mkwav CLI."""
    args = docopt(trim_docstring(__doc__), version=sonusai.__version__, options_first=True)

    verbose = args["--verbose"]
    mixid = args["--mixid"]
    write_source = args["--source"]
    write_sources = args["--sources"]
    write_noise = args["--noise"]
    location = args["LOC"]

    start_time = time.monotonic()

    create_file_handler(str(Path(location) / "mkwav.log"), verbose)
    update_console_handler(verbose)
    initial_log_messages("mkwav")

    logger.info(f"Load mixture database from {location}")
    mixdb = MixtureDatabase(location)
    mixid = mixdb.mixids_to_list(mixid)

    total_samples = mixdb.total_samples(mixid)

    logger.info("")
    logger.info(f"Found {len(mixid):,} mixtures to process")
    logger.info(f"{total_samples:,} samples")

    check_audio_files_exist(mixdb)

    progress = track(total=len(mixid))
    par_track(
        partial(
            _process_mixture,
            location=location,
            write_target=write_source,
            write_targets=write_sources,
            write_noise=write_noise,
        ),
        mixid,
        progress=progress,
    )
    progress.close()

    logger.info(f"Wrote {len(mixid)} mixtures to {location}")
    logger.info("")
    end_time = time.monotonic()
    logger.info(f"Completed in {seconds_to_hms(seconds=end_time - start_time)}")
    logger.info("")


if __name__ == "__main__":
    register_keyboard_interrupt()
    try:
        main()
    except Exception as e:  # noqa: BLE001 (Global CLI exception handler)
        exception_handler(e)
