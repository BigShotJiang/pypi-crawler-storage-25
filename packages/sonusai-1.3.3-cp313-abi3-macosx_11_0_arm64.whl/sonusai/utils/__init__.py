"""Core utility functions and classes for the SonusAI project.

This package contains miscellaneous utilities for audio processing, string
manipulation, data structures, and more.
"""

from .asr import ASRResult

__all__ = ["ASRResult"]
