"""Utilities for calculating the number of frames in an audio batch."""


def get_frames_per_batch(batch_size: int, timesteps: int) -> int:
    """Calculate the total number of frames in a batch.

    Args:
        batch_size: The number of sequences in a batch.
        timesteps: The number of timesteps per sequence.

    Returns:
        The total number of frames.

    """
    return batch_size if timesteps == 0 else batch_size * timesteps
