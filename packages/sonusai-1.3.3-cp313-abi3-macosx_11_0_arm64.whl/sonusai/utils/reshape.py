"""Utilities for reshaping audio feature and prediction data for model input/output."""

import numpy as np

from sonusai.datatypes import Feature
from sonusai.datatypes import Predict
from sonusai.datatypes import Truth


def get_input_shape(feature: Feature) -> tuple[int, ...]:
    """Return the input shape of the feature (excluding the batch dimension).

    Args:
        feature: The feature NumPy array.

    Returns:
        The shape of a single feature sample.

    """
    return feature.shape[1:]


def reshape_inputs(
    feature: Feature,
    batch_size: int,
    **options: object,
) -> tuple[Feature, Truth | None]:
    """Reshape feature and truth data for neural network input.

    Converts feature of size [frames, strides, feature_parameters] into one of several options
    based on the provided parameters.

    If timesteps > 0:
      - no-flatten, no-channel:   [sequences, timesteps, strides, feature_parameters]
      - flatten, no-channel:      [sequences, timesteps, strides*feature_parameters]
      - no-flatten, add-1channel: [sequences, timesteps, strides, feature_parameters, 1]
      - flatten, add-1channel:    [sequences, timesteps, strides*feature_parameters, 1]

    The number of frames is trimmed to be a multiple of both `timesteps` and `batch_size`.
    A channel dimension can be added as the last dimension.

    Args:
        feature: The input feature array.
        batch_size: The batch size for the model.
        truth: Optional ground truth labels (default: None).
        timesteps: The number of timesteps for recurrent models (default: 0).
        flatten: Whether to flatten the strides and feature_parameters dimensions (default: False).
        add1ch: Whether to append a channel dimension of size 1 (default: False).
        **options: Optional keyword options for `truth`, `timesteps`,
            `flatten`, and `add1ch`.

    Returns:
        A tuple of (reshaped_feature, reshaped_truth).

    Raises:
        ValueError: If the number of frames in feature and truth do not match.

    """
    truth = options.get("truth")
    timesteps = int(options.get("timesteps", 0))
    flatten = bool(options.get("flatten", False))
    add1ch = bool(options.get("add1ch", False))

    frames, strides, feature_parameters = feature.shape
    if truth is not None:
        truth_frames, num_classes = truth.shape
        # Double-check correctness of inputs
        if frames != truth_frames:
            msg = "Frames in feature and truth do not match"
            raise ValueError(msg)
    else:
        num_classes = 0

    if flatten:
        feature = np.reshape(feature, (frames, strides * feature_parameters))

    # Reshape for Keras/TF recurrent models that require timesteps/sequence length dimension
    if timesteps > 0:
        feature, truth = _reshape_timestep_inputs(
            feature=feature,
            truth=truth,
            context={
                "timesteps": timesteps,
                "batch_size": batch_size,
                "strides": strides,
                "feature_parameters": feature_parameters,
                "num_classes": num_classes,
                "frames": frames,
            },
        )
    else:
        # Drop frames if remainder exists (not fitting into a multiple of new number of sequences)
        fr2drop = feature.shape[0] % batch_size
        if fr2drop > 0:
            feature = feature[0:-fr2drop,]
            if truth is not None:
                truth = truth[0:-fr2drop,]

    # Add channel dimension if required for input to model (i.e. for cnn type input)
    if add1ch:
        feature = np.expand_dims(feature, axis=feature.ndim)  # add as last/outermost dim

    return feature, truth


def _reshape_timestep_inputs(
    feature: Feature,
    truth: Truth | None,
    context: dict,
) -> tuple[Feature, Truth | None]:
    timesteps = context["timesteps"]
    sequences, fr2drop = _trim_for_timesteps(feature, timesteps, context["batch_size"], context["frames"])
    if fr2drop:
        feature = feature[0:-fr2drop,]
        if truth is not None:
            truth = truth[0:-fr2drop,]

    if feature.ndim == 2:
        feature = np.reshape(feature, (sequences, timesteps, context["strides"] * context["feature_parameters"]))
    elif feature.ndim == 3:
        feature = np.reshape(feature, (sequences, timesteps, context["strides"], context["feature_parameters"]))

    if truth is not None:
        truth = np.reshape(truth, (sequences, timesteps, context["num_classes"]))

    return feature, truth


def _trim_for_timesteps(feature: Feature, timesteps: int, batch_size: int, frames: int) -> tuple[int, int]:
    sequences = frames // timesteps
    frames_rem = frames % timesteps
    batch_rem = (frames // timesteps) % batch_size
    fr2drop = frames_rem + (batch_rem * timesteps)
    return sequences - batch_rem, fr2drop


def get_num_classes_from_predict(predict: Predict, timesteps: int = 0) -> int:
    """Determine the number of classes from prediction data.

    Args:
        predict: The prediction results array.
        timesteps: The number of timesteps if applicable (default: 0).

    Returns:
        The number of classes.

    """
    num_dims = predict.ndim
    dims = predict.shape

    if num_dims == 3 or (num_dims == 2 and timesteps > 0):
        # 2D with timesteps - [frames, timesteps]
        if num_dims == 2:
            return 1

        # 3D - [frames, timesteps, num_classes]
        return dims[2]

    # 1D - [frames]
    if num_dims == 1:
        return 1

    # 2D without timesteps - [frames, num_classes]
    return dims[1]


def reshape_outputs(predict: Predict, truth: Truth | None = None, timesteps: int = 0) -> tuple[Predict, Truth | None]:
    """Reshape model output data to remove the timestep dimension.

    Handles reshaping of prediction and optional ground truth data from
    [frames, timesteps, num_classes] to [frames * timesteps, num_classes].

    Args:
        predict: The model prediction array.
        truth: The ground truth array (default: None).
        timesteps: The number of timesteps (default: 0).

    Returns:
        A tuple of (reshaped_predict, reshaped_truth).

    Raises:
        ValueError: If predict and truth shapes do not match or if the number
            of dimensions is unsupported.

    """
    if truth is not None and predict.shape != truth.shape:
        msg = "predict and truth shapes do not match"
        raise ValueError(msg)

    ndim = predict.ndim
    shape = predict.shape

    if not (0 < ndim <= 3):
        msg = f"do not know how to reshape data with {ndim} dimensions"
        raise ValueError(msg)

    if ndim == 3 or (ndim == 2 and timesteps > 0):
        num_classes = (
            1 if ndim == 2 else shape[2]
        )  # 2D with timesteps - [frames, timesteps] else 3D - [frames, timesteps, num_classes]

        # reshape to remove timestep dimension
        shape = (shape[0] * shape[1], num_classes)
        predict = np.reshape(predict, shape)
        if truth is not None:
            truth = np.reshape(truth, shape)
    elif ndim == 1:
        # convert to 2D - [frames, 1]
        predict = np.expand_dims(predict, 1)
        if truth is not None:
            truth = np.expand_dims(truth, 1)

    return predict, truth
