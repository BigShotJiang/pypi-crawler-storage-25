"""Utilities for stratified shuffling and splitting of mixture databases."""

import random
from copy import deepcopy

import numpy as np

from sonusai import logger
from sonusai.mixture.class_count import get_class_count_from_mixids
from sonusai.mixture.mixdb import MixtureDatabase


def _build_class_mixids(mixdb: MixtureDatabase) -> dict[int, list[int]]:
    a_class_mixid: dict[int, list[int]] = {i + 1: [] for i in range(mixdb.num_classes)}
    for mixid, mixture in enumerate(mixdb.mixtures()):
        class_count = get_class_count_from_mixids(mixdb, mixid)
        if any(class_count):
            for class_index in mixdb.target_files[mixture.targets[0].file_id].class_indices:
                a_class_mixid[class_index].append(mixid)
        else:
            a_class_mixid[mixdb.num_classes].append(mixid)
    return a_class_mixid


def _split_class_mixids(
    mixdb: MixtureDatabase,
    a_class_mixid: dict[int, list[int]],
    vsplit: float,
    rnd_seed: int | None,
) -> tuple[list[list[int]], list[list[int]], np.ndarray, np.ndarray, np.ndarray]:
    t_class_mixid: list[list[int]] = [[] for _ in range(mixdb.num_classes)]
    v_class_mixid: list[list[int]] = [[] for _ in range(mixdb.num_classes)]
    a_num_mixid = np.zeros(mixdb.num_classes, dtype=np.int32)
    t_num_mixid = np.zeros(mixdb.num_classes, dtype=np.int32)
    v_num_mixid = np.zeros(mixdb.num_classes, dtype=np.int32)

    for ci in range(mixdb.num_classes):
        a_num_mixid[ci] = len(a_class_mixid[ci + 1])
        t_num_mixid[ci] = int(np.floor(a_num_mixid[ci] * (1 - vsplit)))
        v_num_mixid[ci] = a_num_mixid[ci] - t_num_mixid[ci]
        indices = [*range(a_num_mixid[ci])]
        if rnd_seed is not None:
            random.shuffle(indices)

        t_class_mixid[ci] = [a_class_mixid[ci + 1][ii] for ii in indices[0 : t_num_mixid[ci]]]
        v_class_mixid[ci] = [a_class_mixid[ci + 1][ii] for ii in indices[t_num_mixid[ci] :]]

    return t_class_mixid, v_class_mixid, a_num_mixid, t_num_mixid, v_num_mixid


def _compute_training_pass_params(t_num_mixid: np.ndarray) -> tuple[np.ndarray, int, int, int]:
    nz_indices = np.where(t_num_mixid > 0)[0]
    min_class = min(t_num_mixid[nz_indices])
    n0 = int(np.ceil(min_class / 3))
    n3 = int(n0)
    n2 = int(max(min_class - n0 - n3, 0))
    return nz_indices, n0, n2, n3


def _extract_first_pass(
    mixdb: MixtureDatabase, t_num_mixid2: np.ndarray, tt: list[list[int]], t_mixid: list[int], n0: int
) -> None:
    for _ in range(n0):
        for ci in range(mixdb.num_classes):
            if t_num_mixid2[ci] > 0:
                t_mixid.append(tt[ci][0])
                del tt[ci][0]
                t_num_mixid2[ci] = len(tt[ci])


def _extract_weighted_pass(context: dict, n2: int) -> None:
    if n2 <= 0:
        return

    min_class = int(np.min(context["t_num_mixid2"] - context["n3"]))
    class_count = np.floor((context["t_num_mixid2"] - context["n3"]) / min_class)
    for _ in range(min_class):
        for ci in range(context["mixdb"].num_classes):
            if class_count[ci] > 0:
                for _ in range(int(class_count[ci])):
                    context["t_mixid"].append(context["tt"][ci][0])
                    del context["tt"][ci][0]
                    context["t_num_mixid2"][ci] = len(context["tt"][ci])


def _stratify_training_mixids(
    mixdb: MixtureDatabase,
    t_class_mixid: list[list[int]],
    t_num_mixid: np.ndarray,
) -> list[int]:
    tt = deepcopy(t_class_mixid)
    t_num_mixid2 = deepcopy(t_num_mixid)
    t_mixid: list[int] = []

    nz_indices, n0, n2, n3 = _compute_training_pass_params(t_num_mixid)
    logger.info(
        f"Stratifying training, x1 cnt {n0}: x(class_count/{n2}): x1 cnt {n3} x1, "
        f"for {len(nz_indices)} populated classes"
    )

    _extract_first_pass(mixdb, t_num_mixid2, tt, t_mixid, n0)
    _extract_weighted_pass(
        {
            "mixdb": mixdb,
            "t_num_mixid2": t_num_mixid2,
            "tt": tt,
            "t_mixid": t_mixid,
            "n3": n3,
        },
        n2,
    )
    t_mixid = _extract_remaining_mixids(mixdb, t_mixid, t_num_mixid2, tt)

    if len(t_mixid) != sum(t_num_mixid):
        logger.warning("Final stratified training list length does not match starting list length.")
    if any(t_num_mixid2) or any(tt):
        logger.warning("Remaining training mixid list not empty.")

    return t_mixid


def _stratify_validation_mixids(
    mixdb: MixtureDatabase, v_class_mixid: list[list[int]], v_num_mixid: np.ndarray
) -> list[int]:
    vv = deepcopy(v_class_mixid)
    v_num_mixid2 = deepcopy(v_num_mixid)
    v_mixid = _extract_remaining_mixids(mixdb, [], v_num_mixid2, vv)

    if len(v_mixid) != sum(v_num_mixid):
        logger.warning("Final stratified validation list length does not match starting lists length.")
    if any(v_num_mixid2) or any(vv):
        logger.warning("Remaining validation mixid list not empty.")
    return v_mixid


def stratified_shuffle_split_mixid(
    mixdb: MixtureDatabase,
    vsplit: float = 0.2,
    nsplit: int = 0,
    rnd_seed: int | None = 0,
) -> tuple[list[int], list[int], np.ndarray, np.ndarray]:
    """Create training and validation lists of mixture IDs from a database.

    The mixtures are stratified across all populated classes and randomly
    shuffled if a seed is provided.

    Args:
        mixdb: The mixture database.
        vsplit: Fractional split for validation (0.0 to 1.0, default 0.2).
        nsplit: Number of splits (currently unused).
        rnd_seed: Seed for reproducible shuffling (default 0). If None, no
            shuffling is performed.

    Returns:
        A tuple containing:
            - list of mixture IDs for training.
            - list of mixture IDs for validation.
            - array of class counts for training.
            - array of class counts for validation.

    Raises:
        ValueError: If `vsplit` is not between 0 and 1.

    """
    if vsplit < 0 or vsplit > 1:
        msg = "vsplit must be between 0 and 1"
        raise ValueError(msg)

    if rnd_seed is not None:
        random.seed(rnd_seed)

    a_class_mixid = _build_class_mixids(mixdb)
    t_class_mixid, v_class_mixid, _, t_num_mixid, v_num_mixid = _split_class_mixids(
        mixdb,
        a_class_mixid,
        vsplit,
        rnd_seed,
    )

    if np.any(~(t_num_mixid > 0)):
        logger.warning(f"Some classes have zero coverage: {np.where(~(t_num_mixid > 0))[0]}")

    t_mixid = _stratify_training_mixids(mixdb, t_class_mixid, t_num_mixid)
    v_mixid = _stratify_validation_mixids(mixdb, v_class_mixid, v_num_mixid)

    return t_mixid, v_mixid, t_num_mixid, v_num_mixid


def _extract_remaining_mixids(
    mixdb: MixtureDatabase,
    mixid: list[int],
    num_mixid: np.ndarray,
    class_mixid: list[list[int]],
) -> list[int]:
    """Extract remaining mixture IDs, one from each class until empty.

    Args:
        mixdb: The mixture database.
        mixid: The list to which extracted IDs will be appended.
        num_mixid: Array of remaining counts for each class.
        class_mixid: Lists of mixture IDs for each class.

    Returns:
        The updated list of mixture IDs.

    """
    for _ in range(max(num_mixid)):
        for ci in range(mixdb.num_classes):
            if num_mixid[ci] > 0:
                # append first
                mixid.append(class_mixid[ci][0])
                del class_mixid[ci][0]
                num_mixid[ci] = len(class_mixid[ci])

    return mixid
