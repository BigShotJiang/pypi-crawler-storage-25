"""Data structures for storing file path information."""

from dataclasses import dataclass


@dataclass(frozen=True)
class PathInfo:
    """Information about a file path and its associated audio file.

    Attributes:
        abs_path: The absolute path to the data file.
        audio_filepath: The relative path or filename of the audio file.

    """

    abs_path: str
    audio_filepath: str
