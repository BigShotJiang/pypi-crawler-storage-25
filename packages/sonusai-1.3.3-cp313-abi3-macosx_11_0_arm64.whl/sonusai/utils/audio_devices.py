"""Utilities for interacting with audio devices via PyAudio."""

import pyaudio


def get_input_device_index_by_name(p: pyaudio.PyAudio, name: str | None = None) -> int:
    """Find the index of an input device by its name.

    Args:
        p: The PyAudio instance.
        name: The name of the input device to find (default: None).

    Returns:
        The index of the matching input device.

    Raises:
        ValueError: If the device cannot be found.

    """
    info = p.get_host_api_info_by_index(0)
    device_count = info.get("deviceCount")
    if isinstance(device_count, int):
        for i in range(device_count):
            device_info = p.get_device_info_by_host_api_device_index(0, i)
            device_name = None if name is None else device_info.get("name")
            if isinstance(device_name, str) or device_name is None:
                input_channels = device_info.get("maxInputChannels")
                if name == device_name and isinstance(input_channels, int) and input_channels > 0:
                    return i

    msg = f"Could not find {name}"
    raise ValueError(msg)


def get_input_devices(p: pyaudio.PyAudio) -> list[str]:
    """Retrieve a list of all available input device names.

    Args:
        p: The PyAudio instance.

    Returns:
        A list of available input device names.

    """
    names = []
    info = p.get_host_api_info_by_index(0)
    device_count = info.get("deviceCount")
    if isinstance(device_count, int):
        for i in range(device_count):
            device_info = p.get_device_info_by_host_api_device_index(0, i)
            device_name = device_info.get("name")
            if isinstance(device_name, str):
                input_channels = device_info.get("maxInputChannels")
                if isinstance(input_channels, int) and input_channels > 0:
                    names.append(device_name)

    return names


def get_default_input_device(p: pyaudio.PyAudio) -> str:
    """Return the name of the first available input audio device.

    Args:
        p: The PyAudio instance.

    Returns:
        The name of the default input device.

    Raises:
        ValueError: If no input audio devices are found.

    """
    info = p.get_host_api_info_by_index(0)
    device_count = info.get("deviceCount")
    if isinstance(device_count, int):
        for i in range(device_count):
            device_info = p.get_device_info_by_host_api_device_index(0, i)
            device_name = device_info.get("name")
            if isinstance(device_name, str):
                input_channels = device_info.get("maxInputChannels")
                if isinstance(input_channels, int) and input_channels > 0:
                    return device_name

    msg = "No input audio devices found"
    raise ValueError(msg)
