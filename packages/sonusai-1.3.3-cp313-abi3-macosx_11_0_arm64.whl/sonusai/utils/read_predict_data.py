"""Utilities for reading prediction data from HDF5 files."""

import h5py
import numpy as np

from sonusai import logger
from sonusai.datatypes import Predict


def read_predict_data(filename: str) -> Predict:
    """Read prediction data from an HDF5 file and return it as a NumPy array.

    The prediction data is expected to be in the 'predict' dataset and should
    be either [frames, num_classes] or [frames, timesteps, num_classes]. If the
    latter, it is reshaped to [frames * timesteps, num_classes].

    Args:
        filename: The path to the HDF5 file.

    Returns:
        The prediction data as a NumPy array.

    Raises:
        RuntimeError: If the prediction data dimensions are invalid.

    """
    logger.debug(f"Reading prediction data from {filename}")
    with h5py.File(filename, "r") as f:
        # prediction data is either [frames, num_classes], or [frames, timesteps, num_classes]
        predict = np.array(f["predict"])

        if predict.ndim == 2:
            return predict

        if predict.ndim == 3:
            frames, timesteps, num_classes = predict.shape

            logger.debug(
                f"Reshaping prediction data in {filename} "
                f""
                f"from [{frames}, {timesteps}, {num_classes}] "
                f"to [{frames * timesteps}, {num_classes}]"
            )
            return np.reshape(predict, [frames * timesteps, num_classes], order="F")

        msg = f"Invalid prediction data dimensions in {filename}"
        raise RuntimeError(msg)
