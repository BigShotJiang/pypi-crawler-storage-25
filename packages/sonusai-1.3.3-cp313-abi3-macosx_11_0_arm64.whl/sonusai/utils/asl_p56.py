"""Active speech level calculation following ITU-T Recommendation P.56."""

import numpy as np

from sonusai.datatypes import AudioT
from sonusai.rs import asl_p56 as _rs_asl_p56


def asl_p56(audio: AudioT) -> float:
    """Calculate the active speech level using ITU-T P.56 Method B.

    Args:
        audio: The audio signal to analyze for active speech level.

    Returns:
        The active speech level as a mean square energy value.

    """
    return float(_rs_asl_p56(np.ascontiguousarray(audio, dtype=np.float32)))
