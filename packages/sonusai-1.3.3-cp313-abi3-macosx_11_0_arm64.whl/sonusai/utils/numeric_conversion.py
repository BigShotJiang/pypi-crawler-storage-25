"""Utilities for converting between integer and floating-point audio data."""

import numpy as np


def int16_to_float(x: np.ndarray) -> np.ndarray:
    """Convert an int16 array to a floating-point array with range +/- 1.

    Args:
        x: The input int16 array.

    Returns:
        The converted float32 array.

    """
    return x.astype(np.float32) / 32768


def float_to_int16(x: np.ndarray) -> np.ndarray:
    """Convert a floating-point array with range +/- 1 to an int16 array.

    Args:
        x: The input floating-point array.

    Returns:
        The converted int16 array.

    """
    return (x * 32768).astype(np.int16)


def float32_to_int32(audio: np.ndarray) -> np.ndarray:
    """Convert float32 audio to int32 (SoX-compatible).

    Uses the same rounding and clipping logic as SoX's SOX_FLOAT_32BIT_TO_SAMPLE macro.

    Args:
        audio: Input audio data (float32).

    Returns:
        Audio data converted to int32.

    """
    # Match Rust: floor(scaled + 0.5) with clipping to i32::MIN, i32::MAX
    scaled = audio.astype(np.float64) * 2147483648.0
    return np.clip(np.floor(scaled + 0.5), -2147483648, 2147483647).astype(np.int32)


def int32_to_float32(audio: np.ndarray) -> np.ndarray:
    """Convert int32 audio to float32 (SoX-compatible).

    Uses the same logic as SoX's SOX_SAMPLE_TO_FLOAT_32BIT macro.

    Args:
        audio: Input audio data (int32).

    Returns:
        Audio data converted to float32.

    """
    return (audio.astype(np.float64) / 2147483648.0).astype(np.float32)
