"""Utilities for dynamic loading and importing of Python modules/models."""

from __future__ import annotations

import sys
from importlib import import_module as _import_module
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from types import ModuleType


def import_module(name: str) -> ModuleType:
    """Import a Python module by file path.

    Adds the module's parent directory to `sys.path` so that relative imports
    within the module function correctly.

    Args:
        name: The file path to the Python module.

    Returns:
        The imported module object.

    Raises:
        OSError: If the file cannot be found or the import fails.

    """
    try:
        name_path = Path(name)
        path = name_path.parent

        # Add model file location to system path
        sys.path.append(str(path.resolve()))

        try:
            root = name_path.stem
            model = _import_module(root)
        except Exception as e:
            msg = f"Error: could not import model from {name}: {e}."
            raise OSError(msg) from e
    except Exception as e:
        msg = f"Error: could not find {name}: {e}."
        raise OSError(msg) from e

    return model
