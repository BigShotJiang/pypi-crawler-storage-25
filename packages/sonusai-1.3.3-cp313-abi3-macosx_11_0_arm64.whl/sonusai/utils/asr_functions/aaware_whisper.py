"""Aaware Whisper ASR engine implementation."""

from __future__ import annotations

from typing import TYPE_CHECKING
from typing import Any

if TYPE_CHECKING:
    from sonusai.datatypes import AudioT

import os
import tempfile
from math import exp
from pathlib import Path

import requests

from sonusai.utils.asr import ASRResult
from sonusai.utils.numeric_conversion import float_to_int16
from sonusai.utils.write_audio import write_audio


def aaware_whisper_validate(**_config: Any) -> None:  # noqa: ANN401
    """Validate the configuration for the Aaware Whisper ASR engine.

    Args:
        **_config: Configuration parameters to validate.

    """


def aaware_whisper(audio: AudioT, **_config: Any) -> ASRResult:  # noqa: ANN401
    """Run ASR on audio using the Aaware Whisper web service.

    Args:
        audio: The audio signal to transcribe.
        **_config: Additional configuration parameters.

    Returns:
        The ASR transcription result.

    Raises:
        OSError: If the AAWARE_WHISPER_URL environment variable is not set.
        RuntimeError: If the ASR service returns an error or an exception occurs.

    """
    url = os.getenv("AAWARE_WHISPER_URL")
    if url is None:
        msg = "AAWARE_WHISPER_URL environment variable does not exist"
        raise OSError(msg)
    url += "/asr?task=transcribe&language=en&encode=true&output=json"

    with tempfile.TemporaryDirectory() as tmp:
        file = Path(tmp) / "asr.wav"
        write_audio(name=file, audio=float_to_int16(audio))

        with file.open("rb") as f:
            files = {"audio_file": (str(file), f, "audio/wav")}

            try:
                response = requests.post(url, files=files)  # noqa: S113
                if response.status_code != 200:
                    if response.status_code == 422:
                        msg = f"Validation error: {response.json()}"
                        raise RuntimeError(msg)  # noqa: TRY301
                    msg = f"Invalid response: {response.status_code}"
                    raise RuntimeError(msg)  # noqa: TRY301
                result = response.json()
                return ASRResult(
                    text=result["text"],
                    confidence=exp(float(result["segments"][0]["avg_logprob"])),
                )
            except Exception as e:
                msg = f"Aaware Whisper exception: {e.args}"
                raise RuntimeError(msg) from e


"""
Aaware Whisper Asr Webservice results:
{
  "text": " The birch canoes slid on the smooth planks.",
  "segments": [
    {
      "id": 0,
      "seek": 0,
      "start": 0.0,
      "end": 2.32,
      "text": " The birch canoes slid on the smooth planks.",
      "tokens": [
        50364, 440, 1904, 339, 393, 78, 279, 1061, 327, 322, 264, 5508, 499,
        14592, 13, 50480
      ],
      "temperature": 0.0,
      "avg_logprob": -0.385713913861443,
      "compression_ratio": 0.86,
      "no_speech_prob": 0.006166956853121519
    }
  ],
  "language": "en"
}
"""
