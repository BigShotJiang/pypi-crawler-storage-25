"""Utilities for converting byte sizes into human-readable strings."""


def human_readable_size(num: float, decimal_places: int = 3, suffix: str = "B") -> str:
    """Convert a numeric size into a human-readable string with units.

    Args:
        num: The number to convert (e.g., in bytes).
        decimal_places: The number of decimal places to show (default: 3).
        suffix: The base unit suffix (default: "B").

    Returns:
        A formatted string representing the size with its unit prefix.

    """
    for unit in ("", "k", "M", "G", "T", "P", "E", "Z"):
        if abs(num) < 1024.0:
            return f"{num:.{decimal_places}f} {unit}{suffix}"
        num /= 1024.0
    return f"{num:.{decimal_places}f} Y{suffix}"
