"""Utilities for grouping elements from an iterable into fixed-length chunks."""

from __future__ import annotations

from itertools import zip_longest
from typing import TYPE_CHECKING
from typing import TypeVar

if TYPE_CHECKING:
    from collections.abc import Iterable

T = TypeVar("T")


def grouper[T](iterable: Iterable[T], n: int) -> list[list[T]]:
    """Collect data into fixed-length chunks or blocks.

    Args:
        iterable: The input iterable to group.
        n: The size of each chunk.

    Returns:
        A list of lists, where each inner list has at most `n` elements.

    """
    args = [iter(iterable)] * n
    result = zip_longest(*args, fillvalue=None)
    return [list(filter(None.__ne__, x)) for x in result]
