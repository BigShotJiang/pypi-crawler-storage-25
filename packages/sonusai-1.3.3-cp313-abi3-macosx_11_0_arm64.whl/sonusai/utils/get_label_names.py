"""Utilities for retrieving label names from files or generating default names."""

import csv
from pathlib import Path


def get_label_names(num_labels: int, file: str | None = None) -> list:
    """Return a list of label names, optionally reading them from a CSV file.

    Args:
        num_labels: The total number of labels.
        file: Path to a CSV file containing label mappings (default: None).

    Returns:
        A list of label names.

    Raises:
        ValueError: If the CSV file is missing required fields or if the
            number of labels doesn't match the input.

    """
    if file is None:
        return [f"Class {val + 1}" for val in range(num_labels)]

    label_names = [""] * num_labels

    with Path(file).open() as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None or "index" not in reader.fieldnames or "display_name" not in reader.fieldnames:
            msg = "Missing required fields in labels CSV."
            raise ValueError(msg)

        for row in reader:
            index = int(row["index"]) - 1
            if index >= num_labels:
                msg = "The number of given label names does not match the number of labels."
                raise ValueError(msg)
            label_names[index] = row["display_name"]

    return label_names
