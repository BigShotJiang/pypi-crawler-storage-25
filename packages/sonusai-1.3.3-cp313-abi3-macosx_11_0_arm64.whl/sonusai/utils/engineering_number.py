"""Utilities for working with numbers in engineering notation (e.g., 1k, 2.5M)."""

from __future__ import annotations

from decimal import Decimal
from typing import ClassVar


class EngineeringNumber:
    """A numeric type that supports engineering notation suffixes.

    Supports common suffixes like 'k' (kilo), 'M' (mega), 'm' (milli), etc.,
    and provides arithmetic operations that preserve precision.

    Attributes:
        precision: The number of decimal places to show.
        significant: The number of significant digits to show.
        number: The underlying Decimal representation of the value.

    """

    _suffix_lookup: ClassVar = {
        "Y": "e24",
        "Z": "e21",
        "E": "e18",
        "P": "e15",
        "T": "e12",
        "G": "e9",
        "M": "e6",
        "k": "e3",
        "": "e0",
        "m": "e-3",
        "u": "e-6",
        "n": "e-9",
        "p": "e-12",
        "f": "e-15",
        "a": "e-18",
        "z": "e-21",
        "y": "e-24",
    }

    _exponent_lookup_scaled: ClassVar = {
        "-12": "Y",
        "-15": "Z",
        "-18": "E",
        "-21": "P",
        "-24": "T",
        "-27": "G",
        "-30": "M",
        "-33": "k",
        "-36": "",
        "-39": "m",
        "-42": "u",
        "-45": "n",
        "-48": "p",
        "-51": "f",
        "-54": "a",
        "-57": "z",
        "-60": "y",
    }

    def __init__(
        self,
        value: str | float | EngineeringNumber,
        precision: int = 2,
        significant: int = 0,
    ) -> None:
        """Initialize an EngineeringNumber.

        Args:
            value: The numeric value (string, float, or another EngineeringNumber).
            precision: The number of digits past the decimal (default: 2).
            significant: The number of significant digits. If non-zero, this
                takes precedence over precision (default: 0).

        Raises:
            TypeError: If the value type is not supported.

        """
        self.precision = precision
        self.significant = significant

        if isinstance(value, str):
            suffix_keys = [key for key in self._suffix_lookup if key != ""]

            str_value = str(value)
            for suffix in suffix_keys:
                if suffix in str_value:
                    str_value = str_value[:-1] + self._suffix_lookup[suffix]
                    break

            self.number = Decimal(str_value)

        elif isinstance(value, int | float | EngineeringNumber):
            self.number = Decimal(str(value))

        else:
            msg = "value has unsupported type"
            raise TypeError(msg)

    def __repr__(self) -> str:
        """Return the engineering notation string representation."""
        # The Decimal class only really converts numbers that are very small into engineering notation.
        # So we will simply make all numbers small numbers and take advantage of the Decimal class.
        number_str = self.number * Decimal("10e-37")
        number_str = number_str.to_eng_string().lower()

        base, exponent = number_str.split("e")

        if self.significant > 0:
            abs_base = abs(Decimal(base))
            num_digits = 1
            num_digits += 1 if abs_base >= 10 else 0
            num_digits += 1 if abs_base >= 100 else 0
            num_digits = self.significant - num_digits
        else:
            num_digits = self.precision

        base = str(round(Decimal(base), num_digits))

        if "e" in base.lower():
            base = str(int(Decimal(base)))

        # Remove trailing decimal
        if "." in base:
            base = base.rstrip(".")

        return base + self._exponent_lookup_scaled[exponent]

    def __str__(self) -> str:
        """Return the string representation."""
        return self.__repr__()

    def __int__(self) -> int:
        """Return the integer representation."""
        return int(self.number)

    def __float__(self) -> float:
        """Return the float representation."""
        return float(self.number)

    @staticmethod
    def _to_decimal(other: str | float | EngineeringNumber) -> Decimal:
        """Convert an input value to a Decimal.

        Args:
            other: The value to convert.

        Returns:
            The Decimal representation.

        """
        if not isinstance(other, EngineeringNumber):
            other = EngineeringNumber(other)
        return other.number

    def __add__(self, other: str | float | EngineeringNumber) -> EngineeringNumber:
        """Add two EngineeringNumbers."""
        return EngineeringNumber(str(self.number + self._to_decimal(other)))

    def __radd__(self, other: str | float | EngineeringNumber) -> EngineeringNumber:
        """Add two EngineeringNumbers (reflected)."""
        return self.__add__(other)

    def __sub__(self, other: str | float | EngineeringNumber) -> EngineeringNumber:
        """Subtract two EngineeringNumbers."""
        return EngineeringNumber(str(self.number - self._to_decimal(other)))

    def __rsub__(self, other: str | float | EngineeringNumber) -> EngineeringNumber:
        """Subtract two EngineeringNumbers (reflected)."""
        return EngineeringNumber(str(self._to_decimal(other) - self.number))

    def __mul__(self, other: str | float | EngineeringNumber) -> EngineeringNumber:
        """Multiply two EngineeringNumbers."""
        return EngineeringNumber(str(self.number * self._to_decimal(other)))

    def __rmul__(self, other: str | float | EngineeringNumber) -> EngineeringNumber:
        """Multiply two EngineeringNumbers (reflected)."""
        return self.__mul__(other)

    def __truediv__(self, other: str | float | EngineeringNumber) -> EngineeringNumber:
        """Divide two EngineeringNumbers."""
        return EngineeringNumber(str(self.number / self._to_decimal(other)))

    def __rtruediv__(self, other: str | float | EngineeringNumber) -> EngineeringNumber:
        """Divide two EngineeringNumbers (reflected)."""
        return EngineeringNumber(str(self._to_decimal(other) / self.number))

    def __lt__(self, other: str | float | EngineeringNumber) -> bool:
        """Less than comparison."""
        return self.number < self._to_decimal(other)

    def __gt__(self, other: str | float | EngineeringNumber) -> bool:
        """Greater than comparison."""
        return self.number > self._to_decimal(other)

    def __le__(self, other: str | float | EngineeringNumber) -> bool:
        """Less than or equal comparison."""
        return self.number <= self._to_decimal(other)

    def __ge__(self, other: str | float | EngineeringNumber) -> bool:
        """Greater than or equal comparison."""
        return self.number >= self._to_decimal(other)

    def __eq__(self, other: object) -> bool:
        """Equality comparison."""
        if not isinstance(other, str | float | int | EngineeringNumber):
            return NotImplemented
        return self.number == self._to_decimal(other)
