"""Automated Speech Recognition (ASR) utility functions and types."""

from __future__ import annotations

from copy import copy
from dataclasses import dataclass
from importlib import import_module
from pkgutil import iter_modules
from typing import TYPE_CHECKING
from typing import Any

import numpy as np

from sonusai.mixture.audio import read_audio

if TYPE_CHECKING:
    from collections.abc import Callable

    from sonusai.datatypes import AudioT


@dataclass(frozen=True)
class ASRResult:
    """The result of an ASR operation.

    Attributes:
        text: The transcribed text.
        confidence: The confidence score of the transcription.
        lang: The detected language.
        lang_prob: The probability of the detected language.
        duration: The duration of the audio processed in seconds.
        num_segments: The number of segments identified in the audio.
        asr_cpu_time: The CPU time spent on ASR in seconds.

    """

    text: str
    confidence: float | None = None
    lang: str | None = None
    lang_prob: float | None = None
    duration: float | None = None
    num_segments: int | None = None
    asr_cpu_time: float | None = None


def get_available_engines() -> list[str]:
    """Return a list of all available ASR engines.

    The engines are discovered from the `sonusai.utils.asr_functions` module
    and any external packages with the `sonusai_asr_` prefix.

    Returns:
        A list of available ASR engine names.

    """
    module = import_module("sonusai.utils.asr_functions")
    engines = [method for method in dir(module) if not method.startswith("_")]
    for _, name, _ in iter_modules():
        if name.startswith("sonusai_asr_"):
            module = import_module(f"{name}.asr_functions")
            engines.extend(method for method in dir(module) if not method.startswith("_"))

    return engines


def _asr_fn(engine: str) -> Callable[..., ASRResult]:
    """Retrieve the ASR function for a given engine name.

    Args:
        engine: The name of the ASR engine.

    Returns:
        The callable ASR function.

    Raises:
        ValueError: If the engine is not supported.

    """
    module = import_module("sonusai.utils.asr_functions")
    for method in dir(module):
        if method == engine:
            return getattr(module, method)

    for _, name, _ in iter_modules():
        if name.startswith("sonusai_asr_"):
            module = import_module(f"{name}.asr_functions")
            for method in dir(module):
                if method == engine:
                    return getattr(module, method)

    msg = f"engine {engine} not supported"
    raise ValueError(msg)


def calc_asr(audio: AudioT | str, engine: str, **config: Any) -> ASRResult:  # noqa: ANN401
    """Run ASR on audio using the specified engine.

    Args:
        audio: NumPy array of audio samples or path to an audio file.
        engine: The ASR engine to use.
        **config: Additional configuration parameters for the ASR engine.

    Returns:
        An ASRResult object containing the transcription results.

    """
    if not isinstance(audio, np.ndarray):
        audio = copy(read_audio(audio, config.get("use_cache", True)))

    return _asr_fn(engine)(audio, **config)


def validate_asr(engine: str, **config: Any) -> None:  # noqa: ANN401
    """Validate the configuration for a specific ASR engine.

    Args:
        engine: The ASR engine to validate.
        **config: Configuration parameters to validate.

    Raises:
        ValueError: If the engine is not supported.

    """
    module = import_module("sonusai.utils.asr_functions")
    for method in dir(module):
        if method == engine:
            getattr(module, method + "_validate")(**config)
            return

    for _, name, _ in iter_modules():
        if name.startswith("sonusai_asr_"):
            module = import_module(f"{name}.asr_functions")
            for method in dir(module):
                if method == engine:
                    getattr(module, method + "_validate")(**config)
                    return

    msg = f"engine {engine} not supported"
    raise ValueError(msg)
