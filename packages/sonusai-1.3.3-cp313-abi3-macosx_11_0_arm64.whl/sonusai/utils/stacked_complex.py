"""Utilities for stacking and unstacking real and imaginary parts of complex arrays."""

import numpy as np


def stack_complex(unstacked: np.ndarray) -> np.ndarray:
    """Stack a complex array by concatenating real and imaginary parts.

    A stacked array doubles the last dimension and organizes the data as:
        - first half is all the real data
        - second half is all the imaginary data

    Args:
        unstacked: An n-dimensional array (n > 1) containing complex data.

    Returns:
        A stacked floating-point array.

    Raises:
        ValueError: If the input array has fewer than 2 dimensions.

    """
    if not unstacked.ndim > 1:
        msg = "unstacked must have more than 1 dimension"
        raise ValueError(msg)

    shape = list(unstacked.shape)
    shape[-1] = shape[-1] * 2
    stacked = np.empty(shape, dtype=np.float32)
    half = unstacked.shape[-1]
    stacked[..., :half] = np.real(unstacked)
    stacked[..., half:] = np.imag(unstacked)

    return stacked


def unstack_complex(stacked: np.ndarray) -> np.ndarray:
    """Unstack a stacked complex array into a complex-valued array.

    Args:
        stacked: An n-dimensional array (n > 1) where the last dimension
            contains stacked real and imaginary data.

    Returns:
        An unstacked complex-valued array.

    Raises:
        ValueError: If the input array has fewer than 2 dimensions or the
            last dimension size is not a multiple of 2.

    """
    if not stacked.ndim > 1:
        msg = "stacked must have more than 1 dimension"
        raise ValueError(msg)

    if stacked.shape[-1] % 2 != 0:
        msg = "last dimension of stacked must be a multiple of 2"
        raise ValueError(msg)

    half = stacked.shape[-1] // 2
    unstacked = 1j * stacked[..., half:]
    unstacked += stacked[..., :half]

    return unstacked


def stacked_complex_real(stacked: np.ndarray) -> np.ndarray:
    """Get the real elements from a stacked complex array.

    Args:
        stacked: An n-dimensional array (n > 1) where the last dimension
            contains stacked real and imaginary data.

    Returns:
        The real elements from the first half of the last dimension.

    Raises:
        ValueError: If the input array has fewer than 2 dimensions or the
            last dimension size is not a multiple of 2.

    """
    if not stacked.ndim > 1:
        msg = "stacked must have more than 1 dimension"
        raise ValueError(msg)

    if stacked.shape[-1] % 2 != 0:
        msg = "last dimension of stacked must be a multiple of 2"
        raise ValueError(msg)

    half = stacked.shape[-1] // 2
    return stacked[..., :half]


def stacked_complex_imag(stacked: np.ndarray) -> np.ndarray:
    """Get the imaginary elements from a stacked complex array.

    Args:
        stacked: An n-dimensional array (n > 1) where the last dimension
            contains stacked real and imaginary data.

    Returns:
        The imaginary elements from the second half of the last dimension.

    Raises:
        ValueError: If the input array has fewer than 2 dimensions or the
            last dimension size is not a multiple of 2.

    """
    if not stacked.ndim > 1:
        msg = "stacked must have more than 1 dimension"
        raise ValueError(msg)

    if stacked.shape[-1] % 2 != 0:
        msg = "last dimension of stacked must be a multiple of 2"
        raise ValueError(msg)

    half = stacked.shape[-1] // 2
    return stacked[..., half:]
