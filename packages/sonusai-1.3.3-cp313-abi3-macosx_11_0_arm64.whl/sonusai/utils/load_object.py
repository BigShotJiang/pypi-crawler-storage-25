"""Utilities for loading pickled Python objects from disk with optional caching."""

from __future__ import annotations

import pickle
from functools import lru_cache
from pathlib import Path
from typing import Any


def load_object(name: str, use_cache: bool = True) -> Any:  # noqa: ANN401
    """Load a Python object from a pickle file.

    Args:
        name: The path to the pickle file.
        use_cache: Whether to use the internal LRU cache (default: True).

    Returns:
        The deserialized Python object.

    Raises:
        FileNotFoundError: If the specified file does not exist.

    """
    if use_cache:
        return _load_object(name)
    return _load_object.__wrapped__(name)


@lru_cache
def _load_object(name: str) -> Any:  # noqa: ANN401
    """Load a pickle file with LRU caching.

    Args:
        name: The path to the pickle file.

    Returns:
        The deserialized Python object.

    Raises:
        FileNotFoundError: If the specified file does not exist.

    """
    path = Path(name)
    if path.exists():
        with path.open("rb") as f:
            return pickle.load(f)  # noqa: S301

    raise FileNotFoundError(name)
