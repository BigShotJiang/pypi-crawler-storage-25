"""Utilities for prompting user for yes or no input."""


def yes_or_no(question: str) -> bool:
    """Prompt the user for a yes or no response.

    Args:
        question: The question to display to the user.

    Returns:
        True if the user answers 'y' (yes), False if the user answers 'n' (no).

    """
    while True:
        reply = str(input(question + " (y/n)?: ")).lower().strip()
        if reply[:1] == "y":
            return True
        if reply[:1] == "n":
            return False
