"""Utilities for expanding and replacing tokenized shell variables in strings."""

import os
from pathlib import Path

from pyaaware.env_vars import tokenized_expand as _tokenized_expand
from pyaaware.env_vars import tokenized_replace as _tokenized_replace

from sonusai.constants import DEFAULT_NOISE


def tokenized_expand(name: str | bytes | Path) -> tuple[str, dict[str, str]]:
    """Expand shell variables of the forms $var, ${var}, and %var%.

    Unknown variables are left unchanged. No expansion occurs within single
    quotes. '$$' is translated into '$', and '%%' into '%'. Supports
    ${var}, $varname, and %var% formats.

    Args:
        name: The string or path to expand.

    Returns:
        A tuple of (expanded string, dictionary of tokens).

    """
    os.environ["default_noise"] = str(DEFAULT_NOISE)  # noqa: SIM112

    return _tokenized_expand(name)


def tokenized_replace(name: str, tokens: dict[str, str]) -> str:
    """Replace text with shell variables.

    Args:
        name: The string to process.
        tokens: A dictionary of replacement tokens.

    Returns:
        The processed string with replacements.

    """
    return _tokenized_replace(name, tokens)
