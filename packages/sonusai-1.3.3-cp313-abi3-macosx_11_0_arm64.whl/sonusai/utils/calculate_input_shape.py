"""Utilities for calculating neural network input shapes based on feature parameters."""

from pyaaware import FeatureGenerator


def calculate_input_shape(feature: str, flatten: bool = False, timesteps: int = 0, add1ch: bool = False) -> list[int]:
    """Calculate input shape given feature and user-specified reshape parameters.

    Args:
        feature: String defining the Aaware feature used in SonusAI.
        flatten: If true, flatten the 2D spectrogram from SxB to S*B (default: False).
        timesteps: Pre-pend timesteps dimension if non-zero, size = timesteps (default: 0).
        add1ch: Append channel dimension of size 1 (channel last) (default: False).

    Returns:
        A list of integers representing the input shape.

    """
    fg = FeatureGenerator(feature_mode=feature)

    in_shape = [fg.stride * fg.feature_parameters] if flatten else [fg.stride, fg.feature_parameters]

    if timesteps > 0:
        in_shape.insert(0, timesteps)

    if add1ch:
        in_shape.append(1)

    return in_shape
