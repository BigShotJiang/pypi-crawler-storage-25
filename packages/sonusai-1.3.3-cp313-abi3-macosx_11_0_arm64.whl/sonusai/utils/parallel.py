"""Utilities for parallel execution of functions with progress tracking."""

from __future__ import annotations

import sys
import warnings
from collections.abc import Sized
from multiprocessing import current_process
from multiprocessing import get_all_start_methods
from multiprocessing import get_context
from typing import TYPE_CHECKING
from typing import Any

from psutil import cpu_count
from tqdm import TqdmExperimentalWarning
from tqdm.rich import tqdm

if TYPE_CHECKING:
    from collections.abc import Callable
    from collections.abc import Iterable

warnings.filterwarnings(action="ignore", category=TqdmExperimentalWarning)

track = tqdm


def _get_default_context() -> str:
    """Get the default multiprocessing context based on the platform."""
    methods = get_all_start_methods()
    if sys.platform == "win32":
        if "spawn" in methods:
            return "spawn"
    if "forkserver" in methods:
        try:
            from multiprocessing import set_forkserver_preload

            set_forkserver_preload(["numpy", "torch", "sonusai.mixture.mixdb", "sonusai.config.config"])
        except (ImportError, AttributeError):
            pass
        return "forkserver"
    return "fork"


CONTEXT = _get_default_context()


class _ExecutionContext:
    def __init__(
        self,
        initializer: Callable[..., None] | None,
        initargs: Iterable[Any] | None,
        progress: tqdm | None,
        pass_index: bool,
    ) -> None:
        self.initializer = initializer
        self.initargs = initargs
        self.progress = progress
        self.pass_index = pass_index


def _parse_options(
    options: dict[str, object],
) -> tuple[Callable[..., None] | None, Iterable[Any] | None, tqdm | None, float | None, int | None, bool, bool]:
    allowed = {"initializer", "initargs", "progress", "num_cpus", "total", "no_par", "pass_index"}
    unknown = set(options) - allowed
    if unknown:
        unknown_names = ", ".join(sorted(unknown))
        msg = f"Unknown par_track options: {unknown_names}"
        raise TypeError(msg)

    return (
        options.get("initializer"),
        options.get("initargs"),
        options.get("progress"),
        options.get("num_cpus"),
        options.get("total"),
        options.get("no_par", False),
        options.get("pass_index", False),
    )


def par_track(
    func: Callable,
    *iterables: Iterable,
    **options: object,
) -> list[Any]:
    """Perform a parallel ordered imap with tqdm progress tracking.

    Args:
        func: The function to execute in parallel.
        *iterables: One or more iterables to pass to the function.
        initializer: A function to call on initialization of each worker process.
        initargs: Arguments to pass to the initializer (default: None).
        progress: A tqdm progress bar instance (default: None). If provided,
            lifecycle ownership remains with the caller.
        num_cpus: The number of CPUs to use, or a fraction of total CPUs
            if provided as a float (default: None).
        total: The total number of items to process (default: None).
        no_par: If true, execute sequentially instead of in parallel (default: False).
        pass_index: If true, pass the current index as the first argument to `func`.
        **options: Optional keyword options (`initializer`, `initargs`,
            `progress`, `num_cpus`, `total`, `no_par`, `pass_index`).

    Returns:
        A list of results from the function execution.

    """
    initializer, initargs, progress, num_cpus, total, no_par, pass_index = _parse_options(options)
    context = _ExecutionContext(initializer, initargs, progress, pass_index)
    total_items = _calculate_total_items(iterables, total)
    results: list[Any] = [None] * total_items

    if no_par or current_process().daemon or total_items == 0:
        _execute_sequential(func, iterables, results, context)
    else:
        cpu_count = _determine_cpu_count(num_cpus, total_items)
        _execute_parallel(func, iterables, results, context, cpu_count)

    return results


def _calculate_total_items(iterables: tuple[Iterable, ...], total: int | None) -> int:
    """Calculate the total number of items to process.

    Args:
        iterables: The input iterables.
        total: An optional manually specified total.

    Returns:
        The total number of items.

    """
    if total is None:
        return min(len(iterable) for iterable in iterables if isinstance(iterable, Sized))
    return int(total)


def _cpu_count() -> int:
    """Get the number of logical CPUs available on the system.

    Returns:
        The number of CPUs, or 1 if it cannot be determined.

    """
    count = cpu_count()
    if count is None:
        return 1
    return count


def _determine_cpu_count(num_cpus: float | None, total_items: int) -> int:
    """Determine the optimal number of CPUs to use for a parallel task.

    Args:
        num_cpus: Requested number or fraction of CPUs.
        total_items: The number of items to be processed.

    Returns:
        The calculated number of CPUs to use.

    """
    if num_cpus is None:
        # Reserve 2 CPUs for system, minimum 1
        optimal_cpus = max(_cpu_count() - 2, 1)
    elif isinstance(num_cpus, float):
        optimal_cpus = round(num_cpus * _cpu_count())
    else:
        optimal_cpus = int(num_cpus)

    return min(optimal_cpus, total_items)


def _create_indexed_iterables(iterables: tuple[Iterable, ...]) -> tuple[Iterable, ...]:
    """Modify iterables to include a zero-based index as the first element.

    Args:
        iterables: The original input iterables.

    Returns:
        A tuple of iterables where the first one is enumerated.

    """
    # Get the first iterable to enumerate over
    first_iterable = iterables[0]
    remaining_iterables = iterables[1:]

    # Create an enumerated version: (index, first_item), second_item, third_item, ...
    indexed_first = enumerate(first_iterable)

    if remaining_iterables:
        return (indexed_first, *remaining_iterables)
    return (indexed_first,)


class _IndexedFunctionWrapper:
    """Pickle-able wrapper class for functions that need an index as the first argument."""

    def __init__(self, func: Callable) -> None:
        self.func = func

    def __call__(self, indexed_first_arg: tuple[int, Any], *remaining_args: Any) -> Any:  # noqa: ANN401
        index, first_arg = indexed_first_arg
        return self.func(index, first_arg, *remaining_args)


def _wrap_function_with_index(func: Callable) -> Callable:
    """Wrap a function to handle indexed arguments from `_create_indexed_iterables`.

    Args:
        func: The original function.

    Returns:
        A wrapped version of the function that expects (index, arg1) as its
        first argument.

    """
    return _IndexedFunctionWrapper(func)


def _execute_sequential(
    func: Callable,
    iterables: tuple[Iterable, ...],
    results: list[Any],
    context: _ExecutionContext,
) -> None:
    """Execute a function sequentially without using multiprocessing.

    Args:
        func: The function to execute.
        iterables: The input data iterables.
        initializer: Optional initialization function.
        initargs: Arguments for the initializer.
        results: List to store results in-place.
        progress: Optional tqdm progress bar.
        pass_index: Whether to pass the index to `func`.
        context: Execution configuration bundle.

    """
    if context.initializer is not None:
        if context.initargs is not None:
            context.initializer(*context.initargs)
        else:
            context.initializer()

    if context.pass_index:
        mapped_iterables = _create_indexed_iterables(iterables)
        wrapped_func = _wrap_function_with_index(func)
        iterator = map(wrapped_func, *mapped_iterables)
    else:
        iterator = map(func, *iterables)

    accumulated = 0
    update_interval = max(1, len(results) // 100)
    for index, result in enumerate(iterator):
        results[index] = result
        accumulated += 1
        if context.progress is not None and (accumulated >= update_interval or index == len(results) - 1):
            context.progress.update(accumulated)
            accumulated = 0


def _execute_parallel(
    func: Callable,
    iterables: tuple[Iterable, ...],
    results: list[Any],
    context: _ExecutionContext,
    cpu_count: int,
) -> None:
    """Execute a function in parallel using multiprocessing.

    Args:
        func: The function to execute.
        iterables: The input data iterables.
        initializer: Initialization function for workers.
        initargs: Arguments for the initializer.
        results: List to store results in-place.
        progress: Optional tqdm progress bar.
        pass_index: Whether to pass the index to `func`.
        context: Execution configuration bundle.
        cpu_count: Number of parallel processes to use.

    """
    init_args = context.initargs if context.initargs is not None else []

    if context.pass_index:
        mapped_iterables = _create_indexed_iterables(iterables)
        wrapped_func = _wrap_function_with_index(func)
    else:
        mapped_iterables = iterables
        wrapped_func = func

    with get_context(CONTEXT).Pool(processes=cpu_count, initializer=context.initializer, initargs=init_args) as pool:
        # Use a larger chunksize for better performance with forkserver/spawn
        # A value of 1 causes excessive communication overhead.
        # We cap it to avoid overly large chunks for small workloads.
        total_items = len(results)
        chunksize = max(1, min(total_items // (cpu_count * 4), 1000))
        update_interval = max(1, chunksize)
        accumulated = 0

        for index, result in enumerate(pool.imap(wrapped_func, *mapped_iterables, chunksize=chunksize)):
            results[index] = result
            accumulated += 1
            if context.progress is not None and (accumulated >= update_interval or index == total_items - 1):
                context.progress.update(accumulated)
                accumulated = 0
        pool.close()
        pool.join()
