"""Utilities for handling keyboard interrupts (SIGINT)."""

from __future__ import annotations

import signal
import sys
from typing import Any

from sonusai import logger


def register_keyboard_interrupt() -> None:
    """Register a custom signal handler for keyboard interrupts (SIGINT).

    When a keyboard interrupt occurs, it logs a cancellation message and
    exits the application with status code 1.
    """

    def signal_handler(_sig: int, _frame: Any) -> None:  # noqa: ANN401
        logger.info("Canceled due to keyboard interrupt")
        sys.exit(1)

    signal.signal(signal.SIGINT, signal_handler)
