"""Utilities for evaluating random rule directives in strings."""

import re
from random import uniform


def evaluate_random_rule(rule: str) -> str | float:
    """Evaluate 'rand' directives within a string and return the result.

    Directives in the form 'rand(min, max)' are replaced with a random float
    between min and max.

    Args:
        rule: The string containing random rule directives.

    Returns:
        The evaluated value, which could be a string or a float.

    """
    rand_pattern = re.compile(r"rand\(([-+]?(\d+(\.\d*)?|\.\d+)),\s*([-+]?(\d+(\.\d*)?|\.\d+))\)")

    def rand_repl(m: re.Match[str]) -> str:
        return f"{uniform(float(m.group(1)), float(m.group(4))):.2f}"  # noqa: S311

    return eval(re.sub(rand_pattern, rand_repl, rule))  # noqa: S307
