"""Utilities for glob-style file searching with brace expansion support."""

import itertools
import re
from collections.abc import Generator
from pathlib import Path
from typing import LiteralString


def expand_braces(text: LiteralString | str | bytes, seen: set[str] | None = None) -> Generator[str]:
    """Expand braces in a string to produce all possible combinations.

    This function performs brace-expansion (e.g., "a{b,c}" becomes ["ab", "ac"]).

    Args:
        text: The string containing braces to expand.
        seen: A set of already expanded strings to avoid duplicates (default: None).

    Yields:
        Each expanded string combination.

    """
    if seen is None:
        seen = set()

    if not isinstance(text, str):
        text = str(text)

    spans = [m.span() for m in re.finditer(r"\{[^{}]*}", text)][::-1]
    alts = [text[start + 1 : stop - 1].split(",") for start, stop in spans]

    if len(spans) == 0:
        if text not in seen:
            yield text
        seen.add(text)
    else:
        for combo in itertools.product(*alts):
            replaced = list(text)
            for (start, stop), replacement in zip(spans, combo, strict=False):
                replaced[start:stop] = replacement
            yield from expand_braces("".join(replaced), seen)


def braced_glob(pathname: LiteralString | str | bytes, recursive: bool = False) -> list[str]:
    """Perform glob-style file searching with support for brace expansion.

    Args:
        pathname: The path pattern to search for, including potential braces.
        recursive: Whether to search recursively in subdirectories (default: False).

    Returns:
        A list of matching file paths.

    """
    result = []
    for expanded_path in expand_braces(pathname):
        # We use Path().glob() which works similarly to glob.glob()
        # but is recommended by PTH207.
        path_obj = Path()
        matches = path_obj.rglob(expanded_path) if recursive else path_obj.glob(expanded_path)
        result.extend(str(p) for p in matches)

    return result


def braced_iglob(pathname: LiteralString | str | bytes, recursive: bool = False) -> Generator[str]:
    """Return an iterator that yields matching file paths with brace expansion.

    Args:
        pathname: The path pattern to search for, including potential braces.
        recursive: Whether to search recursively in subdirectories (default: False).

    Yields:
        Each matching file path.

    """
    for expanded_path in expand_braces(pathname):
        path_obj = Path()
        matches = path_obj.rglob(expanded_path) if recursive else path_obj.glob(expanded_path)
        yield from (str(p) for p in matches)
