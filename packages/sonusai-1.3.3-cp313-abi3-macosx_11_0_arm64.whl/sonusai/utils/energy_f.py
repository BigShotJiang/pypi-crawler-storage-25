"""Utilities for computing per-bin energy from frequency domain audio data."""

import numpy as np
import torch
from pyaaware.torch import ForwardTransform

from sonusai.datatypes import AudioF
from sonusai.datatypes import AudioT
from sonusai.datatypes import EnergyF


def compute_energy_f(
    frequency_domain: AudioF | None = None,
    time_domain: AudioT | None = None,
    transform: ForwardTransform | None = None,
) -> EnergyF:
    """Compute the energy in each frequency bin.

    Must provide either frequency domain or time domain input. If time domain
    input is provided, a ForwardTransform object must also be provided to
    convert to the frequency domain.

    Args:
        frequency_domain: Frequency domain data [frames, bins] (default: None).
        time_domain: Time domain data [samples] (default: None).
        transform: ForwardTransform object (default: None).

    Returns:
        Frequency domain per-bin energy data [frames, bins].

    Raises:
        ValueError: If neither frequency_domain nor time_domain is provided,
            or if time_domain is provided without a transform.

    """
    if frequency_domain is None:
        if time_domain is None:
            msg = "Must provide time or frequency domain input"
            raise ValueError(msg)
        if transform is None:
            msg = "Must provide ForwardTransform object"
            raise ValueError(msg)

        _frequency_domain = transform.execute_all(torch.from_numpy(time_domain))[0].numpy()
    else:
        _frequency_domain = frequency_domain

    frames, bins = _frequency_domain.shape
    result = np.empty((frames, bins), dtype=np.float32)

    for f in range(frames):
        for b in range(bins):
            value = _frequency_domain[f, b]
            result[f, b] = np.real(value) * np.real(value) + np.imag(value) * np.imag(value)

    return result
