"""Utilities for making random or sequential selections from a list of items."""

from __future__ import annotations

import random
from abc import ABC
from abc import abstractmethod
from typing import Any


class BaseChoice(ABC):
    """Abstract base class for item selection strategies.

    Attributes:
        data: The list of items to choose from.
        index: The current position in the sequence of choices.
        choices: The internal list of shuffled or ordered items.

    """

    def __init__(self, data: list[Any]) -> None:
        """Initialize the choice strategy with data.

        Args:
            data: The list of items to choose from.

        """
        self.data = data
        self.index = 0
        self.choices: list[Any] = []

    @abstractmethod
    def next(self) -> Any:  # noqa: ANN401
        """Return the next selected item.

        Returns:
            The next item from the data based on the strategy.

        """


class RandomChoice(BaseChoice):
    """A selection strategy that chooses items randomly from a list.

    Attributes:
        repeat: Whether to allow immediate repetitions by picking with replacement.

    """

    def __init__(self, data: list[Any], repetition: bool = False) -> None:
        """Initialize the random choice strategy.

        Args:
            data: The list of items to choose from.
            repetition: If true, pick items with replacement (default: False).

        """
        super().__init__(data)
        self.repeat = repetition
        self.choices = random.sample(self.data, len(self.data))

    def next(self) -> Any:  # noqa: ANN401
        """Return the next random item.

        Returns:
            A randomly selected item.

        """
        if self.repeat:
            return random.choice(self.data)  # noqa: S311

        if self.index >= len(self.data):
            self.choices = random.sample(self.data, len(self.data))
            self.index = 0

        item = self.choices[self.index]
        self.index += 1

        return item


class SequentialChoice(BaseChoice):
    """A selection strategy that chooses items in sequential order."""

    def __init__(self, data: list[Any]) -> None:
        """Initialize the sequential choice strategy.

        Args:
            data: The list of items to choose from.

        """
        super().__init__(data)

    def next(self) -> Any:  # noqa: ANN401
        """Return the next item in the sequence.

        Returns:
            The next item from the data list.

        """
        if self.index >= len(self.data):
            self.index = 0
        item = self.data[self.index]
        self.index += 1
        return item
