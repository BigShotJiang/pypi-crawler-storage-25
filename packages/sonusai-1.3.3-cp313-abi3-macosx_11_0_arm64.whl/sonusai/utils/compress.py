"""Utilities for power-law compression and decompression of complex-valued features."""

import numpy as np

from sonusai.datatypes import AudioF


def power_compress(feature: AudioF) -> AudioF:
    """Apply power-law compression to a complex-valued feature.

    Args:
        feature: The complex-valued input feature (e.g., STFT).

    Returns:
        The compressed feature.

    """
    mag = np.abs(feature)
    phase = np.angle(feature)
    mag = mag**0.3
    real_compress = mag * np.cos(phase)
    imag_compress = mag * np.sin(phase)

    return real_compress + 1j * imag_compress


def power_uncompress(feature: AudioF) -> AudioF:
    """Reverse power-law compression on a complex-valued feature.

    Args:
        feature: The compressed complex-valued feature.

    Returns:
        The uncompressed (original scale) feature.

    """
    mag = np.abs(feature)
    phase = np.angle(feature)
    mag = mag ** (1.0 / 0.3)
    real_uncompress = mag * np.cos(phase)
    imag_uncompress = mag * np.sin(phase)

    return real_uncompress + 1j * imag_uncompress
