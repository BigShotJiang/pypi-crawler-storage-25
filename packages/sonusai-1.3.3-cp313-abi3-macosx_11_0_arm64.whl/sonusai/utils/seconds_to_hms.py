"""Utilities for converting time durations into human-readable formats."""


def seconds_to_hms(seconds: float) -> str:
    """Convert a duration in seconds to an H:MM:SS string.

    Args:
        seconds: The number of seconds to convert.

    Returns:
        A string in the format "H:MM:SS (H:MM:SS)".

    """
    h = int(seconds / 3600)
    s = seconds - h * 3600
    m = int(s / 60)
    s = int(seconds - h * 3600 - m * 60)
    return f"{h:d}:{m:02d}:{s:02d} (H:MM:SS)"
