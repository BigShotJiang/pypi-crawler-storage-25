"""Reference Python implementations for Active speech level calculation (ITU-T P.56)."""

import numpy as np

from sonusai.datatypes import AudioT


def _compute_envelope(audio: AudioT, sample_rate: int) -> tuple[object, float, float, int, object]:
    """Compute the signal envelope following ITU-T P.56 Method B.

    Args:
        audio: The input audio signal.
        sample_rate: The sampling rate of the audio.

    Returns:
        A tuple of (envelope, margin, epsilon, h_samples, thresholds).

    """
    from scipy import signal  # noqa: PLC0415 (Heavy loading: ~450ms)

    t_const = 0.03
    h_const = 0.2
    thresh_num = 15
    g = np.exp(-1 / (sample_rate * t_const))
    h_samples = int(np.ceil(h_const * sample_rate))
    c = 2 ** np.arange(-15, thresh_num - 15, dtype=np.float32)

    p = signal.lfilter([1 - g, 0], [1, -g], abs(audio))
    q = signal.lfilter([1 - g, 0], [1, -g], p)
    return q, 15.9, float(np.finfo(np.float32).eps), h_samples, c


def _count_activity(q: object, c: object, h_samples: int, length: int) -> object:
    """Count activity at various thresholds.

    Args:
        q: The signal envelope.
        c: The array of thresholds.
        h_samples: Hangover time in samples.
        length: The length of the signal.

    Returns:
        An array of activity counts.

    """
    a = np.full(len(c), -1)
    h = np.full(len(c), h_samples)
    for k in range(length):
        for j in range(len(c)):
            if q[k] >= c[j]:
                a[j] = a[j] + 1
                h[j] = 0
            elif h[j] < h_samples:
                a[j] = a[j] + 1
                h[j] = h[j] + 1
            else:
                break
    return a


def _compute_asl_from_thresholds(a: object, c: object, sq: float, eps: float, margin: float) -> float:
    """Calculate the active speech level from thresholds.

    Args:
        a: Activity counts.
        c: Thresholds.
        sq: Total square energy.
        eps: Epsilon for stability.
        margin: The margin value.

    Returns:
        The active speech level.

    """
    asl_msq = 0.0
    if a[0] == -1:
        return asl_msq

    # Important: a is modified in place in the original but we should be careful
    # if we want to avoid side effects or re-run tests.
    # The original did: a += 2. We'll replicate it for parity.
    a = a.copy() + 2
    a_db1 = 10 * np.log10(sq / a[0] + eps)
    c_db1 = 20 * np.log10(c[0] + eps)
    if a_db1 - c_db1 < margin:
        return asl_msq

    thresh_num = len(c)
    a_db = np.zeros(thresh_num)
    c_db = np.zeros(thresh_num)
    delta = np.zeros(thresh_num)
    a_db[0] = a_db1
    c_db[0] = c_db1
    delta[0] = a_db1 - c_db1

    for j in range(1, thresh_num):
        a_db[j] = 10 * np.log10(sq / (a[j] + eps) + eps)
        c_db[j] = 20 * np.log10(c[j] + eps)

    for j in range(1, thresh_num):
        if a[j] != 0:
            delta[j] = a_db[j] - c_db[j]
            if delta[j] <= margin:
                asl_ms_log = _bin_interp(
                    {
                        "u_cnt": a_db[j],
                        "l_cnt": a_db[j - 1],
                        "u_thr": c_db[j],
                        "l_thr": c_db[j - 1],
                        "margin": margin,
                    },
                    tol=0.5,
                )
                return 10.0 ** (asl_ms_log / 10)

    return asl_msq


def _bin_interp(bounds: dict, tol: float) -> float:
    """Perform binary interpolation for active speech level calculation.

    Args:
        bounds: Dictionary containing interpolation bounds (`u_cnt`, `l_cnt`,
            `u_thr`, `l_thr`) and `margin`.
        tol: The tolerance for convergence.

    Returns:
        The interpolated active speech level value.

    """
    tol = abs(tol)

    # Check if extreme counts are not already the true active value
    iter_num = 1
    if abs(bounds["u_cnt"] - bounds["u_thr"] - bounds["margin"]) < tol:
        return bounds["u_cnt"]

    if abs(bounds["l_cnt"] - bounds["l_thr"] - bounds["margin"]) < tol:
        return bounds["l_cnt"]

    # Initialize first middle for given (initial) bounds
    m_cnt = (bounds["u_cnt"] + bounds["l_cnt"]) / 2.0
    m_thr = (bounds["u_thr"] + bounds["l_thr"]) / 2.0

    while True:
        # Loop until diff falls inside the tolerance (-tol<=diff<=tol)
        diff = m_cnt - m_thr - bounds["margin"]
        if abs(diff) <= tol:
            break

        # If tolerance is not met up to 20 iterations, then relax the tolerance by 10
        iter_num += 1
        if iter_num > 20:
            tol = tol * 1.1

        if diff > tol:
            m_cnt = (bounds["u_cnt"] + m_cnt) / 2.0
            m_thr = (bounds["u_thr"] + m_thr) / 2.0
        elif diff < -tol:
            m_cnt = (m_cnt + bounds["l_cnt"]) / 2.0
            m_thr = (m_thr + bounds["l_thr"]) / 2.0

    return m_cnt


def _asl_p56(audio: AudioT) -> float:
    from sonusai.constants import SAMPLE_RATE

    q, margin, eps, h_samples, c = _compute_envelope(audio, SAMPLE_RATE)
    sq = float(np.sum(np.square(audio)))
    a = _count_activity(q, c, h_samples, len(audio))
    return _compute_asl_from_thresholds(a, c, sq, eps, margin)
