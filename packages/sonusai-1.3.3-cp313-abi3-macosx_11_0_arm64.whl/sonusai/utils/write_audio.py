"""Utilities for writing audio data to files."""

import numpy as np
from pyaaware import rs as pars

from sonusai.constants import SAMPLE_RATE
from sonusai.datatypes import AudioT


def _to_array(audio: AudioT) -> np.ndarray:
    """Convert input audio payload to ndarray representation."""
    return np.asarray(audio)


def _normalize_dimensions(data: np.ndarray) -> np.ndarray:
    """Normalize 1D input to 2D and validate dimensionality contract."""
    if data.ndim == 1:
        data = np.reshape(data, (1, data.shape[0]))
    if data.ndim != 2:
        msg = "audio must be a 1D or 2D array"
        raise ValueError(msg)
    return data


def _normalize_orientation(data: np.ndarray) -> np.ndarray:
    """Apply transpose heuristic to maintain channels-first semantics."""
    # Assuming data has more samples than channels, check if array needs to be transposed
    if data.shape[1] < data.shape[0]:
        data = np.transpose(data, (1, 0))
    return data


def write_audio(name: str, audio: AudioT, sample_rate: int = SAMPLE_RATE) -> None:
    """Write an audio file to disk.

    To write multiple channels, use a 2D array of shape [channels, samples].
    The bits per sample and encoding (PCM/float) are determined by the data
    type.

    Args:
        name: The file path or name where audio will be saved.
        audio: The audio data (1D or 2D array).
        sample_rate: The sampling rate of the audio (default from constants).

    Raises:
        ValueError: If the audio data does not have 1 or 2 dimensions.

    """
    data = _to_array(audio)
    data = _normalize_dimensions(data)
    data = _normalize_orientation(data)

    if data.dtype == np.int16:
        data = data.astype(np.float32) / 32768.0
    elif data.dtype != np.float32:
        data = data.astype(np.float32)

    pars.write_wav(name, data, sample_rate)
