"""Utilities for processing and enhancing Python docstrings."""

import sys

import sonusai


def trim_docstring(docstring: str | None) -> str:
    """Trim leading whitespace from a docstring.

    Args:
        docstring: The docstring to trim.

    Returns:
        The trimmed docstring.

    """
    if not docstring:
        return ""

    # Convert tabs to spaces (following the normal Python rules)
    # and split into a list of lines:
    lines = docstring.expandtabs().splitlines()

    # Determine minimum indentation (first line doesn't count)
    indent = sys.maxsize
    for line in lines[1:]:
        stripped = line.lstrip()
        if stripped:
            indent = min(indent, len(line) - len(stripped))

    # Remove indentation (first line is special):
    trimmed = [lines[0].strip()]
    if indent < sys.maxsize:
        trimmed.extend(line[indent:].rstrip() for line in lines[1:])

    # Strip off leading blank lines:
    while trimmed and not trimmed[0]:
        trimmed.pop(0)

    # Return a single string
    while trimmed and not trimmed[-1]:
        trimmed.pop()

    return "\n".join(trimmed)


def add_commands_to_docstring(docstring: str | None, plugin_docstrings: list[str]) -> str:
    """Add plugin commands to a base docstring.

    Args:
        docstring: The base docstring to modify.
        plugin_docstrings: A list of docstrings from plugins.

    Returns:
        The updated docstring with all commands included.

    """
    lines = [] if not docstring else docstring.splitlines()

    start = lines.index("The sonusai commands are:")
    end = lines.index("", start)

    commands = sonusai.commands_doc.splitlines()
    for plugin_docstring in plugin_docstrings:
        commands.extend(plugin_docstring.splitlines())
    commands.sort()
    commands = list(filter(None, commands))

    lines = lines[: start + 1] + commands + lines[end:]

    return "\n".join(lines)
