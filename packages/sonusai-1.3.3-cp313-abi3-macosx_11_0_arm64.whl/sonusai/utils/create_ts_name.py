"""Utilities for creating unique timestamped directory or file names."""

from datetime import UTC
from datetime import datetime
from pathlib import Path


def create_ts_name(base: str) -> str:
    """Create a unique timestamped name based on a base string.

    Initially tries the base name with a YYYYMMDD suffix. If it exists,
    appends HHMMSS to ensure uniqueness.

    Args:
        base: The base string to use for the name.

    Returns:
        A timestamped name string.

    """
    ts = datetime.now(UTC)

    # First try just date
    dir_name = base + "-" + ts.strftime("%Y%m%d")
    if Path(dir_name).exists():
        # add hour-min-sec if necessary
        dir_name = base + "-" + ts.strftime("%Y%m%d-%H%M%S")

    return dir_name
