"""Utilities for managing random number generator seeds and contexts."""

from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from collections.abc import Generator


@contextlib.contextmanager
def seed_context(seed: int | None) -> Generator[None]:
    """Provide a context manager for temporarily setting the random seed.

    Resets the NumPy random state to its original value after the context
    is exited.

    Args:
        seed: The random seed to set. If None, the seed is not set.

    """
    state = np.random.get_state()
    np.random.seed(seed)
    try:
        yield
    finally:
        np.random.set_state(state)
