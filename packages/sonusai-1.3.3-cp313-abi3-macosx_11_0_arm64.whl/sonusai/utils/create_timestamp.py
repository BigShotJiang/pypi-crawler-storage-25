"""Utilities for creating ISO-like timestamps for filenames and logging."""

from datetime import UTC
from datetime import datetime


def create_timestamp() -> str:
    """Create a formatted timestamp string (YYYYMMDD-HHMMSS).

    Returns:
        A UTC timestamp string.

    """
    return datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
