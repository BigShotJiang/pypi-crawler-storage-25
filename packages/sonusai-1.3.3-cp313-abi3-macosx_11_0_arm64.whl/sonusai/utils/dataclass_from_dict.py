"""Utilities for recursively instantiating dataclasses from dictionaries."""

from __future__ import annotations

from typing import TYPE_CHECKING
from typing import Any
from typing import TypeVar

if TYPE_CHECKING:
    from collections.abc import Sequence

T = TypeVar("T")


def dataclass_from_dict[T](klass: type[T], dikt: dict[str, Any]) -> T | Any:  # noqa: ANN401
    """Recursively instantiate a dataclass from a dictionary.

    Args:
        klass: The dataclass type to instantiate.
        dikt: The dictionary containing field values.

    Returns:
        An instance of the dataclass or the original dictionary if conversion fails.

    """
    try:
        field_types = klass.__annotations__
        return klass(**{f: dataclass_from_dict(field_types[f], dikt[f]) for f in dikt if f in field_types})
    except AttributeError:
        return dikt


def list_dataclass_from_dict(klass: Any, dikt: Sequence[dict[str, Any]]) -> list[Any]:  # noqa: ANN401
    """Convert a list of dictionaries to a list of dataclasses.

    Args:
        klass: The list-like type containing the target dataclass.
        dikt: A sequence of dictionaries to convert.

    Returns:
        A list of dataclass instances.

    """
    return [dataclass_from_dict(klass.__args__[0], f) for f in dikt]
