"""Utilities for calculating text formatting widths."""

import numpy as np


def max_text_width(number_of_items: int) -> int:
    """Compute the maximum text width needed to display indices of a sequence.

    Args:
        number_of_items: Total number of items in the sequence.

    Returns:
        The text width of the largest item index.

    """
    return int(np.ceil(np.log10(number_of_items)))
