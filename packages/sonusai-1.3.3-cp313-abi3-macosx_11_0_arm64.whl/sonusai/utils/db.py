"""Utilities for converting between linear and decibel (dB) scales."""

import numpy as np


def linear_to_db(linear: float) -> float:
    """Convert a linear amplitude value to decibels (dB).

    Args:
        linear: The linear amplitude value to convert.

    Returns:
        The corresponding value in dB.

    """
    return 20 * np.log10(abs(linear))


def db_to_linear(db: float) -> float:
    """Convert a decibel (dB) value to a linear amplitude scale.

    Args:
        db: The value in dB to convert.

    Returns:
        The corresponding linear amplitude value.

    """
    return 10 ** (db / 20)
