"""Utilities for expanding and consolidating numeric range strings."""

import itertools
import re
from collections.abc import Generator


def expand_range(s: str, sort: bool = True) -> list[int]:
    """Return a list of integers from a string input representing a range.

    Examples of supported formats: "1-5", "1,2,5", "1:5", "1 2 5".

    Args:
        s: The string containing the range representation.
        sort: Whether to sort the resulting list (default: True).

    Returns:
        A list of integers within the specified ranges.

    """
    clean_s = s.replace(":", "-")
    clean_s = clean_s.replace(";", ",")
    clean_s = re.sub(r" +", ",", clean_s)
    clean_s = re.sub(r",+", ",", clean_s)

    r: list[int] = []
    for i in clean_s.split(","):
        if "-" not in i:
            r.append(int(i))
        else:
            lo, hi = map(int, i.split("-"))
            r += range(lo, hi + 1)

    if sort:
        r = sorted(r)

    return r


def consolidate_range(r: list[int]) -> str:
    """Return a concise string representation of a list of integers as ranges.

    Args:
        r: A list of integers to consolidate.

    Returns:
        A string where consecutive numbers are grouped as ranges (e.g., "1-3, 5").

    """

    def ranges(i: list[int]) -> Generator[tuple[int, int]]:
        """Identify continuous ranges in a sequence.

        Args:
            i: The sequence of integers.

        Yields:
            Tuples of (start, end) for each continuous range.

        """
        for _, b in itertools.groupby(enumerate(i), lambda pair: pair[1] - pair[0]):
            b_list = list(b)
            yield b_list[0][1], b_list[-1][1]

    ls: list[tuple[int, int]] = list(ranges(r))
    result: list[str] = []
    for val in ls:
        entry = str(val[0])
        if val[0] != val[1]:
            entry += f"-{val[1]}"
        result.append(entry)

    return ", ".join(result)
