"""Utilities for converting strings to numerical types when possible."""


def convert_string_to_number(string: str) -> float | int | str:
    """Attempt to convert a string to an integer or float.

    If the string cannot be converted, the original string is returned.

    Args:
        string: The string to convert.

    Returns:
        The converted number (int or float) or the original string.

    """
    try:
        result = float(string)
        return int(result) if result == int(result) else result
    except ValueError:
        return string
