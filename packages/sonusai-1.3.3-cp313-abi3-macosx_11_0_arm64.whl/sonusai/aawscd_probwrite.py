#!/usr/bin/env python3
"""Capture and write sound classification probability output to HDF5.

Usage:
    aawscd_probwrite [-h] [-m MACHINE] [-f FRAMES] FILE

Options:
    -h, --help                       Show this screen.
    -m MACHINE, --machine MACHINE    IP address of aawscd platform. [default: localhost].
    -f FRAMES, --frames FRAMES       Number of frames to capture. [default: 10].

aawscd_probwrite connects to an Aaware platform running aawscd and writes the sound classification
probability output to an HDF5 file.
"""

from __future__ import annotations

import signal
from threading import Condition
from typing import TYPE_CHECKING

import h5py
import numpy as np
import paho.mqtt.client as mqtt
import yaml
from docopt import docopt

from sonusai.utils.parallel import track

CLIENT: str = "aawscd_probwrite"
TOPIC: str = "aawscd/sc/prob"
DONE: Condition = Condition()
FRAMES: int = 10
FRAME_COUNT: int = 0
DATA: np.ndarray | None = None
PROGRESS: track | None = None


if TYPE_CHECKING:
    from typing import Any


def shutdown(_signum: int, _frame: Any) -> None:  # noqa: ANN401
    """Signal handler for graceful shutdown.

    Args:
        _signum: Signal number.
        _frame: Current stack frame.

    """
    global DONE
    with DONE:
        DONE.notify()


def unpack_prob_entry(entry: int) -> tuple[int, int, int]:
    """Decode the packed probability data.

    Data format: [ 16-bit label | 8-bit zone | 8-bit probability ].

    Args:
        entry: Packed probability entry.

    Returns:
        A tuple of (zone, label, value).

    """
    data = np.array(entry, dtype=np.uint32)
    label = np.right_shift(data, 16)
    zone = np.bitwise_and(np.right_shift(data, 8), 0xFF)
    value = np.bitwise_and(entry, 0xFF)
    return int(zone), int(label), int(value)


def parse_prob(payload: list) -> np.ndarray:
    """Parse MQTT probability payload from aawscd.

    The 'aawscd/sc/prob' payload is a list of uint32. Each item contains packed data and is
    unpacked/decoded and inserted into an array.

    Args:
        payload: MQTT probability payload.

    Returns:
        An array of probabilities.

    """
    # First pass: get the zones and labels to determine the size of the array
    zones = set()
    labels = set()
    for entry in payload:
        zone, label, _ = unpack_prob_entry(entry)
        zones.add(zone)
        labels.add(label)

    # Create the array
    prob = np.zeros((len(list(labels)), len(list(zones))), dtype=np.uint8)

    # Second pass: fill in the array probability values.
    for entry in payload:
        zone, label, value = unpack_prob_entry(entry)
        prob[label, zone] = value

    # Return the array
    return prob


def on_message(_client: mqtt.Client, _userdata: Any, message: mqtt.MQTTMessage) -> None:  # noqa: ANN401
    """Handle incoming MQTT messages.

    Args:
        _client: The client instance for this callback.
        _userdata: The private user data as set in Client() or user_data_set().
        message: An instance of MQTTMessage.

    """
    global TOPIC
    if mqtt.topic_matches_sub(TOPIC, message.topic):
        payload = yaml.safe_load(str(message.payload.decode("utf-8")))
        prob = parse_prob(payload["prob"])

        global DATA
        global FRAMES
        if DATA is None:
            DATA = np.zeros((FRAMES, prob.shape[0], prob.shape[1]), dtype=prob.dtype)

        global FRAME_COUNT
        DATA[FRAME_COUNT] = prob
        FRAME_COUNT += 1

        global PROGRESS
        PROGRESS.update()

        if FRAME_COUNT == FRAMES:
            global DONE
            with DONE:
                DONE.notify()


def main() -> None:
    """Execute the aawscd_probwrite CLI."""
    args = docopt(__doc__, version="1.0.0", options_first=True)

    machine = args["--machine"]

    global FRAMES
    FRAMES = int(args["--frames"])

    file = args["FILE"]

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    global CLIENT
    client = mqtt.Client(client_id=CLIENT)
    client.on_message = on_message
    client.connect(host=machine)
    client.loop_start()
    global TOPIC
    client.subscribe(topic=TOPIC)

    global PROGRESS
    PROGRESS = track(total=FRAMES, desc=file)

    with DONE:
        DONE.wait()

    PROGRESS.close()

    client.unsubscribe(topic=TOPIC)
    client.loop_stop()
    client.disconnect()

    global DATA
    with h5py.File(file, "w") as f:
        f.create_dataset(name="prob", data=DATA)


if __name__ == "__main__":
    main()
