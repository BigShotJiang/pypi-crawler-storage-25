"""TIMIT dataset loader."""

from __future__ import annotations

import string
from pathlib import Path

from sonusai.mixture.audio import get_sample_rate

from .types import TimeAlignedType


def load_text(audio: str | Path) -> TimeAlignedType | None:
    """Load time-aligned text data from a TIMIT audio file.

    Args:
        audio: Path to the TIMIT audio file.

    Returns:
        TimeAlignedType | None: A TimeAlignedType object, or None if not found.

    """
    file = Path(audio).with_suffix(".TXT")
    if not file.exists():
        return None

    sample_rate = get_sample_rate(str(audio))

    with file.open(encoding="utf-8") as f:
        line = f.read()

    fields = line.strip().split()
    start = int(fields[0]) / sample_rate
    end = int(fields[1]) / sample_rate
    text = " ".join(fields[2:]).lower().translate(str.maketrans("", "", string.punctuation))

    return TimeAlignedType(start, end, text)


def load_words(audio: str | Path) -> list[TimeAlignedType] | None:
    """Load time-aligned word data given a TIMIT audio file.

    :param audio: Path to the TIMIT audio file.
    :return: A list of TimeAlignedType objects.
    """
    return _load_ta(audio, "words")


def load_phonemes(audio: str | Path) -> list[TimeAlignedType] | None:
    """Load time-aligned phonemes data given a TIMIT audio file.

    :param audio: Path to the TIMIT audio file.
    :return: A list of TimeAlignedType objects.
    """
    return _load_ta(audio, "phonemes")


def _load_ta(audio: str | Path, tier: str) -> list[TimeAlignedType] | None:
    if tier == "words":
        file = Path(audio).with_suffix(".WRD")
    elif tier == "phonemes":
        file = Path(audio).with_suffix(".PHN")
    else:
        msg = f"Unknown tier: {tier}"
        raise ValueError(msg)

    if not file.exists():
        return None

    sample_rate = get_sample_rate(str(audio))

    entries: list[TimeAlignedType] = []
    first = True
    with file.open(encoding="utf-8") as f:
        for line in f:
            fields = line.strip().split()
            start = int(fields[0]) / sample_rate
            end = int(fields[1]) / sample_rate
            text = " ".join(fields[2:])

            if first:
                first = False
            else:
                if start < entries[-1].end:
                    start = entries[-1].end - (entries[-1].end - start) // 2
                    entries[-1] = TimeAlignedType(text=entries[-1].text, start=entries[-1].start, end=start)

                if end <= start:
                    end = start + 1 / sample_rate

            entries.append(TimeAlignedType(text=text, start=start, end=end))

    return entries


def _years_between(record: str, born: str) -> int | str:
    try:
        rec_fields = [int(x) for x in record.split("/")]
        brn_fields = [int(x) for x in born.split("/")]
        return rec_fields[2] - brn_fields[2] - ((rec_fields[1], rec_fields[0]) < (brn_fields[1], brn_fields[0]))
    except ValueError:
        return "??"


def _decode_dialect(d: str) -> str:
    dialect_map = {
        "DR1": "New England",
        "1": "New England",
        "DR2": "Northern",
        "2": "Northern",
        "DR3": "North Midland",
        "3": "North Midland",
        "DR4": "South Midland",
        "4": "South Midland",
        "DR5": "Southern",
        "5": "Southern",
        "DR6": "New York City",
        "6": "New York City",
        "DR7": "Western",
        "7": "Western",
        "DR8": "Army Brat",
        "8": "Army Brat",
    }
    if d not in dialect_map:
        msg = f"Unrecognized dialect: {d}"
        raise ValueError(msg)
    return dialect_map[d]


def load_speakers(input_dir: Path) -> dict[str, dict[str, str | int]]:
    """Load speaker information from TIMIT metadata.

    Args:
        input_dir: Path to the dataset directory.

    Returns:
        dict[str, dict[str, str | int]]: Dictionary mapping speaker IDs to
            gender, dialect, and age.

    """
    speakers = {}
    with (input_dir / "SPKRINFO.TXT").open() as file:
        for line in file:
            if not line.startswith(";"):
                fields = line.strip().split()
                speaker_id = fields[0]
                gender = fields[1]
                dialect = _decode_dialect(fields[2])
                age = _years_between(fields[4], fields[5])
                speakers[speaker_id] = {
                    "gender": gender,
                    "dialect": dialect,
                    "age": age,
                }
    return speakers
