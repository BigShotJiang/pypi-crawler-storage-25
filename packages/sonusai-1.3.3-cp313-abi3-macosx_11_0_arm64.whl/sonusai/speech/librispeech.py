"""LibriSpeech dataset loader."""

import os
import string
from pathlib import Path

from praatio import textgrid
from praatio.utilities.constants import Interval
from pyaaware import rs as pars

from sonusai.mixture.audio import get_sample_rate

from .types import TimeAlignedType


def _get_num_samples(audio: str | os.PathLike[str]) -> int:
    """Get the number of samples from an audio file.

    Args:
        audio: Audio file path.

    Returns:
        int: Number of samples.

    """
    return pars.get_audio_info(str(audio)).num_samples


def load_text(audio: str | os.PathLike[str]) -> TimeAlignedType | None:
    """Load text data from a LibriSpeech transcription file.

    Args:
        audio: Path to the LibriSpeech audio file.

    Returns:
        TimeAlignedType | None: A TimeAlignedType object, or None if not found.

    """
    path = Path(audio)
    name = path.stem
    transcript_filename = path.parent / f"{path.parent.parent.name}-{path.parent.name}.trans.txt"

    if not transcript_filename.exists():
        return None

    with transcript_filename.open(encoding="utf-8") as f:
        for line in f:
            fields = line.strip().split()
            key = fields[0]
            if key == name:
                text = " ".join(fields[1:]).lower().translate(str.maketrans("", "", string.punctuation))
                return TimeAlignedType(0, _get_num_samples(audio) / get_sample_rate(str(audio)), text)

    return None


def load_words(audio: str | os.PathLike[str]) -> list[TimeAlignedType] | None:
    """Load time-aligned word data given a LibriSpeech audio file.

    Args:
        audio: Path to the LibriSpeech audio file.

    Returns:
        list[TimeAlignedType] | None: A list of TimeAlignedType objects, or None if not found.

    """
    return _load_ta(audio, "words")


def load_phonemes(audio: str | os.PathLike[str]) -> list[TimeAlignedType] | None:
    """Load time-aligned phonemes data given a LibriSpeech audio file.

    Args:
        audio: Path to the LibriSpeech audio file.

    Returns:
        list[TimeAlignedType] | None: A list of TimeAlignedType objects, or None if not found.

    """
    return _load_ta(audio, "phones")


def _load_ta(audio: str | os.PathLike[str], tier: str) -> list[TimeAlignedType] | None:
    """Load time-aligned data from a TextGrid file.

    Args:
        audio: Path to the audio file.
        tier: Name of the tier to load.

    Returns:
        list[TimeAlignedType] | None: A list of TimeAlignedType objects, or None if not found.

    """
    file = Path(audio).with_suffix(".TextGrid")
    if not file.exists():
        return None

    tg = textgrid.openTextgrid(str(file), includeEmptyIntervals=False)
    if tier not in tg.tierNames:
        return None

    entries: list[TimeAlignedType] = []
    for entry in tg.getTier(tier).entries:
        if isinstance(entry, Interval):
            entries.append(TimeAlignedType(text=entry.label, start=entry.start, end=entry.end))
        else:
            entries.append(TimeAlignedType(text=entry.label, start=entry.time, end=entry.time))

    return entries


def load_speakers(input_dir: Path) -> dict:
    """Load speaker information from LibriSpeech metadata.

    Args:
        input_dir: Path to the dataset directory.

    Returns:
        dict: Dictionary mapping speaker IDs to gender.

    """
    speakers = {}
    with (input_dir / "SPEAKERS.TXT").open() as file:
        for line in file:
            if not line.startswith(";"):
                fields = line.strip().split("|")
                speaker_id = fields[0].strip()
                gender = fields[1].strip()
                speakers[speaker_id] = {"gender": gender}
    return speakers
