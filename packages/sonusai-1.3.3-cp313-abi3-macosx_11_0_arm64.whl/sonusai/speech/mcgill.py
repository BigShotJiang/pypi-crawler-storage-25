"""McGill-Speech dataset loader."""

import os
import string
import struct
from pathlib import Path

from sonusai.mixture.audio import get_sample_rate

from .types import TimeAlignedType


def _parse_chunk_text(raw_chunk: str) -> str | None:
    if not raw_chunk.startswith('text: "'):
        return None

    return raw_chunk[7:-1].lower().translate(str.maketrans("", "", string.punctuation))


def _parse_wav_header(content: bytes) -> tuple[int, int, int] | None:
    if len(content) < 36:
        return None

    riff_id, file_size, wave_id = struct.unpack("<4si4s", content[:12])
    fmt_id, fmt_size = struct.unpack("<4si", content[12:20])
    if (
        riff_id.decode("utf-8") != "RIFF"
        or wave_id.decode("utf-8") != "WAVE"
        or fmt_id.decode("utf-8") != "fmt "
        or fmt_size != 16
    ):
        return None

    _wave_format_tag, channels, _samples_per_sec, _avg_bytes_per_sec, _block_align, bits_per_sample = struct.unpack(
        "<hhiihh", content[20:36]
    )
    return file_size, channels, bits_per_sample


def _extract_mcgill_text_and_samples(
    content: bytes, file_size: int, channels: int, bits_per_sample: int
) -> tuple[str | None, float | None]:
    i = 36
    samples = None
    text = None
    while i < file_size:
        chunk_id = struct.unpack("<4s", content[i : i + 4])[0].decode("utf-8")
        chunk_size = struct.unpack("<i", content[i + 4 : i + 8])[0]

        if chunk_id == "data":
            samples = chunk_size / channels / (bits_per_sample / 8)
            break

        if chunk_id == "afsp":
            chunks = struct.unpack(f"<{chunk_size}s", content[i + 8 : i + 8 + chunk_size])[0]
            for chunk in chunks.decode("utf-8").split("\x00"):
                parsed_text = _parse_chunk_text(chunk)
                if parsed_text is not None:
                    text = parsed_text
        i += 8 + chunk_size + chunk_size % 2

    return text, samples


def load_text(audio: str | os.PathLike[str]) -> TimeAlignedType | None:
    """Load time-aligned text data from a McGill-Speech audio file.

    Args:
        audio: Path to the McGill-Speech audio file.

    Returns:
        TimeAlignedType | None: A TimeAlignedType object, or None if not found.

    """
    audio_path = Path(audio)
    if not audio_path.exists():
        return None

    with audio_path.open(mode="rb") as f:
        content = f.read()

    header = _parse_wav_header(content)
    if header is None:
        return None

    file_size, channels, bits_per_sample = header
    text, samples = _extract_mcgill_text_and_samples(content, file_size, channels, bits_per_sample)

    if not text or samples is None:
        return None

    sample_rate = get_sample_rate(str(audio_path))
    return TimeAlignedType(start=0, end=samples / sample_rate, text=text)
