"""VCTK dataset loader."""

import string
from pathlib import Path

from pyaaware import rs as pars

from .types import TimeAlignedType


def _get_duration(name: str) -> float:
    """Get the duration of an audio file.

    Args:
        name: Path to the audio file.

    Returns:
        float: Duration in seconds.

    Raises:
        OSError: If reading the file fails.

    """
    try:
        info = pars.get_audio_info(name)
        return info.num_samples / info.sample_rate
    except Exception as e:
        msg = f"Error reading {name}: {e}"
        raise OSError(msg) from e


def load_text(audio: str | Path) -> TimeAlignedType | None:
    """Load time-aligned text data from a VCTK audio file.

    Args:
        audio: Path to the VCTK audio file.

    Returns:
        TimeAlignedType | None: A TimeAlignedType object, or None if not found.

    """
    audio_path = Path(audio)
    file = audio_path.parents[2] / "txt" / audio_path.parent.name / (audio_path.stem[:-5] + ".txt")
    if not file.exists():
        return None

    with file.open(encoding="utf-8") as f:
        line = f.read()

    start = 0
    end = _get_duration(str(audio_path))
    text = line.strip().lower().translate(str.maketrans("", "", string.punctuation))

    return TimeAlignedType(start, end, text)


def load_speakers(input_dir: Path) -> dict:
    """Load speaker information from VCTK metadata.

    Args:
        input_dir: Path to the dataset directory.

    Returns:
        dict: Dictionary mapping speaker IDs to gender, dialect, and age.

    """
    speakers = {}
    with (input_dir / "speaker-info.txt").open() as file:
        for line in file:
            if not line.startswith("ID"):
                fields = line.strip().split("(", 1)[0].split()
                speaker_id = fields[0]
                age = fields[1]
                gender = fields[2]
                dialect = " ".join(list(fields[3:]))
                speakers[speaker_id] = {
                    "gender": gender,
                    "dialect": dialect,
                    "age": age,
                }
    return speakers
