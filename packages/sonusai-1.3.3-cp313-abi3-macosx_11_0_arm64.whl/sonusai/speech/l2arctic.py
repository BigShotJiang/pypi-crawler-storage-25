"""L2-ARCTIC dataset loader."""

import string
from pathlib import Path

from praatio import textgrid
from praatio.utilities.constants import Interval
from pyaaware import rs as pars

from .types import TimeAlignedType


def _get_duration(name: str) -> float:
    """Get duration of an audio file.

    Args:
        name: Path to the audio file.

    Returns:
        float: Duration in seconds.

    Raises:
        OSError: If reading the file fails.

    """
    try:
        info = pars.get_audio_info(name)
        return info.num_samples / info.sample_rate
    except Exception as e:
        msg = f"Error reading {name}: {e}"
        raise OSError(msg) from e


def load_text(audio: str | Path) -> TimeAlignedType | None:
    """Load time-aligned text data given a L2-ARCTIC audio file.

    Args:
        audio: Path to the L2-ARCTIC audio file.

    Returns:
        TimeAlignedType | None: A TimeAlignedType object, or None if not found.

    """
    file = Path(audio).parent.parent / "transcript" / (Path(audio).stem + ".txt")
    if not file.exists():
        return None

    with file.open(encoding="utf-8") as f:
        line = f.read()

    return TimeAlignedType(
        0,
        _get_duration(str(audio)),
        line.strip().lower().translate(str.maketrans("", "", string.punctuation)),
    )


def load_words(audio: str | Path) -> list[TimeAlignedType] | None:
    """Load time-aligned word data given a L2-ARCTIC audio file.

    Args:
        audio: Path to the L2-ARCTIC audio file.

    Returns:
        list[TimeAlignedType] | None: A list of TimeAlignedType objects, or None if not found.

    """
    return _load_ta(audio, "words")


def load_phonemes(audio: str | Path) -> list[TimeAlignedType] | None:
    """Load time-aligned phonemes data given a L2-ARCTIC audio file.

    Args:
        audio: Path to the L2-ARCTIC audio file.

    Returns:
        list[TimeAlignedType] | None: A list of TimeAlignedType objects, or None if not found.

    """
    return _load_ta(audio, "phones")


def _load_ta(audio: str | Path, tier: str) -> list[TimeAlignedType] | None:
    """Load time-aligned data from a TextGrid file.

    Args:
        audio: Path to the audio file.
        tier: Name of the tier to load.

    Returns:
        list[TimeAlignedType] | None: A list of TimeAlignedType objects, or None if not found.

    """
    file = Path(audio).parent.parent / "textgrid" / (Path(audio).stem + ".TextGrid")
    if not file.exists():
        return None

    tg = textgrid.openTextgrid(str(file), includeEmptyIntervals=False)
    if tier not in tg.tierNames:
        return None

    return [
        TimeAlignedType(text=entry.label, start=entry.start, end=entry.end)
        for entry in tg.getTier(tier).entries
        if isinstance(entry, Interval)
    ]


def load_annotations(
    audio: str | Path,
) -> dict[str, list[TimeAlignedType]] | None:
    """Load time-aligned annotation data given a L2-ARCTIC audio file.

    Args:
        audio: Path to the L2-ARCTIC audio file.

    Returns:
        dict[str, list[TimeAlignedType]] | None: A dictionary of lists of
            TimeAlignedType objects, or None if not found.

    """
    file = Path(audio).parent.parent / "annotation" / (Path(audio).stem + ".TextGrid")
    if not file.exists():
        return None

    tg = textgrid.openTextgrid(str(file), includeEmptyIntervals=False)
    result: dict[str, list[TimeAlignedType]] = {}
    for tier in tg.tierNames:
        result[tier] = [
            TimeAlignedType(text=entry.label, start=entry.start, end=entry.end)
            for entry in tg.getTier(tier).entries
            if isinstance(entry, Interval)
        ]

    return result


def load_speakers(input_dir: Path) -> dict:
    """Load speaker information from L2-ARCTIC readme.

    Args:
        input_dir: Path to the dataset directory.

    Returns:
        dict: Dictionary mapping speaker IDs to gender and dialect.

    """
    speakers = {}
    with (input_dir / "readme-download.txt").open() as file:
        processing = False
        for line in file:
            if not processing and line.startswith("|---|"):
                processing = True
                continue

            if processing:
                if line.startswith("|**Total**|"):
                    break
                fields = line.strip().split("|")
                speaker_id = fields[1]
                gender = fields[2]
                dialect = fields[3]
                speakers[speaker_id] = {"gender": gender, "dialect": dialect}

    return speakers
