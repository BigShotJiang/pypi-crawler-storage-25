"""Speech dataset types."""

from dataclasses import dataclass


@dataclass(frozen=True)
class TimeAlignedType:
    """Represents a time-aligned text segment.

    Attributes:
        start: Start time in seconds.
        end: End time in seconds.
        text: Transcribed text.

    """

    start: float
    end: float
    text: str

    @property
    def duration(self) -> float:
        """Calculate the duration of the segment.

        Returns:
            float: Duration in seconds.

        """
        return self.end - self.start
