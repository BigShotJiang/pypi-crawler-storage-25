"""Data directory for SonusAI."""
