"""Deprecated utility functions and scripts."""
