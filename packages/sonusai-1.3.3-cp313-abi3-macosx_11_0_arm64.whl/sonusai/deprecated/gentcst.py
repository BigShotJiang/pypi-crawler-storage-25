"""SonusAI gentcst utility.

Usage: gentcst [-hvru] [-o OUTPUT] [-f FOLD] [-y ONTOLOGY]

Options:
    -h, --help
    -v, --verbose                       Be verbose.
    -o OUTPUT, --output OUTPUT          Output file name.
    -f FOLD, --fold FOLD                Fold(s) to include. [default: *].
    -y ONTOLOGY, --ontology ONTOLOGY    Reference ontology JSON file for cross-check and adding metadata.
                                        [default: ontology.json].
    -r, --hierarchical                  Generate hierarchical multiclass truth for non-leaf nodes.
    -u, --update                        Write JSON metadata into the tree.

Generate a target SonusAI configuration file from a hierarchical subdirectory tree
under the local directory. Leaves in the subdirectory tree define classes by providing SonusAI list
.txt files for class data and additional truth config definitions. This offers a way to simplify and
more clearly manage hierarchical class structure similar to the Audioset ontology.

Features:
    - automatically compiles the target configuration with the number of classes and each truth
      index and the associated files (note: files should use absolute path with env variable)
    - supports hierarchical multilabel class truth generation, where higher nodes in the tree
      are included with leaf truth index, and different leaves with the same name will have the
      same index (i.e. door/squeak, chair/squeak, and brief-tone/squeak)
    - support config overrides for class config.yml or filename.yml for specific file config
    - manages folds via file prefix naming convention, i.e. 1-*.txt, 2-*.txt, etc.
      specifies data for fold 1, 2, etc.
    - cross-check node definitions with the reference ontology and auto copy class metadata into
      the tree to help define/collect data
    - class label is also generated (in the .yml or referencing a .csv)

Inputs:
    The local subdirectory tree with expected top-level configuration file config.yml. This
    file must at least define the feature and can have additional parameters treated as default
    (for truth, augmentation, etc.) which will be included in the generated output yaml file.
    An entire class dataset config parameter can be overridden by including it in a config.yml
    file in the class subdirectory. Individual file config parameters can be further overridden
    or specified in a file of the same name but with .yml (i.e. 1-data.yml with the 1-data.txt)

Outputs:
    output.yml
    output.csv
    gentcst.log
"""

from __future__ import annotations

import signal
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from types import FrameType  # noqa: PLC0415
from dataclasses import dataclass


def signal_handler(_sig: int, _frame: FrameType | None) -> None:
    """Handle termination signals.

    Args:
        _sig: The signal number.
        _frame: The current stack frame.

    """
    import sys  # noqa: PLC0415

    from sonusai import logger  # noqa: PLC0415

    logger.info("Canceled due to keyboard interrupt")
    sys.exit(1)


signal.signal(signal.SIGINT, signal_handler)

CONFIG_FILE = "config.yml"


@dataclass
class FileInfo:
    """Information about a data file.

    Attributes:
        file: Path to the file.
        classes: List of classes associated with the file.
        leaf: Leaf node name.
        labels: List of labels.
        fold: Fold number.
        truth_index: Optional list of truth indices.

    """

    file: str
    classes: list[str]
    leaf: str
    labels: list[str]
    fold: int
    truth_index: list[int] | None = None


@dataclass(frozen=True)
class DirInfo:
    """Information about a directory.

    Attributes:
        file: Directory path.
        classes: List of classes associated with the directory.

    """

    file: str
    classes: list[str]


@dataclass(frozen=True)
class LabelInfo:
    """Label information for a class.

    Attributes:
        index: Truth index.
        display_name: Human-readable name.

    """

    index: int
    display_name: str


@dataclass(frozen=True)
class OntologyInfo:
    """Ontology information for a class.

    Attributes:
        id: Unique identifier.
        name: List of names/aliases.
        description: Description of the class.
        citation_uri: Reference URI.
        positive_examples: List of example URIs.
        child_ids: List of children IDs.
        restrictions: List of restrictions.

    """

    id: str
    name: list[str]
    description: str
    citation_uri: str
    positive_examples: list[str]
    child_ids: list[str]
    restrictions: list[str]


def gentcst(  # noqa: C901, PLR0912, PLR0915
    fold: str = "*",
    ontology: str = "ontology.json",
    hierarchical: bool = False,
    update: bool = False,
    verbose: bool = False,
) -> tuple[dict, list[LabelInfo]]:
    """Generate target SonusAI configuration.

    Args:
        fold: Fold(s) to include.
        ontology: Reference ontology JSON file.
        hierarchical: If True, generate hierarchical multiclass truth.
        update: If True, write JSON metadata into the tree.
        verbose: If True, enable verbose logging.

    Returns:
        A tuple containing the generated configuration dictionary and label info list.

    """
    from copy import deepcopy  # noqa: PLC0415
    from pathlib import Path  # noqa: PLC0415

    from sonusai import SonusAIError  # noqa: PLC0415
    from sonusai import initial_log_messages  # noqa: PLC0415
    from sonusai import logger  # noqa: PLC0415
    from sonusai import update_console_handler  # noqa: PLC0415
    from sonusai.config.truth import validate_truth_configs  # noqa: PLC0415
    from sonusai.mixture.config import get_default_config  # noqa: PLC0415
    from sonusai.mixture.config import raw_load_config  # noqa: PLC0415
    from sonusai.mixture.config import update_config_from_hierarchy  # noqa: PLC0415

    update_console_handler(verbose)
    initial_log_messages("gentcst")

    if update:
        logger.info("Updating tree with JSON metadata")
        logger.info("")

    logger.debug(f"fold:         {fold}")
    logger.debug(f"ontology:     {ontology}")
    logger.debug(f"hierarchical: {hierarchical}")
    logger.debug(f"update:       {update}")
    logger.debug("")

    config = get_config()

    if config["truth_mode"] == "mutex" and hierarchical:
        msg = "Multi-class truth is incompatible with truth_mode mutex"
        raise SonusAIError(msg)

    all_files = get_all_files(hierarchical)
    all_folds = get_folds_from_files(all_files)
    use_folds = get_use_folds(all_folds, fold)
    use_files = get_files_from_folds(all_files, use_folds)
    report_leaf_fold_data_usage(all_files, use_files)

    ontology_data = validate_ontology(ontology, use_files)

    labels = get_labels_from_files(all_files)
    logger.debug("Truth indices:")
    for item in labels:
        logger.debug(f" {item.index:3} {item.display_name}")
    logger.debug("")

    gen_truth_indices(use_files, labels)

    config["num_classes"] = len(labels)
    if config["truth_mode"] == "mutex":
        config["num_classes"] = config["num_classes"] + 1

    config["targets"] = []

    logger.info(f"gentcst {len(use_files)} entries in tree")
    root = Path.cwd()
    for file in use_files:
        file_path = Path(file.file)
        leaf = str(file_path.parent)
        local_config = get_default_config()
        local_config = update_config_from_hierarchy(root=root, leaf=leaf, config=local_config)
        if not isinstance(local_config["truth_settings"], list):
            local_config["truth_settings"] = [local_config["truth_settings"]]

        specific_name = str(file_path.with_suffix(".yml"))
        if Path(specific_name).exists():
            specific_config = raw_load_config(specific_name)

            for key in specific_config:
                if key != "truth_settings":
                    local_config[key] = specific_config[key]
                else:
                    local_config["truth_settings"] = validate_truth_configs(
                        given=specific_config["truth_settings"],
                        default=local_config["truth_settings"],
                    )

        truth_settings = deepcopy(local_config["truth_settings"])
        for idx, val in enumerate(truth_settings):
            val["index"] = file.truth_index
            for key in ["function", "config"]:
                if key in val and val[key] == config["truth_settings"][idx][key]:
                    del val[key]

        target = {"name": file.file, "truth_settings": truth_settings}

        config["targets"].append(target)

        if update:
            write_metadata_to_tree(ontology_data, file)

    return config, labels


def get_ontology(ontology: str) -> list[OntologyInfo]:
    """Load ontology data from a JSON file.

    Args:
        ontology: Path to the ontology JSON file.

    Returns:
        A list of OntologyInfo objects.

    """
    import json  # noqa: PLC0415
    from pathlib import Path  # noqa: PLC0415

    raw_ontology_data = []
    ontology_path = Path(ontology)
    if ontology_path.exists():
        with ontology_path.open(encoding="utf-8") as f:
            raw_ontology_data = json.load(f)

    return [
        OntologyInfo(
            id=item["id"],
            name=convert_ontology_name(item["name"]),
            description=item["description"],
            citation_uri=item["citation_uri"],
            positive_examples=item["positive_examples"],
            child_ids=item["child_ids"],
            restrictions=item["restrictions"],
        )
        for item in raw_ontology_data
    ]


def convert_ontology_name(name: str) -> list[str]:
    """Convert names to lowercase, convert spaces to '-', split into lists on ','."""
    text = name.lower()
    # Need to find ', ' before converting spaces so that we don't convert ', ' to ',-'
    text = text.replace(", ", ",")
    text = text.replace(" ", "-")
    return text.split(",")


def get_dirs() -> list[DirInfo]:
    """Find all class directories in the current directory tree.

    Returns:
        A list of DirInfo objects for each class directory.

    """
    from os import walk  # noqa: PLC0415
    from pathlib import Path  # noqa: PLC0415

    cwd = Path.cwd()
    match: list[str] = sorted(
        str((Path(root) / d).relative_to(cwd)).replace("\\", "/") for root, ds, _ in walk(cwd) for d in ds
    )

    dirs: list[DirInfo] = []
    for m in match:
        if not m.startswith("./gentcst") and m != ".":
            classes = m.split("/")
            # Remove first element because it is '.'
            classes.pop(0)
            dirs.append(DirInfo(file=m, classes=classes))

    return dirs


def get_leaf_from_classes(classes: list[str]) -> str:
    """Join a list of classes into a leaf node path.

    Args:
        classes: List of class names.

    Returns:
        The leaf node path string.

    """
    return "/".join(classes)


def get_all_files(hierarchical: bool) -> list[FileInfo]:
    """Find all data files in the directory tree.

    Args:
        hierarchical: If True, include parent classes in labels.

    Returns:
        A list of FileInfo objects for all found files.

    """
    import re  # noqa: PLC0415
    from os import walk  # noqa: PLC0415
    from pathlib import Path  # noqa: PLC0415

    cwd = Path.cwd()
    regex = re.compile(r"^\d+-.*\.txt$")
    file_list: list[str] = [
        str((Path(root) / f).relative_to(cwd)).replace("\\", "/")
        for root, _, fs in walk(cwd)
        for f in fs
        if regex.match(f)
    ]

    files: list[FileInfo] = []
    fold_pattern = re.compile(r".*/(\d+)-.*\.txt")
    for file in file_list:
        fold_match = fold_pattern.match(file)
        if fold_match:
            fold = int(fold_match.group(1))

            classes = file.split("/")
            # Remove first element because it is '.'
            classes.pop(0)
            # Remove last element because it is the file name
            classes.pop()

            leaf = get_leaf_from_classes(classes)

            labels = classes if hierarchical else [leaf]

            files.append(FileInfo(file=file, classes=classes, leaf=leaf, labels=labels, fold=fold))

    return files


def get_use_folds(all_folds: list[int], fold: str) -> list[int]:
    """Determine which folds to use based on availability and request.

    Args:
        all_folds: List of all available fold numbers.
        fold: Fold selection string (e.g., "*", "1", "1-3").

    Returns:
        A list of fold numbers to include.

    """
    import numpy as np  # noqa: PLC0415

    from sonusai import logger  # noqa: PLC0415

    req_folds: list[int] = get_req_folds(all_folds, fold)
    use_folds: list[int] = list(set(req_folds).intersection(all_folds))

    logger.debug("Fold information")
    logger.debug(f" Available: {all_folds}")
    logger.debug(f" Requested: {req_folds}")
    logger.debug(f" Used:      {use_folds}")
    logger.debug(f" Unused:    {list(set(use_folds).symmetric_difference(all_folds))}")
    logger.debug(f" Missing:   {list(np.setdiff1d(req_folds, all_folds))}")
    logger.debug("")

    return use_folds


def get_files_from_folds(files: list[FileInfo], folds: list[int]) -> list[FileInfo]:
    """Filter files that belong to the specified folds.

    Args:
        files: List of FileInfo objects.
        folds: List of fold numbers to include.

    Returns:
        Filtered list of FileInfo objects.

    """
    return [file for file in files if file.fold in folds]


def get_item_from_name(ontology_data: list[OntologyInfo], name: str) -> OntologyInfo | None:
    """Find an ontology item by name.

    Args:
        ontology_data: List of ontology info.
        name: Name to look for.

    Returns:
        The matching OntologyInfo object, or None if not found.

    """
    return next((item for item in ontology_data if name in item.name), None)


def get_item_from_id(ontology_data: list[OntologyInfo], identity: str) -> OntologyInfo | None:
    """Find an ontology item by ID.

    Args:
        ontology_data: List of ontology info.
        identity: ID to look for.

    Returns:
        The matching OntologyInfo object, or None if not found.

    """
    return next((item for item in ontology_data if item.id == identity), None)


def get_name_from_id(ontology_data: list[OntologyInfo], identity: str) -> list[str] | None:
    """Get names for a given ontology ID.

    Args:
        ontology_data: List of ontology info.
        identity: ID to look for.

    Returns:
        List of names for the ID, or None if not found.

    Raises:
        SonusAIError: If the ID appears multiple times in the ontology.

    """
    from sonusai import SonusAIError  # noqa: PLC0415

    name = None
    found = False

    for item in ontology_data:
        if item.id == identity:
            if found:
                msg = f"id {identity} appears multiple times in ontology"
                raise SonusAIError(msg)

            name = item.name
            found = True

    return name


def get_id_from_name(ontology_data: list[OntologyInfo], name: str) -> str | None:
    """Get the ID for a given ontology name.

    Args:
        ontology_data: List of ontology info.
        name: Name to look for.

    Returns:
        The ID string for the name, or None if not found.

    Raises:
        SonusAIError: If the name appears multiple times in the ontology.

    """
    from sonusai import SonusAIError  # noqa: PLC0415

    identity = None
    found = False

    for item in ontology_data:
        if name in item.name:
            if found:
                msg = f"name {name} appears multiple times in ontology"
                raise SonusAIError(msg)

            identity = item.id
            found = True

    return identity


def is_valid_name(ontology_data: list[OntologyInfo], name: str) -> bool:
    """Check if a name exists in the ontology.

    Args:
        ontology_data: List of ontology info.
        name: Name to check.

    Returns:
        True if the name is found in the ontology.

    """
    return any(name in item.name for item in ontology_data)


def is_valid_child(ontology_data: list[OntologyInfo], parent: str, child: str) -> bool:
    """Check if a child class is a valid child of a parent class in the ontology.

    Args:
        ontology_data: List of ontology info.
        parent: Parent class name.
        child: Child class name.

    Returns:
        True if the child is a valid descendant of the parent.

    """
    valid = False
    parent_item = get_item_from_name(ontology_data, parent)
    child_id = get_id_from_name(ontology_data, child)

    if child_id is not None and parent_item is not None and child_id in parent_item.child_ids:
        valid = True

    return valid


def is_valid_hierarchy(ontology_data: list[OntologyInfo], classes: list[str]) -> bool:
    """Check if a hierarchy of classes is valid in the ontology.

    Args:
        ontology_data: List of ontology info.
        classes: List of class names representing a hierarchy.

    Returns:
        True if all parent-child relationships in the hierarchy are valid.

    """
    from itertools import pairwise  # noqa: PLC0415

    valid = True

    for parent, child in pairwise(classes):
        if not is_valid_child(ontology_data, parent, child):
            valid = False

    return valid


def validate_class(ontology_data: list[OntologyInfo], item: FileInfo | DirInfo) -> bool:
    """Validate a FileInfo or DirInfo against the ontology.

    Args:
        ontology_data: List of ontology info.
        item: The file or directory info to validate.

    Returns:
        True if the item's classes and hierarchy are valid.

    """
    from sonusai import logger  # noqa: PLC0415

    valid = True

    for c in item.classes:
        if not is_valid_name(ontology_data, c):
            logger.warning(f" Could not find {c} in ontology for {item.file}")
            valid = False

    if valid and not is_valid_hierarchy(ontology_data, item.classes):
        logger.warning(f" Invalid parent/child relationship for {item.file}")
        valid = False

    return valid


def get_req_folds(folds: list[int], fold: str) -> list[int]:
    """Parse and expand requested fold ranges.

    Args:
        folds: List of available fold numbers.
        fold: Fold selection string.

    Returns:
        List of requested fold numbers.

    """
    from sonusai.utils.ranges import expand_range  # noqa: PLC0415

    if fold == "*":
        return folds

    return expand_range(fold)


def get_folds_from_files(files: list[FileInfo]) -> list[int]:
    """Get a sorted list of unique fold numbers from a list of files.

    Args:
        files: List of FileInfo objects.

    Returns:
        Sorted list of unique fold numbers.

    """
    result: list[int] = [file.fold for file in files]
    # Converting to set and back to list ensures uniqueness
    return sorted(set(result))


def get_leaves_from_files(files: list[FileInfo]) -> list[str]:
    """Get a sorted list of unique leaf node names from a list of files.

    Args:
        files: List of FileInfo objects.

    Returns:
        Sorted list of unique leaf node names.

    """
    result: list[str] = [file.leaf for file in files]
    # Converting to set and back to list ensures uniqueness
    return sorted(set(result))


def get_labels_from_files(files: list[FileInfo]) -> list[LabelInfo]:
    """Generate LabelInfo objects from a list of files.

    Args:
        files: List of FileInfo objects.

    Returns:
        List of LabelInfo objects, prioritized by depth.

    """
    all_labels = [file.labels for file in files]

    # Get labels by depth
    labels_by_depth: list[list[str]] = [[] for _ in range(max([len(label) for label in all_labels]))]
    for label in all_labels:
        for index, name in enumerate(label):
            labels_by_depth[index].append(name)

    for n in range(len(labels_by_depth)):
        # Converting to set and back to list ensures uniqueness
        labels_by_depth[n] = sorted(set(labels_by_depth[n]))

    # We want the deepest leaves first
    labels_by_depth.reverse()

    # Now flatten the list
    flattened_labels_by_depth = [item for sublist in labels_by_depth for item in sublist]

    # Generate index, name pairs
    return [LabelInfo(index=index + 1, display_name=file) for index, file in enumerate(flattened_labels_by_depth)]


def gen_truth_indices(files: list[FileInfo], labels: list[LabelInfo]) -> None:
    """Populate truth_index for each file based on its labels.

    Args:
        files: List of FileInfo objects to update.
        labels: List of all LabelInfo objects.

    """
    for file in files:
        file.truth_index = sorted([get_index_from_label(labels, label) for label in file.labels])


def get_index_from_label(labels: list[LabelInfo], label: str) -> int:
    """Get the truth index for a label name.

    Args:
        labels: List of LabelInfo objects.
        label: Label name to look for.

    Returns:
        The truth index for the label.

    """
    return next((item for item in labels if item.display_name == label), None).index


def get_config() -> dict:
    """Load and validate the top-level configuration file.

    Returns:
        The configuration dictionary.

    Raises:
        SonusAIError: If the config file is missing or invalid.

    """
    from pathlib import Path  # noqa: PLC0415

    from sonusai import SonusAIError  # noqa: PLC0415
    from sonusai.mixture import raw_load_config  # noqa: PLC0415

    if not Path(CONFIG_FILE).exists():
        msg = f"No {CONFIG_FILE} at top level"
        raise SonusAIError(msg)

    config = raw_load_config(CONFIG_FILE)

    if "feature" not in config:
        msg = "feature not in top level config"
        raise SonusAIError(msg)

    if "truth_mode" not in config:
        msg = "truth_mode not in top level config"
        raise SonusAIError(msg)

    if config["truth_mode"] not in ["normal", "mutex"]:
        msg = "Invalid truth_mode in top level config"
        raise SonusAIError(msg)

    if "truth_settings" in config and not isinstance(config["truth_settings"], list):
        config["truth_settings"] = [config["truth_settings"]]

    return config


def validate_ontology(ontology: str, items: list[FileInfo] | list[DirInfo]) -> list[OntologyInfo]:
    """Validate the local directory tree and files against a reference ontology.

    Args:
        ontology: Path to the reference ontology JSON file.
        items: List of FileInfo or DirInfo objects to validate.

    Returns:
        The loaded ontology data if validation succeeds, otherwise an empty list.

    """
    from pathlib import Path  # noqa: PLC0415

    from sonusai import logger  # noqa: PLC0415

    if Path(ontology).exists():
        ontology_data = get_ontology(ontology)
        logger.debug(f"Reference ontology in {ontology} has {len(ontology_data)} classes")
        logger.debug("")

        logger.info("Checking tree against reference ontology")
        all_dirs = get_dirs()
        valid = True
        for file in all_dirs:
            if not validate_class(ontology_data, file):
                valid = False
        if valid:
            logger.info("PASS")
        logger.info("")

        logger.info("Checking files against reference ontology")
        valid = True
        for item in items:
            if not validate_class(ontology_data, item):
                valid = False
        if valid:
            logger.info("PASS")
        logger.info("")

        return ontology_data

    return []


def get_node_from_name(ontology_data: list[OntologyInfo], name: str) -> OntologyInfo | None:
    """Find a single ontology node by name.

    Args:
        ontology_data: List of ontology info.
        name: Name to look for.

    Returns:
        The matching OntologyInfo object, or None if not found or ambiguous.

    """
    from sonusai import logger  # noqa: PLC0415

    nodes = [item for item in ontology_data if name in item.name]
    if len(nodes) == 1:
        return nodes[0]

    if nodes:
        logger.warning(f"Found multiple entries in reference ontology that match {name}")
    else:
        logger.warning(f"Could not find entry for {name} in reference ontology")

    return None


def write_metadata_to_tree(ontology_data: list[OntologyInfo], file: FileInfo) -> None:
    """Write ontology metadata for a file's class to a JSON file in its directory.

    Args:
        ontology_data: List of ontology info.
        file: FileInfo object containing class information.

    """
    import json  # noqa: PLC0415
    from dataclasses import asdict  # noqa: PLC0415
    from pathlib import Path  # noqa: PLC0415

    if ontology_data:
        node = get_node_from_name(ontology_data, file.classes[-1])
        if node is not None:
            dir_path = Path(file.file).parent
            json_name = dir_path / f"{dir_path.name}.json"
            with json_name.open(mode="w") as f:
                json.dump(asdict(node), f)


def get_folds_from_leaf(all_files: list[FileInfo], leaf: str) -> list[int]:
    """Get all unique fold numbers associated with a specific leaf node.

    Args:
        all_files: List of all FileInfo objects.
        leaf: Leaf node name.

    Returns:
        Sorted list of unique fold numbers.

    """
    files = [item for item in all_files if item.leaf == leaf]
    return get_folds_from_files(files)


def report_leaf_fold_data_usage(all_files: list[FileInfo], use_files: list[FileInfo]) -> None:
    """Log information about data folds present in each leaf and any missing data.

    Args:
        all_files: List of all available FileInfo objects.
        use_files: List of FileInfo objects being used.

    """
    from sonusai import logger  # noqa: PLC0415

    use_leaves = get_leaves_from_files(use_files)
    all_leaves = get_leaves_from_files(all_files)

    logger.debug("Data folds present in each leaf")
    leaf_len = len(max(all_leaves, key=len))
    for leaf in all_leaves:
        folds = get_folds_from_leaf(all_files, leaf)
        logger.debug(f" {leaf:{leaf_len}} {folds}")
    logger.debug("")

    dif_leaves = set(all_leaves).symmetric_difference(use_leaves)
    if dif_leaves:
        logger.warning("This fold selection is missing data from the following leaves")
        for c in dif_leaves:
            logger.warning(f" {c}")
        logger.warning("")


def main() -> None:
    """Run the gentcst utility."""
    from docopt import docopt  # noqa: PLC0415

    import sonusai  # noqa: PLC0415
    from sonusai.utils.docstring import trim_docstring  # noqa: PLC0415

    args = docopt(trim_docstring(__doc__), version=sonusai.__version__, options_first=True)

    verbose = args["--verbose"]
    output_name = args["--output"]
    fold = args["--fold"]
    ontology = args["--ontology"]
    hierarchical = args["--hierarchical"]
    update = args["--update"]

    import csv  # noqa: PLC0415
    from dataclasses import asdict  # noqa: PLC0415
    from pathlib import Path  # noqa: PLC0415

    import yaml  # noqa: PLC0415

    from sonusai import create_file_handler  # noqa: PLC0415
    from sonusai import logger  # noqa: PLC0415

    if not output_name:
        output_name = f"{Path.cwd().name}.yml"

    create_file_handler("gentcst.log")

    config, labels = gentcst(
        fold=fold,
        ontology=ontology,
        hierarchical=hierarchical,
        update=update,
        verbose=verbose,
    )

    output_path = Path(output_name)
    with output_path.open(mode="w") as f:
        yaml.dump(config, f)
        logger.info(f"Wrote config to {output_name}")

    csv_fields = ["index", "display_name"]
    csv_name = str(output_path.with_suffix(".csv"))

    with Path(csv_name).open(mode="w") as f:
        writer = csv.DictWriter(f, fieldnames=csv_fields)
        writer.writeheader()
        writer.writerows([asdict(label) for label in labels])
        logger.info(f"Wrote labels to {csv_name}")


if __name__ == "__main__":
    main()
