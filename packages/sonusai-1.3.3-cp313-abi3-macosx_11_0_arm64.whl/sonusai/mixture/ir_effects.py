"""Impulse response processing utilities for mixtures."""

from contextlib import AbstractContextManager
from contextlib import nullcontext
from functools import lru_cache
from pathlib import Path
from typing import TYPE_CHECKING
from typing import Optional

import numpy as np
from pyaaware.rs import resample
from scipy.signal import fftconvolve

if TYPE_CHECKING:
    from sonusai.perf.timer import PhaseTimer

from sonusai.constants import RESAMPLE_MODE
from sonusai.constants import SAMPLE_RATE
from sonusai.datatypes import AudioT
from sonusai.datatypes import ImpulseResponseData

from .audio import raw_read_audio


def apply_ir(audio: AudioT, ir: ImpulseResponseData, timer: Optional["PhaseTimer"] = None) -> AudioT:
    """Apply impulse response to audio data using scipy.

    Args:
        audio: Input audio data.
        ir: Impulse response data.
        timer: Optional PhaseTimer for performance instrumentation.

    Returns:
        Audio data after applying the impulse response.

    Raises:
        TypeError: If audio is not a numpy array.

    """

    def _measure(stage: str) -> AbstractContextManager[None]:
        if timer:
            return timer.measure(stage)
        return nullcontext()

    if not isinstance(audio, np.ndarray):
        msg = "audio must be a numpy array"
        raise TypeError(msg)

    # Early exit if no ir or if all audio is zero
    with _measure("ir_zero_audio_check"):
        if ir is None or not audio.any():
            return audio

    pk_in = np.max(np.abs(audio))

    # Convert audio to IR sample rate
    if ir.sample_rate == SAMPLE_RATE:
        audio_in = audio
    else:
        with _measure("ir_input_resample"):
            audio_in = resample(audio, orig_sr=SAMPLE_RATE, target_sr=ir.sample_rate, mode=RESAMPLE_MODE)

    # Apply IR
    with _measure("ir_convolution"):
        audio_out = fftconvolve(audio_in, ir.data, mode="full")

    # Delay compensation
    with _measure("ir_delay_compensation"):
        audio_out = audio_out[ir.delay :]

    # Convert back to the global sample rate
    if ir.sample_rate == SAMPLE_RATE:
        audio_out_resampled = audio_out
    else:
        with _measure("ir_output_resample"):
            audio_out_resampled = resample(
                audio_out,
                orig_sr=ir.sample_rate,
                target_sr=SAMPLE_RATE,
                mode=RESAMPLE_MODE,
            )

    # Trim to length
    with _measure("ir_trim"):
        audio_out = audio_out_resampled[: len(audio)]

    # Gain compensation
    with _measure("ir_gain_compensation"):
        pk_out = np.max(np.abs(audio_out))
        pk_gain = pk_in / pk_out
        return audio_out * pk_gain


def read_ir(name: str | Path, delay: int, use_cache: bool = True) -> ImpulseResponseData:
    """Read impulse response data from a file.

    Args:
        name: Path to the IR file.
        delay: Delay in samples.
        use_cache: If true, use LRU caching.

    Returns:
        ImpulseResponseData containing the audio data and sample rate.

    """
    if use_cache:
        return _read_ir(name, delay)
    return _read_ir.__wrapped__(name, delay)


@lru_cache
def _read_ir(name: str | Path, delay: int) -> ImpulseResponseData:
    """Read impulse response data.

    Args:
        name: Path to the IR file.
        delay: Delay in samples.

    Returns:
        ImpulseResponseData containing the audio data and sample rate.

    """
    out, sample_rate = raw_read_audio(name)
    return ImpulseResponseData(data=out, sample_rate=sample_rate, delay=delay)
