"""Audio processing utilities for SonusAI mixtures."""

from __future__ import annotations

import math
from functools import cache
from functools import lru_cache
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np
from pyaaware import rs as pars

if TYPE_CHECKING:
    from sonusai.datatypes import AudioT

from sonusai.constants import RESAMPLE_MODE
from sonusai.constants import SAMPLE_RATE
from sonusai.utils.tokenized_shell_vars import tokenized_expand


def get_next_noise(audio: AudioT, offset: int, length: int) -> AudioT:
    """Get the next sequence of noise data from noise audio.

    Args:
        audio: Overall noise audio (entire file's worth of data).
        offset: Starting sample index.
        length: Number of samples to get.

    Returns:
        Sequence of noise audio data.

    """
    return np.take(audio, range(offset, offset + length), mode="wrap")


def get_duration(audio: AudioT) -> float:
    """Get the duration of audio in seconds.

    Args:
        audio: Time domain data [samples].

    Returns:
        Duration of audio in seconds.

    """
    return len(audio) / SAMPLE_RATE


def validate_input_file(input_filepath: str | Path) -> None:
    """Validate that the input file exists and its format is supported.

    Args:
        input_filepath: Path to the input audio file.

    Raises:
        OSError: If the file does not exist or the format is not supported.

    """
    path = Path(input_filepath)
    if not path.exists():
        msg = f"input_filepath {input_filepath} does not exist."
        raise OSError(msg)

    ext = path.suffix[1:].lower()
    read_formats = _get_supported_formats()
    if ext not in read_formats:
        msg = f"This installation cannot process .{ext} files"
        raise OSError(msg)


def get_sample_rate(name: str | Path, use_cache: bool = True) -> int:
    """Get the sample rate from an audio file.

    Args:
        name: File name.
        use_cache: If true, use LRU caching.

    Returns:
        Sample rate.

    """
    if use_cache:
        return _get_sample_rate(name)
    return _get_sample_rate.__wrapped__(name)


@cache
def _get_sample_rate(name: str | Path) -> int:
    """Get the sample rate from an audio file.

    Args:
        name: File name.

    Returns:
        Sample rate.

    """
    expanded_name, _ = tokenized_expand(name)

    try:
        info = pars.get_audio_info(expanded_name)
    except Exception as e:
        if name != expanded_name:
            msg = f"Error reading {name} (expanded: {expanded_name}): {e}"
            raise OSError(msg) from e
        msg = f"Error reading {name}: {e}"
        raise OSError(msg) from e
    else:
        return info.sample_rate


def raw_read_audio(name: str | Path) -> tuple[AudioT, int]:
    """Read raw audio data and sample rate from a file.

    Args:
        name: File name.

    Returns:
        A tuple containing the audio data and the sample rate.

    """
    expanded_name, _ = tokenized_expand(name)

    return pars.raw_read_audio(expanded_name)


def read_audio(name: str | Path, use_cache: bool = True) -> AudioT:
    """Read audio data from a file.

    Args:
        name: File name.
        use_cache: If true, use LRU caching.

    Returns:
        Array of time domain audio data.

    """
    if use_cache:
        return _read_audio(name)
    return _read_audio.__wrapped__(name)


@lru_cache(maxsize=1024)
def _read_audio(name: str | Path) -> AudioT:
    """Read audio data from a file using pyaaware.

    Args:
        name: File name.

    Returns:
        Array of time domain audio data.

    """
    expanded_name, _ = tokenized_expand(name)

    return pars.read_audio(expanded_name, SAMPLE_RATE, RESAMPLE_MODE)


def get_num_samples(name: str | Path, use_cache: bool = True) -> int:
    """Get the number of samples resampled to the SonusAI sample rate.

    Args:
        name: File name.
        use_cache: If true, use LRU caching.

    Returns:
        Number of samples in resampled audio.

    """
    if use_cache:
        return _get_num_samples(name)
    return _get_num_samples.__wrapped__(name)


@cache
def _get_num_samples(name: str | Path) -> int:
    """Get the number of samples resampled to the SonusAI sample rate.

    Args:
        name: File name.

    Returns:
        Number of samples in resampled audio.

    """
    expanded_name, _ = tokenized_expand(name)

    try:
        info = pars.get_audio_info(expanded_name)
        samples = info.num_samples
        sample_rate = info.sample_rate
    except Exception as e:
        if name != expanded_name:
            msg = f"Error reading {name} (expanded: {expanded_name}): {e}"
            raise OSError(msg) from e
        msg = f"Error reading {name}: {e}"
        raise OSError(msg) from e

    return math.ceil(SAMPLE_RATE * samples / sample_rate)


@lru_cache(maxsize=1)
def _get_supported_formats() -> list[str]:
    return [item.lower() for item in pars.get_supported_formats()]


def get_cache_metrics() -> dict:
    """Get internal cache metrics."""
    return {
        "sample_rate": _get_sample_rate.cache_info()._asdict(),
        "num_samples": _get_num_samples.cache_info()._asdict(),
        "supported_formats": _get_supported_formats.cache_info()._asdict(),
        "read_audio": _read_audio.cache_info()._asdict(),
    }
