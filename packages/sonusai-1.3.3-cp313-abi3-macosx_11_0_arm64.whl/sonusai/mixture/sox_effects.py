"""Utilities for applying SoX effects to audio data."""

import subprocess
from functools import lru_cache
from inspect import getmembers
from inspect import isfunction
from shlex import split

import numpy as np

from sonusai.constants import SAMPLE_RATE
from sonusai.datatypes import AudioT

from . import effects_help


def validate_sox_effects(effects: list[str]) -> None:
    """Validate that the given SoX effects are supported and syntactically correct.

    Args:
        effects: List of SoX effect strings to validate.

    Raises:
        ValueError: If an effect is not supported or if SoX returns an error.

    """
    zeros = np.zeros((1, 100), dtype=np.float32)

    for effect in effects:
        name = effect.split()[0]
        if name not in list_sox_effects():
            msg = f"Effect {name} is not supported."
            raise ValueError(msg)

    args_list = _build_sox_args(effects)

    for args in args_list:
        process_handle = subprocess.Popen(  # noqa: S603
            args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        _, stderr = process_handle.communicate(zeros.T.tobytes(order="F"))
        stderr = stderr.decode("utf-8")
        status = process_handle.returncode

        if status != 0:
            msg = f"For SoX effects: {' '.join(effects)}\n{stderr}"
            raise ValueError(msg)


def apply_sox_effects(audio: AudioT, effects: list[str]) -> AudioT:
    """Apply SoX effects to audio data.

    Args:
        audio: Input audio data.
        effects: List of SoX effect strings to apply.

    Returns:
        Audio data after applying the effects.

    Raises:
        RuntimeError: If `sox` returns an error or if an unexpected length change occurs.

    """
    new_audio = audio.copy()

    args_list = _build_sox_args(effects)
    for args in args_list:
        process_handle = subprocess.Popen(  # noqa: S603
            args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        stdout, stderr = process_handle.communicate(new_audio.T.tobytes(order="F"))
        stderr = stderr.decode("utf-8")
        status = process_handle.returncode

        if status != 0:
            raise RuntimeError(stderr)

        old_samples = len(new_audio)
        new_audio = np.frombuffer(stdout, dtype=audio.dtype)

        # The length sometimes changes +/-1 with the 'pitch' effect;
        # force the output back to the original length
        new_samples = len(new_audio)
        if "pitch" in args:
            if abs(new_samples - old_samples) > 1:
                msg = (
                    "Encountered unexpected length change during 'pitch' effect:\n"
                    f"{' '.join(args)}\n"
                    f"original length: {old_samples}, new length: {new_samples}"
                )
                raise RuntimeError(msg)
            if new_samples < old_samples:
                new_audio = np.pad(array=new_audio, pad_width=(0, old_samples - new_samples))
            elif new_samples > old_samples:
                new_audio = new_audio[:old_samples]

    return new_audio


def _build_sox_args(effects: list[str], base_args: list | None = None) -> list[list[str]]:
    """Build the command-line arguments for SoX.

    Args:
        effects: List of effect strings.
        base_args: Optional base arguments to use (e.g. for different I/O formats).

    Returns:
        A list of argument lists, where each list represents a SoX command chain.

    """
    if base_args is None:
        base_args = [
            "sox",
            "-D",  # don't dither automatically
            "-V2",  # set verbosity to warning
            "-t",  # set input file type
            "f32",
            "-r",  # set input sample rate
            SAMPLE_RATE,
            "-c",  # set input channels
            1,
            "-",
            "-t",  # set output file type
            "f32",
            "-r",  # set output sample rate
            SAMPLE_RATE,
            "-c",  # set output channels
            1,
            "-",
        ]

    result: list[list[str]] = []
    args: list = []
    for effect in effects:
        # If this is a pitch effect and there were other effects already,
        # isolate those other effects and start a new chain
        if (effect == "pitch" or effect.startswith("pitch ")) and args:
            result.append([str(x) for x in base_args + args])
            args = []

        args.extend(split(effect))

        # If this is a pitch effect, finish isolating it as its own chain
        # This allows "fixing" the length after applying the effect
        if "pitch" in args:
            result.append([str(x) for x in base_args + args])
            args = []

    if args:
        result.append([str(x) for x in base_args + args])

    return result


@lru_cache
def list_sox_effects() -> list[str]:
    """List all supported audio effects.

    Returns:
        A list of supported effect names.

    """
    return [member[0] for member in getmembers(effects_help, isfunction)]


def help_sox_effects(name: str) -> str:
    """Get help information for a specific SoX effect.

    Args:
        name: Name of the effect.

    Returns:
        Help string for the effect.

    Raises:
        ValueError: If the effect is not supported.

    """
    if name not in list_sox_effects():
        msg = f"Effect {name} not supported."
        raise ValueError(msg)

    return getattr(effects_help, name)()


def apply_sox_effects_i32(audio: np.ndarray, effects: list[str]) -> np.ndarray:
    """Apply SoX effects to int32 audio data using raw 32-bit integer I/O.

    This avoids quantization noise introduced by float32 I/O at the SoX boundary.

    Args:
        audio: Input audio data (int32).
        effects: List of SoX effect strings to apply.

    Returns:
        Audio data after applying the effects (int32).

    Raises:
        RuntimeError: If `sox` returns an error or if an unexpected length change occurs.
        ValueError: If audio is not int32.

    """
    if audio.dtype != np.int32:
        msg = f"Expected int32 audio, got {audio.dtype}"
        raise ValueError(msg)

    new_audio = audio

    # Build the base arguments for int32 raw I/O
    # -t raw -b 32 -e signed-integer
    i32_format = [
        "-t",
        "raw",
        "-b",
        "32",
        "-e",
        "signed-integer",
        "-r",
        SAMPLE_RATE,
        "-c",
        1,
        "-",
    ]
    base_args = ["sox", "-D", "-V2", *i32_format, *i32_format]

    args_list = _build_sox_args(effects, base_args=base_args)
    for args in args_list:
        process_handle = subprocess.Popen(  # noqa: S603
            args,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        stdout, stderr = process_handle.communicate(new_audio.tobytes(order="C"))
        stderr = stderr.decode("utf-8")
        status = process_handle.returncode

        if status != 0:
            raise RuntimeError(stderr)

        old_samples = len(new_audio)
        new_audio = np.frombuffer(stdout, dtype=np.int32)

        # The length sometimes changes +/-1 with the 'pitch' effect;
        # force the output back to the original length
        new_samples = len(new_audio)
        if "pitch" in args:
            if abs(new_samples - old_samples) > 1:
                msg = (
                    "Encountered unexpected length change during 'pitch' effect:\n"
                    f"{' '.join(args)}\n"
                    f"original length: {old_samples}, new length: {new_samples}"
                )
                raise RuntimeError(msg)
            if new_samples < old_samples:
                new_audio = np.pad(array=new_audio, pad_width=(0, old_samples - new_samples))
            elif new_samples > old_samples:
                new_audio = new_audio[:old_samples]

    return new_audio


def sox_stats(audio: AudioT, win_len: float | None = None) -> str:
    """Get statistics for the audio data using SoX.

    Args:
        audio: Input audio data.
        win_len: Window length for stats calculation.

    Returns:
        Statistics output from SoX as a string.

    Raises:
        RuntimeError: If SoX returns an error.

    """
    args = [
        "sox",
        "-D",
        "-V2",
        "-t",
        "f32",
        "-r",
        SAMPLE_RATE,
        "-c",
        1,
        "-",
        "-n",
        "stats",
    ]

    if win_len is not None:
        args.extend(["-w", win_len])

    args = [str(x) for x in args]

    process_handle = subprocess.Popen(  # noqa: S603
        args,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    _, stderr = process_handle.communicate(audio.T.tobytes(order="F"))
    stderr = stderr.decode("utf-8")
    status = process_handle.returncode

    if status != 0:
        raise RuntimeError(stderr)

    return stderr
