"""Input/Output utilities for mixture data."""

from __future__ import annotations

import pickle
from pathlib import Path
from typing import Any

import h5py
import numpy as np


def _get_hdf5_name(location: str | Path, index: str) -> Path:
    """Get the path to an HDF5 file for a given index.

    Args:
        location: Base directory location.
        index: File index.

    Returns:
        Path to the HDF5 file.

    """
    return Path(location) / f"{index}.h5"


def _get_pickle_name(location: str | Path, index: str, item: str) -> Path:
    """Get the path to a pickle file for a given index and item.

    Args:
        location: Base directory location.
        index: Directory index.
        item: Item name.

    Returns:
        Path to the pickle file.

    """
    return Path(location) / index / f"{item}.pkl"


def read_hdf5_data(location: str | Path, index: str, items: list[str] | str) -> dict[str, Any]:
    """Read mixture, target, or noise data from an HDF5 file.

    Args:
        location: Location of the file.
        index: Mixture, target, or noise index.
        items: String(s) of data to retrieve.

    Returns:
        Dictionary mapping item names to their retrieved data.

    Raises:
        OSError: If there is an error reading the HDF5 file.

    """

    def _get_dataset(file: h5py.File, d_name: str) -> Any:  # noqa: ANN401
        if d_name in file:
            data = np.array(file[d_name])
            if data.size == 1:
                item = data.item()
                if isinstance(item, bytes):
                    return item.decode("utf-8")
                return item
            return data
        return None

    if not isinstance(items, list):
        items = [items]

    h5_name = _get_hdf5_name(location, index)
    if h5_name.exists():
        try:
            with h5py.File(h5_name, "r") as f:
                result = {item: _get_dataset(f, item) for item in items}
        except Exception as e:
            msg = f"Error reading {h5_name}: {e}"
            raise OSError(msg) from e
    else:
        result = dict.fromkeys(items)

    return result


def write_hdf5_data(location: str | Path, index: str, items: dict[str, Any]) -> None:
    """Write mixture, target, or noise data to an HDF5 file.

    Args:
        location: Location of the file.
        index: Mixture, target, or noise index.
        items: Dictionary mapping names to data.

    """
    h5_name = _get_hdf5_name(location, index)
    with h5py.File(h5_name, "a") as f:
        for name, data in items.items():
            if name in f:
                del f[name]
            f.create_dataset(name=name, data=data)


def read_pickle_data(location: str | Path, index: str, items: list[str] | str) -> dict[str, Any]:
    """Read mixture, target, or noise data from a pickle file.

    Args:
        location: Location of the file.
        index: Mixture, target, or noise index.
        items: String(s) of data to retrieve.

    Returns:
        Dictionary mapping item names to their retrieved data.

    """
    if not isinstance(items, list):
        items = [items]

    result: dict[str, Any] = {}
    for item in items:
        pkl_name = _get_pickle_name(location, index, item)
        if pkl_name.exists():
            with pkl_name.open("rb") as f:
                result[item] = pickle.load(f)  # noqa: S301
        else:
            result[item] = None

    return result


def write_pickle_data(location: str | Path, index: str, items: dict[str, Any]) -> None:
    """Write mixture, target, or noise data to a pickle file.

    Args:
        location: Location of the file.
        index: Mixture, target, or noise index.
        items: Dictionary mapping names to data.

    """
    directory = Path(location) / index
    directory.mkdir(parents=True, exist_ok=True)
    for name, data in items.items():
        pkl_name = _get_pickle_name(location, index, name)
        with pkl_name.open("wb") as f:
            f.write(pickle.dumps(data))


def clear_pickle_data(location: str | Path, index: str, items: list[str] | str) -> None:
    """Clear mixture, target, or noise data pickle file.

    Args:
        location: Location of the file.
        index: Mixture, target, or noise index.
        items: String(s) of data to retrieve.

    """
    if not isinstance(items, list):
        items = [items]

    for item in items:
        _get_pickle_name(location, index, item).unlink(missing_ok=True)


def read_cached_data(location: str | Path, name: str, index: str, items: list[str] | str) -> dict[str, Any]:
    """Read cached data from a file.

    Args:
        location: Location of the mixture database.
        name: Data name ('mixture', 'target', or 'noise').
        index: Data index (mixture, target, or noise ID).
        items: String(s) of data to retrieve.

    Returns:
        Dictionary mapping item names to their retrieved data.

    """
    return read_pickle_data(Path(location) / name, index, items)


def write_cached_data(location: str | Path, name: str, index: str, items: dict[str, Any]) -> None:
    """Write data to a file.

    Args:
        location: Location of the mixture database.
        name: Data name ('mixture', 'target', or 'noise').
        index: Data index (mixture, target, or noise ID).
        items: Dictionary mapping names to data.

    """
    write_pickle_data(Path(location) / name, index, items)


def clear_cached_data(location: str | Path, name: str, index: str, items: list[str] | str) -> None:
    """Remove cached data file(s).

    Args:
        location: Location of the mixture database.
        name: Data name ('mixture', 'target', or 'noise').
        index: Data index (mixture, target, or noise ID).
        items: String(s) of data to clear.

    """
    clear_pickle_data(Path(location) / name, index, items)
