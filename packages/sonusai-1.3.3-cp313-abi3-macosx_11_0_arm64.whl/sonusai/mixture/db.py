"""SQLite database utilities for SonusAI mixture database."""

from __future__ import annotations

import contextlib
import sqlite3
from pathlib import Path
from sqlite3 import Connection
from sqlite3 import Cursor
from typing import TYPE_CHECKING

from sonusai import logger_db

from .constants import MIXDB_NAME
from .constants import TEST_MIXDB_NAME

if TYPE_CHECKING:
    from types import TracebackType


def db_file(location: str, test: bool = False) -> str:
    """Get the path to the mixture database file.

    Args:
        location: Base directory location.
        test: If True, use the test database name.

    Returns:
        Path to the database file as a string.

    """
    name = TEST_MIXDB_NAME if test else MIXDB_NAME
    return str(Path(location) / name)


class SQLiteDatabase:
    """A context manager for SQLite database connections with configurable behavior."""

    # Constants for database configuration
    READONLY_MODE = "?mode=ro"
    CONNECTION_TIMEOUT = 20

    def __init__(
        self,
        location: str,
        create: bool = False,
        readonly: bool = True,
        test: bool = False,
        verbose: bool = False,
    ) -> None:
        """Initialize SQLite database connection manager.

        Args:
            location: Path to the database file.
            create: If True, create a new database file, overwriting any existing one.
            readonly: If True, open the database in read-only mode.
            test: If True, use the test database path.
            verbose: If True, enable SQL statement logging.

        """
        self.location = location
        self.create = create
        self.readonly = readonly and not create
        self.test = test
        self.verbose = verbose
        self.con: Connection | None = None
        self.cur: Cursor | None = None
        self.db_path = db_file(location, test)

    def __enter__(self) -> Cursor:
        """Enter the context manager, establishing the database connection.

        Returns:
            A database cursor for executing queries.

        Raises:
            sqlite3.Error: If the connection fails.

        """
        try:
            self._establish_connection()
        except Exception:
            self._close_resources()
            raise

        if self.cur:
            self.cur.execute("BEGIN TRANSACTION")
            return self.cur
        msg = "Failed to connect to database"
        raise sqlite3.Error(msg)

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit the context manager, committing changes if appropriate and closing resources.

        Args:
            exc_type: The exception type, if any.
            exc_val: The exception value, if any.
            exc_tb: The exception traceback, if any.

        """
        if self.con:
            if not self.readonly:
                if exc_type is None:
                    # Commit only on successful exit
                    self.con.commit()
                else:
                    # Rollback on exception
                    self.con.rollback()
            self._close_resources()

    def _close_resources(self) -> None:
        """Safely close database cursor and connection resources."""
        if self.cur:
            with contextlib.suppress(sqlite3.Error):
                self.cur.close()
            self.cur = None

        if self.con:
            with contextlib.suppress(sqlite3.Error):
                self.con.close()
            self.con = None

    def _establish_connection(self) -> None:
        """Establish a connection to the SQLite database.

        Raises:
            OSError: If the database file doesn't exist and create=False.
            sqlite3.Error: If connection to the database fails.

        """
        self._prepare_db_file(self.db_path)
        uri = self._build_connection_uri(self.db_path)

        try:
            self.con = sqlite3.connect(
                f"file:{uri}",
                uri=True,
                timeout=self.CONNECTION_TIMEOUT,
                isolation_level=None,
            )

            if self.verbose and self.con:
                self.con.set_trace_callback(logger_db.debug)

            if not self.readonly:
                self.con.execute("PRAGMA journal_mode=wal")
                self.con.execute("PRAGMA synchronous=off")
                self.con.execute("PRAGMA locking_mode=exclusive")
                self.con.execute("PRAGMA cache_size=10000")
                self.con.execute("PRAGMA temp_store=memory")
                self.con.execute("PRAGMA mmap_size=268435456")  # 256MB
            else:
                self.con.execute("PRAGMA synchronous=normal")
                self.con.execute("PRAGMA cache_size=10000")
                self.con.execute("PRAGMA temp_store=memory")
                self.con.execute("PRAGMA mmap_size=268435456")  # 256MB

            self.con.commit()

        except sqlite3.Error as e:
            msg = f"Failed to connect to database: {e}"
            raise sqlite3.Error(msg) from e

        self.cur = self.con.cursor()

    def _prepare_db_file(self, db_path: str) -> None:
        """Prepare the database file based on creation settings.

        Args:
            db_path: Path to the database file.

        Raises:
            OSError: If the database file doesn't exist and create=False.

        """
        path = Path(db_path)
        if self.create and path.exists():
            path.unlink()

        if not self.create and not path.exists():
            msg = f"Could not find mixture database in {self.location}"
            raise OSError(msg)

    def _build_connection_uri(self, db_path: str) -> str:
        """Build the SQLite connection URI with appropriate options.

        Args:
            db_path: Path to the database file.

        Returns:
            A properly formatted SQLite URI with appropriate options.

        """
        uri = db_path

        # Add readonly mode if needed
        if self.readonly:
            uri += self.READONLY_MODE

        return uri
