"""Utilities for generating and processing mixture truth data."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from sonusai.datatypes import Truth
    from sonusai.datatypes import TruthDict
    from sonusai.datatypes import TruthsDict

    from .mixdb import MixtureDatabase


def truth_function(mixdb: MixtureDatabase, m_id: int) -> TruthsDict:
    """Generate all truth data for a given mixture.

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.

    Returns:
        A dictionary mapping source categories to their truth configurations and values.

    Raises:
        AttributeError: If a truth function is unsupported.
        RuntimeError: If an error occurs during truth function execution.

    """
    from . import truth_functions  # noqa: PLC0415 (Circular dependency)

    result: TruthsDict = {}
    for category, source in mixdb.mixture(m_id).all_sources.items():
        truth: TruthDict = {}
        source_file = mixdb.source_file(source.file_id)
        for name, config in source_file.truth_configs.items():
            try:
                truth[name] = getattr(truth_functions, config.function)(mixdb, m_id, category, config.config)
            except AttributeError as e:
                msg = f"Unsupported truth function: {config.function}"
                raise AttributeError(msg) from e
            except Exception as e:
                msg = f"Error in truth function '{config.function}': {e}"
                raise RuntimeError(msg) from e

        if truth:
            result[category] = truth

    return result


def get_class_indices_for_mixid(mixdb: MixtureDatabase, mixid: int) -> list[int]:
    """Get a list of class indices for a given mixture ID.

    Args:
        mixdb: Mixture database.
        mixid: Mixture ID.

    Returns:
        Sorted list of unique class indices.

    """
    indices: list[int] = []
    for source in mixdb.mixture(mixid).all_sources.values():
        indices.extend(mixdb.source_file(source.file_id).class_indices)

    return sorted(set(indices))


def truth_stride_reduction(truth: Truth, function: str) -> Truth:
    """Reduce the stride dimension of truth data.

    Args:
        truth: Truth data with shape [frames, stride, truth_parameters].
        function: Name of the stride reduction function ('none', 'max', 'mean', 'first').

    Returns:
        Stride-reduced truth data with shape [frames, 1, truth_parameters] (or original shape if 'none').

    Raises:
        ValueError: If truth shape is invalid or the reduction function is unknown.

    """
    if truth.ndim != 3:
        msg = "Invalid truth shape"
        raise ValueError(msg)

    if function == "none":
        return truth

    if function == "max":
        return np.max(truth, axis=1, keepdims=True)

    if function == "mean":
        return np.mean(truth, axis=1, keepdims=True)

    if function == "first":
        return truth[:, 0, :].reshape((truth.shape[0], 1, truth.shape[2]))

    msg = f"Invalid truth stride reduction function: {function}"
    raise ValueError(msg)
