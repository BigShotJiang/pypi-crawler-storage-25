"""Constants for the SonusAI mixture database."""

MIXDB_VERSION = 3
MIXDB_NAME = "mixdb.db"
TEST_MIXDB_NAME = "mixdb_test.db"
