"""Database management and mixture generation logic."""

# ruff: noqa: S608
from __future__ import annotations

import json
from collections import OrderedDict
from collections import defaultdict
from copy import deepcopy
from functools import partial
from pathlib import Path
from random import choice
from random import randint
from typing import Any

import numpy as np
import pandas as pd
import yaml
from praatio import textgrid

from sonusai import logger
from sonusai.config.config import load_config
from sonusai.config.ir import get_ir_files
from sonusai.config.source import get_source_files
from sonusai.config.spectral_masks import get_spectral_masks
from sonusai.config.truth import get_truth_parameters
from sonusai.constants import SAMPLE_BYTES
from sonusai.constants import SAMPLE_RATE
from sonusai.datatypes import AudioT
from sonusai.datatypes import Effects
from sonusai.datatypes import GenMixData
from sonusai.datatypes import ImpulseResponseFile
from sonusai.datatypes import Mixture
from sonusai.datatypes import Source
from sonusai.datatypes import SourceFile
from sonusai.datatypes import SourcesAudioT
from sonusai.datatypes import UniversalSNR
from sonusai.datatypes import UniversalSNRGenerator
from sonusai.parse.parse_source_directive import parse_source_directive
from sonusai.utils.asl_p56 import asl_p56
from sonusai.utils.choice import RandomChoice
from sonusai.utils.choice import SequentialChoice
from sonusai.utils.db import db_to_linear
from sonusai.utils.human_readable_size import human_readable_size
from sonusai.utils.max_text_width import max_text_width
from sonusai.utils.parallel import track
from sonusai.utils.seconds_to_hms import seconds_to_hms
from sonusai.utils.tokenized_shell_vars import tokenized_expand

from .constants import MIXDB_VERSION
from .db import SQLiteDatabase
from .effects import apply_mixture_effects
from .effects import conform_audio_to_length
from .effects import effects_from_rules
from .effects import estimate_effected_length
from .effects import get_effect_rules
from .helpers import from_mixture
from .helpers import from_source
from .mixdb import MixtureDatabase


def config_file(location: str) -> str:
    """Get the configuration file path.

    Args:
        location: The configuration directory.

    Returns:
        The configuration file path.

    """
    return str(Path(location) / "config.yml")


# Database schema definition
DATABASE_SCHEMA = [
    """
    CREATE TABLE truth_config(
    id INTEGER PRIMARY KEY NOT NULL,
    config TEXT NOT NULL)
    """,
    """
    CREATE TABLE truth_parameters(
    id INTEGER PRIMARY KEY NOT NULL,
    category TEXT NOT NULL,
    name TEXT NOT NULL,
    parameters INTEGER)
    """,
    """
    CREATE TABLE source_file (
    id INTEGER PRIMARY KEY NOT NULL,
    category TEXT NOT NULL,
    class_indices TEXT,
    level_type TEXT NOT NULL,
    name TEXT NOT NULL,
    samples INTEGER NOT NULL,
    speaker_id INTEGER,
    FOREIGN KEY(speaker_id) REFERENCES speaker (id))
    """,
    """
    CREATE TABLE ir_file (
    id INTEGER PRIMARY KEY NOT NULL,
    delay INTEGER NOT NULL,
    name TEXT NOT NULL)
    """,
    """
    CREATE TABLE ir_tag (
    id INTEGER PRIMARY KEY NOT NULL,
    tag TEXT NOT NULL UNIQUE)
    """,
    """
    CREATE TABLE ir_file_ir_tag (
    file_id INTEGER NOT NULL,
    tag_id INTEGER NOT NULL,
    FOREIGN KEY(file_id) REFERENCES ir_file (id),
    FOREIGN KEY(tag_id) REFERENCES ir_tag (id))
    """,
    """
    CREATE TABLE speaker (
    id INTEGER PRIMARY KEY NOT NULL,
    parent TEXT NOT NULL)
    """,
    """
    CREATE TABLE top (
    id INTEGER PRIMARY KEY NOT NULL,
    asr_configs TEXT NOT NULL,
    class_balancing BOOLEAN NOT NULL,
    feature TEXT NOT NULL,
    mixid_width INTEGER NOT NULL,
    num_classes INTEGER NOT NULL,
    seed INTEGER NOT NULL,
    speaker_metadata_tiers TEXT NOT NULL,
    textgrid_metadata_tiers TEXT NOT NULL,
    version INTEGER NOT NULL)
    """,
    """
    CREATE TABLE class_label (
    id INTEGER PRIMARY KEY NOT NULL,
    label TEXT NOT NULL)
    """,
    """
    CREATE TABLE class_weights_threshold (
    id INTEGER PRIMARY KEY NOT NULL,
    threshold FLOAT NOT NULL)
    """,
    """
    CREATE TABLE spectral_mask (
    id INTEGER PRIMARY KEY NOT NULL,
    f_max_width INTEGER NOT NULL,
    f_num INTEGER NOT NULL,
    t_max_percent INTEGER NOT NULL,
    t_max_width INTEGER NOT NULL,
    t_num INTEGER NOT NULL)
    """,
    """
    CREATE TABLE source_file_truth_config (
    source_file_id INTEGER NOT NULL,
    truth_config_id INTEGER NOT NULL,
    FOREIGN KEY(source_file_id) REFERENCES source_file (id),
    FOREIGN KEY(truth_config_id) REFERENCES truth_config (id))
    """,
    """
    CREATE TABLE source (
    id INTEGER PRIMARY KEY NOT NULL,
    effects TEXT NOT NULL,
    file_id INTEGER NOT NULL,
    pre_tempo FLOAT NOT NULL,
    repeat BOOLEAN NOT NULL,
    snr FLOAT NOT NULL,
    snr_gain FLOAT NOT NULL,
    snr_random BOOLEAN NOT NULL,
    start INTEGER NOT NULL,
    UNIQUE(effects, file_id, pre_tempo, repeat, snr, snr_gain, snr_random, start),
    FOREIGN KEY(file_id) REFERENCES source_file (id))
    """,
    """
    CREATE TABLE mixture (
    id INTEGER PRIMARY KEY NOT NULL,
    name TEXT NOT NULL,
    samples INTEGER NOT NULL,
    spectral_mask_id INTEGER NOT NULL,
    spectral_mask_seed INTEGER NOT NULL,
    FOREIGN KEY(spectral_mask_id) REFERENCES spectral_mask (id))
    """,
    """
    CREATE TABLE mixture_source (
    mixture_id INTEGER NOT NULL,
    source_id INTEGER NOT NULL,
    FOREIGN KEY(mixture_id) REFERENCES mixture (id),
    FOREIGN KEY(source_id) REFERENCES source (id))
    """,
]


class DatabaseManager:
    """Manages database operations for mixture database generation."""

    def __init__(
        self,
        location: str,
        test: bool = False,
        verbose: bool = False,
        logging: bool = False,
        validate_asr: bool = True,
    ) -> None:
        """Initialize the database manager.

        Args:
            location: The database location.
            test: Whether to use test data.
            verbose: Whether to enable verbose output.
            logging: Whether to enable logging.
            validate_asr: Whether to validate ASR configurations.

        """
        self.location = location
        self.test = test
        self.verbose = verbose
        self.logging = logging

        self.config = load_config(self.location, validate_asr=validate_asr)
        self.db = partial(SQLiteDatabase, location=self.location, test=self.test, verbose=self.verbose)

        with self.db(create=True) as c:
            for table_sql in DATABASE_SCHEMA:
                c.execute(table_sql)

        self.mixdb = MixtureDatabase(location=self.location, test=self.test)

    def populate_top_table(self) -> None:
        """Populate the top table."""
        parameters = (
            1,
            json.dumps(self.config["asr_configs"]),
            self.config["class_balancing"],
            self.config["feature"],
            0,
            self.config["num_classes"],
            self.config["seed"],
            "",
            "",
            MIXDB_VERSION,
        )

        with self.db(readonly=False) as c:
            c.execute(
                """
                INSERT INTO top (id, asr_configs, class_balancing, feature, mixid_width, num_classes,
                                 seed, speaker_metadata_tiers, textgrid_metadata_tiers, version)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                parameters,
            )

    def populate_class_label_table(self) -> None:
        """Populate the class_label table."""
        with self.db(readonly=False) as c:
            c.executemany(
                "INSERT INTO class_label (label) VALUES (?)",
                [(item,) for item in self.config["class_labels"]],
            )

    def populate_class_weights_threshold_table(self) -> None:
        """Populate the class_weights_threshold table."""
        class_weights_threshold = self.config["class_weights_threshold"]
        num_classes = self.config["num_classes"]

        if not isinstance(class_weights_threshold, list):
            class_weights_threshold = [class_weights_threshold]

        if len(class_weights_threshold) == 1:
            class_weights_threshold = [class_weights_threshold[0]] * num_classes

        if len(class_weights_threshold) != num_classes:
            msg = f"invalid class_weights_threshold length: {len(class_weights_threshold)}"
            raise ValueError(msg)

        with self.db(readonly=False) as c:
            c.executemany(
                "INSERT INTO class_weights_threshold (threshold) VALUES (?)",
                [(item,) for item in class_weights_threshold],
            )

    def populate_spectral_mask_table(self) -> None:
        """Populate the spectral_mask table."""
        with self.db(readonly=False) as c:
            c.executemany(
                """
            INSERT INTO spectral_mask (f_max_width, f_num, t_max_percent, t_max_width, t_num) VALUES (?, ?, ?, ?, ?)
            """,
                [
                    (
                        item.f_max_width,
                        item.f_num,
                        item.t_max_percent,
                        item.t_max_width,
                        item.t_num,
                    )
                    for item in get_spectral_masks(self.config)
                ],
            )

    def populate_truth_parameters_table(self) -> None:
        """Populate the truth_parameters table."""
        with self.db(readonly=False) as c:
            c.executemany(
                """
            INSERT INTO truth_parameters (category, name, parameters) VALUES (?, ?, ?)
            """,
                [
                    (
                        item.category,
                        item.name,
                        item.parameters,
                    )
                    for item in get_truth_parameters(self.config)
                ],
            )

    def populate_source_file_table(self, show_progress: bool = False, no_par: bool = False) -> None:
        """Populate the source file table."""
        if self.logging:
            logger.info("Collecting sources")

        files = get_source_files(self.config, show_progress, no_par)
        if self.logging:
            logger.info("")

        if len([file for file in files if file.category == "primary"]) == 0:
            msg = "Canceled due to no primary sources"
            raise RuntimeError(msg)

        if self.logging:
            logger.info("Populating source file table")

        self._populate_truth_config_table(files)
        self._populate_speaker_table(files)

        with self.db(readonly=False) as c:
            textgrid_metadata_tiers = self._insert_source_files(c, files)

            # Update textgrid_metadata_tiers in the top table
            c.execute(
                "UPDATE top SET textgrid_metadata_tiers=? WHERE ? = id",
                (json.dumps(sorted(textgrid_metadata_tiers)), 1),
            )

        if self.logging:
            self._log_sources_summary()

    def _insert_source_files(self, c: SQLiteDatabase, files: list[SourceFile]) -> set[str]:
        textgrid_metadata_tiers: set[str] = set()
        for file in files:
            textgrid_metadata_tiers.update(_get_textgrid_tiers_from_source_file(file.name))
            truth_config_ids = self._truth_config_ids(c, file)
            speaker_id = self._speaker_id(c, file)
            source_file_id = self._insert_source_file(c, file, speaker_id)
            self._insert_source_file_truth_configs(c, source_file_id, truth_config_ids)
        return textgrid_metadata_tiers

    def _truth_config_ids(self, c: SQLiteDatabase, file: SourceFile) -> list[int]:
        truth_config_ids: list[int] = []
        if not file.truth_configs:
            return truth_config_ids
        for name, config in file.truth_configs.items():
            ts = json.dumps({"name": name} | config.to_dict())
            c.execute(
                "SELECT truth_config.id FROM truth_config WHERE ? = truth_config.config",
                (ts,),
            )
            truth_config_ids.append(c.fetchone()[0])
        return truth_config_ids

    def _speaker_id(self, c: SQLiteDatabase, file: SourceFile) -> int | None:
        c.execute("SELECT speaker.id FROM speaker WHERE ? = speaker.parent", (Path(file.name).parent.as_posix(),))
        result = c.fetchone()
        return None if result is None else result[0]

    def _insert_source_file(self, c: SQLiteDatabase, file: SourceFile, speaker_id: int | None) -> int:
        c.execute(
            """
            INSERT INTO source_file (category, class_indices, level_type, name, samples, speaker_id)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                file.category,
                json.dumps(file.class_indices),
                file.level_type,
                file.name,
                file.samples,
                speaker_id,
            ),
        )
        return c.lastrowid

    def _insert_source_file_truth_configs(
        self,
        c: SQLiteDatabase,
        source_file_id: int,
        truth_config_ids: list[int],
    ) -> None:
        for truth_config_id in truth_config_ids:
            c.execute(
                "INSERT INTO source_file_truth_config (source_file_id, truth_config_id) VALUES (?, ?)",
                (source_file_id, truth_config_id),
            )

    def _log_sources_summary(self) -> None:
        logger.info("Sources summary")
        data = {
            "category": [],
            "files": [],
            "size": [],
            "duration": [],
        }
        for category, files in self.mixdb.source_files.items():
            audio_samples = sum([source.samples for source in files])
            audio_duration = audio_samples / SAMPLE_RATE
            data["category"].append(category)
            data["files"].append(self.mixdb.num_source_files(category))
            data["size"].append(human_readable_size(audio_samples * SAMPLE_BYTES, 1))
            data["duration"].append(seconds_to_hms(seconds=audio_duration))

        df = pd.DataFrame(data)
        logger.info(df.to_string(index=False, header=False))
        logger.info("")

        for category, files in self.mixdb.source_files.items():
            logger.debug(f"List of {category} sources:")
            logger.debug(yaml.dump([file.name for file in files], default_flow_style=False))

    def populate_impulse_response_file_table(self, show_progress: bool = False, no_par: bool = False) -> None:
        """Populate the impulse response file table."""
        if self.logging:
            logger.info("Collecting impulse responses")

        files = get_ir_files(self.config, show_progress=show_progress, no_par=no_par)

        if self.logging:
            logger.info("")
            logger.info("Populating impulse response file table")

        self._populate_impulse_response_tag_table(files)

        with self.db(readonly=False) as c:
            for file in files:
                # Get the tags for the file
                tag_ids: list[int] = []
                for tag in file.tags:
                    c.execute("SELECT id FROM ir_tag WHERE ? = tag", (tag,))
                    tag_ids.append(c.fetchone()[0])

                c.execute("INSERT INTO ir_file (delay, name) VALUES (?, ?)", (file.delay, file.name))

                file_id = c.lastrowid
                for tag_id in tag_ids:
                    c.execute("INSERT INTO ir_file_ir_tag (file_id, tag_id) VALUES (?, ?)", (file_id, tag_id))

        if self.logging:
            logger.debug("List of impulse responses:")
            for idx, file in enumerate(files):
                logger.debug(f"id: {idx}, name:{file.name}, delay: {file.delay}, tags: [{', '.join(file.tags)}]")
            logger.debug("")

    def populate_mixture_table(self, mixtures: list[Mixture], show_progress: bool = False) -> None:
        """Populate the mixture table."""
        if self.logging:
            logger.info("Populating mixture and source tables")

        with self.db(readonly=False) as c:
            source_cache: dict[tuple, int] = {}
            mixture_source_rows: list[tuple[int, int]] = []

            # Populate the source table
            for mixture in track(mixtures, disable=not show_progress):
                m_id = int(mixture.name) + 1
                c.execute(
                    """
                    INSERT INTO mixture (id, name, samples, spectral_mask_id, spectral_mask_seed)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (m_id, *from_mixture(mixture)),
                )

                for source in mixture.all_sources.values():
                    source_key = from_source(source)
                    if source_key in source_cache:
                        source_id = source_cache[source_key]
                    else:
                        c.execute(
                            """
                            INSERT OR IGNORE INTO source (effects, file_id, pre_tempo, repeat, snr, snr_gain, snr_random, start)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            source_key,
                        )

                        source_id = c.execute(
                            """
                            SELECT id
                            FROM source
                            WHERE effects = ?
                            AND file_id = ?
                            AND pre_tempo = ?
                            AND repeat = ?
                            AND snr = ?
                            AND snr_gain = ?
                            AND snr_random = ?
                            AND start = ?
                            """,
                            source_key,
                        ).fetchone()[0]
                        source_cache[source_key] = source_id

                    mixture_source_rows.append((m_id, source_id))

            if mixture_source_rows:
                c.executemany("INSERT INTO mixture_source (mixture_id, source_id) VALUES (?, ?)", mixture_source_rows)

            if self.logging:
                logger.info("Closing mixture and source tables")

    def _populate_speaker_table(self, source_files: list[SourceFile]) -> None:
        """Populate the speaker table."""
        # Determine the columns for speaker the table
        all_parents = {Path(file.name).parent for file in source_files}
        speaker_parents = (
            parent for parent in all_parents if Path(tokenized_expand(parent / "speaker.yml")[0]).exists()
        )

        speakers: dict[Path, dict[str, str]] = {}
        for parent in sorted(speaker_parents):
            with Path(tokenized_expand(parent / "speaker.yml")[0]).open() as f:
                speakers[parent] = yaml.safe_load(f)

        new_columns: list[str] = [column for s in speakers.values() for column in s]
        new_columns = sorted(set(new_columns))

        with self.db(readonly=False) as c:
            for new_column in new_columns:
                c.execute(f"ALTER TABLE speaker ADD COLUMN {new_column} TEXT")

            # Populate the speaker table
            speaker_rows: list[tuple[str, ...]] = []
            for key in speakers:
                entry = (speakers[key].get(column, None) for column in new_columns)
                speaker_rows.append((key.as_posix(), *entry))  # type: ignore[arg-type]

            column_ids = ", ".join(["parent", *new_columns])
            column_values = ", ".join(["?"] * (len(new_columns) + 1))
            c.executemany(f"INSERT INTO speaker ({column_ids}) VALUES ({column_values})", speaker_rows)

            c.execute("CREATE INDEX speaker_parent_idx ON speaker (parent)")

            # Update speaker_metadata_tiers in the top table
            tiers = [
                description[0]
                for description in c.execute("SELECT * FROM speaker").description
                if description[0] not in ("id", "parent")
            ]
            c.execute("UPDATE top SET speaker_metadata_tiers=? WHERE ? = id", (json.dumps(tiers), 1))

            if "speaker_id" in tiers:
                c.execute("CREATE INDEX speaker_speaker_id_idx ON source_file (speaker_id)")

    def _populate_truth_config_table(self, source_files: list[SourceFile]) -> None:
        """Populate the truth_config table."""
        with self.db(readonly=False) as c:
            # Populate truth_config table
            truth_configs: list[str] = []
            for file in source_files:
                for name, config in file.truth_configs.items():
                    ts = json.dumps({"name": name} | config.to_dict())
                    if ts not in truth_configs:
                        truth_configs.append(ts)
            c.executemany(
                "INSERT INTO truth_config (config) VALUES (?)",
                [(item,) for item in truth_configs],
            )

    def _populate_impulse_response_tag_table(self, files: list[ImpulseResponseFile]) -> None:
        """Populate the ir_tag table."""
        with self.db(readonly=False) as c:
            c.executemany(
                "INSERT INTO ir_tag (tag) VALUES (?)",
                [(tag,) for tag in {tag for file in files for tag in file.tags}],
            )

    def generate_mixtures(self) -> list[Mixture]:
        """Generate mixtures."""
        if self.logging:
            logger.info("Collecting effects")

        rules = get_effect_rules(self.location, self.config, self.test)

        if self.logging:
            self._log_rules(rules)
            self._log_mixture_inputs()

        if self.logging:
            logger.info("Generating mixtures")

        effected_sources = self._build_effected_sources(rules)

        # First, create mixtures of primary and noise
        mixtures = self._build_noise_mixtures(effected_sources)

        # Next, cycle through any additional sources and apply mix rules for each
        mixtures = self._add_additional_sources(mixtures, effected_sources)

        # Update the mixid width
        with self.db(readonly=False) as c:
            c.execute("UPDATE top SET mixid_width=? WHERE ? = id", (max_text_width(len(mixtures)), 1))

        return mixtures

    def _log_rules(self, rules: dict[str, list[Effects]]) -> None:
        logger.info("")
        for category, effect in rules.items():
            logger.debug(f"List of {category} rules:")
            logger.debug(yaml.dump([entry.to_dict() for entry in effect], default_flow_style=False))

    def _log_mixture_inputs(self) -> None:
        logger.debug("SNRS:")
        for category, source in self.config["sources"].items():
            if category != "primary":
                logger.debug(f"  {category}")
                for snr in source["snrs"]:
                    logger.debug(f"  - {snr}")
        logger.debug("")
        logger.debug("Mix Rules:")
        for category, source in self.config["sources"].items():
            if category != "primary":
                logger.debug(f"  {category}")
                for mix_rule in source["mix_rules"]:
                    logger.debug(f"  - {mix_rule}")
        logger.debug("")
        logger.debug("Spectral masks:")
        for spectral_mask in self.mixdb.spectral_masks:
            logger.debug(f"- {spectral_mask}")
        logger.debug("")

    def _build_effected_sources(self, rules: dict[str, list[Effects]]) -> dict[str, list[tuple[SourceFile, Effects]]]:
        effected_sources: dict[str, list[tuple[SourceFile, Effects]]] = {}
        for category in self.mixdb.source_files:
            effected_sources[category] = []
            for file in self.mixdb.source_files[category]:
                for rule in rules[category]:
                    effected_sources[category].append((file, rule))
        return effected_sources

    def _build_noise_mixtures(self, effected_sources: dict[str, list[tuple[SourceFile, Effects]]]) -> list[Mixture]:
        mixtures: list[Mixture] = []
        for mix_rule in self.config["sources"]["noise"]["mix_rules"]:
            mixtures.extend(
                self._process_noise_sources(
                    primary_effected_sources=effected_sources["primary"],
                    noise_effected_sources=effected_sources["noise"],
                    mix_rule=mix_rule,
                )
            )
        return mixtures

    def _add_additional_sources(
        self,
        mixtures: list[Mixture],
        effected_sources: dict[str, list[tuple[SourceFile, Effects]]],
    ) -> list[Mixture]:
        additional_sources = [cat for cat in self.mixdb.source_files if cat not in ("primary", "noise")]
        for category in additional_sources:
            new_mixtures: list[Mixture] = []
            for mix_rule in self.config["sources"][category]["mix_rules"]:
                new_mixtures.extend(
                    self._process_additional_sources(
                        effected_sources=effected_sources[category],
                        mixtures=mixtures,
                        category=category,
                        mix_rule=mix_rule,
                    )
                )
            mixtures = new_mixtures
        return mixtures

    def _process_noise_sources(
        self,
        primary_effected_sources: list[tuple[SourceFile, Effects]],
        noise_effected_sources: list[tuple[SourceFile, Effects]],
        mix_rule: str,
    ) -> list[Mixture]:
        match mix_rule:
            case "exhaustive":
                return self._noise_exhaustive(primary_effected_sources, noise_effected_sources)
            case "non-exhaustive":
                return self._noise_non_exhaustive(primary_effected_sources, noise_effected_sources)
            case "non-combinatorial":
                return self._noise_non_combinatorial(primary_effected_sources, noise_effected_sources)
            case _:
                msg = f"invalid noise mix_rule: {mix_rule}"
                raise ValueError(msg)

    def _noise_exhaustive(
        self,
        primary_effected_sources: list[tuple[SourceFile, Effects]],
        noise_effected_sources: list[tuple[SourceFile, Effects]],
    ) -> list[Mixture]:
        """Use every noise/effect with every source/effect+interferences/effect."""
        snrs = self.all_snrs()

        mixtures: list[Mixture] = []
        for noise_file, noise_rule in noise_effected_sources:
            noise_start = 0
            noise_effect = effects_from_rules(self.mixdb, noise_rule)
            noise_length = estimate_effected_length(noise_file.samples, noise_effect)

            for primary_file, primary_rule in primary_effected_sources:
                primary_effect = effects_from_rules(self.mixdb, primary_rule)
                primary_length = estimate_effected_length(
                    primary_file.samples, primary_effect, self.mixdb.feature_step_samples
                )

                for spectral_mask_id in range(len(self.config["spectral_masks"])):
                    for snr in snrs["noise"]:
                        mixtures.append(
                            Mixture(
                                name="",
                                all_sources={
                                    "primary": Source(
                                        file_id=primary_file.id,
                                        effects=primary_effect,
                                    ),
                                    "noise": Source(
                                        file_id=noise_file.id,
                                        effects=noise_effect,
                                        start=noise_start,
                                        loop=True,
                                        snr=UniversalSNR(value=snr.value, is_random=snr.is_random),
                                    ),
                                },
                                samples=primary_length,
                                spectral_mask_id=spectral_mask_id + 1,
                                spectral_mask_seed=randint(0, np.iinfo("i").max),  # noqa: S311
                            )
                        )
                        noise_start = int((noise_start + primary_length) % noise_length)

        return mixtures

    def _noise_non_exhaustive(
        self,
        primary_effected_sources: list[tuple[SourceFile, Effects]],
        noise_effected_sources: list[tuple[SourceFile, Effects]],
    ) -> list[Mixture]:
        """Cycle through source/effect combinations without using all noise/effect combinations.

        This reduced data set approach ensures each primary source is used.

        Args:
            primary_effected_sources: List of primary source/effect tuples.
            noise_effected_sources: List of noise source/effect tuples.

        Returns:
            A list of generated mixtures.

        """
        snrs = self.all_snrs()

        next_noise = NextNoise(self.mixdb, noise_effected_sources)

        mixtures: list[Mixture] = []
        for primary_file, primary_rule in primary_effected_sources:
            primary_effect = effects_from_rules(self.mixdb, primary_rule)
            primary_length = estimate_effected_length(
                primary_file.samples, primary_effect, self.mixdb.feature_step_samples
            )

            for spectral_mask_id in range(len(self.config["spectral_masks"])):
                for snr in snrs["noise"]:
                    noise_file_id, noise_effect, noise_start = next_noise.generate(primary_file.samples)

                    mixtures.append(
                        Mixture(
                            name="",
                            all_sources={
                                "primary": Source(
                                    file_id=primary_file.id,
                                    effects=primary_effect,
                                ),
                                "noise": Source(
                                    file_id=noise_file_id,
                                    effects=noise_effect,
                                    start=noise_start,
                                    loop=True,
                                    snr=UniversalSNR(value=snr.value, is_random=snr.is_random),
                                ),
                            },
                            samples=primary_length,
                            spectral_mask_id=spectral_mask_id + 1,
                            spectral_mask_seed=randint(0, np.iinfo("i").max),  # noqa: S311
                        )
                    )

        return mixtures

    def _noise_non_combinatorial(
        self,
        primary_effected_sources: list[tuple[SourceFile, Effects]],
        noise_effected_sources: list[tuple[SourceFile, Effects]],
    ) -> list[Mixture]:
        """Combine source/effect with noise/effect non-exhaustively.

        Each source/effect+interferences/effect does not use each noise/effect.
        Cut has a random start and loop back to the beginning if the end of noise/effect is reached.

        Args:
            primary_effected_sources: List of primary source/effect tuples.
            noise_effected_sources: List of noise source/effect tuples.

        Returns:
            A list of generated mixtures.

        """
        snrs = self.all_snrs()

        noise_id = 0
        mixtures: list[Mixture] = []
        for primary_file, primary_rule in primary_effected_sources:
            primary_effect = effects_from_rules(self.mixdb, primary_rule)
            primary_length = estimate_effected_length(
                primary_file.samples, primary_effect, self.mixdb.feature_step_samples
            )

            for spectral_mask_id in range(len(self.config["spectral_masks"])):
                for snr in snrs["noise"]:
                    noise_file, noise_rule = noise_effected_sources[noise_id]
                    noise_effect = effects_from_rules(self.mixdb, noise_rule)
                    noise_length = estimate_effected_length(noise_file.samples, noise_effect)

                    mixtures.append(
                        Mixture(
                            name="",
                            all_sources={
                                "primary": Source(
                                    file_id=primary_file.id,
                                    effects=primary_effect,
                                ),
                                "noise": Source(
                                    file_id=noise_file.id,
                                    effects=noise_effect,
                                    start=choice(range(noise_length)),  # noqa: S311
                                    loop=True,
                                    snr=UniversalSNR(value=snr.value, is_random=snr.is_random),
                                ),
                            },
                            samples=primary_length,
                            spectral_mask_id=spectral_mask_id + 1,
                            spectral_mask_seed=randint(0, np.iinfo("i").max),  # noqa: S311
                        )
                    )
                    noise_id = (noise_id + 1) % len(noise_effected_sources)

        return mixtures

    def _process_additional_sources(
        self,
        effected_sources: list[tuple[SourceFile, Effects]],
        mixtures: list[Mixture],
        category: str,
        mix_rule: str,
    ) -> list[Mixture]:
        if mix_rule == "none":
            return mixtures
        if mix_rule.startswith("choose"):
            return self._additional_choose(
                effected_sources=effected_sources,
                mixtures=mixtures,
                category=category,
                mix_rule=mix_rule,
            )
        if mix_rule.startswith("sequence"):
            return self._additional_sequence(
                effected_sources=effected_sources,
                mixtures=mixtures,
                category=category,
                mix_rule=mix_rule,
            )
        msg = f"invalid {category} mix_rule: {mix_rule}"
        raise ValueError(msg)

    def _additional_choose(
        self,
        effected_sources: list[tuple[SourceFile, Effects]],
        mixtures: list[Mixture],
        category: str,
        mix_rule: str,
    ) -> list[Mixture]:
        # Parse the mix rule
        try:
            params = parse_source_directive(mix_rule)
        except ValueError as e:
            msg = f"Error parsing choose directive: {e}"
            raise ValueError(msg) from e

        snrs = self.all_snrs()[category]

        choice_objs: dict[tuple[int, ...], RandomChoice] = {}
        if params.unique == "speaker_id":
            # Get a set of speaker_id values in use in the existing mixtures.
            all_speaker_ids = {self.get_mixture_speaker_ids(mixture) for mixture in mixtures}

            # Create a set of RandomChoice objects that are filtered on those values.
            for speaker_ids in all_speaker_ids:
                filtered_sources = _filter_sources(effected_sources, speaker_ids)
                if not filtered_sources:
                    msg = (
                        f"Additional source, {category}, has no valid entries for speaker_ids unique from {speaker_ids}"
                    )
                    raise ValueError(msg)
                choice_objs[speaker_ids] = RandomChoice(data=filtered_sources, repetition=params.repeat)
        elif params.unique is None:
            choice_objs = {(0,): RandomChoice(data=effected_sources, repetition=params.repeat)}
        else:
            msg = f"Invalid unique value: {params.unique}"
            raise ValueError(msg)

        # Loop over mixtures and add additional sources
        new_mixtures: list[Mixture] = []
        for mixture in mixtures:
            for snr in snrs:
                new_mixture = deepcopy(mixture)
                if params.unique == "speaker_id":
                    speaker_ids = self.get_mixture_speaker_ids(mixture)
                elif params.unique is None:
                    speaker_ids = (0,)
                else:
                    msg = f"Invalid unique value: {params.unique}"
                    raise ValueError(msg)
                source, effect = choice_objs[speaker_ids].next()
                new_source = Source(
                    file_id=source.id,
                    effects=effect,
                    start=params.start,
                    loop=params.loop,
                    snr=UniversalSNR(value=snr.value, is_random=snr.is_random),
                )
                new_mixture.all_sources[category] = new_source
                new_mixtures.append(new_mixture)

        return new_mixtures

    def _additional_sequence(
        self,
        effected_sources: list[tuple[SourceFile, Effects]],
        mixtures: list[Mixture],
        category: str,
        mix_rule: str,
    ) -> list[Mixture]:
        # Parse the mix rule
        try:
            params = parse_source_directive(mix_rule)
        except ValueError as e:
            msg = f"Error parsing choose directive: {e}"
            raise ValueError(msg) from e

        snrs = self.all_snrs()[category]

        sequence_objs: dict[tuple[int, ...], SequentialChoice] = {}
        if params.unique == "speaker_id":
            # Get a set of speaker_id values in use in the existing mixtures.
            all_speaker_ids = {self.get_mixture_speaker_ids(mixture) for mixture in mixtures}

            # Create a set of SequentialChoice objects that are filtered on those values.
            for speaker_ids in all_speaker_ids:
                filtered_sources = _filter_sources(effected_sources, speaker_ids)
                if not filtered_sources:
                    msg = (
                        f"Additional source, {category}, has no valid entries for speaker_ids unique from {speaker_ids}"
                    )
                    raise ValueError(msg)
                sequence_objs[speaker_ids] = SequentialChoice(data=filtered_sources)
        elif params.unique is None:
            sequence_objs = {(0,): SequentialChoice(data=effected_sources)}
        else:
            msg = f"Invalid unique value: {params.unique}"
            raise ValueError(msg)

        # Loop over mixtures and add additional sources
        new_mixtures: list[Mixture] = []
        for mixture in mixtures:
            for snr in snrs:
                new_mixture = deepcopy(mixture)
                if params.unique == "speaker_id":
                    speaker_ids = self.get_mixture_speaker_ids(mixture)
                elif params.unique is None:
                    speaker_ids = (0,)
                else:
                    msg = f"Invalid unique value: {params.unique}"
                    raise ValueError(msg)
                source, effect = sequence_objs[speaker_ids].next()
                new_source = Source(
                    file_id=source.id,
                    effects=effect,
                    start=params.start,
                    loop=params.loop,
                    snr=UniversalSNR(value=snr.value, is_random=snr.is_random),
                )
                new_mixture.all_sources[category] = new_source
                new_mixtures.append(new_mixture)

        return new_mixtures

    def get_mixture_speaker_ids(self, mixture: Mixture) -> tuple[int, ...]:
        """Get the speaker IDs used in a mixture, excluding None values."""
        valid_speaker_ids = [
            speaker_id
            for source in mixture.all_sources.values()
            if (speaker_id := self.mixdb.source_file(source.file_id).speaker_id) is not None
        ]
        return tuple(valid_speaker_ids)

    def all_snrs(self) -> dict[str, list[UniversalSNRGenerator]]:
        """Get all SNR generators for all source categories.

        Returns:
            A dictionary mapping category names to lists of SNR generators.

        """
        snrs: dict[str, list[UniversalSNRGenerator]] = {}
        for category in self.config["sources"]:
            if category != "primary":
                snrs[category] = [UniversalSNRGenerator(snr) for snr in self.config["sources"][category]["snrs"]]
        return snrs


def update_mixture(mixdb: MixtureDatabase, mixture: Mixture, with_data: bool = False) -> tuple[Mixture, GenMixData]:
    """Update mixture record with name, samples, and gains."""
    sources_audio: SourcesAudioT = {}
    post_audio: SourcesAudioT = {}
    for category in mixture.all_sources:
        mixture, sources_audio[category], post_audio[category] = _update_source(mixdb, mixture, category)

    mixture = _initialize_mixture_gains(mixdb, mixture, post_audio)

    if not with_data:
        return mixture, GenMixData()

    # Apply gains
    post_audio = {
        category: post_audio[category] * mixture.all_sources[category].snr_gain for category in mixture.all_sources
    }

    # Sum sources, noise, and mixture
    source_audio = np.sum([post_audio[category] for category in mixture.sources], axis=0)
    noise_audio = post_audio["noise"]
    mixture_audio = source_audio + noise_audio

    return mixture, GenMixData(
        sources=sources_audio,
        source=source_audio,
        noise=noise_audio,
        mixture=mixture_audio,
    )


def _update_source(mixdb: MixtureDatabase, mixture: Mixture, category: str) -> tuple[Mixture, AudioT, AudioT]:
    source = mixture.all_sources[category]

    # Track and use pre-effects cache
    pre_effects_key = (mixdb.location, source.file_id, tuple(source.effects.pre))
    cached_val = _PRE_EFFECTS_CACHE.get(pre_effects_key)

    if cached_val is None:
        org_audio = mixdb.read_source_audio(source.file_id)
        org_samples = len(org_audio)
        pre_audio = apply_mixture_effects(mixdb, org_audio, source.effects, pre=True, post=False)
        _PRE_EFFECTS_CACHE.put(pre_effects_key, (org_samples, pre_audio.copy()))
    else:
        org_samples, pre_audio = cached_val
        pre_audio = pre_audio.copy()

    _REUSE_TRACKER.track("pre_effects", pre_effects_key, len(pre_audio))

    mixture.all_sources[category].pre_tempo = org_samples / len(pre_audio)

    # Track potential conformed reuse
    conformed_key = (
        mixdb.location,
        source.file_id,
        tuple(source.effects.pre),
        mixture.samples,
        source.loop,
        source.start,
    )

    pre_audio = conform_audio_to_length(pre_audio, mixture.samples, source.loop, source.start)

    _REUSE_TRACKER.track("conformed", conformed_key, len(pre_audio))

    # Track potential post-effects reuse
    post_effects_key = (
        mixdb.location,
        source.file_id,
        tuple(source.effects.pre),
        tuple(source.effects.post),
        mixture.samples,
        source.loop,
        source.start,
    )

    post_audio = apply_mixture_effects(mixdb, pre_audio, source.effects, pre=False, post=True)

    _REUSE_TRACKER.track("post_effects", post_effects_key, len(post_audio))
    if len(pre_audio) != len(post_audio):
        msg = f"post-truth effects changed length: {source.effects.post}"
        raise RuntimeError(msg)

    return mixture, pre_audio, post_audio


def _initialize_mixture_gains(mixdb: MixtureDatabase, mixture: Mixture, sources_audio: SourcesAudioT) -> Mixture:
    sources_energy = _source_energies(mixdb, mixture, sources_audio, asl_p56)
    _initialize_gains(mixture)
    _resolve_non_primary_gains(mixture, sources_energy, db_to_linear)
    _normalize_gains(mixture)
    _apply_clip_protection(mixture, sources_audio, db_to_linear)
    _round_gains(mixture)

    return mixture


def _source_energies(
    mixdb: MixtureDatabase,
    mixture: Mixture,
    sources_audio: SourcesAudioT,
    asl_p56: partial,
) -> dict[str, float]:
    sources_energy: dict[str, float] = {}
    for category in mixture.all_sources:
        level_type = mixdb.source_file(mixture.all_sources[category].file_id).level_type
        if level_type == "default":
            sources_energy[category] = float(np.mean(np.square(sources_audio[category])))
        elif level_type == "speech":
            sources_energy[category] = asl_p56(sources_audio[category])
        else:
            msg = f"Unknown level_type: {level_type}"
            raise ValueError(msg)
    return sources_energy


def _initialize_gains(mixture: Mixture) -> None:
    for category in mixture.all_sources:
        mixture.all_sources[category].snr_gain = 1


def _resolve_non_primary_gains(
    mixture: Mixture,
    sources_energy: dict[str, float],
    db_to_linear: partial,
) -> None:
    for category in mixture.all_sources:
        if mixture.is_noise_only and category != "noise":
            mixture.all_sources[category].snr_gain = 0
            continue
        if mixture.is_source_only and category == "noise":
            mixture.all_sources[category].snr_gain = 0
            continue
        if category == "primary":
            continue
        if sources_energy["primary"] == 0 or sources_energy[category] == 0:
            mixture.all_sources[category].snr_gain = 1
            continue
        mixture.all_sources[category].snr_gain = float(
            np.sqrt(sources_energy["primary"] / sources_energy[category])
        ) / db_to_linear(mixture.all_sources[category].snr)


def _normalize_gains(mixture: Mixture) -> None:
    max_snr_gain = max([source.snr_gain for source in mixture.all_sources.values()])
    for category in mixture.all_sources:
        mixture.all_sources[category].snr_gain = mixture.all_sources[category].snr_gain / max_snr_gain


def _apply_clip_protection(mixture: Mixture, sources_audio: SourcesAudioT, db_to_linear: partial) -> None:
    mixture_audio = np.sum(
        [sources_audio[category] * mixture.all_sources[category].snr_gain for category in mixture.all_sources], axis=0
    )
    max_abs_audio = float(np.max(np.abs(mixture_audio)))
    clip_level = db_to_linear(-0.25)
    if max_abs_audio <= clip_level:
        return
    gain_adjustment = clip_level / max_abs_audio
    for category in mixture.all_sources:
        mixture.all_sources[category].snr_gain *= gain_adjustment


def _round_gains(mixture: Mixture) -> None:
    for category in mixture.all_sources:
        mixture.all_sources[category].snr_gain = round(mixture.all_sources[category].snr_gain, ndigits=5)


class NextNoise:
    """Helper class to manage noise cycling during mixture generation."""

    def __init__(self, mixdb: MixtureDatabase, effected_noises: list[tuple[SourceFile, Effects]]) -> None:
        """Initialize the noise cycler.

        Args:
            mixdb: The mixture database.
            effected_noises: List of noise source/effect tuples.

        """
        self.mixdb = mixdb
        self.effected_noises = effected_noises

        self.noise_start = 0
        self.noise_id = 0
        self.noise_effect = effects_from_rules(self.mixdb, self.noise_rule)
        self.noise_length = estimate_effected_length(self.noise_file.samples, self.noise_effect)

    @property
    def noise_file(self) -> SourceFile:
        """Get the current noise source file.

        Returns:
            The current source file.

        """
        return self.effected_noises[self.noise_id][0]

    @property
    def noise_rule(self) -> Effects:
        """Get the current noise effect rule.

        Returns:
            The current effect rule.

        """
        return self.effected_noises[self.noise_id][1]

    def generate(self, length: int) -> tuple[int, Effects, int]:
        """Generate a noise slice.

        Args:
            length: The required length in samples.

        Returns:
            A tuple of (noise file id, noise effect rule, noise start sample).

        """
        if self.noise_start + length > self.noise_length:
            # Not enough samples in current noise
            if self.noise_start == 0:
                msg = "Length of primary audio exceeds length of noise audio"
                raise ValueError(msg)

            self.noise_start = 0
            self.noise_id = (self.noise_id + 1) % len(self.effected_noises)
            self.noise_effect = effects_from_rules(self.mixdb, self.noise_rule)
            self.noise_length = estimate_effected_length(self.noise_file.samples, self.noise_effect)
            noise_start = self.noise_start
        else:
            # Current noise has enough samples
            noise_start = self.noise_start
            self.noise_start += length

        return self.noise_file.id, self.noise_effect, noise_start


def _get_textgrid_tiers_from_source_file(file: str) -> list[str]:
    textgrid_file = Path(tokenized_expand(file)[0]).with_suffix(".TextGrid")
    if not textgrid_file.exists():
        return []

    tg = textgrid.openTextgrid(str(textgrid_file), includeEmptyIntervals=False)

    return sorted(tg.tierNames)


def _filter_sources(
    effected_sources: list[tuple[SourceFile, Effects]],
    speaker_id: tuple[int, ...],
) -> list[tuple[SourceFile, Effects]]:
    return [
        (source_file, effects) for source_file, effects in effected_sources if source_file.speaker_id not in speaker_id
    ]


class ReuseTracker:
    """Tracks potential source-plan reuse for reporting."""

    def __init__(self) -> None:
        """Initialize the reuse tracker."""
        self.counts: dict[str, dict[tuple, int]] = {
            "pre_effects": defaultdict(int),
            "conformed": defaultdict(int),
            "post_effects": defaultdict(int),
        }
        self.byte_estimates: dict[str, dict[tuple, int]] = {
            "pre_effects": defaultdict(int),
            "conformed": defaultdict(int),
            "post_effects": defaultdict(int),
        }

    def track(self, stage: str, key: tuple, num_samples: int) -> None:
        """Record a call to a potentially reusable stage.

        Args:
            stage: The name of the stage.
            key: The unique key for the operation.
            num_samples: Number of samples in the resulting audio.

        """
        self.counts[stage][key] += 1
        self.byte_estimates[stage][key] = num_samples * SAMPLE_BYTES

    def get_metrics(self) -> dict[str, dict[str, Any]]:
        """Calculate hits, misses, hit-rate, and estimated unique bytes.

        Returns:
            A dictionary containing metrics for each stage.

        """
        metrics = {}
        for stage, counts in self.counts.items():
            total_calls = sum(counts.values())
            unique_keys = len(counts)
            hits = total_calls - unique_keys
            hit_rate = hits / total_calls if total_calls > 0 else 0
            total_bytes = sum(self.byte_estimates[stage].values())

            metrics[stage] = {
                "calls": total_calls,
                "hits": hits,
                "hit_rate": hit_rate,
                "estimated_unique_bytes": total_bytes,
                "estimated_unique_bytes_human": human_readable_size(total_bytes),
            }
        return metrics

    def clear(self) -> None:
        """Clear the current reuse metrics."""
        for stage in self.counts:
            self.counts[stage].clear()
            self.byte_estimates[stage].clear()


class ByteAwareCache:
    """A simple LRU cache that respects a byte limit."""

    def __init__(self, max_bytes: int) -> None:
        """Initialize the byte-aware cache.

        Args:
            max_bytes: Maximum number of bytes to store in the cache.

        """
        self.max_bytes = max_bytes
        self.current_bytes = 0
        self.cache: OrderedDict[tuple, tuple[int, AudioT]] = OrderedDict()

    def get(self, key: tuple) -> tuple[int, AudioT] | None:
        """Get an item from the cache.

        Args:
            key: The unique key for the item.

        Returns:
            The cached (org_samples, audio) tuple, or None if not found.

        """
        if key in self.cache:
            org_samples, value = self.cache.pop(key)
            self.cache[key] = (org_samples, value)
            return org_samples, value
        return None

    def put(self, key: tuple, value: tuple[int, AudioT]) -> None:
        """Put an item into the cache.

        Args:
            key: The unique key for the item.
            value: The (org_samples, audio) tuple to cache.

        """
        _, audio = value
        size = audio.nbytes
        if size > self.max_bytes:
            return

        while self.current_bytes + size > self.max_bytes and self.cache:
            _, old_entry = self.cache.popitem(last=False)
            self.current_bytes -= old_entry[1].nbytes

        if key in self.cache:
            _, old_audio = self.cache.pop(key)
            self.current_bytes -= old_audio.nbytes

        self.cache[key] = value
        self.current_bytes += size

    def clear(self) -> None:
        """Clear the cache."""
        self.cache.clear()
        self.current_bytes = 0

    def get_cache_metrics(self) -> dict[str, Any]:
        """Get current cache utilization metrics.

        Returns:
            A dictionary containing cache metrics.

        """
        return {
            "current_bytes": self.current_bytes,
            "current_bytes_human": human_readable_size(self.current_bytes),
            "items": len(self.cache),
            "max_bytes": self.max_bytes,
            "max_bytes_human": human_readable_size(self.max_bytes),
        }


_REUSE_TRACKER = ReuseTracker()
_PRE_EFFECTS_CACHE = ByteAwareCache(max_bytes=512 * 1024 * 1024)


def get_reuse_metrics() -> dict[str, dict[str, Any]]:
    """Get the current source-plan reuse metrics."""
    metrics = _REUSE_TRACKER.get_metrics()
    metrics["cache"] = _PRE_EFFECTS_CACHE.get_cache_metrics()
    return metrics


def clear_reuse_metrics() -> None:
    """Clear the current source-plan reuse metrics."""
    _REUSE_TRACKER.clear()
    _PRE_EFFECTS_CACHE.clear()
