"""Truth functions that retrieve source metrics."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sonusai.datatypes import Truth
    from sonusai.mixture.mixdb import MixtureDatabase


def metrics_validate(config: dict) -> None:
    """Validate the metrics truth configuration.

    Args:
        config: Configuration dictionary containing the 'metric' name.

    Raises:
        AttributeError: If 'metric' is missing or configuration is empty.

    """
    if len(config) == 0:
        msg = "metrics truth function is missing config"
        raise AttributeError(msg)

    parameters = ["metric"]
    for parameter in parameters:
        if parameter not in config:
            msg = f"metrics truth function is missing required '{parameter}'"
            raise AttributeError(msg)


def metrics_parameters(_feature: str, _num_classes: int, _config: dict) -> int | None:
    """Get the number of parameters for the metrics truth function.

    Args:
        _feature: Feature mode (unused).
        _num_classes: Number of classes (unused).
        _config: Configuration dictionary (unused).

    Returns:
        None, as metrics don't have a fixed number of numeric parameters.

    """
    return None


def metrics(mixdb: MixtureDatabase, m_id: int, category: str, config: dict) -> Truth:
    """Retrieve metrics for a source category.

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.
        category: Source category.
        config: Configuration dictionary containing the 'metric' name.

    Returns:
        Metrics for the category.

    """
    m = [config["metric"]] if not isinstance(config["metric"], list) else config["metric"]
    return mixdb.mixture_metrics(m_id, m)[m[0]][category]
