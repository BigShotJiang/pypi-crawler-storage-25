"""Truth functions that retrieve source metadata."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sonusai.datatypes import Truth
    from sonusai.mixture.mixdb import MixtureDatabase


def metadata_validate(config: dict) -> None:
    """Validate the metadata truth configuration.

    Args:
        config: Configuration dictionary containing the 'tier' name.

    Raises:
        AttributeError: If 'tier' is missing or configuration is empty.

    """
    if len(config) == 0:
        msg = "metadata truth function is missing config"
        raise AttributeError(msg)

    parameters = ["tier"]
    for parameter in parameters:
        if parameter not in config:
            msg = f"metadata truth function is missing required '{parameter}'"
            raise AttributeError(msg)


def metadata_parameters(_feature: str, _num_classes: int, _config: dict) -> int | None:
    """Get the number of parameters for the metadata truth function.

    Args:
        _feature: Feature mode (unused).
        _num_classes: Number of classes (unused).
        _config: Configuration dictionary (unused).

    Returns:
        None, as metadata doesn't have a fixed number of numeric parameters.

    """
    return None


def metadata(mixdb: MixtureDatabase, m_id: int, category: str, config: dict) -> Truth:
    """Retrieve metadata for a source category.

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.
        category: Source category.
        config: Configuration dictionary containing the 'tier' name.

    Returns:
        Metadata for the category.

    """
    return mixdb.mixture_speech_metadata(m_id, config["tier"])[category]
