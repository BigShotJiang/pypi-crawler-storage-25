"""Truth functions for phoneme-based truth generation (Not implemented)."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sonusai.datatypes import Truth
    from sonusai.mixture.mixdb import MixtureDatabase


def phoneme_validate(_config: dict) -> None:
    """Validate the phoneme truth configuration.

    Args:
        _config: Configuration dictionary.

    Raises:
        NotImplementedError: This function is not yet implemented.

    """
    msg = "Truth function phoneme is not supported yet"
    raise NotImplementedError(msg)


def phoneme_parameters(_feature: str, _num_classes: int, _config: dict) -> int:
    """Get the number of parameters for the phoneme truth function.

    Args:
        _feature: Feature mode.
        _num_classes: Number of classes.
        _config: Configuration dictionary.

    Returns:
        Number of truth parameters.

    Raises:
        NotImplementedError: This function is not yet implemented.

    """
    msg = "Truth function phoneme is not supported yet"
    raise NotImplementedError(msg)


def phoneme(_mixdb: MixtureDatabase, _m_id: int, _category: str, _config: dict) -> Truth:
    """Generate phoneme-based truth data.

    Args:
        _mixdb: Mixture database.
        _m_id: Mixture ID.
        _category: Source category.
        _config: Configuration dictionary.

    Returns:
        Phoneme truth data.

    Raises:
        NotImplementedError: This function is not yet implemented.

    """
    msg = "Truth function phoneme is not supported yet"
    raise NotImplementedError(msg)
