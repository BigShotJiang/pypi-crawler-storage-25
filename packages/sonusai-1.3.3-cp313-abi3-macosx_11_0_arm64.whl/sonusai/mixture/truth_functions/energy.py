"""Energy-based truth functions."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np
import scipy.special as sc
from pyaaware import feature_forward_transform_config
from pyaaware.torch import ForwardTransform

from sonusai.utils.energy_f import compute_energy_f
from sonusai.utils.load_object import load_object

if TYPE_CHECKING:
    from sonusai.datatypes import Truth
    from sonusai.mixture.mixdb import MixtureDatabase


def _core(
    mixdb: MixtureDatabase,
    m_id: int,
    category: str,
    config: dict,
    options: tuple[int, bool, bool, bool],
) -> Truth:
    import torch  # noqa: PLC0415 (Heavy loading: ~524ms)

    parameters, mapped, snr, use_cache = options

    source_audio = mixdb.mixture_sources(m_id)[category]
    ft = ForwardTransform(**feature_forward_transform_config(mixdb.feature))

    frames = ft.frames(torch.from_numpy(source_audio))

    if mixdb.mixture(m_id).all_sources[category].snr_gain == 0:
        return np.zeros((frames, parameters), dtype=np.float32)

    noise_audio = mixdb.mixture_noise(m_id)

    source_energy = compute_energy_f(time_domain=source_audio, transform=ft)
    noise_energy = None
    if snr:
        noise_energy = compute_energy_f(time_domain=noise_audio, transform=ft)

    frames = len(source_energy)
    truth = np.empty((frames, ft.bins), dtype=np.float32)
    for frame in range(frames):
        tmp = source_energy[frame]

        if noise_energy is not None:
            old_err = np.seterr(divide="ignore", invalid="ignore")
            tmp /= noise_energy[frame]
            np.seterr(**old_err)

        tmp = np.nan_to_num(tmp, nan=-np.inf, posinf=np.inf, neginf=-np.inf)

        if mapped:
            snr_db_mean = load_object(str(Path(mixdb.location) / config["snr_db_mean"]), use_cache)
            snr_db_std = load_object(str(Path(mixdb.location) / config["snr_db_std"]), use_cache)
            tmp = _calculate_mapped_snr_f(tmp, snr_db_mean, snr_db_std)

        truth[frame] = tmp

    return truth


def _calculate_mapped_snr_f(truth_f: np.ndarray, snr_db_mean: np.ndarray, snr_db_std: np.ndarray) -> np.ndarray:
    """Calculate mapped SNR from standard SNR energy per bin/class.

    Args:
        truth_f: Truth data in frequency domain.
        snr_db_mean: Mean of SNR in dB.
        snr_db_std: Standard deviation of SNR in dB.

    Returns:
        Mapped SNR values.

    """
    old_err = np.seterr(divide="ignore", invalid="ignore")
    num = 10 * np.log10(np.double(truth_f)) - np.double(snr_db_mean)
    den = np.double(snr_db_std) * np.sqrt(2)
    q = num / den
    q = np.nan_to_num(q, nan=-np.inf, posinf=np.inf, neginf=-np.inf)
    result = 0.5 * (1 + sc.erf(q))
    np.seterr(**old_err)

    return result.astype(np.float32)


def energy_f_validate(_config: dict) -> None:
    """Validate energy_f configuration.

    Args:
        _config: Configuration dictionary.

    """


def energy_f_parameters(feature: str, _num_classes: int, _config: dict) -> int:
    """Get the number of parameters for the energy_f truth function.

    Args:
        feature: Feature mode.
        _num_classes: Number of classes.
        _config: Configuration dictionary.

    Returns:
        Number of truth parameters.

    """
    return ForwardTransform(**feature_forward_transform_config(feature)).bins


def energy_f(mixdb: MixtureDatabase, m_id: int, category: str, config: dict, use_cache: bool = True) -> Truth:
    """Generate frequency domain energy truth data.

    Calculates the true energy per bin: Ti^2 + Tr^2, where T is the target
    STFT bin values.

    Output shape: [:, bins]

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.
        category: Source category.
        config: Configuration dictionary.
        use_cache: If true, use LRU caching.

    Returns:
        Frequency domain energy truth.

    """
    return _core(
        mixdb=mixdb,
        m_id=m_id,
        category=category,
        config=config,
        options=(
            energy_f_parameters(mixdb.feature, mixdb.num_classes, config),
            False,
            False,
            use_cache,
        ),
    )


def snr_f_validate(_config: dict) -> None:
    """Validate snr_f configuration.

    Args:
        _config: Configuration dictionary.

    """


def snr_f_parameters(feature: str, _num_classes: int, _config: dict) -> int:
    """Get the number of parameters for the snr_f truth function.

    Args:
        feature: Feature mode.
        _num_classes: Number of classes.
        _config: Configuration dictionary.

    Returns:
        Number of truth parameters.

    """
    return ForwardTransform(**feature_forward_transform_config(feature)).bins


def snr_f(mixdb: MixtureDatabase, m_id: int, category: str, config: dict, use_cache: bool = True) -> Truth:
    """Generate frequency domain SNR truth data.

    Calculates the true SNR per bin: (Ti^2 + Tr^2) / (Ni^2 + Nr^2), where T
    is the target and N is the noise STFT bin values.

    Output shape: [:, bins]

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.
        category: Source category.
        config: Configuration dictionary.
        use_cache: If true, use LRU caching.

    Returns:
        Frequency domain SNR truth.

    """
    return _core(
        mixdb=mixdb,
        m_id=m_id,
        category=category,
        config=config,
        options=(
            snr_f_parameters(mixdb.feature, mixdb.num_classes, config),
            False,
            True,
            use_cache,
        ),
    )


def mapped_snr_f_validate(config: dict) -> None:
    """Validate mapped_snr_f configuration.

    Args:
        config: Configuration dictionary.

    Raises:
        AttributeError: If required configuration keys are missing.

    """
    if len(config) == 0:
        msg = "mapped_snr_f truth function is missing config"
        raise AttributeError(msg)

    for parameter in ("snr_db_mean", "snr_db_std"):
        if parameter not in config:
            msg = f"mapped_snr_f truth function is missing required '{parameter}'"
            raise AttributeError(msg)


def mapped_snr_f_parameters(feature: str, _num_classes: int, _config: dict) -> int:
    """Get the number of parameters for the mapped_snr_f truth function.

    Args:
        feature: Feature mode.
        _num_classes: Number of classes.
        _config: Configuration dictionary.

    Returns:
        Number of truth parameters.

    """
    return ForwardTransform(**feature_forward_transform_config(feature)).bins


def mapped_snr_f(mixdb: MixtureDatabase, m_id: int, category: str, config: dict, use_cache: bool = True) -> Truth:
    """Generate frequency domain mapped SNR truth data.

    Output shape: [:, bins]

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.
        category: Source category.
        config: Configuration dictionary.
        use_cache: If true, use LRU caching.

    Returns:
        Frequency domain mapped SNR truth.

    """
    return _core(
        mixdb=mixdb,
        m_id=m_id,
        category=category,
        config=config,
        options=(
            mapped_snr_f_parameters(mixdb.feature, mixdb.num_classes, config),
            True,
            True,
            use_cache,
        ),
    )


def energy_t_validate(_config: dict) -> None:
    """Validate energy_t configuration.

    Args:
        _config: Configuration dictionary.

    """


def energy_t_parameters(_feature: str, _num_classes: int, _config: dict) -> int:
    """Get the number of parameters for the energy_t truth function.

    Args:
        _feature: Feature mode.
        _num_classes: Number of classes.
        _config: Configuration dictionary.

    Returns:
        1, as time domain energy is a single value per frame.

    """
    return 1


def energy_t(mixdb: MixtureDatabase, m_id: int, category: str, _config: dict) -> Truth:
    """Generate time domain energy truth data.

    Calculates the true time domain energy of each frame.

    Output shape: [:, 1]

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.
        category: Source category.
        _config: Configuration dictionary.

    Returns:
        Time domain energy truth.

    """
    import torch  # noqa: PLC0415 (Heavy loading: ~524ms)

    source_audio = torch.from_numpy(mixdb.mixture_sources(m_id)[category])

    ft = ForwardTransform(**feature_forward_transform_config(mixdb.feature))

    frames = ft.frames(source_audio)
    parameters = energy_f_parameters(mixdb.feature, mixdb.num_classes, _config)
    if mixdb.mixture(m_id).all_sources[category].snr_gain == 0:
        return np.zeros((frames, parameters), dtype=np.float32)

    return ft.execute_all(source_audio)[1].numpy()
