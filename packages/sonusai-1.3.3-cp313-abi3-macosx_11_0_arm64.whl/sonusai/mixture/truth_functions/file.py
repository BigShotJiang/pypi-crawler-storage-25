"""Truth functions that read truth data from a file."""

from __future__ import annotations

from typing import TYPE_CHECKING

import h5py
import numpy as np
from pyaaware import feature_inverse_transform_config

if TYPE_CHECKING:
    from sonusai.datatypes import Truth
    from sonusai.mixture.mixdb import MixtureDatabase


def file_validate(config: dict) -> None:
    """Validate the file truth configuration.

    Args:
        config: Configuration dictionary containing the 'file' path.

    Raises:
        AttributeError: If 'file' is missing from the configuration.
        ValueError: If the truth file does not contain the 'truth_f' dataset.

    """
    if len(config) == 0:
        msg = "file truth function is missing config"
        raise AttributeError(msg)

    if "file" not in config:
        msg = "file truth function is missing required 'file'"
        raise AttributeError(msg)

    with h5py.File(config["file"], "r") as f:
        if "truth_f" not in f:
            msg = "Truth file does not contain truth_f dataset"
            raise ValueError(msg)


def file_parameters(_feature: str, _num_classes: int, config: dict) -> int:
    """Get the number of parameters for the file truth function.

    Args:
        _feature: Feature mode (unused).
        _num_classes: Number of classes (unused).
        config: Configuration dictionary containing the 'file' path.

    Returns:
        Number of truth parameters.

    """
    with h5py.File(config["file"], "r") as f:
        truth = np.array(f["truth_f"])

    return truth.shape[-1]


def file(mixdb: MixtureDatabase, m_id: int, category: str, config: dict) -> Truth:
    """Read truth data from an HDF5 file.

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.
        category: Source category.
        config: Configuration dictionary containing the 'file' path.

    Returns:
        Truth data from the file.

    Raises:
        ValueError: If truth data has incorrect dimensions or number of frames.

    """
    source_audio = mixdb.mixture_sources(m_id)[category]

    frame_size = feature_inverse_transform_config(mixdb.feature)["overlap"]

    with h5py.File(config["file"], "r") as f:
        truth = np.array(f["truth_f"])

    if truth.ndim != 2:
        msg = "Truth file data is not 2 dimensions"
        raise ValueError(msg)

    if truth.shape[0] != len(source_audio) // frame_size:
        msg = "Truth file does not contain the right amount of frames"
        raise ValueError(msg)

    return truth
