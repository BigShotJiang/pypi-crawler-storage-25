"""Sound Energy Detection (SED) truth functions."""

from __future__ import annotations

from itertools import pairwise
from typing import TYPE_CHECKING

import numpy as np
from pyaaware import SED
from pyaaware import feature_forward_transform_config
from pyaaware import feature_inverse_transform_config

if TYPE_CHECKING:
    from sonusai.datatypes import Truth
    from sonusai.mixture.mixdb import MixtureDatabase


def sed_validate(config: dict) -> None:
    """Validate the SED truth configuration.

    Args:
        config: Configuration dictionary containing 'thresholds'.

    Raises:
        AttributeError: If 'thresholds' is missing or configuration is empty.
        ValueError: If thresholds are not strictly decreasing.

    """
    if len(config) == 0:
        msg = "sed truth function is missing config"
        raise AttributeError(msg)

    parameters = ["thresholds"]
    for parameter in parameters:
        if parameter not in config:
            msg = f"sed truth function is missing required '{parameter}'"
            raise AttributeError(msg)

    thresholds = config["thresholds"]
    if not _strictly_decreasing(thresholds):
        msg = f"sed truth function 'thresholds' are not strictly decreasing: {thresholds}"
        raise ValueError(msg)


def sed_parameters(_feature: str, num_classes: int, _config: dict) -> int:
    """Get the number of parameters for the SED truth function.

    Args:
        _feature: Feature mode.
        num_classes: Number of classes.
        _config: Configuration dictionary.

    Returns:
        Number of truth parameters (equal to num_classes).

    """
    return num_classes


def sed(mixdb: MixtureDatabase, m_id: int, category: str, config: dict) -> Truth:
    """Generate Sound Energy Detection (SED) truth data.

    Calculates sound energy detection truth using a simple 3 threshold
    hysteresis algorithm. SED outputs 3 possible probabilities of
    sound presence: 1.0 present, 0.5 (transition/uncertain), 0 not
    present.

    Output shape: [:, num_classes]

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.
        category: Source category.
        config: Configuration dictionary containing 'thresholds'.

    Returns:
        SED truth data.

    Raises:
        ValueError: If audio length is invalid or frame calculation is incorrect.

    """
    import torch  # noqa: PLC0415 (Heavy loading: ~400ms)
    from pyaaware.torch import ForwardTransform  # noqa: PLC0415 (Heavy loading: ~390ms)

    source_audio = torch.from_numpy(mixdb.mixture_sources(m_id)[category])

    frame_size = feature_inverse_transform_config(mixdb.feature)["overlap"]

    ft = ForwardTransform(**feature_forward_transform_config(mixdb.feature))

    if len(source_audio) % frame_size != 0:
        msg = f"Number of samples in audio is not a multiple of {frame_size}"
        raise ValueError(msg)

    frames = ft.frames(source_audio)
    parameters = sed_parameters(mixdb.feature, mixdb.num_classes, config)
    if mixdb.mixture(m_id).all_sources[category].snr_gain == 0:
        return np.zeros((frames, parameters), dtype=np.float32)

    # SED wants 1-based indices
    s = SED(
        thresholds=config["thresholds"],
        index=mixdb.source_file(mixdb.mixture(m_id).all_sources[category].file_id).class_indices,
        frame_size=frame_size,
        num_classes=mixdb.num_classes,
    )

    # Compute energy
    target_energy = ft.execute_all(source_audio)[1].numpy()

    if frames != target_energy.shape[0]:
        msg = "Incorrect frames calculation in sed truth function"
        raise ValueError(msg)

    return s.execute_all(target_energy)


def _strictly_decreasing(list_to_check: list) -> bool:
    """Check if a list of values is strictly decreasing.

    Args:
        list_to_check: List of numeric values.

    Returns:
        True if strictly decreasing, False otherwise.

    """
    return all(x > y for x, y in pairwise(list_to_check))
