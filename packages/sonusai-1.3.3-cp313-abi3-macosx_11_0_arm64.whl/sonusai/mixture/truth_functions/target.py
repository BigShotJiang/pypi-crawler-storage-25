"""Target-based truth functions (frequency domain)."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import torch
from pyaaware import feature_forward_transform_config
from pyaaware import feature_inverse_transform_config
from pyaaware.torch import ForwardTransform
from pyaaware.torch import InverseTransform

from sonusai.utils.stacked_complex import stack_complex

if TYPE_CHECKING:
    from sonusai.datatypes import Truth
    from sonusai.mixture.mixdb import MixtureDatabase


def target_f_validate(_config: dict) -> None:
    """Validate target_f configuration.

    Args:
        _config: Configuration dictionary.

    """


def target_f_parameters(feature: str, _num_classes: int, _config: dict) -> int:
    """Get the number of parameters for the target_f truth function.

    Args:
        feature: Feature mode.
        _num_classes: Number of classes.
        _config: Configuration dictionary.

    Returns:
        Number of truth parameters.

    """
    ft = ForwardTransform(**feature_forward_transform_config(feature))

    if ft.ttype == "tdac-co":
        return ft.bins

    return ft.bins * 2


def target_f(mixdb: MixtureDatabase, m_id: int, category: str, _config: dict) -> Truth:
    """Generate frequency domain target truth data.

    Calculates the true transform of the target using the STFT
    configuration defined by the feature.

    Output shape: [:, 2 * bins] (target stacked real, imag) or
                  [:, bins] (target real only for tdac-co)

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.
        category: Source category.
        _config: Configuration dictionary.

    Returns:
        Frequency domain target truth.

    """
    ft = ForwardTransform(**feature_forward_transform_config(mixdb.feature))

    target_audio = torch.tensor(mixdb.mixture_sources(m_id)[category])

    target_freq = ft.execute_all(target_audio)[0].numpy()
    return _stack_real_imag(target_freq, ft.ttype)


def target_mixture_f_validate(_config: dict) -> None:
    """Validate target_mixture_f configuration.

    Args:
        _config: Configuration dictionary.

    """


def target_mixture_f_parameters(feature: str, _num_classes: int, _config: dict) -> int:
    """Get the number of parameters for the target_mixture_f truth function.

    Args:
        feature: Feature mode.
        _num_classes: Number of classes.
        _config: Configuration dictionary.

    Returns:
        Number of truth parameters.

    """
    ft = ForwardTransform(**feature_forward_transform_config(feature))

    if ft.ttype == "tdac-co":
        return ft.bins * 2

    return ft.bins * 4


def target_mixture_f(mixdb: MixtureDatabase, m_id: int, category: str, _config: dict) -> Truth:
    """Generate frequency domain target and mixture truth data.

    Calculates the true transform of the target and the mixture
    using the STFT configuration defined by the feature.

    Output shape: [:, 4 * bins] (target stacked real, imag; mixture stacked real, imag) or
                  [:, 2 * bins] (target real; mixture real for tdac-co)

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.
        category: Source category.
        _config: Configuration dictionary.

    Returns:
        Frequency domain target and mixture truth.

    """
    ft = ForwardTransform(**feature_forward_transform_config(mixdb.feature))

    target_audio = torch.from_numpy(mixdb.mixture_sources(m_id)[category])
    mixture_audio = torch.from_numpy(mixdb.mixture_mixture(m_id))

    target_freq = ft.execute_all(torch.from_numpy(target_audio))[0].numpy()
    mixture_freq = ft.execute_all(torch.from_numpy(mixture_audio))[0].numpy()

    frames, bins = target_freq.shape
    truth = np.empty((frames, bins * 4), dtype=np.float32)
    truth[:, : bins * 2] = _stack_real_imag(target_freq, ft.ttype)
    truth[:, bins * 2 :] = _stack_real_imag(mixture_freq, ft.ttype)
    return truth


def target_swin_f_validate(_config: dict) -> None:
    """Validate target_swin_f configuration.

    Args:
        _config: Configuration dictionary.

    """


def target_swin_f_parameters(feature: str, _num_classes: int, _config: dict) -> int:
    """Get the number of parameters for the target_swin_f truth function.

    Args:
        feature: Feature mode.
        _num_classes: Number of classes.
        _config: Configuration dictionary.

    Returns:
        Number of truth parameters.

    """
    return ForwardTransform(**feature_forward_transform_config(feature)).bins * 2


def target_swin_f(mixdb: MixtureDatabase, m_id: int, category: str, _config: dict) -> Truth:
    """Generate frequency domain target with synthesis window truth data.

    Calculates the true transform of the target using the STFT
    configuration defined by the feature, including the synthesis window.

    Output shape: [:, 2 * bins] (stacked real, imag)

    Args:
        mixdb: Mixture database.
        m_id: Mixture ID.
        category: Source category.
        _config: Configuration dictionary.

    Returns:
        Frequency domain target with synthesis window truth.

    """
    ft = ForwardTransform(**feature_forward_transform_config(mixdb.feature))
    it = InverseTransform(**feature_inverse_transform_config(mixdb.feature))

    target_audio = mixdb.mixture_sources(m_id)[category]

    truth = np.empty((len(target_audio) // ft.overlap, ft.bins * 2), dtype=np.float32)
    for idx, offset in enumerate(range(0, len(target_audio), ft.overlap)):
        audio_frame = torch.from_numpy(np.multiply(target_audio[offset : offset + ft.overlap], it.window))
        target_freq = ft.execute(audio_frame)[0].numpy()
        truth[idx] = stack_complex(target_freq)

    return truth


def _stack_real_imag(data: Truth, ttype: str) -> Truth:
    """Stack real and imaginary components of complex data.

    Args:
        data: Complex input data.
        ttype: Transform type.

    Returns:
        Stacked real/imag data or just real part if tdac-co.

    """
    if ttype == "tdac-co":
        return np.real(data)

    return stack_complex(data)
