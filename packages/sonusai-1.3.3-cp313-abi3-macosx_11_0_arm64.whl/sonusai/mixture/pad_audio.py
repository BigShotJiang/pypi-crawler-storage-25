"""Audio padding utilities for mixtures."""

import numpy as np

from sonusai.datatypes import AudioT


def pad_audio_to_frame(audio: AudioT, frame_length: int = 1) -> AudioT:
    """Pad audio to be a multiple of frame length.

    Args:
        audio: Audio data.
        frame_length: Pad resulting audio to be a multiple of this.

    Returns:
        Padded audio data.

    """
    return pad_audio_to_length(audio, get_padded_length(len(audio), frame_length))


def get_padded_length(length: int, frame_length: int) -> int:
    """Get the number of pad samples needed.

    Args:
        length: Original length of audio.
        frame_length: Desired length will be a multiple of this.

    Returns:
        The total length after padding.

    """
    mod = int(length % frame_length)
    pad_length = frame_length - mod if mod else 0
    return length + pad_length


def pad_audio_to_length(audio: AudioT, length: int) -> AudioT:
    """Pad audio to the given length.

    Args:
        audio: Audio data.
        length: Desired output length.

    Returns:
        Padded audio data.

    """
    return np.pad(array=audio, pad_width=(0, length - len(audio)))
