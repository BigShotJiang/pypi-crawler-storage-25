"""Feature extraction and audio reconstruction for mixtures."""

import numpy as np
from pyaaware import FeatureGenerator

from sonusai.datatypes import AudioT
from sonusai.datatypes import Feature
from sonusai.datatypes import TransformConfig
from sonusai.utils.compress import power_uncompress
from sonusai.utils.stacked_complex import unstack_complex

from .helpers import forward_transform
from .helpers import inverse_transform


def get_feature_from_audio(audio: AudioT, feature_mode: str) -> Feature:
    """Apply forward transform and generate feature data from audio data.

    Args:
        audio: Time domain audio data [samples].
        feature_mode: Feature mode.

    Returns:
        Feature data [frames, strides, feature_parameters].

    """
    fg = FeatureGenerator(feature_mode=feature_mode)

    audio_f = forward_transform(
        audio=audio,
        config=TransformConfig(
            length=fg.ftransform_length,
            overlap=fg.ftransform_overlap,
            bin_start=fg.bin_start,
            bin_end=fg.bin_end,
            ttype=fg.ftransform_ttype,
        ),
    )

    # Need to pad transform data to account for SOV modes
    # audio_f dimensions [transform_frames, bins]
    original_frames = audio_f.shape[0]
    total_frames = np.ceil(original_frames / fg.step) * fg.step
    pad_frames = total_frames - original_frames
    padded_audio_f = np.pad(audio_f, ((0, pad_frames), (0, 0)), mode="constant", constant_values=0)

    return fg.execute_tf_all(padded_audio_f)[0]


def get_audio_from_feature(feature: Feature, feature_mode: str) -> AudioT:
    """Apply inverse transform to feature data to generate audio data.

    Args:
        feature: Feature data [frames, stride=1, feature_parameters].
        feature_mode: Feature mode.

    Returns:
        Audio data [samples].

    Raises:
        ValueError: If feature dimensions are invalid or stride is not 1.

    """
    if feature.ndim != 3:
        msg = "feature must have 3 dimensions: [frames, stride=1, feature_parameters]"
        raise ValueError(msg)

    if feature.shape[1] != 1:
        msg = "Strided feature data is not supported for audio extraction; stride must be 1."
        raise ValueError(msg)

    fg = FeatureGenerator(feature_mode=feature_mode)

    feature_complex = unstack_complex(feature.squeeze())
    if feature_mode[0:1] == "h":
        feature_complex = power_uncompress(feature_complex)
    return np.squeeze(
        inverse_transform(
            transform=feature_complex,
            config=TransformConfig(
                length=fg.itransform_length,
                overlap=fg.itransform_overlap,
                bin_start=fg.bin_start,
                bin_end=fg.bin_end,
                ttype=fg.itransform_ttype,
            ),
        )
    )
