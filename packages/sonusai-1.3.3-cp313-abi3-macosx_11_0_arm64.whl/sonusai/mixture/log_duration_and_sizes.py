"""Utilities for logging mixture durations and estimated memory sizes."""

from sonusai import logger
from sonusai.constants import FLOAT_BYTES
from sonusai.constants import SAMPLE_BYTES
from sonusai.constants import SAMPLE_RATE
from sonusai.utils.human_readable_size import human_readable_size
from sonusai.utils.seconds_to_hms import seconds_to_hms


def log_duration_and_sizes(
    total_duration: float,
    feature_step_samples: int,
    feature_parameters: int,
    stride: int,
    desc: str,
) -> None:
    """Log the total duration and estimated memory sizes for mixture and features.

    Args:
        total_duration: Total duration in seconds.
        feature_step_samples: Number of samples per feature step.
        feature_parameters: Number of parameters per feature.
        stride: Stride value.
        desc: Description prefix for log messages.

    """
    total_samples = int(total_duration * SAMPLE_RATE)
    mixture_bytes = total_samples * SAMPLE_BYTES
    feature_bytes = total_samples / feature_step_samples * stride * feature_parameters * FLOAT_BYTES

    logger.info("")
    logger.info(f"{desc} duration:   {seconds_to_hms(seconds=total_duration)}")
    logger.info(f"{desc} sizes:")
    logger.info(f" mixture:             {human_readable_size(mixture_bytes, 1)}")
    logger.info(f" feature:             {human_readable_size(feature_bytes, 1)}")
