"""Utilities for applying spectral masking to audio features."""

import numpy as np

from sonusai.datatypes import AudioF
from sonusai.datatypes import SpectralMask


def apply_spectral_mask(audio_f: AudioF, spectral_mask: SpectralMask, seed: int | None = None) -> AudioF:
    """Apply frequency and time masking (SpecAugment).

    Implementation of SpecAugment: A Simple Data Augmentation Method for Automatic Speech Recognition.
    Reference: https://arxiv.org/pdf/1904.08779.pdf

    Args:
        audio_f: Numpy array of transform audio data [frames, bins].
        spectral_mask: Spectral mask parameters.
        seed: Random number seed.

    Returns:
        Augmented feature.

    Raises:
        ValueError: If feature input does not have two dimensions [frames, bins].

    """
    if audio_f.ndim != 2:
        msg = "feature input must have three dimensions [frames, bins]"
        raise ValueError(msg)

    frames, bins = audio_f.shape

    f_max_width = spectral_mask.f_max_width
    if f_max_width not in range(bins + 1):
        f_max_width = bins

    rng = np.random.default_rng(seed)

    # apply f_num frequency masks to the feature
    for _ in range(spectral_mask.f_num):
        f_width = int(rng.uniform(0, f_max_width))
        f_start = rng.integers(0, bins - f_width, endpoint=True)
        audio_f[:, f_start : f_start + f_width] = 0

    # apply t_num time masks to the feature
    t_upper_bound = int(spectral_mask.t_max_percent / 100 * frames)
    for _ in range(spectral_mask.t_num):
        t_width = min(int(rng.uniform(0, spectral_mask.t_max_width)), t_upper_bound)
        t_start = rng.integers(0, frames - t_width, endpoint=True)
        audio_f[t_start : t_start + t_width, :] = 0

    return audio_f
