"""Calculate speech enhancement metrics for SonusAI mixture data.

Usage:
    genmetrics [-hvusd] [-i MIXID] [-n INCLUDE] [-x EXCLUDE] [-p NUMPROC] LOC

Options:
    -h, --help
    -v, --verbose                   Be verbose.
    -i MIXID, --mixid MIXID         Mixture ID(s) to generate. [default: *].
    -n INCLUDE, --include INCLUDE   Metrics to include. [default: all]
    -x EXCLUDE, --exclude EXCLUDE   Metrics to exclude. [default: none]
    -p NUMPROC, --nproc NUMPROC     Number of parallel processes to use. Default single thread.
    -u, --update                    Update metrics (do not regenerate existing metrics).
    -s, --supported                 Show list of supported metrics.
    -d, --dryrun                    Show list of metrics that will be generated and exit.

Inputs:
    LOC         A SonusAI mixture database directory.
    MIXID       A glob of mixture ID(s) to generate.
    INCLUDE     Comma separated list of metrics to include. Can be "all" or
                any of the supported metrics or glob(s).
    EXCLUDE     Comma separated list of metrics to exclude. Can be "none" or
                any of the supported metrics or glob(s)

Note: The default include of "all" excludes the generation of ASR metrics,
i.e., "*asr*,*wer*". However, if include is manually specified to something other than "all",
then this behavior is overridden.

Similarly, the default exclude of "none" excludes the generation of ASR metrics,
i.e., "*asr*,*wer*". However, if exclude is manually specified to something other than "none",
then this behavior is also overridden.

Examples:
    Generate all available mxwer metrics (as determined by mixdb asr_configs parameter):
    > sonusai genmetrics -n"mxwer*" mixdb_loc

    Generate only mxwer.faster metrics:
    > sonusai genmetrics -n"mxwer.faster" mixdb_loc

    Generate only faster metrics:
    > sonusai genmetrics -n"*faster" mixdb_loc

    Generate all available metrics except for mxcovl
    > sonusai genmetrics -x"mxcovl" mixdb_loc

"""

from __future__ import annotations

import fnmatch
import sys
import time
from dataclasses import dataclass
from functools import partial
from pathlib import Path

from docopt import docopt

import sonusai
from sonusai import create_file_handler
from sonusai import exception_handler
from sonusai import initial_log_messages
from sonusai import logger
from sonusai import update_console_handler
from sonusai.mixture import MixtureDatabase
from sonusai.mixture.data_io import write_cached_data
from sonusai.mixture.helpers import write_mixture_metadata
from sonusai.utils.docstring import trim_docstring
from sonusai.utils.keyboard_interrupt import register_keyboard_interrupt
from sonusai.utils.parallel import par_track
from sonusai.utils.parallel import track
from sonusai.utils.seconds_to_hms import seconds_to_hms


@dataclass
class GenMetricsCliArgs:
    """Parsed CLI arguments for genmetrics."""

    verbose: bool
    mixids: str
    includes: set[str]
    excludes: set[str]
    update: bool
    show_supported: bool
    dryrun: bool
    num_proc: int | None
    location: str


def _split_patterns(raw: str) -> set[str]:
    """Split comma/space-separated pattern strings."""
    return {item.strip() for item in raw.replace(" ", ",").lower().split(",") if item != ""}


def _parse_cli_args(args: dict[str, object]) -> GenMetricsCliArgs:
    """Convert docopt args to structured CLI arguments."""
    num_proc = int(args["--nproc"]) if args["--nproc"] is not None else None
    return GenMetricsCliArgs(
        verbose=bool(args["--verbose"]),
        mixids=str(args["--mixid"]),
        includes=_split_patterns(str(args["--include"])),
        excludes=_split_patterns(str(args["--exclude"])),
        update=bool(args["--update"]),
        show_supported=bool(args["--supported"]),
        dryrun=bool(args["--dryrun"]),
        num_proc=num_proc,
        location=str(args["LOC"]),
    )


def _resolve_requested_metrics(supported_names: list[str], includes: set[str], excludes: set[str]) -> list[str]:
    """Resolve requested metrics from include/exclude glob patterns."""
    effective_excludes = excludes
    if "none" in effective_excludes:
        effective_excludes = {"*asr*", "*wer*"} if "all" in includes else set()

    effective_includes = {"*"} if "all" in includes else includes

    included_metrics = {metric for include in effective_includes for metric in fnmatch.filter(supported_names, include)}
    excluded_metrics = {metric for exclude in effective_excludes for metric in fnmatch.filter(supported_names, exclude)}

    return sorted(included_metrics - excluded_metrics)


def _handle_supported_and_dryrun(show_supported: bool, dryrun: bool, supported_pretty: str, metrics: list[str]) -> None:
    """Handle early-exit CLI modes."""
    if show_supported:
        logger.info(f"\nSupported metrics:\n\n{supported_pretty}")
        sys.exit(0)

    if len(metrics) == 0:
        logger.warning("No metrics were requested")
        sys.exit(1)

    logger.info("Generating metrics:")
    logger.info(f"{', '.join(metrics)}")
    if dryrun:
        sys.exit(0)


def _run_metric_generation(
    location: str,
    mixids: list[int],
    metrics: list[str],
    update: bool,
    num_proc: int | None,
) -> list[set[str]]:
    """Generate metrics for all requested mixids."""
    no_par = num_proc == 1 or len(mixids) == 1
    progress = track(total=len(mixids), desc="genmetrics")
    results = par_track(
        partial(_process_mixture, location=location, metrics=metrics, update=update),
        mixids,
        progress=progress,
        num_cpus=num_proc,
        no_par=no_par,
    )
    progress.close()
    return results


def _process_mixture(mixid: int, location: str, metrics: list[str], update: bool = False) -> set[str]:
    """Process a single mixture to calculate and cache metrics.

    Args:
        mixid: ID of the mixture to process.
        location: Path to the mixture database.
        metrics: List of metric names to calculate.
        update: If True, only calculate metrics that are not already cached.

    Returns:
        A set of metric names that were successfully calculated and cached.

    """
    mixdb = MixtureDatabase(location)
    results = mixdb.mixture_metrics(m_id=mixid, metrics=metrics, force=not update)
    write_cached_data(mixdb.location, "mixture", mixdb.mixture(mixid).name, results)
    write_mixture_metadata(mixdb, mixture=mixdb.mixture(mixid))

    return set(results.keys())


def main() -> None:
    """Execute the genmetrics CLI."""
    args = docopt(trim_docstring(__doc__), version=sonusai.__version__, options_first=True)

    cli_args = _parse_cli_args(args)

    start_time = time.monotonic()

    # Setup logging file
    create_file_handler(str(Path(cli_args.location) / "genmetrics.log"), cli_args.verbose)
    update_console_handler(cli_args.verbose)
    initial_log_messages("genmetrics")

    logger.info(f"Load mixture database from {cli_args.location}")

    mixdb = MixtureDatabase(cli_args.location)
    supported = mixdb.supported_metrics
    metrics = _resolve_requested_metrics(supported.names, cli_args.includes, cli_args.excludes)
    _handle_supported_and_dryrun(cli_args.show_supported, cli_args.dryrun, supported.pretty, metrics)

    mixids = mixdb.mixids_to_list(cli_args.mixids)
    logger.info("")
    logger.info(f"Found {len(mixids):,} mixtures to process")

    results = _run_metric_generation(
        location=cli_args.location,
        mixids=mixids,
        metrics=metrics,
        update=cli_args.update,
        num_proc=cli_args.num_proc,
    )

    written_metrics = sorted(set().union(*results))
    logger.info(f"Wrote metrics for {len(mixids)} mixtures to {cli_args.location}:")
    logger.info(f"{', '.join(written_metrics)}")
    logger.info("")

    end_time = time.monotonic()
    logger.info(f"Completed in {seconds_to_hms(seconds=end_time - start_time)}")
    logger.info("")


if __name__ == "__main__":
    register_keyboard_interrupt()
    try:
        main()
    except Exception as e:  # noqa: BLE001 (Global CLI exception handler)
        exception_handler(e)
