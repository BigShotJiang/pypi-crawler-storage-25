"""Calculate delay and gain metrics of impulse response (IR) files.

Usage:
    ir_metric [-h] [-n NCPU] IRLOC

Options:
    -h, --help
    -n, --num_process NCPU      Number of parallel processes to use [default: auto]

Calculates gain and multiple ways to calculate the IR delay:
 - gmax:  max abs(fft(ir,4096))
 - dcc:   cross-correlation of ir with pulse train
 - dmax:  index of max(ir)
 - dgd:   group delay method
 - dcen:  centroid of energy

Results are written into `IRLOC/ir_metrics.txt`.

IRLOC: Directory containing impulse response data in audio files (.wav, .flac, etc.).
Only the first channel is analyzed.
"""

from __future__ import annotations

from functools import partial
from os.path import commonprefix
from pathlib import Path
from typing import TYPE_CHECKING

import docopt
import matplotlib.pyplot as plt
import numpy as np
import psutil
from numpy import fft
from pyaaware import rs as pars

from sonusai import __version__ as sai_version
from sonusai.utils.braced_glob import braced_iglob
from sonusai.utils.create_timestamp import create_timestamp
from sonusai.utils.docstring import trim_docstring
from sonusai.utils.parallel import par_track
from sonusai.utils.parallel import track

if TYPE_CHECKING:
    import pandas as pd
    from numpy.typing import ArrayLike


def tdoa(  # noqa: PLR0913 (Public API; keep signature compatibility)
    signal: ArrayLike,
    reference: ArrayLike,
    interp: int = 1,
    phat: bool = False,
    fs: int | float = 1,
    t_max: float | None = None,
) -> float:
    """Estimate the time delay of arrival (TDOA).

    Estimates the shift of array signal with respect to reference using
    generalized cross-correlation.

    Args:
        signal: The array whose TDOA is measured.
        reference: The reference array.
        interp: The interpolation factor for the output array.
        phat: Whether to apply the PHAT weighting.
        fs: The sampling frequency of the input arrays.
        t_max: Maximum time delay to consider.

    Returns:
        float: The estimated delay between the two arrays.

    """
    signal = np.array(signal)
    reference = np.array(reference)

    signal.shape[0]
    N2 = reference.shape[0]  # noqa: N806  # Math notation: length of signal 2

    r_12 = correlate(signal, reference, interp=interp, phat=phat)

    return (np.argmax(np.abs(r_12)) / interp - (N2 - 1)) / fs


def correlate(x1: ArrayLike, x2: ArrayLike, interp: int = 1, phat: bool = False) -> np.ndarray:
    """Compute the cross-correlation between x1 and x2.

    Args:
        x1: First data array.
        x2: Second data array.
        interp: The interpolation factor for the output array.
        phat: Whether to apply the PHAT weighting.

    Returns:
        np.ndarray: The cross-correlation between the two arrays.

    """
    N1 = x1.shape[0]  # noqa: N806  # Math notation: length of signal 1
    N2 = x2.shape[0]  # noqa: N806  # Math notation: length of signal 2

    N = N1 + N2 - 1  # noqa: N806  # Math notation: FFT length

    X1 = fft.rfft(x1, n=N)  # noqa: N806  # Math notation: FFT of signal 1
    X2 = fft.rfft(x2, n=N)  # noqa: N806  # Math notation: FFT of signal 2

    if phat:
        eps1 = np.mean(np.abs(X1)) * 1e-10
        X1 /= np.abs(X1) + eps1  # noqa: N806
        eps2 = np.mean(np.abs(X2)) * 1e-10
        X2 /= np.abs(X2) + eps2  # noqa: N806

    np.minimum(N1, N2)

    out = fft.irfft(X1 * np.conj(X2), n=int(N * interp))

    return np.concatenate([out[-interp * (N2 - 1) :], out[: (interp * N1)]])


def hilbert(u: ArrayLike) -> np.ndarray:
    """Compute the analytic signal using the Hilbert transform.

    Args:
        u: The input signal.

    Returns:
        np.ndarray: The analytic signal.

    """
    # N : fft length
    # M : number of elements to zero out
    # U : DFT of u
    # v : IDFT of H(U)

    N = len(u)  # noqa: N806  # Math notation: FFT length
    # take forward Fourier transform
    U = fft.fft(u)  # noqa: N806  # Math notation: FFT of signal
    M = N - N // 2 - 1  # noqa: N806  # Math notation: number of elements to zero out
    # zero out negative frequency components
    U[N // 2 + 1 :] = [0] * M
    # double fft energy except @ DC0
    U[1 : N // 2] = 2 * U[1 : N // 2]
    # take inverse Fourier transform
    return fft.ifft(U)


def _normalize_energy_curve(
    h: ArrayLike, fs: float | int, energy_thres: float
) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    """Create normalized Schroeder energy curve in dB."""
    h_arr = np.abs(hilbert(np.array(h)))
    fs_float = float(fs)

    power = h_arr**2
    energy = np.cumsum(power[::-1])[::-1]

    if energy_thres < 1.0:
        assert 0.0 < energy_thres < 1.0
        energy -= energy[0] * (1.0 - energy_thres)
        energy = np.maximum(energy, 0.0)

    i_nz = np.max(np.where(energy > 0)[0])
    energy = energy[:i_nz]
    energy_db = 10 * np.log10(energy)
    energy_db -= energy_db[0]
    return power, energy, energy_db, fs_float


def _find_decay_index(energy_db: np.ndarray, threshold: float) -> int | None:
    """Find first index where the dB curve drops below threshold."""
    try:
        return int(np.min(np.where(energy_db < threshold)[0]))
    except ValueError:
        return None


def _compute_rt_metrics(energy_db: np.ndarray, fs: float, i_5db: int) -> tuple[float, float, float, int]:
    """Compute RT10/RT20/RT60 and floor level from the normalized curve."""
    floor = 1
    t_5db = i_5db / fs

    i_decay10db = _find_decay_index(energy_db, -15)
    if i_decay10db is None:
        i_decay10db = len(energy_db)
    rt10 = i_decay10db / fs - t_5db

    i_decay20db = _find_decay_index(energy_db, -25)
    if i_decay20db is None:
        floor = 2
        i_decay20db = len(energy_db)
    rt20 = i_decay20db / fs - t_5db

    i_decay60db = _find_decay_index(energy_db, -65)
    if i_decay60db is None:
        floor = 3
        rt60 = 3 * i_decay20db / fs - t_5db
    else:
        floor = 4
        rt60 = i_decay60db / fs - t_5db

    return rt60, rt10, rt20, floor


def _plot_rt60(  # noqa: PLR0913 (Clear explicit plotting inputs preferred)
    energy: np.ndarray,
    power: np.ndarray,
    energy_db: np.ndarray,
    fs: float,
    i_5db: int,
    e_5db: float,
    rt60: float,
    rt60_tgt: float | None,
) -> None:
    """Plot power and energy decay along with RT60 estimate."""
    energy_min = energy[-1]
    energy_db_min = energy_db[-1]
    power_plot = power.copy()
    power_plot[power_plot < energy_min] = energy_min
    power_db = 10 * np.log10(power_plot)
    power_db -= np.max(power_db)

    def get_time(x: np.ndarray, sampling_rate: float) -> np.ndarray:
        return np.arange(x.shape[0]) / sampling_rate - i_5db / sampling_rate

    time_axis = get_time(power_db, fs)
    plt.plot(get_time(energy_db, fs), energy_db, label="Energy")
    plt.plot([0, rt60], [e_5db, -65], "--", label="Linear Fit")
    plt.plot(time_axis, np.ones_like(time_axis) * -60, "--", label="-60 dB")
    plt.vlines(rt60, energy_db_min, 0, linestyles="dashed", label="Estimated RT60")

    if rt60_tgt is not None:
        plt.vlines(rt60_tgt, energy_db_min, 0, label="Target RT60")

    plt.legend()


def measure_rt60(  # noqa: PLR0913 (Public API; keep signature compatibility)
    h: ArrayLike,
    fs: float | int = 1,
    decay_db: float | int = 60,
    energy_thres: float = 1.0,
    plot: bool = False,
    rt60_tgt: float | None = None,
) -> tuple[float, float, float, float, int]:
    """RT60 Measurement Routine (taken/modified from Pyroomacoustics).

    Calculates reverberation time of an impulse response using the Schroeder
    method [1].

    References:
        [1] M. R. Schroeder, "New Method of Measuring Reverberation Time,"
            J. Acoust. Soc. Am., vol. 37, no. 3, pp. 409-412, Mar. 1968.

    Args:
        h: The impulse response.
        fs: The sampling frequency of h (default to 1, i.e., samples).
        decay_db: The decay in decibels for which we actually estimate the
            slope and time. Although we want to estimate the RT60, it might
            not be practical. Instead, we measure the RT10, RT20 or RT30
            and extrapolate to RT60.
        energy_thres: This should be a value between 0.0 and 1.0. If provided,
            the fit will be done using a fraction energy_thres of the whole
            energy. This is useful when there is a long noisy tail for example.
        plot: If set to True, the power decay and different estimated values
            will be plotted.
        rt60_tgt: This parameter can be used to indicate a target RT60 to which
            we want to compare the estimated value.

    Returns:
        tuple[float, float, float, float, int]: A tuple containing:
            - rt60: Reverberation time to -60dB (-5dB to -65dB).
            - edt: Early decay time from 0dB to -10dB.
            - rt10: Reverberation time to -10dB (-5dB to -15dB).
            - rt20: Reverberation time to -20dB (-5dB to -25dB).
            - floor: Noise floor status:
                - 0: noise floor > -10dB or energy curve is not a decay.
                - 1: noise floor > -15dB, edt measured, rt10 estimated.
                - 2: noise -15dB > floor > -25dB, rt20 estimated from rt10.
                - 3: noise -25dB > floor > -65dB, rt60 estimated from rt20.
                - 4: noise floor < -65dB, all measured.

    """
    power, energy, energy_db, fs = _normalize_energy_curve(h, fs, energy_thres)

    min_energy_db = -np.min(energy_db)
    if min_energy_db - 5 < decay_db:
        decay_db = min_energy_db

    # -5 dB headroom
    i_5db = _find_decay_index(energy_db, -5)
    if i_5db is None:
        floor = 0
        return 0.0, 0.0, 0.0, 0.0, floor  # failed, energy curve is not a decay, or has noise floor tail above -5db
    e_5db = energy_db[i_5db]

    # Estimate slope from 0db to -10db - this is also known as EDT (early decay time)
    i_10db = _find_decay_index(energy_db, -10)
    if i_10db is None:
        floor = 0
        return 0.0, 0.0, 0.0, 0.0, floor  # failed, energy curve is not a decay, or noise floor tail above -10db
    edt = i_10db / fs  # this is also known as EDT (early decay time)

    rt60, rt10, rt20, floor = _compute_rt_metrics(energy_db, fs, i_5db)

    if plot:
        _plot_rt60(energy, power, energy_db, fs, i_5db, e_5db, rt60, rt60_tgt)

    return rt60, edt, rt10, rt20, floor


def process_path(path: str, extensions: list[str] | None = None) -> tuple[list, str | None]:
    """Check path which can be a single file, a subdirectory, or a brace-glob.

    Args:
        path: File, directory, or brace-glob pattern.
        extensions: List of matching extensions (e.g. ['.wav', '.mp3']).

    Returns:
        tuple[list, str | None]: A tuple containing:
            - A list of matching files.
            - The base directory of the path.

    """
    if extensions is None:
        extensions = [".wav", ".WAV", ".flac", ".FLAC", ".mp3", ".aac"]

    path_obj = Path(path)

    # Check if the path is a single file, and return it as a list with the dirname
    if path_obj.is_file():
        if any(path_obj.name.endswith(ext) for ext in extensions):
            basedir = str(path_obj.parent)  # base directory
            if basedir == ".":
                basedir = "./"
            return [path], basedir

        return [], None

    # Check if the path is a dir, recursively find all files any of the specified extensions, return file list and dir
    if path_obj.is_dir():
        matching_files = [str(f) for ext in extensions for f in path_obj.rglob(f"*{ext}")]
        return matching_files, path

    # Process as a regex, return list of filenames and basedir
    apath = str(path_obj.resolve())  # join(abspath(path), "**", "*.{wav,flac,WAV}")
    matching_files = []
    for file in braced_iglob(pathname=apath, recursive=True):
        matching_files.append(file)

    if matching_files:
        basedir = commonprefix(matching_files)  # Find basedir
        return matching_files, basedir

    return [], None


def _process_ir(pfile: str, irtab_col: list, basedir: str) -> pd.DataFrame:
    """Process a single impulse response file and calculate metrics.

    Args:
        pfile: Path to the audio file.
        irtab_col: List of metric column names.
        basedir: Base directory for relative path calculation.

    Returns:
        pd.DataFrame: DataFrame with calculated metrics.

    """
    import pandas as pd  # noqa: PLC0415 (Heavy loading: ~197ms)

    # 1)  Read ir audio file, and calc basic stats
    ir_fname = pfile[1]  # abs_path
    irwav, sample_rate = pars.raw_read_audio(ir_fname)
    if irwav.ndim == 2:
        irwav = irwav[:, 0]  # Only first channel of multi-channel
    duration = len(irwav) / sample_rate
    srk = sample_rate / 1000
    ir_basename = str(Path(ir_fname).relative_to(basedir))

    # 2) Compute delay via autocorrelation (not working - always zero, use interpolated tdoa instead)

    # 3) Compute delay via max argument - find the peak
    peak_index = np.argmax(irwav)
    peak_value = irwav[peak_index]
    dmax = peak_index

    # 4) Calculate cross-correlation with white gaussian noise ref (ssame as pyrooma.tdoa() with interp=1)
    np.random.seed(42)
    wgn_ref = np.random.normal(0, 0.2, int(np.ceil(0.05 * sample_rate)))  # (mean,std_dev,length)
    wgn_conv = np.convolve(irwav, wgn_ref)
    wgn_corr = np.correlate(wgn_conv, wgn_ref, mode="full")  # Compute cross-correlation
    delay_index = np.argmax(np.abs(wgn_corr))  # Find the delay (need abs??, yes)
    dcc = delay_index - len(wgn_ref) + 1  # Adjust for the mode='full' shift
    # GCC with PHAT weighting known to be best, but does seem to mismatch dcc, dmax more frequently
    dtdoa = tdoa(wgn_conv, wgn_ref, interp=16, phat=True)
    gdccmax = np.max(np.abs(wgn_conv)) / np.max(np.abs(wgn_ref))  # gain of max value

    # 5) Calculate delay using group_delay method
    fft_size = len(irwav)
    H = np.fft.fft(irwav, n=fft_size)  # noqa: N806  # Math notation: FFT of IR
    phase = np.unwrap(np.angle(H))
    freq = np.fft.fftfreq(fft_size)  # in samples, using d=1/sampling_rate=1
    group_delay = -np.gradient(phase) / (2 * np.pi * np.gradient(freq))
    dagd = np.mean(group_delay[np.isfinite(group_delay)])  # Average group delay
    gmax = max(np.abs(H))

    rt60, _edt, _rt10, rt20, _nfloor = measure_rt60(irwav, sample_rate, plot=False)

    # 6) Tabulate metrics as single row in table of scalar metrics per mixture
    metr1 = [dmax, dcc, dtdoa, dagd, gdccmax, rt20, rt60, peak_value, min(irwav), gmax, duration, srk, ir_basename]
    return pd.DataFrame([metr1], columns=irtab_col, index=[pfile[0]])  # return tuple of dataframe


def _resolve_output_paths(pfiles: list[str], basedir: str) -> tuple[Path | None, Path]:
    """Resolve output file paths based on number of input files."""
    basedir_path = Path(basedir)
    if len(pfiles) == 1:
        fbase = Path(pfiles[0]).stem
        return None, basedir_path / f"{fbase}-irmetric.txt"
    return basedir_path / "ir_metric_list.csv", basedir_path / "ir_metric_summary.txt"


def _resolve_cpu_count(num_proc: str, num_cpu: int, cpu_percent: float) -> int | None:
    """Resolve worker count from CLI value and host capacity."""
    if num_proc == "auto":
        return int(num_cpu * (0.9 - cpu_percent / 100))
    if num_proc == "None":
        return None
    return min(max(int(num_proc), 1), num_cpu)


def _run_metric_table(
    pfiles: list[str],
    basedir: str,
    progress: object,
    use_cpu: int | None,
) -> tuple[pd.DataFrame, list[tuple[int, str]]]:
    """Process IR files and return sorted metrics table and indexed file list."""
    import pandas as pd  # noqa: PLC0415 (Heavy loading: ~197ms)

    irtab_col = [
        "dmax",
        "dcc",
        "dccphat",
        "dagd",
        "gdccmax",
        "rt20",
        "rt60",
        "max",
        "min",
        "gmax",
        "dur",
        "sr",
        "irfile",
    ]
    llfiles = list(zip(range(len(pfiles)), pfiles, strict=False))
    no_par = use_cpu is None or len(pfiles) == 1
    num_cpus = None if no_par else use_cpu

    all_metrics_tables = par_track(
        partial(_process_ir, irtab_col=irtab_col, basedir=basedir),
        llfiles,
        progress=progress,
        num_cpus=num_cpus,
        no_par=no_par,
    )
    all_metrics_tab = pd.concat(list(all_metrics_tables))
    return all_metrics_tab.sort_values(by=["irfile"]), llfiles


def _write_metric_outputs(  # noqa: PLR0913 (I/O helper with explicit output context)
    wlcsv_name: Path | None,
    txt_fname: Path,
    timestamp: str,
    ir_location: str,
    llfiles: list[tuple[int, str]],
    mtabsort: pd.DataFrame,
) -> None:
    """Write IR metric outputs to CSV (optional) and TXT summary."""
    import pandas as pd  # noqa: PLC0415 (Heavy loading: ~197ms)

    table_args = {"mode": "a", "encoding": "utf-8"}
    if wlcsv_name:
        pd.DataFrame([["Timestamp", timestamp]]).to_csv(wlcsv_name, header=False, index=False)
        pd.DataFrame([f"IR metric list for {ir_location}:"]).to_csv(wlcsv_name, mode="a", header=False, index=False)
        mtabsort.round(2).to_csv(wlcsv_name, **table_args)

    with Path(txt_fname).open("w") as f:
        print(f"Timestamp: {timestamp}", file=f)
        print(f"IR metrics stats over {len(llfiles)} files:", file=f)
        print(mtabsort.describe().round(3).T.to_string(float_format=lambda x: f"{x:.3f}", index=True), file=f)
        print(file=f)
        print(file=f)
        print([f"IR metric list for {ir_location}:"], file=f)
        print(mtabsort.round(3).to_string(), file=f)


def main() -> None:
    """Run the main entry point for calculating IR metrics."""
    args = docopt.docopt(trim_docstring(__doc__), version=sai_version, options_first=True)

    ir_location = args["IRLOC"]
    num_proc = args["--num_process"]

    # Check location, default ext are ['.wav', '.WAV', '.flac', '.FLAC', '.mp3', '.aac']
    pfiles, basedir = process_path(ir_location)
    pfiles = sorted(pfiles, key=lambda x: Path(x).name)

    if pfiles is None or len(pfiles) < 1:
        raise SystemExit(1)

    wlcsv_name, txt_fname = _resolve_output_paths(pfiles, basedir)

    num_cpu = psutil.cpu_count()
    cpu_percent = psutil.cpu_percent(interval=1)
    use_cpu = _resolve_cpu_count(num_proc, num_cpu, cpu_percent)

    timestamp = create_timestamp()
    progress = track(total=len(pfiles))
    mtabsort, llfiles = _run_metric_table(pfiles, basedir, progress, use_cpu)
    progress.close()

    _write_metric_outputs(wlcsv_name, txt_fname, timestamp, ir_location, llfiles, mtabsort)


if __name__ == "__main__":
    from sonusai import exception_handler
    from sonusai.utils.keyboard_interrupt import register_keyboard_interrupt

    register_keyboard_interrupt()
    try:
        main()
    except Exception as e:  # noqa: BLE001 (Global CLI exception handler)
        exception_handler(e)
