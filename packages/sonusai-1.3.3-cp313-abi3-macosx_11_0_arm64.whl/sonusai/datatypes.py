"""Common data structures and type definitions for SonusAI."""

from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field
from typing import TYPE_CHECKING
from typing import Any
from typing import NamedTuple
from typing import SupportsIndex

import numpy as np
import numpy.typing as npt
from dataclasses_json import DataClassJsonMixin
from praatio.utilities.constants import Interval

from sonusai.constants import SAMPLE_RATE

if TYPE_CHECKING:
    from collections.abc import Iterable

AudioT = npt.NDArray[np.float32]

Truth = Any
TruthDict = dict[str, Truth]
TruthsDict = dict[str, "TruthsDict"]
Segsnr = npt.NDArray[np.float32]

AudioF = npt.NDArray[np.complex64]

EnergyT = npt.NDArray[np.float32]
EnergyF = npt.NDArray[np.float32]

Feature = npt.NDArray[np.float32]

Predict = npt.NDArray[np.float32]

# JSON type defined to maintain compatibility with DataClassJsonMixin
Json = dict | list | str | int | float | bool | None


class DataClassSonusAIMixin(DataClassJsonMixin):
    """Mixin to provide SonusAI-specific functionality to dataclasses."""

    def __str__(self) -> str:
        """Return a string representation of the object."""
        return f"{self.to_dict()}"

    # Override DataClassJsonMixin to remove dictionary keys with values of None
    def to_dict(self, encode_json: bool = False) -> dict[str, Json]:
        """Convert the dataclass to a dictionary, removing None values.

        Args:
            encode_json: If True, encode values as JSON.

        Returns:
            Dictionary representation of the dataclass.

        """

        def del_none(d: Json) -> Json:
            if isinstance(d, dict):
                for key, value in list(d.items()):
                    if value is None:
                        del d[key]
                    elif isinstance(value, dict):
                        del_none(value)
                    elif isinstance(value, list):
                        for item in value:
                            del_none(item)
            elif isinstance(d, list):
                for item in d:
                    del_none(item)
            return d

        return del_none(super().to_dict(encode_json))


@dataclass(frozen=True)
class TruthConfig(DataClassSonusAIMixin):
    """Configuration for a truth function."""

    function: str
    stride_reduction: str
    config: dict = field(default_factory=dict)

    def __hash__(self) -> int:
        """Hash representation of the configuration."""
        return hash(self.to_json())

    def __eq__(self, other: object) -> bool:
        """Compare two TruthConfig objects for equality."""
        return isinstance(other, TruthConfig) and hash(self) == hash(other)


TruthConfigs = dict[str, TruthConfig]
TruthsConfigs = dict[str, TruthConfigs]


NumberStr = float | int | str
OptionalNumberStr = NumberStr | None
OptionalListNumberStr = list[NumberStr] | None


EffectList = list[str]


@dataclass
class Effects(DataClassSonusAIMixin):
    """Pre and post-processing effects."""

    pre: EffectList = field(default_factory=EffectList)
    post: EffectList = field(default_factory=EffectList)


class UniversalSNRGenerator:
    """Generator for Signal-to-Noise Ratio (SNR) values.

    Supports static values, random directives, or sequences.
    """

    def __init__(self, raw_value: float | str) -> None:
        """Initialize the SNR generator.

        Args:
            raw_value: Input value or directive string.

        """
        from sonusai.parse.choose import parse_choose_expression
        from sonusai.parse.sequence import parse_sequence_expression

        self.is_random = False
        self._rand_obj = None

        if isinstance(raw_value, str) and raw_value.startswith("rand"):
            self.is_random = True
            self._rand_directive = str(raw_value)
        elif isinstance(raw_value, str) and raw_value.startswith("choose"):
            self._rand_obj = parse_choose_expression(raw_value)
        elif isinstance(raw_value, str) and raw_value.startswith("sequence"):
            self._rand_obj = parse_sequence_expression(raw_value)
        else:
            self._raw_value = float(raw_value)

    @property
    def value(self) -> float:
        """Get the next SNR value.

        Returns:
            The calculated or generated SNR value.

        """
        if self.is_random:
            from sonusai.parse.rand import rand

            return float(rand(self._rand_directive))

        if self._rand_obj:
            return float(self._rand_obj.next())

        return self._raw_value


class UniversalSNR(float):
    """A float subclass that tracks if the value was randomly generated."""

    def __new__(cls, value: float, is_random: bool = False) -> UniversalSNR:
        """Create a new UniversalSNR instance."""
        return float.__new__(cls, value)

    def __init__(self, value: float, is_random: bool = False) -> None:
        """Initialize the UniversalSNR instance.

        Args:
            value: The float value.
            is_random: Whether the value was randomly generated.

        """
        float.__init__(value)
        self._is_random = bool(is_random)

    @property
    def is_random(self) -> bool:
        """Whether the value was randomly generated."""
        return self._is_random


Speaker = dict[str, str]


@dataclass
class SourceFile(DataClassSonusAIMixin):
    """Metadata for a source audio file."""

    category: str
    class_indices: list[int]
    name: str
    samples: int
    truth_configs: TruthConfigs
    class_balancing_effect: EffectList | None = None
    id: int = -1
    level_type: str | None = None
    speaker_id: int | None = None

    @property
    def duration(self) -> float:
        """Get the duration of the source file in seconds.

        Returns:
            Duration in seconds.

        """
        return self.samples / SAMPLE_RATE


@dataclass
class EffectedFile(DataClassSonusAIMixin):
    """Mapping between a file and an effect."""

    file_id: int
    effect_id: int


type ClassCount = list[int]

type GeneralizedIDs = str | int | list[int] | range


@dataclass(frozen=True)
class SpectralMask(DataClassSonusAIMixin):
    """Parameters for spectral masking."""

    f_max_width: int
    f_num: int
    t_max_width: int
    t_num: int
    t_max_percent: int


@dataclass(frozen=True)
class TruthParameter(DataClassSonusAIMixin):
    """Parameters for a truth function."""

    category: str
    name: str
    parameters: int | None


@dataclass
class Source(DataClassSonusAIMixin):
    """A processed source in a mixture."""

    effects: Effects
    file_id: int
    pre_tempo: float = 1
    loop: bool = False
    snr: UniversalSNR = field(default_factory=lambda: UniversalSNR(0))
    snr_gain: float = 0
    start: int = 0


type Sources = dict[str, Source]
type SourcesAudioT = dict[str, AudioT]
type SourcesAudioF = dict[str, AudioF]


@dataclass
class Mixture(DataClassSonusAIMixin):
    """Metadata for an audio mixture."""

    name: str
    samples: int
    all_sources: Sources
    spectral_mask_id: int
    spectral_mask_seed: int

    @property
    def all_source_ids(self) -> dict[str, int]:
        """IDs of all sources in the mixture."""
        return {category: source.file_id for category, source in self.all_sources.items()}

    @property
    def sources(self) -> Sources:
        """All sources except noise."""
        return {category: source for category, source in self.all_sources.items() if category != "noise"}

    @property
    def source_ids(self) -> dict[str, int]:
        """IDs of sources except noise."""
        return {category: source.file_id for category, source in self.sources.items()}

    @property
    def noise(self) -> Source:
        """The noise source in the mixture."""
        return self.all_sources["noise"]

    @property
    def noise_id(self) -> int:
        """The ID of the noise source."""
        return self.noise.file_id

    @property
    def source_effects(self) -> dict[str, Effects]:
        """Effects applied to each source."""
        return {category: source.effects for category, source in self.sources.items()}

    @property
    def noise_effects(self) -> Effects:
        """Effects applied to the noise source."""
        return self.noise.effects

    @property
    def is_noise_only(self) -> bool:
        """Whether the mixture is effectively noise only."""
        return self.noise.snr < -96

    @property
    def is_source_only(self) -> bool:
        """Whether the mixture is effectively source only."""
        return self.noise.snr > 96


@dataclass(frozen=True)
class TransformConfig:
    """Configuration for a signal transform."""

    length: int
    overlap: int
    bin_start: int
    bin_end: int
    ttype: str


@dataclass(frozen=True)
class FeatureGeneratorConfig:
    """Configuration for a feature generator."""

    feature_mode: str
    truth_parameters: dict[str, dict[str, int | None]]


@dataclass(frozen=True)
class FeatureGeneratorInfo:
    """Detailed information about a feature generator."""

    decimation: int
    stride: int
    step: int
    feature_parameters: int
    ft_config: TransformConfig
    eft_config: TransformConfig
    it_config: TransformConfig


type ASRConfigs = dict[str, dict[str, Any]]


@dataclass
class GenMixData:
    """Data generated during mixture creation."""

    mixture: AudioT | None = None
    truth_t: TruthsDict | None = None
    segsnr_t: Segsnr | None = None
    sources: SourcesAudioT | None = None
    source: AudioT | None = None
    noise: AudioT | None = None


@dataclass
class GenFTData:
    """Data generated during feature transformation."""

    feature: Feature | None = None
    truth_f: TruthsDict | None = None
    segsnr: Segsnr | None = None


@dataclass
class ImpulseResponseData:
    """Impulse response audio data and metadata."""

    data: AudioT
    sample_rate: int
    delay: int


@dataclass
class ImpulseResponseFile(DataClassSonusAIMixin):
    """Metadata for an impulse response file."""

    name: str
    tags: list[str] = field(default_factory=list)
    delay: str | int = "auto"


@dataclass
class MixtureDatabaseConfig(DataClassSonusAIMixin):
    """Configuration for a mixture database."""

    asr_configs: ASRConfigs
    class_balancing: bool
    class_labels: list[str]
    class_weights_threshold: list[float]
    feature: str
    ir_files: list[ImpulseResponseFile]
    mixtures: list[Mixture]
    num_classes: int
    source_files: dict[str, list[SourceFile]]
    spectral_masks: list[SpectralMask]


type SpeechMetadata = str | list[Interval] | None


class SnrFMetrics(NamedTuple):
    """SNR metrics."""

    avg: float | None = None
    std: float | None = None
    db_avg: float | None = None
    db_std: float | None = None


class SnrFBinMetrics(NamedTuple):
    """SNR metrics per frequency bin."""

    avg: np.ndarray | None = None
    std: np.ndarray | None = None
    db_avg: np.ndarray | None = None
    db_std: np.ndarray | None = None


class SpeechMetrics(NamedTuple):
    """Composite speech quality metrics (CSIG, CBAK, COVL)."""

    csig: float | None = None
    cbak: float | None = None
    covl: float | None = None


class AudioStatsMetrics(NamedTuple):
    """Statistical metrics for audio signals."""

    dco: float | None = None
    min: float | None = None
    max: float | None = None
    pkdb: float | None = None
    lrms: float | None = None
    pkr: float | None = None
    tr: float | None = None
    cr: float | None = None
    fl: float | None = None
    pkc: float | None = None


@dataclass
class MetricDoc:
    """Documentation for a metric."""

    category: str
    name: str
    description: str


class MetricDocs(list[MetricDoc]):
    """A collection of metric documentations."""

    def __init__(self, __iterable: Iterable[MetricDoc]) -> None:
        """Initialize the collection.

        Args:
            __iterable: An iterable of MetricDoc objects.

        """
        super().__init__(item for item in __iterable)

    def __setitem__(self, __key: SupportsIndex, __value: MetricDoc) -> None:  # type: ignore[override]
        """Set a MetricDoc at the specified index."""
        super().__setitem__(__key, __value)

    def insert(self, __index: SupportsIndex, __object: MetricDoc) -> None:
        """Insert a MetricDoc at the specified index."""
        super().insert(__index, __object)

    def append(self, __object: MetricDoc) -> None:
        """Append a MetricDoc to the collection."""
        super().append(__object)

    def extend(self, __iterable: Iterable[MetricDoc]) -> None:
        """Extend the collection with MetricDoc objects."""
        if isinstance(__iterable, type(self)):
            super().extend(__iterable)
        else:
            super().extend(item for item in __iterable)

    @property
    def pretty(self) -> str:
        """A pretty-printed string representation of the documentation."""
        max_category_len = ((max([len(item.category) for item in self]) + 9) // 10) * 10
        max_name_len = 2 + ((max([len(item.name) for item in self]) + 1) // 2) * 2
        categories: list[str] = []
        for item in self:
            if item.category not in categories:
                categories.append(item.category)

        result = ""
        for category in categories:
            result += f"{category}\n"
            result += "-" * max_category_len + "\n"
            for item in [sub for sub in self if sub.category == category]:
                result += f"  {item.name:<{max_name_len}}{item.description}\n"
            result += "\n"

        return result

    @property
    def names(self) -> set[str]:
        """A set of all metric names in the collection."""
        return {item.name for item in self}
