"""Create mixture data from a SonusAI mixture database.

Usage:
    genmix [-hvtsn] [-i MIXID] LOC

Options:
    -h, --help
    -v, --verbose               Be verbose.
    -i MIXID, --mixid MIXID     Mixture ID(s) to generate. [default: *].
    -t, --truth                 Save truth_t. [default: False].
    -s, --segsnr                Save segsnr_t. [default: False].
    -n, --nopar                 Do not run in parallel. [default: False].

Inputs:
    LOC         A SonusAI mixture database directory.
    MIXID       A glob of mixture ID(s) to generate.

Outputs the following to the mixture database directory:
    <id>/
        metadata.txt
        sources.pkl
        source.pkl
        noise.pkl
        mixture.pkl
        truth_t.pkl (optional)
        segsnr_t.pkl (optional)
    genmix.log
"""

import time
from dataclasses import dataclass
from functools import partial
from pathlib import Path

from docopt import docopt

from sonusai import __version__ as sai_version
from sonusai import create_file_handler
from sonusai import exception_handler
from sonusai import initial_log_messages
from sonusai import logger
from sonusai import update_console_handler
from sonusai.constants import SAMPLE_RATE
from sonusai.datatypes import GeneralizedIDs
from sonusai.datatypes import GenMixData
from sonusai.mixture import MixtureDatabase
from sonusai.mixture.helpers import check_audio_files_exist
from sonusai.mixture.helpers import write_mixture_metadata
from sonusai.utils.docstring import trim_docstring
from sonusai.utils.human_readable_size import human_readable_size
from sonusai.utils.keyboard_interrupt import register_keyboard_interrupt
from sonusai.utils.parallel import par_track
from sonusai.utils.parallel import track
from sonusai.utils.seconds_to_hms import seconds_to_hms


@dataclass(frozen=True)
class GenMixOptions:
    """Runtime options for mixture generation."""

    compute_truth: bool = False
    compute_segsnr: bool = False
    cache: bool = False
    show_progress: bool = False
    force: bool = True


def genmix(
    location: str | Path,
    mixids: GeneralizedIDs = "*",
    options: GenMixOptions | None = None,
    no_par: bool = False,
) -> list[GenMixData]:
    """Generate mixtures for specified IDs.

    Args:
        location: Path to the mixture database.
        mixids: IDs of mixtures to generate.
        options: Runtime generation options.
        no_par: If True, do not use parallel processing.

    Returns:
        A list of GenMixData objects containing the generated mixture data.

    """
    effective_options = options or GenMixOptions()
    mixdb = MixtureDatabase(location)
    mixids = mixdb.mixids_to_list(mixids)
    progress = track(total=len(mixids), disable=not effective_options.show_progress)
    results = par_track(
        partial(
            _genmix_kernel,
            mixdb=mixdb,
            options=effective_options,
        ),
        mixids,
        progress=progress,
        no_par=no_par,
    )
    progress.close()

    return results


def _genmix_kernel(
    m_id: int,
    mixdb: MixtureDatabase,
    options: GenMixOptions,
) -> GenMixData:
    """Kernel function for generating a single mixture.

    Args:
        m_id: Mixture ID to process.
        mixdb: MixtureDatabase instance.
        options: Runtime generation options.

    Returns:
        A GenMixData object containing the generated data.

    """
    result = GenMixData()
    result.sources = mixdb.mixture_sources(m_id=m_id, force=options.force, cache=options.cache)
    result.source = mixdb.mixture_source(
        m_id=m_id,
        sources=result.sources,
        force=options.force,
        cache=options.cache,
    )
    result.noise = mixdb.mixture_noise(
        m_id=m_id,
        sources=result.sources,
        force=options.force,
        cache=options.cache,
    )
    result.mixture = mixdb.mixture_mixture(
        m_id=m_id,
        sources=result.sources,
        source=result.source,
        noise=result.noise,
        force=options.force,
        cache=options.cache,
    )

    if options.compute_truth:
        result.truth_t = mixdb.mixture_truth_t(m_id=m_id, force=options.force, cache=options.cache)

    if options.compute_segsnr:
        result.segsnr_t = mixdb.mixture_segsnr_t(
            m_id=m_id,
            sources=result.sources,
            source=result.source,
            noise=result.noise,
            force=options.force,
            cache=options.cache,
        )

    if options.cache:
        write_mixture_metadata(mixdb, m_id=m_id)

    return result


def main() -> None:
    """Execute the genmix CLI."""
    args = docopt(trim_docstring(__doc__), version=sai_version, options_first=True)

    verbose = args["--verbose"]
    location = args["LOC"]
    mixids = args["--mixid"]
    compute_truth = args["--truth"]
    compute_segsnr = args["--segsnr"]
    no_par = args["--nopar"]

    start_time = time.monotonic()

    create_file_handler(str(Path(location) / "genmix.log"), verbose)
    update_console_handler(verbose)
    initial_log_messages("genmix")

    logger.info(f"Load mixture database from {location}")
    mixdb = MixtureDatabase(location)
    mixids = mixdb.mixids_to_list(mixids)

    total_samples = mixdb.total_samples(mixids)
    duration = total_samples / SAMPLE_RATE

    logger.info("")
    logger.info(f"Found {len(mixids):,} mixtures to process")
    logger.info(f"{total_samples:,} samples")

    check_audio_files_exist(mixdb)

    genmix(
        location=location,
        mixids=mixids,
        options=GenMixOptions(
            compute_truth=compute_truth, compute_segsnr=compute_segsnr, cache=True, show_progress=True
        ),
        no_par=no_par,
    )

    logger.info(f"Wrote {len(mixids)} mixtures to {location}")
    logger.info("")
    logger.info(f"Duration: {seconds_to_hms(seconds=duration)}")
    logger.info(f"mixture:  {human_readable_size(total_samples * 2, 1)}")
    if compute_truth:
        logger.info(f"truth_t:  {human_readable_size(total_samples * mixdb.num_classes * 4, 1)}")
    logger.info(f"target:   {human_readable_size(total_samples * 2, 1)}")
    logger.info(f"noise:    {human_readable_size(total_samples * 2, 1)}")
    if compute_segsnr:
        logger.info(f"segsnr:   {human_readable_size(total_samples * 4, 1)}")

    end_time = time.monotonic()
    logger.info(f"Completed in {seconds_to_hms(seconds=end_time - start_time)}")
    logger.info("")


if __name__ == "__main__":
    from sonusai import exception_handler
    from sonusai.utils.keyboard_interrupt import register_keyboard_interrupt

    register_keyboard_interrupt()
    try:
        main()
    except Exception as e:  # noqa: BLE001 (Global CLI exception handler)
        exception_handler(e)
