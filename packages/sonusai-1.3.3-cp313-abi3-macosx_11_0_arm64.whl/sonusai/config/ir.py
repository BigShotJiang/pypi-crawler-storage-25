"""Impulse response configuration and processing."""

from itertools import chain
from pathlib import Path

from sonusai.datatypes import ImpulseResponseFile
from sonusai.mixture.audio import validate_input_file
from sonusai.utils.parallel import par_track
from sonusai.utils.parallel import track
from sonusai.utils.tokenized_shell_vars import tokenized_expand
from sonusai.utils.tokenized_shell_vars import tokenized_replace

from .config import load_yaml
from .ir_delay import get_ir_delay


def resolve_ir_entry_paths(name: str) -> tuple[list[Path], dict[str, str]]:
    """Resolve impulse response entry paths.

    Args:
        name: Name or glob pattern of the impulse response files.

    Returns:
        A tuple containing the list of resolved paths and the new tokens.

    Raises:
        OSError: If no paths are found.

    """
    in_name, new_tokens = tokenized_expand(name)
    names = (
        sorted(Path().glob(in_name))
        if not Path(in_name).is_absolute()
        else sorted(Path(Path(in_name).anchor).glob(str(Path(in_name).relative_to(Path(in_name).anchor))))
    )
    if not names:
        msg = f"Could not find {in_name}. Make sure path exists"
        raise OSError(msg)
    return names, new_tokens


def _iter_ir_text_references(path: object) -> list[str]:
    refs: list[str] = []
    with path.open() as txt_file:
        for line in txt_file:
            file_str = line.partition("#")[0].rstrip()
            if file_str:
                expanded, _ = tokenized_expand(file_str)
                refs.append(expanded)
    return refs


def _append_plain_ir_file(path: object, entry: ImpulseResponseFile, tokens: dict) -> list[ImpulseResponseFile]:
    validate_input_file(str(path))
    return [ImpulseResponseFile(tokenized_replace(str(path), tokens), entry.tags, entry.delay)]


def _append_ir_path(path: object, entry: ImpulseResponseFile, tokens: dict) -> list[ImpulseResponseFile]:
    dir_name = path.parent
    if path.is_dir():
        ir_files: list[ImpulseResponseFile] = []
        for child_path in path.iterdir():
            child_file = child_path if child_path.is_absolute() else dir_name / child_path
            child = ImpulseResponseFile(str(child_file), entry.tags, entry.delay)
            ir_files.extend(append_ir_files(entry=child, tokens=tokens))
        return ir_files

    ext = path.suffix.lower()
    if ext == ".txt":
        ir_files = []
        for ref in _iter_ir_text_references(path):
            child_file = Path(ref)
            if not child_file.is_absolute():
                child_file = dir_name / child_file
            child = ImpulseResponseFile(str(child_file), entry.tags, entry.delay)
            ir_files.extend(append_ir_files(entry=child, tokens=tokens))
        return ir_files

    if ext == ".yml":
        yml_config = load_yaml(str(path))
        if "impulse_responses" not in yml_config:
            return []
        return [
            ir_file
            for record in yml_config["impulse_responses"]
            for ir_file in append_ir_files(entry=record, tokens=tokens)
        ]

    return _append_plain_ir_file(path, entry, tokens)


def get_ir_files(config: dict, show_progress: bool = False, no_par: bool = False) -> list[ImpulseResponseFile]:
    """Get the list of impulse response files from a config.

    Args:
        config: Config dictionary.
        show_progress: Show progress bar.
        no_par: If True, execute delay calculation sequentially instead of in parallel.

    Returns:
        List of impulse response files.

    """
    ir_files = list(
        chain.from_iterable(
            [
                append_ir_files(
                    entry=ImpulseResponseFile(
                        name=entry["name"],
                        tags=entry.get("tags", []),
                        delay=entry.get("delay", "auto"),
                    )
                )
                for entry in config["impulse_responses"]
            ]
        )
    )

    if len(ir_files) == 0:
        return []

    progress = track(total=len(ir_files), disable=not show_progress)
    ir_files = par_track(_get_ir_delay, ir_files, progress=progress, no_par=no_par)
    progress.close()

    return ir_files


def append_ir_files(entry: ImpulseResponseFile, tokens: dict | None = None) -> list[ImpulseResponseFile]:
    """Process impulse response files list and append as needed.

    Args:
        entry: Impulse response file entry to append to the list.
        tokens: Tokens used for variable expansion.

    Returns:
        List of impulse response files.

    Raises:
        OSError: If a file or path cannot be found or processed.

    """
    if tokens is None:
        tokens = {}

    names, new_tokens = resolve_ir_entry_paths(entry.name)
    tokens.update(new_tokens)

    ir_files: list[ImpulseResponseFile] = []
    for path in names:
        try:
            ir_files.extend(_append_ir_path(path, entry, tokens))
        except Exception as e:
            msg = f"Error processing {path}: {e}"
            raise OSError(msg) from e

    return ir_files


def _get_ir_delay(entry: ImpulseResponseFile) -> ImpulseResponseFile:
    """Calculate or parse the delay for an impulse response file.

    Args:
        entry: Impulse response file entry.

    Returns:
        The entry with the delay field populated.

    Raises:
        ValueError: If the delay value is invalid.

    """
    if entry.delay == "auto":
        entry.delay = get_ir_delay(entry.name)
    else:
        try:
            entry.delay = int(entry.delay)
        except ValueError as e:
            msg = f"Invalid impulse response delay: {entry.delay}"
            raise ValueError(msg) from e

    return entry
