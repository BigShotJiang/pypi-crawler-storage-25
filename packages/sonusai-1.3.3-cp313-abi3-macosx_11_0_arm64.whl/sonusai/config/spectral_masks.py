"""Spectral mask configuration and processing."""

from sonusai.datatypes import SpectralMask
from sonusai.utils.dataclass_from_dict import list_dataclass_from_dict


def get_spectral_masks(config: dict) -> list[SpectralMask]:
    """Get the list of spectral masks from a config.

    Args:
        config: Config dictionary.

    Returns:
        List of spectral masks.

    Raises:
        ValueError: If there's an error in the spectral masks configuration.

    """
    try:
        return list_dataclass_from_dict(list[SpectralMask], config["spectral_masks"])
    except Exception as e:
        msg = f"Error in spectral_masks: {e}"
        raise ValueError(msg) from e
