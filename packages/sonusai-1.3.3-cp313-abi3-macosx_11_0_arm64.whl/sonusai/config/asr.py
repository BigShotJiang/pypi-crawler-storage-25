"""ASR configuration validation functions."""

from sonusai.utils.asr import validate_asr

from .constants import REQUIRED_ASR_CONFIGS_FIELDS


def validate_asr_configs(given: dict) -> None:
    """Validate fields in 'asr_config' in the given config.

    Args:
        given: The dictionary of the given config.

    Raises:
        AttributeError: If a required field is missing.

    """
    if "asr_configs" not in given:
        msg = "config is missing required 'asr_configs'"
        raise AttributeError(msg)

    asr_configs = given["asr_configs"]

    for name, asr_config in asr_configs.items():
        for key in REQUIRED_ASR_CONFIGS_FIELDS:
            if key not in asr_config:
                msg = f"'{name}' in asr_configs is missing required '{key}'"
                raise AttributeError(msg)

        engine = asr_config["engine"]
        config = {x: asr_config[x] for x in asr_config if x != "engine"}
        validate_asr(engine, **config)
