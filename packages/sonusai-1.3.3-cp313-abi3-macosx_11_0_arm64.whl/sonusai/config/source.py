"""Source configuration and processing."""

from __future__ import annotations

from copy import deepcopy
from itertools import chain
from pathlib import Path

from sonusai.config.constants import REQUIRED_NON_PRIMARY_SOURCE_CONFIG_FIELDS
from sonusai.config.constants import REQUIRED_SOURCE_CONFIG_FIELDS
from sonusai.config.constants import REQUIRED_SOURCES_CATEGORIES
from sonusai.config.constants import REQUIRED_TRUTH_CONFIG_FIELDS
from sonusai.config.constants import VALID_NON_PRIMARY_SOURCE_CONFIG_FIELDS
from sonusai.config.constants import VALID_PRIMARY_SOURCE_CONFIG_FIELDS
from sonusai.datatypes import SourceFile
from sonusai.datatypes import TruthConfig
from sonusai.mixture.audio import get_num_samples
from sonusai.mixture.audio import validate_input_file
from sonusai.utils.dataclass_from_dict import dataclass_from_dict
from sonusai.utils.parallel import par_track
from sonusai.utils.parallel import track
from sonusai.utils.tokenized_shell_vars import tokenized_expand
from sonusai.utils.tokenized_shell_vars import tokenized_replace


def _validate_required_categories(sources: dict, required_categories: list[str]) -> None:
    for category in required_categories:
        if category not in sources:
            msg = f"config sources is missing required '{category}'"
            raise AttributeError(msg)


def _validate_source_config_fields(
    category: str,
    source: dict,
    constants: dict,
) -> None:
    for key in constants["required_fields"]:
        if key not in source:
            msg = f"config source '{category}' is missing required '{key}'"
            raise AttributeError(msg)

    if category == "primary":
        _validate_known_source_fields(category, source, constants["valid_primary_fields"], "sources")
        return

    for key in constants["required_non_primary_fields"]:
        if key not in source:
            msg = f"config source '{category}' is missing required '{key}'"
            raise AttributeError(msg)

    _validate_known_source_fields(category, source, constants["valid_non_primary_fields"], "source")


def _validate_known_source_fields(category: str, source: dict, valid_fields: list[str], label: str) -> None:
    for key in source:
        if key not in valid_fields:
            nice_list = "\n".join([f"  {item}" for item in valid_fields])
            msg = f"Invalid source '{category}' config parameter: '{key}'.\nValid {label} config parameters are:\n{nice_list}"
            raise AttributeError(msg)


def _validate_files_parameter(category: str, files: list | str, sources: dict) -> None:
    if isinstance(files, str) and files in sources and files != category:
        return

    if isinstance(files, list):
        return

    msg = f"'file' parameter of config source '{category}' is not a list or a reference to another source"
    raise TypeError(msg)


def _resolve_source_file_references(given: dict) -> None:
    sources = given["sources"]
    count = 0
    while any(isinstance(source["files"], str) for source in sources.values()) and count < 100:
        count += 1
        for category, source in sources.items():
            files = source["files"]
            if isinstance(files, str):
                given["sources"][category]["files"] = sources[files]["files"]

    if count == 100:
        msg = "Check config sources for circular references"
        raise RuntimeError(msg)


def update_sources(given: dict) -> dict:
    """Validate and update fields in given 'sources'.

    Args:
        given: The dictionary of the given config.

    Returns:
        The updated config dictionary.

    Raises:
        AttributeError: If required fields are missing or invalid.
        TypeError: If 'files' parameter is not a list or a string reference.
        RuntimeError: If circular references are detected in sources.

    """
    sources = given["sources"]

    _validate_required_categories(sources, REQUIRED_SOURCES_CATEGORIES)
    constants = {
        "required_fields": REQUIRED_SOURCE_CONFIG_FIELDS,
        "required_non_primary_fields": REQUIRED_NON_PRIMARY_SOURCE_CONFIG_FIELDS,
        "valid_primary_fields": VALID_PRIMARY_SOURCE_CONFIG_FIELDS,
        "valid_non_primary_fields": VALID_NON_PRIMARY_SOURCE_CONFIG_FIELDS,
    }

    for category, source in sources.items():
        _validate_source_config_fields(category, source, constants)
        _validate_files_parameter(category, source["files"], sources)

    _resolve_source_file_references(given)

    return given


def get_source_files(config: dict, show_progress: bool = False, no_par: bool = False) -> list[SourceFile]:
    """Get the list of source files from a config.

    Args:
        config: Config dictionary.
        show_progress: Show progress bar.
        no_par: Execute sample counting sequentially instead of in parallel.

    Returns:
        List of source files.

    Raises:
        TypeError: If 'sources' is not a dictionary.
        AttributeError: If 'primary' is missing in 'sources'.
        ValueError: If class indices are invalid.

    """
    sources = config["sources"]
    if not isinstance(sources, dict) and not all(isinstance(source, dict) for source in sources):
        msg = "'sources' must be a dictionary of dictionaries"
        raise TypeError(msg)

    if "primary" not in sources:
        msg = "'primary' is missing in 'sources'"
        raise AttributeError(msg)

    class_indices = config["class_indices"]
    if not isinstance(class_indices, list):
        class_indices = [class_indices]

    level_type = config["level_type"]

    source_files: list[SourceFile] = []
    for category in sources:
        context = {
            "class_indices": class_indices,
            "truth_configs": sources[category].get("truth_configs", {}),
            "level_type": level_type,
        }
        source_files.extend(
            chain.from_iterable(
                [
                    append_source_files(
                        category=category,
                        entry=entry,
                        context=context,
                    )
                    for entry in sources[category]["files"]
                ]
            )
        )

    progress = track(total=len(source_files), disable=not show_progress)
    source_files = par_track(_get_num_samples, source_files, progress=progress, no_par=no_par)
    progress.close()

    num_classes = config["num_classes"]
    for source_file in source_files:
        if any(class_index < 0 for class_index in source_file.class_indices):
            msg = "class indices must contain only positive elements"
            raise ValueError(msg)

        if any(class_index > num_classes for class_index in source_file.class_indices):
            msg = f"class index elements must not be greater than {num_classes}"
            raise ValueError(msg)

    return source_files


def _as_class_indices(indices: int | list[int]) -> list[int]:
    if isinstance(indices, list):
        return indices
    return [indices]


def _merge_truth_configs(base_truth_configs: dict, entry: dict) -> dict:
    truth_configs_merged = deepcopy(base_truth_configs)
    truth_configs_override = entry.get("truth_configs", {})
    for key in truth_configs_override:
        if key not in base_truth_configs:
            msg = f"Truth config '{key}' override specified for {entry['name']} is not defined at top level"
            raise AttributeError(msg)
        truth_configs_merged[key] |= truth_configs_override[key]

    return truth_configs_merged


def resolve_entry_paths(in_name: str) -> tuple[list[Path], dict[str, str]]:
    """Resolve entry paths for source files.

    Args:
        in_name: Name or glob pattern of the source files.

    Returns:
        A tuple containing the list of resolved paths and the new tokens.

    Raises:
        OSError: If no paths are found.

    """
    expanded_name, new_tokens = tokenized_expand(in_name)
    names = (
        sorted(Path().glob(expanded_name))
        if not Path(expanded_name).is_absolute()
        else sorted(
            Path(Path(expanded_name).anchor).glob(str(Path(expanded_name).relative_to(Path(expanded_name).anchor)))
        )
    )
    if not names:
        msg = f"Could not find {expanded_name}. Make sure path exists"
        raise OSError(msg)
    return names, new_tokens


def _iter_text_references(path: object) -> list[str]:
    children: list[str] = []
    with path.open() as txt_file:
        for line in txt_file:
            child_str = line.partition("#")[0].rstrip()
            if child_str:
                expanded, _ = tokenized_expand(child_str)
                children.append(expanded)
    return children


def _build_source_file(
    category: str,
    path: str,
    context: dict,
    validate_path: str | None = None,
) -> SourceFile:
    validate_input_file(validate_path or path)
    source_file = SourceFile(
        category=category,
        name=str(path),
        samples=0,
        class_indices=context["class_indices"],
        level_type=context["level_type"],
        truth_configs={},
    )
    truth_configs_merged = context["truth_configs"]
    if len(truth_configs_merged) == 0:
        return source_file

    for tc_key, tc_value in truth_configs_merged.items():
        config = deepcopy(tc_value)
        truth_config: dict = {}
        for key in REQUIRED_TRUTH_CONFIG_FIELDS:
            truth_config[key] = config[key]
            del config[key]
        truth_config["config"] = config
        source_file.truth_configs[tc_key] = dataclass_from_dict(TruthConfig, truth_config)

    for tc_key in source_file.truth_configs:
        if "function" in truth_configs_merged[tc_key] and truth_configs_merged[tc_key]["function"] == "file":
            truth_configs_merged[tc_key]["file"] = str(Path(source_file.name).with_suffix(".h5"))

    return source_file


def _normalize_tokens_for_path_replacement(tokens: dict) -> dict:
    normalized: dict = {}
    for token, value in tokens.items():
        if isinstance(value, str) and len(value) > 1:
            normalized[token] = value.rstrip("/")
        else:
            normalized[token] = value
    return normalized


def _process_source_path(
    path: object,
    category: str,
    context: dict,
    tokens: dict,
) -> list[SourceFile]:
    dir_name = path.parent
    if path.is_dir():
        source_files: list[SourceFile] = []
        for child in path.iterdir():
            child_path = child if child.is_absolute() else dir_name / child
            source_files.extend(
                append_source_files(
                    category=category,
                    entry={"name": str(child_path)},
                    context={
                        "class_indices": context["class_indices"],
                        "truth_configs": context["truth_configs"],
                        "level_type": context["level_type"],
                    },
                    tokens=tokens,
                )
            )
        return source_files

    if path.suffix.lower() == ".txt":
        source_files = []
        for child_str in _iter_text_references(path):
            child_path = Path(child_str)
            if not child_path.is_absolute():
                child_path = dir_name / child_path
            source_files.extend(
                append_source_files(
                    category=category,
                    entry={"name": str(child_path)},
                    context={
                        "class_indices": context["class_indices"],
                        "truth_configs": context["truth_configs"],
                        "level_type": context["level_type"],
                    },
                    tokens=tokens,
                )
            )
        return source_files

    source_file = _build_source_file(
        category=category,
        path=tokenized_replace(str(path), _normalize_tokens_for_path_replacement(tokens)),
        context=context,
        validate_path=str(path),
    )
    return [source_file]


def append_source_files(category: str, entry: dict, context: dict, tokens: dict | None = None) -> list[SourceFile]:
    """Process source files list and append as needed.

    Args:
        category: Source file category name.
        entry: Source file entry to append to the list.
        context: Source processing context.
        tokens: Tokens used for variable expansion.

    Returns:
        List of source files.

    Raises:
        TypeError: If 'entry' is not a dictionary.
        KeyError: If entry is missing 'name'.
        AttributeError: If truth config override is invalid.
        OSError: If path doesn't exist or file processing fails.

    """
    if tokens is None:
        tokens = {}

    if not isinstance(entry, dict):
        msg = "'entry' must be a dictionary"
        raise TypeError(msg)

    in_name = entry.get("name")
    if in_name is None:
        msg = "Source file list contained record without name"
        raise KeyError(msg)

    class_indices = _as_class_indices(entry.get("class_indices", context["class_indices"]))
    truth_configs_merged = _merge_truth_configs(context["truth_configs"], entry)
    level_type = entry.get("level_type", context["level_type"])

    names, new_tokens = resolve_entry_paths(in_name)
    tokens.update(new_tokens)

    source_files: list[SourceFile] = []
    for path in names:
        try:
            source_files.extend(
                _process_source_path(
                    path,
                    category,
                    {
                        "class_indices": class_indices,
                        "truth_configs": truth_configs_merged,
                        "level_type": level_type,
                    },
                    tokens,
                )
            )
        except Exception as e:
            msg = f"Error processing {path}: {e}"
            raise OSError(msg) from e

    return source_files


def _get_num_samples(entry: SourceFile) -> SourceFile:
    """Get the number of samples for a source file.

    Args:
        entry: Source file entry.

    Returns:
        The entry with the samples field populated.

    """
    entry.samples = get_num_samples(entry.name)
    return entry
