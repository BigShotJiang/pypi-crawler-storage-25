"""Configuration loading and management utilities."""

from copy import deepcopy
from functools import lru_cache
from pathlib import Path

import yaml

from sonusai.config.asr import validate_asr_configs
from sonusai.config.source import update_sources
from sonusai.config.truth import validate_truth_configs

from .constants import DEFAULT_CONFIG


def load_yaml(name: str | Path) -> dict:
    """Load YAML file.

    Args:
        name: File name.

    Returns:
        Dictionary of config data.

    """
    return yaml.safe_load(Path(name).read_text())


@lru_cache
def default_config() -> dict:
    """Load default SonusAI config.

    Returns:
        Dictionary of default config data.

    """
    try:
        return load_yaml(DEFAULT_CONFIG)
    except Exception as e:
        msg = f"Error loading default config: {e}"
        raise OSError(msg) from e


def _update_config_from_file(filename: str | Path, given_config: dict) -> dict:
    """Update the given config with the config in the specified YAML file.

    Args:
        filename: File name.
        given_config: Config dictionary to update.

    Returns:
        Updated config dictionary.

    Raises:
        OSError: If there's an error when loading the config file.

    """
    updated_config = deepcopy(given_config)

    try:
        file_config = load_yaml(filename)
    except Exception as e:
        msg = f"Error loading config from {filename}: {e}"
        raise OSError(msg) from e

    # Use default config as base and overwrite with given config keys as found
    if file_config:
        updated_config.update(file_config)

    return updated_config


def load_config(name: str | Path, validate_asr: bool = True) -> dict:
    """Load the default config and update with the given location.

    Performs SonusAI variable substitution.

    Args:
        name: Directory containing a mixture database.
        validate_asr: Validate ASR configuration.

    Returns:
        Dictionary of config data.

    """
    path = Path(name) / "config.yml"
    config = _update_config_from_file(filename=path, given_config=default_config())
    config = update_sources(config)

    if validate_asr:
        validate_asr_configs(config)

    validate_truth_configs(config)
    return config
