"""Show SonusAI documentation.

Usage:
    doc [-h] [TOPIC]

Options:
    -h, --help
"""

from docopt import docopt
from rich.console import Console

from sonusai import __version__ as sai_version
from sonusai import doc_strings
from sonusai import exception_handler
from sonusai.utils.docstring import trim_docstring
from sonusai.utils.keyboard_interrupt import register_keyboard_interrupt


def main() -> None:
    """Execute the doc CLI."""
    console = Console()
    args = docopt(trim_docstring(__doc__), version=sai_version, options_first=True)

    topic = args["TOPIC"]

    topics = sorted(
        [item[4:] for item in dir(doc_strings) if item.startswith("doc_") and callable(getattr(doc_strings, item))]
    )

    if topic not in topics:
        if topic is not None:
            console.print(f"Unknown topic: {topic}")
        console.print("Available topics:")
        for _item in topics:
            console.print(f"  {_item}")
        return

    console.print(getattr(doc_strings, "doc_" + topic)())


if __name__ == "__main__":
    register_keyboard_interrupt()
    try:
        main()
    except Exception as e:  # noqa: BLE001 (Global CLI exception handler)
        exception_handler(e)
