"""Phase timing helpers used for performance instrumentation."""

import json
import time
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass
from dataclasses import field
from pathlib import Path

import numpy as np


@dataclass
class PhaseData:
    """Timing state for a single named stage."""

    start_time: float
    end_time: float | None = None
    op_durations: list[float] = field(default_factory=list)


class PhaseTimer:
    """Collect and summarize stage-level operation timings."""

    def __init__(self) -> None:
        """Initialize an empty stage map."""
        self.phases: dict[str, PhaseData] = {}

    @contextmanager
    def measure(self, stage_name: str) -> Generator[None]:
        """Context manager that records one operation duration for a stage."""
        if stage_name not in self.phases:
            self.phases[stage_name] = PhaseData(start_time=time.monotonic())

        start = time.monotonic()
        yield
        end = time.monotonic()

        self.phases[stage_name].end_time = end
        self.phases[stage_name].op_durations.append(end - start)

    def get_phase_summary(self, stage_name: str) -> dict[str, float | int | str]:
        """Return aggregate timing summary for a stage."""
        data = self.phases.get(stage_name)
        if not data:
            return {}

        durations = np.array(data.op_durations)
        n = len(durations)
        if n == 0:
            return {"stage_name": stage_name, "duration_seconds": 0.0}

        total_duration = sum(durations)
        avg = np.mean(durations)
        p95 = np.percentile(durations, 95) if n > 1 else avg

        return {
            "stage_name": stage_name,
            "duration_seconds": total_duration,
            "op_count": n,
            "avg_per_op": avg,
            "p95_per_op": p95,
        }

    def save(self, path: str) -> None:
        """Persist all stage summaries as JSON."""
        summary = [self.get_phase_summary(name) for name in self.phases]
        with Path(path).open("w") as f:
            json.dump(summary, f, indent=4)
