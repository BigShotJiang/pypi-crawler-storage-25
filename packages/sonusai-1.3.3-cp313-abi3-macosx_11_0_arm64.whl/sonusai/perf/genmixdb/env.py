"""Environment capture utilities for GenMixDB perf runs."""

import platform
import subprocess
import sys
from datetime import UTC
from datetime import datetime

from sonusai.perf.genmixdb.schemas import RunMetadata


def get_git_sha() -> str:
    """Return current repository commit SHA, or `unknown` on failure."""
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"]).decode("utf-8").strip()
    except subprocess.CalledProcessError:
        return "unknown"


def get_rust_version() -> str:
    """Return installed Rust compiler version, or `unknown` on failure."""
    try:
        return subprocess.check_output(["rustc", "--version"]).decode("utf-8").strip()
    except subprocess.CalledProcessError:
        return "unknown"


def capture_env() -> RunMetadata:
    """Capture environment metadata for benchmark manifests."""
    return RunMetadata(
        git_sha=get_git_sha(),
        python_version=sys.version.split()[0],
        rust_version=get_rust_version(),
        host_arch=platform.machine(),
        storage_class_tag="local",  # Defaulting to local as per scope
        timestamp=datetime.now(tz=UTC).isoformat(),
    )
