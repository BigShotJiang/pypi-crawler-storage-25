"""Benchmark matrix construction for GenMixDB performance runs."""

import json

from sonusai.perf.genmixdb.env import capture_env


def generate_matrix_json(configs: list[str], repeats: int, modes: list[str] | None = None) -> str:
    """Build matrix payload JSON for configured benchmark repetitions."""
    if modes is None:
        modes = ["serial_no_par", "default_parallel"]

    metadata = capture_env()
    entries: list[dict[str, str | int]] = []
    for config in configs:
        for mode in modes:
            command = f"sonusai genmixdb -n {config}" if mode == "serial_no_par" else f"sonusai genmixdb {config}"
            entries.extend(
                {
                    "command": command,
                    "config_path": config,
                    "repeat_index": i,
                    "parallel_mode": mode,
                }
                for i in range(repeats)
            )

    payload = {"metadata": metadata.to_dict(), "entries": entries}
    return json.dumps(payload, indent=2)
