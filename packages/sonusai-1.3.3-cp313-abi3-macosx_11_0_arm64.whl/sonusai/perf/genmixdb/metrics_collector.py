"""Resource and DB metric extraction for GenMixDB perf runs."""

import re
import sqlite3
from pathlib import Path


def collect_resources(command_stderr: str) -> dict[str, float]:
    """Collect resource usage using /usr/bin/time -l output string."""
    output = command_stderr

    metrics = {"wall_clock_seconds": 0.0, "cpu_user_seconds": 0.0, "cpu_system_seconds": 0.0, "peak_rss_kb": 0.0}

    # Regex patterns for time -l output on macOS
    real_match = re.search(r"real\s+(\d+\.\d+)", output)
    if real_match:
        metrics["wall_clock_seconds"] = float(real_match.group(1))

    user_match = re.search(r"user\s+(\d+\.\d+)", output)
    if user_match:
        metrics["cpu_user_seconds"] = float(user_match.group(1))

    sys_match = re.search(r"sys\s+(\d+\.\d+)", output)
    if sys_match:
        metrics["cpu_system_seconds"] = float(sys_match.group(1))

    rss_match = re.search(r"(\d+)\s+maximum resident set size", output)
    if rss_match:
        metrics["peak_rss_kb"] = float(rss_match.group(1))

    return metrics


def probe_db(location: str) -> dict[str, int | dict[str, int]]:
    """Probe DB for size and key row counts."""
    db_path = Path(location) / "mixdb.db"

    # Size in bytes
    size = db_path.stat().st_size if db_path.exists() else 0

    row_counts = {}
    if db_path.exists():
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            for table in tables:
                cursor.execute(f"SELECT count(*) FROM {table}")
                row_counts[table] = cursor.fetchone()[0]
            conn.close()
        except sqlite3.Error:
            pass

    return {"file_size_bytes": size, "row_counts": row_counts}
