"""A/B test runner utilities for GenMixDB performance comparisons."""

import json
import math
from pathlib import Path
from typing import Any

import numpy as np
from scipy import stats

from sonusai.perf.genmixdb.runner import execute_run


class ABTestRunner:
    """Execute and analyze baseline vs candidate performance runs."""

    def __init__(self, baseline_command: str, candidate_command: str, artifact_base_dir: str) -> None:
        """Initialize the A/B runner with command variants and artifact destination."""
        self.baseline_command = baseline_command
        self.candidate_command = candidate_command
        self.artifact_dir = Path(artifact_base_dir) / "ab_test"
        self.artifact_dir.mkdir(parents=True, exist_ok=True)

    def run_tests(self, repeats: int = 5) -> dict[str, Any]:
        """Run repeated baseline/candidate executions and return significance analysis."""
        baseline_records = []
        candidate_records = []

        # Run Baseline
        for i in range(repeats):
            manifest = execute_run(self.baseline_command, str(self.artifact_dir), i)
            if manifest.success:
                with (self.artifact_dir / f"{manifest.run_id}.json").open() as f:
                    data = json.load(f)
                    metrics = data.get("metrics", {})
                    wall_clock = metrics.get("wall_clock_seconds")
                    if wall_clock is None:
                        continue
                    baseline_records.append(
                        {
                            "index": i,
                            "run_id": manifest.run_id,
                            "wall_clock_seconds": float(wall_clock),
                            "artifact": f"{manifest.run_id}.json",
                        }
                    )

        # Run Candidate
        for i in range(repeats):
            manifest = execute_run(self.candidate_command, str(self.artifact_dir), i + repeats)  # offset index
            if manifest.success:
                with (self.artifact_dir / f"{manifest.run_id}.json").open() as f:
                    data = json.load(f)
                    metrics = data.get("metrics", {})
                    wall_clock = metrics.get("wall_clock_seconds")
                    if wall_clock is None:
                        continue
                    candidate_records.append(
                        {
                            "index": i,
                            "run_id": manifest.run_id,
                            "wall_clock_seconds": float(wall_clock),
                            "artifact": f"{manifest.run_id}.json",
                        }
                    )

        analysis = self.analyze(baseline_records, candidate_records)
        report_path = self.artifact_dir / "ab_comparison.json"
        with report_path.open("w") as f:
            json.dump(analysis, f, indent=4)
        return analysis

    def analyze(
        self,
        baseline: list[float] | list[dict[str, Any]],
        candidate: list[float] | list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Analyze two performance samples using Welch's t-test and effect size."""
        baseline_records = self._normalize_records(baseline, "baseline")
        candidate_records = self._normalize_records(candidate, "candidate")
        aligned_records = self._align_records(baseline_records, candidate_records)

        if len(aligned_records) < 2:
            return {
                "error": "Insufficient data for significance testing",
                "record_alignment": {
                    "paired_count": len(aligned_records),
                    "expected_pairs": min(len(baseline_records), len(candidate_records)),
                    "paired_records": aligned_records,
                },
            }

        baseline_values = [record["baseline"]["wall_clock_seconds"] for record in aligned_records]
        candidate_values = [record["candidate"]["wall_clock_seconds"] for record in aligned_records]

        # Perform Welch's t-test
        t_stat, p_value = stats.ttest_ind(baseline_values, candidate_values, equal_var=False)

        b_mean = float(np.mean(baseline_values))
        c_mean = float(np.mean(candidate_values))
        effect_size = (c_mean - b_mean) / b_mean  # Percentage improvement
        paired_deltas = [
            candidate_value - baseline_value
            for baseline_value, candidate_value in zip(baseline_values, candidate_values)
        ]
        ci_low, ci_high = self._bootstrap_mean_ci(paired_deltas)
        mann_whitney = stats.mannwhitneyu(baseline_values, candidate_values, alternative="two-sided")

        acceptance_gates = {
            "min_aligned_pairs": len(aligned_records) >= 2,
            "p_value_lt_0_05": float(p_value) < 0.05,
            "effect_size_improves": float(effect_size) < 0.0,
            "ci_excludes_zero": ci_high < 0.0,
        }

        recommendation = "NEUTRAL"
        if acceptance_gates["p_value_lt_0_05"]:
            recommendation = "PROMOTE" if effect_size < 0 else "REJECT"

        if recommendation == "PROMOTE":
            rationale = "Promotion recommended: all acceptance gates passed and candidate is faster than baseline."
        elif recommendation == "REJECT":
            rationale = "Promotion rejected: significant difference found but candidate is slower than baseline."
        else:
            failed_gates = [name for name, passed in acceptance_gates.items() if not passed]
            rationale = (
                "No promotion decision: acceptance gates not fully met. "
                f"Failed gates: {', '.join(failed_gates) if failed_gates else 'none'}."
            )

        return {
            "baseline_mean": b_mean,
            "candidate_mean": c_mean,
            "p_value": float(p_value),
            "effect_size": float(effect_size),
            "t_statistic": float(t_stat),
            "mann_whitney_p_value": float(mann_whitney.pvalue),
            "bootstrap_delta_ci": {
                "lower": ci_low,
                "upper": ci_high,
                "confidence": 0.95,
            },
            "record_alignment": {
                "paired_count": len(aligned_records),
                "expected_pairs": min(len(baseline_records), len(candidate_records)),
                "paired_records": aligned_records,
            },
            "acceptance_gates": acceptance_gates,
            "recommendation": recommendation,
            "promotion_rationale": rationale,
        }

    @staticmethod
    def _normalize_records(
        values: list[float] | list[dict[str, Any]],
        variant: str,
    ) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        for index, entry in enumerate(values):
            if isinstance(entry, dict):
                wall_clock = entry.get("wall_clock_seconds")
                if wall_clock is None:
                    continue
                record = {
                    "index": int(entry.get("index", index)),
                    "run_id": str(entry.get("run_id", f"{variant}_{index}")),
                    "wall_clock_seconds": float(wall_clock),
                    "artifact": str(entry.get("artifact", "")),
                }
            else:
                record = {
                    "index": index,
                    "run_id": f"{variant}_{index}",
                    "wall_clock_seconds": float(entry),
                    "artifact": "",
                }
            records.append(record)

        return sorted(records, key=lambda record: (record["index"], record["run_id"]))

    @staticmethod
    def _align_records(
        baseline_records: list[dict[str, Any]],
        candidate_records: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        pair_count = min(len(baseline_records), len(candidate_records))
        aligned = []
        for index in range(pair_count):
            baseline_record = baseline_records[index]
            candidate_record = candidate_records[index]
            aligned.append(
                {
                    "pair_index": index,
                    "baseline": baseline_record,
                    "candidate": candidate_record,
                }
            )
        return aligned

    @staticmethod
    def _bootstrap_mean_ci(values: list[float], confidence: float = 0.95, samples: int = 2000) -> tuple[float, float]:
        if not values:
            return (0.0, 0.0)
        if len(values) == 1:
            value = float(values[0])
            return (value, value)

        rng = np.random.default_rng(0)
        data = np.array(values, dtype=float)
        bootstrap_means = np.empty(samples, dtype=float)
        for sample_index in range(samples):
            sampled = rng.choice(data, size=data.size, replace=True)
            bootstrap_means[sample_index] = float(np.mean(sampled))

        alpha = 1.0 - confidence
        lower = float(np.quantile(bootstrap_means, alpha / 2.0))
        upper = float(np.quantile(bootstrap_means, 1.0 - (alpha / 2.0)))

        if math.isnan(lower) or math.isnan(upper):
            return (0.0, 0.0)
        return (lower, upper)
