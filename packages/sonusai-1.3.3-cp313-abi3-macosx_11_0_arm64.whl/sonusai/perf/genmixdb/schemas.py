"""Dataclasses describing GenMixDB performance artifacts."""

from dataclasses import dataclass

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class RunMetadata:
    """Static environment metadata captured for each run batch."""

    git_sha: str
    python_version: str
    rust_version: str
    host_arch: str
    storage_class_tag: str
    timestamp: str


@dataclass_json
@dataclass
class RuntimeMetrics:
    """Runtime resource metrics parsed from command execution."""

    wall_clock_seconds: float
    cpu_user_seconds: float
    cpu_system_seconds: float
    peak_rss_kb: int
    io_ops_read: int | None = None
    io_ops_write: int | None = None


@dataclass_json
@dataclass
class PhaseTiming:
    """Per-stage timing summary for instrumented operations."""

    stage_name: str
    duration_seconds: float
    op_count: int | None = None
    avg_per_op: float | None = None
    p95_per_op: float | None = None


@dataclass_json
@dataclass
class ProfileManifest:
    """Profiling artifact references for one run."""

    run_id: str
    flamegraph_path: str | None = None
    pstats_path: str | None = None
    speedscope_path: str | None = None
    tops_path: str | None = None
    scalene_json_path: str | None = None
    scalene_html_path: str | None = None


@dataclass_json
@dataclass
class RunManifest:
    """Core execution result metadata for a benchmark run."""

    run_id: str
    command: str
    start_time: str
    end_time: str
    exit_code: int
    success: bool
    parallel_mode: str | None = None
