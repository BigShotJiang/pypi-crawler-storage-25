"""Profiling helpers for GenMixDB benchmark runs."""

import os
import platform
import shlex
import subprocess
from pathlib import Path

from sonusai.perf.genmixdb.schemas import ProfileManifest

SCALENE_TIMEOUT_SECONDS = 900


def _build_scalene_program_args(command: str) -> list[str]:
    """Build Scalene `run` program/args payload for supported command shapes."""
    command_parts = shlex.split(command)
    if not command_parts:
        return []

    # sonusai genmixdb <location> -> scalene run sonusai/main.py --- genmixdb <location>
    if len(command_parts) >= 2 and command_parts[0] == "sonusai":
        main_py = Path(__file__).resolve().parents[2] / "main.py"
        cli_args = command_parts[1:]
        return [str(main_py), "---", *cli_args]

    # python -m sonusai.main genmixdb <location> -> scalene run sonusai/main.py --- genmixdb <location>
    if len(command_parts) >= 4 and command_parts[:3] == ["python", "-m", "sonusai.main"]:
        main_py = Path(__file__).resolve().parents[2] / "main.py"
        cli_args = command_parts[3:]
        return [str(main_py), "---", *cli_args]

    # python script.py ... -> scalene run script.py --- ...
    if len(command_parts) >= 2 and command_parts[0] == "python" and command_parts[1].endswith(".py"):
        return [command_parts[1], "---", *command_parts[2:]]

    return command_parts


def _build_profiler_error(
    profiler_name: str,
    result: subprocess.CompletedProcess[str],
    command: list[str],
) -> subprocess.CalledProcessError:
    stderr = (result.stderr or "").strip() or "<streamed-live-not-captured>"
    stdout = (result.stdout or "").strip() or "<streamed-live-not-captured>"
    hint = ""
    if profiler_name == "py-spy":
        hint = (
            " hint: this often indicates py-spy permission/SIP restrictions on macOS, "
            "or that the target command failed under profiler startup."
        )

    message = (
        f"{profiler_name} profiling failed (exit_code={result.returncode})"
        f"; command={' '.join(command)}"
        f"; stderr={stderr or '<empty>'}"
        f"; stdout={stdout or '<empty>'}"
        f";{hint}"
    )
    return subprocess.CalledProcessError(result.returncode, command, output=result.stdout, stderr=message)


def _ensure_pyspy_supported_or_raise(command: list[str]) -> None:
    """Raise a profiler-shaped error when py-spy is unsupported in this runtime."""
    if platform.system() != "Darwin":
        return

    geteuid = getattr(os, "geteuid", None)
    if geteuid is None or geteuid() == 0:
        return

    result = subprocess.CompletedProcess(
        args=command,
        returncode=1,
        stdout="",
        stderr="This program requires root on OSX.",
    )
    raise _build_profiler_error("py-spy", result, command)


def run_with_pyspy(command: str, artifact_dir: str, run_id: str, quiet: bool = False) -> ProfileManifest:
    """Execute a command under `py-spy` and capture speedscope artifacts."""
    artifact_path = Path(artifact_dir)
    speedscope_path = artifact_path / f"{run_id}_profile.speedscope.json"

    # py-spy record -o <output> -- <command>
    # Note: Assuming py-spy is in the path.
    # The command provided to this function is the full command string like "sonusai genmixdb ...".
    # We might need to split it or use shell=True. The runner used split().

    py_spy_cmd = [
        "py-spy",
        "record",
        "--format",
        "speedscope",
        "--subprocesses",
        "-o",
        str(speedscope_path),
        "--",
    ] + shlex.split(command)
    _ensure_pyspy_supported_or_raise(py_spy_cmd)
    run_kwargs = {"check": False}
    if quiet:
        run_kwargs.update({"capture_output": True, "text": True})
    result = subprocess.run(py_spy_cmd, **run_kwargs)
    if result.returncode != 0:
        raise _build_profiler_error("py-spy", result, py_spy_cmd)

    return ProfileManifest(
        run_id=run_id,
        speedscope_path=str(speedscope_path),
    )


def run_with_cprofile(command: str, artifact_dir: str, run_id: str, quiet: bool = False) -> ProfileManifest:
    """Execute the command under `cProfile` and emit statistics artifacts.

    Note: cProfile run via subprocess only profiles the parent process.
    Worker processes spawned by multiprocessing are not captured.
    For full parallel coverage, use py-spy with --subprocesses.
    """
    artifact_path = Path(artifact_dir)
    pstats_path = artifact_path / f"{run_id}_profile.stats"

    # python -m cProfile -o <output> sonusai/main.py genmixdb ...
    # This might be tricky because genmixdb is a CLI command inside sonusai.
    # If the command is "sonusai genmixdb ...", it's a CLI entry point.
    # Assuming 'python -m cProfile -o <output> -m sonusai.main genmixdb ...'

    # The command is "sonusai genmixdb ...".
    # If we assume 'sonusai' is the package, and 'genmixdb' is the command.
    # The actual entry point is likely 'python -m sonusai.main genmixdb ...'

    # Let's try to convert the command to a module execution
    # If command is 'sonusai genmixdb', we want 'python -m sonusai.main genmixdb'

    # But for now, let's keep it generic if possible or assume we are running the module.
    # Let's assume we can run 'python -m cProfile -o <output> <command_executable_or_script>'
    # This might not work directly with 'sonusai genmixdb'.

    # Maybe we can use 'cProfile' inside the Python code?
    # But the requirement says, "Add cProfile execution mode".

    # Let's use 'python -m cProfile -o' with the command, assuming the command is a script or module.
    # Actually, if we just prepend 'python -m cProfile -o <output>' to the command,
    # it assumes the command is a valid Python script execution.
    # "sonusai genmixdb" is probably installed as a CLI script, but we can call it via python -m sonusai.main

    # I'll implement a simple execution wrapper.

    # For now, let's just use subprocess with cProfile -m
    # We use -m sonusai.main as the entry point
    command_parts = shlex.split(command)
    cprofile_cmd = ["python", "-m", "cProfile", "-o", str(pstats_path), "-m", "sonusai.main"] + command_parts[1:]
    run_kwargs = {"check": False}
    if quiet:
        run_kwargs.update({"capture_output": True, "text": True})
    result = subprocess.run(cprofile_cmd, **run_kwargs)
    if result.returncode != 0:
        raise _build_profiler_error("cProfile", result, cprofile_cmd)

    # Generate human-readable pstats summary
    import pstats

    txt_path = artifact_path / f"{run_id}_profile.txt"
    p = pstats.Stats(str(pstats_path))
    with txt_path.open("w") as f:
        p.stream = f
        p.sort_stats("cumulative").print_stats()

    tops_path = artifact_path / f"{run_id}_tops.txt"
    p_tops = pstats.Stats(str(pstats_path))
    with tops_path.open("w") as f:
        p_tops.stream = f
        p_tops.sort_stats("cumulative").print_stats(30)

    return ProfileManifest(run_id=run_id, pstats_path=str(pstats_path), tops_path=str(tops_path))


def run_with_scalene(command: str, artifact_dir: str, run_id: str, quiet: bool = False) -> ProfileManifest:
    """Execute a command under `scalene` and capture JSON report.

    Scalene provides per-line Python vs. native vs. system CPU time and memory
    allocation data. Higher overhead than py-spy (~10-20%); intended for one
    representative run per config, not all repeats.
    """
    artifact_path = Path(artifact_dir)
    json_path = artifact_path / f"{run_id}_profile.scalene.json"

    scalene_cmd = [
        "scalene",
        "run",
        "--outfile",
        str(json_path),
    ] + _build_scalene_program_args(command)
    run_kwargs = {"check": False}
    if quiet:
        run_kwargs.update({"capture_output": True, "text": True})
    try:
        result = subprocess.run(scalene_cmd, timeout=SCALENE_TIMEOUT_SECONDS, **run_kwargs)
    except subprocess.TimeoutExpired as err:
        timeout_result = subprocess.CompletedProcess(
            args=scalene_cmd,
            returncode=124,
            stdout=err.stdout if isinstance(err.stdout, str) else "",
            stderr=f"scalene timed out after {SCALENE_TIMEOUT_SECONDS} seconds",
        )
        raise _build_profiler_error("scalene", timeout_result, scalene_cmd) from err
    if result.returncode != 0:
        raise _build_profiler_error("scalene", result, scalene_cmd)

    return ProfileManifest(run_id=run_id, scalene_json_path=str(json_path), scalene_html_path=None)
