"""Hotspot analysis and refactor backlog generation utilities."""

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class HotspotCandidate:
    """Candidate optimization hotspot scored by impact, breadth, and cost."""

    name: str
    description: str
    impact: float  # 0.0 - 1.0
    breadth: float  # 0.0 - 1.0
    risk: float  # 0.0 - 1.0 (lower is better, but maybe invert for score)
    effort: float  # 0.0 - 1.0 (lower is better, but maybe invert for score)
    explained_runtime_share: float = 0.0  # 0.0 - 1.0

    @property
    def score(self) -> float:
        """Compute weighted priority score for ranking."""
        # Weighted scoring: Impact 40%, Breadth 20%, Risk 20%, Effort 20%
        # Normalize Risk and Effort (invert them): 1.0 - value
        risk_score = 1.0 - self.risk
        effort_score = 1.0 - self.effort
        return (self.impact * 0.4) + (self.breadth * 0.2) + (risk_score * 0.2) + (effort_score * 0.2)


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def _extract_profile_entries(profile_data: dict[str, Any]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for key in ("top_functions", "functions", "top_stacks", "stacks"):
        values = profile_data.get(key, [])
        if isinstance(values, list):
            entries.extend(item for item in values if isinstance(item, dict))
    return entries


def _entry_name(entry: dict[str, Any]) -> str:
    return str(entry.get("function") or entry.get("name") or entry.get("label") or "unknown")


def _entry_share(entry: dict[str, Any], total_time: float) -> float:
    for key in ("share", "pct", "percentage"):
        value = entry.get(key)
        if isinstance(value, (float, int)):
            return _clamp(float(value) / 100.0 if float(value) > 1.0 else float(value))

    for key in ("cumulative_seconds", "total_seconds", "self_seconds", "time_seconds"):
        value = entry.get(key)
        if isinstance(value, (float, int)) and total_time > 0:
            return _clamp(float(value) / total_time)

    return 0.0


def _tokenize(value: str) -> set[str]:
    normalized = "".join(char.lower() if char.isalnum() else " " for char in value)
    return {part for part in normalized.split() if len(part) >= 3}


def _safe_float(value: object) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _frame_names_from_shared(shared: dict[str, Any]) -> list[str]:
    frames = shared.get("frames")
    if not isinstance(frames, list):
        return []
    return [str(frame.get("name") or "unknown") if isinstance(frame, dict) else "unknown" for frame in frames]


def _accumulate_speedscope_profile(
    profile: dict[str, Any],
    frame_names: list[str],
    cumulative_by_name: dict[str, float],
    self_by_name: dict[str, float],
) -> None:
    samples = profile.get("samples")
    weights = profile.get("weights")
    if not isinstance(samples, list) or not isinstance(weights, list):
        return

    for sample, weight in zip(samples, weights, strict=False):
        if not isinstance(sample, list):
            continue

        sample_weight = _safe_float(weight)
        if sample_weight is None:
            continue

        for frame_index in sample:
            if isinstance(frame_index, int) and 0 <= frame_index < len(frame_names):
                frame_name = frame_names[frame_index]
                cumulative_by_name[frame_name] = cumulative_by_name.get(frame_name, 0.0) + sample_weight

        if not sample:
            continue

        top_frame_index = sample[-1]
        if isinstance(top_frame_index, int) and 0 <= top_frame_index < len(frame_names):
            top_frame_name = frame_names[top_frame_index]
            self_by_name[top_frame_name] = self_by_name.get(top_frame_name, 0.0) + sample_weight


def _speedscope_entries(
    cumulative_by_name: dict[str, float],
    self_by_name: dict[str, float],
) -> list[dict[str, Any]]:
    entries = [
        {
            "function": function_name,
            "self_seconds": self_by_name.get(function_name, 0.0),
            "cumulative_seconds": cumulative_seconds,
        }
        for function_name, cumulative_seconds in cumulative_by_name.items()
    ]
    entries.sort(key=lambda entry: (-float(entry["cumulative_seconds"]), str(entry["function"])))
    return entries


def parse_speedscope(speedscope_path: str) -> list[dict[str, Any]]:
    """Parse a speedscope JSON file and extract per-function timing entries.

    Returns a list of dicts with keys: function, self_seconds, cumulative_seconds.
    Returns an empty list if the file is missing or malformed.

    """
    try:
        payload = json.loads(Path(speedscope_path).read_text())
        shared = payload.get("shared")
        profiles = payload.get("profiles")
        if not isinstance(shared, dict) or not isinstance(profiles, list):
            return []

        frame_names = _frame_names_from_shared(shared)
        if not frame_names:
            return []

        cumulative_by_name: dict[str, float] = {}
        self_by_name: dict[str, float] = {}

        for profile in profiles:
            if isinstance(profile, dict):
                _accumulate_speedscope_profile(profile, frame_names, cumulative_by_name, self_by_name)
        return _speedscope_entries(cumulative_by_name, self_by_name)
    except Exception:  # noqa: BLE001 (Malformed profiling payloads should not break analysis)
        return []


def parse_cprofile_tops(tops_path: str) -> list[dict[str, Any]]:
    """Parse a cProfile tops.txt file and extract top cumulative-time rows.

    Returns a list of dicts with keys: function, cumulative_seconds.
    Returns an empty list if the file is missing or malformed.

    """
    try:
        content = Path(tops_path).read_text()
        lines = content.splitlines()

        # Look for the header row: ncalls tottime percall cumtime percall filename:lineno(function)
        start_idx = -1
        for i, line in enumerate(lines):
            if "ncalls" in line and "cumtime" in line:
                start_idx = i + 1
                break

        if start_idx == -1:
            return []

        entries: list[dict[str, Any]] = []
        for line in lines[start_idx:]:
            if not line.strip():
                continue

            # Example:
            #    120    0.002    0.000   13.565    0.113 /path/to/file.py:244(refresh)
            parts = line.split()
            if len(parts) < 6:
                continue

            try:
                cum_time = float(parts[3])
                func_name = " ".join(parts[5:])
                entries.append({"function": func_name, "cumulative_seconds": cum_time})
            except (ValueError, IndexError):
                continue
    except Exception:  # noqa: BLE001
        return []
    else:
        return entries


def parse_scalene_json(scalene_path: str) -> list[dict[str, Any]]:
    """Parse a Scalene JSON file and extract per-function timing entries.

    Returns a list of dicts with keys: function, cumulative_seconds.
    Returns an empty list if the file is missing or malformed.

    """
    try:
        data = json.loads(Path(scalene_path).read_text())
        elapsed_time = float(data.get("elapsed_time_sec", 0.0))
        files = data.get("files", {})

        entries: list[dict[str, Any]] = []
        for filename, file_data in files.items():
            functions = file_data.get("functions", [])
            for func in functions:
                name = func.get("line") or "unknown"
                # Scalene provides percentages (0-100 or 0-1)
                cpu_python = float(func.get("n_cpu_percent_python", 0.0))
                cpu_c = float(func.get("n_cpu_percent_c", 0.0))
                total_cpu = cpu_python + cpu_c

                # If total_cpu is > 1.0, it's likely a percentage (0-100), normalize to 0-1
                share = total_cpu / 100.0 if total_cpu > 1.0 else total_cpu

                entries.append(
                    {
                        "function": f"{filename}:{name}",
                        "cumulative_seconds": share * elapsed_time,
                        "share": share,
                    }
                )

        entries.sort(key=lambda x: x.get("cumulative_seconds", 0.0), reverse=True)
    except Exception:  # noqa: BLE001
        return []
    else:
        return entries


def synthesize_hotspots(phase_timings: list[dict[str, Any]], profile_data: dict[str, Any]) -> list[HotspotCandidate]:
    """Synthesize ranked hotspot candidates from timing and profiling data."""
    candidates: list[HotspotCandidate] = []

    phase_total = sum(float(phase.get("duration_seconds", 0.0) or 0.0) for phase in phase_timings)
    profile_entries = _extract_profile_entries(profile_data)
    profile_total = sum(
        float(entry.get("cumulative_seconds", 0.0) or 0.0)
        for entry in profile_entries
        if isinstance(entry.get("cumulative_seconds", 0.0), (float, int))
    )

    ranked_profile = [(_entry_name(entry), _entry_share(entry, profile_total)) for entry in profile_entries]
    ranked_profile = [(name, share) for name, share in ranked_profile if share > 0]
    ranked_profile.sort(key=lambda item: (-item[1], item[0]))

    top_profile = ranked_profile[:5]
    phase_max_ops = (
        max(int(phase.get("op_count", 0) or 0) for phase in phase_timings if isinstance(phase.get("op_count", 0), int))
        if phase_timings
        else 0
    )

    for phase in phase_timings:
        stage_name = str(phase.get("stage_name") or "unknown")
        duration = float(phase.get("duration_seconds", 0.0) or 0.0)
        if duration <= 0:
            continue

        phase_share = _clamp(duration / phase_total) if phase_total > 0 else 0.0
        stage_tokens = _tokenize(stage_name)
        correlated = [(name, share) for name, share in top_profile if stage_tokens.intersection(_tokenize(name))]
        correlated.sort(key=lambda item: (-item[1], item[0]))
        explained_share = _clamp(phase_share + sum(share for _, share in correlated[:2]) * 0.3)

        op_count = int(phase.get("op_count", 0) or 0)
        breadth = _clamp(op_count / phase_max_ops) if phase_max_ops > 0 else 0.5
        impact = _clamp(max(phase_share, explained_share))
        risk = 0.35 if correlated else 0.45
        effort = _clamp(0.7 - (impact * 0.5))

        if correlated:
            correlation_note = ", ".join(f"{name} ({share * 100:.1f}%)" for name, share in correlated[:2])
            description = (
                f"{stage_name} accounts for {phase_share * 100:.1f}% phase runtime; "
                f"profile correlation: {correlation_note}."
            )
        else:
            description = (
                f"{stage_name} accounts for {phase_share * 100:.1f}% phase runtime with no direct profile match."
            )

        candidates.append(
            HotspotCandidate(
                name=f"Phase: {stage_name}",
                description=description,
                impact=impact,
                breadth=breadth,
                risk=risk,
                effort=effort,
                explained_runtime_share=explained_share,
            )
        )

    if not candidates:
        for function_name, share in top_profile[:3]:
            candidates.append(
                HotspotCandidate(
                    name=f"Profile: {function_name}",
                    description=f"{function_name} contributes {share * 100:.1f}% of sampled runtime.",
                    impact=share,
                    breadth=0.6,
                    risk=0.4,
                    effort=_clamp(0.65 - (share * 0.25)),
                    explained_runtime_share=share,
                )
            )

    candidates.sort(key=lambda candidate: (-candidate.score, -candidate.explained_runtime_share, candidate.name))
    return candidates


def generate_backlog_artifact(candidates: list[HotspotCandidate], evidence: dict[str, str] | None = None) -> str:
    """Generate markdown backlog output from ranked hotspot candidates."""
    evidence = evidence or {}
    run_count = evidence.get("run_count", "unknown")
    summary_path = evidence.get("summary_path", "summary.md")
    matrix_path = evidence.get("matrix_path", "matrix.json")
    db_sizes = evidence.get("db_sizes", "not captured")
    phase_sources = evidence.get("phase_sources", "none")
    profile_sources = evidence.get("profile_sources", "none")

    lines = ["# Ranked Refactor Backlog", ""]
    for i, c in enumerate(candidates[:3]):
        lines.append(f"## {i + 1}. {c.name}")
        lines.append(f"- **Description**: {c.description}")
        lines.append(f"- **Score**: {c.score:.2f}")
        lines.append(
            f"- **Hypothesis**: Optimize `{c.name}` to reduce p95 runtime while preserving output correctness."
        )
        lines.append(
            "- **Proof Point**: "
            f"Derived from {run_count} orchestrated run artifacts and ranking synthesis. "
            f"Baseline table: `{summary_path}`; matrix metadata: `{matrix_path}`; "
            f"phase evidence files: `{phase_sources}`; profile evidence files: `{profile_sources}`."
        )
        lines.append(
            f"- **Change Proposal**: Implement a small scoped optimization in `{c.name}` and benchmark via the same matrix."
        )
        lines.append("- **Gain Range**: Target 5-20% p95 improvement depending on candidate complexity.")
        lines.append(
            "- **Validation Plan**: Re-run orchestrator with identical config/repeats, compare p50/p95/CoV gates, "
            f"and confirm DB artifact stability ({db_sizes})."
        )
        lines.append("")
    return "\n".join(lines)
