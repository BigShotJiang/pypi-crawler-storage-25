"""Utilities for audio testing."""

from pathlib import Path

import numpy as np

from sonusai.mixture.audio import read_audio
from sonusai.utils.numeric_conversion import float32_to_int32


def generate_tone(
    freq: float, duration_sec: float, sr: int = 16000, amplitude: float = 0.5, as_int: bool = False
) -> np.ndarray:
    """Generate a deterministic sine tone."""
    t = np.linspace(0, duration_sec, int(sr * duration_sec), endpoint=False, dtype=np.float32)
    result = amplitude * np.sin(2 * np.pi * freq * t)
    if as_int:
        return float32_to_int32(result)
    return result


def generate_sweep(  # noqa: PLR0913
    f_start: float, f_end: float, duration_sec: float, sr: int = 16000, amplitude: float = 0.5, as_int: bool = False
) -> np.ndarray:
    """Generate a deterministic linear frequency sweep."""
    t = np.linspace(0, duration_sec, int(sr * duration_sec), endpoint=False, dtype=np.float32)
    # Phase is integral of frequency: f(t) = f_start + (f_end - f_start) * t / duration_sec
    # phase(t) = 2*pi * [f_start * t + 0.5 * (f_end - f_start) * t^2 / duration_sec]
    phase = 2 * np.pi * (f_start * t + 0.5 * (f_end - f_start) * (t**2) / duration_sec)
    result = amplitude * np.sin(phase).astype(np.float32)
    if as_int:
        return float32_to_int32(result)
    return result


def generate_white_noise(
    duration_sec: float, sr: int = 16000, amplitude: float = 0.1, seed: int = 42, as_int: bool = False
) -> np.ndarray:
    """Generate deterministic white noise."""
    rng = np.random.default_rng(seed)
    num_samples = int(sr * duration_sec)
    result = rng.uniform(-amplitude, amplitude, num_samples).astype(np.float32)
    if as_int:
        return float32_to_int32(result)
    return result


def generate_pink_noise(
    duration_sec: float, sr: int = 16000, amplitude: float = 0.1, seed: int = 42, as_int: bool = False
) -> np.ndarray:
    """Generate deterministic pink noise (1/f) using the Voss-McCartney algorithm."""
    # Simplified pink noise approx via filtering or summation
    # For TDD harness, we just need deterministic and roughly pinkish or complex noise.
    # Let's use a spectral approach for better quality.
    rng = np.random.default_rng(seed)
    num_samples = int(sr * duration_sec)
    white = rng.standard_normal(num_samples)
    spec = np.fft.rfft(white)
    frequencies = np.fft.rfftfreq(num_samples)
    frequencies[0] = 1  # avoid div by zero
    spec = spec / np.sqrt(frequencies)
    pink = np.fft.irfft(spec, n=num_samples)
    # Normalize to desired amplitude
    pink = amplitude * pink / np.max(np.abs(pink))
    result = pink.astype(np.float32)
    if as_int:
        return float32_to_int32(result)
    return result


def load_fixture_speech(name: str, as_int: bool = False) -> np.ndarray:
    """Load a speech fixture from tests/data/audio/fixtures/speech/."""
    path = Path("tests") / "data" / "audio" / "fixtures" / "speech" / f"{name}.wav"
    result = read_audio(path)
    if as_int:
        return float32_to_int32(result)
    return result


def generate_impulse(duration_sec: float, sr: int = 16000, amplitude: float = 1.0, as_int: bool = False) -> np.ndarray:
    """Generate an impulse (Dirac delta) at the first sample.

    Args:
        duration_sec: Duration in seconds.
        sr: Sample rate.
        amplitude: Amplitude (0 to 1).
        as_int: If True, returns int32 data.

    Returns:
        Impulse signal.

    """
    n_samples = int(duration_sec * sr)
    y = np.zeros(n_samples, dtype=np.float32)
    y[0] = amplitude
    if as_int:
        return float32_to_int32(y)
    return y


def load_golden_sox(effect_name: str, fixture_name: str) -> np.ndarray:
    """Load a .npy golden file from tests/data/audio/golden/sox14_4_2_f32/."""
    path = Path("tests") / "data" / "audio" / "golden" / "sox14_4_2_f32" / f"{effect_name}_{fixture_name}.npy"
    return np.load(path)


def load_golden_sox_i32(effect_name: str, fixture_name: str) -> np.ndarray:
    """Load a .npy golden file from tests/data/audio/golden/sox14_4_2_i32/."""
    path = Path("tests") / "data" / "audio" / "golden" / "sox14_4_2_i32" / f"{effect_name}_{fixture_name}.npy"
    return np.load(path)


def save_golden_sox(data: np.ndarray, effect_name: str, fixture_name: str) -> None:
    """Utility to save golden data during development (not for CI use)."""
    base_path = Path("tests") / "data" / "audio" / "golden" / "sox14_4_2_f32"
    base_path.mkdir(parents=True, exist_ok=True)
    path = base_path / f"{effect_name}_{fixture_name}.npy"
    np.save(path, data)


def calculate_snr(actual: np.ndarray, desired: np.ndarray) -> float:
    """Calculate Signal-to-Noise Ratio (SNR) in dB."""
    noise = actual - desired
    signal_power = np.mean(desired.astype(np.float32) ** 2)
    noise_power = np.mean(noise.astype(np.float32) ** 2)
    if noise_power == 0:
        return float("inf")
    return 10 * np.log10(signal_power / noise_power)


def calculate_max_abs(actual: np.ndarray, desired: np.ndarray) -> float:
    """Calculate max absolute error between actual and desired."""
    return float(np.max(np.abs(actual - desired)))


def assert_secondary_acceptance(
    actual: np.ndarray,
    desired: np.ndarray,
    snr_threshold_db: float,
    max_abs_threshold: float,
) -> None:
    """Verify secondary acceptance criteria: SNR and Max-Abs error."""
    snr = calculate_snr(actual, desired)
    max_abs = calculate_max_abs(actual, desired)
    assert snr >= snr_threshold_db, f"SNR {snr:.2f} dB < {snr_threshold_db} dB"
    assert max_abs <= max_abs_threshold, f"Max-Abs error {max_abs:.6f} > {max_abs_threshold}"
