"""Helper functions for tests."""

import numpy as np


def convert_integer_encoded_onehot(
    p_label: list[int], t_label: list[int], num_classes: int
) -> tuple[np.ndarray, np.ndarray]:
    """Convert integer-encoded labels to one-hot binary arrays.

    Args:
        p_label: Predicted labels as a list of integers.
        t_label: True labels as a list of integers.
        num_classes: Number of classes.

    Returns:
        A tuple containing (predicted_onehot, true_onehot).

    """
    # convert list of integers encoded (0:num_classes-1) labels to one-hot [frames, num_classes] binary
    # use for easy test vector creation via one-line Fx1 np.array
    # binary case is num_classes = 2, then remove first dim.
    frames = np.shape(p_label)[0]

    p_binary = np.zeros((frames, num_classes), dtype=np.int8)
    t_binary = np.zeros((frames, num_classes), dtype=np.int8)

    p_binary[np.arange(p_binary.shape[0]), p_label] = 1
    t_binary[np.arange(t_binary.shape[0]), t_label] = 1

    return p_binary, t_binary
