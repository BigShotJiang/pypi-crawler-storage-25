"""Rust core integration for SonusAI."""
