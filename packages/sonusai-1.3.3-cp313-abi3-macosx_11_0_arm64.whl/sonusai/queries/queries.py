"""Database query functions for filtering mixtures."""

from __future__ import annotations

from typing import TYPE_CHECKING

from sonusai.config.constants import REQUIRED_TRUTH_CONFIG_FIELDS

if TYPE_CHECKING:
    from collections.abc import Callable

    from sonusai.datatypes import GeneralizedIDs
    from sonusai.mixture.mixdb import MixtureDatabase

from typing import Any


def _true_predicate(_: object) -> bool:
    return True


def _iter_field_values(value: object) -> list[object]:
    if isinstance(value, dict):
        return list(value.values())
    return [value]


def _group_mixids_by_mixture_field(
    mixdb: MixtureDatabase,
    mixid_out: list[int],
    field: str,
    predicate: Callable[[Any], bool],
) -> dict[object, list[int]]:
    result: dict[object, list[int]] = {}
    for m_id in mixid_out:
        value = getattr(mixdb.mixture(m_id), field)
        for entry in _iter_field_values(value):
            if predicate(entry):
                result.setdefault(entry, []).append(m_id)
    return {criterion: sorted(set(mixids)) for criterion, mixids in sorted(result.items(), key=lambda item: item[0])}


def _collect_source_ids_for_truth_value(mixdb: MixtureDatabase, field: str, value: object) -> list[int]:
    indices = []
    for s_ids in mixdb.source_file_ids.values():
        for s_id in s_ids:
            source = mixdb.source_file(s_id)
            for truth_config in source.truth_configs.values():
                if field in REQUIRED_TRUTH_CONFIG_FIELDS:
                    if value in getattr(truth_config, field):
                        indices.append(s_id)
                elif value in getattr(truth_config.config, field):
                    indices.append(s_id)
    return sorted(set(indices))


def _collect_mixids_for_source_ids(mixdb: MixtureDatabase, mixid_out: list[int], source_ids: list[int]) -> list[int]:
    mixids = []
    for source_id in source_ids:
        mixids.extend(
            m_id
            for m_id in mixid_out
            if source_id in [source.file_id for source in mixdb.mixture(m_id).all_sources.values()]
        )
    return sorted(set(mixids))


def get_mixids_from_mixture_field_predicate(
    mixdb: MixtureDatabase,
    field: str,
    mixids: GeneralizedIDs = "*",
    predicate: Callable[[Any], bool] | None = None,
) -> dict[int, list[int]]:
    """Generate mixture IDs based on the mixture field and predicate.

    Returns a dictionary where:
        - keys are the matching field values
        - values are lists of the mixids that match the criteria
    """
    mixid_out = mixdb.mixids_to_list(mixids)

    if predicate is None:
        predicate = _true_predicate

    return _group_mixids_by_mixture_field(mixdb, mixid_out, field, predicate)


def get_mixids_from_truth_configs_field_predicate(
    mixdb: MixtureDatabase,
    field: str,
    mixids: GeneralizedIDs = "*",
    predicate: Callable[[Any], bool] | None = None,
) -> dict[int, list[int]]:
    """Generate mixture IDs based on the target truth_configs field and predicate.

    Returns a dictionary where:
        - keys are the matching field values
        - values are lists of the mixids that match the criteria
    """
    mixid_out = mixdb.mixids_to_list(mixids)

    # Get all field values
    values = get_all_truth_configs_values_from_field(mixdb, field)

    if predicate is None:
        predicate = _true_predicate

    # Get only values of interest
    values = [value for value in values if predicate(value)]

    result: dict[object, list[int]] = {}
    for value in values:
        indices = _collect_source_ids_for_truth_value(mixdb, field, value)
        value_mixids = _collect_mixids_for_source_ids(mixdb, mixid_out, indices)
        if value_mixids:
            result[value] = value_mixids

    return result


def get_all_truth_configs_values_from_field(mixdb: MixtureDatabase, field: str) -> list:
    """Generate a list of all values for the given field in truth_configs."""
    result = []
    for sources in mixdb.source_files.values():
        for source in sources:
            for truth_config in source.truth_configs.values():
                if field in REQUIRED_TRUTH_CONFIG_FIELDS:
                    value = getattr(truth_config, field)
                else:
                    value = getattr(truth_config.config, field, None)
                if not isinstance(value, list):
                    value = [value]
                result.extend(value)

    return sorted(set(result))


def get_mixids_from_noise(
    mixdb: MixtureDatabase,
    mixids: GeneralizedIDs = "*",
    predicate: Callable[[Any], bool] | None = None,
) -> dict[int, list[int]]:
    """Generate mixids based on noise index predicate.

    Returns a dictionary where:
        - keys are the noise indices
        - values are lists of the mixids that match the noise index
    """
    return get_mixids_from_mixture_field_predicate(mixdb=mixdb, mixids=mixids, field="noise_id", predicate=predicate)


def get_mixids_from_source(
    mixdb: MixtureDatabase,
    mixids: GeneralizedIDs = "*",
    predicate: Callable[[Any], bool] | None = None,
) -> dict[int, list[int]]:
    """Generate mixids based on a source index predicate.

    Returns a dictionary where:
        - keys are the source indices
        - values are lists of the mixids that match the source index
    """
    return get_mixids_from_mixture_field_predicate(mixdb=mixdb, mixids=mixids, field="source_ids", predicate=predicate)


def get_mixids_from_snr(
    mixdb: MixtureDatabase,
    mixids: GeneralizedIDs = "*",
    predicate: Callable[[Any], bool] | None = None,
) -> dict[float, list[int]]:
    """Generate mixids based on an SNR predicate.

    Returns a dictionary where:
        - keys are the SNRs
        - values are lists of the mixids that match the SNR
    """
    mixid_out = mixdb.mixids_to_list(mixids)

    # Get all the SNRs
    snrs = [float(snr) for snr in mixdb.all_snrs if not snr.is_random]

    if predicate is None:
        predicate = _true_predicate

    # Get only the SNRs of interest (filter on predicate)
    snrs = [snr for snr in snrs if predicate(snr)]

    result: dict[float, list[int]] = {}
    for snr in snrs:
        # Get a list of mixids for each SNR
        result[snr] = sorted(
            [i for i, mixture in enumerate(mixdb.mixtures) if mixture.noise.snr == snr and i in mixid_out]
        )

    return result


def get_mixids_from_class_indices(
    mixdb: MixtureDatabase,
    mixids: GeneralizedIDs = "*",
    predicate: Callable[[Any], bool] | None = None,
) -> dict[int, list[int]]:
    """Generate mixids based on a class index predicate.

    Returns a dictionary where:
        - keys are the class indices
        - values are lists of the mixids that match the class index
    """
    mixid_out = mixdb.mixids_to_list(mixids)

    if predicate is None:
        predicate = _true_predicate

    criteria_set = set()
    for m_id in mixid_out:
        class_indices = mixdb.mixture_class_indices(m_id)
        for class_index in class_indices:
            if predicate(class_index):
                criteria_set.add(class_index)
    criteria = sorted(criteria_set)

    result: dict[int, list[int]] = {}
    for criterion in criteria:
        result[criterion] = []
        for m_id in mixid_out:
            class_indices = mixdb.mixture_class_indices(m_id)
            for class_index in class_indices:
                if class_index == criterion:
                    result[criterion].append(m_id)

    return result


def get_mixids_from_truth_function(
    mixdb: MixtureDatabase,
    mixids: GeneralizedIDs = "*",
    predicate: Callable[[Any], bool] | None = None,
) -> dict[int, list[int]]:
    """Generate mixids based on a truth function predicate.

    Returns a dictionary where:
        - keys are the truth functions
        - values are lists of the mixids that match the truth function
    """
    return get_mixids_from_truth_configs_field_predicate(
        mixdb=mixdb, mixids=mixids, field="function", predicate=predicate
    )
