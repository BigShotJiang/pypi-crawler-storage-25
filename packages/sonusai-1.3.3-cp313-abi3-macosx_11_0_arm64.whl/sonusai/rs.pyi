import numpy as np

class asl_p56_internal:  # noqa: N801
    @staticmethod
    def count_activity(
        q: np.ndarray,
        c: np.ndarray,
        h_samples: int,
        length: int,
    ) -> np.ndarray: ...
    @staticmethod
    def compute_envelope(
        audio: np.ndarray,
        sample_rate: int,
    ) -> tuple[np.ndarray, float, float, int, np.ndarray]: ...
    @staticmethod
    def bin_interp(
        u_cnt: float,
        l_cnt: float,
        u_thr: float,
        l_thr: float,
        margin: float,
        tol: float,
    ) -> float: ...
    @staticmethod
    def compute_asl_from_thresholds(
        a: np.ndarray,
        c: np.ndarray,
        sq: float,
        eps: float,
        margin: float,
    ) -> float: ...

def asl_p56(
    audio: np.ndarray,
) -> float: ...

__version__: str
