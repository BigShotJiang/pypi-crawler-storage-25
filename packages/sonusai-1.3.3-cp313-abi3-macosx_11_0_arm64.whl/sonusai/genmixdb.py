"""Create mixture database data for training and evaluation.

Usage:
    genmixdb [-hvmdjn] LOC

Options:
    -h, --help
    -v, --verbose   Be verbose.
    -m, --mix       Save mixture data. [default: False].
    -d, --dryrun    Perform a dry run showing the processed config. [default: False].
    -j, --json      Save a JSON version of the database. [default: False].
    -n, --nopar     Do not run in parallel. [default: False].

Create mixture database data for training and evaluation. Optionally, also create mixture audio and feature/truth data.

genmixdb creates a database of training and evaluation feature and truth data generation information. It allows the
choice of audio neural-network feature types that are supported by the Aaware real-time front-end and truth data that is
synchronized frame-by-frame with the feature data.

For details, see sonusai doc.
"""

import time
from contextlib import AbstractContextManager
from dataclasses import dataclass
from functools import partial
from pathlib import Path
from random import seed
from typing import TYPE_CHECKING
from typing import Optional

if TYPE_CHECKING:
    from sonusai.perf.timer import PhaseTimer

import yaml
from docopt import docopt

from sonusai import __version__ as sai_version
from sonusai import create_file_handler
from sonusai import exception_handler
from sonusai import initial_log_messages
from sonusai import logger
from sonusai import update_console_handler
from sonusai.config.config import load_config
from sonusai.constants import SAMPLE_RATE
from sonusai.datatypes import Mixture
from sonusai.mixture import MixtureDatabase
from sonusai.mixture.data_io import write_cached_data
from sonusai.mixture.generation import DatabaseManager
from sonusai.mixture.generation import clear_reuse_metrics
from sonusai.mixture.generation import update_mixture
from sonusai.mixture.helpers import write_mixture_metadata
from sonusai.mixture.log_duration_and_sizes import log_duration_and_sizes
from sonusai.utils.docstring import trim_docstring
from sonusai.utils.keyboard_interrupt import register_keyboard_interrupt
from sonusai.utils.parallel import par_track
from sonusai.utils.parallel import track
from sonusai.utils.seconds_to_hms import seconds_to_hms


@dataclass(frozen=True)
class GenMixDbOptions:
    """Runtime options for database generation."""

    save_mix: bool = False
    logging: bool = True
    show_progress: bool = False
    test: bool = False
    verbose: bool = False
    save_json: bool = False
    no_par: bool = False


def genmixdb(
    location: str,
    options: GenMixDbOptions | None = None,
    timer: Optional["PhaseTimer"] = None,
) -> None:
    """Generate a mixture database at the specified location.

    Args:
        location: Path where the mixture database will be created.
        options: Runtime generation options.
        timer: Optional PhaseTimer for performance instrumentation.

    """
    effective_options = options or GenMixDbOptions()

    # Instrumentation utility
    def _measure(stage: str) -> AbstractContextManager[None]:
        if timer:
            return timer.measure(stage)
        from contextlib import nullcontext

        return nullcontext()

    dbm = DatabaseManager(location, effective_options.test, effective_options.verbose, effective_options.logging)
    mixdb = MixtureDatabase(location, effective_options.test)

    clear_reuse_metrics()

    with _measure("config_loading"):
        dbm.populate_top_table()
        dbm.populate_class_label_table()
        dbm.populate_class_weights_threshold_table()
        dbm.populate_spectral_mask_table()
        dbm.populate_truth_parameters_table()

    seed(dbm.config["seed"])

    if effective_options.logging:
        logger.debug(f"Seed: {dbm.config['seed']}")
        logger.debug("Configuration:")
        logger.debug(yaml.dump(dbm.config))

    with _measure("source_discovery_and_population"):
        dbm.populate_source_file_table(effective_options.show_progress, effective_options.no_par)
    with _measure("ir_discovery_and_population"):
        dbm.populate_impulse_response_file_table(effective_options.show_progress, effective_options.no_par)

    with _measure("mixture_planning"):
        mixtures = dbm.generate_mixtures()
    num_mixtures = len(mixtures)

    if effective_options.logging:
        _log_estimated_duration(mixdb, mixtures)

    # Fill in the details
    if effective_options.logging:
        logger.info("Processing mixtures")
    progress = track(total=num_mixtures, disable=not effective_options.show_progress)

    # Instrument the loop logic
    mixtures = par_track(
        partial(
            _process_mixture,
            mixdb=mixdb,
            options=effective_options,
            timer=timer,
        ),
        mixtures,
        progress=progress,
        no_par=effective_options.no_par,
        pass_index=True,
    )
    progress.close()

    with _measure("db_insert_and_commit"):
        dbm.populate_mixture_table(mixtures=mixtures, show_progress=effective_options.show_progress)

    with _measure("final_summary"):
        total_duration = float(mixdb.total_samples() / SAMPLE_RATE)

        if effective_options.logging:
            _log_actual_duration(mixdb, total_duration)

    if not effective_options.test and effective_options.save_json:
        with _measure("save_json"):
            if effective_options.logging:
                logger.info(f"Writing JSON version of database to {location}")
            mixdb = MixtureDatabase(location)
            mixdb.save()


def _log_estimated_duration(mixdb: MixtureDatabase, mixtures: list[Mixture]) -> None:
    num_mixtures = len(mixtures)
    logger.info(f"Found {num_mixtures:,} mixtures to process")

    total_duration = float(sum([mixture.samples for mixture in mixtures])) / SAMPLE_RATE

    log_duration_and_sizes(
        total_duration=total_duration,
        feature_step_samples=mixdb.feature_step_samples,
        feature_parameters=mixdb.feature_parameters,
        stride=mixdb.fg_stride,
        desc="Estimated",
    )
    logger.info(
        f"Feature shape:        "
        f"{mixdb.fg_stride} x {mixdb.feature_parameters} "
        f"({mixdb.fg_stride * mixdb.feature_parameters} total parameters)"
    )
    logger.info(f"Feature samples:      {mixdb.feature_samples} samples ({mixdb.feature_ms} ms)")
    logger.info(f"Feature step samples: {mixdb.feature_step_samples} samples ({mixdb.feature_step_ms} ms)")
    logger.info("")


def _log_actual_duration(mixdb: MixtureDatabase, total_duration: float) -> None:
    log_duration_and_sizes(
        total_duration=total_duration,
        feature_step_samples=mixdb.feature_step_samples,
        feature_parameters=mixdb.feature_parameters,
        stride=mixdb.fg_stride,
        desc="Actual",
    )
    logger.info("")


def _process_mixture(
    index: int,
    mixture: Mixture,
    mixdb: MixtureDatabase,
    options: GenMixDbOptions,
    timer: Optional["PhaseTimer"] = None,
) -> Mixture:
    """Kernel function to process and optionally save a single mixture.

    Args:
        index: Index of the mixture.
        mixture: Mixture object to process.
        mixdb: MixtureDatabase instance.
        options: Runtime generation options.
        timer: Optional PhaseTimer for performance instrumentation.

    Returns:
        The updated Mixture object.

    """

    def _measure(stage: str) -> AbstractContextManager[None]:
        if timer:
            return timer.measure(stage)
        from contextlib import nullcontext

        return nullcontext()

    location = mixdb.location
    mixture.name = f"{index:0{mixdb.mixid_width}}"

    with _measure("per_mixture_kernel"):
        mixture, genmix_data = update_mixture(mixdb, mixture, options.save_mix)

    write = partial(write_cached_data, location=location, name="mixture", index=mixture.name)

    if options.save_mix:
        write(
            items={
                "sources": genmix_data.sources,
                "source": genmix_data.source,
                "noise": genmix_data.noise,
                "mixture": genmix_data.mixture,
            }
        )

        write_mixture_metadata(mixdb, mixture=mixture)

    return mixture


def main() -> None:
    """Execute the genmixdb CLI."""
    args = docopt(trim_docstring(__doc__), version=sai_version, options_first=True)

    verbose = args["--verbose"]
    save_mix = args["--mix"]
    dryrun = args["--dryrun"]
    save_json = args["--json"]
    no_par = args["--nopar"]
    location = args["LOC"]

    start_time = time.monotonic()
    loc_path = Path(location)

    if loc_path.exists() and not loc_path.is_dir():
        loc_path.unlink()

    loc_path.mkdir(parents=True, exist_ok=True)

    create_file_handler(str(loc_path / "genmixdb.log"), verbose)
    update_console_handler(verbose)
    initial_log_messages("genmixdb")

    if dryrun:
        config = load_config(location)
        logger.info("Dryrun configuration:")
        logger.info(yaml.dump(config))
        return

    logger.info(f"Creating mixture database for {location}")
    logger.info("")

    genmixdb(
        location=location,
        options=GenMixDbOptions(
            save_mix=save_mix,
            show_progress=True,
            save_json=save_json,
            verbose=verbose,
            no_par=no_par,
        ),
    )

    end_time = time.monotonic()
    logger.info(f"Completed in {seconds_to_hms(seconds=end_time - start_time)}")
    logger.info("")


if __name__ == "__main__":
    register_keyboard_interrupt()
    try:
        main()
    except Exception as e:  # noqa: BLE001 (Global CLI exception handler)
        exception_handler(e)
