"""PolyBot test suite."""
