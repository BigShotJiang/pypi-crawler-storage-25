"""Unit tests for PolyBot."""
