# Copyright 2026 OpenC3, Inc.
# All Rights Reserved.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE.md for more details.

# This file may also be used under the terms of a commercial license
# if purchased from OpenC3, Inc.

import re
from typing import Any

from openc3.environment import OPENC3_SCOPE
from openc3.utilities.local_mode import LocalMode
from openc3.utilities.store import Store


# Allowlist: letters, digits, hyphens, underscores, spaces, and periods
VALID_NAME_PATTERN = re.compile(r"^[A-Za-z0-9_\-. ]+$")


class ToolConfigModel:
    @classmethod
    def config_tool_names(cls, scope: str = OPENC3_SCOPE):
        cursor, keys = Store.scan(match=f"{scope}__config__*", count=100, _type="HASH")
        result = [key.decode().split("__")[2] for key in keys]
        result.sort()
        return result

    @classmethod
    def list_configs(cls, tool: str, scope: str = OPENC3_SCOPE):
        if not VALID_NAME_PATTERN.match(tool):
            raise RuntimeError(f"Invalid tool name: {tool}")
        keys = Store.hkeys(f"{scope}__config__{tool}")
        return [key.decode() for key in keys]

    @classmethod
    def load_config(cls, tool: str, name: str, scope: str = OPENC3_SCOPE):
        if not VALID_NAME_PATTERN.match(tool):
            raise RuntimeError(f"Invalid tool name: {tool}")
        if not VALID_NAME_PATTERN.match(name):
            raise RuntimeError(f"Invalid config name: {name}")
        return Store.hget(f"{scope}__config__{tool}", name).decode()

    @classmethod
    def save_config(
        cls,
        tool: str,
        name: str,
        data: Any,
        local_mode: bool = True,
        scope: str = OPENC3_SCOPE,
    ):
        if not VALID_NAME_PATTERN.match(tool):
            raise RuntimeError(f"Invalid tool name: {tool}")
        if not VALID_NAME_PATTERN.match(name):
            raise RuntimeError(f"Invalid config name: {name}")
        Store.hset(f"{scope}__config__{tool}", name, data)
        if local_mode:
            LocalMode.save_tool_config(scope, tool, name, data)

    @classmethod
    def delete_config(cls, tool: str, name: str, local_mode: bool = True, scope: str = OPENC3_SCOPE):
        if not VALID_NAME_PATTERN.match(tool):
            raise RuntimeError(f"Invalid tool name: {tool}")
        if not VALID_NAME_PATTERN.match(name):
            raise RuntimeError(f"Invalid config name: {name}")
        Store.hdel(f"{scope}__config__{tool}", name)
        if local_mode:
            LocalMode.delete_tool_config(scope, tool, name)
