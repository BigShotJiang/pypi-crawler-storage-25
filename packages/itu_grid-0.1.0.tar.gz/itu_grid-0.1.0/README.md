# ITU grid

<center>
<a href='https://itu-grid.readthedocs.io/en/latest/?badge=latest'>
    <img src='https://readthedocs.org/projects/itu-grid/badge/?version=latest' alt='Documentation Status' />
</a>
<a href="https://github.com/nanoy42/itu-grid/blob/main/LICENSE"><img alt="Github - License" src="https://img.shields.io/github/license/nanoy42/itu-grid"/></a>
<a href="https://github.com/nanoy42/itu-grid/releases/latest"><img alt="Github - Release" src="https://img.shields.io/github/v/release/nanoy42/itu-grid"/></a>
<a href="https://pypi.org/project/itu-grid/"><img alt="PyPI - Version" src="https://img.shields.io/pypi/v/qosst-bob"></a>
<a href="https://github.com/psf/black"><img alt="Code style: black" src="https://img.shields.io/badge/code%20style-black-000000.svg"></a>
<a href="https://github.com/pylint-dev/pylint"><img alt="Linting with pylint" src="https://img.shields.io/badge/linting-pylint-yellowgreen"/></a>
<a href="https://mypy-lang.org/"><img alt="Checked with mypy" src="https://www.mypy-lang.org/static/mypy_badge.svg"></a>
<a href="https://img.shields.io/pypi/pyversions/itu-grid">
    <img alt="Python Version" src="https://img.shields.io/pypi/pyversions/itu-grid">
</a>
<img alt="Docstr coverage" src=".coverage_badge.svg" />
</center>
<hr/>

## Description

itu-grid is a small python package that can be used to quickly identify the channels in the ITU grid. The app can:

* list the ITU grid;
* identify a channel from a wavelength or a frequency;
* give the wavelength and frequency from a channel;
* apply this to different spacing.

The default parameters for the grid are the following:

| Number of channels | Spacing | Starting center frequency |
| ------------------ | ------- | ------------------------- |
| 80                 | 100 GHz | 190.1 THz                 |

## Usage

The itu-grid package is shipped with a command line interface (CLI) that can be called using the `itu` command. Calling this command without any parameters print the grid:

```console
$ itu
| Channel | Cent. Freq. | Cent. Wav. | Channel | Cent. Freq. | Cent. Wav. |
| ------- | ----------- | ---------- | ------- | ----------- | ---------- |
| 1       | 190.1 THz   | 1577.03 nm | 41      | 194.1 THz   | 1544.53 nm |
| 2       | 190.2 THz   | 1576.20 nm | 42      | 194.2 THz   | 1543.73 nm |
| 3       | 190.3 THz   | 1575.37 nm | 43      | 194.3 THz   | 1542.94 nm |
| 4       | 190.4 THz   | 1574.54 nm | 44      | 194.4 THz   | 1542.14 nm |
| 5       | 190.5 THz   | 1573.71 nm | 45      | 194.5 THz   | 1541.35 nm |
| 6       | 190.6 THz   | 1572.89 nm | 46      | 194.6 THz   | 1540.56 nm |
| 7       | 190.7 THz   | 1572.06 nm | 47      | 194.7 THz   | 1539.77 nm |
| 8       | 190.8 THz   | 1571.24 nm | 48      | 194.8 THz   | 1538.98 nm |
| 9       | 190.9 THz   | 1570.42 nm | 49      | 194.9 THz   | 1538.19 nm |
| 10      | 191.0 THz   | 1569.59 nm | 50      | 195.0 THz   | 1537.40 nm |
| 11      | 191.1 THz   | 1568.77 nm | 51      | 195.1 THz   | 1536.61 nm |
| 12      | 191.2 THz   | 1567.95 nm | 52      | 195.2 THz   | 1535.82 nm |
| 13      | 191.3 THz   | 1567.13 nm | 53      | 195.3 THz   | 1535.04 nm |
| 14      | 191.4 THz   | 1566.31 nm | 54      | 195.4 THz   | 1534.25 nm |
| 15      | 191.5 THz   | 1565.50 nm | 55      | 195.5 THz   | 1533.47 nm |
| 16      | 191.6 THz   | 1564.68 nm | 56      | 195.6 THz   | 1532.68 nm |
| 17      | 191.7 THz   | 1563.86 nm | 57      | 195.7 THz   | 1531.90 nm |
| 18      | 191.8 THz   | 1563.05 nm | 58      | 195.8 THz   | 1531.12 nm |
| 19      | 191.9 THz   | 1562.23 nm | 59      | 195.9 THz   | 1530.33 nm |
| 20      | 192.0 THz   | 1561.42 nm | 60      | 196.0 THz   | 1529.55 nm |
| 21      | 192.1 THz   | 1560.61 nm | 61      | 196.1 THz   | 1528.77 nm |
| 22      | 192.2 THz   | 1559.79 nm | 62      | 196.2 THz   | 1527.99 nm |
| 23      | 192.3 THz   | 1558.98 nm | 63      | 196.3 THz   | 1527.22 nm |
| 24      | 192.4 THz   | 1558.17 nm | 64      | 196.4 THz   | 1526.44 nm |
| 25      | 192.5 THz   | 1557.36 nm | 65      | 196.5 THz   | 1525.66 nm |
| 26      | 192.6 THz   | 1556.55 nm | 66      | 196.6 THz   | 1524.89 nm |
| 27      | 192.7 THz   | 1555.75 nm | 67      | 196.7 THz   | 1524.11 nm |
| 28      | 192.8 THz   | 1554.94 nm | 68      | 196.8 THz   | 1523.34 nm |
| 29      | 192.9 THz   | 1554.13 nm | 69      | 196.9 THz   | 1522.56 nm |
| 30      | 193.0 THz   | 1553.33 nm | 70      | 197.0 THz   | 1521.79 nm |
| 31      | 193.1 THz   | 1552.52 nm | 71      | 197.1 THz   | 1521.02 nm |
| 32      | 193.2 THz   | 1551.72 nm | 72      | 197.2 THz   | 1520.25 nm |
| 33      | 193.3 THz   | 1550.92 nm | 73      | 197.3 THz   | 1519.48 nm |
| 34      | 193.4 THz   | 1550.12 nm | 74      | 197.4 THz   | 1518.71 nm |
| 35      | 193.5 THz   | 1549.32 nm | 75      | 197.5 THz   | 1517.94 nm |
| 36      | 193.6 THz   | 1548.51 nm | 76      | 197.6 THz   | 1517.17 nm |
| 37      | 193.7 THz   | 1547.72 nm | 77      | 197.7 THz   | 1516.40 nm |
| 38      | 193.8 THz   | 1546.92 nm | 78      | 197.8 THz   | 1515.63 nm |
| 39      | 193.9 THz   | 1546.12 nm | 79      | 197.9 THz   | 1514.87 nm |
| 40      | 194.0 THz   | 1545.32 nm | 80      | 198.0 THz   | 1514.10 nm |
```

The information of specific channel can be queried by passing as argument `C` followed by the channel number, e.g.

```console
$ itu C34
Channel 34
Frequency: 193.4 THz (193.3 - 193.4 THz)
Wavelength: 1550.12 nm (1549.72 - 1550.52 nm)
```

The channel for a given wavelength can be queried by passing a number followed by `nm` without space (the number will be interpreted as the wavelength in nm), e.g.

```console
$ itu 1550nm
1550.0 nm is in channel 34
```

The channel for a givenwavelength can be queried by passing a number followed by thz without space (the number will be interpreted as the frequency in THz), e.g.

```console
$ itu 190.25Thz
190.25 THz is in channel 2
```

In case the format of the argument passed to itu is none of the one above, it will try to guess the type of parameter, as long as the number is a float.

```console
$ itu 34
Query has no C, nm or thz indicator. Trying to guess the query.
Query is less than 100 and integer. Channel is assumed (equivalent to C34).
Channel 34
Frequency: 193.4 THz (193.3 - 193.4 THz)
Wavelength: 1550.12 nm (1549.72 - 1550.52 nm)
```

```console
$ itu 1550
Query has no C, nm or thz indicator. Trying to guess the query.
Query is between 1000 and 2000. Assuming it is a wavelength in nm (equivalent to 1550.0nm).
1550.0 nm is in channel 34
```

```console
$ itu 190.25
Query has no C, nm or thz indicator. Trying to guess the query.
Query is between 100 and 200. Assuming it is a frequency in Thz (equivalent to 190.25thz).
190.25 THz is in channel 2
```

In case the query cannot be interpreted (not a float or a float that doesn't make sense in the context), the ITU grid is printed.

For any of these commands, the parameters of the grid can be tuned from the command line with the `--num-channels` (or `-n`), `--start-freq` (or `-f`) and `--spacing` (or `-s`) parameters.

## Installation

The package can be installed via pip:

```console
$ pip install itu-grid
```

For arch-linux users, a PKGBUILD file is available in the `archlinux` folder and can be used with `makepkg -si`.

## License

itu-grid is distributed under the MIT license.