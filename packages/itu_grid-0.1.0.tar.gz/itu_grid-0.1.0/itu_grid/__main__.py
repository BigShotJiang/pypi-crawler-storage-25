# Copyright (c) 2025 Yoann Piétri
#
# This software is released under the MIT License.
# https://opensource.org/licenses/MIT

"""
Main entrypoint for the itu scrip.
"""

import argparse
from typing import Tuple
from enum import IntEnum

from itu_grid.itu import ITUGrid


class Query(IntEnum):
    """The types of queries."""

    CHANNEL = 0
    WAV = 1
    FREQ = 2


# pylint: disable=too-many-return-statements
def _parse_query(query: str) -> Tuple[Query, float | int] | None:
    """Guess the type of query from the user input.

    The logic is the following:
        * it first starts by looking for key indicators (in order):
            * if the query starts with a C (case insensitive), it is assumed to be a channel query. Channel query is returned if the rest of the query can be interpreted as an integer.
            * if the query ends with nm (case insensitive), it is assumed to be a wavelength query. Wavelength query is returned if the rest of the query can be interpreted as a float.
            * if the query ends with thz (case insensitive), it is assumed to be a frequency query. Frequency query is returned if the rest of the query can be interpreted as a float.
        * then if the value is numerical (in order):
            * if it is an integer and strictly less than 100, channel query is assumed.
            * if the numerical value is between 1000 and 2000, wavelength query is assumed.
            * if the numerical value is between 100 and 200, frequency query is assumed.
        * finally, if nothing fits, the function returns None (which will result in priting the itu grid).

    Args:
        query (str): the user input query.

    Returns:
        Tuple[Query, float | int] | None: the type of query, accompanied by the value the query should use, or None if no query was found.
    """
    val: float | int
    if query[0].lower() == "c":
        try:
            val = int(query[1:])
        except ValueError:
            print(
                f"Argument has C in it, assumed it was a channel. However, {query[1:]} cannot be interpreted as an integer."
            )
            return None
        return (Query.CHANNEL, val)
    if len(query) > 2 and query[-2:].lower() == "nm":
        try:
            val = float(query[:-2])
        except ValueError:
            print(
                f"Argument has nm at the end, assumed it was a wavelength. However {query[:-2]} cannot be interpreted as a float."
            )
            return None
        return (Query.WAV, val)
    if len(query) > 3 and query[-3:].lower() == "thz":
        try:
            val = float(query[:-3])
        except ValueError:
            print(
                f"Argument has thz at the end, assumed it was a frequency. However {query[:-3]} cannot be interpreted as a float."
            )
            return None
        return (Query.FREQ, val)

    print("Query has no C, nm or thz indicator. Trying to guess the query.")
    try:
        converted_query = float(query)
    except ValueError:
        print("Query cannot be interpreted as a number. Printing ITU grid.")
        return None

    if converted_query < 100 and int(converted_query) == converted_query:
        val = int(converted_query)
        print(
            f"Query is less than 100 and integer. Channel is assumed (equivalent to C{val})."
        )
        return (Query.CHANNEL, val)

    if 1000 < converted_query < 2000:
        print(
            f"Query is between 1000 and 2000. Assuming it is a wavelength in nm (equivalent to {converted_query}nm)."
        )
        return (Query.WAV, converted_query)

    if 100 < converted_query < 200:
        print(
            f"Query is between 100 and 200. Assuming it is a frequency in Thz (equivalent to {converted_query}thz)."
        )
        return (Query.FREQ, converted_query)

    print("Query cannot be interpreted. Printing ITU grid.")
    return None


def main():
    """
    The main entrypoint of the itu script.
    """
    parser = argparse.ArgumentParser(prog="itu")

    parser.add_argument("-s", "--spacing", type=float, help="Spacing of the grid in THz. If not passed, the default value of 100 GHz is used.")

    parser.add_argument("-n", "--num-channels", type=int, help="Number of channels in the grid. If not passed, the default value of 80 is used.")

    parser.add_argument("-f", "--start-freq", type=float, help="Frequency of the first channel. If not passed, the default value of 190.1 THz is used.")
    parser.add_argument("query", nargs="?")

    args = parser.parse_args()

    grid = ITUGrid()

    if args.spacing is not None:
        grid.spacing = args.spacing

    if args.num_channels is not None:
        grid.num_channels = args.num_channels

    if args.start_freq is not None:
        grid.starting_frequency = args.start_freq

    if args.query:
        parsed_query = _parse_query(args.query)
    else:
        parsed_query = None

    if parsed_query:
        mode, val = parsed_query
        if mode == Query.WAV:
            print(
                f"{val} nm is in channel {grid.get_itu_channel_by_wavelength(val*1e-9)}"
            )
        if mode == Query.FREQ:
            print(
                f"{val} THz is in channel {grid.get_itu_channel_by_frequency(val*1e12)}"
            )
        if mode == Query.CHANNEL:
            freq_center, freq_start, freq_end, wav_center, wav_start, wav_end = (
                grid.get_channel_info(val)
            )
            print(f"Channel {val}")
            print(
                f"Frequency: {freq_center*1e-12:.1f} THz ({freq_start*1e-12:.1f} - {freq_end*1e-12:.1f} THz)"
            )
            print(
                f"Wavelength: {wav_center*1e9:.2f} nm ({wav_start*1e9:.2f} - {wav_end*1e9:.2f} nm)"
            )
    else:
        print(grid.format())


if __name__ == "__main__":
    main()
