# Copyright (c) 2025 Yoann Piétri
#
# This software is released under the MIT License.
# https://opensource.org/licenses/MIT

"""
Define the ITUGrid class.
"""

from typing import List, Tuple

from itu_grid import (
    LIGHT_SPEED,
    DEFAULT_FIRST_CHANNEL_CENTER,
    DEFAULT_NUMBER_CHANNELS,
    DEFAULT_SPACING,
)


class ITUGrid:
    """
    Define the ITU grid based on the spacing, number of channels and starting frequency.

    Exposes a number of functions to print the channels, and link channel numbers to
    frequency and wavelength.
    """

    _spacing: float  #: The spacing of the grid in Hz.
    _num_channels: int  #: The number of channel in the grid.
    _starting_frequency: float  #: The starting frequency in Hz.

    _grid: List[float]  #: The grid, i.e. the list of the center frequencies in Hz.

    def __init__(
        self,
        spacing: float = DEFAULT_SPACING,
        num_channels: int = DEFAULT_NUMBER_CHANNELS,
        starting_frequency: float = DEFAULT_FIRST_CHANNEL_CENTER,
    ):
        self._spacing = spacing
        self._num_channels = num_channels
        self._starting_frequency = starting_frequency

        self._generate_grid()

    @property
    def spacing(self) -> float:
        """The spacing of the grid in Hz.

        Returns:
            float: the spacing of the grid in Hz.
        """
        return self._spacing

    @spacing.setter
    def spacing(self, spacing: float):
        """Set the spacing. The grid is regenerated.

        Args:
            spacing (float): the new spacing of the grid in Hz.
        """
        self._spacing = spacing
        self._generate_grid()

    @property
    def num_channels(self) -> int:
        """The number of channels in the grid.

        Returns:
            int: the number of channels in the grid.
        """
        return self._num_channels

    @num_channels.setter
    def num_channels(self, num_channels: int):
        """Set the number of channels. Update the grid.

        Args:
            num_channels (int): the number of channels in the grid.
        """
        self._num_channels = num_channels
        self._generate_grid()

    @property
    def starting_frequency(self) -> float:
        """The starting frequency of the grid.

        Returns:
            float: the starting frequency of the grid, in Hz.
        """
        return self._starting_frequency

    @starting_frequency.setter
    def starting_frequency(self, starting_frequency: float):
        """Set the starting frequency of the grid. Update the grid.

        Args:
            starting_frequency (float): Starting frequency of the grid, in Hz.
        """
        self._starting_frequency = starting_frequency
        self._generate_grid()

    def _generate_grid(self):
        """
        Generate the grid using the starting frequency, the spacing and the number of channels.
        """
        self._grid = [
            self._starting_frequency + self._spacing * i
            for i in range(self._num_channels)
        ]

    @property
    def grid(self) -> List[float]:
        """Return the grid, i.e. the list of the center frequencies of the channels.

        Returns:
            List[float]: the grid.
        """
        return self._grid

    def format(self, num_columns: int = 2) -> str:
        """Return a formatted vesion of the grid.

        Args:
            num_columns (int, optional): number of columns in the table.. Defaults to 2.

        Returns:
            str: the formatted table.
        """
        header_1 = "Channel"
        header_2 = "Cent. Freq."
        header_3 = "Cent. Wav."
        column_1_length = len(header_1) + 2
        column_2_length = len(header_2) + 2
        column_3_length = len(header_3) + 2
        res = ""
        res += f"| {header_1} | {header_2} | {header_3} " * num_columns + "|\n"
        res += "|---------|-------------|------------" * num_columns + "|\n"
        for i in range(len(self._grid) // num_columns):
            for k in range(num_columns):
                text_1 = str(i + k * len(self._grid) // num_columns + 1)
                text_2 = (
                    f"{self._grid[i+k*len(self._grid) // num_columns]*1e-12:.1f} THz"
                )
                text_3 = f"{LIGHT_SPEED/self._grid[i+k*len(self._grid) // num_columns]*1e9:.2f} nm"
                res += "|" + text_1 + " " * (column_1_length - len(text_1))
                res += "|" + text_2 + " " * (column_2_length - len(text_2))
                res += "|" + text_3 + " " * (column_3_length - len(text_3))
            res += "|\n"
        return res

    def get_itu_channel_by_wavelength(self, wavelength: float) -> int:
        """Return the ITU associated to a given wavelength.

        This is done by computing the frequency and using the function to get the
        channel from frequency.

        Args:
            wavelength (float): the wavelength to look for the associated channel.

        Returns:
            int: the associated channel.
        """
        frequency = LIGHT_SPEED / wavelength
        return self.get_itu_channel_by_frequency(frequency)

    def get_itu_channel_by_frequency(self, frequency: float) -> int:
        """Return the ITU channel associated to the given frequency.

        This is dony by returning the channel with the closest center frequency.

        Args:
            frequency (float): the frequency to look for the associated channel.

        Raises:
            ValueError: if the frequency is outside the grid.

        Returns:
            int: the associated channel.
        """
        spacing = self.grid[1] - self.grid[0]
        if (
            frequency < self.grid[0] - spacing / 2
            or frequency > self.grid[-1] + spacing / 2
        ):
            raise ValueError("Frequency is outisde ITU grid.")

        return int(
            1
            + _argmin(
                [abs(frequency - center_frequency) for center_frequency in self.grid]
            )
        )

    def get_channel_info(
        self, channel_number: int
    ) -> Tuple[float, float, float, float, float, float]:
        """Return the info of a single channel, that is the center
        frequency, star frequency, end frequency, center wavelength,
        start wavelength and end wavelngth.

        Args:
            channel_number (int): the number of the channel to get the info from (between 1 and number channels).

        Raises:
            ValueError: if the channel number is not an int.
            ValueError: if the channel number is not between 1 and the number of channels.

        Returns:
            Tuple[float, float, float, float, float, float]: center frequency, start frequency, end frequency, center wavelength, start wavelength, end wavelength.
        """
        if not isinstance(channel_number, int):
            raise ValueError("The channel number must be an int.")

        if channel_number <= 0 or channel_number > self.num_channels:
            raise ValueError(
                f"The channel number must be between 1 and {self.num_channels} (number of channels)."
            )

        center_freq = self.grid[channel_number - 1]
        freq_start = center_freq - self.spacing / 2
        freq_end = center_freq + self.spacing / 2
        wav_center = LIGHT_SPEED / center_freq
        wav_start = LIGHT_SPEED / freq_end
        wav_end = LIGHT_SPEED / freq_start
        return (center_freq, freq_start, freq_end, wav_center, wav_start, wav_end)


def _argmin(arr: List[float]) -> int:
    """Return the index of the minimal element in
    the list. If two or more minimums are found,
    return the smallest index.

    Args:
        arr (List[float]): the list to search the minimum in.

    Returns:
        int: index of the minimum item (smallest index for several minimums.)
    """

    return min(range(len(arr)), key=lambda x: arr[x])
