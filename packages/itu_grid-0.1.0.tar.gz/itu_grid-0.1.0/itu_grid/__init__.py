# Copyright (c) 2025 Yoann Piétri
#
# This software is released under the MIT License.
# https://opensource.org/licenses/MIT

"""
A small utility for ITU channel grids.
"""

__version__ = "0.1.0"

LIGHT_SPEED: int = 299792458  #: The speed of light, in m/s
DEFAULT_FIRST_CHANNEL_CENTER: float = (
    190.1e12  #: The default first channel of the grid, in Hz.
)
DEFAULT_NUMBER_CHANNELS = 80  #: The default number of channels in the grid.
DEFAULT_SPACING = 100e9  #: The default spacing of the channel, in Hz.
