import subprocess
import click
from typing import Optional, List
import re

from sima_cli.utils.env import is_devkit_running_elxr


def _get_installed_palette_version() -> Optional[str]:
    """Return installed simaai-palette-modalix version, or None if unavailable."""
    try:
        result = subprocess.run(
            ["dpkg-query", "-W", "-f=${Version}", "simaai-palette-modalix"],
            capture_output=True,
            text=True,
            check=True,
        )
    except subprocess.CalledProcessError:
        return None

    version = result.stdout.strip()
    return version if version else None


def _get_available_palette_versions() -> List[str]:
    """Parse apt policy output and return available simaai-palette-modalix versions."""
    try:
        result = subprocess.run(
            ["apt", "policy", "simaai-palette-modalix"],
            capture_output=True,
            text=True,
            check=True,
        )
    except subprocess.CalledProcessError:
        click.echo("❌ Failed to run: apt policy simaai-palette-modalix")
        return []

    versions: List[str] = []
    capture = False

    # Matches lines like:
    #   "     2.0.0~git202511281205.97d3129-755 950"
    #   "*** 2.0.0~git202511271206.97d3129-751 950"
    pattern = re.compile(r"^\s*(\*{3}\s+)?([0-9A-Za-z.~+-]+)\s+")

    for line in result.stdout.splitlines():
        line = line.rstrip()

        if "Version table:" in line:
            capture = True
            continue

        if not capture:
            continue

        m = pattern.match(line)
        if not m:
            continue

        ver = m.group(2)

        # Skip pure numeric entries (950, 100, etc.)
        if ver.isdigit():
            continue

        versions.append(ver)

    # Remove duplicates, preserve order
    versions = list(dict.fromkeys(versions))

    return versions


def print_current_versions():
    p1 = subprocess.Popen(
        ["dpkg", "-l"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    p2 = subprocess.Popen(
        ["grep", "simaai"],
        stdin=p1.stdout,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    p1.stdout.close()
    out, err = p2.communicate()

    click.secho('Current SiMa component versions:', fg='green')
    click.secho(out)

def update_elxr(version_or_url: Optional[str]):
    """
    Update packages on an ELXR-based devkit using simaai-ota.
    Enhanced:
    - "Update to a specific version" shows available versions from apt policy.
    - Adds Back and Cancel options.
    """
    if not is_devkit_running_elxr():
        click.echo("ℹ️  Not an ELXR devkit, skipping update")
        return

    print_current_versions()

    from InquirerPy import inquirer

    # Check connectivity
    if subprocess.call(["ping", "-c", "1", "deb.debian.org"],
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL) != 0:
        click.echo("⚠️  ELXR devkit not connected to the network, skipping update")
        return

    click.echo("➡️  Refreshing APT package metadata...")
    if subprocess.call(["sudo", "-n", "true"],
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL) != 0:
        click.echo("ℹ️  sudo may prompt you for a password...")
    try:
        subprocess.check_call(["sudo", "apt", "update"])
    except subprocess.CalledProcessError:
        click.echo("❌ Failed to run: sudo apt update")
        return

    # -----------------------------
    # Main interaction loop
    # -----------------------------
    while True:

        # If user did not pass a version, show the update type menu
        if version_or_url is None:
            choice = inquirer.select(
                message="How would you like to update this ELXR devkit?",
                choices=[
                    {"name": "Update all packages to the latest", "value": "latest"},
                    {"name": "Update to a specific sima-palette version", "value": "version"},
                    {"name": "Fix u-boot environment (force reinstall + overwrite)", "value": "fix-uboot"},
                    {"name": "Cancel", "value": "cancel"},
                ],
                default="latest"
            ).execute()

            if choice == "cancel":
                click.echo("❌ Update cancelled")
                return

            if choice == "latest":
                cmd = ["simaai-ota", "-f", "-o"]
                desc = "Update all packages to the latest"
                break

            elif choice == "fix-uboot":
                cmd = ["simaai-ota", "-f", "-o"]
                desc = "Fix u-boot environment (force reinstall + overwrite)"
                break

            elif choice == "version":
                # -----------------------------
                # Fetch and display version list
                # -----------------------------
                versions = _get_available_palette_versions()
                installed_version = _get_installed_palette_version()

                if not versions:
                    click.echo("❌ No versions found in APT policy, aborting.")
                    return

                # Add back and cancel
                version_choices = (
                    [{"name": "⬅️  Back to previous menu", "value": "back"}] +
                    [{"name": v, "value": v} for v in versions] +
                    [{"name": "❌ Cancel", "value": "cancel"}]
                )

                selected = inquirer.fuzzy(
                    message="Available simaai-palette-modalix versions:",
                    choices=version_choices,
                ).execute()

                if selected == "back":
                    # Return to main menu loop
                    continue

                if selected == "cancel":
                    click.echo("❌ Update cancelled")
                    return

                # A version was selected
                if installed_version and selected == installed_version:
                    same_version_choice = inquirer.select(
                        message=(
                            f"Version {selected} is already running. "
                            "Do you want to force reinstall it?"
                        ),
                        choices=[
                            {"name": "⬅️  Back to previous menu", "value": "back"},
                            {"name": "✅ Confirm force reinstall", "value": "confirm"},
                        ],
                        default="back"
                    ).execute()

                    if same_version_choice == "back":
                        continue

                    cmd = ["simaai-ota", "-f", "-o", "-v", selected]
                    desc = f"Force reinstall specific version {selected}"
                else:
                    cmd = ["simaai-ota", "-f", "-o", "-v", selected]
                    desc = f"Update to specific version {selected}"
                break

        else:
            # version_or_url specified by user (non-interactive)
            cmd = ["simaai-ota", "-f", "-o", "-v", version_or_url]
            desc = f"Update to specific version {version_or_url}"
            break

    # -----------------------------
    # Execute update
    # -----------------------------
    click.secho(
        "⚠️  This update will reset the u-boot environment variable to the target version.\n"
        "   For standard setups, this is expected and typically harmless.\n"
        "   If you have custom u-boot environment settings, you will need to re-apply them after the update.",
        fg="yellow",
    )
    if not click.confirm("Proceed with ELXR update?", default=False):
        click.echo("❌ Update cancelled")
        return

    cmd = ["sudo"] + cmd
    click.echo(f"➡️  {desc}\n   " + click.style(f"Running: {' '.join(cmd)}", fg="cyan"))

    if subprocess.call(["sudo", "-n", "true"],
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL) != 0:
        click.echo("ℹ️  sudo may prompt you for a password...")

    subprocess.check_call(cmd)
    click.echo("✅ ELXR update completed successfully")
