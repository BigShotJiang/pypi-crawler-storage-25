import pytest
from unittest.mock import MagicMock
from langchain_core.documents import Document
from chroma_hybrid_rrf.retriever import ChromaHybridRRFRetriever

def test_tokenize():
    """Verify that the simple tokenizer correctly cleans and tokenizes strings."""
    retriever = ChromaHybridRRFRetriever(chroma_vectorstore=MagicMock(), top_n=2)
    text = "Hello, world! Building Production-Grade agentic pipelines."
    expected = ["hello", "world", "building", "production-grade", "agentic", "pipelines"]
    assert retriever._tokenize(text) == expected

def test_apply_rrf():
    """Verify the Reciprocal Rank Fusion calculation and ordering."""
    # Create retriever with k=60
    retriever = ChromaHybridRRFRetriever(chroma_vectorstore=MagicMock(), rrf_k=60, top_n=3)
    
    doc1 = Document(page_content="Text A", metadata={"source": "doc1"})
    doc2 = Document(page_content="Text B", metadata={"source": "doc2"})
    doc3 = Document(page_content="Text C", metadata={"source": "doc3"})
    
    # Dense results list: rank 0=doc1, rank 1=doc2
    dense_docs = [doc1, doc2]
    # Sparse results list: rank 0=doc2, rank 1=doc3
    sparse_docs = [doc2, doc3]
    
    # Let's calculate expected RRF scores manually:
    # doc1 (dense rank 0, sparse absent): 1 / (60 + 0 + 1) = 1/61 = 0.016393
    # doc2 (dense rank 1, sparse rank 0): 1 / (60 + 1 + 1) + 1 / (60 + 0 + 1) = 1/62 + 1/61 = 0.016129 + 0.016393 = 0.032522
    # doc3 (dense absent, sparse rank 1): 1 / (60 + 1 + 1) = 1/62 = 0.016129
    
    fused = retriever._apply_rrf(dense_docs, sparse_docs)
    
    # Check that doc2 comes first because it has the highest score
    assert len(fused) == 3
    assert fused[0].page_content == "Text B"
    assert fused[1].page_content == "Text A"
    assert fused[2].page_content == "Text C"
    
    # Check that the metadata contains the calculated rrf_score
    assert pytest.approx(fused[0].metadata["rrf_score"], abs=1e-5) == (1/61 + 1/62)
    assert pytest.approx(fused[1].metadata["rrf_score"], abs=1e-5) == (1/61)
    assert pytest.approx(fused[2].metadata["rrf_score"], abs=1e-5) == (1/62)

def test_get_relevant_documents():
    """Verify retriever pipeline with mock vector store."""
    mock_vectorstore = MagicMock()
    
    # Setup mock documents
    doc1 = Document(page_content="Python FastAPI development", metadata={"id": "1"})
    doc2 = Document(page_content="LangGraph multi-agent systems", metadata={"id": "2"})
    
    # Mock Chroma vector store response
    mock_vectorstore.similarity_search.return_value = [doc1, doc2]
    # Mock Chroma .get() database response for BM25 building
    mock_vectorstore.get.return_value = {
        "documents": ["Python FastAPI development", "LangGraph multi-agent systems"],
        "metadatas": [{"id": "1"}, {"id": "2"}],
        "ids": ["1", "2"]
    }
    
    # Initialize retriever
    retriever = ChromaHybridRRFRetriever(chroma_vectorstore=mock_vectorstore, top_n=2)
    
    # Perform retrieval
    results = retriever.invoke("FastAPI systems")
    
    # Assert similarity search was called
    mock_vectorstore.similarity_search.assert_called_once_with("FastAPI systems", k=4)
    assert len(results) == 2
    # Verify RRF score added to metadata
    assert "rrf_score" in results[0].metadata
