import math
from typing import List, Any, Dict, Optional
from pydantic import Field, PrivateAttr
from langchain_core.retrievers import BaseRetriever
from langchain_core.callbacks import CallbackManagerForRetrieverRun, AsyncCallbackManagerForRetrieverRun
from langchain_core.documents import Document
from rank_bm25 import BM25Okapi

class ChromaHybridRRFRetriever(BaseRetriever):
    """
    A custom high-performance LangChain-compatible retriever that integrates
    dense vector search (via ChromaDB) and sparse keyword search (via BM25),
    ranking the combined results using Reciprocal Rank Fusion (RRF).
    """

    chroma_vectorstore: Any = Field(description="The Chroma vector store instance used for dense vector search.")
    bm25_k1: float = Field(default=1.5, description="BM25 k1 parameter (controls term frequency scaling).")
    bm25_b: float = Field(default=0.75, description="BM25 b parameter (controls document length normalization).")
    rrf_k: int = Field(default=60, description="RRF constant k (mitigates the influence of outlier rank systems).")
    top_n: int = Field(default=4, description="Total number of final fused documents to return.")

    # Private attributes for managing state safely in Pydantic
    _bm25: Optional[BM25Okapi] = PrivateAttr(default=None)
    _documents: List[Document] = PrivateAttr(default_factory=list)

    def __init__(self, **data: Any):
        super().__init__(**data)
        # Eagerly initialize if the vector store already contains items
        self.update_bm25()

    def _tokenize(self, text: str) -> List[str]:
        """Simple tokenizer splitting by whitespace and cleaning special characters."""
        return [word.lower().strip(".,!?;:()[]{}'\"") for word in text.split()]

    def update_bm25(self, documents: Optional[List[Document]] = None) -> None:
        """
        Rebuilds or initializes the local BM25 index.
        If a list of documents is provided, it indexes them.
        Otherwise, it queries the Chroma vector store and indexes all documents stored inside.
        """
        if documents is not None:
            self._documents = documents
        else:
            try:
                # Query all documents currently in Chroma
                chroma_data = self.chroma_vectorstore.get()
                docs = []
                if chroma_data and "documents" in chroma_data and chroma_data["documents"]:
                    for i in range(len(chroma_data["documents"])):
                        text = chroma_data["documents"][i]
                        metadata = chroma_data["metadatas"][i] if (chroma_data["metadatas"] and i < len(chroma_data["metadatas"])) else {}
                        doc_id = chroma_data["ids"][i]
                        # Capture the document
                        docs.append(Document(page_content=text, metadata={**metadata, "_chroma_id": doc_id}))
                self._documents = docs
            except Exception:
                # Fallback if Chroma store is uninitialized or does not support get()
                self._documents = []

        if not self._documents:
            self._bm25 = None
            return

        # Initialize the BM25 index with the tokenized corpus
        tokenized_corpus = [self._tokenize(doc.page_content) for doc in self._documents]
        self._bm25 = BM25Okapi(tokenized_corpus, k1=self.bm25_k1, b=self.bm25_b)

    def _get_relevant_documents(
        self, query: str, *, run_manager: Optional[CallbackManagerForRetrieverRun] = None
    ) -> List[Document]:
        """
        Performs synchronous hybrid search: dense (Chroma) and sparse (BM25),
        and applies Reciprocal Rank Fusion (RRF) to combine and rerank them.
        """
        # Ensure BM25 is initialized (lazy-load fallback if eager failed or empty)
        if self._bm25 is None:
            self.update_bm25()

        # 1. Retrieve Dense results from Chroma (similarity search)
        # Fetching top_n * 2 to give the fusion rank algorithm room to merge
        dense_docs = self.chroma_vectorstore.similarity_search(query, k=self.top_n * 2)

        # 2. Retrieve Sparse results using BM25
        sparse_docs = []
        if self._bm25 is not None and self._documents:
            tokenized_query = self._tokenize(query)
            scores = self._bm25.get_scores(tokenized_query)
            # Pair docs with scores and sort in descending order
            doc_scores = sorted(zip(self._documents, scores), key=lambda x: x[1], reverse=True)
            # Take top docs that have a score > 0
            sparse_docs = [doc for doc, score in doc_scores[:self.top_n * 2] if score > 0]

        # 3. Apply Reciprocal Rank Fusion
        return self._apply_rrf(dense_docs, sparse_docs)

    async def _aget_relevant_documents(
        self, query: str, *, run_manager: Optional[AsyncCallbackManagerForRetrieverRun] = None
    ) -> List[Document]:
        """
        Performs asynchronous hybrid search. Falls back to synchronous run
        since local BM25 and standard Chroma client are fast.
        """
        return self._get_relevant_documents(query, run_manager=run_manager.get_sync() if run_manager else None)

    def _apply_rrf(self, dense_docs: List[Document], sparse_docs: List[Document]) -> List[Document]:
        """
        Applies Reciprocal Rank Fusion (RRF) to combine dense and sparse lists of documents.
        RRF formula: Score(d) = sum_{retriever} 1 / (k + rank_d)
        """
        rrf_scores: Dict[str, float] = {}
        # Keep reference to the actual document objects mapped by content
        # (Using content + sorted metadata keys to uniquely identify unique docs)
        doc_registry: Dict[str, Document] = {}

        def get_doc_key(doc: Document) -> str:
            # Create a unique hashable signature for the document
            return f"{doc.page_content}:::{sorted(doc.metadata.items())}"

        # Calculate RRF scores for dense results
        for rank, doc in enumerate(dense_docs):
            key = get_doc_key(doc)
            if key not in doc_registry:
                doc_registry[key] = doc
            rrf_scores[key] = rrf_scores.get(key, 0.0) + (1.0 / (self.rrf_k + rank + 1))

        # Calculate RRF scores for sparse results
        for rank, doc in enumerate(sparse_docs):
            key = get_doc_key(doc)
            if key not in doc_registry:
                doc_registry[key] = doc
            rrf_scores[key] = rrf_scores.get(key, 0.0) + (1.0 / (self.rrf_k + rank + 1))

        # Sort documents by their calculated RRF score in descending order
        sorted_keys = sorted(rrf_scores.keys(), key=lambda k: rrf_scores[k], reverse=True)

        # Select the top N ranked documents
        final_docs = []
        for key in sorted_keys[:self.top_n]:
            doc = doc_registry[key]
            # Proactively append RRF metrics to document metadata for debugging/evaluation
            doc.metadata["rrf_score"] = rrf_scores[key]
            final_docs.append(doc)

        return final_docs
