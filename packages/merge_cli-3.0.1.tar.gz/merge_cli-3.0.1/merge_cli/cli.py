"""
merge_cli/cli.py  —  v3.0.0

变更：
  1. 服务器地址固定为 https://merge.fanglab.cn/，无需配置
  2. 移除注册（register）和登录（login）命令
  3. 集成模型 pkl 随 pip install 自动内嵌，无需手动下载
  4. Evo2 与 HyenaDNA 一样使用预构建 Docker 镜像，自动拉取
  5. 新增 merge doctor：自动检测 GPU，给出本地 vs 远程建议
"""
import os, sys, time
import click
from rich.console import Console
from rich.table import Table
from rich import box

from . import api, output
from .config import (
    get_mode, set_mode,
    set_local_config, set_local_config_bulk,
    get_local_config, show_config, FIXED_API_URL,
)

console = Console()

# ── 全局模型开关
_MODEL_OPTIONS = [
    click.option("--no-alphagenome",   is_flag=True, default=False, help="跳过 AlphaGenome"),
    click.option("--no-hyenadna",      is_flag=True, default=False, help="跳过 HyenaDNA"),
    click.option("--no-nt",            is_flag=True, default=False, help="跳过 Nucleotide Transformer"),
    click.option("--no-alphamissense", is_flag=True, default=False, help="跳过 AlphaMissense"),
    click.option("--no-esm1b",         is_flag=True, default=False, help="跳过 ESM1b"),
    click.option("--no-gpn-msa",       is_flag=True, default=False, help="跳过 GPN-MSA"),
    click.option("--no-popeve",        is_flag=True, default=False, help="跳过 popEVE"),
    click.option("--no-evo2",          is_flag=True, default=False, help="跳过 Evo2"),
]


def _add_model_options(f):
    for opt in reversed(_MODEL_OPTIONS):
        f = opt(f)
    return f


def _model_flags(**kwargs) -> dict:
    return {
        "use_alphagenome":   not kwargs.get("no_alphagenome",   False),
        "use_hyenadna":      not kwargs.get("no_hyenadna",      False),
        "use_nt":            not kwargs.get("no_nt",            False),
        "use_alphamissense": not kwargs.get("no_alphamissense", False),
        "use_esm1b":         not kwargs.get("no_esm1b",         False),
        "use_gpn_msa":       not kwargs.get("no_gpn_msa",       False),
        "use_popeve":        not kwargs.get("no_popeve",         False),
        "use_evo2":          not kwargs.get("no_evo2",           False),
    }


def _normalize_chrom(chrom: str) -> str:
    return chrom if chrom.startswith("chr") else "chr" + chrom


# ─────────────────────── 根命令 ───────────────────────────────
@click.group()
@click.version_option("3.0.0", prog_name="merge")
def cli():
    """MERGE 变异致病性预测 CLI  v3.0.0

    \b
    服务器：https://merge.fanglab.cn  （固定，无需配置）

    \b
    快速开始（远程模式）：
      merge predict --chrom chr17 --pos 43092919 --ref A --alt G

    \b
    本地模式（无速率限制，需 GPU）：
      merge doctor           # 检测设备，获取建议
      merge local setup      # 配置本地环境
      merge local docker start
      merge local predict --chrom chr17 --pos 43092919 --ref A --alt G
    """


# ─────────────────────── merge doctor ─────────────────────────
@cli.command()
def doctor():
    """检测本机 GPU 和环境，给出运行模式建议。"""
    from .local_engine import detect_gpu, check_local_files, check_docker_health
    import shutil

    console.print("\n[bold]═══ MERGE 环境诊断 v3.0.0 ═══[/bold]\n")

    # GPU 检测
    console.print("[bold]GPU 检测[/bold]")
    gpu_info = detect_gpu()
    if gpu_info["has_gpu"]:
        for i, (name, vram) in enumerate(zip(gpu_info["gpus"], gpu_info["vram_gb"])):
            vram_str = f"{vram} GB" if vram else "未知显存"
            console.print(f"  [green]✓[/green] GPU {i}: {name}（{vram_str}）")
        console.print(
            "\n  [bold green]建议：您的设备有 GPU，推荐使用本地模式。[/bold green]\n"
            "  本地模式无速率限制，速度更快。\n"
            "  运行 [bold]merge local setup[/bold] 开始配置。"
        )
    else:
        console.print("  [yellow]○[/yellow] 未检测到 NVIDIA GPU")
        console.print(
            "\n  [bold yellow]建议：您的设备没有 GPU，推荐使用远程模式。[/bold yellow]\n"
            "  在 CPU 上运行深度学习模型速度极慢（单次预测可能超过 30 分钟）。\n"
            "  远程模式使用 MERGE 服务器（https://merge.fanglab.cn）处理所有计算，\n"
            "  直接运行 [bold]merge predict[/bold] 即可，无需任何本地配置。"
        )

    # Docker 检测
    console.print("\n[bold]Docker 检测[/bold]")
    if shutil.which("docker"):
        console.print("  [green]✓[/green] Docker 已安装")
        for m in ["hyenadna", "evo2"]:
            h = check_docker_health(m)
            if h["online"]:
                console.print(f"  [green]●[/green] {m:<12} 在线  {h.get('latency_ms')} ms")
            else:
                console.print(f"  [dim]○[/dim] {m:<12} 未运行（{h.get('error', '')}）")
    else:
        console.print("  [red]✗[/red] Docker 未安装（本地模式需要）")
        console.print("      → https://www.docker.com/products/docker-desktop/")

    # 内嵌模型检测
    console.print("\n[bold]内嵌集成模型（pip 随包安装）[/bold]")
    files_info = check_local_files()
    any_model_ok = False
    for label, info in files_info.items():
        if not info.get("bundled"):
            continue
        if info["exists"]:
            console.print(f"  [green]✓[/green] {label}")
            any_model_ok = True
        else:
            console.print(f"  [red]✗[/red] {label}  [dim](未找到，请重新安装：pip install --force-reinstall merge-cli)[/dim]")

    # 大数据文件
    console.print("\n[bold]预计算数据文件（需手动下载）[/bold]")
    for label, info in files_info.items():
        if info.get("bundled"):
            continue
        if info["exists"]:
            sz = f"{info['size_gb']} GB" if info["size_gb"] else ""
            console.print(f"  [green]✓[/green] {label:<20} {sz}")
        else:
            console.print(f"  [dim]○[/dim] {label:<20} [dim]未下载（本地模式需要）[/dim]")

    console.print(f"\n  服务器：[bold]{FIXED_API_URL}[/bold]（远程模式默认使用）")
    console.print(f"  当前模式：[bold]{get_mode()}[/bold]\n")


# ─────────────────────── merge config ─────────────────────────
@cli.group()
def config():
    """管理运行模式等配置（服务器地址已固定，无需配置）。"""


@config.command("set-mode")
@click.argument("mode", type=click.Choice(["remote", "local"]))
def config_set_mode(mode):
    """切换运行模式（remote / local）。"""
    set_mode(mode)
    console.print(f"[green]✓[/green] 运行模式已切换为：[bold]{mode}[/bold]")
    if mode == "local":
        console.print("  请确保已完成：merge local setup")


@config.command("show")
def config_show():
    """查看当前所有配置。"""
    info = show_config()
    console.print(f"\n  服务器地址  : [bold]{info['api_url']}[/bold]  [dim]（固定，不可更改）[/dim]")
    console.print(f"  运行模式    : [bold]{info['mode']}[/bold]")
    console.print(f"  配置文件    : [dim]{info['config_file']}[/dim]")
    if info["mode"] == "local":
        lc = info["local"]
        console.print("\n[bold]本地配置：[/bold]")
        console.print(f"  数据目录    : {lc.get('data_dir')}")
        console.print(f"  模型目录    : {lc.get('model_dir')}  [dim]（pkl 已内嵌，仅供参考）[/dim]")
        console.print(f"  ANNOVAR 目录: {lc.get('annovar_dir') or '(未设置)'}")
        console.print(f"  HyenaDNA   : {lc.get('hyenadna_url')}")
        console.print(f"  NT          : {lc.get('nt_url')}")
        console.print(f"  Evo2        : {lc.get('evo2_url')}")
    console.print()


# ─────────────────────── merge predict ────────────────────────
@cli.command()
@click.option("--chrom",   required=True, help="染色体，如 chr17 或 17")
@click.option("--pos",     required=True, type=int, help="变异位置（1-based）")
@click.option("--ref",     required=True, help="参考碱基")
@click.option("--alt",     required=True, help="变异碱基")
@click.option("--genome",  default="hg38", type=click.Choice(["hg38", "hg19"]))
@click.option("--format",  "fmt", default="table",
              type=click.Choice(["table", "json", "tsv"]))
@click.option("--no-ensemble", is_flag=True, default=False,
              help="跳过 MERGE 集成评分")
@click.option("--local", "use_local", is_flag=True, default=False,
              help="强制使用本地模式")
@click.option("--ensemble-type",
              type=click.Choice(["coding", "noncoding", "splice"]), default=None,
              help="手动指定变异类型（跳过 ANNOVAR）")
@_add_model_options
def predict(chrom, pos, ref, alt, genome, fmt, no_ensemble,
            use_local, ensemble_type, **kwargs):
    """单变异致病性预测（远程 / 本地模式）。

    \b
    示例：
      merge predict --chrom chr17 --pos 43092919 --ref A --alt G
      merge predict --chrom 17 --pos 43092919 --ref A --alt G --genome hg19
    """
    flags    = _model_flags(**kwargs)
    chrom    = _normalize_chrom(chrom)
    is_local = use_local or (get_mode() == "local")

    if is_local:
        from . import local_engine
        with console.status("[bold cyan]本地预测中…[/bold cyan]"):
            try:
                resp = local_engine.predict_local(chrom, pos, ref, alt, genome, **flags)
            except FileNotFoundError as e:
                console.print(f"[red]文件缺失：{e}[/red]"); sys.exit(1)
            except Exception as e:
                console.print(f"[red]本地预测失败：{e}[/red]"); sys.exit(1)
    else:
        with console.status(f"[bold cyan]正在预测（{FIXED_API_URL}）…[/bold cyan]"):
            try:
                resp = api.predict_single(chrom, pos, ref, alt, genome, **flags)
            except Exception as e:
                console.print(f"[red]预测失败：{e}[/red]"); sys.exit(1)

    if not resp.get("success"):
        console.print(f"[red]服务端错误：{resp.get('error')}[/red]"); sys.exit(1)

    prediction = resp["prediction"]
    ensemble   = None

    if not no_ensemble:
        with console.status("[bold cyan]计算 MERGE 集成分数…[/bold cyan]"):
            try:
                if is_local:
                    from . import local_engine
                    dbnsfp      = prediction.get("dbnsfp") or {}
                    transcripts = dbnsfp.get("transcripts") or ([dbnsfp] if dbnsfp else [])
                    ens_result, ens_err = local_engine.run_local_ensemble(
                        prediction, transcripts, ensemble_type=ensemble_type)
                    if ens_err:
                        console.print(f"[yellow]集成模型警告：{ens_err}[/yellow]")
                    ensemble = {"success": True, **ens_result}
                else:
                    dbnsfp      = prediction.get("dbnsfp") or {}
                    transcripts = [dbnsfp] if dbnsfp else []
                    ens_resp = api.predict_ensemble(prediction, transcripts)
                    if ens_resp.get("success"):
                        ensemble = ens_resp
            except Exception as e:
                console.print(
                    f"[yellow]集成分数获取失败（不影响原始分数）：{e}[/yellow]"
                )

    output.render_single(prediction, ensemble, fmt=fmt,
                         errors=prediction.get("errors"))


# ─────────────────────── merge batch ──────────────────────────
@cli.command()
@click.argument("vcf_file", type=click.Path(exists=True))
@click.option("--email",  required=True, help="结果通知邮件地址")
@click.option("--genome", default="hg38", type=click.Choice(["hg38", "hg19"]))
@_add_model_options
def batch(vcf_file, email, genome, **kwargs):
    """批量 VCF 文件预测（异步，结果通过邮件发送）。

    \b
    示例：
      merge batch variants.vcf --email you@example.com
    """
    flags = _model_flags(**kwargs)
    with console.status("[bold cyan]上传 VCF 文件…[/bold cyan]"):
        try:
            resp = api.submit_batch(vcf_file, email, genome, **flags)
        except Exception as e:
            console.print(f"[red]提交失败：{e}[/red]"); sys.exit(1)
    if not resp.get("success"):
        console.print(f"[red]提交失败：{resp.get('error')}[/red]"); sys.exit(1)
    output.render_batch_submitted(resp["job_id"], email)


# ─────────────────────── merge status ─────────────────────────
@cli.command()
@click.argument("job_id")
@click.option("--watch", is_flag=True, default=False, help="每 30 秒轮询一次")
def status(job_id, watch):
    """查询批量任务状态。"""
    def _poll():
        try:
            data = api.get_batch_status(job_id)
        except Exception as e:
            console.print(f"[red]查询失败：{e}[/red]"); return None
        output.render_status(data)
        return data

    data = _poll()
    if not watch or not data:
        return
    while data and data.get("status") == "processing":
        console.print("\n[dim]30 秒后再次查询… Ctrl+C 退出[/dim]")
        try:
            time.sleep(30)
        except KeyboardInterrupt:
            break
        data = _poll()


# ─────────────────────── merge local ──────────────────────────
@cli.group()
def local():
    """本地模式管理：所有计算在用户本机完成（推荐 GPU 设备）。

    \b
    快速开始：
      merge doctor                          # 第 0 步：检测设备
      merge local setup                     # 第 1 步：交互式配置
      merge local docker pull               # 第 2 步：拉取 Docker 镜像
      merge local docker start              # 第 3 步：启动容器
      merge local download --file dbnsfp   # 第 4 步：查看 dbNSFP 下载说明
      merge local predict --chrom chr17 --pos 43092919 --ref A --alt G
    """


# ── merge local setup ─────────────────────────────────────────
@local.command("setup")
def local_setup():
    """交互式引导：配置本地模式所需路径和端口。"""
    from pathlib import Path
    from .local_engine import detect_gpu

    console.print("\n[bold]MERGE 本地模式配置向导  v3.0.0[/bold]")
    console.print(f"  服务器：[dim]{FIXED_API_URL}[/dim]（固定）\n")

    # GPU 建议
    gpu_info = detect_gpu()
    if gpu_info["has_gpu"]:
        gpu_names = "、".join(gpu_info["gpus"])
        console.print(f"[green]✓ 检测到 GPU：{gpu_names}[/green]")
        console.print("  [bold green]本地模式是最佳选择！[/bold green]\n")
    else:
        console.print("[yellow]⚠ 未检测到 GPU[/yellow]")
        console.print(
            "  [bold yellow]警告：CPU 模式下深度学习模型运行极慢。[/bold yellow]\n"
            "  建议继续使用远程模式（merge predict 直接运行）。\n"
        )
        if not click.confirm("确定要配置本地模式吗？", default=False):
            console.print("[dim]已取消。直接运行 merge predict 使用远程模式。[/dim]")
            return

    console.print("[dim]按 Enter 接受括号内的默认值[/dim]\n")
    data_dir     = click.prompt("预计算文件目录（dbNSFP / GPN-MSA / popEVE）",
                                default=str(Path.home() / ".merge-data"))
    annovar_dir  = click.prompt("ANNOVAR 目录（留空则需手动 --ensemble-type）", default="")
    hyenadna_url = click.prompt("HyenaDNA 容器地址", default="http://localhost:5001")
    nt_url       = click.prompt("NT 本地地址",       default="http://localhost:5002")
    evo2_url     = click.prompt("Evo2 容器地址",     default="http://localhost:8082")

    os.makedirs(data_dir, exist_ok=True)

    set_local_config_bulk({
        "data_dir": data_dir, "annovar_dir": annovar_dir,
        "hyenadna_url": hyenadna_url, "nt_url": nt_url, "evo2_url": evo2_url,
    })
    console.print("\n[green]✓ 配置已保存[/green]")

    if click.confirm("将默认模式切换为本地模式？", default=True):
        set_mode("local")
        console.print("[green]✓ 已切换到本地模式[/green]")

    console.print("\n[bold]下一步建议：[/bold]")
    console.print("  1. [bold]merge local docker pull[/bold]            # 拉取 HyenaDNA + Evo2 镜像")
    console.print("  2. [bold]merge local docker start[/bold]           # 启动所有容器")
    console.print("  3. [bold]merge local download --file dbnsfp[/bold] # 查看 dbNSFP 下载说明")
    console.print("  4. [bold]merge local status[/bold]                 # 验证环境")
    console.print("  5. [bold]merge local predict ...[/bold]            # 开始预测")


# ── merge local docker ────────────────────────────────────────
@local.command("docker")
@click.argument("action", type=click.Choice(["pull", "start", "stop", "restart", "status"]))
@click.option("--model", "model_name", default="all",
              type=click.Choice(["all", "hyenadna", "nt", "evo2"]),
              help="指定操作哪个模型容器（默认 all）")
@click.option("--evo2-src", default=None,
              help="（仅 Evo2）已有的 evo2 源码目录路径；为空时自动 git clone")
def local_docker(action, model_name, evo2_src):
    """管理本地 Docker 模型容器。

    \b
    HyenaDNA：官方预构建镜像，docker pull 即可。
    Evo2    ：官方无预构建镜像，MERGE 会自动 git clone + docker build。
    NT      ：无 Docker，直接本地 Python 调用。

    \b
    镜像说明：
      HyenaDNA  →  docker pull hyenadna/hyena-dna:latest
      Evo2      →  git clone https://github.com/arcinstitute/evo2
                   docker build -t evo2 .
                   （模型权重缓存至 ~/.merge-evo2-cache，重启后不丢失）

    \b
    Evo2 GPU 要求：
      7B  模型：任何支持的 NVIDIA GPU（bfloat16，无需 Transformer Engine）
      20B 模型：Hopper 架构 GPU（如 H100），需 FP8 + Transformer Engine
      40B 模型：同上

    \b
    示例：
      merge local docker pull                        # 准备所有镜像
      merge local docker pull --model evo2           # 仅构建 Evo2
      merge local docker pull --model evo2 \\
          --evo2-src ~/repos/evo2                    # 使用已有源码
      merge local docker start                       # 启动所有容器
      merge local docker start --model evo2
      merge local docker stop
      merge local docker status
    """
    import subprocess, shutil
    from .local_engine import (
        _DOCKER_CONTAINERS, docker_pull, docker_start,
        check_docker_health, _evo2_image_exists,
    )

    if not shutil.which("docker"):
        console.print("[red]✗ 未找到 Docker 命令[/red]")
        console.print("  请先安装 Docker Desktop：https://www.docker.com/products/docker-desktop/")
        sys.exit(1)

    cfg = get_local_config()
    targets = (list(_DOCKER_CONTAINERS.keys())
               if model_name == "all" else [model_name])

    for m in targets:
        # NT 无 Docker
        if m == "nt":
            if action in ("pull", "start", "restart"):
                console.print(
                    "[yellow]⚠ NT（Nucleotide Transformer）无 Docker 镜像，直接本地调用。[/yellow]\n"
                    "  如需启动本地 NT 服务：pip install transformers torch"
                )
            elif action == "status":
                console.print(f"  [dim]○[/dim] {'nt':<12} [dim]直接本地调用（无 Docker）[/dim]")
            continue

        c = _DOCKER_CONTAINERS[m]

        if action == "pull":
            docker_pull(m, console=console, evo2_source_dir=evo2_src)

        elif action == "start":
            if m == "evo2" and not _evo2_image_exists():
                console.print(
                    "[yellow]⚠ Evo2 镜像尚未构建，正在自动执行 clone + build…[/yellow]\n"
                    "  （首次构建需 10–30 分钟，请耐心等待）"
                )
                docker_pull("evo2", console=console, evo2_source_dir=evo2_src)
            docker_start(m, console=console)

        elif action == "stop":
            try:
                result = subprocess.run(
                    ["docker", "stop", c["name"]],
                    capture_output=True, text=True,
                )
                if result.returncode == 0:
                    console.print(f"[green]✓ {m} 已停止[/green]")
                else:
                    console.print(f"[yellow]⚠ {m} 未在运行[/yellow]")
            except FileNotFoundError:
                console.print("[red]✗ Docker 命令不可用[/red]"); sys.exit(1)

        elif action == "restart":
            try:
                subprocess.run(["docker", "stop", c["name"]], capture_output=True)
                time.sleep(2)
                docker_start(m, console=console)
            except Exception as e:
                console.print(f"[red]✗ {m} 重启失败：{e}[/red]")

        elif action == "status":
            h = check_docker_health(m)
            health_url = cfg.get(c["url_key"], "")
            if h["online"]:
                console.print(
                    f"[green]●[/green] {m:<12} 在线  "
                    f"[dim]{h.get('latency_ms')} ms  {health_url}[/dim]"
                )
            else:
                extra = ""
                if m == "evo2":
                    extra = "  [dim]（镜像已构建）[/dim]" if _evo2_image_exists() \
                            else "  [yellow]（镜像未构建，请先执行 merge local docker pull --model evo2）[/yellow]"
                console.print(
                    f"[red]○[/red] {m:<12} [dim]离线  {h.get('error', '')}[/dim]{extra}"
                )


# ── merge local download ──────────────────────────────────────
@local.command("download")
@click.option("--file", "file_type",
              type=click.Choice(["all", "dbnsfp", "gpn-msa", "popeve"]),
              default="all",
              help="查看指定文件的下载说明")
def local_download(file_type):
    """显示预计算文件（dbNSFP / GPN-MSA / popEVE）官方下载地址。

    \b
    ╔══════════════════════════════════════════════════════════════╗
    ║  集成模型（pkl 文件）已在 pip install 时自动内嵌，无需下载  ║
    ║  以下仅为大型预计算注释数据库，需前往官网手动下载           ║
    ╚══════════════════════════════════════════════════════════════╝

    \b
    示例：
      merge local download --file dbnsfp   # 查看 dbNSFP 下载说明
      merge local download --file all      # 显示所有说明
    """
    cfg = get_local_config()
    data_dir = cfg["data_dir"]
    os.makedirs(data_dir, exist_ok=True)

    INSTRUCTIONS = {
        "dbnsfp": {
            "label": "dbNSFP（ESM1b + AlphaMissense）",
            "url":   "https://www.dbnsfp.org/",
            "steps": [
                "访问 https://www.dbnsfp.org/ 注册并登录",
                "下载 dbNSFP5.3a_grch38.gz（约 110 GB）及 .tbi 索引",
                f"将文件放入数据目录：{data_dir}",
                "hg19 版本：dbNSFP5.3a_grch37.gz（可选）",
            ],
        },
        "gpn-msa": {
            "label": "GPN-MSA 预计算分数",
            "url":   "https://huggingface.co/datasets/songlab/gpn-msa-hg38-scores/tree/main",
            "steps": [
                "访问 Hugging Face 数据集页面（上方 URL）",
                "下载 scores.tsv.bgz 及 scores.tsv.bgz.tbi",
                f"将文件放入数据目录：{data_dir}",
            ],
        },
        "popeve": {
            "label": "popEVE 预计算分数",
            "url":   "https://pop.evemodel.org/",
            "steps": [
                "访问 https://pop.evemodel.org/",
                "下载 grch38_popEVE_ukbb_*.vcf.gz 及 .tbi 索引",
                f"将文件放入数据目录：{data_dir}",
            ],
        },
    }

    # 内嵌模型提示
    console.print(
        "\n[bold green]✓ 集成模型（pkl 文件）[/bold green] 已在 pip install 时随包内嵌，"
        "无需手动下载。\n"
        "  如果模型文件缺失，请执行：[bold]pip install --force-reinstall merge-cli[/bold]\n"
    )

    show_keys = (list(INSTRUCTIONS.keys()) if file_type == "all"
                 else [file_type] if file_type in INSTRUCTIONS else [])

    for key in show_keys:
        info = INSTRUCTIONS[key]
        console.print(f"[bold cyan]══ {info['label']} ══[/bold cyan]")
        console.print(f"  官方下载地址：[link={info['url']}]{info['url']}[/link]")
        console.print("  下载步骤：")
        for i, step in enumerate(info["steps"], 1):
            console.print(f"    {i}. {step}")
        console.print()


# ── merge local predict ───────────────────────────────────────
@local.command("predict")
@click.option("--chrom",   required=True)
@click.option("--pos",     required=True, type=int)
@click.option("--ref",     required=True)
@click.option("--alt",     required=True)
@click.option("--genome",  default="hg38", type=click.Choice(["hg38", "hg19"]))
@click.option("--format",  "fmt", default="table",
              type=click.Choice(["table", "json", "tsv"]))
@click.option("--no-ensemble", is_flag=True, default=False)
@click.option("--ensemble-type",
              type=click.Choice(["coding", "noncoding", "splice"]),
              default=None,
              help="手动指定变异类型（跳过 ANNOVAR）：coding / noncoding / splice")
@_add_model_options
def local_predict(chrom, pos, ref, alt, genome, fmt,
                  no_ensemble, ensemble_type, **kwargs):
    """完全在本地运行单变异预测，无速率限制。

    \b
    示例：
      merge local predict --chrom chr17 --pos 43092919 --ref A --alt G
      merge local predict --chrom chr17 --pos 43092919 --ref A --alt G \\
          --ensemble-type coding --format json
    """
    from . import local_engine
    chrom = _normalize_chrom(chrom)
    flags = _model_flags(**kwargs)

    with console.status("[bold cyan]本地预测中（无速率限制）…[/bold cyan]"):
        try:
            resp = local_engine.predict_local(chrom, pos, ref, alt, genome, **flags)
        except FileNotFoundError as e:
            console.print(f"\n[red]文件缺失：{e}[/red]")
            console.print("[dim]运行 merge local status 查看哪些文件未就绪[/dim]")
            sys.exit(1)
        except ImportError as e:
            console.print(f"\n[red]缺少依赖：{e}[/red]"); sys.exit(1)
        except Exception as e:
            console.print(f"\n[red]本地预测失败：{e}[/red]"); sys.exit(1)

    if not resp.get("success"):
        console.print(f"[red]预测失败：{resp.get('error')}[/red]"); sys.exit(1)

    prediction = resp["prediction"]
    for src, err in prediction.get("errors", {}).items():
        console.print(f"[yellow]⚠ {src}：{err}[/yellow]")

    ensemble = None
    if not no_ensemble:
        with console.status("[bold cyan]运行本地集成模型（pkl 内嵌版）…[/bold cyan]"):
            try:
                dbnsfp = prediction.get("dbnsfp") or {}
                transcripts = dbnsfp.get("transcripts") or ([dbnsfp] if dbnsfp else [])
                ens_result, ens_err = local_engine.run_local_ensemble(
                    prediction, transcripts, ensemble_type=ensemble_type)
                if ens_err:
                    console.print(f"[yellow]集成模型警告：{ens_err}[/yellow]")
                ensemble = {"success": True, **ens_result}
            except FileNotFoundError as e:
                console.print(f"[red]集成模型文件缺失：{e}[/red]")
                console.print("[dim]请执行：pip install --force-reinstall merge-cli[/dim]")
            except Exception as e:
                console.print(f"[yellow]集成模型运行失败：{e}[/yellow]")

    output.render_single(prediction, ensemble, fmt=fmt,
                         errors=prediction.get("errors"))


# ── merge local status ────────────────────────────────────────
@local.command("status")
def local_status():
    """检查本地环境状态：文件 / Docker 容器 / ANNOVAR。"""
    from . import local_engine
    cfg = get_local_config()
    console.print(f"\n[bold]本地环境状态[/bold]")
    console.print(f"  服务器    : [dim]{FIXED_API_URL}[/dim]")
    console.print(f"  数据目录  : {cfg['data_dir']}")

    # GPU
    gpu_info = local_engine.detect_gpu()
    if gpu_info["has_gpu"]:
        console.print(f"  GPU       : [green]{', '.join(gpu_info['gpus'])}[/green]")
    else:
        console.print("  GPU       : [yellow]未检测到（建议使用远程模式）[/yellow]")

    # 内嵌模型
    console.print("\n[bold]集成模型文件（pip 内嵌）[/bold]")
    all_files = local_engine.check_local_files()
    for label, info in all_files.items():
        if not info.get("bundled"):
            continue
        if info["exists"]:
            console.print(f"  [green]✓[/green] {label}")
        else:
            console.print(f"  [red]✗[/red] [dim]{label}[/dim]  [dim](请重新安装 merge-cli)[/dim]")

    # 大数据文件
    console.print("\n[bold]预计算数据文件[/bold]")
    for label, info in all_files.items():
        if info.get("bundled"):
            continue
        if info["exists"]:
            sz = f"{info['size_gb']} GB" if info["size_gb"] else ""
            console.print(f"  [green]✓[/green] {label:<20} {sz}")
        else:
            console.print(f"  [red]✗[/red] [dim]{label}[/dim]  [dim](未下载)[/dim]")

    # Docker 容器
    console.print("\n[bold]Docker 模型容器[/bold]")
    for m in ["hyenadna", "evo2"]:
        h = local_engine.check_docker_health(m)
        url = cfg.get(local_engine._DOCKER_CONTAINERS[m]["url_key"], "")
        if h["online"]:
            console.print(
                f"  [green]●[/green] {m:<12} 在线  "
                f"[dim]{h.get('latency_ms')} ms  {url}[/dim]"
            )
        else:
            console.print(f"  [red]○[/red] {m:<12} [dim]离线  {h.get('error', '')}[/dim]")
    console.print(f"  [dim]○[/dim] {'nt':<12} [dim]直接本地调用（无需 Docker）[/dim]")

    # ANNOVAR
    console.print("\n[bold]ANNOVAR[/bold]")
    annovar_dir = cfg.get("annovar_dir", "")
    if annovar_dir and os.path.exists(os.path.join(annovar_dir, "annotate_variation.pl")):
        console.print(f"  [green]✓[/green] ANNOVAR 已配置：{annovar_dir}")
    else:
        console.print(
            "  [yellow]⚠[/yellow] ANNOVAR 未配置\n"
            "    [dim]预测时请加 --ensemble-type coding|noncoding|splice[/dim]"
        )
    console.print()
