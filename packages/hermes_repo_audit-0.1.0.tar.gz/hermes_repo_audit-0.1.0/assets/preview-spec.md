# Preview Spec — repo-audit

- Dimensions: `1600x900`
- Theme: dark terminal card
- Font treatment: monospace, regular weight, high contrast
- Padding: `64px` outer, `28px` inner text padding
- Background: charcoal (#1e1e1e) canvas with slightly lighter terminal panel (#2d2d2d)
- Command shown: `$ repo-audit github.com/roli-lpci/lintlang`
- Exact output shown: contents of `assets/preview-source.txt`
- Color coding:
  - `PASS` lines: green (#4ec9b0)
  - `WARN` lines: yellow (#d7ba7d)
  - `FAIL` lines: red (#f48771)
  - Score/grade header: white
  - Action list items: light gray (#cccccc)
- Family rule: use the same dimensions, palette, corner radius, text sizing, and panel chrome across all roli-lpci OSS repos

## Rendering Rules

- Real CLI output only (from `assets/preview-source.txt`)
- Preserve line breaks exactly
- No fake window chrome beyond minimal terminal-card framing
- No logos, mascots, or decorative art
- Same aspect ratio (16:9) across the family

## Replace-or-Keep Rule

- If this repo has no preview image, render from this spec
- If a preview exists but uses fake output or breaks the family format, replace it
- If a compliant preview already exists, keep it
