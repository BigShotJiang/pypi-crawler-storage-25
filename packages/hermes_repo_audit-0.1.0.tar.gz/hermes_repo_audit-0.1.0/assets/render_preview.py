"""Render assets/preview.png from preview-spec.md + preview-source.txt.

Run from the repo root:
    python assets/render_preview.py

Produces assets/preview.png at 1600x900, dark terminal card, color-coded
PASS/WARN/FAIL lines. No fake chrome, real CLI output only.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

W, H = 1600, 900
BG = (30, 30, 30)
PANEL = (45, 45, 45)
OUTER_PAD = 64
INNER_PAD = 28
CORNER_RADIUS = 14

GREEN = (78, 201, 176)
YELLOW = (215, 186, 125)
RED = (244, 135, 113)
WHITE = (245, 245, 245)
GRAY = (204, 204, 204)
DIM = (150, 150, 150)


def pick_font(size: int) -> ImageFont.FreeTypeFont:
    candidates = [
        "/System/Library/Fonts/SFNSMono.ttf",
        "/System/Library/Fonts/Menlo.ttc",
        "/System/Library/Fonts/Monaco.ttf",
        "/Library/Fonts/Menlo.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
    ]
    for path in candidates:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
    return ImageFont.load_default()


def color_for_line(line: str) -> tuple[int, int, int]:
    stripped = line.lstrip()
    if stripped.startswith("PASS"):
        return GREEN
    if stripped.startswith("WARN"):
        return YELLOW
    if stripped.startswith("FAIL"):
        return RED
    if stripped.startswith("$ "):
        return WHITE
    if stripped.startswith("Top actions:"):
        return WHITE
    if stripped.startswith("["):
        return GRAY
    if "Score:" in stripped or "Grade:" in stripped:
        return WHITE
    if stripped.startswith("repo-audit:"):
        return WHITE
    return GRAY


def main() -> int:
    here = Path(__file__).parent
    src = here / "preview-source.txt"
    out = here / "preview.png"

    if not src.exists():
        print(f"ERROR: {src} not found", file=sys.stderr)
        return 1

    lines = src.read_text().splitlines()

    img = Image.new("RGB", (W, H), BG)
    draw = ImageDraw.Draw(img)

    panel_x0, panel_y0 = OUTER_PAD, OUTER_PAD
    panel_x1, panel_y1 = W - OUTER_PAD, H - OUTER_PAD
    draw.rounded_rectangle(
        [panel_x0, panel_y0, panel_x1, panel_y1],
        radius=CORNER_RADIUS,
        fill=PANEL,
    )

    dot_r = 7
    dot_y = panel_y0 + 22
    for i, color in enumerate([(255, 95, 86), (255, 189, 46), (39, 201, 63)]):
        cx = panel_x0 + 22 + i * 22
        draw.ellipse([cx - dot_r, dot_y - dot_r, cx + dot_r, dot_y + dot_r], fill=color)

    font = pick_font(26)
    body_top = panel_y0 + 56 + INNER_PAD
    text_x = panel_x0 + INNER_PAD
    line_h = 34

    y = body_top
    for line in lines:
        draw.text((text_x, y), line, font=font, fill=color_for_line(line))
        y += line_h

    footer_font = pick_font(18)
    footer = "github.com/roli-lpci/repo-audit"
    bbox = draw.textbbox((0, 0), footer, font=footer_font)
    fw = bbox[2] - bbox[0]
    draw.text(
        (panel_x1 - INNER_PAD - fw, panel_y1 - INNER_PAD - 22),
        footer,
        font=footer_font,
        fill=DIM,
    )

    img.save(out, "PNG", optimize=True)
    print(f"wrote {out} ({out.stat().st_size} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
