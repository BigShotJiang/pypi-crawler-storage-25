# IDEAS.md — Design Decisions

## Two Ideas Considered

### Idea 1: Search-Corpus Visualizer

A tool that takes a search output directory and builds an HTML dashboard showing:
- URL coverage by source (DDG, HN, arXiv, GitHub)
- Top domains hit
- Citation network between papers/repos
- Keyword frequency map

**Why we didn't pick it:** Downstream analysis tool, not actionable for founders. The output is a report to read, not a punch-list to execute. Building a robust parser for all output variants would consume most of the build time. High complexity, medium value.

### Idea 2: GitHub Repo Launch-Readiness Auditor (repo-audit) — CHOSEN

A signal-based scoring tool that evaluates a GitHub repo against the exact criteria that make a repo discoverable, trustworthy, and install-worthy to developers encountering it for the first time.

**Why we picked it:**

1. **The problem is real and immediate.** Many public repos built quickly have 0 stars not because the code is bad but because the launch surface is empty. The tool pays for itself on the first run.

2. **The signal set is well-defined.** GitHub's discovery algorithm, PyPI search, and HN crawlers all use a known set of signals. This isn't fuzzy — it's a checklist with measurable binary/scalar values.

3. **Provenance is clean.** Every signal traces to a GitHub API endpoint or registry URL. All claims are machine-readable API responses, no LLM inference.

4. **Public search integration is a natural fit.** Web discoverability and topical citations (HN/Reddit mentions) are exactly what DuckDuckGo site: queries fetch. The tool degrades gracefully to WARN when search is unavailable.

5. **Pairs with lintlang.** lintlang audits agent configs inside a repo. repo-audit audits the repo's public-facing launch surface. Together: "is the code well-described?" + "will anyone find it?"

## Design Choices

- **No auth required by default.** 60 req/hr unauthenticated covers single-repo audits. `GITHUB_TOKEN` is an env var opt-in, not a hard requirement.
- **Score starts at 100, deductions per missing signal.** Avoids the "everything fails by default" UX problem of additive scoring.
- **Distribution check starts at 0.** PyPI/npm presence is a bonus, not a baseline assumption.
- **DDG checks degrade to WARN, not FAIL.** Web discoverability and citations require network; if DDG is unavailable or rate-limited, the tool is honest about it rather than returning false zeros.
