# Code of Conduct

## Our Standards

- Be respectful and constructive in all interactions.
- Focus on the technical substance.
- Accept honest disagreement and move forward.

## Unacceptable Behavior

- Personal attacks or harassment.
- Dismissive or demeaning language.
- Publishing others' private information.

## Reporting

Report issues to the maintainer via a private GitHub message or the email in SECURITY.md.

## Attribution

This code of conduct is adapted from the Contributor Covenant.
