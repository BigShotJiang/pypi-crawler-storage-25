"""
Core audit runner — orchestrates all signal checks and produces a structured report.
"""

import time
from dataclasses import dataclass, field
from typing import Optional

from .github_client import parse_github_url, get_repo_meta, GITHUB_API
from .signals import (
    check_readme,
    check_social_proof,
    check_release_cadence,
    check_metadata,
    check_docs,
    check_distribution,
    check_web_discoverability,
    check_topical_citations,
    check_launch_channels,
    SignalResult,
)


@dataclass
class AuditReport:
    owner: str
    repo: str
    github_url: str
    api_url: str
    overall_score: int
    grade: str          # A / B / C / D / F
    signals: list[SignalResult] = field(default_factory=list)
    top_actions: list[str] = field(default_factory=list)
    elapsed_seconds: float = 0.0
    error: Optional[str] = None


def _grade(score: int) -> str:
    if score >= 85:
        return "A"
    if score >= 70:
        return "B"
    if score >= 55:
        return "C"
    if score >= 40:
        return "D"
    return "F"


def run_audit(github_url: str) -> AuditReport:
    """
    Run a full launch-readiness audit on a GitHub repo.

    Args:
        github_url: GitHub URL in any supported format.

    Returns:
        AuditReport with per-signal scores and ranked action items.
    """
    t0 = time.time()

    owner, repo = parse_github_url(github_url)
    api_url = f"{GITHUB_API}/repos/{owner}/{repo}"
    canonical_url = f"https://github.com/{owner}/{repo}"

    # Fetch core metadata (single API call — used by all signal checks)
    meta = get_repo_meta(owner, repo)

    # Run all signal checks
    results = []

    results.append(check_readme(owner, repo, meta))
    results.append(check_metadata(owner, repo, meta))
    results.append(check_social_proof(owner, repo, meta))
    results.append(check_release_cadence(owner, repo))
    results.append(check_docs(owner, repo, meta))
    results.append(check_distribution(owner, repo, meta))
    results.append(check_web_discoverability(owner, repo, meta))
    results.append(check_topical_citations(owner, repo, meta))
    results.append(check_launch_channels(owner, repo, meta))

    # Weighted overall score
    # Weights reflect impact on launch discoverability
    weights = {
        "README Quality": 15,
        "Repo Metadata": 12,
        "Social Proof": 10,
        "Release Cadence": 8,
        "Docs & Agent Files": 10,
        "Distribution (PyPI/npm)": 15,
        "Web Discoverability": 12,
        "Topical Citations": 10,
        "Launch Channels": 8,
    }
    total_weight = sum(weights.values())
    weighted_sum = 0
    for r in results:
        w = weights.get(r.name, 5)
        weighted_sum += r.score * w
    overall = int(weighted_sum / total_weight)

    # Collect all actions from failing signals, ranked by impact
    # (lower score = higher priority)
    failing_signals = sorted([r for r in results if r.score < 80], key=lambda x: x.score)
    top_actions = []
    for sig in failing_signals:
        for action in sig.actions[:2]:  # top 2 per failing signal
            top_actions.append(f"[{sig.name}] {action}")
    top_actions = top_actions[:10]  # global top 10

    elapsed = time.time() - t0

    return AuditReport(
        owner=owner,
        repo=repo,
        github_url=canonical_url,
        api_url=api_url,
        overall_score=overall,
        grade=_grade(overall),
        signals=results,
        top_actions=top_actions,
        elapsed_seconds=round(elapsed, 1),
    )
