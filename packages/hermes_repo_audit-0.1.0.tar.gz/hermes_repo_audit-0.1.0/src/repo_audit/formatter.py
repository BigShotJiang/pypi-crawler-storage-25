"""
Output formatters: human-readable punch-list and JSON.
"""

import json
from .audit import AuditReport
from .signals import SignalResult


GRADE_COLORS = {
    "A": "\033[92m",   # green
    "B": "\033[94m",   # blue
    "C": "\033[93m",   # yellow
    "D": "\033[91m",   # red
    "F": "\033[91m",   # red
}
RESET = "\033[0m"
BOLD = "\033[1m"


def _score_bar(score: int, width: int = 20) -> str:
    filled = int(score / 100 * width)
    return "[" + "█" * filled + "░" * (width - filled) + f"] {score:3d}/100"


def _signal_label_color(label: str) -> str:
    if label == "PASS":
        return f"\033[92m{label}\033[0m"
    if label == "WARN":
        return f"\033[93m{label}\033[0m"
    return f"\033[91m{label}\033[0m"


def format_text(report: AuditReport, verbose: bool = False) -> str:
    """Format report as human-readable punch-list text."""
    lines = []

    # Header
    grade_color = GRADE_COLORS.get(report.grade, "")
    lines.append("")
    lines.append(f"{BOLD}{'─'*60}{RESET}")
    lines.append(f"{BOLD}  REPO LAUNCH-READINESS AUDIT{RESET}")
    lines.append(f"{BOLD}{'─'*60}{RESET}")
    lines.append(f"  Repo:    {report.github_url}")
    lines.append(f"  API:     {report.api_url}")
    lines.append(f"  Grade:   {grade_color}{BOLD}{report.grade}{RESET}  ({_score_bar(report.overall_score)})")
    lines.append(f"  Elapsed: {report.elapsed_seconds}s")
    lines.append("")

    # Per-signal table
    lines.append(f"{BOLD}  SIGNAL SCORES{RESET}")
    lines.append("  " + "─" * 55)
    for sig in report.signals:
        label_str = _signal_label_color(sig.label)
        lines.append(f"  {sig.name:<28}  {label_str:<20}  {sig.score:3d}/100")
    lines.append("")

    # Top action items (punch-list)
    if report.top_actions:
        lines.append(f"{BOLD}  PUNCH-LIST (ranked by urgency){RESET}")
        lines.append("  " + "─" * 55)
        for i, action in enumerate(report.top_actions, 1):
            # Wrap at 75 chars
            prefix = f"  {i:2d}. "
            indent = " " * len(prefix)
            words = action.split()
            current_line = prefix
            for word in words:
                if len(current_line) + len(word) + 1 > 78:
                    lines.append(current_line)
                    current_line = indent + word + " "
                else:
                    current_line += word + " "
            lines.append(current_line.rstrip())
        lines.append("")

    # Verbose: per-signal details + sources
    if verbose:
        lines.append(f"{BOLD}  SIGNAL DETAILS{RESET}")
        lines.append("  " + "─" * 55)
        for sig in report.signals:
            if sig.findings or sig.actions:
                lines.append(f"\n  [{sig.name}]  score={sig.score}")
                for f in sig.findings:
                    lines.append(f"    ✗ {f}")
                for a in sig.actions:
                    lines.append(f"    → {a}")
                if sig.sources:
                    lines.append("    Sources:")
                    for s in sig.sources:
                        lines.append(f"      • {s.get('url', '')}")
                        snippet = s.get('snippet', '')
                        if snippet:
                            lines.append(f"        {snippet[:120]}")
        lines.append("")

    lines.append(f"{'─'*60}")
    return "\n".join(lines)


def format_json(report: AuditReport) -> str:
    """Format report as JSON for machine consumption."""
    def sig_to_dict(s: SignalResult) -> dict:
        return {
            "name": s.name,
            "score": s.score,
            "label": s.label,
            "findings": s.findings,
            "actions": s.actions,
            "sources": s.sources,
            "raw": s.raw,
        }

    data = {
        "owner": report.owner,
        "repo": report.repo,
        "github_url": report.github_url,
        "api_url": report.api_url,
        "overall_score": report.overall_score,
        "grade": report.grade,
        "elapsed_seconds": report.elapsed_seconds,
        "top_actions": report.top_actions,
        "signals": [sig_to_dict(s) for s in report.signals],
        "error": report.error,
    }
    return json.dumps(data, indent=2)
