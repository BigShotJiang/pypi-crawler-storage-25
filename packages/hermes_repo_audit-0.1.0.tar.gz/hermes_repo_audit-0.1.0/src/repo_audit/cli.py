"""
CLI entry point for repo-audit.

Usage:
    repo-audit <github-url> [--json] [--verbose]
    repo-audit --help
"""

import sys
import argparse

from .audit import run_audit
from .formatter import format_text, format_json
from .github_client import PrivateRepoError, RateLimitError, GitHubError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="repo-audit",
        description=(
            "GitHub repo launch-readiness auditor.\n"
            "Checks README quality, discoverability, social proof, distribution,\n"
            "citations, docs, and launch channels. Outputs a concrete punch-list.\n\n"
            "Every signal is backed by a real source URL. No fabricated scores."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  repo-audit github.com/psf/black\n"
            "  repo-audit https://github.com/psf/black --json\n"
            "  repo-audit psf/black --verbose\n"
        ),
    )
    parser.add_argument(
        "github_url",
        metavar="GITHUB_URL",
        help="GitHub repo URL. Accepts: github.com/owner/repo, https://github.com/owner/repo, or owner/repo",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output structured JSON instead of human-readable text.",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Show per-signal findings and source URLs.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0",
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    try:
        report = run_audit(args.github_url)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        print("Run `repo-audit --help` for usage.", file=sys.stderr)
        return 2
    except PrivateRepoError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        print("Check that the repo is public and the URL is correct.", file=sys.stderr)
        return 1
    except RateLimitError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except GitHubError as exc:
        print(f"GitHub API error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nAborted.", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"Unexpected error: {exc}", file=sys.stderr)
        return 1

    if args.json:
        print(format_json(report))
    else:
        print(format_text(report, verbose=args.verbose))

    return 0


if __name__ == "__main__":
    sys.exit(main())
