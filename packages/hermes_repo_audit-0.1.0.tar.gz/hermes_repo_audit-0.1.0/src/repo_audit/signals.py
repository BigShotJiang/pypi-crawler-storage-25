"""
Signal checkers for repo launch-readiness audit.

Each check returns a SignalResult with:
  - score: 0-100
  - findings: list of (issue, action) tuples
  - sources: list of {"url": ..., "snippet": ...} — PROVENANCE REQUIRED
  - raw: any raw data for --verbose / --json

All claims must be backed by a source URL. No fabrication.
"""

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone

from .github_client import (
    get_releases, get_tags, get_root_contents,
    get_raw_file, GITHUB_API, GITHUB_RAW
)


def _ddg_search(query: str, max_results: int = 5, timeout: int = 15) -> list:
    """
    Run a DuckDuckGo text search via the public `ddgs` package.
    Returns a list of {"url": ..., "snippet": ...} dicts.
    Never raises — returns [] on any error.
    """
    try:
        from ddgs import DDGS
        with DDGS() as ddgs:
            raw = list(ddgs.text(query, max_results=max_results))
        results = []
        for r in raw:
            results.append({
                "url": r.get("href") or r.get("url") or "",
                "snippet": (r.get("body") or r.get("snippet") or "")[:200],
            })
        return results
    except Exception:
        return []


@dataclass
class SignalResult:
    name: str
    score: int  # 0-100
    label: str  # e.g. "PASS", "WARN", "FAIL"
    findings: list = field(default_factory=list)   # list of str (issues)
    actions: list = field(default_factory=list)    # list of str (concrete fixes)
    sources: list = field(default_factory=list)    # list of {url, snippet}
    raw: dict = field(default_factory=dict)


def _label(score: int) -> str:
    if score >= 80:
        return "PASS"
    if score >= 50:
        return "WARN"
    return "FAIL"


# ---------------------------------------------------------------------------
# README Quality
# ---------------------------------------------------------------------------

def check_readme(owner: str, repo: str, meta: dict) -> SignalResult:
    """
    Check README quality: length, quickstart, badges, license mention.
    Source: raw.githubusercontent.com
    """
    default_branch = meta.get("default_branch", "main")
    readme_url = f"{GITHUB_RAW}/{owner}/{repo}/{default_branch}/README.md"
    content = get_raw_file(owner, repo, "README.md", default_branch)

    findings = []
    actions = []
    sources = []
    score = 100

    if not content:
        return SignalResult(
            name="README Quality",
            score=0,
            label="FAIL",
            findings=["README.md not found"],
            actions=["Create a README.md with install instructions, quickstart, and badges."],
            sources=[{"url": readme_url, "snippet": "404 — file not present"}],
            raw={"readme_url": readme_url}
        )

    sources.append({
        "url": readme_url,
        "snippet": content[:200].replace("\n", " ")
    })

    word_count = len(content.split())
    char_count = len(content)

    # Length check
    if char_count < 500:
        findings.append(f"README is very short ({char_count} chars, {word_count} words)")
        actions.append("Expand README: add project overview, use cases, and quick-start code snippet.")
        score -= 30
    elif char_count < 1500:
        findings.append(f"README is minimal ({char_count} chars, {word_count} words)")
        actions.append("Expand README: add examples, badges, and installation section.")
        score -= 15

    # Quickstart / install
    has_quickstart = bool(re.search(r'(quick\s*start|installation|install|getting\s*started|usage)', content, re.IGNORECASE))
    has_code_block = "```" in content
    if not has_quickstart:
        findings.append("No quickstart/install section detected")
        actions.append("Add a ## Quick Start or ## Installation section with copy-paste install command.")
        score -= 20
    if not has_code_block:
        findings.append("No code blocks in README")
        actions.append("Add at least one code example block showing how to use the tool.")
        score -= 15

    # Badges
    badge_count = len(re.findall(r'\[!\[', content))
    if badge_count == 0:
        findings.append("No badges found in README")
        actions.append("Add CI/build badge (shields.io or GitHub Actions badge). Badges signal active maintenance.")
        score -= 10

    # License mention
    has_license = bool(re.search(r'licen[sc]e', content, re.IGNORECASE))
    if not has_license:
        findings.append("No license mention in README")
        actions.append("Add license info to README (e.g. '## License — MIT').")
        score -= 5

    score = max(0, score)
    return SignalResult(
        name="README Quality",
        score=score,
        label=_label(score),
        findings=findings,
        actions=actions,
        sources=sources,
        raw={
            "char_count": char_count,
            "word_count": word_count,
            "badge_count": badge_count,
            "has_quickstart": has_quickstart,
            "has_code_block": has_code_block,
            "has_license": has_license,
            "readme_url": readme_url,
        }
    )


# ---------------------------------------------------------------------------
# Social Proof (stars, forks, commit recency)
# ---------------------------------------------------------------------------

def check_social_proof(owner: str, repo: str, meta: dict) -> SignalResult:
    """
    Check stars, forks, and recent commit activity.
    Source: GitHub API
    """
    api_url = f"{GITHUB_API}/repos/{owner}/{repo}"
    stars = meta.get("stargazers_count", 0)
    forks = meta.get("forks_count", 0)
    pushed_at = meta.get("pushed_at", "")

    findings = []
    actions = []
    score = 100

    # Stars
    if stars == 0:
        findings.append("0 stars — no public social proof")
        actions.append("Share on LinkedIn, HN, or Reddit to get initial stars. Even 10 stars signals legitimacy.")
        score -= 40
    elif stars < 10:
        findings.append(f"Only {stars} stars — low visibility signal")
        actions.append("Get to 25+ stars: post Show HN, share in relevant Slack/Discord communities.")
        score -= 20
    elif stars < 50:
        score -= 5

    # Forks
    if forks == 0 and stars > 5:
        findings.append("0 forks — no downstream usage signal")
        actions.append("Create example projects / templates that fork this repo to signal reusability.")
        score -= 10

    # Recency
    if pushed_at:
        try:
            pushed_dt = datetime.fromisoformat(pushed_at.replace("Z", "+00:00"))
            days_ago = (datetime.now(timezone.utc) - pushed_dt).days
            if days_ago > 180:
                findings.append(f"Last push was {days_ago} days ago — repo looks inactive")
                actions.append("Push a commit (even a docs update) to signal active maintenance.")
                score -= 25
            elif days_ago > 60:
                findings.append(f"Last push was {days_ago} days ago — moderate activity")
                actions.append("Maintain commit cadence: at least one push per month for discovery signals.")
                score -= 10
        except (ValueError, TypeError):  # noqa: silent — malformed GitHub pushed_at timestamp; skip freshness heuristic
            pass

    score = max(0, score)
    return SignalResult(
        name="Social Proof",
        score=score,
        label=_label(score),
        findings=findings,
        actions=actions,
        sources=[{
            "url": api_url,
            "snippet": f"stargazers_count={stars}, forks_count={forks}, pushed_at={pushed_at}"
        }],
        raw={"stars": stars, "forks": forks, "pushed_at": pushed_at, "api_url": api_url}
    )


# ---------------------------------------------------------------------------
# Release Cadence
# ---------------------------------------------------------------------------

def check_release_cadence(owner: str, repo: str) -> SignalResult:
    """
    Check for GitHub releases and tags.
    Source: GitHub API releases + tags endpoints
    """
    releases_url = f"{GITHUB_API}/repos/{owner}/{repo}/releases"
    tags_url = f"{GITHUB_API}/repos/{owner}/{repo}/tags"

    releases = get_releases(owner, repo)
    tags = get_tags(owner, repo)

    findings = []
    actions = []
    score = 100
    sources = [
        {"url": releases_url, "snippet": f"{len(releases)} releases found"},
        {"url": tags_url, "snippet": f"{len(tags)} tags found"},
    ]

    if len(releases) == 0 and len(tags) == 0:
        findings.append("No GitHub releases or tags")
        actions.append("Create a v0.1.0 GitHub release. Releases appear in GitHub search and signal maturity.")
        score -= 50
    elif len(releases) == 0:
        findings.append(f"No GitHub releases (only {len(tags)} tags)")
        actions.append("Promote tags to GitHub Releases with a changelog. Releases get indexed by GitHub search.")
        score -= 25
    else:
        # Check freshness
        latest = releases[0]
        pub = latest.get("published_at", "")
        if pub:
            try:
                pub_dt = datetime.fromisoformat(pub.replace("Z", "+00:00"))
                days_ago = (datetime.now(timezone.utc) - pub_dt).days
                if days_ago > 365:
                    findings.append(f"Latest release is {days_ago} days old")
                    actions.append("Cut a new release to signal active development.")
                    score -= 20
            except (ValueError, TypeError):  # noqa: silent — malformed GitHub release published_at timestamp; skip freshness heuristic
                pass
        sources[0]["snippet"] = f"{len(releases)} releases; latest={latest.get('tag_name')} on {pub}"

    score = max(0, score)
    return SignalResult(
        name="Release Cadence",
        score=score,
        label=_label(score),
        findings=findings,
        actions=actions,
        sources=sources,
        raw={"release_count": len(releases), "tag_count": len(tags), "releases": [r.get("tag_name") for r in releases[:3]]}
    )


# ---------------------------------------------------------------------------
# Repo Metadata (topics, description)
# ---------------------------------------------------------------------------

def check_metadata(owner: str, repo: str, meta: dict) -> SignalResult:
    """
    Check GitHub topics, description, and homepage.
    Source: GitHub API
    """
    api_url = f"{GITHUB_API}/repos/{owner}/{repo}"
    topics = meta.get("topics", [])
    description = meta.get("description", "") or ""
    homepage = meta.get("homepage", "") or ""

    findings = []
    actions = []
    score = 100

    if not description:
        findings.append("No repo description set")
        actions.append("Set a repo description in GitHub repo Settings > Description. Indexed by GitHub search.")
        score -= 25

    if len(topics) == 0:
        findings.append("No topics set")
        actions.append("Add 5-10 GitHub topics in repo Settings > Topics. These are searchable and boost discovery.")
        score -= 30
    elif len(topics) < 3:
        findings.append(f"Only {len(topics)} topic(s) set — low discoverability")
        actions.append(f"Add more topics (have: {', '.join(topics)}). Aim for 6-10 relevant keywords.")
        score -= 15

    if not homepage:
        findings.append("No homepage URL set")
        actions.append("Set homepage URL (PyPI page, docs site, or landing page) in repo settings.")
        score -= 10

    score = max(0, score)
    return SignalResult(
        name="Repo Metadata",
        score=score,
        label=_label(score),
        findings=findings,
        actions=actions,
        sources=[{
            "url": api_url,
            "snippet": f"topics={topics[:5]}, description={description[:80]!r}, homepage={homepage!r}"
        }],
        raw={"topics": topics, "description": description, "homepage": homepage, "api_url": api_url}
    )


# ---------------------------------------------------------------------------
# Docs & Agent Files
# ---------------------------------------------------------------------------

def check_docs(owner: str, repo: str, meta: dict) -> SignalResult:
    """
    Check for docs/, AGENTS.md, llms.txt, CONTRIBUTING.md, etc.
    Source: GitHub contents API
    """
    default_branch = meta.get("default_branch", "main")
    contents_url = f"{GITHUB_API}/repos/{owner}/{repo}/contents/"
    root_files = get_root_contents(owner, repo, default_branch)
    names = {f["name"].lower() for f in root_files}

    findings = []
    actions = []
    score = 100
    sources = [{"url": contents_url, "snippet": f"Root files: {sorted(list(names))[:12]}"}]

    checks = [
        ("agents.md", "AGENTS.md", "Add AGENTS.md — AI coding assistants (Claude Code, Cursor, Copilot) use this for context. Increases AI-assisted discoverability."),
        ("llms.txt", "llms.txt", "Add llms.txt — emerging standard for LLM-readable project summaries. Adds AI-native discoverability."),
        ("contributing.md", "CONTRIBUTING.md", "Add CONTRIBUTING.md — signals welcoming community; required for awesome-* list inclusion."),
        ("license", "LICENSE", "Add a LICENSE file — repositories without licenses are legally unusable. Required for PyPI / npm distribution."),
        ("changelog.md", "CHANGELOG.md or CHANGELOG", "Add CHANGELOG.md — tells users what changed. Increases trust and search indexability."),
    ]

    penalty_per = 10
    for key, display, action in checks:
        found = any(v.lower() in names for v in [key, key.upper()])
        if not found:
            # Check if docs/ directory exists
            if key in ("agents.md", "llms.txt"):
                findings.append(f"{display} missing")
                actions.append(action)
                score -= 15
            else:
                findings.append(f"{display} missing")
                actions.append(action)
                score -= penalty_per

    # Check for docs/ directory
    has_docs_dir = any(f.get("type") == "dir" and f["name"].lower() == "docs" for f in root_files)
    if not has_docs_dir:
        findings.append("No docs/ directory")
        actions.append("Add a docs/ directory or link to external docs. Critical for PyPI/npm discoverability.")
        score -= 10

    score = max(0, score)
    return SignalResult(
        name="Docs & Agent Files",
        score=score,
        label=_label(score),
        findings=findings,
        actions=actions,
        sources=sources,
        raw={"root_files": sorted(list(names)), "has_docs_dir": has_docs_dir}
    )


# ---------------------------------------------------------------------------
# Distribution (PyPI / npm)
# ---------------------------------------------------------------------------

def check_distribution(owner: str, repo: str, meta: dict) -> SignalResult:
    """
    Check for PyPI or npm distribution.
    Source: pypi.org, npmjs.com public APIs.
    """
    import requests

    findings = []
    actions = []
    sources = []
    score = 0  # Start at 0 — this is a bonus signal

    pypi_url = f"https://pypi.org/pypi/{repo}/json"
    npm_url = f"https://registry.npmjs.org/{repo}"

    pypi_found = False
    npm_found = False

    # PyPI check
    try:
        resp = requests.get(pypi_url, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            version = data.get("info", {}).get("version", "?")
            summary = data.get("info", {}).get("summary", "")
            score += 70
            pypi_found = True
            sources.append({
                "url": pypi_url,
                "snippet": f"Found on PyPI: version={version}, summary={summary[:80]!r}"
            })
        else:
            sources.append({"url": pypi_url, "snippet": f"HTTP {resp.status_code} — not found on PyPI"})
    except Exception as exc:
        sources.append({"url": pypi_url, "snippet": f"Error checking PyPI: {exc}"})

    # npm check
    if not pypi_found:
        try:
            resp = requests.get(npm_url, timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                version = data.get("dist-tags", {}).get("latest", "?")
                score += 70
                npm_found = True
                sources.append({
                    "url": npm_url,
                    "snippet": f"Found on npm: latest={version}"
                })
            else:
                sources.append({"url": npm_url, "snippet": f"HTTP {resp.status_code} — not found on npm"})
        except Exception as exc:
            sources.append({"url": npm_url, "snippet": f"Error checking npm: {exc}"})

    if not pypi_found and not npm_found:
        findings.append("Not published to PyPI or npm")
        actions.append(
            "Publish to PyPI (`pip install build && python -m build && twine upload dist/*`). "
            "PyPI listing drives install discoverability significantly."
        )
        score = 20  # Partial credit if code is public
    else:
        score = min(100, score)
        # Check for download badges or stats
        if pypi_found:
            actions.append("Add PyPI download count badge to README for social proof.")

    return SignalResult(
        name="Distribution (PyPI/npm)",
        score=score,
        label=_label(score),
        findings=findings,
        actions=actions,
        sources=sources,
        raw={"pypi_found": pypi_found, "npm_found": npm_found, "pypi_url": pypi_url, "npm_url": npm_url}
    )


# ---------------------------------------------------------------------------
# Web Discoverability (DDG)
# ---------------------------------------------------------------------------

def check_web_discoverability(owner: str, repo: str, meta: dict) -> SignalResult:
    """
    Check if the repo appears in web search results for its own name/topic.
    Uses DuckDuckGo public search (ddgs package). Provenance from result URLs.
    """
    findings = []
    actions = []
    topics = meta.get("topics", [])

    # Build a targeted query
    query = f"{repo} github.com/{owner}/{repo}"
    raw_results = _ddg_search(query, max_results=8)

    sources = [r for r in raw_results if r["url"]]

    repo_url_pattern = f"github.com/{owner}/{repo}".lower()
    hits = [r for r in sources if repo_url_pattern in r["url"].lower()]

    score = 100
    if len(hits) == 0:
        findings.append(f"Repo URL not found in top search results for query: {query!r}")
        actions.append(
            f"Improve discoverability: ensure repo description contains keywords users search for. "
            f"Current topics: {topics[:5]}."
        )
        score -= 40
    elif len(hits) < 2:
        findings.append("Repo appears only once in top results (low signal)")
        actions.append("Build backlinks: mention the repo in blog posts, READMEs of related tools, and package registries.")
        score -= 15

    return SignalResult(
        name="Web Discoverability",
        score=max(0, score),
        label=_label(max(0, score)),
        findings=findings,
        actions=actions,
        sources=sources,
        raw={"query": query, "total_results": len(raw_results), "repo_hits": len(hits)}
    )


# ---------------------------------------------------------------------------
# Topical Citations (HN / Reddit / arXiv mentions via DDG)
# ---------------------------------------------------------------------------

def check_topical_citations(owner: str, repo: str, meta: dict) -> SignalResult:
    """
    Check if the repo is mentioned on HN, Reddit, or arXiv.
    Uses targeted DDG site: queries. Provenance from result URLs.
    """
    findings = []
    actions = []
    sources = []

    # Three targeted site: queries — each returns real DDG results or []
    hn_results = _ddg_search(f"site:news.ycombinator.com {repo}", max_results=5)
    reddit_results = _ddg_search(f"site:reddit.com {repo}", max_results=5)
    arxiv_results = _ddg_search(f"site:arxiv.org {repo}", max_results=3)

    hn_hits = [r for r in hn_results if "news.ycombinator.com" in r["url"]]
    reddit_hits = [r for r in reddit_results if "reddit.com" in r["url"]]
    arxiv_hits = [r for r in arxiv_results if "arxiv.org" in r["url"]]

    for r in (hn_results + reddit_results + arxiv_results)[:8]:
        if r["url"]:
            sources.append(r)

    score = 100
    if len(hn_hits) == 0:
        findings.append("No Hacker News mentions found")
        actions.append(
            f"Post 'Show HN: {repo} \u2014 <one line description>' at news.ycombinator.com. "
            "HN links drive high-quality GitHub traffic."
        )
        score -= 30

    if len(reddit_hits) == 0:
        findings.append("No Reddit mentions found")
        actions.append("Post to r/MachineLearning, r/programming, or relevant subreddits.")
        score -= 20

    if len(arxiv_hits) == 0 and meta.get("stargazers_count", 0) > 20:
        # Only flag arXiv for higher-visibility repos
        findings.append("No arXiv citations found")
        actions.append("Write a technical blog post or preprint linking to the repo to seed academic citations.")
        score -= 10

    if not findings:
        actions.append("Maintain citation presence: monitor mentions via Google Alerts for repo name.")

    score = max(0, score)
    return SignalResult(
        name="Topical Citations",
        score=score,
        label=_label(score),
        findings=findings,
        actions=actions,
        sources=sources,
        raw={
            "hn_query": f"site:news.ycombinator.com {repo}",
            "reddit_query": f"site:reddit.com {repo}",
            "arxiv_query": f"site:arxiv.org {repo}",
            "hn_hits": len(hn_hits),
            "reddit_hits": len(reddit_hits),
            "arxiv_hits": len(arxiv_hits),
        }
    )


# ---------------------------------------------------------------------------
# Launch Channels
# ---------------------------------------------------------------------------

def check_launch_channels(owner: str, repo: str, meta: dict) -> SignalResult:
    """
    Check for presence on known launch channels: DEV.to, awesome-* lists.
    Uses targeted DDG queries. Provenance from result URLs.
    """
    findings = []
    actions = []
    sources = []
    score = 100

    # Check awesome-* inclusion
    awesome_results = _ddg_search(f"awesome {repo} github list", max_results=5)
    awesome_hits = [r for r in awesome_results if "awesome" in r["url"].lower() and "github.com" in r["url"]]
    for r in awesome_results[:3]:
        if r["url"]:
            sources.append(r)

    if not awesome_hits:
        findings.append("Not found in any awesome-* lists")
        actions.append(
            "Find the relevant awesome-* list (e.g., awesome-llm, awesome-agents) and submit a PR to add this repo."
        )
        score -= 25

    # Check DEV.to
    devto_results = _ddg_search(f"{repo} site:dev.to", max_results=3)
    devto_hits = [r for r in devto_results if "dev.to" in r["url"]]
    if devto_hits:
        for r in devto_hits[:2]:
            sources.append(r)
    else:
        findings.append("No DEV.to article found for this repo")
        actions.append(
            f"Write a DEV.to post: 'Building {repo}: a <category> tool for <audience>'. "
            "DEV.to articles rank in Google and drive GitHub traffic."
        )
        score -= 20

    score = max(0, score)
    return SignalResult(
        name="Launch Channels",
        score=score,
        label=_label(score),
        findings=findings,
        actions=actions,
        sources=sources,
        raw={}
    )
