"""GitHub public API client — no auth required, 60 req/hr."""

import re
import requests
from typing import Optional


GITHUB_API = "https://api.github.com"
GITHUB_RAW = "https://raw.githubusercontent.com"
DEFAULT_TIMEOUT = 12  # seconds


class GitHubError(Exception):
    """Raised when GitHub API returns an error."""
    pass


class PrivateRepoError(GitHubError):
    """Raised for 404 (private or non-existent repos)."""
    pass


class RateLimitError(GitHubError):
    """Raised when GitHub rate limit is hit."""
    pass


def parse_github_url(url: str) -> tuple[str, str]:
    """
    Parse owner and repo from a GitHub URL.
    Accepts: github.com/owner/repo, https://github.com/owner/repo, owner/repo.
    Returns: (owner, repo) tuple.
    Raises: ValueError if URL cannot be parsed.
    """
    url = url.strip().rstrip("/")
    # Strip protocol
    url = re.sub(r"^https?://", "", url)
    # Must start with github.com/ or be owner/repo
    if url.startswith("github.com/"):
        url = url[len("github.com/"):]
    parts = url.split("/")
    if len(parts) < 2 or not parts[0] or not parts[1]:
        raise ValueError(
            f"Cannot parse GitHub URL: {url!r}. "
            "Expected format: github.com/owner/repo or owner/repo"
        )
    return parts[0], parts[1]


def _get(url: str, timeout: int = DEFAULT_TIMEOUT) -> dict:
    """Make a GET request; handle common error codes."""
    try:
        resp = requests.get(url, timeout=timeout, headers={"Accept": "application/vnd.github.v3+json"})
    except requests.exceptions.ConnectionError as exc:
        raise GitHubError(f"Network error fetching {url}: {exc}") from exc
    except requests.exceptions.Timeout as exc:
        raise GitHubError(f"Timeout fetching {url}") from exc

    if resp.status_code == 404:
        raise PrivateRepoError(f"Repo not found or private (404): {url}")
    if resp.status_code == 403:
        remaining = resp.headers.get("X-RateLimit-Remaining", "?")
        raise RateLimitError(
            f"GitHub rate limit hit (403). X-RateLimit-Remaining={remaining}. "
            "Wait ~60 min or add a GitHub token via GITHUB_TOKEN env var."
        )
    if resp.status_code != 200:
        raise GitHubError(f"GitHub API returned {resp.status_code} for {url}")
    return resp.json()


def get_repo_meta(owner: str, repo: str) -> dict:
    """Fetch repo metadata from GitHub API."""
    url = f"{GITHUB_API}/repos/{owner}/{repo}"
    return _get(url)


def get_releases(owner: str, repo: str, per_page: int = 5) -> list:
    """Fetch recent releases."""
    url = f"{GITHUB_API}/repos/{owner}/{repo}/releases?per_page={per_page}"
    try:
        return _get(url)
    except GitHubError:
        return []


def get_tags(owner: str, repo: str, per_page: int = 5) -> list:
    """Fetch tags (fallback for repos that use tags but not releases)."""
    url = f"{GITHUB_API}/repos/{owner}/{repo}/tags?per_page={per_page}"
    try:
        return _get(url)
    except GitHubError:
        return []


def get_root_contents(owner: str, repo: str, branch: str = "main") -> list:
    """Fetch root directory file listing."""
    url = f"{GITHUB_API}/repos/{owner}/{repo}/contents/"
    try:
        result = _get(url)
        if isinstance(result, list):
            return result
        return []
    except GitHubError:
        return []


def get_raw_file(owner: str, repo: str, path: str, branch: str = "main") -> Optional[str]:
    """Fetch raw file content from GitHub raw.githubusercontent.com."""
    url = f"{GITHUB_RAW}/{owner}/{repo}/{branch}/{path}"
    try:
        resp = requests.get(url, timeout=DEFAULT_TIMEOUT)
        if resp.status_code == 200:
            return resp.text
        # Try master branch as fallback
        if branch == "main":
            url2 = f"{GITHUB_RAW}/{owner}/{repo}/master/{path}"
            resp2 = requests.get(url2, timeout=DEFAULT_TIMEOUT)
            if resp2.status_code == 200:
                return resp2.text
        return None
    except requests.exceptions.RequestException:
        return None


def get_commits(owner: str, repo: str, per_page: int = 10) -> list:
    """Fetch recent commits."""
    url = f"{GITHUB_API}/repos/{owner}/{repo}/commits?per_page={per_page}"
    try:
        return _get(url)
    except GitHubError:
        return []
