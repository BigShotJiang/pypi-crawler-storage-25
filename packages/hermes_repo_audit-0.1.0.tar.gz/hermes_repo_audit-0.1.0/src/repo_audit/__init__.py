"""repo-audit: GitHub repo launch-readiness auditor."""

__version__ = "0.1.0"
__author__ = "roli-lpci"
