"""Tests for GitHub URL parsing and client helpers."""

import pytest
from unittest.mock import patch, MagicMock
from repo_audit.github_client import (
    parse_github_url,
    PrivateRepoError,
    RateLimitError,
    GitHubError,
    _get,
)


class TestParseGithubUrl:
    def test_full_https_url(self):
        owner, repo = parse_github_url("https://github.com/roli-lpci/lintlang")
        assert owner == "roli-lpci"
        assert repo == "lintlang"

    def test_no_protocol(self):
        owner, repo = parse_github_url("github.com/psf/black")
        assert owner == "psf"
        assert repo == "black"

    def test_owner_repo_only(self):
        owner, repo = parse_github_url("roli-lpci/langquant")
        assert owner == "roli-lpci"
        assert repo == "langquant"

    def test_trailing_slash_stripped(self):
        owner, repo = parse_github_url("github.com/roli-lpci/lintlang/")
        assert owner == "roli-lpci"
        assert repo == "lintlang"

    def test_invalid_url_raises(self):
        with pytest.raises(ValueError):
            parse_github_url("notarepo")

    def test_empty_owner_raises(self):
        with pytest.raises(ValueError):
            parse_github_url("github.com//lintlang")

    def test_http_url(self):
        owner, repo = parse_github_url("http://github.com/psf/black")
        assert owner == "psf"
        assert repo == "black"


class TestGetHelper:
    def test_404_raises_private_repo_error(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 404
        with patch("requests.get", return_value=mock_resp):
            with pytest.raises(PrivateRepoError):
                _get("https://api.github.com/repos/nobody/fakerepo")

    def test_403_raises_rate_limit_error(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 403
        mock_resp.headers = {"X-RateLimit-Remaining": "0"}
        with patch("requests.get", return_value=mock_resp):
            with pytest.raises(RateLimitError):
                _get("https://api.github.com/repos/owner/repo")

    def test_500_raises_github_error(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        with patch("requests.get", return_value=mock_resp):
            with pytest.raises(GitHubError):
                _get("https://api.github.com/repos/owner/repo")

    def test_200_returns_json(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"name": "lintlang", "stargazers_count": 25}
        with patch("requests.get", return_value=mock_resp):
            result = _get("https://api.github.com/repos/roli-lpci/lintlang")
            assert result["name"] == "lintlang"
            assert result["stargazers_count"] == 25
