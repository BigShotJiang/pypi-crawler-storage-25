"""
Graceful-degradation tests for hermes-seal Continuity category.

Declared in .hermes-seal.yaml under `continuity.graceful_degradation`.
Each test verifies that when an external dependency fails, repo-audit exits
with a non-zero code and a human-readable error on stderr — never a stacktrace,
never a silent success.

External dependencies that the tool must degrade on:
  - GitHub API (rate limit 403, private repo 404, network failure)
  - DuckDuckGo search (any exception → empty list, audit proceeds)
"""
from __future__ import annotations

import io
import sys
from unittest.mock import patch

import pytest

from repo_audit.cli import main
from repo_audit.github_client import GitHubError, PrivateRepoError, RateLimitError


def _run_cli(argv: list[str]) -> tuple[int, str, str]:
    """Run the CLI with argv, capture exit code + stdout + stderr."""
    stdout = io.StringIO()
    stderr = io.StringIO()
    with patch.object(sys, "argv", ["repo-audit", *argv]):
        with patch.object(sys, "stdout", stdout), patch.object(sys, "stderr", stderr):
            try:
                code = main()
            except SystemExit as e:
                code = int(e.code) if e.code is not None else 0
    return code, stdout.getvalue(), stderr.getvalue()


class TestGracefulDegradation:
    """When external dependencies fail, the tool must exit cleanly with a
    human-readable error — never crash with a stacktrace, never silently pass.
    """

    def test_rate_limit_emits_human_error_and_exits_1(self):
        """GitHub rate-limit hit mid-audit → exit 1 + actionable message on stderr."""
        err = RateLimitError(
            "GitHub rate limit hit (403). X-RateLimit-Remaining=0. "
            "Wait ~60 min or add a GitHub token via GITHUB_TOKEN env var."
        )
        with patch("repo_audit.cli.run_audit", side_effect=err):
            code, _, stderr = _run_cli(["github.com/x/y"])
        assert code == 1, f"expected exit 1, got {code}"
        assert "rate limit" in stderr.lower(), f"stderr missing rate-limit message: {stderr!r}"
        assert "GITHUB_TOKEN" in stderr, "stderr must tell the user how to recover"
        assert "Traceback" not in stderr, "stderr must not leak a stacktrace"

    def test_private_repo_emits_human_error_and_exits_1(self):
        """Private repo (GitHub 404) → exit 1 + clear explanation on stderr."""
        err = PrivateRepoError("Repo not found or private (404): https://api.github.com/repos/x/y")
        with patch("repo_audit.cli.run_audit", side_effect=err):
            code, _, stderr = _run_cli(["github.com/x/y"])
        assert code == 1
        assert "private" in stderr.lower() or "not found" in stderr.lower()
        assert "public" in stderr.lower(), "stderr must explain the tool only audits public repos"
        assert "Traceback" not in stderr

    def test_generic_github_error_emits_human_error_and_exits_1(self):
        """Any unclassified GitHub API failure → exit 1 + prefixed message, no stacktrace."""
        err = GitHubError("502 Bad Gateway")
        with patch("repo_audit.cli.run_audit", side_effect=err):
            code, _, stderr = _run_cli(["github.com/x/y"])
        assert code == 1
        assert "GitHub API error" in stderr
        assert "Traceback" not in stderr

    def test_unexpected_exception_emits_human_error_and_exits_1(self):
        """Unknown exception (e.g. network stack failure) → exit 1, prefixed, no stacktrace."""
        with patch("repo_audit.cli.run_audit", side_effect=RuntimeError("socket reset")):
            code, _, stderr = _run_cli(["github.com/x/y"])
        assert code == 1
        assert "Unexpected error" in stderr
        assert "Traceback" not in stderr, "main() must catch Exception and print a human message"

    def test_ddg_search_failure_does_not_raise(self):
        """DuckDuckGo is best-effort: any exception inside _ddg_search returns [],
        audit proceeds with an empty-results signal rather than crashing."""
        from repo_audit.signals import _ddg_search

        with patch("ddgs.DDGS", side_effect=RuntimeError("ddg network down")):
            result = _ddg_search("anything")
        assert result == [], f"expected [] on ddg failure, got {result!r}"

    def test_invalid_url_exits_2_not_1(self):
        """Clearly-invalid input → exit 2 (usage error), distinct from runtime failure (1)."""
        with patch("repo_audit.cli.run_audit", side_effect=ValueError("not a github url")):
            code, _, stderr = _run_cli(["not-a-url"])
        assert code == 2, f"expected exit 2 for ValueError (usage), got {code}"
        assert "--help" in stderr

    def test_keyboard_interrupt_exits_130(self):
        """Ctrl+C mid-audit → exit 130, conventional shell signal + ~128."""
        with patch("repo_audit.cli.run_audit", side_effect=KeyboardInterrupt):
            code, _, _ = _run_cli(["github.com/x/y"])
        assert code == 130, f"expected exit 130 for Ctrl+C, got {code}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
