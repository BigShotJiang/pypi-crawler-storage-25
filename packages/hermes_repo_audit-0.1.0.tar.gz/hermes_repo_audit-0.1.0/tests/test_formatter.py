"""Tests for output formatters."""

import json
from repo_audit.formatter import format_text, format_json
from repo_audit.audit import AuditReport
from repo_audit.signals import SignalResult


def _make_report(score=72, grade="B") -> AuditReport:
    signals = [
        SignalResult(
            name="README Quality",
            score=90,
            label="PASS",
            findings=[],
            actions=["Add download badge"],
            sources=[{"url": "https://raw.githubusercontent.com/owner/repo/main/README.md", "snippet": "# Tool"}],
        ),
        SignalResult(
            name="Social Proof",
            score=40,
            label="FAIL",
            findings=["Only 3 stars"],
            actions=["Post Show HN"],
            sources=[{"url": "https://api.github.com/repos/owner/repo", "snippet": "stars=3"}],
        ),
    ]
    return AuditReport(
        owner="owner",
        repo="repo",
        github_url="https://github.com/owner/repo",
        api_url="https://api.github.com/repos/owner/repo",
        overall_score=score,
        grade=grade,
        signals=signals,
        top_actions=["[Social Proof] Post Show HN"],
        elapsed_seconds=5.2,
    )


class TestFormatText:
    def test_contains_grade(self):
        report = _make_report()
        output = format_text(report)
        assert "B" in output

    def test_contains_repo_url(self):
        report = _make_report()
        output = format_text(report)
        assert "github.com/owner/repo" in output

    def test_contains_signal_names(self):
        report = _make_report()
        output = format_text(report)
        assert "README Quality" in output
        assert "Social Proof" in output

    def test_contains_punch_list(self):
        report = _make_report()
        output = format_text(report)
        assert "PUNCH-LIST" in output
        assert "Show HN" in output

    def test_verbose_shows_sources(self):
        report = _make_report()
        output = format_text(report, verbose=True)
        assert "api.github.com" in output

    def test_non_verbose_no_source_urls(self):
        report = _make_report()
        output = format_text(report, verbose=False)
        # Sources section shouldn't appear in non-verbose
        assert "Sources:" not in output


class TestFormatJson:
    def test_valid_json(self):
        report = _make_report()
        output = format_json(report)
        data = json.loads(output)  # Should not raise
        assert data["owner"] == "owner"
        assert data["repo"] == "repo"

    def test_contains_signals(self):
        report = _make_report()
        data = json.loads(format_json(report))
        assert len(data["signals"]) == 2
        signal_names = [s["name"] for s in data["signals"]]
        assert "README Quality" in signal_names

    def test_sources_in_json(self):
        report = _make_report()
        data = json.loads(format_json(report))
        # Every signal must have a sources list (provenance gate)
        for sig in data["signals"]:
            assert "sources" in sig
            assert isinstance(sig["sources"], list)

    def test_overall_score_present(self):
        report = _make_report(score=65, grade="C")
        data = json.loads(format_json(report))
        assert data["overall_score"] == 65
        assert data["grade"] == "C"
