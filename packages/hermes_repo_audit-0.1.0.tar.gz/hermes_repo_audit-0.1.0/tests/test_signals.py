"""Tests for individual signal checkers."""

from unittest.mock import patch, MagicMock
from repo_audit.signals import (
    check_readme,
    check_social_proof,
    check_release_cadence,
    check_metadata,
    check_docs,
    check_distribution,
)


MINIMAL_META = {
    "default_branch": "main",
    "stargazers_count": 5,
    "forks_count": 0,
    "pushed_at": "2026-04-01T10:00:00Z",
    "topics": ["python", "cli"],
    "description": "A test tool",
    "homepage": "",
    "license": {"key": "mit"},
}

RICH_META = {
    "default_branch": "main",
    "stargazers_count": 100,
    "forks_count": 20,
    "pushed_at": "2026-04-15T10:00:00Z",
    "topics": ["python", "cli", "github", "audit", "devtools", "open-source"],
    "description": "A well-described tool for auditing repos",
    "homepage": "https://hermeslabs.ai",
    "license": {"key": "apache-2.0"},
}

GOOD_README = """
# my-tool

[![CI](https://img.shields.io/badge/CI-passing-green)](https://github.com)
[![PyPI](https://img.shields.io/pypi/v/my-tool)](https://pypi.org)

A tool for doing things.

## Install

```bash
pip install my-tool
```

## Quick Start

```python
import my_tool
my_tool.run()
```

## License

MIT License.
""" * 5  # Make it long enough


class TestCheckReadme:
    def test_good_readme_passes(self):
        with patch("repo_audit.signals.get_raw_file", return_value=GOOD_README):
            result = check_readme("owner", "repo", MINIMAL_META)
        assert result.score >= 80
        assert result.label == "PASS"

    def test_missing_readme_fails(self):
        with patch("repo_audit.signals.get_raw_file", return_value=None):
            result = check_readme("owner", "repo", MINIMAL_META)
        assert result.score == 0
        assert result.label == "FAIL"
        assert len(result.findings) > 0

    def test_short_readme_penalized(self):
        with patch("repo_audit.signals.get_raw_file", return_value="# Tool\nA short readme."):
            result = check_readme("owner", "repo", MINIMAL_META)
        assert result.score < 80

    def test_sources_always_populated(self):
        with patch("repo_audit.signals.get_raw_file", return_value=GOOD_README):
            result = check_readme("owner", "repo", MINIMAL_META)
        # Provenance gate: sources must have URLs
        assert len(result.sources) > 0
        for src in result.sources:
            assert "url" in src
            assert src["url"]  # not empty

    def test_no_badges_penalized(self):
        readme_no_badges = "# Tool\n\n## Install\n\n```bash\npip install tool\n```\n\n## License\nMIT\n" * 5
        with patch("repo_audit.signals.get_raw_file", return_value=readme_no_badges):
            result = check_readme("owner", "repo", MINIMAL_META)
        # Should flag missing badges
        badge_findings = [f for f in result.findings if "badge" in f.lower()]
        assert len(badge_findings) > 0


class TestCheckSocialProof:
    def test_zero_stars_fails(self):
        meta = {**MINIMAL_META, "stargazers_count": 0}
        result = check_social_proof("owner", "repo", meta)
        assert result.score < 80
        assert any("star" in f.lower() for f in result.findings)

    def test_high_stars_passes(self):
        meta = {**RICH_META, "stargazers_count": 500}
        result = check_social_proof("owner", "repo", meta)
        assert result.score >= 80

    def test_sources_populated(self):
        result = check_social_proof("owner", "repo", MINIMAL_META)
        assert len(result.sources) > 0
        assert all(s.get("url") for s in result.sources)

    def test_stale_repo_penalized(self):
        meta = {**MINIMAL_META, "pushed_at": "2024-01-01T10:00:00Z"}
        result = check_social_proof("owner", "repo", meta)
        stale_findings = [f for f in result.findings if "days ago" in f.lower() or "inactive" in f.lower()]
        assert len(stale_findings) > 0


class TestCheckReleases:
    def test_no_releases_fails(self):
        with patch("repo_audit.signals.get_releases", return_value=[]):
            with patch("repo_audit.signals.get_tags", return_value=[]):
                result = check_release_cadence("owner", "repo")
        assert result.score < 80
        assert any("release" in f.lower() for f in result.findings)

    def test_has_releases_passes(self):
        releases = [{"tag_name": "v1.0.0", "published_at": "2026-04-01T10:00:00Z"}]
        with patch("repo_audit.signals.get_releases", return_value=releases):
            with patch("repo_audit.signals.get_tags", return_value=[]):
                result = check_release_cadence("owner", "repo")
        assert result.score >= 80

    def test_sources_include_api_urls(self):
        releases = [{"tag_name": "v0.1.0", "published_at": "2026-01-01T00:00:00Z"}]
        with patch("repo_audit.signals.get_releases", return_value=releases):
            with patch("repo_audit.signals.get_tags", return_value=[]):
                result = check_release_cadence("owner", "repo")
        urls = [s.get("url", "") for s in result.sources]
        assert any("api.github.com" in u for u in urls)


class TestCheckMetadata:
    def test_no_description_penalized(self):
        meta = {**MINIMAL_META, "description": "", "topics": []}
        result = check_metadata("owner", "repo", meta)
        assert result.score < 80

    def test_rich_metadata_passes(self):
        result = check_metadata("owner", "repo", RICH_META)
        assert result.score >= 80

    def test_no_topics_penalized(self):
        meta = {**MINIMAL_META, "topics": []}
        result = check_metadata("owner", "repo", meta)
        assert any("topic" in f.lower() for f in result.findings)


class TestCheckDocs:
    def test_missing_agents_md_flagged(self):
        root_files = [
            {"name": "README.md", "type": "file"},
            {"name": "LICENSE", "type": "file"},
        ]
        with patch("repo_audit.signals.get_root_contents", return_value=root_files):
            result = check_docs("owner", "repo", MINIMAL_META)
        agents_findings = [f for f in result.findings if "agents" in f.lower()]
        assert len(agents_findings) > 0

    def test_full_docs_setup_passes(self):
        root_files = [
            {"name": "README.md", "type": "file"},
            {"name": "AGENTS.md", "type": "file"},
            {"name": "llms.txt", "type": "file"},
            {"name": "CONTRIBUTING.md", "type": "file"},
            {"name": "LICENSE", "type": "file"},
            {"name": "CHANGELOG.md", "type": "file"},
            {"name": "docs", "type": "dir"},
        ]
        with patch("repo_audit.signals.get_root_contents", return_value=root_files):
            result = check_docs("owner", "repo", MINIMAL_META)
        assert result.score >= 80


class TestCheckDistribution:
    def test_pypi_found(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "info": {"name": "lintlang", "version": "0.2.1", "summary": "A linter"}
        }
        with patch("requests.get", return_value=mock_resp):
            result = check_distribution("owner", "lintlang", MINIMAL_META)
        assert result.score >= 70
        assert result.raw["pypi_found"] is True

    def test_not_on_pypi(self):
        mock_resp = MagicMock()
        mock_resp.status_code = 404
        with patch("requests.get", return_value=mock_resp):
            result = check_distribution("owner", "obscure-tool-xyz", MINIMAL_META)
        assert result.raw["pypi_found"] is False
        assert any("pypi" in a.lower() or "publish" in a.lower() for a in result.actions)
