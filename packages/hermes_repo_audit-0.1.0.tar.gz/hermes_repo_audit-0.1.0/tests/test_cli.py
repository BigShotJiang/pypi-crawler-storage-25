"""Tests for CLI entry point."""

import json
import pytest
from unittest.mock import patch
from repo_audit.cli import main, build_parser
from repo_audit.github_client import PrivateRepoError, RateLimitError
from repo_audit.audit import AuditReport
from repo_audit.signals import SignalResult


def _make_minimal_report() -> AuditReport:
    return AuditReport(
        owner="owner",
        repo="repo",
        github_url="https://github.com/owner/repo",
        api_url="https://api.github.com/repos/owner/repo",
        overall_score=72,
        grade="B",
        signals=[
            SignalResult(
                name="README Quality",
                score=90,
                label="PASS",
                sources=[{"url": "https://raw.githubusercontent.com/owner/repo/main/README.md", "snippet": "# Tool"}],
            )
        ],
        top_actions=["[README Quality] Add badge"],
        elapsed_seconds=3.1,
    )


class TestParser:
    def test_help_exits_zero(self):
        parser = build_parser()
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(["--help"])
        assert exc.value.code == 0

    def test_version_exits_zero(self):
        parser = build_parser()
        with pytest.raises(SystemExit) as exc:
            parser.parse_args(["--version"])
        assert exc.value.code == 0

    def test_parses_github_url(self):
        parser = build_parser()
        args = parser.parse_args(["github.com/owner/repo"])
        assert args.github_url == "github.com/owner/repo"

    def test_json_flag(self):
        parser = build_parser()
        args = parser.parse_args(["github.com/owner/repo", "--json"])
        assert args.json is True

    def test_verbose_flag(self):
        parser = build_parser()
        args = parser.parse_args(["github.com/owner/repo", "--verbose"])
        assert args.verbose is True


class TestMain:
    def test_invalid_url_returns_2(self):
        with patch("sys.argv", ["repo-audit", "notarepo"]):
            with patch("repo_audit.cli.run_audit", side_effect=ValueError("bad url")):
                code = main()
        assert code == 2

    def test_private_repo_returns_1(self):
        with patch("sys.argv", ["repo-audit", "github.com/x/private"]):
            with patch("repo_audit.cli.run_audit", side_effect=PrivateRepoError("404")):
                code = main()
        assert code == 1

    def test_rate_limit_returns_1(self):
        with patch("sys.argv", ["repo-audit", "github.com/x/repo"]):
            with patch("repo_audit.cli.run_audit", side_effect=RateLimitError("rate limit")):
                code = main()
        assert code == 1

    def test_success_returns_0(self, capsys):
        report = _make_minimal_report()
        with patch("sys.argv", ["repo-audit", "github.com/owner/repo"]):
            with patch("repo_audit.cli.run_audit", return_value=report):
                code = main()
        assert code == 0
        captured = capsys.readouterr()
        assert "owner/repo" in captured.out

    def test_json_output_is_valid(self, capsys):
        report = _make_minimal_report()
        with patch("sys.argv", ["repo-audit", "github.com/owner/repo", "--json"]):
            with patch("repo_audit.cli.run_audit", return_value=report):
                code = main()
        assert code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["overall_score"] == 72
