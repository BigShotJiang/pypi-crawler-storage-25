# INTENT.md — repo-audit

## Problem

You've built a tool and pushed it to GitHub. Now what? Most solo founders and indie hackers have no idea which signals recruiters, potential contributors, and algorithm crawlers actually use to evaluate a repo. They get 0 stars not because the tool is bad, but because it's invisible: no topics set, no PyPI page, README is 3 lines, never posted to HN. The gap between "works locally" and "discoverable publicly" is invisible and un-measured.

repo-audit measures that gap in 15 seconds.

## What It Does

Runs 9 signal checks against any public GitHub repo using only the GitHub public API (no auth required), the PyPI/npm registries, and DuckDuckGo search (via the `ddgs` package). Produces a scored punch-list — not a report to read, but a ranked to-do list you can execute.

Signals checked:
1. README Quality — length, quickstart section, code blocks, badges, license
2. Repo Metadata — description, topics count, homepage URL
3. Social Proof — star count, fork count, commit recency
4. Release Cadence — GitHub releases and tags (promotes to GitHub search)
5. Docs & Agent Files — AGENTS.md, llms.txt, CONTRIBUTING.md, CHANGELOG.md, LICENSE, docs/ dir
6. Distribution (PyPI/npm) — whether the package is installable from a registry
7. Web Discoverability — whether the repo URL appears in web search for its own name
8. Topical Citations — HN, Reddit, arXiv mentions
9. Launch Channels — awesome-* list inclusion, DEV.to articles

Every score is backed by a source URL. No fabricated metrics.

## Non-Goals

- Does NOT analyze code quality (use lintlang for that)
- Does NOT check private repos (GitHub public API only, by design)
- Does NOT post, star, or modify anything on your behalf
- Does NOT require a GitHub token (60 req/hr unauthenticated is enough for single-repo audits)
- Does NOT make up scores when data is unavailable — returns honest nulls

## Success Criteria

1. Running `repo-audit github.com/owner/repo` in <30s produces a punch-list you can act on immediately
2. Every signal score has at least one source URL you can click to verify
3. URLs cited as sources resolve with HTTP 200 (no 404s in output)
4. Tool handles private repos, rate limits, and network errors gracefully with clear messages

## Why This Tool

The GitHub launch-readiness problem is well-defined but under-tooled. Existing tools (GitHub Insights, Shields.io badge generators) tell you individual metrics; none give you a ranked action list across all dimensions. This tool treats your repo as a product launch artifact and scores it accordingly.

Pairs well with lintlang (audits agent configs) and claude-router (routes Claude API calls).
