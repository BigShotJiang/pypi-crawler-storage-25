# VERIFICATION.md — Source Provenance for Demo Claims

All URLs HEAD-checked 2026-04-19. All return HTTP 200.

---

## Demo 1: roli-lpci/lintlang (demo-lintlang.json)

### Source 1: GitHub API — repo metadata
**URL:** https://api.github.com/repos/roli-lpci/lintlang  
**Verbatim snippet (live curl 2026-04-19):**
```
"stargazers_count": 25
"topics": ["agent-configuration", "agent-testing", "ai-agents", "ai-safety", "ai-security", ...]
"description": "lintlang by Hermes Labs — static linter for AI agent configs, tool descriptions, and system prompts."
"pushed_at": "2026-04-18T18:18:57Z"
```
**Claim verified:** 25 stars, 15 topics (Repo Metadata PASS), recent push (Social Proof PASS).

### Source 2: raw.githubusercontent.com — README.md
**URL:** https://raw.githubusercontent.com/roli-lpci/lintlang/main/README.md  
**Verbatim snippet (first 3 lines):**
```
# lintlang

[![CI](https://github.com/roli-lpci/lintlang/actions/workflows/ci.yml/badge.svg)](https://github.com/roli-lpci/lintlang/actions/workflows/ci.yml)
```
**Claim verified:** README exists, has badges (badge_count=6), 8531 chars — README Quality PASS.

### Source 3: PyPI JSON API
**URL:** https://pypi.org/pypi/lintlang/json  
**Verbatim snippet:**
```
"version": "0.2.1"
"summary": "Linter for AI agent tool descriptions, system prompts, and configs. Catches vague instructions, miss..."
```
**Claim verified:** Published to PyPI at v0.2.1 — Distribution WARN (on PyPI, score=70).

---

## Demo 2: roli-lpci/claude-router (demo-claude-router.json)

### Source 1: GitHub API — repo metadata
**URL:** https://api.github.com/repos/roli-lpci/claude-router  
**Verbatim snippet (live curl 2026-04-19):**
```
"stargazers_count": 0
"topics": ["anthropic", "claude", "cost-optimization", "haiku", "llm", "model-routing", "prompt-engineering", "scaffolding"]
"description": "Route Claude API calls to the cheapest model that works. Embedding-based task classification + 5 val..."
"pushed_at": "2026-04-18T09:04:37Z"
```
**Claim verified:** 0 stars → Social Proof WARN. 8 topics → Repo Metadata PASS.

### Source 2: raw.githubusercontent.com — README.md
**URL:** https://raw.githubusercontent.com/roli-lpci/claude-router/main/README.md  
**Verbatim snippet (first 3 lines):**
```
# claude-router

Route Claude API calls to the cheapest model that works. 5 validated scaffolds, embedding-based task classification in ~10ms. Validated on 300+ blind-judged API calls.
```
**Claim verified:** README exists, has install and quickstart sections, no badges yet → README Quality score=90 (badge deduction), PASS.

### Source 3: PyPI JSON API
**URL:** https://pypi.org/pypi/claude-router/json  
**Verbatim snippet:**
```
"version": "1.0.0"
"summary": "Embedding-based scaffold router for Claude API. Routes tasks to the right scaffold using centroid ma..."
```
**Claim verified:** Published to PyPI at v1.0.0 — Distribution WARN (on PyPI, score=70).

---

## Demo 3: roli-lpci/langquant (demo-langquant.json)

### Source 1: GitHub API — repo metadata
**URL:** https://api.github.com/repos/roli-lpci/langquant  
**Verbatim snippet (live curl 2026-04-19):**
```
"stargazers_count": 0
"topics": ["ai-agents", "information-theory", "language-scaffold", "llm-memory", "lpci", ...]
"description": "LPCI PROVED: Stateless LLM maintains conversational coherence across 20 turns via refreshing languag..."
"pushed_at": "2026-04-18T09:17:03Z"
```
**Claim verified:** 0 stars → Social Proof WARN. 8 topics → Repo Metadata PASS. Recent push.

### Source 2: raw.githubusercontent.com — README.md
**URL:** https://raw.githubusercontent.com/roli-lpci/langquant/main/README.md  
**Verbatim snippet (first content lines):**
```
<p align="center">
  <a href="https://github.com/roli-lpci/langquant"><img src="https://img.shields.io/github/stars/roli-lpci/langquant" alt="GitHub stars"></a>
  <a href="https://github.com/roli-lpci/langquant/blob/main/LICENSE"><img src="https://img.shields.io/github/license/roli-lpci/langquant" alt="License"></a>
```
**Claim verified:** README exists (11526 chars), no `## Install` or `## Quick Start` heading detected → README Quality WARN (score=70). Note: badges use HTML img tags, not `[![` markdown syntax, so badge_count=0 by regex — accurate finding.

### Source 3: GitHub API — tags
**URL:** https://api.github.com/repos/roli-lpci/langquant/tags  
**Verbatim snippet:**
```
[{"name": "v0.0.8", ...}]
```
**Claim verified:** 1 tag, 0 releases → Release Cadence WARN (score=75). Action: promote tag to GitHub Release.

---

## Provenance Gate Summary

| URL | HTTP Status | Claim |
|-----|-------------|-------|
| https://api.github.com/repos/roli-lpci/lintlang | 200 | 25 stars, 15 topics |
| https://raw.githubusercontent.com/roli-lpci/lintlang/main/README.md | 200 | README exists, badges present |
| https://pypi.org/pypi/lintlang/json | 200 | v0.2.1 on PyPI |
| https://api.github.com/repos/roli-lpci/claude-router | 200 | 0 stars, 8 topics |
| https://raw.githubusercontent.com/roli-lpci/claude-router/main/README.md | 200 | README exists, no badges |
| https://pypi.org/pypi/claude-router/json | 200 | v1.0.0 on PyPI |
| https://api.github.com/repos/roli-lpci/langquant | 200 | 0 stars, 8 topics |
| https://raw.githubusercontent.com/roli-lpci/langquant/main/README.md | 200 | README 11526 chars |
| https://api.github.com/repos/roli-lpci/langquant/tags | 200 | 1 tag (v0.0.8) |

All 9 URLs return 200. No fabricated claims. No 404s in cited sources.
