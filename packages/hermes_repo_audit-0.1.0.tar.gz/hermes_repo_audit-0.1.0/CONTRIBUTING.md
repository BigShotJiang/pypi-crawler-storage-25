# Contributing to repo-audit

Thanks for your interest. Contributions are welcome.

## Setup

```bash
git clone https://github.com/roli-lpci/repo-audit
cd repo-audit
pip install -e ".[dev]"
```

## Running Tests

```bash
pytest -q
```

## Linting

```bash
ruff check .
ruff check . --fix  # auto-fix safe issues
```

## Submitting Changes

1. Fork the repo and create a branch.
2. Make your change with tests.
3. Confirm `pytest -q` and `ruff check .` both pass.
4. Open a pull request with a clear description of what changed and why.

## Scope

This tool audits GitHub repo discoverability signals. Changes that add new signals, fix scoring bugs, or improve the CLI are in scope. Changes that add private deps, business-specific heuristics, or authentication requirements are not.

## Reporting Bugs

Open a GitHub Issue with the repo URL you audited, the output you got, and what you expected.
