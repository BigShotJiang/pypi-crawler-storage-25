# AGENTS.md — repo-audit

## What It Does

`repo-audit` checks a public GitHub repo against 9 launch-readiness signals and returns a scored punch-list of what's missing for public discoverability. Every score cites a real source URL. No fabricated metrics.

## When To Use It

- Before sharing a repo publicly
- As a pre-launch CI check
- Before submitting to awesome-* lists
- When auditing a repo for quick discoverability wins

## When Not To Use It

- Private repos (returns `PrivateRepoError` immediately)
- Code quality or correctness checks (not in scope)
- Repos on GitHub Enterprise or self-hosted GitHub

## Install

```bash
pip install repo-audit
```

## Invocation

```bash
# Human-readable punch-list (default)
repo-audit github.com/owner/repo

# JSON output for parsing
repo-audit github.com/owner/repo --json

# Verbose: include per-signal findings and source URLs
repo-audit github.com/owner/repo --verbose
```

Accepts any of: `github.com/owner/repo`, `https://github.com/owner/repo`, or `owner/repo`.

## Python API

```python
from repo_audit.audit import run_audit

report = run_audit("github.com/psf/black")
print(report.overall_score)   # int 0-100
print(report.grade)           # "A" | "B" | "C" | "D" | "F"
print(report.top_actions)     # list[str] — ranked concrete actions
for signal in report.signals:
    print(signal.name, signal.score, signal.label)
    for src in signal.sources:
        print("  SOURCE:", src["url"])
```

## Output Shape (JSON)

```json
{
  "owner": "string",
  "repo": "string",
  "github_url": "string",
  "overall_score": 0,
  "grade": "A|B|C|D|F",
  "elapsed_seconds": 0.0,
  "top_actions": ["[Signal Name] Action text"],
  "signals": [
    {
      "name": "README Quality",
      "score": 0,
      "label": "PASS|WARN|FAIL",
      "findings": ["issue description"],
      "actions": ["concrete fix"],
      "sources": [{"url": "https://...", "snippet": "verbatim text"}],
      "raw": {}
    }
  ],
  "error": null
}
```

## Error Handling

| Condition | Exit code | Exception |
|---|---|---|
| Private or non-existent repo | 1 | `PrivateRepoError` |
| GitHub rate limit (403) | 1 | `RateLimitError` |
| Network error | 1 | `GitHubError` |
| Malformed URL | 2 | `ValueError` |

No GitHub token required. Unauthenticated limit is 60 req/hr — sufficient for single-repo audits.

## Signals and Weights

| Signal | Weight |
|---|---|
| README Quality | 15 |
| Repo Metadata | 12 |
| Social Proof | 10 |
| Release Cadence | 8 |
| Docs & Agent Files | 10 |
| Distribution (PyPI/npm) | 15 |
| Web Discoverability | 12 |
| Topical Citations | 10 |
| Launch Channels | 8 |

Grade thresholds: A≥85, B≥70, C≥55, D≥40, F<40.

## Known Limitations

- DDG-based signals (Web Discoverability, Topical Citations, Launch Channels) may return empty results if DDG rate-limits. Score defaults to `WARN` (50), not `FAIL`.
- Distribution check uses repo name as PyPI/npm package name — misses renamed packages.
- GitHub API unauthenticated limit is 60 req/hr. For batch audits, set `GITHUB_TOKEN` env var.

## What Counts As Success

A successful run returns an `AuditReport` with `overall_score` (0-100), a `grade`, and a `top_actions` list. Every signal has at least one `sources` entry with a real URL. `error` field is null.
