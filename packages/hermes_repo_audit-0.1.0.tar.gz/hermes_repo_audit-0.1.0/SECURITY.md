# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 0.1.x   | Yes       |

## Reporting a Vulnerability

Please do not open a public GitHub Issue for security vulnerabilities.

Email: security@roli-lpci.dev (or open a private GitHub Security Advisory).

Include:
- A description of the vulnerability
- Steps to reproduce
- Potential impact

You'll receive a response within 72 hours.

## Scope

`repo-audit` makes outbound HTTP requests to:
- `api.github.com` (read-only, public repos only)
- `raw.githubusercontent.com` (read-only)
- `pypi.org` and `registry.npmjs.org` (read-only)
- DuckDuckGo via the `ddgs` package (read-only search queries)

It does not store credentials, tokens, or user data. No GitHub token is required or stored.
