class BudgetAnalyzer:
    def __init__(self, budget, spent):
        self.budget = budget
        self.spent = spent

    def usage_percentage(self):
        if self.budget == 0:
            return 0
        return round((self.spent / self.budget) * 100, 2)

    def status(self):
        pct = self.usage_percentage()

        if pct >= 100:
            return "OVERSPENT"
        elif pct >= 80:
            return "WARNING"
        else:
            return "HEALTHY"
