class InsightGenerator:
    def generate(self, category, spent, budget):
        if budget == 0:
            return f"No budget set for {category}"

        pct = (spent / budget) * 100

        if pct > 100:
            return f"You have exceeded your {category} budget 🚨"
        elif pct > 80:
            return f"You're close to exceeding {category} budget ⚠️"
        else:
            return f"{category} spending is under control ✅"
