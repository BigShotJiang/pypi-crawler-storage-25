class SpendingPredictor:
    def __init__(self, spent, days_passed, days_in_month):
        self.spent = spent
        self.days_passed = days_passed
        self.days_in_month = days_in_month

    def projected_spend(self):
        if self.days_passed == 0:
            return 0
        daily_avg = self.spent / self.days_passed
        return round(daily_avg * self.days_in_month, 2)
