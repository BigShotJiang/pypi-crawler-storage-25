from __future__ import annotations

import asyncio
import hashlib
import logging
import sys
from pathlib import Path
from typing import Sequence

from coding_agent_telegram.agent_runner import MultiAgentRunner
from coding_agent_telegram.bot import build_application, default_bot_commands, initialize_bot_commands
from coding_agent_telegram.command_router import CommandRouter, RouterDeps
from coding_agent_telegram.config import create_initial_env_file, load_config, resolve_env_file_path
from coding_agent_telegram.i18n import translate
from coding_agent_telegram.logging_utils import setup_logging
from coding_agent_telegram.session_store import SessionStore


logger = logging.getLogger(__name__)
BOT_ID_HASH_PREFIX_LENGTH = 12


def _ensure_env_file() -> tuple[Path, str | None]:
    env_path = resolve_env_file_path()
    env_path.parent.mkdir(parents=True, exist_ok=True)
    if not env_path.exists():
        return env_path, create_initial_env_file(env_path)
    return env_path, None


def _bot_id_from_token(token: str) -> str:
    return f"bot-{hashlib.sha256(token.encode('utf-8')).hexdigest()[:BOT_ID_HASH_PREFIX_LENGTH]}"


def _env_locale_for_messages(env_path: Path) -> str:
    try:
        for raw_line in env_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            if key.strip() == "APP_LOCALE":
                return value.strip() or "en"
    except OSError:
        pass
    return "en"


async def _run_polling_apps(apps: Sequence) -> None:
    started_apps = []
    try:
        for app in apps:
            await app.initialize()
            me = await app.bot.get_me()
            logger.info(
                "Connected Telegram bot: @%s (id=%s, name=%s)",
                me.username or "unknown",
                me.id,
                me.first_name,
            )
            enable_commit_command = bool(app.bot_data.get("enable_commit_command", False))
            allowed_chat_ids = set(app.bot_data.get("allowed_chat_ids", set()))
            await initialize_bot_commands(
                app,
                enable_commit_command=enable_commit_command,
                allowed_chat_ids=allowed_chat_ids,
                locale=app.bot_data.get("locale", "en"),
            )
            logger.info(
                "Registered %d Telegram commands for %d allowed chat(s) on @%s",
                len(default_bot_commands(enable_commit_command=enable_commit_command, locale=app.bot_data.get("locale", "en"))),
                len(allowed_chat_ids),
                me.username or "unknown",
            )
            await app.start()
            if app.updater is None:
                raise RuntimeError("Telegram updater is not available.")
            await app.updater.start_polling()
            logger.info("Started polling for @%s", me.username or "unknown")
            started_apps.append(app)

        logger.info("Started %d Telegram bot(s).", len(started_apps))
        await asyncio.Event().wait()
    finally:
        for app in reversed(started_apps):
            if app.updater is not None:
                await app.updater.stop()
            await app.stop()
            await app.shutdown()


async def _run(cfg, store: SessionStore, runner: MultiAgentRunner) -> None:
    apps = []
    for token in cfg.telegram_bot_tokens:
        router = CommandRouter(RouterDeps(cfg=cfg, store=store, agent_runner=runner, bot_id=_bot_id_from_token(token)))
        app = build_application(token, router, allowed_chat_ids=cfg.allowed_chat_ids)
        app.bot_data["enable_commit_command"] = cfg.enable_commit_command
        app.bot_data["allowed_chat_ids"] = set(cfg.allowed_chat_ids)
        app.bot_data["locale"] = cfg.locale
        app.bot_data["max_telegram_message_length"] = cfg.max_telegram_message_length
        apps.append(app)

    await _run_polling_apps(apps)


def main() -> None:
    env_path, created_locale = _ensure_env_file()
    if created_locale is not None:
        print(
            translate(
                created_locale,
                "bootstrap.env_created_locale_line",
                env_path=env_path,
                app_locale=created_locale,
            ),
            file=sys.stderr,
        )
        print(
            translate(
                created_locale,
                "bootstrap.env_created_change_line",
                env_path=env_path,
            ),
            file=sys.stderr,
        )
    try:
        cfg = load_config(env_path)
    except ValueError as exc:
        locale = created_locale or _env_locale_for_messages(env_path)
        print(str(exc), file=sys.stderr)
        print("", file=sys.stderr)
        print(translate(locale, "cli.created_env_if_missing", env_path=env_path), file=sys.stderr)
        print(translate(locale, "cli.update_fields_in_env", env_path=env_path), file=sys.stderr)
        print("- WORKSPACE_ROOT", file=sys.stderr)
        print("- TELEGRAM_BOT_TOKENS", file=sys.stderr)
        print("- ALLOWED_CHAT_IDS", file=sys.stderr)
        print("", file=sys.stderr)
        print(translate(locale, "cli.then_run"), file=sys.stderr)
        raise SystemExit(1)

    log_file = setup_logging(cfg.log_level, cfg.log_dir)
    logger.info("Logging to %s", log_file)

    store = SessionStore(cfg.state_file, cfg.state_backup_file)
    runner = MultiAgentRunner(
        codex_bin=cfg.codex_bin,
        copilot_bin=cfg.copilot_bin,
        approval_policy=cfg.codex_approval_policy,
        sandbox_mode=cfg.codex_sandbox_mode,
        codex_model=cfg.codex_model,
        copilot_model=cfg.copilot_model,
        copilot_autopilot=cfg.copilot_autopilot,
        copilot_no_ask_user=cfg.copilot_no_ask_user,
        copilot_allow_all=cfg.copilot_allow_all,
        copilot_allow_all_tools=cfg.copilot_allow_all_tools,
        copilot_allow_tools=cfg.copilot_allow_tools,
        copilot_deny_tools=cfg.copilot_deny_tools,
        copilot_available_tools=cfg.copilot_available_tools,
        hard_timeout_seconds=cfg.agent_hard_timeout_seconds,
    )
    try:
        asyncio.run(_run(cfg, store, runner))
    except KeyboardInterrupt:
        logger.info("Stopping Telegram bot polling.")
