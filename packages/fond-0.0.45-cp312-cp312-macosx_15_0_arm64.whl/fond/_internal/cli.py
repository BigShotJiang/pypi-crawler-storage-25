from __future__ import annotations

import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .info import ExitCode


def main(args: list[str] | None = None) -> ExitCode:
    """Entry point for the CLI application.

    This function is executed when you type `fond` or `python -m fond`.

    If none is passed into main, it is converted to sys.argv[1:] by the args_inject decorator and
    then passed through to get_args to be parsed.

    Parameters:
        args: Arguments passed from the command line.

    Returns:
        An exit code.
    """
    if args is None:
        args = sys.argv[1:]

    from ._cmds import get_args
    from .info import ExitCode

    try:
        return get_args(args)
    except Exception as e:
        print("An error occurred while processing the command. Please check your input and try again.")
        print(f"Error details: {e}")
        return ExitCode.FAILURE


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

# ruff: noqa: PLC0415
