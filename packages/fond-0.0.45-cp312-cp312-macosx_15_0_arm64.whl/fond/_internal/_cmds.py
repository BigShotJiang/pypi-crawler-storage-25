from __future__ import annotations

from argparse import ArgumentParser, Namespace, _SubParsersAction
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from collections.abc import Callable

    from .info import ExitCode

PARSER_CHOICES: frozenset[str] = frozenset({"stdout", "file"})
ParserChoices = Literal["stdout", "file"]


def get_version(args: Namespace) -> ExitCode:
    """CLI command to get the version of the package."""
    from .info import METADATA, ExitCode

    if args.name:
        print(METADATA.full_version)
    else:
        print(METADATA.version)
    return ExitCode.SUCCESS


def bump_version(args: Namespace) -> ExitCode:
    """Bump the version of the current package.

    Args:
        args: The parsed command-line arguments.

    Returns:
        An ExitCode indicating success or failure.
    """
    from .info import _VALID_BUMP_TYPES as VALIDS, METADATA, ExitCode, _Version

    v: _Version = METADATA.version_tuple
    if args.bump_type not in VALIDS:
        print(f"Invalid argument '{args.bump_type}'. Use one of: {', '.join(VALIDS)}.")
        from .info import ExitCode

        return ExitCode.FAILURE

    if v == (0, 0, 0):
        print("Current version is 0.0.0, cannot bump version.")
        from .info import ExitCode

        return ExitCode.FAILURE
    try:
        new_version: _Version = v.new_version(args.bump_type)
        print(str(new_version))
        from .info import ExitCode

        return ExitCode.SUCCESS
    except ValueError:
        print(f"Invalid version tuple: {v}")
        from .info import ExitCode

        return ExitCode.FAILURE


def debug_info(args: Namespace) -> ExitCode:
    """CLI command to print debug information."""
    from .debug import _print_debug_info
    from .info import ExitCode

    _print_debug_info(no_color=args.no_color)

    return ExitCode.SUCCESS


def dump_nix_grammar_json(args: Namespace) -> ExitCode:
    """Dump the grammar as JSON."""
    from .info import ExitCode
    from .ts_grammar_nix import grammar

    output: str = grammar.model_dump_json(indent=2, exclude_none=True)
    match args.subcommand:
        case "stdout":
            print(output)
        case "file":
            print(f"Writing grammar JSON to {args.output}...")
            out: Path = Path(args.output).resolve()
            with out.open("w") as f:
                f.write(output)
    return ExitCode.SUCCESS


def dump_toml_grammar_json(args: Namespace) -> ExitCode:
    """Dump the grammar as JSON."""
    from .info import ExitCode
    from .ts_grammar_toml import grammar

    output: str = grammar.model_dump_json(indent=2, exclude_none=True)
    match args.subcommand:
        case "stdout":
            print(output)
        case "file":
            print(f"Writing grammar JSON to {args.output}...")
            out: Path = Path(args.output).resolve()
            with out.open("w") as f:
                f.write(output)
    return ExitCode.SUCCESS


def dump_pico8_grammar_json(args: Namespace) -> ExitCode:
    """Dump the grammar as JSON."""
    from .info import ExitCode
    from .ts_grammar_pico8 import grammar

    output: str = grammar.model_dump_json(indent=2, exclude_none=True, by_alias=True)
    match args.subcommand:
        case "stdout":
            print(output)
        case "file":
            print(f"Writing grammar JSON to {args.output}...")
            out: Path = Path(args.output).resolve()
            with out.open("w") as f:
                f.write(output)
    return ExitCode.SUCCESS


def get_include_paths(_args: Namespace) -> ExitCode:
    from fond import get_include_paths

    from .info import ExitCode

    temp: str = ""
    paths: list[Path] = get_include_paths()
    for include in paths:
        i: Path = include.resolve()
        temp += f"-I{i} "
    print(temp)
    return ExitCode.SUCCESS


def get_libs_paths(_args: Namespace) -> ExitCode:
    from fond import get_libs_paths

    from .info import ExitCode

    temp: str = ""
    paths: list[Path] = get_libs_paths()
    seen: set[str] = set()
    for lib in paths:
        li: Path = lib.resolve()
        if li.parent not in seen:
            temp += f"-L{li.parent} "
            seen.add(str(li.parent))
        temp += f"-l{li.stem} "
    print(temp)
    return ExitCode.SUCCESS


def get_so(_args: Namespace, prefix: str) -> ExitCode:
    from fond import get_libs_paths

    from .info import ExitCode

    paths: list[Path] = get_libs_paths()
    for lib in paths:
        li: Path = lib.resolve()
        if li.name.startswith(f"{prefix}_parser"):
            temp = str(li)
            print(temp)
            break
    return ExitCode.SUCCESS


def create_language_parser(
    name: str,
    subparsers: _SubParsersAction[ArgumentParser],
    dump_func: Callable[[Namespace], ExitCode],
) -> None:
    parser: ArgumentParser = subparsers.add_parser(name, help=f"Commands related to the {name} parser.")
    parser.add_argument("subcommand", choices=PARSER_CHOICES, help="The subcommand to run.")
    parser.add_argument("--output", "-o", default="grammar.json", help="The output file path.", type=str)
    parser.set_defaults(func=dump_func)
    so_help: str = f"Get the path to the parser .so file for {name}."
    so_partial: partial[ExitCode] = partial(get_so, prefix=name)
    subparsers.add_parser(f"{name}_so", help=so_help).set_defaults(func=so_partial)


def get_args(args: list[str]) -> ExitCode:
    """Parse command-line arguments."""
    from .info import _VALID_BUMP_TYPES as VALIDS

    parser = ArgumentParser(description="Pack Int CLI")
    subparsers: _SubParsersAction[ArgumentParser] = parser.add_subparsers(dest="command", required=True)

    create_language_parser("nix", subparsers, dump_nix_grammar_json)
    create_language_parser("toml", subparsers, dump_toml_grammar_json)
    create_language_parser("pico8", subparsers, dump_pico8_grammar_json)

    subparsers.add_parser("includes", help="List all include paths.").set_defaults(func=get_include_paths)
    subparsers.add_parser("libs", help="List all library paths.").set_defaults(func=get_libs_paths)

    version: ArgumentParser = subparsers.add_parser("version", help="Get the version of the package.")
    version.add_argument("--name", "-n", action="store_true", help="Print only the version name.")
    version.set_defaults(func=get_version)

    bump: ArgumentParser = subparsers.add_parser("bump", help="Bump the version of the package.")
    bump.add_argument("bump_type", type=str, choices=VALIDS, help="Type of version bump (major, minor, patch).")
    bump.set_defaults(func=bump_version)

    debug: ArgumentParser = subparsers.add_parser("debug", help="Print debug information.")
    debug.add_argument("--no-color", "-nc", action="store_true", help="Disable colored output.")
    debug.set_defaults(func=debug_info)

    parsed: Namespace = parser.parse_args(args)
    return parsed.func(parsed)


# ruff: noqa: PLC0415
