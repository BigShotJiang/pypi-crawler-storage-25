r"""PICO-8 Lua Grammar for Tree-sitter by Green Hedgie (💚🦔) on April 17th, 2026.

Defines the PICO-8 Lua grammar using the Fond Pydantic DSL.
Export to JSON with:
    fond-dev pico8 stdout > grammar.json && tree-sitter generate

PICO-8 extends standard Lua with:
  - `\\` integer division (no `//`; PICO-8 spec differs from Lua 5.3)
  - `!=` synonym for `~=`
  - `^^` synonym for `~` (xor); both supported as binary xor
  - Extra shifts/rotates: `>>>` (logical rshift), `<<>` (rotl), `>><` (rotr)
  - Unary memory-peek prefixes: `@` (peek), `%` (peek2), `$` (peek4)
  - Compound assignment:
        += -= *= /= \\= %= ^= ..= |= &= ^^= <<= >>= >>>= <<>= >><=
  - Short-form `if (cond) stmts [else stmts]` and `while (cond) stmts`
  - `?` statement-level print shorthand
  - `goto` / `::label::` (from Lua 5.2)

PICO-8 REMOVES from standard Lua:
  - Integer division `//` (replaced by `\\`)
  - The standard library (math, string, table, io, os, etc.) — lexically fine,
    just no rules needed to reserve those identifiers.
"""

from fond.ts_grammar_rules import (
    ExternalSymbol,
    GrammarRoot,
    Rules,
    alias,
    bin_op,
    choice,
    field,
    optional,
    pat,
    prec,
    prec_left,
    prec_right,
    repeat,
    repeat1,
    seq,
    string,
    sym,
    token,
)

# Operator precedence tiers (higher == binds tighter).
# Matches PICO-8's documented precedence table.
P_OR = 3
P_AND = 4
P_REL = 5  # == ~= != < <= > >=
P_BOR = 6  # |
P_BXOR = 7  # ~  ^^
P_BAND = 8  # &
P_SHIFT = 9  # << >> >>> <<> >><
P_CONCAT = 10  # ..    (right-assoc)
P_ADD = 11  # + -
P_MUL = 12  # * / % \
P_UNARY = 13  # not # - ~ @ % $
P_POW = 14  # ^     (right-assoc)

# Identifier chars: ASCII letters/digits/underscore PLUS any high-byte range
# (\x80-\xff). PICO-8's P8SCII charset uses those bytes for button glyphs
# (⬆️⬇️⬅️➡️❎🅾️), Japanese kana, shapes, etc., all of which are valid
# identifier characters in PICO-8 source code. Tree-sitter's scanner operates
# on bytes, so treating any high byte as identifier-continuable is the
# simplest and most correct match for PICO-8's "any P8SCII char is text" rule.
# Widened to the full Unicode range so PICO-8's P8SCII glyphs work as
# identifier characters — button symbols (⬆️⬇️⬅️➡️❎ in BMP), kana, shapes,
# AND emoji in the Supplementary Multilingual Plane (🅾️ = U+1F17E, 🐱 = U+1F431).
# Tree-sitter's regex compiler accepts \U-escape (capital U) for code points
# above U+FFFF.
IDENTIFIER = r"[a-zA-Z_\u0080-\U0010ffff][a-zA-Z0-9_\u0080-\U0010ffff]*"


grammar = GrammarRoot(
    name="pico8",
    rules=Rules(
        {
            # ── Program root ──────────────────────────────────────
            "program": prec(
                16,
                seq(
                    repeat(sym("_statement")),
                    optional(alias(sym("return_statement"), "module_return_statement", named=True)),
                ),
            ),
            # ── Statements ────────────────────────────────────────
            "_statement": prec_right(
                15,
                seq(
                    choice(
                        sym("variable_declaration"),
                        sym("compound_assignment"),
                        sym("function_call"),
                        sym("do_statement"),
                        sym("while_statement"),
                        sym("short_while_statement"),
                        sym("repeat_statement"),
                        sym("if_statement"),
                        sym("short_if_statement"),
                        sym("for_statement"),
                        sym("function_statement"),
                        sym("goto_statement"),
                        sym("label_statement"),
                        sym("print_statement"),
                    ),
                    optional(string(";")),
                ),
            ),
            "_last_statement": choice(
                sym("return_statement"),
                sym("break_statement"),
            ),
            "_chunk": choice(
                seq(
                    repeat1(sym("_statement")),
                    optional(sym("_last_statement")),
                ),
                sym("_last_statement"),
            ),
            "_block": sym("_chunk"),
            # ── Variable declaration (possibly local) ─────────────
            "local": string("local"),
            "variable_declaration": prec_right(
                1,
                seq(
                    optional(sym("local")),
                    seq(
                        field("name", sym("variable_declarator")),
                        repeat(seq(string(","), field("name", sym("variable_declarator")))),
                    ),
                    optional(
                        seq(
                            string("="),
                            seq(
                                field("value", sym("_expression")),
                                repeat(seq(string(","), field("value", sym("_expression")))),
                            ),
                        )
                    ),
                ),
            ),
            "variable_declarator": sym("_var"),
            "_var": prec(
                2,
                choice(
                    sym("identifier"),
                    seq(
                        sym("prefix_exp"),
                        string("["),
                        sym("_expression"),
                        string("]"),
                    ),
                    seq(sym("prefix_exp"), string("."), sym("identifier")),
                ),
            ),
            "var_list": seq(
                sym("_var"),
                repeat(seq(string(","), sym("_var"))),
            ),
            "_identifier_list": prec_right(
                -1,
                seq(
                    sym("identifier"),
                    repeat(seq(pat(r",\s*"), sym("identifier"))),
                ),
            ),
            # ── Compound assignment (PICO-8 extension) ────────────
            # LHS reuses variable_declarator; same conflict entry covers both.
            "compound_assignment": seq(
                field("name", sym("variable_declarator")),
                field(
                    "op",
                    choice(
                        string("+="),
                        string("-="),
                        string("*="),
                        string("/="),
                        string("\\="),
                        string("%="),
                        string("^="),
                        string("..="),
                        string("|="),
                        string("&="),
                        string("^^="),
                        string("<<="),
                        string(">>="),
                        string(">>>="),
                        string("<<>="),
                        string(">><="),
                    ),
                ),
                field("value", sym("_expression")),
            ),
            # ── return / break ────────────────────────────────────
            "return_statement": prec(
                2,
                seq(
                    string("return"),
                    optional(
                        seq(
                            sym("_expression"),
                            repeat(seq(string(","), sym("_expression"))),
                        )
                    ),
                ),
            ),
            "break_statement": string("break"),
            # ── Blocks: do / while / repeat / if / for ────────────
            "do_statement": seq(
                alias(string("do"), "do_start", named=True),
                optional(sym("_block")),
                alias(string("end"), "do_end", named=True),
            ),
            "while_statement": seq(
                alias(string("while"), "while_start", named=True),
                field("cond", sym("_expression")),
                alias(string("do"), "while_do", named=True),
                optional(sym("_block")),
                alias(string("end"), "while_end", named=True),
            ),
            # PICO-8 short form: `while (cond) stmt [stmt]...` (no `do`, no `end`)
            "short_while_statement": prec(
                1,
                seq(
                    alias(string("while"), "while_start", named=True),
                    string("("),
                    field("cond", sym("_expression")),
                    string(")"),
                    field("body", repeat1(sym("_statement"))),
                ),
            ),
            "repeat_statement": seq(
                alias(string("repeat"), "repeat_start", named=True),
                optional(sym("_block")),
                alias(string("until"), "repeat_until", named=True),
                sym("_expression"),
            ),
            "if_statement": seq(
                alias(string("if"), "if_start", named=True),
                field("cond", sym("_expression")),
                alias(string("then"), "if_then", named=True),
                optional(sym("_block")),
                repeat(
                    seq(
                        alias(string("elseif"), "if_elseif", named=True),
                        field("cond", sym("_expression")),
                        alias(string("then"), "if_then", named=True),
                        optional(sym("_block")),
                    )
                ),
                optional(
                    seq(
                        alias(string("else"), "if_else", named=True),
                        optional(sym("_block")),
                    )
                ),
                alias(string("end"), "if_end", named=True),
            ),
            # PICO-8 short form: `if (cond) stmt+ [else stmt+]` (no `then`, no `end`)
            # prec_right: inner `if` eats any trailing `else` (standard dangling-else resolution).
            "short_if_statement": prec_right(
                1,
                seq(
                    alias(string("if"), "if_start", named=True),
                    string("("),
                    field("cond", sym("_expression")),
                    string(")"),
                    field("consequence", repeat1(sym("_statement"))),
                    optional(
                        seq(
                            alias(string("else"), "if_else", named=True),
                            field("alternative", repeat1(sym("_statement"))),
                        )
                    ),
                ),
            ),
            "for_statement": seq(
                alias(string("for"), "for_start", named=True),
                choice(sym("for_numeric"), sym("for_generic")),
                alias(string("do"), "for_do", named=True),
                optional(sym("_block")),
                alias(string("end"), "for_end", named=True),
            ),
            "for_numeric": seq(
                field("var", sym("identifier")),
                string("="),
                field("start", sym("_expression")),
                string(","),
                field("finish", sym("_expression")),
                optional(seq(string(","), field("step", sym("_expression")))),
            ),
            "for_generic": seq(
                field(
                    "identifier_list",
                    alias(sym("_identifier_list"), "identifier_list", named=True),
                ),
                alias(string("in"), "for_in", named=True),
                field("expression_list", sym("_expression_list")),
            ),
            # ── goto / label (Lua 5.2 feature, supported by PICO-8) ─
            "goto_statement": seq(string("goto"), sym("identifier")),
            "label_statement": seq(
                string("::"),
                sym("identifier"),
                string("::"),
            ),
            # ── `?` print shorthand (statement-level) ─────────────
            "print_statement": prec(
                1,
                seq(
                    string("?"),
                    sym("_expression"),
                    repeat(seq(string(","), sym("_expression"))),
                ),
            ),
            # ── Function statement (named) ────────────────────────
            "function_start": string("function"),
            "function_statement": prec_right(
                1,
                seq(
                    choice(
                        seq(
                            alias(string("local"), "local", named=True),
                            sym("function_start"),
                            field("name", sym("identifier")),
                        ),
                        seq(
                            sym("function_start"),
                            pat(r"\s*"),
                            field("name", sym("function_name")),
                        ),
                    ),
                    sym("function_impl"),
                ),
            ),
            "function_name": seq(
                seq(
                    sym("identifier"),
                    repeat(
                        seq(
                            alias(string("."), "table_dot", named=True),
                            sym("identifier"),
                        )
                    ),
                ),
                optional(
                    seq(
                        alias(string(":"), "table_colon", named=True),
                        sym("identifier"),
                    )
                ),
            ),
            # ── Anonymous function (expression) ───────────────────
            "function": seq(sym("function_start"), sym("function_impl")),
            "function_impl": seq(
                alias(sym("left_paren"), "function_body_paren", named=True),
                optional(sym("parameter_list")),
                alias(sym("right_paren"), "function_body_paren", named=True),
                alias(optional(sym("_block")), "function_body", named=True),
                alias(string("end"), "function_end", named=True),
            ),
            "parameter_list": choice(
                seq(
                    prec_left(
                        -1,
                        seq(
                            sym("identifier"),
                            repeat(seq(pat(r",\s*"), sym("identifier"))),
                        ),
                    ),
                    optional(seq(pat(r",\s*"), sym("ellipsis"))),
                ),
                sym("ellipsis"),
            ),
            # ── Expressions ───────────────────────────────────────
            "_expression": prec_left(
                0,
                choice(
                    sym("nil"),
                    sym("boolean"),
                    sym("number"),
                    sym("string"),
                    sym("ellipsis"),
                    sym("function"),
                    sym("prefix_exp"),
                    sym("tableconstructor"),
                    sym("binary_operation"),
                    sym("unary_operation"),
                ),
            ),
            "_expression_list": seq(
                sym("_expression"),
                repeat(seq(string(","), sym("_expression"))),
            ),
            "nil": string("nil"),
            "boolean": choice(string("true"), string("false")),
            "ellipsis": string("..."),
            # ── Number (decimal / hex / binary, optional fractional) ─
            # PICO-8 numbers are 16:16 fixed point. PICO-8 itself rejects
            # scientific notation, but we accept it in decimal literals so
            # this grammar is useful for Lua-style data config files too.
            # Consumers serializing back to real .p8 cartridges should
            # enable the writer's pico8_safe mode to normalize to decimals.
            "number": token(
                choice(
                    # Hex: 0x[hex]+  optional .[hex]+
                    seq(
                        choice(string("0x"), string("0X")),
                        pat(r"[a-fA-F0-9]+"),
                        optional(seq(string("."), pat(r"[a-fA-F0-9]+"))),
                    ),
                    # Binary: 0b[01]+  optional .[01]+
                    seq(
                        choice(string("0b"), string("0B")),
                        pat(r"[01]+"),
                        optional(seq(string("."), pat(r"[01]+"))),
                    ),
                    # Decimal: digits with optional fractional, optional
                    # exponent. Or .digits with optional exponent.
                    seq(
                        choice(
                            seq(
                                pat(r"[0-9]+"),
                                optional(seq(string("."), optional(pat(r"[0-9]+")))),
                            ),
                            seq(string("."), pat(r"[0-9]+")),
                        ),
                        optional(
                            seq(
                                choice(string("e"), string("E")),
                                optional(choice(string("+"), string("-"))),
                                pat(r"[0-9]+"),
                            )
                        ),
                    ),
                )
            ),
            # ── String (handled by external scanner — same as reference) ─
            "string": seq(
                field(
                    "start",
                    alias(sym("_string_start"), "string_start", named=False),
                ),
                field(
                    "content",
                    optional(alias(sym("_string_content"), "string_content", named=False)),
                ),
                field(
                    "end",
                    alias(sym("_string_end"), "string_end", named=False),
                ),
            ),
            # ── Binary / unary operations ─────────────────────────
            "binary_operation": choice(
                # Logical
                bin_op("or", P_OR),
                bin_op("and", P_AND),
                # Relational (PICO-8 has both ~= and !=)
                bin_op("<", P_REL),
                bin_op("<=", P_REL),
                bin_op("==", P_REL),
                bin_op("~=", P_REL),
                bin_op("!=", P_REL),
                bin_op(">=", P_REL),
                bin_op(">", P_REL),
                # Bitwise
                bin_op("|", P_BOR),
                bin_op("~", P_BXOR),  # xor (Lua 5.3 spelling)
                bin_op("^^", P_BXOR),  # xor (PICO-8 spelling)
                bin_op("&", P_BAND),
                # Shifts & rotates (PICO-8 adds >>>, <<>, >><)
                bin_op("<<", P_SHIFT),
                bin_op(">>", P_SHIFT),
                bin_op(">>>", P_SHIFT),
                bin_op("<<>", P_SHIFT),
                bin_op(">><", P_SHIFT),
                # Concat (right-assoc)
                bin_op("..", P_CONCAT, right=True),
                # Additive
                bin_op("+", P_ADD),
                bin_op("-", P_ADD),
                # Multiplicative (PICO-8 uses \ for integer division, not //)
                bin_op("*", P_MUL),
                bin_op("/", P_MUL),
                bin_op("%", P_MUL),
                bin_op("\\", P_MUL),
                # Power (right-assoc)
                bin_op("^", P_POW, right=True),
            ),
            "unary_operation": prec_left(
                P_UNARY,
                seq(
                    choice(
                        string("not"),
                        string("#"),
                        string("-"),
                        string("~"),
                        string("@"),  # peek
                        string("%"),  # peek2
                        string("$"),  # peek4
                    ),
                    sym("_expression"),
                ),
            ),
            # ── Table constructor ─────────────────────────────────
            "tableconstructor": seq(
                string("{"),
                optional(sym("fieldlist")),
                string("}"),
            ),
            "fieldlist": prec(
                -1,
                seq(
                    sym("field"),
                    repeat(seq(sym("field_separator"), sym("field"))),
                    optional(sym("field_separator")),
                ),
            ),
            "field": sym("_field_expression"),
            "_field_expression": choice(
                sym("_expression_field_expression"),
                sym("_named_field_expression"),
                field("value", sym("_expression")),
            ),
            "_named_field_expression": prec(
                2,
                seq(
                    field("name", sym("identifier")),
                    string("="),
                    field("value", sym("_expression")),
                ),
            ),
            "_expression_field_expression": prec(
                2,
                seq(
                    field(
                        "field_left_bracket",
                        alias(sym("left_bracket"), "field_left_bracket", named=True),
                    ),
                    field("key", sym("_expression")),
                    field(
                        "field_right_bracket",
                        alias(sym("right_bracket"), "field_right_bracket", named=True),
                    ),
                    string("="),
                    field("value", sym("_expression")),
                ),
            ),
            "field_separator": choice(string(","), string(";")),
            # ── Prefix expressions & function calls ───────────────
            "_prefix_exp": choice(
                sym("_var"),
                sym("function_call"),
                seq(sym("left_paren"), sym("_expression"), sym("right_paren")),
            ),
            "prefix_exp": sym("_prefix_exp"),
            "function_call": prec_right(
                1,
                seq(
                    field("prefix", sym("prefix_exp")),
                    choice(sym("_args"), sym("_self_call")),
                ),
            ),
            "_args": choice(
                sym("_parentheses_call"),
                sym("_table_call"),
                sym("_string_call"),
            ),
            "_parentheses_call": seq(
                alias(sym("left_paren"), "function_call_paren", named=True),
                field("args", optional(sym("function_arguments"))),
                alias(sym("right_paren"), "function_call_paren", named=True),
            ),
            "_string_call": field("args", alias(sym("string"), "string_argument", named=True)),
            "_table_call": field("args", alias(sym("tableconstructor"), "table_argument", named=True)),
            "_self_call": seq(
                alias(string(":"), "self_call_colon", named=True),
                sym("identifier"),
                sym("_args"),
            ),
            "function_arguments": seq(
                sym("_expression"),
                optional(repeat(seq(string(","), sym("_expression")))),
            ),
            # ── Identifiers & punctuation ─────────────────────────
            "_identifier": pat(IDENTIFIER),
            "identifier": sym("_identifier"),
            "left_paren": string("("),
            "right_paren": string(")"),
            "left_bracket": string("["),
            "right_bracket": string("]"),
            # ── Comment (line comments inline; block comments via external) ─
            "comment": choice(
                seq(
                    field(
                        "start",
                        alias(string("--"), "comment_start", named=False),
                    ),
                    field(
                        "content",
                        alias(pat(r"[^\r\n]*"), "comment_content", named=False),
                    ),
                ),
                seq(
                    field(
                        "start",
                        alias(sym("_block_comment_start"), "comment_start", named=False),
                    ),
                    field(
                        "content",
                        optional(
                            alias(
                                sym("_block_comment_content"),
                                "comment_content",
                                named=False,
                            )
                        ),
                    ),
                    field(
                        "end",
                        alias(sym("_block_comment_end"), "comment_end", named=False),
                    ),
                ),
            ),
        }
    ),
    extras=[
        pat(r"[\n]"),
        pat(r"\s"),
        sym("comment"),
    ],
    conflicts=[
        # From the reference Lua grammar — a `_var` at statement start could be
        # either the LHS of assignment or the prefix of a function-call expression.
        ["variable_declarator", "_prefix_exp"],
        # Short and long forms of if/while both begin with keyword + `(expr)`;
        # disambiguated by the token after `)` (`then`/`do` → long, else short).
        # ["if_statement", "short_if_statement"],
        # ["while_statement", "short_while_statement"],
    ],
    externals=[
        ExternalSymbol(type="SYMBOL", name="_block_comment_start"),
        ExternalSymbol(type="SYMBOL", name="_block_comment_content"),
        ExternalSymbol(type="SYMBOL", name="_block_comment_end"),
        ExternalSymbol(type="SYMBOL", name="_string_start"),
        ExternalSymbol(type="SYMBOL", name="_string_content"),
        ExternalSymbol(type="SYMBOL", name="_string_end"),
    ],
    inline=[
        "_expression",
        "_field_expression",
        "field_separator",
        "prefix_exp",
        "function_impl",
        "comment",
    ],
)
