"""Generates C++ string lookup functions using switch cascades."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

from ._strings import CB, INCLUDE, OB
from .helpers import (
    Buffer,
    OrdKey,
    SortedKeywords,
    _make_key,
    _quad_comment,
    _quad_hex,
    call_clang_format,
    chunk_hex,
    read_plain_keywords,
    string_to_chunk_comment,
    string_to_chunks,
)

if TYPE_CHECKING:
    from .config import Arguments, Level


@dataclass(slots=True)
class GlobalContext:
    """Mutable global context during tree building and emission."""

    var_count: int = 0

    def tick(self) -> int:
        idx: int = self.var_count
        self.var_count += 1
        return idx

    def reset(self) -> None:
        self.var_count = 0


_ctx = GlobalContext()  # Global context instance for variable naming


@dataclass(slots=True, frozen=True)
class DispatchContext:
    """Immutable context accumulated during tree building."""

    len_checked: bool = False
    positions_checked: tuple[int, ...] = ()

    def with_len(self) -> DispatchContext:
        """Return a new context with length checked."""
        return DispatchContext(len_checked=True, positions_checked=self.positions_checked)

    def with_pos(self, positions: list[int]) -> DispatchContext:
        """Return a new context with given positions checked."""
        return DispatchContext(
            len_checked=self.len_checked,
            positions_checked=(*self.positions_checked, *tuple(positions)),
        )


Strategies = Literal["pos", "len", "match", "chunk", "direct", "verify_one"]


@dataclass(slots=True)
class DispatchNode:
    """A node in the dispatch tree. Built first, emitted second."""

    strategy: Strategies
    keywords: list[str] = field(default_factory=list)
    children: dict[int, DispatchNode] = field(default_factory=dict)
    len_checked: bool = False
    positions: list[int] = field(default_factory=list)
    key_var: str = ""


def _next_var() -> str:
    v: str = f"w{_ctx.tick()}"
    return v


def _next_key_var() -> str:
    v: str = f"key{_ctx.tick()}"
    return v


def _emit_header(buf: Buffer, include_name: str = "") -> None:
    buf.write_raw("#pragma once")
    buf.nl()
    if include_name:
        buf.write_raw(f'{INCLUDE} "{include_name}"')
    buf.write_raw(f"{INCLUDE} <string_view>")
    buf.write_raw(f"{INCLUDE} <cstddef>")
    buf.write_raw(f"{INCLUDE} <cstdint>")
    buf.write_raw(f"{INCLUDE} <cstring>")
    buf.nl()


def _build_tree(
    strings: list[str],
    levels: list[Level],
    level_idx: int,
    threshold: int,
    ctx: DispatchContext,
) -> DispatchNode:
    """Build a dispatch tree from keywords and level configuration."""
    if len(strings) == 1:
        kw: str = strings[0]
        checked: set[int] = {p % len(kw) if p >= 0 else len(kw) + p for p in ctx.positions_checked}
        unchecked: set[int] = set(range(len(kw))) - checked

        if not unchecked:
            return DispatchNode(strategy="direct", keywords=strings, len_checked=ctx.len_checked)
        if len(unchecked) == 1:
            return DispatchNode(
                strategy="verify_one",
                keywords=strings,
                positions=list(unchecked),
                len_checked=ctx.len_checked,
            )
        return DispatchNode(strategy="match", keywords=strings, len_checked=ctx.len_checked)

    if len(strings) <= threshold or level_idx >= len(levels):
        return DispatchNode(strategy="match", keywords=strings, len_checked=ctx.len_checked)

    level: Level = levels[level_idx]

    match level.strategy:
        case "match":
            return DispatchNode(strategy="match", keywords=strings, len_checked=ctx.len_checked)

        case "len":
            by_len: dict[int, list[str]] = defaultdict(list)
            for s in strings:
                by_len[len(s)].append(s)

            if len(by_len) <= 1:
                return _build_tree(strings, levels, level_idx + 1, threshold, ctx.with_len())

            node = DispatchNode(strategy="len", keywords=strings, len_checked=True)
            child_ctx: DispatchContext = ctx.with_len()
            for slen in sorted(by_len):
                child: DispatchNode = _build_tree(by_len[slen], levels, level_idx + 1, threshold, child_ctx)
                child.keywords = child.keywords or by_len[slen]
                node.children[slen] = child
            return node

        case "pos":
            positions = level.positions or [0]
            by_key: dict[int, list[str]] = defaultdict(list)
            for s in strings:
                by_key[_make_key(s, positions)].append(s)

            node = DispatchNode(strategy="pos", keywords=strings, positions=positions, key_var=_next_key_var())
            child_ctx = ctx.with_pos(positions)
            for key_val in sorted(by_key):
                child = _build_tree(by_key[key_val], levels, level_idx + 1, threshold, child_ctx)
                child.keywords = child.keywords or by_key[key_val]
                node.children[key_val] = child
            return node

        case "chunk":
            return DispatchNode(strategy="chunk", keywords=strings, len_checked=ctx.len_checked)

    return DispatchNode(strategy="match", keywords=strings)


_CPP_ESCAPE: dict[int, str] = str.maketrans(
    {"\\": "\\\\", '"': '\\"', "\n": "\\n", "\t": "\\t", "\r": "\\r", "\0": "\\0"}
)
_CPP_CHAR_ESCAPE: dict[int, str] = str.maketrans(
    {"\\": "\\\\", "'": "\\'", "\n": "\\n", "\t": "\\t", "\r": "\\r", "\0": "\\0"}
)


def _esc(s: str) -> str:
    return s.translate(_CPP_ESCAPE)


def _esc_char(c: str) -> str:
    return c.translate(_CPP_CHAR_ESCAPE)


class _Emitter:
    """Handles the difference between bool, enum, and string return styles."""

    def __init__(
        self,
        keywords: SortedKeywords,
        mode: str = "bool",
    ) -> None:
        self.keywords: SortedKeywords = keywords
        self.mode: str = mode
        self.is_bool: bool = mode == "bool"

    def _value(self, s: str) -> str:
        if self.mode == "string":
            return f'"{_esc(self.keywords[s].value)}"'
        return self.keywords[s].value

    def match(self, s: str) -> str:
        if self.is_bool:
            return f'return str == "{_esc(s)}";'
        return f'if (str == "{_esc(s)}") return {self._value(s)};'

    def match_true(self, s: str) -> str:
        if self.is_bool:
            return f'if (str == "{_esc(s)}") return true;'
        return self.match(s)

    def sole_case_return(self, s: str) -> str:
        if self.is_bool:
            return f'return str == "{_esc(s)}";'
        return f'if (str == "{_esc(s)}") return {self._value(s)}; break;'

    def direct_return(self, s: str) -> str:
        """Return value directly — prior dispatch already proved identity."""
        if self.is_bool:
            return "return true;"
        return f"return {self._value(s)};"

    def verify_one(self, s: str, pos: int) -> str:
        """Verify one remaining character then return."""
        char: str = _esc_char(s[pos])
        if self.is_bool:
            return f"if (str[{pos}] == '{char}') return true;"
        return f"if (str[{pos}] == '{char}') return {self._value(s)};"


def _emit_matches(buf: Buffer, strings: list[str], emitter: _Emitter) -> None:
    """Emit sequential matches for a small group, with break if needed."""
    if len(strings) == 1:
        buf.write(emitter.sole_case_return(strings[0]))
        return
    for s in strings:
        buf.write(emitter.match_true(s))
    buf.write("break;")


def _gen_key_expr(positions: OrdKey) -> str:
    """Generate C++ expression to pack characters at given positions into an integer."""
    parts: list[str] = []
    for i, pos in enumerate(positions):
        accessor: str = f"str[{pos}]" if pos >= 0 else ("str.back()" if pos == -1 else f"str[len{pos}]")
        shift: str = f" << {8 * i}" if i > 0 else ""
        parts.append(f"{accessor}{shift}")
    n: int = len(positions)
    if n <= 1:
        return f"static_cast<uint8_t>({parts[0]})"
    if n <= 2:
        return f"static_cast<uint16_t>({' | '.join(parts)})"
    return f"static_cast<uint32_t>({' | '.join(parts)})"


def _emit_node(buf: Buffer, node: DispatchNode, emitter: _Emitter, is_root: bool = False) -> None:
    """Emit C++ from a dispatch tree node."""
    match node.strategy:
        case "direct":
            buf.write(f"{emitter.direct_return(node.keywords[0])} break;")

        case "verify_one":
            buf.write(f"{emitter.verify_one(node.keywords[0], node.positions[0])} break;")

        case "match":
            if is_root:
                for s in node.keywords:
                    buf.write(emitter.match_true(s))
            else:
                _emit_matches(buf, node.keywords, emitter)

        case "len":
            with buf.block(f"switch (len) {OB}"):
                for slen, child in sorted(node.children.items()):
                    if child.strategy == "direct":
                        buf.write(f"case {slen}: {emitter.direct_return(child.keywords[0])} break;")
                    elif child.strategy == "verify_one":
                        buf.write(f"case {slen}: {emitter.verify_one(child.keywords[0], child.positions[0])} break;")
                    else:
                        buf.write(f"case {slen}:")
                        buf.indent()
                        temp = buf.capture()
                        _emit_node(temp, child, emitter)
                        buf.absorb(temp, scope_if_decls=True)
                        buf.dedent()
            if not is_root:
                buf.write("break;")

        case "pos":

            def _emit_pos_body() -> None:
                buf.write(f"const auto {node.key_var} = {_gen_key_expr(node.positions)};")
                with buf.block(f"switch ({node.key_var}) {OB}"):
                    for _, child in sorted(node.children.items()):
                        s0: str = child.keywords[0] if child.keywords else ""
                        buf.write(f"case {_quad_hex(s0, node.positions)}: {_quad_comment(s0, node.positions)}")
                        buf.indent()
                        temp = buf.capture()
                        _emit_node(temp, child, emitter)
                        buf.absorb(temp, scope_if_decls=True)
                        buf.dedent()

            if is_root:
                _emit_pos_body()
            else:
                with buf.block(OB):
                    _emit_pos_body()
                buf.write("break;")

        case "chunk":
            _emit_chunk(buf, node, emitter)
            if not is_root:
                buf.write("break;")


def _emit_chunk(buf: Buffer, node: DispatchNode, emitter: _Emitter) -> None:
    """Emit integer chunk comparisons from a chunk node."""
    strings: list[str] = node.keywords
    if not strings:
        return

    by_len: dict[int, list[str]] = defaultdict(list)
    for s in strings:
        by_len[len(s)].append(s)

    for slen, group in sorted(by_len.items()):
        chunks_needed: int = (slen + 7) // 8
        var_names: list[str] = []
        for i in range(chunks_needed):
            offset: int = i * 8
            remaining: int = slen - offset
            load_size: int = min(remaining, 8)
            var: str = _next_var()
            var_names.append(var)
            buf.write(f"uint64_t {var} = 0; std::memcpy(&{var}, str.data() + {offset}, {load_size});")

        for s in group:
            chunks: list[int] = string_to_chunks(s)
            comment: str = string_to_chunk_comment(s)
            if len(chunks) == 1:
                cond: str = f"{var_names[0]} == {chunk_hex(chunks[0])}"
            else:
                cond = " && ".join(f"{var_names[i]} == {chunk_hex(c)}" for i, c in enumerate(chunks))

            if not node.len_checked:
                cond = f"len == {slen} && {cond}"

            if emitter.is_bool:
                buf.write(f"if ({cond}) return true; {comment}")
            else:
                buf.write(f"if ({cond}) return {emitter._value(s)}; {comment}")


def _emit_enum(
    buf: Buffer,
    enum_name: str,
    keywords: SortedKeywords,
    sentinel: str,
    comment_keys: bool = False,
) -> None:
    """Emit an enum class definition from keyword values."""
    prefix: str = f"{enum_name}::"
    with buf.block(f"enum class {enum_name} {OB}", f"{CB};"):
        for kw in keywords.values():
            bare: str = kw.value.removeprefix(prefix)
            if comment_keys:
                buf.write(f"{bare}, // {kw.s}")
            else:
                buf.write(f"{bare},")
        buf.nl()
        buf.write(f"{sentinel},")
    buf.nl()


def _generate_core(
    name: str,
    keywords: SortedKeywords,
    return_type: str,
    default_return: str,
    emitter: _Emitter,
    levels: list[Level],
    namespace: str | None = None,
    header: bool = True,
    include_name: str = "",
    threshold: int = 3,
    create_enum: bool = False,
    enum_name: str = "",
    sentinel: str = "",
    comment_keys: bool = False,
    extra_constant: str = "",
) -> str:
    buf = Buffer()
    all_strings: list[str] = list(keywords.str_iter())

    if header:
        _emit_header(buf, include_name)

    if namespace:
        buf.write(f"namespace {namespace} {OB}")
        buf.nl()

    if extra_constant:
        buf.write(extra_constant)
        buf.nl()

    if create_enum and enum_name:
        _emit_enum(buf, enum_name, keywords, sentinel, comment_keys)

    _ctx.reset()
    tree: DispatchNode = _build_tree(all_strings, levels, 0, threshold, DispatchContext())

    with buf.block(f"static inline {return_type} {name}(std::string_view str) {OB}"):
        buf.write("const size_t len = str.size();")
        if keywords.min_len == keywords.max_len:
            buf.write(f"if (len != {keywords.min_len}) return {default_return};")
        elif keywords.min_len > 1:
            buf.write(f"if (len < {keywords.min_len} || len > {keywords.max_len}) return {default_return};")
        else:
            buf.write(f"if (len > {keywords.max_len}) return {default_return};")
        _emit_node(buf, tree, emitter, is_root=True)
        buf.write(f"return {default_return};")

    if namespace:
        buf.nl()
        buf.write(f"{CB} // namespace {namespace}")

    return buf.join() + "\n"


def switch_output(a: Arguments) -> None:
    """Generate switch-cascade lookup from pre-parsed arguments."""
    keywords: SortedKeywords = read_plain_keywords(a)

    match a.comp_mode:
        case "bool":
            emitter = _Emitter(keywords, mode="bool")
        case "enum":
            for key, kw in keywords:
                if kw.value:
                    keywords.set_value(key, f"{a.enum_name}::{kw.value}")
                else:
                    keywords.set_value(key, f"{a.enum_name}::{a.prefix}{kw.low}")
            emitter = _Emitter(keywords, mode="enum")
        case "string":
            emitter = _Emitter(keywords, mode="string")

    match a.comp_mode:
        case "bool":
            return_type = "bool"
            default_return: str = a.default_return or "false"
        case "enum":
            return_type: str = a.enum_name
            default_return = a.default_return
        case "string":
            return_type = "std::string_view"
            if a.string_return:
                default_return = f'"{a.default_return}"' if a.default_return else '""'
            else:
                default_return = a.default_return or '""'

    sentinel: str = default_return.split("::")[-1] if "::" in default_return else default_return
    result: str = _generate_core(
        name=a.func_name,
        keywords=keywords,
        return_type=return_type,
        default_return=default_return,
        emitter=emitter,
        levels=a.levels,
        namespace=a.namespace,
        include_name="" if a.create_enum else a.include_name,
        threshold=a.threshold,
        create_enum=a.create_enum,
        enum_name=a.enum_name,
        sentinel=sentinel,
        extra_constant=a.extra_constant,
    )

    if a.stdout:
        print(result)
    if a.output_enabled:
        a.output.write_text(result)
        call_clang_format(a.output)


# ruff: noqa: PLR2004 D102
