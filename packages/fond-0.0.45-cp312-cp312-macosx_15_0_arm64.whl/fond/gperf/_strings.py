from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from . import Arguments
    from .helpers import GPerfTables

OB = "{"
CB = "}"
QU = '"'
SLASH = "\\"
UINT8X16_T = "uint8x16_t"
UINT8_T = "uint8_t"
UINT16_T = "uint16_t"
UINT32_T = "uint32_t"
INCLUDE = "#include"
NS = "namespace"
INDENT = "    "
INDENT2: str = INDENT * 2
VMAXVQ_U8 = "vmaxvq_u8"


# Strategies whose generated code uses NEON intrinsics directly. If the build
# target isn't AArch64+NEON, fail at the top of the generated header with a
# clear message instead of cascading errors deep inside the lookup function.
NEEDS_NEON: frozenset[str] = frozenset({"neon", "neon_xor", "neon_strcmp", "neon_padded"})


def get_header(a: Arguments) -> str:
    requires_neon = a.string_compare in NEEDS_NEON
    header_name = a.output.name if a.output_enabled else "this header"
    neon_guard = (
        "#if !defined(__aarch64__) || !defined(__ARM_NEON)\n"
        f'#error "{header_name} currently requires AArch64 NEON. '
        'Add scalar/x86 fallback before building this target."\n'
        "#endif\n\n"
    ) if requires_neon else ""

    return (
        "#pragma once\n"
        f"{neon_guard}"
        f"{INCLUDE} <cstddef>\n"
        f"{INCLUDE} <cstring>\n"
        f'{INCLUDE} "{a.include_name}"\n'
        f'{INCLUDE} "fond/str_utils.hpp"\n'
        "#if defined(__ARM_NEON)\n"
        f"{INCLUDE} <arm_neon.h>\n"
        "#endif\n\n"
        f"{NS} {a.namespace} {OB}\n"
        f"{NS} {OB}\n"
    )


def tables_section(tables: GPerfTables, a: Arguments, pad_to: int = 0) -> str:
    from fond.gperf.helpers._extras import SIXTEEN_BYTES  # noqa: PLC0415

    if pad_to:
        struct: str = f"{INDENT}using {a.struct_name} = LookupEntry<{pad_to}, {a.enum_name}>;\n"
    else:
        struct = f"{INDENT}using {a.struct_name} = LookupEntry<MAX_WORD_LENGTH + 1, {a.enum_name}>;\n"

    wordlist = tables.wordlist
    function_signature = "const char *str, size_t len"
    if pad_to:
        from .helpers import transform_wordlist_to_padded  # noqa: PLC0415

        wordlist: str = transform_wordlist_to_padded(wordlist, pad_to)
        function_signature: str = f"PadStr<{pad_to}>& pad"

    output: str = f"{struct}" + "\n"
    output += f"{INDENT}static inline {a.enum_name} {a.func_name}({function_signature}) noexcept {OB}\n"
    if pad_to >= SIXTEEN_BYTES:
        output += f"{INDENT2}const char* str = pad.data;\n"
        output += f"{INDENT2}size_t len = pad.len;\n"
    output += f"{INDENT2}static constexpr {UINT16_T} asso_values[] = {tables.asso_values}\n"
    output += f"{INDENT2}static constexpr {a.struct_name} wordlist[] = {wordlist}\n"
    return output


def hash_section(tables: GPerfTables, a: Arguments) -> str:
    output: str = f"{INDENT2}{CB};\n"
    output += f"{INDENT}if (len > MAX_WORD_LENGTH || len < MIN_WORD_LENGTH) {OB} return {a.enum_name}::{a.default_return}; {CB}\n"
    output += f"{INDENT}{tables.hash_body}\n"
    output += f"{INDENT2}unsigned h = {tables.hash_return};\n"
    return output


def saturate_hash_check() -> str:
    return "if (h > MAX_HASH_VALUE + 1) h = MAX_HASH_VALUE + 1;\n"


def max_hash_check(a: Arguments) -> str:
    return f"if (h > MAX_HASH_VALUE) return {a.enum_name}::{a.default_return};\n"


def entry_lookup(a: Arguments) -> str:
    return f"const {a.struct_name}& entry = wordlist[h];\n"


def neon_iota_mask_xor() -> str:
    return (
        f"static constexpr {UINT8_T} iota_data[16] = {{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}};\n"
        f"{UINT8X16_T} iota = vld1q_u8(iota_data);\n"
        f"{UINT8X16_T} mask = vcltq_u8(iota, vdupq_n_u8(static_cast<{UINT8_T}>(len)));\n"
        f"{UINT8X16_T} entry_v = vld1q_u8(reinterpret_cast<const {UINT8_T}*>(entry.str));\n"
        f"{UINT8X16_T} str_v = vld1q_u8(reinterpret_cast<const {UINT8_T}*>(str));\n"
        f"{UINT8X16_T} diff = veorq_u8(entry_v, str_v);\n"
        f"{UINT8X16_T} masked_diff = vandq_u8(diff, mask);\n"
    )


def cmov_length_check_asm(a: Arguments) -> str:
    return (
        "int result = (int)entry.value;\n"
        "__asm__(\n"
        f'{INDENT}"ldrb w8, %[entry_str_at_len]\\n"\n'
        f'{INDENT}"cmp w8, #0\\n"\n'
        f'{INDENT}"csel %w[result], %w[ident], %w[result], ne\\n"\n'
        f'{INDENT}: [result]"+r"(result)\n'
        f'{INDENT}: [entry_str_at_len]"m"(entry.str[len]),\n'
        f'      [ident]"r"((int){a.enum_name}::{a.default_return})\n'
        f'{INDENT}: "cc", "x8"\n'
        ");\n"
    )


def cmov_neon_tst_asm(a: Arguments) -> str:
    """Cmov check using TST for the neon bitmask strategy."""
    return (
        "__asm__(\n"
        f'{INDENT}"tst %w[not_equal_mask], %w[mask]\\n"\n'
        f'{INDENT}"csel %w[result], %w[ident], %w[result], ne\\n"\n'
        f'{INDENT}: [result]"+r"(result)\n'
        f'{INDENT}: [not_equal_mask]"r"(not_equal_mask),\n'
        f'{INDENT}  [mask]"r"(mask),\n'
        f'      [ident]"r"((int){a.enum_name}::{a.default_return})\n'
        f'{INDENT}: "cc"\n'
        ");\n"
        f"return ({a.enum_name})result;\n"
    )


def cmov_maxdiff_asm(a: Arguments) -> str:
    """Cmov check using max_diff for xor/strcmp strategies."""
    return (
        "__asm__(\n"
        f'{INDENT}"cmp %w[max_diff], #0\\n"\n'
        f'{INDENT}"csel %w[result], %w[ident], %w[result], ne\\n"\n'
        f'{INDENT}: [result]"+r"(result)\n'
        f'{INDENT}: [max_diff]"r"((int)max_diff),\n'
        f'      [ident]"r"((int){a.enum_name}::{a.default_return})\n'
        f'{INDENT}: "cc"\n'
        ");\n"
        f"return ({a.enum_name})result;\n"
    )


def cmov_combined_asm(a: Arguments) -> str:
    """Single asm block with both length and content checks (neon_strcmp + cmov)."""
    return (
        f"{UINT8_T} max_diff = {VMAXVQ_U8}(masked_diff);\n"
        "int result = (int)entry.value;\n"
        "__asm__(\n"
        f"{INDENT}// Check length: entry.str[len] must be null terminator\n"
        f'{INDENT}"ldrb w8, %[entry_str_at_len]\\n"\n'
        f'{INDENT}"cmp w8, #0\\n"\n'
        f'{INDENT}"csel %w[result], %w[ident], %w[result], ne\\n"\n'
        f"{INDENT}// Check content: masked diff must be zero\n"
        f'{INDENT}"cmp %w[max_diff], #0\\n"\n'
        f'{INDENT}"csel %w[result], %w[ident], %w[result], ne\\n"\n'
        f'{INDENT}: [result]"+r"(result)\n'
        f'{INDENT}: [entry_str_at_len]"m"(entry.str[len]),\n'
        f'{INDENT}  [max_diff]"r"((int)max_diff),\n'
        f'      [ident]"r"((int){a.enum_name}::{a.default_return})\n'
        f'{INDENT}: "cc", "x8"\n'
        ");\n"
        f"return ({a.enum_name})result;\n"
    )


def compare_neon_padded(a: Arguments, cmov: bool) -> str:
    """NEON comparison for padded arrays.

    No length mask needed — padding is all zeros/underscores,
    and the input must also be padded. Two loads cover up to 32 bytes.
    """
    setup = (
        f"// Input must be padded to {32} bytes for safe NEON loads\n"
        f"{UINT8X16_T} entry_lo = vld1q_u8(reinterpret_cast<const {UINT8_T}*>(entry.str));\n"
        f"{UINT8X16_T} str_lo = vld1q_u8(reinterpret_cast<const {UINT8_T}*>(str));\n"
        f"{UINT8X16_T} diff_lo = veorq_u8(entry_lo, str_lo);\n"
        f"{UINT8X16_T} entry_hi = vld1q_u8(reinterpret_cast<const {UINT8_T}*>(entry.str + 16));\n"
        f"{UINT8X16_T} str_hi = vld1q_u8(reinterpret_cast<const {UINT8_T}*>(str + 16));\n"
        f"{UINT8X16_T} diff_hi = veorq_u8(entry_hi, str_hi);\n"
        f"{UINT8X16_T} combined = vorrq_u8(diff_lo, diff_hi);\n"
        f"{UINT8_T} max_diff = {VMAXVQ_U8}(combined);\n"
    )
    if cmov:
        return (
            setup
            + "int result = (int)entry.value;\n"
            + "__asm__(\n"
            + f'{INDENT}"cmp %w[max_diff], #0\\n"\n'
            + f'{INDENT}"csel %w[result], %w[ident], %w[result], ne\\n"\n'
            + f'{INDENT}: [result]"+r"(result)\n'
            + f'{INDENT}: [max_diff]"r"((int)max_diff),\n'
            + f'      [ident]"r"((int){a.enum_name}::{a.default_return})\n'
            + f'{INDENT}: "cc"\n'
            + ");\n"
            + f"return ({a.enum_name})result;\n"
        )
    return setup + "if (max_diff == 0) return entry.value;\n" + f"return {a.enum_name}::{a.default_return};\n"


def compare_memcmp() -> str:
    return "int comparison = std::memcmp(str, entry.str, len);\nif (comparison == 0) comparison = entry.str[len];\n"


def compare_check1memcmp(a: Arguments) -> str:
    return (
        f"if (entry.str[0] != str[0]) return {a.enum_name}::{a.default_return};\n"
        "int comparison = std::memcmp(str, entry.str, len);\n"
        "if (comparison == 0) comparison = entry.str[len];\n"
    )


def compare_neon(a: Arguments, cmov: bool) -> str:
    setup = (
        f"{UINT8X16_T} entry_v = vld1q_u8(reinterpret_cast<const {UINT8_T}*>(entry.str));\n"
        f"{UINT8X16_T} str_v = vld1q_u8(reinterpret_cast<const {UINT8_T}*>(str));\n"
        f"{UINT8X16_T} cmp = vceqq_u8(entry_v, str_v);\n"
        "uint16x8_t shifted = vreinterpretq_u16_u8(vandq_u8(cmp, vdupq_n_u8(0x80)));\n"
        "uint64_t lo = vgetq_lane_u64(vreinterpretq_u64_u8(vshrn_n_u16(shifted, 4)), 0);\n"
        f"{UINT32_T} inv_mask = ~({UINT32_T})0 << len;\n"
        f"{UINT32_T} mask = ~inv_mask;\n"
        f"{UINT32_T} equal_mask = static_cast<{UINT32_T}>(lo) & 0x8888'8888u;\n"
        f"{UINT32_T} not_equal_mask = ~equal_mask;\n"
    )
    if cmov:
        return setup + cmov_length_check_asm(a) + cmov_neon_tst_asm(a)
    return setup + "int comparison = mask & not_equal_mask;\nif (comparison == 0) comparison = entry.str[len];\n"


def compare_neon_xor(a: Arguments, cmov: bool) -> str:
    setup = neon_iota_mask_xor()
    if cmov:
        return (
            setup + f"{UINT8_T} max_diff = {VMAXVQ_U8}(masked_diff);\n" + cmov_length_check_asm(a) + cmov_maxdiff_asm(a)
        )
    return (
        setup + f"int comparison = {VMAXVQ_U8}(masked_diff) != 0;\nif (comparison == 0) comparison = entry.str[len];\n"
    )


def compare_neon_strcmp(a: Arguments, cmov: bool) -> str:
    setup = neon_iota_mask_xor()
    if cmov:
        return setup + cmov_combined_asm(a)
    return (
        setup + f"int comparison = {VMAXVQ_U8}(masked_diff) != 0;\nif (comparison == 0) comparison = entry.str[len];\n"
    )


def comparison_return(a: Arguments) -> str:
    return f"if (comparison == 0) return entry.value;\nreturn {a.enum_name}::{a.default_return};\n"


def footer() -> str:
    return f"{CB}\n{CB}\n{CB}\n"
