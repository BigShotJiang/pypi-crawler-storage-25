"""Macro generation utilities."""

from __future__ import annotations

from argparse import ArgumentParser, Namespace, _SubParsersAction
from pathlib import Path
import string
import sys
from typing import Literal, NoReturn

reserved: frozenset[str] = frozenset({"F"})


def gen_arg_names(n: int) -> list[str]:
    """Generates a list of argument names for macros, skipping 'f'."""
    names: list[str] = []
    letters: Literal["abcdefghijklmnopqrstuvwxyz"] = string.ascii_lowercase

    i = 0
    while len(names) < n:
        name: str = ""
        x: int = i
        while True:
            name = letters[x % 26] + name
            x = x // 26 - 1
            if x < 0:
                break

        if name not in reserved:
            names.append(name)

        i += 1

    return names


def gen_paste_macro(prefix: str, n: int) -> str:
    """Generates a macro that pastes its arguments together."""
    args: list[str] = gen_arg_names(n)
    params: str = ", ".join(["F", *args])
    body: str = " ".join(f"F({arg})" for arg in args)
    return f"#define {prefix}{n}({params}) {body}"


def gen_pick_macro(prefix: str, max_n: int) -> str:
    """Generates a macro that picks the Nth argument from a list of arguments."""
    args: str = ", ".join(f"_{i}" for i in range(1, max_n + 1))
    return f"#define {prefix}_PICK({args}, NAME, ...) NAME"


def gen_dispatch_macro(prefix: str, max_n: int) -> str:
    """Generates a macro that dispatches to the correct paste macro based on the number of arguments."""
    reversed_macros: str = ", ".join(f"{prefix}{i}" for i in range(max_n, 0, -1))
    return f"#define {prefix}(func, ...) \\\n  {prefix}_PICK(__VA_ARGS__, {reversed_macros})(func, __VA_ARGS__)"


def generate_for_each(prefix: str, max_n: int) -> str:
    """Generates the base FOR_EACH machinery (PASTE macros + PICK + dispatch)."""
    lines: list[str] = [gen_paste_macro(prefix, i) for i in range(1, max_n + 1)]
    lines.append(gen_pick_macro(prefix, max_n))
    lines.append(gen_dispatch_macro(prefix, max_n))
    return "\n".join(lines)


def generate_define(
    name: str,
    for_each: str,
    type_param: str = "Type",
    fields: list[tuple[str, str]] | None = None,
) -> str:
    """Generates a DEFINE macro that uses FOR_EACH to apply field-level macros.

    Args:
        name: the macro name, e.g. "LUA_DEFINE"
        for_each: the FOR_EACH macro to use, e.g. "FOND_FOR_EACH"
        type_param: the struct type parameter name
        fields: list of (macro_name, body_template) pairs where `{field}` is
                the placeholder for the field name and `{field_str}` for the
                stringified version. Each pair generates a field-level macro
                and a method that applies it via FOR_EACH.

    Returns:
        A string of #define macros.

    Example:
        generate_define(
            name="LUA_DEFINE",
            for_each="FOND_FOR_EACH",
            fields=[
                ("LUA_WRITE_FIELD", 'r.write_field(#{field}, {field});'),
                ("LUA_READ_FIELD", 'obj.{field} = LuaSystem::lua_get(t, #{field}, defaults.{field});'),
            ],
        )
    """
    if not fields:
        return ""

    lines: list[str] = []
    for macro_name, body in fields:
        expanded = body.replace("{field}", "FIELD").replace("#{field}", "#FIELD")
        lines.append(f"#define {macro_name}(FIELD) {expanded}")

    lines.append("")

    define_body_parts: list[str] = []
    for macro_name, _ in fields:
        define_body_parts.append(f"  {for_each}({macro_name}, __VA_ARGS__)")

    define_inner = " \\\n".join(define_body_parts)
    lines.append(f"#define {name}({type_param}, ...) \\\n{define_inner}")

    return "\n".join(lines)


def generate_header(prefix: str, max_n: int) -> str:
    """Generates a complete header file with the FOR_EACH machinery."""
    lines = [
        "#pragma once",
        "",
        generate_for_each(prefix, max_n),
        "",
        f"#define FOND_FOR_EACH(func, ...) {prefix}(func, __VA_ARGS__)",
        "",
    ]
    return "\n".join(lines)


def _write_or_print(content: str, output: Path | None) -> None:
    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(content)
        print(f"Wrote {output}")
    else:
        print(content)


def main(arguments: list[str] | None = None) -> NoReturn:
    """Command-line interface for generating macros."""
    if arguments is None:
        arguments = sys.argv[1:]

    parser = ArgumentParser(description="Generate FOND macro headers.")
    sub: _SubParsersAction[ArgumentParser] = parser.add_subparsers(dest="command", required=True)

    # --- header command ---
    header_cmd: ArgumentParser = sub.add_parser("header", help="Generate the FOND_FOR_EACH header.")
    header_cmd.add_argument("-o", "--output", type=Path, help="Write to file instead of stdout.")
    header_cmd.add_argument("-n", "--max-args", type=int, default=20, help="Max number of arguments (default: 20).")

    # --- define command ---
    define_cmd = sub.add_parser("define", help="Generate a DEFINE macro using FOND_FOR_EACH.")
    define_cmd.add_argument("name", help="Macro name, e.g. LUA_DEFINE")
    define_cmd.add_argument(
        "--field",
        action="append",
        required=True,
        metavar="NAME:BODY",
        help="Field macro as NAME:BODY (use {field} for field name, #{field} for stringified). Repeatable.",
    )
    define_cmd.add_argument("-o", "--output", type=Path, help="Write to file instead of stdout.")

    args: Namespace = parser.parse_args(arguments)

    match args.command:
        case "header":
            _write_or_print(generate_header("FOND_PASTE_", args.max_args), args.output)

        case "define":
            fields: list[tuple[str, str]] = []
            for f in args.field:
                name, _, body = f.partition(":")
                if not body:
                    parser.error(f"Invalid --field format: {f!r} (expected NAME:BODY)")
                fields.append((name.strip(), body.strip()))

            content = generate_define(
                name=args.name,
                for_each="FOND_FOR_EACH",
                fields=fields,
            )
            _write_or_print(content, args.output)
    sys.exit(0)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
