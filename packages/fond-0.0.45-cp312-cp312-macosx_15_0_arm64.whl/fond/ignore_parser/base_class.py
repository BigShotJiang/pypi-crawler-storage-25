"""Base class for handling ignore patterns and checking if files should be ignored."""

from collections.abc import Iterable, Sequence
from pathlib import Path
from typing import TYPE_CHECKING

from fond.ignore_parser.common import IgnoreConfig, SortedList, create_spec, file_to_patterns

if TYPE_CHECKING:
    from pathspec import PathSpec


class BaseIgnoreHandler:
    """Basic ignore handler for manually checking if a file should be ignored based on set patterns."""

    def __init__(self, **kwargs) -> None:
        """Initialize the IgnoreHandler with an optional ignore file."""
        self.config: IgnoreConfig = kwargs.pop("config") or IgnoreConfig().update(**kwargs)
        self.ignore_count: int = self.config.ignore_count
        self.ignore_files: Iterable[Path] = self.config.ignore_files
        self.patterns: SortedList[str] = self._create_patterns()
        self.spec: PathSpec = create_spec(self.patterns)
        self.output_as_absolute: bool = self.config.output_as_absolute

    def _create_patterns(self) -> SortedList[str]:
        """Create and return the current list of ignore patterns.

        Returns:
            List of current ignore patterns
        """
        patterns: SortedList[str] = SortedList(iterable=self.config.patterns)
        for path in self.ignore_files:
            patterns.extend(file_to_patterns(path))
        return patterns

    def add_pattern(self, pattern: str) -> None:
        """Inject a single pattern into the existing spec.

        Args:
            pattern: The pattern to inject
        """
        if pattern not in self.patterns:
            self.patterns.add(pattern)
            self.spec = create_spec(self.patterns)

    def add_patterns(self, patterns: Sequence[str]) -> None:
        """Inject additional patterns into the existing spec.

        Args:
            patterns: List of additional patterns to inject
        """
        self.patterns.extend(patterns)
        self.spec = create_spec(self.patterns)

    def should_ignore(self, path: Path | str) -> bool:
        """Check if a given path should be ignored based on the ignore patterns.

        Args:
            path (Path): The path to check
        Returns:
            bool: True if the path should be ignored, False otherwise
        """
        path = Path(path).expanduser().resolve()
        if path.is_dir() and not str(path).endswith("/"):
            return self.spec.match_file(str(path) + "/")
        return self.spec.match_file(str(path))
