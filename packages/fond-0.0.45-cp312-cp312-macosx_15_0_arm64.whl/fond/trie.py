"""Trie (prefix tree) for string lookup, prefix search, and autocomplete."""

from __future__ import annotations

from dataclasses import dataclass, field
from math import log2


@dataclass(slots=True)
class TrieNode:
    """A node in the Trie."""

    children: dict[str, TrieNode] = field(default_factory=dict)
    is_end: bool = False
    value: str = ""


@dataclass(slots=True)
class Prefixes:
    """Represents an optimal prefix for dispatching."""

    prefix: str
    entropy: float
    keyword_count: int


@dataclass(slots=True)
class Trie:
    """A Trie (prefix tree) for efficient string storage and retrieval."""

    root: TrieNode = field(default_factory=TrieNode)
    _count: int = 0

    def _walk(self, prefix: str) -> TrieNode | None:
        node: TrieNode = self.root
        for c in prefix:
            if c not in node.children:
                return None
            node = node.children[c]
        return node

    def _collect(self, node: TrieNode, prefix: str, results: list[str]) -> None:
        if node.is_end:
            results.append(prefix)
        for c in sorted(node.children):
            self._collect(node.children[c], prefix + c, results)

    def _find_branches(self, node: TrieNode, depth: int, points: list[int]) -> None:
        if len(node.children) > 1:
            points.append(depth)
        for child in node.children.values():
            self._find_branches(child, depth + 1, points)

    def _find_prefixes(self, node: TrieNode, prefix: str, prefixes: list[str]) -> None:
        if len(node.children) > 1 and prefix:
            prefixes.append(prefix)
        for c, child in sorted(node.children.items()):
            self._find_prefixes(child, prefix + c, prefixes)

    def _count_leaves(self, node: TrieNode) -> int:
        count = 1 if node.is_end else 0
        for child in node.children.values():
            count += self._count_leaves(child)
        return count

    @staticmethod
    def _entropy(groups: list[int]) -> float:
        total: int = sum(groups)
        if total == 0:
            return 0.0
        ent = 0.0
        for g in groups:
            if g > 0:
                p: float = g / total
                ent -= p * log2(p)
        return ent

    def _collect_entropy(
        self,
        node: TrieNode,
        prefix: str,
        results: list[Prefixes],
        min_char: int = 2,
    ) -> None:
        if len(node.children) > 1 and prefix:
            groups: list[int] = [self._count_leaves(child) for child in node.children.values()]
            total: int = sum(groups)
            if total > 1:
                ent: float = self._entropy(groups)
                if len(prefix) >= min_char:
                    results.append(Prefixes(prefix, ent, total))
        for c, child in sorted(node.children.items()):
            self._collect_entropy(child, prefix + c, results, min_char)

    def insert(self, word: str, value: str = "") -> None:
        """Insert a word into the Trie, optionally with an associated value."""
        node: TrieNode = self.root
        for c in word:
            if c not in node.children:
                node.children[c] = TrieNode()
            node = node.children[c]
        if not node.is_end:
            node.is_end = True
            self._count += 1
        node.value = value or word

    def contains(self, word: str) -> bool:
        """Check if a word exists in the Trie."""
        node: TrieNode | None = self._walk(word)
        return node is not None and node.is_end

    def has_prefix(self, prefix: str) -> bool:
        """Check if any word in the Trie starts with the given prefix."""
        return self._walk(prefix) is not None

    def remove(self, word: str) -> bool:
        """Remove a word from the Trie. Returns True if removed, False if not found."""
        node: TrieNode | None = self._walk(word)
        if node is None or not node.is_end:
            return False
        node.is_end = False
        self._count -= 1
        return True

    def find_all(self, prefix: str = "") -> list[str]:
        """Find all words in the Trie that start with the given prefix."""
        results: list[str] = []
        node: TrieNode | None = self._walk(prefix)
        if node:
            self._collect(node, prefix, results)
        return results

    def autocomplete(self, prefix: str, max_results: int = 10) -> list[str]:
        """Return up to max_results words that start with the given prefix."""
        results: list[str] = self.find_all(prefix)
        return results[:max_results]

    def branching_points(self) -> list[int]:
        """Return character positions where the trie forks (2+ children)."""
        points: list[int] = []
        self._find_branches(self.root, 0, points)
        return points

    def common_prefixes(self) -> list[str]:
        """Return prefixes where the trie branches — shared prefixes of the keyword set."""
        prefixes: list[str] = []
        self._find_prefixes(self.root, "", prefixes)
        return prefixes

    def optimal_prefixes(self, top_n: int = 10, min_keywords: int = 5, min_char: int = 2) -> list[Prefixes]:
        """Return the top N branching prefixes ranked by entropy.

        Each result is (prefix, entropy, keyword_count). Higher entropy means
        a more even split — better for dispatch.
        """
        results: list[Prefixes] = []
        raw_results: list[Prefixes] = []
        self._collect_entropy(self.root, "", raw_results, min_char)
        raw_results.sort(key=lambda r: r.entropy, reverse=True)
        for prefix_data in raw_results[:top_n]:
            if prefix_data.keyword_count >= min_keywords:
                results.append(prefix_data)
        return results

    @property
    def size(self) -> int:
        """Return the number of words stored in the Trie."""
        return self._count

    @property
    def empty(self) -> bool:
        """Return True if the Trie is empty."""
        return self._count == 0


# if __name__ == "__main__":
#     trie = Trie()
#     with open("src/fond/strings.txt") as f:
#         for line in f:
#             stripped = line.strip()
#             if line.startswith("#") or not stripped:
#                 continue
#             split_line = stripped.split()
#             keyword = split_line[0].strip()
#             trie.insert(keyword)

#     prefixes = trie.optimal_prefixes()

#     for p in prefixes:
#         print(f"{p.prefix}: entropy={p.entropy:.4f}, keywords={p.keyword_count}")
