#pragma once

// mtime.hpp — File modification time tracking.
//
// Tracks a set of paths and their mtimes. On next check,
// compares current mtimes to detect changes.
//
// Usage:
//   MtimeSet files;
//   files.track("src/main.bake");
//   files.track("config/settings.toml");
//   files.save("build/.mtimes");
//
//   // Later:
//   auto files = MtimeSet::load("build/.mtimes");
//   if (files.changed()) { /* something was modified */ }

#include "fond/time/clock_cast.hpp"

#include <cstdio>
#include <filesystem>
#include <vector>

namespace Fond::FileIO {

namespace fs = std::filesystem;

struct TrackedFile {
    fs::path path;
    std::int64_t mtime; // milliseconds since Unix epoch
};

class MtimeSet {
    std::vector<TrackedFile> entries_;

    static std::int64_t get_mtime(const fs::path& p) {
        if (!fs::exists(p)) return 0;
        return Fond::Chrono::to_epoch_ms(fs::last_write_time(p));
    }

public:
    MtimeSet() = default;

    void track(const fs::path& p) {entries_.push_back({fs::weakly_canonical(p), get_mtime(p)});}

    bool changed() const {
        for (const auto& e : entries_) if (get_mtime(e.path) != e.mtime) return true;
        return false;
    }

    bool empty() const { return entries_.empty(); }
    size_t size() const { return entries_.size(); }
    const std::vector<TrackedFile>& entries() const { return entries_; }

    bool save(const fs::path& path) const {
        fs::create_directories(path.parent_path());
        FILE* f = fopen(path.c_str(), "w");
        if (!f) return false;
        for (const auto& e : entries_) fprintf(f, "%s:%lld\n", e.path.c_str(), static_cast<long long>(e.mtime));
        fclose(f);
        return true;
    }

    static MtimeSet load(const fs::path& path) {
        MtimeSet result;
        FILE* f = fopen(path.c_str(), "r");
        if (!f) return result;
        char path_buf[4096];
        long long mtime;
        while (fscanf(f, "%4095[^:]:%lld\n", path_buf, &mtime) == 2) {
            result.entries_.push_back({fs::path(path_buf), static_cast<std::int64_t>(mtime)});
        }
        fclose(f);
        return result;
    }
};

} // namespace Fond::FileIO
