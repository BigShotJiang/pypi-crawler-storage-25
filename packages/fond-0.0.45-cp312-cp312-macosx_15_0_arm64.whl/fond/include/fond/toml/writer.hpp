#pragma once

#include <string>
#include <sstream>
#include <fstream>

#include "fond/str_utils.hpp"
#include "fond/toml/value.hpp"

namespace Fond::Toml {

class Writer {
    static void write_string(std::ostream& out, const TomlStr& s) {
        out << str::escape_string(std::string_view(s.data(), s.size()));
    }

    static void write_value(std::ostream& out, const TomlValue& val, int depth = 0) {
        std::visit([&](auto&& arg) {
            using T = std::decay_t<decltype(arg)>;
            if constexpr (std::is_same_v<T, TomlNone>) {
                out << toml::None;
            } else if constexpr (std::is_same_v<T, bool>) {
                out << (arg ? toml::True : toml::False);
            } else if constexpr (std::is_same_v<T, int64_t>) {
                out << arg;
            } else if constexpr (std::is_same_v<T, double>) {
                // TODO: ostringstream per float is expensive — consider snprintf or
                // std::to_chars with manual decimal point handling for hot paths.
                std::ostringstream ss;
                ss.imbue(std::locale::classic());
                ss << arg;
                auto s = ss.str();
                if (s.find('.') == std::string::npos && s.find('e') == std::string::npos) s += ".0";
                out << s;
            } else if constexpr (std::is_same_v<T, TomlStr>) {
                write_string(out, arg);
            } else if constexpr (std::is_same_v<T, toml::array>) {
                write_array(out, arg, depth);
            } else if constexpr (std::is_same_v<T, toml::table>) {
                write_inline_table(out, arg);
            }
        }, val.data);
    }

    static bool array_has_tables(const toml::array& arr) {
        for (const auto& item : arr) {
            if (item.is_table()) return true;
        }
        return false;
    }

    static void write_array(std::ostream& out, const toml::array& arr, int depth) {
        if (arr.empty()) {
            out << "[]";
            return;
        }

        bool has_tables = array_has_tables(arr);
        bool all_simple = !has_tables;

        if (all_simple && arr.size() <= 5) {
            out << '[';
            for (size_t i = 0; i < arr.size(); ++i) {
                if (i > 0) out << ", ";
                write_value(out, arr[i], depth);
            }
            out << ']';
            return;
        }

        out << "[\n";
        std::string indent((depth + 1) * 4, ' ');
        for (size_t i = 0; i < arr.size(); ++i) {
            out << indent;
            write_value(out, arr[i], depth + 1);
            out << ",\n";
        }
        out << std::string(depth * 4, ' ') << ']';
    }

    static void write_inline_table(std::ostream& out, const toml::table& tbl) {
        out << "{ ";
        bool first = true;
        for (const auto& [key, val] : tbl) {
            if (!first) out << ", ";
            out.write(key.data(), key.size());
            out << " = ";
            write_value(out, val);
            first = false;
        }
        out << " }";
    }

    // TODO: write_table builds prefix via std::string concatenation — could use
    // a pre-allocated buffer or string_view chain to avoid allocations per key.
    static void write_table(std::ostream& out, const toml::table& tbl, const std::string& prefix = "") {
        for (const auto& [key, val] : tbl) {
            if (val.is_table()) continue;
            out.write(key.data(), key.size());
            out << " = ";
            write_value(out, val);
            out << '\n';
        }

        for (const auto& [key, val] : tbl) {
            if (!val.is_table()) continue;
            auto key_str = std::string(key.data(), key.size());
            auto full_key = prefix.empty() ? key_str : prefix + "." + key_str;
            out << '\n';
            out << '[' << full_key << "]\n";
            write_table(out, val.as_table(), full_key);
        }
    }

public:
    static std::string dumps(const TomlValue& val) {
        std::ostringstream out;
        if (val.is_table()) {
            write_table(out, val.as_table());
        } else {
            write_value(out, val);
        }
        return out.str();
    }

    static void dump(const std::string& path, const TomlValue& val) {
        std::ofstream f(path);
        f << dumps(val);
    }
    static void dump(std::ostream& out, const TomlValue& val) {
        if (val.is_table()) {
            write_table(out, val.as_table());
        } else {
            write_value(out, val);
        }
    }
};

} // namespace Fond::Toml
