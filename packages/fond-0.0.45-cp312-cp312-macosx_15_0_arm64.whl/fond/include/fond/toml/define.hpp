#pragma once

#include "fond/toml/value.hpp"
#include "fond/toml/writer.hpp" // IWYU pragma: keep
#include "fond/macros/for_each.hpp"
#include <string>
#include <type_traits>
#include <vector>

namespace Fond::Toml {

template <typename T> struct is_vector : std::false_type {};
template <typename T> struct is_vector<std::vector<T>> : std::true_type {};

// Thread-local arena for TOML_DEFINE macro. Resets each call to prevent
// unbounded growth. Used internally by toml_save/toml_dumps/toml_pack_unsafe.
inline Arena& define_arena() {
    static thread_local Arena arena(4096);
    return arena;
}

template <typename T>
inline TomlValue toml_to_value(const T& val) {
    auto& arena = define_arena();
    if constexpr (std::is_same_v<T, bool>) {
        return TomlValue(val);
    } else if constexpr (std::is_same_v<T, double> || std::is_same_v<T, float>) {
        return TomlValue(static_cast<double>(val));
    } else if constexpr (std::is_same_v<T, std::string>) {
        return TomlValue(TomlStr(val.data(), val.size(), ArenaAlloc<char>(arena)));
    } else if constexpr (std::is_integral_v<T>) {
        return TomlValue(static_cast<int64_t>(val));
    } else if constexpr (is_vector<T>::value) {
        toml::array arr{ArenaAlloc<TomlValue>(arena)};
        for (const auto& item : val)
            arr.push_back(toml_to_value(item));
        return TomlValue(std::move(arr));
    } else {
        return val.toml_pack_unsafe();
    }
}

template <typename T>
inline T toml_from_value(const toml::table& tbl, const char* name, const T& fallback) {
    ArenaString key(name, ArenaAlloc<char>(define_arena()));
    auto it = tbl.find(key);
    if (it == tbl.end()) return fallback;
    const auto& val = it->second;

    if constexpr (std::is_same_v<T, bool>) {
        return val.is_bool() ? val.as_bool() : fallback;
    } else if constexpr (std::is_same_v<T, double> || std::is_same_v<T, float>) {
        if (val.is_float()) return static_cast<T>(val.as_float());
        if (val.is_int()) return static_cast<T>(val.as_int());
        return fallback;
    } else if constexpr (std::is_same_v<T, std::string>) {
        if (!val.is_string()) return fallback;
        auto& s = val.as_string();
        return std::string(s.data(), s.size());
    } else if constexpr (std::is_integral_v<T>) {
        return val.is_int() ? static_cast<T>(val.as_int()) : fallback;
    } else if constexpr (is_vector<T>::value) {
        if (!val.is_array()) return fallback;
        T result;
        for (const auto& item : val.as_array()) {
            using Elem = typename T::value_type;
            if constexpr (std::is_same_v<Elem, std::string>) {
                if (item.is_string()) { auto& s = item.as_string(); result.emplace_back(s.data(), s.size()); }
            } else if constexpr (std::is_same_v<Elem, bool>) {
                if (item.is_bool()) result.push_back(item.as_bool());
            } else if constexpr (std::is_floating_point_v<Elem>) {
                if (item.is_float()) result.push_back(static_cast<Elem>(item.as_float()));
            } else if constexpr (std::is_integral_v<Elem>) {
                if (item.is_int()) result.push_back(static_cast<Elem>(item.as_int()));
            }
        }
        return result;
    } else {
        if (val.is_table()) return T::toml_unpack(val.as_table());
        return fallback;
    }
}

} // namespace Fond::Toml

#define FOND_TOML_PACK_FIELD(FIELD) tbl_.insert(ArenaString(#FIELD, ArenaAlloc<char>(arena_)), Fond::Toml::toml_to_value(FIELD));
#define FOND_TOML_UNPACK_FIELD(FIELD) obj.FIELD = Fond::Toml::toml_from_value(tbl_, #FIELD, defaults.FIELD);
#define FOND_TOML_COUNT_FIELD(FIELD) +1

#define TOML_DEFINE(Type, ...)                                                  \
Fond::Toml::TomlValue toml_pack_unsafe() const {                                \
    auto& arena_ = Fond::Toml::define_arena();                                  \
    arena_.reset();                                                             \
    Fond::Toml::toml::table tbl_{ArenaAlloc<std::pair<const ArenaString,        \
        Fond::Toml::TomlValue>>(arena_)};                                       \
    FOND_FOR_EACH(FOND_TOML_PACK_FIELD, __VA_ARGS__)                            \
    return Fond::Toml::TomlValue(std::move(tbl_));                              \
}                                                                               \
void toml_save(const std::string& path) const {                                 \
    Fond::Toml::Writer::dump(path, toml_pack_unsafe());                         \
    Fond::Toml::define_arena().reset();                                         \
}                                                                               \
std::string toml_dumps() const {                                                \
    auto result = Fond::Toml::Writer::dumps(toml_pack_unsafe());                \
    Fond::Toml::define_arena().reset();                                         \
    return result;                                                              \
}                                                                               \
static Type toml_unpack(const Fond::Toml::toml::table& tbl_) {                  \
    Type obj{};                                                                 \
    const Type defaults{};                                                      \
    FOND_FOR_EACH(FOND_TOML_UNPACK_FIELD, __VA_ARGS__)                          \
    Fond::Toml::define_arena().reset();                                         \
    return obj;                                                                 \
}
