#pragma once

// Shadow copy of value.hpp, but with the OrderedMap-backed `table` type that
// triggers the bug we're hunting (fond brack #350). Lives in namespace
// Fond::TomlRepro so it can coexist with the working Fond::Toml.
//
// Delete this file once #350 is fixed and value.hpp goes back to OrderedMap.

#include <cstdint>
#include <functional> // IWYU pragma: keep
#include <variant>
#include <vector>

#include "fond/collections/arena.hpp"
#include "fond/collections/maps.hpp" // IWYU pragma: keep

namespace Fond::TomlRepro {

using Arena = CollectionsCub::Arena;
using TomlStr = ArenaString;

struct TomlValue;

namespace toml {
constexpr const char* True = "true";
constexpr const char* False = "false";
constexpr const char* None = "::None::";

using array = std::vector<TomlValue, ArenaAlloc<TomlValue>>;
using table = CollectionsCub::OrderedMap<ArenaString, TomlValue,
    ArenaAlloc<std::pair<const ArenaString, TomlValue>>>;
} // namespace toml

struct TomlNone {
    bool operator==(const TomlNone&) const { return true; }
};

struct TomlValue {
    std::variant<
        TomlNone,
        bool,
        int64_t,
        double,
        TomlStr,
        toml::array,
        toml::table
    > data;

    TomlValue() : data(TomlNone{}) {}
    TomlValue(TomlNone) : data(TomlNone{}) {}
    TomlValue(bool v) : data(v) {}
    TomlValue(int64_t v) : data(v) {}
    TomlValue(int v) : data(static_cast<int64_t>(v)) {}
    TomlValue(double v) : data(v) {}
    TomlValue(TomlStr v) : data(std::move(v)) {}
    TomlValue(toml::array v) : data(std::move(v)) {}
    TomlValue(toml::table v) : data(std::move(v)) {}

    TomlValue(std::string_view sv, Arena& arena)
        : data(ArenaString(sv.data(), sv.size(), ArenaAlloc<char>(arena))) {}

    bool is_none() const { return std::holds_alternative<TomlNone>(data); }
    bool is_bool() const { return std::holds_alternative<bool>(data); }
    bool is_int() const { return std::holds_alternative<int64_t>(data); }
    bool is_float() const { return std::holds_alternative<double>(data); }
    bool is_string() const { return std::holds_alternative<TomlStr>(data); }
    bool is_array() const { return std::holds_alternative<toml::array>(data); }
    bool is_table() const { return std::holds_alternative<toml::table>(data); }

    bool& as_bool() { return std::get<bool>(data); }
    int64_t& as_int() { return std::get<int64_t>(data); }
    double& as_float() { return std::get<double>(data); }
    TomlStr& as_string() { return std::get<TomlStr>(data); }
    toml::array& as_array() { return std::get<toml::array>(data); }
    toml::table& as_table() { return std::get<toml::table>(data); }

    const bool& as_bool() const { return std::get<bool>(data); }
    const int64_t& as_int() const { return std::get<int64_t>(data); }
    const double& as_float() const { return std::get<double>(data); }
    const TomlStr& as_string() const { return std::get<TomlStr>(data); }
    const toml::array& as_array() const { return std::get<toml::array>(data); }
    const toml::table& as_table() const { return std::get<toml::table>(data); }

    template <typename T>
    T get(T fallback = {}) const {
        if constexpr (std::is_same_v<T, bool>) {
            return is_bool() ? as_bool() : fallback;
        } else if constexpr (std::is_same_v<T, int64_t> || std::is_integral_v<T>) {
            return is_int() ? static_cast<T>(as_int()) : fallback;
        } else if constexpr (std::is_same_v<T, double> || std::is_floating_point_v<T>) {
            return is_float() ? static_cast<T>(as_float()) : fallback;
        } else if constexpr (std::is_same_v<T, TomlStr>) {
            return is_string() ? as_string() : fallback;
        } else {
            return fallback;
        }
    }

    TomlValue& operator[](const TomlStr& key) { return as_table()[key]; }
    TomlValue& operator[](size_t index) { return as_array()[index]; }
};

inline const TomlValue TOML_NULL = TomlValue{};
inline const TomlValue TOML_TRUE = TomlValue{true};
inline const TomlValue TOML_FALSE = TomlValue{false};

} // namespace Fond::TomlRepro
