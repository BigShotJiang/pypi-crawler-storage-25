#pragma once

#include "fond/toml/value.hpp"
#include "fond/py_tools/py_convert.hpp"

namespace Fond::PyTools {

template <>
struct ValueTraits<Fond::Toml::TomlValue> {
    using none_type = Fond::Toml::TomlNone;
    using array_type = Fond::Toml::toml::array;
    using map_type = Fond::Toml::toml::table;
    using string_type = ArenaString;
    using arena_type = CollectionsCub::Arena;
    template <typename T> using alloc_type = ArenaAlloc<T>;
    static constexpr bool has_uint64 = false;
};

} // namespace Fond::PyTools
