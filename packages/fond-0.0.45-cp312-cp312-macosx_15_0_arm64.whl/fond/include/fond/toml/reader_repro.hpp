#pragma once

// Shadow copy of reader.hpp paired with value_repro.hpp's OrderedMap-backed
// table type. Used by tests/cpp/test_toml_shape.cpp to reproduce the bug
// tracked in fond brack #350. Delete alongside value_repro.hpp once fixed.

#include <dlfcn.h>
#include "fond/cpp_tree_sitter.hpp"
#include "fond/file_io/ops.hpp"
#include "fond/toml/value_repro.hpp"
#include "fond/toml/ast_symbols.hpp"
#include <string>
#include <string_view>
#include <charconv>
#include <limits>
#include <optional>
#include <filesystem>

namespace Fond::TomlRepro {

static inline ts::Language load_toml_language(const char* so_path = nullptr) {
    using TSLangFn = TSLanguage*(*)();
    static std::optional<ts::Language> cached_lang = std::nullopt;
    if (cached_lang.has_value()) return cached_lang.value();

    auto fn = reinterpret_cast<TSLangFn>(dlsym(RTLD_DEFAULT, "tree_sitter_toml"));
    if (fn) { cached_lang = fn(); return cached_lang.value(); }

    #ifdef FOND_TOML_PARSER_SO
    const char *path = so_path ? so_path : FOND_TOML_PARSER_SO;
    #else
    const char *path = so_path ? so_path : std::getenv("FOND_TOML_PARSER_SO");
    #endif
    if (!path) throw std::runtime_error("tree_sitter_toml not found. Set FOND_TOML_PARSER_SO or link toml_parser.o");
    void* lib = dlopen(path, RTLD_LAZY);
    if (!lib) throw std::runtime_error(std::string("dlopen: ") + dlerror());
    fn = reinterpret_cast<TSLangFn>(dlsym(lib, "tree_sitter_toml"));
    if (!fn) throw std::runtime_error(std::string("dlsym: ") + dlerror());
    cached_lang = fn();
    return cached_lang.value();
}

class Reader {
    ts::Parser parser_;
    Arena arena_;

    TomlStr make_string(std::string_view sv) { return TomlStr(sv.data(), sv.size(), ArenaAlloc<char>(arena_)); }
    toml::array make_array() { return toml::array(ArenaAlloc<TomlValue>(arena_)); }
    toml::table make_table() { return toml::table{ArenaAlloc<std::pair<const ArenaString, TomlValue>>(arena_)}; }

    TomlStr extract_key(ts::Node node, std::string_view source) {
        auto text = node.getSourceRange(source);
        if (node.getSymbol() == Fond::Toml::sym::sym_quoted_key && text.size() >= 2)
            return make_string(text.substr(1, text.size() - 2));
        return make_string(text);
    }

    void collect_key_parts(ts::Node node, std::string_view source, std::vector<TomlStr>& parts) {
        if (node.getSymbol() == Fond::Toml::sym::sym_dotted_key) {
            for (auto child : ts::Children{node}) {
                if (!child.isNamed()) continue;
                auto s = child.getSymbol();
                if (s == Fond::Toml::sym::sym_dotted_key) {
                    collect_key_parts(child, source, parts);
                } else if (s == Fond::Toml::sym::sym_bare_key || s == Fond::Toml::sym::sym_quoted_key) {
                    parts.push_back(extract_key(child, source));
                }
            }
        } else {
            parts.push_back(extract_key(node, source));
        }
    }

    std::vector<TomlStr> get_key_path(ts::Node node, std::string_view source) {
        std::vector<TomlStr> parts;
        collect_key_parts(node, source, parts);
        return parts;
    }

    toml::table& ensure_path(toml::table& root, const std::vector<TomlStr>& path) {
        toml::table* current = &root;
        for (const auto& key : path) {
            auto& val = (*current)[key];
            if (val.is_none()) val = TomlValue(make_table());
            current = &val.as_table();
        }
        return *current;
    }

    TomlValue parse_value(ts::Node node, std::string_view source) {
        auto text = node.getSourceRange(source);
        auto symbol = node.getSymbol();
        if (symbol < 2 || symbol > 55) return TOML_NULL;
        switch (symbol) {
            case Fond::Toml::sym::sym_string: {
                if (text.size() >= 6 && (text.starts_with("\"\"\"") || text.starts_with("'''")))
                    return make_string(text.substr(3, text.size() - 6));
                if (text.size() >= 2 && (text[0] == '"' || text[0] == '\''))
                    return make_string(text.substr(1, text.size() - 2));
                return make_string(text);
            }
            case Fond::Toml::sym::sym_integer: {
                auto s = std::string(text);
                std::erase(s, '_');
                int64_t val = 0;
                if (s.starts_with("0x") || s.starts_with("0X"))
                    std::from_chars(s.data() + 2, s.data() + s.size(), val, 16);
                else if (s.starts_with("0o") || s.starts_with("0O"))
                    std::from_chars(s.data() + 2, s.data() + s.size(), val, 8);
                else if (s.starts_with("0b") || s.starts_with("0B"))
                    std::from_chars(s.data() + 2, s.data() + s.size(), val, 2);
                else
                    std::from_chars(s.data(), s.data() + s.size(), val);
                return val;
            }
            case Fond::Toml::sym::sym_float: {
                auto s = std::string(text);
                std::erase(s, '_');
                if (s == "inf" || s == "+inf") return std::numeric_limits<double>::infinity();
                if (s == "-inf") return -std::numeric_limits<double>::infinity();
                if (s == "nan" || s == "+nan" || s == "-nan") return std::numeric_limits<double>::quiet_NaN();
                return std::stod(s);
            }

            case Fond::Toml::sym::sym_boolean: return text == "true";
            case Fond::Toml::sym::sym_array: {
                toml::array arr = make_array();
                for (auto child : ts::Children{node}) {
                    if (!child.isNamed()) continue;
                    arr.push_back(parse_value(child, source));
                }
                return arr;
            }
            case Fond::Toml::sym::sym_inline_table: {
                toml::table tbl = make_table();
                for (auto child : ts::Children{node}) {
                    if (!child.isNamed() || child.getSymbol() != Fond::Toml::sym::sym_pair) continue;
                    parse_pair(child, source, tbl);
                }
                return tbl;
            }
            case Fond::Toml::sym::sym_local_date:
            case Fond::Toml::sym::sym_local_time:
            case Fond::Toml::sym::sym_local_date_time:
            case Fond::Toml::sym::sym_offset_date_time: return make_string(text);
            default: return TOML_NULL;
        }
    }

    void parse_pair(ts::Node node, std::string_view source, toml::table& target) {
        auto key_node = node.getChildByFieldName("key");
        auto val_node = node.getChildByFieldName("value");
        if (key_node.isNull() || val_node.isNull()) return;

        auto path = get_key_path(key_node, source);
        if (path.size() == 1) {
            target.insert(path[0], parse_value(val_node, source));
        } else {
            auto& nested = ensure_path(target, {path.begin(), path.end() - 1});
            nested.insert(path.back(), parse_value(val_node, source));
        }
    }

    void parse_table(ts::Node node, std::string_view source, toml::table& root) {
        auto name_node = node.getChildByFieldName("name");
        if (name_node.isNull()) return;

        auto path = get_key_path(name_node, source);
        auto& target = ensure_path(root, path);

        for (auto child : ts::Children{node}) {
            if (!child.isNamed() || child.getSymbol() != Fond::Toml::sym::sym_pair) continue;
            parse_pair(child, source, target);
        }
    }

    void parse_table_array(ts::Node node, std::string_view source, toml::table& root) {
        auto name_node = node.getChildByFieldName("name");
        if (name_node.isNull()) return;

        auto path = get_key_path(name_node, source);
        if (path.empty()) return;

        auto& parent = path.size() > 1
            ? ensure_path(root, {path.begin(), path.end() - 1})
            : root;

        auto& arr_val = parent[path.back()];
        if (arr_val.is_none()) arr_val = TomlValue(make_array());

        toml::table element = make_table();
        for (auto child : ts::Children{node}) {
            if (!child.isNamed() || child.getSymbol() != Fond::Toml::sym::sym_pair) continue;
            parse_pair(child, source, element);
        }
        arr_val.as_array().push_back(TomlValue(std::move(element)));
    }

    TomlValue parse_document(std::string_view source) {
        auto tree = parser_.parseString(source);
        auto root_node = tree.getRootNode();
        toml::table root = make_table();

        for (auto child : ts::Children{root_node}) {
            if (!child.isNamed()) continue;
            switch (child.getSymbol()) {
                case Fond::Toml::sym::sym_pair:
                    parse_pair(child, source, root);
                    break;
                case Fond::Toml::sym::sym_table:
                    parse_table(child, source, root);
                    break;
                case Fond::Toml::sym::sym_table_array_element:
                    parse_table_array(child, source, root);
                    break;
                default: break;
            }
        }

        return TomlValue(std::move(root));
    }

public:
    Reader(size_t arena_block_size = 4096) : parser_(load_toml_language()), arena_(arena_block_size) {}

    TomlValue parse(std::string_view source) { arena_.reset(); return parse_document(source); }
    TomlValue parse_no_reset(std::string_view source) { return parse_document(source); }

    TomlValue parse_file(const std::filesystem::path& path) {
        arena_.reset();
        auto content = Fond::FileIO::read(path);
        return parse_document(content);
    }
    TomlValue parse_file_no_reset(const std::filesystem::path& path) {
        auto content = Fond::FileIO::read(path);
        return parse_document(content);
    }

    void reset() { arena_.reset(); }
    TomlStr make_key(std::string_view sv) { return make_string(sv); }
    Arena& arena() { return arena_; }
};

} // namespace Fond::TomlRepro
