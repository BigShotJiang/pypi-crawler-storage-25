#pragma once

#include "color.hpp"
#include "../math.hpp"

#include <stdexcept>

namespace Fond {

namespace FM = Fond::Math;

constexpr Color DEFAULT_START = {255, 0, 0};   // Red
constexpr Color DEFAULT_MID = {255, 255, 0};   // Yellow
constexpr Color DEFAULT_END = {0, 255, 0};     // Green


// 3-color gradient interpolator. Maps a value in [min, max] to a color along
// start → mid → end. Default: red → yellow → green.
class ColorGradient {
    Color start_ = DEFAULT_START;
    Color mid_ = DEFAULT_MID;
    Color end_ = DEFAULT_END;

    double start_t_ = 0.0;
    double mid_t_ = 0.4;
    double end_t_ = 1.0;

    bool reverse_ = false;

    std::pair<Color, Color> segment(double n) const {
        return n <= mid_t_ ? std::pair{start_, mid_} : std::pair{mid_, end_};
    }

    double segment_position(double n) const {
        return n <= mid_t_
            ? FM::inv_lerp(start_t_, mid_t_, n)
            : FM::inv_lerp(mid_t_, end_t_, n);
    }

public:
    ColorGradient() = default;

    ColorGradient(Color start, Color mid, Color end) : start_(start), mid_(mid), end_(end) {}

    ColorGradient& colors(Color start, Color mid, Color end) {
        start_ = start; mid_ = mid; end_ = end;
        return *this;
    }

    ColorGradient& thresholds(double start, double mid, double end) {
        if (!(0.0 <= start && start < mid && mid < end && end <= 1.0))
            throw std::invalid_argument("thresholds must be strictly increasing in [0, 1]");
        start_t_ = start; mid_t_ = mid; end_t_ = end;
        return *this;
    }

    ColorGradient& reverse(bool r = true) { reverse_ = r; return *this; }
    void flip() { reverse_ = !reverse_; }

    Color map(double min_v, double max_v, double v) const {
        double n = FM::norm_position(min_v, max_v, v, reverse_);
        auto [a, b] = segment(n);
        double t = segment_position(n);
        return Color{
            FM::lerp_channel(a.r, b.r, t),
            FM::lerp_channel(a.g, b.g, t),
            FM::lerp_channel(a.b, b.b, t),
            255
        };
    }
};

} // namespace Fond
