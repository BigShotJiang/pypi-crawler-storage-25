#pragma once

#include "color.hpp"

#include <cstdint>
#include <ostream>
#include <string>

namespace Fond {

// Fluent ANSI style builder. Chain .bold().red() etc, stream into ostream.
// Call .reset() or stream Style::RESET to end the style.
class Style {
    enum Flag : uint8_t {
        NONE      = 0,
        BOLD_BIT  = 1 << 0,
        DIM_BIT   = 1 << 1,
        ITALIC    = 1 << 2,
        UNDERLINE = 1 << 3,
    };

    uint8_t flags_ = 0;
    int fg_code_ = -1;   // ANSI 30-37 basic color, -1 if unset
    int bg_code_ = -1;
    Color fg_rgb_{0, 0, 0, 0};   // a=0 means unset
    Color bg_rgb_{0, 0, 0, 0};

public:
    Style() = default;

    Style& bold() { flags_ |= BOLD_BIT; return *this; }
    Style& dim() { flags_ |= DIM_BIT; return *this; }
    Style& italic() { flags_ |= ITALIC; return *this; }
    Style& underline() { flags_ |= UNDERLINE; return *this; }

    Style& black()   { fg_code_ = 30; return *this; }
    Style& red()     { fg_code_ = 31; return *this; }
    Style& green()   { fg_code_ = 32; return *this; }
    Style& yellow()  { fg_code_ = 33; return *this; }
    Style& blue()    { fg_code_ = 34; return *this; }
    Style& magenta() { fg_code_ = 35; return *this; }
    Style& cyan()    { fg_code_ = 36; return *this; }
    Style& white()   { fg_code_ = 37; return *this; }

    Style& fg(const Color& c) { fg_rgb_ = c; fg_rgb_.a = 255; fg_code_ = -1; return *this; }
    Style& bg(const Color& c) { bg_rgb_ = c; bg_rgb_.a = 255; bg_code_ = -1; return *this; }

    std::string str() const {
        std::string out = "\033[";
        bool first = true;
        auto sep = [&] { if (!first) out += ';'; first = false; };

        if (flags_ & BOLD_BIT)  { sep(); out += '1'; }
        if (flags_ & DIM_BIT)   { sep(); out += '2'; }
        if (flags_ & ITALIC)    { sep(); out += '3'; }
        if (flags_ & UNDERLINE) { sep(); out += '4'; }

        if (fg_code_ >= 0) { sep(); out += std::to_string(fg_code_); }
        else if (fg_rgb_.a) { sep(); out += "38;2;"; out += std::to_string(fg_rgb_.r); out += ';'; out += std::to_string(fg_rgb_.g); out += ';'; out += std::to_string(fg_rgb_.b); }

        if (bg_code_ >= 0) { sep(); out += std::to_string(bg_code_); }
        else if (bg_rgb_.a) { sep(); out += "48;2;"; out += std::to_string(bg_rgb_.r); out += ';'; out += std::to_string(bg_rgb_.g); out += ';'; out += std::to_string(bg_rgb_.b); }

        if (first) return "";  // no flags set
        out += 'm';
        return out;
    }

    static constexpr const char* RESET = "\033[0m";

    friend std::ostream& operator<<(std::ostream& os, const Style& s) {
        return os << s.str();
    }
};

} // namespace Fond
