#pragma once

#include "fwd.hpp"
#include <initializer_list>
#include <list>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace CollectionsCub {

template <typename T, typename Policy, typename Hash, typename KeyEqual, typename Alloc>
class Set {
    using ListAlloc = typename std::allocator_traits<Alloc>::template rebind_alloc<T>;
    using SetAlloc = typename std::allocator_traits<Alloc>::template rebind_alloc<T>;
    using OrderedStorage = std::list<T, ListAlloc>;
    using UnorderedStorage = std::unordered_set<T, Hash, KeyEqual, SetAlloc>;
    using IdxPair = std::pair<const T, typename OrderedStorage::iterator>;
    using IdxAlloc = typename std::allocator_traits<Alloc>::template rebind_alloc<IdxPair>;
    using IndexMap = std::unordered_map<T, typename OrderedStorage::iterator, Hash, KeyEqual, IdxAlloc>;

    std::conditional_t<Policy::ordered, OrderedStorage, UnorderedStorage> data_;
    std::conditional_t<Policy::ordered, IndexMap, EmptyIndex> index_;

    // Private: bulk insert that bypasses the immutable check
    // Used by freeze/unfreeze and the initializer_list constructor for frozen sets
    void _bulk_insert(const T& value) {
        if constexpr (Policy::ordered) {
            if (index_.count(value) > 0) return;
            data_.push_back(value);
            index_[value] = std::prev(data_.end());
        } else {
            data_.insert(value);
        }
    }
    bool locked = false;
public:
    Set() requires std::is_default_constructible_v<Alloc> = default;
    ~Set() = default;

    // Explicit copy/move ctors mirror Map. The implicit versions interact
    // badly with allocators that have is_always_equal=false_type (e.g.
    // ArenaAllocator) — std::variant<...,Set,...> would land in
    // valueless_by_exception state on construction. Defining the rule of
    // five by hand restores noexcept move semantics. See fond brack #350.
    Set(const Set& o) : data_(o.data_), index_(o.index_), locked(o.locked) {}
    Set(Set&& o) noexcept
        : data_(std::move(o.data_)), index_(std::move(o.index_)), locked(o.locked) {}
    Set& operator=(const Set& o) {
        data_ = o.data_; index_ = o.index_; locked = o.locked; return *this;
    }
    Set& operator=(Set&& o) noexcept {
        data_ = std::move(o.data_);
        index_ = std::move(o.index_);
        locked = o.locked;
        return *this;
    }

    explicit Set(const Alloc& alloc) requires (Policy::ordered)
        : data_(ListAlloc(alloc)), index_(IdxAlloc(alloc)) {}

    explicit Set(const Alloc& alloc) requires (!Policy::ordered)
        : data_(SetAlloc(alloc)) {}

    Set(std::initializer_list<T> init) { for (const auto& item : init) _bulk_insert(item); }
    Set(const std::vector<T>& values) { for (const auto& item : values) _bulk_insert(item); }
    template <typename Iter> Set(Iter first, Iter last) { for (auto it = first; it != last; ++it) _bulk_insert(*it); }

    void insert(std::initializer_list<T> init) requires (!Policy::immutable) { for (const auto& item : init) add(item); }
    void insert(const std::vector<T>& values) requires (!Policy::immutable) { for (const auto& item : values) add(item); }
    template <typename... Args> void insert(Args&&... args) requires (!Policy::immutable) { (add(T(std::forward<Args>(args))), ...); }
    
    void _add_items(std::initializer_list<T> init) requires (Policy::immutable) {
        if (locked) return; // sry
        for (const auto& item : init) _bulk_insert(item);
        locked = true;
    }

    void _add_items(const std::vector<T>& values) requires (Policy::immutable) {
        if (locked) return;
        for (const auto& item : values) _bulk_insert(item);
        locked = true;
    }
    
    size_t size() const { return data_.size(); }
    bool empty() const { return data_.empty(); }

    bool contains(const T& value) const {
        if constexpr (Policy::ordered) {
            return index_.contains(value);
        } else {
            return data_.contains(value);
        }
    }

    // --- Add (only available when not immutable) ---

    bool add(const T& value) requires (!Policy::immutable) {
        if (contains(value)) return false;
        if constexpr (Policy::ordered) {
            data_.push_back(value);
            index_[value] = std::prev(data_.end());
        } else {
            data_.insert(value);
        }
        return true;
    }

    // --- Remove (only available when not immutable) ---

    bool remove(const T& value) requires (!Policy::immutable) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(value);
            if (it == index_.end()) return false;
            data_.erase(it->second);
            index_.erase(it);
        } else {
            return data_.erase(value) > 0;
        }
        return true;
    }

    void clear() requires (!Policy::immutable) {
        data_.clear();
        if constexpr (Policy::ordered) index_.clear();
    }

    // --- Order-specific (only when ordered) ---

    const T& front() const requires (Policy::ordered) { return data_.front(); }
    const T& back() const requires (Policy::ordered) { return data_.back(); }

    void pop_front() requires (Policy::ordered && !Policy::immutable) {
        if (data_.empty()) return;
        index_.erase(data_.front());
        data_.pop_front();
    }

    void pop_back() requires (Policy::ordered && !Policy::immutable) {
        if (data_.empty()) return;
        index_.erase(data_.back());
        data_.pop_back();
    }

    bool move_to_end(const T& value) requires (Policy::ordered && !Policy::immutable) {
        auto it = index_.find(value);
        if (it == index_.end()) return false;
        data_.splice(data_.end(), data_, it->second);
        return true;
    }

    bool move_to_front(const T& value) requires (Policy::ordered && !Policy::immutable) {
        auto it = index_.find(value);
        if (it == index_.end()) return false;
        data_.splice(data_.begin(), data_, it->second);
        return true;
    }


    std::vector<T> to_vector() const { return std::vector<T>(data_.begin(), data_.end()); }
    List<T> to_list() const { return List<T>(data_.begin(), data_.end()); }
    Tuple<T> to_tuple() const { return Tuple<T>(data_.begin(), data_.end()); }

    // Freeze: mutable → immutable (same ordering)
    Set<T, Freeze<Policy>, Hash, KeyEqual, Alloc> freeze() const requires (!Policy::immutable) {
        return Set<T, Freeze<Policy>, Hash, KeyEqual, Alloc>(data_.begin(), data_.end());
    }

    // Unfreeze: immutable → mutable (same ordering)
    Set<T, Unfreeze<Policy>, Hash, KeyEqual, Alloc> unfreeze() const requires (Policy::immutable) {
        return Set<T, Unfreeze<Policy>, Hash, KeyEqual, Alloc>(data_.begin(), data_.end());
    }

    auto begin() const { return data_.begin(); }
    auto end() const { return data_.end(); }
    auto cbegin() const { return data_.cbegin(); }
    auto cend() const { return data_.cend(); }
};

template <typename T>
static inline std::vector<T> unique_ordered_keys(const std::vector<T>& input) { return OrderedSet<T>(input).to_vector(); }


}  // namespace CollectionsCub
