#pragma once

#include <algorithm>
#include <functional>
#include <vector>

namespace CollectionsCub {

template <typename T, typename Cmp = std::less<T>, typename Alloc = std::allocator<T>>
class PriorityQueue {
    std::vector<T, Alloc> data_;
    Cmp cmp_;

public:
    PriorityQueue() = default;
    explicit PriorityQueue(Cmp cmp) : cmp_(std::move(cmp)) {}
    explicit PriorityQueue(Alloc alloc) : data_(alloc) {}
    PriorityQueue(Cmp cmp, Alloc alloc) : data_(alloc), cmp_(std::move(cmp)) {}

    // Explicit copy/move ctors mirror Map/Set/List. Implicit versions interact
    // badly with allocators where is_always_equal=false_type — see fond #350.
    PriorityQueue(const PriorityQueue& o) : data_(o.data_), cmp_(o.cmp_) {}
    PriorityQueue(PriorityQueue&& o) noexcept
        : data_(std::move(o.data_)), cmp_(std::move(o.cmp_)) {}
    PriorityQueue& operator=(const PriorityQueue& o) {
        data_ = o.data_; cmp_ = o.cmp_; return *this;
    }
    PriorityQueue& operator=(PriorityQueue&& o) noexcept {
        data_ = std::move(o.data_); cmp_ = std::move(o.cmp_); return *this;
    }

    void put(T item) {
        data_.push_back(std::move(item));
        std::push_heap(data_.begin(), data_.end(), cmp_);
    }

    T get() {
        std::pop_heap(data_.begin(), data_.end(), cmp_);
        T val = std::move(data_.back());
        data_.pop_back();
        return val;
    }

    const T& peek() const { return data_.front(); }
    bool empty() const { return data_.empty(); }
    size_t size() const { return data_.size(); }

    void clear() { data_.clear(); }

    template <typename Pred>
    bool remove_if(Pred pred) {
        auto it = std::find_if(data_.begin(), data_.end(), pred);
        if (it == data_.end()) return false;
        data_.erase(it);
        std::make_heap(data_.begin(), data_.end(), cmp_);
        return true;
    }

    std::vector<T> top_n(size_t n) const {
        n = std::min(n, data_.size());
        std::vector<T> result(n);
        std::partial_sort_copy(data_.begin(), data_.end(), result.begin(), result.end(), cmp_);
        return result;
    }

    auto begin() const { return data_.begin(); }
    auto end() const { return data_.end(); }
    const std::vector<T, Alloc>& data() const { return data_; }
};

} // namespace CollectionsCub
