#pragma once

#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstring>

#include "arena.hpp"

namespace CollectionsCub {

constexpr size_t BITS_PER_WORD = 64;

template <size_t N = 32>
struct StaticBitset {
    static constexpr size_t n_words = (N + BITS_PER_WORD - 1) / BITS_PER_WORD;
    uint64_t bits[n_words];

    StaticBitset() { reset_all(); }

    void set(size_t i) { bits[i / BITS_PER_WORD] |= (1ULL << (i % BITS_PER_WORD)); }
    void unset(size_t i) { bits[i / BITS_PER_WORD] &= ~(1ULL << (i % BITS_PER_WORD)); }
    void toggle(size_t i) { bits[i / BITS_PER_WORD] ^= (1ULL << (i % BITS_PER_WORD)); }
    bool test(size_t i) const { return (bits[i / BITS_PER_WORD] & (1ULL << (i % BITS_PER_WORD))) != 0; }

    size_t count() const {
        size_t cnt = 0;
        for (size_t i = 0; i < n_words; ++i) cnt += static_cast<size_t>(std::popcount(bits[i]));
        return cnt;
    }
    bool any() const { for (size_t i = 0; i < n_words; ++i) if (bits[i]) return true; return false; }
    bool none() const { return !any(); }
    constexpr size_t size() const { return N; }
    void reset_all() { memset(bits, 0, sizeof(bits)); }
    void set_all() { memset(bits, 0xFF, sizeof(bits)); }
};

template <typename Alloc = std::allocator<uint64_t>>
struct DynamicBitset {
    static constexpr bool is_arena = !std::is_default_constructible_v<Alloc>;
    using Storage = std::conditional_t<is_arena, uint64_t*, std::vector<uint64_t>>;

    Storage bits_;
    size_t n_words_;
    size_t n_bits_;

    DynamicBitset(size_t n) requires (!is_arena)
        : bits_((n + BITS_PER_WORD - 1) / BITS_PER_WORD, 0), n_words_(bits_.size()), n_bits_(n) {}

    DynamicBitset(size_t n, Arena& arena) requires (is_arena)
        : n_words_((n + BITS_PER_WORD - 1) / BITS_PER_WORD), n_bits_(n) {
        bits_ = arena.create_array<uint64_t>(n_words_);
        reset_all();
    }

    uint64_t* data() {
        if constexpr (is_arena) return bits_;
        else return bits_.data();
    }
    const uint64_t* data() const {
        if constexpr (is_arena) return bits_;
        else return bits_.data();
    }

    void set(size_t i) { data()[i / BITS_PER_WORD] |= (1ULL << (i % BITS_PER_WORD)); }
    void unset(size_t i) { data()[i / BITS_PER_WORD] &= ~(1ULL << (i % BITS_PER_WORD)); }
    void toggle(size_t i) { data()[i / BITS_PER_WORD] ^= (1ULL << (i % BITS_PER_WORD)); }
    bool test(size_t i) const { return (data()[i / BITS_PER_WORD] & (1ULL << (i % BITS_PER_WORD))) != 0; }

    size_t count() const {
        size_t cnt = 0;
        for (size_t i = 0; i < n_words_; ++i) cnt += static_cast<size_t>(std::popcount(data()[i]));
        return cnt;
    }
    bool any() const { for (size_t i = 0; i < n_words_; ++i) if (data()[i]) return true; return false; }
    bool none() const { return !any(); }
    size_t size() const { return n_bits_; }
    void reset_all() { memset(data(), 0, n_words_ * sizeof(uint64_t)); }
    void set_all() { memset(data(), 0xFF, n_words_ * sizeof(uint64_t)); }
};

}