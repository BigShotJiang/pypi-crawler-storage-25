#pragma once

#include <array>
#include <string>
#include <string_view>
#include <vector>

#include "arena.hpp"

namespace CollectionsCub {

class Trie {
    struct Node {
        std::array<Node*, 128> children{};
        bool is_end = false;
    };

    Arena arena_;
    Node* root_;
    size_t count_ = 0;

    Node* make_node() { return arena_.create<Node>(); }

    Node* walk(std::string_view prefix) const {
        Node* current = root_;
        for (char c : prefix) {
            auto idx = static_cast<unsigned char>(c);
            if (!current->children[idx]) return nullptr;
            current = current->children[idx];
        }
        return current;
    }

    void collect(Node* node, std::string& prefix, std::vector<std::string>& results) const {
        if (node->is_end) results.push_back(prefix);
        for (int i = 0; i < 128; ++i) {
            if (node->children[i]) {
                prefix.push_back(static_cast<char>(i));
                collect(node->children[i], prefix, results);
                prefix.pop_back();
            }
        }
    }

public:
    Trie(size_t arena_size = 4096) : arena_(arena_size), root_(make_node()) {}

    size_t size() const { return count_; }
    bool empty() const { return count_ == 0; }

    void insert(std::string_view word) {
        Node* current = root_;
        for (char c : word) {
            auto idx = static_cast<unsigned char>(c);
            if (!current->children[idx]) current->children[idx] = make_node();
            current = current->children[idx];
        }
        if (!current->is_end) {
            current->is_end = true;
            ++count_;
        }
    }

    bool contains(std::string_view word) const {
        Node* node = walk(word);
        return node && node->is_end;
    }

    bool has_prefix(std::string_view prefix) const { return walk(prefix) != nullptr; }

    bool remove(std::string_view word) {
        Node* node = walk(word);
        if (!node || !node->is_end) return false;
        node->is_end = false;
        --count_;
        return true;
    }

    std::vector<std::string> find_all(std::string_view prefix) const {
        std::vector<std::string> results;
        Node* node = walk(prefix);
        if (node) {
            std::string buf(prefix);
            collect(node, buf, results);
        }
        return results;
    }

    std::vector<std::string> autocomplete(std::string_view prefix, size_t max_results = 10) const {
        auto all = find_all(prefix);
        if (all.size() > max_results) all.resize(max_results);
        return all;
    }

    std::vector<std::string> all_words() const {
        std::vector<std::string> results;
        std::string buf;
        collect(root_, buf, results);
        return results;
    }

    void clear() {
        arena_.reset();
        root_ = make_node();
        count_ = 0;
    }

    Arena& arena() { return arena_; }
};

}  // namespace CollectionsCub
