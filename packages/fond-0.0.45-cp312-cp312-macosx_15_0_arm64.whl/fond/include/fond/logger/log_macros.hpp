#pragma once

#include "fond/logger/logger.hpp" // IWYU pragma: keep

#undef LOG_VERBOSE_TRUE

#if defined(LOGGER_LEVEL_VERBOSE) && defined(LOGGER_ENABLED)
#define LOC (Fond::Logging::LogLoc{SHORT_FILE, __func__, __LINE__})
#define LOG_PLEX_INFO(...) Fond::Logging::g_logger.Info_(LOC, __VA_ARGS__)
#define LOG_PLEX_ERR(...) Fond::Logging::g_logger.Error_(LOC, __VA_ARGS__)
#define LOG_PLEX_WARN(...) Fond::Logging::g_logger.Warning_(LOC, __VA_ARGS__)
#define LOG_PLEX_DEBUG(...) Fond::Logging::g_logger.Debug_(LOC, __VA_ARGS__)
#define LOG_PLEX_VERB(...) Fond::Logging::g_logger.Verbose_(LOC, __VA_ARGS__)
#define LOG_PLEX_ASSERT(expr, msg) \
  do { \
    if (!(expr)) { \
      const std::string _assert_msg = std::format("Assertion failed: {}", msg); \
      const std::string _assert_loc = std::format("[{}::{}[{}]]", SHORT_FILE, __func__, __LINE__); \
      Fond::Logging::g_logger.Error_(_assert_loc, _assert_msg); \
      assert(expr); \
    } \
  } while (0)
#else
#define LOG_PLEX_INFO(...)
#define LOG_PLEX_ERR(...)
#define LOG_PLEX_WARN(...)
#define LOG_PLEX_DEBUG(...)
#define LOG_PLEX_VERB(...)
#define LOG_PLEX_ASSERT(expr, msg) assert(expr)
#endif