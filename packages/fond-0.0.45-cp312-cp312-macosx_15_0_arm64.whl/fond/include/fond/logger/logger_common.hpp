#pragma once

#ifdef LOGGER_COLORS
#include "../colors/ansi.hpp"
#endif
#include <string>

namespace Fond::Logging {

    template <size_t N> constexpr size_t MEGABYTE = 1024 * 1024 * N;

    #ifdef LOGGER_FILE
    #ifndef LOGGER_FILE_PATH
    #define LOGGER_FILE_PATH "general.log"
    #endif
    #ifndef LOGGER_FILE_ROTATIONS
    #define LOGGER_FILE_ROTATIONS 5
    #endif
    #ifndef LOGGER_FILE_MAX_SIZE
    #define LOGGER_FILE_MAX_SIZE (MEGABYTE<5>)
    #endif
    #endif
    
    constexpr const char *INFO_PREFIX = "[INFO]";
    constexpr const char *ERROR_PREFIX = "[ERROR]";
    constexpr const char *WARNING_PREFIX = "[WARNING]";
    constexpr const char *DEBUG_PREFIX = "[DEBUG]";
    constexpr const char *VERBOSE_PREFIX = "[VERBOSE]";

    enum class LogLevel {
        NOTSET = 0,
        INFO,
        WARNING,
        ERROR,
        DEBUG,
        VERBOSE
    };
    
    static inline const char* get_prefix(LogLevel level) {
        switch (level) {
            case LogLevel::INFO: return INFO_PREFIX;
            case LogLevel::ERROR: return ERROR_PREFIX;
            case LogLevel::WARNING: return WARNING_PREFIX;
            case LogLevel::DEBUG: return DEBUG_PREFIX;
            case LogLevel::VERBOSE: return VERBOSE_PREFIX;
            default: return "";
        }
    }

    // This is specifcally here for fast conversion in weird use cases
    // don't ask why, ask what
    static inline char lvl_to_str(LogLevel level) {
        switch (level) {
            case LogLevel::INFO: return 'i';
            case LogLevel::ERROR: return 'e';
            case LogLevel::WARNING: return 'w';
            case LogLevel::DEBUG: return 'd';
            case LogLevel::VERBOSE: return 'v';
            default: return 'i';
        }
    }
    
    enum LoggingMode {
        NONE = 0,
        FILE_MODE = 1 << 0,    // 0b0001
        STDOUT_MODE = 1 << 1,  // 0b0010
        STDERR_MODE = 1 << 2,  // 0b0100
        BUFFER_MODE = 1 << 3   // 0b1000
    };
    
    struct LogEntry {
        LogLevel level;
        std::string message;
        std::string timestamp;
    };

    constexpr LoggingMode _build_logging_mode() {
        int mode = NONE;
        #ifdef LOGGER_STDOUT
            mode |= STDOUT_MODE;
        #endif
        #ifdef LOGGER_STDERR
            mode |= STDERR_MODE;
        #endif
        #ifdef LOGGER_FILE
            mode |= FILE_MODE;
        #endif
        #ifdef LOGGER_BUFFER
            mode |= BUFFER_MODE;
        #endif
        return static_cast<LoggingMode>(mode);
    }
    
    constexpr LogLevel _build_log_level() {
        #ifdef LOGGER_LEVEL_INFO
            return LogLevel::INFO;
        #elif defined(LOGGER_LEVEL_WARNING)
            return LogLevel::WARNING;
        #elif defined(LOGGER_LEVEL_ERROR)
            return LogLevel::ERROR;
        #elif defined(LOGGER_LEVEL_DEBUG)
            return LogLevel::DEBUG;
        #elif defined(LOGGER_LEVEL_VERBOSE)
            return LogLevel::VERBOSE;
        #else
            return LogLevel::NOTSET;
        #endif
    }

    #ifdef LOGGER_COLORS
    static inline const char *get_level_color(LogLevel level) {
      switch (level) {
      case LogLevel::INFO:
        return Ansi::GREEN;
      case LogLevel::WARNING:
        return Ansi::YELLOW;
      case LogLevel::ERROR:
        return Ansi::RED;
      case LogLevel::DEBUG:
        return Ansi::BLUE;
      case LogLevel::VERBOSE:
        return Ansi::CYAN;
      default:
        return Ansi::RESET;
      }
    }
    #endif
} // namespace Fond::Logging
