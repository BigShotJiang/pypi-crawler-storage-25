#pragma once

#include <cctype>
#include <cstddef>
#include <cstring>
#include <string>
#include <string_view>

template <size_t PadSize> struct alignas(PadSize) PadStr {
    char data[PadSize] = {};
    size_t len = 0;
};

using PadStr8 = PadStr<8>;
using PadStr16 = PadStr<16>;
using PadStr32 = PadStr<32>;
using PadStr64 = PadStr<64>;

template <size_t N, typename InputType>
static inline bool within_pad_str_length(InputType s) {
    if constexpr (std::is_convertible_v<InputType, std::string_view>) {
        return s.size() <= N;
    } else {
        return sizeof(s) <= N;
    }
}

template <size_t N, typename InputType>
static inline PadStr<N> to_pad_str(InputType s) {
    PadStr<N> result;
    if (within_pad_str_length<N, InputType>(s)) {
        if constexpr (std::is_convertible_v<InputType, std::string_view>) {
            std::memcpy(result.data, s.data(), s.size());
            result.len = s.size();
        } else {
            std::memcpy(result.data, &s, sizeof(s));
            result.len = sizeof(s);
        }
    }
    return result;
}

template <size_t N, typename EnumType> struct LookupEntry {
    char str[N];
    EnumType value;
};

namespace str {
constexpr char NEWLINE = '\n';
constexpr char TAB_CHAR = '\t';
constexpr char CARRIAGE_RETURN = '\r';
constexpr char DOUBLE_QUOTE = '"';
constexpr char BACKSLASH = '\\';
constexpr char DOLLAR_SIGN = '$';

static inline char unescape_char(char c) noexcept {
    switch (c) {
        case 'n': return NEWLINE;
        case 't': return TAB_CHAR;
        case 'r': return CARRIAGE_RETURN;
        case '"': return DOUBLE_QUOTE;
        case '\\': return BACKSLASH;
        case '$': return DOLLAR_SIGN;
        default: return c;
    };
}

constexpr const char* ESCAPED_NL = "\\n";
constexpr const char* ESCAPED_TAB = "\\t";
constexpr const char* ESCAPED_CR = "\\r";
constexpr const char* ESCAPED_DQ = "\\\"";
constexpr const char* ESCAPED_BS = "\\\\";
constexpr const char *ESCAPED_DOLLAR = "\\$";

static inline std::string escape_string(std::string_view sv) {
    std::string out;
    out.reserve(sv.size() + 2);
    out += DOUBLE_QUOTE;
    for (char c : sv) {
        switch (c) {
            case '\\': out += ESCAPED_BS; break;
            case '"': out += ESCAPED_DQ; break;
            case '\n': out += ESCAPED_NL; break;
            case '\r': out += ESCAPED_CR; break;
            case '\t': out += ESCAPED_TAB; break;
            case '$': out += ESCAPED_DOLLAR; break;
            default: out += c; break;
        }
     }
    out += DOUBLE_QUOTE;
    return out;
}
} // namespace str

namespace Fond::Str {

static inline std::string to_pascal(std::string_view snake) {
    std::string result;
    result.reserve(snake.size());
    bool capitalize = true;
    for (char c : snake) {
        if (c == '_' || c == '-') {
            capitalize = true;
        } else {
            result.push_back(capitalize ? static_cast<char>(std::toupper(static_cast<unsigned char>(c))) : c);
            capitalize = false;
        }
    }
    return result;
}

static inline std::string to_snake(std::string_view input) {
    std::string result;
    result.reserve(input.size() + 4);
    for (size_t i = 0; i < input.size(); ++i) {
        char c = input[i];
        if (std::isupper(static_cast<unsigned char>(c))) {
            if (i > 0) result.push_back('_');
            result.push_back(static_cast<char>(std::tolower(static_cast<unsigned char>(c))));
        } else {
            result.push_back(c);
        }
    }
    return result;
}

} // namespace Fond::Str
