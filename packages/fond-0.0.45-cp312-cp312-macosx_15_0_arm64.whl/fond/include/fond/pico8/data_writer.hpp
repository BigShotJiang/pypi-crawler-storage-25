#pragma once

#include <charconv>
#include <fstream>
#include <ostream>
#include <sstream>
#include <string>
#include <type_traits>
#include <vector>

#include "fond/pico8/data_value.hpp"

namespace Fond::Pico8::Data {

// DataWriter — emits a Pico8Value (root table or anything inside it) as
// PICO-8/Lua source text. Produces valid Lua that reparses through DataReader.
//
// Layout rules:
//   * ROOT table: each key becomes a top-level global assignment on its own
//     line, blank line between keys. Mirrors the shape of a hand-written
//     config file.
//   * Nested tables: compact inline form unless they contain other tables,
//     in which case we emit one-field-per-line with indentation.
//   * Arrays of tables: one element per line, trailing comma.
//
// Not a source-preserving formatter — comments and original whitespace are
// NOT preserved. This is a codec, not a tool for manual editing.
// Writer behavior knobs. `pico8_safe` forces fixed-notation floats (never
// emits scientific), so the output is safe to load back in actual PICO-8 —
// its tokenizer rejects `1e6`-style literals. Default ON when writing to a
// `.p8` target; can be toggled explicitly for `.lua` targets that also want
// the safety.
struct WriterConfig {
    bool pico8_safe = false;
};

class DataWriter {
    std::ostream& out_;
    WriterConfig config_;
    int indent_level_ = 0;
    static constexpr const char* INDENT_UNIT = "  ";

    void indent() { for (int i = 0; i < indent_level_; ++i) out_ << INDENT_UNIT; }

    static bool is_table_ish(const Pico8Value& v) { return v.is_table() || v.is_array(); }

    // Quote-and-escape a string for Lua source. Minimal — handles the usual
    // suspects (newline, tab, quote, backslash). Assumes no control chars
    // beyond those; if consumers want full Lua string-literal correctness
    // they should escape upstream.
    void write_string(const Pico8Str& s) {
        out_ << '"';
        for (char c : std::string_view(s.data(), s.size())) {
            switch (c) {
                case '"':  out_ << "\\\""; break;
                case '\\': out_ << "\\\\"; break;
                case '\n': out_ << "\\n"; break;
                case '\t': out_ << "\\t"; break;
                case '\r': out_ << "\\r"; break;
                default:   out_ << c;
            }
        }
        out_ << '"';
    }

    void write_number_int(int64_t i) {
        char buf[32];
        auto [p, ec] = std::to_chars(buf, buf + sizeof(buf), i);
        if (ec == std::errc{}) out_.write(buf, p - buf);
    }

    void write_number_float(double d) {
        std::ostringstream ss;
        ss.imbue(std::locale::classic());
        if (config_.pico8_safe) {
            // Force decimal notation so PICO-8's tokenizer never sees an
            // exponent. Use enough precision to round-trip a double — 17
            // digits is the IEEE754 guarantee. Trailing zeros are trimmed
            // below to keep output readable.
            ss << std::fixed;
            ss.precision(17);
        }
        ss << d;
        auto s = ss.str();
        if (config_.pico8_safe) {
            // std::fixed always writes the decimal point + requested digits.
            // Trim trailing zeros past the point for readability — keep at
            // least one digit after the point so it's obviously a float.
            auto dot = s.find('.');
            if (dot != std::string::npos) {
                auto last = s.find_last_not_of('0');
                if (last > dot) s.erase(last + 1);
                else             s.erase(dot + 2); // leave "X.0"
            }
        } else {
            // Default mode: add ".0" if the value stringifies as an integer
            // so reparsing keeps it typed as float.
            if (s.find('.') == std::string::npos && s.find('e') == std::string::npos) s += ".0";
        }
        out_ << s;
    }

    void write_inline_array(const p8data::array& arr) {
        out_ << '{';
        bool first = true;
        for (const auto& v : arr) {
            if (!first) out_ << ", ";
            write_value(v);
            first = false;
        }
        out_ << '}';
    }

    // Array with table elements — one per line. Matches the shape of WALLS/
    // SECTORS in a hand-written map file.
    void write_block_array(const p8data::array& arr) {
        out_ << "{\n";
        ++indent_level_;
        for (const auto& v : arr) {
            indent();
            write_value(v);
            out_ << ",\n";
        }
        --indent_level_;
        indent();
        out_ << '}';
    }

    void write_inline_table(const p8data::table& tbl) {
        out_ << '{';
        bool first = true;
        for (const auto& [k, v] : tbl) {
            if (!first) out_ << ", ";
            out_.write(k.data(), k.size());
            out_ << '=';
            write_value(v);
            first = false;
        }
        out_ << '}';
    }

public:
    explicit DataWriter(std::ostream& out, WriterConfig cfg = {})
        : out_(out), config_(cfg) {}

    void write_value(const Pico8Value& val) {
        std::visit([this](auto&& arg) {
            using T = std::decay_t<decltype(arg)>;
            if constexpr (std::is_same_v<T, Pico8None>) {
                out_ << "nil";
            } else if constexpr (std::is_same_v<T, bool>) {
                out_ << (arg ? "true" : "false");
            } else if constexpr (std::is_same_v<T, int64_t>) {
                write_number_int(arg);
            } else if constexpr (std::is_same_v<T, double>) {
                write_number_float(arg);
            } else if constexpr (std::is_same_v<T, Pico8Str>) {
                write_string(arg);
            } else if constexpr (std::is_same_v<T, p8data::array>) {
                // Arrays of tables/arrays go block-form; arrays of scalars
                // stay inline to match the hand-written file aesthetic.
                bool any_block = false;
                for (const auto& e : arg) if (is_table_ish(e)) { any_block = true; break; }
                if (any_block) write_block_array(arg);
                else           write_inline_array(arg);
            } else if constexpr (std::is_same_v<T, p8data::table>) {
                write_inline_table(arg);
            }
        }, val.data);
    }

    // Root-table write — every key becomes a top-level `NAME = value` line.
    // Adds blank lines between entries for readability.
    void write_program(const Pico8Value& root) {
        if (!root.is_table()) { write_value(root); out_ << '\n'; return; }
        const auto& tbl = root.as_table();
        bool first = true;
        for (const auto& [k, v] : tbl) {
            if (!first) out_ << '\n';
            out_.write(k.data(), k.size());
            out_ << " = ";
            write_value(v);
            out_ << '\n';
            first = false;
        }
    }
};

// Convenience: one-shot serialize-to-string.
inline std::string to_source(const Pico8Value& root) {
    std::ostringstream ss;
    DataWriter w(ss);
    w.write_program(root);
    return ss.str();
}

// Emit the minimal PICO-8 cartridge framing — 3 lines, no gfx/map/sfx data.
// The resulting file is a valid PICO-8 cartridge (PICO-8 will open it, it
// just has empty graphics/map/audio banks). We write no other sections
// because we have no data for them — honest minimal output.
inline void write_cart_header(std::ostream& out) {
    out << CART_HEADER << '\n'
        << CART_VERSION << '\n'
        << CART_LUA_TAG << '\n';
}

inline bool dump(const Pico8Value& root, const std::filesystem::path& path) {
    std::ofstream f(path);
    if (!f.is_open()) return false;
    bool is_cart = (path.extension() == ".p8");
    // If saving to a .p8 extension, emit the cartridge wrapper so the result
    // is openable in PICO-8. Any other extension (.lua, .p8dat, etc.) gets
    // bare Lua output. pico8_safe is auto-enabled for .p8 to force decimal
    // floats — PICO-8 chokes on scientific notation.
    if (is_cart) write_cart_header(f);
    DataWriter w(f, WriterConfig{.pico8_safe = is_cart});
    w.write_program(root);
    return true;
}


} // namespace Fond::Pico8::Data
