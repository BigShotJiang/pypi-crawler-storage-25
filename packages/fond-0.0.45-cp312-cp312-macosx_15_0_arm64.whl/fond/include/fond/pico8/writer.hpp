#pragma once

#include <string>
#include <string_view>
#include "fond/pico8/value.hpp"

namespace Fond::Pico8 {

// Pretty-print a PICO-8 AST back to source text.
//
// Design goals:
//   * Output is valid PICO-8 Lua that round-trips through the reader.
//   * Not a source-preserving formatter — whitespace, original layout, and
//     comments are NOT preserved. This is the transpiler's emit layer, so we
//     emit one canonical form (2-space indent, newline-terminated blocks).
//   * Short forms (`if (x) stmt`, `while (x) stmt`) get their own node kinds
//     so the writer emits the right shape automatically.
class Writer {
    std::string out_;
    int indent_level_ = 0;
    static constexpr const char* INDENT_UNIT = "  ";

    void indent() {
        for (int i = 0; i < indent_level_; ++i) out_ += INDENT_UNIT;
    }

    void write(std::string_view s) { out_.append(s); }
    void write(char c) { out_ += c; }
    void newline() { out_ += '\n'; }

    // Comma-separated list of expression emissions.
    template <typename Range>
    void write_csv(const Range& xs) {
        bool first = true;
        for (auto* x : xs) {
            if (!first) write(", ");
            emit_expr(x);
            first = false;
        }
    }

    // Dispatch for any expression position: unwraps to the right shape for
    // operators, calls, literals, etc. Does NOT indent or newline — caller
    // controls placement.
    void emit_expr(NodePtr n) {
        if (!n) { write("nil"); return; }
        switch (n->kind) {
            case NodeKind::Nil:         write("nil"); return;
            case NodeKind::Boolean:     write(as<BooleanNode>(n)->value ? "true" : "false"); return;
            case NodeKind::Number:      write(as<NumberNode>(n)->raw); return;
            case NodeKind::String:      write(as<StringNode>(n)->value); return;
            case NodeKind::Ellipsis:    write("..."); return;
            case NodeKind::Identifier:  write(as<IdentifierNode>(n)->name); return;

            case NodeKind::BinaryOp: {
                auto* b = as<BinaryOpNode>(n);
                // Conservative parenthesization: wrap both sides so we never
                // emit something that reparses with wrong precedence. Can
                // tighten later with a precedence-aware emitter.
                write('(');
                emit_expr(b->lhs);
                write(' '); write(b->op); write(' ');
                emit_expr(b->rhs);
                write(')');
                return;
            }
            case NodeKind::UnaryOp: {
                auto* u = as<UnaryOpNode>(n);
                // Word-operators (not) need a space; symbolic ones (-,#,@,%,$,~) don't.
                write(u->op);
                if (!u->op.empty()) {
                    char c = u->op.front();
                    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) write(' ');
                }
                emit_expr(u->operand);
                return;
            }
            case NodeKind::Index: {
                auto* i = as<IndexNode>(n);
                emit_expr(i->object); write('['); emit_expr(i->index); write(']');
                return;
            }
            case NodeKind::FieldAccess: {
                auto* f = as<FieldAccessNode>(n);
                emit_expr(f->object); write('.'); write(f->field);
                return;
            }
            case NodeKind::FunctionCall: {
                auto* fc = as<FunctionCallNode>(n);
                emit_expr(fc->callee); write('(');
                write_csv(fc->args);
                write(')');
                return;
            }
            case NodeKind::MethodCall: {
                auto* mc = as<MethodCallNode>(n);
                emit_expr(mc->receiver); write(':'); write(mc->method); write('(');
                write_csv(mc->args);
                write(')');
                return;
            }
            case NodeKind::TableConstructor: {
                auto* t = as<TableConstructorNode>(n);
                write('{');
                bool first = true;
                for (auto* f : t->fields) {
                    if (!first) write(", ");
                    emit_table_field(f);
                    first = false;
                }
                write('}');
                return;
            }
            case NodeKind::FunctionExpr: {
                auto* f = as<FunctionExprNode>(n);
                write("function(");
                emit_param_list(f->params, f->varargs);
                write(')'); newline();
                emit_block_inner(f->body);
                indent(); write("end");
                return;
            }
            case NodeKind::Unknown:
                // Unknown nodes round-trip as their raw source text. Keeps the
                // writer correct even when the reader didn't recognize a construct.
                write(as<UnknownNode>(n)->raw);
                return;
            default:
                write("--[[ unhandled expr: "); write(type_name(n->kind)); write(" ]]--");
                return;
        }
    }

    void emit_table_field(NodePtr n) {
        auto* tf = as<TableFieldNode>(n);
        if (!tf) { emit_expr(n); return; }
        if (!tf->key_name.empty()) {
            write(tf->key_name); write(" = "); emit_expr(tf->value);
        } else if (tf->key_expr) {
            write('['); emit_expr(tf->key_expr); write("] = "); emit_expr(tf->value);
        } else {
            emit_expr(tf->value);
        }
    }

    template <typename Range>
    void emit_param_list(const Range& params, bool varargs) {
        bool first = true;
        for (auto* p : params) {
            if (!first) write(", ");
            emit_expr(p);
            first = false;
        }
        if (varargs) {
            if (!first) write(", ");
            write("...");
        }
    }

    // Emit the contents of a block (not including its opening/closing keywords).
    // Increases indent for the duration; safe to call with nullptr for empty bodies.
    void emit_block_inner(NodePtr maybe_block) {
        if (!maybe_block) return;
        auto* b = as<BlockNode>(maybe_block);
        if (!b) {
            // Caller handed a non-block — likely a single statement wrapper.
            ++indent_level_;
            indent(); emit_stmt(maybe_block); newline();
            --indent_level_;
            return;
        }
        ++indent_level_;
        for (auto* s : b->statements) {
            indent(); emit_stmt(s); newline();
        }
        --indent_level_;
    }

    // Dispatch for statement position. Does NOT indent — caller indents then
    // calls emit_stmt. Does NOT append newline — caller terminates the line.
    void emit_stmt(NodePtr n) {
        if (!n) return;
        switch (n->kind) {
            case NodeKind::LocalDecl: {
                auto* d = as<LocalDeclNode>(n);
                write("local ");
                write_csv(d->names);
                if (!d->values.empty()) {
                    write(" = ");
                    write_csv(d->values);
                }
                return;
            }
            case NodeKind::Assignment: {
                auto* a = as<AssignmentNode>(n);
                write_csv(a->targets);
                write(" = ");
                write_csv(a->values);
                return;
            }
            case NodeKind::CompoundAssign: {
                auto* ca = as<CompoundAssignNode>(n);
                emit_expr(ca->target);
                write(' '); write(ca->op); write(' ');
                emit_expr(ca->value);
                return;
            }
            case NodeKind::FunctionCall:
            case NodeKind::MethodCall:
                emit_expr(n);
                return;
            case NodeKind::Return: {
                auto* r = as<ReturnNode>(n);
                write("return");
                if (!r->values.empty()) {
                    write(' ');
                    write_csv(r->values);
                }
                return;
            }
            case NodeKind::Break:   write("break"); return;
            case NodeKind::Goto: {
                auto* g = as<GotoNode>(n);
                write("goto "); write(g->label);
                return;
            }
            case NodeKind::Label: {
                auto* l = as<LabelNode>(n);
                write("::"); write(l->name); write("::");
                return;
            }
            case NodeKind::Print: {
                auto* p = as<PrintNode>(n);
                write("? ");
                write_csv(p->values);
                return;
            }
            case NodeKind::If: {
                auto* i = as<IfNode>(n);
                bool first = true;
                for (auto& br : i->branches) {
                    write(first ? "if " : "elseif ");
                    emit_expr(br.cond);
                    write(" then"); newline();
                    emit_block_inner(br.body);
                    indent();
                    first = false;
                }
                if (i->else_body) {
                    write("else"); newline();
                    emit_block_inner(i->else_body);
                    indent();
                }
                write("end");
                return;
            }
            case NodeKind::ShortIf: {
                auto* si = as<ShortIfNode>(n);
                write("if ("); emit_expr(si->cond); write(") ");
                emit_stmt(si->consequence);
                if (si->alternative) {
                    write(" else "); emit_stmt(si->alternative);
                }
                return;
            }
            case NodeKind::While: {
                auto* w = as<WhileNode>(n);
                write("while "); emit_expr(w->cond); write(" do"); newline();
                emit_block_inner(w->body);
                indent(); write("end");
                return;
            }
            case NodeKind::ShortWhile: {
                auto* sw = as<ShortWhileNode>(n);
                write("while ("); emit_expr(sw->cond); write(") ");
                emit_stmt(sw->body);
                return;
            }
            case NodeKind::Repeat: {
                auto* r = as<RepeatNode>(n);
                write("repeat"); newline();
                emit_block_inner(r->body);
                indent(); write("until "); emit_expr(r->cond);
                return;
            }
            case NodeKind::ForNumeric: {
                auto* f = as<ForNumericNode>(n);
                write("for "); write(f->var); write(" = ");
                emit_expr(f->start); write(", "); emit_expr(f->finish);
                if (f->step) { write(", "); emit_expr(f->step); }
                write(" do"); newline();
                emit_block_inner(f->body);
                indent(); write("end");
                return;
            }
            case NodeKind::ForGeneric: {
                auto* f = as<ForGenericNode>(n);
                write("for ");
                write_csv(f->names);
                write(" in ");
                write_csv(f->exprs);
                write(" do"); newline();
                emit_block_inner(f->body);
                indent(); write("end");
                return;
            }
            case NodeKind::Do: {
                auto* d = as<DoNode>(n);
                write("do"); newline();
                emit_block_inner(d->body);
                indent(); write("end");
                return;
            }
            case NodeKind::FunctionStmt: {
                auto* f = as<FunctionStmtNode>(n);
                if (f->is_local) write("local ");
                write("function ");
                bool first = true;
                for (auto* part : f->name_parts) {
                    if (!first) write('.');
                    emit_expr(part);
                    first = false;
                }
                if (!f->method_name.empty()) {
                    write(':'); write(f->method_name);
                }
                write('(');
                emit_param_list(f->params, f->varargs);
                write(')'); newline();
                emit_block_inner(f->body);
                indent(); write("end");
                return;
            }
            case NodeKind::Block: {
                // Bare block in statement position (unusual) — emit as do/end
                // to preserve scoping.
                write("do"); newline();
                emit_block_inner(n);
                indent(); write("end");
                return;
            }
            case NodeKind::Unknown:
                write(as<UnknownNode>(n)->raw);
                return;
            default:
                write("--[[ unhandled stmt: "); write(type_name(n->kind)); write(" ]]--");
                return;
        }
    }

public:
    Writer() { out_.reserve(256); }

    std::string& write_program(NodePtr root) {
        out_.clear();
        indent_level_ = 0;
        if (auto* p = as<ProgramNode>(root)) {
            for (auto* s : p->statements) {
                indent(); emit_stmt(s); newline();
            }
            if (p->trailing_return) {
                indent(); emit_stmt(p->trailing_return); newline();
            }
        } else if (root) {
            emit_stmt(root); newline();
        }
        return out_;
    }

    const std::string& output() const { return out_; }
};

// Convenience: one-shot AST → source string.
inline std::string to_source(NodePtr root) {
    Writer w;
    return w.write_program(root);
}

} // namespace Fond::Pico8
