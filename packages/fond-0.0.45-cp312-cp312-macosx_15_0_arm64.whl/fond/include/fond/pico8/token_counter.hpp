#pragma once

#include <filesystem>
#include <string_view>

#include "fond/cpp_tree_sitter.hpp"
#include "fond/pico8/ast_symbols.hpp"
#include "fond/pico8/data_reader.hpp" // for detect_cart / strip_cart
#include "fond/pico8/reader.hpp"      // for load_pico8_language()

// ===========================================================================
// PICO-8 TOKEN COUNTER
// ===========================================================================
// Returns the same token count PICO-8's editor reports. Carts are capped at
// 8192 tokens; this is the function that tells you if your code fits.
//
// Calibrated to match PICO-8's manual exactly, verified against three real
// cartridges (tests/data/all_tokens.p8 = 509, move.p8 = 529,
// sun_escapes_me.p8 = 5127). Regression tests pin those numbers.
//
// ---------------------------------------------------------------------------
// WHAT COUNTS (per PICO-8 manual):
//   * Literals: nil, false, true, numbers (decimal / hex / binary /
//     scientific / with-leading-dot), strings (any size)
//   * Variables (identifiers) and operators
//   * Opening brackets `(` `[` `{`
//   * Keywords — every one EXCEPT `end` and `local`
//
// WHAT'S FREE (not counted):
//   * Punctuation: `,` `;` `.` `:` `::`
//   * Closing brackets: `)` `]` `}`
//   * Keywords: `end`, `local`
//   * Unary `-` or `~` on a numeric literal (-3 and ~1e4 are one token each)
//   * Comments and whitespace (never reach the counter)
//
// ---------------------------------------------------------------------------
// GOTCHAS learned during calibration — if you change anything, remember:
//
// 1. OPT-IN ONLY: structural nodes (sym_program, sym_tableconstructor,
//    sym_function_call, etc.) contribute ZERO directly — their children do.
//    Do NOT switch to "count every leaf" — it counts structural placeholders
//    like an empty sym_program for empty input.
//
// 2. sym_boolean IS A WRAPPER, not a token. It wraps anon_sym_true or
//    anon_sym_false. If you add it to the countable list, every boolean
//    literal gets counted TWICE (wrapper + inner anon). The inner anon tokens
//    are caught by the 1-84 range check already.
//
// 3. ALIASED KEYWORDS live above the anon-range (ID > 84). The grammar
//    promotes `do` inside `while...do` to alias_sym_while_do, `do` in a
//    standalone `do` block to alias_sym_do_start, etc. These MUST be listed
//    explicitly — they don't fall into the range check. But NOT their `end`
//    counterparts: `end` is free, so while_end/for_end/function_end are
//    intentionally excluded.
//
// 4. ALIASED STRING-ARG CALLS: `f"str"` (no parens) aliases the string node
//    to alias_sym_string_argument, which REPLACES sym_string in the tree. If
//    you don't list it, the string literal vanishes from the count. Table-arg
//    form (`f{...}`) doesn't have this problem because children emit normally.
//
// 5. UNARY MINUS/COMPLEMENT ON LITERAL is free, but ONLY when the operand is
//    a numeric literal. `-x` (unary on variable) counts the `-` normally.
//    The check walks the unary_operation's children for a sym_number.
//
// 6. picotool's counter drifts from PICO-8 in at least two places: it counts
//    scientific-notation numbers as 2 tokens (PICO-8 counts 1), and its
//    source has a TODO acknowledging `1 .. 5` vs `1..5` tokenization is off.
//    We match PICO-8, not picotool, where they disagree.
//
// 7. ERROR nodes from partial parses are silently skipped (count returns 0
//    for a tree with any error). Callers wanting to distinguish "empty file"
//    from "parse error" should parse via Reader first.
//
// 8. CART FRAMING is auto-stripped: pass a raw .p8 cartridge with
//    __gfx__/__map__ and only the __lua__ section gets counted.
// ===========================================================================
namespace Fond::Pico8 {

inline bool is_free_token(sym::Symbol s) {
    switch (s) {
        case sym::anon_sym_COMMA:
        case sym::anon_sym_SEMI:
        case sym::anon_sym_DOT:
        case sym::anon_sym_COLON:
        case sym::anon_sym_COLON_COLON:
        case sym::anon_sym_RPAREN:
        case sym::anon_sym_RBRACK:
        case sym::anon_sym_RBRACE:
        case sym::anon_sym_local:
        case sym::anon_sym_end:
            return true;
        default:
            return false;
    }
}

inline bool is_countable_terminal(sym::Symbol s) {
    switch (s) {
        case sym::sym_number:
        case sym::sym_nil:
        case sym::sym_ellipsis:
        case sym::sym_break_statement:
        case sym::sym_function_start:
        case sym::sym_identifier:
        case sym::sym_string:
        case sym::alias_sym_while_do:
        case sym::alias_sym_do_start:
        case sym::alias_sym_string_argument:
            return true;
        default:
            break;
    }
    // Every anon_sym_* (punctuation/keyword/operator) falls in IDs 1-84 in
    // the current grammar. Upper bound is anon_sym_DASH_DASH (84). If the
    // grammar ever grows past that, this range needs updating.
    return s >= 1 && s <= 84;
}

inline bool is_comment_token(sym::Symbol s) {
    return s == sym::sym_comment
        || s == sym::sym__block_comment_start
        || s == sym::sym__block_comment_content
        || s == sym::sym__block_comment_end;
}

class TokenCounter {
    ts::Parser parser_;
    std::string source_;

    static constexpr size_t token_weight(sym::Symbol, ts::Node) { return 1; }

    size_t visit(ts::Node n) const {
        if (n.isNull()) return 0;
        auto s = n.getSymbol();

        if (is_comment_token(s)) return 0;

        if (s == sym::sym_unary_operation && is_unary_on_literal(n)) {
            uint32_t nc = n.getNumChildren();
            for (uint32_t i = 0; i < nc; ++i) {
                auto child = n.getChild(i);
                if (child.getSymbol() == sym::sym_number) {
                    return visit(child);
                }
            }
            return 0;
        }

        size_t total = 0;
        if (is_countable_terminal(s) && !is_free_token(s)) {
            total += token_weight(s, n);
        }

        uint32_t n_children = n.getNumChildren();
        for (uint32_t i = 0; i < n_children; ++i) {
            total += visit(n.getChild(i));
        }
        return total;
    }

    bool is_unary_on_literal(ts::Node n) const {
        auto range = n.getByteRange();
        if (range.end > source_.size() || range.start >= source_.size()) return false;
        char first = source_[range.start];
        if (first != '-' && first != '~') return false;
        uint32_t nc = n.getNumChildren();
        for (uint32_t i = 0; i < nc; ++i) {
            if (n.getChild(i).getSymbol() == sym::sym_number) return true;
        }
        return false;
    }

public:
    TokenCounter() : parser_(load_pico8_language()) {}

    size_t count(std::string_view src) {
        std::string_view body = Data::strip_cart(src);
        source_.assign(body.data(), body.size());
        auto tree = parser_.parseString(source_);
        if (tree.hasError()) return 0;
        return visit(tree.getRootNode());
    }

    size_t count_file(const std::filesystem::path& path) {
        auto content = Fond::FileIO::read(path);
        return count(content);
    }
};

// One-shot convenience — constructs a fresh counter per call. For repeated
// counting use TokenCounter directly to amortize parser construction.
inline size_t count_tokens(std::string_view src) {
    TokenCounter c;
    return c.count(src);
}

} // namespace Fond::Pico8
