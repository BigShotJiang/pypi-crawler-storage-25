#pragma once

#include <cstdint>
#include <string_view>
#include <variant>
#include <vector>

#include "fond/collections/arena.hpp"
#include "fond/collections/maps.hpp" // IWYU pragma: keep

// PICO-8 cartridge header constants. Reader detects these to auto-strip
// cartridge framing; writer emits them when saving to a .p8 target.
namespace Fond::Pico8 {
inline constexpr std::string_view CART_HEADER  = "pico-8 cartridge // http://www.pico-8.com";
inline constexpr std::string_view CART_VERSION = "version 43";
inline constexpr std::string_view CART_LUA_TAG = "__lua__";
} // namespace Fond::Pico8

// Pico8 Data codec — pure-data subset of PICO-8 Lua treated as a serialization
// format. Not a Lua runtime, not an AST: this is the "dataclass" layer, for
// files that are only globals assigning table literals.
//
// If consumers need function calls, metatables, require(), arithmetic, etc.,
// reach for fond/lua/serialize.hpp (sol2-backed) or a real Lua VM. This layer
// refuses to pretend.
namespace Fond::Pico8::Data {

using Arena = CollectionsCub::Arena;
using Pico8Str = ArenaString;

struct Pico8Value;

namespace p8data {
using array = std::vector<Pico8Value, ArenaAlloc<Pico8Value>>;
using table = CollectionsCub::OrderedMap<ArenaString, Pico8Value,
    ArenaAlloc<std::pair<const ArenaString, Pico8Value>>>;
} // namespace p8data

// Null/None marker — distinguishes "missing field" from "field present but nil".
struct Pico8None {
    bool operator==(const Pico8None&) const { return true; }
};

struct Pico8Value {
    std::variant<
        Pico8None,
        bool,
        int64_t,
        double,
        Pico8Str,
        p8data::array,
        p8data::table
    > data;

    Pico8Value() : data(Pico8None{}) {}
    Pico8Value(Pico8None) : data(Pico8None{}) {}
    Pico8Value(bool v) : data(v) {}
    Pico8Value(int64_t v) : data(v) {}
    Pico8Value(int v) : data(static_cast<int64_t>(v)) {}
    Pico8Value(double v) : data(v) {}
    Pico8Value(Pico8Str v) : data(std::move(v)) {}
    Pico8Value(p8data::array v) : data(std::move(v)) {}
    Pico8Value(p8data::table v) : data(std::move(v)) {}

    Pico8Value(std::string_view sv, Arena& arena)
        : data(ArenaString(sv.data(), sv.size(), ArenaAlloc<char>(arena))) {}

    bool is_none() const { return std::holds_alternative<Pico8None>(data); }
    bool is_bool() const { return std::holds_alternative<bool>(data); }
    bool is_int() const { return std::holds_alternative<int64_t>(data); }
    bool is_float() const { return std::holds_alternative<double>(data); }
    bool is_string() const { return std::holds_alternative<Pico8Str>(data); }
    bool is_array() const { return std::holds_alternative<p8data::array>(data); }
    bool is_table() const { return std::holds_alternative<p8data::table>(data); }

    bool& as_bool() { return std::get<bool>(data); }
    int64_t& as_int() { return std::get<int64_t>(data); }
    double& as_float() { return std::get<double>(data); }
    Pico8Str& as_string() { return std::get<Pico8Str>(data); }
    p8data::array& as_array() { return std::get<p8data::array>(data); }
    p8data::table& as_table() { return std::get<p8data::table>(data); }

    const bool& as_bool() const { return std::get<bool>(data); }
    const int64_t& as_int() const { return std::get<int64_t>(data); }
    const double& as_float() const { return std::get<double>(data); }
    const Pico8Str& as_string() const { return std::get<Pico8Str>(data); }
    const p8data::array& as_array() const { return std::get<p8data::array>(data); }
    const p8data::table& as_table() const { return std::get<p8data::table>(data); }

    template <typename T>
    T get(T fallback = {}) const {
        if constexpr (std::is_same_v<T, bool>) {
            return is_bool() ? as_bool() : fallback;
        } else if constexpr (std::is_same_v<T, int64_t> || std::is_integral_v<T>) {
            // Accept int-valued floats too — Lua uses double for everything,
            // so a literal `5` in source may arrive as either side depending
            // on how the reader classified it.
            if (is_int()) return static_cast<T>(as_int());
            if (is_float()) return static_cast<T>(as_float());
            return fallback;
        } else if constexpr (std::is_same_v<T, double> || std::is_floating_point_v<T>) {
            if (is_float()) return static_cast<T>(as_float());
            if (is_int()) return static_cast<T>(as_int());
            return fallback;
        } else if constexpr (std::is_same_v<T, Pico8Str>) {
            return is_string() ? as_string() : fallback;
        } else {
            return fallback;
        }
    }

    Pico8Value& operator[](const Pico8Str& key) { return as_table()[key]; }
    Pico8Value& operator[](size_t index) { return as_array()[index]; }
};

inline const Pico8Value PICO8_NULL  = Pico8Value{};
inline const Pico8Value PICO8_TRUE  = Pico8Value{true};
inline const Pico8Value PICO8_FALSE = Pico8Value{false};

} // namespace Fond::Pico8::Data
