#pragma once

#include <cstdint>
#include <string_view>
#include <vector>

#include "fond/collections/arena.hpp"

namespace Fond::Pico8 {

using Arena = CollectionsCub::Arena;

// AST string fields are views into the parse source. The source text outlives
// the AST (the reader holds it), so slicing is safe and allocation-free. If a
// consumer wants an owned copy, it can intern into its own arena.
using Pico8Str = std::string_view;

struct Node;
using NodePtr = Node*;
using NodeList = std::vector<NodePtr, ArenaAlloc<NodePtr>>;

// X-macro: single source of truth for the node kind list.
// Order matches the rough "scalar → expr → statement → root" grouping but is
// otherwise arbitrary — changing it doesn't affect correctness, only the
// enum's underlying integer value.
#define FOND_PICO8_NODE_KINDS(X) \
    /* literals */              \
    X(Nil)                      \
    X(Boolean)                  \
    X(Number)                   \
    X(String)                   \
    X(Ellipsis)                 \
    X(Identifier)               \
    /* expressions */           \
    X(BinaryOp)                 \
    X(UnaryOp)                  \
    X(Index)                    \
    X(FieldAccess)              \
    X(FunctionCall)             \
    X(MethodCall)               \
    X(TableConstructor)         \
    X(TableField)               \
    X(FunctionExpr)             \
    /* statements */            \
    X(Block)                    \
    X(LocalDecl)                \
    X(Assignment)               \
    X(CompoundAssign)           \
    X(If)                       \
    X(ShortIf)                  \
    X(While)                    \
    X(ShortWhile)               \
    X(Repeat)                   \
    X(ForNumeric)               \
    X(ForGeneric)               \
    X(Do)                       \
    X(Return)                   \
    X(Break)                    \
    X(Goto)                     \
    X(Label)                    \
    X(Print)                    \
    X(FunctionStmt)             \
    /* root */                  \
    X(Program)                  \
    /* fallback for unhandled Tree-sitter nodes during incremental build */ \
    X(Unknown)

enum class NodeKind : uint16_t {
#define FOND_PICO8_X(Name) Name,
    FOND_PICO8_NODE_KINDS(FOND_PICO8_X)
#undef FOND_PICO8_X
    _Count,
};

inline constexpr const char* type_name(NodeKind k) {
    switch (k) {
#define FOND_PICO8_X(Name) case NodeKind::Name: return #Name;
        FOND_PICO8_NODE_KINDS(FOND_PICO8_X)
#undef FOND_PICO8_X
        default: return "???";
    }
}

static inline NodeKind p8str_to_enum(std::string_view str) {
    const size_t len = str.size();
    if (len < 2 || len > 16) return NodeKind::Unknown;
    const auto key0 = static_cast<uint8_t>(str[0]);
    switch (key0) {
    case 0x00000041: /* 'A' */
        if (str == "Assignment") return NodeKind::Assignment;
        break;
    case 0x00000042: /* 'B' */
        if (str == "BinaryOp") return NodeKind::BinaryOp;
        if (str == "Block") return NodeKind::Block;
        if (str == "Boolean") return NodeKind::Boolean;
        if (str == "Break") return NodeKind::Break;
        break;
    case 0x00000043: /* 'C' */
        if (str == "CompoundAssign") return NodeKind::CompoundAssign;
        break;
    case 0x00000044: /* 'D' */
        if (len == 2 && str[1] == 'o') return NodeKind::Do;
        break;
    case 0x00000045: /* 'E' */
        if (str == "Ellipsis") return NodeKind::Ellipsis;
        break;
    case 0x00000046: /* 'F' */
        if (str == "FieldAccess") return NodeKind::FieldAccess;
        if (str == "ForGeneric") return NodeKind::ForGeneric;
        if (str == "ForNumeric") return NodeKind::ForNumeric;
        if (str == "FunctionCall") return NodeKind::FunctionCall;
        if (str == "FunctionExpr") return NodeKind::FunctionExpr;
        if (str == "FunctionStmt") return NodeKind::FunctionStmt;
        break;
    case 0x00000047: /* 'G' */
        if (str == "Goto") return NodeKind::Goto;
        break;
    case 0x00000049: /* 'I' */
        if (str == "Identifier") return NodeKind::Identifier;
        if (str == "If") return NodeKind::If;
        if (str == "Index") return NodeKind::Index;
        break;
    case 0x0000004c: /* 'L' */
        if (str == "Label") return NodeKind::Label;
        if (str == "LocalDecl") return NodeKind::LocalDecl;
        break;
    case 0x0000004d: /* 'M' */
        if (str == "MethodCall") return NodeKind::MethodCall;
        break;
    case 0x0000004e: /* 'N' */
        if (str == "Nil") return NodeKind::Nil;
        if (str == "Number") return NodeKind::Number;
        break;
    case 0x00000050: /* 'P' */
        if (str == "Print") return NodeKind::Print;
        if (str == "Program") return NodeKind::Program;
        break;
    case 0x00000052: /* 'R' */
        if (str == "Repeat") return NodeKind::Repeat;
        if (str == "Return") return NodeKind::Return;
        break;
    case 0x00000053: /* 'S' */
        if (str == "ShortIf") return NodeKind::ShortIf;
        if (str == "ShortWhile") return NodeKind::ShortWhile;
        if (str == "String") return NodeKind::String;
        break;
    case 0x00000054: /* 'T' */
        if (str == "TableConstructor") return NodeKind::TableConstructor;
        if (str == "TableField") return NodeKind::TableField;
        break;
    case 0x00000055: /* 'U' */
        if (str == "UnaryOp") return NodeKind::UnaryOp;
        if (str == "Unknown") return NodeKind::Unknown;
        break;
    case 0x00000057: /* 'W' */
        if (str == "While") return NodeKind::While;
        break;
    }
    return NodeKind::Unknown;
}

// kind_from_string: O(N) linear scan. Fine for debug/repl use; if this ever
// becomes hot, swap for a perfect-hash table (fond has gen-lookup for this).
inline constexpr NodeKind kind_from_string(std::string_view s) {
#define FOND_PICO8_X(Name) if (s == #Name) return NodeKind::Name;
    FOND_PICO8_NODE_KINDS(FOND_PICO8_X)
#undef FOND_PICO8_X
    return NodeKind::Unknown;
}

// Common header on every node. Source span lets errors/pretty-printers point
// back at the original text. kind tag drives dispatch via switch.
struct Node {
    NodeKind kind;
    uint32_t source_start = 0;
    uint32_t source_end = 0;

    constexpr Node(NodeKind k) : kind(k) {}
};

// ---- Literal / terminal nodes ----------------------------------------------

struct NilNode : Node {
    NilNode() : Node(NodeKind::Nil) {}
};

struct BooleanNode : Node {
    bool value = false;
    BooleanNode(bool v) : Node(NodeKind::Boolean), value(v) {}
};

// Numbers are kept as source text until a consumer asks for a parsed value —
// PICO-8 uses 16.16 fixed-point with hex/binary literals, so we avoid locking
// in a C++ numeric representation at read-time.
struct NumberNode : Node {
    Pico8Str raw;
    NumberNode(Pico8Str s) : Node(NodeKind::Number), raw(s) {}
};

struct StringNode : Node {
    Pico8Str value;
    StringNode(Pico8Str v) : Node(NodeKind::String), value(v) {}
};

struct EllipsisNode : Node {
    EllipsisNode() : Node(NodeKind::Ellipsis) {}
};

struct IdentifierNode : Node {
    Pico8Str name;
    IdentifierNode(Pico8Str n) : Node(NodeKind::Identifier), name(n) {}
};

struct UnknownNode : Node {
    Pico8Str ts_kind;
    Pico8Str raw;
    UnknownNode(Pico8Str k, Pico8Str r)
        : Node(NodeKind::Unknown), ts_kind(k), raw(r) {}
};

// ---- Expression nodes ------------------------------------------------------

struct BinaryOpNode : Node {
    Pico8Str op;
    NodePtr lhs = nullptr;
    NodePtr rhs = nullptr;
    BinaryOpNode() : Node(NodeKind::BinaryOp) {}
};

struct UnaryOpNode : Node {
    Pico8Str op;
    NodePtr operand = nullptr;
    UnaryOpNode() : Node(NodeKind::UnaryOp) {}
};

struct IndexNode : Node {
    NodePtr object = nullptr;
    NodePtr index = nullptr;
    IndexNode() : Node(NodeKind::Index) {}
};

struct FieldAccessNode : Node {
    NodePtr object = nullptr;
    Pico8Str field;
    FieldAccessNode() : Node(NodeKind::FieldAccess) {}
};

struct FunctionCallNode : Node {
    NodePtr callee = nullptr;
    NodeList args;
    FunctionCallNode(Arena& a) : Node(NodeKind::FunctionCall), args(ArenaAlloc<NodePtr>(a)) {}
};

struct MethodCallNode : Node {
    NodePtr receiver = nullptr;
    Pico8Str method;
    NodeList args;
    MethodCallNode(Arena& a) : Node(NodeKind::MethodCall), args(ArenaAlloc<NodePtr>(a)) {}
};

struct TableFieldNode : Node {
    // Three cases: named (key_name), computed (key_expr), positional (both null).
    Pico8Str key_name;
    NodePtr key_expr = nullptr;
    NodePtr value = nullptr;
    TableFieldNode() : Node(NodeKind::TableField) {}
};

struct TableConstructorNode : Node {
    NodeList fields;
    TableConstructorNode(Arena& a) : Node(NodeKind::TableConstructor), fields(ArenaAlloc<NodePtr>(a)) {}
};

struct FunctionExprNode : Node {
    NodeList params;
    bool varargs = false;
    NodePtr body = nullptr;
    FunctionExprNode(Arena& a) : Node(NodeKind::FunctionExpr), params(ArenaAlloc<NodePtr>(a)) {}
};

// ---- Statement nodes -------------------------------------------------------

struct BlockNode : Node {
    NodeList statements;
    BlockNode(Arena& a) : Node(NodeKind::Block), statements(ArenaAlloc<NodePtr>(a)) {}
};

struct LocalDeclNode : Node {
    NodeList names;
    NodeList values;
    LocalDeclNode(Arena& a)
        : Node(NodeKind::LocalDecl),
          names(ArenaAlloc<NodePtr>(a)),
          values(ArenaAlloc<NodePtr>(a)) {}
};

struct AssignmentNode : Node {
    NodeList targets;
    NodeList values;
    AssignmentNode(Arena& a)
        : Node(NodeKind::Assignment),
          targets(ArenaAlloc<NodePtr>(a)),
          values(ArenaAlloc<NodePtr>(a)) {}
};

struct CompoundAssignNode : Node {
    NodePtr target = nullptr;
    Pico8Str op;
    NodePtr value = nullptr;
    CompoundAssignNode() : Node(NodeKind::CompoundAssign) {}
};

struct IfBranch {
    NodePtr cond = nullptr;
    NodePtr body = nullptr;
};

struct IfNode : Node {
    std::vector<IfBranch, ArenaAlloc<IfBranch>> branches;
    NodePtr else_body = nullptr;
    IfNode(Arena& a) : Node(NodeKind::If), branches(ArenaAlloc<IfBranch>(a)) {}
};

struct ShortIfNode : Node {
    NodePtr cond = nullptr;
    NodePtr consequence = nullptr;
    NodePtr alternative = nullptr;
    ShortIfNode() : Node(NodeKind::ShortIf) {}
};

struct WhileNode : Node {
    NodePtr cond = nullptr;
    NodePtr body = nullptr;
    WhileNode() : Node(NodeKind::While) {}
};

struct ShortWhileNode : Node {
    NodePtr cond = nullptr;
    NodePtr body = nullptr;
    ShortWhileNode() : Node(NodeKind::ShortWhile) {}
};

struct RepeatNode : Node {
    NodePtr body = nullptr;
    NodePtr cond = nullptr;
    RepeatNode() : Node(NodeKind::Repeat) {}
};

struct ForNumericNode : Node {
    Pico8Str var;
    NodePtr start = nullptr;
    NodePtr finish = nullptr;
    NodePtr step = nullptr; // nullable
    NodePtr body = nullptr;
    ForNumericNode() : Node(NodeKind::ForNumeric) {}
};

struct ForGenericNode : Node {
    NodeList names;
    NodeList exprs;
    NodePtr body = nullptr;
    ForGenericNode(Arena& a)
        : Node(NodeKind::ForGeneric),
          names(ArenaAlloc<NodePtr>(a)),
          exprs(ArenaAlloc<NodePtr>(a)) {}
};

struct DoNode : Node {
    NodePtr body = nullptr;
    DoNode() : Node(NodeKind::Do) {}
};

struct ReturnNode : Node {
    NodeList values;
    ReturnNode(Arena& a) : Node(NodeKind::Return), values(ArenaAlloc<NodePtr>(a)) {}
};

struct BreakNode : Node {
    BreakNode() : Node(NodeKind::Break) {}
};

struct GotoNode : Node {
    Pico8Str label;
    GotoNode() : Node(NodeKind::Goto) {}
};

struct LabelNode : Node {
    Pico8Str name;
    LabelNode() : Node(NodeKind::Label) {}
};

struct PrintNode : Node {
    NodeList values;
    PrintNode(Arena& a) : Node(NodeKind::Print), values(ArenaAlloc<NodePtr>(a)) {}
};

struct FunctionStmtNode : Node {
    bool is_local = false;
    // Name parts: ident ("." ident)* optional (":" ident). Length >= 1.
    // method_name set iff ":" form was used.
    NodeList name_parts;
    Pico8Str method_name;
    NodeList params;
    bool varargs = false;
    NodePtr body = nullptr;
    FunctionStmtNode(Arena& a)
        : Node(NodeKind::FunctionStmt),
          name_parts(ArenaAlloc<NodePtr>(a)),
          params(ArenaAlloc<NodePtr>(a)) {}
};

// ---- Root ------------------------------------------------------------------

struct ProgramNode : Node {
    NodeList statements;
    NodePtr trailing_return = nullptr; // optional module-level return
    ProgramNode(Arena& a) : Node(NodeKind::Program), statements(ArenaAlloc<NodePtr>(a)) {}
};

// ---- Safe downcast ---------------------------------------------------------
// Usage: if (auto* n = as<IfNode>(node)) { ... }
// Relies on the 1:1 mapping between struct type and NodeKind tag.
template <typename T>
inline T* as(NodePtr n);

#define FOND_PICO8_AS(Name) \
    template <> inline Name##Node* as<Name##Node>(NodePtr n) { \
        return (n && n->kind == NodeKind::Name) ? static_cast<Name##Node*>(n) : nullptr; \
    }
FOND_PICO8_NODE_KINDS(FOND_PICO8_AS)
#undef FOND_PICO8_AS

} // namespace Fond::Pico8
