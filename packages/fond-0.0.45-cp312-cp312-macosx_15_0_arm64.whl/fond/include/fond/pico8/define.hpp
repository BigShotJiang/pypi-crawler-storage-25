#pragma once

#include <string>
#include <type_traits>
#include <vector>

#include "fond/macros/for_each.hpp"
#include "fond/pico8/data_reader.hpp" // IWYU pragma: keep
#include "fond/pico8/data_value.hpp"
#include "fond/pico8/data_writer.hpp" // IWYU pragma: keep

// PICO8_DEFINE — intrusive macro that grows a struct with pico8_pack /
// pico8_unpack / pico8_save / pico8_dumps methods. Mirrors TOML_DEFINE.
//
// Usage:
//   struct Wall {
//     float x, y;
//     int tex_top = -1;
//     PICO8_DEFINE(Wall, x, y, tex_top)
//   };
//
// The macro assumes the struct is default-constructible (used as the source
// of per-field fallback values in pico8_unpack). Field types must be one of:
// bool, integral, floating-point, std::string, enum, std::vector<T>, or
// another struct that itself uses PICO8_DEFINE.
namespace Fond::Pico8::Data {

template <typename T> struct is_vector : std::false_type {};
template <typename T> struct is_vector<std::vector<T>> : std::true_type {};

// Thread-local arena for PICO8_DEFINE macro. Resets each call so the arena
// doesn't grow unbounded across repeated serializations. Not suitable for
// concurrent writers holding onto returned Pico8Values — copy out first.
inline Arena& define_arena() {
    static thread_local Arena arena(4096);
    return arena;
}

template <typename T>
inline Pico8Value pico8_to_value(const T& val) {
    auto& arena = define_arena();
    if constexpr (std::is_same_v<T, bool>) {
        return Pico8Value(val);
    } else if constexpr (std::is_enum_v<T>) {
        return Pico8Value(static_cast<int64_t>(val));
    } else if constexpr (std::is_same_v<T, double> || std::is_same_v<T, float>) {
        return Pico8Value(static_cast<double>(val));
    } else if constexpr (std::is_same_v<T, std::string>) {
        return Pico8Value(Pico8Str(val.data(), val.size(), ArenaAlloc<char>(arena)));
    } else if constexpr (std::is_integral_v<T>) {
        return Pico8Value(static_cast<int64_t>(val));
    } else if constexpr (is_vector<T>::value) {
        p8data::array arr{ArenaAlloc<Pico8Value>(arena)};
        arr.reserve(val.size());
        for (const auto& item : val) arr.push_back(pico8_to_value(item));
        return Pico8Value(std::move(arr));
    } else {
        // Nested struct path — consumer must define pico8_pack().
        return val.pico8_pack();
    }
}

template <typename T>
inline T pico8_from_value(const p8data::table& tbl, const char* name, const T& fallback) {
    Pico8Str key(name, ArenaAlloc<char>(define_arena()));
    auto it = tbl.find(key);
    if (it == tbl.end()) return fallback;
    const auto& val = it->second;

    if constexpr (std::is_same_v<T, bool>) {
        return val.is_bool() ? val.as_bool() : fallback;
    } else if constexpr (std::is_enum_v<T>) {
        if (val.is_int()) return static_cast<T>(val.as_int());
        if (val.is_float()) return static_cast<T>(static_cast<int64_t>(val.as_float()));
        return fallback;
    } else if constexpr (std::is_same_v<T, double> || std::is_same_v<T, float>) {
        if (val.is_float()) return static_cast<T>(val.as_float());
        if (val.is_int()) return static_cast<T>(val.as_int());
        return fallback;
    } else if constexpr (std::is_same_v<T, std::string>) {
        if (!val.is_string()) return fallback;
        const auto& s = val.as_string();
        return std::string(s.data(), s.size());
    } else if constexpr (std::is_integral_v<T>) {
        if (val.is_int()) return static_cast<T>(val.as_int());
        if (val.is_float()) return static_cast<T>(val.as_float());
        return fallback;
    } else if constexpr (is_vector<T>::value) {
        if (!val.is_array()) return fallback;
        T result;
        using Elem = typename T::value_type;
        const auto& arr = val.as_array();
        result.reserve(arr.size());
        for (const auto& item : arr) {
            if constexpr (std::is_same_v<Elem, bool>) {
                if (item.is_bool()) result.push_back(item.as_bool());
            } else if constexpr (std::is_enum_v<Elem>) {
                if (item.is_int()) result.push_back(static_cast<Elem>(item.as_int()));
                else if (item.is_float()) result.push_back(static_cast<Elem>(static_cast<int64_t>(item.as_float())));
            } else if constexpr (std::is_floating_point_v<Elem>) {
                if (item.is_float()) result.push_back(static_cast<Elem>(item.as_float()));
                else if (item.is_int()) result.push_back(static_cast<Elem>(item.as_int()));
            } else if constexpr (std::is_integral_v<Elem>) {
                if (item.is_int()) result.push_back(static_cast<Elem>(item.as_int()));
                else if (item.is_float()) result.push_back(static_cast<Elem>(item.as_float()));
            } else if constexpr (std::is_same_v<Elem, std::string>) {
                if (item.is_string()) {
                    const auto& s = item.as_string();
                    result.emplace_back(s.data(), s.size());
                }
            } else {
                // Nested struct in vector — consumer provides pico8_unpack.
                if (item.is_table()) result.push_back(Elem::pico8_unpack(item.as_table()));
            }
        }
        return result;
    } else {
        if (val.is_table()) return T::pico8_unpack(val.as_table());
        return fallback;
    }
}

// ---------------------------------------------------------------------------
// TopLevelWriter — streams `NAME = value\n\n` per call for files with
// multiple top-level globals (maps, configs). Type-dispatched via
// pico8_to_value, so scalars, vectors, and PICO8_DEFINE'd structs all Just
// Work through one API. Ergonomic mirror of the old sol2 TableWriter.
//
// Usage:
//   std::ofstream f(path);
//   bool is_cart = path.extension() == ".p8";
//   if (is_cart) write_cart_header(f);
//   TopLevelWriter w(f, {.pico8_safe = is_cart});
//   w.write("PLAYER_START", m.player_start);
//   w.write("WALLS", m.walls);
// ---------------------------------------------------------------------------
class TopLevelWriter {
    std::ostream& out_;
    WriterConfig config_;

public:
    explicit TopLevelWriter(std::ostream& out, WriterConfig cfg = {})
        : out_(out), config_(cfg) {}

    // Write `NAME = <value>\n\n`. Dispatches on T through pico8_to_value —
    // bool/int/float/string/std::vector<T>/PICO8_DEFINE'd struct all work.
    template <typename T>
    void write(const char* name, const T& val) {
        out_ << name << " = ";
        DataWriter inner(out_, config_);
        inner.write_value(pico8_to_value(val));
        define_arena().reset();
        out_ << "\n\n";
    }
};

} // namespace Fond::Pico8::Data

#define FOND_PICO8_PACK_FIELD(FIELD) \
    tbl_.insert(ArenaString(#FIELD, ArenaAlloc<char>(arena_)), Fond::Pico8::Data::pico8_to_value(FIELD));
#define FOND_PICO8_UNPACK_FIELD(FIELD) \
    obj.FIELD = Fond::Pico8::Data::pico8_from_value(tbl_, #FIELD, defaults.FIELD);

// Grow a struct with pico8_pack (→ Pico8Value table), pico8_unpack (static,
// table → struct), pico8_save (write to file), pico8_dumps (serialize to
// string). Naming mirrors TOML_DEFINE for discoverability.
#define PICO8_DEFINE(Type, ...)                                                 \
Fond::Pico8::Data::Pico8Value pico8_pack() const {                              \
    auto& arena_ = Fond::Pico8::Data::define_arena();                           \
    arena_.reset();                                                             \
    Fond::Pico8::Data::p8data::table tbl_{                                      \
        ArenaAlloc<std::pair<const ArenaString,                                 \
            Fond::Pico8::Data::Pico8Value>>(arena_)};                           \
    FOND_FOR_EACH(FOND_PICO8_PACK_FIELD, __VA_ARGS__)                           \
    return Fond::Pico8::Data::Pico8Value(std::move(tbl_));                      \
}                                                                               \
bool pico8_save(const std::filesystem::path& path) const {                      \
    auto val = pico8_pack();                                                    \
    bool ok = Fond::Pico8::Data::dump(val, path);                               \
    Fond::Pico8::Data::define_arena().reset();                                  \
    return ok;                                                                  \
}                                                                               \
std::string pico8_dumps() const {                                               \
    auto result = Fond::Pico8::Data::to_source(pico8_pack());                   \
    Fond::Pico8::Data::define_arena().reset();                                  \
    return result;                                                              \
}                                                                               \
static Type pico8_unpack(const Fond::Pico8::Data::p8data::table& tbl_) {        \
    Type obj{};                                                                 \
    const Type defaults{};                                                      \
    FOND_FOR_EACH(FOND_PICO8_UNPACK_FIELD, __VA_ARGS__)                         \
    return obj;                                                                 \
}
