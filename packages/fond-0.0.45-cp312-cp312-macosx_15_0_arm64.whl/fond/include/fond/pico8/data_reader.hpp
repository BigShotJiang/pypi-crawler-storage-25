#pragma once

#include <charconv>
#include <cstdlib>
#include <filesystem>
#include <string>
#include <string_view>

#include "fond/pico8/data_value.hpp"
#include "fond/pico8/reader.hpp"
#include "fond/pico8/value.hpp"

namespace Fond::Pico8::Data {

using namespace Fond::Pico8;

// Detect whether the source looks like a PICO-8 cartridge file.
// Checks the magic header line — presence is unambiguous because the string
// "pico-8 cartridge // ..." is a syntax error in bare Lua.
inline bool detect_cart(std::string_view src) {
    return src.starts_with(CART_HEADER);
}

// Strip cart framing and return the substring covering the __lua__ section.
// Passes the source through untouched if no cart header is detected.
// On malformed carts (header present but no __lua__), returns empty view —
// downstream parse() will no-op gracefully.
inline std::string_view strip_cart(std::string_view src) {
    if (!detect_cart(src)) return src;
    // Find the __lua__ marker line; the code starts on the next line.
    auto tag_pos = src.find(CART_LUA_TAG);
    if (tag_pos == std::string_view::npos) return {};
    auto start = src.find('\n', tag_pos);
    if (start == std::string_view::npos) return {};
    ++start;
    // Code ends at the next section marker ("__xxx__") or EOF. Search
    // line-by-line so we only match markers at line-start.
    std::string_view after = src.substr(start);
    size_t line_begin = 0;
    while (line_begin < after.size()) {
        size_t line_end = after.find('\n', line_begin);
        std::string_view line = after.substr(line_begin,
            line_end == std::string_view::npos ? after.size() - line_begin : line_end - line_begin);
        if (line.starts_with("__") && line.ends_with("__") && line.size() >= 4) {
            return after.substr(0, line_begin);
        }
        if (line_end == std::string_view::npos) break;
        line_begin = line_end + 1;
    }
    return after;
}

// DataReader — parses a PICO-8/Lua SOURCE FILE as pure data.
//
// Handles the shape of config files where the entire program is:
//   NAME1 = value
//   NAME2 = {...}
//   ...
// Each top-level Assignment (single-target) becomes a key in the root table.
// Everything else at top level (function defs, statements, expressions) is
// silently skipped — this layer is a codec, not an interpreter.
//
// Ownership: the returned Pico8Value owns its arena-backed strings and tables
// via the DataReader's arena. Copy out what you need before the DataReader
// dies, or keep the DataReader alive.
class DataReader {
    Reader ast_reader_;
    Arena arena_;

    // Parse a NumberNode's raw source text to int or double.
    // PICO-8 number literals can be: decimal (42, 1.5), hex (0x1F),
    // binary (0b1010), with optional fractional (0x1F.8) and negative sign
    // handled at a higher level (UnaryOp wraps Number). We stay simple here.
    Pico8Value parse_number(std::string_view raw) {
        // Probe: is there a '.' or fractional hex component? Treat as float.
        bool looks_float = false;
        for (char c : raw) { if (c == '.' || c == 'e' || c == 'E') { looks_float = true; break; } }
        if (looks_float) {
            // strtod instead of from_chars: libc++'s floating-point from_chars
            // is gated on macOS 26+, which is too new a deployment target.
            // strtod requires a null-terminated string; copy to a small buffer.
            std::string tmp(raw);
            char* end = nullptr;
            double d = std::strtod(tmp.c_str(), &end);
            if (end && end != tmp.c_str()) return Pico8Value(d);
            return Pico8Value(Pico8None{});
        }
        // Integer path — handle hex (0x...) and binary (0b...) prefixes.
        int64_t i = 0;
        int base = 10;
        std::string_view body = raw;
        if (body.size() > 2 && body[0] == '0' && (body[1] == 'x' || body[1] == 'X')) {
            base = 16; body.remove_prefix(2);
        } else if (body.size() > 2 && body[0] == '0' && (body[1] == 'b' || body[1] == 'B')) {
            base = 2; body.remove_prefix(2);
        }
        auto [p, ec] = std::from_chars(body.data(), body.data() + body.size(), i, base);
        (void)p;
        if (ec == std::errc{}) return Pico8Value(i);
        return Pico8Value(Pico8None{});
    }

    // Strip surrounding quote chars from a StringNode's raw value. The reader
    // keeps the quotes in StringNode::value — we want the content only.
    // Takes string_view (AST side), returns ArenaString (data side) copied
    // into our arena. Two different Pico8Str types under two namespaces — be
    // explicit so the compiler doesn't confuse them.
    ArenaString unquote(std::string_view raw) {
        if (raw.size() >= 2) {
            char first = raw.front();
            char last = raw.back();
            if ((first == '"' && last == '"') || (first == '\'' && last == '\'')) {
                raw.remove_prefix(1);
                raw.remove_suffix(1);
            }
        }
        return ArenaString(raw.data(), raw.size(), ArenaAlloc<char>(arena_));
    }

    Pico8Value node_to_value(NodePtr n) {
        if (!n) return Pico8Value(Pico8None{});
        auto kind = n->kind;
        switch (kind) {
            case NodeKind::Nil: return Pico8Value(Pico8None{});
            case NodeKind::Boolean: return Pico8Value(as<BooleanNode>(n)->value);
            case NodeKind::Number:
                return parse_number(std::string_view(as<NumberNode>(n)->raw.data(), as<NumberNode>(n)->raw.size()));
            case NodeKind::String: {
                auto& raw = as<StringNode>(n)->value;
                return Pico8Value(unquote(std::string_view(raw.data(), raw.size())));
            }
            case NodeKind::UnaryOp: {
                // Only `-` on a Number matters for data — negates and returns.
                // Everything else (`not`, `#`, peek prefixes) isn't meaningful
                // in a pure-data context.
                auto* u = as<UnaryOpNode>(n);
                if (u->op.size() == 1 && u->op[0] == '-') {
                    Pico8Value inner = node_to_value(u->operand);
                    if (inner.is_int())   return Pico8Value(-inner.as_int());
                    if (inner.is_float()) return Pico8Value(-inner.as_float());
                }
                return Pico8Value(Pico8None{});
            }
            case NodeKind::TableConstructor: return table_to_value(as<TableConstructorNode>(n));
            default: return Pico8Value(Pico8None{}); // Identifier, Call, FieldAccess, etc. — not data.
        }
    }

    // A TableConstructor is an array if all fields are positional, a table if
    // any field is named. Mixed (named + positional) is legal in Lua but rare
    // in config files — we treat it as a table with integer keys for positions.
    Pico8Value table_to_value(TableConstructorNode* tc) {
        bool any_named = false;
        for (auto* f : tc->fields) {
            auto* tf = as<TableFieldNode>(f);
            if (tf && !tf->key_name.empty()) { any_named = true; break; }
        }

        if (!any_named) {
            p8data::array arr{ArenaAlloc<Pico8Value>(arena_)};
            arr.reserve(tc->fields.size());
            for (auto* f : tc->fields) {
                auto* tf = as<TableFieldNode>(f);
                if (tf) arr.push_back(node_to_value(tf->value));
            }
            return Pico8Value(std::move(arr));
        }

        p8data::table tbl{ArenaAlloc<std::pair<const ArenaString, Pico8Value>>(arena_)};
        size_t positional_idx = 1; // Lua arrays are 1-based
        for (auto* f : tc->fields) {
            auto* tf = as<TableFieldNode>(f);
            if (!tf) continue;
            if (!tf->key_name.empty()) {
                ArenaString key(tf->key_name.data(), tf->key_name.size(), ArenaAlloc<char>(arena_));
                tbl[key] = node_to_value(tf->value);
            } else {
                char buf[24];
                auto [p, ec] = std::to_chars(buf, buf + sizeof(buf), positional_idx);
                if (ec == std::errc{}) {
                    ArenaString key(buf, static_cast<size_t>(p - buf),
                                    ArenaAlloc<char>(arena_));
                    tbl[key] = node_to_value(tf->value);
                }
                ++positional_idx;
            }
        }
        return Pico8Value(std::move(tbl));
    }

public:
    DataReader() : arena_(1 << 14) {}

    Arena& arena() { return arena_; }

    // Parse source text into a root table whose keys are the top-level
    // identifier names being assigned. Returns a Pico8Value holding that
    // table — guaranteed to be either a table or None (on parse failure).
    Pico8Value parse(std::string_view src) {
        arena_.reset();
        // Auto-strip PICO-8 cartridge framing so consumers don't need to
        // pre-process — a .p8 file's __lua__ section parses the same way
        // a plain .lua file does.
        src = strip_cart(src);
        NodePtr root = ast_reader_.parse(src);
        if (!root || root->kind != NodeKind::Program) return Pico8Value(Pico8None{});

        p8data::table root_tbl{ArenaAlloc<std::pair<const ArenaString, Pico8Value>>(arena_)};
        auto* prog = as<ProgramNode>(root);
        for (auto* stmt : prog->statements) {
            if (!stmt || stmt->kind != NodeKind::Assignment) continue;
            auto* a = as<AssignmentNode>(stmt);
            // Single-target, single-value assignments only — the data shape.
            if (a->targets.size() != 1 || a->values.size() != 1) continue;
            if (a->targets[0]->kind != NodeKind::Identifier) continue;
            auto* ident = as<IdentifierNode>(a->targets[0]);
            ArenaString key(ident->name.data(), ident->name.size(), ArenaAlloc<char>(arena_));
            root_tbl[key] = node_to_value(a->values[0]);
        }
        return Pico8Value(std::move(root_tbl));
    }

    Pico8Value parse_file(const std::filesystem::path& path) {
        auto content = Fond::FileIO::read(path);
        return parse(content);
    }
};

// No one-shot parse(src) helper — arena lifetime would outlive any temporary
// DataReader, leaving returned Pico8Value's arena-backed strings dangling.
// Consumers hold a DataReader or copy into their own arena.

// ---------------------------------------------------------------------------
// Ergonomic top-level lookup — takes the ArenaString boilerplate out of the
// common "I have a root table, pull a named global into my struct" pattern.
// Each helper returns true on success, false when the key is missing or the
// value's shape doesn't match what the target expects.
// ---------------------------------------------------------------------------

// Load a nested-table global into a struct that uses PICO8_DEFINE.
// Usage: load_struct(reader, root_tbl, "PLAYER_START", m.player_start);
template <typename T>
inline bool load_struct(DataReader& reader, const p8data::table& tbl,
                        const char* key, T& out) {
    ArenaString k(key, ArenaAlloc<char>(reader.arena()));
    auto it = tbl.find(k);
    if (it == tbl.end() || !it->second.is_table()) return false;
    out = T::pico8_unpack(it->second.as_table());
    return true;
}

// Load an array-of-tables global into a std::vector<T> where T has
// PICO8_DEFINE. Clears `out` first. Silently skips non-table array entries.
// Usage: load_vector(reader, root_tbl, "WALLS", m.walls);
template <typename T>
inline bool load_vector(DataReader& reader, const p8data::table& tbl,
                        const char* key, std::vector<T>& out) {
    ArenaString k(key, ArenaAlloc<char>(reader.arena()));
    auto it = tbl.find(k);
    if (it == tbl.end() || !it->second.is_array()) return false;
    const auto& arr = it->second.as_array();
    out.clear();
    out.reserve(arr.size());
    for (const auto& item : arr) {
        if (item.is_table()) out.push_back(T::pico8_unpack(item.as_table()));
    }
    return true;
}

// Load a scalar-valued global (bool/int/float/string) into a native type.
// Uses Pico8Value::get<T>()'s built-in numeric coercion.
// Usage: load_scalar(reader, root_tbl, "VERSION", m.version);
template <typename T>
inline bool load_scalar(DataReader& reader, const p8data::table& tbl, const char* key, T& out) {
    ArenaString k(key, ArenaAlloc<char>(reader.arena()));
    auto it = tbl.find(k);
    if (it == tbl.end()) return false;
    if constexpr (std::is_same_v<T, std::string>) {
        if (!it->second.is_string()) return false;
        const auto& s = it->second.as_string();
        out.assign(s.data(), s.size());
        return true;
    } else {
        out = it->second.template get<T>(out);
        return true;
    }
}

} // namespace Fond::Pico8::Data
