#pragma once

// Constellation HTTP helpers — distilled from chirp's broker server (per-route
// JSON response patterns) and brack's web server (global request logging +
// exception handling). For JSON-API consumers like plexus and chirp; brack's
// HTML-template routes are a different shape and don't use these.
//
// Usage:
//   httplib::Server srv;
//   SharedHttp::setup_observability(srv);   // once at server-init
//
//   srv.Post("/thing", [](const auto& req, auto& res) {
//       SharedHttp::handle(res, [&] {
//           auto body = json::parse(req.body);
//           // ... do work; throw on error ...
//           SharedHttp::respond(res, SharedHttp::ok_json());
//       });
//   });

#include <fond/logger/log_macros.hpp>
#include <httplib.h>
#include <nlohmann/json.hpp>
#include <string>
#include <string_view>

namespace Fond::Http {

using json = nlohmann::json;

inline constexpr std::string_view CONTENT_TYPE_JSON = "application/json";

// Standard response shapes — every JSON API in the constellation uses these
// {"ok": true, ...} or {"ok": false, "error": "..."} so clients can branch
// on a single field regardless of which service responded.
inline json ok_json() { return {{"ok", true}}; }

inline json error_json(const std::string& msg) { return {{"ok", false}, {"error", msg}}; }

// Set JSON content-type and body in one call.
inline void respond(httplib::Response& res, const json& j) { res.set_content(j.dump(), std::string(CONTENT_TYPE_JSON));}

// Per-route exception wrapper. Wrap your route body in `handle(res, [&]{ ... })`
// — anything thrown becomes a 500 with the standard error_json shape and gets
// logged. Saves the per-route try/catch boilerplate.
template <typename F>
void handle(httplib::Response& res, F&& fn) {
    try {
        fn();
    } catch (const std::exception& e) {
        std::string what = e.what();
        LOG_PLEX_ERR("Request failed: {}", what);
        res.status = 500;
        respond(res, error_json(what));
    } catch (...) {
        std::string msg = "Request failed: (non-std::exception thrown)";
        LOG_PLEX_ERR(msg);
        res.status = 500;
        respond(res, error_json(msg));
    }
}

// Wire up server-wide observability. Call once at server-construction time.
//   - post-routing handler logs every completed request (method path -> status)
//   - exception handler is a final safety net for anything `handle()` missed
//     (e.g. routes that didn't wrap themselves, or framework-internal throws)
inline void setup_observability(httplib::Server& srv) {
    srv.set_post_routing_handler(
        [](const httplib::Request& req, const httplib::Response& res) {
            LOG_PLEX_INFO("{} {} -> {}", req.method, req.path, res.status);
        });

    srv.set_exception_handler(
        [](const httplib::Request& req, httplib::Response& res, std::exception_ptr ep) {
            std::string msg = "(unknown)";
            try {
                if (ep) std::rethrow_exception(ep);
            } catch (const std::exception& e) {
                msg = e.what();
            } catch (...) {
                msg = "(non-std::exception thrown)";
            }
            LOG_PLEX_ERR("{} {} threw: {}", req.method, req.path, msg);
            res.status = 500;
            res.set_content(error_json(msg).dump(), std::string(CONTENT_TYPE_JSON));
        });
}

inline bool post(const std::string_view url, const json& body, json& response) {
    httplib::Client cli(url.data());
    auto res = cli.Post("/", body.dump(), CONTENT_TYPE_JSON.data());
    if (!res) {
        LOG_PLEX_ERR("HTTP request to {} failed: {}", url, httplib::to_string(res.error()));
        return false;
    }
    if (res->status != 200) {
        LOG_PLEX_ERR("HTTP request to {} returned status {}: {}", url, res->status, res->body);
        return false;
    }
    try {
        response = json::parse(res->body);
        return true;
    } catch (const std::exception& e) {
        LOG_PLEX_ERR("Failed to parse JSON response from {}: {}", url, e.what());
        return false;
    }
}

} // namespace Fond::Http
