#pragma once

#include "fwd.hpp"
#ifdef FOND_USE_GLFW
#include "fond/log.hpp"
#include "fond/graphics/window.hpp"    // IWYU pragma: keep
#include "fond/graphics/input.hpp"     // IWYU pragma: keep
#include "fond/graphics/frame_time.hpp" // IWYU pragma: keep
#include "fond/file_io/ops.hpp"         // IWYU pragma: keep
#include "fond/colors/color.hpp"

#ifdef FOND_USE_SHADERS
#include "fond/graphics/primitives.hpp" // IWYU pragma: keep
#include "fond/graphics/text.hpp"       // IWYU pragma: keep
#endif

namespace Fond::Graphics {

using iVec2 = glm::ivec2;

// ── Global state ─────────────────────────────────────────────────
inline GlfwWindow* g_glfw_ctx = nullptr;
inline FrameTime* g_frame_time = nullptr;
inline MousePosition* g_mouse_pos = nullptr;
inline KeyStates g_key_states;
inline MouseStates g_mouse_button_states;

// ── Init / Teardown ──────────────────────────────────────────────

inline bool owns_ctx_ = false;

static inline bool setup_glfw_ctx(GlfwWindow* ctx) {
    if (g_glfw_ctx) { FOND_LOG_WARN("GLFW context already initialized"); return false; }
    g_glfw_ctx = ctx;
    g_frame_time = &g_glfw_ctx->frame_time();
    g_mouse_pos = &g_glfw_ctx->mouse_pos();
    if (!g_glfw_ctx->initialize()) {
        FOND_LOG_ERR("Failed to initialize GLFW context");
        g_glfw_ctx = nullptr;
        return false;
    }
    #ifdef FOND_USE_SHADERS
    g_prim_batch = &g_glfw_ctx->prim_batch();
    #endif
    return true;
}

static inline GlfwWindow* init_glfw_ctx(int width, int height, int fps, const char* title, bool vsync = false, bool headless = false) {
    auto* ctx = new GlfwWindow(width, height, fps, title, vsync, headless);
    if (!setup_glfw_ctx(ctx)) { delete ctx; return nullptr; }
    owns_ctx_ = true;
    FOND_LOG_DEBUG("GLFW context initialized %dx%d @ %d FPS", width, height, fps);
    return g_glfw_ctx;
}

static inline bool init_glfw_ctx(GlfwWindow& ctx) {
    if (!setup_glfw_ctx(&ctx)) return false;
    owns_ctx_ = false;
    FOND_LOG_DEBUG("GLFW context initialized %dx%d @ %d FPS", ctx.width, ctx.height, 0);
    return true;
}

static inline void destroy_glfw_ctx() {
    if (g_glfw_ctx) {
        if (owns_ctx_) delete g_glfw_ctx;
        g_glfw_ctx = nullptr;
        owns_ctx_ = false;
    }
}

// ── Flat API ─────────────────────────────────────────────────────

static inline void SetupFrame(float r = 1.0f, float g = 0.08f, float b = 0.58f, float a = 1.0f) { g_glfw_ctx->setup_frame(r, g, b, a); }
static inline void SetupFrame(const Fond::Color& c) { SetupFrame(c.norm_r(), c.norm_g(), c.norm_b(), c.norm_a()); }
static inline void SetContextCurrent() { glfwMakeContextCurrent(g_glfw_ctx->window); }
static inline bool WindowShouldClose() { return g_glfw_ctx->should_close(); }
static inline void ShouldClose(bool value) { glfwSetWindowShouldClose(g_glfw_ctx->window, value); }
static inline void ProcessEvents() { g_glfw_ctx->process_events(); }
static inline void SwapBuffers() { g_glfw_ctx->swap_buffers(); }

static inline void SetWindowTitle(const char* title) { glfwSetWindowTitle(g_glfw_ctx->window, title); }
static inline void SetWindowPosition(int x, int y) { glfwSetWindowPos(g_glfw_ctx->window, x, y); }
static inline void SetWindowSize(int width, int height) { glfwSetWindowSize(g_glfw_ctx->window, width, height); }
static inline bool IsWindowFullScreen() { return glfwGetWindowMonitor(g_glfw_ctx->window) != nullptr; }
static inline void ToggleFullscreen() {
    GLFWmonitor* monitor = glfwGetPrimaryMonitor();
    const GLFWvidmode* mode = glfwGetVideoMode(monitor);
    if (IsWindowFullScreen()) {
        glfwSetWindowMonitor(g_glfw_ctx->window, nullptr, 100, 100, g_glfw_ctx->width, g_glfw_ctx->height, mode->refreshRate);
    } else {
        glfwSetWindowMonitor(g_glfw_ctx->window, monitor, 0, 0, mode->width, mode->height, mode->refreshRate);
    }
}

static inline iVec2 GetWindowSize() { int w, h; glfwGetWindowSize(g_glfw_ctx->window, &w, &h); return {w, h}; }
static inline iVec2 GetFrameBufferSize() { int w, h; glfwGetFramebufferSize(g_glfw_ctx->window, &w, &h); return {w, h}; }
static inline void ClearBackground(const Fond::Color& c, int) { glClearColor(c.norm_r(), c.norm_g(), c.norm_b(), c.norm_a()); }
static inline void ClearFlags(GLbitfield flags) { glClear(flags); }
static inline float GetFPS() { return g_frame_time->GetFPS(); }
static inline float GetFrameTime() { return g_frame_time->GetFrameTime(); }
static inline void SetTargetFPS(int fps) { g_glfw_ctx->SetTargetFPS(fps); }

// ── Input ────────────────────────────────────────────────────────

static inline bool IsKeyDown(int key) { return glfwGetKey(g_glfw_ctx->window, key) == GLFW_PRESS; }
static inline bool IsKeyUp(int key) { return glfwGetKey(g_glfw_ctx->window, key) == GLFW_RELEASE; }
static inline bool IsKeyPressed(int key) {
    bool currently_down = IsKeyDown(key);
    bool& was_down = g_key_states[key];
    bool pressed = currently_down && !was_down;
    was_down = currently_down;
    return pressed;
}

static inline bool IsMouseButtonDown(int button) { return glfwGetMouseButton(g_glfw_ctx->window, button) == GLFW_PRESS; }
static inline bool IsMouseButtonUp(int button) { return glfwGetMouseButton(g_glfw_ctx->window, button) == GLFW_RELEASE; }
static inline bool IsMouseButtonPressed(int button) {
    bool currently_down = IsMouseButtonDown(button);
    bool& was_down = g_mouse_button_states[button];
    bool pressed = currently_down && !was_down;
    was_down = currently_down;
    return pressed;
}

static inline void DisableCursor() { glfwSetInputMode(g_glfw_ctx->window, GLFW_CURSOR, GLFW_CURSOR_DISABLED); }
static inline void EnableCursor() { glfwSetInputMode(g_glfw_ctx->window, GLFW_CURSOR, GLFW_CURSOR_NORMAL); }
static inline Vec2 GetCursorPos() { return g_mouse_pos->GetMousePos(); }
static inline void SetCursorPos(float x, float y) { glfwSetCursorPos(g_glfw_ctx->window, x, y); }
static inline void SetCursorPos(const Vec2& pos) { SetCursorPos(pos.x, pos.y); }
static inline Vec2 GetCursorDelta() { return g_mouse_pos->GetMouseDelta(); }

// ── Utilities ────────────────────────────────────────────────────

static inline bool FileExists(const std::string& path) { return Fond::FileIO::exists(path); }

#ifdef FOND_USE_SHADERS
static inline void DrawFPS(float x, float y, float size = 3.0f) { DrawFPS(x, y, *g_frame_time, size); }
#else
static inline void DrawFPS(float, float, float = 3.0f) {}
#endif

} // namespace Fond::Graphics

#endif // FOND_USE_GLFW
