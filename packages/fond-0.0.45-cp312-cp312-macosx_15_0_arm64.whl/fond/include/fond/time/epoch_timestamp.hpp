#pragma once

#include <chrono>
#include <cstdint>
#include <format>
#include <string>

#ifdef ENABLE_NLOHMANN
#include <nlohmann/json.hpp>
#endif

namespace Fond::Time {

constexpr const char* DEFAULT_TZ = "UTC";
constexpr int MILLISECONDS_IN_SECOND = 1000;
constexpr int MICROSECONDS_IN_SECOND = 1000000;

namespace SC = std::chrono;

// strftime format — override before including to customize
#ifndef FOND_TS_FMT
#define FOND_TS_FMT "%Y-%m-%d %H:%M:%S"
#endif

static inline struct tm *safe_localtime(const time_t *t, struct tm *out) {
#ifdef _WIN32
  localtime_s(out, t);
  return out;
#else
  return localtime_r(t, out);
#endif
}

static inline const char* get_ord_suffix(uint8_t day) {
    if (day >= 11 && day <= 13) return "th";
    switch (day % 10) {
        case 1: return "st";
        case 2: return "nd";
        case 3: return "rd";
        default: return "th";
    }
}

enum class TimestampPrecision {
    Seconds,
    Milliseconds,
    Microseconds
};

const TimestampPrecision DEFAULT_PRECISION = TimestampPrecision::Milliseconds;

struct EpochTimestamp {

    uint64_t timestamp;

    const char* tz;
    std::string str;

    uint16_t millisecond;
    uint16_t microsecond;
    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
    bool is_pm;

    TimestampPrecision precision;

    const char* ampm() const { return is_pm ? "PM" : "AM"; }

    // TODO(Fondie): SORRY FONDIE BUT CAN YOU PLEASE ADD THE AM PM SPLICING HERE TOO? I LOVE YOU!
    template <TimestampPrecision P>
    static EpochTimestamp now(bool enable_tz = false) {
        EpochTimestamp ts = {};
        auto now = SC::system_clock::now();
        auto time_t_now = SC::system_clock::to_time_t(now);
        struct tm time_info;
        safe_localtime(&time_t_now, &time_info);
        auto epoch = now.time_since_epoch();
        ts.year = time_info.tm_year + 1900;
        ts.month = time_info.tm_mon + 1;
        ts.day = time_info.tm_mday;
        ts.hour = time_info.tm_hour;
        ts.is_pm = ts.hour >= 12;
        ts.minute = time_info.tm_min;
        ts.second = time_info.tm_sec;
        ts.millisecond = SC::duration_cast<SC::milliseconds>(epoch).count() % MILLISECONDS_IN_SECOND;
        ts.microsecond = SC::duration_cast<SC::microseconds>(epoch).count() % MICROSECONDS_IN_SECOND;
        ts.tz = time_info.tm_zone ? time_info.tm_zone : DEFAULT_TZ;
        char buf[32];
        strftime(buf, sizeof(buf), FOND_TS_FMT, &time_info);
        std::string time_str(buf);

        if constexpr (P == TimestampPrecision::Seconds) {
            ts.timestamp = SC::duration_cast<SC::seconds>(epoch).count();
            ts.precision = TimestampPrecision::Seconds;
            if (enable_tz) {
                ts.str = std::format("{} {}", time_str, ts.tz);
            } else {
                ts.str = time_str;
            }
        } else if constexpr (P == TimestampPrecision::Milliseconds) {
            ts.timestamp = SC::duration_cast<SC::milliseconds>(epoch).count();
            ts.precision = TimestampPrecision::Milliseconds;
            if (enable_tz) {
                ts.str = std::format("{}.{:03d} {}", time_str, ts.millisecond, ts.tz);
            } else {
                ts.str = std::format("{}.{:03d}", time_str, ts.millisecond);
            }
        } else if constexpr (P == TimestampPrecision::Microseconds) {
            ts.timestamp = SC::duration_cast<SC::microseconds>(epoch).count();
            ts.precision = TimestampPrecision::Microseconds;
            if (enable_tz) {
                ts.str = std::format("{}.{:06d} {}", time_str, ts.microsecond, ts.tz);
            } else {
                ts.str = std::format("{}.{:06d}", time_str, ts.microsecond);
            }
        }
        return ts;
    }

    std::string to_string() const { return str; }
    uint64_t to_int() const { return static_cast<uint64_t>(timestamp); }
    bool same_precision(const EpochTimestamp &other) const { return precision == other.precision; }

    operator uint64_t() const { return static_cast<uint64_t>(timestamp); }

    auto operator<=>(const EpochTimestamp& other) const {
        if (!same_precision(other)) throw std::invalid_argument("Cannot compare timestamps with different precision");
        return timestamp <=> other.timestamp;
    }

    auto operator==(const EpochTimestamp& other) const {
        if (!same_precision(other)) throw std::invalid_argument("Cannot compare timestamps with different precision");
        return timestamp == other.timestamp;
    }

    uint64_t since(const EpochTimestamp& other) const {
        if (!same_precision(other)) { throw std::invalid_argument("Cannot compare timestamps with different precision"); }
        return timestamp - other.timestamp;
    }
};

// Fast path — just a formatted string, no struct overhead
static inline std::string fast_now(bool enable_tz = false, bool am_pm = true) {
    auto now = SC::system_clock::now();
    auto time_t_now = SC::system_clock::to_time_t(now);
    auto ms = SC::duration_cast<SC::milliseconds>(now.time_since_epoch()).count() % MILLISECONDS_IN_SECOND;
    struct tm ti;
    safe_localtime(&time_t_now, &ti);
    char buf[32];
    strftime(buf, sizeof(buf), FOND_TS_FMT, &ti);

    // Pick the AM/PM suffix once. strftime("%p") is locale-aware and already
    // returns "AM"/"PM" — no need to overwrite it manually.
    char am_pm_buf[4] = {};
    if (am_pm) strftime(am_pm_buf, sizeof(am_pm_buf), "%p", &ti);

    const char* tz = enable_tz ? (ti.tm_zone ? ti.tm_zone : DEFAULT_TZ) : "";

    // Four shapes — pick the format string up front so we never interpolate
    // empty values that would leave dangling spaces.
    if (am_pm && enable_tz) {
        return std::format("{}.{:03d} {} {}", std::string(buf), ms, am_pm_buf, tz);
    } else if (am_pm) {
        return std::format("{}.{:03d} {}", std::string(buf), ms, am_pm_buf);
    } else if (enable_tz) {
        return std::format("{}.{:03d} {}", std::string(buf), ms, tz);
    } else {
        return std::format("{}.{:03d}", std::string(buf), ms);
    }
}

static inline EpochTimestamp now(TimestampPrecision default_precision = DEFAULT_PRECISION) { return EpochTimestamp::now<DEFAULT_PRECISION>(); }
static inline uint64_t time_since(const EpochTimestamp& start, const EpochTimestamp& end) { return end.since(start); }


// Divisors for converting precision-native units into seconds.
inline uint64_t seconds_per_unit(TimestampPrecision p) {
    switch (p) {
        case TimestampPrecision::Seconds:      return 1;
        case TimestampPrecision::Milliseconds: return MILLISECONDS_IN_SECOND;
        case TimestampPrecision::Microseconds: return MICROSECONDS_IN_SECOND;
    }
    return 1;
}

static inline const char* month_short(uint8_t month) {
    static constexpr const char *NAMES[] = {
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec"
    };
    return (month >= 1 && month <= 12) ? NAMES[month - 1] : "???";
}

// Relative-time string, with an absolute fallback once the delta exceeds the
// configured threshold.
//
//   < 1 min     →  "just now"
//   < 60 min    →  "N min ago"
//   < 24 h      →  "N hours ago"
//   < 48 h      →  "yesterday"
//   < 7 days    →  "N days ago"
//   otherwise   →  "Apr 21 at 10:58 PM"  (uses ts's own components)
//
// `now` lets callers inject a fixed reference for testing; defaults to wall
// clock with matching precision.
inline std::string format_relative(const EpochTimestamp& ts,std::optional<EpochTimestamp> now_opt = std::nullopt) {
    EpochTimestamp now_ts = now_opt.value_or(now(ts.precision));
    // Caller's problem if they mixed precisions — fall back to absolute.
    if (!ts.same_precision(now_ts)) { return ts.to_string(); }

    // Signed delta in the native unit (negative = future, we clamp to 0).
    int64_t delta_native = int64_t(now_ts.timestamp) - int64_t(ts.timestamp);
    if (delta_native < 0) delta_native = 0;

    uint64_t spu = seconds_per_unit(ts.precision);
    uint64_t delta_sec = uint64_t(delta_native) / spu;

    if (delta_sec < 60)          return "just now";
    if (delta_sec < 3600) {
        uint64_t m = delta_sec / 60;
        return std::format("{} min ago", m);
    }
    if (delta_sec < 86400) {
        uint64_t h = delta_sec / 3600;
        return std::format("{} hour{} ago", h, h == 1 ? "" : "s");
    }
    if (delta_sec < 172800)      return "yesterday";
    if (delta_sec < 604800) {
        uint64_t d = delta_sec / 86400;
        return std::format("{} days ago", d);
    }

    // Absolute fallback — human shape, pulls from ts's own components so we
    // don't need another strftime call.
    uint8_t h12 = ts.hour % 12;
    if (h12 == 0) h12 = 12;
    return std::format("{} {} at {}:{:02d} {}", month_short(ts.month), ts.day, h12, ts.minute, ts.ampm());
}
  
inline EpochTimestamp from_ms(uint64_t ms) {
    EpochTimestamp ts = {};
    ts.timestamp = ms;
    ts.precision = TimestampPrecision::Milliseconds;
    time_t secs = time_t(ms / MILLISECONDS_IN_SECOND);
    struct tm ti;
    safe_localtime(&secs, &ti);
    ts.year  = ti.tm_year + 1900;
    ts.month = ti.tm_mon + 1;
    ts.day   = ti.tm_mday;
    ts.hour  = ti.tm_hour;
    ts.is_pm = ts.hour >= 12;
    ts.minute = ti.tm_min;
    ts.second = ti.tm_sec;
    ts.millisecond = uint16_t(ms % MILLISECONDS_IN_SECOND);
    ts.microsecond = ts.millisecond * 1000;
    ts.tz = ti.tm_zone ? ti.tm_zone : DEFAULT_TZ;
    char buf[32];
    strftime(buf, sizeof(buf), FOND_TS_FMT, &ti);
    ts.str = std::format("{}.{:03d} {}", std::string(buf), ts.millisecond, ts.tz);
    return ts;
}

#ifdef ENABLE_NLOHMANN
inline void to_json(nlohmann::json& j, const EpochTimestamp& ts) {
    j = ts.timestamp;
}
inline void from_json(const nlohmann::json& j, EpochTimestamp& ts) {
    ts = from_ms(j.get<uint64_t>());
}
#endif

} // namespace Fond::Time
