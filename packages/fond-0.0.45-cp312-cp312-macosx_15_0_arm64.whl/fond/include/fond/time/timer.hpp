#pragma once

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <format>
#include <functional>
#include <string>
#include <vector>

static inline std::string format_duration(double ns) {
    if (ns < 1'000.0) return std::format("{:.2f} ns", ns);
    if (ns < 1'000'000.0) return std::format("{:.2f} µs", ns / 1'000.0);
    if (ns < 1'000'000'000.0) return std::format("{:.2f} ms", ns / 1'000'000.0);
    return std::format("{:.2f} s", ns / 1'000'000'000.0);
}

#ifdef LOGGER_ENABLED
#include "fond/logger/logger.hpp"
inline void default_report(const char* name, double ns) {
    Fond::Logging::g_logger.Info("[{}] took {}", name, format_duration(ns));
#else
inline void default_report(const char* name, double ns) {
    printf("[%s] took %s\n", name, format_duration(ns).c_str());
#endif
}

#ifdef BENCHMARK_COLOR
#include "fond/colors/style.hpp"
#include "fond/colors/gradient.hpp"
#endif

namespace Fond::Timer {

using Clock = std::chrono::high_resolution_clock;
using TimePoint = Clock::time_point;

using ReportFn = std::function<void(const char*, double)>;

struct ScopedTimer {
    const char* name;
    TimePoint start;
    ReportFn report;

    ScopedTimer(const char* n, ReportFn fn = default_report) : name(n), start(Clock::now()), report(std::move(fn)) {}

    ~ScopedTimer() {
        double ns = static_cast<double>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count());
        report(name, ns);
    }

    // Lap: report elapsed so far without stopping
    void lap(const char* label = nullptr) const {
        double ns = static_cast<double>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count());
        report(label ? label : name, ns);
    }

    double elapsed_ns() const {
        return static_cast<double>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count());
    }

    double elapsed_ms() const { return elapsed_ns() / 1'000'000.0; }
};

// Simple one-shot: returns elapsed nanoseconds
inline double time_it(std::invocable<> auto&& fn) {
    auto start = Clock::now();
    fn();
    return static_cast<double>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count());
}

// --- Benchmark report ---
// Caller owns the report. bench() times the lambda and writes into it.
// report.print() emits a sorted comparison table.

struct BenchResult {
    std::string name;
    double ns = 0.0;
    size_t ops = 0;
    double ns_per_op() const { return ops ? ns / static_cast<double>(ops) : 0.0; }
};

struct BenchReport {
    std::string title;
    size_t ops_per_run;
    std::vector<BenchResult> results;

    BenchReport(std::string t, size_t ops) : title(std::move(t)), ops_per_run(ops) {}

    void add(const std::string& name, double ns) { results.push_back({name, ns, ops_per_run}); }

#ifdef BENCHMARK_COLOR
    void print(ColorGradient& grad) const {
#else
    void print() const {
#endif
        if (results.empty()) { printf("%s — no results\n", title.c_str()); return; }
        auto sorted = results;
        std::sort(sorted.begin(), sorted.end(), [](const auto& a, const auto& b) { return a.ns < b.ns; });
        double baseline = sorted.front().ns;

        size_t name_w = 0, dur_w = 0, op_w = 0;
        std::vector<std::string> dur_strs, op_strs;
        dur_strs.reserve(sorted.size());
        op_strs.reserve(sorted.size());
        for (const auto& r : sorted) {
            name_w = std::max(name_w, r.name.size());
            dur_strs.push_back(format_duration(r.ns));
            op_strs.push_back(format_duration(r.ns_per_op()) + "/op");
            dur_w = std::max(dur_w, dur_strs.back().size());
            op_w = std::max(op_w, op_strs.back().size());
        }

#ifdef BENCHMARK_COLOR
        printf("\n%s%s — %s ops%s\n",
            Style().bold().cyan().str().c_str(),
            title.c_str(), format_ops(ops_per_run).c_str(),
            Style::RESET);


        double slowest = sorted.back().ns;
#else
        printf("\n%s — %s ops\n", title.c_str(), format_ops(ops_per_run).c_str());
#endif
        for (size_t i = 0; i < sorted.size(); ++i) {
            const auto& r = sorted[i];
            double ratio = r.ns / baseline;
#ifdef BENCHMARK_COLOR
            Color c = grad.map(baseline, slowest, r.ns);
            std::string color = Style().fg(c).str();
            if (i == 0) color = Style().fg(c).bold().str();
            printf("%s %-*s %*s | %*s | %.2fx%s%s\n",
                color.c_str(),
                static_cast<int>(name_w), r.name.c_str(),
                static_cast<int>(dur_w), dur_strs[i].c_str(),
                static_cast<int>(op_w), op_strs[i].c_str(),
                ratio, i == 0 ? " ** " : "",
                Style::RESET);
#else
            printf(" %-*s %*s | %*s | %.2fx%s\n",
                static_cast<int>(name_w), r.name.c_str(),
                static_cast<int>(dur_w), dur_strs[i].c_str(),
                static_cast<int>(op_w), op_strs[i].c_str(),
                ratio, i == 0 ? " ** " : "");
#endif
        }
    }

private:
    static std::string format_ops(size_t n) {
        auto s = std::to_string(n);
        for (int i = static_cast<int>(s.size()) - 3; i > 0; i -= 3) s.insert(static_cast<size_t>(i), ",");
        return s;
    }
};

template <typename Fn>
inline void bench(BenchReport& report, const std::string& name, Fn&& fn) {
    auto start = Clock::now();
    fn();
    double ns = static_cast<double>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count());
    report.add(name, ns);
}

} // namespace Fond::Timer

// Macro needs two levels of indirection to expand __LINE__ properly
#define FOND_TIMER_CONCAT_(a, b) a##b
#define FOND_TIMER_CONCAT(a, b) FOND_TIMER_CONCAT_(a, b)
#define PROFILE_SCOPE(name) Fond::Timer::ScopedTimer FOND_TIMER_CONCAT(timer_, __LINE__)(name)
