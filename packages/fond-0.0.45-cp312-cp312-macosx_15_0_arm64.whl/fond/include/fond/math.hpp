#pragma once

#include <algorithm>

namespace Fond::Math {

static inline double lerp(double a, double b, double t) { return a + (b - a) * t; }

static inline double clamp(double v, double min_v, double max_v) {
    return std::max(min_v, std::min(max_v, v));
}

static inline double inv_lerp(double a, double b, double v) {
    if (a == b) return 0.0;
    return clamp((v - a) / (b - a), 0.0, 1.0);
}

static inline  uint8_t lerp_channel(uint8_t a, uint8_t b, double t) {
    double v = lerp(static_cast<double>(a), static_cast<double>(b), t);
    return static_cast<uint8_t>(std::clamp(v, 0.0, 255.0));
}

static inline  double norm_position(double min_v, double max_v, double v, bool reverse) {
    double n = inv_lerp(min_v, max_v, v);
    return reverse ? 1.0 - n : n;
}

}