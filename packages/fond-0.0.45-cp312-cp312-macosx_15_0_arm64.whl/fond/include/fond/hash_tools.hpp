#pragma once

#include "fond/file_io/ops.hpp"
#include <openssl/evp.h>
#include <string>
#include <filesystem>

namespace Fond::HashTools {

static inline std::string hex_string(const unsigned char* data, size_t len) {
    std::string result;
    result.reserve(len * 2);
    for (size_t i = 0; i < len; ++i) {
        char buf[3];
        snprintf(buf, sizeof(buf), "%02x", data[i]);
        result += buf;
    }
    return result;
}

static inline std::string get_sha256_string(const std::string& input, size_t digest_size = -1) {
    unsigned char hash[EVP_MAX_MD_SIZE];
    unsigned int hash_len = 0;
    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    EVP_DigestInit_ex(ctx, EVP_sha256(), nullptr);
    EVP_DigestUpdate(ctx, input.data(), input.size());
    EVP_DigestFinal_ex(ctx, hash, &hash_len);
    EVP_MD_CTX_free(ctx);
    auto out = hex_string(hash, hash_len);
    if (digest_size != static_cast<size_t>(-1) && digest_size < out.size()) out.resize(digest_size); 
    return out;
}

static inline std::string get_file_sha256(const std::filesystem::path& path) {
    if (!std::filesystem::exists(path)) return "";
    FileIO::FileHandle fh(path);
    if (!fh) return "";

    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    EVP_DigestInit_ex(ctx, EVP_sha256(), nullptr);

    unsigned char read_buf[8192];
    size_t bytes_read;
    while ((bytes_read = fread(read_buf, 1, sizeof(read_buf), fh)) > 0) {
        EVP_DigestUpdate(ctx, read_buf, bytes_read);
    }

    unsigned char hash[EVP_MAX_MD_SIZE];
    unsigned int hash_len = 0;
    EVP_DigestFinal_ex(ctx, hash, &hash_len);
    EVP_MD_CTX_free(ctx);
    return hex_string(hash, hash_len);
}

} // namespace Fond::HashTools
