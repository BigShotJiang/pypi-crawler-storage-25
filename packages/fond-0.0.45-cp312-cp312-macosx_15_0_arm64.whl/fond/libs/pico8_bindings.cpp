/*
 * pybind11 bindings for Fond's PICO-8 reader/writer.
 *
 * NOTE: this shit is rough — it's a skeleton, not a finished binding. The goal
 * is to get py2p8 (and eventually a picotool replacement) off the ground with
 * something that parses, emits, and exposes enough of the AST to walk. Filling
 * out every kind-specific accessor is a separate afternoon's work.
 *
 * Shape differs intentionally from toml/nix bindings:
 *   * TOML/Nix are DATA codecs — they use py_convert to round-trip dicts/lists.
 *   * PICO-8 is CODE — there's no dict representation of "function statement
 *     with compound-assign body." So this exposes the AST directly as a Python
 *     object model: Reader owns the arena, Node is the walking handle, and
 *     lifetime is managed via pybind11's keep_alive so Python can't outlive
 *     the arena that backs the nodes it's holding.
 */

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <stdexcept>
#include <string>

#include "fond/pico8/reader.hpp"
#include "fond/pico8/value.hpp"
#include "fond/pico8/writer.hpp"

namespace py = pybind11;
using namespace Fond::Pico8;

// Helper: throw a Python AttributeError when a kind-specific accessor is
// called on the wrong node kind. Keeps the Python-side error shape familiar —
// `node.name` on a Number raises AttributeError, not some C++ bad_cast.
[[noreturn]] static void attr_mismatch(NodeKind actual, const char* expected, const char* field) {
    std::string msg = "Node(kind=";
    msg += kind_name(actual);
    msg += ") has no attribute '";
    msg += field;
    msg += "' (only valid on ";
    msg += expected;
    msg += ")";
    throw py::attribute_error(msg);
}

// Small convenience: require a specific kind, else raise AttributeError.
// Used by every kind-specific property below.
template <typename T>
static T* require(NodePtr n, NodeKind want, const char* expected, const char* field) {
    if (!n || n->kind != want) attr_mismatch(n ? n->kind : NodeKind::Unknown, expected, field);
    return as<T>(n);
}

PYBIND11_MODULE(pico8_bindings, m) {
    m.doc() = "PICO-8 AST reader/writer (Fond + Tree-sitter). Rough skeleton — "
              "expect gaps in kind-specific accessors.";

    // -----------------------------------------------------------------------
    // NodeKind enum — driven off the X-macro so adding a kind in value.hpp
    // auto-surfaces in Python. Consumers get `pico8.NodeKind.Identifier` etc.
    // -----------------------------------------------------------------------
    py::enum_<NodeKind> kind_enum(m, "NodeKind");
#define FOND_PICO8_X(Name) kind_enum.value(#Name, NodeKind::Name);
    FOND_PICO8_NODE_KINDS(FOND_PICO8_X)
#undef FOND_PICO8_X
    kind_enum.export_values();

    // -----------------------------------------------------------------------
    // Node — the walking handle. One Python class covers all 35+ kinds via
    // kind-dispatched properties. Alternative would be 35 py::class_ with
    // inheritance — gives better isinstance() but explodes binding code.
    // Going single-class + property-dispatch until the transpiler proves it
    // wants real subclasses.
    // -----------------------------------------------------------------------
    py::class_<Node, NodePtr>(m, "Node")
        .def_readonly("kind", &Node::kind)
        .def_readonly("source_start", &Node::source_start)
        .def_readonly("source_end", &Node::source_end)

        // --- literal-ish accessors ---------------------------------------
        // Surface the "interesting field" of each leaf kind under the name
        // the kind most naturally uses. Mismatches raise AttributeError.
        .def_property_readonly("name", [](NodePtr n) {
            return std::string(require<IdentifierNode>(n, NodeKind::Identifier, "Identifier", "name")->name);
        })
        .def_property_readonly("raw", [](NodePtr n) {
            return std::string(require<NumberNode>(n, NodeKind::Number, "Number", "raw")->raw);
        })
        .def_property_readonly("value", [](NodePtr n) -> py::object {
            // Shared name across String/Boolean — dispatch on kind.
            if (!n) attr_mismatch(NodeKind::Unknown, "String/Boolean", "value");
            if (n->kind == NodeKind::String)  return py::cast(std::string(as<StringNode>(n)->value));
            if (n->kind == NodeKind::Boolean) return py::cast(as<BooleanNode>(n)->value);
            attr_mismatch(n->kind, "String/Boolean", "value");
        })
        .def_property_readonly("op", [](NodePtr n) -> std::string {
            // Shared across BinaryOp / UnaryOp / CompoundAssign.
            if (!n) attr_mismatch(NodeKind::Unknown, "BinaryOp/UnaryOp/CompoundAssign", "op");
            if (n->kind == NodeKind::BinaryOp)       return std::string(as<BinaryOpNode>(n)->op);
            if (n->kind == NodeKind::UnaryOp)        return std::string(as<UnaryOpNode>(n)->op);
            if (n->kind == NodeKind::CompoundAssign) return std::string(as<CompoundAssignNode>(n)->op);
            attr_mismatch(n->kind, "BinaryOp/UnaryOp/CompoundAssign", "op");
        })

        // --- child accessors ---------------------------------------------
        // TODO(fondie): fill out the rest of these — lhs/rhs, operand,
        // callee/args, statements, targets/values, branches, body, cond,
        // etc. Pattern is the same: require<T>() + return the pointer with
        // reference_internal so the arena (via Reader) keeps it alive.
        .def_property_readonly("lhs", [](NodePtr n) -> NodePtr {
            return require<BinaryOpNode>(n, NodeKind::BinaryOp, "BinaryOp", "lhs")->lhs;
        }, py::return_value_policy::reference)
        .def_property_readonly("rhs", [](NodePtr n) -> NodePtr {
            return require<BinaryOpNode>(n, NodeKind::BinaryOp, "BinaryOp", "rhs")->rhs;
        }, py::return_value_policy::reference)
        .def_property_readonly("statements", [](NodePtr n) -> std::vector<NodePtr> {
            // Program and Block both have `statements` — treat uniformly.
            if (!n) attr_mismatch(NodeKind::Unknown, "Program/Block", "statements");
            if (n->kind == NodeKind::Program) {
                auto& s = as<ProgramNode>(n)->statements;
                return {s.begin(), s.end()};
            }
            if (n->kind == NodeKind::Block) {
                auto& s = as<BlockNode>(n)->statements;
                return {s.begin(), s.end()};
            }
            attr_mismatch(n->kind, "Program/Block", "statements");
        })

        .def("__repr__", [](const Node& n) {
            std::string r = "<Node kind=";
            r += kind_name(n.kind);
            r += ">";
            return r;
        });

    // -----------------------------------------------------------------------
    // Reader — owns the arena + the parsed tree. Nodes handed out via
    // parse/parse_file are only valid for the lifetime of this Reader.
    // pybind11's reference_internal policy ties each returned Node back to
    // the Reader that produced it — dropping the Reader with live Nodes
    // around is a use-after-free, so we lean on Python refcounting to
    // prevent it.
    // -----------------------------------------------------------------------
    py::class_<Reader>(m, "Reader")
        .def(py::init<>())
        .def("parse", [](Reader& r, const std::string& src) -> NodePtr {
            return r.parse(src);
        }, py::arg("source"), py::return_value_policy::reference_internal)
        .def("parse_file", [](Reader& r, const std::string& path) -> NodePtr {
            // TODO(fondie): Reader::parse_file doesn't exist yet — either add
            // it to reader.hpp (mirrors toml/nix pattern) or drop this method.
            // Leaving the binding here as a placeholder so the API shape is
            // visible.
            (void)r; (void)path;
            throw std::runtime_error("Reader.parse_file: not implemented yet");
        }, py::arg("path"));

    // -----------------------------------------------------------------------
    // Free functions — quality-of-life wrappers that mirror the loads/dumps
    // cadence of toml/nix bindings in spirit. These return a (Reader, Node)
    // pair via a tiny wrapper so callers don't have to juggle Reader lifetime
    // manually. Pick whichever feels better in py2p8 and deprecate the other.
    // -----------------------------------------------------------------------

    // `to_source(node) -> str` — AST → PICO-8 source text. Lossless for
    // structure, NOT for whitespace/comments (writer is a canonical emitter,
    // not a source-preserving formatter).
    m.def("to_source", [](NodePtr n) {
        return to_source(n);
    }, py::arg("node"), "Emit PICO-8 source text from an AST node.");

    // `parse(src) -> (Reader, Node)` — the simple path. Caller keeps the
    // Reader alive as long as they hold the Node. Ugly but explicit.
    // TODO(fondie): replace with a ParseResult wrapper that owns the Reader
    // and acts like the root Node (forwards attribute access). Nicer UX.
    m.def("parse", [](const std::string& src) {
        auto reader = std::make_unique<Reader>();
        NodePtr root = reader->parse(src);
        // Return the pair; Python tuple keeps both alive until the tuple drops.
        return py::make_tuple(py::cast(std::move(reader)), py::cast(root, py::return_value_policy::reference));
    }, py::arg("source"), "Parse PICO-8 source and return (reader, root_node).");
}
