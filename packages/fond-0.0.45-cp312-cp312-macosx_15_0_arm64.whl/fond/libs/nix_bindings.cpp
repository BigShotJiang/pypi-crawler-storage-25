/*
 * pybind11 bindings for Fond's Nix reader/writer.
 * Uses Fond's generic py_convert for Python ↔ C++ value conversion.
 */

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "fond/nix/reader.hpp"
#include "fond/nix/writer.hpp"
#include "fond/nix/py_traits.hpp" // IWYU pragma: keep

namespace py = pybind11;

inline Fond::Nix::Reader g_reader;

using namespace Fond::Nix;
using Fond::PyTools::to_py;
using Fond::PyTools::from_py;

static py::object loads(const std::string& source) {
    return to_py<NixValue>(g_reader.parse(source));
}

static py::object load(const std::string& filepath) {
    return to_py<NixValue>(g_reader.parse_file(filepath));
}

static std::string dumps(const py::object& obj, size_t indent, bool sort_keys, bool inline_lists, bool inline_arrays, size_t max_inline) {
    CollectionsCub::Arena arena;
    auto val = from_py<NixValue>(obj, arena);
    Writer writer(WriterConfig{indent, sort_keys, inline_lists, inline_arrays, max_inline});
    return writer.write(val);
}

static void dump(const py::object& obj, const std::string& filepath, size_t indent, bool sort_keys, bool inline_lists, bool inline_arrays, size_t max_inline) {
    auto content = dumps(obj, indent, sort_keys, inline_lists, inline_arrays, max_inline);
    std::ofstream file(filepath);
    if (!file) throw py::value_error("Cannot open file for writing: " + filepath);
    file << content;
}

PYBIND11_MODULE(nix_bindings, m) {
    m.doc() = "Fast Nix data reader and writer implemented in C++";
    m.def("loads", &loads, "Parse a Nix string and return a Python dict.", py::arg("source"));
    m.def("load", &load, "Parse a Nix file and return a Python dict.", py::arg("filepath"));
    m.def("dumps", &dumps, "Serialize a Python dict to a Nix string.",
          py::arg("obj"), py::arg("indent") = 2, py::arg("sort_keys") = false,
          py::arg("inline_lists") = true, py::arg("inline_arrays") = true,
          py::arg("max_inline") = 8);
    m.def("dump", &dump, "Serialize a Python dict and write to a Nix file.",
          py::arg("obj"), py::arg("filepath"), py::arg("indent") = 2,
          py::arg("sort_keys") = false, py::arg("inline_lists") = true,
          py::arg("inline_arrays") = true, py::arg("max_inline") = 8);
}
