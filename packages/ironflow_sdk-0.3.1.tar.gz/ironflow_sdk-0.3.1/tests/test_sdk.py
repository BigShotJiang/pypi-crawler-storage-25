# Unit tests for the Ironflow Python SDK.

import json
import pytest
import httpx
import respx

from ironflow_sdk import Ironflow
from ironflow_sdk.errors import AuthError, TierError, RateLimitError, IronflowError, QueryWindowError, QueryTimeoutError, QueryTooExpensiveError
from ironflow_sdk.client import Page


BASE = "https://api.ironflow.sh"


def list_of(data):
    return {"data": data, "pagination": {"next_cursor": None, "has_more": False}}


def list_with_more(data, cursor):
    return {"data": data, "pagination": {"next_cursor": cursor, "has_more": True}}


FAKE_TRADE = {
    "source": "hyperliquid",
    "market": "BTC-PERP",
    "market_type": "perp",
    "timestamp": 1700000000000,
    "block_number": 1234,
    "sequence": 1,
    "price": "50000.00",
    "size": "0.1",
    "side": "buy",
    "address": "0xabc",
    "fee": "0.5",
    "realized_pnl": "0",
    "hash": "0xhash",
}


# ─── Constructor ─────────────────────────────────────────────────────────────

def test_constructor_creates_client():
    client = Ironflow("if_test_key")
    assert client is not None
    assert client.stream is not None


# ─── trades() ────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_trades_returns_page():
    respx.get(f"{BASE}/v1/trades").mock(return_value=httpx.Response(200, json=list_of([FAKE_TRADE])))

    async with Ironflow("if_test") as client:
        page = await client.trades("BTC-PERP")

    assert isinstance(page, Page)
    assert len(page.data) == 1
    assert page.data[0].price == "50000.00"
    assert page.has_more is False


@pytest.mark.asyncio
@respx.mock
async def test_trades_passes_query_params():
    route = respx.get(f"{BASE}/v1/trades").mock(return_value=httpx.Response(200, json=list_of([])))

    async with Ironflow("if_test") as client:
        await client.trades("ETH-PERP", limit=50)

    assert route.called
    req = route.calls.last.request
    assert "market=ETH-PERP" in str(req.url)
    assert "limit=50" in str(req.url)


@pytest.mark.asyncio
@respx.mock
async def test_trades_paginates():
    trade1 = {**FAKE_TRADE, "sequence": 1}
    trade2 = {**FAKE_TRADE, "sequence": 2}

    respx.get(f"{BASE}/v1/trades").mock(
        side_effect=[
            httpx.Response(200, json=list_with_more([trade1], "cursor_abc")),
            httpx.Response(200, json=list_of([trade2])),
        ]
    )

    async with Ironflow("if_test") as client:
        page1 = await client.trades("BTC-PERP")
        assert page1.has_more is True
        assert page1.data[0].sequence == 1

        page2 = await page1.next()
        assert page2.has_more is False
        assert page2.data[0].sequence == 2


@pytest.mark.asyncio
@respx.mock
async def test_trades_raises_on_no_more_pages():
    respx.get(f"{BASE}/v1/trades").mock(return_value=httpx.Response(200, json=list_of([])))

    async with Ironflow("if_test") as client:
        page = await client.trades("BTC-PERP")
        with pytest.raises(StopAsyncIteration):
            await page.next()


# ─── book() ──────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_book_returns_page():
    snapshot = {
        "source": "hyperliquid",
        "market": "BTC-PERP",
        "timestamp": 1700000000000,
        "bids": [{"price": "49999", "size": "1.0"}],
        "asks": [{"price": "50001", "size": "0.5"}],
    }
    respx.get(f"{BASE}/v1/book").mock(return_value=httpx.Response(200, json=list_of([snapshot])))

    async with Ironflow("if_test") as client:
        page = await client.book("BTC-PERP")

    assert len(page.data) == 1
    assert len(page.data[0].bids) == 1
    assert page.data[0].bids[0].price == "49999"
    assert len(page.data[0].asks) == 1


# ─── candles() ───────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_candles_passes_interval():
    route = respx.get(f"{BASE}/v1/candles").mock(return_value=httpx.Response(200, json=list_of([])))

    async with Ironflow("if_test") as client:
        await client.candles("BTC-PERP", "1h", limit=24)

    req = route.calls.last.request
    assert "interval=1h" in str(req.url)
    assert "limit=24" in str(req.url)


# ─── fills() ─────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_fills_passes_address():
    route = respx.get(f"{BASE}/v1/fills").mock(return_value=httpx.Response(200, json=list_of([])))

    async with Ironflow("if_test") as client:
        await client.fills("0xdeadbeef")

    req = route.calls.last.request
    assert "address=0xdeadbeef" in str(req.url)


# ─── info() ──────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_info_posts_body():
    route = respx.post(f"{BASE}/v1/info").mock(return_value=httpx.Response(200, json={"result": "ok"}))

    async with Ironflow("if_test") as client:
        result = await client.info({"type": "allMids"})

    assert result == {"result": "ok"}
    req = route.calls.last.request
    assert json.loads(req.content) == {"type": "allMids"}


# ─── Authorization header ─────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_auth_header_sent():
    route = respx.get(f"{BASE}/v1/trades").mock(return_value=httpx.Response(200, json=list_of([])))

    async with Ironflow("if_mykey") as client:
        await client.trades("BTC-PERP")

    req = route.calls.last.request
    assert req.headers["Authorization"] == "Bearer if_mykey"


# ─── Error handling ──────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_raises_auth_error_on_401():
    respx.get(f"{BASE}/v1/trades").mock(
        return_value=httpx.Response(401, json={"error": {"code": "UNAUTHORIZED", "message": "Bad key"}})
    )
    async with Ironflow("if_bad") as client:
        with pytest.raises(AuthError):
            await client.trades("BTC-PERP")


@pytest.mark.asyncio
@respx.mock
async def test_raises_tier_error_on_403():
    respx.get(f"{BASE}/v1/trades").mock(
        return_value=httpx.Response(403, json={"error": {"code": "TIER_INSUFFICIENT", "message": "Upgrade"}})
    )
    async with Ironflow("if_free") as client:
        with pytest.raises(TierError):
            await client.trades("BTC-PERP")


@pytest.mark.asyncio
@respx.mock
async def test_raises_rate_limit_error_on_429():
    respx.get(f"{BASE}/v1/trades").mock(
        return_value=httpx.Response(
            429,
            json={"error": {"code": "RATE_LIMIT_EXCEEDED", "message": "Slow down"}},
            headers={"Retry-After": "30"},
        )
    )
    async with Ironflow("if_test") as client:
        with pytest.raises(RateLimitError) as exc_info:
            await client.trades("BTC-PERP")

    assert exc_info.value.retry_after_ms == 30_000


@pytest.mark.asyncio
@respx.mock
async def test_raises_ironflow_error_on_500():
    respx.get(f"{BASE}/v1/trades").mock(
        return_value=httpx.Response(500, json={"error": {"code": "INTERNAL", "message": "boom"}})
    )
    async with Ironflow("if_test") as client:
        with pytest.raises(IronflowError) as exc_info:
            await client.trades("BTC-PERP")

    assert exc_info.value.status == 500


# ─── Custom base_url ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_custom_base_url():
    route = respx.get("https://staging.ironflow.sh/v1/trades").mock(
        return_value=httpx.Response(200, json=list_of([]))
    )

    async with Ironflow("if_test", base_url="https://staging.ironflow.sh") as client:
        await client.trades("BTC-PERP")

    assert route.called


# ─── Context manager ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_async_context_manager():
    respx.get(f"{BASE}/v1/trades").mock(return_value=httpx.Response(200, json=list_of([])))

    async with Ironflow("if_test") as client:
        page = await client.trades("BTC-PERP")
    assert isinstance(page, Page)


# ─── export_data() ───────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_export_data_returns_bytes():
    respx.get(f"{BASE}/v1/export").mock(return_value=httpx.Response(200, content=b"col1,col2\n1,2\n"))

    async with Ironflow("if_test") as client:
        result = await client.export_data("fills", format="csv")

    assert isinstance(result, bytes)
    assert b"col1" in result


@pytest.mark.asyncio
@respx.mock
async def test_export_data_raises_auth_error_on_401():
    respx.get(f"{BASE}/v1/export").mock(
        return_value=httpx.Response(401, json={"error": {"code": "UNAUTHORIZED", "message": "Bad key"}})
    )
    async with Ironflow("if_bad") as client:
        with pytest.raises(AuthError):
            await client.export_data("fills")


@pytest.mark.asyncio
@respx.mock
async def test_export_data_raises_tier_error_on_403():
    respx.get(f"{BASE}/v1/export").mock(
        return_value=httpx.Response(403, json={"error": {"code": "TIER_INSUFFICIENT", "message": "Upgrade"}})
    )
    async with Ironflow("if_free") as client:
        with pytest.raises(TierError):
            await client.export_data("fills")


@pytest.mark.asyncio
@respx.mock
async def test_export_data_passes_params():
    route = respx.get(f"{BASE}/v1/export").mock(return_value=httpx.Response(200, content=b""))

    async with Ironflow("if_test") as client:
        await client.export_data("fills", market="BTC-PERP", from_ts=1000, to_ts=2000, format="parquet")

    req = route.calls.last.request
    assert "event_type=fills" in str(req.url)
    assert "market=BTC-PERP" in str(req.url)
    assert "format=parquet" in str(req.url)
    assert "from=1000" in str(req.url)
    assert "to=2000" in str(req.url)


# ─── Query error types ──────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_raises_query_window_error():
    respx.get(f"{BASE}/v1/trades").mock(
        return_value=httpx.Response(400, json={"error": {"code": "QUERY_WINDOW_EXCEEDED", "message": "Too wide"}})
    )
    async with Ironflow("if_test") as client:
        with pytest.raises(QueryWindowError) as exc_info:
            await client.trades("BTC-PERP")
    assert exc_info.value.code == "QUERY_WINDOW_EXCEEDED"


@pytest.mark.asyncio
@respx.mock
async def test_raises_query_too_expensive_error():
    respx.get(f"{BASE}/v1/trades").mock(
        return_value=httpx.Response(400, json={"error": {"code": "QUERY_TOO_EXPENSIVE", "message": "Too many rows"}})
    )
    async with Ironflow("if_test") as client:
        with pytest.raises(QueryTooExpensiveError):
            await client.trades("BTC-PERP")


@pytest.mark.asyncio
@respx.mock
async def test_raises_query_timeout_error():
    respx.get(f"{BASE}/v1/trades").mock(
        return_value=httpx.Response(504, json={"error": {"code": "QUERY_TIMEOUT", "message": "Timed out"}})
    )
    async with Ironflow("if_test") as client:
        with pytest.raises(QueryTimeoutError):
            await client.trades("BTC-PERP")


# ─── Remaining market data endpoints ────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_liquidations_returns_page():
    respx.get(f"{BASE}/v1/liquidations").mock(return_value=httpx.Response(200, json=list_of([
        {"source": "hyperliquid", "market": "BTC-PERP", "market_type": "perp", "timestamp": 1700000000000,
         "block_number": 1, "address": "0x", "size": "1", "price": "50000", "side": "long",
         "account_value": "0", "leverage_type": "isolated", "bankrupt": False, "sequence": 1}
    ])))
    async with Ironflow("if_test") as client:
        page = await client.liquidations("BTC-PERP")
    assert len(page.data) == 1
    assert page.data[0].side == "long"


@pytest.mark.asyncio
@respx.mock
async def test_funding_returns_page():
    respx.get(f"{BASE}/v1/funding").mock(return_value=httpx.Response(200, json=list_of([
        {"source": "hyperliquid", "market": "BTC-PERP", "timestamp": 1700000000000,
         "rate": "0.0001", "sequence": 1}
    ])))
    async with Ironflow("if_test") as client:
        page = await client.funding("BTC-PERP")
    assert page.data[0].rate == "0.0001"


@pytest.mark.asyncio
@respx.mock
async def test_open_interest_returns_page():
    respx.get(f"{BASE}/v1/open-interest").mock(return_value=httpx.Response(200, json=list_of([
        {"source": "hyperliquid", "market": "BTC-PERP", "timestamp": 1700000000000, "open_interest": "50000", "volume_24h": "100000"}
    ])))
    async with Ironflow("if_test") as client:
        page = await client.open_interest("BTC-PERP")
    assert page.data[0].open_interest == "50000"


@pytest.mark.asyncio
@respx.mock
async def test_mark_prices_returns_page():
    respx.get(f"{BASE}/v1/mark-prices").mock(return_value=httpx.Response(200, json=list_of([
        {"source": "hyperliquid", "market": "BTC-PERP", "timestamp": 1700000000000, "mark_price": "50000", "oracle_price": "49999", "funding_rate": "0.0001"}
    ])))
    async with Ironflow("if_test") as client:
        page = await client.mark_prices("BTC-PERP")
    assert page.data[0].mark_price == "50000"


@pytest.mark.asyncio
@respx.mock
async def test_deposits_returns_page():
    respx.get(f"{BASE}/v1/deposits").mock(return_value=httpx.Response(200, json=list_of([
        {"source": "hyperliquid", "market_type": "spot", "timestamp": 1700000000000, "block_number": 1,
         "address": "0x", "token": "USDC", "amount": "1000", "fee": "0", "sequence": 1}
    ])))
    async with Ironflow("if_test") as client:
        page = await client.deposits()
    assert page.data[0].amount == "1000"


@pytest.mark.asyncio
@respx.mock
async def test_withdrawals_returns_page():
    respx.get(f"{BASE}/v1/withdrawals").mock(return_value=httpx.Response(200, json=list_of([
        {"source": "hyperliquid", "market_type": "spot", "timestamp": 1700000000000, "block_number": 1,
         "address": "0x", "token": "USDC", "amount": "500", "fee": "0", "net_amount": "500", "sequence": 1}
    ])))
    async with Ironflow("if_test") as client:
        page = await client.withdrawals()
    assert page.data[0].amount == "500"


@pytest.mark.asyncio
@respx.mock
async def test_order_statuses_returns_page():
    respx.get(f"{BASE}/v1/order-statuses").mock(return_value=httpx.Response(200, json=list_of([
        {"source": "hyperliquid", "market": "BTC-PERP", "market_type": "perp", "timestamp": 1700000000000,
         "block_number": 1, "address": "0x", "order_id": "123", "status": "filled", "side": "buy",
         "price": "50000", "size": "0.1", "is_trigger": False, "reduce_only": False, "sequence": 1}
    ])))
    async with Ironflow("if_test") as client:
        page = await client.order_statuses()
    assert page.data[0].status == "filled"


@pytest.mark.asyncio
@respx.mock
async def test_vault_operations_returns_page():
    respx.get(f"{BASE}/v1/vault-operations").mock(return_value=httpx.Response(200, json=list_of([
        {"source": "hyperliquid", "market_type": "perp", "timestamp": 1700000000000, "block_number": 1,
         "vault": "HLP", "address": "0x", "operation": "deposit", "token": "USDC",
         "requested_amount": "1000", "net_amount": "1000", "commission": "0", "closing_cost": "0",
         "basis": "0", "sequence": 1}
    ])))
    async with Ironflow("if_test") as client:
        page = await client.vault_operations()
    assert page.data[0].operation == "deposit"


# ─── Triggers ───────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_create_trigger():
    trigger = {"id": 1, "user_id": 1, "name": "test", "channel": "trades", "rule": {}, "webhook_url": "https://x.com/hook", "is_active": True, "created_at": "2024-01-01"}
    route = respx.post(f"{BASE}/v1/triggers").mock(return_value=httpx.Response(200, json=trigger))

    async with Ironflow("if_test") as client:
        result = await client.create_trigger("test", "trades", {}, "https://x.com/hook")
    assert result.id == 1
    assert result.name == "test"
    assert route.called


@pytest.mark.asyncio
@respx.mock
async def test_list_triggers():
    respx.get(f"{BASE}/v1/triggers").mock(return_value=httpx.Response(200, json={
        "data": [{"id": 1, "user_id": 1, "name": "t", "channel": "trades", "rule": {}, "webhook_url": "https://x.com", "is_active": True}]
    }))
    async with Ironflow("if_test") as client:
        result = await client.list_triggers()
    assert len(result) == 1
    assert result[0].id == 1


@pytest.mark.asyncio
@respx.mock
async def test_toggle_trigger():
    trigger = {"id": 1, "user_id": 1, "name": "t", "channel": "trades", "rule": {}, "webhook_url": "https://x.com", "is_active": False, "created_at": ""}
    route = respx.patch(f"{BASE}/v1/triggers/1").mock(return_value=httpx.Response(200, json=trigger))

    async with Ironflow("if_test") as client:
        result = await client.toggle_trigger(1, is_active=False)
    assert result.is_active is False
    assert route.called


@pytest.mark.asyncio
@respx.mock
async def test_delete_trigger():
    route = respx.request("DELETE", f"{BASE}/v1/triggers/1").mock(return_value=httpx.Response(204))
    async with Ironflow("if_test") as client:
        await client.delete_trigger(1)
    assert route.called


@pytest.mark.asyncio
@respx.mock
async def test_test_trigger():
    respx.post(f"{BASE}/v1/triggers/test").mock(return_value=httpx.Response(200, json={"matched": True}))
    async with Ironflow("if_test") as client:
        result = await client.test_trigger({"condition": {"field": "data.size", "op": "gt", "value": "10"}}, {"size": "50"})
    assert result is True


# ─── Cohorts ────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_list_cohorts():
    respx.get(f"{BASE}/v1/cohorts").mock(return_value=httpx.Response(200, json={
        "data": [{"name": "top_pnl_30d", "description": "Top 100 PnL over 30d"}]
    }))
    async with Ironflow("if_test") as client:
        result = await client.list_cohorts()
    assert len(result) == 1
    assert result[0].name == "top_pnl_30d"
    assert result[0].description == "Top 100 PnL over 30d"


@pytest.mark.asyncio
@respx.mock
async def test_list_triggers_handles_null_data():
    # Server returns `{"data": null}` when the user has no triggers.
    respx.get(f"{BASE}/v1/triggers").mock(return_value=httpx.Response(200, json={"data": None}))
    async with Ironflow("if_test") as client:
        result = await client.list_triggers()
    assert result == []


@pytest.mark.asyncio
@respx.mock
async def test_cohort_addresses():
    respx.get(f"{BASE}/v1/cohorts/top_pnl_30d").mock(return_value=httpx.Response(200, json={
        "addresses": [{"address": "0xabc", "value": "123.45"}], "fetched_at": 1700000000000
    }))
    async with Ironflow("if_test") as client:
        result = await client.cohort_addresses("top_pnl_30d")
    assert len(result.addresses) == 1
    assert result.addresses[0].address == "0xabc"
    assert result.addresses[0].value == "123.45"


@pytest.mark.asyncio
@respx.mock
async def test_create_cohort():
    route = respx.post(f"{BASE}/v1/cohorts").mock(return_value=httpx.Response(200, json={"name": "my_whales", "description": ""}))
    async with Ironflow("if_test") as client:
        result = await client.create_cohort("my_whales", ["0xa", "0xb", "0xc"])
    assert result.name == "my_whales"
    assert route.called


@pytest.mark.asyncio
async def test_page_pagination_is_public():
    from ironflow_sdk.client import Page
    page = Page(data=[1, 2, 3], has_more=True, next_cursor="abc", next_fn=None)
    assert page.pagination.next_cursor == "abc"
    assert page.pagination.has_more is True


@pytest.mark.asyncio
@respx.mock
async def test_delete_cohort():
    route = respx.request("DELETE", f"{BASE}/v1/cohorts/my_whales").mock(return_value=httpx.Response(204))
    async with Ironflow("if_test") as client:
        await client.delete_cohort("my_whales")
    assert route.called


# ─── Analytics ──────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_net_flows():
    respx.get(f"{BASE}/v1/analytics/net-flows").mock(return_value=httpx.Response(200, json={
        "data": [{"source": "hyperliquid", "address": "0x", "bucket": 1700000000000, "deposits": "1000", "withdrawals": "500", "net_flow": "500"}]
    }))
    async with Ironflow("if_test") as client:
        result = await client.net_flows()
    assert len(result) == 1
    assert result[0].net_flow == "500"


@pytest.mark.asyncio
@respx.mock
async def test_liquidation_levels():
    respx.get(f"{BASE}/v1/analytics/liquidation-levels").mock(return_value=httpx.Response(200, json={
        "data": [{"source": "hyperliquid", "market": "BTC-PERP", "price_bucket": "50000", "side": "buy", "count": 10, "total_size": "100"}]
    }))
    async with Ironflow("if_test") as client:
        result = await client.liquidation_levels("BTC-PERP")
    assert result[0].price_bucket == "50000"


@pytest.mark.asyncio
@respx.mock
async def test_order_flow():
    respx.get(f"{BASE}/v1/analytics/order-flow").mock(return_value=httpx.Response(200, json={
        "data": [{"source": "hyperliquid", "market": "BTC-PERP", "total_orders": 150, "filled_orders": 100, "cancelled": 50, "fill_rate": "0.67"}]
    }))
    async with Ironflow("if_test") as client:
        result = await client.order_flow()
    assert result[0].filled_orders == 100


@pytest.mark.asyncio
@respx.mock
async def test_vault_leaderboard():
    respx.get(f"{BASE}/v1/analytics/vault-leaderboard").mock(return_value=httpx.Response(200, json={
        "data": [{"source": "hyperliquid", "vault": "HLP", "total_deposits": "1000000", "total_withdrawals": "200000", "net_flow": "800000", "unique_users": 50}]
    }))
    async with Ironflow("if_test") as client:
        result = await client.vault_leaderboard()
    assert result[0].vault == "HLP"


@pytest.mark.asyncio
@respx.mock
async def test_funding_stats():
    respx.get(f"{BASE}/v1/analytics/funding-stats").mock(return_value=httpx.Response(200, json={
        "data": [{"source": "hyperliquid", "market": "BTC-PERP", "bucket": 1700000000000, "avg_rate": "0.0001", "min_rate": "-0.0001", "max_rate": "0.0003", "cumulative_rate": "0.0003"}]
    }))
    async with Ironflow("if_test") as client:
        result = await client.funding_stats("BTC-PERP")
    assert result[0].avg_rate == "0.0001"


# ─── Status ─────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_status():
    respx.get(f"{BASE}/v1/status").mock(return_value=httpx.Response(200, json={
        "status": "operational",
        "timestamp": 1700000000000,
        "uptime": "1h2m3s",
        "platform": {
            "total_events": 1_000_000,
            "total_markets": 568,
            "event_types_active": 9,
            "oldest_data_days": 260,
        },
        "venues": {
            "hyperliquid": {
                "status": "operational",
                "markets": 568,
                "streams": {
                    "fills": {
                        "latest_timestamp": "2026-04-20 09:58:53.033",
                        "age_seconds": 2.5,
                        "total_rows": 1_800_000_000,
                    },
                },
                "events": {
                    "liquidations": {
                        "latest_timestamp": "2026-04-20 09:54:12.019",
                        "age_seconds": 281.0,
                        "total_rows": 1_200_000,
                    },
                },
            }
        }
    }))
    async with Ironflow("if_test") as client:
        result = await client.status()
    assert result.status == "operational"
    assert result.venues["hyperliquid"].streams["fills"].age_seconds == 2.5
    assert result.venues["hyperliquid"].streams["fills"].total_rows == 1_800_000_000
    assert result.venues["hyperliquid"].events["liquidations"].age_seconds == 281.0
    assert result.platform is not None
    assert result.platform.total_markets == 568


# ─── Timeout config ─────────────────────────────────────────────────────────

def test_timeout_passed_to_client():
    client = Ironflow("if_test", timeout=5.0)
    # Verify the httpx client was configured with the timeout
    assert client._http._client.timeout.connect == 5.0


# ─── User-Agent header ──────────────────────────────────────────────────────

@pytest.mark.asyncio
@respx.mock
async def test_user_agent_header():
    route = respx.get(f"{BASE}/v1/trades").mock(return_value=httpx.Response(200, json=list_of([])))
    async with Ironflow("if_test") as client:
        await client.trades("BTC-PERP")
    req = route.calls.last.request
    assert req.headers["User-Agent"].startswith("ironflow-sdk/")


# ─── Streaming (smoke test) ──────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_stream_client_returns_async_generator():
    from collections.abc import AsyncGenerator
    from ironflow_sdk.stream import StreamClient

    sc = StreamClient("wss://example.com/ws")
    gen = sc.trades("BTC-PERP")
    assert isinstance(gen, AsyncGenerator)
    await gen.aclose()


@pytest.mark.asyncio
async def test_stream_typed_methods_exist():
    from ironflow_sdk.stream import StreamClient

    sc = StreamClient("wss://example.com/ws")
    # Verify all stream methods exist and return generators
    methods = ["trades", "fills", "book", "book_l4", "orders", "liquidations",
               "funding_rates", "deposits", "withdrawals", "vault_operations"]
    for method_name in methods:
        method = getattr(sc, method_name)
        assert callable(method), f"StreamClient.{method_name} should be callable"
