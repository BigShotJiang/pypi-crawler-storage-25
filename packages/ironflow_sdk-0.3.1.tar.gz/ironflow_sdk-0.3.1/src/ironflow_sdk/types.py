# Response dataclasses for the Ironflow API.

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class Trade:
    source: str
    #: Full market identifier. Native HL perps use the base symbol (e.g. ``BTC-PERP``);
    #: HIP-3 builder-deployed markets are namespaced as ``<builder>:<base>`` (e.g. ``flx:GAS-PERP``).
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped. Equal to ``market`` for native HL perps.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    sequence: int
    price: str
    size: str
    side: str
    address: str
    fee: str
    realized_pnl: str
    hash: str
    # v3 identity fields (HIP-3 cutover, 2026-04-27).
    venue: str = ""
    market_class: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""
    # v3 fills-specific fields.
    notional: str = ""
    oid: int = 0
    tid: int = 0
    fee_token: str = ""
    liquidation: bool = False


@dataclass
class BookLevel:
    price: str
    size: str


@dataclass
class BookSnapshot:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    timestamp: int
    bids: list[BookLevel]
    asks: list[BookLevel]
    # v3 identity fields.
    venue: str = ""
    market_class: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


@dataclass
class Candle:
    source: str
    market: str
    #: Echoes the ``issuer`` filter used in the request. Empty if not filtered.
    issuer: str
    #: Echoes the ``base_market`` filter used in the request. Empty if not filtered.
    base_market: str
    interval: str
    timestamp: int
    open: str
    high: str
    low: str
    close: str
    volume: str
    trade_count: int


@dataclass
class FundingRate:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    timestamp: int
    rate: str
    sequence: int
    # v3 identity fields. funding_rates_v3 is perp-only — no market_class.
    venue: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


@dataclass
class Liquidation:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    address: str
    side: str
    price: str
    size: str
    account_value: str
    leverage_type: str
    bankrupt: bool
    sequence: int
    liquidator: str = ""
    realized_pnl: str = ""
    margin_requirement: str = ""
    hash: str = ""
    detection_method: str = ""
    # v3 identity fields. liquidations_v3 is perp-only — no market_class.
    venue: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


@dataclass
class OpenInterest:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    timestamp: int
    open_interest: str
    #: Always ``"0"`` post-HIP-3 cutover. ``open_interest_v3`` dropped this column;
    #: the field is kept for backwards-compat but never populated.
    volume_24h: str
    # v3 identity fields. open_interest_v3 is perp-only — no market_class.
    venue: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


@dataclass
class MarkPrice:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    timestamp: int
    mark_price: str
    #: Always ``"0"`` post-HIP-3 cutover. ``mark_prices_v3`` carries only ``price``.
    oracle_price: str
    #: Always ``"0"`` post-HIP-3 cutover. ``mark_prices_v3`` carries only ``price``.
    funding_rate: str
    # v3 identity fields. mark_prices_v3 is perp-only — no market_class.
    venue: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


@dataclass
class Deposit:
    source: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL (non-market-scoped event).
    issuer: str
    #: Base market symbol for market-scoped deposits. Empty for global deposits.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    address: str
    token: str
    amount: str
    fee: str
    sequence: int
    origin: str = ""
    tx_hash: str = ""


@dataclass
class Withdrawal:
    source: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL (non-market-scoped event).
    issuer: str
    #: Base market symbol for market-scoped withdrawals. Empty for global withdrawals.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    address: str
    token: str
    amount: str
    fee: str
    net_amount: str
    sequence: int
    destination: str = ""
    tx_hash: str = ""
    nonce: int = 0


@dataclass
class OrderStatus:
    source: str
    market: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL markets.
    issuer: str
    #: Base market symbol with any issuer namespace stripped.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    address: str
    order_id: str
    status: str
    side: str
    price: str
    size: str
    is_trigger: bool
    reduce_only: bool
    sequence: int
    client_order_id: str = ""
    original_size: str = ""
    order_type: str = ""
    time_in_force: str = ""
    trigger_price: str = ""
    trigger_condition: str = ""
    # v3 identity fields (HIP-3 cutover).
    venue: str = ""
    market_class: str = ""
    market_id: int = 0
    quote_asset: str = ""
    display_symbol: str = ""


# ─── Vault Operations ─────────────────────────────────────────────────


@dataclass
class VaultOperation:
    source: str
    #: HIP-3 builder/issuer namespace. Empty string for native HL (non-market-scoped event).
    issuer: str
    #: Base market symbol for market-scoped vault ops. Empty for global vault ops.
    base_market: str
    market_type: str
    timestamp: int
    block_number: int
    address: str
    vault: str
    operation: str
    token: str
    requested_amount: str
    net_amount: str
    commission: str
    closing_cost: str
    basis: str
    sequence: int
    tx_hash: str = ""


# ─── Triggers ─────────────────────────────────────────────────────────


@dataclass
class Trigger:
    id: int
    user_id: int
    name: str
    channel: str
    rule: dict[str, Any]
    webhook_url: str
    is_active: bool
    created_at: str = ""


# ─── Cohorts ──────────────────────────────────────────────────────────


@dataclass
class CohortInfo:
    name: str
    description: str = ""


@dataclass
class CohortAddressEntry:
    address: str
    value: str | None = None


@dataclass
class CohortAddresses:
    addresses: list[CohortAddressEntry]
    fetched_at: int


# ─── Analytics ────────────────────────────────────────────────────────


@dataclass
class NetFlow:
    source: str
    address: str
    bucket: int
    deposits: str
    withdrawals: str
    net_flow: str


@dataclass
class LiquidationLevel:
    source: str
    market: str
    price_bucket: str
    side: str
    count: int
    total_size: str


@dataclass
class OrderFlow:
    source: str
    market: str
    total_orders: int
    filled_orders: int
    cancelled: int
    fill_rate: str


@dataclass
class VaultLeaderboardEntry:
    source: str
    vault: str
    total_deposits: str
    total_withdrawals: str
    net_flow: str
    unique_users: int


@dataclass
class FundingStats:
    source: str
    market: str
    bucket: int
    avg_rate: str
    min_rate: str
    max_rate: str
    cumulative_rate: str


@dataclass
class DataFreshness:
    latest_timestamp: str
    age_seconds: float
    total_rows: int


@dataclass
class VenueStatus:
    status: str
    markets: int
    streams: dict[str, DataFreshness]
    events: dict[str, DataFreshness]


@dataclass
class PlatformStats:
    total_events: int
    total_markets: int
    event_types_active: int
    oldest_data_days: int


@dataclass
class StatusResponse:
    status: str
    timestamp: int
    uptime: str
    venues: dict[str, VenueStatus]
    platform: PlatformStats | None = None


# ─── Account ──────────────────────────────────────────────────────────


@dataclass
class MeLimits:
    requests_per_min: int
    info_requests_per_min: int
    history_window_ms: int
    websocket_connections: int
    address_tracking: int
    full_analytics: bool


@dataclass
class MeResponse:
    tier: str
    active: bool
    limits: MeLimits


@dataclass
class HealthResponse:
    status: str


# ─── Markets registry ─────────────────────────────────────────────────


@dataclass
class Market:
    market_id: int
    source: str
    market_class: str  # "perp" | "spot" | "prediction" | "option"
    issuer: str
    base_asset: str
    quote_asset: str
    base_market: str
    display_symbol: str
    active_from_ms: int
    hl_coin: str | None = None


# ─── System metrics & history ─────────────────────────────────────────


@dataclass
class APIMetrics:
    latency_p50_ms: float
    latency_p99_ms: float
    error_rate: float
    websocket_clients: int


@dataclass
class PipelineMetrics:
    streaming_latency_ms: float
    events_per_sec: float


@dataclass
class SyntheticMetrics:
    ws_latency_ms: float
    ws_latency_p50_ms: float
    query_latencies: dict[str, float]


@dataclass
class StatusMetricsResponse:
    timestamp: int
    api: APIMetrics
    pipeline: PipelineMetrics
    synthetic: SyntheticMetrics


@dataclass
class UptimePoint:
    ts: int
    status: str  # "operational" | "degraded" | "down"
    fresh_sec: float


@dataclass
class StatusHistoryResponse:
    period: str
    uptime_percent: float
    points: list[UptimePoint]
