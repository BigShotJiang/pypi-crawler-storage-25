# Typed exceptions for the Ironflow API.


class IronflowError(Exception):
    """Base class for all Ironflow API errors."""

    def __init__(self, message: str, code: str, status: int) -> None:
        super().__init__(message)
        self.code = code
        self.status = status


class RateLimitError(IronflowError):
    """Raised when the API returns 429 Too Many Requests."""

    def __init__(self, message: str, retry_after_ms: int) -> None:
        super().__init__(message, "RATE_LIMIT_EXCEEDED", 429)
        self.retry_after_ms = retry_after_ms


class AuthError(IronflowError):
    """Raised when the API returns 401 Unauthorized."""

    def __init__(self, message: str) -> None:
        super().__init__(message, "UNAUTHORIZED", 401)


class TierError(IronflowError):
    """Raised when the API returns 403 Forbidden (tier insufficient)."""

    def __init__(self, message: str, code: str = "TIER_FORBIDDEN") -> None:
        super().__init__(message, code, 403)


class QueryWindowError(IronflowError):
    """Raised when the query time range exceeds the per-request maximum."""

    def __init__(self, message: str) -> None:
        super().__init__(message, "QUERY_WINDOW_EXCEEDED", 400)


class QueryTimeoutError(IronflowError):
    """Raised when a query exceeds the server execution time limit (15s)."""

    def __init__(self, message: str) -> None:
        super().__init__(message, "QUERY_TIMEOUT", 504)


class QueryTooExpensiveError(IronflowError):
    """Raised when a query exceeds server resource limits (row/byte scan caps)."""

    def __init__(self, message: str) -> None:
        super().__init__(message, "QUERY_TOO_EXPENSIVE", 400)
