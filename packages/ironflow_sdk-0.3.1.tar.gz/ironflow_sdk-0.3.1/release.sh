#!/usr/bin/env bash
# Release helper for ironflow-sdk.
#
# Python has no equivalent to npm's prepublishOnly hook, so this script
# enforces the "wipe → build → lint → upload" sequence. Use this instead
# of calling twine directly to guarantee a fresh build.
#
# Usage:
#   ./release.sh               # builds and uploads via twine (reads ~/.pypirc)
#   ./release.sh --dry-run     # builds and runs twine check, skips upload
set -euo pipefail

cd "$(dirname "$0")"

VENV="/tmp/ironflow-release-venv"
if [[ ! -x "$VENV/bin/python" ]]; then
  echo "creating release venv at $VENV"
  /opt/homebrew/bin/python3.13 -m venv "$VENV"
  "$VENV/bin/pip" install -q --upgrade pip build twine
fi

echo "→ wiping dist/"
rm -rf dist build

echo "→ building sdist + wheel"
"$VENV/bin/python" -m build

echo "→ twine check"
"$VENV/bin/python" -m twine check dist/*

if [[ "${1:-}" == "--dry-run" ]]; then
  echo "dry-run complete, skipping upload"
  exit 0
fi

echo "→ uploading to PyPI"
"$VENV/bin/python" -m twine upload dist/*

echo "✓ published. don't forget to tag:"
VERSION=$(grep -E '^version\s*=' pyproject.toml | head -1 | sed -E 's/.*"(.+)".*/\1/')
echo "  git tag sdk-python-v$VERSION && git push origin sdk-python-v$VERSION"
