from ._linerapy import YieldCurve

__all__ = ["YieldCurve"]

__version__ = "0.1.0"