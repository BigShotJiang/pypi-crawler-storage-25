"""CLI 入口"""
import os
import click
import json
import shutil
from typing import Callable, Optional

from .api import BUG_DIRECTION_NEXT_NODE_IDS, DevOpsAPI
from .auth import login
from .config import config


def _parse_custom_fields(entries):
    result = []
    for item in entries:
        if "=" not in item:
            raise click.ClickException(f"--field 参数格式错误: {item}，应为 fieldId=value")
        field_id, value = item.split("=", 1)
        field_id = field_id.strip()
        if not field_id:
            raise click.ClickException(f"--field 参数格式错误: {item}，fieldId 不能为空")
        result.append({"fieldId": field_id, "value": value})
    return result


def _normalize_cell(value):
    if value is None:
        return "-"
    return str(value)


def _truncate_text(text, width):
    if width <= 0:
        return ""
    if len(text) <= width:
        return text
    if width <= 1:
        return text[:width]
    return text[: width - 1] + "…"


def render_table(headers, rows, max_width=120, no_truncate_headers=None):
    if not rows:
        click.echo("暂无数据")
        return

    terminal_width = shutil.get_terminal_size((max_width, 20)).columns
    table_max_width = min(max_width, terminal_width)

    no_truncate_headers = set(no_truncate_headers or [])

    normalized_rows = []
    for row in rows:
        normalized = [_normalize_cell(cell) for cell in row[: len(headers)]]
        if len(normalized) < len(headers):
            normalized.extend(["-"] * (len(headers) - len(normalized)))
        normalized_rows.append(normalized)

    widths = [len(h) for h in headers]
    for row in normalized_rows:
        for idx, cell in enumerate(row):
            widths[idx] = max(widths[idx], len(cell))

    # 边框和分隔占用: 左右边框 + 每列两侧空格 + 列分隔符
    overhead = 3 * len(headers) + 1
    available = max(20, table_max_width - overhead)
    min_col_width = 10
    widths = [max(min_col_width, w) for w in widths]

    total = sum(widths)
    if total > available:
        fixed_idx = {i for i, h in enumerate(headers) if h in no_truncate_headers}
        shrinkable_idx = [i for i in range(len(headers)) if i not in fixed_idx]

        if shrinkable_idx:
            while sum(widths) > available:
                idx = max(shrinkable_idx, key=lambda i: widths[i])
                if widths[idx] > min_col_width:
                    widths[idx] -= 1
                else:
                    if all(widths[i] <= min_col_width for i in shrinkable_idx):
                        break
        # 若仍超出可用宽度，保留不截断列完整内容，允许终端自动换行/横向滚动查看

    def format_row(cells):
        parts = []
        for i, cell in enumerate(cells):
            text = cell if headers[i] in no_truncate_headers else _truncate_text(cell, widths[i])
            parts.append(f" {text.ljust(widths[i])} ")
        return "|" + "|".join(parts) + "|"

    border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    click.echo(border)
    click.echo(format_row(headers))
    click.echo(border)
    for row in normalized_rows:
        click.echo(format_row(row))
    click.echo(border)


def _extract_api_message(payload) -> str:
    if not isinstance(payload, dict):
        return ""
    for key in ("message", "msg", "errorMsg", "error"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _is_api_success(payload) -> bool:
    """兼容不同后端返回结构，判断请求是否成功。"""
    if payload is None:
        return False

    # HTTP 2xx 但无 body 的场景，_request 会返回 {}
    if isinstance(payload, dict) and not payload:
        return True

    if not isinstance(payload, dict):
        return False

    for key in ("success", "ok"):
        if key in payload:
            return bool(payload.get(key))

    code = payload.get("code")
    if code is not None:
        if str(code).strip() in {"0", "200"}:
            return True
        return False

    status = payload.get("status")
    if isinstance(status, str):
        norm_status = status.strip().lower()
        if norm_status in {"success", "ok", "succeeded"}:
            return True
        if norm_status in {"fail", "failed", "error"}:
            return False

    message = _extract_api_message(payload).lower()
    if message:
        if any(word in message for word in ("失败", "错误", "error", "fail")):
            return False
        if any(word in message for word in ("成功", "success")):
            return True

    if "data" in payload:
        return payload.get("data") is not None

    return False


def _print_action_result(
        ctx,
        result,
        success_text: str = "",
        fail_prefix: str = "操作失败",
        success_checker: Optional[Callable[[dict], bool]] = None,
        success_text_builder: Optional[Callable[[dict], str]] = None,
) -> bool:
    """统一处理命令结果输出；返回是否成功。"""
    checker = success_checker or _is_api_success

    if ctx.obj.get("output_format") == "json":
        click.echo(json.dumps(result, ensure_ascii=False, indent=2, default=str))
        return checker(result)

    if checker(result):
        text = success_text_builder(result) if success_text_builder else success_text
        if text:
            click.echo(text)
        return True

    msg = _extract_api_message(result) or "未返回成功状态"
    click.echo(f"{fail_prefix}: {msg}", err=True)
    return False


@click.group()
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option(
    "--output",
    "-o",
    "output_format",
    type=click.Choice(["human", "json"], case_sensitive=False),
    default="json",
    show_default=True,
    help="输出格式: human(表格) / json",
)
@click.pass_context
def cli(ctx, project, output_format):
    """DevOps 平台迭代管理工具"""
    ctx.ensure_object(dict)
    ctx.obj["project"] = project or config.default_project
    ctx.obj["output_format"] = output_format.lower()


@cli.command("login")
@click.option(
    "--headed",
    is_flag=True,
    help="显示浏览器窗口，用于无环境变量时的手动登录",
)
def cmd_login(headed):
    """登录 - 打开浏览器重新获取 cookie（默认无头；需手动登录时请传 --headed）"""
    login(headless=not headed)


@cli.group()
def sprint():
    """迭代管理命令组"""
    pass


@cli.group()
def project():
    """项目管理命令组"""
    pass


@cli.group()
def issue():
    """需求管理命令组"""
    pass


@cli.group()
def bug():
    """缺陷管理命令组"""
    pass


@cli.group()
def task():
    """任务管理命令组"""
    pass


@cli.group("zteam-project")
def zteam_project():
    """ZTeam 项目命令组"""
    pass


@sprint.command("create")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--title", "-t", required=True, help="迭代名称")
@click.option("--start-date", "-s", required=True, help="开始日期 (YYYY-MM-DD)")
@click.option("--end-date", "-e", required=True, help="结束日期 (YYYY-MM-DD)")
@click.option("--purpose", required=True, help="迭代目标")
@click.option("--test-start", required=True, help="测试开始日期")
@click.option("--test-end", required=True, help="测试结束日期")
@click.pass_context
def create_sprint(ctx, project, title, start_date, end_date, purpose, test_start, test_end):
    """创建迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        result = api.create_sprint(
            title=title,
            start_date=start_date,
            end_date=end_date,
            purpose=purpose or "",
            test_start_date=test_start,
            test_end_date=test_end,
        )

        _print_action_result(
            ctx,
            result,
            fail_prefix="创建失败",
            success_checker=lambda payload: bool(
                payload.get("data", {}).get("id")
            ) if isinstance(payload, dict) else False,
            success_text_builder=lambda payload: f"创建成功! 迭代 ID: {payload.get('data', {}).get('id')}",
        )

    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("start")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--sprint-id", "-i", required=True, help="迭代 ID")
@click.pass_context
def start_sprint(ctx, project, sprint_id):
    """启用迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        sprints = api.list_sprints()
        sprint_data = None
        for s in sprints.get("data").get("content"):
            if s.get("id") == sprint_id:
                sprint_data = s
                break

        if not sprint_data:
            click.echo(f"未找到迭代: {sprint_id}", err=True)
            return

        result = api.start_sprint(sprint_data)
        _print_action_result(ctx, result, "启用成功!", "启用失败")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("delete")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--sprint-id", "-i", required=True, help="迭代 ID")
@click.pass_context
def delete_sprint(ctx, project, sprint_id):
    """删除迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    if not click.confirm(f"确认删除迭代 {sprint_id}?"):
        return

    try:
        result = api.delete_sprint(sprint_id)
        _print_action_result(ctx, result, "删除成功!", "删除失败")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("done")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--sprint-id", "-i", required=True, help="迭代 ID")
@click.pass_context
def done_sprint(ctx, project, sprint_id):
    """ 完成迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    if not click.confirm(f"确认完成迭代 {sprint_id}?"):
        return

    try:
        result = api.done_sprint(sprint_id)
        _print_action_result(ctx, result, "完成成功!", "完成失败")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("list")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.pass_context
def list_sprint(ctx, project):
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        sprints = api.list_sprints()
        sprint_list = sprints.get("data", {}).get("content", [])
        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    sprint_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return
        render_table(
            headers=["迭代名称", "迭代ID", "开始时间", "结束时间", "迭代状态", "提测时间", "测试开始时间",
                     "测试完成时间", "验收完成", "开发负责人", "测试负责人", "验收负责人"],
            rows=[
                [
                    s.get("title"),
                    s.get("id"),
                    s.get("startDate"),
                    s.get("endDate"),
                    s.get("state"),
                    s.get("testStartDate"),
                    s.get("smokeEndDate"),
                    s.get("testEndDate"),
                    s.get("acceptanceEndDate"),
                    s.get("developmentPic"),
                    s.get("testPic"),
                    s.get("acceptancePic")
                ]
                for s in sprint_list
            ],
            no_truncate_headers=["迭代ID", "迭代名称"],
        )

    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("test-list")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--num", default=1, show_default=True, type=int, help="页码")
@click.option("--size", default=20, show_default=True, type=int, help="每页条数")
@click.option("--search", default="", show_default=True, help="搜索关键词（如迭代名称）")
@click.option("--result", "results", multiple=True, help="提测结果，可重复传入")
@click.option("--create-user", "create_users", multiple=True, help="创建人账号，可重复传入")
@click.option("--create-time", "create_times", multiple=True, help="创建时间筛选值，可重复传入")
@click.option("--principal", "principals", multiple=True, help="负责人账号，可重复传入")
@click.option("--obj-id", "obj_ids", multiple=True, help="对象 ID，可重复传入")
@click.pass_context
def list_sprint_tests(ctx, project, num, size, search, results, create_users, create_times, principals, obj_ids):
    """查询迭代提测列表"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        payload = api.list_sprint_tests(
            num=num,
            size=size,
            search=search,
            result=list(results),
            create_user=list(create_users),
            create_time=list(create_times),
            principal=list(principals),
            obj_id=list(obj_ids),
        )
        data = payload.get("data", {}) if isinstance(payload, dict) else {}
        test_list = data.get("content", []) if isinstance(data, dict) else []
        if not isinstance(test_list, list):
            test_list = []

        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    test_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return

        render_table(
            headers=["提测ID", "迭代名称", "提测标题", "提测结果", "负责人", "创建人", "创建时间"],
            rows=[
                [
                    s.get("id"),
                    s.get("objName") or s.get("sprintName"),
                    s.get("title") or s.get("name"),
                    s.get("result"),
                    s.get("principal"),
                    s.get("createUser"),
                    s.get("createTime"),
                ]
                for s in test_list
            ],
            no_truncate_headers=["提测ID", "迭代名称", "提测标题"],
        )
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@project.command("list")
@click.pass_context
def list_project(ctx):
    api = DevOpsAPI("")

    try:
        projects = api.list_projects()
        project_list = projects.get("data", [])
        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    project_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return
        render_table(
            headers=["项目代码", "项目名称", "部门名称"],
            rows=[
                [
                    s.get("projectCode"),
                    s.get("projectName"),
                    s.get("deptName"),
                ]
                for s in project_list
            ],
        )

    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@zteam_project.command("list")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.pass_context
def list_zteam_project(ctx, project):
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        payload = api.list_zteam_projects()
        project_list = payload.get("data", []) if isinstance(payload, dict) else []
        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    project_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return
        render_table(
            headers=["ZTeam项目ID", "ZTeam项目名称"],
            rows=[
                [
                    s.get("id") or s.get("value"),
                    s.get("name") or s.get("label"),
                ]
                for s in project_list
            ],
            no_truncate_headers=["ZTeam项目ID", "ZTeam项目名称"],
        )

    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@issue.command("field-options")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option(
    "--field-id",
    required=True,
    help="字段 ID（与页面 issue_field_value/.../option/{fieldId} 一致）",
)
@click.option(
    "--classify",
    required=True,
    help="工作项类型，与页面 classify 一致，如 BUG、TASK、STORY",
)
@click.option(
    "--all/--no-all",
    "all_options",
    default=False,
    show_default=True,
    help="是否返回全部选项（与页面 all 参数一致）",
)
@click.pass_context
def list_issue_field_options(ctx, project, field_id, classify, all_options):
    """查询工作项自定义字段下拉可选项（如需求/缺陷的优先级、严重程度等，取决于 field-id 与 classify）。"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        payload = api.list_issue_field_value_options(
            field_id=field_id,
            classify=classify,
            all_options=all_options,
        )
        options = payload.get("data", []) if isinstance(payload, dict) else []
        if not isinstance(options, list):
            options = []

        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    options,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return

        render_table(
            headers=["选项值", "选项名称"],
            rows=[
                [
                    s.get("id") or s.get("value"),
                    s.get("name") or s.get("label"),
                ]
                for s in options
            ],
            no_truncate_headers=["选项值", "选项名称"],
        )
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@task.command("list")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option("--start-date", required=True, help="预计开始/结束筛选起始日期 (YYYY-MM-DD)")
@click.option("--end-date", required=True, help="预计开始/结束筛选结束日期 (YYYY-MM-DD)")
@click.option("--creator", required=None, help="创建人账号，例如 zt07905")
@click.option("--num", default=1, show_default=True, type=int, help="页码")
@click.option("--size", default=20, show_default=True, type=int, help="每页条数")
@click.option("--remember/--no-remember", default=False, show_default=True, help="是否启用后端记忆筛选条件")
@click.pass_context
def list_task(ctx, project, start_date, end_date, creator, num, size, remember):
    def _extract_task_list(payload):
        if not isinstance(payload, dict):
            return []
        data = payload.get("data")
        if isinstance(data, list):
            return data
        if not isinstance(data, dict):
            return []

        # 兼容多种后端结构:
        # 1) data 为列表
        # 2) data.content 为列表
        # 3) data.records.content 为列表（DevOps 新版任务接口）
        content = None
        if isinstance(data.get("content"), list):
            content = data.get("content")
        else:
            records = data.get("records")
            if isinstance(records, dict) and isinstance(records.get("content"), list):
                content = records.get("content")

        if not isinstance(content, list):
            return []

        def _unwrap_value(v):
            if not isinstance(v, dict):
                return v
            for key in ("value", "label", "name", "displayName", "text", "title"):
                if key in v and v.get(key) not in (None, ""):
                    return v.get(key)
            # 兜底: 防止 {...} 这类占位结构影响输出
            return None

        result = []
        for item in content:
            if not isinstance(item, dict):
                continue

            # data.records.content[].property 结构
            prop = item.get("property")
            if isinstance(prop, dict):
                flattened = {}
                for k, v in prop.items():
                    flattened[k] = _unwrap_value(v)
                result.append(flattened)
                continue

            # 兼容旧结构（item 本身就是任务对象）
            normalized = {}
            for k, v in item.items():
                normalized[k] = _unwrap_value(v)
            result.append(normalized)

        return result

    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        result = api.list_tasks(
            start_date=start_date,
            end_date=end_date,
            creator=creator,
            num=num,
            size=size,
            remember=remember,
        )
        task_list = _extract_task_list(result)

        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    task_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return

        render_table(
            headers=["任务ID", "标题", "状态", "创建人", "负责人", "预计开始", "预计结束"],
            rows=[
                [
                    t.get("id") or t.get("issue_id"),
                    t.get("title") or t.get("name"),
                    t.get("state") or t.get("status"),
                    t.get("createUser") or t.get("creator"),
                    t.get("currentOwner") or t.get("handler"),
                    t.get("estimate_start_time") or t.get("estimateStartTime"),
                    t.get("estimate_end_time") or t.get("estimateEndTime"),
                ]
                for t in task_list
            ],
            no_truncate_headers=["任务ID", "标题"],
        )
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


def _csv_to_list(value: Optional[str]) -> Optional[list]:
    if value is None or not str(value).strip():
        return None
    parts = [p.strip() for p in str(value).split(",") if p.strip()]
    return parts or None


@bug.command("list")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option("--num", default=1, show_default=True, type=int, help="页码")
@click.option("--size", default=20, show_default=True, type=int, help="每页条数")
@click.option("--remember/--no-remember", default=False, show_default=True, help="是否启用后端记忆筛选条件")
@click.option("--operator", help="缺陷经办人账号，多个用英文逗号分隔（operator_user）")
@click.option(
    "--zteam-project",
    help="ZTeam 团队项目筛选值，多个用英文逗号分隔（z_team_project_name，如列表中的项目 ID）",
)
@click.option(
    "--owner-field",
    default="F0dvVdNHpJ",
    show_default=True,
    help="缺陷责任人对应自定义字段名（不同项目可能不同；与页面请求体 name 一致）",
)
@click.option("--owner", help="缺陷责任人账号，多个用英文逗号分隔（写入 --owner-field 对应字段）")
@click.option("--state", help="缺陷状态 ID，多个用英文逗号分隔（可先执行 bug states 查询）")
@click.option("--creator", help="缺陷创建人账号，多个用英文逗号分隔（createUser）")
@click.option(
    "--create-date",
    help="创建日期 YYYY-MM-DD（单日筛选，等价于起止均为该日）",
)
@click.option("--create-start", help="创建时间筛选起始 YYYY-MM-DD（需与 --create-end 同时使用）")
@click.option("--create-end", help="创建时间筛选结束 YYYY-MM-DD（需与 --create-start 同时使用）")
@click.pass_context
def list_bugs(
        ctx,
        project,
        num,
        size,
        remember,
        operator,
        zteam_project,
        owner_field,
        owner,
        state,
        creator,
        create_date,
        create_start,
        create_end,
):
    """查询缺陷列表"""
    if (create_start or create_end) and not (create_start and create_end):
        click.echo("错误: --create-start 与 --create-end 需同时指定", err=True)
        raise click.Abort()

    create_time = None
    if create_start and create_end:
        create_time = [create_start, create_end]
    elif create_date:
        create_time = [create_date, create_date]

    def _extract_bug_list(payload):
        if not isinstance(payload, dict):
            return []
        data = payload.get("data")
        if isinstance(data, list):
            return data
        if not isinstance(data, dict):
            return []

        content = None
        if isinstance(data.get("content"), list):
            content = data.get("content")
        else:
            records = data.get("records")
            if isinstance(records, dict) and isinstance(records.get("content"), list):
                content = records.get("content")

        if not isinstance(content, list):
            return []

        def _unwrap_value(v):
            if not isinstance(v, dict):
                return v
            for key in ("value", "label", "name", "displayName", "text", "title"):
                if key in v and v.get(key) not in (None, ""):
                    return v.get(key)
            return None

        result = []
        for item in content:
            if not isinstance(item, dict):
                continue
            prop = item.get("property")
            if isinstance(prop, dict):
                flattened = {}
                for k, v in prop.items():
                    flattened[k] = _unwrap_value(v)
                result.append(flattened)
                continue

            normalized = {}
            for k, v in item.items():
                normalized[k] = _unwrap_value(v)
            result.append(normalized)
        return result

    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        result = api.list_bugs(
            num=num,
            size=size,
            remember=remember,
            operator_user=_csv_to_list(operator),
            z_team_project_name=_csv_to_list(zteam_project),
            defect_owner_field=owner_field,
            defect_owner=_csv_to_list(owner),
            state=_csv_to_list(state),
            create_user=_csv_to_list(creator),
            create_time=create_time,
        )
        bug_list = _extract_bug_list(result)

        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    bug_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return

        render_table(
            headers=["缺陷ID", "标题", "状态", "创建人", "负责人", "优先级", "严重程度"],
            rows=[
                [
                    b.get("id") or b.get("issue_id"),
                    b.get("title") or b.get("name"),
                    b.get("state") or b.get("status"),
                    b.get("createUser") or b.get("creator"),
                    b.get("currentOwner") or b.get("handler"),
                    b.get("priority"),
                    b.get("severity"),
                ]
                for b in bug_list
            ],
            no_truncate_headers=["缺陷ID", "标题"],
        )
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


def _flatten_issue_detail_for_table(detail):
    """将详情接口返回的 data 展平为 {字段: 显示值}，供 human 表格使用。"""
    if not isinstance(detail, dict):
        return {}

    def _unwrap_value(v):
        if not isinstance(v, dict):
            return v
        for key in ("value", "label", "name", "displayName", "text", "title"):
            if key in v and v.get(key) not in (None, ""):
                return v.get(key)
        return json.dumps(v, ensure_ascii=False)

    rows = {}
    prop = detail.get("property")
    if isinstance(prop, dict):
        for k, v in prop.items():
            rows[k] = _unwrap_value(v)

    for k, v in detail.items():
        if k == "property":
            continue
        if k in rows:
            continue
        if isinstance(v, (dict, list)):
            rows[k] = json.dumps(v, ensure_ascii=False) if v else ""
        else:
            rows[k] = v

    return rows


@bug.command("detail")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--bug-id", "-i", required=True, help="缺陷 ID（与列表「缺陷ID」、详情页 URL 中 id 一致）")
@click.pass_context
def get_bug_detail(ctx, project, bug_id):
    """查询单个缺陷详情"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project", err=True)
        raise click.Abort()

    api = DevOpsAPI(project_id)
    try:
        payload = api.get_bug(bug_id)
        data = payload.get("data") if isinstance(payload, dict) else None

        if ctx.obj.get("output_format") == "json":
            out = data if data is not None else payload
            click.echo(json.dumps(out, ensure_ascii=False, indent=2, default=str))
            return

        if data is None:
            msg = _extract_api_message(payload) if isinstance(payload, dict) else ""
            click.echo(msg or "未返回详情数据", err=True)
            return

        flat = _flatten_issue_detail_for_table(data)
        if not flat:
            click.echo(json.dumps(data, ensure_ascii=False, indent=2, default=str))
            return

        keys = sorted(flat.keys(), key=lambda x: (str(x).lower(), str(x)))
        render_table(
            headers=["字段", "值"],
            rows=[[k, flat[k]] for k in keys],
            no_truncate_headers=["字段", "值"],
        )
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@bug.command("get-states")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option(
    "--all/--no-all",
    "all_options",
    default=True,
    show_default=True,
    help="是否返回全部状态选项（与页面 all 参数一致）",
)
@click.pass_context
def list_bug_states(ctx, project, all_options):
    """查询缺陷「状态」（BUG 状态下拉）"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        payload = api.list_bug_state_options(all_options=all_options)
        options = payload.get("data", []) if isinstance(payload, dict) else []
        if not isinstance(options, list):
            options = []

        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    options,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return

        render_table(
            headers=["状态值", "状态名称"],
            rows=[
                [
                    s.get("id") or s.get("value"),
                    s.get("name") or s.get("label"),
                ]
                for s in options
            ],
            no_truncate_headers=["状态值", "状态名称"],
        )
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@bug.command("get-discovery-phases")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option(
    "--all/--no-all",
    "all_options",
    default=False,
    show_default=True,
    help="是否返回全部选项（与页面 all 参数一致；默认 false 与缺陷表 twBug 一致）",
)
@click.option(
    "--field-id",
    default=None,
    help="发现阶段字段 ID（项目模板不同时传入；默认与 create_bug / 页面抓包一致）",
)
@click.pass_context
def list_bug_discovery_phases(ctx, project, all_options, field_id):
    """查询缺陷「发现阶段」(BUG 发现阶段 字段)"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        payload = api.list_bug_discovery_phase_options(
            all_options=all_options,
            field_id=field_id,
        )
        options = payload.get("data", []) if isinstance(payload, dict) else []
        if not isinstance(options, list):
            options = []

        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    options,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return

        render_table(
            headers=["阶段值", "阶段名称"],
            rows=[
                [
                    s.get("id") or s.get("value"),
                    s.get("name") or s.get("label"),
                ]
                for s in options
            ],
            no_truncate_headers=["阶段值", "阶段名称"],
        )
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@bug.command("get-solution-methods")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option(
    "--all/--no-all",
    "all_options",
    default=False,
    show_default=True,
    help="是否返回全部选项（与页面 all 参数一致；默认 false 与缺陷表 twBug 一致）",
)
@click.option(
    "--field-id",
    default=None,
    help="解决方法字段 ID（项目模板不同时传入；默认与 create_bug / 页面抓包一致）",
)
@click.pass_context
def list_bug_solution_methods(ctx, project, all_options, field_id):
    """查询缺陷「解决方法」(BUG 解决方法 字段）"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        payload = api.list_bug_solution_method_options(
            all_options=all_options,
            field_id=field_id,
        )
        options = payload.get("data", []) if isinstance(payload, dict) else []
        if not isinstance(options, list):
            options = []

        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    options,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return

        render_table(
            headers=["方法值", "方法名称"],
            rows=[
                [
                    s.get("id") or s.get("value"),
                    s.get("name") or s.get("label"),
                ]
                for s in options
            ],
            no_truncate_headers=["方法值", "方法名称"],
        )
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@bug.command("get-types")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option(
    "--all/--no-all",
    "all_options",
    default=False,
    show_default=True,
    help="是否返回全部选项（与页面 all 参数一致；默认 false 与缺陷列表页一致）",
)
@click.option(
    "--field-id",
    default=None,
    help="缺陷类型字段 ID（项目模板不同时传入；默认与平台抓包一致）",
)
@click.pass_context
def list_bug_types(ctx, project, all_options, field_id):
    """查询缺陷「类型」（BUG 类型下拉）"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    try:
        payload = api.list_bug_defect_type_options(
            all_options=all_options,
            field_id=field_id,
        )
        options = payload.get("data", []) if isinstance(payload, dict) else []
        if not isinstance(options, list):
            options = []

        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    options,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return

        render_table(
            headers=["类型值", "类型名称"],
            rows=[
                [
                    s.get("id") or s.get("value"),
                    s.get("name") or s.get("label"),
                ]
                for s in options
            ],
            no_truncate_headers=["类型值", "类型名称"],
        )
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@bug.command("create")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option("--zteam-project-id", required=True, help="ZTeam 项目 ID")
@click.option("--sprint-id", required=True, default="", show_default=True, help="迭代 id")
@click.option("--title", "-t", required=True, help="缺陷标题")
@click.option("--priority", default="CENTRAL", show_default=True, help="缺陷优先级")
@click.option("--desc-editor-type", default="RICHTEXT", show_default=True, help="缺陷描述编辑器类型")
@click.option("--desc", default="<h2><span style=\"font-size: 16px;\">【前置条件】</span></h2>\n"
                                "<h2><span style=\"font-size: 16px;\">【操作步骤】</span></h2>\n"
                                "<h2><span style=\"font-size: 16px;\">【实际结果】</span></h2>\n"
                                "<h2><span style=\"font-size: 16px;\">【预期结果】</span></h2>", show_default=True,
              help="缺陷描述（支持 HTML")
@click.option("--severity", required=True, default="", show_default=True, help="缺陷严重程度")
@click.option("--type", required=True, default="", show_default=True, help="缺陷分类")
@click.option("--discovery-phase", required=True, default="", show_default=True, help="缺陷发现阶段")
@click.option("--solution-method", required=False, default="", show_default=True, help="缺陷解决方法")
@click.option("--owner", default="", show_default=True, help="缺陷负责人")
@click.option("--parent-id", default="", show_default=True, help="父缺陷 ID")
@click.option("--model-type-id", default="808fb2fd3da74f1da4c772712e10c665", show_default=True, help="缺陷模型 ID")
@click.option("--demand-classify", default="-1", show_default=True, help="需求分类")
@click.pass_context
def create_bug(
        ctx,
        project,
        zteam_project_id,
        sprint_id,
        title,
        priority,
        desc_editor_type,
        desc,
        severity,
        type,
        discovery_phase,
        solution_method,
        owner,
        parent_id,
        model_type_id,
        demand_classify
):
    """创建缺陷"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()

    # 基础字段沿用页面创建缺陷抓包；其余字段可通过 --field 传入
    instance_values = [
        {"fieldId": "684f26d36cd747f68dde32104a701956", "value": sprint_id},  # 迭代
        {"fieldId": "5abdcb4c783e11edbef4fa819a160800", "value": zteam_project_id},  # ZTeam 项目
        {"fieldId": "456e808faf85419b912535da923b7f22", "value": owner},  # 经办人
        {"fieldId": "f05cf2f5dc614dbaa05a13894abb5683", "value": severity},  # 严重程度
        {"fieldId": "f672b38532614f428828d9a68a514e24", "value": type},  # 缺陷类型
        {"fieldId": "bcee87c140d3475496a2a31c236631f4", "value": discovery_phase},  # 发现阶段
        {"fieldId": "8756c5b483434c2bb54bd6bc6586b09b", "value": solution_method},  # 解决方法
        {"fieldId": "3cd53ac875944b599f5e70e035327d42", "value": owner},  # 缺陷责任人
    ]

    api = DevOpsAPI(project_id)
    try:
        result = api.create_bug(
            title=title,
            model_type_id=model_type_id,
            priority=priority,
            editor_type=desc_editor_type,
            desc=desc,
            parent_id=parent_id,
            demand_classify=demand_classify,
            instance_values=instance_values,
        )
        _print_action_result(
            ctx,
            result,
            fail_prefix="创建失败",
            success_checker=lambda payload: bool(
                payload.get("data", {}).get("id")
            ) if isinstance(payload, dict) else False,
            success_text_builder=lambda payload: f"创建成功! 缺陷 ID: {payload.get('data', {}).get('id')}",
        )
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


def _bug_direction_operators_list(operator: str) -> Optional[list[str]]:
    """将 --operator（逗号分隔）解析为 API 所需的 operators 列表。"""
    raw = (operator or "").strip()
    if not raw:
        return None
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    return parts or None


def _bug_direction_go(ctx, project, bug_id, target_key, comment, operators):
    """缺陷工作流 POST issue_direction/.../next 的共用逻辑。"""
    project_id = project or ctx.obj.get("project") or config.default_project
    if not project_id:
        click.echo(
            "错误: 请传 -p/--project，或在根命令指定 --project，或在 config 中设置 default_project",
            err=True,
        )
        raise click.Abort()

    op_list = _bug_direction_operators_list(operators)
    if not op_list:
        click.echo("错误: --operator 不能为空（多个账号用英文逗号分隔）", err=True)
        raise click.Abort()

    next_node_id = BUG_DIRECTION_NEXT_NODE_IDS.get(target_key)
    if not next_node_id:
        click.echo(
            f"错误: 未配置动作 {target_key!r} 的 nextNodeId，请在 api.BUG_DIRECTION_NEXT_NODE_IDS 中维护",
            err=True,
        )
        raise click.Abort()

    api = DevOpsAPI(project_id)
    try:
        result = api.bug_direction_next(
            issue_id=bug_id,
            next_node_id=next_node_id,
            operators=op_list,
            comment=comment,
        )
        _print_action_result(ctx, result, "流转请求已提交", "流转失败")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


def _bug_direction_options(cmd):
    cmd = click.option(
        "-i",
        "--bug-id",
        required=True,
        help="缺陷 ID",
    )(cmd)

    cmd = click.option(
        "-p",
        "--project",
        required=True,
        help="项目 ID（可省略：使用根命令 -p 或 config 中 default_project）",
    )(cmd)

    """缺陷流转：project / bug-id / operator 由选项传入。"""
    cmd = click.option(
        "--operator",
        required=True,
        help="经办人账号，多个用英文逗号分隔",
    )(cmd)

    cmd = click.option(
        "--comment",
        default="",
        show_default=True,
        help="流转备注（富文本，可直接传 HTML，如 <p>说明</p>）",
    )(cmd)

    return cmd


@bug.command("accept")
@_bug_direction_options
@click.pass_context
def bug_accept(ctx, bug_id, project, comment, operator):
    """接受缺陷"""
    _bug_direction_go(
        ctx, project, bug_id, "accept", comment, operator
    )


@bug.command("resolve")
@_bug_direction_options
@click.pass_context
def bug_resolve(ctx, bug_id, project, comment, operator):
    """将缺陷标记为已解决"""
    _bug_direction_go(
        ctx, project, bug_id, "resolved", comment, operator
    )


@bug.command("verify")
@_bug_direction_options
@click.pass_context
def bug_verify(ctx, bug_id, project, comment, operator):
    """将缺陷标记为已验证"""
    _bug_direction_go(
        ctx, project, bug_id, "verified", comment, operator
    )


@bug.command("close")
@_bug_direction_options
@click.pass_context
def bug_close(ctx, bug_id, project, comment, operator):
    """关闭缺陷"""
    _bug_direction_go(
        ctx, project, bug_id, "close", comment, operator
    )


@bug.command("reopen")
@_bug_direction_options
@click.pass_context
def bug_reopen(ctx, bug_id, project, comment, operator):
    """重新打开缺陷"""
    _bug_direction_go(
        ctx, project, bug_id, "reopen", comment, operator
    )


@bug.command("reject")
@_bug_direction_options
@click.pass_context
def bug_reject(ctx, bug_id, project, comment, operator):
    """拒绝缺陷"""
    _bug_direction_go(
        ctx, project, bug_id, "reject", comment, operator
    )


@bug.command("delete")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option("--bug-id", "-i", required=True, help="缺陷 ID")
@click.option("--yes", "-y", is_flag=True, help="跳过删除确认")
@click.pass_context
def bug_delete(ctx, project, bug_id, yes):
    """删除缺陷"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project", err=True)
        raise click.Abort()

    if not yes and not click.confirm(f"确认删除缺陷 {bug_id} ?"):
        return

    api = DevOpsAPI(project_id)
    try:
        result = api.delete_issue(bug_id)
        _print_action_result(ctx, result, "删除成功", "删除失败")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@task.command("create")
@click.option("--project", "-p", required=True, help="项目 ID")
@click.option("--title", "-t", required=True, help="任务标题")
@click.option("--model-type-id", default="4ba3d2994e6b456da3ddc43e94ad5c70", show_default=True, help="任务模型 ID")
@click.option("--priority", default="CENTRAL", show_default=True, help="优先级")
@click.option("--editor-type", default="MARKDOWN", show_default=True, help="编辑器类型")
@click.option("--desc", default="", show_default=True, help="任务描述")
@click.option("--parent-id", default="", show_default=True, help="父任务 ID")
@click.option("--demand-classify", default="-1", show_default=True, help="需求分类")
@click.option("--owner", required=True, help="负责人账号，例如 zt07905")
@click.option("--estimate-start", required=True, help="预计开始日期 (YYYY-MM-DD)")
@click.option("--estimate-end", required=True, help="预计结束日期 (YYYY-MM-DD)")
@click.option("--origin-hours", default="8.00", show_default=True, help="原始工时")
@click.option("--remain-hours", default="8.00", show_default=True, help="剩余工时")
@click.option("--zteam-project-id", required=True, default="", show_default=True, help="Zteam项目id")
@click.option("--field", "custom_fields", multiple=True, help="自定义字段，格式: fieldId=value，可重复")
@click.pass_context
def create_task(
        ctx,
        project,
        title,
        model_type_id,
        priority,
        editor_type,
        desc,
        parent_id,
        demand_classify,
        owner,
        estimate_start,
        estimate_end,
        origin_hours,
        remain_hours,
        zteam_project_id,
        custom_fields,
):
    """创建任务（TASK）"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()

    # 与浏览器抓包参数保持一致，便于直接复现页面创建行为
    instance_values = [
        {"fieldId": "456e808faf85419b912535da923b7f22", "value": owner},
        {"fieldId": "684f26d36cd747f68dde32104a701956", "value": ""},
        {"fieldId": "a84b922da3054d08bfee798f7162a0c6", "value": ""},
        {"fieldId": "0cae6c6cbfb64b52a33beec849dd7a78", "value": ""},
        {"fieldId": "80d66115a46946a08a3cebf542df6339", "value": estimate_start},
        {"fieldId": "43bc2b003ee445c999fc948005238658", "value": estimate_end},
        {"fieldId": "753aefd914cb403685edcb6fc79d5de2", "value": ""},
        {"fieldId": "4d24b8fe8c41406f9a0ed023aac0f954", "value": origin_hours},
        {"fieldId": "b70df6a5c2ba4a5f96b41416949df209", "value": remain_hours},
        {"fieldId": "5abdcb4c783e11edbef4fa819a160800", "value": zteam_project_id},
    ]
    instance_values.extend(_parse_custom_fields(custom_fields))

    api = DevOpsAPI(project_id)
    try:
        result = api.create_task(
            title=title,
            model_type_id=model_type_id,
            priority=priority,
            editor_type=editor_type,
            desc=desc,
            parent_id=parent_id,
            demand_classify=demand_classify,
            instance_values=instance_values,
        )
        _print_action_result(
            ctx,
            result,
            fail_prefix="创建失败",
            success_checker=lambda payload: bool(
                payload.get("data", {}).get("id")
            ) if isinstance(payload, dict) else False,
            success_text_builder=lambda payload: f"创建成功! 任务 ID: {payload.get('data', {}).get('id')}",
        )

    except Exception as e:
        click.echo(f"错误: {e}", err=True)


def main():
    cli()


if __name__ == "__main__":
    main()
