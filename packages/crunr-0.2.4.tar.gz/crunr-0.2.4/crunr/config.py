"""Instance profiles, constants, and static configuration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

RUNR_DIR = "~/.crunr"
JOBS_FILE = "~/.crunr/jobs.json"
KEY_NAME = "crunr-key"
KEY_FILE = "~/.crunr/crunr-key.pem"
SG_NAME = "crunr-sg"
SG_DESCRIPTION = "crunr - SSH access for ephemeral job instances"
REMOTE_WORKSPACE = "~/crunr-workspace"

# ---------------------------------------------------------------------------
# SSH / rsync
# ---------------------------------------------------------------------------

SSH_TIMEOUT = 10  # seconds per connection attempt
SSH_POLL_INTERVAL = 3  # seconds between :22 retries
SSH_MAX_WAIT = 300  # seconds before giving up on SSH

CLOUD_INIT_TIMEOUT = 300  # seconds to wait for cloud-init done

RSYNC_EXCLUDES = [
    ".git",
    "__pycache__",
    "*.pyc",
    "*.pyo",
    ".venv",
    "venv",
    "env",
    ".env",
    "node_modules",
    ".DS_Store",
    "*.egg-info",
    "dist",
    "build",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".tox",
    "*.log",
    ".idea",
    ".vscode",
]

# Tried in order until one succeeds
CANDIDATE_SSH_USERS = ["ec2-user", "ubuntu", "admin", "centos", "rocky", "al2023-user"]

# ---------------------------------------------------------------------------
# Polling
# ---------------------------------------------------------------------------

INSTANCE_POLL_INTERVAL = 5   # seconds between DescribeInstances calls
INSTANCE_MAX_WAIT = 300      # seconds before giving up on instance start

# ---------------------------------------------------------------------------
# Instance profiles
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InstanceProfile:
    instance_type: str
    vcpus: int
    ram_gb: float
    gpu: bool
    gpu_count: int
    gpu_memory_gb: float  # per card


# CPU-only candidates (ordered cheapest-first for spot selection fallback)
CPU_CANDIDATES: list[InstanceProfile] = [
    InstanceProfile("t3.nano",     2,   0.5,  False, 0, 0),
    InstanceProfile("t3.micro",    2,   1.0,  False, 0, 0),
    InstanceProfile("t3.small",    2,   2.0,  False, 0, 0),
    InstanceProfile("t3.medium",   2,   4.0,  False, 0, 0),
    InstanceProfile("t3.large",    2,   8.0,  False, 0, 0),
    InstanceProfile("t3.xlarge",   4,  16.0,  False, 0, 0),
    InstanceProfile("t3.2xlarge",  8,  32.0,  False, 0, 0),
    InstanceProfile("c5.xlarge",   4,   8.0,  False, 0, 0),
    InstanceProfile("c5.2xlarge",  8,  16.0,  False, 0, 0),
    InstanceProfile("c5.4xlarge", 16,  32.0,  False, 0, 0),
    InstanceProfile("c5.9xlarge", 36,  72.0,  False, 0, 0),
    InstanceProfile("m5.xlarge",   4,  16.0,  False, 0, 0),
    InstanceProfile("m5.2xlarge",  8,  32.0,  False, 0, 0),
    InstanceProfile("m5.4xlarge", 16,  64.0,  False, 0, 0),
    InstanceProfile("r5.xlarge",   4,  32.0,  False, 0, 0),
    InstanceProfile("r5.2xlarge",  8,  64.0,  False, 0, 0),
    InstanceProfile("r5.4xlarge", 16, 128.0,  False, 0, 0),
]

# GPU candidates (ordered cheapest-first by approximate spot price)
GPU_CANDIDATES: list[InstanceProfile] = [
    InstanceProfile("g4dn.xlarge",   4,   16.0, True, 1,  16.0),  # T4
    InstanceProfile("g4dn.2xlarge",  8,   32.0, True, 1,  16.0),  # T4
    InstanceProfile("g4dn.4xlarge", 16,   64.0, True, 1,  16.0),  # T4
    InstanceProfile("g4dn.8xlarge", 32,  128.0, True, 1,  16.0),  # T4
    InstanceProfile("g4dn.12xlarge",48,  192.0, True, 4,  16.0),  # 4×T4
    InstanceProfile("g5.xlarge",     4,   16.0, True, 1,  24.0),  # A10G
    InstanceProfile("g5.2xlarge",    8,   32.0, True, 1,  24.0),  # A10G
    InstanceProfile("g5.4xlarge",   16,   64.0, True, 1,  24.0),  # A10G
    InstanceProfile("g5.12xlarge",  48,  192.0, True, 4,  24.0),  # 4×A10G
    InstanceProfile("g5.48xlarge",  192, 768.0, True, 8,  24.0),  # 8×A10G
    InstanceProfile("p3.2xlarge",    8,   61.0, True, 1,  16.0),  # V100
    InstanceProfile("p3.8xlarge",   32,  244.0, True, 4,  16.0),  # 4×V100
    InstanceProfile("p3.16xlarge",  64,  488.0, True, 8,  16.0),  # 8×V100
    InstanceProfile("p4d.24xlarge", 96, 1152.0, True, 8,  40.0),  # 8×A100-40GB
    InstanceProfile("p4de.24xlarge",96, 1152.0, True, 8,  80.0),  # 8×A100-80GB
]

# Map instance_type → InstanceProfile for O(1) lookup
_CPU_MAP: dict[str, InstanceProfile] = {p.instance_type: p for p in CPU_CANDIDATES}
_GPU_MAP: dict[str, InstanceProfile] = {p.instance_type: p for p in GPU_CANDIDATES}
ALL_PROFILES: dict[str, InstanceProfile] = {**_CPU_MAP, **_GPU_MAP}


def get_profile(instance_type: str) -> Optional[InstanceProfile]:
    return ALL_PROFILES.get(instance_type)


# ---------------------------------------------------------------------------
# AWS Regions with friendly names
# ---------------------------------------------------------------------------

REGIONS: list[tuple[str, str]] = [
    ("us-east-1",      "US East (N. Virginia)"),
    ("us-east-2",      "US East (Ohio)"),
    ("us-west-1",      "US West (N. California)"),
    ("us-west-2",      "US West (Oregon)"),
    ("eu-west-1",      "EU (Ireland)"),
    ("eu-west-2",      "EU (London)"),
    ("eu-west-3",      "EU (Paris)"),
    ("eu-central-1",   "EU (Frankfurt)"),
    ("eu-north-1",     "EU (Stockholm)"),
    ("ap-southeast-1", "Asia Pacific (Singapore)"),
    ("ap-southeast-2", "Asia Pacific (Sydney)"),
    ("ap-northeast-1", "Asia Pacific (Tokyo)"),
    ("ap-northeast-2", "Asia Pacific (Seoul)"),
    ("ap-south-1",     "Asia Pacific (Mumbai)"),
    ("ca-central-1",   "Canada (Central)"),
    ("sa-east-1",      "South America (São Paulo)"),
    ("me-south-1",     "Middle East (Bahrain)"),
    ("af-south-1",     "Africa (Cape Town)"),
]

# ---------------------------------------------------------------------------
# S3 defaults
# ---------------------------------------------------------------------------

S3_DEFAULT_PREFIX = "crunr-jobs"

# ---------------------------------------------------------------------------
# EBS disk defaults
# ---------------------------------------------------------------------------

# gp3 is cheaper than gp2 and has better baseline performance
EBS_VOLUME_TYPE = "gp3"

# Minimum sensible disk size per job type.
# Deep Learning AMIs ship with ~75 GB of pre-installed CUDA/frameworks, so the
# root volume must be at least that large even before your data lands on it.
MIN_DISK_GB_CPU = 8
MIN_DISK_GB_GPU = 150   # DL AMI snapshot is ~95 GB; 150 gives ~55 GB free for packages/data

# ---------------------------------------------------------------------------
# AMI search patterns
# ---------------------------------------------------------------------------

# Owner for standard Amazon Linux AMIs
AMAZON_OWNER_ID = "137112412989"

# Deep Learning AMIs are published under a separate AWS account
DL_AMI_OWNER_ID = "898082745236"

# Deep Learning AMI patterns (checked in order; first match wins)
DL_AMI_FILTERS = [
    # AL2023 DL AMI (newest)
    {
        "Name": "name",
        "Values": ["Deep Learning OSS Nvidia Driver AMI GPU PyTorch * (Amazon Linux 2023) *"],
    },
    # AL2 DL AMI fallback
    {
        "Name": "name",
        "Values": ["Deep Learning AMI GPU PyTorch * (Amazon Linux 2) *"],
    },
]

# Plain Amazon Linux 2023 for CPU jobs
AL2023_AMI_FILTER = {
    "Name": "name",
    "Values": ["al2023-ami-2023*-x86_64"],
}
