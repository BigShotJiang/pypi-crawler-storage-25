from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.geoteknisk_unders import GeotekniskUnders
from ...types import UNSET, Response, Unset


def _get_kwargs(
    geoteknisk_unders_id: str,
    *,
    include_har_dokument: bool | Unset = UNSET,
    include_har_tolkning: bool | Unset = UNSET,
    include_har_unders_ø_kelse: bool | Unset = UNSET,
    include_metode: bool | Unset = UNSET,
    versjon_id: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["includeHarDokument"] = include_har_dokument

    params["includeHarTolkning"] = include_har_tolkning

    params["includeHarUndersøkelse"] = include_har_unders_ø_kelse

    params["includeMetode"] = include_metode

    params["versjonId"] = versjon_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/nadag/innmelding/v1/validation/GeotekniskUnders/{geoteknisk_unders_id}".format(
            geoteknisk_unders_id=quote(str(geoteknisk_unders_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | GeotekniskUnders | None:
    if response.status_code == 200:
        response_200 = GeotekniskUnders.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | GeotekniskUnders]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    geoteknisk_unders_id: str,
    *,
    client: AuthenticatedClient | Client,
    include_har_dokument: bool | Unset = UNSET,
    include_har_tolkning: bool | Unset = UNSET,
    include_har_unders_ø_kelse: bool | Unset = UNSET,
    include_metode: bool | Unset = UNSET,
    versjon_id: int | Unset = UNSET,
) -> Response[Any | GeotekniskUnders]:
    """Fetches the latest GeotekniskUnders given the lokalId.

     Fetches a GeotekniskUnders by id.

    Args:
        geoteknisk_unders_id (str):
        include_har_dokument (bool | Unset):
        include_har_tolkning (bool | Unset):
        include_har_unders_ø_kelse (bool | Unset):
        include_metode (bool | Unset):
        versjon_id (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | GeotekniskUnders]
    """

    kwargs = _get_kwargs(
        geoteknisk_unders_id=geoteknisk_unders_id,
        include_har_dokument=include_har_dokument,
        include_har_tolkning=include_har_tolkning,
        include_har_unders_ø_kelse=include_har_unders_ø_kelse,
        include_metode=include_metode,
        versjon_id=versjon_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    geoteknisk_unders_id: str,
    *,
    client: AuthenticatedClient | Client,
    include_har_dokument: bool | Unset = UNSET,
    include_har_tolkning: bool | Unset = UNSET,
    include_har_unders_ø_kelse: bool | Unset = UNSET,
    include_metode: bool | Unset = UNSET,
    versjon_id: int | Unset = UNSET,
) -> Any | GeotekniskUnders | None:
    """Fetches the latest GeotekniskUnders given the lokalId.

     Fetches a GeotekniskUnders by id.

    Args:
        geoteknisk_unders_id (str):
        include_har_dokument (bool | Unset):
        include_har_tolkning (bool | Unset):
        include_har_unders_ø_kelse (bool | Unset):
        include_metode (bool | Unset):
        versjon_id (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | GeotekniskUnders
    """

    return sync_detailed(
        geoteknisk_unders_id=geoteknisk_unders_id,
        client=client,
        include_har_dokument=include_har_dokument,
        include_har_tolkning=include_har_tolkning,
        include_har_unders_ø_kelse=include_har_unders_ø_kelse,
        include_metode=include_metode,
        versjon_id=versjon_id,
    ).parsed


async def asyncio_detailed(
    geoteknisk_unders_id: str,
    *,
    client: AuthenticatedClient | Client,
    include_har_dokument: bool | Unset = UNSET,
    include_har_tolkning: bool | Unset = UNSET,
    include_har_unders_ø_kelse: bool | Unset = UNSET,
    include_metode: bool | Unset = UNSET,
    versjon_id: int | Unset = UNSET,
) -> Response[Any | GeotekniskUnders]:
    """Fetches the latest GeotekniskUnders given the lokalId.

     Fetches a GeotekniskUnders by id.

    Args:
        geoteknisk_unders_id (str):
        include_har_dokument (bool | Unset):
        include_har_tolkning (bool | Unset):
        include_har_unders_ø_kelse (bool | Unset):
        include_metode (bool | Unset):
        versjon_id (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | GeotekniskUnders]
    """

    kwargs = _get_kwargs(
        geoteknisk_unders_id=geoteknisk_unders_id,
        include_har_dokument=include_har_dokument,
        include_har_tolkning=include_har_tolkning,
        include_har_unders_ø_kelse=include_har_unders_ø_kelse,
        include_metode=include_metode,
        versjon_id=versjon_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    geoteknisk_unders_id: str,
    *,
    client: AuthenticatedClient | Client,
    include_har_dokument: bool | Unset = UNSET,
    include_har_tolkning: bool | Unset = UNSET,
    include_har_unders_ø_kelse: bool | Unset = UNSET,
    include_metode: bool | Unset = UNSET,
    versjon_id: int | Unset = UNSET,
) -> Any | GeotekniskUnders | None:
    """Fetches the latest GeotekniskUnders given the lokalId.

     Fetches a GeotekniskUnders by id.

    Args:
        geoteknisk_unders_id (str):
        include_har_dokument (bool | Unset):
        include_har_tolkning (bool | Unset):
        include_har_unders_ø_kelse (bool | Unset):
        include_metode (bool | Unset):
        versjon_id (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | GeotekniskUnders
    """

    return (
        await asyncio_detailed(
            geoteknisk_unders_id=geoteknisk_unders_id,
            client=client,
            include_har_dokument=include_har_dokument,
            include_har_tolkning=include_har_tolkning,
            include_har_unders_ø_kelse=include_har_unders_ø_kelse,
            include_metode=include_metode,
            versjon_id=versjon_id,
        )
    ).parsed
