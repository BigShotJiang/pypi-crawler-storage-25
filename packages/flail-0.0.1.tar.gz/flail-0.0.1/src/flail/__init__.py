"""flail — pre-release placeholder. Not yet functional."""

__version__ = "0.0.1"
__all__ = ["__version__"]
