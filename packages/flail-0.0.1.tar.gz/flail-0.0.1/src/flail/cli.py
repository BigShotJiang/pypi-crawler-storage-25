from __future__ import annotations

import sys

from . import __version__

_PLACEHOLDER_MESSAGE = (
    f"flail {__version__} is a pre-release placeholder and is not yet functional.\n"
    "Watch https://pypi.org/project/flail/ for the first real release."
)


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    if args and args[0] in {"-V", "--version"}:
        print(f"flail {__version__}")
        return 0
    print(_PLACEHOLDER_MESSAGE, file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
