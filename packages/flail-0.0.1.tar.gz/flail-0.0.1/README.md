# flail

**Status: pre-release placeholder.** This distribution reserves the `flail` name on PyPI while the project is prepared for its first functional release. Installing it today does not give you a working tool.

## What flail will be

A command-line utility. A full description and documentation will appear here with the first functional release (`0.1.0` or later).

## Installing now

You can install this placeholder, but `flail` will exit immediately with a message indicating it is not yet released:

```sh
pip install flail
flail
# flail is a pre-release placeholder and is not yet functional.
# Watch https://pypi.org/project/flail/ for the first real release.
```

## Why this exists

In line with PyPI policy (PEP 541), this package is a genuine pre-release of a project under active preparation, not a name reservation for resale or transfer. If you believe you have a stronger claim to the `flail` name, please open an issue or contact the maintainer.

## License

MIT — see [LICENSE](LICENSE).
