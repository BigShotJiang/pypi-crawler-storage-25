"""Workspace-specific tests against the live CData Connect AI environment."""

import os

import pytest
import cdata_connect_ai

from tests.integration_live.helpers import TABLE, WORKSPACE_TABLE

class TestWorkspace:

    def test_default_connection_has_no_workspace(self):       
        conn = cdata_connect_ai.connect(
            base_url=os.environ.get("CDATA_BASE_URL"),
            username=os.environ.get("CDATA_USERNAME"),
            password=os.environ.get("CDATA_PASSWORD"), 
            workspace=None
        )
        assert conn.workspace is None
        conn.close()

    def test_workspace_stored_on_connection(self):
        conn = cdata_connect_ai.connect(
            base_url=os.environ.get("CDATA_BASE_URL"),
            username=os.environ.get("CDATA_USERNAME"),
            password=os.environ.get("CDATA_PASSWORD"), 
            workspace="WorkspacePython"
        )
        assert conn.workspace == "WorkspacePython"
        conn.close()

    def test_no_workspace_url_has_no_query_param(self, cur):
       conn = cdata_connect_ai.connect(
            base_url=os.environ.get("CDATA_BASE_URL"),
            username=os.environ.get("CDATA_USERNAME"),
            password=os.environ.get("CDATA_PASSWORD")           
        )
       cur = conn.cursor()
       for endpoint in ("query", "batch", "exec"):
            url = cur._build_url(endpoint)
            assert "workspace" not in url, (
                f"Unexpected ?workspace= in {endpoint} URL: {url}"
            )
       cur.close()


    def test_workspace_select_returns_rows(self, cur):
        conn = cdata_connect_ai.connect(
            base_url=os.environ.get("CDATA_BASE_URL"),
            username=os.environ.get("CDATA_USERNAME"),
            password=os.environ.get("CDATA_PASSWORD"),
            workspace="WorkspacePython"         
        )
        cur = conn.cursor()
        cur.execute(f"SELECT id, first_name FROM {WORKSPACE_TABLE} LIMIT 5")
        rows = cur.fetchall()
        assert len(rows) > 0
        assert len(rows[0]) == 2
        assert cur.description is not None
        assert cur.description[0][0] == "id"
        assert cur.description[1][0] == "first_name"


    def test_workspace_connection_as_context_manager(self):
        url  = os.environ.get("CDATA_BASE_URL")
        user = os.environ.get("CDATA_USERNAME")
        pwd  = os.environ.get("CDATA_PASSWORD")

        with cdata_connect_ai.connect(
            base_url=url, username=user, password=pwd, workspace="WorkspacePython"
        ) as conn:
            assert conn.workspace == "WorkspacePython"
            c = conn.cursor()
            c.execute(f"SELECT COUNT(*) FROM {WORKSPACE_TABLE}")
            rows = c.fetchall()
            assert rows[0][0] > 0
            c.close()
        assert not conn.is_open
