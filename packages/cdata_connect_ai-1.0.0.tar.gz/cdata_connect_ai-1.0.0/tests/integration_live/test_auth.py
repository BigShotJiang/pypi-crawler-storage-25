"""Connection and Authentication tests against the live CData Connect AI environment."""

import os
import pytest
import cdata_connect_ai


class TestConnectionAndAuthentication:

    def test_auth_valid_credentials(self, live_con):
        assert live_con.is_open is True

    def test_auth_no_credentials_raises_interface_error(self):
        with pytest.raises(cdata_connect_ai.InterfaceError):
            cdata_connect_ai.connect()

    def test_auth_wrong_password_raises_on_execute(self):
        base_url = os.environ.get("CDATA_BASE_URL", "https://cloud.cdata.com/api")
        user = os.environ.get("CDATA_USERNAME", "")
        conn = cdata_connect_ai.connect(base_url=base_url, username=user, password="wrongpassword")     
        cur = conn.cursor()
        with pytest.raises(cdata_connect_ai.exceptions.OperationalError):
            cur.execute("SELECT 1")
        conn.close()  

    def test_auth_username_only_raises_config_error(self):
        base_url = os.environ.get("CDATA_BASE_URL", "https://cloud.cdata.com/api")
        with pytest.raises(cdata_connect_ai.exceptions.InterfaceError):
           cdata_connect_ai.connect(base_url=base_url)   

    def test_auth_username_only_raises_interface_error(self):
        base_url = os.environ.get("CDATA_BASE_URL", "https://cloud.cdata.com/api")
        with pytest.raises(cdata_connect_ai.InterfaceError):
            cdata_connect_ai.connect(base_url=base_url, username="user@x.com")

    def test_auth_missing_config_file_raises(self):
        with pytest.raises(cdata_connect_ai.ConfigurationError):
            cdata_connect_ai.connect(config_path="/nonexistent/path.conf")

    def test_auth_closed_connection_all_ops_raise(self):
        url  = os.environ.get("CDATA_BASE_URL", "https://cloud.cdata.com/api")
        user = os.environ.get("CDATA_USERNAME", "")
        pwd  = os.environ.get("CDATA_PASSWORD", "")
        conn = cdata_connect_ai.connect(base_url=url, username=user, password=pwd)
        conn.close()
        with pytest.raises(cdata_connect_ai.InterfaceError):
            conn.cursor()
        with pytest.raises(cdata_connect_ai.InterfaceError):
            conn.commit()
        with pytest.raises(cdata_connect_ai.InterfaceError):
            conn.rollback()
        with pytest.raises(cdata_connect_ai.InterfaceError):
            conn.close()

    def test_auth_context_manager_auto_close(self):
        url  = os.environ.get("CDATA_BASE_URL", "https://cloud.cdata.com/api")
        user = os.environ.get("CDATA_USERNAME", "")
        pwd  = os.environ.get("CDATA_PASSWORD", "")
        with cdata_connect_ai.connect(base_url=url, username=user, password=pwd) as conn:
            assert conn.is_open is True
        assert conn.is_open is False
        with pytest.raises(cdata_connect_ai.InterfaceError):
            conn.cursor()

    def test_auth_trailing_slash_stripped_from_base_url(self):
        url  = os.environ.get("CDATA_BASE_URL", "https://cloud.cdata.com/api")
        user = os.environ.get("CDATA_USERNAME", "")
        pwd  = os.environ.get("CDATA_PASSWORD", "")
        conn = cdata_connect_ai.connect(
            base_url=url.rstrip("/") + "/",
            username=user,
            password=pwd,
        )
        assert conn.base_url == url.rstrip("/")
        conn.close()

    def test_conn_auth_stores_tuple(self):
        url  = os.environ.get("CDATA_BASE_URL", "https://cloud.cdata.com/api")
        user = os.environ.get("CDATA_USERNAME", "")
        pwd  = os.environ.get("CDATA_PASSWORD", "")
        conn = cdata_connect_ai.connect(base_url=url, username=user, password=pwd)
        assert conn.auth == (user, pwd)
        conn.close()

    def test_auth_workspace_parameter_appended_to_url(self):
        url  = os.environ.get("CDATA_BASE_URL", "https://cloud.cdata.com/api")
        user = os.environ.get("CDATA_USERNAME", "")
        pwd  = os.environ.get("CDATA_PASSWORD", "")
        conn = cdata_connect_ai.connect(base_url=url, username=user, password=pwd, workspace="WorkspacePython")
        cur = conn.cursor()
        cur.execute("SELECT * FROM WorkspacePython.ROOT.users")
        rows = cur.fetchall()
        assert len(rows) >= 0
        conn.close()

    def test_auth_pyhocon_config_file(self, tmp_path):
        url  = os.environ.get("CDATA_BASE_URL", "https://cloud.cdata.com/api")
        user = os.environ.get("CDATA_USERNAME", "")
        pwd  = os.environ.get("CDATA_PASSWORD", "")
        config_content = f"""
cdata_api_db {{
  base_url = "{url}"
  username = "{user}"
  password = "{pwd}"
}}
"""
        config_file = tmp_path / "cdata.conf"
        config_file.write_text(config_content)
        conn = cdata_connect_ai.connect(config_path=str(config_file))
        cur = conn.cursor()
        cur.execute("SELECT * FROM [PostgreSQLPythonConnectorIntegrationTest].[public].[users]")
        rows = cur.fetchall()
        assert len(rows) >= 0
        conn.close()    
