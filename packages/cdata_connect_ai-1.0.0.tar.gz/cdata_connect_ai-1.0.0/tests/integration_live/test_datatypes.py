"""Datatypes tests against the live CData Connect AI environment.."""

import datetime
import uuid
from decimal import Decimal

import pytest

from tests.integration_live.helpers import DATATYPES_TABLE, TABLE

class TestDataTypeCoverage:

    def test_integer_types_return_python_int(self, cur):
        cur.execute(
            f"SELECT id, small_val, big_val "
            f"FROM {DATATYPES_TABLE}"
        )
        rows = cur.fetchall()
        for row in rows:
            if row[1] is not None:
                assert isinstance(row[1], int), f"small_val should be int, got {type(row[1])}"
            if row[2] is not None:
                assert isinstance(row[2], int), f"big_val should be int, got {type(row[2])}"


    def test_float_double_return_python_float(self, cur):
        cur.execute(f"SELECT float_val, double_val FROM {DATATYPES_TABLE}")
        rows = cur.fetchall()
        assert isinstance(rows[0][0], float)
        assert isinstance(rows[0][1], float)

    def test_boolean_returns_python_bool(self, cur):
        cur.execute(f"SELECT is_active FROM {DATATYPES_TABLE}")
        rows = cur.fetchall()
        assert rows[0][0] is True
        assert rows[1][0] is False
        assert isinstance(rows[0][0], bool)


    def test_timestamp_format_variations_parse_correctly(self, cur):
        cur.execute(f"SELECT created_at FROM {TABLE}")
        rows = cur.fetchall()
        for row in rows:
            if row[0] is not None:
                assert isinstance(row[0], datetime.datetime), f"created_at should be datetime, got {type(row[0])}"

    def test_binary_returns_bytearray(self, cur):
        cur.execute(f"SELECT binary_val FROM {DATATYPES_TABLE}")
        rows = cur.fetchall()
        for row in rows:
            if row[0] is not None:
                assert isinstance(row[0], bytearray), f"binary_val should be bytearray, got {type(row[0])}"

    def test_null_in_every_column_returns_none(self, cur):
        cur.execute(f"SELECT optional_val FROM {DATATYPES_TABLE} WHERE id = 1")
        rows = cur.fetchall()
        assert len(rows) == 1
        assert rows[0][0] is None
  

    def test_type_10_description_type_codes_correct(self, cur):
        cur.execute(f"SELECT * FROM {DATATYPES_TABLE}")
        rows = cur.fetchall()
        desc = cur.description
        assert desc[0][1] == 2  # id -> NUMBER
        assert desc[10][1] == 0  # binary_val → STRING (BINARY maps to STRING)
        assert desc[4][1] == 0  # text_val → STRING 
        assert desc[8][1] == 2  # is_active → NUMBER (BOOLEAN maps to NUMBER)
        # Verify null_ok field
        assert desc[0][6] is False  # id NOT NULL
        assert desc[1][6] is True  # small_val NOT NULL
