""" EDGE CASES AND BOUNDARY CONDITIONS TESTS
"""

import os

import pytest
import cdata_connect_ai

from tests.integration_live.helpers import TABLE, EMPLOYEES_TABLE

WORKSPACE = os.environ.get("LIVE_WORKSPACE", None)

class TestEdgeCasesAndBoundaryConditions:

    def test_sql_special_chars_escaped_single_quote(self, cur):
       
        cur.execute(
            f"SELECT * FROM {EMPLOYEES_TABLE} WHERE name = 'O''Brien Industries'"
        )
        rows = cur.fetchall()
        # May return 0 rows if not in test data — key is no SQL syntax error
        assert isinstance(rows, list)

    def test_unicode_chars_in_query_and_data(self, cur):
        cur.execute(
            f"SELECT * FROM {EMPLOYEES_TABLE} WHERE name = 'Société Générale'"
        )
        rows = cur.fetchall()
        assert isinstance(rows, list)

    def test_fetchmany_size_zero_returns_empty_list(self, cur):
        
        cur.execute(f"SELECT * FROM {TABLE}")
        rows = cur.fetchmany(0)
        assert rows == []
        # Cursor not exhausted
        next_row = cur.fetchone()
        assert next_row is not None

    def test_fetchmany_size_larger_than_result_set(self, cur):
        cur.execute(f"SELECT * FROM {TABLE}")  # 50 rows
        rows = cur.fetchmany(1000)
        assert len(rows) == 50

    def test_fetchall_twice_second_returns_empty(self, cur):
        cur.execute(f"SELECT * FROM {TABLE}")
        rows1 = cur.fetchall()
        rows2 = cur.fetchall()
        assert len(rows1) == 50
        assert rows2 == []

    def test_cursor_close_during_active_stream(self):       
        conn = cdata_connect_ai.connect(
            base_url=os.environ.get("CDATA_BASE_URL"),
            username=os.environ.get("CDATA_USERNAME"),
            password=os.environ.get("CDATA_PASSWORD"),
        ) 
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {TABLE}")  
        cur.fetchone()  # consume 1 row
        cur.close()    

        # Connection should still be usable
        cur2 = conn.cursor()
       
        cur2.execute(f"SELECT * FROM {TABLE}")
        rows = cur2.fetchall()
        assert len(rows) == 50
        conn.close()

    def test_cursor_as_context_manager_auto_closes(self):
        conn = cdata_connect_ai.connect(
            base_url=os.environ.get("CDATA_BASE_URL"),
            username=os.environ.get("CDATA_USERNAME"),
            password=os.environ.get("CDATA_PASSWORD"),
        ) 
        with conn.cursor() as cur:
            cur.execute(f"SELECT * FROM {TABLE}")
            rows = cur.fetchall()
            assert len(rows) == 50
        with pytest.raises(cdata_connect_ai.InterfaceError):
            cur.fetchone()
        conn.close()

    def test_exception_in_cursor_with_block_cursor_still_closed(self):
        conn = cdata_connect_ai.connect(
            base_url=os.environ.get("CDATA_BASE_URL"),
            username=os.environ.get("CDATA_USERNAME"),
            password=os.environ.get("CDATA_PASSWORD"),
        )  
        try:
            with conn.cursor() as cur:
                raise ValueError("deliberate error")
        except ValueError:
            pass
        with pytest.raises(cdata_connect_ai.InterfaceError):
            cur.fetchone()
        conn.close()

    def test_commit_and_rollback_are_noops(self):
        conn = cdata_connect_ai.connect(
            base_url=os.environ.get("CDATA_BASE_URL"),
            username=os.environ.get("CDATA_USERNAME"),
            password=os.environ.get("CDATA_PASSWORD"),
        )   
        conn.commit()    
        conn.rollback() 
        assert conn.is_open is True
        conn.close()

    def test_setinputsizes_setoutputsize_are_noops(self, cur):
        cur.setinputsizes((25,))
        cur.setoutputsize(1000)
        cur.setoutputsize(2000, 0)
        cur.execute(f"SELECT * FROM {TABLE}")
        rows = cur.fetchall()
        assert len(rows) == 50

    def test_module_level_dbapi_attributes(self):
        assert cdata_connect_ai.apilevel == "2.0"
        assert cdata_connect_ai.paramstyle == "pyformat"
        assert cdata_connect_ai.threadsafety in (0, 1, 2, 3)
        assert hasattr(cdata_connect_ai, "STRING")
        assert hasattr(cdata_connect_ai, "BINARY")
        assert hasattr(cdata_connect_ai, "NUMBER")
        assert hasattr(cdata_connect_ai, "DATETIME")
        assert hasattr(cdata_connect_ai, "ROWID")

    def test_exception_hierarchy(self):
        assert issubclass(cdata_connect_ai.Warning, Exception)
        assert issubclass(cdata_connect_ai.Error, Exception)
        assert issubclass(cdata_connect_ai.InterfaceError, cdata_connect_ai.Error)
        assert issubclass(cdata_connect_ai.DatabaseError, cdata_connect_ai.Error)
        assert issubclass(cdata_connect_ai.OperationalError, cdata_connect_ai.DatabaseError)
        assert issubclass(cdata_connect_ai.DataError, cdata_connect_ai.DatabaseError)
        assert issubclass(cdata_connect_ai.ProgrammingError, cdata_connect_ai.DatabaseError)
        assert issubclass(cdata_connect_ai.IntegrityError, cdata_connect_ai.DatabaseError)
        assert issubclass(cdata_connect_ai.InternalError, cdata_connect_ai.DatabaseError)
        assert issubclass(cdata_connect_ai.NotSupportedError, cdata_connect_ai.DatabaseError)


