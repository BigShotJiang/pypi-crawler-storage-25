"""Derived view tests against the live CData Connect AI environment."""

from tests.integration_live.helpers import TABLE, DERIVED_VIEW, make_email, insert_user, cleanup


class TestDerivedViews:

    def test_derived_view_select_returns_rows(self, cur):
        cur.execute(f"SELECT * FROM {DERIVED_VIEW} LIMIT 10")
        rows = cur.fetchall()
        assert len(rows) > 0

    def test_derived_view_description_populated(self, cur):
        cur.execute(f"SELECT * FROM {DERIVED_VIEW} LIMIT 1")
        cur.fetchall()
        assert cur.description is not None
        assert len(cur.description) > 0
        col_names = [d[0].lower() for d in cur.description]
        assert "id" in col_names
        assert "first_name" in col_names

    def test_derived_view_where_filter(self, cur):
        e = make_email("dvwhr")
        try:
            insert_user(cur, e, first_name="DerivedFilter", country="USA")
            cur.execute(f"SELECT first_name, email FROM {DERIVED_VIEW} WHERE email = '{e}'")
            rows = cur.fetchall()
            assert len(rows) == 1
            assert rows[0][0] == "DerivedFilter"
            assert rows[0][1] == e
        finally:
            cleanup(cur, e)

    def test_derived_view_count_returns_integer(self, cur):
        cur.execute(f"SELECT COUNT(*) FROM {DERIVED_VIEW}")
        rows = cur.fetchall()
        assert len(rows) == 1
        assert isinstance(rows[0][0], int)
        assert rows[0][0] > 0

    def test_derived_view_order_by_ascending(self, cur):
        cur.execute(f"SELECT id FROM {DERIVED_VIEW} ORDER BY id ASC LIMIT 10")
        ids = [r[0] for r in cur.fetchall()]
        assert len(ids) > 0
        assert ids == sorted(ids)

    def test_derived_view_limit_respected(self, cur):
        cur.execute(f"SELECT id FROM {DERIVED_VIEW} LIMIT 5")
        rows = cur.fetchall()
        assert len(rows) <= 5

    def test_derived_view_result_consistent_with_table(self, cur):
        cur.execute(f"SELECT COUNT(*) FROM {DERIVED_VIEW}")
        view_count = cur.fetchone()[0]

        cur.execute(f"SELECT COUNT(*) FROM {DERIVED_VIEW} WHERE is_active = TRUE")
        table_count = cur.fetchone()[0]

        assert view_count == table_count

    def test_derived_view_column_projection(self, cur):
        cur.execute(f"SELECT id, email FROM {DERIVED_VIEW} LIMIT 5")
        rows = cur.fetchall()
        assert len(rows) > 0
        assert len(rows[0]) == 2
        assert cur.description[0][0] == "id"
        assert cur.description[1][0] == "email"
