"""SELECT tests against the live CData Connect AI environment."""

from tests.integration_live.helpers import TABLE, EMPLOYEES_TABLE, cleanup, insert_user, make_email


class TestSelect:

    def test_select_full_table_scan(self, cur):   
        cur.execute(f"SELECT * FROM {TABLE}")
        rows = cur.fetchall()
        assert len(rows) == 50
        assert len(rows[0]) == 15
        assert cur.description is not None
        assert len(cur.description) == 15
        assert cur.description[0][0] == "id"
        assert cur.description[4][1] == 0  # Country → DBAPI_TYPE_STRING

    def test_select_returns_list(self, cur):
        cur.execute(f"SELECT id, first_name, last_name, email FROM {TABLE} LIMIT 5")
        rows = cur.fetchall()
        assert isinstance(rows, list)

    def test_description_exposes_column_metadata(self, cur):
        cur.execute(f"SELECT id, first_name, email, is_active FROM {TABLE} LIMIT 1")
        cur.fetchall()
        assert cur.description is not None
        col_names = [d[0].lower() for d in cur.description]
        for col in ("id", "first_name", "email", "is_active"):
            assert col in col_names, f"Expected column '{col}' in description"

    def test_select_with_where_filter(self, cur):
        e = make_email("selflt")
        try:
            insert_user(cur, e, first_name="FilterMe")
            cur.execute(f"SELECT first_name, email FROM {TABLE} WHERE email = '{e}'")
            rows = cur.fetchall()
            assert len(rows) == 1
            assert rows[0][0] == "FilterMe"
            assert rows[0][1] == e
        finally:
            cleanup(cur, e)

    def test_select_order_by_id_ascending(self, cur):
        cur.execute(f"SELECT id FROM {TABLE} ORDER BY id ASC LIMIT 10")
        ids = [r[0] for r in cur.fetchall()]
        assert ids == sorted(ids), "Rows should be in ascending id order"

    def test_select_order_by_id_descending(self, cur):
        cur.execute(f"SELECT id FROM {TABLE} ORDER BY id DESC LIMIT 10")
        ids = [r[0] for r in cur.fetchall()]
        assert ids == sorted(ids, reverse=True), "Rows should be in descending id order"

    def test_select_count_returns_integer(self, cur):
        cur.execute(f"SELECT COUNT(*) FROM {TABLE}")
        rows = cur.fetchall()
        assert len(rows) == 1
        assert isinstance(rows[0][0], int)
        assert rows[0][0] >= 0

    def test_fetchone_returns_single_row(self, cur):
        cur.execute(f"SELECT id, first_name FROM {TABLE} LIMIT 5")
        row = cur.fetchone()
        assert row is not None
        assert len(row) == 2

    def test_fetchmany_respects_size(self, cur):
        cur.execute(f"SELECT id FROM {TABLE} LIMIT 10")
        rows = cur.fetchmany(3)
        assert len(rows) <= 3

    def test_iterate_cursor(self, cur):
        e = make_email("selitr")
        try:
            insert_user(cur, e)
            cur.execute(f"SELECT email FROM {TABLE} WHERE email = '{e}'")
            collected = list(cur)
            assert any(r[0] == e for r in collected)
        finally:
            cleanup(cur, e)

    def test_select_column_projection(self, cur):       
        cur.execute(f"SELECT address, city FROM {TABLE}")
        rows = cur.fetchall()
        assert len(rows[0]) == 2
        assert cur.description[0][0] == "address"
        assert cur.description[1][0] == "city"   

    def test_select_where_numeric_comparison(self, cur):
      cur.execute(f"SELECT id, country FROM {TABLE} WHERE id > 49")
      rows = cur.fetchall()
      assert len(rows) == 1
      for row in rows:
          assert isinstance(row[0], (int, float)) or hasattr(row[0], "__float__")         

    def test_select_where_like_pattern(self, cur):       
        cur.execute(f"SELECT first_name FROM {TABLE} WHERE first_name LIKE '%ya%'")
        rows = cur.fetchall()
        assert len(rows) == 1
        names = [row[0] for row in rows]
        assert all("ya" in name for name in names)

    def test_select_where_in_clause(self, cur):       
        cur.execute(
            f"SELECT first_name, country FROM {TABLE} "
            "WHERE country IN ('USA', 'India')"
        )
        rows = cur.fetchall()
        allowed = {"USA", "India"}
        country_idx = next(i for i, d in enumerate(cur.description) if d[0] == "country")
        for row in rows:
            assert row[country_idx] in allowed

    def test_select_where_is_null_and_is_not_null(self, cur):
        
        cur.execute(f"SELECT first_name FROM {TABLE} WHERE country IS NULL")
        rows_null = cur.fetchall()
        # All returned rows should have no Industry — verified server-side

        cur.execute(f"SELECT first_name, country FROM {TABLE} WHERE country IS NOT NULL")
        rows_not_null = cur.fetchall()
        for row in rows_not_null:
            assert row[1] is not None        

    def test_select_group_by_with_having(self, cur):
        cur.execute(
            f"SELECT country, COUNT(*) as cnt FROM {TABLE} "
            "GROUP BY country HAVING COUNT(*) > 1"
        )
        rows = cur.fetchall()
        countries = [row[0] for row in rows]
        assert "USA" in countries
        assert len(countries) == len(set(countries))  # no duplicates

    def test_select_aggregate_functions(self, cur):
        cur.execute(
            f"SELECT COUNT(*), SUM(id), MIN(id), "
            f"MAX(id), AVG(id) FROM {TABLE}"
        )
        rows = cur.fetchall()
        assert len(rows) == 1
        count, total, minimum, maximum, average = rows[0]
        assert count == 50
        assert total == 1275
        assert minimum == 1
        assert maximum == 50
        assert minimum < average < maximum    

    def test_select_distinct(self, cur):
        cur.execute(f"SELECT DISTINCT country FROM {TABLE}")
        rows = cur.fetchall()
        countries = [row[0] for row in rows if row[0] is not None]
        assert len(countries) == len(set(countries))
        assert len(countries) == 12

    def test_select_empty_result_set(self, cur):
        cur.execute(f"SELECT * FROM {TABLE} WHERE country = 'NonExistentCountry'")
        rows = cur.fetchall()
        assert rows == []
        assert cur.description is not None
    
    def test_select_fetchone_fetchmany_fetchall_mixed(self, cur):
        cur.execute(f"SELECT * FROM {TABLE}")  # 50 rows
        r1 = cur.fetchone()
        r2_3 = cur.fetchmany(15)
        rest = cur.fetchall()
        empty = cur.fetchall()

        assert r1 is not None
        assert len(r2_3) == 15
        assert len(rest) == 34
        assert empty == []
        assert 1 + 15 + 34 == 50


    def test_full_sql_join_across_schemas(self, cur):
        cur.execute(f"""
            SELECT e.id, e.name, u.email, e.salary
            FROM {EMPLOYEES_TABLE} e
            JOIN {TABLE} u ON e.id = u.id
            WHERE u.gender='Male'
            ORDER BY u.created_at ASC
        """)
        rows = cur.fetchall()
        assert len(cur.description) == 4
        for row in rows:
            assert isinstance(row[0], int)
            assert isinstance(row[1], str)
            assert row[2] is not None
            assert isinstance(row[3], (int, float))


    def test_cte_common_table_expression(self, cur):
        cur.execute(f"""
            WITH high_value AS (
                SELECT id, salary
                FROM {EMPLOYEES_TABLE}
                GROUP BY id
                HAVING SUM(salary) > 50000
            )
            SELECT * FROM high_value ORDER BY salary DESC
        """)
        rows = cur.fetchall()
        for row in rows:
            assert row[1] > 50000  # SALARY > 50000

    def test_null_aggregation_count_star_vs_count_column(self, cur):
        cur.execute(f"""
            SELECT COUNT(*) AS all_rows,
                   COUNT(country) AS non_null_country
            FROM {TABLE}
        """)
        rows = cur.fetchall()
        all_rows, non_null_country = rows[0]
        assert all_rows >= non_null_country

