"""UPDATE tests against the live CData Connect AI environment."""

from tests.integration_live.helpers import TABLE, cleanup, insert_user, make_email


class TestUpdate:
    def test_update_single_field(self, cur):
        e = make_email("updsingle")
        try:
            insert_user(cur, e, city="OldCity")
            cur.executemany(
                f"UPDATE {TABLE} SET city = @city WHERE email = @em",
                [{"@city": "NewCity", "@em": e}],
            )
            cur.execute(f"SELECT city FROM {TABLE} WHERE email = '{e}'")
            assert cur.fetchone()[0] == "NewCity"
        finally:
            cleanup(cur, e)

    def test_update_multiple_fields(self, cur):
        e = make_email("updmulti")
        try:
            insert_user(cur, e, phone="+1-000-0000", occupation="Junior")
            cur.executemany(
                f"UPDATE {TABLE} SET phone = @ph, occupation = @oc WHERE email = @em",
                [{"@ph": "+1-999-9999", "@oc": "Senior", "@em": e}],
            )
            cur.execute(f"SELECT phone, occupation FROM {TABLE} WHERE email = '{e}'")
            row = cur.fetchone()
            assert row[0] == "+1-999-9999"
            assert row[1] == "Senior"
        finally:
            cleanup(cur, e)

    def test_update_boolean_field(self, cur):
        e = make_email("updbool")
        try:
            insert_user(cur, e)
            # Use inline literal FALSE; only parameterise the WHERE predicate.
            cur.executemany(
                f"UPDATE {TABLE} SET is_active = FALSE WHERE email = @em",
                [{"@em": e}],
            )
            cur.execute(f"SELECT is_active FROM {TABLE} WHERE email = '{e}'")
            assert cur.fetchone()[0] is False
        finally:
            cleanup(cur, e)

    def test_update_does_not_affect_other_rows(self, cur):
        email_a = make_email("updisoa")
        email_b = make_email("updisob")
        try:
            insert_user(cur, email_a, city="CityA")
            insert_user(cur, email_b, city="CityB")
            cur.executemany(
                f"UPDATE {TABLE} SET city = @city WHERE email = @em",
                [{"@city": "Updated", "@em": email_a}],
            )
            cur.execute(f"SELECT city FROM {TABLE} WHERE email = '{email_b}'")
            assert cur.fetchone()[0] == "CityB"
        finally:
            cleanup(cur, email_a, email_b)
