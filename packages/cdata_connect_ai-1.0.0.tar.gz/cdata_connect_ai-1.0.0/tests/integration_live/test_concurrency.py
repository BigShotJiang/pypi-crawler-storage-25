""" Concurrency tests for concurrency scenarios with cdata_connect_ai connector.
"""

import os
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

import cdata_connect_ai

USERS_TABLE = "[PostgreSQLPythonConnectorIntegrationTest].[public].[users]"
BASE_URL = os.environ.get("CDATA_BASE_URL", "https://cloud.cdata.com/api")
USERNAME = os.environ.get("CDATA_USERNAME", "")
PAT       = os.environ.get("CDATA_PASSWORD", "")

def connect(pat: str, **kwargs):
    return cdata_connect_ai.connect(
        base_url=BASE_URL,
        username=USERNAME,
        password=pat,
        **kwargs,
    )


class TestConcurrency:

    def test_conc_01_two_threads_independent_connections(self):
        results = {}
        errors = {}

        def worker(tid, pat, expected):
            try:
                conn = connect(pat)
                cur = conn.cursor()
                cur.execute(f"SELECT * FROM {USERS_TABLE}")
                results[tid] = len(cur.fetchall())
                conn.close()
            except Exception as e:
                errors[tid] = e

        t1 = threading.Thread(target=worker, args=(1, PAT, 100))
        t2 = threading.Thread(target=worker, args=(2, PAT, 1000))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        assert not errors, f"Thread errors: {errors}"
        assert results[1] == 50
        assert results[2] == 50

    def test_conc_02_ten_concurrent_threads_all_correct_row_counts(self):

        def fetch(_):
            conn = connect(PAT)
            cur = conn.cursor()
            cur.execute(f"SELECT * FROM {USERS_TABLE}")
            n = len(cur.fetchall())
            conn.close()
            return n

        with ThreadPoolExecutor(max_workers=10) as pool:
            futures = [pool.submit(fetch, i) for i in range(10)]
            for future in as_completed(futures):
                assert future.result() == 50

    def test_conc_03_same_connection_two_cursors_interleaved_fetch(self):
        conn = connect(PAT) 
        cur1 = conn.cursor()
        cur2 = conn.cursor()

        cur1.execute(f"SELECT * FROM {USERS_TABLE}")
        cur2.execute(f"SELECT * FROM {USERS_TABLE}")

        r1 = cur1.fetchone()   # from USERS_TABLE (15 columns)
        r2 = cur2.fetchone()   # from USERS_TABLE (15 columns)
        rest1 = cur1.fetchall()  # remaining USERS  _TABLE rows (49)
        rest2 = cur2.fetchall()  # remaining USERS_TABLE rows (49)

        assert len(r1) == 15         # USERS: 5 columns
        assert len(r2) == 15        # USERS: 5 columns (adjust if schema differs)
        assert len(rest1) == 49      # 50 total - 1 fetched
        assert len(rest2) == 49      # 50 total - 1 fetched

        conn.close()
