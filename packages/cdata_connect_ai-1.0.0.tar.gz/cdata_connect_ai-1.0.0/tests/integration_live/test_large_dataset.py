"""Large dataset tests (~1M rows) against the live CData Connect AI environment."""

from tests.integration_live.helpers import LARGE_TABLE

MIN_ROW_COUNT = 100_000


class TestLargeDataset:

    def test_count_returns_at_least_one_million_rows(self, cur):
        cur.execute(f"SELECT COUNT(*) FROM {LARGE_TABLE}")
        rows = cur.fetchall()
        assert len(rows) == 1
        assert isinstance(rows[0][0], int)
        assert rows[0][0] >= MIN_ROW_COUNT, (
            f"Expected >= {MIN_ROW_COUNT} rows, got {rows[0][0]}"
        )

    def test_limit_returns_exact_row_count(self, cur):
        cur.execute(f"SELECT * FROM {LARGE_TABLE} LIMIT 1000")
        rows = cur.fetchall()
        assert len(rows) == 1000

    def test_fetchmany_large_batch(self, cur):
        cur.execute(f"SELECT * FROM {LARGE_TABLE} LIMIT 10000")
        batch = cur.fetchmany(5000)
        assert len(batch) == 5000
        rest = cur.fetchmany(5000)
        assert len(rest) == 5000
        empty = cur.fetchmany(1)
        assert empty == []

    def test_streaming_fetchone_traverses_large_result(self, cur):
        cur.execute(f"SELECT * FROM {LARGE_TABLE} LIMIT 100000")
        count = 0
        while True:
            row = cur.fetchone()
            if row is None:
                break
            count += 1
        assert count == 100000

    def test_fetchall_large_result_set(self, cur):
        cur.execute(f"SELECT * FROM {LARGE_TABLE} LIMIT 100000")
        rows = cur.fetchall()
        assert len(rows) == 100000
        assert all(isinstance(row, list) for row in rows)

    def test_description_populated_on_large_table(self, cur):
        cur.execute(f"SELECT * FROM {LARGE_TABLE} LIMIT 1")
        cur.fetchall()
        assert cur.description is not None
        assert len(cur.description) > 0
        for col in cur.description:
            assert col[0] is not None  # column name present

    def test_aggregate_min_max_on_large_table(self, cur):
        cur.execute(f"SELECT MIN(id), MAX(id), COUNT(*) FROM {LARGE_TABLE}")
        rows = cur.fetchall()
        assert len(rows) == 1
        minimum, maximum, count = rows[0]
        assert minimum is not None
        assert maximum is not None
        assert maximum > minimum
        assert count >= MIN_ROW_COUNT

    def test_cursor_iterator_over_large_limit(self, cur):
        cur.execute(f"SELECT id FROM {LARGE_TABLE} LIMIT 50000")
        count = sum(1 for _ in cur)
        assert count == 50000

    def test_fetchall_twice_second_is_empty(self, cur):
        cur.execute(f"SELECT id FROM {LARGE_TABLE} LIMIT 10000")
        first = cur.fetchall()
        second = cur.fetchall()
        assert len(first) == 10000
        assert second == []
