"""DELETE tests against the live CData Connect AI environment."""

import os
import uuid
import pytest
import cdata_connect_ai

from tests.integration_live.helpers import TABLE, EMPLOYEES_TABLE, cleanup, cleanup_employee, company, insert_employee, insert_user, make_email


class TestDelete:
    def test_delete_removes_row(self, cur):
        e = make_email("del1")
        try:
            insert_user(cur, e)
            cur.executemany(
                f"DELETE FROM {TABLE} WHERE email = @em",
                [{"@em": e}],
            )
            cur.execute(f"SELECT id FROM {TABLE} WHERE email = '{e}'")
            assert cur.fetchall() == []
        finally:
            cleanup(cur, e)

    def test_delete_specific_row_only(self, cur):
        email_target = make_email("deltgt")
        email_keep   = make_email("delkeep")
        try:
            insert_user(cur, email_target)
            insert_user(cur, email_keep)
            cur.executemany(
                f"DELETE FROM {TABLE} WHERE email = @em",
                [{"@em": email_target}],
            )
            cur.execute(f"SELECT email FROM {TABLE} WHERE email = '{email_keep}'")
            assert len(cur.fetchall()) == 1, "Sibling row must survive the DELETE"
        finally:
            cleanup(cur, email_target, email_keep)

    def test_delete_multiple_rows_with_condition(self, cur):
        co     = company("delbatch")
        emails = [make_email(f"delbatch{i}") for i in range(3)]
        try:
            for e in emails:
                insert_user(cur, e, company=co)
            cur.executemany(
                f"DELETE FROM {TABLE} WHERE company = @co",
                [{"@co": co}],
            )
            for e in emails:
                cur.execute(f"SELECT id FROM {TABLE} WHERE email = '{e}'")
                assert cur.fetchall() == [], f"Row for {e} should have been deleted"
        finally:
            cleanup(cur, *emails)

    def test_fetchall_after_delete_raises_programming_error(self, cur):
        name = f"DelTest_{uuid.uuid4().hex[:8]}"
        try:
            insert_employee(cur, name)
            cur.executemany(
                f"DELETE FROM {EMPLOYEES_TABLE} WHERE name = @nm",
                [{"@nm": name}],
            )
            with pytest.raises(cdata_connect_ai.ProgrammingError):
                cur.fetchall()
        finally:            
            cleanup_employee(cur, name)
