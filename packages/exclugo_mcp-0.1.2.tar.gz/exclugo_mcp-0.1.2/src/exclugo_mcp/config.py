import os


class Config:
    base_url: str = os.environ.get("EXCLUGO_BASE_URL", "http://localhost:8000")
    api_token: str | None = os.environ.get("EXCLUGO_API_TOKEN")
    username: str | None = os.environ.get("EXCLUGO_USERNAME")
    password: str | None = os.environ.get("EXCLUGO_PASSWORD")


config = Config()
