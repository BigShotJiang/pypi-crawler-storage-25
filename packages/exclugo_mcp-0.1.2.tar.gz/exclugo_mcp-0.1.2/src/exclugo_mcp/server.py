from mcp.server.fastmcp import FastMCP

from .tools import (
    auth,
    facilities,
    employees,
    vendors,
    licenses,
    npis,
    reports,
    billing,
    calendar,
    users,
    uploads,
    monitoring,
    dashboard,
)

mcp = FastMCP(
    "exclugo",
    instructions=(
        "Exclugo MCP Server — healthcare compliance background screening platform. "
        "Use the authenticate tool first (or set EXCLUGO_API_TOKEN env var) before calling other tools. "
        "Tools are grouped by: facilities, employees, vendors, licenses, NPIs, reports, "
        "billing, calendar, users, uploads, monitoring, and dashboard."
    ),
)

# Register all tool modules
auth.register(mcp)
facilities.register(mcp)
employees.register(mcp)
vendors.register(mcp)
licenses.register(mcp)
npis.register(mcp)
reports.register(mcp)
billing.register(mcp)
calendar.register(mcp)
users.register(mcp)
uploads.register(mcp)
monitoring.register(mcp)
dashboard.register(mcp)


def main():
    mcp.run()


if __name__ == "__main__":
    main()
