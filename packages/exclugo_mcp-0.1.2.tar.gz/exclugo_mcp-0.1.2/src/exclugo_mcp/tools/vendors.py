from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_vendor_individual(
        facility: int,
        first_name: str,
        last_name: str,
        ein_ssn: str,
        dob: str = "",
        middle_name: str = "",
        address: str = "",
        city: str = "",
        state: str = "",
        zip: str = "",
        unique_vendor_id: str = "",
        reference: str = "",
        file_no: str = "",
    ) -> dict:
        """Create/order a new individual vendor for background screening.
        ein_ssn: the vendor's EIN or SSN."""
        data = {
            "facility": facility,
            "first_name": first_name,
            "last_name": last_name,
            "ein_ssn": ein_ssn,
            "dob": dob,
            "middle_name": middle_name,
            "address": address,
            "city": city,
            "state": state,
            "zip": zip,
            "unique_vendor_id": unique_vendor_id,
            "reference": reference,
            "file_no": file_no,
        }
        return await client.post("/api/individualorder/vendorindividual/", json=data)

    @mcp.tool()
    async def create_vendor_organization(
        facility: int,
        business_name: str,
        ein_ssn: str,
        address: str = "",
        city: str = "",
        state: str = "",
        zip: str = "",
        unique_vendor_id: str = "",
        reference: str = "",
        file_no: str = "",
    ) -> dict:
        """Create/order a new organization vendor for background screening."""
        data = {
            "facility": facility,
            "business_name": business_name,
            "ein_ssn": ein_ssn,
            "address": address,
            "city": city,
            "state": state,
            "zip": zip,
            "unique_vendor_id": unique_vendor_id,
            "reference": reference,
            "file_no": file_no,
        }
        return await client.post("/api/individualorder/vendororganization/", json=data)

    @mcp.tool()
    async def edit_vendor(vendor_id: int, updates: dict) -> dict:
        """Edit an existing vendor record. Pass a dict of fields to update."""
        return await client.put(f"/api/reports/edit/vendor/{vendor_id}/", json=updates)

    @mcp.tool()
    async def search_vendors(
        name: str = "",
        ein_ssn: str = "",
        facility_id: int | None = None,
    ) -> list | dict:
        """Search vendors by name, EIN/SSN, or facility."""
        params: dict = {}
        if name:
            params["name"] = name
        if ein_ssn:
            params["ein_ssn"] = ein_ssn
        if facility_id:
            params["facility"] = facility_id
        return await client.get("/api/admin/vendor/search/", params=params)
