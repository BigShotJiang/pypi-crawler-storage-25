from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def run_exclusion_matching(facility_id: int | None = None) -> dict:
        """Run exclusion list matching for all pending employees, or for a specific facility.
        This checks employees against OIG, SAM, state exclusion lists, etc."""
        if facility_id:
            return await client.post(f"/api/employeematching/{facility_id}/")
        return await client.post("/api/employeematching/")

    @mcp.tool()
    async def run_sex_offender_check() -> dict:
        """Run the daily sex offender registry check for all pending employees."""
        return await client.post("/api/socheck/")

    @mcp.tool()
    async def run_dmf_check() -> dict:
        """Run the daily Death Master File (DMF) check for all pending employees."""
        return await client.post("/api/dmfcheck/")

    @mcp.tool()
    async def run_npi_check() -> dict:
        """Run the daily NPI registry check for all pending NPI records."""
        return await client.post("/api/npicheck/")

    @mcp.tool()
    async def run_ssn_plus_exclusion_check() -> dict:
        """Run the SSN + exclusion combination check for all pending records."""
        return await client.post("/api/ssnplusexclusioncheck/")

    @mcp.tool()
    async def run_ssn_verification() -> dict:
        """Run SSN verification for pending employees."""
        return await client.post("/api/ssnverification/")
