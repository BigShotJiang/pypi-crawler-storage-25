from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def get_dashboard() -> dict:
        """Get the client dashboard summary: charts, alerts, monitoring counts, license expirations."""
        return await client.get("/api/client/dashboard/")

    @mcp.tool()
    async def get_client_report(report_num: str) -> dict:
        """Get a client-facing report by report number."""
        return await client.get(f"/api/client/clientreport/{report_num}/")

    @mcp.tool()
    async def update_alert(alert_type: str, alert_id: int, data: dict) -> dict:
        """Update/acknowledge a client alert. alert_type: 'exclusion', 'sexoffender', 'dmf', 'npi', 'license'.
        data: fields to update like {'acknowledged': true, 'dashboard_comments': '...'}."""
        return await client.put(f"/api/client/updatealert/{alert_type}/{alert_id}/", json=data)

    @mcp.tool()
    async def disable_monitoring(entity_type: str, entity_id: int) -> dict:
        """Disable monitoring for an entity (e.g. terminated employee).
        entity_type: 'employee', 'vendor', 'license', 'npi'."""
        return await client.put(f"/api/client/disablemonitoring/{entity_type}/{entity_id}/")
