from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def admin_upload(upload_choice: str, upload_obj: str, data: dict) -> dict:
        """Admin upload of employee/vendor/license/NPI lists.
        upload_choice: 'payrollupload' or 'addbulk'.
        upload_obj: 'employee', 'vendorindividual', 'vendororganization', 'license', 'npi'.
        data: upload payload with facility, records, etc."""
        return await client.post(f"/api/upload/{upload_choice}/{upload_obj}/", json=data)

    @mcp.tool()
    async def client_upload(upload_choice: str, upload_obj: str, data: dict) -> dict:
        """Client-side upload of employee/vendor/license/NPI lists.
        upload_choice: 'payrollupload' or 'addbulk'.
        upload_obj: 'employee', 'vendorindividual', 'vendororganization', 'license', 'npi'.
        data: upload payload with facility, records, etc."""
        return await client.post(f"/api/upload/client/{upload_choice}/{upload_obj}/", json=data)

    @mcp.tool()
    async def get_upload_logs(
        client_id: int | None = None,
        year: int | None = None,
        month: int | None = None,
    ) -> list | dict:
        """Get upload history logs. Optionally filter by client, year, and month."""
        if client_id and year and month:
            return await client.get(f"/api/uploadlogs/{client_id}/{year}/{month}/")
        return await client.get("/api/uploadlogs/")

    @mcp.tool()
    async def get_failed_records(upload_log_id: int) -> list | dict:
        """Get failed/errored records from an upload by upload log ID."""
        return await client.get(f"/api/failedrecords/{upload_log_id}/")

    @mcp.tool()
    async def resolve_failed_records(data: dict) -> dict:
        """Resolve failed upload records. data should contain the records to resolve."""
        return await client.post("/api/resolverecords/", json=data)
