from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def list_reports(status: str = "pending") -> list | dict:
        """List reports by status. status: 'pending', 'complete', 'expiring', etc."""
        return await client.get(f"/api/reports/{status}/")

    @mcp.tool()
    async def get_report(report_num: str) -> dict:
        """Get full details for a specific report by report number."""
        return await client.get(f"/api/admin/report/{report_num}/")

    @mcp.tool()
    async def get_report_searches(report_num: str) -> list | dict:
        """Get all searches (exclusion checks, license checks, etc.) for a report."""
        return await client.get(f"/api/admin/report/{report_num}/searches/")

    @mcp.tool()
    async def get_search_detail(search_id: int) -> dict:
        """Get detailed information for a specific search by ID."""
        return await client.get(f"/api/admin/search/{search_id}/")

    @mcp.tool()
    async def get_search_alerts(search_id: int) -> list | dict:
        """Get all alerts/flags for a specific search."""
        return await client.get(f"/api/admin/alerts/{search_id}/")

    @mcp.tool()
    async def get_ssn_trace(search_id: int) -> dict:
        """Get SSN trace information for a search."""
        return await client.get(f"/api/admin/ssntrace/{search_id}/")

    @mcp.tool()
    async def get_report_history(report_num: int) -> list | dict:
        """Get processing history/notes for a report."""
        return await client.get(f"/api/admin/history/{report_num}/")

    @mcp.tool()
    async def add_report_note(entity_type: str, entity_id: int, note: str) -> dict:
        """Add a processing note to a report. entity_type: 'employee', 'vendor', 'license', 'npi'."""
        return await client.post(
            f"/api/admin/reportlevelnote/{entity_type}/{entity_id}/",
            json={"note": note},
        )

    @mcp.tool()
    async def save_report_document(search_id: int, data: dict) -> dict:
        """Save a document/file to a report search. data should include file info."""
        return await client.post(f"/api/admin/savereportdocument/{search_id}/", json=data)

    @mcp.tool()
    async def get_source_lists() -> list | dict:
        """Get all exclusion source lists (OIG, SAM, state lists, etc.) with their status."""
        return await client.get("/api/admin/sourcelists/")
