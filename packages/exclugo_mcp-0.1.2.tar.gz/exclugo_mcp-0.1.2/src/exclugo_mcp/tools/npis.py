from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_npi(
        facility: int,
        first_name: str,
        last_name: str,
        npi: str,
        ssn: str = "",
        dob: str = "",
        middle_name: str = "",
        address: str = "",
        city: str = "",
        state: str = "",
        zip: str = "",
        reference: str = "",
        file_no: str = "",
    ) -> dict:
        """Create/order a new NPI (National Provider Identifier) for monitoring."""
        data = {
            "facility": facility,
            "first_name": first_name,
            "last_name": last_name,
            "npi": npi,
            "ssn": ssn,
            "dob": dob,
            "middle_name": middle_name,
            "address": address,
            "city": city,
            "state": state,
            "zip": zip,
            "reference": reference,
            "file_no": file_no,
        }
        return await client.post("/api/individualorder/npi/", json=data)

    @mcp.tool()
    async def edit_npi(npi_id: int, updates: dict) -> dict:
        """Edit an existing NPI record. Pass a dict of fields to update."""
        return await client.put(f"/api/reports/edit/npi/{npi_id}/", json=updates)

    @mcp.tool()
    async def search_npis(
        first_name: str = "",
        last_name: str = "",
        npi: str = "",
        facility_id: int | None = None,
    ) -> list | dict:
        """Search NPI records by name, NPI number, or facility."""
        params: dict = {}
        if first_name:
            params["first_name"] = first_name
        if last_name:
            params["last_name"] = last_name
        if npi:
            params["npi"] = npi
        if facility_id:
            params["facility"] = facility_id
        return await client.get("/api/admin/npi/search/", params=params)
