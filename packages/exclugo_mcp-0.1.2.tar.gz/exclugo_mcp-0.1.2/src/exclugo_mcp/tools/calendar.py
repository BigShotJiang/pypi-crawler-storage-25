from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_calendar(data: dict) -> dict:
        """Create or update a calendar. data should include: name (str), and optionally
        facility IDs, list types, events, etc."""
        return await client.post("/api/newcalendar/", json=data)

    @mcp.tool()
    async def get_calendar_for_facility(facility_id: int) -> dict:
        """Get the calendar configuration for a facility."""
        return await client.get(f"/api/getfacilitycalendar/{facility_id}/")

    @mcp.tool()
    async def get_calendar_events(calendar_id: int) -> list | dict:
        """Get all events and lists for a specific calendar."""
        return await client.get(f"/api/getcalendarevents/{calendar_id}/")

    @mcp.tool()
    async def get_all_events(filter: str = "all") -> list | dict:
        """Get all calendar events. filter: 'all', 'upcoming', 'overdue', etc."""
        return await client.get(f"/api/getallevents/{filter}/")

    @mcp.tool()
    async def calendar_override(calendar_id: int, data: dict) -> dict:
        """Override a calendar event. data should include override_reason, etc."""
        return await client.post(f"/api/override/{calendar_id}/", json=data)

    @mcp.tool()
    async def send_email_reminder(calendar_id: int) -> dict:
        """Manually send an email reminder for a calendar event."""
        return await client.post(f"/api/manualemailreminder/{calendar_id}/")
