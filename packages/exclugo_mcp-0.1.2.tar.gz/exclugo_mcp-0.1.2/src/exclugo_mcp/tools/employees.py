from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_employee(
        facility: int,
        first_name: str,
        last_name: str,
        ssn: str,
        dob: str = "",
        middle_name: str = "",
        address: str = "",
        city: str = "",
        state: str = "",
        zip: str = "",
        email: str = "",
        npi: str = "",
        license_number: str = "",
        license_state: str = "",
        reference: str = "",
        file_no: str = "",
    ) -> dict:
        """Create/order a new employee for background screening.
        facility: the facility ID. ssn: Social Security Number. dob: date of birth (YYYY-MM-DD)."""
        data = {
            "facility": facility,
            "first_name": first_name,
            "last_name": last_name,
            "ssn": ssn,
            "dob": dob,
            "middle_name": middle_name,
            "address": address,
            "city": city,
            "state": state,
            "zip": zip,
            "email": email,
            "npi": npi,
            "license_number": license_number,
            "license_state": license_state,
            "reference": reference,
            "file_no": file_no,
        }
        return await client.post("/api/individualorder/employee/", json=data)

    @mcp.tool()
    async def edit_employee(employee_id: int, updates: dict) -> dict:
        """Edit an existing employee record. Pass a dict of fields to update."""
        return await client.put(f"/api/reports/edit/employee/{employee_id}/", json=updates)

    @mcp.tool()
    async def search_employees(
        first_name: str = "",
        last_name: str = "",
        ssn: str = "",
        facility_id: int | None = None,
    ) -> list | dict:
        """Search employees by name, SSN, or facility. At least one search parameter is recommended."""
        params: dict = {}
        if first_name:
            params["first_name"] = first_name
        if last_name:
            params["last_name"] = last_name
        if ssn:
            params["ssn"] = ssn
        if facility_id:
            params["facility"] = facility_id
        return await client.get("/api/admin/employee/search/", params=params)

    @mcp.tool()
    async def search_by_ssn(ssn: int) -> list | dict:
        """Search for all reports associated with an SSN or report number."""
        return await client.get(f"/api/searchresults/{ssn}/")

    @mcp.tool()
    async def get_employee_address_history(employee_id: int) -> list | dict:
        """Get address history for an employee."""
        return await client.get(f"/api/addresshistory/employee/{employee_id}/")
