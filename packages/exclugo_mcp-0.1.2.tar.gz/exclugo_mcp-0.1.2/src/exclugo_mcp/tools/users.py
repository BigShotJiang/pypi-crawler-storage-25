from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from .. import client


def register(mcp: FastMCP) -> None:

    @mcp.tool()
    async def get_current_user() -> dict:
        """Get the currently authenticated user's info."""
        return await client.get("/api/user/")

    @mcp.tool()
    async def list_admin_users() -> list | dict:
        """List all admin/CRA users."""
        return await client.get("/api/admin/allusers/")

    @mcp.tool()
    async def get_user_detail(user_id: int) -> dict:
        """Get detailed info for a specific user."""
        return await client.get(f"/api/admin/user/{user_id}/")

    @mcp.tool()
    async def add_client_user(
        username: str,
        email: str,
        password: str,
        first_name: str = "",
        last_name: str = "",
        facilities: list[int] | None = None,
        permissions: str = "monitoring",
    ) -> dict:
        """Add a new client user. permissions: 'monitoring', 'reports_processing', 'preferences', etc."""
        data = {
            "username": username,
            "email": email,
            "password": password,
            "first_name": first_name,
            "last_name": last_name,
            "permissions": permissions,
        }
        if facilities:
            data["facilities"] = facilities
        return await client.post("/api/admin/user/", json=data)

    @mcp.tool()
    async def get_client_users(client_level: str, client_id: int) -> list | dict:
        """Get all users for a client/facility. client_level: 'client' or 'facility'."""
        return await client.get(f"/api/admin/clientusers/{client_level}/{client_id}/")

    @mcp.tool()
    async def get_user_facilities() -> list | dict:
        """Get all facilities the current user has access to."""
        return await client.get("/api/user/facilities/")
