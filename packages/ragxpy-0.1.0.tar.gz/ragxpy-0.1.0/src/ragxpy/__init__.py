"""ragx — Production-grade RAG in 4 lines. Hybrid search on by default."""

from ragxpy.agent import as_claude_tool, as_openai_tool
from ragxpy.config import Answer, IngestResult, QueryConfig, RAGConfig
from ragxpy.eval.schema import EvalSchema
from ragxpy.indexing.base import SearchResult
from ragxpy.pipeline import RAG

__version__ = "0.1.0"

__all__ = [
    "RAGConfig",
    "QueryConfig",
    "Answer",
    "IngestResult",
    "EvalSchema",
    "SearchResult",
    "RAG",
    "as_claude_tool",
    "as_openai_tool",
]
