"""S1-T1 scaffold smoke tests — verifies the package installs and all stubs are importable."""
from __future__ import annotations

import ragxpy
import ragxpy.embedding
import ragxpy.eval
import ragxpy.generation
import ragxpy.indexing
import ragxpy.ingestion
import ragxpy.retrieval
import ragxpy.utils


def test_version() -> None:
    assert ragxpy.__version__ == "0.1.0"


def test_all_subpackages_importable() -> None:
    # Each sub-package must be importable without errors
    for mod in (
        ragxpy.embedding,
        ragxpy.eval,
        ragxpy.generation,
        ragxpy.indexing,
        ragxpy.ingestion,
        ragxpy.retrieval,
        ragxpy.utils,
    ):
        assert hasattr(mod, "__all__")
