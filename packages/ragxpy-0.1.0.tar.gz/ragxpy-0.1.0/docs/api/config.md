# Config

Configuration dataclasses for ragx. All are frozen and typed.

## RAGConfig

Top-level configuration — passed implicitly through `RAG(...)` constructor parameters.

::: ragx.config.RAGConfig
    options:
      show_source: true

## QueryConfig

Per-query options passed to `rag.query(..., config=QueryConfig(...))`.

::: ragx.config.QueryConfig
    options:
      show_source: true

## Answer

Returned by `rag.query()`.

::: ragx.config.Answer
    options:
      show_source: true

## IngestResult

Returned by `rag.ingest()`. Never raises — failures are captured in `errors`.

::: ragx.config.IngestResult
    options:
      show_source: true
