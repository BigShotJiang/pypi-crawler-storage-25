# Changelog

All notable changes to this project will be documented in this file.

## [0.3.1] — 2026-03-28

### Fixed

- `LightGBMPredictor`: standard PyPI `lightgbm` wheels are CPU-only; GPU/CUDA
  support requires a specially compiled build.  `device="auto"` now probes
  LightGBM with a tiny dummy fit before selecting CUDA, so it no longer
  resolves to `"cuda"` on systems with a CPU-only wheel.  For explicit
  `device="cuda"` or `device="gpu"`, a graceful fallback to CPU with a
  `RuntimeWarning` is applied if the wheel lacks GPU support.

## [0.3.0] — 2026-03-28

### Added

- `eapctf.predict.defaults` — standard hyperparameter grids for paper benchmarks
  - `GKX_PARAM_GRIDS` — GKX (2020) grids for lasso, ridge, elastic_net, rf, gbt, nn
  - `HJKP_PARAM_GRIDS` — HJKP (2025) grids with extended ridge range and lgbm
  - `make_cv_predictor(model_type, preset, ...)` — one-line `CVPredictor` factory
  - `make_predictor("lasso_cv")` shorthand via `_cv` suffix dispatch
- `LightGBMPredictor.device` parameter for GPU compute device selection
  - `device="auto"` (default): detects CUDA via `torch.cuda.is_available()`, falls back to CPU
  - `device="cuda"` / `device="gpu"` / `device="cpu"` for explicit control
  - `n_jobs` omitted from params when non-CPU device is selected

### Changed

- RF grids (`GKX_PARAM_GRIDS["rf"]`, `HJKP_PARAM_GRIDS["rf"]`) search only
  `max_features` and `max_depth` — `n_estimators` intentionally excluded
  because averaging more trees always reduces variance with no bias cost
  (Goulet Coulombe 2022)
- GBT grids search only `max_depth` and `learning_rate`; `n_estimators` fixed
  at GKX Table A.5 value of 300

## [0.2.0] — 2026-03-27

### Added

- `eapctf.ctf.conformal` — MAPIE CV+ conformal prediction with Adaptive Conformal Inference
  - `ctf_conformal_oos()` — full CTF conformal pipeline returning `id, eom, w, w_baseline, interval_width, alpha_t`
  - `AdaptiveConformalInference` — per-period alpha_t update via cross-sectional coverage (Gibbs & Candes 2021)
  - Uncertainty-adjusted signal: `mu_tilde = point_pred - lambda_t * interval_width / 2`
  - Supports `refit_freq="yearly"` / `"monthly"`, and all three weight modes
- New optional dependency group: `eapctf[conformal]` (`mapie>=1.0.0`)
- Docs: conformal prediction section added to writing guide and API reference

## [0.1.0] — 2026-03-27

### Added

- `eapctf.ctf` — CTF (Competition to Forecast) integration module
  - `run_local()` — execute a CTF model script against local parquet data
  - `compute_metrics()` — ex-ante Sharpe, annual return, vol, max drawdown with 10% vol-targeting
  - `validate()` — 14 auto-checked CTF compliance rules (look-ahead, signature, determinism, etc.)
  - `fetch_leaderboard()` — retrieve current CTF leaderboard from jkpfactors.com
  - `pipeline()` — end-to-end run → metrics → validate → submit workflow
  - `download_ctf_data()` — fetch CTF datasets via WRDS

- `eapctf.sorting` — portfolio sorting and factor construction
  - `univariate_sort()`, `bivariate_sort()` — single and double conditional sorts
  - `long_short_portfolio()` — characteristic-sorted long-short spreads
  - `ff3_factors()`, `ff5_factors()`, `hxz4_factors()`, `sy4_factors()`, `mom_factor()`, `char_factor()`

- `eap.crosssection` — Fama-MacBeth two-pass cross-sectional regression

- `eap.timeseries` — GRS test, time-series alpha estimation

- `eap.sdf` — GMM SDF estimation, Hansen-Jagannathan distance

- `eapctf.predict` — expanding-window out-of-sample prediction framework

- `eapctf.portfolio` — mean-variance optimization weights

- `eapctf.utils` — `EAPPanel`, `rank_normalize`, `classify`, `JKP_153`, `GFD_CHAR_MAP`, `load_gfd_chars`

- `reference/` — runnable CTF benchmark scripts
  - `benchmark-ipca-pf.py` — IPCA (Kelly, Pruitt, Su 2019) with joblib parallelization
  - `benchmark-one-over-n.py` — equal-weight 1/N baseline
  - `template-ctf-model.py` — copy-and-modify template for new CTF submissions

- `docs/ctf_features.yaml` — annotated catalogue of all 402 CTF features (153 JKP + 249 additional)

### CTF Replication

Verified that `eapctf.ctf.compute_metrics()` reproduces CTF server evaluation (10% vol-targeting):

| Model | Sharpe | Annual Return | Vol | Max Drawdown |
|---|---|---|---|---|
| 1/N equal weight | 0.551 | 5.13% | 10.00% | -30.43% |
| IPCA (KPS 2019) | 1.939 | 20.64% | 10.00% | -10.30% |

IPCA leaderboard (CTF server): Sharpe 1.948, Annual 19.48%, Vol 10.00%, MDD -9.92%.
Discrepancy of 0.009 Sharpe units reflects minor implementation differences (window alignment, factor count).
