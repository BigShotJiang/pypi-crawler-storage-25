"""Tests for eapctf.predict.defaults — standard hyperparameter grids."""

from __future__ import annotations

import pytest

from eapctf.predict.defaults import (
    GKX_PARAM_GRIDS,
    HJKP_PARAM_GRIDS,
    make_cv_predictor,
)
from eapctf.predict.models import CVPredictor, make_predictor


# ---------------------------------------------------------------------------
# GKX_PARAM_GRIDS
# ---------------------------------------------------------------------------


class TestGkxParamGrids:
    _EXPECTED_KEYS = {"lasso", "ridge", "elastic_net", "nn"}

    def test_expected_models_present(self) -> None:
        assert self._EXPECTED_KEYS.issubset(set(GKX_PARAM_GRIDS))

    def test_lasso_has_alpha(self) -> None:
        assert "alpha" in GKX_PARAM_GRIDS["lasso"]

    def test_lasso_covers_log_range(self) -> None:
        alphas = GKX_PARAM_GRIDS["lasso"]["alpha"]
        assert min(alphas) <= 1e-4
        assert max(alphas) >= 1.0

    def test_ridge_has_alpha(self) -> None:
        assert "alpha" in GKX_PARAM_GRIDS["ridge"]

    def test_elastic_net_has_both_params(self) -> None:
        grid = GKX_PARAM_GRIDS["elastic_net"]
        assert "alpha" in grid
        assert "l1_ratio" in grid
        # Must span from Ridge-like to Lasso-like
        assert min(grid["l1_ratio"]) <= 0.2
        assert max(grid["l1_ratio"]) >= 0.8

    def test_all_grid_values_are_lists(self) -> None:
        for model, grid in GKX_PARAM_GRIDS.items():
            for param, vals in grid.items():
                assert isinstance(vals, list), f"{model}.{param} must be a list"

    def test_rf_grid_has_max_features_and_depth(self) -> None:
        """RF grid tunes mtry and depth but NOT n_estimators."""
        grid = GKX_PARAM_GRIDS["rf"]
        assert "max_features" in grid
        assert "max_depth" in grid
        assert "n_estimators" not in grid

    def test_gbt_grid_has_depth_and_lr(self) -> None:
        """GBT grid tunes depth and learning_rate but NOT n_estimators."""
        grid = GKX_PARAM_GRIDS["gbt"]
        assert "max_depth" in grid
        assert "learning_rate" in grid
        assert "n_estimators" not in grid


# ---------------------------------------------------------------------------
# HJKP_PARAM_GRIDS
# ---------------------------------------------------------------------------


class TestHjkpParamGrids:
    def test_linear_models_present(self) -> None:
        for m in ("lasso", "ridge", "elastic_net"):
            assert m in HJKP_PARAM_GRIDS

    def test_ridge_extended_upper_end(self) -> None:
        # HJKP extends the range for larger N
        assert max(HJKP_PARAM_GRIDS["ridge"]["alpha"]) >= 10.0

    def test_all_grid_values_are_lists(self) -> None:
        for model, grid in HJKP_PARAM_GRIDS.items():
            for param, vals in grid.items():
                assert isinstance(vals, list), f"{model}.{param} must be a list"

    def test_rf_and_gbt_present(self) -> None:
        assert "rf" in HJKP_PARAM_GRIDS
        assert "gbt" in HJKP_PARAM_GRIDS


# ---------------------------------------------------------------------------
# make_cv_predictor
# ---------------------------------------------------------------------------


class TestMakeCvPredictor:
    def test_returns_cv_predictor(self) -> None:
        p = make_cv_predictor("lasso")
        assert isinstance(p, CVPredictor)

    def test_lasso_cv_uses_gkx_grid_by_default(self) -> None:
        p = make_cv_predictor("lasso")
        assert p.param_grid == GKX_PARAM_GRIDS["lasso"]

    def test_ridge_cv_gkx(self) -> None:
        p = make_cv_predictor("ridge", preset="gkx")
        assert p.param_grid == GKX_PARAM_GRIDS["ridge"]

    def test_ridge_cv_hjkp(self) -> None:
        p = make_cv_predictor("ridge", preset="hjkp")
        assert p.param_grid == HJKP_PARAM_GRIDS["ridge"]

    def test_custom_param_grid_overrides_preset(self) -> None:
        custom = {"alpha": [0.5, 1.0]}
        p = make_cv_predictor("lasso", param_grid=custom)
        assert p.param_grid == custom

    def test_scoring_kwarg_forwarded(self) -> None:
        p = make_cv_predictor("ridge", scoring="r2")
        assert p.scoring == "r2"

    def test_invalid_model_type_raises(self) -> None:
        with pytest.raises(ValueError, match="model_type"):
            make_cv_predictor("unknown_model")

    def test_invalid_preset_raises(self) -> None:
        with pytest.raises(ValueError, match="preset"):
            make_cv_predictor("lasso", preset="bad_preset")

    def test_rf_gkx_preset_works(self) -> None:
        """RF now has a GKX grid — n_estimators excluded (not a tuning param)."""
        p = make_cv_predictor("rf")
        assert isinstance(p, CVPredictor)
        assert "max_features" in p.param_grid
        assert "n_estimators" not in p.param_grid

    def test_gbt_gkx_preset_works(self) -> None:
        p = make_cv_predictor("gbt")
        assert isinstance(p, CVPredictor)
        assert "max_depth" in p.param_grid
        assert "n_estimators" not in p.param_grid

    def test_rf_with_custom_grid(self) -> None:
        """Custom param_grid overrides the preset."""
        p = make_cv_predictor("rf", param_grid={"max_depth": [3, 6]})
        assert isinstance(p, CVPredictor)
        assert p.param_grid == {"max_depth": [3, 6]}

    @pytest.mark.parametrize("model_type", ["lasso", "ridge", "elastic_net"])
    def test_all_linear_models_gkx(self, model_type: str) -> None:
        p = make_cv_predictor(model_type, preset="gkx")
        assert isinstance(p, CVPredictor)
        assert len(p.param_grid) > 0


# ---------------------------------------------------------------------------
# make_predictor _cv suffix
# ---------------------------------------------------------------------------


class TestMakePredictorCvSuffix:
    def test_lasso_cv_shorthand(self) -> None:
        p = make_predictor("lasso_cv")
        assert isinstance(p, CVPredictor)
        assert "alpha" in p.param_grid

    def test_ridge_cv_shorthand(self) -> None:
        p = make_predictor("ridge_cv")
        assert isinstance(p, CVPredictor)

    def test_cv_suffix_accepts_preset_kwarg(self) -> None:
        p = make_predictor("ridge_cv", preset="hjkp")
        assert p.param_grid == HJKP_PARAM_GRIDS["ridge"]

    def test_cv_suffix_accepts_custom_param_grid(self) -> None:
        custom = {"alpha": [0.1, 1.0]}
        p = make_predictor("lasso_cv", param_grid=custom)
        assert p.param_grid == custom

    def test_plain_predictor_unaffected(self) -> None:
        from eapctf.predict.models import RidgePredictor
        p = make_predictor("ridge")
        assert isinstance(p, RidgePredictor)

    def test_unknown_cv_suffix_raises(self) -> None:
        with pytest.raises(ValueError):
            make_predictor("unknown_cv")
