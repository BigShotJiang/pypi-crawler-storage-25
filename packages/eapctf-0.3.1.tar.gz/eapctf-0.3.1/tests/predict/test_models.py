"""Tests for eapctf.predict.models — predictor classes."""

from __future__ import annotations

import pytest

from eapctf.predict.models import LightGBMPredictor, RandomForestPredictor


# ---------------------------------------------------------------------------
# RandomForestPredictor
# ---------------------------------------------------------------------------


class TestRandomForestPredictor:
    def test_default_n_estimators(self) -> None:
        m = RandomForestPredictor()
        assert m.n_estimators == 300

    def test_n_estimators_not_in_gkx_grid(self) -> None:
        """n_estimators must not appear in the GKX RF grid."""
        from eapctf.predict.defaults import GKX_PARAM_GRIDS

        assert "n_estimators" not in GKX_PARAM_GRIDS["rf"]

    def test_max_features_in_gkx_grid(self) -> None:
        from eapctf.predict.defaults import GKX_PARAM_GRIDS

        assert "max_features" in GKX_PARAM_GRIDS["rf"]
        assert len(GKX_PARAM_GRIDS["rf"]["max_features"]) > 0

    def test_max_depth_in_gkx_grid(self) -> None:
        from eapctf.predict.defaults import GKX_PARAM_GRIDS

        assert "max_depth" in GKX_PARAM_GRIDS["rf"]


# ---------------------------------------------------------------------------
# LightGBMPredictor — device resolution
# ---------------------------------------------------------------------------


class TestLightGBMPredictorDevice:
    def test_default_device_is_auto(self) -> None:
        m = LightGBMPredictor()
        assert m.device == "auto"

    def test_explicit_cpu_resolves_to_cpu(self) -> None:
        m = LightGBMPredictor(device="cpu")
        assert m._resolve_device() == "cpu"

    def test_explicit_cuda_resolves_to_cuda(self) -> None:
        m = LightGBMPredictor(device="cuda")
        assert m._resolve_device() == "cuda"

    def test_explicit_gpu_resolves_to_gpu(self) -> None:
        m = LightGBMPredictor(device="gpu")
        assert m._resolve_device() == "gpu"

    def test_auto_resolves_to_string(self) -> None:
        m = LightGBMPredictor(device="auto")
        result = m._resolve_device()
        assert result in {"cpu", "cuda", "gpu"}

    def test_auto_falls_back_to_cpu_without_cuda(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When torch.cuda is unavailable, auto → cpu."""
        import sys
        import types

        fake_torch = types.ModuleType("torch")
        fake_cuda = types.ModuleType("torch.cuda")
        fake_cuda.is_available = lambda: False  # type: ignore[attr-defined]
        fake_torch.cuda = fake_cuda  # type: ignore[attr-defined]
        monkeypatch.setitem(sys.modules, "torch", fake_torch)

        m = LightGBMPredictor(device="auto")
        assert m._resolve_device() == "cpu"

    def test_auto_returns_cuda_when_lgbm_supports_it(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When torch CUDA is available AND LightGBM supports CUDA, auto → cuda."""
        import sys
        import types

        fake_torch = types.ModuleType("torch")
        fake_cuda = types.ModuleType("torch.cuda")
        fake_cuda.is_available = lambda: True  # type: ignore[attr-defined]
        fake_torch.cuda = fake_cuda  # type: ignore[attr-defined]
        monkeypatch.setitem(sys.modules, "torch", fake_torch)
        monkeypatch.setattr(LightGBMPredictor, "_lgbm_supports_device", staticmethod(lambda device: True))

        m = LightGBMPredictor(device="auto")
        assert m._resolve_device() == "cuda"

    def test_auto_falls_back_when_lgbm_lacks_gpu_build(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """torch CUDA available but standard CPU-only lightgbm wheel → auto falls back to cpu."""
        import sys
        import types

        fake_torch = types.ModuleType("torch")
        fake_cuda = types.ModuleType("torch.cuda")
        fake_cuda.is_available = lambda: True  # type: ignore[attr-defined]
        fake_torch.cuda = fake_cuda  # type: ignore[attr-defined]
        monkeypatch.setitem(sys.modules, "torch", fake_torch)
        # Simulate CPU-only lightgbm wheel: _lgbm_supports_device returns False
        monkeypatch.setattr(LightGBMPredictor, "_lgbm_supports_device", staticmethod(lambda device: False))

        m = LightGBMPredictor(device="auto")
        assert m._resolve_device() == "cpu"
