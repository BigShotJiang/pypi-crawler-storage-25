"""Shared fixtures for the eap test suite."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest


@pytest.fixture
def small_panel() -> pd.DataFrame:
    """50 stocks x 120 months (10 years), random returns + 5 characteristics.

    Columns: permno, date, ret, mktcap, exchcd, bm, op, inv, mom12m, rf
    """
    np.random.seed(42)

    n_stocks = 50
    n_months = 120

    # Integer dates: 1..120 (months)
    dates = list(range(1, n_months + 1))
    permnos = list(range(1001, 1001 + n_stocks))

    rows = []
    for date in dates:
        for permno in permnos:
            rows.append(
                {
                    "permno": permno,
                    "date": date,
                    "ret": np.random.normal(0.005, 0.06),
                    "mktcap": np.random.lognormal(5, 1),
                    # NYSE (1) for first 25 stocks, AMEX/NASDAQ (2) for rest
                    "exchcd": 1 if permno < 1026 else 2,
                    "bm": np.random.lognormal(-0.3, 0.5),
                    "op": np.random.normal(0.12, 0.06),
                    "inv": np.random.normal(0.05, 0.15),
                    "mom12m": np.random.normal(0.0, 0.25),
                    "rf": 0.0001,
                }
            )

    df = pd.DataFrame(rows)
    return df
