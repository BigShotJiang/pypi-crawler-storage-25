"""eapctf.utils — Utility functions for the empirical asset pricing toolkit.

Re-exports all public symbols from submodules for convenient access:
    from eapctf.utils import rank_normalize, EAPPanel, classify, JKP_153
"""

from eapctf.utils.constants import (
    FF3_FACTORS,
    FF5_FACTORS,
    GFD_CHAR_MAP,
    GFD_CHAR_UNAVAILABLE,
    HXZ4_FACTORS,
    JKP_153,
    SY4_FACTORS,
)
from eapctf.utils.data import EAPPanel, align_returns_chars, lag_panel, load_gfd_chars
from eapctf.utils.preprocessing import classify, rank_normalize, standardize, winsorize
from eapctf.utils.validation import (
    TemporalLeakageError,
    check_no_lookahead,
    check_panel_dims,
)

__all__ = [
    # constants
    "FF3_FACTORS",
    "FF5_FACTORS",
    "GFD_CHAR_MAP",
    "GFD_CHAR_UNAVAILABLE",
    "HXZ4_FACTORS",
    "JKP_153",
    "SY4_FACTORS",
    # data
    "EAPPanel",
    "align_returns_chars",
    "lag_panel",
    "load_gfd_chars",
    # preprocessing
    "classify",
    "rank_normalize",
    "standardize",
    "winsorize",
    # validation
    "TemporalLeakageError",
    "check_no_lookahead",
    "check_panel_dims",
]
