"""eapctf.crosssection -- Cross-sectional asset pricing tests.

Re-exports public symbols from submodules:
    - Fama-MacBeth two-pass regression (fmb)
    - Pooled cross-sectional regression with clustered SE (cs_regression)
    - Multiple testing correction for anomaly discovery (cs_regression)
"""

from eapctf.crosssection.cs_regression import (
    CSRegressionResult,
    cs_regression,
    multiple_testing_correction,
)
from eapctf.crosssection.fmb import FMBResult, fama_macbeth

__all__ = [
    "CSRegressionResult",
    "FMBResult",
    "cs_regression",
    "fama_macbeth",
    "multiple_testing_correction",
]
