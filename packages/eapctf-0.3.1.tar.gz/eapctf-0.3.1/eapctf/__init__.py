"""eap — Empirical Asset Pricing Toolkit.

Top-level re-exports for the most commonly used symbols.
Full API is available via the submodules:
    eapctf.utils, eapctf.sorting, eapctf.crosssection, eapctf.timeseries,
    eapctf.sdf, eapctf.predict, eapctf.portfolio, eapctf.ctf
"""

__version__ = "0.3.1"

from eapctf import ctf  # noqa: F401 — makes `import eapctf; eapctf.ctf.pipeline(...)` work
from eapctf.crosssection import fama_macbeth
from eapctf.portfolio import mean_variance_weights
from eapctf.predict import expanding_window_oos
from eapctf.sdf import gmm_estimate, hj_distance
from eapctf.sorting import (
    bivariate_sort,
    char_factor,
    ff3_factors,
    ff5_factors,
    hxz4_factors,
    long_short_portfolio,
    mom_factor,
    sy4_factors,
    univariate_sort,
)
from eapctf.timeseries import grs_test, time_series_alpha
from eapctf.utils import (
    GFD_CHAR_MAP,
    GFD_CHAR_UNAVAILABLE,
    JKP_153,
    EAPPanel,
    classify,
    load_gfd_chars,
    rank_normalize,
)

__all__ = [
    # ctf
    "ctf",
    # utils
    "rank_normalize",
    "EAPPanel",
    "classify",
    "JKP_153",
    "GFD_CHAR_MAP",
    "GFD_CHAR_UNAVAILABLE",
    "load_gfd_chars",
    # sorting / factors
    "univariate_sort",
    "bivariate_sort",
    "char_factor",
    "ff3_factors",
    "ff5_factors",
    "hxz4_factors",
    "sy4_factors",
    "mom_factor",
    "long_short_portfolio",
    # cross-section
    "fama_macbeth",
    # time series
    "grs_test",
    "time_series_alpha",
    # sdf
    "gmm_estimate",
    "hj_distance",
    # prediction
    "expanding_window_oos",
    # portfolio (optimization)
    "mean_variance_weights",
]
