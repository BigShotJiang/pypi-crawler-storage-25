"""SDF estimation, testing, and diagnostics.

Provides Hansen (1982) GMM estimation, Hansen-Jagannathan (1991) distance
and volatility bounds, and pricing error diagnostics for linear SDF models.
"""

from eapctf.sdf.gmm import GMMResult, gmm_estimate
from eapctf.sdf.hj import HJResult, hj_bounds, hj_distance
from eapctf.sdf.pricing_errors import PricingErrorResult, pricing_errors

__all__ = [
    "GMMResult",
    "gmm_estimate",
    "HJResult",
    "hj_distance",
    "hj_bounds",
    "PricingErrorResult",
    "pricing_errors",
]
