"""Time-series factor model tests and regressions.

Provides tools for time-series alpha estimation, the GRS test for
joint significance of alphas, and mean-variance spanning tests.
"""

from eapctf.timeseries.alpha import AlphaResult, newey_west_se, rolling_beta, time_series_alpha
from eapctf.timeseries.grs import GRSResult, grs_test
from eapctf.timeseries.spanning import SpanningResult, spanning_test

__all__ = [
    "AlphaResult",
    "GRSResult",
    "SpanningResult",
    "grs_test",
    "newey_west_se",
    "rolling_beta",
    "spanning_test",
    "time_series_alpha",
]
