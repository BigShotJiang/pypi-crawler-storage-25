"""CTF submission utilities for the eap package.

Provides tools for validating, packaging, and submitting models to the
HJKP 2025 Common Task Framework at jkpfactors.com.
"""

from eapctf.ctf.conformal import (
    AdaptiveConformalInference,
    ctf_conformal_oos,
)
from eapctf.ctf.data import download_ctf_data
from eapctf.ctf.interface import (
    CTF_PREINSTALLED,
    generate_main_template,
    predictions_to_ctf_weights,
    run_local,
)
from eapctf.ctf.leaderboard import LeaderboardEntry, LeaderboardResult, fetch_leaderboard
from eapctf.ctf.metrics import MetricsResult, compute_metrics
from eapctf.ctf.package import SubmissionBundle, build_submission
from eapctf.ctf.pipeline import CTFReport, pipeline
from eapctf.ctf.predict import ctf_expanding_window_oos
from eapctf.ctf.prep import ctf_rank_normalize, ctf_select_features
from eapctf.ctf.submit import SubmissionResult, submit
from eapctf.ctf.validate import ValidationResult, validate

__all__ = [
    "CTF_PREINSTALLED",
    "generate_main_template",
    "predictions_to_ctf_weights",
    "run_local",
    "validate",
    "ValidationResult",
    "compute_metrics",
    "MetricsResult",
    "build_submission",
    "SubmissionBundle",
    "fetch_leaderboard",
    "LeaderboardEntry",
    "LeaderboardResult",
    "submit",
    "SubmissionResult",
    "download_ctf_data",
    "pipeline",
    "CTFReport",
    "ctf_rank_normalize",
    "ctf_select_features",
    "ctf_expanding_window_oos",
    "ctf_conformal_oos",
    "AdaptiveConformalInference",
]
