"""eapctf.portfolio — Portfolio optimization and evaluation.

Covers optimization-based portfolio construction (mean-variance, Black-Litterman,
HRP, parametric policies) and portfolio performance evaluation.

For sorting-based long-short portfolios, see eapctf.sorting.portfolio.

Re-exports all public symbols from submodules:
    from eapctf.portfolio import mean_variance_weights, evaluate_portfolio
"""

from eapctf.portfolio.metrics import (
    PortfolioMetrics,
    evaluate_portfolio,
)
from eapctf.portfolio.parametric import ParametricPolicy
from eapctf.portfolio.weighting import (
    ManagedPortfolio,
    black_litterman_weights,
    cov_matrix,
    hrp_weights,
    mean_variance_weights,
)

__all__ = [
    # parametric
    "ParametricPolicy",
    # metrics
    "PortfolioMetrics",
    "evaluate_portfolio",
    # weighting
    "ManagedPortfolio",
    "cov_matrix",
    "mean_variance_weights",
    "black_litterman_weights",
    "hrp_weights",
]
