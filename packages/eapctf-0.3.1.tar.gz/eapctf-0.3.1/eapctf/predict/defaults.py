"""Standard hyperparameter grids for eapctf predictors.

Centralises the model configurations from two key benchmarks:

- **GKX (2020)**: Gu, Kelly, and Xiu (2020), *Empirical Asset Pricing via
  Machine Learning*, RFS 33(5), Table IA.I and Online Appendix.
- **HJKP (2025)**: Hellum, Jensen, Kelly, and Pedersen (2025), *The Power of
  the Common Task Framework*, SSRN 5242901.

Only grids are provided — no "fixed defaults".  GKX always selects
hyperparameters via a rolling validation-period grid search; there are no
paper-specified single values for individual models.

Usage::

    from eapctf.predict.defaults import make_cv_predictor, GKX_PARAM_GRIDS

    # CVPredictor with GKX paper grid
    lasso_cv = make_cv_predictor("lasso")
    ridge_cv = make_cv_predictor("ridge", preset="hjkp")

    # Shorthand via make_predictor
    from eapctf.predict import make_predictor
    lasso_cv = make_predictor("lasso_cv")
"""

from __future__ import annotations

from typing import Any

from eapctf.predict.models import (
    CVPredictor,
    ElasticNetPredictor,
    GBTPredictor,
    LassoPredictor,
    LightGBMPredictor,
    NeuralNetPredictor,
    OLSPredictor,
    RandomForestPredictor,
    RidgePredictor,
)

# ---------------------------------------------------------------------------
# GKX (2020) hyperparameter grids
# For penalised linear models and NNs, GKX searches over a grid on a
# rolling validation window and picks the best value before each refit.
# Alpha range: 10^-5 to 10, log-spaced (7 values).
# Source: GKX (2020) Online Appendix Table IA.I.
# ---------------------------------------------------------------------------

GKX_PARAM_GRIDS: dict[str, dict[str, list[Any]]] = {
    "lasso": {
        "alpha": [1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1.0, 10.0],
    },
    "ridge": {
        "alpha": [1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1.0, 10.0],
    },
    "elastic_net": {
        "alpha": [1e-4, 1e-3, 1e-2, 1e-1, 1.0],
        # l1_ratio: 0.1 → Ridge-like, 0.9 → Lasso-like
        "l1_ratio": [0.1, 0.5, 0.9],
    },
    # RF: n_estimators is NOT a tuning parameter — more trees always helps and
    # there is no bias-variance tradeoff (Goulet Coulombe 2022).  Use a fixed
    # large value (default 300 per GKX) and only search over mtry and depth.
    # Source: GKX (2020) Online Appendix Table A.5.
    "rf": {
        # mtry: number of features randomly eligible at each split
        "max_features": [3, 5, 10, 20, 30, 50],
        "max_depth": [1, 2, 3, 4, 5, 6],
    },
    # GBT: n_estimators fixed at 300 per GKX Table A.5; tune depth and lr.
    "gbt": {
        "max_depth": [1, 2, 3, 4, 5, 6],
        "learning_rate": [0.01, 0.05],
    },
    # NN: GKX sweeps architecture (NN1–NN5) and regularisation strength
    "nn": {
        "hidden_sizes": [(32, 16), (32, 32), (64, 32), (64, 64), (64, 32, 16)],
        "dropout": [0.3, 0.5],
        "l1_lambda": [1e-3, 1e-2],
    },
}

# ---------------------------------------------------------------------------
# HJKP (2025) hyperparameter grids
# Follows GKX methodology with 5-fold temporal cross-validation.
# Linear-model grids are slightly extended for the CTF's larger cross-section.
# Source: HJKP (2025) SSRN 5242901 Sec. 4.
# ---------------------------------------------------------------------------

HJKP_PARAM_GRIDS: dict[str, dict[str, list[Any]]] = {
    "lasso": {
        "alpha": [1e-5, 1e-4, 1e-3, 1e-2, 1e-1, 1.0],
    },
    "ridge": {
        # Extended upper end — larger N in the CTF cross-section
        "alpha": [1e-4, 1e-3, 1e-2, 1e-1, 1.0, 10.0, 100.0],
    },
    "elastic_net": {
        "alpha": [1e-4, 1e-3, 1e-2, 1e-1, 1.0],
        "l1_ratio": [0.1, 0.5, 0.9],
    },
    # RF/GBT: same grid as GKX — n_estimators is not a tuning parameter
    "rf": {
        "max_features": [3, 5, 10, 20, 30, 50],
        "max_depth": [1, 2, 3, 4, 5, 6],
    },
    "gbt": {
        "max_depth": [1, 2, 3, 4, 5, 6],
        "learning_rate": [0.01, 0.05],
    },
    # LightGBM: no canonical CTF grid; covers the standard tuning surface.
    # n_estimators IS tuned for LGBM because leaf-wise boosting is sensitive
    # to the number of rounds (unlike bagging ensembles).
    "lgbm": {
        "num_leaves": [31, 63, 127],
        "learning_rate": [0.01, 0.05, 0.1],
        "n_estimators": [100, 300, 500],
    },
    "nn": {
        "hidden_sizes": [(32, 16), (32, 32), (64, 32), (64, 64)],
        "dropout": [0.3, 0.5],
        "l1_lambda": [1e-3, 1e-2],
    },
}

_PRESET_MAP: dict[str, dict[str, dict[str, list[Any]]]] = {
    "gkx": GKX_PARAM_GRIDS,
    "hjkp": HJKP_PARAM_GRIDS,
}

_PREDICTOR_CLASS_MAP: dict[str, type] = {
    "ols": OLSPredictor,
    "lasso": LassoPredictor,
    "ridge": RidgePredictor,
    "elastic_net": ElasticNetPredictor,
    "rf": RandomForestPredictor,
    "gbt": GBTPredictor,
    "lgbm": LightGBMPredictor,
    "nn": NeuralNetPredictor,
}


def make_cv_predictor(
    model_type: str,
    preset: str = "gkx",
    param_grid: dict[str, list[Any]] | None = None,
    scoring: str = "mse",
    **fixed_kwargs: Any,
) -> CVPredictor:
    """Create a :class:`~eapctf.predict.models.CVPredictor` with a standard param grid.

    Looks up the hyperparameter grid for ``model_type`` from the chosen
    ``preset``.  A custom ``param_grid`` overrides the preset entirely.

    Parameters
    ----------
    model_type : str
        One of ``"lasso"``, ``"ridge"``, ``"elastic_net"``, ``"lgbm"``,
        ``"nn"`` for ``"gkx"`` preset; additionally ``"lgbm"`` for
        ``"hjkp"`` preset.  ``"rf"`` and ``"gbt"`` are not in either grid
        because GKX fixes those architectures — pass ``param_grid``
        explicitly if you want to tune them.
    preset : str
        ``"gkx"`` (default) or ``"hjkp"``.
    param_grid : dict | None
        Custom grid.  Overrides ``preset`` when provided.
    scoring : str
        ``"mse"`` (default) or ``"r2"``.
    **fixed_kwargs : Any
        Fixed constructor kwargs forwarded regardless of the grid
        (e.g. ``max_iter=20_000`` for Lasso).

    Returns
    -------
    CVPredictor
        Ready for :func:`~eapctf.predict.oos.expanding_window_oos`
        with ``val_window > 0``.

    Raises
    ------
    ValueError
        If ``preset`` is unknown, ``model_type`` is unrecognised, or the
        chosen preset has no grid for ``model_type`` and no custom
        ``param_grid`` was supplied.

    Examples
    --------
    GKX-style Lasso::

        from eapctf.predict.defaults import make_cv_predictor

        cv_lasso = make_cv_predictor("lasso")
        result = expanding_window_oos(data, models=[cv_lasso], val_window=12)

    HJKP Ridge in a CTF model::

        def main(chars, features, daily_ret):
            oos = ctf_expanding_window_oos(
                chars, features,
                models=[make_cv_predictor("ridge", preset="hjkp")],
                val_window=12,
            )
            return oos.to_ctf_weights(signal_col="pred_CVPredictor", mode="zscore")

    Tune GBT depth (custom grid, GKX fixes this but you can override)::

        cv_gbt = make_cv_predictor(
            "gbt",
            param_grid={"max_depth": [1, 2, 3], "learning_rate": [0.01, 0.05]},
        )
    """
    if preset not in _PRESET_MAP:
        raise ValueError(
            f"preset must be one of {set(_PRESET_MAP)}, got {preset!r}"
        )
    if model_type not in _PREDICTOR_CLASS_MAP:
        raise ValueError(
            f"model_type must be one of {set(_PREDICTOR_CLASS_MAP)}, "
            f"got {model_type!r}"
        )

    if param_grid is None:
        grids = _PRESET_MAP[preset]
        if model_type not in grids:
            raise ValueError(
                f"No {preset!r} grid defined for {model_type!r}. "
                f"GKX fixes rf/gbt architectures — pass param_grid explicitly "
                f"to tune them.  Available in this preset: {set(grids)}."
            )
        param_grid = grids[model_type]

    predictor_class = _PREDICTOR_CLASS_MAP[model_type]
    return CVPredictor(
        predictor_class, param_grid=param_grid, scoring=scoring, **fixed_kwargs
    )
