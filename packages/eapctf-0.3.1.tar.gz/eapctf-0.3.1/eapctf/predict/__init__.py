"""Prediction module for empirical asset pricing.

Provides ML models, characteristic preparation, and an expanding-window
out-of-sample prediction framework following GKX (2020).
"""

from eapctf.predict.defaults import (
    GKX_PARAM_GRIDS,
    HJKP_PARAM_GRIDS,
    make_cv_predictor,
)
from eapctf.predict.eval import eval_oos_result, portfolio_eval, prediction_eval
from eapctf.predict.models import (
    BasePredictor,
    CVPredictor,
    ElasticNetPredictor,
    GBTPredictor,
    IPCAPredictor,
    LassoPredictor,
    LightGBMPredictor,
    NeuralNetPredictor,
    OLSPredictor,
    RandomForestPredictor,
    RidgePredictor,
    make_predictor,
)
from eapctf.predict.oos import OOSResult, expanding_window_oos
from eapctf.predict.prep import char_prep

__all__ = [
    "GKX_PARAM_GRIDS",
    "HJKP_PARAM_GRIDS",
    "make_cv_predictor",
    "BasePredictor",
    "CVPredictor",
    "ElasticNetPredictor",
    "GBTPredictor",
    "IPCAPredictor",
    "LassoPredictor",
    "LightGBMPredictor",
    "NeuralNetPredictor",
    "OLSPredictor",
    "OOSResult",
    "RandomForestPredictor",
    "RidgePredictor",
    "char_prep",
    "eval_oos_result",
    "expanding_window_oos",
    "make_predictor",
    "portfolio_eval",
    "prediction_eval",
]
