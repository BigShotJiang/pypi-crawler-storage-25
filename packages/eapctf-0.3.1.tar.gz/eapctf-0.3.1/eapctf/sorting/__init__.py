"""Portfolio sorting and factor construction.

This module provides tools for forming characteristic-sorted portfolios,
constructing standard factor models, and building long-short portfolios
from sorted signals.
"""

from eapctf.sorting.breakpoints import nyse_breakpoints
from eapctf.sorting.factors import (
    FactorResult,
    char_factor,
    ff3_factors,
    ff5_factors,
    hxz4_factors,
    mom_factor,
    sy4_factors,
)
from eapctf.sorting.portfolio import (
    PortfolioResult,
    long_short_portfolio,
)
from eapctf.sorting.sorts import (
    SortResult,
    bivariate_sort,
    univariate_sort,
)

__all__ = [
    "SortResult",
    "FactorResult",
    "PortfolioResult",
    "univariate_sort",
    "bivariate_sort",
    "nyse_breakpoints",
    "char_factor",
    "ff3_factors",
    "ff5_factors",
    "hxz4_factors",
    "sy4_factors",
    "mom_factor",
    "long_short_portfolio",
]
