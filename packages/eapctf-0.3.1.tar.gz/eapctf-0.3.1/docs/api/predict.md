# eapctf.predict

Expanding-window out-of-sample prediction with a unified estimator interface.

::: eapctf.predict
    options:
      show_submodules: true
