# eapctf.timeseries

Time-series alpha estimation, GRS test, and spanning test.

::: eapctf.timeseries
    options:
      show_submodules: true
