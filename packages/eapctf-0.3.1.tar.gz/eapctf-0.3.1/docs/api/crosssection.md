# eapctf.crosssection

Fama-MacBeth cross-sectional regressions and multiple-testing correction.

::: eapctf.crosssection
    options:
      show_submodules: true
