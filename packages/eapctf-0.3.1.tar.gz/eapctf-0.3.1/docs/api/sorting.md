# eapctf.sorting

Portfolio sorting, factor construction, and long-short portfolio utilities.

::: eapctf.sorting
    options:
      show_submodules: true
