# eapctf.ctf

CTF local pipeline for running, evaluating, validating, and submitting model scripts to the Common Task Framework.

::: eapctf.ctf
    options:
      show_submodules: true
      members:
        - run_local
        - compute_metrics
        - validate
        - fetch_leaderboard
        - pipeline
        - download_ctf_data
        - build_submission
        - submit
        - predictions_to_ctf_weights
        - ctf_rank_normalize
        - ctf_select_features
        - ctf_expanding_window_oos
        - ctf_conformal_oos
        - AdaptiveConformalInference
