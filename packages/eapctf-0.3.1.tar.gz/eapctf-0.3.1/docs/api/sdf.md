# eapctf.sdf

Stochastic discount factor estimation via GMM and Hansen-Jagannathan distance.

::: eapctf.sdf
    options:
      show_submodules: true
