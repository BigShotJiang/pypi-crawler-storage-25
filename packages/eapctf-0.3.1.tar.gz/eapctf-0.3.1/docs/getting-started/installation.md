# Installation

## Requirements

- Python 3.11 or later
- [uv](https://docs.astral.sh/uv/) (recommended) or pip

## Basic Install

```bash
# with uv
uv add eapctf

# with pip
pip install eapctf
```

This installs the core package with all modules except optional ML backends.

## Optional Extras

### CTF data download

Adds WRDS connectivity for downloading CTF data directly:

```bash
uv add "eapctf[ctf]"
```

Includes: `wrds`, `python-dotenv`, `requests`.

### ML backends

Adds PyTorch and LightGBM for the `NeuralNetPredictor` and `LightGBMPredictor` in
`eapctf.predict`:

```bash
uv add "eapctf[ml]"
```

Includes: `torch`, `lightgbm`.

### Development

```bash
uv sync --dev
```

Adds: `pytest`, `ruff`, `mypy`, `pandas-stubs`, `pytest-cov`.

### Documentation

```bash
uv sync --extra docs
```

Adds: `mkdocs-material`, `mkdocstrings[python]`, and related plugins.

## Verifying the Install

```python
import eapctf
print(eapctf.__version__)  # 0.1.0
```

## CTF Data

The CTF competition data must be downloaded separately from WRDS. The data files
(`ctff_chars.parquet`, `ctff_daily_ret.parquet`, `ctff_features.parquet`) are large
(approximately 3.4 GB total) and are not distributed with the package.

See [Running Locally](../ctf/running-locally.md#data-download) for instructions.
