"""
tests/test_morphe_metrics.py
Unit tests for morphe-metrics.

Run: python -m pytest tests/ -v

ORCID: 0000-0002-3315-7907
CANARY: MayaNexusVS2026NLL_Bengaluru_Narasimha
"""

import numpy as np
import pytest
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from morphe_metrics import (
    compute_efc, interpret_efc, efc_summary,
    EFCTracker, topology_delta, edge_retention_rate,
    field_alignment_score, bhaya_quiescence_check, buddhi_curve_check,
    VAIRAGYA_PHYSICS_CONSTANT,
)


# ── core ─────────────────────────────────────────────────────────────────────

def test_efc_perfect_positive():
    field = np.array([0.1, 0.5, 0.9])
    probs = np.array([0.1, 0.5, 0.9])
    efc = compute_efc(field, probs)
    assert abs(efc - 1.0) < 1e-5, f"Expected 1.0, got {efc}"

def test_efc_perfect_negative():
    field = np.array([0.1, 0.5, 0.9])
    probs = np.array([0.9, 0.5, 0.1])
    efc = compute_efc(field, probs)
    assert abs(efc + 1.0) < 1e-5, f"Expected -1.0, got {efc}"

def test_efc_constant_field_returns_zero():
    field = np.array([0.5, 0.5, 0.5, 0.5])
    probs = np.array([0.1, 0.9, 0.3, 0.7])
    assert compute_efc(field, probs) == 0.0

def test_efc_too_few_samples():
    assert compute_efc([0.5, 0.5], [0.5, 0.5]) == 0.0

def test_efc_mismatched_lengths():
    with pytest.raises(ValueError):
        compute_efc([0.1, 0.5, 0.9], [0.1, 0.5])

def test_efc_p3_range():
    # P3 empirical result: EFC in [-0.019, -0.009]
    rng = np.random.default_rng(2315)
    field = rng.uniform(0, 1, 500)
    # Slightly anti-correlated probs to reproduce exploratory regime
    probs = 1.0 - field + rng.normal(0, 0.3, 500)
    probs = np.clip(probs, 0, 1)
    efc = compute_efc(field, probs)
    assert efc < 0.0, f"Expected negative EFC (exploratory), got {efc}"

def test_vairagya_constant():
    assert VAIRAGYA_PHYSICS_CONSTANT == 0.002315


# ── interpret ─────────────────────────────────────────────────────────────────

def test_interpret_exploratory():
    assert interpret_efc(-0.015) == "exploratory"

def test_interpret_random():
    assert interpret_efc(0.0) == "random"

def test_interpret_guided():
    assert interpret_efc(0.3) == "guided"

def test_interpret_strongly_guided():
    assert interpret_efc(0.8) == "strongly_guided"

def test_interpret_pathological():
    assert interpret_efc(-0.5) == "pathological"


# ── summary ───────────────────────────────────────────────────────────────────

def test_efc_summary_keys():
    field = np.linspace(0, 1, 20)
    probs = np.linspace(0, 1, 20)
    s = efc_summary(field, probs)
    for key in ["efc", "label", "n_samples", "field_mean", "field_std",
                "prob_mean", "prob_std", "p4_target"]:
        assert key in s, f"Missing key: {key}"

def test_efc_summary_p4_target():
    field = np.linspace(0, 1, 20)
    probs = np.linspace(0, 1, 20)
    s = efc_summary(field, probs)
    assert s["p4_target"] == True   # perfectly guided → EFC=1


# ── tracker ───────────────────────────────────────────────────────────────────

def test_tracker_update_and_summary():
    tracker = EFCTracker()
    rng = np.random.default_rng(42)
    for epoch in range(1, 11):
        f = rng.uniform(0, 1, 100)
        p = f + rng.normal(0, 0.1, 100)
        p = np.clip(p, 0, 1)
        tracker.update(epoch, f, p)
    s = tracker.summary()
    assert s["n_epochs"] == 10
    assert "final_efc" in s
    assert "p4_achieved" in s

def test_tracker_save_csv(tmp_path):
    tracker = EFCTracker()
    tracker.update(1, [0.1, 0.5, 0.9], [0.1, 0.5, 0.9])
    csv_path = str(tmp_path / "efc.csv")
    tracker.save_csv(csv_path)
    import csv
    with open(csv_path) as fh:
        rows = list(csv.DictReader(fh))
    assert len(rows) == 1
    assert float(rows[0]["efc"]) > 0.99


# ── topology ─────────────────────────────────────────────────────────────────

def test_topology_delta_growth():
    d = topology_delta(100, 150)
    assert d["direction"] == "growth"
    assert d["delta"] == 50

def test_topology_delta_pruning():
    d = topology_delta(100, 80)
    assert d["direction"] == "pruning"

def test_topology_delta_stable():
    d = topology_delta(100, 100)
    assert d["direction"] == "stable"

def test_edge_retention_rate():
    formed  = [1, 1, 1, 1, 1]
    removed = [10, 10, 3, 10, 2]   # 3 persist >= 5 steps, 2 don't
    rate = edge_retention_rate(formed, removed, k=5)
    assert abs(rate - 0.6) < 1e-5

def test_field_alignment_score_aligned():
    edges = np.array([[1, 0], [0, 1], [1, 0]])
    grads = np.array([[1, 0], [0, 1], [1, 0]])
    score = field_alignment_score(edges, grads)
    assert abs(score - 1.0) < 1e-5

def test_field_alignment_score_opposing():
    edges = np.array([[1, 0], [0, 1]])
    grads = np.array([[-1, 0], [0, -1]])
    score = field_alignment_score(edges, grads)
    assert abs(score + 1.0) < 1e-5


# ── series constants ─────────────────────────────────────────────────────────

def test_bhaya_confirmed():
    vals = [0.003, 0.0032, 0.0034, 0.0031]
    r = bhaya_quiescence_check(vals)
    assert r["status"] == "CONFIRMED"

def test_bhaya_modified():
    vals = [0.15, 0.16, 0.14]   # ~48x above baseline (P3 result)
    r = bhaya_quiescence_check(vals)
    assert r["status"] == "MODIFIED"
    assert r["ratio"] > 10

def test_bhaya_insufficient():
    r = bhaya_quiescence_check([0.003])
    assert r["status"] == "INSUFFICIENT_DATA"

def test_buddhi_s_curve():
    # Synthesise S-curve
    t = np.linspace(-6, 6, 100)
    trajectory = 1 / (1 + np.exp(-t))
    r = buddhi_curve_check(trajectory)
    assert r["status"] == "S_CURVE"

def test_buddhi_flat():
    trajectory = np.ones(50) * 0.5
    r = buddhi_curve_check(trajectory)
    assert r["status"] == "FLAT"
