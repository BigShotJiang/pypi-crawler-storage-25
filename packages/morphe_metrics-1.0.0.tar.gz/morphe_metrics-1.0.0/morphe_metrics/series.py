"""
morphe_metrics.series
---------------------
Cross-substrate series constant checks for the Maya-Morphe series.

These are mandatory checks in every Maya-Morphe experiment.
Their presence or absence in a new substrate is itself a publishable finding.

Bhaya Quiescence Law : aggregate KILL+SUSPEND rate = 0.32% (SNN baseline)
                       MODIFIED in morphogenetic substrate (P3: ~48x above)
Buddhi S-curve       : deterministic S-curve convergence across substrates

ORCID: 0000-0002-3315-7907
CANARY: MayaNexusVS2026NLL_Bengaluru_Narasimha
"""

from __future__ import annotations
import numpy as np
from typing import Union, Dict, List


BHAYA_SNN_LAW    = 0.0032   # confirmed across Maya P1-P9, Maya-Defence
VAIRAGYA_PHYSICS = 0.002315  # ORCID-derived


def bhaya_quiescence_check(
    bhaya_values:    Union[np.ndarray, list],
    tolerance_frac:  float = 0.20,
) -> Dict:
    """
    Test whether Bhaya quiescence rate is consistent with the SNN law (0.32%).

    A CONFIRMED result means the morphogenetic substrate behaves like the SNN
    substrate. A MODIFIED result means the substrate has a different quiescence
    regime — which is itself a finding worth reporting.

    Parameters
    ----------
    bhaya_values   : array-like — Bhaya crisis fraction values across trials.
                     Each value should be in [0, 1].
    tolerance_frac : float — fractional tolerance around 0.0032 for CONFIRMED.
                     Default 0.20 means +/- 20% of 0.0032.

    Returns
    -------
    dict:
        mean_bhaya   : float
        law_value    : float  — 0.0032
        ratio        : float  — mean_bhaya / 0.0032
        status       : str    — 'CONFIRMED' | 'MODIFIED' | 'INSUFFICIENT_DATA'
        n_trials     : int
        interpretation : str
    """
    b = np.asarray(bhaya_values, dtype=np.float32).ravel()
    if len(b) < 3:
        return {
            "mean_bhaya": 0.0, "law_value": BHAYA_SNN_LAW,
            "ratio": 0.0, "status": "INSUFFICIENT_DATA",
            "n_trials": len(b), "interpretation": "Need >= 3 trials.",
        }

    mean_b = float(b.mean())
    ratio  = mean_b / BHAYA_SNN_LAW
    lo     = BHAYA_SNN_LAW * (1 - tolerance_frac)
    hi     = BHAYA_SNN_LAW * (1 + tolerance_frac)
    status = "CONFIRMED" if lo <= mean_b <= hi else "MODIFIED"

    if status == "CONFIRMED":
        interp = f"Bhaya quiescence law holds in this substrate ({mean_b:.4f} ≈ 0.0032)."
    else:
        interp = (
            f"Bhaya quiescence law MODIFIED in this substrate. "
            f"Mean={mean_b:.4f}, ratio={ratio:.1f}x above SNN baseline. "
            f"This deviation is a substrate-specific finding."
        )

    return {
        "mean_bhaya":    round(mean_b, 6),
        "law_value":     BHAYA_SNN_LAW,
        "ratio":         round(ratio, 2),
        "status":        status,
        "n_trials":      len(b),
        "interpretation": interp,
    }


def buddhi_curve_check(
    buddhi_trajectory: Union[np.ndarray, list],
) -> Dict:
    """
    Check whether a Buddhi confidence trajectory follows the S-curve pattern
    confirmed as a series constant across SNN, LLM, and ESN substrates.

    The S-curve is characterised by:
      - Slow initial rise (epochs 0-30%)
      - Rapid mid-phase growth (epochs 30-70%)
      - Plateau near saturation (epochs 70-100%)

    Parameters
    ----------
    buddhi_trajectory : array-like, shape (T,)
        Buddhi (confidence/discriminative score) values over T epochs.
        Should be in [0, 1] or normalised to that range.

    Returns
    -------
    dict:
        status           : str   — 'S_CURVE' | 'LINEAR' | 'FLAT' | 'INSUFFICIENT'
        early_slope      : float — mean rate of change in first 30%
        mid_slope        : float — mean rate of change in middle 40%
        late_slope       : float — mean rate of change in last 30%
        s_curve_ratio    : float — mid_slope / max(early_slope, late_slope)
        interpretation   : str
    """
    t = np.asarray(buddhi_trajectory, dtype=np.float32).ravel()
    if len(t) < 10:
        return {"status": "INSUFFICIENT", "interpretation": "Need >= 10 epochs."}

    n      = len(t)
    early  = t[:int(n*0.3)]
    mid    = t[int(n*0.3):int(n*0.7)]
    late   = t[int(n*0.7):]

    def slope(arr):
        if len(arr) < 2:
            return 0.0
        return float(np.diff(arr).mean())

    es = abs(slope(early))
    ms = abs(slope(mid))
    ls = abs(slope(late))
    ratio = ms / max(es, ls, 1e-8)

    if t.std() < 1e-4:
        status = "FLAT"
        interp = "Buddhi trajectory is flat — no learning signal detected."
    elif ratio > 1.5:
        status = "S_CURVE"
        interp = (
            f"Buddhi S-curve confirmed (mid/flank ratio={ratio:.2f}). "
            f"Consistent with series constant across SNN, LLM, ESN substrates."
        )
    else:
        status = "LINEAR"
        interp = (
            f"Buddhi trajectory is approximately linear (ratio={ratio:.2f}). "
            f"S-curve pattern not confirmed in this substrate."
        )

    return {
        "status":        status,
        "early_slope":   round(es, 6),
        "mid_slope":     round(ms, 6),
        "late_slope":    round(ls, 6),
        "s_curve_ratio": round(ratio, 3),
        "interpretation": interp,
    }
