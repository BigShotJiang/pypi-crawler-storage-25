"""
morphe_metrics.tracker
----------------------
EFCTracker: epoch-level EFC logging for training loops.

Records EFC at every epoch, computes trajectory statistics,
and detects sign crossings (exploratory → guided transition).

ORCID: 0000-0002-3315-7907
CANARY: MayaNexusVS2026NLL_Bengaluru_Narasimha
"""

from __future__ import annotations
import csv, numpy as np
from typing import List, Optional, Dict
from .core import compute_efc, interpret_efc


class EFCTracker:
    """
    Track EFC across training epochs.

    Usage
    -----
    tracker = EFCTracker()

    # Inside training loop:
    tracker.update(epoch, field_at_candidate, edge_formation_prob)

    # After training:
    tracker.save_csv("logs/efc_trajectory.csv")
    summary = tracker.summary()
    """

    def __init__(self):
        self._epochs: List[int]   = []
        self._efc:    List[float] = []
        self._labels: List[str]   = []

    def update(
        self,
        epoch: int,
        field_at_candidate,
        edge_formation_prob,
        min_samples: int = 3,
    ) -> float:
        """
        Record EFC for one epoch.

        Parameters
        ----------
        epoch               : int   — current training epoch (1-indexed)
        field_at_candidate  : array-like — field values at candidate nodes
        edge_formation_prob : array-like — edge formation probabilities

        Returns
        -------
        float : EFC value recorded for this epoch
        """
        efc   = compute_efc(field_at_candidate, edge_formation_prob, min_samples)
        label = interpret_efc(efc)
        self._epochs.append(epoch)
        self._efc.append(efc)
        self._labels.append(label)
        return efc

    def summary(self) -> Dict:
        """
        Return trajectory summary statistics.

        Returns
        -------
        dict with keys:
            n_epochs        : int
            final_efc       : float
            final_label     : str
            min_efc         : float
            max_efc         : float
            mean_efc        : float
            sign_crossings  : int   — number of times EFC crosses zero
            p4_achieved     : bool  — True if final EFC > 0
            first_positive  : int | None — epoch at which EFC first went positive
        """
        if not self._efc:
            return {}

        arr   = np.array(self._efc)
        signs = np.sign(arr)
        crossings = int(np.sum(np.diff(signs) != 0))

        first_pos = None
        for ep, val in zip(self._epochs, self._efc):
            if val > 0:
                first_pos = ep
                break

        return {
            "n_epochs":       len(self._epochs),
            "final_efc":      self._efc[-1],
            "final_label":    self._labels[-1],
            "min_efc":        float(arr.min()),
            "max_efc":        float(arr.max()),
            "mean_efc":       float(arr.mean()),
            "sign_crossings": crossings,
            "p4_achieved":    self._efc[-1] > 0.0,
            "first_positive": first_pos,
        }

    def save_csv(self, path: str) -> None:
        """Save epoch-level EFC trajectory to CSV."""
        import os
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=["epoch", "efc", "label"])
            w.writeheader()
            for ep, val, lab in zip(self._epochs, self._efc, self._labels):
                w.writerow({"epoch": ep, "efc": round(val, 6), "label": lab})

    def efc_values(self) -> List[float]:
        return list(self._efc)

    def epochs(self) -> List[int]:
        return list(self._epochs)
