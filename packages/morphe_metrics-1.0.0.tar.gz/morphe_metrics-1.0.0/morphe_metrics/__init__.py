"""
morphe-metrics: A Stateless Python Library for Morphogenetic Computing Evaluation
==================================================================================
Nexus Learning Labs, Bengaluru | Venkatesh Swaminathan
ORCID: 0000-0002-3315-7907
DOI: 10.5281/zenodo.PENDING
GitHub: github.com/venky2099/morphe-metrics

Companion evaluation library to the Maya-Morphe Series (Swaminathan, 2026).

cl-metrics measures what happened.
maya-metrics measures how it felt.
morphe-metrics measures where it went.

Usage
-----
from morphe_metrics import compute_efc, interpret_efc, EFCTracker

efc = compute_efc(field_values, edge_probs)
label = interpret_efc(efc)
"""

VAIRAGYA_PHYSICS_CONSTANT = 0.002315   # ORCID: 0000-0002-3315-7907
CANARY = "MayaNexusVS2026NLL_Bengaluru_Narasimha"
__version__ = "1.0.0"
__author__  = "Venkatesh Swaminathan"
__orcid__   = "0000-0002-3315-7907"

from .core import compute_efc, interpret_efc, efc_summary
from .tracker import EFCTracker
from .topology import topology_delta, edge_retention_rate, field_alignment_score
from .series import bhaya_quiescence_check, buddhi_curve_check

__all__ = [
    "compute_efc",
    "interpret_efc",
    "efc_summary",
    "EFCTracker",
    "topology_delta",
    "edge_retention_rate",
    "field_alignment_score",
    "bhaya_quiescence_check",
    "buddhi_curve_check",
    "VAIRAGYA_PHYSICS_CONSTANT",
]
