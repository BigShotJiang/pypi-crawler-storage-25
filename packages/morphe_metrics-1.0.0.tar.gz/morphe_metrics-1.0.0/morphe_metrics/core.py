"""
morphe_metrics.core
-------------------
Edge-Field Concordance (EFC): the primary metric of morphogenetic computing.

EFC = Pearson correlation between bioelectric field strength at candidate
neighbour nodes and edge formation probability at those nodes.

Interpretation
--------------
  EFC < -0.05  : Anti-field formation (pathological)
  EFC in [-0.05, -0.001] : Exploratory formation (growth-cone analogy;
                            biologically consistent starting condition)
  EFC ~ 0.0    : Random formation (no field guidance)
  EFC > 0.001  : Field-guided formation (committed pathfinding)
  EFC > 0.5    : Strong field guidance
  EFC = 1.0    : Perfect field guidance (theoretical ceiling)

Reference
---------
Swaminathan, V. (2026). Maya-Morphe P3: Axon. DOI: 10.5281/zenodo.20102536
Bhattacharya et al. (2021). Galvanotaxis of cranial neural crest cells.
  Developmental Cell 56(1), 26-38.

ORCID: 0000-0002-3315-7907
CANARY: MayaNexusVS2026NLL_Bengaluru_Narasimha
"""

from __future__ import annotations
import numpy as np
from typing import Union, Dict

# Vairagya physics constant — ORCID-derived provenance signature
VAIRAGYA_PHYSICS_CONSTANT = 0.002315


def compute_efc(
    field_at_candidate: Union[np.ndarray, list],
    edge_formation_prob: Union[np.ndarray, list],
    min_samples: int = 3,
) -> float:
    """
    Compute Edge-Field Concordance (EFC).

    EFC is the Pearson correlation coefficient between the bioelectric field
    strength observed at candidate neighbour nodes and the probability that
    an edge forms toward each candidate.

    Parameters
    ----------
    field_at_candidate : array-like, shape (N,)
        Bioelectric field strength (or voltage) at each candidate neighbour
        node evaluated during edge formation. Values should be non-negative
        floats in [0, 1] (normalised voltage) but are not strictly required
        to be bounded. Can be a raw voltage tensor detached to CPU numpy.

    edge_formation_prob : array-like, shape (N,)
        Probability (or soft Gumbel-Softmax score) that an edge forms toward
        each candidate. Shape must match field_at_candidate.

    min_samples : int, default 3
        Minimum number of samples required to compute a meaningful
        correlation. Returns 0.0 if below threshold.

    Returns
    -------
    float
        EFC value in [-1, 1].
        Returns 0.0 if inputs are degenerate (constant, empty, or too small).

    Examples
    --------
    >>> import numpy as np
    >>> field = np.array([0.8, 0.3, 0.9, 0.1, 0.7])
    >>> probs = np.array([0.7, 0.2, 0.85, 0.15, 0.6])
    >>> compute_efc(field, probs)
    0.999...   # near-perfect field guidance

    >>> field = np.array([0.8, 0.3, 0.9, 0.1, 0.7])
    >>> probs = np.array([0.2, 0.7, 0.1, 0.85, 0.3])
    >>> compute_efc(field, probs)
    -0.98...   # anti-field (exploratory or pathological)
    """
    f = np.asarray(field_at_candidate, dtype=np.float32).ravel()
    s = np.asarray(edge_formation_prob, dtype=np.float32).ravel()

    if len(f) < min_samples or len(s) < min_samples:
        return 0.0
    if len(f) != len(s):
        raise ValueError(
            f"field_at_candidate and edge_formation_prob must have the same "
            f"length. Got {len(f)} and {len(s)}."
        )

    f_std = f.std()
    s_std = s.std()
    if f_std < 1e-8 or s_std < 1e-8:
        return 0.0

    fn = (f - f.mean()) / f_std
    sn = (s - s.mean()) / s_std
    return float((fn * sn).mean())


def interpret_efc(efc: float) -> str:
    """
    Return a human-readable interpretation of an EFC value.

    Parameters
    ----------
    efc : float
        EFC value from compute_efc().

    Returns
    -------
    str
        One of: 'pathological', 'exploratory', 'random', 'guided', 'strongly_guided'
    """
    if efc < -0.05:
        return "pathological"
    elif efc < -0.001:
        return "exploratory"
    elif efc <= 0.001:
        return "random"
    elif efc <= 0.5:
        return "guided"
    else:
        return "strongly_guided"


def efc_summary(
    field_at_candidate: Union[np.ndarray, list],
    edge_formation_prob: Union[np.ndarray, list],
    min_samples: int = 3,
) -> Dict:
    """
    Compute EFC and return a full summary dictionary.

    Returns
    -------
    dict with keys:
        efc         : float  — EFC value
        label       : str    — human-readable interpretation
        n_samples   : int    — number of candidate edges evaluated
        field_mean  : float  — mean field strength at candidates
        field_std   : float  — std of field strength
        prob_mean   : float  — mean edge formation probability
        prob_std    : float  — std of edge formation probability
        p4_target   : bool   — True if EFC > 0 (field-guided; P4 objective)
    """
    f = np.asarray(field_at_candidate, dtype=np.float32).ravel()
    s = np.asarray(edge_formation_prob, dtype=np.float32).ravel()
    efc = compute_efc(f, s, min_samples)
    return {
        "efc":        efc,
        "label":      interpret_efc(efc),
        "n_samples":  len(f),
        "field_mean": float(f.mean()) if len(f) > 0 else 0.0,
        "field_std":  float(f.std())  if len(f) > 0 else 0.0,
        "prob_mean":  float(s.mean()) if len(s) > 0 else 0.0,
        "prob_std":   float(s.std())  if len(s) > 0 else 0.0,
        "p4_target":  efc > 0.0,
    }
