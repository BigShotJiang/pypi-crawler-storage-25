"""
morphe_metrics.topology
-----------------------
Topology-level metrics for morphogenetic computing experiments.

topology_delta        : edges added / removed during self-organisation
edge_retention_rate   : fraction of formed edges that persist > k steps
field_alignment_score : directional alignment between edges and field gradient

ORCID: 0000-0002-3315-7907
CANARY: MayaNexusVS2026NLL_Bengaluru_Narasimha
"""

from __future__ import annotations
import numpy as np
from typing import Union, Tuple


def topology_delta(
    edges_before: int,
    edges_after: int,
) -> dict:
    """
    Compute topology change during self-organisation.

    Parameters
    ----------
    edges_before : int — edge count before self-organisation event
    edges_after  : int — edge count after self-organisation event

    Returns
    -------
    dict:
        delta      : int   — net edge change (positive = growth)
        delta_frac : float — fractional change relative to before
        direction  : str   — 'growth', 'pruning', or 'stable'
    """
    delta = edges_after - edges_before
    frac  = delta / max(edges_before, 1)
    if delta > 0:
        direction = "growth"
    elif delta < 0:
        direction = "pruning"
    else:
        direction = "stable"
    return {"delta": delta, "delta_frac": round(frac, 4), "direction": direction}


def edge_retention_rate(
    edge_formation_times: Union[np.ndarray, list],
    edge_removal_times:   Union[np.ndarray, list],
    k: int = 5,
) -> float:
    """
    Fraction of formed edges that persist for at least k steps.

    Distinguishes committed from transient connections — an indicator
    that field-guided pathfinding produced stable topology rather than
    ephemeral probing.

    Parameters
    ----------
    edge_formation_times : array-like, shape (N,)
        Step at which each edge was formed.
    edge_removal_times   : array-like, shape (N,)
        Step at which each edge was removed. Use np.inf for edges
        that were never removed.
    k : int, default 5
        Persistence threshold in steps.

    Returns
    -------
    float : fraction of edges that persisted >= k steps. In [0, 1].
    """
    formed  = np.asarray(edge_formation_times, dtype=np.float32)
    removed = np.asarray(edge_removal_times,   dtype=np.float32)
    if len(formed) == 0:
        return 0.0
    lifetimes = removed - formed
    persistent = (lifetimes >= k).sum()
    return float(persistent / len(formed))


def field_alignment_score(
    edge_directions:  Union[np.ndarray, list],
    field_gradients:  Union[np.ndarray, list],
) -> float:
    """
    Mean cosine similarity between edge direction vectors and field
    gradient vectors at edge origin nodes.

    Directional commitment metric — complements EFC (which is
    correlational) with an explicit geometric alignment measure.

    Parameters
    ----------
    edge_directions : array-like, shape (N, 2) or (N, 3)
        Unit vectors indicating direction of each formed edge
        (from recovering node toward candidate neighbour).
    field_gradients : array-like, shape (N, 2) or (N, 3)
        Field gradient vectors at the recovering node for each edge.
        Need not be unit vectors — normalised internally.

    Returns
    -------
    float : mean cosine similarity in [-1, 1].
        1.0  = all edges perfectly aligned with field gradient
        0.0  = edges orthogonal to field (random)
       -1.0  = all edges opposing field gradient (anti-field)
    """
    e = np.asarray(edge_directions,  dtype=np.float32)
    g = np.asarray(field_gradients,  dtype=np.float32)

    if e.ndim != 2 or g.ndim != 2 or e.shape != g.shape:
        raise ValueError("edge_directions and field_gradients must have shape (N, D)")
    if len(e) == 0:
        return 0.0

    e_norm = e / (np.linalg.norm(e, axis=1, keepdims=True) + 1e-8)
    g_norm = g / (np.linalg.norm(g, axis=1, keepdims=True) + 1e-8)
    cosines = (e_norm * g_norm).sum(axis=1)
    return float(cosines.mean())
