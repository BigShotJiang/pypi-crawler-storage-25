import sys
from CalculusCalculator.main import MainWindow
from PySide6.QtWidgets import QApplication

def run():
    # 主程序
    app = QApplication(sys.argv)
    mainWindow = MainWindow()
    mainWindow.show()
    sys.exit(app.exec())
