"""
Real-time inference server for Neon VLA with Real-Time Chunking (RTC).

Inspired by LeRobot/Physical Intelligence's RTC implementation
(Black et al., 2025 — "Real-Time Execution of Action Chunking Flow Policies").

Two key improvements over naive EMA smoothing:

1. **Inference-delay-aware execution** — Skip stale actions that correspond
   to timesteps the robot already executed during inference latency.

2. **Prefix-weighted blending** — Overlap region between old and new chunks
   uses decaying weights (linear/exponential) instead of uniform EMA.
   Early overlap = high trust in old prediction. Far future = trust new.

Runs on Thor (Jetson Orin) or any CUDA machine.
Provides HTTP API for real-time action prediction from camera + language.
"""

from __future__ import annotations

import json
import logging
import math
import time
from enum import Enum
from typing import Optional

import numpy as np
import torch

from neon.model.neon_vla import NeonOutput, NeonVLA

logger = logging.getLogger(__name__)


class BlendSchedule(str, Enum):
    """Blending schedule for overlap region between consecutive chunks."""
    EMA = "ema"          # Classic exponential moving average (Neon v1)
    LINEAR = "linear"    # Linear decay from 1→0 (RTC default)
    EXP = "exp"          # Exponential decay (smoother than linear)
    LATEST = "latest"    # Always use new chunk (no blending)


class ActionQueue:
    """Thread-safe action queue with RTC-style overlap blending.

    Manages the handoff between consecutive action chunks, handling:
    - Inference delay compensation (skip stale actions)
    - Prefix-weighted blending in overlap regions
    - Smooth transitions at chunk boundaries

    Inspired by LeRobot's ActionQueue but adapted for Neon's
    single-pass MLP architecture (no flow-matching denoising).
    """

    def __init__(
        self,
        blend_schedule: BlendSchedule = BlendSchedule.LINEAR,
        execution_horizon: int = 10,
        control_freq: float = 50.0,
    ):
        self.blend_schedule = blend_schedule
        self.execution_horizon = execution_horizon
        self.control_freq = control_freq
        self.dt = 1.0 / control_freq  # seconds per control step

        # Current action chunk being executed
        self._actions: Optional[np.ndarray] = None       # (chunk_size, action_dim)
        self._raw_actions: Optional[np.ndarray] = None
        self._index: int = 0                              # next action to execute

        # Previous chunk's leftover (for blending)
        self._prev_leftover: Optional[np.ndarray] = None

        # Timing
        self._last_inference_time: float = 0.0  # seconds
        self._inference_start: Optional[float] = None

    def mark_inference_start(self):
        """Call this right before running model inference."""
        self._inference_start = time.time()

    def update(
        self,
        actions: np.ndarray,
        raw_actions: Optional[np.ndarray] = None,
        inference_latency: Optional[float] = None,
    ):
        """Update the queue with a new predicted chunk.

        This is where the RTC magic happens:
        1. Compute how many steps elapsed during inference (delay)
        2. Save leftover from old chunk as prefix
        3. Blend overlap region with prefix weights
        4. Skip first `delay` actions (robot already moved past them)

        Args:
            actions: New predicted chunk (chunk_size, action_dim), normalized [-1,1]
            raw_actions: Denormalized actions (chunk_size, action_dim)
            inference_latency: Time spent on inference in seconds.
                If None, computed from mark_inference_start().
        """
        # Compute inference delay in timesteps
        if inference_latency is None and self._inference_start is not None:
            inference_latency = time.time() - self._inference_start
        if inference_latency is None:
            inference_latency = 0.0

        self._last_inference_time = inference_latency
        delay_steps = max(0, int(math.ceil(inference_latency * self.control_freq)))

        # Save leftover from current chunk before replacing
        if self._actions is not None and self._index < len(self._actions):
            self._prev_leftover = self._actions[self._index:].copy()
        else:
            self._prev_leftover = None

        # Blend overlap region
        blended_actions = self._blend_with_prefix(actions, delay_steps)

        # Skip stale actions (robot already executed during inference)
        skip = min(delay_steps, len(blended_actions) - 1)
        self._actions = blended_actions[skip:]
        if raw_actions is not None:
            self._raw_actions = raw_actions[skip:]
        else:
            self._raw_actions = None
        self._index = 0

        logger.debug(
            f"ActionQueue updated: latency={inference_latency*1000:.1f}ms, "
            f"delay={delay_steps} steps, skip={skip}, "
            f"remaining={len(self._actions)} actions, "
            f"blend={self.blend_schedule.value}"
        )

    def _blend_with_prefix(self, new_actions: np.ndarray, delay_steps: int) -> np.ndarray:
        """Blend new chunk with leftover prefix from previous chunk.

        The prefix weights decay from 1.0 (trust old) to 0.0 (trust new)
        across the overlap region. This is the core RTC insight adapted
        for single-pass models.

        Args:
            new_actions: New predicted chunk (chunk_size, action_dim)
            delay_steps: Number of steps elapsed during inference

        Returns:
            Blended actions (chunk_size, action_dim)
        """
        if self._prev_leftover is None or self.blend_schedule == BlendSchedule.LATEST:
            return new_actions.copy()

        chunk_size = len(new_actions)
        prefix_len = len(self._prev_leftover)

        # Overlap region = min(prefix available, execution_horizon, chunk_size)
        overlap = min(prefix_len, self.execution_horizon, chunk_size)
        if overlap <= 0:
            return new_actions.copy()

        # Compute prefix weights
        weights = self._get_prefix_weights(delay_steps, overlap, chunk_size)

        # Expand prefix to match new chunk length (zero-pad if shorter)
        prefix_padded = np.zeros_like(new_actions)
        copy_len = min(prefix_len, chunk_size)
        prefix_padded[:copy_len] = self._prev_leftover[:copy_len]

        # Blend: w * prefix + (1-w) * new
        weights_2d = weights[:, np.newaxis]  # (chunk_size, 1) for broadcasting
        blended = weights_2d * prefix_padded + (1.0 - weights_2d) * new_actions

        return blended

    def _get_prefix_weights(self, start: int, end: int, total: int) -> np.ndarray:
        """Compute prefix blending weights.

        Weights are 1.0 for already-committed steps, linearly/exponentially
        decaying in the transition region, and 0.0 for free steps.

        Matches LeRobot's RTCProcessor.get_prefix_weights() but in numpy.

        Args:
            start: First free step (= inference delay)
            end: End of transition region (= execution_horizon)
            total: Total chunk size

        Returns:
            weights: (total,) array with values in [0, 1]
        """
        start = min(start, end)
        weights = np.zeros(total, dtype=np.float32)

        if self.blend_schedule == BlendSchedule.EMA:
            # Classic EMA: uniform alpha across all steps (Neon v1 behavior)
            alpha = 0.3  # trust in old prediction
            weights[:end] = alpha
            return weights

        elif self.blend_schedule == BlendSchedule.LINEAR:
            # Leading ones (committed steps)
            weights[:start] = 1.0
            # Linear decay from 1→0
            transition_len = end - start
            if transition_len > 0:
                decay = np.linspace(1.0, 0.0, transition_len + 2)[1:-1]
                weights[start:end] = decay
            return weights

        elif self.blend_schedule == BlendSchedule.EXP:
            # Leading ones
            weights[:start] = 1.0
            # Exponential decay
            transition_len = end - start
            if transition_len > 0:
                lin = np.linspace(1.0, 0.0, transition_len + 2)[1:-1]
                exp_weights = lin * np.expm1(lin) / (math.e - 1)
                weights[start:end] = exp_weights
            return weights

        return weights  # LATEST: all zeros = fully trust new

    def get(self) -> Optional[np.ndarray]:
        """Get the next action from the queue.

        Returns:
            Next action (action_dim,) or None if empty.
        """
        if self._actions is None or self._index >= len(self._actions):
            return None
        action = self._actions[self._index].copy()
        self._index += 1
        return action

    def get_raw(self) -> Optional[np.ndarray]:
        """Get the next raw (denormalized) action."""
        if self._raw_actions is None or self._index - 1 >= len(self._raw_actions):
            return None
        # -1 because get() already incremented index
        return self._raw_actions[self._index - 1].copy()

    def remaining(self) -> int:
        """Number of unconsumed actions."""
        if self._actions is None:
            return 0
        return max(0, len(self._actions) - self._index)

    def empty(self) -> bool:
        """Check if all actions have been consumed."""
        return self.remaining() <= 0

    @property
    def inference_latency_ms(self) -> float:
        """Last measured inference latency in milliseconds."""
        return self._last_inference_time * 1000


class NeonInferenceServer:
    """Real-time inference server with RTC-style action queue.

    Three modes:
    - **Legacy** (smooth=True): EMA blending like Neon v1. Simple, no queue.
    - **RTC** (rtc=True): Inference-delay-aware queue with prefix blending.
    - **Photon** (photon=True): Adaptive routing + speculative decoding + compiled.
      Inspired by Moondream Photon's co-designed architecture for real-time inference.

    The RTC mode is recommended for real robot deployment. It handles
    the fundamental problem that inference takes time, and during that
    time the robot moves forward — so the first few predicted actions
    are already stale when they arrive.

    Photon mode adds on top of RTC: adaptive compute routing skips the
    expensive Flow/DiT head for ~60% of actions (simple motions), achieving
    up to 100Hz on Jetson Orin for easy actions, ~50Hz average.
    """

    def __init__(
        self,
        model_path: str = "cagataydev/neon-g1-v1",
        device: str = "auto",
        blend_schedule: str = "linear",
        execution_horizon: int = 10,
        control_freq: float = 50.0,
        photon: bool = False,
        compile_heads: bool = False,
    ):
        """Initialize the inference server.

        Args:
            model_path: HuggingFace model ID or local path
            device: Device for inference ("auto", "cuda", "mps", "cpu")
            blend_schedule: How to blend overlapping chunks
                "linear" — RTC linear decay (recommended)
                "exp" — RTC exponential decay (smoother)
                "ema" — Classic EMA (Neon v1 behavior)
                "latest" — No blending, always use newest prediction
            execution_horizon: How many steps into the future to blend.
                Higher = smoother transitions, slower to react.
                Lower = more responsive, potential discontinuities.
            control_freq: Robot control frequency in Hz (default: 50)
        """
        # Select device
        if device == "auto":
            if torch.cuda.is_available():
                self.device = torch.device("cuda")
            elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                self.device = torch.device("mps")
            else:
                self.device = torch.device("cpu")
        else:
            self.device = torch.device(device)

        logger.info(f"Loading Neon model from {model_path} on {self.device}")
        self.model = NeonVLA.from_pretrained(model_path, load_backbone=True)
        self.model.to(self.device)
        self.model.eval()

        # RTC action queue
        schedule = BlendSchedule(blend_schedule)
        self.action_queue = ActionQueue(
            blend_schedule=schedule,
            execution_horizon=execution_horizon,
            control_freq=control_freq,
        )

        # Legacy EMA smoothing (for backward compat)
        self._prev_actions: Optional[np.ndarray] = None
        self._smoothing_alpha = 0.7

        logger.info(
            f"Neon inference server ready: {self.model}, "
            f"blend={blend_schedule}, horizon={execution_horizon}"
        )

        # Photon inference engine (optional — adaptive routing + speculative + compiled)
        self._photon_engine = None
        if photon:
            try:
                from neon.model.photon import PhotonInferenceEngine
                self._photon_engine = PhotonInferenceEngine(
                    model=self.model,
                    device=str(self.device),
                    compile_heads=compile_heads,
                    use_speculative=True,
                    use_adaptive_routing=True,
                )
                logger.info("Photon inference engine enabled (speculative + adaptive routing)")
            except Exception as e:
                logger.warning(f"Photon engine init failed: {e}, using standard inference")
        elif compile_heads and torch.cuda.is_available():
            # Even without full Photon, compile heads for speed
            try:
                from neon.model.photon import compile_action_head
                self.model.action_head = compile_action_head(
                    self.model.action_head, mode="reduce-overhead"
                )
                logger.info("Action head compiled with torch.compile (no Photon engine)")
            except Exception as e:
                logger.warning(f"torch.compile failed: {e}")

    @torch.no_grad()
    def predict(
        self,
        image=None,
        video_frames: list = None,
        instruction: str = "",
        proprioception: np.ndarray = None,
        audio: np.ndarray = None,
        lidar: np.ndarray = None,
        eef_state: np.ndarray = None,
        speak: bool = False,
        smooth: bool = False,
        rtc: bool = True,
    ) -> NeonOutput:
        """Predict next actions from observations.

        Args:
            image: Current camera frame (PIL Image)
            video_frames: Recent camera frames
            instruction: Language instruction
            proprioception: Current joint positions
            audio: Raw audio waveform at 16kHz (samples,) — voice command
            lidar: Point cloud (N, 4) — (x, y, z, intensity) from L1 LiDAR
            eef_state: End-effector state (14,) — bimanual pos+quat
            speak: If True, generate speech response via PersonaPlex
            smooth: Apply legacy EMA smoothing (Neon v1)
            rtc: Use RTC action queue (recommended for real robot)

        Returns:
            NeonOutput with predicted actions (and optional speech_path)
        """
        # Mark inference start for delay calculation
        if rtc:
            self.action_queue.mark_inference_start()

        start = time.time()

        output = self.model.predict(
            image=image,
            video_frames=video_frames,
            instruction=instruction,
            proprioception=proprioception,
            audio=audio,
            lidar=lidar,
            eef_state=eef_state,
            speak=speak,
        )

        inference_latency = time.time() - start

        if rtc:
            # RTC mode: update queue with delay-aware blending
            self.action_queue.update(
                actions=output.actions,
                raw_actions=output.raw_actions,
                inference_latency=inference_latency,
            )
        elif smooth and self._prev_actions is not None:
            # Legacy EMA mode
            output.actions = (
                self._smoothing_alpha * output.actions
                + (1 - self._smoothing_alpha) * self._prev_actions
            )
            output.raw_actions = np.stack([
                self.model.action_space.denormalize(a) for a in output.actions
            ])

        self._prev_actions = output.actions.copy()

        logger.debug(
            f"Inference: {inference_latency*1000:.1f}ms, "
            f"queue: {self.action_queue.remaining()} actions"
        )

        return output

    def get_action(self) -> Optional[np.ndarray]:
        """Get next action from the RTC queue.

        Use this in the control loop:
            while running:
                action = server.get_action()
                if action is None:
                    output = server.predict(image, instruction, proprio, rtc=True)
                    action = server.get_action()
                robot.send(action)

        Returns:
            Next action (action_dim,) normalized [-1,1], or None if empty.
        """
        return self.action_queue.get()

    def actions_remaining(self) -> int:
        """How many actions left in the queue."""
        return self.action_queue.remaining()

    def reset(self):
        """Reset state (call between episodes)."""
        self._prev_actions = None
        self.action_queue = ActionQueue(
            blend_schedule=self.action_queue.blend_schedule,
            execution_horizon=self.action_queue.execution_horizon,
            control_freq=self.action_queue.control_freq,
        )


def main():
    """CLI entry point for the inference server."""
    import argparse

    parser = argparse.ArgumentParser(description="Neon Inference Server")
    parser.add_argument("--model", type=str, default="cagataydev/neon-g1-v1")
    parser.add_argument("--port", type=int, default=8300)
    parser.add_argument("--host", type=str, default="0.0.0.0")
    parser.add_argument("--blend", type=str, default="linear",
                        choices=["linear", "exp", "ema", "latest"],
                        help="Chunk blending schedule (default: linear)")
    parser.add_argument("--horizon", type=int, default=10,
                        help="Execution horizon for blending (default: 10)")
    parser.add_argument("--freq", type=float, default=50.0,
                        help="Control frequency in Hz (default: 50)")
    parser.add_argument("--photon", action="store_true",
                        help="Enable Photon inference engine (speculative + adaptive routing)")
    parser.add_argument("--compile", action="store_true",
                        help="Compile action heads with torch.compile for faster inference")
    args = parser.parse_args()

    server = NeonInferenceServer(
        model_path=args.model,
        blend_schedule=args.blend,
        execution_horizon=args.horizon,
        control_freq=args.freq,
        photon=args.photon,
        compile_heads=args.compile,
    )

    try:
        import base64
        import io
        from http.server import BaseHTTPRequestHandler, HTTPServer

        from PIL import Image

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                if self.path == "/predict":
                    content_len = int(self.headers.get("Content-Length", 0))
                    body = json.loads(self.rfile.read(content_len))

                    # Camera image (single frame)
                    image = None
                    if "image_base64" in body:
                        img_bytes = base64.b64decode(body["image_base64"])
                        image = Image.open(io.BytesIO(img_bytes))

                    # Video frames (multiple frames)
                    video_frames = None
                    if "video_frames_base64" in body:
                        video_frames = []
                        for frame_b64 in body["video_frames_base64"]:
                            img_bytes = base64.b64decode(frame_b64)
                            video_frames.append(Image.open(io.BytesIO(img_bytes)))

                    # Proprioception (joint positions)
                    proprio = None
                    if "proprioception" in body:
                        proprio = np.array(body["proprioception"], dtype=np.float32)

                    # Audio waveform (16kHz PCM as float list)
                    audio = None
                    if "audio" in body:
                        audio = np.array(body["audio"], dtype=np.float32)
                    elif "audio_base64" in body:
                        # Base64-encoded raw PCM-16 little-endian
                        audio_bytes = base64.b64decode(body["audio_base64"])
                        audio = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32) / 32768.0

                    # LiDAR point cloud (N×4 as nested list or flattened)
                    lidar = None
                    if "lidar" in body:
                        lidar = np.array(body["lidar"], dtype=np.float32)
                        if lidar.ndim == 1:
                            lidar = lidar.reshape(-1, 4)  # Unflatten to (N, 4)

                    # End-effector state (14-DOF bimanual pos+quat)
                    eef_state = None
                    if "eef_state" in body:
                        eef_state = np.array(body["eef_state"], dtype=np.float32)

                    output = server.predict(
                        image=image,
                        video_frames=video_frames,
                        instruction=body.get("instruction", ""),
                        proprioception=proprio,
                        audio=audio,
                        lidar=lidar,
                        eef_state=eef_state,
                        speak=body.get("speak", False),
                        rtc=body.get("rtc", True),
                    )

                    response = {
                        "actions": output.actions.tolist(),
                        "raw_actions": output.raw_actions.tolist() if output.raw_actions is not None else None,
                        "queue_remaining": server.actions_remaining(),
                        "inference_ms": server.action_queue.inference_latency_ms,
                    }
                    if output.speech_path:
                        response["speech_path"] = output.speech_path
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(json.dumps(response).encode())

                elif self.path == "/action":
                    action = server.get_action()
                    response = {"action": action.tolist() if action is not None else None}
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(json.dumps(response).encode())

                elif self.path == "/reset":
                    server.reset()
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b'{"status":"ok"}')

            def do_GET(self):
                if self.path == "/health":
                    model = server.model
                    info = {
                        "status": "ok",
                        "model": str(model),
                        "device": str(server.device),
                        "action_space": model.action_space.to_dict(),
                        "blend_schedule": server.action_queue.blend_schedule.value,
                        "execution_horizon": server.action_queue.execution_horizon,
                        "queue_remaining": server.actions_remaining(),
                        "modalities": {
                            "camera": True,
                            "video_frames": True,
                            "proprioception": model.proprio_encoder is not None,
                            "audio": model.audio_encoder is not None,
                            "lidar": model.lidar_encoder is not None,
                            "eef_state": model.eef_encoder is not None,
                            "speech_output": model.speaker is not None,
                        },
                    }
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(json.dumps(info).encode())

        httpd = HTTPServer((args.host, args.port), Handler)
        print(f"🤖 Neon inference server: http://{args.host}:{args.port}")
        print("   POST /predict — predict + queue actions (RTC)")
        print("   POST /action  — get next action from queue")
        print("   POST /reset   — reset episode state")
        print("   GET  /health  — server status")
        print(f"   Blend: {args.blend}, Horizon: {args.horizon}, Freq: {args.freq}Hz")
        httpd.serve_forever()

    except KeyboardInterrupt:
        print("\n🤖 Neon server stopped")


if __name__ == "__main__":
    main()
