"""
G1 Hardware Controller — Interface between Neon VLA and the physical robot.

Communicates with the Unitree G1 via the Unitree SDK.
Handles joint position commands, locomotion velocity, camera streaming.

Architecture adapted from GR00T-WBC decoupled controller:
- Neon VLA produces upper-body target poses (arms + waist)
- These feed as `ref_upper_dof_pos` to the SONIC lower-body RL policy
- SONIC handles balance, locomotion, and full 29-DoF coordination
- Joint safety monitoring with velocity-based kill switch (from GR00T-WBC)
- Interpolation smoothing for safe ramp-up (from GR00T-WBC InterpolationPolicy)
- PD control via Unitree SDK (KP/KD from SONIC yaml)
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np

from neon.data.action_space import ControlMode, G1ActionSpace

logger = logging.getLogger(__name__)


# =============================================================================
# Joint Safety Monitor — adapted from GR00T-WBC JointSafetyMonitor
# =============================================================================

class JointSafetyMonitor:
    """Monitor joint velocities and positions for safe operation.

    Ported from GR00T-WBC decoupled_wbc/control/envs/g1/utils/joint_safety.py.
    Key design decisions from NVIDIA's production deployment:
    - Velocity violations are CRITICAL → immediate shutdown
    - Position violations are WARNINGS → log but continue
    - Startup ramping over 2 seconds to prevent jerky initialization
    """

    def __init__(
        self,
        action_space: G1ActionSpace,
        arm_vel_limit: float = 6.0,
        startup_ramp_seconds: float = 2.0,
        control_freq: float = 50.0,
    ):
        self.action_space = action_space
        self.arm_vel_limit = arm_vel_limit
        self.control_freq = control_freq
        self.ramp_steps = int(startup_ramp_seconds * control_freq)
        self.step_count = 0
        self.initial_positions: Optional[np.ndarray] = None
        self.startup_complete = False
        self._prev_positions: Optional[np.ndarray] = None

    def check_velocity_safety(self, positions: np.ndarray) -> Tuple[bool, List[str]]:
        """Check if joint velocities are within safe bounds.

        Estimates velocity from position delta (like GR00T-WBC).
        Returns (is_safe, list_of_violation_messages).
        """
        violations = []
        if self._prev_positions is None:
            self._prev_positions = positions.copy()
            return True, []

        dt = 1.0 / self.control_freq
        velocities = (positions - self._prev_positions) / dt
        self._prev_positions = positions.copy()

        for i, joint in enumerate(self.action_space.active_joints):
            if i >= len(velocities):
                break
            vel = abs(velocities[i])
            # Use per-joint vel_limit from SONIC config if available
            limit = getattr(joint, 'vel_limit', self.arm_vel_limit)
            # Arm joints use the safety limit (6 rad/s from GR00T-WBC)
            if joint.group in ("left_arm", "right_arm"):
                limit = min(limit, self.arm_vel_limit)
            if vel > limit:
                violations.append(
                    f"{joint.name}: vel={vel:.2f} rad/s > limit={limit:.2f}"
                )

        return len(violations) == 0, violations

    def apply_startup_ramp(
        self, current_positions: np.ndarray, target_positions: np.ndarray
    ) -> np.ndarray:
        """Apply smooth startup ramping (from GR00T-WBC InterpolationPolicy pattern).

        During the first `ramp_steps` control cycles, linearly interpolate
        from initial observed position to target. Prevents jerky startup.
        """
        if self.startup_complete:
            return target_positions

        if self.initial_positions is None:
            self.initial_positions = current_positions.copy()

        self.step_count += 1
        if self.step_count >= self.ramp_steps:
            self.startup_complete = True
            return target_positions

        # Linear ramp: 0.0 → 1.0 over ramp_steps
        alpha = self.step_count / self.ramp_steps
        return self.initial_positions + alpha * (target_positions - self.initial_positions)

    def reset(self):
        """Reset safety monitor state (e.g., after environment reset)."""
        self.step_count = 0
        self.initial_positions = None
        self.startup_complete = False
        self._prev_positions = None


@dataclass
class G1Config:
    """Configuration for the G1 hardware interface.

    PD gains and safety limits from GR00T-WBC SONIC config.
    """

    # Connection
    robot_ip: str = "192.168.123.10"  # Default G1 IP (from SONIC: 192.168.123.164)
    sdk_port: int = 8080
    # Control — from SONIC BaseConfig
    control_frequency: float = 50.0  # Hz (SONIC control_frequency=50)
    sim_frequency: float = 200.0  # Hz (SONIC sim_frequency=200, for sim only)
    mode: str = "arms_only"  # Control mode
    # Safety — from GR00T-WBC JointSafetyMonitor
    arm_velocity_limit: float = 6.0  # rad/s (GR00T-WBC ARM_VELOCITY_LIMIT)
    hand_velocity_limit: float = 50.0  # rad/s (GR00T-WBC HAND_VELOCITY_LIMIT)
    max_linear_velocity: float = 1.5  # m/s
    max_angular_velocity: float = 1.0  # rad/s
    enable_safety_checks: bool = True
    startup_ramp_seconds: float = 2.0  # Smooth startup (from GR00T-WBC)
    teleop_timeout_seconds: float = 1.0  # Safety timeout (from G1DecoupledWholeBodyPolicy)
    # Safety mode: "kill" = shutdown, "freeze" = hold position (from SONIC joint_safety_mode)
    safety_mode: str = "kill"
    # Camera
    camera_id: int = 0  # Which camera to use (0=head, 1=chest)
    camera_fps: int = 30
    image_size: Tuple[int, int] = (640, 480)
    # PD gains override (None = use per-joint SONIC defaults from action_space)
    use_sonic_pd_gains: bool = True


class G1Controller:
    """Hardware controller for the Unitree G1 humanoid.

    Adapted from GR00T-WBC's decoupled whole-body controller architecture:

    1. Neon VLA predicts upper-body targets (arms + waist)
    2. Safety monitor checks velocity bounds (from GR00T-WBC)
    3. Interpolation smoothing for startup ramp (from GR00T-WBC)
    4. PD position control via Unitree SDK with SONIC gains
    5. Locomotion commands sent as velocity (vx, vy, omega)

    In full-stack mode (with SONIC lower-body policy):
        Neon VLA → ref_upper_dof_pos → SONIC RL policy → full 29-DoF

    In standalone mode (current):
        Neon VLA → PD position control → arm joints only
        Keyboard/joystick → locomotion velocity → legs

    Usage:
        controller = G1Controller(G1Config())
        controller.connect()

        while running:
            image = controller.get_camera_frame()
            joint_states = controller.get_joint_states()
            actions = model.predict(image, instruction, joint_states)
            controller.send_actions(actions.raw_actions[0])

        controller.disconnect()
    """

    def __init__(self, config: G1Config):
        self.config = config
        self.action_space = G1ActionSpace(
            mode=ControlMode(config.mode),
            include_locomotion=True,
        )
        self._connected = False
        self._robot = None
        self._camera = None
        self._last_goal_time = time.monotonic()

        # Joint safety monitor (from GR00T-WBC)
        self.safety_monitor = JointSafetyMonitor(
            action_space=self.action_space,
            arm_vel_limit=config.arm_velocity_limit,
            startup_ramp_seconds=config.startup_ramp_seconds,
            control_freq=config.control_frequency,
        )

    def connect(self):
        """Connect to the G1 robot."""
        logger.info(f"Connecting to G1 at {self.config.robot_ip}...")

        try:
            # Try Unitree SDK
            import unitree_sdk2py  # noqa: F401
            from unitree_sdk2py.core.channel import ChannelFactory
            from unitree_sdk2py.go2.sport import SportClient  # G1 uses similar API

            ChannelFactory.Init(0, self.config.robot_ip)
            self._robot = SportClient()
            self._robot.Init()
            self._connected = True
            logger.info("Connected to G1 via Unitree SDK")

        except ImportError:
            logger.warning(
                "Unitree SDK not installed. Running in simulation/mock mode. "
                "Install with: pip install unitree_sdk2py"
            )
            self._connected = False
            self._robot = None

    def disconnect(self):
        """Disconnect from the robot."""
        if self._connected:
            # Send zero velocity to stop
            self._send_locomotion_command(0.0, 0.0, 0.0)
            self._connected = False
            logger.info("Disconnected from G1")

    def is_connected(self) -> bool:
        return self._connected

    def get_camera_frame(self):
        """Capture a frame from the robot's camera.

        Returns:
            PIL Image or None
        """
        if self._camera is not None:
            try:
                import cv2
                from PIL import Image

                ret, frame = self._camera.read()
                if ret:
                    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    return Image.fromarray(frame_rgb)
            except Exception as e:
                logger.warning(f"Camera capture failed: {e}")

        # Fallback: try network camera
        try:
            import cv2
            from PIL import Image

            cap = cv2.VideoCapture(f"http://{self.config.robot_ip}:8080/camera")
            ret, frame = cap.read()
            cap.release()
            if ret:
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                return Image.fromarray(frame_rgb)
        except Exception:
            pass

        return None

    def get_joint_states(self) -> np.ndarray:
        """Get current joint positions.

        Returns:
            np.ndarray of shape (action_dim,) with current positions
        """
        if self._robot is not None:
            try:
                # Get state from Unitree SDK
                state = self._robot.GetMotorState()
                positions = np.array([s.q for s in state], dtype=np.float32)
                return positions[: self.action_space.action_dim]
            except Exception as e:
                logger.warning(f"Failed to read joint states: {e}")

        # Return default position if no robot
        return self.action_space.default_position()

    def send_actions(self, actions: np.ndarray):
        """Send action commands to the robot.

        Pipeline (adapted from GR00T-WBC G1DecoupledWholeBodyPolicy):
        1. Apply safety limits (position clipping)
        2. Check velocity safety (kill switch if exceeded)
        3. Apply startup ramp (smooth initialization)
        4. Split into joint positions + locomotion
        5. Send via PD control with SONIC gains

        Args:
            actions: (action_dim,) array of joint positions + locomotion velocity
                Already denormalized to physical units.
        """
        current_positions = self.get_joint_states()
        self._last_goal_time = time.monotonic()

        if self.config.enable_safety_checks:
            # Step 1: Position limits
            actions = self._apply_safety_limits(actions)

            # Step 2: Velocity safety check (from GR00T-WBC)
            n_joints = len(self.action_space.active_joints)
            joint_positions = actions[:n_joints]
            is_safe, violations = self.safety_monitor.check_velocity_safety(joint_positions)

            if not is_safe:
                logger.error(f"SAFETY VIOLATION: {violations}")
                if self.config.safety_mode == "kill":
                    self._send_locomotion_command(0.0, 0.0, 0.0)
                    raise RuntimeError(f"Joint safety violation: {violations}")
                else:  # freeze
                    logger.warning("Freezing — holding current position")
                    return

            # Step 3: Startup ramp (from GR00T-WBC InterpolationPolicy)
            joint_targets = self.safety_monitor.apply_startup_ramp(
                current_positions[:n_joints], joint_positions
            )
            actions[:n_joints] = joint_targets

        # Split into joint positions and locomotion
        split = self.action_space.split_action(actions)

        # Send joint position commands with SONIC PD gains
        joint_groups = ["left_arm", "right_arm", "torso"]
        if self.action_space.mode in (ControlMode.WHOLE_BODY, ControlMode.WHOLE_BODY_HANDS):
            joint_groups.extend(["left_leg", "right_leg"])

        for group in joint_groups:
            if group in split:
                self._send_joint_command(group, split[group])

        # Send locomotion velocity
        if "locomotion" in split:
            vx, vy, omega = split["locomotion"]
            self._send_locomotion_command(vx, vy, omega)

    def _send_joint_command(self, group: str, positions: np.ndarray):
        """Send joint position command for a specific group.

        Uses SONIC PD gains (kp, kd) from action_space.JointInfo when available.
        """
        if self._robot is None:
            return

        try:
            indices = self.action_space.get_group_indices(group)
            active_joints = self.action_space.active_joints

            for i, local_idx in enumerate(indices):
                if i < len(positions) and local_idx < len(active_joints):
                    active_joints[local_idx]
                    # Use SONIC PD gains from action_space

                    # TODO: Send via Unitree low-level API with PD gains:
                    # cmd.motorCmd[motor_id].q = positions[i]
                    # cmd.motorCmd[motor_id].Kp = kp
                    # cmd.motorCmd[motor_id].Kd = kd
                    # cmd.motorCmd[motor_id].dq = 0.0
                    # cmd.motorCmd[motor_id].tau = 0.0
                    pass
        except Exception as e:
            logger.warning(f"Failed to send {group} command: {e}")

    def _send_locomotion_command(self, vx: float, vy: float, omega: float):
        """Send locomotion velocity command."""
        if self._robot is None:
            return

        try:
            self._robot.Move(vx, vy, omega)
        except Exception as e:
            logger.warning(f"Failed to send locomotion command: {e}")

    def _apply_safety_limits(self, actions: np.ndarray) -> np.ndarray:
        """Apply safety limits to prevent dangerous motions.

        Uses per-joint limits from SONIC YAML (via action_space.JointInfo).
        """
        actions = actions.copy()

        # Clip joint positions to URDF limits
        joints = self.action_space.active_joints
        n_joints = len(joints)
        for i, joint in enumerate(joints):
            if i < len(actions):
                actions[i] = np.clip(actions[i], joint.lower_limit, joint.upper_limit)

        # Clip locomotion velocity
        if self.action_space.include_locomotion and len(actions) > n_joints:
            actions[n_joints] = np.clip(
                actions[n_joints],
                -self.config.max_linear_velocity,
                self.config.max_linear_velocity,
            )
            actions[n_joints + 1] = np.clip(
                actions[n_joints + 1],
                -self.config.max_linear_velocity,
                self.config.max_linear_velocity,
            )
            actions[n_joints + 2] = np.clip(
                actions[n_joints + 2],
                -self.config.max_angular_velocity,
                self.config.max_angular_velocity,
            )

        return actions

    def check_timeout_safety(self) -> bool:
        """Check teleop timeout safety (from G1DecoupledWholeBodyPolicy).

        If no goal received for `teleop_timeout_seconds`, inject safe stop.
        Returns True if safe, False if timed out.
        """
        time_since_goal = time.monotonic() - self._last_goal_time
        if time_since_goal > self.config.teleop_timeout_seconds:
            logger.warning(
                f"SAFETY: Teleop timeout after {time_since_goal:.1f}s, stopping"
            )
            self._send_locomotion_command(0.0, 0.0, 0.0)
            return False
        return True

    def run_control_loop(
        self,
        model,
        instruction: str = "",
        max_steps: int = 1000,
        action_chunk_index: int = 0,
    ):
        """Run a closed-loop control session.

        Includes GR00T-WBC safety patterns:
        - Startup ramp for smooth initialization
        - Velocity monitoring with kill switch
        - Teleop timeout safety
        - Control frequency enforcement

        Args:
            model: NeonVLA model or inference server
            instruction: Language instruction
            max_steps: Maximum control steps
            action_chunk_index: Which step of the action chunk to execute (0 = first)
        """
        logger.info(f"Starting control loop: '{instruction}' (max {max_steps} steps)")
        logger.info(f"  Control freq: {self.config.control_frequency} Hz")
        logger.info(f"  Safety mode: {self.config.safety_mode}")
        logger.info(f"  Startup ramp: {self.config.startup_ramp_seconds}s")

        dt = 1.0 / self.config.control_frequency
        step = 0

        # Reset safety monitor for fresh startup ramp
        self.safety_monitor.reset()

        try:
            while step < max_steps:
                t0 = time.time()

                # Check teleop timeout (from G1DecoupledWholeBodyPolicy)
                if step > 0 and not self.check_timeout_safety():
                    logger.warning("Teleop timeout — stopping control loop")
                    break

                # Observe
                image = self.get_camera_frame()
                joint_states = self.get_joint_states()

                # Predict
                output = model.predict(
                    image=image,
                    instruction=instruction,
                    proprioception=joint_states,
                )

                # Execute action from chunk
                if output.raw_actions is not None and len(output.raw_actions) > action_chunk_index:
                    try:
                        self.send_actions(output.raw_actions[action_chunk_index])
                    except RuntimeError as e:
                        # Safety violation — stop immediately
                        logger.error(f"Control loop stopped: {e}")
                        break

                step += 1

                # Control rate enforcement
                elapsed = time.time() - t0
                sleep_time = max(0, dt - elapsed)
                if sleep_time > 0:
                    time.sleep(sleep_time)

                if step % 50 == 0:
                    freq = 1.0 / (elapsed + 1e-6)
                    ramp_status = "ramping" if not self.safety_monitor.startup_complete else "active"
                    logger.info(
                        f"Step {step}/{max_steps}, freq: {freq:.1f} Hz, status: {ramp_status}"
                    )

        except KeyboardInterrupt:
            logger.info("Control loop interrupted")
        finally:
            # Safety: stop robot
            self._send_locomotion_command(0.0, 0.0, 0.0)
            logger.info(f"Control loop ended after {step} steps")
