"""Neon inference module — real-time serving."""
