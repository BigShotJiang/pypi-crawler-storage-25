#!/usr/bin/env python3
"""
G1DataCollector — High-caliber omni-modal dataset collection from real G1.

Collects the richest possible training data by layering perception models
on top of raw sensor streams:

    Raw Camera -> YOLO (detection) -> bounding boxes + classes
              -> SAM (segmentation) -> per-pixel masks
              -> raw RGB -> observation.image

    Raw Audio  -> Sound4D / PCM-16 -> observation.audio
    Joint FK   -> EEF bimanual pos+quat -> observation.eef_state
    Motors     -> 29/43-DOF positions -> observation.state
    LiDAR L1   -> 4096 points -> observation.lidar
    Teleop     -> joint targets -> action

All written to LeRobot v3 via NeonLeRobotWriter -> HuggingFace Hub.

Usage:
    from neon.collect import G1DataCollector, G1CollectorConfig

    collector = G1DataCollector(G1CollectorConfig(
        robot_ip="192.168.123.10",
        hub_id="cagataydev/neon-g1-real-v1",
        enable_yolo=True, enable_sam=True, enable_audio=True,
    ))
    collector.start()
    collector.new_episode("pick up the red cup")
    # ... teleop the robot ...
    collector.end_episode()
    collector.stop()  # exports + pushes to HuggingFace

CLI:
    python -m neon.collect.g1_data_collector --robot-ip 192.168.123.10 \
        --hub-id cagataydev/neon-g1-real-v1 --yolo --sam --audio
"""

from __future__ import annotations

import logging
import math
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import numpy as np

from neon.data.action_space import G1ActionSpace, ControlMode
from neon.data.lerobot_v3 import (
    EEF_DIM, FULL_ACTION_DIM, FULL_STATE_DIM,
    NeonLeRobotWriter, NeonWriterConfig, make_neon_features,
)

logger = logging.getLogger(__name__)


# =============================================================================
# FK for EEF
# =============================================================================

def compute_eef_from_joints(joint_positions: np.ndarray) -> np.ndarray:
    """Compute bimanual end-effector state from joint positions via FK.

    Simplified FK using G1 URDF link lengths. For production accuracy,
    use MuJoCo mj_fwdKinematics or Unitree SDK built-in FK.

    Args:
        joint_positions: (29,) or (43,) joint angles in radians
    Returns:
        (14,) [left_xyz(3), left_quat(4), right_xyz(3), right_quat(4)]
    """
    UPPER_ARM = 0.2725
    FOREARM = 0.2595
    SHOULDER_OFFSET_Y = 0.1585
    SHOULDER_HEIGHT_Z = 0.35

    eef = np.zeros(14, dtype=np.float32)

    for side_idx, (start, y_sign) in enumerate([(15, 1.0), (22, -1.0)]):
        if start + 6 >= len(joint_positions):
            continue

        sp = joint_positions[start]
        sr = joint_positions[start + 1]
        sy = joint_positions[start + 2]
        el = joint_positions[start + 3]
        wr = joint_positions[start + 4]
        wp = joint_positions[start + 5]
        wy = joint_positions[start + 6]

        c_sp, s_sp = math.cos(sp), math.sin(sp)
        c_sr, s_sr = math.cos(sr), math.sin(sr)
        c_sy, s_sy = math.cos(sy), math.sin(sy)

        elbow_x = UPPER_ARM * s_sp
        elbow_z = -UPPER_ARM * c_sp
        wrist_x = elbow_x + FOREARM * math.sin(sp + el)
        wrist_z = elbow_z - FOREARM * math.cos(sp + el)
        wrist_y_local = wrist_x * s_sr
        wrist_x_local = wrist_x * c_sr
        wx = wrist_x_local * c_sy - wrist_y_local * s_sy
        wy_local = wrist_x_local * s_sy + wrist_y_local * c_sy

        x, y, z = wx, y_sign * SHOULDER_OFFSET_Y + wy_local, SHOULDER_HEIGHT_Z + wrist_z

        # Euler to quaternion (ZYX intrinsic)
        tp, tr, ty = sp + el + wp, sr + wr, sy + wy
        cr2, sr2 = math.cos(tr / 2), math.sin(tr / 2)
        cp2, sp2 = math.cos(tp / 2), math.sin(tp / 2)
        cy2, sy2 = math.cos(ty / 2), math.sin(ty / 2)

        qw = cr2 * cp2 * cy2 + sr2 * sp2 * sy2
        qx = sr2 * cp2 * cy2 - cr2 * sp2 * sy2
        qy = cr2 * sp2 * cy2 + sr2 * cp2 * sy2
        qz = cr2 * cp2 * sy2 - sr2 * sp2 * cy2
        qn = math.sqrt(qw**2 + qx**2 + qy**2 + qz**2) + 1e-8

        off = side_idx * 7
        eef[off:off + 3] = [x, y, z]
        eef[off + 3:off + 7] = [qx / qn, qy / qn, qz / qn, qw / qn]

    return eef


# =============================================================================
# Perception Processors
# =============================================================================

class YOLOProcessor:
    """YOLO object detection. Boxes seed SAM for pixel-perfect masks."""

    def __init__(self, model_name: str = "yolo11n.pt", device: str = "auto", conf: float = 0.25):
        self.model_name, self.conf, self._model, self._device = model_name, conf, None, device

    def load(self):
        if self._model is not None:
            return
        from ultralytics import YOLO
        self._model = YOLO(self.model_name)
        if self._device != "auto":
            self._model.to(self._device)
        logger.info(f"YOLO loaded: {self.model_name}")

    def detect(self, frame: np.ndarray) -> Dict[str, Any]:
        if self._model is None:
            self.load()
        results = self._model(frame, conf=self.conf, verbose=False)[0]
        boxes = results.boxes.xyxy.cpu().numpy() if results.boxes else np.zeros((0, 4))
        classes = results.boxes.cls.cpu().numpy().astype(int) if results.boxes else np.zeros(0, dtype=int)
        scores = results.boxes.conf.cpu().numpy() if results.boxes else np.zeros(0)
        names = [results.names[c] for c in classes] if results.boxes else []
        return {"boxes": boxes, "classes": classes, "scores": scores, "names": names}

    def boxes_to_segmask(self, det: Dict, h: int, w: int) -> np.ndarray:
        mask = np.zeros((h, w), dtype=np.uint8)
        if len(det["boxes"]) == 0:
            return mask
        for idx in np.argsort(det["scores"]):
            x1, y1, x2, y2 = det["boxes"][idx].astype(int)
            cls = det["classes"][idx] + 1
            mask[max(0, y1):min(h, y2), max(0, x1):min(w, x2)] = cls
        return mask


class SAMProcessor:
    """SAM segmentation using YOLO boxes as prompts."""

    def __init__(self, model_type: str = "vit_b", checkpoint: str = "", device: str = "auto"):
        self.model_type, self.checkpoint, self._predictor, self._device = model_type, checkpoint, None, device

    def load(self):
        if self._predictor is not None:
            return
        from segment_anything import SamPredictor, sam_model_registry
        if not self.checkpoint:
            import urllib.request
            from pathlib import Path
            d = Path.home() / ".cache" / "neon" / "sam"
            d.mkdir(parents=True, exist_ok=True)
            p = d / f"sam_{self.model_type}.pth"
            if not p.exists():
                url = f"https://dl.fbaipublicfiles.com/segment_anything/sam_{self.model_type}.pth"
                logger.info(f"Downloading SAM: {url}")
                urllib.request.urlretrieve(url, str(p))
            self.checkpoint = str(p)
        import torch
        dev = self._device if self._device != "auto" else ("cuda" if torch.cuda.is_available() else "cpu")
        sam = sam_model_registry[self.model_type](checkpoint=self.checkpoint)
        sam.to(dev)
        self._predictor = SamPredictor(sam)
        logger.info(f"SAM loaded: {self.model_type} on {dev}")

    def segment_with_boxes(self, frame: np.ndarray, boxes: np.ndarray, classes: np.ndarray) -> np.ndarray:
        if self._predictor is None:
            self.load()
        h, w = frame.shape[:2]
        mask = np.zeros((h, w), dtype=np.uint8)
        if len(boxes) == 0:
            return mask
        self._predictor.set_image(frame)
        for i in range(len(boxes)):
            masks, _, _ = self._predictor.predict(box=boxes[i:i+1], multimask_output=False)
            mask[masks[0]] = classes[i] + 1
        return mask


class AudioCapture:
    """Continuous 16kHz mono audio capture with ring buffer."""

    def __init__(self, sample_rate: int = 16000, buffer_seconds: float = 30.0, device_index: int = None):
        self.sample_rate, self.device_index = sample_rate, device_index
        self._buffer: List[np.ndarray] = []
        self._max_samples = int(sample_rate * buffer_seconds)
        self._running, self._thread, self._lock = False, None, threading.Lock()

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info(f"Audio capture: {self.sample_rate}Hz, device={self.device_index}")

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)

    def get_window(self, seconds: float = 2.0) -> np.ndarray:
        target = int(self.sample_rate * seconds)
        with self._lock:
            if not self._buffer:
                return np.zeros(target, dtype=np.float32)
            all_audio = np.concatenate(self._buffer)
            return all_audio[-target:] if len(all_audio) >= target else np.pad(all_audio, (target - len(all_audio), 0))

    def _loop(self):
        try:
            import sounddevice as sd
        except ImportError:
            logger.error("pip install sounddevice")
            return
        def cb(indata, frames, ti, status):
            if not self._running:
                return
            chunk = indata[:, 0].astype(np.float32).copy()
            with self._lock:
                self._buffer.append(chunk)
                total = sum(len(c) for c in self._buffer)
                while total > self._max_samples and self._buffer:
                    total -= len(self._buffer.pop(0))
        try:
            with sd.InputStream(samplerate=self.sample_rate, channels=1,
                                blocksize=int(self.sample_rate * 0.1),
                                callback=cb, device=self.device_index):
                while self._running:
                    time.sleep(0.05)
        except Exception as e:
            logger.error(f"Audio error: {e}")


# =============================================================================
# G1DataCollector
# =============================================================================

@dataclass
class G1CollectorConfig:
    """Configuration for the G1 data collector."""
    robot_ip: str = "192.168.123.10"
    control_mode: str = "arms_only"
    hub_id: str = "cagataydev/neon-g1-real-v1"
    output_dir: str = "./neon_collected"
    fps: int = 20
    push_to_hub: bool = True
    private: bool = True
    enable_yolo: bool = True
    yolo_model: str = "yolo11n.pt"
    yolo_conf: float = 0.25
    enable_sam: bool = True
    sam_model: str = "vit_b"
    sam_checkpoint: str = ""
    perception_device: str = "auto"
    enable_audio: bool = True
    audio_device: int = None
    sample_rate: int = 16000
    enable_lidar: bool = True
    enable_eef: bool = True
    camera_width: int = 640
    camera_height: int = 480


class G1DataCollector:
    """High-caliber omni-modal data collector for real G1 hardware.

    Orchestrates: G1Controller + YOLO + SAM + AudioCapture + FK/EEF
    + NeonLeRobotWriter -> HuggingFace Hub.

    Perception (YOLO+SAM) runs async at ~5-10Hz. Main loop at config.fps.
    """

    def __init__(self, config: G1CollectorConfig):
        self.config = config
        self._running = self._collecting = False
        self._controller = None
        self._action_space = G1ActionSpace(mode=ControlMode(config.control_mode), include_locomotion=True)
        self._yolo: Optional[YOLOProcessor] = None
        self._sam: Optional[SAMProcessor] = None
        self._audio: Optional[AudioCapture] = None
        self._latest_detections: Dict[str, Any] = {}
        self._latest_segmask: Optional[np.ndarray] = None
        self._perception_lock = threading.Lock()
        self._perception_thread: Optional[threading.Thread] = None

        features = make_neon_features(
            image_height=config.camera_height, image_width=config.camera_width,
            include_lidar=config.enable_lidar, include_audio=config.enable_audio,
            include_eef=config.enable_eef,
            include_segmentation=config.enable_sam or config.enable_yolo,
        )
        self._writer = NeonLeRobotWriter(NeonWriterConfig(
            repo_id=config.hub_id, root=config.output_dir, fps=config.fps,
            features=features, push_to_hub=config.push_to_hub,
            private=config.private, source="real",
        ))
        self._current_action: Optional[np.ndarray] = None
        self._current_action_eef: Optional[np.ndarray] = None
        self._frame_count = self._episode_count = 0
        self._start_time = 0.0

    def start(self):
        """Initialize everything and start background threads."""
        logger.info("=" * 60)
        logger.info("G1DataCollector - Starting omni-modal collection")
        logger.info("=" * 60)

        from neon.inference.g1_controller import G1Config, G1Controller
        self._controller = G1Controller(G1Config(robot_ip=self.config.robot_ip, mode=self.config.control_mode))
        self._controller.connect()
        logger.info(f"[ok] Robot: {self.config.robot_ip}")

        if self.config.enable_yolo:
            self._yolo = YOLOProcessor(self.config.yolo_model, self.config.perception_device, self.config.yolo_conf)
            self._yolo.load()
            logger.info("[ok] YOLO")

        if self.config.enable_sam:
            self._sam = SAMProcessor(self.config.sam_model, self.config.sam_checkpoint, self.config.perception_device)
            self._sam.load()
            logger.info("[ok] SAM")

        if self.config.enable_audio:
            self._audio = AudioCapture(self.config.sample_rate, device_index=self.config.audio_device)
            self._audio.start()
            logger.info("[ok] Audio")

        self._writer.open()
        logger.info(f"[ok] Writer: {self.config.hub_id}")

        self._running = True
        if self._yolo or self._sam:
            self._perception_thread = threading.Thread(target=self._perception_loop, daemon=True)
            self._perception_thread.start()
            logger.info("[ok] Perception thread (YOLO+SAM)")

        self._start_time = time.time()
        logger.info("Ready! Call .new_episode(task) to begin.")

    def stop(self):
        self._running = self._collecting = False
        if self._audio:
            self._audio.stop()
        if self._controller:
            self._controller.disconnect()
        self._writer.save_and_push()
        elapsed = time.time() - self._start_time
        logger.info(f"Done: {self._episode_count} episodes, {self._frame_count} frames in {elapsed:.0f}s")

    def new_episode(self, task: str = ""):
        self._writer.start_episode(task=task)
        self._collecting = True
        logger.info(f"Episode {self._episode_count}: '{task}'")

    def end_episode(self):
        self._collecting = False
        self._writer.end_episode()
        self._episode_count += 1

    def set_action(self, action: np.ndarray, action_eef: np.ndarray = None):
        self._current_action = action
        self._current_action_eef = action_eef

    def collect_frame(self) -> Dict[str, Any]:
        """Collect one frame from all modalities and write to dataset."""
        if not self._collecting:
            return {}
        fd = {}

        # Camera
        if self._controller and self._controller.is_connected():
            img = self._controller.get_camera_frame()
            if img is not None:
                fd["image_head"] = np.array(img)

        # Joints
        joint_state = None
        if self._controller and self._controller.is_connected():
            joint_state = self._controller.get_joint_states()
            full = np.zeros(FULL_STATE_DIM, dtype=np.float32)
            full[:min(len(joint_state), FULL_STATE_DIM)] = joint_state[:FULL_STATE_DIM]
            fd["state"] = full

        # EEF from FK
        if self.config.enable_eef and joint_state is not None:
            padded = np.zeros(29, dtype=np.float32)
            padded[:min(len(joint_state), 29)] = joint_state[:29]
            fd["eef_state"] = compute_eef_from_joints(padded)

        # Segmentation (cached from perception thread)
        with self._perception_lock:
            if self._latest_segmask is not None:
                fd["segmentation"] = self._latest_segmask.copy()

        # Audio
        if self._audio:
            fd["audio"] = self._audio.get_window(seconds=2.0)

        # Action
        if self._current_action is not None:
            fd["action"] = self._current_action.copy()
        elif joint_state is not None:
            a = np.zeros(FULL_ACTION_DIM, dtype=np.float32)
            a[:min(len(joint_state), FULL_STATE_DIM)] = joint_state[:FULL_STATE_DIM]
            fd["action"] = a

        if self._current_action_eef is not None:
            fd["action_eef"] = self._current_action_eef.copy()

        # Write
        self._writer.add_frame(
            image_head=fd.get("image_head"), state=fd.get("state"),
            action=fd.get("action"), eef_state=fd.get("eef_state"),
            action_eef=fd.get("action_eef"), audio=fd.get("audio"),
            segmentation=fd.get("segmentation"),
        )
        self._frame_count += 1
        return fd

    def run_collection_loop(self, task: str = "", duration: float = 60.0):
        """Run a timed collection loop at config.fps."""
        self.new_episode(task)
        dt = 1.0 / self.config.fps
        start = time.time()
        n = 0
        try:
            while time.time() - start < duration and self._running:
                t0 = time.time()
                self.collect_frame()
                n += 1
                if n % (self.config.fps * 5) == 0:
                    logger.info(f"  [{time.time()-start:.0f}s/{duration:.0f}s] {n} frames")
                sl = dt - (time.time() - t0)
                if sl > 0:
                    time.sleep(sl)
        except KeyboardInterrupt:
            logger.info("Interrupted")
        finally:
            self.end_episode()

    def _perception_loop(self):
        """Background YOLO+SAM at ~5-10Hz, caches results for main loop."""
        while self._running:
            try:
                if not (self._controller and self._controller.is_connected()):
                    time.sleep(0.1)
                    continue
                img = self._controller.get_camera_frame()
                if img is None:
                    time.sleep(0.05)
                    continue
                frame = np.array(img)
                h, w = frame.shape[:2]
                det = self._yolo.detect(frame) if self._yolo else {}
                seg = None
                if self._sam and len(det.get("boxes", [])) > 0:
                    seg = self._sam.segment_with_boxes(frame, det["boxes"], det["classes"])
                elif self._yolo and len(det.get("boxes", [])) > 0:
                    seg = self._yolo.boxes_to_segmask(det, h, w)
                with self._perception_lock:
                    self._latest_detections = det
                    self._latest_segmask = seg
            except Exception as e:
                logger.debug(f"Perception: {e}")
                time.sleep(0.1)
            time.sleep(0.05)

    @property
    def stats(self) -> Dict[str, Any]:
        elapsed = time.time() - self._start_time if self._start_time else 0
        return {
            "episodes": self._episode_count, "total_frames": self._frame_count,
            "elapsed_s": round(elapsed, 1),
            "avg_fps": round(self._frame_count / max(elapsed, 1), 1),
            "hub_id": self.config.hub_id,
            "modalities": {
                "camera": True, "joints": True, "eef": self.config.enable_eef,
                "yolo": self.config.enable_yolo, "sam": self.config.enable_sam,
                "audio": self.config.enable_audio, "lidar": self.config.enable_lidar,
            },
        }


def main():
    import argparse
    p = argparse.ArgumentParser(description="G1 omni-modal data collector")
    p.add_argument("--robot-ip", default="192.168.123.10")
    p.add_argument("--hub-id", default="cagataydev/neon-g1-real-v1")
    p.add_argument("--output-dir", default="./neon_collected")
    p.add_argument("--fps", type=int, default=20)
    p.add_argument("--duration", type=float, default=60.0)
    p.add_argument("--task", default="")
    p.add_argument("--no-yolo", action="store_true")
    p.add_argument("--no-sam", action="store_true")
    p.add_argument("--no-audio", action="store_true")
    p.add_argument("--no-push", action="store_true")
    p.add_argument("--mode", default="arms_only", choices=["arms_only", "upper_body", "whole_body"])
    a = p.parse_args()

    cfg = G1CollectorConfig(
        robot_ip=a.robot_ip, hub_id=a.hub_id, output_dir=a.output_dir,
        fps=a.fps, control_mode=a.mode,
        enable_yolo=not a.no_yolo, enable_sam=not a.no_sam,
        enable_audio=not a.no_audio, push_to_hub=not a.no_push,
    )
    c = G1DataCollector(cfg)
    try:
        c.start()
        if a.task:
            c.run_collection_loop(task=a.task, duration=a.duration)
        else:
            print("\nInteractive: n <task> | e (end) | s (stats) | q (quit)")
            while True:
                try:
                    cmd = input("collect> ").strip()
                except (EOFError, KeyboardInterrupt):
                    break
                if cmd.startswith("n "):
                    c.new_episode(cmd[2:].strip())
                    threading.Thread(target=_auto, args=(c, cfg.fps), daemon=True).start()
                elif cmd == "e":
                    c.end_episode()
                elif cmd == "s":
                    import json; print(json.dumps(c.stats, indent=2))
                elif cmd in ("q", "quit", "exit"):
                    break
    finally:
        c.stop()


def _auto(collector, fps):
    dt = 1.0 / fps
    while collector._collecting and collector._running:
        t0 = time.time()
        collector.collect_frame()
        sl = dt - (time.time() - t0)
        if sl > 0:
            time.sleep(sl)


if __name__ == "__main__":
    main()
