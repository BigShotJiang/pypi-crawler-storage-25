"""Neon data collection — real hardware omni-modal dataset recording."""
from neon.collect.g1_data_collector import (
    G1CollectorConfig, G1DataCollector, AudioCapture,
    SAMProcessor, YOLOProcessor, compute_eef_from_joints,
)
__all__ = ["G1DataCollector", "G1CollectorConfig", "YOLOProcessor", "SAMProcessor", "AudioCapture", "compute_eef_from_joints"]
