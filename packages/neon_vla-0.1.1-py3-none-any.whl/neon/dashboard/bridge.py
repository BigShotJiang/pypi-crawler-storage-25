"""
Neon Dashboard Bridge — WebSocket server that exposes G1 streams to browsers.

Runs on the G1 (Jetson Orin) or any machine connected to the robot.
Bridges between Zenoh P2P channels and browser WebSockets.

Architecture:
    Browser (dashboard.html)
       │ WebSocket ws://G1:10100
       ▼
    NeonBridge (this file)
       │ reads from StreamSession channels
       │ publishes commands back to robot
       ▼
    G1 Hardware (joints, cameras, lidar, audio)

Usage:
    # On G1 / Jetson:
    python -m neon.dashboard.bridge --port 10100

    # Or from Python:
    from neon.dashboard.bridge import NeonBridge
    bridge = NeonBridge(port=10100)
    bridge.start()

Protocol (JSON over WebSocket):
    Browser → Bridge:
        {"type": "subscribe", "channels": ["camera", "joints", "lidar"]}
        {"type": "instruct", "text": "pick up the red cup"}
        {"type": "speak", "text": "hello robot"}
        {"type": "teleop", "axes": [0.0, 0.1, 0.0, ...]}  # gamepad
        {"type": "policy", "action": "start", "name": "neon-v1"}
        {"type": "policy", "action": "stop"}
        {"type": "audio", "data": "<base64 PCM>"}  # voice from browser mic

    Bridge → Browser:
        {"type": "camera", "ts": 1234.5, "data": "<base64 JPEG>", "fps": 30}
        {"type": "joints", "ts": 1234.5, "positions": [...], "velocities": [...]}
        {"type": "lidar", "ts": 1234.5, "points": [...]}  # downsampled for viz
        {"type": "audio", "ts": 1234.5, "data": "<base64 PCM>"}
        {"type": "status", "policy": "neon-v1", "state": "running", "fps": 4.2}
        {"type": "log", "level": "info", "message": "..."}
        {"type": "speech", "text": "I see a red cup on the table"}
"""

from __future__ import annotations

import asyncio
import base64
import io
import json
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

import numpy as np

logger = logging.getLogger(__name__)

# Max points to send to browser for 3D viz (full scan = 21,600)
LIDAR_VIZ_POINTS = 2048
# JPEG quality for camera stream
JPEG_QUALITY = 60
# Max camera FPS to browser (downsample from 30Hz)
CAMERA_MAX_FPS = 15
# Joint state publish rate to browser
JOINTS_MAX_HZ = 30


@dataclass
class ClientState:
    """Per-client subscription and state tracking."""
    ws: Any  # websocket connection
    subscriptions: Set[str] = field(default_factory=lambda: {"status"})
    last_camera_ts: float = 0.0
    last_joints_ts: float = 0.0
    last_lidar_ts: float = 0.0
    connected_at: float = field(default_factory=time.time)


class NeonBridge:
    """WebSocket bridge between G1 streams and browser dashboard.

    Lifecycle:
    1. start() → launches asyncio WebSocket server
    2. Clients connect and send {"type": "subscribe", "channels": [...]}
    3. Bridge reads from StreamSession channels at appropriate rates
    4. Forwards data as JSON+base64 to subscribed clients
    5. Receives commands (instruct, teleop, policy) and routes to robot
    """

    def __init__(
        self,
        port: int = 10100,
        host: str = "0.0.0.0",
        session=None,  # Optional StreamSession instance
    ):
        self.port = port
        self.host = host
        self.session = session
        self.clients: Dict[str, ClientState] = {}
        self._running = False
        self._server = None
        self._loop = None
        self._thread = None

        # Policy runner state
        self._active_policy = None
        self._policy_fps = 0.0

        # Stats
        self._frames_sent = 0
        self._messages_received = 0

    def start(self, blocking: bool = False):
        """Start the bridge server.

        Args:
            blocking: If True, run in current thread (blocks).
                      If False, run in background thread.
        """
        if self._running:
            logger.warning("Bridge already running")
            return

        self._running = True

        if blocking:
            asyncio.run(self._serve())
        else:
            self._thread = threading.Thread(target=self._run_in_thread, daemon=True)
            self._thread.start()
            logger.info(f"Neon Bridge started on ws://{self.host}:{self.port}")

    def _run_in_thread(self):
        """Run asyncio event loop in background thread."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._serve())

    async def _serve(self):
        """Main WebSocket server loop."""
        try:
            import websockets
        except ImportError:
            logger.error("websockets package required: pip install websockets")
            return

        logger.info(f"Starting Neon Bridge on ws://{self.host}:{self.port}")

        async with websockets.serve(
            self._handle_client,
            self.host,
            self.port,
            max_size=10 * 1024 * 1024,  # 10MB max message (for camera frames)
            ping_interval=20,
            ping_timeout=30,
        ) as server:
            self._server = server
            logger.info(f"Neon Bridge listening on ws://{self.host}:{self.port}")

            # Start channel publisher tasks
            tasks = [
                asyncio.create_task(self._publish_camera()),
                asyncio.create_task(self._publish_joints()),
                asyncio.create_task(self._publish_lidar()),
                asyncio.create_task(self._publish_status()),
            ]

            # Wait until stopped
            while self._running:
                await asyncio.sleep(0.1)

            for t in tasks:
                t.cancel()

    async def _handle_client(self, ws, path=None):
        """Handle a single WebSocket client connection."""
        client_id = f"{ws.remote_address[0]}:{ws.remote_address[1]}"
        client = ClientState(ws=ws)
        self.clients[client_id] = client

        logger.info(f"Client connected: {client_id} (total: {len(self.clients)})")

        # Send welcome
        await self._send(ws, {
            "type": "welcome",
            "robot": "unitree_g1",
            "channels": ["camera", "joints", "lidar", "audio", "status"],
            "policy_running": self._active_policy is not None,
            "active_policy": self._active_policy,
        })

        try:
            async for message in ws:
                self._messages_received += 1
                try:
                    data = json.loads(message)
                    await self._handle_message(client_id, data)
                except json.JSONDecodeError:
                    await self._send(ws, {"type": "error", "message": "Invalid JSON"})
                except Exception as e:
                    logger.error(f"Error handling message from {client_id}: {e}")
                    await self._send(ws, {"type": "error", "message": str(e)})
        except Exception as e:
            logger.info(f"Client disconnected: {client_id} ({e})")
        finally:
            del self.clients[client_id]

    async def _handle_message(self, client_id: str, data: Dict):
        """Route incoming messages from browser."""
        msg_type = data.get("type", "")
        client = self.clients.get(client_id)
        if not client:
            return

        if msg_type == "subscribe":
            channels = set(data.get("channels", []))
            client.subscriptions = channels | {"status"}  # Always include status
            logger.info(f"Client {client_id} subscribed to: {channels}")
            await self._send(client.ws, {
                "type": "subscribed",
                "channels": list(client.subscriptions),
            })

        elif msg_type == "instruct":
            text = data.get("text", "")
            if text and self.session:
                logger.info(f"Instruction from {client_id}: {text}")
                # Run in background to not block WebSocket
                asyncio.get_event_loop().run_in_executor(
                    None, self.session.instruct, text
                )
                await self._broadcast("status", {
                    "type": "log",
                    "level": "info",
                    "message": f"Instruction: {text}",
                })

        elif msg_type == "speak":
            text = data.get("text", "")
            if text and self.session and hasattr(self.session, "speak"):
                asyncio.get_event_loop().run_in_executor(
                    None, self.session.speak, text
                )

        elif msg_type == "teleop":
            # Gamepad axes → joint velocity commands
            axes = data.get("axes", [])
            if axes and self.session and hasattr(self.session, "teleop"):
                self.session.teleop(np.array(axes, dtype=np.float32))

        elif msg_type == "policy":
            action = data.get("action", "")
            if action == "start":
                policy_name = data.get("name", "neon-v1")
                await self._start_policy(policy_name)
            elif action == "stop":
                await self._stop_policy()
            elif action == "list":
                await self._send(client.ws, {
                    "type": "policies",
                    "available": self._list_policies(),
                    "active": self._active_policy,
                })

        elif msg_type == "audio":
            # Browser mic audio → robot's audio channel
            audio_b64 = data.get("data", "")
            if audio_b64 and self.session:
                audio_bytes = base64.b64decode(audio_b64)
                audio_np = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32) / 32768.0
                if hasattr(self.session, "process_audio"):
                    asyncio.get_event_loop().run_in_executor(
                        None, self.session.process_audio, audio_np
                    )

        elif msg_type == "ping":
            await self._send(client.ws, {"type": "pong", "ts": time.time()})

    # ── Channel publishers ──────────────────────────────────────────

    async def _publish_camera(self):
        """Publish camera frames to subscribed clients."""
        while self._running:
            try:
                if not self.session:
                    await asyncio.sleep(0.1)
                    continue

                # Get latest camera frame from session
                frame = self._get_camera_frame()
                if frame is None:
                    await asyncio.sleep(1.0 / CAMERA_MAX_FPS)
                    continue

                # Encode to JPEG
                jpeg_b64 = self._encode_frame_jpeg(frame)
                if jpeg_b64 is None:
                    await asyncio.sleep(1.0 / CAMERA_MAX_FPS)
                    continue

                msg = {
                    "type": "camera",
                    "ts": time.time(),
                    "data": jpeg_b64,
                    "width": frame.shape[1] if hasattr(frame, "shape") else 640,
                    "height": frame.shape[0] if hasattr(frame, "shape") else 480,
                }

                await self._broadcast("camera", msg)
                self._frames_sent += 1

            except Exception as e:
                logger.debug(f"Camera publish error: {e}")

            await asyncio.sleep(1.0 / CAMERA_MAX_FPS)

    async def _publish_joints(self):
        """Publish joint states to subscribed clients."""
        while self._running:
            try:
                if not self.session:
                    await asyncio.sleep(0.1)
                    continue

                joints = self._get_joint_state()
                if joints is None:
                    await asyncio.sleep(1.0 / JOINTS_MAX_HZ)
                    continue

                msg = {
                    "type": "joints",
                    "ts": time.time(),
                    "positions": joints.get("positions", []),
                    "velocities": joints.get("velocities", []),
                    "names": joints.get("names", []),
                }
                await self._broadcast("joints", msg)

            except Exception as e:
                logger.debug(f"Joints publish error: {e}")

            await asyncio.sleep(1.0 / JOINTS_MAX_HZ)

    async def _publish_lidar(self):
        """Publish downsampled LiDAR point cloud."""
        while self._running:
            try:
                if not self.session:
                    await asyncio.sleep(0.5)
                    continue

                points = self._get_lidar_points()
                if points is None:
                    await asyncio.sleep(0.5)
                    continue

                # Downsample for browser viz
                if len(points) > LIDAR_VIZ_POINTS:
                    indices = np.random.choice(len(points), LIDAR_VIZ_POINTS, replace=False)
                    points = points[indices]

                msg = {
                    "type": "lidar",
                    "ts": time.time(),
                    "points": points.tolist(),  # [[x,y,z,intensity], ...]
                    "count": len(points),
                }
                await self._broadcast("lidar", msg)

            except Exception as e:
                logger.debug(f"LiDAR publish error: {e}")

            await asyncio.sleep(0.1)  # 10Hz

    async def _publish_status(self):
        """Publish periodic status updates."""
        while self._running:
            try:
                status = {
                    "type": "status",
                    "ts": time.time(),
                    "clients": len(self.clients),
                    "frames_sent": self._frames_sent,
                    "messages_received": self._messages_received,
                    "policy": self._active_policy,
                    "policy_fps": self._policy_fps,
                    "session_active": self.session is not None,
                }

                if self.session and hasattr(self.session, "get_status"):
                    status["session"] = self.session.get_status()

                await self._broadcast("status", status)

            except Exception as e:
                logger.debug(f"Status publish error: {e}")

            await asyncio.sleep(1.0)  # 1Hz

    # ── Data accessors (from StreamSession channels) ────────────────

    def _get_camera_frame(self) -> Optional[np.ndarray]:
        """Get latest camera frame from session."""
        if not self.session:
            return None
        try:
            if hasattr(self.session, "get_latest_frame"):
                return self.session.get_latest_frame()
            # Try reading from camera channel directly
            if hasattr(self.session, "channels") and "camera" in self.session.channels:
                sample = self.session.channels["camera"].get_latest()
                if sample:
                    return sample.data
        except Exception:
            pass
        return None

    def _get_joint_state(self) -> Optional[Dict]:
        """Get latest joint state from session."""
        if not self.session:
            return None
        try:
            if hasattr(self.session, "get_latest_joints"):
                return self.session.get_latest_joints()
            if hasattr(self.session, "channels") and "joints" in self.session.channels:
                sample = self.session.channels["joints"].get_latest()
                if sample and sample.data is not None:
                    return {
                        "positions": sample.data.tolist() if hasattr(sample.data, "tolist") else list(sample.data),
                        "velocities": [],
                        "names": [],
                    }
        except Exception:
            pass
        return None

    def _get_lidar_points(self) -> Optional[np.ndarray]:
        """Get latest LiDAR point cloud from session."""
        if not self.session:
            return None
        try:
            if hasattr(self.session, "get_latest_lidar"):
                return self.session.get_latest_lidar()
            if hasattr(self.session, "channels") and "lidar" in self.session.channels:
                sample = self.session.channels["lidar"].get_latest()
                if sample and sample.data is not None:
                    return np.asarray(sample.data)
        except Exception:
            pass
        return None

    def _encode_frame_jpeg(self, frame) -> Optional[str]:
        """Encode numpy frame to base64 JPEG."""
        try:
            from PIL import Image
            if isinstance(frame, np.ndarray):
                img = Image.fromarray(frame)
            elif hasattr(frame, "save"):
                img = frame
            else:
                return None

            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=JPEG_QUALITY)
            return base64.b64encode(buf.getvalue()).decode("ascii")
        except Exception:
            return None

    # ── Policy management ───────────────────────────────────────────

    async def _start_policy(self, name: str):
        """Start a policy on the robot."""
        self._active_policy = name
        logger.info(f"Starting policy: {name}")

        if self.session and hasattr(self.session, "start_policy"):
            asyncio.get_event_loop().run_in_executor(
                None, self.session.start_policy, name
            )

        await self._broadcast("status", {
            "type": "log",
            "level": "info",
            "message": f"Policy started: {name}",
        })

    async def _stop_policy(self):
        """Stop the active policy."""
        name = self._active_policy
        self._active_policy = None
        logger.info(f"Stopping policy: {name}")

        if self.session and hasattr(self.session, "stop_policy"):
            asyncio.get_event_loop().run_in_executor(
                None, self.session.stop_policy
            )

        await self._broadcast("status", {
            "type": "log",
            "level": "info",
            "message": f"Policy stopped: {name}",
        })

    def _list_policies(self) -> List[str]:
        """List available policies."""
        if self.session and hasattr(self.session, "list_policies"):
            return self.session.list_policies()
        return ["neon-v1", "groot-wbc", "teleop-direct"]

    # ── Helpers ─────────────────────────────────────────────────────

    async def _send(self, ws, data: Dict):
        """Send JSON message to a single client."""
        try:
            await ws.send(json.dumps(data))
        except Exception:
            pass

    async def _broadcast(self, channel: str, data: Dict):
        """Broadcast to all clients subscribed to a channel."""
        dead = []
        for client_id, client in self.clients.items():
            if channel in client.subscriptions or channel == "status":
                try:
                    await client.ws.send(json.dumps(data))
                except Exception:
                    dead.append(client_id)

        for cid in dead:
            self.clients.pop(cid, None)

    def stop(self):
        """Stop the bridge."""
        self._running = False
        logger.info("Neon Bridge stopped")


def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(description="Neon Dashboard Bridge")
    parser.add_argument("--port", type=int, default=10100, help="WebSocket port")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="Bind address")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    logger.info(f"Starting Neon Bridge on ws://{args.host}:{args.port}")

    bridge = NeonBridge(port=args.port, host=args.host)
    bridge.start(blocking=True)


if __name__ == "__main__":
    main()
