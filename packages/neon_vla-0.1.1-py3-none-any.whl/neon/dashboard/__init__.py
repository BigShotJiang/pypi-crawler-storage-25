"""Neon Dashboard — WebSocket bridge + browser UI for live G1 control."""
from neon.dashboard.bridge import NeonBridge

__all__ = ["NeonBridge"]
