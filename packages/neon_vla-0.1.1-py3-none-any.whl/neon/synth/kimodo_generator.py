"""
Kimodo Motion Generator — Text-to-G1-Motion data factory.

Uses NVIDIA Kimodo (kinematic motion diffusion) to generate unlimited
G1-native joint trajectories from text prompts and kinematic constraints.

Pipeline:
    Text prompt → Kimodo G1 model → G1 joint trajectory → (optional) NeonSimEnv render
    → LeRobot v3 Parquet with all modalities

Models (HuggingFace):
    nvidia/Kimodo-G1-RP-v1      — G1 skeleton, Rigplay 700h mocap
    nvidia/Kimodo-G1-SEED-v1    — G1 skeleton, SEED 142K motions
    nvidia/Kimodo-SOMA-RP-v1    — Human SOMA skeleton (retargetable)
    nvidia/Kimodo-SMPLX-RP-v1   — SMPL-X body model

Reference: https://research.nvidia.com/labs/sil/projects/kimodo/
Code: https://github.com/nv-tlabs/kimodo
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


# ── Prompt Templates ────────────────────────────────────────────────────

LOCOMOTION_PROMPTS = [
    "walk forward steadily",
    "walk forward and stop",
    "jog forward at moderate speed",
    "turn left 90 degrees while walking",
    "turn right 90 degrees while walking",
    "turn around 180 degrees",
    "sidestep to the left",
    "sidestep to the right",
    "walk backward slowly",
    "walk in a circle",
    "crouch down and stand back up",
    "step over an obstacle on the ground",
    "walk up a small incline",
    "walk while maintaining a low stance",
    "walk forward then stop suddenly",
    "march in place",
    "take three steps forward",
    "shuffle forward slowly",
    "walk on tiptoes",
    "walk with wide steps",
]

MANIPULATION_PROMPTS = [
    "reach forward with the right hand to grab an object on the table",
    "reach forward with the left hand to pick up a cup",
    "reach both arms forward and grasp a box",
    "lift an object from the table with the right hand",
    "place an object down on the table with the right hand",
    "hand an object from the right hand to the left hand",
    "push an object forward on the table",
    "pull an object toward the body",
    "reach up to a high shelf with the right hand",
    "reach down to pick something from the floor",
    "open a drawer with the right hand",
    "close a drawer with the left hand",
    "turn a knob with the right hand",
    "wave the right hand",
    "point forward with the right arm",
    "reach to the left side with the left arm",
    "reach to the right side with the right arm",
    "extend both arms sideways",
    "fold arms across the chest",
    "clap hands together",
]

PICK_AND_NAVIGATE_PROMPTS = [
    "walk to the table and pick up the red cup",
    "walk forward, bend down, and pick up an object from the floor",
    "walk to the shelf and grab the book",
    "pick up the box from the table and carry it forward",
    "walk to the counter, pick up the plate, and bring it to the table",
    "approach the desk and pick up the pen",
    "walk to the door and reach for the handle",
    "pick up the bottle and walk to the sink",
    "walk backward while holding an object",
    "carry a box from one table to another",
    "walk to the left, pick up an object, and bring it back",
    "pick up two objects, one in each hand",
    "navigate around the chair and pick up the toy",
    "walk in a zigzag pattern and pick up objects along the way",
    "crouch to pick up an object and then walk forward",
]

INTERACTION_PROMPTS = [
    "sit down on a chair",
    "stand up from a seated position",
    "lean against a wall",
    "open a door and walk through",
    "close a door behind",
    "push a cart forward",
    "pull a lever down",
    "climb onto a low platform",
    "step down from a platform",
    "balance on one foot",
]

ALL_PROMPTS = LOCOMOTION_PROMPTS + MANIPULATION_PROMPTS + PICK_AND_NAVIGATE_PROMPTS + INTERACTION_PROMPTS

# Prompt categories for weighted sampling
PROMPT_CATEGORIES = {
    "locomotion": LOCOMOTION_PROMPTS,
    "manipulation": MANIPULATION_PROMPTS,
    "pick_and_navigate": PICK_AND_NAVIGATE_PROMPTS,
    "interaction": INTERACTION_PROMPTS,
}


@dataclass
class KimodoConfig:
    """Configuration for Kimodo motion generation."""

    # Model
    model_id: str = "nvidia/Kimodo-G1-RP-v1"
    device: str = "cuda:0"
    dtype: str = "float32"  # float16 or float32

    # Generation
    num_episodes: int = 1000
    episode_length_seconds: float = 8.0
    fps: int = 30  # Kimodo native output rate
    output_fps: int = 50  # Resample to match Neon control_hz

    # Prompts
    prompts: Optional[List[str]] = None  # Override with custom prompts
    category_weights: Dict[str, float] = field(default_factory=lambda: {
        "locomotion": 0.3,
        "manipulation": 0.3,
        "pick_and_navigate": 0.25,
        "interaction": 0.15,
    })

    # Constraints (optional)
    use_ee_constraints: bool = False  # End-effector target constraints
    use_keyframe_constraints: bool = False  # Sparse keyframe constraints

    # Diffusion
    num_denoise_steps: int = 50
    guidance_scale: float = 7.5

    # G1 joint mapping
    num_body_joints: int = 29
    num_hand_joints: int = 14
    total_joints: int = 43

    # Sim rendering (if enabled, uses NeonSimEnv to render all modalities)
    render_in_sim: bool = True
    sim_image_width: int = 640
    sim_image_height: int = 480

    # Export
    output_dir: str = "/tmp/neon_kimodo"
    repo_id: str = "cagataydev/neon-g1-kimodo-50k"
    push_to_hub: bool = True

    # Presets
    @classmethod
    def diverse_50k(cls) -> "KimodoConfig":
        """50K diverse episodes from text prompts."""
        return cls(
            num_episodes=50000,
            repo_id="cagataydev/neon-g1-kimodo-50k",
        )

    @classmethod
    def constrained_10k(cls) -> "KimodoConfig":
        """10K episodes with EE constraints (reaching tasks)."""
        return cls(
            num_episodes=10000,
            use_ee_constraints=True,
            category_weights={
                "locomotion": 0.1,
                "manipulation": 0.5,
                "pick_and_navigate": 0.3,
                "interaction": 0.1,
            },
            repo_id="cagataydev/neon-g1-kimodo-constrained-10k",
        )

    @classmethod
    def locomotion_20k(cls) -> "KimodoConfig":
        """20K pure locomotion episodes."""
        return cls(
            num_episodes=20000,
            category_weights={
                "locomotion": 0.8,
                "manipulation": 0.0,
                "pick_and_navigate": 0.1,
                "interaction": 0.1,
            },
            render_in_sim=False,  # No vision needed for pure loco
            repo_id="cagataydev/neon-g1-kimodo-loco-20k",
        )

    @classmethod
    def fast_debug(cls) -> "KimodoConfig":
        """Tiny config for testing."""
        return cls(
            num_episodes=5,
            episode_length_seconds=2.0,
            device="cpu",
            render_in_sim=False,
            push_to_hub=False,
            output_dir="/tmp/neon_kimodo_debug",
            repo_id="local/kimodo-debug",
        )


@dataclass
class KimodoMotion:
    """A single generated motion trajectory."""

    joint_positions: np.ndarray  # (T, num_joints) — joint angles in radians
    prompt: str
    category: str
    duration: float  # seconds
    fps: int
    root_positions: Optional[np.ndarray] = None  # (T, 3) — root xyz
    root_orientations: Optional[np.ndarray] = None  # (T, 4) — root quaternion
    ee_positions: Optional[np.ndarray] = None  # (T, 14) — EEF positions
    metadata: Optional[Dict[str, Any]] = None

    @property
    def num_frames(self) -> int:
        return self.joint_positions.shape[0]

    @property
    def num_joints(self) -> int:
        return self.joint_positions.shape[1]


class KimodoGenerator:
    """Generate G1 motions from text using Kimodo diffusion model.

    Usage:
        gen = KimodoGenerator(KimodoConfig.diverse_50k())
        gen.load_model()  # Downloads from HuggingFace

        # Generate a single motion
        motion = gen.generate("walk forward and pick up the cup")

        # Generate batch
        motions = gen.generate_batch(prompts, batch_size=32)

        # Full pipeline: generate + render in sim + export to LeRobot v3
        gen.run_pipeline()

    If Kimodo model is not available (not installed), falls back to
    procedural motion generation using sine waves and scripted trajectories.
    This ensures the pipeline always works for testing and CI.
    """

    def __init__(self, config: Optional[KimodoConfig] = None):
        self.config = config or KimodoConfig()
        self._model = None
        self._tokenizer = None
        self._use_fallback = False
        self._rng = np.random.default_rng(42)

    def load_model(self) -> bool:
        """Load the Kimodo model from HuggingFace.

        Returns:
            True if real model loaded, False if using fallback.
        """
        try:
            # Try to import Kimodo (nv-tlabs/kimodo)
            from kimodo import load_model as kimodo_load_model  # type: ignore
            from kimodo import AVAILABLE_MODELS  # type: ignore

            # Map our model_id to Kimodo short key
            # e.g. "nvidia/Kimodo-G1-RP-v1" → "kimodo-g1-rp"
            model_key = self.config.model_id
            if "/" in model_key:
                # Convert HF repo name to Kimodo short key
                # nvidia/Kimodo-G1-RP-v1 → kimodo-g1-rp-v1 → kimodo-g1-rp
                short = model_key.split("/")[-1].lower().replace("-v1", "")
                if short in AVAILABLE_MODELS:
                    model_key = short
                else:
                    # Default to G1 RP model
                    model_key = "kimodo-g1-rp"

            logger.info(f"Loading Kimodo model: {model_key}")
            device = self.config.device
            self._model = kimodo_load_model(model_key, device=device)
            self._kimodo_fps = self._model.fps
            logger.info(
                f"Kimodo model loaded: {model_key} "
                f"(skeleton: {self._model.skeleton.name}, "
                f"joints: {self._model.skeleton.nbjoints}, "
                f"fps: {self._kimodo_fps})"
            )
            self._use_fallback = False
            return True

        except ImportError:
            logger.warning(
                "Kimodo not installed. Using procedural motion fallback. "
                "Install with: pip install -e /path/to/kimodo"
            )
            self._use_fallback = True
            return False

        except Exception as e:
            logger.warning(f"Failed to load Kimodo model: {e}. Using fallback.")
            self._use_fallback = True
            return False

    def _sample_prompt(self) -> Tuple[str, str]:
        """Sample a prompt with weighted category selection.

        Returns:
            (prompt_text, category_name)
        """
        if self.config.prompts:
            prompt = self._rng.choice(self.config.prompts)
            return prompt, "custom"

        # Weighted category selection
        categories = list(self.config.category_weights.keys())
        weights = [self.config.category_weights[c] for c in categories]
        weights = np.array(weights) / sum(weights)

        category = self._rng.choice(categories, p=weights)
        prompts = PROMPT_CATEGORIES.get(category, ALL_PROMPTS)
        prompt = self._rng.choice(prompts)
        return prompt, category

    def generate(
        self,
        prompt: Optional[str] = None,
        duration: Optional[float] = None,
        ee_targets: Optional[np.ndarray] = None,
        keyframes: Optional[Dict[int, np.ndarray]] = None,
    ) -> KimodoMotion:
        """Generate a single motion from text prompt.

        Args:
            prompt: Text instruction. If None, samples from categories.
            duration: Override episode duration in seconds.
            ee_targets: (N, 3) end-effector target positions for constraint mode.
            keyframes: {frame_idx: joint_positions} sparse keyframe constraints.

        Returns:
            KimodoMotion with joint trajectories.
        """
        if prompt is None:
            prompt, category = self._sample_prompt()
        else:
            category = "custom"

        dur = duration or self.config.episode_length_seconds
        num_frames = int(dur * self.config.fps)

        if self._use_fallback or self._model is None:
            return self._generate_fallback(prompt, category, num_frames, dur)

        # Real Kimodo generation
        return self._generate_kimodo(prompt, category, num_frames, dur, ee_targets, keyframes)

    def _generate_kimodo(
        self,
        prompt: str,
        category: str,
        num_frames: int,
        duration: float,
        ee_targets: Optional[np.ndarray] = None,
        keyframes: Optional[Dict[int, np.ndarray]] = None,
    ) -> KimodoMotion:
        """Generate motion using real Kimodo model.

        Uses the official Kimodo API:
            output = model(prompts, num_frames, num_denoising_steps, ...)

        Output dict contains:
            - posed_joints: (B, T, J, 3) joint positions in world space
            - global_rot_mats: (B, T, J, 3, 3) global rotation matrices
            - local_rot_mats: (B, T, J, 3, 3) local rotation matrices
            - root_positions: (B, T, 3) root (pelvis) positions
        """
        import torch

        # Ensure prompt ends with period (Kimodo convention)
        if not prompt.endswith("."):
            prompt_text = prompt + "."
        else:
            prompt_text = prompt

        # Use Kimodo's native FPS for generation, then resample
        native_num_frames = int(duration * self._kimodo_fps)

        # Generate using official Kimodo API
        with torch.no_grad():
            output = self._model(
                [prompt_text],
                [native_num_frames],
                num_denoising_steps=self.config.num_denoise_steps,
                num_samples=1,
                multi_prompt=False,
                return_numpy=True,
            )

        # Extract outputs — shapes: (1, T, J, ...) → squeeze batch dim
        posed_joints = output["posed_joints"][0]  # (T, J, 3)
        root_positions = output.get("root_positions")
        if root_positions is not None:
            root_positions = root_positions[0]  # (T, 3)
        root_orientations = output.get("root_orientations")
        if root_orientations is not None:
            root_orientations = root_orientations[0]

        local_rot_mats = output.get("local_rot_mats")
        if local_rot_mats is not None:
            local_rot_mats = local_rot_mats[0]  # (T, J, 3, 3)

        # Convert to MuJoCo qpos (29-DoF joint angles)
        # This gives us the actual G1 joint angles from the skeleton motion
        try:
            from kimodo.exports.mujoco import MujocoQposConverter

            converter = MujocoQposConverter(self._model.skeleton)
            # Re-batch for converter: needs (B, T, ...)
            qpos_input = {
                k: v[np.newaxis] if hasattr(v, "shape") and v.ndim >= 2 else v
                for k, v in output.items()
            }
            qpos = converter.dict_to_qpos(
                qpos_input, self.config.device, mujoco_rest_zero=True
            )
            # qpos shape: (1, T, 36) → root_trans(3) + root_quat(4) + joint_dofs(29)
            joint_angles = qpos[0, :, 7:]  # (T, 29) — the 29 DoF joint angles
        except Exception as e:
            logger.warning(f"MuJoCo qpos conversion failed: {e}. Using posed_joints.")
            # Fallback: use posed_joints directly (less accurate)
            joint_angles = posed_joints[:, :29, 0]  # rough fallback

        # Pad with zeros for hand joints (14 DOF)
        hand_padding = np.zeros(
            (joint_angles.shape[0], self.config.num_hand_joints),
            dtype=np.float32,
        )
        joint_positions = np.concatenate(
            [joint_angles, hand_padding], axis=1
        )  # (T, 43)

        # Resample to output FPS if different from Kimodo native
        if self._kimodo_fps != self.config.output_fps:
            joint_positions = self._resample(
                joint_positions, self._kimodo_fps, self.config.output_fps
            )
            if root_positions is not None:
                root_positions = self._resample(
                    root_positions, self._kimodo_fps, self.config.output_fps
                )

        return KimodoMotion(
            joint_positions=joint_positions,
            prompt=prompt,
            category=category,
            duration=duration,
            fps=self.config.output_fps,
            root_positions=root_positions,
            root_orientations=root_orientations,
            metadata={
                "model": self.config.model_id,
                "kimodo_skeleton": self._model.skeleton.name,
                "kimodo_fps": self._kimodo_fps,
                "kimodo_joints": self._model.skeleton.nbjoints,
                "denoise_steps": self.config.num_denoise_steps,
                "guidance": self.config.guidance_scale,
                "posed_joints_shape": list(posed_joints.shape),
                "has_qpos": True,
            },
        )

    def _generate_fallback(
        self,
        prompt: str,
        category: str,
        num_frames: int,
        duration: float,
    ) -> KimodoMotion:
        """Generate procedural motion (fallback when Kimodo not installed).

        Uses sine waves with per-joint frequency/amplitude modulation
        based on prompt category. Good enough for pipeline testing.
        """
        from neon.data.action_space import G1_JOINTS

        num_joints = self.config.total_joints
        t = np.linspace(0, duration, num_frames, dtype=np.float32)

        # Base frequencies per joint group
        joint_positions = np.zeros((num_frames, num_joints), dtype=np.float32)

        # Set default standing pose
        for j, joint in enumerate(G1_JOINTS):
            if j < num_joints:
                joint_positions[:, j] = joint.default_pos

        # Add motion based on category
        if category in ("locomotion", "pick_and_navigate"):
            # Sinusoidal leg motion (walking pattern)
            walk_freq = 0.8 + self._rng.uniform(-0.2, 0.2)
            walk_amp = 0.3 + self._rng.uniform(-0.1, 0.1)

            # Left leg
            joint_positions[:, 0] += walk_amp * np.sin(2 * np.pi * walk_freq * t)  # left_hip_pitch
            joint_positions[:, 3] += walk_amp * 0.6 * np.sin(2 * np.pi * walk_freq * t + np.pi * 0.3)  # left_knee
            joint_positions[:, 4] += walk_amp * 0.3 * np.sin(2 * np.pi * walk_freq * t + np.pi * 0.5)  # left_ankle

            # Right leg (anti-phase)
            joint_positions[:, 6] += walk_amp * np.sin(2 * np.pi * walk_freq * t + np.pi)  # right_hip_pitch
            joint_positions[:, 9] += walk_amp * 0.6 * np.sin(2 * np.pi * walk_freq * t + np.pi * 1.3)
            joint_positions[:, 10] += walk_amp * 0.3 * np.sin(2 * np.pi * walk_freq * t + np.pi * 1.5)

            # Arm swing
            joint_positions[:, 15] += 0.2 * np.sin(2 * np.pi * walk_freq * t + np.pi)  # left_shoulder
            joint_positions[:, 22] += 0.2 * np.sin(2 * np.pi * walk_freq * t)  # right_shoulder

        if category in ("manipulation", "pick_and_navigate"):
            # Reaching motion
            reach_start = int(num_frames * 0.2)
            reach_peak = int(num_frames * 0.5)
            reach_end = int(num_frames * 0.8)

            # Smooth reach profile
            reach_profile = np.zeros(num_frames, dtype=np.float32)
            # Ramp up
            if reach_peak > reach_start:
                reach_profile[reach_start:reach_peak] = np.linspace(0, 1, reach_peak - reach_start)
            # Hold
            reach_profile[reach_peak:reach_end] = 1.0
            # Ramp down
            if num_frames > reach_end:
                reach_profile[reach_end:] = np.linspace(1, 0, num_frames - reach_end)

            # Right arm reach forward
            joint_positions[:, 22] += reach_profile * (-0.8)  # right_shoulder_pitch (forward)
            joint_positions[:, 25] += reach_profile * 0.6  # right_elbow (extend)
            joint_positions[:, 14] += reach_profile * 0.1  # waist_pitch (lean forward)

        if category == "interaction":
            # Varied motion: crouch, lean, balance
            phase = self._rng.uniform(0, 2 * np.pi)
            freq = 0.3 + self._rng.uniform(-0.1, 0.1)

            # Slow whole-body motion
            joint_positions[:, 12] += 0.3 * np.sin(2 * np.pi * freq * t + phase)  # waist_yaw
            joint_positions[:, 0] += 0.2 * np.sin(2 * np.pi * freq * 0.5 * t)  # hip
            joint_positions[:, 3] += 0.15 * np.sin(2 * np.pi * freq * 0.5 * t + 0.3)  # knee

        # Add small noise for realism
        noise = self._rng.normal(0, 0.01, joint_positions.shape).astype(np.float32)
        joint_positions += noise

        # Clip to joint limits
        for j, joint in enumerate(G1_JOINTS):
            if j < num_joints:
                joint_positions[:, j] = np.clip(
                    joint_positions[:, j], joint.lower_limit, joint.upper_limit
                )

        # Resample if needed
        if self.config.fps != self.config.output_fps:
            joint_positions = self._resample(
                joint_positions, self.config.fps, self.config.output_fps
            )
            num_frames = joint_positions.shape[0]

        # Synthetic root position (forward walk)
        root_positions = np.zeros((num_frames, 3), dtype=np.float32)
        if category in ("locomotion", "pick_and_navigate"):
            root_positions[:, 0] = np.linspace(0, duration * 0.5, num_frames)  # x forward
        root_positions[:, 2] = 0.8  # standing height

        return KimodoMotion(
            joint_positions=joint_positions,
            prompt=prompt,
            category=category,
            duration=duration,
            fps=self.config.output_fps,
            root_positions=root_positions,
            root_orientations=None,
            metadata={
                "model": "procedural_fallback",
                "category": category,
            },
        )

    def _resample(
        self,
        data: np.ndarray,
        source_fps: int,
        target_fps: int,
    ) -> np.ndarray:
        """Resample time-series data from source_fps to target_fps."""
        if source_fps == target_fps:
            return data

        num_source = data.shape[0]
        duration = num_source / source_fps
        num_target = int(duration * target_fps)

        source_times = np.linspace(0, duration, num_source)
        target_times = np.linspace(0, duration, num_target)

        # Linear interpolation per joint
        resampled = np.zeros((num_target, data.shape[1]), dtype=data.dtype)
        for j in range(data.shape[1]):
            resampled[:, j] = np.interp(target_times, source_times, data[:, j])

        return resampled

    def generate_batch(
        self,
        prompts: Optional[List[str]] = None,
        num_episodes: Optional[int] = None,
        batch_size: int = 32,
    ) -> List[KimodoMotion]:
        """Generate a batch of motions.

        Args:
            prompts: List of text prompts. If None, samples from categories.
            num_episodes: Number of episodes to generate. Defaults to config.
            batch_size: Processing batch size (for GPU efficiency).

        Returns:
            List of KimodoMotion objects.
        """
        n = num_episodes or self.config.num_episodes
        motions = []

        logger.info(f"Generating {n} motions (batch_size={batch_size})")
        start_time = time.time()

        for i in range(n):
            prompt = prompts[i % len(prompts)] if prompts else None
            motion = self.generate(prompt=prompt)
            motions.append(motion)

            if (i + 1) % 100 == 0:
                elapsed = time.time() - start_time
                rate = (i + 1) / elapsed
                eta = (n - i - 1) / rate if rate > 0 else 0
                logger.info(
                    f"Generated {i + 1}/{n} motions "
                    f"({rate:.1f}/s, ETA: {eta:.0f}s)"
                )

        elapsed = time.time() - start_time
        logger.info(f"Generated {n} motions in {elapsed:.1f}s ({n / elapsed:.1f}/s)")
        return motions

    def motion_to_episode(
        self,
        motion: KimodoMotion,
    ) -> Dict[str, Any]:
        """Convert a KimodoMotion to a Neon episode dict.

        Compatible with NeonLeRobotWriter.add_frame() format.
        """
        episode = {
            "joint_positions": motion.joint_positions,  # (T, 43)
            "language_instruction": motion.prompt,
            "root_positions": motion.root_positions,
            "root_orientations": motion.root_orientations,
            "metadata": {
                "source": "kimodo",
                "model": self.config.model_id,
                "category": motion.category,
                "duration": motion.duration,
                "fps": motion.fps,
                **(motion.metadata or {}),
            },
        }

        # Compute actions as joint position targets (same as observations for kinematic)
        # Action = next joint positions (shifted by 1 frame)
        actions = np.zeros((motion.num_frames, 46), dtype=np.float32)  # 43 joints + 3 loco
        actions[:, :motion.num_joints] = motion.joint_positions

        # Locomotion commands from root velocity
        if motion.root_positions is not None and motion.num_frames > 1:
            root_vel = np.diff(motion.root_positions, axis=0) * motion.fps
            root_vel = np.vstack([root_vel, root_vel[-1:]])  # pad last frame
            actions[:, 43] = root_vel[:, 0]  # vx
            actions[:, 44] = root_vel[:, 1]  # vy
            # omega from heading change (if orientation available)
            if motion.root_orientations is not None:
                # Simple: use yaw rate
                actions[:, 45] = 0.0  # TODO: compute from quaternion diff

        episode["actions"] = actions
        return episode

    def run_pipeline(
        self,
        render: bool = True,
        export: bool = True,
    ) -> Dict[str, Any]:
        """Full pipeline: generate motions → (optional) render → export.

        Args:
            render: If True and config.render_in_sim, render all modalities in MuJoCo.
            export: If True, export to LeRobot v3 Parquet.

        Returns:
            Summary dict with stats.
        """
        logger.info("=" * 60)
        logger.info(f"Kimodo Pipeline: {self.config.num_episodes} episodes")
        logger.info(f"Model: {self.config.model_id}")
        logger.info(f"Output: {self.config.repo_id}")
        logger.info("=" * 60)

        # Step 1: Load model
        real_model = self.load_model()
        logger.info(f"Using {'Kimodo model' if real_model else 'procedural fallback'}")

        # Step 2: Generate motions
        motions = self.generate_batch()

        # Step 3: Convert to episodes
        episodes = [self.motion_to_episode(m) for m in motions]

        # Step 4: Render in sim (optional)
        if render and self.config.render_in_sim:
            episodes = self._render_in_sim(episodes, motions)

        # Step 5: Export to LeRobot v3 (optional)
        if export:
            self._export_lerobot(episodes, motions)

        # Summary
        summary = {
            "num_episodes": len(episodes),
            "total_frames": sum(m.num_frames for m in motions),
            "model": self.config.model_id if real_model else "procedural_fallback",
            "categories": {
                cat: sum(1 for m in motions if m.category == cat)
                for cat in set(m.category for m in motions)
            },
            "output": self.config.repo_id,
        }

        logger.info(f"Pipeline complete: {summary}")
        return summary

    def _render_in_sim(
        self,
        episodes: List[Dict[str, Any]],
        motions: List[KimodoMotion],
    ) -> List[Dict[str, Any]]:
        """Render motions in NeonSimEnv to get all sensor modalities."""
        try:
            from neon.sim.env import NeonSimEnv

            logger.info("Rendering motions in NeonSimEnv...")
            env = NeonSimEnv(
                render_width=self.config.sim_image_width,
                render_height=self.config.sim_image_height,
            )

            for i, (episode, motion) in enumerate(zip(episodes, motions)):
                try:
                    env.reset()

                    images = []
                    depths = []
                    lidars = []

                    for t in range(motion.num_frames):
                        # Set joint positions from Kimodo output
                        joint_pos = motion.joint_positions[t, :29]  # body joints only
                        env.set_joint_positions(joint_pos)
                        env.step()

                        # Render
                        rgb = env.render_rgb()
                        images.append(rgb)

                        if hasattr(env, "render_depth"):
                            depths.append(env.render_depth())
                        if hasattr(env, "get_lidar"):
                            lidars.append(env.get_lidar())

                    episode["images"] = np.array(images)
                    if depths:
                        episode["depths"] = np.array(depths)
                    if lidars:
                        episode["lidars"] = np.array(lidars)

                    if (i + 1) % 100 == 0:
                        logger.info(f"Rendered {i + 1}/{len(motions)} episodes")

                except Exception as e:
                    logger.warning(f"Render failed for episode {i}: {e}")
                    continue

            env.close()

        except ImportError:
            logger.warning("NeonSimEnv not available. Skipping rendering.")

        return episodes

    def _export_lerobot(
        self,
        episodes: List[Dict[str, Any]],
        motions: List[KimodoMotion],
    ) -> str:
        """Export episodes to LeRobot v3 Parquet format."""
        output_dir = Path(self.config.output_dir) / self.config.repo_id.split("/")[-1]
        output_dir.mkdir(parents=True, exist_ok=True)

        try:
            from neon.data.lerobot_v3 import NeonLeRobotWriter, NeonLeRobotConfig

            logger.info(f"Exporting {len(episodes)} episodes to {output_dir}")

            writer_config = NeonLeRobotConfig(
                repo_id=self.config.repo_id,
                fps=self.config.output_fps,
            )
            writer = NeonLeRobotWriter(writer_config)

            for i, (episode, motion) in enumerate(zip(episodes, motions)):
                writer.begin_episode()

                for t in range(motion.num_frames):
                    frame_data = {
                        "state": motion.joint_positions[t],
                        "action": episode["actions"][t],
                        "language_instruction": motion.prompt,
                    }

                    # Add rendered images if available
                    if "images" in episode:
                        frame_data["image_head"] = episode["images"][t]
                    if "depths" in episode:
                        frame_data["depth"] = episode["depths"][t]
                    if "lidars" in episode:
                        frame_data["lidar"] = episode["lidars"][t]

                    writer.add_frame(**frame_data)

                writer.end_episode()

                if (i + 1) % 100 == 0:
                    logger.info(f"Exported {i + 1}/{len(episodes)} episodes")

            # Finalize
            writer.finalize()

            if self.config.push_to_hub:
                logger.info(f"Pushing to HuggingFace: {self.config.repo_id}")
                writer.push_to_hub()

            logger.info(f"Export complete: {output_dir}")
            return str(output_dir)

        except ImportError:
            # Fallback: save as numpy
            logger.warning("NeonLeRobotWriter not fully available. Saving as numpy.")
            np.savez(
                str(output_dir / "kimodo_motions.npz"),
                joint_positions=np.array([m.joint_positions for m in motions], dtype=object),
                prompts=np.array([m.prompt for m in motions]),
                categories=np.array([m.category for m in motions]),
            )
            return str(output_dir)


# ── Convenience functions ────────────────────────────────────────────────

def generate_kimodo_dataset(
    preset: str = "diverse_50k",
    render: bool = True,
    export: bool = True,
) -> Dict[str, Any]:
    """One-liner to generate a Kimodo dataset.

    Args:
        preset: "diverse_50k", "constrained_10k", "locomotion_20k", "fast_debug"
        render: Render in MuJoCo sim for all modalities.
        export: Export to LeRobot v3 Parquet.

    Returns:
        Summary dict.

    Example:
        from neon.synth.kimodo_generator import generate_kimodo_dataset
        summary = generate_kimodo_dataset("fast_debug")
    """
    configs = {
        "diverse_50k": KimodoConfig.diverse_50k,
        "constrained_10k": KimodoConfig.constrained_10k,
        "locomotion_20k": KimodoConfig.locomotion_20k,
        "fast_debug": KimodoConfig.fast_debug,
    }

    config_fn = configs.get(preset)
    if config_fn is None:
        raise ValueError(f"Unknown preset: {preset}. Choose from: {list(configs.keys())}")

    config = config_fn()
    generator = KimodoGenerator(config)
    return generator.run_pipeline(render=render, export=export)
