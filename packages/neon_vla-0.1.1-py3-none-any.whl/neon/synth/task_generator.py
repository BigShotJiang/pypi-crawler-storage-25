"""
Task Generator — Procedural task + instruction + scripted trajectory generation.

Generates manipulation and navigation tasks for the G1 in sim environments.
Each task produces:
1. Language instruction (natural language)
2. Target object + goal position
3. Scripted arm trajectory (IK-based) + locomotion commands
4. Success condition

The scripted trajectories are NOT a trained policy — they're expert demonstrations
computed from IK + smooth interpolation. This is the same approach NVIDIA uses in
GR00T-Dreams: scripted expert → sim recording → train VLA on recordings.
"""

from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from neon.data.action_space import G1ActionSpace, G1_JOINTS, ControlMode
from neon.synth.config import TaskConfig

logger = logging.getLogger(__name__)

# ─── Default language templates ────────────────────────────────────

DEFAULT_TEMPLATES: Dict[str, List[str]] = {
    "pick_place": [
        "pick up the {object} and place it on the {target}",
        "move the {object} to the {target}",
        "grab the {object} from the table",
        "take the {object} and put it {direction}",
        "lift the {object} and set it down on the {target}",
    ],
    "push": [
        "push the {object} to the {direction}",
        "slide the {object} towards the {target}",
        "nudge the {object} {direction}",
    ],
    "navigate": [
        "walk to the {target}",
        "move to the {object}",
        "go to the {direction} side of the room",
        "approach the {target}",
    ],
    "pick_and_navigate": [
        "pick up the {object} and bring it to the {target}",
        "grab the {object} then walk to the {target}",
        "carry the {object} to the {direction} side",
    ],
}

DIRECTIONS = ["left", "right", "front", "back", "center", "far side", "near edge"]
TARGETS = ["table center", "left side", "right side", "plate", "bowl", "counter edge"]


@dataclass
class TaskSpec:
    """Specification for a single manipulation/navigation task."""

    task_type: str  # "pick_place", "push", "navigate", "pick_and_navigate"
    instruction: str  # Natural language
    object_name: str  # Target object to interact with
    object_pos: np.ndarray  # (3,) world position of the object
    goal_pos: Optional[np.ndarray] = None  # (3,) target position for the object
    locomotion_target: Optional[np.ndarray] = None  # (3,) walk-to position
    grasp: bool = False  # Whether this task involves grasping
    duration_steps: int = 400  # Episode length in control steps

    @property
    def has_manipulation(self) -> bool:
        return self.task_type in ("pick_place", "push", "pick_and_navigate")

    @property
    def has_navigation(self) -> bool:
        return self.task_type in ("navigate", "pick_and_navigate")


@dataclass
class ScriptedTrajectory:
    """A complete scripted trajectory for a task.

    Contains the full sequence of joint targets + locomotion commands
    that an expert would execute to complete the task.
    """

    joint_targets: np.ndarray  # (T, 43) joint position targets
    locomotion_cmds: np.ndarray  # (T, 3) [vx, vy, omega]
    eef_targets: np.ndarray  # (T, 14) bimanual EEF pos+quat targets
    task_spec: TaskSpec
    phases: List[str]  # Phase names for each timestep (e.g., "approach", "grasp", "lift")


class TaskGenerator:
    """Generates procedural tasks and scripted trajectories.

    Usage:
        gen = TaskGenerator(TaskConfig())
        objects = [{"name": "red_cube", "pos": [0.4, 0.0, 0.75]}]
        task = gen.sample_task(objects)
        trajectory = gen.generate_trajectory(task, current_joint_state)
    """

    def __init__(self, config: TaskConfig = None, seed: int = 42):
        self.config = config or TaskConfig()
        self.rng = np.random.RandomState(seed)
        self.templates = self.config.templates or DEFAULT_TEMPLATES
        self.action_space = G1ActionSpace(
            mode=ControlMode.WHOLE_BODY_HANDS,
            include_locomotion=True,
        )

    def sample_task(
        self,
        objects_in_scene: List[Dict[str, Any]],
        table_pos: np.ndarray = None,
    ) -> TaskSpec:
        """Sample a random task based on objects in the scene.

        Args:
            objects_in_scene: List of dicts with "name" and "pos" keys
            table_pos: (3,) table center position

        Returns:
            TaskSpec with instruction, target, and goals
        """
        if not objects_in_scene:
            # Navigation-only task
            return self._sample_navigation_task(table_pos)

        # Sample task type based on weights
        task_type = self.rng.choice(
            self.config.task_types,
            p=np.array(self.config.task_weights) / sum(self.config.task_weights),
        )

        obj = objects_in_scene[self.rng.randint(len(objects_in_scene))]
        obj_name = obj["name"]
        obj_pos = np.array(obj["pos"], dtype=np.float32)

        if table_pos is None:
            table_pos = np.array([0.55, 0.0, 0.4], dtype=np.float32)

        if task_type == "pick_place":
            return self._sample_pick_place(obj_name, obj_pos, table_pos)
        elif task_type == "push":
            return self._sample_push(obj_name, obj_pos, table_pos)
        elif task_type == "navigate":
            return self._sample_navigation_task(table_pos)
        elif task_type == "pick_and_navigate":
            return self._sample_pick_and_navigate(obj_name, obj_pos, table_pos)
        else:
            return self._sample_pick_place(obj_name, obj_pos, table_pos)

    def _sample_pick_place(
        self, obj_name: str, obj_pos: np.ndarray, table_pos: np.ndarray,
    ) -> TaskSpec:
        target_name = self.rng.choice(TARGETS)
        direction = self.rng.choice(DIRECTIONS)

        template = self.rng.choice(self.templates.get("pick_place", ["pick up the {object}"]))
        instruction = template.format(object=obj_name.replace("_", " "), target=target_name, direction=direction)

        # Compute goal position (random offset on table surface)
        goal_offset = self.rng.uniform(-0.2, 0.2, size=2)
        goal_pos = table_pos.copy()
        goal_pos[0] += goal_offset[0]
        goal_pos[1] += goal_offset[1]
        goal_pos[2] = obj_pos[2]  # Same height as original

        return TaskSpec(
            task_type="pick_place",
            instruction=instruction,
            object_name=obj_name,
            object_pos=obj_pos,
            goal_pos=goal_pos,
            grasp=True,
        )

    def _sample_push(
        self, obj_name: str, obj_pos: np.ndarray, table_pos: np.ndarray,
    ) -> TaskSpec:
        direction = self.rng.choice(DIRECTIONS)
        template = self.rng.choice(self.templates.get("push", ["push the {object} {direction}"]))
        instruction = template.format(object=obj_name.replace("_", " "), direction=direction, target=direction)

        push_dir = self.rng.uniform(-0.15, 0.15, size=2)
        goal_pos = obj_pos.copy()
        goal_pos[0] += push_dir[0]
        goal_pos[1] += push_dir[1]

        return TaskSpec(
            task_type="push",
            instruction=instruction,
            object_name=obj_name,
            object_pos=obj_pos,
            goal_pos=goal_pos,
            grasp=False,
        )

    def _sample_navigation_task(self, table_pos: np.ndarray = None) -> TaskSpec:
        direction = self.rng.choice(DIRECTIONS)
        target = self.rng.choice(TARGETS)
        template = self.rng.choice(self.templates.get("navigate", ["walk to the {target}"]))
        instruction = template.format(target=target, direction=direction, object=target)

        # Random locomotion target within room bounds
        loco_target = np.array([
            self.rng.uniform(-2.0, 2.0),
            self.rng.uniform(-2.0, 2.0),
            0.0,
        ], dtype=np.float32)

        return TaskSpec(
            task_type="navigate",
            instruction=instruction,
            object_name="",
            object_pos=np.zeros(3, dtype=np.float32),
            locomotion_target=loco_target,
        )

    def _sample_pick_and_navigate(
        self, obj_name: str, obj_pos: np.ndarray, table_pos: np.ndarray,
    ) -> TaskSpec:
        target = self.rng.choice(TARGETS)
        template = self.rng.choice(self.templates.get(
            "pick_and_navigate", ["pick up the {object} and bring it to the {target}"]
        ))
        instruction = template.format(
            object=obj_name.replace("_", " "), target=target, direction=self.rng.choice(DIRECTIONS),
        )

        loco_target = np.array([
            self.rng.uniform(-1.5, 1.5),
            self.rng.uniform(-1.5, 1.5),
            0.0,
        ], dtype=np.float32)

        return TaskSpec(
            task_type="pick_and_navigate",
            instruction=instruction,
            object_name=obj_name,
            object_pos=obj_pos,
            goal_pos=loco_target + np.array([0, 0, obj_pos[2]]),
            locomotion_target=loco_target,
            grasp=True,
        )

    # ─── Trajectory generation ──────────────────────────────────────

    def generate_trajectory(
        self,
        task: TaskSpec,
        current_joint_pos: np.ndarray,
        dt: float = 0.02,
    ) -> ScriptedTrajectory:
        """Generate a scripted expert trajectory for the given task.

        Uses IK-based waypoint planning with smooth interpolation.
        Adds Gaussian noise for diversity.

        Args:
            task: The task specification
            current_joint_pos: (N,) initial joint positions (29 or 43)
            dt: Control timestep (1/control_hz)

        Returns:
            ScriptedTrajectory with full joint + locomotion sequences
        """
        num_dofs = len(current_joint_pos)  # 29 (body only) or 43 (body+hands)
        T = task.duration_steps
        joint_targets = np.tile(current_joint_pos[:num_dofs], (T, 1))
        loco_cmds = np.zeros((T, 3), dtype=np.float32)
        eef_targets = np.zeros((T, 14), dtype=np.float32)
        phases = ["idle"] * T

        step = 0

        if task.has_navigation and task.locomotion_target is not None:
            # Phase 1: Navigate to target
            nav_steps = min(T // 2, 200)
            loco_cmds[:nav_steps], nav_phases = self._plan_locomotion(
                task.locomotion_target, nav_steps, dt,
            )
            phases[:nav_steps] = nav_phases
            step = nav_steps

        if task.has_manipulation and task.object_pos is not None:
            remaining = T - step
            manip_targets, manip_phases = self._plan_manipulation(
                task, current_joint_pos, remaining, dt,
            )
            joint_targets[step:step + len(manip_targets)] = manip_targets
            phases[step:step + len(manip_phases)] = manip_phases
            step += len(manip_targets)

        # Add noise for diversity
        noise = self.rng.normal(0, self.config.joint_noise_std, joint_targets.shape).astype(np.float32)
        # Don't add noise to legs (indices 0-11) during manipulation — would destabilize
        if task.has_manipulation:
            noise[:, :12] *= 0.1
        joint_targets += noise

        # Clip to joint limits
        for i, joint in enumerate(G1_JOINTS):
            if i < joint_targets.shape[1]:
                joint_targets[:, i] = np.clip(
                    joint_targets[:, i], joint.lower_limit, joint.upper_limit,
                )

        return ScriptedTrajectory(
            joint_targets=joint_targets,
            locomotion_cmds=loco_cmds,
            eef_targets=eef_targets,
            task_spec=task,
            phases=phases,
        )

    def _plan_locomotion(
        self, target: np.ndarray, num_steps: int, dt: float,
    ) -> Tuple[np.ndarray, List[str]]:
        """Plan locomotion velocity commands to reach a target position.

        Uses a simple proportional controller with acceleration limits.
        """
        cmds = np.zeros((num_steps, 3), dtype=np.float32)
        phases = []

        # Current position estimate (start at origin, integrate velocity)
        pos = np.zeros(2, dtype=np.float32)
        target_2d = target[:2]

        max_vel = 1.0  # m/s
        max_omega = 0.5  # rad/s
        kp = 2.0  # proportional gain

        for i in range(num_steps):
            delta = target_2d - pos
            dist = np.linalg.norm(delta)

            if dist < 0.1:
                phases.append("arrived")
                continue

            # Direction to target
            heading = math.atan2(delta[1], delta[0])

            # Velocity commands (proportional to distance)
            vx = np.clip(kp * dist * math.cos(heading), -max_vel, max_vel)
            vy = np.clip(kp * dist * math.sin(heading), -max_vel * 0.3, max_vel * 0.3)
            omega = np.clip(heading * 0.5, -max_omega, max_omega)

            cmds[i] = [vx, vy, omega]
            phases.append("navigating")

            # Integrate position estimate
            pos[0] += vx * dt
            pos[1] += vy * dt

        return cmds, phases

    def _plan_manipulation(
        self,
        task: TaskSpec,
        initial_joints: np.ndarray,
        num_steps: int,
        dt: float,
    ) -> Tuple[np.ndarray, List[str]]:
        """Plan scripted arm manipulation trajectory.

        Phases:
        1. Approach: Move right EEF above object
        2. Descend: Lower EEF to object height
        3. Grasp: Close fingers (if grasp=True)
        4. Lift: Raise object above table
        5. Transport: Move to goal position
        6. Place: Lower and release
        """
        targets = np.tile(initial_joints[:43], (num_steps, 1))
        phases = ["idle"] * num_steps

        obj_pos = task.object_pos
        goal_pos = task.goal_pos if task.goal_pos is not None else obj_pos

        # Arm joint indices (right arm: 22-28 in SONIC ordering)
        # We'll animate the right arm through IK-like waypoints
        # Simplified: use shoulder + elbow for gross positioning
        right_shoulder_pitch = 22  # Index in 43-DOF
        right_shoulder_roll = 23
        right_shoulder_yaw = 24
        right_elbow = 25
        right_wrist_roll = 26
        right_wrist_pitch = 27
        right_wrist_yaw = 28

        # Phase allocation
        approach_steps = num_steps // 5
        descend_steps = num_steps // 10
        grasp_steps = self.config.grasp_close_steps if task.grasp else 0
        lift_steps = num_steps // 10
        transport_steps = num_steps // 4
        place_steps = num_steps // 10
        hold_steps = num_steps - (approach_steps + descend_steps + grasp_steps + lift_steps + transport_steps + place_steps)

        step = 0

        # Phase 1: Approach — extend arm forward and down
        approach_targets = np.linspace(
            [0.0, -0.3, 0.0, 1.0, 0.0, 0.0, 0.0],  # start (neutral)
            [-0.8, -0.5, 0.0, 1.5, 0.0, -0.3, 0.0],  # end (reaching forward)
            approach_steps,
        ).astype(np.float32)

        for i in range(approach_steps):
            if step + i >= num_steps:
                break
            targets[step + i, right_shoulder_pitch] = approach_targets[i, 0]
            targets[step + i, right_shoulder_roll] = approach_targets[i, 1]
            targets[step + i, right_shoulder_yaw] = approach_targets[i, 2]
            targets[step + i, right_elbow] = approach_targets[i, 3]
            targets[step + i, right_wrist_roll] = approach_targets[i, 4]
            targets[step + i, right_wrist_pitch] = approach_targets[i, 5]
            targets[step + i, right_wrist_yaw] = approach_targets[i, 6]
            phases[step + i] = "approach"
        step += approach_steps

        # Phase 2: Descend — lower arm to object
        for i in range(min(descend_steps, num_steps - step)):
            alpha = i / max(descend_steps, 1)
            targets[step + i, right_shoulder_pitch] = -0.8 - 0.3 * alpha
            targets[step + i, right_elbow] = 1.5 + 0.3 * alpha
            phases[step + i] = "descend"
        step += descend_steps

        # Phase 3: Grasp — close hand fingers
        if task.grasp and grasp_steps > 0:
            # Hand finger indices: 29-42 (only exist in 43-DOF mode)
            # In 29-DOF mode, we simulate grasp by curling wrist
            for i in range(min(grasp_steps, num_steps - step)):
                alpha = i / max(grasp_steps, 1)
                if targets.shape[1] > 36:
                    # 43-DOF: close fingers
                    for finger_idx in range(36, min(43, targets.shape[1])):
                        targets[step + i, finger_idx] = -1.0 * alpha
                else:
                    # 29-DOF: curl wrist as grasp proxy
                    if right_wrist_pitch < targets.shape[1]:
                        targets[step + i, right_wrist_pitch] = -0.5 * alpha
                phases[step + i] = "grasp"
            step += grasp_steps

        # Phase 4: Lift — raise arm
        for i in range(min(lift_steps, num_steps - step)):
            alpha = i / max(lift_steps, 1)
            targets[step + i, right_shoulder_pitch] = -1.1 + 0.5 * alpha
            targets[step + i, right_elbow] = 1.8 - 0.3 * alpha
            phases[step + i] = "lift"
        step += lift_steps

        # Phase 5: Transport — move arm to goal position
        for i in range(min(transport_steps, num_steps - step)):
            alpha = i / max(transport_steps, 1)
            # Smooth S-curve interpolation
            s = 3 * alpha**2 - 2 * alpha**3
            targets[step + i, right_shoulder_pitch] = -0.6
            targets[step + i, right_shoulder_yaw] = s * 0.5  # Rotate towards goal
            targets[step + i, right_elbow] = 1.5
            phases[step + i] = "transport"
        step += transport_steps

        # Phase 6: Place — lower and release
        for i in range(min(place_steps, num_steps - step)):
            alpha = i / max(place_steps, 1)
            targets[step + i, right_shoulder_pitch] = -0.6 - 0.3 * alpha
            targets[step + i, right_elbow] = 1.5 + 0.3 * alpha
            # Open fingers
            if task.grasp:
                if targets.shape[1] > 36:
                    for finger_idx in range(36, min(43, targets.shape[1])):
                        targets[step + i, finger_idx] = -1.0 * (1 - alpha)
                elif right_wrist_pitch < targets.shape[1]:
                    targets[step + i, right_wrist_pitch] = -0.5 * (1 - alpha)
            phases[step + i] = "place"
        step += place_steps

        # Phase 7: Hold / return to neutral
        for i in range(min(hold_steps, num_steps - step)):
            alpha = i / max(hold_steps, 1)
            targets[step + i, right_shoulder_pitch] = -0.9 * (1 - alpha)
            targets[step + i, right_elbow] = 1.8 * (1 - alpha)
            phases[step + i] = "return"

        return targets[:num_steps], phases[:num_steps]
