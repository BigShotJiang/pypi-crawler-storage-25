"""
World Generator — Marble 3D room generation + scene composition.

Ports the MarblePipeline from strands-gtc-nvidia into Neon's synth factory.
Generates 3D rooms from text prompts, places objects, composes with G1 robot.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from neon.sim.scene import OBJECT_LIBRARY, ObjectSpec, SceneBuilder, SceneConfig
from neon.synth.config import WorldGenConfig

logger = logging.getLogger(__name__)

# Scene presets (from strands-gtc-nvidia marble module)
SCENE_PRESETS: Dict[str, Dict[str, Any]] = {
    "kitchen": {
        "prompt": "A modern kitchen with wooden countertops, stainless steel sink, "
                  "and a cutting board with fruits on the counter",
        "objects": ["red_mug", "plate", "bottle", "ball", "can"],
        "table_height": 0.85,
    },
    "workshop": {
        "prompt": "A workshop table with tools, screws in a box, a circuit board, "
                  "and a soldering iron in a well-lit garage",
        "objects": ["red_cube", "blue_cube", "can", "bowl"],
        "table_height": 0.75,
    },
    "office_desk": {
        "prompt": "A cluttered office desk with papers, a coffee mug, pens, "
                  "and a laptop next to a wooden bookshelf",
        "objects": ["blue_mug", "red_cube", "green_cube", "plate"],
        "table_height": 0.72,
    },
    "living_room": {
        "prompt": "A cozy living room with a coffee table, scattered toys, "
                  "folded towels, and a houseplant near a window",
        "objects": ["ball", "red_cube", "bowl", "bottle"],
        "table_height": 0.45,
    },
    "warehouse": {
        "prompt": "A warehouse aisle with metal shelving, cardboard boxes of "
                  "varying sizes, and a packing station",
        "objects": ["red_cube", "blue_cube", "can", "can"],
        "table_height": 0.80,
    },
    "lab_bench": {
        "prompt": "A clean laboratory bench with beakers, test tubes in a rack, "
                  "a microscope, and a precision scale",
        "objects": ["bottle", "bottle", "plate", "bowl"],
        "table_height": 0.90,
    },
    "restaurant": {
        "prompt": "A restaurant table with plates, napkins, wine glasses, "
                  "cutlery, and a bread basket, warm ambient lighting",
        "objects": ["plate", "plate", "blue_mug", "bowl"],
        "table_height": 0.75,
    },
    "outdoor_garden": {
        "prompt": "A garden table on a patio with potted plants, a watering can, "
                  "garden tools, and a wooden fence background",
        "objects": ["bottle", "bowl", "can", "ball"],
        "table_height": 0.70,
    },
}


@dataclass
class GeneratedWorld:
    """A generated 3D world ready for physics simulation."""

    world_id: str
    preset: str
    prompt: str
    # Marble outputs (may be None if API not available)
    ply_path: Optional[str] = None
    glb_path: Optional[str] = None
    spz_path: Optional[str] = None
    usdz_path: Optional[str] = None
    marble_world_id: Optional[str] = None
    # Scene composition (always available)
    scene_xml: Optional[str] = None  # MuJoCo MJCF for the scene (objects + table)
    objects: List[ObjectSpec] = None
    table_pos: np.ndarray = None
    table_height: float = 0.75
    output_dir: str = ""
    metadata: Dict[str, Any] = None

    def __post_init__(self):
        if self.objects is None:
            self.objects = []
        if self.table_pos is None:
            self.table_pos = np.array([0.55, 0.0, 0.0], dtype=np.float32)
        if self.metadata is None:
            self.metadata = {}


class WorldGenerator:
    """Generates 3D worlds from Marble API + procedural scene composition.

    Two paths:
    1. Full Marble path: API call → PLY/GLB/SPZ → convert → compose USD
    2. Fallback path: procedural MuJoCo scene (SceneBuilder) — always works

    The physics simulation always uses the MuJoCo scene (path 2), but
    Cosmos Transfer uses the Marble visuals (path 1) to make it look real.
    """

    def __init__(self, config: WorldGenConfig, seed: int = 42):
        self.config = config
        self._seed = seed
        self.rng = np.random.RandomState(seed)
        self._marble_pipeline = None
        self._worlds: List[GeneratedWorld] = []

    def generate_all(self, output_dir: str) -> List[GeneratedWorld]:
        """Generate all worlds from presets + custom prompts.

        Returns:
            List of GeneratedWorld objects ready for physics sim.
        """
        os.makedirs(output_dir, exist_ok=True)
        worlds = []

        # Generate from presets
        for preset_name in self.config.presets:
            if preset_name not in SCENE_PRESETS:
                logger.warning(f"Unknown preset: {preset_name}, skipping")
                continue

            for var_idx in range(self.config.worlds_per_preset):
                world = self._generate_single_world(
                    preset_name=preset_name,
                    variation_idx=var_idx,
                    output_dir=output_dir,
                )
                worlds.append(world)

        # Generate from custom prompts
        for prompt_idx, prompt in enumerate(self.config.custom_prompts):
            world = self._generate_single_world(
                preset_name="custom",
                variation_idx=prompt_idx,
                output_dir=output_dir,
                custom_prompt=prompt,
            )
            worlds.append(world)

        self._worlds = worlds
        logger.info(f"Generated {len(worlds)} worlds in {output_dir}")
        return worlds

    def _generate_single_world(
        self,
        preset_name: str,
        variation_idx: int,
        output_dir: str,
        custom_prompt: str = None,
    ) -> GeneratedWorld:
        """Generate a single world variation."""
        world_id = f"{preset_name}_{variation_idx:04d}_{uuid.uuid4().hex[:6]}"
        world_dir = os.path.join(output_dir, world_id)
        os.makedirs(world_dir, exist_ok=True)

        preset = SCENE_PRESETS.get(preset_name, SCENE_PRESETS["kitchen"])
        prompt = custom_prompt or preset["prompt"]

        # Vary the prompt slightly for diversity
        if variation_idx > 0 and not custom_prompt:
            lighting_variants = ["warm lighting", "bright fluorescent", "natural daylight", "dim ambient", "soft LED"]
            material_variants = ["wooden", "marble", "stainless steel", "granite", "white laminate"]
            prompt += f", {self.rng.choice(lighting_variants)}, {self.rng.choice(material_variants)} surfaces"

        world = GeneratedWorld(
            world_id=world_id,
            preset=preset_name,
            prompt=prompt,
            table_height=preset.get("table_height", 0.75),
            output_dir=world_dir,
            metadata={"variation_idx": variation_idx, "seed": self.rng.randint(2**31)},
        )

        # Step 1: Try Marble API for 3D room generation
        marble_result = self._try_marble_generation(prompt, world_dir)
        if marble_result:
            world.ply_path = marble_result.get("ply_path")
            world.glb_path = marble_result.get("glb_path")
            world.spz_path = marble_result.get("spz_path")
            world.usdz_path = marble_result.get("usdz_path")
            world.marble_world_id = marble_result.get("world_id")
            world.metadata["marble"] = marble_result.get("metadata", {})

        # Step 2: Generate procedural MuJoCo scene (always — this is what physics uses)
        scene_config = SceneConfig(
            table_pos=(0.55, 0.0, 0.0),
            table_size=(0.4, 0.6, world.table_height),
            num_objects=self.config.objects_per_scene,
            object_types=preset.get("objects", list(OBJECT_LIBRARY.keys())),
            randomize_lighting=True,
            seed=world.metadata["seed"],
        )

        builder = SceneBuilder(scene_config)
        asset_xml, worldbody_xml = builder.build()
        world.objects = builder.objects
        world.table_pos = np.array(scene_config.table_pos, dtype=np.float32)

        # Save scene data
        scene_data = {
            "world_id": world_id,
            "preset": preset_name,
            "prompt": prompt,
            "objects": [
                {"name": o.name, "shape": o.shape, "pos": list(o.pos),
                 "size": list(o.size), "rgba": list(o.rgba), "mass": o.mass}
                for o in world.objects
            ],
            "table_pos": list(scene_config.table_pos),
            "table_height": world.table_height,
            "has_marble": world.ply_path is not None or world.spz_path is not None,
        }
        with open(os.path.join(world_dir, "world_meta.json"), "w") as f:
            json.dump(scene_data, f, indent=2)

        logger.debug(f"World {world_id}: {len(world.objects)} objects, marble={world.ply_path is not None}")
        return world

    def _try_marble_generation(self, prompt: str, output_dir: str) -> Optional[Dict[str, Any]]:
        """Try to generate a 3D room via Marble API.

        Returns None if Marble is not available or API key is not set.
        """
        api_key = self.config.api_key or os.getenv("WLT_API_KEY") or os.getenv("MARBLE_API_KEY")
        if not api_key:
            logger.debug("Marble API key not set — using procedural scenes only")
            return None

        try:
            import requests
            import time as _time

            MARBLE_API_URL = "https://api.worldlabs.ai"
            headers = {
                "Content-Type": "application/json",
                "WLT-Api-Key": api_key,
            }

            # POST /marble/v1/worlds:generate
            payload = {
                "world_prompt": {"type": "text", "text_prompt": prompt},
                "model": "Marble 0.1-plus",
                "permission": {"public": False},
                "seed": self._seed,
            }
            resp = requests.post(
                f"{MARBLE_API_URL}/marble/v1/worlds:generate",
                headers=headers,
                json=payload,
                timeout=60,
            )
            resp.raise_for_status()
            operation_id = resp.json()["operation_id"]
            logger.info(f"Marble generation started: {operation_id}")

            # Poll until done (max 10 min)
            deadline = _time.time() + 600
            world = None
            while _time.time() < deadline:
                poll = requests.get(
                    f"{MARBLE_API_URL}/marble/v1/operations/{operation_id}",
                    headers=headers,
                    timeout=30,
                )
                poll.raise_for_status()
                data = poll.json()
                if data.get("done"):
                    error = data.get("error")
                    if error and isinstance(error, dict) and error.get("message"):
                        raise RuntimeError(f"Marble error: {error['message']}")
                    world = data.get("response") or data.get("result") or data.get("world")
                    if not world:
                        # The entire data might be the world if response/result keys missing
                        logger.debug(f"Marble operation response keys: {list(data.keys())}")
                        if "world_id" in data or "assets" in data:
                            world = data
                    break
                _time.sleep(5)

            if not world:
                raise RuntimeError("Marble generation timed out or returned empty response")

            # Save raw response for debugging
            import json as _json
            debug_path = os.path.join(output_dir, "marble_raw_response.json")
            os.makedirs(output_dir, exist_ok=True)
            with open(debug_path, "w") as f:
                _json.dump(world, f, indent=2, default=str)
            logger.info(f"Marble raw response saved: {debug_path}")

            # Download assets — handle both v1 (world.assets) and v2 (world directly) formats
            if not isinstance(world, dict):
                raise RuntimeError(f"Unexpected Marble response type: {type(world)}")

            result = {"metadata": world, "world_id": world.get("world_id")}
            os.makedirs(output_dir, exist_ok=True)

            # Try both possible asset locations
            assets = world.get("assets") or world or {}

            # Collider mesh (GLB)
            mesh = assets.get("mesh") or {}
            if mesh.get("collider_mesh_url"):
                glb_path = os.path.join(output_dir, "scene.glb")
                r = requests.get(mesh["collider_mesh_url"], headers=headers, timeout=120, stream=True)
                with open(glb_path, "wb") as f:
                    for chunk in r.iter_content(8192):
                        f.write(chunk)
                result["glb_path"] = glb_path

            # SPZ Gaussian splat
            splats = assets.get("splats") or {}
            spz_urls = splats.get("spz_urls") or {}
            if spz_urls:
                key = next((k for k in ["500k", "full_res", "100k"] if k in spz_urls), next(iter(spz_urls)))
                spz_path = os.path.join(output_dir, f"scene_{key}.spz")
                r = requests.get(spz_urls[key], headers=headers, timeout=120, stream=True)
                with open(spz_path, "wb") as f:
                    for chunk in r.iter_content(8192):
                        f.write(chunk)
                result["spz_path"] = spz_path

            # Panorama
            imagery = assets.get("imagery") or {}
            if imagery.get("pano_url"):
                pano_path = os.path.join(output_dir, "pano.jpg")
                r = requests.get(imagery["pano_url"], headers=headers, timeout=60, stream=True)
                with open(pano_path, "wb") as f:
                    for chunk in r.iter_content(8192):
                        f.write(chunk)
                result["ply_path"] = pano_path  # Use as visual reference

            return result

        except Exception as e:
            logger.warning(f"Marble generation failed: {e}")

        return None

    @property
    def worlds(self) -> List[GeneratedWorld]:
        return self._worlds
