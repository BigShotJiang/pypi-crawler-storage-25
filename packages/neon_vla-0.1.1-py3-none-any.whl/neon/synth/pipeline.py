"""
SynthPipeline — The master orchestrator for synthetic data generation.

Ties together:
1. WorldGenerator → 3D rooms from Marble + procedural objects
2. NewtonCollector → GPU-parallel physics simulation + data collection
3. CosmosAugmentor → sim→real visual augmentation
4. NeonLeRobotWriter → LeRobot v3 export (same schema as real teleop)

Usage:
    from neon.synth import SynthPipeline, SynthConfig

    # Quick: 10K kitchen episodes
    pipeline = SynthPipeline(SynthConfig.kitchen_10k())
    pipeline.run()

    # Full: 50K diverse episodes
    pipeline = SynthPipeline(SynthConfig.diverse_50k())
    pipeline.run()

    # Debug: tiny config, no GPU, no Cosmos
    pipeline = SynthPipeline(SynthConfig.fast_debug())
    pipeline.run()
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from neon.synth.config import SynthConfig

logger = logging.getLogger(__name__)


class SynthPipeline:
    """Master pipeline for synthetic data factory.

    Orchestrates the full flow: world gen → physics → cosmos → export.
    Designed for resilience: each stage saves intermediate results,
    and the pipeline can resume from any stage.
    """

    def __init__(self, config: SynthConfig = None):
        self.config = config or SynthConfig()
        self._worlds = []
        self._episodes = []
        self._video_paths = []
        self._cosmos_results = []
        self._start_time = None

        # Setup logging
        logging.basicConfig(
            level=getattr(logging, self.config.log_level),
            format="%(asctime)s %(levelname)s [neon.synth] %(message)s",
        )

        # Create output directory
        os.makedirs(self.config.output_dir, exist_ok=True)

    def run(self, start_stage: int = 1, end_stage: int = 4) -> Dict[str, Any]:
        """Run the full pipeline (or a subset of stages).

        Stages:
            1. World generation (Marble + procedural objects)
            2. Physics simulation + data collection (Newton GPU)
            3. Visual augmentation (Cosmos Transfer 2.5)
            4. Export to LeRobot v3 + push to HuggingFace

        Args:
            start_stage: First stage to run (1-4)
            end_stage: Last stage to run (1-4)

        Returns:
            Pipeline results dict with stats and paths
        """
        self._start_time = time.time()

        self._print_banner()
        self._save_config()

        results = {}

        try:
            if start_stage <= 1 <= end_stage:
                results["stage1"] = self._stage1_world_generation()

            if start_stage <= 2 <= end_stage:
                results["stage2"] = self._stage2_physics_collection()

            if start_stage <= 3 <= end_stage:
                results["stage3"] = self._stage3_cosmos_augmentation()

            if start_stage <= 4 <= end_stage:
                results["stage4"] = self._stage4_export()

        except Exception as e:
            logger.error(f"Pipeline failed at stage: {e}")
            results["error"] = str(e)
            # Save progress so far
            self._save_progress(results)
            raise

        # Final summary
        elapsed = time.time() - self._start_time
        results["total_time_s"] = round(elapsed, 1)
        results["total_time_min"] = round(elapsed / 60, 1)

        self._save_progress(results)
        self._print_summary(results)

        return results

    # ─── Stage 1: World Generation ──────────────────────────────────

    def _stage1_world_generation(self) -> Dict[str, Any]:
        """Generate 3D worlds from Marble + procedural objects."""
        logger.info("=" * 60)
        logger.info("STAGE 1: World Generation")
        logger.info("=" * 60)
        t0 = time.time()

        from neon.synth.world_generator import WorldGenerator

        generator = WorldGenerator(self.config.world, seed=self.config.seed)
        worlds_dir = os.path.join(self.config.output_dir, "worlds")
        self._worlds = generator.generate_all(worlds_dir)

        elapsed = time.time() - t0
        result = {
            "num_worlds": len(self._worlds),
            "presets": self.config.world.presets,
            "worlds_dir": worlds_dir,
            "time_s": round(elapsed, 1),
            "marble_count": sum(1 for w in self._worlds if w.ply_path or w.spz_path),
            "procedural_count": len(self._worlds),
        }

        logger.info(
            f"Stage 1 complete: {result['num_worlds']} worlds "
            f"({result['marble_count']} Marble, {result['procedural_count']} procedural) "
            f"in {elapsed:.1f}s"
        )
        return result

    # ─── Stage 2: Physics Simulation ────────────────────────────────

    def _stage2_physics_collection(self) -> Dict[str, Any]:
        """Run Newton GPU simulation and collect all modalities."""
        logger.info("=" * 60)
        logger.info("STAGE 2: Physics Simulation + Data Collection")
        logger.info("=" * 60)
        t0 = time.time()

        from neon.synth.newton_collector import NewtonCollector
        from neon.synth.task_generator import TaskGenerator

        task_gen = TaskGenerator(self.config.tasks, seed=self.config.seed)
        collector = NewtonCollector(self.config.physics)

        try:
            collector.setup()
            self._episodes = collector.collect(
                worlds=self._worlds,
                task_generator=task_gen,
                num_episodes_per_world=self.config.physics.episodes_per_world,
            )
        finally:
            collector.cleanup()

        # Save intermediate video files for Cosmos Transfer
        self._video_paths = self._save_episode_videos()

        elapsed = time.time() - t0
        total_steps = sum(ep.num_steps for ep in self._episodes)
        total_frames = sum(ep.num_frames for ep in self._episodes)

        result = {
            "num_episodes": len(self._episodes),
            "total_steps": total_steps,
            "total_frames": total_frames,
            "num_videos": len(self._video_paths),
            "time_s": round(elapsed, 1),
            "eps_per_second": round(len(self._episodes) / max(elapsed, 1), 1),
        }

        logger.info(
            f"Stage 2 complete: {result['num_episodes']} episodes, "
            f"{total_frames} frames, {total_steps} steps in {elapsed:.1f}s"
        )
        return result

    def _save_episode_videos(self) -> List[str]:
        """Save rendered frames as MP4 videos for Cosmos Transfer input."""
        video_dir = os.path.join(self.config.output_dir, "sim_videos")
        os.makedirs(video_dir, exist_ok=True)
        paths = []

        for ep in self._episodes:
            if not ep.frames:
                continue

            video_path = os.path.join(video_dir, f"episode_{ep.episode_id:06d}.mp4")

            try:
                # Try ffmpeg (best quality)
                self._save_video_ffmpeg(ep.frames, video_path, self.config.physics.render_hz)
                paths.append(video_path)
            except Exception:
                try:
                    # Fallback: imageio
                    import imageio
                    writer = imageio.get_writer(video_path, fps=self.config.physics.render_hz, quality=8)
                    for frame in ep.frames:
                        writer.append_data(frame)
                    writer.close()
                    paths.append(video_path)
                except Exception:
                    try:
                        # Fallback: cv2
                        import cv2
                        h, w = ep.frames[0].shape[:2]
                        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                        out = cv2.VideoWriter(video_path, fourcc, self.config.physics.render_hz, (w, h))
                        for frame in ep.frames:
                            out.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
                        out.release()
                        paths.append(video_path)
                    except Exception as e:
                        logger.warning(f"Cannot save video for episode {ep.episode_id}: {e}")

        logger.info(f"Saved {len(paths)} episode videos to {video_dir}")
        return paths

    @staticmethod
    def _save_video_ffmpeg(frames: List[np.ndarray], output_path: str, fps: int):
        """Save frames as MP4 via ffmpeg subprocess pipe."""
        h, w = frames[0].shape[:2]
        cmd = [
            "ffmpeg", "-y", "-f", "rawvideo", "-vcodec", "rawvideo",
            "-s", f"{w}x{h}", "-pix_fmt", "rgb24", "-r", str(fps),
            "-i", "-", "-an", "-vcodec", "libx264", "-pix_fmt", "yuv420p",
            "-crf", "20", "-preset", "fast", output_path,
        ]
        proc = subprocess.Popen(
            cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        for frame in frames:
            proc.stdin.write(frame.astype(np.uint8).tobytes())
        proc.stdin.close()
        proc.wait()
        if proc.returncode != 0:
            raise RuntimeError(f"ffmpeg failed with code {proc.returncode}")

    # ─── Stage 3: Cosmos Transfer ───────────────────────────────────

    def _stage3_cosmos_augmentation(self) -> Dict[str, Any]:
        """Apply Cosmos Transfer 2.5 to make sim videos look real."""
        logger.info("=" * 60)
        logger.info("STAGE 3: Cosmos Transfer 2.5 Visual Augmentation")
        logger.info("=" * 60)
        t0 = time.time()

        from neon.synth.cosmos_augmentor import CosmosAugmentor

        augmentor = CosmosAugmentor(self.config.cosmos)
        cosmos_dir = os.path.join(self.config.output_dir, "cosmos_videos")

        if not self._video_paths:
            logger.info("No videos to augment — skipping Cosmos Transfer")
            return {"skipped": True, "reason": "no_videos"}

        # Build prompts from episode tasks + world presets
        prompts = []
        for ep in self._episodes:
            if ep.frames:  # Only for episodes with video
                world = next((w for w in self._worlds if w.world_id == ep.world_id), None)
                scene_type = world.preset if world else "room"
                prompt = self.config.cosmos.prompt_template.format(
                    robot_type="Unitree G1 humanoid",
                    scene_type=scene_type,
                )
                prompts.append(prompt)

        try:
            self._cosmos_results = augmentor.augment_batch(
                video_paths=self._video_paths,
                prompts=prompts,
                output_dir=cosmos_dir,
            )
        finally:
            augmentor.cleanup()

        elapsed = time.time() - t0
        success_count = sum(1 for r in self._cosmos_results if r.get("success"))

        result = {
            "total_videos": len(self._video_paths),
            "augmented": success_count,
            "fallbacks": len(self._video_paths) - success_count,
            "cosmos_dir": cosmos_dir,
            "time_s": round(elapsed, 1),
        }

        logger.info(
            f"Stage 3 complete: {success_count}/{len(self._video_paths)} augmented "
            f"in {elapsed:.1f}s"
        )
        return result

    # ─── Stage 4: LeRobot v3 Export ─────────────────────────────────

    def _stage4_export(self) -> Dict[str, Any]:
        """Export all collected data to LeRobot v3 format."""
        logger.info("=" * 60)
        logger.info("STAGE 4: LeRobot v3 Export")
        logger.info("=" * 60)
        t0 = time.time()

        from neon.data.lerobot_v3 import NeonLeRobotWriter, NeonWriterConfig, make_neon_features
        from neon.sim.env import synthesize_audio_from_text

        export_cfg = self.config.export
        physics_cfg = self.config.physics

        features = make_neon_features(
            image_height=physics_cfg.image_height,
            image_width=physics_cfg.image_width,
            include_hand_camera=export_cfg.include_hand_camera,
            include_lidar=export_cfg.include_lidar and physics_cfg.lidar_enabled,
            include_audio=export_cfg.include_audio,
            include_eef=export_cfg.include_eef,
        )

        writer_config = NeonWriterConfig(
            repo_id=export_cfg.repo_id,
            fps=export_cfg.fps,
            features=features,
            source=export_cfg.source_tag,
            sim_engine="newton",
            push_to_hub=export_cfg.push_to_hub,
            private=export_cfg.private,
            vcodec=export_cfg.vcodec,
        )

        writer = NeonLeRobotWriter(writer_config)
        writer.open()

        # Build a map from episode_id to cosmos-augmented video path
        cosmos_map: Dict[int, str] = {}
        if self._cosmos_results:
            for ep, result in zip(
                [e for e in self._episodes if e.frames],
                self._cosmos_results,
            ):
                if result.get("output_path") and os.path.exists(result["output_path"]):
                    cosmos_map[ep.episode_id] = result["output_path"]

        # Write episodes
        for ep in self._episodes:
            writer.start_episode(task=ep.task.instruction)

            # Determine video frames source
            # If Cosmos augmented, we'd need to decode the video back to frames
            # For now, use the sim frames (Cosmos video is stored separately)
            frames = ep.frames
            render_ratio = max(1, physics_cfg.control_hz // physics_cfg.render_hz)

            for step_idx in range(ep.num_steps):
                # Image (at render_hz, not control_hz)
                frame_idx = step_idx // render_ratio
                image_head = frames[frame_idx] if frame_idx < len(frames) else None

                # Joint state (43-DOF)
                state = ep.joint_states[step_idx] if step_idx < len(ep.joint_states) else None

                # Action (43 joints + 3 locomotion = 46)
                action = ep.actions[step_idx] if step_idx < len(ep.actions) else None

                # EEF state (14-DOF)
                eef_state = ep.eef_states[step_idx] if step_idx < len(ep.eef_states) else None

                # LiDAR (placeholder — raycast would be computed per-step in full impl)
                lidar = None
                if export_cfg.include_lidar:
                    # Generate synthetic lidar from a simple floor+table model
                    lidar = self._synthetic_lidar_scan()

                # Audio (synthesized from task instruction)
                audio = None
                if export_cfg.include_audio and step_idx == 0:
                    audio = synthesize_audio_from_text(
                        ep.task.instruction,
                        duration=self.config.tasks.audio_duration,
                        sample_rate=self.config.tasks.audio_sample_rate,
                    )

                writer.add_frame(
                    image_head=image_head,
                    state=state,
                    action=action,
                    eef_state=eef_state,
                    lidar=lidar,
                    audio=audio,
                    language=ep.task.instruction,
                )

            writer.end_episode()

        # Save and push
        writer.save_and_push()

        elapsed = time.time() - t0
        result = {
            "repo_id": export_cfg.repo_id,
            "num_episodes": len(self._episodes),
            "total_frames_written": sum(ep.num_steps for ep in self._episodes),
            "cosmos_augmented_videos": len(cosmos_map),
            "pushed_to_hub": export_cfg.push_to_hub,
            "time_s": round(elapsed, 1),
        }

        logger.info(
            f"Stage 4 complete: {result['num_episodes']} episodes → "
            f"{export_cfg.repo_id} in {elapsed:.1f}s"
        )
        return result

    @staticmethod
    def _synthetic_lidar_scan(n_points: int = 4096) -> np.ndarray:
        """Generate a simple synthetic LiDAR scan.

        Creates a basic point cloud representing a floor + table scene.
        Not physically accurate — just fills the LiDAR channel so the
        encoder has something to learn from.
        """
        points = np.zeros((n_points, 4), dtype=np.float32)

        # Floor points (60%)
        n_floor = int(n_points * 0.6)
        points[:n_floor, 0] = np.random.uniform(-3, 3, n_floor)  # x
        points[:n_floor, 1] = np.random.uniform(-3, 3, n_floor)  # y
        points[:n_floor, 2] = np.random.normal(0, 0.01, n_floor)  # z ≈ 0
        points[:n_floor, 3] = np.random.uniform(0.3, 0.5, n_floor)  # intensity

        # Table points (25%)
        n_table = int(n_points * 0.25)
        points[n_floor:n_floor + n_table, 0] = np.random.uniform(0.2, 0.9, n_table)
        points[n_floor:n_floor + n_table, 1] = np.random.uniform(-0.5, 0.5, n_table)
        points[n_floor:n_floor + n_table, 2] = np.random.uniform(0.7, 0.8, n_table)
        points[n_floor:n_floor + n_table, 3] = np.random.uniform(0.5, 0.8, n_table)

        # Object points (15%)
        n_obj = n_points - n_floor - n_table
        points[n_floor + n_table:, 0] = np.random.uniform(0.3, 0.7, n_obj)
        points[n_floor + n_table:, 1] = np.random.uniform(-0.3, 0.3, n_obj)
        points[n_floor + n_table:, 2] = np.random.uniform(0.8, 1.0, n_obj)
        points[n_floor + n_table:, 3] = np.random.uniform(0.6, 1.0, n_obj)

        return points

    # ─── Utilities ──────────────────────────────────────────────────

    def _save_config(self):
        """Save config snapshot for reproducibility."""
        import dataclasses

        config_path = os.path.join(self.config.output_dir, "synth_config.json")
        with open(config_path, "w") as f:
            json.dump(dataclasses.asdict(self.config), f, indent=2, default=str)

    def _save_progress(self, results: Dict):
        """Save pipeline progress/results."""
        progress_path = os.path.join(self.config.output_dir, "pipeline_results.json")
        with open(progress_path, "w") as f:
            json.dump(results, f, indent=2, default=str)

    def _print_banner(self):
        print("=" * 60)
        print("  🤖 Neon Synthetic Data Factory")
        print("=" * 60)
        print(f"  Worlds:    {self.config.total_worlds}")
        print(f"  Episodes:  {self.config.total_episodes}")
        print(f"  Frames:    ~{self.config.total_frames:,}")
        print(f"  Envs:      {self.config.physics.num_envs} parallel (Newton GPU)")
        print(f"  Cosmos:    {'enabled' if self.config.cosmos.enabled else 'disabled'}")
        print(f"  Output:    {self.config.export.repo_id}")
        print("=" * 60)

    # ─── GEN4: Omni-Modal Recording Config ─────────────────────────

    @staticmethod
    def omnimodal_recording_config(
        repo_id: str = "cagataydev/neon-g1-omni-kitchen-10k",
        num_episodes: int = 10_000,
        scene_type: str = "kitchen",
        fps: int = 20,
        image_height: int = 480,
        image_width: int = 640,
        push_to_hub: bool = True,
    ) -> Dict[str, Any]:
        """Generate a 10K episode omni-modal dataset recording configuration.

        Produces a config dict for recording kitchen-scene episodes with all
        9 Neon modalities:
            1. RGB camera (head)
            2. Language instruction
            3. Audio (synthetic TTS)
            4. Proprioception (43-DOF joint state)
            5. LiDAR (4096 points)
            6. EEF (14-DOF bimanual)
            7. GPS (6-DOF lat/lon/alt/heading/pitch/roll)
            8. Depth (float32 depth map)
            9. Segmentation (uint8 class mask)

        Usage:
            config = SynthPipeline.omnimodal_recording_config()
            # Use config["features"] with NeonLeRobotWriter
            # Use config["synth_config"] with SynthPipeline

        Args:
            repo_id: HuggingFace dataset ID for the generated dataset
            num_episodes: Target number of episodes (default: 10,000)
            scene_type: Scene preset (default: "kitchen")
            fps: Recording FPS (default: 20)
            image_height: Camera frame height
            image_width: Camera frame width
            push_to_hub: Whether to push to HuggingFace Hub

        Returns:
            Dict with:
                - features: LeRobot v3 feature schema (all 9 modalities)
                - writer_config: NeonWriterConfig kwargs
                - synth_config: SynthConfig for the full pipeline
                - modalities: List of all 9 modality names
                - recording_plan: Episode count, scene type, etc.
        """
        from neon.data.lerobot_v3 import make_neon_features, NeonWriterConfig

        # Build full 9-modality feature schema
        features = make_neon_features(
            image_height=image_height,
            image_width=image_width,
            include_hand_camera=False,  # Kitchen typically uses head camera only
            include_lidar=True,
            include_audio=True,
            include_eef=True,
            include_gps=True,
            include_depth=True,
            include_segmentation=True,
            depth_height=image_height,
            depth_width=image_width,
            seg_num_classes=20,  # Kitchen: floor, wall, table, cup, plate, etc.
            seg_height=image_height,
            seg_width=image_width,
        )

        # Calculate physics config for target episode count
        worlds_per_preset = max(1, num_episodes // 100)  # 100 episodes per world
        episodes_per_world = max(1, num_episodes // worlds_per_preset)

        # Build SynthConfig
        synth_config = SynthConfig(
            world=__import__('neon.synth.config', fromlist=['WorldGenConfig']).WorldGenConfig(
                presets=[scene_type],
                worlds_per_preset=worlds_per_preset,
                objects_per_scene=5,
            ),
            physics=__import__('neon.synth.config', fromlist=['PhysicsConfig']).PhysicsConfig(
                num_envs=256,
                episodes_per_world=episodes_per_world,
                episode_steps=400,  # 8 seconds at 50Hz control
                image_height=image_height,
                image_width=image_width,
                lidar_enabled=True,
            ),
            cosmos=__import__('neon.synth.config', fromlist=['CosmosConfig']).CosmosConfig(
                enabled=True,
                output_resolution="480",
            ),
            export=__import__('neon.synth.config', fromlist=['ExportConfig']).ExportConfig(
                repo_id=repo_id,
                fps=fps,
                push_to_hub=push_to_hub,
                include_lidar=True,
                include_audio=True,
                include_eef=True,
            ),
        )

        # Writer config kwargs
        writer_config_kwargs = {
            "repo_id": repo_id,
            "fps": fps,
            "features": features,
            "source": "synth",
            "sim_engine": "newton",
            "push_to_hub": push_to_hub,
            "robot_type": "unitree_g1",
        }

        modalities = [
            "rgb_camera",
            "language",
            "audio",
            "proprioception",
            "lidar",
            "eef",
            "gps",
            "depth",
            "segmentation",
        ]

        # Kitchen task templates
        kitchen_tasks = [
            "pick up the {object}",
            "move the {object} to the {location}",
            "push the {object} across the table",
            "stack the {object} on the {object2}",
            "open the drawer",
            "close the cabinet",
            "wipe the table surface",
            "sort the utensils",
        ]
        kitchen_objects = ["red cup", "blue mug", "plate", "bowl", "spoon", "fork", "bottle", "sponge"]
        kitchen_locations = ["counter", "sink", "stove", "shelf", "table center"]

        return {
            "features": features,
            "writer_config": writer_config_kwargs,
            "synth_config": synth_config,
            "modalities": modalities,
            "num_modalities": len(modalities),
            "recording_plan": {
                "num_episodes": num_episodes,
                "scene_type": scene_type,
                "fps": fps,
                "image_resolution": f"{image_width}x{image_height}",
                "worlds": worlds_per_preset,
                "episodes_per_world": episodes_per_world,
                "estimated_frames": num_episodes * 400 // (50 // fps),
                "estimated_hours": round(num_episodes * 8 / 3600, 1),
            },
            "task_templates": kitchen_tasks,
            "objects": kitchen_objects,
            "locations": kitchen_locations,
        }

    def _print_summary(self, results: Dict):
        elapsed = results.get("total_time_s", 0)
        print()
        print("=" * 60)
        print("  ✅ Pipeline Complete")
        print(f"  Time: {elapsed:.0f}s ({elapsed/60:.1f} min)")
        for stage_key in ["stage1", "stage2", "stage3", "stage4"]:
            if stage_key in results:
                stage = results[stage_key]
                print(f"  {stage_key}: {json.dumps({k: v for k, v in stage.items() if k != 'cosmos_dir'}, default=str)[:100]}")
        if "error" in results:
            print(f"  ❌ Error: {results['error']}")
        print("=" * 60)
