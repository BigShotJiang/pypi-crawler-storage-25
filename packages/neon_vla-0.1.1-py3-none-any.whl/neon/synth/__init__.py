"""
Neon Synth — Synthetic Data Factory for G1 VLA Training.

Generates photorealistic, physics-accurate training data at scale by combining:
1. Marble 3D world generation (World Labs API)
2. Newton GPU-parallel physics simulation (4096+ envs)
3. Cosmos Transfer 2.5 visual augmentation (sim→real)
4. IDM action extraction (NVIDIA GR00T-Dreams inverse dynamics)
5. LeRobot v3 export (same schema as real teleop)

The output is indistinguishable from real G1 teleop data in schema, and
visually competitive thanks to Cosmos Transfer. Actions are refined by
blending MuJoCo physics with IDM visual predictions for best quality.

Usage:
    from neon.synth import SynthPipeline, SynthConfig

    pipeline = SynthPipeline(SynthConfig(
        marble_presets=["kitchen", "workshop"],
        num_envs=256,
        episodes_per_world=100,
        cosmos_enabled=True,
        output_repo_id="cagataydev/neon-g1-synth-10k",
    ))
    pipeline.run()
"""

from neon.synth.config import SynthConfig
from neon.synth.pipeline import SynthPipeline

__all__ = ["SynthPipeline", "SynthConfig"]
