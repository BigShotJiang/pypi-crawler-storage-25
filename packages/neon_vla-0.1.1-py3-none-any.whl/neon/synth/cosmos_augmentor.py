"""
Cosmos Augmentor — Visual augmentation via Cosmos Transfer 2.5.

Transforms simulation-rendered RGB videos into photorealistic footage.
Robot pose is preserved via depth/edge ControlNet conditioning.

Ported from strands-gtc-nvidia/strands_robots/cosmos_transfer/__init__.py.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from neon.synth.config import CosmosConfig

logger = logging.getLogger(__name__)


class CosmosAugmentor:
    """Applies Cosmos Transfer 2.5 sim→real augmentation to episode videos.

    Wraps the Cosmos Transfer pipeline with batch processing support.
    Falls back to original sim video if Cosmos is unavailable.

    Usage:
        augmentor = CosmosAugmentor(CosmosConfig(num_gpus=2))
        results = augmentor.augment_batch(video_paths, prompts, output_dir)
    """

    def __init__(self, config: CosmosConfig):
        self.config = config
        self._pipeline = None
        self._tmp_dirs: List[str] = []

    def augment_single(
        self,
        sim_video_path: str,
        prompt: str,
        output_path: str,
    ) -> Dict[str, Any]:
        """Augment a single simulation video.

        Args:
            sim_video_path: Path to sim-rendered MP4
            prompt: Scene description for Cosmos generation
            output_path: Path for photorealistic output MP4

        Returns:
            Dict with output_path, success status, method used
        """
        if not self.config.enabled:
            # Pass-through: copy sim video as-is
            shutil.copy2(sim_video_path, output_path)
            return {"output_path": output_path, "success": True, "method": "passthrough"}

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        # Strategy 1: Try strands_robots.cosmos_transfer (full pipeline)
        result = self._try_strands_cosmos(sim_video_path, prompt, output_path)
        if result:
            return result

        # Strategy 2: Try cosmos_transfer2 CLI directly
        result = self._try_cosmos_cli(sim_video_path, prompt, output_path)
        if result:
            return result

        # Strategy 3: Fallback — copy original with warning
        if self.config.skip_on_failure:
            logger.warning(
                f"Cosmos Transfer not available — using sim video: {sim_video_path}"
            )
            shutil.copy2(sim_video_path, output_path)
            return {"output_path": output_path, "success": True, "method": "sim_fallback"}

        raise RuntimeError(
            "Cosmos Transfer 2.5 not available. Install with: pip install cosmos-transfer2\n"
            "Or set cosmos.enabled=False to skip visual augmentation."
        )

    def augment_batch(
        self,
        video_paths: List[str],
        prompts: List[str],
        output_dir: str,
    ) -> List[Dict[str, Any]]:
        """Augment a batch of simulation videos.

        Args:
            video_paths: List of sim video paths
            prompts: List of scene description prompts (one per video)
            output_dir: Directory for output videos

        Returns:
            List of result dicts (one per video)
        """
        os.makedirs(output_dir, exist_ok=True)
        results = []
        total = len(video_paths)

        for i, (video_path, prompt) in enumerate(zip(video_paths, prompts)):
            stem = Path(video_path).stem
            output_path = os.path.join(output_dir, f"{stem}_real.mp4")

            try:
                result = self.augment_single(video_path, prompt, output_path)
                results.append(result)
            except Exception as e:
                logger.error(f"Cosmos augmentation failed for {video_path}: {e}")
                # Copy original as fallback
                shutil.copy2(video_path, output_path)
                results.append({
                    "output_path": output_path,
                    "success": False,
                    "method": "error_fallback",
                    "error": str(e),
                })

            if (i + 1) % 10 == 0:
                logger.info(f"  Cosmos augmentation: {i+1}/{total}")

        success_count = sum(1 for r in results if r.get("success"))
        logger.info(
            f"Cosmos batch complete: {success_count}/{total} augmented, "
            f"{total - success_count} fallbacks"
        )
        return results

    def _try_strands_cosmos(
        self, sim_video: str, prompt: str, output_path: str,
    ) -> Optional[Dict[str, Any]]:
        """Try Cosmos Transfer via strands_robots module."""
        try:
            from strands_robots.cosmos_transfer import (
                CosmosTransferConfig,
                CosmosTransferPipeline,
            )

            if self._pipeline is None:
                config = CosmosTransferConfig(
                    model_variant=self.config.model_variant,
                    checkpoint_path=self.config.checkpoint_path,
                    cosmos_transfer_path=self.config.cosmos_transfer_path,
                    num_gpus=self.config.num_gpus,
                    guidance=self.config.guidance,
                    num_steps=self.config.num_steps,
                    control_weight=self.config.control_weight,
                    output_resolution=self.config.output_resolution,
                    seed=self.config.seed,
                )
                self._pipeline = CosmosTransferPipeline(config)

            result = self._pipeline.transfer_video(
                sim_video_path=sim_video,
                prompt=prompt,
                output_path=output_path,
                control_types=self.config.control_types,
            )
            return {
                "output_path": result["output_path"],
                "success": True,
                "method": "strands_cosmos",
                "frame_count": result.get("frame_count", 0),
            }
        except ImportError:
            logger.debug("strands_robots.cosmos_transfer not available")
            return None
        except Exception as e:
            logger.warning(f"strands_robots cosmos transfer failed: {e}")
            return None

    # Cosmos Transfer 2.5 requires exactly N frames per chunk.
    # The 2B model uses num_video_frames_per_chunk=93 by default.
    # Videos shorter than this get padded internally, but the control
    # branch does NOT pad — causing an assertion error.  Fix: resample
    # the input video to exactly the chunk size before calling Cosmos.
    COSMOS_CHUNK_FRAMES = 93
    COSMOS_FPS = 16  # Cosmos native FPS

    @staticmethod
    def _resample_video_to_frames(
        video_path: str, target_frames: int, output_path: str
    ) -> str:
        """Resample a video to exactly `target_frames` frames.

        Uses frame interpolation (duplicate/drop) to match exactly.
        Returns path to resampled video.
        """
        try:
            import cv2
        except ImportError:
            return video_path  # can't resample without cv2

        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            return video_path

        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        if total == 0:
            cap.release()
            return video_path

        # Read all frames
        frames = []
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            frames.append(frame)
        cap.release()

        if not frames:
            return video_path

        actual = len(frames)
        if actual == target_frames:
            return video_path  # already correct

        # Resample: pick frames at evenly spaced indices
        indices = np.linspace(0, actual - 1, target_frames).astype(int)
        resampled = [frames[i] for i in indices]

        # Write resampled video at Cosmos native FPS
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(output_path, fourcc, 16.0, (w, h))
        for frame in resampled:
            writer.write(frame)
        writer.release()

        logger.info(f"Resampled {actual} → {target_frames} frames: {output_path}")
        return output_path

    def _try_cosmos_cli(
        self, sim_video: str, prompt: str, output_path: str,
    ) -> Optional[Dict[str, Any]]:
        """Try Cosmos Transfer via CLI (cosmos_transfer2 package)."""
        # Resolve checkpoint
        checkpoint = (
            self.config.checkpoint_path
            or os.environ.get("COSMOS_CHECKPOINT_DIR")
        )
        if not checkpoint or not os.path.isdir(str(checkpoint)):
            logger.debug("Cosmos checkpoint not found")
            return None

        # Resolve Cosmos Transfer path
        cosmos_root = (
            self.config.cosmos_transfer_path
            or os.environ.get("COSMOS_TRANSFER_PATH")
        )
        inference_script = None
        if cosmos_root:
            candidate = os.path.join(cosmos_root, "examples", "inference.py")
            if os.path.isfile(candidate):
                inference_script = candidate

        if not inference_script:
            logger.debug("Cosmos inference script not found")
            return None

        # Build working directory
        work_dir = tempfile.mkdtemp(prefix="neon_cosmos_")
        self._tmp_dirs.append(work_dir)

        # ── Resample input video to exactly COSMOS_CHUNK_FRAMES ──
        # Cosmos Transfer asserts control_input length == expected chunk frames.
        # The video branch pads short videos but the control branch doesn't,
        # causing an assertion error.  We fix this by giving Cosmos exactly
        # the right number of frames upfront.
        resampled_video = os.path.join(work_dir, "input_resampled.mp4")
        resampled_video = self._resample_video_to_frames(
            sim_video, self.COSMOS_CHUNK_FRAMES, resampled_video
        )

        # ── Detect distilled checkpoint ──
        # If the checkpoint dir contains a "distilled" subdirectory, prefer it
        # (uses ~4GB VRAM vs ~30GB for full model)
        distilled_ckpt = None
        for root, dirs, files in os.walk(checkpoint):
            for f in files:
                if "distilled" in root.lower() and f.endswith("_ema_bf16.pt"):
                    distilled_ckpt = os.path.join(root, f)
                    break
            if distilled_ckpt:
                break

        # Build inference spec (matches Cosmos Transfer InferenceArguments)
        spec = {
            "name": Path(output_path).stem,
            "prompt": prompt,
            "video_path": os.path.abspath(resampled_video),
            "guidance": self.config.guidance,
            "num_steps": self.config.num_steps,
            "num_video_frames_per_chunk": self.COSMOS_CHUNK_FRAMES,
            "resolution": self.config.output_resolution or "480",
            "seed": self.config.seed,
        }

        # Let Cosmos generate edge maps on-the-fly from the video
        # (don't provide external control_path — Cosmos computes edges internally)
        for ct in self.config.control_types:
            spec[ct] = {
                "control_weight": self.config.control_weight,
            }

        spec_path = os.path.join(work_dir, "spec.json")
        with open(spec_path, "w") as f:
            json.dump(spec, f, indent=2)

        # ── Resolve Python interpreter ──
        # Cosmos needs its own venv with torch + CUDA deps
        cosmos_python = None
        if cosmos_root:
            cosmos_venv_python = os.path.join(cosmos_root, ".venv", "bin", "python3")
            if os.path.isfile(cosmos_venv_python):
                cosmos_python = cosmos_venv_python
        if not cosmos_python:
            cosmos_python = shutil.which("python3") or shutil.which("python")

        # ── Build command ──
        ckpt_arg = distilled_ckpt or str(checkpoint)
        cmd = [
            cosmos_python, inference_script,
            "-i", spec_path,
            "-o", work_dir,
            "--model", "edge",
            "--disable-guardrails",
        ]
        # Only pass --checkpoint-path for distilled (single .pt file)
        # For the full model dir, Cosmos auto-downloads from HuggingFace
        if distilled_ckpt:
            cmd.extend(["--checkpoint-path", distilled_ckpt])

        if self.config.num_gpus > 1:
            torchrun = shutil.which("torchrun")
            if torchrun:
                cmd = [
                    torchrun, f"--nproc_per_node={self.config.num_gpus}",
                    inference_script, "-i", spec_path, "-o", work_dir,
                    "--model", "edge", "--disable-guardrails",
                ]
                if distilled_ckpt:
                    cmd.extend(["--checkpoint-path", distilled_ckpt])

        # Append the control subcommand (tyro expects it as positional)
        cmd.append("control:edge")

        # ── Environment: ensure uv/uvx is on PATH for checkpoint downloads ──
        env = dict(os.environ)
        home = os.path.expanduser("~")
        env["PATH"] = os.path.join(home, ".local", "bin") + ":" + env.get("PATH", "")
        env["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

        logger.info(f"Cosmos CLI: {' '.join(cmd[:6])}...")
        logger.info(f"Spec: frames={self.COSMOS_CHUNK_FRAMES}, "
                     f"distilled={'yes' if distilled_ckpt else 'no'}, "
                     f"resolution={spec.get('resolution')}")

        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=900, env=env
            )

            if result.returncode == 0:
                # Find output video — Cosmos saves as <name>.mp4 in work_dir
                mp4s = sorted(
                    Path(work_dir).glob("*.mp4"),
                    key=lambda p: p.stat().st_mtime,
                    reverse=True,
                )
                # Filter out our input files
                mp4s = [p for p in mp4s if "input_resampled" not in p.name
                        and "control" not in p.name]
                if mp4s:
                    shutil.copy2(str(mp4s[0]), output_path)
                    logger.info(f"Cosmos output: {mp4s[0]} → {output_path}")
                    return {
                        "output_path": output_path,
                        "success": True,
                        "method": "cosmos_cli" + ("_distilled" if distilled_ckpt else ""),
                    }
                else:
                    logger.warning(f"Cosmos succeeded but no output MP4 found in {work_dir}")
            else:
                # Log failure details for debugging
                stderr_tail = result.stderr[-500:] if result.stderr else ""
                stdout_tail = result.stdout[-500:] if result.stdout else ""
                logger.warning(
                    f"Cosmos CLI failed (rc={result.returncode}):\n"
                    f"STDOUT: {stdout_tail}\nSTDERR: {stderr_tail}"
                )
        except subprocess.TimeoutExpired:
            logger.warning("Cosmos CLI timed out (900s)")
        except Exception as e:
            logger.warning(f"Cosmos CLI error: {e}")

        return None

    def _generate_control(self, control_type: str, video_path: str, work_dir: str) -> Optional[str]:
        """Generate a control signal video (depth, edge, or seg)."""
        output = os.path.join(work_dir, f"{control_type}_control.mp4")

        try:
            import cv2
        except ImportError:
            return None

        if control_type == "edge":
            return self._generate_edge_control(video_path, output)
        elif control_type == "depth":
            return self._generate_depth_control(video_path, output)
        elif control_type == "seg":
            return self._generate_seg_control(video_path, output)
        return None

    def _generate_edge_control(self, video_path: str, output_path: str) -> Optional[str]:
        """Generate Canny edge control video."""
        try:
            import cv2

            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                return None

            fps = cap.get(cv2.CAP_PROP_FPS) or 20.0
            w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(output_path, fourcc, fps, (w, h))

            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                grey = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                blurred = cv2.GaussianBlur(grey, (5, 5), 1.4)
                edges = cv2.Canny(blurred, 100, 200)
                writer.write(cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR))

            cap.release()
            writer.release()
            return output_path
        except Exception:
            return None

    def _generate_depth_control(self, video_path: str, output_path: str) -> Optional[str]:
        """Generate greyscale depth proxy control video."""
        try:
            import cv2

            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                return None

            fps = cap.get(cv2.CAP_PROP_FPS) or 20.0
            w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(output_path, fourcc, fps, (w, h))

            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                grey = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                writer.write(cv2.cvtColor(grey, cv2.COLOR_GRAY2BGR))

            cap.release()
            writer.release()
            return output_path
        except Exception:
            return None

    def _generate_seg_control(self, video_path: str, output_path: str) -> Optional[str]:
        """Generate colour-quantized segmentation control video."""
        try:
            import cv2

            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                return None

            fps = cap.get(cv2.CAP_PROP_FPS) or 20.0
            w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(output_path, fourcc, fps, (w, h))
            criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)

            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                pixels = frame.reshape(-1, 3).astype(np.float32)
                _, labels, centers = cv2.kmeans(pixels, 8, None, criteria, 3, cv2.KMEANS_PP_CENTERS)
                seg = centers[labels.flatten()].reshape(h, w, 3).astype(np.uint8)
                writer.write(seg)

            cap.release()
            writer.release()
            return output_path
        except Exception:
            return None

    # =================================================================
    # GEN5: Omni-Modal Sim2Real Augmentation Pipeline
    # =================================================================

    def augment_omnimodal(
        self,
        rgb_frames: List[np.ndarray],
        depth_frames: List[np.ndarray],
        seg_frames: List[np.ndarray],
        prompt: str,
        output_dir: str,
        episode_id: int = 0,
        fps: int = 20,
    ) -> Dict[str, Any]:
        """Augment RGB+depth+segmentation from sim → photorealistic via Cosmos Transfer.

        This is the core sim2real augmentation method. It takes all three visual
        modalities from MuJoCo rendering and:
        1. Uses depth as structural conditioning (preserves 3D layout)
        2. Uses segmentation as semantic conditioning (preserves object identity)
        3. Transforms RGB into photorealistic footage via Cosmos Transfer 2.5

        The depth and segmentation remain unchanged (they're ground truth from
        the simulator), while the RGB is replaced with photorealistic frames
        that match the same geometric and semantic structure.

        Args:
            rgb_frames: List of (H, W, 3) uint8 RGB frames from MuJoCo
            depth_frames: List of (H, W) float32 depth maps in meters
            seg_frames: List of (H, W) uint8 segmentation masks
            prompt: Scene description for Cosmos generation
            output_dir: Directory for output files
            episode_id: Episode identifier for file naming
            fps: Frame rate for video encoding

        Returns:
            Dict with:
                - rgb_augmented: Path to photorealistic video (or None)
                - depth_preserved: Path to depth video (unchanged)
                - seg_preserved: Path to segmentation video (unchanged)
                - success: Whether Cosmos augmentation succeeded
                - method: "cosmos_omnimodal", "passthrough", or "error"
                - rgb_frames: List of augmented RGB frames (if decode available)
        """
        os.makedirs(output_dir, exist_ok=True)

        result = {
            "rgb_augmented": None,
            "depth_preserved": None,
            "seg_preserved": None,
            "success": False,
            "method": "passthrough",
            "rgb_frames": rgb_frames,  # Default: unchanged
        }

        if not rgb_frames:
            result["method"] = "error"
            result["error"] = "No RGB frames provided"
            return result

        prefix = f"episode_{episode_id:06d}"

        # Step 1: Save sim RGB as temporary video for Cosmos input
        sim_video_path = os.path.join(output_dir, f"{prefix}_sim_rgb.mp4")
        try:
            self._save_frames_as_video(rgb_frames, sim_video_path, fps)
        except Exception as e:
            logger.warning(f"Failed to save sim video: {e}")
            result["error"] = str(e)
            return result

        # Step 2: Generate depth control video from depth frames
        depth_control_path = None
        if depth_frames:
            depth_control_path = os.path.join(output_dir, f"{prefix}_depth_control.mp4")
            try:
                self._save_depth_as_control_video(depth_frames, depth_control_path, fps)
                result["depth_preserved"] = depth_control_path
            except Exception as e:
                logger.debug(f"Depth control video failed: {e}")

        # Step 3: Generate segmentation control video from seg frames
        seg_control_path = None
        if seg_frames:
            seg_control_path = os.path.join(output_dir, f"{prefix}_seg_control.mp4")
            try:
                self._save_seg_as_control_video(seg_frames, seg_control_path, fps)
                result["seg_preserved"] = seg_control_path
            except Exception as e:
                logger.debug(f"Seg control video failed: {e}")

        # Step 4: Run Cosmos Transfer with depth+seg conditioning
        cosmos_output_path = os.path.join(output_dir, f"{prefix}_real_rgb.mp4")

        if self.config.enabled:
            cosmos_result = self.augment_single(
                sim_video_path=sim_video_path,
                prompt=prompt,
                output_path=cosmos_output_path,
            )

            if cosmos_result.get("success"):
                result["rgb_augmented"] = cosmos_result["output_path"]
                result["success"] = True
                result["method"] = "cosmos_omnimodal"
                # Try to decode augmented frames back
                try:
                    result["rgb_frames"] = self._decode_video_frames(cosmos_result["output_path"])
                except Exception:
                    pass  # Keep original frames as fallback
            else:
                result["rgb_augmented"] = sim_video_path
                result["method"] = "passthrough"
                result["success"] = True  # Still usable with sim frames
        else:
            # Cosmos disabled — pass through sim frames
            result["rgb_augmented"] = sim_video_path
            result["success"] = True
            result["method"] = "passthrough"

        return result

    @staticmethod
    def _save_frames_as_video(frames: List[np.ndarray], path: str, fps: int):
        """Save RGB frames as MP4 video."""
        if not frames:
            return

        h, w = frames[0].shape[:2]

        try:
            import cv2
            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(path, fourcc, fps, (w, h))
            for frame in frames:
                writer.write(cv2.cvtColor(frame, cv2.COLOR_RGB2BGR))
            writer.release()
        except ImportError:
            # Fallback: raw frame dump as numpy
            np.save(path.replace(".mp4", ".npy"), np.stack(frames))

    @staticmethod
    def _save_depth_as_control_video(
        depth_frames: List[np.ndarray], path: str, fps: int
    ):
        """Save depth maps as greyscale control video for Cosmos conditioning."""
        if not depth_frames:
            return

        h, w = depth_frames[0].shape[:2]

        try:
            import cv2
            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(path, fourcc, fps, (w, h))
            for depth in depth_frames:
                # Normalise depth to [0, 255] for visualisation
                d_min = np.nanmin(depth)
                d_max = np.nanmax(depth)
                if d_max > d_min:
                    norm = ((depth - d_min) / (d_max - d_min) * 255).astype(np.uint8)
                else:
                    norm = np.zeros_like(depth, dtype=np.uint8)
                writer.write(cv2.cvtColor(norm, cv2.COLOR_GRAY2BGR))
            writer.release()
        except ImportError:
            np.save(path.replace(".mp4", ".npy"), np.stack(depth_frames))

    @staticmethod
    def _save_seg_as_control_video(
        seg_frames: List[np.ndarray], path: str, fps: int
    ):
        """Save segmentation masks as colour-coded control video."""
        if not seg_frames:
            return

        h, w = seg_frames[0].shape[:2]

        # Colour palette for segmentation classes (up to 20 classes)
        palette = np.array([
            [0, 0, 0],       # 0: background (black)
            [128, 128, 128], # 1: ground (grey)
            [0, 0, 255],     # 2: robot (blue)
            [139, 69, 19],   # 3: table (brown)
            [255, 0, 0],     # 4: object 1 (red)
            [0, 255, 0],     # 5: object 2 (green)
            [255, 255, 0],   # 6: object 3 (yellow)
            [255, 0, 255],   # 7: object 4 (magenta)
            [0, 255, 255],   # 8: object 5 (cyan)
            [255, 128, 0],   # 9: object 6 (orange)
            [128, 0, 255],   # 10: object 7 (purple)
            [255, 255, 255], # 11+: white
        ] + [[255, 255, 255]] * 245, dtype=np.uint8)  # pad to 256

        try:
            import cv2
            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(path, fourcc, fps, (w, h))
            for seg in seg_frames:
                colour = palette[seg.clip(0, 255)]
                writer.write(cv2.cvtColor(colour, cv2.COLOR_RGB2BGR))
            writer.release()
        except ImportError:
            np.save(path.replace(".mp4", ".npy"), np.stack(seg_frames))

    @staticmethod
    def _decode_video_frames(video_path: str) -> List[np.ndarray]:
        """Decode an MP4 video back to a list of RGB frames."""
        try:
            import cv2
            cap = cv2.VideoCapture(video_path)
            frames = []
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                frames.append(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            cap.release()
            return frames
        except ImportError:
            return []

    def cleanup(self):
        """Remove temp directories."""
        for d in self._tmp_dirs:
            if os.path.isdir(d):
                shutil.rmtree(d, ignore_errors=True)
        self._tmp_dirs.clear()
        if self._pipeline and hasattr(self._pipeline, "cleanup"):
            self._pipeline.cleanup()
