"""
Synthetic Data Factory Configuration.

Central config for the entire pipeline: world generation, physics sim,
visual augmentation, task generation, and export.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass
class WorldGenConfig:
    """Configuration for Marble 3D world generation."""

    # Marble API
    api_key: Optional[str] = None  # Falls back to WLT_API_KEY / MARBLE_API_KEY env
    model: str = "Marble 0.1-plus"
    presets: List[str] = field(default_factory=lambda: ["kitchen", "workshop", "office_desk", "living_room"])
    custom_prompts: List[str] = field(default_factory=list)
    worlds_per_preset: int = 25  # Total unique rooms = len(presets) * worlds_per_preset
    convert_to_usdz: bool = True  # PLY → USDZ via 3DGrut or OpenUSD
    # Object placement
    objects_per_scene: int = 5
    object_scatter_radius: float = 0.25  # meters from table center
    # 3D object sources (HuggingFace dataset IDs or local dirs)
    object_datasets: List[str] = field(default_factory=lambda: [
        "nvidia/PhysicalAI-Robotics-GR00T-Kitchen-Objects",  # NVIDIA kitchen 3D meshes
    ])
    # Fallback: use Neon's built-in procedural objects if no mesh datasets available
    use_procedural_fallback: bool = True


@dataclass
class PhysicsConfig:
    """Configuration for Newton GPU physics simulation."""

    # Parallelism
    num_envs: int = 256  # Parallel envs on GPU (4096 on H100, 256 on A100)
    device: str = "cuda:0"
    solver: str = "mujoco"  # Newton solver backend

    # Timing
    sim_hz: int = 200  # Physics substep rate
    control_hz: int = 50  # Policy / data collection rate
    render_hz: int = 20  # Camera frame rate (matches real teleop)

    # Episode
    episode_steps: int = 400  # At 50Hz = 8 seconds
    episodes_per_world: int = 100  # Tasks per generated room

    # Robot
    robot_model: str = "unitree_g1"
    num_dofs: int = 43  # 29 body + 14 hand
    use_sonic_gains: bool = True  # SONIC PD gains from action_space.py
    initial_height: float = 0.8  # meters above ground

    # Locomotion policy (pre-trained RL)
    loco_policy_path: Optional[str] = None  # Path to .pt JIT policy
    loco_policy_config: Optional[str] = None  # Path to .yaml config

    # Camera
    image_width: int = 640
    image_height: int = 480

    # LiDAR raycast
    lidar_enabled: bool = True
    lidar_num_horizontal: int = 180
    lidar_num_vertical: int = 12
    lidar_range_max: float = 30.0
    lidar_noise_std: float = 0.002

    # Domain randomization per-world
    randomize_lighting: bool = True
    randomize_friction: bool = True
    friction_range: Tuple[float, float] = (0.5, 1.5)
    randomize_mass: bool = True
    mass_range: Tuple[float, float] = (0.7, 1.3)
    randomize_camera_noise: bool = True
    camera_noise_std: float = 0.01  # Gaussian pixel noise


@dataclass
class TaskConfig:
    """Configuration for procedural task generation."""

    # Task types to generate
    task_types: List[str] = field(default_factory=lambda: [
        "pick_place", "push", "navigate", "pick_and_navigate",
    ])
    # Weights for task type sampling
    task_weights: List[float] = field(default_factory=lambda: [0.4, 0.1, 0.3, 0.2])

    # Scripted manipulation
    reach_speed: float = 0.5  # m/s approach speed
    grasp_close_steps: int = 20  # Steps to close gripper
    transport_height: float = 0.15  # Lift height above table (meters)
    place_tolerance: float = 0.05  # meters

    # Noise for diversity
    joint_noise_std: float = 0.03  # radians per joint per step
    eef_noise_std: float = 0.005  # meters per step

    # Language templates
    templates: Optional[Dict[str, List[str]]] = None  # None = use defaults

    # Audio synthesis
    audio_enabled: bool = True
    audio_sample_rate: int = 16000
    audio_duration: float = 2.0  # seconds per frame window


@dataclass
class CosmosConfig:
    """Configuration for Cosmos Transfer 2.5 visual augmentation."""

    enabled: bool = True
    model_variant: str = "depth"
    checkpoint_path: Optional[str] = None  # Falls back to COSMOS_CHECKPOINT_DIR env
    cosmos_transfer_path: Optional[str] = None  # Falls back to COSMOS_TRANSFER_PATH env
    num_gpus: int = 1
    guidance: float = 3.0
    num_steps: int = 35
    control_types: List[str] = field(default_factory=lambda: ["depth", "edge"])
    control_weight: float = 1.0
    output_resolution: str = "256"  # "256" for L40S (46GB), "480" for A100 (80GB), "720" for quality
    seed: int = 2025
    # Prompts (auto-generated from Marble scene description if empty)
    prompt_template: str = (
        "A {robot_type} humanoid robot in a {scene_type}, "
        "realistic lighting, high quality, photorealistic"
    )
    # Batch processing
    max_concurrent_transfers: int = 4  # Parallel Cosmos Transfer jobs
    skip_on_failure: bool = True  # Use sim video if Cosmos fails


@dataclass
class IDMConfig:
    """Configuration for IDM (Inverse Dynamics Model) action extraction.

    Uses NVIDIA's GR00T-Dreams IDM to extract visually-grounded robot actions
    from Cosmos-generated photorealistic videos. The IDM watches video frames
    and predicts what joint actions would produce the observed motion.

    Pipeline: Cosmos video → frame pairs → IDM → predicted actions
    Integration: blend IDM actions with MuJoCo sim actions for best quality.
    """

    enabled: bool = False  # Disabled by default — requires extra deps
    checkpoint: str = "seonghyeonye/IDM_gr1"  # HuggingFace model ID
    embodiment: str = "gr1"  # gr1, franka, so100
    device: str = "cuda"
    batch_size: int = 4
    video_delta_indices: str = "0 8"  # frame pairs: t and t+8

    # Action blending: merge sim physics with IDM visual predictions
    # 0.0 = pure sim actions, 1.0 = pure IDM, 0.3 = recommended
    blend_weight: float = 0.3

    # Map GR1 44-DoF → G1 43-DoF
    enable_g1_mapping: bool = True

    # Path to GR00T-Dreams repo (optional, for full pipeline)
    groot_dreams_path: Optional[str] = None


@dataclass
class ExportConfig:
    """Configuration for LeRobot v3 dataset export."""

    repo_id: str = "cagataydev/neon-g1-synth-v1"
    fps: int = 20  # Recording FPS (matches real teleop)
    push_to_hub: bool = True
    private: bool = True
    source_tag: str = "synth"
    # Which modalities to include
    include_lidar: bool = True
    include_audio: bool = True
    include_eef: bool = True
    include_hand_camera: bool = False  # Sim typically has one camera
    # Video encoding
    vcodec: str = "libx264"


@dataclass
class SynthConfig:
    """Master configuration for the synthetic data factory."""

    # Sub-configs
    world: WorldGenConfig = field(default_factory=WorldGenConfig)
    physics: PhysicsConfig = field(default_factory=PhysicsConfig)
    tasks: TaskConfig = field(default_factory=TaskConfig)
    cosmos: CosmosConfig = field(default_factory=CosmosConfig)
    idm: IDMConfig = field(default_factory=IDMConfig)
    export: ExportConfig = field(default_factory=ExportConfig)

    # Global
    seed: int = 42
    output_dir: str = "/tmp/neon_synth"
    log_level: str = "INFO"

    # Convenience setters for common patterns
    @property
    def total_worlds(self) -> int:
        n_preset = len(self.world.presets) * self.world.worlds_per_preset
        n_custom = len(self.world.custom_prompts)
        return n_preset + n_custom

    @property
    def total_episodes(self) -> int:
        return self.total_worlds * self.physics.episodes_per_world

    @property
    def total_frames(self) -> int:
        """Estimated total video frames."""
        steps_per_ep = self.physics.episode_steps
        render_ratio = self.physics.control_hz // self.physics.render_hz
        frames_per_ep = steps_per_ep // render_ratio
        return self.total_episodes * frames_per_ep

    # ── Preset factories ────────────────────────────────────────

    @classmethod
    def kitchen_10k(cls) -> "SynthConfig":
        """10K kitchen episodes — first milestone target."""
        return cls(
            world=WorldGenConfig(
                presets=["kitchen"],
                worlds_per_preset=100,
                objects_per_scene=5,
            ),
            physics=PhysicsConfig(
                num_envs=256,
                episodes_per_world=100,
                episode_steps=400,
            ),
            cosmos=CosmosConfig(enabled=True, output_resolution="480"),
            idm=IDMConfig(enabled=True, blend_weight=0.3),
            export=ExportConfig(repo_id="cagataydev/neon-g1-synth-kitchen-10k"),
        )

    @classmethod
    def diverse_50k(cls) -> "SynthConfig":
        """50K diverse episodes across 4 environments."""
        return cls(
            world=WorldGenConfig(
                presets=["kitchen", "workshop", "office_desk", "living_room"],
                worlds_per_preset=50,
                objects_per_scene=6,
            ),
            physics=PhysicsConfig(
                num_envs=512,
                episodes_per_world=250,
                episode_steps=400,
            ),
            cosmos=CosmosConfig(enabled=True, output_resolution="480"),
            idm=IDMConfig(enabled=True, blend_weight=0.3),
            export=ExportConfig(repo_id="cagataydev/neon-g1-synth-diverse-50k"),
        )

    @classmethod
    def fast_debug(cls) -> "SynthConfig":
        """Tiny config for testing the pipeline locally."""
        return cls(
            world=WorldGenConfig(
                presets=["kitchen"],
                worlds_per_preset=1,
                objects_per_scene=2,
            ),
            physics=PhysicsConfig(
                num_envs=4,
                episodes_per_world=2,
                episode_steps=50,
                device="cpu",
            ),
            cosmos=CosmosConfig(enabled=False),
            export=ExportConfig(
                repo_id="local/neon-synth-debug",
                push_to_hub=False,
            ),
            output_dir="/tmp/neon_synth_debug",
        )
