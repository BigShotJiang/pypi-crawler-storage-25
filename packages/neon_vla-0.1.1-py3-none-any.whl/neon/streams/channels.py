"""
Stream Channels — Typed data channels for omni-modal streaming.

Each channel:
- Has a fixed schema (dtype, shape, sample_rate)
- Buffers data in a ring buffer
- Timestamps every sample
- Serializes to LeRobot-compatible format for training
- Publishes to Zenoh for P2P streaming

The G1 running on gantry streams ALL channels simultaneously:
- Joints @ 500Hz (29-DOF position + velocity + torque = 87 floats)
- LiDAR @ 10Hz (21,600 points × 3 = 64,800 floats)
- Cameras @ 30Hz (stereo 640×480 RGB = 2 × 921,600 bytes)
- Audio @ 16kHz (mono PCM-16)
- Text (agent output, tool calls, instructions)
- Tool calls (strands agent actions — what the agent decided to do)

All channels feed into:
1. StreamRecorder → LeRobot dataset on HuggingFace (training data)
2. NeonVLA model → action predictions (inference)
3. Zenoh mesh → any connected device (telemetry/teleop)
"""

from __future__ import annotations

import logging
import struct
import time
from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass
from enum import Enum
from typing import Any, Deque, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


class ChannelType(Enum):
    """Types of data channels."""

    JOINTS = "joints"
    LIDAR = "lidar"
    CAMERA = "camera"
    AUDIO = "audio"
    TEXT = "text"
    TOOL_CALL = "tool_call"
    IMU = "imu"
    FORCE = "force"
    GPS = "gps"
    DEPTH = "depth"
    SEGMENTATION = "segmentation"
    TACTILE = "tactile"


@dataclass
class Sample:
    """A single timestamped sample from any channel."""

    timestamp: float  # Unix time in seconds (monotonic)
    channel: str  # Channel name
    data: Any  # Channel-specific payload
    seq: int = 0  # Sequence number

    @property
    def age(self) -> float:
        """Seconds since this sample was captured."""
        return time.monotonic() - self.timestamp


@dataclass
class ChannelConfig:
    """Base configuration for a data channel."""

    name: str
    channel_type: ChannelType
    sample_rate: float  # Hz (0 = event-driven, no fixed rate)
    buffer_seconds: float = 30.0  # Ring buffer duration
    enabled: bool = True
    # Zenoh publishing
    zenoh_topic: str = ""  # Empty = auto from name
    publish_to_zenoh: bool = True
    # Recording
    record: bool = True
    # Compression
    compress: bool = False  # LZ4 compress before Zenoh publish


class Channel(ABC):
    """Base class for all data channels.

    A channel is a typed stream of timestamped samples.
    Channels buffer data in a ring buffer and can publish to Zenoh.
    """

    def __init__(self, config: ChannelConfig):
        self.config = config
        self._buffer: Deque[Sample] = deque()
        self._max_samples = int(config.sample_rate * config.buffer_seconds) if config.sample_rate > 0 else 10000
        self._seq = 0
        self._callbacks: List = []
        self._zenoh_pub = None

    @property
    def name(self) -> str:
        return self.config.name

    @property
    def channel_type(self) -> ChannelType:
        return self.config.channel_type

    def push(self, data: Any, timestamp: float = None) -> Sample:
        """Push a new sample into the channel.

        Args:
            data: Channel-specific payload
            timestamp: Unix timestamp (default: now)

        Returns:
            The created Sample
        """
        if timestamp is None:
            timestamp = time.monotonic()

        sample = Sample(
            timestamp=timestamp,
            channel=self.name,
            data=data,
            seq=self._seq,
        )
        self._seq += 1

        # Ring buffer
        self._buffer.append(sample)
        while len(self._buffer) > self._max_samples:
            self._buffer.popleft()

        # Notify callbacks
        for cb in self._callbacks:
            try:
                cb(sample)
            except Exception as e:
                logger.debug(f"Channel {self.name} callback error: {e}")

        # Publish to Zenoh
        if self.config.publish_to_zenoh and self._zenoh_pub is not None:
            self._publish_zenoh(sample)

        return sample

    def latest(self) -> Optional[Sample]:
        """Get the most recent sample."""
        return self._buffer[-1] if self._buffer else None

    def latest_n(self, n: int) -> List[Sample]:
        """Get the N most recent samples."""
        return list(self._buffer)[-n:]

    def window(self, seconds: float) -> List[Sample]:
        """Get all samples from the last N seconds."""
        cutoff = time.monotonic() - seconds
        return [s for s in self._buffer if s.timestamp >= cutoff]

    def on_sample(self, callback):
        """Register a callback for new samples."""
        self._callbacks.append(callback)

    def attach_zenoh(self, session, topic: str = None):
        """Attach a Zenoh publisher for this channel."""
        t = topic or self.config.zenoh_topic or f"neon/{self.name}"
        self._zenoh_pub = session.declare_publisher(t)
        logger.info(f"Channel {self.name} → Zenoh topic: {t}")

    def _publish_zenoh(self, sample: Sample):
        """Publish sample to Zenoh."""
        try:
            payload = self.serialize(sample)
            if self.config.compress:
                import lz4.frame
                payload = lz4.frame.compress(payload)
            self._zenoh_pub.put(payload)
        except Exception as e:
            logger.debug(f"Zenoh publish failed for {self.name}: {e}")

    @abstractmethod
    def serialize(self, sample: Sample) -> bytes:
        """Serialize a sample for network transmission."""
        ...

    @abstractmethod
    def deserialize(self, data: bytes) -> Sample:
        """Deserialize a sample from network data."""
        ...

    @abstractmethod
    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        """Convert samples to LeRobot-compatible training format."""
        ...

    def __len__(self) -> int:
        return len(self._buffer)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.name}, rate={self.config.sample_rate}Hz, buf={len(self._buffer)})"


# =============================================================================
# Concrete Channel Implementations
# =============================================================================


class JointChannel(Channel):
    """29-DOF joint state stream from the G1.

    Each sample: position(29) + velocity(29) + torque(29) = 87 floats.
    @ 500Hz from unitree_sdk2.
    """

    DTYPE = np.float32
    N_JOINTS = 29
    SAMPLE_SIZE = N_JOINTS * 3  # pos + vel + torque

    def __init__(self, name: str = "joints", sample_rate: float = 500.0, **kwargs):
        super().__init__(ChannelConfig(name=name, channel_type=ChannelType.JOINTS, sample_rate=sample_rate, **kwargs))

    def push_joint_state(
        self,
        positions: np.ndarray,
        velocities: np.ndarray = None,
        torques: np.ndarray = None,
        timestamp: float = None,
    ) -> Sample:
        """Push a joint state sample."""
        if velocities is None:
            velocities = np.zeros(self.N_JOINTS, dtype=self.DTYPE)
        if torques is None:
            torques = np.zeros(self.N_JOINTS, dtype=self.DTYPE)

        data = np.concatenate([
            positions.astype(self.DTYPE),
            velocities.astype(self.DTYPE),
            torques.astype(self.DTYPE),
        ])
        return self.push(data, timestamp)

    def serialize(self, sample: Sample) -> bytes:
        header = struct.pack("!dI", sample.timestamp, sample.seq)
        return header + sample.data.tobytes()

    def deserialize(self, data: bytes) -> Sample:
        ts, seq = struct.unpack("!dI", data[:12])
        arr = np.frombuffer(data[12:], dtype=self.DTYPE)
        return Sample(timestamp=ts, channel=self.name, data=arr, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        """Convert to LeRobot joint state format."""
        if not samples:
            return {}
        states = np.stack([s.data[:self.N_JOINTS] for s in samples])  # positions only
        timestamps = np.array([s.timestamp for s in samples])
        return {
            "observation.state": states,  # (T, 29)
            "timestamps.state": timestamps,
        }


class LidarChannel(Channel):
    """Unitree L1 LiDAR point cloud stream.

    L1 specs: 360° × ~70° FOV, 21,600 pts/revolution @ 10Hz.
    Each point: (x, y, z, intensity) = 4 floats.
    Raw data arrives via UDP port 6100 as custom Unitree protocol.
    """

    DTYPE = np.float32
    POINTS_PER_SCAN = 21600
    POINT_DIM = 4  # x, y, z, intensity

    def __init__(self, name: str = "lidar", sample_rate: float = 10.0, **kwargs):
        super().__init__(ChannelConfig(name=name, channel_type=ChannelType.LIDAR, sample_rate=sample_rate, compress=True, **kwargs))

    def push_scan(self, points: np.ndarray, timestamp: float = None) -> Sample:
        """Push a LiDAR scan.

        Args:
            points: (N, 4) array of (x, y, z, intensity)
        """
        return self.push(points.astype(self.DTYPE), timestamp)

    def serialize(self, sample: Sample) -> bytes:
        header = struct.pack("!dII", sample.timestamp, sample.seq, sample.data.shape[0])
        return header + sample.data.tobytes()

    def deserialize(self, data: bytes) -> Sample:
        ts, seq, n_points = struct.unpack("!dII", data[:16])
        arr = np.frombuffer(data[16:], dtype=self.DTYPE).reshape(n_points, self.POINT_DIM)
        return Sample(timestamp=ts, channel=self.name, data=arr, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        """Convert to point cloud training format.

        For VLA training, we downsample the point cloud to a fixed size
        and encode as a depth-like feature map for the backbone.
        """
        if not samples:
            return {}
        # Downsample to 4096 points per scan for training
        target_n = 4096
        clouds = []
        for s in samples:
            pts = s.data
            if len(pts) > target_n:
                idx = np.random.choice(len(pts), target_n, replace=False)
                pts = pts[idx]
            elif len(pts) < target_n:
                pad = np.zeros((target_n - len(pts), self.POINT_DIM), dtype=self.DTYPE)
                pts = np.concatenate([pts, pad])
            clouds.append(pts)

        return {
            "observation.lidar": np.stack(clouds),  # (T, 4096, 4)
            "timestamps.lidar": np.array([s.timestamp for s in samples]),
        }


class CameraChannel(Channel):
    """Camera frame stream (stereo head cameras, or single camera).

    Supports: RGB (H,W,3), Depth (H,W), Stereo pairs.
    @ 30Hz from V4L2 or ROS2 topic.
    """

    def __init__(
        self,
        name: str = "camera_head",
        sample_rate: float = 30.0,
        image_size: Tuple[int, int] = (640, 480),
        is_stereo: bool = False,
        **kwargs,
    ):
        super().__init__(ChannelConfig(name=name, channel_type=ChannelType.CAMERA, sample_rate=sample_rate, compress=True, **kwargs))
        self.image_size = image_size
        self.is_stereo = is_stereo

    def push_frame(self, frame: np.ndarray, right_frame: np.ndarray = None, timestamp: float = None) -> Sample:
        """Push a camera frame.

        Args:
            frame: (H, W, 3) uint8 RGB image (numpy or PIL)
            right_frame: Optional right camera for stereo
        """
        # Ensure numpy — sim renderers may return PIL.Image
        if not isinstance(frame, np.ndarray):
            frame = np.asarray(frame, dtype=np.uint8)
        if right_frame is not None and not isinstance(right_frame, np.ndarray):
            right_frame = np.asarray(right_frame, dtype=np.uint8)
        data = {"left": frame}
        if right_frame is not None:
            data["right"] = right_frame
        return self.push(data, timestamp)

    def serialize(self, sample: Sample) -> bytes:
        import cv2
        header = struct.pack("!dI", sample.timestamp, sample.seq)
        # JPEG compress for network
        _, left_jpg = cv2.imencode(".jpg", sample.data["left"], [cv2.IMWRITE_JPEG_QUALITY, 85])
        left_bytes = left_jpg.tobytes()
        parts = struct.pack("!I", len(left_bytes)) + left_bytes
        if "right" in sample.data and sample.data["right"] is not None:
            _, right_jpg = cv2.imencode(".jpg", sample.data["right"], [cv2.IMWRITE_JPEG_QUALITY, 85])
            right_bytes = right_jpg.tobytes()
            parts += struct.pack("!I", len(right_bytes)) + right_bytes
        return header + parts

    def deserialize(self, data: bytes) -> Sample:
        import cv2
        ts, seq = struct.unpack("!dI", data[:12])
        offset = 12
        left_len = struct.unpack("!I", data[offset:offset+4])[0]
        offset += 4
        left = cv2.imdecode(np.frombuffer(data[offset:offset+left_len], dtype=np.uint8), cv2.IMREAD_COLOR)
        offset += left_len
        right = None
        if offset < len(data):
            right_len = struct.unpack("!I", data[offset:offset+4])[0]
            offset += 4
            right = cv2.imdecode(np.frombuffer(data[offset:offset+right_len], dtype=np.uint8), cv2.IMREAD_COLOR)
        result = {"left": left}
        if right is not None:
            result["right"] = right
        return Sample(timestamp=ts, channel=self.name, data=result, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        from PIL import Image
        frames = [Image.fromarray(s.data["left"]) for s in samples if s.data.get("left") is not None]
        result = {f"observation.image.{self.name}": frames}
        # Add stereo right if available
        right_frames = [Image.fromarray(s.data["right"]) for s in samples if s.data.get("right") is not None]
        if right_frames:
            result[f"observation.image.{self.name}_right"] = right_frames
        return result


class AudioChannel(Channel):
    """Audio stream — microphone input + speaker output.

    Input: 16kHz mono PCM-16 from G1 microphone
    Output: PersonaPlex TTS responses via speaker

    Both directions are recorded for training the audio encoder
    and the speech response head.
    """

    SAMPLE_RATE_HZ = 16000
    DTYPE = np.float32

    def __init__(self, name: str = "audio", **kwargs):
        super().__init__(ChannelConfig(
            name=name,
            channel_type=ChannelType.AUDIO,
            sample_rate=0,  # Event-driven (chunks, not individual samples)
            **kwargs,
        ))

    def push_audio_chunk(
        self,
        samples: np.ndarray,
        direction: str = "input",
        timestamp: float = None,
    ) -> Sample:
        """Push an audio chunk.

        Args:
            samples: (N,) float32 audio samples
            direction: "input" (microphone) or "output" (speaker)
        """
        data = {"samples": samples.astype(self.DTYPE), "direction": direction}
        return self.push(data, timestamp)

    def serialize(self, sample: Sample) -> bytes:
        direction_byte = b"\x00" if sample.data["direction"] == "input" else b"\x01"
        header = struct.pack("!dI", sample.timestamp, sample.seq) + direction_byte
        return header + sample.data["samples"].tobytes()

    def deserialize(self, data: bytes) -> Sample:
        ts, seq = struct.unpack("!dI", data[:12])
        direction = "input" if data[12:13] == b"\x00" else "output"
        arr = np.frombuffer(data[13:], dtype=self.DTYPE)
        return Sample(timestamp=ts, channel=self.name, data={"samples": arr, "direction": direction}, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        """Concatenate audio chunks into a continuous waveform."""
        input_chunks = [s.data["samples"] for s in samples if s.data["direction"] == "input"]
        output_chunks = [s.data["samples"] for s in samples if s.data["direction"] == "output"]

        result = {}
        if input_chunks:
            result["observation.audio"] = np.concatenate(input_chunks)
        if output_chunks:
            result["action.audio_response"] = np.concatenate(output_chunks)
        return result


class TextChannel(Channel):
    """Text stream — instructions, agent thoughts, transcriptions.

    Captures:
    - User instructions (natural language commands)
    - Agent reasoning (chain-of-thought from strands agent)
    - ASR transcriptions (from AudioChannel via Whisper)
    - Scene descriptions (from vision model)
    """

    def __init__(self, name: str = "text", **kwargs):
        super().__init__(ChannelConfig(name=name, channel_type=ChannelType.TEXT, sample_rate=0, **kwargs))

    def push_text(self, text: str, role: str = "user", timestamp: float = None) -> Sample:
        """Push a text message.

        Args:
            text: The text content
            role: "user", "agent", "asr", "scene"
        """
        return self.push({"text": text, "role": role}, timestamp)

    def serialize(self, sample: Sample) -> bytes:
        import json
        header = struct.pack("!dI", sample.timestamp, sample.seq)
        payload = json.dumps(sample.data).encode("utf-8")
        return header + struct.pack("!I", len(payload)) + payload

    def deserialize(self, data: bytes) -> Sample:
        import json
        ts, seq = struct.unpack("!dI", data[:12])
        payload_len = struct.unpack("!I", data[12:16])[0]
        payload = json.loads(data[16:16+payload_len].decode("utf-8"))
        return Sample(timestamp=ts, channel=self.name, data=payload, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        # Concatenate user instructions as language conditioning
        instructions = [s.data["text"] for s in samples if s.data["role"] == "user"]
        return {
            "language_instruction": " ".join(instructions) if instructions else "",
        }


class ToolCallChannel(Channel):
    """Tool call stream — records what the strands agent decided to do.

    Every tool call the agent makes becomes training data:
    - tool_name, arguments, result, duration
    - This teaches the model WHEN to use tools and WHAT to do

    Combined with audio/vision, this creates:
    "I heard 'pick up the cup' → I saw the cup at (x,y,z) → I called robot.move_to()"
    """

    def __init__(self, name: str = "tool_calls", **kwargs):
        super().__init__(ChannelConfig(name=name, channel_type=ChannelType.TOOL_CALL, sample_rate=0, **kwargs))

    def push_tool_call(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        result: Any = None,
        duration_ms: float = 0,
        timestamp: float = None,
    ) -> Sample:
        """Record a tool call."""
        data = {
            "tool": tool_name,
            "args": arguments,
            "result": str(result)[:500] if result else None,
            "duration_ms": duration_ms,
        }
        return self.push(data, timestamp)

    def serialize(self, sample: Sample) -> bytes:
        import json
        header = struct.pack("!dI", sample.timestamp, sample.seq)
        payload = json.dumps(sample.data, default=str).encode("utf-8")
        return header + struct.pack("!I", len(payload)) + payload

    def deserialize(self, data: bytes) -> Sample:
        import json
        ts, seq = struct.unpack("!dI", data[:12])
        payload_len = struct.unpack("!I", data[12:16])[0]
        payload = json.loads(data[16:16+payload_len].decode("utf-8"))
        return Sample(timestamp=ts, channel=self.name, data=payload, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        """Convert tool calls to training-friendly format.

        Each tool call becomes a structured text entry that teaches the model:
        1. Tool selection (which tool to call)
        2. Argument generation (what parameters to use)
        3. Result interpretation (what happened)
        """
        tool_texts = []
        for s in samples:
            d = s.data
            tool_texts.append(f"<tool>{d['tool']}</tool><args>{d['args']}</args>")

        return {
            "tool_calls": tool_texts,
            "tool_call_count": len(samples),
        }


class GPSChannel(Channel):
    """GPS/IMU state stream for outdoor navigation and warehouse tasks.

    Input: 6-DOF state [latitude, longitude, altitude, heading, pitch, roll]
    @ 10Hz from GPS module + IMU fusion.

    Inspired by OmniVLA — adds global position awareness for navigation-heavy
    tasks. The G1 can use this for warehouse traversal, outdoor locomotion,
    or any task where absolute position matters.
    """

    DTYPE = np.float32
    GPS_DIM = 6  # lat, lon, alt, heading, pitch, roll

    def __init__(self, name: str = "gps", sample_rate: float = 10.0, **kwargs):
        super().__init__(ChannelConfig(
            name=name, channel_type=ChannelType.GPS, sample_rate=sample_rate, **kwargs,
        ))

    def push_gps(
        self,
        latitude: float,
        longitude: float,
        altitude: float = 0.0,
        heading: float = 0.0,
        pitch: float = 0.0,
        roll: float = 0.0,
        timestamp: float = None,
    ) -> Sample:
        """Push a GPS/IMU state sample.

        Args:
            latitude: Decimal degrees (e.g. 37.7749)
            longitude: Decimal degrees (e.g. -122.4194)
            altitude: Meters above sea level
            heading: Degrees from north (0-360)
            pitch: Degrees (-90 to 90)
            roll: Degrees (-180 to 180)
        """
        data = np.array(
            [latitude, longitude, altitude, heading, pitch, roll],
            dtype=self.DTYPE,
        )
        return self.push(data, timestamp)

    def serialize(self, sample: Sample) -> bytes:
        header = struct.pack("!dI", sample.timestamp, sample.seq)
        return header + sample.data.tobytes()

    def deserialize(self, data: bytes) -> Sample:
        ts, seq = struct.unpack("!dI", data[:12])
        arr = np.frombuffer(data[12:], dtype=self.DTYPE)
        return Sample(timestamp=ts, channel=self.name, data=arr, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        """Convert to LeRobot GPS training format."""
        if not samples:
            return {}
        states = np.stack([s.data for s in samples])  # (T, 6)
        return {
            "observation.gps": states,
            "timestamps.gps": np.array([s.timestamp for s in samples]),
        }


class DepthChannel(Channel):
    """Monocular depth map stream, synced with CameraChannel.

    Input: Single-channel depth map (H, W) float32, values in meters.
    @ 30Hz from stereo disparity, structured light, or monocular estimation
    (e.g., Depth Anything V2).

    Inspired by Cosmos-Transfer2.5 depth conditioning — the depth map
    provides explicit spatial structure that the RGB camera cannot.
    Critical for grasping (z-axis precision) and obstacle avoidance.
    """

    DTYPE = np.float32

    def __init__(
        self,
        name: str = "depth_head",
        sample_rate: float = 30.0,
        image_size: Tuple[int, int] = (640, 480),
        **kwargs,
    ):
        super().__init__(ChannelConfig(
            name=name, channel_type=ChannelType.DEPTH, sample_rate=sample_rate,
            compress=True, **kwargs,
        ))
        self.image_size = image_size  # (width, height)

    def push_depth(self, depth_map: np.ndarray, timestamp: float = None) -> Sample:
        """Push a depth map.

        Args:
            depth_map: (H, W) float32 depth in meters
        """
        return self.push(depth_map.astype(self.DTYPE), timestamp)

    def serialize(self, sample: Sample) -> bytes:
        h, w = sample.data.shape
        header = struct.pack("!dIII", sample.timestamp, sample.seq, h, w)
        return header + sample.data.tobytes()

    def deserialize(self, data: bytes) -> Sample:
        ts, seq, h, w = struct.unpack("!dIII", data[:20])
        arr = np.frombuffer(data[20:], dtype=self.DTYPE).reshape(h, w)
        return Sample(timestamp=ts, channel=self.name, data=arr, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        """Convert to LeRobot depth training format."""
        if not samples:
            return {}
        depths = np.stack([s.data for s in samples])  # (T, H, W)
        return {
            f"observation.depth.{self.name}": depths,
            f"timestamps.depth.{self.name}": np.array([s.timestamp for s in samples]),
        }


class SegmentationChannel(Channel):
    """Semantic segmentation mask stream, synced with CameraChannel.

    Input: Per-pixel class index (H, W) uint8, values in [0, num_classes).
    @ 30Hz from real-time segmentation model (e.g., SAM 2, OneFormer).

    Inspired by Cosmos-Transfer2.5 segmentation conditioning — gives the
    model explicit object-level scene understanding without having to learn
    it from raw pixels. Tells the model where the cup, table, hand, etc. are.
    """

    DTYPE = np.uint8

    def __init__(
        self,
        name: str = "seg_head",
        sample_rate: float = 30.0,
        image_size: Tuple[int, int] = (640, 480),
        num_classes: int = 20,
        **kwargs,
    ):
        super().__init__(ChannelConfig(
            name=name, channel_type=ChannelType.SEGMENTATION, sample_rate=sample_rate,
            compress=True, **kwargs,
        ))
        self.image_size = image_size
        self.num_classes = num_classes

    def push_segmentation(self, seg_mask: np.ndarray, timestamp: float = None) -> Sample:
        """Push a segmentation mask.

        Args:
            seg_mask: (H, W) uint8 per-pixel class indices
        """
        return self.push(seg_mask.astype(self.DTYPE), timestamp)

    def serialize(self, sample: Sample) -> bytes:
        h, w = sample.data.shape
        header = struct.pack("!dIII", sample.timestamp, sample.seq, h, w)
        return header + sample.data.tobytes()

    def deserialize(self, data: bytes) -> Sample:
        ts, seq, h, w = struct.unpack("!dIII", data[:20])
        arr = np.frombuffer(data[20:], dtype=self.DTYPE).reshape(h, w)
        return Sample(timestamp=ts, channel=self.name, data=arr, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        """Convert to LeRobot segmentation training format."""
        if not samples:
            return {}
        masks = np.stack([s.data for s in samples])  # (T, H, W)
        return {
            f"observation.segmentation.{self.name}": masks,
            f"timestamps.segmentation.{self.name}": np.array([s.timestamp for s in samples]),
        }


# =============================================================================
# NEW Channels — Tactile, IMU, Force (NEXT.md Week 1)
# =============================================================================


class TactileChannel(Channel):
    """Tactile finger force/torque sensor stream.

    G1 hands: 14 finger links × 6-axis force/torque = 84 floats per sample.
    @ 100Hz from MuJoCo touch sensors or real G1 force sensors.

    Unique to Neon — no other VLA has tactile. Enables:
    - Grasp force regulation (don't crush the egg)
    - Slip detection (object moving in hand)
    - Contact-rich manipulation (insertion, lever)
    """

    DTYPE = np.float32
    NUM_LINKS = 14
    FT_DIM = 6  # fx, fy, fz, tx, ty, tz per link

    def __init__(self, name: str = "tactile", sample_rate: float = 100.0, **kwargs):
        super().__init__(ChannelConfig(
            name=name, channel_type=ChannelType.TACTILE, sample_rate=sample_rate, **kwargs,
        ))

    def push_tactile(self, forces: np.ndarray, timestamp: float = None) -> Sample:
        """Push a tactile sensor reading.

        Args:
            forces: (14, 6) per-link force/torque values
        """
        return self.push(forces.astype(self.DTYPE), timestamp)

    def serialize(self, sample: Sample) -> bytes:
        header = struct.pack("!dI", sample.timestamp, sample.seq)
        return header + sample.data.tobytes()

    def deserialize(self, data: bytes) -> Sample:
        ts, seq = struct.unpack("!dI", data[:12])
        arr = np.frombuffer(data[12:], dtype=self.DTYPE).reshape(self.NUM_LINKS, self.FT_DIM)
        return Sample(timestamp=ts, channel=self.name, data=arr, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        """Convert to LeRobot tactile training format."""
        if not samples:
            return {}
        forces = np.stack([s.data for s in samples])  # (T, 14, 6)
        return {
            "observation.tactile": forces,
            "timestamps.tactile": np.array([s.timestamp for s in samples]),
        }


class IMUChannel(Channel):
    """IMU (Inertial Measurement Unit) stream from G1 trunk.

    Input: 9-DOF — 3 accelerometer + 3 gyroscope + 3 magnetometer.
    @ 200Hz from G1 trunk IMU or sim state derivatives.

    Critical for locomotion: provides orientation and angular velocity
    that proprioception alone cannot capture (it tells you WHERE joints
    are, not HOW FAST the body is rotating in world frame).
    """

    DTYPE = np.float32
    IMU_DIM = 9  # accel(3) + gyro(3) + mag(3)

    def __init__(self, name: str = "imu", sample_rate: float = 200.0, **kwargs):
        super().__init__(ChannelConfig(
            name=name, channel_type=ChannelType.IMU, sample_rate=sample_rate, **kwargs,
        ))

    def push_imu(
        self,
        accel: np.ndarray,
        gyro: np.ndarray,
        mag: np.ndarray = None,
        timestamp: float = None,
    ) -> Sample:
        """Push an IMU sample.

        Args:
            accel: (3,) linear acceleration [ax, ay, az] m/s²
            gyro: (3,) angular velocity [gx, gy, gz] rad/s
            mag: (3,) magnetometer [mx, my, mz] μT (optional, zeros if None)
        """
        if mag is None:
            mag = np.zeros(3, dtype=self.DTYPE)
        data = np.concatenate([
            accel.astype(self.DTYPE),
            gyro.astype(self.DTYPE),
            mag.astype(self.DTYPE),
        ])
        return self.push(data, timestamp)

    def serialize(self, sample: Sample) -> bytes:
        header = struct.pack("!dI", sample.timestamp, sample.seq)
        return header + sample.data.tobytes()

    def deserialize(self, data: bytes) -> Sample:
        ts, seq = struct.unpack("!dI", data[:12])
        arr = np.frombuffer(data[12:], dtype=self.DTYPE)
        return Sample(timestamp=ts, channel=self.name, data=arr, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        """Convert to LeRobot IMU training format."""
        if not samples:
            return {}
        states = np.stack([s.data for s in samples])  # (T, 9)
        return {
            "observation.imu": states,
            "timestamps.imu": np.array([s.timestamp for s in samples]),
        }


class ForceChannel(Channel):
    """Wrist force/torque sensor stream.

    Input: 6-DOF — [fx, fy, fz, tx, ty, tz] from wrist F/T sensor.
    @ 100Hz from real sensor or MuJoCo contact force computation.

    Essential for contact-rich tasks: the model needs to know HOW HARD
    it's pushing/pulling. Vision can't measure force — only F/T sensors can.
    """

    DTYPE = np.float32
    FORCE_DIM = 6  # fx, fy, fz, tx, ty, tz

    def __init__(self, name: str = "force", sample_rate: float = 100.0, **kwargs):
        super().__init__(ChannelConfig(
            name=name, channel_type=ChannelType.FORCE, sample_rate=sample_rate, **kwargs,
        ))

    def push_force(self, force_torque: np.ndarray, timestamp: float = None) -> Sample:
        """Push a wrist F/T reading.

        Args:
            force_torque: (6,) [fx, fy, fz, tx, ty, tz]
        """
        return self.push(force_torque.astype(self.DTYPE), timestamp)

    def serialize(self, sample: Sample) -> bytes:
        header = struct.pack("!dI", sample.timestamp, sample.seq)
        return header + sample.data.tobytes()

    def deserialize(self, data: bytes) -> Sample:
        ts, seq = struct.unpack("!dI", data[:12])
        arr = np.frombuffer(data[12:], dtype=self.DTYPE)
        return Sample(timestamp=ts, channel=self.name, data=arr, seq=seq)

    def to_training_format(self, samples: List[Sample]) -> Dict[str, Any]:
        """Convert to LeRobot force training format."""
        if not samples:
            return {}
        forces = np.stack([s.data for s in samples])  # (T, 6)
        return {
            "observation.force": forces,
            "timestamps.force": np.array([s.timestamp for s in samples]),
        }

