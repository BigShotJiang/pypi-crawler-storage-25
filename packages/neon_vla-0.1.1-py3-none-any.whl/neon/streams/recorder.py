"""
StreamRecorder — Records all channels to a LeRobot-compatible dataset.

Continuously captures data from all channels and writes episodes
to HuggingFace Hub in LeRobot format for training.

The recorder is always on when the G1 is on the gantry. Every second
of sensor data becomes potential training data for the next Neon model.

Episode segmentation:
- Auto-segment by time (e.g., 60s episodes)
- Manual segment via text command ("new episode")
- Task-boundary detection (locomotion → manipulation transition)

Output format:
    dataset/
    ├── data/
    │   ├── chunk-000/
    │   │   ├── episode_000000.parquet
    │   │   ├── episode_000001.parquet
    │   │   └── ...
    │   └── ...
    ├── meta/
    │   ├── info.json
    │   ├── episodes.jsonl
    │   └── tasks.jsonl
    └── videos/
        ├── observation.image.camera_head/
        │   ├── episode_000000.mp4
        │   └── ...
        └── observation.image.camera_hand/
            └── ...
"""

from __future__ import annotations

import json
import logging
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from neon.streams.channels import (
    Channel,
    ChannelType,
    Sample,
)

logger = logging.getLogger(__name__)


@dataclass
class RecorderConfig:
    """Configuration for the stream recorder."""

    # Output
    output_dir: str = "./neon_recordings"
    dataset_name: str = "neon-g1-episodes"
    push_to_hub: bool = True
    hub_id: str = ""  # e.g., "cagataydev/neon-g1-data"
    private: bool = True

    # Episode segmentation
    episode_duration: float = 60.0  # Seconds per episode (0 = manual only)
    min_episode_length: float = 5.0  # Discard episodes shorter than this

    # Sampling (downsample high-rate channels for training)
    target_fps: int = 4  # Training frame rate
    joint_downsample_ratio: int = 125  # 500Hz → 4Hz
    lidar_downsample_ratio: int = 2  # 10Hz → 5Hz

    # Storage
    max_local_episodes: int = 1000  # Rotate after this many
    video_codec: str = "mp4v"
    video_quality: int = 23  # CRF for H.264 (lower = better)

    # LeRobot v3 mode (recommended)
    use_lerobot_v3: bool = True  # Use NeonLeRobotWriter for output


class EpisodeBuffer:
    """Buffers samples for a single episode across all channels."""

    def __init__(self, episode_id: int, start_time: float):
        self.episode_id = episode_id
        self.start_time = start_time
        self.end_time: Optional[float] = None
        self.samples: Dict[str, List[Sample]] = {}
        self.task: str = ""
        self.language_instruction: str = ""

    def add(self, sample: Sample):
        """Add a sample to this episode."""
        self.samples.setdefault(sample.channel, []).append(sample)

    @property
    def duration(self) -> float:
        end = self.end_time or time.monotonic()
        return end - self.start_time

    @property
    def total_samples(self) -> int:
        return sum(len(v) for v in self.samples.values())

    def finalize(self):
        """Mark this episode as complete."""
        self.end_time = time.monotonic()


class StreamRecorder:
    """Records all channel data to LeRobot-format datasets.

    Usage:
        recorder = StreamRecorder(RecorderConfig(hub_id="cagataydev/neon-g1-data"))
        recorder.attach(joints_channel)
        recorder.attach(camera_channel)
        recorder.attach(audio_channel)
        recorder.attach(lidar_channel)
        recorder.attach(text_channel)
        recorder.attach(tool_call_channel)

        recorder.start()  # Begins recording

        # ... robot operates, all channels push data ...

        recorder.new_episode("pick up the red cup")  # Manual segment
        recorder.stop()  # Finalizes + pushes to HuggingFace
    """

    def __init__(self, config: RecorderConfig):
        self.config = config
        self.channels: Dict[str, Channel] = {}
        self._recording = False
        self._episode_count = 0
        self._current_episode: Optional[EpisodeBuffer] = None
        self._completed_episodes: List[EpisodeBuffer] = []
        self._lock = threading.Lock()
        self._auto_segment_thread: Optional[threading.Thread] = None

        # LeRobot v3 writer (optional, preferred)
        self._v3_writer = None
        if config.use_lerobot_v3 and config.hub_id:
            try:
                from neon.data.lerobot_v3 import NeonLeRobotWriter, NeonWriterConfig
                self._v3_writer = NeonLeRobotWriter(NeonWriterConfig(
                    repo_id=config.hub_id,
                    root=config.output_dir,
                    fps=config.target_fps,
                    push_to_hub=config.push_to_hub,
                    private=config.private,
                    source="real",
                ))
                self._v3_writer.open()
                logger.info(f"LeRobot v3 writer initialized: {config.hub_id}")
            except Exception as e:
                logger.warning(f"Failed to init v3 writer, using legacy: {e}")
                self._v3_writer = None

        # Ensure output directory
        Path(config.output_dir).mkdir(parents=True, exist_ok=True)

    def attach(self, channel: Channel):
        """Attach a channel to record from."""
        self.channels[channel.name] = channel
        channel.on_sample(self._on_sample)
        logger.info(f"Recorder attached to channel: {channel.name}")

    def start(self, initial_task: str = ""):
        """Start recording."""
        if self._recording:
            logger.warning("Already recording")
            return

        self._recording = True
        self._start_new_episode(initial_task)

        # Auto-segmentation thread
        if self.config.episode_duration > 0:
            self._auto_segment_thread = threading.Thread(target=self._auto_segment_loop, daemon=True)
            self._auto_segment_thread.start()

        logger.info(f"Recording started → {self.config.output_dir}")

    def stop(self):
        """Stop recording, finalize current episode, push to hub."""
        if not self._recording:
            return

        self._recording = False

        # Finalize current episode
        if self._current_episode:
            self._finalize_current_episode()

        # Export: prefer v3 writer, fall back to legacy
        if self._v3_writer is not None:
            self._export_v3()
        else:
            self._export_dataset()

        # Push to HuggingFace (legacy path only — v3 writer handles its own push)
        if self._v3_writer is None and self.config.push_to_hub and self.config.hub_id:
            self._push_to_hub()

        logger.info(f"Recording stopped. {len(self._completed_episodes)} episodes saved.")

    def new_episode(self, task: str = ""):
        """Manually start a new episode."""
        with self._lock:
            if self._current_episode:
                self._finalize_current_episode()
            self._start_new_episode(task)

    def _on_sample(self, sample: Sample):
        """Callback when any channel produces a sample."""
        if not self._recording or self._current_episode is None:
            return
        with self._lock:
            self._current_episode.add(sample)

    def _start_new_episode(self, task: str = ""):
        """Start a new episode buffer."""
        self._current_episode = EpisodeBuffer(
            episode_id=self._episode_count,
            start_time=time.monotonic(),
        )
        self._current_episode.task = task
        self._episode_count += 1
        logger.info(f"Episode {self._current_episode.episode_id} started (task: '{task}')")

    def _finalize_current_episode(self):
        """Finalize the current episode and move to completed list."""
        ep = self._current_episode
        if ep is None:
            return

        ep.finalize()

        # Discard too-short episodes
        if ep.duration < self.config.min_episode_length:
            logger.info(f"Episode {ep.episode_id} discarded (too short: {ep.duration:.1f}s)")
            return

        self._completed_episodes.append(ep)
        logger.info(
            f"Episode {ep.episode_id} finalized: "
            f"{ep.duration:.1f}s, {ep.total_samples} samples"
        )

    def _auto_segment_loop(self):
        """Background thread for automatic episode segmentation."""
        while self._recording:
            time.sleep(1.0)
            if self._current_episode and self._current_episode.duration >= self.config.episode_duration:
                task = self._current_episode.task  # Carry over task
                with self._lock:
                    self._finalize_current_episode()
                    self._start_new_episode(task)


    def _export_v3(self):
        """Export completed episodes using LeRobot v3 writer.

        Converts buffered channel samples into per-frame dicts and writes
        them through NeonLeRobotWriter. This produces the canonical Neon
        dataset format with all modalities.
        """
        from neon.data.lerobot_v3 import FULL_STATE_DIM, channels_to_frame

        writer = self._v3_writer

        for ep in self._completed_episodes:
            writer.start_episode(task=ep.task or ep.language_instruction)

            # Determine the frame timestamps from joint channel (highest rate)
            # After downsampling, we get one frame per training tick
            joint_samples = ep.samples.get("joints", [])
            camera_samples = ep.samples.get("camera_head", [])
            lidar_samples = ep.samples.get("lidar", [])
            audio_samples_all = ep.samples.get("audio", [])
            text_samples = ep.samples.get("text", [])

            # Downsample joints to target_fps
            joint_step = max(1, self.config.joint_downsample_ratio)
            ds_joints = joint_samples[::joint_step]

            # Downsample camera to target_fps
            cam_step = max(1, len(camera_samples) // max(1, len(ds_joints))) if camera_samples and ds_joints else 1
            ds_cameras = camera_samples[::cam_step] if camera_samples else []

            # Downsample lidar
            lidar_step = max(1, self.config.lidar_downsample_ratio)
            ds_lidar = lidar_samples[::lidar_step] if lidar_samples else []

            # Number of output frames
            n_frames = len(ds_joints) if ds_joints else len(ds_cameras)
            if n_frames == 0:
                logger.debug(f"Episode {ep.episode_id} has no frames, skipping")
                continue

            # Get language instruction
            language = ep.task or ""
            if not language and text_samples:
                user_texts = [s.data["text"] for s in text_samples if s.data.get("role") == "user"]
                if user_texts:
                    language = user_texts[-1]

            for i in range(n_frames):
                # Joint state → action (for now, state = action in teleop)
                joint_s = ds_joints[i] if i < len(ds_joints) else None
                camera_s = ds_cameras[i] if i < len(ds_cameras) else None
                lidar_s = ds_lidar[i] if i < len(ds_lidar) else None

                # Audio: 2-second window centered on this frame
                audio_window = []
                if audio_samples_all and joint_s:
                    frame_time = joint_s.timestamp
                    audio_window = [
                        s for s in audio_samples_all
                        if abs(s.timestamp - frame_time) < 1.0
                        and s.data.get("direction") == "input"
                    ]

                frame = channels_to_frame(
                    joint_sample=joint_s,
                    camera_sample=camera_s,
                    lidar_sample=lidar_s,
                    audio_samples=audio_window,
                    action=joint_s.data[:FULL_STATE_DIM] if joint_s is not None else None,
                )
                frame["language"] = language

                writer.add_frame(**frame)

            writer.end_episode()

        # Save and push
        writer.save_and_push()
        logger.info(f"Exported {len(self._completed_episodes)} episodes via LeRobot v3 writer")


    def _export_dataset(self):
        """Export completed episodes to LeRobot dataset format."""
        output_dir = Path(self.config.output_dir)
        data_dir = output_dir / "data" / "chunk-000"
        meta_dir = output_dir / "meta"
        video_dir = output_dir / "videos"

        data_dir.mkdir(parents=True, exist_ok=True)
        meta_dir.mkdir(parents=True, exist_ok=True)
        video_dir.mkdir(parents=True, exist_ok=True)

        episodes_meta = []

        for ep in self._completed_episodes:
            ep_id = ep.episode_id

            # Collect training data from all channels
            training_data = {}
            for ch_name, samples in ep.samples.items():
                channel = self.channels.get(ch_name)
                if channel and channel.config.record:
                    # Downsample if needed
                    downsampled = self._downsample(samples, channel)
                    fmt = channel.to_training_format(downsampled)
                    training_data.update(fmt)

            # Add language instruction
            if not training_data.get("language_instruction"):
                training_data["language_instruction"] = ep.task or ep.language_instruction or ""

            # Build frame-level records
            n_frames = self._count_frames(training_data)
            if n_frames == 0:
                continue

            # Add episode/frame indices
            training_data["episode_index"] = [ep_id] * n_frames
            training_data["frame_index"] = list(range(n_frames))

            # Save as parquet
            try:
                import pyarrow as pa
                import pyarrow.parquet as pq

                # Flatten to per-frame records
                records = []
                for i in range(n_frames):
                    record = {"episode_index": ep_id, "frame_index": i}
                    for key, val in training_data.items():
                        if isinstance(val, (list, np.ndarray)) and len(val) > i:
                            v = val[i]
                            if isinstance(v, np.ndarray):
                                record[key] = v.tolist()
                            else:
                                record[key] = v
                        elif isinstance(val, str):
                            record[key] = val
                    records.append(record)

                table = pa.Table.from_pylist(records)
                pq.write_table(table, data_dir / f"episode_{ep_id:06d}.parquet")
            except ImportError:
                # Fallback: save as JSON
                with open(data_dir / f"episode_{ep_id:06d}.json", "w") as f:
                    json.dump({"n_frames": n_frames, "task": ep.task}, f)

            # Save camera frames as video
            for ch_name in ep.samples:
                channel = self.channels.get(ch_name)
                if channel and channel.channel_type == ChannelType.CAMERA:
                    self._save_video(ep, ch_name, video_dir)

            episodes_meta.append({
                "episode_index": ep_id,
                "tasks": [ep.task] if ep.task else [],
                "length": n_frames,
                "duration_s": ep.duration,
                "channels": list(ep.samples.keys()),
                "total_samples": ep.total_samples,
            })

        # Write metadata
        info = {
            "fps": self.config.target_fps,
            "robot_type": "unitree_g1",
            "total_episodes": len(episodes_meta),
            "channels": list(self.channels.keys()),
            "recording_config": {
                "episode_duration": self.config.episode_duration,
                "target_fps": self.config.target_fps,
            },
        }
        with open(meta_dir / "info.json", "w") as f:
            json.dump(info, f, indent=2)

        with open(meta_dir / "episodes.jsonl", "w") as f:
            for ep_meta in episodes_meta:
                f.write(json.dumps(ep_meta) + "\n")

        logger.info(f"Exported {len(episodes_meta)} episodes to {output_dir}")

    def _downsample(self, samples: List[Sample], channel: Channel) -> List[Sample]:
        """Downsample high-rate channels for training."""
        if not samples:
            return samples

        if channel.channel_type == ChannelType.JOINTS:
            ratio = self.config.joint_downsample_ratio
            return samples[::ratio]
        elif channel.channel_type == ChannelType.LIDAR:
            ratio = self.config.lidar_downsample_ratio
            return samples[::ratio]
        elif channel.channel_type == ChannelType.CAMERA:
            # Downsample camera to target_fps
            if channel.config.sample_rate > 0:
                ratio = max(1, int(channel.config.sample_rate / self.config.target_fps))
                return samples[::ratio]
        # Text, audio, tool_calls: keep all
        return samples

    def _count_frames(self, training_data: Dict[str, Any]) -> int:
        """Count the number of frames in the training data."""
        for key, val in training_data.items():
            if isinstance(val, (list, np.ndarray)):
                return len(val)
        return 0

    def _save_video(self, episode: EpisodeBuffer, channel_name: str, video_dir: Path):
        """Save camera frames as MP4 video."""
        try:
            import cv2

            samples = episode.samples.get(channel_name, [])
            if not samples:
                return

            cam_dir = video_dir / f"observation.image.{channel_name}"
            cam_dir.mkdir(parents=True, exist_ok=True)

            # Get first frame to determine size
            first_frame = samples[0].data.get("left")
            if first_frame is None:
                return

            h, w = first_frame.shape[:2]
            out_path = cam_dir / f"episode_{episode.episode_id:06d}.mp4"

            fourcc = cv2.VideoWriter.fourcc(*self.config.video_codec)
            writer = cv2.VideoWriter(str(out_path), fourcc, self.config.target_fps, (w, h))

            # Downsample to target_fps
            ratio = max(1, int(30 / self.config.target_fps))
            for s in samples[::ratio]:
                frame = s.data.get("left")
                if frame is not None:
                    bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR) if frame.shape[-1] == 3 else frame
                    writer.write(bgr)

            writer.release()
            logger.debug(f"Saved video: {out_path}")

        except Exception as e:
            logger.warning(f"Failed to save video for {channel_name}: {e}")

    def _push_to_hub(self):
        """Push the dataset to HuggingFace Hub."""
        try:
            from huggingface_hub import HfApi

            api = HfApi()
            api.upload_folder(
                folder_path=self.config.output_dir,
                repo_id=self.config.hub_id,
                repo_type="dataset",
                private=self.config.private,
            )
            logger.info(f"Dataset pushed to HuggingFace: {self.config.hub_id}")
        except Exception as e:
            logger.error(f"Failed to push to HuggingFace: {e}")
