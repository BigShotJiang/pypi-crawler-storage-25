"""
StreamSession — Orchestrates all channels for a live G1 session.

This is the main entry point for running Neon on the real G1.
It wires up all channels, starts recording, runs inference, and
handles the full stream-in/stream-out loop.

Usage:
    from neon.streams import StreamSession

    session = StreamSession.from_robot(
        robot_ip="192.168.123.10",
        hub_id="cagataydev/neon-g1-data",
    )
    session.start()

    # Robot is now:
    # - Streaming all sensors to Zenoh
    # - Recording everything to HuggingFace
    # - Running VLA inference in real-time
    # - Accepting voice commands via microphone
    # - Responding via PersonaPlex TTS

    session.instruct("Pick up the red cup")  # Text command
    # or just speak — the microphone is always on

    session.stop()

Architecture:
    ┌─────────────────────────────────────────────────┐
    │              StreamSession                       │
    │                                                  │
    │  ┌──────────┐ ┌──────────┐ ┌──────────┐        │
    │  │ Joints   │ │ LiDAR    │ │ Camera   │        │
    │  │ @500Hz   │ │ @10Hz    │ │ @30Hz    │  ...   │
    │  └────┬─────┘ └────┬─────┘ └────┬─────┘        │
    │       │            │            │               │
    │       ▼            ▼            ▼               │
    │  ┌─────────────────────────────────────┐        │
    │  │         StreamRecorder              │        │
    │  │    → LeRobot format → HuggingFace   │        │
    │  └──────────────┬──────────────────────┘        │
    │                 │                                │
    │       ┌─────────▼──────────┐                    │
    │       │    NeonVLA Model   │                    │
    │       │  (omni-modal)      │                    │
    │       └─────────┬──────────┘                    │
    │                 │                                │
    │       ┌─────────▼──────────┐                    │
    │       │  G1Controller      │                    │
    │       │  → joint commands  │                    │
    │       │  → locomotion vel  │                    │
    │       └────────────────────┘                    │
    │                                                  │
    │  ┌──────────┐ ┌──────────┐ ┌──────────┐        │
    │  │ Audio    │ │ Text     │ │ToolCalls │        │
    │  │ in/out   │ │ instruct │ │ agent    │        │
    │  └──────────┘ └──────────┘ └──────────┘        │
    │                                                  │
    │  ──────── Zenoh mesh ────────────────           │
    │  (all channels published P2P)                    │
    └─────────────────────────────────────────────────┘
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import List

import numpy as np

from neon.streams.channels import (
    AudioChannel,
    CameraChannel,
    JointChannel,
    LidarChannel,
    TextChannel,
    ToolCallChannel,
)
from neon.streams.recorder import RecorderConfig, StreamRecorder

logger = logging.getLogger(__name__)


@dataclass
class SessionConfig:
    """Configuration for a streaming session."""

    # Robot
    robot_ip: str = "192.168.123.10"
    robot_name: str = "neon-g1"

    # Channels
    enable_lidar: bool = True
    enable_audio: bool = True
    enable_stereo: bool = True  # Stereo camera pair
    enable_tool_calls: bool = True

    # Inference
    model_path: str = ""  # Path to NeonVLA checkpoint
    inference_fps: float = 4.0  # VLA inference rate
    enable_inference: bool = True

    # Recording
    recorder: RecorderConfig = field(default_factory=RecorderConfig)

    # Zenoh
    enable_zenoh: bool = True
    zenoh_connect: str = ""  # Remote Zenoh endpoint (empty = local only)

    # Audio
    whisper_model: str = "openai/whisper-base"
    personaplex_voice: str = "NATM1"
    personaplex_host: str = "http://192.168.1.151:8400"

    # Safety
    emergency_stop_on_disconnect: bool = True


class StreamSession:
    """Orchestrates all channels for a live G1 session.

    This is the top-level object that ties everything together:
    - Connects to the G1 via SDK
    - Creates all data channels
    - Starts recording to HuggingFace
    - Runs VLA inference in a control loop
    - Handles voice commands (ASR → instruction → VLA → action)
    - Publishes all data to Zenoh for monitoring/teleop
    """

    def __init__(self, config: SessionConfig):
        self.config = config
        self._running = False

        # Channels
        self.joints = JointChannel("joints", sample_rate=500.0)
        self.camera_head = CameraChannel("camera_head", sample_rate=30.0, is_stereo=config.enable_stereo)
        self.text = TextChannel("text")
        self.tool_calls = ToolCallChannel("tool_calls")
        self.audio = AudioChannel("audio") if config.enable_audio else None
        self.lidar = LidarChannel("lidar") if config.enable_lidar else None

        self._all_channels: List = [self.joints, self.camera_head, self.text, self.tool_calls]
        if self.audio:
            self._all_channels.append(self.audio)
        if self.lidar:
            self._all_channels.append(self.lidar)

        # Recorder
        self.recorder = StreamRecorder(config.recorder)
        for ch in self._all_channels:
            self.recorder.attach(ch)

        # Model + controller (lazy-loaded)
        self._model = None
        self._controller = None
        self._inference_thread = None

        # Zenoh session
        self._zenoh_session = None

        # State
        self._current_instruction = ""

    @classmethod
    def from_robot(
        cls,
        robot_ip: str = "192.168.123.10",
        hub_id: str = "",
        model_path: str = "",
        **kwargs,
    ) -> "StreamSession":
        """Create a session configured for a specific robot.

        Args:
            robot_ip: G1 IP address
            hub_id: HuggingFace dataset ID for recording
            model_path: Path to NeonVLA checkpoint for inference
        """
        config = SessionConfig(
            robot_ip=robot_ip,
            recorder=RecorderConfig(hub_id=hub_id),
            model_path=model_path,
            **kwargs,
        )
        return cls(config)

    def start(self):
        """Start the full streaming session."""
        if self._running:
            logger.warning("Session already running")
            return

        self._running = True
        logger.info(f"Starting Neon streaming session → {self.config.robot_ip}")

        # 1. Connect to robot
        self._connect_robot()

        # 2. Start Zenoh mesh
        if self.config.enable_zenoh:
            self._start_zenoh()

        # 3. Start sensor polling threads
        self._start_sensor_threads()

        # 4. Start recording
        self.recorder.start(initial_task="idle")

        # 5. Start inference loop
        if self.config.enable_inference and self.config.model_path:
            self._start_inference()

        # 6. Start audio listener (ASR → instruction)
        if self.audio:
            self._start_audio_listener()

        logger.info("✅ Neon session active — all channels streaming")

    def stop(self):
        """Stop everything gracefully."""
        logger.info("Stopping Neon session...")
        self._running = False

        # Stop recording (this exports + pushes to HuggingFace)
        self.recorder.stop()

        # Disconnect robot
        if self._controller:
            self._controller.disconnect()

        # Close Zenoh
        if self._zenoh_session:
            self._zenoh_session.close()

        logger.info("Neon session stopped")

    def instruct(self, text: str):
        """Give a text instruction to the robot."""
        self._current_instruction = text
        self.text.push_text(text, role="user")
        logger.info(f"Instruction: {text}")

        # Start a new recording episode for this task
        self.recorder.new_episode(task=text)

    def _connect_robot(self):
        """Connect to the G1 hardware."""
        from neon.inference.g1_controller import G1Config, G1Controller

        self._controller = G1Controller(G1Config(robot_ip=self.config.robot_ip))
        self._controller.connect()

    def _start_zenoh(self):
        """Start Zenoh networking for all channels."""
        try:
            import zenoh

            zconfig = zenoh.Config()
            if self.config.zenoh_connect:
                zconfig.insert_json5("connect/endpoints", f'["{self.config.zenoh_connect}"]')

            self._zenoh_session = zenoh.open(zconfig)

            for ch in self._all_channels:
                ch.attach_zenoh(self._zenoh_session)

            logger.info("Zenoh mesh started — all channels publishing")
        except ImportError:
            logger.warning("Zenoh not available — running without P2P networking")
        except Exception as e:
            logger.warning(f"Zenoh start failed: {e}")

    def _start_sensor_threads(self):
        """Start background threads for sensor polling."""
        # Joint state polling @ 500Hz
        threading.Thread(target=self._poll_joints, daemon=True).start()

        # Camera polling @ 30Hz
        threading.Thread(target=self._poll_camera, daemon=True).start()

        # LiDAR polling @ 10Hz
        if self.lidar:
            threading.Thread(target=self._poll_lidar, daemon=True).start()

    def _poll_joints(self):
        """Poll joint states from the G1 SDK."""
        dt = 1.0 / 500.0
        while self._running:
            try:
                t0 = time.monotonic()
                if self._controller and self._controller.is_connected():
                    states = self._controller.get_joint_states()
                    self.joints.push_joint_state(positions=states)
                elapsed = time.monotonic() - t0
                if dt - elapsed > 0:
                    time.sleep(dt - elapsed)
            except Exception as e:
                logger.debug(f"Joint poll error: {e}")
                time.sleep(0.01)

    def _poll_camera(self):
        """Poll camera frames from the G1."""
        dt = 1.0 / 30.0
        while self._running:
            try:
                t0 = time.monotonic()
                if self._controller and self._controller.is_connected():
                    frame = self._controller.get_camera_frame()
                    if frame is not None:
                        self.camera_head.push_frame(np.array(frame))
                elapsed = time.monotonic() - t0
                if dt - elapsed > 0:
                    time.sleep(dt - elapsed)
            except Exception as e:
                logger.debug(f"Camera poll error: {e}")
                time.sleep(0.05)

    def _poll_lidar(self):
        """Poll LiDAR scans from the G1.

        The Unitree L1 LiDAR streams via UDP port 6100.
        We decode the proprietary Unitree LiDAR protocol into XYZ points.
        """
        import socket

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(1.0)
        try:
            sock.bind(("0.0.0.0", 6100))
        except OSError as e:
            logger.warning(f"Cannot bind LiDAR port 6100: {e}")
            return

        logger.info("LiDAR listener started on UDP 6100")

        while self._running:
            try:
                data, addr = sock.recvfrom(65535)
                # Decode Unitree L1 point cloud packet
                # Protocol: header(16 bytes) + points(N × 12 bytes)
                # Each point: float32 x, float32 y, float32 z
                if len(data) > 16:
                    header_size = 16
                    point_data = data[header_size:]
                    n_points = len(point_data) // 12
                    if n_points > 0:
                        points = np.frombuffer(point_data[:n_points*12], dtype=np.float32).reshape(n_points, 3)
                        # Add intensity column (not in basic L1 protocol)
                        intensity = np.ones((n_points, 1), dtype=np.float32)
                        full_points = np.hstack([points, intensity])
                        self.lidar.push_scan(full_points)
            except socket.timeout:
                continue
            except Exception as e:
                logger.debug(f"LiDAR poll error: {e}")

        sock.close()

    def _start_inference(self):
        """Start the VLA inference loop."""
        self._inference_thread = threading.Thread(target=self._inference_loop, daemon=True)
        self._inference_thread.start()

    def _inference_loop(self):
        """Run NeonVLA inference in a control loop."""
        from neon.model.neon_vla import NeonVLA

        logger.info(f"Loading NeonVLA from {self.config.model_path}")
        self._model = NeonVLA.from_pretrained(self.config.model_path, load_backbone=True)
        self._model.eval()

        device = "cuda" if self._has_cuda() else "cpu"
        self._model = self._model.to(device)

        dt = 1.0 / self.config.inference_fps
        logger.info(f"Inference loop started @ {self.config.inference_fps} Hz on {device}")

        while self._running:
            try:
                t0 = time.monotonic()

                # Gather latest observations from channels
                camera_sample = self.camera_head.latest()
                joint_sample = self.joints.latest()
                audio_samples = self.audio.window(2.0) if self.audio else []  # Last 2s of audio

                # Build observation
                image = None
                if camera_sample:
                    from PIL import Image
                    frame = camera_sample.data.get("left")
                    if frame is not None:
                        image = Image.fromarray(frame) if isinstance(frame, np.ndarray) else frame

                proprio = None
                if joint_sample:
                    proprio = joint_sample.data[:29]  # positions only

                # Audio waveform (concatenate recent chunks)
                audio_wave = None
                if audio_samples:
                    input_chunks = [s.data["samples"] for s in audio_samples if s.data["direction"] == "input"]
                    if input_chunks:
                        audio_wave = np.concatenate(input_chunks)

                # Run model
                output = self._model.predict(
                    image=image,
                    instruction=self._current_instruction,
                    proprioception=proprio,
                    audio=audio_wave,
                )

                # Send first action step to robot
                if output.raw_actions is not None and len(output.raw_actions) > 0:
                    if self._controller and self._controller.is_connected():
                        self._controller.send_actions(output.raw_actions[0])

                    # Record the tool call (action execution)
                    self.tool_calls.push_tool_call(
                        tool_name="neon_vla.predict",
                        arguments={"instruction": self._current_instruction},
                        result=f"actions_shape={output.actions.shape}",
                        duration_ms=(time.monotonic() - t0) * 1000,
                    )

                # Speech output
                if output.speech_path:
                    # Play on robot speaker + record
                    if self.audio:
                        try:
                            import soundfile as sf
                            speech_data, sr = sf.read(output.speech_path)
                            self.audio.push_audio_chunk(speech_data.astype(np.float32), direction="output")
                        except Exception:
                            pass

                elapsed = time.monotonic() - t0
                if dt - elapsed > 0:
                    time.sleep(dt - elapsed)

            except Exception as e:
                logger.error(f"Inference error: {e}")
                time.sleep(1.0)

    def _start_audio_listener(self):
        """Start background audio capture + ASR for voice commands."""
        threading.Thread(target=self._audio_listener_loop, daemon=True).start()

    def _audio_listener_loop(self):
        """Capture audio from microphone, run ASR, update instructions."""
        try:
            import sounddevice as sd
        except ImportError:
            logger.warning("sounddevice not available — no microphone input")
            return

        sample_rate = 16000
        chunk_duration = 2.0  # Process 2s chunks
        int(sample_rate * chunk_duration)

        logger.info("Audio listener started (16kHz, 2s chunks)")

        # VAD state
        silence_threshold = 0.01
        speech_buffer = []
        is_speaking = False

        def audio_callback(indata, frames, time_info, status):
            if not self._running:
                return
            audio_data = indata[:, 0].astype(np.float32)  # Mono

            # Push to audio channel
            if self.audio:
                self.audio.push_audio_chunk(audio_data, direction="input")

            # Simple VAD
            energy = np.mean(np.abs(audio_data))
            nonlocal is_speaking, speech_buffer

            if energy > silence_threshold:
                is_speaking = True
                speech_buffer.append(audio_data.copy())
            elif is_speaking and len(speech_buffer) > 0:
                # End of speech — run ASR
                is_speaking = False
                full_audio = np.concatenate(speech_buffer)
                speech_buffer = []

                if len(full_audio) > sample_rate * 0.5:  # At least 0.5s
                    self._transcribe_and_instruct(full_audio)

        try:
            with sd.InputStream(
                samplerate=sample_rate,
                channels=1,
                callback=audio_callback,
                blocksize=int(sample_rate * 0.1),  # 100ms blocks
            ):
                while self._running:
                    time.sleep(0.1)
        except Exception as e:
            logger.error(f"Audio stream error: {e}")

    def _transcribe_and_instruct(self, audio: np.ndarray):
        """Run Whisper ASR on audio and use as instruction."""
        try:
            import whisper

            # Use tiny model for speed
            if not hasattr(self, "_whisper_model"):
                self._whisper_model = whisper.load_model("base")

            result = self._whisper_model.transcribe(
                audio,
                language="en",
                fp16=False,
            )
            text = result["text"].strip()

            if text and len(text) > 3:
                logger.info(f"ASR: '{text}'")
                self.text.push_text(text, role="asr")
                self.instruct(text)

        except ImportError:
            logger.debug("Whisper not available for ASR")
        except Exception as e:
            logger.debug(f"ASR error: {e}")

    @staticmethod
    def _has_cuda() -> bool:
        try:
            import torch
            return torch.cuda.is_available()
        except ImportError:
            return False
