"""
Neon Streams — Omni-modal streaming data collection + inference.

Every channel in, every channel out, all at once.
The G1 is not a policy executor — it's a continuous learning machine.
"""

from neon.streams.channels import (
    AudioChannel,
    CameraChannel,
    JointChannel,
    LidarChannel,
    TextChannel,
    ToolCallChannel,
)
from neon.streams.recorder import StreamRecorder
from neon.streams.session import StreamSession

__all__ = [
    "AudioChannel",
    "CameraChannel",
    "JointChannel",
    "LidarChannel",
    "TextChannel",
    "ToolCallChannel",
    "StreamRecorder",
    "StreamSession",
]
