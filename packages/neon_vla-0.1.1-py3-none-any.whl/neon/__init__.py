"""
🤖 Neon — Open-source G1 humanoid VLA.

Video foundation model backbone + data soup training for whole-body control.

Quick start:
    # As a VLA model
    from neon import NeonVLA
    model = NeonVLA(NeonConfig(control_mode="arms_only"))

    # As a strands-robots policy
    from neon import NeonPolicy
    policy = NeonPolicy(host="localhost", port=8300)
    actions = policy.get_actions_sync(obs, "pick up the cup")

    # Via strands-robots create_policy (auto-registered)
    from strands_robots.policies import create_policy
    policy = create_policy("neon", host="localhost", port=8300)
"""

__version__ = "0.1.0"

from neon.data.action_space import G1ActionSpace
from neon.model.neon_vla import NeonVLA
from neon.policy import NeonPolicy

__all__ = ["NeonVLA", "G1ActionSpace", "NeonPolicy"]
