"""Neon tools module — Strands Agent integration."""
