"""
SceneBuilder — Procedural MuJoCo scene generation for Neon.

Generates MJCF XML for:
- Tables with random objects (cubes, bottles, mugs)
- Kitchen-like environments
- Warehouse/factory scenes
- Randomized lighting and textures

Each scene is a self-contained MJCF string that can be loaded
by NeonSimEnv alongside the G1 robot model.
"""

from __future__ import annotations

import logging
import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class ObjectSpec:
    """Specification for a manipulable object."""

    name: str
    shape: str  # "box", "sphere", "cylinder", "capsule"
    size: Tuple[float, ...]  # MuJoCo size params
    rgba: Tuple[float, float, float, float] = (0.5, 0.5, 0.5, 1.0)
    mass: float = 0.1  # kg
    friction: Tuple[float, float, float] = (0.8, 0.3, 0.1)
    pos: Tuple[float, float, float] = (0.0, 0.0, 0.0)


# Common household objects
OBJECT_LIBRARY: Dict[str, ObjectSpec] = {
    "red_cube": ObjectSpec("red_cube", "box", (0.03, 0.03, 0.03), (0.9, 0.1, 0.1, 1.0), 0.05),
    "blue_cube": ObjectSpec("blue_cube", "box", (0.035, 0.035, 0.035), (0.1, 0.2, 0.9, 1.0), 0.06),
    "green_cube": ObjectSpec("green_cube", "box", (0.025, 0.025, 0.025), (0.1, 0.8, 0.2, 1.0), 0.04),
    "red_mug": ObjectSpec("red_mug", "cylinder", (0.035, 0.05), (0.8, 0.1, 0.1, 1.0), 0.15),
    "blue_mug": ObjectSpec("blue_mug", "cylinder", (0.035, 0.05), (0.1, 0.2, 0.8, 1.0), 0.15),
    "bottle": ObjectSpec("bottle", "cylinder", (0.025, 0.1), (0.3, 0.7, 0.3, 1.0), 0.2),
    "ball": ObjectSpec("ball", "sphere", (0.03,), (1.0, 0.6, 0.0, 1.0), 0.05),
    "plate": ObjectSpec("plate", "cylinder", (0.08, 0.01), (0.9, 0.9, 0.85, 1.0), 0.2),
    "bowl": ObjectSpec("bowl", "sphere", (0.06,), (0.7, 0.5, 0.3, 1.0), 0.12),
    "can": ObjectSpec("can", "cylinder", (0.03, 0.06), (0.8, 0.0, 0.0, 1.0), 0.35),
}


@dataclass
class SceneConfig:
    """Configuration for procedural scene generation."""

    # Table
    table_pos: Tuple[float, float, float] = (0.55, 0.0, 0.0)
    table_size: Tuple[float, float, float] = (0.4, 0.6, 0.4)
    table_rgba: Tuple[float, float, float, float] = (0.6, 0.5, 0.4, 1.0)

    # Objects
    num_objects: int = 3
    object_types: Optional[List[str]] = None  # None = random from library
    object_scatter_radius: float = 0.25  # Scatter radius on table

    # Lighting
    randomize_lighting: bool = True
    num_lights: int = 2

    # Floor
    floor_texture: str = "checker"  # "checker", "flat"
    floor_rgba1: Tuple[float, float, float] = (0.2, 0.3, 0.4)
    floor_rgba2: Tuple[float, float, float] = (0.1, 0.2, 0.3)

    # Random seed
    seed: Optional[int] = None


class SceneBuilder:
    """Builds MuJoCo scene XML fragments for NeonSimEnv.

    Usage:
        builder = SceneBuilder(SceneConfig(num_objects=5))
        xml_fragment = builder.build()  # Returns MJCF XML string
        objects = builder.objects       # List of spawned ObjectSpecs
        tasks = builder.sample_tasks()  # Random task instructions
    """

    def __init__(self, config: SceneConfig = None):
        self.config = config or SceneConfig()
        self.objects: List[ObjectSpec] = []
        self._rng = np.random.RandomState(self.config.seed)

    def build(self) -> str:
        """Build complete scene MJCF fragment (worldbody children + assets).

        Returns:
            Tuple of (asset_xml, worldbody_xml) strings to inject into base MJCF.
        """
        self.objects = []

        asset_parts = [self._build_textures()]
        body_parts = [
            self._build_floor(),
            self._build_lights(),
            self._build_table(),
        ]

        # Spawn objects on table
        obj_types = self.config.object_types or list(OBJECT_LIBRARY.keys())
        table_top_z = self.config.table_pos[2] + self.config.table_size[2] + 0.05

        for i in range(self.config.num_objects):
            obj_name = self._rng.choice(obj_types)
            template = OBJECT_LIBRARY.get(obj_name)
            if template is None:
                continue

            # Random position on table surface
            angle = self._rng.uniform(0, 2 * np.pi)
            r = self._rng.uniform(0, self.config.object_scatter_radius)
            ox = self.config.table_pos[0] + r * np.cos(angle)
            oy = self.config.table_pos[1] + r * np.sin(angle)

            # Height depends on shape
            if template.shape == "box":
                oz = table_top_z + template.size[2]
            elif template.shape == "cylinder":
                oz = table_top_z + template.size[1]
            elif template.shape == "sphere":
                oz = table_top_z + template.size[0]
            else:
                oz = table_top_z + 0.05

            obj = ObjectSpec(
                name=f"{template.name}_{i}",
                shape=template.shape,
                size=template.size,
                rgba=template.rgba,
                mass=template.mass,
                friction=template.friction,
                pos=(ox, oy, oz),
            )
            self.objects.append(obj)
            body_parts.append(self._build_object(obj))

        asset_xml = "\n".join(asset_parts)
        worldbody_xml = "\n".join(body_parts)
        return asset_xml, worldbody_xml

    def sample_tasks(self, n: int = 5) -> List[str]:
        """Generate random task instructions based on spawned objects.

        Returns:
            List of natural language task strings.
        """
        if not self.objects:
            return ["explore the environment"]

        tasks = []
        verbs = ["pick up", "grasp", "move", "push", "lift"]
        targets = ["the table center", "the left side", "the right side", "near the edge"]

        for _ in range(n):
            obj = random.choice(self.objects)
            base_name = obj.name.rsplit("_", 1)[0].replace("_", " ")
            verb = random.choice(verbs)
            target = random.choice(targets)
            tasks.append(f"{verb} the {base_name} and place it on {target}")

        return tasks

    def _build_textures(self) -> str:
        """Build texture and material assets."""
        r1, g1, b1 = self.config.floor_rgba1
        r2, g2, b2 = self.config.floor_rgba2
        return f"""
    <texture type="skybox" builtin="gradient" rgb1="0.4 0.6 0.8" rgb2="0.05 0.05 0.1" width="512" height="3072"/>
    <texture type="2d" name="groundplane" builtin="{self.config.floor_texture}" mark="edge"
        rgb1="{r1} {g1} {b1}" rgb2="{r2} {g2} {b2}" markrgb="0.8 0.8 0.8" width="300" height="300"/>
    <material name="groundplane" texture="groundplane" texuniform="true" texrepeat="5 5" reflectance="0.2"/>
    <texture type="2d" name="table_tex" builtin="flat" rgb1="0.7 0.6 0.5" width="256" height="256"/>
    <material name="table_mat" texture="table_tex" texuniform="true" reflectance="0.1"/>"""

    def _build_floor(self) -> str:
        return '    <geom name="floor" size="0 0 0.05" type="plane" material="groundplane"/>'

    def _build_lights(self) -> str:
        parts = []
        for i in range(self.config.num_lights):
            if self.config.randomize_lighting:
                x = self._rng.uniform(-1, 2)
                y = self._rng.uniform(-2, 2)
                z = self._rng.uniform(2, 4)
                diffuse = self._rng.uniform(0.4, 0.8)
            else:
                x, y, z = 0, 0, 3
                diffuse = 0.6
            parts.append(
                f'    <light name="light_{i}" pos="{x:.2f} {y:.2f} {z:.2f}" '
                f'dir="0 0 -1" diffuse="{diffuse:.2f} {diffuse:.2f} {diffuse:.2f}" '
                f'specular="0.3 0.3 0.3"/>'
            )
        return "\n".join(parts)

    def _build_table(self) -> str:
        tx, ty, tz = self.config.table_pos
        sx, sy, sz = self.config.table_size
        r, g, b, a = self.config.table_rgba
        top_z = sz  # Top surface relative to body origin
        return f"""
    <body name="table" pos="{tx} {ty} {tz}">
      <geom name="table_top" pos="0 0 {top_z}" size="{sx} {sy} 0.03" type="box"
          rgba="{r} {g} {b} {a}" friction="0.8 0.3 0.1"/>
      <geom name="table_leg_fl" pos="{sx-0.05} {sy-0.05} {top_z/2}" size="0.03 0.03 {top_z/2}" type="box"
          rgba="{r*0.7} {g*0.7} {b*0.7} {a}"/>
      <geom name="table_leg_fr" pos="{sx-0.05} {-sy+0.05} {top_z/2}" size="0.03 0.03 {top_z/2}" type="box"
          rgba="{r*0.7} {g*0.7} {b*0.7} {a}"/>
      <geom name="table_leg_bl" pos="{-sx+0.05} {sy-0.05} {top_z/2}" size="0.03 0.03 {top_z/2}" type="box"
          rgba="{r*0.7} {g*0.7} {b*0.7} {a}"/>
      <geom name="table_leg_br" pos="{-sx+0.05} {-sy+0.05} {top_z/2}" size="0.03 0.03 {top_z/2}" type="box"
          rgba="{r*0.7} {g*0.7} {b*0.7} {a}"/>
    </body>"""

    def _build_object(self, obj: ObjectSpec) -> str:
        """Build MJCF for a single free-body object."""
        size_str = " ".join(f"{s:.4f}" for s in obj.size)
        rgba_str = " ".join(f"{c:.2f}" for c in obj.rgba)
        fric_str = " ".join(f"{f:.2f}" for f in obj.friction)
        px, py, pz = obj.pos
        return f"""
    <body name="{obj.name}" pos="{px:.4f} {py:.4f} {pz:.4f}">
      <joint type="free" name="{obj.name}_joint" damping="0.001"/>
      <geom name="{obj.name}_geom" type="{obj.shape}" size="{size_str}"
          rgba="{rgba_str}" mass="{obj.mass}" friction="{fric_str}"
          solimp="0.998 0.998 0.001" solref="0.001 2"/>
    </body>"""
