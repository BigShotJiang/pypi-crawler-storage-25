"""
NeonSimEnv — Simulation environment for G1 dataset generation.

Wraps strands_robots.Simulation (MuJoCo) and optionally
strands_robots.newton.NewtonBackend (GPU-accelerated) to provide
Neon-specific features:

1. Raycast LiDAR (matching Unitree L1 specs)
2. EEF tracking (bimanual pos+quat)
3. Neon stream channel integration → LeRobot v3 dataset
4. SceneBuilder for procedural manipulation scenes
5. Keyboard/gamepad teleop mapped to G1 29-DoF

The key insight: strands-robots already has a production-grade Simulation
class with URDF loading, multi-robot support, rendering, domain randomization,
and trajectory recording. We DON'T reinvent that — we layer Neon's
omni-modal sensors on top.

Architecture:
    ┌─────────────────────────────────────────────────────┐
    │                   NeonSimEnv                        │
    │                                                     │
    │  ┌──────────────────────────────────────────────┐  │
    │  │    strands_robots.Simulation (MuJoCo)        │  │
    │  │    or strands_robots.newton.NewtonBackend     │  │
    │  │    (physics, rendering, URDF, domain rand)   │  │
    │  └──────────────────┬───────────────────────────┘  │
    │                     │                               │
    │  ┌──────────────────┼──────────────────┐           │
    │  │ Neon Sensors (layered on top)       │           │
    │  │  - Raycast LiDAR (mj_ray)           │           │
    │  │  - EEF tracking (site FK)           │           │
    │  │  - Audio placeholder                │           │
    │  └──────────────────┬──────────────────┘           │
    │                     │                               │
    │  ┌──────────────────┼──────────────────┐           │
    │  │  Neon Stream Channels               │           │
    │  │  → StreamRecorder → LeRobot v3      │           │
    │  └─────────────────────────────────────┘           │
    └─────────────────────────────────────────────────────┘

Usage (MuJoCo backend — default):
    env = NeonSimEnv(NeonSimConfig(num_objects=5))
    env.reset(task="pick up the red cube")
    for _ in range(500):
        obs = env.get_observation()
        env.step(action)
    env.save_dataset()

Usage (Newton GPU backend — 4096 parallel envs):
    env = NeonSimEnv(NeonSimConfig(
        backend="newton",
        num_envs=4096,
        device="cuda:0",
    ))
    env.reset(task="pick up the red cube")
    # obs batched: (4096, ...)
    obs = env.get_observation()

Requires:
    - strands-robots>=0.1.0 (core dependency)
    - mujoco>=3.0.0 for MuJoCo backend (pip install neon-vla[sim])
    - newton for GPU backend (pip install newton-sim)
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import numpy as np

logger = logging.getLogger(__name__)


# =============================================================================
# LiDAR configuration (Neon-specific — not in strands-robots)
# =============================================================================


@dataclass
class LidarConfig:
    """Raycast LiDAR configuration matching Unitree L1 specs.

    Unitree L1 specs (real hardware):
    - FOV: 360° horizontal, ±15° vertical (30° total)
    - Range: 0.05m – 30m
    - Points per scan: ~21,600
    - Rate: 10 Hz

    We simulate this with MuJoCo raycasts from the head body.
    """

    enabled: bool = True
    num_horizontal: int = 180  # Rays around 360° azimuth
    num_vertical: int = 12  # Vertical channels
    fov_horizontal: float = 2 * math.pi  # 360°
    fov_vertical: float = math.radians(30)  # ±15°
    range_min: float = 0.05  # meters
    range_max: float = 30.0  # meters
    noise_std: float = 0.002  # Gaussian noise (meters)
    mount_body: str = "torso_link"  # MuJoCo body to mount sensor on (Menagerie: torso_link)

    @property
    def total_rays(self) -> int:
        return self.num_horizontal * self.num_vertical


@dataclass
class CameraConfig:
    """Camera configuration for head and hand cameras."""

    enabled: bool = True
    width: int = 640
    height: int = 480
    fov: float = 60.0  # degrees
    head_camera_body: str = "torso_link"
    hand_camera_body: str = "left_wrist_yaw_link"


@dataclass
class NeonSimConfig:
    """Configuration for the Neon simulation environment."""

    # Backend selection
    backend: str = "mujoco"  # "mujoco" or "newton"
    num_envs: int = 1  # >1 only with newton backend
    device: str = "cuda:0"  # For newton backend

    # Physics
    physics_dt: float = 0.002  # 500 Hz physics
    control_dt: float = 0.02  # 50 Hz control (matches real G1)

    # Robot
    robot_name: str = "unitree_g1"
    use_hands: bool = False  # Use 43-DoF model

    # Sensors
    lidar: LidarConfig = field(default_factory=LidarConfig)
    camera: CameraConfig = field(default_factory=CameraConfig)

    # Scene
    num_objects: int = 3
    scene_seed: Optional[int] = None

    # Recording
    record: bool = True
    hub_id: str = ""  # HuggingFace dataset ID
    output_dir: str = "/tmp/neon_sim_data"
    fps: int = 4  # Recording FPS (LeRobot v3 target)

    # EEF tracking
    left_eef_site: str = "left_hand_marker"
    right_eef_site: str = "right_hand_marker"


class NeonSimEnv:
    """MuJoCo/Newton simulation environment for G1 dataset generation.

    Wraps strands_robots.Simulation for physics + rendering, layers
    Neon-specific sensors (LiDAR, EEF) and recording on top.
    """

    def __init__(self, config: NeonSimConfig = None):
        self.config = config or NeonSimConfig()
        self._sim = None  # strands_robots.Simulation
        self._newton = None  # strands_robots.newton.NewtonBackend
        self._step_count = 0
        self._episode_count = 0

        # LiDAR ray directions (precomputed)
        self._lidar_directions: Optional[np.ndarray] = None

        # Stream channels + recorder
        self._recorder = None
        self._channels_initialized = False
        self._scene_builder = None
        self._scene_objects = []

        # Direct LeRobot v3 writer (alternative to StreamRecorder)
        self._v3_writer = None
        self._v3_task = ""
        self._last_action: Optional[np.ndarray] = None

        self._load()

    def _load(self):
        """Initialize the simulation backend."""
        if self.config.backend == "newton":
            self._load_newton()
        else:
            self._load_mujoco()

        # Precompute LiDAR rays
        if self.config.lidar.enabled:
            self._precompute_lidar_rays()

        # Init recording channels
        if self.config.record:
            self._init_recording()

    def _load_mujoco(self):
        """Initialize via strands_robots.Simulation."""
        try:
            from neon.sim.simulation import Simulation
        except ImportError:
            raise ImportError(
                "MuJoCo simulation requires mujoco. "
                "Install with: pip install neon-vla[sim]"
            )

        self._sim = Simulation(
            tool_name="neon_sim",
            default_timestep=self.config.physics_dt,
            default_width=self.config.camera.width,
            default_height=self.config.camera.height,
            mesh=False,  # Don't auto-start Zenoh mesh for sim
        )

        # Create world
        self._sim_action("create_world")

        # Add G1 robot
        robot_kwargs = {"name": "g1", "data_config": self.config.robot_name}
        self._sim_action("add_robot", **robot_kwargs)

        # Build scene with objects
        if self.config.num_objects > 0:
            self._build_scene()

        # Add cameras
        self._sim_action("add_camera", name="head_cam", position=[1.5, 0, 1.5], fov=60)
        self._sim_action("add_camera", name="hand_cam", position=[0.8, 0.5, 1.0], fov=60)

        # Settle physics
        self._sim_action("step", n_steps=100)

        logger.info(f"NeonSimEnv (MuJoCo) loaded: {self.config.robot_name}")

    def _load_newton(self):
        """Initialize via strands_robots.newton.NewtonBackend."""
        try:
            from neon.sim.newton import NewtonBackend, NewtonConfig
        except ImportError:
            raise ImportError(
                "Newton backend requires: pip install neon-vla[newton]\n"
                "Or use backend='mujoco' (default)"
            )

        newton_config = NewtonConfig(
            num_envs=self.config.num_envs,
            solver="mujoco",
            device=self.config.device,
            physics_dt=self.config.physics_dt,
        )
        self._newton = NewtonBackend(newton_config)
        self._newton.create_world()
        self._newton.add_robot("g1", data_config=self.config.robot_name)

        if self.config.num_envs > 1:
            self._newton.replicate(num_envs=self.config.num_envs)

        logger.info(f"NeonSimEnv (Newton GPU) loaded: {self.config.num_envs} envs on {self.config.device}")

    def _build_scene(self):
        """Add table and objects to the scene using SceneBuilder."""
        from neon.sim.scene import SceneBuilder, SceneConfig

        scene_config = SceneConfig(
            num_objects=self.config.num_objects,
            seed=self.config.scene_seed,
        )
        self._scene_builder = SceneBuilder(scene_config)
        self._scene_builder.build()
        self._scene_objects = self._scene_builder.objects

        # Add table via strands-robots
        tx, ty, tz = scene_config.table_pos
        sx, sy, sz = scene_config.table_size
        self._sim_action(
            "add_object", name="table", shape="box",
            position=[tx, ty, tz + sz], size=[sx * 2, sy * 2, 0.06],
            color=[0.6, 0.5, 0.4, 1.0], is_static=True,
        )

        # Add objects
        for obj in self._scene_objects:
            self._sim_action(
                "add_object", name=obj.name, shape=obj.shape,
                position=list(obj.pos), size=list(obj.size),
                color=list(obj.rgba), mass=obj.mass,
            )

    def _sim_action(self, action: str, **kwargs) -> Dict[str, Any]:
        """Call a strands_robots.Simulation action."""
        if self._sim is None:
            return {}
        # Use the Simulation's internal methods directly
        # (more efficient than going through the AgentTool interface)
        method = getattr(self._sim, f"_{action}", None) or getattr(self._sim, action, None)
        if method and callable(method):
            return method(**kwargs)
        # Fallback: go through the tool interface
        try:
            return self._sim.invoke({"action": action, **kwargs})
        except Exception as e:
            logger.debug(f"sim_action({action}) failed: {e}")
            return {}

    def _precompute_lidar_rays(self):
        """Precompute ray directions for LiDAR simulation."""
        cfg = self.config.lidar
        directions = []
        for v in range(cfg.num_vertical):
            elevation = -cfg.fov_vertical / 2 + cfg.fov_vertical * v / max(cfg.num_vertical - 1, 1)
            for h in range(cfg.num_horizontal):
                azimuth = cfg.fov_horizontal * h / cfg.num_horizontal
                dx = math.cos(elevation) * math.cos(azimuth)
                dy = math.cos(elevation) * math.sin(azimuth)
                dz = math.sin(elevation)
                directions.append([dx, dy, dz])
        self._lidar_directions = np.array(directions, dtype=np.float64)

    def _init_recording(self):
        """Initialize stream channels and recorder for LeRobot v3 export."""
        from neon.streams.channels import (
            CameraChannel,
            JointChannel,
            LidarChannel,
            TextChannel,
        )
        from neon.streams.recorder import RecorderConfig, StreamRecorder

        self._joint_channel = JointChannel("joints", sample_rate=50.0)
        self._camera_channel = CameraChannel("camera_head", sample_rate=30.0)
        self._lidar_channel = LidarChannel("lidar") if self.config.lidar.enabled else None
        self._text_channel = TextChannel("text")

        recorder_config = RecorderConfig(
            hub_id=self.config.hub_id,
            output_dir=self.config.output_dir,
            target_fps=self.config.fps,
            push_to_hub=bool(self.config.hub_id),
            use_lerobot_v3=True,
            episode_duration=0,  # Manual segmentation — don't auto-split
            min_episode_length=0.5,  # Accept short episodes
        )
        self._recorder = StreamRecorder(recorder_config)

        all_channels = [self._joint_channel, self._camera_channel, self._text_channel]
        if self._lidar_channel:
            all_channels.append(self._lidar_channel)
        for ch in all_channels:
            self._recorder.attach(ch)

        self._channels_initialized = True

    # =========================================================================
    # Public API
    # =========================================================================

    def reset(self, task: str = "", seed: int = None) -> Dict[str, Any]:
        """Reset environment to initial state."""
        if self._sim:
            self._sim_action("reset")
            # Must call mj_forward to populate xpos/xmat after reset
            # (reset zeros them out, making raycasts fail)
            try:
                import mujoco as mj
                if self._sim.mj_model and self._sim.mj_data:
                    mj.mj_forward(self._sim.mj_model, self._sim.mj_data)
            except ImportError:
                pass
        elif self._newton:
            self._newton.reset()

        self._step_count = 0

        if self._recorder:
            if self._episode_count > 0:
                self._recorder.new_episode(task=task)
            else:
                self._recorder.start(initial_task=task)
            if task and self._channels_initialized:
                self._text_channel.push_text(task, role="user")

        self._episode_count += 1
        return self.get_observation()

    def step(self, action: np.ndarray) -> Dict[str, Any]:
        """Step the simulation with a joint action.

        Args:
            action: Joint position targets (29, 43, or 46 DoF)

        Returns:
            Observation dict with all modalities.
        """
        if self._sim:
            # Convert array action to joint-name dict for strands-robots
            obs = self._sim.get_observation("g1")
            if obs:
                joint_names = [k for k in obs.keys() if not k.startswith("cam_")]
                action_dict = {}
                for i, name in enumerate(joint_names):
                    if i < len(action):
                        action_dict[name] = float(action[i])
                self._sim.send_action(action_dict, robot_name="g1")
            # Step physics
            n_substeps = max(1, int(self.config.control_dt / self.config.physics_dt))
            self._sim_action("step", n_steps=n_substeps)
        elif self._newton:
            self._newton.step({"g1": action})

        self._step_count += 1
        obs = self.get_observation()

        if self._channels_initialized:
            self._record_step(obs)

        # V3 direct recording
        if self._v3_writer is not None:
            self.record_v3_frame(obs, action)
        self._last_action = action

        return obs

    def get_observation(self) -> Dict[str, Any]:
        """Get current observation from all sensors.

        Returns:
            Dict with: joint_pos, joint_vel, image_head, image_hand,
            lidar, eef_left, eef_right, depth, segmentation, gps, time
        """
        obs = {"time": self._step_count * self.config.control_dt}

        if self._sim:
            # Get joint state from strands-robots
            sim_obs = self._sim.get_observation("g1")
            if sim_obs:
                # Filter to scalar joint values only (exclude camera images)
                joint_names = [
                    k for k, v in sim_obs.items()
                    if not k.startswith("cam_") and not k.endswith("_cam")
                    and isinstance(v, (int, float))
                ]
                obs["joint_pos"] = np.array([sim_obs[n] for n in joint_names], dtype=np.float32)
                obs["joint_names"] = joint_names

                # Extract camera images from sim observation
                for cam_key in ["head_cam", "hand_cam"]:
                    if cam_key in sim_obs and isinstance(sim_obs[cam_key], np.ndarray):
                        obs_key = "image_head" if "head" in cam_key else "image_hand"
                        obs[obs_key] = sim_obs[cam_key]

            # Camera via strands-robots render
            try:
                img = self._sim_action("render", camera_name="head_cam")
                if isinstance(img, np.ndarray):
                    obs["image_head"] = img
                elif img is not None:
                    # PIL Image or other format → convert to numpy
                    obs["image_head"] = np.asarray(img, dtype=np.uint8)
            except Exception:
                pass

            # Depth rendering (GEN1)
            obs["depth"] = self._render_depth()

            # Segmentation rendering (GEN2)
            obs["segmentation"] = self._render_segmentation()

            # GPS simulation (GEN3)
            obs["gps"] = self._simulate_gps()

            # LiDAR via MuJoCo raycasts (Neon-specific)
            if self.config.lidar.enabled and self._sim.mj_model is not None:
                obs["lidar"] = self._raycast_lidar()

            # EEF tracking (Neon-specific)
            obs["eef_left"] = self._get_eef_state("left")
            obs["eef_right"] = self._get_eef_state("right")

        elif self._newton:
            newton_obs = self._newton.get_observation("g1")
            if newton_obs:
                obs["joint_pos"] = newton_obs.get("joint_pos", np.zeros(29))

        return obs

    def _render_depth(self) -> np.ndarray:
        """Render depth map from the head camera using MuJoCo depth buffer.

        GEN1: MuJoCo provides a depth buffer per camera render. We extract it
        and convert from OpenGL z-buffer to metric depth (meters).

        Returns:
            (H, W) float32 depth map in meters. Returns zeros if unavailable.
        """
        H = self.config.camera.height
        W = self.config.camera.width
        try:
            import mujoco as mj

            model = self._sim.mj_model
            data = self._sim.mj_data
            if model is None or data is None:
                return np.zeros((H, W), dtype=np.float32)

            # Create renderer if needed
            renderer = mj.Renderer(model, height=H, width=W)
            renderer.update_scene(data, camera="head_cam")
            renderer.enable_depth_rendering(True)
            depth_buffer = renderer.render()
            renderer.enable_depth_rendering(False)

            # Convert OpenGL depth buffer to metric depth
            # MuJoCo depth buffer is in [0, 1] (znear to zfar)
            extent = model.stat.extent
            near = model.vis.map.znear * extent
            far = model.vis.map.zfar * extent
            # Linear depth: d = near * far / (far - (far - near) * depth_buffer)
            depth_linear = near * far / (far - (far - near) * depth_buffer)
            depth_linear = np.clip(depth_linear, 0, far).astype(np.float32)

            renderer.close()
            return depth_linear

        except (ImportError, AttributeError, Exception) as e:
            logger.debug(f"Depth rendering unavailable: {e}")
            return np.zeros((H, W), dtype=np.float32)

    def _render_segmentation(self) -> np.ndarray:
        """Render per-pixel segmentation labels using MuJoCo segid buffer.

        GEN2: MuJoCo assigns a geom ID to each pixel during rendering.
        We map these to semantic class labels.

        Class mapping:
            0: background/sky
            1: floor/ground
            2: table
            3: robot body
            4-19: objects (cubes, cups, etc.)

        Returns:
            (H, W) uint8 segmentation mask with class IDs.
        """
        H = self.config.camera.height
        W = self.config.camera.width
        try:
            import mujoco as mj

            model = self._sim.mj_model
            data = self._sim.mj_data
            if model is None or data is None:
                return np.zeros((H, W), dtype=np.uint8)

            # Create renderer for segmentation
            renderer = mj.Renderer(model, height=H, width=W)
            renderer.update_scene(data, camera="head_cam")
            renderer.enable_segmentation_rendering(True)
            seg_buffer = renderer.render()  # (H, W, 2) — [geom_id, body_type]
            renderer.enable_segmentation_rendering(False)

            # Extract geom IDs (first channel)
            if seg_buffer.ndim == 3:
                geom_ids = seg_buffer[:, :, 0]
            else:
                geom_ids = seg_buffer

            # Map geom IDs to semantic classes
            seg_mask = np.zeros((H, W), dtype=np.uint8)

            for geom_id in np.unique(geom_ids):
                if geom_id < 0:
                    seg_mask[geom_ids == geom_id] = 0  # Background
                    continue

                try:
                    geom_name = mj.mj_id2name(model, mj.mjtObj.mjOBJ_GEOM, int(geom_id))
                    body_id = model.geom_bodyid[int(geom_id)]
                    body_name = mj.mj_id2name(model, mj.mjtObj.mjOBJ_BODY, body_id) or ""
                except Exception:
                    geom_name = ""
                    body_name = ""

                geom_name = (geom_name or "").lower()
                body_name = (body_name or "").lower()

                # Classify based on name patterns
                if "floor" in geom_name or "ground" in geom_name:
                    cls = 1
                elif "table" in geom_name:
                    cls = 2
                elif any(r in body_name for r in ["g1", "robot", "link", "joint"]):
                    cls = 3
                elif geom_id > 0:
                    # Objects: map to classes 4-19
                    cls = 4 + (int(geom_id) % 16)
                else:
                    cls = 0

                seg_mask[geom_ids == geom_id] = cls

            renderer.close()
            return seg_mask

        except (ImportError, AttributeError, Exception) as e:
            logger.debug(f"Segmentation rendering unavailable: {e}")
            return np.zeros((H, W), dtype=np.uint8)

    def _simulate_gps(self) -> np.ndarray:
        """Simulate GPS coordinates from robot root body position.

        GEN3: Converts MuJoCo world position to synthetic GPS coordinates.
        The robot's pelvis/torso position is mapped to [lat, lon, alt, heading, pitch, roll].

        This is SYNTHETIC GPS — not real satellite positioning. It provides:
        - Global position awareness (x, y → lat, lon)
        - Altitude (z → alt)
        - Orientation (body rotation → heading, pitch, roll)

        Reference frame: MuJoCo origin → GPS origin at (37.7749, -122.4194, 0) [San Francisco]

        Returns:
            (6,) float32: [latitude, longitude, altitude, heading, pitch, roll]
        """
        try:
            import mujoco as mj

            model = self._sim.mj_model
            data = self._sim.mj_data
            if model is None or data is None:
                return np.zeros(6, dtype=np.float32)

            # Get robot root body position
            try:
                body_id = mj.mj_name2id(model, mj.mjtObj.mjOBJ_BODY, "torso_link")
                if body_id < 0:
                    body_id = 1  # pelvis
            except Exception:
                body_id = 1

            pos = data.xpos[body_id].copy()  # (x, y, z) in meters
            rot_mat = data.xmat[body_id].reshape(3, 3).copy()

            # Convert position to GPS coordinates
            # 1 meter ≈ 0.000009° latitude, ≈ 0.000011° longitude at SF
            ref_lat, ref_lon = 37.7749, -122.4194
            lat = ref_lat + pos[0] * 0.000009
            lon = ref_lon + pos[1] * 0.000011
            alt = pos[2]  # meters above ground

            # Extract heading, pitch, roll from rotation matrix
            # heading = atan2(R[1,0], R[0,0])
            heading = np.arctan2(rot_mat[1, 0], rot_mat[0, 0])
            # pitch = asin(-R[2,0])
            pitch = np.arcsin(-np.clip(rot_mat[2, 0], -1, 1))
            # roll = atan2(R[2,1], R[2,2])
            roll = np.arctan2(rot_mat[2, 1], rot_mat[2, 2])

            return np.array([lat, lon, alt, heading, pitch, roll], dtype=np.float32)

        except (ImportError, Exception) as e:
            logger.debug(f"GPS simulation unavailable: {e}")
            return np.zeros(6, dtype=np.float32)

    def _raycast_lidar(self) -> np.ndarray:
        """Simulate LiDAR by raycasting from the sensor mount point."""
        try:
            import mujoco as mj
        except ImportError:
            return np.zeros((0, 4), dtype=np.float32)

        model = self._sim.mj_model
        data = self._sim.mj_data
        cfg = self.config.lidar

        if model is None or data is None:
            return np.zeros((0, 4), dtype=np.float32)

        # Get sensor mount body pose
        try:
            body_id = mj.mj_name2id(model, mj.mjtObj.mjOBJ_BODY, cfg.mount_body)
            if body_id < 0:
                # Body not found — try torso_link as fallback
                body_id = mj.mj_name2id(model, mj.mjtObj.mjOBJ_BODY, "torso_link")
            if body_id < 0:
                body_id = 1  # pelvis (always exists)
        except Exception:
            body_id = 1

        mount_pos = data.xpos[body_id].copy()
        mount_rot = data.xmat[body_id].reshape(3, 3).copy()

        # Ensure kinematics are up to date (xpos/xmat need mj_forward)
        mj.mj_forward(model, data)

        # Re-read after forward pass (positions now updated)
        mount_pos = data.xpos[body_id].copy()
        mount_rot = data.xmat[body_id].reshape(3, 3).copy()

        # Transform ray directions to world frame
        world_dirs = (mount_rot @ self._lidar_directions.T).T

        # Normalize directions (rotation should preserve length, but numerical issues)
        norms = np.linalg.norm(world_dirs, axis=1, keepdims=True)
        norms = np.maximum(norms, 1e-8)  # Avoid division by zero
        world_dirs = world_dirs / norms

        points = []
        for direction in world_dirs:
            # Skip near-zero directions (safety check for mj_ray)
            if np.linalg.norm(direction) < 1e-6:
                continue
            geomid = np.array([-1], dtype=np.int32)
            dist = mj.mj_ray(model, data, mount_pos, direction, None, 1, -1, geomid)

            if dist > 0 and cfg.range_min <= dist <= cfg.range_max:
                if cfg.noise_std > 0:
                    dist += np.random.normal(0, cfg.noise_std)
                hit_point = mount_pos + direction * dist
                intensity = max(0.0, 1.0 - dist / cfg.range_max)
                points.append([hit_point[0], hit_point[1], hit_point[2], intensity])

        return np.array(points, dtype=np.float32) if points else np.zeros((0, 4), dtype=np.float32)

    def _get_eef_state(self, side: str) -> np.ndarray:
        """Get end-effector position and orientation [x, y, z, qw, qx, qy, qz]."""
        try:
            import mujoco as mj
        except ImportError:
            return np.zeros(7, dtype=np.float32)

        model = self._sim.mj_model
        data = self._sim.mj_data
        if model is None or data is None:
            return np.zeros(7, dtype=np.float32)

        site_name = self.config.left_eef_site if side == "left" else self.config.right_eef_site
        try:
            site_id = mj.mj_name2id(model, mj.mjtObj.mjOBJ_SITE, site_name)
            pos = data.site_xpos[site_id].copy()
            rot_mat = data.site_xmat[site_id].reshape(3, 3)
            quat = _rotmat_to_quat(rot_mat)
            return np.concatenate([pos, quat]).astype(np.float32)
        except Exception:
            return np.zeros(7, dtype=np.float32)

    def _record_step(self, obs: Dict[str, Any]):
        """Push current observation to recording channels."""
        if "joint_pos" in obs:
            jp = obs["joint_pos"]
            n = len(jp)
            joint_data = np.zeros(n * 3, dtype=np.float32)
            joint_data[:n] = jp
            self._joint_channel.push_joint_state(positions=joint_data)

        if "image_head" in obs:
            self._camera_channel.push_frame(obs["image_head"])

        if self._lidar_channel and "lidar" in obs and len(obs["lidar"]) > 0:
            self._lidar_channel.push_scan(obs["lidar"])

        # EEF state (bimanual) — store via base push on joint channel
        if hasattr(self, '_joint_channel') and ("eef_left" in obs or "eef_right" in obs):
            eef_left = obs.get("eef_left", np.zeros(7, dtype=np.float32))
            eef_right = obs.get("eef_right", np.zeros(7, dtype=np.float32))
            eef_state = np.concatenate([eef_left, eef_right]).astype(np.float32)
            self._joint_channel.push({"eef_state": eef_state})

    # =========================================================================
    # GEN1: Depth Rendering
    # =========================================================================

    def render_depth(
        self,
        camera_name: str = "head_cam",
        width: int = None,
        height: int = None,
        near: float = 0.01,
        far: float = 50.0,
    ) -> np.ndarray:
        """Render a depth map from the specified camera.

        Uses MuJoCo's depth buffer to produce a float32 depth map where
        each pixel contains the distance from the camera in meters.

        The raw MuJoCo depth buffer is in normalised [0, 1] range where:
            0.0 = near clip plane
            1.0 = far clip plane (or background)
        We linearise it to metric depth using the model's znear/zfar.

        Args:
            camera_name: MuJoCo camera name (default: "head_cam")
            width: Override render width (default: config.camera.width)
            height: Override render height (default: config.camera.height)
            near: Near clip plane in meters (default: 0.01)
            far: Far clip plane in meters (default: 50.0)

        Returns:
            (H, W) float32 array with depth values in meters.
            Background pixels have depth = far.
        """
        w = width or self.config.camera.width
        h = height or self.config.camera.height

        if self._sim is None or self._sim.mj_model is None or self._sim.mj_data is None:
            return np.full((h, w), far, dtype=np.float32)

        try:
            import mujoco as mj

            model = self._sim.mj_model
            data = self._sim.mj_data

            # Ensure kinematics are up to date
            mj.mj_forward(model, data)

            renderer = mj.Renderer(model, height=h, width=w)

            # Resolve camera
            cam_id = mj.mj_name2id(model, mj.mjtObj.mjOBJ_CAMERA, camera_name)
            if cam_id >= 0:
                renderer.update_scene(data, camera=cam_id)
            else:
                renderer.update_scene(data)

            # Enable depth rendering
            renderer.enable_depth_rendering()
            raw_depth = renderer.render().copy()
            renderer.disable_depth_rendering()
            del renderer

            # Linearise normalised depth buffer to metric depth
            # MuJoCo depth buffer: 0 = near, 1 = far (background)
            # Use model extent to get reasonable near/far if available
            model_near = near
            model_far = far

            # Linearise: depth_m = near * far / (far - raw * (far - near))
            denom = model_far - raw_depth * (model_far - model_near)
            denom = np.maximum(denom, 1e-8)  # avoid div-by-zero
            depth_meters = (model_near * model_far / denom).astype(np.float32)

            # Clamp background (raw_depth ~= 1.0) to far
            depth_meters = np.clip(depth_meters, model_near, model_far)

            return depth_meters

        except ImportError:
            return np.full((h, w), far, dtype=np.float32)
        except Exception as e:
            logger.warning(f"Depth rendering failed: {e}")
            return np.full((h, w), far, dtype=np.float32)

    # =========================================================================
    # GEN2: Segmentation Rendering
    # =========================================================================

    def render_segmentation(
        self,
        camera_name: str = "head_cam",
        width: int = None,
        height: int = None,
    ) -> np.ndarray:
        """Render a semantic segmentation mask from the specified camera.

        Uses MuJoCo's segmentation buffer (geom IDs per pixel) and maps
        them to semantic class labels based on body membership.

        Class mapping:
            0 = background (sky / far plane)
            1 = ground/floor
            2 = robot body parts
            3 = table / static furniture
            4+ = dynamic objects (one class per object)

        Args:
            camera_name: MuJoCo camera name (default: "head_cam")
            width: Override render width (default: config.camera.width)
            height: Override render height (default: config.camera.height)

        Returns:
            (H, W) uint8 array with per-pixel class labels.
        """
        w = width or self.config.camera.width
        h = height or self.config.camera.height

        if self._sim is None or self._sim.mj_model is None or self._sim.mj_data is None:
            return np.zeros((h, w), dtype=np.uint8)

        try:
            import mujoco as mj

            model = self._sim.mj_model
            data = self._sim.mj_data

            mj.mj_forward(model, data)

            renderer = mj.Renderer(model, height=h, width=w)

            cam_id = mj.mj_name2id(model, mj.mjtObj.mjOBJ_CAMERA, camera_name)
            if cam_id >= 0:
                renderer.update_scene(data, camera=cam_id)
            else:
                renderer.update_scene(data)

            # Enable segmentation rendering — returns (H, W, 3) with
            # [:, :, 0] = geom id, [:, :, 1] = body id (MuJoCo >= 3.0)
            renderer.enable_segmentation_rendering()
            seg_raw = renderer.render().copy()
            renderer.disable_segmentation_rendering()
            del renderer

            # Build semantic label map from geom/body IDs
            seg_mask = np.zeros((h, w), dtype=np.uint8)

            # seg_raw shape is (H, W, 3) int32: [geom_id, body_type/id, ...]
            geom_ids = seg_raw[:, :, 0]

            # Build geom → class mapping
            geom_class = self._build_geom_class_map(model)

            # Vectorised lookup
            for gid, cls_label in geom_class.items():
                seg_mask[geom_ids == gid] = cls_label

            # Background: geom_id == -1
            seg_mask[geom_ids < 0] = 0

            return seg_mask

        except ImportError:
            return np.zeros((h, w), dtype=np.uint8)
        except Exception as e:
            logger.warning(f"Segmentation rendering failed: {e}")
            return np.zeros((h, w), dtype=np.uint8)

    def _build_geom_class_map(self, model) -> Dict[int, int]:
        """Build a mapping from MuJoCo geom ID to semantic class label.

        Returns:
            Dict mapping geom_id → class_label (uint8)
        """
        try:
            import mujoco as mj
        except ImportError:
            return {}

        geom_class = {}
        # Collect known object names for class assignment
        object_names = {obj.name for obj in self._scene_objects} if self._scene_objects else set()
        next_dynamic_class = 4  # Start dynamic objects at class 4

        dynamic_name_to_class: Dict[str, int] = {}

        for gid in range(model.ngeom):
            geom_name = mj.mj_id2name(model, mj.mjtObj.mjOBJ_GEOM, gid) or ""
            body_id = model.geom_bodyid[gid]
            body_name = mj.mj_id2name(model, mj.mjtObj.mjOBJ_BODY, body_id) or "" if body_id >= 0 else ""

            if "ground" in geom_name or "floor" in geom_name:
                geom_class[gid] = 1  # ground
            elif "table" in geom_name or "table" in body_name:
                geom_class[gid] = 3  # table / static furniture
            elif body_name in object_names or geom_name.replace("_geom", "") in object_names:
                obj_key = body_name if body_name in object_names else geom_name.replace("_geom", "")
                if obj_key not in dynamic_name_to_class:
                    dynamic_name_to_class[obj_key] = min(next_dynamic_class, 255)
                    next_dynamic_class += 1
                geom_class[gid] = dynamic_name_to_class[obj_key]
            elif body_id > 0:
                # Anything attached to a non-world body is probably the robot
                geom_class[gid] = 2  # robot
            else:
                geom_class[gid] = 0  # background / world body geoms

        return geom_class

    # =========================================================================
    # GEN3: GPS Simulation
    # =========================================================================

    # Synthetic GPS origin — maps MuJoCo world (0,0,0) to a reference
    # GPS coordinate. Default: NVIDIA GTC convention center, San Jose.
    _GPS_ORIGIN_LAT = 37.3318  # degrees
    _GPS_ORIGIN_LON = -121.8905  # degrees
    _GPS_ORIGIN_ALT = 26.0  # meters above sea level

    # Approximate meters per degree at this latitude
    _METERS_PER_DEG_LAT = 111_320.0
    _METERS_PER_DEG_LON = 111_320.0 * math.cos(math.radians(37.3318))

    def get_gps(self) -> np.ndarray:
        """Get synthetic GPS coordinates from the robot's root body position.

        Converts the robot's MuJoCo world-frame position (x, y, z) into
        synthetic GPS coordinates (latitude, longitude, altitude) and
        orientation (heading, pitch, roll) from the root body rotation matrix.

        The mapping uses a fixed GPS origin so that sim positions are
        reproducibly mapped to geographic coordinates.

        Returns:
            (6,) float32 array: [latitude, longitude, altitude, heading, pitch, roll]
                - latitude/longitude: decimal degrees
                - altitude: meters above sea level
                - heading: degrees from north [0, 360)
                - pitch: degrees [-90, 90]
                - roll: degrees [-180, 180]
        """
        default_gps = np.array([
            self._GPS_ORIGIN_LAT,
            self._GPS_ORIGIN_LON,
            self._GPS_ORIGIN_ALT,
            0.0, 0.0, 0.0,
        ], dtype=np.float32)

        if self._sim is None or self._sim.mj_model is None or self._sim.mj_data is None:
            return default_gps

        try:
            import mujoco as mj

            model = self._sim.mj_model
            data = self._sim.mj_data

            # Find the robot root body (first body after world body)
            root_body_id = 1  # world body is 0, robot root is typically 1
            # Try named body first
            for name in ["pelvis", "torso_link", "base_link"]:
                bid = mj.mj_name2id(model, mj.mjtObj.mjOBJ_BODY, name)
                if bid > 0:
                    root_body_id = bid
                    break

            # Ensure kinematics are up-to-date
            mj.mj_forward(model, data)

            # Position in MuJoCo world frame
            pos = data.xpos[root_body_id].copy()  # (x, y, z) meters
            rot = data.xmat[root_body_id].reshape(3, 3).copy()

            # Convert position → lat/lon/alt
            latitude = self._GPS_ORIGIN_LAT + pos[0] / self._METERS_PER_DEG_LAT
            longitude = self._GPS_ORIGIN_LON + pos[1] / self._METERS_PER_DEG_LON
            altitude = self._GPS_ORIGIN_ALT + pos[2]

            # Extract heading/pitch/roll from rotation matrix
            # Heading = yaw (rotation around z-axis), measured from north (y-axis in world)
            heading = math.degrees(math.atan2(rot[1, 0], rot[0, 0])) % 360.0

            # Pitch = rotation around y-axis
            pitch = math.degrees(math.asin(np.clip(-rot[2, 0], -1.0, 1.0)))

            # Roll = rotation around x-axis
            roll = math.degrees(math.atan2(rot[2, 1], rot[2, 2]))

            return np.array([latitude, longitude, altitude, heading, pitch, roll], dtype=np.float32)

        except ImportError:
            return default_gps
        except Exception as e:
            logger.warning(f"GPS simulation failed: {e}")
            return default_gps

    def get_joint_positions(self, mode: str = "sonic") -> np.ndarray:
        """Get joint positions in SONIC ordering."""
        obs = self.get_observation()
        jp = obs.get("joint_pos", np.zeros(29, dtype=np.float32))
        if mode == "sonic":
            return jp[:29]
        return jp

    def close(self):
        """Clean up resources."""
        if self._recorder:
            self._recorder.stop()
        if self._v3_writer:
            self.save_v3_recording()
        if self._sim:
            self._sim_action("destroy")
        if self._newton:
            self._newton.destroy()
        logger.info("NeonSimEnv closed")

    def save_dataset(self):
        """Stop recording and save/push the dataset."""
        if self._recorder:
            self._recorder.stop()

    # =========================================================================
    # LeRobot v3 Direct Recording
    # =========================================================================

    def start_v3_recording(
        self,
        repo_id: str,
        task: str = "",
        fps: int = None,
        source: str = "sim",
        include_lidar: bool = True,
        include_audio: bool = False,
        push_to_hub: bool = True,
    ):
        """Start recording directly to LeRobot v3 format via NeonLeRobotWriter.

        This is the recommended recording path for sim data. It bypasses
        StreamRecorder and writes directly to LeRobot v3 format with all
        Neon modalities (vision, joints, LiDAR, EEF, audio).

        Args:
            repo_id: HuggingFace dataset ID (e.g. "cagataydev/neon-g1-sim-v1")
            task: Default task description for all frames
            fps: Recording FPS (default: self.config.fps)
            source: Data source tag ("sim" or "real")
            include_lidar: Include LiDAR modality
            include_audio: Include audio modality (for synthetic TTS)
            push_to_hub: Push to HF Hub when done

        Example:
            env = NeonSimEnv()
            env.start_v3_recording("cagataydev/neon-g1-kitchen-sim", task="pick up red cup")
            env.reset(task="pick up red cup")
            for _ in range(100):
                action = policy(env.get_observation())
                env.step(action)
            env.end_v3_episode()
            env.save_v3_recording()
        """
        from neon.data.lerobot_v3 import NeonLeRobotWriter, NeonWriterConfig, make_neon_features

        effective_fps = fps or self.config.fps
        sim_engine = "newton" if self.config.backend == "newton" else "mujoco"

        features = make_neon_features(
            image_height=self.config.camera.height,
            image_width=self.config.camera.width,
            include_hand_camera=False,  # Sim typically has one camera
            include_lidar=include_lidar and self.config.lidar.enabled,
            include_audio=include_audio,
            include_eef=True,
        )

        writer_config = NeonWriterConfig(
            repo_id=repo_id,
            fps=effective_fps,
            features=features,
            source=source,
            sim_engine=sim_engine,
            push_to_hub=push_to_hub,
        )

        self._v3_writer = NeonLeRobotWriter(writer_config)
        self._v3_writer.open()
        self._v3_task = task
        self._v3_writer.start_episode(task=task)

        logger.info(f"V3 recording started: {repo_id} @ {effective_fps}fps (sim={sim_engine})")

    def record_v3_frame(self, obs: Dict[str, Any], action: np.ndarray = None):
        """Record a single frame to the v3 writer.

        Called automatically by step() if v3 writer is active,
        or can be called manually for custom recording logic.

        Args:
            obs: Observation dict from get_observation()
            action: Action array (joint targets)
        """
        if self._v3_writer is None:
            return

        # Build frame kwargs
        kwargs = {}

        # Image
        if "image_head" in obs:
            kwargs["image_head"] = obs["image_head"]

        # Joint state — pad to 43-DoF (29 body + 14 hand zeros)
        if "joint_pos" in obs:
            jp = obs["joint_pos"]
            state = np.zeros(43, dtype=np.float32)
            state[:len(jp)] = jp
            kwargs["state"] = state

        # EEF state (bimanual: left 7 + right 7 = 14)
        eef_left = obs.get("eef_left", np.zeros(7, dtype=np.float32))
        eef_right = obs.get("eef_right", np.zeros(7, dtype=np.float32))
        kwargs["eef_state"] = np.concatenate([eef_left, eef_right]).astype(np.float32)

        # LiDAR
        if "lidar" in obs and len(obs["lidar"]) > 0:
            kwargs["lidar"] = obs["lidar"]

        # Action (from last step, since obs is post-step)
        if action is not None:
            kwargs["action"] = action
        elif self._last_action is not None:
            kwargs["action"] = self._last_action

        # Language
        kwargs["language"] = self._v3_task

        try:
            self._v3_writer.add_frame(**kwargs)
        except Exception as e:
            logger.warning(f"V3 frame recording failed: {e}")

    def end_v3_episode(self):
        """End the current v3 recording episode."""
        if self._v3_writer:
            self._v3_writer.end_episode()

    def start_v3_episode(self, task: str = ""):
        """Start a new v3 recording episode."""
        if self._v3_writer:
            self._v3_task = task or self._v3_task
            self._v3_writer.start_episode(task=self._v3_task)

    def save_v3_recording(self):
        """Finalize and optionally push the v3 dataset."""
        if self._v3_writer:
            self._v3_writer.save_and_push()
            logger.info("V3 recording saved and pushed")
            self._v3_writer = None

    def new_episode(self, task: str = ""):
        """Start a new recording episode without resetting physics."""
        if self._recorder:
            self._recorder.new_episode(task=task)
        if task and self._channels_initialized:
            self._text_channel.push_text(task, role="user")

    # =========================================================================
    # Teleop helpers
    # =========================================================================

    def get_action_from_keyboard(self, key_states: Dict[str, bool]) -> Optional[np.ndarray]:
        """Convert keyboard inputs to joint delta actions.

        W/S: left shoulder pitch, A/D: left shoulder roll
        I/K: right shoulder pitch, J/L: right shoulder roll
        Q/E: waist yaw
        """
        delta = np.zeros(29, dtype=np.float32)
        step = 0.05

        if key_states.get("w"): delta[15] -= step
        if key_states.get("s"): delta[15] += step
        if key_states.get("a"): delta[16] -= step
        if key_states.get("d"): delta[16] += step
        if key_states.get("i"): delta[22] -= step
        if key_states.get("k"): delta[22] += step
        if key_states.get("j"): delta[23] -= step
        if key_states.get("l"): delta[23] += step
        if key_states.get("q"): delta[12] -= step
        if key_states.get("e"): delta[12] += step

        if np.any(delta != 0):
            current = self.get_joint_positions("sonic")
            return current + delta
        return None

    # =========================================================================
    # strands-robots integration helpers
    # =========================================================================

    def run_policy(self, instruction: str = "", duration: float = 10.0, provider: str = "neon"):
        """Run a strands-robots policy on the simulated G1.

        Args:
            instruction: Task instruction for VLA
            duration: Duration in seconds
            provider: Policy provider ("neon", "groot", "mock", etc.)
        """
        if self._sim:
            self._sim_action(
                "run_policy",
                robot_name="g1",
                policy_provider=provider,
                instruction=instruction,
                duration=duration,
            )

    def domain_randomize(self, **kwargs):
        """Apply domain randomization via strands-robots."""
        if self._sim:
            self._sim_action("randomize", **kwargs)

    @property
    def objects_in_scene(self) -> List:
        return self._scene_objects

    @property
    def sim_time(self) -> float:
        return self._step_count * self.config.control_dt

    @property
    def num_steps(self) -> int:
        return self._step_count

    @property
    def simulation(self):
        """Direct access to the underlying strands_robots.Simulation."""
        return self._sim

    @property
    def newton_backend(self):
        """Direct access to the Newton GPU backend (if using newton)."""
        return self._newton


# =============================================================================
# Utility
# =============================================================================


def _rotmat_to_quat(R: np.ndarray) -> np.ndarray:
    """Convert 3x3 rotation matrix to quaternion [w, x, y, z]."""
    trace = R[0, 0] + R[1, 1] + R[2, 2]
    if trace > 0:
        s = 0.5 / math.sqrt(trace + 1.0)
        w = 0.25 / s
        x = (R[2, 1] - R[1, 2]) * s
        y = (R[0, 2] - R[2, 0]) * s
        z = (R[1, 0] - R[0, 1]) * s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = 2.0 * math.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
        w = (R[2, 1] - R[1, 2]) / s
        x = 0.25 * s
        y = (R[0, 1] + R[1, 0]) / s
        z = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = 2.0 * math.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
        w = (R[0, 2] - R[2, 0]) / s
        x = (R[0, 1] + R[1, 0]) / s
        y = 0.25 * s
        z = (R[1, 2] + R[2, 1]) / s
    else:
        s = 2.0 * math.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
        w = (R[1, 0] - R[0, 1]) / s
        x = (R[0, 2] + R[2, 0]) / s
        y = (R[1, 2] + R[2, 1]) / s
        z = 0.25 * s
    return np.array([w, x, y, z], dtype=np.float32)


def synthesize_audio_from_text(
    text: str,
    duration: float = 2.0,
    sample_rate: int = 16000,
) -> np.ndarray:
    """Synthesize a simple audio waveform from text for sim training data.

    For sim→real transfer, the audio encoder needs training data. This
    generates a deterministic pseudo-speech signal from the text string,
    so the same instruction always produces the same audio pattern.

    The signal is NOT real speech — it's a hash-based frequency pattern
    that gives the audio encoder a consistent signal to learn from.
    For real speech data, use actual TTS (e.g., PersonaPlex) on the real robot.

    Args:
        text: Instruction text (determines frequency pattern)
        duration: Audio duration in seconds
        sample_rate: Sample rate (16kHz matches Whisper input)

    Returns:
        (N,) float32 array with N = duration * sample_rate
    """
    n_samples = int(duration * sample_rate)

    if not text:
        return np.zeros(n_samples, dtype=np.float32)

    # Generate deterministic frequencies from text hash
    text_hash = hash(text) & 0xFFFFFFFF
    rng = np.random.RandomState(text_hash)

    # Create 3-5 frequency components (pseudo-formants)
    n_components = 3 + (text_hash % 3)
    t = np.linspace(0, duration, n_samples, dtype=np.float32)
    signal = np.zeros(n_samples, dtype=np.float32)

    for i in range(n_components):
        freq = 100 + rng.randint(50, 400)  # 100-500 Hz (speech range)
        amp = 0.1 + 0.2 * rng.random()
        phase = rng.random() * 2 * np.pi
        signal += amp * np.sin(2 * np.pi * freq * t + phase).astype(np.float32)

    # Apply envelope (fade in/out like a spoken sentence)
    envelope = np.ones(n_samples, dtype=np.float32)
    fade_samples = min(int(0.1 * sample_rate), n_samples // 4)
    if fade_samples > 0:
        envelope[:fade_samples] = np.linspace(0, 1, fade_samples)
        envelope[-fade_samples:] = np.linspace(1, 0, fade_samples)
    signal *= envelope

    # Normalize to [-0.5, 0.5] range
    max_val = np.abs(signal).max()
    if max_val > 0:
        signal = signal / max_val * 0.5

    return signal
