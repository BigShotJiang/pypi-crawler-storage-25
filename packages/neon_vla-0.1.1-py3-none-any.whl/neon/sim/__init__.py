"""
Neon Sim — Self-contained simulation stack for G1 dataset generation.

Three backends:
- MuJoCo via neon.sim.simulation.Simulation (default, CPU)
- Newton GPU via neon.sim.newton.NewtonBackend (4096+ parallel envs)
- Isaac Sim via neon.sim.isaac.IsaacSimBackend (photorealistic)

Neon layers on top: raycast LiDAR, EEF tracking, LeRobot v3 export.

Ported from strands-robots (private) to be self-contained in Neon.
"""

from neon.sim.env import CameraConfig, LidarConfig, NeonSimConfig, NeonSimEnv
from neon.sim.scene import SceneBuilder, SceneConfig
from neon.sim.morphology import (
    GULAMANNEN_CONFIGS,
    MorphologyConfig,
    MorphologyExplorer,
    morphology_to_action_space,
    get_embodiment_id,
    register_gulamannen_urdfs,
)

__all__ = [
    # High-level env
    "NeonSimEnv",
    "NeonSimConfig",
    "LidarConfig",
    "CameraConfig",
    # Scene
    "SceneBuilder",
    "SceneConfig",
    # Morphology (adapted from GulaMannen)
    "GULAMANNEN_CONFIGS",
    "MorphologyConfig",
    "MorphologyExplorer",
    "morphology_to_action_space",
    "get_embodiment_id",
    "register_gulamannen_urdfs",
    # Backends (lazy import)
    # from neon.sim.simulation import Simulation
    # from neon.sim.newton import NewtonBackend, NewtonConfig
    # from neon.sim.isaac import IsaacSimBackend, IsaacSimConfig
]
