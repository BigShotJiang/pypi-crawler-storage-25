"""Stub for asset downloading — not yet implemented in Neon standalone."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def download_robots(*args, **kwargs):
    """Placeholder for robot model download.

    In strands-robots this downloads from HuggingFace Hub.
    For Neon, users should manually place URDFs in ~/.neon/urdfs/
    """
    logger.warning(
        "Robot download not yet available in Neon standalone. "
        "Place URDF files in ~/.neon/urdfs/ or install strands-robots."
    )
    return None
