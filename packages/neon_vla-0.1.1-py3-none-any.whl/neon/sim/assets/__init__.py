"""
neon.sim.assets — Robot model resolution with auto-download from MuJoCo Menagerie.

Resolution priority:
1. User-specified STRANDS_URDF_DIR
2. ~/.neon/urdfs/ (auto-downloaded from Menagerie)
3. Standard search paths

Auto-downloads Unitree G1 (29-DoF) MJCF + STL meshes from
google-deepmind/mujoco_menagerie on first use.
"""

from __future__ import annotations

import logging
import os
import re
import urllib.request
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)

# Standard search paths (in priority order)
_SEARCH_PATHS = [
    Path.home() / ".neon" / "urdfs",
    Path.home() / ".strands_robots" / "urdfs",
    Path("/opt/strands_robots/urdfs"),
]

# Override from env
_env_dir = os.getenv("STRANDS_URDF_DIR")
if _env_dir:
    _SEARCH_PATHS.insert(0, Path(_env_dir))

_HAS_ASSET_MANAGER = True  # We ARE the asset manager now

# MuJoCo Menagerie GitHub base URL
_MENAGERIE_BASE = "https://raw.githubusercontent.com/google-deepmind/mujoco_menagerie/main"

# Robot aliases → Menagerie directory names
_MENAGERIE_ROBOTS: Dict[str, str] = {
    "unitree_g1": "unitree_g1",
    "unitree_g1_locomanip": "unitree_g1",
    "unitree_h1": "unitree_h1",
    "unitree_go2": "unitree_go2",
    "franka": "franka_emika_panda",
    "panda": "franka_emika_panda",
    "bimanual_panda_gripper": "franka_emika_panda",
    "kuka": "kuka_iiwa_14",
    "ur5e": "universal_robots_ur5e",
}


def _download_menagerie_robot(robot_dir: str, dest_base: Path) -> bool:
    """Download a robot from MuJoCo Menagerie.

    Downloads the main XML + scene XML + all referenced mesh assets.

    Args:
        robot_dir: Menagerie directory name (e.g., "unitree_g1")
        dest_base: Base directory to save to (e.g., ~/.neon/urdfs/)

    Returns:
        True if successful
    """
    dest = dest_base / robot_dir
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "assets").mkdir(exist_ok=True)

    base_url = f"{_MENAGERIE_BASE}/{robot_dir}/"

    # Download main XML files
    xml_files = [f"{robot_dir}.xml", "scene.xml"]
    # Some menagerie robots use different naming
    alt_names = [f"{robot_dir.split('_', 1)[-1]}.xml"] if "_" in robot_dir else []
    xml_files.extend(alt_names)

    downloaded_xml = []
    for xml_file in xml_files:
        out = dest / xml_file
        if out.exists() and out.stat().st_size > 100:
            downloaded_xml.append(xml_file)
            continue
        url = base_url + xml_file
        try:
            urllib.request.urlretrieve(url, str(out))
            if out.stat().st_size > 100:
                downloaded_xml.append(xml_file)
                logger.info(f"Downloaded {robot_dir}/{xml_file}")
        except Exception:
            # Try alternate name pattern
            pass

    if not downloaded_xml:
        logger.warning(f"No XML files found for {robot_dir} in Menagerie")
        return False

    # Parse XMLs for required mesh files
    meshes = set()
    for xml_file in downloaded_xml:
        xml_path = dest / xml_file
        if xml_path.exists():
            content = xml_path.read_text(errors="ignore")
            meshes.update(re.findall(r'file="([^"]+)"', content))

    # Download mesh assets
    assets_url = base_url + "assets/"
    for mesh in sorted(meshes):
        out = dest / "assets" / mesh
        if out.exists() and out.stat().st_size > 100:
            continue
        try:
            urllib.request.urlretrieve(assets_url + mesh, str(out))
        except Exception as e:
            logger.debug(f"Mesh download failed: {mesh} — {e}")

    downloaded_meshes = len([f for f in (dest / "assets").iterdir() if f.stat().st_size > 100])
    logger.info(f"Downloaded {robot_dir}: {len(downloaded_xml)} XMLs, {downloaded_meshes}/{len(meshes)} meshes")
    return True


def resolve_model_path(name: str, prefer_scene: bool = True) -> Optional[Path]:
    """Resolve a robot model name to a file path.

    Auto-downloads from MuJoCo Menagerie if not found locally.

    Args:
        name: Robot name or alias (e.g., "unitree_g1", "franka")
        prefer_scene: If True, prefer scene.xml over bare model.xml

    Returns:
        Path to model file, or None if not found
    """
    # Normalize name
    name_lower = name.lower().strip()

    for base in _SEARCH_PATHS:
        subdir = base / name_lower
        if subdir.is_dir():
            # Prefer scene.xml (includes ground plane, lighting)
            if prefer_scene:
                scene = subdir / "scene.xml"
                if scene.exists() and scene.stat().st_size > 100:
                    return scene

            # Try model XML (named after directory)
            for pattern in [f"{name_lower}.xml", "*.xml", f"{name_lower}.urdf", "*.urdf", "*.mjcf"]:
                for f in subdir.glob(pattern):
                    if f.name != "scene.xml" and f.stat().st_size > 100:
                        return f

            # Fallback to scene.xml even if not preferred
            scene = subdir / "scene.xml"
            if scene.exists():
                return scene

        # Try direct file match
        for ext in [".xml", ".urdf", ".mjcf"]:
            candidate = base / f"{name_lower}{ext}"
            if candidate.exists():
                return candidate

    # Not found locally — try auto-download from Menagerie
    menagerie_dir = _MENAGERIE_ROBOTS.get(name_lower)
    if menagerie_dir:
        dest_base = _SEARCH_PATHS[0]  # ~/.neon/urdfs/
        logger.info(f"Auto-downloading {name_lower} from MuJoCo Menagerie...")
        if _download_menagerie_robot(menagerie_dir, dest_base):
            # Retry resolution after download
            return resolve_model_path(name, prefer_scene=prefer_scene)

    return None


def resolve_robot_name(name: str) -> Optional[str]:
    """Alias for resolve_model_path (returns str)."""
    path = resolve_model_path(name)
    return str(path) if path else None


def list_available_robots() -> Dict[str, Optional[str]]:
    """List all available robots (local + downloadable)."""
    robots = {}

    # Local robots
    for base in _SEARCH_PATHS:
        if base.is_dir():
            for subdir in base.iterdir():
                if subdir.is_dir():
                    path = resolve_model_path(subdir.name)
                    robots[subdir.name] = str(path) if path else None

    # Menagerie robots (downloadable)
    for alias, menagerie_name in _MENAGERIE_ROBOTS.items():
        if alias not in robots:
            robots[alias] = f"[downloadable: {menagerie_name}]"

    return robots


def format_robot_table() -> str:
    """Format a human-readable table of available robots."""
    robots = list_available_robots()
    lines = ["Available Robots:"]
    for name, path in sorted(robots.items()):
        status = "✅" if path and not path.startswith("[") else "📥"
        lines.append(f"  {status} {name}: {path}")
    return "\n".join(lines)
