"""
Stub for neon.sim.policies — policy provider interface.

In strands-robots this provides a Policy ABC and create_policy() factory.
For Neon standalone, we provide the NeonPolicy directly from neon.policy.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


def create_policy(provider: str = "neon", **kwargs) -> Any:
    """Create a policy provider instance.

    Args:
        provider: Policy provider name ("neon", "mock", etc.)
        **kwargs: Provider-specific config (host, port, etc.)

    Returns:
        Policy instance.
    """
    if provider == "neon":
        try:
            from neon.policy import NeonPolicy
            return NeonPolicy(**kwargs)
        except ImportError:
            raise ImportError("NeonPolicy requires neon.policy module")

    elif provider == "mock":
        return _MockPolicy(**kwargs)

    else:
        raise ValueError(
            f"Unknown policy provider: {provider}. "
            f"Available: 'neon', 'mock'. "
            f"For more providers, install strands-robots."
        )


class _MockPolicy:
    """Simple mock policy for testing."""

    def __init__(self, num_dof: int = 29, **kwargs):
        self.num_dof = num_dof

    async def get_actions(self, observation_dict: Dict, instruction: str, **kwargs) -> List[Dict]:
        import numpy as np
        return [{"joint_positions": np.zeros(self.num_dof).tolist()}]

    def get_actions_sync(self, observation_dict: Dict, instruction: str, **kwargs) -> List[Dict]:
        import asyncio
        return asyncio.run(self.get_actions(observation_dict, instruction, **kwargs))

    @property
    def provider_name(self) -> str:
        return "mock"

    def set_robot_state_keys(self, keys: List[str]) -> None:
        pass
