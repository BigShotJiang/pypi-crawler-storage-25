"""
Modular Humanoid Morphology System — adapted from GulaMannen.

Source: https://github.com/mehrdad-Farimani/gulamannen-reference-humanoids
Adapted for Neon's multi-embodiment VLA pipeline.

Core idea from GulaMannen: Instead of hardcoding one humanoid body plan,
define morphology as a composition of swappable subsystems. This lets you:
1. Explore proportions BEFORE committing to hardware
2. Share upper-body architecture across different base configs
3. Parametrize joint types (serial vs parallel wrist/ankle)
4. Generate URDF/MJCF procedurally for sim evaluation

Why this matters for Neon:
- Neon already has CategorySpecificLinear for per-embodiment weights
- GulaMannen gives us STRUCTURED morphology variation (not just "robot A vs B")
- Same VLA model can generalize across 6 GulaMannen configs via embodiment_id
- Simulation-first morphology search → find optimal body for each task

The 6 GulaMannen Configurations:
1. Series Biped — 30 DoF, fully articulated (baseline)
2. Parallel Joints Biped — intersecting rotational axes at wrist/ankle
3. Pedestal Hybrid — upper body on fixed pedestal (manipulation focus)
4. Vertical Actuator Hybrid — upper body on adjustable column
5. Single-Leg Hybrid — minimal lower body (3-DoF positioning)
6. Linear Rail Tower — upper body on vertical rail elevator

Reference:
    Farimani, M. "GulaMannen: Modular Humanoid Reference Platform" (2025)
    https://github.com/mehrdad-Farimani/gulamannen-reference-humanoids
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


# =============================================================================
# Actuator Classes — from GulaMannen
# =============================================================================
# GulaMannen uses 3 placeholder actuator classes inspired by QDD harmonic drive
# actuators. These are simulation-level estimates; replace with real specs
# for production hardware.

@dataclass
class ActuatorSpec:
    """Actuator specification for simulation-level morphology exploration.

    Based on commercially available QDD harmonic drive actuators.
    From GulaMannen: three size classes cover typical humanoid joints.
    """

    name: str
    peak_torque_nm: float  # Peak torque in Nm
    mass_kg: float  # Approximate mass in kg
    typical_usage: List[str]  # Which joints typically use this class
    # Extended specs for Neon's PD control pipeline
    kp_default: float = 100.0  # Default proportional gain
    kd_default: float = 2.0  # Default derivative gain
    vel_limit_rad_s: float = 37.0  # Max velocity (rad/s)
    gear_ratio: float = 1.0  # Gear reduction ratio
    rotor_inertia: float = 0.0  # Reflected rotor inertia (kg·m²)


# Three canonical actuator classes from GulaMannen
ACTUATOR_SMALL = ActuatorSpec(
    name="small",
    peak_torque_nm=40.0,
    mass_kg=0.8,
    typical_usage=["wrist", "neck"],
    kp_default=20.0,
    kd_default=2.0,
    vel_limit_rad_s=37.0,
)

ACTUATOR_MEDIUM = ActuatorSpec(
    name="medium",
    peak_torque_nm=120.0,
    mass_kg=1.9,
    typical_usage=["elbow", "ankle"],
    kp_default=40.0,
    kd_default=2.0,
    vel_limit_rad_s=32.0,
)

ACTUATOR_LARGE = ActuatorSpec(
    name="large",
    peak_torque_nm=280.0,
    mass_kg=3.8,
    typical_usage=["hip", "knee", "shoulder"],
    kp_default=200.0,
    kd_default=4.0,
    vel_limit_rad_s=20.0,
)

ACTUATOR_CLASSES = {
    "small": ACTUATOR_SMALL,
    "medium": ACTUATOR_MEDIUM,
    "large": ACTUATOR_LARGE,
}


# =============================================================================
# Joint Architecture Types — from GulaMannen modular design
# =============================================================================

class JointArchitecture(Enum):
    """Joint architecture variants for wrist and ankle.

    GulaMannen provides both serial and parallel joint configurations
    as interchangeable modules. This affects:
    - Workspace (serial = larger, parallel = more compact)
    - Stiffness (parallel generally stiffer)
    - Control complexity (parallel requires coupled control)
    """

    SERIAL = "serial"
    PARALLEL = "parallel"  # Intersecting rotational axes


class HipArchitecture(Enum):
    """Hip architecture variants.

    GulaMannen provides horizontal and 25° angled PRY-based hip variants.
    Angled hip improves walking gait stability.
    """

    HORIZONTAL = "horizontal"  # Standard PRY hip
    ANGLED_25 = "angled_25"  # 25° angled PRY (better walking dynamics)


class BaseConfiguration(Enum):
    """Base/lower-body configuration types from GulaMannen.

    The upper body is shared; only the base changes.
    This maps directly to Neon's embodiment_id system.
    """

    FULL_BIPED = "full_biped"  # Config 1/2: Walking humanoid
    PEDESTAL = "pedestal"  # Config 3: Fixed-height mount
    VERTICAL_ACTUATOR = "vertical_actuator"  # Config 4: Adjustable column
    SINGLE_LEG = "single_leg"  # Config 5: Minimal 3-DoF lower body
    LINEAR_RAIL = "linear_rail"  # Config 6: Vertical rail elevator
    MOBILE_BASE = "mobile_base"  # Extension: wheeled base


# =============================================================================
# Subsystem Specifications
# =============================================================================

@dataclass
class SubsystemSpec:
    """Specification for a modular subsystem (arm, leg, torso, etc.).

    Each subsystem has a defined DoF count, actuator assignments,
    and joint limits. Subsystems are composable into full morphologies.
    """

    name: str
    dof: int
    joint_names: List[str]
    actuator_classes: List[str]  # Maps to ACTUATOR_CLASSES keys
    joint_limits_lower: List[float]  # Radians
    joint_limits_upper: List[float]  # Radians
    default_positions: List[float]  # Default standing pose (radians)
    # Optional: architecture variant
    architecture: Optional[str] = None  # "serial", "parallel", etc.


# Standard subsystem library from GulaMannen
SUBSYSTEMS: Dict[str, SubsystemSpec] = {
    "neck": SubsystemSpec(
        name="neck",
        dof=2,
        joint_names=["neck_pitch", "neck_yaw"],
        actuator_classes=["small", "small"],
        joint_limits_lower=[-0.5, -1.0],
        joint_limits_upper=[0.5, 1.0],
        default_positions=[0.0, 0.0],
    ),
    "shoulder_serial": SubsystemSpec(
        name="shoulder",
        dof=3,
        joint_names=["shoulder_pitch", "shoulder_roll", "shoulder_yaw"],
        actuator_classes=["large", "large", "large"],
        joint_limits_lower=[-3.09, -1.59, -2.62],
        joint_limits_upper=[2.67, 2.25, 2.62],
        default_positions=[0.0, 0.0, 0.0],
        architecture="serial",
    ),
    "elbow": SubsystemSpec(
        name="elbow",
        dof=1,
        joint_names=["elbow"],
        actuator_classes=["medium"],
        joint_limits_lower=[-1.05],
        joint_limits_upper=[2.09],
        default_positions=[0.0],
    ),
    "wrist_serial": SubsystemSpec(
        name="wrist",
        dof=3,
        joint_names=["wrist_roll", "wrist_pitch", "wrist_yaw"],
        actuator_classes=["small", "small", "small"],
        joint_limits_lower=[-1.97, -1.61, -1.61],
        joint_limits_upper=[1.97, 1.61, 1.61],
        default_positions=[0.0, 0.0, 0.0],
        architecture="serial",
    ),
    "wrist_parallel": SubsystemSpec(
        name="wrist",
        dof=3,
        joint_names=["wrist_roll", "wrist_pitch", "wrist_yaw"],
        actuator_classes=["small", "small", "small"],
        joint_limits_lower=[-1.5, -1.2, -1.2],
        joint_limits_upper=[1.5, 1.2, 1.2],
        default_positions=[0.0, 0.0, 0.0],
        architecture="parallel",
    ),
    "torso": SubsystemSpec(
        name="torso",
        dof=2,
        joint_names=["waist_yaw", "waist_roll"],
        actuator_classes=["large", "large"],
        joint_limits_lower=[-2.62, -0.52],
        joint_limits_upper=[2.62, 0.52],
        default_positions=[0.0, 0.0],
    ),
    "hip_horizontal": SubsystemSpec(
        name="hip",
        dof=3,
        joint_names=["hip_pitch", "hip_roll", "hip_yaw"],
        actuator_classes=["large", "large", "large"],
        joint_limits_lower=[-2.53, -0.52, -2.76],
        joint_limits_upper=[2.88, 2.97, 2.76],
        default_positions=[-0.1, 0.0, 0.0],
        architecture="horizontal",
    ),
    "hip_angled_25": SubsystemSpec(
        name="hip",
        dof=3,
        joint_names=["hip_pitch", "hip_roll", "hip_yaw"],
        actuator_classes=["large", "large", "large"],
        joint_limits_lower=[-2.53, -0.52, -2.76],
        joint_limits_upper=[2.88, 2.97, 2.76],
        default_positions=[-0.15, 0.0, 0.0],
        architecture="angled_25",
    ),
    "knee": SubsystemSpec(
        name="knee",
        dof=1,
        joint_names=["knee"],
        actuator_classes=["large"],
        joint_limits_lower=[-0.09],
        joint_limits_upper=[2.88],
        default_positions=[0.3],
    ),
    "ankle_serial": SubsystemSpec(
        name="ankle",
        dof=2,
        joint_names=["ankle_pitch", "ankle_roll"],
        actuator_classes=["medium", "medium"],
        joint_limits_lower=[-0.87, -0.26],
        joint_limits_upper=[0.52, 0.26],
        default_positions=[-0.2, 0.0],
        architecture="serial",
    ),
    "ankle_parallel": SubsystemSpec(
        name="ankle",
        dof=2,
        joint_names=["ankle_pitch", "ankle_roll"],
        actuator_classes=["medium", "medium"],
        joint_limits_lower=[-0.7, -0.2],
        joint_limits_upper=[0.4, 0.2],
        default_positions=[-0.2, 0.0],
        architecture="parallel",
    ),
    # Minimal lower body for Config 5
    "positioning_3dof": SubsystemSpec(
        name="positioning",
        dof=3,
        joint_names=["pos_x", "pos_y", "pos_z"],
        actuator_classes=["large", "large", "large"],
        joint_limits_lower=[-0.5, -0.5, 0.0],
        joint_limits_upper=[0.5, 0.5, 1.0],
        default_positions=[0.0, 0.0, 0.5],
    ),
    # Vertical actuator for Config 4
    "vertical_column": SubsystemSpec(
        name="vertical_actuator",
        dof=1,
        joint_names=["column_height"],
        actuator_classes=["large"],
        joint_limits_lower=[0.0],
        joint_limits_upper=[1.0],  # 0-1m travel
        default_positions=[0.5],
    ),
    # Linear rail for Config 6
    "vertical_rail": SubsystemSpec(
        name="linear_rail",
        dof=1,
        joint_names=["rail_height"],
        actuator_classes=["large"],
        joint_limits_lower=[0.0],
        joint_limits_upper=[1.8],  # Full height range
        default_positions=[0.9],
    ),
}


# =============================================================================
# Morphology Configuration — Composable Body Plans
# =============================================================================

@dataclass
class MorphologyConfig:
    """Complete humanoid morphology specification.

    Composes subsystems into a full body plan. Each configuration from
    GulaMannen is a different MorphologyConfig.

    The key insight: Neon's embodiment_id maps 1:1 to MorphologyConfig.
    Train one VLA with CategorySpecificLinear → each GulaMannen config
    gets its own action head weights, but shares the vision backbone.

    This enables:
    - Sim-first morphology search (try all 6 configs, find best for task)
    - Cross-morphology transfer (biped knowledge helps pedestal manipulation)
    - Progressive complexity (start with pedestal, graduate to full biped)
    """

    name: str
    description: str
    embodiment_id: int  # Maps to CategorySpecificLinear cat_id
    height_mm: Tuple[int, int]  # (min, max) height range
    approx_mass_kg: float
    base_config: BaseConfiguration
    foot_size_mm: Optional[Tuple[int, int]] = None  # (length, width)

    # Subsystem composition
    neck: str = "neck"  # Key into SUBSYSTEMS
    left_shoulder: str = "shoulder_serial"
    right_shoulder: str = "shoulder_serial"
    left_elbow: str = "elbow"
    right_elbow: str = "elbow"
    left_wrist: str = "wrist_serial"
    right_wrist: str = "wrist_serial"
    torso: str = "torso"
    left_hip: Optional[str] = "hip_horizontal"
    right_hip: Optional[str] = "hip_horizontal"
    left_knee: Optional[str] = "knee"
    right_knee: Optional[str] = "knee"
    left_ankle: Optional[str] = "ankle_serial"
    right_ankle: Optional[str] = "ankle_serial"
    base_subsystem: Optional[str] = None  # For non-biped configs

    @property
    def total_dof(self) -> int:
        """Calculate total degrees of freedom from subsystem composition."""
        dof = 0
        subsystem_keys = [
            self.neck, self.left_shoulder, self.right_shoulder,
            self.left_elbow, self.right_elbow,
            self.left_wrist, self.right_wrist,
            self.torso,
        ]
        # Lower body (optional per config)
        for key in [self.left_hip, self.right_hip,
                     self.left_knee, self.right_knee,
                     self.left_ankle, self.right_ankle]:
            if key:
                subsystem_keys.append(key)
        if self.base_subsystem:
            subsystem_keys.append(self.base_subsystem)

        for key in subsystem_keys:
            if key and key in SUBSYSTEMS:
                dof += SUBSYSTEMS[key].dof
        return dof

    def get_all_joints(self) -> List[str]:
        """Get ordered list of all joint names with L/R prefixing."""
        joints = []

        def _add_subsystem(prefix: str, key: Optional[str]):
            if key and key in SUBSYSTEMS:
                sub = SUBSYSTEMS[key]
                for jn in sub.joint_names:
                    joints.append(f"{prefix}_{jn}" if prefix else jn)

        # Neck (no prefix)
        _add_subsystem("", self.neck)
        # Torso (no prefix)
        _add_subsystem("", self.torso)
        # Left arm chain
        _add_subsystem("left", self.left_shoulder)
        _add_subsystem("left", self.left_elbow)
        _add_subsystem("left", self.left_wrist)
        # Right arm chain
        _add_subsystem("right", self.right_shoulder)
        _add_subsystem("right", self.right_elbow)
        _add_subsystem("right", self.right_wrist)
        # Left leg chain (optional)
        _add_subsystem("left", self.left_hip)
        _add_subsystem("left", self.left_knee)
        _add_subsystem("left", self.left_ankle)
        # Right leg chain (optional)
        _add_subsystem("right", self.right_hip)
        _add_subsystem("right", self.right_knee)
        _add_subsystem("right", self.right_ankle)
        # Base subsystem (optional)
        _add_subsystem("", self.base_subsystem)

        return joints

    def get_actuator_mass(self) -> float:
        """Estimate total actuator mass from subsystem specs."""
        total = 0.0
        for key in [self.neck, self.left_shoulder, self.right_shoulder,
                     self.left_elbow, self.right_elbow,
                     self.left_wrist, self.right_wrist,
                     self.torso, self.left_hip, self.right_hip,
                     self.left_knee, self.right_knee,
                     self.left_ankle, self.right_ankle,
                     self.base_subsystem]:
            if key and key in SUBSYSTEMS:
                sub = SUBSYSTEMS[key]
                for ac_class in sub.actuator_classes:
                    if ac_class in ACTUATOR_CLASSES:
                        total += ACTUATOR_CLASSES[ac_class].mass_kg
        return total

    def get_default_positions(self) -> np.ndarray:
        """Get default standing positions for all joints."""
        positions = []
        subsystem_order = [
            self.neck, self.torso,
            self.left_shoulder, self.left_elbow, self.left_wrist,
            self.right_shoulder, self.right_elbow, self.right_wrist,
            self.left_hip, self.left_knee, self.left_ankle,
            self.right_hip, self.right_knee, self.right_ankle,
            self.base_subsystem,
        ]
        for key in subsystem_order:
            if key and key in SUBSYSTEMS:
                positions.extend(SUBSYSTEMS[key].default_positions)
        return np.array(positions, dtype=np.float32)

    def get_joint_limits(self) -> Tuple[np.ndarray, np.ndarray]:
        """Get (lower, upper) joint limits for all joints."""
        lower, upper = [], []
        subsystem_order = [
            self.neck, self.torso,
            self.left_shoulder, self.left_elbow, self.left_wrist,
            self.right_shoulder, self.right_elbow, self.right_wrist,
            self.left_hip, self.left_knee, self.left_ankle,
            self.right_hip, self.right_knee, self.right_ankle,
            self.base_subsystem,
        ]
        for key in subsystem_order:
            if key and key in SUBSYSTEMS:
                sub = SUBSYSTEMS[key]
                lower.extend(sub.joint_limits_lower)
                upper.extend(sub.joint_limits_upper)
        return np.array(lower, dtype=np.float32), np.array(upper, dtype=np.float32)

    def to_dict(self) -> Dict:
        """Serialize for config files and training."""
        return {
            "name": self.name,
            "embodiment_id": self.embodiment_id,
            "total_dof": self.total_dof,
            "base_config": self.base_config.value,
            "height_mm": list(self.height_mm),
            "approx_mass_kg": self.approx_mass_kg,
            "joints": self.get_all_joints(),
            "default_positions": self.get_default_positions().tolist(),
        }


# =============================================================================
# The 6 GulaMannen Reference Configurations
# =============================================================================

GULAMANNEN_CONFIGS: Dict[str, MorphologyConfig] = {
    # Config 1: Series Biped — canonical baseline
    "series_biped": MorphologyConfig(
        name="series_biped",
        description="Fully articulated biped with serial actuators. Canonical baseline.",
        embodiment_id=10,  # 0-9 reserved for existing Neon embodiments
        height_mm=(900, 1800),
        approx_mass_kg=62.0,
        base_config=BaseConfiguration.FULL_BIPED,
        foot_size_mm=(280, 110),
        left_wrist="wrist_serial",
        right_wrist="wrist_serial",
        left_ankle="ankle_serial",
        right_ankle="ankle_serial",
    ),
    # Config 2: Parallel Joints Biped
    "parallel_biped": MorphologyConfig(
        name="parallel_biped",
        description="Biped with intersecting rotational axes at wrist and ankle.",
        embodiment_id=11,
        height_mm=(900, 1800),
        approx_mass_kg=62.0,
        base_config=BaseConfiguration.FULL_BIPED,
        foot_size_mm=(280, 110),
        left_wrist="wrist_parallel",
        right_wrist="wrist_parallel",
        left_ankle="ankle_parallel",
        right_ankle="ankle_parallel",
    ),
    # Config 3: Pedestal Hybrid
    "pedestal_hybrid": MorphologyConfig(
        name="pedestal_hybrid",
        description="Upper body on fixed-height pedestal. Manipulation research.",
        embodiment_id=12,
        height_mm=(1200, 1200),  # Fixed height
        approx_mass_kg=35.0,
        base_config=BaseConfiguration.PEDESTAL,
        left_hip=None, right_hip=None,
        left_knee=None, right_knee=None,
        left_ankle=None, right_ankle=None,
    ),
    # Config 4: Vertical Actuator Hybrid
    "vertical_actuator_hybrid": MorphologyConfig(
        name="vertical_actuator_hybrid",
        description="Upper body on vertically adjustable column.",
        embodiment_id=13,
        height_mm=(900, 1800),
        approx_mass_kg=38.0,
        base_config=BaseConfiguration.VERTICAL_ACTUATOR,
        left_hip=None, right_hip=None,
        left_knee=None, right_knee=None,
        left_ankle=None, right_ankle=None,
        base_subsystem="vertical_column",
    ),
    # Config 5: Single-Leg Hybrid
    "single_leg_hybrid": MorphologyConfig(
        name="single_leg_hybrid",
        description="Minimal lower body with 3-DoF positioning.",
        embodiment_id=14,
        height_mm=(900, 1500),
        approx_mass_kg=40.0,
        base_config=BaseConfiguration.SINGLE_LEG,
        left_hip=None, right_hip=None,
        left_knee=None, right_knee=None,
        left_ankle=None, right_ankle=None,
        base_subsystem="positioning_3dof",
    ),
    # Config 6: Linear Rail Tower
    "linear_rail_tower": MorphologyConfig(
        name="linear_rail_tower",
        description="Upper body on vertical rail elevator. Indoor service.",
        embodiment_id=15,
        height_mm=(0, 1800),  # Full range
        approx_mass_kg=42.0,
        base_config=BaseConfiguration.LINEAR_RAIL,
        left_hip=None, right_hip=None,
        left_knee=None, right_knee=None,
        left_ankle=None, right_ankle=None,
        base_subsystem="vertical_rail",
    ),
}


# =============================================================================
# Morphology Search — find the best body for a given task
# =============================================================================

class MorphologyExplorer:
    """Explore and compare morphology configurations for task suitability.

    Given a task description and constraints, ranks morphology configs
    by estimated suitability. Used in Neon's sim-first development loop:

    1. Define task (e.g., "shelf stocking in warehouse")
    2. MorphologyExplorer ranks configs by workspace/DoF/mass fit
    3. Top-N configs are simulated with NeonSimEnv
    4. VLA trained with CategorySpecificLinear per-config
    5. Best config deployed to real hardware

    This replaces ad-hoc "which robot should we use?" with structured search.
    """

    def __init__(self, configs: Optional[Dict[str, MorphologyConfig]] = None):
        self.configs = configs or GULAMANNEN_CONFIGS

    def rank_for_task(
        self,
        task: str,
        requires_locomotion: bool = False,
        requires_manipulation: bool = True,
        workspace_height_mm: Optional[Tuple[int, int]] = None,
        max_mass_kg: Optional[float] = None,
    ) -> List[Tuple[str, float, str]]:
        """Rank morphology configs for a task.

        Returns list of (config_name, score, reason) sorted by score descending.
        """
        results = []

        for name, config in self.configs.items():
            score = 1.0
            reasons = []

            # Locomotion filter
            if requires_locomotion and config.base_config != BaseConfiguration.FULL_BIPED:
                score *= 0.1
                reasons.append("no locomotion")

            # Manipulation DoF bonus
            if requires_manipulation:
                # Count arm DoFs (shoulder + elbow + wrist per side)
                arm_dof = 0
                for key in [config.left_shoulder, config.left_elbow, config.left_wrist,
                             config.right_shoulder, config.right_elbow, config.right_wrist]:
                    if key and key in SUBSYSTEMS:
                        arm_dof += SUBSYSTEMS[key].dof
                score *= min(arm_dof / 14.0, 1.5)  # 14 DoF = full bimanual
                reasons.append(f"{arm_dof} arm DoFs")

            # Workspace height match
            if workspace_height_mm:
                req_min, req_max = workspace_height_mm
                cfg_min, cfg_max = config.height_mm
                overlap = min(req_max, cfg_max) - max(req_min, cfg_min)
                if overlap <= 0:
                    score *= 0.1
                    reasons.append("height mismatch")
                else:
                    coverage = overlap / (req_max - req_min)
                    score *= coverage
                    reasons.append(f"{coverage:.0%} height coverage")

            # Mass constraint
            if max_mass_kg and config.approx_mass_kg > max_mass_kg:
                score *= 0.5
                reasons.append(f"overweight ({config.approx_mass_kg:.0f}kg)")

            # Complexity bonus (simpler = easier to deploy, but lower capability)
            dof_norm = config.total_dof / 30.0  # Normalize by max (biped = 30)
            score *= (0.5 + 0.5 * dof_norm)  # Balance simplicity and capability

            results.append((name, score, "; ".join(reasons)))

        return sorted(results, key=lambda x: x[1], reverse=True)

    def compare_configs(self, config_a: str, config_b: str) -> Dict:
        """Compare two morphology configs side by side."""
        a = self.configs.get(config_a)
        b = self.configs.get(config_b)
        if not a or not b:
            return {"error": f"Config not found: {config_a if not a else config_b}"}

        return {
            "configs": [config_a, config_b],
            "dof": [a.total_dof, b.total_dof],
            "mass_kg": [a.approx_mass_kg, b.approx_mass_kg],
            "height_mm": [a.height_mm, b.height_mm],
            "base": [a.base_config.value, b.base_config.value],
            "actuator_mass_kg": [a.get_actuator_mass(), b.get_actuator_mass()],
            "has_locomotion": [
                a.base_config == BaseConfiguration.FULL_BIPED,
                b.base_config == BaseConfiguration.FULL_BIPED,
            ],
        }

    def list_configs(self) -> str:
        """Human-readable config listing."""
        lines = ["GulaMannen Morphology Configurations:"]
        lines.append("=" * 60)
        for name, config in self.configs.items():
            lines.append(
                f"  {config.embodiment_id:2d}. {name:30s} "
                f"| {config.total_dof:2d} DoF | {config.approx_mass_kg:.0f}kg "
                f"| {config.base_config.value}"
            )
        return "\n".join(lines)


# =============================================================================
# Integration with Neon's CategorySpecificLinear
# =============================================================================

def get_embodiment_id(config_name: str) -> int:
    """Get the embodiment_id for use with CategorySpecificLinear.

    Args:
        config_name: GulaMannen config name or "g1" for default Unitree G1

    Returns:
        Integer embodiment_id for cat_ids tensor

    Usage in training:
        cat_ids = torch.tensor([get_embodiment_id("series_biped")] * batch_size)
        output = category_specific_linear(features, cat_ids)
    """
    # Standard Neon embodiments (0-9)
    neon_embodiments = {
        "g1": 0,
        "g1_arms_only": 0,
        "g1_whole_body": 0,
        "franka": 1,
        "panda": 1,
        "so100": 2,
        "droid": 3,
        "gr1": 4,
    }

    if config_name in neon_embodiments:
        return neon_embodiments[config_name]

    if config_name in GULAMANNEN_CONFIGS:
        return GULAMANNEN_CONFIGS[config_name].embodiment_id

    logger.warning(f"Unknown morphology config: {config_name}, defaulting to 0")
    return 0


def morphology_to_action_space(config_name: str) -> Dict:
    """Convert a GulaMannen morphology to an action space definition.

    Returns a dict compatible with Neon's training pipeline:
    - joint_names: ordered list of joint names
    - action_dim: total degrees of freedom
    - joint_limits: (lower, upper) arrays
    - default_positions: standing pose
    - embodiment_id: for CategorySpecificLinear
    """
    config = GULAMANNEN_CONFIGS.get(config_name)
    if not config:
        raise ValueError(f"Unknown config: {config_name}. Available: {list(GULAMANNEN_CONFIGS.keys())}")

    lower, upper = config.get_joint_limits()

    return {
        "name": config.name,
        "joint_names": config.get_all_joints(),
        "action_dim": config.total_dof,
        "joint_limits_lower": lower,
        "joint_limits_upper": upper,
        "default_positions": config.get_default_positions(),
        "embodiment_id": config.embodiment_id,
        "base_config": config.base_config.value,
        "approx_mass_kg": config.approx_mass_kg,
    }


def register_gulamannen_urdfs():
    """Register all GulaMannen URDF configs into Neon's simulation URDF registry.

    Call this at startup to make GulaMannen configs available via:
        sim(action="add_robot", data_config="gulamannen_series_biped")
    """
    try:
        from neon.sim.simulation import register_urdf

        for name, config in GULAMANNEN_CONFIGS.items():
            data_config = f"gulamannen_{name}"
            # URDF path — users should place GulaMannen URDFs in ~/.neon/urdfs/gulamannen/
            urdf_path = f"gulamannen/{name}/{name}.urdf"
            register_urdf(data_config, urdf_path)
            logger.debug(f"Registered GulaMannen URDF: {data_config}")

        logger.info(f"Registered {len(GULAMANNEN_CONFIGS)} GulaMannen morphologies")
    except ImportError:
        logger.debug("neon.sim.simulation not available — URDF registration skipped")


# Convenience: auto-register on import (non-fatal)
try:
    register_gulamannen_urdfs()
except Exception:
    pass
