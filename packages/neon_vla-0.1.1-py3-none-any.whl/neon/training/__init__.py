"""Neon training module.

Submodules:
    - train: Core NeonTrainer training loop
    - config: TrainConfig presets (20+ configs)
    - sagemaker: Amazon SageMaker cloud training launcher
    - distill: Knowledge distillation
    - self_learner: Self-supervised learning
"""
