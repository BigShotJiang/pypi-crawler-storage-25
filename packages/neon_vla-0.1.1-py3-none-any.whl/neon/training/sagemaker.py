"""
Neon VLA — Amazon SageMaker Training Integration.

Deep integration with the HuggingFace SageMaker SDK for cloud-scale training
on AWS GPU instances (ml.p4d.24xlarge, ml.p5.48xlarge, ml.g5.xlarge, etc.).

Uses the `sagemaker` Python SDK with HuggingFace estimator to:
1. Package Neon as a training job from any TrainConfig
2. Upload data to S3 (or use existing S3/HF datasets)
3. Launch distributed training on SageMaker managed infrastructure
4. Stream logs, auto-checkpoint to S3, push to HuggingFace Hub
5. Spot instance support for 60-90% cost savings

Architecture:
    Local Machine                    SageMaker
    ─────────────                    ─────────
    TrainConfig ──► sagemaker.py ──► HuggingFace Estimator ──► ml.p4d.24xlarge
                    │                     │                         │
                    │ S3 upload           │ DLC container           │ torchrun
                    └─► s3://bucket/     └─► train.py              └─► checkpoint → S3
                                                                        └─► Hub push

Usage:
    from neon.training.sagemaker import SageMakerLauncher
    from neon.training.config import neon_base_flow_config

    launcher = SageMakerLauncher(
        role="arn:aws:iam::123456789012:role/SageMakerRole",
        output_s3="s3://my-bucket/neon-training",
    )

    # Launch a training job
    estimator = launcher.launch(
        config=neon_base_flow_config(),
        instance_type="ml.p4d.24xlarge",
        instance_count=1,
        spot=True,
    )

    # Or use the CLI
    # neon-sagemaker --config neon_base_flow --instance ml.p4d.24xlarge --spot

References:
    - https://huggingface.co/docs/sagemaker/tutorials/sagemaker-sdk/training-sagemaker-sdk
    - https://sagemaker.readthedocs.io/en/stable/frameworks/huggingface/sagemaker.huggingface.html
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# Instance type → GPU mapping for documentation and validation
INSTANCE_GPU_MAP = {
    # G5 family (NVIDIA A10G, 24GB each)
    "ml.g5.xlarge": {"gpus": 1, "gpu_mem_gb": 24, "gpu_type": "A10G"},
    "ml.g5.2xlarge": {"gpus": 1, "gpu_mem_gb": 24, "gpu_type": "A10G"},
    "ml.g5.4xlarge": {"gpus": 1, "gpu_mem_gb": 24, "gpu_type": "A10G"},
    "ml.g5.12xlarge": {"gpus": 4, "gpu_mem_gb": 96, "gpu_type": "A10G"},
    "ml.g5.48xlarge": {"gpus": 8, "gpu_mem_gb": 192, "gpu_type": "A10G"},
    # G6 family (NVIDIA L4, 24GB each)
    "ml.g6.xlarge": {"gpus": 1, "gpu_mem_gb": 24, "gpu_type": "L4"},
    "ml.g6.2xlarge": {"gpus": 1, "gpu_mem_gb": 24, "gpu_type": "L4"},
    "ml.g6.12xlarge": {"gpus": 4, "gpu_mem_gb": 96, "gpu_type": "L4"},
    "ml.g6.48xlarge": {"gpus": 8, "gpu_mem_gb": 192, "gpu_type": "L4"},
    # P4d family (NVIDIA A100, 40GB each)
    "ml.p4d.24xlarge": {"gpus": 8, "gpu_mem_gb": 320, "gpu_type": "A100-40GB"},
    # P4de family (NVIDIA A100, 80GB each)
    "ml.p4de.24xlarge": {"gpus": 8, "gpu_mem_gb": 640, "gpu_type": "A100-80GB"},
    # P5 family (NVIDIA H100, 80GB each)
    "ml.p5.48xlarge": {"gpus": 8, "gpu_mem_gb": 640, "gpu_type": "H100"},
    # Trn1 family (AWS Trainium)
    "ml.trn1.2xlarge": {"gpus": 1, "gpu_mem_gb": 32, "gpu_type": "Trainium"},
    "ml.trn1.32xlarge": {"gpus": 16, "gpu_mem_gb": 512, "gpu_type": "Trainium"},
}

# Recommended instance type per config complexity
CONFIG_INSTANCE_RECOMMENDATIONS = {
    "neon_nano": "ml.g5.xlarge",          # 3B backbone, cheap
    "edge_3b": "ml.g5.xlarge",            # 3B backbone, cheap
    "default_arms_only": "ml.p4d.24xlarge",  # 7B backbone, needs A100
    "neon_base_flow": "ml.p4d.24xlarge",
    "neon_dit": "ml.p4de.24xlarge",       # DiT needs 80GB
    "neon_cosmos_flow": "ml.p4d.24xlarge",
    "neon_ensemble": "ml.p4de.24xlarge",
    "neon_omni_12": "ml.p4de.24xlarge",
    "neon_photon_3b": "ml.p4d.24xlarge",
    "neon_photon_7b": "ml.p4de.24xlarge",
    "large_wholebody": "ml.p4de.24xlarge",
    "flow_wholebody": "ml.p4d.24xlarge",
}


def _config_to_hyperparameters(config) -> Dict[str, str]:
    """Convert a TrainConfig to SageMaker hyperparameters dict.

    SageMaker passes hyperparameters as string key-value pairs.
    We serialize the full config as JSON under the 'neon_config' key,
    plus individual top-level params for SageMaker UI visibility.
    """
    from neon.training.config import TrainConfig

    hp = {}

    # Top-level params visible in SageMaker console
    hp["epochs"] = str(config.epochs)
    hp["batch_size"] = str(config.batch_size)
    hp["learning_rate"] = str(config.learning_rate)
    hp["gradient_accumulation_steps"] = str(config.gradient_accumulation_steps)
    hp["max_grad_norm"] = str(config.max_grad_norm)
    hp["use_lora"] = str(config.use_lora)
    hp["lora_r"] = str(config.lora_r)
    hp["lora_alpha"] = str(config.lora_alpha)
    hp["hub_model_id"] = config.hub_model_id
    hp["push_to_hub"] = str(config.push_to_hub)

    # Model config as JSON
    hp["backbone_model_id"] = config.model.backbone.model_id
    hp["control_mode"] = config.model.control_mode
    hp["action_head_type"] = config.model.action_head_type
    hp["num_action_steps"] = str(config.model.num_action_steps)

    # Full config serialized (for the training script to reconstruct)
    try:
        full_config = asdict(config)
        hp["neon_config_json"] = json.dumps(full_config)
    except Exception as e:
        logger.warning(f"Could not serialize full config: {e}")

    return hp


class SageMakerLauncher:
    """Launch Neon training jobs on Amazon SageMaker.

    Wraps the HuggingFace SageMaker estimator with Neon-specific defaults:
    - Auto-installs neon-vla[train] in the training container
    - Configures distributed training (torchrun) for multi-GPU
    - Handles S3 data channels and checkpoint output
    - Supports spot instances for cost savings
    - Streams CloudWatch logs to terminal

    Args:
        role: SageMaker execution role ARN. If None, auto-detects.
        output_s3: S3 path for training outputs (checkpoints, artifacts).
        session: Optional boto3 SageMaker session.
        region: AWS region (default: us-west-2).

    Example:
        launcher = SageMakerLauncher(
            role="arn:aws:iam::123456789012:role/SageMakerRole",
            output_s3="s3://neon-training/output",
        )
        estimator = launcher.launch(neon_base_flow_config(), instance_type="ml.p4d.24xlarge")
    """

    def __init__(
        self,
        role: Optional[str] = None,
        output_s3: Optional[str] = None,
        session=None,
        region: str = "us-west-2",
    ):
        self.role = role or os.getenv("SAGEMAKER_ROLE")
        self.output_s3 = output_s3 or os.getenv(
            "SAGEMAKER_OUTPUT_S3", "s3://neon-training-output/jobs"
        )
        self.region = region
        self._session = session
        self._sagemaker = None
        self._huggingface = None

    @property
    def session(self):
        """Lazy-load SageMaker session."""
        if self._session is None:
            import boto3
            import sagemaker

            boto_session = boto3.Session(region_name=self.region)
            self._session = sagemaker.Session(boto_session=boto_session)
        return self._session

    def _get_role(self) -> str:
        """Get or auto-detect SageMaker execution role."""
        if self.role:
            return self.role

        # Try to get from SageMaker notebook environment
        try:
            import sagemaker

            return sagemaker.get_execution_role()
        except Exception:
            pass

        # Try to construct from current IAM identity
        try:
            import boto3

            sts = boto3.client("sts", region_name=self.region)
            account_id = sts.get_caller_identity()["Account"]
            # Default SageMaker role name convention
            role = f"arn:aws:iam::{account_id}:role/SageMakerRole"
            logger.warning(f"Auto-detected role: {role} — verify this exists!")
            return role
        except Exception as e:
            raise ValueError(
                "Could not detect SageMaker role. "
                "Set SAGEMAKER_ROLE env var or pass role= parameter. "
                f"Error: {e}"
            )

    def _create_training_script(self, config) -> str:
        """Create the SageMaker entry point training script.

        This script runs INSIDE the SageMaker container. It:
        1. Installs neon-vla from git
        2. Reconstructs TrainConfig from hyperparameters
        3. Runs NeonTrainer
        4. Pushes to HuggingFace Hub

        The script is self-contained and uses SM_ environment variables
        for paths (SM_MODEL_DIR, SM_OUTPUT_DIR, SM_CHANNEL_*).
        """
        script = '''#!/usr/bin/env python3
"""Neon VLA SageMaker Training Entry Point.

Auto-generated by neon.training.sagemaker.SageMakerLauncher.
Runs inside the HuggingFace Deep Learning Container on SageMaker.
"""
import json
import logging
import os
import subprocess
import sys
import time

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

def main():
    start_time = time.time()

    # SageMaker environment variables
    model_dir = os.environ.get("SM_MODEL_DIR", "/opt/ml/model")
    output_dir = os.environ.get("SM_OUTPUT_DIR", "/opt/ml/output")
    num_gpus = int(os.environ.get("SM_NUM_GPUS", "1"))
    num_hosts = int(os.environ.get("SM_NUM_HOSTS", "1"))

    log.info(f"SageMaker Training Starting")
    log.info(f"  GPUs: {num_gpus}, Hosts: {num_hosts}")
    log.info(f"  Model dir: {model_dir}")
    log.info(f"  Output dir: {output_dir}")

    # Install neon-vla from GitHub (latest main branch)
    log.info("Installing neon-vla[train]...")
    subprocess.check_call([
        sys.executable, "-m", "pip", "install",
        "git+https://github.com/cagataycali/neon.git@main#egg=neon-vla[train]",
        "--quiet",
    ])

    # HuggingFace login if token available
    hf_token = os.environ.get("HF_TOKEN", "")
    if hf_token:
        from huggingface_hub import login
        login(token=hf_token)
        log.info("Logged into HuggingFace Hub")

    # Reconstruct config from hyperparameters
    import torch
    from neon.training.config import TrainConfig
    from neon.training.train import NeonTrainer

    neon_config_json = os.environ.get("SM_HP_NEON_CONFIG_JSON", "")

    if neon_config_json:
        log.info("Reconstructing config from neon_config_json hyperparameter...")
        config_dict = json.loads(neon_config_json)
        config = _dict_to_train_config(config_dict)
    else:
        log.info("Using default arms_only config")
        from neon.training.config import default_arms_only_config
        config = default_arms_only_config()

    # Override output dir to SageMaker model dir
    config.output_dir = model_dir
    config.push_to_hub = bool(hf_token)

    # Override hub_model_id from hyperparameters if set
    hub_id = os.environ.get("SM_HP_HUB_MODEL_ID", "")
    if hub_id:
        config.hub_model_id = hub_id

    # Handle S3 data channels
    # SageMaker downloads S3 data to /opt/ml/input/data/<channel_name>/
    train_channel = os.environ.get("SM_CHANNEL_TRAIN")
    if train_channel and os.path.exists(train_channel):
        log.info(f"Train data channel: {train_channel}")
        # Override data paths to use local SageMaker data
        for source in config.data.sources:
            # If source path was S3, it's now local
            channel_path = os.path.join(train_channel, source.name)
            if os.path.exists(channel_path):
                log.info(f"  Mapping {source.name} → {channel_path}")
                source.path = channel_path

    # Log configuration
    log.info(f"Training configuration:")
    log.info(f"  Backbone: {config.model.backbone.model_id}")
    log.info(f"  Control mode: {config.model.control_mode}")
    log.info(f"  Action head: {config.model.action_head_type}")
    log.info(f"  Epochs: {config.epochs}")
    log.info(f"  Batch size: {config.batch_size}")
    log.info(f"  Learning rate: {config.learning_rate}")
    log.info(f"  LoRA: r={config.lora_r}, alpha={config.lora_alpha}")
    log.info(f"  Hub model: {config.hub_model_id}")
    log.info(f"  GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}")
    if torch.cuda.is_available():
        log.info(f"  VRAM: {torch.cuda.get_device_properties(0).total_mem / 1e9:.1f} GB")

    # Train!
    trainer = NeonTrainer(config)
    stats = trainer.train()

    # Save training stats
    stats["duration_seconds"] = time.time() - start_time
    stats["instance_type"] = os.environ.get("SM_RESOURCE_CONFIG", "unknown")
    stats_path = os.path.join(model_dir, "sagemaker_training_stats.json")
    with open(stats_path, "w") as f:
        json.dump(stats, f, indent=2)

    log.info(f"Training complete in {stats['duration_seconds']:.0f}s")
    log.info(f"Best loss: {stats.get('best_loss', 'N/A')}")
    log.info(f"Model saved to: {model_dir}")


def _dict_to_train_config(d: dict):
    """Reconstruct TrainConfig from a dict (deserialized from JSON)."""
    from neon.model.neon_vla import NeonConfig
    from neon.model.video_backbone import BackboneConfig
    from neon.data.data_soup import DataSoupConfig, DataSourceConfig
    from neon.training.config import TrainConfig

    # Reconstruct nested configs
    model_dict = d.get("model", {})
    backbone_dict = model_dict.pop("backbone", {})
    backbone = BackboneConfig(**{k: v for k, v in backbone_dict.items() if k in BackboneConfig.__dataclass_fields__})

    model_dict["backbone"] = backbone
    # Filter to only valid NeonConfig fields
    valid_model_fields = set(NeonConfig.__dataclass_fields__.keys())
    model_dict = {k: v for k, v in model_dict.items() if k in valid_model_fields}
    model_config = NeonConfig(**model_dict)

    # Reconstruct data config
    data_dict = d.get("data", {})
    sources = []
    for src in data_dict.get("sources", []):
        valid_src_fields = set(DataSourceConfig.__dataclass_fields__.keys())
        src = {k: v for k, v in src.items() if k in valid_src_fields}
        sources.append(DataSourceConfig(**src))
    data_config = DataSoupConfig(sources=sources)

    # Build TrainConfig
    valid_train_fields = set(TrainConfig.__dataclass_fields__.keys())
    train_dict = {k: v for k, v in d.items() if k in valid_train_fields and k not in ("model", "data")}
    train_dict["model"] = model_config
    train_dict["data"] = data_config

    return TrainConfig(**train_dict)


if __name__ == "__main__":
    main()
'''
        return script

    def _write_training_script(self, config) -> Path:
        """Write the training entry point script to a temp directory."""
        script_content = self._create_training_script(config)
        script_dir = Path(tempfile.mkdtemp(prefix="neon_sm_"))
        script_path = script_dir / "train_sagemaker.py"
        script_path.write_text(script_content)

        # Also write a requirements.txt for additional deps
        reqs_path = script_dir / "requirements.txt"
        reqs_path.write_text(
            "git+https://github.com/cagataycali/neon.git@main#egg=neon-vla[train]\n"
        )

        logger.info(f"Training script written to: {script_path}")
        return script_dir

    def launch(
        self,
        config,
        instance_type: str = "ml.p4d.24xlarge",
        instance_count: int = 1,
        spot: bool = False,
        max_run_hours: int = 24,
        max_wait_hours: int = 48,
        job_name: Optional[str] = None,
        volume_size_gb: int = 200,
        hf_token: Optional[str] = None,
        extra_env: Optional[Dict[str, str]] = None,
        data_channels: Optional[Dict[str, str]] = None,
        tags: Optional[List[Dict[str, str]]] = None,
        wait: bool = True,
        py_version: str = "py310",
        transformers_version: str = "4.45.2",
        pytorch_version: str = "2.5.1",
        distribution: Optional[Dict] = None,
    ):
        """Launch a Neon training job on SageMaker.

        Args:
            config: TrainConfig instance defining the training run.
            instance_type: SageMaker instance type (e.g., ml.p4d.24xlarge).
            instance_count: Number of instances for distributed training.
            spot: Use spot instances (60-90% cheaper, may be interrupted).
            max_run_hours: Max training time in hours.
            max_wait_hours: Max wait time for spot capacity.
            job_name: Custom job name (auto-generated if None).
            volume_size_gb: EBS volume size in GB.
            hf_token: HuggingFace token for Hub push.
            extra_env: Additional environment variables.
            data_channels: S3 data channel mapping {"train": "s3://...", "validation": "s3://..."}.
            tags: SageMaker job tags [{"Key": "project", "Value": "neon"}].
            wait: Block until training completes.
            py_version: Python version for the DLC.
            transformers_version: Transformers version for the HF DLC.
            pytorch_version: PyTorch version for the HF DLC.
            distribution: Custom distribution config. Auto-set for multi-GPU.

        Returns:
            sagemaker.huggingface.HuggingFace estimator with the launched job.
        """
        from sagemaker.huggingface import HuggingFace

        role = self._get_role()
        script_dir = self._write_training_script(config)

        # Auto-generate job name
        if job_name is None:
            from datetime import datetime

            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            head_type = config.model.action_head_type
            backbone_short = config.model.backbone.model_id.split("/")[-1][:20]
            job_name = f"neon-{head_type}-{backbone_short}-{timestamp}"
            # SageMaker job names: max 63 chars, alphanumeric + hyphens
            job_name = job_name[:63].replace(".", "-").replace("_", "-").lower()

        # Build hyperparameters
        hyperparameters = _config_to_hyperparameters(config)

        # Environment variables
        env = {
            "NEON_SAGEMAKER": "1",
            "WANDB_DISABLED": "true",  # Default off; override in extra_env
        }
        if hf_token or os.getenv("HF_TOKEN"):
            env["HF_TOKEN"] = hf_token or os.getenv("HF_TOKEN", "")
        if extra_env:
            env.update(extra_env)

        # Distribution config for multi-GPU
        if distribution is None and instance_type in INSTANCE_GPU_MAP:
            gpu_info = INSTANCE_GPU_MAP[instance_type]
            num_gpus = gpu_info["gpus"]
            if num_gpus > 1 or instance_count > 1:
                distribution = {
                    "torch_distributed": {
                        "enabled": True,
                    }
                }
                logger.info(
                    f"Enabled torch_distributed for {num_gpus} GPUs × {instance_count} instances"
                )

        # Spot instance configuration
        use_spot = spot
        max_run = max_run_hours * 3600
        max_wait = max_wait_hours * 3600 if spot else None

        # Checkpoint config for spot resilience
        checkpoint_s3 = f"{self.output_s3}/{job_name}/checkpoints"

        logger.info(f"Launching SageMaker training job: {job_name}")
        logger.info(f"  Instance: {instance_type} × {instance_count}")
        logger.info(f"  Spot: {use_spot}")
        logger.info(f"  Config: {config.model.backbone.model_id} / {config.model.action_head_type}")
        logger.info(f"  Output: {self.output_s3}/{job_name}")

        # Create HuggingFace estimator
        estimator = HuggingFace(
            entry_point="train_sagemaker.py",
            source_dir=str(script_dir),
            role=role,
            instance_type=instance_type,
            instance_count=instance_count,
            transformers_version=transformers_version,
            pytorch_version=pytorch_version,
            py_version=py_version,
            hyperparameters=hyperparameters,
            environment=env,
            output_path=f"{self.output_s3}/{job_name}",
            checkpoint_s3_uri=checkpoint_s3 if use_spot else None,
            use_spot_instances=use_spot,
            max_run=max_run,
            max_wait=max_wait if use_spot else None,
            volume_size=volume_size_gb,
            distribution=distribution,
            sagemaker_session=self.session,
            tags=tags
            or [
                {"Key": "project", "Value": "neon"},
                {"Key": "model", "Value": config.model.backbone.model_id},
                {"Key": "head", "Value": config.model.action_head_type},
            ],
            base_job_name=job_name,
        )

        # Data channels
        fit_inputs = {}
        if data_channels:
            fit_inputs.update(data_channels)

        # Launch!
        logger.info(f"Calling estimator.fit(wait={wait})...")
        estimator.fit(inputs=fit_inputs if fit_inputs else None, wait=wait)

        if wait:
            logger.info(f"Training complete! Output: {self.output_s3}/{job_name}")
        else:
            logger.info(f"Training job submitted: {job_name}")
            logger.info(f"  Monitor: https://{self.region}.console.aws.amazon.com/sagemaker/home?region={self.region}#/jobs")

        return estimator

    def launch_from_preset(
        self,
        preset_name: str,
        instance_type: Optional[str] = None,
        spot: bool = True,
        **kwargs,
    ):
        """Launch training from a named preset config.

        Args:
            preset_name: Config function name from neon.training.config
                (e.g., "neon_base_flow", "neon_nano", "neon_dit")
            instance_type: Override instance type (auto-recommended if None)
            spot: Use spot instances
            **kwargs: Additional arguments passed to launch()

        Returns:
            Estimator with launched job.
        """
        from neon.training import config as config_module

        # Look up config function
        config_func_name = f"{preset_name}_config"
        if not hasattr(config_module, config_func_name):
            available = [
                n.replace("_config", "")
                for n in dir(config_module)
                if n.endswith("_config") and callable(getattr(config_module, n))
            ]
            raise ValueError(
                f"Unknown preset '{preset_name}'. Available: {', '.join(sorted(available))}"
            )

        config_func = getattr(config_module, config_func_name)
        config = config_func()

        # Auto-recommend instance type if not specified
        if instance_type is None:
            instance_type = CONFIG_INSTANCE_RECOMMENDATIONS.get(
                preset_name, "ml.p4d.24xlarge"
            )
            logger.info(f"Auto-selected instance type: {instance_type}")

        return self.launch(config, instance_type=instance_type, spot=spot, **kwargs)

    def estimate_cost(
        self,
        config,
        instance_type: str = "ml.p4d.24xlarge",
        instance_count: int = 1,
        estimated_hours: float = 8.0,
        spot: bool = True,
    ) -> Dict[str, Any]:
        """Estimate training cost.

        Uses approximate on-demand pricing. Spot is typically 60-90% cheaper.

        Returns dict with cost breakdown.
        """
        # Approximate on-demand hourly rates (us-west-2, as of 2025)
        on_demand_rates = {
            "ml.g5.xlarge": 1.408,
            "ml.g5.2xlarge": 1.515,
            "ml.g5.4xlarge": 2.03,
            "ml.g5.12xlarge": 7.09,
            "ml.g5.48xlarge": 20.28,
            "ml.g6.xlarge": 1.26,
            "ml.g6.2xlarge": 1.48,
            "ml.g6.12xlarge": 6.68,
            "ml.g6.48xlarge": 19.08,
            "ml.p4d.24xlarge": 37.688,
            "ml.p4de.24xlarge": 43.842,
            "ml.p5.48xlarge": 98.32,
            "ml.trn1.2xlarge": 1.34,
            "ml.trn1.32xlarge": 21.50,
        }

        hourly_rate = on_demand_rates.get(instance_type, 0)
        spot_discount = 0.3 if spot else 1.0  # Spot is ~70% cheaper

        total_on_demand = hourly_rate * instance_count * estimated_hours
        total_spot = total_on_demand * spot_discount

        gpu_info = INSTANCE_GPU_MAP.get(instance_type, {})

        return {
            "instance_type": instance_type,
            "instance_count": instance_count,
            "gpu_type": gpu_info.get("gpu_type", "unknown"),
            "gpu_count": gpu_info.get("gpus", 0) * instance_count,
            "total_gpu_mem_gb": gpu_info.get("gpu_mem_gb", 0) * instance_count,
            "estimated_hours": estimated_hours,
            "hourly_rate_on_demand": hourly_rate,
            "total_cost_on_demand": round(total_on_demand, 2),
            "total_cost_spot": round(total_spot, 2),
            "spot_savings_pct": round((1 - spot_discount) * 100),
            "recommended_spot": spot,
            "config_backbone": config.model.backbone.model_id,
            "config_head": config.model.action_head_type,
        }

    def list_jobs(self, max_results: int = 20) -> List[Dict[str, Any]]:
        """List recent Neon training jobs.

        Returns:
            List of job summaries sorted by creation time (newest first).
        """
        import boto3

        sm_client = boto3.client("sagemaker", region_name=self.region)

        response = sm_client.list_training_jobs(
            NameContains="neon",
            SortBy="CreationTime",
            SortOrder="Descending",
            MaxResults=max_results,
        )

        jobs = []
        for job in response.get("TrainingJobSummaries", []):
            jobs.append(
                {
                    "name": job["TrainingJobName"],
                    "status": job["TrainingJobStatus"],
                    "created": str(job["CreationTime"]),
                    "instance": job.get("TrainingEndTime", "running"),
                }
            )

        return jobs

    def describe_job(self, job_name: str) -> Dict[str, Any]:
        """Get detailed info about a training job.

        Returns:
            Full job description dict.
        """
        import boto3

        sm_client = boto3.client("sagemaker", region_name=self.region)
        return sm_client.describe_training_job(TrainingJobName=job_name)

    def stop_job(self, job_name: str):
        """Stop a running training job."""
        import boto3

        sm_client = boto3.client("sagemaker", region_name=self.region)
        sm_client.stop_training_job(TrainingJobName=job_name)
        logger.info(f"Stopped training job: {job_name}")


def launch_cli():
    """CLI entry point for launching SageMaker training jobs.

    Usage:
        neon-sagemaker --config neon_base_flow --instance ml.p4d.24xlarge --spot
        neon-sagemaker --config neon_nano --instance ml.g5.xlarge
        neon-sagemaker --list-presets
        neon-sagemaker --estimate --config neon_dit --hours 12
        neon-sagemaker --list-jobs
    """
    import argparse

    parser = argparse.ArgumentParser(
        description="🤖 Neon VLA — SageMaker Training Launcher",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  neon-sagemaker --config neon_base_flow --spot
  neon-sagemaker --config neon_nano --instance ml.g5.xlarge
  neon-sagemaker --config neon_dit --instance ml.p4de.24xlarge --spot
  neon-sagemaker --estimate --config neon_dit --hours 12
  neon-sagemaker --list-presets
  neon-sagemaker --list-jobs
        """,
    )

    parser.add_argument(
        "--config", "-c", type=str, help="Preset config name (e.g., neon_base_flow)"
    )
    parser.add_argument(
        "--instance", "-i", type=str, default=None, help="Instance type (auto-recommended if not set)"
    )
    parser.add_argument(
        "--count", "-n", type=int, default=1, help="Instance count (default: 1)"
    )
    parser.add_argument("--spot", action="store_true", default=True, help="Use spot instances (default: True)")
    parser.add_argument("--no-spot", action="store_true", help="Disable spot instances")
    parser.add_argument("--role", type=str, default=None, help="SageMaker execution role ARN")
    parser.add_argument("--output-s3", type=str, default=None, help="S3 output path")
    parser.add_argument("--region", type=str, default="us-west-2", help="AWS region")
    parser.add_argument("--hf-token", type=str, default=None, help="HuggingFace token")
    parser.add_argument("--max-hours", type=int, default=24, help="Max training hours")
    parser.add_argument("--volume-gb", type=int, default=200, help="EBS volume size GB")
    parser.add_argument("--no-wait", action="store_true", help="Don't wait for completion")
    parser.add_argument("--job-name", type=str, default=None, help="Custom job name")

    # Info commands
    parser.add_argument("--list-presets", action="store_true", help="List available preset configs")
    parser.add_argument("--list-jobs", action="store_true", help="List recent training jobs")
    parser.add_argument("--estimate", action="store_true", help="Estimate cost without launching")
    parser.add_argument("--hours", type=float, default=8.0, help="Estimated hours (for cost estimation)")
    parser.add_argument("--list-instances", action="store_true", help="List supported instance types")

    args = parser.parse_args()

    # List presets
    if args.list_presets:
        from neon.training import config as config_module

        print("🤖 Available Neon Training Presets:\n")
        presets = [
            n.replace("_config", "")
            for n in sorted(dir(config_module))
            if n.endswith("_config") and callable(getattr(config_module, n))
        ]
        for p in presets:
            rec = CONFIG_INSTANCE_RECOMMENDATIONS.get(p, "ml.p4d.24xlarge")
            print(f"  {p:<40} → {rec}")
        print(f"\n  Total: {len(presets)} presets")
        return

    # List instances
    if args.list_instances:
        print("🖥️  Supported SageMaker Instance Types:\n")
        for inst, info in sorted(INSTANCE_GPU_MAP.items()):
            print(
                f"  {inst:<25} {info['gpus']}× {info['gpu_type']:<12} "
                f"({info['gpu_mem_gb']} GB total)"
            )
        return

    # List jobs
    if args.list_jobs:
        launcher = SageMakerLauncher(region=args.region)
        jobs = launcher.list_jobs()
        if not jobs:
            print("No neon training jobs found.")
        else:
            print("🤖 Recent Neon Training Jobs:\n")
            for j in jobs:
                status_icon = {"Completed": "✅", "InProgress": "🔄", "Failed": "❌", "Stopped": "⏹️"}.get(
                    j["status"], "❓"
                )
                print(f"  {status_icon} {j['name']:<50} {j['status']}")
        return

    # Need a config for everything else
    if not args.config:
        parser.print_help()
        return

    launcher = SageMakerLauncher(
        role=args.role,
        output_s3=args.output_s3,
        region=args.region,
    )

    # Estimate cost
    if args.estimate:
        from neon.training import config as config_module

        config_func = getattr(config_module, f"{args.config}_config")
        config = config_func()
        instance = args.instance or CONFIG_INSTANCE_RECOMMENDATIONS.get(args.config, "ml.p4d.24xlarge")
        use_spot = args.spot and not args.no_spot

        est = launcher.estimate_cost(
            config,
            instance_type=instance,
            instance_count=args.count,
            estimated_hours=args.hours,
            spot=use_spot,
        )

        print(f"💰 Cost Estimate: {args.config}\n")
        print(f"  Instance:     {est['instance_type']} × {est['instance_count']}")
        print(f"  GPU:          {est['gpu_count']}× {est['gpu_type']} ({est['total_gpu_mem_gb']} GB)")
        print(f"  Duration:     {est['estimated_hours']}h")
        print(f"  Backbone:     {est['config_backbone']}")
        print(f"  Action Head:  {est['config_head']}")
        print(f"  On-Demand:    ${est['total_cost_on_demand']:.2f}")
        print(f"  Spot:         ${est['total_cost_spot']:.2f} ({est['spot_savings_pct']}% savings)")
        print(f"\n  Recommended:  {'Spot ✅' if est['recommended_spot'] else 'On-Demand'}")
        return

    # Launch!
    use_spot = args.spot and not args.no_spot
    estimator = launcher.launch_from_preset(
        preset_name=args.config,
        instance_type=args.instance,
        spot=use_spot,
        instance_count=args.count,
        max_run_hours=args.max_hours,
        job_name=args.job_name,
        volume_size_gb=args.volume_gb,
        hf_token=args.hf_token,
        wait=not args.no_wait,
    )

    print(f"\n✅ Job complete!" if not args.no_wait else f"\n🚀 Job submitted!")
