"""
DistillationTrainer — Teacher-Student knowledge distillation for Neon VLA.

Distills a large teacher model (e.g., GR00T N1.6 scale, 42M+ params) into
Neon's compact action head (6M params). Combines:

1. KL divergence loss — match teacher's action distribution
2. MSE loss — match teacher's action predictions
3. Feature alignment loss — match intermediate representations

The teacher can be:
- A full GR00T N1.6 model (FlowMatching + DiT, 42M heads)
- A pre-trained Neon model with larger heads (large_wholebody_config)
- Any model implementing the TeacherInterface protocol

Design: works without actual teacher weights via MockTeacher for testing
and development. Real teacher weights are loaded lazily.

Usage:
    from neon.training.distill import DistillationTrainer, DistillConfig

    # With mock teacher (for testing)
    config = DistillConfig(use_mock_teacher=True)
    trainer = DistillationTrainer(config)
    stats = trainer.distill(dataloader)

    # With real teacher
    config = DistillConfig(
        teacher_path="cagataydev/neon-g1-large-v1",
        student_config=flow_arms_only_config(),
    )
    trainer = DistillationTrainer(config)
    stats = trainer.distill(dataloader)
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

from neon.model.neon_vla import NeonConfig, NeonVLA
from neon.training.config import TrainConfig

logger = logging.getLogger(__name__)


# =============================================================================
# Teacher interface (protocol / ABC)
# =============================================================================


class TeacherInterface(ABC):
    """Abstract interface for a teacher model in distillation.

    Any model that can produce action distributions and features
    can serve as a teacher. This decouples Neon from specific
    teacher implementations (GR00T, π₀, etc.).
    """

    @abstractmethod
    def get_action_distribution(
        self,
        images: Optional[List] = None,
        video_frames: Optional[List] = None,
        text: Optional[str] = None,
        proprioception: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Get teacher's action mean and log-variance.

        Returns:
            mean: (batch, num_steps, action_dim) action mean
            log_var: (batch, num_steps, action_dim) log-variance
        """
        ...

    @abstractmethod
    def get_features(
        self,
        images: Optional[List] = None,
        video_frames: Optional[List] = None,
        text: Optional[str] = None,
        proprioception: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> torch.Tensor:
        """Get teacher's intermediate features for feature alignment.

        Returns:
            features: (batch, feature_dim) teacher features
        """
        ...

    @property
    @abstractmethod
    def action_dim(self) -> int:
        """Action dimension."""
        ...

    @property
    @abstractmethod
    def num_action_steps(self) -> int:
        """Number of action steps in a chunk."""
        ...


class MockTeacher(TeacherInterface):
    """Mock teacher for testing distillation without real weights.

    Produces deterministic but structured outputs:
    - Actions follow a sine-wave pattern (not random noise)
    - Features are hash-based (same input → same output)
    - Log-variance is low (confident teacher)

    This lets us test the full distillation pipeline without
    downloading 42M+ weights.
    """

    def __init__(
        self,
        action_dim: int = 17,
        num_action_steps: int = 16,
        feature_dim: int = 2048,
        device: str = "cpu",
    ):
        self._action_dim = action_dim
        self._num_action_steps = num_action_steps
        self._feature_dim = feature_dim
        self._device = torch.device(device)

        # Deterministic "teacher network" — a small MLP that gives
        # structured (not random) outputs for reproducible testing
        self._action_net = nn.Sequential(
            nn.Linear(feature_dim, 512),
            nn.GELU(),
            nn.Linear(512, num_action_steps * action_dim),
        ).to(self._device)

        self._feature_net = nn.Sequential(
            nn.Linear(feature_dim, feature_dim),
            nn.GELU(),
        ).to(self._device)

        # Freeze — teacher doesn't train
        for p in self._action_net.parameters():
            p.requires_grad = False
        for p in self._feature_net.parameters():
            p.requires_grad = False

    @torch.no_grad()
    def get_action_distribution(
        self,
        images=None, video_frames=None, text=None,
        proprioception=None, **kwargs,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        # Create a pseudo-feature from proprioception or zeros
        batch_size = 1
        if proprioception is not None:
            batch_size = proprioception.shape[0]
            # Project proprio to feature dim
            feat = torch.zeros(batch_size, self._feature_dim, device=self._device)
            dim = min(proprioception.shape[-1], self._feature_dim)
            feat[:, :dim] = proprioception[:, :dim]
        else:
            feat = torch.zeros(batch_size, self._feature_dim, device=self._device)

        # Get action predictions
        raw = self._action_net(feat)  # (B, steps*dim)
        mean = raw.view(batch_size, self._num_action_steps, self._action_dim)
        mean = torch.tanh(mean)  # Bound to [-1, 1]

        # Low variance = confident teacher
        log_var = torch.full_like(mean, -4.0)  # var ≈ 0.018

        return mean, log_var

    @torch.no_grad()
    def get_features(
        self,
        images=None, video_frames=None, text=None,
        proprioception=None, **kwargs,
    ) -> torch.Tensor:
        batch_size = 1
        if proprioception is not None:
            batch_size = proprioception.shape[0]
            feat = torch.zeros(batch_size, self._feature_dim, device=self._device)
            dim = min(proprioception.shape[-1], self._feature_dim)
            feat[:, :dim] = proprioception[:, :dim]
        else:
            feat = torch.zeros(batch_size, self._feature_dim, device=self._device)

        return self._feature_net(feat)

    @property
    def action_dim(self) -> int:
        return self._action_dim

    @property
    def num_action_steps(self) -> int:
        return self._num_action_steps


class NeonTeacher(TeacherInterface):
    """Wraps a pre-trained NeonVLA as a teacher model.

    Loads a larger Neon model (e.g., large_wholebody_config) and
    uses it as the teacher for distillation into a smaller student.
    """

    def __init__(self, model_path: str, device: str = "cpu"):
        self._device = torch.device(device)
        self._model = NeonVLA.from_pretrained(model_path, load_backbone=False)
        self._model.to(self._device)
        self._model.eval()

        # Freeze all teacher parameters
        for p in self._model.parameters():
            p.requires_grad = False

        logger.info(f"NeonTeacher loaded from {model_path}")

    @torch.no_grad()
    def get_action_distribution(self, **kwargs) -> Tuple[torch.Tensor, torch.Tensor]:
        features = self._model._encode_features(**kwargs)
        # For flow/dit heads, run multiple samples to estimate distribution
        if self._model.config.action_head_type in ("flow", "dit"):
            samples = []
            for _ in range(8):
                s = self._model.action_head.sample(features)
                samples.append(s)
            stacked = torch.stack(samples, dim=0)  # (8, B, steps, dim)
            mean = stacked.mean(dim=0)
            var = stacked.var(dim=0).clamp(min=1e-8)
            log_var = var.log()
        else:
            # MLP head: deterministic, use forward as mean with low variance
            mean = self._model.action_head(features)
            log_var = torch.full_like(mean, -4.0)
        return mean, log_var

    @torch.no_grad()
    def get_features(self, **kwargs) -> torch.Tensor:
        return self._model._encode_features(**kwargs)

    @property
    def action_dim(self) -> int:
        return self._model.action_space.action_dim

    @property
    def num_action_steps(self) -> int:
        return self._model.config.num_action_steps


# =============================================================================
# Distillation config
# =============================================================================


@dataclass
class DistillConfig:
    """Configuration for teacher-student distillation."""

    # Teacher
    teacher_path: str = ""  # Path to pre-trained teacher model
    use_mock_teacher: bool = True  # Use MockTeacher (for testing)
    teacher_feature_dim: int = 2048  # Feature dim of teacher (for mock)

    # Student
    student_config: TrainConfig = field(default_factory=TrainConfig)

    # Loss weights
    kl_weight: float = 1.0  # Weight for KL divergence loss
    mse_weight: float = 1.0  # Weight for MSE loss (action matching)
    feature_weight: float = 0.1  # Weight for feature alignment loss
    task_weight: float = 0.5  # Weight for ground-truth task loss

    # KL settings
    kl_temperature: float = 2.0  # Temperature for softening distributions
    kl_reduction: str = "batchmean"  # KL reduction method

    # Training
    epochs: int = 3
    learning_rate: float = 1e-4
    warmup_ratio: float = 0.1
    max_grad_norm: float = 0.5
    batch_size: int = 4

    # Feature alignment
    use_feature_alignment: bool = True
    feature_proj_dim: int = 512  # Project teacher/student features to this dim

    # Logging
    logging_steps: int = 10
    output_dir: str = "/tmp/neon_distill"


# =============================================================================
# Feature alignment module
# =============================================================================


class FeatureAligner(nn.Module):
    """Projects teacher and student features to a common space for alignment.

    Teacher features may be much larger (2048d) than student features (512d).
    This module projects both to a shared dimension and computes cosine
    similarity loss.
    """

    def __init__(self, teacher_dim: int, student_dim: int, proj_dim: int = 512):
        super().__init__()
        self.teacher_proj = nn.Linear(teacher_dim, proj_dim)
        self.student_proj = nn.Linear(student_dim, proj_dim)

    def forward(
        self, teacher_feat: torch.Tensor, student_feat: torch.Tensor
    ) -> torch.Tensor:
        """Compute feature alignment loss (1 - cosine_similarity).

        Args:
            teacher_feat: (batch, teacher_dim)
            student_feat: (batch, student_dim)

        Returns:
            Scalar alignment loss
        """
        t_proj = F.normalize(self.teacher_proj(teacher_feat), dim=-1)
        s_proj = F.normalize(self.student_proj(student_feat), dim=-1)
        # Cosine similarity → higher is better → loss = 1 - sim
        cos_sim = (t_proj * s_proj).sum(dim=-1)  # (batch,)
        return (1.0 - cos_sim).mean()


# =============================================================================
# Distillation Trainer
# =============================================================================


class DistillationTrainer:
    """Teacher-Student distillation trainer for Neon VLA.

    Combines three loss terms:
    1. KL divergence: match teacher's action distribution
    2. MSE: match teacher's action predictions directly
    3. Feature alignment: match intermediate representations (optional)
    4. Task loss: standard supervised loss on ground truth (optional)

    The student model is trained end-to-end while the teacher is frozen.
    """

    def __init__(self, config: DistillConfig):
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Build student model
        logger.info("Building student model...")
        self.student = NeonVLA(config.student_config.model)
        self.student.to(self.device)

        # Build teacher
        if config.use_mock_teacher:
            logger.info("Using MockTeacher (no real weights)")
            self.teacher = MockTeacher(
                action_dim=self.student.action_space.action_dim,
                num_action_steps=self.student.config.num_action_steps,
                feature_dim=config.teacher_feature_dim,
                device=str(self.device),
            )
        elif config.teacher_path:
            logger.info(f"Loading teacher from {config.teacher_path}")
            self.teacher = NeonTeacher(config.teacher_path, device=str(self.device))
        else:
            raise ValueError("Must set either use_mock_teacher=True or teacher_path")

        # Feature alignment module
        self.feature_aligner = None
        if config.use_feature_alignment:
            student_feat_dim = self.student.backbone.hidden_size
            teacher_feat_dim = config.teacher_feature_dim
            self.feature_aligner = FeatureAligner(
                teacher_dim=teacher_feat_dim,
                student_dim=student_feat_dim,
                proj_dim=config.feature_proj_dim,
            ).to(self.device)

        # Optimizer (student params + feature aligner params)
        trainable = list(self.student.parameters())
        if self.feature_aligner is not None:
            trainable.extend(self.feature_aligner.parameters())
        self.optimizer = torch.optim.AdamW(
            [p for p in trainable if p.requires_grad],
            lr=config.learning_rate,
            weight_decay=0.01,
        )

        # Print param counts
        student_params = sum(p.numel() for p in self.student.parameters() if p.requires_grad)
        logger.info(f"Student trainable params: {student_params:,}")

    def compute_kl_loss(
        self,
        student_mean: torch.Tensor,
        student_log_var: torch.Tensor,
        teacher_mean: torch.Tensor,
        teacher_log_var: torch.Tensor,
    ) -> torch.Tensor:
        """Compute KL divergence between student and teacher action distributions.

        Assumes diagonal Gaussian distributions for both teacher and student.
        KL(student || teacher) = 0.5 * sum(
            teacher_log_var - student_log_var
            + (student_var + (student_mean - teacher_mean)^2) / teacher_var
            - 1
        )

        Args:
            student_mean: (B, T, D)
            student_log_var: (B, T, D)
            teacher_mean: (B, T, D)
            teacher_log_var: (B, T, D)

        Returns:
            Scalar KL loss
        """
        temp = self.config.kl_temperature

        # Soften distributions by temperature
        s_var = (student_log_var / temp).exp()
        t_var = (teacher_log_var / temp).exp()

        kl = 0.5 * (
            teacher_log_var / temp - student_log_var / temp
            + (s_var + (student_mean - teacher_mean).pow(2)) / t_var.clamp(min=1e-8)
            - 1.0
        )
        return kl.mean()

    def compute_mse_loss(
        self,
        student_actions: torch.Tensor,
        teacher_actions: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Compute MSE between student and teacher action predictions.

        Args:
            student_actions: (B, T, D) student predicted actions
            teacher_actions: (B, T, D) teacher predicted actions
            mask: (B, T) optional mask for valid timesteps

        Returns:
            Scalar MSE loss
        """
        mse = (student_actions - teacher_actions).pow(2)
        if mask is not None:
            # Expand mask to match action dims
            mask_expanded = mask.unsqueeze(-1).expand_as(mse)
            mse = mse * mask_expanded
            return mse.sum() / mask_expanded.sum().clamp(min=1.0)
        return mse.mean()

    def distill_step(self, batch: Dict[str, Any]) -> Dict[str, float]:
        """Single distillation step.

        Args:
            batch: Training batch with images, text, proprio, target_actions, etc.

        Returns:
            Dict with loss breakdown
        """
        self.student.train()

        # Prepare inputs for teacher
        teacher_kwargs = {}
        if batch.get("proprioception") is not None:
            teacher_kwargs["proprioception"] = batch["proprioception"]

        # Get teacher predictions (frozen, no grad)
        with torch.no_grad():
            teacher_mean, teacher_log_var = self.teacher.get_action_distribution(
                **teacher_kwargs
            )
            if self.feature_aligner is not None:
                teacher_features = self.teacher.get_features(**teacher_kwargs)

        # Get student predictions
        # Encode student features
        student_proprio = batch.get("proprioception")
        student_features = self.student._encode_features(
            proprioception=student_proprio,
        )

        # Student action predictions
        if self.student.config.action_head_type in ("flow", "dit"):
            student_actions = self.student.action_head.sample(student_features)
        else:
            student_actions = self.student.action_head(student_features)

        # Student log-variance: for MLP heads, estimate from multiple forward passes
        # For simplicity, use a learned parameter or fixed low variance
        student_log_var = torch.full_like(student_actions, -3.0)

        # Ensure shapes match
        teacher_mean = teacher_mean.to(student_actions.device)
        teacher_log_var = teacher_log_var.to(student_actions.device)

        # Losses
        losses = {}

        # 1. KL divergence
        kl_loss = self.compute_kl_loss(
            student_actions, student_log_var,
            teacher_mean, teacher_log_var,
        )
        losses["kl_loss"] = kl_loss.item()

        # 2. MSE (action matching)
        mask = batch.get("action_masks")
        mse_loss = self.compute_mse_loss(student_actions, teacher_mean, mask)
        losses["mse_loss"] = mse_loss.item()

        # 3. Feature alignment (optional)
        feat_loss = torch.tensor(0.0, device=self.device)
        if self.feature_aligner is not None and teacher_features is not None:
            teacher_features = teacher_features.to(self.device)
            feat_loss = self.feature_aligner(teacher_features, student_features)
            losses["feature_loss"] = feat_loss.item()

        # 4. Task loss (ground truth, if available)
        task_loss = torch.tensor(0.0, device=self.device)
        if batch.get("target_actions") is not None and self.config.task_weight > 0:
            targets = batch["target_actions"]
            if self.student.config.action_head_type in ("flow", "dit"):
                task_loss = self.student.action_head.compute_loss(
                    student_features, targets, mask
                )
            else:
                task_loss = F.mse_loss(student_actions, targets)
            losses["task_loss"] = task_loss.item()

        # Total loss
        total_loss = (
            self.config.kl_weight * kl_loss
            + self.config.mse_weight * mse_loss
            + self.config.feature_weight * feat_loss
            + self.config.task_weight * task_loss
        )
        losses["total_loss"] = total_loss.item()

        # Backward + optimize
        total_loss.backward()
        if self.config.max_grad_norm > 0:
            torch.nn.utils.clip_grad_norm_(
                [p for p in self.student.parameters() if p.requires_grad],
                self.config.max_grad_norm,
            )
        self.optimizer.step()
        self.optimizer.zero_grad()

        return losses

    def distill(
        self, dataloader: Optional[DataLoader] = None, num_steps: int = 100
    ) -> Dict[str, Any]:
        """Run distillation loop.

        Args:
            dataloader: Training data loader (if None, uses synthetic data)
            num_steps: Number of distillation steps (if no dataloader)

        Returns:
            Training statistics
        """
        logger.info("Starting distillation...")

        loss_history = []
        global_step = 0

        if dataloader is not None:
            for epoch in range(self.config.epochs):
                for batch in dataloader:
                    losses = self.distill_step(batch)
                    loss_history.append(losses)
                    global_step += 1

                    if global_step % self.config.logging_steps == 0:
                        logger.info(
                            f"Step {global_step}: "
                            f"total={losses['total_loss']:.4f} "
                            f"kl={losses['kl_loss']:.4f} "
                            f"mse={losses['mse_loss']:.4f}"
                        )
        else:
            # Synthetic distillation (no real data — for testing)
            action_dim = self.student.action_space.action_dim
            num_steps_action = self.student.config.num_action_steps

            for step in range(num_steps):
                # Generate synthetic batch
                batch = {
                    "proprioception": torch.randn(
                        self.config.batch_size, action_dim, device=self.device
                    ),
                    "target_actions": torch.randn(
                        self.config.batch_size, num_steps_action, action_dim,
                        device=self.device,
                    ),
                    "action_masks": torch.ones(
                        self.config.batch_size, num_steps_action, device=self.device
                    ),
                }

                losses = self.distill_step(batch)
                loss_history.append(losses)
                global_step += 1

                if global_step % self.config.logging_steps == 0:
                    logger.info(
                        f"Step {global_step}/{num_steps}: "
                        f"total={losses['total_loss']:.4f} "
                        f"kl={losses['kl_loss']:.4f} "
                        f"mse={losses['mse_loss']:.4f}"
                    )

        stats = {
            "total_steps": global_step,
            "final_loss": loss_history[-1] if loss_history else {},
            "loss_history": loss_history,
        }

        logger.info(f"Distillation complete: {global_step} steps")
        return stats
