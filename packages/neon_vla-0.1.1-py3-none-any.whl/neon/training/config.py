"""
Training configuration for Neon VLA.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from neon.data.data_soup import DataSoupConfig, DataSourceConfig
from neon.model.neon_vla import NeonConfig


@dataclass
class TrainConfig:
    """Full training configuration."""

    # Model
    model: NeonConfig = field(default_factory=NeonConfig)

    # Data
    data: DataSoupConfig = field(default_factory=DataSoupConfig)

    # Training hyperparameters
    epochs: int = 3
    batch_size: int = 4
    gradient_accumulation_steps: int = 8
    learning_rate: float = 2e-4
    weight_decay: float = 0.01
    warmup_ratio: float = 0.1
    lr_scheduler: str = "cosine"
    max_grad_norm: float = 0.3  # Parameter Golf: tighter clipping for small heads

    # Optimization — Parameter Golf Adam betas for action prediction
    optim: str = "paged_adamw_8bit"
    adam_beta1: float = 0.85  # Lower β₁ — faster adaptation to shifting action distributions
    adam_beta2: float = 0.99  # Standard β₂ from MicroGPT engine
    bf16: bool = True
    gradient_checkpointing: bool = True

    # LoRA (for backbone fine-tuning, if not frozen)
    use_lora: bool = True
    lora_r: int = 32
    lora_alpha: int = 64
    lora_dropout: float = 0.05
    lora_target_modules: List[str] = field(
        default_factory=lambda: ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
    )

    # Saving
    output_dir: str = "/tmp/neon_output"
    hub_model_id: str = "cagataydev/neon-g1-v1"
    push_to_hub: bool = True
    save_steps: int = 500
    save_total_limit: int = 3

    # Logging
    logging_steps: int = 10
    report_to: str = "none"  # "wandb" for W&B

    # Hardware
    num_workers: int = 4
    seed: int = 42


def default_arms_only_config() -> TrainConfig:
    """Default config for arms-only training (tabletop manipulation).

    Uses Qwen2.5-Omni-7B with flash_attention_2 auto-detection.
    Audio is enabled via Omni's native encoder.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",  # Auto-falls back to eager
            ),
            control_mode="arms_only",
            include_locomotion=False,
            num_action_steps=16,
            use_action_chunking=True,
            audio={
                "enabled": True,
                "encoder_type": "omni",
                "enable_speech_output": False,
            },
        ),
        epochs=3,
        batch_size=4,
        learning_rate=2e-4,
    )


def default_wholebody_config() -> TrainConfig:
    """Default config for whole-body training (locomotion + manipulation).

    Uses Qwen2.5-Omni-7B with flash_attention_2 auto-detection.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="whole_body",
            include_locomotion=True,
            num_action_steps=16,
            use_action_chunking=True,
            audio={
                "enabled": True,
                "encoder_type": "omni",
                "enable_speech_output": False,
            },
        ),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=1e-4,
    )


def cosmos_physics_config() -> TrainConfig:
    """Config for physics-focused training with Cosmos-Reason2-8B.

    Best for sim2real transfer, physics-heavy manipulation, world model tasks.
    Uses Whisper encoder for audio (Cosmos doesn't have native audio).
    Requires A100 (40GB+).
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="nvidia/Cosmos-Reason2-8B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=True,
            num_action_steps=16,
            use_action_chunking=True,
            mlp_hidden=768,
            action_head_layers=4,
            audio={
                "enabled": True,
                "encoder_type": "whisper",
                "whisper_model": "openai/whisper-base",
                "freeze_encoder": True,
                "enable_speech_output": False,
            },
        ),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=1e-4,
        hub_model_id="cagataydev/neon-g1-cosmos-v1",
    )


def large_arms_config() -> TrainConfig:
    """Large action head config for maximum quality (~44M trainable).

    Action heads scaled to GR00T-Dreams territory:
    - mlp_hidden=2048 (4× default) — matches DiT hidden_size
    - action_head_layers=8 (2.7× default) — deeper reasoning
    - proprioception_hidden=512 — rich state encoding

    With 7B backbone: ~44M trainable params (action heads + fusion + proprio)
    GR00T-Dreams reference: ~42M in their FlowMatchingActionHead + DiT.

    Uses Qwen2.5-Omni-7B backbone. Requires A100 40GB+.
    This is the config for producing publication-quality results.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=True,
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=True,
            mlp_hidden=2048,            # 4× default — GR00T-Dreams scale
            action_head_layers=8,       # Deep heads for complex action prediction
            proprioception_hidden=512,  # Rich state encoding
            audio={
                "enabled": True,
                "encoder_type": "omni",
                "enable_speech_output": False,
            },
        ),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=1e-4,           # Lower LR for larger heads
        max_grad_norm=0.3,
        hub_model_id="cagataydev/neon-g1-large-v1",
    )


def large_cosmos_config() -> TrainConfig:
    """Large action head + Cosmos-Reason2-8B backbone (~44M trainable).

    Physics-grounded with GR00T-Dreams-scale action heads.
    Best for sim2real, physical reasoning tasks.
    Requires A100 40GB+.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="nvidia/Cosmos-Reason2-8B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=True,
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=True,
            mlp_hidden=2048,
            action_head_layers=8,
            proprioception_hidden=512,
            audio={
                "enabled": True,
                "encoder_type": "whisper",
                "whisper_model": "openai/whisper-base",
                "freeze_encoder": True,
                "enable_speech_output": False,
            },
        ),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=1e-4,
        hub_model_id="cagataydev/neon-g1-cosmos-large-v1",
    )


def large_wholebody_config() -> TrainConfig:
    """Large action head for whole-body (29 DoF) control (~55M trainable).

    GR00T-Dreams-scale heads for all 29 joints + locomotion.
    Needs A100 80GB due to:
    - 7B backbone (4-bit) + ~55M action heads
    - 32 DoF output (29 joints + 3 loco)
    - Action chunking (16 steps)
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="whole_body",
            include_locomotion=True,
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=True,
            mlp_hidden=2048,
            action_head_layers=8,
            proprioception_hidden=512,
            audio={
                "enabled": True,
                "encoder_type": "omni",
                "enable_speech_output": False,
            },
        ),
        epochs=5,
        batch_size=1,
        gradient_accumulation_steps=32,
        learning_rate=1e-4,
        hub_model_id="cagataydev/neon-g1-wholebody-large-v1",
    )


def edge_3b_config() -> TrainConfig:
    """Lightweight config for Jetson Orin / L4 deployment.

    Uses Qwen2.5-Omni-3B — smallest audio-native backbone.
    Fits in ~4GB VRAM (4-bit).
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-3B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=False,
            num_action_steps=8,
            use_action_chunking=True,
            mlp_hidden=256,
            action_head_layers=2,
            audio={
                "enabled": True,
                "encoder_type": "omni",
                "enable_speech_output": False,
            },
        ),
        epochs=3,
        batch_size=8,
        learning_rate=3e-4,
        hub_model_id="cagataydev/neon-g1-edge-v1",
    )


def flow_arms_only_config() -> TrainConfig:
    """Flow-matching action head config for arms-only tabletop manipulation.

    Replaces unimodal MSE with multi-modal flow matching — the single biggest
    upgrade path for action quality. Captures multiple valid action modes
    (e.g., reach-from-left vs reach-from-right) that MSE would average out.

    Key differences from default_arms_only_config:
    - action_head_type="flow" — FlowMatchingHead instead of MLP
    - flow_hidden_dim=512 — same as MLP hidden (1.3M params)
    - flow_num_denoise_steps=4 — fast Euler sampling at inference
    - flow_num_layers=4 — deeper than MLP (better velocity field)
    - Lower learning rate (1e-4) — flow matching needs smoother training
    - use_separate_heads=False — flow head handles all actions jointly

    Hardware: A100 40GB+ recommended. ~1.3M flow head params + 7B backbone (4-bit).
    Training: ~4h on 1xA100 for 3 epochs on 1K episodes.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=False,
            action_head_type="flow",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,  # Flow head handles all dims jointly
            flow_hidden_dim=512,
            flow_num_layers=4,
            flow_num_denoise_steps=4,
            proprioception_hidden=128,
            audio={
                "enabled": True,
                "encoder_type": "omni",
                "enable_speech_output": False,
            },
        ),
        epochs=3,
        batch_size=4,
        gradient_accumulation_steps=8,
        learning_rate=1e-4,  # Lower LR for flow matching stability
        warmup_ratio=0.15,   # Longer warmup — flow loss is noisy early on
        max_grad_norm=0.5,   # Slightly relaxed — flow gradients are smoother
        hub_model_id="cagataydev/neon-g1-flow-arms-v1",
    )


def dit_arms_only_config() -> TrainConfig:
    """DiT action head config for arms-only tabletop manipulation.

    Uses Diffusion Transformer (DiT) with adaLN conditioning — the same
    architecture family as GR00T N1.6. More expressive than FlowMatchingHead
    but ~2.5× more parameters (3.1M vs 1.3M).

    Key differences from flow_arms_only_config:
    - action_head_type="dit" — DiTActionHead (self-attention over action tokens)
    - dit_hidden_dim=384, dit_num_layers=8, dit_num_heads=6
    - DDIM sampling instead of Euler
    - Higher capacity → better for complex multi-modal distributions

    Hardware: A100 40GB+ recommended. ~3.1M DiT params + 7B backbone (4-bit).
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=False,
            action_head_type="dit",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,  # DiT handles all dims jointly
            dit_hidden_dim=384,
            dit_num_layers=8,
            dit_num_heads=6,
            dit_num_denoise_steps=4,
            proprioception_hidden=128,
            audio={
                "enabled": True,
                "encoder_type": "omni",
                "enable_speech_output": False,
            },
        ),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=1e-4,
        warmup_ratio=0.15,
        max_grad_norm=0.5,
        hub_model_id="cagataydev/neon-g1-dit-arms-v1",
    )



def synth_omnimodal_config() -> TrainConfig:
    """Training config mixing synthetic factory data with real teleop.

    The key insight: synthetic data from the Neon Synth Factory uses the
    EXACT same LeRobot v3 schema as real teleop data. DataSoup mixes them
    seamlessly with weighted sampling.

    Data sources (priority order):
    1. Real G1 teleop (weight=3.0) — ground truth, highest quality
    2. Synthetic factory (weight=2.0) — massive scale, all 6 modalities
    3. NVIDIA GR00T Teleop (weight=1.5) — real G1, different tasks
    4. Voice commands (weight=0.3) — language conditioning diversity

    Train with:
        python -m neon.training.train --config synth_omnimodal
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="whole_body",
            include_locomotion=True,
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=True,
            mlp_hidden=1024,
            action_head_layers=6,
            proprioception_hidden=256,
            audio={
                "enabled": True,
                "encoder_type": "omni",
                "enable_speech_output": False,
            },
            use_lidar=True,
            lidar_points=4096,
            lidar_hidden=128,
            use_eef=True,
            eef_dim=14,
            eef_hidden=64,
        ),
        data=DataSoupConfig(
            sources=[
                # REAL G1 teleop (highest weight — ground truth)
                DataSourceConfig(
                    name="g1_teleop_real",
                    type="g1_teleop",
                    path="s3://pick-basket-dataset/pick_basket_dataset/",
                    weight=3.0,
                    fps=4,
                ),
                # SYNTHETIC factory (high weight — massive scale, all modalities)
                DataSourceConfig(
                    name="synth_factory",
                    type="synthetic_factory",
                    path="cagataydev/neon-g1-synth-kitchen-10k",
                    weight=2.0,
                    fps=4,
                ),
                # NVIDIA GR00T real G1 teleop
                DataSourceConfig(
                    name="groot_teleop_g1",
                    type="groot_teleop",
                    path="nvidia/PhysicalAI-Robotics-GR00T-Teleop-G1",
                    weight=1.5,
                    max_episodes=500,
                    fps=4,
                ),
                # Language conditioning
                DataSourceConfig(
                    name="voice_commands",
                    type="voice_commands",
                    path="cagataydev/vlm-voice-commands",
                    weight=0.3,
                    max_samples=10000,
                ),
            ],
        ),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=1.5e-4,
        hub_model_id="cagataydev/neon-g1-synth-omnimodal-v1",
    )


def g1_omnimodal_config() -> TrainConfig:
    """Full omni-modal config with ALL sensor inputs enabled.

    Enables: camera + audio + LiDAR + EEF + proprioception.
    This is the config for G1 teleoperation data that has all modalities.
    Requires A100 40GB+ due to extra encoder parameters.

    Data sources:
    - Neon v3 omni-modal dataset (real G1 recordings with all sensors)
    - G1 teleop pick-basket dataset (proprioception + EEF, no lidar/audio)
    - NVIDIA GR00T Teleop G1 (real G1 teleoperation, 4 pick tasks)
    - NVIDIA GR00T X-Embodiment Sim (sim data with EEF, G1 task)
    - Voice commands (language conditioning)
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="whole_body",
            include_locomotion=True,
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=True,
            mlp_hidden=1024,
            action_head_layers=6,
            proprioception_hidden=256,
            audio={
                "enabled": True,
                "encoder_type": "omni",
                "enable_speech_output": False,
            },
            use_lidar=True,
            lidar_points=4096,
            lidar_hidden=128,
            use_eef=True,
            eef_dim=14,
            eef_hidden=64,
        ),
        data=DataSoupConfig(
            sources=[
                # PRIMARY: Neon v3 omni-modal (all sensors)
                DataSourceConfig(
                    name="neon_g1_omnimodal",
                    type="neon_v3",
                    path="cagataydev/neon-g1-omnimodal-v1",
                    weight=3.0,  # Highest weight — this is our richest data
                    fps=4,
                ),
                # NVIDIA GR00T Teleop G1: Real G1 teleoperation (4 tasks, ~1244 episodes)
                # 43-DOF joints + ego_view video @20fps. No EEF/lidar but real robot data.
                DataSourceConfig(
                    name="groot_teleop_g1",
                    type="groot_teleop",
                    path="nvidia/PhysicalAI-Robotics-GR00T-Teleop-G1",
                    weight=2.0,  # High weight — real G1 data
                    max_episodes=500,
                    fps=4,
                ),
                # NVIDIA X-Embodiment Sim G1: Sim with EEF state (14D bimanual)
                # 43-DOF + EEF + sim state @50fps. Only G1 task: unitree_g1.LMPnPAppleToPlateDC
                DataSourceConfig(
                    name="groot_xembodiment_g1",
                    type="groot_teleop",
                    path="nvidia/PhysicalAI-Robotics-GR00T-X-Embodiment-Sim",
                    weight=1.5,
                    camera_ids=["unitree_g1"],  # Only load G1 sub-dataset
                    fps=4,
                ),
                # G1 teleop (proprio + EEF, no lidar/audio)
                DataSourceConfig(
                    name="g1_teleop_basket",
                    type="g1_teleop",
                    path="s3://pick-basket-dataset/pick_basket_dataset/",
                    weight=1.0,
                    max_episodes=200,
                    fps=4,
                ),
                # Language conditioning
                DataSourceConfig(
                    name="voice_commands",
                    type="voice_commands",
                    path="cagataydev/vlm-voice-commands",
                    weight=0.3,
                    max_samples=10000,
                ),
            ],
        ),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=1.5e-4,
        hub_model_id="cagataydev/neon-g1-omnimodal-v1",
    )


def flow_wholebody_config() -> TrainConfig:
    """Flow-matching head for whole-body (29 DoF) control with BONES-SEED data.

    Combines:
    - FlowMatchingHead — multi-modal action distributions for complex whole-body
    - whole_body control mode (29 DoF = 12 legs + 3 waist + 14 arms)
    - BONES-SEED data (142K whole-body motions for G1, native format)
    - NVIDIA GR00T teleop (real G1 data)
    - Voice commands (language conditioning)

    Key design decisions:
    - Flow head handles ALL 29 DoF jointly (no separate heads) — this is
      critical because whole-body motions have strong joint correlations
      (e.g., arm swing during walking, balance adjustments during reaching)
    - BONES-SEED weight=3.0 — it has by far the most whole-body motion diversity
    - Locomotion enabled — walking, turning, crouching
    - Lower LR (8e-5) — more joints → higher loss landscape curvature

    Hardware: A100 40GB+ recommended. ~1.3M flow params + 7B backbone (4-bit).
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="whole_body",
            include_locomotion=True,
            action_head_type="flow",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,  # Flow handles all 29 DoF jointly
            flow_hidden_dim=512,
            flow_num_layers=4,
            flow_num_denoise_steps=4,
            proprioception_hidden=256,  # Richer proprio for 29 DoF
            audio={
                "enabled": True,
                "encoder_type": "omni",
                "enable_speech_output": False,
            },
        ),
        data=DataSoupConfig(
            sources=[
                # BONES-SEED: 142K whole-body motions (native G1)
                DataSourceConfig(
                    name="bones_seed",
                    type="bones_seed",
                    path="cagataydev/bones-seed-g1",
                    weight=3.0,  # Highest — best wholebody coverage
                    fps=4,
                ),
                # NVIDIA GR00T Teleop G1: Real robot data
                DataSourceConfig(
                    name="groot_teleop_g1",
                    type="groot_teleop",
                    path="nvidia/PhysicalAI-Robotics-GR00T-Teleop-G1",
                    weight=2.0,
                    max_episodes=500,
                    fps=4,
                ),
                # G1 teleop basket (real data)
                DataSourceConfig(
                    name="g1_teleop_basket",
                    type="g1_teleop",
                    path="s3://pick-basket-dataset/pick_basket_dataset/",
                    weight=1.5,
                    max_episodes=200,
                    fps=4,
                ),
                # Language conditioning
                DataSourceConfig(
                    name="voice_commands",
                    type="voice_commands",
                    path="cagataydev/vlm-voice-commands",
                    weight=0.3,
                    max_samples=10000,
                ),
            ],
        ),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=8e-5,   # Lower LR for whole-body flow matching
        warmup_ratio=0.15,
        max_grad_norm=0.5,
        hub_model_id="cagataydev/neon-g1-flow-wholebody-v1",
    )


def omnimodal_9_config() -> TrainConfig:
    """ALL 9 modalities enabled: vision + language + audio + proprioception +
    LiDAR + EEF + GPS + depth + segmentation.

    This is the ultimate configuration — uses every sensor and encoder
    that Neon supports. Designed for maximum benchmark performance when
    all modalities are available.

    The 9 modalities:
    1. Vision (camera RGB) — Qwen2.5-Omni backbone
    2. Language (text instructions) — Qwen2.5-Omni backbone
    3. Audio (spoken commands) — Omni native audio encoder
    4. Proprioception (29-43 DoF joint state) — ProprioceptionEncoder
    5. LiDAR (4096-point cloud) — PointCloudEncoder
    6. EEF (14D bimanual pos+quat) — EEFEncoder
    7. GPS (6D lat/lon/alt/heading/pitch/roll) — GPSEncoder
    8. Depth (monocular depth map) — DepthEncoder
    9. Segmentation (semantic mask) — SegmentationEncoder

    Fusion dim with all modalities:
    = backbone(3584) + proprio(512) + audio(3584) + lidar(256)
      + eef(128) + gps(64) + depth(128) + seg(128)
    ≈ 8384 → fused to backbone_hidden via linear projection

    Hardware: A100 80GB recommended due to all encoders active.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="whole_body",
            include_locomotion=True,
            action_head_type="flow",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,
            flow_hidden_dim=512,
            flow_num_layers=4,
            flow_num_denoise_steps=4,
            proprioception_hidden=256,
            # Audio (modality 3)
            audio={
                "enabled": True,
                "encoder_type": "omni",
                "enable_speech_output": False,
            },
            # LiDAR (modality 5)
            use_lidar=True,
            lidar_points=4096,
            lidar_hidden=128,
            # EEF (modality 6)
            use_eef=True,
            eef_dim=14,
            eef_hidden=64,
            # GPS (modality 7)
            use_gps=True,
            gps_dim=6,
            gps_hidden=32,
            # Depth (modality 8)
            use_depth=True,
            depth_hidden=64,
            # Segmentation (modality 9)
            use_segmentation=True,
            seg_num_classes=20,
            seg_hidden=64,
        ),
        data=DataSoupConfig(
            sources=[
                # Neon v3 omni-modal (has all modalities)
                DataSourceConfig(
                    name="neon_g1_omnimodal",
                    type="neon_v3",
                    path="cagataydev/neon-g1-omnimodal-v1",
                    weight=3.0,
                    fps=4,
                ),
                # Synthetic factory (sim with depth + seg + GPS)
                DataSourceConfig(
                    name="synth_factory_omni",
                    type="synthetic_factory",
                    path="cagataydev/neon-g1-synth-omni-10k",
                    weight=2.5,
                    fps=4,
                ),
                # BONES-SEED (whole-body motions)
                DataSourceConfig(
                    name="bones_seed",
                    type="bones_seed",
                    path="cagataydev/bones-seed-g1",
                    weight=2.0,
                    fps=4,
                ),
                # NVIDIA GR00T Teleop G1
                DataSourceConfig(
                    name="groot_teleop_g1",
                    type="groot_teleop",
                    path="nvidia/PhysicalAI-Robotics-GR00T-Teleop-G1",
                    weight=1.5,
                    max_episodes=500,
                    fps=4,
                ),
                # Voice commands
                DataSourceConfig(
                    name="voice_commands",
                    type="voice_commands",
                    path="cagataydev/vlm-voice-commands",
                    weight=0.3,
                    max_samples=10000,
                ),
            ],
        ),
        epochs=5,
        batch_size=1,  # Small batch — large fusion dim
        gradient_accumulation_steps=32,
        learning_rate=8e-5,
        warmup_ratio=0.15,
        max_grad_norm=0.5,
        hub_model_id="cagataydev/neon-g1-omnimodal-9-v1",
    )


# =============================================================================
# NEXT.md Week 1 Training Configs — 7 new model variants
# =============================================================================


def neon_nano_config() -> TrainConfig:
    """Neon-Nano: 3B backbone + 3M MLP head. Cheapest useful model.

    bridge+droid only — no sim data. Train on RTX 3090 in ~4h.
    This is the "can it work at all?" baseline.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-3B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=False,
            action_head_type="mlp",
            num_action_steps=16,
            use_action_chunking=True,
            mlp_hidden=256,
            action_head_layers=2,
            use_separate_heads=True,
            audio={"enabled": True, "encoder_type": "omni", "enable_speech_output": False},
        ),
        data=DataSoupConfig(sources=[
            DataSourceConfig(name="bridge", type="lerobot", path="lerobot/bridge_orig", weight=0.6),
            DataSourceConfig(name="droid", type="lerobot", path="lerobot/droid", weight=0.3),
            DataSourceConfig(name="voice", type="voice_commands", path="cagataydev/vlm-voice-commands", weight=0.1),
        ]),
        epochs=3,
        batch_size=8,
        learning_rate=3e-4,
        hub_model_id="cagataydev/neon-nano-v0.2",
    )


def neon_base_flow_config() -> TrainConfig:
    """Neon-Base-Flow: 7B backbone + 4M FlowMatchingHead. Full data mix.

    The "standard quality" model — flow matching for multi-modal actions,
    trained on the full neon_v0.2_mix dataset. A100 40GB, ~8h.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=True,
            action_head_type="flow",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,
            flow_hidden_dim=512,
            flow_num_layers=4,
            flow_num_denoise_steps=4,
            proprioception_hidden=128,
            audio={"enabled": True, "encoder_type": "omni", "enable_speech_output": False},
        ),
        data=DataSoupConfig(sources=[
            DataSourceConfig(name="bridge", type="lerobot", path="lerobot/bridge_orig", weight=0.15),
            DataSourceConfig(name="droid", type="lerobot", path="lerobot/droid", weight=0.10),
            DataSourceConfig(name="agibot", type="agibot", path="lerobot/xvla-agibot-world", weight=0.15),
            DataSourceConfig(name="kitchen_10k", type="neon_v3", path="cagataydev/neon-g1-kitchen-10k", weight=0.20),
            DataSourceConfig(name="diverse_50k", type="neon_v3", path="cagataydev/neon-g1-diverse-50k", weight=0.15),
            DataSourceConfig(name="bones_seed", type="bones_seed", path="cagataydev/neon-g1-bones-seed-142k", weight=0.10),
            DataSourceConfig(name="loco_20k", type="neon_v3", path="cagataydev/neon-g1-locomotion-20k", weight=0.05),
            DataSourceConfig(name="cosmos_10k", type="neon_v3", path="cagataydev/neon-g1-cosmos-10k", weight=0.05),
            DataSourceConfig(name="voice", type="voice_commands", path="cagataydev/vlm-voice-commands", weight=0.03),
            DataSourceConfig(name="voice_audio", type="voice_commands", path="cagataydev/vlm-voice-audio", weight=0.02),
        ]),
        epochs=3,
        batch_size=4,
        gradient_accumulation_steps=8,
        learning_rate=1e-4,
        warmup_ratio=0.15,
        max_grad_norm=0.5,
        hub_model_id="cagataydev/neon-base-flow-v0.2",
    )


def neon_dit_config() -> TrainConfig:
    """Neon-DiT: 7B backbone + 6M DiT 8-layer head. Full data mix.

    Highest capacity single-head model. DiT with adaLN conditioning.
    A100 80GB, ~12h.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=True,
            action_head_type="dit",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,
            dit_hidden_dim=384,
            dit_num_layers=8,
            dit_num_heads=6,
            dit_num_denoise_steps=4,
            proprioception_hidden=128,
            audio={"enabled": True, "encoder_type": "omni", "enable_speech_output": False},
        ),
        data=DataSoupConfig(sources=[
            DataSourceConfig(name="bridge", type="lerobot", path="lerobot/bridge_orig", weight=0.15),
            DataSourceConfig(name="droid", type="lerobot", path="lerobot/droid", weight=0.10),
            DataSourceConfig(name="agibot", type="agibot", path="lerobot/xvla-agibot-world", weight=0.15),
            DataSourceConfig(name="kitchen_10k", type="neon_v3", path="cagataydev/neon-g1-kitchen-10k", weight=0.20),
            DataSourceConfig(name="diverse_50k", type="neon_v3", path="cagataydev/neon-g1-diverse-50k", weight=0.15),
            DataSourceConfig(name="bones_seed", type="bones_seed", path="cagataydev/neon-g1-bones-seed-142k", weight=0.10),
            DataSourceConfig(name="cosmos_10k", type="neon_v3", path="cagataydev/neon-g1-cosmos-10k", weight=0.05),
            DataSourceConfig(name="voice", type="voice_commands", path="cagataydev/vlm-voice-commands", weight=0.03),
        ]),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=1e-4,
        warmup_ratio=0.15,
        max_grad_norm=0.5,
        hub_model_id="cagataydev/neon-dit-v0.2",
    )


def neon_cosmos_flow_config() -> TrainConfig:
    """Neon-Cosmos-Flow: Cosmos-Reason2-8B + FlowMatchingHead. Physics focus.

    Uses Cosmos backbone which has superior physics understanding from
    video prediction pre-training. Best for sim2real and physics-heavy tasks.
    L40S 46GB, ~10h.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="nvidia/Cosmos-Reason2-8B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=True,
            action_head_type="flow",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,
            flow_hidden_dim=512,
            flow_num_layers=4,
            flow_num_denoise_steps=4,
            proprioception_hidden=128,
            audio={"enabled": True, "encoder_type": "whisper", "whisper_model": "openai/whisper-base", "freeze_encoder": True, "enable_speech_output": False},
        ),
        data=DataSoupConfig(sources=[
            DataSourceConfig(name="bridge", type="lerobot", path="lerobot/bridge_orig", weight=0.15),
            DataSourceConfig(name="droid", type="lerobot", path="lerobot/droid", weight=0.10),
            DataSourceConfig(name="kitchen_10k", type="neon_v3", path="cagataydev/neon-g1-kitchen-10k", weight=0.25),
            DataSourceConfig(name="diverse_50k", type="neon_v3", path="cagataydev/neon-g1-diverse-50k", weight=0.20),
            DataSourceConfig(name="cosmos_10k", type="neon_v3", path="cagataydev/neon-g1-cosmos-10k", weight=0.15),
            DataSourceConfig(name="bones_seed", type="bones_seed", path="cagataydev/neon-g1-bones-seed-142k", weight=0.10),
            DataSourceConfig(name="voice", type="voice_commands", path="cagataydev/vlm-voice-commands", weight=0.05),
        ]),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=1e-4,
        hub_model_id="cagataydev/neon-cosmos-flow-v0.2",
    )


def neon_ensemble_config() -> TrainConfig:
    """Neon-Ensemble: 7B backbone + gated MLP+Flow+DiT (~13M trainable).

    Best of all worlds — learned gate routes to the optimal head per task.
    Most expensive to train but should yield best benchmark numbers.
    A100 80GB, ~16h.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=True,
            action_head_type="ensemble",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,
            proprioception_hidden=256,
            audio={"enabled": True, "encoder_type": "omni", "enable_speech_output": False},
        ),
        data=DataSoupConfig(sources=[
            DataSourceConfig(name="bridge", type="lerobot", path="lerobot/bridge_orig", weight=0.15),
            DataSourceConfig(name="droid", type="lerobot", path="lerobot/droid", weight=0.10),
            DataSourceConfig(name="agibot", type="agibot", path="lerobot/xvla-agibot-world", weight=0.15),
            DataSourceConfig(name="kitchen_10k", type="neon_v3", path="cagataydev/neon-g1-kitchen-10k", weight=0.20),
            DataSourceConfig(name="diverse_50k", type="neon_v3", path="cagataydev/neon-g1-diverse-50k", weight=0.15),
            DataSourceConfig(name="bones_seed", type="bones_seed", path="cagataydev/neon-g1-bones-seed-142k", weight=0.10),
            DataSourceConfig(name="cosmos_10k", type="neon_v3", path="cagataydev/neon-g1-cosmos-10k", weight=0.05),
            DataSourceConfig(name="voice", type="voice_commands", path="cagataydev/vlm-voice-commands", weight=0.03),
        ]),
        epochs=5,
        batch_size=1,
        gradient_accumulation_steps=32,
        learning_rate=8e-5,
        warmup_ratio=0.15,
        max_grad_norm=0.3,
        hub_model_id="cagataydev/neon-ensemble-v0.2",
    )


def neon_omni_12_config() -> TrainConfig:
    """Neon-Omni: 7B + Flow + ALL 12+ modalities. The flagship model.

    Every sensor Neon supports: vision, language, audio, proprio, LiDAR,
    EEF, GPS, depth, segmentation, tactile, IMU, force.
    Requires synthetic data with all modalities. A100 80GB, ~12h.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="whole_body",
            include_locomotion=True,
            action_head_type="flow",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,
            flow_hidden_dim=512,
            flow_num_layers=4,
            flow_num_denoise_steps=4,
            proprioception_hidden=256,
            audio={"enabled": True, "encoder_type": "omni", "enable_speech_output": False},
            use_lidar=True, lidar_points=4096, lidar_hidden=128,
            use_eef=True, eef_dim=14, eef_hidden=64,
            use_gps=True, gps_dim=6, gps_hidden=32,
            use_depth=True, depth_hidden=64,
            use_segmentation=True, seg_num_classes=20, seg_hidden=64,
            use_tactile=True, tactile_num_links=14, tactile_ft_dim=6, tactile_hidden=32,
            use_imu=True, imu_dim=9, imu_hidden=16,
            use_force=True, force_dim=6, force_hidden=16,
        ),
        data=DataSoupConfig(sources=[
            DataSourceConfig(name="kitchen_10k", type="neon_v3", path="cagataydev/neon-g1-kitchen-10k", weight=0.25),
            DataSourceConfig(name="diverse_50k", type="neon_v3", path="cagataydev/neon-g1-diverse-50k", weight=0.20),
            DataSourceConfig(name="tactile_5k", type="neon_v3", path="cagataydev/neon-g1-tactile-5k", weight=0.15),
            DataSourceConfig(name="imu_nav_10k", type="neon_v3", path="cagataydev/neon-g1-imu-nav-10k", weight=0.10),
            DataSourceConfig(name="bones_seed", type="bones_seed", path="cagataydev/neon-g1-bones-seed-142k", weight=0.10),
            DataSourceConfig(name="cosmos_10k", type="neon_v3", path="cagataydev/neon-g1-cosmos-10k", weight=0.10),
            DataSourceConfig(name="voice", type="voice_commands", path="cagataydev/vlm-voice-commands", weight=0.05),
            DataSourceConfig(name="voice_audio", type="voice_commands", path="cagataydev/vlm-voice-audio", weight=0.05),
        ]),
        epochs=5,
        batch_size=1,
        gradient_accumulation_steps=32,
        learning_rate=8e-5,
        warmup_ratio=0.15,
        max_grad_norm=0.5,
        hub_model_id="cagataydev/neon-omni-v0.2",
    )


def neon_wholebody_flow_config() -> TrainConfig:
    """Neon-Wholebody-Flow: 7B + Flow + 29 DoF + BONES-SEED + locomotion.

    Full whole-body control with flow matching. Uses BONES-SEED as primary
    data source for motion diversity, plus locomotion-specific data.
    A100 80GB, ~12h.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="whole_body",
            include_locomotion=True,
            action_head_type="flow",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,
            flow_hidden_dim=512,
            flow_num_layers=4,
            flow_num_denoise_steps=4,
            proprioception_hidden=256,
            audio={"enabled": True, "encoder_type": "omni", "enable_speech_output": False},
            use_imu=True, imu_dim=9, imu_hidden=16,
        ),
        data=DataSoupConfig(sources=[
            DataSourceConfig(name="bones_seed", type="bones_seed", path="cagataydev/neon-g1-bones-seed-142k", weight=0.30),
            DataSourceConfig(name="loco_20k", type="neon_v3", path="cagataydev/neon-g1-locomotion-20k", weight=0.20),
            DataSourceConfig(name="kitchen_10k", type="neon_v3", path="cagataydev/neon-g1-kitchen-10k", weight=0.15),
            DataSourceConfig(name="diverse_50k", type="neon_v3", path="cagataydev/neon-g1-diverse-50k", weight=0.15),
            DataSourceConfig(name="groot_teleop", type="groot_teleop", path="nvidia/PhysicalAI-Robotics-GR00T-Teleop-G1", weight=0.10, fps=4),
            DataSourceConfig(name="voice", type="voice_commands", path="cagataydev/vlm-voice-commands", weight=0.05),
            DataSourceConfig(name="kimodo_g1", type="kimodo", path="cagataydev/neon-g1-kimodo-loco-20k", weight=0.05),
        ]),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=8e-5,
        warmup_ratio=0.15,
        max_grad_norm=0.5,
        hub_model_id="cagataydev/neon-wholebody-flow-v0.2",
    )



def neon_multi_embodiment_flow_config() -> TrainConfig:
    """Neon-MultiEmbodiment: 7B + Flow + Beta noise + 4 embodiments.

    Adapted from GR00T N1.6: train one model across multiple robot platforms
    using CategorySpecificLinear per-embodiment weights. Beta distribution
    noise scheduling concentrates training on harder noise levels.

    Embodiments: G1 (0), Franka (1), DROID (2), GR1 (3)
    A100 80GB, ~12h.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=True,
            action_head_type="flow",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,
            flow_hidden_dim=512,
            flow_num_layers=4,
            flow_num_denoise_steps=4,
            proprioception_hidden=256,
            audio={"enabled": True, "encoder_type": "omni", "enable_speech_output": False},
            # GR00T N1.6 features
            num_embodiments=4,
            noise_beta_alpha=1.5,
            noise_beta_beta=1.0,
        ),
        data=DataSoupConfig(sources=[
            # G1 native (embodiment_id=0)
            DataSourceConfig(name="kitchen_10k", type="neon_v3", path="cagataydev/neon-g1-kitchen-10k", weight=0.20),
            DataSourceConfig(name="diverse_50k", type="neon_v3", path="cagataydev/neon-g1-diverse-50k", weight=0.15),
            # Cross-embodiment (mapped to G1, embodiment_id varies by source)
            DataSourceConfig(name="bridge", type="lerobot", path="lerobot/bridge_orig", weight=0.15),
            DataSourceConfig(name="droid", type="lerobot", path="lerobot/droid", weight=0.15),
            DataSourceConfig(name="agibot", type="agibot", path="lerobot/xvla-agibot-world", weight=0.15),
            DataSourceConfig(name="bones_seed", type="bones_seed", path="cagataydev/neon-g1-bones-seed-142k", weight=0.10),
            DataSourceConfig(name="voice", type="voice_commands", path="cagataydev/vlm-voice-commands", weight=0.05),
            DataSourceConfig(name="groot_teleop", type="groot_teleop", path="nvidia/PhysicalAI-Robotics-GR00T-Teleop-G1", weight=0.05, fps=4),
        ]),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=8e-5,
        warmup_ratio=0.15,
        max_grad_norm=0.3,
        hub_model_id="cagataydev/neon-multi-embodiment-flow-v0.2",
    )


def neon_photon_3b_config() -> TrainConfig:
    """Neon-Photon-3B: Co-designed backbone + heads — Moondream Photon style.

    KEY INSIGHT from Photon: Don't freeze the backbone. Co-train a smaller
    backbone end-to-end with the action heads. A 3B model co-trained beats
    a frozen 7B because every layer optimizes for action prediction.

    Changes from standard Neon:
    - freeze_backbone=False — backbone learns action-relevant features
    - LoRA r=64 — high-rank for maximum expressiveness during co-training
    - flow head — multi-modal actions benefit most from co-training
    - Lower LR (5e-5) — co-training needs careful learning rate balance
    - Gradient checkpointing — saves memory for unfrozen backbone

    Performance target: 50Hz on Jetson Orin with Photon inference engine.
    VRAM: ~8GB (3B 4-bit + LoRA + flow head).
    Training: A100 40GB, ~6h.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-3B",
                load_in_4bit=True,
                freeze_backbone=False,  # PHOTON: co-train backbone
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=True,
            action_head_type="flow",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,
            flow_hidden_dim=384,
            flow_num_layers=4,
            flow_num_denoise_steps=4,
            proprioception_hidden=128,
            audio={"enabled": True, "encoder_type": "omni", "enable_speech_output": False},
        ),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=5e-5,  # Lower LR for co-training stability
        warmup_ratio=0.2,    # Longer warmup — backbone needs gentle start
        max_grad_norm=0.3,
        gradient_checkpointing=True,  # Memory savings for unfrozen backbone
        # LoRA for co-training (high rank)
        use_lora=True,
        lora_r=64,
        lora_alpha=128,
        lora_dropout=0.05,
        hub_model_id="cagataydev/neon-photon-3b-v0.1",
    )


def neon_photon_7b_config() -> TrainConfig:
    """Neon-Photon-7B: Co-designed 7B backbone — maximum quality Photon style.

    Like Photon-3B but with 7B backbone for highest action quality.
    The co-training effect is even stronger at 7B because the backbone
    has more capacity to learn action-relevant representations.

    Key differences from standard large_arms_config:
    - Backbone is UNFROZEN (LoRA r=64) — learns what matters for actions
    - Flow head instead of MLP — captures multi-modal action distributions
    - Joint training means features are directly optimized for action prediction

    Hardware: A100 80GB required (unfrozen 7B + LoRA + flow head).
    Training: ~12h.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=False,  # PHOTON: co-train backbone
                attn_implementation="flash_attention_2",
            ),
            control_mode="arms_only",
            include_locomotion=True,
            action_head_type="flow",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,
            flow_hidden_dim=512,
            flow_num_layers=4,
            flow_num_denoise_steps=4,
            proprioception_hidden=256,
            audio={"enabled": True, "encoder_type": "omni", "enable_speech_output": False},
        ),
        epochs=5,
        batch_size=1,
        gradient_accumulation_steps=32,
        learning_rate=3e-5,  # Even lower for 7B co-training
        warmup_ratio=0.2,
        max_grad_norm=0.3,
        gradient_checkpointing=True,
        use_lora=True,
        lora_r=64,
        lora_alpha=128,
        lora_dropout=0.05,
        hub_model_id="cagataydev/neon-photon-7b-v0.1",
    )


def neon_kimodo_loco_config() -> TrainConfig:
    """Neon-Kimodo-Loco: 7B + Flow + Kimodo G1 motion data + locomotion.

    Uses NVIDIA Kimodo text→G1 motion generation as primary data source.
    Kimodo provides G1-native joint trajectories from text prompts —
    no retargeting needed. Combined with BONES-SEED + locomotion data.
    A100 40GB, ~8h.
    """
    return TrainConfig(
        model=NeonConfig(
            backbone=__import__("neon.model.video_backbone", fromlist=["BackboneConfig"]).BackboneConfig(
                model_id="Qwen/Qwen2.5-Omni-7B",
                load_in_4bit=True,
                freeze_backbone=True,
                attn_implementation="flash_attention_2",
            ),
            control_mode="whole_body",
            include_locomotion=True,
            action_head_type="flow",
            num_action_steps=16,
            use_action_chunking=True,
            use_separate_heads=False,
            flow_hidden_dim=512,
            flow_num_layers=4,
            flow_num_denoise_steps=4,
            proprioception_hidden=256,
            use_imu=True, imu_dim=9, imu_hidden=16,
            noise_beta_alpha=1.5,
            noise_beta_beta=1.0,
        ),
        data=DataSoupConfig(sources=[
            DataSourceConfig(name="kimodo_g1", type="kimodo", path="cagataydev/neon-g1-kimodo-50k", weight=0.30),
            DataSourceConfig(name="kimodo_loco", type="kimodo", path="cagataydev/neon-g1-kimodo-loco-20k", weight=0.20),
            DataSourceConfig(name="bones_seed", type="bones_seed", path="cagataydev/neon-g1-bones-seed-142k", weight=0.20),
            DataSourceConfig(name="loco_20k", type="neon_v3", path="cagataydev/neon-g1-locomotion-20k", weight=0.15),
            DataSourceConfig(name="groot_teleop", type="groot_teleop", path="nvidia/PhysicalAI-Robotics-GR00T-Teleop-G1", weight=0.10, fps=4),
            DataSourceConfig(name="voice", type="voice_commands", path="cagataydev/vlm-voice-commands", weight=0.05),
        ]),
        epochs=5,
        batch_size=2,
        gradient_accumulation_steps=16,
        learning_rate=8e-5,
        warmup_ratio=0.15,
        max_grad_norm=0.5,
        hub_model_id="cagataydev/neon-kimodo-loco-v0.2",
    )

