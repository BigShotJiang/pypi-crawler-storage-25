"""
NeonSelfLearner — Online Self-Supervised Adaptation During Deployment.

The core idea: a frozen video backbone that understands physics can serve as
BOTH the perception system AND the reward/critic model. No human labels needed.

== The Self-Learning Loop ==

    1. SNAPSHOT: Encode observation before action → f_before
    2. PREDICT:  Forward model predicts expected outcome features → f_predicted
    3. ACT:      Execute action chunk (16 steps)
    4. OBSERVE:  Encode observation after action → f_after
    5. LEARN:    Compute self-supervised losses:
       a) Outcome Prediction Loss: ||f_predicted - f_after||²
       b) Temporal Coherence Loss: cosine(f_after - f_before, instruction_embedding)
       c) Action Consistency Loss: re-encode trajectory → should predict same actions
    6. UPDATE:   Backprop through action heads only (backbone stays frozen)
    7. PROTECT:  EWC regularization prevents catastrophic forgetting

== What Makes This Novel ==

Unlike Test-Time Training (Sun et al. 2020) which uses self-supervised objectives
on the INPUT (e.g., rotation prediction), we use self-supervised objectives on
the OUTCOME — measuring whether the robot's actions produced the intended physical
effect in the world. The video backbone's physics understanding is the "free" reward.

Unlike RLHF/PPO, there's no separate reward model. The backbone IS the reward model.
Unlike DAgger, there's no human expert in the loop.
Unlike hindsight relabeling alone, we also predict and verify outcomes.

This is closest to "Autonomous Improvement of Robot Policies" (Chebotar et al. 2021)
but instead of training a separate success classifier, we leverage the backbone's
pre-trained physics understanding as a zero-shot critic.

== Safety ==

- Confidence gating: only learn from high-confidence assessments
- EWC regularization: Fisher Information Matrix protects critical weights
- Learning rate warmup: start conservative, increase as confidence grows
- Replay buffer: prioritized by surprise (novel situations → faster learning)
- Rollback: checkpoint before each adaptation, revert if performance drops

References:
    - Sun et al. "Test-Time Training with Self-Supervision" (NeurIPS 2020)
    - Sun et al. "Learning to (Learn at Test Time)" (ICML 2024) — TTT layers
    - Chebotar et al. "Autonomous Improvement" (CoRL 2021)
    - Kirkpatrick et al. "Overcoming Catastrophic Forgetting" (EWC, PNAS 2017)
    - Hansen et al. "TD-MPC2: Scalable, Robust World Models" (ICLR 2024)
"""

from __future__ import annotations

import copy
import logging
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)


# =============================================================================
# Configuration
# =============================================================================


class AdaptationStrategy(Enum):
    """How aggressively to self-learn."""
    CONSERVATIVE = "conservative"  # Only learn from very confident assessments
    BALANCED = "balanced"          # Default — moderate confidence threshold
    AGGRESSIVE = "aggressive"      # Learn from most experiences


@dataclass
class SelfLearnerConfig:
    """Configuration for online self-supervised adaptation."""

    # Core learning
    enabled: bool = True
    learning_rate: float = 1e-5          # Very small — we're fine-tuning
    lr_warmup_steps: int = 50            # Warm up over first 50 interactions
    max_lr: float = 5e-5                 # Peak LR after warmup
    strategy: str = "balanced"           # conservative, balanced, aggressive

    # Confidence gating
    confidence_threshold: float = 0.6    # Only learn when backbone confidence > this
    min_feature_change: float = 0.01     # Skip if observation barely changed (robot didn't move)
    max_feature_change: float = 5.0      # Skip if observation changed too much (scene cut/glitch)

    # Loss weights
    w_outcome: float = 1.0              # Outcome prediction loss weight
    w_coherence: float = 0.5            # Temporal coherence loss weight
    w_consistency: float = 0.3          # Action consistency loss weight
    w_ewc: float = 1000.0              # EWC regularization weight (high = conservative)

    # Replay buffer
    buffer_size: int = 1000             # Max experiences to store
    batch_size: int = 8                 # Mini-batch for replay updates
    replay_every: int = 10              # Replay every N online updates
    priority_alpha: float = 0.6         # Prioritization exponent (0=uniform, 1=full priority)

    # Safety
    max_grad_norm: float = 1.0          # Gradient clipping
    checkpoint_every: int = 50          # Save checkpoint every N updates
    rollback_threshold: float = 0.2     # Rollback if loss increases by this fraction
    max_updates_without_improvement: int = 100  # Stop adapting after N stale updates

    # Forward model (outcome predictor)
    forward_model_hidden: int = 512     # Hidden dim of the outcome predictor MLP
    forward_model_layers: int = 3       # Depth of outcome predictor

    # Logging
    log_every: int = 10                 # Log metrics every N updates


# =============================================================================
# Experience Replay Buffer
# =============================================================================


@dataclass
class Experience:
    """A single self-learning experience."""
    features_before: torch.Tensor    # (hidden_size,) backbone features before action
    features_after: torch.Tensor     # (hidden_size,) backbone features after action
    action_chunk: torch.Tensor       # (num_steps, action_dim) executed actions
    instruction_embedding: torch.Tensor  # (hidden_size,) instruction features
    proprioception: Optional[torch.Tensor] = None  # (action_dim,) joint state
    confidence: float = 0.0          # Backbone confidence in this experience
    td_error: float = 1.0           # Priority for replay (initialized high)
    timestamp: float = 0.0


class PrioritizedReplayBuffer:
    """Prioritized experience replay buffer for self-learning.

    Experiences with higher surprise (TD error / prediction error) are
    replayed more frequently — the robot learns fastest from situations
    where its predictions were most wrong.

    Implements rank-based prioritization (Schaul et al. 2015).
    """

    def __init__(self, capacity: int = 1000, alpha: float = 0.6):
        self.capacity = capacity
        self.alpha = alpha  # Priority exponent
        self.buffer: Deque[Experience] = deque(maxlen=capacity)
        self._priorities: Deque[float] = deque(maxlen=capacity)

    def add(self, experience: Experience):
        """Add experience with initial priority."""
        self.buffer.append(experience)
        # New experiences get max priority (optimistic — try them first)
        max_priority = max(self._priorities) if self._priorities else 1.0
        self._priorities.append(max_priority)

    def sample(self, batch_size: int) -> Tuple[List[Experience], List[int]]:
        """Sample a prioritized mini-batch.

        Returns:
            (experiences, indices) for updating priorities after learning.
        """
        if len(self.buffer) == 0:
            return [], []

        n = min(batch_size, len(self.buffer))

        # Compute sampling probabilities
        priorities = np.array(list(self._priorities), dtype=np.float64)
        priorities = priorities ** self.alpha
        probs = priorities / priorities.sum()

        # Sample indices
        indices = np.random.choice(len(self.buffer), size=n, replace=False, p=probs)
        experiences = [self.buffer[i] for i in indices]

        return experiences, indices.tolist()

    def update_priorities(self, indices: List[int], td_errors: List[float]):
        """Update priorities after learning."""
        for idx, td_error in zip(indices, td_errors):
            if 0 <= idx < len(self._priorities):
                self._priorities[idx] = abs(td_error) + 1e-6

    def __len__(self) -> int:
        return len(self.buffer)


# =============================================================================
# Outcome Predictor (Forward Model)
# =============================================================================


class OutcomePredictor(nn.Module):
    """Predicts expected backbone features AFTER action execution.

    Given (features_before, action_chunk, instruction), predicts what
    the backbone features SHOULD look like if the action succeeds.

    This is the key to self-supervised learning: the prediction error
    between expected and actual outcome IS the learning signal.

    Architecture: MLP with residual connections.
    Input: concat(f_before, action_flat, instruction) → predicted f_after
    """

    def __init__(
        self,
        feature_dim: int,
        action_dim: int,
        num_action_steps: int = 16,
        hidden_dim: int = 512,
        num_layers: int = 3,
    ):
        super().__init__()
        self.feature_dim = feature_dim
        flat_action_dim = action_dim * num_action_steps

        # Input: f_before (feature_dim) + flat_actions + instruction (feature_dim)
        input_dim = feature_dim * 2 + flat_action_dim

        layers = []
        current_dim = input_dim
        for i in range(num_layers - 1):
            layers.extend([
                nn.Linear(current_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Dropout(0.1),
            ])
            current_dim = hidden_dim

        layers.append(nn.Linear(current_dim, feature_dim))
        self.net = nn.Sequential(*layers)

        # Residual connection: predicted = f_before + delta
        # The predictor only needs to learn the CHANGE, not the full state
        self.use_residual = True

        total_params = sum(p.numel() for p in self.parameters())
        logger.info(f"OutcomePredictor: {total_params:,} params")

    def forward(
        self,
        features_before: torch.Tensor,
        action_chunk: torch.Tensor,
        instruction_features: torch.Tensor,
    ) -> torch.Tensor:
        """Predict features after action execution.

        Args:
            features_before: (batch, feature_dim) current observation features
            action_chunk: (batch, num_steps, action_dim) planned actions
            instruction_features: (batch, feature_dim) instruction embedding

        Returns:
            (batch, feature_dim) predicted post-action features
        """
        # Flatten action chunk
        action_flat = action_chunk.reshape(action_chunk.shape[0], -1)

        # Concatenate all inputs
        x = torch.cat([features_before, action_flat, instruction_features], dim=-1)

        # Predict delta (if residual) or full features
        delta = self.net(x)

        if self.use_residual:
            return features_before + delta
        return delta


# =============================================================================
# Elastic Weight Consolidation (EWC)
# =============================================================================


class EWCRegularizer:
    """Elastic Weight Consolidation to prevent catastrophic forgetting.

    Computes the Fisher Information Matrix over the pre-trained weights
    and penalizes deviations from them. Critical parameters (high Fisher
    diagonal) are protected more strongly.

    Reference: Kirkpatrick et al. "Overcoming Catastrophic Forgetting" (2017)
    """

    def __init__(self, model: nn.Module, lambda_ewc: float = 1000.0):
        self.lambda_ewc = lambda_ewc
        self._fisher: Dict[str, torch.Tensor] = {}
        self._optimal_params: Dict[str, torch.Tensor] = {}
        self._initialized = False

    def compute_fisher(
        self,
        model: nn.Module,
        dataloader_or_experiences: Any,
        num_samples: int = 200,
    ):
        """Compute Fisher Information Matrix diagonal from experiences.

        In practice, we approximate F_ii = E[(∂L/∂θ_i)²] using the
        squared gradients from a set of representative experiences.
        """
        model.eval()

        # Store optimal (pre-trained) parameters
        for name, param in model.named_parameters():
            if param.requires_grad:
                self._optimal_params[name] = param.data.clone()
                self._fisher[name] = torch.zeros_like(param.data)

        # We'll compute Fisher incrementally during self-learning
        # For now, initialize with uniform prior (all weights equally important)
        for name in self._fisher:
            self._fisher[name] = torch.ones_like(self._fisher[name]) * 0.01

        self._initialized = True
        logger.info(f"EWC initialized: {len(self._fisher)} parameter groups")

    def update_fisher(self, model: nn.Module, loss: torch.Tensor):
        """Incrementally update Fisher Information from a training step.

        Online Fisher estimation: running average of squared gradients.
        """
        if not self._initialized:
            return

        # Compute gradients (without stepping optimizer)
        grads = torch.autograd.grad(
            loss, [p for p in model.parameters() if p.requires_grad],
            retain_graph=True, allow_unused=True,
        )

        # Update Fisher diagonal with exponential moving average
        decay = 0.99
        grad_idx = 0
        for name, param in model.named_parameters():
            if param.requires_grad and name in self._fisher:
                if grads[grad_idx] is not None:
                    self._fisher[name] = (
                        decay * self._fisher[name]
                        + (1 - decay) * grads[grad_idx].data.pow(2)
                    )
                grad_idx += 1

    def penalty(self, model: nn.Module) -> torch.Tensor:
        """Compute EWC penalty: λ/2 * Σ F_i * (θ_i - θ*_i)²"""
        if not self._initialized:
            return torch.tensor(0.0)

        loss = torch.tensor(0.0, device=next(model.parameters()).device)
        for name, param in model.named_parameters():
            if param.requires_grad and name in self._fisher:
                fisher = self._fisher[name].to(param.device)
                optimal = self._optimal_params[name].to(param.device)
                loss = loss + (fisher * (param - optimal).pow(2)).sum()

        return 0.5 * self.lambda_ewc * loss


# =============================================================================
# Self-Supervised Loss Functions
# =============================================================================


def outcome_prediction_loss(
    predicted_features: torch.Tensor,
    actual_features: torch.Tensor,
) -> torch.Tensor:
    """L_outcome: How well did we predict what would happen?

    MSE between predicted and actual post-action backbone features.
    This is the primary self-supervised signal.

    Low loss = our forward model accurately predicts action outcomes
    High loss = surprising outcome → high learning value
    """
    return F.mse_loss(predicted_features, actual_features)


def temporal_coherence_loss(
    features_before: torch.Tensor,
    features_after: torch.Tensor,
    instruction_features: torch.Tensor,
) -> torch.Tensor:
    """L_coherence: Did the world change in the direction the instruction implied?

    Measures cosine similarity between:
    - The actual change in features: Δf = f_after - f_before
    - The instruction embedding (which encodes the intended change direction)

    High similarity = action moved the world toward the instruction goal
    Low similarity = action was irrelevant or counterproductive

    This loss trains the action heads to produce actions whose outcomes
    ALIGN with the instruction semantics, using the backbone's understanding
    of both language and physics.
    """
    # Feature change vector
    delta_f = features_after - features_before  # (batch, hidden)

    # Normalize for cosine similarity
    delta_f_norm = F.normalize(delta_f, dim=-1)
    instr_norm = F.normalize(instruction_features, dim=-1)

    # Cosine similarity (want to maximize → minimize negative)
    similarity = (delta_f_norm * instr_norm).sum(dim=-1)  # (batch,)

    # Loss: 1 - similarity (0 when perfectly aligned, 2 when opposite)
    return (1.0 - similarity).mean()


def action_consistency_loss(
    model_forward_fn: Callable,
    features_after: torch.Tensor,
    original_actions: torch.Tensor,
    instruction_features: torch.Tensor,
    proprioception: Optional[torch.Tensor] = None,
) -> torch.Tensor:
    """L_consistency: Would we take the same action again given the outcome?

    Re-runs the action head with post-action features and checks if it
    would predict similar actions. This is a form of temporal consistency
    regularization — the policy should be smooth across similar states.

    If the action heads are well-calibrated, seeing the post-action state
    should produce actions that are "nearby" the ones just executed (since
    the world only changed incrementally over one action chunk).

    Note: This uses stop-gradient on features_after to avoid the backbone
    influencing this loss (backbone is frozen anyway, but explicit is better).
    """
    # Re-predict actions from post-action state (detached — no grad through features)
    with torch.no_grad():
        repredicted_features = features_after.detach()

    # Forward through action heads with post-action features
    # This requires the model to expose its encode→fuse→decode pipeline
    repredicted_actions = model_forward_fn(repredicted_features)

    # MSE between original and re-predicted actions
    # We only penalize large deviations (smooth L1 for robustness)
    return F.smooth_l1_loss(repredicted_actions, original_actions.detach())


# =============================================================================
# The Self-Learner
# =============================================================================


class NeonSelfLearner:
    """Online self-supervised adaptation engine for Neon VLA.

    Attaches to a NeonVLA model and continuously improves action heads
    using self-supervised signals from the frozen video backbone.

    Usage:
        from neon.model.neon_vla import NeonVLA, NeonConfig
        from neon.training.self_learner import NeonSelfLearner, SelfLearnerConfig

        # Create model
        model = NeonVLA(NeonConfig(action_head_type="flow"))
        model.load_backbone()

        # Attach self-learner
        learner = NeonSelfLearner(model, SelfLearnerConfig())

        # In the control loop:
        while running:
            # 1. Snapshot before action
            learner.pre_action(image, instruction, joint_state)

            # 2. Get and execute actions
            output = model.predict(image, instruction=instruction, proprioception=joint_state)
            robot.execute(output.raw_actions)

            # 3. Observe outcome and learn
            metrics = learner.post_action(new_image)
            print(f"Self-learning: {metrics}")

        # Save adapted model
        learner.save_checkpoint("adapted_model/")
    """

    def __init__(
        self,
        model: nn.Module,  # NeonVLA
        config: SelfLearnerConfig = None,
    ):
        self.model = model
        self.config = config or SelfLearnerConfig()

        # Build outcome predictor
        backbone_hidden = model.backbone.hidden_size if hasattr(model, 'backbone') else 2048
        action_dim = model.action_space.action_dim if hasattr(model, 'action_space') else 17
        num_steps = model.config.num_action_steps if hasattr(model, 'config') else 16

        self.outcome_predictor = OutcomePredictor(
            feature_dim=backbone_hidden,
            action_dim=action_dim,
            num_action_steps=num_steps,
            hidden_dim=self.config.forward_model_hidden,
            num_layers=self.config.forward_model_layers,
        )

        # Move to same device as model
        device = next(model.action_head.parameters()).device
        self.outcome_predictor.to(device)
        self.device = device

        # Optimizer: train action heads + outcome predictor
        trainable_params = []
        # Action heads
        for p in model.action_head.parameters():
            if p.requires_grad:
                trainable_params.append(p)
        # Fusion layer
        for p in model.fusion.parameters():
            if p.requires_grad:
                trainable_params.append(p)
        # Proprioception encoder
        if hasattr(model, 'proprio_encoder') and model.proprio_encoder is not None:
            for p in model.proprio_encoder.parameters():
                if p.requires_grad:
                    trainable_params.append(p)
        # Outcome predictor (always trainable)
        trainable_params.extend(self.outcome_predictor.parameters())

        self.optimizer = torch.optim.AdamW(
            trainable_params,
            lr=self.config.learning_rate,
            weight_decay=0.01,
        )

        # EWC regularizer
        self.ewc = EWCRegularizer(model, lambda_ewc=self.config.w_ewc)
        self.ewc.compute_fisher(model, None)  # Initialize with uniform prior

        # Replay buffer
        self.replay_buffer = PrioritizedReplayBuffer(
            capacity=self.config.buffer_size,
            alpha=self.config.priority_alpha,
        )

        # State tracking
        self._pre_action_state: Optional[Dict[str, torch.Tensor]] = None
        self._step = 0
        self._total_updates = 0
        self._best_loss = float('inf')
        self._updates_without_improvement = 0
        self._loss_history: Deque[float] = deque(maxlen=100)

        # Checkpoint for rollback
        self._checkpoint_state: Optional[Dict] = None
        self._save_checkpoint()

        # Metrics
        self.metrics: Dict[str, float] = {
            "outcome_loss": 0.0,
            "coherence_loss": 0.0,
            "consistency_loss": 0.0,
            "ewc_penalty": 0.0,
            "total_loss": 0.0,
            "confidence": 0.0,
            "buffer_size": 0,
            "updates": 0,
            "lr": self.config.learning_rate,
            "adapted": False,
        }

        strategy = AdaptationStrategy(self.config.strategy)
        logger.info(
            f"NeonSelfLearner initialized: strategy={strategy.value}, "
            f"lr={self.config.learning_rate}, ewc_λ={self.config.w_ewc}, "
            f"buffer={self.config.buffer_size}"
        )

    # ─── Control Loop Interface ─────────────────────────────────────

    @torch.no_grad()
    def pre_action(
        self,
        image: Any = None,
        video_frames: Optional[list] = None,
        instruction: str = "",
        proprioception: Optional[np.ndarray] = None,
        action_chunk: Optional[np.ndarray] = None,
    ):
        """Call BEFORE executing actions. Snapshots current state.

        Args:
            image: Current camera frame (PIL Image)
            video_frames: Recent video frames
            instruction: Language instruction
            proprioception: Current joint positions
            action_chunk: The action chunk about to be executed
        """
        if not self.config.enabled:
            return

        # Encode current observation with frozen backbone
        images = [image] if image is not None else None
        backbone_out = self.model.backbone.encode(
            images=images, video_frames=video_frames, text=instruction
        )

        self._pre_action_state = {
            "features_before": backbone_out["pooled"].detach(),
            "instruction_features": backbone_out["pooled"].detach(),  # instruction is fused in
            "instruction_text": instruction,
            "timestamp": time.time(),
        }

        if proprioception is not None:
            self._pre_action_state["proprioception"] = (
                torch.from_numpy(proprioception).float().to(self.device)
            )

        if action_chunk is not None:
            self._pre_action_state["action_chunk"] = (
                torch.from_numpy(action_chunk).float().to(self.device)
            )

        self._step += 1

    def post_action(
        self,
        image: Any = None,
        video_frames: Optional[list] = None,
    ) -> Dict[str, float]:
        """Call AFTER executing actions. Observes outcome and learns.

        Args:
            image: New camera frame after action execution
            video_frames: New video frames

        Returns:
            Dict of self-learning metrics
        """
        if not self.config.enabled or self._pre_action_state is None:
            return self.metrics

        # Encode post-action observation
        with torch.no_grad():
            images = [image] if image is not None else None
            backbone_out = self.model.backbone.encode(
                images=images,
                video_frames=video_frames,
                text=self._pre_action_state.get("instruction_text", ""),
            )
            features_after = backbone_out["pooled"].detach()

        features_before = self._pre_action_state["features_before"]
        instruction_features = self._pre_action_state["instruction_features"]

        # ─── Confidence Gating ───────────────────────────────────
        # Check if the observation actually changed (robot did something)
        feature_change = (features_after - features_before).norm().item()

        if feature_change < self.config.min_feature_change:
            logger.debug(f"Self-learner: skipping — feature change too small ({feature_change:.4f})")
            return self.metrics

        if feature_change > self.config.max_feature_change:
            logger.debug(f"Self-learner: skipping — feature change too large ({feature_change:.4f})")
            return self.metrics

        # Compute confidence as inverse of prediction surprise
        # (will be refined after computing outcome loss)
        confidence = min(1.0, 1.0 / (1.0 + feature_change))

        strategy = AdaptationStrategy(self.config.strategy)
        threshold = {
            AdaptationStrategy.CONSERVATIVE: 0.8,
            AdaptationStrategy.BALANCED: 0.6,
            AdaptationStrategy.AGGRESSIVE: 0.3,
        }[strategy]

        # ─── Store Experience ────────────────────────────────────
        action_chunk = self._pre_action_state.get("action_chunk")
        if action_chunk is None:
            # No action chunk recorded — can't learn from this
            return self.metrics

        experience = Experience(
            features_before=features_before.cpu(),
            features_after=features_after.cpu(),
            action_chunk=action_chunk.cpu() if isinstance(action_chunk, torch.Tensor) else torch.tensor(action_chunk),
            instruction_embedding=instruction_features.cpu(),
            proprioception=self._pre_action_state.get("proprioception", torch.zeros(1)).cpu(),
            confidence=confidence,
            timestamp=time.time(),
        )
        self.replay_buffer.add(experience)

        # ─── Online Update ───────────────────────────────────────
        if confidence >= threshold:
            metrics = self._update_step(
                features_before.unsqueeze(0),
                features_after.unsqueeze(0),
                action_chunk.unsqueeze(0) if action_chunk.dim() == 2 else action_chunk,
                instruction_features.unsqueeze(0),
            )
            self.metrics.update(metrics)
            self.metrics["confidence"] = confidence
            self.metrics["adapted"] = True
        else:
            self.metrics["confidence"] = confidence
            self.metrics["adapted"] = False

        # ─── Replay Update ───────────────────────────────────────
        if (
            self._total_updates > 0
            and self._total_updates % self.config.replay_every == 0
            and len(self.replay_buffer) >= self.config.batch_size
        ):
            self._replay_update()

        # ─── Checkpoint & Rollback ───────────────────────────────
        if self._total_updates % self.config.checkpoint_every == 0:
            self._save_checkpoint()

        self.metrics["buffer_size"] = len(self.replay_buffer)
        self.metrics["updates"] = self._total_updates

        # Clear pre-action state
        self._pre_action_state = None

        return self.metrics

    # ─── Learning Steps ─────────────────────────────────────────────

    def _get_current_lr(self) -> float:
        """Compute current learning rate with warmup."""
        if self._total_updates < self.config.lr_warmup_steps:
            # Linear warmup
            warmup_frac = self._total_updates / self.config.lr_warmup_steps
            return self.config.learning_rate + warmup_frac * (self.config.max_lr - self.config.learning_rate)
        return self.config.max_lr

    def _update_step(
        self,
        features_before: torch.Tensor,
        features_after: torch.Tensor,
        action_chunk: torch.Tensor,
        instruction_features: torch.Tensor,
    ) -> Dict[str, float]:
        """Single self-supervised update step.

        Computes all three losses + EWC penalty and updates action heads.
        """
        self.model.train()
        self.outcome_predictor.train()

        # Update learning rate
        current_lr = self._get_current_lr()
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = current_lr

        # Move to device
        fb = features_before.to(self.device)
        fa = features_after.to(self.device)
        ac = action_chunk.to(self.device)
        ie = instruction_features.to(self.device)

        # ─── Loss 1: Outcome Prediction ──────────────────────────
        predicted_features = self.outcome_predictor(fb, ac, ie)
        l_outcome = outcome_prediction_loss(predicted_features, fa)

        # ─── Loss 2: Temporal Coherence ──────────────────────────
        l_coherence = temporal_coherence_loss(fb, fa, ie)

        # ─── Loss 3: Action Consistency ──────────────────────────
        # Re-predict actions from fused features
        # We need to go through fusion → action_head
        fused_features = self.model.fusion(fa)
        repredicted_actions = self.model.action_head(fused_features)

        # Match shapes (action_chunk may be (B, steps, dim) or (B, dim))
        if repredicted_actions.shape != ac.shape:
            # Truncate or pad to match
            min_steps = min(repredicted_actions.shape[1] if repredicted_actions.dim() == 3 else 1,
                          ac.shape[1] if ac.dim() == 3 else 1)
            if repredicted_actions.dim() == 3 and ac.dim() == 3:
                repredicted_actions = repredicted_actions[:, :min_steps]
                ac_matched = ac[:, :min_steps]
            else:
                ac_matched = ac
        else:
            ac_matched = ac

        l_consistency = F.smooth_l1_loss(repredicted_actions, ac_matched.detach())

        # ─── EWC Penalty ─────────────────────────────────────────
        l_ewc = self.ewc.penalty(self.model)

        # ─── Total Loss ──────────────────────────────────────────
        total_loss = (
            self.config.w_outcome * l_outcome
            + self.config.w_coherence * l_coherence
            + self.config.w_consistency * l_consistency
            + l_ewc
        )

        # ─── Backward + Step ─────────────────────────────────────
        self.optimizer.zero_grad()
        total_loss.backward()

        # Gradient clipping
        torch.nn.utils.clip_grad_norm_(
            list(self.model.action_head.parameters()) + list(self.outcome_predictor.parameters()),
            self.config.max_grad_norm,
        )

        self.optimizer.step()

        # Update EWC Fisher information
        # Update EWC Fisher: use outcome loss WITH grad (not detached)
        if l_outcome.requires_grad:
            self.ewc.update_fisher(self.model, l_outcome)
        # else: skip Fisher update when loss has no grad_fn

        self._total_updates += 1
        total_loss_val = total_loss.item()
        self._loss_history.append(total_loss_val)

        # Track best loss for rollback
        if total_loss_val < self._best_loss:
            self._best_loss = total_loss_val
            self._updates_without_improvement = 0
        else:
            self._updates_without_improvement += 1

        # Rollback check
        if (
            len(self._loss_history) > 20
            and total_loss_val > self._best_loss * (1 + self.config.rollback_threshold)
            and self._updates_without_improvement > self.config.max_updates_without_improvement
        ):
            logger.warning(f"Self-learner: rolling back — loss degraded ({total_loss_val:.4f} > {self._best_loss:.4f})")
            self._rollback()

        # Logging
        if self._total_updates % self.config.log_every == 0:
            logger.info(
                f"Self-learn step {self._total_updates}: "
                f"outcome={l_outcome.item():.4f} coherence={l_coherence.item():.4f} "
                f"consistency={l_consistency.item():.4f} ewc={l_ewc.item():.4f} "
                f"total={total_loss_val:.4f} lr={current_lr:.2e}"
            )

        return {
            "outcome_loss": l_outcome.item(),
            "coherence_loss": l_coherence.item(),
            "consistency_loss": l_consistency.item(),
            "ewc_penalty": l_ewc.item(),
            "total_loss": total_loss_val,
            "lr": current_lr,
        }

    def _replay_update(self):
        """Sample from replay buffer and perform additional update steps."""
        experiences, indices = self.replay_buffer.sample(self.config.batch_size)
        if not experiences:
            return

        # Stack into batches
        fb = torch.stack([e.features_before for e in experiences]).to(self.device)
        fa = torch.stack([e.features_after for e in experiences]).to(self.device)
        ac = torch.stack([e.action_chunk for e in experiences]).to(self.device)
        ie = torch.stack([e.instruction_embedding for e in experiences]).to(self.device)

        # Update
        metrics = self._update_step(fb, fa, ac, ie)

        # Update priorities based on prediction error
        td_errors = []
        with torch.no_grad():
            predicted = self.outcome_predictor(fb, ac, ie)
            per_sample_error = (predicted - fa).pow(2).mean(dim=-1)
            td_errors = per_sample_error.cpu().tolist()

        self.replay_buffer.update_priorities(indices, td_errors)

        logger.debug(f"Replay update: batch={len(experiences)}, loss={metrics['total_loss']:.4f}")

    # ─── Checkpointing ──────────────────────────────────────────────

    def _save_checkpoint(self):
        """Save current state for potential rollback."""
        self._checkpoint_state = {
            "action_head": copy.deepcopy(self.model.action_head.state_dict()),
            "fusion": copy.deepcopy(self.model.fusion.state_dict()),
            "outcome_predictor": copy.deepcopy(self.outcome_predictor.state_dict()),
            "optimizer": copy.deepcopy(self.optimizer.state_dict()),
            "best_loss": self._best_loss,
            "step": self._total_updates,
        }

    def _rollback(self):
        """Rollback to last checkpoint."""
        if self._checkpoint_state is None:
            logger.warning("No checkpoint to rollback to")
            return

        self.model.action_head.load_state_dict(self._checkpoint_state["action_head"])
        self.model.fusion.load_state_dict(self._checkpoint_state["fusion"])
        self.outcome_predictor.load_state_dict(self._checkpoint_state["outcome_predictor"])
        self.optimizer.load_state_dict(self._checkpoint_state["optimizer"])
        self._best_loss = self._checkpoint_state["best_loss"]
        self._updates_without_improvement = 0

        logger.info(f"Rolled back to step {self._checkpoint_state['step']}")

    def save(self, path: str):
        """Save the adapted model and self-learner state."""
        save_dir = Path(path)
        save_dir.mkdir(parents=True, exist_ok=True)

        # Save action heads + fusion + outcome predictor
        torch.save({
            "action_head": self.model.action_head.state_dict(),
            "fusion": self.model.fusion.state_dict(),
            "outcome_predictor": self.outcome_predictor.state_dict(),
            "optimizer": self.optimizer.state_dict(),
            "ewc_fisher": self.ewc._fisher,
            "ewc_optimal": self.ewc._optimal_params,
            "metrics": self.metrics,
            "total_updates": self._total_updates,
            "best_loss": self._best_loss,
        }, save_dir / "self_learner_state.pt")

        # Also save the full model via NeonVLA's save_pretrained
        if hasattr(self.model, 'save_pretrained'):
            self.model.save_pretrained(str(save_dir / "adapted_model"))

        logger.info(f"Self-learner state saved to {save_dir}")

    @classmethod
    def load(cls, model: nn.Module, path: str, config: SelfLearnerConfig = None) -> "NeonSelfLearner":
        """Load a self-learner from saved state."""
        learner = cls(model, config)

        state_path = Path(path) / "self_learner_state.pt"
        if state_path.exists():
            state = torch.load(state_path, map_location="cpu", weights_only=False)
            model.action_head.load_state_dict(state["action_head"])
            model.fusion.load_state_dict(state["fusion"])
            learner.outcome_predictor.load_state_dict(state["outcome_predictor"])
            learner.optimizer.load_state_dict(state["optimizer"])
            learner.ewc._fisher = state.get("ewc_fisher", {})
            learner.ewc._optimal_params = state.get("ewc_optimal", {})
            learner._total_updates = state.get("total_updates", 0)
            learner._best_loss = state.get("best_loss", float('inf'))
            learner.metrics = state.get("metrics", learner.metrics)
            logger.info(f"Self-learner loaded from {path} (step {learner._total_updates})")

        return learner

    def __repr__(self) -> str:
        return (
            f"NeonSelfLearner("
            f"strategy={self.config.strategy}, "
            f"updates={self._total_updates}, "
            f"buffer={len(self.replay_buffer)}/{self.config.buffer_size}, "
            f"best_loss={self._best_loss:.4f}, "
            f"lr={self._get_current_lr():.2e})"
        )
