"""Neon evaluation module — benchmark scripts for LIBERO, SimplerEnv, RoboCasa, DreamGenBench, MuJoCo."""
