"""
Physics-Aware Guidance Functions for Flow-Matching Action Generation.

Adapted from AirVLA (Stanford / Physical Intelligence, arXiv:2603.25038).

Core idea: Instead of retraining the VLA for new physics constraints,
inject gradient corrections into the flow-matching sampling process at
inference time. This steers the generative policy toward physically
feasible actions WITHOUT modifying model weights.

The guidance loss Φ(A; o) is differentiated w.r.t. the denoised action
chunk, and its gradient is subtracted from the velocity field:
    v_guided = v_base - λ * ∇_x Φ(denoise(x_t))

This works for ANY flow-matching head (FlowMatchingHead, DiTActionHead).
Pass guidance_fn to head.sample() at inference time.

Example usage:
    # Aerial manipulation — compensate for payload sag
    guidance = PayloadAwareGuidance(
        altitude_index=2,          # z is at index 2 in action space
        gripper_index=4,           # gripper is at index 4
        target_altitude_offset=0.05,  # 5cm upward bias under load
    )
    actions = flow_head.sample(
        features,
        guidance_fn=guidance,
        guidance_scale=2.0,
    )

    # Ground robot — joint torque safety limits
    guidance = JointTorqueSafetyGuidance(action_space=g1_action_space)
    actions = flow_head.sample(features, guidance_fn=guidance, guidance_scale=1.0)

    # Compose multiple guidance functions
    guidance = CompositeGuidance([
        (PayloadAwareGuidance(...), 2.0),
        (CollisionAvoidanceGuidance(...), 1.0),
    ])
    actions = flow_head.sample(features, guidance_fn=guidance, guidance_scale=1.0)

Reference:
    Tucker et al. "π, But Make It Fly: Physics-Guided Transfer of VLA
    Models to Aerial Manipulation" (2026), arXiv:2603.25038, §3.4
"""

from __future__ import annotations

import logging
from typing import Callable, List, Optional, Tuple

import torch
import torch.nn.functional as F

logger = logging.getLogger(__name__)


class PayloadAwareGuidance:
    """Payload-aware vertical guidance for aerial manipulation.

    From AirVLA §3.4: The dominant disturbance during drone grasping is
    vertical sag from increased effective mass. Rather than modeling full
    6-DOF dynamics, we apply guidance only on the altitude dimension.

    The guidance biases the drone toward slightly higher altitude when
    payload confidence α is high (gripper closed + object detected).

    Φ(A) = α * Σ_t (A[t, z_idx] - z_target)²

    Where:
        α = payload_confidence ∈ [0, 1] — from gripper aperture
        z_target = current_altitude + altitude_offset
        z_idx = index of altitude dimension in action vector

    When α ≈ 0: loss vanishes → vanilla flow matching
    When α ≈ 1: sampler prefers chunks biased upward → compensates sag

    This can be viewed as mode-dependent feedforward (gain scheduling /
    gravity compensation), but injected INSIDE the generative policy's
    sampling dynamics.
    """

    def __init__(
        self,
        altitude_index: int = 2,
        gripper_index: int = 4,
        target_altitude_offset: float = 0.05,
        gripper_close_threshold: float = 0.3,
    ):
        """Initialize payload-aware guidance.

        Args:
            altitude_index: Index of the altitude (z) dimension in the action vector.
            gripper_index: Index of the gripper dimension in the action vector.
            target_altitude_offset: Altitude bias (meters) to apply when carrying payload.
                                    Positive = upward. Tuned per platform and typical payload mass.
            gripper_close_threshold: Gripper aperture below which we assume object is grasped.
                                    For UMI gripper: 0.3 means "mostly closed".
        """
        self.altitude_index = altitude_index
        self.gripper_index = gripper_index
        self.target_altitude_offset = target_altitude_offset
        self.gripper_close_threshold = gripper_close_threshold
        self._last_gripper_aperture: Optional[float] = None
        self._payload_confidence: float = 0.0

    def update_state(
        self,
        gripper_aperture: float,
        previous_actions: Optional[torch.Tensor] = None,
    ):
        """Update payload confidence from sensor readings.

        Should be called before each sample() call with the latest
        gripper aperture reading.

        Args:
            gripper_aperture: Current gripper aperture ∈ [0, 1]. 0=closed, 1=open.
            previous_actions: Optional previous action chunk for smoothing.
        """
        # Simple binary confidence based on gripper state
        # AirVLA uses a smooth ramp; we implement both
        if gripper_aperture < self.gripper_close_threshold:
            # Gripper is closed — likely carrying payload
            # Smooth ramp-up: confidence increases as gripper closes more
            self._payload_confidence = 1.0 - (gripper_aperture / self.gripper_close_threshold)
        else:
            # Gripper open — no payload
            self._payload_confidence = 0.0

        self._last_gripper_aperture = gripper_aperture

    @property
    def payload_confidence(self) -> float:
        """Current payload confidence α ∈ [0, 1]."""
        return self._payload_confidence

    def __call__(self, actions: torch.Tensor) -> torch.Tensor:
        """Compute payload-aware altitude guidance loss.

        Args:
            actions: (batch, num_steps, action_dim) denoised action chunk

        Returns:
            Scalar loss — higher when altitude is too low under load
        """
        alpha = self._payload_confidence
        if alpha < 1e-6:
            # No payload → zero loss → vanilla sampling
            return torch.tensor(0.0, device=actions.device, requires_grad=True)

        # Extract altitude dimension across all timesteps
        z = actions[:, :, self.altitude_index]  # (batch, num_steps)

        # Target: bias altitude upward by offset amount
        target_z = self.target_altitude_offset

        # MSE loss on altitude deviation, weighted by payload confidence
        loss = alpha * F.mse_loss(z, torch.full_like(z, target_z))

        return loss


class JointTorqueSafetyGuidance:
    """Joint torque / velocity safety guidance for humanoid robots.

    Generalization of AirVLA's physics guidance to ground robots.
    Penalizes actions that would exceed joint velocity or effort limits.

    Φ(A) = Σ_t Σ_j max(0, |A[t,j] - A[t-1,j]|/dt - vel_limit_j)²
          + Σ_t Σ_j max(0, |A[t,j]| - effort_limit_j / kp_j)²

    This keeps actions within the physically safe envelope without
    retraining — useful when deploying a model trained in simulation
    to real hardware with tighter safety margins.
    """

    def __init__(
        self,
        velocity_limits: Optional[torch.Tensor] = None,
        position_limits_low: Optional[torch.Tensor] = None,
        position_limits_high: Optional[torch.Tensor] = None,
        dt: float = 0.1,
        velocity_weight: float = 1.0,
        position_weight: float = 0.5,
    ):
        """Initialize joint safety guidance.

        Args:
            velocity_limits: (action_dim,) per-joint velocity limits (rad/s).
            position_limits_low: (action_dim,) per-joint lower position limits.
            position_limits_high: (action_dim,) per-joint upper position limits.
            dt: Timestep between action steps (seconds).
            velocity_weight: Weight for velocity violation penalty.
            position_weight: Weight for position limit penalty.
        """
        self.velocity_limits = velocity_limits
        self.position_limits_low = position_limits_low
        self.position_limits_high = position_limits_high
        self.dt = dt
        self.velocity_weight = velocity_weight
        self.position_weight = position_weight

    @classmethod
    def from_action_space(cls, action_space, dt: float = 0.1) -> "JointTorqueSafetyGuidance":
        """Create from a G1ActionSpace instance, extracting limits automatically."""
        joints = action_space.active_joints
        vel_limits = torch.tensor([j.vel_limit for j in joints], dtype=torch.float32)
        pos_low = torch.tensor([j.lower_limit for j in joints], dtype=torch.float32)
        pos_high = torch.tensor([j.upper_limit for j in joints], dtype=torch.float32)
        return cls(
            velocity_limits=vel_limits,
            position_limits_low=pos_low,
            position_limits_high=pos_high,
            dt=dt,
        )

    def __call__(self, actions: torch.Tensor) -> torch.Tensor:
        """Compute joint safety guidance loss.

        Args:
            actions: (batch, num_steps, action_dim) denoised action chunk

        Returns:
            Scalar loss — higher when actions violate safety limits
        """
        device = actions.device
        loss = torch.tensor(0.0, device=device, requires_grad=True)

        # Velocity limit violations
        if self.velocity_limits is not None:
            vel_limits = self.velocity_limits.to(device)
            # Finite differences: (A[t] - A[t-1]) / dt
            velocities = torch.diff(actions, dim=1) / self.dt  # (B, T-1, D)
            violations = F.relu(velocities.abs() - vel_limits)  # Only penalize violations
            loss = loss + self.velocity_weight * violations.pow(2).mean()

        # Position limit violations
        if self.position_limits_low is not None and self.position_limits_high is not None:
            low = self.position_limits_low.to(device)
            high = self.position_limits_high.to(device)
            below = F.relu(low - actions)  # How much below lower limit
            above = F.relu(actions - high)  # How much above upper limit
            loss = loss + self.position_weight * (below.pow(2) + above.pow(2)).mean()

        return loss


class CollisionAvoidanceGuidance:
    """Obstacle avoidance guidance using distance fields.

    Penalizes end-effector positions that are too close to known obstacles.
    Works with both point obstacles and signed distance fields (SDF).

    Φ(A) = Σ_t max(0, d_safe - d(ee_pos(A[t]), obstacle))²

    For aerial platforms: obstacles are gates, walls, ceiling.
    For humanoids: obstacles are table edges, other robots, humans.
    """

    def __init__(
        self,
        obstacle_positions: Optional[torch.Tensor] = None,
        safe_distance: float = 0.15,
        position_indices: Tuple[int, ...] = (0, 1, 2),
    ):
        """Initialize collision avoidance guidance.

        Args:
            obstacle_positions: (N, 3) positions of point obstacles.
            safe_distance: Minimum allowed distance to any obstacle (meters).
            position_indices: Indices of x, y, z in the action vector.
        """
        self.obstacle_positions = obstacle_positions
        self.safe_distance = safe_distance
        self.position_indices = position_indices

    def update_obstacles(self, positions: torch.Tensor):
        """Update obstacle positions (e.g., from LiDAR or vision)."""
        self.obstacle_positions = positions

    def __call__(self, actions: torch.Tensor) -> torch.Tensor:
        """Compute collision avoidance loss.

        Args:
            actions: (batch, num_steps, action_dim) denoised action chunk

        Returns:
            Scalar loss — higher when too close to obstacles
        """
        if self.obstacle_positions is None:
            return torch.tensor(0.0, device=actions.device, requires_grad=True)

        device = actions.device
        obstacles = self.obstacle_positions.to(device)  # (N, 3)

        # Extract position dimensions from actions
        idx = list(self.position_indices)
        positions = actions[:, :, idx]  # (B, T, 3)

        # Distance from each action position to each obstacle
        # positions: (B, T, 1, 3), obstacles: (1, 1, N, 3)
        diffs = positions.unsqueeze(2) - obstacles.unsqueeze(0).unsqueeze(0)
        distances = diffs.norm(dim=-1)  # (B, T, N)

        # Penalize being closer than safe_distance
        violations = F.relu(self.safe_distance - distances)  # (B, T, N)

        return violations.pow(2).mean()


class SmoothTrajectoryGuidance:
    """Trajectory smoothness guidance — reduces jerk in action chunks.

    Penalizes high jerk (third derivative) in the action trajectory.
    Useful for both aerial and ground robots to prevent aggressive motions.

    Φ(A) = Σ_t ||A[t+2] - 2*A[t+1] + A[t]||² / dt²

    AirVLA found that RTC alone improved smoothness, but explicit
    jerk minimization further reduces oscillations at chunk boundaries.
    """

    def __init__(self, dt: float = 0.1, weight: float = 0.1):
        self.dt = dt
        self.weight = weight

    def __call__(self, actions: torch.Tensor) -> torch.Tensor:
        """Compute jerk minimization loss.

        Args:
            actions: (batch, num_steps, action_dim) denoised action chunk

        Returns:
            Scalar loss — higher for jerky trajectories
        """
        if actions.shape[1] < 3:
            return torch.tensor(0.0, device=actions.device, requires_grad=True)

        # Second-order finite differences ≈ acceleration differences ≈ jerk
        jerk = actions[:, 2:] - 2 * actions[:, 1:-1] + actions[:, :-2]
        return self.weight * jerk.pow(2).mean() / (self.dt ** 2)


class CompositeGuidance:
    """Compose multiple guidance functions with individual weights.

    Example:
        guidance = CompositeGuidance([
            (PayloadAwareGuidance(altitude_index=2, gripper_index=4), 2.0),
            (CollisionAvoidanceGuidance(obstacles, safe_dist=0.2), 1.0),
            (SmoothTrajectoryGuidance(dt=0.1), 0.5),
        ])
        actions = head.sample(features, guidance_fn=guidance, guidance_scale=1.0)
    """

    def __init__(self, guidance_fns: List[Tuple[Callable, float]]):
        """Initialize composite guidance.

        Args:
            guidance_fns: List of (guidance_fn, weight) tuples.
        """
        self.guidance_fns = guidance_fns

    def __call__(self, actions: torch.Tensor) -> torch.Tensor:
        """Compute weighted sum of all guidance losses."""
        total_loss = torch.tensor(0.0, device=actions.device, requires_grad=True)
        for fn, weight in self.guidance_fns:
            total_loss = total_loss + weight * fn(actions)
        return total_loss
