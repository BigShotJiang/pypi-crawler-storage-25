"""
LeWM-Neon — Latent World Model for planning and imagination.

Yoinked from: https://github.com/lucas-maes/le-wm
Paper: "LeWorldModel: Stable End-to-End JEPA from Pixels" (Maes et al., 2026)

Why this matters for Neon:
─────────────────────────
1. **48× faster planning** than foundation-model world models
2. **Only 2 loss terms** — prediction + SIGReg (vs 6+ in alternatives)
3. **~15M params** — trains on single GPU in hours
4. **Collapse-free** — SIGReg prevents representation collapse without EMA/pretrained encoders
5. **Plans in latent space** — no pixel reconstruction, pure embedding prediction

Architecture (from LeWM):
    Encoder (ViT) → CLS token → Projector → Latent embedding z
    Action → Action Embedder → act_emb
    [z_t, act_t] → AR Predictor (AdaLN-zero Transformer) → z_{t+1} prediction

How Neon uses it:
    - Imagination rollouts for action planning (MPC/CEM in latent space)
    - Model-based RL reward shaping in simulation
    - Surprise detection for safety (OOD detection via prediction error)
    - Dream training — generate training data from imagined trajectories

License: Apache-2.0 (this implementation), CC-BY-NC-4.0 (original LeWM ideas)

Reference:
    @article{maes_lelidec2026lewm,
      title={LeWorldModel: Stable End-to-End JEPA from Pixels},
      author={Maes, Lucas and Le Lidec, Quentin and Scieur, Damien and LeCun, Yann and Balestriero, Randall},
      journal={arXiv preprint},
      year={2026}
    }
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

logger = logging.getLogger(__name__)


# =============================================================================
# Core Primitives — from le-wm/module.py
# =============================================================================


def _modulate(x: torch.Tensor, shift: torch.Tensor, scale: torch.Tensor) -> torch.Tensor:
    """AdaLN-zero modulation: x * (1 + scale) + shift."""
    return x * (1 + scale) + shift


class SIGReg(nn.Module):
    """Sketch Isotropic Gaussian Regularizer.

    From LeWM: enforces latent embeddings to follow a Gaussian distribution.
    This is THE key innovation — prevents representation collapse with just
    one regularizer term, no EMA target networks, no pretrained encoders.

    How it works:
    - Projects embeddings onto random 1D subspaces
    - Computes characteristic function statistics
    - Penalizes deviation from Gaussian characteristic function

    For Neon: applied to the latent embeddings from the visual encoder
    to ensure the world model's latent space stays well-structured
    and doesn't collapse during training.

    Args:
        knots: Number of evaluation points for characteristic function
        num_proj: Number of random projection directions (more = better estimate)
    """

    def __init__(self, knots: int = 17, num_proj: int = 1024):
        super().__init__()
        self.num_proj = num_proj
        t = torch.linspace(0, 3, knots, dtype=torch.float32)
        dt = 3 / (knots - 1)
        weights = torch.full((knots,), 2 * dt, dtype=torch.float32)
        weights[[0, -1]] = dt
        window = torch.exp(-t.square() / 2.0)
        self.register_buffer("t", t)
        self.register_buffer("phi", window)
        self.register_buffer("weights", weights * window)

    def forward(self, embeddings: torch.Tensor) -> torch.Tensor:
        """Compute SIGReg loss.

        Args:
            embeddings: (T, B, D) latent embeddings — time-first for temporal consistency

        Returns:
            Scalar loss penalizing deviation from Gaussian distribution
        """
        # Random projections onto 1D subspaces
        A = torch.randn(embeddings.size(-1), self.num_proj, device=embeddings.device)
        A = A.div_(A.norm(p=2, dim=0))

        # Compute Epps-Pulley statistic (characteristic function test for Gaussianity)
        x_t = (embeddings @ A).unsqueeze(-1) * self.t
        err = (x_t.cos().mean(-3) - self.phi).square() + x_t.sin().mean(-3).square()
        statistic = (err @ self.weights) * embeddings.size(-2)
        return statistic.mean()


# =============================================================================
# Transformer Components — from le-wm/module.py
# =============================================================================


class FeedForward(nn.Module):
    """Standard Transformer FFN with pre-norm."""

    def __init__(self, dim: int, hidden_dim: int, dropout: float = 0.0):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class CausalAttention(nn.Module):
    """Causal multi-head attention with scaled dot-product."""

    def __init__(self, dim: int, heads: int = 8, dim_head: int = 64, dropout: float = 0.0):
        super().__init__()
        inner_dim = dim_head * heads
        self.heads = heads
        self.dropout = dropout
        self.norm = nn.LayerNorm(dim)
        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias=False)
        self.to_out = nn.Sequential(nn.Linear(inner_dim, dim), nn.Dropout(dropout))

    def forward(self, x: torch.Tensor, causal: bool = True) -> torch.Tensor:
        """Multi-head attention.

        Args:
            x: (B, T, D) input sequence
            causal: If True, apply causal masking (default for AR prediction)
        """
        x = self.norm(x)
        drop = self.dropout if self.training else 0.0
        qkv = self.to_qkv(x).chunk(3, dim=-1)
        q, k, v = (rearrange(t, "b t (h d) -> b h t d", h=self.heads) for t in qkv)
        out = F.scaled_dot_product_attention(q, k, v, dropout_p=drop, is_causal=causal)
        out = rearrange(out, "b h t d -> b t (h d)")
        return self.to_out(out)


class ConditionalBlock(nn.Module):
    """Transformer block with AdaLN-zero conditioning on action embeddings.

    From LeWM: the predictor uses action embeddings as conditioning signal
    via Adaptive Layer Normalization with zero initialization.
    This lets the model learn action-conditioned state transitions.

    AdaLN-zero: modulate(LayerNorm(x), shift, scale) where shift/scale
    come from the action embedding. "Zero" because the modulation
    parameters are initialized to zero → identity transform at start.
    """

    def __init__(self, dim: int, heads: int, dim_head: int, mlp_dim: int, dropout: float = 0.0):
        super().__init__()
        self.attn = CausalAttention(dim, heads=heads, dim_head=dim_head, dropout=dropout)
        self.mlp = FeedForward(dim, mlp_dim, dropout=dropout)
        self.norm1 = nn.LayerNorm(dim, elementwise_affine=False, eps=1e-6)
        self.norm2 = nn.LayerNorm(dim, elementwise_affine=False, eps=1e-6)

        # AdaLN-zero: 6 modulation parameters (shift, scale, gate for attn + mlp)
        self.adaLN_modulation = nn.Sequential(
            nn.SiLU(),
            nn.Linear(dim, 6 * dim, bias=True),
        )
        # Zero-initialize → identity at start
        nn.init.constant_(self.adaLN_modulation[-1].weight, 0)
        nn.init.constant_(self.adaLN_modulation[-1].bias, 0)

    def forward(self, x: torch.Tensor, c: torch.Tensor) -> torch.Tensor:
        """Forward with action conditioning.

        Args:
            x: (B, T, D) state embeddings
            c: (B, T, D) action embeddings (conditioning)
        """
        shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp = (
            self.adaLN_modulation(c).chunk(6, dim=-1)
        )
        x = x + gate_msa * self.attn(_modulate(self.norm1(x), shift_msa, scale_msa))
        x = x + gate_mlp * self.mlp(_modulate(self.norm2(x), shift_mlp, scale_mlp))
        return x


class ActionEmbedder(nn.Module):
    """Embeds raw actions into the latent space for conditioning.

    From LeWM: Conv1d patch embedding + 2-layer MLP.
    Handles variable action dimensions (arms=14, upper_body=17, whole_body=29).
    """

    def __init__(self, input_dim: int, emb_dim: int, mlp_scale: int = 4):
        super().__init__()
        self.patch_embed = nn.Conv1d(input_dim, input_dim, kernel_size=1, stride=1)
        self.embed = nn.Sequential(
            nn.Linear(input_dim, mlp_scale * emb_dim),
            nn.SiLU(),
            nn.Linear(mlp_scale * emb_dim, emb_dim),
        )

    def forward(self, actions: torch.Tensor) -> torch.Tensor:
        """Embed action sequence.

        Args:
            actions: (B, T, action_dim) raw actions

        Returns:
            (B, T, emb_dim) action embeddings
        """
        x = actions.float()
        x = x.permute(0, 2, 1)  # (B, action_dim, T)
        x = self.patch_embed(x)
        x = x.permute(0, 2, 1)  # (B, T, action_dim)
        return self.embed(x)


class ARPredictor(nn.Module):
    """Autoregressive next-state predictor using action-conditioned Transformer.

    From LeWM: predicts z_{t+1} from z_t and a_t using causal attention
    with AdaLN-zero conditioning. The core "world model" component.

    Args:
        num_frames: Maximum sequence length (history window)
        depth: Number of Transformer layers
        heads: Number of attention heads
        mlp_dim: FFN hidden dimension
        input_dim: State embedding dimension
        hidden_dim: Transformer hidden dimension
        output_dim: Predicted embedding dimension
        dim_head: Dimension per attention head
        dropout: Dropout rate
    """

    def __init__(
        self,
        *,
        num_frames: int,
        depth: int,
        heads: int,
        mlp_dim: int,
        input_dim: int,
        hidden_dim: int,
        output_dim: int = None,
        dim_head: int = 64,
        dropout: float = 0.0,
        emb_dropout: float = 0.0,
    ):
        super().__init__()
        output_dim = output_dim or input_dim
        self.pos_embedding = nn.Parameter(torch.randn(1, num_frames, input_dim))

        self.input_proj = nn.Linear(input_dim, hidden_dim) if input_dim != hidden_dim else nn.Identity()
        self.cond_proj = nn.Linear(input_dim, hidden_dim) if input_dim != hidden_dim else nn.Identity()
        self.output_proj = nn.Linear(hidden_dim, output_dim) if hidden_dim != output_dim else nn.Identity()

        self.dropout = nn.Dropout(emb_dropout)
        self.blocks = nn.ModuleList([
            ConditionalBlock(hidden_dim, heads, dim_head, mlp_dim, dropout)
            for _ in range(depth)
        ])
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x: torch.Tensor, c: torch.Tensor) -> torch.Tensor:
        """Predict next-state embeddings.

        Args:
            x: (B, T, D) state embeddings
            c: (B, T, D) action embeddings

        Returns:
            (B, T, output_dim) predicted next-state embeddings
        """
        T = x.size(1)
        x = x + self.pos_embedding[:, :T]
        x = self.dropout(x)
        x = self.input_proj(x)
        c = self.cond_proj(c)
        for block in self.blocks:
            x = block(x, c)
        x = self.norm(x)
        return self.output_proj(x)


# =============================================================================
# JEPA — Joint Embedding Predictive Architecture (from le-wm/jepa.py)
# =============================================================================


def _detach_clone(v):
    """Detach and clone a tensor, or pass through non-tensors."""
    return v.detach().clone() if torch.is_tensor(v) else v


class JEPA(nn.Module):
    """Joint Embedding Predictive Architecture for world modeling.

    From LeWM: instead of predicting pixels, predict in latent embedding space.
    This is much faster and more stable than pixel-space world models.

    Pipeline:
        1. encoder(pixels) → CLS token → projector → z (embedding)
        2. action_encoder(actions) → act_emb
        3. predictor(z_t, act_emb_t) → z_{t+1} (predicted next embedding)

    Training:
        loss = MSE(predicted_emb, target_emb) + λ * SIGReg(embeddings)

    Inference (planning):
        Given initial observation + action sequence → rollout predicted embeddings
        Compare to goal embedding → select best action sequence (CEM/Adam)
    """

    def __init__(
        self,
        encoder: nn.Module,
        predictor: ARPredictor,
        action_encoder: ActionEmbedder,
        projector: nn.Module = None,
        pred_proj: nn.Module = None,
    ):
        super().__init__()
        self.encoder = encoder
        self.predictor = predictor
        self.action_encoder = action_encoder
        self.projector = projector or nn.Identity()
        self.pred_proj = pred_proj or nn.Identity()

    def encode(self, info: Dict[str, Any]) -> Dict[str, Any]:
        """Encode observations and actions into embeddings.

        Args:
            info: Dict with "pixels" (B, T, C, H, W) and optional "action" (B, T, action_dim)

        Returns:
            info dict augmented with "emb" and optionally "act_emb"
        """
        pixels = info["pixels"].float()
        b = pixels.size(0)
        pixels = rearrange(pixels, "b t ... -> (b t) ...")

        # Encode through ViT backbone
        output = self.encoder(pixels, interpolate_pos_encoding=True)
        pixels_emb = output.last_hidden_state[:, 0]  # CLS token

        # Project to latent space
        emb = self.projector(pixels_emb)
        info["emb"] = rearrange(emb, "(b t) d -> b t d", b=b)

        if "action" in info:
            info["act_emb"] = self.action_encoder(info["action"])

        return info

    def predict(self, emb: torch.Tensor, act_emb: torch.Tensor) -> torch.Tensor:
        """Predict next-state embedding.

        Args:
            emb: (B, T, D) state embeddings
            act_emb: (B, T, D) action embeddings

        Returns:
            (B, T, D) predicted next-state embeddings
        """
        preds = self.predictor(emb, act_emb)
        preds = self.pred_proj(rearrange(preds, "b t d -> (b t) d"))
        return rearrange(preds, "(b t) d -> b t d", b=emb.size(0))

    def rollout(
        self,
        info: Dict[str, Any],
        action_sequence: torch.Tensor,
        history_size: int = 3,
    ) -> Dict[str, Any]:
        """Rollout the world model autoregressively for planning.

        Given initial observation and a sequence of candidate actions,
        predict the full trajectory of embeddings in latent space.

        Args:
            info: Dict with "pixels" (B, S, T, C, H, W) initial frames
            action_sequence: (B, S, T, action_dim) candidate action plans
                B = batch, S = number of action samples (CEM population), T = horizon
            history_size: Number of past frames for context

        Returns:
            info dict with "predicted_emb" (B, S, T+1, D) predicted trajectory
        """
        assert "pixels" in info, "pixels not in info dict"
        H = info["pixels"].size(2)  # History frames
        B, S, T = action_sequence.shape[:3]
        act_0, act_future = torch.split(action_sequence, [H, T - H], dim=2)
        info["action"] = act_0
        n_steps = T - H

        # Encode initial observation
        _init = {k: v[:, 0] for k, v in info.items() if torch.is_tensor(v)}
        _init = self.encode(_init)
        emb = info["emb"] = _init["emb"].unsqueeze(1).expand(B, S, -1, -1)
        _init = {k: _detach_clone(v) for k, v in _init.items()}

        # Flatten batch × samples for efficient rollout
        emb = rearrange(emb, "b s ... -> (b s) ...").clone()
        act = rearrange(act_0, "b s ... -> (b s) ...")
        act_future = rearrange(act_future, "b s ... -> (b s) ...")

        # Autoregressive rollout
        HS = history_size
        for t in range(n_steps):
            act_emb = self.action_encoder(act)
            emb_trunc = emb[:, -HS:]
            act_trunc = act_emb[:, -HS:]
            pred_emb = self.predict(emb_trunc, act_trunc)[:, -1:]
            emb = torch.cat([emb, pred_emb], dim=1)
            next_act = act_future[:, t:t + 1, :]
            act = torch.cat([act, next_act], dim=1)

        # Final prediction
        act_emb = self.action_encoder(act)
        pred_emb = self.predict(emb[:, -HS:], act_emb[:, -HS:])[:, -1:]
        emb = torch.cat([emb, pred_emb], dim=1)

        # Unflatten
        pred_rollout = rearrange(emb, "(b s) ... -> b s ...", b=B, s=S)
        info["predicted_emb"] = pred_rollout
        return info

    def compute_cost(
        self,
        info: Dict[str, Any],
        action_candidates: torch.Tensor,
    ) -> torch.Tensor:
        """Compute planning cost for action candidates.

        Used by CEM/Adam planners to evaluate action sequences:
        1. Rollout predicted embeddings for each action candidate
        2. Compare final predicted embedding to goal embedding
        3. Return per-candidate costs

        Args:
            info: Dict with "pixels" (initial obs) and "goal" (goal obs)
            action_candidates: (B, S, T, action_dim) candidate action plans

        Returns:
            (B, S) cost per action candidate (lower = better)
        """
        assert "goal" in info, "goal observation required for planning"

        device = next(self.parameters()).device
        for k in list(info.keys()):
            if torch.is_tensor(info[k]):
                info[k] = info[k].to(device)

        # Encode goal
        goal = {k: v[:, 0] for k, v in info.items() if torch.is_tensor(v)}
        goal["pixels"] = goal["goal"]
        for k in list(info.keys()):
            if k.startswith("goal_"):
                goal[k[len("goal_"):]] = goal.pop(k, None)
        goal.pop("action", None)
        goal = self.encode(goal)
        info["goal_emb"] = goal["emb"]

        # Rollout
        info = self.rollout(info, action_candidates)

        # Cost: MSE between final predicted embedding and goal embedding
        pred_emb = info["predicted_emb"]  # (B, S, T, D)
        goal_emb = info["goal_emb"]  # (B, S, T, D)
        goal_emb = goal_emb[..., -1:, :].expand_as(pred_emb)

        cost = F.mse_loss(
            pred_emb[..., -1:, :],
            goal_emb[..., -1:, :].detach(),
            reduction="none",
        ).sum(dim=tuple(range(2, pred_emb.ndim)))  # (B, S)

        return cost


# =============================================================================
# MLP Projectors — from le-wm/module.py
# =============================================================================


class MLPProjector(nn.Module):
    """MLP projector for embedding space transformations.

    Used for:
    - encoder output → latent space (projector)
    - predictor output → latent space (pred_proj)
    """

    def __init__(
        self,
        input_dim: int,
        hidden_dim: int,
        output_dim: int = None,
        norm_fn: type = nn.BatchNorm1d,
        act_fn: type = nn.GELU,
    ):
        super().__init__()
        output_dim = output_dim or input_dim
        norm = norm_fn(hidden_dim) if norm_fn is not None else nn.Identity()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            norm,
            act_fn(),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


# =============================================================================
# NeonWorldModel — high-level wrapper for Neon integration
# =============================================================================


@dataclass
class WorldModelConfig:
    """Configuration for the Neon world model.

    Tuned defaults for robotics (vs LeWM's DMC/PushT defaults):
    - Larger embed_dim (256 vs 192) for richer robot state
    - Deeper predictor (8 vs 6 layers) for complex dynamics
    - More history frames (4 vs 3) for temporal context
    """

    # Encoder
    encoder_type: str = "vit_tiny"  # "vit_tiny", "vit_small", "vit_base", or "neon_backbone"
    image_size: int = 224
    patch_size: int = 14
    freeze_encoder: bool = False  # End-to-end by default (LeWM's key insight)

    # Latent space
    embed_dim: int = 256
    hidden_dim: int = 384  # Transformer hidden size

    # Predictor
    predictor_depth: int = 8
    predictor_heads: int = 16
    predictor_mlp_dim: int = 2048
    predictor_dim_head: int = 64
    predictor_dropout: float = 0.1

    # Action space
    action_dim: int = 17  # G1 default: 14 arm + 3 loco

    # Training
    history_size: int = 4  # Number of context frames
    num_preds: int = 1  # Number of prediction steps in training
    sigreg_weight: float = 0.09  # λ for SIGReg loss
    sigreg_knots: int = 17
    sigreg_num_proj: int = 1024
    learning_rate: float = 5e-5
    weight_decay: float = 1e-3
    max_epochs: int = 100
    batch_size: int = 128

    # Planning
    planning_horizon: int = 16
    planning_samples: int = 512  # CEM population size
    planning_elites: int = 64  # Top-k for CEM


class NeonWorldModel(nn.Module):
    """High-level Neon world model combining LeWM JEPA with Neon's backbone.

    Two modes:
    1. **Standalone** (encoder_type="vit_tiny/small/base"):
       Small ViT encoder trained end-to-end with predictor.
       ~15M params, single GPU, few hours. Good for simulation.

    2. **Backbone-integrated** (encoder_type="neon_backbone"):
       Uses Neon's frozen VideoBackbone as encoder.
       Only trains predictor + projectors. Good for real-robot planning.

    Usage:
        # Standalone (simulation)
        wm = NeonWorldModel(WorldModelConfig(action_dim=17))
        loss = wm.compute_training_loss(pixels, actions)

        # With Neon backbone
        config = WorldModelConfig(encoder_type="neon_backbone", action_dim=17)
        wm = NeonWorldModel(config)
        wm.set_backbone(neon_vla.backbone)

        # Planning (both modes)
        cost = wm.plan(current_obs, goal_obs, action_candidates)
    """

    def __init__(self, config: WorldModelConfig):
        super().__init__()
        self.config = config

        # Build encoder
        if config.encoder_type == "neon_backbone":
            # Placeholder — set via set_backbone()
            self.encoder = None
            self._encoder_hidden = config.embed_dim  # Will be overridden
            logger.info("World model: using Neon backbone (call set_backbone())")
        else:
            self.encoder, self._encoder_hidden = self._build_vit_encoder(config)
            logger.info(f"World model: standalone {config.encoder_type} encoder")

        # Projectors (encoder output → latent space)
        self.projector = MLPProjector(
            input_dim=self._encoder_hidden,
            output_dim=config.embed_dim,
            hidden_dim=2048,
            norm_fn=nn.BatchNorm1d,
        )
        self.pred_proj = MLPProjector(
            input_dim=config.hidden_dim,
            output_dim=config.embed_dim,
            hidden_dim=2048,
            norm_fn=nn.BatchNorm1d,
        )

        # Action encoder
        self.action_encoder = ActionEmbedder(
            input_dim=config.action_dim,
            emb_dim=config.embed_dim,
        )

        # AR Predictor
        self.predictor = ARPredictor(
            num_frames=config.history_size,
            input_dim=config.embed_dim,
            hidden_dim=config.hidden_dim,
            output_dim=config.hidden_dim,
            depth=config.predictor_depth,
            heads=config.predictor_heads,
            mlp_dim=config.predictor_mlp_dim,
            dim_head=config.predictor_dim_head,
            dropout=config.predictor_dropout,
        )

        # SIGReg regularizer
        self.sigreg = SIGReg(
            knots=config.sigreg_knots,
            num_proj=config.sigreg_num_proj,
        )

        # JEPA wrapper
        self.jepa = JEPA(
            encoder=self.encoder or nn.Identity(),
            predictor=self.predictor,
            action_encoder=self.action_encoder,
            projector=self.projector,
            pred_proj=self.pred_proj,
        )

        # Parameter count
        total = sum(p.numel() for p in self.parameters())
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        logger.info(f"NeonWorldModel: {trainable:,} trainable / {total:,} total params")

    def _build_vit_encoder(self, config: WorldModelConfig):
        """Build a standalone ViT encoder for the world model."""
        try:
            from transformers import ViTModel, ViTConfig

            vit_configs = {
                "vit_tiny": {"hidden_size": 192, "num_hidden_layers": 12, "num_attention_heads": 3, "intermediate_size": 768},
                "vit_small": {"hidden_size": 384, "num_hidden_layers": 12, "num_attention_heads": 6, "intermediate_size": 1536},
                "vit_base": {"hidden_size": 768, "num_hidden_layers": 12, "num_attention_heads": 12, "intermediate_size": 3072},
            }

            if config.encoder_type not in vit_configs:
                raise ValueError(f"Unknown encoder_type: {config.encoder_type}")

            vit_cfg = vit_configs[config.encoder_type]
            hf_config = ViTConfig(
                image_size=config.image_size,
                patch_size=config.patch_size,
                **vit_cfg,
            )
            encoder = ViTModel(hf_config)
            hidden_size = vit_cfg["hidden_size"]

            if config.freeze_encoder:
                for p in encoder.parameters():
                    p.requires_grad = False

            return encoder, hidden_size

        except ImportError:
            logger.warning("transformers not available, using simple CNN encoder fallback")
            return self._build_simple_encoder(config)

    def _build_simple_encoder(self, config: WorldModelConfig):
        """Fallback CNN encoder when transformers is not available."""
        hidden = 192
        encoder = nn.Sequential(
            nn.Conv2d(3, 32, 7, stride=4, padding=3),
            nn.GELU(),
            nn.Conv2d(32, 64, 3, stride=2, padding=1),
            nn.GELU(),
            nn.Conv2d(64, hidden, 3, stride=2, padding=1),
            nn.GELU(),
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
        )
        return encoder, hidden

    def set_backbone(self, backbone: nn.Module):
        """Set Neon's VideoBackbone as the encoder.

        Args:
            backbone: Neon VideoBackbone instance (already loaded)
        """
        self.encoder = backbone
        self.jepa.encoder = backbone
        self._encoder_hidden = backbone.hidden_size

        # Rebuild projector if dimensions changed
        if self.projector.net[0].in_features != self._encoder_hidden:
            self.projector = MLPProjector(
                input_dim=self._encoder_hidden,
                output_dim=self.config.embed_dim,
                hidden_dim=2048,
                norm_fn=nn.BatchNorm1d,
            )
            self.jepa.projector = self.projector
            logger.info(f"Rebuilt projector: {self._encoder_hidden} → {self.config.embed_dim}")

    def encode_observation(self, pixels: torch.Tensor) -> torch.Tensor:
        """Encode a batch of observation images into latent embeddings.

        Works with both standalone ViT and Neon backbone.

        Args:
            pixels: (B, C, H, W) or (B, T, C, H, W) images

        Returns:
            (B, D) or (B, T, D) latent embeddings
        """
        has_time = pixels.ndim == 5
        if has_time:
            b, t = pixels.shape[:2]
            pixels = rearrange(pixels, "b t c h w -> (b t) c h w")

        if hasattr(self.encoder, "encode"):
            # Neon VideoBackbone
            result = self.encoder.encode(images=[pixels])
            emb = result["pooled"]
        elif hasattr(self.encoder, "last_hidden_state"):
            # HuggingFace ViT
            output = self.encoder(pixels, interpolate_pos_encoding=True)
            emb = output.last_hidden_state[:, 0]  # CLS token
        else:
            # Simple CNN fallback
            emb = self.encoder(pixels)

        emb = self.projector(emb)

        if has_time:
            emb = rearrange(emb, "(b t) d -> b t d", b=b, t=t)

        return emb

    def compute_training_loss(
        self,
        pixels: torch.Tensor,
        actions: torch.Tensor,
    ) -> Dict[str, torch.Tensor]:
        """Compute the LeWM training loss.

        Only 2 terms:
        1. Prediction loss: MSE(predicted_emb, target_emb)
        2. SIGReg: Gaussian regularization on embeddings

        Total: L = L_pred + λ * L_sigreg

        Args:
            pixels: (B, T, C, H, W) observation sequence
            actions: (B, T, action_dim) action sequence

        Returns:
            Dict with "loss", "pred_loss", "sigreg_loss"
        """
        ctx_len = self.config.history_size
        n_preds = self.config.num_preds
        lambd = self.config.sigreg_weight

        # Handle NaN (sequence boundaries)
        actions = torch.nan_to_num(actions, 0.0)

        # Encode
        info = {"pixels": pixels, "action": actions}
        output = self.jepa.encode(info)

        emb = output["emb"]  # (B, T, D)
        act_emb = output["act_emb"]

        # Context and target
        ctx_emb = emb[:, :ctx_len]
        ctx_act = act_emb[:, :ctx_len]
        tgt_emb = emb[:, n_preds:]  # Labels
        pred_emb = self.jepa.predict(ctx_emb, ctx_act)  # Predictions

        # Losses
        pred_loss = (pred_emb - tgt_emb).pow(2).mean()
        sigreg_loss = self.sigreg(emb.transpose(0, 1))
        total_loss = pred_loss + lambd * sigreg_loss

        return {
            "loss": total_loss,
            "pred_loss": pred_loss,
            "sigreg_loss": sigreg_loss,
        }

    def imagine(
        self,
        initial_emb: torch.Tensor,
        action_sequence: torch.Tensor,
        history_size: int = None,
    ) -> torch.Tensor:
        """Imagine future embeddings given initial state and action plan.

        Pure latent-space rollout — no pixel decoding needed.

        Args:
            initial_emb: (B, D) or (B, H, D) initial embeddings (H = history)
            action_sequence: (B, T, action_dim) action plan to execute

        Returns:
            (B, T+1, D) predicted embedding trajectory
        """
        HS = history_size or self.config.history_size

        if initial_emb.ndim == 2:
            initial_emb = initial_emb.unsqueeze(1)  # (B, 1, D)

        emb = initial_emb.clone()
        T = action_sequence.size(1)

        # Encode all actions at once
        full_act_emb = self.action_encoder(action_sequence)

        # Autoregressive rollout
        for t in range(T):
            # Truncate context to history window
            emb_ctx = emb[:, -HS:]
            # Build action context: use what we have so far
            t_start = max(0, t - HS + 1)
            act_ctx = full_act_emb[:, t_start:t + 1]

            # Pad action context if shorter than state context
            if act_ctx.size(1) < emb_ctx.size(1):
                pad = torch.zeros(
                    act_ctx.size(0),
                    emb_ctx.size(1) - act_ctx.size(1),
                    act_ctx.size(2),
                    device=act_ctx.device,
                )
                act_ctx = torch.cat([pad, act_ctx], dim=1)

            pred = self.jepa.predict(emb_ctx, act_ctx)[:, -1:]  # (B, 1, D)
            emb = torch.cat([emb, pred], dim=1)

        return emb

    @torch.no_grad()
    def surprise_score(
        self,
        pixels_t: torch.Tensor,
        pixels_t1: torch.Tensor,
        action: torch.Tensor,
    ) -> torch.Tensor:
        """Compute surprise score — how unexpected is the next observation?

        From LeWM: prediction error in latent space detects physically
        implausible events. High surprise = OOD or anomaly.

        For Neon:
        - Safety: high surprise → slow down, ask for help
        - Exploration: seek high-surprise states in RL
        - Data quality: filter training samples by surprise

        Args:
            pixels_t: (B, C, H, W) current observation
            pixels_t1: (B, C, H, W) next observation
            action: (B, action_dim) action taken

        Returns:
            (B,) surprise scores (higher = more unexpected)
        """
        self.eval()

        # Encode both observations
        z_t = self.encode_observation(pixels_t)  # (B, D)
        z_t1 = self.encode_observation(pixels_t1)  # (B, D)

        # Predict next embedding from current + action
        z_t_seq = z_t.unsqueeze(1)  # (B, 1, D)
        act_seq = action.unsqueeze(1)  # (B, 1, action_dim)
        act_emb = self.action_encoder(act_seq)
        z_pred = self.jepa.predict(z_t_seq, act_emb)[:, -1, :]  # (B, D)

        # Surprise = prediction error in latent space
        surprise = (z_pred - z_t1).pow(2).sum(dim=-1)  # (B,)
        return surprise

    def plan_cem(
        self,
        initial_emb: torch.Tensor,
        goal_emb: torch.Tensor,
        action_dim: int = None,
        horizon: int = None,
        num_samples: int = None,
        num_elites: int = None,
        num_iterations: int = 5,
    ) -> torch.Tensor:
        """Plan actions using Cross-Entropy Method (CEM) in latent space.

        48× faster than pixel-space planning because we never decode pixels.

        Args:
            initial_emb: (B, D) current state embedding
            goal_emb: (B, D) goal state embedding
            action_dim: Action dimensionality (default: config)
            horizon: Planning horizon (default: config)
            num_samples: CEM population size (default: config)
            num_elites: Top-k for CEM (default: config)
            num_iterations: CEM iterations

        Returns:
            (B, horizon, action_dim) best action plan
        """
        B = initial_emb.size(0)
        D = action_dim or self.config.action_dim
        H = horizon or self.config.planning_horizon
        S = num_samples or self.config.planning_samples
        K = num_elites or self.config.planning_elites
        device = initial_emb.device

        # Initialize CEM distribution
        mean = torch.zeros(B, H, D, device=device)
        std = torch.ones(B, H, D, device=device)

        best_actions = mean.clone()
        best_cost = torch.full((B,), float("inf"), device=device)

        for iteration in range(num_iterations):
            # Sample action candidates from current distribution
            noise = torch.randn(B, S, H, D, device=device)
            candidates = mean.unsqueeze(1) + std.unsqueeze(1) * noise
            candidates = candidates.clamp(-1, 1)  # Normalized action space

            # Evaluate each candidate via imagination rollout
            costs = torch.zeros(B, S, device=device)
            for s in range(S):
                traj = self.imagine(initial_emb, candidates[:, s])  # (B, H+1, D)
                final_emb = traj[:, -1, :]  # (B, D)
                costs[:, s] = (final_emb - goal_emb).pow(2).sum(dim=-1)

            # Select elites
            _, elite_idx = costs.topk(K, dim=1, largest=False)
            elite_actions = torch.gather(
                candidates,
                1,
                elite_idx.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, H, D),
            )

            # Update distribution
            mean = elite_actions.mean(dim=1)
            std = elite_actions.std(dim=1).clamp(min=0.01)

            # Track best
            batch_best_idx = costs.argmin(dim=1)
            batch_best_cost = costs[torch.arange(B), batch_best_idx]
            improved = batch_best_cost < best_cost
            best_cost[improved] = batch_best_cost[improved]
            best_actions[improved] = candidates[
                torch.arange(B)[improved],
                batch_best_idx[improved],
            ]

        return best_actions


# =============================================================================
# Factory function
# =============================================================================


def create_world_model(
    action_dim: int = 17,
    encoder_type: str = "vit_tiny",
    **kwargs,
) -> NeonWorldModel:
    """Create a NeonWorldModel with sensible defaults.

    Args:
        action_dim: Robot action dimensionality (default: 17 for G1)
        encoder_type: "vit_tiny", "vit_small", "vit_base", or "neon_backbone"
        **kwargs: Override any WorldModelConfig field

    Returns:
        NeonWorldModel ready for training or planning

    Examples:
        # Standalone for simulation
        wm = create_world_model(action_dim=17, encoder_type="vit_tiny")

        # With Neon backbone
        wm = create_world_model(action_dim=17, encoder_type="neon_backbone")
        wm.set_backbone(neon_vla.backbone)

        # Custom config
        wm = create_world_model(
            action_dim=29,
            encoder_type="vit_small",
            predictor_depth=12,
            planning_horizon=32,
        )
    """
    config = WorldModelConfig(
        action_dim=action_dim,
        encoder_type=encoder_type,
        **kwargs,
    )
    return NeonWorldModel(config)
