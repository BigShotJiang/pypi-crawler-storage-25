"""
NeonVLA — The core Vision-Language-Action model for G1.

Combines:
1. Video foundation model backbone (Qwen2.5-VL or Cosmos-Reason2)
2. Proprioception encoder (current joint states)
3. Multi-head action decoder (arms, locomotion, grippers)
4. Action chunking for temporal smoothness

The model takes (video_frames, language_instruction, proprioception)
and outputs a chunk of future actions for the G1 humanoid.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn

from neon.data.action_space import ControlMode, G1ActionSpace
from neon.model.action_heads import ActionHeadConfig, DiTActionHead, FlowMatchingHead, G1ActionHead
from neon.model.video_backbone import BackboneConfig, VideoBackbone
from neon.model.tribe_backbone import TribeBackboneConfig, TribeMultimodalBackbone

logger = logging.getLogger(__name__)


@dataclass
class NeonConfig:
    """Full configuration for the Neon VLA model."""

    # Backbone
    backbone: BackboneConfig = field(default_factory=BackboneConfig)
    # Backbone type: "omni" (default, single VLM) or "tribe" (native multimodal)
    backbone_type: str = "omni"  # "omni" | "tribe"
    # TRIBEv2 backbone config (used when backbone_type="tribe")
    tribe_backbone: Optional[TribeBackboneConfig] = None
    # Action space
    control_mode: str = "arms_only"  # "arms_only", "upper_body", "whole_body"
    include_locomotion: bool = True
    # Action head
    action_head_type: str = "mlp"  # "mlp" | "flow" | "dit"
    num_action_steps: int = 16  # Action chunk size
    mlp_hidden: int = 512
    action_head_layers: int = 3
    action_head_dropout: float = 0.1
    use_separate_heads: bool = True
    use_action_chunking: bool = True
    # Flow matching head settings (used when action_head_type="flow")
    flow_hidden_dim: int = 512
    flow_num_layers: int = 4
    flow_num_denoise_steps: int = 4
    flow_use_cross_attention: bool = False  # MolmoBot-Pi0 style cross-attn to backbone sequence
    flow_cross_attention_dim: Optional[int] = None  # Cross-attn KV dim (default: backbone hidden_size)
    # DiT head settings (used when action_head_type="dit")
    dit_hidden_dim: int = 384
    dit_num_layers: int = 8
    dit_num_heads: int = 6
    dit_num_denoise_steps: int = 4
    # Proprioception
    use_proprioception: bool = True
    proprioception_hidden: int = 128
    # Training
    learning_rate: float = 2e-4
    weight_decay: float = 0.01
    warmup_ratio: float = 0.1
    # Audio
    audio: Optional[Dict] = None  # AudioConfig as dict, or None to disable
    # LiDAR point cloud encoder
    use_lidar: bool = False  # Enable LiDAR point cloud input
    lidar_points: int = 4096  # Downsampled points per scan
    lidar_hidden: int = 128
    # End-effector state encoder
    use_eef: bool = False  # Enable EE state input (bimanual pos+quat)
    eef_dim: int = 14  # 7 per wrist (3 pos + 4 quat)
    eef_hidden: int = 64
    # GPS encoder (from OmniVLA — outdoor/warehouse navigation)
    use_gps: bool = False  # Enable GPS input [lat, lon, alt, heading, pitch, roll]
    gps_dim: int = 6  # 6-DOF: lat, lon, alt, heading, pitch, roll
    gps_hidden: int = 32
    # Depth encoder (from Cosmos-Transfer2.5 — spatial reasoning)
    use_depth: bool = False  # Enable monocular depth map input
    depth_hidden: int = 64
    # Segmentation encoder (from Cosmos-Transfer2.5 — semantic scene understanding)
    use_segmentation: bool = False  # Enable semantic segmentation mask input
    seg_num_classes: int = 20  # Number of semantic classes in seg mask
    seg_hidden: int = 64
    # Tactile encoder (NEW — G1 finger force/torque sensors)
    use_tactile: bool = False  # Enable tactile input (14 links × 6-axis F/T)
    tactile_num_links: int = 14
    tactile_ft_dim: int = 6  # 6-axis force/torque per link
    tactile_hidden: int = 32
    # IMU encoder (NEW — trunk IMU for locomotion stability)
    use_imu: bool = False  # Enable IMU input [accel(3) + gyro(3) + mag(3)]
    imu_dim: int = 9
    imu_hidden: int = 16
    # Force encoder (NEW — wrist F/T sensor)
    use_force: bool = False  # Enable wrist force/torque input
    force_dim: int = 6  # 6-axis F/T
    force_hidden: int = 16
    # Multi-embodiment support (GR00T N1.6 style)
    num_embodiments: int = 1  # Number of robot embodiments (1=single robot, default)
    # Beta noise scheduling for flow matching (GR00T N1.6)
    noise_beta_alpha: float = 0.0  # Beta(α, β) noise schedule; 0 = uniform U(0,1)
    noise_beta_beta: float = 0.0  # Set both > 0 to enable (e.g., 1.5, 1.0)

    def to_dict(self) -> Dict:
        return asdict(self)

    def save(self, path: str):
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, path: str) -> "NeonConfig":
        with open(path) as f:
            d = json.load(f)
        # Reconstruct nested configs
        if "backbone" in d and isinstance(d["backbone"], dict):
            d["backbone"] = BackboneConfig(**d["backbone"])
        return cls(**d)


@dataclass
class NeonOutput:
    """Output of a NeonVLA forward pass or prediction."""

    actions: np.ndarray  # (num_steps, action_dim) normalized to [-1, 1]
    raw_actions: Optional[np.ndarray] = None  # Denormalized actions
    upper_body: Optional[np.ndarray] = None  # (num_steps, 14) arm joint positions
    locomotion: Optional[np.ndarray] = None  # (num_steps, 3) vx, vy, omega
    gripper: Optional[np.ndarray] = None  # (num_steps, 2) gripper positions
    speech_path: Optional[str] = None  # Path to generated speech audio (from PersonaPlex)


class ProprioceptionEncoder(nn.Module):
    """Encodes current joint states into a feature vector.

    Proprioception is crucial for closed-loop control — the model needs
    to know where the robot currently is to predict good next actions.
    """

    def __init__(self, input_dim: int, hidden_dim: int = 128, output_dim: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
            nn.GELU(),
        )

    def forward(self, proprio: torch.Tensor) -> torch.Tensor:
        """Encode proprioception.

        Args:
            proprio: (batch, joint_dim) current joint positions

        Returns:
            (batch, output_dim) proprioception features
        """
        return self.net(proprio)


class PointCloudEncoder(nn.Module):
    """Encodes LiDAR point clouds into spatial feature vectors.

    Unitree L1 LiDAR: 21,600 points/scan → downsampled to 4,096 for training.
    Each point: (x, y, z, intensity) = 4 floats.

    Architecture: PointNet-style (shared MLPs + max-pool).
    Simple but effective — we don't need full PointNet++ for the
    relatively clean L1 scans. The key insight is that the robot
    needs spatial awareness (obstacles, table height, workspace bounds)
    not fine-grained 3D reconstruction.
    """

    def __init__(self, input_dim: int = 4, hidden_dim: int = 128, output_dim: int = 256):
        super().__init__()
        self.shared_mlp = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.GELU(),
            nn.Linear(64, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
        )
        self.projection = nn.Sequential(
            nn.Linear(hidden_dim, output_dim),
            nn.GELU(),
        )
        self._output_dim = output_dim

    @property
    def output_dim(self) -> int:
        return self._output_dim

    def forward(self, points: torch.Tensor) -> torch.Tensor:
        """Encode point cloud to spatial features.

        Args:
            points: (batch, N, 4) — N points with (x, y, z, intensity)

        Returns:
            (batch, output_dim) spatial feature vector
        """
        # Shared MLP on each point
        features = self.shared_mlp(points)  # (batch, N, hidden_dim)
        # Global max-pool (permutation invariant)
        pooled = features.max(dim=1).values  # (batch, hidden_dim)
        return self.projection(pooled)


class EEFEncoder(nn.Module):
    """Encodes end-effector state (position + quaternion) for both wrists.

    The G1 teleop dataset provides:
    - left_wrist_pos (3) + left_wrist_abs_quat (4) = 7
    - right_wrist_pos (3) + right_wrist_abs_quat (4) = 7
    Total: 14-DOF EE state

    This is complementary to joint proprioception — proprioception tells
    the model WHERE each joint is, EE state tells it WHERE the hands are
    in Cartesian space. Critical for manipulation tasks.
    """

    def __init__(self, input_dim: int = 14, hidden_dim: int = 64, output_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
            nn.GELU(),
        )
        self._output_dim = output_dim

    @property
    def output_dim(self) -> int:
        return self._output_dim

    def forward(self, eef_state: torch.Tensor) -> torch.Tensor:
        """Encode EE state.

        Args:
            eef_state: (batch, 14) bimanual EE pos + quat

        Returns:
            (batch, output_dim) EE features
        """
        return self.net(eef_state)


class GPSEncoder(nn.Module):
    """Encodes GPS/IMU state into a feature vector.

    Inspired by OmniVLA's multi-modal approach — GPS provides global
    position awareness for navigation-heavy tasks (warehouse pick, outdoor
    traversal). The 6-DOF input captures both position and orientation:

    Input: [latitude, longitude, altitude, heading, pitch, roll]

    Architecture: Same 2-layer MLP pattern as EEFEncoder.
    Output dim is 64 by default (small — GPS is a weak prior, we don't
    want it to dominate the fusion).
    """

    def __init__(self, input_dim: int = 6, hidden_dim: int = 32, output_dim: int = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
            nn.GELU(),
        )
        self._output_dim = output_dim

    @property
    def output_dim(self) -> int:
        return self._output_dim

    def forward(self, gps: torch.Tensor) -> torch.Tensor:
        """Encode GPS/IMU state.

        Args:
            gps: (batch, 6) [lat, lon, alt, heading, pitch, roll]

        Returns:
            (batch, output_dim) GPS features
        """
        return self.net(gps)


class DepthEncoder(nn.Module):
    """Encodes monocular depth maps into spatial feature vectors.

    Inspired by Cosmos-Transfer2.5 depth-conditioned generation.
    Single-channel depth maps from stereo cameras, LiDAR projection,
    or monocular depth estimation (e.g., Depth Anything V2).

    Architecture: lightweight CNN — 3 conv blocks with stride-2 downsampling
    + adaptive average pool + linear projection → 128-d features.
    Designed to run on Jetson Orin at 30Hz alongside the main pipeline.
    """

    def __init__(self, hidden_dim: int = 64, output_dim: int = 128):
        super().__init__()
        # 3-block CNN: 1→32→64→hidden_dim, each block halves spatial dims
        self.conv = nn.Sequential(
            # Block 1: (1, H, W) → (32, H/2, W/2)
            nn.Conv2d(1, 32, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.GELU(),
            # Block 2: (32, H/2, W/2) → (64, H/4, W/4)
            nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.GELU(),
            # Block 3: (64, H/4, W/4) → (hidden_dim, H/8, W/8)
            nn.Conv2d(64, hidden_dim, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(hidden_dim),
            nn.GELU(),
        )
        # Adaptive pool → fixed-size regardless of input resolution
        self.pool = nn.AdaptiveAvgPool2d(1)  # → (batch, hidden_dim, 1, 1)
        self.projection = nn.Sequential(
            nn.Linear(hidden_dim, output_dim),
            nn.GELU(),
        )
        self._output_dim = output_dim

    @property
    def output_dim(self) -> int:
        return self._output_dim

    def forward(self, depth: torch.Tensor) -> torch.Tensor:
        """Encode depth map.

        Args:
            depth: (batch, 1, H, W) single-channel depth map (float32, meters)

        Returns:
            (batch, output_dim) depth features
        """
        x = self.conv(depth)  # (batch, hidden_dim, H/8, W/8)
        x = self.pool(x)  # (batch, hidden_dim, 1, 1)
        x = x.flatten(1)  # (batch, hidden_dim)
        return self.projection(x)  # (batch, output_dim)


class SegmentationEncoder(nn.Module):
    """Encodes semantic segmentation masks into scene-understanding features.

    Inspired by Cosmos-Transfer2.5 segmentation-conditioned generation.
    Input is a multi-channel one-hot (or soft) segmentation mask where
    each channel represents one semantic class (table, cup, hand, floor, etc.).

    Architecture: Same lightweight CNN pattern as DepthEncoder but with
    variable input channels (num_classes). This lets the model learn
    which object classes matter for the current task.
    """

    def __init__(self, num_classes: int = 20, hidden_dim: int = 64, output_dim: int = 128):
        super().__init__()
        # 3-block CNN: num_classes→32→64→hidden_dim
        self.conv = nn.Sequential(
            # Block 1: (C, H, W) → (32, H/2, W/2)
            nn.Conv2d(num_classes, 32, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.GELU(),
            # Block 2: (32, H/2, W/2) → (64, H/4, W/4)
            nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.GELU(),
            # Block 3: (64, H/4, W/4) → (hidden_dim, H/8, W/8)
            nn.Conv2d(64, hidden_dim, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(hidden_dim),
            nn.GELU(),
        )
        # Adaptive pool → fixed-size regardless of input resolution
        self.pool = nn.AdaptiveAvgPool2d(1)  # → (batch, hidden_dim, 1, 1)
        self.projection = nn.Sequential(
            nn.Linear(hidden_dim, output_dim),
            nn.GELU(),
        )
        self._output_dim = output_dim

    @property
    def output_dim(self) -> int:
        return self._output_dim

    def forward(self, seg_mask: torch.Tensor) -> torch.Tensor:
        """Encode segmentation mask.

        Args:
            seg_mask: (batch, num_classes, H, W) one-hot or soft segmentation mask

        Returns:
            (batch, output_dim) segmentation features
        """
        x = self.conv(seg_mask)  # (batch, hidden_dim, H/8, W/8)
        x = self.pool(x)  # (batch, hidden_dim, 1, 1)
        x = x.flatten(1)  # (batch, hidden_dim)
        return self.projection(x)  # (batch, output_dim)


class TactileEncoder(nn.Module):
    """Encodes fingertip force/torque sensor readings.

    G1 hands have 14 finger links, each with a 6-axis force/torque sensor.
    Input: (batch, 14, 6) — 14 links × (fx, fy, fz, tx, ty, tz).

    Nobody else has this. Enables grasp refinement without vision —
    the robot can feel when an object is slipping or when grip force
    is sufficient. Critical for delicate manipulation (eggs, cups).

    Architecture: Per-link MLP → max-pool across links → projection.
    Similar to PointCloudEncoder but over finger links instead of 3D points.
    """

    def __init__(self, num_links: int = 14, ft_dim: int = 6, hidden_dim: int = 32, output_dim: int = 64):
        super().__init__()
        self.per_link_mlp = nn.Sequential(
            nn.Linear(ft_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
        )
        self.projection = nn.Sequential(
            nn.Linear(hidden_dim, output_dim),
            nn.GELU(),
        )
        self._output_dim = output_dim

    @property
    def output_dim(self) -> int:
        return self._output_dim

    def forward(self, tactile: torch.Tensor) -> torch.Tensor:
        """Encode tactile sensor data.

        Args:
            tactile: (batch, 14, 6) per-link force/torque

        Returns:
            (batch, output_dim) tactile features
        """
        # Per-link encoding
        link_features = self.per_link_mlp(tactile)  # (batch, 14, hidden_dim)
        # Max-pool across links (which finger is most informative?)
        pooled = link_features.max(dim=1).values  # (batch, hidden_dim)
        return self.projection(pooled)


class IMUEncoder(nn.Module):
    """Encodes IMU (accelerometer + gyroscope + magnetometer) readings.

    Input: (batch, 9) — 3 accel + 3 gyro + 3 magnetometer.

    Critical for locomotion stability — tells the model the robot's
    orientation and angular velocity without relying on vision.
    SONIC uses IMU implicitly via proprioception; we make it explicit
    so the model can learn balance-specific features.
    """

    def __init__(self, input_dim: int = 9, hidden_dim: int = 16, output_dim: int = 32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
            nn.GELU(),
        )
        self._output_dim = output_dim

    @property
    def output_dim(self) -> int:
        return self._output_dim

    def forward(self, imu: torch.Tensor) -> torch.Tensor:
        """Encode IMU state.

        Args:
            imu: (batch, 9) [ax, ay, az, gx, gy, gz, mx, my, mz]

        Returns:
            (batch, output_dim) IMU features
        """
        return self.net(imu)


class ForceEncoder(nn.Module):
    """Encodes 6-axis wrist force/torque sensor readings.

    Input: (batch, 6) — [fx, fy, fz, tx, ty, tz] from wrist F/T sensor.

    Essential for contact-rich manipulation: opening doors, pushing drawers,
    inserting connectors. The model needs to know applied forces to
    regulate them — vision alone cannot detect force magnitudes.
    """

    def __init__(self, input_dim: int = 6, hidden_dim: int = 16, output_dim: int = 32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
            nn.GELU(),
        )
        self._output_dim = output_dim

    @property
    def output_dim(self) -> int:
        return self._output_dim

    def forward(self, force: torch.Tensor) -> torch.Tensor:
        """Encode wrist force/torque.

        Args:
            force: (batch, 6) [fx, fy, fz, tx, ty, tz]

        Returns:
            (batch, output_dim) force features
        """
        return self.net(force)


class NeonVLA(nn.Module):
    """Neon Vision-Language-Action model for the G1 humanoid.

    Pipeline:
        1. Video backbone encodes (frames, language) → visual-language features
        2. Proprioception encoder encodes current joint states → proprio features
        3. Feature fusion: concat + project
        4. Action heads decode → action chunks

    Usage:
        model = NeonVLA(NeonConfig())
        model.load_backbone()  # Load video foundation model

        # Training
        loss = model.compute_loss(images, text, proprio, target_actions)

        # Inference
        output = model.predict(image, instruction, joint_states)
    """

    def __init__(self, config: NeonConfig):
        super().__init__()
        self.config = config

        # Build action space
        self.action_space = G1ActionSpace(
            mode=ControlMode(config.control_mode),
            include_locomotion=config.include_locomotion,
        )

        # Build video backbone (lazy-loaded)
        self.backbone = VideoBackbone(config.backbone)
        self._backbone_type = config.backbone_type

        # Build TRIBEv2 native multimodal backbone (alternative)
        self.tribe_backbone = None
        if config.backbone_type == "tribe":
            tribe_cfg = config.tribe_backbone or TribeBackboneConfig()
            self.tribe_backbone = TribeMultimodalBackbone(tribe_cfg)
            # Override hidden_size to match tribe backbone
            logger.info(
                f"Using TRIBEv2 native multimodal backbone "
                f"(V-JEPA2 + Wav2Vec-BERT + LLaMA, hidden={tribe_cfg.hidden_size})"
            )

        # Build audio encoder (optional)
        self.audio_encoder = None
        self.speech_head = None
        self.speaker = None
        self._audio_config = None

        # Determine active backbone hidden size (used throughout __init__)
        if config.backbone_type == "tribe" and self.tribe_backbone is not None:
            _backbone_hidden = self.tribe_backbone.hidden_size
        else:
            _backbone_hidden = self.backbone.hidden_size

        if config.audio is not None:
            from neon.model.audio import AudioConfig, AudioEncoder, PersonaPlexSpeaker, SpeechResponseHead

            self._audio_config = AudioConfig(**config.audio)
            if self._audio_config.enabled:
                self.audio_encoder = AudioEncoder(self._audio_config, _backbone_hidden)
                if self._audio_config.enable_speech_output:
                    self.speech_head = SpeechResponseHead(_backbone_hidden)
                    self.speaker = PersonaPlexSpeaker(self._audio_config)
                logger.info(f"Audio encoder enabled: {self._audio_config.encoder_type}")

        # Build proprioception encoder

        if config.use_proprioception:
            self.proprio_encoder = ProprioceptionEncoder(
                input_dim=self.action_space.action_dim,
                hidden_dim=config.proprioception_hidden,
                output_dim=config.proprioception_hidden * 2,
            )
            fusion_dim = _backbone_hidden + config.proprioception_hidden * 2
        else:
            self.proprio_encoder = None
            fusion_dim = _backbone_hidden

        # Add audio features to fusion if audio encoder is present
        if self.audio_encoder is not None:
            fusion_dim += self.audio_encoder.output_dim

        # Build LiDAR encoder (optional)
        self.lidar_encoder = None
        if config.use_lidar:
            self.lidar_encoder = PointCloudEncoder(
                input_dim=4,  # x, y, z, intensity
                hidden_dim=config.lidar_hidden,
                output_dim=config.lidar_hidden * 2,
            )
            fusion_dim += self.lidar_encoder.output_dim
            logger.info(f"LiDAR encoder enabled: {config.lidar_points} points → {self.lidar_encoder.output_dim}d")

        # Build EEF encoder (optional)
        self.eef_encoder = None
        if config.use_eef:
            self.eef_encoder = EEFEncoder(
                input_dim=config.eef_dim,
                hidden_dim=config.eef_hidden,
                output_dim=config.eef_hidden * 2,
            )
            fusion_dim += self.eef_encoder.output_dim
            logger.info(f"EEF encoder enabled: {config.eef_dim}d → {self.eef_encoder.output_dim}d")

        # Build GPS encoder (optional)
        self.gps_encoder = None
        if config.use_gps:
            self.gps_encoder = GPSEncoder(
                input_dim=config.gps_dim,
                hidden_dim=config.gps_hidden,
                output_dim=config.gps_hidden * 2,
            )
            fusion_dim += self.gps_encoder.output_dim
            logger.info(f"GPS encoder enabled: {config.gps_dim}d → {self.gps_encoder.output_dim}d")

        # Build Depth encoder (optional)
        self.depth_encoder = None
        if config.use_depth:
            self.depth_encoder = DepthEncoder(
                hidden_dim=config.depth_hidden,
                output_dim=config.depth_hidden * 2,
            )
            fusion_dim += self.depth_encoder.output_dim
            logger.info(f"Depth encoder enabled: (1,H,W) → {self.depth_encoder.output_dim}d")

        # Build Segmentation encoder (optional)
        self.seg_encoder = None
        if config.use_segmentation:
            self.seg_encoder = SegmentationEncoder(
                num_classes=config.seg_num_classes,
                hidden_dim=config.seg_hidden,
                output_dim=config.seg_hidden * 2,
            )
            fusion_dim += self.seg_encoder.output_dim
            logger.info(f"Segmentation encoder enabled: ({config.seg_num_classes},H,W) → {self.seg_encoder.output_dim}d")

        # Build Tactile encoder (optional — NEW)
        self.tactile_encoder = None
        if config.use_tactile:
            self.tactile_encoder = TactileEncoder(
                num_links=config.tactile_num_links,
                ft_dim=config.tactile_ft_dim,
                hidden_dim=config.tactile_hidden,
                output_dim=config.tactile_hidden * 2,
            )
            fusion_dim += self.tactile_encoder.output_dim
            logger.info(f"Tactile encoder enabled: ({config.tactile_num_links},{config.tactile_ft_dim}) → {self.tactile_encoder.output_dim}d")

        # Build IMU encoder (optional — NEW)
        self.imu_encoder = None
        if config.use_imu:
            self.imu_encoder = IMUEncoder(
                input_dim=config.imu_dim,
                hidden_dim=config.imu_hidden,
                output_dim=config.imu_hidden * 2,
            )
            fusion_dim += self.imu_encoder.output_dim
            logger.info(f"IMU encoder enabled: {config.imu_dim}d → {self.imu_encoder.output_dim}d")

        # Build Force encoder (optional — NEW)
        self.force_encoder = None
        if config.use_force:
            self.force_encoder = ForceEncoder(
                input_dim=config.force_dim,
                hidden_dim=config.force_hidden,
                output_dim=config.force_hidden * 2,
            )
            fusion_dim += self.force_encoder.output_dim
            logger.info(f"Force encoder enabled: {config.force_dim}d → {self.force_encoder.output_dim}d")

        # Feature fusion projection
        self.fusion = nn.Sequential(
            nn.Linear(fusion_dim, _backbone_hidden),
            nn.GELU(),
            nn.Dropout(config.action_head_dropout),
        )

        # Build action heads — select based on action_head_type
        if config.action_head_type == "flow":
            self.action_head = FlowMatchingHead(
                input_dim=_backbone_hidden,
                action_dim=self.action_space.action_dim,
                num_steps=config.num_action_steps,
                hidden_dim=config.flow_hidden_dim,
                num_layers=config.flow_num_layers,
                dropout=config.action_head_dropout,
                num_denoise_steps=config.flow_num_denoise_steps,
                noise_beta_alpha=config.noise_beta_alpha,
                noise_beta_beta=config.noise_beta_beta,
                use_cross_attention=config.flow_use_cross_attention,
                cross_attention_dim=config.flow_cross_attention_dim,
            )
            noise_info = f"Beta({config.noise_beta_alpha}, {config.noise_beta_beta})" if config.noise_beta_alpha > 0 else "Uniform"
            ca_info = ", cross-attn" if config.flow_use_cross_attention else ""
            logger.info(f"Action head: FlowMatchingHead ({config.flow_num_denoise_steps} denoise steps, {noise_info} noise{ca_info})")
        elif config.action_head_type == "dit":
            self.action_head = DiTActionHead(
                input_dim=_backbone_hidden,
                action_dim=self.action_space.action_dim,
                num_steps=config.num_action_steps,
                hidden_dim=config.dit_hidden_dim,
                num_layers=config.dit_num_layers,
                num_heads=config.dit_num_heads,
                dropout=config.action_head_dropout,
                num_denoise_steps=config.dit_num_denoise_steps,
            )
            logger.info(f"Action head: DiTActionHead ({config.dit_num_layers} layers, {config.dit_num_heads} heads)")
        elif config.action_head_type == "mlp":
            head_config = ActionHeadConfig(
                hidden_size=_backbone_hidden,
                action_dim=self.action_space.action_dim,
                num_action_steps=config.num_action_steps,
                mlp_hidden=config.mlp_hidden,
                num_layers=config.action_head_layers,
                dropout=config.action_head_dropout,
                use_separate_heads=config.use_separate_heads,
                use_action_chunking=config.use_action_chunking,
            )
            self.action_head = G1ActionHead(head_config, self.action_space)
            logger.info("Action head: G1ActionHead (MLP)")
        elif config.action_head_type == "ensemble":
            from neon.model.action_heads import EnsembleHead
            self.action_head = EnsembleHead(
                input_dim=_backbone_hidden,
                action_dim=self.action_space.action_dim,
                num_steps=config.num_action_steps,
                mlp_hidden=config.mlp_hidden,
                flow_hidden=config.flow_hidden_dim,
                dit_hidden=config.dit_hidden_dim,
                dit_layers=config.dit_num_layers,
                dit_heads=config.dit_num_heads,
                flow_layers=config.flow_num_layers,
                dropout=config.action_head_dropout,
                num_denoise_steps=config.flow_num_denoise_steps,
            )
            logger.info("Action head: EnsembleHead (gated MLP+Flow+DiT)")
        else:
            raise ValueError(
                f"Unknown action_head_type={config.action_head_type!r}. "
                f"Must be 'mlp', 'flow', 'dit', or 'ensemble'."
            )

        logger.info(f"NeonVLA initialized: {self.action_space}")

    def load_backbone(self):
        """Load the video backbone model weights. Call before training/inference."""
        if self._backbone_type == "tribe" and self.tribe_backbone is not None:
            self.tribe_backbone.load()
        else:
            self.backbone.load()

    @property
    def _active_backbone_hidden_size(self) -> int:
        """Get the hidden size of the active backbone."""
        if self._backbone_type == "tribe" and self.tribe_backbone is not None:
            return self.tribe_backbone.hidden_size
        return self.backbone.hidden_size

    def _encode_features(
        self,
        images: Optional[List] = None,
        video_frames: Optional[List] = None,
        text: Optional[str] = None,
        proprioception: Optional[torch.Tensor] = None,
        audio: Optional[torch.Tensor] = None,
        lidar: Optional[torch.Tensor] = None,
        eef_state: Optional[torch.Tensor] = None,
        gps: Optional[torch.Tensor] = None,
        depth: Optional[torch.Tensor] = None,
        segmentation: Optional[torch.Tensor] = None,
        tactile: Optional[torch.Tensor] = None,
        imu: Optional[torch.Tensor] = None,
        force: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Encode all modalities and fuse into a single feature vector.

        Returns:
            (batch, hidden_size) fused features ready for action head
        """
        # Encode visual + language (route through active backbone)
        if self._backbone_type == "tribe" and self.tribe_backbone is not None:
            # TRIBEv2: native multimodal encoding — video, audio, text all go through
            # separate specialized encoders + Transformer fusion
            backbone_out = self.tribe_backbone.encode(
                images=images,
                video_frames=video_frames,
                text=text,
                audio=audio,  # Audio handled natively by Wav2Vec-BERT
            )
            features = backbone_out["pooled"]  # (batch, hidden_size)
            # Audio already encoded in tribe backbone — skip separate audio encoder
            audio = None  # Prevent double-encoding below
        else:
            # Omni backbone (Qwen2.5-VL/Omni, Cosmos)
            backbone_out = self.backbone.encode(images=images, video_frames=video_frames, text=text)
            features = backbone_out["pooled"]  # (batch, hidden_size)

        # Fuse with proprioception
        if self.proprio_encoder is not None and proprioception is not None:
            proprio_feat = self.proprio_encoder(proprioception)
            features = torch.cat([features, proprio_feat], dim=-1)

        # Fuse with audio features
        if self.audio_encoder is not None and audio is not None:
            audio_feat = self.audio_encoder(audio)  # (batch, audio_output_dim)
            features = torch.cat([features, audio_feat], dim=-1)

        # Fuse with LiDAR point cloud
        if self.lidar_encoder is not None and lidar is not None:
            lidar_feat = self.lidar_encoder(lidar)  # (batch, lidar_output_dim)
            features = torch.cat([features, lidar_feat], dim=-1)

        # Fuse with end-effector state
        if self.eef_encoder is not None and eef_state is not None:
            eef_feat = self.eef_encoder(eef_state)  # (batch, eef_output_dim)
            features = torch.cat([features, eef_feat], dim=-1)

        # Fuse with GPS/IMU state
        if self.gps_encoder is not None and gps is not None:
            gps_feat = self.gps_encoder(gps)  # (batch, gps_output_dim)
            features = torch.cat([features, gps_feat], dim=-1)

        # Fuse with depth map
        if self.depth_encoder is not None and depth is not None:
            depth_feat = self.depth_encoder(depth)  # (batch, depth_output_dim)
            features = torch.cat([features, depth_feat], dim=-1)

        # Fuse with segmentation mask
        if self.seg_encoder is not None and segmentation is not None:
            seg_feat = self.seg_encoder(segmentation)  # (batch, seg_output_dim)
            features = torch.cat([features, seg_feat], dim=-1)

        # Fuse with tactile (NEW)
        if self.tactile_encoder is not None and tactile is not None:
            tactile_feat = self.tactile_encoder(tactile)  # (batch, tactile_output_dim)
            features = torch.cat([features, tactile_feat], dim=-1)

        # Fuse with IMU (NEW)
        if self.imu_encoder is not None and imu is not None:
            imu_feat = self.imu_encoder(imu)  # (batch, imu_output_dim)
            features = torch.cat([features, imu_feat], dim=-1)

        # Fuse with wrist force/torque (NEW)
        if self.force_encoder is not None and force is not None:
            force_feat = self.force_encoder(force)  # (batch, force_output_dim)
            features = torch.cat([features, force_feat], dim=-1)

        features = self.fusion(features)
        return features

    def forward(
        self,
        images: Optional[List] = None,
        video_frames: Optional[List] = None,
        text: Optional[str] = None,
        proprioception: Optional[torch.Tensor] = None,
        audio: Optional[torch.Tensor] = None,
        lidar: Optional[torch.Tensor] = None,
        eef_state: Optional[torch.Tensor] = None,
        gps: Optional[torch.Tensor] = None,
        depth: Optional[torch.Tensor] = None,
        segmentation: Optional[torch.Tensor] = None,
        tactile: Optional[torch.Tensor] = None,
        imu: Optional[torch.Tensor] = None,
        force: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Forward pass — encode all modalities and decode actions.

        Args:
            images: List of PIL images (single-frame input)
            video_frames: List of PIL images as video sequence
            text: Language instruction (text)
            proprioception: (batch, action_dim) current joint states
            audio: (batch, samples) raw audio waveform at 16kHz
            lidar: (batch, N, 4) point cloud (x, y, z, intensity)
            eef_state: (batch, 14) bimanual end-effector pos+quat
            gps: (batch, 6) GPS/IMU state [lat, lon, alt, heading, pitch, roll]
            depth: (batch, 1, H, W) monocular depth map
            segmentation: (batch, num_classes, H, W) semantic segmentation mask
            tactile: (batch, 14, 6) finger force/torque sensors
            imu: (batch, 9) accelerometer + gyroscope + magnetometer
            force: (batch, 6) wrist force/torque sensor

        Returns:
            If action_chunking: (batch, num_steps, action_dim)
            Else: (batch, action_dim)
        """
        features = self._encode_features(
            images, video_frames, text, proprioception, audio, lidar, eef_state,
            gps=gps, depth=depth, segmentation=segmentation,
            tactile=tactile, imu=imu, force=force,
        )

        # Decode actions — flow/dit heads take features directly (they sample internally)
        # MLP heads also take features directly
        actions = self.action_head(features)
        return actions

    def compute_loss(
        self,
        images: Optional[List] = None,
        video_frames: Optional[List] = None,
        text: Optional[str] = None,
        proprioception: Optional[torch.Tensor] = None,
        target_actions: Optional[torch.Tensor] = None,
        action_mask: Optional[torch.Tensor] = None,
        audio: Optional[torch.Tensor] = None,
        lidar: Optional[torch.Tensor] = None,
        eef_state: Optional[torch.Tensor] = None,
        gps: Optional[torch.Tensor] = None,
        depth: Optional[torch.Tensor] = None,
        segmentation: Optional[torch.Tensor] = None,
        tactile: Optional[torch.Tensor] = None,
        imu: Optional[torch.Tensor] = None,
        force: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """Compute training loss.

        For MLP head: forward pass → MSE(predicted, target)
        For flow/dit head: encode features → head.compute_loss(features, target)
            (flow matching or DDPM noise prediction loss internally)

        Args:
            images, video_frames, text, proprioception, audio, lidar, eef_state: Model inputs
            gps: (batch, 6) GPS/IMU state
            depth: (batch, 1, H, W) depth map
            segmentation: (batch, num_classes, H, W) segmentation mask
            target_actions: Ground truth action chunks (batch, num_steps, action_dim)
            action_mask: Valid timestep mask (batch, num_steps)

        Returns:
            Dict with "loss" and optional per-group losses
        """
        # Flow, DiT, and Ensemble heads compute loss differently — they need features, not predicted actions
        if self.config.action_head_type in ("flow", "dit", "ensemble"):
            features = self._encode_features(
                images, video_frames, text, proprioception,
                audio=audio, lidar=lidar, eef_state=eef_state,
                gps=gps, depth=depth, segmentation=segmentation,
                tactile=tactile, imu=imu, force=force,
            )
            loss = self.action_head.compute_loss(features, target_actions, action_mask)
            return {"loss": loss, "head_type": self.config.action_head_type}

        # MLP head: forward pass then MSE
        predicted = self.forward(
            images, video_frames, text, proprioception,
            audio=audio, lidar=lidar, eef_state=eef_state,
            gps=gps, depth=depth, segmentation=segmentation,
            tactile=tactile, imu=imu, force=force,
        )
        loss = self.action_head.compute_loss(predicted, target_actions, action_mask)
        return {"loss": loss, "head_type": "mlp"}

    @torch.no_grad()
    def predict(
        self,
        image: Any = None,
        video_frames: Optional[List] = None,
        instruction: str = "",
        proprioception: Optional[np.ndarray] = None,
        audio: Optional[np.ndarray] = None,
        lidar: Optional[np.ndarray] = None,
        eef_state: Optional[np.ndarray] = None,
        gps: Optional[np.ndarray] = None,
        depth: Optional[np.ndarray] = None,
        segmentation: Optional[np.ndarray] = None,
        tactile: Optional[np.ndarray] = None,
        imu: Optional[np.ndarray] = None,
        force: Optional[np.ndarray] = None,
        speak: bool = False,
    ) -> NeonOutput:
        """Run inference — predict actions from observations.

        Args:
            image: Single PIL image (current camera frame)
            video_frames: List of recent camera frames
            instruction: Natural language instruction (text)
            proprioception: Current joint positions (action_dim,)
            audio: Raw audio waveform at 16kHz (samples,) — spoken command
            lidar: Point cloud (N, 4) — (x, y, z, intensity)
            eef_state: End-effector state (14,) — bimanual pos+quat
            gps: GPS/IMU state (6,) — [lat, lon, alt, heading, pitch, roll]
            depth: Depth map (1, H, W) or (H, W) — float32 meters
            segmentation: Segmentation mask (num_classes, H, W) — one-hot
            speak: If True, robot narrates its action via PersonaPlex

        Returns:
            NeonOutput with predicted actions (and optional speech_path)
        """
        self.eval()

        # Prepare inputs
        images = [image] if image is not None else None
        device = next(self.action_head.parameters()).device

        # Proprioception
        proprio_tensor = None
        if proprioception is not None and self.proprio_encoder is not None:
            proprio_tensor = torch.from_numpy(proprioception).float().unsqueeze(0).to(device)

        # Audio
        audio_tensor = None
        if audio is not None and self.audio_encoder is not None:
            audio_tensor = torch.from_numpy(audio).float().unsqueeze(0).to(device)

        # LiDAR
        lidar_tensor = None
        if lidar is not None and self.lidar_encoder is not None:
            lidar_tensor = torch.from_numpy(lidar).float().unsqueeze(0).to(device)

        # EEF state
        eef_tensor = None
        if eef_state is not None and self.eef_encoder is not None:
            eef_tensor = torch.from_numpy(eef_state).float().unsqueeze(0).to(device)

        # GPS/IMU state
        gps_tensor = None
        if gps is not None and self.gps_encoder is not None:
            gps_tensor = torch.from_numpy(gps).float().unsqueeze(0).to(device)

        # Depth map
        depth_tensor = None
        if depth is not None and self.depth_encoder is not None:
            depth_tensor = torch.from_numpy(depth).float().unsqueeze(0).to(device)
            # Ensure (batch, 1, H, W) shape
            if depth_tensor.ndim == 3:
                depth_tensor = depth_tensor.unsqueeze(1)  # (batch, H, W) → (batch, 1, H, W)

        # Segmentation mask
        seg_tensor = None
        if segmentation is not None and self.seg_encoder is not None:
            seg_tensor = torch.from_numpy(segmentation).float().unsqueeze(0).to(device)

        # Tactile (NEW)
        tactile_tensor = None
        if tactile is not None and self.tactile_encoder is not None:
            tactile_tensor = torch.from_numpy(tactile).float().unsqueeze(0).to(device)

        # IMU (NEW)
        imu_tensor = None
        if imu is not None and self.imu_encoder is not None:
            imu_tensor = torch.from_numpy(imu).float().unsqueeze(0).to(device)

        # Force (NEW)
        force_tensor = None
        if force is not None and self.force_encoder is not None:
            force_tensor = torch.from_numpy(force).float().unsqueeze(0).to(device)

        # Forward
        # For flow/dit heads, use .sample() explicitly for clarity
        # (forward() already calls sample(), but being explicit is better)
        if self.config.action_head_type in ("flow", "dit", "ensemble"):
            features = self._encode_features(
                images=images,
                video_frames=video_frames,
                text=instruction,
                proprioception=proprio_tensor,
                audio=audio_tensor,
                lidar=lidar_tensor,
                eef_state=eef_tensor,
                gps=gps_tensor,
                depth=depth_tensor,
                segmentation=seg_tensor,
                tactile=tactile_tensor,
                imu=imu_tensor,
                force=force_tensor,
            )
            actions_tensor = self.action_head.sample(features)
        else:
            actions_tensor = self.forward(
                images=images,
                video_frames=video_frames,
                text=instruction,
                proprioception=proprio_tensor,
                audio=audio_tensor,
                lidar=lidar_tensor,
                eef_state=eef_tensor,
                gps=gps_tensor,
                depth=depth_tensor,
                segmentation=seg_tensor,
                tactile=tactile_tensor,
                imu=imu_tensor,
                force=force_tensor,
            )

        # To numpy
        actions_np = actions_tensor.cpu().numpy().squeeze(0)  # (num_steps, action_dim) or (action_dim,)
        if actions_np.ndim == 1:
            actions_np = actions_np[np.newaxis, :]  # (1, action_dim)

        # Denormalize
        raw_actions = np.stack([self.action_space.denormalize(a) for a in actions_np])

        # Split into groups
        split = self.action_space.split_action(raw_actions)

        output = NeonOutput(
            actions=actions_np,
            raw_actions=raw_actions,
            upper_body=np.concatenate(
                [split.get("left_arm", np.array([])), split.get("right_arm", np.array([]))], axis=-1
            ) if "left_arm" in split else None,
            locomotion=split.get("locomotion"),
            gripper=None,  # Extracted from arms if needed
        )

        # Speech output
        if speak and self.speaker is not None:
            speech_path = self.speaker.speak(f"Executing: {instruction}")
            output.speech_path = speech_path

        return output

    def save_pretrained(self, path: str):
        """Save model config + action head weights.

        Note: Backbone weights are loaded from HuggingFace separately.
        We only save the action heads + fusion layers + proprio encoder.
        """
        save_dir = Path(path)
        save_dir.mkdir(parents=True, exist_ok=True)

        # Save config
        self.config.save(str(save_dir / "config.json"))

        # Save action space
        with open(save_dir / "action_space.json", "w") as f:
            json.dump(self.action_space.to_dict(), f, indent=2)

        # Save trainable weights (action heads, fusion, proprio encoder)
        state = {}
        for name, param in self.named_parameters():
            if param.requires_grad or "action_head" in name or "fusion" in name or "proprio" in name or "lidar" in name or "eef" in name or "audio" in name or "speech" in name or "flow" in name or "dit" in name or "gps" in name or "depth" in name or "seg" in name or "tactile" in name or "imu" in name or "force" in name:
                state[name] = param.cpu()

        torch.save(state, save_dir / "neon_weights.pt")
        logger.info(f"Saved Neon model to {save_dir} ({len(state)} tensors)")

    @classmethod
    def from_pretrained(cls, path: str, load_backbone: bool = False) -> "NeonVLA":
        """Load a saved Neon model.

        Args:
            path: Path to saved model directory or HuggingFace model ID
            load_backbone: If True, also load the video backbone

        Returns:
            NeonVLA instance with loaded weights
        """
        model_dir = Path(path)

        # Check if it's a HuggingFace model ID
        if not model_dir.exists():
            from huggingface_hub import snapshot_download

            model_dir = Path(snapshot_download(path))

        # Load config
        config = NeonConfig.load(str(model_dir / "config.json"))

        # Create model
        model = cls(config)

        # Load trainable weights
        weights_path = model_dir / "neon_weights.pt"
        if weights_path.exists():
            state = torch.load(weights_path, map_location="cpu", weights_only=True)
            missing, unexpected = model.load_state_dict(state, strict=False)
            logger.info(f"Loaded Neon weights: {len(state)} tensors, {len(missing)} missing, {len(unexpected)} unexpected")

        # Optionally load backbone
        if load_backbone:
            model.load_backbone()

        return model

    def __repr__(self) -> str:
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        total = sum(p.numel() for p in self.parameters())
        return (
            f"NeonVLA(\n"
            f"  backbone={self.config.backbone.model_id},\n"
            f"  action_space={self.action_space},\n"
            f"  action_chunking={self.config.use_action_chunking} (steps={self.config.num_action_steps}),\n"
            f"  trainable={trainable:,} / {total:,} params\n"
            f")"
        )
