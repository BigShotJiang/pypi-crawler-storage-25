"""
TRIBEv2 Native Multimodal Backbone — V-JEPA2 (video) + Wav2Vec-BERT (audio) + LLaMA (text).

Why this over an omni model (Qwen2.5-VL/Omni)?
────────────────────────────────────────────────
1. **Native modality encoders** — V-JEPA2 learns video through self-supervised
   joint-embedding prediction, NOT next-token prediction. It understands physics,
   motion, and temporal dynamics natively. Wav2Vec-BERT processes raw audio waveforms
   natively (not text-transcribed). LLaMA processes language natively.

2. **Better feature quality per modality** — Omni models compress all modalities into
   one token stream. TRIBE keeps each encoder specialized, then fuses via Transformer.
   Each encoder is SOTA for its modality.

3. **Flexible modality availability** — Robot may have video but no audio, or audio but
   no camera. TRIBE's per-modality projectors + modality dropout handle missing inputs
   gracefully. Omni models choke on missing modalities.

4. **Compute efficiency** — Freeze each encoder, only train projectors + fusion
   Transformer + action heads. Much smaller trainable parameter count.

Models used:
- Video: facebook/vjepa2-vitg-fpc64-256 (V-JEPA2 ViT-G, 64-frame, 256px)
- Audio: facebook/w2v-bert-2.0 (Wav2Vec-BERT 2.0, 4.5B params pre-training)
- Text: meta-llama/Llama-3.2-3B (LLaMA 3.2 3B, instruction-tuned)

Reference:
    d'Ascoli et al. "A foundation model of vision, audition, and language
    for in-silico neuroscience." Meta AI, 2026.
    https://github.com/facebookresearch/tribev2

License: MIT (this file), CC-BY-NC-4.0 (TRIBEv2 original)
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


# =============================================================================
# Configuration
# =============================================================================


@dataclass
class TribeBackboneConfig:
    """Configuration for the TRIBEv2-style native multimodal backbone.

    Unlike BackboneConfig (single omni model), this uses separate
    SOTA encoders per modality and fuses them via a Transformer.
    """

    # ── Video encoder (V-JEPA2) ──
    video_model_id: str = "facebook/vjepa2-vitg-fpc64-256"
    video_enabled: bool = True
    video_fps: int = 4
    video_max_frames: int = 16
    video_image_size: int = 256  # V-JEPA2 native res
    video_freeze: bool = True
    # V-JEPA2 layer selection (TRIBE concatenates multiple layers)
    video_layers: Optional[List[int]] = None  # None = last layer only

    # ── Audio encoder (Wav2Vec-BERT 2.0) ──
    audio_model_id: str = "facebook/w2v-bert-2.0"
    audio_enabled: bool = True
    audio_sample_rate: int = 16000
    audio_max_seconds: float = 15.0
    audio_freeze: bool = True

    # ── Text encoder (LLaMA 3.2) ──
    text_model_id: str = "meta-llama/Llama-3.2-3B"
    text_enabled: bool = True
    text_max_length: int = 256
    text_freeze: bool = True

    # ── Fusion ──
    hidden_size: int = 512  # Fusion Transformer hidden dim
    num_fusion_layers: int = 4  # Transformer encoder layers
    num_fusion_heads: int = 8
    fusion_dropout: float = 0.1
    max_seq_len: int = 512  # Max fused sequence length

    # ── TRIBEv2 techniques ──
    modality_dropout: float = 0.1  # Drop entire modalities during training
    temporal_dropout: float = 0.05  # Drop random timesteps
    temporal_smoothing: bool = True  # Gaussian temporal smoothing
    smoothing_kernel: int = 5
    smoothing_sigma: float = 1.5
    time_pos_embedding: bool = True  # Learnable temporal position embeddings

    # ── Quantization & dtype ──
    torch_dtype: str = "bfloat16"
    load_in_4bit: bool = False  # V-JEPA2/W2V are frozen, 4-bit OK
    device_map: str = "auto"

    # ── Layer aggregation (from TRIBE) ──
    layer_aggregation: str = "cat"  # "cat" or "mean"
    extractor_aggregation: str = "cat"  # How to combine modality features


# =============================================================================
# Per-modality encoders
# =============================================================================


class VJEPAVideoEncoder(nn.Module):
    """V-JEPA2 video encoder — self-supervised video understanding.

    V-JEPA2 learns video representations through joint-embedding
    predictive architecture. Unlike contrastive methods, it predicts
    masked spatio-temporal regions in embedding space, learning rich
    temporal dynamics without text supervision.

    For robotics:
    - Understands object motion trajectories
    - Encodes physics (gravity, collision, deformation)
    - Temporal coherence between frames
    - No text supervision needed → pure visual understanding
    """

    def __init__(self, config: TribeBackboneConfig):
        super().__init__()
        self.config = config
        self._model = None
        self._processor = None
        self._hidden_size = 0

    @property
    def hidden_size(self) -> int:
        if self._hidden_size > 0:
            return self._hidden_size
        # V-JEPA2 ViT-G hidden sizes
        model_id = self.config.video_model_id.lower()
        if "vitg" in model_id or "vit-g" in model_id:
            return 1408  # ViT-Giant
        elif "vitl" in model_id or "vit-l" in model_id:
            return 1024
        elif "vith" in model_id or "vit-h" in model_id:
            return 1280
        return 1024  # Default

    def load(self):
        """Load V-JEPA2 model from HuggingFace."""
        if self._model is not None:
            return

        logger.info(f"Loading V-JEPA2: {self.config.video_model_id}")

        dtype_map = {"bfloat16": torch.bfloat16, "float16": torch.float16, "float32": torch.float32}
        torch_dtype = dtype_map.get(self.config.torch_dtype, torch.bfloat16)

        try:
            from transformers import AutoModel, AutoProcessor

            self._model = AutoModel.from_pretrained(
                self.config.video_model_id,
                torch_dtype=torch_dtype,
                device_map=self.config.device_map,
                trust_remote_code=True,
            )
            self._processor = AutoProcessor.from_pretrained(
                self.config.video_model_id,
                trust_remote_code=True,
            )

            # Detect hidden size
            if hasattr(self._model, "config"):
                self._hidden_size = getattr(self._model.config, "hidden_size", self.hidden_size)

            # Freeze
            if self.config.video_freeze:
                for p in self._model.parameters():
                    p.requires_grad = False
                logger.info("V-JEPA2 frozen")

            logger.info(f"V-JEPA2 loaded: hidden_size={self._hidden_size}")

        except Exception as e:
            logger.error(f"Failed to load V-JEPA2: {e}")
            logger.info("Falling back to random projection (for testing)")
            self._hidden_size = self.hidden_size
            self._model = nn.Linear(3 * self.config.video_image_size * self.config.video_image_size, self._hidden_size)

    def encode(self, video_frames: List[Any]) -> torch.Tensor:
        """Encode video frames into temporal feature sequence.

        Args:
            video_frames: List of PIL images (video frames)

        Returns:
            (batch, num_frames, hidden_size) temporal video features
        """
        if self._model is None:
            self.load()

        frames = video_frames[:self.config.video_max_frames]

        try:
            if self._processor is not None:
                inputs = self._processor(
                    videos=frames,
                    return_tensors="pt",
                )
                device = next(self._model.parameters()).device
                inputs = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in inputs.items()}

                with torch.no_grad():
                    outputs = self._model(**inputs, output_hidden_states=True)

                # Get features — either last hidden state or selected layers
                if self.config.video_layers and hasattr(outputs, "hidden_states"):
                    # TRIBE-style: concatenate selected layers
                    selected = [outputs.hidden_states[i] for i in self.config.video_layers
                                if i < len(outputs.hidden_states)]
                    if self.config.layer_aggregation == "cat":
                        features = torch.cat(selected, dim=-1)
                    else:
                        features = torch.stack(selected).mean(dim=0)
                else:
                    features = outputs.last_hidden_state

                return features  # (batch, seq_len, hidden_size)
            else:
                # Fallback: simple forward
                device = next(self._model.parameters()).device
                # Dummy tensor for testing
                x = torch.randn(1, len(frames), self._hidden_size, device=device)
                return x

        except Exception as e:
            logger.warning(f"V-JEPA2 encode failed: {e}, returning zeros")
            return torch.zeros(1, len(frames), self.hidden_size)


class Wav2VecAudioEncoder(nn.Module):
    """Wav2Vec-BERT 2.0 audio encoder — native audio understanding.

    Unlike Whisper (ASR-focused, outputs text), Wav2Vec-BERT learns
    rich audio representations from raw waveforms. It captures:
    - Speech content AND prosody (tone, urgency, emphasis)
    - Non-speech sounds (motor noise, object collisions, alarms)
    - Temporal audio patterns (footsteps approaching, door opening)

    For robotics:
    - Understand spoken commands with nuance (urgent vs casual)
    - Environmental audio awareness (safety-critical sounds)
    - Audio-visual correspondence (see + hear object drop)
    """

    def __init__(self, config: TribeBackboneConfig):
        super().__init__()
        self.config = config
        self._model = None
        self._processor = None
        self._hidden_size = 0

    @property
    def hidden_size(self) -> int:
        if self._hidden_size > 0:
            return self._hidden_size
        # Wav2Vec-BERT 2.0 default
        return 1024

    def load(self):
        """Load Wav2Vec-BERT model."""
        if self._model is not None:
            return

        logger.info(f"Loading Wav2Vec-BERT: {self.config.audio_model_id}")

        dtype_map = {"bfloat16": torch.bfloat16, "float16": torch.float16, "float32": torch.float32}
        torch_dtype = dtype_map.get(self.config.torch_dtype, torch.bfloat16)

        try:
            from transformers import AutoFeatureExtractor, AutoModel

            self._model = AutoModel.from_pretrained(
                self.config.audio_model_id,
                torch_dtype=torch_dtype,
                device_map=self.config.device_map,
                trust_remote_code=True,
            )
            self._processor = AutoFeatureExtractor.from_pretrained(
                self.config.audio_model_id,
                trust_remote_code=True,
            )

            if hasattr(self._model, "config"):
                self._hidden_size = getattr(self._model.config, "hidden_size", self.hidden_size)

            if self.config.audio_freeze:
                for p in self._model.parameters():
                    p.requires_grad = False
                logger.info("Wav2Vec-BERT frozen")

            logger.info(f"Wav2Vec-BERT loaded: hidden_size={self._hidden_size}")

        except Exception as e:
            logger.error(f"Failed to load Wav2Vec-BERT: {e}")
            self._hidden_size = self.hidden_size

    def encode(self, audio: torch.Tensor) -> torch.Tensor:
        """Encode raw audio waveform.

        Args:
            audio: (batch, samples) raw waveform at 16kHz

        Returns:
            (batch, time_steps, hidden_size) audio features
        """
        if self._model is None:
            self.load()

        if self._model is None:
            return torch.zeros(audio.shape[0], 1, self.hidden_size, device=audio.device)

        try:
            device = next(self._model.parameters()).device

            # Truncate to max seconds
            max_samples = int(self.config.audio_sample_rate * self.config.audio_max_seconds)
            audio = audio[:, :max_samples]

            # Process with feature extractor
            if self._processor is not None:
                audio_np = audio.cpu().numpy()
                inputs = self._processor(
                    audio_np,
                    sampling_rate=self.config.audio_sample_rate,
                    return_tensors="pt",
                    padding=True,
                )
                inputs = {k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in inputs.items()}
            else:
                inputs = {"input_values": audio.to(device)}

            with torch.no_grad():
                outputs = self._model(**inputs, output_hidden_states=True)

            return outputs.last_hidden_state  # (batch, time, hidden)

        except Exception as e:
            logger.warning(f"Wav2Vec-BERT encode failed: {e}")
            return torch.zeros(audio.shape[0], 1, self.hidden_size, device=audio.device)


class LLaMATextEncoder(nn.Module):
    """LLaMA 3.2 text encoder — instruction understanding.

    Uses LLaMA's hidden states (not generation output) as rich
    text features. The key advantage over CLIP text encoders:
    - Much larger context window (instructions can be detailed)
    - Better instruction following (trained for it)
    - Captures nuance, multi-step reasoning, spatial language

    For robotics:
    - "Pick up the RED cup, not the blue one" → spatial reasoning
    - "Gently place it on the shelf" → force modulation from text
    - "First open the drawer, then put it inside" → sequential planning
    """

    def __init__(self, config: TribeBackboneConfig):
        super().__init__()
        self.config = config
        self._model = None
        self._tokenizer = None
        self._hidden_size = 0

    @property
    def hidden_size(self) -> int:
        if self._hidden_size > 0:
            return self._hidden_size
        model_id = self.config.text_model_id.lower()
        if "3b" in model_id:
            return 3072
        elif "1b" in model_id:
            return 2048
        elif "8b" in model_id:
            return 4096
        return 3072

    def load(self):
        """Load LLaMA model (encoder-only mode)."""
        if self._model is not None:
            return

        logger.info(f"Loading LLaMA text encoder: {self.config.text_model_id}")

        dtype_map = {"bfloat16": torch.bfloat16, "float16": torch.float16, "float32": torch.float32}
        torch_dtype = dtype_map.get(self.config.torch_dtype, torch.bfloat16)

        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer

            load_kwargs = {
                "torch_dtype": torch_dtype,
                "device_map": self.config.device_map,
                "trust_remote_code": True,
            }

            if self.config.load_in_4bit:
                from transformers import BitsAndBytesConfig
                load_kwargs["quantization_config"] = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_quant_type="nf4",
                    bnb_4bit_compute_dtype=torch_dtype,
                )

            self._model = AutoModelForCausalLM.from_pretrained(
                self.config.text_model_id, **load_kwargs
            )
            self._tokenizer = AutoTokenizer.from_pretrained(
                self.config.text_model_id, trust_remote_code=True
            )

            if hasattr(self._model, "config"):
                self._hidden_size = getattr(self._model.config, "hidden_size", self.hidden_size)

            if self.config.text_freeze:
                for p in self._model.parameters():
                    p.requires_grad = False
                logger.info("LLaMA frozen")

            logger.info(f"LLaMA loaded: hidden_size={self._hidden_size}")

        except Exception as e:
            logger.error(f"Failed to load LLaMA: {e}")
            self._hidden_size = self.hidden_size

    def encode(self, text: str) -> torch.Tensor:
        """Encode text instruction into features.

        Args:
            text: Language instruction string

        Returns:
            (1, seq_len, hidden_size) text features
        """
        if self._model is None:
            self.load()

        if self._model is None or self._tokenizer is None:
            return torch.zeros(1, 1, self.hidden_size)

        try:
            device = next(self._model.parameters()).device

            inputs = self._tokenizer(
                text,
                return_tensors="pt",
                max_length=self.config.text_max_length,
                truncation=True,
                padding=True,
            ).to(device)

            with torch.no_grad():
                outputs = self._model(**inputs, output_hidden_states=True)

            # Use last hidden state (not logits)
            return outputs.hidden_states[-1]  # (1, seq_len, hidden)

        except Exception as e:
            logger.warning(f"LLaMA encode failed: {e}")
            return torch.zeros(1, 1, self.hidden_size)


# =============================================================================
# Fusion Transformer — TRIBE-style cross-modal integration
# =============================================================================


class ModalityProjector(nn.Module):
    """Projects per-modality features to shared fusion dimension.

    From TRIBE: each modality gets its own MLP projector that maps
    from encoder-specific dimensions to the shared fusion hidden size.
    """

    def __init__(self, input_dim: int, output_dim: int, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, output_dim),
            nn.LayerNorm(output_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class FusionTransformer(nn.Module):
    """Transformer encoder that fuses projected modality tokens.

    From TRIBE: after per-modality projection, all tokens are
    concatenated into one sequence and processed by a shared
    Transformer. This allows cross-modal attention:
    - Video tokens attend to audio tokens (audio-visual grounding)
    - Text tokens attend to video tokens (instruction grounding)
    - All modalities influence each other
    """

    def __init__(self, config: TribeBackboneConfig):
        super().__init__()
        self.config = config

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=config.hidden_size,
            nhead=config.num_fusion_heads,
            dim_feedforward=config.hidden_size * 4,
            dropout=config.fusion_dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,  # Pre-norm (more stable training)
        )
        self.encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=config.num_fusion_layers,
        )

        # Temporal position embedding (TRIBE)
        if config.time_pos_embedding:
            self.time_pos_embed = nn.Parameter(
                torch.randn(1, config.max_seq_len, config.hidden_size) * 0.02
            )

        # Modality type embedding (video=0, audio=1, text=2)
        self.modality_embed = nn.Embedding(3, config.hidden_size)

        # Output projection + pool
        self.output_norm = nn.LayerNorm(config.hidden_size)

    def forward(
        self,
        tokens: torch.Tensor,
        modality_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """Fuse multimodal tokens via cross-attention.

        Args:
            tokens: (batch, total_seq_len, hidden_size) concatenated projected tokens
            modality_ids: (batch, total_seq_len) integer modality type (0=video, 1=audio, 2=text)
            attention_mask: Optional padding mask

        Returns:
            Dict with "hidden_states" and "pooled" features
        """
        # Add modality type embeddings
        tokens = tokens + self.modality_embed(modality_ids)

        # Add temporal position embeddings
        if hasattr(self, "time_pos_embed"):
            seq_len = tokens.shape[1]
            tokens = tokens + self.time_pos_embed[:, :seq_len, :]

        # Transformer fusion
        if attention_mask is not None:
            # Convert bool mask to float: True = attend, False = ignore
            src_key_padding_mask = ~attention_mask  # TransformerEncoder expects True=ignore
        else:
            src_key_padding_mask = None

        hidden = self.encoder(tokens, src_key_padding_mask=src_key_padding_mask)
        hidden = self.output_norm(hidden)

        # Pool: mean over all tokens
        if attention_mask is not None:
            mask_expanded = attention_mask.unsqueeze(-1).float()
            pooled = (hidden * mask_expanded).sum(dim=1) / mask_expanded.sum(dim=1).clamp(min=1)
        else:
            pooled = hidden.mean(dim=1)

        return {
            "hidden_states": hidden,
            "pooled": pooled,
        }


# =============================================================================
# TRIBEv2 Native Multimodal Backbone — drop-in replacement for VideoBackbone
# =============================================================================


class TribeMultimodalBackbone(nn.Module):
    """TRIBEv2-style native multimodal backbone for NeonVLA.

    Drop-in replacement for VideoBackbone. Instead of one omni model,
    uses three specialized encoders + Transformer fusion.

    Pipeline:
        video_frames → V-JEPA2 → video projector ─┐
        audio        → Wav2Vec  → audio projector ─┤→ concat → FusionTransformer → pooled features
        text         → LLaMA    → text projector  ─┘

    Compatible with NeonVLA's .encode() and .forward() interface.

    Args:
        config: TribeBackboneConfig with per-encoder settings
    """

    def __init__(self, config: TribeBackboneConfig):
        super().__init__()
        self.config = config

        # Per-modality encoders (lazy-loaded)
        self.video_encoder = VJEPAVideoEncoder(config) if config.video_enabled else None
        self.audio_encoder = Wav2VecAudioEncoder(config) if config.audio_enabled else None
        self.text_encoder = LLaMATextEncoder(config) if config.text_enabled else None

        # Per-modality projectors → shared hidden_size
        self.projectors = nn.ModuleDict()
        if config.video_enabled:
            video_dim = VJEPAVideoEncoder(config).hidden_size
            if config.video_layers and config.layer_aggregation == "cat":
                video_dim *= len(config.video_layers)
            self.projectors["video"] = ModalityProjector(video_dim, config.hidden_size, config.fusion_dropout)

        if config.audio_enabled:
            audio_dim = Wav2VecAudioEncoder(config).hidden_size
            self.projectors["audio"] = ModalityProjector(audio_dim, config.hidden_size, config.fusion_dropout)

        if config.text_enabled:
            text_dim = LLaMATextEncoder(config).hidden_size
            self.projectors["text"] = ModalityProjector(text_dim, config.hidden_size, config.fusion_dropout)

        # Fusion Transformer
        self.fusion = FusionTransformer(config)

        # Modality dropout (TRIBE: randomly zero entire modalities during training)
        self.modality_dropout_p = config.modality_dropout

        # Hidden size for NeonVLA compatibility
        self._hidden_size = config.hidden_size
        self._is_cosmos = False  # Not a Cosmos model

        # Track what's loaded
        self._loaded = False

        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        logger.info(
            f"TribeMultimodalBackbone: {total_params:,} total, {trainable_params:,} trainable "
            f"(video={config.video_enabled}, audio={config.audio_enabled}, text={config.text_enabled})"
        )

    @property
    def hidden_size(self) -> int:
        return self._hidden_size

    def load(self):
        """Load all encoder models. Call before forward()."""
        if self._loaded:
            return

        logger.info("Loading TRIBEv2 multimodal encoders...")

        if self.video_encoder is not None:
            self.video_encoder.load()
        if self.audio_encoder is not None:
            self.audio_encoder.load()
        if self.text_encoder is not None:
            self.text_encoder.load()

        self._loaded = True
        logger.info("All TRIBEv2 encoders loaded")

    def encode(
        self,
        images: Optional[List[Any]] = None,
        video_frames: Optional[List[Any]] = None,
        text: Optional[str] = None,
        audio: Optional[torch.Tensor] = None,
        return_dict: bool = True,
    ) -> Dict[str, torch.Tensor]:
        """Encode multimodal inputs and fuse via Transformer.

        Compatible with VideoBackbone.encode() interface (images, video_frames, text).
        Extended with native audio input.

        Args:
            images: List of PIL images (treated as single-frame video)
            video_frames: List of PIL images as video sequence
            text: Language instruction
            audio: (batch, samples) raw audio waveform at 16kHz
            return_dict: If True, return dict with hidden_states + pooled

        Returns:
            Dict with:
                - "hidden_states": (batch, total_seq, hidden_size)
                - "pooled": (batch, hidden_size)
        """
        if not self._loaded:
            self.load()

        all_tokens = []
        all_modality_ids = []
        batch_size = 1

        # ── Video encoding ──
        if self.video_encoder is not None and (video_frames is not None or images is not None):
            frames = video_frames or images
            video_features = self.video_encoder.encode(frames)  # (B, T_v, H_v)
            batch_size = video_features.shape[0]

            # Apply modality dropout
            if self.training and self.modality_dropout_p > 0:
                if torch.rand(1).item() < self.modality_dropout_p:
                    video_features = torch.zeros_like(video_features)

            # Project to fusion dim
            video_tokens = self.projectors["video"](video_features)  # (B, T_v, hidden)
            all_tokens.append(video_tokens)
            all_modality_ids.append(
                torch.zeros(batch_size, video_tokens.shape[1], dtype=torch.long, device=video_tokens.device)
            )

        # ── Audio encoding ──
        if self.audio_encoder is not None and audio is not None:
            audio_features = self.audio_encoder.encode(audio)  # (B, T_a, H_a)
            batch_size = audio_features.shape[0]

            if self.training and self.modality_dropout_p > 0:
                if torch.rand(1).item() < self.modality_dropout_p:
                    audio_features = torch.zeros_like(audio_features)

            audio_tokens = self.projectors["audio"](audio_features)
            all_tokens.append(audio_tokens)
            all_modality_ids.append(
                torch.ones(batch_size, audio_tokens.shape[1], dtype=torch.long, device=audio_tokens.device)
            )

        # ── Text encoding ──
        if self.text_encoder is not None and text is not None:
            text_features = self.text_encoder.encode(text)  # (1, T_t, H_t)
            if text_features.shape[0] == 1 and batch_size > 1:
                text_features = text_features.expand(batch_size, -1, -1)

            if self.training and self.modality_dropout_p > 0:
                if torch.rand(1).item() < self.modality_dropout_p:
                    text_features = torch.zeros_like(text_features)

            text_tokens = self.projectors["text"](text_features)
            all_tokens.append(text_tokens)
            all_modality_ids.append(
                torch.full((batch_size, text_tokens.shape[1]), 2, dtype=torch.long, device=text_tokens.device)
            )

        # ── Handle no input ──
        if not all_tokens:
            device = next(self.parameters()).device
            dummy = torch.zeros(1, 1, self._hidden_size, device=device)
            return {"hidden_states": dummy, "pooled": dummy.squeeze(1)}

        # ── Concatenate all modality tokens ──
        tokens = torch.cat(all_tokens, dim=1)  # (B, T_total, hidden)
        modality_ids = torch.cat(all_modality_ids, dim=1)  # (B, T_total)

        # Truncate to max_seq_len
        if tokens.shape[1] > self.config.max_seq_len:
            tokens = tokens[:, :self.config.max_seq_len, :]
            modality_ids = modality_ids[:, :self.config.max_seq_len]

        # ── Fusion Transformer ──
        result = self.fusion(tokens, modality_ids)

        return result

    def forward(
        self,
        images: Optional[List] = None,
        video_frames: Optional[List] = None,
        text: Optional[str] = None,
        audio: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Forward pass — returns pooled features.

        Compatible with VideoBackbone.forward().
        """
        result = self.encode(images=images, video_frames=video_frames, text=text, audio=audio)
        return result["pooled"]
