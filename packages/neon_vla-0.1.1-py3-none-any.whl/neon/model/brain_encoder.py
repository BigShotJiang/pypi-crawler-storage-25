"""
Brain-Inspired Multimodal Fusion — ported from Meta's TRIBEv2.

TRIBEv2 (facebook/tribev2) maps multimodal inputs → cortical surface
predictions using a unified Transformer. Their key insights:

1. **Temporal Smoothing** — Gaussian 1D conv across time dimension
   stabilizes predictions across timesteps (no jitter between frames).
   For robotics: smoother action trajectories, less oscillation.

2. **Modality Dropout** — Randomly zero-out entire modalities during
   training (video, audio, proprioception). Forces the model to learn
   redundant representations. For robotics: graceful degradation when
   a sensor fails (camera occlusion, audio noise, LiDAR dropout).

3. **Subject Layers** — Per-subject (per-robot) affine transforms on
   features. For robotics: per-embodiment adaptation without retraining
   the whole model. A single Neon model can adapt to different G1 units
   with slightly different joint calibrations.

4. **Temporal Position Embedding** — Learnable position embeddings for
   the time axis, separate from spatial position. For robotics: the
   model explicitly reasons about action sequencing, not just current
   frame.

5. **Layer Aggregation** — TRIBE concatenates features from multiple
   backbone layers (early = low-level, late = semantic). For robotics:
   early visual features capture object edges/grasps, late features
   capture task semantics.

Reference:
    d'Ascoli et al. "A foundation model of vision, audition, and language
    for in-silico neuroscience." Meta AI, 2026.
    https://huggingface.co/facebook/tribev2

License: CC-BY-NC-4.0 (TRIBEv2 ideas), Apache-2.0 (this implementation)
"""

from __future__ import annotations

import logging
import math
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)


# =============================================================================
# Temporal Smoothing — from TRIBEv2 model.py:TemporalSmoothing
# =============================================================================


class TemporalSmoothing(nn.Module):
    """Gaussian 1D temporal smoothing across action/feature sequences.

    From TRIBEv2: depthwise Conv1d with Gaussian kernel initialization.
    Smooths predictions across time to reduce jitter.

    For robotics:
    - Applied AFTER the action head, before output
    - Kernel size 9 ≈ ~0.5s at 16-step chunks @ 4Hz
    - Learnable: starts Gaussian, model can sharpen/broaden
    - Depthwise: each action dim smoothed independently

    Args:
        dim: Number of channels (action dimensions)
        kernel_size: Temporal kernel width (odd number)
        sigma: Gaussian sigma (None = learnable from scratch)
        learnable: If True, kernel weights are trainable parameters
    """

    def __init__(
        self,
        dim: int,
        kernel_size: int = 9,
        sigma: Optional[float] = None,
        learnable: bool = True,
    ):
        super().__init__()
        self.dim = dim
        self.kernel_size = kernel_size

        # Depthwise conv: each channel has its own 1D filter
        self.conv = nn.Conv1d(
            dim,
            dim,
            kernel_size=kernel_size,
            padding=kernel_size // 2,
            bias=False,
            groups=dim,
        )

        # Initialize with Gaussian kernel if sigma provided
        if sigma is not None:
            kernel = self._gaussian_kernel_1d(kernel_size, sigma)
            kernel = kernel.repeat(dim, 1, 1)  # (dim, 1, kernel_size)
            self.conv.weight.data = kernel

        # Freeze if not learnable
        if not learnable:
            self.conv.weight.requires_grad = False

    @staticmethod
    def _gaussian_kernel_1d(kernel_size: int, sigma: float) -> torch.Tensor:
        """Create a 1D Gaussian kernel."""
        x = torch.arange(kernel_size) - kernel_size // 2
        kernel = torch.exp(-0.5 * (x / sigma) ** 2)
        kernel = kernel / kernel.sum()
        return kernel.view(1, 1, -1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Smooth a temporal sequence.

        Args:
            x: (batch, time, dim) feature/action sequence

        Returns:
            (batch, time, dim) smoothed sequence
        """
        # Conv1d expects (batch, channels, time)
        x = x.transpose(1, 2)  # (batch, dim, time)
        x = self.conv(x)
        x = x.transpose(1, 2)  # (batch, time, dim)
        return x


# =============================================================================
# Modality Dropout — from TRIBEv2 model.py:FmriEncoderModel (modality_dropout)
# =============================================================================


class ModalityDropout(nn.Module):
    """Randomly zero-out entire modality features during training.

    From TRIBEv2: during training, each modality has `p` probability
    of being completely zeroed. This forces the model to not rely on
    any single modality and learn redundant cross-modal representations.

    For robotics, this is critical for robustness:
    - Camera occluded by arm → model uses proprioception + audio
    - Noisy audio environment → model uses vision + LiDAR
    - LiDAR reflections → model uses vision + proprioception
    - EEF sensor drift → model uses joint states directly

    Unlike standard dropout (per-element), this drops entire feature
    vectors for a modality. Similar to DropBlock but along the modality axis.

    Args:
        p: Probability of dropping each modality (0.0 = no dropout)
        modalities: List of modality names for logging
    """

    def __init__(self, p: float = 0.1, modalities: Optional[List[str]] = None):
        super().__init__()
        self.p = p
        self.modalities = modalities or []

    def forward(
        self, features: Dict[str, torch.Tensor]
    ) -> Dict[str, torch.Tensor]:
        """Apply modality dropout.

        Args:
            features: Dict mapping modality name → (batch, dim) features

        Returns:
            Same dict with some modalities potentially zeroed out
        """
        if not self.training or self.p <= 0.0:
            return features

        result = {}
        for name, feat in features.items():
            if torch.rand(1).item() < self.p:
                result[name] = torch.zeros_like(feat)
                # Note: don't log every call — too noisy during training
            else:
                result[name] = feat
        return result


# =============================================================================
# Temporal Dropout — from TRIBEv2 model.py:FmriEncoderModel (temporal_dropout)
# =============================================================================


class TemporalDropout(nn.Module):
    """Randomly zero-out entire timesteps in a sequence.

    From TRIBEv2: complements modality dropout by dropping along the
    time axis instead of the feature axis. Forces the model to
    interpolate missing timesteps from context.

    For robotics:
    - Simulates dropped frames (camera lag, network delay)
    - Teaches action chunking head to handle gaps
    - Improves robustness at variable inference frequencies

    Args:
        p: Probability of dropping each timestep
    """

    def __init__(self, p: float = 0.1):
        super().__init__()
        self.p = p

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Apply temporal dropout.

        Args:
            x: (batch, time, dim) sequence features

        Returns:
            (batch, time, dim) with some timesteps zeroed
        """
        if not self.training or self.p <= 0.0:
            return x

        batch, time, dim = x.shape
        # Create per-timestep mask (same across batch for consistency)
        mask = torch.bernoulli(
            torch.full((1, time, 1), 1.0 - self.p, device=x.device)
        )
        return x * mask


# =============================================================================
# Embodiment Layers — inspired by TRIBEv2 SubjectLayers
# =============================================================================


class EmbodimentLayers(nn.Module):
    """Per-embodiment affine transform on features.

    From TRIBEv2's SubjectLayers: each "subject" (brain) gets its own
    affine transform to account for individual differences. In robotics,
    each embodiment (or individual robot unit) gets similar treatment.

    This enables:
    1. One base model shared across embodiments (G1, GR1, Franka, SO-100)
    2. Per-embodiment scale+shift learned with minimal parameters
    3. Quick adaptation to new embodiments with few-shot fine-tuning
    4. Individual robot calibration (joint offsets, sensor biases)

    Args:
        in_channels: Input feature dimension
        out_channels: Output dimension (typically same as in_channels)
        num_embodiments: Number of known embodiments
        names: Optional list of embodiment names for lookup
    """

    KNOWN_EMBODIMENTS = [
        "g1",          # Unitree G1 29-DOF
        "g1_43",       # Unitree G1 43-DOF (with hands)
        "gr1",         # Fourier GR1
        "franka",      # Franka Panda
        "so100",       # SO-100 arm
        "agibot_go1",  # AgiBotWorld GO-1
        "ur5",         # Universal Robots UR5
        "unknown",     # Fallback
    ]

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        num_embodiments: int = 8,
        names: Optional[List[str]] = None,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_embodiments = num_embodiments
        self.names = names or self.KNOWN_EMBODIMENTS[:num_embodiments]

        # Per-embodiment affine: scale (gamma) and shift (beta)
        # Initialized to identity transform: gamma=1, beta=0
        self.gamma = nn.Parameter(torch.ones(num_embodiments, 1, out_channels))
        self.beta = nn.Parameter(torch.zeros(num_embodiments, 1, out_channels))

        # Optional projection if in/out dimensions differ
        if in_channels != out_channels:
            self.proj = nn.Linear(in_channels, out_channels, bias=False)
        else:
            self.proj = None

        # Name → index mapping
        self._name_to_idx = {name: i for i, name in enumerate(self.names)}

    def get_index(self, embodiment_name: str) -> int:
        """Get the index for a named embodiment, defaulting to 'unknown'."""
        return self._name_to_idx.get(
            embodiment_name.lower(),
            self._name_to_idx.get("unknown", self.num_embodiments - 1),
        )

    def forward(
        self,
        x: torch.Tensor,
        embodiment_id: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Apply per-embodiment affine transform.

        Args:
            x: (batch, time, channels) or (batch, channels) features
            embodiment_id: (batch,) integer indices, or None for default (0)

        Returns:
            Transformed features with same shape as input
        """
        if self.proj is not None:
            x = self.proj(x)

        if embodiment_id is None:
            # Use first embodiment (default = G1)
            return x * self.gamma[0] + self.beta[0]

        # Gather per-sample scale and shift
        gamma = self.gamma[embodiment_id]  # (batch, 1, out_channels)
        beta = self.beta[embodiment_id]    # (batch, 1, out_channels)

        if x.dim() == 2:
            # (batch, channels) → squeeze time dim from gamma/beta
            gamma = gamma.squeeze(1)
            beta = beta.squeeze(1)

        return x * gamma + beta


# =============================================================================
# Multi-Layer Feature Aggregation — from TRIBEv2
# =============================================================================


class LayerAggregator(nn.Module):
    """Aggregate features from multiple backbone layers.

    TRIBEv2 insight: different backbone layers capture different
    information levels:
    - Early layers: edges, textures, spatial structure → grasp affordances
    - Middle layers: object parts, shapes → object recognition
    - Late layers: semantic, task-level → instruction understanding

    By concatenating features from selected layers (like TRIBE does),
    we give the action head access to ALL levels of representation.

    This is an alternative to just using the final hidden state.

    Args:
        layer_dims: List of (layer_index, feature_dim) pairs
        output_dim: Target output dimension after aggregation
        aggregation: "cat" (concatenate) or "mean" (average)
    """

    def __init__(
        self,
        layer_dims: List[Tuple[int, int]],
        output_dim: int,
        aggregation: str = "cat",
    ):
        super().__init__()
        self.aggregation = aggregation

        if aggregation == "cat":
            total_dim = sum(dim for _, dim in layer_dims)
        else:  # mean
            total_dim = layer_dims[0][1] if layer_dims else output_dim

        self.projection = nn.Linear(total_dim, output_dim)
        self.norm = nn.LayerNorm(output_dim)

    def forward(self, layer_features: List[torch.Tensor]) -> torch.Tensor:
        """Aggregate features from multiple layers.

        Args:
            layer_features: List of (batch, dim_i) tensors from selected layers

        Returns:
            (batch, output_dim) aggregated features
        """
        if self.aggregation == "cat":
            x = torch.cat(layer_features, dim=-1)
        else:
            # Mean across layers (requires same dim)
            x = torch.stack(layer_features, dim=0).mean(dim=0)

        x = self.projection(x)
        x = self.norm(x)
        return x


# =============================================================================
# BrainFusion — putting it all together
# =============================================================================


class BrainFusion(nn.Module):
    """Brain-inspired multimodal fusion module for NeonVLA.

    Combines TRIBEv2 techniques into a single fusion module that sits
    between the encoders and the action head:

    Pipeline:
        encoders → modality_dropout → concat → embodiment_layers
                 → temporal_dropout → temporal_smoothing → action_head

    This replaces the simple `nn.Sequential(Linear, GELU, Dropout)` fusion
    in the current NeonVLA with a neuroscience-inspired architecture.

    Args:
        modality_dims: Dict mapping modality name → feature dimension
        output_dim: Output feature dimension (backbone hidden size)
        modality_dropout: Probability of dropping each modality
        temporal_dropout: Probability of dropping each timestep
        temporal_smoothing: Whether to apply Gaussian temporal smoothing
        smoothing_kernel: Kernel size for temporal smoothing
        smoothing_sigma: Gaussian sigma (None = learnable)
        num_embodiments: Number of embodiments for EmbodimentLayers
    """

    def __init__(
        self,
        modality_dims: Dict[str, int],
        output_dim: int,
        modality_dropout: float = 0.1,
        temporal_dropout: float = 0.05,
        temporal_smoothing: bool = True,
        smoothing_kernel: int = 5,
        smoothing_sigma: Optional[float] = 1.5,
        num_embodiments: int = 8,
    ):
        super().__init__()

        total_input_dim = sum(modality_dims.values())
        modality_names = list(modality_dims.keys())

        # 1. Modality dropout (TRIBEv2)
        self.modality_dropout = ModalityDropout(
            p=modality_dropout, modalities=modality_names
        )

        # 2. Projection from concat to hidden
        self.projection = nn.Sequential(
            nn.Linear(total_input_dim, output_dim),
            nn.GELU(),
        )

        # 3. Embodiment-specific adaptation (TRIBEv2 SubjectLayers)
        self.embodiment_layers = EmbodimentLayers(
            in_channels=output_dim,
            out_channels=output_dim,
            num_embodiments=num_embodiments,
        )

        # 4. Temporal dropout (TRIBEv2)
        self.temporal_dropout = TemporalDropout(p=temporal_dropout)

        # 5. Temporal smoothing (TRIBEv2) — applied to output features
        self.temporal_smoothing = None
        if temporal_smoothing:
            self.temporal_smoothing = TemporalSmoothing(
                dim=output_dim,
                kernel_size=smoothing_kernel,
                sigma=smoothing_sigma,
                learnable=True,
            )

        # 6. Final dropout
        self.dropout = nn.Dropout(0.1)

        # Stats
        total_params = sum(p.numel() for p in self.parameters())
        logger.info(
            f"BrainFusion: {len(modality_names)} modalities, "
            f"{total_input_dim}→{output_dim}d, "
            f"mod_drop={modality_dropout}, temp_drop={temporal_dropout}, "
            f"smoothing={'yes' if temporal_smoothing else 'no'}, "
            f"{total_params:,} params"
        )

    def forward(
        self,
        modality_features: Dict[str, torch.Tensor],
        embodiment_id: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Fuse multimodal features with brain-inspired techniques.

        Args:
            modality_features: Dict of modality_name → (batch, dim) features
            embodiment_id: (batch,) embodiment indices for per-robot adaptation

        Returns:
            (batch, output_dim) fused features ready for action decoding
        """
        # 1. Modality dropout — randomly zero entire modalities
        features = self.modality_dropout(modality_features)

        # 2. Concatenate all modality features
        cat_features = torch.cat(list(features.values()), dim=-1)

        # 3. Project to hidden dimension
        hidden = self.projection(cat_features)

        # 4. Per-embodiment affine adaptation
        hidden = self.embodiment_layers(hidden, embodiment_id)

        # 5. Temporal operations (if we have a time dimension)
        if hidden.dim() == 3:  # (batch, time, dim)
            hidden = self.temporal_dropout(hidden)
            if self.temporal_smoothing is not None:
                hidden = self.temporal_smoothing(hidden)

        # 6. Final dropout
        hidden = self.dropout(hidden)

        return hidden
