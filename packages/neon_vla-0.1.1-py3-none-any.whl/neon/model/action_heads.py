"""
Action Heads — G1-specific action decoders.

Converts visual-language features from the video backbone into robot actions.
Supports multiple output heads for different control groups:
- Upper body (14 DoF arms)
- Grippers (2 DoF)
- Locomotion velocity (3 DoF: vx, vy, omega)
- Whole body (all 29 DoF, when enabled)

Architecture inspired by:
- GR00T N1's action tokenizer (VQ-BeT style)
- OmniVLA's multi-head action decoder
- RT-2's action token prediction

v2 enhancements from MicroGPT Parameter Golf winners:
- ReLU² activation (smoother gradients than GELU, cheaper)
- RMSNorm (lighter than LayerNorm, no mean subtraction)
- Learnable residual scales (prevents frozen backbone from dominating)
- U-Net skip connections (gradient highway through deeper MLPs)
- Logit soft-capping (smoother than hard Tanh clamp)

Key insight: Action heads are our "small model" (~2M params). Every
parameter-efficiency trick from the golf competition applies here.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from neon.data.action_space import ControlMode, G1ActionSpace

logger = logging.getLogger(__name__)


# =============================================================================
# Multi-Embodiment Support — adapted from GR00T N1.6
# (isaac-gr00t/gr00t/model/modules/embodiment_conditioned_mlp.py)
# =============================================================================


class CategorySpecificLinear(nn.Module):
    """Linear layer with per-embodiment weights — enables training one model for multiple robots.

    From GR00T N1.6: each embodiment (G1, Franka, DROID, etc.) gets its own
    weight matrix. At runtime, batch elements select their embodiment's weights
    via cat_ids. Zero overhead when num_categories=1.

    Args:
        num_categories: Number of embodiment types (e.g., 4 for G1+Franka+DROID+GR1)
        input_dim: Input feature dimension
        hidden_dim: Output feature dimension
    """

    def __init__(self, num_categories: int, input_dim: int, hidden_dim: int):
        super().__init__()
        self.num_categories = num_categories
        self.W = nn.Parameter(0.02 * torch.randn(num_categories, input_dim, hidden_dim))
        self.b = nn.Parameter(torch.zeros(num_categories, hidden_dim))

    def forward(self, x: torch.Tensor, cat_ids: torch.Tensor) -> torch.Tensor:
        """Forward pass with embodiment-specific weights.

        Args:
            x: (batch, ..., input_dim) input tensor (2D or 3D)
            cat_ids: (batch,) integer embodiment IDs

        Returns:
            (batch, ..., hidden_dim) output with embodiment-specific transform
        """
        selected_W = self.W[cat_ids]  # (B, input_dim, hidden_dim)
        selected_b = self.b[cat_ids]  # (B, hidden_dim)
        if x.ndim == 3:
            return torch.bmm(x, selected_W) + selected_b.unsqueeze(1)
        else:
            # (B, input_dim) @ (B, input_dim, hidden_dim) → (B, hidden_dim)
            return torch.bmm(x.unsqueeze(1), selected_W).squeeze(1) + selected_b


class CategorySpecificMLP(nn.Module):
    """Two-layer MLP with per-embodiment weights.

    From GR00T N1.6: enables a single model to handle multiple robot embodiments
    with separate learned projections per embodiment type.
    """

    def __init__(self, num_categories: int, input_dim: int, hidden_dim: int, output_dim: int):
        super().__init__()
        self.layer1 = CategorySpecificLinear(num_categories, input_dim, hidden_dim)
        self.layer2 = CategorySpecificLinear(num_categories, hidden_dim, output_dim)

    def forward(self, x: torch.Tensor, cat_ids: torch.Tensor) -> torch.Tensor:
        hidden = F.relu(self.layer1(x, cat_ids))
        return self.layer2(hidden, cat_ids)


class SinusoidalTimeEncoding(nn.Module):
    """Sinusoidal positional encoding for diffusion timesteps.

    Produces (B, T, embedding_dim) from timesteps (B, T).
    Used by MultiEmbodimentActionEncoder for flow-matching time conditioning.
    """

    def __init__(self, embedding_dim: int):
        super().__init__()
        self.embedding_dim = embedding_dim

    def forward(self, timesteps: torch.Tensor) -> torch.Tensor:
        timesteps = timesteps.float()
        half_dim = self.embedding_dim // 2
        exponent = -torch.arange(half_dim, dtype=torch.float, device=timesteps.device) * (
            torch.log(torch.tensor(10000.0)) / half_dim
        )
        if timesteps.ndim == 1:
            timesteps = timesteps.unsqueeze(-1)  # (B,) → (B, 1)
        freqs = timesteps.unsqueeze(-1) * exponent.exp()  # (..., half_dim)
        return torch.cat([torch.sin(freqs), torch.cos(freqs)], dim=-1)


class MultiEmbodimentActionEncoder(nn.Module):
    """Action encoder with per-embodiment projections + sinusoidal time encoding.

    From GR00T N1.6: each embodiment gets its own action→hidden projection.
    Combined with sinusoidal time encoding for flow-matching diffusion.

    Used inside cross-attention DiT: encodes noisy actions + timestep into
    a sequence of action tokens that attend to backbone features.
    """

    def __init__(self, action_dim: int, hidden_size: int, num_embodiments: int):
        super().__init__()
        self.hidden_size = hidden_size
        self.W1 = CategorySpecificLinear(num_embodiments, action_dim, hidden_size)
        self.W2 = CategorySpecificLinear(num_embodiments, 2 * hidden_size, hidden_size)
        self.W3 = CategorySpecificLinear(num_embodiments, hidden_size, hidden_size)
        self.pos_encoding = SinusoidalTimeEncoding(hidden_size)

    def forward(
        self,
        actions: torch.Tensor,
        timesteps: torch.Tensor,
        cat_ids: torch.Tensor,
    ) -> torch.Tensor:
        """Encode noisy actions with timestep and embodiment conditioning.

        Args:
            actions: (batch, T, action_dim)
            timesteps: (batch,) integer timestep per batch item
            cat_ids: (batch,) embodiment IDs

        Returns:
            (batch, T, hidden_size) encoded action features
        """
        B, T, _ = actions.shape
        # Replicate timestep across action horizon
        t_expanded = timesteps.unsqueeze(1).expand(-1, T)  # (B, T)
        a_emb = self.W1(actions, cat_ids)  # (B, T, hidden)
        tau_emb = self.pos_encoding(t_expanded).to(dtype=a_emb.dtype)  # (B, T, hidden)
        x = torch.cat([a_emb, tau_emb], dim=-1)  # (B, T, 2*hidden)

        def _swish(x):
            return x * torch.sigmoid(x)

        x = _swish(self.W2(x, cat_ids))  # (B, T, hidden)
        return self.W3(x, cat_ids)  # (B, T, hidden)


# =============================================================================
# Parameter Golf primitives — ported from MicroGPT v2 to PyTorch
# =============================================================================


class ReLUSquared(nn.Module):
    """ReLU² activation: max(0, x)².

    From Parameter Golf winners — smoother gradients than ReLU, cheaper than GELU.
    Gradient: 2 * max(0, x) — continuous at zero unlike ReLU.
    For action heads: produces smoother action trajectories.
    """

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.relu(x).square()


class RMSNorm(nn.Module):
    """Root Mean Square Layer Normalization.

    From MicroGPT engine: scale = (mean(x²) + ε)^(-0.5)
    Lighter than LayerNorm — no mean subtraction, no bias.
    Same stabilization benefit for small MLPs.
    """

    def __init__(self, dim: int, eps: float = 1e-5):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        ms = x.pow(2).mean(-1, keepdim=True)
        x_normed = x * torch.rsqrt(ms + self.eps)
        return x_normed * self.weight


def soft_cap(x: torch.Tensor, cap: float = 30.0) -> torch.Tensor:
    """Logit soft-capping: cap * tanh(x / cap).

    From Parameter Golf — smoother than hard Tanh clamp.
    Approaches [-cap, cap] asymptotically instead of hitting a wall.
    For action outputs capped to [-1, 1], use cap=1.0.
    """
    return cap * torch.tanh(x / cap)


@dataclass
class ActionHeadConfig:
    """Configuration for the action decoder heads."""

    hidden_size: int = 2048  # Input feature dim from backbone
    action_dim: int = 17  # Total action output dim (depends on ControlMode)
    num_action_steps: int = 16  # Predict this many future steps (action chunking)
    mlp_hidden: int = 512  # Hidden dim of MLP layers
    num_layers: int = 3  # Depth of the MLP decoder
    dropout: float = 0.1
    use_separate_heads: bool = True  # Separate MLP per group (arms, grip, loco)
    use_action_chunking: bool = True  # Predict multiple future steps
    # Parameter Golf v2 options
    use_relu_squared: bool = True  # ReLU² instead of GELU
    use_rmsnorm: bool = True  # RMSNorm before each MLP layer
    use_residual_scale: bool = True  # Learnable residual connection scales
    use_skip_connections: bool = True  # U-Net skip from layer 0 → last
    soft_cap_value: float = 1.0  # Soft-cap output (0 = use hard Tanh)


class MLPDecoder(nn.Module):
    """MLP action decoder with Parameter Golf v2 enhancements.

    Enhancements over vanilla MLP:
    - RMSNorm before each hidden layer (training stability)
    - ReLU² activation (smoother action outputs)
    - Learnable residual scales (prevents backbone feature domination)
    - U-Net skip connection from first hidden to last hidden
    - Soft-capping instead of hard Tanh for output range
    """

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dim: int = 512,
        num_layers: int = 3,
        dropout: float = 0.1,
        use_relu_squared: bool = True,
        use_rmsnorm: bool = True,
        use_residual_scale: bool = True,
        use_skip_connections: bool = True,
        soft_cap_value: float = 1.0,
    ):
        super().__init__()
        self.use_skip_connections = use_skip_connections and num_layers >= 3
        self.soft_cap_value = soft_cap_value

        activation = ReLUSquared if use_relu_squared else nn.GELU

        # Build layers individually for skip connection support
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.input_norm = RMSNorm(hidden_dim) if use_rmsnorm else nn.Identity()
        self.input_act = activation()
        self.input_drop = nn.Dropout(dropout)

        # Hidden layers
        self.hidden_layers = nn.ModuleList()
        self.hidden_norms = nn.ModuleList()
        self.hidden_acts = nn.ModuleList()
        self.hidden_drops = nn.ModuleList()
        for i in range(num_layers - 2):
            # Skip connection doubles input dim for the last hidden layer
            in_d = hidden_dim * 2 if (self.use_skip_connections and i == num_layers - 3) else hidden_dim
            self.hidden_layers.append(nn.Linear(in_d, hidden_dim))
            self.hidden_norms.append(RMSNorm(hidden_dim) if use_rmsnorm else nn.Identity())
            self.hidden_acts.append(activation())
            self.hidden_drops.append(nn.Dropout(dropout))

        # Output projection — no activation, we use soft-cap
        self.output_proj = nn.Linear(hidden_dim, output_dim)

        # Learnable residual scales (one per hidden layer + input)
        if use_residual_scale and num_layers >= 3:
            # α starts at 1.0 — network learns to scale residuals
            self.residual_scales = nn.ParameterList([
                nn.Parameter(torch.ones(1)) for _ in range(num_layers - 1)
            ])
        else:
            self.residual_scales = None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Input projection
        h = self.input_proj(x)
        h = self.input_norm(h)
        h = self.input_act(h)
        h = self.input_drop(h)
        skip = h  # Save for U-Net skip

        # Hidden layers
        for i, (linear, norm, act, drop) in enumerate(
            zip(self.hidden_layers, self.hidden_norms, self.hidden_acts, self.hidden_drops)
        ):
            h_in = h
            # U-Net skip: concat first hidden features into last hidden layer
            if self.use_skip_connections and i == len(self.hidden_layers) - 1:
                h = torch.cat([h, skip], dim=-1)

            h = linear(h)
            h = norm(h)
            h = act(h)
            h = drop(h)

            # Residual with learnable scale (only if dims match)
            if self.residual_scales is not None and h.shape == h_in.shape:
                scale = self.residual_scales[min(i, len(self.residual_scales) - 1)]
                h = h + scale * h_in

        # Output with soft-capping
        out = self.output_proj(h)
        if self.soft_cap_value > 0:
            out = soft_cap(out, self.soft_cap_value)
        else:
            out = torch.tanh(out)  # Legacy hard clamp
        return out


class ActionChunkingHead(nn.Module):
    """Action chunking decoder — predicts multiple future action steps.

    Instead of predicting a single action, predicts a sequence of future actions.
    This reduces compounding errors and improves policy smoothness.
    Reference: ACT (Action Chunking with Transformers), Zhao et al. 2023.

    v2: Uses Parameter Golf primitives (ReLU², RMSNorm, soft-capping).

    Output shape: (batch, num_steps, action_dim)
    """

    def __init__(
        self,
        input_dim: int,
        action_dim: int,
        num_steps: int = 16,
        hidden_dim: int = 512,
        num_layers: int = 3,
        dropout: float = 0.1,
        use_relu_squared: bool = True,
        use_rmsnorm: bool = True,
        soft_cap_value: float = 1.0,
    ):
        super().__init__()
        self.num_steps = num_steps
        self.action_dim = action_dim
        self.soft_cap_value = soft_cap_value

        activation = ReLUSquared if use_relu_squared else nn.GELU

        # Temporal embedding for each step
        self.step_embed = nn.Embedding(num_steps, hidden_dim)

        # Feature projection with RMSNorm
        self.feature_proj = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            RMSNorm(hidden_dim) if use_rmsnorm else nn.Identity(),
            activation(),
            nn.Dropout(dropout),
        )

        # Per-step decoder with v2 enhancements
        self.decoder = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),  # Features + step embedding
            RMSNorm(hidden_dim) if use_rmsnorm else nn.Identity(),
            activation(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            RMSNorm(hidden_dim) if use_rmsnorm else nn.Identity(),
            activation(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, action_dim),
            # No activation — soft-cap applied in forward()
        )

        # Learnable residual scale for decoder skip
        self.residual_scale = nn.Parameter(torch.ones(1))

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        """Predict a chunk of future actions.

        Args:
            features: (batch, hidden_size) pooled backbone features

        Returns:
            (batch, num_steps, action_dim) predicted action chunk
        """
        batch_size = features.shape[0]
        device = features.device

        # Project features
        feat = self.feature_proj(features)  # (batch, hidden_dim)

        # Generate step embeddings
        step_ids = torch.arange(self.num_steps, device=device)
        step_emb = self.step_embed(step_ids)  # (num_steps, hidden_dim)

        # Expand and concatenate
        feat_expanded = feat.unsqueeze(1).expand(-1, self.num_steps, -1)  # (batch, num_steps, hidden_dim)
        step_expanded = step_emb.unsqueeze(0).expand(batch_size, -1, -1)  # (batch, num_steps, hidden_dim)
        combined = torch.cat([feat_expanded, step_expanded], dim=-1)  # (batch, num_steps, hidden_dim*2)

        # Decode each step with soft-capping
        actions = self.decoder(combined)  # (batch, num_steps, action_dim)
        if self.soft_cap_value > 0:
            actions = soft_cap(actions, self.soft_cap_value)
        else:
            actions = torch.tanh(actions)

        return actions


class FlowMatchingHead(nn.Module):
    """Flow-matching action head for multi-modal action distributions.

    Derived from π₀ (Physical Intelligence) and rectified flow formulation.
    Unlike MSE (unimodal), flow matching captures multiple valid action modes.

    Training:
        t ~ Uniform(0, 1)
        noise ~ N(0, I)
        x_t = (1 - t) * noise + t * action          # linear interpolation
        v_target = action - noise                     # target velocity field
        v_pred = model(x_t, t, features)              # predict velocity
        loss = ||v_pred - v_target||²                 # flow matching loss

    Inference (Euler integration):
        x_0 ~ N(0, I)
        for step in range(num_denoise_steps):
            t = step / num_denoise_steps
            v = model(x_t, t, features)
            x_t = x_t + v * dt
        return soft_cap(x_1)                          # = denoised action

    Reference: Lipman et al. "Flow Matching for Generative Modeling" (2022)
    """

    def __init__(
        self,
        input_dim: int,
        action_dim: int,
        num_steps: int = 16,
        hidden_dim: int = 512,
        num_layers: int = 4,
        dropout: float = 0.1,
        num_denoise_steps: int = 4,
        soft_cap_value: float = 1.0,
        noise_beta_alpha: float = 0.0,
        noise_beta_beta: float = 0.0,
        use_cross_attention: bool = False,
        cross_attention_dim: Optional[int] = None,
    ):
        super().__init__()
        self.action_dim = action_dim
        self.num_steps = num_steps
        self.num_denoise_steps = num_denoise_steps
        self.soft_cap_value = soft_cap_value
        self.flat_action_dim = action_dim * num_steps
        self.use_cross_attention = use_cross_attention

        # Noise scheduling: Beta distribution (GR00T N1.6) vs Uniform
        # Beta(α, β) concentrates training around harder noise levels
        # When alpha=beta=0, falls back to uniform U(0,1)
        self._use_beta_noise = noise_beta_alpha > 0 and noise_beta_beta > 0
        if self._use_beta_noise:
            from torch.distributions import Beta
            self._beta_dist = Beta(noise_beta_alpha, noise_beta_beta)
            logger.info(f"FlowMatchingHead: Beta({noise_beta_alpha}, {noise_beta_beta}) noise scheduling")

        # Time embedding: scalar t → hidden_dim
        self.time_embed = nn.Sequential(
            nn.Linear(1, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )

        # Feature conditioning projection
        self.feature_proj = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            RMSNorm(hidden_dim),
            ReLUSquared(),
        )

        # Noisy action projection
        self.action_proj = nn.Sequential(
            nn.Linear(self.flat_action_dim, hidden_dim),
            RMSNorm(hidden_dim),
            ReLUSquared(),
        )

        # Cross-attention to backbone sequence features (MolmoBot-Pi0 style)
        # Instead of only using pooled features via adaLN, we attend to the
        # full sequence of VL tokens — this gives the velocity network direct
        # access to spatial information from the backbone.
        if use_cross_attention:
            ca_dim = cross_attention_dim or input_dim
            self.cross_attn_norm = RMSNorm(hidden_dim)
            self.cross_kv_proj = nn.Linear(ca_dim, hidden_dim) if ca_dim != hidden_dim else nn.Identity()
            self.cross_attn = nn.MultiheadAttention(
                hidden_dim, num_heads=4, dropout=dropout, batch_first=True,
            )
            self.cross_attn_gate = nn.Parameter(torch.zeros(1))  # Learnable gate, starts at 0
            logger.info(f"FlowMatchingHead: cross-attention enabled (dim={ca_dim})")

        # Velocity prediction network: (action + time + features) → velocity
        layers = []
        for i in range(num_layers):
            in_d = hidden_dim  # residual path dimension
            layers.append(nn.Sequential(
                RMSNorm(hidden_dim * 3),  # concat of action_h, time_h, feat_h
                nn.Linear(hidden_dim * 3, hidden_dim),
                ReLUSquared(),
                nn.Dropout(dropout),
            ))
        self.blocks = nn.ModuleList(layers)

        # Output projection: hidden → flat action velocity
        self.out_proj = nn.Linear(hidden_dim, self.flat_action_dim)

        # Learnable residual scales (Parameter Golf v2)
        self.residual_scales = nn.ParameterList([
            nn.Parameter(torch.ones(1)) for _ in range(num_layers)
        ])

        total_params = sum(p.numel() for p in self.parameters())
        logger.info(f"FlowMatchingHead: {total_params:,} params, {num_denoise_steps} denoise steps")

    def _predict_velocity(
        self,
        noisy_actions_flat: torch.Tensor,
        t: torch.Tensor,
        features: torch.Tensor,
        encoder_hidden_states: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Predict velocity field v(x_t, t, c).

        Args:
            noisy_actions_flat: (batch, action_dim * num_steps) flattened noisy actions
            t: (batch,) time in [0, 1]
            features: (batch, input_dim) conditioning features
            encoder_hidden_states: Optional (batch, seq_len, dim) backbone sequence features
                                   for cross-attention (MolmoBot-Pi0 style)

        Returns:
            (batch, action_dim * num_steps) predicted velocity
        """
        h_act = self.action_proj(noisy_actions_flat)       # (batch, hidden)
        h_time = self.time_embed(t.unsqueeze(-1))          # (batch, hidden)
        h_feat = self.feature_proj(features)               # (batch, hidden)

        h = h_act
        for i, block in enumerate(self.blocks):
            h_in = h
            h = block(torch.cat([h, h_time, h_feat], dim=-1))
            # Learnable residual
            h = h + self.residual_scales[i] * h_in

            # Cross-attention to backbone sequence after middle blocks (Pi0 style)
            # This lets action tokens attend to spatial VL features from the backbone
            if self.use_cross_attention and encoder_hidden_states is not None and i == len(self.blocks) // 2:
                h_normed = self.cross_attn_norm(h).unsqueeze(1)  # (B, 1, hidden)
                kv = self.cross_kv_proj(encoder_hidden_states)   # (B, S, hidden)
                ca_out, _ = self.cross_attn(h_normed, kv, kv, need_weights=False)
                h = h + self.cross_attn_gate * ca_out.squeeze(1)  # Gated residual

        return self.out_proj(h)  # (batch, flat_action_dim)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        """Generate actions via Euler integration (inference mode).

        Args:
            features: (batch, input_dim) conditioning features

        Returns:
            (batch, num_steps, action_dim) sampled actions
        """
        return self.sample(features, self.num_denoise_steps)

    def compute_loss(
        self,
        features: torch.Tensor,
        target_actions: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Flow matching training loss.

        Args:
            features: (batch, input_dim) conditioning features from backbone
            target_actions: (batch, num_steps, action_dim) ground truth actions
            mask: Optional (batch, num_steps) validity mask

        Returns:
            Scalar loss
        """
        B = features.shape[0]
        device = features.device

        # Flatten target actions
        target_flat = target_actions.reshape(B, -1)  # (batch, flat_action_dim)

        # Sample random time t ~ Beta(α, β) or U(0, 1)
        if self._use_beta_noise:
            t = self._beta_dist.sample((B,)).to(device)
        else:
            t = torch.rand(B, device=device)

        # Sample noise
        noise = torch.randn_like(target_flat)

        # Linear interpolation: x_t = (1 - t) * noise + t * target
        t_expand = t.unsqueeze(-1)  # (batch, 1)
        x_t = (1.0 - t_expand) * noise + t_expand * target_flat

        # Predict velocity
        v_pred = self._predict_velocity(x_t, t, features)

        # Target velocity: action - noise
        v_target = target_flat - noise

        # MSE on velocity field
        loss = F.mse_loss(v_pred, v_target, reduction="none")  # (batch, flat_action_dim)

        # Apply mask if provided
        if mask is not None:
            # Expand mask to cover all action dims per step
            mask_flat = mask.unsqueeze(-1).expand(-1, -1, self.action_dim).reshape(B, -1)
            loss = loss * mask_flat

        return loss.mean()

    @torch.no_grad()
    def sample(
        self,
        features: torch.Tensor,
        num_denoise_steps: int = None,
        guidance_fn: Optional[callable] = None,
        guidance_scale: float = 1.0,
        frozen_prefix: Optional[torch.Tensor] = None,
        frozen_steps: int = 0,
    ) -> torch.Tensor:
        """Sample actions via Euler integration with optional physics-aware guidance.

        Implements AirVLA's two key inference-time interventions:

        1. **Physics-Aware Guidance** (AirVLA §3.4): Inject a gradient correction
           into the velocity field to steer sampling toward physically feasible
           actions (e.g., altitude compensation for payload-induced sag in drones,
           or joint torque limits for humanoids). The guidance_fn computes a scalar
           loss Φ(A; o) over the denoised action chunk, and its gradient is added
           to the base velocity field:
               v_guided = v_base - guidance_scale * ∇_x Φ(denoise(x_t))

        2. **Real-Time Chunking (RTC)** (AirVLA §3.3): Freeze the prefix of the
           action chunk that will execute before inference completes, and inpaint
           the remaining suffix conditioned on the frozen prefix. This enables
           asynchronous inference at ~5-10 Hz while the robot runs at 50 Hz.

        Args:
            features: (batch, input_dim) conditioning features
            num_denoise_steps: Number of Euler steps (default: self.num_denoise_steps)
            guidance_fn: Optional callable(actions_chunk) → scalar loss for
                         physics-aware guidance. The gradient of this loss w.r.t.
                         actions steers sampling. Set to None to disable.
                         Example: PayloadAwareGuidance for aerial manipulation.
            guidance_scale: Strength of the guidance gradient (default: 1.0).
                           Higher = more aggressive steering.
            frozen_prefix: Optional (batch, frozen_steps, action_dim) tensor of
                          committed actions from the previous chunk (RTC).
                          These are held fixed during denoising.
            frozen_steps: Number of prefix steps to freeze (RTC). The remaining
                         (num_steps - frozen_steps) are inpainted.

        Returns:
            (batch, num_steps, action_dim) sampled and capped actions

        Reference:
            Tucker et al. "π, But Make It Fly: Physics-Guided Transfer of VLA
            Models to Aerial Manipulation" (2026), arXiv:2603.25038
        """
        if num_denoise_steps is None:
            num_denoise_steps = self.num_denoise_steps

        B = features.shape[0]
        device = features.device

        # Start from noise
        x = torch.randn(B, self.flat_action_dim, device=device)

        # RTC: overwrite frozen prefix in the initial noise
        if frozen_prefix is not None and frozen_steps > 0:
            prefix_flat = frozen_prefix[:, :frozen_steps].reshape(B, -1)
            x[:, :frozen_steps * self.action_dim] = prefix_flat

        dt = 1.0 / num_denoise_steps

        for i in range(num_denoise_steps):
            t = torch.full((B,), i * dt, device=device)
            v = self._predict_velocity(x, t, features)

            # Physics-aware guidance: add gradient correction to velocity field
            # AirVLA Eq. 4: v_guided = v_base - λ * ∇_x Φ(denoise(x_t))
            if guidance_fn is not None and guidance_scale > 0:
                # Enable gradients for guidance computation only
                # (we're inside @torch.no_grad(), so must explicitly enable)
                with torch.enable_grad():
                    x_guided = x.detach().requires_grad_(True)
                    # Estimate denoised action from current noisy state
                    # (one-step denoising estimate: x_denoised ≈ x_t + v * (1 - t))
                    remaining_t = 1.0 - (i * dt)
                    v_for_denoise = self._predict_velocity(x_guided, t, features)
                    x_denoised = x_guided + v_for_denoise * remaining_t
                    x_denoised_shaped = x_denoised.reshape(B, self.num_steps, self.action_dim)
                    # Compute guidance loss
                    guidance_loss = guidance_fn(x_denoised_shaped)
                    guidance_grad = torch.autograd.grad(guidance_loss, x_guided)[0]
                # Subtract guidance gradient from velocity (gradient descent on loss)
                v = v - guidance_scale * guidance_grad

            x = x + v * dt

            # RTC: re-freeze prefix after each step to prevent drift
            if frozen_prefix is not None and frozen_steps > 0:
                x[:, :frozen_steps * self.action_dim] = prefix_flat

        # Reshape and soft-cap
        actions = x.reshape(B, self.num_steps, self.action_dim)
        if self.soft_cap_value > 0:
            actions = soft_cap(actions, self.soft_cap_value)

        return actions


class DiTActionHead(nn.Module):
    """Diffusion Transformer (DiT) action head inspired by GR00T N1.6.

    Uses adaptive layer norm (adaLN) conditioning from features + timestep.
    DDIM sampling with configurable denoising steps.

    Architecture: N DiT blocks, each with:
        1. adaLN(features, t) → scale, shift, gate
        2. Self-attention over action tokens (num_steps tokens)
        3. MLP with ReLU² + RMSNorm

    Simpler than GR00T's 32-layer DiT — we use 8 layers since our
    backbone is frozen and provides stronger features.
    """

    def __init__(
        self,
        input_dim: int,
        action_dim: int,
        num_steps: int = 16,
        hidden_dim: int = 384,
        num_layers: int = 8,
        num_heads: int = 6,
        dropout: float = 0.1,
        num_denoise_steps: int = 4,
        soft_cap_value: float = 1.0,
    ):
        super().__init__()
        self.action_dim = action_dim
        self.num_steps = num_steps
        self.num_denoise_steps = num_denoise_steps
        self.soft_cap_value = soft_cap_value
        self.hidden_dim = hidden_dim

        # Action token embedding (action_dim → hidden_dim per step)
        self.action_embed = nn.Linear(action_dim, hidden_dim)

        # Positional embedding for action steps
        self.pos_embed = nn.Parameter(torch.randn(1, num_steps, hidden_dim) * 0.02)

        # Timestep embedding
        self.time_embed = nn.Sequential(
            nn.Linear(1, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
        )

        # Feature conditioning
        self.cond_proj = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            RMSNorm(hidden_dim),
            ReLUSquared(),
        )

        # DiT blocks
        self.blocks = nn.ModuleList([
            DiTBlock(hidden_dim, num_heads, dropout) for _ in range(num_layers)
        ])

        # Final layer norm + output projection
        self.final_norm = RMSNorm(hidden_dim)
        self.out_proj = nn.Linear(hidden_dim, action_dim)

        # Initialize output layer to near-zero (diffusion best practice)
        nn.init.zeros_(self.out_proj.weight)
        nn.init.zeros_(self.out_proj.bias)

        total_params = sum(p.numel() for p in self.parameters())
        logger.info(f"DiTActionHead: {total_params:,} params, {num_layers} layers, {num_heads} heads")

    def _forward_with_t(
        self,
        noisy_actions: torch.Tensor,
        t: torch.Tensor,
        features: torch.Tensor,
    ) -> torch.Tensor:
        """Predict noise/score at timestep t.

        Args:
            noisy_actions: (batch, num_steps, action_dim)
            t: (batch,) diffusion timestep in [0, 1]
            features: (batch, input_dim) conditioning

        Returns:
            (batch, num_steps, action_dim) predicted noise
        """
        B = noisy_actions.shape[0]

        # Embed action tokens + positional
        h = self.action_embed(noisy_actions) + self.pos_embed  # (B, S, D)

        # Condition embedding: features + time
        cond = self.cond_proj(features) + self.time_embed(t.unsqueeze(-1))  # (B, D)

        # Pass through DiT blocks with adaLN conditioning
        for block in self.blocks:
            h = block(h, cond)

        # Output projection
        h = self.final_norm(h)
        return self.out_proj(h)  # (B, S, action_dim)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        """Generate actions via DDIM sampling."""
        return self.sample(features, self.num_denoise_steps)

    def compute_loss(
        self,
        features: torch.Tensor,
        target_actions: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """DDPM-style noise prediction loss.

        Simple formulation: predict the noise added at random timestep.
        """
        B = features.shape[0]
        device = features.device

        # Random timestep
        t = torch.rand(B, device=device)

        # Sample noise
        noise = torch.randn_like(target_actions)

        # Noisy actions (simple linear schedule)
        alpha_t = t.unsqueeze(-1).unsqueeze(-1)  # (B, 1, 1)
        noisy = alpha_t * target_actions + (1.0 - alpha_t) * noise

        # Predict noise
        noise_pred = self._forward_with_t(noisy, t, features)

        # MSE loss on noise
        loss = F.mse_loss(noise_pred, noise, reduction="none")

        if mask is not None:
            loss = loss * mask.unsqueeze(-1)

        return loss.mean()

    @torch.no_grad()
    def sample(self, features: torch.Tensor, num_denoise_steps: int = None) -> torch.Tensor:
        """DDIM deterministic sampling."""
        if num_denoise_steps is None:
            num_denoise_steps = self.num_denoise_steps

        B = features.shape[0]
        device = features.device

        # Start from noise
        x = torch.randn(B, self.num_steps, self.action_dim, device=device)

        # DDIM steps (from t=0 noise to t=1 clean)
        timesteps = torch.linspace(0, 1, num_denoise_steps + 1, device=device)

        for i in range(num_denoise_steps):
            t_curr = timesteps[i]
            t_next = timesteps[i + 1]

            t_batch = torch.full((B,), t_curr.item(), device=device)
            noise_pred = self._forward_with_t(x, t_batch, features)

            # DDIM step: move toward signal
            # x_0_pred = (x - (1-α_t)*noise) / α_t
            alpha_curr = t_curr
            alpha_next = t_next
            # Simplified: linear interpolation toward predicted clean
            x_0_pred = (x - (1.0 - alpha_curr) * noise_pred) / alpha_curr.clamp(min=1e-5)
            x = alpha_next * x_0_pred + (1.0 - alpha_next) * noise_pred

        # Soft-cap output
        if self.soft_cap_value > 0:
            x = soft_cap(x, self.soft_cap_value)

        return x


class DiTBlock(nn.Module):
    """Single DiT block with adaptive layer norm and optional cross-attention.

    Architecture:
        1. adaLN → self-attention → residual
        2. adaLN → cross-attention to backbone features (optional) → residual
        3. adaLN → MLP (ReLU²) → residual

    The cross-attention path (from GR00T N1.6) lets action tokens attend
    directly to backbone VL features — much stronger than conditioning only
    via adaLN scale/shift.
    """

    def __init__(
        self,
        hidden_dim: int,
        num_heads: int = 6,
        dropout: float = 0.1,
        cross_attention_dim: Optional[int] = None,
    ):
        super().__init__()
        # Self-attention
        self.norm1 = RMSNorm(hidden_dim)
        self.attn = nn.MultiheadAttention(
            hidden_dim, num_heads, dropout=dropout, batch_first=True,
        )

        # MLP
        self.norm2 = RMSNorm(hidden_dim)
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim * 4),
            ReLUSquared(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 4, hidden_dim),
            nn.Dropout(dropout),
        )

        # Cross-attention to backbone features (GR00T N1.6 style)
        self.has_cross_attn = cross_attention_dim is not None
        if self.has_cross_attn:
            self.norm_cross = RMSNorm(hidden_dim)
            # Project cross_attention_dim to hidden_dim for K,V
            self.cross_kv_proj = nn.Linear(cross_attention_dim, hidden_dim) if cross_attention_dim != hidden_dim else nn.Identity()
            self.cross_attn = nn.MultiheadAttention(
                hidden_dim, num_heads, dropout=dropout, batch_first=True,
            )
            # adaLN for cross-attention: 3 more params (scale, shift, gate)
            num_adaln_params = 9  # 3 blocks × 3 params
        else:
            num_adaln_params = 6  # 2 blocks × 3 params

        # adaLN modulation: condition → (scale, shift, gate) × num_blocks
        self.adaLN = nn.Sequential(
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim * num_adaln_params),
        )
        self._num_adaln_params = num_adaln_params

    def forward(
        self,
        x: torch.Tensor,
        cond: torch.Tensor,
        encoder_hidden_states: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Forward with adaptive conditioning and optional cross-attention.

        Args:
            x: (batch, seq_len, hidden_dim) action tokens
            cond: (batch, hidden_dim) conditioning (features + time)
            encoder_hidden_states: (batch, src_len, cross_attention_dim) backbone features
                                   Required when cross_attention_dim was set.

        Returns:
            (batch, seq_len, hidden_dim) updated tokens
        """
        # Get modulation parameters
        mod = self.adaLN(cond).unsqueeze(1)  # (B, 1, N*D)

        # Split into per-block (scale, shift, gate) triplets
        if self._num_adaln_params == 9:
            mod_params = mod.chunk(9, dim=-1)
            scale1, shift1, gate1 = mod_params[0], mod_params[1], mod_params[2]
            scale_c, shift_c, gate_c = mod_params[3], mod_params[4], mod_params[5]
            scale2, shift2, gate2 = mod_params[6], mod_params[7], mod_params[8]
        else:
            mod_params = mod.chunk(6, dim=-1)
            scale1, shift1, gate1 = mod_params[0], mod_params[1], mod_params[2]
            scale2, shift2, gate2 = mod_params[3], mod_params[4], mod_params[5]

        # Self-attention with adaLN
        h = self.norm1(x)
        h = h * (1 + scale1) + shift1
        h, _ = self.attn(h, h, h, need_weights=False)
        x = x + gate1 * h

        # === Cross-attention block (GR00T N1.6) ===
        if self.has_cross_attn and encoder_hidden_states is not None:
            h = self.norm_cross(x)
            h = h * (1 + scale_c) + shift_c
            kv = self.cross_kv_proj(encoder_hidden_states)
            h, _ = self.cross_attn(h, kv, kv, need_weights=False)
            x = x + gate_c * h

        # === MLP block ===
        h = self.norm2(x)
        h = h * (1 + scale2) + shift2
        h = self.mlp(h)
        x = x + gate2 * h

        return x


class StateRelativeHead(nn.Module):
    """State-relative action head wrapper — outputs Δ from current state.

    Inspired by GR00T N1.6's relative action formulation. Instead of predicting
    absolute joint positions, predicts deltas from the current proprioception:

        action_absolute = current_state + inner_head(features)

    This reduces error accumulation in closed-loop control because small
    prediction errors stay small instead of drifting from the true state.

    Wraps any existing action head (MLP, Flow, DiT) — zero extra parameters
    beyond the inner head.
    """

    def __init__(self, inner_head: nn.Module, action_dim: int, num_steps: int = 16):
        super().__init__()
        self.inner_head = inner_head
        self.action_dim = action_dim
        self.num_steps = num_steps

    def forward(
        self,
        features: torch.Tensor,
        current_state: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Predict actions as deltas from current state.

        Args:
            features: (batch, hidden_size) conditioning features
            current_state: (batch, action_dim) current joint positions.
                If None, falls back to absolute prediction.

        Returns:
            (batch, num_steps, action_dim) absolute actions
        """
        deltas = self.inner_head(features)  # (batch, num_steps, action_dim) or (batch, action_dim)

        if current_state is None:
            return deltas

        # Expand current_state to match action chunk shape
        if deltas.dim() == 3:
            # (batch, action_dim) → (batch, 1, action_dim) → broadcast
            state_expanded = current_state.unsqueeze(1)
        else:
            state_expanded = current_state

        return state_expanded + deltas

    def compute_loss(
        self,
        features: torch.Tensor,
        target_actions: torch.Tensor,
        current_state: Optional[torch.Tensor] = None,
        mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Compute loss on deltas (not absolute positions).

        If current_state is provided, converts targets to deltas first,
        then computes loss in delta space. This is key — training on
        deltas is more stable than training on absolutes.
        """
        if current_state is not None:
            # Convert targets to deltas
            if target_actions.dim() == 3:
                state_expanded = current_state.unsqueeze(1)
            else:
                state_expanded = current_state
            target_deltas = target_actions - state_expanded
        else:
            target_deltas = target_actions

        # Delegate to inner head's loss if it has one (Flow/DiT)
        if hasattr(self.inner_head, 'compute_loss'):
            return self.inner_head.compute_loss(features, target_deltas, mask)

        # Fallback: MSE on deltas
        predicted_deltas = self.inner_head(features)
        loss = F.mse_loss(predicted_deltas, target_deltas, reduction="none")
        if mask is not None:
            if loss.dim() == 3:
                mask = mask.unsqueeze(-1).expand_as(loss)
            loss = loss * mask
        return loss.mean()

    @torch.no_grad()
    def sample(self, features: torch.Tensor, current_state: Optional[torch.Tensor] = None, **kwargs) -> torch.Tensor:
        """Sample actions (for Flow/DiT inner heads)."""
        if hasattr(self.inner_head, 'sample'):
            deltas = self.inner_head.sample(features, **kwargs)
        else:
            deltas = self.inner_head(features)

        if current_state is not None:
            if deltas.dim() == 3:
                state_expanded = current_state.unsqueeze(1)
            else:
                state_expanded = current_state
            return state_expanded + deltas
        return deltas


class EnsembleHead(nn.Module):
    """Gated ensemble of MLP + Flow + DiT action heads.

    Learns a per-sample gate that weights predictions from three heads.
    The gate is conditioned on the input features — so the model learns
    WHICH head to trust for which task/state:

    - MLP: fast, good for simple trajectories
    - Flow: multi-modal, good for ambiguous actions
    - DiT: highest capacity, good for complex sequences

    Gate: softmax(Linear(features)) → (batch, 3)
    Output: gate[0]*mlp + gate[1]*flow + gate[2]*dit

    Total params: ~13M (MLP ~3M + Flow ~4M + DiT ~6M + gate ~6K)
    """

    def __init__(
        self,
        input_dim: int,
        action_dim: int,
        num_steps: int = 16,
        mlp_hidden: int = 512,
        flow_hidden: int = 512,
        dit_hidden: int = 384,
        dit_layers: int = 8,
        dit_heads: int = 6,
        flow_layers: int = 4,
        dropout: float = 0.1,
        num_denoise_steps: int = 4,
        soft_cap_value: float = 1.0,
    ):
        super().__init__()
        self.action_dim = action_dim
        self.num_steps = num_steps

        # Three action heads
        self.mlp_head = ActionChunkingHead(
            input_dim=input_dim, action_dim=action_dim, num_steps=num_steps,
            hidden_dim=mlp_hidden, dropout=dropout, soft_cap_value=soft_cap_value,
        )
        self.flow_head = FlowMatchingHead(
            input_dim=input_dim, action_dim=action_dim, num_steps=num_steps,
            hidden_dim=flow_hidden, num_layers=flow_layers, dropout=dropout,
            num_denoise_steps=num_denoise_steps, soft_cap_value=soft_cap_value,
        )
        self.dit_head = DiTActionHead(
            input_dim=input_dim, action_dim=action_dim, num_steps=num_steps,
            hidden_dim=dit_hidden, num_layers=dit_layers, num_heads=dit_heads,
            dropout=dropout, num_denoise_steps=num_denoise_steps,
            soft_cap_value=soft_cap_value,
        )

        # Learned gating network
        self.gate = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.GELU(),
            nn.Linear(64, 3),  # 3 heads
        )

        total_params = sum(p.numel() for p in self.parameters())
        logger.info(f"EnsembleHead: {total_params:,} params (MLP+Flow+DiT+gate)")

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        """Gated ensemble prediction.

        Args:
            features: (batch, input_dim)

        Returns:
            (batch, num_steps, action_dim) weighted ensemble output
        """
        # Get predictions from all heads
        mlp_out = self.mlp_head(features)   # (batch, num_steps, action_dim)
        flow_out = self.flow_head(features)  # (batch, num_steps, action_dim)
        dit_out = self.dit_head(features)    # (batch, num_steps, action_dim)

        # Compute gate weights
        gate_logits = self.gate(features)  # (batch, 3)
        gate_weights = F.softmax(gate_logits, dim=-1)  # (batch, 3)

        # Weighted sum: expand gate to (batch, 1, 1) for broadcasting
        w = gate_weights.unsqueeze(-1).unsqueeze(-1)  # (batch, 3, 1, 1)
        stacked = torch.stack([mlp_out, flow_out, dit_out], dim=1)  # (batch, 3, steps, dim)
        return (w * stacked).sum(dim=1)  # (batch, steps, dim)

    def compute_loss(
        self,
        features: torch.Tensor,
        target_actions: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Train all three heads + gate jointly.

        Each head computes its own loss. The gate loss encourages
        routing to the head with lowest error.
        """
        # Individual head losses
        flow_loss = self.flow_head.compute_loss(features, target_actions, mask)
        dit_loss = self.dit_head.compute_loss(features, target_actions, mask)

        # MLP loss (direct MSE)
        mlp_pred = self.mlp_head(features)
        mlp_loss = F.mse_loss(mlp_pred, target_actions, reduction="none")
        if mask is not None:
            mlp_loss = mlp_loss * mask.unsqueeze(-1)
        mlp_loss = mlp_loss.mean()

        # Ensemble prediction loss (the main loss)
        ensemble_pred = self.forward(features)
        ensemble_loss = F.mse_loss(ensemble_pred, target_actions, reduction="none")
        if mask is not None:
            ensemble_loss = ensemble_loss * mask.unsqueeze(-1)
        ensemble_loss = ensemble_loss.mean()

        # Combined: ensemble + 0.3 * (individual heads) for regularization
        total = ensemble_loss + 0.3 * (mlp_loss + flow_loss + dit_loss)
        return total

    @torch.no_grad()
    def sample(self, features: torch.Tensor, num_denoise_steps: int = None) -> torch.Tensor:
        """Sample via gated ensemble."""
        return self.forward(features)


class G1ActionHead(nn.Module):
    """Multi-head action decoder for the G1 humanoid.

    Can use either:
    1. Single MLP for all actions
    2. Separate heads per group (arms, grippers, locomotion)

    With optional action chunking for temporal smoothness.
    """

    def __init__(self, config: ActionHeadConfig, action_space: G1ActionSpace):
        super().__init__()
        self.config = config
        self.action_space = action_space

        if config.use_separate_heads:
            self._build_separate_heads()
        else:
            self._build_single_head()

        # Count parameters
        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        logger.info(f"ActionHead: {trainable_params:,} trainable / {total_params:,} total parameters")

    def _build_single_head(self):
        """Single MLP/chunking head for all actions."""
        if self.config.use_action_chunking:
            self.head = ActionChunkingHead(
                input_dim=self.config.hidden_size,
                action_dim=self.action_space.action_dim,
                num_steps=self.config.num_action_steps,
                hidden_dim=self.config.mlp_hidden,
                dropout=self.config.dropout,
                use_relu_squared=self.config.use_relu_squared,
                use_rmsnorm=self.config.use_rmsnorm,
                soft_cap_value=self.config.soft_cap_value,
            )
        else:
            self.head = MLPDecoder(
                input_dim=self.config.hidden_size,
                output_dim=self.action_space.action_dim,
                hidden_dim=self.config.mlp_hidden,
                num_layers=self.config.num_layers,
                dropout=self.config.dropout,
                use_relu_squared=self.config.use_relu_squared,
                use_rmsnorm=self.config.use_rmsnorm,
                use_residual_scale=self.config.use_residual_scale,
                use_skip_connections=self.config.use_skip_connections,
                soft_cap_value=self.config.soft_cap_value,
            )

    def _build_separate_heads(self):
        """Separate decoder head per action group."""
        self.heads = nn.ModuleDict()

        # Common v2 kwargs for all sub-heads
        v2_mlp = dict(
            use_relu_squared=self.config.use_relu_squared,
            use_rmsnorm=self.config.use_rmsnorm,
            use_residual_scale=self.config.use_residual_scale,
            use_skip_connections=self.config.use_skip_connections,
            soft_cap_value=self.config.soft_cap_value,
        )
        v2_chunk = dict(
            use_relu_squared=self.config.use_relu_squared,
            use_rmsnorm=self.config.use_rmsnorm,
            soft_cap_value=self.config.soft_cap_value,
        )

        # Arms head (left + right)
        arm_indices = (
            self.action_space.get_group_indices("left_arm")
            + self.action_space.get_group_indices("right_arm")
        )
        if arm_indices:
            arm_dim = len(arm_indices)
            if self.config.use_action_chunking:
                self.heads["arms"] = ActionChunkingHead(
                    self.config.hidden_size, arm_dim,
                    self.config.num_action_steps, self.config.mlp_hidden,
                    dropout=self.config.dropout, **v2_chunk,
                )
            else:
                self.heads["arms"] = MLPDecoder(
                    self.config.hidden_size, arm_dim,
                    self.config.mlp_hidden, self.config.num_layers,
                    self.config.dropout, **v2_mlp,
                )

        # Locomotion head
        if self.action_space.include_locomotion:
            if self.config.use_action_chunking:
                self.heads["locomotion"] = ActionChunkingHead(
                    self.config.hidden_size, 3,
                    self.config.num_action_steps, self.config.mlp_hidden // 2,
                    dropout=self.config.dropout, **v2_chunk,
                )
            else:
                self.heads["locomotion"] = MLPDecoder(
                    self.config.hidden_size, 3,
                    self.config.mlp_hidden // 2, 2,
                    self.config.dropout, **v2_mlp,
                )

        # Torso + head joints (if in upper_body or whole_body mode)
        if self.action_space.mode in (ControlMode.UPPER_BODY, ControlMode.WHOLE_BODY):
            torso_head_indices = (
                self.action_space.get_group_indices("torso")
                + self.action_space.get_group_indices("head")
            )
            if torso_head_indices:
                dim = len(torso_head_indices)
                self.heads["torso_head"] = MLPDecoder(
                    self.config.hidden_size, dim,
                    self.config.mlp_hidden // 2, 2,
                    self.config.dropout, **v2_mlp,
                )

        # Leg joints (if whole_body mode)
        if self.action_space.mode == ControlMode.WHOLE_BODY:
            leg_indices = (
                self.action_space.get_group_indices("left_leg")
                + self.action_space.get_group_indices("right_leg")
            )
            if leg_indices:
                dim = len(leg_indices)
                self.heads["legs"] = MLPDecoder(
                    self.config.hidden_size, dim,
                    self.config.mlp_hidden, self.config.num_layers,
                    self.config.dropout, **v2_mlp,
                )

        # Record index mapping for assembly
        self._arm_indices = arm_indices if arm_indices else []
        self._torso_head_indices = (
            self.action_space.get_group_indices("torso")
            + self.action_space.get_group_indices("head")
        ) if self.action_space.mode != ControlMode.ARMS_ONLY else []
        self._leg_indices = (
            self.action_space.get_group_indices("left_leg")
            + self.action_space.get_group_indices("right_leg")
        ) if self.action_space.mode == ControlMode.WHOLE_BODY else []

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        """Decode features into actions.

        Args:
            features: (batch, hidden_size) pooled features from backbone

        Returns:
            If action_chunking: (batch, num_steps, action_dim)
            Else: (batch, action_dim)
        """
        if not self.config.use_separate_heads:
            return self.head(features)

        # Separate heads — assemble output
        parts = []

        if "arms" in self.heads:
            parts.append(self.heads["arms"](features))

        if "torso_head" in self.heads:
            parts.append(self.heads["torso_head"](features))

        if "legs" in self.heads:
            parts.append(self.heads["legs"](features))

        if "locomotion" in self.heads:
            parts.append(self.heads["locomotion"](features))

        # Concatenate along action dimension
        if self.config.use_action_chunking:
            # All parts: (batch, num_steps, dim_i)
            return torch.cat(parts, dim=-1)
        else:
            # All parts: (batch, dim_i)
            return torch.cat(parts, dim=-1)

    def compute_loss(
        self,
        predicted: torch.Tensor,
        target: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Compute MSE loss between predicted and target actions.

        Args:
            predicted: Predicted actions (batch, [num_steps,] action_dim)
            target: Ground truth actions (batch, [num_steps,] action_dim)
            mask: Optional mask for valid timesteps (batch, [num_steps])

        Returns:
            Scalar loss
        """
        loss = F.mse_loss(predicted, target, reduction="none")  # Per-element loss

        if mask is not None:
            # Expand mask to action dim
            if loss.dim() == 3:  # (batch, steps, dim)
                mask = mask.unsqueeze(-1).expand_as(loss)
            loss = loss * mask

        return loss.mean()
