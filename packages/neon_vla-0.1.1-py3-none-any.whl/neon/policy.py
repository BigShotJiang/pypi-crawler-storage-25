#!/usr/bin/env python3
"""
Neon Policy Provider for strands-robots — plug-and-play VLA policy.

Exposes Neon as a first-class strands-robots policy so users can do:

    from strands_robots.policies import create_policy
    policy = create_policy("neon", host="localhost", port=8300)
    actions = await policy.get_actions(obs, "pick up the red cup")

Or directly:

    from neon.policy import NeonPolicy
    policy = NeonPolicy(host="localhost", port=8300)

Full omni-modal support:
    📷 Camera    — RGB images (single or multi-frame video)
    🦾 Proprio   — Joint positions (29-DOF G1)
    🎤 Audio     — 16kHz voice commands → Whisper encoder
    📡 LiDAR     — Point clouds (N×4) → PointNet encoder
    🤲 EEF       — Bimanual end-effector pos+quat (14-DOF)
    🗣️ Speech    — PersonaPlex TTS response

Server setup:
    python -m neon.inference.server --model cagataydev/neon-g1-v1-dev --port 8300
"""

from __future__ import annotations

import logging
import time
from collections import deque
from typing import Any, Dict, List, Optional

import numpy as np

logger = logging.getLogger(__name__)

# Try to import strands_robots Policy base — graceful fallback
try:
    from strands_robots.policies import Policy
except ImportError:
    from abc import ABC, abstractmethod

    class Policy(ABC):
        """Minimal Policy ABC when strands-robots is not installed."""

        @abstractmethod
        async def get_actions(self, observation_dict: Dict[str, Any], instruction: str, **kwargs) -> List[Dict[str, Any]]:
            pass

        def get_actions_sync(self, observation_dict: Dict[str, Any], instruction: str, **kwargs) -> List[Dict[str, Any]]:
            import asyncio
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                loop = None
            if loop and loop.is_running():
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    return pool.submit(asyncio.run, self.get_actions(observation_dict, instruction, **kwargs)).result()
            else:
                return asyncio.run(self.get_actions(observation_dict, instruction, **kwargs))

        @abstractmethod
        def set_robot_state_keys(self, robot_state_keys: List[str]) -> None:
            pass

        @property
        @abstractmethod
        def provider_name(self) -> str:
            pass


# ─── Observation key conventions ────────────────────────────────────
# strands-robots uses "observation.*" keys. Neon inference server has
# specific field names. This mapping bridges both:

_OBS_KEY_MAP = {
    # Camera
    "observation.images.front": "image",
    "observation.images.main": "image",
    "observation.image": "image",
    # Proprioception
    "observation.state": "proprioception",
    "observation.joint_positions": "proprioception",
    # Audio
    "observation.audio": "audio",
    "observation.voice": "audio",
    # LiDAR
    "observation.lidar": "lidar",
    "observation.point_cloud": "lidar",
    # EEF
    "observation.eef_state": "eef_state",
    "observation.end_effector": "eef_state",
}


class NeonPolicy(Policy):
    """Neon VLA Policy — frozen video backbone + lightweight action heads.

    Connects to a Neon inference server via HTTP or ZMQ. Implements an RTC
    (Real-Time Control) action queue that bridges VLA inference frequency
    (~5-10 Hz) with robot control frequency (50 Hz) via temporal blending.

    Supports ALL Neon modalities:

    | Modality | Observation Key | Server Field | Encoding |
    |----------|----------------|--------------|----------|
    | Camera   | observation.images.* | image_base64 | Base64 PNG |
    | Video    | observation.video_frames | video_frames_base64 | Base64 PNG list |
    | Proprio  | observation.state | proprioception | Float list |
    | Audio    | observation.audio | audio / audio_base64 | Float list or PCM-16 |
    | LiDAR    | observation.lidar | lidar | Float list (N×4) |
    | EEF      | observation.eef_state | eef_state | Float list (14) |

    Parameters
    ----------
    host : str
        Neon inference server hostname (default: "localhost").
    port : int
        Neon inference server port (default: 8300).
    protocol : str
        Communication protocol — "http" or "zmq" (default: "http").
    blend_schedule : str
        RTC blending schedule: "linear", "step", or "exponential".
    actions_per_step : int
        Actions to dequeue per get_actions() call (default: 1).
    chunk_size : int
        Expected action chunk size (default: 16).
    action_dim : int
        Action dimensionality (default: 17 = 14 arm + 3 loco).
    refill_threshold : int
        Request new chunk when queue has this many left (default: 4).
    timeout : float
        Request timeout in seconds (default: 5.0).
    speak : bool
        Enable speech output from robot (default: False).

    Examples
    --------
    >>> from neon import NeonPolicy
    >>> policy = NeonPolicy(host="192.168.123.10", port=8300)
    >>>
    >>> # Full omni-modal observation
    >>> obs = {
    ...     "observation.images.front": camera_frame,       # (H,W,3) uint8
    ...     "observation.state": joint_positions,            # (17,) float32
    ...     "observation.audio": voice_waveform,             # (16000,) float32
    ...     "observation.lidar": point_cloud,                # (4096, 4) float32
    ...     "observation.eef_state": ee_state,               # (14,) float32
    ... }
    >>> actions = policy.get_actions_sync(obs, "pick up the red cup")
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 8300,
        protocol: str = "http",
        blend_schedule: str = "linear",
        actions_per_step: int = 1,
        chunk_size: int = 16,
        action_dim: int = 17,
        refill_threshold: int = 4,
        timeout: float = 5.0,
        speak: bool = False,
        **kwargs,
    ):
        if refill_threshold >= chunk_size:
            raise ValueError(
                f"refill_threshold ({refill_threshold}) must be < chunk_size ({chunk_size}). "
                f"The overlap region is where blending occurs."
            )

        self._host = host
        self._port = port
        self._protocol = protocol
        self._blend_schedule = blend_schedule
        self._actions_per_step = actions_per_step
        self._chunk_size = chunk_size
        self._action_dim = action_dim
        self._refill_threshold = refill_threshold
        self._timeout = timeout
        self._speak = speak

        self._robot_state_keys: List[str] = []
        self._action_queue: deque = deque()
        self._session = None
        self._zmq_socket = None
        self._step = 0
        self._last_instruction: str = ""
        self._server_modalities: Optional[Dict[str, bool]] = None

        logger.info(
            f"🦾 Neon policy initialized: {protocol}://{host}:{port} "
            f"blend={blend_schedule} chunk={chunk_size} dim={action_dim}"
        )

    @property
    def provider_name(self) -> str:
        return "neon"

    def set_robot_state_keys(self, robot_state_keys: List[str]) -> None:
        """Set robot joint/state key names for action dict construction."""
        self._robot_state_keys = robot_state_keys
        logger.info(f"🔧 Neon robot state keys set: {len(robot_state_keys)} keys")

    # ─── Observation Parsing ────────────────────────────────────────────

    def _parse_observations(
        self, observation_dict: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Parse strands-robots observation dict into Neon server payload fields.

        Handles key mapping, type conversion, and encoding for all modalities.

        Returns:
            Dict with server-compatible fields: image_base64, video_frames_base64,
            proprioception, audio, audio_base64, lidar, eef_state.
        """
        import base64
        import io

        payload: Dict[str, Any] = {}
        images_for_video = []

        for key, value in observation_dict.items():
            # Map canonical keys
            mapped = _OBS_KEY_MAP.get(key)

            if isinstance(value, np.ndarray):
                if value.ndim >= 3 and value.shape[-1] in (1, 3, 4):
                    # Likely an image (H, W, C)
                    from PIL import Image
                    img = Image.fromarray(value.astype(np.uint8))
                    buf = io.BytesIO()
                    img.save(buf, format="PNG")
                    b64 = base64.b64encode(buf.getvalue()).decode()

                    if "video" in key.lower() or "frames" in key.lower():
                        images_for_video.append(b64)
                    elif "image_base64" not in payload:
                        payload["image_base64"] = b64
                    else:
                        images_for_video.append(b64)

                elif mapped == "audio" or "audio" in key.lower() or "voice" in key.lower():
                    # Audio waveform — send as float list
                    payload["audio"] = value.astype(np.float32).flatten().tolist()

                elif mapped == "lidar" or "lidar" in key.lower() or "point_cloud" in key.lower():
                    # LiDAR point cloud — (N, 4) as nested list
                    pts = value.astype(np.float32)
                    if pts.ndim == 1:
                        pts = pts.reshape(-1, 4)
                    payload["lidar"] = pts.tolist()

                elif mapped == "eef_state" or "eef" in key.lower() or "end_effector" in key.lower():
                    # End-effector state
                    payload["eef_state"] = value.astype(np.float32).flatten().tolist()

                elif mapped == "proprioception" or "state" in key.lower() or "joint" in key.lower() or "proprio" in key.lower():
                    # Joint state / proprioception
                    payload["proprioception"] = value.astype(np.float32).flatten().tolist()

                else:
                    # Generic array — try to guess by shape
                    if value.ndim == 1 and len(value) <= 64:
                        # Small 1D vector → proprioception or eef
                        if "proprioception" not in payload:
                            payload["proprioception"] = value.astype(np.float32).tolist()
                    else:
                        logger.debug(f"Skipping unrecognized observation key: {key} shape={value.shape}")

            elif isinstance(value, (list, tuple)):
                if mapped == "proprioception" or "state" in key.lower():
                    payload["proprioception"] = [float(v) for v in value]
                elif mapped == "audio":
                    payload["audio"] = [float(v) for v in value]
                elif mapped == "lidar":
                    payload["lidar"] = value
                elif mapped == "eef_state":
                    payload["eef_state"] = [float(v) for v in value]

            elif isinstance(value, bytes) and ("audio" in key.lower() or mapped == "audio"):
                # Raw PCM-16 audio bytes
                payload["audio_base64"] = base64.b64encode(value).decode()

        # Collect video frames
        if images_for_video:
            payload["video_frames_base64"] = images_for_video

        return payload

    # ─── HTTP / ZMQ Communication ───────────────────────────────────────

    def _ensure_http_session(self):
        """Lazily create HTTP session for server communication."""
        if self._session is not None:
            return
        try:
            import requests
        except ImportError:
            raise ImportError("Neon HTTP mode requires requests: pip install requests")
        self._session = requests.Session()
        self._session.headers.update({"Content-Type": "application/json"})

    def _ensure_zmq_socket(self):
        """Lazily create ZMQ socket for server communication."""
        if self._zmq_socket is not None:
            return
        try:
            import zmq
        except ImportError:
            raise ImportError("Neon ZMQ mode requires pyzmq: pip install pyzmq")
        context = zmq.Context.instance()
        self._zmq_socket = context.socket(zmq.REQ)
        self._zmq_socket.setsockopt(zmq.RCVTIMEO, int(self._timeout * 1000))
        self._zmq_socket.setsockopt(zmq.SNDTIMEO, int(self._timeout * 1000))
        self._zmq_socket.connect(f"tcp://{self._host}:{self._port}")

    def _request_chunk_http(
        self, observation_dict: Dict[str, Any], instruction: str
    ) -> np.ndarray:
        """Request an action chunk from the Neon HTTP server.

        Parses the observation dict and sends all detected modalities.
        """
        self._ensure_http_session()

        # Parse observations into server-compatible payload
        payload = self._parse_observations(observation_dict)
        payload["instruction"] = instruction
        payload["speak"] = self._speak

        url = f"http://{self._host}:{self._port}/predict"
        try:
            response = self._session.post(url, json=payload, timeout=self._timeout)
            response.raise_for_status()
            result = response.json()
        except Exception as e:
            raise RuntimeError(
                f"Neon HTTP request failed ({url}): {e}. "
                f"Start server with: python -m neon.inference.server --port {self._port}"
            ) from e

        # Store speech path if returned
        if "speech_path" in result:
            self._last_speech_path = result["speech_path"]

        return np.array(result["actions"], dtype=np.float32)

    def _request_chunk_zmq(
        self, observation_dict: Dict[str, Any], instruction: str
    ) -> np.ndarray:
        """Request an action chunk from the Neon ZMQ server."""
        self._ensure_zmq_socket()
        try:
            import msgpack
            import msgpack_numpy
            msgpack_numpy.patch()
        except ImportError:
            raise ImportError("Neon ZMQ mode requires msgpack: pip install msgpack msgpack-numpy")

        request = {
            "instruction": instruction,
            "observations": observation_dict,
            "step": self._step,
            "speak": self._speak,
        }
        try:
            packed = msgpack.packb(request, default=msgpack_numpy.encode)
            self._zmq_socket.send(packed)
            reply = self._zmq_socket.recv()
            result = msgpack.unpackb(reply, object_hook=msgpack_numpy.decode)
        except Exception as e:
            raise RuntimeError(f"Neon ZMQ request failed: {e}") from e

        return np.array(result["actions"], dtype=np.float32)

    def _request_chunk(
        self, observation_dict: Dict[str, Any], instruction: str
    ) -> np.ndarray:
        """Request an action chunk using the configured protocol."""
        if self._protocol == "zmq":
            return self._request_chunk_zmq(observation_dict, instruction)
        return self._request_chunk_http(observation_dict, instruction)

    # ─── RTC Action Queue ───────────────────────────────────────────────

    def _blend_chunks(
        self, old_remaining: np.ndarray, new_chunk: np.ndarray
    ) -> np.ndarray:
        """Blend overlapping actions from old and new chunks."""
        overlap = min(len(old_remaining), len(new_chunk))
        if overlap == 0:
            return new_chunk

        old_overlap = old_remaining[-overlap:]
        new_overlap = new_chunk[:overlap]

        if self._blend_schedule == "linear":
            alpha = np.linspace(0, 1, overlap).reshape(-1, 1)
            blended = (1 - alpha) * old_overlap + alpha * new_overlap
        elif self._blend_schedule == "step":
            mid = overlap // 2
            blended = np.concatenate([old_overlap[:mid], new_overlap[mid:]], axis=0)
        elif self._blend_schedule == "exponential":
            decay = 0.5
            alpha = np.array([1 - decay ** (i + 1) for i in range(overlap)]).reshape(-1, 1)
            blended = (1 - alpha) * old_overlap + alpha * new_overlap
        else:
            raise ValueError(f"Unknown blend_schedule '{self._blend_schedule}'")

        result_parts = []
        if len(old_remaining) > overlap:
            result_parts.append(old_remaining[:-overlap])
        result_parts.append(blended)
        if len(new_chunk) > overlap:
            result_parts.append(new_chunk[overlap:])

        return np.concatenate(result_parts, axis=0)

    def _refill_queue(
        self, observation_dict: Dict[str, Any], instruction: str
    ) -> None:
        """Refill the action queue by requesting a new chunk and blending."""
        new_chunk = self._request_chunk(observation_dict, instruction)

        if len(self._action_queue) > 0:
            old_remaining = np.array(list(self._action_queue))
            blended = self._blend_chunks(old_remaining, new_chunk)
            self._action_queue.clear()
            for action in blended:
                self._action_queue.append(action)
        else:
            for action in new_chunk:
                self._action_queue.append(action)

    def _action_array_to_dicts(self, actions: np.ndarray) -> List[Dict[str, Any]]:
        """Convert action array rows to action dictionaries."""
        result = []
        for action_row in actions:
            if self._robot_state_keys:
                action_dict = {}
                for i, key in enumerate(self._robot_state_keys):
                    if i < len(action_row):
                        action_dict[key] = float(action_row[i])
                result.append(action_dict)
            else:
                result.append({f"joint_{i}": float(v) for i, v in enumerate(action_row)})
        return result

    # ─── Policy ABC Implementation ──────────────────────────────────────

    async def get_actions(
        self,
        observation_dict: Dict[str, Any],
        instruction: str,
        **kwargs,
    ) -> List[Dict[str, Any]]:
        """Get actions from Neon VLA via the RTC action queue.

        Accepts all Neon modalities in the observation dict:

        Parameters
        ----------
        observation_dict : dict
            Robot observations. Recognized keys:

            **Camera** (any key with 3D+ ndarray or "image" in name):
            - "observation.images.front": (H, W, 3) uint8 → base64 PNG
            - "observation.images.wrist": additional cameras → video frames

            **Proprioception** (1D array, "state"/"joint" in key):
            - "observation.state": (17,) float32 joint positions

            **Audio** ("audio"/"voice" in key):
            - "observation.audio": (N,) float32 at 16kHz — voice command

            **LiDAR** ("lidar"/"point_cloud" in key):
            - "observation.lidar": (N, 4) float32 — x, y, z, intensity

            **EEF** ("eef"/"end_effector" in key):
            - "observation.eef_state": (14,) float32 — bimanual pos+quat

        instruction : str
            Natural language instruction or voice command text.

        Returns
        -------
        list[dict]
            Action dicts (length = actions_per_step), keyed by robot_state_keys.
        """
        if len(self._action_queue) <= self._refill_threshold:
            self._refill_queue(observation_dict, instruction)
            self._last_instruction = instruction

        actions_to_return = []
        for _ in range(self._actions_per_step):
            if self._action_queue:
                actions_to_return.append(self._action_queue.popleft())
            else:
                self._refill_queue(observation_dict, instruction)
                if self._action_queue:
                    actions_to_return.append(self._action_queue.popleft())
                else:
                    raise RuntimeError("Neon action queue empty after refill.")

        self._step += len(actions_to_return)
        return self._action_array_to_dicts(np.array(actions_to_return, dtype=np.float32))

    async def health_check(self) -> Dict[str, Any]:
        """Check Neon inference server health and discover supported modalities.

        Returns:
            Dict with server status, model info, latency, and modalities.
        """
        if self._protocol == "zmq":
            return {"status": "unknown", "protocol": "zmq"}
        self._ensure_http_session()
        url = f"http://{self._host}:{self._port}/health"
        try:
            start = time.time()
            response = self._session.get(url, timeout=self._timeout)
            latency = time.time() - start
            response.raise_for_status()
            result = response.json()
            result["latency_ms"] = round(latency * 1000, 1)
            # Cache modalities for observation validation
            if "modalities" in result:
                self._server_modalities = result["modalities"]
            return result
        except Exception as e:
            return {"status": "error", "error": str(e)}

    @property
    def server_modalities(self) -> Optional[Dict[str, bool]]:
        """Get cached server modalities (call health_check first)."""
        return self._server_modalities

    def close(self):
        """Clean up connections."""
        if self._session:
            self._session.close()
            self._session = None
        if self._zmq_socket:
            self._zmq_socket.close()
            self._zmq_socket = None

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def __repr__(self) -> str:
        mods = ""
        if self._server_modalities:
            enabled = [k for k, v in self._server_modalities.items() if v]
            mods = f", modalities=[{','.join(enabled)}]"
        return (
            f"NeonPolicy({self._protocol}://{self._host}:{self._port}, "
            f"blend={self._blend_schedule}, chunk={self._chunk_size}, "
            f"dim={self._action_dim}, queue={len(self._action_queue)}{mods})"
        )


def register_with_strands_robots():
    """Register NeonPolicy with strands-robots policy registry.

    Called automatically when neon is imported if strands-robots is installed.
    This makes ``create_policy("neon", ...)`` work out of the box.
    """
    try:
        from strands_robots.policies import register_policy
        register_policy(
            "neon",
            loader=lambda: NeonPolicy,
            aliases=["neon_g1", "neon_vla", "neon-g1"],
        )
        logger.info("🦾 Neon registered with strands-robots policy registry")
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f"Could not register with strands-robots: {e}")


# Auto-register on import
register_with_strands_robots()
