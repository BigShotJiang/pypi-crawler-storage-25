"""
LeRobot v3 Dataset Interface — Write and read Neon omni-modal datasets.

LeRobot v3.0 format:
    dataset/
    ├── data/
    │   └── chunk-000/
    │       └── 000000.parquet   (frames, chunked)
    ├── meta/
    │   ├── info.json
    │   ├── episodes.parquet
    │   ├── tasks.parquet
    │   └── stats.parquet
    └── videos/
        ├── observation.image.camera_head/
        │   └── chunk-000/
        │       └── 000000.mp4
        └── observation.image.camera_hand/
            └── ...

This module provides:
- NEON_G1_FEATURES: The canonical feature schema for Neon G1 datasets
- NeonLeRobotWriter: Records episodes from StreamSession channels → v3 dataset
- NeonLeRobotReader: Loads v3 datasets back into NeonEpisode for DataSoup
- Schema helpers for sim/real parity

All modalities:
- Camera (head + hand) → video
- Joint state (43-DOF) → float32 array
- EEF state (14-DOF bimanual pos+quat) → float32 array
- LiDAR point cloud (4096×4) → float32 2D array
- Audio waveform (2s @16kHz per frame) → float32 array
- Actions (43-DOF joints + 3-DOF locomotion) → float32 array
- Language instruction → string
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from neon.data.action_space import (
    G1_DATASET_JOINT_NAMES,
    ControlMode,
    G1ActionSpace,
)

logger = logging.getLogger(__name__)

# =============================================================================
# Neon G1 Feature Schema — LeRobot v3.0
# =============================================================================
#
# This is the canonical schema for all Neon G1 datasets (real + sim).
# Every recording session uses this exact feature dict so datasets are
# interchangeable regardless of source.
#
# Design decisions:
# - 43-DOF state (29 body + 14 hand) even in arms_only mode — zero-pad unused
# - LiDAR downsampled to 4096 points (from L1's 21,600) for training efficiency
# - Audio stored as 2-second windows per frame @16kHz = 32,000 samples
# - EEF state is bimanual: 7 per wrist (xyz + quat)
# - Actions include locomotion velocity (vx, vy, omega) appended after joints

# Audio samples per frame at training fps.
# At 4Hz training fps, each frame spans 0.25s, but we store 2s context windows
# for the Whisper encoder (which expects ≥1s input).
AUDIO_SAMPLES_PER_FRAME = 32000  # 2 seconds @ 16kHz

# LiDAR points per frame after downsampling
LIDAR_POINTS_PER_FRAME = 4096

# Point cloud dimensions: x, y, z, intensity
LIDAR_POINT_DIM = 4

# Full action dimension: 43 joints + 3 locomotion
FULL_ACTION_DIM = 46

# Full state dimension: 43 joints (29 body + 14 hand)
FULL_STATE_DIM = 43

# EEF state dimension: 7 per wrist × 2 wrists
EEF_DIM = 14

# GPS/IMU state dimension: lat, lon, alt, heading, pitch, roll
GPS_DIM = 6


def make_neon_features(
    image_height: int = 480,
    image_width: int = 640,
    include_hand_camera: bool = True,
    include_lidar: bool = True,
    include_audio: bool = True,
    include_eef: bool = True,
    include_gps: bool = False,
    include_depth: bool = False,
    include_segmentation: bool = False,
    include_tactile: bool = False,
    include_imu: bool = False,
    include_force: bool = False,
    depth_height: int = 480,
    depth_width: int = 640,
    seg_num_classes: int = 20,
    seg_height: int = 480,
    seg_width: int = 640,
    tactile_num_links: int = 14,
    tactile_ft_dim: int = 6,
    imu_dim: int = 9,
    force_dim: int = 6,
    state_dim: int = FULL_STATE_DIM,
    action_dim: int = FULL_ACTION_DIM,
) -> Dict[str, Dict]:
    """Build the LeRobot v3 features dict for a Neon G1 dataset.

    This is the single source of truth for the dataset schema.
    Both the writer and reader use this to ensure consistency.

    Args:
        image_height: Camera frame height (default 480)
        image_width: Camera frame width (default 640)
        include_hand_camera: Include hand-mounted camera
        include_lidar: Include LiDAR point cloud feature
        include_audio: Include audio waveform feature
        include_eef: Include end-effector state feature
        include_gps: Include GPS/IMU state feature (6-DOF)
        include_depth: Include monocular depth map feature
        include_segmentation: Include semantic segmentation mask feature
        depth_height: Depth map height (default same as camera)
        depth_width: Depth map width (default same as camera)
        seg_num_classes: Number of segmentation classes (default 20)
        seg_height: Segmentation mask height (default same as camera)
        seg_width: Segmentation mask width (default same as camera)
        state_dim: Joint state dimension (default 43)
        action_dim: Action dimension (default 46 = 43 joints + 3 loco)

    Returns:
        Dict of feature specifications compatible with LeRobot v3
    """
    features = {}

    # --- Visual modalities (stored as video) ---
    features["observation.image.camera_head"] = {
        "dtype": "video",
        "shape": (image_height, image_width, 3),
        "names": ["height", "width", "channels"],
    }

    if include_hand_camera:
        features["observation.image.camera_hand"] = {
            "dtype": "video",
            "shape": (image_height, image_width, 3),
            "names": ["height", "width", "channels"],
        }

    # --- Proprioception ---
    features["observation.state"] = {
        "dtype": "float32",
        "shape": (state_dim,),
        "names": G1_DATASET_JOINT_NAMES[:state_dim],
    }

    # --- End-effector state (bimanual pos + quat) ---
    if include_eef:
        features["observation.eef_state"] = {
            "dtype": "float32",
            "shape": (EEF_DIM,),
            "names": [
                "left_x", "left_y", "left_z",
                "left_qx", "left_qy", "left_qz", "left_qw",
                "right_x", "right_y", "right_z",
                "right_qx", "right_qy", "right_qz", "right_qw",
            ],
        }

    # --- LiDAR point cloud ---
    if include_lidar:
        features["observation.lidar"] = {
            "dtype": "float32",
            "shape": (LIDAR_POINTS_PER_FRAME, LIDAR_POINT_DIM),
            "names": None,
        }

    # --- Audio waveform ---
    if include_audio:
        features["observation.audio"] = {
            "dtype": "float32",
            "shape": (AUDIO_SAMPLES_PER_FRAME,),
            "names": None,
        }

    # --- GPS/IMU state ---
    if include_gps:
        features["observation.gps"] = {
            "dtype": "float32",
            "shape": (GPS_DIM,),
            "names": ["latitude", "longitude", "altitude", "heading", "pitch", "roll"],
        }

    # --- Depth map (single-channel, meters) ---
    if include_depth:
        features["observation.depth.camera_head"] = {
            "dtype": "float32",
            "shape": (depth_height, depth_width),
            "names": ["height", "width"],
        }

    # --- Segmentation mask (per-pixel class index) ---
    if include_segmentation:
        features["observation.segmentation.camera_head"] = {
            "dtype": "uint8",
            "shape": (seg_height, seg_width),
            "names": ["height", "width"],
        }

    # --- Tactile sensors (NEW — finger force/torque) ---
    if include_tactile:
        features["observation.tactile"] = {
            "dtype": "float32",
            "shape": (tactile_num_links, tactile_ft_dim),
            "names": ["link", "force_torque"],
        }

    # --- IMU (NEW — accelerometer + gyroscope + magnetometer) ---
    if include_imu:
        features["observation.imu"] = {
            "dtype": "float32",
            "shape": (imu_dim,),
            "names": ["accel_x", "accel_y", "accel_z", "gyro_x", "gyro_y", "gyro_z", "mag_x", "mag_y", "mag_z"][:imu_dim],
        }

    # --- Wrist force/torque (NEW) ---
    if include_force:
        features["observation.force"] = {
            "dtype": "float32",
            "shape": (force_dim,),
            "names": ["fx", "fy", "fz", "tx", "ty", "tz"][:force_dim],
        }

    # --- Actions ---
    features["action"] = {
        "dtype": "float32",
        "shape": (action_dim,),
        "names": None,
    }

    # --- EEF actions (delta or absolute) ---
    if include_eef:
        features["action.eef"] = {
            "dtype": "float32",
            "shape": (EEF_DIM,),
            "names": None,
        }

    # --- Language instruction ---
    features["language_instruction"] = {
        "dtype": "string",
        "shape": (1,),
        "names": None,
    }

    return features


# Pre-built canonical schema (all modalities)
NEON_G1_FEATURES = make_neon_features()

# Full omni-modal schema (all 12+ modalities including GPS, depth, segmentation, tactile, IMU, force)
NEON_G1_FEATURES_OMNI = make_neon_features(
    include_gps=True,
    include_depth=True,
    include_segmentation=True,
    include_tactile=True,
    include_imu=True,
    include_force=True,
)

# Minimal schema (vision + proprio + actions only — for sim bootstrap)
NEON_G1_FEATURES_MINIMAL = make_neon_features(
    include_hand_camera=False,
    include_lidar=False,
    include_audio=False,
    include_eef=False,
)


# =============================================================================
# Writer — Records NeonEpisodes to LeRobot v3 datasets
# =============================================================================


@dataclass
class NeonWriterConfig:
    """Configuration for the Neon LeRobot v3 writer."""

    repo_id: str  # e.g. "cagataydev/neon-g1-kitchen-v1"
    root: Optional[str] = None  # Local path (default: HF cache)
    fps: int = 20  # Recording/training fps
    robot_type: str = "unitree_g1"
    use_videos: bool = True
    features: Optional[Dict] = None  # Override features (default: NEON_G1_FEATURES)
    push_to_hub: bool = True
    private: bool = True
    # Video encoding
    vcodec: str = "libsvtav1"  # AV1 (LeRobot default) — fallback to libx264
    # Source metadata
    source: str = "real"  # "real" or "sim"
    sim_engine: str = ""  # "mujoco", "isaac", etc.


class NeonLeRobotWriter:
    """Writes Neon omni-modal episodes to LeRobot v3 format.

    Usage (standalone):
        writer = NeonLeRobotWriter(NeonWriterConfig(
            repo_id="cagataydev/neon-g1-kitchen-v1",
            fps=20,
        ))

        # Record an episode
        writer.start_episode(task="pick up the red cup")
        for frame in sensor_stream:
            writer.add_frame(
                image_head=frame.camera_head,  # (H,W,3) uint8
                image_hand=frame.camera_hand,
                state=frame.joint_positions,    # (43,) float32
                action=frame.joint_targets,     # (46,) float32
                eef_state=frame.eef_state,      # (14,) float32
                lidar=frame.lidar_points,       # (4096,4) float32
                audio=frame.audio_chunk,        # (32000,) float32
                language="pick up the red cup",
            )
        writer.end_episode()

        # Push to HuggingFace
        writer.save_and_push()

    Usage (from StreamSession channels):
        writer = NeonLeRobotWriter.from_channels(
            channels=session._all_channels,
            config=NeonWriterConfig(repo_id="cagataydev/neon-g1-data"),
        )
    """

    def __init__(self, config: NeonWriterConfig):
        self.config = config
        self._dataset = None
        self._episode_count = 0
        self._frame_count = 0
        self._current_task = ""

        # Resolve features
        self._features = config.features or NEON_G1_FEATURES

        # Lazy import to avoid hard dependency
        self._lerobot_available = self._check_lerobot()

    def _check_lerobot(self) -> bool:
        """Check if lerobot is importable."""
        try:
            from lerobot.datasets.lerobot_dataset import LeRobotDataset  # noqa: F401
            return True
        except ImportError:
            logger.warning(
                "lerobot not installed. Install with: pip install lerobot\n"
                "Writer will use fallback parquet format."
            )
            return False

    def open(self):
        """Initialize the dataset for writing."""
        if self._lerobot_available:
            self._open_lerobot()
        else:
            self._open_fallback()

        logger.info(
            f"NeonLeRobotWriter opened: {self.config.repo_id} "
            f"(fps={self.config.fps}, source={self.config.source})"
        )

    def _open_lerobot(self):
        """Open using native LeRobot v3 API."""
        from lerobot.datasets.lerobot_dataset import LeRobotDataset

        self._dataset = LeRobotDataset.create(
            repo_id=self.config.repo_id,
            fps=self.config.fps,
            features=self._features,
            root=self.config.root,
            robot_type=self.config.robot_type,
            use_videos=self.config.use_videos,
            vcodec=self.config.vcodec,
        )
        logger.info("Opened LeRobot v3 dataset (native API)")

    def _open_fallback(self):
        """Open using fallback parquet-based format (no lerobot dependency)."""
        root = Path(self.config.root or f"./neon_datasets/{self.config.repo_id.split('/')[-1]}")
        root.mkdir(parents=True, exist_ok=True)
        (root / "data" / "chunk-000").mkdir(parents=True, exist_ok=True)
        (root / "meta").mkdir(parents=True, exist_ok=True)
        (root / "videos").mkdir(parents=True, exist_ok=True)

        self._fallback_root = root
        self._fallback_frames: List[Dict] = []
        self._fallback_episodes: List[Dict] = []
        self._fallback_tasks: Dict[str, int] = {}
        logger.info(f"Opened fallback dataset at {root}")

    def start_episode(self, task: str = ""):
        """Begin recording a new episode.

        Args:
            task: Language description of the task
        """
        self._current_task = task
        self._frame_count = 0

        if self._lerobot_available and self._dataset is not None:
            self._dataset.episode_buffer = self._dataset.create_episode_buffer()

        logger.debug(f"Episode {self._episode_count} started: '{task}'")

    def add_frame(
        self,
        image_head: Optional[np.ndarray] = None,
        image_hand: Optional[np.ndarray] = None,
        state: Optional[np.ndarray] = None,
        action: Optional[np.ndarray] = None,
        eef_state: Optional[np.ndarray] = None,
        action_eef: Optional[np.ndarray] = None,
        lidar: Optional[np.ndarray] = None,
        audio: Optional[np.ndarray] = None,
        gps: Optional[np.ndarray] = None,
        depth: Optional[np.ndarray] = None,
        segmentation: Optional[np.ndarray] = None,
        tactile: Optional[np.ndarray] = None,
        imu: Optional[np.ndarray] = None,
        force: Optional[np.ndarray] = None,
        language: Optional[str] = None,
        timestamp: Optional[float] = None,
    ):
        """Add a single frame to the current episode.

        All arrays are optional — missing modalities are zero-filled.
        This allows recording from incomplete sensor setups (e.g., no LiDAR in sim).

        Args:
            image_head: Head camera frame (H, W, 3) uint8
            image_hand: Hand camera frame (H, W, 3) uint8
            state: Joint positions (43,) float32
            action: Joint targets + locomotion (46,) float32
            eef_state: End-effector state (14,) float32
            action_eef: End-effector action targets (14,) float32
            lidar: Point cloud (N, 4) float32 — auto-resampled to 4096
            audio: Audio waveform (S,) float32 — auto-padded/trimmed to 32000
            gps: GPS/IMU state (6,) float32 [lat, lon, alt, heading, pitch, roll]
            depth: Depth map (H, W) float32 in meters
            segmentation: Segmentation mask (H, W) uint8 class indices
            tactile: Finger force/torque (14, 6) float32
            imu: IMU readings (9,) float32 [accel(3) + gyro(3) + mag(3)]
            force: Wrist force/torque (6,) float32 [fx, fy, fz, tx, ty, tz]
            language: Language instruction string
            timestamp: Frame timestamp (default: auto from frame index)
        """
        frame = {}

        # --- Images ---
        if image_head is not None:
            frame["observation.image.camera_head"] = image_head
        elif "observation.image.camera_head" in self._features:
            h, w = self._features["observation.image.camera_head"]["shape"][:2]
            frame["observation.image.camera_head"] = np.zeros((h, w, 3), dtype=np.uint8)

        if image_hand is not None and "observation.image.camera_hand" in self._features:
            frame["observation.image.camera_hand"] = image_hand
        elif "observation.image.camera_hand" in self._features:
            h, w = self._features["observation.image.camera_hand"]["shape"][:2]
            frame["observation.image.camera_hand"] = np.zeros((h, w, 3), dtype=np.uint8)

        # --- State ---
        if "observation.state" in self._features:
            dim = self._features["observation.state"]["shape"][0]
            if state is not None:
                s = np.zeros(dim, dtype=np.float32)
                s[:min(len(state), dim)] = state[:dim]
                frame["observation.state"] = s
            else:
                frame["observation.state"] = np.zeros(dim, dtype=np.float32)

        # --- EEF State ---
        if "observation.eef_state" in self._features:
            if eef_state is not None:
                e = np.zeros(EEF_DIM, dtype=np.float32)
                e[:min(len(eef_state), EEF_DIM)] = eef_state[:EEF_DIM]
                frame["observation.eef_state"] = e
            else:
                frame["observation.eef_state"] = np.zeros(EEF_DIM, dtype=np.float32)

        # --- LiDAR ---
        if "observation.lidar" in self._features:
            if lidar is not None:
                frame["observation.lidar"] = self._resample_lidar(lidar)
            else:
                frame["observation.lidar"] = np.zeros(
                    (LIDAR_POINTS_PER_FRAME, LIDAR_POINT_DIM), dtype=np.float32
                )

        # --- Audio ---
        if "observation.audio" in self._features:
            if audio is not None:
                frame["observation.audio"] = self._pad_or_trim_audio(audio)
            else:
                frame["observation.audio"] = np.zeros(AUDIO_SAMPLES_PER_FRAME, dtype=np.float32)

        # --- GPS ---
        if "observation.gps" in self._features:
            if gps is not None:
                g = np.zeros(GPS_DIM, dtype=np.float32)
                g[:min(len(gps), GPS_DIM)] = gps[:GPS_DIM]
                frame["observation.gps"] = g
            else:
                frame["observation.gps"] = np.zeros(GPS_DIM, dtype=np.float32)

        # --- Depth ---
        if "observation.depth.camera_head" in self._features:
            if depth is not None:
                frame["observation.depth.camera_head"] = depth.astype(np.float32)
            else:
                h, w = self._features["observation.depth.camera_head"]["shape"]
                frame["observation.depth.camera_head"] = np.zeros((h, w), dtype=np.float32)

        # --- Segmentation ---
        if "observation.segmentation.camera_head" in self._features:
            if segmentation is not None:
                frame["observation.segmentation.camera_head"] = segmentation.astype(np.uint8)
            else:
                h, w = self._features["observation.segmentation.camera_head"]["shape"]
                frame["observation.segmentation.camera_head"] = np.zeros((h, w), dtype=np.uint8)

        # --- Tactile (NEW) ---
        if "observation.tactile" in self._features:
            shape = self._features["observation.tactile"]["shape"]
            if tactile is not None:
                t = np.zeros(shape, dtype=np.float32)
                t[:min(tactile.shape[0], shape[0]), :min(tactile.shape[1], shape[1])] = (
                    tactile[:shape[0], :shape[1]]
                )
                frame["observation.tactile"] = t
            else:
                frame["observation.tactile"] = np.zeros(shape, dtype=np.float32)

        # --- IMU (NEW) ---
        if "observation.imu" in self._features:
            dim = self._features["observation.imu"]["shape"][0]
            if imu is not None:
                v = np.zeros(dim, dtype=np.float32)
                v[:min(len(imu), dim)] = imu[:dim]
                frame["observation.imu"] = v
            else:
                frame["observation.imu"] = np.zeros(dim, dtype=np.float32)

        # --- Force (NEW) ---
        if "observation.force" in self._features:
            dim = self._features["observation.force"]["shape"][0]
            if force is not None:
                v = np.zeros(dim, dtype=np.float32)
                v[:min(len(force), dim)] = force[:dim]
                frame["observation.force"] = v
            else:
                frame["observation.force"] = np.zeros(dim, dtype=np.float32)

        # --- Action ---
        if "action" in self._features:
            dim = self._features["action"]["shape"][0]
            if action is not None:
                a = np.zeros(dim, dtype=np.float32)
                a[:min(len(action), dim)] = action[:dim]
                frame["action"] = a
            else:
                frame["action"] = np.zeros(dim, dtype=np.float32)

        # --- Action EEF ---
        if "action.eef" in self._features:
            if action_eef is not None:
                ae = np.zeros(EEF_DIM, dtype=np.float32)
                ae[:min(len(action_eef), EEF_DIM)] = action_eef[:EEF_DIM]
                frame["action.eef"] = ae
            else:
                frame["action.eef"] = np.zeros(EEF_DIM, dtype=np.float32)

        # --- Language ---
        if "language_instruction" in self._features:
            frame["language_instruction"] = language or self._current_task or ""

        # --- Timestamp ---
        if timestamp is not None:
            frame["timestamp"] = timestamp

        # Write frame
        if self._lerobot_available and self._dataset is not None:
            self._dataset.add_frame(frame)
        else:
            # Fallback: accumulate in memory
            frame["episode_index"] = self._episode_count
            frame["frame_index"] = self._frame_count
            frame["timestamp"] = timestamp or (self._frame_count / self.config.fps)
            self._fallback_frames.append(frame)

        self._frame_count += 1

    def end_episode(self):
        """Finalize the current episode."""
        if self._frame_count == 0:
            logger.warning("Empty episode — skipping")
            return

        if self._lerobot_available and self._dataset is not None:
            self._dataset.save_episode(task=self._current_task)
        else:
            # Fallback: record episode metadata
            if self._current_task not in self._fallback_tasks:
                self._fallback_tasks[self._current_task] = len(self._fallback_tasks)

            self._fallback_episodes.append({
                "episode_index": self._episode_count,
                "task": self._current_task,
                "task_index": self._fallback_tasks[self._current_task],
                "length": self._frame_count,
            })

        logger.info(
            f"Episode {self._episode_count} saved: "
            f"{self._frame_count} frames, task='{self._current_task}'"
        )
        self._episode_count += 1
        self._frame_count = 0

    def save_and_push(self):
        """Save dataset and optionally push to HuggingFace Hub."""
        if self._lerobot_available and self._dataset is not None:
            # Consolidate dataset
            self._dataset.consolidate(run_compute_stats=True)
            logger.info(f"Dataset consolidated: {self._episode_count} episodes")

            if self.config.push_to_hub:
                self._dataset.push_to_hub(
                    tags=["neon", "g1", "unitree", "omni-modal", self.config.source],
                    private=self.config.private,
                    license="mit",
                )
                logger.info(f"Pushed to HuggingFace: {self.config.repo_id}")
        else:
            self._save_fallback()
            if self.config.push_to_hub:
                self._push_fallback()

    def _save_fallback(self):
        """Save using fallback parquet format."""
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
        except ImportError:
            logger.error("pyarrow required for fallback save: pip install pyarrow")
            return

        root = self._fallback_root

        # Build per-frame records (flatten arrays to lists for parquet)
        records = []
        for frame in self._fallback_frames:
            record = {}
            for key, val in frame.items():
                if isinstance(val, np.ndarray):
                    if val.ndim == 1:
                        record[key] = val.tolist()
                    elif val.ndim == 2:
                        # Store 2D arrays as flat list (row-major)
                        record[key] = val.flatten().tolist()
                    else:
                        # Skip images for parquet (they go in videos/)
                        continue
                else:
                    record[key] = val
            records.append(record)

        if records:
            table = pa.Table.from_pylist(records)
            pq.write_table(
                table,
                root / "data" / "chunk-000" / "000000.parquet",
            )
            logger.info(f"Saved {len(records)} frames to parquet")

        # Save metadata
        info = {
            "codebase_version": "v3.0",
            "robot_type": self.config.robot_type,
            "fps": self.config.fps,
            "total_episodes": self._episode_count,
            "total_frames": len(self._fallback_frames),
            "features": self._features,
            "source": self.config.source,
            "sim_engine": self.config.sim_engine,
        }
        with open(root / "meta" / "info.json", "w") as f:
            json.dump(info, f, indent=2)

        # Save episodes
        if self._fallback_episodes:
            ep_table = pa.Table.from_pylist(self._fallback_episodes)
            pq.write_table(ep_table, root / "meta" / "episodes.parquet")

        # Save tasks
        if self._fallback_tasks:
            tasks_list = [
                {"task_index": idx, "task": task}
                for task, idx in self._fallback_tasks.items()
            ]
            tasks_table = pa.Table.from_pylist(tasks_list)
            pq.write_table(tasks_table, root / "meta" / "tasks.parquet")

        logger.info(f"Fallback dataset saved to {root}")

    def _push_fallback(self):
        """Push fallback dataset to HuggingFace Hub."""
        try:
            from huggingface_hub import HfApi

            api = HfApi()
            api.create_repo(
                self.config.repo_id,
                repo_type="dataset",
                private=self.config.private,
                exist_ok=True,
            )
            api.upload_folder(
                folder_path=str(self._fallback_root),
                repo_id=self.config.repo_id,
                repo_type="dataset",
            )
            logger.info(f"Fallback dataset pushed to HF: {self.config.repo_id}")
        except Exception as e:
            logger.error(f"Failed to push to HF: {e}")

    @staticmethod
    def _resample_lidar(points: np.ndarray) -> np.ndarray:
        """Resample point cloud to fixed size.

        Args:
            points: (N, 3) or (N, 4) point cloud

        Returns:
            (LIDAR_POINTS_PER_FRAME, 4) resampled with intensity
        """
        target = LIDAR_POINTS_PER_FRAME

        # Ensure 4 columns (x, y, z, intensity)
        if points.ndim == 1:
            points = points.reshape(-1, LIDAR_POINT_DIM)
        if points.shape[1] == 3:
            intensity = np.ones((len(points), 1), dtype=np.float32)
            points = np.hstack([points.astype(np.float32), intensity])

        n = len(points)
        if n == 0:
            return np.zeros((target, LIDAR_POINT_DIM), dtype=np.float32)
        elif n == target:
            return points.astype(np.float32)
        elif n > target:
            # Random subsample
            idx = np.random.choice(n, target, replace=False)
            return points[idx].astype(np.float32)
        else:
            # Zero-pad
            padded = np.zeros((target, LIDAR_POINT_DIM), dtype=np.float32)
            padded[:n] = points[:, :LIDAR_POINT_DIM].astype(np.float32)
            return padded

    @staticmethod
    def _pad_or_trim_audio(audio: np.ndarray) -> np.ndarray:
        """Pad or trim audio to fixed length.

        Args:
            audio: (S,) float32 audio samples

        Returns:
            (AUDIO_SAMPLES_PER_FRAME,) padded/trimmed
        """
        target = AUDIO_SAMPLES_PER_FRAME
        audio = audio.astype(np.float32).flatten()

        if len(audio) == target:
            return audio
        elif len(audio) > target:
            # Take the most recent samples
            return audio[-target:]
        else:
            # Zero-pad at the beginning (silence before speech)
            padded = np.zeros(target, dtype=np.float32)
            padded[-len(audio):] = audio
            return padded


# =============================================================================
# Reader — Loads LeRobot v3 datasets back into NeonEpisode format
# =============================================================================


class NeonLeRobotReader:
    """Reads a LeRobot v3 dataset and yields NeonEpisodes for DataSoup.

    This bridges LeRobot v3 → Neon's training pipeline.

    Usage:
        reader = NeonLeRobotReader("cagataydev/neon-g1-kitchen-v1")
        episodes = reader.load_episodes(max_episodes=100)
        # episodes is List[NeonEpisode] with all modalities populated
    """

    def __init__(
        self,
        repo_id_or_path: str,
        revision: str = "v3.0",
        action_space: Optional[G1ActionSpace] = None,
    ):
        """Initialize reader.

        Args:
            repo_id_or_path: HuggingFace dataset ID or local path
            revision: Dataset revision (default: v3.0)
            action_space: Target action space for mapping (default: whole_body_hands)
        """
        self.repo_id = repo_id_or_path
        self.revision = revision
        self.action_space = action_space or G1ActionSpace(
            mode=ControlMode.WHOLE_BODY_HANDS,
            include_locomotion=True,
        )

        self._dataset = None
        self._meta = None

    def load_episodes(
        self,
        max_episodes: Optional[int] = None,
        fps: Optional[int] = None,
    ) -> list:
        """Load episodes from the dataset.

        Args:
            max_episodes: Limit number of episodes
            fps: Target fps for downsampling (None = use dataset fps)

        Returns:
            List of NeonEpisode objects with all available modalities
        """

        # Try native LeRobot first, fall back to manual loading
        episodes = []

        try:
            episodes = self._load_via_lerobot(max_episodes, fps)
        except ImportError:
            logger.info("lerobot not available, using manual loader")
            episodes = self._load_manual(max_episodes, fps)
        except Exception as e:
            logger.warning(f"LeRobot native load failed: {e}, trying manual")
            episodes = self._load_manual(max_episodes, fps)

        logger.info(
            f"Loaded {len(episodes)} episodes from {self.repo_id} "
            f"({sum(ep.length for ep in episodes)} total frames)"
        )
        return episodes

    def _load_via_lerobot(self, max_episodes, fps):
        """Load using native LeRobot API."""
        from lerobot.datasets.lerobot_dataset import LeRobotDataset

        from neon.data.data_soup import NeonEpisode

        ds = LeRobotDataset(self.repo_id, revision=self.revision)
        features = ds.features
        dataset_fps = ds.fps

        # Determine downsample ratio
        step = max(1, dataset_fps // fps) if fps else 1

        episodes = []
        episode_indices = list(range(ds.num_episodes))
        if max_episodes:
            episode_indices = episode_indices[:max_episodes]

        for ep_idx in episode_indices:
            ep_data = ds.hf_dataset.filter(lambda x: x["episode_index"] == ep_idx)

            if len(ep_data) == 0:
                continue

            # Extract all modalities
            images = []
            actions_list = []
            states_list = []
            eef_list = []
            lidar_list = []
            audio_list = []
            language = ""

            for i in range(0, len(ep_data), step):
                row = ep_data[i]

                # Actions
                if "action" in row:
                    a = np.array(row["action"], dtype=np.float32)
                    actions_list.append(a)

                # State
                if "observation.state" in row:
                    s = np.array(row["observation.state"], dtype=np.float32)
                    states_list.append(s)

                # EEF
                if "observation.eef_state" in row:
                    e = np.array(row["observation.eef_state"], dtype=np.float32)
                    eef_list.append(e)

                # LiDAR
                if "observation.lidar" in row:
                    pts = np.array(row["observation.lidar"], dtype=np.float32)
                    if pts.ndim == 1:
                        pts = pts.reshape(-1, LIDAR_POINT_DIM)
                    lidar_list.append(pts)

                # Audio
                if "observation.audio" in row:
                    aud = np.array(row["observation.audio"], dtype=np.float32)
                    audio_list.append(aud)

                # Language (take first non-empty)
                if not language and "language_instruction" in row:
                    lang = row["language_instruction"]
                    if isinstance(lang, str) and lang.strip():
                        language = lang.strip()

            if not actions_list:
                continue

            len(actions_list)

            # Build NeonEpisode
            episode = NeonEpisode(
                images=images,  # Video frames loaded lazily by LeRobot
                actions=np.stack(actions_list),
                language=language,
                proprioception=np.stack(states_list) if states_list else None,
                audio=np.stack(audio_list) if audio_list else None,
                lidar=np.stack(lidar_list) if lidar_list else None,
                eef_state=np.stack(eef_list) if eef_list else None,
                metadata={
                    "source": "neon_v3",
                    "repo_id": self.repo_id,
                    "episode_index": ep_idx,
                    "original_fps": dataset_fps,
                    "downsampled_fps": fps or dataset_fps,
                    "has_lidar": len(lidar_list) > 0,
                    "has_audio": len(audio_list) > 0,
                    "has_eef": len(eef_list) > 0,
                    "modalities": self._detect_modalities(features),
                },
            )
            episodes.append(episode)

        return episodes

    def _load_manual(self, max_episodes, fps):
        """Load manually from parquet files (no lerobot dependency)."""
        from pathlib import Path

        from neon.data.data_soup import NeonEpisode

        # Determine path
        path = Path(self.repo_id)
        if not path.exists():
            # Download from HuggingFace
            try:
                from huggingface_hub import snapshot_download
                path = Path(snapshot_download(
                    self.repo_id,
                    repo_type="dataset",
                    revision=self.revision,
                    allow_patterns=["meta/*", "data/*"],
                ))
            except Exception as e:
                logger.error(f"Failed to download {self.repo_id}: {e}")
                return []

        # Load metadata
        info_path = path / "meta" / "info.json"
        if not info_path.exists():
            logger.error(f"No info.json found in {path}")
            return []

        with open(info_path) as f:
            info = json.load(f)

        dataset_fps = info.get("fps", 20)
        info.get("features", {})
        step = max(1, dataset_fps // fps) if fps else 1

        # Load tasks
        tasks_map = {}
        tasks_path = path / "meta" / "tasks.parquet"
        if tasks_path.exists():
            try:
                import pyarrow.parquet as pq
                tasks_table = pq.read_table(tasks_path)
                tasks_df = tasks_table.to_pandas()
                for _, row in tasks_df.iterrows():
                    tasks_map[int(row["task_index"])] = row["task"]
            except Exception:
                pass

        # Load parquet data files
        episodes = []
        data_dir = path / "data"
        parquet_files = sorted(data_dir.rglob("*.parquet"))

        if not parquet_files:
            logger.warning(f"No parquet files found in {data_dir}")
            return []

        try:
            import pyarrow.parquet as pq
        except ImportError:
            logger.error("pyarrow required: pip install pyarrow")
            return []

        # Read all data
        for pq_file in parquet_files:
            try:
                table = pq.read_table(pq_file)
                df = table.to_pandas()
            except Exception as e:
                logger.warning(f"Failed to read {pq_file}: {e}")
                continue

            if "episode_index" not in df.columns:
                continue

            # Group by episode
            for ep_idx, ep_df in df.groupby("episode_index"):
                if max_episodes and len(episodes) >= max_episodes:
                    break

                ep_df = ep_df.sort_values("frame_index").iloc[::step]
                T = len(ep_df)
                if T < 2:
                    continue

                # Extract modalities
                actions = self._extract_array(ep_df, "action")
                states = self._extract_array(ep_df, "observation.state")
                eef = self._extract_array(ep_df, "observation.eef_state")
                lidar_data = self._extract_2d_array(ep_df, "observation.lidar", LIDAR_POINTS_PER_FRAME, LIDAR_POINT_DIM)
                audio_data = self._extract_array(ep_df, "observation.audio")

                # Language
                language = ""
                if "task_index" in ep_df.columns:
                    task_idx = int(ep_df["task_index"].iloc[0])
                    language = tasks_map.get(task_idx, "")
                if not language and "language_instruction" in ep_df.columns:
                    lang_vals = ep_df["language_instruction"].dropna()
                    if len(lang_vals) > 0:
                        language = str(lang_vals.iloc[0])

                if actions is None:
                    continue

                episode = NeonEpisode(
                    images=[],
                    actions=actions,
                    language=language,
                    proprioception=states,
                    audio=audio_data,
                    lidar=lidar_data,
                    eef_state=eef,
                    metadata={
                        "source": "neon_v3",
                        "repo_id": self.repo_id,
                        "episode_index": int(ep_idx),
                        "original_fps": dataset_fps,
                        "has_lidar": lidar_data is not None,
                        "has_audio": audio_data is not None,
                        "has_eef": eef is not None,
                    },
                )
                episodes.append(episode)

            if max_episodes and len(episodes) >= max_episodes:
                break

        return episodes

    @staticmethod
    def _extract_array(df, column: str) -> Optional[np.ndarray]:
        """Extract a 1D array column from a dataframe."""
        if column not in df.columns:
            return None
        try:
            vals = df[column].tolist()
            if isinstance(vals[0], (list, np.ndarray)):
                return np.array(vals, dtype=np.float32)
            else:
                return np.array(vals, dtype=np.float32).reshape(-1, 1)
        except Exception:
            return None

    @staticmethod
    def _extract_2d_array(
        df, column: str, rows: int, cols: int
    ) -> Optional[np.ndarray]:
        """Extract a 2D array column stored as flat list."""
        if column not in df.columns:
            return None
        try:
            vals = df[column].tolist()
            flat = np.array(vals, dtype=np.float32)
            if flat.ndim == 1:
                # Stored as flat — reshape
                T = len(df)
                expected = T * rows * cols
                if len(flat) == expected:
                    return flat.reshape(T, rows, cols)
            elif flat.ndim == 2 and flat.shape[1] == rows * cols:
                return flat.reshape(-1, rows, cols)
            elif flat.ndim == 3:
                return flat
            return None
        except Exception:
            return None

    @staticmethod
    def _detect_modalities(features: dict) -> List[str]:
        """Detect which modalities are present in the features."""
        modalities = []
        for key in features:
            if "image" in key or "video" in key:
                modalities.append("vision")
            elif "state" in key and "eef" not in key:
                modalities.append("proprioception")
            elif "eef" in key:
                modalities.append("eef")
            elif "lidar" in key:
                modalities.append("lidar")
            elif "audio" in key:
                modalities.append("audio")
            elif "gps" in key:
                modalities.append("gps")
            elif "depth" in key:
                modalities.append("depth")
            elif "segmentation" in key:
                modalities.append("segmentation")
            elif "action" in key:
                modalities.append("action")
            elif "language" in key or "instruction" in key:
                modalities.append("language")
        return list(set(modalities))


# =============================================================================
# Channel-to-Writer Bridge — Connects StreamSession channels to the writer
# =============================================================================


def channels_to_frame(
    joint_sample=None,
    camera_sample=None,
    lidar_sample=None,
    audio_samples=None,
    text_sample=None,
    eef_state=None,
    action=None,
    action_eef=None,
) -> Dict[str, Any]:
    """Convert channel samples into a frame dict for NeonLeRobotWriter.

    This bridges the real-time streaming channels to the dataset writer.
    Called once per training-fps tick to snapshot all channels.

    Args:
        joint_sample: Latest sample from JointChannel
        camera_sample: Latest sample from CameraChannel
        lidar_sample: Latest sample from LidarChannel
        audio_samples: Recent samples from AudioChannel (2s window)
        text_sample: Latest instruction from TextChannel
        eef_state: End-effector state (14,) — computed from FK or direct sensor
        action: Action target (46,) — from teleop or VLA prediction
        action_eef: EEF action target (14,)

    Returns:
        Dict ready for writer.add_frame(**frame)
    """
    frame = {}

    # Camera
    if camera_sample is not None:
        left = camera_sample.data.get("left")
        if left is not None:
            frame["image_head"] = np.asarray(left, dtype=np.uint8)
        right = camera_sample.data.get("right")
        if right is not None:
            frame["image_hand"] = np.asarray(right, dtype=np.uint8)

    # Joints
    if joint_sample is not None:
        positions = joint_sample.data[:FULL_STATE_DIM]
        frame["state"] = positions.astype(np.float32)

    # LiDAR
    if lidar_sample is not None:
        frame["lidar"] = lidar_sample.data.astype(np.float32)

    # Audio (concatenate 2s window)
    if audio_samples:
        input_chunks = [
            s.data["samples"]
            for s in audio_samples
            if s.data.get("direction") == "input"
        ]
        if input_chunks:
            frame["audio"] = np.concatenate(input_chunks).astype(np.float32)

    # Text
    if text_sample is not None:
        frame["language"] = text_sample.data.get("text", "")

    # EEF
    if eef_state is not None:
        frame["eef_state"] = np.asarray(eef_state, dtype=np.float32)

    # Action
    if action is not None:
        frame["action"] = np.asarray(action, dtype=np.float32)
    if action_eef is not None:
        frame["action_eef"] = np.asarray(action_eef, dtype=np.float32)

    return frame
