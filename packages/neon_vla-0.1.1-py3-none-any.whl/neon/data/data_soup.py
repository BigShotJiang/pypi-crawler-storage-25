"""
Data Soup — Multi-source dataset mixing for VLA training.

Implements the data soup approach from XVLA/Agibot-World:
mix multiple datasets with configurable ratios for robust training.

Supported sources:
- AgiBotWorld-Beta (native H5 format, 1M+ bimanual trajectories)
- LeRobot datasets (HuggingFace)
- GR00T-Dreams synthetic data
- Custom G1 teleoperation data (S3/local, LeRobot v2.1)
- Open X-Embodiment (OXE)
- Voice commands (text instructions for language conditioning)
- Stereo4D (stereo video pairs for visual pretraining / depth)
- Cosmos DreamGen (world model synthetic data with relative actions)

Cross-embodiment mapping:
- AgiBotWorld (GO-1): 16-DOF → G1 14-DOF arms via agibot_go1 mapping
  with automatic denormalization using GO-1 dataset_stats.json
- Franka: 7-DOF + gripper → G1 right arm
- SO-100: 6-DOF + gripper → G1 right arm
- G1 teleop: 43-DOF native → identity mapping
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from torch.utils.data import Dataset, WeightedRandomSampler

from neon.data.action_space import G1ActionSpace

logger = logging.getLogger(__name__)


@dataclass
class DataSourceConfig:
    """Configuration for a single data source."""

    name: str
    type: str  # "lerobot", "agibot_world"/"agibot", "dreamgen", "custom", "oxe", "voice_commands", "stereo4d", "cosmos_dreamgen", "g1_teleop", "groot_teleop", "neon_v3", "bones_seed", "kimodo", "molmobot", "tribev2_fmri"
    path: str  # HuggingFace dataset ID or local path
    weight: float = 1.0  # Sampling weight in the mixture
    max_episodes: Optional[int] = None  # Limit number of episodes
    # Action mapping
    action_key: str = "action"  # Key in the dataset for actions
    image_key: str = "observation.image"  # Key for camera images
    language_key: str = "language_instruction"  # Key for text
    proprioception_key: str = "observation.state"  # Key for joint states
    # Preprocessing
    image_size: int = 224
    fps: int = 4
    # Voice commands specific
    category_filter: Optional[List[str]] = None  # Filter by category (e.g., ["pick_place", "navigation"])
    max_samples: Optional[int] = None  # Limit total samples (for voice_commands, stereo4d)
    # Stereo4D specific
    use_stereo_pair: bool = True  # Use both left+right as multi-view input
    compute_depth: bool = False  # Compute disparity map from stereo pair
    # Cosmos DreamGen specific
    use_relative_actions: bool = True  # Use Cosmos relative action representation
    action_scaler: float = 20.0  # Scale factor for relative actions (Cosmos default)
    camera_ids: Optional[List[str]] = None  # Multi-camera IDs (e.g., ["head", "hand_0", "hand_1"])
    # MolmoBot-specific (sim data from MolmoSpaces)
    molmobot_exo_camera: str = "randomized_zed2_analogue_1"  # Exo camera key
    molmobot_wrist_camera: str = "wrist_camera_zed_mini"  # Wrist camera key
    joint_pos_actions: bool = True  # True=absolute joint pos, False=delta
    trim_episode_length: int = 0  # Trim last N frames per episode
    randomize_prompts: bool = True  # Randomize task prompts (MolmoBot-style)
    prompt_templates: Optional[Dict] = None  # Custom prompt templates per task
    auxiliary_datasets: Optional[Dict[str, float]] = None  # {path: weight} for weighted mixing


@dataclass
class DataSoupConfig:
    """Configuration for the full data soup."""

    sources: List[DataSourceConfig] = field(default_factory=list)
    action_chunk_size: int = 16  # Number of future steps per example
    max_language_length: int = 128  # Max tokens for language
    augment_images: bool = True
    seed: int = 42


class NeonEpisode:
    """A single training episode with unified format.

    Each episode contains:
    - images: List of camera frames (PIL or numpy)
    - actions: (T, action_dim) normalized action sequence
    - language: str instruction
    - proprioception: (T, state_dim) joint state sequence
    - metadata: dict with source info
    """

    def __init__(
        self,
        images: List[Any],
        actions: np.ndarray,
        language: str = "",
        proprioception: Optional[np.ndarray] = None,
        audio: Optional[np.ndarray] = None,
        lidar: Optional[np.ndarray] = None,
        eef_state: Optional[np.ndarray] = None,
        metadata: Optional[Dict] = None,
    ):
        self.images = images
        self.actions = actions
        self.language = language
        self.proprioception = proprioception
        self.audio = audio  # (T, samples) or (samples,) per-episode audio
        self.lidar = lidar  # (T, N, 4) point clouds per timestep
        self.eef_state = eef_state  # (T, 14) bimanual EE pos+quat
        self.metadata = metadata or {}

    @property
    def length(self) -> int:
        return len(self.images)


class ActionMapper:
    """Maps actions from different embodiments to the G1 action space.

    Different datasets have different action representations:
    - Agibot-World: 14 DoF bimanual (7+7 arms)
    - Franka: 7 DoF + gripper
    - SO-100: 6 DoF + gripper
    - GR00T: 14 DoF bimanual
    - OXE: varies by dataset

    This mapper normalizes everything to the G1 action space.
    """

    # Known mappings from source embodiment to G1 indices
    EMBODIMENT_MAPS = {
        "agibot": {
            # Agibot has similar bimanual layout to G1 upper body
            "source_dim": 14,
            "target_indices": list(range(14)),  # Direct map to G1 arms
        },
        "agibot_go1": {
            # GO-1 model: 16-DOF actions from AgiBotWorld
            # GO-1 action space: [left_arm(7), gripper_left(1), right_arm(7), gripper_right(1)]
            # Maps to G1 arm joints (global indices 15-28):
            #   GO-1 indices 0-5  → G1 left arm joints 15-20
            #   GO-1 index 6      → G1 left wrist yaw 21
            #   GO-1 index 7      → G1 left wrist yaw 21 (gripper → wrist, duplicate)
            #   GO-1 indices 8-13 → G1 right arm joints 22-27
            #   GO-1 index 14     → G1 right wrist yaw 28
            #   GO-1 index 15     → G1 right wrist yaw 28 (gripper → wrist, duplicate)
            "source_dim": 16,
            "target_indices": [15, 16, 17, 18, 19, 20, 21, 21, 22, 23, 24, 25, 26, 27, 28, 28],
            # Normalization stats from GO-1 dataset_stats.json
            "norm_mean": [-1.0138, 0.6469, 0.6194, -0.9804, 0.594, 0.9804, 0.0014, 0.0,
                          1.0362, -0.6618, -0.7937, 0.8947, -0.5716, -0.9804, -0.0385, 0.0],
            "norm_std": [0.5498, 0.3525, 0.5309, 0.3673, 0.4718, 0.4574, 0.61, 1.0,
                         0.5598, 0.3512, 0.5483, 0.3923, 0.5157, 0.4449, 0.629, 1.0],
        },
        "franka": {
            # Franka: 7 DoF arm + gripper → map to G1 right arm (global 22-28)
            "source_dim": 8,
            "target_indices": [22, 23, 24, 25, 26, 27, 28],
        },
        "molmobot_droid": {
            # MolmoBot-DROID / MolmoBot-Pi0: 8 DoF (7 joint_pos + 1 gripper)
            # Same as Franka — map to G1 right arm (global indices 22-28)
            "source_dim": 8,
            "target_indices": [22, 23, 24, 25, 26, 27, 28],
        },
        "so100": {
            # SO-100: 6 DoF + gripper → map to G1 right arm (global 22-28)
            "source_dim": 7,
            "target_indices": [22, 23, 24, 25, 26, 27, 28],
        },
        "gr1": {
            # Fourier GR1: similar bimanual layout → G1 arms (global 15-28)
            "source_dim": 14,
            "target_indices": list(range(15, 29)),
        },
        "g1": {
            # G1 native: identity mapping
            "source_dim": 29,
            "target_indices": list(range(29)),
        },
        "g1_43": {
            # G1 with hands (43-DOF): identity mapping for full body + hands
            "source_dim": 43,
            "target_indices": list(range(43)),
        },
    }

    def __init__(self, target_space: G1ActionSpace):
        self.target_space = target_space

    def map_actions(
        self,
        source_actions: np.ndarray,
        source_embodiment: str,
        normalize: bool = True,
    ) -> np.ndarray:
        """Map actions from source embodiment to G1 action space.

        For embodiments with source normalization stats (e.g. agibot_go1),
        source actions are first denormalized from their native space, then
        mapped to G1 joint indices, then normalized to G1 space.

        Args:
            source_actions: (T, source_dim) actions from source
            source_embodiment: Name of source robot
            normalize: If True, normalize output to [-1, 1]

        Returns:
            (T, action_dim) actions in G1 space
        """
        mapping = self.EMBODIMENT_MAPS.get(source_embodiment.lower())
        if mapping is None:
            logger.warning(f"Unknown embodiment: {source_embodiment}, using zero-pad")
            # Zero-pad to target dim
            T = source_actions.shape[0]
            target = np.zeros((T, self.target_space.action_dim), dtype=np.float32)
            dim = min(source_actions.shape[1], self.target_space.action_dim)
            target[:, :dim] = source_actions[:, :dim]
            return target

        # Step 1: If source has normalization stats, denormalize first
        # (so we work in raw joint-position space for cross-embodiment mapping)
        if "norm_mean" in mapping and "norm_std" in mapping:
            mean = np.array(mapping["norm_mean"], dtype=np.float32)
            std = np.array(mapping["norm_std"], dtype=np.float32)
            src_dim = min(source_actions.shape[1], len(mean))
            source_actions = source_actions.copy()
            # GO-1 stores actions as z-scored: raw = z * std + mean
            source_actions[:, :src_dim] = source_actions[:, :src_dim] * std[:src_dim] + mean[:src_dim]

        # Step 2: Map source actions to target indices
        T = source_actions.shape[0]
        target = np.zeros((T, self.target_space.action_dim), dtype=np.float32)
        src_dim = min(source_actions.shape[1], mapping["source_dim"])
        tgt_indices = mapping["target_indices"][:src_dim]

        # Find which target indices are in the active set
        active_indices = self.target_space.active_indices
        for src_i, tgt_i in enumerate(tgt_indices):
            if tgt_i in active_indices:
                local_i = active_indices.index(tgt_i)
                if src_i < source_actions.shape[1] and local_i < target.shape[1]:
                    target[:, local_i] = source_actions[:, src_i]

        # Step 3: Normalize to G1 space [-1, 1]
        if normalize:
            target = self.target_space.normalize(target)

        return target


class DataSoupDataset(Dataset):
    """Mixed multi-source dataset for VLA training.

    Loads episodes from multiple sources, maps actions to G1 space,
    and provides (observation, action_chunk, language) tuples for training.
    """

    def __init__(self, config: DataSoupConfig, action_space: G1ActionSpace):
        self.config = config
        self.action_space = action_space
        self.action_mapper = ActionMapper(action_space)

        # Load all sources
        self.episodes: List[NeonEpisode] = []
        self.source_weights: List[float] = []
        self.source_offsets: List[Tuple[int, int]] = []  # (start, end) per source

        for source_config in config.sources:
            logger.info(f"Loading source: {source_config.name} ({source_config.type})")
            source_episodes = self._load_source(source_config)
            start = len(self.episodes)
            self.episodes.extend(source_episodes)
            end = len(self.episodes)
            self.source_offsets.append((start, end))
            self.source_weights.extend([source_config.weight] * len(source_episodes))
            logger.info(f"  Loaded {len(source_episodes)} episodes from {source_config.name}")

        # Build sample indices: each sample is (episode_idx, timestep)
        self.samples = []
        for ep_idx, ep in enumerate(self.episodes):
            for t in range(max(0, ep.length - config.action_chunk_size)):
                self.samples.append((ep_idx, t))

        logger.info(
            f"DataSoup: {len(self.episodes)} episodes, {len(self.samples)} samples "
            f"from {len(config.sources)} sources"
        )

    def _load_source(self, source_config: DataSourceConfig) -> List[NeonEpisode]:
        """Load episodes from a single source."""
        if source_config.type == "lerobot":
            return self._load_lerobot(source_config)
        elif source_config.type == "agibot_world" or source_config.type == "agibot":
            return self._load_agibot_world(source_config)
        elif source_config.type == "dreamgen":
            return self._load_dreamgen(source_config)
        elif source_config.type == "custom":
            return self._load_custom(source_config)
        elif source_config.type == "voice_commands":
            return self._load_voice_commands(source_config)
        elif source_config.type == "stereo4d":
            return self._load_stereo4d(source_config)
        elif source_config.type == "cosmos_dreamgen":
            return self._load_cosmos_dreamgen(source_config)
        elif source_config.type == "g1_teleop":
            return self._load_g1_teleop(source_config)
        elif source_config.type == "groot_teleop":
            return self._load_groot_teleop(source_config)
        elif source_config.type == "neon_v3":
            return self._load_neon_v3(source_config)
        elif source_config.type == "synthetic_factory":
            return self._load_neon_v3(source_config)  # Same schema as neon_v3
        elif source_config.type == "bones_seed":
            return self._load_bones_seed(source_config)
        elif source_config.type == "kimodo":
            return self._load_kimodo(source_config)
        elif source_config.type == "molmobot":
            return self._load_molmobot(source_config)
        elif source_config.type == "tribev2_fmri":
            return self._load_tribev2_fmri(source_config)
        else:
            logger.warning(f"Unknown source type: {source_config.type}")
            return []

    def _load_lerobot(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load from LeRobot HuggingFace dataset format."""
        try:
            from datasets import load_dataset

            ds = load_dataset(config.path, split="train")

            # Group by episode
            episodes_data: Dict[int, List] = {}
            for item in ds:
                ep_id = item.get("episode_index", 0)
                episodes_data.setdefault(ep_id, []).append(item)

            episodes = []
            for ep_id, items in sorted(episodes_data.items()):
                if config.max_episodes and len(episodes) >= config.max_episodes:
                    break

                images = []
                actions = []
                states = []
                language = ""

                for item in items:
                    # Extract image
                    if config.image_key in item:
                        images.append(item[config.image_key])

                    # Extract action
                    if config.action_key in item:
                        actions.append(np.array(item[config.action_key], dtype=np.float32))

                    # Extract proprioception
                    if config.proprioception_key in item:
                        states.append(np.array(item[config.proprioception_key], dtype=np.float32))

                    # Extract language
                    if config.language_key in item and not language:
                        language = str(item[config.language_key])

                if not actions:
                    continue

                actions_arr = np.stack(actions)
                states_arr = np.stack(states) if states else None

                # Map actions to G1 space
                # Detect embodiment from dataset metadata
                embodiment = "franka"  # Default; could be detected from dataset
                mapped_actions = self.action_mapper.map_actions(actions_arr, embodiment)

                episodes.append(
                    NeonEpisode(
                        images=images,
                        actions=mapped_actions,
                        language=language,
                        proprioception=states_arr,
                        metadata={"source": config.name, "episode_id": ep_id},
                    )
                )

            return episodes

        except Exception as e:
            logger.error(f"Failed to load LeRobot dataset {config.path}: {e}")
            return []

    def _load_dreamgen(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load from GR00T-Dreams synthetic data format.

        DreamGen output is:
        - Synthetic videos (MP4)
        - IDM-extracted actions (LeRobot format)
        """
        try:
            # DreamGen exports to LeRobot format after IDM extraction
            # So we can use the LeRobot loader
            return self._load_lerobot(config)
        except Exception as e:
            logger.error(f"Failed to load DreamGen data {config.path}: {e}")
            return []

    def _load_agibot_world(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load from AgiBotWorld-Beta native format (H5 proprio + MP4 video).

        Dataset: agibot-world/AgiBotWorld-Beta  (CC BY-NC-SA 4.0)
        Structure on HuggingFace:
            observations/{task_id}/{episode_id}/videos/*.mp4
            observations/{task_id}/{episode_id}/depth/*.png
            proprio_stats/{task_id}/{episode_id}/proprio_stats.h5
            task_info/task_{task_id}.json
            parameters/{task_id}/{episode_id}/camera/

        H5 proprio layout (from the dataset README):
            /timestamp                       [N]
            /state/joint/position            [N, 14]  (left 7 + right 7)
            /state/effector/position         [N, 2]   (left gripper, right gripper mm)
            /state/end/position              [N, 2, 3] (bimanual EE xyz)
            /state/end/orientation           [N, 2, 4] (bimanual EE quat xyzw)
            /state/head/position             [N, 2]   (yaw, pitch)
            /state/waist/position            [N, 2]   (pitch, lift)
            /action/joint/position           [N, 14]  (target joint positions)
            /action/effector/position        [N, 2]   (gripper targets, 0=open 1=close)
            /action/*/index                  [M]      (timesteps when commands sent)

        GO-1 flattens this to 16-DOF: joint(14) + effector(2) for both state & action.
        We use the same representation → agibot_go1 embodiment mapping → G1 space.

        Supports two paths:
        1. Local directory (pre-downloaded): config.path = "/path/to/AgiBotWorld-Beta"
        2. HuggingFace streaming with selective download: config.path = "agibot-world/AgiBotWorld-Beta"

        Args:
            config: DataSourceConfig with type="agibot_world"
                - config.path: HF dataset ID or local dir
                - config.max_episodes: limit episodes to load
                - config.fps: target fps (source is ~30fps, default downsample to 4)
                - config.category_filter: list of task_ids to include (e.g. ["327", "352"])

        Returns:
            List of NeonEpisode with actions in G1 normalized space
        """
        import json
        from pathlib import Path

        logger.info(f"Loading AgiBotWorld: {config.path}")

        source_path = Path(config.path)
        is_local = source_path.exists() and source_path.is_dir()

        episodes = []
        episode_count = 0

        if is_local:
            # --- LOCAL PATH ---
            proprio_root = source_path / "proprio_stats"
            task_info_root = source_path / "task_info"

            if not proprio_root.exists():
                logger.error(f"proprio_stats/ not found in {config.path}")
                return []

            # Discover task dirs
            task_dirs = sorted(proprio_root.iterdir()) if proprio_root.exists() else []
            if config.category_filter:
                task_dirs = [d for d in task_dirs if d.name in config.category_filter]

            for task_dir in task_dirs:
                if not task_dir.is_dir():
                    continue
                task_id = task_dir.name

                # Load task language instruction
                language = ""
                task_json = task_info_root / f"task_{task_id}.json"
                if task_json.exists():
                    try:
                        with open(task_json) as f:
                            task_data = json.load(f)
                        if isinstance(task_data, list) and task_data:
                            language = task_data[0].get("task_name", "")
                        elif isinstance(task_data, dict):
                            language = task_data.get("task_name", "")
                    except Exception as e:
                        logger.debug(f"Could not parse task JSON {task_json}: {e}")

                # Load episodes for this task
                ep_dirs = sorted(task_dir.iterdir())
                for ep_dir in ep_dirs:
                    if config.max_episodes and episode_count >= config.max_episodes:
                        break

                    h5_path = ep_dir / "proprio_stats.h5"
                    if not h5_path.exists():
                        continue

                    ep = self._parse_agibot_h5(
                        h5_path, config, language, task_id, ep_dir.name
                    )
                    if ep is not None:
                        episodes.append(ep)
                        episode_count += 1

                if config.max_episodes and episode_count >= config.max_episodes:
                    break
        else:
            # --- HUGGINGFACE DOWNLOAD (selective) ---
            try:
                from huggingface_hub import HfApi, hf_hub_download

                api = HfApi()
                siblings = api.dataset_info(config.path).siblings or []

                # Find all H5 files
                h5_files = [
                    s.rfilename for s in siblings
                    if s.rfilename.endswith("proprio_stats.h5")
                ]
                # Find task JSONs
                task_jsons = [
                    s.rfilename for s in siblings
                    if s.rfilename.startswith("task_info/") and s.rfilename.endswith(".json")
                ]

                # Filter by task_id if category_filter specified
                if config.category_filter:
                    h5_files = [
                        f for f in h5_files
                        if any(f"/{tid}/" in f for tid in config.category_filter)
                    ]
                    task_jsons = [
                        f for f in task_jsons
                        if any(f"task_{tid}.json" in f for tid in config.category_filter)
                    ]

                if config.max_episodes:
                    h5_files = h5_files[: config.max_episodes]

                logger.info(f"Found {len(h5_files)} H5 files, {len(task_jsons)} task JSONs")

                # Pre-download task JSONs for language instructions
                task_languages = {}
                for tj in task_jsons:
                    try:
                        local_path = hf_hub_download(config.path, tj, repo_type="dataset")
                        with open(local_path) as f:
                            task_data = json.load(f)
                        if isinstance(task_data, list) and task_data:
                            task_languages[tj] = task_data[0].get("task_name", "")
                        elif isinstance(task_data, dict):
                            task_languages[tj] = task_data.get("task_name", "")
                    except Exception:
                        pass

                # Download and parse each H5
                for h5_rpath in h5_files:
                    if config.max_episodes and episode_count >= config.max_episodes:
                        break

                    try:
                        local_h5 = hf_hub_download(config.path, h5_rpath, repo_type="dataset")

                        # Extract task_id from path: proprio_stats/{task_id}/{ep_id}/proprio_stats.h5
                        parts = h5_rpath.split("/")
                        task_id = parts[1] if len(parts) > 2 else "unknown"
                        ep_id = parts[2] if len(parts) > 3 else "unknown"

                        # Find language
                        lang_key = f"task_info/task_{task_id}.json"
                        language = task_languages.get(lang_key, "")

                        ep = self._parse_agibot_h5(
                            Path(local_h5), config, language, task_id, ep_id
                        )
                        if ep is not None:
                            episodes.append(ep)
                            episode_count += 1

                    except Exception as e:
                        logger.debug(f"Failed to load {h5_rpath}: {e}")
                        continue

            except Exception as e:
                logger.error(f"Failed to load AgiBotWorld from HF: {e}")
                return []

        logger.info(
            f"Loaded {len(episodes)} AgiBotWorld episodes "
            f"({sum(ep.length for ep in episodes)} total frames)"
        )
        return episodes

    def _parse_agibot_h5(
        self,
        h5_path: "Path",
        config: DataSourceConfig,
        language: str,
        task_id: str,
        episode_id: str,
    ) -> Optional[NeonEpisode]:
        """Parse a single AgiBotWorld H5 proprio file into a NeonEpisode.

        Extracts 16-DOF state and action vectors:
        - joint_positions: [N, 14]  (7 left arm + 7 right arm)
        - effector_positions: [N, 2] (left gripper, right gripper)
        → concatenated: [N, 16]

        Then maps through ActionMapper("agibot_go1") → G1 normalized space.
        """
        try:
            import h5py
        except ImportError:
            logger.error("h5py required for AgiBotWorld loading: pip install h5py")
            return None

        try:
            with h5py.File(str(h5_path), "r") as f:
                # Extract joint positions: [N, 14]
                if "action/joint/position" not in f:
                    logger.debug(f"No action/joint/position in {h5_path}")
                    return None
                action_joints = f["action/joint/position"][:]  # (N, 14)

                # Extract gripper commands: [N, 2]
                action_grippers = np.zeros((action_joints.shape[0], 2), dtype=np.float32)
                if "action/effector/position" in f:
                    eff = f["action/effector/position"][:]
                    action_grippers[:eff.shape[0], :eff.shape[1]] = eff

                # Extract state (proprioception)
                state_joints = None
                if "state/joint/position" in f:
                    state_joints = f["state/joint/position"][:]  # (N, 14)

                state_grippers = np.zeros_like(action_grippers)
                if "state/effector/position" in f:
                    eff_s = f["state/effector/position"][:]
                    state_grippers[:eff_s.shape[0], :eff_s.shape[1]] = eff_s

                # Optional: head and waist state for richer proprioception
                head_pos = None
                if "state/head/position" in f:
                    head_pos = f["state/head/position"][:]  # (N, 2)

                waist_pos = None
                if "state/waist/position" in f:
                    waist_pos = f["state/waist/position"][:]  # (N, 2)

            # Build 16-DOF action: [joint(14), gripper(2)]
            # GO-1 format: [left_arm(7), left_grip(1), right_arm(7), right_grip(1)]
            T = action_joints.shape[0]
            actions_16 = np.zeros((T, 16), dtype=np.float32)
            actions_16[:, 0:7] = action_joints[:, :7]      # Left arm 7 joints
            actions_16[:, 7] = action_grippers[:, 0]         # Left gripper
            actions_16[:, 8:15] = action_joints[:, 7:14]    # Right arm 7 joints
            actions_16[:, 15] = action_grippers[:, 1]        # Right gripper

            # Build 16-DOF state (same layout)
            states_16 = None
            if state_joints is not None:
                states_16 = np.zeros((T, 16), dtype=np.float32)
                states_16[:, 0:7] = state_joints[:, :7]
                states_16[:, 7] = state_grippers[:, 0]
                states_16[:, 8:15] = state_joints[:, 7:14]
                states_16[:, 15] = state_grippers[:, 1]

            # Downsample from ~30fps to target fps
            source_fps = 30  # AgiBotWorld is ~30fps
            step = max(1, source_fps // config.fps)
            actions_16 = actions_16[::step]
            if states_16 is not None:
                states_16 = states_16[::step]
            T = actions_16.shape[0]

            if T < 2:
                return None

            # Map to G1 action space using agibot_go1 embodiment
            mapped_actions = self.action_mapper.map_actions(
                actions_16, "agibot_go1", normalize=True
            )

            # Map states for proprioception (same mapping, same normalization)
            mapped_states = None
            if states_16 is not None:
                mapped_states = self.action_mapper.map_actions(
                    states_16, "agibot_go1", normalize=True
                )

            return NeonEpisode(
                images=[],  # Videos loaded separately (too large for eager loading)
                actions=mapped_actions,
                language=language or "bimanual manipulation",
                proprioception=mapped_states,
                metadata={
                    "source": config.name,
                    "type": "agibot_world",
                    "task_id": task_id,
                    "episode_id": episode_id,
                    "original_fps": source_fps,
                    "downsampled_fps": config.fps,
                    "original_length": action_joints.shape[0],
                    "downsampled_length": T,
                    "action_dim": 16,
                    "embodiment": "agibot_go1",
                    "has_head": head_pos is not None,
                    "has_waist": waist_pos is not None,
                },
            )

        except Exception as e:
            logger.debug(f"Failed to parse {h5_path}: {e}")
            return None

    def _load_custom(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load from custom directory structure.

        Expected format:
        path/
        ├── episode_000/
        │   ├── images/
        │   │   ├── 000.jpg
        │   │   ├── 001.jpg
        │   │   └── ...
        │   ├── actions.npy    # (T, action_dim)
        │   ├── states.npy     # (T, state_dim)
        │   └── instruction.txt
        └── episode_001/
            └── ...
        """
        from pathlib import Path

        data_dir = Path(config.path)
        if not data_dir.exists():
            logger.warning(f"Custom data dir not found: {data_dir}")
            return []

        episodes = []
        for ep_dir in sorted(data_dir.iterdir()):
            if not ep_dir.is_dir() or ep_dir.name.startswith("."):
                continue

            if config.max_episodes and len(episodes) >= config.max_episodes:
                break

            try:
                # Load images
                images_dir = ep_dir / "images"
                images = []
                if images_dir.exists():
                    from PIL import Image

                    for img_path in sorted(images_dir.glob("*.jpg")) + sorted(images_dir.glob("*.png")):
                        images.append(Image.open(img_path))

                # Load actions
                actions_path = ep_dir / "actions.npy"
                if not actions_path.exists():
                    continue
                actions = np.load(actions_path)

                # Load states
                states = None
                states_path = ep_dir / "states.npy"
                if states_path.exists():
                    states = np.load(states_path)

                # Load instruction
                language = ""
                instruction_path = ep_dir / "instruction.txt"
                if instruction_path.exists():
                    language = instruction_path.read_text().strip()

                # Map to G1 space
                mapped_actions = self.action_mapper.map_actions(actions, "g1")

                episodes.append(
                    NeonEpisode(
                        images=images,
                        actions=mapped_actions,
                        language=language,
                        proprioception=states,
                        metadata={"source": config.name, "episode_dir": str(ep_dir)},
                    )
                )
            except Exception as e:
                logger.warning(f"Failed to load episode {ep_dir}: {e}")

        return episodes

    def _load_voice_commands(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load from voice commands dataset for language conditioning.

        Dataset: cagataydev/vlm-voice-commands
        Schema: {id, text, category, difficulty, voice, word_count}

        These are text-only robot instructions (50K across 10 categories).
        No images or actions — used for:
        1. Language conditioning: teach the model the distribution of natural
           language robot commands (pick/place, navigation, spatial, etc.)
        2. Audio pairing: when combined with vlm-voice-audio, provides
           text+audio pairs for the Omni backbone's native audio encoder
        3. Instruction augmentation: randomly pair voice commands with visual
           episodes from other sources to increase language diversity

        Each command becomes a 1-frame "episode" with zero actions.
        The training loop uses these for language-only loss (no action loss).
        """
        try:
            from datasets import load_dataset

            logger.info(f"Loading voice commands: {config.path}")
            ds = load_dataset(config.path, split="train", streaming=True)

            episodes = []
            count = 0

            for item in ds:
                # Category filter
                if config.category_filter:
                    if item.get("category") not in config.category_filter:
                        continue

                # Max samples limit
                if config.max_samples and count >= config.max_samples:
                    break

                text = item.get("text", "")
                if not text:
                    continue

                # Create a language-only episode (no images, zero actions)
                # These contribute to language conditioning loss only
                action_dim = self.action_space.action_dim
                episodes.append(
                    NeonEpisode(
                        images=[],  # No visual data
                        actions=np.zeros((1, action_dim), dtype=np.float32),
                        language=text,
                        proprioception=None,
                        metadata={
                            "source": config.name,
                            "type": "voice_commands",
                            "category": item.get("category", ""),
                            "difficulty": item.get("difficulty", ""),
                            "voice": item.get("voice", ""),
                            "language_only": True,  # Flag for training loop
                        },
                    )
                )
                count += 1

            logger.info(
                f"Loaded {len(episodes)} voice commands "
                f"(categories: {config.category_filter or 'all'})"
            )
            return episodes

        except Exception as e:
            logger.error(f"Failed to load voice commands {config.path}: {e}")
            return []

    def _load_stereo4d(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load from stereo4D video dataset for visual pretraining.

        Dataset: cagataydev/strands-kitchen-stereo4d
        Structure: episode_XXX/stereo_left/frame_XXXXXX.png + stereo_right/...
        Loaded as imagefolder: {image: PIL} — images flattened

        Stereo4D provides:
        1. Temporal video sequences from a real kitchen environment
        2. Stereo pairs (left + right) for implicit depth understanding
        3. Scene priors: object layout, counters, spatial relations

        No actions — used for visual backbone pretraining:
        - Video temporal consistency (frame N → N+1 transitions)
        - Scene understanding (kitchen objects, workspace geometry)
        - Depth from stereo (when compute_depth=True)

        Each episode becomes a video sequence with zero actions.
        Training loop applies visual loss only (contrastive / reconstruction).

        The dataset structure on HuggingFace is:
            episode_XXX/stereo_left/frame_XXXXXX.png   (640×480)
            episode_XXX/stereo_right/frame_XXXXXX.png  (640×480)

        When loaded as imagefolder, all images are flattened.
        We reconstruct episodes from download_checksums metadata which
        contains the original paths.
        """
        try:
            from datasets import load_dataset

            logger.info(f"Loading stereo4D: {config.path}")
            ds_info = load_dataset(config.path, split="train", streaming=True)

            # The imagefolder loader flattens the directory structure.
            # We need to reconstruct episodes from the file ordering.
            # From inspection: 1038 files across ~10 episodes, ~97 frames each,
            # stereo_left + stereo_right interleaved per episode.
            #
            # Strategy: collect all images, group into chunks of consecutive
            # frames. Each chunk of left frames = one episode's video.
            # Right frames = stereo pair for that episode.

            all_images = []
            count = 0
            for item in ds_info:
                if config.max_samples and count >= config.max_samples:
                    break
                all_images.append(item["image"])
                count += 1

            if not all_images:
                logger.warning(f"No images loaded from {config.path}")
                return []

            logger.info(f"Loaded {len(all_images)} raw images from stereo4D")

            # Reconstruct episodes from the flattened image list
            # The dataset has ~10 episodes, each with stereo_left then stereo_right
            # Total 1004 images = ~10 episodes × ~50 frames × 2 cameras
            # Images are ordered: ep0/left/f0, ep0/left/f1, ..., ep0/right/f0, ...
            #
            # Each episode contributes ~97 left + ~97 right = ~194 images
            # (except shorter episodes at the end)
            #
            # Simple heuristic: split into episodes based on total count
            # and the known structure (roughly equal-sized episodes)
            total = len(all_images)
            # Each episode has left + right, with left frames first in sorted order
            # Estimate: half are left, half are right
            half = total // 2
            left_images = all_images[:half]
            right_images = all_images[half:]

            # Estimate ~10 episodes of roughly equal length
            # (from inspection: episodes 000-008 have ~97 frames, 009 has ~30)
            num_episodes = max(1, round(len(left_images) / 80))  # ~80 frames per episode avg
            frames_per_ep = len(left_images) // num_episodes

            episodes = []
            action_dim = self.action_space.action_dim

            for ep_i in range(num_episodes):
                start = ep_i * frames_per_ep
                end = start + frames_per_ep if ep_i < num_episodes - 1 else len(left_images)

                ep_left = left_images[start:end]
                if not ep_left:
                    continue

                # Subsample to target fps (dataset is dense, we want ~4fps)
                # Keep every Nth frame based on source fps vs target
                step = max(1, len(ep_left) // (config.fps * 10))  # ~10 sec episodes
                ep_frames = ep_left[::step][:32]  # Cap at 32 frames for memory

                # Optionally pair with right camera for stereo
                stereo_right = None
                if config.use_stereo_pair and ep_i * frames_per_ep < len(right_images):
                    r_start = ep_i * frames_per_ep
                    r_end = r_start + frames_per_ep if ep_i < num_episodes - 1 else len(right_images)
                    ep_right = right_images[r_start:r_end]
                    stereo_right = ep_right[::step][:32]

                T = len(ep_frames)

                episodes.append(
                    NeonEpisode(
                        images=ep_frames,
                        actions=np.zeros((T, action_dim), dtype=np.float32),  # No actions
                        language="observe kitchen scene",  # Generic scene description
                        proprioception=None,
                        metadata={
                            "source": config.name,
                            "type": "stereo4d",
                            "episode_index": ep_i,
                            "num_frames": T,
                            "has_stereo": stereo_right is not None,
                            "stereo_right": stereo_right,  # Stored in metadata for backbone
                            "visual_only": True,  # Flag: no action loss for this source
                        },
                    )
                )

            logger.info(
                f"Loaded {len(episodes)} stereo4D episodes "
                f"({sum(ep.length for ep in episodes)} total frames, "
                f"stereo_pairs={'yes' if config.use_stereo_pair else 'no'})"
            )
            return episodes

        except Exception as e:
            logger.error(f"Failed to load stereo4D {config.path}: {e}")
            return []


    def _load_cosmos_dreamgen(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load from Cosmos-Predict2.5 DreamGen / action-conditioned data.

        Cosmos DreamGen data comes in two forms:
        1. GR1/GR00T-Dreams: HuggingFace datasets with video + text prompts
           (nvidia/GR1-100, NVIDIA/GR00T-Dreams-GR1)
        2. Bridge-style: videos/ + annotations/*.json with robot states

        Key Cosmos techniques ported here:
        - Relative end-effector actions (delta xyz/rpy in gripper frame)
        - Multi-camera conditioning (head, hand_0, hand_1)
        - Action chunking aligned to 4× temporal compression ratio
        - Scale factor of 20.0 for action deltas

        The relative action representation is crucial for cross-embodiment
        transfer. From Cosmos paper: "rel_xyz = prev_rotm.T @ (curr_xyz - prev_xyz)"
        — this makes the same delta movement mean the same thing regardless of
        workspace origin or robot geometry.

        This loader reads:
        - Videos (from HF or local path)
        - Robot state annotations (end-effector pose + gripper)
        - Text prompts (language instructions)

        And converts to NeonEpisodes using Cosmos relative actions mapped
        through our ActionMapper to the G1 action space.
        """
        try:
            import json
            from pathlib import Path

            logger.info(f"Loading Cosmos DreamGen data: {config.path}")

            # Determine if HuggingFace dataset or local path
            source_path = Path(config.path)
            episodes = []
            action_dim = self.action_space.action_dim

            if source_path.exists() and source_path.is_dir():
                # Local Cosmos-style data: videos/ + annotations/*.json
                annotations_dir = source_path / "annotations"
                videos_dir = source_path / "videos"

                if not annotations_dir.exists():
                    logger.warning(f"No annotations/ dir in {config.path}")
                    return []

                json_files = sorted(annotations_dir.glob("*.json"))
                if config.max_episodes:
                    json_files = json_files[: config.max_episodes]

                for json_path in json_files:
                    try:
                        with open(json_path) as f:
                            annotation = json.load(f)

                        # Extract relative actions using Cosmos method
                        from neon.data.relative_actions import get_action_sequence_from_states

                        rel_actions = get_action_sequence_from_states(
                            annotation,
                            fps_downsample_ratio=max(1, 30 // config.fps),  # Source typically 30fps
                            state_key=config.action_key if config.action_key != "action" else "state",
                            action_scaler=config.action_scaler,
                        )

                        # Map 7-DoF relative EE actions to G1 space
                        # Cosmos actions are [rel_xyz(3), rel_rpy(3), gripper(1)]
                        # We pad/map to full G1 action dim
                        T = len(rel_actions)
                        mapped_actions = np.zeros((T, action_dim), dtype=np.float32)
                        # Map to right arm position deltas + gripper
                        ee_dim = min(rel_actions.shape[1], action_dim)
                        mapped_actions[:, :ee_dim] = rel_actions[:, :ee_dim]

                        # Load video frames (optional — may not exist for all entries)
                        frames = []
                        video_name = json_path.stem
                        video_path = videos_dir / f"{video_name}.mp4"
                        if video_path.exists():
                            try:
                                import mediapy

                                video_array = mediapy.read_video(str(video_path))
                                step = max(1, len(video_array) // T)
                                frames = [video_array[i] for i in range(0, len(video_array), step)][:T]
                            except ImportError:
                                logger.debug("mediapy not available, skipping video frames")

                        # Text prompt
                        language = annotation.get("prompt", annotation.get("text", "robot manipulation"))

                        episodes.append(
                            NeonEpisode(
                                images=frames,
                                actions=mapped_actions,
                                language=language,
                                proprioception=None,
                                metadata={
                                    "source": config.name,
                                    "type": "cosmos_dreamgen",
                                    "action_repr": "relative_ee",
                                    "action_scaler": config.action_scaler,
                                    "original_action_dim": rel_actions.shape[1],
                                    "has_video": len(frames) > 0,
                                },
                            )
                        )
                    except Exception as e:
                        logger.debug(f"Skipping {json_path.name}: {e}")
                        continue
            else:
                # HuggingFace dataset (nvidia/GR1-100, etc.)
                from datasets import load_dataset

                logger.info(f"Loading HF Cosmos DreamGen: {config.path}")
                ds = load_dataset(config.path, split="train", streaming=True)

                count = 0
                for item in ds:
                    if config.max_episodes and count >= config.max_episodes:
                        break

                    # GR1/DreamGen datasets have varying schemas
                    # Common fields: video, text/prompt/caption
                    language = (
                        item.get("text")
                        or item.get("prompt")
                        or item.get("caption")
                        or "robot manipulation"
                    )

                    # If the dataset has state information, compute relative actions
                    if "state" in item and "continuous_gripper_state" in item:
                        from neon.data.relative_actions import get_action_sequence_from_states

                        rel_actions = get_action_sequence_from_states(
                            item, action_scaler=config.action_scaler,
                        )
                        T = len(rel_actions)
                        mapped_actions = np.zeros((T, action_dim), dtype=np.float32)
                        ee_dim = min(rel_actions.shape[1], action_dim)
                        mapped_actions[:, :ee_dim] = rel_actions[:, :ee_dim]
                    else:
                        # No state info — visual-only episode (like DreamGen bench)
                        T = 16  # Default frame count
                        mapped_actions = np.zeros((T, action_dim), dtype=np.float32)

                    episodes.append(
                        NeonEpisode(
                            images=[],  # HF streaming — frames loaded lazily
                            actions=mapped_actions,
                            language=language,
                            proprioception=None,
                            metadata={
                                "source": config.name,
                                "type": "cosmos_dreamgen",
                                "action_repr": "relative_ee" if "state" in item else "none",
                                "visual_only": "state" not in item,
                            },
                        )
                    )
                    count += 1

            logger.info(
                f"Loaded {len(episodes)} Cosmos DreamGen episodes from {config.path}"
            )
            return episodes

        except Exception as e:
            logger.error(f"Failed to load Cosmos DreamGen {config.path}: {e}")
            return []


    def _load_g1_teleop(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load G1 teleop dataset from S3 or local path (LeRobot v2.1 format).

        The pick-basket dataset has:
        - 526 episodes, 39,670 frames @20fps (33 min total)
        - observation.state: 43-DOF joint positions (29 body + 14 hand)
        - observation.eef_state: 14-DOF end-effector (bimanual pos+quat)
        - action: 43-DOF target joint positions
        - action.eef: 14-DOF end-effector targets
        - teleop.navigate_command: 3-DOF locomotion (vx, vy, omega)
        - teleop.base_height_command: 1-DOF
        - observation.images.ego_view: 640x480 H.264 @20fps
        - Task: "pick up the basket"

        Source: s3://pick-basket-dataset/pick_basket_dataset/
        Format: LeRobot v2.1 (data/chunk-000/*.parquet + videos/ + meta/)

        The joint ordering matches G1_DATASET_JOINT_NAMES from action_space.py.
        The dataset was collected with GR00T WBC for lower-body balance,
        exoskeleton teleop for upper body + hands.

        This is NATIVE G1 data — no cross-embodiment mapping needed.
        Actions map directly to our action space in WHOLE_BODY_HANDS mode.
        """
        import json
        from pathlib import Path

        logger.info(f"Loading G1 teleop dataset: {config.path}")

        # Determine if S3 or local
        is_s3 = config.path.startswith("s3://")
        local_dir = None

        if is_s3:
            local_dir = self._sync_s3_dataset(config.path, config.max_episodes)
        else:
            local_dir = Path(config.path)
            if not local_dir.exists():
                logger.error(f"G1 teleop path not found: {config.path}")
                return []

        # Load metadata
        meta_dir = local_dir / "meta"
        info_path = meta_dir / "info.json"
        episodes_path = meta_dir / "episodes.jsonl"
        tasks_path = meta_dir / "tasks.jsonl"

        if not info_path.exists():
            logger.error(f"Missing info.json in {meta_dir}")
            return []

        with open(info_path) as f:
            info = json.load(f)

        fps = info.get("fps", 20)
        total_episodes = info.get("total_episodes", 0)

        # Load task descriptions
        task_map = {}
        if tasks_path.exists():
            with open(tasks_path) as f:
                for line in f:
                    t = json.loads(line)
                    task_map[t["task_index"]] = t["task"]

        # Load episode metadata
        episode_metas = []
        if episodes_path.exists():
            with open(episodes_path) as f:
                for line in f:
                    episode_metas.append(json.loads(line))

        if config.max_episodes:
            episode_metas = episode_metas[: config.max_episodes]

        logger.info(f"Loading {len(episode_metas)}/{total_episodes} episodes from G1 teleop @ {fps}fps")

        # Load parquet data
        episodes = []
        data_dir = local_dir / "data" / "chunk-000"

        try:
            import pyarrow.parquet as pq
        except ImportError:
            logger.error("pyarrow required for parquet loading: pip install pyarrow")
            return []

        for ep_meta in episode_metas:
            ep_idx = ep_meta["episode_index"]
            ep_length = ep_meta.get("length", 0)
            parquet_path = data_dir / f"episode_{ep_idx:06d}.parquet"

            if not parquet_path.exists():
                logger.debug(f"Skipping missing episode {ep_idx}")
                continue

            try:
                table = pq.read_table(parquet_path)
                df = table.to_pandas()

                # Extract 43-DOF joint states and actions
                states = np.array(df["observation.state"].tolist(), dtype=np.float32)
                actions = np.array(df["action"].tolist(), dtype=np.float32)

                # Extract EE states (14-DOF: bimanual pos+quat)
                eef_states = None
                if "observation.eef_state" in df.columns:
                    eef_states = np.array(df["observation.eef_state"].tolist(), dtype=np.float32)

                # Extract locomotion commands
                nav_cmds = None
                if "teleop.navigate_command" in df.columns:
                    nav_cmds = np.array(df["teleop.navigate_command"].tolist(), dtype=np.float32)

                # Task description
                task_idx = int(df["task_index"].iloc[0]) if "task_index" in df.columns else 0
                language = task_map.get(task_idx, "")
                if not language and ep_meta.get("tasks"):
                    language = ep_meta["tasks"][0]

                # Downsample from dataset fps to training fps
                step = max(1, fps // config.fps)
                states = states[::step]
                actions = actions[::step]
                if eef_states is not None:
                    eef_states = eef_states[::step]
                if nav_cmds is not None:
                    nav_cmds = nav_cmds[::step]

                T = len(actions)

                # For the action mapper: this is native G1 data, identity mapping.
                # 43-DOF actions go directly into the action space.
                # If our action_space is 29-DOF (no hands), we truncate.
                # If 43-DOF (WHOLE_BODY_HANDS), we keep everything.
                action_dim = self.action_space.action_dim
                loco_dim = 3 if self.action_space.include_locomotion else 0
                joint_dim = action_dim - loco_dim

                mapped_actions = np.zeros((T, action_dim), dtype=np.float32)

                # Map dataset joints → our action space joints
                # Dataset order: legs(12), waist(3), left_arm(7), left_hand(7), right_arm(7), right_hand(7)
                # Our order depends on control mode, but for whole_body_hands it's our G1_JOINTS_WITH_HANDS
                src_dim = min(actions.shape[1], joint_dim)
                mapped_actions[:, :src_dim] = actions[:, :src_dim]

                # Append locomotion if available and enabled
                if nav_cmds is not None and loco_dim > 0:
                    mapped_actions[:, joint_dim:joint_dim + 3] = nav_cmds[:T]

                episodes.append(
                    NeonEpisode(
                        images=[],  # Video loaded separately (too large for memory)
                        actions=mapped_actions,
                        language=language,
                        proprioception=states[:, :joint_dim],
                        eef_state=eef_states,  # (T, 14) bimanual pos+quat, or None
                        metadata={
                            "source": config.name,
                            "type": "g1_teleop",
                            "episode_index": ep_idx,
                            "original_fps": fps,
                            "original_length": ep_length,
                            "downsampled_length": T,
                            "has_eef": eef_states is not None,
                            "has_locomotion": nav_cmds is not None,
                            "has_hands": actions.shape[1] == 43,
                            "action_dim": actions.shape[1],
                            "embodiment": "g1",
                        },
                    )
                )

            except Exception as e:
                logger.warning(f"Failed to load episode {ep_idx}: {e}")
                continue

        logger.info(
            f"Loaded {len(episodes)} G1 teleop episodes "
            f"({sum(ep.length for ep in episodes)} frames, "
            f"action_dim={episodes[0].actions.shape[1] if episodes else '?'})"
        )
        return episodes


    def _load_groot_teleop(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load NVIDIA GR00T teleop/sim datasets from HuggingFace (LeRobot v2.1 format).

        Supports multiple NVIDIA GR00T datasets:
        - nvidia/PhysicalAI-Robotics-GR00T-Teleop-G1: Real G1 teleoperation (4 pick tasks)
        - nvidia/PhysicalAI-Robotics-GR00T-X-Embodiment-Sim: Sim data with EEF (G1 + GR1 + Panda)
        - nvidia/PhysicalAI-Robotics-GR00T-Teleop-Sim: Sim teleop data
        - nvidia/PhysicalAI-Robotics-GR00T-Teleop-GR1: Real GR1 teleop
        - nvidia/PhysicalAI-Robotics-GR00T-GR1: Real GR1 data

        These datasets use LeRobot v2.1 format:
        - data/chunk-000/episode_XXXXXX.parquet (per-episode parquet)
        - videos/chunk-000/{video_key}/episode_XXXXXX.mp4
        - meta/info.json (schema + feature definitions)
        - meta/episodes.jsonl (episode metadata + task descriptions)
        - meta/tasks.jsonl (task index → description mapping)

        The dataset contains multiple sub-datasets (one per task), each identified
        by a folder name. config.path should point to the HuggingFace repo ID.
        config.camera_ids can specify which sub-datasets to load (by folder prefix).

        Features in teleop datasets:
        - observation.images.ego_view: (480, 640, 3) video @20fps
        - observation.state: (43,) full G1 joint positions
        - action: (43,) target joint positions

        X-Embodiment-Sim additionally has:
        - observation.eef_state: (14,) bimanual EEF pos+quat
        - action.eef: (14,) EEF targets
        - observation.sim.*: sim state (MuJoCo qpos, wrist poses, etc.)
        """
        import json

        logger.info(f"Loading GR00T dataset: {config.path}")

        try:
            from huggingface_hub import HfApi, hf_hub_download
        except ImportError:
            logger.error("huggingface_hub required: pip install huggingface-hub")
            return []

        try:
            import pyarrow.parquet as pq
        except ImportError:
            logger.error("pyarrow required: pip install pyarrow")
            return []

        api = HfApi()

        # Discover sub-datasets (each task is a top-level folder)
        try:
            top_items = list(api.list_repo_tree(config.path, repo_type="dataset", recursive=False))
        except Exception as e:
            logger.error(f"Failed to list repo {config.path}: {e}")
            return []

        # Filter to folders that contain data (skip .gitattributes, README, etc.)
        subdatasets = []
        for item in top_items:
            path = item.rfilename if hasattr(item, "rfilename") else str(item)
            # RepoFolder objects have a path attribute
            folder_path = getattr(item, "path", path)
            if hasattr(item, "tree_id"):  # It's a folder
                # Filter by camera_ids (used as task filter here)
                if config.camera_ids:
                    if not any(prefix in folder_path for prefix in config.camera_ids):
                        continue
                subdatasets.append(folder_path)

        if not subdatasets:
            logger.warning(f"No sub-datasets found in {config.path}")
            return []

        logger.info(f"Found {len(subdatasets)} sub-datasets: {subdatasets[:5]}{'...' if len(subdatasets) > 5 else ''}")

        all_episodes = []
        total_loaded = 0

        for subds_name in subdatasets:
            if config.max_episodes and total_loaded >= config.max_episodes:
                break

            # Download and parse meta/info.json for this sub-dataset
            try:
                info_path = hf_hub_download(
                    config.path,
                    f"{subds_name}/meta/info.json",
                    repo_type="dataset",
                )
                with open(info_path) as f:
                    info = json.load(f)
            except Exception as e:
                logger.debug(f"Skipping {subds_name}: no info.json ({e})")
                continue

            fps = info.get("fps", 20)
            total_eps = info.get("total_episodes", 0)
            features = info.get("features", {})

            # Check what modalities are available
            has_eef = "observation.eef_state" in features
            has_sim = any(k.startswith("observation.sim.") for k in features)
            state_dim = features.get("observation.state", {}).get("shape", [43])[0]
            action_dim_src = features.get("action", {}).get("shape", [43])[0]

            # Detect embodiment from folder name or state dim
            folder_lower = subds_name.lower()
            if "g1" in folder_lower or "unitree_g1" in folder_lower:
                embodiment = "g1_43" if state_dim == 43 else "g1"
            elif "gr1" in folder_lower:
                embodiment = "gr1"
            elif "panda" in folder_lower or "franka" in folder_lower:
                embodiment = "franka"
            else:
                embodiment = "g1_43" if state_dim == 43 else "g1"

            # Load task descriptions
            task_map = {}
            try:
                tasks_path = hf_hub_download(
                    config.path,
                    f"{subds_name}/meta/tasks.jsonl",
                    repo_type="dataset",
                )
                with open(tasks_path) as f:
                    for line in f:
                        t = json.loads(line)
                        task_map[t["task_index"]] = t["task"]
            except Exception:
                pass  # tasks.jsonl is optional

            # Load episode metadata
            episode_metas = []
            try:
                ep_path = hf_hub_download(
                    config.path,
                    f"{subds_name}/meta/episodes.jsonl",
                    repo_type="dataset",
                )
                with open(ep_path) as f:
                    for line in f:
                        episode_metas.append(json.loads(line))
            except Exception as e:
                logger.debug(f"No episodes.jsonl for {subds_name}: {e}")
                continue

            # Limit episodes per sub-dataset
            remaining = (config.max_episodes - total_loaded) if config.max_episodes else None
            if remaining is not None:
                episode_metas = episode_metas[:remaining]

            logger.info(
                f"  {subds_name}: {len(episode_metas)}/{total_eps} episodes, "
                f"{state_dim}-DOF, eef={has_eef}, sim={has_sim}, embodiment={embodiment}"
            )

            # Load parquet data for each episode
            for ep_meta in episode_metas:
                ep_idx = ep_meta["episode_index"]
                chunk_idx = ep_idx // info.get("chunks_size", 1000)

                parquet_rel = f"{subds_name}/data/chunk-{chunk_idx:03d}/episode_{ep_idx:06d}.parquet"

                try:
                    parquet_path = hf_hub_download(
                        config.path,
                        parquet_rel,
                        repo_type="dataset",
                    )
                except Exception as e:
                    logger.debug(f"Skipping episode {ep_idx}: {e}")
                    continue

                try:
                    table = pq.read_table(parquet_path)
                    df = table.to_pandas()

                    # Extract joint states and actions
                    states = np.array(df["observation.state"].tolist(), dtype=np.float32)
                    actions = np.array(df["action"].tolist(), dtype=np.float32)

                    # Extract EEF states if available
                    eef_states = None
                    if has_eef and "observation.eef_state" in df.columns:
                        eef_states = np.array(df["observation.eef_state"].tolist(), dtype=np.float32)

                    # Task description
                    task_idx = int(df["task_index"].iloc[0]) if "task_index" in df.columns else 0
                    language = task_map.get(task_idx, "")
                    if not language and ep_meta.get("tasks"):
                        language = ep_meta["tasks"][0]

                    # Downsample from dataset fps to training fps
                    step = max(1, fps // config.fps)
                    states = states[::step]
                    actions = actions[::step]
                    if eef_states is not None:
                        eef_states = eef_states[::step]

                    T = len(actions)

                    # Map actions to G1 action space
                    mapped_actions = self.action_mapper.map_actions(actions, embodiment)

                    # Map proprioception similarly
                    mapped_proprio = self.action_mapper.map_actions(states, embodiment)

                    all_episodes.append(
                        NeonEpisode(
                            images=[],  # Videos downloaded separately (too large for memory)
                            actions=mapped_actions,
                            language=language,
                            proprioception=mapped_proprio,
                            eef_state=eef_states,
                            metadata={
                                "source": config.name,
                                "type": "groot_teleop",
                                "sub_dataset": subds_name,
                                "episode_index": ep_idx,
                                "original_fps": fps,
                                "original_length": ep_meta.get("length", T),
                                "downsampled_length": T,
                                "has_eef": eef_states is not None,
                                "has_sim_state": has_sim,
                                "state_dim": state_dim,
                                "action_dim": action_dim_src,
                                "embodiment": embodiment,
                            },
                        )
                    )
                    total_loaded += 1

                except Exception as e:
                    logger.warning(f"Failed to load {subds_name} ep {ep_idx}: {e}")
                    continue

        logger.info(
            f"Loaded {len(all_episodes)} GR00T episodes from {config.path} "
            f"({sum(ep.length for ep in all_episodes)} frames, "
            f"{len(subdatasets)} sub-datasets)"
        )
        return all_episodes

    def _load_neon_v3(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load from a Neon LeRobot v3 omni-modal dataset.

        These datasets are recorded by NeonLeRobotWriter from real G1 sessions
        or sim environments, and contain ALL modalities:
        - Camera (head + hand) as video
        - Joint state (43-DOF)
        - EEF state (14-DOF bimanual pos+quat)
        - LiDAR point cloud (4096×4)
        - Audio waveform (32000 samples per frame @16kHz)
        - Actions (43-DOF joints + 3-DOF locomotion)
        - Language instructions

        This is the only data source that fills all encoder pipelines
        in NeonVLA simultaneously (vision + proprio + lidar + audio + eef).

        Args:
            config: DataSourceConfig with type="neon_v3"
                - config.path: HuggingFace dataset ID or local path
                - config.max_episodes: limit episodes to load
                - config.fps: target fps for downsampling

        Returns:
            List of NeonEpisode with all modalities populated
        """
        try:
            from neon.data.lerobot_v3 import NeonLeRobotReader

            logger.info(f"Loading Neon v3 dataset: {config.path}")

            reader = NeonLeRobotReader(
                repo_id_or_path=config.path,
                action_space=self.action_space,
            )

            episodes = reader.load_episodes(
                max_episodes=config.max_episodes,
                fps=config.fps,
            )

            # Tag episodes with the data source config name
            for ep in episodes:
                ep.metadata["source"] = config.name

            logger.info(
                f"Loaded {len(episodes)} Neon v3 episodes from {config.path} "
                f"(modalities: {episodes[0].metadata.get('modalities', []) if episodes else '?'})"
            )
            return episodes

        except Exception as e:
            logger.error(f"Failed to load Neon v3 dataset {config.path}: {e}")
            return []

    def _load_bones_seed(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load BONES-SEED whole-body motion dataset for G1.

        BONES-SEED is a large-scale motion dataset with 142K whole-body
        motions specifically curated for the Unitree G1 humanoid robot.
        It contains:
        - Joint trajectories for all 29 body DoF
        - Locomotion commands (walking, turning, crouching)
        - Manipulation motions (reaching, grasping, carrying)
        - Whole-body coordination (walk-and-grasp, etc.)

        Dataset format (HuggingFace):
            Each sample has:
            - joint_positions: (T, 29) float32 — joint angle trajectories
            - joint_velocities: (T, 29) float32 — joint velocity trajectories (optional)
            - task_description: str — natural language description
            - motion_type: str — category (locomotion/manipulation/wholebody)
            - duration: float — motion duration in seconds
            - fps: int — original recording fps

        This is MOTION data, not teleoperation — it comes from motion
        planning, retargeted human motions, and RL policies. Actions are
        the joint_positions themselves (position control targets).

        Key for BONES-SEED: it provides locomotion + whole-body motions
        that are hard to get from pure teleoperation, especially complex
        locomotion patterns and whole-body coordination.

        Args:
            config: DataSourceConfig with type="bones_seed"
                - config.path: HuggingFace dataset ID (e.g., "cagataydev/bones-seed-g1")
                - config.max_episodes: limit motions to load
                - config.fps: target fps for downsampling
                - config.category_filter: filter by motion_type (optional)

        Returns:
            List of NeonEpisode with whole-body joint trajectories
        """
        try:
            from datasets import load_dataset

            logger.info(f"Loading BONES-SEED: {config.path}")

            # Load from HuggingFace (streaming to handle 142K motions)
            try:
                ds = load_dataset(config.path, split="train", streaming=True)
            except Exception:
                # Fallback: try loading with trust_remote_code
                ds = load_dataset(config.path, split="train", streaming=True, trust_remote_code=True)

            episodes = []
            count = 0
            action_dim = self.action_space.action_dim

            for item in ds:
                # Category filter
                if config.category_filter:
                    motion_type = item.get("motion_type", "")
                    if motion_type not in config.category_filter:
                        continue

                # Max episodes limit
                if config.max_episodes and count >= config.max_episodes:
                    break

                # Extract joint positions — the core motion data
                joint_positions = None
                if "joint_positions" in item:
                    joint_positions = np.array(item["joint_positions"], dtype=np.float32)
                elif "positions" in item:
                    joint_positions = np.array(item["positions"], dtype=np.float32)
                elif "action" in item:
                    joint_positions = np.array(item["action"], dtype=np.float32)
                else:
                    continue

                if joint_positions.ndim == 1:
                    # Single timestep — expand
                    joint_positions = joint_positions[np.newaxis, :]

                T = joint_positions.shape[0]
                if T < 2:
                    continue

                # Downsample to target fps
                source_fps = item.get("fps", 30)
                step = max(1, source_fps // config.fps)
                joint_positions = joint_positions[::step]
                T = joint_positions.shape[0]

                if T < 2:
                    continue

                # Map to G1 action space
                # BONES-SEED is native G1 data (29 DoF)
                src_dim = joint_positions.shape[1]
                mapped_actions = np.zeros((T, action_dim), dtype=np.float32)
                dim = min(src_dim, action_dim)
                mapped_actions[:, :dim] = joint_positions[:, :dim]

                # Normalize to [-1, 1]
                mapped_actions = self.action_space.normalize(mapped_actions)

                # Proprioception = joint_positions (same as actions for motion data)
                proprio = mapped_actions.copy()

                # Task description
                language = (
                    item.get("task_description", "")
                    or item.get("description", "")
                    or item.get("text", "")
                    or "whole body motion"
                )

                episodes.append(
                    NeonEpisode(
                        images=[],  # Motion data — no images
                        actions=mapped_actions,
                        language=language,
                        proprioception=proprio,
                        metadata={
                            "source": config.name,
                            "type": "bones_seed",
                            "motion_type": item.get("motion_type", "unknown"),
                            "original_fps": source_fps,
                            "original_length": item.get("duration", T / source_fps),
                            "downsampled_length": T,
                            "src_joint_dim": src_dim,
                            "embodiment": "g1",
                        },
                    )
                )
                count += 1

            logger.info(
                f"Loaded {len(episodes)} BONES-SEED motions from {config.path} "
                f"({sum(ep.actions.shape[0] for ep in episodes)} total frames)"
            )
            return episodes

        except Exception as e:
            logger.error(f"Failed to load BONES-SEED {config.path}: {e}")
            return []

    def _load_kimodo(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load or generate motions using Kimodo text-to-G1-motion model.

        Kimodo (NVIDIA) generates G1-native joint trajectories from text
        prompts using kinematic motion diffusion trained on 700h mocap.

        If the pre-generated HuggingFace dataset exists, loads from there.
        Otherwise, generates motions on-the-fly using KimodoGenerator
        (falls back to procedural generation if Kimodo is not installed).

        Args:
            config: DataSourceConfig with type="kimodo"
                - config.path: HF dataset ID (e.g., "cagataydev/neon-g1-kimodo-50k")
                  or Kimodo model ID (e.g., "nvidia/Kimodo-G1-RP-v1")
                - config.max_episodes: limit number of motions
                - config.fps: target fps

        Returns:
            List of NeonEpisode with G1 joint trajectories
        """
        # First try: load pre-generated dataset from HuggingFace
        if config.path.startswith("cagataydev/") or config.path.startswith("local/"):
            try:
                from datasets import load_dataset

                logger.info(f"Loading pre-generated Kimodo dataset: {config.path}")
                ds = load_dataset(config.path, split="train", streaming=True)

                episodes = []
                count = 0
                action_dim = self.action_space.action_dim

                for item in ds:
                    if config.max_episodes and count >= config.max_episodes:
                        break

                    # Extract joint positions
                    joint_positions = np.array(
                        item.get("joint_positions", item.get("observation.state", [])),
                        dtype=np.float32,
                    )
                    if joint_positions.ndim == 1:
                        joint_positions = joint_positions[np.newaxis, :]
                    T = joint_positions.shape[0]
                    if T < 2:
                        continue

                    # Map to action space
                    src_dim = joint_positions.shape[1]
                    mapped_actions = np.zeros((T, action_dim), dtype=np.float32)
                    dim = min(src_dim, action_dim)
                    mapped_actions[:, :dim] = joint_positions[:, :dim]
                    mapped_actions = self.action_space.normalize(mapped_actions)

                    language = (
                        item.get("language_instruction", "")
                        or item.get("prompt", "")
                        or item.get("text", "")
                        or "generated motion"
                    )

                    episodes.append(
                        NeonEpisode(
                            images=[],
                            actions=mapped_actions,
                            language=language,
                            proprioception=mapped_actions.copy(),
                            metadata={
                                "source": config.name,
                                "type": "kimodo",
                                "category": item.get("category", "unknown"),
                                "embodiment": "g1",
                            },
                        )
                    )
                    count += 1

                logger.info(f"Loaded {len(episodes)} Kimodo episodes from {config.path}")
                return episodes

            except Exception as e:
                logger.info(f"Pre-generated dataset not found ({e}), generating on-the-fly")

        # Second try: generate motions using KimodoGenerator
        try:
            from neon.synth.kimodo_generator import KimodoGenerator, KimodoConfig

            logger.info(f"Generating Kimodo motions from model: {config.path}")

            kimodo_config = KimodoConfig(
                model_id=config.path if config.path.startswith("nvidia/") else "nvidia/Kimodo-G1-RP-v1",
                num_episodes=config.max_episodes or 1000,
                output_fps=config.fps,
                render_in_sim=False,  # Don't render during data loading
            )

            generator = KimodoGenerator(kimodo_config)
            generator.load_model()

            motions = generator.generate_batch()
            episodes = []
            action_dim = self.action_space.action_dim

            for motion in motions:
                T = motion.num_frames
                src_dim = motion.num_joints

                mapped_actions = np.zeros((T, action_dim), dtype=np.float32)
                dim = min(src_dim, action_dim)
                mapped_actions[:, :dim] = motion.joint_positions[:, :dim]
                mapped_actions = self.action_space.normalize(mapped_actions)

                episodes.append(
                    NeonEpisode(
                        images=[],
                        actions=mapped_actions,
                        language=motion.prompt,
                        proprioception=mapped_actions.copy(),
                        metadata={
                            "source": config.name,
                            "type": "kimodo",
                            "category": motion.category,
                            "model": kimodo_config.model_id,
                            "embodiment": "g1",
                        },
                    )
                )

            logger.info(
                f"Generated {len(episodes)} Kimodo motions "
                f"({sum(ep.actions.shape[0] for ep in episodes)} total frames)"
            )
            return episodes

        except Exception as e:
            logger.error(f"Failed to load/generate Kimodo data: {e}")
            return []



    def _load_molmobot(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load from MolmoBot-Data (HuggingFace sim trajectories).

        MolmoBot-Data is synthetic manipulation data from MolmoSpaces simulator:
        - FrankaPickAndPlaceOmniCamConfig: Franka pick-and-place (multi-camera)
        - FrankaPickOmniCamConfig: Franka pick (single object)
        - RBY1 variants: Rainbow Robotics bimanual

        Data format (H5 per trajectory):
        - obs/agent/qpos/arm: (T, 7) joint positions
        - obs/agent/qpos/gripper: (T, 1) gripper state
        - actions/joint_pos/arm: (T, 7) target joint positions
        - actions/joint_pos/gripper: (T, 1) target gripper
        - obs/cameras/<cam_name>/video: (T, H, W, 3) camera frames
        - task_description: str

        Flow matching training insight from MolmoBot-Pi0:
        - Joint position actions (not deltas) work better with flow matching
        - Exo + wrist camera pairs give robust sim-to-real transfer
        - Prompt randomization (case, punctuation, synonyms) prevents overfitting
        - Auxiliary dataset mixing with weighted sampling improves generalization

        Reference: "MolmoB0T: Large-Scale Simulation Enables Zero-Shot Manipulation"
        (Deshpande et al., arXiv:2603.16861)
        """
        import h5py
        from pathlib import Path as _Path

        episodes = []
        data_root = _Path(config.path)

        # Support both local path and HuggingFace download
        if not data_root.exists():
            try:
                from huggingface_hub import snapshot_download
                logger.info(f"Downloading MolmoBot data from HuggingFace: {config.path}")
                data_root = _Path(snapshot_download(
                    config.path,
                    repo_type="dataset",
                    allow_patterns=["*.h5", "*.json", "*.mp4"],
                ))
            except Exception as e:
                logger.error(f"Failed to download MolmoBot data: {e}")
                return []

        # Find trajectory directories
        traj_dirs = sorted([
            d for d in data_root.rglob("*.h5")
            if not d.name.startswith(".")
        ])

        if not traj_dirs:
            # Try alternative: look for episode directories with H5 files
            traj_dirs = sorted([
                f for d in data_root.iterdir()
                if d.is_dir()
                for f in d.glob("*.h5")
            ])

        if config.max_episodes:
            traj_dirs = traj_dirs[:config.max_episodes]

        logger.info(f"MolmoBot: found {len(traj_dirs)} trajectories in {data_root}")

        # MolmoBot prompt randomization templates (from MolmoBot-Pi0)
        _PICK_PLACE_PROMPTS = [
            ["put the {obj} in the {target}", "place the {obj} into the {target}",
             "move the {obj} to the {target}", "pick up the {obj} and put it in the {target}"],
            ["Put the {obj} in the {target}.", "Place the {obj} into the {target}."],
        ]

        for h5_path in traj_dirs:
            try:
                with h5py.File(str(h5_path), "r") as f:
                    # Extract actions
                    if config.joint_pos_actions:
                        arm_actions = np.array(f["actions/joint_pos/arm"])  # (T, 7)
                    else:
                        arm_actions = np.array(f["actions/joint_pos_rel/arm"])  # (T, 7)

                    gripper_actions = np.array(f["actions/joint_pos/gripper"])  # (T, 1)

                    # Normalize gripper to [0, 1] range (MolmoBot convention: 0-255)
                    if gripper_actions.max() > 1.0:
                        gripper_actions = gripper_actions / 255.0

                    # Combine: (T, 8) = [arm(7), gripper(1)]
                    actions = np.concatenate([arm_actions, gripper_actions], axis=-1).astype(np.float32)

                    # Extract proprioception (current state)
                    arm_state = np.array(f["obs/agent/qpos/arm"])  # (T, 7)
                    grip_state = np.array(f["obs/agent/qpos/gripper"])  # (T, 1)
                    if grip_state.max() > 1.0:
                        grip_state = np.clip(grip_state / 0.824033, 0, 1)
                    proprio = np.concatenate([arm_state, grip_state], axis=-1).astype(np.float32)

                    # Extract camera frames (exo + wrist)
                    images = []
                    exo_key = f"obs/cameras/{config.molmobot_exo_camera}/video"
                    wrist_key = f"obs/cameras/{config.molmobot_wrist_camera}/video"

                    # Try video keys, fall back to image keys
                    for cam_key in [exo_key, wrist_key]:
                        if cam_key in f:
                            # Use first available camera
                            frames = np.array(f[cam_key])  # (T, H, W, 3)
                            images = [frames[i] for i in range(len(frames))]
                            break

                    if not images:
                        # Try any camera
                        for key in f["obs/cameras"]:
                            video_key = f"obs/cameras/{key}/video"
                            if video_key in f:
                                frames = np.array(f[video_key])
                                images = [frames[i] for i in range(len(frames))]
                                break

                    # Extract task description
                    task_desc = ""
                    if "task_description" in f.attrs:
                        task_desc = str(f.attrs["task_description"])
                    elif "task" in f.attrs:
                        task_desc = str(f.attrs["task"])
                    elif "prompt" in f:
                        task_desc = str(np.array(f["prompt"]))

                    # Prompt randomization (MolmoBot-Pi0 style)
                    if config.randomize_prompts and task_desc:
                        import random as _rng
                        # Random case variation
                        if _rng.random() < 0.3:
                            task_desc = task_desc.lower()
                        elif _rng.random() < 0.3:
                            task_desc = task_desc.capitalize()
                        # Random punctuation
                        if _rng.random() < 0.5:
                            task_desc = task_desc.rstrip(".")
                        elif not task_desc.endswith("."):
                            task_desc = task_desc + "."

                    # Trim episode (MolmoBot trims last N frames to avoid idle end)
                    trim = config.trim_episode_length
                    if trim > 0 and len(actions) > trim:
                        actions = actions[:-trim]
                        proprio = proprio[:-trim]
                        if images:
                            images = images[:-trim]

                    # Map Franka/DROID actions to G1 action space
                    mapped_actions = self.action_mapper.map_actions(
                        actions, "molmobot_droid", normalize=True,
                    )

                    episodes.append(NeonEpisode(
                        images=images,
                        actions=mapped_actions,
                        language=task_desc,
                        proprioception=proprio,
                        metadata={
                            "source": "molmobot",
                            "path": str(h5_path),
                            "embodiment": "franka_droid",
                            "action_type": "joint_pos" if config.joint_pos_actions else "joint_pos_rel",
                        },
                    ))

            except Exception as e:
                logger.warning(f"Failed to load MolmoBot trajectory {h5_path}: {e}")
                continue

        # Handle auxiliary datasets (MolmoBot-Pi0 weighted mixing)
        if config.auxiliary_datasets:
            for aux_path, aux_weight in config.auxiliary_datasets.items():
                aux_config = DataSourceConfig(
                    name=f"molmobot_aux_{Path(aux_path).name}",
                    type="molmobot",
                    path=aux_path,
                    weight=aux_weight,
                    molmobot_exo_camera=config.molmobot_exo_camera,
                    molmobot_wrist_camera=config.molmobot_wrist_camera,
                    joint_pos_actions=config.joint_pos_actions,
                    trim_episode_length=config.trim_episode_length,
                    randomize_prompts=config.randomize_prompts,
                    max_episodes=config.max_episodes,
                )
                aux_episodes = self._load_molmobot(aux_config)
                episodes.extend(aux_episodes)
                logger.info(f"MolmoBot auxiliary: {aux_path} → {len(aux_episodes)} episodes (weight={aux_weight})")

        logger.info(f"MolmoBot: loaded {len(episodes)} total episodes")
        return episodes



    def _load_tribev2_fmri(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Load from Meta's TRIBEv2 fMRI brain response predictions as training signal.

        TRIBEv2 (facebook/tribev2) predicts fMRI brain responses to naturalistic
        stimuli (video, audio, text). The predicted brain activations can be used
        as an auxiliary training signal for the VLA:

        1. **Brain-guided visual attention**: TRIBEv2 predicts which cortical
           regions activate for each video frame. High activation in visual cortex
           → salient visual features. We use this as a soft attention mask over
           the video backbone's spatial features.

        2. **Temporal brain dynamics**: Brain responses have a hemodynamic delay
           (~5s) but encode temporal structure. The predicted fMRI time series
           provides a "brain rhythm" that can regularize action chunking to
           match natural temporal patterns.

        3. **Multimodal alignment loss**: TRIBEv2's predictions for video-only
           vs audio-only vs text-only inputs reveal how the brain aligns these
           modalities. We use the cross-modal prediction gap as an auxiliary
           loss to encourage modality fusion in Neon's BrainFusion module.

        This is experimental — the idea is that brain-like representations
        might transfer well to embodied agents. The cortical surface predictions
        (~20k vertices on fsaverage5) are compressed to a low-dimensional
        "brain code" via PCA and used as an auxiliary target.

        Args:
            config: DataSourceConfig with type="tribev2_fmri"
                - config.path: HuggingFace model ID ("facebook/tribev2") or local checkpoint
                - config.max_episodes: limit number of video stimuli to process
                - config.max_samples: max brain response samples to generate

        Returns:
            List of NeonEpisode with brain activation codes as auxiliary metadata
        """
        try:
            logger.info(f"Loading TRIBEv2 brain encoder: {config.path}")

            # Try to load TRIBEv2 model
            try:
                from tribev2 import TribeModel

                model = TribeModel.from_pretrained(config.path, cache_folder="/tmp/tribev2_cache")
                logger.info("TRIBEv2 model loaded successfully")
            except ImportError:
                logger.warning(
                    "tribev2 package not installed. Install with: "
                    "pip install git+https://github.com/facebookresearch/tribev2.git"
                )
                # Fallback: generate synthetic "brain codes" as placeholder
                return self._generate_synthetic_brain_codes(config)

            # Process existing video episodes to get brain predictions
            # This retroactively adds brain response signals to visual data
            episodes = []
            action_dim = self.action_space.action_dim

            # Find video files from other loaded episodes
            video_sources = [
                ep for ep in self.episodes
                if ep.images and len(ep.images) > 0
            ]

            if not video_sources:
                logger.info("No video episodes loaded yet — generating synthetic brain codes")
                return self._generate_synthetic_brain_codes(config)

            # Process each video episode through TRIBEv2
            max_process = config.max_episodes or 100
            import tempfile
            from pathlib import Path

            for i, source_ep in enumerate(video_sources[:max_process]):
                try:
                    # Save frames as temporary video for TRIBEv2
                    # TRIBEv2 expects a video file path
                    with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as tmp:
                        tmp_path = tmp.name

                    # Write frames to video (requires imageio or similar)
                    try:
                        import imageio

                        writer = imageio.get_writer(tmp_path, fps=4)
                        for frame in source_ep.images[:32]:  # Cap frames
                            if hasattr(frame, "numpy"):
                                writer.append_data(frame.numpy())
                            else:
                                writer.append_data(np.array(frame))
                        writer.close()

                        # Get brain predictions
                        events_df = model.get_events_dataframe(video_path=tmp_path)
                        preds, segments = model.predict(events=events_df)
                        # preds: (n_timesteps, n_vertices) — ~20k cortical vertices

                        # Compress to brain code via PCA (keep top 64 components)
                        from sklearn.decomposition import PCA

                        n_components = min(64, preds.shape[1], preds.shape[0])
                        pca = PCA(n_components=n_components)
                        brain_codes = pca.fit_transform(preds)  # (T, 64)

                        # Create episode with brain codes as auxiliary signal
                        T = min(len(source_ep.images), brain_codes.shape[0])
                        episodes.append(
                            NeonEpisode(
                                images=source_ep.images[:T],
                                actions=source_ep.actions[:T] if len(source_ep.actions) >= T else np.zeros((T, action_dim), dtype=np.float32),
                                language=source_ep.language,
                                proprioception=source_ep.proprioception[:T] if source_ep.proprioception is not None else None,
                                metadata={
                                    "source": config.name,
                                    "type": "tribev2_fmri",
                                    "brain_codes": brain_codes[:T].tolist(),  # Auxiliary signal
                                    "brain_pca_variance": pca.explained_variance_ratio_.tolist(),
                                    "n_vertices": preds.shape[1],
                                    "has_brain_signal": True,
                                },
                            )
                        )

                    except ImportError:
                        logger.debug("imageio not available for video writing")
                        break
                    finally:
                        Path(tmp_path).unlink(missing_ok=True)

                except Exception as e:
                    logger.debug(f"Failed to process episode {i} through TRIBEv2: {e}")
                    continue

            if not episodes:
                return self._generate_synthetic_brain_codes(config)

            logger.info(f"Generated {len(episodes)} brain-coded episodes via TRIBEv2")
            return episodes

        except Exception as e:
            logger.error(f"Failed to load TRIBEv2: {e}")
            return self._generate_synthetic_brain_codes(config)

    def _generate_synthetic_brain_codes(self, config: DataSourceConfig) -> List[NeonEpisode]:
        """Generate synthetic brain activation codes for auxiliary training.

        When TRIBEv2 is not available, we generate synthetic brain codes
        that mimic the statistical properties of real cortical responses:
        - Hemodynamic response function (HRF) temporal profile
        - Spatial smoothness on cortical surface
        - Modality-specific activation patterns

        These serve as a regularizer — even without real brain data, the
        auxiliary brain prediction loss encourages the model to learn
        representations that have brain-like statistical properties.
        """
        logger.info("Generating synthetic brain codes (TRIBEv2 fallback)")

        episodes = []
        action_dim = self.action_space.action_dim
        n_codes = config.max_samples or 50
        brain_dim = 64  # Compressed brain code dimension

        for i in range(n_codes):
            T = 16  # Standard action chunk length

            # Generate HRF-convolved brain codes
            # HRF: double-gamma function peaks at ~5s, undershoot at ~15s
            t_axis = np.linspace(0, 8, T)
            hrf = (t_axis ** 5) * np.exp(-t_axis) / 120  # Simplified HRF
            hrf = hrf / (hrf.max() + 1e-8)

            # Brain codes: smooth temporal signal with random spatial patterns
            spatial_pattern = np.random.randn(brain_dim).astype(np.float32)
            brain_codes = np.outer(hrf, spatial_pattern)  # (T, brain_dim)
            brain_codes += 0.1 * np.random.randn(T, brain_dim).astype(np.float32)  # Noise

            episodes.append(
                NeonEpisode(
                    images=[],
                    actions=np.zeros((T, action_dim), dtype=np.float32),
                    language="auxiliary brain encoding signal",
                    proprioception=None,
                    metadata={
                        "source": config.name,
                        "type": "tribev2_fmri",
                        "brain_codes": brain_codes.tolist(),
                        "synthetic": True,
                        "has_brain_signal": True,
                        "auxiliary_only": True,  # No action loss for this source
                    },
                )
            )

        logger.info(f"Generated {len(episodes)} synthetic brain code episodes")
        return episodes


    def _sync_s3_dataset(self, s3_path: str, max_episodes: Optional[int] = None) -> Path:
        """Download dataset from S3 to local cache.

        Only downloads metadata + parquet (not videos, to save bandwidth).
        Videos are loaded on-demand during training via video_path.
        """
        import subprocess
        from pathlib import Path

        # Cache directory
        bucket_name = s3_path.split("/")[2]
        dataset_key = "/".join(s3_path.split("/")[3:]).rstrip("/")
        cache_dir = Path("/tmp/neon_datasets") / bucket_name / dataset_key
        cache_dir.mkdir(parents=True, exist_ok=True)

        # Check if already cached
        meta_dir = cache_dir / "meta"
        if (meta_dir / "info.json").exists():
            logger.info(f"Using cached dataset: {cache_dir}")
            # Check if we need more episodes
            data_dir = cache_dir / "data" / "chunk-000"
            if data_dir.exists() and any(data_dir.iterdir()):
                return cache_dir

        logger.info(f"Downloading dataset from {s3_path}...")

        # Download meta/ (small, always needed)
        subprocess.run(
            ["aws", "s3", "sync", f"{s3_path}meta/", str(meta_dir) + "/",
             "--profile", "default", "--quiet"],
            check=False, capture_output=True,
        )

        # Download parquet data (selective if max_episodes is set)
        data_dir = cache_dir / "data" / "chunk-000"
        data_dir.mkdir(parents=True, exist_ok=True)

        if max_episodes:
            # Download only the episodes we need
            for i in range(max_episodes):
                fname = f"episode_{i:06d}.parquet"
                subprocess.run(
                    ["aws", "s3", "cp",
                     f"{s3_path}data/chunk-000/{fname}",
                     str(data_dir / fname),
                     "--profile", "default", "--quiet"],
                    check=False, capture_output=True,
                )
        else:
            # Download all parquet files
            subprocess.run(
                ["aws", "s3", "sync",
                 f"{s3_path}data/", str(cache_dir / "data") + "/",
                 "--profile", "default", "--quiet"],
                check=False, capture_output=True,
            )

        logger.info(f"Dataset cached at {cache_dir}")
        return cache_dir

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        """Get a single training sample.

        Returns:
            Dict with:
                - "image": Current frame (PIL Image)
                - "video_frames": Recent frames list
                - "language": Instruction text
                - "proprioception": Current joint state (action_dim,)
                - "target_actions": Future action chunk (chunk_size, action_dim)
                - "action_mask": Valid timestep mask (chunk_size,)
        """
        ep_idx, t = self.samples[idx]
        episode = self.episodes[ep_idx]
        chunk = self.config.action_chunk_size

        # Current observation
        image = episode.images[t] if t < len(episode.images) else None

        # Recent frames for video context (up to 4 past frames)
        video_start = max(0, t - 3)
        video_frames = episode.images[video_start : t + 1] if episode.images else []

        # Language instruction
        language = episode.language

        # Current proprioception
        proprio = None
        if episode.proprioception is not None and t < len(episode.proprioception):
            proprio = episode.proprioception[t].astype(np.float32)

        # Future action chunk (target)
        action_end = min(t + chunk, episode.length)
        target_actions = episode.actions[t:action_end]

        # Pad if needed
        actual_steps = target_actions.shape[0]
        if actual_steps < chunk:
            pad = np.zeros((chunk - actual_steps, target_actions.shape[1]), dtype=np.float32)
            target_actions = np.concatenate([target_actions, pad], axis=0)

        # Mask: 1 for valid steps, 0 for padding
        mask = np.zeros(chunk, dtype=np.float32)
        mask[:actual_steps] = 1.0

        return {
            "image": image,
            "video_frames": video_frames,
            "language": language,
            "proprioception": proprio,
            "target_actions": target_actions,
            "action_mask": mask,
            # Omni-modal inputs (may be None if dataset doesn't have them)
            "audio": episode.audio[t] if episode.audio is not None and t < len(episode.audio) else None,
            "lidar": episode.lidar[t].astype(np.float32) if episode.lidar is not None and t < len(episode.lidar) else None,
            "eef_state": episode.eef_state[t].astype(np.float32) if episode.eef_state is not None and t < len(episode.eef_state) else None,
            "metadata": episode.metadata,
            # Training flags — checked by loss computation
            "language_only": episode.metadata.get("language_only", False),
            "visual_only": episode.metadata.get("visual_only", False),
        }

    def get_sampler(self) -> WeightedRandomSampler:
        """Get a weighted sampler that respects source weights."""
        sample_weights = []
        for ep_idx, _ in self.samples:
            sample_weights.append(self.source_weights[ep_idx])

        return WeightedRandomSampler(
            weights=sample_weights,
            num_samples=len(self.samples),
            replacement=True,
        )
