"""
G1 Action Space — 29 DoF humanoid action definition.

The Unitree G1 humanoid has 29 controllable joints organized into groups.
This module defines the action space, joint limits, normalization, and PD gains.

Joint limits, PD gains, default positions, and velocity limits are sourced from
GR00T-WholeBodyControl (GEAR-SONIC) g1_29dof_sonic_model12.yaml — the
production config used to deploy SONIC on real G1 hardware.

Reference:
- GR00T-WBC: github.com/NVlabs/GR00T-WholeBodyControl
- SONIC: arxiv.org/abs/2511.07820
- Unitree G1 URDF (29 DoF + 14 hand DoF = 43 total)
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Tuple

import numpy as np


class ControlMode(Enum):
    """Control modes for the G1 and aerial platforms."""

    ARMS_ONLY = "arms_only"  # 14 DoF arms + 3 locomotion vel
    UPPER_BODY = "upper_body"  # Arms + torso (17 DoF)
    WHOLE_BODY = "whole_body"  # All 29 DoF
    WHOLE_BODY_HANDS = "whole_body_hands"  # 43 DoF (29 body + 14 hand fingers)
    # Aerial modes — adapted from AirVLA (Stanford/Physical Intelligence)
    AERIAL_NAV = "aerial_nav"  # 4 DoF: x, y, z, yaw (drone navigation)
    AERIAL_MANIP = "aerial_manip"  # 5 DoF: x, y, z, yaw + gripper (aerial manipulation)
    AERIAL_FULL = "aerial_full"  # 7 DoF: x, y, z, roll, pitch, yaw + gripper


@dataclass
class JointInfo:
    """Information about a single joint.

    PD gains from GR00T-WBC SONIC config (g1_29dof_sonic_model12.yaml).
    These are the production values used on real G1 hardware.
    """

    name: str
    index: int  # Index in the SONIC 29-DoF ordering (legs→waist→arms)
    group: str  # "left_arm", "right_arm", "torso", "left_leg", "right_leg"
    lower_limit: float  # Radians — from URDF via GR00T-WBC
    upper_limit: float  # Radians — from URDF via GR00T-WBC
    default_pos: float = 0.0  # Default standing position (SONIC DEFAULT_DOF_ANGLES)
    kp: float = 100.0  # PD proportional gain (SONIC MOTOR_KP)
    kd: float = 2.0  # PD derivative gain (SONIC MOTOR_KD)
    vel_limit: float = 37.0  # Velocity limit rad/s (SONIC motor_vel_limit_list)
    effort_limit: float = 25.0  # Torque limit Nm (SONIC motor_effort_limit_list)


# fmt: off
# =============================================================================
# G1 joint definitions (29 joints) — SONIC ordering
# =============================================================================
# Source: GR00T-WholeBodyControl g1_29dof_sonic_model12.yaml
# Source: G1SupplementalInfo.joint_limits (from URDF)
# Ordering: legs(12) → waist(3) → left_arm(7) → right_arm(7)
#
# IMPORTANT: This ordering matches SONIC/GR00T-WBC exactly.
# When mapping from other datasets, use G1_NEON_TO_SONIC_MAP.
# =============================================================================

G1_JOINTS: List[JointInfo] = [
    # Left Leg (6 DoF) — indices 0-5
    JointInfo("left_hip_pitch",    0,  "left_leg",  -2.5307,  2.8798, -0.10, kp=150, kd=2, vel_limit=32.0, effort_limit=88.0),
    JointInfo("left_hip_roll",     1,  "left_leg",  -0.5236,  2.9671,  0.00, kp=150, kd=2, vel_limit=32.0, effort_limit=88.0),
    JointInfo("left_hip_yaw",      2,  "left_leg",  -2.7576,  2.7576,  0.00, kp=150, kd=2, vel_limit=32.0, effort_limit=88.0),
    JointInfo("left_knee",         3,  "left_leg",  -0.0873,  2.8798,  0.30, kp=200, kd=4, vel_limit=20.0, effort_limit=139.0),
    JointInfo("left_ankle_pitch",  4,  "left_leg",  -0.8727,  0.5236, -0.20, kp=40,  kd=2, vel_limit=37.0, effort_limit=50.0),
    JointInfo("left_ankle_roll",   5,  "left_leg",  -0.2618,  0.2618,  0.00, kp=40,  kd=2, vel_limit=37.0, effort_limit=50.0),

    # Right Leg (6 DoF) — indices 6-11
    JointInfo("right_hip_pitch",   6,  "right_leg", -2.5307,  2.8798, -0.10, kp=150, kd=2, vel_limit=32.0, effort_limit=88.0),
    JointInfo("right_hip_roll",    7,  "right_leg", -2.9671,  0.5236,  0.00, kp=150, kd=2, vel_limit=32.0, effort_limit=88.0),
    JointInfo("right_hip_yaw",     8,  "right_leg", -2.7576,  2.7576,  0.00, kp=150, kd=2, vel_limit=32.0, effort_limit=88.0),
    JointInfo("right_knee",        9,  "right_leg", -0.0873,  2.8798,  0.30, kp=200, kd=4, vel_limit=20.0, effort_limit=139.0),
    JointInfo("right_ankle_pitch", 10, "right_leg", -0.8727,  0.5236, -0.20, kp=40,  kd=2, vel_limit=37.0, effort_limit=50.0),
    JointInfo("right_ankle_roll",  11, "right_leg", -0.2618,  0.2618,  0.00, kp=40,  kd=2, vel_limit=37.0, effort_limit=50.0),

    # Waist / Torso (3 DoF) — indices 12-14
    JointInfo("waist_yaw",         12, "torso",     -2.618,   2.618,   0.00, kp=250, kd=5, vel_limit=32.0, effort_limit=88.0),
    JointInfo("waist_roll",        13, "torso",     -0.52,    0.52,    0.00, kp=250, kd=5, vel_limit=37.0, effort_limit=50.0),
    JointInfo("waist_pitch",       14, "torso",     -0.52,    0.52,    0.00, kp=250, kd=5, vel_limit=37.0, effort_limit=50.0),

    # Left Arm (7 DoF) — indices 15-21
    JointInfo("left_shoulder_pitch",  15, "left_arm",  -3.0892,  2.6704,  0.00, kp=100, kd=5, vel_limit=37.0, effort_limit=25.0),
    JointInfo("left_shoulder_roll",   16, "left_arm",  -1.5882,  2.2515,  0.00, kp=100, kd=5, vel_limit=37.0, effort_limit=25.0),
    JointInfo("left_shoulder_yaw",    17, "left_arm",  -2.618,   2.618,   0.00, kp=40,  kd=2, vel_limit=37.0, effort_limit=25.0),
    JointInfo("left_elbow",           18, "left_arm",  -1.0472,  2.0944,  0.00, kp=40,  kd=2, vel_limit=37.0, effort_limit=25.0),
    JointInfo("left_wrist_roll",      19, "left_arm",  -1.9722,  1.9722,  0.00, kp=20,  kd=2, vel_limit=37.0, effort_limit=5.0),
    JointInfo("left_wrist_pitch",     20, "left_arm",  -1.6144,  1.6144,  0.00, kp=20,  kd=2, vel_limit=22.0, effort_limit=5.0),
    JointInfo("left_wrist_yaw",       21, "left_arm",  -1.6144,  1.6144,  0.00, kp=20,  kd=2, vel_limit=22.0, effort_limit=5.0),

    # Right Arm (7 DoF) — indices 22-28
    JointInfo("right_shoulder_pitch", 22, "right_arm", -3.0892,  2.6704,  0.00, kp=100, kd=5, vel_limit=37.0, effort_limit=25.0),
    JointInfo("right_shoulder_roll",  23, "right_arm", -2.2515,  1.5882,  0.00, kp=100, kd=5, vel_limit=37.0, effort_limit=25.0),
    JointInfo("right_shoulder_yaw",   24, "right_arm", -2.618,   2.618,   0.00, kp=40,  kd=2, vel_limit=37.0, effort_limit=25.0),
    JointInfo("right_elbow",          25, "right_arm", -1.0472,  2.0944,  0.00, kp=40,  kd=2, vel_limit=37.0, effort_limit=25.0),
    JointInfo("right_wrist_roll",     26, "right_arm", -1.9722,  1.9722,  0.00, kp=20,  kd=2, vel_limit=37.0, effort_limit=5.0),
    JointInfo("right_wrist_pitch",    27, "right_arm", -1.6144,  1.6144,  0.00, kp=20,  kd=2, vel_limit=22.0, effort_limit=5.0),
    JointInfo("right_wrist_yaw",      28, "right_arm", -1.6144,  1.6144,  0.00, kp=20,  kd=2, vel_limit=22.0, effort_limit=5.0),
]

# G1 hand joints (14 DoF: 7 per hand) — extends the 29-DoF body
# Limits from GR00T-WBC G1SupplementalInfo
G1_HAND_JOINTS: List[JointInfo] = [
    # Left Hand (7 DoF) — indices 29-35
    JointInfo("left_hand_thumb_0",    29, "left_hand",  -1.0472,  1.0472, 0.0, kp=5, kd=0.1),
    JointInfo("left_hand_thumb_1",    30, "left_hand",  -0.7243,  1.0472, 0.0, kp=5, kd=0.1),
    JointInfo("left_hand_thumb_2",    31, "left_hand",   0.0,     1.7453, 0.0, kp=5, kd=0.1),
    JointInfo("left_hand_index_0",    32, "left_hand",  -1.5708,  0.0,    0.0, kp=5, kd=0.1),
    JointInfo("left_hand_index_1",    33, "left_hand",  -1.7453,  0.0,    0.0, kp=5, kd=0.1),
    JointInfo("left_hand_middle_0",   34, "left_hand",  -1.5708,  0.0,    0.0, kp=5, kd=0.1),
    JointInfo("left_hand_middle_1",   35, "left_hand",  -1.7453,  0.0,    0.0, kp=5, kd=0.1),

    # Right Hand (7 DoF) — indices 36-42
    JointInfo("right_hand_thumb_0",   36, "right_hand", -1.0472,  1.0472, 0.0, kp=5, kd=0.1),
    JointInfo("right_hand_thumb_1",   37, "right_hand", -0.7243,  1.0472, 0.0, kp=5, kd=0.1),
    JointInfo("right_hand_thumb_2",   38, "right_hand",  0.0,     1.7453, 0.0, kp=5, kd=0.1),
    JointInfo("right_hand_index_0",   39, "right_hand", -1.5708,  0.0,    0.0, kp=5, kd=0.1),
    JointInfo("right_hand_index_1",   40, "right_hand", -1.7453,  0.0,    0.0, kp=5, kd=0.1),
    JointInfo("right_hand_middle_0",  41, "right_hand", -1.5708,  0.0,    0.0, kp=5, kd=0.1),
    JointInfo("right_hand_middle_1",  42, "right_hand", -1.7453,  0.0,    0.0, kp=5, kd=0.1),
]
# fmt: on

# Combined 43-DoF joint list (body + hands)
G1_JOINTS_WITH_HANDS: List[JointInfo] = G1_JOINTS + G1_HAND_JOINTS


# =============================================================================
# Observation scales — from GR00T-WBC SONIC obs_scales config
# =============================================================================
# These scales are applied to observations BEFORE feeding to the policy.
# Critical for training stability — mis-scaled obs = divergent training.

OBS_SCALES = {
    "base_lin_vel": 2.0,
    "base_ang_vel": 0.25,
    "projected_gravity": 1.0,
    "command_lin_vel": 1.0,
    "command_ang_vel": 1.0,
    "command_stand": 1.0,
    "command_base_height": 2.0,  # "Yuanhang: it's 2, not 1!" — from SONIC yaml
    "dof_pos": 1.0,
    "dof_vel": 0.05,  # Key: velocities are scaled down 20× for stability
    "actions": 1.0,
}


# =============================================================================
# SONIC-compatible joint ordering and dataset mapping
# =============================================================================

# Joint ordering in the S3 pick-basket dataset (43-DOF)
# This maps the dataset column order → G1 joint indices
G1_DATASET_JOINT_NAMES = [
    "left_hip_pitch_joint", "left_hip_roll_joint", "left_hip_yaw_joint",
    "left_knee_joint", "left_ankle_pitch_joint", "left_ankle_roll_joint",
    "right_hip_pitch_joint", "right_hip_roll_joint", "right_hip_yaw_joint",
    "right_knee_joint", "right_ankle_pitch_joint", "right_ankle_roll_joint",
    "waist_yaw_joint", "waist_roll_joint", "waist_pitch_joint",
    "left_shoulder_pitch_joint", "left_shoulder_roll_joint",
    "left_shoulder_yaw_joint", "left_elbow_joint",
    "left_wrist_roll_joint", "left_wrist_pitch_joint", "left_wrist_yaw_joint",
    "left_hand_index_0_joint", "left_hand_index_1_joint",
    "left_hand_middle_0_joint", "left_hand_middle_1_joint",
    "left_hand_thumb_0_joint", "left_hand_thumb_1_joint", "left_hand_thumb_2_joint",
    "right_shoulder_pitch_joint", "right_shoulder_roll_joint",
    "right_shoulder_yaw_joint", "right_elbow_joint",
    "right_wrist_roll_joint", "right_wrist_pitch_joint", "right_wrist_yaw_joint",
    "right_hand_index_0_joint", "right_hand_index_1_joint",
    "right_hand_middle_0_joint", "right_hand_middle_1_joint",
    "right_hand_thumb_0_joint", "right_hand_thumb_1_joint", "right_hand_thumb_2_joint",
]

# SONIC standing position for upper body (17 joints: waist + arms)
# Used by SONIC's locomotion policy as the reference upper body pose.
# From loco_upper_body_dof_pos in g1_29dof_sonic_model12.yaml
SONIC_LOCO_UPPER_BODY_DEFAULT = np.array([
    0.0, 0.0, 0.0,               # waist (yaw, roll, pitch)
    0.0, 0.3, 0.0, 1.0,          # left arm (shoulder_p, shoulder_r, shoulder_y, elbow)
    0.0, 0.0, 0.0,               # left wrist (roll, pitch, yaw)
    0.0, -0.3, 0.0, 1.0,         # right arm (shoulder_p, shoulder_r, shoulder_y, elbow)
    0.0, 0.0, 0.0,               # right wrist (roll, pitch, yaw)
], dtype=np.float32)




# =============================================================================
# Aerial Action Space — adapted from AirVLA (Stanford / Physical Intelligence)
# =============================================================================
# AirVLA: "π, But Make It Fly" — Tucker et al. 2026, arXiv:2603.25038
#
# Key insight: VLA visual representations transfer from arms to drones,
# but control dynamics DON'T. Aerial platforms need:
# 1. Delta end-effector pose commands (not joint angles)
# 2. Payload-aware guidance at inference time
# 3. Real-Time Chunking for asynchronous execution
#
# Action space: relative EE pose at 10Hz → PX4 flight controller
# Observation: 3 cameras (256×256) + pose from MoCap + gripper aperture

# fmt: off
AERIAL_NAV_JOINTS: List[JointInfo] = [
    # 4-DOF navigation: delta position + yaw
    JointInfo("delta_x",   0, "aerial_pos",  -2.0,  2.0, 0.0, kp=1.0, kd=0.1, vel_limit=2.0, effort_limit=10.0),
    JointInfo("delta_y",   1, "aerial_pos",  -2.0,  2.0, 0.0, kp=1.0, kd=0.1, vel_limit=2.0, effort_limit=10.0),
    JointInfo("delta_z",   2, "aerial_pos",  -1.0,  1.0, 0.0, kp=1.0, kd=0.1, vel_limit=1.0, effort_limit=10.0),
    JointInfo("delta_yaw", 3, "aerial_rot",  -3.14, 3.14, 0.0, kp=0.5, kd=0.05, vel_limit=3.14, effort_limit=5.0),
]

AERIAL_MANIP_JOINTS: List[JointInfo] = [
    # 5-DOF aerial manipulation: delta pos + yaw + gripper
    JointInfo("delta_x",      0, "aerial_pos",    -2.0,  2.0, 0.0, kp=1.0, kd=0.1, vel_limit=2.0, effort_limit=10.0),
    JointInfo("delta_y",      1, "aerial_pos",    -2.0,  2.0, 0.0, kp=1.0, kd=0.1, vel_limit=2.0, effort_limit=10.0),
    JointInfo("delta_z",      2, "aerial_pos",    -1.0,  1.0, 0.0, kp=1.0, kd=0.1, vel_limit=1.0, effort_limit=10.0),
    JointInfo("delta_yaw",    3, "aerial_rot",    -3.14, 3.14, 0.0, kp=0.5, kd=0.05, vel_limit=3.14, effort_limit=5.0),
    JointInfo("gripper",      4, "aerial_gripper", 0.0,  1.0, 0.0, kp=1.0, kd=0.1, vel_limit=5.0, effort_limit=2.0),
]

AERIAL_FULL_JOINTS: List[JointInfo] = [
    # 7-DOF full aerial: delta pos + full orientation + gripper
    JointInfo("delta_x",      0, "aerial_pos",    -2.0,  2.0, 0.0, kp=1.0, kd=0.1, vel_limit=2.0, effort_limit=10.0),
    JointInfo("delta_y",      1, "aerial_pos",    -2.0,  2.0, 0.0, kp=1.0, kd=0.1, vel_limit=2.0, effort_limit=10.0),
    JointInfo("delta_z",      2, "aerial_pos",    -1.0,  1.0, 0.0, kp=1.0, kd=0.1, vel_limit=1.0, effort_limit=10.0),
    JointInfo("delta_roll",   3, "aerial_rot",    -0.5,  0.5, 0.0, kp=0.5, kd=0.05, vel_limit=1.0, effort_limit=5.0),
    JointInfo("delta_pitch",  4, "aerial_rot",    -0.5,  0.5, 0.0, kp=0.5, kd=0.05, vel_limit=1.0, effort_limit=5.0),
    JointInfo("delta_yaw",    5, "aerial_rot",    -3.14, 3.14, 0.0, kp=0.5, kd=0.05, vel_limit=3.14, effort_limit=5.0),
    JointInfo("gripper",      6, "aerial_gripper", 0.0,  1.0, 0.0, kp=1.0, kd=0.1, vel_limit=5.0, effort_limit=2.0),
]
# fmt: on

# Lookup map: ControlMode → joint list
AERIAL_JOINTS: Dict[ControlMode, List[JointInfo]] = {
    ControlMode.AERIAL_NAV: AERIAL_NAV_JOINTS,
    ControlMode.AERIAL_MANIP: AERIAL_MANIP_JOINTS,
    ControlMode.AERIAL_FULL: AERIAL_FULL_JOINTS,
}

# Payload mass estimates for guidance (kg) — typical objects for indoor drone manipulation
# From AirVLA Table 3: penguin (~0.05kg), sandwich (~0.15kg), box (~0.25kg)
AERIAL_PAYLOAD_MASS_ESTIMATES = {
    "light": 0.05,   # Stuffed animals, small toys
    "medium": 0.15,  # Food items, small tools
    "heavy": 0.25,   # Boxes, containers
}

@dataclass
class G1ActionSpace:
    """G1/Aerial action space with normalization and group-based access.

    Provides:
    - Joint-level access by name or index
    - Group-level access (left_arm, right_arm, etc.)
    - Normalization to [-1, 1] based on joint limits
    - Mode-based masking (arms_only, upper_body, whole_body, aerial_*)
    - Locomotion velocity (vx, vy, omega) as separate output (ground only)
    - Aerial platforms: position/orientation delta commands (AirVLA style)
    """

    mode: ControlMode = ControlMode.ARMS_ONLY
    include_locomotion: bool = True  # 3 extra dims for (vx, vy, omega)

    # Locomotion limits (m/s, m/s, rad/s)
    locomotion_limits: Tuple[float, float, float] = (1.5, 0.5, 1.0)

    def __post_init__(self):
        # Aerial modes use their own joint definitions, not G1 joints
        if self.mode.value.startswith("aerial"):
            all_joints = AERIAL_JOINTS[self.mode]
            self._is_aerial = True
        elif self.mode == ControlMode.WHOLE_BODY_HANDS:
            all_joints = G1_JOINTS_WITH_HANDS
            self._is_aerial = False
        else:
            all_joints = G1_JOINTS
            self._is_aerial = False
        self._joints = {j.name: j for j in all_joints}
        self._groups: Dict[str, List[JointInfo]] = {}
        for j in all_joints:
            self._groups.setdefault(j.group, []).append(j)

    @property
    def is_aerial(self) -> bool:
        """Whether this action space is for an aerial platform."""
        return self._is_aerial

    @property
    def num_joints(self) -> int:
        """Number of controlled joints for current mode."""
        return len(self.active_joints)

    @property
    def action_dim(self) -> int:
        """Total action dimension (joints + optional locomotion)."""
        dim = self.num_joints
        if self.include_locomotion and not self._is_aerial:
            dim += 3  # vx, vy, omega (ground robots only)
        return dim

    @property
    def active_joints(self) -> List[JointInfo]:
        """Joints active in the current control mode."""
        if self._is_aerial:
            return AERIAL_JOINTS[self.mode]
        elif self.mode == ControlMode.ARMS_ONLY:
            return self._groups.get("left_arm", []) + self._groups.get("right_arm", [])
        elif self.mode == ControlMode.UPPER_BODY:
            return (
                self._groups.get("left_arm", [])
                + self._groups.get("right_arm", [])
                + self._groups.get("torso", [])
                + self._groups.get("head", [])
            )
        elif self.mode == ControlMode.WHOLE_BODY_HANDS:
            return G1_JOINTS_WITH_HANDS
        else:  # WHOLE_BODY
            return G1_JOINTS

    @property
    def active_indices(self) -> List[int]:
        """Indices of active joints in the full 29-DoF vector."""
        return [j.index for j in self.active_joints]

    @property
    def joint_names(self) -> List[str]:
        """Names of active joints."""
        return [j.name for j in self.active_joints]

    def normalize(self, actions: np.ndarray) -> np.ndarray:
        """Normalize raw joint positions to [-1, 1].

        Args:
            actions: Raw joint positions, shape (..., action_dim)

        Returns:
            Normalized actions in [-1, 1], same shape
        """
        result = np.zeros_like(actions)
        joints = self.active_joints
        n_joints = len(joints)

        for i, joint in enumerate(joints):
            lo, hi = joint.lower_limit, joint.upper_limit
            mid = (lo + hi) / 2
            half_range = (hi - lo) / 2
            if half_range > 0:
                result[..., i] = (actions[..., i] - mid) / half_range
            else:
                result[..., i] = 0.0

        # Normalize locomotion if present
        if self.include_locomotion and actions.shape[-1] > n_joints:
            for k, limit in enumerate(self.locomotion_limits):
                idx = n_joints + k
                if limit > 0:
                    result[..., idx] = actions[..., idx] / limit

        return np.clip(result, -1.0, 1.0)

    def denormalize(self, actions: np.ndarray) -> np.ndarray:
        """Denormalize [-1, 1] actions to raw joint positions.

        Args:
            actions: Normalized actions in [-1, 1], shape (..., action_dim)

        Returns:
            Raw joint positions, same shape
        """
        result = np.zeros_like(actions)
        joints = self.active_joints
        n_joints = len(joints)

        for i, joint in enumerate(joints):
            lo, hi = joint.lower_limit, joint.upper_limit
            mid = (lo + hi) / 2
            half_range = (hi - lo) / 2
            result[..., i] = actions[..., i] * half_range + mid

        # Denormalize locomotion
        if self.include_locomotion and actions.shape[-1] > n_joints:
            for k, limit in enumerate(self.locomotion_limits):
                idx = n_joints + k
                result[..., idx] = actions[..., idx] * limit

        return result

    def default_position(self) -> np.ndarray:
        """Get default standing position for active joints."""
        joints = self.active_joints
        pos = np.array([j.default_pos for j in joints], dtype=np.float32)
        if self.include_locomotion:
            pos = np.concatenate([pos, np.zeros(3, dtype=np.float32)])
        return pos

    def get_group_indices(self, group: str) -> List[int]:
        """Get indices within the active action vector for a joint group.

        Args:
            group: One of "left_arm", "right_arm", "torso", "head", "left_leg", "right_leg"

        Returns:
            List of indices within the active action vector
        """
        active_names = self.joint_names
        group_joints = self._groups.get(group, [])
        return [active_names.index(j.name) for j in group_joints if j.name in active_names]

    def split_action(self, action: np.ndarray) -> Dict[str, np.ndarray]:
        """Split a full action vector into named groups.

        Returns dict with keys: left_arm, right_arm, torso, head, left_leg, right_leg,
        left_hand, right_hand (if WHOLE_BODY_HANDS), locomotion
        """
        result = {}
        groups = ["left_arm", "right_arm", "torso", "head", "left_leg", "right_leg"]
        if self.mode == ControlMode.WHOLE_BODY_HANDS:
            groups.extend(["left_hand", "right_hand"])

        for group_name in groups:
            indices = self.get_group_indices(group_name)
            if indices:
                result[group_name] = action[..., indices]

        if self.include_locomotion:
            n = self.num_joints
            result["locomotion"] = action[..., n : n + 3]

        return result

    def to_dict(self) -> Dict:
        """Serialize to dict for config files."""
        return {
            "mode": self.mode.value,
            "include_locomotion": self.include_locomotion,
            "locomotion_limits": list(self.locomotion_limits),
            "num_joints": self.num_joints,
            "action_dim": self.action_dim,
            "joint_names": self.joint_names,
        }

    @classmethod
    def from_dict(cls, d: Dict) -> "G1ActionSpace":
        """Deserialize from dict."""
        return cls(
            mode=ControlMode(d["mode"]),
            include_locomotion=d.get("include_locomotion", True),
            locomotion_limits=tuple(d.get("locomotion_limits", (1.5, 0.5, 1.0))),
        )

    def __repr__(self) -> str:
        return (
            f"G1ActionSpace(mode={self.mode.value}, "
            f"joints={self.num_joints}, action_dim={self.action_dim})"
        )
