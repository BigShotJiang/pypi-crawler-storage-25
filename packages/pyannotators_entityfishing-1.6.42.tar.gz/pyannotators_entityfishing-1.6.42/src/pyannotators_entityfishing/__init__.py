"""Annotator based on entity-fishing"""

__version__ = "1.6.42"
