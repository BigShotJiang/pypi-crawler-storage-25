"""
corteX - Enterprise AI Agent SDK

Brain-inspired intelligence layer for production AI agents.
Works with LangChain, CrewAI, OpenAI Agents, Google ADK, and more.

This package is currently in early access.
"""

__version__ = "0.0.1"

print()
print("  corteX SDK - Early Access")
print("  -------------------------")
print("  This SDK is currently available by invitation only.")
print()
print("  To request access:")
print("    Website:  https://cortex.questo.media")
print("    Email:    netanel@questo.media")
print("    Phone:    +972-52-231-3366")
print("    Contact:  Netanel Bezalel")
print()
