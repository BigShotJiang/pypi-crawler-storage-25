# corteX - Enterprise AI Agent SDK

Brain-inspired intelligence layer for production AI agents.

## Early Access

corteX is currently in early access. To request access:

- Website: https://cortex.questo.media
- Email: netanel@questo.media
- Phone: +972-52-231-3366
- Contact: Netanel Bezalel

## What is corteX?

corteX adds a learning brain to your existing AI agents. It works as a layer on top of LangChain, CrewAI, OpenAI Agents SDK, Google ADK, and others - no rewrite needed.

Your agents learn from every interaction, remember what works, adapt to their environment, and improve over time. All on-prem, all enterprise-ready.

## Features

- 20+ brain components based on neuroscience research
- Synaptic weights that learn tool preferences from experience
- Episodic memory that persists across sessions
- Dual-process routing (fast/cheap vs slow/accurate)
- Provider-agnostic (OpenAI, Gemini, local models)
- Full on-premises deployment support
- Enterprise compliance (SOC 2, GDPR ready)

## Patent

corteX cognitive architecture is patent-pending.
