"""Orchestrator - coordinates parallel agent work across tasks."""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from pathlib import Path

from rich.console import Console
from rich.live import Live
from rich.table import Table
from rich.text import Text

from .agents import AgentResult, Role, TaskStatus, run_merge_resolver, run_pipeline
from .path_resolver import resolve_agents_config_paths, resolve_profile_paths
from .plan_parser import Plan, Task
from .profile import Profile
from .session_status import SessionStatus
from .worktree import (
    Worktree,
    attach_worktree,
    branch_exists,
    cleanup_merge_worktree,
    complete_merge,
    create_session_branch,
    create_worktree,
    delete_branch,
    get_main_branch,
    get_merged_branches,
    merge_into_session,
    push_session_branch,
)


@dataclass
class TaskState:
    task: Task
    worktree: Worktree | None = None
    status: TaskStatus = TaskStatus.PENDING
    results: list[AgentResult] = field(default_factory=list)
    started_at: float | None = None
    finished_at: float | None = None
    pending_persists: list[asyncio.Task] = field(default_factory=list)
    wave_num: int = 0
    merged: bool = False
    merge_error: bool = False
    resume_stages: list[str] = field(default_factory=list)
    prior_results: list[AgentResult] = field(default_factory=list)

    @property
    def elapsed(self) -> str:
        if self.started_at is None:
            return "-"
        end = self.finished_at or time.time()
        mins = int(end - self.started_at) // 60
        secs = int(end - self.started_at) % 60
        return f"{mins}m{secs:02d}s"

    @property
    def fix_count(self) -> int:
        """How many fix cycles have run."""
        return sum(1 for r in self.results if r.role == Role.FIXER)

    @property
    def phase_summary(self) -> str:
        """Short summary of where we are in the pipeline."""
        phases = []
        for r in self.results:
            if r.role == Role.IMPLEMENTOR:
                phases.append("impl:ok" if r.status != TaskStatus.FAILED else "impl:fail")
            elif r.role == Role.TESTER:
                if r.passed:
                    phases.append("test:pass")
                elif r.status == TaskStatus.FAILED:
                    phases.append("test:crash")
                else:
                    phases.append(f"test:fail")
            elif r.role == Role.FIXER:
                phases.append("fix" if r.status != TaskStatus.FAILED else "fix:fail")
            elif r.role == Role.REVIEWER:
                if r.passed:
                    phases.append("review:pass")
                elif r.status == TaskStatus.FAILED:
                    phases.append("review:crash")
                else:
                    phases.append(f"review:fail")

        in_progress = {
            TaskStatus.IMPLEMENTING: "impl…",
            TaskStatus.TESTING: "test…",
            TaskStatus.REVIEWING: "review…",
            TaskStatus.FIXING: "fix…",
            TaskStatus.MERGING: "merge…",
        }
        if self.status in in_progress:
            phases.append(in_progress[self.status])

        return " → ".join(phases)


def _status_table(states: list[TaskState]) -> Table:
    table = Table(title="Workbench", show_lines=True)
    table.add_column("Task", style="bold", min_width=30)
    table.add_column("Wave", justify="center", min_width=4)
    table.add_column("Status", min_width=14)
    table.add_column("Branch", min_width=20)
    table.add_column("Time", min_width=8)
    table.add_column("Pipeline", min_width=40)
    table.add_column("Merged", justify="center", min_width=7)

    status_styles = {
        TaskStatus.PENDING: "dim",
        TaskStatus.IMPLEMENTING: "yellow",
        TaskStatus.TESTING: "cyan",
        TaskStatus.REVIEWING: "magenta",
        TaskStatus.FIXING: "yellow bold",
        TaskStatus.MERGING: "blue bold",
        TaskStatus.DONE: "green",
        TaskStatus.FAILED: "red bold",
    }

    for s in states:
        style = status_styles.get(s.status, "")
        wave = str(s.wave_num) if s.wave_num else "-"
        branch = s.worktree.branch if s.worktree else "-"
        pipeline = s.phase_summary or ""
        if s.merged:
            merged = Text("✓", style="green")
        elif s.merge_error:
            merged = Text("✗", style="red")
        else:
            merged = Text("-", style="dim")

        table.add_row(
            s.task.title,
            wave,
            Text(s.status.value, style=style),
            branch,
            s.elapsed,
            pipeline,
            merged,
        )

    return table


async def run_plan(
    plan: Plan,
    repo: Path,
    max_concurrent: int = 4,
    max_retries: int = 2,
    skip_test: bool = False,
    skip_review: bool = False,
    agent_cmd: str = "claude",
    cleanup_on_done: bool = False,
    session_branch: str | None = None,
    start_wave: int = 1,
    end_wave: int | None = None,
    use_tmux: bool = True,
    directives: dict[Role, str] | None = None,
    tdd: bool = False,
    local: bool = False,
    base_branch: str | None = None,
    profile_path: Path | None = None,
    profile_name: str | None = None,
    session_name: str | None = None,
    keep_branches: bool = False,
    retry_failed: bool = False,
    fail_fast: bool = False,
    only_incomplete: bool = False,
    task_filter: set[str] | None = None,
    push: bool = False,
    agents_config_paths: list[Path] | None = None,
) -> list[TaskState]:
    """Execute a plan with parallel agent workers."""
    console = Console()
    profile_paths = resolve_profile_paths(
        repo,
        plan_slug=plan.folder_id,
        explicit_path=profile_path,
        name=profile_name,
    )
    profile = Profile.from_layered_yaml(list(reversed(profile_paths)))
    if agents_config_paths is None:
        agents_config_paths = resolve_agents_config_paths(repo, plan_slug=plan.folder_id)
    waves = plan.independent_groups
    all_states: list[TaskState] = []
    state_map: dict[str, TaskState] = {}

    # session_branch and session_name are aliases for "the session branch name
    # to use for this run". Both create-from-base if missing and reuse if it
    # already exists. session_branch wins if both are set; warn if they differ.
    declared = session_branch or session_name
    if session_branch and session_name and session_branch != session_name:
        console.print(
            f"[yellow]Both session_branch ({session_branch!r}) and name "
            f"({session_name!r}) were provided; using {session_branch!r}.[/yellow]"
        )
    if declared is None:
        session_branch = create_session_branch(
            repo, local=local, base=base_branch, session_name=None
        )
    elif branch_exists(repo, declared):
        session_branch = declared
    else:
        console.print(
            f"[dim]Session branch {declared!r} does not exist — "
            f"creating from {base_branch or get_main_branch(repo)!r}...[/dim]"
        )
        session_branch = create_session_branch(
            repo, local=local, base=base_branch, session_name=declared
        )

    # Initialize session status tracking
    plan_slug = plan.folder_id
    plan_source = str(plan.source)
    session_status = SessionStatus(
        plan_slug=plan_slug,
        session_branch=session_branch,
        plan_source=plan_source,
    )

    # Resolve --task filter: accept task IDs or slugs
    filtered_task_ids: set[str] | None = None
    if task_filter:
        filtered_task_ids = set()
        for task in plan.tasks:
            if task.id in task_filter or task.slug in task_filter:
                filtered_task_ids.add(task.id)
        unmatched = task_filter - filtered_task_ids - {t.slug for t in plan.tasks}
        if unmatched:
            console.print(f"[yellow]Warning: no tasks matched: {', '.join(unmatched)}[/yellow]")

    # Load prior session status to carry forward records for non-targeted tasks
    prior = SessionStatus.load(repo, plan_slug, session_branch)
    if prior:
        for tid, rec in prior.tasks.items():
            if filtered_task_ids is None or tid not in filtered_task_ids:
                # Carry forward — this task is not being re-run
                session_status.tasks[tid] = rec

    # --only-incomplete: skip completed tasks
    skipped_task_ids: set[str] = set()
    if only_incomplete and prior:
        skipped_task_ids = prior.completed_task_ids()
        if skipped_task_ids:
            console.print(
                f"[dim]--only-incomplete: skipping {len(skipped_task_ids)} completed task(s)[/dim]"
            )

    # Seed the status file with every task in the plan as 'pending' so the
    # on-disk record reflects the full plan from t=0. Carried-forward records
    # take precedence; only tasks without a prior entry get a pending record.
    # Persist immediately so subsequent async update_task calls modify an
    # existing file rather than racing to create it.
    session_status.seed_pending(t.id for t in plan.tasks)
    session_status.save(repo)

    console.print(f"\n[bold]Plan:[/bold] {plan.title}")
    console.print(f"[bold]Tasks:[/bold] {len(plan.tasks)} across {len(waves)} wave(s)")
    console.print(f"[bold]Concurrency:[/bold] {max_concurrent}")
    console.print(f"[bold]Max retries:[/bold] {max_retries}")
    console.print(f"[bold]Repo:[/bold] {repo}")
    console.print(f"[bold]Session branch:[/bold] {session_branch}")
    console.print(f"[bold]tmux:[/bold] {'enabled' if use_tmux else 'disabled'}")
    if retry_failed:
        console.print("[bold]Retry failed:[/bold] enabled (one retry pass per wave)")
    if fail_fast:
        console.print("[bold]Fail fast:[/bold] enabled (stop on first wave with failures)")
    if filtered_task_ids is not None:
        names = [t.title for t in plan.tasks if t.id in filtered_task_ids]
        console.print(f"[bold]Task filter:[/bold] {', '.join(names)}")
    if tdd:
        console.print("[bold]Mode:[/bold] test-driven development (tests first)")
    if directives:
        for role, _ in directives.items():
            console.print(f"[bold]Custom directive:[/bold] {role.value}")
    for role in Role:
        rc = getattr(profile, role.value)
        if rc.agent != "claude":
            console.print(f"[bold]{role.value}:[/bold] using {rc.agent}")
    console.print()

    shutdown = asyncio.Event()

    async def _refresh(live: Live) -> None:
        while not shutdown.is_set():
            live.update(_status_table(all_states))
            try:
                await asyncio.wait_for(shutdown.wait(), timeout=1.0)
            except asyncio.TimeoutError:
                pass
        live.update(_status_table(all_states))

    with Live(_status_table(all_states), console=console, refresh_per_second=1) as live:
        refresh_task = asyncio.create_task(_refresh(live))
        try:
            for wave_idx, wave in enumerate(waves):
                wave_num = wave_idx + 1

                # Skip waves before start_wave
                if wave_num < start_wave:
                    for task in wave:
                        state = TaskState(task=task)
                        state.wave_num = wave_num
                        state.status = TaskStatus.DONE
                        all_states.append(state)
                        state_map[task.id] = state
                    continue

                # Stop after end_wave
                if end_wave is not None and wave_num > end_wave:
                    break

                # Initialize state for this wave
                # --task: filtered-out tasks are excluded entirely
                # --only-incomplete: completed tasks are pre-marked DONE
                wave_states: list[TaskState] = []
                for task in wave:
                    if filtered_task_ids is not None and task.id not in filtered_task_ids:
                        continue
                    state = TaskState(task=task)
                    state.wave_num = wave_num
                    if task.id in skipped_task_ids:
                        state.status = TaskStatus.DONE
                    wave_states.append(state)
                    all_states.append(state)
                    state_map[task.id] = state

                # Create worktrees for all tasks in wave, branching from session branch
                # Skip tasks pre-marked DONE by --only-incomplete
                for state in wave_states:
                    if state.status == TaskStatus.DONE:
                        continue

                    # Resume path: when retry_failed is set and the prior status
                    # records a failed task with completed stages on an existing
                    # branch, reuse the on-disk worktree instead of wiping it.
                    prior_record = prior.tasks.get(state.task.id) if prior else None
                    resume_stages = list(prior_record.completed_stages) if prior_record else []
                    can_resume = (
                        retry_failed
                        and bool(resume_stages)
                        and prior_record is not None
                        and prior_record.status == "failed"
                        and prior_record.branch is not None
                        and branch_exists(repo, prior_record.branch)
                        and not tdd
                    )
                    if can_resume:
                        try:
                            wt = attach_worktree(
                                repo,
                                state.task.id,
                                state.task.slug,
                                plan_slug=plan_slug,
                                branch=prior_record.branch,
                            )
                            state.worktree = wt
                            state.resume_stages = resume_stages
                            state.prior_results = []
                            console.print(
                                f"[bold cyan]Resuming {state.task.id}[/bold cyan] "
                                f"from after {resume_stages[-1]} "
                                f"(skipping {len(resume_stages)} stage(s))"
                            )
                            continue
                        except RuntimeError:
                            # Worktree dir was wiped between runs (e.g. `wb clean`).
                            pass

                    # Clean up existing worktree/branch from a prior run (e.g. --task re-run)
                    old_worktree_path = repo / ".workbench" / plan_slug / state.task.id
                    if old_worktree_path.exists():
                        Worktree(
                            path=old_worktree_path,
                            branch=f"wb/{state.task.slug}",
                            task_id=state.task.id,
                        ).cleanup()
                    else:
                        delete_branch(repo, f"wb/{state.task.slug}")
                    try:
                        wt = create_worktree(
                            repo,
                            state.task.id,
                            state.task.slug,
                            plan_slug=plan_slug,
                            base_branch=session_branch,
                        )
                        state.worktree = wt
                    except Exception as e:
                        state.status = TaskStatus.FAILED
                        state.results.append(
                            AgentResult(
                                task_id=state.task.id,
                                role=Role.IMPLEMENTOR,
                                status=TaskStatus.FAILED,
                                output=f"Worktree creation failed: {e}",
                            )
                        )

                # Status callback so the pipeline can update our display state and
                # persist the current phase to status.yaml at every handoff. Persisting
                # mid-pipeline lets external observers (and post-crash inspection)
                # see which agent a task got stuck on instead of seeing it stuck at
                # "pending".
                _status_to_agent: dict[TaskStatus, str] = {
                    TaskStatus.IMPLEMENTING: Role.IMPLEMENTOR.value,
                    TaskStatus.TESTING: Role.TESTER.value,
                    TaskStatus.REVIEWING: Role.REVIEWER.value,
                    TaskStatus.FIXING: Role.FIXER.value,
                    TaskStatus.MERGING: Role.MERGER.value,
                }

                def _completed_stages(
                    results: list[AgentResult],
                    resume_stages: list[str] | None = None,
                ) -> list[str]:
                    """Pipeline stages that have completed successfully, post fixer invalidation.

                    A fixer edits code on top of impl, invalidating any earlier test/review
                    pass — those passes must be re-run before they're trusted again.

                    ``resume_stages`` seeds the trusted set for resumed tasks where
                    impl/test ran in a prior process; a fixer in the current results
                    still invalidates them.
                    """
                    trusted: set[str] = set(resume_stages or [])
                    for r in results:
                        if r.role == Role.IMPLEMENTOR and r.status != TaskStatus.FAILED:
                            trusted.add(Role.IMPLEMENTOR.value)
                        elif r.role == Role.TESTER and r.passed:
                            trusted.add(Role.TESTER.value)
                        elif r.role == Role.REVIEWER and r.passed:
                            trusted.add(Role.REVIEWER.value)
                        elif r.role == Role.FIXER:
                            trusted.discard(Role.TESTER.value)
                            trusted.discard(Role.REVIEWER.value)
                    order = [Role.IMPLEMENTOR.value, Role.TESTER.value, Role.REVIEWER.value]
                    return [v for v in order if v in trusted]

                def _persist_stages(state: TaskState) -> list[str] | None:
                    """Build the completed_stages list for a persist call.

                    Returns None when there's no new information yet (no results, no
                    resumed stages) so update_task preserves any prior value rather
                    than zeroing it. This guards mid-pipeline writes where a status
                    transition fires before the first AgentResult arrives.
                    """
                    if not state.results and not state.resume_stages:
                        return None
                    return _completed_stages(state.results, state.resume_stages)

                async def _persist_status(state: TaskState, status: TaskStatus, last_agent: str):
                    try:
                        # Preserve the existing `merged` flag — update_task replaces the
                        # whole TaskRecord, so without this, a mid-pipeline write would
                        # transiently wipe `merged: True` for tasks already merged on a
                        # prior run (the wave's update_merged eventually restores it,
                        # but the window is visible to external observers).
                        existing = session_status.tasks.get(state.task.id)
                        merged = existing.merged if existing else False
                        await session_status.update_task(
                            repo=repo,
                            task_id=state.task.id,
                            status=status.value,
                            branch=state.worktree.branch if state.worktree else None,
                            merged=merged,
                            last_agent=last_agent,
                            completed_stages=_persist_stages(state),
                        )
                    except Exception as e:
                        console.print(
                            f"[dim red]status persist failed for {state.task.id}: {e}[/dim red]"
                        )

                def _make_callback(state: TaskState):
                    def _on_status(task_id: str, status: TaskStatus):
                        state.status = status
                        # Only persist mid-pipeline phases. DONE/FAILED are written
                        # authoritatively by the final update_task below using the
                        # result list, so we leave those for the awaited write.
                        last_agent = _status_to_agent.get(status)
                        if last_agent is None:
                            return
                        # Track the persist task so we can await it before the final
                        # write — asyncio.create_task schedules but does not run until
                        # the event loop yields, so without explicitly awaiting these,
                        # the final "done" write could acquire the lock and complete
                        # before any of the mid-pipeline writes get scheduled to run.
                        state.pending_persists.append(
                            asyncio.create_task(_persist_status(state, status, last_agent))
                        )

                    return _on_status

                # Run tasks concurrently with semaphore
                sem = asyncio.Semaphore(max_concurrent)

                async def _run_task(state: TaskState):
                    if state.status in (TaskStatus.FAILED, TaskStatus.DONE):
                        return

                    async with sem:
                        state.started_at = time.time()
                        state.status = TaskStatus.IMPLEMENTING

                        def _on_result(r: AgentResult, _state=state):
                            _state.results.append(r)
                            last_agent = r.role.value
                            _state.pending_persists.append(
                                asyncio.create_task(
                                    _persist_status(_state, _state.status, last_agent)
                                )
                            )

                        results = await run_pipeline(
                            task=state.task,
                            worktree=state.worktree,
                            repo=repo,
                            skip_test=skip_test,
                            skip_review=skip_review,
                            max_retries=max_retries,
                            agent_cmd=agent_cmd,
                            on_status_change=_make_callback(state),
                            on_result=_on_result,
                            resume_completed_stages=state.resume_stages or None,
                            prior_results=state.prior_results or None,
                            session_branch=session_branch,
                            plan_context=plan.context,
                            plan_conventions=plan.conventions,
                            directives=directives,
                            use_tmux=use_tmux,
                            tdd=tdd,
                            profile=profile,
                            agents_config_paths=agents_config_paths,
                        )

                        state.results = results
                        state.finished_at = time.time()

                        # Final status based on last result
                        if any(
                            r.role in (Role.TESTER, Role.REVIEWER)
                            and not r.passed
                            and r == results[-1]
                            for r in results
                        ):
                            state.status = TaskStatus.FAILED
                        elif any(r.status == TaskStatus.FAILED for r in results):
                            state.status = TaskStatus.FAILED
                        else:
                            state.status = TaskStatus.DONE

                        # Drain any in-flight mid-pipeline persists so the final
                        # update_task below is guaranteed to be the last write.
                        if state.pending_persists:
                            await asyncio.gather(*state.pending_persists, return_exceptions=True)
                            state.pending_persists.clear()

                        # Persist task outcome immediately (lock-protected for concurrency)
                        await session_status.update_task(
                            repo=repo,
                            task_id=state.task.id,
                            status=state.status.value,
                            branch=state.worktree.branch if state.worktree else None,
                            last_agent=results[-1].role.value if results else "",
                            completed_stages=_completed_stages(results, state.resume_stages),
                        )

                # Run wave tasks; the outer refresh coroutine drives display updates.
                tasks = [_run_task(s) for s in wave_states]
                await asyncio.gather(*tasks)

                # After the wave: merge all successful task branches into the session
                # branch. Exclude tasks pre-skipped by --only-incomplete (no worktree).
                done_states = [
                    s
                    for s in wave_states
                    if s.status == TaskStatus.DONE and s.worktree is not None
                ]
                for state in done_states:
                    result = merge_into_session(repo, session_branch, state.worktree.branch)
                    if result.success:
                        state.merged = True
                        await session_status.update_merged(repo, state.task.id)
                        if not keep_branches:
                            delete_branch(repo, state.worktree.branch)
                    elif result.conflicts and result.merge_dir:
                        # Conflicts detected — dispatch merge resolver agent
                        console.print(
                            f"  [blue]⚡[/blue] {state.worktree.branch} — "
                            f"{result.message} Resolving..."
                        )
                        for cf in result.conflicts:
                            console.print(f"      [dim]{cf}[/dim]")

                        state.status = TaskStatus.MERGING

                        resolver_result = await run_merge_resolver(
                            task_branch=state.worktree.branch,
                            session_branch=session_branch,
                            merge_dir=result.merge_dir,
                            conflicts=result.conflicts,
                            repo=repo,
                            agent_cmd=agent_cmd,
                            agents_config_paths=agents_config_paths,
                        )
                        state.results.append(resolver_result)

                        if resolver_result.passed:
                            # Resolver succeeded — complete the merge
                            merge_finish = complete_merge(
                                result.merge_dir,
                                repo,
                                session_branch,
                                state.worktree.branch,
                            )
                            if merge_finish.success:
                                console.print(
                                    f"  [green]✓[/green] {state.worktree.branch} — "
                                    f"{merge_finish.message}"
                                )
                                state.status = TaskStatus.DONE
                                state.merged = True
                                await session_status.update_merged(repo, state.task.id)
                                if not keep_branches:
                                    delete_branch(repo, state.worktree.branch)
                            else:
                                console.print(
                                    f"  [red]✗[/red] {state.worktree.branch} — "
                                    f"{merge_finish.message}"
                                )
                                cleanup_merge_worktree(repo, result.merge_dir)
                                state.status = TaskStatus.FAILED
                                state.merge_error = True
                        else:
                            # Resolver failed — abort and mark failed
                            console.print(
                                f"  [red]✗[/red] {state.worktree.branch} — "
                                f"Merge resolver failed"
                            )
                            cleanup_merge_worktree(repo, result.merge_dir)
                            state.status = TaskStatus.FAILED
                            state.merge_error = True
                    else:
                        state.status = TaskStatus.FAILED
                        state.merge_error = True

                # --retry-failed: re-run tasks that failed due to transient errors.
                # A task is retryable if it crashed before exhausting its fix cycles
                # (i.e. fix_count < max_retries). Tasks that went through all retries
                # and still failed need human intervention, not another blind run.
                if retry_failed:
                    retryable = [
                        s
                        for s in wave_states
                        if s.status == TaskStatus.FAILED
                        and s.worktree is not None
                        and s.fix_count < max_retries
                    ]

                    if retryable:
                        console.print(
                            f"[bold yellow]Retrying {len(retryable)} failed task(s)...[/bold yellow]"
                        )

                        # Reset state for retry
                        for state in retryable:
                            state.status = TaskStatus.PENDING
                            state.results.clear()
                            state.started_at = None
                            state.finished_at = None
                            state.merge_error = False

                            prior_record = prior.tasks.get(state.task.id) if prior else None
                            resume_stages = (
                                list(prior_record.completed_stages) if prior_record else []
                            )
                            can_resume = (
                                bool(resume_stages)
                                and prior_record is not None
                                and prior_record.branch is not None
                                and branch_exists(repo, prior_record.branch)
                                and not tdd
                            )

                            if can_resume:
                                try:
                                    wt = attach_worktree(
                                        repo,
                                        state.task.id,
                                        state.task.slug,
                                        plan_slug=plan_slug,
                                        branch=prior_record.branch,
                                    )
                                    state.worktree = wt
                                    state.resume_stages = resume_stages
                                    state.prior_results = []
                                    console.print(
                                        f"[bold cyan]Resuming {state.task.id}[/bold cyan] "
                                        f"from after {resume_stages[-1]} "
                                        f"(skipping {len(resume_stages)} stage(s))"
                                    )
                                    continue
                                except RuntimeError:
                                    pass

                            # Fall back: wipe and recreate
                            if state.worktree:
                                state.worktree.cleanup()
                                state.worktree = None
                            state.resume_stages = []
                            state.prior_results = []
                            try:
                                wt = create_worktree(
                                    repo,
                                    state.task.id,
                                    state.task.slug,
                                    plan_slug=plan_slug,
                                    base_branch=session_branch,
                                )
                                state.worktree = wt
                            except Exception as e:
                                state.status = TaskStatus.FAILED
                                state.results.append(
                                    AgentResult(
                                        task_id=state.task.id,
                                        role=Role.IMPLEMENTOR,
                                        status=TaskStatus.FAILED,
                                        output=f"Retry worktree creation failed: {e}",
                                    )
                                )

                        retry_tasks = [_run_task(s) for s in retryable]
                        await asyncio.gather(*retry_tasks)

                        # Merge any newly successful retried tasks
                        retry_done = [s for s in retryable if s.status == TaskStatus.DONE]
                        for state in retry_done:
                            result = merge_into_session(
                                repo, session_branch, state.worktree.branch
                            )
                            if result.success:
                                state.merged = True
                                await session_status.update_merged(repo, state.task.id)
                                if not keep_branches:
                                    delete_branch(repo, state.worktree.branch)
                            else:
                                state.status = TaskStatus.FAILED
                                state.merge_error = True

                # --fail-fast: stop processing further waves if any task failed
                if fail_fast:
                    wave_failed = [s for s in wave_states if s.status == TaskStatus.FAILED]
                    if wave_failed:
                        console.print(
                            f"[bold red]--fail-fast: {len(wave_failed)} task(s) failed in "
                            f"wave {wave_num}, stopping.[/bold red]"
                        )
                        break
        finally:
            shutdown.set()
            await refresh_task

    # Summary
    console.print("\n[bold]━━━ Summary ━━━[/bold]\n")
    done = [s for s in all_states if s.status == TaskStatus.DONE]
    failed = [s for s in all_states if s.status == TaskStatus.FAILED]
    fixed = [s for s in done if s.fix_count > 0]

    console.print(f"  [green]✓ {len(done)} completed[/green]")
    if fixed:
        console.print(f"  [yellow]↻ {len(fixed)} required fixes[/yellow]")
        for s in fixed:
            console.print(f"    - {s.task.title} ({s.fix_count} fix cycle(s))")
    if failed:
        console.print(f"  [red]✗ {len(failed)} failed[/red]")
        for s in failed:
            console.print(f"    - {s.task.title}: {s.phase_summary}")

    # Show session branch for review
    if done:
        console.print(f"\n[bold]All changes merged into:[/bold] {session_branch}")
        console.print(f"  git checkout {session_branch}")
        console.print(f"  git diff main...{session_branch}")

    # Push session branch to origin
    if push and done:
        success, msg = push_session_branch(repo, session_branch)
        if success:
            console.print(f"\n[green]{msg}[/green]")
        else:
            console.print(f"\n[red]Push failed: {msg}[/red]")

    if cleanup_on_done:
        for s in all_states:
            if s.worktree:
                s.worktree.cleanup()
        console.print("\n[dim]Worktrees cleaned up.[/dim]")

    return all_states


async def merge_unmerged(
    repo: Path,
    session_branch: str,
    plan_slug: str | None = None,
    agent_cmd: str = "claude",
    use_tmux: bool = True,
    keep_branches: bool = False,
    push: bool = False,
    agents_config_paths: list[Path] | None = None,
) -> SessionStatus:
    """Merge all completed-but-unmerged task branches into the session branch.

    If ``plan_slug`` is provided, loads that specific status file.
    Otherwise, scans all status files for the session branch.
    """
    console = Console()

    if plan_slug:
        status = SessionStatus.load(repo, plan_slug, session_branch)
    else:
        try:
            status = SessionStatus.find_by_session(repo, session_branch)
        except ValueError as e:
            console.print(f"[red]{e}[/red]")
            return SessionStatus(plan_slug="", session_branch=session_branch)

    if status is None:
        console.print("[red]No status found for this session. Run 'wb run' first.[/red]")
        return SessionStatus(plan_slug=plan_slug or "", session_branch=session_branch)

    if agents_config_paths is None:
        agents_config_paths = resolve_agents_config_paths(repo, plan_slug=status.plan_slug)

    # Find tasks that completed but haven't been merged
    unmerged = {
        tid: rec
        for tid, rec in status.tasks.items()
        if rec.status == "done" and not rec.merged and rec.branch
    }

    if not unmerged:
        console.print("[dim]No unmerged tasks found.[/dim]")
        return status

    # Pre-check: skip branches already merged via git (manual merge)
    already_merged = get_merged_branches(repo, session_branch)

    console.print(f"\n[bold]Merging {len(unmerged)} branch(es) into {session_branch}...[/bold]\n")

    for tid, rec in unmerged.items():
        if rec.branch in already_merged:
            console.print(f"  [green]✓[/green] {rec.branch} — already merged")
            await status.update_merged(repo, tid)
            if not keep_branches:
                delete_branch(repo, rec.branch)
            continue

        result = merge_into_session(repo, session_branch, rec.branch)
        if result.success:
            console.print(f"  [green]✓[/green] {rec.branch} — {result.message}")
            await status.update_merged(repo, tid)
            if not keep_branches:
                delete_branch(repo, rec.branch)
        elif result.conflicts and result.merge_dir:
            console.print(f"  [blue]⚡[/blue] {rec.branch} — " f"{result.message} Resolving...")
            for cf in result.conflicts:
                console.print(f"      [dim]{cf}[/dim]")

            resolver_result = await run_merge_resolver(
                task_branch=rec.branch,
                session_branch=session_branch,
                merge_dir=result.merge_dir,
                conflicts=result.conflicts,
                repo=repo,
                agent_cmd=agent_cmd,
                use_tmux=use_tmux,
                agents_config_paths=agents_config_paths,
            )

            if resolver_result.passed:
                merge_finish = complete_merge(result.merge_dir, repo, session_branch, rec.branch)
                if merge_finish.success:
                    console.print(f"  [green]✓[/green] {rec.branch} — {merge_finish.message}")
                    await status.update_merged(repo, tid)
                    if not keep_branches:
                        delete_branch(repo, rec.branch)
                else:
                    console.print(f"  [red]✗[/red] {rec.branch} — {merge_finish.message}")
                    cleanup_merge_worktree(repo, result.merge_dir)
            else:
                console.print(f"  [red]✗[/red] {rec.branch} — Merge resolver failed")
                cleanup_merge_worktree(repo, result.merge_dir)
        else:
            console.print(f"  [red]✗[/red] {rec.branch} — {result.message}")

    # Summary
    merged_count = sum(1 for rec in status.tasks.values() if rec.merged)
    total = len(status.tasks)
    console.print(f"\n[bold]{merged_count}/{total} task(s) merged into {session_branch}[/bold]")

    # Push session branch to origin
    if push and merged_count > 0:
        success, msg = push_session_branch(repo, session_branch)
        if success:
            console.print(f"\n[green]{msg}[/green]")
        else:
            console.print(f"\n[red]Push failed: {msg}[/red]")

    return status
