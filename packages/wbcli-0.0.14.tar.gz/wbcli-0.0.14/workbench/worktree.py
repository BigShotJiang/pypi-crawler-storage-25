"""Git worktree management for isolated agent work."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Worktree:
    """A git worktree for an agent to work in."""

    path: Path
    branch: str
    task_id: str

    @property
    def repo(self) -> Path:
        """Derive the repo root by walking up until we find ``.workbench``.

        Handles both the new layout (``.workbench/<plan>/<task>``) and the
        legacy layout (``.workbench/<task>``). Worktrees are always created
        under ``.workbench``, so failing to find it indicates a malformed
        ``Worktree`` and is a programming error.
        """
        cur = self.path
        while cur != cur.parent:
            if cur.name == ".workbench":
                return cur.parent
            cur = cur.parent
        raise ValueError(f"Worktree path is not under .workbench: {self.path}")

    def cleanup(self):
        """Remove the worktree and delete the branch."""
        repo = self.repo
        subprocess.run(
            ["git", "worktree", "remove", str(self.path), "--force"],
            cwd=repo,
            capture_output=True,
        )
        subprocess.run(
            ["git", "branch", "-D", self.branch],
            cwd=repo,
            capture_output=True,
        )


def delete_branch(repo: Path, branch: str) -> None:
    """Delete a local branch. Silently ignores errors (e.g. branch doesn't exist)."""
    subprocess.run(
        ["git", "branch", "-D", branch],
        cwd=repo,
        capture_output=True,
    )


def branch_exists(repo: Path, branch: str) -> bool:
    """Return True if a local branch with this name exists."""
    result = subprocess.run(
        ["git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"],
        cwd=repo,
        capture_output=True,
    )
    return result.returncode == 0


def get_main_branch(repo: Path) -> str:
    """Detect the main/default branch."""
    result = subprocess.run(
        ["git", "symbolic-ref", "refs/remotes/origin/HEAD"],
        cwd=repo,
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return result.stdout.strip().split("/")[-1]

    # Fallback: check for main or master
    result = subprocess.run(
        ["git", "branch", "--list", "main"],
        cwd=repo,
        capture_output=True,
        text=True,
    )
    if "main" in result.stdout:
        return "main"
    return "master"


def create_session_branch(
    repo: Path,
    local: bool = False,
    base: str | None = None,
    session_name: str | None = None,
) -> str:
    """Create a clean session branch off a base branch.

    Branch naming:
        - With session_name: ``workbench-<name>``
        - Without: ``workbench-<N>`` where N auto-increments.

    Args:
        repo: Path to the git repository.
        local: If True, branch from the local ref. If False (default), fetch
            from origin first and prefer origin/<base>.
        base: Base branch to branch from. Defaults to main/master.
        session_name: Optional name for the session branch.
    """
    base = base or get_main_branch(repo)

    if session_name:
        session_branch = session_name
    else:
        # Find the next available session number
        result = subprocess.run(
            ["git", "branch", "--list", "workbench-*"],
            cwd=repo,
            capture_output=True,
            text=True,
        )
        existing = []
        for line in result.stdout.strip().split("\n"):
            name = line.strip().lstrip("* ")
            if name.startswith("workbench-"):
                try:
                    num = int(name.split("-", 1)[1])
                    existing.append(num)
                except ValueError:
                    pass

        next_num = max(existing, default=0) + 1
        session_branch = f"workbench-{next_num}"

    if local:
        branch_point = base
    else:
        # Fetch latest from remote so we branch from up-to-date main
        subprocess.run(
            ["git", "fetch", "origin", base],
            cwd=repo,
            capture_output=True,
        )

        # Prefer origin/base if it exists, otherwise fall back to local base
        ref_check = subprocess.run(
            ["git", "rev-parse", "--verify", f"origin/{base}"],
            cwd=repo,
            capture_output=True,
        )
        branch_point = f"origin/{base}" if ref_check.returncode == 0 else base

    subprocess.run(
        ["git", "branch", "--no-track", session_branch, branch_point],
        cwd=repo,
        capture_output=True,
        text=True,
        check=True,
    )

    return session_branch


def create_worktree(
    repo: Path,
    task_id: str,
    task_slug: str,
    plan_slug: str,
    base_branch: str | None = None,
) -> Worktree:
    """Create an isolated worktree for a task under the plan folder.

    Path: ``repo / ".workbench" / plan_slug / task_id``.

    Args:
        repo: Path to the git repo root.
        task_id: Unique task identifier.
        task_slug: Slug for the branch name.
        plan_slug: Plan folder name — worktrees live under it.
        base_branch: Branch to create the worktree from. Defaults to main.
    """
    branch = f"wb/{task_slug}"
    base = base_branch or get_main_branch(repo)
    worktree_dir = repo / ".workbench" / plan_slug / task_id
    worktree_dir.parent.mkdir(parents=True, exist_ok=True)

    # Create the branch from the base (--no-track prevents inheriting upstream)
    subprocess.run(
        ["git", "branch", "--no-track", branch, base],
        cwd=repo,
        capture_output=True,
        text=True,
        check=True,
    )

    # Create the worktree
    subprocess.run(
        ["git", "worktree", "add", str(worktree_dir), branch],
        cwd=repo,
        capture_output=True,
        text=True,
        check=True,
    )

    return Worktree(path=worktree_dir, branch=branch, task_id=task_id)


def attach_worktree(
    repo: Path,
    task_id: str,
    task_slug: str,
    plan_slug: str | None,
    branch: str,
) -> Worktree:
    """Re-attach a Worktree handle to an on-disk worktree + branch.

    Used on resume: the worktree directory and branch still exist from the
    prior run; we need a Worktree dataclass to pass to the orchestrator
    without re-creating either. Raises RuntimeError if path or branch is
    missing — the caller should fall back to create_worktree.
    """
    if plan_slug:
        worktree_dir = repo / ".workbench" / plan_slug / task_id
    else:
        worktree_dir = repo / ".workbench" / task_slug

    if not worktree_dir.is_dir() or not branch_exists(repo, branch):
        raise RuntimeError(f"Cannot attach worktree for {task_id}: path or branch missing")

    return Worktree(path=worktree_dir, branch=branch, task_id=task_id)


def is_workbench_worktree(path: Path) -> bool:
    """Return True if ``path`` looks like a workbench task worktree.

    A workbench worktree is a directory under some ``.workbench/`` whose
    ``.git`` entry is a file (git worktrees use a gitfile, not a gitdir).
    """
    if not path.is_dir():
        return False
    git_marker = path / ".git"
    if not git_marker.is_file():
        return False
    cur = path.parent
    while cur != cur.parent:
        if cur.name == ".workbench":
            return True
        cur = cur.parent
    return False


def iter_worktree_dirs(repo: Path) -> list[Path]:
    """Return all task worktree directories under ``repo/.workbench``.

    Scans both the new layout (``.workbench/<plan>/<task>``) and the
    legacy layout (``.workbench/<task>``). Identified by the presence of a
    ``.git`` gitfile, so non-worktree directories like ``wrap-up/`` are
    skipped.
    """
    workbench_dir = repo / ".workbench"
    if not workbench_dir.is_dir():
        return []

    seen: dict[Path, None] = {}
    for child in workbench_dir.iterdir():
        if not child.is_dir():
            continue
        if is_workbench_worktree(child):
            seen.setdefault(child.resolve(), None)
            # Legacy worktree — its contents are the working tree, don't recurse.
            continue
        for grandchild in child.iterdir():
            if not grandchild.is_dir():
                continue
            if is_workbench_worktree(grandchild):
                seen.setdefault(grandchild.resolve(), None)

    return list(seen.keys())


@dataclass
class MergeResult:
    """Result of merging a task branch into the session branch."""

    branch: str
    success: bool
    message: str
    conflicts: list[str] | None = None
    merge_dir: Path | None = None


def merge_into_session(
    repo: Path,
    session_branch: str,
    task_branch: str,
    cleanup_on_conflict: bool = False,
) -> MergeResult:
    """Merge a task branch into the session branch.

    Uses a temporary worktree to avoid disturbing the main working tree.

    When cleanup_on_conflict is False (default), the merge worktree is left
    in place on conflict so a resolver agent can be dispatched into it.
    When True, conflicts are aborted and the worktree is cleaned up immediately.
    """
    merge_dir = repo / ".workbench" / "_merge"

    # Create a temporary worktree on the session branch
    subprocess.run(
        ["git", "worktree", "remove", str(merge_dir), "--force"],
        cwd=repo,
        capture_output=True,
    )
    add_wt = subprocess.run(
        ["git", "worktree", "add", str(merge_dir), session_branch],
        cwd=repo,
        capture_output=True,
        text=True,
    )
    if add_wt.returncode != 0:
        return MergeResult(
            branch=task_branch,
            success=False,
            message=f"Failed to create merge worktree: {add_wt.stderr}",
        )

    # Attempt the merge inside the worktree
    merge = subprocess.run(
        ["git", "merge", task_branch, "-m", f"Merge {task_branch} into {session_branch}"],
        cwd=merge_dir,
        capture_output=True,
        text=True,
    )

    if merge.returncode == 0:
        # Clean merge — clean up worktree
        subprocess.run(
            ["git", "worktree", "remove", str(merge_dir), "--force"],
            cwd=repo,
            capture_output=True,
        )
        return MergeResult(branch=task_branch, success=True, message="Merged cleanly.")

    # Merge conflict — collect conflicting files
    status = subprocess.run(
        ["git", "diff", "--name-only", "--diff-filter=U"],
        cwd=merge_dir,
        capture_output=True,
        text=True,
    )
    conflicts = [f.strip() for f in status.stdout.strip().split("\n") if f.strip()]

    if cleanup_on_conflict:
        # Abort and clean up (old behavior)
        subprocess.run(["git", "merge", "--abort"], cwd=merge_dir, capture_output=True)
        subprocess.run(
            ["git", "worktree", "remove", str(merge_dir), "--force"],
            cwd=repo,
            capture_output=True,
        )
        return MergeResult(
            branch=task_branch,
            success=False,
            message=f"Merge conflict in {len(conflicts)} file(s).",
            conflicts=conflicts,
        )

    # Leave merge worktree in place for resolver agent
    return MergeResult(
        branch=task_branch,
        success=False,
        message=f"Merge conflict in {len(conflicts)} file(s).",
        conflicts=conflicts,
        merge_dir=merge_dir,
    )


def complete_merge(
    merge_dir: Path, repo: Path, session_branch: str, task_branch: str
) -> MergeResult:
    """Complete a merge after conflicts have been resolved by staging and committing.

    Checks that no conflict markers remain, commits the merge, and cleans up
    the temporary merge worktree.
    """
    # Check for remaining conflict markers in tracked files
    check = subprocess.run(
        ["git", "diff", "--check"],
        cwd=merge_dir,
        capture_output=True,
        text=True,
    )
    if check.returncode != 0:
        return MergeResult(
            branch=task_branch,
            success=False,
            message=f"Conflict markers remain: {check.stdout.strip()}",
        )

    # Commit the resolved merge
    commit = subprocess.run(
        ["git", "commit", "--no-edit"],
        cwd=merge_dir,
        capture_output=True,
        text=True,
    )
    if commit.returncode != 0:
        return MergeResult(
            branch=task_branch,
            success=False,
            message=f"Merge commit failed: {commit.stderr.strip()}",
        )

    # Clean up the merge worktree
    subprocess.run(
        ["git", "worktree", "remove", str(merge_dir), "--force"],
        cwd=repo,
        capture_output=True,
    )

    return MergeResult(
        branch=task_branch,
        success=True,
        message=f"Merged {task_branch} into {session_branch} (conflicts resolved).",
    )


def cleanup_merge_worktree(repo: Path, merge_dir: Path) -> None:
    """Abort merge and remove the merge worktree."""
    subprocess.run(["git", "merge", "--abort"], cwd=merge_dir, capture_output=True)
    subprocess.run(
        ["git", "worktree", "remove", str(merge_dir), "--force"],
        cwd=repo,
        capture_output=True,
    )


def get_merged_branches(repo: Path, session_branch: str) -> set[str]:
    """Return the set of branch names already merged into the session branch.

    Used by --only-incomplete to skip tasks whose branches were already merged.
    """
    result = subprocess.run(
        ["git", "branch", "--merged", session_branch],
        cwd=repo,
        capture_output=True,
        text=True,
    )
    merged = set()
    for line in result.stdout.strip().split("\n"):
        branch = line.strip().lstrip("*+ ")
        if branch:
            merged.add(branch)
    return merged


def push_session_branch(repo: Path, session_branch: str) -> tuple[bool, str]:
    """Push the session branch to origin with upstream tracking.

    Returns (success, message).
    """
    result = subprocess.run(
        ["git", "push", "-u", "origin", session_branch],
        cwd=repo,
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return True, f"Pushed {session_branch} to origin/{session_branch}"
    return False, result.stderr.strip() or "Push failed"


def get_diff(worktree: Worktree, base_branch: str) -> str:
    """Get the diff of changes made in a worktree."""
    result = subprocess.run(
        ["git", "diff", f"{base_branch}...HEAD"],
        cwd=worktree.path,
        capture_output=True,
        text=True,
    )
    return result.stdout


def get_diff_since(worktree: Worktree, since_sha: str) -> str:
    """Get the diff between a specific commit and HEAD in a worktree."""
    result = subprocess.run(
        ["git", "diff", f"{since_sha}..HEAD"],
        cwd=worktree.path,
        capture_output=True,
        text=True,
    )
    return result.stdout


def get_head_sha(worktree: Worktree) -> str:
    """Return the current HEAD SHA of a worktree, or empty string on failure."""
    result = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=worktree.path,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return ""
    return result.stdout.strip()
