import logging
from collections.abc import Sequence
from typing import Generic, TypeAlias, TypeVar, overload

from quelware_core.entities.directives import Directive, FixedTimelineDirective
from quelware_core.entities.instrument import (
    ConfigVariant,
    FixedTimelineConfig,
    FixedTimelineProfile,
    InstrumentDefinition,
    InstrumentInfo,
    InstrumentMode,
    ProfileVariant,
)
from quelware_core.entities.resource import ResourceId, extract_unit_label
from quelware_core.entities.result import (
    ResultContainer,
)
from quelware_core.entities.session import SessionToken

from quelware_client.core import Session
from quelware_client.core.interfaces.instrument_agent import InstrumentAgent

logger = logging.getLogger(__name__)

D = TypeVar("D", bound="Directive")
C = TypeVar("C", bound="ConfigVariant")
P = TypeVar("P", bound="ProfileVariant")


class InstrumentDriver(Generic[D, C, P]):
    def __init__(  # noqa: PLR0913
        self,
        session_token: SessionToken,
        instrument_id: ResourceId,
        port_id: ResourceId,
        definition: InstrumentDefinition[P],
        config: C,
        instrument_agent: InstrumentAgent,
    ):
        self._token = session_token
        self._id = instrument_id
        self._port_id = port_id
        self._definition = definition
        self._config = config
        self._agent = instrument_agent

    @overload
    async def apply(self, directive: D) -> bool: ...

    @overload
    async def apply(self, directive: Sequence[D]) -> bool: ...

    async def apply(self, directive) -> bool:
        if isinstance(directive, Sequence):
            return await self._agent.configure(self._token, self._id, directive)
        else:
            return await self._agent.configure(self._token, self._id, [directive])

    async def initialize(self):
        await self._agent.initialize(self._token, [self._id])

    @property
    def instrument_config(self) -> C:
        return self._config

    async def fetch_result(self) -> ResultContainer:
        res = await self._agent.fetch_result(self._token, self._id)
        return res


FixedTimelineInstrumentDriver: TypeAlias = InstrumentDriver[
    FixedTimelineDirective,
    FixedTimelineConfig,
    FixedTimelineProfile,
]


def create_instrument_driver_fixed_timeline(
    session: Session, instrument_info: InstrumentInfo
) -> FixedTimelineInstrumentDriver:
    if instrument_info.definition.mode is not InstrumentMode.FIXED_TIMELINE:
        raise ValueError(
            f"Instrument mode is mismatched: '{instrument_info.definition.mode}' "
            f"(expected '{InstrumentMode.FIXED_TIMELINE}')"
        )
    if instrument_info.id not in session.available_resource_ids:
        raise ValueError(
            f"instrument '{instrument_info.id}' is not availble in the session "
            f"with token '{session.token}'."
        )

    return InstrumentDriver(
        session.token,
        instrument_info.id,
        instrument_info.port_id,
        instrument_info.definition,
        instrument_info.config,
        session.agent_container.instrument(extract_unit_label(instrument_info.id)),
    )


__all__ = ["InstrumentDriver"]
