"""Tests for confab.quarantine — auto-quarantine of persistently unverified claims.

Tests cover:
- QuarantineResult formatting (human-readable and Slack)
- _find_claim_line — locating claim text in file content
- _move_to_quarantine_section — file manipulation (create/append quarantine section)
- run_quarantine — full pipeline with mock GateReport
- Edge cases: already quarantined, missing source file, dry run, no candidates
"""

import json
import os
import tempfile
import textwrap
import unittest
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

from confab.quarantine import (
    QUARANTINE_SECTION,
    QUARANTINE_THRESHOLD,
    QuarantineAction,
    QuarantineResult,
    _find_claim_line,
    _move_to_quarantine_section,
    _suggest_verification,
    run_quarantine,
)
from confab.claims import ClaimType


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_gate_report(stale_details: List[Dict[str, Any]]):
    """Create a minimal mock GateReport with just stale_details populated."""
    report = MagicMock()
    report.stale_details = stale_details
    return report


def _write_priority_file(tmp: str, content: str) -> str:
    """Write content to a temp priority file, return its path."""
    path = os.path.join(tmp, "builder_priorities.md")
    with open(path, "w") as f:
        f.write(textwrap.dedent(content))
    return path


# ---------------------------------------------------------------------------
# QuarantineAction / QuarantineResult formatting
# ---------------------------------------------------------------------------

class TestQuarantineResult(unittest.TestCase):
    def test_format_report_empty(self):
        result = QuarantineResult(
            timestamp="2026-04-05T00:00:00+00:00",
            threshold=5,
            candidates=0,
        )
        text = result.format_report()
        self.assertIn("Candidates: 0", text)
        self.assertIn("Quarantined: 0", text)

    def test_format_report_with_actions(self):
        result = QuarantineResult(
            timestamp="2026-04-05T00:00:00+00:00",
            threshold=5,
            candidates=2,
            quarantined=[
                QuarantineAction(
                    claim_text="Config at deploy/config.toml is ready",
                    claim_type="file_exists",
                    source_file="priorities.md",
                    run_count=7,
                    verification_hint="Check: `ls deploy/config.toml`",
                    moved=True,
                ),
            ],
        )
        text = result.format_report()
        self.assertIn("Candidates: 2", text)
        self.assertIn("Quarantined: 1", text)
        self.assertIn("[MOVED]", text)
        self.assertIn("[7 runs]", text)
        self.assertIn("Config at deploy/config.toml", text)

    def test_format_report_not_moved(self):
        result = QuarantineResult(
            timestamp="2026-04-05T00:00:00+00:00",
            threshold=5,
            candidates=1,
            quarantined=[
                QuarantineAction(
                    claim_text="Some claim",
                    claim_type="file_exists",
                    source_file="x.md",
                    run_count=5,
                    verification_hint="verify it",
                    moved=False,
                ),
            ],
        )
        text = result.format_report()
        self.assertIn("[NOTED]", text)

    def test_format_report_dry_run(self):
        result = QuarantineResult(
            timestamp="2026-04-05T00:00:00+00:00",
            threshold=5,
            candidates=0,
            dry_run=True,
        )
        text = result.format_report()
        self.assertIn("[DRY RUN]", text)

    def test_format_report_with_skipped(self):
        result = QuarantineResult(
            timestamp="2026-04-05T00:00:00+00:00",
            threshold=5,
            candidates=1,
            skipped=[{"claim": "some claim", "reason": "No source file"}],
        )
        text = result.format_report()
        self.assertIn("Skipped: 1", text)
        self.assertIn("No source file", text)

    def test_format_slack_empty(self):
        result = QuarantineResult(
            timestamp="2026-04-05T00:00:00+00:00",
            threshold=5,
            candidates=0,
        )
        self.assertEqual(result.format_slack(), "")

    def test_format_slack_with_actions(self):
        result = QuarantineResult(
            timestamp="2026-04-05T00:00:00+00:00",
            threshold=5,
            candidates=1,
            quarantined=[
                QuarantineAction(
                    claim_text="Pipeline is working",
                    claim_type="pipeline_works",
                    source_file="priorities.md",
                    run_count=6,
                    verification_hint="run the pipeline",
                    moved=True,
                ),
            ],
        )
        text = result.format_slack()
        self.assertIn("Confab Quarantine Alert", text)
        self.assertIn("[6 runs]", text)
        self.assertIn("Pipeline is working", text)
        self.assertIn("QUARANTINED CLAIMS", text)

    def test_to_dict(self):
        action = QuarantineAction(
            claim_text="test claim",
            claim_type="file_exists",
            source_file="x.md",
            run_count=5,
            verification_hint="check it",
            moved=True,
        )
        result = QuarantineResult(
            timestamp="2026-04-05T00:00:00+00:00",
            threshold=5,
            candidates=1,
            quarantined=[action],
            skipped=[{"claim": "skipped", "reason": "no file"}],
            slack_posted=True,
            dry_run=False,
        )
        d = result.to_dict()
        self.assertEqual(d["threshold"], 5)
        self.assertEqual(d["candidates"], 1)
        self.assertEqual(len(d["quarantined"]), 1)
        self.assertEqual(d["quarantined"][0]["claim_text"], "test claim")
        self.assertTrue(d["quarantined"][0]["moved"])
        self.assertTrue(d["slack_posted"])


# ---------------------------------------------------------------------------
# _suggest_verification
# ---------------------------------------------------------------------------

class TestSuggestVerification(unittest.TestCase):
    def test_known_claim_types(self):
        hint = _suggest_verification(ClaimType.FILE_EXISTS.value, "config.toml is ready")
        self.assertIn("ls", hint)

    def test_env_var_type(self):
        hint = _suggest_verification(ClaimType.ENV_VAR.value, "needs API_KEY")
        self.assertIn("echo", hint)

    def test_unknown_type_fallback(self):
        hint = _suggest_verification("unknown_type", "something")
        self.assertIn("Manually verify", hint)


# ---------------------------------------------------------------------------
# _find_claim_line
# ---------------------------------------------------------------------------

class TestFindClaimLine(unittest.TestCase):
    def test_exact_match(self):
        content = "- Audio pipeline: WORKING [v2: verified]\n- Config is ready\n"
        line = _find_claim_line(content, "Config is ready")
        self.assertEqual(line, "- Config is ready")

    def test_match_within_line(self):
        content = "- **Audio pipeline**: WORKING [v2: verified 2026-03-14]\n"
        line = _find_claim_line(content, "Audio pipeline")
        self.assertIsNotNone(line)
        self.assertIn("Audio pipeline", line)

    def test_numbered_claim(self):
        content = "1. Deploy config at path/to/file is ready\n2. Tests pass\n"
        line = _find_claim_line(content, "Deploy config at path/to/file is ready")
        self.assertIsNotNone(line)
        self.assertIn("Deploy config", line)

    def test_no_match(self):
        content = "- Some unrelated line\n- Another line\n"
        line = _find_claim_line(content, "This claim does not exist anywhere")
        self.assertIsNone(line)

    def test_core_match_fallback(self):
        """When the exact claim_text doesn't match, falls back to core content."""
        content = "- 1. The deploy config at deploy/config.toml needs review\n"
        line = _find_claim_line(content, "1. The deploy config at deploy/config.toml needs review")
        self.assertIsNotNone(line)

    def test_stripped_match(self):
        content = "  - Audio pipeline: WORKING\n"
        line = _find_claim_line(content, "Audio pipeline: WORKING")
        self.assertIsNotNone(line)


# ---------------------------------------------------------------------------
# _move_to_quarantine_section
# ---------------------------------------------------------------------------

class TestMoveToQuarantineSection(unittest.TestCase):
    def test_creates_new_section(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, """\
            # Priorities

            - Audio pipeline: WORKING
            - Config at deploy/config.toml is ready
            """)

            moved = _move_to_quarantine_section(
                path,
                ["- Config at deploy/config.toml is ready"],
                {"- Config at deploy/config.toml is ready": 7},
            )

            self.assertEqual(moved, 1)
            content = Path(path).read_text()
            # The claim should be removed from its original position
            self.assertNotIn("- Config at deploy/config.toml is ready\n", content.split(QUARANTINE_SECTION)[0])
            # And appear in the quarantine section
            self.assertIn(QUARANTINE_SECTION, content)
            self.assertIn("Config at deploy/config.toml is ready", content.split(QUARANTINE_SECTION)[1])
            self.assertIn("quarantined", content.split(QUARANTINE_SECTION)[1])
            self.assertIn("7 gate runs", content.split(QUARANTINE_SECTION)[1])

    def test_appends_to_existing_section(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, f"""\
            # Priorities

            - New stale claim
            - Active item

            ---

            {QUARANTINE_SECTION}

            Claims moved here have persisted 5+ gate runs without verification.

            - Old quarantined claim  *(quarantined 2026-04-01, 6 gate runs unverified)*
            """)

            moved = _move_to_quarantine_section(
                path,
                ["- New stale claim"],
                {"- New stale claim": 8},
            )

            self.assertEqual(moved, 1)
            content = Path(path).read_text()
            # Old quarantined claim should still be there
            self.assertIn("Old quarantined claim", content)
            # New claim should be in the quarantine section
            self.assertIn("New stale claim", content.split(QUARANTINE_SECTION)[1])
            self.assertIn("8 gate runs", content)

    def test_nonexistent_file(self):
        moved = _move_to_quarantine_section(
            "/nonexistent/path/file.md",
            ["- some claim"],
            {"- some claim": 5},
        )
        self.assertEqual(moved, 0)

    def test_no_matching_lines(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, """\
            # Priorities

            - Active item
            """)

            moved = _move_to_quarantine_section(
                path,
                ["- This line does not exist in the file"],
                {"- This line does not exist in the file": 5},
            )

            self.assertEqual(moved, 0)
            content = Path(path).read_text()
            # File should be unchanged — no quarantine section added
            self.assertNotIn(QUARANTINE_SECTION, content)

    def test_multiple_lines_moved(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, """\
            # Priorities

            - Claim A is stale
            - Active item
            - Claim B is also stale
            """)

            lines = ["- Claim A is stale", "- Claim B is also stale"]
            counts = {"- Claim A is stale": 6, "- Claim B is also stale": 9}
            moved = _move_to_quarantine_section(path, lines, counts)

            self.assertEqual(moved, 2)
            content = Path(path).read_text()
            before_section = content.split(QUARANTINE_SECTION)[0]
            after_section = content.split(QUARANTINE_SECTION)[1]
            # Both claims removed from original position
            self.assertNotIn("Claim A is stale\n", before_section)
            self.assertNotIn("Claim B is also stale\n", before_section)
            # Active item still present
            self.assertIn("Active item", before_section)
            # Both in quarantine section
            self.assertIn("Claim A is stale", after_section)
            self.assertIn("Claim B is also stale", after_section)


# ---------------------------------------------------------------------------
# run_quarantine — full pipeline
# ---------------------------------------------------------------------------

class TestRunQuarantine(unittest.TestCase):
    def test_no_candidates(self):
        """No stale claims above threshold → empty result."""
        report = _make_gate_report([
            {"claim_text": "some claim", "claim_type": "file_exists",
             "age_builds": 2, "source_file": "x.md"},
        ])
        result = run_quarantine(report, threshold=5, dry_run=True)
        self.assertEqual(result.candidates, 0)
        self.assertEqual(len(result.quarantined), 0)

    def test_threshold_filtering(self):
        """Only claims at or above the threshold become candidates."""
        report = _make_gate_report([
            {"claim_text": "below", "claim_type": "file_exists",
             "tracker_run_count": 4, "source_file": "x.md"},
            {"claim_text": "at threshold", "claim_type": "file_exists",
             "tracker_run_count": 5, "source_file": "x.md"},
            {"claim_text": "above", "claim_type": "file_exists",
             "tracker_run_count": 8, "source_file": "x.md"},
        ])
        result = run_quarantine(report, threshold=5, dry_run=True)
        self.assertEqual(result.candidates, 2)

    def test_age_builds_fallback(self):
        """Uses age_builds when tracker_run_count is absent."""
        report = _make_gate_report([
            {"claim_text": "old claim", "claim_type": "file_exists",
             "age_builds": 7, "source_file": "x.md"},
        ])
        result = run_quarantine(report, threshold=5, dry_run=True)
        self.assertEqual(result.candidates, 1)

    def test_no_source_file_skipped(self):
        """Claims without source_file are skipped."""
        report = _make_gate_report([
            {"claim_text": "orphan claim", "claim_type": "file_exists",
             "tracker_run_count": 10},
        ])
        result = run_quarantine(report, threshold=5, dry_run=True)
        self.assertEqual(result.candidates, 1)
        self.assertEqual(len(result.skipped), 1)
        self.assertIn("No source file", result.skipped[0]["reason"])

    def test_missing_source_file_skipped(self):
        """Claims whose source file doesn't exist on disk are skipped."""
        report = _make_gate_report([
            {"claim_text": "ghost claim", "claim_type": "file_exists",
             "tracker_run_count": 10, "source_file": "/nonexistent/file.md"},
        ])
        result = run_quarantine(report, threshold=5, dry_run=True)
        self.assertEqual(len(result.skipped), 1)
        self.assertIn("not found", result.skipped[0]["reason"])

    @patch("confab.quarantine._move_to_quarantine_section", return_value=1)
    @patch("confab.tracker.update_claim_status")
    @patch("confab.tracker._hash_claim")
    def test_dry_run_does_not_modify(self, mock_hash, mock_update, mock_move):
        """Dry run reports candidates but doesn't move or update tracker."""
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, """\
            # Priorities
            - Stale claim text here
            """)
            report = _make_gate_report([
                {"claim_text": "Stale claim text here", "claim_type": "file_exists",
                 "tracker_run_count": 7, "source_file": path},
            ])
            result = run_quarantine(report, threshold=5, dry_run=True)

            self.assertTrue(result.dry_run)
            self.assertEqual(len(result.quarantined), 1)
            mock_move.assert_not_called()
            mock_update.assert_not_called()

    def test_live_run_moves_claim(self):
        """Live run actually modifies the file and moves the claim."""
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, """\
            # Priorities

            - Audio pipeline: WORKING [v2: verified]
            - Stale: config at deploy/config.toml is ready
            - Active task item
            """)
            report = _make_gate_report([
                {"claim_text": "Stale: config at deploy/config.toml is ready",
                 "claim_type": "file_exists",
                 "tracker_run_count": 8, "source_file": path},
            ])

            with patch("confab.tracker.update_claim_status"), \
                 patch("confab.tracker._hash_claim", return_value="abc123"):
                result = run_quarantine(report, threshold=5, dry_run=False)

            self.assertEqual(len(result.quarantined), 1)
            self.assertTrue(result.quarantined[0].moved)

            content = Path(path).read_text()
            # Claim moved to quarantine
            self.assertIn(QUARANTINE_SECTION, content)
            # Active items preserved
            self.assertIn("Audio pipeline: WORKING", content)
            self.assertIn("Active task item", content)

    def test_already_quarantined_skipped(self):
        """Claims already in the quarantine section are skipped."""
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, f"""\
            # Priorities

            - Active item

            ---

            {QUARANTINE_SECTION}

            - Already quarantined claim  *(quarantined 2026-04-01)*
            """)
            report = _make_gate_report([
                {"claim_text": "Already quarantined claim",
                 "claim_type": "file_exists",
                 "tracker_run_count": 12, "source_file": path},
            ])
            result = run_quarantine(report, threshold=5, dry_run=True)

            self.assertEqual(len(result.skipped), 1)
            self.assertIn("Already in quarantine", result.skipped[0]["reason"])

    def test_claim_not_found_in_file_skipped(self):
        """Claims whose text can't be located in the file are skipped."""
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, """\
            # Priorities

            - Completely different content
            """)
            report = _make_gate_report([
                {"claim_text": "This text is not in the file at all whatsoever",
                 "claim_type": "file_exists",
                 "tracker_run_count": 10, "source_file": path},
            ])
            result = run_quarantine(report, threshold=5, dry_run=True)

            self.assertEqual(len(result.skipped), 1)
            self.assertIn("Line not found", result.skipped[0]["reason"])

    def test_verification_hint_populated(self):
        """Quarantined claims get appropriate verification hints."""
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, """\
            # Priorities

            - Config at deploy/config.toml is ready
            """)
            report = _make_gate_report([
                {"claim_text": "Config at deploy/config.toml is ready",
                 "claim_type": ClaimType.FILE_EXISTS.value,
                 "tracker_run_count": 6, "source_file": path},
            ])
            result = run_quarantine(report, threshold=5, dry_run=True)

            self.assertEqual(len(result.quarantined), 1)
            self.assertIn("ls", result.quarantined[0].verification_hint)

    def test_multiple_claims_from_same_file(self):
        """Multiple stale claims in the same file are batched."""
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, """\
            # Priorities

            - Claim one is stale
            - Active work
            - Claim two is also stale
            """)
            report = _make_gate_report([
                {"claim_text": "Claim one is stale", "claim_type": "file_exists",
                 "tracker_run_count": 6, "source_file": path},
                {"claim_text": "Claim two is also stale", "claim_type": "file_exists",
                 "tracker_run_count": 9, "source_file": path},
            ])

            with patch("confab.tracker.update_claim_status"), \
                 patch("confab.tracker._hash_claim", return_value="h"):
                result = run_quarantine(report, threshold=5, dry_run=False)

            self.assertEqual(len(result.quarantined), 2)
            content = Path(path).read_text()
            self.assertIn("Active work", content)
            # Both in quarantine section
            after = content.split(QUARANTINE_SECTION)[1]
            self.assertIn("Claim one", after)
            self.assertIn("Claim two", after)

    def test_claims_across_multiple_files(self):
        """Claims from different files are handled independently."""
        with tempfile.TemporaryDirectory() as tmp:
            path_a = os.path.join(tmp, "file_a.md")
            path_b = os.path.join(tmp, "file_b.md")
            Path(path_a).write_text("- Stale in file A\n- Keep me A\n")
            Path(path_b).write_text("- Stale in file B\n- Keep me B\n")

            report = _make_gate_report([
                {"claim_text": "Stale in file A", "claim_type": "file_exists",
                 "tracker_run_count": 5, "source_file": path_a},
                {"claim_text": "Stale in file B", "claim_type": "file_exists",
                 "tracker_run_count": 7, "source_file": path_b},
            ])

            with patch("confab.tracker.update_claim_status"), \
                 patch("confab.tracker._hash_claim", return_value="h"):
                result = run_quarantine(report, threshold=5, dry_run=False)

            self.assertEqual(len(result.quarantined), 2)

            content_a = Path(path_a).read_text()
            content_b = Path(path_b).read_text()
            self.assertIn(QUARANTINE_SECTION, content_a)
            self.assertIn(QUARANTINE_SECTION, content_b)
            self.assertIn("Keep me A", content_a)
            self.assertIn("Keep me B", content_b)

    @patch("confab.quarantine._post_quarantine_slack", return_value=True)
    def test_slack_posting(self, mock_slack):
        """When post_slack=True, Slack notification is sent."""
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, """\
            # Priorities

            - Stale claim for slack test
            """)
            report = _make_gate_report([
                {"claim_text": "Stale claim for slack test",
                 "claim_type": "file_exists",
                 "tracker_run_count": 10, "source_file": path},
            ])

            with patch("confab.tracker.update_claim_status"), \
                 patch("confab.tracker._hash_claim", return_value="h"):
                result = run_quarantine(report, threshold=5, post_slack=True, dry_run=False)

            self.assertTrue(result.slack_posted)
            mock_slack.assert_called_once()

    def test_no_slack_on_dry_run(self):
        """Dry run does not post to Slack even when post_slack=True."""
        report = _make_gate_report([
            {"claim_text": "stale", "claim_type": "file_exists",
             "tracker_run_count": 10, "source_file": "/nonexistent.md"},
        ])
        with patch("confab.quarantine._post_quarantine_slack") as mock_slack:
            result = run_quarantine(report, threshold=5, post_slack=True, dry_run=True)
            mock_slack.assert_not_called()

    def test_default_threshold(self):
        """QUARANTINE_THRESHOLD constant is 5."""
        self.assertEqual(QUARANTINE_THRESHOLD, 5)

    def test_tracker_update_failure_non_fatal(self):
        """Tracker update failures don't crash quarantine."""
        with tempfile.TemporaryDirectory() as tmp:
            path = _write_priority_file(tmp, """\
            # Priorities

            - Stale claim tracker fail test
            """)
            report = _make_gate_report([
                {"claim_text": "Stale claim tracker fail test",
                 "claim_type": "file_exists",
                 "tracker_run_count": 6, "source_file": path},
            ])

            with patch("confab.tracker.update_claim_status", side_effect=Exception("DB error")), \
                 patch("confab.tracker._hash_claim", return_value="h"):
                # Should not raise
                result = run_quarantine(report, threshold=5, dry_run=False)

            self.assertEqual(len(result.quarantined), 1)


# ---------------------------------------------------------------------------
# _post_quarantine_slack
# ---------------------------------------------------------------------------

class TestPostQuarantineSlack(unittest.TestCase):
    def test_no_token_returns_false(self):
        from confab.quarantine import _post_quarantine_slack

        result = QuarantineResult(
            timestamp="2026-04-05T00:00:00+00:00",
            threshold=5,
            candidates=1,
            quarantined=[QuarantineAction(
                claim_text="test", claim_type="file_exists",
                source_file="x.md", run_count=5,
                verification_hint="check", moved=True,
            )],
        )
        with patch.dict(os.environ, {}, clear=True):
            # Remove SLACK_BOT_TOKEN if present
            os.environ.pop("SLACK_BOT_TOKEN", None)
            self.assertFalse(_post_quarantine_slack(result))


if __name__ == "__main__":
    unittest.main()
