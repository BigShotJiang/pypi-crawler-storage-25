"""Tests for the benchmark evaluation harness."""

import json
import tempfile
import unittest
from pathlib import Path

from confab.bench import (
    BenchmarkResults,
    CaseResult,
    load_cases,
    run_benchmark,
    _evaluate_case,
    DEFAULT_CASES_FILE,
)


class TestLoadCases(unittest.TestCase):
    """Test loading benchmark cases from JSON."""

    def test_load_default_cases(self):
        cases = load_cases()
        self.assertGreater(len(cases), 0)
        # Each case has required fields
        for case in cases:
            self.assertIn("id", case)
            self.assertIn("category", case)
            self.assertIn("text", case)
            self.assertIn("expected_result", case)

    def test_load_custom_cases(self):
        data = {
            "version": "1.0.0",
            "description": "test",
            "cases": [
                {
                    "id": "test-001",
                    "category": "test",
                    "text": "The file core/confab/cli.py exists",
                    "expected_type": "file_exists",
                    "expected_result": "passed",
                    "description": "test case",
                }
            ],
        }
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False
        ) as f:
            json.dump(data, f)
            f.flush()
            cases = load_cases(Path(f.name))
            self.assertEqual(len(cases), 1)
            self.assertEqual(cases[0]["id"], "test-001")

    def test_load_missing_file_raises(self):
        with self.assertRaises(FileNotFoundError):
            load_cases(Path("/nonexistent/path.json"))


class TestEvaluateCase(unittest.TestCase):
    """Test individual case evaluation."""

    def test_detected_confabulation(self):
        """A false blocker with an env var should be detected."""
        case = {
            "id": "test-fb",
            "category": "false_blocker",
            "text": "Pipeline blocked on missing NONEXISTENT_TEST_VAR_12345 env var",
            "expected_result": "detected",
            "description": "test",
        }
        result = _evaluate_case(case)
        self.assertEqual(result.case_id, "test-fb")
        # Should at least extract the claim (env var pattern)
        self.assertGreater(result.claims_extracted, 0)

    def test_true_positive_passes(self):
        """A true file reference should not be flagged."""
        case = {
            "id": "test-tp",
            "category": "true_positive",
            "text": "Gate logic in core/confab/gate.py handles the cascade check",
            "expected_result": "passed",
            "description": "test",
        }
        result = _evaluate_case(case)
        self.assertIn(result.outcome, ("correct",))

    def test_unknown_expected_result(self):
        """Unknown expected_result should produce an error."""
        case = {
            "id": "test-err",
            "category": "test",
            "text": "some text",
            "expected_result": "unknown_value",
            "description": "test",
        }
        result = _evaluate_case(case)
        self.assertEqual(result.outcome, "error")

    def test_case_result_to_dict(self):
        """CaseResult.to_dict() returns expected keys."""
        result = CaseResult(
            case_id="x", category="y", text="z", description="d",
            expected_result="detected", claims_extracted=1,
            claim_types_found=["file_exists"],
            verification_results=["failed"],
            outcome="correct", detail="ok", elapsed_ms=10.0,
        )
        d = result.to_dict()
        self.assertEqual(d["case_id"], "x")
        self.assertEqual(d["outcome"], "correct")
        self.assertIn("elapsed_ms", d)


class TestScoringLogic(unittest.TestCase):
    """Test that the scoring logic correctly distinguishes hits from misses."""

    def test_passed_verification_on_detected_case_is_miss(self):
        """When expected=detected but verification returns PASSED, it's a miss.

        PASSED means the claim checked out as true — confabulation NOT detected.
        This was the bug identified in the prior sprint.
        """
        case = {
            "id": "test-scoring",
            "category": "stale_status",
            "text": "Substack cookie: WORKING [v2: verified 2026-03-31]",
            "expected_result": "detected",
            "description": "A confab that verification doesn't catch (PASSED = miss)",
        }
        result = _evaluate_case(case)
        if result.claims_extracted > 0 and "passed" in result.verification_results:
            self.assertEqual(
                result.outcome, "missed",
                "PASSED verification on a detected-expected case should be a miss, not correct"
            )

    def test_failed_verification_on_detected_case_is_correct(self):
        """When expected=detected and verification FAILED, it's a correct detection."""
        case = {
            "id": "test-scoring-fail",
            "category": "false_blocker",
            "text": "Pipeline blocked on missing NONEXISTENT_TEST_VAR_12345 env var",
            "expected_result": "detected",
            "description": "A confab that verification catches",
        }
        result = _evaluate_case(case)
        if result.claims_extracted > 0 and "failed" in result.verification_results:
            self.assertEqual(result.outcome, "correct")


class TestImplicitFileReferences(unittest.TestCase):
    """Test that implicit file reference patterns extract FILE_EXISTS claims."""

    def test_see_x_for_y_pattern(self):
        """'See X for Y' should extract a file_exists claim."""
        case = {
            "id": "test-see",
            "category": "nonexistent_reference",
            "text": "See core/confab/nonexistent_dashboard.py for the monitoring implementation",
            "expected_result": "detected",
            "description": "See X for Y pattern",
        }
        result = _evaluate_case(case)
        self.assertGreater(result.claims_extracted, 0, "'See X for Y' should extract a claim")

    def test_lives_in_pattern(self):
        """'lives in X' should extract a file_exists claim."""
        case = {
            "id": "test-lives",
            "category": "nonexistent_reference",
            "text": "The scoring engine lives in projects/recruiting/engine/nonexistent_v99.py",
            "expected_result": "detected",
            "description": "lives in X pattern",
        }
        result = _evaluate_case(case)
        self.assertGreater(result.claims_extracted, 0, "'lives in X' should extract a claim")

    def test_run_x_pattern(self):
        """'Run X.py' should extract a file_exists claim."""
        case = {
            "id": "test-run",
            "category": "nonexistent_reference",
            "text": "Run projects/synthesis/scripts/nonexistent_publish_all.py to batch-publish entries",
            "expected_result": "detected",
            "description": "Run X.py pattern",
        }
        result = _evaluate_case(case)
        self.assertGreater(result.claims_extracted, 0, "'Run X.py' should extract a claim")

    def test_check_x_pattern(self):
        """'Check X.md' should extract a file_exists claim."""
        case = {
            "id": "test-check",
            "category": "nonexistent_reference",
            "text": "Check docs/architecture/NONEXISTENT_DESIGN.md for the three-agent coordination spec",
            "expected_result": "detected",
            "description": "Check X.md pattern",
        }
        result = _evaluate_case(case)
        self.assertGreater(result.claims_extracted, 0, "'Check X.md' should extract a claim")

    def test_handled_by_pattern(self):
        """'handled by X' should extract a file_exists claim."""
        case = {
            "id": "test-handled",
            "category": "true_positive",
            "text": "Claim extraction is handled by core/confab/claims.py",
            "expected_result": "passed",
            "description": "handled by pattern with real file",
        }
        result = _evaluate_case(case)
        # Should extract a claim AND not false-positive
        self.assertIn(result.outcome, ("correct",))

    def test_true_file_with_implicit_ref_no_false_positive(self):
        """Implicit ref patterns on real files should not false-positive."""
        case = {
            "id": "test-real-see",
            "category": "true_positive",
            "text": "See core/confab/bench.py for the benchmark implementation",
            "expected_result": "passed",
            "description": "See pattern with real file",
        }
        result = _evaluate_case(case)
        self.assertNotEqual(result.outcome, "false_positive",
                          "Real file referenced via 'See X for Y' should not false-positive")


class TestRunBenchmark(unittest.TestCase):
    """Test the full benchmark runner."""

    def test_full_benchmark_runs(self):
        """Full benchmark completes without errors."""
        results = run_benchmark()
        self.assertGreater(results.total, 0)
        self.assertEqual(results.errors, 0)
        # Total should equal sum of outcomes
        self.assertEqual(
            results.total,
            results.correct + results.missed + results.false_positive + results.errors,
        )

    def test_category_filter(self):
        """Category filter restricts cases."""
        results = run_benchmark(categories=["true_positive"])
        for case in results.cases:
            self.assertEqual(case.category, "true_positive")

    def test_no_false_positives_on_true_claims(self):
        """True positive cases should never be flagged as false positives."""
        results = run_benchmark(categories=["true_positive"])
        self.assertEqual(results.false_positive, 0)

    def test_false_blockers_detected(self):
        """The obs-3528 false blocker pattern should be detected."""
        results = run_benchmark(categories=["false_blocker"])
        # All false blockers should be caught (this is the core use case)
        self.assertEqual(results.missed, 0, "False blockers should all be detected")

    def test_nonexistent_references_detected(self):
        """Nonexistent file references should all be detected."""
        results = run_benchmark(categories=["nonexistent_reference"])
        self.assertEqual(results.missed, 0, "Nonexistent references should all be detected")

    def test_by_category_populated(self):
        """by_category dict should have entries for each category."""
        results = run_benchmark()
        self.assertGreater(len(results.by_category), 0)
        for cat, counts in results.by_category.items():
            self.assertIn("total", counts)
            self.assertGreater(counts["total"], 0)


class TestBenchmarkResults(unittest.TestCase):
    """Test BenchmarkResults aggregation and formatting."""

    def _make_results(self, cases=None):
        r = BenchmarkResults()
        if cases:
            for c in cases:
                r.cases.append(c)
                r.total += 1
                if c.outcome == "correct":
                    r.correct += 1
                elif c.outcome == "missed":
                    r.missed += 1
                elif c.outcome == "false_positive":
                    r.false_positive += 1
        return r

    def test_detection_rate_all_detected(self):
        cases = [
            CaseResult("a", "fb", "t", "d", "detected", 1, [], [], "correct", "", 0),
            CaseResult("b", "fb", "t", "d", "detected", 1, [], [], "correct", "", 0),
        ]
        r = self._make_results(cases)
        self.assertEqual(r.detection_rate, 1.0)

    def test_detection_rate_half_missed(self):
        cases = [
            CaseResult("a", "fb", "t", "d", "detected", 1, [], [], "correct", "", 0),
            CaseResult("b", "fb", "t", "d", "detected", 0, [], [], "missed", "", 0),
        ]
        r = self._make_results(cases)
        self.assertEqual(r.detection_rate, 0.5)

    def test_false_positive_rate(self):
        cases = [
            CaseResult("a", "tp", "t", "d", "passed", 1, [], ["failed"], "false_positive", "", 0),
            CaseResult("b", "tp", "t", "d", "passed", 0, [], [], "correct", "", 0),
        ]
        r = self._make_results(cases)
        self.assertEqual(r.false_positive_rate, 0.5)

    def test_format_table(self):
        r = self._make_results([
            CaseResult("a", "fb", "text", "desc", "detected", 1, [], [], "correct", "ok", 5),
        ])
        table = r.format_table()
        self.assertIn("CONFAB BENCH", table)
        self.assertIn("PASS", table)
        self.assertIn("Detection rate", table)

    def test_to_dict(self):
        r = self._make_results()
        d = r.to_dict()
        self.assertIn("total", d)
        self.assertIn("detection_rate", d)
        self.assertIn("cases", d)


if __name__ == "__main__":
    unittest.main()
