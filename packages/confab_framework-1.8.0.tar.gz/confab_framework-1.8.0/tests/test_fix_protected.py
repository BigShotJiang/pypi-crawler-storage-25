"""Tests for _is_protected_line — prevents confab fix from deleting reference data."""

import tempfile
from pathlib import Path

from core.confab.cli import _is_protected_line


class TestProtectedLineDetection:
    """Test that protected content is correctly identified."""

    def test_markdown_table_row_protected(self):
        result = _is_protected_line(None, "| CPI >3.5% | 39 | HOLD. March CPI baked. |")
        assert result == "markdown_table_row"

    def test_markdown_table_header_protected(self):
        result = _is_protected_line(None, "| Position | Contracts | Status |")
        assert result == "markdown_table_row"

    def test_directive_never_protected(self):
        text = 'Existing 15 attorney-ready leads preserved in `projects/sentinel/`. **NEVER write about publicly.**'
        result = _is_protected_line(None, text)
        assert result == "directive_keyword"

    def test_directive_stopped_protected(self):
        result = _is_protected_line(None, "**Sentinel: STOPPED** (Dennis directive, Apr 8). No further work.")
        assert result == "directive_keyword"

    def test_directive_paused_protected(self):
        result = _is_protected_line(None, "Canton Coin App Research — PAUSED (Mar 3, 2026)")
        assert result == "directive_keyword"

    def test_normal_stale_claim_not_protected(self):
        result = _is_protected_line(None, "Notes volume increased: Daily cap raised from 2 → 5 notes/day.")
        assert result is None

    def test_old_build_log_not_protected(self):
        result = _is_protected_line(None, "Cleaned stale build sections from builder_priorities.md")
        assert result is None

    def test_section_awareness_portfolio(self):
        """Lines under Portfolio Status section should be protected."""
        content = """# Builder Priorities

## Portfolio Status (verified: 2026-04-08)

**Cash: $255.49** | CPI positions winning big.

S&P futures -0.4% after yesterday's rally.

---

## Latest Build
Some old build note here.
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as f:
            f.write(content)
            f.flush()
            # Cash line — in Portfolio Status section
            result = _is_protected_line(f.name, "**Cash: $255.49** | CPI positions winning big.")
            assert result is not None
            assert "portfolio status" in result

            # S&P line — also in Portfolio Status section
            result = _is_protected_line(f.name, "S&P futures -0.4% after yesterday's rally.")
            assert result is not None
            assert "portfolio status" in result

            # Build note — in Latest Build section, not protected by section
            result = _is_protected_line(f.name, "Some old build note here.")
            assert result is None

        Path(f.name).unlink()

    def test_section_awareness_standing_items(self):
        """Lines under Standing Items section should be protected."""
        content = """# Priorities

## Standing Items

- Audio pipeline: WORKING [v2: verified]
- Substack pipeline: WORKING [v2: verified]
"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as f:
            f.write(content)
            f.flush()
            result = _is_protected_line(f.name, "Audio pipeline: WORKING [v2: verified]")
            assert result is not None
            assert "standing items" in result
        Path(f.name).unlink()

    def test_pipe_in_normal_text_not_protected(self):
        """A single pipe in text should not trigger table protection."""
        result = _is_protected_line(None, "CPI positions winning big | some note")
        assert result is None  # Only 1 pipe, need >= 2

    def test_nonexistent_file_falls_through(self):
        """If source file doesn't exist, section check is skipped gracefully."""
        result = _is_protected_line("/nonexistent/path.md", "Some normal claim")
        assert result is None
