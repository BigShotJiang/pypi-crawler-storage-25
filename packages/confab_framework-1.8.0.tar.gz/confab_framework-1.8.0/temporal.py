"""Temporal consistency detector for the confabulation framework.

Catches the "dreamer-from-memory" year-confusion pattern: agents present
market/economic data from a previous year as current-year events. This was
documented 4 times on April 4, 2026 (ep-1168, ep-1172, The Same Desk,
The Wrecking Ball) — all involving April 2025 Liberation Day crash data
("$6.6T crash", "S&P -5.97%", "Dow -2,231") presented as April 2026.

The detector operates on raw text (handoff messages, priority files) and
flags TEMPORAL_MISMATCH when market/economic claims reference a year that
doesn't match the current year. This is a text-level scan, not a
claim-by-claim verifier — it catches patterns the claim extractor misses.

Design: regex extracts (year, context_sentence) pairs. If the sentence
contains market/economic keywords and the year != current year, flag it.
"""

import re
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional, Any
from zoneinfo import ZoneInfo


# Market/economic keywords that indicate a year reference is about market data.
# These are deliberately broad — false positives are cheap (agent checks),
# false negatives are expensive (confabulation propagates).
MARKET_KEYWORDS = {
    # Market moves
    "crash", "rally", "surge", "plunge", "drop", "fell", "rose", "gain",
    "loss", "decline", "correction", "sell-off", "selloff", "rout",
    # Indices and instruments
    "s&p", "dow", "nasdaq", "russell", "vix", "treasury", "yield",
    "crude", "oil", "gold", "bitcoin", "btc", "brent", "wti",
    # Economic data
    "gdp", "cpi", "ppi", "inflation", "unemployment", "payroll",
    "nonfarm", "jobs", "employment", "tariff", "recession",
    # Financial metrics
    "trillion", "billion", "basis point", "bps", "percent",
    # Specific patterns from the confabulated texts
    "liberation day", "worst", "biggest", "largest", "record",
    "market cap", "erased", "wiped",
}

# Patterns that extract year references from text.
# Each pattern captures (full_match, year_str).
YEAR_PATTERNS = [
    # "April 2025", "March 2026", "Q4 2025"
    re.compile(
        r'(?:(?:January|February|March|April|May|June|July|August|September|'
        r'October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|'
        r'Nov|Dec|Q[1-4])\s+)(20[0-9]{2})',
        re.IGNORECASE,
    ),
    # "April 2, 2025", "March 14, 2026" — Month Day, Year format
    # (distinct from Month Year because of the day number in between)
    re.compile(
        r'(?:January|February|March|April|May|June|July|August|September|'
        r'October|November|December|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|'
        r'Nov|Dec)\s+\d{1,2},?\s+(20[0-9]{2})',
        re.IGNORECASE,
    ),
    # "2025-04-02", "2025/04/02"
    re.compile(r'(20[0-9]{2})[-/]\d{1,2}[-/]\d{1,2}'),
    # "in 2025", "since 2024", "from 2025", "during 2025"
    re.compile(r'(?:in|since|from|during|of|by)\s+(20[0-9]{2})\b', re.IGNORECASE),
    # Standalone year after specific market phrases:
    # "the 2025 crash", "a 2025 sell-off"
    re.compile(r'(?:the|a|an)\s+(20[0-9]{2})\s+(?:crash|rally|correction|sell-?off|recession|crisis)', re.IGNORECASE),
]

# Known anniversary-confusion markers — specific data points from
# documented confabulations that are year-locked to 2025 Liberation Day.
# If these exact figures appear in text about 2026, it's almost certainly
# a temporal mismatch regardless of what year is explicitly stated.
KNOWN_STALE_MARKERS = [
    # April 2025 Liberation Day crash data
    (r'\$6\.6\s*T', "April 2025 Liberation Day crash ($6.6T market cap loss)"),
    (r'S&P\s*(?:500\s*)?-5\.97%', "April 2025 Liberation Day S&P drop"),
    (r'Dow\s*-2,?231', "April 2025 Liberation Day Dow drop"),
    (r'worst\s+(?:single[- ]day|two[- ]day|2[- ]day)\s+(?:loss|drop|decline)', "Possible Liberation Day superlative — verify year"),
]


@dataclass
class TemporalMismatch:
    """A detected temporal inconsistency."""
    text_excerpt: str          # The sentence or context containing the mismatch
    detected_year: int         # The year found in the text
    current_year: int          # What year it actually is
    match_type: str            # "year_keyword", "stale_marker"
    evidence: str              # Why this was flagged
    source_file: Optional[str] = None
    source_line: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "text_excerpt": self.text_excerpt[:200],
            "detected_year": self.detected_year,
            "current_year": self.current_year,
            "match_type": self.match_type,
            "evidence": self.evidence,
            "source_file": self.source_file,
            "source_line": self.source_line,
        }


def _get_sentence_context(text: str, match_start: int, match_end: int) -> str:
    """Extract the sentence containing a match for context."""
    # Find sentence boundaries (rough: look for period, newline, or bullet)
    sent_start = max(0, match_start - 150)
    sent_end = min(len(text), match_end + 150)

    # Try to find sentence start
    for delim in ['\n', '. ', '- ', '* ']:
        idx = text.rfind(delim, sent_start, match_start)
        if idx != -1:
            sent_start = idx + len(delim)
            break

    # Try to find sentence end
    for delim in ['\n', '. ', '- ', '* ']:
        idx = text.find(delim, match_end, sent_end)
        if idx != -1:
            sent_end = idx
            break

    return text[sent_start:sent_end].strip()


def _sentence_has_market_keywords(sentence: str) -> bool:
    """Check if a sentence contains market/economic keywords."""
    lower = sentence.lower()
    return any(kw in lower for kw in MARKET_KEYWORDS)


def check_temporal_consistency(
    text: str,
    current_year: Optional[int] = None,
    source_file: Optional[str] = None,
) -> List[TemporalMismatch]:
    """Scan text for temporal mismatches in market/economic claims.

    Detects two patterns:
    1. Year references in market-context sentences where year != current_year
    2. Known stale data markers (e.g., Liberation Day crash figures)

    Args:
        text: The text to scan (handoff message, priority file content, etc.)
        current_year: Override for current year (for testing). Defaults to now.
        source_file: Optional source file path for reporting.

    Returns:
        List of TemporalMismatch objects. Empty list = no issues found.
    """
    if current_year is None:
        current_year = datetime.now(ZoneInfo("America/Los_Angeles")).year

    mismatches: List[TemporalMismatch] = []
    seen_excerpts: set = set()  # Dedup

    # Pattern 1: Year references in market-context sentences
    for pattern in YEAR_PATTERNS:
        for match in pattern.finditer(text):
            # Extract year — it's always in group 1
            year_str = match.group(1) if match.lastindex and match.lastindex >= 1 else match.group(0)
            # Handle patterns where year is embedded (e.g., "2025-04-02")
            year_match = re.search(r'20[0-9]{2}', year_str)
            if not year_match:
                continue
            year = int(year_match.group(0))

            if year == current_year:
                continue  # Current year is fine

            # Future years > current+1 are suspicious but different issue
            if year > current_year:
                continue

            sentence = _get_sentence_context(text, match.start(), match.end())

            if not _sentence_has_market_keywords(sentence):
                continue  # Not a market/economic context

            excerpt_key = sentence[:100]
            if excerpt_key in seen_excerpts:
                continue
            seen_excerpts.add(excerpt_key)

            mismatches.append(TemporalMismatch(
                text_excerpt=sentence,
                detected_year=year,
                current_year=current_year,
                match_type="year_keyword",
                evidence=(
                    f"Market/economic claim references {year}, but current year is "
                    f"{current_year}. This may be the dreamer-from-memory pattern — "
                    f"verify the data is from {current_year}, not a prior year."
                ),
                source_file=source_file,
            ))

    # Pattern 2: Known stale data markers (year-locked confabulation signatures)
    for marker_pattern, description in KNOWN_STALE_MARKERS:
        for match in re.finditer(marker_pattern, text, re.IGNORECASE):
            sentence = _get_sentence_context(text, match.start(), match.end())

            excerpt_key = sentence[:100]
            if excerpt_key in seen_excerpts:
                continue
            seen_excerpts.add(excerpt_key)

            mismatches.append(TemporalMismatch(
                text_excerpt=sentence,
                detected_year=2025,  # These markers are all from 2025
                current_year=current_year,
                match_type="stale_marker",
                evidence=(
                    f"Known stale data marker detected: {description}. "
                    f"This data point is from April 2025, not {current_year}. "
                    f"The dreamer-from-memory pattern recycles anniversary data."
                ),
                source_file=source_file,
            ))

    return mismatches


def check_temporal_consistency_file(
    file_path: str,
    current_year: Optional[int] = None,
) -> List[TemporalMismatch]:
    """Convenience wrapper: scan a file for temporal mismatches."""
    try:
        with open(file_path) as f:
            text = f.read()
    except (OSError, IOError):
        return []

    mismatches = check_temporal_consistency(
        text, current_year=current_year, source_file=file_path
    )

    # Add line numbers
    if mismatches:
        lines = text.split('\n')
        for mm in mismatches:
            for i, line in enumerate(lines, 1):
                if mm.text_excerpt[:50] in line:
                    mm.source_line = i
                    break

    return mismatches
