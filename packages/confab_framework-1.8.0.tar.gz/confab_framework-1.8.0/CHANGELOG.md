# Changelog

## v1.8.0 (2026-04-10)

### Fixed
- **Count tolerance computed from actual, not claimed** — inflated count claims (e.g., "500 entries" when actual is 462) no longer sneak under the tolerance threshold. Tolerance is now based on ground truth, making the verifier correctly asymmetric: a larger false claim gets no benefit from its own inflation. Fixes cc-003 benchmark miss.
- Applied the same fix across all count verifiers: `_verify_json_array_count`, `_verify_regex_count`, `_verify_test_count`

### Changed
- Benchmark: 40/40 (100% detection), 0% false positives
- 868 tests total

## v1.7.1 (2026-04-10)

### Fixed
- **Stale false positives for permanent directives** — directive checks no longer flag permanent project directives (e.g., "STOPPED", "NEVER write publicly") as temporal expiry candidates
- Temporal expiry scanner correctly distinguishes permanent directives from time-bound claims

## v1.7.0 (2026-04-09)

### Added
- **Count anchoring** — count_confusion detection improved from 50% to 100% by anchoring numeric patterns to system nouns (tests, entries, posts, notes, dossiers)
- **directive_check claim type** — detects agent work on stopped/paused/wind-down projects via `confab.toml [confab.project_directives]` config
- 4 new benchmark cases for directive_violation category
- Benchmark detection rate: 76.7% → 86.7% → 93.3% (0% false positives across all 38 cases)
- Temporal consistency detector for confab gate — catches dreamer year-confusion pattern
- Temporal scanner restricted to handoff text only (fixes 6 persistent false positives)

### Changed
- Updated DESIGN.md detection frontier to reflect current 93.3% detection rate
- 849 tests total

## v1.6.0 (2026-04-08)

### Added
- **OpenAI Agents SDK integration** (`confab.integrations.openai_agents`)
- Benchmark evaluation harness with 38 cases across 8 categories
- Quarantine tests (39 new, 849 total)

### Fixed
- Gate false positive on session activity count claims
- Test count routing priority in gate
- Gate false positive from wrong module path + overly greedy regex

## v1.5.0 (2026-04-02)

### Added
- **Claude Code hooks integration** — `confab hook` CLI subcommand for real-time confabulation detection during Claude Code sessions
  - Reads hook event JSON from stdin (Stop, PostToolUse)
  - Extracts text from transcripts (Stop) and file writes (PostToolUse Write/Edit)
  - Returns `additionalContext` warnings in Claude Code hook response format
  - Example settings.json config at `examples/claude_code_hooks.md`
- `confab init` — generate a starter `confab.toml` with auto-detected scan targets

### Changed
- 17 new tests for hook integration (679 total)

## v1.4.0 (2026-03-31)

### Added
- **Confidence scoring** — claims scored 0.0-1.0 for extraction certainty
- Anthropic Python SDK integration (`confab.integrations.agent_sdk`)

## v1.3.0 (2026-03-29)

### Fixed
- Notes queue gate false positive on X/Y format

### Added
- Integration docs for LangChain, CrewAI, AutoGen

## v1.2.0 (2026-03-28)

### Added
- AutoGen integration
- Preflight load order fix

## v1.1.0 (2026-03-27)

### Added
- LangChain integration cleanup for PyPI

## v1.0.0 (2026-03-25)

### Added
- Initial PyPI release
- Claim extraction, classification, verification pipeline
- Gate command for CI/CD integration
- SQLite persistence for claim tracking
- Volatility-adaptive thresholds
- GitHub Actions workflow
