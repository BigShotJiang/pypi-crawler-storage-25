"""Benchmark evaluation harness for the confabulation framework.

Runs a dataset of known confabulations and true claims through the
extract+verify pipeline and measures detection effectiveness.

Sourced from ia's documented confabulation history:
- obs-3528: 16-build false blocker cascade
- idea-298: dreamer-from-memory pattern (5+ documented instances)
- Known good claims as true-positive controls

Usage:
    from confab.bench import run_benchmark, load_cases
    results = run_benchmark()
    print(results.format_table())
"""

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from .claims import Claim, ClaimType, extract_claims
from .verify import (
    VerificationOutcome,
    VerificationResult,
    verify_all,
)


BENCHDATA_DIR = Path(__file__).parent / "benchdata"
DEFAULT_CASES_FILE = BENCHDATA_DIR / "cases.json"


@dataclass
class CaseResult:
    """Result of running a single benchmark case."""
    case_id: str
    category: str
    text: str
    description: str
    expected_result: str          # "detected" or "passed"
    claims_extracted: int         # how many claims extract_claims found
    claim_types_found: List[str]  # types of claims found
    verification_results: List[str]  # verification outcomes
    outcome: str                  # "correct", "missed", "false_positive", "error"
    detail: str                   # explanation of the outcome
    elapsed_ms: float             # time taken

    def to_dict(self) -> Dict[str, Any]:
        return {
            "case_id": self.case_id,
            "category": self.category,
            "expected": self.expected_result,
            "outcome": self.outcome,
            "claims_extracted": self.claims_extracted,
            "claim_types": self.claim_types_found,
            "verification_results": self.verification_results,
            "detail": self.detail,
            "elapsed_ms": round(self.elapsed_ms, 1),
        }


@dataclass
class BenchmarkResults:
    """Aggregate results from a benchmark run."""
    total: int = 0
    correct: int = 0
    missed: int = 0
    false_positive: int = 0
    errors: int = 0
    by_category: Dict[str, Dict[str, int]] = field(default_factory=dict)
    cases: List[CaseResult] = field(default_factory=list)
    elapsed_ms: float = 0.0

    @property
    def detection_rate(self) -> float:
        """Fraction of confabulations correctly detected."""
        confab_cases = self.total - self._true_positive_count
        if confab_cases == 0:
            return 1.0
        detected = sum(
            1 for c in self.cases
            if c.expected_result == "detected" and c.outcome == "correct"
        )
        return detected / confab_cases

    @property
    def false_positive_rate(self) -> float:
        """Fraction of true claims incorrectly flagged."""
        if self._true_positive_count == 0:
            return 0.0
        flagged = sum(
            1 for c in self.cases
            if c.expected_result == "passed" and c.outcome == "false_positive"
        )
        return flagged / self._true_positive_count

    @property
    def _true_positive_count(self) -> int:
        return sum(1 for c in self.cases if c.expected_result == "passed")

    def format_table(self) -> str:
        """Format results as a human-readable table."""
        lines = []
        lines.append("=" * 72)
        lines.append("CONFAB BENCH — Evaluation Results")
        lines.append("=" * 72)
        lines.append("")

        # Summary
        lines.append(f"  Total cases:      {self.total}")
        lines.append(f"  Correct:          {self.correct}")
        lines.append(f"  Missed:           {self.missed}")
        lines.append(f"  False positives:  {self.false_positive}")
        lines.append(f"  Errors:           {self.errors}")
        lines.append(f"  Detection rate:   {self.detection_rate:.1%}")
        lines.append(f"  False pos. rate:  {self.false_positive_rate:.1%}")
        lines.append(f"  Time:             {self.elapsed_ms:.0f}ms")
        lines.append("")

        # By category
        lines.append("-" * 72)
        lines.append(f"  {'Category':<25} {'Total':>6} {'Correct':>8} {'Missed':>7} {'FP':>4}")
        lines.append("-" * 72)
        for cat, counts in sorted(self.by_category.items()):
            lines.append(
                f"  {cat:<25} {counts.get('total', 0):>6} "
                f"{counts.get('correct', 0):>8} "
                f"{counts.get('missed', 0):>7} "
                f"{counts.get('false_positive', 0):>4}"
            )
        lines.append("")

        # Individual case results
        lines.append("-" * 72)
        lines.append("  Case Details:")
        lines.append("-" * 72)
        for case in self.cases:
            icon = {
                "correct": "PASS",
                "missed": "MISS",
                "false_positive": "FP  ",
                "error": "ERR ",
            }.get(case.outcome, "????")
            lines.append(f"  [{icon}] {case.case_id}: {case.detail}")
        lines.append("")
        lines.append("=" * 72)

        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total": self.total,
            "correct": self.correct,
            "missed": self.missed,
            "false_positive": self.false_positive,
            "errors": self.errors,
            "detection_rate": round(self.detection_rate, 4),
            "false_positive_rate": round(self.false_positive_rate, 4),
            "elapsed_ms": round(self.elapsed_ms, 1),
            "by_category": self.by_category,
            "cases": [c.to_dict() for c in self.cases],
        }


def load_cases(cases_file: Optional[Path] = None) -> List[Dict[str, Any]]:
    """Load benchmark cases from JSON file."""
    path = cases_file or DEFAULT_CASES_FILE
    if not path.exists():
        raise FileNotFoundError(f"Benchmark cases file not found: {path}")
    data = json.loads(path.read_text())
    return data["cases"]


def _evaluate_case(case: Dict[str, Any]) -> CaseResult:
    """Run a single benchmark case through extract+verify and evaluate."""
    case_id = case["id"]
    category = case["category"]
    text = case["text"]
    expected = case["expected_result"]
    description = case.get("description", "")

    start = time.monotonic()

    try:
        # Step 1: Extract claims from the text
        claims = extract_claims(text, source_file="<bench>")

        # Step 2: Verify extracted claims
        outcomes = verify_all(claims) if claims else []

        elapsed = (time.monotonic() - start) * 1000

        claim_types = [c.claim_type.value for c in claims]
        verif_results = [o.result.value for o in outcomes]

        # Step 3: Evaluate against expected outcome
        if expected == "detected":
            # For confabulation cases: success = framework extracted a claim
            # AND (verification failed or flagged it as inconclusive/stale)
            if not claims:
                return CaseResult(
                    case_id=case_id, category=category, text=text,
                    description=description, expected_result=expected,
                    claims_extracted=0, claim_types_found=[],
                    verification_results=[],
                    outcome="missed",
                    detail=f"No claims extracted from confabulation text",
                    elapsed_ms=elapsed,
                )

            # Check if any claim was flagged (failed verification or found verifiable)
            has_failed = any(o.result == VerificationResult.FAILED for o in outcomes)
            has_verifiable = any(
                o.result in (VerificationResult.PASSED, VerificationResult.FAILED,
                             VerificationResult.INCONCLUSIVE)
                for o in outcomes
            )

            has_inconclusive = any(
                o.result == VerificationResult.INCONCLUSIVE for o in outcomes
            )
            # PASSED means the claim checked out as true — confabulation NOT detected.
            # Only FAILED = definite detection, INCONCLUSIVE = partial detection.
            all_passed = all(
                o.result == VerificationResult.PASSED
                for o in outcomes
                if o.result in (VerificationResult.PASSED, VerificationResult.FAILED,
                                VerificationResult.INCONCLUSIVE)
            )

            if has_failed:
                return CaseResult(
                    case_id=case_id, category=category, text=text,
                    description=description, expected_result=expected,
                    claims_extracted=len(claims), claim_types_found=claim_types,
                    verification_results=verif_results,
                    outcome="correct",
                    detail=f"Confabulation detected: {len(claims)} claim(s), verification FAILED",
                    elapsed_ms=elapsed,
                )
            elif has_inconclusive:
                # Extracted and routed — inconclusive means the system flagged
                # it for review (partial detection)
                return CaseResult(
                    case_id=case_id, category=category, text=text,
                    description=description, expected_result=expected,
                    claims_extracted=len(claims), claim_types_found=claim_types,
                    verification_results=verif_results,
                    outcome="correct",
                    detail=f"Confabulation flagged as inconclusive ({verif_results})",
                    elapsed_ms=elapsed,
                )
            elif all_passed:
                # PASSED = claim looks true = confabulation was NOT caught
                return CaseResult(
                    case_id=case_id, category=category, text=text,
                    description=description, expected_result=expected,
                    claims_extracted=len(claims), claim_types_found=claim_types,
                    verification_results=verif_results,
                    outcome="missed",
                    detail=f"Confabulation not detected: verification PASSED (false negative)",
                    elapsed_ms=elapsed,
                )
            else:
                # Claims found but all skipped — partial miss
                return CaseResult(
                    case_id=case_id, category=category, text=text,
                    description=description, expected_result=expected,
                    claims_extracted=len(claims), claim_types_found=claim_types,
                    verification_results=verif_results,
                    outcome="missed",
                    detail=f"Claims extracted but all skipped (not auto-verifiable)",
                    elapsed_ms=elapsed,
                )

        elif expected == "passed":
            # For true-positive controls: success = claim passes or is correctly handled
            if not claims:
                # No claims extracted from a true claim — that's fine, it's not flagged
                return CaseResult(
                    case_id=case_id, category=category, text=text,
                    description=description, expected_result=expected,
                    claims_extracted=0, claim_types_found=[],
                    verification_results=[],
                    outcome="correct",
                    detail="No false flags — claim not extracted (benign)",
                    elapsed_ms=elapsed,
                )

            has_failed = any(o.result == VerificationResult.FAILED for o in outcomes)
            if has_failed:
                return CaseResult(
                    case_id=case_id, category=category, text=text,
                    description=description, expected_result=expected,
                    claims_extracted=len(claims), claim_types_found=claim_types,
                    verification_results=verif_results,
                    outcome="false_positive",
                    detail=f"True claim incorrectly flagged as FAILED",
                    elapsed_ms=elapsed,
                )
            else:
                return CaseResult(
                    case_id=case_id, category=category, text=text,
                    description=description, expected_result=expected,
                    claims_extracted=len(claims), claim_types_found=claim_types,
                    verification_results=verif_results,
                    outcome="correct",
                    detail=f"True claim correctly handled ({verif_results})",
                    elapsed_ms=elapsed,
                )

        else:
            elapsed = (time.monotonic() - start) * 1000
            return CaseResult(
                case_id=case_id, category=category, text=text,
                description=description, expected_result=expected,
                claims_extracted=0, claim_types_found=[],
                verification_results=[],
                outcome="error",
                detail=f"Unknown expected_result: {expected}",
                elapsed_ms=elapsed,
            )

    except Exception as e:
        elapsed = (time.monotonic() - start) * 1000
        return CaseResult(
            case_id=case_id, category=category, text=text,
            description=description, expected_result=expected,
            claims_extracted=0, claim_types_found=[],
            verification_results=[],
            outcome="error",
            detail=f"Exception: {e}",
            elapsed_ms=elapsed,
        )


def run_benchmark(
    cases_file: Optional[Path] = None,
    categories: Optional[List[str]] = None,
) -> BenchmarkResults:
    """Run the full benchmark suite.

    Args:
        cases_file: Path to cases JSON. Defaults to benchdata/cases.json.
        categories: If provided, only run cases in these categories.

    Returns:
        BenchmarkResults with per-case and aggregate metrics.
    """
    cases = load_cases(cases_file)

    if categories:
        cases = [c for c in cases if c["category"] in categories]

    results = BenchmarkResults()
    start = time.monotonic()

    for case in cases:
        result = _evaluate_case(case)
        results.cases.append(result)
        results.total += 1

        # Aggregate
        if result.outcome == "correct":
            results.correct += 1
        elif result.outcome == "missed":
            results.missed += 1
        elif result.outcome == "false_positive":
            results.false_positive += 1
        elif result.outcome == "error":
            results.errors += 1

        # By category
        cat = result.category
        if cat not in results.by_category:
            results.by_category[cat] = {"total": 0, "correct": 0, "missed": 0, "false_positive": 0, "errors": 0}
        results.by_category[cat]["total"] += 1
        results.by_category[cat][result.outcome] = results.by_category[cat].get(result.outcome, 0) + 1

    results.elapsed_ms = (time.monotonic() - start) * 1000
    return results
