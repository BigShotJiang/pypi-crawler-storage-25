from unittest.mock import MagicMock

from project_hub.core.cache import Cache
from project_hub.core.config import Config
from project_hub.core.models import MR, RepoRecord
from project_hub.core.workspace import Workspace
from project_hub.mcp.server import AppContext, list_mrs, repo_status


# --- Model-level tests ---


def test_is_ready_annotated():
    r = RepoRecord(name="a", path="/tmp/a", remote_url="", forge_host=None,
                   forge_type=None, project_path=None, role="API")
    assert r.is_ready() is True


def test_is_ready_unannotated():
    r = RepoRecord(name="a", path="/tmp/a", remote_url="", forge_host=None,
                   forge_type=None, project_path=None)
    assert r.is_ready() is False


def test_is_ready_exempted():
    r = RepoRecord(name="a", path="/tmp/a", remote_url="", forge_host=None,
                   forge_type=None, project_path=None)
    assert r.is_ready(annotation_not_required=["a"]) is True


# --- Integration-level gating tests ---


def _make_repo(name):
    from project_hub.core.models import Repo
    return Repo(name=name, path=f"/tmp/{name}", remote_url="", forge_host="gitlab.com",
                forge_type="gitlab", has_forge=True, project_path=f"group/{name}")


def _make_ctx(app):
    ctx = MagicMock()
    ctx.request_context = MagicMock()
    ctx.request_context.lifespan_context = app
    return ctx


async def test_repo_status_blocks_unannotated(tmp_path):
    """repo_status on a single unannotated repo should return an error."""
    cache = Cache(tmp_path / "cache.db")
    await cache.initialize()
    await cache.store_repos([RepoRecord(
        name="my-repo", path="/tmp/my-repo", remote_url="",
        forge_host="gitlab.com", forge_type="gitlab", project_path="group/my-repo",
    )])

    ws = MagicMock(spec=Workspace)
    ws.cache = cache
    ws.config = Config()  # no exemptions
    ws.repos = [_make_repo("my-repo")]
    ws._git_statuses = {}
    ws._default_divergence = {}

    import project_hub.mcp.server as srv
    srv._app_context = AppContext(workspace=ws)
    ctx = _make_ctx(AppContext(workspace=ws))

    result = await repo_status(ctx, repo="my-repo")
    assert "no annotations" in result.lower()
    assert "annotate_repo" in result.lower()

    await cache.close()


async def test_list_mrs_filters_unannotated_in_batch(tmp_path):
    """list_mrs without repo arg should skip unannotated repos and warn."""
    cache = Cache(tmp_path / "cache.db")
    await cache.initialize()

    # One annotated, one not
    await cache.store_repos([
        RepoRecord(name="annotated-repo", path="/tmp/a", remote_url="",
                   forge_host="gitlab.com", forge_type="gitlab",
                   project_path="group/annotated-repo", role="API"),
        RepoRecord(name="bare-repo", path="/tmp/b", remote_url="",
                   forge_host="gitlab.com", forge_type="gitlab",
                   project_path="group/bare-repo"),
    ])
    mr = MR(id=100, iid=1, title="Test MR", author="alice", state="opened",
            source_branch="feat", target_branch="main",
            web_url="https://gitlab.com/mr/1", user_notes_count=0, approved=False,
            created_at="2024-01-01T00:00:00Z", updated_at="2024-01-02T00:00:00Z",
            repo_name="bare-repo", sha="abc")
    await cache.store_mrs("bare-repo", [mr])

    ws = MagicMock(spec=Workspace)
    ws.cache = cache
    ws.config = Config()  # no exemptions
    ws.repos = [_make_repo("annotated-repo"), _make_repo("bare-repo")]

    import project_hub.mcp.server as srv
    srv._app_context = AppContext(workspace=ws)
    ctx = _make_ctx(AppContext(workspace=ws))

    result = await list_mrs(ctx)
    # MR from bare-repo should be filtered out
    assert "bare-repo" not in result.split("---")[0]
    # Warning should mention the skipped repo
    assert "bare-repo" in result
    assert "skipped" in result.lower()

    await cache.close()
