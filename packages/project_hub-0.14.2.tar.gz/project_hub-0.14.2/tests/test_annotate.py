import pytest
from project_hub.core.cache import Cache
from project_hub.core.models import RepoRecord


@pytest.fixture
async def cache(tmp_path):
    c = Cache(tmp_path / "test.db")
    await c.initialize()
    yield c
    await c.close()


async def test_annotate_sets_fields(cache):
    repo = RepoRecord(
        name="my-repo", path="/tmp/r", remote_url="",
        forge_host=None, forge_type=None, project_path=None,
    )
    await cache.store_repos([repo])
    ok = await cache.annotate_repo("my-repo", role="Main API", domain="backend")
    assert ok is True
    result = (await cache.get_repos(["my-repo"]))[0]
    assert result.role == "Main API"
    assert result.domain == "backend"


async def test_annotate_partial_update(cache):
    repo = RepoRecord(
        name="my-repo", path="/tmp/r", remote_url="",
        forge_host=None, forge_type=None, project_path=None,
    )
    await cache.store_repos([repo])
    await cache.annotate_repo("my-repo", role="API", domain="svc")
    await cache.annotate_repo("my-repo", role="Updated API")
    result = (await cache.get_repos(["my-repo"]))[0]
    assert result.role == "Updated API"
    assert result.domain == "svc"  # preserved
