from project_hub.core.models import RepoRecord


def _build(discovered_names, repo_records):
    from project_hub.mcp.server import _build_instructions_from_db
    return _build_instructions_from_db(discovered_names, repo_records)


def test_groups_repos_by_project_path():
    records = [
        RepoRecord(
            name="web-api", path="/tmp/a", remote_url="",
            forge_host="gitlab.com", forge_type="gitlab",
            project_path="acme/platform/services/web-api",
            description="REST API server", role="Main API", domain="services",
        ),
        RepoRecord(
            name="deploy-charts", path="/tmp/b", remote_url="",
            forge_host="gitlab.com", forge_type="gitlab",
            project_path="acme/platform/infrastructure/deploy-charts",
            description="Helm charts", role="Central helmfile",
        ),
    ]
    text = _build({"web-api", "deploy-charts"}, records)
    assert "web-api" in text
    assert "deploy-charts" in text
    # Dense format: group names present, repo names listed
    assert "services/" in text
    assert "infrastructure/" in text
    # Descriptions NOT in instructions (available via list_repos)
    assert "Main API" not in text
    assert "REST API server" not in text
    assert "list_repos" in text  # points to tool for full details


def test_dense_format_lists_all_repos():
    """Dense format includes all discovered repos regardless of annotation status."""
    records = [
        RepoRecord(
            name="repo-a", path="/tmp/a", remote_url="",
            forge_host=None, forge_type=None, project_path=None,
            description="Some repo",
        ),
        RepoRecord(
            name="repo-b", path="/tmp/b", remote_url="",
            forge_host=None, forge_type=None, project_path=None,
            description="Another", role="Important one",
        ),
    ]
    text = _build({"repo-a", "repo-b"}, records)
    assert "repo-a" in text
    assert "repo-b" in text
    # Unannotated repo flagged in compact hint
    assert "unannotated" in text.lower()
    assert "repo-a" in text  # repo-a has no role/domain


def test_warns_when_over_budget(monkeypatch, caplog):
    """When dense instructions exceed budget, a warning is logged."""
    import project_hub.mcp.server as srv
    monkeypatch.setattr(srv, "INSTRUCTIONS_BUDGET", 200)  # tiny budget

    records = [
        RepoRecord(
            name="svc-alpha", path="/tmp/a", remote_url="",
            forge_host=None, forge_type=None,
            project_path="acme/services/svc-alpha",
            role="A long role description that takes up space",
        ),
        RepoRecord(
            name="svc-beta", path="/tmp/b", remote_url="",
            forge_host=None, forge_type=None,
            project_path="acme/services/svc-beta",
            role="Another verbose role description here",
        ),
    ]
    import logging
    with caplog.at_level(logging.WARNING):
        text = _build({"svc-alpha", "svc-beta"}, records)
    # Both repos still present (no content dropped)
    assert "svc-alpha" in text
    assert "svc-beta" in text
    # Warning logged
    assert "exceed" in caplog.text.lower()


def test_undiscovered_repos_excluded():
    records = [
        RepoRecord(name="active-repo", path="/tmp/a", remote_url="",
                    forge_host=None, forge_type=None, project_path=None),
        RepoRecord(name="removed-repo", path="/tmp/b", remote_url="",
                    forge_host=None, forge_type=None, project_path=None),
    ]
    text = _build({"active-repo"}, records)
    assert "active-repo" in text
    assert "removed-repo" not in text
