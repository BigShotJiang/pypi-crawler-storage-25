import pytest

from project_hub.core.cache import Cache
from project_hub.core.models import RepoRecord


def make_repo(name: str, **kwargs) -> RepoRecord:
    defaults = dict(
        path=f"/workspace/{name}",
        remote_url=f"git@gitlab.com:group/{name}.git",
        forge_host="gitlab.com",
        forge_type="gitlab",
        project_path=f"group/{name}",
        default_branch="main",
    )
    defaults.update(kwargs)
    return RepoRecord(name=name, **defaults)


@pytest.fixture
async def cache(tmp_path):
    c = Cache(tmp_path / "test.db")
    await c.initialize()
    yield c
    await c.close()


async def test_store_and_get_repos(cache: Cache):
    repos = [
        make_repo("alpha", description="Alpha service", topics=["python", "api"]),
        make_repo("beta", description="Beta worker", topics=["worker"]),
    ]
    await cache.store_repos(repos)

    result = await cache.get_repos()
    assert len(result) == 2
    names = {r.name for r in result}
    assert names == {"alpha", "beta"}

    alpha = next(r for r in result if r.name == "alpha")
    assert alpha.path == "/workspace/alpha"
    assert alpha.remote_url == "git@gitlab.com:group/alpha.git"
    assert alpha.forge_host == "gitlab.com"
    assert alpha.forge_type == "gitlab"
    assert alpha.project_path == "group/alpha"
    assert alpha.default_branch == "main"
    assert alpha.description == "Alpha service"
    assert alpha.topics == ["python", "api"]
    assert alpha.role is None
    assert alpha.domain is None
    assert alpha.links == []
    assert alpha.notes is None


async def test_annotations_preserved_on_upsert(cache: Cache):
    repo = make_repo("gamma", description="Original description", topics=["go"])
    await cache.store_repos([repo])

    annotated = await cache.annotate_repo("gamma", role="service", domain="billing", notes="key repo")
    assert annotated is True

    # Re-upsert with new auto-filled data (simulates a refresh cycle)
    updated = make_repo("gamma", description="Updated description", topics=["go", "grpc"])
    await cache.store_repos([updated])

    result = await cache.get_repos(["gamma"])
    assert len(result) == 1
    r = result[0]
    # Auto-filled fields updated
    assert r.description == "Updated description"
    assert r.topics == ["go", "grpc"]
    # Manual annotations preserved
    assert r.role == "service"
    assert r.domain == "billing"
    assert r.notes == "key repo"


async def test_empty_description_preserves_cached(cache: Cache):
    """Empty string description from forge should not overwrite existing cached description."""
    repo = make_repo("epsilon", description="Real description", topics=["python"])
    await cache.store_repos([repo])

    # Simulate a refresh where forge returns empty description (project.description or "")
    updated = make_repo("epsilon", description="", topics=[])
    await cache.store_repos([updated])

    result = await cache.get_repos(["epsilon"])
    assert len(result) == 1
    assert result[0].description == "Real description"
    assert result[0].topics == ["python"]


async def test_none_description_preserves_cached(cache: Cache):
    """None description (from _sync_repos_to_db path) should not overwrite existing."""
    repo = make_repo("zeta", description="Cached desc")
    await cache.store_repos([repo])

    # Simulate _sync_repos_to_db which creates RepoRecord without description
    updated = make_repo("zeta", description=None)
    await cache.store_repos([updated])

    result = await cache.get_repos(["zeta"])
    assert len(result) == 1
    assert result[0].description == "Cached desc"


async def test_annotate_nonexistent_repo(cache: Cache):
    result = await cache.annotate_repo("does-not-exist", role="service")
    assert result is False


async def test_get_repos_empty_list(cache: Cache):
    await cache.store_repos([make_repo("delta")])
    result = await cache.get_repos([])
    assert result == []


async def test_repos_survive_maintenance(cache: Cache):
    """Repos not in active set should survive maintenance (annotations preserved)."""
    repo = RepoRecord(
        name="old-repo", path="/tmp/old", remote_url="",
        forge_host=None, forge_type=None, project_path=None,
    )
    await cache.store_repos([repo])
    await cache.annotate_repo("old-repo", role="Legacy service")

    # Run maintenance with a different active set
    await cache.run_maintenance(active_repos={"new-repo"})

    # old-repo should still be in the repos table
    result = await cache.get_repos(["old-repo"])
    assert len(result) == 1
    assert result[0].role == "Legacy service"
