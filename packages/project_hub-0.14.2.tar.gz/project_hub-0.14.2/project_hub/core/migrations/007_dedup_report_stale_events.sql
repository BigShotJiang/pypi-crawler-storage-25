-- Remove duplicate report_stale_too_long events (same vuln name + repo),
-- keeping only the oldest per (detail, repo_name) pair.
DELETE FROM events WHERE type = 'report_stale_too_long'
  AND id NOT IN (
    SELECT MIN(id) FROM events
    WHERE type = 'report_stale_too_long'
    GROUP BY detail, repo_name
  );
