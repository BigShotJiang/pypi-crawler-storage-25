ALTER TABLE vulnerabilities ADD COLUMN created_at TEXT;
