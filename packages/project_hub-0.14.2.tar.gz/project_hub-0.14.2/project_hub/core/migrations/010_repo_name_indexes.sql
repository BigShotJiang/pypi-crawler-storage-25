CREATE INDEX IF NOT EXISTS idx_mr_repo ON merge_requests(repo_name);
CREATE INDEX IF NOT EXISTS idx_pipeline_repo ON pipelines(repo_name);
CREATE INDEX IF NOT EXISTS idx_vuln_repo ON vulnerabilities(repo_name);
CREATE INDEX IF NOT EXISTS idx_issue_repo ON issues(repo_name);
CREATE INDEX IF NOT EXISTS idx_pull_status_repo ON pull_status(repo_name);
