-- Create repos table to store both auto-filled forge metadata and manual user annotations.
-- Auto-filled fields (description, topics) are populated from the forge API during refresh.
-- Manual annotation fields (role, domain, links, notes) are never overwritten by refresh.

CREATE TABLE IF NOT EXISTS repos (
    name            TEXT PRIMARY KEY,
    path            TEXT NOT NULL,
    remote_url      TEXT NOT NULL DEFAULT '',
    forge_host      TEXT,
    forge_type      TEXT,
    project_path    TEXT,
    default_branch  TEXT,
    -- Auto-filled from forge API
    description     TEXT,
    topics          TEXT,  -- JSON array
    -- Manual annotations (never overwritten by refresh)
    role            TEXT,
    domain          TEXT,
    links           TEXT,  -- JSON array of repo names
    notes           TEXT
);
