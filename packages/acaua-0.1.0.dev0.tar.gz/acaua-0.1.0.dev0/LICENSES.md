# Weight Licenses

acaua's pitch is license hygiene: every weight in the default load path has an auditable, declared Apache-2.0 upstream, pinned to a specific commit SHA on a mirror under `CondadosAI/*`. Non-Apache weights raise `LicenseError` unless you opt in with `allow_non_apache=True`.

This document is the human-readable surface of the audit. The machine-readable source of truth is `src/acaua/_data/licenses.py`, which is what `Model.from_pretrained()` actually consults.

## Policy

- **Default path is Apache-clean.** acaua never auto-downloads weights whose upstream declaration is anything other than Apache-2.0.
- **No fresh license claims.** We redistribute only what an upstream author already stamped Apache-2.0 in writing. We never upgrade a license on our own.
- **Every mirror pins a commit SHA.** Upstream can force-push, rotate weights, or re-license — our manifest is frozen on a specific byte-identical artifact, so the audit claim stays verifiable forever.
- **NOTICE files satisfy Apache-2.0 §4(d).** Every `CondadosAI/<model>` mirror carries a `NOTICE` file naming every upstream contributor in the chain.

## Shipped in v0.1

| acaua repo | Task | Upstream | Upstream SHA | Mirror SHA | License |
|---|---|---|---|---|---|
| [`CondadosAI/rtdetr_r50vd`](https://huggingface.co/CondadosAI/rtdetr_r50vd) | object detection | [`PekingU/rtdetr_r50vd_coco_o365`](https://huggingface.co/PekingU/rtdetr_r50vd_coco_o365) | `457857ce…21af8` | `cdafce18…2ba4c` | Apache-2.0 |
| [`CondadosAI/mask2former_swin_tiny_coco_instance`](https://huggingface.co/CondadosAI/mask2former_swin_tiny_coco_instance) | instance segmentation | [`facebook/mask2former-swin-tiny-coco-instance`](https://huggingface.co/facebook/mask2former-swin-tiny-coco-instance) | `22c4a2f1…6f6` | `fb63ea7f…8f3ab9` | Apache-2.0 |
| [`CondadosAI/acaua-task-test`](https://huggingface.co/CondadosAI/acaua-task-test) | test fixture (no weights) | synthetic | n/a | `6efce47d…3fda9` | Apache-2.0 |

Collection: [`CondadosAI/acaua-v0.1-weights`](https://huggingface.co/collections/CondadosAI/acaua-v01-weights-69e2a34a98b9dc35687d4352)

## Attribution chains

### RT-DETR (object detection)

Mirrored from [`PekingU/rtdetr_r50vd_coco_o365`](https://huggingface.co/PekingU/rtdetr_r50vd_coco_o365) at commit `457857cec8ac28ddede40ecee9eed2beca321af8` (2024-07-01).

- **Paper:** Zhao et al., *"DETRs Beat YOLOs on Real-time Object Detection"*, arXiv:[2304.08069](https://arxiv.org/abs/2304.08069), 2023.
- **Upstream code:** [`lyuwenyu/RT-DETR`](https://github.com/lyuwenyu/RT-DETR) — Apache-2.0.
- **Backbone pretraining:** ResNet-50-vd on ImageNet-1k, via [PaddleClas](https://github.com/PaddlePaddle/PaddleClas) — Apache-2.0.
- **Transformers port:** HF conversion by Sangbum Choi and Pavel Iakubovskii.

### Mask2Former Swin-Tiny (instance segmentation)

Mirrored from [`facebook/mask2former-swin-tiny-coco-instance`](https://huggingface.co/facebook/mask2former-swin-tiny-coco-instance) at commit `22c4a2f15dc88149b8b8d9f4d42c54431fbd66f6` (2023-09-11).

- **Paper:** Cheng et al., *"Masked-attention Mask Transformer for Universal Image Segmentation"*, CVPR 2022, arXiv:[2112.01527](https://arxiv.org/abs/2112.01527).
- **Reference implementation:** [`facebookresearch/Mask2Former`](https://github.com/facebookresearch/Mask2Former) — MIT. (The weights as redistributed by `facebook/*` on Hugging Face are declared Apache-2.0 in the upstream model card YAML.)
- **Backbone:** Swin-Tiny (Liu et al., *"Swin Transformer"*, ICCV 2021, arXiv:[2103.14030](https://arxiv.org/abs/2103.14030)).
- **One deliberate deviation from upstream:** the legacy `pytorch_model.bin` pickle file that facebook ships alongside `model.safetensors` has been removed from our mirror for security hygiene (pickle loads can execute arbitrary code). `transformers` auto-prefers safetensors when both exist, so this has zero functional impact on downstream users.

## Caveats acaua is honest about

- **ImageNet-1k pretraining** for the RT-DETR R50-vd backbone and the Swin-Tiny backbone inherits whatever ambiguity exists in the ImageNet access terms. acaua's posture: we rely on the upstream publisher's explicit Apache-2.0 declaration, we do not make a fresh claim. The full reasoning lives in the v0.1 audit doc.
- **Torchvision's Mask R-CNN was considered and rejected for v0.1** because torchvision explicitly refuses to declare a license on its pretrained weights. Mirroring those under Apache-2.0 would have been an unverifiable fresh claim. This is why v0.1 segmentation uses Mask2Former instead.
- **Apache-2.0 on a HF model card is the uploader's claim, not a contract with users.** For normal open-source use, practical interpretation is strong enough. For commercial use where legal certainty matters more than conventional practice, have your own counsel review these upstream declarations before shipping.

## If you need a non-Apache weight

```python
model = acaua.Model.from_pretrained(
    "some/non-apache-repo", allow_non_apache=True
)
```

This disables the `LicenseError` raise. You accept responsibility for whatever the upstream license allows.

## Acknowledgements

None of this ships without the upstream contributors doing the actual science and the actual framework work. acaua is a thin coat of paint over:

- **PyTorch team** (BSD-3) — foundation of everything.
- **Hugging Face** — Transformers, HF Hub, the whole ecosystem that makes `.from_pretrained()` feel like magic.
- **torchvision team** — detection and segmentation scaffolding that future acaua adapters will build on.
- **Roboflow Supervision** — the annotation and post-processing layer acaua's `Result.to_supervision()` slots into.
- **The paper authors named above** — RT-DETR, Mask2Former, Swin, and the backbone pretraining pipelines they depend on.
