"""License manifest for every weight source acaua knows about.

Shipped as static Python data inside the wheel. Read at
`Model.from_pretrained()` time BEFORE any network call, so non-Apache weights
never touch the user's disk on a default load.

The authoritative source of truth for these entries is the audit doc at
`~/.gstack/projects/acaua/lcondados-master-r50-license-audit-20260417.md`.
When updating this file, update the audit doc registry in lockstep.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class LicenseEntry:
    """One weight-source entry.

    Attributes:
        license: SPDX identifier (e.g. "apache-2.0"). Anything other than
            "apache-2.0" triggers `LicenseError` unless the caller passes
            `allow_non_apache=True`.
        loader: how acaua loads the weights. v0.1 only supports "hf_mirror"
            (pointing at a repo under `CondadosAI/*` whose license was audited
            before upload). Reserved for v0.2: "torchvision_runtime" for
            models where the upstream refuses to declare a weights license.
        upstream_src: upstream repo_id the mirror was derived from.
        upstream_sha: upstream commit SHA at the time of mirror. Audit-anchor.
        acaua_sha: commit SHA on the mirror repo. This is what `hf_hub_download`
            is called with as `revision=`, so users always get identical bytes.
    """

    license: str
    loader: str
    upstream_src: str
    upstream_sha: str
    acaua_sha: str


LICENSES: dict[str, LicenseEntry] = {
    "CondadosAI/rtdetr_r50vd": LicenseEntry(
        license="apache-2.0",
        loader="hf_mirror",
        upstream_src="PekingU/rtdetr_r50vd_coco_o365",
        upstream_sha="457857cec8ac28ddede40ecee9eed2beca321af8",
        acaua_sha="cdafce18c8cbf601aaf058cc60db8c873362ba4c",
    ),
    "CondadosAI/mask2former_swin_tiny_coco_instance": LicenseEntry(
        license="apache-2.0",
        loader="hf_mirror",
        upstream_src="facebook/mask2former-swin-tiny-coco-instance",
        upstream_sha="22c4a2f15dc88149b8b8d9f4d42c54431fbd66f6",
        acaua_sha="fb63ea7ff77ec1811237f60d733f8e60968f3ab9",
    ),
    "CondadosAI/acaua-task-test": LicenseEntry(
        license="apache-2.0",
        loader="hf_mirror",
        upstream_src="(synthetic test fixture)",
        upstream_sha="n/a",
        acaua_sha="6efce47d5e915182ad5944c87c9288f0acd7fda9",
    ),
}
