"""Task -> adapter class registry.

Keyed by task string (the value returned by `Model._resolve_task`). Each
entry is a `(module_path, class_name)` pair that `importlib.import_module`
can resolve lazily at `from_pretrained` time. Keeping the registry
declarative (a dict in a small data module, not a decorator-based registry
class) is deliberate — no mmcv/mmengine-style magic.

Extras (`acaua[ocr]`, `acaua[vlm]`, `acaua[zeroshot]`) extend this map by
shipping new adapter modules that this dict points at. If the extra isn't
installed, `importlib.import_module` raises `ImportError` with a message
that includes the missing extra name.
"""

from __future__ import annotations

ADAPTERS: dict[str, tuple[str, str]] = {
    "detection": ("acaua.adapters.rtdetr", "RTDETRAdapter"),
    "segmentation": ("acaua.adapters.mask2former", "Mask2FormerAdapter"),
}
