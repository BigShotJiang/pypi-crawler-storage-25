"""Fallback `repo_id -> task` map used when a repo's `config.json` does not
carry an `acaua_task` field.

Primary routing path: `Model.from_pretrained()` downloads the repo's
`config.json` (tiny file) at the pinned revision and looks for an
`acaua_task` field. If present, that wins.

This dict is only consulted when the field is missing — which is the case
for all upstream-provenanced mirrors in v0.1 (upstreams don't know about
acaua). When we add self-authored models later, they will ship
`acaua_task` in their config and bypass this dict.

Leave entries here in lockstep with `LICENSES` in `licenses.py`. The fixture
repo `CondadosAI/acaua-task-test` is intentionally absent so the integration
test can prove the metadata-read path fires on that repo.
"""

from __future__ import annotations

TASK_FALLBACK: dict[str, str] = {
    "CondadosAI/rtdetr_r50vd": "detection",
    "CondadosAI/mask2former_swin_tiny_coco_instance": "segmentation",
}
