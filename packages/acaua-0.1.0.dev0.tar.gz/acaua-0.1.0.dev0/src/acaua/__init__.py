"""acaua — Apache-2.0 PyTorch-native computer vision library.

    import acaua
    model = acaua.Model.from_pretrained("CondadosAI/rtdetr_r50vd")
    results = model.predict("image.jpg")

One API across detection, segmentation, OBB, OCR, VLM, zero-shot —
predict / train / export, applied uniformly. v0.1 ships detection
(RT-DETR) and instance segmentation (Mask2Former-Swin-Tiny) at
`.predict()` parity; later versions extend the other verbs and tasks.

License-clean by design: every weight in the default path is an
Apache-2.0-declared upstream mirrored under `CondadosAI/*` at a pinned
commit SHA. Non-Apache weights raise `LicenseError` unless you pass
`allow_non_apache=True`.
"""

from __future__ import annotations

from acaua.exceptions import (
    AcauaError,
    InputFormatError,
    LicenseError,
    TaskResolutionError,
    WeightDownloadError,
)
from acaua.model import Model
from acaua.results import DetectionResult, Result, SegmentationResult

__version__ = "0.1.0.dev0"

__all__ = [
    "AcauaError",
    "DetectionResult",
    "InputFormatError",
    "LicenseError",
    "Model",
    "Result",
    "SegmentationResult",
    "TaskResolutionError",
    "WeightDownloadError",
    "__version__",
]
