"""Exception hierarchy for acaua.

All library-raised exceptions inherit from `AcauaError`. Users who want a
catch-all can do `except AcauaError`; users who want to handle specific
failure modes (license block, missing weights, bad input) import the
specific subclass.
"""

from __future__ import annotations


class AcauaError(Exception):
    """Base class for all acaua-raised exceptions."""


class LicenseError(AcauaError):
    """Raised when loading non-Apache-2.0 weights without explicit opt-in.

    acaua's default posture is Apache-clean: any repo whose license is not
    `apache-2.0` in the manifest raises this on `Model.from_pretrained(...)`.
    Users who knowingly want non-Apache weights pass `allow_non_apache=True`.
    """


class TaskResolutionError(AcauaError):
    """Raised when a repo's task cannot be resolved.

    Two ways this fires:
    1. The repo_id is not in acaua's license manifest (`_data/licenses.py`).
    2. The repo's `config.json` has no `acaua_task` field AND the repo_id
       is not in the fallback dict (`_data/task_fallback.py`).
    """


class WeightDownloadError(AcauaError):
    """Raised when a Hugging Face download fails.

    Wraps network errors, HTTP 4xx/5xx, auth failures, or corrupt responses.
    The original `huggingface_hub` exception is attached as `__cause__`.
    """


class InputFormatError(AcauaError):
    """Raised when a `.predict()` input has unsupported type, shape, or dtype.

    Also raised by the BGR-smell heuristic in `io.load_images` when a numpy
    `ndarray` looks like OpenCV-style BGR instead of the required RGB.
    """
