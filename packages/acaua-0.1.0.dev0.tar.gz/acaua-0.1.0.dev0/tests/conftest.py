"""Shared pytest fixtures.

Keep this thin. A fixture lives here only if two or more test files use it.
Single-consumer fixtures belong in the consuming test file.
"""

from __future__ import annotations

import numpy as np
import pytest
import torch
from PIL import Image


@pytest.fixture
def rgb_pil() -> Image.Image:
    """Small solid-color RGB PIL image, genuinely RGB (does not trip BGR heuristic)."""
    return Image.fromarray(np.full((64, 64, 3), 100, dtype=np.uint8), mode="RGB")


@pytest.fixture
def rgb_ndarray() -> np.ndarray:
    """Small solid-color HWC uint8 RGB ndarray."""
    return np.full((64, 64, 3), 100, dtype=np.uint8)


@pytest.fixture
def bgr_smelling_ndarray() -> np.ndarray:
    """HWC uint8 ndarray whose channel stats look BGR (ch0 mean > ch2 mean + 10)."""
    arr = np.zeros((32, 32, 3), dtype=np.uint8)
    arr[..., 0] = 200  # "blue" slot in BGR convention → high
    arr[..., 2] = 50  # "red" slot in BGR convention → low
    return arr


@pytest.fixture
def rgb_tensor() -> torch.Tensor:
    """Small CHW float32 tensor in [0, 1]."""
    return torch.full((3, 64, 64), 0.4, dtype=torch.float32)
