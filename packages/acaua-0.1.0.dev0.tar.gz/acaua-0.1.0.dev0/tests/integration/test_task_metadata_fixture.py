"""Integration test for the `acaua_task` metadata-reading path.

Downloads only the fixture repo's `config.json` (tiny — a few hundred bytes)
and asserts the metadata routing picks up the `acaua_task` field. Proves
that the metadata path is wired up, independent of any adapter work.

The fixture repo `CondadosAI/acaua-task-test` is intentionally absent from
`TASK_FALLBACK`, so a successful resolve to `"detection"` can only come from
the metadata read — not from the dict fallback.
"""

from __future__ import annotations

import pytest

from acaua._data.licenses import LICENSES
from acaua._data.task_fallback import TASK_FALLBACK
from acaua.model import _resolve_task


@pytest.mark.e2e
def test_fixture_config_has_metadata_field() -> None:
    entry = LICENSES["CondadosAI/acaua-task-test"]
    assert "CondadosAI/acaua-task-test" not in TASK_FALLBACK, (
        "fixture must NOT be in TASK_FALLBACK — the whole point is proving "
        "the metadata-read path works without a fallback safety net"
    )
    task = _resolve_task("CondadosAI/acaua-task-test", revision=entry.acaua_sha)
    assert task == "detection"
