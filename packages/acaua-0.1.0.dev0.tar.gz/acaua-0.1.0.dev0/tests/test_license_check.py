"""License-enforcement path of `Model.from_pretrained`.

Tests the `_lookup` + `_enforce_license` helpers directly (unit-level, no
network) plus the full dispatch behavior on unknown repo ids and non-Apache
entries. Real-weight download testing lives in `tests/integration/`.
"""

from __future__ import annotations

import pytest

from acaua import LicenseError, Model, TaskResolutionError
from acaua._data.licenses import LICENSES, LicenseEntry
from acaua.model import _enforce_license, _lookup


def _non_apache_entry() -> LicenseEntry:
    return LicenseEntry(
        license="cc-by-nc-4.0",
        loader="hf_mirror",
        upstream_src="fake/upstream",
        upstream_sha="deadbeef",
        acaua_sha="cafef00d",
    )


class TestLookup:
    def test_known_repo_returns_entry(self) -> None:
        entry = _lookup("CondadosAI/rtdetr_r50vd")
        assert entry.license == "apache-2.0"
        assert entry.loader == "hf_mirror"

    def test_unknown_repo_raises_task_resolution(self) -> None:
        with pytest.raises(TaskResolutionError, match="not in acaua's model manifest"):
            _lookup("nobody/not-a-real-repo")


class TestEnforceLicense:
    def test_apache_passes(self) -> None:
        entry = LICENSES["CondadosAI/rtdetr_r50vd"]
        _enforce_license("CondadosAI/rtdetr_r50vd", entry, allow_non_apache=False)

    def test_non_apache_blocked_by_default(self) -> None:
        entry = _non_apache_entry()
        with pytest.raises(LicenseError, match=r"cc-by-nc-4\.0"):
            _enforce_license("fake/repo", entry, allow_non_apache=False)

    def test_non_apache_allowed_with_override(self) -> None:
        entry = _non_apache_entry()
        _enforce_license("fake/repo", entry, allow_non_apache=True)

    def test_error_message_names_upstream(self) -> None:
        entry = _non_apache_entry()
        with pytest.raises(LicenseError, match="fake/upstream"):
            _enforce_license("fake/repo", entry, allow_non_apache=False)

    def test_error_message_suggests_override(self) -> None:
        entry = _non_apache_entry()
        with pytest.raises(LicenseError, match="allow_non_apache=True"):
            _enforce_license("fake/repo", entry, allow_non_apache=False)


class TestFromPretrainedLicensePaths:
    def test_unknown_repo_raises_before_network(self) -> None:
        with pytest.raises(TaskResolutionError, match="not in acaua's model manifest"):
            Model.from_pretrained("nobody/not-a-real-repo")

    def test_non_apache_entry_blocks_without_network(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """Injecting a non-Apache entry must raise `LicenseError` before any
        network call is made. Proves the license check is truly pre-download."""
        fake_entry = _non_apache_entry()
        monkeypatch.setitem(LICENSES, "fake/non-apache", fake_entry)
        # No HF mocking needed — the LicenseError must fire before any
        # hf_hub_download call. If the implementation leaks network access
        # before the license check, this test will either hang or error out
        # differently.
        with pytest.raises(LicenseError, match=r"cc-by-nc-4\.0"):
            Model.from_pretrained("fake/non-apache")
