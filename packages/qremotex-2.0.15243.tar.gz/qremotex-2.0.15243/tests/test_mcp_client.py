"""Tests for qremotex.tools.mcp_client — MCP JSON-RPC 2.0 client."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from qremotex.tools.mcp_client import McpClient, build_auth_headers


# ──────────────────────────────────────────────── Auth Headers ──


class TestBuildAuthHeaders:
    def test_none_returns_empty(self) -> None:
        assert build_auth_headers("NONE", {}) == {}

    def test_empty_string_returns_empty(self) -> None:
        assert build_auth_headers("", {}) == {}

    def test_none_type_returns_empty(self) -> None:
        assert build_auth_headers(None, {}) == {}  # type: ignore[arg-type]

    def test_api_key(self) -> None:
        headers = build_auth_headers("API_KEY", {
            "api_key_name": "X-My-Key",
            "api_key_value": "secret123",
        })
        assert headers == {"X-My-Key": "secret123"}

    def test_api_key_default_header_name(self) -> None:
        headers = build_auth_headers("API_KEY", {"api_key_value": "abc"})
        assert headers == {"X-API-Key": "abc"}

    def test_api_key_fallback_field_names(self) -> None:
        headers = build_auth_headers("API_KEY", {
            "api_key_header_name": "Authorization",
            "api_key": "xyz",
        })
        assert headers == {"Authorization": "xyz"}

    def test_api_key_no_value_returns_empty(self) -> None:
        headers = build_auth_headers("API_KEY", {"api_key_name": "X-Key"})
        assert headers == {}

    def test_bearer_token(self) -> None:
        headers = build_auth_headers("BEARER_TOKEN", {"bearer_token": "tok123"})
        assert headers == {"Authorization": "Bearer tok123"}

    def test_bearer_token_fallback(self) -> None:
        headers = build_auth_headers("BEARER_TOKEN", {"token": "tok456"})
        assert headers == {"Authorization": "Bearer tok456"}

    def test_bearer_token_no_value_returns_empty(self) -> None:
        headers = build_auth_headers("BEARER_TOKEN", {})
        assert headers == {}

    def test_custom_headers_dict(self) -> None:
        headers = build_auth_headers("CUSTOM_HEADERS", {
            "custom_headers": {"X-Foo": "bar", "X-Baz": "qux"},
        })
        assert headers == {"X-Foo": "bar", "X-Baz": "qux"}

    def test_custom_headers_json_string(self) -> None:
        headers = build_auth_headers("CUSTOM_HEADERS", {
            "custom_headers": json.dumps({"X-Foo": "bar"}),
        })
        assert headers == {"X-Foo": "bar"}

    def test_custom_headers_invalid_json_returns_empty(self) -> None:
        headers = build_auth_headers("CUSTOM_HEADERS", {
            "custom_headers": "not-json",
        })
        assert headers == {}

    def test_custom_headers_empty_returns_empty(self) -> None:
        headers = build_auth_headers("CUSTOM_HEADERS", {})
        assert headers == {}

    def test_case_insensitive_auth_type(self) -> None:
        headers = build_auth_headers("bearer_token", {"bearer_token": "tok"})
        assert headers == {"Authorization": "Bearer tok"}


# ──────────────────────────────────────────────── SSRF Check ──


class TestMcpClientSsrf:
    @pytest.mark.asyncio
    async def test_call_tool_blocks_loopback(self) -> None:
        client = McpClient()
        result = await client.call_tool(
            server_url="http://127.0.0.1:8080/mcp",
            tool_name="test",
            arguments={},
            auth_headers={},
            timeout=5,
        )
        assert result["success"] is False
        assert "SSRF" in result["error"]

    @pytest.mark.asyncio
    async def test_list_tools_blocks_metadata(self) -> None:
        client = McpClient()
        result = await client.list_tools(
            server_url="http://169.254.169.254/latest/meta-data",
            auth_headers={},
            timeout=5,
        )
        assert result["success"] is False
        assert "SSRF" in result["error"]

    @pytest.mark.asyncio
    async def test_call_tool_blocks_alibaba_metadata(self) -> None:
        client = McpClient()
        result = await client.call_tool(
            server_url="http://100.100.100.200/meta-data",
            tool_name="test",
            arguments={},
            auth_headers={},
            timeout=5,
        )
        assert result["success"] is False
        assert "SSRF" in result["error"]


# ──────────────────────────────────────────────── JSON-RPC Parsing ──


class TestParseJsonrpcResult:
    def setup_method(self) -> None:
        self.client = McpClient()

    def test_call_tool_success(self) -> None:
        response = {
            "jsonrpc": "2.0",
            "result": {
                "content": [{"type": "text", "text": "Hello"}],
            },
            "id": 1,
        }
        result = self.client._parse_jsonrpc_result(response, "call_tool")
        assert result["success"] is True
        assert result["content"] == [{"type": "text", "text": "Hello"}]

    def test_call_tool_is_error(self) -> None:
        response = {
            "jsonrpc": "2.0",
            "result": {
                "content": [{"type": "text", "text": "Something went wrong"}],
                "isError": True,
            },
            "id": 1,
        }
        result = self.client._parse_jsonrpc_result(response, "call_tool")
        assert result["success"] is False
        assert "Something went wrong" in result["error"]

    def test_list_tools_success(self) -> None:
        response = {
            "jsonrpc": "2.0",
            "result": {
                "tools": [
                    {"name": "create_issue", "description": "Creates a Jira issue"},
                    {"name": "list_projects", "description": "Lists projects"},
                ],
            },
            "id": 1,
        }
        result = self.client._parse_jsonrpc_result(response, "list_tools")
        assert result["success"] is True
        assert len(result["tools"]) == 2
        assert result["tools"][0]["name"] == "create_issue"

    def test_jsonrpc_error(self) -> None:
        response = {
            "jsonrpc": "2.0",
            "error": {"code": -32600, "message": "Invalid Request"},
            "id": 1,
        }
        result = self.client._parse_jsonrpc_result(response, "call_tool")
        assert result["success"] is False
        assert "-32600" in result["error"]
        assert "Invalid Request" in result["error"]

    def test_empty_result(self) -> None:
        response = {"jsonrpc": "2.0", "result": {}, "id": 1}
        result = self.client._parse_jsonrpc_result(response, "call_tool")
        assert result["success"] is True
        assert result["content"] == []


# ──────────────────────────────────────────────── SSE Parsing ──


class TestParseSseResponse:
    @pytest.mark.asyncio
    async def test_parse_sse_single_data_line(self) -> None:
        client = McpClient()
        resp = MagicMock()

        sse_data = json.dumps({
            "jsonrpc": "2.0",
            "result": {"content": [{"type": "text", "text": "ok"}]},
            "id": 1,
        })

        async def mock_content():
            yield f"data: {sse_data}\n".encode("utf-8")

        resp.content = mock_content()
        result = await client._parse_sse_response(resp)
        assert "result" in result
        assert result["result"]["content"][0]["text"] == "ok"

    @pytest.mark.asyncio
    async def test_parse_sse_multiple_data_lines_takes_last(self) -> None:
        client = McpClient()
        resp = MagicMock()

        first_data = json.dumps({"jsonrpc": "2.0", "result": {"content": [{"type": "text", "text": "first"}]}, "id": 1})
        last_data = json.dumps({"jsonrpc": "2.0", "result": {"content": [{"type": "text", "text": "last"}]}, "id": 1})

        async def mock_content():
            yield f"data: {first_data}\n".encode("utf-8")
            yield b"event: progress\n"
            yield f"data: {last_data}\n".encode("utf-8")

        resp.content = mock_content()
        result = await client._parse_sse_response(resp)
        assert result["result"]["content"][0]["text"] == "last"

    @pytest.mark.asyncio
    async def test_parse_sse_empty_returns_error(self) -> None:
        client = McpClient()
        resp = MagicMock()

        async def mock_content():
            yield b"event: keep-alive\n"
            yield b": comment\n"

        resp.content = mock_content()
        result = await client._parse_sse_response(resp)
        assert "error" in result

    @pytest.mark.asyncio
    async def test_parse_sse_invalid_json_returns_error(self) -> None:
        client = McpClient()
        resp = MagicMock()

        async def mock_content():
            yield b"data: not-json\n"

        resp.content = mock_content()
        result = await client._parse_sse_response(resp)
        assert "error" in result


# ──────────────────────────────────────────────── Integration (mocked HTTP) ──


class TestMcpClientCallTool:
    @pytest.mark.asyncio
    async def test_call_tool_success(self) -> None:
        client = McpClient()
        jsonrpc_response = {
            "jsonrpc": "2.0",
            "result": {"content": [{"type": "text", "text": "Created issue PROJ-123"}]},
            "id": 1,
        }

        mock_resp = AsyncMock()
        mock_resp.status = 200
        mock_resp.headers = {"content-type": "application/json"}
        mock_resp.json = AsyncMock(return_value=jsonrpc_response)

        mock_session = AsyncMock()
        mock_session.post = MagicMock(return_value=_async_context_manager(mock_resp))

        with patch("qremotex.tools.mcp_client.validate_outbound_target", return_value=True):
            with patch("aiohttp.ClientSession", return_value=_async_context_manager(mock_session)):
                result = await client.call_tool(
                    server_url="https://jira-mcp.corp:8443/mcp",
                    tool_name="create_issue",
                    arguments={"project": "PROJ", "summary": "Test"},
                    auth_headers={"Authorization": "Bearer tok"},
                    timeout=30,
                )

        assert result["success"] is True
        assert result["content"][0]["text"] == "Created issue PROJ-123"

    @pytest.mark.asyncio
    async def test_call_tool_http_error(self) -> None:
        client = McpClient()

        mock_resp = AsyncMock()
        mock_resp.status = 500
        mock_resp.headers = {"content-type": "text/plain"}
        mock_resp.text = AsyncMock(return_value="Internal Server Error")

        mock_session = AsyncMock()
        mock_session.post = MagicMock(return_value=_async_context_manager(mock_resp))

        with patch("qremotex.tools.mcp_client.validate_outbound_target", return_value=True):
            with patch("aiohttp.ClientSession", return_value=_async_context_manager(mock_session)):
                result = await client.call_tool(
                    server_url="https://mcp.corp/mcp",
                    tool_name="test",
                    arguments={},
                    auth_headers={},
                    timeout=10,
                )

        assert result["success"] is False
        assert "HTTP 500" in result["error"]

    @pytest.mark.asyncio
    async def test_call_tool_connection_error(self) -> None:
        client = McpClient()

        import aiohttp
        with patch("qremotex.tools.mcp_client.validate_outbound_target", return_value=True):
            with patch("aiohttp.ClientSession", side_effect=aiohttp.ClientError("connection refused")):
                result = await client.call_tool(
                    server_url="https://unreachable.corp/mcp",
                    tool_name="test",
                    arguments={},
                    auth_headers={},
                    timeout=5,
                )

        assert result["success"] is False
        assert "Connection failed" in result["error"] or "ClientError" in result["error"]


class TestMcpClientListTools:
    @pytest.mark.asyncio
    async def test_list_tools_success(self) -> None:
        client = McpClient()
        jsonrpc_response = {
            "jsonrpc": "2.0",
            "result": {
                "tools": [
                    {"name": "create_issue", "description": "Create Jira issue", "inputSchema": {"type": "object"}},
                ],
            },
            "id": 1,
        }

        mock_resp = AsyncMock()
        mock_resp.status = 200
        mock_resp.headers = {"content-type": "application/json"}
        mock_resp.json = AsyncMock(return_value=jsonrpc_response)

        mock_session = AsyncMock()
        mock_session.post = MagicMock(return_value=_async_context_manager(mock_resp))

        with patch("qremotex.tools.mcp_client.validate_outbound_target", return_value=True):
            with patch("aiohttp.ClientSession", return_value=_async_context_manager(mock_session)):
                result = await client.list_tools(
                    server_url="https://jira-mcp.corp/mcp",
                    auth_headers={},
                    timeout=30,
                )

        assert result["success"] is True
        assert len(result["tools"]) == 1
        assert result["tools"][0]["name"] == "create_issue"


# ──────────────────────────────────────────────── Helpers ──


def _async_context_manager(return_value):
    """Create an async context manager mock."""
    cm = MagicMock()
    cm.__aenter__ = AsyncMock(return_value=return_value)
    cm.__aexit__ = AsyncMock(return_value=False)
    return cm
