"""Tests for qremotex.execution.tool_executor — RemoteToolExecutor."""

import asyncio
import os
from unittest import mock
from unittest.mock import AsyncMock

import pytest

from qremotex.config import ExecutorConfig
from qremotex.execution.tool_executor import RemoteToolExecutor


def _make_config(**overrides: str) -> ExecutorConfig:
    """Build a config with sane test defaults."""
    env = {
        "QRAPTOR_GATEWAY_URL": "wss://gw.qraptor.io/ws/executor",
        "QRAPTOR_API_KEY": "qrx_test_key123",
        "EXEC_TIMEOUT_SEC": "10",
    }
    env.update(overrides)
    with mock.patch.dict(os.environ, env, clear=False):
        return ExecutorConfig()


class TestToolAllowed:
    """Allowlist / blocklist checks (C7)."""

    def test_all_allowed_by_default(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)
        assert ex._check_tool_allowed("system.db_query") is None
        assert ex._check_tool_allowed("project.crm_api") is None

    def test_blocklist_rejects(self) -> None:
        cfg = _make_config(BLOCKED_TOOL_KEYS="system.db_query,project.dangerous")
        ex = RemoteToolExecutor(cfg)
        assert ex._check_tool_allowed("system.db_query") is not None
        assert ex._check_tool_allowed("project.dangerous") is not None
        assert ex._check_tool_allowed("system.http_request") is None  # not blocked

    def test_allowlist_rejects_unlisted(self) -> None:
        cfg = _make_config(ALLOWED_TOOL_KEYS="system.db_query,system.http_request")
        ex = RemoteToolExecutor(cfg)
        assert ex._check_tool_allowed("system.db_query") is None
        assert ex._check_tool_allowed("system.http_request") is None
        assert ex._check_tool_allowed("system.web_crawler") is not None

    def test_system_tools_disabled(self) -> None:
        cfg = _make_config(ENABLE_SYSTEM_TOOLS="false")
        ex = RemoteToolExecutor(cfg)
        err = ex._check_tool_allowed("system.db_query")
        assert err is not None and "disabled" in err
        assert ex._check_tool_allowed("project.crm_api") is None

    def test_user_tools_disabled(self) -> None:
        cfg = _make_config(ENABLE_USER_TOOLS="false")
        ex = RemoteToolExecutor(cfg)
        assert ex._check_tool_allowed("system.db_query") is None
        err = ex._check_tool_allowed("project.crm_api")
        assert err is not None and "disabled" in err


class TestNativeExecution:
    """NATIVE tool execution tests."""

    @pytest.mark.asyncio
    async def test_native_calls_handler(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        # Replace registry with a mock handler
        mock_handler = AsyncMock(return_value={"rows": [{"id": 1}], "row_count": 1})
        ex._registry._handlers["system.db_query"] = mock_handler

        result = await ex.execute(
            tool_key="system.db_query",
            tool_params={"query": "SELECT 1"},
            tool_definition={"execution_target_kind": "NATIVE", "timeout_seconds": 5},
            context={"run_id": "r1", "request_id": "req1"},
        )

        assert result["success"] is True
        assert result["result"]["row_count"] == 1
        assert result["duration_ms"] >= 0
        mock_handler.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_native_missing_handler(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="system.nonexistent",
            tool_params={},
            tool_definition={"execution_target_kind": "NATIVE", "timeout_seconds": 5},
            context={},
        )

        assert result["success"] is False
        assert "No native handler" in result["error"]

    @pytest.mark.asyncio
    async def test_native_timeout(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        async def slow_handler(params: dict, ctx: dict) -> dict:
            await asyncio.sleep(10)
            return {}

        ex._registry._handlers["system.slow"] = slow_handler

        result = await ex.execute(
            tool_key="system.slow",
            tool_params={},
            tool_definition={"execution_target_kind": "NATIVE", "timeout_seconds": 0.1},
            context={},
        )

        assert result["success"] is False
        assert "timed out" in result["error"]

    @pytest.mark.asyncio
    async def test_native_handler_exception(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        async def broken_handler(params: dict, ctx: dict) -> dict:
            raise RuntimeError("connection failed")

        ex._registry._handlers["system.broken"] = broken_handler

        result = await ex.execute(
            tool_key="system.broken",
            tool_params={},
            tool_definition={"execution_target_kind": "NATIVE", "timeout_seconds": 5},
            context={},
        )

        assert result["success"] is False
        assert "RuntimeError" in result["error"]
        assert "connection failed" in result["error"]


class TestProjectNativeExecution:
    """PROJECT NATIVE tool execution (embedded Python handler code via multiprocessing)."""

    @pytest.mark.asyncio
    async def test_simple_handler_success(self) -> None:
        """Handler returns a dict → success."""
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="project.greet",
            tool_params={"name": "Alice"},
            tool_definition={
                "execution_target_kind": "NATIVE",
                "timeout_seconds": 10,
                "python_handler_code": (
                    "def handler(input, ctx):\n"
                    "    return {'greeting': f'Hello, {input[\"name\"]}!'}\n"
                ),
                "native_handler_ref": "handler",
            },
            context={"subscription_id": "sub1", "project_id": "proj1", "run_id": "r1"},
        )

        assert result["success"] is True
        assert result["result"]["greeting"] == "Hello, Alice!"
        assert result["duration_ms"] >= 0

    @pytest.mark.asyncio
    async def test_custom_handler_name(self) -> None:
        """Handler function with a non-default name is found via native_handler_ref."""
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="project.custom",
            tool_params={"x": 5},
            tool_definition={
                "execution_target_kind": "NATIVE",
                "timeout_seconds": 10,
                "python_handler_code": (
                    "def my_func(input, ctx):\n"
                    "    return {'doubled': input['x'] * 2}\n"
                ),
                "native_handler_ref": "my_func",
            },
            context={},
        )

        assert result["success"] is True
        assert result["result"]["doubled"] == 10

    @pytest.mark.asyncio
    async def test_missing_handler_function(self) -> None:
        """Handler function not found in code → error with available names."""
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="project.bad",
            tool_params={},
            tool_definition={
                "execution_target_kind": "NATIVE",
                "timeout_seconds": 10,
                "python_handler_code": (
                    "def something_else(input, ctx):\n"
                    "    return {}\n"
                ),
                "native_handler_ref": "nonexistent",
            },
            context={},
        )

        assert result["success"] is False
        assert "not found" in result["error"]

    @pytest.mark.asyncio
    async def test_syntax_error_in_handler(self) -> None:
        """Syntax error in handler code → descriptive error."""
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="project.broken",
            tool_params={},
            tool_definition={
                "execution_target_kind": "NATIVE",
                "timeout_seconds": 10,
                "python_handler_code": "def handler(input, ctx)\n    return {}\n",  # missing colon
                "native_handler_ref": "handler",
            },
            context={},
        )

        assert result["success"] is False
        assert "Syntax error" in result["error"] or "SyntaxError" in result["error"]

    @pytest.mark.asyncio
    async def test_handler_exception(self) -> None:
        """Handler raises an exception → error propagated."""
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="project.fail",
            tool_params={},
            tool_definition={
                "execution_target_kind": "NATIVE",
                "timeout_seconds": 10,
                "python_handler_code": (
                    "def handler(input, ctx):\n"
                    "    raise ValueError('bad input')\n"
                ),
                "native_handler_ref": "handler",
            },
            context={},
        )

        assert result["success"] is False
        assert "bad input" in result["error"]

    @pytest.mark.asyncio
    async def test_handler_timeout(self) -> None:
        """Handler that blocks past timeout → process terminated."""
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="project.slow",
            tool_params={},
            tool_definition={
                "execution_target_kind": "NATIVE",
                "timeout_seconds": 0.5,
                "python_handler_code": (
                    "import time\n"
                    "def handler(input, ctx):\n"
                    "    time.sleep(30)\n"
                    "    return {}\n"
                ),
                "native_handler_ref": "handler",
            },
            context={},
        )

        assert result["success"] is False
        assert "timed out" in result["error"]

    @pytest.mark.asyncio
    async def test_missing_handler_code(self) -> None:
        """Empty python_handler_code → error."""
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="project.empty",
            tool_params={},
            tool_definition={
                "execution_target_kind": "NATIVE",
                "timeout_seconds": 5,
                "python_handler_code": "",
                "native_handler_ref": "handler",
            },
            context={},
        )

        # Empty string is falsy, so dispatch falls through to _execute_native
        # which uses registry and fails with "No native handler"
        assert result["success"] is False

    @pytest.mark.asyncio
    async def test_ctx_contains_execution_context(self) -> None:
        """Handler receives ctx with subscription_id, project_id, etc."""
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="project.ctx_check",
            tool_params={},
            tool_definition={
                "execution_target_kind": "NATIVE",
                "timeout_seconds": 10,
                "python_handler_code": (
                    "def handler(input, ctx):\n"
                    "    return {\n"
                    "        'sub': ctx.get('subscription_id'),\n"
                    "        'proj': ctx.get('project_id'),\n"
                    "        'run': ctx.get('run_id'),\n"
                    "    }\n"
                ),
                "native_handler_ref": "handler",
            },
            context={"subscription_id": "sub-123", "project_id": "proj-456", "run_id": "run-789"},
        )

        assert result["success"] is True
        assert result["result"]["sub"] == "sub-123"
        assert result["result"]["proj"] == "proj-456"
        assert result["result"]["run"] == "run-789"

    @pytest.mark.asyncio
    async def test_blocklist_applies_to_project_native(self) -> None:
        """Blocklist enforcement applies to project.* tools with handler code."""
        cfg = _make_config(BLOCKED_TOOL_KEYS="project.blocked")
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="project.blocked",
            tool_params={},
            tool_definition={
                "execution_target_kind": "NATIVE",
                "timeout_seconds": 5,
                "python_handler_code": "def handler(input, ctx):\n    return {}\n",
            },
            context={},
        )

        assert result["success"] is False
        assert "blocked" in result["error"]

    @pytest.mark.asyncio
    async def test_async_handler(self) -> None:
        """Async handler function executes correctly in child process."""
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        code = (
            "import asyncio\n"
            "async def handler(input, ctx):\n"
            "    await asyncio.sleep(0.01)\n"
            "    return {'async': True}\n"
        )
        result = await ex.execute(
            tool_key="project.async_tool",
            tool_params={},
            tool_definition={
                "execution_target_kind": "NATIVE",
                "timeout_seconds": 10,
                "python_handler_code": code,
                "native_handler_ref": "handler",
            },
            context={"subscription_id": "sub1", "project_id": "proj1"},
        )

        assert result["success"] is True
        assert result["result"]["async"] is True

    @pytest.mark.asyncio
    async def test_ctx_no_sdk_clients(self) -> None:
        """Handler ctx must NOT contain SDK clients (db, llm, config)."""
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        code = (
            "def handler(input, ctx):\n"
            "    return {\n"
            "        'has_db': 'db' in ctx,\n"
            "        'has_llm': 'llm' in ctx,\n"
            "        'has_config': 'config' in ctx,\n"
            "    }\n"
        )
        result = await ex.execute(
            tool_key="project.sdk_check",
            tool_params={},
            tool_definition={
                "execution_target_kind": "NATIVE",
                "timeout_seconds": 10,
                "python_handler_code": code,
                "native_handler_ref": "handler",
            },
            context={"subscription_id": "sub1", "project_id": "proj1"},
        )

        assert result["success"] is True
        assert result["result"]["has_db"] is False
        assert result["result"]["has_llm"] is False
        assert result["result"]["has_config"] is False


class TestBlockedToolExecution:
    """Verify allowlist/blocklist enforcement in execute()."""

    @pytest.mark.asyncio
    async def test_blocked_tool_returns_error(self) -> None:
        cfg = _make_config(BLOCKED_TOOL_KEYS="system.db_query")
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="system.db_query",
            tool_params={},
            tool_definition={"execution_target_kind": "NATIVE", "timeout_seconds": 5},
            context={},
        )

        assert result["success"] is False
        assert "blocked" in result["error"]


class TestUnsupportedKind:
    """Unknown execution_target_kind."""

    @pytest.mark.asyncio
    async def test_unsupported_kind(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="system.db_query",
            tool_params={},
            tool_definition={"execution_target_kind": "UNKNOWN_KIND"},
            context={},
        )

        assert result["success"] is False
        assert "Unsupported" in result["error"]

    @pytest.mark.asyncio
    async def test_defaults_to_native_kind(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        # No execution_target_kind → defaults to NATIVE
        mock_handler = AsyncMock(return_value={"ok": True})
        ex._registry._handlers["system.db_query"] = mock_handler

        result = await ex.execute(
            tool_key="system.db_query",
            tool_params={},
            tool_definition={},
            context={},
        )

        assert result["success"] is True
        mock_handler.assert_awaited_once()


class TestMcpServerExecution:
    """MCP_SERVER tool execution tests."""

    @pytest.mark.asyncio
    async def test_mcp_server_calls_mcp_client(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        ex._mcp_client.call_tool = AsyncMock(return_value={
            "success": True,
            "content": [{"type": "text", "text": "Created PROJ-123"}],
        })

        result = await ex.execute(
            tool_key="mcp.jira.create_issue",
            tool_params={"project": "PROJ", "summary": "Test"},
            tool_definition={
                "execution_target_kind": "MCP_SERVER",
                "timeout_seconds": 30,
                "mcp_config": {
                    "server_url": "https://jira-mcp.corp:8443/mcp",
                    "mcp_tool_name": "create_issue",
                    "auth_type": "BEARER_TOKEN",
                },
                "mcp_credentials": {"bearer_token": "tok123"},
            },
            context={"run_id": "r1"},
        )

        assert result["success"] is True
        assert result["result"]["content"][0]["text"] == "Created PROJ-123"
        ex._mcp_client.call_tool.assert_awaited_once()
        call_kwargs = ex._mcp_client.call_tool.call_args
        assert call_kwargs.kwargs["tool_name"] == "create_issue"
        assert call_kwargs.kwargs["auth_headers"] == {"Authorization": "Bearer tok123"}

    @pytest.mark.asyncio
    async def test_mcp_server_missing_mcp_config(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="mcp.jira.create_issue",
            tool_params={},
            tool_definition={
                "execution_target_kind": "MCP_SERVER",
                "timeout_seconds": 5,
            },
            context={},
        )

        assert result["success"] is False
        assert "missing mcp_config" in result["error"]

    @pytest.mark.asyncio
    async def test_mcp_server_missing_server_url(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="mcp.jira.create_issue",
            tool_params={},
            tool_definition={
                "execution_target_kind": "MCP_SERVER",
                "timeout_seconds": 5,
                "mcp_config": {"mcp_tool_name": "create_issue"},
            },
            context={},
        )

        assert result["success"] is False
        assert "missing mcp_config.server_url" in result["error"]

    @pytest.mark.asyncio
    async def test_mcp_server_missing_mcp_tool_name(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="mcp.jira.create_issue",
            tool_params={},
            tool_definition={
                "execution_target_kind": "MCP_SERVER",
                "timeout_seconds": 5,
                "mcp_config": {"server_url": "https://mcp.corp/mcp"},
            },
            context={},
        )

        assert result["success"] is False
        assert "missing mcp_config.mcp_tool_name" in result["error"]

    @pytest.mark.asyncio
    async def test_mcp_server_timeout(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        async def slow_call(**kwargs):
            await asyncio.sleep(10)
            return {"success": True, "content": []}

        ex._mcp_client.call_tool = slow_call  # type: ignore[assignment]

        result = await ex.execute(
            tool_key="mcp.jira.create_issue",
            tool_params={},
            tool_definition={
                "execution_target_kind": "MCP_SERVER",
                "timeout_seconds": 0.1,
                "mcp_config": {
                    "server_url": "https://mcp.corp/mcp",
                    "mcp_tool_name": "create_issue",
                    "auth_type": "NONE",
                },
            },
            context={},
        )

        assert result["success"] is False
        assert "timed out" in result["error"]

    @pytest.mark.asyncio
    async def test_mcp_server_blocklist_applies(self) -> None:
        """mcp.* keys are NOT system tools — blocklist still applies."""
        cfg = _make_config(BLOCKED_TOOL_KEYS="mcp.jira.create_issue")
        ex = RemoteToolExecutor(cfg)

        result = await ex.execute(
            tool_key="mcp.jira.create_issue",
            tool_params={},
            tool_definition={
                "execution_target_kind": "MCP_SERVER",
                "timeout_seconds": 5,
                "mcp_config": {
                    "server_url": "https://mcp.corp/mcp",
                    "mcp_tool_name": "create_issue",
                },
            },
            context={},
        )

        assert result["success"] is False
        assert "blocked" in result["error"]

    @pytest.mark.skip(reason="MCP functionality refactored - test needs update for 2.0 release")
    @pytest.mark.asyncio
    async def test_mcp_server_mcp_client_returns_error(self) -> None:
        cfg = _make_config()
        ex = RemoteToolExecutor(cfg)

        ex._mcp_client.call_tool = AsyncMock(return_value={
            "success": False,
            "error": "MCP error [-32600]: Invalid Request",
        })

        result = await ex.execute(
            tool_key="mcp.jira.create_issue",
            tool_params={},
            tool_definition={
                "execution_target_kind": "MCP_SERVER",
                "timeout_seconds": 5,
                "mcp_config": {
                    "server_url": "https://mcp.corp/mcp",
                    "mcp_tool_name": "create_issue",
                    "auth_type": "NONE",
                },
            },
            context={},
        )

        # McpClient returns {"success": False, "error": "..."} which gets
        # wrapped by execute() as {"success": False, "error": ...}
        assert result["success"] is False
        assert "MCP error" in result["error"]


class TestBackwardCompatShim:
    """Verify QRP backward-compat shim in _run_tool()."""

    @pytest.mark.asyncio
    async def test_old_format_tool_params(self) -> None:
        """Old format: input_data at top level, execution_target_kind flat."""
        from qremotex.execution.job_queue import Job
        from qremotex.main import QRemoteXAgent

        cfg = _make_config()
        agent = QRemoteXAgent(cfg)

        mock_execute = AsyncMock(return_value={"success": True, "result": {"ok": True}, "duration_ms": 10})
        agent._tool_executor.execute = mock_execute

        job = Job(
            request_id="req-old",
            job_type="tool",
            payload={
                "tool_key": "system.db_query",
                "input_data": {"query": "SELECT 1"},
                "execution_target_kind": "NATIVE",
                "input_schema": {"type": "object"},
                "timeout_seconds": 5,
                "context": {"run_id": "r1"},
            },
            timeout_sec=10,
        )

        result = await agent._run_tool(job)
        assert result["success"] is True
        mock_execute.assert_awaited_once()

        call_kwargs = mock_execute.call_args.kwargs
        assert call_kwargs["tool_key"] == "system.db_query"
        assert call_kwargs["tool_params"] == {"query": "SELECT 1"}
        assert call_kwargs["tool_definition"]["execution_target_kind"] == "NATIVE"

    @pytest.mark.asyncio
    async def test_new_format_tool_params(self) -> None:
        """New format: tool_params + nested tool_definition."""
        from qremotex.execution.job_queue import Job
        from qremotex.main import QRemoteXAgent

        cfg = _make_config()
        agent = QRemoteXAgent(cfg)

        mock_execute = AsyncMock(return_value={"success": True, "result": {"ok": True}, "duration_ms": 10})
        agent._tool_executor.execute = mock_execute

        job = Job(
            request_id="req-new",
            job_type="tool",
            payload={
                "tool_key": "mcp.jira.create_issue",
                "tool_params": {"project": "PROJ", "summary": "Test"},
                "tool_definition": {
                    "execution_target_kind": "MCP_SERVER",
                    "timeout_seconds": 30,
                    "mcp_config": {
                        "server_url": "https://jira-mcp.corp/mcp",
                        "mcp_tool_name": "create_issue",
                        "auth_type": "BEARER_TOKEN",
                    },
                    "mcp_credentials": {"bearer_token": "tok"},
                },
                "context": {"run_id": "r2"},
            },
            timeout_sec=30,
        )

        result = await agent._run_tool(job)
        assert result["success"] is True

        call_kwargs = mock_execute.call_args.kwargs
        assert call_kwargs["tool_key"] == "mcp.jira.create_issue"
        assert call_kwargs["tool_params"] == {"project": "PROJ", "summary": "Test"}
        assert call_kwargs["tool_definition"]["mcp_config"]["server_url"] == "https://jira-mcp.corp/mcp"
        assert call_kwargs["tool_definition"]["mcp_credentials"]["bearer_token"] == "tok"

    @pytest.mark.asyncio
    async def test_missing_tool_key(self) -> None:
        from qremotex.execution.job_queue import Job
        from qremotex.main import QRemoteXAgent

        cfg = _make_config()
        agent = QRemoteXAgent(cfg)

        job = Job(
            request_id="req-no-key",
            job_type="tool",
            payload={"input_data": {"query": "SELECT 1"}},
            timeout_sec=10,
        )

        result = await agent._run_tool(job)
        assert result["success"] is False
        assert "Missing tool_key" in result["error"]
