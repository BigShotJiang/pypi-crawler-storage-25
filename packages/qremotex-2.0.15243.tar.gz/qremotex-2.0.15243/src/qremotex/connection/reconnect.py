"""Exponential backoff reconnect strategy.

Implements the reconnect pattern from Section 5.1:
  - Exponential backoff with jitter
  - Maximum backoff cap (default 60s)
  - Reset on successful connection
"""

from __future__ import annotations

import random


class ReconnectStrategy:
    """Exponential backoff with jitter for WebSocket reconnection."""

    def __init__(self, max_sec: int = 60, base: float = 1.0) -> None:
        self._max_sec = max_sec
        self._base = base
        self._attempt = 0

    def next_delay(self) -> float:
        """Calculate next reconnect delay in seconds."""
        delay = min(self._max_sec, self._base * (2 ** self._attempt))
        jitter = random.uniform(0, 0.5 * delay)
        self._attempt += 1
        return delay + jitter

    def reset(self) -> None:
        """Reset backoff counter (call on successful connection)."""
        self._attempt = 0

    @property
    def attempt(self) -> int:
        return self._attempt
