"""StorageProvider bridge for qRemoteX file transfers.

Provides a high-level API for qRemoteX executors to fetch input files and
upload execution results via the qRunX StorageProvider abstraction.

DECISION D7: qRemoteX uses StorageProvider (via qRunX Media API) for all file
operations. In hosted mode, qRunX delegates to QRaptorDMSProvider → DMS.
In export mode, qRunX delegates to LocalStorageProvider → filesystem.

Architecture:
    qRemoteX executor needs input file
      → StorageBridge.download_input(ref_id) 
      → HTTP GET qRunX /api/v1/media/{ref_id}/download
      → File written to local executor workspace
      
    qRemoteX executor produces output file
      → StorageBridge.upload_result(local_path, ...)
      → HTTP POST qRunX /api/v1/media/upload
      → Returns StorageRef {ref_id, download_url}

This supplements (not replaces) the existing chunked QRP transfer for cases
where HTTP is available. The chunked QRP transfer (FileDownloader/FileUploader)
remains for cases where only WebSocket is available.

SECURITY:
─────────
- Subscription-scoped access (X-Subscription-Id header required)
- API key authentication to qRunX
- Path traversal prevention on local paths
- SHA-256 checksum verification on downloads
- TLS required for all HTTP calls

Copyright (c) 2025-2026 qRaptor. All rights reserved.
"""

from __future__ import annotations

import hashlib
import logging
import os
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger("qremotex.transfer.storage_bridge")


@dataclass
class StorageRefResult:
    """Result from a StorageProvider operation via qRunX."""

    ref_id: str
    download_url: str
    mime_type: str
    filename: str
    size_bytes: int


class StorageBridge:
    """Bridge between qRemoteX and qRunX StorageProvider via HTTP.

    Uses the qRunX Media API endpoints for file operations:
    - GET  /api/v1/media/{ref_id}/download
    - POST /api/v1/media/upload

    This is the recommended approach when HTTP connectivity to qRunX
    is available. Falls back to QRP chunked transfer (FileDownloader/
    FileUploader) when only WebSocket is available.
    """

    def __init__(
        self,
        qrunx_base_url: str,
        api_key: str,
        subscription_id: str,
        executor_id: str,
        download_dir: str | None = None,
    ) -> None:
        """Initialize StorageBridge.

        Args:
            qrunx_base_url: Base URL for qRunX (e.g., "http://qrunx:8000")
            api_key: API key for authenticating to qRunX
            subscription_id: Tenant ID for scoping operations
            executor_id: This executor's ID for audit logging
            download_dir: Local directory for downloaded files
        """
        self._base_url = qrunx_base_url.rstrip("/")
        self._api_key = api_key
        self._subscription_id = subscription_id
        self._executor_id = executor_id
        self._download_dir = download_dir or "/tmp/qremotex-files"
        os.makedirs(self._download_dir, exist_ok=True)

    async def download_input(
        self,
        ref_id: str,
        target_filename: str | None = None,
    ) -> dict[str, Any]:
        """Download an input file from StorageProvider via qRunX.

        Args:
            ref_id: StorageRef ref_id for the file to download.
            target_filename: Optional local filename. If not provided,
                            uses the filename from the response headers.

        Returns:
            {"ok": True, "local_path": ..., "size_bytes": ..., "checksum": ...}
            or {"ok": False, "error": ...}
        """
        try:
            import httpx

            url = f"{self._base_url}/api/v1/media/{ref_id}/download"
            headers = {
                "X-Subscription-Id": self._subscription_id,
                "X-Executor-Id": self._executor_id,
                "Authorization": f"Bearer {self._api_key}",
            }

            async with httpx.AsyncClient(timeout=120.0) as client:
                response = await client.get(url, headers=headers)
                response.raise_for_status()

                # Determine filename
                if not target_filename:
                    cd = response.headers.get("content-disposition", "")
                    if 'filename="' in cd:
                        target_filename = cd.split('filename="')[1].rstrip('"')
                    else:
                        target_filename = f"input_{ref_id[:8]}"

                # Validate filename — prevent path traversal
                safe_name = os.path.basename(target_filename)
                local_path = os.path.join(self._download_dir, safe_name)

                # Verify path stays within download_dir
                resolved = os.path.realpath(local_path)
                if not resolved.startswith(os.path.realpath(self._download_dir)):
                    return {"ok": False, "error": "Path traversal detected"}

                data = response.content
                checksum = f"sha256:{hashlib.sha256(data).hexdigest()}"

                with open(local_path, "wb") as f:
                    f.write(data)

                logger.info(
                    "Downloaded input: ref_id=%s path=%s size=%d",
                    ref_id, local_path, len(data),
                )

                return {
                    "ok": True,
                    "local_path": local_path,
                    "size_bytes": len(data),
                    "checksum": checksum,
                    "mime_type": response.headers.get("content-type", ""),
                }

        except Exception as e:
            logger.error("Download failed: ref_id=%s error=%s", ref_id, e)
            return {"ok": False, "error": str(e)}

    async def upload_result(
        self,
        local_path: str,
        thread_id: str,
        mime_type: str | None = None,
    ) -> dict[str, Any]:
        """Upload an execution result to StorageProvider via qRunX.

        Args:
            local_path: Local path to the result file.
            thread_id: Thread/conversation ID for path scoping.
            mime_type: MIME type override. Auto-detected if not provided.

        Returns:
            {"ok": True, "ref_id": ..., "download_url": ..., "size_bytes": ...}
            or {"ok": False, "error": ...}
        """
        if not os.path.isfile(local_path):
            return {"ok": False, "error": f"File not found: {local_path}"}

        try:
            import httpx

            url = f"{self._base_url}/api/v1/media/upload"
            headers = {
                "X-Subscription-Id": self._subscription_id,
                "X-Executor-Id": self._executor_id,
                "Authorization": f"Bearer {self._api_key}",
            }
            params = {"thread_id": thread_id}

            filename = os.path.basename(local_path)
            content_type = mime_type or _guess_content_type(local_path)

            async with httpx.AsyncClient(timeout=120.0) as client:
                with open(local_path, "rb") as f:
                    files = {"file": (filename, f, content_type)}
                    response = await client.post(
                        url, headers=headers, params=params, files=files
                    )
                    response.raise_for_status()

                result = response.json()

                logger.info(
                    "Uploaded result: path=%s ref_id=%s size=%d",
                    local_path,
                    result.get("ref_id"),
                    result.get("size_bytes", 0),
                )

                return {
                    "ok": True,
                    "ref_id": result["ref_id"],
                    "download_url": result["download_url"],
                    "size_bytes": result.get("size_bytes", 0),
                    "mime_type": result.get("mime_type", content_type),
                    "filename": result.get("filename", filename),
                }

        except Exception as e:
            logger.error("Upload failed: path=%s error=%s", local_path, e)
            return {"ok": False, "error": str(e)}

    async def check_connectivity(self) -> bool:
        """Verify connectivity to qRunX Media API."""
        try:
            import httpx

            url = f"{self._base_url}/health"
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(url)
                return response.status_code == 200
        except Exception:
            return False


def _guess_content_type(path: str) -> str:
    """Detect content type from file extension."""
    ext = os.path.splitext(path)[1].lower()
    mapping = {
        ".json": "application/json",
        ".csv": "text/csv",
        ".txt": "text/plain",
        ".html": "text/html",
        ".xml": "application/xml",
        ".pdf": "application/pdf",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".mp3": "audio/mpeg",
        ".wav": "audio/wav",
        ".webm": "audio/webm",
        ".ogg": "audio/ogg",
        ".mp4": "video/mp4",
        ".zip": "application/zip",
        ".gz": "application/gzip",
    }
    return mapping.get(ext, "application/octet-stream")
