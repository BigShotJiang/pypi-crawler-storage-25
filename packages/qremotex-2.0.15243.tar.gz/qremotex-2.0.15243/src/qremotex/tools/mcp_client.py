"""MCP JSON-RPC 2.0 client for qRemoteX.

Supports two operations:
  - tools/call:  Execute a tool on an MCP server
  - tools/list:  Discover tools from an MCP server

Transport: HTTP POST with JSON-RPC 2.0 request body.
Response handling: synchronous JSON or SSE (text/event-stream).
Auth: 4 types — NONE, API_KEY, BEARER_TOKEN, CUSTOM_HEADERS.
SSRF: Uses OutboundBlocklistConfig from connection/ip_allowlist.py.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

import aiohttp

from qremotex.connection.ip_allowlist import (
    OutboundBlocklistConfig,
    validate_outbound_target,
)

logger = logging.getLogger("qremotex.tools.mcp_client")

# Shared SSRF config — initialized once
_ssrf_config = OutboundBlocklistConfig()


def build_auth_headers(auth_type: str, credentials: dict[str, Any]) -> dict[str, str]:
    """Build HTTP auth headers from pre-resolved credentials.

    Args:
        auth_type: One of NONE, API_KEY, BEARER_TOKEN, CUSTOM_HEADERS
        credentials: Pre-resolved credential values from qRunX

    Returns:
        Dict of HTTP headers to include in the MCP request.
    """
    if not auth_type or auth_type.upper() == "NONE":
        return {}

    headers: dict[str, str] = {}
    auth_upper = auth_type.upper()

    if auth_upper == "API_KEY":
        key_name = credentials.get("api_key_name") or credentials.get("api_key_header_name") or "X-API-Key"
        key_value = credentials.get("api_key_value") or credentials.get("api_key") or ""
        if key_value:
            headers[key_name] = key_value

    elif auth_upper == "BEARER_TOKEN":
        token = credentials.get("bearer_token") or credentials.get("token") or ""
        if token:
            headers["Authorization"] = f"Bearer {token}"

    elif auth_upper == "CUSTOM_HEADERS":
        custom = credentials.get("custom_headers", {})
        if isinstance(custom, str):
            try:
                custom = json.loads(custom)
            except (json.JSONDecodeError, TypeError):
                custom = {}
        if isinstance(custom, dict):
            for k, v in custom.items():
                headers[str(k)] = str(v)

    return headers


class McpClient:
    """MCP JSON-RPC 2.0 client using aiohttp."""

    async def call_tool(
        self,
        server_url: str,
        tool_name: str,
        arguments: dict[str, Any],
        auth_headers: dict[str, str],
        timeout: float,
    ) -> dict[str, Any]:
        """Execute MCP tools/call.

        Returns:
            {"success": True, "content": [...]} on success
            {"success": False, "error": "..."} on failure
        """
        # SSRF check
        if not validate_outbound_target(server_url, _ssrf_config):
            return {"success": False, "error": "MCP server URL blocked by SSRF protection"}

        request_body = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {"name": tool_name, "arguments": arguments},
            "id": 1,
        }

        return await self._send_jsonrpc(server_url, request_body, auth_headers, timeout, "call_tool")

    async def list_tools(
        self,
        server_url: str,
        auth_headers: dict[str, str],
        timeout: float,
    ) -> dict[str, Any]:
        """Execute MCP tools/list (discovery).

        Returns:
            {"success": True, "tools": [...]} on success
            {"success": False, "error": "..."} on failure
        """
        # SSRF check
        if not validate_outbound_target(server_url, _ssrf_config):
            return {"success": False, "error": "MCP server URL blocked by SSRF protection"}

        request_body = {
            "jsonrpc": "2.0",
            "method": "tools/list",
            "params": {},
            "id": 1,
        }

        return await self._send_jsonrpc(server_url, request_body, auth_headers, timeout, "list_tools")

    async def _send_jsonrpc(
        self,
        server_url: str,
        request_body: dict[str, Any],
        auth_headers: dict[str, str],
        timeout: float,
        operation: str,
    ) -> dict[str, Any]:
        """Send a JSON-RPC request and parse the response."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        headers.update(auth_headers)

        client_timeout = aiohttp.ClientTimeout(total=timeout)
        start = time.monotonic()

        try:
            async with aiohttp.ClientSession(timeout=client_timeout) as session:
                async with session.post(server_url, json=request_body, headers=headers) as resp:
                    duration_ms = int((time.monotonic() - start) * 1000)

                    if resp.status >= 400:
                        body_text = await resp.text()
                        logger.warning(
                            "MCP %s HTTP %d from %s (%dms)",
                            operation, resp.status, server_url, duration_ms,
                        )
                        return {
                            "success": False,
                            "error": f"MCP server returned HTTP {resp.status}: {body_text[:500]}",
                        }

                    content_type = resp.headers.get("content-type", "")

                    if "text/event-stream" in content_type:
                        # SSE response — buffer all data lines and parse final result
                        result = await self._parse_sse_response(resp)
                    else:
                        # Standard JSON response
                        result = await resp.json()

                    logger.info("MCP %s completed: %s (%dms)", operation, server_url, duration_ms)
                    return self._parse_jsonrpc_result(result, operation)

        except aiohttp.ClientError as e:
            logger.warning("MCP %s connection failed: %s: %s", operation, server_url, e)
            return {"success": False, "error": f"Connection failed: {server_url}: {e}"}
        except TimeoutError:
            logger.warning("MCP %s timed out after %.1fs: %s", operation, timeout, server_url)
            return {"success": False, "error": f"MCP server timed out after {timeout}s"}
        except Exception as e:
            logger.error("MCP %s unexpected error: %s: %s", operation, type(e).__name__, e)
            return {"success": False, "error": f"{type(e).__name__}: {e}"}

    async def _parse_sse_response(self, resp: aiohttp.ClientResponse) -> dict[str, Any]:
        """Parse an SSE (text/event-stream) response.

        Buffers all `data:` lines and parses the last one as the JSON-RPC result.
        """
        last_data = None
        async for line in resp.content:
            decoded = line.decode("utf-8", errors="replace").strip()
            if decoded.startswith("data:"):
                data_str = decoded[5:].strip()
                if data_str:
                    last_data = data_str

        if last_data is None:
            return {"error": {"code": -1, "message": "Empty SSE response"}}

        try:
            return json.loads(last_data)
        except json.JSONDecodeError:
            return {"error": {"code": -1, "message": "Invalid JSON in SSE response"}}

    def _parse_jsonrpc_result(
        self, response: dict[str, Any], operation: str
    ) -> dict[str, Any]:
        """Parse a JSON-RPC 2.0 response into our standard format."""
        # Check for JSON-RPC error
        if "error" in response and response["error"]:
            err = response["error"]
            code = err.get("code", "unknown")
            message = err.get("message", "Unknown MCP error")
            return {"success": False, "error": f"MCP error [{code}]: {message}"}

        result = response.get("result", {})

        if operation == "list_tools":
            tools = result.get("tools", [])
            return {"success": True, "tools": tools}
        else:
            content = result.get("content", [])
            is_error = result.get("isError", False)
            if is_error:
                error_text = ""
                for item in content:
                    if item.get("type") == "text":
                        error_text += item.get("text", "")
                return {"success": False, "error": error_text or "MCP tool returned an error"}
            return {"success": True, "content": content}
