"""RemoteToolExecutor — executes tools on the qRemoteX agent.

Handles two execution kinds per Section 12.3:
  NATIVE:      Built-in Python handlers (system.db_query, system.http_request, etc.)
  REMOTE_HTTP: HTTP calls to endpoints reachable from this machine's network.

Tool definitions (including kind, schema, http_config) are sent from qRunX
in the QRP execute_tool message.  All secrets/templates are PRE-RESOLVED by
qRunX before dispatch — qRemoteX is a "dumb executor".

Architecture reference: Section 12.3 — Tool Execution Architecture on qRemoteX.
"""

from __future__ import annotations

import asyncio
import logging
import multiprocessing as mp
import time
from typing import Any

import aiohttp

from qremotex.config import ExecutorConfig
from qremotex.tools.mcp_client import McpClient, build_auth_headers
from qremotex.tools.registry import ToolRegistry, build_default_registry

logger = logging.getLogger("qremotex.execution.tool_executor")


# ------------------------------------------------------------------ #
# PROJECT NATIVE worker (runs in child process)
# ------------------------------------------------------------------ #

_MAX_LOG_LINE = 10 * 1024  # 10 KB


def _project_native_worker(
    handler_code: str,
    handler_name: str,
    tool_params: dict,
    ctx: dict,
    log_q: mp.Queue,
    result_q: mp.Queue,
) -> None:
    """Execute a PROJECT NATIVE tool handler in an isolated child process.

    Called via multiprocessing.Process (spawn). The handler code is
    exec()'d to define the handler function, which is then called
    with (tool_params, ctx).

    Stdout/stderr is captured and forwarded as log entries via log_q.
    The final result (or error) goes to result_q.
    """
    import contextlib
    import io
    import inspect
    import json
    import traceback
    from datetime import datetime, timezone

    # -- stdout/stderr capture (reuse ScriptExecutor pattern) --
    def _emit(level: str, message: str, stream: str = "stdout") -> None:
        if len(message) > _MAX_LOG_LINE:
            message = message[:_MAX_LOG_LINE] + "... [truncated]"
        try:
            log_q.put_nowait({
                "type": "log",
                "level": level,
                "stream": stream,
                "message": message,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
        except Exception:
            pass

    class _LineBuffer(io.TextIOBase):
        def __init__(self, level: str, stream_name: str):
            self.buf = ""
            self.level = level
            self.stream_name = stream_name

        def write(self, s: str) -> int:
            if not isinstance(s, str):
                s = str(s)
            self.buf += s
            while "\n" in self.buf:
                line, self.buf = self.buf.split("\n", 1)
                if line:
                    _emit(self.level, line, self.stream_name)
            return len(s)

        def flush(self) -> None:
            if self.buf:
                _emit(self.level, self.buf, self.stream_name)
                self.buf = ""

    stdout_cap = _LineBuffer("info", "stdout")
    stderr_cap = _LineBuffer("error", "stderr")

    try:
        with contextlib.redirect_stdout(stdout_cap), contextlib.redirect_stderr(stderr_cap):
            # Build sandbox globals — full builtins (customer owns the environment)
            sandbox_globals: dict = {
                "__name__": "__handler__",
                "__builtins__": __builtins__,
            }

            # Step 1: exec handler code to define the function
            compiled = compile(handler_code, "<project_handler>", "exec")
            exec(compiled, sandbox_globals)  # noqa: S102

            # Step 2: find the handler function
            handler_func = sandbox_globals.get(handler_name)
            if not handler_func or not callable(handler_func):
                # Try common fallback names
                for fallback in ("handler", "main", "run", "execute"):
                    handler_func = sandbox_globals.get(fallback)
                    if handler_func and callable(handler_func):
                        break

            if not handler_func or not callable(handler_func):
                available = [
                    k for k in sandbox_globals
                    if callable(sandbox_globals.get(k)) and not k.startswith("_")
                ]
                result_q.put({
                    "success": False,
                    "error": f"Handler function '{handler_name}' not found in code. Available: {available}",
                })
                return

            # Step 3: call the handler (sync or async)
            if inspect.iscoroutinefunction(handler_func):
                import asyncio as _aio
                loop = _aio.new_event_loop()
                try:
                    result = loop.run_until_complete(handler_func(tool_params, ctx))
                finally:
                    loop.close()
            else:
                result = handler_func(tool_params, ctx)

        stdout_cap.flush()
        stderr_cap.flush()

        # Validate result is JSON-serializable
        try:
            json.dumps(result)
            result_q.put({"success": True, "result": result})
        except (TypeError, ValueError):
            result_q.put({"success": True, "result": {"__repr__": repr(result)}})

    except SyntaxError as e:
        stdout_cap.flush()
        stderr_cap.flush()
        result_q.put({
            "success": False,
            "error": f"Syntax error in handler code: {e}",
        })
    except Exception as e:
        stdout_cap.flush()
        stderr_cap.flush()
        result_q.put({
            "success": False,
            "error": f"Handler error: {e}",
            "trace": traceback.format_exc(),
        })


class RemoteToolExecutor:
    """Executes tools dispatched from qRunX via QRP execute_tool messages.

    Supports two kinds:
    - NATIVE:      Invokes a registered Python handler locally.
    - REMOTE_HTTP: Makes an HTTP call from this machine's network.
    """

    def __init__(self, config: ExecutorConfig) -> None:
        self._config = config
        self._registry: ToolRegistry = build_default_registry()
        self._mcp_client = McpClient()

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    async def execute(
        self,
        tool_key: str,
        tool_params: dict[str, Any],
        tool_definition: dict[str, Any],
        context: dict[str, Any],
        on_log: Any = None,
    ) -> dict[str, Any]:
        """Execute a tool and return a result dict.

        Args:
            tool_key: Full tool key (e.g. "system.db_query", "project.crm_api")
            tool_params: Fully-resolved input parameters from qRunX
            tool_definition: Tool metadata including execution_target_kind,
                             input_schema, http_config, timeout_seconds
            context: Execution context (run_id, request_id, subscription_id, trace_id)

        Returns:
            dict: {"success": True, "result": ..., "duration_ms": ...}
                  or {"success": False, "error": "..."}
        """
        # Check allowlist/blocklist
        rejection = self._check_tool_allowed(tool_key)
        if rejection:
            return {"success": False, "error": rejection}

        kind = tool_definition.get("execution_target_kind", "NATIVE").upper()
        timeout_sec = tool_definition.get("timeout_seconds", self._config.exec_timeout_sec)

        start = time.monotonic()
        try:
            if kind == "NATIVE":
                # Check if this is a PROJECT tool with embedded handler code
                if tool_definition.get("python_handler_code"):
                    result = await asyncio.wait_for(
                        self._execute_project_native(
                            tool_key, tool_params, tool_definition, context,
                            on_log=on_log,
                        ),
                        timeout=timeout_sec,
                    )
                else:
                    # Existing path: system tool via registry
                    result = await asyncio.wait_for(
                        self._execute_native(tool_key, tool_params, context),
                        timeout=timeout_sec,
                    )
            elif kind == "REMOTE_HTTP":
                result = await asyncio.wait_for(
                    self._execute_http(tool_key, tool_params, tool_definition, context),
                    timeout=timeout_sec,
                )
            elif kind == "MCP_SERVER":
                result = await asyncio.wait_for(
                    self._execute_mcp(tool_key, tool_params, tool_definition, context),
                    timeout=timeout_sec,
                )
            else:
                return {
                    "success": False,
                    "error": f"Unsupported execution_target_kind: {kind}",
                }

            duration_ms = int((time.monotonic() - start) * 1000)

            # If the handler already returned a structured result, use it
            if isinstance(result, dict) and "error" in result and "success" not in result:
                return {"success": False, "error": result["error"], "duration_ms": duration_ms}

            return {"success": True, "result": result, "duration_ms": duration_ms}

        except asyncio.TimeoutError:
            duration_ms = int((time.monotonic() - start) * 1000)
            logger.warning("Tool %s timed out after %ds", tool_key, timeout_sec)
            return {
                "success": False,
                "error": f"Tool execution timed out after {timeout_sec}s",
                "duration_ms": duration_ms,
            }
        except Exception as e:
            duration_ms = int((time.monotonic() - start) * 1000)
            logger.error("Tool %s failed: %s: %s", tool_key, type(e).__name__, e)
            return {
                "success": False,
                "error": f"{type(e).__name__}: {e}",
                "duration_ms": duration_ms,
            }

    # ------------------------------------------------------------------ #
    # Allowlist / Blocklist (C7)
    # ------------------------------------------------------------------ #

    def _check_tool_allowed(self, tool_key: str) -> str | None:
        """Return an error string if the tool is blocked, None if allowed."""
        # Blocklist takes precedence
        if tool_key in self._config.blocked_tool_keys:
            return f"Tool '{tool_key}' is blocked by executor configuration"

        # Check system/user tool category
        is_system = tool_key.startswith("system.")
        if is_system and not self._config.enable_system_tools:
            return f"System tools disabled on this executor (tool: {tool_key})"
        if not is_system and not self._config.enable_user_tools:
            return f"User/project tools disabled on this executor (tool: {tool_key})"

        # Allowlist: "*" means all allowed, otherwise must be in the list
        allowed = self._config.allowed_tool_keys
        if allowed != "*" and isinstance(allowed, list):
            if tool_key not in allowed:
                return f"Tool '{tool_key}' not in executor allowlist"

        return None

    # ------------------------------------------------------------------ #
    # NATIVE execution
    # ------------------------------------------------------------------ #

    async def _execute_native(
        self,
        tool_key: str,
        tool_params: dict[str, Any],
        context: dict[str, Any],
    ) -> Any:
        """Execute a NATIVE tool via the registry."""
        if not self._registry.has(tool_key):
            available = self._registry.registered_keys
            raise ValueError(
                f"No native handler for '{tool_key}'. Available: {available}"
            )

        handler = self._registry.get(tool_key)
        logger.info("Executing NATIVE tool: %s", tool_key)
        return await handler(tool_params, context)

    # ------------------------------------------------------------------ #
    # PROJECT NATIVE execution (embedded code in isolated process)
    # ------------------------------------------------------------------ #

    async def _execute_project_native(
        self,
        tool_key: str,
        tool_params: dict[str, Any],
        tool_definition: dict[str, Any],
        context: dict[str, Any],
        *,
        on_log: Any = None,
    ) -> dict[str, Any]:
        """Execute a PROJECT NATIVE tool with embedded Python handler code.

        Runs the handler in an isolated multiprocessing.Process (spawn).
        Handler code and secrets are pre-resolved by qRunX before dispatch.

        Args:
            tool_key: Full tool key (e.g. "project.my_tool")
            tool_params: Fully-resolved input parameters
            tool_definition: Contains python_handler_code, native_handler_ref, etc.
            context: Execution context (subscription_id, project_id, run_id, etc.)

        Returns:
            Handler result dict on success, error dict on failure.
        """
        handler_code = tool_definition.get("python_handler_code", "")
        if not handler_code:
            return {"error": "Missing python_handler_code for NATIVE tool"}

        handler_name = tool_definition.get("native_handler_ref", "handler")
        timeout_sec = tool_definition.get("timeout_seconds", self._config.exec_timeout_sec)

        # Build minimal ctx for handler (no SDK clients — Decision 4)
        ctx = {
            "subscription_id": context.get("subscription_id"),
            "project_id": context.get("project_id"),
            "run_id": context.get("run_id"),
            "trace_id": context.get("trace_id"),
            "agent_id": context.get("agent_id"),
        }

        # Do NOT log handler_code — may contain resolved secrets (NFR1.4)
        logger.info(
            "Executing PROJECT NATIVE tool: %s (handler=%s, code_len=%d)",
            tool_key, handler_name, len(handler_code),
        )

        log_q: mp.Queue = mp.Queue()
        result_q: mp.Queue = mp.Queue()

        proc = mp.Process(
            target=_project_native_worker,
            args=(handler_code, handler_name, tool_params, ctx, log_q, result_q),
            daemon=True,
        )
        proc.start()
        start = time.monotonic()

        try:
            while True:
                # Drain log queue (handler print() output)
                while not log_q.empty():
                    try:
                        _entry = log_q.get_nowait()
                        if on_log:
                            await on_log(_entry)
                    except Exception:
                        pass

                # Check for result
                if not result_q.empty():
                    res = result_q.get()
                    if res.get("success"):
                        return res.get("result", {})
                    else:
                        return {"error": res.get("error", "Unknown handler error")}

                # Timeout check
                elapsed = time.monotonic() - start
                if elapsed > timeout_sec:
                    if proc.is_alive():
                        proc.terminate()
                        proc.join(timeout=2)
                        if proc.is_alive():
                            proc.kill()
                    return {"error": f"Handler timed out after {timeout_sec}s"}

                await asyncio.sleep(0.05)

        finally:
            if proc.is_alive():
                try:
                    proc.terminate()
                    proc.join(timeout=1)
                except Exception:
                    pass

    # ------------------------------------------------------------------ #
    # REMOTE_HTTP execution
    # ------------------------------------------------------------------ #

    async def _execute_http(
        self,
        tool_key: str,
        tool_params: dict[str, Any],
        tool_definition: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute a REMOTE_HTTP tool by making an HTTP call from this machine.

        http_config is pre-resolved by qRunX (secrets injected, templates expanded).
        """
        http_config = tool_definition.get("http_config")
        if not http_config:
            raise ValueError(f"REMOTE_HTTP tool '{tool_key}' missing http_config")

        url = http_config.get("url")
        if not url:
            raise ValueError(f"REMOTE_HTTP tool '{tool_key}' missing http_config.url")

        method = http_config.get("method", "POST").upper()
        headers = dict(http_config.get("headers", {}))
        timeout_sec = tool_definition.get("timeout_seconds", 30)
        body_mode = http_config.get("body_mode", "json")  # json | form | raw

        logger.info("Executing REMOTE_HTTP tool: %s  %s %s", tool_key, method, url)

        timeout = aiohttp.ClientTimeout(total=timeout_sec)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            kwargs: dict[str, Any] = {"headers": headers}

            if method in ("POST", "PUT", "PATCH") and tool_params:
                if body_mode == "form":
                    kwargs["data"] = tool_params
                elif body_mode == "raw":
                    kwargs["data"] = str(tool_params.get("body", ""))
                else:
                    kwargs["json"] = tool_params

            async with session.request(method, url, **kwargs) as resp:
                content_type = resp.headers.get("content-type", "")
                if "application/json" in content_type:
                    body = await resp.json()
                else:
                    body = await resp.text()

                return {
                    "status_code": resp.status,
                    "body": body,
                    "headers": {k: v for k, v in resp.headers.items()},
                }

    # ------------------------------------------------------------------ #
    # MCP_SERVER execution
    # ------------------------------------------------------------------ #

    async def _execute_mcp(
        self,
        tool_key: str,
        tool_params: dict[str, Any],
        tool_definition: dict[str, Any],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute an MCP_SERVER tool via JSON-RPC tools/call.

        mcp_config and mcp_credentials are pre-resolved by qRunX and
        included in tool_definition.
        """
        mcp_config = tool_definition.get("mcp_config")
        if not mcp_config:
            raise ValueError(f"MCP_SERVER tool '{tool_key}' missing mcp_config in tool_definition")

        server_url = mcp_config.get("server_url")
        if not server_url:
            raise ValueError(f"MCP_SERVER tool '{tool_key}' missing mcp_config.server_url")

        mcp_tool_name = mcp_config.get("mcp_tool_name")
        if not mcp_tool_name:
            raise ValueError(f"MCP_SERVER tool '{tool_key}' missing mcp_config.mcp_tool_name")

        # Build auth headers from pre-resolved credentials
        mcp_credentials = tool_definition.get("mcp_credentials", {})
        auth_type = mcp_config.get("auth_type", "NONE")
        auth_headers = build_auth_headers(auth_type, mcp_credentials)

        timeout_sec = tool_definition.get("timeout_seconds", self._config.exec_timeout_sec)

        logger.info(
            "Executing MCP_SERVER tool: %s → %s on %s",
            tool_key, mcp_tool_name, server_url,
        )

        result = await self._mcp_client.call_tool(
            server_url=server_url,
            tool_name=mcp_tool_name,
            arguments=tool_params,
            auth_headers=auth_headers,
            timeout=timeout_sec,
        )

        return result
