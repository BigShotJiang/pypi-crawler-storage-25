#!/bin/sh
set -e

# ──────────────────────────────────────────────────────────
# qRemoteX Docker Entrypoint
# ──────────────────────────────────────────────────────────
# Installs user-specified packages before starting the agent.
#
# Usage:
#   Option A: Mount a requirements file
#     docker run -v /path/to/requirements.txt:/app/extra-requirements.txt ...
#
#   Option B: Pass packages via environment variable
#     docker run -e QRAPTOR_EXTRA_PACKAGES="pandas torch boto3" ...
#
#   Option C: No extras (default — just start the agent)
#     docker run ...
# ──────────────────────────────────────────────────────────

# Install from mounted requirements file
if [ -f /app/extra-requirements.txt ]; then
    echo "[qRemoteX] Installing packages from /app/extra-requirements.txt ..."
    pip install --no-cache-dir --user -r /app/extra-requirements.txt
    echo "[qRemoteX] Extra packages installed successfully."
fi

# Install from environment variable
if [ -n "$QRAPTOR_EXTRA_PACKAGES" ]; then
    echo "[qRemoteX] Installing packages: $QRAPTOR_EXTRA_PACKAGES ..."
    pip install --no-cache-dir --user $QRAPTOR_EXTRA_PACKAGES
    echo "[qRemoteX] Extra packages installed successfully."
fi

# Execute the main command
exec "$@"
