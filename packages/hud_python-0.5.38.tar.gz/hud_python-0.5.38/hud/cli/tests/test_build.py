"""Tests for build.py - Build HUD environments and generate lock files."""

from __future__ import annotations

import subprocess
from unittest import mock

import pytest
import typer
import yaml

from hud.cli.build import (
    analyze_mcp_environment,
    build_docker_image,
    build_environment,
    extract_env_vars_from_dockerfile,
    get_docker_image_digest,
    get_docker_image_id,
    get_existing_version,
    increment_version,
    parse_version,
)
from hud.cli.utils.docker import detect_transport, stop_container


class TestParseVersion:
    """Test version parsing functionality."""

    def test_parse_standard_version(self):
        """Test parsing standard semantic version."""
        assert parse_version("1.2.3") == (1, 2, 3)
        assert parse_version("10.20.30") == (10, 20, 30)

    def test_parse_version_with_v_prefix(self):
        """Test parsing version with v prefix."""
        assert parse_version("v1.2.3") == (1, 2, 3)
        assert parse_version("v2.0.0") == (2, 0, 0)

    def test_parse_incomplete_version(self):
        """Test parsing versions with missing parts."""
        assert parse_version("1.2") == (1, 2, 0)
        assert parse_version("1") == (1, 0, 0)
        assert parse_version("") == (0, 0, 0)

    def test_parse_invalid_version(self):
        """Test parsing invalid versions."""
        assert parse_version("abc") == (0, 0, 0)
        assert parse_version("1.x.3") == (0, 0, 0)
        assert parse_version("not-a-version") == (0, 0, 0)


class TestIncrementVersion:
    """Test version incrementing functionality."""

    def test_increment_patch(self):
        """Test incrementing patch version."""
        assert increment_version("1.2.3") == "1.2.4"
        assert increment_version("1.2.3", "patch") == "1.2.4"
        assert increment_version("1.0.0") == "1.0.1"

    def test_increment_minor(self):
        """Test incrementing minor version."""
        assert increment_version("1.2.3", "minor") == "1.3.0"
        assert increment_version("0.5.38", "minor") == "0.6.0"

    def test_increment_major(self):
        """Test incrementing major version."""
        assert increment_version("1.2.3", "major") == "2.0.0"
        assert increment_version("0.5.38", "major") == "1.0.0"

    def test_increment_with_v_prefix(self):
        """Test incrementing version with v prefix."""
        assert increment_version("v1.2.3") == "1.2.4"
        assert increment_version("v2.0.0", "major") == "3.0.0"


class TestGetExistingVersion:
    """Test getting version from lock file."""

    def test_get_version_from_lock(self, tmp_path):
        """Test extracting version from lock file."""
        lock_data = {"build": {"version": "1.2.3"}}
        lock_path = tmp_path / "hud.lock.yaml"
        lock_path.write_text(yaml.dump(lock_data))

        assert get_existing_version(lock_path) == "1.2.3"

    def test_get_version_no_build_section(self, tmp_path):
        """Test when lock file has no build section."""
        lock_data = {"other": "data"}
        lock_path = tmp_path / "hud.lock.yaml"
        lock_path.write_text(yaml.dump(lock_data))

        assert get_existing_version(lock_path) is None

    def test_get_version_no_file(self, tmp_path):
        """Test when lock file doesn't exist."""
        lock_path = tmp_path / "hud.lock.yaml"
        assert get_existing_version(lock_path) is None

    def test_get_version_invalid_yaml(self, tmp_path):
        """Test when lock file has invalid YAML."""
        lock_path = tmp_path / "hud.lock.yaml"
        lock_path.write_text("invalid: yaml: content:")
        assert get_existing_version(lock_path) is None


class TestGetDockerImageDigest:
    """Test getting Docker image digest."""

    @mock.patch("subprocess.run")
    def test_get_digest_success(self, mock_run):
        """Test successfully getting image digest."""
        # Note: The function expects to parse a list from the string representation
        mock_run.return_value = mock.Mock(
            stdout="['docker.io/library/test@sha256:abc123']", returncode=0
        )

        result = get_docker_image_digest("test:latest")
        assert result == "docker.io/library/test@sha256:abc123"

    @mock.patch("subprocess.run")
    def test_get_digest_empty(self, mock_run):
        """Test when docker returns empty digest list."""
        mock_run.return_value = mock.Mock(stdout="[]", returncode=0)

        result = get_docker_image_digest("test:latest")
        assert result is None

    @mock.patch("subprocess.run")
    def test_get_digest_failure(self, mock_run):
        """Test when docker command fails."""
        mock_run.side_effect = subprocess.CalledProcessError(1, ["docker"])

        result = get_docker_image_digest("test:latest")
        assert result is None


class TestGetDockerImageId:
    """Test getting Docker image ID."""

    @mock.patch("subprocess.run")
    def test_get_id_success(self, mock_run):
        """Test successfully getting image ID."""
        mock_run.return_value = mock.Mock(stdout="sha256:abc123def456", returncode=0)

        result = get_docker_image_id("test:latest")
        assert result == "sha256:abc123def456"

    @mock.patch("subprocess.run")
    def test_get_id_empty(self, mock_run):
        """Test when docker returns empty ID."""
        mock_run.return_value = mock.Mock(stdout="", returncode=0)

        result = get_docker_image_id("test:latest")
        assert result is None

    @mock.patch("subprocess.run")
    def test_get_id_failure(self, mock_run):
        """Test when docker command fails."""
        mock_run.side_effect = subprocess.CalledProcessError(1, ["docker"])

        result = get_docker_image_id("test:latest")
        assert result is None


class TestExtractEnvVarsFromDockerfile:
    """Test extracting environment variables from Dockerfile."""

    def test_extract_required_env_vars(self, tmp_path):
        """Test extracting required environment variables."""
        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("""
FROM python:3.11
ENV API_KEY
ENV SECRET_TOKEN=
ENV OTHER_VAR=default_value
""")

        required, optional = extract_env_vars_from_dockerfile(dockerfile)
        assert "API_KEY" in required
        assert "SECRET_TOKEN" in required
        assert "OTHER_VAR" not in required
        assert len(optional) == 0

    def test_extract_no_env_vars(self, tmp_path):
        """Test Dockerfile with no ENV directives."""
        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("""
FROM python:3.11
RUN pip install fastmcp
""")

        required, optional = extract_env_vars_from_dockerfile(dockerfile)
        assert len(required) == 0
        assert len(optional) == 0

    def test_extract_no_dockerfile(self, tmp_path):
        """Test when Dockerfile doesn't exist."""
        dockerfile = tmp_path / "Dockerfile"
        required, optional = extract_env_vars_from_dockerfile(dockerfile)
        assert len(required) == 0
        assert len(optional) == 0


@pytest.mark.asyncio
class TestAnalyzeMcpEnvironment:
    """Test analyzing MCP environment."""

    @mock.patch("hud.cli.utils.docker.detect_transport", return_value=("stdio", None))
    @mock.patch("hud.cli.utils.analysis.analyze_environment")
    @mock.patch("fastmcp.Client")
    async def test_analyze_success(self, mock_client_class, mock_mcp_analyze, _mock_detect):
        """Test successful environment analysis."""
        # Setup mock client
        mock_client = mock.MagicMock()
        mock_client.__aenter__ = mock.AsyncMock(return_value=mock_client)
        mock_client.is_connected = mock.MagicMock(return_value=True)
        mock_client.close = mock.AsyncMock()
        mock_client_class.return_value = mock_client

        # Mock analyze_environment return value
        mock_mcp_analyze.return_value = {
            "initializeMs": 123,
            "toolCount": 1,
            "internalToolCount": 0,
            "success": True,
            "metadata": {"servers": ["local"], "initialized": True},
            "tools": [{"name": "test_tool", "description": "Test tool"}],
            "hubTools": {},
            "prompts": [],
            "resources": [],
            "scenarios": [],
            "telemetry": {},
        }

        result = await analyze_mcp_environment("test:latest")

        assert result["success"] is True
        assert result["toolCount"] == 1
        assert len(result["tools"]) == 1
        assert result["tools"][0]["name"] == "test_tool"
        assert "initializeMs" in result

    @mock.patch("hud.cli.utils.docker.detect_transport", return_value=("stdio", None))
    @mock.patch("fastmcp.Client")
    async def test_analyze_failure(self, mock_client_class, _mock_detect):
        """Test failed environment analysis."""
        # Setup mock client to fail on __aenter__
        mock_client = mock.MagicMock()
        mock_client.__aenter__ = mock.AsyncMock(side_effect=ConnectionError("Connection failed"))
        mock_client.is_connected = mock.MagicMock(return_value=True)
        mock_client.close = mock.AsyncMock()
        mock_client_class.return_value = mock_client

        from hud.shared.exceptions import HudException

        with pytest.raises(HudException, match="Connection failed"):
            await analyze_mcp_environment("test:latest")

    @mock.patch("hud.cli.utils.docker.detect_transport", return_value=("stdio", None))
    @mock.patch("hud.cli.utils.analysis.analyze_environment")
    @mock.patch("fastmcp.Client")
    async def test_analyze_verbose_mode(self, mock_client_class, mock_mcp_analyze, _mock_detect):
        """Test analysis in verbose mode."""
        mock_client = mock.MagicMock()
        mock_client.__aenter__ = mock.AsyncMock(return_value=mock_client)
        mock_client.is_connected = mock.MagicMock(return_value=True)
        mock_client.close = mock.AsyncMock()
        mock_client_class.return_value = mock_client
        mock_mcp_analyze.return_value = {
            "initializeMs": 123,
            "toolCount": 0,
            "internalToolCount": 0,
            "success": True,
            "metadata": {"servers": ["local"], "initialized": True},
            "tools": [],
            "hubTools": {},
            "prompts": [],
            "resources": [],
            "scenarios": [],
            "telemetry": {},
        }

        # Just test that it runs without error in verbose mode
        result = await analyze_mcp_environment("test:latest", verbose=True)

        assert result["success"] is True
        assert "initializeMs" in result


class TestDetectTransport:
    """Test detect_transport auto-detection across all CMD shapes."""

    # --- proper exec form ---

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_exec_form_http(self, mock_get_cmd):
        mock_get_cmd.return_value = ["hud", "dev", "env:env", "--port", "8080"]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 8080

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_exec_form_http_default_port(self, mock_get_cmd):
        mock_get_cmd.return_value = ["hud", "dev", "env:env"]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 8765

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_exec_form_stdio(self, mock_get_cmd):
        mock_get_cmd.return_value = [
            "uv",
            "run",
            "python",
            "-m",
            "hud",
            "dev",
            "env:env",
            "--stdio",
        ]
        mode, port = detect_transport("img:latest")
        assert mode == "stdio"
        assert port is None

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_exec_form_short_port_flag(self, mock_get_cmd):
        mock_get_cmd.return_value = ["hud", "dev", "env:env", "-p", "3000"]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 3000

    # --- uv run python -m prefix ---

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_uv_run_python_m_http(self, mock_get_cmd):
        mock_get_cmd.return_value = ["uv", "run", "python", "-m", "hud", "dev", "env:env"]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 8765

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_uv_run_python_m_with_port(self, mock_get_cmd):
        mock_get_cmd.return_value = [
            "uv",
            "run",
            "python",
            "-m",
            "hud",
            "dev",
            "env:env",
            "--port",
            "9000",
        ]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 9000

    # --- sh -c shell wrapper ---

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_sh_c_http(self, mock_get_cmd):
        mock_get_cmd.return_value = ["sh", "-c", "hud dev env:env --port 8080"]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 8080

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_sh_c_stdio(self, mock_get_cmd):
        mock_get_cmd.return_value = ["sh", "-c", "hud dev env:env --stdio"]
        mode, port = detect_transport("img:latest")
        assert mode == "stdio"
        assert port is None

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_sh_c_default_port(self, mock_get_cmd):
        mock_get_cmd.return_value = ["sh", "-c", "hud dev env:env"]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 8765

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_bash_c_variant(self, mock_get_cmd):
        mock_get_cmd.return_value = ["/bin/bash", "-c", "hud dev env:env --port 4000"]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 4000

    # --- single-string exec form (Docker misuse but common) ---

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_single_string_http(self, mock_get_cmd):
        mock_get_cmd.return_value = ["hud dev env:env --port 8080"]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 8080

    # --- chained / multi-command shell ---

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_chained_and_operator(self, mock_get_cmd):
        mock_get_cmd.return_value = ["sh", "-c", "cd /app && hud dev env:env --port 8080"]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 8080

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_chained_semicolon(self, mock_get_cmd):
        mock_get_cmd.return_value = ["sh", "-c", "setup.sh; hud dev env:env"]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 8765

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_backgrounded_backend(self, mock_get_cmd):
        mock_get_cmd.return_value = ["sh", "-c", "python backend.py & hud dev env:env --port 8080"]
        mode, port = detect_transport("img:latest")
        assert mode == "http"
        assert port == 8080

    # --- fallback to stdio ---

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_stdio_when_no_cmd(self, mock_get_cmd):
        mock_get_cmd.return_value = None
        mode, port = detect_transport("img:latest")
        assert mode == "stdio"
        assert port is None

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_stdio_for_custom_entrypoint(self, mock_get_cmd):
        mock_get_cmd.return_value = ["python", "server.py"]
        mode, port = detect_transport("img:latest")
        assert mode == "stdio"
        assert port is None

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_stdio_for_empty_cmd(self, mock_get_cmd):
        mock_get_cmd.return_value = []
        mode, port = detect_transport("img:latest")
        assert mode == "stdio"
        assert port is None

    @mock.patch("hud.cli.utils.docker.get_docker_cmd")
    def test_stdio_dev_alone_without_hud(self, mock_get_cmd):
        """Bare 'dev' without preceding 'hud' should not trigger HTTP."""
        mock_get_cmd.return_value = ["python", "dev", "server.py"]
        mode, port = detect_transport("img:latest")
        assert mode == "stdio"
        assert port is None


@pytest.mark.asyncio
class TestAnalyzeMcpHttp:
    """Test HTTP-mode analysis in analyze_mcp_environment."""

    @mock.patch("hud.cli.utils.docker.stop_container")
    @mock.patch("hud.cli.utils.analysis.wait_for_http_server", new_callable=mock.AsyncMock)
    @mock.patch("subprocess.run")
    @mock.patch("hud.cli.utils.docker.detect_transport", return_value=("http", 8765))
    @mock.patch("hud.cli.utils.analysis.analyze_environment")
    @mock.patch("fastmcp.Client")
    async def test_http_analysis_success(
        self,
        mock_client_class,
        mock_mcp_analyze,
        _mock_detect,
        mock_subprocess,
        _mock_wait,
        _mock_stop,
    ):
        """HTTP path: runs detached container, connects via URL, cleans up."""
        mock_client = mock.MagicMock()
        mock_client.__aenter__ = mock.AsyncMock(return_value=mock_client)
        mock_client.is_connected = mock.MagicMock(return_value=True)
        mock_client.close = mock.AsyncMock()
        mock_client_class.return_value = mock_client

        mock_proc = mock.MagicMock()
        mock_proc.stdout = "abc123def456\n"
        mock_subprocess.return_value = mock_proc

        mock_mcp_analyze.return_value = {
            "initializeMs": 456,
            "toolCount": 1,
            "internalToolCount": 0,
            "success": True,
            "tools": [{"name": "tool1", "description": "A tool"}],
            "hubTools": {},
            "prompts": [],
            "resources": [],
            "scenarios": [],
        }

        result = await analyze_mcp_environment("http-img:latest")

        assert result["success"] is True
        assert result["toolCount"] == 1

        # Verify docker run was called with -d and port mapping
        docker_call = mock_subprocess.call_args
        cmd = docker_call.args[0] if docker_call.args else docker_call[0][0]
        assert "-d" in cmd
        assert "--rm" in cmd

        # Verify client was constructed with an HTTP URL transport
        transport_arg = (
            mock_client_class.call_args.kwargs.get("transport")
            or mock_client_class.call_args.args[0]
        )
        assert "hud" in transport_arg
        assert "localhost" in transport_arg["hud"]["url"]
        assert transport_arg["hud"]["auth"] is None

        # Cleanup was called
        _mock_stop.assert_called_once()

    @mock.patch("hud.cli.utils.docker.stop_container")
    @mock.patch("subprocess.run")
    @mock.patch("hud.cli.utils.docker.detect_transport", return_value=("http", 8765))
    async def test_http_container_start_failure(self, _mock_detect, mock_subprocess, _mock_stop):
        """HTTP path: failing to start the container raises HudException."""
        mock_subprocess.side_effect = subprocess.CalledProcessError(
            1, "docker run", stderr="image not found"
        )

        from hud.shared.exceptions import HudException

        with pytest.raises(HudException, match="Failed to start Docker container"):
            await analyze_mcp_environment("bad-img:latest")

        _mock_stop.assert_called_once()

    @mock.patch("hud.cli.utils.docker.stop_container")
    @mock.patch("hud.cli.utils.analysis.wait_for_http_server", new_callable=mock.AsyncMock)
    @mock.patch("subprocess.run")
    @mock.patch("hud.cli.utils.docker.detect_transport", return_value=("http", 8765))
    async def test_http_server_timeout(self, _mock_detect, mock_subprocess, mock_wait, _mock_stop):
        """HTTP path: server not becoming ready raises HudException."""
        mock_proc = mock.MagicMock()
        mock_proc.stdout = "abc123\n"
        mock_subprocess.return_value = mock_proc
        mock_wait.side_effect = TimeoutError("not ready")

        from hud.shared.exceptions import HudException

        with pytest.raises(HudException, match="readiness timeout"):
            await analyze_mcp_environment("slow-img:latest")

        _mock_stop.assert_called_once()


class TestStopContainer:
    """Test stop_container helper."""

    @mock.patch("hud.cli.utils.docker.subprocess.run")
    def test_calls_stop_then_rm(self, mock_run):
        stop_container("my-container")
        assert mock_run.call_count == 2
        calls = [c.args[0] for c in mock_run.call_args_list]
        assert calls[0] == ["docker", "stop", "my-container"]
        assert calls[1] == ["docker", "rm", "-f", "my-container"]

    @mock.patch("hud.cli.utils.docker.subprocess.run", side_effect=Exception("docker not found"))
    def test_suppresses_errors(self, mock_run):
        stop_container("my-container")


class TestBuildDockerImage:
    """Test building Docker images."""

    @mock.patch("subprocess.run")
    def test_build_success(self, mock_run, tmp_path):
        """Test successful Docker build."""
        # Create Dockerfile
        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("FROM python:3.11")

        # Mock successful process
        mock_result = mock.Mock()
        mock_result.returncode = 0
        mock_run.return_value = mock_result

        result = build_docker_image(tmp_path, "test:latest")
        assert result is True
        call_args = mock_run.call_args[0][0]
        assert call_args[:3] == ["docker", "buildx", "build"]
        assert "--load" in call_args

    @mock.patch("subprocess.run")
    def test_build_failure(self, mock_run, tmp_path):
        """Test failed Docker build."""
        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("FROM python:3.11")

        # Mock failed process
        mock_result = mock.Mock()
        mock_result.returncode = 1
        mock_run.return_value = mock_result

        result = build_docker_image(tmp_path, "test:latest")
        assert result is False

    def test_build_no_dockerfile(self, tmp_path):
        """Test build when Dockerfile missing."""
        result = build_docker_image(tmp_path, "test:latest")
        assert result is False

    @mock.patch("subprocess.run")
    def test_build_with_no_cache(self, mock_run, tmp_path):
        """Test build with --no-cache flag."""
        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("FROM python:3.11")

        mock_result = mock.Mock()
        mock_result.returncode = 0
        mock_run.return_value = mock_result

        build_docker_image(tmp_path, "test:latest", no_cache=True)

        # Check that --no-cache was included
        call_args = mock_run.call_args[0][0]
        assert "--no-cache" in call_args

    @mock.patch("subprocess.run")
    def test_build_with_push_does_not_add_load(self, mock_run, tmp_path):
        """Pushed builds should stay on the push output mode."""
        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("FROM python:3.11")

        mock_result = mock.Mock()
        mock_result.returncode = 0
        mock_run.return_value = mock_result

        build_docker_image(tmp_path, "registry.example/test:latest", docker_args=["--push"])

        call_args = mock_run.call_args[0][0]
        assert call_args[:3] == ["docker", "buildx", "build"]
        assert "--push" in call_args
        assert "--load" not in call_args

    @mock.patch("subprocess.run")
    def test_build_with_explicit_output_does_not_add_load(self, mock_run, tmp_path):
        """Explicit buildx outputs should not be combined with auto --load."""
        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("FROM python:3.11")

        mock_result = mock.Mock()
        mock_result.returncode = 0
        mock_run.return_value = mock_result

        build_docker_image(
            tmp_path,
            "test:latest",
            docker_args=["--output", "type=oci,dest=out.tar"],
        )

        call_args = mock_run.call_args[0][0]
        assert call_args[:3] == ["docker", "buildx", "build"]
        assert "--output" in call_args
        assert "--load" not in call_args


class TestBuildEnvironment:
    """Test the main build_environment function."""

    @mock.patch("hud.cli.build.build_docker_image")
    @mock.patch("hud.cli.build.analyze_mcp_environment")
    @mock.patch("hud.cli.build.get_docker_image_id")
    @mock.patch("subprocess.run")
    def test_build_environment_success(
        self,
        mock_run,
        mock_get_id,
        mock_analyze,
        mock_build_docker,
        tmp_path,
    ):
        """Test successful environment build."""
        # Setup directory structure
        env_dir = tmp_path / "test-env"
        env_dir.mkdir()

        # Create pyproject.toml
        pyproject = env_dir / "pyproject.toml"
        pyproject.write_text("""
[tool.hud]
image = "test/env:dev"
""")

        # Create Dockerfile
        dockerfile = env_dir / "Dockerfile"
        dockerfile.write_text("""
FROM python:3.11
ENV API_KEY
""")

        # Mock functions
        mock_build_docker.return_value = True
        mock_analyze.return_value = {
            "success": True,
            "toolCount": 2,
            "initializeMs": 1500,
            "tools": [
                {"name": "tool1", "description": "Tool 1"},
                {"name": "tool2", "description": "Tool 2"},
            ],
        }
        mock_get_id.return_value = "sha256:abc123"

        # Mock final rebuild
        mock_result = mock.Mock()
        mock_result.returncode = 0
        mock_run.return_value = mock_result

        # Run build
        build_environment(str(env_dir), "test-env:latest")

        # Check lock file was created
        lock_file = env_dir / "hud.lock.yaml"
        assert lock_file.exists()

        # Verify lock file content
        with open(lock_file) as f:
            lock_data = yaml.safe_load(f)

        # Lock file format version
        assert lock_data["version"] == "1.3"

        assert lock_data["images"]["full"] == "test-env:0.1.0@sha256:abc123"
        assert lock_data["images"]["local"] == "test-env:0.1.0"
        assert lock_data["build"]["version"] == "0.1.0"
        assert lock_data["build"]["baseImage"] == "python:3.11"
        assert lock_data["build"]["platform"] == "linux/amd64"
        assert lock_data["environment"]["toolCount"] == 2
        assert "runtime" not in lock_data["environment"]
        assert len(lock_data["tools"]) == 2

    @mock.patch("hud.cli.build.build_docker_image")
    @mock.patch("hud.cli.build.analyze_mcp_environment")
    @mock.patch("hud.cli.build.get_docker_image_id")
    @mock.patch("subprocess.run")
    def test_build_environment_internal_tools(
        self,
        mock_run,
        mock_get_id,
        mock_analyze,
        mock_build_docker,
        tmp_path,
    ):
        """Dispatcher tools should include internalTools in lock, with count."""
        env_dir = tmp_path / "env-int"
        env_dir.mkdir()
        (env_dir / "pyproject.toml").write_text("""
[tool.hud]
image = "test/env:dev"
""")
        dockerfile = env_dir / "Dockerfile"
        dockerfile.write_text("""
FROM python:3.11
""")

        mock_build_docker.return_value = True
        mock_analyze.return_value = {
            "success": True,
            "toolCount": 1,
            "internalToolCount": 2,
            "initializeMs": 500,
            "tools": [
                {
                    "name": "setup",
                    "description": "setup dispatcher",
                    "inputSchema": {"type": "object"},
                    "internalTools": ["board", "seed"],
                }
            ],
        }
        mock_get_id.return_value = "sha256:fff111"

        mock_result = mock.Mock()
        mock_result.returncode = 0
        mock_run.return_value = mock_result

        build_environment(str(env_dir), "env-int:latest")

        lock_file = env_dir / "hud.lock.yaml"
        with open(lock_file) as f:
            data = yaml.safe_load(f)
        assert data["version"] == "1.3"
        assert data["environment"]["internalToolCount"] == 2
        assert data["tools"][0]["name"] == "setup"
        assert data["tools"][0]["internalTools"] == ["board", "seed"]

    def test_build_environment_no_directory(self):
        """Test build when directory doesn't exist."""
        with pytest.raises(typer.Exit):
            build_environment("/nonexistent/path")

    def test_build_environment_no_pyproject(self, tmp_path):
        """Test build when pyproject.toml missing."""
        with pytest.raises(typer.Exit):
            build_environment(str(tmp_path))

    @mock.patch("hud.cli.build.build_docker_image")
    def test_build_environment_docker_failure(self, mock_build, tmp_path):
        """Test when Docker build fails."""
        env_dir = tmp_path / "test-env"
        env_dir.mkdir()
        (env_dir / "pyproject.toml").write_text("[tool.hud]")
        (env_dir / "Dockerfile").write_text("FROM python:3.11")

        mock_build.return_value = False

        with pytest.raises(typer.Exit):
            build_environment(str(env_dir))
