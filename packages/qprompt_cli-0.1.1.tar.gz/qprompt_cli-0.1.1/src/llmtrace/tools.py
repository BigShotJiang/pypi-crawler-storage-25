from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class ToolRunResult:
    value: Any
    output_summary: str


class ToolTracer:
    def __init__(self, trace: dict[str, Any]) -> None:
        self.trace = trace

    def log_tool_call(
        self,
        tool: str,
        tool_input: Any,
        output_summary: str,
        status: str = "ok",
        error: str | None = None,
    ) -> None:
        step = {
            "type": "tool_call",
            "tool": tool,
            "input": tool_input,
            "output_summary": output_summary,
            "status": status,
        }
        if error:
            step["error"] = error
        self.trace.setdefault("steps", []).append(step)


def redact_value(value: Any, max_len: int = 500) -> str:
    text = str(value)
    if len(text) > max_len:
        return text[:max_len] + "... [truncated]"
    return text


def traced_tool(name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            tracer: ToolTracer | None = kwargs.pop("_tool_tracer", None)
            redacted_input = {
                "args": [redact_value(a) for a in args],
                "kwargs": {k: redact_value(v) for k, v in kwargs.items()},
            }
            try:
                value = func(*args, **kwargs)
                if isinstance(value, ToolRunResult):
                    summary = value.output_summary
                    real_value = value.value
                else:
                    summary = f"completed, type={type(value).__name__}"
                    real_value = value

                if tracer:
                    tracer.log_tool_call(name, redacted_input, summary, status="ok")
                return real_value
            except Exception as exc:  # pragma: no cover - passthrough + log
                if tracer:
                    tracer.log_tool_call(name, redacted_input, "failed", status="error", error=str(exc))
                raise

        return wrapper

    return decorator
