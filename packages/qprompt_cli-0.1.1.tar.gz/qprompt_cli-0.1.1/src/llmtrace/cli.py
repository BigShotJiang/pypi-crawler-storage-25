from __future__ import annotations

import argparse
import difflib
import json

from .storage import TraceStorage
from .tracer import Tracer


def _cmd_run(args: argparse.Namespace) -> int:
    tracer = Tracer(model=args.model)
    trace, path = tracer.run(args.question, include_demo_sql=not args.no_demo_sql)

    print(f"Saved trace: {path}")
    print(f"Trace ID: {trace['trace_id']}")
    print("\nParsed as:")
    print(f"- Intent: {trace['parsed']['intent']}")
    entities = trace["parsed"].get("entities", {})
    for k, v in entities.items():
        print(f"- {k}: {v}")
    for a in trace["parsed"].get("assumptions", []):
        print(f"- Assumption: {a}")

    tool_steps = [s for s in trace.get("steps", []) if s.get("type") == "tool_call"]
    if tool_steps:
        print("\nTools used:")
        for i, step in enumerate(tool_steps, start=1):
            print(f"{i}. {step['tool']} ({step['output_summary']})")

    if trace.get("evidence"):
        print("\nEvidence:")
        for item in trace["evidence"]:
            print(f"- {item.get('claim', 'n/a')}")

    if trace.get("risks"):
        print("\nRisks:")
        for risk in trace["risks"]:
            print(f"- {risk}")

    return 0


def _cmd_show(args: argparse.Namespace) -> int:
    storage = TraceStorage()
    trace = storage.load_trace(args.trace)
    print(json.dumps(trace, indent=2))
    return 0


def _cmd_list(args: argparse.Namespace) -> int:
    storage = TraceStorage()
    files = storage.list_trace_paths(limit=args.limit)
    if not files:
        print("No traces found.")
        return 0

    for p in files:
        print(str(p))
    return 0


def _cmd_diff(args: argparse.Namespace) -> int:
    storage = TraceStorage()
    a = storage.load_trace(args.trace_a)
    b = storage.load_trace(args.trace_b)

    text_a = json.dumps(a, indent=2).splitlines()
    text_b = json.dumps(b, indent=2).splitlines()

    diff = difflib.unified_diff(
        text_a,
        text_b,
        fromfile=args.trace_a,
        tofile=args.trace_b,
        lineterm="",
    )

    print("\n".join(diff))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="qprompt", description="LLM tracing CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    run_p = sub.add_parser("run", help="Run a traced question")
    run_p.add_argument("question", type=str)
    run_p.add_argument("--model", default="mock-gpt")
    run_p.add_argument("--no-demo-sql", action="store_true", help="Disable demo SQL tool call")
    run_p.set_defaults(func=_cmd_run)

    show_p = sub.add_parser("show", help="Show a trace JSON")
    show_p.add_argument("trace", type=str, help="Trace ID or path")
    show_p.set_defaults(func=_cmd_show)

    list_p = sub.add_parser("list", help="List traces")
    list_p.add_argument("--limit", type=int, default=20)
    list_p.set_defaults(func=_cmd_list)

    diff_p = sub.add_parser("diff", help="Diff two traces")
    diff_p.add_argument("trace_a", type=str)
    diff_p.add_argument("trace_b", type=str)
    diff_p.set_defaults(func=_cmd_diff)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
