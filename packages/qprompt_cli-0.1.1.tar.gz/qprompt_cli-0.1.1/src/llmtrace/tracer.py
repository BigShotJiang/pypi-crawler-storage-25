from __future__ import annotations

import re
from time import perf_counter
from typing import Any

from .audit import run_answer_audit
from .schema import add_step, new_trace, validate_trace
from .storage import TraceStorage
from .tools import ToolTracer, traced_tool, ToolRunResult


@traced_tool("sql")
def _demo_sql(query: str) -> ToolRunResult:
    rows = [
        {"segment": "enterprise", "month": "March", "revenue_change_pct": -18},
        {"segment": "mid_market", "month": "March", "revenue_change_pct": -6},
    ]
    return ToolRunResult(value=rows, output_summary=f"returned {len(rows)} rows")


class Tracer:
    def __init__(self, storage: TraceStorage | None = None, model: str = "mock-gpt") -> None:
        self.storage = storage or TraceStorage()
        self.model = model

    def parse_question(self, question: str) -> dict[str, Any]:
        q = question.lower()
        intent = "general_qa"
        entities: dict[str, Any] = {}
        assumptions: list[str] = []
        missing_context: list[str] = []
        suggested_tools: list[str] = []

        if "revenue" in q or "sales" in q:
            intent = "metric_explanation"
            entities["metric"] = "revenue" if "revenue" in q else "sales"
            suggested_tools.append("sql")

        month_names = [
            "january",
            "february",
            "march",
            "april",
            "may",
            "june",
            "july",
            "august",
            "september",
            "october",
            "november",
            "december",
        ]
        month_pattern = r"\b(" + "|".join(month_names) + r")\b"
        months_found = [m.group(1) for m in re.finditer(month_pattern, q)]
        months_unique_in_order: list[str] = []
        for month in months_found:
            if month not in months_unique_in_order:
                months_unique_in_order.append(month)
        months_title = [m.title() for m in months_unique_in_order]

        if len(months_title) >= 2:
            entities["period"] = f"{months_title[0]} vs {months_title[1]}"
        elif len(months_title) == 1:
            entities["period"] = months_title[0]
            assumptions.append(f"Compare {months_title[0]} to previous month")

        if "region" not in q:
            missing_context.append("No region specified")

        return {
            "intent": intent,
            "entities": entities,
            "assumptions": assumptions,
            "missing_context": missing_context,
            "suggested_tools": suggested_tools,
        }

    def _mock_answer(self, question: str, parsed: dict[str, Any], sql_rows: list[dict[str, Any]] | None) -> str:
        if parsed.get("intent") == "metric_explanation" and sql_rows:
            return (
                "Revenue dropped mainly in enterprise (about 18% down in March), "
                "with smaller declines in other segments."
            )
        return f"Parsed question: {question}. No tool data was required for this answer."

    def chat(
        self,
        *,
        messages: list[dict[str, str]],
        llm_callable: Any,
        trace: dict[str, Any],
        tools: list[dict[str, Any]] | None = None,
    ) -> str:
        add_step(
            trace,
            {
                "type": "request_sent",
                "messages": messages,
                "tools_available": tools or [],
                "model": self.model,
            },
        )

        t0 = perf_counter()
        response = llm_callable(messages=messages, tools=tools or [])
        elapsed_ms = int((perf_counter() - t0) * 1000)

        answer = str(response.get("text", ""))
        usage = response.get("usage", {})
        add_step(
            trace,
            {
                "type": "model_response",
                "latency_ms": elapsed_ms,
                "tokens": {
                    "input_estimate": int(usage.get("input_tokens", max(1, len(" ".join(m["content"] for m in messages).split())))),
                    "output_estimate": int(usage.get("output_tokens", max(1, len(answer.split())))),
                },
            },
        )
        return answer

    def run(self, question: str, include_demo_sql: bool = True) -> tuple[dict[str, Any], str]:
        trace = new_trace(question=question, model=self.model)

        add_step(
            trace,
            {
                "type": "input_received",
                "question": question,
            },
        )

        t0 = perf_counter()
        parsed = self.parse_question(question)
        parse_ms = int((perf_counter() - t0) * 1000)
        trace["parsed"] = parsed
        add_step(
            trace,
            {
                "type": "question_parser",
                "output": parsed,
                "latency_ms": parse_ms,
            },
        )

        sql_rows: list[dict[str, Any]] | None = None
        if include_demo_sql and "sql" in parsed.get("suggested_tools", []):
            tool_tracer = ToolTracer(trace)
            sql_rows = _demo_sql(
                "SELECT month, segment, revenue_change_pct FROM revenue_by_segment WHERE month='March'",
                _tool_tracer=tool_tracer,
            )
            if sql_rows:
                trace.setdefault("evidence", []).append(
                    {
                        "source": "query_result",
                        "claim": "Enterprise revenue dropped 18%",
                        "evidence_id": "query_result_enterprise_drop",
                    }
                )

        def _mock_llm(*, messages: list[dict[str, str]], tools: list[dict[str, Any]]) -> dict[str, Any]:
            _ = tools
            text = self._mock_answer(question, parsed, sql_rows)
            return {
                "text": text,
                "usage": {
                    "input_tokens": max(1, len(" ".join(m["content"] for m in messages).split())),
                    "output_tokens": max(1, len(text.split())),
                },
            }

        messages = [
            {"role": "system", "content": "You are a concise analytics assistant."},
            {"role": "user", "content": question},
        ]
        tools = [{"name": "sql", "description": "Query analytical warehouse"}] if include_demo_sql else []
        answer = self.chat(messages=messages, llm_callable=_mock_llm, trace=trace, tools=tools)
        trace["final_answer"] = answer

        audit = run_answer_audit(trace)
        add_step(trace, {"type": "answer_audit", "output": audit})
        trace["risks"] = audit.get("risk_flags", [])

        ok, errors = validate_trace(trace)
        if not ok:
            raise ValueError(f"Trace validation failed: {errors}")

        path = self.storage.save_trace(trace)
        return trace, str(path)
