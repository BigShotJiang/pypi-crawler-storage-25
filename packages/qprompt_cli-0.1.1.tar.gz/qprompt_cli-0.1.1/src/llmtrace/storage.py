from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any


class TraceStorage:
    def __init__(self, root: str = ".traces") -> None:
        self.root = Path(root)

    def save_trace(self, trace: dict[str, Any]) -> Path:
        day = datetime.utcnow().strftime("%Y-%m-%d")
        out_dir = self.root / day
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"trace_{trace['trace_id']}.json"
        path.write_text(json.dumps(trace, indent=2), encoding="utf-8")
        return path

    def load_trace(self, trace_id_or_path: str) -> dict[str, Any]:
        candidate = Path(trace_id_or_path)
        if candidate.exists():
            return json.loads(candidate.read_text(encoding="utf-8"))

        normalized = trace_id_or_path
        if normalized.startswith("trace_"):
            normalized = normalized[len("trace_") :]
        if normalized.endswith(".json"):
            normalized = normalized[:-5]

        matches = list(self.root.glob(f"**/trace_{normalized}.json"))
        if not matches:
            raise FileNotFoundError(f"Trace not found: {trace_id_or_path}")

        return json.loads(matches[0].read_text(encoding="utf-8"))

    def list_trace_paths(self, limit: int = 50) -> list[Path]:
        if not self.root.exists():
            return []
        files = sorted(self.root.glob("**/trace_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        return files[:limit]
