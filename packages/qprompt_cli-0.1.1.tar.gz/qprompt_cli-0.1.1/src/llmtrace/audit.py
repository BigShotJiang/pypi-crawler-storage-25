from __future__ import annotations

from typing import Any


def _truncate(text: str, max_len: int = 180) -> str:
    if len(text) <= max_len:
        return text
    return text[:max_len] + "... [truncated]"


def run_answer_audit(trace: dict[str, Any]) -> dict[str, Any]:
    final_answer = trace.get("final_answer", "")
    evidence = trace.get("evidence", [])
    parsed = trace.get("parsed", {})

    claims: list[dict[str, Any]] = []
    unsupported: list[str] = []

    if "enterprise" in final_answer.lower():
        claims.append(
            {
                "claim": "Enterprise segment is a key driver",
                "evidence": "query_result_enterprise_drop",
                "confidence": "medium",
            }
        )

    if not evidence and final_answer:
        unsupported.append("Answer contains claims but no attached evidence records")

    risk_flags: list[str] = []
    if parsed.get("missing_context"):
        risk_flags.extend([f"Missing context: {x}" for x in parsed["missing_context"]])

    steps = trace.get("steps", [])
    failed_tool_steps = [s for s in steps if s.get("type") == "tool_call" and s.get("status") == "error"]
    for step in failed_tool_steps:
        tool_name = step.get("tool", "unknown_tool")
        error_text = _truncate(str(step.get("error", "unknown error")))
        risk_flags.append(f"Tool call failed ({tool_name}): {error_text}")

    return {
        "claims": claims,
        "unsupported_claims": unsupported,
        "assumptions_used": parsed.get("assumptions", []),
        "risk_flags": risk_flags,
    }
