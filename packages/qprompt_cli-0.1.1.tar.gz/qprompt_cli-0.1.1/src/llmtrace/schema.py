from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from uuid import uuid4


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_trace(question: str, model: str) -> dict[str, Any]:
    return {
        "trace_id": str(uuid4()),
        "question": question,
        "timestamp": utc_now_iso(),
        "model": model,
        "parsed": {
            "intent": "unknown",
            "entities": {},
            "assumptions": [],
            "missing_context": [],
            "suggested_tools": [],
        },
        "steps": [],
        "evidence": [],
        "final_answer": "",
        "risks": [],
    }


def add_step(trace: dict[str, Any], step: dict[str, Any]) -> None:
    steps = trace.setdefault("steps", [])
    steps.append(step)


def validate_trace(trace: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []

    required_top = [
        "trace_id",
        "question",
        "timestamp",
        "model",
        "parsed",
        "steps",
        "evidence",
        "final_answer",
        "risks",
    ]
    for key in required_top:
        if key not in trace:
            errors.append(f"missing top-level field: {key}")

    parsed = trace.get("parsed", {})
    for key in ["intent", "entities", "assumptions"]:
        if key not in parsed:
            errors.append(f"missing parsed field: {key}")

    return (len(errors) == 0, errors)
