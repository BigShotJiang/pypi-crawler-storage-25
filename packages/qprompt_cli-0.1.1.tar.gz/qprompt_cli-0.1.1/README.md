# qprompt-cli

Flight recorder for LLM apps: capture how a question was parsed, what tools were called, what evidence was used, and what risks remain.

## What this tracks

- `question`, `model`, timestamp, `trace_id`
- parser output (`intent`, `entities`, assumptions)
- request envelope (`messages`, tools available)
- tool calls (name, redacted input, output summary, status/error)
- response metrics (latency, token estimates)
- evidence and answer audit risk flags

## What this does not track

- Hidden internal chain-of-thought for hosted closed models
- Neuron-level/attention internals from provider backends

## Install (local)

```bash
python -m pip install -e .
```

Python import:

```python
from qprompt import Tracer
```

## CLI

```bash
qprompt run "why did revenue drop in March?"
qprompt list
qprompt show <trace_id_or_path>
qprompt diff <trace_a> <trace_b>
```

Traces are saved under:

```text
.traces/YYYY-MM-DD/trace_<uuid>.json
```

## Schema

- JSON schema file: `src/llmtrace/trace_schema.json`
- Runtime trace builder/validator: `src/llmtrace/schema.py`

## Example output (run)

- Parsed intent and entities
- Tools used and summaries
- Evidence list
- Risk flags

## Next integration step

Replace the mock callable in `Tracer.chat(...)` with your real model provider call and preserve returned `usage` token fields.
