"""
SubscribeFlow Python SDK

A type-safe async client for the SubscribeFlow API.

Example:
    >>> from subscribeflow import SubscribeFlowClient
    >>>
    >>> async with SubscribeFlowClient(api_key="sf_live_xxx") as client:
    ...     # Create or get existing tag
    ...     tag, _ = await client.tags.get_or_create(name="newsletter")
    ...
    ...     # Create or get existing subscriber
    ...     subscriber, created = await client.subscribers.get_or_create(
    ...         email="user@example.com",
    ...         tags=[str(tag.id)],
    ...     )
    ...     print(f"{'Created' if created else 'Found'}: {subscriber.id}")
"""

from subscribeflow.client import SubscribeFlowClient
from subscribeflow.exceptions import (
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    LimitExceededError,
    NotFoundError,
    RateLimitError,
    SubscribeFlowError,
    ValidationError,
)
from subscribeflow.models import (
    Campaign,
    CheckoutSession,
    EmailSendResponse,
    EmailTemplate,
    EmailTrigger,
    PaginatedResponse,
    PortalSession,
    Subscriber,
    SubscriptionInfo,
    SyncResult,
    Tag,
    WebhookDelivery,
    WebhookDeliveryDetail,
    WebhookDeliveryStats,
    WebhookEndpoint,
)

__version__ = "0.1.0"

__all__ = [
    # Client
    "SubscribeFlowClient",
    # Exceptions
    "SubscribeFlowError",
    "AuthenticationError",
    "AuthorizationError",
    "LimitExceededError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "RateLimitError",
    # Models
    "Subscriber",
    "Tag",
    "WebhookEndpoint",
    "WebhookDelivery",
    "WebhookDeliveryDetail",
    "WebhookDeliveryStats",
    "EmailTemplate",
    "EmailTrigger",
    "EmailSendResponse",
    "Campaign",
    "PaginatedResponse",
    "SubscriptionInfo",
    "CheckoutSession",
    "PortalSession",
    "SyncResult",
]
