"""Exception classes for SubscribeFlow SDK."""

from typing import Any


class SubscribeFlowError(Exception):
    """Base exception for SubscribeFlow SDK errors.

    Attributes:
        status: HTTP status code
        type: Error type URI
        title: Short error title
        detail: Detailed error message
        instance: Request path that caused the error
        errors: Validation errors (for 422 responses)
    """

    def __init__(
        self,
        message: str,
        *,
        status: int = 500,
        type: str = "https://subscribeflow.net/errors/unknown",
        title: str = "Unknown Error",
        detail: str | None = None,
        instance: str | None = None,
        errors: list[dict[str, Any]] | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.type = type
        self.title = title
        self.detail = detail or message
        self.instance = instance
        self.errors = errors or []

    @classmethod
    def from_response(cls, data: dict[str, Any], status: int) -> "SubscribeFlowError":
        """Create an exception from an API error response.

        Args:
            data: Response JSON data (RFC 7807 format)
            status: HTTP status code

        Returns:
            Appropriate exception instance based on status code
        """
        # 402 has extra fields (limit, current, max, upgrade_url)
        if status == 402:
            return LimitExceededError.from_limit_response(data)

        error_class = _STATUS_TO_EXCEPTION.get(status, cls)
        return error_class(
            message=data.get("detail", "An error occurred"),
            status=status,
            type=data.get("type", ""),
            title=data.get("title", "Error"),
            detail=data.get("detail"),
            instance=data.get("instance"),
            errors=data.get("errors"),
        )


class AuthenticationError(SubscribeFlowError):
    """Raised when authentication fails (401)."""

    pass


class AuthorizationError(SubscribeFlowError):
    """Raised when access is denied (403)."""

    pass


class NotFoundError(SubscribeFlowError):
    """Raised when a resource is not found (404)."""

    pass


class ConflictError(SubscribeFlowError):
    """Raised when there's a resource conflict (409)."""

    pass


class ValidationError(SubscribeFlowError):
    """Raised when request validation fails (422).

    The `errors` attribute contains detailed validation errors.
    """

    pass


class LimitExceededError(SubscribeFlowError):
    """Raised when a plan limit is exceeded (402).

    Attributes:
        limit: Which limit was exceeded (e.g. 'subscribers', 'emails')
        current: Current usage count
        max_value: Maximum allowed by the current plan
        upgrade_url: URL to upgrade the plan
    """

    def __init__(
        self,
        message: str,
        *,
        status: int = 402,
        type: str = "https://subscribeflow.net/errors/limit_exceeded",
        title: str = "Plan Limit Exceeded",
        detail: str | None = None,
        instance: str | None = None,
        errors: list[dict[str, Any]] | None = None,
        limit: str = "",
        current: int = 0,
        max_value: int = 0,
        upgrade_url: str = "",
    ) -> None:
        super().__init__(
            message,
            status=status,
            type=type,
            title=title,
            detail=detail,
            instance=instance,
            errors=errors,
        )
        self.limit = limit
        self.current = current
        self.max_value = max_value
        self.upgrade_url = upgrade_url

    @classmethod
    def from_limit_response(cls, data: dict[str, Any]) -> "LimitExceededError":
        """Create from a 402 limit-exceeded API response."""
        return cls(
            message=data.get("detail", "Plan limit exceeded"),
            detail=data.get("detail"),
            type=data.get("type", "https://subscribeflow.net/errors/limit_exceeded"),
            title=data.get("title", "Plan Limit Exceeded"),
            instance=data.get("instance"),
            limit=data.get("limit", ""),
            current=data.get("current", 0),
            max_value=data.get("max", 0),
            upgrade_url=data.get("upgrade_url", ""),
        )


class RateLimitError(SubscribeFlowError):
    """Raised when rate limit is exceeded (429)."""

    pass


# Map status codes to exception classes
_STATUS_TO_EXCEPTION: dict[int, type[SubscribeFlowError]] = {
    401: AuthenticationError,
    402: LimitExceededError,
    403: AuthorizationError,
    404: NotFoundError,
    409: ConflictError,
    422: ValidationError,
    429: RateLimitError,
}
