"""MCP Tool definitions for SubscribeFlow.

This module defines all available tools that can be called by LLM agents.
"""

from mcp.types import Tool

# Tool definitions organized by resource type

SUBSCRIBER_TOOLS = [
    Tool(
        name="list_subscribers",
        description="List all subscribers with optional filtering by status or tag",
        inputSchema={
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["active", "unsubscribed", "bounced", "complained"],
                    "description": "Filter by subscription status",
                },
                "tag": {
                    "type": "string",
                    "description": "Filter by tag ID (UUID)",
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 100,
                    "default": 50,
                    "description": "Maximum number of results to return",
                },
            },
        },
    ),
    Tool(
        name="get_subscriber",
        description="Get a subscriber by their ID",
        inputSchema={
            "type": "object",
            "properties": {
                "subscriber_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Subscriber UUID",
                },
            },
            "required": ["subscriber_id"],
        },
    ),
    Tool(
        name="get_subscriber_by_email",
        description="Get a subscriber by their email address",
        inputSchema={
            "type": "object",
            "properties": {
                "email": {
                    "type": "string",
                    "format": "email",
                    "description": "Subscriber email address",
                },
            },
            "required": ["email"],
        },
    ),
    Tool(
        name="create_subscriber",
        description="Create a new newsletter subscriber with optional tags and metadata",
        inputSchema={
            "type": "object",
            "properties": {
                "email": {
                    "type": "string",
                    "format": "email",
                    "description": "Subscriber email address",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of tag IDs (UUIDs) or tag names to subscribe to",
                },
                "metadata": {
                    "type": "object",
                    "description": "Custom metadata key-value pairs",
                },
            },
            "required": ["email"],
        },
    ),
    Tool(
        name="get_or_create_subscriber",
        description=(
            "Get an existing subscriber by email or create a new one if not found. "
            "This is idempotent - safe to call multiple times with the same email."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "email": {
                    "type": "string",
                    "format": "email",
                    "description": "Subscriber email address",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of tag IDs or names (only used if creating)",
                },
                "metadata": {
                    "type": "object",
                    "description": "Custom metadata (only used if creating)",
                },
            },
            "required": ["email"],
        },
    ),
    Tool(
        name="update_subscriber",
        description="Update a subscriber's metadata or status",
        inputSchema={
            "type": "object",
            "properties": {
                "subscriber_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Subscriber UUID",
                },
                "metadata": {
                    "type": "object",
                    "description": "Custom metadata to update (merged with existing)",
                },
                "status": {
                    "type": "string",
                    "enum": ["active", "unsubscribed"],
                    "description": "New subscription status",
                },
            },
            "required": ["subscriber_id"],
        },
    ),
    Tool(
        name="delete_subscriber",
        description="Permanently delete a subscriber. This action cannot be undone.",
        inputSchema={
            "type": "object",
            "properties": {
                "subscriber_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Subscriber UUID to delete",
                },
            },
            "required": ["subscriber_id"],
        },
    ),
    Tool(
        name="generate_preference_token",
        description=(
            "Generate a secure token for accessing the Preference Center. "
            "The token is valid for 7 days by default."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "subscriber_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Subscriber UUID",
                },
            },
            "required": ["subscriber_id"],
        },
    ),
    Tool(
        name="add_subscriber_tags",
        description="Add one or more tags to an existing subscriber. Requires tag UUIDs.",
        inputSchema={
            "type": "object",
            "properties": {
                "subscriber_id": {
                    "type": "string",
                    "description": "UUID of the subscriber",
                },
                "tag_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                    "description": "List of tag UUIDs to add (at least one required)",
                },
            },
            "required": ["subscriber_id", "tag_ids"],
        },
    ),
    Tool(
        name="remove_subscriber_tag",
        description="Remove a tag from a subscriber.",
        inputSchema={
            "type": "object",
            "properties": {
                "subscriber_id": {
                    "type": "string",
                    "description": "UUID of the subscriber",
                },
                "tag_id": {
                    "type": "string",
                    "description": "UUID of the tag to remove",
                },
            },
            "required": ["subscriber_id", "tag_id"],
        },
    ),
]

TAG_TOOLS = [
    Tool(
        name="list_tags",
        description="List all available subscription tags/topics",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 100,
                    "default": 50,
                    "description": "Maximum number of results to return",
                },
            },
        },
    ),
    Tool(
        name="get_tag",
        description="Get a tag by its ID",
        inputSchema={
            "type": "object",
            "properties": {
                "tag_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Tag UUID",
                },
            },
            "required": ["tag_id"],
        },
    ),
    Tool(
        name="get_tag_by_name",
        description="Get a tag by its unique name",
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Tag name (case-sensitive)",
                },
            },
            "required": ["name"],
        },
    ),
    Tool(
        name="create_tag",
        description="Create a new subscription tag/topic",
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Tag display name (must be unique)",
                },
                "description": {
                    "type": "string",
                    "description": "Tag description shown in Preference Center",
                },
                "category": {
                    "type": "string",
                    "description": "Category for grouping tags in Preference Center",
                },
                "is_public": {
                    "type": "boolean",
                    "default": True,
                    "description": "Whether the tag is visible in Preference Center",
                },
            },
            "required": ["name"],
        },
    ),
    Tool(
        name="get_or_create_tag",
        description=(
            "Get an existing tag by name or create a new one if not found. "
            "This is idempotent - safe to call multiple times with the same name."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Tag name",
                },
                "description": {
                    "type": "string",
                    "description": "Tag description (only used if creating)",
                },
                "category": {
                    "type": "string",
                    "description": "Category (only used if creating)",
                },
                "is_public": {
                    "type": "boolean",
                    "default": True,
                    "description": "Visibility (only used if creating)",
                },
            },
            "required": ["name"],
        },
    ),
    Tool(
        name="update_tag",
        description="Update a tag's properties",
        inputSchema={
            "type": "object",
            "properties": {
                "tag_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Tag UUID",
                },
                "name": {
                    "type": "string",
                    "description": "New tag name",
                },
                "description": {
                    "type": "string",
                    "description": "New description",
                },
                "category": {
                    "type": "string",
                    "description": "New category",
                },
                "is_public": {
                    "type": "boolean",
                    "description": "New visibility setting",
                },
            },
            "required": ["tag_id"],
        },
    ),
    Tool(
        name="delete_tag",
        description="Delete a tag. This will remove the tag from all subscribers.",
        inputSchema={
            "type": "object",
            "properties": {
                "tag_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Tag UUID to delete",
                },
            },
            "required": ["tag_id"],
        },
    ),
]

TEMPLATE_TOOLS = [
    Tool(
        name="list_templates",
        description="List email templates with optional category filter",
        inputSchema={
            "type": "object",
            "properties": {
                "category": {
                    "type": "string",
                    "enum": ["transactional", "marketing"],
                    "description": "Filter by template category",
                },
                "skip": {
                    "type": "integer",
                    "minimum": 0,
                    "default": 0,
                    "description": "Number of items to skip (offset-based pagination)",
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 100,
                    "default": 50,
                    "description": "Maximum number of results to return",
                },
            },
        },
    ),
    Tool(
        name="get_template",
        description="Get an email template by its slug",
        inputSchema={
            "type": "object",
            "properties": {
                "slug": {
                    "type": "string",
                    "description": "Template slug identifier",
                },
            },
            "required": ["slug"],
        },
    ),
    Tool(
        name="create_template",
        description="Create a new email template with MJML content",
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Template display name",
                },
                "subject": {
                    "type": "string",
                    "description": "Email subject line (supports variables)",
                },
                "mjml_content": {
                    "type": "string",
                    "description": "MJML template content",
                },
                "category": {
                    "type": "string",
                    "enum": ["transactional", "marketing"],
                    "default": "transactional",
                    "description": "Template category",
                },
            },
            "required": ["name", "subject", "mjml_content"],
        },
    ),
    Tool(
        name="update_template",
        description="Update an existing email template by slug",
        inputSchema={
            "type": "object",
            "properties": {
                "slug": {
                    "type": "string",
                    "description": "Template slug identifier",
                },
                "name": {
                    "type": "string",
                    "description": "New template name",
                },
                "subject": {
                    "type": "string",
                    "description": "New email subject line",
                },
                "mjml_content": {
                    "type": "string",
                    "description": "New MJML template content",
                },
                "category": {
                    "type": "string",
                    "enum": ["transactional", "marketing"],
                    "description": "New template category",
                },
            },
            "required": ["slug"],
        },
    ),
    Tool(
        name="delete_template",
        description="Delete an email template by slug",
        inputSchema={
            "type": "object",
            "properties": {
                "slug": {
                    "type": "string",
                    "description": "Template slug to delete",
                },
            },
            "required": ["slug"],
        },
    ),
    Tool(
        name="preview_template",
        description="Preview a rendered email template with optional variables",
        inputSchema={
            "type": "object",
            "properties": {
                "slug": {
                    "type": "string",
                    "description": "Template slug to preview",
                },
                "variables": {
                    "type": "object",
                    "description": "Template variables for rendering",
                },
            },
            "required": ["slug"],
        },
    ),
]

EMAIL_TOOLS = [
    Tool(
        name="send_email",
        description="Send an email using a template to a recipient",
        inputSchema={
            "type": "object",
            "properties": {
                "template_slug": {
                    "type": "string",
                    "description": "Template slug to use for the email",
                },
                "to": {
                    "type": "string",
                    "format": "email",
                    "description": "Recipient email address",
                },
                "variables": {
                    "type": "object",
                    "description": "Template variables for personalization",
                },
                "idempotency_key": {
                    "type": "string",
                    "description": "Unique key to prevent duplicate sends",
                },
            },
            "required": ["template_slug", "to"],
        },
    ),
]

CAMPAIGN_TOOLS = [
    Tool(
        name="list_campaigns",
        description=("List campaigns with optional status filtering and sorting"),
        inputSchema={
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": [
                        "draft",
                        "sending",
                        "completed",
                        "cancelled",
                    ],
                    "description": "Filter by campaign status",
                },
                "sort_by": {
                    "type": "string",
                    "enum": ["created_at", "name"],
                    "description": "Sort field",
                },
                "sort_desc": {
                    "type": "boolean",
                    "default": True,
                    "description": "Sort descending",
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 100,
                    "default": 50,
                    "description": "Maximum number of results",
                },
            },
        },
    ),
    Tool(
        name="get_campaign",
        description="Get a campaign by ID with sending statistics",
        inputSchema={
            "type": "object",
            "properties": {
                "campaign_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Campaign UUID",
                },
            },
            "required": ["campaign_id"],
        },
    ),
    Tool(
        name="create_campaign",
        description="Create a new email campaign in draft status",
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Campaign name",
                },
                "template_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": ("Template UUID to use for the campaign"),
                },
                "tag_filter": {
                    "type": "object",
                    "description": "Tag-based recipient filter",
                    "properties": {
                        "include_tags": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Tag IDs to include",
                        },
                        "exclude_tags": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Tag IDs to exclude",
                        },
                        "match": {
                            "type": "string",
                            "enum": ["any", "all"],
                            "default": "any",
                            "description": "Match mode",
                        },
                    },
                },
            },
            "required": ["name", "template_id"],
        },
    ),
    Tool(
        name="update_campaign",
        description="Update a campaign (draft status only)",
        inputSchema={
            "type": "object",
            "properties": {
                "campaign_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Campaign UUID",
                },
                "name": {
                    "type": "string",
                    "description": "New campaign name",
                },
                "template_id": {
                    "type": "string",
                    "description": "New template UUID",
                },
                "tag_filter": {
                    "type": "object",
                    "description": ("New tag-based recipient filter"),
                },
            },
            "required": ["campaign_id"],
        },
    ),
    Tool(
        name="send_campaign",
        description=("Trigger sending of a campaign to all matching recipients"),
        inputSchema={
            "type": "object",
            "properties": {
                "campaign_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Campaign UUID to send",
                },
                "batch_size": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 500,
                    "default": 50,
                    "description": "Emails per batch",
                },
            },
            "required": ["campaign_id"],
        },
    ),
    Tool(
        name="cancel_campaign",
        description=("Cancel a campaign that is currently sending"),
        inputSchema={
            "type": "object",
            "properties": {
                "campaign_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Campaign UUID to cancel",
                },
            },
            "required": ["campaign_id"],
        },
    ),
    Tool(
        name="count_campaign_recipients",
        description=("Count how many subscribers match a tag filter (preview before sending)"),
        inputSchema={
            "type": "object",
            "properties": {
                "include_tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Tag IDs to include",
                },
                "exclude_tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Tag IDs to exclude",
                },
                "match": {
                    "type": "string",
                    "enum": ["any", "all"],
                    "default": "any",
                    "description": "Match mode: 'any' or 'all'",
                },
            },
        },
    ),
    Tool(
        name="retry_campaign",
        description="Retry sending a failed campaign to its failed recipients only",
        inputSchema={
            "type": "object",
            "properties": {
                "campaign_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Campaign UUID to retry",
                },
            },
            "required": ["campaign_id"],
        },
    ),
    Tool(
        name="duplicate_campaign",
        description="Duplicate a campaign as a new draft with the same template and tag filter",
        inputSchema={
            "type": "object",
            "properties": {
                "campaign_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Campaign UUID to duplicate",
                },
            },
            "required": ["campaign_id"],
        },
    ),
]

TRIGGER_TOOLS = [
    Tool(
        name="list_triggers",
        description=("List all email triggers for event-based automatic emails"),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    Tool(
        name="get_trigger",
        description="Get an email trigger by ID",
        inputSchema={
            "type": "object",
            "properties": {
                "trigger_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Trigger UUID",
                },
            },
            "required": ["trigger_id"],
        },
    ),
    Tool(
        name="create_trigger",
        description=("Create a new email trigger for automatic event-based emails"),
        inputSchema={
            "type": "object",
            "properties": {
                "event_type": {
                    "type": "string",
                    "description": ("Event type (e.g., subscriber.created, tag.subscribed)"),
                },
                "template_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": ("Template UUID to send when triggered"),
                },
                "description": {
                    "type": "string",
                    "description": "Trigger description",
                },
                "is_active": {
                    "type": "boolean",
                    "default": True,
                    "description": ("Whether trigger is active immediately"),
                },
            },
            "required": ["event_type", "template_id"],
        },
    ),
    Tool(
        name="update_trigger",
        description="Update an email trigger",
        inputSchema={
            "type": "object",
            "properties": {
                "trigger_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Trigger UUID",
                },
                "event_type": {
                    "type": "string",
                    "description": "New event type",
                },
                "template_id": {
                    "type": "string",
                    "description": "New template UUID",
                },
                "description": {
                    "type": "string",
                    "description": "New description",
                },
                "is_active": {
                    "type": "boolean",
                    "description": "New active state",
                },
            },
            "required": ["trigger_id"],
        },
    ),
    Tool(
        name="delete_trigger",
        description="Delete an email trigger",
        inputSchema={
            "type": "object",
            "properties": {
                "trigger_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Trigger UUID to delete",
                },
            },
            "required": ["trigger_id"],
        },
    ),
]

WEBHOOK_TOOLS = [
    Tool(
        name="list_webhooks",
        description="List all configured webhook endpoints",
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 100,
                    "default": 50,
                    "description": "Maximum number of results",
                },
            },
        },
    ),
    Tool(
        name="get_webhook",
        description="Get a webhook endpoint by its ID",
        inputSchema={
            "type": "object",
            "properties": {
                "webhook_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Webhook UUID",
                },
            },
            "required": ["webhook_id"],
        },
    ),
    Tool(
        name="create_webhook",
        description="Create a new webhook endpoint to receive event notifications",
        inputSchema={
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "format": "uri",
                    "description": "HTTPS URL to receive webhook events",
                },
                "events": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Event types to subscribe to. "
                        "Use list_webhook_event_types to see available types."
                    ),
                },
                "description": {
                    "type": "string",
                    "description": "Optional description for the webhook",
                },
            },
            "required": ["url", "events"],
        },
    ),
    Tool(
        name="delete_webhook",
        description="Delete a webhook endpoint",
        inputSchema={
            "type": "object",
            "properties": {
                "webhook_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Webhook UUID to delete",
                },
            },
            "required": ["webhook_id"],
        },
    ),
    Tool(
        name="test_webhook",
        description="Send a test event to a webhook endpoint to verify it's working",
        inputSchema={
            "type": "object",
            "properties": {
                "webhook_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Webhook UUID to test",
                },
            },
            "required": ["webhook_id"],
        },
    ),
]

WEBHOOK_EXTENDED_TOOLS = [
    Tool(
        name="update_webhook",
        description="Update a webhook endpoint's URL, events, description, or active state",
        inputSchema={
            "type": "object",
            "properties": {
                "endpoint_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Webhook endpoint UUID",
                },
                "url": {
                    "type": "string",
                    "format": "uri",
                    "description": "New webhook URL",
                },
                "description": {
                    "type": "string",
                    "description": "New description",
                },
                "events": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "New event types to subscribe to",
                },
                "is_active": {
                    "type": "boolean",
                    "description": "New active state",
                },
            },
            "required": ["endpoint_id"],
        },
    ),
    Tool(
        name="regenerate_webhook_secret",
        description=(
            "Regenerate the signing secret for a webhook endpoint. "
            "The old secret will be invalidated immediately."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "endpoint_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Webhook endpoint UUID",
                },
            },
            "required": ["endpoint_id"],
        },
    ),
    Tool(
        name="list_webhook_deliveries",
        description=(
            "List delivery attempts for a specific webhook endpoint "
            "with optional filtering by event type or status"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "endpoint_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Webhook endpoint UUID",
                },
                "event_type": {
                    "type": "string",
                    "description": "Filter by event type",
                },
                "status": {
                    "type": "string",
                    "enum": [
                        "pending",
                        "delivered",
                        "failed",
                        "retrying",
                    ],
                    "description": "Filter by delivery status",
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 100,
                    "default": 50,
                    "description": "Maximum number of results",
                },
            },
            "required": ["endpoint_id"],
        },
    ),
    Tool(
        name="get_webhook_delivery",
        description=(
            "Get detailed information about a specific webhook "
            "delivery including payload and response"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "endpoint_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Webhook endpoint UUID",
                },
                "delivery_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Delivery UUID",
                },
            },
            "required": ["endpoint_id", "delivery_id"],
        },
    ),
    Tool(
        name="retry_webhook_delivery",
        description="Retry a failed webhook delivery",
        inputSchema={
            "type": "object",
            "properties": {
                "endpoint_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Webhook endpoint UUID",
                },
                "delivery_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Delivery UUID to retry",
                },
            },
            "required": ["endpoint_id", "delivery_id"],
        },
    ),
    Tool(
        name="get_webhook_stats",
        description=(
            "Get delivery statistics for a specific webhook "
            "endpoint (success rate, counts, avg response time)"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "endpoint_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Webhook endpoint UUID",
                },
                "days": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 365,
                    "default": 30,
                    "description": "Number of days to include",
                },
            },
            "required": ["endpoint_id"],
        },
    ),
    Tool(
        name="list_all_webhook_deliveries",
        description=("List delivery attempts across all webhook endpoints with optional filtering"),
        inputSchema={
            "type": "object",
            "properties": {
                "event_type": {
                    "type": "string",
                    "description": "Filter by event type",
                },
                "status": {
                    "type": "string",
                    "enum": [
                        "pending",
                        "delivered",
                        "failed",
                        "retrying",
                    ],
                    "description": "Filter by delivery status",
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 100,
                    "default": 50,
                    "description": "Maximum number of results",
                },
            },
        },
    ),
    Tool(
        name="get_global_webhook_stats",
        description=("Get aggregated delivery statistics across all webhook endpoints"),
        inputSchema={
            "type": "object",
            "properties": {
                "days": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 365,
                    "default": 30,
                    "description": "Number of days to include",
                },
            },
        },
    ),
    Tool(
        name="list_webhook_event_types",
        description=("List all available webhook event types with their descriptions"),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
]

PREFERENCE_CENTER_TOOLS = [
    Tool(
        name="get_preferences",
        description=(
            "Get subscriber preferences and available tags "
            "using a JWT token from generate_preference_token"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "token": {
                    "type": "string",
                    "description": ("JWT token from generate_preference_token"),
                },
            },
            "required": ["token"],
        },
    ),
    Tool(
        name="subscribe_to_tag",
        description=("Subscribe to a public tag using a JWT token"),
        inputSchema={
            "type": "object",
            "properties": {
                "token": {
                    "type": "string",
                    "description": ("JWT token from generate_preference_token"),
                },
                "tag_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Tag UUID to subscribe to",
                },
            },
            "required": ["token", "tag_id"],
        },
    ),
    Tool(
        name="unsubscribe_from_tag",
        description=("Unsubscribe from a tag using a JWT token"),
        inputSchema={
            "type": "object",
            "properties": {
                "token": {
                    "type": "string",
                    "description": ("JWT token from generate_preference_token"),
                },
                "tag_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Tag UUID to unsubscribe from",
                },
            },
            "required": ["token", "tag_id"],
        },
    ),
    Tool(
        name="export_subscriber_data",
        description=("Export all stored subscriber data (DSGVO right of access) using a JWT token"),
        inputSchema={
            "type": "object",
            "properties": {
                "token": {
                    "type": "string",
                    "description": ("JWT token from generate_preference_token"),
                },
            },
            "required": ["token"],
        },
    ),
    Tool(
        name="delete_subscriber_account",
        description=(
            "Delete subscriber account and all data (DSGVO right to erasure) using a JWT token"
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "token": {
                    "type": "string",
                    "description": ("JWT token from generate_preference_token"),
                },
            },
            "required": ["token"],
        },
    ),
]


NOTE_TOOLS = [
    Tool(
        name="create_note",
        description=(
            "Create a note for a subscriber. Notes capture free-text messages such as "
            "contact form submissions, admin comments, or system entries."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "subscriber_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Subscriber UUID",
                },
                "content": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 5000,
                    "description": "Note content",
                },
                "source": {
                    "type": "string",
                    "enum": ["contact_form", "admin", "api", "system"],
                    "default": "api",
                    "description": "Source of the note",
                },
                "subject": {
                    "type": "string",
                    "maxLength": 200,
                    "description": "Optional subject line",
                },
                "metadata": {
                    "type": "object",
                    "description": "Optional metadata key-value pairs",
                },
            },
            "required": ["subscriber_id", "content"],
        },
    ),
    Tool(
        name="list_notes",
        description="List notes for a subscriber with optional filtering and search",
        inputSchema={
            "type": "object",
            "properties": {
                "subscriber_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Subscriber UUID",
                },
                "source": {
                    "type": "string",
                    "enum": ["contact_form", "admin", "api", "system"],
                    "description": "Filter by note source",
                },
                "search": {
                    "type": "string",
                    "maxLength": 200,
                    "description": "Full-text search in note content",
                },
                "created_after": {
                    "type": "string",
                    "description": "Filter notes created after this ISO datetime",
                },
                "created_before": {
                    "type": "string",
                    "description": "Filter notes created before this ISO datetime",
                },
                "sort": {
                    "type": "string",
                    "enum": ["asc", "desc"],
                    "default": "desc",
                    "description": "Sort order by created_at",
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 100,
                    "default": 50,
                    "description": "Maximum number of results to return",
                },
                "cursor": {
                    "type": "string",
                    "description": "Pagination cursor from previous response",
                },
            },
            "required": ["subscriber_id"],
        },
    ),
    Tool(
        name="get_note",
        description="Get a specific note by ID",
        inputSchema={
            "type": "object",
            "properties": {
                "subscriber_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Subscriber UUID",
                },
                "note_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Note UUID",
                },
            },
            "required": ["subscriber_id", "note_id"],
        },
    ),
    Tool(
        name="update_note",
        description="Update an existing note's content, subject, or metadata",
        inputSchema={
            "type": "object",
            "properties": {
                "subscriber_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Subscriber UUID",
                },
                "note_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Note UUID",
                },
                "content": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 5000,
                    "description": "Updated content",
                },
                "subject": {
                    "type": "string",
                    "maxLength": 200,
                    "description": "Updated subject line",
                },
                "metadata": {
                    "type": "object",
                    "description": "Updated metadata (replaces existing)",
                },
            },
            "required": ["subscriber_id", "note_id"],
        },
    ),
    Tool(
        name="delete_note",
        description="Delete a subscriber note permanently",
        inputSchema={
            "type": "object",
            "properties": {
                "subscriber_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Subscriber UUID",
                },
                "note_id": {
                    "type": "string",
                    "format": "uuid",
                    "description": "Note UUID",
                },
            },
            "required": ["subscriber_id", "note_id"],
        },
    ),
]


BILLING_TOOLS = [
    Tool(
        name="get_subscription",
        description=(
            "Get the current billing subscription for the organization. "
            "Returns the plan tier, status, Stripe subscription ID, "
            "period end date, subscriber limit, email limit, and current usage."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    Tool(
        name="get_usage",
        description=(
            "Get current usage counters and plan limits. "
            "Returns subscribers count, emails sent this month, "
            "and the maximum allowed by the current plan."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
]


def get_all_tools() -> list[Tool]:
    """Return all available MCP tools."""
    return (
        SUBSCRIBER_TOOLS
        + TAG_TOOLS
        + NOTE_TOOLS
        + TEMPLATE_TOOLS
        + EMAIL_TOOLS
        + CAMPAIGN_TOOLS
        + TRIGGER_TOOLS
        + WEBHOOK_TOOLS
        + WEBHOOK_EXTENDED_TOOLS
        + PREFERENCE_CENTER_TOOLS
        + BILLING_TOOLS
    )
