"""SubscribeFlow MCP Server module.

This module provides a Model Context Protocol (MCP) server that enables
LLM agents like Claude to interact with the SubscribeFlow API.

Usage:
    # Start the server
    subscribeflow-mcp

    # Or programmatically
    from subscribeflow.mcp import main
    main()

Environment Variables:
    SUBSCRIBEFLOW_API_KEY: Required. Your SubscribeFlow API key.
    SUBSCRIBEFLOW_BASE_URL: Optional. API base URL (default: https://api.subscribeflow.net)
"""

from subscribeflow.mcp.server import main

__all__ = ["main"]
