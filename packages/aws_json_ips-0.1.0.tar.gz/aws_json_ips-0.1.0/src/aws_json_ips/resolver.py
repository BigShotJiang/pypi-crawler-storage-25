"""Resolve AWS-published IP ranges from the authoritative JSON source."""

from __future__ import annotations

import json
from dataclasses import dataclass
from ipaddress import IPv4Network, IPv6Network, ip_network
from typing import Any, Iterable
from urllib.request import Request, urlopen

DEFAULT_IP_RANGES_URL = "https://ip-ranges.amazonaws.com/ip-ranges.json"


@dataclass(frozen=True)
class ResolutionResult:
    """Holds parsed CIDRs and source metadata from AWS's JSON feed."""

    cidrs: tuple[str, ...]
    sync_token: str
    create_date: str
    source_url: str
    selected_prefix_count: int


def _normalize_filters(values: Iterable[str] | None) -> set[str] | None:
    if values is None:
        return None
    normalized = {value.strip().upper() for value in values if value.strip()}
    return normalized or None


def _normalize_region_filters(values: Iterable[str] | None) -> set[str] | None:
    if values is None:
        return None
    normalized = {value.strip().lower() for value in values if value.strip()}
    return normalized or None


def _download_ip_ranges(source_url: str, timeout: float) -> dict[str, Any]:
    request = Request(
        source_url,
        headers={
            "User-Agent": "aws-json-ips/0.1.0",
            "Accept": "application/json",
        },
    )
    with urlopen(request, timeout=timeout) as response:
        charset = response.headers.get_content_charset() or "utf-8"
        payload = response.read().decode(charset)
    data = json.loads(payload)
    if not isinstance(data, dict):
        raise ValueError("AWS IP ranges source did not return a JSON object")
    return data


def _entry_matches(
    entry: dict[str, Any],
    *,
    services: set[str] | None,
    regions: set[str] | None,
    network_border_groups: set[str] | None,
) -> bool:
    service = str(entry.get("service", "")).upper()
    region = str(entry.get("region", "")).lower()
    network_border_group = str(entry.get("network_border_group", "")).upper()

    if services is not None and service not in services:
        return False
    if regions is not None and region not in regions:
        return False
    if network_border_groups is not None and network_border_group not in network_border_groups:
        return False
    return True


def get_aws_ip_cidrs(
    *,
    source_url: str = DEFAULT_IP_RANGES_URL,
    services: Iterable[str] | None = None,
    regions: Iterable[str] | None = None,
    network_border_groups: Iterable[str] | None = None,
    timeout: float = 10.0,
) -> ResolutionResult:
    """Resolve and return sorted AWS CIDR strings from the published JSON source.

    Args:
        source_url: AWS JSON URL to fetch.
        services: Optional AWS service filters such as AMAZON, EC2, or S3.
        regions: Optional AWS region filters such as us-east-1.
        network_border_groups: Optional network border group filters.
        timeout: HTTP timeout in seconds.

    Returns:
        ResolutionResult containing unique, sorted CIDRs and JSON source metadata.
    """
    data = _download_ip_ranges(source_url, timeout=timeout)

    service_filter = _normalize_filters(services)
    region_filter = _normalize_region_filters(regions)
    border_group_filter = _normalize_filters(network_border_groups)

    cidrs: set[str] = set()
    selected_prefix_count = 0

    for entry in data.get("prefixes", []):
        if not isinstance(entry, dict) or not _entry_matches(
            entry,
            services=service_filter,
            regions=region_filter,
            network_border_groups=border_group_filter,
        ):
            continue

        cidr = entry.get("ip_prefix")
        if not isinstance(cidr, str) or not cidr:
            continue

        cidrs.add(str(ip_network(cidr, strict=False)))
        selected_prefix_count += 1

    for entry in data.get("ipv6_prefixes", []):
        if not isinstance(entry, dict) or not _entry_matches(
            entry,
            services=service_filter,
            regions=region_filter,
            network_border_groups=border_group_filter,
        ):
            continue

        cidr = entry.get("ipv6_prefix")
        if not isinstance(cidr, str) or not cidr:
            continue

        cidrs.add(str(ip_network(cidr, strict=False)))
        selected_prefix_count += 1

    return ResolutionResult(
        cidrs=tuple(sorted(cidrs)),
        sync_token=str(data.get("syncToken", "")),
        create_date=str(data.get("createDate", "")),
        source_url=source_url,
        selected_prefix_count=selected_prefix_count,
    )


def get_aws_ip_networks(**kwargs) -> tuple[IPv4Network | IPv6Network, ...]:
    """Resolve AWS ranges and return ipaddress network objects."""
    result = get_aws_ip_cidrs(**kwargs)
    return tuple(ip_network(cidr) for cidr in result.cidrs)