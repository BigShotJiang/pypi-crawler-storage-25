"""Public API for aws_json_ips."""

from .query import AWSIPQuery
from .resolver import (
    DEFAULT_IP_RANGES_URL,
    ResolutionResult,
    get_aws_ip_cidrs,
    get_aws_ip_networks,
)

__all__ = [
    "AWSIPQuery",
    "DEFAULT_IP_RANGES_URL",
    "ResolutionResult",
    "get_aws_ip_cidrs",
    "get_aws_ip_networks",
]