#!/bin/bash
# Globe Server Startup Script with Update Management
# This script handles software updates and starts the Globe Server

set -e  # Exit on error

# Configuration
GLOBE_DIR="$HOME/.globe-server"
VENV_DIR="$GLOBE_DIR/venv"
UPDATES_DIR="$GLOBE_DIR/updates"
LOG_FILE="$GLOBE_DIR/logs/startup.log"
PACKAGE_NAME="globe-server"

# Ensure log directory exists
mkdir -p "$(dirname "$LOG_FILE")"

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "=== Globe Server Startup Script Started ==="

# Check if virtual environment exists
if [ ! -d "$VENV_DIR" ]; then
    log "ERROR: Virtual environment not found at $VENV_DIR"
    log "Please run initial setup first"
    exit 1
fi

# Activate virtual environment
log "Activating virtual environment..."
source "$VENV_DIR/bin/activate"

# Verify activation
if [ -z "$VIRTUAL_ENV" ]; then
    log "ERROR: Failed to activate virtual environment"
    exit 1
fi

log "Virtual environment activated: $VIRTUAL_ENV"

# Function to check PyPI connectivity
check_pypi() {
    log "Checking PyPI connectivity..."
    if pip index versions "$PACKAGE_NAME" &>/dev/null; then
        log "PyPI is accessible"
        return 0
    else
        log "PyPI is not accessible"
        return 1
    fi
}

# Function to update from PyPI
update_from_pypi() {
    log "Attempting to update from PyPI..."
    if pip install --upgrade "$PACKAGE_NAME"; then
        log "Successfully updated from PyPI"
        return 0
    else
        log "Failed to update from PyPI"
        return 1
    fi
}

# Function to update from local files
update_from_local() {
    log "Checking for local update files in $UPDATES_DIR..."
    
    if [ ! -d "$UPDATES_DIR" ]; then
        log "Updates directory does not exist"
        return 1
    fi
    
    # Check if there are any .whl files
    if ! ls "$UPDATES_DIR"/*.whl 1> /dev/null 2>&1; then
        log "No .whl files found in updates directory"
        return 1
    fi
    
    log "Found .whl files in updates directory"
    log "Installing from local files..."
    
    # Install using pip with no-index and find-links
    if pip install --no-index --find-links="$UPDATES_DIR" --upgrade "$PACKAGE_NAME"; then
        log "Successfully installed from local files"
        
        # Clean up the updates directory after successful installation
        log "Cleaning up updates directory..."
        rm -f "$UPDATES_DIR"/*.whl
        log "Updates directory cleaned"
        
        return 0
    else
        log "Failed to install from local files"
        return 1
    fi
}

# Update logic
log "Starting update check..."

# Try PyPI first
if check_pypi; then
    update_from_pypi
    # Function logs its own result
else
    # PyPI not accessible, try local files
    log "PyPI not accessible, checking local updates..."
    if update_from_local; then
        log "Update check complete - updated from local files"
    else
        log "Update check complete - no local updates available"
    fi
fi

# Get installed version
INSTALLED_VERSION=$(pip show "$PACKAGE_NAME" | grep "^Version:" | cut -d' ' -f2)
log "Running $PACKAGE_NAME version: $INSTALLED_VERSION"

# Start the server
log "Starting Globe Server..."

# Use the entry point defined in pyproject.toml
exec globe-server
