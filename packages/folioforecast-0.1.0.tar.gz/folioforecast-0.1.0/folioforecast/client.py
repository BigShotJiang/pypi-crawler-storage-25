"""FolioForecast HTTP client.

A thin, well-typed wrapper around the FolioForecast REST API at
``https://www.folioforecast.com/api/v1``. Pure HTTP over ``httpx``; no
hidden state, no magic, no heavy dependencies.

The client mirrors the four portfolio tools exposed by the API today:

    * ``optimize``            — POST /optimize
    * ``search_tickers``      — GET  /search
    * ``stress_test``         — POST /crisis-scenarios
    * ``asset_metadata``      — POST /asset-metadata

Plus housekeeping:

    * ``health``              — GET  /health
    * ``usage``               — GET  /usage
    * ``list_keys``           — GET  /keys
    * ``create_key``          — POST /keys
    * ``revoke_key``          — POST /keys/{key_id}/revoke

Example:

    import folioforecast as ff

    client = ff.Client(api_key="ff_live_...")
    result = client.optimize(
        tickers=["AAPL.US", "MSFT.US", "GOOGL.US", "AMZN.US"],
        goal="max_sharpe",
    )
    print(result.weights)
    print(result.metrics)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from types import TracebackType
from typing import Any, Literal

import httpx

DEFAULT_BASE_URL = "https://www.folioforecast.com/api/v1"
DEFAULT_TIMEOUT = 60.0
USER_AGENT = "folioforecast-python/0.1.0"

OptimizationGoal = Literal[
    "max_sharpe",
    "min_volatility",
    "risk_parity",
    "equal_weight",
    "min_vol_target_return",
    "max_return_target_vol",
    "min_cvar",
    "min_cvar_target_return",
    "max_return_target_cvar",
    "min_tracking_error",
    "max_information_ratio",
    "max_excess_return_target_te",
    "max_kelly",
    "min_drawdown_target_return",
    "max_omega_target_return",
    "max_sortino_target_return",
    "robust_max_sharpe",
    "robust_min_volatility",
    "robust_min_vol_target_return",
    "robust_max_return_target_vol",
]


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class FolioForecastError(Exception):
    """Base class for all FolioForecast SDK errors."""


class APIError(FolioForecastError):
    """Non-success HTTP response from the FolioForecast API."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        response_data: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data or {}

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        return f"[{self.status_code}] {super().__str__()}"


class AuthError(APIError):
    """401 / 403 — missing, invalid, or revoked API key."""


class BillingError(APIError):
    """402 — payment method required. Add billing at /hub?tab=settings."""


class RateLimitError(APIError):
    """429 — rate limit exceeded. Check ``retry_after`` for the wait in seconds."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        response_data: dict[str, Any] | None = None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(message, status_code=status_code, response_data=response_data)
        self.retry_after = retry_after


# ---------------------------------------------------------------------------
# Result dataclasses
# ---------------------------------------------------------------------------


@dataclass
class OptimizationResult:
    """Result of a portfolio optimization call.

    Convenience attributes expose the most common fields; the full raw API
    response is always available via ``raw`` for fields the SDK hasn't
    promoted to first-class attributes.
    """

    weights: dict[str, float]
    metrics: dict[str, Any]
    efficient_frontier: list[dict[str, Any]] | None = None
    benchmark_comparison: dict[str, Any] | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> OptimizationResult:
        return cls(
            weights=data.get("weights") or data.get("optimal_weights") or {},
            metrics=data.get("metrics") or data.get("portfolio_metrics") or {},
            efficient_frontier=data.get("efficient_frontier"),
            benchmark_comparison=data.get("benchmark_comparison"),
            raw=data,
        )


@dataclass
class TickerSearchResult:
    symbol: str
    name: str
    exchange: str | None = None
    asset_type: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> TickerSearchResult:
        return cls(
            symbol=data.get("symbol", ""),
            name=data.get("name", ""),
            exchange=data.get("exchange"),
            asset_type=data.get("asset_type") or data.get("type"),
            raw=data,
        )


@dataclass
class StressTestResult:
    scenarios: list[dict[str, Any]]
    summary: dict[str, Any]
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> StressTestResult:
        return cls(
            scenarios=data.get("scenarios") or data.get("results") or [],
            summary=data.get("summary") or {},
            raw=data,
        )


@dataclass
class AssetMetadataResult:
    """Metadata for a single ticker."""

    symbol: str
    sector: str | None = None
    industry: str | None = None
    asset_class: str | None = None
    market_cap: float | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> AssetMetadataResult:
        return cls(
            symbol=data.get("symbol", ""),
            sector=data.get("sector"),
            industry=data.get("industry"),
            asset_class=data.get("asset_class") or data.get("class"),
            market_cap=data.get("market_cap"),
            raw=data,
        )


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class Client:
    """Synchronous client for the FolioForecast API.

    Args:
        api_key: Your FolioForecast API key (``ff_live_...`` or ``ff_test_...``).
            If omitted, the ``FOLIOFORECAST_API_KEY`` environment variable is used.
        base_url: API base URL. Defaults to production.
        timeout: Per-request timeout in seconds.
        http_client: Pre-configured ``httpx.Client`` for advanced use
            (proxies, custom transports, etc.). If provided, ``timeout`` is ignored.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        http_client: httpx.Client | None = None,
    ) -> None:
        if api_key is None:
            import os
            api_key = os.environ.get("FOLIOFORECAST_API_KEY", "")
        if not api_key:
            raise FolioForecastError(
                "FolioForecast API key is required. Pass api_key=... or set "
                "FOLIOFORECAST_API_KEY. Get a key at https://www.folioforecast.com/developers"
            )

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._owns_client = http_client is None
        self._http = http_client or httpx.Client(
            timeout=timeout,
            headers={
                "User-Agent": USER_AGENT,
                "X-API-Key": api_key,
                "Accept": "application/json",
            },
        )

    # ------------------------------------------------------------------
    # Context-manager support
    # ------------------------------------------------------------------

    def __enter__(self) -> Client:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_client:
            self._http.close()

    # ------------------------------------------------------------------
    # Low-level request
    # ------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        try:
            response = self._http.request(method, url, json=json, params=params)
        except httpx.RequestError as exc:
            raise FolioForecastError(f"Network error calling {method} {url}: {exc}") from exc

        try:
            data = response.json() if response.content else {}
        except ValueError:
            data = {"raw_text": response.text}

        if response.is_success:
            return data if isinstance(data, dict) else {"data": data}

        # Error path — raise the right subclass so callers can distinguish.
        message = (
            (isinstance(data, dict) and (data.get("message") or data.get("error")))
            or response.text
            or f"HTTP {response.status_code}"
        )
        status = response.status_code

        if status in (401, 403):
            raise AuthError(message, status_code=status, response_data=data if isinstance(data, dict) else None)
        if status == 402:
            raise BillingError(message, status_code=status, response_data=data if isinstance(data, dict) else None)
        if status == 429:
            retry_after_header = response.headers.get("Retry-After")
            retry_after: float | None
            try:
                retry_after = float(retry_after_header) if retry_after_header else None
            except ValueError:
                retry_after = None
            raise RateLimitError(
                message,
                status_code=status,
                response_data=data if isinstance(data, dict) else None,
                retry_after=retry_after,
            )
        raise APIError(message, status_code=status, response_data=data if isinstance(data, dict) else None)

    # ------------------------------------------------------------------
    # Portfolio tools
    # ------------------------------------------------------------------

    def optimize(
        self,
        tickers: list[str],
        *,
        goal: OptimizationGoal = "max_sharpe",
        start_date: str | None = None,
        end_date: str | None = None,
        min_weight: float | None = None,
        max_weight: float | None = None,
        benchmark: str | None = None,
        user_weights: dict[str, float] | None = None,
        target_return: float | None = None,
        target_volatility: float | None = None,
    ) -> OptimizationResult:
        """Run portfolio optimization.

        Args:
            tickers: Symbols in ``SYMBOL.EXCHANGE`` format, e.g. ``["AAPL.US", "GOOGL.US"]``.
                1–50 tickers per call.
            goal: Optimization method. See ``OptimizationGoal`` for the full list.
            start_date / end_date: Analysis window (``YYYY-MM-DD``). Defaults to 2019-01-01 → today.
            min_weight / max_weight: Per-asset weight constraints (0–1).
            benchmark: Benchmark ticker for comparison (default ``SPY.US``).
            user_weights: Current portfolio to compare against the optimized one.
                Map of ticker to weight percentage, e.g. ``{"AAPL.US": 60, "AGG.US": 40}``.
            target_return: Required for target-return methods (decimal, e.g. 0.10 for 10%).
            target_volatility: Required for ``max_return_target_vol`` (decimal).

        Returns:
            An :class:`OptimizationResult` with ``.weights``, ``.metrics``,
            ``.efficient_frontier``, ``.benchmark_comparison``, and ``.raw``.
        """
        if not tickers:
            raise ValueError("optimize() requires at least one ticker")

        body: dict[str, Any] = {
            "tickers": tickers,
            "optimization_goal": goal,
        }
        if start_date:
            body["start_date"] = start_date
        if end_date:
            body["end_date"] = end_date
        if min_weight is not None or max_weight is not None:
            body["constraints"] = {}
            if min_weight is not None:
                body["constraints"]["min_weight"] = min_weight
            if max_weight is not None:
                body["constraints"]["max_weight"] = max_weight
        if benchmark:
            body["benchmark"] = benchmark
        if user_weights:
            body["user_weights"] = user_weights
        if target_return is not None:
            body["target_return"] = target_return
        if target_volatility is not None:
            body["target_volatility"] = target_volatility

        data = self._request("POST", "/optimize", json=body)
        return OptimizationResult.from_response(data)

    def search_tickers(
        self,
        query: str,
        *,
        limit: int = 20,
    ) -> list[TickerSearchResult]:
        """Search 165,000+ tickers by symbol or name.

        Args:
            query: Free-text search string, e.g. ``"apple"`` or ``"SPY"``.
            limit: Maximum number of results to return.

        Returns:
            A list of :class:`TickerSearchResult`. Free — 0 compute units.
        """
        data = self._request("GET", "/search", params={"q": query, "limit": limit})
        results = data.get("results") or data.get("tickers") or data.get("data") or []
        return [TickerSearchResult.from_response(r) for r in results if isinstance(r, dict)]

    def stress_test(
        self,
        tickers: list[str],
        *,
        weights: dict[str, float] | None = None,
        scenarios: list[str] | None = None,
    ) -> StressTestResult:
        """Run crisis-scenario stress tests.

        Args:
            tickers: Portfolio tickers.
            weights: Current weights. If omitted, assumes equal-weight.
            scenarios: Specific scenario IDs to run (e.g. ``["2008_gfc", "covid_2020"]``).
                If omitted, runs the full default set.

        Returns:
            A :class:`StressTestResult` with scenarios and summary.
        """
        body: dict[str, Any] = {"tickers": tickers}
        if weights:
            body["weights"] = weights
        if scenarios:
            body["scenarios"] = scenarios
        data = self._request("POST", "/crisis-scenarios", json=body)
        return StressTestResult.from_response(data)

    def asset_metadata(self, tickers: list[str]) -> list[AssetMetadataResult]:
        """Look up sector, industry, asset class, and market cap for each ticker.

        Cost: 0.1 compute units per ticker.
        """
        data = self._request("POST", "/asset-metadata", json={"tickers": tickers})
        results = data.get("results") or data.get("metadata") or data.get("data") or []
        return [AssetMetadataResult.from_response(r) for r in results if isinstance(r, dict)]

    # ------------------------------------------------------------------
    # Housekeeping
    # ------------------------------------------------------------------

    def health(self) -> dict[str, Any]:
        """Ping ``/health``. No authentication required by the server for this endpoint."""
        return self._request("GET", "/health")

    def usage(self) -> dict[str, Any]:
        """Get current billing-period usage (compute units consumed, remaining, etc.)."""
        return self._request("GET", "/usage")

    def list_keys(self) -> dict[str, Any]:
        """List your API keys (metadata only — raw keys are never returned)."""
        return self._request("GET", "/keys")

    def create_key(self, *, name: str, environment: str = "live") -> dict[str, Any]:
        """Create a new API key. The raw key is returned once — store it securely."""
        return self._request("POST", "/keys", json={"name": name, "environment": environment})

    def revoke_key(self, key_id: str) -> dict[str, Any]:
        """Revoke an API key by its ID."""
        return self._request("POST", f"/keys/{key_id}/revoke")
