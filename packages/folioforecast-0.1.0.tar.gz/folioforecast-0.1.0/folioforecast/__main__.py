"""Allow `python -m folioforecast` to show version and usage.

For the MCP server, run `python -m folioforecast.mcp` instead.
"""
from __future__ import annotations

import sys

from folioforecast import __version__


def main() -> int:
    print(f"folioforecast {__version__}")
    print()
    print("Usage:")
    print("  python -m folioforecast.mcp        Start the MCP server (stdio)")
    print("  folioforecast-mcp                  Same, via console script")
    print()
    print("Or use the SDK in Python:")
    print("  import folioforecast as ff")
    print("  client = ff.Client(api_key='ff_live_...')")
    print("  result = client.optimize(tickers=['AAPL.US', 'MSFT.US'], goal='max_sharpe')")
    print()
    print("Docs: https://www.folioforecast.com/developers")
    return 0


if __name__ == "__main__":
    sys.exit(main())
