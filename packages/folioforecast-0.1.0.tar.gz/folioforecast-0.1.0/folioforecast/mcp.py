"""FolioForecast MCP server (Python).

Exposes the FolioForecast portfolio APIs as Model Context Protocol tools so
Claude Desktop, Claude Code, Cursor, Windsurf, and any other MCP-capable
client can call them directly.

Tool parity with the Node/TypeScript server: same tool names, same parameter
names, same optimization-goal enum. Python users can use either runtime —
they're interchangeable.

Run as:

    pip install 'folioforecast[mcp]'
    export FOLIOFORECAST_API_KEY=ff_live_...
    python -m folioforecast.mcp

Or configure in Claude Desktop
(``~/Library/Application Support/Claude/claude_desktop_config.json``):

    {
      "mcpServers": {
        "folioforecast": {
          "command": "folioforecast-mcp",
          "env": { "FOLIOFORECAST_API_KEY": "ff_live_..." }
        }
      }
    }

Environment variables:

    FOLIOFORECAST_API_KEY   (required)  Your API key
    FOLIOFORECAST_API_URL   (optional)  Override the API base URL for testing

Heavy lifting happens server-side on folioforecast.com — this process is
a thin stdio shim. No portfolio math runs locally.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from typing import Any

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import TextContent, Tool
except ImportError:
    sys.stderr.write(
        "The 'mcp' package is required to run the FolioForecast MCP server.\n"
        "Install with:\n"
        "    pip install 'folioforecast[mcp]'\n"
    )
    sys.exit(1)

from folioforecast import __version__
from folioforecast.client import (
    APIError,
    AuthError,
    BillingError,
    Client,
    FolioForecastError,
    RateLimitError,
)

# ---------------------------------------------------------------------------
# Tool schemas
# ---------------------------------------------------------------------------

OPTIMIZATION_GOALS = [
    "max_sharpe",
    "min_volatility",
    "risk_parity",
    "equal_weight",
    "min_vol_target_return",
    "max_return_target_vol",
    "min_cvar",
    "min_cvar_target_return",
    "max_return_target_cvar",
    "min_tracking_error",
    "max_information_ratio",
    "max_excess_return_target_te",
    "max_kelly",
    "min_drawdown_target_return",
    "max_omega_target_return",
    "max_sortino_target_return",
    "robust_max_sharpe",
    "robust_min_volatility",
    "robust_min_vol_target_return",
    "robust_max_return_target_vol",
]

OPTIMIZE_PORTFOLIO_DESCRIPTION = """\
Optimize a portfolio of assets using quantitative methods.

Given a list of ticker symbols, this tool runs mean-variance optimization (or one of 20 other methods) \
and returns the optimal asset weights, expected return, volatility, Sharpe ratio, and other risk metrics.

USE THIS WHEN:
- A user wants to know the best allocation across a set of stocks/ETFs/bonds
- You need to compare an existing portfolio against an optimized one
- You need risk metrics (volatility, CVaR, max drawdown) for a set of assets
- You want to find the minimum-risk or maximum-return portfolio

TICKER FORMAT: Always use SYMBOL.EXCHANGE format (e.g., "AAPL.US", "SPY.US", "AGG.US", "VOO.US").
Common US exchanges: .US for NYSE/NASDAQ. Use .LSE for London, .XETRA for Frankfurt.

COSTS: 1 compute unit (basic methods) or 2 units (advanced/robust methods)."""

SEARCH_TICKERS_DESCRIPTION = """\
Search FolioForecast's universe of 165,000+ tickers by symbol or name.

USE THIS WHEN:
- A user names a company but you don't know the ticker
- You need to confirm a symbol exists or pick the right exchange listing
- You need asset-type classification (stock, ETF, bond, etc.)

COSTS: Free (0 compute units)."""

STRESS_TEST_DESCRIPTION = """\
Run historical crisis-scenario stress tests against a portfolio.

Returns drawdowns, recovery times, and relative performance across events like \
the 2008 financial crisis, the COVID 2020 crash, the dot-com bust, and more.

USE THIS WHEN:
- A user asks "what would happen to my portfolio in a recession?"
- You need to compare how different allocations weathered past crises
- You need max drawdown and recovery-time metrics

COSTS: 1 compute unit per scenario."""

ASSET_METADATA_DESCRIPTION = """\
Look up sector, industry, asset class, and market cap for a list of tickers.

USE THIS WHEN:
- You need to classify holdings (sector breakdown, large-cap vs small-cap, etc.)
- You're building a portfolio report or factsheet
- You need the asset class of a ticker (equity, fixed income, commodity, etc.)

COSTS: 0.1 compute units per ticker."""


TOOL_DEFINITIONS: list[Tool] = [
    Tool(
        name="optimize_portfolio",
        description=OPTIMIZE_PORTFOLIO_DESCRIPTION,
        inputSchema={
            "type": "object",
            "properties": {
                "tickers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                    "maxItems": 50,
                    "description": (
                        'Ticker symbols in SYMBOL.EXCHANGE format '
                        '(e.g., ["AAPL.US", "GOOGL.US", "AGG.US"])'
                    ),
                },
                "optimization_goal": {
                    "type": "string",
                    "enum": OPTIMIZATION_GOALS,
                    "description": "Optimization method to use. Defaults to max_sharpe.",
                },
                "start_date": {
                    "type": "string",
                    "description": "Analysis start date (YYYY-MM-DD). Defaults to 2019-01-01.",
                },
                "end_date": {
                    "type": "string",
                    "description": "Analysis end date (YYYY-MM-DD). Defaults to today.",
                },
                "min_weight": {
                    "type": "number",
                    "minimum": 0,
                    "maximum": 1,
                    "description": "Minimum weight per asset (0-1). Default 0.",
                },
                "max_weight": {
                    "type": "number",
                    "minimum": 0,
                    "maximum": 1,
                    "description": "Maximum weight per asset (0-1). Default 1.",
                },
                "benchmark": {
                    "type": "string",
                    "description": "Benchmark ticker for comparison (default SPY.US).",
                },
                "user_weights": {
                    "type": "object",
                    "additionalProperties": {"type": "number"},
                    "description": (
                        'Current portfolio weights for comparison. Map of ticker to weight '
                        'percentage (e.g., {"AAPL.US": 60, "AGG.US": 40})'
                    ),
                },
                "target_return": {
                    "type": "number",
                    "description": (
                        "Target annualized return (decimal, e.g., 0.10 for 10%). "
                        "Required for target-return methods."
                    ),
                },
                "target_volatility": {
                    "type": "number",
                    "description": (
                        "Target annualized volatility (decimal). "
                        "Required for max_return_target_vol."
                    ),
                },
            },
            "required": ["tickers"],
        },
    ),
    Tool(
        name="search_tickers",
        description=SEARCH_TICKERS_DESCRIPTION,
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Free-text search string (symbol or name).",
                },
                "limit": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 100,
                    "description": "Max results to return. Default 20.",
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="stress_test",
        description=STRESS_TEST_DESCRIPTION,
        inputSchema={
            "type": "object",
            "properties": {
                "tickers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                    "description": "Portfolio tickers in SYMBOL.EXCHANGE format.",
                },
                "weights": {
                    "type": "object",
                    "additionalProperties": {"type": "number"},
                    "description": "Current weights. Omit for equal-weight.",
                },
                "scenarios": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        'Scenario IDs to run (e.g., ["2008_gfc", "covid_2020"]). '
                        'Omit to run the default set.'
                    ),
                },
            },
            "required": ["tickers"],
        },
    ),
    Tool(
        name="get_asset_metadata",
        description=ASSET_METADATA_DESCRIPTION,
        inputSchema={
            "type": "object",
            "properties": {
                "tickers": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                    "description": "Tickers to look up.",
                },
            },
            "required": ["tickers"],
        },
    ),
]


# ---------------------------------------------------------------------------
# Tool dispatcher
# ---------------------------------------------------------------------------


def _format_error(exc: Exception) -> str:
    """Turn an SDK/HTTP error into a message the model can reason about."""
    if isinstance(exc, AuthError):
        return (
            "Authentication failed. The FOLIOFORECAST_API_KEY is missing, invalid, "
            "or has been revoked. Get a new key at "
            "https://www.folioforecast.com/hub?tab=settings"
        )
    if isinstance(exc, BillingError):
        return (
            "Billing required (HTTP 402). Add a payment method at "
            "https://www.folioforecast.com/hub?tab=settings — free tier does not "
            "cover paid endpoints."
        )
    if isinstance(exc, RateLimitError):
        wait = f" Retry after {exc.retry_after}s." if exc.retry_after else ""
        return f"Rate limit exceeded.{wait} Slow down or upgrade your tier."
    if isinstance(exc, APIError):
        return f"FolioForecast API error [{exc.status_code}]: {exc}"
    if isinstance(exc, FolioForecastError):
        return str(exc)
    return f"Unexpected error: {exc.__class__.__name__}: {exc}"


def _run_tool(client: Client, name: str, args: dict[str, Any]) -> dict[str, Any]:
    """Dispatch a tool call to the SDK and return a JSON-serializable dict."""
    if name == "optimize_portfolio":
        result = client.optimize(
            tickers=args["tickers"],
            goal=args.get("optimization_goal", "max_sharpe"),
            start_date=args.get("start_date"),
            end_date=args.get("end_date"),
            min_weight=args.get("min_weight"),
            max_weight=args.get("max_weight"),
            benchmark=args.get("benchmark"),
            user_weights=args.get("user_weights"),
            target_return=args.get("target_return"),
            target_volatility=args.get("target_volatility"),
        )
        return result.raw or {
            "weights": result.weights,
            "metrics": result.metrics,
            "efficient_frontier": result.efficient_frontier,
            "benchmark_comparison": result.benchmark_comparison,
        }

    if name == "search_tickers":
        results = client.search_tickers(
            query=args["query"],
            limit=args.get("limit", 20),
        )
        return {"results": [r.raw or r.__dict__ for r in results]}

    if name == "stress_test":
        result = client.stress_test(
            tickers=args["tickers"],
            weights=args.get("weights"),
            scenarios=args.get("scenarios"),
        )
        return result.raw or {"scenarios": result.scenarios, "summary": result.summary}

    if name == "get_asset_metadata":
        results = client.asset_metadata(tickers=args["tickers"])
        return {"results": [r.raw or r.__dict__ for r in results]}

    raise FolioForecastError(f"Unknown tool: {name}")


# ---------------------------------------------------------------------------
# Server wiring
# ---------------------------------------------------------------------------


def _build_server(client: Client) -> Server:
    server: Server = Server("folioforecast")

    @server.list_tools()
    async def list_tools() -> list[Tool]:  # type: ignore[misc]
        return TOOL_DEFINITIONS

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:  # type: ignore[misc]
        try:
            payload = await asyncio.to_thread(_run_tool, client, name, arguments or {})
            text = json.dumps(payload, indent=2, default=str)
        except Exception as exc:  # noqa: BLE001 — convert to tool error for the model
            text = json.dumps({"error": _format_error(exc)}, indent=2)
        return [TextContent(type="text", text=text)]

    return server


async def _serve() -> None:
    api_key = os.environ.get("FOLIOFORECAST_API_KEY", "").strip()
    if not api_key:
        sys.stderr.write(
            "FOLIOFORECAST_API_KEY is required. "
            "Get a key at https://www.folioforecast.com/hub?tab=settings\n"
        )
        sys.exit(2)

    base_url = os.environ.get("FOLIOFORECAST_API_URL", "https://www.folioforecast.com/api/v1")
    client = Client(api_key=api_key, base_url=base_url)
    server = _build_server(client)

    sys.stderr.write(
        f"folioforecast-mcp {__version__} — serving over stdio "
        f"(api={base_url}). 4 portfolio tools registered.\n"
    )

    try:
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )
    finally:
        client.close()


def main() -> None:
    """Entry point for the ``folioforecast-mcp`` console script."""
    try:
        asyncio.run(_serve())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
