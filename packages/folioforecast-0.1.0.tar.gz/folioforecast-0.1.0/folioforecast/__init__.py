"""FolioForecast Python SDK.

Programmatic portfolio optimization for AI agents, robo-advisors, and fintech apps.
One API call to optimize, search, or stress-test any portfolio.

Quick start:

    import folioforecast as ff

    client = ff.Client(api_key="ff_live_...")

    result = client.optimize(
        tickers=["AAPL.US", "MSFT.US", "GOOGL.US", "AMZN.US"],
        goal="max_sharpe",
    )
    print(result.weights)    # {'AAPL.US': 0.30, 'MSFT.US': 0.25, ...}
    print(result.metrics)    # {'sharpe': 1.42, 'volatility': 0.18, ...}

To run as a local MCP server for Claude Desktop / Code / Cursor:

    pip install 'folioforecast[mcp]'
    FOLIOFORECAST_API_KEY=ff_live_... python -m folioforecast.mcp

See https://www.folioforecast.com/developers for full documentation.
"""

from folioforecast.client import (
    APIError,
    AssetMetadataResult,
    AuthError,
    BillingError,
    Client,
    FolioForecastError,
    OptimizationResult,
    RateLimitError,
    StressTestResult,
    TickerSearchResult,
)

__version__ = "0.1.0"

__all__ = [
    "Client",
    "FolioForecastError",
    "APIError",
    "AuthError",
    "BillingError",
    "RateLimitError",
    "OptimizationResult",
    "StressTestResult",
    "TickerSearchResult",
    "AssetMetadataResult",
    "__version__",
]
