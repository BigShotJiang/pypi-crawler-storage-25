# SPDX-License-Identifier: Apache-2.0

import os

from ansible import constants as ansible_constants
from ansible.errors import AnsibleError
from ansible.parsing.vault import VaultLib, VaultSecret
from loguru import logger

from osism import utils
import sushy
import urllib3
import yaml

DELETE_SENTINEL = "DELETE"


def deep_compare(a, b, updates):
    """
    Find items in a that do not exist in b or are different.
    Write required changes into updates
    """
    for key, value in a.items():
        if type(value) is not dict:
            if key not in b or b[key] != value:
                updates[key] = value
        else:
            updates[key] = {}
            deep_compare(a[key], b.get(key, {}), updates[key])
            if not updates[key]:
                updates.pop(key)


def deep_merge(a, b):
    for key, value in b.items():
        if value == DELETE_SENTINEL:
            # NOTE: Use special string to remove keys
            a.pop(key, None)
        elif (
            key not in a.keys()
            or not isinstance(a[key], dict)
            or not isinstance(value, dict)
        ):
            a[key] = value
        else:
            deep_merge(a[key], value)


def deep_decrypt(a, vault):
    if a is None:
        return
    if isinstance(a, dict):
        for key, value in list(a.items()):
            if isinstance(value, (dict, list)):
                deep_decrypt(a[key], vault)
            elif vault.is_encrypted(value):
                try:
                    a[key] = vault.decrypt(value).decode().strip()
                except Exception:
                    a.pop(key, None)
    elif isinstance(a, list):
        for i, item in enumerate(a):
            if isinstance(item, (dict, list)):
                deep_decrypt(item, vault)
            elif vault.is_encrypted(item):
                try:
                    a[i] = vault.decrypt(item).decode().strip()
                except Exception:
                    pass


def get_vault():
    """Create and return a VaultLib instance for decrypting secrets"""
    try:
        vault_secret = utils.get_ansible_vault_password()
        vault = VaultLib(
            [
                (
                    ansible_constants.DEFAULT_VAULT_ID_MATCH,
                    VaultSecret(vault_secret.encode()),
                )
            ]
        )
    except ValueError as exc:
        # Handle specific vault password configuration errors
        logger.error(f"Vault password configuration error: {exc}")
        logger.error("Please check your vault password setup in Redis")
        vault = VaultLib()
    except Exception as exc:
        # Handle other errors (file access, decryption, etc.)
        logger.error(f"Unable to get vault secret: {exc}")
        logger.error("Dropping encrypted entries")
        vault = VaultLib()
    return vault


def load_yaml_file(path):
    """Load a YAML file and only request the vault secret when needed."""
    if not os.path.exists(path):
        logger.debug(f"YAML file not found: {path}")
        return None

    try:
        with open(path, "rb") as f:
            file_data = f.read()

        if VaultLib().is_encrypted(file_data):
            decrypted_data = get_vault().decrypt(file_data).decode()
            logger.debug(f"Successfully decrypted vault-encrypted YAML file: {path}")
        else:
            decrypted_data = file_data.decode()
            logger.debug(f"YAML file is not encrypted: {path}")

        return yaml.safe_load(decrypted_data)
    except yaml.YAMLError as exc:
        logger.debug(f"Failed to parse YAML file {path}: {exc}")
        return None
    except AnsibleError as exc:
        logger.debug(f"Failed to decrypt YAML file {path}: {exc}")
        return None
    except OSError as exc:
        logger.debug(f"Failed to read YAML file {path}: {exc}")
        return None


def get_redfish_connection(
    hostname, username=None, password=None, ignore_ssl_errors=True, timeout=None
):
    """Create a Redfish connection to the specified hostname."""
    from osism import settings
    from osism.tasks import openstack

    if not hostname:
        return None

    # Use configurable timeout if not provided
    if timeout is None:
        timeout = settings.REDFISH_TIMEOUT

    # Get Redfish address from Ironic driver_info
    base_url = f"https://{hostname}"
    device = None

    # Try to find NetBox device first for conductor configuration fallback
    if utils.nb:
        try:
            # First try to find device by name
            device = utils.nb.dcim.devices.get(name=hostname)

            # If not found by name, try by inventory_hostname custom field
            if not device:
                devices = utils.nb.dcim.devices.filter(cf_inventory_hostname=hostname)
                if devices:
                    device = devices[0]
        except Exception as exc:
            logger.warning(f"Could not resolve hostname {hostname} via NetBox: {exc}")

    try:
        ironic_node = openstack.baremetal_node_show(hostname, ignore_missing=True)
        if ironic_node and "driver_info" in ironic_node:
            driver_info = ironic_node["driver_info"]
            # Use redfish_address from driver_info if available (contains full URL)
            if "redfish_address" in driver_info:
                base_url = driver_info["redfish_address"]
                logger.info(f"Using Ironic redfish_address {base_url} for {hostname}")
        else:
            # Fallback to conductor configuration if Ironic driver_info not available
            conductor_address = _get_conductor_redfish_address(device)
            if conductor_address:
                base_url = conductor_address
                logger.info(
                    f"Using conductor redfish_address {base_url} for {hostname}"
                )
    except Exception as exc:
        logger.warning(f"Could not get Ironic node for {hostname}: {exc}")
        # Fallback to conductor configuration on Ironic error
        conductor_address = _get_conductor_redfish_address(device)
        if conductor_address:
            base_url = conductor_address
            logger.info(f"Using conductor redfish_address {base_url} for {hostname}")

    # Get credentials from conductor configuration if not provided
    if not username or not password:
        conductor_username, conductor_password = _get_conductor_redfish_credentials(
            device
        )
        if not username:
            username = conductor_username
        if not password:
            password = conductor_password

    auth = sushy.auth.SessionOrBasicAuth(username=username, password=password)

    try:
        if ignore_ssl_errors:
            urllib3.disable_warnings()
            conn = sushy.Sushy(base_url, auth=auth, verify=False)
        else:
            conn = sushy.Sushy(base_url, auth=auth)

        return conn
    except Exception as exc:
        logger.error(
            f"Unable to connect to Redfish API at {base_url} with timeout {timeout}s: {exc}"
        )
        return None


def _get_conductor_redfish_credentials(device):
    """Get Redfish credentials from conductor configuration and device secrets."""
    from osism.tasks.conductor.config import get_configuration
    from osism.tasks.conductor.ironic import _prepare_node_attributes

    try:
        if not device:
            return None, None

        # Use _prepare_node_attributes to get processed node attributes
        def get_ironic_parameters():
            configuration = get_configuration()
            return configuration.get("ironic_parameters", {})

        node_attributes = _prepare_node_attributes(device, get_ironic_parameters)

        # Extract Redfish credentials if available
        if (
            "driver_info" in node_attributes
            and node_attributes.get("driver") == "redfish"
        ):
            driver_info = node_attributes["driver_info"]
            username = driver_info.get("redfish_username")
            password = driver_info.get("redfish_password")
            return username, password

    except Exception as exc:
        logger.warning(f"Could not get conductor Redfish credentials: {exc}")

    return None, None


def _get_conductor_redfish_address(device):
    """Get Redfish address from conductor configuration and device OOB IP."""
    from osism.tasks.conductor.config import get_configuration
    from osism.tasks.conductor.ironic import _prepare_node_attributes

    try:
        if not device:
            return None

        # Use _prepare_node_attributes to get processed node attributes
        def get_ironic_parameters():
            configuration = get_configuration()
            return configuration.get("ironic_parameters", {})

        node_attributes = _prepare_node_attributes(device, get_ironic_parameters)

        # Extract Redfish address if available
        if (
            "driver_info" in node_attributes
            and node_attributes.get("driver") == "redfish"
        ):
            driver_info = node_attributes["driver_info"]
            address = driver_info.get("redfish_address")
            return address

    except Exception as exc:
        logger.warning(f"Could not get conductor Redfish address: {exc}")

    return None


def check_task_lock_and_exit():
    """
    Check if tasks are locked and exit with error message if they are.
    Used by commands that should not run when tasks are locked.

    This is a convenience wrapper around the main utils function.
    """
    return utils.check_task_lock_and_exit()


def _is_secret_key(key):
    if not isinstance(key, str):
        return False
    lower = key.lower()
    return "password" in lower or "secret" in lower or lower.startswith("ironic_osism_")


def mask_secrets(obj, mask="xxx", secret_values=None):
    """Return a deep copy of obj with secret values masked.

    Recursively masks all dict values whose key contains
    'password' or 'secret' (case-insensitive) or starts with
    'ironic_osism_'. If secret_values is provided, also replaces
    those literal strings within all string values.
    """
    import copy

    result = copy.deepcopy(obj)
    _mask_secrets_inplace(result, mask, secret_values or set())
    return result


def _mask_secrets_inplace(obj, mask, secret_values):
    if isinstance(obj, dict):
        for key in list(obj.keys()):
            if _is_secret_key(key):
                obj[key] = mask
            elif isinstance(obj[key], str):
                for sv in secret_values:
                    obj[key] = obj[key].replace(sv, mask)
            else:
                _mask_secrets_inplace(obj[key], mask, secret_values)
    elif isinstance(obj, list):
        for i in range(len(obj)):
            if isinstance(obj[i], str):
                for sv in secret_values:
                    obj[i] = obj[i].replace(sv, mask)
            else:
                _mask_secrets_inplace(obj[i], mask, secret_values)
