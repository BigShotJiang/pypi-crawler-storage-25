"""
Abstract base class for all NeuroMesh AI recommendation engines.

Every engine (TF-IDF, embedding, collaborative, trending, hybrid) must
subclass ``BaseEngine`` and implement its abstract methods.  The contract
enforced here keeps engines interchangeable inside the ``Trainer`` and
``Recommender`` classes.

``RecommendationResult`` is the canonical output model for all engines:
every recommendation returned to the caller must be an instance of this
Pydantic model.
"""

from __future__ import annotations

import abc
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class RecommendationResult(BaseModel):
    """A single recommendation returned by any engine.

    Attributes:
        item_id:    The unique identifier of the recommended item.
        score:      Relevance / similarity score in [0, 1].  Higher is better.
        engine:     Name of the engine that produced this recommendation.
        explanation: Human-readable explanation dict (populated by the
                     explainability layer; empty by default).
        metadata:   Pass-through dict of item fields the caller chose to
                    attach (title, category, etc.). Not set by engines.
    """

    model_config = ConfigDict(frozen=True)

    item_id: str = Field(..., description="Unique identifier of the recommended item.")
    score: float = Field(..., ge=0.0, le=1.0, description="Relevance score in [0, 1].")
    engine: str = Field(..., description="Name of the engine that produced this result.")
    explanation: dict[str, Any] = Field(
        default_factory=dict,
        description="Explainability payload (populated by the explainability layer).",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Optional pass-through item metadata (title, category, etc.).",
    )


class BaseEngine(abc.ABC):
    """Abstract interface that every recommendation engine must implement.

    Subclasses must implement:
    - ``fit()``            — Train the engine on a validated item corpus.
    - ``recommend()``      — Return top-K items similar to a given item.
    - ``similar()``        — Alias / variant of ``recommend()`` (may share impl).
    - ``engine_name``      — Property returning the engine identifier string.

    Optionally override:
    - ``recommend_for_user()`` — User-based recommendations (collaborative engines).
    - ``add_item()``           — Incremental item addition without full retraining.
    - ``add_interaction()``    — Record a user-item interaction.
    - ``is_fitted``            — Property indicating if the engine has been trained.
    """

    @property
    @abc.abstractmethod
    def engine_name(self) -> str:
        """Short identifier for this engine (e.g. ``"tfidf"``, ``"embedding"``)."""

    @property
    def is_fitted(self) -> bool:
        """Return True if the engine has been successfully trained.

        Default implementation checks for ``self._fitted`` bool attribute.
        Override if your engine tracks fitness differently.
        """
        return getattr(self, "_fitted", False)

    @abc.abstractmethod
    def fit(
        self,
        items: list[dict[str, Any]],
        corpus: list[str],
        popularity_scores: dict[str, float],
        freshness_scores: dict[str, float],
        interactions: list[dict[str, Any]],
    ) -> None:
        """Train the engine on the provided data.

        Args:
            items:             Validated item dicts (output of ``validate_items()``).
            corpus:            Text blobs in the same order as ``items``
                               (output of ``FeatureBuilder.build_text_corpus()``).
            popularity_scores: Mapping of item_id → normalized popularity in [0, 1].
            freshness_scores:  Mapping of item_id → freshness score in [0, 1].
            interactions:      List of user-item interaction dicts (may be empty).
        """

    @abc.abstractmethod
    def recommend(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return the top-K items most similar to ``item_id``.

        Args:
            item_id:    The seed item to find similar items for.
            top_k:      Maximum number of results to return.
            exclude_ids: Item IDs to exclude from results (e.g. already shown).

        Returns:
            list[RecommendationResult]: Sorted descending by ``score``.

        Raises:
            EngineNotFittedError: If ``fit()`` has not been called.
            ItemNotFoundError:    If ``item_id`` is not in the trained index.
        """

    @abc.abstractmethod
    def similar(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return items similar to ``item_id`` (alias / variant of ``recommend``).

        Args:
            item_id:    The seed item.
            top_k:      Maximum number of results.
            exclude_ids: Items to exclude.

        Returns:
            list[RecommendationResult]: Sorted descending by ``score``.
        """

    def recommend_for_user(
        self,
        user_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return personalized recommendations for a user.

        Default implementation raises ``NotImplementedError``. Override in
        collaborative and hybrid engines.

        Args:
            user_id:     The user to recommend items for.
            top_k:       Maximum number of results.
            exclude_ids: Items to exclude.

        Returns:
            list[RecommendationResult]: Sorted descending by ``score``.
        """
        raise NotImplementedError(
            f"Engine '{self.engine_name}' does not support user-based recommendations. "
            "Use a collaborative or hybrid engine instead."
        )

    def add_item(self, item: dict[str, Any]) -> None:
        """Incrementally add a new item without full retraining.

        Default implementation raises ``NotImplementedError``. Override in
        engines that support incremental learning (Phase 2).

        Args:
            item: A validated item dict with at least an ``id`` field.
        """
        raise NotImplementedError(
            f"Engine '{self.engine_name}' does not support incremental item addition. "
            "Call fit() again with the full updated item set."
        )

    def add_interaction(self, user_id: str, item_id: str, weight: float = 1.0) -> None:
        """Record a user-item interaction for online learning.

        Default implementation raises ``NotImplementedError``. Override in
        collaborative and hybrid engines (Phase 2).

        Args:
            user_id:  The user who interacted.
            item_id:  The item that was interacted with.
            weight:   Interaction weight (e.g. 1.0 = view, 2.0 = purchase).
        """
        raise NotImplementedError(
            f"Engine '{self.engine_name}' does not support interaction tracking. "
            "Use a collaborative or hybrid engine instead."
        )
