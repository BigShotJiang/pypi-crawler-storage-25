"""
Hybrid recommendation engine for NeuroMesh AI.

Combines signals from up to four component engines using configurable
linear blending weights:

- **Semantic** — :class:`~neuromesh.engines.embedding_engine.EmbeddingEngine`
  (dense vector similarity via sentence transformers).
- **Collaborative** — :class:`~neuromesh.engines.collaborative_engine.CollaborativeEngine`
  (ALS matrix factorisation on user-item interactions).
- **Content** — :class:`~neuromesh.engines.tfidf_engine.TFIDFEngine`
  (TF-IDF cosine similarity on text features).
- **Trending** — :class:`~neuromesh.engines.trending_engine.TrendingEngine`
  (popularity + freshness scoring).

Each engine's scores are independently normalised to ``[0, 1]`` and then
blended with user-supplied weights (which are re-normalised internally so
they always sum to 1).  Engines that are not fitted or have no coverage for
a given item are gracefully skipped — their weight is redistributed among
the active engines.

Usage::

    from neuromesh.engines.hybrid_engine import HybridEngine

    engine = HybridEngine(
        weights={"semantic": 0.4, "collaborative": 0.3, "content": 0.2, "trending": 0.1}
    )
    engine.fit(items, corpus, popularity_scores, freshness_scores, interactions)
    results = engine.recommend("item-42", top_k=10)
    personal = engine.recommend_for_user("user-99", top_k=10)
"""

from __future__ import annotations

from typing import Any

from neuromesh.engines.base_engine import BaseEngine, RecommendationResult
from neuromesh.utils.exceptions import EngineNotFittedError, ItemNotFoundError
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)

# Default signal weights — must sum to 1 (they are re-normalised anyway)
_DEFAULT_WEIGHTS: dict[str, float] = {
    "semantic": 0.40,
    "collaborative": 0.30,
    "content": 0.20,
    "trending": 0.10,
}


class HybridEngine(BaseEngine):
    """Linear-blend hybrid recommendation engine.

    Args:
        weights:          Dict of signal name → weight.  Keys must be a subset of
                          ``{"semantic", "collaborative", "content", "trending"}``.
                          Values are re-normalised so they sum to 1.0.
        embedding_engine: Pre-configured :class:`~neuromesh.engines.embedding_engine.EmbeddingEngine`.
                          Created automatically if ``None``.
        collaborative_engine: Pre-configured
                          :class:`~neuromesh.engines.collaborative_engine.CollaborativeEngine`.
                          Created automatically if ``None``.
        content_engine:   Pre-configured :class:`~neuromesh.engines.tfidf_engine.TFIDFEngine`.
                          Created automatically if ``None``.
        trending_engine:  Pre-configured :class:`~neuromesh.engines.trending_engine.TrendingEngine`.
                          Created automatically if ``None``.
        top_k_per_engine: How many candidates to fetch from each engine before blending.
                          Higher values improve recall at the cost of latency.
    """

    def __init__(
        self,
        weights: dict[str, float] | None = None,
        embedding_engine: BaseEngine | None = None,
        collaborative_engine: BaseEngine | None = None,
        content_engine: BaseEngine | None = None,
        trending_engine: BaseEngine | None = None,
        top_k_per_engine: int = 50,
    ) -> None:
        raw_weights = weights or _DEFAULT_WEIGHTS
        self._weights = self._normalise_weights(raw_weights)
        self._top_k_per_engine = top_k_per_engine

        # Lazy-import engines to avoid circular deps at module level
        self._engines: dict[str, BaseEngine] = {}
        if embedding_engine is not None:
            self._engines["semantic"] = embedding_engine
        if collaborative_engine is not None:
            self._engines["collaborative"] = collaborative_engine
        if content_engine is not None:
            self._engines["content"] = content_engine
        if trending_engine is not None:
            self._engines["trending"] = trending_engine

        self._fitted = False

    # ------------------------------------------------------------------
    # BaseEngine interface
    # ------------------------------------------------------------------

    @property
    def engine_name(self) -> str:
        return "hybrid"

    def fit(
        self,
        items: list[dict[str, Any]],
        corpus: list[str],
        popularity_scores: dict[str, float],
        freshness_scores: dict[str, float],
        interactions: list[dict[str, Any]],
    ) -> None:
        """Fit all component engines on the provided data.

        Engines that are not present in ``self._engines`` are created with
        default parameters before training.

        Args:
            items:             Validated item dicts.
            corpus:            Text blobs in same order as ``items``.
            popularity_scores: Mapping of item_id → popularity score in ``[0, 1]``.
            freshness_scores:  Mapping of item_id → freshness score in ``[0, 1]``.
            interactions:      User-item interaction dicts.
        """
        self._ensure_engines()

        for name, engine in self._engines.items():
            try:
                logger.info("HybridEngine: fitting '%s' sub-engine …", name)
                engine.fit(
                    items=items,
                    corpus=corpus,
                    popularity_scores=popularity_scores,
                    freshness_scores=freshness_scores,
                    interactions=interactions,
                )
            except Exception as exc:
                logger.warning(
                    "HybridEngine: sub-engine '%s' failed to fit — skipping. Error: %s",
                    name,
                    exc,
                )

        self._fitted = True
        logger.info("HybridEngine: all sub-engines fitted.")

    def recommend(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return blended top-K recommendations for an item.

        Args:
            item_id:     Seed item.
            top_k:       Maximum number of results.
            exclude_ids: Item IDs to omit.

        Returns:
            List of :class:`RecommendationResult` sorted descending by blended score.

        Raises:
            :class:`~neuromesh.utils.exceptions.EngineNotFittedError`:
                If :meth:`fit` has not been called.
            :class:`~neuromesh.utils.exceptions.ItemNotFoundError`:
                If ``item_id`` is unknown across *all* component engines.
        """
        self._assert_fitted()
        exclude = set(exclude_ids or []) | {item_id}
        found_in_any = False

        score_map: dict[str, float] = {}

        for name, engine in self._engines.items():
            if not engine.is_fitted:
                continue
            weight = self._weights.get(name, 0.0)
            if weight == 0.0:
                continue
            try:
                raw = engine.recommend(
                    item_id, top_k=self._top_k_per_engine, exclude_ids=list(exclude)
                )
                found_in_any = True
                for r in raw:
                    score_map[r.item_id] = score_map.get(r.item_id, 0.0) + r.score * weight
            except ItemNotFoundError:
                continue
            except Exception as exc:
                logger.warning("HybridEngine: sub-engine '%s' raised error: %s", name, exc)

        if not found_in_any:
            raise ItemNotFoundError(item_id)

        return self._rank(score_map, exclude, top_k)

    def similar(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Alias for :meth:`recommend`."""
        return self.recommend(item_id, top_k=top_k, exclude_ids=exclude_ids)

    def recommend_for_user(
        self,
        user_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return personalised recommendations for a user.

        Delegates to the collaborative engine for user-based candidates,
        then re-scores with other engines for blending.

        Args:
            user_id:     Target user.
            top_k:       Maximum number of results.
            exclude_ids: Item IDs to omit.

        Returns:
            List of :class:`RecommendationResult` sorted descending by blended score.

        Raises:
            :class:`~neuromesh.utils.exceptions.EngineNotFittedError`:
                If :meth:`fit` has not been called.
            :class:`~neuromesh.utils.exceptions.ItemNotFoundError`:
                If ``user_id`` is unknown.
        """
        self._assert_fitted()
        collab = self._engines.get("collaborative")
        if collab is None or not collab.is_fitted:
            raise EngineNotFittedError("CollaborativeEngine not available in this HybridEngine.")

        exclude = set(exclude_ids or [])
        collab_results = collab.recommend_for_user(
            user_id, top_k=self._top_k_per_engine, exclude_ids=list(exclude)
        )
        collab_weight = self._weights.get("collaborative", 1.0)
        score_map: dict[str, float] = {r.item_id: r.score * collab_weight for r in collab_results}
        return self._rank(score_map, exclude, top_k)

    # ------------------------------------------------------------------
    # Sub-engine access
    # ------------------------------------------------------------------

    def get_engine(self, name: str) -> BaseEngine | None:
        """Retrieve a component engine by name.

        Args:
            name: One of ``"semantic"``, ``"collaborative"``, ``"content"``,
                  ``"trending"``.

        Returns:
            The component engine, or ``None`` if not configured.
        """
        return self._engines.get(name)

    # ------------------------------------------------------------------
    # Repr
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        status = "fitted" if self._fitted else "not fitted"
        w = ", ".join(f"{k}={v:.2f}" for k, v in self._weights.items())
        return f"HybridEngine(weights=[{w}], status='{status}')"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _ensure_engines(self) -> None:
        """Create any missing sub-engines with default parameters."""
        if "semantic" not in self._engines and self._weights.get("semantic", 0) > 0:
            from neuromesh.engines.embedding_engine import EmbeddingEngine

            self._engines["semantic"] = EmbeddingEngine()

        if "collaborative" not in self._engines and self._weights.get("collaborative", 0) > 0:
            from neuromesh.engines.collaborative_engine import CollaborativeEngine

            self._engines["collaborative"] = CollaborativeEngine()

        if "content" not in self._engines and self._weights.get("content", 0) > 0:
            from neuromesh.engines.tfidf_engine import TFIDFEngine

            self._engines["content"] = TFIDFEngine()

        if "trending" not in self._engines and self._weights.get("trending", 0) > 0:
            from neuromesh.engines.trending_engine import TrendingEngine

            self._engines["trending"] = TrendingEngine()

    def _assert_fitted(self) -> None:
        if not self._fitted:
            raise EngineNotFittedError("HybridEngine")

    @staticmethod
    def _normalise_weights(weights: dict[str, float]) -> dict[str, float]:
        total = sum(weights.values())
        if total == 0:
            raise ValueError("All weights are zero — cannot normalise.")
        return {k: v / total for k, v in weights.items()}

    @staticmethod
    def _rank(
        score_map: dict[str, float],
        exclude: set[str],
        top_k: int,
    ) -> list[RecommendationResult]:
        filtered = {iid: score for iid, score in score_map.items() if iid not in exclude}
        sorted_items = sorted(filtered.items(), key=lambda x: x[1], reverse=True)
        return [
            RecommendationResult(item_id=iid, score=min(score, 1.0), engine="hybrid")
            for iid, score in sorted_items[:top_k]
        ]
