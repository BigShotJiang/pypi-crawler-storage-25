"""
Collaborative filtering engine for NeuroMesh AI.

Uses Alternating Least Squares (ALS) from the ``implicit`` library to learn
user and item latent factor matrices from implicit feedback signals
(views, clicks, purchases, ratings, etc.).

Key features
------------
- ALS matrix factorisation via ``implicit.als.AlternatingLeastSquares``.
- Sparse user-item matrix from raw interaction dicts — no pre-processing needed.
- Item-to-item recommendations (similar items co-interacted with).
- User-to-item recommendations (personalised, via ``recommend_for_user()``).
- Incremental interaction recording via ``add_interaction()`` with lazy re-fit.
- Fully compatible with the :class:`~neuromesh.engines.base_engine.BaseEngine`
  contract.

Usage::

    from neuromesh.engines.collaborative_engine import CollaborativeEngine

    engine = CollaborativeEngine(factors=64, iterations=20)
    engine.fit(items, corpus=[], popularity_scores={}, freshness_scores={},
               interactions=interactions)
    similar = engine.recommend("item-42", top_k=10)
    personal = engine.recommend_for_user("user-99", top_k=10)
"""

from __future__ import annotations

from typing import Any

import numpy as np

from neuromesh.engines.base_engine import BaseEngine, RecommendationResult
from neuromesh.utils.exceptions import EngineNotFittedError, ItemNotFoundError
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)


class CollaborativeEngine(BaseEngine):
    """Collaborative filtering engine powered by ALS matrix factorisation.

    Args:
        factors:       Number of latent factors. Higher → richer model, slower.
        iterations:    Number of ALS training iterations.
        regularization: L2 regularisation strength.
        alpha:         Confidence scaling factor for implicit feedback.
        random_state:  Seed for reproducibility.
        use_gpu:       Whether to let ``implicit`` attempt GPU training.
    """

    def __init__(
        self,
        factors: int = 64,
        iterations: int = 15,
        regularization: float = 0.01,
        alpha: float = 40.0,
        random_state: int = 42,
        use_gpu: bool = False,
    ) -> None:
        self._factors = factors
        self._iterations = iterations
        self._regularization = regularization
        self._alpha = alpha
        self._random_state = random_state
        self._use_gpu = use_gpu

        # State set during fit()
        self._model: Any = None
        self._user_item_matrix: Any = None  # scipy csr_matrix
        self._item_ids: list[str] = []
        self._item_to_idx: dict[str, int] = {}
        self._user_ids: list[str] = []
        self._user_to_idx: dict[str, int] = {}
        self._fitted = False

        # Buffer for incremental interactions (flushed on next fit/recommend)
        self._pending_interactions: list[dict[str, Any]] = []

    # ------------------------------------------------------------------
    # BaseEngine interface
    # ------------------------------------------------------------------

    @property
    def engine_name(self) -> str:
        return "collaborative"

    def fit(
        self,
        items: list[dict[str, Any]],
        corpus: list[str],
        popularity_scores: dict[str, float],
        freshness_scores: dict[str, float],
        interactions: list[dict[str, Any]],
    ) -> None:
        """Build the user-item sparse matrix and train the ALS model.

        Args:
            items:             Validated item dicts (must have ``"id"`` key).
            corpus:            Not used by this engine; kept for interface compat.
            popularity_scores: Not used by this engine; kept for interface compat.
            freshness_scores:  Not used by this engine; kept for interface compat.
            interactions:      List of dicts with keys ``"user_id"``, ``"item_id"``,
                               and optional ``"score"`` (default 1.0).
        """
        try:
            import implicit  # noqa: F401
            from scipy.sparse import csr_matrix
        except ImportError as exc:
            raise ImportError(
                "implicit and scipy are required for CollaborativeEngine. "
                "Install with: pip install neuromesh-ai[collaborative]"
            ) from exc

        # Build index mappings
        self._item_ids = [str(item["id"]) for item in items]
        self._item_to_idx = {iid: idx for idx, iid in enumerate(self._item_ids)}

        all_interactions = list(interactions) + self._pending_interactions
        self._pending_interactions = []

        if not all_interactions:
            logger.warning(
                "CollaborativeEngine: no interactions — "
                "ALS model will not produce meaningful recommendations."
            )
            self._fitted = True
            return

        # Collect unique users
        user_set: list[str] = []
        seen_users: set[str] = set()
        for ia in all_interactions:
            uid = str(ia.get("user_id", ""))
            if uid and uid not in seen_users:
                user_set.append(uid)
                seen_users.add(uid)

        self._user_ids = user_set
        self._user_to_idx = {uid: idx for idx, uid in enumerate(self._user_ids)}

        n_users = len(self._user_ids)
        n_items = len(self._item_ids)

        rows: list[int] = []
        cols: list[int] = []
        data: list[float] = []

        for ia in all_interactions:
            uid = str(ia.get("user_id", ""))
            iid = str(ia.get("item_id", ""))
            score = float(ia.get("score", 1.0))
            if uid in self._user_to_idx and iid in self._item_to_idx:
                rows.append(self._user_to_idx[uid])
                cols.append(self._item_to_idx[iid])
                data.append(score * self._alpha)

        if not data:
            logger.warning(
                "CollaborativeEngine: no valid interactions found after index filtering."
            )
            self._fitted = True
            return

        self._user_item_matrix = csr_matrix(
            (data, (rows, cols)), shape=(n_users, n_items), dtype=np.float32
        )

        logger.info(
            "CollaborativeEngine: training ALS (factors=%d, iterations=%d, users=%d, items=%d) …",
            self._factors,
            self._iterations,
            n_users,
            n_items,
        )

        from implicit.als import AlternatingLeastSquares

        self._model = AlternatingLeastSquares(
            factors=self._factors,
            iterations=self._iterations,
            regularization=self._regularization,
            use_gpu=self._use_gpu,
            random_state=self._random_state,
        )
        self._model.fit(self._user_item_matrix)
        self._fitted = True
        logger.info("CollaborativeEngine: ALS training complete.")

    def recommend(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return top-K items most similar to ``item_id`` in latent space.

        Uses item-factor vectors from the ALS model to compute cosine
        similarity between items.

        Args:
            item_id:     Seed item.
            top_k:       Maximum number of results.
            exclude_ids: Item IDs to omit.

        Returns:
            List of :class:`RecommendationResult` sorted descending by score.

        Raises:
            :class:`~neuromesh.utils.exceptions.EngineNotFittedError`:
                If :meth:`fit` has not been called.
            :class:`~neuromesh.utils.exceptions.ItemNotFoundError`:
                If ``item_id`` is not in the trained index.
        """
        self._assert_fitted()
        if item_id not in self._item_to_idx:
            raise ItemNotFoundError(item_id)

        if self._model is None:
            return []

        idx = self._item_to_idx[item_id]
        exclude = set(exclude_ids or []) | {item_id}

        # item_factors shape: (n_items, factors)
        item_vectors: np.ndarray = self._model.item_factors
        query_vec: np.ndarray = item_vectors[idx]

        # Compute cosine similarities
        norms: np.ndarray = np.linalg.norm(item_vectors, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1e-9, norms)
        query_norm = float(np.linalg.norm(query_vec)) or 1e-9
        similarities: np.ndarray = (item_vectors @ query_vec) / (norms.squeeze() * query_norm)

        # Sort descending, skip excluded
        sorted_idxs: np.ndarray = np.argsort(-similarities)
        results: list[RecommendationResult] = []
        for i in sorted_idxs:
            if len(results) >= top_k:
                break
            iid = self._item_ids[i]
            if iid in exclude:
                continue
            score = float(np.clip(similarities[i], 0.0, 1.0))
            results.append(RecommendationResult(item_id=iid, score=score, engine=self.engine_name))

        return results

    def similar(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Alias for :meth:`recommend`."""
        return self.recommend(item_id, top_k=top_k, exclude_ids=exclude_ids)

    def recommend_for_user(
        self,
        user_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return personalised top-K recommendations for a user.

        Items the user has already interacted with are automatically excluded.

        Args:
            user_id:     Target user.
            top_k:       Maximum number of results.
            exclude_ids: Additional item IDs to exclude.

        Returns:
            List of :class:`RecommendationResult` sorted descending by score.

        Raises:
            :class:`~neuromesh.utils.exceptions.EngineNotFittedError`:
                If :meth:`fit` has not been called.
            :class:`~neuromesh.utils.exceptions.ItemNotFoundError`:
                If ``user_id`` is not known (cold-start).
        """
        self._assert_fitted()
        if user_id not in self._user_to_idx:
            raise ItemNotFoundError(user_id)

        if self._model is None:
            return []

        user_idx = self._user_to_idx[user_id]
        ids, scores = self._model.recommend(
            user_idx,
            self._user_item_matrix[user_idx],
            N=top_k + len(exclude_ids or []),
            filter_already_liked_items=True,
        )

        exclude = set(exclude_ids or [])
        results: list[RecommendationResult] = []
        for item_idx, score in zip(ids.tolist(), scores.tolist()):
            if len(results) >= top_k:
                break
            iid = self._item_ids[item_idx]
            if iid in exclude:
                continue
            results.append(
                RecommendationResult(
                    item_id=iid,
                    score=float(np.clip(score, 0.0, 1.0)),
                    engine=self.engine_name,
                )
            )
        return results

    # ------------------------------------------------------------------
    # Incremental updates
    # ------------------------------------------------------------------

    def add_interaction(self, user_id: str, item_id: str, score: float = 1.0) -> None:
        """Record a new user-item interaction.

        The interaction is buffered in memory. Call :meth:`fit` again to
        incorporate buffered interactions into the ALS model.

        Args:
            user_id: User who performed the action.
            item_id: Item that was acted upon.
            score:   Interaction strength (e.g. 1.0 for click, 5.0 for purchase).
        """
        self._pending_interactions.append({"user_id": user_id, "item_id": item_id, "score": score})
        logger.debug(
            "CollaborativeEngine: buffered interaction user='%s' item='%s'.",
            user_id,
            item_id,
        )

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def n_users(self) -> int:
        """Number of users seen during training."""
        return len(self._user_ids)

    @property
    def n_items(self) -> int:
        """Number of items seen during training."""
        return len(self._item_ids)

    def __repr__(self) -> str:
        status = "fitted" if self._fitted else "not fitted"
        return (
            f"CollaborativeEngine("
            f"factors={self._factors}, "
            f"iterations={self._iterations}, "
            f"users={self.n_users}, "
            f"items={self.n_items}, "
            f"status='{status}')"
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _assert_fitted(self) -> None:
        if not self._fitted:
            raise EngineNotFittedError("CollaborativeEngine")
