"""
TF-IDF content-based recommendation engine for NeuroMesh AI.

Uses scikit-learn's ``TfidfVectorizer`` and cosine similarity to find
items with similar textual content (title, description, tags, etc.).

This engine is purely content-based — it does not use any user interaction
data. It is the default engine in Phase 1.

Usage::

    from neuromesh.engines.tfidf_engine import TFIDFEngine
    from neuromesh.training.trainer import Trainer

    engine  = TFIDFEngine()
    trainer = Trainer()
    trainer.train(engine, items)

    results = engine.recommend("product_42", top_k=10)
    for r in results:
        print(r.item_id, r.score)
"""

from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from neuromesh.engines.base_engine import BaseEngine, RecommendationResult
from neuromesh.utils.exceptions import EngineNotFittedError, ItemNotFoundError
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)


class TFIDFEngine(BaseEngine):
    """Content-based recommendation engine using TF-IDF and cosine similarity.

    Fits a ``TfidfVectorizer`` on the item text corpus and stores the
    resulting sparse TF-IDF matrix. At inference time, cosine similarity
    is computed between the seed item's vector and all other item vectors,
    returning the top-K closest results.

    Args:
        max_features: Maximum vocabulary size for the vectorizer.
            Defaults to 50,000. Reduce for memory-constrained deployments.
        ngram_range: n-gram range passed to ``TfidfVectorizer``.
            Defaults to ``(1, 2)`` (unigrams + bigrams).
        min_df: Minimum document frequency for a term to enter the vocabulary.
            Defaults to 1 (include all terms). Increase to prune rare tokens.
        sublinear_tf: Apply sublinear TF scaling (``1 + log(tf)``).
            Defaults to ``True`` for better performance on long documents.

    Example::

        engine = TFIDFEngine(max_features=20_000, ngram_range=(1, 2))
        trainer.train(engine, items)
        engine.recommend("item_001", top_k=5)
    """

    def __init__(
        self,
        max_features: int = 50_000,
        ngram_range: tuple[int, int] = (1, 2),
        min_df: int = 1,
        sublinear_tf: bool = True,
    ) -> None:
        self._vectorizer = TfidfVectorizer(
            max_features=max_features,
            ngram_range=ngram_range,
            min_df=min_df,
            sublinear_tf=sublinear_tf,
            strip_accents="unicode",
            analyzer="word",
        )
        self._tfidf_matrix: np.ndarray | None = None
        self._item_ids: list[str] = []
        self._id_to_index: dict[str, int] = {}
        self._fitted: bool = False

    @property
    def engine_name(self) -> str:
        return "tfidf"

    def fit(
        self,
        items: list[dict[str, Any]],
        corpus: list[str],
        popularity_scores: dict[str, float],
        freshness_scores: dict[str, float],
        interactions: list[dict[str, Any]],
    ) -> None:
        """Fit the TF-IDF vectorizer on the text corpus.

        Args:
            items:             Validated item dicts (must have ``id`` field).
            corpus:            Text blobs in the same order as ``items``.
            popularity_scores: Not used by TF-IDF; stored for future hybrid use.
            freshness_scores:  Not used by TF-IDF; stored for future hybrid use.
            interactions:      Ignored by this content-based engine.

        Raises:
            ValueError: If ``items`` and ``corpus`` have different lengths.
        """
        if len(items) != len(corpus):
            raise ValueError(
                f"items length ({len(items)}) must equal corpus length ({len(corpus)})."
            )

        self._item_ids = [item["id"] for item in items]
        self._id_to_index = {item_id: idx for idx, item_id in enumerate(self._item_ids)}

        # Handle edge-case: all corpus entries are empty strings
        effective_corpus = corpus if any(corpus) else ["__empty__"] * len(corpus)

        logger.info("Fitting TF-IDF vectorizer on %d documents.", len(effective_corpus))
        self._tfidf_matrix = self._vectorizer.fit_transform(effective_corpus)
        self._fitted = True

        vocab_size = len(self._vectorizer.vocabulary_)
        logger.info(
            "TF-IDF fit complete — items=%d vocab_size=%d matrix_shape=%s",
            len(items),
            vocab_size,
            self._tfidf_matrix.shape,
        )

    def recommend(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return top-K items most similar (by TF-IDF cosine similarity) to ``item_id``.

        Args:
            item_id:     The seed item ID to find similar items for.
            top_k:       Maximum number of results.
            exclude_ids: Item IDs to exclude (e.g. already interacted with).

        Returns:
            list[RecommendationResult]: Sorted descending by ``score``.

        Raises:
            EngineNotFittedError: If ``fit()`` has not been called.
            ItemNotFoundError:    If ``item_id`` is not in the trained index.
        """
        self._assert_fitted()
        self._assert_item_exists(item_id)

        seed_idx = self._id_to_index[item_id]
        seed_vector = self._tfidf_matrix[seed_idx]  # type: ignore[index]

        # Compute cosine similarity against all items
        sim_scores = cosine_similarity(seed_vector, self._tfidf_matrix).flatten()

        excluded = set(exclude_ids or [])
        excluded.add(item_id)  # always exclude seed

        results: list[RecommendationResult] = []
        # argsort descending; skip seed and excluded items
        for idx in np.argsort(sim_scores)[::-1]:
            candidate_id = self._item_ids[idx]
            if candidate_id in excluded:
                continue
            raw_score = float(sim_scores[idx])
            if raw_score <= 0.0:
                break  # all remaining items have zero similarity
            results.append(
                RecommendationResult(
                    item_id=candidate_id,
                    score=min(raw_score, 1.0),
                    engine=self.engine_name,
                )
            )
            if len(results) >= top_k:
                break

        logger.debug(
            "TFIDFEngine.recommend item_id=%s top_k=%d results=%d",
            item_id,
            top_k,
            len(results),
        )
        return results

    def similar(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Alias for ``recommend()``.

        Args:
            item_id:     The seed item.
            top_k:       Maximum number of results.
            exclude_ids: Items to exclude.

        Returns:
            list[RecommendationResult]: Sorted descending by ``score``.
        """
        return self.recommend(item_id, top_k=top_k, exclude_ids=exclude_ids)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _assert_fitted(self) -> None:
        if not self._fitted or self._tfidf_matrix is None:
            raise EngineNotFittedError(engine_name=self.engine_name)

    def _assert_item_exists(self, item_id: str) -> None:
        if item_id not in self._id_to_index:
            raise ItemNotFoundError(item_id=item_id)
