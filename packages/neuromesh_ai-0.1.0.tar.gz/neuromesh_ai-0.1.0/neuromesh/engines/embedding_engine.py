"""
Embedding-based recommendation engine for NeuroMesh AI.

Uses a :class:`~neuromesh.embeddings.encoder.Encoder` to produce dense
sentence embeddings for every item in the corpus, then stores them in a
pluggable :class:`~neuromesh.embeddings.vector_store.VectorStore` backend
for approximate-nearest-neighbour retrieval.

Key features
------------
- Dense semantic similarity via SentenceTransformer models.
- Pluggable ANN backend: FAISS (default), Qdrant, or Chroma.
- Online incremental indexing via ``add_item()`` — no full refit needed.
- Free-text query support via ``encode_query()``.
- Fully compatible with the :class:`~neuromesh.engines.base_engine.BaseEngine`
  contract so it can be used anywhere TF-IDF or Trending engines are used.

Usage::

    from neuromesh.engines.embedding_engine import EmbeddingEngine

    engine = EmbeddingEngine()
    engine.fit(items, corpus, popularity_scores, freshness_scores, interactions=[])
    results = engine.recommend("item-42", top_k=10)
    free_text = engine.encode_query("dark sci-fi thriller", top_k=5)
"""

from __future__ import annotations

import os
from typing import Any

import numpy as np

from neuromesh.embeddings.encoder import Encoder
from neuromesh.embeddings.vector_store import VectorStore, create_vector_store
from neuromesh.engines.base_engine import BaseEngine, RecommendationResult
from neuromesh.utils.exceptions import EngineNotFittedError, ItemNotFoundError
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)


class EmbeddingEngine(BaseEngine):
    """Semantic embedding engine using dense vector similarity.

    Args:
        encoder:     :class:`~neuromesh.embeddings.encoder.Encoder` instance.
                     If ``None``, a default encoder is created using the
                     ``NEUROMESH_EMBEDDING_MODEL`` env var (or ``all-MiniLM-L6-v2``).
        vector_store: Pre-configured :class:`~neuromesh.embeddings.vector_store.VectorStore`.
                     If ``None``, one is created via :func:`create_vector_store`
                     using the ``NEUROMESH_VECTOR_STORE`` env var (default: ``"faiss"``).
        store_type:  Override the store type string (passed to :func:`create_vector_store`
                     only when ``vector_store`` is ``None``).
        batch_size:  Encoding batch size for ``fit()`` (passed to encoder).
    """

    def __init__(
        self,
        encoder: Encoder | None = None,
        vector_store: VectorStore | None = None,
        store_type: str | None = None,
        batch_size: int = 64,
    ) -> None:
        self._encoder = encoder or Encoder(batch_size=batch_size)
        self._store_type = store_type or os.getenv("NEUROMESH_VECTOR_STORE", "faiss")
        self._vector_store: VectorStore | None = vector_store
        self._item_index: dict[str, dict[str, Any]] = {}  # item_id → raw item dict
        self._fitted = False

    # ------------------------------------------------------------------
    # BaseEngine interface
    # ------------------------------------------------------------------

    @property
    def engine_name(self) -> str:
        return "embedding"

    def fit(
        self,
        items: list[dict[str, Any]],
        corpus: list[str],
        popularity_scores: dict[str, float],
        freshness_scores: dict[str, float],
        interactions: list[dict[str, Any]],
    ) -> None:
        """Encode all items and build the vector index.

        Args:
            items:             Validated item dicts. Each must have an ``"id"`` key.
            corpus:            Text blobs in the same order as ``items``.
            popularity_scores: Not used by this engine (kept for interface compat.).
            freshness_scores:  Not used by this engine (kept for interface compat.).
            interactions:      Not used by this engine (kept for interface compat.).
        """
        if not items:
            logger.warning("EmbeddingEngine.fit called with empty items list.")
            self._fitted = True
            return

        logger.info("EmbeddingEngine: encoding %d items …", len(items))
        embeddings: np.ndarray = self._encoder.encode(corpus)  # (N, dim)

        # Initialise (or re-initialise) the vector store with correct dim
        self._vector_store = create_vector_store(self._store_type, dim=self._encoder.embedding_dim)

        item_ids = [str(item["id"]) for item in items]
        self._vector_store.add(item_ids, embeddings)

        self._item_index = {str(item["id"]): item for item in items}
        self._fitted = True
        logger.info("EmbeddingEngine: indexed %d items (dim=%d).", len(items), embeddings.shape[1])

    def recommend(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return the top-K semantically similar items.

        Args:
            item_id:     Seed item to find neighbours for.
            top_k:       Maximum number of results.
            exclude_ids: Item IDs to omit from results.

        Returns:
            List of :class:`RecommendationResult` sorted descending by score.

        Raises:
            :class:`~neuromesh.utils.exceptions.EngineNotFittedError`:
                If :meth:`fit` has not been called.
            :class:`~neuromesh.utils.exceptions.ItemNotFoundError`:
                If ``item_id`` is not in the index.
        """
        self._assert_fitted()
        if item_id not in self._item_index:
            raise ItemNotFoundError(item_id)

        exclude = set(exclude_ids or []) | {item_id}
        # Retrieve extra results to account for exclusions
        fetch_k = top_k + len(exclude) + 1

        query_vec = self._get_item_vector(item_id)
        raw = self._vector_store.search(query_vec, top_k=fetch_k)  # type: ignore[union-attr]

        results: list[RecommendationResult] = []
        for rid, score in raw:
            if rid in exclude:
                continue
            results.append(RecommendationResult(item_id=rid, score=score, engine=self.engine_name))
            if len(results) >= top_k:
                break

        return results

    def similar(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Alias for :meth:`recommend`."""
        return self.recommend(item_id, top_k=top_k, exclude_ids=exclude_ids)

    # ------------------------------------------------------------------
    # Incremental updates
    # ------------------------------------------------------------------

    def add_item(self, item: dict[str, Any], text: str = "") -> None:
        """Add a new item to the index without a full refit.

        Args:
            item: Item dict with at least an ``"id"`` key.
            text: Text representation used for embedding (same format as
                  the ``corpus`` entries passed to :meth:`fit`). Derived
                  from item fields (description, title, name, id) when
                  omitted.
        """
        if not self._fitted or self._vector_store is None:
            raise EngineNotFittedError("EmbeddingEngine")

        if not text:
            text = str(
                item.get("description")
                or item.get("title")
                or item.get("name")
                or item.get("id", "")
            )

        item_id = str(item["id"])
        vec = self._encoder.encode_single(text).reshape(1, -1)
        self._vector_store.add([item_id], vec)
        self._item_index[item_id] = item
        logger.debug("EmbeddingEngine: added item '%s' incrementally.", item_id)

    def delete_item(self, item_id: str) -> None:
        """Remove an item from the vector index.

        Args:
            item_id: ID of the item to remove.
        """
        if self._vector_store is None:
            return
        self._vector_store.delete(item_id)
        self._item_index.pop(item_id, None)

    # ------------------------------------------------------------------
    # Free-text search
    # ------------------------------------------------------------------

    def encode_query(
        self, query: str, top_k: int = 10, exclude_ids: list[str] | None = None
    ) -> list[RecommendationResult]:
        """Return top-K items matching a free-text query.

        The query is encoded with the same model used during ``fit()``,
        so the resulting embedding lives in the same vector space as the
        stored item embeddings.

        Args:
            query:       Free-text search string.
            top_k:       Maximum number of results.
            exclude_ids: Item IDs to omit from results.

        Returns:
            List of :class:`RecommendationResult` sorted descending by score.

        Raises:
            :class:`~neuromesh.utils.exceptions.EngineNotFittedError`:
                If :meth:`fit` has not been called.
        """
        self._assert_fitted()
        query_vec = self._encoder.encode_single(query)
        exclude = set(exclude_ids or [])

        fetch_k = top_k + len(exclude) + 1
        raw = self._vector_store.search(query_vec, top_k=fetch_k)  # type: ignore[union-attr]

        results: list[RecommendationResult] = []
        for rid, score in raw:
            if rid in exclude:
                continue
            results.append(RecommendationResult(item_id=rid, score=score, engine=self.engine_name))
            if len(results) >= top_k:
                break
        return results

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def vector_store(self) -> VectorStore | None:
        """The underlying vector store (available after ``fit()``)."""
        return self._vector_store

    @property
    def encoder(self) -> Encoder:
        """The underlying encoder instance."""
        return self._encoder

    def __repr__(self) -> str:
        status = "fitted" if self._fitted else "not fitted"
        n = len(self._item_index)
        return (
            f"EmbeddingEngine("
            f"encoder={self._encoder!r}, "
            f"store={self._store_type}, "
            f"items={n}, "
            f"status='{status}')"
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _assert_fitted(self) -> None:
        if not self._fitted or self._vector_store is None:
            raise EngineNotFittedError("EmbeddingEngine")

    def _get_item_vector(self, item_id: str) -> np.ndarray:
        """Re-encode the item text to get its query vector."""
        item = self._item_index[item_id]
        # Use the 'description' field if available, else fall back to 'title'/'name'/'id'
        text = item.get("description") or item.get("title") or item.get("name") or item_id
        return self._encoder.encode_single(str(text))
