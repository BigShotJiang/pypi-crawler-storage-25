"""
Trending recommendation engine for NeuroMesh AI.

Returns the globally most popular and/or freshest items, optionally
filtered by category or item schema field values.  Does not require a
seed item — it is the default engine for "What's trending right now?"
use-cases.

The trending score is a configurable weighted blend of:
- Popularity score (views, purchases, likes, etc.)
- Freshness score (exponential time decay)

Usage::

    from neuromesh.engines.trending_engine import TrendingEngine
    from neuromesh.training.trainer import Trainer

    engine  = TrendingEngine(popularity_weight=0.6, freshness_weight=0.4)
    trainer = Trainer()
    trainer.train(engine, items)

    results = engine.trending(top_k=20)
    category_results = engine.trending(top_k=10, category="electronics")
"""

from __future__ import annotations

from typing import Any

from neuromesh.engines.base_engine import BaseEngine, RecommendationResult
from neuromesh.utils.exceptions import EngineNotFittedError
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)


class TrendingEngine(BaseEngine):
    """Popularity + freshness blended trending engine.

    Scores each item as a weighted combination of its normalized popularity
    and freshness scores, then returns the top-K globally trending items.

    Supports optional category/field filtering so callers can ask for
    "trending electronics" or "trending in the last 7 days" without
    rebuilding the full index.

    Args:
        popularity_weight: Weight applied to the popularity score.
            Defaults to 0.6.
        freshness_weight: Weight applied to the freshness score.
            Defaults to 0.4.
        category_field: Name of the item field used for category filtering.
            Defaults to ``"category"``.

    Note:
        ``popularity_weight + freshness_weight`` does not need to equal 1.0 —
        the blended score is not re-normalized after blending.
    """

    def __init__(
        self,
        popularity_weight: float = 0.6,
        freshness_weight: float = 0.4,
        category_field: str = "category",
    ) -> None:
        if popularity_weight < 0 or freshness_weight < 0:
            raise ValueError("Weights must be non-negative.")
        self.popularity_weight = popularity_weight
        self.freshness_weight = freshness_weight
        self.category_field = category_field

        self._items: list[dict[str, Any]] = []
        self._trending_scores: dict[str, float] = {}
        self._fitted: bool = False

    @property
    def engine_name(self) -> str:
        return "trending"

    def fit(
        self,
        items: list[dict[str, Any]],
        corpus: list[str],
        popularity_scores: dict[str, float],
        freshness_scores: dict[str, float],
        interactions: list[dict[str, Any]],
    ) -> None:
        """Compute and store blended trending scores for all items.

        Args:
            items:             Validated item dicts.
            corpus:            Text corpus (not used by this engine).
            popularity_scores: Mapping of item_id → normalized popularity score.
            freshness_scores:  Mapping of item_id → freshness score.
            interactions:      Ignored by the trending engine.
        """
        self._items = list(items)
        self._trending_scores = {}

        for item in items:
            item_id = item["id"]
            pop = popularity_scores.get(item_id, 0.0)
            fresh = freshness_scores.get(item_id, 0.0)
            score = (self.popularity_weight * pop) + (self.freshness_weight * fresh)
            self._trending_scores[item_id] = score

        self._fitted = True
        logger.info(
            "TrendingEngine fit complete — items=%d pop_weight=%.2f fresh_weight=%.2f",
            len(items),
            self.popularity_weight,
            self.freshness_weight,
        )

    def trending(
        self,
        top_k: int = 10,
        category: str | None = None,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return the top-K trending items, optionally filtered by category.

        Args:
            top_k:       Maximum number of results.
            category:    If provided, only return items where
                         ``item[category_field] == category`` (case-insensitive).
            exclude_ids: Item IDs to exclude from results.

        Returns:
            list[RecommendationResult]: Sorted descending by trending score.

        Raises:
            EngineNotFittedError: If ``fit()`` has not been called.
        """
        self._assert_fitted()
        excluded = set(exclude_ids or [])

        # Apply category filter if requested
        if category:
            cat_lower = category.lower()
            candidate_ids = {
                item["id"]
                for item in self._items
                if str(item.get(self.category_field, "")).lower() == cat_lower
            }
        else:
            candidate_ids = {item["id"] for item in self._items}

        # Sort candidates by trending score descending
        ranked = sorted(
            (
                (item_id, score)
                for item_id, score in self._trending_scores.items()
                if item_id in candidate_ids and item_id not in excluded
            ),
            key=lambda t: t[1],
            reverse=True,
        )

        results = [
            RecommendationResult(
                item_id=item_id,
                score=min(score, 1.0),
                engine=self.engine_name,
            )
            for item_id, score in ranked[:top_k]
        ]

        logger.debug(
            "TrendingEngine.trending top_k=%d category=%s results=%d",
            top_k,
            category,
            len(results),
        )
        return results

    def recommend(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return trending items, ignoring ``item_id`` (trending is not seed-based).

        Provided to satisfy the ``BaseEngine`` contract. Delegates to
        ``trending()`` with ``item_id`` added to ``exclude_ids``.

        Args:
            item_id:     Ignored for ranking; added to ``exclude_ids``.
            top_k:       Maximum number of results.
            exclude_ids: Additional items to exclude.

        Returns:
            list[RecommendationResult]: Top trending items.
        """
        all_excluded = list(exclude_ids or []) + [item_id]
        return self.trending(top_k=top_k, exclude_ids=all_excluded)

    def similar(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Alias for ``recommend()`` — trending engine does not compute similarity.

        Args:
            item_id:     Ignored for ranking.
            top_k:       Maximum number of results.
            exclude_ids: Items to exclude.

        Returns:
            list[RecommendationResult]: Top trending items.
        """
        return self.recommend(item_id, top_k=top_k, exclude_ids=exclude_ids)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _assert_fitted(self) -> None:
        if not self._fitted:
            raise EngineNotFittedError(engine_name=self.engine_name)
