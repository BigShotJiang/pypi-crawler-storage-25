"""Async SQLAlchemy session factory for NeuroMesh AI.

Usage::

    from neuromesh.db.session import get_session, init_db

    await init_db()

    async with get_session() as session:
        session.add(Item(item_id="abc", metadata_={"title": "Example"}))
        await session.commit()
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from neuromesh.db.models import Base
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)

_engine = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def _get_engine(database_url: str) -> Any:
    """Return a cached async engine for *database_url*."""
    global _engine, _session_factory
    if _engine is None:
        _engine = create_async_engine(
            database_url,
            echo=False,
            pool_pre_ping=True,
            pool_size=5,
            max_overflow=10,
        )
        _session_factory = async_sessionmaker(
            _engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )
        logger.info("Database engine created: %s", database_url.split("@")[-1])
    return _engine


async def init_db(database_url: str = "") -> None:
    """Create all tables if they do not already exist.

    Args:
        database_url: Async PostgreSQL URL
                      (``postgresql+asyncpg://user:pass@host/db``).
                      Falls back to ``NEUROMESH_DATABASE_URL`` env var when
                      the argument is omitted.
    """
    if not database_url:
        from neuromesh.config.settings import get_settings

        database_url = get_settings().database_url

    if not database_url:
        logger.warning("No DATABASE_URL configured — skipping table creation.")
        return

    engine = _get_engine(database_url)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables verified / created.")


@asynccontextmanager
async def get_session(database_url: str = "") -> AsyncGenerator[AsyncSession, None]:
    """Async context manager that yields a database session.

    The session is committed on success and rolled back on any exception.
    The caller does **not** need to call ``commit()`` explicitly.

    Args:
        database_url: Async PostgreSQL URL. Falls back to settings when omitted.

    Yields:
        :class:`AsyncSession` bound to the connection pool.

    Example::

        async with get_session() as session:
            session.add(Item(item_id="x"))
    """
    global _session_factory

    if not database_url:
        from neuromesh.config.settings import get_settings

        database_url = get_settings().database_url

    _get_engine(database_url)

    if _session_factory is None:
        raise RuntimeError("Session factory not initialised. Call init_db() first.")

    async with _session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
