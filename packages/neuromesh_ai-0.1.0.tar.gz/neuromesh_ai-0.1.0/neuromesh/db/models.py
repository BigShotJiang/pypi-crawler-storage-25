"""SQLAlchemy ORM models for NeuroMesh AI.

Three models are defined:

* ``Item``             — Catalogue entry with JSONB metadata and optional
                         embedding vector stored as a binary blob (JSON).
* ``Interaction``      — User-item interaction event (view, click, purchase …).
* ``RecommendationLog`` — Audit log of every recommendation returned by an engine.

All models use SQLAlchemy 2.x declarative style with typed columns.
"""

from __future__ import annotations

import datetime
from typing import Any

from sqlalchemy import DateTime, Float, Index, Integer, String, Text, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.types import JSON


class Base(DeclarativeBase):
    """Shared declarative base for all NeuroMesh ORM models."""


class Item(Base):
    """Catalogue item persisted to PostgreSQL.

    Attributes:
        id:          Surrogate integer primary key.
        item_id:     Business identifier (unique, max 255 chars).
        metadata_:   Arbitrary item attributes stored as JSON (title, category, tags…).
        embedding:   Raw embedding vector serialised as a JSON list of floats.
                     Stored as ``TEXT`` for portability; use pgvector in
                     production for ANN queries.
        created_at:  Row creation timestamp (UTC, server-default).
        updated_at:  Last update timestamp (UTC, updated on every write).
    """

    __tablename__ = "items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    item_id: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    metadata_: Mapped[dict[str, Any]] = mapped_column(
        "metadata", JSON, nullable=False, default=dict
    )
    embedding: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    updated_at: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )

    def __repr__(self) -> str:
        return f"Item(item_id={self.item_id!r}, created_at={self.created_at})"


class Interaction(Base):
    """User-item interaction event.

    Attributes:
        id:        Surrogate primary key.
        user_id:   Identifier of the acting user.
        item_id:   Identifier of the item interacted with.
        action:    Interaction type: ``view``, ``click``, ``like``,
                   ``purchase``, or ``rating``.
        score:     Interaction weight (e.g. 1.0 for view, 5.0 for purchase).
        timestamp: UTC timestamp of the event (server-default = now).
    """

    __tablename__ = "interactions"
    __table_args__ = (
        Index("ix_interactions_user_id", "user_id"),
        Index("ix_interactions_item_id", "item_id"),
        Index("ix_interactions_timestamp", "timestamp"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(String(255), nullable=False)
    item_id: Mapped[str] = mapped_column(String(255), nullable=False)
    action: Mapped[str] = mapped_column(String(50), nullable=False)
    score: Mapped[float] = mapped_column(Float, nullable=False, default=1.0)
    timestamp: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    def __repr__(self) -> str:
        return (
            f"Interaction(user_id={self.user_id!r}, item_id={self.item_id!r}, "
            f"action={self.action!r}, score={self.score})"
        )


class RecommendationLog(Base):
    """Audit record for every recommendation served by NeuroMesh.

    Attributes:
        id:         Surrogate primary key.
        user_id:    Requesting user (empty string for item-to-item queries).
        item_id:    Recommended item.
        score:      Recommendation score in [0, 1].
        engine:     Engine that produced the recommendation.
        created_at: UTC timestamp (server-default = now).
    """

    __tablename__ = "recommendation_logs"
    __table_args__ = (
        Index("ix_reclogs_user_id", "user_id"),
        Index("ix_reclogs_item_id", "item_id"),
        Index("ix_reclogs_created_at", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    item_id: Mapped[str] = mapped_column(String(255), nullable=False)
    score: Mapped[float] = mapped_column(Float, nullable=False)
    engine: Mapped[str] = mapped_column(String(100), nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    def __repr__(self) -> str:
        return (
            f"RecommendationLog(user_id={self.user_id!r}, item_id={self.item_id!r}, "
            f"engine={self.engine!r}, score={self.score:.3f})"
        )
