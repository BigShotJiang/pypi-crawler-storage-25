"""
Data preprocessing for NeuroMesh AI.

Cleans, normalizes, and validates raw item dicts before they are passed
to any recommendation engine. The functions here are schema-agnostic —
they work with any item shape as long as an ``id`` field is present.

Usage::

    from neuromesh.training.preprocessing import validate_items, extract_text_features

    items = validate_items(raw_items)
    text = extract_text_features(items[0])
"""

from __future__ import annotations

import re
import unicodedata
from typing import Any

from neuromesh.utils.exceptions import InvalidItemSchemaError
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)

# Fields that are concatenated (in priority order) to build the text corpus
_TEXT_FIELDS = ("title", "name", "description", "summary", "category", "genre", "author", "artist")
_TAG_FIELDS = ("tags", "keywords", "labels")

# Pre-compiled regex patterns
_HTML_TAG_RE = re.compile(r"<[^>]+>")
_WHITESPACE_RE = re.compile(r"\s+")
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")


def clean_text(text: str) -> str:
    """Clean and normalize a raw text string.

    Performs the following transformations in order:
    1. Strip HTML tags
    2. Decode HTML entities (via unicodedata normalization)
    3. Remove control characters
    4. Lowercase
    5. Collapse multiple whitespace to a single space
    6. Strip leading/trailing whitespace

    Args:
        text: Raw input text, may contain HTML, extra whitespace, etc.

    Returns:
        str: Cleaned, lowercased, normalized text.

    Example::

        clean_text("<b>Gaming Laptop</b>  RTX 4080 ")
        # "gaming laptop rtx 4080"
    """
    if not isinstance(text, str):
        return ""
    text = _HTML_TAG_RE.sub(" ", text)
    text = unicodedata.normalize("NFKD", text)
    text = _CONTROL_RE.sub(" ", text)
    text = text.lower()
    text = _WHITESPACE_RE.sub(" ", text)
    return text.strip()


def normalize_item(item: dict[str, Any]) -> dict[str, Any]:
    """Normalize a single item dict.

    Ensures the ``id`` field is a non-empty string. Converts numeric or
    other primitive IDs to strings. Leaves all other fields untouched.

    Args:
        item: Raw item dict from the caller. Must contain an ``id`` field.

    Returns:
        dict: Normalized item with ``id`` guaranteed to be a non-empty string.

    Raises:
        InvalidItemSchemaError: If ``id`` is missing or evaluates to empty.
    """
    if "id" not in item:
        raise InvalidItemSchemaError(reason="Missing required field 'id'.")
    item = dict(item)  # shallow copy — do not mutate caller's data
    item["id"] = str(item["id"]).strip()
    if not item["id"]:
        raise InvalidItemSchemaError(reason="Field 'id' must not be an empty string.")
    return item


def validate_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Validate and normalize a batch of item dicts.

    Checks every item for a valid ``id`` field and deduplicates by ID
    (last occurrence wins). Logs a warning if duplicates are found.

    Args:
        items: List of raw item dicts.

    Returns:
        list[dict]: Validated and deduplicated items.

    Raises:
        InvalidItemSchemaError: If any item is missing a valid ``id``.
        ValueError: If ``items`` is empty.

    Example::

        validated = validate_items([{"id": "1", "title": "Laptop"}, ...])
    """
    if not items:
        raise ValueError("Items list must not be empty.")

    seen: dict[str, dict[str, Any]] = {}
    for idx, item in enumerate(items):
        try:
            normalized = normalize_item(item)
        except InvalidItemSchemaError as exc:
            raise InvalidItemSchemaError(reason=exc.reason, item_index=idx) from exc

        item_id = normalized["id"]
        if item_id in seen:
            logger.warning("Duplicate item ID '%s' at index %d — overwriting.", item_id, idx)
        seen[item_id] = normalized

    return list(seen.values())


def extract_text_features(item: dict[str, Any]) -> str:
    """Build a single text blob from an item's text-bearing fields.

    Concatenates the following fields (when present) in priority order:
    title/name, description/summary, category/genre/author/artist, and
    any tag/keyword lists. All values are cleaned via ``clean_text()``.

    Args:
        item: A normalized item dict (output of ``normalize_item``).

    Returns:
        str: A single space-separated text string representing the item.
             Returns an empty string if no text fields are found.

    Example::

        item = {"id": "1", "title": "Gaming Laptop", "tags": ["gaming", "RTX"]}
        extract_text_features(item)
        # "gaming laptop gaming rtx"
    """
    parts: list[str] = []

    # Primary text fields
    for field in _TEXT_FIELDS:
        value = item.get(field)
        if value and isinstance(value, str):
            cleaned = clean_text(value)
            if cleaned:
                parts.append(cleaned)

    # Tag/keyword fields — flatten lists to space-separated tokens
    for field in _TAG_FIELDS:
        value = item.get(field)
        if value:
            if isinstance(value, list):
                tokens = " ".join(str(t) for t in value if t)
            elif isinstance(value, str):
                tokens = value
            else:
                continue
            cleaned = clean_text(tokens)
            if cleaned:
                parts.append(cleaned)

    return " ".join(parts)
