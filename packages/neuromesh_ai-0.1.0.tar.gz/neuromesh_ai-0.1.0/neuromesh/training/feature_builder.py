"""
Feature builder for NeuroMesh AI.

Transforms validated item dicts into numerical feature representations
used by the recommendation engines:

- Text corpus (for TF-IDF and embedding engines)
- Popularity scores (for trending and hybrid engines)
- Freshness scores (for trending and hybrid engines)

Usage::

    from neuromesh.training.feature_builder import FeatureBuilder

    builder = FeatureBuilder()
    corpus = builder.build_text_corpus(items)
    popularity = builder.build_popularity_scores(items)
    freshness = builder.build_freshness_scores(items)
"""

from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Any

from neuromesh.training.preprocessing import extract_text_features
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)

# Fields inspected to derive a popularity signal
_POPULARITY_FIELDS = (
    ("views", 1.0),
    ("view_count", 1.0),
    ("purchases", 2.0),  # purchases weighted more than views
    ("sales_count", 2.0),
    ("orders", 2.0),
    ("likes", 1.5),
    ("ratings_count", 1.5),
    ("clicks", 0.8),
)

# Fields inspected for item creation/publish date
_DATE_FIELDS = ("created_at", "published_at", "date", "release_date", "updated_at")


def _safe_float(value: Any) -> float:
    """Coerce a value to float, returning 0.0 on failure."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _min_max_normalize(scores: dict[str, float]) -> dict[str, float]:
    """Normalize a dict of scores to the [0.0, 1.0] range (min-max).

    Args:
        scores: Mapping of item_id → raw score.

    Returns:
        dict: Same keys with values normalized to [0.0, 1.0].
              If all values are identical, returns all 0.0.
    """
    if not scores:
        return {}
    min_val = min(scores.values())
    max_val = max(scores.values())
    spread = max_val - min_val
    if spread == 0.0:
        return {k: 0.0 for k in scores}
    return {k: (v - min_val) / spread for k, v in scores.items()}


class FeatureBuilder:
    """Builds feature representations from validated item dicts.

    All methods are stateless — they accept items and return computed
    features without storing any internal state.

    Example::

        from neuromesh.training.feature_builder import FeatureBuilder

        builder = FeatureBuilder(freshness_decay_days=30)
        corpus   = builder.build_text_corpus(items)
        pop      = builder.build_popularity_scores(items)
        fresh    = builder.build_freshness_scores(items)
    """

    def __init__(self, freshness_decay_days: int = 30) -> None:
        """Initialize FeatureBuilder.

        Args:
            freshness_decay_days: Half-life in days for the freshness
                exponential decay function. Items older than this number
                of days receive a score below 0.5. Defaults to 30.
        """
        self.freshness_decay_days = freshness_decay_days

    def build_text_corpus(self, items: list[dict[str, Any]]) -> list[str]:
        """Build a list of text blobs, one per item, in the same order as ``items``.

        Each blob is produced by ``extract_text_features()`` and represents
        the item's full textual content (title, description, tags, etc.).

        Args:
            items: Validated item dicts (output of ``validate_items()``).

        Returns:
            list[str]: Text blobs in the same order as ``items``.
                       Items with no text fields produce an empty string.

        Example::

            corpus = builder.build_text_corpus(items)
            # ["gaming laptop rtx 4080 electronics gaming", "python tutorial ...")
        """
        corpus = [extract_text_features(item) for item in items]
        empty_count = sum(1 for t in corpus if not t)
        if empty_count:
            logger.warning(
                "%d item(s) produced no text features — they may score low in content-based engines.",
                empty_count,
            )
        return corpus

    def build_popularity_scores(self, items: list[dict[str, Any]]) -> dict[str, float]:
        """Compute a normalized [0, 1] popularity score for each item.

        Inspects common engagement fields (views, purchases, likes, etc.)
        with field-specific weights, sums the weighted values, then applies
        min-max normalization across all items.

        Args:
            items: Validated item dicts.

        Returns:
            dict[str, float]: Mapping of item_id → normalized popularity score.
                              Items with no engagement data receive 0.0.

        Example::

            scores = builder.build_popularity_scores(items)
            scores["product_42"]  # e.g. 0.85
        """
        raw: dict[str, float] = {}
        for item in items:
            item_id = item["id"]
            score = 0.0
            for field, weight in _POPULARITY_FIELDS:
                value = _safe_float(item.get(field, 0))
                score += value * weight
            raw[item_id] = score

        normalized = _min_max_normalize(raw)
        logger.debug("Computed popularity scores for %d items.", len(normalized))
        return normalized

    def build_freshness_scores(self, items: list[dict[str, Any]]) -> dict[str, float]:
        """Compute a normalized [0, 1] freshness score for each item.

        Uses exponential decay: ``score = exp(-age_days / decay_days)``.
        A brand-new item scores 1.0; an item exactly ``decay_days`` old
        scores ~0.37; an item 3× ``decay_days`` old scores ~0.05.

        Items with no parseable date field receive a score of 0.0.

        Args:
            items: Validated item dicts.

        Returns:
            dict[str, float]: Mapping of item_id → freshness score in [0, 1].

        Example::

            scores = builder.build_freshness_scores(items)
            scores["new_item"]  # e.g. 0.97
        """
        now = datetime.now(tz=timezone.utc)
        scores: dict[str, float] = {}

        for item in items:
            item_id = item["id"]
            date_value: datetime | None = None

            for field in _DATE_FIELDS:
                raw_date = item.get(field)
                if raw_date is None:
                    continue
                if isinstance(raw_date, datetime):
                    date_value = (
                        raw_date if raw_date.tzinfo else raw_date.replace(tzinfo=timezone.utc)
                    )
                    break
                if isinstance(raw_date, str):
                    try:
                        parsed = datetime.fromisoformat(raw_date.replace("Z", "+00:00"))
                        date_value = (
                            parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
                        )
                        break
                    except ValueError:
                        continue

            if date_value is None:
                scores[item_id] = 0.0
                continue

            age_days = max((now - date_value).total_seconds() / 86400.0, 0.0)
            scores[item_id] = math.exp(-age_days / self.freshness_decay_days)

        logger.debug("Computed freshness scores for %d items.", len(scores))
        return scores
