"""
Training orchestrator for NeuroMesh AI.

The ``Trainer`` class provides a single entry point that runs the full
preprocessing → feature building → engine fitting pipeline.

Usage::

    from neuromesh.training.trainer import Trainer
    from neuromesh.engines.tfidf_engine import TFIDFEngine

    engine = TFIDFEngine()
    trainer = Trainer()
    trainer.train(engine, raw_items)
"""

from __future__ import annotations

import time
from typing import Any

from neuromesh.training.feature_builder import FeatureBuilder
from neuromesh.training.preprocessing import validate_items
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)


class Trainer:
    """Orchestrates the full data pipeline from raw items to a fitted engine.

    Steps performed by ``train()``:
    1. Validate and normalize all items via ``validate_items()``.
    2. Build a text corpus via ``FeatureBuilder.build_text_corpus()``.
    3. Build popularity scores via ``FeatureBuilder.build_popularity_scores()``.
    4. Build freshness scores via ``FeatureBuilder.build_freshness_scores()``.
    5. Call ``engine.fit(items, corpus, popularity, freshness)``.

    Args:
        freshness_decay_days: Half-life in days for freshness scoring.
            Passed directly to ``FeatureBuilder``. Defaults to 30.

    Example::

        from neuromesh.training.trainer import Trainer
        from neuromesh.engines.tfidf_engine import TFIDFEngine

        trainer = Trainer()
        engine  = TFIDFEngine()
        trainer.train(engine, items)
    """

    def __init__(self, freshness_decay_days: int = 30) -> None:
        self._feature_builder = FeatureBuilder(freshness_decay_days=freshness_decay_days)

    def train(
        self,
        engine: Any,
        items: list[dict[str, Any]],
        interactions: list[dict[str, Any]] | None = None,
    ) -> list[dict[str, Any]]:
        """Run the full training pipeline on the provided engine.

        Args:
            engine: Any engine that implements ``BaseEngine.fit()``.
            items: Raw item dicts. Only ``id`` is required; all other
                fields are optional and schema-agnostic.
            interactions: Optional list of user-item interaction dicts
                (used by collaborative and hybrid engines).

        Returns:
            list[dict]: The validated, normalized items that were used
                        for training (useful for logging or inspection).

        Raises:
            ValueError: If ``items`` is empty.
            InvalidItemSchemaError: If any item lacks a valid ``id``.
        """
        start = time.perf_counter()
        logger.info("Training pipeline started — %d raw items.", len(items))

        # Step 1: Validate and normalize
        validated = validate_items(items)
        logger.info("Validation complete — %d unique items.", len(validated))

        # Step 2: Build features
        corpus = self._feature_builder.build_text_corpus(validated)
        popularity = self._feature_builder.build_popularity_scores(validated)
        freshness = self._feature_builder.build_freshness_scores(validated)

        # Step 3: Fit engine
        engine.fit(
            items=validated,
            corpus=corpus,
            popularity_scores=popularity,
            freshness_scores=freshness,
            interactions=interactions or [],
        )

        elapsed = time.perf_counter() - start
        logger.info(
            "Training pipeline complete — engine=%s items=%d elapsed=%.3fs",
            type(engine).__name__,
            len(validated),
            elapsed,
        )
        return validated
