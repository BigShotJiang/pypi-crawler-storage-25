"""Odoo ERP/POS connector for NeuroMesh AI.

Connects to an Odoo instance via XML-RPC, fetches product catalogues and
sale-order history, and converts them into the item/interaction dicts that
NeuroMesh engines consume.

Usage::

    from neuromesh.integrations.odoo.connector import OdooConnector

    conn = OdooConnector(
        url="https://myodoo.example.com",
        db="mydb",
        username="admin",
        password="secret",
    )
    conn.connect()

    items        = conn.fetch_products()
    interactions = conn.fetch_sale_orders()

    rec = Recommender(engine="hybrid")
    rec.train(items, interactions=interactions)

    cross_sell = conn.recommend_cross_sell("product_42", recommender=rec)
"""

from __future__ import annotations

import logging
import xmlrpc.client
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

_PRODUCT_FIELDS = [
    "id",
    "name",
    "description_sale",
    "categ_id",
    "list_price",
    "qty_available",
    "sales_count",
    "default_code",
    "product_tag_ids",
    "write_date",
]

_ORDER_LINE_FIELDS = ["order_id", "product_id", "product_uom_qty", "price_unit"]


class OdooConnector:
    """XML-RPC connector to an Odoo instance.

    Args:
        url:      Base URL of the Odoo server (e.g. ``https://odoo.example.com``).
        db:       Odoo database name.
        username: Odoo login username.
        password: Odoo login password or API key.
    """

    def __init__(
        self,
        url: str,
        db: str,
        username: str,
        password: str,
    ) -> None:
        self._url = url.rstrip("/")
        self._db = db
        self._username = username
        self._password = password
        self._uid: int | None = None
        self._models: xmlrpc.client.ServerProxy | None = None

    # ------------------------------------------------------------------
    # Connection
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Authenticate with Odoo and store the session UID."""
        common = xmlrpc.client.ServerProxy(f"{self._url}/xmlrpc/2/common")
        raw_uid = common.authenticate(self._db, self._username, self._password, {})
        self._uid = int(raw_uid)  # type: ignore[arg-type]
        if self._uid == 0:
            raise ConnectionError(
                f"Odoo authentication failed for user '{self._username}' on db '{self._db}'"
            )
        self._models = xmlrpc.client.ServerProxy(f"{self._url}/xmlrpc/2/object")
        logger.info("Connected to Odoo as uid=%d", self._uid)

    def _check_connected(self) -> None:
        if self._uid is None or self._models is None:
            raise RuntimeError("Call connect() before using the connector.")

    def _execute(self, model: str, method: str, *args: Any, **kwargs: Any) -> Any:
        self._check_connected()
        assert self._models is not None
        return self._models.execute_kw(
            self._db, self._uid, self._password, model, method, list(args), kwargs
        )

    # ------------------------------------------------------------------
    # Product catalogue
    # ------------------------------------------------------------------

    def fetch_products(
        self,
        domain: list[Any] | None = None,
        limit: int = 10_000,
    ) -> list[dict[str, Any]]:
        """Fetch active sale products from Odoo.

        Returns a list of item dicts compatible with NeuroMesh ``train()``.

        Args:
            domain: Optional Odoo domain filter (default: active products only).
            limit:  Maximum number of records to fetch.
        """
        if domain is None:
            domain = [["sale_ok", "=", True], ["active", "=", True]]

        raw: list[dict[str, Any]] = self._execute(
            "product.template",
            "search_read",
            domain,
            fields=_PRODUCT_FIELDS,
            limit=limit,
        )

        items: list[dict[str, Any]] = []
        for p in raw:
            category = p["categ_id"][1] if p.get("categ_id") else ""
            items.append(
                {
                    "id": f"odoo-product-{p['id']}",
                    "title": p.get("name") or "",
                    "description": p.get("description_sale") or "",
                    "category": category,
                    "price": float(p.get("list_price") or 0.0),
                    "stock": float(p.get("qty_available") or 0.0),
                    "sales_count": int(p.get("sales_count") or 0),
                    "sku": p.get("default_code") or "",
                    "created_at": p.get("write_date") or datetime.now(tz=timezone.utc).isoformat(),
                    "_odoo_id": p["id"],
                }
            )
        logger.info("Fetched %d products from Odoo", len(items))
        return items

    # ------------------------------------------------------------------
    # Sale order history → interactions
    # ------------------------------------------------------------------

    def fetch_sale_orders(
        self,
        domain: list[Any] | None = None,
        limit: int = 50_000,
    ) -> list[dict[str, Any]]:
        """Fetch confirmed sale order lines as user-item interactions.

        Each sale line becomes one interaction with ``action="purchase"``
        and a score proportional to the quantity ordered.

        Args:
            domain: Optional Odoo domain filter.
            limit:  Maximum number of order lines to fetch.
        """
        if domain is None:
            domain = [["order_id.state", "in", ["sale", "done"]]]

        raw: list[dict[str, Any]] = self._execute(
            "sale.order.line",
            "search_read",
            domain,
            fields=_ORDER_LINE_FIELDS,
            limit=limit,
        )

        interactions: list[dict[str, Any]] = []
        for line in raw:
            order_id = line["order_id"][0] if line.get("order_id") else None
            product_id = line["product_id"][0] if line.get("product_id") else None
            if order_id is None or product_id is None:
                continue
            qty = float(line.get("product_uom_qty") or 1.0)
            interactions.append(
                {
                    "user_id": f"odoo-order-{order_id}",
                    "item_id": f"odoo-product-{product_id}",
                    "action": "purchase",
                    "score": min(qty, 5.0),  # cap score at 5
                }
            )
        logger.info("Fetched %d sale-order interactions from Odoo", len(interactions))
        return interactions

    # ------------------------------------------------------------------
    # Recommendation helpers
    # ------------------------------------------------------------------

    def recommend_cross_sell(
        self,
        product_id: int,
        recommender: Any,
        top_k: int = 5,
    ) -> list[dict[str, Any]]:
        """Return cross-sell recommendations for an Odoo product.

        Args:
            product_id:   Odoo integer product ID.
            recommender:  A fitted ``neuromesh.Recommender`` instance.
            top_k:        Number of results to return.

        Returns:
            List of dicts with ``item_id`` and ``score`` keys.
        """
        item_id = f"odoo-product-{product_id}"
        results = recommender.recommend(item_id, top_k=top_k)
        return [{"item_id": r.item_id, "score": r.score} for r in results]

    def recommend_upsell(
        self,
        product_id: int,
        recommender: Any,
        top_k: int = 3,
    ) -> list[dict[str, Any]]:
        """Return upsell recommendations (similar but higher-priced items).

        Delegates to ``recommend_cross_sell`` — filtering by price should be
        done by the caller once product prices are known.
        """
        return self.recommend_cross_sell(product_id, recommender, top_k=top_k)

    def dead_stock_prediction(
        self,
        min_stock: float = 10.0,
        max_sales: int = 5,
    ) -> list[dict[str, Any]]:
        """Return products with high stock but few sales (dead stock risk).

        Args:
            min_stock:  Minimum qty on hand to consider.
            max_sales:  Maximum sales_count threshold.
        """
        domain = [
            ["qty_available", ">=", min_stock],
            ["sales_count", "<=", max_sales],
            ["sale_ok", "=", True],
            ["active", "=", True],
        ]
        raw: list[dict[str, Any]] = self._execute(
            "product.template",
            "search_read",
            domain,
            fields=["id", "name", "qty_available", "sales_count", "list_price"],
            limit=1_000,
        )
        return [
            {
                "id": f"odoo-product-{p['id']}",
                "name": p["name"],
                "stock": float(p.get("qty_available") or 0),
                "sales_count": int(p.get("sales_count") or 0),
                "price": float(p.get("list_price") or 0),
            }
            for p in raw
        ]

    # ------------------------------------------------------------------
    # Dunder
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        status = f"uid={self._uid}" if self._uid else "not connected"
        return f"OdooConnector(url={self._url!r}, db={self._db!r}, {status})"
