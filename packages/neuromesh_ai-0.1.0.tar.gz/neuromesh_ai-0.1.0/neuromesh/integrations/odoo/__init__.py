﻿"""Odoo ERP/POS integration for NeuroMesh AI."""

from neuromesh.integrations.odoo.connector import OdooConnector

__all__ = ["OdooConnector"]
