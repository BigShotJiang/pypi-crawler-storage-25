"""Shopify Admin REST API connector for NeuroMesh AI.

Fetches product catalogues and order history from a Shopify store and
converts them into NeuroMesh item/interaction dicts.

Usage::

    from neuromesh.integrations.shopify.connector import ShopifyConnector

    conn = ShopifyConnector(
        store_url="mystore.myshopify.com",
        token="shpat_xxxx",
    )
    items        = await conn.fetch_products()
    interactions = await conn.fetch_orders()

    rec = Recommender(engine="tfidf")
    rec.train(items)
    recs = await conn.recommend_for_product(product_id=123456789, recommender=rec)
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_API_VERSION = "2024-01"


class ShopifyConnector:
    """Async connector to the Shopify Admin REST API.

    Args:
        store_url: Shopify store domain (e.g. ``mystore.myshopify.com``).
        token:     Shopify Admin API access token (``shpat_…``).
        api_version: API version to use (default: ``2024-01``).
    """

    def __init__(
        self,
        store_url: str,
        token: str,
        api_version: str = _API_VERSION,
    ) -> None:
        host = store_url.rstrip("/")
        if not host.startswith("https://"):
            host = f"https://{host}"
        self._base = f"{host}/admin/api/{api_version}"
        self._headers = {
            "X-Shopify-Access-Token": token,
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _get_all(self, endpoint: str, key: str, limit: int = 250) -> list[dict[str, Any]]:
        """Paginate through all pages of a Shopify REST endpoint."""
        results: list[dict[str, Any]] = []
        url: str | None = f"{self._base}/{endpoint}.json?limit={limit}"

        async with httpx.AsyncClient(headers=self._headers, timeout=30) as client:
            while url:
                resp = client.get(url)
                # Use sync-style in tests; in production callers should await
                # We keep the implementation simple with httpx's sync client
                # for broader compatibility.  Callers may use asyncio.run().
                raise NotImplementedError(  # pragma: no cover
                    "Use fetch_products_sync / fetch_orders_sync for synchronous use, "
                    "or call _get_all_sync directly."
                )

        return results  # pragma: no cover

    def _get_all_sync(self, endpoint: str, key: str, limit: int = 250) -> list[dict[str, Any]]:
        """Paginate through all pages synchronously via httpx."""
        results: list[dict[str, Any]] = []
        url: str | None = f"{self._base}/{endpoint}.json?limit={limit}"

        with httpx.Client(headers=self._headers, timeout=30) as client:
            while url:
                resp = client.get(url)
                resp.raise_for_status()
                data = resp.json()
                page_items: list[dict[str, Any]] = data.get(key, [])
                results.extend(page_items)

                # Follow Link header for cursor-based pagination
                link_header = resp.headers.get("link", "")
                url = _parse_next_link(link_header)

        return results

    # ------------------------------------------------------------------
    # Products
    # ------------------------------------------------------------------

    def fetch_products(self, limit: int = 250) -> list[dict[str, Any]]:
        """Fetch all published products from the Shopify store.

        Returns:
            List of item dicts compatible with NeuroMesh ``train()``.
        """
        raw = self._get_all_sync("products", "products", limit=limit)
        items: list[dict[str, Any]] = []

        for p in raw:
            # Flatten variant prices — use the lowest variant price
            prices = [float(v.get("price") or 0) for v in p.get("variants", []) if v.get("price")]
            price = min(prices) if prices else 0.0

            # Collect tags
            tags = [t.strip() for t in (p.get("tags") or "").split(",") if t.strip()]

            items.append(
                {
                    "id": f"shopify-product-{p['id']}",
                    "title": p.get("title") or "",
                    "description": _strip_html(p.get("body_html") or ""),
                    "category": p.get("product_type") or "",
                    "vendor": p.get("vendor") or "",
                    "tags": tags,
                    "price": price,
                    "created_at": p.get("created_at") or "",
                    "_shopify_id": p["id"],
                }
            )

        logger.info("Fetched %d products from Shopify", len(items))
        return items

    # ------------------------------------------------------------------
    # Orders → interactions
    # ------------------------------------------------------------------

    def fetch_orders(
        self,
        status: str = "any",
        limit: int = 250,
    ) -> list[dict[str, Any]]:
        """Fetch orders and convert line items to user-item interactions.

        Args:
            status: Shopify order status filter (``any``, ``open``, ``closed``).
            limit:  Page size (max 250).

        Returns:
            List of interaction dicts with ``user_id``, ``item_id``,
            ``action``, ``score``.
        """
        raw = self._get_all_sync(f"orders?status={status}", "orders", limit=limit)
        interactions: list[dict[str, Any]] = []

        for order in raw:
            customer = order.get("customer") or {}
            customer_id = customer.get("id") or order.get("id")
            user_id = f"shopify-customer-{customer_id}"

            for line in order.get("line_items", []):
                product_id = line.get("product_id")
                if product_id is None:
                    continue
                qty = float(line.get("quantity") or 1)
                interactions.append(
                    {
                        "user_id": user_id,
                        "item_id": f"shopify-product-{product_id}",
                        "action": "purchase",
                        "score": min(qty, 5.0),
                    }
                )

        logger.info("Fetched %d interactions from Shopify orders", len(interactions))
        return interactions

    # ------------------------------------------------------------------
    # Recommendation helpers
    # ------------------------------------------------------------------

    def recommend_for_product(
        self,
        product_id: int,
        recommender: Any,
        top_k: int = 5,
    ) -> list[dict[str, Any]]:
        """Return NeuroMesh recommendations for a Shopify product.

        Args:
            product_id:   Shopify integer product ID.
            recommender:  Fitted ``neuromesh.Recommender`` instance.
            top_k:        Number of results.
        """
        item_id = f"shopify-product-{product_id}"
        results = recommender.recommend(item_id, top_k=top_k)
        return [{"item_id": r.item_id, "score": r.score} for r in results]

    # ------------------------------------------------------------------
    # Dunder
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"ShopifyConnector(base={self._base!r})"


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _strip_html(html: str) -> str:
    """Remove HTML tags from a string."""
    import re

    return re.sub(r"<[^>]+>", " ", html).strip()


def _parse_next_link(link_header: str) -> str | None:
    """Parse the ``Link`` header and return the 'next' URL if present."""
    for part in link_header.split(","):
        part = part.strip()
        if 'rel="next"' in part:
            url_part = part.split(";")[0].strip()
            return url_part.strip("<>")
    return None
