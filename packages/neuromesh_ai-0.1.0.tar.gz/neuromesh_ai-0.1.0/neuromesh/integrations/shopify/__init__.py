﻿"""Shopify integration for NeuroMesh AI."""

from neuromesh.integrations.shopify.connector import ShopifyConnector

__all__ = ["ShopifyConnector"]
