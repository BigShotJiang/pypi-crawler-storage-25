﻿"""Generic custom data connector for NeuroMesh AI."""

from neuromesh.integrations.custom.connector import CustomConnector

__all__ = ["CustomConnector"]
