"""Generic custom data connector for NeuroMesh AI.

Loads item catalogues and interaction histories from CSV files, JSON files,
or in-memory pandas DataFrames.

Usage::

    from neuromesh.integrations.custom.connector import CustomConnector

    conn = CustomConnector()

    # From CSV
    items        = conn.load_items_from_csv("products.csv")
    interactions = conn.load_interactions_from_csv("events.csv")

    # From JSON
    items = conn.load_items_from_json("products.json")

    # From a pandas DataFrame (optional dependency)
    import pandas as pd
    df = pd.read_parquet("products.parquet")
    items = conn.load_items_from_dataframe(df)
"""

from __future__ import annotations

import csv
import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from neuromesh.utils.exceptions import InvalidItemSchemaError

if TYPE_CHECKING:
    import pandas as pd  # noqa: F401 — type-check only

logger = logging.getLogger(__name__)

# Required field for items
_ITEM_ID_FIELD = "id"

# Required fields for interactions
_INTERACTION_REQUIRED = {"user_id", "item_id"}


class CustomConnector:
    """Generic connector that loads data from local files or DataFrames.

    All ``load_*`` methods return plain Python dicts compatible with
    NeuroMesh ``Recommender.train()`` and interaction APIs.
    """

    # ------------------------------------------------------------------
    # CSV loaders
    # ------------------------------------------------------------------

    def load_items_from_csv(
        self,
        path: str | Path,
        id_field: str = "id",
        encoding: str = "utf-8",
    ) -> list[dict[str, Any]]:
        """Load items from a CSV file.

        The CSV must contain a column named ``id`` (configurable via
        ``id_field``). All other columns are carried through as metadata.

        Args:
            path:     Path to the CSV file.
            id_field: Column name to use as the item ``id``.
            encoding: File encoding (default ``utf-8``).

        Returns:
            List of item dicts with at least an ``id`` key.
        """
        items: list[dict[str, Any]] = []
        p = Path(path)

        with p.open(encoding=encoding, newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                item = dict(row)
                # Rename id_field → "id" if needed
                if id_field != "id" and id_field in item:
                    item["id"] = item.pop(id_field)
                if not item.get("id"):
                    raise InvalidItemSchemaError(f"Row missing required field '{id_field}': {row}")
                items.append(item)

        logger.info("Loaded %d items from CSV: %s", len(items), p)
        return items

    def load_interactions_from_csv(
        self,
        path: str | Path,
        encoding: str = "utf-8",
    ) -> list[dict[str, Any]]:
        """Load user-item interactions from a CSV file.

        Required columns: ``user_id``, ``item_id``.
        Optional columns: ``action`` (default ``"view"``), ``score`` (default ``1.0``).

        Args:
            path:     Path to the CSV file.
            encoding: File encoding.
        """
        interactions: list[dict[str, Any]] = []
        p = Path(path)

        with p.open(encoding=encoding, newline="") as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader):
                missing = _INTERACTION_REQUIRED - set(row.keys())
                if missing:
                    raise InvalidItemSchemaError(f"Row {i} missing required columns: {missing}")
                interactions.append(
                    {
                        "user_id": row["user_id"],
                        "item_id": row["item_id"],
                        "action": row.get("action") or "view",
                        "score": float(row["score"]) if row.get("score") else 1.0,
                    }
                )

        logger.info("Loaded %d interactions from CSV: %s", len(interactions), p)
        return interactions

    # ------------------------------------------------------------------
    # JSON loaders
    # ------------------------------------------------------------------

    def load_items_from_json(
        self,
        path: str | Path,
        id_field: str = "id",
        encoding: str = "utf-8",
    ) -> list[dict[str, Any]]:
        """Load items from a JSON file.

        The JSON must be a top-level array of objects, each with an ``id``
        field (configurable via ``id_field``).

        Args:
            path:     Path to the JSON file.
            id_field: Key to use as the item ``id``.
            encoding: File encoding.
        """
        p = Path(path)
        with p.open(encoding=encoding) as f:
            data: Any = json.load(f)

        if not isinstance(data, list):
            raise ValueError(f"Expected a JSON array at top level, got {type(data).__name__}")

        items: list[dict[str, Any]] = []
        for obj in data:
            if not isinstance(obj, dict):
                raise ValueError(f"Expected JSON objects in array, got {type(obj).__name__}")
            if id_field != "id" and id_field in obj:
                obj = dict(obj)
                obj["id"] = obj.pop(id_field)
            if not obj.get("id"):
                raise InvalidItemSchemaError(f"Object missing required field '{id_field}': {obj}")
            items.append(obj)

        logger.info("Loaded %d items from JSON: %s", len(items), p)
        return items

    def load_interactions_from_json(
        self,
        path: str | Path,
        encoding: str = "utf-8",
    ) -> list[dict[str, Any]]:
        """Load interactions from a JSON file (top-level array).

        Each object must have ``user_id`` and ``item_id`` keys.
        """
        p = Path(path)
        with p.open(encoding=encoding) as f:
            data: Any = json.load(f)

        if not isinstance(data, list):
            raise ValueError(f"Expected a JSON array, got {type(data).__name__}")

        interactions: list[dict[str, Any]] = []
        for i, obj in enumerate(data):
            missing = _INTERACTION_REQUIRED - set(obj.keys())
            if missing:
                raise InvalidItemSchemaError(f"Object {i} missing required keys: {missing}")
            interactions.append(
                {
                    "user_id": obj["user_id"],
                    "item_id": obj["item_id"],
                    "action": obj.get("action") or "view",
                    "score": float(obj["score"]) if obj.get("score") else 1.0,
                }
            )

        logger.info("Loaded %d interactions from JSON: %s", len(interactions), p)
        return interactions

    # ------------------------------------------------------------------
    # DataFrame loader (optional pandas dependency)
    # ------------------------------------------------------------------

    def load_items_from_dataframe(
        self,
        df: Any,
        id_field: str = "id",
    ) -> list[dict[str, Any]]:
        """Load items from a pandas DataFrame.

        Args:
            df:       A ``pandas.DataFrame`` with at least an ``id`` column.
            id_field: Column to use as the item ``id``.

        Raises:
            ImportError: If pandas is not installed.
        """
        try:
            import pandas as pd  # noqa: PLC0415
        except ImportError as exc:
            raise ImportError(
                "pandas is required for load_items_from_dataframe. "
                "Install it with: pip install pandas"
            ) from exc

        if not isinstance(df, pd.DataFrame):
            raise TypeError(f"Expected a pandas DataFrame, got {type(df).__name__}")

        if id_field not in df.columns:
            raise InvalidItemSchemaError(f"DataFrame missing required column '{id_field}'")

        records = df.to_dict(orient="records")
        items: list[dict[str, Any]] = []
        for record in records:
            item = {str(k): v for k, v in record.items()}
            if id_field != "id":
                item["id"] = item.pop(id_field)
            if not item.get("id"):
                raise InvalidItemSchemaError(f"Row missing value in '{id_field}' column")
            items.append(item)

        logger.info("Loaded %d items from DataFrame", len(items))
        return items

    def load_interactions_from_dataframe(
        self,
        df: Any,
    ) -> list[dict[str, Any]]:
        """Load interactions from a pandas DataFrame.

        Required columns: ``user_id``, ``item_id``.
        Optional: ``action``, ``score``.
        """
        try:
            import pandas as pd  # noqa: PLC0415
        except ImportError as exc:
            raise ImportError("pandas is required. Install: pip install pandas") from exc

        if not isinstance(df, pd.DataFrame):
            raise TypeError(f"Expected a pandas DataFrame, got {type(df).__name__}")

        missing = _INTERACTION_REQUIRED - set(df.columns)
        if missing:
            raise InvalidItemSchemaError(f"DataFrame missing required columns: {missing}")

        import math  # noqa: PLC0415

        records = df.to_dict(orient="records")
        interactions: list[dict[str, Any]] = []
        for record in records:
            raw_score = record.get("score")
            try:
                score = (
                    float(raw_score)
                    if raw_score is not None and not math.isnan(float(raw_score))
                    else 1.0
                )
            except (TypeError, ValueError):
                score = 1.0
            raw_action = record.get("action")
            action = str(raw_action) if raw_action and str(raw_action) != "nan" else "view"
            interactions.append(
                {
                    "user_id": str(record["user_id"]),
                    "item_id": str(record["item_id"]),
                    "action": action,
                    "score": score,
                }
            )

        logger.info("Loaded %d interactions from DataFrame", len(interactions))
        return interactions

    # ------------------------------------------------------------------
    # Dunder
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return "CustomConnector()"
