"""Redis-backed recommendation cache for NeuroMesh AI.

Caches recommendation results with configurable TTL and pattern-based
invalidation.  Gracefully degrades to a no-op when Redis is unavailable —
callers never need to handle cache exceptions.

Usage::

    cache = RecommendationCache("redis://localhost:6379/0")
    await cache.connect()

    key = RecommendationCache.make_key("tfidf", "item-123", 10)
    results = await cache.get(key)
    if results is None:
        results = engine.recommend("item-123", top_k=10)
        await cache.set(key, results, ttl=300)

    await cache.close()
"""

from __future__ import annotations

import json
from typing import Any

from neuromesh.engines.base_engine import RecommendationResult
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)

_CACHE_PREFIX = "neuromesh:rec"
_USER_PREFIX = "neuromesh:user"


class RecommendationCache:
    """Async Redis cache for recommendation results.

    Uses ``redis.asyncio`` with connection pooling.  All public methods
    swallow exceptions so a Redis outage never surfaces to the caller —
    only a ``WARNING`` log entry is emitted on connection failure and
    ``DEBUG`` entries on individual operation failures.

    Attributes:
        _url:    Redis connection URL.
        _client: Underlying ``redis.asyncio.Redis`` instance, or ``None``
                 when Redis is unavailable.
    """

    def __init__(self, redis_url: str = "redis://localhost:6379/0") -> None:
        self._url = redis_url
        self._client: Any = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Open the Redis connection pool and verify connectivity.

        Logs a warning and sets ``_client = None`` if Redis is unreachable
        so the cache operates silently in degraded (no-op) mode.
        """
        try:
            import redis.asyncio as aioredis

            self._client = aioredis.from_url(
                self._url,
                encoding="utf-8",
                decode_responses=True,
                max_connections=20,
            )
            await self._client.ping()
            logger.info("Redis cache connected: %s", self._url)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Redis unavailable — cache disabled: %s", exc)
            self._client = None

    async def close(self) -> None:
        """Close the Redis connection pool."""
        if self._client is not None:
            try:
                await self._client.aclose()
            except Exception:  # noqa: BLE001
                pass
            self._client = None

    # ------------------------------------------------------------------
    # Cache key helpers
    # ------------------------------------------------------------------

    @staticmethod
    def make_key(engine: str, item_id: str, top_k: int) -> str:
        """Build a canonical item-based cache key.

        Args:
            engine:  Engine name (e.g. ``"tfidf"``, ``"hybrid"``).
            item_id: The seed item identifier.
            top_k:   Number of results requested.

        Returns:
            Cache key: ``neuromesh:rec:{engine}:{item_id}:{top_k}``.
        """
        return f"{_CACHE_PREFIX}:{engine}:{item_id}:{top_k}"

    @staticmethod
    def make_user_key(engine: str, user_id: str, top_k: int) -> str:
        """Build a canonical user-based cache key.

        Args:
            engine:  Engine name.
            user_id: The user identifier.
            top_k:   Number of results requested.

        Returns:
            Cache key: ``neuromesh:user:{engine}:{user_id}:{top_k}``.
        """
        return f"{_USER_PREFIX}:{engine}:{user_id}:{top_k}"

    # ------------------------------------------------------------------
    # Core operations
    # ------------------------------------------------------------------

    async def get(self, key: str) -> list[RecommendationResult] | None:
        """Retrieve cached recommendations.

        Args:
            key: Cache key produced by :meth:`make_key` or :meth:`make_user_key`.

        Returns:
            Deserialized list of :class:`RecommendationResult`, or ``None``
            on cache miss or any Redis error.
        """
        if self._client is None:
            return None
        try:
            raw = await self._client.get(key)
            if raw is None:
                return None
            data: list[dict[str, Any]] = json.loads(raw)
            return [RecommendationResult(**item) for item in data]
        except Exception as exc:  # noqa: BLE001
            logger.debug("Cache get failed key=%s: %s", key, exc)
            return None

    async def set(
        self,
        key: str,
        results: list[RecommendationResult],
        ttl: int = 300,
    ) -> None:
        """Store recommendation results.

        Args:
            key:     Cache key produced by :meth:`make_key` or :meth:`make_user_key`.
            results: Results to cache.
            ttl:     Time-to-live in seconds (default 300 = 5 minutes).
        """
        if self._client is None:
            return
        try:
            payload = json.dumps([r.model_dump() for r in results])
            await self._client.setex(key, ttl, payload)
            logger.debug("Cached %d results key=%s ttl=%ds", len(results), key, ttl)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Cache set failed key=%s: %s", key, exc)

    async def invalidate(self, key: str) -> None:
        """Delete a single cache entry.

        Args:
            key: Cache key to remove.
        """
        if self._client is None:
            return
        try:
            await self._client.delete(key)
            logger.debug("Cache invalidated key=%s", key)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Cache invalidate failed key=%s: %s", key, exc)

    async def invalidate_user(self, user_id: str) -> None:
        """Delete all cache entries associated with a user.

        Uses Redis ``SCAN`` to avoid blocking the event loop.

        Args:
            user_id: The user whose cache entries should be purged.
        """
        if self._client is None:
            return
        pattern = f"{_USER_PREFIX}:*:{user_id}:*"
        try:
            async for key in self._client.scan_iter(pattern):
                await self._client.delete(key)
            logger.debug("Cache invalidated user=%s pattern=%s", user_id, pattern)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Cache invalidate_user failed user=%s: %s", user_id, exc)

    async def invalidate_item(self, item_id: str) -> None:
        """Delete all cache entries associated with an item.

        Uses Redis ``SCAN`` to avoid blocking the event loop.

        Args:
            item_id: The item whose cache entries should be purged.
        """
        if self._client is None:
            return
        pattern = f"{_CACHE_PREFIX}:*:{item_id}:*"
        try:
            async for key in self._client.scan_iter(pattern):
                await self._client.delete(key)
            logger.debug("Cache invalidated item=%s pattern=%s", item_id, pattern)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Cache invalidate_item failed item=%s: %s", item_id, exc)

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------

    @property
    def is_connected(self) -> bool:
        """Return ``True`` if Redis is reachable."""
        return self._client is not None

    def __repr__(self) -> str:
        status = "connected" if self.is_connected else "disconnected"
        return f"RecommendationCache(url={self._url!r}, status={status!r})"
