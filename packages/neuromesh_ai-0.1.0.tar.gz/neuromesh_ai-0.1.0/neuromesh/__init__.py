"""
NeuroMesh AI — Open-source universal recommendation infrastructure.

Usage::

    from neuromesh import Recommender

    rec = Recommender(engine="tfidf")
    rec.train(items)
    results = rec.recommend(item_id="item123", top_k=10)
"""

from neuromesh.recommender import Recommender

__version__ = "0.1.0"
__all__ = ["Recommender"]
