"""
NeuroMesh AI — Main Recommender class.

This is the primary SDK entry point. It wires together:
- Engine selection and instantiation
- Training pipeline (Trainer + engines)
- Post-engine ranking (Ranker)
- Serve mode (FastAPI via uvicorn)

Usage::

    from neuromesh import Recommender

    rec = Recommender(engine="tfidf")
    rec.train(items)

    results = rec.recommend("product_42", top_k=10)
    similar  = rec.similar("product_42", top_k=5)
    trending = rec.trending(top_k=20)
    explained = rec.explain("product_42")

    # Start the REST API server
    rec.serve(host="0.0.0.0", port=8000)
"""

from __future__ import annotations

import importlib
from typing import Any

from neuromesh.engines.base_engine import BaseEngine, RecommendationResult
from neuromesh.engines.tfidf_engine import TFIDFEngine
from neuromesh.engines.trending_engine import TrendingEngine
from neuromesh.ranking.ranker import Ranker
from neuromesh.training.trainer import Trainer
from neuromesh.utils.exceptions import EngineNotFittedError, ItemNotFoundError
from neuromesh.utils.logger import configure_logging, get_logger

logger = get_logger(__name__)

# Registry of built-in engine names → factory callables
_ENGINE_REGISTRY: dict[str, type[BaseEngine]] = {
    "tfidf": TFIDFEngine,
    "trending": TrendingEngine,
    # "embedding": resolved lazily (requires sentence-transformers)
    # "collaborative": resolved lazily (requires implicit)
    # "hybrid": resolved lazily (requires multiple extras)
}


def _resolve_engine(name: str, kwargs: dict[str, Any]) -> BaseEngine:
    """Instantiate an engine by name, supporting lazy imports for optional extras."""
    if name in _ENGINE_REGISTRY:
        return _ENGINE_REGISTRY[name](**kwargs)
    # Lazy-load Phase 2 engines
    if name == "embedding":
        module = importlib.import_module("neuromesh.engines.embedding_engine")
        return module.EmbeddingEngine(**kwargs)  # type: ignore[no-any-return]
    if name == "collaborative":
        module = importlib.import_module("neuromesh.engines.collaborative_engine")
        return module.CollaborativeEngine(**kwargs)  # type: ignore[no-any-return]
    if name == "hybrid":
        module = importlib.import_module("neuromesh.engines.hybrid_engine")
        return module.HybridEngine(**kwargs)  # type: ignore[no-any-return]
    raise ValueError(
        f"Unknown engine '{name}'. Available: tfidf, trending, embedding, collaborative, hybrid."
    )


class Recommender:
    """Universal recommendation engine with a simple, schema-agnostic API.

    Args:
        engine: Engine to use. One of: ``"tfidf"`` (default), ``"trending"``,
                ``"embedding"``, ``"collaborative"``, ``"hybrid"``.
        log_level: Logging level. Defaults to ``"INFO"``.
        production: If True, use JSON log format. Defaults to ``False``
                    (human-readable colored output).
        popularity_weight: Weight for popularity blending in the ranker.
            Defaults to 0.15.
        freshness_weight: Weight for freshness blending in the ranker.
            Defaults to 0.10.
        diversity_penalty: Per-extra-category penalty in the ranker.
            Defaults to 0.05.
        freshness_decay_days: Half-life in days for freshness scoring.
            Defaults to 30.
        **engine_kwargs: Additional keyword arguments forwarded to the engine
            constructor (e.g. ``max_features`` for TFIDFEngine).

    Example::

        rec = Recommender(engine="tfidf", max_features=20_000)
        rec.train([
            {"id": "1", "title": "Gaming Laptop", "category": "electronics"},
            {"id": "2", "title": "Gaming Mouse",  "category": "electronics"},
            {"id": "3", "title": "Python Book",   "category": "books"},
        ])
        rec.recommend("1", top_k=5)
    """

    def __init__(
        self,
        engine: str = "tfidf",
        log_level: str = "INFO",
        production: bool = False,
        popularity_weight: float = 0.15,
        freshness_weight: float = 0.10,
        diversity_penalty: float = 0.05,
        freshness_decay_days: int = 30,
        **engine_kwargs: Any,
    ) -> None:
        configure_logging(level=log_level, production=production)
        self._engine_name = engine
        self._engine: BaseEngine = _resolve_engine(engine, engine_kwargs)
        self._trainer = Trainer(freshness_decay_days=freshness_decay_days)
        self._ranker = Ranker(
            popularity_weight=popularity_weight,
            freshness_weight=freshness_weight,
            diversity_penalty=diversity_penalty,
        )
        self._items: list[dict[str, Any]] = []
        self._items_by_id: dict[str, dict[str, Any]] = {}
        self._popularity_scores: dict[str, float] = {}
        self._freshness_scores: dict[str, float] = {}
        self._trending_engine: TrendingEngine | None = None

    # ------------------------------------------------------------------
    # Training
    # ------------------------------------------------------------------

    def train(
        self,
        items: list[dict[str, Any]],
        interactions: list[dict[str, Any]] | None = None,
    ) -> "Recommender":
        """Train the engine on the provided items.

        Args:
            items:        Raw item dicts. Only ``id`` is required.
            interactions: Optional list of user-item interaction dicts
                          (used by collaborative and hybrid engines).

        Returns:
            self — enables method chaining: ``rec.train(items).recommend("1")``.

        Raises:
            ValueError: If ``items`` is empty.
            InvalidItemSchemaError: If any item lacks a valid ``id``.
        """
        validated = self._trainer.train(self._engine, items, interactions)
        self._items = validated
        self._items_by_id = {item["id"]: item for item in validated}

        # Cache popularity + freshness for the ranker
        fb = self._trainer._feature_builder
        self._popularity_scores = fb.build_popularity_scores(validated)
        self._freshness_scores = fb.build_freshness_scores(validated)

        # Always maintain a separate TrendingEngine for .trending() calls
        if not isinstance(self._engine, TrendingEngine):
            self._trending_engine = TrendingEngine()
            self._trainer.train(self._trending_engine, items, interactions)

        return self

    # ------------------------------------------------------------------
    # Core recommendation methods
    # ------------------------------------------------------------------

    def recommend(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return top-K items most relevant to ``item_id``.

        Delegates to the configured engine then applies the ranking pipeline
        (popularity blend, freshness blend, diversity penalty).

        Args:
            item_id:     The seed item ID.
            top_k:       Maximum number of results. Defaults to 10.
            exclude_ids: Item IDs to exclude from results.

        Returns:
            list[RecommendationResult]: Sorted descending by final score.

        Raises:
            EngineNotFittedError: If ``train()`` has not been called.
            ItemNotFoundError:    If ``item_id`` is unknown.
        """
        self._assert_fitted()
        if item_id not in self._items_by_id:
            raise ItemNotFoundError(item_id=item_id)

        # Fetch more candidates than needed so the ranker has room to re-rank
        candidates = self._engine.recommend(item_id, top_k=top_k * 3, exclude_ids=exclude_ids)
        return self._ranker.rank(
            candidates,
            top_k=top_k,
            popularity_scores=self._popularity_scores,
            freshness_scores=self._freshness_scores,
            items_by_id=self._items_by_id,
        )

    def recommend_for_user(
        self,
        user_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return personalized recommendations for a user.

        Requires a collaborative or hybrid engine. Raises ``NotImplementedError``
        if the configured engine doesn't support user-based recommendations.

        Args:
            user_id:     The user to recommend items for.
            top_k:       Maximum number of results.
            exclude_ids: Items to exclude.

        Returns:
            list[RecommendationResult]: Sorted descending by final score.
        """
        self._assert_fitted()
        candidates = self._engine.recommend_for_user(
            user_id, top_k=top_k * 3, exclude_ids=exclude_ids
        )
        return self._ranker.rank(
            candidates,
            top_k=top_k,
            popularity_scores=self._popularity_scores,
            freshness_scores=self._freshness_scores,
            items_by_id=self._items_by_id,
        )

    def similar(
        self,
        item_id: str,
        top_k: int = 10,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return items similar to ``item_id`` (alias for ``recommend``).

        Args:
            item_id:     The seed item.
            top_k:       Maximum number of results.
            exclude_ids: Items to exclude.

        Returns:
            list[RecommendationResult]: Sorted descending by final score.
        """
        return self.recommend(item_id, top_k=top_k, exclude_ids=exclude_ids)

    def trending(
        self,
        top_k: int = 10,
        category: str | None = None,
        exclude_ids: list[str] | None = None,
    ) -> list[RecommendationResult]:
        """Return top-K currently trending items.

        Uses the internal ``TrendingEngine`` (always available regardless of
        the configured primary engine).

        Args:
            top_k:       Maximum number of results.
            category:    Optional category filter (case-insensitive).
            exclude_ids: Items to exclude.

        Returns:
            list[RecommendationResult]: Sorted descending by trending score.

        Raises:
            EngineNotFittedError: If ``train()`` has not been called.
        """
        self._assert_fitted()
        te = self._trending_engine if self._trending_engine else self._engine
        if not isinstance(te, TrendingEngine):
            raise EngineNotFittedError(engine_name="trending")
        return te.trending(top_k=top_k, category=category, exclude_ids=exclude_ids)

    def explain(
        self,
        item_id: str,
        top_k: int = 10,
    ) -> dict[str, Any]:
        """Return recommendations for ``item_id`` with human-readable explanations.

        In Phase 1, explanations are basic (engine name + score). The full
        explainability module is implemented in Phase 2.

        Args:
            item_id: The seed item to explain recommendations for.
            top_k:   Number of results to explain.

        Returns:
            dict: ``{"item_id": ..., "engine": ..., "recommendations": [...]}``,
                  where each recommendation includes an ``explanation`` dict.
        """
        self._assert_fitted()
        results = self.recommend(item_id, top_k=top_k)
        seed_item = self._items_by_id.get(item_id, {})

        explained = []
        for r in results:
            candidate_item = self._items_by_id.get(r.item_id, {})
            explanation = {
                "engine": r.engine,
                "score": r.score,
                "reason": f"Similar to '{seed_item.get('title') or item_id}' based on content.",
                "matched_fields": [
                    f
                    for f in ("title", "category", "tags", "description")
                    if seed_item.get(f) and candidate_item.get(f)
                ],
            }
            explained.append(r.model_copy(update={"explanation": explanation}))

        return {
            "item_id": item_id,
            "engine": self._engine_name,
            "recommendations": [e.model_dump() for e in explained],
        }

    # ------------------------------------------------------------------
    # Incremental learning
    # ------------------------------------------------------------------

    def add_item(self, item: dict[str, Any]) -> "Recommender":
        """Incrementally add a new item without full retraining.

        Args:
            item: Item dict with at least an ``id`` field.

        Returns:
            self — enables chaining.
        """
        self._assert_fitted()
        self._engine.add_item(item)
        return self

    def add_interaction(self, user_id: str, item_id: str, weight: float = 1.0) -> "Recommender":
        """Record a user-item interaction.

        Args:
            user_id:  The interacting user.
            item_id:  The item that was interacted with.
            weight:   Interaction weight (1.0 = view, 2.0 = purchase, etc.).

        Returns:
            self — enables chaining.
        """
        self._assert_fitted()
        self._engine.add_interaction(user_id, item_id, weight)
        return self

    # ------------------------------------------------------------------
    # Serving
    # ------------------------------------------------------------------

    def serve(
        self,
        host: str = "0.0.0.0",
        port: int = 8000,
        reload: bool = False,
    ) -> None:
        """Start the FastAPI REST API server (implemented in Phase 1.8).

        Args:
            host:   Bind host. Defaults to ``"0.0.0.0"``.
            port:   Bind port. Defaults to ``8000``.
            reload: Enable uvicorn auto-reload. Defaults to ``False``.
        """
        try:
            import uvicorn

            from neuromesh.api.server import build_app
        except ImportError as exc:
            raise ImportError(
                "FastAPI and uvicorn are required for serve(). "
                "Install with: pip install neuromesh-ai"
            ) from exc

        app = build_app(recommender=self)
        logger.info("Starting NeuroMesh AI server on %s:%d", host, port)
        uvicorn.run(app, host=host, port=port, reload=reload)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _assert_fitted(self) -> None:
        if not self._engine.is_fitted:
            raise EngineNotFittedError(engine_name=self._engine_name)

    def __repr__(self) -> str:
        fitted = self._engine.is_fitted
        return (
            f"Recommender(engine={self._engine_name!r}, "
            f"items={len(self._items)}, fitted={fitted})"
        )
