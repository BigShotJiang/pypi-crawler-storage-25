"""
Configuration management for NeuroMesh AI.

All configuration is loaded from environment variables using pydantic-settings.
Copy .env.example to .env and fill in your values — never hardcode secrets.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application-wide settings loaded from environment variables.

    All fields map directly to the environment variables documented in
    ``.env.example``. Sensitive fields (API keys, DB passwords) must
    never be hardcoded or logged.

    Example::

        from neuromesh.config.settings import get_settings

        settings = get_settings()
        print(settings.port)  # 8000
    """

    model_config = SettingsConfigDict(
        env_prefix="NEUROMESH_",
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Core ──────────────────────────────────────────────────────────────────
    env: Literal["development", "production"] = Field(
        default="development",
        description="Runtime environment. Controls logging format and error verbosity.",
    )
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = Field(
        default="INFO",
        description="Logging verbosity level.",
    )

    # ── API Server ─────────────────────────────────────────────────────────────
    host: str = Field(default="0.0.0.0", description="FastAPI bind host.")
    port: int = Field(default=8000, ge=1, le=65535, description="FastAPI bind port.")
    api_key: str = Field(
        default="",
        description="Secret API key for X-API-Key authentication. Must be set in production.",
    )
    cors_origins: list[str] = Field(
        default=["http://localhost:3000", "http://localhost:8000"],
        description="Allowed CORS origins. Never use ['*'] in production.",
    )

    # ── Database ───────────────────────────────────────────────────────────────
    database_url: str = Field(
        default="",
        description="Async PostgreSQL connection URL (postgresql+asyncpg://...).",
    )

    # ── Redis ──────────────────────────────────────────────────────────────────
    redis_url: str = Field(
        default="redis://localhost:6379/0",
        description="Redis connection URL.",
    )

    # ── Vector Store ───────────────────────────────────────────────────────────
    vector_store: Literal["faiss", "qdrant", "chroma"] = Field(
        default="faiss",
        description="Vector store backend to use.",
    )
    qdrant_url: str = Field(
        default="http://localhost:6333",
        description="Qdrant server URL (only used when VECTOR_STORE=qdrant).",
    )
    qdrant_collection: str = Field(
        default="neuromesh",
        description="Qdrant collection name.",
    )
    qdrant_api_key: str = Field(
        default="",
        description="Qdrant API key (leave empty for local unauthenticated Qdrant).",
    )

    # ── Embeddings ─────────────────────────────────────────────────────────────
    embedding_model: str = Field(
        default="all-MiniLM-L6-v2",
        description="sentence-transformers model name for semantic embeddings.",
    )

    # ── Rate Limiting ──────────────────────────────────────────────────────────
    rate_limit_per_minute: int = Field(
        default=60,
        ge=1,
        description="Maximum API requests per minute per IP address.",
    )

    @field_validator("cors_origins", mode="before")
    @classmethod
    def parse_cors_origins(cls, v: object) -> list[str]:
        """Accept comma-separated string or list for CORS origins."""
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",") if origin.strip()]
        return v  # type: ignore[return-value]

    @property
    def is_production(self) -> bool:
        """Return True when running in production mode."""
        return self.env == "production"

    @property
    def is_development(self) -> bool:
        """Return True when running in development mode."""
        return self.env == "development"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return a cached singleton Settings instance.

    Uses ``@lru_cache`` so the .env file is read only once per process.

    Returns:
        Settings: The application settings instance.

    Example::

        from neuromesh.config.settings import get_settings

        settings = get_settings()
    """
    return Settings()
