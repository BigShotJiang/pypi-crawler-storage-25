"""
FastAPI route handlers for the NeuroMesh AI REST API.

All routes are defined on an ``APIRouter`` and mounted by ``server.py``.
The router receives the ``Recommender`` instance via FastAPI's dependency
injection system (``request.app.state.recommender``).

Endpoints
---------
GET  /health                   — Health check
POST /train                    — Train the engine
POST /recommend                — Item-based recommendations
POST /recommend/user           — User-based recommendations
POST /recommend/trending       — Trending items
POST /recommend/explain        — Recommendations with explanations
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, status

from neuromesh.api.models import (
    ErrorResponse,
    ExplainResponse,
    HealthResponse,
    RecommendationItem,
    RecommendRequest,
    RecommendResponse,
    TrainRequest,
    TrainResponse,
    TrendingRequest,
    UserRecommendRequest,
)
from neuromesh.utils.exceptions import (
    EngineNotFittedError,
    InvalidItemSchemaError,
    ItemNotFoundError,
    NeuroMeshError,
    UserNotFoundError,
)
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)

router = APIRouter()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_recommender(request: Request) -> Any:
    """FastAPI dependency — retrieves the shared Recommender from app state."""
    return request.app.state.recommender


def _get_auth(request: Request) -> Any:
    """FastAPI dependency — retrieves the API key checker from app state."""
    return request.app.state.auth_checker


def _neuromesh_error_to_http(exc: NeuroMeshError) -> HTTPException:
    """Convert a NeuroMeshError into the appropriate HTTPException."""
    if isinstance(exc, (ItemNotFoundError, UserNotFoundError)):
        code = status.HTTP_404_NOT_FOUND
    elif isinstance(exc, EngineNotFittedError):
        code = status.HTTP_503_SERVICE_UNAVAILABLE
    elif isinstance(exc, InvalidItemSchemaError):
        code = status.HTTP_422_UNPROCESSABLE_ENTITY
    else:
        code = status.HTTP_500_INTERNAL_SERVER_ERROR
    return HTTPException(status_code=code, detail=exc.to_dict())


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Health check",
    tags=["system"],
)
async def health(rec: Any = Depends(_get_recommender)) -> HealthResponse:
    """Return API health status, version, and whether the engine is fitted."""
    from neuromesh import __version__

    return HealthResponse(
        status="ok",
        version=__version__,
        engine=rec._engine_name,
        fitted=rec._engine.is_fitted,
    )


@router.post(
    "/train",
    response_model=TrainResponse,
    status_code=status.HTTP_200_OK,
    summary="Train the recommendation engine",
    tags=["training"],
)
async def train(
    body: TrainRequest,
    rec: Any = Depends(_get_recommender),
    _auth: Any = Depends(_get_auth),
) -> TrainResponse:
    """Train or re-train the engine on the provided items and interactions."""
    try:
        rec.train(body.items, body.interactions or None)
    except (ValueError, InvalidItemSchemaError) as exc:
        if isinstance(exc, InvalidItemSchemaError):
            raise _neuromesh_error_to_http(exc) from exc
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        ) from exc

    logger.info("Engine retrained via API — items=%d", len(rec._items))
    return TrainResponse(items_trained=len(rec._items), engine=rec._engine_name)


@router.post(
    "/recommend",
    response_model=RecommendResponse,
    summary="Item-based recommendations",
    tags=["recommendations"],
)
async def recommend(
    body: RecommendRequest,
    rec: Any = Depends(_get_recommender),
    _auth: Any = Depends(_get_auth),
) -> RecommendResponse:
    """Return top-K items most relevant to the given seed item."""
    try:
        results = rec.recommend(body.item_id, top_k=body.top_k, exclude_ids=body.exclude_ids)
    except NeuroMeshError as exc:
        raise _neuromesh_error_to_http(exc) from exc

    items = [
        RecommendationItem(
            item_id=r.item_id,
            score=r.score,
            engine=r.engine,
            explanation=r.explanation,
            metadata=r.metadata,
        )
        for r in results
    ]
    return RecommendResponse(results=items, count=len(items), engine=rec._engine_name)


@router.post(
    "/recommend/user",
    response_model=RecommendResponse,
    summary="User-based recommendations",
    tags=["recommendations"],
)
async def recommend_for_user(
    body: UserRecommendRequest,
    rec: Any = Depends(_get_recommender),
    _auth: Any = Depends(_get_auth),
) -> RecommendResponse:
    """Return personalized recommendations for a user (requires collaborative engine)."""
    try:
        results = rec.recommend_for_user(
            body.user_id, top_k=body.top_k, exclude_ids=body.exclude_ids
        )
    except NotImplementedError as exc:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail={"error": str(exc), "code": "not_implemented"},
        ) from exc
    except NeuroMeshError as exc:
        raise _neuromesh_error_to_http(exc) from exc

    items = [RecommendationItem(item_id=r.item_id, score=r.score, engine=r.engine) for r in results]
    return RecommendResponse(results=items, count=len(items), engine=rec._engine_name)


@router.post(
    "/recommend/trending",
    response_model=RecommendResponse,
    summary="Trending items",
    tags=["recommendations"],
)
async def trending(
    body: TrendingRequest,
    rec: Any = Depends(_get_recommender),
    _auth: Any = Depends(_get_auth),
) -> RecommendResponse:
    """Return top-K trending items, optionally filtered by category."""
    try:
        results = rec.trending(
            top_k=body.top_k,
            category=body.category,
            exclude_ids=body.exclude_ids,
        )
    except NeuroMeshError as exc:
        raise _neuromesh_error_to_http(exc) from exc

    items = [RecommendationItem(item_id=r.item_id, score=r.score, engine=r.engine) for r in results]
    return RecommendResponse(results=items, count=len(items), engine=rec._engine_name)


@router.post(
    "/recommend/explain",
    response_model=ExplainResponse,
    summary="Recommendations with explanations",
    tags=["recommendations"],
)
async def explain(
    body: RecommendRequest,
    rec: Any = Depends(_get_recommender),
    _auth: Any = Depends(_get_auth),
) -> ExplainResponse:
    """Return recommendations for the seed item with human-readable explanations."""
    try:
        result = rec.explain(body.item_id, top_k=body.top_k)
    except NeuroMeshError as exc:
        raise _neuromesh_error_to_http(exc) from exc

    return ExplainResponse(
        item_id=result["item_id"],
        engine=result["engine"],
        recommendations=result["recommendations"],
    )
