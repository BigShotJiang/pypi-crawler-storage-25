"""
Pydantic request/response models for the NeuroMesh AI REST API.

All request bodies and response shapes are defined here so that
FastAPI can generate accurate OpenAPI documentation automatically.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------


class RecommendRequest(BaseModel):
    """Request body for item-based recommendations."""

    item_id: str = Field(..., description="Seed item ID to find recommendations for.")
    top_k: int = Field(10, ge=1, le=200, description="Maximum number of results.")
    exclude_ids: list[str] = Field(
        default_factory=list,
        description="Item IDs to exclude from results.",
    )


class UserRecommendRequest(BaseModel):
    """Request body for user-based recommendations."""

    user_id: str = Field(..., description="User ID to recommend items for.")
    top_k: int = Field(10, ge=1, le=200, description="Maximum number of results.")
    exclude_ids: list[str] = Field(default_factory=list)


class TrendingRequest(BaseModel):
    """Request body for trending items."""

    top_k: int = Field(10, ge=1, le=200)
    category: str | None = Field(None, description="Optional category filter.")
    exclude_ids: list[str] = Field(default_factory=list)


class TrainRequest(BaseModel):
    """Request body for training the recommendation engine."""

    items: list[dict[str, Any]] = Field(
        ...,
        min_length=1,
        description="List of item dicts. Each must have an 'id' field.",
    )
    interactions: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Optional user-item interaction records.",
    )


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class RecommendationItem(BaseModel):
    """A single recommendation in an API response."""

    item_id: str
    score: float
    engine: str
    explanation: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class RecommendResponse(BaseModel):
    """Standard recommendations response envelope."""

    results: list[RecommendationItem]
    count: int
    engine: str


class ExplainResponse(BaseModel):
    """Explain endpoint response."""

    item_id: str
    engine: str
    recommendations: list[dict[str, Any]]


class TrainResponse(BaseModel):
    """Response returned after a successful training call."""

    status: str = "ok"
    items_trained: int
    engine: str


class HealthResponse(BaseModel):
    """Health check response."""

    status: str = "ok"
    version: str
    engine: str
    fitted: bool


class ErrorResponse(BaseModel):
    """Standard error response envelope."""

    error: str
    code: str
    details: dict[str, Any] = Field(default_factory=dict)
