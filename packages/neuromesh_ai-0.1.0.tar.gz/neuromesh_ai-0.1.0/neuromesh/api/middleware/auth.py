"""
FastAPI middleware for NeuroMesh AI.

Provides:
- API key authentication (X-API-Key header)
- Request ID injection (X-Request-ID header)
- Structured access logging
"""

from __future__ import annotations

import time
import uuid
from typing import Any

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Injects a unique X-Request-ID header into every request and response.

    If the incoming request already contains an X-Request-ID header, it
    is preserved. Otherwise a new UUID4 is generated.
    """

    async def dispatch(self, request: Request, call_next: object) -> Response:
        request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        # Make the ID available to downstream handlers
        request.state.request_id = request_id
        response: Response = await call_next(request)  # type: ignore[operator]
        response.headers["X-Request-ID"] = request_id
        return response


class AccessLogMiddleware(BaseHTTPMiddleware):
    """Logs every request with method, path, status, and elapsed time."""

    async def dispatch(self, request: Request, call_next: object) -> Response:
        start = time.perf_counter()
        response: Response = await call_next(request)  # type: ignore[operator]
        elapsed_ms = (time.perf_counter() - start) * 1000
        request_id = getattr(request.state, "request_id", "-")
        logger.info(
            "HTTP %s %s → %d (%.1fms) req_id=%s",
            request.method,
            request.url.path,
            response.status_code,
            elapsed_ms,
            request_id,
        )
        return response


def make_api_key_checker(api_key: str | None) -> Any:
    """Return a FastAPI dependency that enforces API key authentication.

    If ``api_key`` is ``None`` or empty, authentication is disabled
    (development mode).

    Args:
        api_key: The expected API key value.

    Returns:
        An async dependency callable for use with ``Depends()``.
    """
    from fastapi import Header, HTTPException, status

    async def _check(x_api_key: str | None = Header(default=None)) -> None:
        if not api_key:
            return  # auth disabled
        if x_api_key != api_key:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={"error": "Invalid or missing API key.", "code": "unauthorized"},
            )

    return _check
