"""
FastAPI application factory for NeuroMesh AI.

Usage::

    from neuromesh.api.server import build_app

    app = build_app(recommender=rec)
    # or from CLI / serve():
    uvicorn.run(app, host="0.0.0.0", port=8000)
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from neuromesh.api.middleware.auth import (
    AccessLogMiddleware,
    RequestIDMiddleware,
    make_api_key_checker,
)
from neuromesh.api.routes.recommendations import router as rec_router
from neuromesh.utils.exceptions import NeuroMeshError
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)


def build_app(recommender: Any, settings: Any | None = None) -> FastAPI:
    """Construct and configure the FastAPI application.

    Args:
        recommender: A trained (or untrained) ``Recommender`` instance.
                     The app is usable before training; endpoints that
                     require a fitted engine return 503 until trained.
        settings:    Optional ``Settings`` instance. If ``None``, loads
                     from environment variables automatically.

    Returns:
        FastAPI: Configured application, ready for ``uvicorn.run()``.
    """
    if settings is None:
        from neuromesh.config.settings import get_settings

        settings = get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
        logger.info(
            "NeuroMesh AI API starting — engine=%s host=%s port=%d",
            recommender._engine_name,
            settings.host,
            settings.port,
        )
        yield
        logger.info("NeuroMesh AI API shutting down.")

    app = FastAPI(
        title="NeuroMesh AI",
        description=(
            "Universal, open-source recommendation infrastructure. "
            "Schema-agnostic · Multi-engine · Real-time learning."
        ),
        version="0.1.0",
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        lifespan=lifespan,
    )

    # -----------------------------------------------------------------------
    # CORS
    # -----------------------------------------------------------------------
    cors_origins = settings.cors_origins if settings.cors_origins else ["*"]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # -----------------------------------------------------------------------
    # Custom middleware (order matters — outermost executes first)
    # -----------------------------------------------------------------------
    app.add_middleware(AccessLogMiddleware)
    app.add_middleware(RequestIDMiddleware)

    # -----------------------------------------------------------------------
    # Application state — shared across all requests
    # -----------------------------------------------------------------------
    app.state.recommender = recommender
    app.state.settings = settings
    app.state.auth_checker = make_api_key_checker(settings.api_key)

    # -----------------------------------------------------------------------
    # Routes
    # -----------------------------------------------------------------------
    app.include_router(rec_router, prefix="/v1")

    # -----------------------------------------------------------------------
    # Global exception handlers
    # -----------------------------------------------------------------------
    @app.exception_handler(NeuroMeshError)
    async def neuromesh_error_handler(request: Request, exc: NeuroMeshError) -> JSONResponse:
        logger.warning(
            "NeuroMeshError: %s code=%s path=%s",
            exc.message,
            exc.code,
            request.url.path,
        )
        return JSONResponse(status_code=500, content=exc.to_dict())

    @app.exception_handler(Exception)
    async def generic_error_handler(request: Request, exc: Exception) -> JSONResponse:
        logger.exception("Unhandled exception on %s: %s", request.url.path, exc)
        return JSONResponse(
            status_code=500,
            content={"error": "Internal server error.", "code": "internal_error", "details": {}},
        )

    return app
