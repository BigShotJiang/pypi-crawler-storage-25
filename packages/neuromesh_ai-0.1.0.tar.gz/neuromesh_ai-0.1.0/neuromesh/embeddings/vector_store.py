"""
Vector store abstraction layer for NeuroMesh AI.

Provides a common ``VectorStore`` ABC and three concrete implementations:

- ``FAISSVectorStore`` — in-process, uses faiss (flat or HNSW index).
- ``QdrantVectorStore`` — connects to a Qdrant server via gRPC/HTTP.
- ``ChromaVectorStore`` — connects to Chroma (in-process or HTTP mode).

Use the factory function :func:`create_vector_store` to select the
backend from the ``VECTOR_STORE`` environment variable.

Usage::

    from neuromesh.embeddings.vector_store import create_vector_store
    import numpy as np

    store = create_vector_store("faiss", dim=384)
    store.add(["a", "b"], np.random.rand(2, 384).astype("float32"))
    results = store.search(np.random.rand(384).astype("float32"), top_k=5)
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

import numpy as np

from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------


class VectorStore(ABC):
    """Abstract interface for all NeuroMesh vector store backends.

    All implementations must be thread-safe for concurrent reads.
    Write operations (``add``, ``delete``) are not required to be
    atomic but must leave the store in a consistent state.
    """

    @abstractmethod
    def add(self, item_ids: list[str], embeddings: np.ndarray) -> None:
        """Index a batch of item embeddings.

        Args:
            item_ids:   Unique item identifiers, same order as ``embeddings``.
            embeddings: Float32 matrix of shape ``(n, dim)``.
        """

    @abstractmethod
    def search(self, query_embedding: np.ndarray, top_k: int = 10) -> list[tuple[str, float]]:
        """Find the ``top_k`` most similar items to the query vector.

        Args:
            query_embedding: 1-D float32 array of length ``dim``.
            top_k:           Number of results to return.

        Returns:
            List of ``(item_id, score)`` tuples, sorted descending by score.
            Score is cosine similarity in ``[0, 1]`` when embeddings are
            L2-normalised (which is the default from :class:`Encoder`).
        """

    @abstractmethod
    def delete(self, item_id: str) -> None:
        """Remove an item from the index.

        Args:
            item_id: ID of the item to remove.
        """

    @abstractmethod
    def exists(self, item_id: str) -> bool:
        """Check whether an item ID is currently indexed.

        Args:
            item_id: ID to look up.

        Returns:
            ``True`` if the item is in the store, ``False`` otherwise.
        """

    @property
    @abstractmethod
    def size(self) -> int:
        """Number of vectors currently stored."""

    def __len__(self) -> int:
        return self.size


# ---------------------------------------------------------------------------
# FAISS implementation
# ---------------------------------------------------------------------------


class FAISSVectorStore(VectorStore):
    """In-process vector store backed by FAISS.

    Uses a flat (exact) inner-product index for corpora smaller than
    ``hnsw_threshold`` items, and an HNSW index for larger corpora.
    When embeddings are L2-normalised the inner product equals cosine
    similarity, so scores are already in ``[0, 1]``.

    Args:
        dim:             Embedding dimension (must match the encoder).
        hnsw_threshold:  Switch to HNSW when corpus exceeds this count.
        hnsw_m:          HNSW ``M`` parameter (graph connectivity).
    """

    def __init__(
        self,
        dim: int,
        hnsw_threshold: int = 1000,
        hnsw_m: int = 32,
    ) -> None:
        self._dim = dim
        self._hnsw_threshold = hnsw_threshold
        self._hnsw_m = hnsw_m
        self._index: Any = None  # faiss index, created lazily
        self._id_to_int: dict[str, int] = {}  # item_id → faiss int id
        self._int_to_id: dict[int, str] = {}  # faiss int id → item_id
        self._next_int: int = 0

    # ------------------------------------------------------------------
    # VectorStore interface
    # ------------------------------------------------------------------

    def add(self, item_ids: list[str], embeddings: np.ndarray) -> None:
        if len(item_ids) != embeddings.shape[0]:
            raise ValueError("item_ids and embeddings must have the same length.")

        self._ensure_index(embeddings.shape[0])
        vecs = embeddings.astype(np.float32)

        int_ids = np.arange(self._next_int, self._next_int + len(item_ids), dtype=np.int64)
        self._index.add_with_ids(vecs, int_ids)

        for item_id, int_id in zip(item_ids, int_ids.tolist()):
            self._id_to_int[item_id] = int_id
            self._int_to_id[int_id] = item_id

        self._next_int += len(item_ids)
        logger.debug("FAISSVectorStore: added %d vectors, total=%d", len(item_ids), self.size)

    def search(self, query_embedding: np.ndarray, top_k: int = 10) -> list[tuple[str, float]]:
        if self._index is None or self.size == 0:
            return []

        q = query_embedding.astype(np.float32).reshape(1, -1)
        k = min(top_k, self.size)
        scores, int_ids = self._index.search(q, k)

        results: list[tuple[str, float]] = []
        for score, int_id in zip(scores[0].tolist(), int_ids[0].tolist()):
            if int_id < 0:
                continue  # faiss returns -1 for padded results
            item_id = self._int_to_id.get(int_id)
            if item_id is not None:
                results.append((item_id, float(min(score, 1.0))))
        return results

    def delete(self, item_id: str) -> None:
        int_id = self._id_to_int.pop(item_id, None)
        if int_id is None:
            return
        self._int_to_id.pop(int_id, None)
        if self._index is not None:
            id_arr = np.array([int_id], dtype=np.int64)
            try:
                self._index.remove_ids(id_arr)
            except Exception:
                logger.warning("FAISSVectorStore: remove_ids not supported on this index type.")

    def exists(self, item_id: str) -> bool:
        return item_id in self._id_to_int

    @property
    def size(self) -> int:
        return len(self._id_to_int)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str | Path) -> None:
        """Persist the FAISS index to disk.

        Args:
            path: Directory to write ``index.faiss`` and ``ids.npy`` into.
        """
        import faiss

        p = Path(path)
        p.mkdir(parents=True, exist_ok=True)
        if self._index is not None:
            faiss.write_index(self._index, str(p / "index.faiss"))
        np.save(str(p / "id_to_int.npy"), self._id_to_int)  # type: ignore[arg-type]
        np.save(str(p / "int_to_id.npy"), self._int_to_id)  # type: ignore[arg-type]
        np.save(str(p / "meta.npy"), np.array([self._next_int, self._dim]))
        logger.info("FAISSVectorStore saved to %s", p)

    def load(self, path: str | Path) -> None:
        """Restore a previously saved FAISS index from disk.

        Args:
            path: Directory containing ``index.faiss`` and ``ids.npy``.
        """
        import faiss

        p = Path(path)
        self._index = faiss.read_index(str(p / "index.faiss"))
        self._id_to_int = np.load(str(p / "id_to_int.npy"), allow_pickle=True).item()
        self._int_to_id = np.load(str(p / "int_to_id.npy"), allow_pickle=True).item()
        meta = np.load(str(p / "meta.npy"))
        self._next_int = int(meta[0])
        self._dim = int(meta[1])
        logger.info("FAISSVectorStore loaded from %s — size=%d", p, self.size)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _ensure_index(self, n_new: int) -> None:
        """Create or upgrade the FAISS index as needed."""
        try:
            import faiss
        except ImportError as exc:
            raise ImportError(
                "faiss-cpu is required for FAISSVectorStore. "
                "Install it with: pip install neuromesh-ai[embedding]"
            ) from exc

        if self._index is not None:
            return  # already created

        total_after = self.size + n_new
        if total_after >= self._hnsw_threshold:
            logger.info(
                "FAISSVectorStore: using HNSWFlat index (M=%d, dim=%d)",
                self._hnsw_m,
                self._dim,
            )
            index = faiss.IndexHNSWFlat(self._dim, self._hnsw_m)
            index.hnsw.efConstruction = 200
        else:
            logger.info("FAISSVectorStore: using FlatIP index (dim=%d)", self._dim)
            index = faiss.IndexFlatIP(self._dim)

        self._index = faiss.IndexIDMap(index)

    def __repr__(self) -> str:
        return f"FAISSVectorStore(dim={self._dim}, size={self.size})"


# ---------------------------------------------------------------------------
# Qdrant implementation
# ---------------------------------------------------------------------------


class QdrantVectorStore(VectorStore):
    """Vector store backed by a Qdrant server.

    Args:
        collection: Qdrant collection name.
        url:        Qdrant server URL. Defaults to ``QDRANT_URL`` env var.
        api_key:    Optional API key for Qdrant Cloud.
        dim:        Embedding dimension. Required when creating a new collection.
    """

    def __init__(
        self,
        collection: str = "neuromesh",
        url: str | None = None,
        api_key: str | None = None,
        dim: int = 384,
    ) -> None:
        self._collection = collection
        self._url = url or os.getenv("QDRANT_URL", "http://localhost:6333")
        self._api_key = api_key or os.getenv("QDRANT_API_KEY")
        self._dim = dim
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is not None:
            return self._client
        try:
            from qdrant_client import QdrantClient
            from qdrant_client.models import Distance, VectorParams
        except ImportError as exc:
            raise ImportError(
                "qdrant-client is required for QdrantVectorStore. "
                "Install it with: pip install neuromesh-ai[qdrant]"
            ) from exc

        self._client = QdrantClient(url=self._url, api_key=self._api_key)

        # Create collection if it doesn't exist
        existing = [c.name for c in self._client.get_collections().collections]
        if self._collection not in existing:
            self._client.create_collection(
                collection_name=self._collection,
                vectors_config=VectorParams(size=self._dim, distance=Distance.COSINE),
            )
            logger.info("QdrantVectorStore: created collection '%s'", self._collection)

        return self._client

    def add(self, item_ids: list[str], embeddings: np.ndarray) -> None:
        from qdrant_client.models import PointStruct

        client = self._get_client()
        points = [
            PointStruct(
                id=abs(hash(item_id)) % (2**63),
                vector=embeddings[i].tolist(),
                payload={"item_id": item_id},
            )
            for i, item_id in enumerate(item_ids)
        ]
        client.upsert(collection_name=self._collection, points=points)
        logger.debug("QdrantVectorStore: upserted %d points", len(points))

    def search(self, query_embedding: np.ndarray, top_k: int = 10) -> list[tuple[str, float]]:
        client = self._get_client()
        hits = client.search(
            collection_name=self._collection,
            query_vector=query_embedding.tolist(),
            limit=top_k,
            with_payload=True,
        )
        return [(h.payload["item_id"], float(h.score)) for h in hits]

    def delete(self, item_id: str) -> None:
        from qdrant_client.models import PointIdsList

        client = self._get_client()
        int_id = abs(hash(item_id)) % (2**63)
        client.delete(
            collection_name=self._collection,
            points_selector=PointIdsList(points=[int_id]),
        )

    def exists(self, item_id: str) -> bool:
        client = self._get_client()
        int_id = abs(hash(item_id)) % (2**63)
        results = client.retrieve(collection_name=self._collection, ids=[int_id], with_payload=True)
        return any(r.payload.get("item_id") == item_id for r in results)

    @property
    def size(self) -> int:
        client = self._get_client()
        info = client.get_collection(self._collection)
        return int(info.points_count or 0)

    def __repr__(self) -> str:
        return f"QdrantVectorStore(collection='{self._collection}', url='{self._url}')"


# ---------------------------------------------------------------------------
# Chroma implementation
# ---------------------------------------------------------------------------


class ChromaVectorStore(VectorStore):
    """Vector store backed by ChromaDB.

    Args:
        collection: Chroma collection name.
        persist_dir: If set, uses a persistent local Chroma client.
                     If ``None``, uses an ephemeral in-process client.
        host:       ChromaDB HTTP host (for remote mode).
        port:       ChromaDB HTTP port (for remote mode).
    """

    def __init__(
        self,
        collection: str = "neuromesh",
        persist_dir: str | None = None,
        host: str | None = None,
        port: int = 8000,
    ) -> None:
        self._collection_name = collection
        self._persist_dir = persist_dir
        self._host = host
        self._port = port
        self._client: Any = None
        self._collection: Any = None

    def _get_collection(self) -> Any:
        if self._collection is not None:
            return self._collection
        try:
            import chromadb
        except ImportError as exc:
            raise ImportError(
                "chromadb is required for ChromaVectorStore. "
                "Install it with: pip install neuromesh-ai[chroma]"
            ) from exc

        if self._host:
            self._client = chromadb.HttpClient(host=self._host, port=self._port)
        elif self._persist_dir:
            self._client = chromadb.PersistentClient(path=self._persist_dir)
        else:
            self._client = chromadb.EphemeralClient()

        self._collection = self._client.get_or_create_collection(
            name=self._collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        return self._collection

    def add(self, item_ids: list[str], embeddings: np.ndarray) -> None:
        col = self._get_collection()
        col.upsert(
            ids=item_ids,
            embeddings=embeddings.tolist(),
        )
        logger.debug("ChromaVectorStore: upserted %d items", len(item_ids))

    def search(self, query_embedding: np.ndarray, top_k: int = 10) -> list[tuple[str, float]]:
        col = self._get_collection()
        results = col.query(
            query_embeddings=[query_embedding.tolist()],
            n_results=min(top_k, self.size or 1),
            include=["distances"],
        )
        ids = results["ids"][0]
        # Chroma returns cosine *distance* (0=identical, 2=opposite); convert to similarity
        distances = results["distances"][0]
        return [(id_, float(1.0 - d / 2.0)) for id_, d in zip(ids, distances)]

    def delete(self, item_id: str) -> None:
        col = self._get_collection()
        col.delete(ids=[item_id])

    def exists(self, item_id: str) -> bool:
        col = self._get_collection()
        results = col.get(ids=[item_id])
        return len(results["ids"]) > 0

    @property
    def size(self) -> int:
        if self._collection is None:
            return 0
        return int(self._get_collection().count())

    def __repr__(self) -> str:
        return f"ChromaVectorStore(collection='{self._collection_name}')"


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_vector_store(store_type: str | None = None, **kwargs: Any) -> VectorStore:
    """Instantiate a vector store by name.

    Reads ``VECTOR_STORE`` env var if ``store_type`` is not provided.
    Defaults to ``"faiss"`` if the env var is also unset.

    Args:
        store_type: One of ``"faiss"``, ``"qdrant"``, ``"chroma"``.
        **kwargs:   Passed directly to the store constructor.

    Returns:
        A configured :class:`VectorStore` instance.

    Raises:
        ValueError: If ``store_type`` is not recognised.
    """
    resolved = (store_type or os.getenv("NEUROMESH_VECTOR_STORE") or "faiss").lower()

    registry: dict[str, type[VectorStore]] = {
        "faiss": FAISSVectorStore,
        "qdrant": QdrantVectorStore,
        "chroma": ChromaVectorStore,
    }

    if resolved not in registry:
        raise ValueError(f"Unknown vector store '{resolved}'. Choose from: {sorted(registry)}.")

    logger.info("Creating vector store backend='%s'", resolved)
    return registry[resolved](**kwargs)
