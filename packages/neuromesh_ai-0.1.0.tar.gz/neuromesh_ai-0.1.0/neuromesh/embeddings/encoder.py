"""
Sentence Transformer encoder for NeuroMesh AI.

Wraps ``sentence_transformers.SentenceTransformer`` with lazy loading,
GPU auto-detection, and batched encoding. The model is loaded on first
use to keep import time fast.

Usage::

    from neuromesh.embeddings.encoder import Encoder

    enc = Encoder()                          # lazy — no model loaded yet
    vectors = enc.encode(["hello world"])    # model loads here on first call
    vec     = enc.encode_single("hello")
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, cast

import numpy as np

from neuromesh.utils.logger import get_logger

if TYPE_CHECKING:
    from sentence_transformers import SentenceTransformer

logger = get_logger(__name__)

_DEFAULT_MODEL = "all-MiniLM-L6-v2"


class Encoder:
    """Lazy-loading sentence transformer encoder.

    The underlying model is NOT loaded until the first call to
    :meth:`encode` or :meth:`encode_single`, keeping import and
    ``Recommender`` construction instant.

    Args:
        model_name: HuggingFace model name or local path.
            Defaults to the ``NEUROMESH_EMBEDDING_MODEL`` env var,
            or ``"all-MiniLM-L6-v2"`` if unset.
        device: ``"cuda"``, ``"cpu"``, or ``None`` (auto-detect).
        batch_size: Number of texts to encode per forward pass.
        normalize_embeddings: If ``True``, L2-normalizes output vectors
            so cosine similarity == dot product (faster ANN lookup).
    """

    def __init__(
        self,
        model_name: str | None = None,
        device: str | None = None,
        batch_size: int = 64,
        normalize_embeddings: bool = True,
    ) -> None:
        self._model_name: str = (
            model_name or os.getenv("NEUROMESH_EMBEDDING_MODEL") or _DEFAULT_MODEL
        )
        self._device = device  # None → auto-detect at load time
        self._batch_size = batch_size
        self._normalize_embeddings = normalize_embeddings
        self._model: SentenceTransformer | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def model_name(self) -> str:
        return self._model_name

    @property
    def embedding_dim(self) -> int:
        """Return the output vector dimension (loads model if needed)."""
        return int(self._get_model().get_sentence_embedding_dimension())

    @property
    def is_loaded(self) -> bool:
        return self._model is not None

    def encode(self, texts: list[str]) -> np.ndarray:
        """Encode a list of texts into a 2-D float32 embedding matrix.

        Args:
            texts: Input strings to encode. Empty strings are replaced
                   with a single space to avoid tokenizer errors.

        Returns:
            numpy.ndarray of shape ``(len(texts), embedding_dim)``
            with dtype ``float32``.
        """
        if not texts:
            return np.empty((0, self.embedding_dim), dtype=np.float32)

        safe_texts = [t if t.strip() else " " for t in texts]
        model = self._get_model()

        logger.debug(
            "Encoding %d texts with model=%s batch_size=%d",
            len(safe_texts),
            self._model_name,
            self._batch_size,
        )

        vectors: np.ndarray = model.encode(
            safe_texts,
            batch_size=self._batch_size,
            normalize_embeddings=self._normalize_embeddings,
            show_progress_bar=False,
            convert_to_numpy=True,
        )
        return vectors.astype(np.float32)

    def encode_single(self, text: str) -> np.ndarray:
        """Encode a single text into a 1-D float32 vector.

        Args:
            text: Input string.

        Returns:
            numpy.ndarray of shape ``(embedding_dim,)`` with dtype ``float32``.
        """
        result = self.encode([text])
        return cast(np.ndarray, result[0])

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_model(self) -> Any:
        """Return the loaded model, loading it on first call."""
        if self._model is None:
            self._load_model()
        return self._model

    def _load_model(self) -> None:
        """Lazily import sentence_transformers and load the model."""
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise ImportError(
                "sentence-transformers is required for the embedding engine. "
                "Install it with: pip install neuromesh-ai[embedding]"
            ) from exc

        device = self._resolve_device()
        logger.info(
            "Loading sentence transformer model '%s' on device='%s'",
            self._model_name,
            device,
        )
        self._model = SentenceTransformer(self._model_name, device=device)
        logger.info(
            "Model loaded — dim=%d",
            self._model.get_sentence_embedding_dimension(),
        )

    def _resolve_device(self) -> str:
        """Return the effective device string ('cuda' or 'cpu')."""
        if self._device is not None:
            return self._device
        try:
            import torch

            return "cuda" if torch.cuda.is_available() else "cpu"
        except ImportError:
            return "cpu"

    def __repr__(self) -> str:
        status = "loaded" if self.is_loaded else "not loaded"
        return (
            f"Encoder(model='{self._model_name}', "
            f"device='{self._device or 'auto'}', "
            f"status='{status}')"
        )
