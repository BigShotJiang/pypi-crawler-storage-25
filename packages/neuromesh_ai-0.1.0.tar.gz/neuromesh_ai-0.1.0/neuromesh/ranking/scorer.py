"""
Scoring functions for NeuroMesh AI ranking pipeline.

Provides pure functions that adjust ``RecommendationResult`` scores by
blending in secondary signals such as popularity and freshness.  These
functions are composable — the ``Ranker`` class chains them in sequence.

All functions return new ``RecommendationResult`` instances (the model is
frozen / immutable) rather than mutating in place.
"""

from __future__ import annotations

import math
from typing import Any

from neuromesh.engines.base_engine import RecommendationResult
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)


def blend_popularity(
    results: list[RecommendationResult],
    popularity_scores: dict[str, float],
    weight: float = 0.15,
) -> list[RecommendationResult]:
    """Blend a popularity signal into existing recommendation scores.

    New score = ``(1 - weight) * original_score + weight * popularity_score``.

    Args:
        results:          List of ``RecommendationResult`` objects to re-score.
        popularity_scores: Mapping of item_id → normalized popularity in [0, 1].
        weight:           How much to weight popularity. 0.0 = no change, 1.0 = pure popularity.
                          Defaults to 0.15.

    Returns:
        list[RecommendationResult]: New list with blended scores, unsorted.
    """
    if weight == 0.0:
        return results
    blended = []
    for r in results:
        pop = popularity_scores.get(r.item_id, 0.0)
        new_score = (1.0 - weight) * r.score + weight * pop
        blended.append(r.model_copy(update={"score": round(min(new_score, 1.0), 6)}))
    return blended


def blend_freshness(
    results: list[RecommendationResult],
    freshness_scores: dict[str, float],
    weight: float = 0.10,
) -> list[RecommendationResult]:
    """Blend a freshness signal into existing recommendation scores.

    New score = ``(1 - weight) * original_score + weight * freshness_score``.

    Args:
        results:          List of ``RecommendationResult`` objects to re-score.
        freshness_scores: Mapping of item_id → freshness score in [0, 1].
        weight:           How much to weight freshness. Defaults to 0.10.

    Returns:
        list[RecommendationResult]: New list with blended scores, unsorted.
    """
    if weight == 0.0:
        return results
    blended = []
    for r in results:
        fresh = freshness_scores.get(r.item_id, 0.0)
        new_score = (1.0 - weight) * r.score + weight * fresh
        blended.append(r.model_copy(update={"score": round(min(new_score, 1.0), 6)}))
    return blended


def apply_diversity_penalty(
    results: list[RecommendationResult],
    items_by_id: dict[str, dict[str, Any]],
    category_field: str = "category",
    penalty: float = 0.05,
) -> list[RecommendationResult]:
    """Apply a penalty to items from over-represented categories.

    Iterates through results in score order. Each time a category appears
    more than once, subsequent items from that category receive a
    multiplicative penalty of ``(1 - penalty * excess_count)``.

    Args:
        results:       Recommendations sorted descending by score.
        items_by_id:   Mapping of item_id → item dict (for category lookup).
        category_field: Item field used as the category key. Defaults to ``"category"``.
        penalty:       Per-extra-occurrence penalty multiplier. Defaults to 0.05
                       (5% reduction per duplicate category occurrence).

    Returns:
        list[RecommendationResult]: New list with diversity-penalized scores, unsorted.
    """
    if penalty == 0.0:
        return results
    category_count: dict[str, int] = {}
    penalized = []
    for r in results:
        item = items_by_id.get(r.item_id, {})
        cat = str(item.get(category_field, ""))
        count = category_count.get(cat, 0)
        if count > 0 and cat:
            factor = max(1.0 - penalty * count, 0.0)
            new_score = r.score * factor
        else:
            new_score = r.score
        category_count[cat] = count + 1
        penalized.append(r.model_copy(update={"score": round(min(new_score, 1.0), 6)}))
    return penalized


def normalize_scores(results: list[RecommendationResult]) -> list[RecommendationResult]:
    """Re-normalize a list of scores to the [0, 1] range using min-max scaling.

    Useful after multiple blending operations that may shift the score
    distribution away from [0, 1].

    Args:
        results: List of ``RecommendationResult`` objects.

    Returns:
        list[RecommendationResult]: New list with scores re-normalized to [0, 1].
    """
    if not results:
        return results
    min_s = min(r.score for r in results)
    max_s = max(r.score for r in results)
    spread = max_s - min_s
    if spread == 0.0:
        return results
    return [r.model_copy(update={"score": round((r.score - min_s) / spread, 6)}) for r in results]
