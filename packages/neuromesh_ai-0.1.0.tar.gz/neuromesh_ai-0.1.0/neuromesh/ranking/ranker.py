"""
Post-engine ranking pipeline for NeuroMesh AI.

The ``Ranker`` takes raw ``RecommendationResult`` lists from any engine
and applies a configurable sequence of re-scoring and filtering steps:

1. Blend popularity signal (optional)
2. Blend freshness signal (optional)
3. Apply diversity penalty (optional)
4. Sort descending by final score
5. Truncate to requested ``top_k``

The ``Ranker`` is intentionally stateless per-call — all scoring data
(popularity, freshness, item index) must be provided at call time.

Usage::

    from neuromesh.ranking.ranker import Ranker

    ranker = Ranker(popularity_weight=0.15, freshness_weight=0.10, diversity_penalty=0.05)
    ranked = ranker.rank(
        results=engine_results,
        top_k=10,
        popularity_scores=pop,
        freshness_scores=fresh,
        items_by_id=items_by_id,
    )
"""

from __future__ import annotations

from typing import Any

from neuromesh.engines.base_engine import RecommendationResult
from neuromesh.ranking.scorer import (
    apply_diversity_penalty,
    blend_freshness,
    blend_popularity,
    normalize_scores,
)
from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)


class Ranker:
    """Post-engine ranking pipeline.

    Applies secondary scoring signals to a raw list of engine results,
    then returns the final ranked and truncated list.

    Args:
        popularity_weight: Weight for popularity blending in [0, 1]. 0 = disabled.
            Defaults to 0.15.
        freshness_weight:  Weight for freshness blending in [0, 1]. 0 = disabled.
            Defaults to 0.10.
        diversity_penalty: Per-extra-category-occurrence score penalty in [0, 1].
            0 = disabled. Defaults to 0.05.
        category_field:    Item dict field used as the category key for diversity.
            Defaults to ``"category"``.

    Example::

        ranker = Ranker()
        ranked = ranker.rank(
            results=engine.recommend("item_1", top_k=50),
            top_k=10,
            popularity_scores=pop,
            freshness_scores=fresh,
            items_by_id={item["id"]: item for item in items},
        )
    """

    def __init__(
        self,
        popularity_weight: float = 0.15,
        freshness_weight: float = 0.10,
        diversity_penalty: float = 0.05,
        category_field: str = "category",
    ) -> None:
        self.popularity_weight = popularity_weight
        self.freshness_weight = freshness_weight
        self.diversity_penalty = diversity_penalty
        self.category_field = category_field

    def rank(
        self,
        results: list[RecommendationResult],
        top_k: int,
        popularity_scores: dict[str, float] | None = None,
        freshness_scores: dict[str, float] | None = None,
        items_by_id: dict[str, dict[str, Any]] | None = None,
    ) -> list[RecommendationResult]:
        """Apply the full ranking pipeline to a list of engine results.

        Steps:
        1. Blend popularity (if ``popularity_scores`` provided and weight > 0).
        2. Blend freshness  (if ``freshness_scores`` provided and weight > 0).
        3. Sort descending by current score.
        4. Apply diversity penalty (if ``items_by_id`` provided and penalty > 0).
        5. Re-sort descending by final score.
        6. Truncate to ``top_k``.

        Args:
            results:           Raw ``RecommendationResult`` list from an engine.
            top_k:             Number of results to return.
            popularity_scores: Optional item_id → popularity score mapping.
            freshness_scores:  Optional item_id → freshness score mapping.
            items_by_id:       Optional item_id → item dict (for category diversity).

        Returns:
            list[RecommendationResult]: Final ranked list, length ≤ ``top_k``.
        """
        if not results:
            return []

        ranked = list(results)

        # Step 1: Popularity blending
        if popularity_scores and self.popularity_weight > 0:
            ranked = blend_popularity(ranked, popularity_scores, weight=self.popularity_weight)

        # Step 2: Freshness blending
        if freshness_scores and self.freshness_weight > 0:
            ranked = blend_freshness(ranked, freshness_scores, weight=self.freshness_weight)

        # Step 3: Sort before diversity so penalty is applied in score order
        ranked.sort(key=lambda r: r.score, reverse=True)

        # Step 4: Diversity penalty
        if items_by_id and self.diversity_penalty > 0:
            ranked = apply_diversity_penalty(
                ranked,
                items_by_id=items_by_id,
                category_field=self.category_field,
                penalty=self.diversity_penalty,
            )

        # Step 5: Final sort + truncate
        ranked.sort(key=lambda r: r.score, reverse=True)
        final = ranked[:top_k]

        logger.debug(
            "Ranker.rank — input=%d output=%d top_k=%d",
            len(results),
            len(final),
            top_k,
        )
        return final
