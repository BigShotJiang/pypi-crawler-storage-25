from neuromesh.realtime.incremental import IncrementalLearner

__all__ = ["IncrementalLearner"]
