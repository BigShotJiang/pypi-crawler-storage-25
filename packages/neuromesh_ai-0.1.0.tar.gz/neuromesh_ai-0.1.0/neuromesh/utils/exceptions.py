"""
Custom exception hierarchy for NeuroMesh AI.

All NeuroMesh exceptions inherit from ``NeuroMeshError`` so callers
can catch the entire family with a single ``except NeuroMeshError``,
or catch specific exceptions for fine-grained error handling.

Usage::

    from neuromesh.utils.exceptions import ItemNotFoundError

    raise ItemNotFoundError(item_id="item123")
"""

from __future__ import annotations

from typing import Any


class NeuroMeshError(Exception):
    """Base exception for all NeuroMesh AI errors.

    All custom exceptions in this package inherit from this class,
    making it easy to catch any NeuroMesh-related error.

    Args:
        message: Human-readable error description.
        code: Machine-readable error code for API responses.
    """

    code: str = "neuromesh_error"

    def __init__(self, message: str, code: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        if code is not None:
            self.code = code

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a safe dict suitable for API error responses.

        Returns:
            dict: Contains ``error``, ``code``, and ``details`` keys.
                  Never includes internal stack trace information.
        """
        return {
            "error": self.message,
            "code": self.code,
            "details": {},
        }


class ItemNotFoundError(NeuroMeshError):
    """Raised when a requested item ID does not exist in the index.

    Args:
        item_id: The item ID that was not found.

    Example::

        raise ItemNotFoundError(item_id="product_42")
    """

    code = "item_not_found"

    def __init__(self, item_id: str) -> None:
        super().__init__(
            message=f"Item '{item_id}' was not found in the recommendation index.",
        )
        self.item_id = item_id

    def to_dict(self) -> dict[str, Any]:
        return {
            "error": self.message,
            "code": self.code,
            "details": {"item_id": self.item_id},
        }


class EngineNotFittedError(NeuroMeshError):
    """Raised when a recommendation engine method is called before ``fit()``.

    Args:
        engine_name: Name of the engine class that was not fitted.

    Example::

        raise EngineNotFittedError(engine_name="TFIDFEngine")
    """

    code = "engine_not_fitted"

    def __init__(self, engine_name: str) -> None:
        super().__init__(
            message=(
                f"'{engine_name}' has not been trained yet. "
                "Call .fit(items) before making recommendations."
            ),
        )
        self.engine_name = engine_name

    def to_dict(self) -> dict[str, Any]:
        return {
            "error": self.message,
            "code": self.code,
            "details": {"engine": self.engine_name},
        }


class InvalidItemSchemaError(NeuroMeshError):
    """Raised when an item dict is missing required fields or has invalid types.

    Args:
        reason: Description of why the schema is invalid.
        item_index: Optional index of the offending item in the batch.

    Example::

        raise InvalidItemSchemaError(
            reason="Missing required field 'id'",
            item_index=3,
        )
    """

    code = "invalid_item_schema"

    def __init__(self, reason: str, item_index: int | None = None) -> None:
        location = f" (item at index {item_index})" if item_index is not None else ""
        super().__init__(message=f"Invalid item schema{location}: {reason}")
        self.reason = reason
        self.item_index = item_index

    def to_dict(self) -> dict[str, Any]:
        return {
            "error": self.message,
            "code": self.code,
            "details": {
                "reason": self.reason,
                "item_index": self.item_index,
            },
        }


class VectorStoreError(NeuroMeshError):
    """Raised when a vector store operation fails.

    Args:
        operation: The operation that failed (e.g., ``"add"``, ``"search"``).
        reason: The underlying error description.

    Example::

        raise VectorStoreError(operation="search", reason="Index not initialized")
    """

    code = "vector_store_error"

    def __init__(self, operation: str, reason: str) -> None:
        super().__init__(
            message=f"Vector store operation '{operation}' failed: {reason}",
        )
        self.operation = operation
        self.reason = reason

    def to_dict(self) -> dict[str, Any]:
        return {
            "error": self.message,
            "code": self.code,
            "details": {"operation": self.operation, "reason": self.reason},
        }


class CacheError(NeuroMeshError):
    """Raised when a Redis cache operation fails unexpectedly.

    Cache errors are non-fatal — the system should fall back to
    computing recommendations directly when this is raised.

    Args:
        operation: The operation that failed (e.g., ``"get"``, ``"set"``).
        reason: The underlying error description.
    """

    code = "cache_error"

    def __init__(self, operation: str, reason: str) -> None:
        super().__init__(
            message=f"Cache operation '{operation}' failed: {reason}",
        )
        self.operation = operation
        self.reason = reason

    def to_dict(self) -> dict[str, Any]:
        return {
            "error": self.message,
            "code": self.code,
            "details": {"operation": self.operation, "reason": self.reason},
        }


class UserNotFoundError(NeuroMeshError):
    """Raised when recommendations are requested for a user with no history.

    Args:
        user_id: The user ID that has no interaction history.
    """

    code = "user_not_found"

    def __init__(self, user_id: str) -> None:
        super().__init__(
            message=(
                f"No interaction history found for user '{user_id}'. "
                "Cannot generate personalized recommendations."
            ),
        )
        self.user_id = user_id

    def to_dict(self) -> dict[str, Any]:
        return {
            "error": self.message,
            "code": self.code,
            "details": {"user_id": self.user_id},
        }
