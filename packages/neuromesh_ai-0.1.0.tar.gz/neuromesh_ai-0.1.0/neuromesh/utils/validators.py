"""Input validators for NeuroMesh AI API boundary safety.

All functions validate and normalise a single value, raising
``ValueError`` with a descriptive message on invalid input.
They are intentionally stateless and have no side-effects.

Usage::

    from neuromesh.utils.validators import validate_item_id, validate_top_k

    item_id = validate_item_id("  ITEM-123  ")   # -> "item-123"
    top_k   = validate_top_k(200)                # -> 100 (clamped)
"""

from __future__ import annotations

import re

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_ITEM_ID_PATTERN = re.compile(r"^[a-zA-Z0-9_\-]+$")
_ITEM_ID_MAX_LEN = 255

_TOP_K_MIN = 1
_TOP_K_MAX = 100

_SCORE_MIN = 0.0
_SCORE_MAX = 5.0

_ALLOWED_ACTIONS = frozenset({"view", "click", "like", "purchase", "rating"})

_ITEMS_LIST_MAX = 10_000


# ---------------------------------------------------------------------------
# Public validators
# ---------------------------------------------------------------------------


def validate_item_id(item_id: str) -> str:
    """Validate and normalise an item identifier.

    Strips surrounding whitespace and converts to lower-case.
    Raises ``ValueError`` if the value is empty, too long, or contains
    characters other than letters, digits, hyphens, and underscores.

    Args:
        item_id: Raw item identifier from caller.

    Returns:
        Cleaned lower-case item identifier.

    Raises:
        ValueError: If ``item_id`` is empty, too long, or has illegal chars.
    """
    cleaned = item_id.strip().lower()
    if not cleaned:
        raise ValueError("item_id must not be empty.")
    if len(cleaned) > _ITEM_ID_MAX_LEN:
        raise ValueError(
            f"item_id must be at most {_ITEM_ID_MAX_LEN} characters, " f"got {len(cleaned)}."
        )
    if not _ITEM_ID_PATTERN.match(cleaned):
        raise ValueError(
            "item_id may only contain letters, digits, hyphens, and underscores. "
            f"Got: {cleaned!r}"
        )
    return cleaned


def validate_top_k(top_k: int) -> int:
    """Clamp ``top_k`` to the allowed range ``[1, 100]``.

    Values below the minimum are raised to 1; values above the maximum
    are capped at 100.  No exception is raised — out-of-range values are
    silently clamped and the adjusted value is returned.

    Args:
        top_k: Requested result count.

    Returns:
        Clamped integer in ``[1, 100]``.
    """
    return max(_TOP_K_MIN, min(_TOP_K_MAX, top_k))


def validate_score(score: float) -> float:
    """Clamp an interaction score to ``[0.0, 5.0]``.

    Args:
        score: Raw score from caller.

    Returns:
        Clamped float in ``[0.0, 5.0]``.
    """
    return max(_SCORE_MIN, min(_SCORE_MAX, score))


def validate_action(action: str) -> str:
    """Validate and normalise an interaction action string.

    Strips whitespace and converts to lower-case before checking against
    the allowed set.

    Args:
        action: Raw action string from caller.

    Returns:
        Normalised action string (one of ``view``, ``click``, ``like``,
        ``purchase``, ``rating``).

    Raises:
        ValueError: If ``action`` is not in the allowed set.
    """
    normalised = action.strip().lower()
    if normalised not in _ALLOWED_ACTIONS:
        raise ValueError(
            f"Invalid action {action!r}. Must be one of: " f"{sorted(_ALLOWED_ACTIONS)}."
        )
    return normalised


def validate_items_list(items: list[dict]) -> list[dict]:  # type: ignore[type-arg]
    """Validate a batch of item dicts.

    Checks that:
    * The list is not empty.
    * The list does not exceed the maximum batch size (10,000 items).
    * Every item has a non-empty ``id`` field.

    Args:
        items: List of item dictionaries.

    Returns:
        The original list unchanged (no deep copy).

    Raises:
        ValueError: If the list is empty, too large, or any item is missing
                    an ``id`` field.
    """
    if not items:
        raise ValueError("items list must not be empty.")
    if len(items) > _ITEMS_LIST_MAX:
        raise ValueError(
            f"items list exceeds the maximum batch size of {_ITEMS_LIST_MAX}. "
            f"Got {len(items)} items."
        )
    for i, item in enumerate(items):
        if not item.get("id"):
            raise ValueError(
                f"Item at index {i} is missing a non-empty 'id' field. " f"Got: {item!r}"
            )
    return items
