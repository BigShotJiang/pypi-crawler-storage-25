"""
Structured logging for NeuroMesh AI.

In development: human-readable text format to stdout.
In production: JSON-structured format for log aggregation pipelines.

Never log secrets, API keys, passwords, or PII through this logger.

Usage::

    from neuromesh.utils.logger import get_logger

    logger = get_logger(__name__)
    logger.info("Training complete", extra={"items": 500, "engine": "tfidf"})
"""

from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timezone
from typing import Any


class _JsonFormatter(logging.Formatter):
    """JSON log formatter for production environments.

    Formats each log record as a single-line JSON object suitable for
    ingestion by Datadog, CloudWatch, Loki, or any structured log system.
    Sensitive fields are never included.
    """

    _EXCLUDED_ATTRS = frozenset(
        {
            "args",
            "exc_info",
            "exc_text",
            "filename",
            "funcName",
            "levelno",
            "lineno",
            "message",
            "module",
            "msecs",
            "msg",
            "pathname",
            "process",
            "processName",
            "relativeCreated",
            "stack_info",
            "thread",
            "threadName",
        }
    )

    def format(self, record: logging.LogRecord) -> str:
        record.message = record.getMessage()
        payload: dict[str, Any] = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.message,
        }

        # Append any extra fields attached via logger.info(..., extra={...})
        for key, value in record.__dict__.items():
            if key not in self._EXCLUDED_ATTRS and not key.startswith("_"):
                payload[key] = value

        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)

        return json.dumps(payload, default=str)


class _DevFormatter(logging.Formatter):
    """Human-readable formatter for development environments."""

    _LEVEL_COLORS = {
        "DEBUG": "\033[36m",  # cyan
        "INFO": "\033[32m",  # green
        "WARNING": "\033[33m",  # yellow
        "ERROR": "\033[31m",  # red
        "CRITICAL": "\033[35m",  # magenta
    }
    _RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        color = self._LEVEL_COLORS.get(record.levelname, "")
        ts = datetime.fromtimestamp(record.created, tz=timezone.utc).strftime("%H:%M:%S")
        prefix = f"{color}{record.levelname:<8}{self._RESET}"
        return f"[{ts}] {prefix} {record.name}: {record.getMessage()}"


def _build_handler(production: bool) -> logging.StreamHandler:  # type: ignore[type-arg]
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(_JsonFormatter() if production else _DevFormatter())
    return handler


def configure_logging(level: str = "INFO", production: bool = False) -> None:
    """Configure the root NeuroMesh logger.

    Call this once at application startup (in the FastAPI lifespan or
    CLI entrypoint). Subsequent calls to ``get_logger()`` will inherit
    this configuration automatically.

    Args:
        level: Log level string — ``"DEBUG"``, ``"INFO"``, ``"WARNING"``,
            or ``"ERROR"``.
        production: When ``True``, emits JSON-structured logs. When
            ``False``, emits human-readable colored logs.
    """
    root = logging.getLogger("neuromesh")
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Avoid duplicate handlers if called more than once
    if not root.handlers:
        root.addHandler(_build_handler(production))

    # Suppress noisy third-party loggers
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    """Return a logger scoped under the ``neuromesh`` namespace.

    Args:
        name: Typically ``__name__`` of the calling module.

    Returns:
        logging.Logger: A logger with the full dotted name.

    Example::

        from neuromesh.utils.logger import get_logger

        logger = get_logger(__name__)
        logger.info("Engine trained", extra={"engine": "tfidf", "items": 1000})
    """
    # Ensure the name is always scoped under neuromesh
    if not name.startswith("neuromesh"):
        name = f"neuromesh.{name}"
    return logging.getLogger(name)
