"""
Explainability layer for NeuroMesh AI.

Provides human-readable explanations for why two items are recommended
together.  Each ``ExplanationFactor`` describes one dimension of
similarity, and the ``Explainer`` assembles all applicable factors into
a structured ``ExplanationResult`` that callers can surface in their UI.

Supported factors
-----------------
- **embedding_similarity** — cosine distance of dense embeddings
  (requires a fitted :class:`~neuromesh.engines.embedding_engine.EmbeddingEngine`).
- **tfidf_similarity** — cosine distance of TF-IDF vectors
  (requires a fitted :class:`~neuromesh.engines.tfidf_engine.TFIDFEngine`).
- **category_match** — whether both items share the same top-level category.
- **tag_overlap** — Jaccard index over item tag sets.
- **co_interaction** — fraction of shared users who interacted with both items.

Usage::

    from neuromesh.explainability.explain import Explainer

    explainer = Explainer()
    result = explainer.explain(
        item_a=item_a_dict,
        item_b=item_b_dict,
        engine=hybrid_engine,
        interactions=interactions_list,
    )
    print(result.summary)
    for factor in result.factors:
        print(factor)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from neuromesh.utils.logger import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ExplanationFactor:
    """A single dimension of similarity contributing to an explanation.

    Attributes:
        name:        Machine-readable factor name.
        score:       Normalised contribution in ``[0, 1]``.
        description: Human-readable sentence suitable for UI display.
    """

    name: str
    score: float
    description: str

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "score": round(self.score, 4), "description": self.description}


@dataclass
class ExplanationResult:
    """Full explanation for a (item_a, item_b) pair.

    Attributes:
        item_a_id:  ID of the seed item.
        item_b_id:  ID of the recommended item.
        factors:    List of contributing :class:`ExplanationFactor` objects,
                    sorted descending by score.
        summary:    Short human-readable summary of the top reasons.
        overall_score: Weighted average of factor scores in ``[0, 1]``.
    """

    item_a_id: str
    item_b_id: str
    factors: list[ExplanationFactor] = field(default_factory=list)
    summary: str = ""
    overall_score: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "item_a_id": self.item_a_id,
            "item_b_id": self.item_b_id,
            "overall_score": round(self.overall_score, 4),
            "summary": self.summary,
            "factors": [f.to_dict() for f in self.factors],
        }


# ---------------------------------------------------------------------------
# Explainer
# ---------------------------------------------------------------------------


class Explainer:
    """Produces structured explanations for item-to-item recommendations.

    The explainer is stateless — no training required.  It reads item
    metadata and optionally calls into fitted engines to derive per-factor
    scores.

    Args:
        factor_weights: Optional dict mapping factor name → weight when
                        computing ``overall_score``.  Factors not listed
                        receive a weight of 1.0.  Weights are *not*
                        normalised automatically.
    """

    _DEFAULT_WEIGHTS: dict[str, float] = {
        "embedding_similarity": 1.5,
        "tfidf_similarity": 1.0,
        "category_match": 0.8,
        "tag_overlap": 0.7,
        "co_interaction": 1.2,
    }

    def __init__(self, factor_weights: dict[str, float] | None = None) -> None:
        self._weights = factor_weights or self._DEFAULT_WEIGHTS.copy()

    def explain(
        self,
        item_a: dict[str, Any],
        item_b: dict[str, Any],
        engine: Any = None,
        interactions: list[dict[str, Any]] | None = None,
    ) -> ExplanationResult:
        """Generate a full explanation for why ``item_b`` was recommended
        given ``item_a``.

        Args:
            item_a:       Seed item dict (must have at least ``"id"``).
            item_b:       Recommended item dict (must have at least ``"id"``).
            engine:       Fitted recommendation engine.  Used to compute
                          ``embedding_similarity`` and ``tfidf_similarity``
                          if the engine supports it.  May be ``None``.
            interactions: List of user-item interaction dicts used to compute
                          ``co_interaction``.  May be ``None`` or empty.

        Returns:
            :class:`ExplanationResult` with all applicable factors filled in.
        """
        id_a = str(item_a.get("id", ""))
        id_b = str(item_b.get("id", ""))
        factors: list[ExplanationFactor] = []

        # 1. Embedding similarity
        emb_factor = self._embedding_factor(id_a, id_b, engine)
        if emb_factor is not None:
            factors.append(emb_factor)

        # 2. TF-IDF similarity
        tfidf_factor = self._tfidf_factor(id_a, id_b, engine)
        if tfidf_factor is not None:
            factors.append(tfidf_factor)

        # 3. Category match
        cat_factor = self._category_factor(item_a, item_b)
        if cat_factor is not None:
            factors.append(cat_factor)

        # 4. Tag overlap
        tag_factor = self._tag_overlap_factor(item_a, item_b)
        if tag_factor is not None:
            factors.append(tag_factor)

        # 5. Co-interaction
        co_factor = self._co_interaction_factor(id_a, id_b, interactions or [])
        if co_factor is not None:
            factors.append(co_factor)

        factors.sort(key=lambda f: f.score, reverse=True)

        overall = self._compute_overall(factors)
        summary = self._build_summary(item_a, item_b, factors)

        return ExplanationResult(
            item_a_id=id_a,
            item_b_id=id_b,
            factors=factors,
            summary=summary,
            overall_score=overall,
        )

    # ------------------------------------------------------------------
    # Factor computers
    # ------------------------------------------------------------------

    def _embedding_factor(self, id_a: str, id_b: str, engine: Any) -> ExplanationFactor | None:
        """Compute cosine similarity of dense embeddings from EmbeddingEngine."""
        if engine is None:
            return None

        # Try to find the underlying embedding engine (handles HybridEngine too)
        emb_engine = self._find_engine(engine, "EmbeddingEngine")
        if emb_engine is None or not emb_engine.is_fitted:
            return None

        try:
            vec_a: np.ndarray = emb_engine._get_item_vector(id_a)
            vec_b: np.ndarray = emb_engine._get_item_vector(id_b)
            score = float(
                np.dot(vec_a, vec_b) / (np.linalg.norm(vec_a) * np.linalg.norm(vec_b) + 1e-9)
            )
            score = max(0.0, min(1.0, score))
            desc = (
                f"Items share {score:.0%} semantic similarity " "based on their text descriptions."
            )
            return ExplanationFactor("embedding_similarity", score, desc)
        except Exception as exc:
            logger.debug("embedding_factor failed: %s", exc)
            return None

    def _tfidf_factor(self, id_a: str, id_b: str, engine: Any) -> ExplanationFactor | None:
        """Compute cosine similarity from TFIDFEngine."""
        if engine is None:
            return None

        tfidf_engine = self._find_engine(engine, "TFIDFEngine")
        if tfidf_engine is None or not tfidf_engine.is_fitted:
            return None

        try:
            # TFIDFEngine stores the tfidf matrix and item index
            idx_a = tfidf_engine._item_to_idx.get(id_a)
            idx_b = tfidf_engine._item_to_idx.get(id_b)
            if idx_a is None or idx_b is None:
                return None
            mat = tfidf_engine._tfidf_matrix
            from sklearn.metrics.pairwise import cosine_similarity

            score = float(cosine_similarity(mat[idx_a], mat[idx_b])[0][0])
            score = max(0.0, min(1.0, score))
            desc = f"Keyword overlap score of {score:.0%} " "based on shared TF-IDF text features."
            return ExplanationFactor("tfidf_similarity", score, desc)
        except Exception as exc:
            logger.debug("tfidf_factor failed: %s", exc)
            return None

    def _category_factor(
        self, item_a: dict[str, Any], item_b: dict[str, Any]
    ) -> ExplanationFactor | None:
        cat_a = str(item_a.get("category") or "").strip().lower()
        cat_b = str(item_b.get("category") or "").strip().lower()
        if not cat_a or not cat_b:
            return None
        if cat_a == cat_b:
            desc = f"Both items are in the '{item_a.get('category')}' category."
            return ExplanationFactor("category_match", 1.0, desc)
        return ExplanationFactor("category_match", 0.0, "Items are in different categories.")

    def _tag_overlap_factor(
        self, item_a: dict[str, Any], item_b: dict[str, Any]
    ) -> ExplanationFactor | None:
        tags_a: set[str] = self._extract_tags(item_a)
        tags_b: set[str] = self._extract_tags(item_b)
        if not tags_a and not tags_b:
            return None
        union = tags_a | tags_b
        intersection = tags_a & tags_b
        jaccard = len(intersection) / len(union) if union else 0.0
        shared = sorted(intersection)
        if shared:
            desc = f"Shared tags: {', '.join(shared[:5])}{'…' if len(shared) > 5 else ''}."
        else:
            desc = "No shared tags found."
        return ExplanationFactor("tag_overlap", jaccard, desc)

    def _co_interaction_factor(
        self, id_a: str, id_b: str, interactions: list[dict[str, Any]]
    ) -> ExplanationFactor | None:
        if not interactions:
            return None

        users_a: set[str] = set()
        users_b: set[str] = set()
        for ia in interactions:
            uid = str(ia.get("user_id", ""))
            iid = str(ia.get("item_id", ""))
            if iid == id_a:
                users_a.add(uid)
            elif iid == id_b:
                users_b.add(uid)

        if not users_a and not users_b:
            return None

        union = users_a | users_b
        intersection = users_a & users_b
        jaccard = len(intersection) / len(union) if union else 0.0
        n = len(intersection)
        desc = (
            f"{n} user{'s' if n != 1 else ''} interacted with both items."
            if n > 0
            else "No common users found in interaction history."
        )
        return ExplanationFactor("co_interaction", jaccard, desc)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _find_engine(engine: Any, class_name: str) -> Any:
        """Traverse engine (including HybridEngine) to find a named class."""
        if type(engine).__name__ == class_name:
            return engine
        # Try HybridEngine sub-engines
        engines_dict: dict[str, Any] = getattr(engine, "_engines", {})
        for sub in engines_dict.values():
            if type(sub).__name__ == class_name:
                return sub
        return None

    def _compute_overall(self, factors: list[ExplanationFactor]) -> float:
        if not factors:
            return 0.0
        total_weight = 0.0
        weighted_sum = 0.0
        for f in factors:
            w = self._weights.get(f.name, 1.0)
            weighted_sum += f.score * w
            total_weight += w
        return round(weighted_sum / total_weight, 4) if total_weight else 0.0

    @staticmethod
    def _extract_tags(item: dict[str, Any]) -> set[str]:
        raw = item.get("tags") or []
        if isinstance(raw, str):
            raw = [t.strip() for t in raw.split(",")]
        return {str(t).strip().lower() for t in raw if t}

    @staticmethod
    def _build_summary(
        item_a: dict[str, Any],
        item_b: dict[str, Any],
        factors: list[ExplanationFactor],
    ) -> str:
        name_a = item_a.get("title") or item_a.get("name") or str(item_a.get("id", "A"))
        name_b = item_b.get("title") or item_b.get("name") or str(item_b.get("id", "B"))

        if not factors:
            return f"'{name_b}' was recommended after '{name_a}'."

        top = factors[0]
        lines = [f"'{name_b}' was recommended because of '{name_a}'."]
        lines.append(f"Primary reason: {top.description}")
        if len(factors) > 1:
            extras = [f.description for f in factors[1:3]]
            lines.append("Also: " + " ".join(extras))
        return " ".join(lines)
