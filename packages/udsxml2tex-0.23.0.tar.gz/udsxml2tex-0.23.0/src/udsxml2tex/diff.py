"""Diff two UDS specifications and report added/removed/changed items."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from udsxml2tex.models import UdsSpecification


class DiffKind(str, Enum):
    """Kind of difference between two specifications."""

    ADDED = "added"
    REMOVED = "removed"
    CHANGED = "changed"


@dataclass
class DiffEntry:
    """A single difference between two UdsSpecification objects."""

    kind: DiffKind
    category: str
    item_id: str
    description: str


@dataclass
class SpecDiff:
    """Structured diff result comparing two UdsSpecification objects."""

    entries: list[DiffEntry] = field(default_factory=list)

    def added(self) -> list[DiffEntry]:
        """Return entries where kind is ADDED."""
        return [e for e in self.entries if e.kind == DiffKind.ADDED]

    def removed(self) -> list[DiffEntry]:
        """Return entries where kind is REMOVED."""
        return [e for e in self.entries if e.kind == DiffKind.REMOVED]

    def changed(self) -> list[DiffEntry]:
        """Return entries where kind is CHANGED."""
        return [e for e in self.entries if e.kind == DiffKind.CHANGED]

    def summary(self) -> str:
        """Return a human-readable summary, e.g. '3 added, 2 removed, 1 changed'."""
        n_added = len(self.added())
        n_removed = len(self.removed())
        n_changed = len(self.changed())
        return f"{n_added} added, {n_removed} removed, {n_changed} changed"

    def to_markdown(self) -> str:
        """Return a Markdown-formatted diff report grouped by category."""
        if not self.entries:
            return "No differences found.\n"

        # Group entries by category
        categories: dict[str, list[DiffEntry]] = {}
        for entry in self.entries:
            categories.setdefault(entry.category, []).append(entry)

        lines: list[str] = ["# Specification Diff\n"]
        lines.append(f"_{self.summary()}_\n")

        for category in sorted(categories):
            lines.append(f"\n## {category}\n")
            cat_entries = categories[category]
            for entry in cat_entries:
                kind_label = entry.kind.value.upper()
                lines.append(f"- **[{kind_label}]** `{entry.item_id}`: {entry.description}")

        return "\n".join(lines) + "\n"

    def __len__(self) -> int:
        return len(self.entries)


class SpecDiffer:
    """Compares two UdsSpecification objects and produces a SpecDiff."""

    def diff(self, spec_a: UdsSpecification, spec_b: UdsSpecification) -> SpecDiff:
        """Return a SpecDiff describing all differences from spec_a to spec_b."""
        result = SpecDiff()
        entries = result.entries

        self._diff_sessions(spec_a, spec_b, entries)
        self._diff_security_levels(spec_a, spec_b, entries)
        self._diff_services(spec_a, spec_b, entries)
        self._diff_dids(spec_a, spec_b, entries)
        self._diff_routines(spec_a, spec_b, entries)
        self._diff_dtcs(spec_a, spec_b, entries)
        self._diff_memory_ranges(spec_a, spec_b, entries)

        return result

    # ------------------------------------------------------------------
    # Per-category diff helpers
    # ------------------------------------------------------------------

    def _diff_sessions(
        self,
        spec_a: UdsSpecification,
        spec_b: UdsSpecification,
        entries: list[DiffEntry],
    ) -> None:
        a_map = {s.session_id: s for s in spec_a.sessions}
        b_map = {s.session_id: s for s in spec_b.sessions}

        for sid in sorted(set(a_map) | set(b_map)):
            item_id = f"0x{sid:02X}"
            if sid not in a_map:
                entries.append(DiffEntry(
                    kind=DiffKind.ADDED,
                    category="sessions",
                    item_id=item_id,
                    description=f"Session '{b_map[sid].short_name}' added",
                ))
            elif sid not in b_map:
                entries.append(DiffEntry(
                    kind=DiffKind.REMOVED,
                    category="sessions",
                    item_id=item_id,
                    description=f"Session '{a_map[sid].short_name}' removed",
                ))
            else:
                a, b = a_map[sid], b_map[sid]
                changes: list[str] = []
                if a.short_name != b.short_name:
                    changes.append(f"short_name: '{a.short_name}' → '{b.short_name}'")
                if a.p2_server_max != b.p2_server_max:
                    changes.append(f"p2_server_max: {a.p2_server_max} → {b.p2_server_max}")
                if a.p2_star_server_max != b.p2_star_server_max:
                    changes.append(
                        f"p2_star_server_max: {a.p2_star_server_max} → {b.p2_star_server_max}"
                    )
                if changes:
                    entries.append(DiffEntry(
                        kind=DiffKind.CHANGED,
                        category="sessions",
                        item_id=item_id,
                        description="; ".join(changes),
                    ))

    def _diff_security_levels(
        self,
        spec_a: UdsSpecification,
        spec_b: UdsSpecification,
        entries: list[DiffEntry],
    ) -> None:
        a_map = {sl.security_level: sl for sl in spec_a.security_levels}
        b_map = {sl.security_level: sl for sl in spec_b.security_levels}

        for lvl in sorted(set(a_map) | set(b_map)):
            item_id = f"0x{lvl:02X}"
            if lvl not in a_map:
                entries.append(DiffEntry(
                    kind=DiffKind.ADDED,
                    category="security_levels",
                    item_id=item_id,
                    description=f"Security level '{b_map[lvl].short_name}' added",
                ))
            elif lvl not in b_map:
                entries.append(DiffEntry(
                    kind=DiffKind.REMOVED,
                    category="security_levels",
                    item_id=item_id,
                    description=f"Security level '{a_map[lvl].short_name}' removed",
                ))
            else:
                a, b = a_map[lvl], b_map[lvl]
                changes: list[str] = []
                if a.short_name != b.short_name:
                    changes.append(f"short_name: '{a.short_name}' → '{b.short_name}'")
                if a.key_size != b.key_size:
                    changes.append(f"key_size: {a.key_size} → {b.key_size}")
                if a.seed_size != b.seed_size:
                    changes.append(f"seed_size: {a.seed_size} → {b.seed_size}")
                if a.num_max_attempts != b.num_max_attempts:
                    changes.append(
                        f"num_max_attempts: {a.num_max_attempts} → {b.num_max_attempts}"
                    )
                if changes:
                    entries.append(DiffEntry(
                        kind=DiffKind.CHANGED,
                        category="security_levels",
                        item_id=item_id,
                        description="; ".join(changes),
                    ))

    def _diff_services(
        self,
        spec_a: UdsSpecification,
        spec_b: UdsSpecification,
        entries: list[DiffEntry],
    ) -> None:
        a_map = {s.service_id: s for s in spec_a.services}
        b_map = {s.service_id: s for s in spec_b.services}

        for sid in sorted(set(a_map) | set(b_map)):
            item_id = f"0x{sid:02X}"
            if sid not in a_map:
                entries.append(DiffEntry(
                    kind=DiffKind.ADDED,
                    category="services",
                    item_id=item_id,
                    description=f"Service '{b_map[sid].short_name}' added",
                ))
            elif sid not in b_map:
                entries.append(DiffEntry(
                    kind=DiffKind.REMOVED,
                    category="services",
                    item_id=item_id,
                    description=f"Service '{a_map[sid].short_name}' removed",
                ))
            else:
                a, b = a_map[sid], b_map[sid]
                changes: list[str] = []
                if a.short_name != b.short_name:
                    changes.append(f"short_name: '{a.short_name}' → '{b.short_name}'")
                if sorted(a.supported_sessions) != sorted(b.supported_sessions):
                    changes.append(
                        f"supported_sessions: {sorted(a.supported_sessions)!r} "
                        f"→ {sorted(b.supported_sessions)!r}"
                    )
                if sorted(a.required_security_levels) != sorted(b.required_security_levels):
                    changes.append(
                        f"required_security_levels: "
                        f"{sorted(a.required_security_levels)!r} "
                        f"→ {sorted(b.required_security_levels)!r}"
                    )
                a_nrcs = sorted(n.nrc_code for n in a.nrc_list)
                b_nrcs = sorted(n.nrc_code for n in b.nrc_list)
                if a_nrcs != b_nrcs:
                    changes.append(
                        f"nrc_list: {[f'0x{c:02X}' for c in a_nrcs]!r} "
                        f"→ {[f'0x{c:02X}' for c in b_nrcs]!r}"
                    )
                if changes:
                    entries.append(DiffEntry(
                        kind=DiffKind.CHANGED,
                        category="services",
                        item_id=item_id,
                        description="; ".join(changes),
                    ))

    def _diff_dids(
        self,
        spec_a: UdsSpecification,
        spec_b: UdsSpecification,
        entries: list[DiffEntry],
    ) -> None:
        a_map = {d.did_id: d for d in spec_a.dids}
        b_map = {d.did_id: d for d in spec_b.dids}

        for did_id in sorted(set(a_map) | set(b_map)):
            item_id = f"0x{did_id:04X}"
            if did_id not in a_map:
                entries.append(DiffEntry(
                    kind=DiffKind.ADDED,
                    category="dids",
                    item_id=item_id,
                    description=f"DID '{b_map[did_id].short_name}' added",
                ))
            elif did_id not in b_map:
                entries.append(DiffEntry(
                    kind=DiffKind.REMOVED,
                    category="dids",
                    item_id=item_id,
                    description=f"DID '{a_map[did_id].short_name}' removed",
                ))
            else:
                a, b = a_map[did_id], b_map[did_id]
                changes: list[str] = []
                if a.short_name != b.short_name:
                    changes.append(f"short_name: '{a.short_name}' → '{b.short_name}'")
                if a.read_access != b.read_access:
                    changes.append(f"read_access: {a.read_access} → {b.read_access}")
                if a.write_access != b.write_access:
                    changes.append(f"write_access: {a.write_access} → {b.write_access}")
                if a.total_byte_length != b.total_byte_length:
                    changes.append(
                        f"total_byte_length: {a.total_byte_length} → {b.total_byte_length}"
                    )
                a_elem_count = len(a.data_elements)
                b_elem_count = len(b.data_elements)
                if a_elem_count != b_elem_count:
                    changes.append(
                        f"data_elements count: {a_elem_count} → {b_elem_count}"
                    )
                if changes:
                    entries.append(DiffEntry(
                        kind=DiffKind.CHANGED,
                        category="dids",
                        item_id=item_id,
                        description="; ".join(changes),
                    ))

    def _diff_routines(
        self,
        spec_a: UdsSpecification,
        spec_b: UdsSpecification,
        entries: list[DiffEntry],
    ) -> None:
        a_map = {r.routine_id: r for r in spec_a.routines}
        b_map = {r.routine_id: r for r in spec_b.routines}

        for rid in sorted(set(a_map) | set(b_map)):
            item_id = f"0x{rid:04X}"
            if rid not in a_map:
                entries.append(DiffEntry(
                    kind=DiffKind.ADDED,
                    category="routines",
                    item_id=item_id,
                    description=f"Routine '{b_map[rid].short_name}' added",
                ))
            elif rid not in b_map:
                entries.append(DiffEntry(
                    kind=DiffKind.REMOVED,
                    category="routines",
                    item_id=item_id,
                    description=f"Routine '{a_map[rid].short_name}' removed",
                ))
            else:
                a, b = a_map[rid], b_map[rid]
                changes: list[str] = []
                if a.short_name != b.short_name:
                    changes.append(f"short_name: '{a.short_name}' → '{b.short_name}'")
                if len(a.in_parameters) != len(b.in_parameters):
                    changes.append(
                        f"in_parameters count: {len(a.in_parameters)} → {len(b.in_parameters)}"
                    )
                if len(a.out_parameters) != len(b.out_parameters):
                    changes.append(
                        f"out_parameters count: {len(a.out_parameters)} → {len(b.out_parameters)}"
                    )
                if changes:
                    entries.append(DiffEntry(
                        kind=DiffKind.CHANGED,
                        category="routines",
                        item_id=item_id,
                        description="; ".join(changes),
                    ))

    def _diff_dtcs(
        self,
        spec_a: UdsSpecification,
        spec_b: UdsSpecification,
        entries: list[DiffEntry],
    ) -> None:
        a_map = {d.dtc_id: d for d in spec_a.dtcs}
        b_map = {d.dtc_id: d for d in spec_b.dtcs}

        for dtc_id in sorted(set(a_map) | set(b_map)):
            item_id = f"0x{dtc_id:06X}"
            if dtc_id not in a_map:
                entries.append(DiffEntry(
                    kind=DiffKind.ADDED,
                    category="dtcs",
                    item_id=item_id,
                    description=f"DTC '{b_map[dtc_id].short_name}' added",
                ))
            elif dtc_id not in b_map:
                entries.append(DiffEntry(
                    kind=DiffKind.REMOVED,
                    category="dtcs",
                    item_id=item_id,
                    description=f"DTC '{a_map[dtc_id].short_name}' removed",
                ))
            else:
                a, b = a_map[dtc_id], b_map[dtc_id]
                changes: list[str] = []
                if a.short_name != b.short_name:
                    changes.append(f"short_name: '{a.short_name}' → '{b.short_name}'")
                if a.description != b.description:
                    changes.append(f"description changed")
                if a.severity != b.severity:
                    changes.append(f"severity: '{a.severity}' → '{b.severity}'")
                if changes:
                    entries.append(DiffEntry(
                        kind=DiffKind.CHANGED,
                        category="dtcs",
                        item_id=item_id,
                        description="; ".join(changes),
                    ))

    def _diff_memory_ranges(
        self,
        spec_a: UdsSpecification,
        spec_b: UdsSpecification,
        entries: list[DiffEntry],
    ) -> None:
        a_map = {mr.short_name: mr for mr in spec_a.memory_ranges}
        b_map = {mr.short_name: mr for mr in spec_b.memory_ranges}

        for name in sorted(set(a_map) | set(b_map)):
            if name not in a_map:
                entries.append(DiffEntry(
                    kind=DiffKind.ADDED,
                    category="memory_ranges",
                    item_id=name,
                    description=f"Memory range '{name}' added",
                ))
            elif name not in b_map:
                entries.append(DiffEntry(
                    kind=DiffKind.REMOVED,
                    category="memory_ranges",
                    item_id=name,
                    description=f"Memory range '{name}' removed",
                ))
            else:
                a, b = a_map[name], b_map[name]
                changes: list[str] = []
                if a.start_address != b.start_address:
                    changes.append(
                        f"start_address: 0x{a.start_address:08X} → 0x{b.start_address:08X}"
                    )
                if a.end_address != b.end_address:
                    changes.append(
                        f"end_address: 0x{a.end_address:08X} → 0x{b.end_address:08X}"
                    )
                if a.read_access != b.read_access:
                    changes.append(f"read_access: {a.read_access} → {b.read_access}")
                if a.write_access != b.write_access:
                    changes.append(f"write_access: {a.write_access} → {b.write_access}")
                if changes:
                    entries.append(DiffEntry(
                        kind=DiffKind.CHANGED,
                        category="memory_ranges",
                        item_id=name,
                        description="; ".join(changes),
                    ))


def diff_specs(a: UdsSpecification, b: UdsSpecification) -> SpecDiff:
    """Convenience function: diff two UdsSpecification objects."""
    return SpecDiffer().diff(a, b)


__all__ = [
    "DiffKind",
    "DiffEntry",
    "SpecDiff",
    "SpecDiffer",
    "diff_specs",
]
