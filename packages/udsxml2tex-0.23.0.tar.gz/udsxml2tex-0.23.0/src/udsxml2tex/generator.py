"""LaTeX generator for UDS specification documents."""

from __future__ import annotations

import io
import logging
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path
from typing import Optional

from jinja2 import Environment, FileSystemLoader, select_autoescape

from udsxml2tex.models import (
    DTC_SEVERITY_LEVELS,
    DTC_STATUS_BIT_DEFINITIONS,
    ISO14229_SERVICE_ORDER,
    NRC_CHECK_ORDER,
    STANDARD_NRCS,
    UDS_MESSAGE_FORMATS,
    UdsSpecification,
)

logger = logging.getLogger(__name__)

# Characters that need escaping in LaTeX
_LATEX_ESCAPE_MAP = {
    "&": r"\&",
    "%": r"\%",
    "$": r"\$",
    "#": r"\#",
    "_": r"\_",
    "{": r"\{",
    "}": r"\}",
    "~": r"\textasciitilde{}",
    "^": r"\textasciicircum{}",
}


def _latex_escape(text: str) -> str:
    """Escape special LaTeX characters in text."""
    if not text:
        return ""
    # Don't escape backslashes that are already LaTeX commands
    result = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "\\" and i + 1 < len(text) and text[i + 1].isalpha():
            # Likely a LaTeX command, don't escape
            result.append(ch)
        elif ch in _LATEX_ESCAPE_MAP:
            result.append(_LATEX_ESCAPE_MAP[ch])
        else:
            result.append(ch)
        i += 1
    return "".join(result)


def _strip_0x(text: str) -> str:
    """Strip '0x' or '0X' prefix from hex string for subscript-16 notation."""
    if isinstance(text, str) and text.lower().startswith("0x"):
        return text[2:]
    return str(text)


class TexGenerator:
    """Generate LaTeX documents from UDS specification data."""

    def __init__(self, template_dir: Optional[str | Path] = None) -> None:
        """Initialize the TeX generator.

        Args:
            template_dir: Directory containing Jinja2 templates.
                         Defaults to the built-in templates directory.
        """
        if template_dir is None:
            template_dir = Path(__file__).parent / "templates"
        else:
            template_dir = Path(template_dir)

        self.template_dir = template_dir
        self.env = Environment(
            loader=FileSystemLoader(str(template_dir)),
            block_start_string=r"\BLOCK{",
            block_end_string="}",
            variable_start_string=r"\VAR{",
            variable_end_string="}",
            comment_start_string=r"\#{",
            comment_end_string="}",
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        # Register custom filters
        self.env.filters["latex_escape"] = _latex_escape
        self.env.filters["strip_0x"] = _strip_0x
        self.env.filters["bitand"] = lambda value, mask: bool(int(value) & int(mask))

    def generate(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        template_name: str = "uds_spec.tex.j2",
        *,
        extra_vars: Optional[dict] = None,
    ) -> Path:
        """Generate a LaTeX document from the UDS specification.

        Args:
            spec:          The UDS specification data.
            output_path:   Path for the output .tex file.
            template_name: Name of the Jinja2 template to use.
            extra_vars:    Optional dict merged into the Jinja2 template context,
                           enabling project-specific variables in custom templates.

        Returns:
            Path to the generated .tex file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        context = self._build_context(spec)
        if extra_vars:
            context.update(extra_vars)

        template = self.env.get_template(template_name)
        rendered = template.render(**context)
        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated LaTeX document: %s", output_path)

        for asset in ("tikz-uml.sty", "udsspec.cls"):
            src = self.template_dir / asset
            if src.exists():
                dst = output_path.parent / asset
                if not dst.exists():
                    shutil.copy2(src, dst)
                    logger.info("Copied %s to %s", asset, dst)

        return output_path

    def generate_string(
        self,
        spec: UdsSpecification,
        template_name: str = "uds_spec.tex.j2",
    ) -> str:
        """Generate LaTeX content as a string.

        Args:
            spec: The UDS specification data.
            template_name: Name of the Jinja2 template to use.

        Returns:
            Rendered LaTeX content.
        """
        template = self.env.get_template(template_name)
        return template.render(**self._build_context(spec))

    def _build_context(self, spec: UdsSpecification) -> dict:
        """Build the shared Jinja2 template context from a UdsSpecification."""
        services = sorted(
            spec.services,
            key=lambda s: ISO14229_SERVICE_ORDER.get(s.service_id, 100),
        )
        dids = sorted(spec.dids, key=lambda d: d.did_id)
        routines = sorted(spec.routines, key=lambda r: r.routine_id)
        sessions = sorted(spec.sessions, key=lambda s: s.session_id)
        security_levels = sorted(spec.security_levels, key=lambda s: s.security_level)

        transport_config = spec.transport_config
        cantp_channels = transport_config.channels if transport_config else []

        session_names = sorted({n for s in services for n in s.supported_sessions})
        security_level_names = sorted(
            {n for s in services for n in s.required_security_levels}
        )

        return {
            "ecu_name": spec.ecu_name,
            "description": spec.description,
            "protocol_name": spec.protocol_name,
            "protocol_type": spec.protocol_type,
            "can_rx_id": spec.can_rx_id,
            "can_tx_id": spec.can_tx_id,
            "can_functional_id": spec.can_functional_id,
            "s3_server": spec.s3_server,
            "dsl_rx_buffer_size": spec.dsl_rx_buffer_size,
            "dsl_tx_buffer_size": spec.dsl_tx_buffer_size,
            "sessions": sessions,
            "security_levels": security_levels,
            "services": services,
            "dids": dids,
            "routines": routines,
            "dtcs": sorted(spec.dtcs, key=lambda d: d.dtc_id),
            "memory_ranges": spec.memory_ranges,
            "io_control_dids": sorted(spec.io_control_dids, key=lambda d: d.did_id),
            "periodic_dids": sorted(spec.periodic_dids, key=lambda d: d.did_id),
            "did_ranges": sorted(spec.did_ranges, key=lambda d: d.lower_did),
            "transport_config": transport_config,
            "cantp_channels": cantp_channels,
            "message_formats": UDS_MESSAGE_FORMATS,
            "nrc_check_order": NRC_CHECK_ORDER,
            "standard_nrcs": STANDARD_NRCS,
            "session_names": session_names,
            "security_level_names": security_level_names,
            "com_control": spec.com_control,
            "response_on_event": spec.response_on_event,
            "dtc_status_availability_mask": spec.dtc_status_availability_mask,
            "max_num_resp_pend": spec.max_num_resp_pend,
            "max_response_length": spec.max_response_length,
            "request_file_transfer": spec.request_file_transfer,
            "clear_dtc_notifications": spec.clear_dtc_notifications,
            "dynamic_dids": sorted(spec.dynamic_dids, key=lambda d: d.did_id),
            "connection_mode": spec.connection_mode,
            "connection_end_of_type": spec.connection_end_of_type,
            "cdtc_status_mask": spec.cdtc_status_mask,
            "clear_dtc_group": spec.clear_dtc_group,
            "module_main_function_period": spec.module_main_function_period,
            "enable_fim_trigger": spec.enable_fim_trigger,
            "protocol_priority": spec.protocol_priority,
            "protocol_trans_type": spec.protocol_trans_type,
            "protocol_preempt_timeout": spec.protocol_preempt_timeout,
            "periodic_slow_rate": spec.periodic_slow_rate,
            "periodic_medium_rate": spec.periodic_medium_rate,
            "periodic_fast_rate": spec.periodic_fast_rate,
            "memory_compression_method": spec.memory_compression_method,
            "memory_encrypting_method": spec.memory_encrypting_method,
            "dev_error_detect": spec.dev_error_detect,
            "version_info_api": spec.version_info_api,
            "task_time": spec.task_time,
            "respond_all_request": spec.respond_all_request,
            "protocol_rows": sorted(spec.protocol_rows, key=lambda r: r.priority),
            "authentication_config": spec.authentication_config,
            "access_timing_rows": spec.access_timing_rows,
            # DEM (Diagnostic Event Manager)
            "dem_general": spec.dem_general,
            "dem_operation_cycles": spec.dem_operation_cycles,
            "dem_event_parameters": sorted(
                spec.dem_event_parameters, key=lambda e: e.event_id
            ),
            "dem_indicators": spec.dem_indicators,
            "dem_enable_conditions": spec.dem_enable_conditions,
            "dem_storage_conditions": spec.dem_storage_conditions,
            "dem_event_memories": spec.dem_event_memories,
            "dem_dtcs": sorted(spec.dem_dtcs, key=lambda d: d.dtc_value),
            "dem_freeze_frame_classes": spec.dem_freeze_frame_classes,
            "dem_extended_data_classes": sorted(
                spec.dem_extended_data_classes, key=lambda e: e.record_number
            ),
            "dem_combined_dtcs": sorted(
                spec.dem_combined_dtcs, key=lambda d: d.combined_dtc_value
            ),
            # ISO 14229-1 constant tables for template rendering
            "dtc_status_bit_definitions": DTC_STATUS_BIT_DEFINITIONS,
            "dtc_severity_levels": DTC_SEVERITY_LEVELS,
            # Upload/Download max block length (ISO 14229-1 §13)
            "max_block_length": spec.max_block_length,
            # LinkControl (0x87) supported baud rates
            "link_control_baudrates": sorted(
                spec.link_control_baudrates, key=lambda b: b.baudrate_value
            ),
            # Named DTC groups (DcmDspGroupOfDTC)
            "dtc_groups": sorted(spec.dtc_groups, key=lambda g: g.group_value),
            # TikZ diagrams (non-standalone figures for inclusion)
            "session_state_diagram": _build_session_state_tikz(sessions, spec.s3_server),
            "nrc_flowcharts": {
                f"0x{svc.service_id:02X}": _build_nrc_flowchart_tikz(svc)
                for svc in services
            },
        }

    # ---- PDF compilation ------------------------------------------------

    def compile_pdf(
        self,
        tex_path: str | Path,
        *,
        clean: bool = True,
    ) -> Path:
        """Compile a .tex file to PDF using latexmk or pdflatex.

        Args:
            tex_path: Path to the .tex file.
            clean: Remove auxiliary files after compilation.

        Returns:
            Path to the generated PDF.

        Raises:
            FileNotFoundError: If no LaTeX compiler is found.
            RuntimeError: If compilation fails.
        """
        tex_path = Path(tex_path).resolve()
        if not tex_path.exists():
            raise FileNotFoundError(f"TeX file not found: {tex_path}")

        work_dir = tex_path.parent

        # Prefer latexmk (handles multiple passes automatically)
        latexmk = shutil.which("latexmk")
        pdflatex = shutil.which("pdflatex")

        if latexmk:
            cmd = [
                latexmk,
                "-pdf",
                "-interaction=nonstopmode",
                "-halt-on-error",
                str(tex_path.name),
            ]
            if clean:
                clean_cmd = [latexmk, "-c", str(tex_path.name)]
        elif pdflatex:
            # Run pdflatex twice for TOC / references
            cmd = [
                pdflatex,
                "-interaction=nonstopmode",
                "-halt-on-error",
                str(tex_path.name),
            ]
            clean_cmd = None
        else:
            raise FileNotFoundError(
                "No LaTeX compiler found. Install TeX Live or MiKTeX "
                "(latexmk or pdflatex must be on PATH)."
            )

        logger.info("Compiling PDF: %s", " ".join(cmd))
        runs = 1 if latexmk else 2
        for i in range(runs):
            result = subprocess.run(
                cmd,
                cwd=str(work_dir),
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode != 0:
                logger.error("LaTeX stdout:\n%s", result.stdout[-2000:])
                logger.error("LaTeX stderr:\n%s", result.stderr[-2000:])
                raise RuntimeError(
                    f"LaTeX compilation failed (exit {result.returncode}). "
                    f"Check log file for details."
                )

        pdf_path = tex_path.with_suffix(".pdf")
        if not pdf_path.exists():
            raise RuntimeError(f"Expected PDF not found: {pdf_path}")

        # Clean auxiliary files
        if clean and latexmk and clean_cmd:
            subprocess.run(clean_cmd, cwd=str(work_dir), capture_output=True)

        logger.info("PDF generated: %s", pdf_path)
        return pdf_path

    # ---- HTML generation ------------------------------------------------

    def generate_html(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        template_name: str = "uds_spec.html.j2",
    ) -> Path:
        """Generate an HTML document from the UDS specification.

        Args:
            spec: The UDS specification data.
            output_path: Path for the output .html file.
            template_name: Name of the HTML Jinja2 template.

        Returns:
            Path to the generated .html file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Create a separate Jinja2 environment with standard delimiters for HTML
        html_env = Environment(
            loader=FileSystemLoader(str(self.template_dir)),
            autoescape=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        html_env.filters["strip_0x"] = _strip_0x

        def _html_hex(value: str) -> str:
            """Render hex value with subscript-16 notation in HTML."""
            v = _strip_0x(str(value))
            return f'<span class="hexval">{v}<sub>16</sub></span>'

        html_env.filters["hexval"] = _html_hex

        template = html_env.get_template(template_name)
        rendered = template.render(**self._build_context(spec))
        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated HTML document: %s", output_path)
        return output_path

    # ---- Structured multi-file LaTeX ZIP --------------------------------

    def generate_structured_tex_zip(
        self,
        spec: "UdsSpecification",
        output_path: "str | Path",
        cls_content: Optional[bytes] = None,
    ) -> Path:
        """Generate a structured multi-file LaTeX project and package it as a ZIP.

        The ZIP mirrors the layout of refs/uds-tex-spec with root.tex plus
        nested sections/, and optionally includes a custom .cls file.

        Args:
            spec: Parsed UDS specification.
            output_path: Destination path for the output ZIP file.
            cls_content: Raw bytes of an optional custom LaTeX class file to
                         include as ``custom.cls`` in the ZIP root.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        structured_dir = Path(__file__).parent / "templates" / "structured_tex"

        # Build a Jinja2 environment pointing at structured_tex/
        from jinja2 import Environment, FileSystemLoader

        tex_env = Environment(
            loader=FileSystemLoader(str(structured_dir)),
            block_start_string=r"\BLOCK{",
            block_end_string="}",
            variable_start_string=r"\VAR{",
            variable_end_string="}",
            comment_start_string=r"\#{",
            comment_end_string="}",
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
            keep_trailing_newline=True,
        )
        tex_env.filters["latex_escape"] = _latex_escape
        tex_env.filters["strip_0x"] = _strip_0x
        tex_env.filters["bitand"] = lambda value, mask: bool(int(value) & int(mask))

        context = self._build_context(spec)

        # Gather all .j2 template files relative to structured_dir
        template_files = sorted(structured_dir.rglob("*.j2"))

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)

            for tmpl_path in template_files:
                rel = tmpl_path.relative_to(structured_dir)
                # Strip the .j2 extension to get the output filename
                out_rel = rel.with_suffix("")  # e.g. root.tex.j2 -> root.tex
                out_path = tmp / out_rel
                out_path.parent.mkdir(parents=True, exist_ok=True)

                template = tex_env.get_template(str(rel).replace("\\", "/"))
                rendered = template.render(**context)
                out_path.write_text(rendered, encoding="utf-8")
                logger.debug("Rendered structured template: %s", out_rel)

            # Copy tikz-uml.sty to zip root
            sty_src = Path(__file__).parent / "templates" / "tikz-uml.sty"
            if sty_src.exists():
                shutil.copy2(sty_src, tmp / "tikz-uml.sty")

            # Optionally write custom .cls file
            if cls_content is not None:
                (tmp / "custom.cls").write_bytes(cls_content)

            # Build the ZIP
            with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for f in sorted(tmp.rglob("*")):
                    if f.is_file():
                        zf.write(f, f.relative_to(tmp))

        logger.info("Generated structured LaTeX ZIP: %s", output_path)
        return output_path

    # ---- Multi-page HTML ZIP --------------------------------------------

    def generate_html_zip(
        self,
        spec: "UdsSpecification",
        output_path: "str | Path",
    ) -> Path:
        """Generate a browsable multi-page HTML UDS specification and ZIP it.

        Creates index.html plus per-section HTML pages that can be opened
        locally in any browser.

        Args:
            spec: Parsed UDS specification.
            output_path: Destination path for the output ZIP file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        ctx = self._build_context(spec)
        services = ctx.get("services", [])

        # Build per-service nav children
        svc_children = []
        for i, svc in enumerate(services, start=2):
            sid_clean = svc.service_id_hex.replace("0x", "").lower()
            path = f"sections/2_high_layer/sid{sid_clean}/index.html"
            svc_children.append({
                "path": path,
                "title": f"§5.{i} {svc.short_name}",
                "children": [],
            })

        # Navigation tree mirroring the structured LaTeX sections/ layout
        nav_tree = [
            {"path": "index.html", "title": "Overview", "children": []},
            {"path": "sections/0_intro/index.html", "title": "Introduction", "children": []},
            {"path": "sections/1_low_layer/index.html", "title": "§4 Network Protocol Layers",
             "children": [
                 {"path": "sections/1_low_layer/2_datalink/index.html",  "title": "§4.1 Data Link",  "children": []},
                 {"path": "sections/1_low_layer/3_network/index.html",   "title": "§4.2 Network",    "children": []},
                 {"path": "sections/1_low_layer/4_transport/index.html", "title": "§4.3 Transport",  "children": []},
                 {"path": "sections/1_low_layer/5_session/index.html",   "title": "§4.4 Session",    "children": []},
             ]},
            {"path": "sections/2_high_layer/index.html", "title": "§5 Application Layers",
             "children": svc_children},
            {"path": "sections/A_annex/index.html", "title": "Annex", "children": []},
        ]

        # Flat ordered page list: (path, title, renderer)
        pages: list[tuple[str, str, object]] = [
            ("index.html",                                          "Overview",                   _render_html_index),
            ("sections/0_intro/index.html",                        "Introduction",               _render_html_intro),
            ("sections/1_low_layer/index.html",                    "§4 Network Protocol Layers", _render_html_low_layer_index),
            ("sections/1_low_layer/2_datalink/index.html",         "§4.1 Data Link Layer",  _render_html_low_datalink),
            ("sections/1_low_layer/3_network/index.html",          "§4.2 Network Layer",    _render_html_low_network),
            ("sections/1_low_layer/4_transport/index.html",        "§4.3 Transport Layer",  _render_html_low_transport),
            ("sections/1_low_layer/5_session/index.html",          "§4.4 Session Layer",    _render_html_low_session),
            ("sections/2_high_layer/index.html",                   "§5 Application Layers", _render_html_high_overview),
        ]
        for i, svc in enumerate(services, start=2):
            sid_clean = svc.service_id_hex.replace("0x", "").lower()
            path = f"sections/2_high_layer/sid{sid_clean}/index.html"
            title = f"§5.{i} {svc.short_name}"
            pages.append((path, title, lambda c, s=svc, idx=i: _render_html_service_page(c, s, idx)))
        pages.append(("sections/A_annex/index.html", "Annex", _render_html_annex))

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)

            for page_path, title, renderer in pages:
                nav_html   = _build_nav_html(nav_tree, page_path)
                page_ctx   = {**ctx, "_current_path": page_path}
                body       = renderer(page_ctx)
                page_html  = _html_page(title, nav_html, body, _HTML_CSS)
                out_file   = tmp / Path(page_path)
                out_file.parent.mkdir(parents=True, exist_ok=True)
                out_file.write_text(page_html, encoding="utf-8")

            with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for f in sorted(tmp.rglob("*")):
                    if f.is_file():
                        zf.write(f, f.relative_to(tmp))

        logger.info("Generated HTML ZIP: %s", output_path)
        return output_path

    # ---- JSON / YAML output ---------------------------------------------

    def generate_json(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Serialize the specification to JSON."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(spec.to_json(), encoding="utf-8")
        logger.info("Generated JSON document: %s", output_path)
        return output_path

    def generate_yaml(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Serialize the specification to YAML."""
        try:
            import yaml  # type: ignore[import]
        except ImportError:
            raise ImportError(
                "PyYAML is required for YAML output. "
                "Install it with: pip install udsxml2tex[yaml]"
            )
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            yaml.dump(spec.to_dict(), allow_unicode=True, default_flow_style=False),
            encoding="utf-8",
        )
        logger.info("Generated YAML document: %s", output_path)
        return output_path

    # ---- Markdown output ------------------------------------------------

    def generate_markdown(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Generate a Markdown specification document."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(_render_markdown(spec), encoding="utf-8")
        logger.info("Generated Markdown document: %s", output_path)
        return output_path

    # ---- RST output -----------------------------------------------------

    def generate_rst(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Generate a reStructuredText specification document."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(_render_rst(spec), encoding="utf-8")
        logger.info("Generated RST document: %s", output_path)
        return output_path

    # ---- CSV output -----------------------------------------------------

    def generate_csv(
        self,
        spec: UdsSpecification,
        output_dir: str | Path,
    ) -> list[Path]:
        """Generate CSV files (one per major category) in *output_dir*.

        Returns:
            List of paths to the generated CSV files.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        return _render_csv(spec, output_dir)

    # ---- Session state-machine diagram ----------------------------------

    def generate_session_diagram(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Generate a standalone TikZ session-transition diagram (.tex)."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(_render_session_tikz(spec), encoding="utf-8")
        logger.info("Generated session diagram: %s", output_path)
        return output_path

    # ---- DOCX output ----------------------------------------------------

    def generate_docx(
        self,
        spec: UdsSpecification,
        path: "str | Path",
    ) -> Path:
        """Generate a DOCX document from the UDS specification.

        Requires: pip install udsxml2tex[docx]
        """
        try:
            from docx import Document  # type: ignore[import]
            from docx.shared import Pt, RGBColor  # type: ignore[import]
            from docx.enum.text import WD_ALIGN_PARAGRAPH  # type: ignore[import]
        except ImportError as exc:
            raise ImportError(
                "python-docx is required for DOCX output. "
                "Install with: pip install udsxml2tex[docx]"
            ) from exc
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        _render_docx(spec, path)
        logger.info("Generated DOCX document: %s", path)
        return path

    # ---- UML sequence diagrams ------------------------------------------

    def generate_sequence_diagrams(
        self,
        spec: UdsSpecification,
        output_dir: "str | Path",
    ) -> "list[Path]":
        """Generate TikZ sequence diagram .tex files into *output_dir*.

        Creates:
          - security_access_sequence.tex
          - routine_control_sequence.tex
          - upload_download_sequence.tex

        Returns:
            List of Path objects for the generated files.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        written: list[Path] = []

        # 1. SecurityAccess flow
        sa_participants = ["Tester", "ECU"]
        sa_messages = [
            ("Tester", "ECU", "Request Seed (27 01)", ""),
            ("ECU", "Tester", "Seed Response (67 01 seed...)", ""),
            ("Tester", "ECU", "Send Key (27 02 key...)", ""),
            ("ECU", "Tester", "Positive Response (67 02)", ""),
            ("ECU", "Tester", "NRC: invalidKey (35)", "dashed"),
            ("ECU", "Tester", "NRC: exceededNumberOfAttempts (36)", "dashed"),
            ("ECU", "Tester", "NRC: requiredTimeDelayNotExpired (37)", "dashed"),
        ]
        sa_path = output_dir / "security_access_sequence.tex"
        sa_path.write_text(
            _render_sequence_tikz("SecurityAccess Flow", sa_participants, sa_messages),
            encoding="utf-8",
        )
        written.append(sa_path)

        # 2. RoutineControl flow
        rc_participants = ["Tester", "ECU"]
        rc_messages = [
            ("Tester", "ECU", "Start Routine (31 01 routineId...)", ""),
            ("ECU", "Tester", "Positive Response (71 01 routineId...)", ""),
            ("Tester", "ECU", "Request Routine Results (31 03 routineId...)", ""),
            ("ECU", "Tester", "Results (71 03 routineId... statusRecord)", ""),
        ]
        rc_path = output_dir / "routine_control_sequence.tex"
        rc_path.write_text(
            _render_sequence_tikz("RoutineControl Flow", rc_participants, rc_messages),
            encoding="utf-8",
        )
        written.append(rc_path)

        # 3. Upload/Download flow
        ud_participants = ["Tester", "ECU"]
        ud_messages = [
            ("Tester", "ECU", "Request Download (34)", ""),
            ("ECU", "Tester", "maxBlockLength Response (74)", ""),
            ("Tester", "ECU", "Transfer Data [1] (36 01 data...)", ""),
            ("ECU", "Tester", "Transfer Data Response (76 01)", ""),
            ("Tester", "ECU", "... [loop] Transfer Data [N] (36 N data...)", ""),
            ("ECU", "Tester", "Transfer Data Response [N] (76 N)", ""),
            ("Tester", "ECU", "Request Transfer Exit (37)", ""),
            ("ECU", "Tester", "Positive Response (77)", ""),
        ]
        ud_path = output_dir / "upload_download_sequence.tex"
        ud_path.write_text(
            _render_sequence_tikz("Upload/Download Flow", ud_participants, ud_messages),
            encoding="utf-8",
        )
        written.append(ud_path)

        logger.info("Generated %d sequence diagram(s) in %s", len(written), output_dir)
        return written

    # ---- Byte-level visualization (bytefield) ----------------------------

    def generate_byte_diagrams(
        self,
        spec: UdsSpecification,
        output_dir: "str | Path",
    ) -> Path:
        """Generate did_byte_fields.tex using LaTeX bytefield package.

        Only DIDs with at least one data element are included.

        Returns:
            Path to the generated did_byte_fields.tex file.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        lines: list[str] = [
            r"% DID byte-field diagrams — generated by udsxml2tex",
            r"% Requires the 'bytefield' LaTeX package.",
            r"",
        ]
        for did in sorted(spec.dids, key=lambda d: d.did_id):
            if not did.data_elements:
                continue
            lines.append(_render_bytefield_did(did))

        out_path = output_dir / "did_byte_fields.tex"
        out_path.write_text("\n".join(lines), encoding="utf-8")
        logger.info("Generated byte-field diagrams: %s", out_path)
        return out_path

    # ---- Unified generate_format() entry point --------------------------

    def generate_format(
        self,
        spec: UdsSpecification,
        fmt: str,
        output_path: str | Path,
        *,
        extra_vars: Optional[dict] = None,
    ) -> Path:
        """Generate output in the requested format.

        Args:
            fmt: One of "tex", "html", "md", "rst", "csv", "yaml", "json".
            extra_vars: Passed through to LaTeX / HTML generation.
        """
        fmt = fmt.lower()
        if fmt == "tex":
            return self.generate(spec, output_path, extra_vars=extra_vars)
        if fmt == "html":
            return self.generate_html(spec, output_path)
        if fmt == "md":
            return self.generate_markdown(spec, output_path)
        if fmt == "rst":
            return self.generate_rst(spec, output_path)
        if fmt == "yaml":
            return self.generate_yaml(spec, output_path)
        if fmt == "json":
            return self.generate_json(spec, output_path)
        if fmt == "csv":
            csv_dir = Path(output_path)
            self.generate_csv(spec, csv_dir)
            return csv_dir
        if fmt == "docx":
            return self.generate_docx(spec, Path(output_path).with_suffix(".docx"))
        raise ValueError(f"Unknown output format: {fmt!r}. "
                         "Choose from: tex, html, md, rst, csv, yaml, json, docx")


# ---------------------------------------------------------------------------
# Markdown renderer
# ---------------------------------------------------------------------------

def _md_escape(text: str) -> str:
    """Minimal Markdown escaping for pipe-table cells."""
    return str(text).replace("|", "\\|").replace("\n", " ")


def _render_markdown(spec: UdsSpecification) -> str:
    lines: list[str] = []
    w = lines.append

    w(f"# {spec.ecu_name} UDS Specification")
    w("")
    if spec.description:
        w(spec.description)
        w("")
    w(f"**Protocol:** {spec.protocol_name}")
    if spec.can_rx_id:
        w(f"**CAN RX ID:** `{spec.can_rx_id}`  **CAN TX ID:** `{spec.can_tx_id}`")
    w(f"**S3 Server Timeout:** {spec.s3_server} s")
    w("")

    # Sessions
    if spec.sessions:
        w("## Diagnostic Sessions")
        w("")
        w("| Session ID | Short Name | P2 (s) | P2* (s) |")
        w("|---|---|---|---|")
        for s in sorted(spec.sessions, key=lambda x: x.session_id):
            w(f"| `{s.session_id_hex}` | {_md_escape(s.short_name)} | {s.p2_server_max} | {s.p2_star_server_max} |")
        w("")

    # Security levels
    if spec.security_levels:
        w("## Security Levels")
        w("")
        w("| Level | Short Name | Seed (B) | Key (B) | Max Attempts |")
        w("|---|---|---|---|---|")
        for s in sorted(spec.security_levels, key=lambda x: x.security_level):
            w(f"| `{s.security_level_hex}` | {_md_escape(s.short_name)} | {s.seed_size} | {s.key_size} | {s.num_max_attempts} |")
        w("")

    # Services
    if spec.services:
        w("## Diagnostic Services")
        w("")
        for svc in sorted(spec.services, key=lambda x: x.service_id):
            w(f"### {svc.short_name} (`{svc.service_id_hex}`)")
            w("")
            if svc.description:
                w(svc.description)
                w("")
            if svc.supported_sessions:
                w(f"**Supported sessions:** {', '.join(svc.supported_sessions)}")
            if svc.required_security_levels:
                w(f"**Required security:** {', '.join(svc.required_security_levels)}")
            if svc.sub_functions:
                w("")
                w("| Sub-function ID | Name |")
                w("|---|---|")
                for sf in svc.sub_functions:
                    w(f"| `{sf.sub_function_id_hex}` | {_md_escape(sf.short_name)} |")
            if svc.nrc_list:
                w("")
                w("| NRC | Name |")
                w("|---|---|")
                for nrc in svc.nrc_list:
                    w(f"| `{nrc.nrc_code_hex}` | {_md_escape(nrc.nrc_name)} |")
            w("")

    # DIDs
    if spec.dids:
        w("## Data Identifiers (DIDs)")
        w("")
        w("| DID ID | Short Name | R | W | Length (B) |")
        w("|---|---|---|---|---|")
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            r = "✓" if d.read_access else ""
            wr = "✓" if d.write_access else ""
            w(f"| `{d.did_id_hex}` | {_md_escape(d.short_name)} | {r} | {wr} | {d.total_byte_length} |")
        w("")

    # Routines
    if spec.routines:
        w("## Routine Controls")
        w("")
        w("| Routine ID | Short Name |")
        w("|---|---|")
        for r in sorted(spec.routines, key=lambda x: x.routine_id):
            w(f"| `{r.routine_id_hex}` | {_md_escape(r.short_name)} |")
        w("")

    # DTCs
    if spec.dtcs:
        w("## Diagnostic Trouble Codes (DTCs)")
        w("")
        w("| DTC ID | Short Name | Severity |")
        w("|---|---|---|")
        for d in sorted(spec.dtcs, key=lambda x: x.dtc_id):
            w(f"| `{d.dtc_id_hex}` | {_md_escape(d.short_name)} | {_md_escape(d.severity)} |")
        w("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# RST renderer
# ---------------------------------------------------------------------------

def _rst_title(text: str, char: str = "=") -> str:
    return f"{text}\n{char * len(text)}\n"


def _rst_table(headers: list[str], rows: list[list[str]]) -> str:
    cols = len(headers)
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row[:cols]):
            widths[i] = max(widths[i], len(str(cell)))
    sep = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    fmt_row = lambda cells: "|" + "|".join(f" {str(c):<{w}} " for c, w in zip(cells, widths)) + "|"
    lines = [sep, fmt_row(headers), sep.replace("-", "=")]
    for row in rows:
        lines.append(fmt_row(row + [""] * (cols - len(row))))
        lines.append(sep)
    return "\n".join(lines) + "\n"


def _render_rst(spec: UdsSpecification) -> str:
    lines: list[str] = []
    w = lines.append

    w(_rst_title(f"{spec.ecu_name} UDS Specification", "="))
    if spec.description:
        w(spec.description)
        w("")
    w(f"**Protocol:** {spec.protocol_name}")
    w(f"**S3 Server Timeout:** {spec.s3_server} s")
    w("")

    if spec.sessions:
        w(_rst_title("Diagnostic Sessions", "-"))
        rows = [[s.session_id_hex, s.short_name, str(s.p2_server_max), str(s.p2_star_server_max)]
                for s in sorted(spec.sessions, key=lambda x: x.session_id)]
        w(_rst_table(["Session ID", "Short Name", "P2 (s)", "P2* (s)"], rows))

    if spec.dids:
        w(_rst_title("Data Identifiers (DIDs)", "-"))
        rows = [[d.did_id_hex, d.short_name, "Yes" if d.read_access else "No",
                 "Yes" if d.write_access else "No", str(d.total_byte_length)]
                for d in sorted(spec.dids, key=lambda x: x.did_id)]
        w(_rst_table(["DID ID", "Short Name", "Read", "Write", "Length (B)"], rows))

    if spec.dtcs:
        w(_rst_title("Diagnostic Trouble Codes (DTCs)", "-"))
        rows = [[d.dtc_id_hex, d.short_name, d.severity]
                for d in sorted(spec.dtcs, key=lambda x: x.dtc_id)]
        w(_rst_table(["DTC ID", "Short Name", "Severity"], rows))

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CSV renderer
# ---------------------------------------------------------------------------

def _render_csv(spec: UdsSpecification, out_dir: Path) -> list[Path]:
    import csv
    written: list[Path] = []

    def _write(name: str, headers: list[str], rows: list[list]) -> None:
        p = out_dir / name
        with open(p, "w", newline="", encoding="utf-8") as f:
            cw = csv.writer(f)
            cw.writerow(headers)
            cw.writerows(rows)
        written.append(p)

    if spec.sessions:
        _write("sessions.csv",
               ["session_id_hex", "short_name", "p2_server_max", "p2_star_server_max",
                "comm_ctrl_option_mask"],
               [[s.session_id_hex, s.short_name, s.p2_server_max, s.p2_star_server_max,
                 s.comm_ctrl_option_mask]
                for s in sorted(spec.sessions, key=lambda x: x.session_id)])

    if spec.security_levels:
        _write("security_levels.csv",
               ["security_level_hex", "short_name", "key_size", "seed_size",
                "num_max_attempts", "attempt_delay"],
               [[s.security_level_hex, s.short_name, s.key_size, s.seed_size,
                 s.num_max_attempts, s.attempt_delay]
                for s in sorted(spec.security_levels, key=lambda x: x.security_level)])

    if spec.services:
        _write("services.csv",
               ["service_id_hex", "short_name", "supported_sessions",
                "required_security_levels", "nrc_count", "sub_function_count"],
               [[s.service_id_hex, s.short_name,
                 ";".join(s.supported_sessions),
                 ";".join(s.required_security_levels),
                 len(s.nrc_list), len(s.sub_functions)]
                for s in sorted(spec.services, key=lambda x: x.service_id)])

    if spec.dids:
        _write("dids.csv",
               ["did_id_hex", "short_name", "read_access", "write_access",
                "total_byte_length", "supported_sessions", "required_security_levels",
                "data_element_count"],
               [[d.did_id_hex, d.short_name, d.read_access, d.write_access,
                 d.total_byte_length, ";".join(d.supported_sessions),
                 ";".join(d.required_security_levels), len(d.data_elements)]
                for d in sorted(spec.dids, key=lambda x: x.did_id)])
        # Data elements flattened
        de_rows = []
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            for de in d.data_elements:
                de_rows.append([d.did_id_hex, d.short_name, de.short_name,
                                 de.byte_position, de.bit_size, de.data_type,
                                 de.description, de.read_function, de.write_function,
                                 ";".join(de.global_variables)])
        if de_rows:
            _write("did_data_elements.csv",
                   ["did_id_hex", "did_short_name", "element_short_name",
                    "byte_position", "bit_size", "data_type", "description",
                    "read_function", "write_function", "global_variables"],
                   de_rows)

    if spec.routines:
        _write("routines.csv",
               ["routine_id_hex", "short_name", "start_supported", "stop_supported",
                "result_supported", "supported_sessions", "required_security_levels"],
               [[r.routine_id_hex, r.short_name, r.start_supported, r.stop_supported,
                 r.result_supported, ";".join(r.supported_sessions),
                 ";".join(r.required_security_levels)]
                for r in sorted(spec.routines, key=lambda x: x.routine_id)])

    if spec.dtcs:
        _write("dtcs.csv",
               ["dtc_id_hex", "short_name", "severity", "description",
                "functional_unit", "priority", "dtc_kind"],
               [[d.dtc_id_hex, d.short_name, d.severity, d.description,
                 d.functional_unit, d.priority, d.dtc_kind]
                for d in sorted(spec.dtcs, key=lambda x: x.dtc_id)])

    logger.info("Generated %d CSV file(s) in %s", len(written), out_dir)
    return written


# ---------------------------------------------------------------------------
# TikZ session state-machine diagram
# ---------------------------------------------------------------------------

def _render_session_tikz(spec: UdsSpecification) -> str:
    sessions = sorted(spec.sessions, key=lambda s: s.session_id)
    if not sessions:
        return "% No sessions defined.\n"

    lines: list[str] = [
        r"\documentclass[tikz,border=10pt]{standalone}",
        r"\usetikzlibrary{automata,arrows.meta,positioning}",
        r"\begin{document}",
        r"\begin{tikzpicture}[",
        r"  > = {Stealth[length=6pt]},",
        r"  node distance = 2.8cm,",
        r"  state/.style = {draw, rounded rectangle, minimum width=3cm, minimum height=1cm,",
        r"                   font=\small\ttfamily, align=center},",
        r"  every edge/.style = {draw, ->, bend left=20},",
        r"]",
    ]

    # Position nodes in a row
    prev = None
    for i, s in enumerate(sessions):
        sid = s.short_name.replace(" ", "_")
        if i == 0:
            lines.append(f"  \\node[state, initial] ({sid}) {{{s.short_name}\\\\{s.session_id_hex}}};")
        else:
            prev_id = sessions[i - 1].short_name.replace(" ", "_")
            lines.append(f"  \\node[state, right of={prev_id}] ({sid}) {{{s.short_name}\\\\{s.session_id_hex}}};")
        prev = sid

    lines.append("")
    # Draw bidirectional transitions between each consecutive pair
    for i in range(len(sessions) - 1):
        a = sessions[i].short_name.replace(" ", "_")
        b = sessions[i + 1].short_name.replace(" ", "_")
        lines.append(f"  \\path ({a}) edge[bend left] node[above]{{0x10}} ({b});")
        lines.append(f"  \\path ({b}) edge[bend left] node[below]{{0x10}} ({a});")
    # Self-loops for TesterPresent-kept sessions
    for s in sessions:
        sid = s.short_name.replace(" ", "_")
        lines.append(f"  \\path ({sid}) edge[loop above] node[above]{{0x3E}} ({sid});")

    lines += [
        r"\end{tikzpicture}",
        r"\end{document}",
    ]
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# TikZ session state-transition figure (non-standalone, for inclusion in ZIP)
# ---------------------------------------------------------------------------

def _build_session_state_tikz(sessions: list, s3_server: float = 5.0) -> str:
    """Return a TikZ figure (non-standalone) for the session state-transition diagram."""
    if not sessions:
        return ""

    def _sid(s) -> str:
        return "s" + re.sub(r"[^A-Za-z0-9]", "", s.short_name)

    default_session = sessions[0]
    non_default = sessions[1:]
    n_nondft = len(non_default)

    lines: list[str] = [
        r"\begin{figure}[H]",
        r"\centering",
        r"\begin{tikzpicture}",
        r"",
        r"% Initial pseudostate",
        r"\umlstateinitial[x=0, y=0, name=init]",
        r"",
        r"% Default session state",
    ]

    default_label = _latex_escape(default_session.short_name)
    lines.append(
        f"\\begin{{umlstate}}[x=0, y=-2, name={_sid(default_session)},"
        f" width=5cm, fill=gray!8]{{{default_label}}}"
    )
    lines.append(r"\end{umlstate}")
    lines.append(r"")
    lines.append(
        f"\\draw[->, >=triangle 45, thick] (init) -- ({_sid(default_session)})"
        r"  node[pos=0.15, right, font=\small, xshift=2pt]"
        r" {\guillemotleft Power On\guillemotright};"
    )

    if non_default:
        lines.append(r"")
        lines.append(r"% Non-default session states")
        for i, sf in enumerate(non_default):
            xoff = (i - (n_nondft - 1) / 2.0) * 8
            label = _latex_escape(sf.short_name)
            lines.append(
                f"\\begin{{umlstate}}[x={xoff:.1f}, y=-6, name={_sid(sf)},"
                f" width=5cm, fill=gray!8]{{{label}}}"
            )
            lines.append(r"\end{umlstate}")

        lines.append(r"")
        lines.append(r"% Transitions: Default <-> each non-default session")
        for sf in non_default:
            sf_hex = sf.session_id_hex.replace("0x", "").replace("0X", "")
            sid = _sid(sf)
            if sf.session_id != 2:
                lines.append(
                    f"\\draw[->, >=triangle 45, thick, bend left=10] ({_sid(default_session)}) to"
                    f" node[auto, font=\\small]"
                    f" {{\\guillemotleft SF = {sf_hex}\\guillemotright}} ({sid});"
                )
            lines.append(
                f"\\draw[->, >=triangle 45, thick, bend left=10] ({sid}) to"
                f" node[auto, font=\\small]"
                f" {{\\guillemotleft SF = 01 / S3 timeout ({s3_server}\\,s)\\guillemotright}}"
                f" ({_sid(default_session)});"
            )

        if n_nondft > 1:
            lines.append(r"")
            lines.append(r"% Transitions between non-default sessions")
            for i, sf_a in enumerate(non_default):
                for sf_b in non_default[i + 1:]:
                    id_a, id_b = _sid(sf_a), _sid(sf_b)
                    hex_a = sf_a.session_id_hex.replace("0x", "").replace("0X", "")
                    hex_b = sf_b.session_id_hex.replace("0x", "").replace("0X", "")
                    lines.append(
                        f"\\draw[->, >=triangle 45, thick, bend left=10] ({id_a}) to"
                        f" node[auto, font=\\small]"
                        f" {{\\guillemotleft SF = {hex_b}\\guillemotright}} ({id_b});"
                    )
                    lines.append(
                        f"\\draw[->, >=triangle 45, thick, bend left=10] ({id_b}) to"
                        f" node[auto, font=\\small]"
                        f" {{\\guillemotleft SF = {hex_a}\\guillemotright}} ({id_a});"
                    )

        lines.append(r"")
        lines.append(r"% Self-transitions for non-default sessions (TesterPresent)")
        for sf in non_default:
            sid = _sid(sf)
            lines.append(
                f"\\umltrans[recursive=210|330|3cm, recursive direction=bottom to bottom,"
                f" arg={{TesterPresent}}, pos stereo=1.5]{{{sid}}}{{{sid}}}"
            )

    lines.append(r"")
    lines.append(r"% Self-transition for default session (rectangular loop on right)")
    lines.append(
        r"\draw[->, >=triangle 45, thick, rounded corners=5pt]"
    )
    lines.append(
        f"  ([yshift=4mm]{_sid(default_session)}.east) -- ++(1.5, 0)"
    )
    lines.append(
        r"  -- ++(0, -0.8) node[midway, right, font=\small] {TesterPresent}"
    )
    lines.append(
        f"  -- ([yshift=-4mm]{_sid(default_session)}.east);"
    )

    lines.append(r"")
    lines.append(r"\end{tikzpicture}")
    lines.append(r"\caption{Session Transition Diagram}\label{fig:session-transition}")
    lines.append(r"\end{figure}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# TikZ NRC flowchart figure (non-standalone, for inclusion in ZIP)
# ---------------------------------------------------------------------------

def _build_nrc_flowchart_tikz(service) -> str:
    """Return a TikZ figure showing the NRC check flow for one UDS service."""
    if not service.nrc_list:
        return ""

    # Filter NRC_CHECK_ORDER to only codes present in this service (preserves priority order)
    nrc_codes_set = {nrc.nrc_code for nrc in service.nrc_list}
    checks = [(code, label) for code, label in NRC_CHECK_ORDER if code in nrc_codes_set]
    if not checks:
        return ""

    sid_hex = f"{service.service_id:02X}"
    name_esc = _latex_escape(service.short_name)

    lines: list[str] = [
        r"\begin{figure}[H]",
        r"\centering",
        r"\begin{tikzpicture}[",
        r"  node distance=0.5cm,",
        r"  startstop/.style={rectangle, rounded corners, minimum width=2.2cm,",
        r"                    minimum height=0.6cm, text centered,",
        r"                    draw=black, fill=gray!12, font=\small},",
        r"  decision/.style={diamond, aspect=1.5, minimum width=0.8cm,",
        r"                   minimum height=0.8cm, inner sep=0pt,",
        r"                   draw=black, fill=white},",
        r"  nrcbox/.style={rectangle, minimum width=1.8cm, minimum height=0.5cm,",
        r"                 text centered, draw=black, fill=gray!20, font=\scriptsize},",
        r"  arrow/.style={thick,->,>=stealth},",
        r"]",
        r"",
        r"\node (start) [startstop] {Request received};",
        r"",
    ]

    prev = "start"
    for idx, (code, label) in enumerate(checks):
        nid = f"chk{idx}"
        nrc_hex = f"{code:02X}"
        lines.append(f"\\node ({nid}) [decision, below=of {prev}] {{}};")
        lines.append(
            f"\\node[left=0.1cm of {nid}, font=\\scriptsize, anchor=east, align=right]"
            f" {{{label}}};"
        )
        lines.append(
            f"\\node (nrc{idx}) [nrcbox, right=1.8cm of {nid}]"
            f" {{NRC \\hex{{{nrc_hex}}}}};"
        )
        lines.append(f"\\draw [arrow] ({prev}) -- ({nid});")
        lines.append(
            f"\\draw [arrow] ({nid}) -- node[above, font=\\scriptsize] {{No}} (nrc{idx});"
        )
        lines.append("")
        prev = nid

    last = f"chk{len(checks) - 1}"
    lines.append(f"\\node (positive) [startstop, below=of {last}] {{Positive Response}};")
    lines.append(
        f"\\draw [arrow] ({last}) -- node[right, font=\\scriptsize] {{Yes}} (positive);"
    )
    lines.append("")

    # "Yes" labels on the main path between consecutive decision nodes
    for idx in range(len(checks) - 1):
        nid = f"chk{idx}"
        next_nid = f"chk{idx + 1}"
        lines.append(
            f"\\node[font=\\scriptsize, right=2pt]"
            f" at ($({nid}.south)!0.5!({next_nid}.north)$) {{Yes}};"
        )

    lines.append(r"\end{tikzpicture}")
    lines.append(
        f"\\caption{{{name_esc} --- NRC Decision Flow}}"
        f"\\label{{fig:nrc-flow-{sid_hex.lower()}}}"
    )
    lines.append(r"\end{figure}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# DOCX renderer
# ---------------------------------------------------------------------------

def _render_docx(spec: UdsSpecification, path: Path) -> None:
    """Create and save a DOCX document for *spec* at *path*.

    Requires python-docx (imported lazily so the rest of the module works
    without the optional dependency installed).
    """
    from docx import Document  # type: ignore[import]

    doc = Document()

    # Title
    doc.add_heading(f"{spec.ecu_name} UDS Specification", level=0)

    # Diagnostic Sessions
    if spec.sessions:
        doc.add_heading("Diagnostic Sessions", level=1)
        tbl = doc.add_table(rows=1, cols=4)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "Session ID"
        hdr[2].text = "P2max (s)"
        hdr[3].text = "P2*max (s)"
        for s in sorted(spec.sessions, key=lambda x: x.session_id):
            row = tbl.add_row().cells
            row[0].text = s.short_name
            row[1].text = s.session_id_hex
            row[2].text = str(s.p2_server_max)
            row[3].text = str(s.p2_star_server_max)

    # Security Access Levels
    if spec.security_levels:
        doc.add_heading("Security Access Levels", level=1)
        tbl = doc.add_table(rows=1, cols=3)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "Level"
        hdr[2].text = "Key Size"
        for s in sorted(spec.security_levels, key=lambda x: x.security_level):
            row = tbl.add_row().cells
            row[0].text = s.short_name
            row[1].text = s.security_level_hex
            row[2].text = str(s.key_size)

    # Services
    if spec.services:
        doc.add_heading("Services", level=1)
        tbl = doc.add_table(rows=1, cols=4)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "SID"
        hdr[2].text = "Supported Sessions"
        hdr[3].text = "Required Security"
        for svc in sorted(spec.services, key=lambda x: x.service_id):
            row = tbl.add_row().cells
            row[0].text = svc.short_name
            row[1].text = svc.service_id_hex
            row[2].text = ", ".join(svc.supported_sessions)
            row[3].text = ", ".join(svc.required_security_levels)

    # Data Identifiers (DIDs)
    if spec.dids:
        doc.add_heading("Data Identifiers (DIDs)", level=1)
        tbl = doc.add_table(rows=1, cols=5)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "DID"
        hdr[2].text = "Read"
        hdr[3].text = "Write"
        hdr[4].text = "Sessions"
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            row = tbl.add_row().cells
            row[0].text = d.short_name
            row[1].text = d.did_id_hex
            row[2].text = "Yes" if d.read_access else "No"
            row[3].text = "Yes" if d.write_access else "No"
            row[4].text = ", ".join(d.supported_sessions)

    # Routines
    if spec.routines:
        doc.add_heading("Routines", level=1)
        tbl = doc.add_table(rows=1, cols=3)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "ID"
        hdr[2].text = "Sessions"
        for r in sorted(spec.routines, key=lambda x: x.routine_id):
            row = tbl.add_row().cells
            row[0].text = r.short_name
            row[1].text = r.routine_id_hex
            row[2].text = ", ".join(r.supported_sessions)

    # DTCs
    if spec.dtcs:
        doc.add_heading("DTCs", level=1)
        tbl = doc.add_table(rows=1, cols=4)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "DTC ID"
        hdr[2].text = "Severity"
        hdr[3].text = "Description"
        for d in sorted(spec.dtcs, key=lambda x: x.dtc_id):
            row = tbl.add_row().cells
            row[0].text = d.short_name
            row[1].text = d.dtc_id_hex
            row[2].text = d.severity
            row[3].text = d.description or ""

    doc.save(str(path))


# ---------------------------------------------------------------------------
# TikZ sequence diagram renderer
# ---------------------------------------------------------------------------

def _render_sequence_tikz(
    title: str,
    participants: list,
    messages: list,
) -> str:
    """Render a simple TikZ sequence diagram.

    Args:
        title:        Diagram title (used as a comment and heading node).
        participants: List of participant name strings, e.g. ["Tester", "ECU"].
        messages:     List of (from, to, label, style) tuples.
                      *style* is "" for a solid arrow or "dashed" for a dashed arrow.

    Returns:
        A standalone LaTeX document string.
    """
    n = len(participants)
    # Horizontal spacing between participant columns (cm)
    col_sep = 6.0
    # Vertical spacing between messages (cm)
    row_sep = 1.2

    lines: list[str] = [
        r"\documentclass[tikz,border=10pt]{standalone}",
        r"\usetikzlibrary{arrows.meta}",
        r"\begin{document}",
        f"% Sequence diagram: {title}",
        r"\begin{tikzpicture}[",
        r"  >=Stealth,",
        r"  participant/.style={draw, rectangle, minimum width=2.8cm, minimum height=0.8cm,",
        r"                      align=center, font=\small\bfseries},",
        r"  msg/.style={draw, ->, font=\footnotesize},",
        r"  msgnrc/.style={draw, ->, dashed, font=\footnotesize},",
        r"]",
    ]

    # Participant header boxes
    for i, p in enumerate(participants):
        x = i * col_sep
        lines.append(
            f"  \\node[participant] (p{i}) at ({x:.1f},0) {{{_latex_escape(p)}}};"
        )

    # Lifelines (vertical dashed lines)
    total_height = (len(messages) + 1) * row_sep
    for i in range(n):
        x = i * col_sep
        lines.append(
            f"  \\draw[dashed, gray] ({x:.1f},-0.4) -- ({x:.1f},-{total_height:.1f});"
        )

    # Message arrows
    part_index = {p: i for i, p in enumerate(participants)}
    for j, msg in enumerate(messages):
        src, dst, label, style = msg
        y = -(j + 1) * row_sep
        src_idx = part_index.get(src, 0)
        dst_idx = part_index.get(dst, 0)
        x1 = src_idx * col_sep
        x2 = dst_idx * col_sep
        tikz_style = "msgnrc" if style == "dashed" else "msg"
        # label above midpoint
        mid_x = (x1 + x2) / 2.0
        label_escaped = _latex_escape(label)
        lines.append(
            f"  \\draw[{tikz_style}] ({x1:.1f},{y:.2f}) -- ({x2:.1f},{y:.2f})"
            f" node[midway, above, align=center, font=\\scriptsize]{{{label_escaped}}};"
        )

    lines += [
        r"\end{tikzpicture}",
        r"\end{document}",
        "",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Bytefield DID renderer
# ---------------------------------------------------------------------------

def _render_bytefield_did(did: object) -> str:
    """Return a LaTeX bytefield snippet for a single DID.

    Args:
        did: A DID model object with attributes ``did_id_hex``, ``short_name``,
             and ``data_elements`` (list of objects with ``short_name``,
             ``byte_position``, and ``bit_size``).

    Returns:
        LaTeX string containing \\subsection* and bytefield environment.
    """
    # Determine total bit width — round up to nearest multiple of 8
    total_bits = 0
    for de in did.data_elements:
        bits = getattr(de, "bit_size", 0) or 0
        bpos = getattr(de, "byte_position", 0) or 0
        end_bit = bpos * 8 + bits
        if end_bit > total_bits:
            total_bits = end_bit
    if total_bits == 0:
        total_bits = 8
    # Round up to multiple of 8
    if total_bits % 8:
        total_bits = ((total_bits // 8) + 1) * 8

    did_name_esc = _latex_escape(str(getattr(did, "short_name", "")))
    did_hex = getattr(did, "did_id_hex", "????")

    lines: list[str] = [
        f"\\subsection*{{DID {did_hex} --- {did_name_esc}}}",
        f"\\begin{{bytefield}}[bitwidth=0.5em]{{{total_bits}}}",
        f"  \\bitheader{{0-{total_bits - 1}}} \\\\",
    ]

    # Sort data elements by byte position
    elements = sorted(
        did.data_elements,
        key=lambda de: (getattr(de, "byte_position", 0) or 0),
    )
    for de in elements:
        bits = getattr(de, "bit_size", 8) or 8
        n_words = max(1, bits // 8)
        name_esc = _latex_escape(str(getattr(de, "short_name", "")))
        bpos = getattr(de, "byte_position", 0) or 0
        lines.append(
            f"  \\wordbox{{{n_words}}}{{{name_esc} ({n_words} byte(s), offset {bpos})}} \\\\"
        )

    lines.append("\\end{bytefield}")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Multi-page HTML helpers for generate_html_zip()
# ---------------------------------------------------------------------------

_HTML_CSS = """
* { box-sizing: border-box; }
body { font-family: Georgia, "Times New Roman", serif; font-size: 14px; line-height: 1.7; color: #111;
       margin: 0; display: flex; min-height: 100vh; background: #fff; }
nav { width: 210px; min-width: 160px; background: #3a3a3a; color: #ddd; padding: 1.5em 1em;
      flex-shrink: 0; border-right: 1px solid #222; }
nav h2 { color: #fff; font-size: 0.95em; font-family: Georgia, serif; margin-bottom: 1em;
          border-bottom: 1px solid #555; padding-bottom: 0.4em; letter-spacing: 0.03em; }
nav ul { list-style: none; padding: 0; margin: 0; }
nav ul li { margin: 0.5em 0; }
nav ul li a { color: #ccc; text-decoration: none; font-size: 0.9em; font-family: Arial, sans-serif; }
nav ul li a:hover { color: #fff; text-decoration: underline; }
main { flex: 1; padding: 2.5em 3em; overflow-x: auto; max-width: 960px; }
h1 { font-size: 1.8em; border-bottom: 2px solid #111; padding-bottom: 0.25em; margin-bottom: 0.6em; }
h2 { font-size: 1.3em; border-bottom: 1px solid #999; padding-bottom: 0.15em; margin-top: 2em; margin-bottom: 0.6em; }
h3 { font-size: 1.05em; margin-top: 1.5em; margin-bottom: 0.3em; }
h4 { font-size: 1em; font-style: italic; margin-top: 1em; margin-bottom: 0.2em; }
table { border-collapse: collapse; margin: 0.8em 0 1.4em; font-size: 0.88em;
        font-family: Arial, Helvetica, sans-serif; width: auto; }
th { background: #e0e0e0; color: #111; font-weight: bold; padding: 6px 10px;
     border: 1px solid #999; text-align: left; }
td { padding: 5px 10px; border: 1px solid #bbb; vertical-align: top; }
tr:nth-child(even) td { background: #f5f5f5; }
caption { font-style: italic; font-size: 0.9em; margin-bottom: 0.3em; text-align: left; color: #444; }
code, .hexval { font-family: "Courier New", Courier, monospace; font-size: 0.92em; }
.badge-yes { font-weight: bold; }
.badge-no { color: #999; }
.meta { color: #555; font-size: 0.88em; margin-bottom: 1.5em; font-family: Arial, sans-serif;
        border-left: 3px solid #ccc; padding-left: 0.8em; }
nav ul.nav-sub { padding-left: 1em; margin: 0.1em 0; }
nav ul.nav-sub li { margin: 0.1em 0; }
nav ul li a.nav-current { color: #fff; font-weight: bold; }
"""


def _html_escape(text: str) -> str:
    """Escape HTML special characters."""
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _html_hex(value: str) -> str:
    """Render hex value as inline code."""
    v = _strip_0x(str(value))
    return f'<code class="hexval">{v}<sub>16</sub></code>'


def _relpath(from_path: str, to_path: str) -> str:
    """Compute relative URL from one HTML file path to another (POSIX slashes)."""
    from_dir = os.path.dirname(from_path) or "."
    rel = os.path.relpath(to_path.replace("/", os.sep), from_dir)
    return rel.replace(os.sep, "/")


def _build_nav_html(nav_tree: list, current_path: str) -> str:
    """Build hierarchical navigation sidebar HTML with relative links."""
    def _item(node: dict) -> str:
        path = node["path"]
        title = node["title"]
        href = _relpath(current_path, path)
        active = ' class="nav-current"' if path == current_path else ""
        link = f'<a href="{href}"{active}>{title}</a>'
        children = node.get("children", [])
        sub = (f'<ul class="nav-sub">{"".join(_item(c) for c in children)}</ul>'
               if children else "")
        return f"<li>{link}{sub}</li>"

    return "<ul>" + "".join(_item(n) for n in nav_tree) + "</ul>"


def _html_page(title: str, nav: str, body: str, css: str) -> str:
    """Wrap body in a full HTML page with nav sidebar."""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{_html_escape(title)}</title>
<style>{css}</style>
</head>
<body>
<nav>
<h2>UDS Specification</h2>
{nav}
</nav>
<main>
{body}
</main>
</body>
</html>
"""


def _html_table(headers: list, rows: list, *, caption: str = "") -> str:
    """Render a simple HTML table."""
    lines = ["<table>"]
    if caption:
        lines.append(f"<caption>{_html_escape(caption)}</caption>")
    lines.append("<thead><tr>" + "".join(f"<th>{_html_escape(str(h))}</th>" for h in headers) + "</tr></thead>")
    lines.append("<tbody>")
    for row in rows:
        lines.append("<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>")
    lines.append("</tbody></table>")
    return "\n".join(lines)


def _render_html_index(ctx: dict) -> str:
    lines: list[str] = []
    ecu = _html_escape(ctx.get("ecu_name", ""))
    proto = _html_escape(ctx.get("protocol_name", ""))
    lines.append(f"<h1>UDS Specification &mdash; {ecu}</h1>")
    lines.append(f'<p class="meta">ECU: <strong>{ecu}</strong> | Protocol: <strong>{proto}</strong></p>')
    lines.append("<p>This document is an automatically generated UDS specification "
                 "extracted from AUTOSAR ARXML configuration.</p>")
    current = ctx.get("_current_path", "index.html")
    lines.append("<h2>Document Sections</h2><ul>")
    for path, title, desc in [
        ("sections/0_intro/index.html",      "Introduction",
         "Scope, abbreviations, reference documents"),
        ("sections/1_low_layer/index.html",  "&sect;4 Network Protocol Layers",
         "CanTp, CAN IDs, timing, sessions"),
        ("sections/2_high_layer/index.html", "&sect;5 Application Layers",
         "All UDS services, DIDs, Routines, SecurityAccess"),
        ("sections/A_annex/index.html",      "Annex",
         "Cross-reference tables (SID/DID/RID/NRC &times; sessions)"),
    ]:
        href = _relpath(current, path)
        lines.append(f'<li><a href="{href}">{title}</a> &mdash; {desc}</li>')
    lines.append("</ul>")

    # Summary stats
    services = ctx.get("services", [])
    dids = ctx.get("dids", [])
    routines = ctx.get("routines", [])
    security_levels = ctx.get("security_levels", [])
    sessions = ctx.get("sessions", [])
    stats = [
        ["Diagnostic Sessions", str(len(sessions))],
        ["Security Levels", str(len(security_levels))],
        ["UDS Services", str(len(services))],
        ["Data Identifiers (DIDs)", str(len(dids))],
        ["Routines (RIDs)", str(len(routines))],
    ]
    lines.append("<h2>Document Statistics</h2>")
    lines.append(_html_table(["Item", "Count"], stats))

    if sessions:
        rows = [
            [_html_hex(s.session_id_hex), _html_escape(s.short_name),
             _html_escape(str(s.p2_server_max) if s.p2_server_max is not None else ""),
             _html_escape(str(s.p2_star_server_max) if s.p2_star_server_max is not None else "")]
            for s in sessions
        ]
        lines.append("<h2>Diagnostic Sessions</h2>")
        lines.append(_html_table(["Session ID", "Name", "P2 max (ms)", "P2* max (ms)"], rows))

    return "\n".join(lines)


def _render_html_intro(ctx: dict) -> str:
    lines: list[str] = []
    ecu  = _html_escape(ctx.get("ecu_name", ""))
    proto = _html_escape(ctx.get("protocol_name", ""))

    # §1 Short Description
    lines.append("<h1>Introduction</h1>")
    lines.append("<h2>Short Description</h2>")
    lines.append(
        f"<p>This document specifies the UDS (Unified Diagnostic Services) "
        f"implementation requirements for the <strong>{ecu}</strong> ECU "
        f"(protocol: <strong>{proto}</strong>). "
        f"It covers all diagnostic services, data identifiers, routines, and "
        f"security mechanisms implemented in the AUTOSAR DCM.</p>"
    )
    lines.append("<h3>Definition of this specification</h3>")
    lines.append(
        "<p>This specification is generated automatically from the AUTOSAR ARXML "
        "configuration using <strong>udsxml2tex</strong>. It defines the diagnostic "
        "communication behaviour of the ECU according to ISO&nbsp;14229 (UDS) and "
        "ISO&nbsp;15765 (UDS on CAN).</p>"
    )
    lines.append("<h3>Clarification of specification</h3>")
    lines.append(
        "<p>All hexadecimal values are prefixed with <code>0x</code>. "
        "Byte fields marked <em>variable</em> depend on runtime parameters. "
        "Session names and security level names are derived from the ARXML short names.</p>"
    )

    # §2 About this document
    lines.append("<h2>About this Document</h2>")
    lines.append("<h3>Term Definitions and Abbreviations</h3>")
    abbrevs = [
        ("ADR",  "Attempt Delay Record"),
        ("CAN",  "Controller Area Network"),
        ("CanTp","CAN Transport Protocol (ISO 15765-2)"),
        ("DCM",  "Diagnostic Communication Manager (AUTOSAR)"),
        ("DEM",  "Diagnostic Event Manager (AUTOSAR)"),
        ("DID",  "Data Identifier"),
        ("DTC",  "Diagnostic Trouble Code"),
        ("ECU",  "Electronic Control Unit"),
        ("FSM",  "Finite State Machine"),
        ("NRC",  "Negative Response Code"),
        ("OSI",  "Open Systems Interconnection"),
        ("PCI",  "Protocol Control Information"),
        ("RID",  "Routine Identifier"),
        ("SID",  "Service Identifier"),
        ("UDS",  "Unified Diagnostic Services (ISO 14229)"),
    ]
    lines.append(_html_table(["Abbreviation", "Definition"], [[a, d] for a, d in abbrevs]))
    lines.append("<h3>Document Generation</h3>")
    lines.append(
        "<p>This document is generated by <strong>udsxml2tex</strong> from AUTOSAR DCM, "
        "CanTp, and DEM ARXML files. All tables and diagrams are derived automatically "
        "from the configuration data; no manual editing is required.</p>"
    )

    # §3 Context Information
    lines.append("<h2>Context Information</h2>")
    lines.append("<h3>Operational Environment</h3>")
    lines.append(
        "<p>The ECU communicates with diagnostic tools (testers) over a CAN bus using "
        "ISO&nbsp;15765-2 (CanTp) as the transport layer and ISO&nbsp;14229 (UDS) as the "
        "application layer. Physical and functional CAN addressing modes are supported.</p>"
    )
    lines.append("<h3>Use Cases</h3>")
    use_cases = [
        ("End-of-line programming",  "Flash reprogramming of ECU software and calibration data."),
        ("Field diagnostics",         "Fault code reading, clearing, and live data access by service tools."),
        ("Software download",         "In-vehicle firmware update via diagnostic tester."),
        ("Security access",           "Restricted diagnostic functions protected by seed/key authentication."),
    ]
    lines.append(_html_table(["Use Case", "Description"], [[u, d] for u, d in use_cases]))
    lines.append("<h3>Reference Documents</h3>")
    lines.append("<h4>International Standards</h4>")
    refs = [
        ("ISO 14229-1:2020", "UDS — Application layer"),
        ("ISO 14229-2:2013", "UDS — Session layer"),
        ("ISO 15765-2:2016", "UDS on CAN — Transport layer"),
        ("ISO 15765-3:2004", "UDS on CAN — Implementation"),
    ]
    lines.append(_html_table(["Document", "Title"], [[r, t] for r, t in refs]))
    lines.append("<h4>Supported Services Summary</h4>")
    lines.append("<ul>")
    for svc in ctx.get("services", []):
        lines.append(
            f"<li>{_html_hex(svc.service_id_hex)} &mdash; "
            f"{_html_escape(svc.short_name)}</li>"
        )
    lines.append("</ul>")

    return "\n".join(lines)


def _render_html_low_layer_index(ctx: dict) -> str:
    """§4 Network Protocol Layers — section overview with links to sub-pages."""
    current = ctx.get("_current_path", "sections/1_low_layer/index.html")
    lines: list[str] = []
    lines.append("<h1>&sect;4 Network Protocol Layers</h1>")
    lines.append(
        "<p>This section describes the communication stack layers for UDS diagnostic "
        "communication over CAN (DoCAN), following the OSI model from the data link "
        "layer through the session layer.</p>"
    )
    sub_pages = [
        ("sections/1_low_layer/2_datalink/index.html",
         "&sect;4.1 Data Link Layer",
         "CAN frame padding and addressing modes"),
        ("sections/1_low_layer/3_network/index.html",
         "&sect;4.2 Network Layer",
         "Physical and functional CAN identifiers"),
        ("sections/1_low_layer/4_transport/index.html",
         "&sect;4.3 Transport Layer",
         "ISO&nbsp;15765-2 CanTp PCI frame types and timing"),
        ("sections/1_low_layer/5_session/index.html",
         "&sect;4.4 Session Layer",
         "Diagnostic sessions, S3 timeout, and timing parameters"),
    ]
    lines.append("<ul>")
    for path, title, desc in sub_pages:
        href = _relpath(current, path)
        lines.append(f'<li><a href="{href}">{title}</a> &mdash; {desc}</li>')
    lines.append("</ul>")
    return "\n".join(lines)


def _render_html_low_datalink(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>&sect;4.1 Data Link Layer</h1>")
    lines.append(
        "<p>In diagnostic communication over CAN (DoCAN), the data link layer is "
        "responsible for physical transmission of CAN frames. Unused bytes in a frame "
        "are filled with a padding byte. The default padding value is <code>0x00</code> "
        "as per ISO&nbsp;15765-2.</p>"
    )
    lines.append("<h2>CAN Frame Padding</h2>")
    pad_rows = [
        ["Standard (11-bit ID)", "0x00", "ISO 15765-2 default"],
        ["Extended (29-bit ID)", "0x00", "ISO 15765-2 default"],
    ]
    lines.append(_html_table(["Address Type", "Padding Byte", "Note"], pad_rows,
                              caption="CAN frame padding configuration"))
    lines.append("<h2>Addressing Modes</h2>")
    lines.append(
        "<p>Two CAN addressing modes are supported:</p>"
        "<ul>"
        "<li><strong>Physical addressing</strong> — unicast request from tester to a single ECU.</li>"
        "<li><strong>Functional addressing</strong> — broadcast request to all ECUs in a function group.</li>"
        "</ul>"
    )
    return "\n".join(lines)


def _render_html_low_network(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>&sect;4.2 Network Layer</h1>")
    lines.append(
        "<p>The network layer handles CAN message routing via assigned CAN identifiers. "
        "Physical and functional CAN IDs are configured in the AUTOSAR CanTp / DCM "
        "configuration.</p>"
    )
    can_rx = ctx.get("can_rx_id")
    can_tx = ctx.get("can_tx_id")
    can_func = ctx.get("can_functional_id")
    if can_rx or can_tx or can_func:
        rows = []
        if can_rx:
            rows.append(["Physical Rx", "Physical request (tester to ECU)", _html_escape(str(can_rx))])
        if can_tx:
            rows.append(["Physical Tx", "Physical response (ECU to tester)", _html_escape(str(can_tx))])
        if can_func:
            rows.append(["Functional", "Functional request (broadcast)", _html_escape(str(can_func))])
        lines.append(_html_table(["Type", "Description", "CAN ID"], rows,
                                  caption="Configured CAN identifiers"))
    else:
        lines.append("<p>CAN IDs are OEM-specific. Refer to the vehicle communication matrix.</p>")
    return "\n".join(lines)


def _render_html_low_transport(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>&sect;4.3 Transport Layer</h1>")
    lines.append(
        "<p>ISO&nbsp;15765-2 (CanTp) defines the transport layer for UDS on CAN. "
        "It provides segmentation and reassembly of multi-frame messages using four "
        "Protocol Control Information (PCI) frame types.</p>"
    )
    lines.append("<h2>PCI Frame Types</h2>")
    pci_rows = [
        ["SF (Single Frame)",      "A single CAN frame containing the entire message.",
         "1st byte: 0xL (L = data length)"],
        ["FF (First Frame)",       "Initial frame of a segmented message.",
         "1st byte: 0x1L, 2nd byte: lower 8 bits of length"],
        ["CF (Consecutive Frame)", "Subsequent frames of a segmented message.",
         "1st byte: 0x2S (S = sequence number 1&ndash;15)"],
        ["FC (Flow Control)",      "Receiver instructs sender to continue, wait, or stop.",
         "1st byte: 0x3F, 2nd: BS, 3rd: STmin"],
    ]
    lines.append(_html_table(["Type", "Description", "PCI Structure"], pci_rows,
                              caption="PCI byte layout in ISO 15765-2"))
    lines.append("<h2>Timing Parameters</h2>")
    timing_rows = [
        ["N_As", "Time for the sender to transmit a PDU."],
        ["N_Bs", "Time to wait for a Flow Control after sending a FF or CF block."],
        ["N_Cs", "Time to wait before sending the next CF."],
        ["N_Ar", "Time for the receiver to transmit an FC frame."],
        ["N_Br", "Time before the receiver sends an FC after receiving an FF."],
        ["N_Cr", "Time to wait for the next CF after receiving an FC."],
    ]
    lines.append(_html_table(["Parameter", "Description"], timing_rows,
                              caption="ISO 15765-2 network-layer timing parameters"))
    return "\n".join(lines)


def _render_html_low_session(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>&sect;4.4 Session Layer</h1>")
    s3 = ctx.get("s3_server")
    lines.append(
        "<p>The session layer manages the lifecycle of diagnostic sessions. "
        "S3 server timeout (session keep-alive): <strong>"
        + _html_escape(str(s3) if s3 else "OEM defined")
        + "</strong>. TesterPresent (SID&nbsp;0x3E) must be sent within S3 to keep "
        "non-default sessions active.</p>"
    )
    sessions = ctx.get("sessions", [])
    if sessions:
        rows = [
            [_html_hex(s.session_id_hex), _html_escape(s.short_name),
             _html_escape(str(s.p2_server_max) if s.p2_server_max is not None else "&mdash;"),
             _html_escape(str(s.p2_star_server_max) if s.p2_star_server_max is not None else "&mdash;")]
            for s in sessions
        ]
        lines.append("<h2>Configured Sessions</h2>")
        lines.append(_html_table(
            ["Session ID", "Name", "P2 max (ms)", "P2* max (ms)"], rows,
            caption="Session timing parameters"))
    lines.append("<h2>Session Transitions</h2>")
    lines.append(
        "<p>Session transitions are triggered by DiagnosticSessionControl (SID&nbsp;0x10). "
        "After a session change or ECU reset, all SecurityAccess levels are locked "
        "(FSM returns to state&nbsp;A per ISO&nbsp;14229-1 Annex&nbsp;I).</p>"
    )
    return "\n".join(lines)


# Keep the old monolithic function as a fallback alias (unused in generate_html_zip)
def _render_html_low_layer(ctx: dict) -> str:
    return _render_html_low_layer_index(ctx)


def _html_req_resp_tables(svc, dids: list, routines: list, security_levels: list) -> list[str]:
    """Return list of HTML strings for Request + Positive Response byte tables."""
    lines = []
    sid = svc.service_id_hex
    sid_val = int(sid, 16)
    prs_val = sid_val + 0x40
    sid_hex = _html_hex(sid)
    prs_hex = _html_hex(f"0x{prs_val:02X}")

    # Build request rows
    req_rows = [[f"1", sid_hex, f"Service Identifier (SID)"]]
    rsp_rows = [[f"1", prs_hex, f"Positive Response SID (SID+0x40)"]]

    if sid == "0x10":  # DiagnosticSessionControl
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x01..0x7F"
        req_rows.append(["2", sf_vals, "Sub-function (sessionType)"])
        rsp_rows += [
            ["2", sf_vals, "Sub-function (sessionType)"],
            ["3&ndash;4", "&mdash;", "P2Server_max (ms, big-endian)"],
            ["5&ndash;6", "&mdash;", "P2*Server_max / 25 ms (big-endian)"],
        ]
    elif sid == "0x11":  # ECUReset
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x01/0x02/0x03"
        req_rows.append(["2", sf_vals, "Sub-function (resetType)"])
        rsp_rows.append(["2", sf_vals, "Sub-function (resetType)"])
    elif sid == "0x14":  # ClearDiagnosticInformation
        req_rows += [
            ["2", "&mdash;", "groupOfDTC[2] (high byte)"],
            ["3", "&mdash;", "groupOfDTC[1] (mid byte)"],
            ["4", "&mdash;", "groupOfDTC[0] (low byte)"],
        ]
    elif sid == "0x19":  # ReadDTCInformation
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x01..0x19"
        req_rows.append(["2", sf_vals, "Sub-function (reportType)"])
        req_rows.append(["3+", "&mdash;", "Parameters (depends on sub-function)"])
        rsp_rows.append(["2", sf_vals, "Sub-function (reportType)"])
        rsp_rows.append(["3+", "&mdash;", "DTC records (depends on sub-function)"])
    elif sid == "0x22":  # ReadDataByIdentifier
        req_rows += [
            ["2", "&mdash;", "dataIdentifier[1] (high byte)"],
            ["3", "&mdash;", "dataIdentifier[0] (low byte)"],
        ]
        rsp_rows += [
            ["2", "&mdash;", "dataIdentifier[1] (high byte)"],
            ["3", "&mdash;", "dataIdentifier[0] (low byte)"],
            ["4+", "&mdash;", "dataRecord (variable length)"],
        ]
    elif sid == "0x27":  # SecurityAccess
        req_rows += [
            ["2", "0x01/0x03/...", "Sub-function (requestSeed, odd value)"],
            ["3+", "&mdash;", "SecurityAccessDataRecord (optional)"],
        ]
        rsp_rows += [
            ["2", "0x01/0x03/...", "Sub-function (requestSeed)"],
            ["3+", "&mdash;", "securitySeed (N bytes)"],
        ]
    elif sid == "0x28":  # CommunicationControl
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x00..0x03"
        req_rows += [
            ["2", sf_vals, "Sub-function (controlType)"],
            ["3", "&mdash;", "communicationType"],
        ]
        rsp_rows.append(["2", sf_vals, "Sub-function (controlType)"])
    elif sid == "0x29":  # Authentication
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x01..0x0A"
        req_rows.append(["2", sf_vals, "Sub-function (authenticationTask)"])
        req_rows.append(["3+", "&mdash;", "authenticationData (depends on sub-function)"])
        rsp_rows.append(["2", sf_vals, "Sub-function (authenticationTask)"])
        rsp_rows.append(["3+", "&mdash;", "authenticationData (depends on sub-function)"])
    elif sid == "0x2E":  # WriteDataByIdentifier
        req_rows += [
            ["2", "&mdash;", "dataIdentifier[1] (high byte)"],
            ["3", "&mdash;", "dataIdentifier[0] (low byte)"],
            ["4+", "&mdash;", "dataRecord (variable length)"],
        ]
        rsp_rows += [
            ["2", "&mdash;", "dataIdentifier[1] (high byte)"],
            ["3", "&mdash;", "dataIdentifier[0] (low byte)"],
        ]
    elif sid == "0x31":  # RoutineControl
        sf_vals = "0x01 / 0x02 / 0x03"
        req_rows += [
            ["2", sf_vals, "Sub-function (routineControlType)"],
            ["3", "&mdash;", "routineIdentifier[1] (high byte)"],
            ["4", "&mdash;", "routineIdentifier[0] (low byte)"],
            ["5+", "&mdash;", "routineOptionRecord (optional)"],
        ]
        rsp_rows += [
            ["2", sf_vals, "Sub-function (routineControlType)"],
            ["3", "&mdash;", "routineIdentifier[1] (high byte)"],
            ["4", "&mdash;", "routineIdentifier[0] (low byte)"],
            ["5+", "&mdash;", "routineStatusRecord (optional)"],
        ]
    elif sid == "0x34":  # RequestDownload
        req_rows += [
            ["2", "&mdash;", "dataFormatIdentifier"],
            ["3", "&mdash;", "addressAndLengthFormatIdentifier"],
            ["4+", "&mdash;", "memoryAddress + memorySize"],
        ]
        rsp_rows += [
            ["2", "&mdash;", "lengthFormatIdentifier"],
            ["3+", "&mdash;", "maxNumberOfBlockLength"],
        ]
    elif sid == "0x36":  # TransferData
        req_rows += [
            ["2", "&mdash;", "blockSequenceCounter"],
            ["3+", "&mdash;", "transferRequestParameterRecord"],
        ]
        rsp_rows += [
            ["2", "&mdash;", "blockSequenceCounter"],
            ["3+", "&mdash;", "transferResponseParameterRecord (optional)"],
        ]
    elif sid == "0x37":  # RequestTransferExit
        req_rows.append(["2+", "&mdash;", "transferRequestParameterRecord (optional)"])
        rsp_rows.append(["2+", "&mdash;", "transferResponseParameterRecord (optional)"])
    elif sid == "0x3E":  # TesterPresent
        req_rows.append(["2", "0x00", "Sub-function (zeroSubFunction)"])
        rsp_rows.append(["2", "0x00", "Sub-function (zeroSubFunction)"])
    elif sid == "0x85":  # ControlDTCSetting
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x01 / 0x02"
        req_rows += [
            ["2", sf_vals, "Sub-function (DTCSettingType)"],
            ["3+", "&mdash;", "DTCSettingControlOptionRecord (optional)"],
        ]
        rsp_rows.append(["2", sf_vals, "Sub-function (DTCSettingType)"])
    elif svc.sub_functions:
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions)
        req_rows.append(["2", sf_vals, "Sub-function"])
        req_rows.append(["3+", "&mdash;", "Parameters (service-specific)"])
        rsp_rows.append(["2", sf_vals, "Sub-function"])
        rsp_rows.append(["3+", "&mdash;", "Response data"])
    else:
        req_rows.append(["2+", "&mdash;", "Service-specific parameters"])
        rsp_rows.append(["2+", "&mdash;", "Service-specific response data"])

    lines.append("<h3>Request Message</h3>")
    lines.append(_html_table(["Byte", "Value", "Description"], req_rows))
    lines.append("<h3>Positive Response Message</h3>")
    lines.append(_html_table(["Byte", "Value", "Description"], rsp_rows))
    return lines


def _render_html_services(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Application Layers</h1>")

    services       = ctx.get("services", [])
    sessions       = ctx.get("sessions", [])
    dids           = ctx.get("dids", [])
    routines       = ctx.get("routines", [])
    security_levels = ctx.get("security_levels", [])
    sess_names     = [s.short_name for s in sessions]

    # ---- §5.1 Overview -------------------------------------------------------
    lines.append('<h2 id="sec-overview">&sect;5.1 Overview</h2>')
    lines.append(
        "<p>This section provides cross-reference matrices for all UDS services, "
        "negative response codes, data identifiers, and routines configured for this ECU.</p>"
    )

    # SID × session matrix
    if services:
        headers = ["SID", "Service", "Sub-functions"] + sess_names
        rows = []
        for svc in services:
            sf_count = str(len(svc.sub_functions)) if svc.sub_functions else "&mdash;"
            cells = [
                '<span class="badge-yes">o</span>' if s.short_name in svc.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(svc.service_id_hex), _html_escape(svc.short_name), sf_count] + cells)
        lines.append("<h3>Supported SID and Sub-function List</h3>")
        lines.append(_html_table(headers, rows, caption="SID support per diagnostic session"))

    # NRC × SID matrix
    if services:
        all_nrcs: dict[int, str] = {}
        for svc in services:
            for nrc in svc.nrc_list:
                if nrc.nrc_code not in all_nrcs:
                    all_nrcs[nrc.nrc_code] = nrc.nrc_name
        if all_nrcs:
            headers = ["NRC", "Description"] + [_html_hex(s.service_id_hex) for s in services]
            rows = []
            for code in sorted(all_nrcs):
                code_hex = f"0x{code:02X}"
                row = [_html_hex(code_hex), _html_escape(all_nrcs[code])]
                for svc in services:
                    found = any(n.nrc_code == code for n in svc.nrc_list)
                    row.append('<span class="badge-yes">o</span>' if found else '<span class="badge-no">x</span>')
                rows.append(row)
            lines.append("<h3>Supported NRC List</h3>")
            lines.append(_html_table(headers, rows, caption="NRC support per SID"))

    # DID × session matrix
    if dids:
        headers = ["DID", "Description", "Read (0x22)", "Write (0x2E)"] + sess_names
        rows = []
        for did in dids:
            r = '<span class="badge-yes">o</span>' if did.read_access else '<span class="badge-no">x</span>'
            w = '<span class="badge-yes">o</span>' if did.write_access else '<span class="badge-no">x</span>'
            cells = [
                '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(did.did_id_hex), _html_escape(did.short_name), r, w] + cells)
        lines.append("<h3>Supported DID List</h3>")
        lines.append(_html_table(headers, rows, caption="DID support per diagnostic session"))

    # RID × session matrix
    if routines:
        headers = ["RID", "Description", "Start", "Stop", "Result"] + sess_names
        rows = []
        for rt in routines:
            start  = '<span class="badge-yes">o</span>' if rt.start_supported  else '<span class="badge-no">x</span>'
            stop   = '<span class="badge-yes">o</span>' if rt.stop_supported   else '<span class="badge-no">x</span>'
            result = '<span class="badge-yes">o</span>' if rt.result_supported else '<span class="badge-no">x</span>'
            cells  = [
                '<span class="badge-yes">o</span>' if s.short_name in rt.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(rt.routine_id_hex), _html_escape(rt.short_name),
                         start, stop, result] + cells)
        lines.append("<h3>Supported RID List</h3>")
        lines.append(_html_table(headers, rows, caption="RID support per diagnostic session"))

    # ---- Intra-page TOC for services ----------------------------------------
    if services:
        lines.append("<h2>Service Sections</h2>")
        lines.append("<ul>")
        for i, svc in enumerate(services, start=2):
            sid_clean = svc.service_id_hex.replace("0x", "").upper()
            lines.append(
                f'<li><a href="#sid-{sid_clean}">'
                f'&sect;5.{i}&nbsp; {_html_escape(svc.short_name)} '
                f'({_html_hex(svc.service_id_hex)})</a></li>'
            )
        lines.append("</ul>")

    # ---- §5.x Per-service sections -------------------------------------------
    for i, svc in enumerate(services, start=2):
        sid       = _html_hex(svc.service_id_hex)
        sid_clean = svc.service_id_hex.replace("0x", "").upper()
        lines.append(
            f'<h2 id="sid-{sid_clean}">'
            f'&sect;5.{i}&nbsp; {_html_escape(svc.short_name)} ({sid}) service</h2>'
        )

        # h3: Overview
        lines.append("<h3>Overview</h3>")
        if svc.supported_sessions:
            lines.append("<p><strong>Supported sessions:</strong> "
                         + ", ".join(_html_escape(s) for s in svc.supported_sessions) + "</p>")
        if svc.required_security_levels:
            lines.append("<p><strong>Required security level:</strong> "
                         + ", ".join(_html_escape(s) for s in svc.required_security_levels) + "</p>")
        if svc.sub_functions:
            sf_rows = [[_html_hex(sf.sub_function_id_hex), _html_escape(sf.short_name)]
                       for sf in svc.sub_functions]
            lines.append(_html_table(["Sub-function", "Description"], sf_rows))

        # h3: Request + Positive Response byte tables
        lines.extend(_html_req_resp_tables(svc, dids, routines, security_levels))

        # h3: NRCs
        if svc.nrc_list:
            nrc_rows = [[_html_hex(nrc.nrc_code_hex), _html_escape(nrc.nrc_name)]
                        for nrc in svc.nrc_list]
            lines.append("<h3>Supported Negative Response Codes</h3>")
            lines.append(_html_table(["NRC", "Description"], nrc_rows))

        # ---- Service-specific extra sections ---------------------------------

        # SecurityAccess (0x27): security levels + FSM
        if svc.service_id_hex == "0x27" and security_levels:
            sl_rows = []
            for s in security_levels:
                sl_rows.append([
                    _html_hex(s.security_level_hex),
                    _html_escape(s.short_name),
                    str(s.num_max_attempts),
                    str(s.attempt_delay),
                    str(s.delay_time_on_boot) if s.delay_time_on_boot else "&mdash;",
                    "On" if s.attempt_counter_enabled else "Off",
                    str(s.seed_size),
                    str(s.key_size),
                    str(s.adr_size),
                    _html_escape(s.algorithm_ref) if s.algorithm_ref else "&mdash;",
                ])
            lines.append("<h3>Security Access Levels</h3>")
            lines.append(_html_table(
                ["Level", "Name", "Max Att.", "Delay (s)", "Boot Delay (s)",
                 "Counter", "Seed (B)", "Key (B)", "ADR (B)", "Algorithm"],
                sl_rows, caption="Configured security access levels"))

            lines.append("<h3>Security Access State Machine (ISO&nbsp;14229-1 Annex&nbsp;I)</h3>")
            lines.append(
                "<p>States: <strong>A</strong>&nbsp;&mdash;&nbsp;All locked, no seed; "
                "<strong>B</strong>&nbsp;&mdash;&nbsp;All locked, seed sent; "
                "<strong>C</strong>&nbsp;&mdash;&nbsp;Unlocked, no seed; "
                "<strong>D</strong>&nbsp;&mdash;&nbsp;Unlocked, seed sent.</p>"
            )
            fsm_rows = [
                ["A &rarr; B", "requestSeed: valid message, session, security level", "Positive response (seed)"],
                ["B &rarr; A", "sendKey: wrong key, Att_Cnt &lt; Att_Cnt_Limit",      "NRC&nbsp;0x35 (invalidKey)"],
                ["B &rarr; A", "sendKey: wrong key, Att_Cnt &ge; Att_Cnt_Limit",      "NRC&nbsp;0x36 (exceededAttempts) + timer"],
                ["B,C,D &rarr; A", "Session change or ECU reset",                     "&mdash; (all levels locked)"],
                ["A &rarr; A", "requestSeed: Delay_Timer still active",               "NRC&nbsp;0x37 (timeDelayNotExpired)"],
                ["B &rarr; C", "sendKey: correct key",                                "Positive response (unlocked)"],
                ["C &rarr; D", "requestSeed: valid message, session, security level", "Positive response (seed)"],
                ["D &rarr; C", "sendKey (any result)",                                "See NRC&nbsp;0x35&nbsp;/&nbsp;Positive"],
            ]
            lines.append(_html_table(
                ["Transition", "Condition", "Response / NRC"],
                fsm_rows, caption="State transitions (ISO 14229-1 Table I.2)"))

            protocol_rows = ctx.get("protocol_rows", [])
            if protocol_rows and len(protocol_rows) > 1:
                lines.append("<h3>Multi-Client Protocol Configuration (ISO&nbsp;14229-1 Annex&nbsp;J)</h3>")
                lines.append(
                    "<p>Multiple diagnostic client slots are configured. "
                    "Lower priority number = higher priority. "
                    "A higher-priority client preempts lower-priority protocols "
                    "after the preempt timeout.</p>"
                )
                pr_rows = []
                for row in protocol_rows:
                    timeout_str = f"{row.preempt_timeout:.3f}&nbsp;s" if row.preempt_timeout else "&mdash;"
                    conns = "; ".join(
                        _html_escape(c.short_name)
                        + (f" (Rx:{_html_escape(c.rx_addr)}, Tx:{_html_escape(c.tx_addr)})" if c.rx_addr else "")
                        for c in row.connections
                    ) if row.connections else "&mdash;"
                    pr_rows.append([
                        _html_escape(row.short_name),
                        _html_escape(row.protocol_type) if row.protocol_type else "&mdash;",
                        str(row.priority), timeout_str,
                        _html_escape(row.trans_type) if row.trans_type else "&mdash;",
                        conns,
                    ])
                lines.append(_html_table(
                    ["Row", "Type", "Priority", "Preempt Timeout", "Trans Type", "Connections"],
                    pr_rows))

        # ReadDataByIdentifier / WriteDataByIdentifier: DID list
        if svc.service_id_hex in ("0x22", "0x2E"):
            access_filter = "read_access" if svc.service_id_hex == "0x22" else "write_access"
            filtered_dids = [d for d in dids if getattr(d, access_filter)]
            if filtered_dids:
                label = "ReadDataByIdentifier" if svc.service_id_hex == "0x22" else "WriteDataByIdentifier"
                lines.append(f"<h3>Supported DID List ({label})</h3>")
                did_rows = []
                for did in filtered_dids:
                    cells = [
                        '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
                        else '<span class="badge-no">x</span>'
                        for s in sessions
                    ]
                    did_rows.append([
                        _html_hex(did.did_id_hex),
                        _html_escape(did.short_name),
                        str(did.total_byte_length) if did.total_byte_length else "&mdash;",
                    ] + cells)
                lines.append(_html_table(
                    ["DID", "Name", "Length (B)"] + sess_names, did_rows,
                    caption=f"DIDs accessible via {_html_escape(label)}"))

                # DID data elements detail
                lines.append("<h3>DID Data Elements</h3>")
                for did in filtered_dids:
                    did_clean = did.did_id_hex.replace("0x", "").upper()
                    lines.append(
                        f'<h4 id="did-{did_clean}">'
                        f'{_html_hex(did.did_id_hex)} &mdash; {_html_escape(did.short_name)}</h4>'
                    )
                    if did.description:
                        lines.append(f'<p class="meta">{_html_escape(did.description)}</p>')
                    if did.data_elements:
                        de_rows = []
                        for de in did.data_elements:
                            de_rows.append([
                                _html_escape(de.short_name),
                                str(de.byte_position),
                                str(de.bit_size),
                                _html_escape(de.data_type or "&mdash;"),
                                _html_escape(de.unit or "&mdash;"),
                                _html_escape(de.description) if de.description else "&mdash;",
                            ])
                        lines.append(_html_table(
                            ["Name", "Byte Pos", "Bits", "Type", "Unit", "Description"],
                            de_rows))
                    has_impl = any(de.read_function or de.write_function or de.global_variables
                                   for de in did.data_elements)
                    if has_impl:
                        impl_rows = []
                        for de in did.data_elements:
                            impl_rows.append([
                                _html_escape(de.short_name),
                                _html_escape(de.read_function) if de.read_function else "&mdash;",
                                _html_escape(de.write_function) if de.write_function else "&mdash;",
                                _html_escape(", ".join(de.global_variables)) if de.global_variables else "&mdash;",
                            ])
                        lines.append(_html_table(
                            ["Element", "Read Function", "Write Function", "Variables"],
                            impl_rows, caption=f"C implementation &mdash; {_html_escape(did.short_name)}"))

        # RoutineControl (0x31): RID list
        if svc.service_id_hex == "0x31" and routines:
            lines.append("<h3>Supported RID List</h3>")
            for rt in routines:
                rid_clean = rt.routine_id_hex.replace("0x", "").upper()
                lines.append(
                    f'<h4 id="rid-{rid_clean}">'
                    f'{_html_hex(rt.routine_id_hex)} &mdash; {_html_escape(rt.short_name)}</h4>'
                )
                if rt.description:
                    lines.append(f'<p class="meta">{_html_escape(rt.description)}</p>')
                ops = []
                if rt.start_supported:  ops.append("Start (0x01)")
                if rt.stop_supported:   ops.append("Stop (0x02)")
                if rt.result_supported: ops.append("RequestResults (0x03)")
                props = []
                if ops:
                    props.append("<strong>Operations:</strong> " + ", ".join(ops))
                if rt.supported_sessions:
                    props.append("<strong>Sessions:</strong> "
                                 + ", ".join(_html_escape(s) for s in rt.supported_sessions))
                if rt.required_security_levels:
                    props.append("<strong>Security:</strong> "
                                 + ", ".join(_html_escape(s) for s in rt.required_security_levels))
                if props:
                    lines.append("<p>" + " &emsp; ".join(props) + "</p>")
                if rt.in_parameters:
                    param_rows = [
                        [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                         _html_escape(p.data_type or "&mdash;"),
                         _html_escape(p.description) if p.description else "&mdash;"]
                        for p in rt.in_parameters
                    ]
                    lines.append("<h5>Input Parameters</h5>")
                    lines.append(_html_table(["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))
                if rt.out_parameters:
                    param_rows = [
                        [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                         _html_escape(p.data_type or "&mdash;"),
                         _html_escape(p.description) if p.description else "&mdash;"]
                        for p in rt.out_parameters
                    ]
                    lines.append("<h5>Output Parameters</h5>")
                    lines.append(_html_table(["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))
                has_impl = rt.start_function or rt.stop_function or rt.result_function or rt.global_variables
                if has_impl:
                    impl_parts = []
                    if rt.start_function:
                        impl_parts.append(f"start: <code>{_html_escape(rt.start_function)}</code>")
                    if rt.stop_function:
                        impl_parts.append(f"stop: <code>{_html_escape(rt.stop_function)}</code>")
                    if rt.result_function:
                        impl_parts.append(f"result: <code>{_html_escape(rt.result_function)}</code>")
                    lines.append("<h5>C Implementation</h5>")
                    if impl_parts:
                        lines.append("<p><strong>Functions:</strong> " + "; ".join(impl_parts) + "</p>")
                    if rt.global_variables:
                        lines.append(
                            "<p><strong>Referenced variables:</strong> "
                            + ", ".join(f"<code>{_html_escape(v)}</code>" for v in rt.global_variables)
                            + "</p>"
                        )

    return "\n".join(lines)


def _render_html_high_overview(ctx: dict) -> str:
    """§5 Application Layers — cross-reference matrices + links to per-service pages."""
    current = ctx.get("_current_path", "sections/2_high_layer/index.html")
    lines: list[str] = []
    lines.append("<h1>&sect;5 Application Layers</h1>")
    lines.append(
        "<p>This section defines all UDS application-layer services implemented by "
        "this ECU. Cross-reference matrices are provided below; follow the links in "
        "the Service Index for each service&rsquo;s detailed specification.</p>"
    )

    services       = ctx.get("services", [])
    sessions       = ctx.get("sessions", [])
    dids           = ctx.get("dids", [])
    routines       = ctx.get("routines", [])
    sess_names     = [s.short_name for s in sessions]

    # Service index with per-service links
    if services:
        lines.append("<h2>Service Index</h2><ul>")
        for i, svc in enumerate(services, start=2):
            sid_clean = svc.service_id_hex.replace("0x", "").lower()
            path = f"sections/2_high_layer/sid{sid_clean}/index.html"
            href = _relpath(current, path)
            lines.append(
                f'<li><a href="{href}">'
                f'&sect;5.{i}&nbsp;{_html_escape(svc.short_name)} '
                f'({_html_hex(svc.service_id_hex)})</a></li>'
            )
        lines.append("</ul>")

    # SID × session matrix
    if services:
        headers = ["SID", "Service", "Sub-functions"] + sess_names
        rows = []
        for svc in services:
            sf_count = str(len(svc.sub_functions)) if svc.sub_functions else "&mdash;"
            cells = [
                '<span class="badge-yes">o</span>' if s.short_name in svc.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(svc.service_id_hex), _html_escape(svc.short_name), sf_count] + cells)
        lines.append("<h2>SID &times; Session Matrix</h2>")
        lines.append(_html_table(headers, rows, caption="SID support per diagnostic session"))

    # NRC × SID matrix
    if services:
        all_nrcs: dict[int, str] = {}
        for svc in services:
            for nrc in svc.nrc_list:
                if nrc.nrc_code not in all_nrcs:
                    all_nrcs[nrc.nrc_code] = nrc.nrc_name
        if all_nrcs:
            headers = ["NRC", "Description"] + [_html_hex(s.service_id_hex) for s in services]
            rows = []
            for code in sorted(all_nrcs):
                code_hex = f"0x{code:02X}"
                row = [_html_hex(code_hex), _html_escape(all_nrcs[code])]
                for svc in services:
                    found = any(n.nrc_code == code for n in svc.nrc_list)
                    row.append('<span class="badge-yes">o</span>' if found else '<span class="badge-no">x</span>')
                rows.append(row)
            lines.append("<h2>NRC &times; SID Matrix</h2>")
            lines.append(_html_table(headers, rows, caption="NRC support per SID"))

    # DID × session matrix
    if dids:
        headers = ["DID", "Description", "Read (0x22)", "Write (0x2E)"] + sess_names
        rows = []
        for did in dids:
            r = '<span class="badge-yes">o</span>' if did.read_access else '<span class="badge-no">x</span>'
            w = '<span class="badge-yes">o</span>' if did.write_access else '<span class="badge-no">x</span>'
            cells = [
                '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(did.did_id_hex), _html_escape(did.short_name), r, w] + cells)
        lines.append("<h2>DID &times; Session Matrix</h2>")
        lines.append(_html_table(headers, rows, caption="DID support per diagnostic session"))

    # RID × session matrix
    if routines:
        headers = ["RID", "Description", "Start", "Stop", "Result"] + sess_names
        rows = []
        for rt in routines:
            start  = '<span class="badge-yes">o</span>' if rt.start_supported  else '<span class="badge-no">x</span>'
            stop   = '<span class="badge-yes">o</span>' if rt.stop_supported   else '<span class="badge-no">x</span>'
            result = '<span class="badge-yes">o</span>' if rt.result_supported else '<span class="badge-no">x</span>'
            cells  = [
                '<span class="badge-yes">o</span>' if s.short_name in rt.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(rt.routine_id_hex), _html_escape(rt.short_name),
                         start, stop, result] + cells)
        lines.append("<h2>RID &times; Session Matrix</h2>")
        lines.append(_html_table(headers, rows, caption="RID support per diagnostic session"))

    return "\n".join(lines)


def _render_html_service_page(ctx: dict, svc, idx: int) -> str:
    """Render a single UDS service detail page."""
    sid = _html_hex(svc.service_id_hex)
    lines: list[str] = []
    lines.append(
        f"<h1>&sect;5.{idx}&nbsp;{_html_escape(svc.short_name)} ({sid}) service</h1>"
    )

    sessions        = ctx.get("sessions", [])
    dids            = ctx.get("dids", [])
    routines        = ctx.get("routines", [])
    security_levels = ctx.get("security_levels", [])
    sess_names      = [s.short_name for s in sessions]

    # Overview
    lines.append("<h2>Overview</h2>")
    if svc.supported_sessions:
        lines.append("<p><strong>Supported sessions:</strong> "
                     + ", ".join(_html_escape(s) for s in svc.supported_sessions) + "</p>")
    if svc.required_security_levels:
        lines.append("<p><strong>Required security level:</strong> "
                     + ", ".join(_html_escape(s) for s in svc.required_security_levels) + "</p>")
    if svc.sub_functions:
        sf_rows = [[_html_hex(sf.sub_function_id_hex), _html_escape(sf.short_name)]
                   for sf in svc.sub_functions]
        lines.append("<h3>Sub-functions</h3>")
        lines.append(_html_table(["Sub-function", "Description"], sf_rows))

    # Request + Positive Response byte tables
    lines.append("<h2>Message Format</h2>")
    lines.extend(_html_req_resp_tables(svc, dids, routines, security_levels))

    # NRCs
    if svc.nrc_list:
        nrc_rows = [[_html_hex(nrc.nrc_code_hex), _html_escape(nrc.nrc_name)]
                    for nrc in svc.nrc_list]
        lines.append("<h2>Supported Negative Response Codes</h2>")
        lines.append(_html_table(["NRC", "Description"], nrc_rows))

    # SecurityAccess (0x27): security levels + FSM + protocol rows
    if svc.service_id_hex == "0x27" and security_levels:
        sl_rows = []
        for s in security_levels:
            sl_rows.append([
                _html_hex(s.security_level_hex),
                _html_escape(s.short_name),
                str(s.num_max_attempts),
                str(s.attempt_delay),
                str(s.delay_time_on_boot) if s.delay_time_on_boot else "&mdash;",
                "On" if s.attempt_counter_enabled else "Off",
                str(s.seed_size),
                str(s.key_size),
                str(s.adr_size),
                _html_escape(s.algorithm_ref) if s.algorithm_ref else "&mdash;",
            ])
        lines.append("<h2>Security Access Levels</h2>")
        lines.append(_html_table(
            ["Level", "Name", "Max Att.", "Delay (s)", "Boot Delay (s)",
             "Counter", "Seed (B)", "Key (B)", "ADR (B)", "Algorithm"],
            sl_rows, caption="Configured security access levels"))

        lines.append("<h2>Security Access State Machine (ISO&nbsp;14229-1 Annex&nbsp;I)</h2>")
        lines.append(
            "<p>States: <strong>A</strong>&nbsp;&mdash;&nbsp;All locked, no seed; "
            "<strong>B</strong>&nbsp;&mdash;&nbsp;All locked, seed sent; "
            "<strong>C</strong>&nbsp;&mdash;&nbsp;Unlocked, no seed; "
            "<strong>D</strong>&nbsp;&mdash;&nbsp;Unlocked, seed sent.</p>"
        )
        fsm_rows = [
            ["A &rarr; B",     "requestSeed: valid message, session, security level", "Positive response (seed)"],
            ["B &rarr; A",     "sendKey: wrong key, Att_Cnt &lt; Att_Cnt_Limit",     "NRC&nbsp;0x35 (invalidKey)"],
            ["B &rarr; A",     "sendKey: wrong key, Att_Cnt &ge; Att_Cnt_Limit",     "NRC&nbsp;0x36 (exceededAttempts) + timer"],
            ["B,C,D &rarr; A", "Session change or ECU reset",                        "&mdash; (all levels locked)"],
            ["A &rarr; A",     "requestSeed: Delay_Timer still active",              "NRC&nbsp;0x37 (timeDelayNotExpired)"],
            ["B &rarr; C",     "sendKey: correct key",                               "Positive response (unlocked)"],
            ["C &rarr; D",     "requestSeed: valid message, session, security level", "Positive response (seed)"],
            ["D &rarr; C",     "sendKey (any result)",                               "See NRC&nbsp;0x35&nbsp;/&nbsp;Positive"],
        ]
        lines.append(_html_table(
            ["Transition", "Condition", "Response / NRC"],
            fsm_rows, caption="State transitions (ISO 14229-1 Table I.2)"))

        protocol_rows = ctx.get("protocol_rows", [])
        if protocol_rows and len(protocol_rows) > 1:
            lines.append("<h2>Multi-Client Protocol Configuration (ISO&nbsp;14229-1 Annex&nbsp;J)</h2>")
            lines.append(
                "<p>Multiple diagnostic client slots are configured. "
                "Lower priority number = higher priority. "
                "A higher-priority client preempts lower-priority protocols "
                "after the configured preempt timeout.</p>"
            )
            pr_rows = []
            for row in protocol_rows:
                timeout_str = f"{row.preempt_timeout:.3f}&nbsp;s" if row.preempt_timeout else "&mdash;"
                conns = "; ".join(
                    _html_escape(c.short_name)
                    + (f" (Rx:{_html_escape(c.rx_addr)}, Tx:{_html_escape(c.tx_addr)})" if c.rx_addr else "")
                    for c in row.connections
                ) if row.connections else "&mdash;"
                pr_rows.append([
                    _html_escape(row.short_name),
                    _html_escape(row.protocol_type) if row.protocol_type else "&mdash;",
                    str(row.priority), timeout_str,
                    _html_escape(row.trans_type) if row.trans_type else "&mdash;",
                    conns,
                ])
            lines.append(_html_table(
                ["Row", "Type", "Priority", "Preempt Timeout", "Trans Type", "Connections"],
                pr_rows, caption="Protocol rows (ISO 14229-1 Annex J)"))

    # ReadDataByIdentifier / WriteDataByIdentifier
    if svc.service_id_hex in ("0x22", "0x2E"):
        access_filter = "read_access" if svc.service_id_hex == "0x22" else "write_access"
        filtered_dids = [d for d in dids if getattr(d, access_filter)]
        if filtered_dids:
            label = "ReadDataByIdentifier" if svc.service_id_hex == "0x22" else "WriteDataByIdentifier"
            lines.append(f"<h2>Supported DID List ({label})</h2>")
            did_rows = []
            for did in filtered_dids:
                cells = [
                    '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
                    else '<span class="badge-no">x</span>'
                    for s in sessions
                ]
                did_rows.append([
                    _html_hex(did.did_id_hex),
                    _html_escape(did.short_name),
                    str(did.total_byte_length) if did.total_byte_length else "&mdash;",
                ] + cells)
            lines.append(_html_table(
                ["DID", "Name", "Length (B)"] + sess_names, did_rows,
                caption=f"DIDs accessible via {_html_escape(label)}"))

            lines.append("<h2>DID Data Elements</h2>")
            for did in filtered_dids:
                did_clean = did.did_id_hex.replace("0x", "").upper()
                lines.append(
                    f'<h3 id="did-{did_clean}">'
                    f'{_html_hex(did.did_id_hex)} &mdash; {_html_escape(did.short_name)}</h3>'
                )
                if did.description:
                    lines.append(f'<p class="meta">{_html_escape(did.description)}</p>')
                if did.data_elements:
                    de_rows = []
                    for de in did.data_elements:
                        de_rows.append([
                            _html_escape(de.short_name),
                            str(de.byte_position),
                            str(de.bit_size),
                            _html_escape(de.data_type or "&mdash;"),
                            _html_escape(de.unit or "&mdash;"),
                            _html_escape(de.description) if de.description else "&mdash;",
                        ])
                    lines.append(_html_table(
                        ["Name", "Byte Pos", "Bits", "Type", "Unit", "Description"],
                        de_rows))
                has_impl = any(de.read_function or de.write_function or de.global_variables
                               for de in did.data_elements)
                if has_impl:
                    impl_rows = []
                    for de in did.data_elements:
                        impl_rows.append([
                            _html_escape(de.short_name),
                            _html_escape(de.read_function) if de.read_function else "&mdash;",
                            _html_escape(de.write_function) if de.write_function else "&mdash;",
                            _html_escape(", ".join(de.global_variables)) if de.global_variables else "&mdash;",
                        ])
                    lines.append(_html_table(
                        ["Element", "Read Function", "Write Function", "Variables"],
                        impl_rows,
                        caption=f"C implementation &mdash; {_html_escape(did.short_name)}"))

    # RoutineControl (0x31)
    if svc.service_id_hex == "0x31" and routines:
        lines.append("<h2>Supported RID List</h2>")
        for rt in routines:
            rid_clean = rt.routine_id_hex.replace("0x", "").upper()
            lines.append(
                f'<h3 id="rid-{rid_clean}">'
                f'{_html_hex(rt.routine_id_hex)} &mdash; {_html_escape(rt.short_name)}</h3>'
            )
            if rt.description:
                lines.append(f'<p class="meta">{_html_escape(rt.description)}</p>')
            ops = []
            if rt.start_supported:  ops.append("Start (0x01)")
            if rt.stop_supported:   ops.append("Stop (0x02)")
            if rt.result_supported: ops.append("RequestResults (0x03)")
            props = []
            if ops:
                props.append("<strong>Operations:</strong> " + ", ".join(ops))
            if rt.supported_sessions:
                props.append("<strong>Sessions:</strong> "
                             + ", ".join(_html_escape(s) for s in rt.supported_sessions))
            if rt.required_security_levels:
                props.append("<strong>Security:</strong> "
                             + ", ".join(_html_escape(s) for s in rt.required_security_levels))
            if props:
                lines.append("<p>" + " &emsp; ".join(props) + "</p>")
            if rt.in_parameters:
                param_rows = [
                    [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                     _html_escape(p.data_type or "&mdash;"),
                     _html_escape(p.description) if p.description else "&mdash;"]
                    for p in rt.in_parameters
                ]
                lines.append("<h4>Input Parameters</h4>")
                lines.append(_html_table(
                    ["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))
            if rt.out_parameters:
                param_rows = [
                    [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                     _html_escape(p.data_type or "&mdash;"),
                     _html_escape(p.description) if p.description else "&mdash;"]
                    for p in rt.out_parameters
                ]
                lines.append("<h4>Output Parameters</h4>")
                lines.append(_html_table(
                    ["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))
            has_impl = rt.start_function or rt.stop_function or rt.result_function or rt.global_variables
            if has_impl:
                impl_parts = []
                if rt.start_function:
                    impl_parts.append(f"start: <code>{_html_escape(rt.start_function)}</code>")
                if rt.stop_function:
                    impl_parts.append(f"stop: <code>{_html_escape(rt.stop_function)}</code>")
                if rt.result_function:
                    impl_parts.append(f"result: <code>{_html_escape(rt.result_function)}</code>")
                lines.append("<h4>C Implementation</h4>")
                if impl_parts:
                    lines.append("<p><strong>Functions:</strong> " + "; ".join(impl_parts) + "</p>")
                if rt.global_variables:
                    lines.append(
                        "<p><strong>Referenced variables:</strong> "
                        + ", ".join(f"<code>{_html_escape(v)}</code>" for v in rt.global_variables)
                        + "</p>"
                    )

    return "\n".join(lines)


def _render_html_security(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>SecurityAccess (SID&nbsp;0x27)</h1>")
    lines.append(
        "<p>The SecurityAccess service (ISO&nbsp;14229-1 §12.8) restricts access to sensitive "
        "diagnostic functions using a seed/key challenge-response mechanism. "
        "Each security level has independent parameters for attempt limits and delay timers.</p>"
    )

    security_levels = ctx.get("security_levels", [])
    if security_levels:
        rows = []
        for s in security_levels:
            rows.append([
                _html_hex(s.security_level_hex),
                _html_escape(s.short_name),
                str(s.num_max_attempts),
                str(s.attempt_delay),
                str(s.delay_time_on_boot) if s.delay_time_on_boot else "&mdash;",
                "On" if s.attempt_counter_enabled else "Off",
                str(s.seed_size),
                str(s.key_size),
                str(s.adr_size),
                _html_escape(s.algorithm_ref) if s.algorithm_ref else "&mdash;",
                _html_escape(s.seed_key_increment_mode) if s.seed_key_increment_mode else "&mdash;",
            ])
        lines.append("<h2>Security Access Levels</h2>")
        lines.append(_html_table(
            ["Level", "Name", "Max Attempts", "Delay (s)", "Boot Delay (s)",
             "Counter", "Seed (B)", "Key (B)", "ADR (B)", "Algorithm", "Increment"],
            rows, caption="Configured security access levels"))

    lines.append("<h2>State Machine (ISO&nbsp;14229-1 Annex&nbsp;I)</h2>")
    lines.append(
        "<p>The SecurityAccess service uses a 4-state finite state machine (FSM) to manage "
        "locking state across all configured security levels. "
        "States: <strong>A</strong>&nbsp;&mdash;&nbsp;All locked, no seed pending; "
        "<strong>B</strong>&nbsp;&mdash;&nbsp;All locked, seed sent; "
        "<strong>C</strong>&nbsp;&mdash;&nbsp;Unlocked, no seed pending; "
        "<strong>D</strong>&nbsp;&mdash;&nbsp;Unlocked, seed sent.</p>"
    )
    fsm_rows = [
        ["A &rarr; B", "requestSeed: valid message, session, security level", "Positive response (seed)"],
        ["B &rarr; A", "sendKey: wrong key, Att_Cnt &lt; Att_Cnt_Limit", "NRC&nbsp;0x35 (invalidKey)"],
        ["B &rarr; A", "sendKey: wrong key, Att_Cnt &ge; Att_Cnt_Limit", "NRC&nbsp;0x36 (exceededAttempts) + start timer"],
        ["B,C,D &rarr; A", "Session change or ECU reset", "&mdash; (all levels locked)"],
        ["A &rarr; A", "requestSeed: Delay_Timer still active", "NRC&nbsp;0x37 (timeDelayNotExpired)"],
        ["B &rarr; C", "sendKey: correct key", "Positive response (unlocked)"],
        ["C &rarr; D", "requestSeed: valid message, session, security level", "Positive response (seed)"],
        ["D &rarr; C", "sendKey (any result)", "See NRC&nbsp;0x35&nbsp;/&nbsp;Positive"],
    ]
    lines.append(_html_table(
        ["Transition", "Condition", "Response / NRC"],
        fsm_rows,
        caption="SecurityAccess state transitions (ISO 14229-1 Table I.2)"))

    protocol_rows = ctx.get("protocol_rows", [])
    if protocol_rows:
        if len(protocol_rows) > 1:
            lines.append("<h2>Multi-Client Protocol Configuration (ISO&nbsp;14229-1 Annex&nbsp;J)</h2>")
            lines.append(
                "<p>Multiple diagnostic client slots are configured. "
                "The DCM manages concurrent requests using protocol priority and preemption "
                "as recommended by ISO&nbsp;14229-1 Annex&nbsp;J. "
                "<strong>Priority rule:</strong> lower numeric value = higher priority. "
                "A higher-priority client preempts a lower-priority active protocol after "
                "the configured preempt timeout.</p>"
            )
        else:
            lines.append("<h2>Protocol Configuration</h2>")
        rows = []
        for row in protocol_rows:
            timeout_str = f"{row.preempt_timeout:.3f}&nbsp;s" if row.preempt_timeout else "&mdash;"
            conns = "; ".join(
                _html_escape(c.short_name)
                + (f" (Rx:&nbsp;{_html_escape(c.rx_addr)}, Tx:&nbsp;{_html_escape(c.tx_addr)})"
                   if c.rx_addr else "")
                for c in row.connections
            ) if row.connections else "&mdash;"
            rows.append([
                _html_escape(row.short_name),
                _html_escape(row.protocol_type) if row.protocol_type else "&mdash;",
                str(row.priority),
                timeout_str,
                _html_escape(row.trans_type) if row.trans_type else "&mdash;",
                conns,
            ])
        lines.append(_html_table(
            ["Protocol Row", "Type", "Priority", "Preempt Timeout", "Trans Type", "Connections"],
            rows, caption="Protocol rows (ISO 14229-1 Annex J)"))

    return "\n".join(lines)


def _render_html_dids(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Data Identifiers (DIDs)</h1>")
    dids = ctx.get("dids", [])
    if not dids:
        lines.append("<p>No DIDs are configured for this ECU.</p>")
        return "\n".join(lines)

    lines.append(
        "<p>DIDs are read via SID&nbsp;0x22 (ReadDataByIdentifier) and written via "
        "SID&nbsp;0x2E (WriteDataByIdentifier). Each DID contains one or more data "
        "elements with defined byte positions and data types.</p>"
    )

    sessions = ctx.get("sessions", [])
    sess_names = [s.short_name for s in sessions]

    # Overview table
    headers = ["DID", "Name", "Read", "Write", "Length (B)"] + sess_names
    rows = []
    for did in dids:
        r = '<span class="badge-yes">o</span>' if did.read_access else '<span class="badge-no">x</span>'
        w = '<span class="badge-yes">o</span>' if did.write_access else '<span class="badge-no">x</span>'
        sess_cells = [
            '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
            else '<span class="badge-no">x</span>'
            for s in sessions
        ]
        rows.append([
            _html_hex(did.did_id_hex), _html_escape(did.short_name), r, w,
            str(did.total_byte_length) if did.total_byte_length else "&mdash;"
        ] + sess_cells)
    lines.append("<h2>DID Overview</h2>")
    lines.append(_html_table(headers, rows, caption="Configured Data Identifiers"))

    # Per-DID details
    lines.append("<h2>DID Details</h2>")
    for did in dids:
        did_clean = did.did_id_hex.replace("0x", "").upper()
        lines.append(
            f'<h3 id="did-{did_clean}">'
            f'{_html_hex(did.did_id_hex)} &mdash; {_html_escape(did.short_name)}</h3>'
        )
        if did.description:
            lines.append(f'<p class="meta">{_html_escape(did.description)}</p>')

        props = []
        if did.supported_sessions:
            props.append("<strong>Sessions:</strong> "
                         + ", ".join(_html_escape(s) for s in did.supported_sessions))
        if did.required_security_levels:
            props.append("<strong>Security:</strong> "
                         + ", ".join(_html_escape(s) for s in did.required_security_levels))
        access_parts = []
        if did.read_access:
            access_parts.append("Read (0x22)")
        if did.write_access:
            access_parts.append("Write (0x2E)")
        if access_parts:
            props.append("<strong>Access:</strong> " + ", ".join(access_parts))
        if did.total_byte_length:
            props.append(f"<strong>Total length:</strong> {did.total_byte_length}&nbsp;bytes")
        if props:
            lines.append("<p>" + " &emsp; ".join(props) + "</p>")

        if did.data_elements:
            de_rows = []
            for de in did.data_elements:
                de_rows.append([
                    _html_escape(de.short_name),
                    str(de.byte_position),
                    str(de.bit_size),
                    _html_escape(de.data_type or "&mdash;"),
                    _html_escape(de.unit or "&mdash;"),
                    _html_escape(de.description) if de.description else "&mdash;",
                ])
            lines.append(_html_table(
                ["Name", "Byte Pos", "Bits", "Type", "Unit", "Description"],
                de_rows, caption=f"Data elements of {_html_escape(did.short_name)}"))

            has_impl = any(
                de.read_function or de.write_function or de.global_variables
                for de in did.data_elements
            )
            if has_impl:
                impl_rows = []
                for de in did.data_elements:
                    impl_rows.append([
                        _html_escape(de.short_name),
                        _html_escape(de.read_function) if de.read_function else "&mdash;",
                        _html_escape(de.write_function) if de.write_function else "&mdash;",
                        _html_escape(", ".join(de.global_variables)) if de.global_variables else "&mdash;",
                    ])
                lines.append(_html_table(
                    ["Data Element", "Read Function", "Write Function", "Referenced Variables"],
                    impl_rows, caption=f"C implementation &mdash; {_html_escape(did.short_name)}"))

    return "\n".join(lines)


def _render_html_routines(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Routines (RIDs)</h1>")
    routines = ctx.get("routines", [])
    if not routines:
        lines.append("<p>No routines are configured for this ECU.</p>")
        return "\n".join(lines)

    lines.append(
        "<p>Routines are controlled via SID&nbsp;0x31 (RoutineControl) with "
        "sub-functions Start&nbsp;(0x01), Stop&nbsp;(0x02), and "
        "RequestResults&nbsp;(0x03).</p>"
    )

    sessions = ctx.get("sessions", [])
    sess_names = [s.short_name for s in sessions]

    # Overview table
    headers = ["RID", "Name", "Start", "Stop", "Result"] + sess_names
    rows = []
    for rt in routines:
        start  = '<span class="badge-yes">o</span>' if rt.start_supported  else '<span class="badge-no">x</span>'
        stop   = '<span class="badge-yes">o</span>' if rt.stop_supported   else '<span class="badge-no">x</span>'
        result = '<span class="badge-yes">o</span>' if rt.result_supported else '<span class="badge-no">x</span>'
        sess_cells = [
            '<span class="badge-yes">o</span>' if s.short_name in rt.supported_sessions
            else '<span class="badge-no">x</span>'
            for s in sessions
        ]
        rows.append([_html_hex(rt.routine_id_hex), _html_escape(rt.short_name),
                     start, stop, result] + sess_cells)
    lines.append("<h2>Routine Overview</h2>")
    lines.append(_html_table(headers, rows, caption="Configured routines"))

    # Per-routine details
    lines.append("<h2>Routine Details</h2>")
    for rt in routines:
        rid_clean = rt.routine_id_hex.replace("0x", "").upper()
        lines.append(
            f'<h3 id="rid-{rid_clean}">'
            f'{_html_hex(rt.routine_id_hex)} &mdash; {_html_escape(rt.short_name)}</h3>'
        )
        if rt.description:
            lines.append(f'<p class="meta">{_html_escape(rt.description)}</p>')

        ops = []
        if rt.start_supported:  ops.append("Start (0x01)")
        if rt.stop_supported:   ops.append("Stop (0x02)")
        if rt.result_supported: ops.append("RequestResults (0x03)")
        props = []
        if ops:
            props.append("<strong>Operations:</strong> " + ", ".join(ops))
        if rt.supported_sessions:
            props.append("<strong>Sessions:</strong> "
                         + ", ".join(_html_escape(s) for s in rt.supported_sessions))
        if rt.required_security_levels:
            props.append("<strong>Security:</strong> "
                         + ", ".join(_html_escape(s) for s in rt.required_security_levels))
        if props:
            lines.append("<p>" + " &emsp; ".join(props) + "</p>")

        if rt.in_parameters:
            param_rows = [
                [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                 _html_escape(p.data_type or "&mdash;"), _html_escape(p.description) if p.description else "&mdash;"]
                for p in rt.in_parameters
            ]
            lines.append("<h4>Input Parameters</h4>")
            lines.append(_html_table(
                ["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))

        if rt.out_parameters:
            param_rows = [
                [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                 _html_escape(p.data_type or "&mdash;"), _html_escape(p.description) if p.description else "&mdash;"]
                for p in rt.out_parameters
            ]
            lines.append("<h4>Output Parameters</h4>")
            lines.append(_html_table(
                ["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))

        has_impl = (rt.start_function or rt.stop_function or rt.result_function
                    or rt.global_variables)
        if has_impl:
            impl_parts = []
            if rt.start_function:
                impl_parts.append(f"start: <code>{_html_escape(rt.start_function)}</code>")
            if rt.stop_function:
                impl_parts.append(f"stop: <code>{_html_escape(rt.stop_function)}</code>")
            if rt.result_function:
                impl_parts.append(f"result: <code>{_html_escape(rt.result_function)}</code>")
            lines.append("<h4>C Implementation</h4>")
            if impl_parts:
                lines.append("<p><strong>Functions:</strong> " + "; ".join(impl_parts) + "</p>")
            if rt.global_variables:
                lines.append(
                    "<p><strong>Referenced variables:</strong> "
                    + ", ".join(f"<code>{_html_escape(v)}</code>" for v in rt.global_variables)
                    + "</p>"
                )

    return "\n".join(lines)


def _render_html_annex(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Annex</h1>")

    sessions = ctx.get("sessions", [])
    sess_names = [s.short_name for s in sessions]

    # SID table
    services = ctx.get("services", [])
    if services:
        headers = ["SID", "Description", "Sub-function"] + sess_names
        rows = []
        for svc in services:
            sid_h = _html_hex(svc.service_id_hex)
            if svc.sub_functions:
                for i, sf in enumerate(svc.sub_functions):
                    sid_cell = sid_h if i == 0 else ""
                    desc_cell = _html_escape(svc.short_name) if i == 0 else ""
                    sf_cell = f"{_html_hex(sf.sub_function_id_hex)}: {_html_escape(sf.short_name)}"
                    sess_cells = [
                        '<span class="badge-yes">o</span>' if s.short_name in svc.supported_sessions
                        else '<span class="badge-no">x</span>'
                        for s in sessions
                    ]
                    rows.append([sid_cell, desc_cell, sf_cell] + sess_cells)
            else:
                sess_cells = [
                    '<span class="badge-yes">o</span>' if s.short_name in svc.supported_sessions
                    else '<span class="badge-no">x</span>'
                    for s in sessions
                ]
                rows.append([sid_h, _html_escape(svc.short_name), "n/a"] + sess_cells)
        lines.append("<h2>Supported SID &amp; Subfunction List</h2>")
        lines.append(_html_table(headers, rows))

    # DID table
    dids = ctx.get("dids", [])
    if dids:
        headers = ["DID", "Description", "Read (0x22)", "Write (0x2E)"] + sess_names
        rows = []
        for did in dids:
            r = '<span class="badge-yes">Yes</span>' if did.read_access else '<span class="badge-no">No</span>'
            w = '<span class="badge-yes">Yes</span>' if did.write_access else '<span class="badge-no">No</span>'
            sess_cells = [
                '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(did.did_id_hex), _html_escape(did.short_name), r, w] + sess_cells)
        lines.append("<h2>Supported DID List</h2>")
        lines.append(_html_table(headers, rows))

    # RID table
    routines = ctx.get("routines", [])
    if routines:
        headers = ["RID", "Description", "Start", "Stop", "Result"] + sess_names
        rows = []
        for rt in routines:
            start = '<span class="badge-yes">o</span>' if rt.start_supported else '<span class="badge-no">x</span>'
            stop = '<span class="badge-yes">o</span>' if rt.stop_supported else '<span class="badge-no">x</span>'
            result = '<span class="badge-yes">o</span>' if rt.result_supported else '<span class="badge-no">x</span>'
            sess_cells = [
                '<span class="badge-yes">o</span>' if s.short_name in rt.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(rt.routine_id_hex), _html_escape(rt.short_name),
                         start, stop, result] + sess_cells)
        lines.append("<h2>Supported RID List</h2>")
        lines.append(_html_table(headers, rows))

    # NRC table
    if services:
        all_nrcs: dict[int, str] = {}
        for svc in services:
            for nrc in svc.nrc_list:
                if nrc.nrc_code not in all_nrcs:
                    all_nrcs[nrc.nrc_code] = nrc.nrc_name
        if all_nrcs:
            headers = ["NRC", "Description"] + [_html_hex(s.service_id_hex) for s in services]
            rows = []
            for code in sorted(all_nrcs):
                # Reconstruct the hex representation
                code_hex = f"0x{code:02X}"
                row = [_html_hex(code_hex), _html_escape(all_nrcs[code])]
                for svc in services:
                    found = any(n.nrc_code == code for n in svc.nrc_list)
                    row.append(
                        '<span class="badge-yes">o</span>' if found
                        else '<span class="badge-no">x</span>'
                    )
                rows.append(row)
            lines.append("<h2>Supported NRC List</h2>")
            lines.append(_html_table(headers, rows))

    return "\n".join(lines)
