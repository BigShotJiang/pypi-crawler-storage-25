"""Command-line interface for udsxml2tex."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from typing import Optional

from udsxml2tex import __version__
from udsxml2tex.generator import TexGenerator
from udsxml2tex.parser import ArxmlParser


_EPILOG = """\
Usage modes:
  1) CLI mode (default):
       udsxml2tex input.arxml -o output.tex
     Directly specify ARXML files for batch conversion.

  2) Interactive mode:
       udsxml2tex -I
     Step-by-step guided generation where you select ARXML type,
     file paths, items to include, and more.

  3) Config file mode:
       udsxml2tex --config udsxml2tex_config.json
     Load a previously saved configuration file to generate the spec.
     Config files can be saved from interactive mode.

  4) Python library usage:
       from udsxml2tex import ArxmlParser, TexGenerator
       spec = ArxmlParser().parse("input.arxml")
       TexGenerator().generate(spec, "output.tex")
     Import and use directly from Python code.
"""


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="udsxml2tex",
        description="Convert AUTOSAR DCM/CanTp arxml to LaTeX UDS specification documents.",
        epilog=_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "input",
        nargs="*",
        help="Input ARXML file(s). Multiple files will be merged. "
             "Not required when using -I or --config.",
    )
    parser.add_argument(
        "-I",
        "--interactive",
        action="store_true",
        help="Launch interactive mode — step-by-step guided generation.",
    )
    parser.add_argument(
        "--config",
        default=None,
        metavar="FILE",
        help="Path to a JSON config file (saved from interactive mode).",
    )
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output .tex file path. Default: <input_stem>_uds_spec.tex",
    )
    parser.add_argument(
        "--ecu-name",
        default=None,
        help="Override ECU name in the generated document.",
    )
    parser.add_argument(
        "--template-dir",
        default=None,
        help="Directory containing custom Jinja2 LaTeX templates.",
    )
    parser.add_argument(
        "--template",
        default="uds_spec.tex.j2",
        help="Template file name (default: uds_spec.tex.j2).",
    )
    parser.add_argument(
        "--pdf",
        action="store_true",
        help="Compile the generated .tex to PDF (requires latexmk or pdflatex).",
    )
    parser.add_argument(
        "--html",
        action="store_true",
        help="Generate an HTML document in addition to (or instead of) LaTeX.",
    )
    parser.add_argument(
        "--dem",
        default=None,
        metavar="FILE",
        help="Path to a separate DEM ARXML file to merge DEM data from.",
    )
    parser.add_argument(
        "--c-source",
        action="append",
        metavar="PATH",
        default=[],
        help=(
            "C source file or directory to scan for DID global variables. "
            "Can be specified multiple times. "
            "When provided, DID data-element tables in the output will include "
            "the global variable names referenced by each DID read/write function."
        ),
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Parse ARXML and print a summary without generating any output files.",
    )
    parser.add_argument(
        "--format",
        default="tex",
        choices=["tex", "html", "md", "rst", "csv", "yaml", "json", "docx"],
        metavar="FORMAT",
        help="Output format: tex (default), html, md, rst, csv, yaml, json, docx.",
    )
    parser.add_argument(
        "--extra-vars",
        action="append",
        metavar="KEY=VALUE",
        default=[],
        help=(
            "Extra Jinja2 template variable (KEY=VALUE). "
            "Can be specified multiple times. Only applies to tex/html output."
        ),
    )
    parser.add_argument(
        "--lang",
        default="en",
        choices=["en", "ja"],
        help="Language for generated document labels (default: en).",
    )
    parser.add_argument(
        "--filter-dids",
        default=None,
        metavar="IDS",
        help="Comma-separated hex DID IDs to include (e.g. 0x1234,0x1235). "
             "Other DIDs are excluded from the output.",
    )
    parser.add_argument(
        "--filter-services",
        default=None,
        metavar="IDS",
        help="Comma-separated hex service IDs to include (e.g. 0x10,0x22).",
    )
    parser.add_argument(
        "--filter-dtcs",
        default=None,
        metavar="IDS",
        help="Comma-separated hex DTC IDs to include.",
    )
    parser.add_argument(
        "--diff",
        default=None,
        metavar="FILE",
        help="Compare parsed ARXML against FILE (ARXML or JSON) and print a diff report.",
    )
    parser.add_argument(
        "--validate",
        action="store_true",
        help="Run ISO 14229-1 consistency validation and print issues. "
             "Exits non-zero if errors are found.",
    )
    parser.add_argument(
        "--watch",
        action="store_true",
        help="Watch input files for changes and re-generate automatically. "
             "Requires the watchdog package (pip install udsxml2tex[watch]).",
    )
    parser.add_argument(
        "--serve",
        action="store_true",
        help="Start the local web server (browser mode). "
             "Requires pip install udsxml2tex[web].",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8765,
        help="Port for --serve mode (default: 8765).",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host for --serve mode (default: 127.0.0.1).",
    )
    parser.add_argument(
        "--generate-completion",
        choices=["bash", "zsh", "fish"],
        metavar="SHELL",
        help="Print a shell completion script and exit (bash, zsh, or fish).",
    )
    parser.add_argument(
        "--c-scan-depth",
        type=int,
        default=0,
        metavar="N",
        help="Transitive C-scan depth: follow function calls up to N levels deep "
             "(0 = direct body only, max 3).",
    )
    parser.add_argument(
        "--doip",
        default=None,
        metavar="FILE",
        help="Path to a DoIP ARXML file to extract ISO 13400 configuration from.",
    )
    parser.add_argument(
        "--comm",
        default=None,
        metavar="FILE",
        help="Path to a Communication ARXML file (I-SIGNAL, FRAME, PDU-TO-FRAME-MAPPING).",
    )
    parser.add_argument(
        "--validate-xsd",
        default=None,
        metavar="XSD",
        help="Validate input ARXML against XSD schema file before parsing.",
    )
    parser.add_argument(
        "--parallel",
        action="store_true",
        help="Parse multiple ARXML input files in parallel (ProcessPoolExecutor).",
    )
    parser.add_argument(
        "--cache-dir",
        default=None,
        metavar="DIR",
        help="Directory to cache parsed specs by file hash for incremental parsing.",
    )
    parser.add_argument(
        "--json-schema",
        action="store_true",
        help="Print the JSON Schema for UdsSpecification to stdout and exit.",
    )
    parser.add_argument(
        "--byte-diagrams",
        default=None,
        metavar="DIR",
        help="Generate bytefield DID byte-layout .tex files into DIR.",
    )
    parser.add_argument(
        "--sequence-diagrams",
        default=None,
        metavar="DIR",
        help="Generate TikZ UML sequence diagram .tex files into DIR.",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose logging output.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """Main entry point for the CLI.

    Args:
        argv: Command-line arguments. Defaults to sys.argv[1:].

    Returns:
        Exit code (0 for success).
    """
    parser = _build_parser()
    args = parser.parse_args(argv)

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(levelname)s: %(message)s",
    )

    # --- JSON Schema output ---------------------------------------------
    if getattr(args, "json_schema", False):
        from udsxml2tex.schema import generate_json_schema
        import json as _json
        print(_json.dumps(generate_json_schema(), indent=2))
        return 0

    # --- Shell completion -----------------------------------------------
    if args.generate_completion:
        from udsxml2tex.completion import print_completion
        print_completion(args.generate_completion)
        return 0

    # --- Web server (browser mode) --------------------------------------
    if args.serve:
        try:
            from udsxml2tex.webserver import start_server
        except ImportError:
            logging.error(
                "Web server dependencies not installed. "
                "Run: pip install udsxml2tex[web]"
            )
            return 1
        start_server(host=args.host, port=args.port, open_browser=True)
        return 0

    # --- Interactive mode -----------------------------------------------
    if args.interactive:
        from udsxml2tex.interactive import InteractiveSession

        return InteractiveSession().run()

    # --- Config-file mode -----------------------------------------------
    if args.config:
        from udsxml2tex.config import GenerationConfig
        from udsxml2tex.interactive import generate_from_config

        try:
            config = GenerationConfig.load(args.config)
        except Exception as e:
            logging.error("Failed to load config: %s", e)
            return 1
        # Allow CLI overrides on top of config
        if args.output:
            config.output_path = args.output
        if args.ecu_name:
            config.ecu_name = args.ecu_name
        if args.template_dir:
            config.template_dir = args.template_dir
        if args.template != "uds_spec.tex.j2":
            config.template = args.template
        return generate_from_config(config)

    # --- Direct CLI mode ------------------------------------------------
    if not args.input:
        parser.print_help()
        return 1

    # Validate input files
    input_paths = [Path(p) for p in args.input]
    for p in input_paths:
        if not p.exists():
            logging.error("Input file not found: %s", p)
            return 1
        if not p.suffix.lower() == ".arxml":
            logging.warning(
                "File does not have .arxml extension: %s", p
            )

    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        stem = input_paths[0].stem
        suffix = ".html" if args.html and not args.pdf else ".tex"
        output_path = input_paths[0].parent / f"{stem}_uds_spec{suffix}"

    # XSD validation (before parsing)
    if getattr(args, "validate_xsd", None):
        xsd_path = Path(args.validate_xsd)
        if not xsd_path.exists():
            logging.error("XSD file not found: %s", xsd_path)
            return 1
        errs = ArxmlParser().validate_against_xsd(input_paths[0], xsd_path)
        if errs:
            for e in errs:
                logging.error("XSD: %s", e)
            return 1
        logging.info("XSD validation passed.")

    # Parse ARXML
    arxml_parser = ArxmlParser()
    _parallel = getattr(args, "parallel", False)
    _cache_dir = getattr(args, "cache_dir", None)
    try:
        if len(input_paths) == 1:
            spec = arxml_parser.parse(input_paths[0], cache_dir=_cache_dir)
        else:
            spec = arxml_parser.parse_multi(input_paths, parallel=_parallel)
    except Exception as e:
        logging.error("Failed to parse ARXML: %s", e)
        return 1

    # Report validation warnings
    if arxml_parser.warnings:
        for w in arxml_parser.warnings:
            logging.warning("[%s] %s", w.section, w.message)

    # Merge separate DEM arxml if provided
    if args.dem:
        from udsxml2tex.dem_parser import DemParser

        dem_path = Path(args.dem)
        if not dem_path.exists():
            logging.error("DEM ARXML file not found: %s", dem_path)
            return 1
        try:
            DemParser().parse(dem_path, spec)
        except Exception as e:
            logging.error("Failed to parse DEM ARXML: %s", e)
            return 1

    # Override ECU name if specified
    if args.ecu_name:
        spec.ecu_name = args.ecu_name

    # Parse DoIP ARXML if provided
    if getattr(args, "doip", None):
        from udsxml2tex.doip_parser import DoIpParser
        from lxml import etree as _etree
        doip_path = Path(args.doip)
        if not doip_path.exists():
            logging.error("DoIP ARXML file not found: %s", doip_path)
            return 1
        try:
            _doip_root = _etree.parse(str(doip_path)).getroot()
            spec.doip_config = DoIpParser().parse(_doip_root)
        except Exception as e:
            logging.warning("DoIP ARXML parsing failed: %s", e)

    # Parse Communication ARXML if provided
    if getattr(args, "comm", None):
        from udsxml2tex.comm_arxml_parser import CommArxmlParser
        from lxml import etree as _etree
        comm_path = Path(args.comm)
        if not comm_path.exists():
            logging.error("Comm ARXML file not found: %s", comm_path)
            return 1
        try:
            _comm_root = _etree.parse(str(comm_path)).getroot()
            spec.comm_config = CommArxmlParser().parse(_comm_root)
        except Exception as e:
            logging.warning("Communication ARXML parsing failed: %s", e)

    # Scan C source files for DID global variables
    if args.c_source:
        from udsxml2tex.c_scanner import scan_did_variables

        c_paths = [Path(p) for p in args.c_source]
        try:
            scan_did_variables(
                c_paths,
                spec.dids,
                transitive_depth=getattr(args, "c_scan_depth", 0),
            )
        except Exception as e:
            logging.warning("C source scanning failed: %s", e)

    # --- Apply filters --------------------------------------------------
    _apply_filters(spec, args)

    # --- Validation mode ------------------------------------------------
    if args.validate:
        return _run_validate(spec)

    # --- Diff mode ------------------------------------------------------
    if args.diff:
        return _run_diff(spec, args.diff)

    # --- Dry-run mode: print summary and exit ---------------------------
    if args.dry_run:
        return _print_dry_run_summary(spec, arxml_parser)

    # --- Parse extra_vars -----------------------------------------------
    extra_vars: dict = {}
    for kv in getattr(args, "extra_vars", []):
        if "=" in kv:
            k, _, v = kv.partition("=")
            extra_vars[k.strip()] = v.strip()
        else:
            logging.warning("Ignoring malformed --extra-vars entry: %r", kv)

    # Add i18n translator to extra_vars when lang is specified
    if getattr(args, "lang", "en") != "en" or extra_vars:
        from udsxml2tex.i18n import Translator
        extra_vars.setdefault("_t", Translator(getattr(args, "lang", "en")).t)

    # --- Generate output ------------------------------------------------
    fmt = getattr(args, "format", "tex")
    # Legacy --html flag maps to html format
    if getattr(args, "html", False) and fmt == "tex" and not getattr(args, "pdf", False):
        fmt = "html"

    try:
        tex_gen = TexGenerator(template_dir=args.template_dir)

        if fmt == "tex":
            tex_output = output_path.with_suffix(".tex")
            result = tex_gen.generate(spec, tex_output, template_name=args.template,
                                      extra_vars=extra_vars or None)
            logging.info("LaTeX output written to: %s", result)
            if getattr(args, "pdf", False):
                pdf_path = tex_gen.compile_pdf(result)
                logging.info("PDF output written to: %s", pdf_path)

        elif fmt == "html":
            html_output = output_path.with_suffix(".html")
            tex_gen.generate_html(spec, html_output)
            logging.info("HTML output written to: %s", html_output)

        elif fmt == "md":
            out = output_path.with_suffix(".md")
            tex_gen.generate_markdown(spec, out)
            logging.info("Markdown output written to: %s", out)

        elif fmt == "rst":
            out = output_path.with_suffix(".rst")
            tex_gen.generate_rst(spec, out)
            logging.info("RST output written to: %s", out)

        elif fmt == "csv":
            csv_dir = output_path.parent / (output_path.stem + "_csv")
            files = tex_gen.generate_csv(spec, csv_dir)
            logging.info("CSV output written to: %s (%d file(s))", csv_dir, len(files))

        elif fmt == "yaml":
            out = output_path.with_suffix(".yaml")
            tex_gen.generate_yaml(spec, out)
            logging.info("YAML output written to: %s", out)

        elif fmt == "json":
            out = output_path.with_suffix(".json")
            tex_gen.generate_json(spec, out)
            logging.info("JSON output written to: %s", out)

        elif fmt == "docx":
            out = output_path.with_suffix(".docx")
            tex_gen.generate_docx(spec, out)
            logging.info("DOCX output written to: %s", out)

        # Byte-level DID diagrams
        if getattr(args, "byte_diagrams", None):
            bd_dir = Path(args.byte_diagrams)
            bd_dir.mkdir(parents=True, exist_ok=True)
            bd_path = tex_gen.generate_byte_diagrams(spec, bd_dir)
            logging.info("Byte diagrams written to: %s", bd_path)

        # UML sequence diagrams
        if getattr(args, "sequence_diagrams", None):
            sd_dir = Path(args.sequence_diagrams)
            sd_dir.mkdir(parents=True, exist_ok=True)
            sd_paths = tex_gen.generate_sequence_diagrams(spec, sd_dir)
            logging.info("Sequence diagrams written to: %s (%d file(s))", sd_dir, len(sd_paths))

        # Also generate HTML when --html is set alongside --pdf
        if getattr(args, "html", False) and getattr(args, "pdf", False):
            html_output = output_path.with_suffix(".html")
            tex_gen.generate_html(spec, html_output)
            logging.info("HTML output written to: %s", html_output)

    except FileNotFoundError as e:
        logging.error("%s", e)
        return 1
    except Exception as e:
        logging.error("Failed to generate output: %s", e)
        return 1

    # --- Watch mode (must be last) --------------------------------------
    if getattr(args, "watch", False):
        return _run_watch(args, argv)

    return 0


def _print_dry_run_summary(spec, arxml_parser) -> int:
    """Print a summary of the parsed ARXML data."""
    from udsxml2tex.models import UDS_SERVICE_NAMES

    print(f"\n{'=' * 60}")
    print(f"  udsxml2tex -- Dry Run Summary")
    print(f"{'=' * 60}")
    print(f"  ECU Name:          {spec.ecu_name}")
    print(f"  Protocol:          {spec.protocol_name}")
    if spec.protocol_type:
        print(f"  Protocol Type:     {spec.protocol_type}")
    print(f"  S3 Server Timeout: {spec.s3_server} s")
    print()

    print(f"  Sessions:          {len(spec.sessions)}")
    for s in sorted(spec.sessions, key=lambda x: x.session_id):
        print(f"    0x{s.session_id:02X} - {s.short_name} "
              f"(P2={s.p2_server_max}s, P2*={s.p2_star_server_max}s)")

    print(f"  Security Levels:   {len(spec.security_levels)}")
    for s in sorted(spec.security_levels, key=lambda x: x.security_level):
        print(f"    Level {s.security_level} - {s.short_name} "
              f"(seed={s.seed_size}B, key={s.key_size}B)")

    print(f"  Services:          {len(spec.services)}")
    for s in sorted(spec.services, key=lambda x: x.service_id):
        name = UDS_SERVICE_NAMES.get(s.service_id, s.short_name)
        sf_count = len(s.sub_functions)
        nrc_count = len(s.nrc_list)
        print(f"    0x{s.service_id:02X} - {name} "
              f"({sf_count} sub-functions, {nrc_count} NRCs)")

    print(f"  DIDs:              {len(spec.dids)}")
    print(f"  Routines:          {len(spec.routines)}")
    print(f"  DTCs:              {len(spec.dtcs)}")
    print(f"  Memory Ranges:     {len(spec.memory_ranges)}")
    print(f"  IO Control DIDs:   {len(spec.io_control_dids)}")
    print(f"  Periodic DIDs:     {len(spec.periodic_dids)}")
    print(f"  DID Ranges:        {len(spec.did_ranges)}")
    print(f"  Dynamic DIDs:      {len(spec.dynamic_dids)}")

    if spec.transport_config:
        print(f"  CanTp Channels:    {len(spec.transport_config.channels)}")
        print(f"  CAN-FD:            {'Yes' if spec.transport_config.can_fd_enabled else 'No'}")

    if arxml_parser.warnings:
        print(f"\n  Warnings:          {len(arxml_parser.warnings)}")
        for w in arxml_parser.warnings:
            print(f"    [{w.section}] {w.message}")

    print(f"\n{'=' * 60}")
    return 0


def _apply_filters(spec, args) -> None:
    """Apply --filter-dids / --filter-services / --filter-dtcs to spec in-place."""
    def _parse_ids(s: Optional[str]) -> Optional[set[int]]:
        if not s:
            return None
        ids: set[int] = set()
        for tok in s.split(","):
            tok = tok.strip()
            if tok:
                try:
                    ids.add(int(tok, 0))
                except ValueError:
                    logging.warning("Ignoring invalid ID in filter: %r", tok)
        return ids if ids else None

    did_ids = _parse_ids(getattr(args, "filter_dids", None))
    svc_ids = _parse_ids(getattr(args, "filter_services", None))
    dtc_ids = _parse_ids(getattr(args, "filter_dtcs", None))

    if did_ids is not None:
        spec.dids = [d for d in spec.dids if d.did_id in did_ids]
    if svc_ids is not None:
        spec.services = [s for s in spec.services if s.service_id in svc_ids]
    if dtc_ids is not None:
        spec.dtcs = [d for d in spec.dtcs if d.dtc_id in dtc_ids]


def _run_validate(spec) -> int:
    """Run ISO 14229-1 validation and print results. Returns 1 if errors found."""
    try:
        from udsxml2tex.validator import UdsValidator
    except ImportError:
        logging.error("validator module not available.")
        return 1

    result = UdsValidator().validate(spec)
    print(f"\n{'=' * 60}")
    print(f"  Validation Result: {result.summary()}")
    print(f"{'=' * 60}")
    for issue in result.issues:
        prefix = {"error": "ERROR", "warning": "WARN ", "info": "INFO "}.get(
            issue.severity, issue.severity.upper()
        )
        item = f" [{issue.item_id}]" if issue.item_id else ""
        print(f"  [{prefix}] [{issue.category}]{item} {issue.message}")
    print(f"{'=' * 60}\n")
    return 1 if result.has_errors() else 0


def _run_diff(spec_a, diff_target: str) -> int:
    """Compare spec_a against diff_target (ARXML or JSON) and print diff."""
    try:
        from udsxml2tex.diff import SpecDiffer
    except ImportError:
        logging.error("diff module not available.")
        return 1

    target_path = Path(diff_target)
    if not target_path.exists():
        logging.error("Diff target not found: %s", target_path)
        return 1

    try:
        if target_path.suffix.lower() == ".json":
            from udsxml2tex.models import UdsSpecification
            spec_b = UdsSpecification.load_json(target_path)
        else:
            spec_b = ArxmlParser().parse(target_path)
    except Exception as e:
        logging.error("Failed to load diff target: %s", e)
        return 1

    diff = SpecDiffer().diff(spec_a, spec_b)
    print(diff.to_markdown())
    return 0


def _run_watch(args, argv: Optional[list[str]]) -> int:
    """Watch input files and re-run generation on changes."""
    try:
        from watchdog.observers import Observer  # type: ignore[import]
        from watchdog.events import FileSystemEventHandler  # type: ignore[import]
    except ImportError:
        logging.error(
            "watchdog is required for --watch mode. "
            "Install it with: pip install udsxml2tex[watch]"
        )
        return 1

    import time

    watch_paths = list(args.input)
    if getattr(args, "dem", None):
        watch_paths.append(args.dem)

    logging.info("Watching %d file(s) for changes. Press Ctrl+C to stop.", len(watch_paths))

    class _Handler(FileSystemEventHandler):
        def on_modified(self, event):  # type: ignore[override]
            if event.src_path in watch_paths:
                logging.info("Change detected: %s — regenerating…", event.src_path)
                # Re-run without --watch to avoid recursion
                filtered = [a for a in (argv or sys.argv[1:]) if a != "--watch"]
                main(filtered)

    observer = Observer()
    watched_dirs: set[str] = set()
    for p in watch_paths:
        d = str(Path(p).parent.resolve())
        if d not in watched_dirs:
            observer.schedule(_Handler(), d, recursive=False)
            watched_dirs.add(d)

    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
    return 0


if __name__ == "__main__":
    sys.exit(main())
