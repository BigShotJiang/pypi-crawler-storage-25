# Staso Python SDK

Python SDK for the Staso platform. Decorator-based tracing and automatic data ingestion for AI agent observability.

## Installation

```bash
pip install staso
pip install -e .

```

# Full Flow 

### 1. Develop on feature branch
git checkout -b feat/new-endpoint

### 2. Merge to main via PR
do chagnes & update docs
git checkout main && git merge feat/new-endpoint

### Bump version (auto-creates git tag)
pipx install bump2version
- Patch release: 0.1.0 → 0.1.1
    - bump2version patch
- Minor release: 0.1.1 → 0.2.0
  - bump2version minor
- Major release: 0.2.0 → 1.0.0
  - bump2version major

### Push tag → triggers GitHub Actions → publishes to PyPI
git push origin main --tags

### Claude Code Config
### PROD
"STASO_API_KEY": "ak_1b64f413d566461c9cc2315ea459ba59",
"STASO_ENVIRONMENT": "mayank",
"STASO_WORKSPACE_SLUG": "claude-code",
"STASO_BASE_URL": "https://api.staso.ai",
"STASO_AUTO_SYNC": "1"
"STASO_GUARD_ENABLED": false

"STASO_API_KEY": "ak_1b64f413d566461c9cc2315ea459ba59",
"STASO_ENVIRONMENT": "mayank",
"STASO_WORKSPACE_SLUG": "claude-code",
"STASO_BASE_URL": "https://api.staso.ai",
"STASO_AUTO_SYNC": "1",
"STASO_GUARD_ENABLED": true,
"STASO_AGENT_NAME": "claude-code-global"

### LOCAL
"STASO_API_KEY": "ak_57552068768c4f97b6a09ecf4d6a0211",
"STASO_ENVIRONMENT": "mayank",
"STASO_WORKSPACE_SLUG": "claude-code",
"STASO_BASE_URL": "http://localhost:6999",
"STASO_AUTO_SYNC": "1",
"STASO_GUARD_ENABLED": false,
"STASO_AGENT_NAME": "claude-code-global"