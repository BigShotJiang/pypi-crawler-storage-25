"""taskforeman.config — Configuration dataclasses."""
