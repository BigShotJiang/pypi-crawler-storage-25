"""Unit tests for block parser helpers."""

import pytest

from dotpromptz.blocks import (
    BlockParseError,
    build_image_part,
    is_block_line,
    parse_block_line,
)
from dotpromptz.typing import Role


def test_is_block_line_requires_top_level_prefix() -> None:
    assert is_block_line(':::system')
    assert not is_block_line('  :::system')
    assert not is_block_line('hello')


def test_parse_role_blocks() -> None:
    token = parse_block_line(':::system', 3)
    assert token is not None
    assert token.kind == 'role'
    assert token.role == Role.SYSTEM
    assert token.lineno == 3


def test_parse_image_block() -> None:
    token = parse_block_line(':::image', 10)
    assert token is not None
    assert token.kind == 'image'
    assert token.role is None


def test_parse_block_line_non_block_returns_none() -> None:
    assert parse_block_line('hello', 1) is None


def test_parse_block_line_rejects_inline_args() -> None:
    with pytest.raises(BlockParseError, match='block_bad_format'):
        parse_block_line(':::image foo', 2)


def test_parse_block_line_rejects_unknown_directive() -> None:
    with pytest.raises(BlockParseError, match='block_unknown'):
        parse_block_line(':::foo', 2)


def test_build_image_part_creates_media_part() -> None:
    part = build_image_part('assets/cat.png', 'image/png')
    assert part.media.url == 'assets/cat.png'
    assert part.media.content_type == 'image/png'
