"""Tests for version constants and strict version validation."""

from textwrap import dedent

import pytest

from dotpromptz.errors import PromptVersionError
from dotpromptz.parser import parse_document
from dotpromptz.version import CURRENT_MAJOR


def test_current_major_is_positive_int() -> None:
    assert isinstance(CURRENT_MAJOR, int)
    assert CURRENT_MAJOR >= 1


def test_parse_document_accepts_matching_version() -> None:
    source = dedent(
        f"""
        ---
        version: {CURRENT_MAJOR}
        ---
        :::user
        hello
        """
    ).strip()
    parsed = parse_document(source)
    assert parsed.version == CURRENT_MAJOR


def test_parse_document_rejects_higher_version() -> None:
    source = dedent(
        f"""
        ---
        version: {CURRENT_MAJOR + 1}
        ---
        :::user
        hello
        """
    ).strip()
    with pytest.raises(PromptVersionError):
        parse_document(source)


def test_parse_document_rejects_lower_version() -> None:
    source = dedent(
        f"""
        ---
        version: {max(CURRENT_MAJOR - 1, 0)}
        ---
        :::user
        hello
        """
    ).strip()
    if CURRENT_MAJOR == 0:
        pytest.skip('CURRENT_MAJOR is zero; lower-version test is not applicable.')
    with pytest.raises(PromptVersionError):
        parse_document(source)
