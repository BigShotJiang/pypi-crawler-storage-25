# `output.schema.fixed` 示例

当你希望输出文件内容不是由 AI 生成，而是直接写入一份固定数据，同时仍然复用 `output.schema` 做校验时，可以使用包装写法：

```prompt
---
version: 1
output:
  format: json
  file_name: result
  schema:
    data:
      type: object
      properties:
        name:
          type: string
        age:
          type: integer
      required: [name, age]
      additionalProperties: false
    fixed:
      name: Alice
      age: 18
---
:::user
这段内容不会发送给模型。
```

运行后会直接写出 `result.json`：

```json
{
  "name": "Alice",
  "age": 18
}
```

也支持在 `fixed` 里使用模板变量：

```prompt
---
version: 1
output:
  format: yaml
  file_name: profile
  schema:
    data:
      type: object
      properties:
        user:
          type: string
        role:
          type: string
      required: [user, role]
    fixed:
      user: '{{ username }}'
      role: reviewer
input:
  data:
    username: alice
---
:::user
同样不会调用模型。
```

说明：

- `schema.data` 是原本的 JSON Schema
- `schema.fixed` 是最终要直接输出的数据
- `schema.fixed` 仅支持 `json` / `yaml`
- 写出前仍会按 `schema.data` 校验；校验失败会直接报错
- 同一个批次里不能混用一部分 `fixed`、一部分 AI 生成输出
