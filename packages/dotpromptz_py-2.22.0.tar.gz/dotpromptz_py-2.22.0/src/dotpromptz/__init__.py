"""dotpromptz: parsing, rendering, and execution for ``.prompt`` files."""

from .compiler import CompiledPrompt, compile_prompt, render_compiled_prompt, render_prompt
from .credentials import Credential, CredentialPool, load_credentials
from .errors import (
    DotpromptzError,
    ExecutionConfigError,
    FrontmatterMissingError,
    FrontmatterUnterminatedError,
    FrontmatterValidationError,
    GhCliError,
    GitError,
    InputResolutionError,
    InputVariableError,
    InputVariableNamingError,
    MessageBlockParseError,
    PromptParseError,
    PromptVersionError,
    TemplateMissingVariableError,
    TemplateVariableNamingError,
    WorkflowError,
)
from .executor import ExecutionReport, execute_plan
from .inputs import infer_schema, infer_schema_from_example, resolve_files, resolve_input
from .logging import configure_logging
from .planner import ExecutionPlan, ExecutionPlanItem, plan_prompt
from .service import BuildReport, RunReport, build_prompt, run_prompt
from .version import CURRENT_MAJOR

__all__ = [
    'BuildReport',
    'CompiledPrompt',
    'CURRENT_MAJOR',
    'Credential',
    'CredentialPool',
    'DotpromptzError',
    'ExecutionPlan',
    'ExecutionPlanItem',
    'ExecutionConfigError',
    'ExecutionReport',
    'FrontmatterMissingError',
    'FrontmatterUnterminatedError',
    'FrontmatterValidationError',
    'GhCliError',
    'GitError',
    'InputResolutionError',
    'InputVariableError',
    'InputVariableNamingError',
    'MessageBlockParseError',
    'PromptParseError',
    'PromptVersionError',
    'RunReport',
    'TemplateMissingVariableError',
    'TemplateVariableNamingError',
    'WorkflowError',
    'build_prompt',
    'compile_prompt',
    'configure_logging',
    'execute_plan',
    'infer_schema',
    'infer_schema_from_example',
    'load_credentials',
    'plan_prompt',
    'render_compiled_prompt',
    'render_prompt',
    'resolve_files',
    'resolve_input',
    'run_prompt',
]
