"""Engine version constants."""

from dotpromptz.errors import PromptVersionError

CURRENT_MAJOR: int = 2
"""Current major version for prompt format validation."""

__all__ = ['CURRENT_MAJOR', 'PromptVersionError']
