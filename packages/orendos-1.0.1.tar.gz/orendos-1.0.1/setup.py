# dev by mero tg @QP4RM
import os
import sys
from setuptools import setup, Extension, find_packages

core_sources = [
    "src/core/orendos_core.c",
    "src/core/engine.c",
    "src/core/algorithms.c",
    "src/core/vm.c",
    "src/core/shield.c",
    "src/core/entropy.c",
]

extra_compile_args = []
extra_link_args = []

if sys.platform == "win32":
    extra_compile_args = ["/O2", "/W3"]
elif sys.platform == "darwin":
    extra_compile_args = ["-O3", "-Wall", "-Wextra", "-std=c11"]
else:
    extra_compile_args = ["-O3", "-Wall", "-Wextra", "-std=c11", "-fPIC"]

orendos_core = Extension(
    "_orendos_core",
    sources=core_sources,
    include_dirs=["src/core"],
    extra_compile_args=extra_compile_args,
    extra_link_args=extra_link_args,
)

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="orendos",
    version="1.0.1",
    author="MERO",
    description="Deep algorithmic code protection for Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/6x-u/orendos",
    packages=find_packages(),
    ext_modules=[orendos_core],
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "orendos=orendos.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: C",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Security",
        "Topic :: Software Development :: Code Generators",
    ],
)
