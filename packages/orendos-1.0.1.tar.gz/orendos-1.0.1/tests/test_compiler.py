# dev by mero tg @QP4RM
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from orendos.compiler import compile_source, compile_file, CompilerError, ORO_FILE_MAGIC


class TestCompiler(unittest.TestCase):
    def test_compile_simple(self):
        source = 'print("hello")'
        result = compile_source(source)
        self.assertIsInstance(result, bytes)
        self.assertTrue(len(result) > 0)

    def test_compile_starts_with_magic(self):
        source = 'x = 1 + 2'
        result = compile_source(source)
        self.assertTrue(result[:6] == ORO_FILE_MAGIC)

    def test_compile_different_entropy(self):
        source = 'print("test")'
        result1 = compile_source(source)
        result2 = compile_source(source)
        self.assertNotEqual(result1, result2)

    def test_compile_syntax_error(self):
        source = 'def foo(:'
        with self.assertRaises(CompilerError):
            compile_source(source)

    def test_compile_file_single_output(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py",
                                          delete=False, dir="/tmp") as f:
            f.write('print("file test")\n')
            f.flush()
            temp_path = f.name

        try:
            protected_path = compile_file(temp_path)
            self.assertTrue(os.path.isfile(protected_path))
            self.assertTrue(protected_path.endswith("_me.py"))

            with open(protected_path, "r") as wf:
                content = wf.read()
                self.assertIn("import orendos as mero", content)
                self.assertIn("mero(", content)
                only_lol = True
                start = content.index('mero("') + 6
                end = content.index('")', start)
                lol_data = content[start:end]
                for ch in lol_data:
                    if ch not in ("l", "o"):
                        only_lol = False
                self.assertTrue(only_lol)
        finally:
            os.unlink(temp_path)
            if os.path.exists(protected_path):
                os.unlink(protected_path)

    def test_compile_complex_source(self):
        source = '''
import json
class Foo:
    def __init__(self):
        self.x = 42
    def bar(self):
        return json.dumps({"x": self.x})
f = Foo()
print(f.bar())
'''
        result = compile_source(source)
        self.assertIsInstance(result, bytes)
        self.assertTrue(len(result) > 100)

    def test_compile_file_not_found(self):
        with self.assertRaises(CompilerError):
            compile_file("/nonexistent/file.py")

    def test_embedded_content_not_readable(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py",
                                          delete=False, dir="/tmp") as f:
            f.write('secret = "this_is_secret_data"\nprint(secret)\n')
            f.flush()
            temp_path = f.name

        try:
            protected_path = compile_file(temp_path)
            with open(protected_path, "r") as wf:
                content = wf.read()
                self.assertNotIn("this_is_secret_data", content)
                self.assertNotIn("secret", content.split("mero(")[0].split("\n", 1)[1])
        finally:
            os.unlink(temp_path)
            if os.path.exists(protected_path):
                os.unlink(protected_path)

    def test_lol_encoding_valid_python(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py",
                                          delete=False, dir="/tmp") as f:
            f.write('print("syntax test")\n')
            f.flush()
            temp_path = f.name

        try:
            protected_path = compile_file(temp_path)
            with open(protected_path, "r") as wf:
                content = wf.read()
            compile(content, protected_path, "exec")
        finally:
            os.unlink(temp_path)
            if os.path.exists(protected_path):
                os.unlink(protected_path)


if __name__ == "__main__":
    unittest.main()
