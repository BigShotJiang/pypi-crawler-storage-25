# dev by mero tg @QP4RM
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from orendos.compiler import compile_source, compile_file
from orendos.runtime import OrendosRuntime, execute_oro
from orendos.runtime import RuntimeError as OroRuntimeError


class TestRuntime(unittest.TestCase):
    def test_load_invalid_data(self):
        runtime = OrendosRuntime()
        with self.assertRaises(OroRuntimeError):
            runtime.load_data(b"invalid data here")

    def test_load_too_small(self):
        runtime = OrendosRuntime()
        with self.assertRaises(OroRuntimeError):
            runtime.load_data(b"\x00\x01")

    def test_execute_without_load(self):
        runtime = OrendosRuntime()
        with self.assertRaises(OroRuntimeError):
            runtime.execute()

    def test_compile_and_load(self):
        source = 'x = 42'
        compiled = compile_source(source)
        runtime = OrendosRuntime()
        result = runtime.load_data(compiled)
        self.assertTrue(result)

    def test_compile_and_execute(self):
        source = 'x = 42\ny = 58\nresult = x + y'
        compiled = compile_source(source)

        with tempfile.NamedTemporaryFile(suffix=".oro", delete=False, dir="/tmp") as f:
            f.write(compiled)
            temp_path = f.name

        try:
            global_vars = {}
            result = execute_oro(temp_path, global_vars)
            self.assertEqual(result["x"], 42)
            self.assertEqual(result["result"], 100)
        finally:
            os.unlink(temp_path)

    def test_compile_and_execute_print(self):
        source = 'import sys\nprint("orendos test output")'
        compiled = compile_source(source)

        with tempfile.NamedTemporaryFile(suffix=".oro", delete=False, dir="/tmp") as f:
            f.write(compiled)
            temp_path = f.name

        try:
            execute_oro(temp_path)
        finally:
            os.unlink(temp_path)

    def test_file_not_found(self):
        with self.assertRaises(OroRuntimeError):
            execute_oro("/nonexistent/file.oro")

    def test_tampered_file(self):
        source = 'x = 1'
        compiled = compile_source(source)
        tampered = bytearray(compiled)
        if len(tampered) > 25:
            tampered[25] ^= 0xFF
        runtime = OrendosRuntime()
        with self.assertRaises(OroRuntimeError):
            runtime.load_data(bytes(tampered))

    def test_protected_py_execution(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py",
                                          delete=False, dir="/tmp") as f:
            f.write('x = 42\ny = 58\nresult = x + y\n')
            f.flush()
            temp_path = f.name

        try:
            protected_path = compile_file(temp_path)
            global_vars = {}
            execute_oro(protected_path, global_vars)
            self.assertEqual(global_vars["result"], 100)
        finally:
            os.unlink(temp_path)
            if os.path.exists(protected_path):
                os.unlink(protected_path)


if __name__ == "__main__":
    unittest.main()
