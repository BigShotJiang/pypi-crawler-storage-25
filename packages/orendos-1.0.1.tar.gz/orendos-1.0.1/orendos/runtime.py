# dev by mero tg @QP4RM
import marshal
import struct
import sys
import os
import types
import hashlib

try:
    import _orendos_core
except ImportError:
    _orendos_core = None

ORO_FILE_MAGIC = b"\x4f\x52\x4e\x44\x4f\x53"
ORO_FORMAT_VERSION = 1


class RuntimeError(Exception):
    pass


def _lol_to_bytes(lol_str):
    clean = ""
    for ch in lol_str:
        if ch in ("l", "o"):
            clean += ch
    if len(clean) % 8 != 0:
        raise ValueError("invalid lol data length")
    result = bytearray()
    for i in range(0, len(clean), 8):
        byte_val = 0
        for j in range(8):
            if clean[i + j] == "o":
                byte_val |= (1 << (7 - j))
        result.append(byte_val)
    return bytes(result)


class OrendosRuntime:
    def __init__(self):
        self._loaded = False
        self._oro_data = None
        self._entropy_seed = None

    def _verify_environment(self):
        if _orendos_core:
            result = _orendos_core.shield_check()
            if result != 0:
                raise RuntimeError("environment integrity check failed")

    def load_file(self, path):
        if not os.path.isfile(path):
            raise RuntimeError(f"file not found: {path}")

        with open(path, "rb") as f:
            raw = f.read()

        magic = raw[:6]
        if magic == ORO_FILE_MAGIC:
            return self.load_data(raw)

        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            return self.load_data(raw)

        return self.load_protected_py(text, path)

    def load_protected_py(self, text, path=None):
        lines = text.strip().split("\n")
        has_import = False
        lol_content = None

        for line in lines:
            stripped = line.strip()
            if stripped.startswith("import orendos as mero"):
                has_import = True
                continue
            if has_import and stripped.startswith("mero("):
                start = stripped.index("(") + 1
                end = stripped.rindex(")")
                inner = stripped[start:end].strip()
                if inner.startswith('"') and inner.endswith('"'):
                    lol_content = inner[1:-1]
                elif inner.startswith("'") and inner.endswith("'"):
                    lol_content = inner[1:-1]
                else:
                    lol_content = inner
                break

        if not has_import or not lol_content:
            raise RuntimeError("not a valid orendos protected file")

        try:
            oro_data = _lol_to_bytes(lol_content)
        except Exception:
            raise RuntimeError("failed to decode embedded content")

        return self.load_data(oro_data)

    def load_data(self, data):
        if len(data) < 19:
            raise RuntimeError("invalid .oro file: too small")

        magic = data[:6]
        if magic != ORO_FILE_MAGIC:
            raise RuntimeError("invalid .oro file: bad magic")

        version = data[6]
        if version != ORO_FORMAT_VERSION:
            raise RuntimeError(f"unsupported format version: {version}")

        self._entropy_seed = struct.unpack("<Q", data[7:15])[0]
        payload_len = struct.unpack("<I", data[15:19])[0]

        if len(data) < 19 + payload_len + 16:
            raise RuntimeError("invalid .oro file: truncated")

        stored_checksum = data[19 + payload_len:19 + payload_len + 16]
        computed_checksum = hashlib.sha256(data[:19 + payload_len]).digest()[:16]

        if stored_checksum != computed_checksum:
            raise RuntimeError("integrity check failed: file corrupted or tampered")

        self._oro_data = data[19:19 + payload_len]
        self._loaded = True
        return True

    def execute(self, global_vars=None):
        if not self._loaded:
            raise RuntimeError("no .oro file loaded")

        self._verify_environment()

        marshaled = self._recover_code(self._oro_data, self._entropy_seed)
        if marshaled is None:
            raise RuntimeError("code recovery failed")

        try:
            code = marshal.loads(marshaled)
        except Exception:
            raise RuntimeError("code materialization failed")
        finally:
            if _orendos_core:
                try:
                    _orendos_core.wipe_bytes(bytearray(marshaled))
                except Exception:
                    pass

        if global_vars is None:
            global_vars = {"__name__": "__main__", "__builtins__": __builtins__}

        exec(code, global_vars)
        return global_vars

    def _recover_code(self, data, entropy_seed):
        if _orendos_core:
            try:
                return _orendos_core.load_compiled(data, entropy_seed)
            except Exception:
                return self._fallback_recover(data, entropy_seed)
        return self._fallback_recover(data, entropy_seed)

    def _fallback_recover(self, data, seed):
        header_size = 6 + 1 + 8 + 4
        if len(data) < header_size:
            return self._fallback_recover_raw(data, seed)
        magic = data[:6]
        if magic == ORO_FILE_MAGIC:
            payload_len = struct.unpack("<I", data[15:19])[0]
            enc_data = data[19:19 + payload_len]
            return self._fallback_recover_raw(enc_data, seed)
        return self._fallback_recover_raw(data, seed)

    def _fallback_recover_raw(self, data, seed):
        key = struct.pack("Q", seed)
        h = hashlib.sha256(key).digest()
        result = bytearray(len(data))
        for i in range(len(data)):
            val = data[i] ^ h[i % len(h)]
            result[i] = val
            h = hashlib.sha256(bytes(h) + bytes([val])).digest()
        return bytes(result)


def execute_oro(path, global_vars=None):
    runtime = OrendosRuntime()
    runtime.load_file(path)
    return runtime.execute(global_vars)


def execute_lol(lol_data, global_vars=None):
    runtime = OrendosRuntime()
    oro_data = _lol_to_bytes(lol_data)
    runtime.load_data(oro_data)
    return runtime.execute(global_vars)


class _MeroModule(types.ModuleType):
    def __init__(self, wrapped):
        super().__init__(wrapped.__name__)
        self._wrapped = wrapped
        self.__dict__.update(wrapped.__dict__)

    def __call__(self, lol_data):
        execute_lol(lol_data)

    def __getattr__(self, name):
        return getattr(self._wrapped, name)


def _install_callable_module():
    import orendos
    if not isinstance(sys.modules["orendos"], _MeroModule):
        sys.modules["orendos"] = _MeroModule(orendos)
