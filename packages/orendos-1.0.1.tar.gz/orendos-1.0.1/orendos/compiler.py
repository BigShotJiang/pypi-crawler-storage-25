# dev by mero tg @QP4RM
import ast
import marshal
import struct
import sys
import os
import time
import hashlib

try:
    import _orendos_core
except ImportError:
    _orendos_core = None

ORO_FILE_MAGIC = b"\x4f\x52\x4e\x44\x4f\x53"
ORO_FORMAT_VERSION = 1


class CompilerError(Exception):
    pass


def _bytes_to_lol(data):
    parts = []
    for b in data:
        for bit in range(7, -1, -1):
            if (b >> bit) & 1:
                parts.append("o")
            else:
                parts.append("l")
    return "".join(parts)


def _lol_to_bytes(lol_str):
    if len(lol_str) % 8 != 0:
        raise ValueError("invalid lol data length")
    result = bytearray()
    for i in range(0, len(lol_str), 8):
        byte_val = 0
        for j in range(8):
            ch = lol_str[i + j]
            if ch == "o":
                byte_val |= (1 << (7 - j))
            elif ch != "l":
                raise ValueError("invalid lol data")
        result.append(byte_val)
    return bytes(result)


class OrendosCompiler:
    def __init__(self):
        self._entropy_seed = None
        self._compiled_data = None

    def _get_entropy(self):
        if _orendos_core:
            return _orendos_core.get_entropy_seed()
        raw = struct.unpack("Q", os.urandom(8))[0]
        raw ^= int(time.time() * 1000000) & 0xFFFFFFFFFFFFFFFF
        return raw

    def _validate_source(self, source):
        try:
            ast.parse(source)
        except SyntaxError as e:
            raise CompilerError(f"syntax error in source: {e}")

    def _prepare_code(self, source, filename="<orendos>"):
        code = compile(source, filename, "exec")
        return code

    def _marshal_code(self, code):
        return marshal.dumps(code)

    def _apply_deep_transform(self, marshaled, entropy_seed):
        if _orendos_core:
            return _orendos_core.compile_source(marshaled, entropy_seed)
        return self._fallback_transform(marshaled, entropy_seed)

    def _fallback_transform(self, data, seed):
        import struct as st
        key = st.pack("Q", seed)
        h = hashlib.sha256(key).digest()
        result = bytearray(len(data))
        for i in range(len(data)):
            result[i] = data[i] ^ h[i % len(h)]
            h = hashlib.sha256(bytes(h) + bytes([data[i]])).digest()
        header = ORO_FILE_MAGIC
        header += st.pack("<BQ", ORO_FORMAT_VERSION, seed)
        header += st.pack("<I", len(data))
        checksum = hashlib.sha256(bytes(result)).digest()[:16]
        header += checksum
        return bytes(header) + bytes(result)

    def compile(self, source, filename="<orendos>"):
        self._validate_source(source)
        self._entropy_seed = self._get_entropy()
        code = self._prepare_code(source, filename)
        marshaled = self._marshal_code(code)
        self._compiled_data = self._apply_deep_transform(
            marshaled, self._entropy_seed
        )
        return self._compiled_data, self._entropy_seed

    def build_oro_file(self, source, filename="<orendos>"):
        compiled_data, entropy_seed = self.compile(source, filename)
        file_content = bytearray()
        file_content.extend(ORO_FILE_MAGIC)
        file_content.extend(struct.pack("<B", ORO_FORMAT_VERSION))
        file_content.extend(struct.pack("<Q", entropy_seed))
        file_content.extend(struct.pack("<I", len(compiled_data)))
        file_content.extend(compiled_data)
        checksum = hashlib.sha256(bytes(file_content)).digest()[:16]
        file_content.extend(checksum)
        return bytes(file_content)

    def build_embedded(self, source, filename="<orendos>"):
        oro_data = self.build_oro_file(source, filename)
        lol_str = _bytes_to_lol(oro_data)
        return lol_str


def compile_source(source, filename="<orendos>"):
    compiler = OrendosCompiler()
    return compiler.build_oro_file(source, filename)


def compile_file(input_path, output_path=None):
    if not os.path.isfile(input_path):
        raise CompilerError(f"file not found: {input_path}")

    with open(input_path, "r", encoding="utf-8") as f:
        source = f.read()

    compiler = OrendosCompiler()
    embedded_content = compiler.build_embedded(source, input_path)

    base, _ = os.path.splitext(input_path)
    if output_path is None:
        output_path = base + "_me.py"

    protected = "import orendos as mero\n"
    protected += "mero(\"" + embedded_content + "\")\n"

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(protected)

    return output_path
