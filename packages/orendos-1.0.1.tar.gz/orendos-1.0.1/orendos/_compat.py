# dev by mero tg @QP4RM
import sys
import platform

SUPPORTED_PLATFORMS = ("linux", "win32", "darwin", "android")

def get_platform():
    p = sys.platform
    if hasattr(sys, "getandroidapilevel"):
        return "android"
    return p

def get_version():
    try:
        from orendos import __version__
        return __version__
    except ImportError:
        return "1.0.0"

def check_platform():
    p = get_platform()
    for sp in SUPPORTED_PLATFORMS:
        if p.startswith(sp):
            return True
    return False

def get_arch():
    return platform.machine()

def is_64bit():
    return sys.maxsize > 2**32
