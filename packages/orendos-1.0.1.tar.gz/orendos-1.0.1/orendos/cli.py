# dev by mero tg @QP4RM
import argparse
import sys
import os

from orendos.compiler import compile_file, CompilerError
from orendos.runtime import execute_oro, RuntimeError as OroRuntimeError


def cmd_compile(args):
    input_path = args.input
    output_path = args.output

    if not os.path.isfile(input_path):
        print(f"[orendos] error: file not found: {input_path}")
        return 1

    try:
        protected_path = compile_file(input_path, output_path)
        print(f"[orendos] done save")
        print(f"[orendos] protected: {protected_path}")
        return 0
    except CompilerError as e:
        print(f"[orendos] compile error: {e}")
        return 1


def cmd_run(args):
    input_path = args.input

    if not os.path.isfile(input_path):
        print(f"[orendos] error: file not found: {input_path}")
        return 1

    try:
        execute_oro(input_path)
        return 0
    except OroRuntimeError as e:
        print(f"[orendos] runtime error: {e}")
        return 1


def cmd_info(args):
    from orendos import __version__
    print(f"orendos v{__version__}")
    print(f"dev by mero tg @QP4RM")
    print(f"python: {sys.version}")
    print(f"platform: {sys.platform}")

    try:
        import _orendos_core
        print(f"native core: loaded (v{_orendos_core.get_version()})")
        shield = _orendos_core.shield_check()
        status = "ok" if shield == 0 else f"warning (code: {shield})"
        print(f"shield: {status}")
    except ImportError:
        print("native core: fallback mode")


def main():
    parser = argparse.ArgumentParser(
        prog="orendos",
        description="orendos - deep algorithmic code protection"
    )
    subparsers = parser.add_subparsers(dest="command")

    p_compile = subparsers.add_parser("compile", help="compile Python source to protected file")
    p_compile.add_argument("input", help="input Python file path")
    p_compile.add_argument("-o", "--output", default=None, help="output protected file path")

    p_run = subparsers.add_parser("run", help="execute protected file")
    p_run.add_argument("input", help="input file path (.py protected or .oro)")

    subparsers.add_parser("info", help="show orendos information")

    args = parser.parse_args()

    if args.command == "compile":
        sys.exit(cmd_compile(args))
    elif args.command == "run":
        sys.exit(cmd_run(args))
    elif args.command == "info":
        cmd_info(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
