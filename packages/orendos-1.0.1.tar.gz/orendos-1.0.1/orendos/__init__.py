# dev by mero tg @QP4RM
from orendos.compiler import compile_file, compile_source
from orendos.runtime import execute_oro, OrendosRuntime, _install_callable_module
from orendos._compat import get_version

__version__ = "1.0.1"
__author__ = "MERO"

__all__ = [
    "compile_file",
    "compile_source",
    "execute_oro",
    "OrendosRuntime",
    "get_version",
]

_install_callable_module()
