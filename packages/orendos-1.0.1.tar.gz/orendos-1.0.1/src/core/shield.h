// dev by mero tg @QP4RM
#ifndef ORENDOS_SHIELD_H
#define ORENDOS_SHIELD_H

#include <stdint.h>
#include <stddef.h>

#define ORO_SHIELD_OK           0
#define ORO_SHIELD_DEBUGGER     1
#define ORO_SHIELD_TAMPERED     2
#define ORO_SHIELD_TIMING       3
#define ORO_SHIELD_ENV          4

int  oro_shield_check_debugger(void);
int  oro_shield_check_integrity(const uint8_t *module_data, size_t size,
                                const uint8_t expected[16]);
int  oro_shield_timing_check(void);
int  oro_shield_full_check(void);
void oro_shield_wipe_memory(void *ptr, size_t size);
int  oro_shield_verify_copyright(const uint8_t *data, size_t size);

#endif
