// dev by mero tg @QP4RM
#ifndef ORENDOS_ALGORITHMS_H
#define ORENDOS_ALGORITHMS_H

#include <stdint.h>
#include <stddef.h>

#define ORO_FEISTEL_ROUNDS  16
#define ORO_FEISTEL_BLOCK   16
#define ORO_SBOX_SIZE       256
#define ORO_PERM_SIZE       256
#define ORO_KEY_SIZE        32
#define ORO_SCATTER_CHUNKS  8

typedef struct {
    uint8_t  sbox[ORO_SBOX_SIZE];
    uint8_t  inv_sbox[ORO_SBOX_SIZE];
    uint8_t  perm_table[ORO_PERM_SIZE];
    uint8_t  inv_perm_table[ORO_PERM_SIZE];
    uint8_t  round_keys[ORO_FEISTEL_ROUNDS][ORO_KEY_SIZE];
    uint64_t stream_state[2];
} oro_cipher_ctx_t;

int  oro_cipher_init(oro_cipher_ctx_t *ctx, uint64_t seed);
void oro_cipher_free(oro_cipher_ctx_t *ctx);

int  oro_feistel_encrypt(oro_cipher_ctx_t *ctx,
                         const uint8_t *in, size_t in_len,
                         uint8_t **out, size_t *out_len);
int  oro_feistel_decrypt(oro_cipher_ctx_t *ctx,
                         const uint8_t *in, size_t in_len,
                         uint8_t **out, size_t *out_len);

void oro_permute(oro_cipher_ctx_t *ctx, uint8_t *data, size_t len);
void oro_unpermute(oro_cipher_ctx_t *ctx, uint8_t *data, size_t len);

void oro_xor_stream(oro_cipher_ctx_t *ctx, uint8_t *data, size_t len);
void oro_xor_stream_reset(oro_cipher_ctx_t *ctx, uint64_t seed);

int  oro_scatter(oro_cipher_ctx_t *ctx,
                 const uint8_t *in, size_t in_len,
                 uint8_t **out, size_t *out_len);
int  oro_gather(oro_cipher_ctx_t *ctx,
                const uint8_t *in, size_t in_len,
                uint8_t **out, size_t *out_len);

void oro_derive_key(uint64_t seed, uint8_t key[ORO_KEY_SIZE]);

#endif
