// dev by mero tg @QP4RM
#include "algorithms.h"
#include "entropy.h"
#include <stdlib.h>
#include <string.h>

static void generate_sbox(oro_entropy_t *ent, uint8_t sbox[ORO_SBOX_SIZE]) {
    oro_entropy_permutation(ent, sbox, ORO_SBOX_SIZE);
}

static void invert_sbox(const uint8_t sbox[ORO_SBOX_SIZE], uint8_t inv[ORO_SBOX_SIZE]) {
    oro_entropy_inverse_permutation(sbox, inv, ORO_SBOX_SIZE);
}

int oro_cipher_init(oro_cipher_ctx_t *ctx, uint64_t seed) {
    if (!ctx) return -1;
    memset(ctx, 0, sizeof(oro_cipher_ctx_t));

    oro_entropy_t ent;
    oro_entropy_init(&ent, seed);

    generate_sbox(&ent, ctx->sbox);
    invert_sbox(ctx->sbox, ctx->inv_sbox);

    oro_entropy_permutation(&ent, ctx->perm_table, ORO_PERM_SIZE);
    oro_entropy_inverse_permutation(ctx->perm_table, ctx->inv_perm_table, ORO_PERM_SIZE);

    for (int r = 0; r < ORO_FEISTEL_ROUNDS; r++)
        oro_entropy_fill(&ent, ctx->round_keys[r], ORO_KEY_SIZE);

    ctx->stream_state[0] = oro_entropy_next(&ent);
    ctx->stream_state[1] = oro_entropy_next(&ent);

    return 0;
}

void oro_cipher_free(oro_cipher_ctx_t *ctx) {
    if (ctx) {
        volatile uint8_t *p = (volatile uint8_t *)ctx;
        for (size_t i = 0; i < sizeof(oro_cipher_ctx_t); i++)
            p[i] = 0;
    }
}

static void feistel_round_func(const uint8_t *half, const uint8_t *key,
                                const uint8_t sbox[ORO_SBOX_SIZE],
                                uint8_t *out, size_t half_len) {
    for (size_t i = 0; i < half_len; i++) {
        uint8_t val = half[i] ^ key[i % ORO_KEY_SIZE];
        val = sbox[val];
        val = (val << 3) | (val >> 5);
        val ^= key[(i + 7) % ORO_KEY_SIZE];
        val = sbox[val];
        out[i] = val;
    }
}

static size_t pad_size(size_t len) {
    size_t block = ORO_FEISTEL_BLOCK;
    size_t padded = ((len + block - 1) / block) * block;
    if (padded < block) padded = block;
    return padded;
}

int oro_feistel_encrypt(oro_cipher_ctx_t *ctx,
                        const uint8_t *in, size_t in_len,
                        uint8_t **out, size_t *out_len) {
    if (!ctx || !in || !out || !out_len) return -1;

    size_t padded = pad_size(in_len);
    size_t total = padded + 4;
    uint8_t *buf = (uint8_t *)calloc(total, 1);
    if (!buf) return -1;

    buf[0] = (uint8_t)(in_len & 0xFF);
    buf[1] = (uint8_t)((in_len >> 8) & 0xFF);
    buf[2] = (uint8_t)((in_len >> 16) & 0xFF);
    buf[3] = (uint8_t)((in_len >> 24) & 0xFF);
    memcpy(buf + 4, in, in_len);

    size_t work_size = total;
    size_t half = work_size / 2;
    uint8_t *left = buf;
    uint8_t *right = buf + half;
    uint8_t *tmp = (uint8_t *)malloc(half);
    if (!tmp) { free(buf); return -1; }

    for (int r = 0; r < ORO_FEISTEL_ROUNDS; r++) {
        feistel_round_func(right, ctx->round_keys[r], ctx->sbox, tmp, half);
        for (size_t i = 0; i < half; i++)
            left[i] ^= tmp[i];
        if (r < ORO_FEISTEL_ROUNDS - 1) {
            uint8_t *swap = (uint8_t *)malloc(half);
            if (!swap) { free(tmp); free(buf); return -1; }
            memcpy(swap, left, half);
            memcpy(left, right, half);
            memcpy(right, swap, half);
            free(swap);
        }
    }

    free(tmp);
    *out = buf;
    *out_len = total;
    return 0;
}

int oro_feistel_decrypt(oro_cipher_ctx_t *ctx,
                        const uint8_t *in, size_t in_len,
                        uint8_t **out, size_t *out_len) {
    if (!ctx || !in || !out || !out_len) return -1;
    if (in_len < ORO_FEISTEL_BLOCK) return -1;

    uint8_t *buf = (uint8_t *)malloc(in_len);
    if (!buf) return -1;
    memcpy(buf, in, in_len);

    size_t half = in_len / 2;
    uint8_t *left = buf;
    uint8_t *right = buf + half;
    uint8_t *tmp = (uint8_t *)malloc(half);
    if (!tmp) { free(buf); return -1; }

    for (int r = ORO_FEISTEL_ROUNDS - 1; r >= 0; r--) {
        if (r < ORO_FEISTEL_ROUNDS - 1) {
            uint8_t *swap = (uint8_t *)malloc(half);
            if (!swap) { free(tmp); free(buf); return -1; }
            memcpy(swap, left, half);
            memcpy(left, right, half);
            memcpy(right, swap, half);
            free(swap);
        }
        feistel_round_func(right, ctx->round_keys[r], ctx->sbox, tmp, half);
        for (size_t i = 0; i < half; i++)
            left[i] ^= tmp[i];
    }

    free(tmp);

    uint32_t orig_len = (uint32_t)buf[0] |
                        ((uint32_t)buf[1] << 8) |
                        ((uint32_t)buf[2] << 16) |
                        ((uint32_t)buf[3] << 24);

    if (orig_len > in_len) {
        free(buf);
        return -1;
    }

    *out = (uint8_t *)malloc(orig_len);
    if (!*out) { free(buf); return -1; }
    memcpy(*out, buf + 4, orig_len);
    *out_len = orig_len;
    free(buf);
    return 0;
}

void oro_permute(oro_cipher_ctx_t *ctx, uint8_t *data, size_t len) {
    for (size_t i = 0; i < len; i++)
        data[i] = ctx->perm_table[data[i]];
}

void oro_unpermute(oro_cipher_ctx_t *ctx, uint8_t *data, size_t len) {
    for (size_t i = 0; i < len; i++)
        data[i] = ctx->inv_perm_table[data[i]];
}

static uint64_t xorshift128plus(uint64_t state[2]) {
    uint64_t s1 = state[0];
    uint64_t s0 = state[1];
    state[0] = s0;
    s1 ^= s1 << 23;
    state[1] = s1 ^ s0 ^ (s1 >> 17) ^ (s0 >> 26);
    return state[1] + s0;
}

void oro_xor_stream(oro_cipher_ctx_t *ctx, uint8_t *data, size_t len) {
    for (size_t i = 0; i < len; i += 8) {
        uint64_t keystream = xorshift128plus(ctx->stream_state);
        size_t chunk = len - i;
        if (chunk > 8) chunk = 8;
        for (size_t j = 0; j < chunk; j++)
            data[i + j] ^= (uint8_t)(keystream >> (j * 8));
    }
}

void oro_xor_stream_reset(oro_cipher_ctx_t *ctx, uint64_t seed) {
    ctx->stream_state[0] = seed ^ 0xDEADBEEFCAFEBABEULL;
    ctx->stream_state[1] = seed ^ 0x0123456789ABCDEFULL;
}

int oro_scatter(oro_cipher_ctx_t *ctx,
                const uint8_t *in, size_t in_len,
                uint8_t **out, size_t *out_len) {
    if (!ctx || !in || !out || !out_len) return -1;

    size_t chunk_size = (in_len + ORO_SCATTER_CHUNKS - 1) / ORO_SCATTER_CHUNKS;
    size_t total = chunk_size * ORO_SCATTER_CHUNKS * 2;
    uint8_t *buf = (uint8_t *)calloc(total + 8, 1);
    if (!buf) return -1;

    buf[0] = (uint8_t)(in_len & 0xFF);
    buf[1] = (uint8_t)((in_len >> 8) & 0xFF);
    buf[2] = (uint8_t)((in_len >> 16) & 0xFF);
    buf[3] = (uint8_t)((in_len >> 24) & 0xFF);
    buf[4] = (uint8_t)(chunk_size & 0xFF);
    buf[5] = (uint8_t)((chunk_size >> 8) & 0xFF);
    buf[6] = (uint8_t)((chunk_size >> 16) & 0xFF);
    buf[7] = (uint8_t)((chunk_size >> 24) & 0xFF);

    oro_entropy_t ent;
    oro_entropy_init(&ent, ctx->stream_state[0]);

    uint8_t order[ORO_SCATTER_CHUNKS];
    for (int i = 0; i < ORO_SCATTER_CHUNKS; i++)
        order[i] = (uint8_t)i;
    for (int i = ORO_SCATTER_CHUNKS - 1; i > 0; i--) {
        int j = (int)(oro_entropy_next(&ent) % (uint64_t)(i + 1));
        uint8_t tmp = order[i];
        order[i] = order[j];
        order[j] = tmp;
    }

    uint8_t *write_ptr = buf + 8;
    for (int i = 0; i < ORO_SCATTER_CHUNKS; i++) {
        int src_idx = order[i];
        size_t src_offset = (size_t)src_idx * chunk_size;
        size_t copy_len = chunk_size;
        if (src_offset + copy_len > in_len)
            copy_len = (src_offset < in_len) ? in_len - src_offset : 0;

        oro_entropy_fill(&ent, write_ptr, chunk_size);
        write_ptr += chunk_size;

        if (copy_len > 0)
            memcpy(write_ptr, in + src_offset, copy_len);
        if (copy_len < chunk_size)
            oro_entropy_fill(&ent, write_ptr + copy_len, chunk_size - copy_len);
        write_ptr += chunk_size;
    }

    *out = buf;
    *out_len = total + 8;
    return 0;
}

int oro_gather(oro_cipher_ctx_t *ctx,
               const uint8_t *in, size_t in_len,
               uint8_t **out, size_t *out_len) {
    if (!ctx || !in || !out || !out_len) return -1;
    if (in_len < 8) return -1;

    uint32_t orig_len = (uint32_t)in[0] |
                        ((uint32_t)in[1] << 8) |
                        ((uint32_t)in[2] << 16) |
                        ((uint32_t)in[3] << 24);
    uint32_t chunk_size = (uint32_t)in[4] |
                          ((uint32_t)in[5] << 8) |
                          ((uint32_t)in[6] << 16) |
                          ((uint32_t)in[7] << 24);

    if (chunk_size == 0 || orig_len > in_len) {
        return -1;
    }

    oro_entropy_t ent;
    oro_entropy_init(&ent, ctx->stream_state[0]);

    uint8_t order[ORO_SCATTER_CHUNKS];
    for (int i = 0; i < ORO_SCATTER_CHUNKS; i++)
        order[i] = (uint8_t)i;
    for (int i = ORO_SCATTER_CHUNKS - 1; i > 0; i--) {
        int j = (int)(oro_entropy_next(&ent) % (uint64_t)(i + 1));
        uint8_t tmp = order[i];
        order[i] = order[j];
        order[j] = tmp;
    }

    uint8_t *result = (uint8_t *)calloc(orig_len, 1);
    if (!result) return -1;

    const uint8_t *read_ptr = in + 8;
    for (int i = 0; i < ORO_SCATTER_CHUNKS; i++) {
        int dst_idx = order[i];
        size_t dst_offset = (size_t)dst_idx * chunk_size;

        read_ptr += chunk_size;

        size_t copy_len = chunk_size;
        if (dst_offset + copy_len > orig_len)
            copy_len = (dst_offset < orig_len) ? orig_len - dst_offset : 0;
        if (copy_len > 0)
            memcpy(result + dst_offset, read_ptr, copy_len);
        read_ptr += chunk_size;
    }

    *out = result;
    *out_len = orig_len;
    return 0;
}

void oro_derive_key(uint64_t seed, uint8_t key[ORO_KEY_SIZE]) {
    oro_entropy_t ent;
    oro_entropy_init(&ent, seed);
    oro_entropy_fill(&ent, key, ORO_KEY_SIZE);
}
