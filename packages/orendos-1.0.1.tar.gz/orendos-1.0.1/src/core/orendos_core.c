// dev by mero tg @QP4RM
#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include "engine.h"
#include "algorithms.h"
#include "vm.h"
#include "shield.h"
#include "entropy.h"
#include <string.h>

static PyObject *OrendosError;

static PyObject *py_compile_source(PyObject *self, PyObject *args) {
    const char *marshaled_data;
    Py_ssize_t marshaled_len;
    unsigned long long entropy_seed;

    if (!PyArg_ParseTuple(args, "y#K", &marshaled_data, &marshaled_len, &entropy_seed))
        return NULL;

    oro_cipher_ctx_t cipher;
    if (oro_cipher_init(&cipher, (uint64_t)entropy_seed) != 0) {
        PyErr_SetString(OrendosError, "cipher initialization failed");
        return NULL;
    }

    uint8_t *encrypted = NULL;
    size_t encrypted_len = 0;
    if (oro_feistel_encrypt(&cipher, (const uint8_t *)marshaled_data,
                            (size_t)marshaled_len,
                            &encrypted, &encrypted_len) != 0) {
        oro_cipher_free(&cipher);
        PyErr_SetString(OrendosError, "feistel encryption failed");
        return NULL;
    }

    uint8_t *scattered = NULL;
    size_t scattered_len = 0;
    if (oro_scatter(&cipher, encrypted, encrypted_len,
                    &scattered, &scattered_len) != 0) {
        oro_shield_wipe_memory(encrypted, encrypted_len);
        free(encrypted);
        oro_cipher_free(&cipher);
        PyErr_SetString(OrendosError, "scatter failed");
        return NULL;
    }
    oro_shield_wipe_memory(encrypted, encrypted_len);
    free(encrypted);

    oro_permute(&cipher, scattered, scattered_len);

    oro_xor_stream_reset(&cipher, (uint64_t)entropy_seed);
    oro_xor_stream(&cipher, scattered, scattered_len);

    oro_container_t container;
    oro_container_init(&container, (uint64_t)entropy_seed);

    if (oro_container_add_section(&container, ORO_SECT_CODE,
                                  scattered, scattered_len) != 0) {
        free(scattered);
        oro_cipher_free(&cipher);
        oro_container_free(&container);
        PyErr_SetString(OrendosError, "add section failed");
        return NULL;
    }

    oro_entropy_t ent;
    oro_entropy_init(&ent, (uint64_t)entropy_seed ^ 0xFF00FF00ULL);
    size_t noise_size = 64 + (oro_entropy_next(&ent) % 256);
    uint8_t *noise = (uint8_t *)malloc(noise_size);
    if (noise) {
        oro_entropy_fill(&ent, noise, noise_size);
        oro_container_add_section(&container, ORO_SECT_NOISE, noise, noise_size);
        free(noise);
    }

    const char *guard_marker = "orendos-v1-protected";
    oro_container_add_section(&container, ORO_SECT_GUARD,
                              (const uint8_t *)guard_marker,
                              strlen(guard_marker));

    free(scattered);

    uint8_t *serialized = NULL;
    size_t serialized_len = 0;
    if (oro_container_serialize(&container, &serialized, &serialized_len) != 0) {
        oro_cipher_free(&cipher);
        oro_container_free(&container);
        PyErr_SetString(OrendosError, "serialization failed");
        return NULL;
    }

    oro_cipher_free(&cipher);
    oro_container_free(&container);

    PyObject *result = PyBytes_FromStringAndSize((const char *)serialized, (Py_ssize_t)serialized_len);
    free(serialized);
    return result;
}

static PyObject *py_load_compiled(PyObject *self, PyObject *args) {
    const char *data;
    Py_ssize_t data_len;
    unsigned long long entropy_seed;

    if (!PyArg_ParseTuple(args, "y#K", &data, &data_len, &entropy_seed))
        return NULL;

    int shield = oro_shield_full_check();
    if (shield != ORO_SHIELD_OK) {
        PyErr_SetString(OrendosError, "environment integrity check failed");
        return NULL;
    }

    oro_vm_t vm;
    oro_vm_init(&vm);

    if (oro_vm_load(&vm, (const uint8_t *)data, (size_t)data_len, (uint64_t)entropy_seed) != 0) {
        oro_vm_destroy(&vm);
        PyErr_SetString(OrendosError, "failed to load compiled data");
        return NULL;
    }

    PyObject *result = PyBytes_FromStringAndSize(
        (const char *)vm.recovered, (Py_ssize_t)vm.recovered_size);

    oro_vm_wipe(&vm);
    oro_vm_destroy(&vm);
    return result;
}

static PyObject *py_get_entropy_seed(PyObject *self, PyObject *args) {
    uint64_t seed = oro_entropy_seed_from_time();
    return PyLong_FromUnsignedLongLong(seed);
}

static PyObject *py_shield_check(PyObject *self, PyObject *args) {
    int result = oro_shield_full_check();
    return PyLong_FromLong(result);
}

static PyObject *py_verify_container(PyObject *self, PyObject *args) {
    const char *data;
    Py_ssize_t data_len;

    if (!PyArg_ParseTuple(args, "y#", &data, &data_len))
        return NULL;

    oro_container_t container;
    int result = oro_container_deserialize(&container, (const uint8_t *)data, (size_t)data_len);
    if (result == 0)
        oro_container_free(&container);

    return PyBool_FromLong(result == 0);
}

static PyObject *py_get_version(PyObject *self, PyObject *args) {
    return Py_BuildValue("s", "1.0.0");
}

static PyObject *py_wipe_bytes(PyObject *self, PyObject *args) {
    Py_buffer buf;
    if (!PyArg_ParseTuple(args, "y*", &buf))
        return NULL;
    oro_shield_wipe_memory(buf.buf, buf.len);
    PyBuffer_Release(&buf);
    Py_RETURN_NONE;
}

static PyMethodDef OrendosMethods[] = {
    {"compile_source", py_compile_source, METH_VARARGS,
     "Compile marshaled Python code into protected .oro format"},
    {"load_compiled", py_load_compiled, METH_VARARGS,
     "Load and recover compiled .oro data"},
    {"get_entropy_seed", py_get_entropy_seed, METH_NOARGS,
     "Generate a new entropy seed"},
    {"shield_check", py_shield_check, METH_NOARGS,
     "Run environment integrity checks"},
    {"verify_container", py_verify_container, METH_VARARGS,
     "Verify .oro container integrity"},
    {"get_version", py_get_version, METH_NOARGS,
     "Get library version"},
    {"wipe_bytes", py_wipe_bytes, METH_VARARGS,
     "Securely wipe bytes from memory"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef orendos_module = {
    PyModuleDef_HEAD_INIT,
    "_orendos_core",
    "orendos native core engine",
    -1,
    OrendosMethods
};

PyMODINIT_FUNC PyInit__orendos_core(void) {
    PyObject *m = PyModule_Create(&orendos_module);
    if (m == NULL) return NULL;

    OrendosError = PyErr_NewException("_orendos_core.OrendosError", NULL, NULL);
    Py_XINCREF(OrendosError);
    if (PyModule_AddObject(m, "OrendosError", OrendosError) < 0) {
        Py_XDECREF(OrendosError);
        Py_CLEAR(OrendosError);
        Py_DECREF(m);
        return NULL;
    }

    return m;
}
