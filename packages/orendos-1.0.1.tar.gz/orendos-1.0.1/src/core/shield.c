// dev by mero tg @QP4RM
#include "shield.h"
#include "entropy.h"
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#elif defined(__linux__)
#include <sys/ptrace.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#elif defined(__APPLE__)
#include <sys/sysctl.h>
#include <unistd.h>
#endif

int oro_shield_check_debugger(void) {
#ifdef _WIN32
    if (IsDebuggerPresent())
        return ORO_SHIELD_DEBUGGER;
#elif defined(__linux__)
    char buf[256];
    int status_fd;
    snprintf(buf, sizeof(buf), "/proc/%d/status", getpid());
    status_fd = open(buf, O_RDONLY);
    if (status_fd >= 0) {
        ssize_t n = read(status_fd, buf, sizeof(buf) - 1);
        close(status_fd);
        if (n > 0) {
            buf[n] = '\0';
            char *tracer = strstr(buf, "TracerPid:");
            if (tracer) {
                tracer += 10;
                while (*tracer == ' ' || *tracer == '\t') tracer++;
                if (*tracer != '0' || (*(tracer+1) >= '0' && *(tracer+1) <= '9'))
                    return ORO_SHIELD_DEBUGGER;
            }
        }
    }
#elif defined(__APPLE__)
    struct kinfo_proc info;
    size_t info_size = sizeof(info);
    int name[4] = { CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid() };
    if (sysctl(name, 4, &info, &info_size, NULL, 0) == 0) {
        if (info.kp_proc.p_flag & P_TRACED)
            return ORO_SHIELD_DEBUGGER;
    }
#endif
    return ORO_SHIELD_OK;
}

int oro_shield_check_integrity(const uint8_t *module_data, size_t size,
                               const uint8_t expected[16]) {
    if (!module_data || !expected) return ORO_SHIELD_TAMPERED;

    uint8_t computed[16];
    uint64_t h0 = 0xCBF29CE484222325ULL;
    uint64_t h1 = 0x100000001B3ULL;

    for (size_t i = 0; i < size; i++) {
        h0 ^= module_data[i];
        h0 *= 0x01000193;
        h1 ^= module_data[i];
        h1 *= 0x00000100000001B3ULL;
        h0 = (h0 << 13) | (h0 >> 51);
        h1 = (h1 << 29) | (h1 >> 35);
    }

    memcpy(computed, &h0, 8);
    memcpy(computed + 8, &h1, 8);

    volatile int diff = 0;
    for (int i = 0; i < 16; i++)
        diff |= computed[i] ^ expected[i];

    return diff ? ORO_SHIELD_TAMPERED : ORO_SHIELD_OK;
}

int oro_shield_timing_check(void) {
    clock_t start = clock();
    volatile int sum = 0;
    for (int i = 0; i < 1000; i++)
        sum += i;
    clock_t end = clock();

    double elapsed = (double)(end - start) / CLOCKS_PER_SEC;
    if (elapsed > 1.0)
        return ORO_SHIELD_TIMING;

    return ORO_SHIELD_OK;
}

int oro_shield_full_check(void) {
    int result = oro_shield_check_debugger();
    if (result != ORO_SHIELD_OK) return result;

    result = oro_shield_timing_check();
    if (result != ORO_SHIELD_OK) return result;

    return ORO_SHIELD_OK;
}

void oro_shield_wipe_memory(void *ptr, size_t size) {
    if (!ptr || size == 0) return;
    volatile uint8_t *p = (volatile uint8_t *)ptr;
    for (size_t i = 0; i < size; i++)
        p[i] = 0;
    __asm__ __volatile__("" ::: "memory");
}

int oro_shield_verify_copyright(const uint8_t *data, size_t size) {
    const char *marker = "orendos";
    size_t marker_len = 7;
    if (size < marker_len) return ORO_SHIELD_TAMPERED;

    for (size_t i = 0; i <= size - marker_len; i++) {
        if (memcmp(data + i, marker, marker_len) == 0)
            return ORO_SHIELD_OK;
    }
    return ORO_SHIELD_TAMPERED;
}
