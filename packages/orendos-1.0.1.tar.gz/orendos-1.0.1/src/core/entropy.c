// dev by mero tg @QP4RM
#include "entropy.h"
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <sys/time.h>
#endif

static uint64_t _oro_seed_counter = 0;

static uint64_t rotl(uint64_t x, int k) {
    return (x << k) | (x >> (64 - k));
}

void oro_entropy_init(oro_entropy_t *ent, uint64_t seed) {
    memset(ent, 0, sizeof(oro_entropy_t));
    ent->state[0] = seed ^ 0x6A09E667F3BCC908ULL;
    ent->state[1] = seed ^ 0xBB67AE8584CAA73BULL;
    ent->state[2] = seed ^ 0x3C6EF372FE94F82BULL;
    ent->state[3] = seed ^ 0xA54FF53A5F1D36F1ULL;
    ent->counter = 0;
    for (int i = 0; i < 20; i++)
        oro_entropy_next(ent);
}

uint64_t oro_entropy_next(oro_entropy_t *ent) {
    uint64_t result = rotl(ent->state[1] * 5, 7) * 9;
    uint64_t t = ent->state[1] << 17;
    ent->state[2] ^= ent->state[0];
    ent->state[3] ^= ent->state[1];
    ent->state[1] ^= ent->state[2];
    ent->state[0] ^= ent->state[3];
    ent->state[2] ^= t;
    ent->state[3] = rotl(ent->state[3], 45);
    ent->counter++;
    return result;
}

uint32_t oro_entropy_next32(oro_entropy_t *ent) {
    return (uint32_t)(oro_entropy_next(ent) >> 32);
}

uint8_t oro_entropy_next8(oro_entropy_t *ent) {
    return (uint8_t)(oro_entropy_next(ent) >> 56);
}

void oro_entropy_fill(oro_entropy_t *ent, uint8_t *buf, size_t len) {
    size_t i = 0;
    while (i < len) {
        uint64_t val = oro_entropy_next(ent);
        size_t remaining = len - i;
        size_t chunk = remaining < 8 ? remaining : 8;
        memcpy(buf + i, &val, chunk);
        i += chunk;
    }
}

void oro_entropy_permutation(oro_entropy_t *ent, uint8_t *table, size_t len) {
    for (size_t i = 0; i < len; i++)
        table[i] = (uint8_t)i;
    for (size_t i = len - 1; i > 0; i--) {
        size_t j = oro_entropy_next(ent) % (i + 1);
        uint8_t tmp = table[i];
        table[i] = table[j];
        table[j] = tmp;
    }
}

void oro_entropy_inverse_permutation(const uint8_t *table, uint8_t *inv, size_t len) {
    for (size_t i = 0; i < len; i++)
        inv[table[i]] = (uint8_t)i;
}

uint64_t oro_entropy_seed_from_time(void) {
    uint64_t t;
#ifdef _WIN32
    LARGE_INTEGER pc;
    QueryPerformanceCounter(&pc);
    t = (uint64_t)pc.QuadPart;
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    t = (uint64_t)tv.tv_sec * 1000000ULL + (uint64_t)tv.tv_usec;
#endif
    t ^= (++_oro_seed_counter) * 0x9E3779B97F4A7C15ULL;
    t ^= t << 13;
    t ^= t >> 7;
    t ^= t << 17;
    t *= 0x2545F4914F6CDD1DULL;
    return t;
}
