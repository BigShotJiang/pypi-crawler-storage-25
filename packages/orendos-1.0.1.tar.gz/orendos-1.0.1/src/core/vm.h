// dev by mero tg @QP4RM
#ifndef ORENDOS_VM_H
#define ORENDOS_VM_H

#include <stdint.h>
#include <stddef.h>

#define ORO_VM_STACK_SIZE   4096
#define ORO_VM_MAX_LOCALS   256
#define ORO_VM_FLAG_READY   0x01
#define ORO_VM_FLAG_RUNNING 0x02
#define ORO_VM_FLAG_HALTED  0x04
#define ORO_VM_FLAG_ERROR   0x08

typedef struct {
    uint8_t  *code;
    size_t    code_size;
    uint8_t  *recovered;
    size_t    recovered_size;
    uint32_t  flags;
    uint64_t  entropy;
    uint64_t  exec_counter;
    void     *py_context;
} oro_vm_t;

int  oro_vm_init(oro_vm_t *vm);
void oro_vm_destroy(oro_vm_t *vm);
int  oro_vm_load(oro_vm_t *vm, const uint8_t *data, size_t size, uint64_t entropy);
int  oro_vm_execute(oro_vm_t *vm);
void oro_vm_wipe(oro_vm_t *vm);
int  oro_vm_get_flags(const oro_vm_t *vm);

#endif
