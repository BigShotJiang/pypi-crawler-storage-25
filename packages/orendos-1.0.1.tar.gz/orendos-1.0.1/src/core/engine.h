// dev by mero tg @QP4RM
#ifndef ORENDOS_ENGINE_H
#define ORENDOS_ENGINE_H

#include <stdint.h>
#include <stddef.h>

#define ORO_MAGIC       0x4F524E44
#define ORO_VERSION     0x0100
#define ORO_BLOCK_SIZE  16
#define ORO_MAX_SECTIONS 64
#define ORO_HEADER_SIZE 48

#define ORO_SECT_CODE   0x01
#define ORO_SECT_DATA   0x02
#define ORO_SECT_META   0x03
#define ORO_SECT_NOISE  0x04
#define ORO_SECT_GUARD  0x05

typedef struct {
    uint32_t magic;
    uint16_t version;
    uint16_t flags;
    uint64_t timestamp;
    uint64_t entropy_seed;
    uint32_t section_count;
    uint32_t total_size;
    uint8_t  checksum[16];
} oro_header_t;

typedef struct {
    uint8_t  type;
    uint16_t flags;
    uint32_t offset;
    uint32_t length;
    uint32_t original_length;
    uint8_t  signature[8];
} oro_section_t;

typedef struct {
    oro_header_t   header;
    oro_section_t  sections[ORO_MAX_SECTIONS];
    uint8_t       *data;
    size_t         data_size;
} oro_container_t;

int  oro_container_init(oro_container_t *container, uint64_t entropy_seed);
void oro_container_free(oro_container_t *container);
int  oro_container_add_section(oro_container_t *container, uint8_t type,
                               const uint8_t *data, size_t length);
int  oro_container_serialize(const oro_container_t *container,
                             uint8_t **out, size_t *out_size);
int  oro_container_deserialize(oro_container_t *container,
                               const uint8_t *data, size_t size);
void oro_compute_checksum(const uint8_t *data, size_t size, uint8_t out[16]);
int  oro_verify_checksum(const oro_container_t *container);

#endif
