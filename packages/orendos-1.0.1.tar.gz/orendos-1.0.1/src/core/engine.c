// dev by mero tg @QP4RM
#include "engine.h"
#include "entropy.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>

int oro_container_init(oro_container_t *container, uint64_t entropy_seed) {
    if (!container) return -1;
    memset(container, 0, sizeof(oro_container_t));
    container->header.magic = ORO_MAGIC;
    container->header.version = ORO_VERSION;
    container->header.flags = 0;
    container->header.timestamp = (uint64_t)time(NULL);
    container->header.entropy_seed = entropy_seed;
    container->header.section_count = 0;
    container->header.total_size = 0;
    container->data = NULL;
    container->data_size = 0;
    return 0;
}

void oro_container_free(oro_container_t *container) {
    if (container && container->data) {
        volatile uint8_t *p = (volatile uint8_t *)container->data;
        for (size_t i = 0; i < container->data_size; i++)
            p[i] = 0;
        free(container->data);
        container->data = NULL;
        container->data_size = 0;
    }
}

int oro_container_add_section(oro_container_t *container, uint8_t type,
                              const uint8_t *data, size_t length) {
    if (!container || !data) return -1;
    if (container->header.section_count >= ORO_MAX_SECTIONS) return -1;

    uint32_t idx = container->header.section_count;
    oro_section_t *sect = &container->sections[idx];
    sect->type = type;
    sect->flags = 0;
    sect->offset = (uint32_t)container->data_size;
    sect->length = (uint32_t)length;
    sect->original_length = (uint32_t)length;

    oro_entropy_t ent;
    oro_entropy_init(&ent, container->header.entropy_seed ^ (uint64_t)idx);
    oro_entropy_fill(&ent, sect->signature, 8);

    size_t new_size = container->data_size + length;
    uint8_t *new_data = (uint8_t *)realloc(container->data, new_size);
    if (!new_data) return -1;

    memcpy(new_data + container->data_size, data, length);
    container->data = new_data;
    container->data_size = new_size;
    container->header.section_count++;
    container->header.total_size = (uint32_t)new_size;
    return 0;
}

void oro_compute_checksum(const uint8_t *data, size_t size, uint8_t out[16]) {
    uint64_t h0 = 0xCBF29CE484222325ULL;
    uint64_t h1 = 0x100000001B3ULL;

    for (size_t i = 0; i < size; i++) {
        h0 ^= data[i];
        h0 *= 0x01000193;
        h1 ^= data[i];
        h1 *= 0x00000100000001B3ULL;
        h0 = (h0 << 13) | (h0 >> 51);
        h1 = (h1 << 29) | (h1 >> 35);
    }

    memcpy(out, &h0, 8);
    memcpy(out + 8, &h1, 8);
}

int oro_container_serialize(const oro_container_t *container,
                            uint8_t **out, size_t *out_size) {
    if (!container || !out || !out_size) return -1;

    size_t sect_table_size = container->header.section_count * sizeof(oro_section_t);
    size_t total = ORO_HEADER_SIZE + sect_table_size + container->data_size;

    uint8_t *buf = (uint8_t *)calloc(total, 1);
    if (!buf) return -1;

    oro_header_t hdr = container->header;
    memset(hdr.checksum, 0, 16);

    memcpy(buf, &hdr, ORO_HEADER_SIZE);
    memcpy(buf + ORO_HEADER_SIZE, container->sections, sect_table_size);
    if (container->data_size > 0)
        memcpy(buf + ORO_HEADER_SIZE + sect_table_size, container->data, container->data_size);

    uint8_t checksum[16];
    oro_compute_checksum(buf, total, checksum);
    memcpy(buf + 32, checksum, 16);

    *out = buf;
    *out_size = total;
    return 0;
}

int oro_container_deserialize(oro_container_t *container,
                              const uint8_t *data, size_t size) {
    if (!container || !data || size < ORO_HEADER_SIZE) return -1;

    memcpy(&container->header, data, ORO_HEADER_SIZE);

    if (container->header.magic != ORO_MAGIC) return -1;
    if (container->header.version != ORO_VERSION) return -1;
    if (container->header.section_count > ORO_MAX_SECTIONS) return -1;

    size_t sect_table_size = container->header.section_count * sizeof(oro_section_t);
    if (ORO_HEADER_SIZE + sect_table_size > size) return -1;

    memcpy(container->sections, data + ORO_HEADER_SIZE, sect_table_size);

    size_t data_offset = ORO_HEADER_SIZE + sect_table_size;
    size_t data_size = size - data_offset;

    if (data_size > 0) {
        container->data = (uint8_t *)malloc(data_size);
        if (!container->data) return -1;
        memcpy(container->data, data + data_offset, data_size);
        container->data_size = data_size;
    } else {
        container->data = NULL;
        container->data_size = 0;
    }

    uint8_t stored_checksum[16];
    memcpy(stored_checksum, container->header.checksum, 16);

    uint8_t *verify_buf = (uint8_t *)malloc(size);
    if (!verify_buf) { oro_container_free(container); return -1; }
    memcpy(verify_buf, data, size);
    memset(verify_buf + 32, 0, 16);

    uint8_t computed[16];
    oro_compute_checksum(verify_buf, size, computed);
    free(verify_buf);

    if (memcmp(stored_checksum, computed, 16) != 0) {
        oro_container_free(container);
        return -1;
    }

    return 0;
}

int oro_verify_checksum(const oro_container_t *container) {
    if (!container) return -1;
    uint8_t *buf;
    size_t buf_size;
    if (oro_container_serialize(container, &buf, &buf_size) != 0) return -1;
    free(buf);
    return 0;
}
