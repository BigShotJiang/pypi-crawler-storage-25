// dev by mero tg @QP4RM
#include "vm.h"
#include "algorithms.h"
#include "engine.h"
#include "shield.h"
#include "entropy.h"
#include <stdlib.h>
#include <string.h>

int oro_vm_init(oro_vm_t *vm) {
    if (!vm) return -1;
    memset(vm, 0, sizeof(oro_vm_t));
    vm->flags = 0;
    vm->exec_counter = 0;
    return 0;
}

void oro_vm_destroy(oro_vm_t *vm) {
    if (!vm) return;
    oro_vm_wipe(vm);
    if (vm->code) {
        free(vm->code);
        vm->code = NULL;
    }
    vm->flags = ORO_VM_FLAG_HALTED;
}

int oro_vm_load(oro_vm_t *vm, const uint8_t *data, size_t size, uint64_t entropy) {
    if (!vm || !data || size == 0) return -1;

    oro_container_t container;
    if (oro_container_deserialize(&container, data, size) != 0)
        return -1;

    if (container.header.section_count < 1) {
        oro_container_free(&container);
        return -1;
    }

    oro_cipher_ctx_t cipher;
    if (oro_cipher_init(&cipher, entropy) != 0) {
        oro_container_free(&container);
        return -1;
    }

    oro_section_t *code_sect = NULL;
    for (uint32_t i = 0; i < container.header.section_count; i++) {
        if (container.sections[i].type == ORO_SECT_CODE) {
            code_sect = &container.sections[i];
            break;
        }
    }

    if (!code_sect) {
        oro_cipher_free(&cipher);
        oro_container_free(&container);
        return -1;
    }

    size_t enc_len = code_sect->length;
    uint8_t *enc_data = (uint8_t *)malloc(enc_len);
    if (!enc_data) {
        oro_cipher_free(&cipher);
        oro_container_free(&container);
        return -1;
    }
    memcpy(enc_data, container.data + code_sect->offset, enc_len);

    uint64_t saved_state[2];
    saved_state[0] = cipher.stream_state[0];
    saved_state[1] = cipher.stream_state[1];

    oro_xor_stream_reset(&cipher, entropy);
    oro_xor_stream(&cipher, enc_data, enc_len);

    oro_unpermute(&cipher, enc_data, enc_len);

    cipher.stream_state[0] = saved_state[0];
    cipher.stream_state[1] = saved_state[1];

    uint8_t *gathered = NULL;
    size_t gathered_len = 0;
    if (oro_gather(&cipher, enc_data, enc_len, &gathered, &gathered_len) != 0) {
        oro_shield_wipe_memory(enc_data, enc_len);
        free(enc_data);
        oro_cipher_free(&cipher);
        oro_container_free(&container);
        return -1;
    }
    oro_shield_wipe_memory(enc_data, enc_len);
    free(enc_data);

    uint8_t *decrypted = NULL;
    size_t decrypted_len = 0;
    if (oro_feistel_decrypt(&cipher, gathered, gathered_len,
                            &decrypted, &decrypted_len) != 0) {
        oro_shield_wipe_memory(gathered, gathered_len);
        free(gathered);
        oro_cipher_free(&cipher);
        oro_container_free(&container);
        return -1;
    }
    oro_shield_wipe_memory(gathered, gathered_len);
    free(gathered);

    vm->recovered = decrypted;
    vm->recovered_size = decrypted_len;
    vm->code = (uint8_t *)malloc(size);
    if (vm->code) {
        memcpy(vm->code, data, size);
        vm->code_size = size;
    }
    vm->entropy = entropy;
    vm->flags = ORO_VM_FLAG_READY;

    oro_cipher_free(&cipher);
    oro_container_free(&container);
    return 0;
}

int oro_vm_execute(oro_vm_t *vm) {
    if (!vm) return -1;
    if (!(vm->flags & ORO_VM_FLAG_READY)) return -1;
    if (!vm->recovered || vm->recovered_size == 0) return -1;

    vm->flags |= ORO_VM_FLAG_RUNNING;
    vm->exec_counter++;
    vm->flags &= ~ORO_VM_FLAG_RUNNING;
    return 0;
}

void oro_vm_wipe(oro_vm_t *vm) {
    if (!vm) return;
    if (vm->recovered && vm->recovered_size > 0) {
        oro_shield_wipe_memory(vm->recovered, vm->recovered_size);
        free(vm->recovered);
        vm->recovered = NULL;
        vm->recovered_size = 0;
    }
}

int oro_vm_get_flags(const oro_vm_t *vm) {
    if (!vm) return -1;
    return (int)vm->flags;
}
