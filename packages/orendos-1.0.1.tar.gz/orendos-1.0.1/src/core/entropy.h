// dev by mero tg @QP4RM
#ifndef ORENDOS_ENTROPY_H
#define ORENDOS_ENTROPY_H

#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint64_t state[4];
    uint64_t counter;
} oro_entropy_t;

void     oro_entropy_init(oro_entropy_t *ent, uint64_t seed);
uint64_t oro_entropy_next(oro_entropy_t *ent);
uint32_t oro_entropy_next32(oro_entropy_t *ent);
uint8_t  oro_entropy_next8(oro_entropy_t *ent);
void     oro_entropy_fill(oro_entropy_t *ent, uint8_t *buf, size_t len);
void     oro_entropy_permutation(oro_entropy_t *ent, uint8_t *table, size_t len);
void     oro_entropy_inverse_permutation(const uint8_t *table, uint8_t *inv, size_t len);
uint64_t oro_entropy_seed_from_time(void);

#endif
