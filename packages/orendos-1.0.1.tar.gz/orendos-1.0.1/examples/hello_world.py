# dev by mero tg @QP4RM
print("hello from orendos protected code!")
print("this source will be transformed into unreadable machine language")

x = 42
y = 58
result = x + y
print(f"calculation: {x} + {y} = {result}")

for i in range(5):
    print(f"  iteration {i}")

print("done!")
