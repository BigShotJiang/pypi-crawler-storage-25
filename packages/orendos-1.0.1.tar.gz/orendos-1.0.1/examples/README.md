# dev by mero tg @QP4RM

# orendos examples

## hello_world.py

basic example showing protected code execution

```bash
# compile
orendos compile examples/hello_world.py

# run
orendos run examples/hello_world_protected.py
```

## advanced_example.py

advanced example with classes, json, hashing, and algorithms

```bash
# compile
orendos compile examples/advanced_example.py

# run
orendos run examples/advanced_example_protected.py
```

## manual conversion

```bash
python scripts/convert.py
# enter the file path when prompted
```
