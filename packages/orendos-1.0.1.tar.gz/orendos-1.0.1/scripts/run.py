#!/usr/bin/env python3
# dev by mero tg @QP4RM
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from orendos.runtime import execute_oro, RuntimeError as OroRuntimeError


def main():
    if len(sys.argv) < 2:
        print("[orendos] usage: python run.py <file.oro>")
        return

    file_path = sys.argv[1]

    if not os.path.isfile(file_path):
        print(f"[orendos] error: file not found: {file_path}")
        return

    try:
        execute_oro(file_path)
    except OroRuntimeError as e:
        print(f"[orendos] runtime error: {e}")
    except Exception as e:
        print(f"[orendos] error: {e}")


if __name__ == "__main__":
    main()
