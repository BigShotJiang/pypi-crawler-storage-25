#!/usr/bin/env python3
# dev by mero tg @QP4RM
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from orendos.compiler import compile_file, CompilerError


def main():
    print("=" * 50)
    print("  orendos v1.0.0 - code protection compiler")
    print("  dev by mero tg @QP4RM")
    print("=" * 50)
    print()

    file_path = input("[orendos] enter python file path: ").strip()

    if not file_path:
        print("[orendos] error: no path provided")
        return

    if not os.path.isfile(file_path):
        print(f"[orendos] error: file not found: {file_path}")
        return

    if not file_path.endswith(".py"):
        print("[orendos] error: file must be a .py file")
        return

    print(f"[orendos] compiling: {file_path}")
    print("[orendos] applying deep algorithmic transformation...")

    try:
        protected_path = compile_file(file_path)
        print()
        print("[orendos] done save")
        print(f"[orendos] protected file: {protected_path}")
        print()
        print("[orendos] to run the protected file:")
        print(f"  orendos run {protected_path}")
        print()
    except CompilerError as e:
        print(f"[orendos] error: {e}")
    except Exception as e:
        print(f"[orendos] unexpected error: {e}")


if __name__ == "__main__":
    main()
