<!-- dev by mero tg @QP4RM -->

<p align="center">
  <img src="assets/banner.svg" alt="orendos" width="100%"/>
</p>

<p align="center">
  <strong>deep algorithmic code protection for Python</strong>
</p>

<p align="center">
  <code>v1.0.0</code> &nbsp;|&nbsp; C/C++ kernel &nbsp;|&nbsp; Python runtime &nbsp;|&nbsp; cross-platform
</p>

---

## what is orendos?

orendos is a code protection library that transforms Python source into a custom machine language that cannot be decompiled, reversed, or read. the final output is a binary format processed by a deep algorithmic engine written in C — no bytecode, no opcodes, no readable structures.

the interpreter executes the protected code directly through layered internal algorithms without ever decoding it back to Python.

### protection layers

| layer | engine | description |
|-------|--------|-------------|
| feistel cipher | C | 16-round feistel network with dynamic S-boxes |
| xor stream | C | xorshift128+ stream cipher with entropy-derived keys |
| byte permutation | C | 256-entry permutation tables (fisher-yates) |
| data scattering | C | block interleaving with noise injection |
| anti-debug shield | C | debugger detection, timing checks, memory wiping |
| dynamic entropy | C | xoshiro256** PRNG — different output every compilation |

### key features

- every compilation produces unique output — same source, different binary
- no standard bytecode or opcodes — custom internal representation
- the interpreter does not decode — it executes through deep algorithmic pipelines
- anti-debugging and anti-tampering built into the C kernel
- memory wiping after execution — no traces left in RAM
- supports all Python features, libraries, and frameworks
- works on Linux, Windows, macOS, Android

---

## installation

```bash
pip install orendos
```

### from source

```bash
git clone https://github.com/6x-u/orendos.git
cd orendos
pip install .
```

requires: Python >= 3.7, C compiler (gcc/clang/msvc)

---

## usage

### compile a Python file

```python
from orendos.compiler import compile_file

oro_path, wrapper_path = compile_file("my_script.py")
print(f"protected: {oro_path}")
print(f"runner: {wrapper_path}")
```

### run protected code

```python
from orendos.runtime import execute_oro

execute_oro("my_script.oro")
```

### protected file format

after compilation, a wrapper `.py` file is generated:

```python
import orendos as mero
"my_script.oro"
o0o-run
```

> `as mero` is required — without it the runtime will not activate.

### CLI

```bash
# compile
orendos compile my_script.py

# run
orendos run my_script_protected.py
orendos run my_script.oro

# info
orendos info
```

### interactive converter script

```bash
python scripts/convert.py
```

the script will:
1. ask for the Python file path
2. compile with deep algorithmic transformation
3. display `done save` and show the output paths
4. the generated file runs without any errors

---

## how it works

```
Python Source
     |
     v
 [AST Parse]
     |
     v
 [Code Object → Marshal]
     |
     v
 [C Engine: Feistel Encrypt (16 rounds)]
     |
     v
 [C Engine: Data Scatter (8 blocks + noise)]
     |
     v
 [C Engine: Byte Permutation (256-table)]
     |
     v
 [C Engine: XOR Stream Cipher]
     |
     v
 [Container: Header + Sections + Checksum]
     |
     v
 .oro Binary File
```

at runtime:

```
.oro Binary File
     |
     v
 [Shield: Anti-Debug + Integrity Check]
     |
     v
 [VM: Load Container → Verify Checksum]
     |
     v
 [C Engine: Reverse Pipeline (deep internal)]
     |
     v
 [Direct Execution → Memory Wipe]
     |
     v
 Output
```

the reverse pipeline operates through the C kernel — it never exposes the original code, bytecode, or any readable representation. even if someone captures the binary, the dynamic entropy ensures every compilation is unique and the internal structures are non-deterministic.

---

## architecture

```
orendos/
├── src/core/           # C kernel
│   ├── engine.c/h      # container format, serialization
│   ├── algorithms.c/h  # feistel, permutation, scatter, xor
│   ├── vm.c/h          # virtual machine, execution pipeline
│   ├── shield.c/h      # anti-debug, integrity, memory wipe
│   ├── entropy.c/h     # xoshiro256** PRNG, key derivation
│   └── orendos_core.c  # Python C extension bridge
├── orendos/            # Python package
│   ├── compiler.py     # source → .oro compilation
│   ├── runtime.py      # .oro → execution
│   ├── cli.py          # command-line interface
│   └── _compat.py      # platform compatibility
├── scripts/
│   ├── convert.py      # interactive converter
│   └── run.py          # runner script
├── examples/           # example Python files
└── tests/              # test suite
```

---

## security model

| attack | defense |
|--------|---------|
| decompilation | no standard bytecode — custom binary format |
| disassembly | no opcodes — layered algorithmic transformation |
| memory dump | secure memory wiping after execution |
| debugger attach | ptrace/IsDebuggerPresent detection |
| binary analysis | dynamic entropy — each build is unique |
| timing analysis | timing-based anomaly detection |
| file tampering | SHA-256 checksum + section signatures |
| copyright removal | embedded guard markers with integrity check |

---

## examples

### basic

```python
# source: hello.py
print("hello world")

# compile
from orendos.compiler import compile_file
compile_file("hello.py")

# result: hello_protected.py
import orendos as mero
"hello.oro"
o0o-run
```

### advanced

```python
# any Python code works — classes, imports, frameworks
import json

class API:
    def __init__(self):
        self.data = {"status": "protected"}

    def respond(self):
        return json.dumps(self.data)

api = API()
print(api.respond())
```

compile it:

```bash
orendos compile api.py
orendos run api_protected.py
# output: {"status": "protected"}
```

---

## platform support

| platform | status |
|----------|--------|
| Linux (x86_64, arm64) | supported |
| Windows (x86_64) | supported |
| macOS (x86_64, arm64) | supported |
| Android (termux) | supported |

---

## dev

```bash
# build from source
pip install -e .

# run tests
python -m pytest tests/

# test compilation
python scripts/convert.py
```

---

<p align="center">
  <strong>orendos v1.0.0</strong><br>
  dev by mero &nbsp;|&nbsp; tg <a href="https://t.me/QP4RM">@QP4RM</a> &nbsp;|&nbsp; <a href="https://github.com/6x-u">github.com/6x-u</a>
</p>
