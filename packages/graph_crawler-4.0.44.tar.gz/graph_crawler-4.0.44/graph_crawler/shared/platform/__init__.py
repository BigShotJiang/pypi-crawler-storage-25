"""Platform detection and system metrics module.

This module provides cross-platform compatibility by detecting:
- Operating system (Windows, Linux, macOS, Android, etc.)
- Python version and features
- Hardware resources (CPU cores, memory)
- Network capabilities (DNS resolver availability)
- Platform-specific optimizations
- Event loop diagnostics
- Crawl session statistics

Usage:
    from graph_crawler.shared.platform import get_platform_info, PlatformConfig

    # Get all platform info
    info = get_platform_info()
    print(info.os_name, info.cpu_cores, info.memory_gb)

    # Get optimized config for current platform
    config = PlatformConfig.get_config()
    print(config.dns_resolver_type, config.recommended_concurrency)
    
    # Collect system snapshot (all diagnostics)
    from graph_crawler.shared.platform import collect_system_snapshot
    snapshot = collect_system_snapshot()
    
    # Crawl session stats (Scrapy-style)
    from graph_crawler.shared.platform import get_global_stats
    stats = get_global_stats()
    stats.record_request(success=True, status_code=200, duration_ms=150)
"""

from graph_crawler.shared.platform.config import (
    DNSResolverType,
    EventLoopPolicy,
    PlatformConfig,
    get_cached_config,
    get_optimized_config,
)
from graph_crawler.shared.platform.detector import (
    PlatformInfo,
    get_cached_platform_info,
    get_platform_info,
    is_android,
    is_container,
    is_linux,
    is_macos,
    is_windows,
)
from graph_crawler.shared.platform.diagnostics import (
    # Session stats (Scrapy-style)
    CrawlSessionStats,
    # Event loop
    EventLoopMetrics,
    EventLoopMonitor,
    # Network
    NetworkCapabilities,
    ResourceStatus,
    # Environment
    RuntimeEnvironment,
    # Complete snapshot
    SystemSnapshot,
    collect_network_capabilities,
    collect_runtime_environment,
    collect_system_snapshot,
    get_global_stats,
    reset_global_stats,
)
from graph_crawler.shared.platform.metrics import (
    MetricsCollector,
    SystemMetrics,
    collect_system_metrics,
    get_global_collector,
)

__all__ = [
    # Platform detection
    "PlatformInfo",
    "get_platform_info",
    "get_cached_platform_info",
    "is_windows",
    "is_linux",
    "is_macos",
    "is_android",
    "is_container",
    # Configuration
    "PlatformConfig",
    "DNSResolverType",
    "EventLoopPolicy",
    "get_optimized_config",
    "get_cached_config",
    # Metrics
    "SystemMetrics",
    "collect_system_metrics",
    "MetricsCollector",
    "get_global_collector",
    # Event loop diagnostics
    "EventLoopMetrics",
    "EventLoopMonitor",
    "ResourceStatus",
    # Network capabilities
    "NetworkCapabilities",
    "collect_network_capabilities",
    # Runtime environment
    "RuntimeEnvironment",
    "collect_runtime_environment",
    # Crawl session stats
    "CrawlSessionStats",
    "get_global_stats",
    "reset_global_stats",
    # System snapshot
    "SystemSnapshot",
    "collect_system_snapshot",
]
