"""Unit tests for the wrapt 1.x → 2.x compatibility shim."""
from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock

import pytest

import raindrop_deep_agents._wrapt_compat as compat


def _fresh_wrapt_stub(version: str, sig_param_name: str) -> types.ModuleType:
    """Build a stand-in ``wrapt`` module so we can exercise install() under
    arbitrary versions without touching the real wrapt installed in this
    venv.  ``sig_param_name`` controls whether the stub's
    ``wrap_function_wrapper`` accepts ``module=`` (1.x) or ``target=`` (2.x).
    """
    stub = types.ModuleType("wrapt")
    stub.__version__ = version

    if sig_param_name == "module":
        def wfw(module, name, wrapper):
            wfw.calls.append({"module": module, "name": name, "wrapper": wrapper})
    elif sig_param_name == "target":
        def wfw(target, name, wrapper):
            wfw.calls.append({"target": target, "name": name, "wrapper": wrapper})
    else:
        raise ValueError(sig_param_name)
    wfw.calls = []  # type: ignore[attr-defined]
    stub.wrap_function_wrapper = wfw

    wrappers = types.ModuleType("wrapt.wrappers")
    wrappers.wrap_function_wrapper = wfw
    stub.wrappers = wrappers
    return stub


def _swap_wrapt(monkeypatch, stub):
    monkeypatch.setitem(sys.modules, "wrapt", stub)
    monkeypatch.setitem(sys.modules, "wrapt.wrappers", stub.wrappers)


class TestWraptCompatShim:
    def test_install_no_op_on_wrapt_1_x(self, monkeypatch):
        stub = _fresh_wrapt_stub("1.17.3", "module")
        _swap_wrapt(monkeypatch, stub)
        applied = compat.install()
        assert applied is False, "shim should be a no-op on wrapt<2"
        assert not getattr(
            stub.wrap_function_wrapper, "_raindrop_deep_agents_compat_shim", False,
        )

    def test_install_translates_module_to_target_on_wrapt_2_x(self, monkeypatch):
        stub = _fresh_wrapt_stub("2.1.2", "target")
        original_wfw = stub.wrap_function_wrapper
        _swap_wrapt(monkeypatch, stub)
        applied = compat.install()
        assert applied is True

        # Caller using legacy module= kwarg → translated to target=.
        wrapper = MagicMock()
        stub.wrap_function_wrapper(
            module="langchain_core.callbacks",
            name="BaseCallbackManager.__init__",
            wrapper=wrapper,
        )
        assert original_wfw.calls == [{
            "target": "langchain_core.callbacks",
            "name": "BaseCallbackManager.__init__",
            "wrapper": wrapper,
        }]

    def test_install_passes_target_kwarg_through_unchanged(self, monkeypatch):
        stub = _fresh_wrapt_stub("2.1.2", "target")
        original_wfw = stub.wrap_function_wrapper
        _swap_wrapt(monkeypatch, stub)
        compat.install()
        wrapper = MagicMock()
        stub.wrap_function_wrapper(target="x.y", name="z", wrapper=wrapper)
        assert original_wfw.calls == [{"target": "x.y", "name": "z", "wrapper": wrapper}]

    def test_install_passes_positional_args_through_unchanged(self, monkeypatch):
        stub = _fresh_wrapt_stub("2.1.2", "target")
        original_wfw = stub.wrap_function_wrapper
        _swap_wrapt(monkeypatch, stub)
        compat.install()
        wrapper = MagicMock()
        stub.wrap_function_wrapper("x.y", "z", wrapper)
        assert original_wfw.calls == [{"target": "x.y", "name": "z", "wrapper": wrapper}]

    def test_install_idempotent(self, monkeypatch):
        stub = _fresh_wrapt_stub("2.1.2", "target")
        _swap_wrapt(monkeypatch, stub)
        assert compat.install() is True
        # Capture the shim function reference after first install.
        first_shim = stub.wrap_function_wrapper
        assert compat.install() is True
        # Re-installation should not double-wrap; same callable still in place.
        assert stub.wrap_function_wrapper is first_shim

    def test_install_handles_missing_wrapt_gracefully(self, monkeypatch):
        # Simulate wrapt entirely missing — install() must return False, not raise.
        monkeypatch.setitem(sys.modules, "wrapt", None)
        # Re-import so the local `import wrapt` inside install() sees None.
        # (sys.modules[name] = None makes Python raise ImportError on import.)
        assert compat.install() is False

    def test_install_handles_unparseable_version(self, monkeypatch):
        stub = _fresh_wrapt_stub("not.a.version", "target")
        _swap_wrapt(monkeypatch, stub)
        # Unparseable version → treated as < 2 → no-op.
        assert compat.install() is False

    def test_module_kwarg_wins_when_target_not_provided(self, monkeypatch):
        stub = _fresh_wrapt_stub("2.1.2", "target")
        original_wfw = stub.wrap_function_wrapper
        _swap_wrapt(monkeypatch, stub)
        compat.install()
        wrapper = MagicMock()
        # explicit target= takes precedence over module= (matches modern API)
        stub.wrap_function_wrapper(
            target="winner", name="z", wrapper=wrapper, module="loser",
        )
        assert original_wfw.calls == [{"target": "winner", "name": "z", "wrapper": wrapper}]
