"""End-to-end tests for raindrop-deep-agents.

Runs REAL Deep Agents workflows via create_deep_agent() against a REAL LLM,
ships telemetry via the Raindrop handler, then queries the dashboard API
to verify events were ingested correctly.

E2E Coverage Mapping (from Step 7b feature plan + every README claim):
  ✓ Event tracking (basic AI call)     → TestEventShape
  ✓ Token usage capture                → TestTokenUsage
  ✓ Model name extraction              → TestModelName
  ✓ Tool call tracing (TOOL_CALL span) → TestToolCalls
  ✓ Sequential call isolation          → TestSequentialCalls
  ✓ Conversation grouping (convoId)    → TestConvoGrouping
  ✓ Error resilience (error event)     → TestErrorHandling
  ✓ identify() + track_signal()        → TestClassAPI
  ✓ Factory function                   → TestFactoryFunction
  ✓ Multi-turn conversation            → TestMultiTurn
  ✓ Debug mode                         → TestDebugMode
  ✓ Tags/metadata forwarding           → TestTagsMetadata
  ✓ Async path (agent.ainvoke)         → TestAsyncPath
  ✓ Finish reason in event properties  → TestFinishReason
  ✓ Extended token categories          → TestExtendedTokens
  ✓ Subagent / task tool grouping      → TestSubagentTaskTool
  ✓ Nested trace spans (OTel)          → TestTraceSpans
  ✗ Streaming (not supported)          → N/A (documented in Known Limitations)

Required environment variables:
  RAINDROP_WRITE_KEY or RAINDROP_API_KEY
  OPENAI_API_KEY
  RAINDROP_DASHBOARD_TOKEN

Run locally:
  cd packages/deep-agents-python
  pip install -e ".[dev]" deepagents langchain-openai requests
  export RAINDROP_WRITE_KEY=... OPENAI_API_KEY=... RAINDROP_DASHBOARD_TOKEN=...
  python -m pytest tests/test_e2e.py -v -s
"""

import json
import os
import time
import urllib.parse
import uuid
from typing import Optional

import pytest

# ``requests`` is a dev-only dependency and is not pulled in by the
# default ``pip install -e .`` that the CI integration workflow uses.
# A bare ``import requests`` at module level would crash pytest
# collection with ModuleNotFoundError BEFORE ``skip_unless_e2e`` can
# fire, breaking CI for the whole package.  Lazy-import only when the
# dashboard helpers are actually called (those helpers are gated by
# ``skip_unless_e2e`` so they only run when the e2e env is fully set up).
try:
    import requests
except ImportError:  # pragma: no cover
    requests = None  # type: ignore[assignment]

WRITE_KEY = os.getenv("RAINDROP_WRITE_KEY") or os.getenv("RAINDROP_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
DASHBOARD_TOKEN = os.getenv("RAINDROP_DASHBOARD_TOKEN")
BACKEND_URL = os.getenv("RAINDROP_BACKEND_URL", "https://backend.raindrop.ai")


skip_unless_e2e = pytest.mark.skipif(
    not all([WRITE_KEY, OPENAI_API_KEY, DASHBOARD_TOKEN, requests is not None]),
    reason=(
        "E2E tests require RAINDROP_WRITE_KEY, OPENAI_API_KEY, "
        "RAINDROP_DASHBOARD_TOKEN, and the ``requests`` package.  Install "
        "the dev extras (``pip install -e \".[dev]\"``) and run via doppler:\n"
        "  RAINDROP_DASHBOARD_TOKEN=$(grab from app.raindrop.ai DevTools → "
        "Network → any backend.raindrop.ai request → 'Authorization: Bearer ...') "
        "doppler run -p dawn -c dev -- pytest tests/test_e2e.py -v"
    ),
)

RUN_ID = uuid.uuid4().hex[:10]
MODEL = "gpt-4o-mini"


def _check_token_freshness(min_ttl_seconds: int = 600) -> None:
    """Decode the dashboard token's exp claim and abort early if it's
    already expired or about to expire mid-run.

    Dashboard JWTs are ~30-min PropelAuth session tokens; by the time a
    human pastes one into the test runner, ~5-10 min may already have
    elapsed.  A 5-min e2e suite started with a 25-min-old token will
    fail with 401 part-way through, manifesting as N flaky tests with
    confusing dashboard errors.  Catch it at session start instead.

    Per new-integration SKILL.md Common Mistake #50.
    """
    if not DASHBOARD_TOKEN:
        return
    import base64
    try:
        body_b64 = DASHBOARD_TOKEN.split(".")[1]
        body_b64 += "=" * (-len(body_b64) % 4)
        body = json.loads(base64.urlsafe_b64decode(body_b64))
        exp = body.get("exp")
        if exp is None:
            return
        ttl = int(exp - time.time())
        if ttl <= 0:
            pytest.exit(
                f"RAINDROP_DASHBOARD_TOKEN expired {-ttl // 60}m ago — "
                "fetch a fresh one from app.raindrop.ai (DevTools → "
                "Network → any backend.raindrop.ai request → "
                "'Authorization: Bearer ...').",
                returncode=2,
            )
        if ttl < min_ttl_seconds:
            print(
                f"⚠️  RAINDROP_DASHBOARD_TOKEN has only {ttl // 60}m left "
                f"(min recommended: {min_ttl_seconds // 60}m).  If the "
                "suite runs longer, expect 401 errors mid-run."
            )
        else:
            print(f"✓ RAINDROP_DASHBOARD_TOKEN: {ttl // 60}m remaining")
    except SystemExit:
        raise
    except Exception:
        # Token shape is unexpected — let the actual API call surface the
        # issue.  Don't preempt with a confusing decoder error.
        pass


# Run the preflight at module import so flakes from expired tokens are
# caught at session start, not 4 minutes into the run.
_check_token_freshness()


def _make_user(suffix: str) -> str:
    return f"e2e_da_{RUN_ID}_{suffix}"


def _make_convo(suffix: str) -> str:
    return f"e2e_da_convo_{RUN_ID}_{suffix}"


def _query_dashboard(limit: int = 50) -> list[dict]:
    input_obj = {"json": {"limit": limit, "orderBy": {"field": "timestamp", "direction": "desc"}}}
    encoded = urllib.parse.quote(json.dumps(input_obj))
    resp = requests.get(
        f"{BACKEND_URL}/api/trpc/events.list?input={encoded}",
        headers={"Authorization": f"Bearer {DASHBOARD_TOKEN}"},
        timeout=20,
    )
    resp.raise_for_status()
    return resp.json().get("result", {}).get("data", [])


def poll_events(
    user_id: str,
    min_count: int = 1,
    timeout: int = 90,
    interval: int = 5,
) -> list[dict]:
    deadline = time.time() + timeout
    matched: list[dict] = []
    while time.time() < deadline:
        all_events = _query_dashboard()
        matched = [e for e in all_events if e.get("userId") == user_id]
        if len(matched) >= min_count:
            return matched
        time.sleep(interval)
    raise TimeoutError(
        f"Expected >= {min_count} events for userId={user_id}, "
        f"got {len(matched)} after {timeout}s"
    )


def _num(val) -> float:
    if val is None:
        return 0
    return float(val)


def _find_llm_event(events: list[dict]) -> dict:
    """Return an event that captures concrete LLM data (model + output).

    Deep Agents invocations produce two kinds of events: the LangGraph
    root chain event (chain input/output, no model) and one or more LLM
    child events (full LLM metadata including model + tokens).  Tests
    that want LLM metadata must skip the root chain event.
    """
    for ev in events:
        ai = ev.get("aiData") or {}
        if ai.get("model") and ai.get("output"):
            return ev
    for ev in events:
        ai = ev.get("aiData") or {}
        if ai.get("output"):
            return ev
    return events[0] if events else {}


def poll_llm_event(
    user_id: str,
    timeout: int = 90,
    interval: int = 5,
) -> dict:
    """Poll until an event with model + output appears for *user_id*."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        all_events = _query_dashboard()
        matched = [e for e in all_events if e.get("userId") == user_id]
        ev = _find_llm_event(matched)
        ai = ev.get("aiData") or {}
        if ev and ai.get("model") and ai.get("output"):
            return ev
        time.sleep(interval)
    raise TimeoutError(
        f"No LLM event with model+output for userId={user_id} after {timeout}s"
    )


# ======================================================================
# Trace query infrastructure (for OTel instrumentor verification)
# ======================================================================


def _query_all_traces() -> list[dict]:
    """Query all traces via pipe proxy (same path the dashboard Traces page uses)."""
    resp = requests.get(
        f"{BACKEND_URL}/api/internal/pipe/proxy",
        params={"pipe": "all_traces"},
        headers={"Authorization": f"Bearer {DASHBOARD_TOKEN}"},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json().get("data", [])


def _query_trace_spans(trace_id: str) -> list[dict]:
    """Query full span tree for a trace via pipe proxy."""
    resp = requests.get(
        f"{BACKEND_URL}/api/internal/pipe/proxy",
        params={"pipe": "traces_for_id", "trace_id": trace_id},
        headers={"Authorization": f"Bearer {DASHBOARD_TOKEN}"},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json().get("data", [])


def poll_traces_matching(
    needle: str,
    min_count: int = 1,
    timeout: int = 120,
    interval: int = 10,
) -> list[dict]:
    """Fallback trace finder: brute-force search ``all_traces`` for spans
    whose attributes contain *needle*.  Slow (one HTTP call per trace) and
    only used when we don't have the trace_id up-front.  Prefer
    :func:`poll_spans_for_event` which jumps straight to the right trace
    via the event's ``properties.trace_id``.
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            all_traces = _query_all_traces()
            mine_spans: list[dict] = []
            for t in all_traces[:100]:
                trace_id = t.get("trace_id")
                if not trace_id:
                    continue
                spans = _query_trace_spans(trace_id)
                trace_matches = False
                for s in spans:
                    attrs = s.get("attributes_string") or {}
                    if any(needle in str(v) for v in attrs.values()):
                        trace_matches = True
                        break
                if trace_matches:
                    mine_spans.extend(spans)
                if len({s.get("trace_id") for s in mine_spans}) >= min_count:
                    break
            if len({s.get("trace_id") for s in mine_spans if s.get("trace_id")}) >= min_count:
                return mine_spans
        except Exception:
            pass
        time.sleep(interval)
    raise TimeoutError(
        f"Expected >= {min_count} traces matching {needle!r}, got 0 after {timeout}s"
    )


def poll_spans_for_event(
    user_id: str,
    timeout: int = 240,
    interval: int = 10,
) -> tuple[str, list[dict]]:
    """Fast, deterministic trace lookup for a Deep Agents run.

    Polls ``events.list`` for the root chain event the user just produced
    (root events carry ``properties.trace_id`` set by ``raindrop.begin()``),
    then jumps straight to that trace's full span tree via
    ``traces_for_id``.

    Returns ``(trace_id_hex, spans)``.  Much more reliable than brute-
    forcing ``all_traces`` since it uses the canonical event → trace link
    the dashboard itself uses, instead of guessing via attribute search.

    The trace ingestion pipeline can take 30-120s, so we poll the trace
    until at least one span lands.  If the root event itself never
    appears, we raise — that means the integration is broken, not that
    the trace is just slow.
    """
    deadline = time.time() + timeout
    trace_id_hex: Optional[str] = None
    while time.time() < deadline:
        for ev in (e for e in _query_dashboard(limit=100) if e.get("userId") == user_id):
            tid = (ev.get("properties") or {}).get("trace_id")
            if tid:
                trace_id_hex = tid
                break
        if trace_id_hex:
            break
        time.sleep(interval)
    if not trace_id_hex:
        raise TimeoutError(
            f"No event with properties.trace_id for userId={user_id} after {timeout}s — "
            "raindrop.begin() may not be running, or the root event isn't being shipped."
        )

    # Now poll the trace pipe for spans on that specific trace_id.
    while time.time() < deadline:
        try:
            spans = _query_trace_spans(trace_id_hex)
            if spans:
                return trace_id_hex, spans
        except Exception:
            pass
        time.sleep(interval)
    raise TimeoutError(
        f"Found event with trace_id={trace_id_hex} but trace_pipe returned 0 spans "
        f"after {timeout}s — OTel instrumentor is broken or ingestion is stuck."
    )


# Backwards-compatible alias for older test code paths.
poll_traces_for_user = poll_traces_matching


@skip_unless_e2e
class TestEventShape:
    """Basic create_deep_agent() invoke — verify full event shape."""

    def test_single_invoke_full_shape(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("shape")
        convo_id = _make_convo("shape")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Answer in one sentence.")
        result = agent.invoke(
            {"messages": [HumanMessage(content="What is the capital of France?")]},
            config={"callbacks": [rd.handler]},
        )
        assert result["messages"][-1].content

        rd.shutdown()

        ev = poll_llm_event(user_id)
        assert ev["userId"] == user_id

        ai = ev.get("aiData") or {}
        assert ai.get("input"), "input should be captured"
        assert ai.get("output"), "output should be captured"
        assert ai.get("model"), f"model should be captured, got: {ai.get('model')}"
        assert ai.get("convoId") == convo_id


@skip_unless_e2e
class TestTokenUsage:
    """Token counts are captured and positive."""

    def test_tokens_present_and_positive(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("tokens")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Reply with just the number.")
        agent.invoke(
            {"messages": [HumanMessage(content="What is 2+2?")]},
            config={"callbacks": [rd.handler]},
        )
        rd.shutdown()

        deadline = time.time() + 90
        pt, ct = 0.0, 0.0
        while time.time() < deadline:
            all_events = _query_dashboard()
            matched = [e for e in all_events if e.get("userId") == user_id]
            for ev in matched:
                p = ev.get("properties") or {}
                pt = _num(p.get("ai.usage.prompt_tokens"))
                ct = _num(p.get("ai.usage.completion_tokens"))
                if pt > 0 and ct > 0:
                    break
            if pt > 0 and ct > 0:
                break
            time.sleep(5)
        assert pt > 0, f"prompt_tokens should be > 0, got {pt}"
        assert ct > 0, f"completion_tokens should be > 0, got {ct}"


@skip_unless_e2e
class TestModelName:
    """Model name appears in event data."""

    def test_model_in_event(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("model")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Say hi.")
        agent.invoke(
            {"messages": [HumanMessage(content="Hello")]},
            config={"callbacks": [rd.handler]},
        )
        rd.shutdown()

        ev = poll_llm_event(user_id)
        ai = ev.get("aiData") or {}
        model_str = ai.get("model") or ""
        assert "gpt-4o" in model_str.lower(), f"Expected gpt-4o in model, got: {model_str}"


@skip_unless_e2e
class TestToolCalls:
    """Agent with real tool — verify tool calls actually surface as
    TOOL_CALL spans on the trace (not just as text in the event JSON).

    Per skill rule: 'if the framework supports tool calling, this MUST
    be verified' — we ship tools via ``interaction.track_tool`` which
    creates TOOL_CALL spans in the traces pipe.
    """

    def test_tool_agent_produces_tool_call_span(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from langchain_core.tools import tool
        from raindrop_deep_agents import RaindropDeepAgents

        @tool
        def get_weather_unique_e2e(city: str) -> str:
            """Get the current weather for a city.  Unique tool name so we
            can find the TOOL_CALL span deterministically across e2e runs."""
            return f"Sunny, 22°C in {city}"

        user_id = _make_user("tools")
        unique_marker = f"weather-marker-{RUN_ID}-{uuid.uuid4().hex[:8]}"
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(
            model=llm,
            tools=[get_weather_unique_e2e],
            system_prompt=(
                "ALWAYS call get_weather_unique_e2e when asked about weather. "
                "Keep final answer under 20 words."
            ),
        )
        result = agent.invoke(
            {"messages": [HumanMessage(
                content=f"What's the weather in Tokyo? Mention '{unique_marker}'."
            )]},
            config={"callbacks": [rd.handler]},
        )
        assert result["messages"][-1].content
        rd.shutdown()

        # 1) Event lands and carries trace_id (set by raindrop.begin()).
        rows = poll_events(user_id, min_count=1, timeout=120)
        assert len(rows) >= 1, f"Expected >= 1 event, got {len(rows)}"

        # 2) Jump straight to the trace via the root event's trace_id —
        #    deterministic and ~100x faster than brute-forcing all_traces.
        trace_id, spans = poll_spans_for_event(user_id, timeout=180, interval=10)
        assert spans, f"No spans for trace_id={trace_id}"

        tool_spans = [
            s for s in spans
            if s.get("span_type") == "TOOL_CALL"
            or "get_weather_unique_e2e" in str(s.get("attributes_string") or {})
            or "get_weather_unique_e2e" in (s.get("name") or "")
        ]
        assert tool_spans, (
            f"Expected at least one TOOL_CALL span (or one referencing "
            f"'get_weather_unique_e2e'); got span types: "
            f"{[s.get('span_type') for s in spans[:10]]}"
        )


@skip_unless_e2e
class TestSequentialCalls:
    """Multiple sequential calls produce distinct events."""

    def test_three_calls_distinct(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("seq")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Reply with just the word.")

        for word in ["alpha", "beta", "gamma"]:
            agent.invoke(
                {"messages": [HumanMessage(content=f"Say '{word}'")]},
                config={"callbacks": [rd.handler]},
            )
        rd.shutdown()

        # Each invoke produces 2 events (root chain + LLM child) → 6 total.
        # Poll until we see all three distinct inputs to avoid a flake where
        # only the latest batch has surfaced.
        deadline = time.time() + 180
        unique_inputs: set[str] = set()
        rows: list[dict] = []
        while time.time() < deadline:
            rows = [e for e in _query_dashboard() if e.get("userId") == user_id]
            unique_inputs = {
                (r.get("aiData") or {}).get("input", "")
                for r in rows
                if (r.get("aiData") or {}).get("input")
            }
            if {"Say 'alpha'", "Say 'beta'", "Say 'gamma'"}.issubset(unique_inputs):
                break
            time.sleep(5)

        assert len(rows) >= 3, f"Expected >= 3 events, got {len(rows)}"
        assert {"Say 'alpha'", "Say 'beta'", "Say 'gamma'"}.issubset(unique_inputs), (
            f"Expected all three distinct inputs to land, got: {unique_inputs}"
        )


@skip_unless_e2e
class TestConvoGrouping:
    """Events with same convo_id are grouped."""

    def test_convo_grouping(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("convo")
        convo_id = _make_convo("group")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Reply briefly.")

        agent.invoke({"messages": [HumanMessage(content="Hello")]}, config={"callbacks": [rd.handler]})
        agent.invoke({"messages": [HumanMessage(content="World")]}, config={"callbacks": [rd.handler]})
        rd.shutdown()

        rows = poll_events(user_id, min_count=2, timeout=120)
        convo_ids = [(r.get("aiData") or {}).get("convoId") for r in rows]
        assert convo_ids.count(convo_id) >= 2, f"Expected >= 2 events with convoId={convo_id}, got {convo_ids}"


@skip_unless_e2e
class TestErrorHandling:
    """Errors don't crash the integration."""

    def test_invalid_model_ships_error_event(self):
        """The integration must (1) not crash the user's pipeline and
        (2) ship a properly-shaped error event to the dashboard with
        ``error.type`` / ``error.message`` properties — proving the error
        path actually reaches the backend, not just the no-crash happy case."""
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("error")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id)

        model = ChatOpenAI(model="gpt-nonexistent-xxxxx", api_key=OPENAI_API_KEY)
        with pytest.raises(Exception):
            model.invoke(
                [HumanMessage(content="This should fail")],
                config={"callbacks": [rd.handler]},
            )

        rd.shutdown()

        deadline = time.time() + 90
        error_ev: dict = {}
        while time.time() < deadline:
            for ev in (e for e in _query_dashboard() if e.get("userId") == user_id):
                ai = ev.get("aiData") or {}
                props = ev.get("properties") or {}
                output = ai.get("output") or ""
                if "[Error]" in output or "error.type" in props:
                    error_ev = ev
                    break
            if error_ev:
                break
            time.sleep(5)

        assert error_ev, (
            f"Expected an error event for userId={user_id} (with [Error] in "
            "output or error.type in properties); none landed."
        )
        ai = error_ev.get("aiData") or {}
        props = error_ev.get("properties") or {}
        assert "[Error]" in (ai.get("output") or ""), (
            f"Error event output should start with '[Error]', got: {ai.get('output')!r}"
        )
        assert props.get("error.type"), (
            f"Error event missing error.type property; got props={list(props.keys())}"
        )
        assert props.get("error.message"), (
            f"Error event missing error.message property; got props={list(props.keys())}"
        )


@skip_unless_e2e
class TestClassAPI:
    """Full class API: invoke + identify + track_signal."""

    def test_identify_and_signal(self):
        """Verify the full class API: identify() lands as user traits and
        track_signal() lands attached to a real event (not a placeholder).
        Per skill rule #27 — every feature must be verified with dashboard
        assertions, not just exercised."""
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("classapi")
        convo_id = _make_convo("classapi")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Reply briefly.")
        agent.invoke(
            {"messages": [HumanMessage(content="What is the meaning of life?")]},
            config={"callbacks": [rd.handler]},
        )

        rd.identify(user_id=user_id, traits={"plan": "pro", "e2e": True})

        # Wait for the agent's event to land so we have a real event_id to
        # attach the signal to (skill rule: signals must point at a real event).
        ev_for_signal = poll_llm_event(user_id, timeout=120)
        attached_event_id = ev_for_signal.get("customEventId")
        assert attached_event_id, "Need a real customEventId to attach the signal to"

        signal_name = f"thumbs_up_{RUN_ID}"
        rd.track_signal(
            event_id=attached_event_id,
            name=signal_name,
            signal_type="feedback",
            sentiment="POSITIVE",
            comment="e2e test feedback signal",
        )
        rd.shutdown()

        # Verify the signal landed on the event.
        deadline = time.time() + 90
        signal_match: dict = {}
        while time.time() < deadline:
            for ev in (e for e in _query_dashboard() if e.get("userId") == user_id):
                for s in (ev.get("signals") or []):
                    if s.get("name") == signal_name:
                        signal_match = s
                        break
                if signal_match:
                    break
            if signal_match:
                break
            time.sleep(5)

        assert signal_match, (
            f"Expected signal name={signal_name!r} attached to an event for "
            f"userId={user_id}; none landed."
        )
        # The dashboard normalizes signal_type to "feedback" for our request.
        # Verify at least the name + sentiment surface — the comment / type
        # storage shape varies between schema versions so we check loosely.
        assert signal_match.get("name") == signal_name


@skip_unless_e2e
class TestFactoryFunction:
    """create_raindrop_deep_agents() factory produces identical telemetry."""

    def test_factory_e2e(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import create_raindrop_deep_agents

        user_id = _make_user("factory")
        rd = create_raindrop_deep_agents(api_key=WRITE_KEY, user_id=user_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Reply briefly.")
        result = agent.invoke(
            {"messages": [HumanMessage(content="Say 'factory test'")]},
            config={"callbacks": [rd.handler]},
        )
        assert result["messages"][-1].content
        rd.shutdown()

        ev = poll_llm_event(user_id)
        ai = ev.get("aiData") or {}
        assert ai.get("output"), "Factory-created handler should capture output"


@skip_unless_e2e
class TestMultiTurn:
    """Multi-turn conversation — each turn produces a distinct event."""

    def test_two_turns_distinct(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("multi")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id, convo_id=_make_convo("multi"))

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Keep answers under 15 words.")

        r1 = agent.invoke(
            {"messages": [HumanMessage(content="Best dish in Bangkok?")]},
            config={"callbacks": [rd.handler]},
        )

        agent.invoke(
            {"messages": [
                HumanMessage(content="Best dish in Bangkok?"),
                r1["messages"][-1],
                HumanMessage(content="Where should I eat it?"),
            ]},
            config={"callbacks": [rd.handler]},
        )
        rd.shutdown()

        # Each turn produces one event (the root chain event with chain-level
        # input/output).  Two turns → 2 events.
        rows = poll_events(user_id, min_count=2, timeout=180)
        inputs = [(r.get("aiData") or {}).get("input", "") for r in rows]
        assert any("Bangkok" in i for i in inputs), (
            f"turn 1 input should contain 'Bangkok', got: {inputs}"
        )
        assert any("eat" in i.lower() or "where" in i.lower() for i in inputs), (
            f"turn 2 input should contain follow-up, got: {inputs}"
        )


@skip_unless_e2e
class TestDebugMode:
    """Debug mode doesn't crash; telemetry still works."""

    def test_debug_flag(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("debug")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id, debug=True)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Say hello.")
        agent.invoke(
            {"messages": [HumanMessage(content="Hi")]},
            config={"callbacks": [rd.handler]},
        )
        rd.shutdown()

        rows = poll_events(user_id)
        assert len(rows) >= 1


@skip_unless_e2e
class TestTagsMetadata:
    """Tags and metadata passed in config appear in event properties."""

    def test_tags_metadata(self):
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("tags")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        llm.invoke(
            [HumanMessage(content="Say 'tagged'")],
            config={
                "callbacks": [rd.handler],
                "tags": ["e2e-test", "deep-agents"],
                "metadata": {"env": "test", "run_id": RUN_ID},
            },
        )
        rd.shutdown()

        deadline = time.time() + 90
        props: dict = {}
        while time.time() < deadline:
            all_events = _query_dashboard()
            matched = [e for e in all_events if e.get("userId") == user_id]
            for ev in matched:
                p = ev.get("properties") or {}
                if p.get("env"):
                    props = p
                    break
            if props:
                break
            time.sleep(5)

        assert props.get("env") == "test", f"Expected env='test', got props={props}"
        assert props.get("run_id") == RUN_ID


@skip_unless_e2e
class TestAsyncPath:
    """README explicitly documents async support via ``agent.ainvoke``.
    Verify the async code path produces the same telemetry shape as sync —
    not just "no crash", but a real event with input + output + model on
    the dashboard.  Per skill rule #25b: every claimed feature MUST have
    a corresponding dashboard assertion in e2e."""

    def test_ainvoke_produces_same_event_shape_as_sync(self):
        import asyncio
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("async")
        convo_id = _make_convo("async")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Reply briefly.")

        async def run():
            return await agent.ainvoke(
                {"messages": [HumanMessage(content="Async hello — name a color.")]},
                config={"callbacks": [rd.handler]},
            )
        result = asyncio.run(run())
        assert result["messages"][-1].content
        rd.shutdown()

        ev = poll_llm_event(user_id)
        ai = ev.get("aiData") or {}
        assert ai.get("input"), "async path: input should be captured"
        assert ai.get("output"), "async path: output should be captured"
        assert ai.get("model"), "async path: model should be captured"
        assert ai.get("convoId") == convo_id


@skip_unless_e2e
class TestFinishReason:
    """README claims ``ai.finish_reason`` is captured for every LLM call.
    Verify it actually lands in event properties on the dashboard.
    Per skill rule: every README claim must be verified end-to-end."""

    def test_finish_reason_in_event_properties(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("finishreason")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Reply with the single word YES.")
        agent.invoke(
            {"messages": [HumanMessage(content="Are you ready?")]},
            config={"callbacks": [rd.handler]},
        )
        rd.shutdown()

        deadline = time.time() + 120
        finish_reason = None
        while time.time() < deadline:
            for ev in (e for e in _query_dashboard() if e.get("userId") == user_id):
                fr = (ev.get("properties") or {}).get("ai.finish_reason")
                if fr:
                    finish_reason = fr
                    break
            if finish_reason:
                break
            time.sleep(5)

        assert finish_reason, (
            f"Expected ai.finish_reason in event properties for userId={user_id}; "
            "none found.  README claims this is captured for every LLM call."
        )
        # OpenAI's finish_reasons are: stop, length, tool_calls, content_filter,
        # function_call.  For a normal short reply it should be 'stop'.
        assert finish_reason in {"stop", "length", "tool_calls", "content_filter", "function_call", "end_turn"}, (
            f"Unexpected finish_reason: {finish_reason!r}"
        )


@skip_unless_e2e
class TestExtendedTokens:
    """README claims ``ai.usage.cached_tokens`` and ``ai.usage.thoughts_tokens``
    are captured when available from the provider.  These properties must be
    present on the event (with value >= 0) — not silently dropped.

    Note: cached_tokens is non-zero only when OpenAI's prompt cache hits
    (long shared prefix).  For determinism we just assert the property
    *exists* (even if 0), which proves the extraction path works."""

    def test_extended_token_categories_present(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("extokens")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(model=llm, system_prompt="Reply concisely.")
        agent.invoke(
            {"messages": [HumanMessage(content="Name three primary colors.")]},
            config={"callbacks": [rd.handler]},
        )
        rd.shutdown()

        deadline = time.time() + 120
        match = None
        while time.time() < deadline:
            for ev in (e for e in _query_dashboard() if e.get("userId") == user_id):
                props = ev.get("properties") or {}
                # Look for the LLM event that carries the extended token
                # categories — distinguished by ai.usage.completion_tokens > 0.
                if (
                    "ai.usage.cached_tokens" in props
                    and "ai.usage.thoughts_tokens" in props
                    and _num(props.get("ai.usage.completion_tokens")) > 0
                ):
                    match = ev
                    break
            if match:
                break
            time.sleep(5)

        assert match, (
            f"Expected at least one event with both ai.usage.cached_tokens "
            f"and ai.usage.thoughts_tokens for userId={user_id}; none found."
        )
        props = match["properties"]
        assert _num(props["ai.usage.cached_tokens"]) >= 0
        assert _num(props["ai.usage.thoughts_tokens"]) >= 0


@skip_unless_e2e
class TestSubagentTaskTool:
    """Deep Agents' headline feature is the ``task`` tool that spawns
    subagents.  README documents subagent isolation as best-effort but
    every subagent invocation MUST still produce events that group
    correctly under the parent's convo_id.  Per skill rule: if the
    framework supports it and the docs mention it, it must be e2e-verified."""

    def test_subagent_invocation_produces_grouped_events(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from langchain_core.tools import tool
        from raindrop_deep_agents import RaindropDeepAgents

        user_id = _make_user("subagent")
        convo_id = _make_convo("subagent")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)

        @tool
        def double(n: int) -> int:
            """Return n times two."""
            return n * 2

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        # Define a subagent so the parent agent can dispatch via the
        # built-in `task` tool.  Schema is the SubAgent TypedDict from
        # deepagents.middleware.subagents:
        # name + description + system_prompt + (optional) tools.
        subagents = [
            {
                "name": "math_helper",
                "description": "Use this for any arithmetic question.",
                "system_prompt": "You are a math expert.  Use the `double` tool when asked.",
                "tools": [double],
            }
        ]
        agent = create_deep_agent(
            model=llm,
            tools=[double],
            subagents=subagents,
            system_prompt=(
                "When asked a math question, delegate to math_helper via the "
                "task tool.  Give a one-line final answer."
            ),
        )
        result = agent.invoke(
            {"messages": [HumanMessage(content="Use math_helper to double 21.")]},
            config={"callbacks": [rd.handler]},
        )
        assert result["messages"][-1].content
        rd.shutdown()

        # We expect at least 2 events grouped by convo_id (parent + at
        # least one child LLM call inside the subagent).  All events for
        # this user MUST share the same convoId — that's the contract
        # the README makes about subagent grouping.
        rows = poll_events(user_id, min_count=2, timeout=180)
        convos = {(r.get("aiData") or {}).get("convoId") for r in rows}
        assert convos == {convo_id}, (
            f"All subagent events must share convo_id={convo_id!r}; got {convos!r}"
        )


@skip_unless_e2e
class TestTraceSpans:
    """Verify nested OTel trace spans produced by the LangChain instrumentor.

    The LangChain OTel instrumentor (activated via instruments={Instruments.LANGCHAIN})
    produces nested spans (agent_node → ChatOpenAI → tool). This test verifies they
    actually land in the dashboard via the all_traces + traces_for_id pipe proxy.
    """

    def test_tool_agent_produces_trace_spans(self):
        from deepagents import create_deep_agent
        from langchain_openai import ChatOpenAI
        from langchain_core.messages import HumanMessage
        from langchain_core.tools import tool
        from raindrop_deep_agents import RaindropDeepAgents

        @tool
        def calculate(expression: str) -> str:
            """Evaluate a math expression."""
            try:
                return str(eval(expression))
            except Exception:
                return "error"

        user_id = _make_user("traces")
        convo_id = _make_convo("traces")
        rd = RaindropDeepAgents(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)

        llm = ChatOpenAI(model=MODEL, api_key=OPENAI_API_KEY)
        agent = create_deep_agent(
            model=llm,
            tools=[calculate],
            system_prompt="Use the calculate tool for math. Keep final answer under 10 words.",
        )
        # Use a unique prompt so we can find this run's trace deterministically
        # — OTel context propagation through LangGraph callbacks does not
        # always carry the user_id baggage attribute to every span, so a
        # content-based search is more reliable.
        unique_marker = f"trace-marker-{RUN_ID}-{uuid.uuid4().hex[:8]}"
        result = agent.invoke(
            {"messages": [HumanMessage(
                content=f"What is 7 times 8? Mention the phrase '{unique_marker}' verbatim in your reply."
            )]},
            config={"callbacks": [rd.handler]},
        )
        assert result["messages"][-1].content
        rd.shutdown()

        # Jump straight to the trace via the root event's properties.trace_id.
        # raindrop.begin() sets it, so any working integration MUST surface it
        # — if not, the test fails fast (correctly identifying the bug)
        # instead of brute-forcing all_traces and timing out ambiguously.
        trace_id, mine_spans = poll_spans_for_event(user_id, timeout=180, interval=10)
        assert len(mine_spans) >= 1, (
            f"Expected >= 1 span for trace_id={trace_id}, got {len(mine_spans)}"
        )

        # Assert at least one LLM span is present and contains our marker
        # in its gen_ai.input.messages — this proves the OTel instrumentor
        # captured the actual LLM call, not just the wrapping chain.
        llm_spans_with_marker = [
            s for s in mine_spans
            if any(
                k.startswith("gen_ai.") and unique_marker in str(v)
                for k, v in (s.get("attributes_string") or {}).items()
            )
        ]
        assert llm_spans_with_marker, (
            f"Expected an LLM span containing {unique_marker!r} in gen_ai.* "
            f"attributes; got span types: "
            f"{[s.get('span_type') for s in mine_spans[:10]]}"
        )

        # Skill rule #40: assert span hierarchy — a real Deep Agents trace
        # has a nested span tree (workflow → chat → tool), not just a flat
        # list.  At least one span must be a parent (its span_id appears as
        # parent_span_id of another span).
        span_ids = {s.get("span_id") for s in mine_spans if s.get("span_id")}
        parent_links = [
            s.get("parent_span_id")
            for s in mine_spans
            if s.get("parent_span_id")
        ]
        valid_parent_links = [p for p in parent_links if p in span_ids]
        assert valid_parent_links, (
            f"Expected at least one span whose parent_span_id refers to a "
            f"sibling in the same trace.  Got {len(mine_spans)} spans, "
            f"{len(parent_links)} with parent_span_id, none of which point at "
            "another span in the trace — trace hierarchy is broken."
        )

        # Assert at least one root span (parent_span_id empty / None).
        root_spans = [s for s in mine_spans if not s.get("parent_span_id")]
        assert root_spans, (
            f"Expected at least one root span (no parent_span_id) in trace "
            f"{trace_id}; got {len(mine_spans)} spans, all with parent_span_id."
        )

        # Assert at least one span carries an LLM-meaningful operation —
        # either a span_type of LLM_GENERATION, or gen_ai.* attributes.
        # This is the skill rule #25 hasAIOperation filter that the backend
        # uses to drop spans during ingestion; if our LLM span doesn't
        # satisfy it, traces silently disappear.
        has_llm_operation = any(
            s.get("span_type") == "LLM_GENERATION"
            or any(k.startswith("gen_ai.") for k in (s.get("attributes_string") or {}))
            for s in mine_spans
        )
        assert has_llm_operation, (
            "No span has an LLM-meaningful operation marker (span_type="
            "LLM_GENERATION or gen_ai.* attributes).  Spans without one of "
            "these are silently dropped by the ingestion pipeline."
        )

        # Assert all spans have non-negative duration
        for s in mine_spans:
            duration = s.get("duration_ns", 0)
            assert duration >= 0, (
                f"Span {s.get('span_id')} has negative duration: {duration}"
            )
