"""Tests for Deep Agents Raindrop integration."""
import uuid
from typing import Any, Dict
from unittest.mock import MagicMock, patch

import pytest

from raindrop_deep_agents.handler import (
    RaindropDeepAgents,
    RaindropDeepAgentsHandler,
    _extract_llm_metadata,
    _is_internal_name,
    _safe_serialize,
    _truncate,
)


class FakeLLMResult:
    """Minimal LLMResult-like object for testing."""

    def __init__(self, text="Hello!", model=None, prompt_tokens=None, completion_tokens=None):
        msg = MagicMock()
        msg.content = text
        msg.response_metadata = {"model_name": model} if model else {}

        if prompt_tokens is not None:
            msg.usage_metadata = {
                "input_tokens": prompt_tokens,
                "output_tokens": completion_tokens,
                "total_tokens": (prompt_tokens or 0) + (completion_tokens or 0),
            }
        else:
            msg.usage_metadata = None

        gen = MagicMock()
        gen.text = text
        gen.message = msg

        self.generations = [[gen]]
        self.llm_output = {}
        if model:
            self.llm_output["model_name"] = model
        if prompt_tokens is not None:
            self.llm_output["token_usage"] = {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": (prompt_tokens or 0) + (completion_tokens or 0),
            }


class _FakeHumanMessage:
    """Minimal LangChain HumanMessage-like object for chain input/output."""
    type = "human"
    def __init__(self, content): self.content = content


class _FakeAIMessage:
    """Minimal LangChain AIMessage-like object for chain input/output."""
    type = "ai"
    def __init__(self, content): self.content = content


FAKE_LLM_SERIALIZED = {
    "id": ["langchain", "chat_models", "ChatAnthropic"],
    "name": "ChatAnthropic",
}
FAKE_TOOL_SERIALIZED = {
    "id": ["deepagents", "tools", "write_file"],
    "name": "write_file",
}
FAKE_CHAIN_SERIALIZED = {
    "id": ["langchain", "chains", "RunnableSequence"],
    "name": "RunnableSequence",
}


_raindrop_patcher = None
_mock_raindrop = None


@pytest.fixture(autouse=True)
def _mock_raindrop_module():
    """Mock the raindrop module for ALL handler tests to prevent HTTP calls.

    The interaction mock's finish() forwards kwargs to track_ai() so that
    existing tests asserting on track_ai still work with the interaction-based path.
    """
    global _raindrop_patcher, _mock_raindrop
    _raindrop_patcher = patch("raindrop_deep_agents.handler.raindrop")
    _mock_raindrop = _raindrop_patcher.start()
    _mock_raindrop.track_ai = MagicMock()
    _mock_raindrop.flush = MagicMock()
    _mock_raindrop.shutdown = MagicMock()
    _mock_raindrop.identify = MagicMock()
    _mock_raindrop.track_signal = MagicMock()
    _mock_raindrop.init = MagicMock()
    _mock_raindrop._track_ai_partial = MagicMock()
    _mock_raindrop.Instruments.LANGCHAIN = "LANGCHAIN"

    interaction = MagicMock()
    interaction.id = "mock-interaction-id"
    _mock_raindrop.begin.return_value = interaction

    yield _mock_raindrop
    _raindrop_patcher.stop()


def _make_handler(**kwargs) -> RaindropDeepAgentsHandler:
    """Create a handler — raindrop is already mocked by the autouse fixture."""
    handler = RaindropDeepAgentsHandler(
        user_id="test-user",
        **kwargs,
    )
    return handler


def _shipped_root_event(mock_raindrop) -> Dict[str, Any]:
    """Aggregate the data shipped for a ROOT event into a single dict
    matching the legacy ``track_ai`` kwargs shape.

    The handler ships root events via the interaction's partial buffer
    (Common Mistake #41 in new-integration SKILL.md), not via a
    standalone ``raindrop.track_ai`` call.  This helper lets tests keep
    asserting on shipped["input"] / ["output"] / ["model"] /
    ["properties"] regardless of which transport was used.  Falls back
    to track_ai for tests that simulate a NON-root LLM (child under a
    chain), which still uses fresh-UUID track_ai shipping.
    """
    out: Dict[str, Any] = {"properties": {}}

    interaction = mock_raindrop.begin.return_value
    if interaction.set_input.call_args is not None:
        out["input"] = interaction.set_input.call_args.args[0]
    if interaction.set_properties.call_args is not None:
        out["properties"] = interaction.set_properties.call_args.args[0]
    if interaction.finish.call_args is not None:
        out["output"] = interaction.finish.call_args.kwargs.get("output")

    for call in mock_raindrop._track_ai_partial.call_args_list:
        if not call.args:
            continue
        ai_data = getattr(call.args[0], "ai_data", None)
        model = getattr(ai_data, "model", None) if ai_data else None
        if model:
            out["model"] = model

    if mock_raindrop.track_ai.call_args is not None:
        kwargs = mock_raindrop.track_ai.call_args.kwargs
        for field in ("input", "output", "model", "user_id", "convo_id", "event"):
            if field not in out and kwargs.get(field) is not None:
                out[field] = kwargs[field]
        if not out["properties"] and kwargs.get("properties"):
            out["properties"] = kwargs["properties"]

    return out


# =============================================================================
# Helper function tests
# =============================================================================


class TestHelpers:
    """Test helper functions."""

    def test_is_internal_name_langgraph(self):
        # LangGraph is the first chain Deep Agents emits and serves as the
        # actual root span of the OpenTelemetry trace.  We MUST NOT filter
        # it — the SDK's begin() call must run before any LangGraph span
        # exists so that user_id / event_id association propagates to all
        # downstream spans.
        assert _is_internal_name("LangGraph") is False
        assert _is_internal_name("__start__") is True
        assert _is_internal_name("__end__") is True
        assert _is_internal_name("ChannelWrite") is True
        assert _is_internal_name("ChannelRead") is True

    def test_is_internal_name_branch(self):
        assert _is_internal_name("Branch:condition") is True

    def test_is_internal_name_dunder(self):
        assert _is_internal_name("__custom__") is True

    def test_is_internal_name_user_chain(self):
        assert _is_internal_name("my_agent") is False
        assert _is_internal_name("research_chain") is False

    def test_is_internal_name_channel_read_variants(self):
        assert _is_internal_name("ChannelRead<messages>") is True
        assert _is_internal_name("ChannelRead<state>") is True

    def test_is_internal_name_channel_write_variants(self):
        assert _is_internal_name("ChannelWrite<messages>") is True
        assert _is_internal_name("ChannelWrite<output>") is True

    def test_safe_serialize_dict(self):
        result = _safe_serialize({"key": "value"})
        assert '"key"' in result

    def test_safe_serialize_non_serializable(self):
        result = _safe_serialize(object())
        assert isinstance(result, str)

    def test_truncate_short(self):
        assert _truncate("short", 100) == "short"

    def test_truncate_long(self):
        result = _truncate("a" * 5000, 100)
        assert len(result) == 100
        assert result.endswith("...")


class TestExtractLLMMetadata:
    """Test the metadata extraction helper."""

    def test_extracts_from_usage_metadata(self):
        result = FakeLLMResult(
            text="Hi", model="claude-sonnet-4-20250514", prompt_tokens=10, completion_tokens=5
        )
        _meta = _extract_llm_metadata(result)
        model, output, pt, ct = _meta.model, _meta.output_text, _meta.prompt_tokens, _meta.completion_tokens
        assert model == "claude-sonnet-4-20250514"
        assert output == "Hi"
        assert pt == 10
        assert ct == 5

    def test_extracts_from_llm_output_fallback(self):
        result = FakeLLMResult(text="Hello", model="claude-3-haiku-20240307")
        result.generations[0][0].message.usage_metadata = None
        result.llm_output["token_usage"] = {
            "prompt_tokens": 20,
            "completion_tokens": 15,
        }
        _meta = _extract_llm_metadata(result)
        model, output, pt, ct = _meta.model, _meta.output_text, _meta.prompt_tokens, _meta.completion_tokens
        assert model == "claude-3-haiku-20240307"
        assert output == "Hello"
        assert pt == 20
        assert ct == 15

    def test_handles_empty_result(self):
        result = MagicMock()
        result.generations = [[]]
        result.llm_output = {}
        _meta = _extract_llm_metadata(result)
        model, output, pt, ct = _meta.model, _meta.output_text, _meta.prompt_tokens, _meta.completion_tokens
        assert model is None
        assert output is None
        assert pt is None
        assert ct is None

    def test_extracts_old_style_tokenUsage(self):
        result = FakeLLMResult(text="Old style")
        result.generations[0][0].message.usage_metadata = None
        result.llm_output = {
            "model_name": "gpt-3.5-turbo",
            "tokenUsage": {
                "promptTokens": 25,
                "completionTokens": 18,
            },
        }
        _meta = _extract_llm_metadata(result)
        model, output, pt, ct = _meta.model, _meta.output_text, _meta.prompt_tokens, _meta.completion_tokens
        assert model == "gpt-3.5-turbo"
        assert pt == 25
        assert ct == 18

    def test_extracts_finish_reason_from_generation_info(self):
        """finish_reason from generation_info."""
        result = FakeLLMResult(text="Hi", model="gpt-4o-mini")
        result.generations[0][0].generation_info = {"finish_reason": "stop"}
        meta = _extract_llm_metadata(result)
        assert meta.finish_reason == "stop"

    def test_extracts_finish_reason_from_response_metadata(self):
        """finish_reason from response_metadata when generation_info missing."""
        result = FakeLLMResult(text="Hi", model="gpt-4o-mini")
        result.generations[0][0].generation_info = None
        result.generations[0][0].message.response_metadata = {
            "finish_reason": "tool_calls",
            "model_name": "gpt-4o-mini",
        }
        meta = _extract_llm_metadata(result)
        assert meta.finish_reason == "tool_calls"

    def test_extracts_cached_tokens_new_format(self):
        """cache_read from input_token_details (new LangChain format)."""
        result = FakeLLMResult(
            text="Hi", model="gpt-4o-mini", prompt_tokens=100, completion_tokens=20,
        )
        result.generations[0][0].message.usage_metadata = {
            "input_tokens": 100,
            "output_tokens": 20,
            "input_token_details": {"cache_read": 60},
            "output_token_details": {"reasoning": 5},
        }
        meta = _extract_llm_metadata(result)
        assert meta.cached_tokens == 60
        assert meta.reasoning_tokens == 5

    def test_extracts_cached_tokens_legacy_format(self):
        """cached_tokens from prompt_tokens_details / completion_tokens_details
        (OpenAI raw legacy format)."""
        result = FakeLLMResult(text="Hi", model="gpt-4o-mini")
        result.generations[0][0].message.usage_metadata = None
        result.llm_output = {
            "model_name": "gpt-4o-mini",
            "token_usage": {
                "prompt_tokens": 100,
                "completion_tokens": 20,
                "prompt_tokens_details": {"cached_tokens": 70},
                "completion_tokens_details": {"reasoning_tokens": 8},
            },
        }
        meta = _extract_llm_metadata(result)
        assert meta.cached_tokens == 70
        assert meta.reasoning_tokens == 8


# =============================================================================
# Core functionality tests (7+)
# =============================================================================


class TestCoreFunctionality:
    """Test core callback handler functionality."""

    def test_wrapper_calls_raindrop_init(self):
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.Instruments.LANGCHAIN = "LANGCHAIN"
            RaindropDeepAgents(api_key="test-write-key", user_id="user-1")
            mock_raindrop.init.assert_called_once()
            call_kwargs = mock_raindrop.init.call_args[1]
            assert call_kwargs["api_key"] == "test-write-key"
            assert call_kwargs["tracing_enabled"] is True
            assert call_kwargs["bypass_otel_for_tools"] is True
            assert call_kwargs["auto_instrument"] is False
            assert "instruments" in call_kwargs, "instruments should be passed when tracing_enabled=True"

    def test_llm_start_and_end(self, _mock_raindrop_module):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["What is 2+2?"], run_id=run_id)
        assert str(run_id) in handler._spans

        _mock_raindrop_module.track_ai.reset_mock()
        result = FakeLLMResult(
            text="4", model="claude-sonnet-4-20250514", prompt_tokens=5, completion_tokens=3
        )
        handler.on_llm_end(result, run_id=run_id)
        # Bare LLM-as-root ships via the interaction's partial buffer
        # (Common Mistake #41), not a standalone track_ai.
        shipped = _shipped_root_event(_mock_raindrop_module)
        assert shipped.get("model") == "claude-sonnet-4-20250514"
        assert _mock_raindrop_module.begin.return_value.finish.called

    def test_chat_model_start_captures_input(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        msg = MagicMock()
        msg.type = "human"
        msg.content = "Write a todo list for my project"

        handler.on_chat_model_start(FAKE_LLM_SERIALIZED, [[msg]], run_id=run_id)
        span_data = handler._spans[str(run_id)]
        assert "todo list" in span_data.get("input", "")

    def test_chain_flow_ships_on_llm_end(self, _mock_raindrop_module):
        """In chain→LLM flows, the LLM span is processed and cleaned up."""
        handler = _make_handler()
        chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)
        handler.on_llm_start(
            FAKE_LLM_SERIALIZED, ["Hello"], run_id=llm_id, parent_run_id=chain_id
        )
        assert str(llm_id) in handler._spans
        assert handler._spans[str(llm_id)]["input"] == "Hello"

        result = FakeLLMResult(text="World", model="claude-sonnet-4-20250514")
        handler.on_llm_end(result, run_id=llm_id, parent_run_id=chain_id)
        assert str(llm_id) not in handler._spans

    def test_tool_events_cleanup(self):
        """Tool start creates span, tool end cleans it up."""
        handler = _make_handler()
        run_id = uuid.uuid4()
        parent_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["calc"], run_id=parent_id)
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED, '{"path": "/tmp/hello.txt"}',
            run_id=run_id, parent_run_id=parent_id,
        )
        assert str(run_id) in handler._spans

        handler.on_tool_end("File written", run_id=run_id)
        assert str(run_id) not in handler._spans

    def test_root_chain_event_includes_aggregated_model_and_tokens(
        self, _mock_raindrop_module,
    ):
        """When LLM calls run as children of a root chain (the standard
        Deep Agents flow), on_chain_end must ship the root event with the
        aggregated model + token usage merged in — otherwise the primary
        dashboard row (the one linked to the OTel trace) carries chain
        I/O but no LLM metadata, and the LLM metadata sits on an orphan
        event reachable only by user_id / convo_id filtering."""
        handler = _make_handler()
        chain_id = uuid.uuid4()
        llm_id_1 = uuid.uuid4()
        llm_id_2 = uuid.uuid4()

        handler.on_chain_start(
            FAKE_CHAIN_SERIALIZED,
            {"messages": [_FakeHumanMessage("Multi-step question")]},
            run_id=chain_id,
        )
        handler.on_llm_start(
            FAKE_LLM_SERIALIZED, ["Step 1"], run_id=llm_id_1, parent_run_id=chain_id,
        )
        handler.on_llm_end(
            FakeLLMResult(
                text="Step 1 answer", model="gpt-4o-mini",
                prompt_tokens=10, completion_tokens=5,
            ),
            run_id=llm_id_1, parent_run_id=chain_id,
        )
        handler.on_llm_start(
            FAKE_LLM_SERIALIZED, ["Step 2"], run_id=llm_id_2, parent_run_id=chain_id,
        )
        handler.on_llm_end(
            FakeLLMResult(
                text="Step 2 answer", model="gpt-4o-mini",
                prompt_tokens=20, completion_tokens=15,
            ),
            run_id=llm_id_2, parent_run_id=chain_id,
        )

        # Capture the interaction the handler created so we can assert on
        # its set_input / set_properties / finish calls.  The root event is
        # shipped via the interaction's partial-buffer mechanism (NOT a
        # standalone track_ai) so the SDK flushes a single coherent
        # ``track_partial`` containing input + properties + model + output
        # — see RaindropDeepAgentsHandler._ship_root_event for the rationale.
        interaction = handler._interaction or _mock_raindrop_module.begin.return_value
        interaction.set_input.reset_mock()
        interaction.set_properties.reset_mock()
        interaction.finish.reset_mock()
        _mock_raindrop_module._track_ai_partial.reset_mock()

        handler.on_chain_end(
            {"messages": [_FakeAIMessage("Final answer")]},
            run_id=chain_id,
        )

        interaction.set_input.assert_called_once_with("Multi-step question")
        sp_calls = interaction.set_properties.call_args_list
        assert sp_calls, "set_properties should have been called with aggregated tokens"
        props = sp_calls[0].args[0] if sp_calls[0].args else sp_calls[0].kwargs.get("props")
        assert props["ai.usage.prompt_tokens"] == 30  # 10 + 20
        assert props["ai.usage.completion_tokens"] == 20  # 5 + 15
        interaction.finish.assert_called_once()
        assert interaction.finish.call_args.kwargs.get("output") == "Final answer"
        partial_calls = _mock_raindrop_module._track_ai_partial.call_args_list
        partial_models = [
            getattr(c.args[0].ai_data, "model", None) if c.args else None
            for c in partial_calls
        ]
        assert "gpt-4o-mini" in partial_models, (
            f"Expected partial event with model='gpt-4o-mini', got: {partial_models}"
        )

    def test_root_chain_event_preserves_zero_token_categories(
        self, _mock_raindrop_module,
    ):
        """When child LLMs report concrete zero values for a token category
        (e.g. cached_tokens=0 when no cache hit), the root event must still
        emit that property — using truthiness would silently drop the 0 and
        diverge from on_llm_end which uses `is not None`."""
        handler = _make_handler()
        chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        handler.on_chain_start(
            FAKE_CHAIN_SERIALIZED,
            {"messages": [_FakeHumanMessage("Question")]},
            run_id=chain_id,
        )
        handler.on_llm_start(
            FAKE_LLM_SERIALIZED, ["Step"], run_id=llm_id, parent_run_id=chain_id,
        )
        result = FakeLLMResult(
            text="Answer", model="gpt-4o-mini",
            prompt_tokens=12, completion_tokens=4,
        )
        # Force cache_read=0 — common for first-call-of-the-day, etc.
        result.generations[0][0].message.usage_metadata = {
            "input_tokens": 12, "output_tokens": 4,
            "input_token_details": {"cache_read": 0},
            "output_token_details": {"reasoning": 0},
        }
        handler.on_llm_end(result, run_id=llm_id, parent_run_id=chain_id)

        interaction = handler._interaction or _mock_raindrop_module.begin.return_value
        interaction.set_properties.reset_mock()
        handler.on_chain_end(
            {"messages": [_FakeAIMessage("Final")]}, run_id=chain_id,
        )
        sp_calls = interaction.set_properties.call_args_list
        assert sp_calls, "set_properties should have been called with aggregated tokens"
        props = sp_calls[0].args[0] if sp_calls[0].args else sp_calls[0].kwargs.get("props")
        # All four categories must be present, even zero ones.
        assert "ai.usage.prompt_tokens" in props and props["ai.usage.prompt_tokens"] == 12
        assert "ai.usage.completion_tokens" in props and props["ai.usage.completion_tokens"] == 4
        assert "ai.usage.cached_tokens" in props and props["ai.usage.cached_tokens"] == 0
        assert "ai.usage.thoughts_tokens" in props and props["ai.usage.thoughts_tokens"] == 0

    def test_finish_reason_forwarded_to_properties(self, _mock_raindrop_module):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hi"], run_id=run_id)

        _mock_raindrop_module.track_ai.reset_mock()
        result = FakeLLMResult(text="Done", model="gpt-4o-mini")
        result.generations[0][0].generation_info = {"finish_reason": "stop"}
        handler.on_llm_end(result, run_id=run_id)
        props = _shipped_root_event(_mock_raindrop_module)["properties"]
        assert props.get("ai.finish_reason") == "stop"

    def test_cached_and_reasoning_tokens_forwarded_to_properties(
        self, _mock_raindrop_module,
    ):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hi"], run_id=run_id)

        _mock_raindrop_module.track_ai.reset_mock()
        result = FakeLLMResult(text="Done", model="gpt-4o-mini")
        result.generations[0][0].message.usage_metadata = {
            "input_tokens": 50,
            "output_tokens": 10,
            "input_token_details": {"cache_read": 30},
            "output_token_details": {"reasoning": 4},
        }
        handler.on_llm_end(result, run_id=run_id)
        props = _shipped_root_event(_mock_raindrop_module)["properties"]
        assert props.get("ai.usage.cached_tokens") == 30
        assert props.get("ai.usage.thoughts_tokens") == 4

    def test_token_counts_forwarded(self, _mock_raindrop_module):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        _mock_raindrop_module.track_ai.reset_mock()
        result = FakeLLMResult(
            text="Hi", model="claude-sonnet-4-20250514", prompt_tokens=10, completion_tokens=5
        )
        handler.on_llm_end(result, run_id=run_id)
        props = _shipped_root_event(_mock_raindrop_module)["properties"]
        assert props.get("ai.usage.prompt_tokens") == 10
        assert props.get("ai.usage.completion_tokens") == 5

    def test_chat_model_end_to_end(self, _mock_raindrop_module):
        handler = _make_handler()
        run_id = uuid.uuid4()

        msg = MagicMock()
        msg.type = "human"
        msg.content = "Create a file with hello world"

        handler.on_chat_model_start(FAKE_LLM_SERIALIZED, [[msg]], run_id=run_id)

        _mock_raindrop_module.track_ai.reset_mock()
        result = FakeLLMResult(
            text="I'll create the file for you.", model="claude-sonnet-4-20250514"
        )
        handler.on_llm_end(result, run_id=run_id)
        shipped = _shipped_root_event(_mock_raindrop_module)
        assert "hello world" in (shipped.get("input") or "")
        assert "create" in (shipped.get("output") or "").lower()


# =============================================================================
# Error handling tests (3+)
# =============================================================================


class TestErrorHandling:
    """Test error handling in the callback handler."""

    def test_llm_error_finalizes_root_event(self, _mock_raindrop_module):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Bad input"], run_id=run_id)
        handler.on_llm_error(RuntimeError("API error"), run_id=run_id)

        interaction = _mock_raindrop_module.begin.return_value
        interaction.finish.assert_called_once()

    def test_error_cleans_up_spans(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Bad"], run_id=run_id)

        with patch("raindrop_deep_agents.handler.raindrop"):
            handler.on_llm_error(RuntimeError("fail"), run_id=run_id)
        assert str(run_id) not in handler._spans

    def test_chain_error_finalizes(self, _mock_raindrop_module):
        handler = _make_handler()
        chain_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)

        _mock_raindrop_module.track_ai.reset_mock()
        handler.on_chain_error(RuntimeError("Chain broke"), run_id=chain_id)
        interaction = _mock_raindrop_module.begin.return_value
        interaction.finish.assert_called_once()

    def test_tool_error_finalizes(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_tool_start(FAKE_TOOL_SERIALIZED, '{"path": "/bad"}', run_id=run_id)

        # Tool error path with no parent → no interaction → falls back to
        # raindrop.track_ai (the no-interaction branch in on_tool_error).
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            handler.on_tool_error(RuntimeError("Tool broke"), run_id=run_id)
            mock_raindrop.track_ai.assert_called_once()
        assert str(run_id) not in handler._spans


# =============================================================================
# Crash protection tests (3+)
# =============================================================================


class TestCrashProtection:
    """Test crash protection — telemetry must never crash user's pipeline."""

    def test_llm_start_with_empty_prompts(self):
        handler = _make_handler()
        run_id = uuid.uuid4()
        # Should not raise
        handler.on_llm_start(FAKE_LLM_SERIALIZED, [], run_id=run_id)

    def test_chat_model_with_empty_messages(self):
        handler = _make_handler()
        run_id = uuid.uuid4()
        # Should not raise
        handler.on_chat_model_start(FAKE_LLM_SERIALIZED, [[]], run_id=run_id)

    def test_llm_end_with_null_generations(self):
        handler = _make_handler()
        run_id = uuid.uuid4()
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        result = MagicMock()
        result.generations = [[]]
        result.llm_output = None

        with patch("raindrop_deep_agents.handler.raindrop"):
            # Should not raise
            handler.on_llm_end(result, run_id=run_id)

    def test_handler_survives_raindrop_track_ai_failure(self):
        """If raindrop.track_ai raises, the handler should not crash."""
        handler = _make_handler()
        run_id = uuid.uuid4()
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.track_ai.side_effect = Exception("Network error")
            # Should not raise
            handler.on_llm_end(
                FakeLLMResult(text="Hi", model="claude-sonnet-4-20250514"), run_id=run_id
            )

    def test_non_error_objects_in_error_handlers(self):
        """Error handlers should not crash with non-BaseException objects."""
        handler = _make_handler()
        run_id = uuid.uuid4()
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)

        with patch("raindrop_deep_agents.handler.raindrop"):
            # Pass a string instead of BaseException — should not crash
            handler.on_llm_error(RuntimeError("string error"), run_id=run_id)


# =============================================================================
# Lifecycle & memory tests (3+)
# =============================================================================


class TestLifecycleMemory:
    """Test lifecycle management and memory cleanup."""

    def test_cleanup_removes_state(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Test"], run_id=run_id)
        assert str(run_id) in handler._spans

        with patch("raindrop_deep_agents.handler.raindrop"):
            result = FakeLLMResult(text="Done")
            handler.on_llm_end(result, run_id=run_id)
        assert str(run_id) not in handler._spans

    def test_multiple_requests_no_leak(self):
        handler = _make_handler()

        for i in range(10):
            run_id = uuid.uuid4()
            handler.on_llm_start(
                FAKE_LLM_SERIALIZED, [f"Request {i}"], run_id=run_id
            )

            with patch("raindrop_deep_agents.handler.raindrop"):
                result = FakeLLMResult(text=f"Response {i}")
                handler.on_llm_end(result, run_id=run_id)

        assert len(handler._spans) == 0
        assert len(handler._root_run_ids) == 0
        assert len(handler._event_ids) == 0

    def test_factory_returns_class_instance(self):
        """create_raindrop_deep_agents now returns a RaindropDeepAgents instance."""
        with patch("raindrop_deep_agents.handler.raindrop"):
            from raindrop_deep_agents import create_raindrop_deep_agents

            result = create_raindrop_deep_agents(api_key="test-key", user_id="user-1")

            assert isinstance(result, RaindropDeepAgents)
            assert isinstance(result.handler, RaindropDeepAgentsHandler)

    def test_factory_handler_has_correct_config(self):
        """Factory function wires through user_id and convo_id."""
        with patch("raindrop_deep_agents.handler.raindrop"):
            from raindrop_deep_agents import create_raindrop_deep_agents

            result = create_raindrop_deep_agents(
                api_key="test-key",
                user_id="user-1",
                convo_id="convo-xyz",
            )
            assert result.handler._convo_id == "convo-xyz"
            assert result.handler._user_id == "user-1"


# =============================================================================
# RaindropDeepAgents class tests
# =============================================================================


class TestRaindropDeepAgentsClass:
    """Test the RaindropDeepAgents class API."""

    def test_class_instantiation(self):
        with patch("raindrop_deep_agents.handler.raindrop"):
            rd = RaindropDeepAgents(api_key="test-key", user_id="user-1")
            assert isinstance(rd.handler, RaindropDeepAgentsHandler)

    def test_api_key_warning_when_missing(self):
        import warnings
        with patch("raindrop_deep_agents.handler.raindrop"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropDeepAgents()
                assert len(w) == 1
                assert "api_key not provided" in str(w[0].message)

    def test_flush_delegates_to_raindrop(self):
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            rd = RaindropDeepAgents(api_key="test-key")
            rd.flush()
            mock_raindrop.flush.assert_called_once()

    def test_shutdown_delegates_to_raindrop(self):
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            rd = RaindropDeepAgents(api_key="test-key")
            rd.shutdown()
            mock_raindrop.shutdown.assert_called_once()

    def test_identify_delegates_to_raindrop(self):
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            rd = RaindropDeepAgents(api_key="test-key")
            rd.identify(user_id="user-1", traits={"plan": "pro"})
            mock_raindrop.identify.assert_called_once_with(
                user_id="user-1", traits={"plan": "pro"}
            )

    def test_identify_does_not_crash_on_failure(self):
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.identify.side_effect = Exception("Network error")
            rd = RaindropDeepAgents(api_key="test-key")
            rd.identify(user_id="user-1")

    def test_track_signal_delegates_to_raindrop(self):
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            rd = RaindropDeepAgents(api_key="test-key")
            rd.track_signal(
                event_id="evt-1", name="thumbs_up",
                signal_type="feedback", sentiment="POSITIVE",
            )
            mock_raindrop.track_signal.assert_called_once_with(
                event_id="evt-1", name="thumbs_up",
                signal_type="feedback", timestamp=None,
                properties=None, attachment_id=None,
                comment=None, after=None, sentiment="POSITIVE",
            )

    def test_track_signal_does_not_crash_on_failure(self):
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.track_signal.side_effect = Exception("Network error")
            rd = RaindropDeepAgents(api_key="test-key")
            rd.track_signal(event_id="evt-1", name="thumbs_up")

    def test_flush_does_not_crash_on_failure(self):
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.flush.side_effect = Exception("Network error")
            rd = RaindropDeepAgents(api_key="test-key")
            rd.flush()

    def test_shutdown_does_not_crash_on_failure(self):
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.shutdown.side_effect = Exception("Network error")
            rd = RaindropDeepAgents(api_key="test-key")
            rd.shutdown()

    def test_getitem_backward_compat(self):
        import warnings as _warnings
        with patch("raindrop_deep_agents.handler.raindrop"):
            rd = RaindropDeepAgents(api_key="test-key")
            with _warnings.catch_warnings(record=True) as w:
                _warnings.simplefilter("always")
                h = rd["handler"]
                assert h is rd.handler
                assert len(w) == 1
                assert "deprecated" in str(w[0].message).lower()

    def test_getitem_raises_keyerror_for_unknown(self):
        import pytest
        with patch("raindrop_deep_agents.handler.raindrop"):
            rd = RaindropDeepAgents(api_key="test-key")
            with pytest.raises(KeyError):
                rd["nonexistent"]

    def test_tracing_enabled_passed_to_init(self):
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            RaindropDeepAgents(api_key="test-key", tracing_enabled=False)
            mock_raindrop.init.assert_called_once()
            call_kwargs = mock_raindrop.init.call_args[1]
            assert call_kwargs["tracing_enabled"] is False

    def test_bypass_otel_for_tools_passed_to_init(self):
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            RaindropDeepAgents(api_key="test-key", bypass_otel_for_tools=False)
            mock_raindrop.init.assert_called_once()
            call_kwargs = mock_raindrop.init.call_args[1]
            assert call_kwargs["bypass_otel_for_tools"] is False

    def test_factory_returns_working_instance_when_init_raises(self):
        """When raindrop.init raises (e.g. wrapt 2.x propagating an
        instrumentor error someday) the constructor's defensive guard
        catches it and returns a usable instance with telemetry disabled.
        The factory's outer try/except never sees the error."""
        import warnings as _warnings
        from raindrop_deep_agents import create_raindrop_deep_agents
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.init.side_effect = Exception("boom")
            mock_raindrop.Instruments.LANGCHAIN = "LANGCHAIN"
            with _warnings.catch_warnings(record=True) as w:
                _warnings.simplefilter("always")
                result = create_raindrop_deep_agents(api_key="test-key")
                assert isinstance(result, RaindropDeepAgents)
                assert isinstance(result.handler, RaindropDeepAgentsHandler)
                msgs = [str(x.message) for x in w]
                assert any("raindrop.init failed" in m for m in msgs), (
                    f"Expected raindrop.init-failed warning, got: {msgs}"
                )

    def test_factory_returns_noop_on_construction_crash(self):
        """If construction itself raises (something OTHER than the guarded
        raindrop.init — e.g. a programming bug in the wrapper), the
        factory catches it and falls back to an object.__new__ no-op
        instance so the user's app does not crash."""
        import warnings as _warnings
        from raindrop_deep_agents import create_raindrop_deep_agents
        # Patch the class itself so __init__ raises the first call.
        original_init = RaindropDeepAgents.__init__
        call_count = [0]
        def boom_init(self, *args, **kwargs):
            call_count[0] += 1
            if call_count[0] == 1:
                raise RuntimeError("simulated wrapper-level init crash")
            return original_init(self, *args, **kwargs)
        with patch.object(RaindropDeepAgents, "__init__", boom_init):
            with patch("raindrop_deep_agents.handler.raindrop"):
                with _warnings.catch_warnings(record=True) as w:
                    _warnings.simplefilter("always")
                    result = create_raindrop_deep_agents(api_key="test-key")
                    assert isinstance(result, RaindropDeepAgents)
                    assert isinstance(result.handler, RaindropDeepAgentsHandler)

    def test_factory_noop_handler_user_id_matches_normal_init(self):
        """The double-failure no-op path must mirror the normal __init__
        contract: the handler's _user_id is `user_id or "unknown"`, never
        bare None.  Otherwise the no-op path silently diverges from the
        invariant the normal path establishes."""
        import warnings as _warnings
        from raindrop_deep_agents import create_raindrop_deep_agents
        original_init = RaindropDeepAgents.__init__
        def always_boom(self, *args, **kwargs):
            raise RuntimeError("forced into double-failure no-op path")
        with patch.object(RaindropDeepAgents, "__init__", always_boom):
            with patch("raindrop_deep_agents.handler.raindrop"):
                with _warnings.catch_warnings():
                    _warnings.simplefilter("ignore")
                    # No explicit user_id → handler should default to "unknown"
                    # exactly like the normal RaindropDeepAgents.__init__ does.
                    rd_no_user = create_raindrop_deep_agents(api_key="test-key")
                    assert rd_no_user._user_id == "unknown"
                    assert rd_no_user._handler._user_id == "unknown"

                    # Explicit user_id → both wrapper and handler reflect it.
                    rd_with_user = create_raindrop_deep_agents(
                        api_key="test-key", user_id="alice",
                    )
                    assert rd_with_user._user_id == "alice"
                    assert rd_with_user._handler._user_id == "alice"

    def test_debug_flag_sets_logger_level(self):
        import logging
        with patch("raindrop_deep_agents.handler.raindrop"):
            rd = RaindropDeepAgents(api_key="test-key", debug=True)
            from raindrop_deep_agents.handler import logger
            assert logger.level == logging.DEBUG

    def test_raindrop_init_failure_does_not_crash_construction(self):
        """If ``raindrop.init`` raises (e.g. wrapt 2.x propagating an
        instrumentor activation error someday) the user's app must not
        crash — telemetry must degrade gracefully with a single warning."""
        import warnings as _warnings
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.init.side_effect = TypeError(
                "wrap_function_wrapper() got an unexpected keyword argument 'module'"
            )
            mock_raindrop.Instruments.LANGCHAIN = "LANGCHAIN"
            with _warnings.catch_warnings(record=True) as w:
                _warnings.simplefilter("always")
                rd = RaindropDeepAgents(api_key="test-key", user_id="alice")
                # Construction succeeded — handler still usable.
                assert rd._user_id == "alice"
                assert isinstance(rd._handler, RaindropDeepAgentsHandler)
                # User got a clear warning about disabled telemetry.
                msgs = [str(x.message) for x in w]
                assert any("raindrop.init failed" in m for m in msgs), (
                    f"Expected init-failed warning, got: {msgs}"
                )

    def test_debug_false_does_not_downgrade_existing_debug_level(self):
        """The module logger is shared across instances.  A second instance
        constructed with debug=False must NOT silently silence DEBUG
        output that an earlier instance enabled — that would be a
        confusing global side effect."""
        import logging
        from raindrop_deep_agents.handler import logger
        original_level = logger.level
        try:
            with patch("raindrop_deep_agents.handler.raindrop"):
                # First instance enables DEBUG.
                RaindropDeepAgents(api_key="test-key", debug=True)
                assert logger.level == logging.DEBUG

                # Second instance with debug=False must not downgrade.
                RaindropDeepAgents(api_key="test-key", debug=False)
                assert logger.level == logging.DEBUG, (
                    "logger.setLevel(WARNING) for debug=False would silently "
                    "kill DEBUG output enabled by an earlier instance"
                )
        finally:
            logger.setLevel(original_level)

    def test_handler_property_returns_same_instance(self):
        with patch("raindrop_deep_agents.handler.raindrop"):
            rd = RaindropDeepAgents(api_key="test-key")
            assert rd.handler is rd.handler  # property returns same instance

    def test_last_event_id_none_until_root_ships(self, _mock_raindrop_module):
        """``last_event_id`` should return None before any root event has
        shipped, so callers can safely guard on it."""
        rd = RaindropDeepAgents(api_key="test-key", user_id="u1")
        assert rd.last_event_id is None

    def test_last_event_id_set_after_root_chain_ships(self, _mock_raindrop_module):
        """After a root chain ships via _ship_root_event, ``last_event_id``
        must return the event_id of that event — so callers can attach a
        track_signal() without polling events.list.  This is the public
        contract documented on the property."""
        rd = RaindropDeepAgents(api_key="test-key", user_id="u1")
        run_id = uuid.uuid4()

        rd.handler.on_chain_start(
            FAKE_CHAIN_SERIALIZED,
            {"messages": [_FakeHumanMessage("Hello")]},
            run_id=run_id, name="LangGraph",
        )
        rd.handler.on_chain_end(
            {"messages": [_FakeAIMessage("Hi")]}, run_id=run_id,
        )

        assert rd.last_event_id is not None, (
            "last_event_id should be set after on_chain_end ships the root"
        )
        # And it's the SAME event_id the interaction was created with.
        begin_event_id = _mock_raindrop_module.begin.call_args.kwargs.get("event_id")
        assert rd.last_event_id == begin_event_id, (
            f"last_event_id ({rd.last_event_id}) should match the "
            f"interaction's event_id ({begin_event_id})"
        )

    def test_last_event_id_set_after_root_error(self, _mock_raindrop_module):
        """Errors go through the same partial-buffer mechanism (Common
        Mistake #41 applies to the error path too), so ``last_event_id``
        should be populated after a root error too — callers can still
        attach a feedback signal to the failed run."""
        rd = RaindropDeepAgents(api_key="test-key", user_id="u1")
        run_id = uuid.uuid4()

        rd.handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hi"], run_id=run_id)
        rd.handler.on_llm_error(RuntimeError("boom"), run_id=run_id)

        assert rd.last_event_id is not None, (
            "last_event_id should be set after root error ships"
        )


# =============================================================================
# Deep Agents-specific tests
# =============================================================================


class TestDeepAgentsSpecific:
    """Test Deep Agents-specific functionality."""

    def test_filters_langgraph_internal_chains(self):
        handler = _make_handler()

        # Internal chain should not create a span
        internal_id = uuid.uuid4()
        handler.on_chain_start(
            {"id": ["langgraph", "__start__"], "name": "__start__"},
            {},
            run_id=internal_id,
            name="__start__",
        )
        assert str(internal_id) not in handler._spans

        # User chain should create a span
        user_id = uuid.uuid4()
        handler.on_chain_start(
            FAKE_CHAIN_SERIALIZED, {}, run_id=user_id, name="my_agent"
        )
        assert str(user_id) in handler._spans

    def test_deep_agents_tool_calls_tracked(self):
        """Deep Agents tools (write_file, read_file, execute, task) are tracked."""
        handler = _make_handler()
        parent_id = uuid.uuid4()
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Do stuff"], run_id=parent_id)

        # write_file tool
        write_id = uuid.uuid4()
        handler.on_tool_start(
            {"id": ["deepagents", "tools", "write_file"], "name": "write_file"},
            '{"path": "/tmp/test.py", "content": "print(1)"}',
            run_id=write_id,
            parent_run_id=parent_id,
        )
        assert str(write_id) in handler._spans
        assert handler._spans[str(write_id)]["name"] == "write_file"

        handler.on_tool_end("File written", run_id=write_id)
        assert str(write_id) not in handler._spans

    def test_subagent_task_tool_tracked(self):
        """Deep Agents 'task' tool (subagent delegation) is tracked."""
        handler = _make_handler()
        parent_id = uuid.uuid4()
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Delegate"], run_id=parent_id)

        task_id = uuid.uuid4()
        handler.on_tool_start(
            {"id": ["deepagents", "tools", "task"], "name": "task"},
            '{"agent": "researcher", "input": "Find docs"}',
            run_id=task_id,
            parent_run_id=parent_id,
        )
        assert str(task_id) in handler._spans
        assert handler._spans[str(task_id)]["name"] == "task"

    def test_execute_tool_tracked(self):
        """Deep Agents 'execute' tool (shell command) is tracked."""
        handler = _make_handler()
        parent_id = uuid.uuid4()
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Run command"], run_id=parent_id)

        exec_id = uuid.uuid4()
        handler.on_tool_start(
            {"id": ["deepagents", "tools", "execute"], "name": "execute"},
            '{"command": "ls -la"}',
            run_id=exec_id,
            parent_run_id=parent_id,
        )
        assert handler._spans[str(exec_id)]["name"] == "execute"
        assert "ls -la" in handler._spans[str(exec_id)]["input"]

    def test_non_root_chain_spans_are_not_tracked(self, _mock_raindrop_module):
        """Non-root chain spans don't produce dashboard data on their own —
        their LLM children's data flows up to the root chain via the
        aggregate (model + tokens), and tool calls flow via
        interaction.track_tool().  Storing per-non-root-chain span entries
        in ``_spans`` would just be dead bookkeeping, so we skip it."""
        handler = _make_handler()
        root_chain_id = uuid.uuid4()
        child_chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=root_chain_id)
        assert str(root_chain_id) in handler._spans
        assert handler._spans[str(root_chain_id)]["type"] == "chain"

        handler.on_chain_start(
            FAKE_CHAIN_SERIALIZED, {}, run_id=child_chain_id,
            parent_run_id=root_chain_id,
        )
        assert str(child_chain_id) not in handler._spans

        handler.on_llm_start(
            FAKE_LLM_SERIALIZED, ["Hello"], run_id=llm_id,
            parent_run_id=root_chain_id,
        )
        assert str(llm_id) in handler._spans

        result = FakeLLMResult(text="World")
        handler.on_llm_end(result, run_id=llm_id, parent_run_id=root_chain_id)
        assert str(llm_id) not in handler._spans

    def test_agent_action_and_finish(self):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Plan the project"], run_id=run_id)

        action = MagicMock()
        action.tool = "write_todos"
        action.tool_input = "Setup project"

        handler.on_agent_action(action, run_id=run_id)
        span_key = f"{run_id}:agent_action"
        assert span_key in handler._spans
        assert handler._spans[span_key]["tool"] == "write_todos"

        finish = MagicMock()
        finish.return_values = {"output": "Todos created"}

        handler.on_agent_finish(finish, run_id=run_id)
        assert span_key not in handler._spans

    def test_does_not_double_track_same_run_id(self):
        """Duplicate LLM start with same runId should be ignored."""
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["First call"], run_id=run_id)
        span_after_first = dict(handler._spans[str(run_id)])

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Duplicate call"], run_id=run_id)
        span_after_second = dict(handler._spans[str(run_id)])

        # Should still have the first call's data
        assert span_after_first["input"] == span_after_second["input"]

    def test_convo_id_forwarded(self, _mock_raindrop_module):
        handler = _make_handler(convo_id="deep-agents-session-123")
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hello"], run_id=run_id)

        result = FakeLLMResult(text="Hi", model="claude-sonnet-4-20250514")
        handler.on_llm_end(result, run_id=run_id)
        # convo_id is forwarded into raindrop.begin() at interaction
        # creation time (Common Mistake #41 — root events ship via
        # the interaction's partial buffer, not via track_ai).
        begin_call = _mock_raindrop_module.begin.call_args
        assert begin_call is not None, "raindrop.begin() should have been called for the root LLM"
        assert begin_call.kwargs.get("convo_id") == "deep-agents-session-123"

    def test_tags_and_metadata_forwarded(self, _mock_raindrop_module):
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(
            FAKE_LLM_SERIALIZED,
            ["Hello"],
            run_id=run_id,
            tags=["production", "deep-agents"],
            metadata={"session_id": "sess-123"},
        )

        result = FakeLLMResult(text="Hi", model="claude-sonnet-4-20250514")
        handler.on_llm_end(result, run_id=run_id)
        props = _shipped_root_event(_mock_raindrop_module)["properties"]
        assert props["deep_agents.tags"] == ["production", "deep-agents"]
        assert props["session_id"] == "sess-123"

    def test_chat_model_with_content_objects(self):
        """Messages with Content objects (not just strings) are handled."""
        handler = _make_handler()
        run_id = uuid.uuid4()

        msg = MagicMock()
        msg.type = "human"
        msg.content = [
            {"type": "text", "text": "What is in this image?"},
            {"type": "image_url", "image_url": "data:..."},
        ]

        handler.on_chat_model_start(FAKE_LLM_SERIALIZED, [[msg]], run_id=run_id)
        span_data = handler._spans[str(run_id)]
        assert "image" in span_data.get("input", "")


# =============================================================================
# Tool span shipping tests (on_tool_end behavior)
# =============================================================================


class TestToolSpanShipping:
    """Verify on_tool_end ships ai_tool_call events with correct shape."""

    def test_on_tool_end_ships_track_tool_via_interaction(self, _mock_raindrop_module):
        """on_tool_end must ship via interaction.track_tool when an interaction
        is active (the normal case under any chain root).  This produces a
        proper TOOL_CALL span linked to the root event so the dashboard's
        "Tool calls" section populates correctly."""
        handler = _make_handler(convo_id="test-convo")
        parent_id = uuid.uuid4()
        tool_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Do stuff"], run_id=parent_id)
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED,
            '{"path": "/tmp/hello.txt", "content": "hello"}',
            run_id=tool_id,
            parent_run_id=parent_id,
        )

        interaction = _mock_raindrop_module.begin.return_value
        interaction.track_tool.reset_mock()
        handler.on_tool_end("File written", run_id=tool_id)
        interaction.track_tool.assert_called_once()
        kwargs = interaction.track_tool.call_args.kwargs
        assert kwargs["name"] == "write_file"
        assert "/tmp/hello.txt" in (kwargs["input"] or "")
        assert kwargs["output"] == "File written"
        assert kwargs.get("duration_ms") is not None

    def test_on_tool_end_passes_input_field(self, _mock_raindrop_module):
        """on_tool_end forwards the tool input verbatim to track_tool."""
        handler = _make_handler()
        parent_id = uuid.uuid4()
        tool_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Do stuff"], run_id=parent_id)
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED,
            '{"path": "/tmp/hello.txt"}',
            run_id=tool_id, parent_run_id=parent_id,
        )

        interaction = _mock_raindrop_module.begin.return_value
        interaction.track_tool.reset_mock()
        handler.on_tool_end("File written", run_id=tool_id)
        kwargs = interaction.track_tool.call_args.kwargs
        assert kwargs["input"] == '{"path": "/tmp/hello.txt"}'

    def test_on_tool_end_with_none_output(self, _mock_raindrop_module):
        """on_tool_end handles None output gracefully."""
        handler = _make_handler()
        parent_id = uuid.uuid4()
        tool_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Do stuff"], run_id=parent_id)
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED, '{"path": "/tmp/f.txt"}',
            run_id=tool_id, parent_run_id=parent_id,
        )

        interaction = _mock_raindrop_module.begin.return_value
        interaction.track_tool.reset_mock()
        handler.on_tool_end(None, run_id=tool_id)
        interaction.track_tool.assert_called_once()
        kwargs = interaction.track_tool.call_args.kwargs
        assert kwargs["output"] is None

    def test_on_tool_end_truncates_long_output(self, _mock_raindrop_module):
        """Very long tool output is truncated before shipping."""
        handler = _make_handler()
        parent_id = uuid.uuid4()
        tool_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Run"], run_id=parent_id)
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED, '{"cmd": "ls"}',
            run_id=tool_id, parent_run_id=parent_id,
        )

        interaction = _mock_raindrop_module.begin.return_value
        interaction.track_tool.reset_mock()
        long_output = "x" * 10000
        handler.on_tool_end(long_output, run_id=tool_id)
        kwargs = interaction.track_tool.call_args.kwargs
        assert len(kwargs["output"]) <= 4096
        assert kwargs["output"].endswith("...")

    def test_on_tool_end_falls_back_to_track_ai_without_interaction(self):
        """If no interaction is active (e.g. tool fires outside a chain root)
        the handler falls back to a standalone ai_tool_call event so data
        still lands somewhere instead of being silently dropped."""
        handler = _make_handler(convo_id="test-convo")
        tool_id = uuid.uuid4()

        # No on_llm_start / on_chain_start → no interaction is created.
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED, '{"path": "/tmp/x"}', run_id=tool_id,
        )
        assert handler._interaction is None

        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            handler.on_tool_end("ok", run_id=tool_id)
            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["event"] == "ai_tool_call"
            assert kwargs["user_id"] == "test-user"
            assert kwargs["convo_id"] == "test-convo"
            assert kwargs["output"] == "ok"
            assert kwargs["properties"]["tool.name"] == "write_file"
            assert kwargs["properties"]["tool.input"] == '{"path": "/tmp/x"}'

    def test_on_tool_error_uses_interaction_track_tool(self, _mock_raindrop_module):
        """Tool errors under an active interaction ship via interaction.track_tool
        with the error kwarg, so the dashboard shows a failed tool span linked
        to the root event."""
        handler = _make_handler()
        parent_id = uuid.uuid4()
        tool_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Run"], run_id=parent_id)
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED, '{"path": "/bad"}',
            run_id=tool_id, parent_run_id=parent_id,
        )

        interaction = _mock_raindrop_module.begin.return_value
        interaction.track_tool.reset_mock()
        err = RuntimeError("disk full")
        handler.on_tool_error(err, run_id=tool_id)
        interaction.track_tool.assert_called_once()
        kwargs = interaction.track_tool.call_args.kwargs
        assert kwargs["name"] == "write_file"
        assert kwargs["error"] is err
        assert kwargs.get("duration_ms") is not None

    def test_on_tool_end_each_call_independently_tracked(self, _mock_raindrop_module):
        """Each tool call produces a separate track_tool invocation under the
        same root interaction.  The interaction's underlying span exporter is
        responsible for giving each call a distinct span_id."""
        handler = _make_handler()
        parent_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Do stuff"], run_id=parent_id)

        interaction = _mock_raindrop_module.begin.return_value
        interaction.track_tool.reset_mock()

        for i in range(3):
            tool_id = uuid.uuid4()
            handler.on_tool_start(
                {"id": ["deepagents", "tools", "execute"], "name": "execute"},
                f'{{"cmd": "echo {i}"}}',
                run_id=tool_id, parent_run_id=parent_id,
            )
            handler.on_tool_end(f"output-{i}", run_id=tool_id)

        assert interaction.track_tool.call_count == 3
        outputs = [c.kwargs["output"] for c in interaction.track_tool.call_args_list]
        assert outputs == ["output-0", "output-1", "output-2"]


# =============================================================================
# _track_error for non-root runs
# =============================================================================


class TestTrackErrorNonRoot:
    """Verify _track_error fires correctly for non-root runs."""

    def test_non_root_llm_error_ships_with_fresh_event_id(self):
        """A child LLM error should ship with a new event_id, not the root's."""
        handler = _make_handler()
        chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id)
        handler.on_llm_start(
            FAKE_LLM_SERIALIZED, ["Bad"], run_id=llm_id, parent_run_id=chain_id
        )

        root_event_id = handler._event_ids.get(str(chain_id))

        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            handler.on_llm_error(RuntimeError("fail"), run_id=llm_id)
            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["event_id"] != root_event_id
            assert kwargs["properties"]["error.type"] == "RuntimeError"
            assert kwargs["properties"]["error.message"] == "fail"
            assert "[Error] RuntimeError: fail" in kwargs["output"]

    def test_non_root_tool_error_ships_with_fresh_event_id(self):
        """A child tool error should ship with a new event_id."""
        handler = _make_handler()
        parent_id = uuid.uuid4()
        tool_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Run"], run_id=parent_id)
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED, '{"path": "/bad"}',
            run_id=tool_id, parent_run_id=parent_id,
        )

        root_event_id = handler._event_ids.get(str(parent_id))

        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            handler.on_tool_error(RuntimeError("Tool fail"), run_id=tool_id)
            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["event_id"] != root_event_id

    def test_root_error_ships_via_interaction_partial_buffer(self, _mock_raindrop_module):
        """A root LLM/chain error must route through the interaction's
        partial buffer (Common Mistake #41) — not via a standalone
        ``track_ai`` that would be masked by the subsequent
        ``interaction.finish()`` partial-flush.

        The error data (output=[Error] ..., properties={error.type, error.message})
        must be attached via ``set_properties`` + ``finish(output=...)`` so
        the SDK flushes a single coherent partial-event with the error
        details.  Verified on the dashboard: without this, the canonical
        row ends up with only convo_id + trace_id and the error is invisible.
        """
        handler = _make_handler()
        run_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Bad"], run_id=run_id)
        interaction = _mock_raindrop_module.begin.return_value
        interaction.set_properties.reset_mock()
        interaction.finish.reset_mock()
        _mock_raindrop_module.track_ai.reset_mock()

        handler.on_llm_error(RuntimeError("fail"), run_id=run_id)

        # Root error path: NO bare track_ai call (that would be masked).
        _mock_raindrop_module.track_ai.assert_not_called()
        # Error props shipped via interaction.set_properties.
        interaction.set_properties.assert_called_once()
        props = interaction.set_properties.call_args.args[0]
        assert props.get("error.type") == "RuntimeError"
        assert props.get("error.message") == "fail"
        # Error output shipped via interaction.finish(output=[Error] ...).
        interaction.finish.assert_called_once()
        assert "[Error]" in interaction.finish.call_args.kwargs.get("output", "")
        assert "RuntimeError" in interaction.finish.call_args.kwargs.get("output", "")

    def test_track_error_with_no_event_id_is_noop(self):
        """_track_error should silently no-op when no event_id exists."""
        handler = _make_handler()
        run_id = uuid.uuid4()

        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            handler.on_llm_error(RuntimeError("orphan"), run_id=run_id)
            mock_raindrop.track_ai.assert_not_called()


# =============================================================================
# Null/None handling at extraction points
# =============================================================================


class TestNullHandling:
    """Verify None/null edge cases in metadata extraction and handlers."""

    def test_extract_llm_metadata_with_none_generations(self):
        """_extract_llm_metadata handles response.generations = None."""
        result = MagicMock()
        result.generations = None
        result.llm_output = {}
        _meta = _extract_llm_metadata(result)
        model, output, pt, ct = _meta.model, _meta.output_text, _meta.prompt_tokens, _meta.completion_tokens
        assert model is None
        assert output is None

    def test_extract_llm_metadata_with_none_in_generations_list(self):
        """_extract_llm_metadata handles response.generations = [None]."""
        result = MagicMock()
        result.generations = [None]
        result.llm_output = {}
        _meta = _extract_llm_metadata(result)
        model, output, pt, ct = _meta.model, _meta.output_text, _meta.prompt_tokens, _meta.completion_tokens
        assert model is None
        assert output is None

    def test_extract_llm_metadata_with_none_llm_output(self):
        """_extract_llm_metadata handles response.llm_output = None."""
        result = MagicMock()
        result.generations = [[]]
        result.llm_output = None
        _meta = _extract_llm_metadata(result)
        model, output, pt, ct = _meta.model, _meta.output_text, _meta.prompt_tokens, _meta.completion_tokens
        assert model is None
        assert pt is None

    def test_extract_llm_metadata_usage_metadata_as_object(self):
        """_extract_llm_metadata handles usage_metadata as an object (not dict)."""
        result = FakeLLMResult(text="Hi", model="test-model")
        usage = MagicMock()
        usage.input_tokens = 42
        usage.output_tokens = 7
        result.generations[0][0].message.usage_metadata = usage
        _meta = _extract_llm_metadata(result)
        model, output, pt, ct = _meta.model, _meta.output_text, _meta.prompt_tokens, _meta.completion_tokens
        assert pt == 42
        assert ct == 7

    def test_on_llm_end_without_prior_start_does_not_crash(self):
        """on_llm_end for an unknown run_id should not crash."""
        handler = _make_handler()
        run_id = uuid.uuid4()

        with patch("raindrop_deep_agents.handler.raindrop"):
            handler.on_llm_end(FakeLLMResult(text="orphan"), run_id=run_id)

    def test_on_tool_end_without_prior_start_does_not_crash(self):
        """on_tool_end for an unknown run_id should not crash."""
        handler = _make_handler()
        run_id = uuid.uuid4()

        with patch("raindrop_deep_agents.handler.raindrop"):
            handler.on_tool_end("orphan output", run_id=run_id)

    def test_get_name_from_serialized_empty_dict(self):
        from raindrop_deep_agents.handler import _get_name_from_serialized
        assert _get_name_from_serialized({}) == "unknown"

    def test_get_name_from_serialized_empty_id_list(self):
        from raindrop_deep_agents.handler import _get_name_from_serialized
        assert _get_name_from_serialized({"id": []}) == "unknown"

    def test_get_name_from_serialized_prefers_name_over_id(self):
        from raindrop_deep_agents.handler import _get_name_from_serialized
        assert _get_name_from_serialized({"name": "foo", "id": ["bar"]}) == "foo"

    def test_chat_model_start_no_user_messages_falls_back_to_last(self):
        """When no user/human messages exist, falls back to last message of any type."""
        handler = _make_handler()
        run_id = uuid.uuid4()

        system_msg = MagicMock()
        system_msg.type = "system"
        system_msg.content = "You are a helpful assistant"

        assistant_msg = MagicMock()
        assistant_msg.type = "assistant"
        assistant_msg.content = "I'll help you with that"

        handler.on_chat_model_start(FAKE_LLM_SERIALIZED, [[system_msg, assistant_msg]], run_id=run_id)
        span_data = handler._spans[str(run_id)]
        assert span_data["input"] == "I'll help you with that"

    def test_chat_model_start_with_none_content(self):
        """Message with None content should not crash."""
        handler = _make_handler()
        run_id = uuid.uuid4()

        msg = MagicMock()
        msg.type = "human"
        msg.content = None

        handler.on_chat_model_start(FAKE_LLM_SERIALIZED, [[msg]], run_id=run_id)
        span_data = handler._spans[str(run_id)]
        assert span_data["input"] is None

    def test_internal_chain_end_is_noop(self):
        """on_chain_end for a filtered internal chain should not call track_ai."""
        handler = _make_handler()
        internal_id = uuid.uuid4()

        handler.on_chain_start(
            {"id": ["langgraph", "__start__"], "name": "__start__"},
            {},
            run_id=internal_id,
            name="__start__",
        )

        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            handler.on_chain_end({}, run_id=internal_id)
            mock_raindrop.track_ai.assert_not_called()

    def test_filtered_internal_chain_end_no_track_ai(self, _mock_raindrop_module):
        """Filtered internal chain end must not call track_ai (no ghost event).

        When on_chain_start filters out a LangGraph internal (e.g. __start__),
        the matching on_chain_end fires _cleanup but the run was never
        registered in _root_run_ids.  _cleanup must not ship a track_ai event
        and must not finish any interaction the real root may have created.
        """
        handler = _make_handler()
        internal_chain_id = uuid.uuid4()

        handler.on_chain_start(
            {"id": ["langgraph", "__start__"], "name": "__start__"},
            {},
            run_id=internal_chain_id,
            name="__start__",
        )
        _mock_raindrop_module.track_ai.reset_mock()
        handler.on_chain_end({}, run_id=internal_chain_id)
        _mock_raindrop_module.track_ai.assert_not_called()

        interaction = _mock_raindrop_module.begin.return_value
        # Filtered internal chains must NEVER finish the interaction
        interaction.finish.assert_not_called()

    def test_child_llm_under_filtered_chain_still_ships(self, _mock_raindrop_module):
        """LLM nested under a filtered internal chain still ships a track_ai event.

        Matches the LangChain reference behavior: every on_llm_end ships a
        track_ai event.  If the LLM is not root, a fresh event_id is generated
        instead of reusing the root's.  This ensures no LLM data is silently
        dropped even when its parent chain was filtered.
        """
        handler = _make_handler()
        internal_chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()

        handler.on_chain_start(
            {"id": ["langgraph", "__start__"], "name": "__start__"},
            {},
            run_id=internal_chain_id,
            name="__start__",
        )
        handler.on_llm_start(
            FAKE_LLM_SERIALIZED, ["Hello"],
            run_id=llm_id, parent_run_id=internal_chain_id,
        )

        _mock_raindrop_module.track_ai.reset_mock()
        handler.on_llm_end(
            FakeLLMResult(text="World", model="gpt-4o"),
            run_id=llm_id, parent_run_id=internal_chain_id,
        )
        _mock_raindrop_module.track_ai.assert_called_once()

    def test_agent_action_with_dict_tool_input(self):
        """on_agent_action with dict tool_input serializes via _safe_serialize."""
        handler = _make_handler()
        run_id = uuid.uuid4()
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Plan"], run_id=run_id)

        action = MagicMock()
        action.tool = "write_file"
        action.tool_input = {"path": "/tmp/test.py", "content": "print(1)"}

        handler.on_agent_action(action, run_id=run_id)
        span_key = f"{run_id}:agent_action"
        assert span_key in handler._spans
        assert "/tmp/test.py" in handler._spans[span_key]["tool_input"]

    def test_noop_factory_instance_has_correct_attrs(self):
        """Double-failure no-op instance has _user_id, _convo_id, _debug set."""
        from raindrop_deep_agents import create_raindrop_deep_agents
        import warnings as _warnings
        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.init.side_effect = Exception("boom")
            with _warnings.catch_warnings(record=True):
                _warnings.simplefilter("always")
                result = create_raindrop_deep_agents(
                    api_key="test-key", user_id="u1", convo_id="c1", debug=True,
                )
                assert result._user_id == "u1"
                assert result._convo_id == "c1"
                assert result._debug is True

    def test_extract_llm_metadata_with_none_response_metadata(self):
        """response_metadata explicitly set to None should not crash."""
        result = FakeLLMResult(text="Hi", model="test-model")
        result.generations[0][0].message.response_metadata = None
        _meta = _extract_llm_metadata(result)
        model, output, pt, ct = _meta.model, _meta.output_text, _meta.prompt_tokens, _meta.completion_tokens
        assert output == "Hi"
        assert model == "test-model"

    def test_build_properties_empty_tags(self):
        """_build_properties with empty tags list returns None."""
        result = RaindropDeepAgentsHandler._build_properties(tags=[], metadata=None)
        assert result is None

    def test_build_properties_empty_metadata(self):
        """_build_properties with empty metadata dict returns None."""
        result = RaindropDeepAgentsHandler._build_properties(tags=None, metadata={})
        assert result is None


# =============================================================================
# Extra kwargs forwarding (handlers must accept arbitrary kwargs)
# =============================================================================


class TestKwargsForwarding:
    """Verify that extra kwargs in callbacks don't crash."""

    def test_on_llm_start_extra_kwargs(self):
        handler = _make_handler()
        run_id = uuid.uuid4()
        handler.on_llm_start(
            FAKE_LLM_SERIALIZED, ["Hello"],
            run_id=run_id, invocation_params={"model": "x"}, extra_key="y",
        )
        assert str(run_id) in handler._spans

    def test_on_llm_end_extra_kwargs(self):
        handler = _make_handler()
        run_id = uuid.uuid4()
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["Hello"], run_id=run_id)

        with patch("raindrop_deep_agents.handler.raindrop"):
            handler.on_llm_end(
                FakeLLMResult(text="Hi"), run_id=run_id, extra_key="y",
            )

    def test_on_tool_start_extra_kwargs(self):
        handler = _make_handler()
        run_id = uuid.uuid4()
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED, '{"path": "/tmp/f.txt"}',
            run_id=run_id, extra_kwarg="value",
        )
        assert str(run_id) in handler._spans

    def test_on_chain_start_extra_kwargs(self):
        handler = _make_handler()
        run_id = uuid.uuid4()
        handler.on_chain_start(
            FAKE_CHAIN_SERIALIZED, {}, run_id=run_id, name="my_chain",
            extra_kwarg="value",
        )
        assert str(run_id) in handler._spans

    def test_on_agent_action_extra_kwargs(self):
        handler = _make_handler()
        run_id = uuid.uuid4()
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["X"], run_id=run_id)
        action = MagicMock()
        action.tool = "test_tool"
        action.tool_input = "input"
        handler.on_agent_action(action, run_id=run_id, extra_kwarg="value")


# =============================================================================
# Sequential request cleanup (memory leak prevention)
# =============================================================================


class TestSequentialCleanup:
    """Verify no memory leaks with mixed tool + LLM sequences."""

    def test_mixed_tool_llm_sequence_no_leak(self):
        """Interleaved tool and LLM requests should not leak state."""
        handler = _make_handler()

        for i in range(5):
            parent_id = uuid.uuid4()
            handler.on_llm_start(
                FAKE_LLM_SERIALIZED, [f"Request {i}"], run_id=parent_id
            )

            tool_id = uuid.uuid4()
            handler.on_tool_start(
                FAKE_TOOL_SERIALIZED, f'{{"cmd": "echo {i}"}}',
                run_id=tool_id, parent_run_id=parent_id,
            )

            with patch("raindrop_deep_agents.handler.raindrop"):
                handler.on_tool_end(f"output-{i}", run_id=tool_id)
                handler.on_llm_end(
                    FakeLLMResult(text=f"Response {i}"), run_id=parent_id
                )

        assert len(handler._spans) == 0
        assert len(handler._root_run_ids) == 0
        assert len(handler._event_ids) == 0

    def test_error_paths_no_leak(self):
        """Errors on every handler type should not leak state."""
        handler = _make_handler()

        for i in range(5):
            run_id = uuid.uuid4()
            handler.on_llm_start(
                FAKE_LLM_SERIALIZED, [f"Fail {i}"], run_id=run_id
            )
            with patch("raindrop_deep_agents.handler.raindrop"):
                handler.on_llm_error(RuntimeError(f"err-{i}"), run_id=run_id)

        for i in range(5):
            run_id = uuid.uuid4()
            handler.on_tool_start(
                FAKE_TOOL_SERIALIZED, f'{{"i": {i}}}', run_id=run_id
            )
            with patch("raindrop_deep_agents.handler.raindrop"):
                handler.on_tool_error(RuntimeError(f"tool-err-{i}"), run_id=run_id)

        for i in range(5):
            run_id = uuid.uuid4()
            handler.on_chain_start(
                FAKE_CHAIN_SERIALIZED, {}, run_id=run_id, name=f"chain_{i}"
            )
            with patch("raindrop_deep_agents.handler.raindrop"):
                handler.on_chain_error(RuntimeError(f"chain-err-{i}"), run_id=run_id)

        assert len(handler._spans) == 0
        assert len(handler._root_run_ids) == 0
        assert len(handler._event_ids) == 0

    def test_agent_action_finish_no_leak(self):
        """Agent action/finish cycles should not leak state."""
        handler = _make_handler()

        for i in range(5):
            run_id = uuid.uuid4()
            handler.on_llm_start(
                FAKE_LLM_SERIALIZED, [f"Plan {i}"], run_id=run_id
            )
            action = MagicMock()
            action.tool = "write_todos"
            action.tool_input = f"Task {i}"
            handler.on_agent_action(action, run_id=run_id)
            finish = MagicMock()
            finish.return_values = {"output": f"done-{i}"}
            handler.on_agent_finish(finish, run_id=run_id)
            with patch("raindrop_deep_agents.handler.raindrop"):
                handler.on_llm_end(
                    FakeLLMResult(text=f"Plan done {i}"), run_id=run_id
                )

        assert len(handler._spans) == 0


# =============================================================================
# Telemetry failure isolation
# =============================================================================


class TestTelemetryFailureIsolation:
    """Verify that telemetry failures never crash user code and cleanup still runs."""

    def test_tool_end_survives_raindrop_failure(self):
        """on_tool_end should not crash when raindrop.track_ai throws."""
        handler = _make_handler()
        parent_id = uuid.uuid4()
        tool_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["X"], run_id=parent_id)
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED, '{"path": "/tmp/f.txt"}',
            run_id=tool_id, parent_run_id=parent_id,
        )

        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.track_ai.side_effect = Exception("Network error")
            handler.on_tool_end("output", run_id=tool_id)

        assert str(tool_id) not in handler._spans

    def test_tool_end_failure_preserves_parent_state(self, _mock_raindrop_module):
        """When tool shipping fails, the parent LLM span should still be valid."""
        handler = _make_handler()
        parent_id = uuid.uuid4()
        tool_id = uuid.uuid4()

        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["X"], run_id=parent_id)
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED, '{"path": "/tmp/f.txt"}',
            run_id=tool_id, parent_run_id=parent_id,
        )

        _mock_raindrop_module.track_ai.side_effect = Exception("Network error")
        handler.on_tool_end("output", run_id=tool_id)

        assert str(parent_id) in handler._spans

        _mock_raindrop_module.track_ai.reset_mock()
        _mock_raindrop_module.track_ai.side_effect = None
        interaction = _mock_raindrop_module.begin.return_value
        interaction.finish.reset_mock()
        handler.on_llm_end(FakeLLMResult(text="Done"), run_id=parent_id)
        # Parent LLM is the root → ships via interaction.finish()
        # (Common Mistake #41).
        assert interaction.finish.called, (
            "Parent LLM root event should be finalized via interaction.finish()"
        )

    def test_llm_error_handler_survives_raindrop_failure_and_cleans_up(self):
        """on_llm_error should not crash and should still clean up."""
        handler = _make_handler()
        run_id = uuid.uuid4()
        handler.on_llm_start(FAKE_LLM_SERIALIZED, ["X"], run_id=run_id)

        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.track_ai.side_effect = Exception("Network error")
            handler.on_llm_error(RuntimeError("API error"), run_id=run_id)

        assert str(run_id) not in handler._spans
        assert str(run_id) not in handler._root_run_ids

    def test_chain_error_handler_survives_raindrop_failure_and_cleans_up(self):
        """on_chain_error should not crash and should still clean up."""
        handler = _make_handler()
        chain_id = uuid.uuid4()
        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id, name="my_chain")

        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.track_ai.side_effect = Exception("Network error")
            handler.on_chain_error(RuntimeError("Chain error"), run_id=chain_id)

        assert str(chain_id) not in handler._spans
        assert str(chain_id) not in handler._root_run_ids

    def test_tool_error_handler_survives_raindrop_failure_and_cleans_up(self):
        """on_tool_error should not crash and should still clean up."""
        handler = _make_handler()
        tool_id = uuid.uuid4()
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED, '{"path": "/bad"}', run_id=tool_id
        )

        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.track_ai.side_effect = Exception("Network error")
            handler.on_tool_error(RuntimeError("Tool error"), run_id=tool_id)

        assert str(tool_id) not in handler._spans

    def test_on_chain_end_survives_raindrop_failure(self):
        """on_chain_end should not crash when raindrop.track_ai throws."""
        handler = _make_handler()
        chain_id = uuid.uuid4()
        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {}, run_id=chain_id, name="my_chain")

        with patch("raindrop_deep_agents.handler.raindrop") as mock_raindrop:
            mock_raindrop.track_ai.side_effect = Exception("Network error")
            handler.on_chain_end({"out": "x"}, run_id=chain_id)

        assert str(chain_id) not in handler._spans


# =============================================================================
# Multi-modal content + chain extraction edge cases
# =============================================================================


class TestContentExtraction:
    """Verify _extract_messages_text handles all the LangChain content shapes
    that real multi-modal / vision / structured-output messages produce."""

    def test_string_content_passthrough(self):
        from raindrop_deep_agents.handler import _extract_messages_text
        msg = MagicMock()
        msg.content = "hello world"
        assert _extract_messages_text([msg]) == "hello world"

    def test_multimodal_text_only_part(self):
        """LangChain vision messages: content is a list of typed parts."""
        from raindrop_deep_agents.handler import _extract_messages_text
        msg = MagicMock()
        msg.content = [{"type": "text", "text": "describe this"}]
        assert _extract_messages_text([msg]) == "describe this"

    def test_multimodal_text_and_image(self):
        """Skip non-text parts, return concatenated text."""
        from raindrop_deep_agents.handler import _extract_messages_text
        msg = MagicMock()
        msg.content = [
            {"type": "text", "text": "Look at this"},
            {"type": "image_url", "image_url": "data:image/png;base64,..."},
            {"type": "text", "text": "and tell me what it is"},
        ]
        result = _extract_messages_text([msg])
        assert "Look at this" in result
        assert "tell me what it is" in result
        assert "data:image/png" not in result

    def test_dict_message_with_dict_content(self):
        """Some chat models pass content as a dict with a 'text' key."""
        from raindrop_deep_agents.handler import _extract_messages_text
        msg = {"type": "human", "content": {"text": "what's up?"}}
        assert _extract_messages_text([msg]) == "what's up?"

    def test_string_parts_in_list(self):
        from raindrop_deep_agents.handler import _extract_messages_text
        msg = MagicMock()
        msg.content = ["part one", "part two"]
        result = _extract_messages_text([msg])
        assert "part one" in result and "part two" in result

    def test_only_non_text_parts_falls_back_to_json(self):
        """If a list has no text parts at all, JSON dump rather than crash."""
        from raindrop_deep_agents.handler import _extract_messages_text
        msg = MagicMock()
        msg.content = [{"type": "image_url", "image_url": "data:..."}]
        result = _extract_messages_text([msg])
        assert result is not None
        assert "image_url" in result

    def test_empty_messages_returns_none(self):
        from raindrop_deep_agents.handler import _extract_messages_text
        assert _extract_messages_text([]) is None
        assert _extract_messages_text(None) is None


class TestChainInputTruncation:
    """Verify oversized chain payloads are truncated, not shipped raw."""

    def test_chain_input_truncated_to_8k(self):
        from raindrop_deep_agents.handler import _extract_chain_input, _CHAIN_TEXT_MAX_LEN
        big = "x" * 50000
        result = _extract_chain_input({"input": big})
        assert result is not None
        assert len(result) == _CHAIN_TEXT_MAX_LEN
        assert result.endswith("...")

    def test_chain_output_truncated_to_8k(self):
        from raindrop_deep_agents.handler import _extract_chain_output, _CHAIN_TEXT_MAX_LEN
        big = "y" * 50000
        result = _extract_chain_output({"output": big})
        assert result is not None
        assert len(result) == _CHAIN_TEXT_MAX_LEN

    def test_short_chain_input_not_truncated(self):
        from raindrop_deep_agents.handler import _extract_chain_input
        result = _extract_chain_input({"input": "small"})
        assert result == "small"

    def test_chain_input_with_huge_message_history_truncated(self):
        """Multi-turn chain input with 100 messages should still truncate."""
        from raindrop_deep_agents.handler import _extract_chain_input, _CHAIN_TEXT_MAX_LEN
        msgs = [_FakeHumanMessage("msg-" + str(i) * 100) for i in range(100)]
        # No human message will be selected for the LAST entry (it IS one),
        # but if all are AI we'd json-dump.  Test the AI-only fallback path:
        ai_msgs = [_FakeAIMessage("ai-" + str(i) * 100) for i in range(100)]
        result = _extract_chain_input({"messages": ai_msgs})
        # Falls through to "messages" path, last message extraction, single
        # AI message text.  Ensure the final string is bounded.
        assert result is not None
        assert len(result) <= _CHAIN_TEXT_MAX_LEN


# =============================================================================
# Idempotency + realistic Deep Agents flow
# =============================================================================


class TestRealisticDeepAgentsFlow:
    """Simulate a full root-chain → subagent chain → LLM → tool flow that
    mirrors what Deep Agents actually emits, and verify the root event
    aggregates everything correctly with no leaks."""

    def test_full_chain_llm_tool_lifecycle(self):
        handler = _make_handler()
        root_chain_id = uuid.uuid4()
        sub_chain_id = uuid.uuid4()
        llm_id = uuid.uuid4()
        tool_id = uuid.uuid4()

        # Root chain (LangGraph) starts
        handler.on_chain_start(
            {"id": ["langchain", "schema", "runnable", "RunnableSequence"], "name": "LangGraph"},
            {"messages": [_FakeHumanMessage("What is the weather in Tokyo?")]},
            run_id=root_chain_id, name="LangGraph",
        )
        # Subagent chain (e.g. agent step)
        handler.on_chain_start(
            FAKE_CHAIN_SERIALIZED,
            {"messages": [_FakeHumanMessage("What is the weather in Tokyo?")]},
            run_id=sub_chain_id, parent_run_id=root_chain_id, name="agent",
        )
        # Inner LLM call
        handler.on_llm_start(
            FAKE_LLM_SERIALIZED, ["What is the weather in Tokyo?"],
            run_id=llm_id, parent_run_id=sub_chain_id,
        )
        # Tool call (sibling of LLM)
        handler.on_tool_start(
            FAKE_TOOL_SERIALIZED, '{"city": "Tokyo"}',
            run_id=tool_id, parent_run_id=sub_chain_id,
        )
        handler.on_tool_end("Sunny, 22C", run_id=tool_id)
        # LLM completes with usage
        handler.on_llm_end(
            FakeLLMResult(text="Sunny, 22C", model="gpt-4o-mini",
                          prompt_tokens=42, completion_tokens=12),
            run_id=llm_id,
        )
        # Subagent completes
        handler.on_chain_end(
            {"messages": [_FakeAIMessage("Sunny, 22C")]},
            run_id=sub_chain_id, parent_run_id=root_chain_id,
        )
        # Root chain completes
        handler.on_chain_end(
            {"messages": [_FakeAIMessage("Sunny, 22C")]},
            run_id=root_chain_id,
        )

        # CHILD LLM ships via track_ai (fresh UUID).  ROOT chain ships via
        # interaction.set_input + set_properties + _track_ai_partial(model)
        # + finish(output) — see RaindropDeepAgentsHandler._ship_root_event.
        interaction = _mock_raindrop.begin.return_value
        ai_generation_calls = [
            c for c in _mock_raindrop.track_ai.call_args_list
            if c.kwargs.get("event") == "ai_generation"
        ]
        assert len(ai_generation_calls) == 1, (
            f"Expected exactly one track_ai for the child LLM, got {len(ai_generation_calls)}"
        )
        llm_call = ai_generation_calls[0]
        assert (llm_call.kwargs.get("properties") or {}).get("ai.usage.prompt_tokens") == 42
        assert llm_call.kwargs.get("model") == "gpt-4o-mini"

        interaction.set_input.assert_called_once()
        assert "Tokyo" in interaction.set_input.call_args.args[0]

        sp_calls = interaction.set_properties.call_args_list
        assert sp_calls, "set_properties should have been called for the root"
        root_props = sp_calls[0].args[0]
        assert root_props.get("ai.usage.prompt_tokens") == 42
        assert root_props.get("ai.usage.completion_tokens") == 12

        interaction.finish.assert_called_once()
        assert "Sunny" in interaction.finish.call_args.kwargs["output"]

        partial_models = [
            getattr(c.args[0].ai_data, "model", None) if c.args else None
            for c in _mock_raindrop._track_ai_partial.call_args_list
        ]
        assert "gpt-4o-mini" in partial_models, (
            f"Expected partial-event with model='gpt-4o-mini', got: {partial_models}"
        )

        assert len(handler._spans) == 0
        assert len(handler._root_run_ids) == 0
        assert len(handler._event_ids) == 0
        assert handler._interaction is None

    def test_on_chain_end_called_twice_does_not_double_ship(self):
        """LangChain occasionally double-fires callbacks; root cleanup should
        be idempotent and the second call should not produce a duplicate
        event nor crash."""
        handler = _make_handler()
        run_id = uuid.uuid4()
        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {"input": "hi"}, run_id=run_id, name="root")
        handler.on_chain_end({"output": "bye"}, run_id=run_id)
        first_call_count = _mock_raindrop.track_ai.call_count
        # Second on_chain_end with the same run_id — state is gone, should
        # be a no-op.
        handler.on_chain_end({"output": "bye"}, run_id=run_id)
        assert _mock_raindrop.track_ai.call_count == first_call_count, (
            "Second on_chain_end produced a duplicate track_ai call"
        )

    def test_on_tool_end_called_twice_does_not_double_ship(self):
        handler = _make_handler()
        chain_id = uuid.uuid4()
        tool_id = uuid.uuid4()
        handler.on_chain_start(FAKE_CHAIN_SERIALIZED, {"input": "x"}, run_id=chain_id, name="root")
        handler.on_tool_start(FAKE_TOOL_SERIALIZED, '{"a": 1}', run_id=tool_id, parent_run_id=chain_id)
        handler.on_tool_end("ok", run_id=tool_id)
        # When interaction is active, track_tool was called on the interaction,
        # not on raindrop.track_ai.  Capture the count and call again.
        interaction_calls = handler._interaction.track_tool.call_count
        handler.on_tool_end("ok", run_id=tool_id)
        assert handler._interaction.track_tool.call_count == interaction_calls, (
            "Second on_tool_end produced a duplicate track_tool call"
        )
