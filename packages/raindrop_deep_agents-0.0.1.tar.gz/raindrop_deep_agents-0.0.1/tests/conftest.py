"""Pytest configuration for raindrop-deep-agents.

Supports running e2e tests against either:

* Production (default) — the SDK ships events to api.raindrop.ai and
  tests verify against backend.raindrop.ai.
* Local-backend mode — set RAINDROP_LOCAL=1 to ship events to a local
  Next.js backend on localhost:3000 (which still writes through to prod
  Tinybird via doppler-supplied credentials).  Traces continue to ship
  to prod api.raindrop.ai because the local backend has no /v1/traces
  handler on main.  This mode is useful when iterating on the
  ingestion route without touching prod write paths.
"""
from __future__ import annotations

import os


def _activate_local_backend_mode() -> None:
    """Re-target the Raindrop SDK's events endpoint at a local backend."""
    if os.getenv("RAINDROP_LOCAL") not in ("1", "true", "True"):
        return

    backend_url = os.getenv("RAINDROP_LOCAL_BACKEND", "http://localhost:3000")

    # Test helpers default to querying the prod dashboard unless the user
    # explicitly points them at the local backend (which mirrors prod data
    # via doppler-managed prod Tinybird credentials).
    os.environ.setdefault("RAINDROP_BACKEND_URL", backend_url)

    # Repoint the SDK's events endpoint at the local backend.  Traces
    # continue to flow to https://api.raindrop.ai/v1/traces via the SDK's
    # default api_url, since main does not run a local trace server.
    import raindrop.analytics as raindrop_analytics
    original_init = raindrop_analytics.init

    def _patched_init(api_key, *args, **kwargs):  # type: ignore[no-untyped-def]
        # Run init with the *prod* api_url so Traceloop's api_endpoint
        # resolves to api.raindrop.ai, then point the events SDK at our
        # local backend afterwards.
        result = original_init(api_key, *args, **kwargs)
        raindrop_analytics.api_url = f"{backend_url}/api/v1/"
        return result

    raindrop_analytics.init = _patched_init


_activate_local_backend_mode()
