"""
Basic example of using the Raindrop Deep Agents integration.

Usage:
    pip install raindrop-deep-agents deepagents langchain-anthropic
    RAINDROP_WRITE_KEY=xxx python main.py
"""

import os

from raindrop_deep_agents import RaindropDeepAgents

# 1. Create the Raindrop client
rd = RaindropDeepAgents(
    api_key=os.environ.get("RAINDROP_WRITE_KEY", ""),
    user_id="example-user",
    convo_id="example-convo",
)

# 2. Pass the handler as a LangChain callback when invoking Deep Agents
#
#    from deepagents import create_deep_agent
#    from langchain_anthropic import ChatAnthropic
#
#    agent = create_deep_agent(
#        model=ChatAnthropic(model="claude-sonnet-4-20250514"),
#        tools=[...],
#    )
#
#    result = agent.invoke(
#        {"messages": [{"role": "user", "content": "Create a hello world file"}]},
#        config={"callbacks": [rd.handler]},
#    )

# 3. Shutdown before exit
rd.shutdown()
print("Done — events shipped to Raindrop.")
