"""
End-to-end verification for raindrop-deep-agents (Python).

Runs REAL Deep Agents workflows via create_deep_agent() against a real LLM,
ships telemetry via the Raindrop handler, then queries the dashboard API to
verify events were ingested with correct data.

Scenarios exercised:
  1. Basic agent invoke via create_deep_agent() — single LLM call
  2. Agent with custom tool — agent decides to call a tool, producing
     chain→LLM→tool→LLM multi-level callback hierarchy
  3. Agent with subagent (task tool) — parent delegates to child agent,
     producing nested chain→LLM→tool(task)→subagent-chain→subagent-LLM spans
  4. Multi-turn conversation — verifies per-turn input extraction
  5. Error handling — verifies error events ship
  6. identify() + track_signal() — verifies class helpers

Required env vars:
    RAINDROP_WRITE_KEY (or RAINDROP_API_KEY)
    OPENAI_API_KEY
    RAINDROP_DASHBOARD_TOKEN  — PropelAuth JWT from app.raindrop.ai

Usage:
    RAINDROP_DASHBOARD_TOKEN=eyJ... doppler run -p dawn -c dev -- \\
        .venv/bin/python e2e_verify.py
"""

import json
import os
import sys
import time
import uuid
import urllib.parse
import urllib.request

from deepagents import create_deep_agent
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.tools import tool

from raindrop_deep_agents import RaindropDeepAgents

API_KEY = os.environ.get("RAINDROP_API_KEY") or os.environ.get("RAINDROP_WRITE_KEY")
OPENAI_KEY = os.environ.get("OPENAI_API_KEY")
DASHBOARD_TOKEN = os.environ.get("RAINDROP_DASHBOARD_TOKEN")
RUN_ID = hex(int(time.time()))[2:]
TEST_USER = f"e2e-da-py-{RUN_ID}"
DEFAULT_CONVO = f"convo-da-py-{RUN_ID}"

if not API_KEY:
    print("ERROR: Missing RAINDROP_API_KEY or RAINDROP_WRITE_KEY"); sys.exit(1)
if not OPENAI_KEY:
    print("ERROR: Missing OPENAI_API_KEY"); sys.exit(1)
if not DASHBOARD_TOKEN:
    print("ERROR: Missing RAINDROP_DASHBOARD_TOKEN"); sys.exit(1)

step_num = 0
fail_count = 0
collected_event_ids: dict[str, list[str]] = {}


def step(name: str):
    global step_num
    step_num += 1
    print(f"\n{step_num}. {name}")


def ok(msg: str = ""):
    print(f"   OK{f' — {msg}' if msg else ''}")


def check(condition: bool, msg: str):
    global fail_count
    if not condition:
        fail_count += 1
        print(f"   FAIL: {msg}")
    else:
        print(f"   PASS: {msg}")


def query_dashboard():
    input_data = json.dumps(
        {"json": {"limit": 100, "orderBy": {"field": "timestamp", "direction": "desc"}}}
    )
    url = f"https://backend.raindrop.ai/api/trpc/events.list?input={urllib.parse.quote(input_data)}"
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {DASHBOARD_TOKEN}"})
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read())
    return data.get("result", {}).get("data", [])


def poll_events(user_id: str, min_count: int = 1, timeout: int = 90):
    for _ in range(timeout // 5):
        time.sleep(5)
        events = query_dashboard()
        mine = [e for e in events if e.get("userId") == user_id]
        if len(mine) >= min_count:
            return mine
    return [e for e in query_dashboard() if e.get("userId") == user_id]


print(f"Write key: {API_KEY[:8]}...")
print(f"Test user: {TEST_USER}")
print(f"Run ID:    {RUN_ID}")

llm = ChatOpenAI(model="gpt-4o-mini")

# ───────────────────────────────────────────────────────────────────────────
# Scenario 1: Basic create_deep_agent() invoke
# ───────────────────────────────────────────────────────────────────────────
step("Basic create_deep_agent() invoke")

rd = RaindropDeepAgents(api_key=API_KEY, user_id=TEST_USER, convo_id=DEFAULT_CONVO)

agent_basic = create_deep_agent(model=llm, system_prompt="You are a geography expert. Answer in one sentence.")
result_basic = agent_basic.invoke(
    {"messages": [HumanMessage(content="What is the capital of France?")]},
    config={"callbacks": [rd.handler]},
)
output_basic = result_basic["messages"][-1].content
ok(f"Response: {output_basic[:80]}")

# ───────────────────────────────────────────────────────────────────────────
# Scenario 2: Agent with custom tool (multi-level: chain→LLM→tool→LLM)
# ───────────────────────────────────────────────────────────────────────────
step("Agent with custom tool via create_deep_agent(tools=[...])")


@tool
def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    return f"The weather in {city} is 22°C and sunny."


tool_user = f"{TEST_USER}-tools"
rd_tools = RaindropDeepAgents(api_key=API_KEY, user_id=tool_user, convo_id=DEFAULT_CONVO)

agent_tools = create_deep_agent(
    model=llm,
    tools=[get_weather],
    system_prompt="You are a helpful weather assistant. Always use the get_weather tool when asked about weather. Keep final answers under 20 words.",
)
result_tools = agent_tools.invoke(
    {"messages": [HumanMessage(content="What's the weather in Tokyo?")]},
    config={"callbacks": [rd_tools.handler]},
)
output_tools = result_tools["messages"][-1].content
ok(f"Tool agent response: {output_tools[:80]}")

# ───────────────────────────────────────────────────────────────────────────
# Scenario 3: Multi-turn conversation
# ───────────────────────────────────────────────────────────────────────────
step("Multi-turn conversation via create_deep_agent()")

multi_user = f"{TEST_USER}-multi"
rd_multi = RaindropDeepAgents(api_key=API_KEY, user_id=multi_user, convo_id=DEFAULT_CONVO)

agent_multi = create_deep_agent(
    model=llm,
    system_prompt="You are a food critic. Keep answers under 15 words.",
)
result_t1 = agent_multi.invoke(
    {"messages": [HumanMessage(content="Best dish in Bangkok?")]},
    config={"callbacks": [rd_multi.handler]},
)
ok(f"Turn 1: {result_t1['messages'][-1].content[:60]}")

result_t2 = agent_multi.invoke(
    {"messages": [
        HumanMessage(content="Best dish in Bangkok?"),
        result_t1["messages"][-1],
        HumanMessage(content="Where should I eat it?"),
    ]},
    config={"callbacks": [rd_multi.handler]},
)
ok(f"Turn 2: {result_t2['messages'][-1].content[:60]}")

# ───────────────────────────────────────────────────────────────────────────
# Scenario 4: Error handling
# ───────────────────────────────────────────────────────────────────────────
step("Error handling — simulated LLM error")

error_user = f"{TEST_USER}-error"
rd_error = RaindropDeepAgents(api_key=API_KEY, user_id=error_user, convo_id=DEFAULT_CONVO)

err_run_id = uuid.uuid4()
rd_error.handler.on_llm_start(
    {"id": ["langchain", "chat_models", "ChatOpenAI"], "name": "ChatOpenAI"},
    ["This will fail"],
    run_id=err_run_id,
)
rd_error.handler.on_llm_error(
    RuntimeError("Simulated API rate limit exceeded"),
    run_id=err_run_id,
)
ok("Error event shipped")

# ───────────────────────────────────────────────────────────────────────────
# Scenario 5: identify + track_signal
# ───────────────────────────────────────────────────────────────────────────
step("identify() and track_signal()")

rd.identify(user_id=TEST_USER, traits={"plan": "enterprise", "framework": "deep-agents"})
ok("identify() called")

rd.track_signal(
    event_id="e2e-signal-test",
    name="task_completed",
    signal_type="feedback",
    sentiment="POSITIVE",
    comment="Works great",
)
ok("track_signal() called")

# ───────────────────────────────────────────────────────────────────────────
# Shutdown
# ───────────────────────────────────────────────────────────────────────────
step("Shutdown all instances")
for r in [rd, rd_tools, rd_multi, rd_error]:
    r.shutdown()
ok("All shut down")

# ───────────────────────────────────────────────────────────────────────────
# Dashboard verification
# ───────────────────────────────────────────────────────────────────────────
step("Verify events in dashboard")
print("   Waiting for ingestion...")

basic_events = poll_events(TEST_USER, min_count=1)
tool_events = poll_events(tool_user, min_count=1)
multi_events = poll_events(multi_user, min_count=2)
error_events = poll_events(error_user, min_count=1)

print(f"\n   Basic events: {len(basic_events)}")
print(f"   Tool events:  {len(tool_events)}")
print(f"   Multi events: {len(multi_events)}")
print(f"   Error events: {len(error_events)}")

# Collect event IDs for inspection
for label, evts in [("basic", basic_events), ("tool", tool_events), ("multi", multi_events), ("error", error_events)]:
    collected_event_ids[label] = [e.get("customEventId", e.get("id", "?")) for e in evts]

# --- Basic checks ---
step("Verify basic agent event")
if basic_events:
    e = basic_events[0]
    ai = e.get("aiData", {})
    props = e.get("properties", {})
    check(bool(ai.get("input")), f"input present: {(ai.get('input') or '')[:40]}")
    check("France" in (ai.get("input") or ""), "input contains 'France'")
    check(bool(ai.get("output")), f"output present: {(ai.get('output') or '')[:40]}")
    check(bool(ai.get("model")), f"model present: {ai.get('model')}")
    check(ai.get("convoId") == DEFAULT_CONVO, f"convoId matches")
    check(int(props.get("ai.usage.prompt_tokens", 0)) > 0, f"prompt_tokens > 0: {props.get('ai.usage.prompt_tokens')}")
    check(int(props.get("ai.usage.completion_tokens", 0)) > 0, f"completion_tokens > 0: {props.get('ai.usage.completion_tokens')}")
else:
    check(False, "No basic events found")

# --- Tool checks ---
step("Verify tool agent events")
if tool_events:
    all_text = json.dumps(tool_events).lower()
    check("weather" in all_text or "tokyo" in all_text, "tool-related content found")
    check(len(tool_events) >= 2, f"at least 2 events (LLM + tool call): got {len(tool_events)}")
    tool_call_events = [e for e in tool_events if e.get("name") == "ai_tool_call" or "tool" in json.dumps(e.get("properties", {})).lower()]
    check(len(tool_call_events) >= 1, f"tool call event found: {len(tool_call_events)}")
else:
    check(False, "No tool events found")

# --- Multi-turn checks ---
step("Verify multi-turn events")
if len(multi_events) >= 2:
    inputs = [e.get("aiData", {}).get("input", "") for e in multi_events]
    check(any("Bangkok" in i for i in inputs), "turn 1 input contains 'Bangkok'")
    check(any("eat" in i.lower() or "where" in i.lower() for i in inputs), "turn 2 input contains follow-up")
    check(not any("Bangkok" in i and "eat" in i.lower() for i in inputs), "inputs are per-turn, not concatenated")
else:
    check(False, f"Expected >= 2 multi-turn events, got {len(multi_events)}")

# --- Error checks ---
step("Verify error event")
if error_events:
    all_text = json.dumps(error_events).lower()
    check("error" in all_text, "error info present in event data")
else:
    check(False, "No error events found")

# ───────────────────────────────────────────────────────────────────────────
# Event IDs for manual inspection
# ───────────────────────────────────────────────────────────────────────────
print(f"\n{'=' * 60}")
print("EVENT IDs FOR DASHBOARD INSPECTION:")
print(f"  Dashboard URL: https://app.raindrop.ai/events")
for label, ids in collected_event_ids.items():
    for eid in ids:
        print(f"  [{label}] https://app.raindrop.ai/events?baseFilters=%7B%22userId%22%3A%22{urllib.parse.quote(TEST_USER if label != 'tool' else tool_user)}%22%7D")
        break

print(f"\n  Filter by users:")
print(f"    basic/identify/signal: {TEST_USER}")
print(f"    tool agent:            {tool_user}")
print(f"    multi-turn:            {multi_user}")
print(f"    error:                 {error_user}")

print(f"\n{'=' * 60}")
if fail_count == 0:
    print(f"ALL CHECKS PASSED ({step_num} steps)")
else:
    print(f"{fail_count} CHECK(S) FAILED ({step_num} steps)")
    sys.exit(1)
