"""Raindrop integration for Deep Agents."""

# IMPORTANT: install the wrapt 2.x compat shim BEFORE handler.py imports
# raindrop.analytics (which transitively triggers Traceloop's instrumentor
# loader).  The shim is a no-op on wrapt 1.x and translates the legacy
# ``module=`` kwarg to ``target=`` on wrapt 2.x so the LangChain
# instrumentor can activate.  See raindrop_deep_agents/_wrapt_compat.py.
from . import _wrapt_compat as _wrapt_compat  # noqa: E402  (must run first)
_wrapt_compat.install()

from .handler import (  # noqa: E402  (after shim install)
    RaindropDeepAgents,
    RaindropDeepAgentsHandler,
    create_raindrop_deep_agents,
)

__version__ = "0.0.1"

__all__ = [
    "RaindropDeepAgents",
    "RaindropDeepAgentsHandler",
    "create_raindrop_deep_agents",
]
