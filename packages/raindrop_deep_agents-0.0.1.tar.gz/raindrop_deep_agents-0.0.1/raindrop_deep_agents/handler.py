"""
Deep Agents callback handler for Raindrop observability.

Captures LLM calls, tool usage (write_todos, read_file, write_file, edit_file,
execute, task, etc.), chains, and agent actions via LangChain's callback system
and ships them to the Raindrop API.

Deep Agents is built on LangChain and LangGraph. This handler extends
LangChain's BaseCallbackHandler to provide observability for Deep Agents
workflows including planning, filesystem operations, shell execution,
and subagent delegation.

Usage:
    from raindrop_deep_agents import RaindropDeepAgents

    rd = RaindropDeepAgents(api_key="your-write-key", user_id="user-123")
    agent = create_deep_agent(tools=[...])
    result = agent.invoke(
        {"messages": [HumanMessage(content="Hello")]},
        config={"callbacks": [rd.handler]},
    )
    rd.shutdown()
"""

from __future__ import annotations

import json
import logging
import time
import uuid
import warnings
from typing import Any, Dict, List, Literal, Optional, Union

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.outputs import LLMResult

import raindrop.analytics as raindrop

logger = logging.getLogger(__name__)

_INTERNAL_NAMES = frozenset({
    "__start__",
    "__end__",
    "ChannelWrite",
    "ChannelRead",
})

# ``LangGraph`` is intentionally NOT in _INTERNAL_NAMES.  In Deep Agents
# workflows it is the very first chain to start, and the Raindrop SDK's
# ``begin()`` call (which sets the OTel association context for the entire
# trace) must run before any LangGraph-emitted span exists; otherwise
# downstream OTel spans land in a trace with no user_id / event_id linkage
# and the dashboard cannot show them on the corresponding event.
#
# Note: even with this in place, the LangChain OTel instrumentor doesn't
# always carry the user_id baggage to every span it emits inside a LangGraph
# callback context — see traceloop/openllmetry#2271.  Documented in the
# README's Known Limitations.


def _is_internal_name(name: str) -> bool:
    """Check if a chain name is a LangGraph/Deep Agents internal."""
    if name in _INTERNAL_NAMES:
        return True
    if name.startswith("Branch:"):
        return True
    if name.startswith("ChannelWrite"):
        return True
    if name.startswith("ChannelRead"):
        return True
    if name.startswith("__") and name.endswith("__"):
        return True
    return False


def _safe_serialize(value: Any) -> str:
    """Safely serialize a value to string. Never throws."""
    try:
        return json.dumps(value)
    except Exception:
        return str(value)


def _truncate(text: str, max_len: int = 4096) -> str:
    """Truncate text to max_len characters."""
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


def _get_name_from_serialized(serialized: Dict[str, Any]) -> str:
    """Extract a human-readable name from a LangChain serialized object."""
    if serialized.get("name"):
        return serialized["name"]
    ids = serialized.get("id")
    if ids and isinstance(ids, list) and len(ids) > 0:
        return ids[-1]
    return "unknown"


def _extract_text_from_content(content: Any) -> Optional[str]:
    """Extract a plain-text representation from a LangChain message ``content``.

    Message content shapes we handle:
    - plain string → returned as-is
    - list of content parts (multi-modal):  ``[{"type": "text", "text": "x"},
      {"type": "image_url", ...}]`` → concatenate the ``text`` of each text part
    - dict with a ``text`` / ``content`` key → use that
    - anything else → JSON dump (with str() fallback so we never raise)
    """
    if content is None:
        return None
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for part in content:
            if isinstance(part, str):
                parts.append(part)
            elif isinstance(part, dict):
                # LangChain multi-modal: {"type": "text", "text": "..."} or
                # provider-specific keys like {"text": "..."} / {"content": "..."}.
                if isinstance(part.get("text"), str):
                    parts.append(part["text"])
                elif part.get("type") == "text" and isinstance(part.get("content"), str):
                    parts.append(part["content"])
                else:
                    # Non-text part (image, audio, etc.).  Skip silently —
                    # the dashboard event input field is for human-readable
                    # context, not raw multi-modal payloads.
                    pass
        if parts:
            return "\n".join(parts)
        # Fall through to JSON dump if no text parts found.
        try:
            return json.dumps(content)
        except Exception:
            return str(content)
    if isinstance(content, dict):
        if isinstance(content.get("text"), str):
            return content["text"]
        if isinstance(content.get("content"), str):
            return content["content"]
        try:
            return json.dumps(content)
        except Exception:
            return str(content)
    return str(content)


def _extract_messages_text(messages: Any) -> Optional[str]:
    """Extract user-facing text from a LangChain/LangGraph messages payload.

    Deep Agents chain inputs/outputs carry a ``messages`` list; the caller
    has already filtered to the last human or AI message before calling us.
    """
    if not isinstance(messages, list) or not messages:
        return None
    msg = messages[-1]
    content = getattr(msg, "content", None)
    if content is None and isinstance(msg, dict):
        content = msg.get("content")
    return _extract_text_from_content(content)


# Cap on chain-level input/output extraction.  LangChain chain payloads
# carry the full message history which can be many KB on multi-turn
# conversations.  The Raindrop SDK validates input/output and rejects
# oversized strings, so truncate aggressively (the dashboard truncates
# anyway for display).  Per-LLM events from on_llm_end are not capped
# here — they only carry one prompt, not the history.
_CHAIN_TEXT_MAX_LEN = 8192


def _extract_chain_input(inputs: Any) -> Optional[str]:
    """Pull a human-readable input string from a chain's inputs dict.

    Deep Agents chains receive ``{"messages": [...]}``; prefer the last
    human message.  Falls back to the first string value or JSON dump.
    Result is truncated to :data:`_CHAIN_TEXT_MAX_LEN` characters.
    """
    text: Optional[str] = None
    if isinstance(inputs, dict):
        if "messages" in inputs:
            messages = inputs["messages"]
            if isinstance(messages, list):
                # Prefer the last human message so re-invocations with full
                # history still surface the new user question at the top.
                for msg in reversed(messages):
                    msg_type = getattr(msg, "type", None) or (
                        msg.get("type") if isinstance(msg, dict) else None
                    )
                    if msg_type in ("human", "user"):
                        text = _extract_messages_text([msg])
                        break
                if text is None:
                    text = _extract_messages_text(messages)
        if text is None and "input" in inputs:
            value = inputs["input"]
            if isinstance(value, str):
                text = value
        if text is None:
            for value in inputs.values():
                if isinstance(value, str):
                    text = value
                    break
    elif isinstance(inputs, str):
        text = inputs

    if text is None:
        try:
            text = json.dumps(inputs)
        except Exception:
            text = str(inputs)

    return _truncate(text, _CHAIN_TEXT_MAX_LEN) if text is not None else None


def _extract_chain_output(outputs: Any) -> Optional[str]:
    """Pull a human-readable output string from a chain's outputs dict.

    Result is truncated to :data:`_CHAIN_TEXT_MAX_LEN` characters.
    """
    text: Optional[str] = None
    if isinstance(outputs, dict):
        if "messages" in outputs:
            messages = outputs["messages"]
            if isinstance(messages, list):
                # Last AI message in the list is the final assistant output.
                for msg in reversed(messages):
                    msg_type = getattr(msg, "type", None) or (
                        msg.get("type") if isinstance(msg, dict) else None
                    )
                    if msg_type in ("ai", "assistant"):
                        text = _extract_messages_text([msg])
                        break
                if text is None:
                    text = _extract_messages_text(messages)
        if text is None and "output" in outputs:
            value = outputs["output"]
            if isinstance(value, str):
                text = value
        if text is None:
            for value in outputs.values():
                if isinstance(value, str):
                    text = value
                    break
    elif isinstance(outputs, str):
        text = outputs

    if text is None:
        try:
            text = json.dumps(outputs)
        except Exception:
            text = str(outputs)

    return _truncate(text, _CHAIN_TEXT_MAX_LEN) if text is not None else None


class _LLMMetadata:
    """Extracted metadata from an LLM response (Deep Agents / LangChain)."""

    __slots__ = (
        "model",
        "output_text",
        "prompt_tokens",
        "completion_tokens",
        "finish_reason",
        "cached_tokens",
        "reasoning_tokens",
    )

    def __init__(
        self,
        model: Optional[str] = None,
        output_text: Optional[str] = None,
        prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
        finish_reason: Optional[str] = None,
        cached_tokens: Optional[int] = None,
        reasoning_tokens: Optional[int] = None,
    ) -> None:
        self.model = model
        self.output_text = output_text
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.finish_reason = finish_reason
        self.cached_tokens = cached_tokens
        self.reasoning_tokens = reasoning_tokens


def _extract_llm_metadata(response: LLMResult) -> _LLMMetadata:
    """Extract model, output, token counts, finish_reason, and extended token
    categories (cached, reasoning) from an :class:`LLMResult`.

    Supports BOTH the new ``usage_metadata`` format (LangChain >= 0.2) and
    the legacy ``token_usage`` / ``tokenUsage`` format inside ``llm_output``.
    Cached/reasoning token categories are pulled from
    ``input_token_details.cache_read`` and ``output_token_details.reasoning``
    on the new format, and from ``prompt_tokens_details.cached_tokens`` /
    ``completion_tokens_details.reasoning_tokens`` on the legacy format.
    """
    model: Optional[str] = None
    output_text: Optional[str] = None
    prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None
    finish_reason: Optional[str] = None
    cached_tokens: Optional[int] = None
    reasoning_tokens: Optional[int] = None

    if response.generations and response.generations[0]:
        gen = response.generations[0][0]
        output_text = gen.text

        gen_info: Dict[str, Any] = getattr(gen, "generation_info", None) or {}
        finish_reason = gen_info.get("finish_reason")

        msg = getattr(gen, "message", None)
        if msg:
            resp_meta: Dict[str, Any] = getattr(msg, "response_metadata", {}) or {}
            model = resp_meta.get("model_name") or resp_meta.get("model")
            if not finish_reason:
                finish_reason = resp_meta.get("finish_reason")

            usage_meta = getattr(msg, "usage_metadata", None)
            if usage_meta:
                if isinstance(usage_meta, dict):
                    prompt_tokens = usage_meta.get("input_tokens")
                    completion_tokens = usage_meta.get("output_tokens")
                    input_details = usage_meta.get("input_token_details") or {}
                    output_details = usage_meta.get("output_token_details") or {}
                    if isinstance(input_details, dict):
                        cached_tokens = input_details.get("cache_read")
                    if isinstance(output_details, dict):
                        reasoning_tokens = output_details.get("reasoning")
                else:
                    prompt_tokens = getattr(usage_meta, "input_tokens", None)
                    completion_tokens = getattr(usage_meta, "output_tokens", None)
                    input_details = getattr(usage_meta, "input_token_details", None) or {}
                    output_details = getattr(usage_meta, "output_token_details", None) or {}
                    if isinstance(input_details, dict):
                        cached_tokens = input_details.get("cache_read")
                    else:
                        cached_tokens = getattr(input_details, "cache_read", None)
                    if isinstance(output_details, dict):
                        reasoning_tokens = output_details.get("reasoning")
                    else:
                        reasoning_tokens = getattr(output_details, "reasoning", None)

    llm_output: Dict[str, Any] = response.llm_output or {}
    if not model:
        model = llm_output.get("model_name") or llm_output.get("model")

    token_usage: Dict[str, Any] = (
        llm_output.get("token_usage") or llm_output.get("tokenUsage") or {}
    )
    if prompt_tokens is None:
        pt = token_usage.get("prompt_tokens")
        prompt_tokens = pt if pt is not None else token_usage.get("promptTokens")
    if completion_tokens is None:
        ct = token_usage.get("completion_tokens")
        completion_tokens = ct if ct is not None else token_usage.get("completionTokens")

    if cached_tokens is None:
        prompt_details = token_usage.get("prompt_tokens_details") or {}
        if isinstance(prompt_details, dict):
            cached_tokens = prompt_details.get("cached_tokens")
    if reasoning_tokens is None:
        completion_details = token_usage.get("completion_tokens_details") or {}
        if isinstance(completion_details, dict):
            reasoning_tokens = completion_details.get("reasoning_tokens")

    return _LLMMetadata(
        model=model,
        output_text=output_text,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        finish_reason=finish_reason,
        cached_tokens=cached_tokens,
        reasoning_tokens=reasoning_tokens,
    )


class RaindropDeepAgentsHandler(BaseCallbackHandler):
    """LangChain callback handler that ships Deep Agents events to Raindrop."""

    def __init__(
        self,
        user_id: Optional[str] = None,
        convo_id: Optional[str] = None,
    ):
        super().__init__()
        self._user_id = user_id
        self._convo_id = convo_id

        self._spans: Dict[str, Any] = {}
        self._root_run_ids: Dict[str, str] = {}
        self._event_ids: Dict[str, str] = {}
        self._interaction: Optional[Any] = None
        # event_id of the most recently shipped ROOT event.  Exposed via
        # ``RaindropDeepAgents.last_event_id`` so callers can attach a
        # feedback signal (``track_signal``) to the agent event they just
        # ran — without having to poll the dashboard API for the real id.
        self._last_root_event_id: Optional[str] = None

    def _get_event_id(
        self, run_id: uuid.UUID, parent_run_id: Optional[uuid.UUID] = None
    ) -> str:
        rid = str(run_id)
        pid = str(parent_run_id) if parent_run_id else None
        root_id = self._root_run_ids.get(pid, pid) if pid else rid
        self._root_run_ids[rid] = root_id
        if root_id not in self._event_ids:
            self._event_ids[root_id] = str(uuid.uuid4())
        return self._event_ids[root_id]

    def _ensure_interaction(self, run_id: uuid.UUID) -> None:
        """Create an interaction for the root run if one does not already exist.

        The interaction sets the OpenTelemetry association context so that spans
        produced by the LangChain OTel instrumentor are linked to this event.
        Only one interaction exists per handler at a time — it is created lazily
        when the first root run fires, and finished in :meth:`_cleanup` when that
        root run completes.
        """
        rid = str(run_id)
        root_id = self._root_run_ids.get(rid, rid)
        if root_id != rid or self._interaction is not None:
            return
        event_id = self._event_ids.get(root_id)
        if not event_id:
            return
        try:
            self._interaction = raindrop.begin(
                user_id=self._user_id or "unknown",
                event="ai_generation",
                event_id=event_id,
                convo_id=self._convo_id,
            )
        except Exception:
            logger.debug("Error creating interaction", exc_info=True)

    def _cleanup(self, run_id: uuid.UUID) -> None:
        rid = str(run_id)
        self._spans.pop(rid, None)
        self._spans.pop(f"{run_id}:agent_action", None)
        was_registered = rid in self._root_run_ids
        root_id = self._root_run_ids.pop(rid, rid)
        if root_id == rid:
            self._event_ids.pop(root_id, None)
            # Only finish the interaction for a legitimate root run.  Filtered
            # internals (e.g. LangGraph) skip ``_get_event_id``, so they are
            # never in ``_root_run_ids`` and must not prematurely finish the
            # interaction created by a real root.
            if was_registered and self._interaction is not None:
                try:
                    self._interaction.finish()
                except Exception:
                    logger.debug("Error finishing interaction", exc_info=True)
                self._interaction = None

    def _track_error(
        self,
        run_id: uuid.UUID,
        error: BaseException,
    ) -> None:
        """Report an error event for both root and non-root runs.

        For ROOT runs the error data is routed through the interaction's
        partial buffer (same mechanism as :meth:`_ship_root_event`) to
        avoid Common Mistake #41 — a bare ``raindrop.track_ai`` for the
        root event_id would be masked by the subsequent
        ``interaction.finish()`` partial-flush, and the dashboard row
        would lose ``error.type`` / ``error.message`` / the ``[Error]``
        output.  See :meth:`_ship_root_event` for the full mechanics.

        For NON-root runs we keep the standalone ``track_ai`` path with a
        fresh UUID — no interaction is in play for those.
        """
        rid = str(run_id)
        root_id = self._root_run_ids.get(rid, rid)
        event_id = self._event_ids.get(root_id)
        if not event_id:
            return

        error_props: Dict[str, Any] = {
            "error.type": type(error).__name__,
            "error.message": str(error),
        }
        error_output = f"[Error] {type(error).__name__}: {error}"

        if root_id == rid and self._interaction is not None:
            # ROOT error path — route through the interaction's partial
            # buffer so ``finish()`` flushes a single coherent event with
            # the error data attached.  Null out ``self._interaction``
            # after so ``_cleanup`` doesn't call ``finish()`` again.
            try:
                self._interaction.set_properties(error_props)
                self._interaction.finish(output=error_output)
                self._last_root_event_id = event_id
            except Exception:
                logger.debug(
                    "Error routing root error through interaction; "
                    "falling back to track_ai",
                    exc_info=True,
                )
                try:
                    raindrop.track_ai(
                        user_id=self._user_id or "unknown",
                        event="ai_generation",
                        event_id=event_id,
                        output=error_output,
                        properties=error_props,
                        convo_id=self._convo_id,
                    )
                except Exception:
                    logger.debug("Fallback track_ai also failed", exc_info=True)
            finally:
                self._interaction = None
            return

        # Non-root error — ship with a fresh UUID via track_ai.
        raindrop.track_ai(
            user_id=self._user_id or "unknown",
            event="ai_generation",
            event_id=str(uuid.uuid4()),
            output=error_output,
            properties=error_props,
            convo_id=self._convo_id,
        )

    @staticmethod
    def _build_properties(
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        if not tags and not metadata:
            return None
        props: Dict[str, Any] = {}
        if tags:
            props["deep_agents.tags"] = tags
        if metadata:
            props.update(metadata)
        return props

    # -------------------------------------------------------------------------
    # LLM events
    # -------------------------------------------------------------------------

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        try:
            if str(run_id) in self._spans:
                return
            event_id = self._get_event_id(run_id, parent_run_id)
            input_text = "\n".join(prompts)
            props = self._build_properties(tags, metadata)
            self._spans[str(run_id)] = {
                "event_id": event_id,
                "type": "llm",
                "input": input_text,
                "properties": props,
            }
            self._ensure_interaction(run_id)
        except Exception:
            logger.debug("Error in on_llm_start", exc_info=True)

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[Any]],
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        try:
            if str(run_id) in self._spans:
                return
            event_id = self._get_event_id(run_id, parent_run_id)
            props = self._build_properties(tags, metadata)
            self._spans[str(run_id)] = {
                "event_id": event_id,
                "type": "chat",
                "properties": props,
            }

            all_msgs = [msg for msg_list in messages for msg in msg_list]
            user_msgs = [
                m
                for m in all_msgs
                if getattr(m, "type", "unknown") in ("human", "user")
            ]
            last_msg = user_msgs[-1] if user_msgs else (all_msgs[-1] if all_msgs else None)
            input_text = None
            if last_msg:
                content = last_msg.content if hasattr(last_msg, "content") else str(last_msg)
                if isinstance(content, list):
                    try:
                        content = json.dumps(content)
                    except Exception:
                        content = str(content)
                input_text = content
            self._spans[str(run_id)]["input"] = input_text
            self._ensure_interaction(run_id)
        except Exception:
            logger.debug("Error in on_chat_model_start", exc_info=True)

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            meta = _extract_llm_metadata(response)

            span_data = self._spans.get(str(run_id), {})
            input_text = span_data.get("input")
            span_props = span_data.get("properties") or {}

            properties: Dict[str, Any] = {**span_props}
            if meta.prompt_tokens is not None:
                properties["ai.usage.prompt_tokens"] = meta.prompt_tokens
            if meta.completion_tokens is not None:
                properties["ai.usage.completion_tokens"] = meta.completion_tokens
            if meta.finish_reason is not None:
                properties["ai.finish_reason"] = meta.finish_reason
            if meta.cached_tokens is not None:
                properties["ai.usage.cached_tokens"] = meta.cached_tokens
            if meta.reasoning_tokens is not None:
                properties["ai.usage.thoughts_tokens"] = meta.reasoning_tokens

            rid = str(run_id)
            root_id = self._root_run_ids.get(rid, rid)
            event_id = self._event_ids.get(root_id)

            # Aggregate model + token usage onto the ROOT chain's span entry
            # so on_chain_end can ship a fully-populated root event with
            # model and totalled tokens.  Otherwise the dashboard's primary
            # event (the one linked to the OTel trace via the interaction)
            # would be missing all LLM metadata, with that data living on
            # an "orphan" event reachable only by user_id / convo_id filter.
            if root_id != rid:
                self._merge_llm_meta_into_root(root_id, meta)

            if event_id:
                if root_id == rid:
                    # Bare LLM-as-root path (e.g. ``llm.invoke([...])``
                    # called directly with our handler attached).  Same
                    # partial-buffer collision as the chain-root case
                    # (Common Mistake #41 in new-integration SKILL.md): if
                    # we ship via a separate ``raindrop.track_ai`` for the
                    # same event_id that ``raindrop.begin()`` opened, the
                    # subsequent ``interaction.finish()`` partial-flush
                    # masks our payload and the dashboard event ends up
                    # empty.  Route the data through the interaction's
                    # mutators so everything flushes as ONE coherent
                    # partial-event.
                    self._ship_root_event(
                        event_id, input_text, meta.output_text, meta.model,
                        properties or None,
                    )
                else:
                    # Child LLM under a chain — ships with a fresh UUID;
                    # the chain root event picks up aggregated tokens via
                    # _merge_llm_meta_into_root above.
                    raindrop.track_ai(
                        user_id=self._user_id or "unknown",
                        event="ai_generation",
                        event_id=str(uuid.uuid4()),
                        input=input_text,
                        output=meta.output_text,
                        model=meta.model,
                        properties=properties if properties else None,
                        convo_id=self._convo_id,
                    )
        except Exception:
            logger.debug("Error in on_llm_end", exc_info=True)
        finally:
            self._cleanup(run_id)

    def _merge_llm_meta_into_root(self, root_id: str, meta: "_LLMMetadata") -> None:
        """Accumulate model + token usage from a child LLM call onto the
        root chain's span entry, so :meth:`on_chain_end` can ship a single
        primary event that carries both the chain-level conversation and
        the aggregated LLM metadata (model, totals, finish reason).
        """
        root_span = self._spans.get(root_id)
        if not isinstance(root_span, dict) or root_span.get("type") != "chain":
            return
        agg = root_span.setdefault("llm_aggregate", {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "cached_tokens": 0,
            "reasoning_tokens": 0,
            "model": None,
            "finish_reason": None,
            "saw_tokens": False,
        })
        if meta.model:
            agg["model"] = meta.model
        if meta.finish_reason:
            agg["finish_reason"] = meta.finish_reason
        if meta.prompt_tokens is not None:
            agg["prompt_tokens"] += int(meta.prompt_tokens)
            agg["saw_tokens"] = True
        if meta.completion_tokens is not None:
            agg["completion_tokens"] += int(meta.completion_tokens)
            agg["saw_tokens"] = True
        if meta.cached_tokens is not None:
            agg["cached_tokens"] += int(meta.cached_tokens)
            agg["saw_tokens"] = True
        if meta.reasoning_tokens is not None:
            agg["reasoning_tokens"] += int(meta.reasoning_tokens)
            agg["saw_tokens"] = True

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._track_error(run_id, error)
        except Exception:
            logger.debug("Error in on_llm_error", exc_info=True)
        finally:
            self._cleanup(run_id)

    # -------------------------------------------------------------------------
    # Chain events
    # -------------------------------------------------------------------------

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        name: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        try:
            chain_name = name or _get_name_from_serialized(serialized)
            if _is_internal_name(chain_name):
                return
            rid = str(run_id)
            self._get_event_id(run_id, parent_run_id)
            root_id = self._root_run_ids.get(rid, rid)
            # Deep Agents wraps LLM calls in a LangGraph chain, so the LLM is
            # never the root.  Create the interaction on the root chain so the
            # OTel association context is in place before the LLM fires.
            self._ensure_interaction(run_id)
            # Capture the human-readable input for the root chain so we can
            # populate the root event with it on chain_end.  Without this the
            # root event would be empty (begin() carries only OTel association
            # context, no data).
            if root_id == rid:
                input_text = _extract_chain_input(inputs)
                self._spans[rid] = {
                    "type": "chain",
                    "name": chain_name,
                    "input": input_text,
                    "properties": self._build_properties(tags, metadata),
                }
            # Non-root chains don't produce dashboard events on their own —
            # their data flows up to the root via _merge_llm_meta_into_root
            # (for LLMs) and interaction.track_tool (for tool calls).
        except Exception:
            logger.debug("Error in on_chain_start", exc_info=True)

    def on_chain_end(
        self,
        outputs: Dict[str, Any],
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            rid = str(run_id)
            root_id = self._root_run_ids.get(rid, rid)
            if root_id == rid:
                event_id = self._event_ids.get(root_id)
                span_data = self._spans.get(rid, {})
                if event_id and span_data.get("type") == "chain":
                    output_text = _extract_chain_output(outputs)
                    input_text = span_data.get("input")
                    base_props = dict(span_data.get("properties") or {})

                    # Merge aggregated LLM metadata captured by child
                    # on_llm_end calls into the root event's properties so
                    # the primary dashboard row carries model + tokens (in
                    # addition to chain-level input/output).  We gate on
                    # ``saw_tokens`` (the flag that tracks whether ANY
                    # child reported tokens) and emit each aggregate
                    # unconditionally — using truthiness here would silently
                    # drop a legitimate cumulative 0, diverging from the
                    # ``is not None`` check we use in on_llm_end.
                    agg = span_data.get("llm_aggregate") or {}
                    model = agg.get("model")
                    if agg.get("saw_tokens"):
                        base_props["ai.usage.prompt_tokens"] = agg.get("prompt_tokens", 0)
                        base_props["ai.usage.completion_tokens"] = agg.get("completion_tokens", 0)
                        base_props["ai.usage.cached_tokens"] = agg.get("cached_tokens", 0)
                        base_props["ai.usage.thoughts_tokens"] = agg.get("reasoning_tokens", 0)
                    if agg.get("finish_reason"):
                        base_props["ai.finish_reason"] = agg["finish_reason"]

                    self._ship_root_event(event_id, input_text, output_text, model, base_props)
        except Exception:
            logger.debug("Error in on_chain_end", exc_info=True)
        finally:
            self._cleanup(run_id)

    def _ship_root_event(
        self,
        event_id: str,
        input_text: Optional[str],
        output_text: Optional[str],
        model: Optional[str],
        properties: Optional[Dict[str, Any]],
    ) -> None:
        """Populate and finalize the root interaction's event in a single,
        coherent partial-event flush.

        Why not just call ``raindrop.track_ai(event_id=event_id, ...)``?
        Because :func:`raindrop.begin` (called from :meth:`_ensure_interaction`)
        opens a partial-event in the SDK's in-memory ``_partial_buffers``
        keyed on ``event_id``.  When ``interaction.finish()`` later runs
        (in :meth:`_cleanup`), it merges its own incremental update into
        that buffer and flushes it via ``/events/track_partial`` with
        ``is_pending=False``.  A separate ``raindrop.track_ai`` call for
        the same ``event_id`` goes through ``/events/track`` instead and
        the backend treats it as a distinct write that the subsequent
        partial-flush effectively masks — the dashboard row ends up with
        only the partial-buffer state (``convo_id`` + ``trace_id``), and
        the ``track_ai`` payload's input / output / model / tokens never
        surface on that event.  The result is a confusing pair of events
        per root chain: a populated one with a fresh UUID (from the LLM
        child ``track_ai``) and an empty placeholder with the root
        ``event_id``.

        Routing the root chain's data through the interaction's partial
        buffer ensures everything ends up in a single ``track_partial``
        flush so the row is fully populated.
        """
        if self._interaction is None:
            # No interaction (begin failed earlier) — fall back to a
            # standalone track_ai so we still capture the data even if
            # OTel association isn't available.
            try:
                raindrop.track_ai(
                    user_id=self._user_id or "unknown",
                    event="ai_generation",
                    event_id=event_id,
                    input=input_text,
                    output=output_text,
                    model=model,
                    properties=properties or None,
                    convo_id=self._convo_id,
                )
            except Exception:
                logger.debug("Error shipping fallback root event", exc_info=True)
            return

        try:
            if input_text is not None:
                self._interaction.set_input(input_text)
            if properties:
                self._interaction.set_properties(properties)
            if model:
                # No public ``set_model`` on the Interaction class, so we
                # use the underlying ``_track_ai_partial`` directly with a
                # ``PartialAIData(model=...)`` payload.  This is the same
                # mechanism :meth:`Interaction.set_input` uses internally
                # — see raindrop/interaction.py:set_input.
                try:
                    from raindrop.models import PartialTrackAIEvent, PartialAIData
                    raindrop._track_ai_partial(
                        PartialTrackAIEvent(
                            event_id=event_id,
                            ai_data=PartialAIData(model=model),
                        )
                    )
                except Exception:
                    logger.debug("Could not set model on root event", exc_info=True)
            # ``finish(output=...)`` adds output to the partial buffer,
            # marks ``is_pending=False``, and triggers a single flush of
            # the merged event to the backend.
            self._interaction.finish(output=output_text)
            # Remember the shipped event_id so callers can attach feedback
            # signals via ``RaindropDeepAgents.last_event_id`` without
            # polling events.list for the real id.
            self._last_root_event_id = event_id
        except Exception:
            logger.debug("Error finalizing root event via interaction", exc_info=True)
            # Best-effort: even if set_input/set_properties/_track_ai_partial
            # raised, try to call ``finish()`` so the partial buffer at
            # least gets flushed with ``is_pending=False``.  Otherwise the
            # event sits pending until the SDK's 20s timer fires, and the
            # dashboard row stays stuck in the "isPending" state.
            try:
                self._interaction.finish()
            except Exception:
                logger.debug(
                    "interaction.finish() also raised after _ship_root_event error",
                    exc_info=True,
                )
        finally:
            # Mark the interaction as already finished so :meth:`_cleanup`
            # doesn't double-flush it.
            self._interaction = None

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            rid = str(run_id)
            if rid in self._root_run_ids:
                self._track_error(run_id, error)
        except Exception:
            logger.debug("Error in on_chain_error", exc_info=True)
        finally:
            self._cleanup(run_id)

    # -------------------------------------------------------------------------
    # Tool events — Deep Agents uses tools heavily (write_todos, read_file,
    # write_file, edit_file, ls, execute, task, etc.)
    # -------------------------------------------------------------------------

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        try:
            event_id = self._get_event_id(run_id, parent_run_id)
            tool_name: Optional[str] = serialized.get("name")
            if not tool_name:
                ids = serialized.get("id")
                if isinstance(ids, list) and ids:
                    tool_name = ids[-1]
            input_text = _truncate(input_str) if isinstance(input_str, str) else (
                _truncate(_safe_serialize(input_str)) if input_str is not None else None
            )
            self._spans[str(run_id)] = {
                "event_id": event_id,
                "type": "tool",
                "name": tool_name,
                "input": input_text,
                "start_time_ns": time.monotonic_ns(),
            }
        except Exception:
            logger.debug("Error in on_tool_start", exc_info=True)

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            span_data = self._spans.get(str(run_id), {})
            if span_data.get("type") != "tool":
                return
            tool_name = span_data.get("name") or "unknown"
            tool_input = span_data.get("input")
            output_str = None
            if output is not None:
                output_str = _truncate(str(output))
            start_ns = span_data.get("start_time_ns")
            duration_ms: Optional[float] = None
            if start_ns is not None:
                duration_ms = (time.monotonic_ns() - start_ns) / 1_000_000

            # Prefer interaction.track_tool when an interaction exists — it
            # ships a proper TOOL_CALL span linked to the event so the
            # dashboard's "Tool calls" section populates correctly.  Fall
            # back to a standalone ai_tool_call event if there is no active
            # interaction (e.g. tool fired before any chain root).
            if self._interaction is not None:
                try:
                    self._interaction.track_tool(
                        name=tool_name,
                        input=tool_input,
                        output=output_str,
                        duration_ms=duration_ms,
                    )
                    return
                except Exception:
                    logger.debug("Error tracking tool span via interaction", exc_info=True)

            event_id = self._event_ids.get(self._root_run_ids.get(str(run_id), str(run_id)))
            if event_id:
                properties: Dict[str, Any] = {"tool.name": tool_name}
                if tool_input:
                    properties["tool.input"] = tool_input
                if duration_ms is not None:
                    properties["tool.duration_ms"] = duration_ms
                raindrop.track_ai(
                    user_id=self._user_id or "unknown",
                    event="ai_tool_call",
                    event_id=str(uuid.uuid4()),
                    input=tool_input,
                    output=output_str,
                    properties=properties if properties else None,
                    convo_id=self._convo_id,
                )
        except Exception:
            logger.debug("Error in on_tool_end", exc_info=True)
        finally:
            self._cleanup(run_id)

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            span_data = self._spans.get(str(run_id), {})
            tool_name = span_data.get("name") or "unknown"
            tool_input = span_data.get("input")
            start_ns = span_data.get("start_time_ns")
            duration_ms: Optional[float] = None
            if start_ns is not None:
                duration_ms = (time.monotonic_ns() - start_ns) / 1_000_000

            if self._interaction is not None:
                try:
                    self._interaction.track_tool(
                        name=tool_name,
                        input=tool_input,
                        error=error,
                        duration_ms=duration_ms,
                    )
                except Exception:
                    logger.debug("Error tracking tool error via interaction", exc_info=True)

            self._track_error(run_id, error)
        except Exception:
            logger.debug("Error in on_tool_error", exc_info=True)
        finally:
            self._cleanup(run_id)

    # -------------------------------------------------------------------------
    # Agent events
    # -------------------------------------------------------------------------

    def on_agent_action(
        self,
        action: Any,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            self._get_event_id(run_id, parent_run_id)
            tool = getattr(action, "tool", None) or "unknown"
            tool_input = getattr(action, "tool_input", "")
            if not isinstance(tool_input, str):
                tool_input = _safe_serialize(tool_input)
            span_key = f"{run_id}:agent_action"
            self._spans[span_key] = {
                "type": "agent_action",
                "tool": tool,
                "tool_input": _truncate(tool_input),
            }
        except Exception:
            logger.debug("Error in on_agent_action", exc_info=True)

    def on_agent_finish(
        self,
        finish: Any,
        *,
        run_id: uuid.UUID,
        parent_run_id: Optional[uuid.UUID] = None,
        **kwargs: Any,
    ) -> None:
        try:
            span_key = f"{run_id}:agent_action"
            self._spans.pop(span_key, None)
        except Exception:
            logger.debug("Error in on_agent_finish", exc_info=True)


class RaindropDeepAgents:
    """Main entry point for the Raindrop / Deep Agents integration.

    Provides a class-based API with a ``handler`` property for LangChain
    callbacks, plus ``flush``, ``shutdown``, ``identify``, and
    ``track_signal`` helpers.

    Example::

        from raindrop_deep_agents import RaindropDeepAgents

        rd = RaindropDeepAgents(api_key="your-write-key", user_id="user-123")
        agent = create_deep_agent(tools=[...])
        result = agent.invoke(
            {"messages": [HumanMessage(content="Hello")]},
            config={"callbacks": [rd.handler]},
        )
        rd.shutdown()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        user_id: Optional[str] = None,
        convo_id: Optional[str] = None,
        tracing_enabled: bool = True,
        bypass_otel_for_tools: bool = True,
        *,
        debug: bool = False,
    ) -> None:
        if not api_key:
            warnings.warn(
                "[raindrop-deep-agents] api_key not provided; telemetry shipping is disabled",
                stacklevel=2,
            )

        # Only ever raise the module logger to DEBUG.  Calling
        # ``logger.setLevel(WARNING)`` for ``debug=False`` would silently
        # disable an earlier instance constructed with ``debug=True``,
        # since ``logging.getLogger(__name__)`` returns the same shared
        # logger object across instances.  First-instance-wins: once any
        # instance enables DEBUG, subsequent instances inherit it.
        if debug:
            logger.setLevel(logging.DEBUG)

        init_kwargs: Dict[str, Any] = {
            "api_key": api_key or "",
            "tracing_enabled": tracing_enabled,
            "bypass_otel_for_tools": bypass_otel_for_tools,
            "auto_instrument": False,
        }
        if tracing_enabled:
            try:
                init_kwargs["instruments"] = {raindrop.Instruments.LANGCHAIN}
            except (AttributeError, KeyError):
                logger.debug("raindrop.Instruments.LANGCHAIN not available", exc_info=True)
        # Defensive guard around raindrop.init: under normal circumstances
        # Traceloop swallows instrumentor activation errors (e.g. wrapt 2.x
        # incompatibility — handled by raindrop_deep_agents/_wrapt_compat.py
        # at import time, see https://github.com/traceloop/openllmetry/issues/4009)
        # and only prints a warning, so the user's app keeps working with
        # traces silently disabled.  But if Traceloop's error handling
        # ever changes — or another wrapped library propagates an
        # unexpected exception during init — we don't want the user's
        # pipeline to crash on construction.  Telemetry must never break
        # the host app.
        try:
            raindrop.init(**init_kwargs)
        except Exception:
            logger.debug(
                "raindrop.init failed; telemetry will be disabled for this instance",
                exc_info=True,
            )
            warnings.warn(
                "[raindrop-deep-agents] raindrop.init failed; telemetry "
                "shipping is disabled for this instance.  Run with "
                "debug=True to see the underlying error.",
                stacklevel=2,
            )

        self._user_id = user_id or "unknown"
        self._convo_id = convo_id
        self._debug = debug

        self._handler = RaindropDeepAgentsHandler(
            user_id=self._user_id,
            convo_id=convo_id,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def handler(self) -> RaindropDeepAgentsHandler:
        """LangChain callback handler to pass via ``config={"callbacks": [rd.handler]}``."""
        return self._handler

    @property
    def last_event_id(self) -> Optional[str]:
        """``event_id`` of the most recently shipped root event, or ``None``
        if no root event has landed yet.

        Useful for attaching a feedback :meth:`track_signal` to the agent
        invocation you just ran, without polling the dashboard API::

            rd = RaindropDeepAgents(api_key=...)
            agent.invoke({"messages": [...]}, config={"callbacks": [rd.handler]})
            if rd.last_event_id:
                rd.track_signal(
                    event_id=rd.last_event_id,
                    name="thumbs_up",
                    signal_type="feedback",
                    sentiment="POSITIVE",
                )

        Returns the event_id of the most recent successful ship; it is
        NOT reset between invocations, so back-to-back calls each pick up
        the event_id from the preceding invocation.
        """
        return self._handler._last_root_event_id

    def flush(self) -> None:
        """Flush all pending events to the Raindrop API."""
        try:
            raindrop.flush()
        except Exception:
            logger.debug("Failed to flush events", exc_info=True)

    def shutdown(self) -> None:
        """Flush remaining events and release resources."""
        try:
            raindrop.shutdown()
        except Exception:
            logger.debug("Failed to shutdown", exc_info=True)

    def identify(
        self,
        user_id: str,
        traits: Optional[Dict[str, Union[str, int, bool, float]]] = None,
    ) -> None:
        """Identify a user with optional traits.

        Args:
            user_id: The user identifier.
            traits: Optional dictionary of user traits.
        """
        try:
            raindrop.identify(user_id=user_id, traits=traits or {})
        except Exception:
            logger.debug("Failed to identify user", exc_info=True)

    def track_signal(
        self,
        event_id: str,
        name: str,
        signal_type: Literal["default", "feedback", "edit"] = "default",
        *,
        timestamp: Optional[str] = None,
        properties: Optional[Dict[str, object]] = None,
        attachment_id: Optional[str] = None,
        comment: Optional[str] = None,
        after: Optional[str] = None,
        sentiment: Optional[Literal["POSITIVE", "NEGATIVE"]] = None,
    ) -> None:
        """Track a signal event.

        Args:
            event_id: The event ID to associate the signal with.
            name: Signal name.
            signal_type: One of "default", "feedback", or "edit".
            timestamp: Optional ISO-8601 timestamp string.
            properties: Optional extra properties dict.
            attachment_id: Optional attachment identifier.
            comment: Optional comment text.
            after: Optional "after" value for edit signals.
            sentiment: Optional sentiment ("POSITIVE" or "NEGATIVE").
        """
        try:
            raindrop.track_signal(
                event_id=event_id,
                name=name,
                signal_type=signal_type,
                timestamp=timestamp,
                properties=properties,
                attachment_id=attachment_id,
                comment=comment,
                after=after,
                sentiment=sentiment,
            )
        except Exception:
            logger.debug("Failed to track signal", exc_info=True)

    # -- backwards-compat dict access ----------------------------------------

    def __getitem__(self, key: str) -> Any:
        """Support dict-style access for backwards compatibility.

        .. deprecated::
            Use attribute access instead.
        """
        _COMPAT_MAP = {"handler": "handler", "flush": "flush", "shutdown": "shutdown"}
        if key in _COMPAT_MAP:
            warnings.warn(
                f'raindrop["{key}"] is deprecated — use raindrop.{key} instead',
                DeprecationWarning,
                stacklevel=2,
            )
            return getattr(self, key)
        raise KeyError(key)


def create_raindrop_deep_agents(
    api_key: Optional[str] = None,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
    tracing_enabled: bool = True,
    bypass_otel_for_tools: bool = True,
    *,
    debug: bool = False,
) -> RaindropDeepAgents:
    """Create a Raindrop-instrumented Deep Agents client.

    This is a convenience factory that returns a :class:`RaindropDeepAgents`
    instance. Prefer using ``RaindropDeepAgents(...)`` directly for the full
    set of constructor options (e.g. ``debug``).

    Args:
        api_key: Raindrop API key. If None, telemetry is disabled.
        user_id: Associate all events with this user.
        convo_id: Conversation/session ID to group related events.
        tracing_enabled: Enable distributed tracing (default: True).
        bypass_otel_for_tools: Bypass OTEL for tool spans (default: True).
        debug: Enable debug logging (default: False).

    Returns:
        A :class:`RaindropDeepAgents` instance.

    Usage::

        from raindrop_deep_agents import create_raindrop_deep_agents

        rd = create_raindrop_deep_agents(api_key="your-write-key")
        agent = create_deep_agent(tools=[...])
        result = agent.invoke(
            {"messages": [HumanMessage(content="Hello")]},
            config={"callbacks": [rd.handler]},
        )
        rd.shutdown()
    """
    try:
        return RaindropDeepAgents(
            api_key=api_key,
            user_id=user_id,
            convo_id=convo_id,
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
            debug=debug,
        )
    except Exception:
        logger.debug("Failed to create RaindropDeepAgents", exc_info=True)
        try:
            # Forward ALL caller-provided options (including
            # tracing_enabled / bypass_otel_for_tools) to the retry.  An
            # earlier version of this fallback used the function defaults,
            # silently re-enabling tracing when the caller had explicitly
            # disabled it.
            return RaindropDeepAgents(
                api_key="",
                user_id=user_id,
                convo_id=convo_id,
                tracing_enabled=tracing_enabled,
                bypass_otel_for_tools=bypass_otel_for_tools,
                debug=debug,
            )
        except Exception:
            logger.debug("Fallback RaindropDeepAgents also failed", exc_info=True)
            warnings.warn(
                "[raindrop-deep-agents] Failed to initialize; "
                "telemetry is fully disabled for this instance",
                stacklevel=2,
            )
            # Mirror the normal __init__ contract: pass user_id or "unknown"
            # to the handler so its _user_id is consistent with attribute
            # access on the wrapper (`self._user_id`).  Otherwise the no-op
            # path leaves the handler with _user_id=None, masked at runtime
            # only by the `_user_id or "unknown"` fallback in callbacks.
            instance = object.__new__(RaindropDeepAgents)
            resolved_user_id = user_id or "unknown"
            instance._handler = RaindropDeepAgentsHandler(
                user_id=resolved_user_id,
                convo_id=convo_id,
            )
            instance._user_id = resolved_user_id
            instance._convo_id = convo_id
            instance._debug = debug
            return instance
