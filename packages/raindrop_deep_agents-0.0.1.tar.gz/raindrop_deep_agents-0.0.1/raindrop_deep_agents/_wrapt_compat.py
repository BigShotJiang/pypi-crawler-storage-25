"""Backwards-compat shim for wrapt 1.x → 2.x.

wrapt 2.0 (released 2026) renamed the first parameter of
``wrap_function_wrapper`` from ``module`` to ``target``::

    # wrapt 1.x
    def wrap_function_wrapper(module, name, wrapper): ...

    # wrapt 2.x
    def wrap_function_wrapper(target, name, wrapper): ...

About 16 OpenTelemetry instrumentation packages — including the
``opentelemetry-instrumentation-langchain`` package that powers our
trace nesting — still call this function with ``module=`` as a
keyword argument.  Under wrapt 2.x that raises::

    TypeError: wrap_function_wrapper() got an unexpected keyword
    argument 'module'

Traceloop catches the exception and silently disables the
instrumentor, so the user's app keeps running while traces never
reach the dashboard — a hard-to-debug feature loss.

This shim wraps ``wrap_function_wrapper`` (in both ``wrapt`` and
``wrapt.wrappers``, since some packages import directly from the
submodule) with a translation layer that accepts ``module=`` and
forwards it as ``target=``.  It is a no-op on wrapt 1.x and is
applied at import time so any subsequent instrumentor activation
sees the patched function.

Tracked upstream:
  - traceloop/openllmetry#4009 (the package we actually depend on,
    via raindrop-ai → traceloop-sdk → opentelemetry-instrumentation-
    langchain).  As of latest release 0.59.2 (uploaded 2026-04-16)
    the call sites still use ``module=`` — fix not shipped yet.
  - Arize-ai/openinference#2996 (a separate but identical instrumentor
    family — same bug, affects 16 packages on their side).

When the Traceloop maintainers migrate the call sites to ``target=``
(or to positional args) and ship a release, this shim becomes
pointless and can be deleted.
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def install() -> bool:
    """Install the wrapt 2.x ``module=`` → ``target=`` compat shim.

    Returns ``True`` if the shim was applied, ``False`` if not needed
    (wrapt < 2.0) or installation failed.
    """
    try:
        import wrapt
    except Exception:  # wrapt should always be importable as a transitive dep
        logger.debug("wrapt not importable — skipping compat shim", exc_info=True)
        return False

    # wrapt 1.x already accepts module= so the shim is unnecessary.  Only
    # touch wrapt 2.x and later.
    version = getattr(wrapt, "__version__", "0")
    try:
        major = int(version.split(".", 1)[0])
    except Exception:
        major = 0
    if major < 2:
        return False

    try:
        original = wrapt.wrap_function_wrapper
    except AttributeError:
        logger.debug(
            "wrapt.wrap_function_wrapper missing — cannot install compat shim",
        )
        return False

    # Idempotent: if we've already shimmed this process, don't double-wrap.
    if getattr(original, "_raindrop_deep_agents_compat_shim", False):
        return True

    def _compat_wrap_function_wrapper(
        target: Any = None,
        name: Any = None,
        wrapper: Any = None,
        *,
        module: Any = None,
    ) -> Any:
        # Translate the legacy module= kwarg to the renamed target= arg.
        # If both are provided, target wins (matches modern API).
        if target is None and module is not None:
            target = module
        return original(target, name, wrapper)

    _compat_wrap_function_wrapper._raindrop_deep_agents_compat_shim = True  # type: ignore[attr-defined]
    wrapt.wrap_function_wrapper = _compat_wrap_function_wrapper

    # Some packages import directly from wrapt.wrappers, so patch both.
    try:
        import wrapt.wrappers as _wrappers
        _wrappers.wrap_function_wrapper = _compat_wrap_function_wrapper
    except Exception:
        logger.debug(
            "Could not patch wrapt.wrappers.wrap_function_wrapper",
            exc_info=True,
        )

    logger.debug("Installed wrapt %s compat shim (module= → target=)", version)
    return True
