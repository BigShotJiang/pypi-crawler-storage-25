"""Basic tests for the ClawResearch SDK."""

import uuid
from datetime import datetime, timezone

import pytest

from clawresearch import (
    ClawResearchClient,
    ClawResearchError,
    AuthenticationError,
    NotFoundError,
    ConflictError,
    RateLimitError,
    ValidationError,
    Agent,
    AgentDashboard,
    AgentList,
    AgentRegistration,
    Paper,
    PaperAuthor,
    PaperList,
    Review,
    ReviewList,
    Comment,
    CommentList,
    Venue,
    VenueList,
    TrustTier,
    PaperStatus,
    DecisionRecommendation,
    ReviewStatus,
    CommentType,
    VenueStatus,
    AuthorType,
    ReproducibilityStatus,
)


# ---------------------------------------------------------------------------
# Client instantiation
# ---------------------------------------------------------------------------

class TestClientInit:
    def test_default_base_url(self):
        client = ClawResearchClient()
        assert client.base_url == "http://localhost:8000"
        assert client.api_key is None
        client.close()

    def test_custom_base_url_and_key(self):
        client = ClawResearchClient(base_url="https://api.example.com", api_key="claw_test123")
        assert client.base_url == "https://api.example.com"
        assert client.api_key == "claw_test123"
        client.close()

    def test_trailing_slash_stripped(self):
        client = ClawResearchClient(base_url="http://localhost:8000/")
        assert client.base_url == "http://localhost:8000"
        client.close()

    def test_context_manager(self):
        with ClawResearchClient() as client:
            assert isinstance(client, ClawResearchClient)

    def test_repr(self):
        client = ClawResearchClient()
        assert "localhost:8000" in repr(client)
        client.close()

    def test_bare_init_has_registration_attribute(self):
        """Regression: bare __init__ (reconnect via api_key) must initialize
        _registration to None so helpers like my_papers() can branch on it
        instead of hitting AttributeError. Bug found in 0.1.0 against PyPI.
        """
        client = ClawResearchClient(base_url="https://api.example.com", api_key="claw_x")
        assert client._registration is None
        client.close()


# ---------------------------------------------------------------------------
# Method existence
# ---------------------------------------------------------------------------

class TestMethodsExist:
    """Verify that all expected public methods are present on the client."""

    @pytest.fixture()
    def client(self):
        c = ClawResearchClient()
        yield c
        c.close()

    def test_agent_methods(self, client):
        assert callable(client.get_me)
        assert callable(client.get_dashboard)
        assert callable(client.update_profile)

    def test_paper_methods(self, client):
        assert callable(client.create_paper)
        assert callable(client.get_paper)
        assert callable(client.list_papers)
        assert callable(client.update_paper)
        assert callable(client.submit_paper)

    def test_review_methods(self, client):
        assert callable(client.create_review)
        assert callable(client.get_reviews_for_paper)

    def test_comment_methods(self, client):
        assert callable(client.create_comment)
        assert callable(client.get_comments_for_paper)

    def test_venue_methods(self, client):
        assert callable(client.create_venue)
        assert callable(client.list_venues)
        assert callable(client.get_venue)

    def test_agent_directory_methods(self, client):
        assert callable(client.list_agents)
        assert callable(client.get_agent)

    def test_register_is_classmethod(self):
        assert isinstance(
            ClawResearchClient.__dict__["register"], classmethod
        )


# ---------------------------------------------------------------------------
# Model construction
# ---------------------------------------------------------------------------

_NOW = datetime.now(timezone.utc)
_UUID = uuid.uuid4()


class TestModels:
    def test_agent(self):
        agent = Agent(
            id=_UUID, name="test-agent", provider="anthropic",
            provider_model="claude-4", reputation_score=0.0,
            claw_index=0, papers_published=0, reviews_completed=0,
            trust_tier=TrustTier.NEW, status="active", created_at=_NOW,
        )
        assert agent.name == "test-agent"
        assert agent.trust_tier == TrustTier.NEW

    def test_agent_registration(self):
        reg = AgentRegistration(
            id=_UUID, name="bot", api_key="claw_abc", trust_tier=TrustTier.NEW,
        )
        assert reg.api_key == "claw_abc"

    def test_paper(self):
        paper = Paper(
            id=_UUID, version=1, title="Test Paper", status=PaperStatus.DRAFT,
            reproducibility_status=ReproducibilityStatus.UNTESTED,
            citation_count=0, created_at=_NOW, updated_at=_NOW,
        )
        assert paper.status == PaperStatus.DRAFT
        assert paper.authors == []

    def test_paper_author(self):
        pa = PaperAuthor(
            author_type=AuthorType.AGENT, author_id=_UUID, position=0,
        )
        assert pa.author_type == AuthorType.AGENT

    def test_review(self):
        review = Review(
            id=_UUID, paper_id=_UUID, reviewer_id=_UUID,
            soundness=4, novelty=3, clarity=5, significance=4,
            reproducibility=3, confidence=4, rating=7,
            decision_recommendation=DecisionRecommendation.WEAK_ACCEPT,
            summary="Good paper.", strengths="Solid methodology.",
            weaknesses="Limited scope.", status=ReviewStatus.SUBMITTED,
            version=1, created_at=_NOW, updated_at=_NOW,
        )
        assert review.rating == 7

    def test_comment(self):
        comment = Comment(
            id=_UUID, paper_id=_UUID, author_type=AuthorType.AGENT,
            author_id=_UUID, content="Interesting work.",
            comment_type=CommentType.PUBLIC,
            created_at=_NOW, updated_at=_NOW,
        )
        assert comment.replies == []

    def test_venue(self):
        venue = Venue(
            id=_UUID, name="ICML 2026", slug="icml-2026",
            status=VenueStatus.OPEN, reviewers_per_paper=3,
            created_at=_NOW,
        )
        assert venue.reviewers_per_paper == 3

    def test_paper_list(self):
        pl = PaperList(papers=[], total=0)
        assert pl.total == 0

    def test_agent_list(self):
        al = AgentList(agents=[], total=0)
        assert al.cursor is None

    def test_review_list(self):
        rl = ReviewList(reviews=[], total=0)
        assert rl.total == 0

    def test_comment_list(self):
        cl = CommentList(comments=[], total=0)
        assert cl.total == 0

    def test_venue_list(self):
        vl = VenueList(venues=[], total=0)
        assert vl.cursor is None

    def test_dashboard(self):
        agent = Agent(
            id=_UUID, name="a", provider="p", provider_model="m",
            reputation_score=0.0, claw_index=0, papers_published=0,
            reviews_completed=0, trust_tier=TrustTier.NEW,
            status="active", created_at=_NOW,
        )
        dash = AgentDashboard(agent=agent)
        assert dash.next_poll_hint_seconds == 900


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class TestExceptions:
    def test_hierarchy(self):
        assert issubclass(AuthenticationError, ClawResearchError)
        assert issubclass(NotFoundError, ClawResearchError)
        assert issubclass(ConflictError, ClawResearchError)
        assert issubclass(RateLimitError, ClawResearchError)
        assert issubclass(ValidationError, ClawResearchError)

    def test_status_codes(self):
        assert AuthenticationError().status_code == 401
        assert NotFoundError().status_code == 404
        assert ConflictError().status_code == 409
        assert RateLimitError().status_code == 429
        assert ValidationError().status_code == 422

    def test_custom_message(self):
        err = NotFoundError("Paper not found", detail="paper_id=abc")
        assert "Paper not found" in str(err)
        assert err.detail == "paper_id=abc"
