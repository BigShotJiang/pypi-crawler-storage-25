"""Tests for the async ClawResearch SDK client."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from clawresearch import AsyncClawResearchClient
from clawresearch.exceptions import NotFoundError, RateLimitError
from clawresearch.models import Agent, AgentRegistration, TrustTier


_NOW = datetime.now(timezone.utc)
_UUID = uuid.uuid4()


def _agent_json() -> dict:
    """Return minimal JSON payload that satisfies the Agent model."""
    return {
        "id": str(_UUID),
        "name": "test-agent",
        "provider": "anthropic",
        "provider_model": "claude-4",
        "reputation_score": 0.0,
        "claw_index": 0,
        "papers_published": 0,
        "reviews_completed": 0,
        "trust_tier": "new",
        "status": "active",
        "created_at": _NOW.isoformat(),
    }


def _registration_json() -> dict:
    """Return minimal JSON payload that satisfies the AgentRegistration model."""
    return {
        "id": str(_UUID),
        "name": "new-bot",
        "api_key": "claw_secret123",
        "trust_tier": "new",
    }


# ---------------------------------------------------------------------------
# Client instantiation
# ---------------------------------------------------------------------------


class TestAsyncClientInit:
    def test_async_client_init(self):
        """Creates httpx.AsyncClient with correct base_url and headers."""
        client = AsyncClawResearchClient(
            base_url="https://api.example.com", api_key="claw_key123"
        )
        assert client.base_url == "https://api.example.com"
        assert client.api_key == "claw_key123"
        assert isinstance(client._client, httpx.AsyncClient)
        # Verify base_url includes the API prefix
        assert str(client._client.base_url).rstrip("/").endswith("/api/v1")
        # Verify headers contain the API key
        assert client._client.headers["x-api-key"] == "claw_key123"
        assert client._client.headers["accept"] == "application/json"

    def test_bare_init_has_registration_attribute(self):
        """Regression: bare __init__ (reconnect via api_key) must initialize
        _registration to None so helpers like my_papers() can branch on it
        instead of hitting AttributeError. Bug found in 0.1.0 against PyPI.
        """
        client = AsyncClawResearchClient(
            base_url="https://api.example.com", api_key="claw_x"
        )
        assert client._registration is None


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------


class TestAsyncClientContextManager:
    @pytest.mark.asyncio
    async def test_async_client_context_manager(self):
        """async with AsyncClawResearchClient(...) as c: works."""
        async with AsyncClawResearchClient(api_key="claw_test") as client:
            assert isinstance(client, AsyncClawResearchClient)
        # After exiting, the underlying client should be closed
        assert client._client.is_closed


# ---------------------------------------------------------------------------
# get_me
# ---------------------------------------------------------------------------


class TestAsyncGetMe:
    @pytest.mark.asyncio
    async def test_async_get_me(self):
        """Mock httpx.AsyncClient.request, verify Agent model returned."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.is_success = True
        mock_response.status_code = 200
        mock_response.json.return_value = _agent_json()

        client = AsyncClawResearchClient(api_key="claw_test")
        client._client.request = AsyncMock(return_value=mock_response)

        agent = await client.get_me()

        assert isinstance(agent, Agent)
        assert agent.name == "test-agent"
        assert agent.trust_tier == TrustTier.NEW

        client._client.request.assert_awaited_once_with("GET", "/agents/me")
        await client.close()


# ---------------------------------------------------------------------------
# register classmethod
# ---------------------------------------------------------------------------


class TestAsyncRegisterClassmethod:
    @pytest.mark.asyncio
    async def test_async_register_classmethod(self):
        """Mock httpx.AsyncClient POST, verify returns authenticated client."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.is_success = True
        mock_response.status_code = 200
        mock_response.json.return_value = _registration_json()

        mock_client_instance = AsyncMock()
        mock_client_instance.post = AsyncMock(return_value=mock_response)
        mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
        mock_client_instance.__aexit__ = AsyncMock(return_value=False)

        with patch("clawresearch.async_client.httpx.AsyncClient", return_value=mock_client_instance):
            result = await AsyncClawResearchClient.register(
                base_url="http://localhost:8000",
                name="new-bot",
                provider="anthropic",
                provider_model="claude-4",
            )

        assert isinstance(result, AsyncClawResearchClient)
        assert result.api_key == "claw_secret123"
        assert result._registration.name == "new-bot"
        await result.close()


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestAsyncErrorHandling:
    @pytest.mark.asyncio
    async def test_async_error_handling_404(self):
        """404 response raises NotFoundError."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.is_success = False
        mock_response.status_code = 404
        mock_response.json.return_value = {"detail": "Paper not found"}

        client = AsyncClawResearchClient(api_key="claw_test")
        client._client.request = AsyncMock(return_value=mock_response)

        with pytest.raises(NotFoundError, match="404"):
            await client.get_me()

        await client.close()

    @pytest.mark.asyncio
    async def test_async_error_handling_429(self):
        """429 response raises RateLimitError."""
        mock_response = MagicMock(spec=httpx.Response)
        mock_response.is_success = False
        mock_response.status_code = 429
        mock_response.json.return_value = {"detail": "Too many requests"}

        client = AsyncClawResearchClient(api_key="claw_test")
        client._client.request = AsyncMock(return_value=mock_response)

        with pytest.raises(RateLimitError, match="429"):
            await client.get_me()

        await client.close()
