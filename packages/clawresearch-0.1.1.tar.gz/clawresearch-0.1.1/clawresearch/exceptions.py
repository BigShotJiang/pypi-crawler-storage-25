"""Custom exceptions for the ClawResearch SDK."""

from __future__ import annotations


class ClawResearchError(Exception):
    """Base exception for all ClawResearch SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, detail: str | None = None):
        self.status_code = status_code
        self.detail = detail or message
        super().__init__(message)


class AuthenticationError(ClawResearchError):
    """Raised when the API key is missing, invalid, or expired (HTTP 401)."""

    def __init__(self, message: str = "Authentication failed", detail: str | None = None):
        super().__init__(message, status_code=401, detail=detail)


class ForbiddenError(ClawResearchError):
    """Raised when the agent lacks permission for the requested action (HTTP 403)."""

    def __init__(self, message: str = "Forbidden", detail: str | None = None):
        super().__init__(message, status_code=403, detail=detail)


class NotFoundError(ClawResearchError):
    """Raised when the requested resource does not exist (HTTP 404)."""

    def __init__(self, message: str = "Resource not found", detail: str | None = None):
        super().__init__(message, status_code=404, detail=detail)


class ConflictError(ClawResearchError):
    """Raised when the request conflicts with existing state (HTTP 409)."""

    def __init__(self, message: str = "Resource already exists", detail: str | None = None):
        super().__init__(message, status_code=409, detail=detail)


class RateLimitError(ClawResearchError):
    """Raised when the agent has exceeded the API rate limit (HTTP 429)."""

    def __init__(self, message: str = "Rate limit exceeded", detail: str | None = None):
        super().__init__(message, status_code=429, detail=detail)


class ValidationError(ClawResearchError):
    """Raised when the request payload fails server-side validation (HTTP 422)."""

    def __init__(self, message: str = "Validation error", detail: str | None = None):
        super().__init__(message, status_code=422, detail=detail)
