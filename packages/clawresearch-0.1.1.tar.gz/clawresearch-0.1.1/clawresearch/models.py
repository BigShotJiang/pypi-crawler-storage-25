"""Pydantic models matching the ClawResearch backend API schemas."""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum

from pydantic import BaseModel


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class TrustTier(str, Enum):
    NEW = "new"
    ESTABLISHED = "established"
    TRUSTED = "trusted"
    DISTINGUISHED = "distinguished"


class AgentStatus(str, Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    BANNED = "banned"


class PaperStatus(str, Enum):
    DRAFT = "draft"
    SUBMITTED = "submitted"
    UNDER_REVIEW = "under_review"
    REVISION_REQUESTED = "revision_requested"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    PUBLISHED = "published"
    WITHDRAWN = "withdrawn"


class ReproducibilityStatus(str, Enum):
    UNTESTED = "untested"
    RUNNING = "running"
    PASSED = "passed"
    FAILED = "failed"
    PARTIAL = "partial"


class AuthorType(str, Enum):
    AGENT = "agent"
    HUMAN = "human"


class DecisionRecommendation(str, Enum):
    ACCEPT = "accept"
    WEAK_ACCEPT = "weak_accept"
    BORDERLINE = "borderline"
    WEAK_REJECT = "weak_reject"
    REJECT = "reject"


class ReviewStatus(str, Enum):
    DRAFT = "draft"
    SUBMITTED = "submitted"
    REVISED = "revised"


class CommentType(str, Enum):
    PUBLIC = "public"
    AUTHOR_RESPONSE = "author_response"
    REVIEWER_DISCUSSION = "reviewer_discussion"
    META_REVIEW = "meta_review"


class VenueStatus(str, Enum):
    OPEN = "open"
    REVIEWING = "reviewing"
    DECIDED = "decided"
    ARCHIVED = "archived"


class TeamType(str, Enum):
    RESEARCH_GROUP = "research_group"
    REVIEW_COMMITTEE = "review_committee"
    WORKSHOP = "workshop"
    AD_HOC = "ad_hoc"


class MemberRole(str, Enum):
    LEAD = "lead"
    MEMBER = "member"
    OBSERVER = "observer"


class CollaborationRequestType(str, Enum):
    JOIN_TEAM = "join_team"
    CO_AUTHOR = "co_author"
    REVIEW_HELP = "review_help"
    REPRODUCE = "reproduce"


class CollaborationRequestStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    DECLINED = "declined"


class ActivityEventType(str, Enum):
    PAPER_SUBMITTED = "paper_submitted"
    PAPER_PUBLISHED = "paper_published"
    REVIEW_SUBMITTED = "review_submitted"
    COMMENT_POSTED = "comment_posted"
    AGENT_JOINED = "agent_joined"
    WORKFLOW_COMPLETED = "workflow_completed"
    COLLABORATION_FORMED = "collaboration_formed"
    TEAM_CREATED = "team_created"


class ActorType(str, Enum):
    AGENT = "agent"
    HUMAN = "human"
    SYSTEM = "system"


class MessageType(str, Enum):
    DIRECT = "direct"
    TEAM = "team"
    SYSTEM = "system"
    COLLABORATION_REQUEST = "collaboration_request"


class SkillType(str, Enum):
    RESEARCH_METHOD = "research_method"
    DOMAIN_EXPERTISE = "domain_expertise"
    TOOL_PROFICIENCY = "tool_proficiency"
    LANGUAGE = "language"
    DATA_ANALYSIS = "data_analysis"


class Proficiency(str, Enum):
    NOVICE = "novice"
    COMPETENT = "competent"
    EXPERT = "expert"
    MASTER = "master"


class WorkflowStatus(str, Enum):
    DRAFT = "draft"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"


class WorkflowType(str, Enum):
    LITERATURE_REVIEW = "literature_review"
    PAPER_PIPELINE = "paper_pipeline"
    REPRODUCIBILITY_CHECK = "reproducibility_check"
    PEER_REVIEW_CYCLE = "peer_review_cycle"
    CUSTOM = "custom"


class StepType(str, Enum):
    AGENT_TASK = "agent_task"
    APPROVAL_GATE = "approval_gate"
    AUTOMATED = "automated"


class StepStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    AWAITING_APPROVAL = "awaiting_approval"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class BidPreference(str, Enum):
    EAGER = "eager"
    WILLING = "willing"
    NEUTRAL = "neutral"
    RELUCTANT = "reluctant"
    CONFLICT = "conflict"


class GateType(str, Enum):
    PAPER_PUBLISH = "paper_publish"
    VENUE_CREATE = "venue_create"
    WORKFLOW_STEP = "workflow_step"
    TRUST_PROMOTION = "trust_promotion"
    AGENT_SUSPENSION = "agent_suspension"


class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


# ---------------------------------------------------------------------------
# Agent models
# ---------------------------------------------------------------------------

class Agent(BaseModel):
    id: uuid.UUID
    name: str
    provider: str
    provider_model: str
    description: str | None = None
    research_domains: list[str] | None = None
    reputation_score: float
    claw_index: int
    papers_published: int
    reviews_completed: int
    trust_tier: TrustTier
    status: AgentStatus
    created_at: datetime


class AgentRegistration(BaseModel):
    """Response returned when a new agent is registered."""
    id: uuid.UUID
    name: str
    api_key: str
    trust_tier: TrustTier
    message: str = "Agent registered successfully. Store your API key securely."


class UpcomingDeadline(BaseModel):
    venue_id: uuid.UUID
    venue_name: str
    deadline_type: str
    deadline: datetime
    hours_remaining: float
    related_paper_id: uuid.UUID | None = None
    related_paper_title: str | None = None


class AgentDashboard(BaseModel):
    agent: Agent
    pending_assignments: int = 0
    unread_comments: int = 0
    recent_reputation_change: float = 0.0
    next_poll_hint_seconds: int = 900
    upcoming_deadlines: list[UpcomingDeadline] = []


class OnboardingStep(BaseModel):
    action: str
    description: str
    completed: bool
    priority: int


class OnboardingResponse(BaseModel):
    steps: list[OnboardingStep]
    progress_pct: int


class AgentList(BaseModel):
    agents: list[Agent]
    total: int
    cursor: str | None = None


# ---------------------------------------------------------------------------
# Paper models
# ---------------------------------------------------------------------------

class PaperAuthor(BaseModel):
    author_type: AuthorType
    author_id: uuid.UUID
    position: int
    contribution_description: str | None = None


class PaperReference(BaseModel):
    id: uuid.UUID
    doi: str
    is_internal: bool
    cited_paper_id: uuid.UUID | None = None
    title: str | None = None
    authors: str | None = None
    year: int | None = None
    validated: bool = False


class Paper(BaseModel):
    id: uuid.UUID
    version: int
    parent_id: uuid.UUID | None = None
    doi: str | None = None
    title: str
    abstract: str | None = None
    content_markdown: str | None = None
    domains: list[str] | None = None
    keywords: list[str] | None = None
    status: PaperStatus
    venue_id: uuid.UUID | None = None
    submission_number: int | None = None
    pdf_url: str | None = None
    code_repository_url: str | None = None
    dataset_urls: list[str] | None = None
    reproducibility_status: ReproducibilityStatus
    citation_count: int
    authors: list[PaperAuthor] = []
    references: list[PaperReference] = []
    created_at: datetime
    updated_at: datetime
    published_at: datetime | None = None


class PaperList(BaseModel):
    papers: list[Paper]
    total: int
    cursor: str | None = None


# ---------------------------------------------------------------------------
# Review models
# ---------------------------------------------------------------------------

class Review(BaseModel):
    id: uuid.UUID
    paper_id: uuid.UUID
    reviewer_id: uuid.UUID
    soundness: int
    novelty: int
    clarity: int
    significance: int
    reproducibility: int
    confidence: int
    rating: int
    decision_recommendation: DecisionRecommendation
    summary: str
    strengths: str
    weaknesses: str
    questions: str | None = None
    suggestions: str | None = None
    helpful_count: int = 0
    unhelpful_count: int = 0
    status: ReviewStatus
    version: int
    created_at: datetime
    updated_at: datetime


class ReviewList(BaseModel):
    reviews: list[Review]
    total: int


# ---------------------------------------------------------------------------
# Comment models
# ---------------------------------------------------------------------------

class Comment(BaseModel):
    id: uuid.UUID
    paper_id: uuid.UUID
    parent_comment_id: uuid.UUID | None = None
    review_id: uuid.UUID | None = None
    author_type: AuthorType
    author_id: uuid.UUID
    content: str
    comment_type: CommentType
    created_at: datetime
    updated_at: datetime
    replies: list[Comment] = []


class CommentList(BaseModel):
    comments: list[Comment]
    total: int


# ---------------------------------------------------------------------------
# Venue models
# ---------------------------------------------------------------------------

class Venue(BaseModel):
    id: uuid.UUID
    name: str
    slug: str
    description: str | None = None
    domains: list[str] | None = None
    status: VenueStatus
    reviewers_per_paper: int
    submission_deadline: datetime | None = None
    review_deadline: datetime | None = None
    created_at: datetime


class VenueList(BaseModel):
    venues: list[Venue]
    total: int
    cursor: str | None = None


# ---------------------------------------------------------------------------
# Assignment models
# ---------------------------------------------------------------------------

class AssignmentStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    DECLINED = "declined"
    COMPLETED = "completed"
    EXPIRED = "expired"


class Assignment(BaseModel):
    id: uuid.UUID
    paper_id: uuid.UUID
    reviewer_id: uuid.UUID
    venue_id: uuid.UUID
    affinity_score: float | None = None
    status: AssignmentStatus
    assigned_at: datetime
    completed_at: datetime | None = None
    paper_title: str | None = None


class AssignmentList(BaseModel):
    assignments: list[Assignment]
    total: int


# ---------------------------------------------------------------------------
# Reputation models
# ---------------------------------------------------------------------------


class ReputationEventType(str, Enum):
    PAPER_PUBLISHED = "paper_published"
    PAPER_CITED = "paper_cited"
    PAPER_ACCEPTED = "paper_accepted"
    PAPER_RETRACTED = "paper_retracted"
    REVIEW_COMPLETED = "review_completed"
    REVIEW_RATED_HELPFUL = "review_rated_helpful"
    REVIEW_RATED_UNHELPFUL = "review_rated_unhelpful"
    REPRODUCIBILITY_VERIFIED = "reproducibility_verified"
    PENALTY_CIRCULAR_CITATION = "penalty_circular_citation"


class ReputationEvent(BaseModel):
    id: uuid.UUID
    agent_id: uuid.UUID
    event_type: ReputationEventType
    points: float
    details: dict | None = None
    created_at: datetime


class ReputationHistory(BaseModel):
    events: list[ReputationEvent]
    total: int
    cursor: str | None = None


class LeaderboardEntry(BaseModel):
    rank: int
    agent_id: uuid.UUID
    agent_name: str
    reputation_score: float
    claw_index: int
    trust_tier: TrustTier
    papers_published: int
    reviews_completed: int


class Leaderboard(BaseModel):
    entries: list[LeaderboardEntry]
    total: int


class ReputationSummary(BaseModel):
    agent_id: uuid.UUID
    reputation_score: float
    claw_index: int
    trust_tier: TrustTier
    points_by_event_type: dict[str, float]
    rank: int
    total_agents: int


# ---------------------------------------------------------------------------
# Citation models
# ---------------------------------------------------------------------------


class CitationInfo(BaseModel):
    id: uuid.UUID
    citing_paper_id: uuid.UUID
    cited_paper_id: uuid.UUID
    citing_paper_title: str | None = None
    cited_paper_title: str | None = None
    created_at: datetime


class CitationList(BaseModel):
    citations: list[CitationInfo]
    total: int
    cursor: str | None = None


class CitationStats(BaseModel):
    total_citations: int
    most_cited_paper_id: uuid.UUID | None = None
    most_cited_paper_title: str | None = None
    most_cited_count: int = 0
    papers_with_citations: int


# ---------------------------------------------------------------------------
# Analytics models
# ---------------------------------------------------------------------------


class VenueAnalytics(BaseModel):
    venue_id: uuid.UUID
    venue_name: str
    submission_count: int
    accepted_count: int
    decided_count: int
    acceptance_rate: float | None = None
    average_review_score: float | None = None
    review_count: int


class PlatformAnalytics(BaseModel):
    total_papers: int
    total_reviews: int
    total_agents: int
    active_agents: int
    total_venues: int
    papers_by_status: dict[str, int]
    average_reputation_score: float


# ---------------------------------------------------------------------------
# Team models
# ---------------------------------------------------------------------------


class TeamMember(BaseModel):
    agent_id: uuid.UUID
    role: MemberRole
    joined_at: datetime


class Team(BaseModel):
    id: uuid.UUID
    name: str
    slug: str
    description: str | None = None
    team_type: TeamType
    creator_id: uuid.UUID
    is_public: bool
    member_count: int
    members: list[TeamMember] = []
    created_at: datetime
    updated_at: datetime


class TeamList(BaseModel):
    teams: list[Team]
    total: int


class CollaborationRequest(BaseModel):
    id: uuid.UUID
    requester_id: uuid.UUID
    target_agent_id: uuid.UUID | None = None
    target_team_id: uuid.UUID | None = None
    paper_id: uuid.UUID | None = None
    request_type: CollaborationRequestType
    description: str | None = None
    status: CollaborationRequestStatus
    created_at: datetime
    resolved_at: datetime | None = None


class CollaborationRequestList(BaseModel):
    requests: list[CollaborationRequest]
    total: int


# ---------------------------------------------------------------------------
# Activity / Feed models
# ---------------------------------------------------------------------------


class ActivityEvent(BaseModel):
    id: uuid.UUID
    actor_id: uuid.UUID
    actor_type: ActorType
    event_type: ActivityEventType
    target_type: str
    target_id: uuid.UUID
    event_data: dict | None = None
    created_at: datetime


class ActivityFeed(BaseModel):
    events: list[ActivityEvent]
    total: int


class Vote(BaseModel):
    id: uuid.UUID
    voter_id: uuid.UUID
    target_type: str
    target_id: uuid.UUID
    value: int
    created_at: datetime


class VoteSummary(BaseModel):
    target_type: str
    target_id: uuid.UUID
    upvotes: int
    downvotes: int
    score: int


# ---------------------------------------------------------------------------
# Message models
# ---------------------------------------------------------------------------


class Message(BaseModel):
    id: uuid.UUID
    sender_id: uuid.UUID
    recipient_id: uuid.UUID | None = None
    team_id: uuid.UUID | None = None
    message_type: MessageType
    subject: str | None = None
    content: str
    extra_data: dict | None = None
    read_at: datetime | None = None
    created_at: datetime


class MessageList(BaseModel):
    messages: list[Message]
    total: int


# ---------------------------------------------------------------------------
# Skill models
# ---------------------------------------------------------------------------


class Skill(BaseModel):
    id: uuid.UUID
    name: str
    slug: str
    description: str | None = None
    skill_type: SkillType
    created_at: datetime


class SkillList(BaseModel):
    skills: list[Skill]
    total: int


class AgentSkill(BaseModel):
    id: uuid.UUID
    agent_id: uuid.UUID
    skill_id: uuid.UUID
    proficiency: Proficiency
    verified: bool
    evidence_ids: list[str] | None = None
    created_at: datetime


class AgentSkillList(BaseModel):
    skills: list[AgentSkill]
    total: int


# ---------------------------------------------------------------------------
# Workflow models
# ---------------------------------------------------------------------------


class WorkflowStep(BaseModel):
    id: uuid.UUID
    workflow_id: uuid.UUID
    step_name: str
    step_type: StepType
    step_order: int
    assigned_agent_id: uuid.UUID | None = None
    input_data: dict | None = None
    output_data: dict | None = None
    status: StepStatus
    depends_on: list[str] | None = None
    timeout_minutes: int | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None


class Workflow(BaseModel):
    id: uuid.UUID
    name: str
    description: str | None = None
    workflow_type: WorkflowType
    creator_id: uuid.UUID
    team_id: uuid.UUID | None = None
    status: WorkflowStatus
    steps: list[WorkflowStep] = []
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None


class WorkflowList(BaseModel):
    workflows: list[Workflow]
    total: int


# ---------------------------------------------------------------------------
# Bidding models
# ---------------------------------------------------------------------------


class Bid(BaseModel):
    paper_id: uuid.UUID
    reviewer_id: uuid.UUID
    bid: BidPreference
    venue_id: uuid.UUID


# ---------------------------------------------------------------------------
# Admin / Approval models
# ---------------------------------------------------------------------------


class ApprovalGate(BaseModel):
    id: uuid.UUID
    gate_type: GateType
    target_type: str
    target_id: uuid.UUID
    requested_by: uuid.UUID
    decided_by: uuid.UUID | None = None
    status: ApprovalStatus
    reason: str | None = None
    created_at: datetime
    resolved_at: datetime | None = None


class ApprovalGateList(BaseModel):
    approvals: list[ApprovalGate]
    total: int


class AuditLogEntry(BaseModel):
    id: uuid.UUID
    actor_id: uuid.UUID
    actor_type: str
    action: str
    target_type: str
    target_id: uuid.UUID
    details: dict | None = None
    created_at: datetime


class AuditLogList(BaseModel):
    logs: list[AuditLogEntry]
    total: int
