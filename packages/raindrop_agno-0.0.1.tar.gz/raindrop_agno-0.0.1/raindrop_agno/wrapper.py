"""
Agno agent/workflow wrapper for Raindrop observability.

Wraps Agno Agent and Workflow objects to automatically capture run() and
arun() calls and ship telemetry to Raindrop via the Interaction API.
When tracing is enabled, the Agno OpenInference instrumentor provides
properly nested spans (agent -> model -> tool) via OTEL.

Agno API:
  - Agent.run()  — synchronous, returns RunOutput
  - Agent.arun() — async, returns RunOutput

Usage:
    from raindrop_agno import create_raindrop_agno
    from agno.agent import Agent
    from agno.models.openai import OpenAIChat

    raindrop = create_raindrop_agno(api_key="rk_...", tracing_enabled=True)
    agent = Agent(model=OpenAIChat(id="gpt-4o"))
    wrapped = raindrop["wrap"](agent)

    result = wrapped.run("Hello!")
    raindrop["shutdown"]()
"""

from __future__ import annotations

import json
from typing import Any, Optional

import raindrop.analytics as raindrop


def create_raindrop_agno(
    api_key: str,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
    tracing_enabled: bool = False,
) -> dict:
    """
    Create a Raindrop-instrumented Agno wrapper.

    Args:
        api_key: Raindrop API key (rk_...).
        user_id: Associate all events with this user.
        convo_id: Conversation ID to group related events.
        tracing_enabled: Enable Raindrop tracing. When True, enables the Agno
            OpenInference instrumentor for properly nested trace spans
            (agent -> model -> tool calls).

    Returns:
        Dict with 'wrap', 'flush', and 'shutdown'.
    """
    init_kwargs: dict[str, Any] = {"api_key": api_key, "tracing_enabled": tracing_enabled}
    if tracing_enabled:
        init_kwargs["instruments"] = {raindrop.Instruments.AGNO}
    raindrop.init(**init_kwargs)

    def wrap(target: Any) -> Any:
        return wrap_agent(target, user_id=user_id, convo_id=convo_id)

    return {
        "wrap": wrap,
        "flush": raindrop.flush,
        "shutdown": raindrop.shutdown,
    }


def wrap_agent(
    agent: Any,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
) -> Any:
    """Wrap an Agno Agent or Workflow to capture run() and arun() calls.

    Agno's sync method is run(), async method is arun().
    """
    if getattr(agent, "_raindrop_wrapped", None) is True:
        return agent

    original_run = getattr(agent, "run", None)
    original_arun = getattr(agent, "arun", None)

    if original_run:
        def wrapped_run(*args: Any, **kwargs: Any) -> Any:
            return _instrument_run_sync(
                original_run, agent, args, kwargs, user_id, convo_id,
            )
        agent.run = wrapped_run

    if original_arun:
        async def wrapped_arun(*args: Any, **kwargs: Any) -> Any:
            return await _instrument_run_async(
                original_arun, agent, args, kwargs, user_id, convo_id,
            )
        agent.arun = wrapped_arun

    agent._raindrop_wrapped = True
    return agent


def _instrument_run_sync(
    original_fn: Any,
    agent: Any,
    args: tuple,
    kwargs: dict,
    user_id: Optional[str],
    convo_id: Optional[str],
) -> Any:
    """Instrument a synchronous run call with telemetry via Interaction API."""
    try:
        input_text = _extract_input_text(args, kwargs)
        model_name = _get_model_name(agent)
    except Exception:
        return original_fn(*args, **kwargs)

    interaction = None
    try:
        interaction = raindrop.begin(
            user_id=user_id or "unknown",
            event="ai_generation",
            input=input_text,
            convo_id=convo_id,
        )
    except Exception:
        pass

    try:
        result = original_fn(*args, **kwargs)
    except Exception as exc:
        if interaction:
            try:
                interaction.set_properties({
                    "agno.error": True,
                    "agno.error_message": str(exc),
                    "ai.model": model_name or "unknown",
                })
            except Exception:
                pass
            try:
                raindrop._track_ai_partial(
                    raindrop.PartialTrackAIEvent(
                        event_id=interaction.id, ai_data={"model": model_name or "unknown"}
                    )
                )
            except Exception:
                pass
            try:
                interaction.finish()
            except Exception:
                pass
        raise

    try:
        _finish_interaction(interaction, result, model_name)
    except Exception:
        pass

    return result


async def _instrument_run_async(
    original_fn: Any,
    agent: Any,
    args: tuple,
    kwargs: dict,
    user_id: Optional[str],
    convo_id: Optional[str],
) -> Any:
    """Instrument an async arun() call with telemetry via Interaction API."""
    try:
        input_text = _extract_input_text(args, kwargs)
        model_name = _get_model_name(agent)
    except Exception:
        return await original_fn(*args, **kwargs)

    interaction = None
    try:
        interaction = raindrop.begin(
            user_id=user_id or "unknown",
            event="ai_generation",
            input=input_text,
            convo_id=convo_id,
        )
    except Exception:
        pass

    try:
        result = await original_fn(*args, **kwargs)
    except Exception as exc:
        if interaction:
            try:
                interaction.set_properties({
                    "agno.error": True,
                    "agno.error_message": str(exc),
                    "ai.model": model_name or "unknown",
                })
            except Exception:
                pass
            try:
                raindrop._track_ai_partial(
                    raindrop.PartialTrackAIEvent(
                        event_id=interaction.id, ai_data={"model": model_name or "unknown"}
                    )
                )
            except Exception:
                pass
            try:
                interaction.finish()
            except Exception:
                pass
        raise

    try:
        _finish_interaction(interaction, result, model_name)
    except Exception:
        pass

    return result


def _finish_interaction(interaction: Any, result: Any, model_name: Optional[str]) -> None:
    """Extract data from RunOutput and finish the Raindrop interaction."""
    if interaction is None:
        return

    output_text = None
    finish_model = model_name
    properties: dict = {}

    try:
        output_text, prompt_tokens, completion_tokens, result_model = _extract_result(result)
        properties = _build_properties(result, prompt_tokens, completion_tokens)

        if result_model or model_name:
            properties["ai.model"] = result_model or model_name
            finish_model = result_model or model_name
    except Exception:
        pass

    if finish_model:
        try:
            raindrop._track_ai_partial(
                raindrop.PartialTrackAIEvent(
                    event_id=interaction.id, ai_data={"model": finish_model}
                )
            )
        except Exception:
            pass

    interaction.finish(
        output=output_text,
        properties=properties if properties else None,
    )


def _extract_result(result: Any) -> tuple:
    """Extract output, tokens, and model name from an Agno RunOutput.

    Returns (output_text, prompt_tokens, completion_tokens, model_name).
    """
    output_text = None
    prompt_tokens = None
    completion_tokens = None
    model_name = None

    content = getattr(result, "content", None)
    if content is not None:
        output_text = _safe_str(content)
    else:
        output = getattr(result, "output", None)
        if output is None:
            output = getattr(result, "data", None)
        if output is not None:
            output_text = _safe_str(output)

    prompt_tokens, completion_tokens = _extract_tokens(result)

    try:
        model_name = getattr(result, "model", None)
        if model_name is None:
            response_data = getattr(result, "response_data", None)
            if response_data is not None:
                model_name = getattr(response_data, "model", None)
    except Exception:
        pass

    return output_text, prompt_tokens, completion_tokens, model_name


def _extract_tokens(result: Any) -> tuple:
    """Extract prompt/completion tokens from RunOutput metrics.

    Handles dict, callable, and RunMetrics dataclass objects.
    """
    prompt_tokens = None
    completion_tokens = None

    try:
        metrics_attr = getattr(result, "metrics", None)
        if metrics_attr is not None:
            if isinstance(metrics_attr, dict):
                prompt_tokens = metrics_attr.get("input_tokens")
                completion_tokens = metrics_attr.get("output_tokens")
            elif callable(metrics_attr):
                metrics_dict = metrics_attr()
                if isinstance(metrics_dict, dict):
                    prompt_tokens = metrics_dict.get("input_tokens")
                    completion_tokens = metrics_dict.get("output_tokens")
            else:
                prompt_tokens = getattr(metrics_attr, "input_tokens", None)
                completion_tokens = getattr(metrics_attr, "output_tokens", None)
                if prompt_tokens is None and completion_tokens is None:
                    try:
                        as_dict = metrics_attr.to_dict() if hasattr(metrics_attr, "to_dict") else vars(metrics_attr)
                        prompt_tokens = as_dict.get("input_tokens")
                        completion_tokens = as_dict.get("output_tokens")
                    except Exception:
                        pass
    except Exception:
        pass

    if prompt_tokens is not None or completion_tokens is not None:
        return prompt_tokens, completion_tokens

    try:
        usage_attr = getattr(result, "usage", None)
        if usage_attr is not None:
            usage = usage_attr() if callable(usage_attr) else usage_attr
            if usage is not None:
                prompt_tokens = getattr(usage, "input_tokens", None)
                if prompt_tokens is None:
                    prompt_tokens = getattr(usage, "prompt_tokens", None)
                completion_tokens = getattr(usage, "output_tokens", None)
                if completion_tokens is None:
                    completion_tokens = getattr(usage, "completion_tokens", None)
    except Exception:
        pass

    return prompt_tokens, completion_tokens


def _build_properties(
    result: Any,
    prompt_tokens: Optional[int],
    completion_tokens: Optional[int],
) -> dict:
    """Build properties dict including tokens and Agno identity fields."""
    props: dict = {}

    if prompt_tokens is not None:
        props["ai.usage.prompt_tokens"] = prompt_tokens
    if completion_tokens is not None:
        props["ai.usage.completion_tokens"] = completion_tokens

    try:
        run_id = getattr(result, "run_id", None)
        if run_id:
            props["agno.run_id"] = str(run_id)

        session_id = getattr(result, "session_id", None)
        if session_id:
            props["agno.session_id"] = str(session_id)

        agent_id = getattr(result, "agent_id", None)
        if agent_id:
            props["agno.agent_id"] = str(agent_id)

        agent_name = getattr(result, "agent_name", None)
        if agent_name:
            props["agno.agent_name"] = str(agent_name)

        workflow_id = getattr(result, "workflow_id", None)
        if workflow_id:
            props["agno.workflow_id"] = str(workflow_id)

        tools = getattr(result, "tools", None)
        if tools:
            props["agno.tool_calls_count"] = len(tools)
    except Exception:
        pass

    return props


def _extract_input_text(args: tuple, kwargs: dict) -> Optional[str]:
    """Extract the user's input text from positional/keyword arguments.

    Agno's run()/arun() accept the message as the first positional arg
    or as keyword ``message=`` / ``input=``.
    """
    # First positional arg is the message
    if args:
        return _safe_str(args[0])
    # Keyword variants used by Agno
    for key in ("message", "input"):
        if key in kwargs:
            return _safe_str(kwargs[key])
    return None


def _get_model_name(agent: Any) -> Optional[str]:
    """Try to extract the model name from the agent's configuration."""
    try:
        model = getattr(agent, "model", None)
        if model is None:
            return None
        if isinstance(model, str):
            return model
        model_id = getattr(model, "id", None)
        if model_id:
            return str(model_id)
        model_name = getattr(model, "model_name", None)
        if model_name:
            return str(model_name)
        name = getattr(model, "name", None)
        if name:
            return str(name)
        return str(model)
    except Exception:
        return None


def _safe_str(value: Any) -> Optional[str]:
    """Convert a value to string safely, handling Pydantic models and non-serializable types."""
    if value is None:
        return None
    if isinstance(value, str):
        return value
    try:
        if hasattr(value, "model_dump_json"):
            return value.model_dump_json()
        if hasattr(value, "model_dump"):
            return json.dumps(value.model_dump(), default=str)
        return json.dumps(value, default=str)
    except Exception:
        try:
            return str(value)
        except Exception:
            return None
