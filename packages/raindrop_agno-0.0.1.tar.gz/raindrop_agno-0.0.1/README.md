# raindrop-agno

Raindrop integration for [Agno](https://github.com/agno-agi/agno) — a Python agent framework for building AI applications.

Wraps Agno `Agent`, `Team`, and `Workflow` objects to automatically capture runs and ship telemetry to Raindrop. When tracing is enabled, the Agno OpenInference instrumentor provides properly nested spans (agent -> model -> tool calls).

## Installation

```bash
pip install raindrop-agno agno
```

## Quick Start

```python
from raindrop_agno import create_raindrop_agno
from agno.agent import Agent
from agno.models.openai import OpenAIChat

raindrop = create_raindrop_agno(
    api_key="rk_...",
    user_id="user-123",
    tracing_enabled=True,
)

agent = Agent(model=OpenAIChat(id="gpt-4o"))
wrapped = raindrop["wrap"](agent)

result = wrapped.run("What is the capital of France?")
print(result.content)

raindrop["shutdown"]()
```

## What Gets Traced

- **Agent runs** — input prompt, output text, model name
- **Token usage** — input_tokens and output_tokens from the Agno RunOutput metrics
- **Tool calls** — nested spans with name, arguments, result, errors, duration (requires `tracing_enabled=True`)
- **Model calls** — LLM invocations as nested child spans (requires `tracing_enabled=True`)
- **Team delegation** — member agent calls appear as nested spans under the team run
- **Errors** — captured (with error message) and re-raised to the caller
- **Async support** — both `run()` (sync) and `arun()` (async) are instrumented
- **Agno identity** — run_id, session_id, agent_name forwarded as properties

## Configuration

```python
raindrop = create_raindrop_agno(
    api_key="rk_...",           # Required: your Raindrop API key
    user_id="user-123",        # Optional: associate events with a user
    convo_id="convo-456",      # Optional: conversation/thread ID
    tracing_enabled=True,      # Recommended: enables nested trace spans
)
```

When `tracing_enabled=True`, the integration enables the Agno OpenInference instrumentor (`Instruments.AGNO`), which automatically creates properly nested OTEL spans for agent runs, model calls, and tool executions. This gives full trace visibility in the Raindrop dashboard.

## Tool Call Tracking

When your agent uses tools and tracing is enabled, each tool execution appears as a nested span in the trace view with input arguments, output, and duration:

```python
def get_stock_price(symbol: str) -> str:
    return "189.50"

agent = Agent(
    model=OpenAIChat(id="gpt-4o-mini"),
    tools=[get_stock_price],
)
wrapped = raindrop["wrap"](agent)
result = wrapped.run("What is the price of AAPL?")
```

Tool call count is also captured in event properties as `agno.tool_calls_count`.

## Wrapping Agents and Workflows

The `wrap()` function works with Agno Agents and Workflows. For Teams, wrap each member agent individually:

```python
from agno.agent import Agent
from agno.models.openai import OpenAIChat

agent = Agent(model=OpenAIChat(id="gpt-4o"))
wrapped_agent = raindrop["wrap"](agent)
```

## Flushing and Shutdown

Always call `shutdown()` before your process exits to ensure all telemetry is shipped:

```python
raindrop["shutdown"]()  # flush + release resources
```

## Known Limitations

- **Streaming**: `run(stream=True)` does not produce events, but trace spans are still captured when `tracing_enabled=True`.
- **Multi-step agent runs**: The event captures the final result. Individual LLM and tool calls appear as nested trace spans when `tracing_enabled=True`.

For `identify()`, `track_signal()`, and other SDK functions, use `import raindrop.analytics as raindrop` directly alongside the wrapper.

## Testing

```bash
cd packages/agno-python
pip install -e .
pip install pytest
pytest
```
