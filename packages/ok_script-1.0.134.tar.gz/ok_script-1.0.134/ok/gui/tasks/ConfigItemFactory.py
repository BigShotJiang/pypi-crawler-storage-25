from ok.gui.tasks.LabelAndButtons import LabelAndButtons
from ok.gui.tasks.LabelAndDoubleSpinBox import LabelAndDoubleSpinBox
from ok.gui.tasks.LabelAndDropDown import LabelAndDropDown
from ok.gui.tasks.LabelAndGlobal import LabelAndGlobal
from ok.gui.tasks.LabelAndLineEdit import LabelAndLineEdit
from ok.gui.tasks.LabelAndMultiSelection import LabelAndMultiSelection
from ok.gui.tasks.LabelAndSpinBox import LabelAndSpinBox
from ok.gui.tasks.LabelAndSwitchButton import LabelAndSwitchButton
from ok.gui.tasks.LabelAndTextEdit import LabelAndTextEdit
from ok.gui.tasks.ModifyListItem import ModifyListItem


def _resolve_type(the_type, default_value):
    if not isinstance(the_type, dict):
        return None

    resolved_type = the_type.get('type')
    if resolved_type:
        return resolved_type
    if 'buttons' in the_type or 'callback' in the_type:
        return 'button'
    if 'options' in the_type:
        if isinstance(default_value, list):
            return 'multi_selection'
        return 'drop_down'
    return None


def config_widget(config_type, config_desc, config, key, value, task):
    the_type = config_type.get(key) if config_type is not None else None
    value = config.get_default(key)
    resolved_type = _resolve_type(the_type, value)
    if resolved_type:
        if resolved_type == 'drop_down':
            if isinstance(value, list) and 'options_available' in the_type:
                return ModifyListItem(
                    config_desc, config, key, options_available=the_type['options_available'],
                    allow_duplication=the_type.get('allow_duplication', False)
                )
            return LabelAndDropDown(config_desc, the_type['options'], config, key)
        elif resolved_type == 'multi_selection':
            return LabelAndMultiSelection(config_desc, the_type['options'], config, key)
        elif resolved_type == 'global':
            config = task.get_global_config(key)
            desc = task.get_global_config_desc(key)
            return LabelAndGlobal(desc, config, key)
        elif resolved_type == 'text_edit':
            return LabelAndTextEdit(config_desc, config, key)
        elif resolved_type == 'button':
            buttons = the_type.get('buttons')
            if not buttons:
                buttons = [the_type]
            return LabelAndButtons(config_desc, key, buttons)
        else:
            raise Exception('Unknown config type')
    if isinstance(value, bool):
        return LabelAndSwitchButton(config_desc, config, key)
    elif isinstance(value, list):
        options_available = the_type.get('options_available') if isinstance(the_type, dict) else None
        allow_duplication = the_type.get('allow_duplication', False) if isinstance(the_type, dict) else False
        return ModifyListItem(
            config_desc, config, key, options_available=options_available,
            allow_duplication=allow_duplication
        )
    elif isinstance(value, int):
        return LabelAndSpinBox(config_desc, config, key)
    elif isinstance(value, float):
        return LabelAndDoubleSpinBox(config_desc, config, key)
    elif isinstance(value, str):
        if value and len(value) > 16 or '\n' in value:
            return LabelAndTextEdit(config_desc, config, key)
        else:
            return LabelAndLineEdit(config_desc, config, key)
    else:
        raise ValueError(f"invalid type {type(value)}, value {value}")
