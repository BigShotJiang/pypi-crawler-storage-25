"""Calc Discovery Path"""
__version__ = "1.0.0"
