"""Interactive configuration wizard for first-time setup."""

from __future__ import annotations

import os

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

from openlaoke.types.providers import MultiProviderConfig, ProviderConfig, ProviderType
from openlaoke.utils.config import AppConfig

console = Console(force_terminal=True)


def run_config_wizard(config: AppConfig | None = None) -> AppConfig:
    """Run the interactive configuration wizard."""
    config = config or AppConfig()

    console.clear()
    console.print(
        Panel.fit(
            "[bold cyan]OpenLaoKe Configuration Wizard[/bold cyan]\n"
            "[dim]Let's set up your AI coding assistant[/dim]",
            border_style="cyan",
        )
    )
    console.print()

    # Step 1: Configure provider
    while True:
        console.print("[bold]Step 1: Choose your AI provider[/bold]")
        console.print()

        table = Table(show_header=False, box=None)
        table.add_column("Option", style="cyan")
        table.add_column("Provider", style="bold")
        table.add_column("Status", style="dim")

        # Check local providers dynamically
        ollama_cfg = config.providers.providers.get("ollama")
        if ollama_cfg is None:
            ollama_cfg = ProviderConfig(provider_type=ProviderType.OLLAMA, is_local=True)
        ollama_status = "local" if ollama_cfg.is_configured() else "not found"

        lm_cfg = config.providers.providers.get("lm_studio")
        if lm_cfg is None:
            lm_cfg = ProviderConfig(provider_type=ProviderType.LM_STUDIO, is_local=True)
        lm_status = "local" if lm_cfg.is_configured() else "not found"

        providers = [
            ("1", "🟠 Ollama (Local)", "ollama", ollama_status),
            ("2", "🆓 OpenCode Zen (FREE)", "opencode", "free"),
            ("3", "💻 Built-in GGUF Model (Local)", "local_builtin", "local"),
            ("4", "MiniMax", "minimax", "cloud"),
            ("5", "Aliyun Coding Plan", "aliyun_coding_plan", "cloud"),
            ("6", "Anthropic", "anthropic", "cloud"),
            ("7", "OpenAI (GPT-4)", "openai", "cloud"),
            ("8", "Azure OpenAI", "azure_openai", "cloud"),
            ("9", "Google AI (Gemini)", "google", "cloud"),
            ("10", "Google Vertex AI", "google_vertex", "cloud"),
            ("11", "AWS Bedrock", "aws_bedrock", "cloud"),
            ("12", "xAI Grok", "xai", "cloud"),
            ("13", "Mistral AI", "mistral", "cloud"),
            ("14", "Groq", "groq", "cloud"),
            ("15", "Cerebras", "cerebras", "cloud"),
            ("16", "Cohere", "cohere", "cloud"),
            ("17", "DeepInfra", "deepinfra", "cloud"),
            ("18", "Together AI", "togetherai", "cloud"),
            ("19", "Perplexity", "perplexity", "cloud"),
            ("20", "OpenRouter", "openrouter", "cloud"),
            ("21", "GitHub Copilot", "github_copilot", "cloud"),
            ("22", "LM Studio (Local)", "lm_studio", lm_status),
            ("23", "OpenAI-Compatible (Custom)", "openai_compatible", "custom"),
            ("24", "Skip (configure later)", "", ""),
        ]

        for opt, name, key, ptype in providers:
            if key and key in config.providers.providers:
                provider = config.providers.providers[key]
                if key in ("ollama", "lm_studio"):
                    status = (
                        "[green]✓ local[/green]" if ptype == "local" else "[dim]not found[/dim]"
                    )
                else:
                    status = _get_provider_status(provider)
                table.add_row(f"  [{opt}]", name, status)
            elif key == "":
                table.add_row(f"  [{opt}]", name, "")
            else:
                table.add_row(f"  [{opt}]", name, "[dim]not configured[/dim]")

        console.print(table)
        console.print()

        choice = Prompt.ask(
            "Select provider",
            choices=[str(i) for i in range(1, 25)],
            default="1",
        )

        provider_map = {
            "1": "ollama",
            "2": "opencode",
            "3": "local_builtin",
            "4": "minimax",
            "5": "aliyun_coding_plan",
            "6": "anthropic",
            "7": "openai",
            "8": "azure_openai",
            "9": "google",
            "10": "google_vertex",
            "11": "aws_bedrock",
            "12": "xai",
            "13": "mistral",
            "14": "groq",
            "15": "cerebras",
            "16": "cohere",
            "17": "deepinfra",
            "18": "togetherai",
            "19": "perplexity",
            "20": "openrouter",
            "21": "github_copilot",
            "22": "lm_studio",
            "23": "openai_compatible",
        }

        if choice == "24":
            console.print("\n[yellow]You can configure later by running:[/yellow]")
            console.print("  openlaoke --config")
            console.print()
            return config

        provider_key = provider_map[choice]
        config.providers = _configure_provider(config.providers, provider_key)

        if _check_provider_ready(config.providers, provider_key):
            set_as_default = Confirm.ask(
                f"\nSet {provider_key} as your default provider?",
                default=True,
            )
            if set_as_default:
                config.providers.active_provider = provider_key
                console.print(f"[green]✓[/green] Active provider set to: {provider_key}")
                break
        else:
            console.print("\n[yellow]Provider not fully configured. Try again?[/yellow]")
            if not Confirm.ask("Continue setup?", default=True):
                break

    # Step 2: Configure proxy
    console.print()
    config = _configure_proxy(config)

    # Done
    console.print()
    console.print("[bold green]Configuration complete![/bold green]")
    console.print(f"\nActive provider: [cyan]{config.providers.active_provider}[/cyan]")
    console.print(f"Active model: [cyan]{config.providers.get_active_model()}[/cyan]")
    console.print(f"Proxy: [cyan]{_get_proxy_display(config)}[/cyan]")
    console.print()

    config.first_run = False
    return config


def _get_proxy_display(config: AppConfig) -> str:
    if config.proxy_mode == "none":
        return "disabled"
    elif config.proxy_mode == "system":
        return "use system proxy"
    elif config.proxy_mode == "custom":
        return config.proxy_url or "(not set)"
    return "unknown"


def _get_env_var_name(provider_type: ProviderType) -> str:
    """Get environment variable name for a provider type."""
    env_map = {
        ProviderType.ANTHROPIC: "ANTHROPIC_API_KEY",
        ProviderType.OPENAI: "OPENAI_API_KEY",
        ProviderType.MINIMAX: "MINIMAX_API_KEY",
        ProviderType.ALIYUN_CODING_PLAN: "ALIYUN_API_KEY",
        ProviderType.AZURE_OPENAI: "AZURE_OPENAI_API_KEY",
        ProviderType.GOOGLE: "GOOGLE_API_KEY",
        ProviderType.GOOGLE_VERTEX: "GOOGLE_APPLICATION_CREDENTIALS",
        ProviderType.AWS_BEDROCK: "AWS_ACCESS_KEY_ID",
        ProviderType.XAI: "XAI_API_KEY",
        ProviderType.MISTRAL: "MISTRAL_API_KEY",
        ProviderType.GROQ: "GROQ_API_KEY",
        ProviderType.CEREBRAS: "CEREBRAS_API_KEY",
        ProviderType.COHERE: "COHERE_API_KEY",
        ProviderType.DEEPINFRA: "DEEPINFRA_API_KEY",
        ProviderType.TOGETHERAI: "TOGETHERAI_API_KEY",
        ProviderType.PERPLEXITY: "PERPLEXITY_API_KEY",
        ProviderType.OPENROUTER: "OPENROUTER_API_KEY",
        ProviderType.GITHUB_COPILOT: "GITHUB_TOKEN",
        ProviderType.OPENCODE: "OPENCODE_API_KEY",
        ProviderType.OPENAI_COMPATIBLE: "OPENAI_API_KEY",
    }
    return env_map.get(provider_type, "")


def _get_provider_status(provider: ProviderConfig) -> str:
    """Get human-readable status for a provider's API key configuration."""
    if provider.is_local:
        return "[green]✓ local[/green]"
    if provider.provider_type == ProviderType.OPENCODE:
        return "[green]✓ FREE (no key needed)[/green]"
    if provider.api_key:
        return "[green]✓ stored[/green]"

    env_var_name = _get_env_var_name(provider.provider_type)
    if env_var_name and os.environ.get(env_var_name):
        return "[green]✓ env var[/green]"
    return "[yellow]needs setup[/yellow]"


def _check_provider_ready(config: MultiProviderConfig, key: str) -> bool:
    """Check if a provider is ready to use."""
    provider = config.providers.get(key)
    if not provider:
        return False
    return provider.is_configured()


def _configure_proxy(config: AppConfig) -> AppConfig:
    """Configure proxy settings."""
    console.print("[bold]Step 2: Proxy Configuration[/bold]")
    console.print("[dim]Configure network proxy for API requests[/dim]\n")

    table = Table(show_header=False, box=None)
    table.add_column("Option", style="cyan")
    table.add_column("Mode", style="bold")
    table.add_column("Description", style="dim")

    table.add_row("  [1]", "No proxy", "Direct connection (default)")
    table.add_row("  [2]", "System proxy", "Use system HTTP/HTTPS proxy settings")
    table.add_row("  [3]", "Custom proxy", "Specify a custom proxy URL")

    console.print(table)
    console.print()

    choice = Prompt.ask(
        "Select proxy mode",
        choices=["1", "2", "3"],
        default="1",
    )

    if choice == "1":
        config.proxy_mode = "none"
        config.proxy_url = ""
        console.print("[green]✓[/green] Proxy disabled")
    elif choice == "2":
        config.proxy_mode = "system"
        config.proxy_url = ""
        system_proxy = os.environ.get("HTTP_PROXY") or os.environ.get("HTTPS_PROXY") or ""
        if system_proxy:
            console.print(f"[green]✓[/green] Will use system proxy: {system_proxy}")
        else:
            console.print("[green]✓[/green] Will use system proxy (none detected)")
    elif choice == "3":
        config.proxy_mode = "custom"
        default_url = config.proxy_url or "http://127.0.0.1:7890"
        proxy_url = Prompt.ask(
            "Enter proxy URL",
            default=default_url,
        )
        config.proxy_url = proxy_url
        console.print(f"[green]✓[/green] Custom proxy set: {proxy_url}")

    return config


def _configure_provider(config: MultiProviderConfig, key: str) -> MultiProviderConfig:
    """Configure a specific provider."""
    provider = config.providers.get(key)
    if not provider:
        return config

    console.print(f"\n[bold]Configuring {key}[/bold]")

    # Check available configurations
    stored_key = provider.api_key
    env_var_name = _get_env_var_name(provider.provider_type)
    env_key = os.environ.get(env_var_name, "")

    # Show configuration options
    if stored_key or env_key:
        console.print()
        table = Table(show_header=False, box=None)
        table.add_column("Option", style="cyan")
        table.add_column("Source", style="bold")
        table.add_column("Details", style="dim")

        options = []
        default_choice = "1"

        if stored_key:
            masked_key = (
                f"{stored_key[:8]}...{stored_key[-4:]}" if len(stored_key) > 12 else stored_key
            )
            table.add_row(
                "  [1]", "Stored config", f"Key: {masked_key}, Model: {provider.default_model}"
            )
            options.append("1")
            default_choice = "1"

        if env_key:
            masked_env = f"{env_key[:8]}...{env_key[-4:]}" if len(env_key) > 12 else env_key
            option_num = str(len(options) + 1)
            table.add_row(f"  [{option_num}]", "Environment var", f"{env_var_name}={masked_env}")
            options.append(option_num)
            if not stored_key:
                default_choice = option_num

        option_num = str(len(options) + 1)
        table.add_row(f"  [{option_num}]", "Reconfigure", "Enter new API key and settings")
        options.append(option_num)

        console.print(table)
        console.print()

        choice = Prompt.ask(
            "Select configuration source",
            choices=options,
            default=default_choice,
        )

        # Use stored configuration (complete config, can return)
        if choice == "1" and stored_key:
            console.print(f"[green]✓ Using stored configuration for {key}[/green]")
            return config

        # Use environment variable (need to continue config for model selection)
        if env_key:
            env_option_idx = 2 if stored_key else 1
            if choice == str(env_option_idx):
                provider.api_key = env_key
                console.print(f"[green]✓ Using {env_var_name} from environment[/green]")
                console.print("[dim]Continue with model selection...[/dim]\n")
            elif choice == options[-1]:
                # Reconfigure - will ask for new API key below
                console.print("\n[yellow]Reconfiguring...[/yellow]")
        elif choice == options[-1]:
            console.print("\n[yellow]Reconfiguring...[/yellow]")

    console.print("[dim]Press Enter to use default value[/dim]\n")

    if key == "local_builtin":
        return _configure_builtin_provider(config, provider, console)

    if provider.is_local:
        base_url = Prompt.ask(
            "API URL",
            default=provider.base_url,
        )
        provider.base_url = base_url

        if key == "ollama":
            models = MultiProviderConfig._detect_ollama_models(base_url.replace("/v1", ""))
            if models:
                console.print(f"[green]✓ Detected {len(models)} models from Ollama[/green]")
                provider.models = models
                provider.default_model = _select_model_from_list(models, provider.default_model)
            else:
                console.print("\n[yellow]⚠ Could not detect models from Ollama.[/yellow]")
                console.print("[dim]Make sure Ollama is running: ollama serve[/dim]")
                console.print("[dim]Or pull some models: ollama pull gemma3:1b[/dim]\n")
                console.print("[bold]Using default model list (you can change this later):[/bold]")
                provider.default_model = _select_model_from_list(
                    provider.models, provider.default_model
                )
        else:
            provider.default_model = _select_model_from_list(
                provider.models, provider.default_model
            )

    elif provider.provider_type == ProviderType.OPENAI_COMPATIBLE:
        console.print("[dim]Enter your custom OpenAI-compatible API details[/dim]")

        base_url = Prompt.ask(
            "API Base URL",
            default=provider.base_url or "http://localhost:8000/v1",
        )
        provider.base_url = base_url

        # Ask for API key if not already set
        if not provider.api_key:
            api_key = Prompt.ask(
                "API Key (required for this provider)",
                password=True,
            )
            provider.api_key = api_key

        if not provider.api_key:
            console.print("[bold red]Warning: No API key provided. API calls may fail.[/bold red]")

        default_model = Prompt.ask(
            "Model name",
            default=provider.default_model or provider.models[0] if provider.models else "default",
        )
        provider.default_model = default_model

    elif provider.provider_type == ProviderType.MINIMAX:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter MiniMax API Key", password=True)

        base_url = Prompt.ask(
            "API Base URL (press Enter for default)",
            default=provider.base_url,
        )
        provider.base_url = base_url
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.ALIYUN_CODING_PLAN:
        if not provider.api_key:
            provider.api_key = Prompt.ask(
                "Enter Aliyun Coding Plan API Key (format: sk-sp-xxxxx)", password=True
            )

        base_url = Prompt.ask(
            "API Base URL (press Enter for default)",
            default=provider.base_url,
        )
        provider.base_url = base_url
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.AZURE_OPENAI:
        console.print("[dim]Azure OpenAI requires endpoint and API key[/dim]")

        # Endpoint configuration
        env_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
        if env_endpoint and not provider.base_url:
            console.print("[green]✓ Found AZURE_OPENAI_ENDPOINT in environment[/green]")
            use_env = Confirm.ask("Use this endpoint?", default=True)
            if use_env:
                provider.base_url = env_endpoint

        if not provider.base_url:
            provider.base_url = Prompt.ask(
                "Enter Azure OpenAI Endpoint (e.g., https://your-resource.openai.azure.com)"
            )

        # API key configuration
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter Azure OpenAI API Key", password=True)

        console.print(
            f"\n[dim]Available models (deployment names): {', '.join(provider.models)}[/dim]"
        )
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.GOOGLE:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter Google AI API Key", password=True)
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.GOOGLE_VERTEX:
        console.print("[dim]Google Vertex AI uses GCP Application Default Credentials[/dim]")
        env_project = os.environ.get("GOOGLE_VERTEX_PROJECT", "")
        if env_project:
            console.print("[green]✓ Found GOOGLE_VERTEX_PROJECT in environment[/green]")
        else:
            project_id = Prompt.ask("Enter GCP Project ID")
            os.environ["GOOGLE_VERTEX_PROJECT"] = project_id
        env_location = os.environ.get("GOOGLE_VERTEX_LOCATION", "")
        if env_location:
            console.print("[green]✓ Found GOOGLE_VERTEX_LOCATION in environment[/green]")
        else:
            location = Prompt.ask("Enter GCP Location (e.g., us-central1)", default="us-central1")
            os.environ["GOOGLE_VERTEX_LOCATION"] = location
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.AWS_BEDROCK:
        console.print("[dim]AWS Bedrock uses AWS credentials from environment[/dim]")
        env_key = os.environ.get("AWS_ACCESS_KEY_ID", "")
        if env_key:
            console.print("[green]✓ Found AWS_ACCESS_KEY_ID in environment[/green]")
        else:
            console.print(
                "[yellow]AWS credentials not found. Configure with AWS CLI or set environment variables[/yellow]"
            )
        env_region = os.environ.get("AWS_REGION", "")
        if env_region:
            console.print("[green]✓ Found AWS_REGION in environment[/green]")
        else:
            region = Prompt.ask("Enter AWS Region (e.g., us-east-1)", default="us-east-1")
            os.environ["AWS_REGION"] = region
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.XAI:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter xAI API Key", password=True)
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.MISTRAL:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter Mistral API Key", password=True)
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.GROQ:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter Groq API Key", password=True)
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.CEREBRAS:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter Cerebras API Key", password=True)
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.COHERE:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter Cohere API Key", password=True)
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.DEEPINFRA:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter DeepInfra API Key", password=True)
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.TOGETHERAI:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter Together AI API Key", password=True)
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.PERPLEXITY:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter Perplexity API Key", password=True)
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.OPENROUTER:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter OpenRouter API Key", password=True)
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.GITHUB_COPILOT:
        if not provider.api_key:
            provider.api_key = Prompt.ask("Enter GitHub Personal Access Token", password=True)
        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    elif provider.provider_type == ProviderType.OPENCODE:
        console.print("[green]✓ No API key required - completely free![/green]")
        console.print("\n[bold]Available free models:[/bold]")
        for i, model in enumerate(provider.models, 1):
            marker = " [cyan](default)[/cyan]" if model == provider.default_model else ""
            console.print(f"  [{i}] {model}{marker}")

        choices = [str(i) for i in range(1, len(provider.models) + 1)]
        selection = Prompt.ask(
            "\nSelect model",
            choices=choices,
            default="1",
        )
        provider.default_model = provider.models[int(selection) - 1]
        provider.enabled = True
        config.providers[key] = provider

        console.print(f"\n[green]✓ Configured {key} with model {provider.default_model}[/green]")
        return config

    else:
        if not provider.api_key:
            api_key = Prompt.ask(
                f"Enter your {key} API Key",
                password=True,
            )
            provider.api_key = api_key

        if key == "anthropic":
            base_url = Prompt.ask(
                "API Base URL (press Enter for default)",
                default=provider.base_url,
            )
        else:
            base_url = Prompt.ask(
                "API Base URL (press Enter for default)",
                default=provider.base_url,
            )
        provider.base_url = base_url

        console.print(f"\n[dim]Available models: {', '.join(provider.models)}[/dim]")
        provider.default_model = _select_model_from_list(provider.models, provider.default_model)

    provider.enabled = True
    config.providers[key] = provider

    return config


def _select_model_from_list(models: list[str], default: str) -> str:
    """Show a numbered list of models and let user select one."""
    if not models:
        return default

    if len(models) == 1:
        console.print(f"[green]Using model: {models[0]}[/green]")
        return models[0]

    # Find preferred default
    preferred_defaults = [
        "qwen3:0.6b",
        "gemma3:1b",
        "gemma4:e4b",
        "llama3.2",
        "gpt-4o",
        "claude-sonnet-4-20250514",
    ]
    actual_default = default
    for pref in preferred_defaults:
        if pref in models:
            actual_default = pref
            break

    console.print("\n[bold]Available models:[/bold]")
    for i, model in enumerate(models, 1):
        marker = " [cyan](default)[/cyan]" if model == actual_default else ""
        console.print(f"  [{i}] {model}{marker}")

    default_idx = models.index(actual_default) + 1 if actual_default in models else 1

    choices = [str(i) for i in range(1, len(models) + 1)]
    selection = Prompt.ask(
        "\nSelect model",
        choices=choices,
        default=str(default_idx),
    )

    return models[int(selection) - 1]


def _configure_builtin_provider(
    config: MultiProviderConfig,
    provider: ProviderConfig,
    console: Console,
) -> MultiProviderConfig:
    """Configure built-in GGUF model provider."""
    from openlaoke.core.local_model_manager import LocalModelManager

    console.print("[bold]Local GGUF Models[/bold]")
    console.print("[dim]Models downloaded from ModelScope[/dim]\n")

    manager = LocalModelManager()
    models = manager.list_models()
    custom_models = [m for m in models if m.model_id.startswith("custom:")]

    if not custom_models:
        console.print("[yellow]No local models downloaded.[/yellow]")
        console.print("[dim]Download one first: openlaoke model search <query>[/dim]")
        console.print("[dim]Then run: openlaoke model download <model_id>[/dim]\n")
        return config

    table = Table(show_header=True, box=None)
    table.add_column("Option", style="cyan")
    table.add_column("Model", style="bold")
    table.add_column("Size", style="dim")
    table.add_column("Status", style="green")

    idx = 1
    all_models = []
    for model in custom_models:
        status = (
            "[green]✓ downloaded[/green]" if model.downloaded else "[yellow]not downloaded[/yellow]"
        )
        table.add_row(
            f"  [{idx}]",
            f"{model.name}\n[dim]{model.description}[/dim]",
            f"{model.size_mb:.0f} MB",
            status,
        )
        all_models.append(model)
        idx += 1

    console.print(table)
    console.print()

    choice = Prompt.ask(
        "Select model to use",
        choices=[str(i) for i in range(1, len(all_models) + 1)],
        default="1",
    )

    selected_model = all_models[int(choice) - 1]

    if not selected_model.downloaded:
        if selected_model.model_id.startswith("custom:"):
            console.print(
                f"\n[yellow]Custom model '{selected_model.name}' file not found.[/yellow]"
            )
            console.print("[yellow]Redownload with: openlaoke model download[/yellow]")
            return config
        console.print(f"\n[yellow]Model '{selected_model.name}' not downloaded.[/yellow]")
        download = Confirm.ask(
            f"Download now? ({selected_model.size_mb} MB)",
            default=True,
        )

        if download:
            import asyncio

            async def do_download():
                def progress(pct, downloaded, total):
                    bars = int(pct / 5)
                    bar_str = "█" * bars + "░" * (20 - bars)
                    console.print(
                        f"\r  Downloading: [{bar_str}] {pct:.0f}% ({downloaded / 1024 / 1024:.1f} MB)",
                        end="",
                    )

                return await manager.download_model(selected_model.model_id, progress)

            try:
                asyncio.run(do_download())
                console.print("\n[green]✓ Download complete![/green]")
                selected_model.downloaded = True
            except Exception as e:
                console.print(f"\n[red]✗ Download failed: {e}[/red]")
                console.print(
                    "[yellow]You can download later with: openlaoke model download[/yellow]"
                )
                return config
        else:
            console.print("[yellow]Skipping download. You can download later.[/yellow]")
            return config

    provider.default_model = selected_model.model_id
    provider.enabled = True
    config.providers["local_builtin"] = provider

    console.print(f"\n[green]✓ Configured built-in model: {selected_model.name}[/green]")
    return config


def show_current_config(config: AppConfig) -> None:
    """Display current configuration."""
    console.print("\n[bold]Current Configuration[/bold]\n")

    # Providers table
    table = Table(title="Providers")
    table.add_column("Provider", style="cyan")
    table.add_column("Model", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("Active", style="magenta")

    for name, provider in config.providers.providers.items():
        status = _get_provider_status(provider)
        active = "✓" if name == config.providers.active_provider else ""
        model = provider.default_model
        table.add_row(name, model, status, active)

    console.print(table)

    # Proxy info
    console.print(f"\n[bold]Proxy:[/bold] {_get_proxy_display(config)}")
    console.print()


def quick_setup(provider: str, api_key: str, model: str = "") -> AppConfig:
    """Quick setup for a single provider (non-interactive)."""
    config = AppConfig()

    if provider in config.providers.providers:
        config.providers.providers[provider].api_key = api_key
        if model:
            config.providers.providers[provider].default_model = model
        config.providers.active_provider = provider
        config.first_run = False

    return config


def get_proxy_url(config: AppConfig) -> str | None:
    """Get the effective proxy URL from config."""
    if config.proxy_mode == "none":
        return None
    elif config.proxy_mode == "system":
        proxy = os.environ.get("HTTP_PROXY") or os.environ.get("HTTPS_PROXY") or None
        return proxy if proxy and proxy != "" else None
    elif config.proxy_mode == "custom":
        return config.proxy_url if config.proxy_url else None
    return None
