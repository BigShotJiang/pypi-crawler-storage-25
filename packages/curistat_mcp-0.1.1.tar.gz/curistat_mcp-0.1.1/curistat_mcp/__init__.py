"""Curistat Trading Analytics -- MCP Server."""
