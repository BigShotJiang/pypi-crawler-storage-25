"""Curistat Trading Analytics -- MCP Server.

Exposes Curistat Developer API endpoints as MCP tools for Claude Desktop,
CrewAI, LangChain, and any MCP-compatible agent framework.

The server is a thin client of our REST API: all auth, rate limiting, and
scope enforcement still applies.  No new attack surface on the backend.

Usage (stdio for Claude Desktop):
    python -m curistat_mcp

Environment variables:
    CURISTAT_API_KEY  -- Bearer token (required)
    CURISTAT_API_URL  -- Base URL (default: https://api.curistat.com)
"""

from __future__ import annotations

import os

import httpx
from mcp.server.fastmcp import FastMCP

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

mcp = FastMCP(
    "Curistat Trading Analytics",
    instructions=(
        "Curistat provides futures-specific volatility intelligence for "
        "ES, NQ, MES, MNQ, SPX, SPY, and QQQ.  Use these tools to get "
        "daily forecasts, regime readings, rare signals, directional bias, "
        "economic calendar, and historical analogs."
    ),
)

API_BASE = os.getenv("CURISTAT_API_URL", "https://api.curistat.com")
API_KEY = os.getenv("CURISTAT_API_KEY", "")

VALID_PRODUCTS = ["ES", "NQ", "MES", "MNQ", "SPX", "SPY", "QQQ"]


# ---------------------------------------------------------------------------
# Internal helper
# ---------------------------------------------------------------------------

async def _call_api(path: str, params: dict | None = None) -> dict:
    """Call Curistat Developer API and return parsed JSON."""
    if not API_KEY:
        return {"error": "CURISTAT_API_KEY environment variable is not set."}
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"{API_BASE}/developer/v1{path}",
            params=params or {},
            headers={"Authorization": f"Bearer {API_KEY}"},
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()


# ===================================================================
# Bundle 1 -- Core Intelligence (scope: core:read)
# ===================================================================

@mcp.tool()
async def get_forecast_today(product: str = "ES") -> dict:
    """Get today's volatility forecast with a 1-10 rating and expected move ranges.

    Products: ES, NQ, MES, MNQ, SPX, SPY, QQQ.
    Returns rating, expected high/low, regime context, and key events.
    """
    return await _call_api("/forecast/today", {"product": product.upper()})


@mcp.tool()
async def get_forecast_week(product: str = "ES", date: str | None = None) -> dict:
    """Get 5-day forward volatility forecast.

    Products: ES, NQ, MES, MNQ, SPX, SPY, QQQ.
    Optional date parameter (YYYY-MM-DD) to anchor the forecast.
    """
    params = {"product": product.upper()}
    if date:
        params["date"] = date
    return await _call_api("/forecast/week", params)


@mcp.tool()
async def get_signals(product: str = "ES", target_date: str | None = None) -> dict:
    """Scan all 24 rare volatility signals for a given product and date.

    Products: ES, NQ, MES, MNQ, SPX, SPY, QQQ.
    These are statistically rare conditions (VIX extremes, term structure
    inversions, volatility compression, etc.) that precede outsized moves.
    """
    params = {"product": product.upper()}
    if target_date:
        params["target_date"] = target_date
    return await _call_api("/signals", params)


@mcp.tool()
async def get_direction(product: str = "ES", date: str | None = None) -> dict:
    """Get directional bias from a 17-component signal aggregate.

    Products: ES, NQ, MES, MNQ, SPX, SPY, QQQ.
    Combines breadth, momentum, positioning, and structural signals
    into a single directional view.
    """
    params = {"product": product.upper()}
    if date:
        params["date"] = date
    return await _call_api("/direction", params)


@mcp.tool()
async def get_session_plan(product: str = "ES", date: str | None = None) -> dict:
    """Get a full session planner with pattern-driven trade setups for today.

    Products: ES, NQ, MES, MNQ, SPX, SPY, QQQ.
    Returns key levels, expected behavior windows, and actionable setups
    based on the day's volatility forecast and regime.
    """
    params = {"product": product.upper()}
    if date:
        params["date"] = date
    return await _call_api("/session-plan", params)


# ===================================================================
# Bundle 2 -- Regime & Indices (scope: regime:read)
# ===================================================================

@mcp.tool()
async def get_regime() -> dict:
    """Get the CRC (Curistat Regime Composite) reading, a 0-100 score
    across 5 bands that fuses HMM, VPIN, BOCD, Hurst exponent, and
    Sample Entropy into a single regime indicator."""
    return await _call_api("/regime")


@mcp.tool()
async def get_pulse(product: str = "ES", date: str | None = None) -> dict:
    """Get a market conditions snapshot for a product.

    Products: ES, NQ, MES, MNQ, SPX, SPY, QQQ.
    Quick overview of current vol, regime, and key metrics.
    """
    params = {"product": product.upper()}
    if date:
        params["date"] = date
    return await _call_api("/pulse", params)


# ===================================================================
# Bundle 3 -- Research & Analytics (scope: research:read)
# ===================================================================

@mcp.tool()
async def get_calendar(days: int = 7) -> dict:
    """Get the economic calendar for the next N days (1-30).

    Returns upcoming events with historical volatility impact estimates
    so agents can anticipate high-impact sessions.
    """
    return await _call_api("/calendar", {"days": days})


@mcp.tool()
async def get_event_impact(event: str, product: str = "ES") -> dict:
    """Analyze historical volatility impact of a specific economic event.

    event: Event name (e.g. CPI, FOMC, NFP, PPI, Retail Sales).
    Products: ES, NQ, MES, MNQ, SPX, SPY, QQQ.
    Returns pre/post event vol stats across multiple historical occurrences.
    """
    return await _call_api("/event-impact", {"event": event, "product": product.upper()})


@mcp.tool()
async def get_similar_days(product: str = "ES", limit: int = 20) -> dict:
    """Find historical days with conditions similar to today.

    Products: ES, NQ, MES, MNQ, SPX, SPY, QQQ.
    Uses feature-vector similarity to find analog days, then shows
    what happened next -- useful for probabilistic scenario planning.
    """
    return await _call_api("/similar-days", {"product": product.upper(), "limit": limit})


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run()
