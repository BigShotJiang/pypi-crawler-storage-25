"""Allow running as: python -m curistat_mcp"""
from .curistat_mcp import mcp

mcp.run()
