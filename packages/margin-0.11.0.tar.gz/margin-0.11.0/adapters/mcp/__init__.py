"""
margin MCP adapter \u2014 an stdio Model Context Protocol server that exposes
margin's typed self-awareness primitives to any MCP-capable client (Claude
Desktop, Claude Code, Cursor, Cline, Windsurf, \u2026).

Shape: stdio server, in-process state during a session, JSON snapshot between
calls so state survives restarts.  The filesystem is the runtime \u2014 inspect with
``cat $MARGIN_MCP_STATE``.

Tools exposed to the model:

    margin_observe(values={...})   record an agent step \u2192 expression + guidance
    margin_reset()                  start a fresh session

Resources the model can read between turns:

    margin://state                  current Expression + FlowResult as JSON
    margin://issues                 current IssueBuffer.diagnose() output

Install the optional MCP dependency and run the server:

    pip install margin[mcp]
    python -m adapters.mcp

Claude Desktop / Claude Code config:

    {
      "mcpServers": {
        "margin": {
          "command": "python",
          "args": ["-m", "adapters.mcp"],
          "env": {"MARGIN_MCP_STATE": "/path/to/margin-state.json"}
        }
      }
    }

The ``mcp`` Python SDK is imported lazily \u2014 if it's not installed, a clear
ImportError fires when you try to start the server, not when you
``import margin``.
"""

from .state import state_path, load_session, save_session, reset_state

__all__ = ["state_path", "load_session", "save_session", "reset_state", "main"]


def main() -> None:
    """Stdio MCP server entrypoint.  Equivalent to ``python -m adapters.mcp``."""
    from .server import main as _main
    _main()
