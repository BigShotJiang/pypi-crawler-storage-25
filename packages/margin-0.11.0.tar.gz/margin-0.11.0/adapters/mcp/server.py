"""
Stdio MCP server exposing margin's self-awareness primitives.

Tools:
    margin_observe(values)   record one agent step; returns expression + guidance
    margin_reset()            delete the snapshot, start fresh

Resources:
    margin://state            current Expression + FlowResult as JSON
    margin://issues           current IssueBuffer.diagnose() as JSON

Design notes
------------

* State is loaded once at server start, held in-memory for the session, and
  snapshotted to disk after every mutation.  That keeps single-session calls
  cheap while surviving restarts.
* The ``mcp`` SDK is imported at function-call time so ``import adapters.mcp``
  without the extra installed doesn't explode.
"""
from __future__ import annotations

import json
from typing import Any

from .state import load_session, save_session, reset_state


_STATE_URI = "margin://state"
_ISSUES_URI = "margin://issues"


def _require_mcp():
    try:
        from mcp.server import Server  # noqa: F401
        from mcp.server.stdio import stdio_server  # noqa: F401
        from mcp import types  # noqa: F401
    except ImportError as e:
        raise ImportError(
            "The margin MCP adapter requires the 'mcp' package.\n"
            "Install it with:  pip install margin[mcp]"
        ) from e


def _expression_doc(monitor, flow) -> dict:
    expr = monitor.expression
    doc: dict[str, Any] = {
        "expression": expr.to_dict() if expr is not None else None,
        "flow": {
            "label":       flow.label,
            "stage":       flow.current.name if flow.current else None,
            "stage_index": flow.stage_index,
            "n_stages":    len(flow.stages),
            "complete":    flow.is_complete,
        },
    }
    return doc


def _issues_doc(monitor, flow) -> dict:
    return {
        "monitor": monitor.issues.diagnose() if hasattr(monitor, "issues") else {},
        "flow":    flow.issues.diagnose() if hasattr(flow, "issues") else {},
    }


def build_server():
    """Build the MCP Server with tool + resource handlers wired up."""
    _require_mcp()
    from mcp.server import Server
    from mcp import types

    server = Server("margin")
    monitor, flow = load_session()

    @server.list_tools()
    async def _list_tools():
        return [
            types.Tool(
                name="margin_observe",
                description=(
                    "Record one agent step and return its typed health + flow "
                    "guidance. 'values' is a dict of agent metrics (e.g. "
                    "{'latency_ms': 2400, 'tokens_used': 1800, "
                    "'tool_success_rate': 0.9, 'retry_count': 1, "
                    "'confidence': 0.72})."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "values": {
                            "type": "object",
                            "additionalProperties": {"type": "number"},
                            "description": "Agent metric dict.",
                        },
                    },
                    "required": ["values"],
                },
            ),
            types.Tool(
                name="margin_reset",
                description="Reset the session \u2014 delete the snapshot, start fresh.",
                inputSchema={"type": "object", "properties": {}},
            ),
        ]

    @server.call_tool()
    async def _call_tool(name: str, arguments: dict):
        nonlocal monitor, flow

        if name == "margin_observe":
            values = dict(arguments.get("values", {}))
            monitor.update(values)
            flow_result = flow.observe(values)
            save_session(monitor, flow)
            payload = {
                "expression": monitor.expression.to_string() if monitor.expression else None,
                "flow":       flow_result.to_atom(),
                "guidance":   flow_result.guidance.value,
            }
            return [types.TextContent(type="text", text=json.dumps(payload, indent=2))]

        if name == "margin_reset":
            reset_state()
            monitor, flow = load_session()
            return [types.TextContent(type="text", text='{"reset": true}')]

        raise ValueError(f"unknown tool: {name!r}")

    @server.list_resources()
    async def _list_resources():
        return [
            types.Resource(
                uri=_STATE_URI,
                name="margin state",
                description="Current Expression + FlowResult as JSON.",
                mimeType="application/json",
            ),
            types.Resource(
                uri=_ISSUES_URI,
                name="margin issues",
                description="IssueBuffer.diagnose() \u2014 library-noticed events.",
                mimeType="application/json",
            ),
        ]

    # The SDK expects ``Iterable[ReadResourceContents]`` back from a resource
    # handler; a bare string triggers a DeprecationWarning on newer mcp versions.
    from mcp.server.lowlevel.helper_types import ReadResourceContents

    @server.read_resource()
    async def _read_resource(uri):
        # ``uri`` can arrive as an AnyUrl or a string depending on SDK version.
        key = str(uri)
        if key == _STATE_URI:
            text = json.dumps(_expression_doc(monitor, flow), indent=2)
        elif key == _ISSUES_URI:
            text = json.dumps(_issues_doc(monitor, flow), indent=2)
        else:
            raise ValueError(f"unknown resource: {key!r}")
        return [ReadResourceContents(content=text, mime_type="application/json")]

    return server


def main() -> None:
    """Run the stdio MCP server.  Blocks until the client disconnects."""
    import anyio
    from mcp.server.stdio import stdio_server

    server = build_server()

    async def _run():
        async with stdio_server() as (read, write):
            await server.run(read, write, server.create_initialization_options())

    anyio.run(_run)
