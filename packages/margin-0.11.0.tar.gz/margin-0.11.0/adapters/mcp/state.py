"""
Session state persistence for the margin MCP server.

State = (Monitor, Flow).  Monitor is persisted via ``save_monitor`` / ``load_monitor``
(margin already ships those).  Flow contains predicate lambdas that aren't
JSON-serializable, so we store only the stage index as a sidecar and rebuild
the Flow via ``agent_flow()`` on load, fast-forwarding to the stored stage.

The state file is a JSON document with two top-level keys::

    {"monitor": {...Monitor.to_dict()...}, "flow_stage": 2}

Default path: ``$MARGIN_MCP_STATE`` or ``~/.margin/mcp-state.json``.  Missing
file means start fresh.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional


DEFAULT_STATE_PATH = Path.home() / ".margin" / "mcp-state.json"


def state_path() -> Path:
    p = os.environ.get("MARGIN_MCP_STATE")
    return Path(p).expanduser() if p else DEFAULT_STATE_PATH


def load_session():
    """
    Return ``(monitor, flow)`` for the current session.

    If a snapshot exists at ``state_path()``, restore both.  Otherwise start
    fresh with the agent-adapter defaults.
    """
    from adapters.agent import agent_parser, agent_flow
    from margin import Monitor
    from margin.persist import load_monitor

    path = state_path()
    flow = agent_flow()
    parser = agent_parser()
    if not path.exists():
        return Monitor(parser=parser), flow

    try:
        doc = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return Monitor(parser=parser), flow

    # Monitor restore.
    monitor = Monitor(parser=parser)
    if "monitor" in doc:
        mpath = path.parent / f".{path.name}.monitor"
        try:
            mpath.write_text(json.dumps(doc["monitor"]))
            monitor = load_monitor(str(mpath), parser=parser)
        finally:
            mpath.unlink(missing_ok=True)

    # Flow fast-forward.
    flow_stage = int(doc.get("flow_stage", 0) or 0)
    for _ in range(min(flow_stage, len(flow.stages) - 1)):
        flow.advance()

    return monitor, flow


def save_session(monitor, flow) -> None:
    """Snapshot ``(monitor, flow)`` to ``state_path()`` atomically."""
    from margin.persist import save_monitor

    path = state_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    # Serialize Monitor to a sidecar, then splice into the session doc.
    side = path.parent / f".{path.name}.monitor"
    try:
        save_monitor(monitor, str(side))
        monitor_doc = json.loads(side.read_text())
    finally:
        side.unlink(missing_ok=True)

    doc = {"monitor": monitor_doc, "flow_stage": getattr(flow, "stage_index", 0)}
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(doc))
    tmp.replace(path)


def reset_state() -> None:
    """Delete the snapshot file if present.  Next ``load_session`` starts fresh."""
    p = state_path()
    p.unlink(missing_ok=True)
