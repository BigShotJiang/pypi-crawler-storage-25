"""``python -m adapters.mcp`` \u2014 start the stdio MCP server."""
from .server import main

if __name__ == "__main__":
    main()
