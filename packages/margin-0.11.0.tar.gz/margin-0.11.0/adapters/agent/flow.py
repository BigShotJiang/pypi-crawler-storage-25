"""
A Flow template for a typical three-stage agent loop:

    PLAN  \u2192  ACT  \u2192  REFLECT  \u2192  (COMPLETE)

Each stage uses the same agent_parser, but advances on different predicates:

    PLAN    \u2192  a concrete plan is produced (confidence above threshold)
    ACT     \u2192  tool calls are succeeding (tool_success_rate holds)
    REFLECT \u2192  the run is converging (retries haven't exploded)

Flow.observe() returns typed live guidance (ADVANCE / HOLD / RETRY / ROLLBACK /
ESCALATE) at every step, and emits typed Issues for predicate failures and
degraded stage entries.  This means your agent gets a typed answer to
"continue, retry, or escalate?" after every observation \u2014 not a string you have
to parse.
"""
from __future__ import annotations

from margin import Flow, Stage, Expression

from .metrics import agent_parser


def _has_plan(expr: Expression) -> bool:
    """PLAN advances once the model's stated confidence crosses intact."""
    conf = next((o for o in expr.observations if o.name == "confidence"), None)
    return conf is not None and conf.health.value == "INTACT"


def _tools_holding(expr: Expression) -> bool:
    """ACT advances once tool success rate is intact and retries aren't ablated."""
    success = next((o for o in expr.observations if o.name == "tool_success_rate"), None)
    retries = next((o for o in expr.observations if o.name == "retry_count"), None)
    if success is None or success.health.value != "INTACT":
        return False
    if retries is not None and retries.health.value == "ABLATED":
        return False
    return True


def _converging(expr: Expression) -> bool:
    """REFLECT advances once retry_count is intact and confidence is intact."""
    retries = next((o for o in expr.observations if o.name == "retry_count"), None)
    conf    = next((o for o in expr.observations if o.name == "confidence"), None)
    return (
        retries is not None and retries.health.value == "INTACT"
        and conf is not None and conf.health.value == "INTACT"
    )


AGENT_STAGES = ("plan", "act", "reflect")


def agent_flow(label: str = "agent") -> Flow:
    """
    Build a typical three-stage agent Flow with shared thresholds.

    Each Flow.observe() call returns a FlowResult whose ``guidance`` is one of
    ADVANCE / HOLD / RETRY / ROLLBACK / ESCALATE / COMPLETE.  Use
    ``result.to_atom()`` to get a single-line summary suitable for logging,
    e.g. ``flow:agent:act[2/3] \u2192 ADVANCE``.
    """
    parser = agent_parser()
    return Flow(
        stages=[
            Stage(name="plan",    parser=parser, advance_when=_has_plan),
            Stage(name="act",     parser=parser, advance_when=_tools_holding),
            Stage(name="reflect", parser=parser, advance_when=_converging),
        ],
        label=label,
    )
