"""
Default baselines and thresholds for common agent / LLM-pipeline metrics.

Polarity is the critical part: for cost-like metrics (latency, tokens, retries)
more is worse, so ``higher_is_better=False``.  For quality metrics (confidence,
tool success rate) more is better.  Margin's sigma normalisation threads that
polarity correctly through every comparison downstream.

The baselines below are deliberately conservative defaults for a mid-size
Claude / GPT call with occasional tool use.  Override per-component for your
specific agent.
"""
from __future__ import annotations

from typing import Optional

from margin import Parser, Thresholds


AGENT_BASELINES: dict[str, float] = {
    "latency_ms":        1500.0,   # typical end-to-end call
    "tokens_used":        800.0,   # input + output
    "tool_success_rate":   0.95,   # fraction of tool calls that succeeded
    "retry_count":         0.0,    # zero retries is the happy path
    "confidence":          0.80,   # model-stated or rubric-derived
}


AGENT_THRESHOLDS: dict[str, Thresholds] = {
    "latency_ms": Thresholds(
        intact=3000.0, ablated=10000.0, higher_is_better=False,
    ),
    "tokens_used": Thresholds(
        intact=3000.0, ablated=10000.0, higher_is_better=False,
    ),
    "tool_success_rate": Thresholds(
        intact=0.80, ablated=0.50, higher_is_better=True,
    ),
    "retry_count": Thresholds(
        intact=1.0, ablated=3.0, higher_is_better=False,
    ),
    "confidence": Thresholds(
        intact=0.60, ablated=0.30, higher_is_better=True,
    ),
}


def agent_parser(
    baselines: Optional[dict[str, float]] = None,
    thresholds: Optional[dict[str, Thresholds]] = None,
) -> Parser:
    """
    Build a Parser with sensible agent-metric defaults.

    ``baselines`` and ``thresholds`` merge over the defaults, so you can pass
    just the overrides you care about::

        parser = agent_parser(
            baselines={"latency_ms": 5000.0},           # slower model
            thresholds={"confidence": Thresholds(
                intact=0.75, ablated=0.50, higher_is_better=True,
            )},
        )
    """
    merged_baselines = dict(AGENT_BASELINES)
    if baselines:
        merged_baselines.update(baselines)
    merged_thresholds = dict(AGENT_THRESHOLDS)
    if thresholds:
        merged_thresholds.update(thresholds)
    # Default per-component thresholds cover every baseline, so the Parser-level
    # fallback is only hit if the caller adds an unrelated component.
    fallback = Thresholds(intact=0.0, ablated=0.0)
    return Parser(
        baselines=merged_baselines,
        thresholds=fallback,
        component_thresholds=merged_thresholds,
    )
