"""
Lightweight helpers for recording an agent step and deriving a feasibility
Intent from it.

The ``AgentStep`` dataclass carries the five canonical agent metrics so you can
collect them once at the call site and feed them to margin in typed form.
There is no hard dependency on any LLM SDK \u2014 wire your own adapter in a couple
of lines, e.g. for Anthropic::

    import time, anthropic
    from adapters.agent import AgentStep, agent_parser

    client = anthropic.Anthropic()
    parser = agent_parser()

    def call(messages, tools=None):
        t0 = time.perf_counter()
        resp = client.messages.create(
            model="claude-opus-4-7",
            max_tokens=1024,
            messages=messages,
            tools=tools or [],
        )
        step = AgentStep(
            latency_ms=(time.perf_counter() - t0) * 1000,
            tokens_used=resp.usage.input_tokens + resp.usage.output_tokens,
            tool_success_rate=1.0,   # fill in from your tool-runner's accounting
            retry_count=0,
            confidence=0.8,          # rubric-derived or model-stated
        )
        expr = parser.parse(step.to_values())
        return resp, expr
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from margin import (
    Expression, Intent, Requirement, Health, Ledger, Record, Op,
)


@dataclass
class AgentStep:
    """
    One agent step's observable metrics.

    latency_ms:        end-to-end wall time for the call in milliseconds
    tokens_used:       input + output tokens
    tool_success_rate: fraction of tool calls that succeeded (0.0\u20131.0)
    retry_count:       how many retries this step consumed
    confidence:        model-stated or rubric-derived confidence (0.0\u20131.0)
    """
    latency_ms: float
    tokens_used: float
    tool_success_rate: float
    retry_count: float
    confidence: float

    def to_values(self) -> dict[str, float]:
        """Dict shape expected by ``agent_parser().parse(...)``."""
        return {
            "latency_ms":        self.latency_ms,
            "tokens_used":       self.tokens_used,
            "tool_success_rate": self.tool_success_rate,
            "retry_count":       self.retry_count,
            "confidence":        self.confidence,
        }


def record_step(
    ledger: Ledger,
    step_index: int,
    expression: Expression,
    tag: str = "",
) -> Record:
    """
    Append one agent step's first observation to the ledger so margin's
    drift/forecast/contract layers can reason about trajectory across steps.
    """
    obs = expression.observations[0] if expression.observations else None
    if obs is None:
        return None
    record = Record(
        step=step_index,
        tag=tag or f"step-{step_index}",
        before=obs,
        fired=False,
        op=Op.NOOP,
        alpha=0.0,
        magnitude=0.0,
    )
    ledger.append(record)
    return record


def agent_intent(deadline_seconds: Optional[float] = None) -> Intent:
    """
    Build a default Intent covering 'the agent run is still feasible' \u2014 a
    compact goal-feasibility check you can drop into ``full_step(... intent=...)``.

    Requirements say latency must stay at DEGRADED-or-better and confidence must
    stay at DEGRADED-or-better.  ``deadline_seconds`` sets an ETA-to-violation
    window from the moment ``Intent.evaluate()`` is called.
    """
    return Intent(
        goal="agent run is still feasible",
        requirements=[
            Requirement(component="latency_ms", min_health=Health.DEGRADED),
            Requirement(component="confidence", min_health=Health.DEGRADED),
        ],
        deadline_seconds=deadline_seconds,
    )
