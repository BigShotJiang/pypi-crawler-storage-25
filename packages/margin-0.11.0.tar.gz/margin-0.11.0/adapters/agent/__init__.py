"""
margin adapter for agent / LLM-pipeline self-awareness.

The primitives (Confidence, Absence, Issue, Flow, Intent, Contract) that margin
exposes are *exactly* the vocabulary an LLM agent needs when it has to answer
"how am I doing, and should I continue?" at each step of its run.

This adapter packages sensible defaults so you can go from zero to a typed
health read-out of an agent step in three lines:

    from adapters.agent import agent_parser, AgentStep

    parser = agent_parser()
    step   = AgentStep(latency_ms=2400, tokens_used=1800,
                       tool_success_rate=0.9, retry_count=1, confidence=0.72)
    print(parser.parse(step.to_values()).to_string())
    # [latency_ms:INTACT(+0.40\u03c3)] [tokens_used:INTACT(+0.75\u03c3)]
    # [tool_success_rate:INTACT(-0.05\u03c3)] [retry_count:DEGRADED(...)]
    # [confidence:INTACT(-0.10\u03c3)]

Use :func:`agent_flow` when your agent runs in stages (plan \u2192 act \u2192 reflect) and
you want typed live guidance (ADVANCE/HOLD/RETRY/ROLLBACK) between them.

Zero SDK dependencies.  See module docstrings for wiring to Anthropic / OpenAI.
"""
from .metrics import AGENT_BASELINES, AGENT_THRESHOLDS, agent_parser
from .flow import AGENT_STAGES, agent_flow
from .wrap import AgentStep, record_step, agent_intent

__all__ = [
    "AGENT_BASELINES", "AGENT_THRESHOLDS", "agent_parser",
    "AGENT_STAGES", "agent_flow",
    "AgentStep", "record_step", "agent_intent",
]
