"""
Flow: ordered sequence of stages with typed guidance.

A Flow is an ordered list of Stage objects, each with its own Parser and
per-stage Monitor.  Observations are routed to the current stage; the Flow
emits typed Guidance (ADVANCE / HOLD / RETRY / ROLLBACK / ESCALATE /
COMPLETE) based on stage health and user-supplied advance/retry/escalate
predicates.

Minimal use::

    from margin import Flow, Stage, Parser, Thresholds, Guidance

    ferment = Flow(stages=[
        Stage(
            name="inoculation",
            parser=Parser(baselines={"pH": 6.5, "DO": 90}, thresholds=Thresholds(...)),
            advance_when=lambda expr: expr.health_of("DO") == Health.INTACT,
        ),
        Stage(
            name="lag_phase",
            parser=Parser(baselines={"pH": 6.3, "biomass": 0.1}, thresholds=Thresholds(...)),
            advance_when=lambda expr: (expr.health_of("biomass") == Health.INTACT
                                       and expr.observations[0].sigma > 0.5),
        ),
        # ...
    ], label="fermentation")

    result = ferment.observe({"pH": 6.5, "DO": 88})
    # → FlowResult(stage="inoculation", guidance=HOLD, reason=...)

    # When ready:
    result = ferment.observe({"pH": 6.4, "DO": 92})
    # → FlowResult(stage="inoculation", guidance=ADVANCE, ...)
    ferment.advance()

    # Compact rendering:
    result.to_atom()
    # → "flow:fermentation:inoculation[1/5] → ADVANCE"

Contracts can be used in predicates::

    from margin import Contract, HealthTarget, Health, Ledger
    contract = Contract(terms=[HealthTarget(component="biomass", target=Health.INTACT)])
    ledger = Ledger()
    stage = Stage(
        name="stationary",
        parser=parser,
        advance_when=lambda expr: contract.evaluate(ledger, expr).passed,
    )

This keeps Flow lightweight (no mandatory Ledger) while letting advanced
users plug in the full Contract machinery when they need it.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Callable, Dict, List, Optional

from .health import Health
from .issue import Issue, IssueBuffer, IssueCode, IssueLevel
from .observation import Expression, Parser
from .streaming import Monitor


# -----------------------------------------------------------------------
# Guidance
# -----------------------------------------------------------------------

class Guidance(Enum):
    """
    Recommendation for the current flow state.

    ADVANCE:  exit criteria satisfied — ready to move to the next stage
    HOLD:     stage running healthy, exit criteria not yet met
    RETRY:    stage degraded but recoverable; continue observing
    ROLLBACK: this stage cannot proceed; return to previous stage
    ESCALATE: cannot proceed automatically — needs human intervention
    COMPLETE: all stages are done
    """
    ADVANCE = "ADVANCE"
    HOLD = "HOLD"
    RETRY = "RETRY"
    ROLLBACK = "ROLLBACK"
    ESCALATE = "ESCALATE"
    COMPLETE = "COMPLETE"


GUIDANCE_SEVERITY: Dict[Guidance, int] = {
    Guidance.COMPLETE: 0,
    Guidance.ADVANCE: 0,
    Guidance.HOLD: 1,
    Guidance.RETRY: 2,
    Guidance.ROLLBACK: 3,
    Guidance.ESCALATE: 4,
}


# -----------------------------------------------------------------------
# Stage
# -----------------------------------------------------------------------

StagePredicate = Callable[[Expression], bool]


@dataclass
class Stage:
    """
    One stage in a process flow.

    name:           human-readable stage identifier
    parser:         Parser for measurements observed during this stage
    advance_when:   predicate(expr) → True means exit criteria met
    retry_when:     predicate(expr) → True means stage is degraded-but-recoverable
    escalate_when:  predicate(expr) → True means stage cannot proceed
    rollback_when:  predicate(expr) → True means return to the previous stage
    window:         observation window size for the stage's Monitor (default 20)

    All predicates are optional.  When none fire, Guidance defaults to HOLD.
    If no explicit predicates are given, the default classifier uses
    observation health (any ABLATED → ESCALATE, any DEGRADED → RETRY, else HOLD).
    """

    name: str
    parser: Parser
    advance_when: Optional[StagePredicate] = None
    retry_when: Optional[StagePredicate] = None
    escalate_when: Optional[StagePredicate] = None
    rollback_when: Optional[StagePredicate] = None
    window: int = 20

    def create_monitor(self) -> Monitor:
        """Fresh Monitor bound to this stage's parser and window."""
        return Monitor(self.parser, window=self.window)


# -----------------------------------------------------------------------
# FlowResult
# -----------------------------------------------------------------------

@dataclass
class FlowResult:
    """Returned from Flow.observe() and flow advancement helpers."""
    flow_label: str
    stage: str
    stage_index: int
    total_stages: int
    expression: Optional[Expression]
    guidance: Guidance
    reason: str
    issues: List[Issue] = None  # type: ignore[assignment]

    def __post_init__(self):
        if self.issues is None:
            self.issues = []

    def to_atom(self) -> str:
        """
        Compact flow notation — consistent format across running and complete states.

        With a flow label::

            "flow:fermentation:lag_phase[2/5] → ADVANCE"
            "flow:fermentation[5/5]"                      # complete

        Without a flow label (empty)::

            "flow:lag_phase[2/5] → ADVANCE"
            "flow[5/5]"                                    # complete
        """
        prefix = f"flow:{self.flow_label}" if self.flow_label else "flow"
        suffix = ""
        if self.issues:
            # Annotate with issue counts by level, in severity order.
            marks = []
            from .issue import IssueLevel as _IL
            counts = {l: 0 for l in _IL}
            for iss in self.issues:
                counts[iss.level] += 1
            level_marks = [
                (_IL.FATAL, "‼"),
                (_IL.ERROR, "!"),
                (_IL.WARNING, "⚠"),
                (_IL.INFO, "·"),
            ]
            for lvl, m in level_marks:
                if counts[lvl] > 0:
                    marks.append(f"{m}{counts[lvl]}")
            if marks:
                suffix = " (" + " ".join(marks) + ")"
        if self.guidance == Guidance.COMPLETE:
            return f"{prefix}[{self.total_stages}/{self.total_stages}]{suffix}"
        return (
            f"{prefix}:{self.stage}[{self.stage_index + 1}/{self.total_stages}]"
            f" → {self.guidance.value}{suffix}"
        )

    def to_dict(self) -> dict:
        d = {
            "flow_label": self.flow_label,
            "stage": self.stage,
            "stage_index": self.stage_index,
            "total_stages": self.total_stages,
            "guidance": self.guidance.value,
            "reason": self.reason,
            "expression": self.expression.to_dict() if self.expression else None,
        }
        if self.issues:
            d["issues"] = [i.to_dict() for i in self.issues]
        return d

    def __repr__(self) -> str:
        return f"FlowResult({self.to_atom()} — {self.reason})"


# -----------------------------------------------------------------------
# Flow
# -----------------------------------------------------------------------

class Flow:
    """
    An ordered sequence of stages with typed per-step guidance.

    Each stage has its own Monitor, created fresh when the flow enters the
    stage.  Observations are routed to the current stage only; earlier-stage
    state is preserved in the transition log.

    Flow does not auto-advance.  ``observe()`` returns guidance; the caller
    (or a policy layer above) decides whether to call ``advance()``.  This
    keeps the flow deterministic and side-effect free, which matters for
    replay, backtesting, and safety-critical use cases.

    Thread safety
    -------------
    Flow is **not thread-safe**.  ``observe()`` mutates the current stage's
    Monitor window; ``advance()`` and ``rollback()`` mutate the stage index.
    If you need to observe a flow from multiple threads, wrap it in a lock
    at the call site.  Per-entity flows in a request/response context (one
    Flow instance per tracked entity) are the intended pattern.

    Predicate ordering
    ------------------
    ``_classify`` evaluates predicates in strict severity order:

        1. ``escalate_when`` (highest — safety gate)
        2. ``rollback_when``
        3. ``advance_when``
        4. ``retry_when``

    A true ``escalate_when`` dominates a true ``advance_when`` — this is
    intentional.  When a stage is in an escalation condition, we do not
    advance even if exit criteria are also met.  Safety-first semantics.

    Memory note
    -----------
    Each ``advance()`` creates a fresh Monitor for the new stage without
    pruning the prior stage's Monitor.  For a 50-stage pipeline, 50 Monitor
    instances accumulate in ``self._monitors``.  This is intentional for
    debuggability but may matter for very long flows.  A pruning option
    may be added in a future release; for now, construct a new Flow if
    memory footprint matters.
    """

    def __init__(
        self,
        stages: List[Stage],
        label: str = "",
    ):
        if not stages:
            raise ValueError("Flow requires at least one stage")
        names = [s.name for s in stages]
        if len(set(names)) != len(names):
            raise ValueError(f"Flow stages must have unique names, got {names}")
        self.stages: List[Stage] = list(stages)
        self.label = label
        self._index = 0
        self._monitors: Dict[str, Monitor] = {
            stages[0].name: stages[0].create_monitor()
        }
        self._transitions: List[dict] = []
        self._entered_at: datetime = datetime.now()
        self._issues: IssueBuffer = IssueBuffer()

        # Emit INFO if a stage has no predicates at all (will HOLD forever)
        for s in self.stages:
            if (s.advance_when is None and s.retry_when is None
                    and s.escalate_when is None and s.rollback_when is None):
                self._issues.emit(
                    IssueLevel.INFO,
                    IssueCode.NO_PREDICATES,
                    detail=(
                        f"stage {s.name!r} has no predicates; will only leave "
                        "via explicit advance()/rollback()."
                    ),
                    component=s.name,
                )

    # ------------------------------------------------------------------
    # Inspection
    # ------------------------------------------------------------------

    @property
    def current(self) -> Optional[Stage]:
        """Current stage, or None if the flow is complete."""
        if self.is_complete:
            return None
        return self.stages[self._index]

    @property
    def current_monitor(self) -> Optional[Monitor]:
        """Monitor for the current stage, or None if complete."""
        if self.is_complete:
            return None
        return self._monitors[self.current.name]

    @property
    def is_complete(self) -> bool:
        return self._index >= len(self.stages)

    @property
    def stage_index(self) -> int:
        return self._index

    @property
    def transitions(self) -> List[dict]:
        """History of stage transitions."""
        return list(self._transitions)

    @property
    def issues(self) -> IssueBuffer:
        """IssueBuffer of diagnostics this Flow has emitted.  Harvestable."""
        return self._issues

    def diagnose(self, n: int = 10) -> dict:
        """Dashboard-friendly summary of recent issues.  See IssueBuffer.diagnose."""
        return self._issues.diagnose(n)

    # ------------------------------------------------------------------
    # Observation
    # ------------------------------------------------------------------

    def observe(self, values: Dict[str, float], **kw) -> FlowResult:
        """
        Route an observation to the current stage and return guidance.

        ``values`` and any kwargs are forwarded to ``Monitor.update()``, so
        confidences, absences, and provenance all pass through.

        Hard-fail semantics: if the underlying Monitor raises, the issue
        is captured as FATAL on the Flow buffer and re-raised.  Predicate
        exceptions are caught (not re-raised), recorded as ERROR issues,
        and guidance degrades to HOLD with a ``predicate failure`` reason.
        """
        import traceback as _tb

        if self.is_complete:
            return FlowResult(
                flow_label=self.label,
                stage=self.label or "flow",
                stage_index=len(self.stages),
                total_stages=len(self.stages),
                expression=None,
                guidance=Guidance.COMPLETE,
                reason="all stages complete",
                issues=[],
            )

        stage = self.current
        monitor = self._monitors[stage.name]
        try:
            expr = monitor.update(values, **kw)
        except Exception as _e:
            self._issues.emit(
                IssueLevel.FATAL,
                IssueCode.INTERNAL_ERROR,
                detail=f"Monitor.update raised in stage {stage.name!r}: {_e}",
                component=stage.name,
                exc_type=type(_e).__name__,
                traceback=_tb.format_exc(),
            )
            raise

        # Collect issues produced this step: Parser's issues are on expr,
        # predicate failures are emitted during _classify.
        step_issues: List[Issue] = list(expr.issues)

        # STAGE_ABLATED_ON_ENTRY: emit WARNING once if the first observation
        # in this stage lands any component in ABLATED state.  The warning
        # helps operators notice "we entered this stage already in trouble."
        if monitor.step == 1:
            ablated_here = [o.name for o in expr.observations
                            if o.health == Health.ABLATED]
            if ablated_here:
                iss = self._issues.emit(
                    IssueLevel.WARNING,
                    IssueCode.STAGE_ABLATED_ON_ENTRY,
                    detail=(
                        f"stage {stage.name!r} entered with ABLATED "
                        f"component(s): {ablated_here}"
                    ),
                    component=stage.name,
                    ablated_components=list(ablated_here),
                )
                step_issues.append(iss)

        guidance, reason = self._classify(stage, expr, step_issues)

        return FlowResult(
            flow_label=self.label,
            stage=stage.name,
            stage_index=self._index,
            total_stages=len(self.stages),
            expression=expr,
            guidance=guidance,
            reason=reason,
            issues=step_issues,
        )

    def _safe_predicate(
        self,
        predicate,
        expr: Expression,
        name: str,
        stage_name: str,
        collected: List[Issue],
    ) -> Optional[bool]:
        """
        Call a stage predicate, capturing any exception as an ERROR issue.
        Returns None on failure (distinguishable from False), the bool result
        on success.  Issues go both on the Flow buffer (for post-mortem) and
        in ``collected`` (for the FlowResult this step).
        """
        try:
            return bool(predicate(expr))
        except Exception as _e:
            import traceback as _tb
            iss = self._issues.emit(
                IssueLevel.ERROR,
                IssueCode.PREDICATE_FAILURE,
                detail=f"{name} raised in stage {stage_name!r}: {_e}",
                component=stage_name,
                predicate=name,
                exc_type=type(_e).__name__,
                traceback=_tb.format_exc(),
            )
            collected.append(iss)
            return None

    def _classify(
        self, stage: Stage, expr: Expression, collected: List[Issue],
    ) -> tuple[Guidance, str]:
        """Evaluate stage predicates in severity order, safely."""
        # Highest severity first — a true escalate dominates an advance
        if stage.escalate_when is not None:
            fired = self._safe_predicate(
                stage.escalate_when, expr, "escalate_when", stage.name, collected,
            )
            if fired:
                return Guidance.ESCALATE, "escalate_when fired"
        if stage.rollback_when is not None:
            fired = self._safe_predicate(
                stage.rollback_when, expr, "rollback_when", stage.name, collected,
            )
            if fired:
                return Guidance.ROLLBACK, "rollback_when fired"
        if stage.advance_when is not None:
            fired = self._safe_predicate(
                stage.advance_when, expr, "advance_when", stage.name, collected,
            )
            if fired:
                return Guidance.ADVANCE, "advance_when fired"
        if stage.retry_when is not None:
            fired = self._safe_predicate(
                stage.retry_when, expr, "retry_when", stage.name, collected,
            )
            if fired:
                return Guidance.RETRY, "retry_when fired"

        # If any predicate raised, surface that in the reason so callers
        # notice degraded guidance without having to inspect the buffer.
        if any(i.code == IssueCode.PREDICATE_FAILURE for i in collected):
            return Guidance.HOLD, "predicate failure — see issues"

        # Fallback classification using observation health alone
        if any(o.health == Health.ABLATED for o in expr.observations):
            return Guidance.ESCALATE, "component ABLATED"
        if any(o.health == Health.DEGRADED for o in expr.observations):
            return Guidance.RETRY, "component DEGRADED"
        return Guidance.HOLD, "healthy, exit criteria not met"

    # ------------------------------------------------------------------
    # Stage transitions
    # ------------------------------------------------------------------

    def advance(self) -> FlowResult:
        """
        Move to the next stage.  Creates a fresh Monitor for that stage.
        Raises if the flow is already complete.
        """
        if self.is_complete:
            raise ValueError("flow is already complete")
        prev = self.stages[self._index].name
        self._index += 1
        self._transitions.append({
            "from": prev,
            "to": self.stages[self._index].name if not self.is_complete else "(complete)",
            "kind": "advance",
            "at": datetime.now().isoformat(),
        })
        if not self.is_complete:
            self._monitors[self.current.name] = self.current.create_monitor()
        return self._status_result("advanced")

    def rollback(self) -> FlowResult:
        """
        Return to the previous stage.  Creates a fresh Monitor for that stage
        (prior observations during the rollback target are discarded).
        Raises if already at the first stage.
        """
        if self._index == 0:
            raise ValueError("cannot rollback from first stage")
        prev = self.current.name if not self.is_complete else "(complete)"
        self._index -= 1
        self._monitors[self.current.name] = self.current.create_monitor()
        self._transitions.append({
            "from": prev,
            "to": self.current.name,
            "kind": "rollback",
            "at": datetime.now().isoformat(),
        })
        return self._status_result("rolled back")

    def reset(self) -> None:
        """Reset to the first stage.  Clears monitors, transitions, and issues."""
        self._index = 0
        self._monitors = {self.stages[0].name: self.stages[0].create_monitor()}
        self._transitions = []
        self._entered_at = datetime.now()
        self._issues.clear()

    def _status_result(self, reason: str) -> FlowResult:
        if self.is_complete:
            return FlowResult(
                flow_label=self.label,
                stage=self.label or "flow",
                stage_index=len(self.stages),
                total_stages=len(self.stages),
                expression=None,
                guidance=Guidance.COMPLETE,
                reason=reason,
            )
        return FlowResult(
            flow_label=self.label,
            stage=self.current.name,
            stage_index=self._index,
            total_stages=len(self.stages),
            expression=None,
            guidance=Guidance.HOLD,
            reason=reason,
        )

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Serialize the flow's current position and transition log."""
        return {
            "label": self.label,
            "stages": [s.name for s in self.stages],
            "index": self._index,
            "transitions": list(self._transitions),
            "entered_at": self._entered_at.isoformat(),
        }

    def __repr__(self) -> str:
        if self.is_complete:
            pos = f"COMPLETE[{len(self.stages)}/{len(self.stages)}]"
        else:
            pos = f"{self.current.name}[{self._index + 1}/{len(self.stages)}]"
        return f"Flow(label={self.label!r}, {pos})"
