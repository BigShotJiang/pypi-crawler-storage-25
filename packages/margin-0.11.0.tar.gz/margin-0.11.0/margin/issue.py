"""
Issue: typed diagnostics for the margin machinery itself.

Where Health describes the state of what we're observing, and Absence
describes why a value is missing, Issue describes something the library
noticed about its own operation: a misconfiguration, a degraded
assumption, a recovered failure, a near-crash.

Design constraints
------------------

1. **Usable, not just aesthetic.**  Issues accumulate on long-lived
   objects (``Monitor._issues``, ``Flow._issues``) and are attached to
   per-call results (``Expression.issues``, ``FlowResult.issues``).
   Consumers never have to construct their own Issues — the library
   emits them at known sites.

2. **Harvestable on hard fail.**  Issues are added to the buffer
   *before* exceptions propagate, using ``try / except / raise`` patterns
   in the callers — the FATAL record is emitted in the except branch
   before the exception is re-raised.  Even a FATAL internal error leaves
   the full recent issue history intact for post-mortem inspection.

3. **Typed, not strings.**  Issue.code is a short stable identifier
   (``BASELINE_MISSING``, ``PREDICATE_FAILURE``) that consumers can
   filter and aggregate programmatically — the same way DriftState
   or Health are typed.

Exceptions vs. Issues
---------------------

- **Exceptions** mean "your code is broken."  Invalid arguments, wrong
  types, structural errors.  These raise loudly.
- **Issues** mean "something worth noting happened in the system we
  observe or in how we're observing it."  Missing baselines,
  insufficient samples, near-zero std, recovered predicate failures.
  These accumulate.

Convenience: ``diagnose()`` on Monitor/Flow returns a grouped summary
suitable for dashboards or log aggregation.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Deque, Dict, List, Optional


# -----------------------------------------------------------------------
# Level
# -----------------------------------------------------------------------

class IssueLevel(Enum):
    """
    Severity of an Issue.

    INFO:     something worth noting but expected (insufficient samples yet)
    WARNING:  degraded assumption (baseline missing, near-zero std)
    ERROR:    recovered failure (predicate raised, continued on fallback)
    FATAL:    unrecovered failure (exception re-raised after capture)
    """
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    FATAL = "FATAL"


ISSUE_SEVERITY: Dict[IssueLevel, int] = {
    IssueLevel.INFO: 0,
    IssueLevel.WARNING: 1,
    IssueLevel.ERROR: 2,
    IssueLevel.FATAL: 3,
}


# -----------------------------------------------------------------------
# Issue
# -----------------------------------------------------------------------

@dataclass
class Issue:
    """
    One diagnostic event from the margin machinery.

    level:      severity
    code:       short stable identifier (``BASELINE_MISSING``, etc.)
    component:  optional component name this issue is scoped to
    detail:     free-text explanation for a human reader
    at:         timestamp (defaults to now)
    context:    optional extra fields — traceback, exc type, source, etc.
    """
    level: IssueLevel
    code: str
    component: Optional[str] = None
    detail: str = ""
    at: datetime = field(default_factory=datetime.now)
    context: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        d: dict = {
            "level": self.level.value,
            "code": self.code,
            "at": self.at.isoformat(),
        }
        if self.component is not None:
            d["component"] = self.component
        if self.detail:
            d["detail"] = self.detail
        if self.context:
            d["context"] = dict(self.context)
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Issue":
        return cls(
            level=IssueLevel(d["level"]),
            code=d["code"],
            component=d.get("component"),
            detail=d.get("detail", ""),
            at=datetime.fromisoformat(d["at"]) if "at" in d else datetime.now(),
            context=dict(d.get("context", {})),
        )

    def to_atom(self) -> str:
        """Compact string: ``!level[code](component)`` — fits alongside observation atoms."""
        mark = {"INFO": "·", "WARNING": "⚠", "ERROR": "!", "FATAL": "‼"}[self.level.value]
        if self.component is not None:
            return f"{mark}{self.level.value}[{self.code}]({self.component})"
        return f"{mark}{self.level.value}[{self.code}]"

    def __repr__(self) -> str:
        comp = f", component={self.component!r}" if self.component is not None else ""
        return f"Issue({self.level.value}, {self.code}{comp}, {self.detail!r})"


# -----------------------------------------------------------------------
# Buffer
# -----------------------------------------------------------------------

class IssueBuffer:
    """
    Bounded ring buffer of Issues with simple query helpers.

    Lives on long-lived objects (Monitor, Flow) so post-mortem inspection
    survives exceptions and crashes inside library methods.  Bounded so
    long-running sessions don't accumulate unbounded memory.

    Default capacity is 1000 issues.  For high-rate production, consider
    periodically exporting with ``drain()`` and clearing.
    """

    def __init__(self, max_issues: int = 1000):
        if max_issues < 1:
            raise ValueError("max_issues must be >= 1")
        self.max_issues = max_issues
        self._issues: Deque[Issue] = deque(maxlen=max_issues)
        # Optional Python logging integration.  When a logger is attached,
        # every Issue added to the buffer is mirrored to the logger.
        self._logger: Optional[Any] = None
        self._level_map: Optional[Dict[IssueLevel, int]] = None

    # ------------------------------------------------------------------
    # Writing
    # ------------------------------------------------------------------

    def add(self, issue: Issue) -> Issue:
        """Append an issue.  Returns the issue for chained access.

        Mirrors to the attached logger (if any) before returning.
        """
        self._issues.append(issue)
        if self._logger is not None:
            self._mirror_to_logger(issue)
        return issue

    def _mirror_to_logger(self, issue: "Issue") -> None:
        """Emit the issue to the attached Python logger."""
        import logging as _logging
        level_map = self._level_map or {
            IssueLevel.INFO: _logging.INFO,
            IssueLevel.WARNING: _logging.WARNING,
            IssueLevel.ERROR: _logging.ERROR,
            IssueLevel.FATAL: _logging.CRITICAL,
        }
        py_level = level_map.get(issue.level, _logging.WARNING)
        if issue.component:
            msg = f"[{issue.code}] ({issue.component}) {issue.detail}"
        else:
            msg = f"[{issue.code}] {issue.detail}"
        try:
            self._logger.log(py_level, msg, extra={
                "margin_code": issue.code,
                "margin_component": issue.component,
                "margin_level": issue.level.value,
            })
        except Exception:
            # Never let logging errors break the buffer.
            pass

    def attach_logger(self, logger, level_map: Optional[Dict[IssueLevel, int]] = None) -> None:
        """
        Attach a Python ``logging.Logger``.  Subsequent issues are mirrored
        to the logger at the mapped level.

        Default level map::

            IssueLevel.INFO     → logging.INFO
            IssueLevel.WARNING  → logging.WARNING
            IssueLevel.ERROR    → logging.ERROR
            IssueLevel.FATAL    → logging.CRITICAL

        Example::

            import logging
            logger = logging.getLogger("margin")
            monitor.issues.attach_logger(logger)
            # Every issue now also appears in the Python log stream.

        Pass ``level_map`` to override specific mappings.
        Call :meth:`detach_logger` to stop mirroring.
        """
        self._logger = logger
        self._level_map = dict(level_map) if level_map else None

    def detach_logger(self) -> None:
        """Stop mirroring issues to the previously-attached logger."""
        self._logger = None
        self._level_map = None

    def emit(
        self,
        level: IssueLevel,
        code: str,
        detail: str = "",
        component: Optional[str] = None,
        **context: Any,
    ) -> Issue:
        """
        Construct and append an Issue inline.  Returns the issue.

        Convenient at call sites::

            self._issues.emit(IssueLevel.WARNING, "BASELINE_MISSING",
                              f"component {name!r} has no baseline",
                              component=name)
        """
        return self.add(Issue(
            level=level,
            code=code,
            component=component,
            detail=detail,
            context=dict(context) if context else {},
        ))

    def clear(self) -> None:
        self._issues.clear()

    def drain(self) -> List[Issue]:
        """Remove and return all current issues.  Buffer becomes empty."""
        out = list(self._issues)
        self._issues.clear()
        return out

    # ------------------------------------------------------------------
    # Reading
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._issues)

    def __iter__(self):
        return iter(self._issues)

    def __bool__(self) -> bool:
        return bool(self._issues)

    def to_list(self) -> List[Issue]:
        """Snapshot copy of all current issues."""
        return list(self._issues)

    def tail(self, n: int = 10) -> List[Issue]:
        """Last ``n`` issues (most recent)."""
        if n <= 0:
            return []
        items = list(self._issues)
        return items[-n:]

    def by_code(self, code: str) -> List[Issue]:
        return [i for i in self._issues if i.code == code]

    def by_level(self, level: IssueLevel) -> List[Issue]:
        return [i for i in self._issues if i.level == level]

    def by_component(self, component: str) -> List[Issue]:
        return [i for i in self._issues if i.component == component]

    def at_least(self, level: IssueLevel) -> List[Issue]:
        """All issues with severity >= ``level``."""
        threshold = ISSUE_SEVERITY[level]
        return [i for i in self._issues if ISSUE_SEVERITY[i.level] >= threshold]

    # ------------------------------------------------------------------
    # Summarization
    # ------------------------------------------------------------------

    def counts(self) -> Dict[str, int]:
        """Count by level.  Result keys are level string values."""
        out: Dict[str, int] = {l.value: 0 for l in IssueLevel}
        for i in self._issues:
            out[i.level.value] += 1
        return out

    def diagnose(self, n: int = 10, serialize: bool = True) -> Dict[str, Any]:
        """
        Human/dashboard-friendly summary.

        With ``serialize=True`` (default) the result is JSON-ready — every
        value is a primitive or dict/list of primitives — so dashboards
        can ``json.dumps(monitor.diagnose())`` directly.

        With ``serialize=False`` the ``recent`` list contains raw
        :class:`Issue` instances for programmatic inspection.

        Returns::

            {
                "total": int,
                "counts": {"INFO": n, "WARNING": n, "ERROR": n, "FATAL": n},
                "recent": [dict or Issue, ...],
                "codes": {"BASELINE_MISSING": n, ...},
            }
        """
        codes: Dict[str, int] = {}
        for i in self._issues:
            codes[i.code] = codes.get(i.code, 0) + 1
        tail = self.tail(n)
        return {
            "total": len(self._issues),
            "counts": self.counts(),
            "recent": [i.to_dict() for i in tail] if serialize else tail,
            "codes": codes,
        }

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "max_issues": self.max_issues,
            "issues": [i.to_dict() for i in self._issues],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "IssueBuffer":
        buf = cls(max_issues=d.get("max_issues", 1000))
        for item in d.get("issues", []):
            buf.add(Issue.from_dict(item))
        return buf

    def __repr__(self) -> str:
        if not self._issues:
            return "IssueBuffer(empty)"
        c = self.counts()
        parts = [f"{k}={v}" for k, v in c.items() if v > 0]
        return f"IssueBuffer({len(self._issues)}: {', '.join(parts)})"


# -----------------------------------------------------------------------
# Well-known issue codes
# -----------------------------------------------------------------------

# These are the codes the margin library itself emits.  Users can define
# their own codes too — they're just strings.  Centralizing the canonical
# ones here makes them greppable and documentable.

class IssueCode:
    # Parser
    BASELINE_MISSING = "BASELINE_MISSING"           # WARNING

    # Monitor
    INSUFFICIENT_SAMPLES = "INSUFFICIENT_SAMPLES"   # INFO
    NEAR_ZERO_STD = "NEAR_ZERO_STD"                 # INFO

    # Flow
    PREDICATE_FAILURE = "PREDICATE_FAILURE"         # ERROR
    STAGE_ABLATED_ON_ENTRY = "STAGE_ABLATED_ON_ENTRY"  # WARNING
    NO_PREDICATES = "NO_PREDICATES"                 # INFO

    # Catch-all for exceptions that were captured as issues before re-raise
    INTERNAL_ERROR = "INTERNAL_ERROR"               # FATAL

    # User-supplied input problems
    UNKNOWN_COMPONENT = "UNKNOWN_COMPONENT"         # WARNING
