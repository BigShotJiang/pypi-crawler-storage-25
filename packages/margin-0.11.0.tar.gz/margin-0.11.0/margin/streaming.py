"""
Streaming trackers: incremental health, drift, anomaly, and correlation.

Instead of recomputing from a full observation list each time, trackers
maintain a bounded window and update classification on each new value.

    tracker = DriftTracker("cpu")
    tracker.update(observation)
    tracker.state  # DriftState.DRIFTING
"""

from __future__ import annotations

import warnings
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class WindowConfig:
    """
    Per-concern window sizes for Monitor.

    drift:        window for DriftTracker (how many steps to classify trajectory)
    anomaly:      window for AnomalyTracker (reference window for outlier detection)
    correlation:  window for CorrelationTracker (how many steps for pairwise correlation)

    All default to None, meaning "inherit the Monitor's base `window` parameter."
    Rule of thumb: anomaly ≈ 4× drift, correlation ≈ 10× drift.
    """
    drift: Optional[int] = None
    anomaly: Optional[int] = None
    correlation: Optional[int] = None

    def to_dict(self) -> dict:
        """Serialize to plain dict; omits None fields."""
        d: dict = {}
        if self.drift is not None:
            d["drift"] = self.drift
        if self.anomaly is not None:
            d["anomaly"] = self.anomaly
        if self.correlation is not None:
            d["correlation"] = self.correlation
        return d

    @classmethod
    def from_dict(cls, d: dict) -> 'WindowConfig':
        """Deserialize from a plain dict produced by to_dict()."""
        return cls(
            drift=d.get("drift"),
            anomaly=d.get("anomaly"),
            correlation=d.get("correlation"),
        )

    def __repr__(self) -> str:
        parts = [f"{k}={v}" for k, v in
                 [("drift", self.drift), ("anomaly", self.anomaly), ("correlation", self.correlation)]
                 if v is not None]
        return f"WindowConfig({', '.join(parts)})" if parts else "WindowConfig()"

from .confidence import Confidence
from .health import Health, Thresholds, classify
from .observation import Observation, Expression
from .provenance import ProvenanceGraph
from .fingerprint import Fingerprint, _percentile as _fp_percentile
from .drift import (
    DriftState, DriftDirection, DriftClassification,
    classify_drift,
)
from .anomaly import (
    AnomalyState, AnomalyClassification,
    classify_anomaly, detect_jumps, Jump,
)
from .correlate import (
    Correlation, CorrelationMatrix,
    correlate as _correlate,
)


# -----------------------------------------------------------------------
# Drift tracker
# -----------------------------------------------------------------------

class DriftTracker:
    """
    Incremental drift classification for one component.

    Maintains a bounded window of observations and reclassifies on each
    update. Window size is O(1) constant, so updates are bounded-time.

    Usage:
        tracker = DriftTracker("cpu", window=50)
        tracker.update(observation)
        tracker.state       # DriftState
        tracker.direction   # DriftDirection
        tracker.classification  # full DriftClassification or None
    """

    def __init__(
        self,
        component: str,
        window: int = 100,
        min_samples: int = 3,
        noise_threshold: float = 1.5,
        accel_threshold: float = 0.1,
    ):
        self.component = component
        self.window = window
        self._observations: deque[Observation] = deque(maxlen=window)
        self._min_samples = min_samples
        self._noise_threshold = noise_threshold
        self._accel_threshold = accel_threshold
        self._classification: Optional[DriftClassification] = None

    def update(self, observation: Observation) -> Optional[DriftClassification]:
        """Add an observation and reclassify. Returns the new classification."""
        self._observations.append(observation)
        self._classification = classify_drift(
            list(self._observations),
            min_samples=self._min_samples,
            noise_threshold=self._noise_threshold,
            accel_threshold=self._accel_threshold,
        )
        return self._classification

    def update_value(
        self,
        value: float,
        baseline: float,
        higher_is_better: bool = True,
        confidence: Confidence = Confidence.HIGH,
        measured_at: Optional[datetime] = None,
    ) -> Optional[DriftClassification]:
        """Convenience: update from a raw value instead of an Observation."""
        obs = Observation(
            name=self.component,
            health=Health.INTACT,  # placeholder — drift doesn't use health state
            value=value,
            baseline=baseline,
            confidence=confidence,
            higher_is_better=higher_is_better,
            measured_at=measured_at or datetime.now(),
        )
        return self.update(obs)

    @property
    def state(self) -> DriftState:
        if self._classification is None:
            return DriftState.STABLE
        return self._classification.state

    @property
    def direction(self) -> DriftDirection:
        if self._classification is None:
            return DriftDirection.NEUTRAL
        return self._classification.direction

    @property
    def classification(self) -> Optional[DriftClassification]:
        return self._classification

    @property
    def n_observations(self) -> int:
        return len(self._observations)

    def reset(self) -> None:
        """Clear the window."""
        self._observations.clear()
        self._classification = None

    def __repr__(self) -> str:
        return f"DriftTracker({self.component}: {self.state.value}, n={self.n_observations})"


# -----------------------------------------------------------------------
# Anomaly tracker
# -----------------------------------------------------------------------

class AnomalyTracker:
    """
    Incremental anomaly classification for one component.

    Maintains a bounded reference window. New values are classified
    against the reference, then added to it (sliding reference).

    Usage:
        tracker = AnomalyTracker("cpu", window=100)
        tracker.update(42.0)
        tracker.state       # AnomalyState
        tracker.classification  # full AnomalyClassification or None
    """

    def __init__(
        self,
        component: str,
        window: int = 100,
        unusual_threshold: float = 2.0,
        anomalous_threshold: float = 3.0,
        novel_margin: float = 0.1,
        min_reference: int = 10,
        jump_threshold: float = 3.0,
    ):
        self.component = component
        self.window = window
        self._values: deque[float] = deque(maxlen=window)
        self._observations: deque[Observation] = deque(maxlen=window)
        self._unusual_threshold = unusual_threshold
        self._anomalous_threshold = anomalous_threshold
        self._novel_margin = novel_margin
        self._min_reference = min_reference
        self._jump_threshold = jump_threshold
        self._classification: Optional[AnomalyClassification] = None
        self._last_jump: Optional[Jump] = None

    def update(self, value: float) -> Optional[AnomalyClassification]:
        """Classify value against reference window, then add to window."""
        # Classify against existing reference (excluding this value)
        ref = list(self._values)
        if len(ref) >= self._min_reference:
            self._classification = classify_anomaly(
                value, ref,
                component=self.component,
                unusual_threshold=self._unusual_threshold,
                anomalous_threshold=self._anomalous_threshold,
                novel_margin=self._novel_margin,
            )
        else:
            self._classification = None

        # Jump detection: check last few values + new one
        obs = Observation(
            name=self.component, health=Health.INTACT, value=value,
            baseline=0.0, confidence=Confidence.HIGH,
        )
        self._observations.append(obs)
        self._values.append(value)

        if len(self._observations) >= 3:
            recent = list(self._observations)[-5:]  # last 5 for jump context
            jumps = detect_jumps(recent, jump_threshold=self._jump_threshold)
            self._last_jump = jumps[-1] if jumps else None
        else:
            self._last_jump = None

        return self._classification

    def update_obs(self, observation: Observation) -> Optional[AnomalyClassification]:
        """Update from an Observation object."""
        return self.update(observation.value)

    @property
    def state(self) -> AnomalyState:
        if self._classification is None:
            return AnomalyState.EXPECTED
        return self._classification.state

    @property
    def classification(self) -> Optional[AnomalyClassification]:
        return self._classification

    @property
    def last_jump(self) -> Optional[Jump]:
        return self._last_jump

    @property
    def n_values(self) -> int:
        return len(self._values)

    def reset(self) -> None:
        self._values.clear()
        self._observations.clear()
        self._classification = None
        self._last_jump = None

    def __repr__(self) -> str:
        return f"AnomalyTracker({self.component}: {self.state.value}, n={self.n_values})"


# -----------------------------------------------------------------------
# Correlation tracker
# -----------------------------------------------------------------------

class CorrelationTracker:
    """
    Incremental correlation tracking across multiple components.

    Maintains aligned value windows and recomputes pairwise correlations
    on each update.

    Usage:
        tracker = CorrelationTracker(["cpu", "mem", "disk"], window=50)
        tracker.update({"cpu": 80, "mem": 60, "disk": 45})
        tracker.matrix      # CorrelationMatrix
        tracker.strongest() # top correlations
    """

    def __init__(
        self,
        components: list[str],
        window: int = 100,
        min_correlation: float = 0.7,
        min_samples: int = 5,
    ):
        self.components = sorted(components)
        self.window = window
        self._series: dict[str, deque[float]] = {c: deque(maxlen=window) for c in self.components}
        self._n_updates = 0
        self._min_correlation = min_correlation
        self._min_samples = min_samples
        self._matrix: Optional[CorrelationMatrix] = None

    def update(self, values: dict[str, float]) -> Optional[CorrelationMatrix]:
        """
        Update with new values for all components.

        All components must be present in `values` for the update to count
        (maintains alignment). Missing components are silently skipped.
        """
        if not all(c in values for c in self.components):
            return self._matrix

        for c in self.components:
            self._series[c].append(values[c])
        self._n_updates += 1

        # Recompute if enough data
        min_len = min(len(self._series[c]) for c in self.components)
        if min_len >= self._min_samples:
            series = {c: list(self._series[c]) for c in self.components}
            self._matrix = _correlate(
                series,
                min_correlation=self._min_correlation,
                min_samples=self._min_samples,
            )
        return self._matrix

    @property
    def matrix(self) -> Optional[CorrelationMatrix]:
        return self._matrix

    def strongest(self, n: int = 5) -> list[Correlation]:
        if self._matrix is None:
            return []
        return self._matrix.strongest(n)

    @property
    def n_updates(self) -> int:
        return self._n_updates

    def reset(self) -> None:
        for c in self.components:
            self._series[c].clear()
        self._n_updates = 0
        self._matrix = None

    def __repr__(self) -> str:
        n_corr = len(self._matrix.correlations) if self._matrix else 0
        return f"CorrelationTracker({len(self.components)} components, {n_corr} correlations, n={self._n_updates})"


# -----------------------------------------------------------------------
# Monitor — unified streaming tracker
# -----------------------------------------------------------------------

class Monitor:
    """
    Unified streaming monitor: health + drift + anomaly + correlation.

    Wraps a Parser and streaming trackers. One `update()` call classifies
    health, updates drift trajectories, checks for anomalies, and tracks
    correlations across all components.

    Usage:
        monitor = Monitor(parser, window=50)
        monitor.update({"cpu": 80, "mem": 60, "error_rate": 0.03})
        monitor.expression      # current Expression
        monitor.drift("cpu")    # DriftClassification
        monitor.anomaly("cpu")  # AnomalyClassification
        monitor.correlations    # CorrelationMatrix
        monitor.status()        # full snapshot dict
    """

    def __init__(
        self,
        parser,
        window: int = 100,
        drift_window: Optional[int] = None,
        anomaly_window: Optional[int] = None,
        correlation_window: Optional[int] = None,
        window_config: Optional[WindowConfig] = None,
        min_correlation: float = 0.7,
        anomaly_min_reference: int = 10,
        features: Optional[set] = None,
        provenance_graph: Optional[ProvenanceGraph] = None,
    ):
        """
        Args:
            parser:               Parser configured with baselines and thresholds
            window:               base window size for all trackers (overridden per-tracker)
            drift_window:         DriftTracker window (overrides ``window``)
            anomaly_window:       AnomalyTracker window (overrides ``window``)
            correlation_window:   CorrelationTracker window (overrides ``window``)
            window_config:        WindowConfig dataclass; overrides named window params
            min_correlation:      minimum |r| to include a pair in correlations
            anomaly_min_reference: minimum steps before AnomalyTracker classifies
            features:             set of tracker names to enable — ``{"drift"``,
                                  ``"anomaly"``, ``"correlation"}``; ``None`` (default)
                                  enables all three; ``set()`` disables all.
                                  ``"health"`` is always implied and need not be listed.
            provenance_graph:     optional ProvenanceGraph; when provided, each
                                  ``update()`` call records a root node
                                  (``"monitor:step:N"``) and threads its ID into
                                  every observation's ``provenance`` list, enabling
                                  full lineage queries via ``monitor.provenance_graph``
        """
        self.parser = parser
        self.window = window

        # Resolve per-tracker windows: window_config > named params > base window
        cfg = window_config or WindowConfig()
        self.drift_window = cfg.drift or drift_window or window
        self.anomaly_window = cfg.anomaly or anomaly_window or window
        self.correlation_window = cfg.correlation or correlation_window or window

        # Resolve feature flags: None means all enabled (backward compatible)
        self.features = frozenset(features) if features is not None else frozenset({"drift", "anomaly", "correlation"})

        if "anomaly" in self.features and anomaly_min_reference > self.anomaly_window:
            warnings.warn(
                f"Monitor: anomaly_min_reference={anomaly_min_reference} > "
                f"anomaly_window={self.anomaly_window} — AnomalyTrackers will never "
                "classify because the reference window can never be filled; raise "
                "anomaly_window or lower anomaly_min_reference.",
                stacklevel=2,
            )

        self.provenance_graph: Optional[ProvenanceGraph] = provenance_graph
        self._expression: Optional[Expression] = None
        self._step = 0

        # Issue buffer — harvestable even on hard fail.  Populated by
        # Parser (via Expression.issues) + direct emission from update().
        from .issue import IssueBuffer
        self._issues = IssueBuffer()
        # Dedup sets: emit once per component per condition until it resolves
        self._drift_warming: set = set()       # components whose DriftTracker is still below min_samples
        self._anomaly_warming: set = set()     # AnomalyTracker below min_reference
        self._unknown_flagged: set = set()     # unknown-component queries we've already warned about

        # Create per-component trackers for enabled features only
        self._drift_trackers: dict[str, DriftTracker] = {}
        self._anomaly_trackers: dict[str, AnomalyTracker] = {}

        if "drift" in self.features:
            for name in parser.baselines:
                self._drift_trackers[name] = DriftTracker(name, window=self.drift_window)

        if "anomaly" in self.features:
            for name in parser.baselines:
                self._anomaly_trackers[name] = AnomalyTracker(
                    name, window=self.anomaly_window, min_reference=anomaly_min_reference,
                )

        if "correlation" in self.features:
            self._correlation_tracker: Optional[CorrelationTracker] = CorrelationTracker(
                list(parser.baselines.keys()),
                window=self.correlation_window,
                min_correlation=min_correlation,
            )
        else:
            self._correlation_tracker = None

    def update(
        self,
        values: dict[str, float],
        label: str = "",
        now: Optional[datetime] = None,
        confidences=None,
        provenance=None,
        absences=None,
    ) -> Expression:
        """
        Process new measurements: classify health, update drift, check anomalies.

        absences: optional {component: Absence} for components that could not
                  be measured this step.  Absent observations are included in
                  the Expression but skipped in drift/anomaly trackers.

        Returns the current Expression.

        Hard-fail semantics: if any internal step raises, the issue buffer
        gets a FATAL ``INTERNAL_ERROR`` record before the exception
        propagates, so ``monitor.issues`` has post-mortem context intact.
        """
        import traceback as _tb
        from .issue import Issue, IssueLevel, IssueCode

        now = now or datetime.now()
        try:
            # Record a step root in the provenance graph if one is attached.
            if self.provenance_graph is not None:
                step_id = self.provenance_graph.create_root(f"monitor:step:{self._step}")
                provenance = [step_id] + list(provenance or [])

            # Health classification via Parser
            self._expression = self.parser.parse(
                values, label=label, step=self._step,
                confidences=confidences, provenance=provenance,
                absences=absences,
            )
            # Propagate Parser's issues onto the Monitor's buffer so they
            # survive subsequent calls.  Expression keeps its own copy.
            for _iss in self._expression.issues:
                self._issues.add(_iss)
            self._step += 1

            # Update per-component trackers (skip absent observations —
            # they carry no measured value and would corrupt drift/anomaly windows)
            for obs in self._expression.observations:
                if obs.is_absent:
                    continue

                name = obs.name
                baseline = self.parser.baselines.get(name, obs.value)
                thresholds = self.parser._thresholds_for(name)

                # Drift
                if name in self._drift_trackers:
                    stamped = Observation(
                        name=obs.name, health=obs.health, value=obs.value,
                        baseline=obs.baseline, confidence=obs.confidence,
                        higher_is_better=obs.higher_is_better, measured_at=now,
                    )
                    self._drift_trackers[name].update(stamped)

                # Anomaly
                if name in self._anomaly_trackers:
                    self._anomaly_trackers[name].update(obs.value)

            # Correlation
            if self._correlation_tracker is not None:
                self._correlation_tracker.update(values)

            # Warming-up diagnostics: emit INFO once per component while a
            # tracker is still below its min-samples threshold; clear the
            # flag when classification graduates.
            self._emit_warming_issues()

            return self._expression
        except Exception as _e:
            self._issues.emit(
                IssueLevel.FATAL,
                IssueCode.INTERNAL_ERROR,
                detail=f"Monitor.update failed: {_e}",
                exc_type=type(_e).__name__,
                traceback=_tb.format_exc(),
            )
            raise

    @property
    def expression(self) -> Optional[Expression]:
        return self._expression

    @property
    def issues(self):
        """IssueBuffer containing all issues emitted by this Monitor (and its Parser)."""
        return self._issues

    def diagnose(self, n: int = 10, serialize: bool = True) -> dict:
        """Dashboard-friendly summary of recent issues.  See IssueBuffer.diagnose."""
        return self._issues.diagnose(n, serialize=serialize)

    def _flag_unknown(self, component: str, where: str) -> None:
        """Emit UNKNOWN_COMPONENT once per unknown component queried via this method."""
        from .issue import IssueLevel, IssueCode
        key = (where, component)
        if key in self._unknown_flagged:
            return
        self._unknown_flagged.add(key)
        self._issues.emit(
            IssueLevel.WARNING,
            IssueCode.UNKNOWN_COMPONENT,
            detail=(
                f"{where}({component!r}): no tracker registered for this "
                "component.  Add it to Parser.baselines or enable the feature."
            ),
            component=component,
        )

    def _emit_warming_issues(self) -> None:
        """Emit / clear INSUFFICIENT_SAMPLES for trackers still below min_samples."""
        from .issue import IssueLevel, IssueCode

        # Drift
        for name, tracker in self._drift_trackers.items():
            if tracker._classification is None and tracker.n_observations < tracker._min_samples:
                if name not in self._drift_warming:
                    self._drift_warming.add(name)
                    self._issues.emit(
                        IssueLevel.INFO,
                        IssueCode.INSUFFICIENT_SAMPLES,
                        detail=(
                            f"drift tracker for {name!r} has "
                            f"{tracker.n_observations}/{tracker._min_samples} "
                            "required samples; classification unavailable until warmed."
                        ),
                        component=name,
                        kind="drift",
                    )
            else:
                self._drift_warming.discard(name)

        # Anomaly
        for name, tracker in self._anomaly_trackers.items():
            if tracker._classification is None and tracker.n_values < tracker._min_reference:
                if name not in self._anomaly_warming:
                    self._anomaly_warming.add(name)
                    self._issues.emit(
                        IssueLevel.INFO,
                        IssueCode.INSUFFICIENT_SAMPLES,
                        detail=(
                            f"anomaly tracker for {name!r} has "
                            f"{tracker.n_values}/{tracker._min_reference} "
                            "reference values; classification unavailable until warmed."
                        ),
                        component=name,
                        kind="anomaly",
                    )
            else:
                self._anomaly_warming.discard(name)

    def drift(self, component: str) -> Optional[DriftClassification]:
        t = self._drift_trackers.get(component)
        if t is None:
            self._flag_unknown(component, "drift")
            return None
        return t.classification

    def anomaly(self, component: str) -> Optional[AnomalyClassification]:
        t = self._anomaly_trackers.get(component)
        if t is None:
            self._flag_unknown(component, "anomaly")
            return None
        return t.classification

    @property
    def correlations(self) -> Optional[CorrelationMatrix]:
        if self._correlation_tracker is None:
            return None
        return self._correlation_tracker.matrix

    @property
    def step(self) -> int:
        return self._step

    def status(self) -> dict:
        """Full snapshot: health + drift + anomaly + correlations.

        Keys are always present; disabled features or no-data trackers
        return empty dicts so callers can index without key-existence checks.
        """
        d: dict = {
            "step": self._step,
            "expression": self._expression.to_dict() if self._expression else None,
            "drift": {},
            "anomaly": {},
            "correlations": {},
        }
        if "drift" in self.features:
            for name, tracker in self._drift_trackers.items():
                if tracker.classification:
                    d["drift"][name] = tracker.classification.to_dict()
        if "anomaly" in self.features:
            for name, tracker in self._anomaly_trackers.items():
                if tracker.classification:
                    d["anomaly"][name] = tracker.classification.to_dict()
        if self._correlation_tracker is not None and self._correlation_tracker.matrix:
            d["correlations"] = self._correlation_tracker.matrix.to_dict()
        if self.provenance_graph is not None:
            d["provenance_nodes"] = len(self.provenance_graph.nodes)
        d["issues"] = self._issues.diagnose(5)
        return d

    def fingerprint(self) -> Fingerprint:
        """
        Session statistics for each component from the current drift window.

        Returns a :class:`~margin.fingerprint.Fingerprint` with:

        - ``fp[name]["mean"]``  — empirical mean
        - ``fp[name]["std"]``   — sample standard deviation (0.0 if n < 2)
        - ``fp[name]["n"]``     — observations in the window
        - ``fp[name]["trend"]`` — DriftState value string, or ``"UNKNOWN"``
        - ``fp.robust_target(name)`` — median (noise-resistant target)
        - ``fp.percentile(name, p)`` — p-th percentile of observed values

        Typical use: dispositional calibration before a session boundary::

            fp = monitor.fingerprint()
            new_parser = monitor.parser.with_baselines(fp)
            ctrl = Controller.from_fingerprint(fp, "recovery_ratio", kp=0.3, cold_target=0.5)
        """
        stats: dict[str, dict] = {}
        raw_values: dict[str, list[float]] = {}
        for name, tracker in self._drift_trackers.items():
            obs = list(tracker._observations)
            n = len(obs)
            if n == 0:
                stats[name] = {
                    "mean": self.parser.baselines.get(name, 0.0),
                    "std": 0.0, "n": 0, "trend": "UNKNOWN",
                }
                raw_values[name] = []
                continue
            values = [o.value for o in obs]
            mean = sum(values) / n
            std = (sum((v - mean) ** 2 for v in values) / (n - 1)) ** 0.5 if n >= 2 else 0.0
            dc = tracker.classification
            stats[name] = {
                "mean": mean,
                "std": std,
                "n": n,
                "trend": dc.state.value if dc is not None else "UNKNOWN",
                "median": _fp_percentile(values, 50),
                "q25": _fp_percentile(values, 25),
                "q75": _fp_percentile(values, 75),
            }
            raw_values[name] = values
        return Fingerprint(stats=stats, values=raw_values)

    def suggest_target(self, component: str) -> dict:
        """
        Suggest a calibration target based on observed values.

        Returns ``{target: float, confidence: str}`` where:

        - ``target = max(0, mean - 0.5 * std)`` — conservative achievable target
        - ``confidence``: ``"HIGH"`` (n≥30), ``"MODERATE"`` (n≥10), ``"LOW"`` (n<10)

        The formula errs toward under-promising: if mean=0.7, std=0.4 the
        suggestion is 0.5, not 0.7 — reflecting that the metric can be noisy.
        """
        tracker = self._drift_trackers.get(component)
        if tracker is None:
            return {"target": 0.0, "confidence": "NONE"}
        obs = list(tracker._observations)
        n = len(obs)
        if n == 0:
            return {"target": 0.0, "confidence": "NONE"}
        values = [o.value for o in obs]
        mean = sum(values) / n
        std = (sum((v - mean) ** 2 for v in values) / (n - 1)) ** 0.5 if n >= 2 else 0.0
        target = max(0.0, mean - 0.5 * std)
        if n >= 30:
            confidence = "HIGH"
        elif n >= 10:
            confidence = "MODERATE"
        else:
            confidence = "LOW"
        return {"target": target, "confidence": confidence}

    def tail(self, n: int = 10) -> list[Observation]:
        """
        Return the ``n`` most recent observations across all components.

        Observations are drawn from the drift-tracker windows (which store
        the same observations that were fed to drift classification) and
        sorted by ``measured_at``.  Components with disabled drift tracking
        are not included.

        Typical use: inspect recent history before a control decision::

            recent = monitor.tail(20)
            means_sigma = sum(o.sigma for o in recent) / len(recent)
        """
        all_obs: list[Observation] = []
        for tracker in self._drift_trackers.values():
            all_obs.extend(list(tracker._observations)[-n:])
        all_obs.sort(key=lambda o: o.measured_at or datetime.min)
        return all_obs[-n:]

    def predict(self, metric: str, steps: int = 1) -> float:
        """
        Extrapolate a tracked metric ``steps`` into the future.

        Fits a simple linear regression (ordinary least squares) to the
        values currently in the drift window for ``metric``, then extrapolates
        ``steps`` steps ahead.  Returns the raw extrapolated value with no
        clamping — the result may exceed the observed min/max.

        Use cases::

            # Predict RSS in 100 batches so the engine can reclaim early
            projected_rss = monitor.predict("rss_gb", steps=100)
            if projected_rss > RSS_CEILING * 0.9:
                trigger_reclaim()

        Returns the most recent observed value when fewer than 2 observations
        are available (no trend to fit).  Returns 0.0 for unknown ``metric``.

        Parameters
        ----------
        metric: component name tracked by this Monitor
        steps:  how many steps ahead to predict (default 1)
        """
        tracker = self._drift_trackers.get(metric)
        if tracker is None:
            return 0.0
        obs = list(tracker._observations)
        n = len(obs)
        if n == 0:
            return 0.0
        if n == 1:
            return obs[0].value

        values = [o.value for o in obs]
        xs = list(range(n))

        # OLS: slope = (n*Σxy - Σx*Σy) / (n*Σx² - (Σx)²)
        sum_x = sum(xs)
        sum_y = sum(values)
        sum_xy = sum(x * y for x, y in zip(xs, values))
        sum_x2 = sum(x * x for x in xs)
        denom = n * sum_x2 - sum_x * sum_x
        if denom == 0:
            return values[-1]
        slope = (n * sum_xy - sum_x * sum_y) / denom
        intercept = (sum_y - slope * sum_x) / n
        return intercept + slope * (n - 1 + steps)

    def attribute_drift(
        self,
        component: Optional[str] = None,
    ):
        """
        Return drift classification(s) framed for attribution / alerting.

        With a ``component``: returns the ``DriftClassification`` for that
        component (same as ``monitor.drift(component)`` but named for
        attribution context — "what is driving the change in pass_rate?").

        Without a ``component``: returns ``{component: DriftClassification}``
        for every tracked component that has a classification, so a watchdog
        can scan all metrics in one call::

            for comp, dc in monitor.attribute_drift().items():
                if dc.state != DriftState.STABLE:
                    alert(f"{comp}: {dc.state.value} @ rate={dc.rate:.3f}")

        Parameters
        ----------
        component: component name, or ``None`` to return all
        """
        if component is not None:
            return self.drift(component)
        return {
            name: t.classification
            for name, t in self._drift_trackers.items()
            if t.classification is not None
        }

    def anomaly_score(
        self,
        reference_fp: "Fingerprint",
        metrics: Optional[list[str]] = None,
    ) -> float:
        """
        Cross-session divergence score: how much does the current session diverge
        from the reference fingerprint?

        Computes the current session fingerprint, then returns the mean absolute
        z-score across all components::

            score = mean(|current_mean − ref_mean| / ref_std)

        A score near 0 means "this session looks like the reference."
        A score > 1.0 means the average component is more than 1 std from baseline.
        A score > 2.0 is a strong signal of distributional shift.

        Components with ``ref_std = 0`` are skipped.

        Parameters
        ----------
        reference_fp: Fingerprint from a prior session (e.g. loaded from JSON)
        metrics:      restrict to these component names; None = all shared keys

        Example::

            fp_s1 = Fingerprint.from_dict(json.loads(open("session1.json").read()))
            score = monitor.anomaly_score(fp_s1)
            if score > 1.5:
                print(f"Session diverged from baseline (score={score:.2f})")
        """
        from .issue import IssueLevel, IssueCode
        current_fp = self.fingerprint()
        _metrics = list(metrics) if metrics is not None else list(
            set(current_fp.keys()) & set(reference_fp.keys())
        )
        if not _metrics:
            return 0.0
        z_scores = []
        skipped_near_zero: list[str] = []
        for m in _metrics:
            ref_std = reference_fp.get(m, {}).get("std", 0.0)
            # 1e-12 tolerance: reject floating-point noise from constant windows
            if ref_std < 1e-12:
                skipped_near_zero.append(m)
                continue
            cur_mean = current_fp.get(m, {}).get("mean", 0.0)
            ref_mean = reference_fp.get(m, {}).get("mean", 0.0)
            z_scores.append(abs(cur_mean - ref_mean) / ref_std)
        if skipped_near_zero:
            self._issues.emit(
                IssueLevel.INFO,
                IssueCode.NEAR_ZERO_STD,
                detail=(
                    f"anomaly_score skipped {len(skipped_near_zero)} "
                    f"metric(s) with near-zero reference std: {skipped_near_zero}"
                ),
                skipped_metrics=list(skipped_near_zero),
            )
        return sum(z_scores) / len(z_scores) if z_scores else 0.0

    def reset_anomaly_reference(self, components: Optional[list[str]] = None) -> None:
        """
        Clear AnomalyTracker reference windows for the specified components.

        Call after recalibrate_parser() to prevent old-baseline data from
        contaminating anomaly classification during the warm-up period that
        follows recalibration. The trackers will return None classifications
        until they accumulate min_reference new values under the new baseline.

        Args:
            components: names to reset; None resets all components.
        """
        targets = components or list(self._anomaly_trackers.keys())
        for name in targets:
            if name in self._anomaly_trackers:
                self._anomaly_trackers[name].reset()

    def reset(self) -> None:
        self._expression = None
        self._step = 0
        for t in self._drift_trackers.values():
            t.reset()
        for t in self._anomaly_trackers.values():
            t.reset()
        if self._correlation_tracker is not None:
            self._correlation_tracker.reset()

    def __repr__(self) -> str:
        windows_uniform = (self.drift_window == self.anomaly_window == self.correlation_window)
        if windows_uniform:
            w = f"window={self.drift_window}"
        else:
            w = f"drift={self.drift_window}, anomaly={self.anomaly_window}, corr={self.correlation_window}"
        all_features = frozenset({"drift", "anomaly", "correlation"})
        if self.features == all_features:
            feat = ""
        else:
            feat = f", features={{{', '.join(sorted(self.features))}}}"
        pg = ", provenance=True" if self.provenance_graph is not None else ""
        return f"Monitor(step={self._step}, {len(self._drift_trackers)} components, {w}{feat}{pg})"
