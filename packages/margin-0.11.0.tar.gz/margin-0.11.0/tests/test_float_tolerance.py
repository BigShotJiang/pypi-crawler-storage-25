"""
Regression tests for floating-point tolerance in std-based division.

On Python 3.10, sum([0.1]*20)/20 returns 0.10000000000000002 and the
resulting std accumulates to ~1.4e-17 instead of exactly 0.0.  Every
site that divides by std must treat that as effectively zero or it
amplifies results by 15+ orders of magnitude.

Sites covered:
    Fingerprint.sigma              (v0.9.25)
    Fingerprint.robust_sigma       (v0.9.25)
    anomaly.check_distribution     (v0.9.25)
    anomaly.classify_anomaly       (v0.9.26)
    anomaly._kurtosis_excess       (v0.9.26)
    anomaly._skewness              (v0.9.26)
    Monitor.anomaly_score          (v0.9.26)
    calibrate.calibrate (use_std)  (v0.9.26)
"""
import math
import pytest

from margin import (
    Absence, AnomalyState, Confidence, Fingerprint, Monitor, Parser, Thresholds,
    calibrate, check_distribution, classify_anomaly,
)


CONSTANT = [0.1] * 20  # sum/n = 0.10000000000000002, std ≈ 1.4e-17 on 3.10


def _fp(values: list[float], name: str = "x") -> Fingerprint:
    n = len(values)
    mean = sum(values) / n
    std = math.sqrt(sum((v - mean) ** 2 for v in values) / (n - 1))
    return Fingerprint(
        stats={name: {"mean": mean, "std": std, "n": n, "trend": "STABLE"}},
        values={name: list(values)},
    )


class TestFingerprintSigma:
    def test_constant_window_does_not_amplify(self):
        fp = _fp(CONSTANT)
        # value-mean = 0.05, std accumulated ≈ 1.4e-17 — bogus division would
        # give ~3.5e15.  Tolerance guard routes to the |mean| branch instead.
        result = fp.sigma("x", 0.15)
        assert abs(result) < 100  # bounded by real signal, not FP noise

    def test_constant_window_robust_sigma_does_not_amplify(self):
        fp = _fp(CONSTANT)
        result = fp.robust_sigma("x", 0.15)
        assert abs(result) < 100


class TestAnomalyClassifyAnomaly:
    def test_constant_reference_does_not_saturate(self):
        # value very close to mean should not classify as NOVEL just because
        # dividing by 1e-17 produces a "huge" z-score.
        ac = classify_anomaly(0.15, CONSTANT, component="rr")
        assert ac is not None
        # z-score is either 0 (equal-means branch) or inf (zero-std branch),
        # never a bogus finite value in the 1e15 range.
        assert ac.z_score == 0 or math.isinf(ac.z_score) or abs(ac.z_score) < 1e6


class TestCheckDistribution:
    def test_both_constant_windows_no_inf_std_ratio(self):
        ref = [70.0] * 20
        recent = [70.2] * 10
        ds = check_distribution(recent, ref)
        # Pre-fix, std_ratio was inf.  Post-fix, it's 1.0 (both effectively zero-std).
        assert math.isfinite(ds.std_ratio) or ds.std_ratio == 1.0

    def test_stable_calibration_no_recalibration(self):
        from margin import needs_recalibration_many
        cal = {"cpu": [50.0] * 20, "mem": [70.0] * 20}
        recent = {"cpu": [50.5] * 10, "mem": [70.2] * 10}
        flags = needs_recalibration_many(cal, recent)
        # Small shifts on constant data must NOT trigger recalibration.
        assert flags["cpu"] is False
        assert flags["mem"] is False


class TestMonitorAnomalyScore:
    def test_constant_reference_fp_skips_noise_metrics(self):
        parser = Parser(baselines={"rr": 0.1}, thresholds=Thresholds(intact=0.8, ablated=0.2))
        m = Monitor(parser, window=50)
        for _ in range(20):
            m.update({"rr": 0.1})
        ref_fp = m.fingerprint()
        # Feed slightly different value, score should be small, not 1e15.
        for _ in range(20):
            m.update({"rr": 0.11})
        score = m.anomaly_score(ref_fp)
        assert math.isfinite(score)
        assert score < 1e6


class TestCalibrateUseStd:
    def test_constant_input_raises_clear_error(self):
        # Pre-fix: std = 1.4e-17 passed the `std == 0` check, producing
        # thresholds that were essentially baseline ± 1e-17 — all values
        # classified INTACT.  Post-fix: raises the same clear error as true zero.
        with pytest.raises(ValueError, match="zero-variance"):
            calibrate(CONSTANT, use_std=True)


class TestSkewKurtosis:
    def test_constant_input_kurtosis_is_zero(self):
        from margin.anomaly import _kurtosis_excess, _skewness, _mean, _std
        xs = CONSTANT
        mean = _mean(xs)
        std = _std(xs, mean)
        # Pre-fix these would divide by ~1e-17 and return nonsense.
        assert _kurtosis_excess(xs, mean, std) == 0.0
        assert _skewness(xs, mean, std) == 0.0
