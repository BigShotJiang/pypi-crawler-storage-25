"""
Tests for Issue, IssueBuffer, and integration into Parser/Monitor/Flow.

Emphasis on harvestability on hard fail: if a Monitor or Flow method
raises an exception, the diagnostic record should be intact in the
buffer, not lost.
"""
import json
import logging
import pytest

from margin import (
    Issue, IssueLevel, IssueCode, IssueBuffer, ISSUE_SEVERITY,
    Expression, Flow, Stage, Guidance, Monitor, Parser, Thresholds,
    Health,
)


# ---------------------------------------------------------------------------
# Issue type
# ---------------------------------------------------------------------------

class TestIssue:
    def test_fields(self):
        i = Issue(level=IssueLevel.WARNING, code="FOO", component="cpu", detail="bar")
        assert i.level == IssueLevel.WARNING
        assert i.code == "FOO"
        assert i.component == "cpu"
        assert i.detail == "bar"
        assert i.at is not None
        assert i.context == {}

    def test_to_dict_minimal(self):
        i = Issue(level=IssueLevel.INFO, code="X")
        d = i.to_dict()
        assert d["level"] == "INFO"
        assert d["code"] == "X"
        assert "component" not in d
        assert "detail" not in d
        assert "context" not in d

    def test_to_dict_full(self):
        i = Issue(
            level=IssueLevel.ERROR,
            code="PREDICATE_FAILURE",
            component="stage_a",
            detail="advance_when raised",
            context={"traceback": "..."},
        )
        d = i.to_dict()
        assert d["level"] == "ERROR"
        assert d["component"] == "stage_a"
        assert d["detail"] == "advance_when raised"
        assert d["context"] == {"traceback": "..."}

    def test_round_trip(self):
        i = Issue(level=IssueLevel.WARNING, code="X", component="c", detail="d",
                  context={"k": "v"})
        restored = Issue.from_dict(i.to_dict())
        assert restored.level == i.level
        assert restored.code == i.code
        assert restored.component == i.component
        assert restored.detail == i.detail
        assert restored.context == i.context

    def test_to_atom(self):
        i = Issue(level=IssueLevel.WARNING, code="BASELINE_MISSING", component="cpu")
        a = i.to_atom()
        assert "WARNING" in a
        assert "BASELINE_MISSING" in a
        assert "(cpu)" in a


# ---------------------------------------------------------------------------
# IssueBuffer
# ---------------------------------------------------------------------------

class TestIssueBuffer:
    def test_empty(self):
        b = IssueBuffer()
        assert len(b) == 0
        assert not b
        assert b.to_list() == []

    def test_add(self):
        b = IssueBuffer()
        b.add(Issue(level=IssueLevel.INFO, code="X"))
        assert len(b) == 1
        assert b

    def test_emit_inline(self):
        b = IssueBuffer()
        iss = b.emit(IssueLevel.WARNING, "BASELINE_MISSING", "x not set", component="x")
        assert iss.code == "BASELINE_MISSING"
        assert len(b) == 1

    def test_bounded(self):
        b = IssueBuffer(max_issues=3)
        for i in range(10):
            b.add(Issue(level=IssueLevel.INFO, code=f"C{i}"))
        assert len(b) == 3
        # FIFO eviction: oldest dropped
        codes = [i.code for i in b]
        assert codes == ["C7", "C8", "C9"]

    def test_clear(self):
        b = IssueBuffer()
        b.emit(IssueLevel.INFO, "X")
        b.clear()
        assert len(b) == 0

    def test_drain(self):
        b = IssueBuffer()
        b.emit(IssueLevel.INFO, "X")
        b.emit(IssueLevel.WARNING, "Y")
        out = b.drain()
        assert len(out) == 2
        assert len(b) == 0

    def test_tail(self):
        b = IssueBuffer()
        for i in range(10):
            b.emit(IssueLevel.INFO, f"C{i}")
        last3 = b.tail(3)
        assert [i.code for i in last3] == ["C7", "C8", "C9"]

    def test_by_code(self):
        b = IssueBuffer()
        b.emit(IssueLevel.INFO, "A")
        b.emit(IssueLevel.INFO, "B")
        b.emit(IssueLevel.INFO, "A")
        assert len(b.by_code("A")) == 2

    def test_by_level(self):
        b = IssueBuffer()
        b.emit(IssueLevel.INFO, "X")
        b.emit(IssueLevel.WARNING, "Y")
        b.emit(IssueLevel.ERROR, "Z")
        assert len(b.by_level(IssueLevel.WARNING)) == 1

    def test_at_least(self):
        b = IssueBuffer()
        b.emit(IssueLevel.INFO, "X")
        b.emit(IssueLevel.WARNING, "Y")
        b.emit(IssueLevel.ERROR, "Z")
        b.emit(IssueLevel.FATAL, "W")
        assert len(b.at_least(IssueLevel.WARNING)) == 3
        assert len(b.at_least(IssueLevel.FATAL)) == 1

    def test_counts(self):
        b = IssueBuffer()
        b.emit(IssueLevel.INFO, "A")
        b.emit(IssueLevel.INFO, "B")
        b.emit(IssueLevel.WARNING, "C")
        c = b.counts()
        assert c["INFO"] == 2
        assert c["WARNING"] == 1
        assert c["ERROR"] == 0

    def test_diagnose(self):
        b = IssueBuffer()
        b.emit(IssueLevel.WARNING, "BASELINE_MISSING")
        b.emit(IssueLevel.WARNING, "BASELINE_MISSING")
        b.emit(IssueLevel.INFO, "INSUFFICIENT_SAMPLES")
        d = b.diagnose()
        assert d["total"] == 3
        assert d["codes"]["BASELINE_MISSING"] == 2
        assert d["codes"]["INSUFFICIENT_SAMPLES"] == 1
        assert len(d["recent"]) == 3

    def test_round_trip(self):
        b = IssueBuffer(max_issues=100)
        b.emit(IssueLevel.WARNING, "X", component="c", detail="d")
        b.emit(IssueLevel.INFO, "Y")
        d = b.to_dict()
        restored = IssueBuffer.from_dict(d)
        assert len(restored) == 2
        assert restored.max_issues == 100

    def test_rejects_invalid_capacity(self):
        with pytest.raises(ValueError):
            IssueBuffer(max_issues=0)


# ---------------------------------------------------------------------------
# Parser → Expression.issues
# ---------------------------------------------------------------------------

class TestParserIssues:
    def test_no_issues_when_baselines_complete(self):
        p = Parser(baselines={"m": 1.0}, thresholds=Thresholds(intact=0.8, ablated=0.2))
        expr = p.parse({"m": 1.0})
        assert expr.issues == []

    def test_baseline_missing_emits_warning_issue(self):
        p = Parser(baselines={}, thresholds=Thresholds(intact=0.8, ablated=0.2))
        with pytest.warns(UserWarning):
            expr = p.parse({"missing": 1.0})
        assert len(expr.issues) == 1
        iss = expr.issues[0]
        assert iss.level == IssueLevel.WARNING
        assert iss.code == IssueCode.BASELINE_MISSING
        assert iss.component == "missing"

    def test_multiple_missing_baselines(self):
        p = Parser(baselines={}, thresholds=Thresholds(intact=0.8, ablated=0.2))
        with pytest.warns(UserWarning):
            expr = p.parse({"a": 1.0, "b": 2.0})
        assert len(expr.issues) == 2
        codes = {i.code for i in expr.issues}
        assert codes == {IssueCode.BASELINE_MISSING}

    def test_expression_issues_round_trip(self):
        p = Parser(baselines={}, thresholds=Thresholds(intact=0.8, ablated=0.2))
        with pytest.warns(UserWarning):
            expr = p.parse({"missing": 1.0})
        restored = Expression.from_dict(expr.to_dict())
        assert len(restored.issues) == 1
        assert restored.issues[0].code == IssueCode.BASELINE_MISSING


# ---------------------------------------------------------------------------
# Monitor issues + harvest-safety
# ---------------------------------------------------------------------------

class TestMonitorIssues:
    def _monitor(self, baselines=None) -> Monitor:
        p = Parser(
            baselines=baselines or {"m": 1.0},
            thresholds=Thresholds(intact=0.8, ablated=0.2),
        )
        return Monitor(p, window=50)

    def test_issues_property_starts_empty(self):
        m = self._monitor()
        assert len(m.issues) == 0

    def test_parser_issues_propagate_to_monitor(self):
        m = self._monitor(baselines={})
        with pytest.warns(UserWarning):
            m.update({"x": 1.0})
        # BASELINE_MISSING from parser, plus INSUFFICIENT_SAMPLES from
        # freshly-created drift/anomaly trackers warming up.
        assert len(m.issues.by_code(IssueCode.BASELINE_MISSING)) == 1

    def test_monitor_issues_accumulate(self):
        m = self._monitor(baselines={})
        with pytest.warns(UserWarning):
            m.update({"a": 1.0})
            m.update({"b": 1.0})
            m.update({"c": 1.0})
        # One BASELINE_MISSING per unique component (parser emits per unknown)
        assert len(m.issues.by_code(IssueCode.BASELINE_MISSING)) == 3

    def test_monitor_diagnose(self):
        m = self._monitor(baselines={})
        with pytest.warns(UserWarning):
            m.update({"a": 1.0})
            m.update({"b": 1.0})
        d = m.diagnose()
        assert d["codes"][IssueCode.BASELINE_MISSING] == 2

    def test_hard_fail_captures_fatal_issue(self):
        """If Monitor.update() raises, the issue buffer must contain
        a FATAL entry describing the failure — harvest-safe invariant."""
        m = self._monitor()

        class _Boom(Exception):
            pass

        # Force a failure by monkey-patching the parser to raise.
        orig_parse = m.parser.parse
        def broken_parse(*a, **kw):
            raise _Boom("simulated parser failure")
        m.parser.parse = broken_parse

        with pytest.raises(_Boom):
            m.update({"m": 1.0})

        # Despite the exception, the buffer must have the FATAL record.
        fatals = m.issues.by_level(IssueLevel.FATAL)
        assert len(fatals) == 1
        assert fatals[0].code == IssueCode.INTERNAL_ERROR
        assert "simulated parser failure" in fatals[0].detail
        assert fatals[0].context.get("exc_type") == "_Boom"
        assert "traceback" in fatals[0].context

        m.parser.parse = orig_parse

    def test_hard_fail_preserves_prior_issues(self):
        """Earlier issues must not be wiped when a later call fails."""
        m = self._monitor(baselines={})
        with pytest.warns(UserWarning):
            m.update({"known_missing": 1.0})
        # At least one BASELINE_MISSING WARNING (plus warming-up INFOs)
        assert len(m.issues.by_level(IssueLevel.WARNING)) >= 1

        class _Boom(Exception): pass
        orig = m.parser.parse
        m.parser.parse = lambda *a, **kw: (_ for _ in ()).throw(_Boom("x"))
        with pytest.raises(_Boom):
            m.update({"m": 1.0})
        m.parser.parse = orig

        # Original WARNING is still there, plus a FATAL.
        assert len(m.issues.by_level(IssueLevel.WARNING)) >= 1
        assert len(m.issues.by_level(IssueLevel.FATAL)) == 1


# ---------------------------------------------------------------------------
# Flow issues + predicate guard
# ---------------------------------------------------------------------------

class TestFlowIssues:
    def _parser(self, baselines=None):
        return Parser(
            baselines=baselines or {"m": 1.0},
            thresholds=Thresholds(intact=0.8, ablated=0.2),
        )

    def test_no_predicates_emits_info_on_construction(self):
        f = Flow(stages=[Stage(name="a", parser=self._parser())])
        # At least one INFO issue for NO_PREDICATES
        codes = {i.code for i in f.issues}
        assert IssueCode.NO_PREDICATES in codes

    def test_stage_with_advance_when_no_info_issue(self):
        f = Flow(stages=[
            Stage(name="a", parser=self._parser(), advance_when=lambda e: False),
        ])
        assert IssueCode.NO_PREDICATES not in {i.code for i in f.issues}

    def test_predicate_failure_captured_not_raised(self):
        """A predicate that raises must NOT propagate.  Instead: ERROR
        issue, HOLD guidance, reason explains."""
        def broken(expr):
            raise RuntimeError("predicate is broken")

        f = Flow(stages=[
            Stage(name="a", parser=self._parser(), advance_when=broken),
        ], label="t")
        result = f.observe({"m": 1.0})

        assert result.guidance == Guidance.HOLD
        assert "predicate failure" in result.reason

        errors = f.issues.by_level(IssueLevel.ERROR)
        assert len(errors) == 1
        assert errors[0].code == IssueCode.PREDICATE_FAILURE
        assert "advance_when" in errors[0].detail
        assert "predicate is broken" in errors[0].detail

        # Issues also attached to the FlowResult for the step.
        assert any(i.code == IssueCode.PREDICATE_FAILURE for i in result.issues)

    def test_predicate_failure_does_not_break_subsequent_observes(self):
        """Flow stays alive after a predicate failure — buffer accumulates."""
        raised = [0]
        def broken(expr):
            raised[0] += 1
            raise ValueError("oops")

        f = Flow(stages=[
            Stage(name="a", parser=self._parser(), advance_when=broken),
        ])
        r1 = f.observe({"m": 1.0})
        r2 = f.observe({"m": 1.0})
        assert r1.guidance == Guidance.HOLD
        assert r2.guidance == Guidance.HOLD
        assert raised[0] == 2
        assert len(f.issues.by_code(IssueCode.PREDICATE_FAILURE)) == 2

    def test_hard_fail_in_monitor_reraises_and_captures(self):
        """If the underlying Monitor.update raises, Flow re-raises but
        the FATAL issue is captured for post-mortem."""
        f = Flow(stages=[Stage(name="a", parser=self._parser())], label="t")
        # Force the Monitor to explode
        class _Boom(Exception): pass
        monitor = f._monitors["a"]
        monitor.parser.parse = lambda *a, **kw: (_ for _ in ()).throw(_Boom("nope"))

        with pytest.raises(_Boom):
            f.observe({"m": 1.0})

        fatals = f.issues.by_level(IssueLevel.FATAL)
        assert len(fatals) >= 1
        # The Flow's own record about Monitor failure
        flow_fatal = [i for i in fatals if "Monitor.update raised" in i.detail]
        assert len(flow_fatal) == 1
        assert flow_fatal[0].component == "a"

    def test_parser_issues_show_in_flow_result(self):
        """Issues from Parser (via Monitor) appear on the FlowResult."""
        f = Flow(stages=[Stage(name="a", parser=self._parser(baselines={}))])
        with pytest.warns(UserWarning):
            r = f.observe({"mystery": 1.0})
        assert any(i.code == IssueCode.BASELINE_MISSING for i in r.issues)

    def test_reset_clears_issues(self):
        f = Flow(stages=[Stage(name="a", parser=self._parser())])  # NO_PREDICATES INFO
        assert len(f.issues) > 0
        f.reset()
        # After reset the NO_PREDICATES doesn't re-emit (we only emit once, at construction)
        assert len(f.issues) == 0

    def test_diagnose_on_flow(self):
        def broken(expr):
            raise RuntimeError("x")

        f = Flow(stages=[Stage(name="a", parser=self._parser(), advance_when=broken)])
        f.observe({"m": 1.0})
        f.observe({"m": 1.0})
        d = f.diagnose()
        assert d["total"] >= 2
        assert d["codes"][IssueCode.PREDICATE_FAILURE] == 2


# ---------------------------------------------------------------------------
# FlowResult atom rendering with issues
# ---------------------------------------------------------------------------

class TestFlowResultAtomWithIssues:
    def test_atom_annotates_issues(self):
        def broken(expr):
            raise RuntimeError("x")

        f = Flow(
            stages=[Stage(name="lag", parser=Parser(
                baselines={"m": 1.0},
                thresholds=Thresholds(intact=0.8, ablated=0.2),
            ), advance_when=broken)],
            label="ferment",
        )
        r = f.observe({"m": 1.0})
        atom = r.to_atom()
        assert "flow:ferment:lag" in atom
        assert "HOLD" in atom
        # Annotation marker for an ERROR issue
        assert "!" in atom or "1" in atom

    def test_atom_unchanged_when_no_issues(self):
        f = Flow(
            stages=[Stage(
                name="lag",
                parser=Parser(baselines={"m": 1.0}, thresholds=Thresholds(intact=0.8, ablated=0.2)),
                advance_when=lambda e: False,  # avoids NO_PREDICATES INFO
            )],
            label="ferment",
        )
        r = f.observe({"m": 1.0})
        # No issues this step, so no suffix parenthetical
        assert "(" not in r.to_atom() or "step" not in r.to_atom().lower()
        assert r.to_atom() == "flow:ferment:lag[1/1] → HOLD"


# ---------------------------------------------------------------------------
# v0.9.31 additions — full emission coverage
# ---------------------------------------------------------------------------

class TestDiagnoseSerialization:
    def test_diagnose_is_json_serializable_by_default(self):
        m = Monitor(
            Parser(baselines={"cpu": 50.0}, thresholds=Thresholds(intact=40, ablated=10)),
            window=20,
        )
        m.update({"cpu": 50.0})
        m.drift("nonexistent")  # emits UNKNOWN_COMPONENT
        d = m.diagnose()
        # Must round-trip through JSON cleanly.
        s = json.dumps(d)
        restored = json.loads(s)
        assert restored["total"] == d["total"]
        assert isinstance(restored["recent"], list)
        # Recent entries are dicts, not Issue objects.
        assert all(isinstance(r, dict) for r in restored["recent"])

    def test_diagnose_serialize_false_returns_issue_objects(self):
        m = Monitor(
            Parser(baselines={"cpu": 50.0}, thresholds=Thresholds(intact=40, ablated=10)),
            window=20,
        )
        m.drift("nonexistent")
        d = m.diagnose(serialize=False)
        assert all(isinstance(r, Issue) for r in d["recent"])


class TestAttachLogger:
    def test_attach_logger_mirrors_emissions(self):
        logger = logging.getLogger("margin.test.attach")
        logger.setLevel(logging.DEBUG)
        records = []
        handler = logging.Handler()
        handler.emit = lambda r: records.append(r)
        logger.addHandler(handler)

        b = IssueBuffer()
        b.attach_logger(logger)
        b.emit(IssueLevel.WARNING, "BASELINE_MISSING", "x", component="cpu")
        b.emit(IssueLevel.FATAL, "INTERNAL_ERROR", "boom")

        assert len(records) == 2
        assert records[0].levelno == logging.WARNING
        assert "BASELINE_MISSING" in records[0].getMessage()
        assert records[0].margin_code == "BASELINE_MISSING"
        assert records[0].margin_component == "cpu"
        assert records[1].levelno == logging.CRITICAL

    def test_detach_logger_stops_mirroring(self):
        logger = logging.getLogger("margin.test.detach")
        logger.setLevel(logging.DEBUG)
        records = []
        handler = logging.Handler()
        handler.emit = lambda r: records.append(r)
        logger.addHandler(handler)

        b = IssueBuffer()
        b.attach_logger(logger)
        b.emit(IssueLevel.INFO, "X")
        b.detach_logger()
        b.emit(IssueLevel.INFO, "Y")
        assert len(records) == 1

    def test_logger_level_map_override(self):
        logger = logging.getLogger("margin.test.levelmap")
        logger.setLevel(logging.DEBUG)
        records = []
        handler = logging.Handler()
        handler.emit = lambda r: records.append(r)
        logger.addHandler(handler)

        b = IssueBuffer()
        # Map INFO to DEBUG so INFO-level issues don't spam user logs
        b.attach_logger(logger, level_map={IssueLevel.INFO: logging.DEBUG})
        b.emit(IssueLevel.INFO, "X")
        # INFO → DEBUG, mirrored at DEBUG level
        assert len(records) == 1 and records[0].levelno == logging.DEBUG

    def test_logger_failure_does_not_break_buffer(self):
        class BrokenLogger:
            def log(self, *a, **kw):
                raise RuntimeError("logger broken")

        b = IssueBuffer()
        b.attach_logger(BrokenLogger())
        # Must not raise
        b.emit(IssueLevel.INFO, "X")
        assert len(b) == 1


class TestInsufficientSamplesEmission:
    def test_warming_up_emits_info_once_per_component(self):
        m = Monitor(
            Parser(baselines={"cpu": 50.0}, thresholds=Thresholds(intact=40, ablated=10)),
            window=20,
        )
        m.update({"cpu": 50.0})
        m.update({"cpu": 50.0})
        m.update({"cpu": 50.0})
        # drift tracker below min_samples (default 3) for the first call,
        # graduates at the third — we should see exactly one INFO per tracker
        # (drift + anomaly) during warming, not one per call.
        insufficient = m.issues.by_code(IssueCode.INSUFFICIENT_SAMPLES)
        # At most one per tracker kind (drift + anomaly)
        assert len(insufficient) <= 2

    def test_insufficient_samples_cleared_after_graduation(self):
        m = Monitor(
            Parser(baselines={"cpu": 50.0}, thresholds=Thresholds(intact=40, ablated=10)),
            window=20,
        )
        for _ in range(20):
            m.update({"cpu": 50.0})
        # Drift should have classified by now; warming-up flag cleared.
        assert "cpu" not in m._drift_warming


class TestUnknownComponentEmission:
    def test_unknown_component_emits_once(self):
        m = Monitor(
            Parser(baselines={"cpu": 50.0}, thresholds=Thresholds(intact=40, ablated=10)),
            window=20,
        )
        assert m.drift("nonexistent") is None
        assert m.drift("nonexistent") is None  # repeated query
        assert m.drift("nonexistent") is None
        unknowns = m.issues.by_code(IssueCode.UNKNOWN_COMPONENT)
        assert len(unknowns) == 1
        assert unknowns[0].component == "nonexistent"

    def test_unknown_component_different_methods_separate_emission(self):
        m = Monitor(
            Parser(baselines={"cpu": 50.0}, thresholds=Thresholds(intact=40, ablated=10)),
            window=20,
        )
        m.drift("missing")
        m.anomaly("missing")  # different call site → separate emission
        unknowns = m.issues.by_code(IssueCode.UNKNOWN_COMPONENT)
        assert len(unknowns) == 2


class TestNearZeroStdEmission:
    def test_anomaly_score_emits_near_zero_std(self):
        from margin import Fingerprint
        m = Monitor(
            Parser(baselines={"x": 1.0}, thresholds=Thresholds(intact=0.8, ablated=0.2)),
            window=20,
        )
        for _ in range(10):
            m.update({"x": 1.0})  # constant — std essentially 0
        current = m.fingerprint()
        # Construct a reference fingerprint with near-zero std
        ref = Fingerprint(stats={
            "x": {"mean": 1.0, "std": 0.0, "n": 10, "trend": "STABLE"}
        })
        score = m.anomaly_score(ref)
        # Skipped metric → NEAR_ZERO_STD issue
        near_zero = m.issues.by_code(IssueCode.NEAR_ZERO_STD)
        assert len(near_zero) == 1
        assert "x" in near_zero[0].context.get("skipped_metrics", [])


class TestStageAblatedOnEntry:
    def test_emits_warning_when_first_obs_ablated(self):
        stage = Stage(
            name="init",
            parser=Parser(
                baselines={"cpu": 50.0},
                thresholds=Thresholds(intact=40, ablated=30),
            ),
        )
        f = Flow(stages=[stage], label="test")
        # Value way below ablated threshold → ABLATED on first obs
        result = f.observe({"cpu": 5.0})
        entry_issues = f.issues.by_code(IssueCode.STAGE_ABLATED_ON_ENTRY)
        assert len(entry_issues) == 1
        assert entry_issues[0].component == "init"
        assert "cpu" in entry_issues[0].context.get("ablated_components", [])
        # Also attached to the step result
        assert any(i.code == IssueCode.STAGE_ABLATED_ON_ENTRY for i in result.issues)

    def test_no_emission_when_first_obs_healthy(self):
        stage = Stage(
            name="init",
            parser=Parser(
                baselines={"cpu": 50.0},
                thresholds=Thresholds(intact=40, ablated=10),
            ),
        )
        f = Flow(stages=[stage])
        f.observe({"cpu": 50.0})
        assert len(f.issues.by_code(IssueCode.STAGE_ABLATED_ON_ENTRY)) == 0

    def test_emission_only_on_first_obs_not_later(self):
        """If stage degrades on step 2, we don't re-emit STAGE_ABLATED_ON_ENTRY."""
        stage = Stage(
            name="init",
            parser=Parser(
                baselines={"cpu": 50.0},
                thresholds=Thresholds(intact=40, ablated=10),
            ),
        )
        f = Flow(stages=[stage])
        f.observe({"cpu": 50.0})   # healthy first obs
        f.observe({"cpu": 5.0})    # ABLATED second obs — not entry
        entry_issues = f.issues.by_code(IssueCode.STAGE_ABLATED_ON_ENTRY)
        assert len(entry_issues) == 0


class TestStatusIncludesIssues:
    def test_status_includes_issues_key(self):
        m = Monitor(
            Parser(baselines={"x": 1.0}, thresholds=Thresholds(intact=0.8, ablated=0.2)),
            window=20,
        )
        m.update({"x": 1.0})
        s = m.status()
        assert "issues" in s
        assert "total" in s["issues"]
        assert "counts" in s["issues"]

    def test_status_issues_are_json_serializable(self):
        m = Monitor(
            Parser(baselines={"cpu": 50.0}, thresholds=Thresholds(intact=40, ablated=10)),
            window=20,
        )
        m.update({"cpu": 50.0})
        m.drift("nonexistent")  # emits UNKNOWN_COMPONENT
        s = m.status()
        # Full status() must be json-safe — that's the dashboard contract.
        json.dumps(s)
