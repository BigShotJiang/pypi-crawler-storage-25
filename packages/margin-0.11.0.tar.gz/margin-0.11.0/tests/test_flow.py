"""Tests for Flow: ordered stages with typed guidance (v0.9.28)."""
import pytest

from margin import (
    Flow, Stage, Guidance,
    Parser, Thresholds, Health, Confidence,
    Expression, Absence,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _parser(baselines: dict, intact: float = 0.8, ablated: float = 0.2,
            higher: bool = True) -> Parser:
    return Parser(
        baselines=baselines,
        thresholds=Thresholds(intact=intact, ablated=ablated, higher_is_better=higher),
    )


# ---------------------------------------------------------------------------
# Guidance enum
# ---------------------------------------------------------------------------

class TestGuidanceEnum:
    def test_members(self):
        assert Guidance.ADVANCE.value == "ADVANCE"
        assert Guidance.HOLD.value == "HOLD"
        assert Guidance.RETRY.value == "RETRY"
        assert Guidance.ROLLBACK.value == "ROLLBACK"
        assert Guidance.ESCALATE.value == "ESCALATE"
        assert Guidance.COMPLETE.value == "COMPLETE"


# ---------------------------------------------------------------------------
# Flow construction
# ---------------------------------------------------------------------------

class TestFlowConstruction:
    def test_requires_at_least_one_stage(self):
        with pytest.raises(ValueError, match="at least one stage"):
            Flow(stages=[])

    def test_rejects_duplicate_stage_names(self):
        s1 = Stage(name="x", parser=_parser({"m": 1.0}))
        s2 = Stage(name="x", parser=_parser({"m": 1.0}))
        with pytest.raises(ValueError, match="unique names"):
            Flow(stages=[s1, s2])

    def test_starts_at_first_stage(self):
        s = Stage(name="init", parser=_parser({"m": 1.0}))
        f = Flow(stages=[s])
        assert f.current is s
        assert f.stage_index == 0
        assert not f.is_complete


# ---------------------------------------------------------------------------
# Observation routing
# ---------------------------------------------------------------------------

class TestObserve:
    def test_observe_returns_flow_result(self):
        s = Stage(name="init", parser=_parser({"m": 1.0}))
        f = Flow(stages=[s])
        result = f.observe({"m": 1.0})
        assert result.stage == "init"
        assert result.stage_index == 0
        assert result.total_stages == 1
        assert result.expression is not None

    def test_observe_routed_only_to_current_stage(self):
        s1 = Stage(name="a", parser=_parser({"m": 1.0}))
        s2 = Stage(name="b", parser=_parser({"m": 2.0}))
        f = Flow(stages=[s1, s2])
        f.observe({"m": 1.0})
        assert f._monitors["a"].expression is not None
        assert "b" not in f._monitors or f._monitors.get("b") is None

    def test_healthy_default_guidance_hold(self):
        s = Stage(name="init", parser=_parser({"m": 1.0}))
        f = Flow(stages=[s])
        result = f.observe({"m": 1.0})
        assert result.guidance == Guidance.HOLD

    def test_ablated_component_defaults_to_escalate(self):
        s = Stage(name="init", parser=_parser({"m": 1.0}, intact=0.8, ablated=0.5))
        f = Flow(stages=[s])
        # Value well below ablated threshold
        result = f.observe({"m": 0.1})
        assert result.guidance == Guidance.ESCALATE

    def test_degraded_component_defaults_to_retry(self):
        s = Stage(name="init", parser=_parser({"m": 1.0}, intact=0.8, ablated=0.2))
        f = Flow(stages=[s])
        # Value between ablated and intact
        result = f.observe({"m": 0.5})
        assert result.guidance == Guidance.RETRY


# ---------------------------------------------------------------------------
# Stage predicates
# ---------------------------------------------------------------------------

class TestStagePredicates:
    def test_advance_when_fires(self):
        s = Stage(
            name="init",
            parser=_parser({"m": 1.0}),
            advance_when=lambda expr: True,
        )
        f = Flow(stages=[s])
        result = f.observe({"m": 1.0})
        assert result.guidance == Guidance.ADVANCE

    def test_advance_when_inspects_expression(self):
        s = Stage(
            name="init",
            parser=_parser({"m": 1.0}),
            advance_when=lambda expr: (expr.health_of("m") == Health.INTACT),
        )
        f = Flow(stages=[s])
        assert f.observe({"m": 1.0}).guidance == Guidance.ADVANCE
        # reset for degraded run
        f.reset()
        assert f.observe({"m": 0.5}).guidance == Guidance.RETRY  # default fallback

    def test_escalate_when_overrides_advance(self):
        s = Stage(
            name="init",
            parser=_parser({"m": 1.0}),
            advance_when=lambda expr: True,
            escalate_when=lambda expr: True,
        )
        f = Flow(stages=[s])
        # escalate is checked first
        assert f.observe({"m": 1.0}).guidance == Guidance.ESCALATE

    def test_rollback_when_fires(self):
        s = Stage(
            name="init",
            parser=_parser({"m": 1.0}),
            rollback_when=lambda expr: True,
        )
        f = Flow(stages=[s])
        assert f.observe({"m": 1.0}).guidance == Guidance.ROLLBACK

    def test_retry_when_fires(self):
        s = Stage(
            name="init",
            parser=_parser({"m": 1.0}),
            retry_when=lambda expr: True,
        )
        f = Flow(stages=[s])
        result = f.observe({"m": 1.0})
        assert result.guidance == Guidance.RETRY


# ---------------------------------------------------------------------------
# Advancement
# ---------------------------------------------------------------------------

class TestAdvance:
    def _three_stage_flow(self) -> Flow:
        return Flow(stages=[
            Stage(name="a", parser=_parser({"m": 1.0})),
            Stage(name="b", parser=_parser({"m": 2.0})),
            Stage(name="c", parser=_parser({"m": 3.0})),
        ], label="abc")

    def test_advance_moves_to_next_stage(self):
        f = self._three_stage_flow()
        assert f.current.name == "a"
        f.advance()
        assert f.current.name == "b"
        assert f.stage_index == 1

    def test_advance_creates_fresh_monitor(self):
        f = self._three_stage_flow()
        f.observe({"m": 1.0})
        first_monitor = f.current_monitor
        f.advance()
        assert f.current_monitor is not first_monitor  # fresh instance
        assert f.current_monitor.step == 0

    def test_advance_from_last_completes(self):
        f = self._three_stage_flow()
        f.advance()  # a → b
        f.advance()  # b → c
        f.advance()  # c → complete
        assert f.is_complete
        assert f.current is None

    def test_advance_when_complete_raises(self):
        s = Stage(name="init", parser=_parser({"m": 1.0}))
        f = Flow(stages=[s])
        f.advance()
        with pytest.raises(ValueError, match="already complete"):
            f.advance()

    def test_observe_after_complete_returns_complete(self):
        s = Stage(name="init", parser=_parser({"m": 1.0}))
        f = Flow(stages=[s])
        f.advance()
        result = f.observe({"m": 1.0})
        assert result.guidance == Guidance.COMPLETE
        assert result.expression is None

    def test_transitions_log_advance(self):
        f = self._three_stage_flow()
        f.advance()
        assert len(f.transitions) == 1
        t = f.transitions[0]
        assert t["from"] == "a"
        assert t["to"] == "b"
        assert t["kind"] == "advance"

    def test_transitions_log_complete(self):
        s = Stage(name="init", parser=_parser({"m": 1.0}))
        f = Flow(stages=[s])
        f.advance()
        t = f.transitions[0]
        assert t["to"] == "(complete)"


# ---------------------------------------------------------------------------
# Rollback
# ---------------------------------------------------------------------------

class TestRollback:
    def test_rollback_from_first_raises(self):
        s = Stage(name="a", parser=_parser({"m": 1.0}))
        f = Flow(stages=[s])
        with pytest.raises(ValueError, match="first stage"):
            f.rollback()

    def test_rollback_returns_to_previous(self):
        f = Flow(stages=[
            Stage(name="a", parser=_parser({"m": 1.0})),
            Stage(name="b", parser=_parser({"m": 2.0})),
        ])
        f.advance()
        assert f.current.name == "b"
        f.rollback()
        assert f.current.name == "a"

    def test_rollback_creates_fresh_monitor(self):
        f = Flow(stages=[
            Stage(name="a", parser=_parser({"m": 1.0})),
            Stage(name="b", parser=_parser({"m": 2.0})),
        ])
        f.observe({"m": 1.0})
        original_monitor = f._monitors["a"]
        f.advance()
        f.rollback()
        assert f._monitors["a"] is not original_monitor

    def test_rollback_logs_transition(self):
        f = Flow(stages=[
            Stage(name="a", parser=_parser({"m": 1.0})),
            Stage(name="b", parser=_parser({"m": 2.0})),
        ])
        f.advance()
        f.rollback()
        assert f.transitions[-1]["kind"] == "rollback"
        assert f.transitions[-1]["from"] == "b"
        assert f.transitions[-1]["to"] == "a"


# ---------------------------------------------------------------------------
# Reset
# ---------------------------------------------------------------------------

class TestReset:
    def test_reset_returns_to_first_stage(self):
        f = Flow(stages=[
            Stage(name="a", parser=_parser({"m": 1.0})),
            Stage(name="b", parser=_parser({"m": 2.0})),
        ])
        f.advance()
        f.reset()
        assert f.current.name == "a"

    def test_reset_clears_transitions(self):
        f = Flow(stages=[
            Stage(name="a", parser=_parser({"m": 1.0})),
            Stage(name="b", parser=_parser({"m": 2.0})),
        ])
        f.advance()
        f.reset()
        assert f.transitions == []


# ---------------------------------------------------------------------------
# Serialization and rendering
# ---------------------------------------------------------------------------

class TestSerialization:
    def test_to_atom_running_includes_flow_label(self):
        f = Flow(stages=[
            Stage(name="lag", parser=_parser({"m": 1.0})),
            Stage(name="exp", parser=_parser({"m": 1.0})),
        ], label="ferment")
        result = f.observe({"m": 1.0})
        atom = result.to_atom()
        # Must include: flow_label, stage_name, position, guidance
        assert atom == "flow:ferment:lag[1/2] → HOLD"

    def test_to_atom_running_no_label(self):
        f = Flow(stages=[
            Stage(name="lag", parser=_parser({"m": 1.0})),
            Stage(name="exp", parser=_parser({"m": 1.0})),
        ])
        result = f.observe({"m": 1.0})
        assert result.to_atom() == "flow:lag[1/2] → HOLD"

    def test_to_atom_complete_includes_flow_label(self):
        s = Stage(name="only", parser=_parser({"m": 1.0}))
        f = Flow(stages=[s], label="linear")
        f.advance()
        result = f.observe({"m": 1.0})
        assert result.guidance == Guidance.COMPLETE
        assert result.to_atom() == "flow:linear[1/1]"

    def test_to_atom_complete_no_label(self):
        s = Stage(name="only", parser=_parser({"m": 1.0}))
        f = Flow(stages=[s])
        f.advance()
        result = f.observe({"m": 1.0})
        assert result.to_atom() == "flow[1/1]"

    def test_concurrent_flows_are_distinguishable(self):
        """Two flows with same stage names but different labels must
        produce distinguishable atoms — without this, operator dashboards
        can't tell flows apart."""
        f1 = Flow(stages=[Stage(name="step", parser=_parser({"m": 1.0}))], label="service_a")
        f2 = Flow(stages=[Stage(name="step", parser=_parser({"m": 1.0}))], label="service_b")
        r1 = f1.observe({"m": 1.0})
        r2 = f2.observe({"m": 1.0})
        assert r1.to_atom() != r2.to_atom()
        assert "service_a" in r1.to_atom()
        assert "service_b" in r2.to_atom()

    def test_flow_to_dict(self):
        f = Flow(stages=[
            Stage(name="a", parser=_parser({"m": 1.0})),
            Stage(name="b", parser=_parser({"m": 2.0})),
        ], label="test")
        d = f.to_dict()
        assert d["label"] == "test"
        assert d["stages"] == ["a", "b"]
        assert d["index"] == 0

    def test_flow_result_to_dict(self):
        s = Stage(name="a", parser=_parser({"m": 1.0}))
        f = Flow(stages=[s], label="t")
        result = f.observe({"m": 1.0})
        d = result.to_dict()
        assert d["stage"] == "a"
        assert d["flow_label"] == "t"
        assert d["guidance"] == "HOLD"
        assert "expression" in d


# ---------------------------------------------------------------------------
# Observe passthrough — absences, confidences
# ---------------------------------------------------------------------------

class TestObservePassthrough:
    def test_absences_flow_through(self):
        """Absences supplied to Flow.observe() must reach the Monitor and
        produce an OOD observation with typed absence in the Expression."""
        stage = Stage(
            name="s",
            parser=Parser(
                baselines={"m": 1.0, "n": 1.0},
                thresholds=Thresholds(intact=0.8, ablated=0.2),
            ),
        )
        f = Flow(stages=[stage])
        result = f.observe({"m": 1.0}, absences={"n": Absence.SENSOR_FAILED})
        obs_by_name = {o.name: o for o in result.expression.observations}
        assert obs_by_name["m"].is_absent is False
        assert obs_by_name["n"].is_absent is True
        assert obs_by_name["n"].absence == Absence.SENSOR_FAILED

    def test_confidences_flow_through(self):
        stage = Stage(name="s", parser=_parser({"m": 1.0}))
        f = Flow(stages=[stage])
        result = f.observe({"m": 1.0}, confidences={"m": Confidence.LOW})
        m = [o for o in result.expression.observations if o.name == "m"][0]
        assert m.confidence == Confidence.LOW


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_empty_values_dict(self):
        """Empty observation should return HOLD and not crash."""
        stage = Stage(name="s", parser=_parser({"m": 1.0}))
        f = Flow(stages=[stage])
        result = f.observe({})
        assert result.guidance == Guidance.HOLD
        assert result.expression is not None
        assert len(result.expression.observations) == 0

    def test_observe_complete_flow_safe(self):
        """observe() on a complete flow returns COMPLETE, doesn't raise."""
        f = Flow(stages=[Stage(name="a", parser=_parser({"m": 1.0}))], label="L")
        f.advance()
        r = f.observe({"m": 1.0})
        assert r.guidance == Guidance.COMPLETE
        assert r.to_atom() == "flow:L[1/1]"


# ---------------------------------------------------------------------------
# Realistic scenario: fermentation
# ---------------------------------------------------------------------------

class TestFermentationScenario:
    def test_advances_through_lag_then_exponential(self):
        """Simulate a tiny fermentation: lag → exponential → stationary."""
        lag = Stage(
            name="lag",
            parser=Parser(
                baselines={"biomass": 0.1},
                thresholds=Thresholds(intact=0.08, ablated=0.02),
            ),
            advance_when=lambda expr: any(
                o.name == "biomass" and o.value >= 0.15
                for o in expr.observations
            ),
        )
        expo = Stage(
            name="exponential",
            parser=Parser(
                baselines={"biomass": 0.5},
                thresholds=Thresholds(intact=0.4, ablated=0.2),
            ),
            advance_when=lambda expr: any(
                o.name == "biomass" and o.value >= 0.8
                for o in expr.observations
            ),
        )
        stationary = Stage(
            name="stationary",
            parser=Parser(
                baselines={"biomass": 1.0},
                thresholds=Thresholds(intact=0.8, ablated=0.3),
            ),
        )

        flow = Flow(stages=[lag, expo, stationary], label="ferment")

        # Lag phase
        assert flow.observe({"biomass": 0.10}).guidance == Guidance.HOLD
        assert flow.observe({"biomass": 0.12}).guidance == Guidance.HOLD
        assert flow.observe({"biomass": 0.16}).guidance == Guidance.ADVANCE
        flow.advance()

        # Exponential
        assert flow.current.name == "exponential"
        assert flow.observe({"biomass": 0.5}).guidance == Guidance.HOLD
        assert flow.observe({"biomass": 0.85}).guidance == Guidance.ADVANCE
        flow.advance()

        # Stationary — no advance_when, default HOLD when healthy
        assert flow.current.name == "stationary"
        assert flow.observe({"biomass": 1.0}).guidance == Guidance.HOLD
        flow.advance()
        assert flow.is_complete

    def test_stage_specific_thresholds_dont_bleed(self):
        """Each stage has its own Parser; a value that's intact in stage A
        could be degraded in stage B."""
        s1 = Stage(
            name="lag",
            parser=Parser(baselines={"biomass": 0.1},
                          thresholds=Thresholds(intact=0.05, ablated=0.01)),
        )
        s2 = Stage(
            name="exp",
            parser=Parser(baselines={"biomass": 0.8},
                          thresholds=Thresholds(intact=0.7, ablated=0.2)),
        )
        f = Flow(stages=[s1, s2])

        # 0.1 is intact in lag
        result = f.observe({"biomass": 0.1})
        assert result.expression.health_of("biomass") == Health.INTACT

        f.advance()
        # 0.1 is ablated in exp
        result = f.observe({"biomass": 0.1})
        assert result.expression.health_of("biomass") == Health.ABLATED
