"""One-call connection to Interlatent's hosted DRTC server.

Users do not deploy anything. They just call ``connect_drtc(...)``
with their Interlatent API key and the policy they want to run.

Example:

    from interlatent.inference.integration.connect import connect_drtc

    client = connect_drtc(
        api_key=os.environ["INTERLATENT_API_KEY"],
        model_id="smolvla-pickup",
        policy_uri="lerobot/smolvla_base",
        policy_backend="lerobot",
        fps=30,
    )
    try:
        while running:
            action = client.step(observation_npz_bytes, codec="npz")
            if action is not None:
                robot.apply(action)
    finally:
        client.close()

The server address defaults to Interlatent's hosted Modal app. Pass
``server_address=`` to override (useful for staging deploys or local
gRPC servers used during SDK development).
"""

from __future__ import annotations

import os
from typing import Optional

from ..client import DRTCClient, DRTCConfig

# Production URL for Interlatent's hosted DRTC server. Replace with
# the URL printed by `modal deploy` once the app is live.
# Override at runtime via env var INTERLATENT_DRTC_URL or via the
# ``server_address`` arg to connect_drtc().
DEFAULT_DRTC_URL = "https://interlatent--interlatent-drtc-inference-web.modal.run"


def connect_drtc(
    *,
    api_key: Optional[str] = None,
    model_id: str,
    policy_uri: str = "",
    policy_backend: str = "lerobot",
    server_address: Optional[str] = None,
    chunk_size: int = 50,
    action_dim: int = 6,
    min_execution_horizon: int = 12,
    cooldown_steps: int = 16,
    fps: float = 30.0,
    payload_codec: str = "npz",
    task: str = "",
    stats_interval_s: float = 5.0,
    metadata: Optional[dict[str, str]] = None,
) -> DRTCClient:
    """Open a DRTC session against Interlatent's hosted server.

    Returns an already-opened ``DRTCClient`` ready for ``step()``.

    Auth:
        Sends ``api_key`` (or the ``INTERLATENT_API_KEY`` env var) as
        a Bearer token. The server validates against the Interlatent
        backend on first contact and caches the result per-container.

    Args mirror ``DRTCConfig``; ``fps`` is converted to
    ``control_period_s`` for convenience.
    """
    key = api_key or os.environ.get("INTERLATENT_API_KEY", "")
    if not key:
        raise ValueError(
            "An Interlatent API key is required. Pass api_key=... or set "
            "INTERLATENT_API_KEY in your environment."
        )
    url = server_address or os.environ.get("INTERLATENT_DRTC_URL") or DEFAULT_DRTC_URL

    # Natural-language task (e.g. SmolVLA instruction) flows via
    # OpenSession metadata. The server pulls `task` and passes it as
    # default_task to the policy backend; LeRobotBackend then injects
    # it into every batch automatically.
    md = dict(metadata or {})
    if task:
        md.setdefault("task", task)

    cfg = DRTCConfig(
        server_address=url,
        api_key=key,
        model_id=model_id,
        policy_uri=policy_uri,
        policy_backend=policy_backend,
        chunk_size=chunk_size,
        action_dim=action_dim,
        min_execution_horizon=min_execution_horizon,
        cooldown_steps=cooldown_steps,
        control_period_s=1.0 / fps if fps > 0 else 1.0 / 30,
        payload_codec=payload_codec,
        # `use_grpc_web` is inferred from URL scheme — local plain-gRPC
        # uses host:port; the hosted Modal endpoint is an https URL.
        use_grpc_web=url.startswith(("http://", "https://")),
        stats_interval_s=stats_interval_s,
        metadata=md,
    )
    client = DRTCClient(cfg)
    client.open()
    return client


__all__ = ["connect_drtc", "DEFAULT_DRTC_URL"]
