"""Auto-detect hookable layers in PyTorch models (lazy torch import)."""
from __future__ import annotations

from typing import List


def _find_submodule(root, dotted: str):
    """Traverse a dotted attribute path to find a submodule."""
    mod = root
    for attr in dotted.split("."):
        mod = getattr(mod, attr, None)
        if mod is None:
            return None
    return mod


def list_layers(model, include_all: bool = False) -> List[dict]:
    """List hookable layers in a PyTorch model with their shapes.

    By default only shows ``nn.Linear`` and convolution layers.
    Set ``include_all=True`` to show every named module.

    Each entry is a dict with keys:
        - ``name``: dotted module path (pass this to ``layer=``)
        - ``type``: class name (e.g. ``"Linear"``)
        - ``shape``: human-readable shape string (e.g. ``"64 -> 128"``)

    Also prints a formatted table to stdout for interactive use.
    """
    import torch.nn as nn

    root = getattr(model, "policy", model)
    hookable_types = (nn.Linear, nn.Conv1d, nn.Conv2d, nn.Conv3d)
    results: List[dict] = []

    for name, mod in root.named_modules():
        if name == "":
            continue
        if not include_all and not isinstance(mod, hookable_types):
            continue

        type_name = type(mod).__name__
        shape = ""
        if isinstance(mod, nn.Linear):
            shape = f"{mod.in_features} -> {mod.out_features}"
        elif isinstance(mod, (nn.Conv1d, nn.Conv2d, nn.Conv3d)):
            shape = f"{mod.in_channels} -> {mod.out_channels}, kernel={mod.kernel_size}"
        else:
            w = getattr(mod, "weight", None)
            if w is not None and hasattr(w, "shape"):
                shape = str(tuple(w.shape))

        results.append({"name": name, "type": type_name, "shape": shape})

    # Print formatted table
    if results:
        max_name = max(len(r["name"]) for r in results)
        max_type = max(len(r["type"]) for r in results)
        header = f"  {'Layer Path':<{max_name}}  {'Type':<{max_type}}  Shape"
        print(f"\n{header}")
        print(f"  {'─' * max_name}  {'─' * max_type}  {'─' * 20}")
        for r in results:
            print(f"  {r['name']:<{max_name}}  {r['type']:<{max_type}}  {r['shape']}")
        print()
    else:
        print("\n  No hookable layers found.\n")

    return results


def detect_hookable_layers(
    model,
    max_layers: int = 3,
) -> List[str]:
    """Walk ``model.named_modules()`` and return dotted paths of hookable layers.

    Detection patterns (checked in order):
    1. SB3 MLP — ``mlp_extractor.policy_net``: return last ``nn.Linear``.
    2. SB3 CNN — ``features_extractor``: return last conv + last MLP linear.
    3. Generic fallback — all ``nn.Linear`` modules, return second-to-last.
    """
    import torch.nn as nn

    # Unwrap SB3 wrapper
    root = getattr(model, "policy", model)

    # Pattern 1: SB3 MLP extractor
    layers = _detect_sb3_mlp(root, nn)
    if layers:
        return layers[:max_layers]

    # Pattern 2: SB3 CNN extractor
    layers = _detect_sb3_cnn(root, nn)
    if layers:
        return layers[:max_layers]

    # Pattern 3: generic fallback
    layers = _detect_generic_linear(root, nn)
    return layers[:max_layers]


def _detect_sb3_mlp(root, nn) -> List[str]:
    mlp = _find_submodule(root, "mlp_extractor.policy_net")
    if mlp is None:
        return []

    last_linear = None
    for name, mod in mlp.named_modules():
        if isinstance(mod, nn.Linear):
            last_linear = name

    if last_linear is None:
        return []

    path = f"mlp_extractor.policy_net.{last_linear}" if last_linear else "mlp_extractor.policy_net"
    return [path]


def _detect_sb3_cnn(root, nn) -> List[str]:
    feat_ext = _find_submodule(root, "features_extractor")
    if feat_ext is None:
        return []

    last_conv = None
    last_linear = None
    for name, mod in feat_ext.named_modules():
        if name == "":
            continue
        if isinstance(mod, (nn.Conv1d, nn.Conv2d, nn.Conv3d)):
            last_conv = f"features_extractor.{name}"
        elif isinstance(mod, nn.Linear):
            last_linear = f"features_extractor.{name}"

    layers = []
    if last_conv:
        layers.append(last_conv)
    if last_linear:
        layers.append(last_linear)
    return layers


def _detect_generic_linear(root, nn) -> List[str]:
    linears: List[str] = []
    for name, mod in root.named_modules():
        if name == "":
            continue
        if isinstance(mod, nn.Linear):
            linears.append(name)

    if len(linears) >= 2:
        return [linears[-2]]
    elif linears:
        return [linears[0]]
    return []
