"""PyTorch forward hooks for activation capture (lazy torch import)."""
from __future__ import annotations

import itertools
import threading
from collections import deque
from concurrent.futures import Future, ThreadPoolExecutor
from contextlib import AbstractContextManager
from typing import Any, Callable, Dict, List, Optional, Sequence

from ._schema import ActivationEvent


def _find_submodule(root, dotted: str):
    """Traverse a dotted attribute path to find a submodule."""
    mod = root
    for attr in dotted.split("."):
        mod = getattr(mod, attr, None)
        if mod is None:
            return None
    return mod


class StepAlignedHookCtx(AbstractContextManager):
    """Forward-hook context that uses an external step counter from context.

    The hook itself only clones the output tensor on-device and appends it
    to a lightweight buffer.  All CPU-bound work (detach → cpu, DB writes)
    happens later when :meth:`drain` is called — typically from
    ``Watcher.tick()``.  This avoids device-to-host transfers and Python-
    level I/O inside the forward pass, which would invalidate CUDA graphs
    and stall compiled / fused kernels.

    All torch imports are deferred to method calls.
    """

    def __init__(
        self,
        model,
        *,
        context_supplier: Optional[Callable[[], Dict[str, Any]]] = None,
        layers: Sequence[str],
        db,
        max_channels: int | None = None,
        step_key: str = "step",
    ) -> None:
        self.model = model
        self.layers = list(layers)
        self.db = db
        self.max_channels = max_channels
        self.step_key = step_key
        self._ctx_fn = context_supplier or (lambda: {})

        self._handles: List = []
        self._step_counter = itertools.count().__next__

        self._module_lookup: Dict[str, Any] = {}
        for name in self.layers:
            mod = _find_submodule(model, name)
            if mod is None:
                raise ValueError(f"Layer '{name}' not found in model")
            self._module_lookup[name] = mod

        # Deferred-write buffer: list of (layer_name, gpu_tensor_clone)
        # populated by the hook, drained by drain().
        self._buffer: deque[tuple[str, Any]] = deque()
        self._buffer_lock = threading.Lock()

        # Background drain thread — GPU→CPU transfer, serialization, and
        # DB writes happen here instead of blocking the inference loop.
        self._drain_pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="hook-drain")
        self._drain_future: Future | None = None

    def __enter__(self):
        for layer_name, module in self._module_lookup.items():
            handle = module.register_forward_hook(self._make_hook(layer_name))
            self._handles.append(handle)
        return self

    def __exit__(self, exc_type, exc, tb):
        self.drain_sync()
        for h in self._handles:
            h.remove()
        self._handles.clear()
        self._drain_pool.shutdown(wait=True)
        return False

    # ------------------------------------------------------------------
    # Public: flush buffered activations to DB
    # ------------------------------------------------------------------

    def drain(self) -> None:
        """Swap the buffer and submit GPU→CPU + DB work to a background
        thread.  Returns immediately — the inference loop is not blocked.

        If the previous drain is still running, this waits for it first
        to cap in-flight GPU memory at ~2 batches.
        """
        with self._buffer_lock:
            if not self._buffer:
                return
            items = list(self._buffer)
            self._buffer.clear()

        # Snapshot context now (on the inference thread) so the
        # background worker sees the correct step/episode state.
        ctx_snapshot = dict(self._ctx_fn())

        # Back-pressure: wait for the previous drain to finish before
        # submitting new work.  This bounds GPU tensor accumulation to
        # at most the current batch + one in-flight batch.
        if self._drain_future is not None:
            self._drain_future.result()

        self._drain_future = self._drain_pool.submit(
            self._drain_work, items, ctx_snapshot,
        )

    def drain_sync(self) -> None:
        """Block until all in-flight drain work completes.

        Call this from ``stop()`` / ``close()`` to ensure every
        buffered activation has been written to the DB.
        """
        # First drain any remaining items in the buffer.
        with self._buffer_lock:
            remaining = list(self._buffer)
            self._buffer.clear()

        if self._drain_future is not None:
            self._drain_future.result()
            self._drain_future = None

        if remaining:
            ctx_snapshot = dict(self._ctx_fn())
            self._drain_work(remaining, ctx_snapshot)

    # ------------------------------------------------------------------
    # Background drain worker
    # ------------------------------------------------------------------

    def _drain_work(
        self,
        items: list[tuple[str, Any]],
        ctx_snapshot: dict[str, Any],
    ) -> int:
        """GPU→CPU transfer, serialization, and DB writes.

        Runs on the background drain thread — never on the inference
        thread.
        """
        import torch

        db = self.db
        max_channels = self.max_channels
        step_key = self.step_key
        step_counter = self._step_counter

        written = 0
        for layer_name, tensor_gpu in items:
            tensor = tensor_gpu.detach().cpu()
            if tensor.ndim < 2:
                tensor = tensor.unsqueeze(1)
            B, C = tensor.shape[:2]
            if max_channels is not None:
                C = min(C, max_channels)
                tensor = tensor[:, :C]

            if tensor.ndim > 2:
                tensor = tensor.reshape(B, C, -1).mean(dim=-1)
            else:
                tensor = tensor.reshape(B, C)

            episode_id = ctx_snapshot.get("episode_id", "")
            base_step = ctx_snapshot.get(step_key)
            if base_step is None:
                base_step = step_counter()

            for b in range(B):
                step = base_step + b if B > 1 else base_step
                vec = tensor[b].float()
                ctx = dict(ctx_snapshot)
                ctx[step_key] = step
                ev = ActivationEvent(
                    episode_id=episode_id,
                    step=int(step),
                    layer=layer_name,
                    channel=0,
                    tensor=vec.tolist(),
                    value_sum=float(vec.sum()),
                    value_sq_sum=float((vec**2).sum()),
                    context=ctx,
                )
                db.write_event(ev)
                written += 1

        return written

    # ------------------------------------------------------------------
    # Hook factory
    # ------------------------------------------------------------------

    def _make_hook(self, layer_name: str):
        buffer = self._buffer
        buffer_lock = self._buffer_lock

        def _hook(module, inp, out):
            import torch

            # Skip during CUDA graph capture to avoid
            # cudaErrorStreamCaptureInvalidated errors.
            if torch.cuda.is_available() and torch.cuda.is_current_stream_capturing():
                return

            # Clone on-device only — no .cpu(), no Python I/O.
            # This keeps the hook CUDA-graph-safe and avoids stalling
            # compiled/fused kernels with a device sync.
            cloned = out.detach().clone()
            with buffer_lock:
                buffer.append((layer_name, cloned))

        return _hook
