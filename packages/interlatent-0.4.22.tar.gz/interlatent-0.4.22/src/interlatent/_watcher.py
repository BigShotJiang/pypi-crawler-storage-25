"""Passive forward-hook watcher for user-driven training loops."""
from __future__ import annotations

import uuid
from typing import Any, Callable, Dict, List, Optional, Sequence

from ._db import CollectionDB
from ._failures import FailureTaxonomy
from ._hooks import StepAlignedHookCtx
from ._schema import ActivationEvent, EpisodeInfo


# Sentinel "layer" written for every step regardless of whether activation
# hooks are installed. The row carries the full per-step context (obs,
# action, reward, metrics, ...) and is the source of truth for the
# upload-time LeRobot rebuild. Real layer rows carry only activation
# tensors with no context.
_CTX_LAYER = "_ctx"


def _flatten(value) -> List[float]:
    """Flatten obs/action into a python list of floats (lossless)."""
    if value is None:
        return []
    try:
        import numpy as np
        arr = np.asarray(value).reshape(-1).astype(float)
        return arr.tolist()
    except Exception:
        if hasattr(value, "__iter__"):
            try:
                return [float(v) for v in value]
            except Exception:
                return []
        try:
            return [float(value)]
        except Exception:
            return []


class Watcher:
    """Passive hook watcher driven by an external training loop.

    Hooks the model on ``start()`` and records activations into a ``CollectionDB``.
    The caller drives the training loop and calls ``tick()`` after each step.

    When ``layers`` is empty (e.g. ``record_activations=False`` at the client
    level) no forward hook is installed. The watcher still writes one
    ``_ctx`` row per ``tick()`` so observation / action / reward / metrics are
    captured for the upload-time LeRobot rebuild.
    """

    def __init__(
        self,
        model,
        *,
        layers: Sequence[str],
        env_name: str,
        db: CollectionDB,
        metrics: List | None = None,
        taxonomy: FailureTaxonomy | None = None,
        context_fn: Callable[..., Dict[str, Any]] | None = None,
        max_channels: int | None = None,
        total_steps: int | None = None,
        run_id: str | None = None,
        episode_id: str | None = None,
    ) -> None:
        self._model = model
        self._layers = list(layers)
        self._env_name = env_name
        self._db = db
        self._metrics = {m.name: m for m in (metrics or [])}
        self._taxonomy = taxonomy
        self._context_fn = context_fn
        self._max_channels = max_channels
        self._total_steps = total_steps

        self._run_id = run_id or str(uuid.uuid4())
        self._step = 0
        # Caller may pin the first episode_id (used by the node daemon so
        # InferenceSession.id == Episode.episode_id end-to-end). Subsequent
        # episodes created via roll_episode() always get fresh uuids.
        self._episode_id = episode_id or str(uuid.uuid4())
        self._all_episode_ids: List[str] = [self._episode_id]
        self._episode_step = 0
        self._episode_reward_acc = 0.0

        # Mutable context dict shared with the hook's context_supplier
        self._step_ctx: Dict[str, Any] = {}

        self._hook_ctx: StepAlignedHookCtx | None = None
        self._started = False

        self._episode_info = EpisodeInfo(
            episode_id=self._episode_id,
            env_name=self._env_name,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def run_id(self) -> str:
        return self._run_id

    @property
    def start_time(self) -> str:
        return self._episode_info.start_time

    @property
    def episode_id(self) -> str:
        return self._episode_id

    @property
    def all_episode_ids(self) -> List[str]:
        return list(self._all_episode_ids)

    @property
    def step(self) -> int:
        return self._step

    @property
    def db(self) -> CollectionDB:
        return self._db

    def start(self) -> "Watcher":
        """Register forward hooks on the model.

        When ``self._layers`` is empty no hooks are installed — the watcher
        is "headless" and only records the per-step ``_ctx`` rows.
        """
        if self._started:
            return self

        if self._layers:
            # Unwrap SB3 wrapper
            root = getattr(self._model, "policy", self._model)
            self._hook_ctx = StepAlignedHookCtx(
                root,
                context_supplier=lambda: dict(self._step_ctx),
                layers=self._layers,
                db=self._db,
                max_channels=self._max_channels,
            )
            self._hook_ctx.__enter__()
        self._started = True
        return self

    def tick(
        self,
        *,
        obs,
        action,
        reward: float = 0.0,
        done: bool = False,
        truncated: bool = False,
        info: dict | None = None,
    ) -> None:
        """Called by the training loop after each env.step().

        ``obs`` and ``action`` are required: they become the
        ``observation.state`` and ``action`` columns in the LeRobot
        dataset built at upload time. Pass the ``obs`` from *before*
        the action was taken (i.e. ``s_t``, not ``s_{t+1}``).
        """
        # Compute metrics
        metric_vals: Dict[str, float | None] = {}
        for m in self._metrics.values():
            val = m.step(
                obs=obs, reward=reward, info=info,
                done=done, truncated=truncated,
            )
            metric_vals[m.name] = val

        # Accumulate episode reward for taxonomy
        self._episode_reward_acc += float(reward)

        # Evaluate failure taxonomy (only for compiled taxonomies with expressions)
        if self._taxonomy is not None and self._taxonomy.is_compiled:
            failure_matches = self._taxonomy.evaluate_step_all(
                obs=obs,
                reward=float(reward),
                metrics={k: v for k, v in metric_vals.items() if v is not None},
                done=done,
                truncated=truncated,
                episode_reward=self._episode_reward_acc,
            )
            failure_type = next(iter(failure_matches), None) if failure_matches else None
        else:
            failure_matches = {}
            failure_type = None

        # Build context for this step. ``observation`` and ``action`` carry
        # the full vectors — at upload time the rebuilder reads them as the
        # canonical LeRobot ``observation.state`` / ``action`` columns.
        ctx: Dict[str, Any] = {
            "env_id": self._env_name,
            "episode_id": self._episode_id,
            "t": self._episode_step,
            "step": self._step,
            "reward": float(reward),
            "done": bool(done),
            "truncated": bool(truncated),
            "metrics": metric_vals,
            "observation": _flatten(obs),
            "action": _flatten(action),
        }

        if failure_type is not None:
            ctx["failure_type"] = failure_type
        if failure_matches:
            ctx["failures"] = failure_matches

        # User-supplied context extension
        if self._context_fn is not None:
            extra = self._context_fn(
                obs=obs, reward=reward, done=done,
                truncated=truncated, info=info,
            )
            if extra:
                ctx.update(extra)

        # Update mutable dict read by hook context_supplier on next forward pass
        self._step_ctx.clear()
        self._step_ctx.update(ctx)

        # Drain deferred hook buffer — moves GPU tensors to CPU and writes
        # to DB *outside* the forward pass so CUDA graphs stay intact.
        if self._hook_ctx is not None:
            self._hook_ctx.drain()

        # Always write a _ctx row carrying the full per-step context.
        # This is the source of truth for the upload-time rebuild —
        # activation rows (if any) carry only the tensor.
        self._db.write_event(ActivationEvent(
            episode_id=self._episode_id,
            step=self._step,
            layer=_CTX_LAYER,
            channel=0,
            tensor=[],
            context=ctx,
        ))

        self._step += 1
        self._episode_step += 1

        # Handle episode boundaries — generate a fresh UUID for the next episode
        if done or truncated:
            self.reset_episode()

    def reset_episode(self) -> None:
        """Begin a new episode: reset metrics, step counter, and reward accumulator."""
        for m in self._metrics.values():
            m.reset()
        self._episode_id = str(uuid.uuid4())
        self._all_episode_ids.append(self._episode_id)
        self._episode_step = 0
        self._episode_reward_acc = 0.0

    def reset_session(self) -> None:
        """Start a fresh upload session.

        Called after ``upload()`` succeeds and the staging cache is wiped.
        Generates a new episode UUID and clears per-episode counters; the
        global step counter persists so multi-checkpoint training runs
        keep a continuous step axis. Subsequent ticks belong to a new
        inbox session.
        """
        self.reset_episode()
        self._all_episode_ids = [self._episode_id]
        self._episode_info = EpisodeInfo(
            episode_id=self._episode_id,
            env_name=self._env_name,
        )

    def stop(self) -> None:
        """Remove hooks and flush remaining data."""
        if not self._started:
            return
        # Wait for all in-flight background drain work to finish,
        # then drain any final buffered activations synchronously.
        if self._hook_ctx is not None:
            self._hook_ctx.drain_sync()
            self._hook_ctx.__exit__(None, None, None)
            self._hook_ctx = None
        self._db.flush()
        self._started = False

    def close(self) -> None:
        """Stop and release resources."""
        self.stop()
