from __future__ import annotations

import time
from typing import Any

from ._http import HTTPClient


class IndexResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def retrieve(self) -> dict[str, Any]:
        return self._http.request("GET", "/api/v1/index")


class EnvironmentsResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self) -> list[dict[str, Any]]:
        return self._http.request("GET", "/api/v1/environments")

    def create(
        self,
        *,
        slug: str,
        display_name: str,
        robot_type: str | None = None,
        num_cameras: int | None = None,
        camera_names: list[str] | None = None,
        action_dim: int | None = None,
        observation_keys: list[str] | None = None,
        task_description: str | None = None,
        preset: str | None = None,
        notes: str | None = None,
        environment_type: str | None = None,
        vlm_enabled: bool = True,
        failure_cases: dict[str, str] | None = None,
        vlm_scoring_targets: dict[str, str] | None = None,
        vlm_model: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "slug": slug,
            "display_name": display_name,
            "vlm_enabled": vlm_enabled,
        }
        if robot_type is not None:
            body["robot_type"] = robot_type
        if num_cameras is not None:
            body["num_cameras"] = num_cameras
        if camera_names is not None:
            body["camera_names"] = camera_names
        if action_dim is not None:
            body["action_dim"] = action_dim
        if observation_keys is not None:
            body["observation_keys"] = observation_keys
        if task_description is not None:
            body["task_description"] = task_description
        if preset is not None:
            body["preset"] = preset
        if notes is not None:
            body["notes"] = notes
        if environment_type is not None:
            body["environment_type"] = environment_type
        if failure_cases is not None:
            body["failure_cases"] = failure_cases
        if vlm_scoring_targets is not None:
            body["vlm_scoring_targets"] = vlm_scoring_targets
        if vlm_model is not None:
            body["vlm_model"] = vlm_model
        return self._http.request("POST", "/api/v1/environments", json_body=body)

    def episodes(self, env_id: str, *, limit: int = 20, offset: int = 0) -> dict[str, Any]:
        return self._http.request(
            "GET",
            f"/api/v1/environments/{env_id}/episodes",
            params={"limit": limit, "offset": offset},
        )


class EpisodesResource:
    """Resource for episode CRUD, upload, and processing."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def retrieve(self, episode_id: str) -> dict[str, Any]:
        return self._http.request("GET", f"/api/v1/episodes/{episode_id}")

    def create(
        self,
        *,
        episode_id: str,
        environment: str,
        layer: str,
        model_id: str | None = None,
        created_at: str | None = None,
        policy_path: str | None = None,
        collect_steps: int | None = None,
        pipeline_status: dict[str, bool] | None = None,
        tags: dict[str, str] | None = None,
        sdk_version: str | None = None,
        model_framework: str | None = None,
        failure_taxonomy: dict[str, str] | None = None,
        metric_definitions: list[str] | None = None,
        reward_config: dict[str, Any] | None = None,
        visual_criteria: list[dict[str, str]] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "episode_id": episode_id,
            "environment": environment,
            "layer": layer,
            "created_at": created_at,
            "policy_path": policy_path,
            "collect_steps": collect_steps,
            "pipeline_status": pipeline_status or {},
            "tags": tags or {},
            "reward_config": reward_config,
        }
        if model_id is not None:
            body["model_id"] = model_id
        if sdk_version is not None:
            body["sdk_version"] = sdk_version
        if model_framework is not None:
            body["model_framework"] = model_framework
        if failure_taxonomy is not None:
            body["failure_taxonomy"] = failure_taxonomy
        if metric_definitions is not None:
            body["metric_definitions"] = metric_definitions
        if visual_criteria is not None:
            body["visual_criteria"] = visual_criteria
        return self._http.request("POST", "/api/v1/episodes", json_body=body)

    def upload_urls(self, episode_id: str, *, files: list[dict[str, Any]]) -> dict[str, Any]:
        return self._http.request(
            "POST",
            f"/api/v1/episodes/{episode_id}/upload-urls",
            json_body={"files": files},
        )

    def upload_complete(self, episode_id: str, *, manifest: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._http.request(
            "POST",
            f"/api/v1/episodes/{episode_id}/upload-complete",
            json_body={"manifest": manifest},
        )

    def gc_inbox(self, episode_id: str, *, session_uuid: str) -> dict[str, Any]:
        """Best-effort cleanup of an inbox prefix after a failed upload.

        Anchors on ``episode_id`` (any episode in the session works) and
        asks the backend to delete every object under
        ``_inbox/{session_uuid}/`` for that model. The SDK calls this
        in ``upload()``'s failure path; preserving local staging on the
        client side so the user can retry.
        """
        return self._http.request(
            "POST",
            f"/api/v1/episodes/{episode_id}/inbox-gc",
            json_body={"session_uuid": session_uuid},
        )

    def update(
        self,
        episode_id: str,
        *,
        pipeline_status: dict[str, bool] | None = None,
        tags: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._http.request(
            "PATCH",
            f"/api/v1/episodes/{episode_id}",
            json_body={"pipeline_status": pipeline_status, "tags": tags},
        )

    def status(self, episode_id: str) -> dict[str, Any]:
        """Get episode status including latest processing job."""
        return self._http.request("GET", f"/api/v1/episodes/{episode_id}/status")

    def results(self, episode_id: str) -> dict[str, Any]:
        """Get processing results (report, export URLs, etc.)."""
        return self._http.request("GET", f"/api/v1/episodes/{episode_id}/results")

    def wait(
        self,
        episode_id: str,
        *,
        timeout: float = 300.0,
        poll: float = 5.0,
    ) -> dict[str, Any]:
        """Poll until server-side processing is completed or failed."""
        deadline = time.monotonic() + timeout
        while True:
            data = self.status(episode_id)
            processing = data.get("processing")
            if processing:
                st = processing.get("status", "")
                if st in ("completed", "failed"):
                    return data
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Processing for episode {episode_id} did not complete "
                    f"within {timeout}s (last status: {data})"
                )
            time.sleep(poll)

    # -- Episode data (frames, chunks, meta) --

    def meta(self, episode_id: str) -> dict[str, Any]:
        return self._http.request("GET", f"/api/v1/episodes/{episode_id}/meta")

    def chunk(self, episode_id: str, chunk_index: int) -> dict[str, Any]:
        return self._http.request("GET", f"/api/v1/episodes/{episode_id}/chunks/{chunk_index}")

    def frame(self, episode_id: str, filename: str) -> bytes:
        data = self._http.request("GET", f"/api/v1/episodes/{episode_id}/frames/{filename}")
        if isinstance(data, bytes):
            return data
        if isinstance(data, str):
            return data.encode("utf-8")
        raise TypeError("Expected frame bytes response")


# Backward compat alias — old code used RunsResource
RunsResource = EpisodesResource


class ModelsResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def get(self, model_id: str) -> dict[str, Any]:
        """Fetch a model's configuration from the backend."""
        return self._http.request("GET", f"/api/v1/models/{model_id}")

    def process(
        self,
        model_id: str,
        *,
        sae_k: int = 32,
        sae_epochs: int = 20,
        sae_l1: float = 0.05,
        sae_top_k: int = 0,
        normalize: bool = True,
        skip_autolabel: bool = False,
        skip_export: bool = False,
        vlm_chunk_size: int | None = None,
        vlm_frames_between: int | None = None,
        visual_criteria: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Trigger server-side processing for all episodes under a model."""
        body: dict[str, Any] = {
            "sae_k": sae_k,
            "sae_epochs": sae_epochs,
            "sae_l1": sae_l1,
            "sae_top_k": sae_top_k,
            "normalize": normalize,
            "skip_autolabel": skip_autolabel,
            "skip_export": skip_export,
        }
        if vlm_chunk_size is not None:
            body["vlm_chunk_size"] = vlm_chunk_size
        if vlm_frames_between is not None:
            body["vlm_frames_between"] = vlm_frames_between
        if visual_criteria is not None:
            body["visual_criteria"] = visual_criteria
        return self._http.request(
            "POST",
            f"/api/v1/models/{model_id}/process",
            json_body=body,
            timeout=120,
        )


class LatentsResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self, model_id: str) -> list[dict[str, Any]]:
        return self._http.request("GET", f"/api/v1/models/{model_id}/latents")

    def retrieve(self, model_id: str, latent_id: int) -> dict[str, Any]:
        return self._http.request("GET", f"/api/v1/models/{model_id}/latents/{latent_id}")

    def create(self, model_id: str, *, latents: list[dict[str, Any]]) -> dict[str, Any]:
        return self._http.request(
            "POST",
            f"/api/v1/models/{model_id}/latents",
            json_body={"latents": latents},
        )


class CheckpointsResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self, model_id: str) -> list[dict[str, Any]]:
        return self._http.request("GET", f"/api/v1/models/{model_id}/checkpoints")

    def retrieve(self, model_id: str, checkpoint_id: str) -> dict[str, Any]:
        return self._http.request("GET", f"/api/v1/models/{model_id}/checkpoints/{checkpoint_id}")

    def create(self, model_id: str, *, report: dict[str, Any]) -> dict[str, Any]:
        return self._http.request(
            "POST",
            f"/api/v1/models/{model_id}/checkpoints",
            json_body={"report": report},
        )


class AuthResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def login(self, *, email: str, password: str) -> dict[str, Any]:
        return self._http.request(
            "POST",
            "/api/v1/auth/login",
            json_body={"email": email, "password": password},
        )
