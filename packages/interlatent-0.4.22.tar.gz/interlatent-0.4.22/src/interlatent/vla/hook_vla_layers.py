# Lerobot subpackage for Interlatent

""" 
This subpackage is used to hook interlatent to policies run via interlatent.
VLA Policy Module Inspector
============================
Walks a VLA policy's submodule tree to identify backbone encoders and MLP
action heads, then drills into backbone encoders to enumerate their layers
with special attention to multi-head attention modules (useful for
extracting attention scores over image tokens).

Usage:
    from inspect_vla_policy import inspect_policy

    # Given a VLA policy (an nn.Module):
    inspect_policy(policy)
"""

from __future__ import annotations

import re
import torch
import torch.nn as nn
from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Primitive / leaf module types — do not recurse into these
# ---------------------------------------------------------------------------

_LEAF_TYPES = (
    nn.Linear,
    nn.Conv1d,
    nn.Conv2d,
    nn.Conv3d,
    nn.ConvTranspose1d,
    nn.ConvTranspose2d,
    nn.ConvTranspose3d,
    nn.Embedding,
    nn.EmbeddingBag,
    nn.LayerNorm,
    nn.BatchNorm1d,
    nn.BatchNorm2d,
    nn.BatchNorm3d,
    nn.GroupNorm,
    nn.InstanceNorm1d,
    nn.InstanceNorm2d,
    nn.InstanceNorm3d,
    nn.MultiheadAttention,
    nn.LSTM,
    nn.GRU,
    nn.RNN,
    nn.Dropout,
    nn.Dropout2d,
    nn.Dropout3d,
)

_ATTENTION_TYPES = (
    "MultiheadAttention",
    "MultiHeadAttention",
    "SelfAttention",
    "Attention",
    "SdpaAttention",
    "FlashAttention",
    "CausalSelfAttention",
)


def _is_leaf(module: nn.Module) -> bool:
    """Return True if this module should not be recursed into."""
    return isinstance(module, _LEAF_TYPES)


def _is_attention(module: nn.Module) -> bool:
    cls_name = type(module).__name__
    return any(t.lower() in cls_name.lower() for t in _ATTENTION_TYPES)


def _is_linear(module: nn.Module) -> bool:
    return isinstance(module, nn.Linear)


def _name_matches(full_name: str, patterns: list[str]) -> bool:
    """Return True if full_name matches any of the given glob-style or regex patterns."""
    return any(re.search(pat, full_name) for pat in patterns)


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------

@dataclass
class LayerRef:
    """A reference to a discovered layer."""
    full_name: str
    module: nn.Module
    kind: str  # "attention" or "linear"
    num_heads: Optional[int] = None
    embed_dim: Optional[int] = None
    in_features: Optional[int] = None
    out_features: Optional[int] = None

    def __repr__(self) -> str:
        meta = []
        if self.kind == "attention":
            if self.num_heads:
                meta.append(f"heads={self.num_heads}")
            if self.embed_dim:
                meta.append(f"embed_dim={self.embed_dim}")
        else:
            if self.in_features:
                meta.append(f"in={self.in_features}")
            if self.out_features:
                meta.append(f"out={self.out_features}")
        meta_str = "  " + ", ".join(meta) if meta else ""
        return f"[{self.kind.upper()}] {self.full_name} ({type(self.module).__name__}){meta_str}"


# ---------------------------------------------------------------------------
# Core recursive walker
# ---------------------------------------------------------------------------

def _walk(
    module: nn.Module,
    prefix: str,
    attn_refs: list[LayerRef],
    linear_refs: list[LayerRef],
    max_attn: Optional[int],
    max_linear: Optional[int],
    name_patterns: list[str],
) -> None:
    """Recursively walk *module*, collecting attention and linear layers."""

    for child_name, child in module.named_children():
        full_name = f"{prefix}.{child_name}" if prefix else child_name

        # Check name filter — if patterns given, skip non-matching leaves
        name_ok = (not name_patterns) or _name_matches(full_name, name_patterns)

        if _is_attention(child):
            if name_ok and (max_attn is None or len(attn_refs) < max_attn):
                num_heads = getattr(child, "num_heads", None) or getattr(child, "num_attention_heads", None)
                embed_dim = getattr(child, "embed_dim", None) or getattr(child, "hidden_size", None)
                attn_refs.append(LayerRef(
                    full_name=full_name,
                    module=child,
                    kind="attention",
                    num_heads=num_heads,
                    embed_dim=embed_dim,
                ))
            # Attention modules are also leaves — do not recurse further
            continue

        if _is_linear(child):
            if name_ok and (max_linear is None or len(linear_refs) < max_linear):
                linear_refs.append(LayerRef(
                    full_name=full_name,
                    module=child,
                    kind="linear",
                    in_features=child.in_features,
                    out_features=child.out_features,
                ))
            # Linear is a leaf — do not recurse further
            continue

        if _is_leaf(child):
            # Other leaf types (norm, dropout, etc.) — skip silently
            continue

        # Not a leaf — recurse
        _walk(child, full_name, attn_refs, linear_refs, max_attn, max_linear, name_patterns)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def inspect_policy(
    policy: nn.Module,
    max_attn_layers: Optional[int] = None,
    max_linear_layers: Optional[int] = None,
    name_patterns: Optional[list[str]] = None,
    verbose: bool = True,
) -> tuple[list[LayerRef], list[LayerRef]]:
    """Walk *policy* and return references to all attention and linear layers.

    Parameters
    ----------
    policy : nn.Module
        The top-level VLA policy module.
    max_attn_layers : int, optional
        Stop collecting attention layers after this many are found.
    max_linear_layers : int, optional
        Stop collecting linear layers after this many are found.
    name_patterns : list[str], optional
        Only include layers whose full dotted name matches at least one
        regex pattern (e.g. ``["vision_encoder", r"layers\\.0"]``).
        If None or empty, all layers are included.
    verbose : bool
        Print a summary table when True.

    Returns
    -------
    attn_layers : list[LayerRef]
    linear_layers : list[LayerRef]
    """
    attn_refs: list[LayerRef] = []
    linear_refs: list[LayerRef] = []
    patterns = name_patterns or []

    _walk(policy, "", attn_refs, linear_refs, max_attn_layers, max_linear_layers, patterns)

    if verbose:
        sep = "=" * 70
        total = sum(p.numel() for p in policy.parameters())
        total_str = f"{total / 1e9:.2f}B" if total >= 1e9 else f"{total / 1e6:.2f}M"
        print(f"\n{sep}")
        print(f"POLICY INSPECTION  —  {type(policy).__name__}  ({total_str} params)")
        print(sep)
        print(f"\nAttention layers ({len(attn_refs)}):")
        for r in attn_refs:
            print(f"  {r}")
        print(f"\nLinear layers ({len(linear_refs)}):")
        for r in linear_refs:
            print(f"  {r}")
        print()

    return attn_refs, linear_refs


# ---------------------------------------------------------------------------
# Demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import torch

    class ToyAttention(nn.Module):
        def __init__(self, dim=128, num_heads=4):
            super().__init__()
            self.num_heads = num_heads
            self.embed_dim = dim
            self.attn = nn.MultiheadAttention(dim, num_heads, batch_first=True)
            self.norm = nn.LayerNorm(dim)

        def forward(self, x):
            out, _ = self.attn(x, x, x)
            return self.norm(out + x)

    class ToyBlock(nn.Module):
        def __init__(self, dim=128):
            super().__init__()
            self.self_attn = ToyAttention(dim)
            self.mlp = nn.Sequential(nn.Linear(dim, dim * 4), nn.GELU(), nn.Linear(dim * 4, dim))

        def forward(self, x):
            return x + self.mlp(self.self_attn(x))

    class ToyEncoder(nn.Module):
        def __init__(self):
            super().__init__()
            self.patch_embed = nn.Linear(768, 128)
            self.blocks = nn.ModuleList([ToyBlock() for _ in range(3)])

        def forward(self, x):
            x = self.patch_embed(x)
            for b in self.blocks:
                x = b(x)
            return x

    class ToyPolicy(nn.Module):
        def __init__(self):
            super().__init__()
            self.vision_encoder = ToyEncoder()
            self.action_head = nn.Sequential(nn.Linear(128, 64), nn.ReLU(), nn.Linear(64, 7))

        def forward(self, x):
            return self.action_head(self.vision_encoder(x)[:, 0])

    policy = ToyPolicy()

    print("--- All layers ---")
    attn, linear = inspect_policy(policy)

    print("--- Only vision_encoder, max 2 attn ---")
    attn, linear = inspect_policy(policy, max_attn_layers=2, name_patterns=["vision_encoder"])
